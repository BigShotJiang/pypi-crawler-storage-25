"""
REST API view for Dashboard Migration.
"""

import base64
import logging
from flask import jsonify, request
from flask_appbuilder import BaseView, expose
from flask_login import current_user

logger = logging.getLogger(__name__)


def get_current_username():
    """Get current user's username."""
    if current_user and current_user.is_authenticated:
        return getattr(current_user, 'username', 'admin')
    return 'anonymous'


class MigrationAPIView(BaseView):
    """REST API endpoints for Dashboard Migration."""

    route_base = "/api/v1/migration"

    def _get_config(self):
        """Get migration configuration from Flask app."""
        from flask import current_app
        return {
            'migration_db_url': current_app.config.get('MIGRATION_DB_URL'),
            'superset_env': current_app.config.get('SUPERSET_ENV', 'dev'),
            'dashboard_repo_path': current_app.config.get('DASHBOARD_REPO_PATH', '/app/dashboard-repo'),
        }

    def _init_services(self):
        """Initialize migration services."""
        from dwe_hub_superset_plugin.database import init_db
        from dwe_hub_superset_plugin.services.superset_api import SupersetAPIClient
        from dwe_hub_superset_plugin.services.git_service import GitDashboardManager

        config = self._get_config()

        # Initialize database
        if config['migration_db_url']:
            init_db(config['migration_db_url'])

        # Initialize git
        git_manager = GitDashboardManager(repo_path=config['dashboard_repo_path'])

        # Initialize API client for current instance
        superset_url = request.host_url.rstrip('/')
        api_client = SupersetAPIClient(
            base_url=superset_url,
            username='admin',
            password='admin',
        )

        return config, git_manager, api_client

    @expose("/health", methods=["GET"])
    def health_check(self):
        """Health check endpoint."""
        return jsonify({
            "status": "healthy",
            "plugin": "dashboard-migration",
            "version": "0.1.0",
        })

    @expose("/dashboards", methods=["GET"])
    def list_dashboards(self):
        """List all dashboards available for migration."""
        try:
            config, git_manager, api_client = self._init_services()
            dashboards = api_client.list_dashboards()

            return jsonify({
                "status": "success",
                "environment": config['superset_env'],
                "count": len(dashboards),
                "result": [
                    {
                        "id": d.id,
                        "uuid": d.uuid,
                        "title": d.dashboard_title,
                        "slug": d.slug,
                        "published": d.published,
                        "changed_on": d.changed_on,
                        "changed_by": d.changed_by_name,
                        "url": d.url,
                    }
                    for d in dashboards
                ],
            })
        except Exception as e:
            logger.error(f"Error listing dashboards: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/dashboard/<int:dashboard_id>", methods=["GET"])
    def get_dashboard(self, dashboard_id):
        """Get a specific dashboard."""
        try:
            config, git_manager, api_client = self._init_services()
            dashboard = api_client.get_dashboard(dashboard_id)

            return jsonify({
                "status": "success",
                "result": {
                    "id": dashboard.id,
                    "uuid": dashboard.uuid,
                    "title": dashboard.dashboard_title,
                    "slug": dashboard.slug,
                    "published": dashboard.published,
                    "changed_on": dashboard.changed_on,
                    "changed_by": dashboard.changed_by_name,
                    "url": dashboard.url,
                },
            })
        except Exception as e:
            logger.error(f"Error getting dashboard: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/migrate", methods=["POST"])
    def initiate_migration(self):
        """
        Initiate a dashboard migration.

        Request body:
        {
            "dashboard_id": 1
        }
        """
        try:
            data = request.get_json() or {}
            dashboard_id = data.get("dashboard_id")

            if not dashboard_id:
                return jsonify({"status": "error", "message": "dashboard_id is required"}), 400

            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import session_scope
            from dwe_hub_superset_plugin.models.migration import DashboardMigration, MigrationStatus
            from dwe_hub_superset_plugin.models.version import DashboardVersion
            from dwe_hub_superset_plugin.models.audit import AuditLog

            # Get dashboard info
            dashboard = api_client.get_dashboard(dashboard_id)
            username = get_current_username()
            current_env = config['superset_env']
            target_env = 'prod' if current_env == 'dev' else 'dev'

            with session_scope() as session:
                # Create migration record
                migration = DashboardMigration(
                    dashboard_uuid=dashboard.uuid,
                    dashboard_name=dashboard.dashboard_title,
                    source_env=current_env,
                    target_env=target_env,
                    status=MigrationStatus.IN_PROGRESS,
                    initiated_by=username,
                )
                session.add(migration)
                session.flush()

                try:
                    # Export dashboard YAML
                    yaml_content = api_client.export_dashboard_yaml(dashboard_id)
                    migration.yaml_export = yaml_content

                    # Commit to git
                    commit_sha = git_manager.commit_dashboard(
                        yaml_content=yaml_content,
                        dashboard_uuid=dashboard.uuid,
                        dashboard_name=dashboard.dashboard_title,
                        user=username,
                    )
                    migration.git_commit_sha = commit_sha

                    # Create version record
                    version_number = DashboardVersion.get_next_version_number(session, dashboard.uuid)
                    version = DashboardVersion(
                        dashboard_uuid=dashboard.uuid,
                        version_number=version_number,
                        git_commit_sha=commit_sha,
                        yaml_content=yaml_content,
                        created_by=username,
                        is_current=True,
                    )
                    version.set_as_current(session)
                    session.add(version)

                    # Mark completed
                    migration.status = MigrationStatus.COMPLETED
                    from datetime import datetime
                    migration.completed_at = datetime.utcnow()

                    # Audit log
                    AuditLog.log_action(
                        session=session,
                        action='migrate',
                        user_name=username,
                        migration_id=migration.id,
                        details={'dashboard_id': dashboard_id, 'commit': commit_sha},
                    )

                    return jsonify({
                        "status": "success",
                        "message": "Migration completed successfully",
                        "result": {
                            "migration_id": migration.id,
                            "dashboard_uuid": dashboard.uuid,
                            "dashboard_name": dashboard.dashboard_title,
                            "version": version_number,
                            "commit_sha": commit_sha,
                            "source_env": current_env,
                            "target_env": target_env,
                        },
                    })

                except Exception as e:
                    migration.status = MigrationStatus.FAILED
                    migration.error_message = str(e)
                    raise

        except Exception as e:
            logger.error(f"Migration failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/status/<int:migration_id>", methods=["GET"])
    def get_migration_status(self, migration_id):
        """Get the status of a specific migration."""
        try:
            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.migration import DashboardMigration

            session = get_session()
            migration = session.query(DashboardMigration).get(migration_id)
            session.close()

            if not migration:
                return jsonify({"status": "error", "message": "Migration not found"}), 404

            return jsonify({
                "status": "success",
                "result": {
                    "id": migration.id,
                    "dashboard_uuid": migration.dashboard_uuid,
                    "dashboard_name": migration.dashboard_name,
                    "status": migration.status.value,
                    "source_env": migration.source_env,
                    "target_env": migration.target_env,
                    "git_commit_sha": migration.git_commit_sha,
                    "initiated_by": migration.initiated_by,
                    "initiated_at": migration.initiated_at.isoformat() if migration.initiated_at else None,
                    "completed_at": migration.completed_at.isoformat() if migration.completed_at else None,
                    "error_message": migration.error_message,
                },
            })
        except Exception as e:
            logger.error(f"Error getting migration status: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/history", methods=["GET"])
    def get_migration_history(self):
        """
        Get migration history.

        Query params:
        - dashboard_uuid: Optional filter by dashboard UUID
        - limit: Maximum number of records (default: 50)
        """
        try:
            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.migration import DashboardMigration

            dashboard_uuid = request.args.get("dashboard_uuid")
            limit = int(request.args.get("limit", 50))

            session = get_session()
            query = session.query(DashboardMigration).order_by(
                DashboardMigration.initiated_at.desc()
            )

            if dashboard_uuid:
                query = query.filter(DashboardMigration.dashboard_uuid == dashboard_uuid)

            migrations = query.limit(limit).all()
            session.close()

            return jsonify({
                "status": "success",
                "count": len(migrations),
                "result": [
                    {
                        "id": m.id,
                        "dashboard_uuid": m.dashboard_uuid,
                        "dashboard_name": m.dashboard_name,
                        "status": m.status.value,
                        "source_env": m.source_env,
                        "target_env": m.target_env,
                        "git_commit_sha": m.git_commit_sha,
                        "initiated_by": m.initiated_by,
                        "initiated_at": m.initiated_at.isoformat() if m.initiated_at else None,
                        "completed_at": m.completed_at.isoformat() if m.completed_at else None,
                    }
                    for m in migrations
                ],
            })
        except Exception as e:
            logger.error(f"Error getting migration history: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/versions/<uuid>", methods=["GET"])
    def get_versions(self, uuid):
        """Get all versions for a dashboard."""
        try:
            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.version import DashboardVersion

            session = get_session()
            versions = session.query(DashboardVersion).filter(
                DashboardVersion.dashboard_uuid == uuid
            ).order_by(DashboardVersion.version_number.desc()).all()
            session.close()

            return jsonify({
                "status": "success",
                "dashboard_uuid": uuid,
                "count": len(versions),
                "result": [
                    {
                        "version_number": v.version_number,
                        "git_commit_sha": v.git_commit_sha,
                        "created_by": v.created_by,
                        "created_at": v.created_at.isoformat() if v.created_at else None,
                        "is_current": v.is_current,
                    }
                    for v in versions
                ],
            })
        except Exception as e:
            logger.error(f"Error getting versions: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/revert", methods=["POST"])
    def revert_to_version(self):
        """
        Revert a dashboard to a specific version.

        Request body:
        {
            "dashboard_uuid": "uuid-string",
            "version_number": 1
        }
        """
        try:
            data = request.get_json() or {}
            dashboard_uuid = data.get("dashboard_uuid")
            version_number = data.get("version_number")

            if not dashboard_uuid or version_number is None:
                return jsonify({
                    "status": "error",
                    "message": "dashboard_uuid and version_number are required"
                }), 400

            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import session_scope
            from dwe_hub_superset_plugin.models.version import DashboardVersion
            from dwe_hub_superset_plugin.models.audit import AuditLog

            username = get_current_username()

            with session_scope() as session:
                # Get the target version
                target_version = session.query(DashboardVersion).filter(
                    DashboardVersion.dashboard_uuid == dashboard_uuid,
                    DashboardVersion.version_number == version_number
                ).first()

                if not target_version:
                    return jsonify({
                        "status": "error",
                        "message": f"Version {version_number} not found"
                    }), 404

                # Revert in git
                new_commit = git_manager.revert_to_commit(
                    commit_sha=target_version.git_commit_sha,
                    dashboard_uuid=dashboard_uuid,
                    user=username,
                )

                # Create new version
                new_version_number = DashboardVersion.get_next_version_number(session, dashboard_uuid)
                new_version = DashboardVersion(
                    dashboard_uuid=dashboard_uuid,
                    version_number=new_version_number,
                    git_commit_sha=new_commit,
                    yaml_content=target_version.yaml_content,
                    created_by=username,
                    is_current=True,
                )
                new_version.set_as_current(session)
                session.add(new_version)

                # Audit log
                AuditLog.log_action(
                    session=session,
                    action='revert',
                    user_name=username,
                    details={
                        'dashboard_uuid': dashboard_uuid,
                        'from_version': version_number,
                        'new_version': new_version_number,
                        'new_commit': new_commit
                    },
                )

                return jsonify({
                    "status": "success",
                    "message": f"Reverted to version {version_number}",
                    "result": {
                        "dashboard_uuid": dashboard_uuid,
                        "reverted_to_version": version_number,
                        "new_version": new_version_number,
                        "new_commit_sha": new_commit,
                    },
                })

        except Exception as e:
            logger.error(f"Revert failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/commits/<uuid>", methods=["GET"])
    def get_git_commits(self, uuid):
        """Get git commit history for a dashboard."""
        try:
            config, git_manager, api_client = self._init_services()
            limit = int(request.args.get("limit", 20))

            commits = git_manager.get_commit_history(dashboard_uuid=uuid, limit=limit)

            return jsonify({
                "status": "success",
                "dashboard_uuid": uuid,
                "count": len(commits),
                "result": [
                    {
                        "sha": c.sha,
                        "short_sha": c.short_sha,
                        "message": c.message,
                        "author": c.author,
                        "author_email": c.author_email,
                        "timestamp": c.timestamp.isoformat(),
                        "files_changed": c.files_changed,
                    }
                    for c in commits
                ],
            })
        except Exception as e:
            logger.error(f"Error getting commits: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/diff", methods=["GET"])
    def get_diff(self):
        """
        Get diff between two commits.

        Query params:
        - sha1: First commit SHA
        - sha2: Second commit SHA
        - dashboard_uuid: Optional dashboard UUID filter
        """
        try:
            sha1 = request.args.get("sha1")
            sha2 = request.args.get("sha2")
            dashboard_uuid = request.args.get("dashboard_uuid")

            if not sha1 or not sha2:
                return jsonify({
                    "status": "error",
                    "message": "sha1 and sha2 are required"
                }), 400

            config, git_manager, api_client = self._init_services()
            diff_text = git_manager.diff_commits(sha1, sha2, dashboard_uuid)

            return jsonify({
                "status": "success",
                "sha1": sha1,
                "sha2": sha2,
                "diff": diff_text,
            })
        except Exception as e:
            logger.error(f"Error getting diff: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/screenshots/<int:migration_id>", methods=["GET"])
    def get_screenshots(self, migration_id):
        """Get screenshots for a migration."""
        try:
            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.screenshot import ScreenshotLog

            session = get_session()
            screenshots = session.query(ScreenshotLog).filter(
                ScreenshotLog.migration_id == migration_id
            ).order_by(ScreenshotLog.captured_at).all()
            session.close()

            result = []
            for s in screenshots:
                # Encode image data as base64
                image_base64 = base64.b64encode(s.image_data).decode('utf-8') if s.image_data else None
                result.append({
                    "id": s.id,
                    "screenshot_type": s.screenshot_type,
                    "environment": s.environment,
                    "captured_at": s.captured_at.isoformat() if s.captured_at else None,
                    "file_size_bytes": s.file_size_bytes,
                    "mime_type": s.mime_type,
                    "image_base64": image_base64,
                })

            return jsonify({
                "status": "success",
                "migration_id": migration_id,
                "count": len(result),
                "result": result,
            })
        except Exception as e:
            logger.error(f"Error getting screenshots: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/audit", methods=["GET"])
    def get_audit_log(self):
        """
        Get audit log.

        Query params:
        - migration_id: Optional filter by migration ID
        - limit: Maximum number of records (default: 100)
        """
        try:
            config, git_manager, api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.audit import AuditLog

            migration_id = request.args.get("migration_id", type=int)
            limit = int(request.args.get("limit", 100))

            session = get_session()
            query = session.query(AuditLog).order_by(AuditLog.timestamp.desc())

            if migration_id:
                query = query.filter(AuditLog.migration_id == migration_id)

            logs = query.limit(limit).all()
            session.close()

            return jsonify({
                "status": "success",
                "count": len(logs),
                "result": [
                    {
                        "id": log.id,
                        "migration_id": log.migration_id,
                        "action": log.action,
                        "user": log.user_name,
                        "details": log.details,
                        "ip_address": log.ip_address,
                        "timestamp": log.timestamp.isoformat() if log.timestamp else None,
                    }
                    for log in logs
                ],
            })
        except Exception as e:
            logger.error(f"Error getting audit log: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/export/<int:dashboard_id>", methods=["GET"])
    def export_dashboard(self, dashboard_id):
        """Export a dashboard as YAML."""
        try:
            config, git_manager, api_client = self._init_services()
            yaml_content = api_client.export_dashboard_yaml(dashboard_id)

            return jsonify({
                "status": "success",
                "dashboard_id": dashboard_id,
                "yaml_content": yaml_content,
            })
        except Exception as e:
            logger.error(f"Error exporting dashboard: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/connections", methods=["GET"])
    def list_connections(self):
        """List all database connections with their UUIDs."""
        try:
            from flask import current_app
            from superset.extensions import db
            from superset.models.core import Database

            with current_app.app_context():
                connections = db.session.query(Database).all()

                return jsonify({
                    "status": "success",
                    "count": len(connections),
                    "result": [
                        {
                            "id": c.id,
                            "database_name": c.database_name,
                            "uuid": c.uuid,
                            "backend": c.backend,
                            "expose_in_sqllab": c.expose_in_sqllab,
                        }
                        for c in connections
                    ],
                })
        except Exception as e:
            logger.error(f"Error listing connections: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    @expose("/connections/setup", methods=["POST"])
    def setup_connections(self):
        """
        Setup database connections from environment variables.

        This endpoint reads CONNECTION_* environment variables and creates
        database connections with the specified UUIDs.
        """
        try:
            import os
            from flask import current_app
            from superset.extensions import db
            from superset.models.core import Database
            from dwe_hub_superset_plugin.setup import SHARED_DB_UUID

            created = []
            skipped = []
            errors = []

            with current_app.app_context():
                # Setup default shared connection
                shared_db_uri = os.getenv(
                    'SHARED_DB_URI',
                    'postgresql+psycopg2://data:data@postgres-shared-data:5432/shared_data'
                )

                existing = db.session.query(Database).filter_by(uuid=SHARED_DB_UUID).first()
                if not existing:
                    shared_db = Database(
                        database_name="Shared Data",
                        sqlalchemy_uri=shared_db_uri,
                        uuid=SHARED_DB_UUID,
                        expose_in_sqllab=True,
                        allow_run_async=True,
                        allow_ctas=True,
                        allow_cvas=True,
                        allow_dml=True,
                    )
                    db.session.add(shared_db)
                    db.session.commit()
                    created.append({
                        "name": "Shared Data",
                        "uuid": SHARED_DB_UUID
                    })
                else:
                    skipped.append({
                        "name": "Shared Data",
                        "uuid": SHARED_DB_UUID,
                        "reason": "already exists"
                    })

                # Process additional CONNECTION_ environment variables
                connection_vars = {
                    k: v for k, v in os.environ.items()
                    if k.startswith('CONNECTION_') and k != 'CONNECTION_SHARED_DATA'
                }

                for env_var, connection_string in connection_vars.items():
                    try:
                        parts = connection_string.split(':', 2)
                        if len(parts) != 3:
                            errors.append({
                                "env_var": env_var,
                                "error": "Invalid format. Expected: Name:UUID:URI"
                            })
                            continue

                        db_name, db_uuid, db_uri = parts

                        existing = db.session.query(Database).filter_by(uuid=db_uuid).first()
                        if not existing:
                            new_db = Database(
                                database_name=db_name,
                                sqlalchemy_uri=db_uri,
                                uuid=db_uuid,
                                expose_in_sqllab=True,
                                allow_run_async=True,
                            )
                            db.session.add(new_db)
                            db.session.commit()
                            created.append({"name": db_name, "uuid": db_uuid})
                        else:
                            skipped.append({
                                "name": db_name,
                                "uuid": db_uuid,
                                "reason": "already exists"
                            })

                    except Exception as e:
                        errors.append({
                            "env_var": env_var,
                            "error": str(e)
                        })

            return jsonify({
                "status": "success",
                "created": created,
                "skipped": skipped,
                "errors": errors,
                "summary": {
                    "created_count": len(created),
                    "skipped_count": len(skipped),
                    "error_count": len(errors),
                }
            })

        except Exception as e:
            logger.error(f"Error setting up connections: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return jsonify({"status": "error", "message": str(e)}), 500
