"""
Flask-AppBuilder UI view for Dashboard Migration.
"""

import logging
import os
from flask import current_app, flash, redirect, request, url_for, jsonify, render_template_string
from flask_appbuilder import BaseView, expose
from flask_login import current_user

logger = logging.getLogger(__name__)

# Standalone HTML template (without extends for compatibility)
BASE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Migration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .main-content {
        margin-left: 0 !important;
        padding: 20px !important;
    }

    .migration-container {
        max-width: 1400px;
        margin: 0 auto;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .migration-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 2px solid #20a7c9;
    }

    .migration-header h1 {
        color: #1a1a1a;
        margin: 0;
        font-size: 24px;
    }

    .env-badge {
        display: inline-block;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 600;
    }

    .env-dev { background: #e3f2fd; color: #1976d2; }
    .env-prod { background: #fce4ec; color: #c2185b; }

    .section {
        background: white;
        border-radius: 8px;
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .section h2 {
        margin-top: 0;
        color: #333;
        border-bottom: 1px solid #eee;
        padding-bottom: 12px;
        font-size: 18px;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 20px;
    }

    .dashboard-card {
        background: #fafafa;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 16px;
        transition: all 0.2s;
    }

    .dashboard-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transform: translateY(-2px);
    }

    .dashboard-name { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 8px; }
    .dashboard-meta { color: #666; font-size: 13px; margin-bottom: 12px; }
    .dashboard-uuid { font-family: monospace; font-size: 11px; color: #999; background: #f0f0f0; padding: 4px 8px; border-radius: 4px; word-break: break-all; }

    .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.2s;
    }

    .btn-primary { background: #20a7c9; color: white; }
    .btn-primary:hover { background: #1a8fad; color: white; text-decoration: none; }
    .btn-secondary { background: white; color: #333; border: 1px solid #ddd; }
    .btn-secondary:hover { background: #f5f5f5; text-decoration: none; }

    .card-actions { display: flex; gap: 8px; margin-top: 12px; }
    .card-actions .btn { flex: 1; justify-content: center; }

    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    th { background: #f8f8f8; font-weight: 600; }

    .status-badge { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }
    .status-completed { background: #e8f5e9; color: #2e7d32; }
    .status-pending { background: #fff8e1; color: #f57c00; }
    .status-in_progress { background: #e3f2fd; color: #1976d2; }
    .status-failed { background: #ffebee; color: #c62828; }
    .status-reverted { background: #f3e5f5; color: #7b1fa2; }

    .empty-state { text-align: center; padding: 40px; color: #999; }
    .back-link { color: #20a7c9; text-decoration: none; display: inline-block; margin-bottom: 20px; }
    .back-link:hover { text-decoration: underline; }

    .version-item { display: flex; padding: 16px; border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 12px; }
    .version-marker { width: 50px; display: flex; flex-direction: column; align-items: center; }
    .version-dot { width: 12px; height: 12px; border-radius: 50%; background: #20a7c9; }
    .version-line { width: 2px; flex: 1; background: #e0e0e0; margin-top: 4px; }
    .version-content { flex: 1; }
    .version-number { font-weight: 600; font-size: 16px; }
    .version-meta { color: #666; font-size: 13px; margin-top: 4px; }
    .commit-sha { font-family: monospace; background: #f0f0f0; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
    .current-badge { background: #e8f5e9; color: #2e7d32; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px; }
    .btn-revert { background: #fff3e0; color: #f57c00; border: 1px solid #f57c00; padding: 6px 12px; font-size: 13px; }
    .btn-revert:hover { background: #f57c00; color: white; }

    .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .info-label { color: #666; font-size: 12px; margin-bottom: 4px; }
    .info-value { font-size: 16px; font-weight: 500; }

    pre { background: #f5f5f5; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 13px; }

    .result-box { padding: 20px; border-radius: 8px; margin-bottom: 20px; }
    .result-box.success { background: #e8f5e9; color: #2e7d32; }
    .result-box.error { background: #ffebee; color: #c62828; }
    .result-box h2 { margin-top: 0; border: none; padding: 0; }
    .navbar-migration { background: #20a7c9; padding: 10px 20px; margin-bottom: 0; }
    .navbar-migration a { color: white; text-decoration: none; font-weight: 500; }
    .navbar-migration a:hover { text-decoration: underline; }
</style>
</head>
<body style="background: #f5f5f5; margin: 0;">
    <nav class="navbar-migration">
        <a href="/superset/welcome/">← Back to Superset</a>
    </nav>
    <div class="container-fluid" style="padding: 0; min-height: calc(100vh - 50px);">
        <div class="migration-container" style="padding: 20px;">
            {{ content|safe }}
        </div>
    </div>
</body>
</html>
"""


def get_current_username():
    """Get current user's username."""
    if current_user and current_user.is_authenticated:
        return getattr(current_user, 'username', 'admin')
    return 'anonymous'


class MigrationDashboardView(BaseView):
    """Dashboard Migration UI view."""

    route_base = "/migration"
    default_view = "list"

    def _get_config(self):
        """Get migration configuration."""
        return {
            'migration_db_url': current_app.config.get('MIGRATION_DB_URL'),
            'superset_env': current_app.config.get('SUPERSET_ENV', 'dev'),
            'dashboard_repo_path': current_app.config.get('DASHBOARD_REPO_PATH', '/app/dashboard-repo'),
            'target_superset_url': current_app.config.get('TARGET_SUPERSET_URL'),
            'target_superset_username': current_app.config.get('TARGET_SUPERSET_USERNAME', 'admin'),
            'target_superset_password': current_app.config.get('TARGET_SUPERSET_PASSWORD', 'admin'),
        }

    def _init_services(self):
        """Initialize migration services."""
        from dwe_hub_superset_plugin.database import init_db
        from dwe_hub_superset_plugin.services.superset_api import SupersetAPIClient
        from dwe_hub_superset_plugin.services.git_service import GitDashboardManager

        config = self._get_config()

        # Initialize database
        if config['migration_db_url']:
            init_db(config['migration_db_url'])

        # Initialize git
        git_manager = GitDashboardManager(repo_path=config['dashboard_repo_path'])

        # Initialize API client for current instance
        superset_url = request.host_url.rstrip('/')
        api_client = SupersetAPIClient(
            base_url=superset_url,
            username='admin',
            password='admin',
        )

        # Initialize API client for target instance
        target_api_client = None
        if config['target_superset_url']:
            target_api_client = SupersetAPIClient(
                base_url=config['target_superset_url'],
                username=config['target_superset_username'],
                password=config['target_superset_password'],
            )

        return config, git_manager, api_client, target_api_client

    def _render(self, content):
        """Render content using the migration template."""
        return render_template_string(BASE_TEMPLATE, content=content)

    @expose("/")
    def list(self):
        """Main dashboard listing page."""
        try:
            config, git_manager, api_client, target_api_client = self._init_services()

            # Get dashboards from current environment
            try:
                dashboards = api_client.list_dashboards()
            except Exception as e:
                logger.warning(f"Could not fetch dashboards: {e}")
                dashboards = []

            # Get recent migrations
            recent_migrations = []
            try:
                from dwe_hub_superset_plugin.database import get_session
                from dwe_hub_superset_plugin.models.migration import DashboardMigration

                session = get_session()
                recent_migrations = session.query(DashboardMigration).order_by(
                    DashboardMigration.initiated_at.desc()
                ).limit(10).all()
                session.close()
            except Exception as e:
                logger.warning(f"Could not fetch migrations: {e}")

            current_env = config['superset_env']
            target_env = 'prod' if current_env == 'dev' else 'dev'

            content = f"""
                <div class="migration-header">
                    <h1>Dashboard Migration</h1>
                    <span class="env-badge env-{current_env}">{current_env.upper()} Environment</span>
                </div>

                <div class="section">
                    <h2>Dashboards Available for Migration</h2>
                    <p style="color: #666; margin-bottom: 20px;">Select a dashboard to migrate from {current_env.upper()} to {target_env.upper()}</p>
            """

            if dashboards:
                content += '<div class="dashboard-grid">'
                for d in dashboards:
                    content += f"""
                        <div class="dashboard-card">
                            <div class="dashboard-name">{d.dashboard_title}</div>
                            <div class="dashboard-meta">
                                {f"Modified: {d.changed_on}" if d.changed_on else ""}
                                {f" by {d.changed_by_name}" if d.changed_by_name else ""}
                            </div>
                            <div class="dashboard-uuid">UUID: {d.uuid}</div>
                            <div class="card-actions">
                                <a href="/migration/history/{d.uuid}" class="btn btn-secondary">History</a>
                                <a href="/migration/migrate/{d.id}" class="btn btn-primary">Migrate</a>
                            </div>
                        </div>
                    """
                content += '</div>'
            else:
                content += '<div class="empty-state">No dashboards found. Create a dashboard first.</div>'

            content += """
                </div>

                <div class="section">
                    <h2>Recent Migrations</h2>
            """

            if recent_migrations:
                content += """
                    <table>
                        <thead>
                            <tr>
                                <th>Dashboard</th>
                                <th>Status</th>
                                <th>Direction</th>
                                <th>By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                """
                for m in recent_migrations:
                    status_class = f"status-{m.status.value}"
                    content += f"""
                            <tr>
                                <td><strong>{m.dashboard_name}</strong></td>
                                <td><span class="status-badge {status_class}">{m.status.value}</span></td>
                                <td>
                                    <span class="env-badge env-{m.source_env}">{m.source_env}</span>
                                    &rarr;
                                    <span class="env-badge env-{m.target_env}">{m.target_env}</span>
                                </td>
                                <td>{m.initiated_by}</td>
                                <td>{m.initiated_at.strftime('%Y-%m-%d %H:%M') if m.initiated_at else '-'}</td>
                                <td>
                                    <a href="/migration/detail/{m.id}" class="btn btn-secondary" style="padding: 4px 12px;">View</a>
                                </td>
                            </tr>
                    """
                content += """
                        </tbody>
                    </table>
                """
            else:
                content += '<div class="empty-state">No migrations yet.</div>'

            content += "</div>"

            return self._render(content)

        except Exception as e:
            logger.error(f"Error loading migration dashboard: {e}")
            import traceback
            logger.error(traceback.format_exc())
            content = f"""
                <div class="migration-header">
                    <h1>Dashboard Migration</h1>
                </div>
                <div class="result-box error">
                    <strong>Error:</strong> {str(e)}
                </div>
                <p><a href="/migration/" class="btn btn-primary">Retry</a></p>
            """
            return self._render(content)

    @expose("/migrate/<int:dashboard_id>")
    def migrate(self, dashboard_id):
        """Initiate and execute a migration."""
        try:
            config, git_manager, api_client, target_api_client = self._init_services()
            from dwe_hub_superset_plugin.database import get_session, session_scope
            from dwe_hub_superset_plugin.models.migration import DashboardMigration, MigrationStatus
            from dwe_hub_superset_plugin.models.version import DashboardVersion
            from dwe_hub_superset_plugin.models.audit import AuditLog

            # Get dashboard info
            dashboard = api_client.get_dashboard(dashboard_id)
            username = get_current_username()
            current_env = config['superset_env']
            target_env = 'prod' if current_env == 'dev' else 'dev'

            with session_scope() as session:
                # Create migration record
                migration = DashboardMigration(
                    dashboard_uuid=dashboard.uuid,
                    dashboard_name=dashboard.dashboard_title,
                    source_env=current_env,
                    target_env=target_env,
                    status=MigrationStatus.IN_PROGRESS,
                    initiated_by=username,
                )
                session.add(migration)
                session.flush()

                try:
                    # Export dashboard as ZIP (for import) and YAML (for git)
                    zip_content = api_client.export_dashboard(dashboard_id)
                    yaml_content = api_client.export_dashboard_yaml(dashboard_id)
                    migration.yaml_export = yaml_content

                    # Commit to git
                    commit_sha = git_manager.commit_dashboard(
                        yaml_content=yaml_content,
                        dashboard_uuid=dashboard.uuid,
                        dashboard_name=dashboard.dashboard_title,
                        user=username,
                    )
                    migration.git_commit_sha = commit_sha

                    # Create version record
                    version_number = DashboardVersion.get_next_version_number(session, dashboard.uuid)
                    version = DashboardVersion(
                        dashboard_uuid=dashboard.uuid,
                        version_number=version_number,
                        git_commit_sha=commit_sha,
                        yaml_content=yaml_content,
                        created_by=username,
                        is_current=True,
                    )
                    version.set_as_current(session)
                    session.add(version)

                    # Import to target environment
                    import_status = "Not configured"
                    if target_api_client:
                        try:
                            target_api_client.import_dashboard(zip_content, overwrite=True)
                            import_status = f"Successfully imported to {target_env.upper()}"
                        except Exception as import_error:
                            import_status = f"Import failed: {str(import_error)}"
                            logger.warning(f"Failed to import to target: {import_error}")

                    # Mark completed
                    migration.status = MigrationStatus.COMPLETED
                    from datetime import datetime
                    migration.completed_at = datetime.utcnow()

                    # Audit log
                    AuditLog.log_action(
                        session=session,
                        action='migrate',
                        user_name=username,
                        migration_id=migration.id,
                        details={'dashboard_id': dashboard_id, 'commit': commit_sha, 'import_status': import_status},
                    )

                    content = f"""
                        <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                        <div class="result-box success">
                            <h2>Migration Successful!</h2>
                            <p><strong>Dashboard:</strong> {dashboard.dashboard_title}</p>
                            <p><strong>Version:</strong> {version_number}</p>
                            <p><strong>Commit:</strong> <code>{commit_sha[:8]}</code></p>
                            <p><strong>Target Import:</strong> {import_status}</p>
                        </div>
                        <p>The dashboard has been exported, versioned, and pushed to {target_env.upper()}.</p>
                        <p><a href="{config['target_superset_url']}/superset/welcome/" target="_blank" class="btn btn-secondary">Open {target_env.upper()} Superset</a></p>
                        <a href="/migration/" class="btn btn-primary">
                            &larr; Back to Dashboard Migration
                        </a>
                    """
                    return self._render(content)

                except Exception as e:
                    migration.status = MigrationStatus.FAILED
                    migration.error_message = str(e)
                    raise

        except Exception as e:
            logger.error(f"Migration failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="result-box error">
                    <h2>Migration Failed</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/migration/" class="btn btn-primary">
                    &larr; Back to Dashboard Migration
                </a>
            """
            return self._render(content)

    @expose("/history/")
    def history_all(self):
        """All migration history."""
        try:
            config, git_manager, api_client, _ = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.migration import DashboardMigration

            session = get_session()
            migrations = session.query(DashboardMigration).order_by(
                DashboardMigration.initiated_at.desc()
            ).limit(50).all()
            session.close()

            content = """
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="migration-header">
                    <h1>Migration History</h1>
                </div>

                <div class="section">
                    <h2>All Migrations</h2>
            """

            if migrations:
                content += """
                    <table>
                        <thead>
                            <tr>
                                <th>Dashboard</th>
                                <th>Status</th>
                                <th>Direction</th>
                                <th>By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                """
                for m in migrations:
                    status_class = f"status-{m.status.value}"
                    content += f"""
                            <tr>
                                <td>
                                    <strong>{m.dashboard_name}</strong>
                                    <div class="dashboard-uuid">{m.dashboard_uuid}</div>
                                </td>
                                <td><span class="status-badge {status_class}">{m.status.value}</span></td>
                                <td>
                                    <span class="env-badge env-{m.source_env}">{m.source_env}</span>
                                    &rarr;
                                    <span class="env-badge env-{m.target_env}">{m.target_env}</span>
                                </td>
                                <td>{m.initiated_by}</td>
                                <td>{m.initiated_at.strftime('%Y-%m-%d %H:%M') if m.initiated_at else '-'}</td>
                                <td>
                                    <a href="/migration/detail/{m.id}" class="btn btn-secondary" style="padding: 4px 12px;">View</a>
                                    <a href="/migration/history/{m.dashboard_uuid}" class="btn btn-secondary" style="padding: 4px 12px;">Versions</a>
                                </td>
                            </tr>
                    """
                content += """
                        </tbody>
                    </table>
                """
            else:
                content += '<div class="empty-state">No migrations yet. Migrate a dashboard to see history here.</div>'

            content += "</div>"

            return self._render(content)

        except Exception as e:
            logger.error(f"Error loading history: {e}")
            import traceback
            logger.error(traceback.format_exc())
            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="result-box error">
                    <h2>Error</h2>
                    <p>{str(e)}</p>
                </div>
            """
            return self._render(content)

    @expose("/history/<uuid>")
    def history(self, uuid):
        """Version history for a dashboard."""
        try:
            config, git_manager, api_client, _ = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.version import DashboardVersion

            session = get_session()
            versions = session.query(DashboardVersion).filter(
                DashboardVersion.dashboard_uuid == uuid
            ).order_by(DashboardVersion.version_number.desc()).all()
            session.close()

            # Get git history
            git_commits = git_manager.get_commit_history(dashboard_uuid=uuid, limit=20)

            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="migration-header">
                    <h1>Version History</h1>
                </div>
                <p class="dashboard-uuid">Dashboard UUID: {uuid}</p>

                <div class="section">
                    <h2>Versions</h2>
            """

            if versions:
                for i, v in enumerate(versions):
                    is_last = i == len(versions) - 1
                    content += f"""
                        <div class="version-item">
                            <div class="version-marker">
                                <div class="version-dot"></div>
                                {"" if is_last else '<div class="version-line"></div>'}
                            </div>
                            <div class="version-content">
                                <div class="version-number">
                                    Version {v.version_number}
                                    {"<span class='current-badge'>CURRENT</span>" if v.is_current else ""}
                                </div>
                                <div class="version-meta">
                                    <span class="commit-sha">{v.git_commit_sha[:8]}</span>
                                    &bull; Created by {v.created_by}
                                    &bull; {v.created_at.strftime('%Y-%m-%d %H:%M') if v.created_at else ''}
                                </div>
                                {f'<a href="/migration/revert/{uuid}/{v.version_number}" class="btn btn-revert">Revert to this version</a>' if not v.is_current else ''}
                            </div>
                        </div>
                    """
            else:
                content += '<div class="empty-state">No versions found for this dashboard.</div>'

            content += """
                </div>

                <div class="section">
                    <h2>Git Commits</h2>
            """

            if git_commits:
                for c in git_commits:
                    content += f"""
                        <div style="padding: 12px; border-bottom: 1px solid #eee;">
                            <div><span class="commit-sha">{c.short_sha}</span> {c.message[:80]}</div>
                            <div style="color: #666; font-size: 12px; margin-top: 4px;">
                                {c.author} &bull; {c.timestamp.strftime('%Y-%m-%d %H:%M')}
                            </div>
                        </div>
                    """
            else:
                content += '<div class="empty-state">No git commits found.</div>'

            content += "</div>"

            return self._render(content)

        except Exception as e:
            logger.error(f"Error loading history: {e}")
            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="result-box error">
                    <h2>Error</h2>
                    <p>{str(e)}</p>
                </div>
            """
            return self._render(content)

    @expose("/detail/<int:migration_id>")
    def detail(self, migration_id):
        """Migration detail view."""
        try:
            config, git_manager, api_client, _ = self._init_services()
            from dwe_hub_superset_plugin.database import get_session
            from dwe_hub_superset_plugin.models.migration import DashboardMigration

            session = get_session()
            migration = session.query(DashboardMigration).get(migration_id)
            session.close()

            if not migration:
                content = """
                    <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                    <div class="result-box error">
                        <h2>Migration not found</h2>
                    </div>
                """
                return self._render(content)

            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="migration-header">
                    <h1>Migration Detail</h1>
                </div>

                <div class="section">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Dashboard</div>
                            <div class="info-value">{migration.dashboard_name}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Status</div>
                            <div class="info-value">
                                <span class="status-badge status-{migration.status.value}">{migration.status.value}</span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Direction</div>
                            <div class="info-value">
                                <span class="env-badge env-{migration.source_env}">{migration.source_env}</span>
                                &rarr;
                                <span class="env-badge env-{migration.target_env}">{migration.target_env}</span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Initiated By</div>
                            <div class="info-value">{migration.initiated_by}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Started</div>
                            <div class="info-value">{migration.initiated_at.strftime('%Y-%m-%d %H:%M:%S') if migration.initiated_at else '-'}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Completed</div>
                            <div class="info-value">{migration.completed_at.strftime('%Y-%m-%d %H:%M:%S') if migration.completed_at else '-'}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Git Commit</div>
                            <div class="info-value"><code>{migration.git_commit_sha[:8] if migration.git_commit_sha else '-'}</code></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Dashboard UUID</div>
                            <div class="info-value" style="font-family: monospace; font-size: 12px;">{migration.dashboard_uuid}</div>
                        </div>
                    </div>
                </div>

                {f'<div class="section"><h2>Error Message</h2><pre>{migration.error_message}</pre></div>' if migration.error_message else ''}

                <div class="section">
                    <h2>Actions</h2>
                    <a href="/migration/history/{migration.dashboard_uuid}" class="btn btn-primary">
                        View History
                    </a>
                </div>
            """

            return self._render(content)

        except Exception as e:
            logger.error(f"Error loading detail: {e}")
            content = f"""
                <a href="/migration/" class="back-link">&larr; Back to Dashboard Migration</a>
                <div class="result-box error">
                    <h2>Error</h2>
                    <p>{str(e)}</p>
                </div>
            """
            return self._render(content)

    @expose("/revert/<uuid>/<int:version_number>")
    def revert(self, uuid, version_number):
        """Revert to a specific version."""
        try:
            config, git_manager, api_client, _ = self._init_services()
            from dwe_hub_superset_plugin.database import session_scope
            from dwe_hub_superset_plugin.models.version import DashboardVersion
            from dwe_hub_superset_plugin.models.audit import AuditLog

            username = get_current_username()

            with session_scope() as session:
                # Get the target version
                target_version = session.query(DashboardVersion).filter(
                    DashboardVersion.dashboard_uuid == uuid,
                    DashboardVersion.version_number == version_number
                ).first()

                if not target_version:
                    content = f"""
                        <a href="/migration/history/{uuid}" class="back-link">&larr; Back to History</a>
                        <div class="result-box error">
                            <h2>Version not found</h2>
                        </div>
                    """
                    return self._render(content)

                # Revert in git
                new_commit = git_manager.revert_to_commit(
                    commit_sha=target_version.git_commit_sha,
                    dashboard_uuid=uuid,
                    user=username,
                )

                # Create new version
                new_version_number = DashboardVersion.get_next_version_number(session, uuid)
                new_version = DashboardVersion(
                    dashboard_uuid=uuid,
                    version_number=new_version_number,
                    git_commit_sha=new_commit,
                    yaml_content=target_version.yaml_content,
                    created_by=username,
                    is_current=True,
                )
                new_version.set_as_current(session)
                session.add(new_version)

                # Audit log
                AuditLog.log_action(
                    session=session,
                    action='revert',
                    user_name=username,
                    details={'from_version': version_number, 'new_commit': new_commit},
                )

            content = f"""
                <a href="/migration/history/{uuid}" class="back-link">&larr; Back to History</a>
                <div class="result-box success">
                    <h2>Revert Successful!</h2>
                    <p>Reverted to version {version_number}</p>
                    <p>New version: {new_version_number}</p>
                    <p>Commit: <code>{new_commit[:8]}</code></p>
                </div>
                <a href="/migration/history/{uuid}" class="btn btn-primary">
                    &larr; Back to History
                </a>
            """
            return self._render(content)

        except Exception as e:
            logger.error(f"Revert failed: {e}")
            content = f"""
                <a href="/migration/history/{uuid}" class="back-link">&larr; Back to History</a>
                <div class="result-box error">
                    <h2>Revert Failed</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/migration/history/{uuid}" class="btn btn-primary">
                    &larr; Back to History
                </a>
            """
            return self._render(content)

    @expose("/api/health")
    def health(self):
        """Health check endpoint."""
        return jsonify({
            "status": "ok",
            "plugin": "dashboard-migration",
            "version": "0.1.0"
        })
