"""
Flask-AppBuilder views for the Dashboard Migration tool.
"""
