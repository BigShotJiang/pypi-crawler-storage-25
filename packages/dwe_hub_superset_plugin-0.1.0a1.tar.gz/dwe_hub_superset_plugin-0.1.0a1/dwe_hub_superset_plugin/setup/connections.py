"""
Database connection setup for Dashboard Migration plugin.

Creates database connections with identical UUIDs across Superset environments
to enable seamless dashboard migration.
"""

import logging
import os
import time
from typing import Optional, Tuple

import requests
from sqlalchemy import create_engine, text

logger = logging.getLogger(__name__)

# Fixed UUID for shared database connection
# This MUST be the same in both dev and prod environments
SHARED_DB_UUID = "a2dc77af-e654-49bb-b321-40f6b559a1ee"


def wait_for_superset_api(base_url: str, max_retries: int = 30, retry_interval: int = 5) -> bool:
    """
    Wait for Superset API to be available.

    Args:
        base_url: Superset base URL
        max_retries: Maximum number of retry attempts
        retry_interval: Seconds between retries

    Returns:
        True if API is available, False otherwise
    """
    logger.info(f"Checking if Superset API is available at {base_url}...")

    for attempt in range(1, max_retries + 1):
        try:
            response = requests.get(f"{base_url}/api/v1/security/login", timeout=5)
            if response.status_code in [200, 405]:
                logger.info(f"Superset API is available (attempt {attempt})")
                return True
            else:
                logger.warning(f"Attempt {attempt}: API returned status {response.status_code}")
        except requests.exceptions.RequestException as e:
            logger.warning(f"Attempt {attempt}: Connection failed - {e}")

        if attempt < max_retries:
            logger.info(f"Waiting {retry_interval} seconds before retry...")
            time.sleep(retry_interval)
        else:
            logger.error(f"Superset API not available after {max_retries} attempts")
            return False

    return False


def test_database_connectivity(
    database_name: str,
    sqlalchemy_uri: str,
    max_retries: int = 6,
    retry_interval: int = 5
) -> bool:
    """
    Test database connectivity before creating connection.

    Args:
        database_name: Name of the database
        sqlalchemy_uri: SQLAlchemy connection URI
        max_retries: Maximum retry attempts
        retry_interval: Seconds between retries

    Returns:
        True if database is accessible, False otherwise
    """
    logger.info(f"Testing connectivity for database '{database_name}'...")

    for attempt in range(1, max_retries + 1):
        engine = None
        try:
            uri_lower = sqlalchemy_uri.lower()
            connect_args = {}
            engine_kwargs = {"pool_timeout": 10, "pool_recycle": 3600}

            if "postgresql" in uri_lower:
                connect_args = {"connect_timeout": 10}
            elif "mysql" in uri_lower:
                connect_args = {"connect_timeout": 10}
            elif "sqlite" in uri_lower:
                connect_args = {"timeout": 10}

            if connect_args:
                engine = create_engine(sqlalchemy_uri, connect_args=connect_args, **engine_kwargs)
            else:
                engine = create_engine(sqlalchemy_uri, **engine_kwargs)

            with engine.connect() as connection:
                result = connection.execute(text("SELECT 1"))
                result.fetchone()

            logger.info(f"Database '{database_name}' is accessible (attempt {attempt})")
            engine.dispose()
            return True

        except Exception as e:
            logger.warning(f"Attempt {attempt}: Database '{database_name}' connection failed - {str(e)[:100]}")
            if engine:
                try:
                    engine.dispose()
                except:
                    pass

        if attempt < max_retries:
            logger.info(f"Waiting {retry_interval} seconds before retry...")
            time.sleep(retry_interval)
        else:
            logger.error(f"Database '{database_name}' not accessible after {max_retries} attempts")
            return False

    return False


def authenticate_superset(
    base_url: str,
    username: str,
    password: str,
    max_retries: int = 10,
    retry_interval: int = 5
) -> Tuple[requests.Session, str, str]:
    """
    Authenticate with Superset and return session with tokens.

    Args:
        base_url: Superset base URL
        username: Superset username
        password: Superset password
        max_retries: Maximum retry attempts
        retry_interval: Seconds between retries

    Returns:
        Tuple of (session, access_token, csrf_token)

    Raises:
        Exception: If authentication fails after all retries
    """
    session = requests.Session()

    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Authentication attempt {attempt}/{max_retries}...")

            # Login
            login_response = session.post(
                f"{base_url}/api/v1/security/login",
                json={
                    "username": username,
                    "password": password,
                    "provider": "db",
                    "refresh": True
                },
                timeout=10
            )

            if login_response.status_code == 200:
                access_token = login_response.json()['access_token']
                logger.info("Login successful")

                # Get CSRF token
                csrf_response = session.get(
                    f"{base_url}/api/v1/security/csrf_token",
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=10
                )

                if csrf_response.status_code == 200:
                    csrf_token = csrf_response.json()['result']
                    logger.info("CSRF token obtained")
                    return session, access_token, csrf_token
                else:
                    logger.error(f"CSRF token failed: {csrf_response.text}")
            else:
                logger.error(f"Login failed: {login_response.status_code} - {login_response.text}")

        except requests.exceptions.RequestException as e:
            logger.error(f"Connection error on attempt {attempt}: {e}")

        if attempt < max_retries:
            logger.info(f"Waiting {retry_interval} seconds before retry...")
            time.sleep(retry_interval)

    raise Exception(f"Failed to authenticate after {max_retries} attempts")


def create_database_connection(
    session: requests.Session,
    base_url: str,
    access_token: str,
    csrf_token: str,
    database_name: str,
    uuid: str,
    sqlalchemy_uri: str,
    test_connectivity: bool = True
) -> bool:
    """
    Create a database connection in Superset using the REST API.

    Args:
        session: Requests session
        base_url: Superset base URL
        access_token: JWT access token
        csrf_token: CSRF token
        database_name: Display name for the connection
        uuid: Fixed UUID for the connection (must match across environments)
        sqlalchemy_uri: SQLAlchemy connection string
        test_connectivity: Whether to test connectivity first

    Returns:
        True if connection was created or already exists, False on error
    """
    headers = {
        "Authorization": f"Bearer {access_token}",
        "X-CSRFToken": csrf_token,
        "Content-Type": "application/json"
    }

    logger.info(f"Creating database connection: {database_name}")

    # Test connectivity first if requested
    if test_connectivity:
        if not test_database_connectivity(database_name, sqlalchemy_uri):
            logger.error(f"Skipping '{database_name}' - database not accessible")
            return False

    payload = {
        "database_name": database_name,
        "sqlalchemy_uri": sqlalchemy_uri,
        "uuid": uuid,
        "expose_in_sqllab": True,
        "allow_run_async": True,
        "allow_ctas": True,
        "allow_cvas": True,
        "allow_dml": True,
        "allow_multi_schema_metadata_fetch": True,
        "allow_csv_upload": True,
        "allow_file_upload": True
    }

    try:
        response = session.post(
            f"{base_url}/api/v1/database/",
            json=payload,
            headers=headers,
            timeout=30
        )

        if response.status_code == 201:
            logger.info(f"Database connection '{database_name}' created successfully")
            return True
        elif response.status_code == 422:
            error_data = response.json()
            if "already exists" in str(error_data).lower() or "duplicate" in str(error_data).lower():
                logger.info(f"Database connection '{database_name}' already exists, skipping...")
                return True
            else:
                logger.error(f"Database connection '{database_name}' creation failed: {response.status_code} - {response.text}")
                return False
        else:
            logger.error(f"Database connection '{database_name}' creation failed: {response.status_code} - {response.text}")
            return False

    except Exception as e:
        logger.error(f"Error creating database connection '{database_name}': {e}")
        return False


def create_connections_from_env(
    session: requests.Session,
    base_url: str,
    access_token: str,
    csrf_token: str,
    test_connectivity: bool = True
) -> Tuple[int, int]:
    """
    Create database connections from environment variables.

    Environment variables should be named CONNECTION_* with format:
    DatabaseName:UUID:sqlalchemy_uri

    Args:
        session: Requests session
        base_url: Superset base URL
        access_token: JWT access token
        csrf_token: CSRF token
        test_connectivity: Whether to test connectivity first

    Returns:
        Tuple of (successful_count, failed_count)
    """
    logger.info("Creating database connections from environment variables...")

    connection_vars = {k: v for k, v in os.environ.items() if k.startswith('CONNECTION_')}

    if not connection_vars:
        logger.warning("No CONNECTION_ environment variables found")
        return 0, 0

    successful = 0
    failed = 0

    for env_var, connection_string in connection_vars.items():
        try:
            parts = connection_string.split(':', 2)
            if len(parts) != 3:
                logger.error(f"Invalid connection string format for {env_var}: {connection_string}")
                logger.error("Expected format: 'DatabaseName:UUID:sqlalchemy_uri'")
                failed += 1
                continue

            database_name, uuid, sqlalchemy_uri = parts

            logger.info(f"Processing {env_var}: {database_name}")

            if create_database_connection(
                session, base_url, access_token, csrf_token,
                database_name, uuid, sqlalchemy_uri, test_connectivity
            ):
                successful += 1
            else:
                failed += 1

        except Exception as e:
            logger.error(f"Error processing {env_var}: {e}")
            failed += 1

    logger.info(f"Database connections summary: {successful} created, {failed} failed")
    return successful, failed


def setup_shared_connections(
    base_url: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    test_connectivity: bool = True
) -> Tuple[int, int]:
    """
    Setup shared database connections for a Superset instance.

    This is the main entry point for setting up connections.
    Can be called from the Superset startup process or manually.

    Args:
        base_url: Superset base URL (defaults to env var or localhost:8088)
        username: Superset admin username (defaults to 'admin')
        password: Superset admin password (defaults to 'admin')
        test_connectivity: Whether to test database connectivity first

    Returns:
        Tuple of (successful_count, failed_count)
    """
    base_url = base_url or os.getenv('SUPERSET_BASE_URL', 'http://localhost:8088')
    username = username or os.getenv('SUPERSET_ADMIN_USER', 'admin')
    password = password or os.getenv('SUPERSET_ADMIN_PASSWORD', 'admin')

    logger.info(f"Setting up shared connections for Superset at {base_url}")

    try:
        # Wait for API to be available
        if not wait_for_superset_api(base_url):
            logger.error("Superset API is not available. Exiting.")
            return 0, 0

        # Authenticate
        session, access_token, csrf_token = authenticate_superset(base_url, username, password)

        # Create connections from environment
        return create_connections_from_env(
            session, base_url, access_token, csrf_token, test_connectivity
        )

    except Exception as e:
        logger.error(f"Failed to setup shared connections: {e}")
        return 0, 1


def setup_default_shared_connection(
    base_url: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
) -> bool:
    """
    Setup the default shared data connection.

    Creates a connection to postgres-shared-data with a fixed UUID
    that matches across dev and prod environments.

    Args:
        base_url: Superset base URL
        username: Superset admin username
        password: Superset admin password

    Returns:
        True if successful, False otherwise
    """
    base_url = base_url or os.getenv('SUPERSET_BASE_URL', 'http://localhost:8088')
    username = username or os.getenv('SUPERSET_ADMIN_USER', 'admin')
    password = password or os.getenv('SUPERSET_ADMIN_PASSWORD', 'admin')

    # Default shared database connection
    shared_db_uri = os.getenv(
        'SHARED_DB_URI',
        'postgresql+psycopg2://data:data@postgres-shared-data:5432/shared_data'
    )

    logger.info(f"Setting up default shared connection for Superset at {base_url}")

    try:
        if not wait_for_superset_api(base_url):
            return False

        session, access_token, csrf_token = authenticate_superset(base_url, username, password)

        return create_database_connection(
            session=session,
            base_url=base_url,
            access_token=access_token,
            csrf_token=csrf_token,
            database_name="Shared Data",
            uuid=SHARED_DB_UUID,
            sqlalchemy_uri=shared_db_uri,
            test_connectivity=True
        )

    except Exception as e:
        logger.error(f"Failed to setup default shared connection: {e}")
        return False


def sync_connections_from_dwe_env(app=None) -> Tuple[int, int]:
    """
    Sync database connections from DWE_SYNC_CONN_* environment variables.

    This function is designed to run during Superset startup and creates
    or updates database connections with fixed UUIDs from environment variables.

    Environment variable format:
        DWE_SYNC_CONN_{NAME}="Display Name|UUID|SQLAlchemy_URI"

    Example:
        DWE_SYNC_CONN_POSTGRES_PROD="Production DB|550e8400-e29b-41d4-a716-446655440001|postgresql://..."
        DWE_SYNC_CONN_SNOWFLAKE="Data Warehouse|a2dc77af-e654-49bb-b321-40f6b559a1ee|snowflake://..."

    Logic:
        - On startup, scan os.environ for keys starting with DWE_SYNC_CONN_
        - Parse the string value by the pipe | delimiter
        - Check if a Database entry exists in Superset with that specific uuid
        - If exists: Update database_name and sqlalchemy_uri
        - If not: Create a new Database record with the provided uuid

    Args:
        app: Flask app instance (optional, will create context if needed)

    Returns:
        Tuple of (successful_count, failed_count)
    """
    logger.info("Syncing database connections from DWE_SYNC_CONN_* environment variables...")

    # Find all DWE_SYNC_CONN_* variables
    sync_vars = {k: v for k, v in os.environ.items() if k.startswith('DWE_SYNC_CONN_')}

    if not sync_vars:
        logger.info("No DWE_SYNC_CONN_* environment variables found")
        return 0, 0

    logger.info(f"Found {len(sync_vars)} DWE_SYNC_CONN_* variables")

    successful = 0
    failed = 0

    # Import inside function to avoid circular imports
    try:
        from superset.app import create_app
        from superset.extensions import db
        from superset.models.core import Database
    except ImportError as e:
        logger.error(f"Cannot import Superset models: {e}")
        return 0, len(sync_vars)

    # Create app context if needed
    if app is None:
        app = create_app()

    ctx = app.app_context()
    ctx.push()

    try:
        for env_var, connection_string in sync_vars.items():
            try:
                # Parse using pipe delimiter
                parts = connection_string.split('|', 2)
                if len(parts) != 3:
                    logger.error(
                        f"Invalid format for {env_var}: expected 'Name|UUID|URI', "
                        f"got {len(parts)} parts"
                    )
                    failed += 1
                    continue

                db_name, db_uuid, db_uri = [p.strip() for p in parts]

                if not db_name or not db_uuid or not db_uri:
                    logger.error(f"Empty values in {env_var}: name='{db_name}', uuid='{db_uuid}'")
                    failed += 1
                    continue

                logger.info(f"Processing {env_var}: {db_name} (UUID: {db_uuid})")

                # Check if connection exists by UUID
                existing = db.session.query(Database).filter_by(uuid=db_uuid).first()

                if existing:
                    # Update existing connection
                    if existing.database_name != db_name or existing.sqlalchemy_uri != db_uri:
                        existing.database_name = db_name
                        existing.sqlalchemy_uri = db_uri
                        db.session.commit()
                        logger.info(f"Updated existing connection '{db_name}' (UUID: {db_uuid})")
                    else:
                        logger.info(f"Connection '{db_name}' already up to date (UUID: {db_uuid})")
                    successful += 1
                else:
                    # Also check by name to avoid duplicates
                    existing_by_name = db.session.query(Database).filter_by(
                        database_name=db_name
                    ).first()

                    if existing_by_name:
                        # Update existing to use the correct UUID
                        existing_by_name.uuid = db_uuid
                        existing_by_name.sqlalchemy_uri = db_uri
                        db.session.commit()
                        logger.info(f"Updated '{db_name}' to use UUID: {db_uuid}")
                    else:
                        # Create new connection
                        new_db = Database(
                            database_name=db_name,
                            sqlalchemy_uri=db_uri,
                            uuid=db_uuid,
                            expose_in_sqllab=True,
                            allow_run_async=True,
                            allow_ctas=True,
                            allow_cvas=True,
                            allow_dml=True,
                        )
                        db.session.add(new_db)
                        db.session.commit()
                        logger.info(f"Created new connection '{db_name}' (UUID: {db_uuid})")

                    successful += 1

            except Exception as e:
                logger.error(f"Error processing {env_var}: {e}")
                import traceback
                logger.error(traceback.format_exc())
                failed += 1
                # Rollback on error
                try:
                    db.session.rollback()
                except:
                    pass

    finally:
        ctx.pop()

    logger.info(f"DWE connection sync complete: {successful} successful, {failed} failed")
    return successful, failed


# CLI entry point
if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    print("Setting up shared database connections...")

    if len(sys.argv) > 1:
        base_url = sys.argv[1]
    else:
        base_url = os.getenv('SUPERSET_BASE_URL', 'http://localhost:8088')

    success, failed = setup_shared_connections(base_url)

    if failed == 0:
        print(f"Successfully created {success} connection(s)")
        sys.exit(0)
    else:
        print(f"Created {success} connection(s), {failed} failed")
        sys.exit(1)
