"""
Setup module for Dashboard Migration plugin.

Provides functions to create database connections with identical UUIDs
across multiple Superset environments.
"""

from dwe_hub_superset_plugin.setup.connections import (
    SHARED_DB_UUID,
    create_database_connection,
    create_connections_from_env,
    setup_shared_connections,
    setup_default_shared_connection,
    wait_for_superset_api,
    authenticate_superset,
    sync_connections_from_dwe_env,
)

__all__ = [
    "SHARED_DB_UUID",
    "create_database_connection",
    "create_connections_from_env",
    "setup_shared_connections",
    "setup_default_shared_connection",
    "wait_for_superset_api",
    "authenticate_superset",
    "sync_connections_from_dwe_env",
]
