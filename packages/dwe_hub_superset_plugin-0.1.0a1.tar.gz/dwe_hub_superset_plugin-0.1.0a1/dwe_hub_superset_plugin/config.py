"""
Configuration management for the Dashboard Migration tool.
"""

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MigrationConfig:
    """
    Configuration for the Dashboard Migration service.

    Attributes:
        migration_db_url: PostgreSQL connection URL for the migration database
        git_repo_path: Path to the git repository for dashboard versioning
        dev_superset_url: URL of the DEV Superset instance
        prod_superset_url: URL of the PROD Superset instance
        superset_username: Username for Superset API authentication
        superset_password: Password for Superset API authentication
        screenshot_enabled: Whether to capture screenshots during migration
        headless_browser: Whether to run Playwright in headless mode
        current_env: Current environment (dev/prod)
    """

    migration_db_url: str = field(
        default_factory=lambda: os.environ.get(
            "MIGRATION_DB_URL",
            "postgresql+psycopg://migration:migration@localhost:5432/migration",
        )
    )
    git_repo_path: str = field(
        default_factory=lambda: os.environ.get("DASHBOARD_REPO_PATH", "./dashboard-repo")
    )
    dev_superset_url: str = field(
        default_factory=lambda: os.environ.get("DEV_SUPERSET_URL", "http://localhost:8088")
    )
    prod_superset_url: str = field(
        default_factory=lambda: os.environ.get("PROD_SUPERSET_URL", "http://localhost:8089")
    )
    superset_username: str = field(
        default_factory=lambda: os.environ.get("SUPERSET_USERNAME", "admin")
    )
    superset_password: str = field(
        default_factory=lambda: os.environ.get("SUPERSET_PASSWORD", "admin")
    )
    screenshot_enabled: bool = field(
        default_factory=lambda: os.environ.get("SCREENSHOT_ENABLED", "true").lower() == "true"
    )
    headless_browser: bool = field(
        default_factory=lambda: os.environ.get("HEADLESS_BROWSER", "true").lower() == "true"
    )
    current_env: str = field(
        default_factory=lambda: os.environ.get("SUPERSET_ENV", "dev")
    )

    @classmethod
    def from_superset_config(cls, app_config: dict) -> "MigrationConfig":
        """
        Create configuration from Superset app config.

        Args:
            app_config: Superset Flask app configuration dictionary

        Returns:
            MigrationConfig instance
        """
        return cls(
            migration_db_url=app_config.get(
                "MIGRATION_DB_URL",
                os.environ.get(
                    "MIGRATION_DB_URL",
                    "postgresql+psycopg://migration:migration@localhost:5432/migration",
                ),
            ),
            git_repo_path=app_config.get(
                "DASHBOARD_REPO_PATH",
                os.environ.get("DASHBOARD_REPO_PATH", "./dashboard-repo"),
            ),
            dev_superset_url=app_config.get(
                "DEV_SUPERSET_URL",
                os.environ.get("DEV_SUPERSET_URL", "http://localhost:8088"),
            ),
            prod_superset_url=app_config.get(
                "PROD_SUPERSET_URL",
                os.environ.get("PROD_SUPERSET_URL", "http://localhost:8089"),
            ),
            superset_username=app_config.get(
                "MIGRATION_TARGET_USERNAME",
                os.environ.get("SUPERSET_USERNAME", "admin"),
            ),
            superset_password=app_config.get(
                "MIGRATION_TARGET_PASSWORD",
                os.environ.get("SUPERSET_PASSWORD", "admin"),
            ),
            current_env=app_config.get(
                "SUPERSET_ENV",
                os.environ.get("SUPERSET_ENV", "dev"),
            ),
        )

    def get_source_url(self) -> str:
        """Get the source Superset URL based on current environment."""
        return self.dev_superset_url if self.current_env == "dev" else self.prod_superset_url

    def get_target_url(self) -> str:
        """Get the target Superset URL based on current environment."""
        return self.prod_superset_url if self.current_env == "dev" else self.dev_superset_url

    def validate(self) -> list[str]:
        """
        Validate the configuration.

        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []

        if not self.migration_db_url:
            errors.append("migration_db_url is required")

        if not self.git_repo_path:
            errors.append("git_repo_path is required")

        if not self.dev_superset_url:
            errors.append("dev_superset_url is required")

        if not self.prod_superset_url:
            errors.append("prod_superset_url is required")

        if self.current_env not in ("dev", "staging", "prod"):
            errors.append(f"current_env must be 'dev', 'staging', or 'prod', got '{self.current_env}'")

        return errors


# Global configuration instance (lazy initialization)
_config: Optional[MigrationConfig] = None


def get_config() -> MigrationConfig:
    """
    Get the global configuration instance.

    Returns:
        MigrationConfig instance
    """
    global _config
    if _config is None:
        _config = MigrationConfig()
    return _config


def set_config(config: MigrationConfig) -> None:
    """
    Set the global configuration instance.

    Args:
        config: MigrationConfig instance to set
    """
    global _config
    _config = config
