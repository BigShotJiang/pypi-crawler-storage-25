"""
Superset Dashboard Migration - Git-like version control for dashboards.
"""

__version__ = "0.1.0"

# Lazy imports to avoid circular dependencies
def get_session():
    from dwe_hub_superset_plugin.database import get_session as _get_session
    return _get_session()

def init_db(url):
    from dwe_hub_superset_plugin.database import init_db as _init_db
    return _init_db(url)
