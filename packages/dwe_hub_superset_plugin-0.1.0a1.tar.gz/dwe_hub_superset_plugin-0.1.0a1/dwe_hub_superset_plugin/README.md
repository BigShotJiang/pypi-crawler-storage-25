# Superset Dashboard Migration Plugin

A Flask-AppBuilder plugin for Apache Superset that enables dashboard export/import via DWE Hub and direct environment-to-environment migration.

## Overview

This plugin adds dashboard migration capabilities to Superset:
- **Hub Integration**: Publish dashboards to DWE Hub, import from Hub gallery
- **Clean Import**: Fully replaces dashboards and charts (no merge artifacts)
- **Version Comparison**: View AI-powered diffs between dashboard versions
- **Connection Sync**: Automatically synchronize database connections across environments
- **Direct Migration** (Legacy): Push dashboards directly between Superset instances

## Installation

### Via Docker (Recommended)

The plugin is automatically installed in the Docker images. See the main project's `docker-compose.yaml`.

### Manual Installation

```bash
cd dwe_hub_superset_plugin
pip install -e .
```

Then configure Superset (see Configuration section below).

## Features

### 1. Hub Export/Import

**Export to Hub:**
1. Go to **Custom Tools > DWE Hub**
2. Click **Export to Hub** tab
3. Select a dashboard
4. Choose visibility (Public/Private)
5. Add description and commit message
6. Click **Publish**

**Import from Hub:**
1. Go to **Custom Tools > DWE Hub**
2. Browse the gallery or search
3. Click **Preview** to see details
4. Click **Import** to add to your Superset

### 2. Clean Import

When importing, the plugin performs a "clean import":
1. Extracts chart UUIDs from the import ZIP
2. Deletes existing charts with matching UUIDs
3. Keeps the dashboard (preserves dashboard ID)
4. Imports fresh via Superset's API with overwrite

This ensures charts are fully replaced, not merged.

### 3. Version Comparison

Compare any two versions of a dashboard:
1. Go to an asset's detail page in Hub
2. Click **Compare Versions**
3. Select two versions to compare
4. View:
   - Structural changes (charts added/removed/modified/moved)
   - AI-powered summary explaining the changes
   - Statistics comparison

### 4. Connection Sync

Automatically create/update database connections on Superset startup using environment variables.

```yaml
environment:
  DWE_SYNC_CONN_MYDB: "My Database|550e8400-e29b-41d4-a716-446655440001|postgresql://user:pass@host:5432/db"
```

Format: `Display Name|UUID|SQLAlchemy_URI`

This ensures dashboards work across environments by maintaining consistent connection UUIDs.

## Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DWE_HUB_URL` | DWE Hub API URL | Yes |
| `DWE_HUB_USER` | Hub username for authentication | Yes |
| `DWE_HUB_PASSWORD` | Hub password | Yes |
| `SUPERSET_ENV` | Environment name (e.g., `dev`, `prod`) | Yes |
| `SUPERSET_BASE_URL` | This Superset's base URL | No |

### superset_config.py

Add the plugin to your Superset configuration:

```python
import os

# Plugin Configuration
DWE_HUB_URL = os.environ.get("DWE_HUB_URL", "http://dwe-hub:5000")
DWE_HUB_USER = os.environ.get("DWE_HUB_USER", "admin")
DWE_HUB_PASSWORD = os.environ.get("DWE_HUB_PASSWORD", "admin")
SUPERSET_ENV = os.environ.get("SUPERSET_ENV", "dev")

# Register the plugin
def init_app(app):
    from dwe_hub_superset_plugin.views.hub_view import DWEHubView

    appbuilder = app.appbuilder
    appbuilder.add_view(
        DWEHubView,
        "DWE Hub",
        icon="fa-cloud",
        category="Custom Tools"
    )

FLASK_APP_MUTATOR = init_app
```

### Connection Sync Setup

In your `docker-entrypoint.sh` or startup script:

```bash
# Set connection sync variables
export DWE_SYNC_CONN_SHARED="Shared Data|a2dc77af-e654-49bb-b321-40f6b559a1ee|postgresql://user:pass@shared-db:5432/data"
export DWE_SYNC_CONN_WAREHOUSE="Data Warehouse|b3ed88bf-f765-50cc-c432-51g7c660b2ff|snowflake://..."
```

The plugin scans for `DWE_SYNC_CONN_*` variables on startup and creates/updates connections.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Superset Instance                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │            dwe_hub_superset_plugin              │   │
│  │                                                      │   │
│  │  ┌──────────────┐  ┌──────────────┐                 │   │
│  │  │  DWEHubView  │  │ MigrationView│  (Flask Views)  │   │
│  │  │  /hub/*      │  │ /migration/* │                 │   │
│  │  └──────┬───────┘  └──────┬───────┘                 │   │
│  │         │                 │                          │   │
│  │  ┌──────┴─────────────────┴──────┐                  │   │
│  │  │          Services             │                  │   │
│  │  │  - HubClient (API client)     │                  │   │
│  │  │  - SupersetAPIClient          │                  │   │
│  │  │  - ConnectionSync             │                  │   │
│  │  └───────────────────────────────┘                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                           │                                 │
└───────────────────────────┼─────────────────────────────────┘
                            │
                            ▼
                   ┌─────────────────┐
                   │    DWE Hub      │
                   │  (REST API)     │
                   └─────────────────┘
```

## Project Structure

```
dwe_hub_superset_plugin/
├── __init__.py              # Package init, plugin registration
├── config.py                # Configuration management
├── database.py              # Legacy migration database
│
├── services/                # Core business logic
│   ├── hub_client.py        # DWE Hub API client
│   │   - HubClient class
│   │   - publish_dashboard()
│   │   - download_asset()
│   │   - get_version_diff()
│   │
│   ├── superset_api.py      # Superset REST API client
│   │   - SupersetAPIClient class
│   │   - export_dashboard()
│   │   - import_dashboard()
│   │   - import_dashboard_clean()
│   │   - list_dashboards()
│   │
│   ├── git_service.py       # Git operations (legacy)
│   └── migration_service.py # Migration orchestration (legacy)
│
├── views/                   # Flask-AppBuilder views
│   ├── hub_view.py          # DWE Hub UI
│   │   - Gallery (import from hub)
│   │   - Export (publish to hub)
│   │   - Preview & Import
│   │   - Version diff
│   │
│   ├── migration_view.py    # Direct migration UI (legacy)
│   └── api_view.py          # REST API endpoints
│
├── setup/                   # Setup utilities
│   └── connections.py       # DWE_SYNC_CONN_* handler
│
├── models/                  # SQLAlchemy models (legacy)
│   ├── migration.py
│   ├── version.py
│   ├── audit.py
│   └── screenshot.py
│
├── templates/               # Jinja2 templates
│   └── hub/
│       ├── gallery.html
│       ├── export.html
│       └── preview.html
│
└── static/                  # CSS/JS assets
    └── hub/
        └── styles.css
```

## Services

### HubClient

Client for interacting with DWE Hub API.

```python
from dwe_hub_superset_plugin.services.hub_client import HubClient

client = HubClient(
    hub_url="http://localhost:5050",
    username="admin",
    password="admin"
)

# List assets
assets = client.list_assets(visibility="public")

# Publish dashboard
result = client.publish_dashboard(
    zip_content=zip_bytes,
    name="My Dashboard",
    description="Description",
    visibility="public",
    commit_message="Initial version",
    source_environment="dev"
)

# Download asset
zip_content = client.download_asset(asset_uuid, version=1)

# Get version diff
diff = client.get_version_diff(asset_uuid, v1=1, v2=2)
```

### SupersetAPIClient

Client for interacting with Superset's REST API.

```python
from dwe_hub_superset_plugin.services.superset_api import SupersetAPIClient

client = SupersetAPIClient(
    base_url="http://localhost:8088",
    username="admin",
    password="admin"
)

# List dashboards
dashboards = client.list_dashboards()

# Export dashboard
zip_content = client.export_dashboard(dashboard_id=1)

# Import dashboard (clean - deletes existing charts first)
client.import_dashboard_clean(zip_content, dashboard_uuid="...")

# Find dashboard by UUID
dashboard = client.find_dashboard_by_uuid("...")
```

## Clean Import Process

The `import_dashboard_clean()` method ensures dashboards are fully replaced:

```
1. Extract chart UUIDs from import ZIP
   └── Parse /charts/*.yaml files

2. For each chart UUID:
   ├── Find existing chart by UUID (export & match)
   └── Delete existing chart if found

3. Check if dashboard exists (by UUID)
   └── Log status (will be updated, not deleted)

4. Import via Superset API with overwrite=True
   ├── Creates new charts
   ├── Updates dashboard properties
   └── Updates position_json (layout)

Result: Dashboard ID stable, charts fully replaced
```

## UI Routes

| Route | Description |
|-------|-------------|
| `/hub/` | Gallery - browse/search public dashboards |
| `/hub/export` | Export - publish dashboard to Hub |
| `/hub/export/<id>` | Export specific dashboard |
| `/hub/preview/<uuid>` | Preview asset details |
| `/hub/import/<uuid>` | Import asset to Superset |
| `/hub/diff/<uuid>` | Version comparison page |

## Troubleshooting

### "Hub not connected"

1. Check Hub is running: `curl http://localhost:5050/api/v1/health`
2. Verify credentials in environment variables
3. Check network: Can Superset reach Hub?

### Import fails silently

Check Superset logs:
```bash
docker logs superset-dev 2>&1 | grep -i "import\|error"
```

Common issues:
- Missing database connection (UUID mismatch)
- Dataset not found
- Permission denied

### Charts not updating after import

The clean import should handle this. If issues persist:
1. Check logs for "Deleting existing chart" messages
2. Verify chart UUIDs match between source and target
3. Try manual delete of charts before import

### Connection sync not working

1. Verify `DWE_SYNC_CONN_*` variable format: `Name|UUID|URI`
2. Check Superset startup logs for sync messages
3. Ensure the Superset user has permission to create database connections

## Development

### Running locally

```bash
# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
mypy dwe_hub_superset_plugin
```

### Adding new views

1. Create view class in `views/`
2. Register in `__init__.py` or via `FLASK_APP_MUTATOR`
3. Add templates in `templates/`

### Extending HubClient

```python
class MyHubClient(HubClient):
    def custom_method(self):
        response = self._request("GET", "/api/v1/custom")
        return response.json()
```

## License

MIT License
