"""
Database connection management for the Dashboard Migration tool.
"""

import logging
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from dwe_hub_superset_plugin.models.base import Base

logger = logging.getLogger(__name__)

_engine = None
_SessionLocal = None


def init_db(database_url, echo=False):
    """Initialize the database connection and create tables."""
    global _engine, _SessionLocal

    if _engine is not None:
        logger.info("Database already initialized")
        return _engine

    logger.info(f"Initializing database: {database_url.split('@')[-1]}")

    _engine = create_engine(
        database_url,
        echo=echo,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
    )

    _SessionLocal = sessionmaker(
        bind=_engine,
        autocommit=False,
        autoflush=False,
    )

    try:
        Base.metadata.create_all(bind=_engine)
        logger.info("Database tables created")
    except Exception as e:
        logger.warning(f"Could not create tables: {e}")

    return _engine


def get_engine():
    """Get the database engine."""
    if _engine is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _engine


def get_session():
    """Get a new database session."""
    if _SessionLocal is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _SessionLocal()


@contextmanager
def session_scope():
    """Provide a transactional scope."""
    session = get_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def check_connection():
    """Check if the database connection is working."""
    try:
        engine = get_engine()
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return False


def close_db():
    """Close the database connection."""
    global _engine, _SessionLocal

    if _engine is not None:
        _engine.dispose()
        _engine = None
        _SessionLocal = None
        logger.info("Database connection closed")
