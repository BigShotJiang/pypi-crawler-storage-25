from pathlib import Path

APPIMAGE_FOLDER = Path("~/.local/appimages/").expanduser()
DESKTOP_ENTRY = Path("~/.local/share/applications/").expanduser()
ICON_FOLDER = Path("~/.local/share/icons/aim/").expanduser()
SYSTEM_BIN = Path("/usr/local/bin")

ROOT_WARNING = (
    "Warning: Aim is designed to run without sudo. Run Aim normally; it will ask "
    "for sudo only when system access is needed."
)

HELP_TEXT = """Aim AppImage Manager

Install and launch:
  install <file-or-url> [options]   Install and register an AppImage.
  open <file-or-url>                Run an AppImage once without installing it.
  run <app>                         Run an installed AppImage by name.

Manage:
  update <app> [app ...] [--no-icon]       Redownload URL-installed apps.
  uninstall <app> [app ...] [--force]      Remove installed apps and their files.

Inspect:
  list [--detailed]                 Show installed apps.
  info <app>                        Show metadata for one app.
  stats                             Show app count and total disk usage.

Paths and editing:
  path <app>                        Print the managed AppImage path.
  desktop <app>                     Print the desktop entry path.
  edit <app>                        Open the desktop entry in your editor.

Install options:
  --name NAME                       Choose the managed app name.
  --replace                         Replace an existing app with the same name.
  --no-icon                         Skip icon extraction.
  --no-desktop                      Skip desktop entry creation.
  --system                          Add a /usr/local/bin command symlink.

Examples:
  aim install ./App.AppImage
  aim install https://example.com/App.AppImage --name app
  aim open ./App.AppImage
  aim install ./cli.AppImage --name cli-tool --system --no-desktop
  aim path app
  aim desktop app
  EDITOR=nano aim edit app
  aim update app another-app
  aim uninstall app another-app --force
"""

def DESKTOP_TEMPLATE(name, app_path, icon_path=None):
    icon_line = f"Icon={icon_path}\n" if icon_path else ""
    return f"""[Desktop Entry]
Name={name}
Exec={app_path}
{icon_line}Type=Application
Terminal=false
Categories=Utility;
"""
