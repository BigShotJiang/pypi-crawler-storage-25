
#!/usr/bin/env python3

"""
Aim: AppImage Installation Manager

CLI Entrypoint
- Parse CLI commands using click
- Route to service layer
- Handles top level errors and gives user friendly output
- Manages root/sudo behavior

Core logic lives in services.py
This file focuses on CLI and orchestration
"""

import os
import shutil
import sys
import subprocess
from functools import wraps

# -- Dependency Startup --
try:
    import click
except ModuleNotFoundError:
    # We avoid using the app with sudo as it can break the virtual environment and is not recommended for regular installs.
    # We only use sudo with certain operations that require it.
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        print(
            "Warning: Aim is designed to run without sudo. Running as root can also bypass your virtual environment.",
            file=sys.stderr,
        )
        print("Try running Aim again without sudo. Aim will ask for sudo only when it needs system access.", file=sys.stderr)
        sys.exit(1)
    print("Missing dependency: click. Activate the virtual environment and try again.", file=sys.stderr)
    sys.exit(1)

try:
    from .appdatabase import AppDatabase
    from .constants import HELP_TEXT, ROOT_WARNING
    from .services import install_application, open_appimage, uninstall_application, update_application
    from .utils import *
except ImportError:
    from appdatabase import AppDatabase
    from constants import HELP_TEXT, ROOT_WARNING
    from services import install_application, open_appimage, uninstall_application, update_application
    from utils import *

# -- CLI Initialization --
def handle_errors(func):
    # Wraps the command function so internal errors are shown as CLI messages
    # rather than Python tracebacks.
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            raise click.ClickException(str(e)) from e
    return wrapper

class AimGroup(click.Group):
    def get_help(self, ctx):
        return HELP_TEXT


@click.group(cls=AimGroup, invoke_without_command=True)
@click.option("--no-root-warning", is_flag=True, help="Hide the warning shown when running as root.")
@click.pass_context
def cli(ctx, no_root_warning):
    if not no_root_warning and hasattr(os, "geteuid") and os.geteuid() == 0:
        click.echo(ROOT_WARNING, err=True)

    if ctx.invoked_subcommand is None:
        click.echo(HELP_TEXT)

@cli.command(name="help")
def help_command():
    click.echo(HELP_TEXT)


# -- CLI Display Helpers --
def _progress_reporter(app_name):
    """
    Makes a progress callback for downloads.
    Returns:
        update_progress(bytes_read, total_size)
        close_progress()

    Uses click.progressbar for visual feedback.
    Initializes the bar only when data starts streaming.
    """
    if not app_name:
        return None, lambda: None

    progress_bar = None

    def update_progress(bytes_read, total_size):
        nonlocal progress_bar
        if progress_bar is None:
            label = f"Downloading {app_name} ({format_size(total_size)})"
            progress_bar = click.progressbar(
                length=total_size or None,
                label=label,
                show_eta=bool(total_size),
                show_percent=bool(total_size),
            )
            progress_bar.__enter__()
        if bytes_read:
            progress_bar.update(bytes_read)

    def close_progress():
        if progress_bar is not None:
            progress_bar.__exit__(None, None, None)

    return update_progress, close_progress


# -- Install Command --
@cli.command()
@click.option("--name", "app_name", help="Name to use for the installed application.")
@click.option("--replace", is_flag=True, help="Replace an existing application with the same name.")
@click.option("--no-icon", is_flag=True, help="Skip AppImage icon extraction.")
@click.option("--no-desktop", is_flag=True, help="Skip desktop entry creation.")
@click.option("--system", is_flag=True, help="Create a system command symlink in /usr/local/bin.")
@click.argument("file_path")
@handle_errors
def install(file_path, app_name, replace, no_icon, no_desktop, system):
    # Resolve name either custom or derived from filename.
    download_name = None
    if is_url(file_path):
        download_name = app_name or get_clean_app_name(filename_from_url(file_path))

    progress_callback, close_progress = _progress_reporter(download_name)
    try:
        app = install_application(
            file_path,
            app_name=app_name,
            replace=replace,
            progress_callback=progress_callback,
            extract_icon=not no_icon,
            create_desktop=not no_desktop,
            system=system,
        )
    finally:
        close_progress()

    click.echo(f"Installed {app['name']}")


# -- Open Command --
@cli.command()
@click.argument("file_path")
@handle_errors
def open(file_path):
    download_name = None
    if is_url(file_path):
        download_name = get_clean_app_name(filename_from_url(file_path))

    progress_callback, close_progress = _progress_reporter(download_name)
    try:
        open_appimage(file_path, progress_callback=progress_callback)
    finally:
        close_progress()


# -- Run Command --
@cli.command()
@click.argument("application_name")
@handle_errors
def run(application_name):
    db = AppDatabase()
    try:
        appPath = db.get_application_path(application_name)
    except KeyError:
        raise click.ClickException(f"Application {application_name} not found")

    runApplication(appPath)


# -- Update Command --
@cli.command()
@click.option("--no-icon", is_flag=True, help="Skip AppImage icon extraction.")
@click.argument("application_names", nargs=-1, required=True)
@handle_errors
def update(application_names, no_icon):
    # Updates multiple apps with individual progress bars.
    for application_name in application_names:
        progress_callback, close_progress = _progress_reporter(application_name)
        try:
            app = update_application(
                application_name,
                progress_callback=progress_callback,
                extract_icon=not no_icon,
            )
        finally:
            close_progress()

        click.echo(f"Updated {app['name']}")


# -- Uninstall Command --
@cli.command()
@click.option("-f", "--force", is_flag=True, help="Uninstall without confirmation.")
@click.argument("application_names", nargs=-1, required=True)
@handle_errors
def uninstall(application_names, force):
    db = AppDatabase()

    for application_name in application_names:
        if not db.application_exists(application_name):
            raise click.ClickException(f"Application {application_name} not found")
        # Ask confirmation unless --force is passed to prevent accidental app deletion.
        if not force and not click.confirm(f"Uninstall {application_name}?"):
            click.echo(f"Skipped {application_name}")
            continue

        # Lower level removal logic is separated from the CLI for reusability and testing.
        uninstall_application(application_name)
        click.echo(f"Uninstalled {application_name}")


# -- List Command --
@cli.command(name="list")
@click.option("--detailed", is_flag=True, help="Show installed app details.")
@handle_errors
def list_apps(detailed):
    db = AppDatabase()
    apps = db.list_applications()
    if not detailed:
        click.echo(format_app_list(apps))
        return

    rows = []
    for app_name in apps:
        app = db.get_application(app_name)
        app_path = app["app_path"]
        source = "url" if app.get("source_url") else "local"
        system_path = app.get("system_path") or "-"
        rows.append((app["name"], format_size(file_size(app_path)), source, app_path, system_path))

    click.echo(_format_detailed_app_list(rows))

# -- List Formatting --
def _format_detailed_app_list(rows):
    if not rows:
        return ""

    headers = ("Name", "Size", "Source", "AppImage Path", "System Path")
    # Compute column width dynamically so that the output shows neatly in the terminal.
    widths = [
        max(len(str(row[index])) for row in (headers, *rows))
        for index in range(len(headers))
    ]
    lines = [
        "  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)),
        "  ".join("-" * width for width in widths),
    ]

    for row in rows:
        lines.append("  ".join(str(value).ljust(widths[index]) for index, value in enumerate(row)))

    return "\n".join(lines)

# -- Info Command --
@cli.command()
@click.argument("application_name")
@handle_errors
def info(application_name):
    # Display detailed metadata for a single app.
    db = AppDatabase()
    try:
        app = db.get_application(application_name)
    except KeyError:
        raise click.ClickException(f"Application {application_name} not found")

    app_path = app["app_path"]
    desktop_path = app.get("desktop_path")
    source_url = app.get("source_url")
    system_path = app.get("system_path")

    click.echo(f"Name: {app['name']}")
    click.echo(f"Path: {app_path}")
    if desktop_path:
        click.echo(f"Desktop: {desktop_path}")
    if system_path:
        click.echo(f"System: {system_path}")
    if source_url:
        click.echo(f"Source: {source_url}")
    click.echo(f"Size: {format_size(file_size(app_path))}")

# -- Path Commands --
@cli.command(name="path")
@click.argument("application_name")
@handle_errors
def app_path(application_name):
    db = AppDatabase()
    try:
        click.echo(db.get_application_path(application_name))
    except KeyError:
        raise click.ClickException(f"Application {application_name} not found")

@cli.command()
@click.argument("application_name")
@handle_errors
def desktop(application_name):
    db = AppDatabase()
    try:
        desktop_path = db.get_desktop_path(application_name)
    except KeyError:
        raise click.ClickException(f"Application {application_name} not found")

    if not desktop_path:
        raise click.ClickException(f"Application {application_name} does not have a desktop entry")

    click.echo(desktop_path)

# -- Edit Command --
@cli.command()
@click.argument("application_name")
@handle_errors
def edit(application_name):
    db = AppDatabase()
    try:
        desktop_path = db.get_desktop_path(application_name)
    except KeyError:
        raise click.ClickException(f"Application {application_name} not found")

    if not desktop_path:
        raise click.ClickException(f"Application {application_name} does not have a desktop entry")

    editor = _get_editor()
    subprocess.run([editor, desktop_path], check=True)
    refresh_desktop()
    click.echo(f"Edited desktop entry for {application_name}")

def _get_editor():
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if editor:
        return editor

    for fallback in ("nano", "vim", "vi"):
        if shutil.which(fallback):
            return fallback

    raise click.ClickException("No editor found. Set EDITOR or VISUAL and try again.")

# -- Stats Command --
@cli.command()
@handle_errors
def stats():
    # Get total disk use for installed AppImages.
    db = AppDatabase()
    apps = db.list_applications()
    total_size = 0

    for app_name in apps:
        app = db.get_application(app_name)
        total_size += file_size(app["app_path"])

    click.echo(f"Applications: {len(apps)}")
    click.echo(f"Total size: {format_size(total_size)}")

if __name__ == "__main__":
    cli()
