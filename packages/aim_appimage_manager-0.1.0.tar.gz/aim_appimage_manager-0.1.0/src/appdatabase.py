"""
JSON-backed application database for Aim.

The database stores one record per managed AppImage, keyed by the app name used
by the CLI. Records include the AppImage path plus optional desktop entry, icon,
source URL, and system command symlink paths.

read the JSON file, update
the in-memory dictionary, then write it back.
"""

import json
from pathlib import Path


class AppDatabase:
    def __init__(self, path=None):
        if path is None:
            # Sote per user app data. No root requried and runs XDG-ish structure 
            path = Path.home() / ".local" / "share" / "aim" / "apps.json"
        self.path = path

    def _ensure_json_file(self):
        if not(self.path.exists()):
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({}))

    def _get_data(self):
        self._ensure_json_file()
        with open(self.path, "r") as f:
            return json.loads(f.read())

    def _write_data(self, data):
        with open(self.path, "w") as f:
            f.write(json.dumps(data, indent=4))

    def add_application(self, name, application_p, desktop_p=None, icon_p=None, source_url=None, system_p=None):
        data = self._get_data()
        data[name] = {
            "app_path": application_p,
            "desktop_path": desktop_p,
            "icon_path": icon_p,
            "source_url": source_url, # Source_url allows redowloading for updates
            "system_path": system_p,
            "name": name
        }
        self._write_data(data)

    def _get_data_with_application(self, application_name):
        data = self._get_data()
        if application_name not in data:
            raise KeyError(f"Application {application_name} does not exist")
        return data

    def application_exists(self, application_name):
        data = self._get_data()
        return application_name in data

    def get_application(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name]

    def get_application_path(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name]["app_path"]

    def get_desktop_path(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name].get("desktop_path")

    def get_icon_path(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name].get("icon_path")

    def get_source_url(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name].get("source_url")

    def get_system_path(self, application_name):
        data = self._get_data_with_application(application_name)
        return data[application_name].get("system_path")

    def list_applications(self):
        data = self._get_data()
        return list(data.keys())

    def remove_app_entry(self, application_name):
        data = self._get_data_with_application(application_name)
        del data[application_name]
        self._write_data(data)

    def print_db(self):
        print(self._get_data())
