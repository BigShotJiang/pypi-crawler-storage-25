"""
Low-level helpers for Aim.

These functions avoid CLI concerns and app workflow decisions. They handle
small reusable operations such as path cleanup, URL downloads, AppImage icon
extraction, file permissions, desktop database refreshes, and display
formatting.

Higher-level install/update/uninstall behavior lives in services.py.
"""

import shutil
import subprocess
from pathlib import Path
import re
import tempfile
from urllib.error import URLError
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

_VERSION_PATTERN = re.compile(
    r"(?i)(?:^|[-_.\s])v?\d+(?:\.\d+)+(?:[-_.+]?(?:alpha|beta|rc|pre|dev|build)\d*)?(?=$|[-_.\s])"
)
_ARCHITECTURE_PATTERN = re.compile(
    r"(?i)(?:^|[-_.\s])(?:x86_64|x86-64|amd64|aarch64|arm64|armv7l|armhf|i386|i686)(?=$|[-_.\s])"
)


try:
    from .constants import APPIMAGE_FOLDER, DESKTOP_ENTRY, ICON_FOLDER
except ImportError:
    from constants import APPIMAGE_FOLDER, DESKTOP_ENTRY, ICON_FOLDER


def get_clean_app_name(file_path):
    # Strip common version/architecture suffixes so AppImage filenames become
    # stable app names like "kdenlive" instead of "kdenlive-26.04.0-x86_64".
    name = Path(file_path).stem

    name = _VERSION_PATTERN.sub("", name).strip("-_. ")
    name = _ARCHITECTURE_PATTERN.sub("", name).strip("-_. ")

    return name.lower()


def format_app_list(apps):
    return "\n".join(f"- {app}" for app in apps)

def format_display_name(app_name):
    words = re.split(r"[-_\s]+", app_name.strip())
    return " ".join(word[:1].upper() + word[1:] for word in words if word)

def move_file(file_path, new_file_path):
    try:
        shutil.move(str(file_path), str(new_file_path))
    except Exception as e:
        raise RuntimeError(f"Failed to move file: {e}")

def download_appimage(url, download_dir, progress_callback=None):
    # Stream in chunks so large AppImages do not need to live in memory.
    download_dir.mkdir(parents=True, exist_ok=True)
    filename = filename_from_url(url)
    destination = _unique_path(download_dir / filename)
    request = Request(url, headers={"User-Agent": "Aim-AppImage-Manager"})

    try:
        with urlopen(request) as response, open(destination, "wb") as file:
            total_size = int(response.headers.get("Content-Length") or 0)
            if progress_callback:
                progress_callback(0, total_size)

            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                file.write(chunk)
                if progress_callback:
                    progress_callback(len(chunk), total_size)
    except (OSError, URLError) as e:
        remove_file(destination)
        raise RuntimeError(f"Failed to download AppImage: {e}") from e

    return destination

def filename_from_url(url):
    name = Path(unquote(urlparse(url).path)).name
    if not name:
        name = "downloaded.AppImage"
    if not name.lower().endswith(".appimage"):
        name = f"{name}.AppImage"
    return name

def format_size(size):
    if not size:
        return "size unknown"

    units = ("B", "KB", "MB", "GB")
    size = float(size)
    for unit in units:
        if size < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024

def file_size(file_path):
    try:
        return Path(file_path).stat().st_size
    except OSError:
        return 0

def is_appimage(file_path):
    # AppImage type 2 files are ELF binaries with an "AI" marker at byte offset 8.
    try:
        with open(file_path, "rb") as file:
            header = file.read(10)
    except OSError:
        return False

    return header.startswith(b"\x7fELF") and header[8:10] == b"AI"

def _unique_path(path):
    if not path.exists():
        return path

    for number in range(1, 1000):
        candidate = path.with_name(f"{path.stem}-{number}{path.suffix}")
        if not candidate.exists():
            return candidate

    raise RuntimeError(f"Could not find available filename for {path.name}")


def ensure_appimage_dir():
    if not APPIMAGE_FOLDER.exists():
        APPIMAGE_FOLDER.mkdir(parents=True, exist_ok=True)
    return APPIMAGE_FOLDER


def chmodFile(file_path):
    try:
        subprocess.run(["chmod", "+x", str(file_path)], check=True)
    except subprocess.CalledProcessError:
        raise RuntimeError("Failed to chmod")

def extract_appimage_icon(appimage_path, app_name):
    # AppImages expose their contents through --appimage-extract. We prefer
    # .DirIcon, then fall back to the icon named by the bundled desktop file.
    image_suffixes = {".png", ".svg", ".xpm"}

    with tempfile.TemporaryDirectory() as tmp_dir:
        try:
            result = subprocess.run(
                [str(appimage_path), "--appimage-extract"],
                cwd=tmp_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        except OSError:
            return None

        if result.returncode != 0:
            return None

        root = Path(tmp_dir) / "squashfs-root"
        if not root.exists():
            return None

        icon_source = root / ".DirIcon"
        if not icon_source.exists():
            icon_name = _read_desktop_icon_name(root)
            icon_source = _find_icon_file(root, icon_name, image_suffixes)

        if not icon_source or not icon_source.exists():
            return None

        suffix = icon_source.suffix or icon_source.resolve().suffix or ".png"
        icon_destination = ICON_FOLDER / f"{app_name}{suffix}"
        icon_destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(icon_source, icon_destination)
        except OSError:
            return None
        return str(icon_destination)

def _read_desktop_icon_name(root):
    for desktop_file in root.glob("*.desktop"):
        try:
            for line in desktop_file.read_text(errors="ignore").splitlines():
                if line.startswith("Icon="):
                    icon_name = line.split("=", 1)[1].strip()
                    return Path(icon_name).stem
        except OSError:
            continue
    return None

def _find_icon_file(root, icon_name, image_suffixes):
    candidates = (
        path for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in image_suffixes
    )

    if icon_name:
        for candidate in candidates:
            if candidate.stem == icon_name:
                return candidate
        candidates = (
            path for path in root.rglob("*")
            if path.is_file() and path.suffix.lower() in image_suffixes
        )

    return max(candidates, key=lambda path: path.stat().st_size, default=None)

def write_file(file_path, content):
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w") as file:
            file.write(content)
    except:
        raise RuntimeError("Write failed we will figure it out maybe ")

def refresh_desktop():
    # Refreshing is best-effort; installs should still succeed if the desktop
    # database tool is unavailable on a user's distro.
    subprocess.run(
        ["update-desktop-database", str(DESKTOP_ENTRY)],
        check=False,
        stderr=subprocess.DEVNULL,
    )

def runApplication(application_path):
    subprocess.run([(application_path)])

def remove_file(file_path):
    path = Path(file_path)
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except Exception as e:
        raise RuntimeError(f"Failed to delete file {e}") from e


def is_url(value):
    return value.startswith(("http://", "https://"))
