"""
Application workflow layer for Aim.

This module owns the high-level AppImage lifecycle:
- install local files and URLs
- update URL-installed applications
- uninstall managed applications
- write desktop entries and database records
- create/remove optional system command symlinks

The CLI layer should call these functions instead of handling file cleanup or
desktop integration directly.
"""

import os
import subprocess
import tempfile
from pathlib import Path

try:
    from .appdatabase import AppDatabase
    from .constants import DESKTOP_ENTRY, DESKTOP_TEMPLATE, SYSTEM_BIN
    from .utils import (
        chmodFile,
        download_appimage,
        ensure_appimage_dir,
        extract_appimage_icon,
        filename_from_url,
        get_clean_app_name,
        format_display_name,
        is_appimage,
        is_url,
        move_file,
        refresh_desktop,
        remove_file,
        write_file,
    )
except ImportError:
    from appdatabase import AppDatabase
    from constants import DESKTOP_ENTRY, DESKTOP_TEMPLATE, SYSTEM_BIN
    from utils import (
        chmodFile,
        download_appimage,
        ensure_appimage_dir,
        extract_appimage_icon,
        filename_from_url,
        get_clean_app_name,
        format_display_name,
        is_appimage,
        is_url,
        move_file,
        refresh_desktop,
        remove_file,
        write_file,
    )


# -- Public Workflows --
def install_application(
    file_path,
    app_name=None,
    replace=False,
    progress_callback=None,
    extract_icon=True,
    create_desktop=True,
    system=False,
):
    install_dir = ensure_appimage_dir()
    db = AppDatabase()
    source_url = file_path if is_url(file_path) else None

    # URL installs keep their source so future updates can redownload from it.
    if is_url(file_path):
        final_name = app_name or get_clean_app_name(filename_from_url(file_path))
        _check_system_install(db, final_name, system, replace)
        _check_install_name(db, final_name, replace)
        destination = download_appimage(file_path, install_dir, progress_callback)
        _validate_appimage(destination)

        if replace:
            _remove_installed_files(db, final_name, skip_app_path=destination)
    else:
        source_path = Path(file_path)
        if not source_path.exists():
            raise FileNotFoundError(f"File {file_path} not found")

        final_name = app_name or get_clean_app_name(source_path)
        _check_system_install(db, final_name, system, replace)
        _check_install_name(db, final_name, replace)
        _validate_appimage(source_path, remove_invalid=False)
        destination = install_dir / source_path.name
        if replace:
            _remove_installed_files(db, final_name, skip_app_path=source_path)
        if source_path.resolve() != destination.resolve():
            move_file(source_path, destination)

    return _register_application(
        db,
        final_name,
        destination,
        source_url,
        extract_icon=extract_icon,
        create_desktop=create_desktop,
        system=system,
    )


def update_application(application_name, progress_callback=None, extract_icon=True):
    db = AppDatabase()
    try:
        source_url = db.get_source_url(application_name)
    except KeyError:
        raise KeyError(f"Application {application_name} not found")

    if not source_url:
        raise ValueError(f"Application {application_name} was not installed from a URL")

    app = db.get_application(application_name)
    create_desktop = bool(app.get("desktop_path"))
    system = bool(app.get("system_path"))
    _check_system_install(db, application_name, system, replace=True)

    # Preserve the original integration style: desktop apps stay desktop apps,
    # system command installs keep their /usr/local/bin symlink.
    install_dir = ensure_appimage_dir()
    destination = download_appimage(source_url, install_dir, progress_callback)
    _validate_appimage(destination)
    _remove_installed_files(db, application_name, skip_app_path=destination)

    return _register_application(
        db,
        application_name,
        destination,
        source_url,
        extract_icon=extract_icon,
        create_desktop=create_desktop,
        system=system,
    )


def uninstall_application(application_name):
    db = AppDatabase()
    if not db.application_exists(application_name):
        raise KeyError(f"Application {application_name} not found")

    _remove_installed_files(db, application_name)
    db.remove_app_entry(application_name)
    refresh_desktop()

    return application_name


def open_appimage(file_path, progress_callback=None):
    with tempfile.TemporaryDirectory() as tmp_dir:
        if is_url(file_path):
            destination = download_appimage(file_path, Path(tmp_dir), progress_callback)
            _validate_appimage(destination)
        else:
            destination = Path(file_path)
            if not destination.exists():
                raise FileNotFoundError(f"File {file_path} not found")
            _validate_appimage(destination, remove_invalid=False)

        chmodFile(destination)
        subprocess.run([str(destination)])

    return str(destination)


# -- Application Registration --
def _register_application(db, app_name, destination, source_url, extract_icon=True, create_desktop=True, system=False):
    # Registration is the final install step after validation/download succeeds.
    # It makes the AppImage executable, adds optional integrations, and records it.
    chmodFile(destination)
    icon_path = extract_appimage_icon(destination, app_name) if extract_icon else None

    dot_desktop_path = None
    if create_desktop:
        dot_desktop_path = DESKTOP_ENTRY / f"{app_name}.desktop"
        desktop_content = DESKTOP_TEMPLATE(
            name=format_display_name(app_name),
            app_path=str(destination),
            icon_path=icon_path,
        )
        write_file(dot_desktop_path, desktop_content)

    system_path = None
    if system:
        system_path = _create_system_symlink(app_name, destination)

    db.add_application(app_name,
                       str(destination),
                       str(dot_desktop_path) if dot_desktop_path else None,
                       icon_path,
                       source_url,
                       str(system_path) if system_path else None)

    refresh_desktop()
    return db.get_application(app_name)


# -- Validation Helpers --
def _validate_appimage(file_path, remove_invalid=True):
    # AppImages are ELF binaries with an "AI" marker at byte offset 8.
    # Invalid URL downloads are removed, but local user files are left alone.
    if is_appimage(file_path):
        return

    if remove_invalid:
        remove_file(file_path)
    raise ValueError(f"{file_path} is not a valid AppImage")


def _check_install_name(db, app_name, replace):
    if db.application_exists(app_name) and not replace:
        raise ValueError(
            f"Application {app_name} is already installed. Choose a different name with --name or use --replace."
        )


# -- Removal Helpers --
def _remove_installed_files(db, app_name, skip_app_path=None):
    # skip_app_path protects a newly downloaded replacement from being deleted
    # when it already lives at the same managed path as the previous install.
    if not db.application_exists(app_name):
        return

    app_path = db.get_application_path(app_name)
    desktop_path = db.get_desktop_path(app_name)
    icon_path = db.get_icon_path(app_name)

    if desktop_path:
        remove_file(desktop_path)
    if skip_app_path is None or Path(app_path).resolve() != Path(skip_app_path).resolve():
        remove_file(app_path)
    if icon_path:
        remove_file(icon_path)

    system_path = db.get_system_path(app_name)
    if system_path:
        remove_system_symlink(system_path)


# -- System Integration --
def _check_system_install(db, app_name, system, replace):
    if not system:
        return

    if not app_name or "/" in app_name:
        raise ValueError("System installs require a valid --name without slashes")

    system_path = SYSTEM_BIN / app_name
    replacing_managed_app = replace and db.application_exists(app_name)
    if (system_path.exists() or system_path.is_symlink()) and not replacing_managed_app:
        raise ValueError(f"System command {system_path} already exists")


def _create_system_symlink(app_name, destination):
    # Aim itself should run as the user. Only the privileged symlink operation
    # asks sudo for access to /usr/local/bin.
    system_path = SYSTEM_BIN / app_name
    if system_path.exists() or system_path.is_symlink():
        raise ValueError(f"System command {system_path} already exists")

    if _is_root():
        SYSTEM_BIN.mkdir(parents=True, exist_ok=True)
        system_path.symlink_to(destination)
    else:
        subprocess.run(["sudo", "mkdir", "-p", str(SYSTEM_BIN)], check=True)
        subprocess.run(["sudo", "ln", "-s", str(destination), str(system_path)], check=True)

    return system_path


def remove_system_symlink(system_path):
    system_path = Path(system_path)
    if system_path.parent != SYSTEM_BIN:
        raise ValueError(f"Refusing to remove system path outside {SYSTEM_BIN}: {system_path}")

    if not system_path.exists() and not system_path.is_symlink():
        return

    if _is_root():
        remove_file(system_path)
    else:
        subprocess.run(["sudo", "rm", "-f", str(system_path)], check=True)


def _is_root():
    return hasattr(os, "geteuid") and os.geteuid() == 0
