# BCPL LSP

Language Server Protocol implementation for [Martin Richards' BCPL](https://www.cl.cam.ac.uk/~mr10/BCPL.html).

## Install

```bash
pip install bcpl-lsp
# or
uv tool install bcpl-lsp
```

The server speaks LSP over stdio:

```bash
bcpl-lsp --stdio
```

## VS Code Extension

Install **BCPL LSP for VS Code** from the
[Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=se9-solutions.bcpl-lsp).
The extension automatically starts the language server when you open a `.b` or `.bcpl` file.

## Features

- Syntax highlighting (TextMate grammar)
- Completion (keywords with snippets, document symbols)
- Go to Definition
- Find References
- Hover (signatures and documentation)
- Rename (across files)
- Diagnostics (unresolved symbols, duplicate globals, unused variables)
- Semantic Tokens
- Document and Workspace Symbols
- Call Hierarchy

## BCPL Dialect

Targets canonical BCPL with uppercase keywords (`LET`, `IF`, `THEN`, `GET`, etc.).

## License

MIT
