"""Tests for completion logic."""

from __future__ import annotations

from lsprotocol import types

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.features.completion import get_completions, KEYWORD_SNIPPETS
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.parser.tokens import KEYWORDS


def test_completions_include_all_keywords():
    result = get_completions([])
    labels = {item.label for item in result.items}
    for kw in KEYWORDS:
        assert kw in labels


def test_keyword_snippets_have_snippet_format():
    result = get_completions([])
    for item in result.items:
        if item.label in KEYWORD_SNIPPETS:
            assert item.insert_text_format == types.InsertTextFormat.Snippet
            assert item.insert_text is not None
            assert item.detail is not None


def test_keyword_without_snippet_has_no_insert_text():
    result = get_completions([])
    non_snippet_kw = [item for item in result.items
                      if item.label in KEYWORDS and item.label not in KEYWORD_SNIPPETS]
    for item in non_snippet_kw:
        assert item.insert_text is None
        assert item.kind == types.CompletionItemKind.Keyword


def test_function_symbol_completion():
    sym = Symbol(
        name="lookup", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 10), params=["key", "table"],
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "lookup"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Function
    assert match[0].detail == "(key, table)"


def test_global_symbol_completion():
    sym = Symbol(
        name="output", kind=SymbolKind.GLOBAL,
        range=Range(0, 0, 0, 6), global_number=149,
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "output"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Variable
    assert match[0].detail == ": 149"


def test_constant_symbol_completion():
    sym = Symbol(
        name="MAXLINE", kind=SymbolKind.CONSTANT,
        range=Range(0, 0, 0, 7),
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "MAXLINE"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Constant


def test_section_symbols_excluded():
    sym = Symbol(
        name="MAIN", kind=SymbolKind.SECTION,
        range=Range(0, 0, 0, 4),
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "MAIN"]
    assert len(match) == 0


def test_completion_list_not_incomplete():
    result = get_completions([])
    assert result.is_incomplete is False


def test_workspace_symbols_merged():
    local = Symbol(name="foo", kind=SymbolKind.FUNCTION, range=Range(0, 4, 0, 7))
    ws_global = Symbol(name="output", kind=SymbolKind.GLOBAL, range=Range(0, 0, 0, 6), global_number=149)
    ws_const = Symbol(name="BUFSIZE", kind=SymbolKind.CONSTANT, range=Range(0, 0, 0, 7))
    result = get_completions([local], workspace_symbols=[ws_global, ws_const])
    labels = {item.label for item in result.items}
    assert "foo" in labels
    assert "output" in labels
    assert "BUFSIZE" in labels


def test_workspace_symbols_local_takes_priority():
    local = Symbol(name="start", kind=SymbolKind.FUNCTION, range=Range(0, 4, 0, 9), params=["x"])
    ws = Symbol(name="start", kind=SymbolKind.FUNCTION, range=Range(0, 4, 0, 9), params=["a", "b"])
    result = get_completions([local], workspace_symbols=[ws])
    matches = [item for item in result.items if item.label == "start"]
    assert len(matches) == 1
    assert matches[0].detail == "(x)"  # local wins, not workspace's (a, b)


def test_workspace_excludes_non_exportable_kinds():
    ws_param = Symbol(name="x", kind=SymbolKind.PARAMETER, range=Range(0, 0, 0, 1))
    ws_var = Symbol(name="temp", kind=SymbolKind.VARIABLE, range=Range(0, 0, 0, 4))
    ws_static = Symbol(name="count", kind=SymbolKind.STATIC, range=Range(0, 0, 0, 5))
    result = get_completions([], workspace_symbols=[ws_param, ws_var, ws_static])
    labels = {item.label for item in result.items}
    assert "x" not in labels
    assert "temp" not in labels
    assert "count" not in labels


def test_workspace_symbols_none_same_as_empty():
    local = Symbol(name="foo", kind=SymbolKind.FUNCTION, range=Range(0, 4, 0, 7))
    result_none = get_completions([local], workspace_symbols=None)
    result_default = get_completions([local])
    assert len(result_none.items) == len(result_default.items)
