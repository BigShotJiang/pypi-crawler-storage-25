"""Tests for rename feature."""

from __future__ import annotations


from bcpl_lsp.analysis.scope_resolver import ResolvedFile, ResolvedReference
from bcpl_lsp.analysis.references import Reference, ReferenceContext
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.features.rename import compute_rename_edits, prepare_rename
from bcpl_lsp.parser.ast_nodes import Range


def _make_symbol(name: str, kind: SymbolKind, line: int = 0, col: int = 0, uri: str = "test.b") -> Symbol:
    return Symbol(name=name, kind=kind, range=Range(line, col, line, col + len(name)), uri=uri)


def _make_ref(name: str, line: int, col: int, uri: str = "test.b") -> Reference:
    return Reference(name=name, range=Range(line, col, line, col + len(name)), uri=uri, context=ReferenceContext.OTHER)


class FakeScopeResolver:
    """Minimal scope resolver for testing rename logic."""

    def __init__(self, resolved_files: dict[str, ResolvedFile], at_result: ResolvedReference | None = None):
        self._files = resolved_files
        self._at_result = at_result

    def resolve_at(self, path: str, line: int, col: int) -> ResolvedReference | None:
        return self._at_result

    def resolve(self, path: str) -> ResolvedFile:
        return self._files.get(path, ResolvedFile(path=path))


class FakeWorkspaceIndex:
    def __init__(self, file_paths: list[str]):
        self._files = file_paths

    def files(self) -> list[str]:
        return self._files


def test_prepare_rename_returns_range_for_variable():
    sym = _make_symbol("count", SymbolKind.VARIABLE, line=2, col=4)
    ref = _make_ref("count", line=5, col=10)
    rr = ResolvedReference(reference=ref, symbol=sym)
    resolver = FakeScopeResolver({}, at_result=rr)

    result = prepare_rename(resolver, "test.b", 5, 10)
    assert result is not None
    assert result.start.line == 5
    assert result.start.character == 10


def test_prepare_rename_rejects_section():
    sym = _make_symbol("main", SymbolKind.SECTION, line=0, col=0)
    ref = _make_ref("main", line=0, col=9)
    rr = ResolvedReference(reference=ref, symbol=sym)
    resolver = FakeScopeResolver({}, at_result=rr)

    result = prepare_rename(resolver, "test.b", 0, 9)
    assert result is None


def test_prepare_rename_rejects_unresolved():
    ref = _make_ref("unknown", line=3, col=0)
    rr = ResolvedReference(reference=ref, symbol=None)
    resolver = FakeScopeResolver({}, at_result=rr)

    result = prepare_rename(resolver, "test.b", 3, 0)
    assert result is None


def test_prepare_rename_returns_none_when_no_symbol():
    resolver = FakeScopeResolver({}, at_result=None)
    result = prepare_rename(resolver, "test.b", 0, 0)
    assert result is None


def test_compute_rename_edits_single_file():
    sym = _make_symbol("foo", SymbolKind.FUNCTION, line=0, col=4, uri="test.b")
    ref1 = _make_ref("foo", line=3, col=2)
    ref2 = _make_ref("foo", line=5, col=8)

    rr_at = ResolvedReference(reference=ref1, symbol=sym)
    resolved_file = ResolvedFile(
        path="test.b",
        symbols=[sym],
        resolved_refs=[
            ResolvedReference(reference=ref1, symbol=sym),
            ResolvedReference(reference=ref2, symbol=sym),
        ],
    )

    resolver = FakeScopeResolver({"test.b": resolved_file}, at_result=rr_at)
    index = FakeWorkspaceIndex(["test.b"])

    edit = compute_rename_edits(resolver, index, "test.b", 3, 2, "bar")
    assert edit is not None
    assert "file:///test.b" in edit.changes
    edits = edit.changes["file:///test.b"]
    # Should have edits for: definition (sym) + 2 references
    assert len(edits) == 3
    new_texts = {e.new_text for e in edits}
    assert new_texts == {"bar"}


def test_compute_rename_edits_cross_file():
    sym = _make_symbol("start", SymbolKind.GLOBAL, line=1, col=0, uri="a.b")
    ref_a = _make_ref("start", line=5, col=0)
    ref_b = _make_ref("start", line=2, col=4)

    rr_at = ResolvedReference(reference=ref_a, symbol=sym)

    resolved_a = ResolvedFile(
        path="a.b",
        symbols=[sym],
        resolved_refs=[ResolvedReference(reference=ref_a, symbol=sym)],
    )
    resolved_b = ResolvedFile(
        path="b.b",
        symbols=[],
        resolved_refs=[ResolvedReference(reference=ref_b, symbol=sym)],
    )

    resolver = FakeScopeResolver({"a.b": resolved_a, "b.b": resolved_b}, at_result=rr_at)
    index = FakeWorkspaceIndex(["a.b", "b.b"])

    edit = compute_rename_edits(resolver, index, "a.b", 5, 0, "begin")
    assert edit is not None
    # a.b: definition + reference, b.b: reference
    assert len(edit.changes["file:///a.b"]) == 2
    assert len(edit.changes["file:///b.b"]) == 1


def test_compute_rename_rejects_section():
    sym = _make_symbol("mysec", SymbolKind.SECTION, line=0, col=9)
    ref = _make_ref("mysec", line=0, col=9)
    rr = ResolvedReference(reference=ref, symbol=sym)
    resolver = FakeScopeResolver({}, at_result=rr)
    index = FakeWorkspaceIndex(["test.b"])

    edit = compute_rename_edits(resolver, index, "test.b", 0, 9, "newsec")
    assert edit is None


def test_rename_variable_scoped_to_file():
    """VARIABLE/PARAMETER renames should not cross file boundaries."""
    sym = _make_symbol("x", SymbolKind.VARIABLE, line=1, col=4, uri="a.b")
    ref_a = _make_ref("x", line=3, col=2, uri="a.b")
    # Same-named variable in another file — should NOT be renamed
    sym_b = _make_symbol("x", SymbolKind.VARIABLE, line=0, col=4, uri="b.b")
    ref_b = _make_ref("x", line=2, col=0, uri="b.b")

    rr_at = ResolvedReference(reference=ref_a, symbol=sym)

    resolved_a = ResolvedFile(
        path="a.b",
        symbols=[sym],
        resolved_refs=[ResolvedReference(reference=ref_a, symbol=sym)],
    )
    resolved_b = ResolvedFile(
        path="b.b",
        symbols=[sym_b],
        resolved_refs=[ResolvedReference(reference=ref_b, symbol=sym_b)],
    )

    resolver = FakeScopeResolver({"a.b": resolved_a, "b.b": resolved_b}, at_result=rr_at)
    index = FakeWorkspaceIndex(["a.b", "b.b"])

    edit = compute_rename_edits(resolver, index, "a.b", 3, 2, "y")
    assert edit is not None
    # Only a.b should have edits — b.b's "x" is a different variable
    assert "file:///a.b" in edit.changes
    assert "file:///b.b" not in edit.changes


def test_rename_global_crosses_files():
    """GLOBAL renames should apply across all files."""
    sym = _make_symbol("output", SymbolKind.GLOBAL, line=1, col=0, uri="a.b")
    ref_a = _make_ref("output", line=5, col=0, uri="a.b")
    ref_b = _make_ref("output", line=2, col=4, uri="b.b")

    rr_at = ResolvedReference(reference=ref_a, symbol=sym)

    resolved_a = ResolvedFile(
        path="a.b",
        symbols=[sym],
        resolved_refs=[ResolvedReference(reference=ref_a, symbol=sym)],
    )
    resolved_b = ResolvedFile(
        path="b.b",
        symbols=[],
        resolved_refs=[ResolvedReference(reference=ref_b, symbol=sym)],
    )

    resolver = FakeScopeResolver({"a.b": resolved_a, "b.b": resolved_b}, at_result=rr_at)
    index = FakeWorkspaceIndex(["a.b", "b.b"])

    edit = compute_rename_edits(resolver, index, "a.b", 5, 0, "out")
    assert edit is not None
    assert "file:///a.b" in edit.changes
    assert "file:///b.b" in edit.changes
