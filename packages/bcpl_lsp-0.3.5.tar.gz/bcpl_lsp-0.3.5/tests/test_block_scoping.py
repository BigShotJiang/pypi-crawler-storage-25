"""Tests for $( ... $) block scoping and GOTO labels.

BCPL's $( ... $) is a compound command, NOT a scope boundary.
Variables declared with LET inside a block should be visible
to sibling statements in the same function.

GOTO labels (name:) should be recognized as symbols and not
flagged as unresolved.
"""

from pathlib import Path

from bcpl_lsp.analysis.diagnostics import semantic_diagnostics
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _get_semantic_diagnostics(source: str, tmp_path: Path) -> list:
    """Analyze source with full semantic diagnostics pipeline."""
    # Write file to disk so the indexer can find it
    test_file = tmp_path / "test.b"
    test_file.write_text(source)

    idx = WorkspaceIndex(tmp_path)
    idx.discover()
    idx.ensure_parsed(str(test_file))

    resolver = GetResolver(search_paths=[])
    scope_resolver = ScopeResolver(idx, resolver)
    resolved = scope_resolver.resolve(str(test_file))
    return semantic_diagnostics(resolved, idx.all_symbols())


def test_let_in_block_not_unresolved(tmp_path):
    """Variables declared with LET inside $( ... $) and used in the same block
    should not produce unresolved symbol warnings."""
    source = """\
LET start() BE
$( LET x = 1
   LET y = 2
   writef("%n %n", x, y)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message and d.message.split("'")[1] in ("x", "y")]
    assert len(unresolved) == 0


def test_let_across_nested_blocks_not_unresolved(tmp_path):
    """A variable declared in an outer $( $) and used in an inner $( $) should resolve."""
    source = """\
LET readexp() BE
$( LET relsize = 0
   $( relsize := relsize + 1
   $)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message and "relsize" in d.message]
    assert len(unresolved) == 0


def test_goto_label_not_unresolved(tmp_path):
    """GOTO labels (name:) should not produce unresolved symbol warnings."""
    source = """\
LET readexp() BE
$( LET op = 0
   GOTO done
   done:
   RETURN
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message and "done" in d.message]
    assert len(unresolved) == 0


def test_multiple_labels_not_unresolved(tmp_path):
    """Multiple GOTO labels in a function should all resolve."""
    source = """\
LET process() BE
$( GOTO elab
   elab: writef("elab*n")
   GOTO elb2
   elb2: writef("elb2*n")
   GOTO done
   done: RETURN
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved_labels = [d for d in diags
                         if "nresolved" in d.message
                         and any(label in d.message for label in ("elab", "elb2", "done"))]
    assert len(unresolved_labels) == 0


def test_block_variable_not_flagged_unused(tmp_path):
    """A variable declared in $( $) and used should not be flagged unused."""
    source = """\
LET start() BE
$( LET x = 1
   writef("%n", x)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unused = [d for d in diags if "nused" in d.message and "'x'" in d.message]
    assert len(unused) == 0


def test_multi_name_let_resolved(tmp_path):
    """LET x, y = a, b should define both x and y as separate symbols."""
    source = """\
LET start() BE
$( LET relsize, abssize = 10, 20
   writef("%n %n", relsize, abssize)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message
                  and any(n in d.message for n in ("relsize", "abssize"))]
    assert len(unresolved) == 0, f"Unexpected unresolved: {[d.message for d in unresolved]}"


def test_multi_name_let_five_vars(tmp_path):
    """LET a, b, c, d, e = 1, 2, 3, 4, 5 should define all five variables."""
    source = """\
LET readexp() BE
$( LET et, eval, mop, op, unknown = 0, 0, 0, 1, 0
   writef("%n", et)
   writef("%n", eval)
   writef("%n", mop)
   writef("%n", op)
   writef("%n", unknown)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message
                  and any(n in d.message for n in ("et", "eval", "mop", "op", "unknown"))]
    assert len(unresolved) == 0, f"Unexpected unresolved: {[d.message for d in unresolved]}"


def test_multi_name_let_nested_blocks(tmp_path):
    """Multi-name LET inside nested blocks should resolve in inner blocks."""
    source = """\
LET readexp() BE
$( LET et, eval, mop = 0, 0, 0
   $( LET sval, st = 0, 0
      eval := eval + sval
      et := et + st
      mop := 0
   $)
$)
"""
    diags = _get_semantic_diagnostics(source, tmp_path)
    unresolved = [d for d in diags if "nresolved" in d.message
                  and any(n in d.message for n in ("et", "eval", "mop", "sval", "st"))]
    assert len(unresolved) == 0, f"Unexpected unresolved: {[d.message for d in unresolved]}"
