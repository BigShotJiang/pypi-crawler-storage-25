"""Tests for _uri_filename helper."""

from bcpl_lsp.server import _uri_filename


def test_extracts_filename_from_uri():
    assert _uri_filename("file:///home/paul/projects/test.b") == "test.b"


def test_extracts_filename_from_windows_uri():
    assert _uri_filename("file:///C:/Users/paul/test.b") == "test.b"


def test_bare_filename():
    assert _uri_filename("test.b") == "test.b"


def test_nested_path():
    assert _uri_filename("file:///a/b/c/deep.b") == "deep.b"
