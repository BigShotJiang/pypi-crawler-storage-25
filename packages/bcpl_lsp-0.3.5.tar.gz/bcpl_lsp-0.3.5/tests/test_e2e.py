"""End-to-end tests: source -> analysis -> LSP response structures.

These tests exercise the full pipeline without starting an LSP server.
"""

from pathlib import Path

from lsprotocol import types

from bcpl_lsp.analysis.diagnostics import Severity, semantic_diagnostics
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.features.completion import get_completions
from bcpl_lsp.features.definition import get_definition
from bcpl_lsp.features.hover import get_hover
from bcpl_lsp.features.semantic_tokens import compute_semantic_tokens
from bcpl_lsp.workspace.document import analyze_document
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _setup_workspace(tmp_path: Path, files: dict[str, str]) -> tuple[WorkspaceIndex, ScopeResolver]:
    """Write files, build index + scope resolver, return both."""
    for name, source in files.items():
        (tmp_path / name).write_text(source)
    idx = WorkspaceIndex(tmp_path)
    idx.discover()
    for name in files:
        idx.ensure_parsed(str(tmp_path / name))
    resolver = GetResolver(search_paths=[])
    scope = ScopeResolver(idx, resolver)
    return idx, scope


# --- Hover ---


def test_hover_returns_markdown_for_function(tmp_path):
    source = "LET start(argv) BE argv\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    # 'argv' reference is at col 19
    resolved = scope.resolve_at(str(tmp_path / "test.b"), 0, 19)
    result = get_hover(resolved)

    assert result is not None
    assert isinstance(result, types.Hover)
    assert isinstance(result.contents, types.MarkupContent)
    assert result.contents.kind == types.MarkupKind.Markdown
    assert "argv" in result.contents.value


def test_hover_returns_none_for_empty_position(tmp_path):
    source = "LET start() BE RETURN\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    # Position on the keyword LET, not an identifier reference
    resolved = scope.resolve_at(str(tmp_path / "test.b"), 0, 0)
    result = get_hover(resolved)

    assert result is None


# --- Definition ---


def test_definition_returns_location_for_variable(tmp_path):
    source = "LET start() BE $( LET x = 1; writef(x) $)\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    # Find the reference to 'x' in writef(x) — search resolved refs
    resolved_file = scope.resolve(path)
    x_refs = [rr for rr in resolved_file.resolved_refs if rr.reference.name == "x"]
    assert len(x_refs) > 0, "Expected at least one resolved reference to 'x'"

    result = get_definition(x_refs[0])

    assert result is not None
    assert isinstance(result, types.Location)
    assert result.uri.endswith("test.b") or "test.b" in result.uri
    assert isinstance(result.range, types.Range)
    assert result.range.start.line == 0


def test_definition_returns_none_for_unresolved(tmp_path):
    source = "LET start() BE writef()\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    resolved_file = scope.resolve(path)
    # writef is unresolved (no libhdr)
    assert len(resolved_file.unresolved_refs) > 0
    from bcpl_lsp.analysis.scope_resolver import ResolvedReference

    unresolved_rr = ResolvedReference(reference=resolved_file.unresolved_refs[0], symbol=None)
    result = get_definition(unresolved_rr)

    assert result is None


# --- Completion ---


def test_completion_contains_keywords_and_symbols(tmp_path):
    source = "LET helper(n) = n + 1\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    state = idx.ensure_parsed(path)

    result = get_completions(state.symbols)

    assert isinstance(result, types.CompletionList)
    assert not result.is_incomplete

    labels = {item.label for item in result.items}
    # Should have keywords
    assert "LET" in labels
    assert "IF" in labels
    assert "FOR" in labels
    # Should have the function symbol
    assert "helper" in labels

    # Verify kinds
    keyword_items = [i for i in result.items if i.kind == types.CompletionItemKind.Keyword]
    function_items = [i for i in result.items if i.kind == types.CompletionItemKind.Function]
    assert len(keyword_items) > 0
    assert len(function_items) > 0


def test_completion_includes_workspace_symbols(tmp_path):
    source_a = "LET localfn() BE RETURN\n"
    source_b = 'GLOBAL $( remotefn : 100 $)\n'
    idx, scope = _setup_workspace(tmp_path, {"a.b": source_a, "b.b": source_b})

    state_a = idx.ensure_parsed(str(tmp_path / "a.b"))
    all_syms = idx.all_symbols()

    result = get_completions(state_a.symbols, workspace_symbols=all_syms)

    labels = {item.label for item in result.items}
    assert "localfn" in labels
    assert "remotefn" in labels


# --- Diagnostics pipeline ---


def test_diagnostics_pipeline_produces_correct_structures(tmp_path):
    source = "LET start() BE $( LET unused = 1; RETURN $)\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    resolved_file = scope.resolve(path)
    all_symbols = idx.all_symbols()
    diags = semantic_diagnostics(resolved_file, all_symbols)

    # Should have an unused variable hint for 'unused'
    hints = [d for d in diags if d.severity == Severity.HINT]
    assert len(hints) >= 1
    assert any("unused" in h.message for h in hints)

    # Verify diagnostic structure has valid positions
    for d in diags:
        assert d.line >= 0
        assert d.column >= 0
        assert d.end_line >= d.line


def test_diagnostics_pipeline_parse_errors(tmp_path):
    source = "LET start( BE\n"  # Missing closing paren
    (tmp_path / "test.b").write_text(source)

    state = analyze_document(str(tmp_path / "test.b"), source)

    # Should have parse errors
    assert len(state.diagnostics) > 0
    assert any(d.severity == Severity.ERROR for d in state.diagnostics)


def test_diagnostics_unresolved_symbol(tmp_path):
    source = "LET start() BE writef()\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    resolved_file = scope.resolve(path)
    diags = semantic_diagnostics(resolved_file, [])

    warnings = [d for d in diags if d.severity == Severity.WARNING]
    assert any("writef" in w.message for w in warnings)


# --- Semantic tokens ---


def test_semantic_tokens_nonempty_for_valid_source(tmp_path):
    source = "LET start(argv) BE RETURN\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    state = idx.ensure_parsed(path)

    data = compute_semantic_tokens(state.tokens, scope, path)

    # Should have token data (multiples of 5: deltaLine, deltaCol, len, type, mods)
    assert len(data) > 0
    assert len(data) % 5 == 0


def test_semantic_tokens_without_scope_resolver(tmp_path):
    source = "LET start() BE RETURN\n"
    (tmp_path / "test.b").write_text(source)

    state = analyze_document(str(tmp_path / "test.b"), source)

    data = compute_semantic_tokens(state.tokens, None, str(tmp_path / "test.b"))

    # Should still produce tokens for keywords, etc.
    assert len(data) > 0
    assert len(data) % 5 == 0


def test_semantic_tokens_include_keyword_and_identifier(tmp_path):
    source = "LET myvar = 42\n"
    idx, scope = _setup_workspace(tmp_path, {"test.b": source})

    path = str(tmp_path / "test.b")
    state = idx.ensure_parsed(path)

    data = compute_semantic_tokens(state.tokens, scope, path)

    # At minimum: LET (keyword), myvar (variable/identifier), 42 (number)
    # Each token is 5 ints, so at least 15 values
    assert len(data) >= 15
