"""Tests for per-file search path resolution via system detection."""

from bcpl_lsp.workspace.get_resolver import GetResolver


def _make_system(tmp_path, name, g_files=("libhdr",)):
    """Create a BCPL system directory with a g/ subdir."""
    system_dir = tmp_path / name
    g_dir = system_dir / "g"
    g_dir.mkdir(parents=True)
    for f in g_files:
        (g_dir / f).write_text(f"// header from {name}")
    return system_dir, g_dir


class TestResolverForFile:
    """Test GetResolver.resolver_for_file — picks the right g/ per source file."""

    def test_file_under_system_root(self, tmp_path):
        """A file directly under a system root uses that system's g/."""
        cintcode, cintcode_g = _make_system(tmp_path, "cintcode")
        resolver = GetResolver(search_paths=[cintcode_g])
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(cintcode / "prog.b")
        assert result.search_paths == [cintcode_g]

    def test_file_in_sibling_tree(self, tmp_path):
        """bcplprogs/cobench/cosim.b should use cintcode/g/, not pdp11/g/."""
        # Layout: bcpl-81/cintcode/g/, bcpl-81/bcplprogs/pdp11/g/,
        #         bcpl-81/bcplprogs/cobench/cosim.b
        bcpl81 = tmp_path / "bcpl-81"
        _, cintcode_g = _make_system(bcpl81, "cintcode")
        _, pdp11_g = _make_system(bcpl81 / "bcplprogs", "pdp11")
        cobench = bcpl81 / "bcplprogs" / "cobench"
        cobench.mkdir(parents=True)
        source = cobench / "cosim.b"
        source.write_text('GET "libhdr"')

        resolver = GetResolver()
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(source)
        assert cintcode_g in result.search_paths
        assert pdp11_g not in result.search_paths

    def test_file_under_pdp11_uses_pdp11(self, tmp_path):
        """A file under bcplprogs/pdp11/ should use pdp11/g/."""
        bcpl81 = tmp_path / "bcpl-81"
        _, cintcode_g = _make_system(bcpl81, "cintcode")
        _, pdp11_g = _make_system(bcpl81 / "bcplprogs", "pdp11")
        source = bcpl81 / "bcplprogs" / "pdp11" / "test.b"
        source.write_text('GET "libhdr"')

        resolver = GetResolver()
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(source)
        assert pdp11_g in result.search_paths

    def test_separate_systems_isolated(self, tmp_path):
        """Files in tripos/ use tripos/g/, not bcpl-81/cintcode/g/."""
        _, cintcode_g = _make_system(tmp_path / "bcpl-81", "cintcode")
        _, tripos_g = _make_system(tmp_path, "tripos")
        source = tmp_path / "tripos" / "src" / "main.b"
        source.parent.mkdir(parents=True)
        source.write_text('GET "libhdr"')

        resolver = GetResolver()
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(source)
        assert tripos_g in result.search_paths
        assert cintcode_g not in result.search_paths

    def test_fallback_when_no_system_found(self, tmp_path):
        """A file not near any system gets all discovered g/ dirs."""
        _, cintcode_g = _make_system(tmp_path / "bcpl-81", "cintcode")
        _, tripos_g = _make_system(tmp_path, "tripos")
        stray = tmp_path / "random" / "file.b"
        stray.parent.mkdir(parents=True)
        stray.write_text('GET "libhdr"')

        resolver = GetResolver()
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(stray)
        # Falls back to all discovered paths
        assert len(result.search_paths) >= 2

    def test_no_systems_detected(self, tmp_path):
        """When no g/ dirs exist, resolver_for_file returns self."""
        source = tmp_path / "prog.b"
        source.write_text('GET "libhdr"')

        resolver = GetResolver()
        resolver.detect_systems(tmp_path)

        result = resolver.resolver_for_file(source)
        assert result is resolver

    def test_explicit_search_paths_bypass_detection(self, tmp_path):
        """When explicit search paths are set, detection is skipped."""
        _, cintcode_g = _make_system(tmp_path / "bcpl-81", "cintcode")
        custom_g = tmp_path / "custom" / "g"
        custom_g.mkdir(parents=True)

        resolver = GetResolver(search_paths=[custom_g])
        # Don't call detect_systems — explicit paths

        result = resolver.resolver_for_file(tmp_path / "anything.b")
        assert result is resolver  # Uses the resolver as-is
