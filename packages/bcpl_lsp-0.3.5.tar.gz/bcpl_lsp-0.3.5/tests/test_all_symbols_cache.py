"""Tests for WorkspaceIndex.all_symbols() caching."""

from pathlib import Path

from bcpl_lsp.workspace.indexer import WorkspaceIndex

FIXTURES = Path(__file__).parent / "fixtures" / "workspace"


def test_all_symbols_returns_symbols_from_parsed_files():
    idx = WorkspaceIndex(FIXTURES)
    idx.discover()
    # Parse a file to populate symbols
    main_path = str(FIXTURES / "main.b")
    idx.ensure_parsed(main_path)
    symbols = idx.all_symbols()
    names = {s.name for s in symbols}
    assert len(symbols) > 0
    assert "start" in names


def test_all_symbols_cache_invalidated_on_update():
    idx = WorkspaceIndex(FIXTURES)
    idx.discover()
    main_path = str(FIXTURES / "main.b")
    idx.ensure_parsed(main_path)

    first = idx.all_symbols()
    # Update with new source that defines a different symbol
    idx.update(main_path, 'LET newfunction() BE RETURN\n')
    second = idx.all_symbols()

    first_names = {s.name for s in first}
    second_names = {s.name for s in second}
    assert "start" in first_names
    assert "newfunction" in second_names
    assert "start" not in second_names


def test_all_symbols_cache_invalidated_on_remove():
    idx = WorkspaceIndex(FIXTURES)
    idx.discover()
    main_path = str(FIXTURES / "main.b")
    idx.ensure_parsed(main_path)

    before = idx.all_symbols()
    assert len(before) > 0

    idx.remove(main_path)
    after = idx.all_symbols()
    # Symbols from main.b should be gone
    after_names = {s.name for s in after}
    assert "start" not in after_names


def test_all_symbols_returns_empty_when_no_files_parsed():
    idx = WorkspaceIndex(FIXTURES)
    idx.discover()
    # Don't parse anything
    symbols = idx.all_symbols()
    assert symbols == []
