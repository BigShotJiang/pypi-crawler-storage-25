"""textDocument/completion handler for BCPL."""

from __future__ import annotations

from lsprotocol import types

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.parser.tokens import KEYWORDS

# Snippet templates for common BCPL patterns
KEYWORD_SNIPPETS: dict[str, tuple[str, str]] = {
    "LET": ("LET ${1:name}(${2:args}) BE\n${\n  $0\n$}", "Define a function"),
    "IF": ("IF ${1:condition} THEN\n  $0", "If-then statement"),
    "TEST": ("TEST ${1:condition}\nTHEN $2\nELSE $0", "Test-then-else statement"),
    "FOR": ("FOR ${1:i} = ${2:start} TO ${3:end} DO\n  $0", "For loop"),
    "WHILE": ("WHILE ${1:condition} DO\n  $0", "While loop"),
    "SWITCHON": ("SWITCHON ${1:expr} INTO\n$(\n  CASE ${2:val}: $0\n  ENDCASE\n$)", "Switch statement"),
    "VALOF": ("VALOF\n$(\n  $0\n  RESULTIS ${1:result}\n$)", "Value-of block"),
    "GLOBAL": ("GLOBAL $(\n  ${1:name} : ${2:number}\n$)", "Global declarations"),
    "MANIFEST": ("MANIFEST $(\n  ${1:name} = ${2:value}\n$)", "Manifest constants"),
    "STATIC": ("STATIC $(\n  ${1:name} = ${2:value}\n$)", "Static variables"),
    "GET": ('GET "${1:libhdr}"', "Include a file"),
    "SECTION": ('SECTION "${1:name}"', "Section declaration"),
}

SYMBOL_KIND_TO_COMPLETION: dict[SymbolKind, types.CompletionItemKind] = {
    SymbolKind.FUNCTION: types.CompletionItemKind.Function,
    SymbolKind.VARIABLE: types.CompletionItemKind.Variable,
    SymbolKind.CONSTANT: types.CompletionItemKind.Constant,
    SymbolKind.GLOBAL: types.CompletionItemKind.Variable,
    SymbolKind.STATIC: types.CompletionItemKind.Variable,
    SymbolKind.PARAMETER: types.CompletionItemKind.Variable,
    SymbolKind.SECTION: types.CompletionItemKind.Module,
}


_WORKSPACE_EXPORTABLE_KINDS = frozenset({
    SymbolKind.GLOBAL,
    SymbolKind.CONSTANT,
    SymbolKind.FUNCTION,
})


def get_completions(
    symbols: list[Symbol],
    workspace_symbols: list[Symbol] | None = None,
) -> types.CompletionList:
    """Build completion list from keywords and document symbols.

    If *workspace_symbols* is provided, GLOBAL, CONSTANT and FUNCTION symbols
    from other files are merged in.  Local symbols take priority when names
    collide.
    """
    # Merge workspace symbols, deduplicating by name (locals win).
    if workspace_symbols:
        local_names = {s.name for s in symbols}
        merged = list(symbols)
        for ws in workspace_symbols:
            if ws.name not in local_names and ws.kind in _WORKSPACE_EXPORTABLE_KINDS:
                merged.append(ws)
        symbols = merged

    items: list[types.CompletionItem] = []

    # Keywords
    for kw in KEYWORDS:
        snippet = KEYWORD_SNIPPETS.get(kw)
        if snippet:
            insert_text, detail = snippet
            items.append(types.CompletionItem(
                label=kw,
                kind=types.CompletionItemKind.Keyword,
                detail=detail,
                insert_text=insert_text,
                insert_text_format=types.InsertTextFormat.Snippet,
            ))
        else:
            items.append(types.CompletionItem(
                label=kw,
                kind=types.CompletionItemKind.Keyword,
            ))

    # Document symbols
    for sym in symbols:
        if sym.kind == SymbolKind.SECTION:
            continue
        detail = ""
        if sym.kind == SymbolKind.FUNCTION and sym.params:
            detail = f"({', '.join(sym.params)})"
        elif sym.kind == SymbolKind.GLOBAL and sym.global_number is not None:
            detail = f": {sym.global_number}"
        items.append(types.CompletionItem(
            label=sym.name,
            kind=SYMBOL_KIND_TO_COMPLETION.get(sym.kind, types.CompletionItemKind.Text),
            detail=detail,
        ))

    return types.CompletionList(is_incomplete=False, items=items)
