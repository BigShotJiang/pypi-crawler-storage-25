"""textDocument/hover handler for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer
from pygls.uris import to_fs_path


from bcpl_lsp.analysis.scope_resolver import ResolvedReference
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind


log = logging.getLogger("bcpl-lsp")


def _uri_filename(uri: str) -> str:
    """Extract filename from a URI for log messages."""
    return uri.rsplit("/", 1)[-1]


def _format_hover(sym: Symbol) -> str:
    """Build Markdown hover content for a symbol."""
    lines: list[str] = []

    if sym.kind == SymbolKind.FUNCTION:
        sig = f"LET {sym.name}"
        if sym.params:
            sig += f"({', '.join(sym.params)})"
        sig += " = ..."
        lines.append(f"```bcpl\n{sig}\n```")
        if sym.global_number is not None:
            lines.append(f"GLOBAL slot: {sym.global_number}")

    elif sym.kind == SymbolKind.CONSTANT:
        if sym.value_text is not None:
            lines.append(f"```bcpl\n{sym.name} = {sym.value_text}\n```")
        else:
            lines.append(f"```bcpl\n{sym.name}\n```")
        lines.append("MANIFEST constant")

    elif sym.kind == SymbolKind.GLOBAL:
        slot = sym.global_number if sym.global_number is not None else "?"
        lines.append(f"```bcpl\n{sym.name} : {slot}\n```")
        lines.append("GLOBAL entry")
        if sym.uri:
            lines.append(f"Defined in `{_uri_filename(sym.uri)}`")

    elif sym.kind == SymbolKind.STATIC:
        lines.append(f"```bcpl\n{sym.name}\n```")
        lines.append("STATIC variable")

    elif sym.kind == SymbolKind.PARAMETER:
        lines.append(f"```bcpl\n{sym.name}\n```")
        lines.append("Parameter")

    elif sym.kind == SymbolKind.VARIABLE:
        lines.append(f"```bcpl\n{sym.name}\n```")
        lines.append("Local variable")

    elif sym.kind == SymbolKind.SECTION:
        lines.append(f"```bcpl\nSECTION \"{sym.name}\"\n```")

    else:
        lines.append(f"`{sym.name}`")

    return "\n\n".join(lines)


def get_hover(resolved: ResolvedReference | None) -> types.Hover | None:
    """Return Hover content for a resolved reference, or None."""
    if resolved is None or resolved.symbol is None:
        return None

    content = _format_hover(resolved.symbol)
    r = resolved.reference.range
    return types.Hover(
        contents=types.MarkupContent(
            kind=types.MarkupKind.Markdown,
            value=content,
        ),
        range=types.Range(
            start=types.Position(line=r.start_line, character=r.start_col),
            end=types.Position(line=r.end_line, character=r.end_col),
        ),
    )


def register(server: LanguageServer) -> None:
    """Register the textDocument/hover handler."""

    @server.feature(types.TEXT_DOCUMENT_HOVER)
    def hover(
        ls: LanguageServer, params: types.HoverParams
    ) -> types.Hover | None:
        try:
            from bcpl_lsp.server import _doc_states, _scope_resolver

            uri = params.text_document.uri
            if uri not in _doc_states or _scope_resolver is None:
                return None

            path = to_fs_path(uri)
            if path is None:
                return None
            line = params.position.line
            col = params.position.character

            resolved = _scope_resolver.resolve_at(path, line, col)
            result = get_hover(resolved)
            sym_name = resolved.symbol.name if resolved and resolved.symbol else "?"
            log.info("Hover: %s:%d:%d → %s", _uri_filename(uri), line, col, sym_name)
            return result
        except Exception:
            log.debug("hover failed", exc_info=True)
            return None
