"""GET directive resolution for BCPL's include system."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from bcpl_lsp.parser.ast_nodes import GetDirective, Node, Section
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser

log = logging.getLogger("bcpl-lsp")


@dataclass
class BcplSystem:
    """A detected BCPL system with its own header directory."""

    root: Path
    g_dir: Path


class GetResolver:
    """Resolves ``GET "filename"`` directives to filesystem paths.

    Search order:
    1. Same directory as the source file.
    2. Each directory in *search_paths* (e.g. the ``g/`` headers directory).

    Matching is case-insensitive.  Extensionless names are tried as-is,
    then with ``.b`` and ``.bcpl`` appended.
    """

    def __init__(self, search_paths: list[Path] | None = None) -> None:
        """
        Parameters
        ----------
        search_paths:
            Ordered list of directories to search after the source directory.
        """
        self._search_paths: list[Path] = list(search_paths or [])
        self._systems: list[BcplSystem] = []

    @property
    def search_paths(self) -> list[Path]:
        return list(self._search_paths)

    def set_search_paths(self, paths: list[Path]) -> None:
        """Replace the current search paths."""
        self._search_paths = list(paths)

    # -- System detection & per-file resolution --

    def detect_systems(self, workspace_root: Path) -> None:
        """Discover BCPL systems by finding ``g/`` directories under *workspace_root*.

        Each ``g/`` directory's parent is treated as a "system root".
        """
        self._systems = []
        try:
            for child in sorted(workspace_root.rglob("g")):
                if child.is_dir() and child.name == "g":
                    system = BcplSystem(root=child.parent, g_dir=child)
                    self._systems.append(system)
                    log.info("Detected BCPL system: %s (headers: %s)", system.root, system.g_dir)
        except OSError:
            pass
        log.info("Detected %d BCPL system(s)", len(self._systems))

    def resolver_for_file(self, file_path: Path) -> GetResolver:
        """Return a ``GetResolver`` scoped to the BCPL system that owns *file_path*.

        Algorithm:
        1. If no systems detected (or explicit search_paths set without
           detection), return *self*.
        2. Find systems whose root is a direct ancestor of *file_path*.
           Pick the deepest (most specific) match.
        3. If no direct ancestor match, walk up from *file_path* and at each
           level check for sibling directories that are system roots. Pick the
           first found (nearest).
        4. Fall back to a resolver with all discovered ``g/`` directories.
        """
        if not self._systems:
            return self

        resolved_path = file_path.resolve()

        # Step 2: direct ancestor — deepest system root wins
        best: BcplSystem | None = None
        best_depth = -1
        for system in self._systems:
            try:
                resolved_path.relative_to(system.root.resolve())
                depth = len(system.root.resolve().parts)
                if depth > best_depth:
                    best = system
                    best_depth = depth
            except ValueError:
                continue

        if best is not None:
            return GetResolver(search_paths=[best.g_dir])

        # Step 3: walk up ancestors of the file.  At each ancestor, check
        # its sibling directories for system roots.  Start from the
        # grandparent level so we skip peer subsystems (e.g. pdp11/ as
        # sibling of cobench/) and find parent systems (e.g. cintcode/
        # as sibling of bcplprogs/).
        system_roots = {s.root.resolve(): s for s in self._systems}
        # Start one level above the file's directory
        current = resolved_path.parent.parent
        workspace_boundary = min(
            (s.root.resolve() for s in self._systems),
            key=lambda p: len(p.parts),
        ).parent

        while current != workspace_boundary.parent and current != current.parent:
            parent = current.parent
            if parent.is_dir():
                try:
                    for sibling in parent.iterdir():
                        if sibling.resolve() == current.resolve():
                            continue
                        if sibling.is_dir() and sibling.resolve() in system_roots:
                            system = system_roots[sibling.resolve()]
                            return GetResolver(search_paths=[system.g_dir])
                except OSError:
                    pass
            current = parent

        # Step 4: fallback — all discovered g/ dirs
        all_g = [s.g_dir for s in self._systems]
        return GetResolver(search_paths=all_g)

    def resolve(self, filename: str, from_file: Path) -> Path | None:
        """Resolve a single GET filename relative to *from_file*.

        Returns the resolved ``Path`` or ``None`` if not found.
        """
        dirs = [from_file.parent] + self._search_paths
        candidates = [filename]
        if "." not in Path(filename).name:
            candidates.append(filename + ".b")
            candidates.append(filename + ".h")
            candidates.append(filename + ".bcpl")

        for search_dir in dirs:
            if not search_dir.is_dir():
                continue
            for candidate in candidates:
                match = self._find_case_insensitive(search_dir, candidate)
                if match is not None:
                    return match
        return None

    @staticmethod
    def _find_case_insensitive(base: Path, name: str) -> Path | None:
        """Walk path components case-insensitively from *base*."""
        parts = Path(name).parts
        current = base
        for part in parts:
            if not current.is_dir():
                return None
            try:
                children = {c.name.lower(): c for c in current.iterdir()}
            except OSError:
                return None
            match = children.get(part.lower())
            if match is None:
                return None
            current = match
        if current.is_file():
            return current
        return None

    def resolve_chain(self, file_path: Path) -> list[Path]:
        """Return the ordered list of all files transitively included by *file_path*.

        The result includes *file_path* itself as the first element.
        Circular GET chains are detected and broken (the cycle-closing
        file is not included a second time).
        """
        result: list[Path] = []
        seen: set[Path] = set()

        def _walk(fp: Path) -> None:
            resolved = fp.resolve()
            if resolved in seen:
                return
            seen.add(resolved)
            result.append(fp)

            try:
                source = fp.read_text(encoding="utf-8", errors="replace")
            except OSError:
                return

            lexer = Lexer(source)
            tokens = lexer.tokenize()
            parser = Parser(tokens)
            ast = parser.parse()

            _collect_gets(ast.declarations, fp)

        def _collect_gets(nodes: list[Node], fp: Path) -> None:
            for node in nodes:
                if isinstance(node, GetDirective) and node.filename:
                    target = self.resolve(node.filename, fp)
                    if target is not None:
                        _walk(target)
                elif isinstance(node, Section):
                    _collect_gets(node.declarations, fp)

        _walk(file_path)
        return result
