"""Diagnostic generation for BCPL."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.parser.errors import ParseError

if TYPE_CHECKING:
    from bcpl_lsp.analysis.scope_resolver import ResolvedFile


class Severity(Enum):
    ERROR = auto()
    WARNING = auto()
    INFO = auto()
    HINT = auto()


@dataclass(frozen=True, slots=True)
class Diagnostic:
    message: str
    severity: Severity
    line: int
    column: int
    end_line: int
    end_column: int


def diagnostics_from_parse_errors(errors: list[ParseError]) -> list[Diagnostic]:
    """Convert parse errors to diagnostics."""
    return [
        Diagnostic(
            message=e.message,
            severity=Severity.ERROR,
            line=e.line,
            column=e.column,
            end_line=e.end_line,
            end_column=e.end_column,
        )
        for e in errors
    ]


def semantic_diagnostics(
    resolved_file: ResolvedFile,
    all_symbols: list[Symbol],
) -> list[Diagnostic]:
    """Produce semantic diagnostics from resolved analysis.

    Checks performed:
    - WARNING: Unresolved symbol references
    - ERROR: Duplicate GLOBAL slot numbers
    - HINT: Unused local variables
    - INFO: Missing GET directive suggestions
    """
    diags: list[Diagnostic] = []
    diags.extend(_unresolved_warnings(resolved_file))
    diags.extend(_duplicate_global_warnings(resolved_file.symbols))
    diags.extend(_unused_local_hints(resolved_file))
    diags.extend(_missing_get_suggestions(resolved_file, all_symbols))
    return diags


def _unresolved_warnings(resolved_file: ResolvedFile) -> list[Diagnostic]:
    """WARNING for each unresolved symbol reference."""
    diags: list[Diagnostic] = []
    for ref in resolved_file.unresolved_refs:
        diags.append(Diagnostic(
            message=f"Unresolved symbol '{ref.name}'",
            severity=Severity.WARNING,
            line=ref.range.start_line,
            column=ref.range.start_col,
            end_line=ref.range.end_line,
            end_column=ref.range.end_col,
        ))
    return diags


def _duplicate_global_warnings(file_symbols: list[Symbol]) -> list[Diagnostic]:
    """WARNING when two symbols in the same file/GET-chain claim the same GLOBAL slot.

    Only checks within a single compilation unit (the file and its GET chain),
    not across the whole workspace — different programs legitimately reuse
    user global slots (150+).
    """
    slot_seen: dict[int, Symbol] = {}
    diags: list[Diagnostic] = []
    for sym in file_symbols:
        if sym.kind != SymbolKind.GLOBAL or sym.global_number is None:
            continue
        slot = sym.global_number
        if slot in slot_seen:
            first = slot_seen[slot]
            # Same name in different files (e.g. multiple libhdr copies) is harmless
            if first.name == sym.name:
                continue
            diags.append(Diagnostic(
                message=f"Duplicate GLOBAL slot {slot} (also declared as '{first.name}')",
                severity=Severity.WARNING,
                line=sym.range.start_line,
                column=sym.range.start_col,
                end_line=sym.range.end_line,
                end_column=sym.range.end_col,
            ))
        else:
            slot_seen[slot] = sym
    return diags


def _unused_local_hints(resolved_file: ResolvedFile) -> list[Diagnostic]:
    """HINT for local variables/parameters declared but never referenced."""
    local_kinds = {SymbolKind.VARIABLE, SymbolKind.PARAMETER}

    # Collect names that are referenced (both resolved and unresolved)
    referenced_names: set[str] = set()
    for rr in resolved_file.resolved_refs:
        referenced_names.add(rr.reference.name)
    for ref in resolved_file.unresolved_refs:
        referenced_names.add(ref.name)

    # Skip names that appear more than once as locals — with flat name-based
    # resolution we can't tell which declaration is actually used, so it's
    # better to miss a hint than to give a false one.
    name_counts: dict[str, int] = {}
    for sym in resolved_file.symbols:
        if sym.kind in local_kinds:
            name_counts[sym.name] = name_counts.get(sym.name, 0) + 1
    ambiguous_names = {n for n, c in name_counts.items() if c > 1}

    diags: list[Diagnostic] = []
    for sym in resolved_file.symbols:
        if sym.kind not in local_kinds:
            continue
        if sym.name in ambiguous_names:
            continue
        if sym.name not in referenced_names:
            diags.append(Diagnostic(
                message=f"Unused local variable '{sym.name}'",
                severity=Severity.HINT,
                line=sym.range.start_line,
                column=sym.range.start_col,
                end_line=sym.range.end_line,
                end_column=sym.range.end_col,
            ))
    return diags


def _missing_get_suggestions(
    resolved_file: ResolvedFile,
    all_symbols: list[Symbol],
) -> list[Diagnostic]:
    """INFO when an unresolved symbol exists in a known header file."""
    # Build lookup: symbol name -> uri of the file providing it
    available: dict[str, str] = {}
    for sym in all_symbols:
        if sym.uri and sym.uri != resolved_file.path:
            available[sym.name] = sym.uri

    diags: list[Diagnostic] = []
    for ref in resolved_file.unresolved_refs:
        if ref.name in available:
            source_uri = available[ref.name]
            diags.append(Diagnostic(
                message=f"'{ref.name}' is defined in '{source_uri}' — consider adding a GET directive",
                severity=Severity.INFO,
                line=ref.range.start_line,
                column=ref.range.start_col,
                end_line=ref.range.end_line,
                end_column=ref.range.end_col,
            ))
    return diags
