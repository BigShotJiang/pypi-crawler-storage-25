"""AST node definitions for BCPL."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class Range:
    start_line: int
    start_col: int
    end_line: int
    end_col: int


@dataclass(slots=True)
class Node:
    range: Range


# Top-level
@dataclass(slots=True)
class Program(Node):
    declarations: list[Node] = field(default_factory=list)


@dataclass(slots=True)
class Section(Node):
    name: str = ""
    declarations: list[Node] = field(default_factory=list)


@dataclass(slots=True)
class GetDirective(Node):
    filename: str = ""


@dataclass(slots=True)
class NeedsDirective(Node):
    name: str = ""


# Declarations
@dataclass(slots=True)
class LetDecl(Node):
    name: str = ""
    names: list[str] = field(default_factory=list)
    params: list[str] = field(default_factory=list)
    is_function: bool = False
    body: Node | None = None


@dataclass(slots=True)
class AndDecl(Node):
    """Simultaneous declaration (AND keyword after LET)."""
    name: str = ""
    names: list[str] = field(default_factory=list)
    params: list[str] = field(default_factory=list)
    is_function: bool = False
    body: Node | None = None


@dataclass(slots=True)
class GlobalBlock(Node):
    entries: list[GlobalEntry] = field(default_factory=list)


@dataclass(slots=True)
class GlobalEntry(Node):
    name: str = ""
    number: int | None = None


@dataclass(slots=True)
class ManifestBlock(Node):
    entries: list[ManifestEntry] = field(default_factory=list)


@dataclass(slots=True)
class ManifestEntry(Node):
    name: str = ""
    value: Node | None = None


@dataclass(slots=True)
class StaticBlock(Node):
    entries: list[StaticEntry] = field(default_factory=list)


@dataclass(slots=True)
class StaticEntry(Node):
    name: str = ""
    value: Node | None = None


# Statements
@dataclass(slots=True)
class LabelStmt(Node):
    name: str = ""
    body: Node | None = None


@dataclass(slots=True)
class Block(Node):
    statements: list[Node] = field(default_factory=list)


@dataclass(slots=True)
class IfStmt(Node):
    condition: Node | None = None
    then_body: Node | None = None
    else_body: Node | None = None


@dataclass(slots=True)
class TestStmt(Node):
    condition: Node | None = None
    then_body: Node | None = None
    else_body: Node | None = None


@dataclass(slots=True)
class WhileStmt(Node):
    condition: Node | None = None
    body: Node | None = None


@dataclass(slots=True)
class UntilStmt(Node):
    condition: Node | None = None
    body: Node | None = None


@dataclass(slots=True)
class ForStmt(Node):
    var: str = ""
    start: Node | None = None
    end: Node | None = None
    step: Node | None = None
    body: Node | None = None


@dataclass(slots=True)
class RepeatStmt(Node):
    body: Node | None = None


@dataclass(slots=True)
class RepeatWhileStmt(Node):
    body: Node | None = None
    condition: Node | None = None


@dataclass(slots=True)
class RepeatUntilStmt(Node):
    body: Node | None = None
    condition: Node | None = None


@dataclass(slots=True)
class SwitchStmt(Node):
    expr: Node | None = None
    body: Node | None = None


@dataclass(slots=True)
class CaseLabel(Node):
    value: Node | None = None


@dataclass(slots=True)
class DefaultLabel(Node):
    pass


@dataclass(slots=True)
class ReturnStmt(Node):
    pass


@dataclass(slots=True)
class ResultIsStmt(Node):
    value: Node | None = None


@dataclass(slots=True)
class BreakStmt(Node):
    pass


@dataclass(slots=True)
class LoopStmt(Node):
    pass


@dataclass(slots=True)
class EndcaseStmt(Node):
    pass


@dataclass(slots=True)
class Assignment(Node):
    target: Node | None = None
    value: Node | None = None


# Expressions
@dataclass(slots=True)
class BinaryExpr(Node):
    op: str = ""
    left: Node | None = None
    right: Node | None = None


@dataclass(slots=True)
class UnaryExpr(Node):
    op: str = ""
    operand: Node | None = None


@dataclass(slots=True)
class CondExpr(Node):
    """Conditional expression: expr -> expr, expr"""
    condition: Node | None = None
    then_expr: Node | None = None
    else_expr: Node | None = None


@dataclass(slots=True)
class CallExpr(Node):
    func: Node | None = None
    args: list[Node] = field(default_factory=list)


@dataclass(slots=True)
class IndexExpr(Node):
    """Vector indexing: expr!expr"""
    base: Node | None = None
    index: Node | None = None


@dataclass(slots=True)
class FieldExpr(Node):
    """Byte/field access: expr%expr"""
    base: Node | None = None
    offset: Node | None = None


@dataclass(slots=True)
class ValofExpr(Node):
    body: Node | None = None


@dataclass(slots=True)
class VecExpr(Node):
    size: Node | None = None


@dataclass(slots=True)
class TableExpr(Node):
    values: list[Node] = field(default_factory=list)


@dataclass(slots=True)
class IdentExpr(Node):
    name: str = ""


@dataclass(slots=True)
class NumberLit(Node):
    value: str = ""


@dataclass(slots=True)
class StringLit(Node):
    value: str = ""


@dataclass(slots=True)
class CharLit(Node):
    value: str = ""


@dataclass(slots=True)
class BoolLit(Node):
    value: bool = False


@dataclass(slots=True)
class ErrorNode(Node):
    message: str = ""
