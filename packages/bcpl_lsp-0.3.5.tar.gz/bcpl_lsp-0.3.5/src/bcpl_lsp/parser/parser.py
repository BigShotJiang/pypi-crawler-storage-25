"""Recursive descent parser for BCPL.

Targets Martin Richards' canonical BCPL grammar where:
- IF uses DO (not THEN): IF expr DO command
- TEST uses THEN/ELSE: TEST expr THEN command ELSE command
- REPEAT/REPEATWHILE/REPEATUNTIL are postfix on commands
- Multiple variables: LET x, y = a, b
- Multiple assignment: x, y := a, b
"""

from __future__ import annotations

from .ast_nodes import (
    AndDecl,
    Assignment,
    BinaryExpr,
    Block,
    BoolLit,
    BreakStmt,
    CallExpr,
    CaseLabel,
    CharLit,
    CondExpr,
    DefaultLabel,
    EndcaseStmt,
    ErrorNode,
    FieldExpr,
    ForStmt,
    GetDirective,
    GlobalBlock,
    GlobalEntry,
    IdentExpr,
    IfStmt,
    IndexExpr,
    LabelStmt,
    LetDecl,
    LoopStmt,
    ManifestBlock,
    ManifestEntry,
    NeedsDirective,
    Node,
    NumberLit,
    Program,
    Range,
    RepeatStmt,
    RepeatUntilStmt,
    RepeatWhileStmt,
    ResultIsStmt,
    ReturnStmt,
    Section,
    StaticBlock,
    StaticEntry,
    StringLit,
    SwitchStmt,
    TableExpr,
    TestStmt,
    UnaryExpr,
    UntilStmt,
    ValofExpr,
    VecExpr,
    WhileStmt,
)
from .errors import ParseError
from .tokens import Token, TokenType

# Keywords that start top-level constructs (sync points for error recovery)
SYNC_TOKENS = {
    TokenType.LET,
    TokenType.AND,
    TokenType.SECTION,
    TokenType.GLOBAL,
    TokenType.MANIFEST,
    TokenType.STATIC,
    TokenType.GET,
    TokenType.NEEDS,
    TokenType.DOT,
    TokenType.EOF,
}

# Tokens that can start a command (used for optional DO in FOR)
COMMAND_STARTERS = {
    TokenType.LBRACE, TokenType.IF, TokenType.UNLESS, TokenType.TEST, TokenType.WHILE,
    TokenType.UNTIL, TokenType.FOR, TokenType.SWITCHON, TokenType.CASE,
    TokenType.DEFAULT, TokenType.RETURN, TokenType.RESULTIS, TokenType.BREAK,
    TokenType.LOOP, TokenType.ENDCASE, TokenType.LET, TokenType.IDENT,
    TokenType.LPAREN, TokenType.BANG, TokenType.PERCENT, TokenType.AT,
    TokenType.MINUS, TokenType.PLUS, TokenType.ABS, TokenType.NOT,
    TokenType.BITNOT, TokenType.NUMBER, TokenType.STRING, TokenType.CHARCONST,
    TokenType.TRUE, TokenType.FALSE, TokenType.VALOF, TokenType.VEC,
    TokenType.TABLE,
}


class Parser:
    """Recursive descent parser for BCPL with error recovery."""

    def __init__(self, tokens: list[Token]) -> None:
        # Filter out comments and newlines for parsing
        self.tokens = [t for t in tokens if t.type not in (TokenType.COMMENT, TokenType.NEWLINE)]
        self.pos = 0
        self.errors: list[ParseError] = []
        # Keep all tokens (including comments) for analysis
        self.all_tokens = tokens
        # When True, IF should not consume ELSE (it belongs to an outer TEST)
        self._in_test_body = False

    def _cur(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # EOF

    def _peek_type(self) -> TokenType:
        return self._cur().type

    def _at(self, *types: TokenType) -> bool:
        return self._peek_type() in types

    def _advance(self) -> Token:
        tok = self._cur()
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return tok

    def _expect(self, type: TokenType) -> Token:
        if self._at(type):
            return self._advance()
        tok = self._cur()
        self._error(f"expected {type.name}, got {tok.type.name} '{tok.text}'")
        return tok

    def _expect_one_of(self, *types: TokenType) -> Token:
        """Expect one of several token types."""
        if self._at(*types):
            return self._advance()
        tok = self._cur()
        names = "/".join(t.name for t in types)
        self._error(f"expected {names}, got {tok.type.name} '{tok.text}'")
        return tok

    def _error(self, message: str) -> None:
        tok = self._cur()
        self.errors.append(ParseError(
            message=message,
            line=tok.line,
            column=tok.column,
            end_line=tok.line,
            end_column=tok.column + len(tok.text),
        ))

    def _range_from(self, start: Token) -> Range:
        end = self.tokens[max(0, self.pos - 1)]
        return Range(
            start_line=start.line,
            start_col=start.column,
            end_line=end.line,
            end_col=end.column + len(end.text),
        )

    def _sync(self) -> None:
        """Skip tokens until we reach a synchronization point."""
        while not self._at(TokenType.EOF) and self._peek_type() not in SYNC_TOKENS:
            self._advance()

    # ── Top level ──────────────────────────────────────────────

    def parse(self) -> Program:
        start = self._cur()
        decls: list[Node] = []

        while not self._at(TokenType.EOF):
            decl = self._parse_top_level()
            if decl is not None:
                decls.append(decl)

        return Program(range=self._range_from(start), declarations=decls)

    def _parse_top_level(self) -> Node | None:
        tt = self._peek_type()

        if tt == TokenType.DOT:
            self._advance()  # consume the '.'
            return self._parse_top_level()  # expect SECTION or other top-level to follow
        if tt == TokenType.SECTION:
            return self._parse_section()
        if tt == TokenType.GET:
            return self._parse_get()
        if tt == TokenType.NEEDS:
            return self._parse_needs()
        if tt == TokenType.LET:
            return self._parse_let_decl()
        if tt == TokenType.AND:
            return self._parse_and_decl()
        if tt == TokenType.GLOBAL:
            return self._parse_global()
        if tt == TokenType.MANIFEST:
            return self._parse_manifest()
        if tt == TokenType.STATIC:
            return self._parse_static()

        self._error(f"unexpected token '{self._cur().text}' at top level")
        self._sync()
        return None

    def _parse_section(self) -> Section:
        start = self._advance()  # SECTION
        name = ""
        if self._at(TokenType.STRING):
            name = self._advance().text.strip('"')
        decls: list[Node] = []
        while not self._at(TokenType.EOF, TokenType.SECTION, TokenType.DOT):
            decl = self._parse_top_level()
            if decl is not None:
                decls.append(decl)
        return Section(range=self._range_from(start), name=name, declarations=decls)

    def _parse_get(self) -> GetDirective:
        start = self._advance()  # GET
        filename = ""
        if self._at(TokenType.STRING):
            filename = self._advance().text.strip('"')
        return GetDirective(range=self._range_from(start), filename=filename)

    def _parse_needs(self) -> NeedsDirective:
        start = self._advance()  # NEEDS
        name = ""
        if self._at(TokenType.STRING):
            name = self._advance().text.strip('"')
        return NeedsDirective(range=self._range_from(start), name=name)

    # ── Declarations ──────────────────────────────────────────

    def _parse_let_decl(self) -> LetDecl:
        start = self._advance()  # LET
        return self._parse_decl_body(start, LetDecl)

    def _parse_and_decl(self) -> AndDecl:
        start = self._advance()  # AND
        return self._parse_decl_body(start, AndDecl)

    def _parse_decl_body(self, start: Token, cls: type) -> LetDecl | AndDecl:
        name = ""
        names: list[str] = []
        params: list[str] = []

        if self._at(TokenType.IDENT):
            name = self._advance().text
            names.append(name)
        else:
            self._error("expected identifier after LET/AND")

        # Check for multiple variable names: LET x, y, z = ...
        # Only consume commas if the next token is an identifier and this pattern
        # continues to = (not a function call pattern)
        while self._at(TokenType.COMMA) and self._is_multi_name_decl():
            self._advance()  # ,
            if self._at(TokenType.IDENT):
                names.append(self._advance().text)

        # Parse parameter list for functions
        if self._at(TokenType.LPAREN):
            self._advance()  # (
            while not self._at(TokenType.RPAREN, TokenType.EOF):
                if self._at(TokenType.IDENT):
                    params.append(self._advance().text)
                if self._at(TokenType.COMMA):
                    self._advance()
                elif not self._at(TokenType.RPAREN):
                    break
            self._expect(TokenType.RPAREN)

        is_function = len(params) > 0
        body: Node | None = None

        if self._at(TokenType.EQ, TokenType.ASSIGN):
            self._advance()  # = or :=
            body = self._parse_expression()
            # Consume additional comma-separated values for multi-variable init
            if len(names) > 1:
                for _ in range(len(names) - 1):
                    if self._at(TokenType.COMMA):
                        self._advance()
                        self._parse_expression()
        elif self._at(TokenType.BE):
            self._advance()  # BE
            is_function = True
            body = self._parse_command()

        return cls(
            range=self._range_from(start),
            name=names[0] if names else name,
            names=names,
            params=params,
            is_function=is_function,
            body=body,
        )

    def _is_multi_name_decl(self) -> bool:
        """Look ahead past comma to see if this is LET x, y, z = ... pattern."""
        # We're at COMMA. Check: COMMA IDENT (COMMA|EQ) pattern
        if self.pos + 1 < len(self.tokens) and self.tokens[self.pos + 1].type == TokenType.IDENT:
            # Check what follows the ident
            if self.pos + 2 < len(self.tokens):
                following = self.tokens[self.pos + 2].type
                return following in (TokenType.COMMA, TokenType.EQ)
        return False

    def _parse_global(self) -> GlobalBlock:
        start = self._advance()  # GLOBAL
        entries: list[GlobalEntry] = []
        self._expect(TokenType.LBRACE)

        while not self._at(TokenType.RBRACE, TokenType.EOF):
            entry_start = self._cur()
            if self._at(TokenType.IDENT):
                name = self._advance().text
                number = None
                if self._at(TokenType.COLON):
                    self._advance()
                    # Parse slot number if present.  Bare ':' (no number) means
                    # auto-assigned — skip expression parsing in that case.
                    if not self._at(TokenType.RBRACE, TokenType.EOF,
                                    TokenType.SEMICOLON, TokenType.QUERY):
                        # Peek ahead: if next is IDENT followed by ':', this is
                        # the next entry — the slot number was omitted.
                        if self._at(TokenType.IDENT) and self.pos + 1 < len(self.tokens) \
                                and self.tokens[self.pos + 1].type == TokenType.COLON:
                            pass  # auto-assigned slot, skip expression
                        else:
                            expr = self._parse_expression()
                            if isinstance(expr, NumberLit):
                                try:
                                    number = int(expr.value)
                                except ValueError:
                                    pass
                # Consume optional ? (marks uninitialized global)
                if self._at(TokenType.QUERY):
                    self._advance()
                entries.append(GlobalEntry(
                    range=self._range_from(entry_start), name=name, number=number
                ))
            else:
                # Skip unexpected tokens (e.g. from conditional compilation)
                self._advance()

            # Skip separators (semicolons and newlines)
            while self._at(TokenType.SEMICOLON):
                self._advance()

        self._expect(TokenType.RBRACE)
        return GlobalBlock(range=self._range_from(start), entries=entries)

    def _parse_manifest(self) -> ManifestBlock:
        start = self._advance()  # MANIFEST
        entries: list[ManifestEntry] = []
        self._expect(TokenType.LBRACE)

        while not self._at(TokenType.RBRACE, TokenType.EOF):
            entry_start = self._cur()
            if self._at(TokenType.IDENT):
                name = self._advance().text
                value = None
                if self._at(TokenType.EQ):
                    self._advance()
                    value = self._parse_expression()
                entries.append(ManifestEntry(
                    range=self._range_from(entry_start), name=name, value=value
                ))
            elif self._at(TokenType.COLON):
                # Bare colon after value (some dialects use : as separator)
                self._advance()
            else:
                # Skip unexpected tokens (e.g. from conditional compilation
                # $<TAG val $>TAG which injects extra values)
                self._advance()

            while self._at(TokenType.SEMICOLON):
                self._advance()

        self._expect(TokenType.RBRACE)
        return ManifestBlock(range=self._range_from(start), entries=entries)

    def _parse_static(self) -> StaticBlock:
        start = self._advance()  # STATIC
        entries: list[StaticEntry] = []
        self._expect(TokenType.LBRACE)

        while not self._at(TokenType.RBRACE, TokenType.EOF):
            entry_start = self._cur()
            if self._at(TokenType.IDENT):
                name = self._advance().text
                value = None
                if self._at(TokenType.EQ):
                    self._advance()
                    value = self._parse_expression()
                entries.append(StaticEntry(
                    range=self._range_from(entry_start), name=name, value=value
                ))
            else:
                self._error(f"expected identifier in STATIC block, got '{self._cur().text}'")
                self._advance()

            while self._at(TokenType.SEMICOLON):
                self._advance()

        self._expect(TokenType.RBRACE)
        return StaticBlock(range=self._range_from(start), entries=entries)

    # ── Commands (statements) ─────────────────────────────────

    def _parse_command(self) -> Node:
        """Parse a command and check for postfix REPEAT/REPEATWHILE/REPEATUNTIL."""
        cmd = self._parse_simple_command()
        # Handle <> sequence operator: cmd1 <> cmd2
        while self._at(TokenType.SEQ):
            self._advance()  # <>
            right = self._parse_simple_command()
            cmd = BinaryExpr(
                range=Range(cmd.range.start_line, cmd.range.start_col,
                            right.range.end_line, right.range.end_col),
                op="<>", left=cmd, right=right,
            )
        return self._check_postfix_repeat(cmd)

    def _check_postfix_repeat(self, cmd: Node) -> Node:
        """Handle postfix REPEAT, REPEATWHILE, REPEATUNTIL."""
        if self._at(TokenType.REPEAT):
            start = self._advance()
            return RepeatStmt(range=self._range_from(start), body=cmd)
        if self._at(TokenType.REPEATWHILE):
            start = self._advance()
            cond = self._parse_expression()
            return RepeatWhileStmt(
                range=self._range_from(start), body=cmd, condition=cond
            )
        if self._at(TokenType.REPEATUNTIL):
            start = self._advance()
            cond = self._parse_expression()
            return RepeatUntilStmt(
                range=self._range_from(start), body=cmd, condition=cond
            )
        return cmd

    def _parse_simple_command(self) -> Node:
        tt = self._peek_type()

        if tt == TokenType.LBRACE:
            return self._parse_block()
        if tt == TokenType.IF:
            return self._parse_if()
        if tt == TokenType.UNLESS:
            return self._parse_unless()
        if tt == TokenType.TEST:
            return self._parse_test()
        if tt == TokenType.WHILE:
            return self._parse_while()
        if tt == TokenType.UNTIL:
            return self._parse_until()
        if tt == TokenType.FOR:
            return self._parse_for()
        if tt == TokenType.SWITCHON:
            return self._parse_switch()
        if tt == TokenType.CASE:
            return self._parse_case_label()
        if tt == TokenType.DEFAULT:
            return self._parse_default_label()
        if tt == TokenType.RETURN:
            start = self._advance()
            return ReturnStmt(range=self._range_from(start))
        if tt == TokenType.RESULTIS:
            return self._parse_resultis()
        if tt == TokenType.BREAK:
            start = self._advance()
            return BreakStmt(range=self._range_from(start))
        if tt == TokenType.LOOP:
            start = self._advance()
            return LoopStmt(range=self._range_from(start))
        if tt == TokenType.ENDCASE:
            start = self._advance()
            return EndcaseStmt(range=self._range_from(start))
        if tt == TokenType.GOTO:
            start = self._advance()
            target = self._parse_expression()
            return target  # GOTO is just consumed; target is an identifier
        if tt == TokenType.LET:
            return self._parse_let_decl()
        if tt == TokenType.AND:
            return self._parse_and_decl()
        if tt == TokenType.MANIFEST:
            return self._parse_manifest()
        if tt == TokenType.STATIC:
            return self._parse_static()
        if tt == TokenType.GLOBAL:
            return self._parse_global()

        # Check for label: ident ':'
        if tt == TokenType.IDENT and self._is_label():
            start = self._advance()  # ident
            label_name = start.text
            self._advance()  # :
            body = self._parse_command()
            return LabelStmt(range=self._range_from(start), name=label_name, body=body)

        # Expression or assignment
        return self._parse_expr_or_assignment()

    def _is_label(self) -> bool:
        """Check if current IDENT token is followed by : (a label, not assignment)."""
        if self.pos + 1 < len(self.tokens):
            return self.tokens[self.pos + 1].type == TokenType.COLON
        return False

    def _parse_block(self) -> Block:
        start = self._advance()  # $( or {
        stmts: list[Node] = []

        while not self._at(TokenType.RBRACE, TokenType.EOF):
            stmt = self._parse_command()
            stmts.append(stmt)
            while self._at(TokenType.SEMICOLON):
                self._advance()

        self._expect(TokenType.RBRACE)
        return Block(range=self._range_from(start), statements=stmts)

    def _consume_optional_do_then(self) -> None:
        """Consume DO or THEN if present; otherwise allow implicit continuation."""
        if self._at(TokenType.DO, TokenType.THEN):
            self._advance()

    def _parse_if(self) -> IfStmt:
        start = self._advance()  # IF
        cond = self._parse_expression()
        self._consume_optional_do_then()
        then_body = self._parse_command()
        else_body = None
        # In canonical BCPL, only TEST has ELSE — IF never does.
        # When inside a TEST body, never let IF consume ELSE (it belongs to TEST).
        # Outside TEST, allow IF...ELSE as a dialect extension.
        if self._at(TokenType.ELSE) and not self._in_test_body:
            self._advance()
            else_body = self._parse_command()
        return IfStmt(
            range=self._range_from(start),
            condition=cond, then_body=then_body, else_body=else_body,
        )

    def _parse_unless(self) -> IfStmt:
        """UNLESS expr DO command — same as IF NOT expr DO command."""
        start = self._advance()  # UNLESS
        cond = self._parse_expression()
        self._consume_optional_do_then()
        body = self._parse_command()
        neg_cond = UnaryExpr(range=cond.range, op="NOT", operand=cond)
        return IfStmt(
            range=self._range_from(start),
            condition=neg_cond, then_body=body, else_body=None,
        )

    def _parse_test(self) -> TestStmt:
        start = self._advance()  # TEST
        cond = self._parse_expression()
        # Accept THEN, DO, or implicit (block follows directly)
        self._consume_optional_do_then()
        # Parse THEN body with flag so nested IF won't steal our ELSE
        prev = self._in_test_body
        self._in_test_body = True
        then_body = self._parse_command()
        self._in_test_body = prev
        # Accept ELSE or OR (TRIPOS BCPL uses TEST...DO...OR as TEST...THEN...ELSE)
        self._expect_one_of(TokenType.ELSE, TokenType.OR)
        else_body = self._parse_command()
        return TestStmt(
            range=self._range_from(start),
            condition=cond, then_body=then_body, else_body=else_body,
        )

    def _parse_while(self) -> WhileStmt:
        start = self._advance()  # WHILE
        cond = self._parse_expression()
        self._consume_optional_do_then()
        body = self._parse_command()
        return WhileStmt(range=self._range_from(start), condition=cond, body=body)

    def _parse_until(self) -> UntilStmt:
        start = self._advance()  # UNTIL
        cond = self._parse_expression()
        self._consume_optional_do_then()
        body = self._parse_command()
        return UntilStmt(range=self._range_from(start), condition=cond, body=body)

    def _parse_for(self) -> ForStmt:
        start = self._advance()  # FOR
        var = ""
        if self._at(TokenType.IDENT):
            var = self._advance().text
        self._expect(TokenType.EQ)
        start_expr = self._parse_expression()
        self._expect(TokenType.TO)
        end_expr = self._parse_expression()
        step = None
        if self._at(TokenType.BY):
            self._advance()
            step = self._parse_expression()
        # DO is expected but accept command directly if a command-starting token follows
        if self._at(TokenType.DO):
            self._advance()
        elif self._peek_type() in COMMAND_STARTERS:
            pass  # Implicit DO — command follows directly
        else:
            self._expect(TokenType.DO)  # Will emit error
        body = self._parse_command()
        return ForStmt(
            range=self._range_from(start),
            var=var, start=start_expr, end=end_expr, step=step, body=body,
        )

    def _parse_switch(self) -> SwitchStmt:
        start = self._advance()  # SWITCHON
        expr = self._parse_expression()
        self._expect(TokenType.INTO)
        body = self._parse_command()
        return SwitchStmt(range=self._range_from(start), expr=expr, body=body)

    def _parse_case_label(self) -> CaseLabel:
        start = self._advance()  # CASE
        value = self._parse_expression()
        self._expect(TokenType.COLON)
        return CaseLabel(range=self._range_from(start), value=value)

    def _parse_default_label(self) -> DefaultLabel:
        start = self._advance()  # DEFAULT
        self._expect(TokenType.COLON)
        return DefaultLabel(range=self._range_from(start))

    def _parse_resultis(self) -> ResultIsStmt:
        start = self._advance()  # RESULTIS
        value = self._parse_expression()
        return ResultIsStmt(range=self._range_from(start), value=value)

    def _parse_expr_or_assignment(self) -> Node:
        expr = self._parse_expression()

        # Multiple assignment: e1, e2 := e3, e4
        if self._at(TokenType.COMMA):
            # Could be multiple targets before :=
            targets = [expr]
            while self._at(TokenType.COMMA):
                self._advance()
                targets.append(self._parse_expression())
            if self._at(TokenType.ASSIGN):
                start_tok = self.tokens[max(0, self.pos - 1)]
                self._advance()  # :=
                value = self._parse_expression()
                # Parse remaining values
                while self._at(TokenType.COMMA):
                    self._advance()
                    self._parse_expression()
                return Assignment(
                    range=self._range_from(start_tok),
                    target=targets[0], value=value,
                )
            # Not an assignment — just expressions separated by commas
            # Return the first one (comma expressions aren't a thing in BCPL
            # outside of -> conditional)
            return expr

        if self._at(TokenType.ASSIGN):
            start_tok = self.tokens[max(0, self.pos - 1)]
            self._advance()  # :=
            value = self._parse_expression()
            return Assignment(
                range=self._range_from(start_tok),
                target=expr, value=value,
            )

        # Compound assignment: x +:= y  =>  x := x + y
        if self._at(TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN,
                     TokenType.STAR_ASSIGN, TokenType.SLASH_ASSIGN,
                     TokenType.AND_ASSIGN, TokenType.OR_ASSIGN,
                     TokenType.EQV_ASSIGN, TokenType.NEQV_ASSIGN):
            start_tok = self.tokens[max(0, self.pos - 1)]
            self._advance()
            value = self._parse_expression()
            return Assignment(
                range=self._range_from(start_tok),
                target=expr, value=value,
            )

        return expr

    # ── Expressions (precedence climbing) ─────────────────────

    def _parse_expression(self) -> Node:
        return self._parse_cond_expr()

    def _parse_cond_expr(self) -> Node:
        """Parse conditional: expr -> expr, expr"""
        left = self._parse_or_expr()
        if self._at(TokenType.COND):
            start_tok = self.tokens[max(0, self.pos - 1)]
            self._advance()  # ->
            then_expr = self._parse_expression()
            self._expect(TokenType.COMMA)
            else_expr = self._parse_expression()
            return CondExpr(
                range=self._range_from(start_tok),
                condition=left, then_expr=then_expr, else_expr=else_expr,
            )
        return left

    def _parse_or_expr(self) -> Node:
        left = self._parse_and_expr()
        while self._at(TokenType.LOGOR, TokenType.OR):
            # OR on a new line in a TEST body is likely ELSE, not logical OR
            if self._at(TokenType.OR) and self._in_test_body and self._on_new_line():
                break
            op = self._advance()
            right = self._parse_and_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_and_expr(self) -> Node:
        left = self._parse_not_expr()
        while self._at(TokenType.LOGAND):
            op = self._advance()
            right = self._parse_not_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_not_expr(self) -> Node:
        if self._at(TokenType.NOT, TokenType.BITNOT):
            start = self._advance()
            operand = self._parse_not_expr()
            return UnaryExpr(
                range=self._range_from(start),
                op=start.text, operand=operand,
            )
        return self._parse_rel_expr()

    def _parse_rel_expr(self) -> Node:
        left = self._parse_eqv_expr()
        while self._at(TokenType.EQ, TokenType.NEQ, TokenType.LT, TokenType.GT,
                        TokenType.LE, TokenType.GE):
            op = self._advance()
            right = self._parse_eqv_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_eqv_expr(self) -> Node:
        left = self._parse_shift_expr()
        while self._at(TokenType.EQV, TokenType.NEQV):
            op = self._advance()
            right = self._parse_shift_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_shift_expr(self) -> Node:
        left = self._parse_add_expr()
        while self._at(TokenType.LSHIFT, TokenType.RSHIFT):
            op = self._advance()
            right = self._parse_add_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_add_expr(self) -> Node:
        left = self._parse_mul_expr()
        while self._at(TokenType.PLUS, TokenType.MINUS):
            op = self._advance()
            right = self._parse_mul_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_mul_expr(self) -> Node:
        left = self._parse_unary_expr()
        while self._at(TokenType.STAR, TokenType.SLASH, TokenType.REM, TokenType.MOD):
            op = self._advance()
            right = self._parse_unary_expr()
            left = BinaryExpr(
                range=Range(left.range.start_line, left.range.start_col,
                            right.range.end_line, right.range.end_col),
                op=op.text, left=left, right=right,
            )
        return left

    def _parse_unary_expr(self) -> Node:
        if self._at(TokenType.MINUS):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="-", operand=operand)
        if self._at(TokenType.PLUS):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="+", operand=operand)
        if self._at(TokenType.ABS):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="ABS", operand=operand)
        if self._at(TokenType.AT):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="@", operand=operand)
        if self._at(TokenType.BANG):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="!", operand=operand)
        if self._at(TokenType.PERCENT):
            start = self._advance()
            operand = self._parse_unary_expr()
            return UnaryExpr(range=self._range_from(start), op="%", operand=operand)
        return self._parse_postfix_expr()

    def _prev_token(self) -> Token:
        """Get the token just before current position."""
        return self.tokens[max(0, self.pos - 1)]

    def _on_new_line(self) -> bool:
        """Check if current token is on a different line than the previous token."""
        return self._cur().line > self._prev_token().line

    def _parse_postfix_expr(self) -> Node:
        left = self._parse_primary()
        while True:
            if self._at(TokenType.LPAREN):
                # Function call — only if ( is on the same line
                if self._on_new_line():
                    break
                self._advance()
                args: list[Node] = []
                while not self._at(TokenType.RPAREN, TokenType.EOF):
                    args.append(self._parse_expression())
                    if self._at(TokenType.COMMA):
                        self._advance()
                    elif not self._at(TokenType.RPAREN):
                        break
                self._expect(TokenType.RPAREN)
                left = CallExpr(
                    range=Range(left.range.start_line, left.range.start_col,
                                self.tokens[max(0, self.pos - 1)].line,
                                self.tokens[max(0, self.pos - 1)].column + 1),
                    func=left, args=args,
                )
            elif self._at(TokenType.BANG):
                # ! as postfix indexing — but NOT if on a new line (likely prefix !)
                if self._on_new_line():
                    break
                self._advance()
                index = self._parse_unary_expr()
                left = IndexExpr(
                    range=Range(left.range.start_line, left.range.start_col,
                                index.range.end_line, index.range.end_col),
                    base=left, index=index,
                )
            elif self._at(TokenType.PERCENT):
                # % as postfix byte access — but NOT if on a new line
                if self._on_new_line():
                    break
                self._advance()
                offset = self._parse_unary_expr()
                left = FieldExpr(
                    range=Range(left.range.start_line, left.range.start_col,
                                offset.range.end_line, offset.range.end_col),
                    base=left, offset=offset,
                )
            elif self._at(TokenType.OF):
                # field OF word — bit-field extraction
                self._advance()
                right = self._parse_unary_expr()
                left = BinaryExpr(
                    range=Range(left.range.start_line, left.range.start_col,
                                right.range.end_line, right.range.end_col),
                    op="OF", left=left, right=right,
                )
            elif self._at(TokenType.HASH):
                # Method dispatch: name#(args)
                self._advance()
                # Continue — next iteration will pick up the ( for call
            elif self._at(TokenType.LBRACKET):
                # f[args] — alternate call/indexing syntax — NOT if on a new line
                if self._on_new_line():
                    break
                self._advance()
                args: list[Node] = []
                while not self._at(TokenType.RBRACKET, TokenType.EOF):
                    args.append(self._parse_expression())
                    if self._at(TokenType.COMMA):
                        self._advance()
                    elif not self._at(TokenType.RBRACKET):
                        break
                self._expect(TokenType.RBRACKET)
                if len(args) == 1:
                    # Single arg — treat as indexing
                    left = IndexExpr(
                        range=Range(left.range.start_line, left.range.start_col,
                                    self.tokens[max(0, self.pos - 1)].line,
                                    self.tokens[max(0, self.pos - 1)].column + 1),
                        base=left, index=args[0],
                    )
                else:
                    # Multiple args or empty — treat as function call
                    left = CallExpr(
                        range=Range(left.range.start_line, left.range.start_col,
                                    self.tokens[max(0, self.pos - 1)].line,
                                    self.tokens[max(0, self.pos - 1)].column + 1),
                        func=left, args=args,
                    )
            else:
                break
        return left

    def _parse_primary(self) -> Node:
        tok = self._cur()

        if self._at(TokenType.NUMBER):
            self._advance()
            return NumberLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                value=tok.text,
            )

        if self._at(TokenType.STRING):
            self._advance()
            return StringLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                value=tok.text,
            )

        if self._at(TokenType.CHARCONST):
            self._advance()
            return CharLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                value=tok.text,
            )

        if self._at(TokenType.TRUE):
            self._advance()
            return BoolLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                value=True,
            )

        if self._at(TokenType.FALSE):
            self._advance()
            return BoolLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                value=False,
            )

        if self._at(TokenType.IDENT):
            self._advance()
            return IdentExpr(
                range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
                name=tok.text,
            )

        if self._at(TokenType.LPAREN):
            self._advance()
            expr = self._parse_expression()
            self._expect(TokenType.RPAREN)
            return expr

        if self._at(TokenType.VALOF):
            start = self._advance()
            body = self._parse_command()
            return ValofExpr(range=self._range_from(start), body=body)

        if self._at(TokenType.VEC):
            start = self._advance()
            size = self._parse_expression()
            return VecExpr(range=self._range_from(start), size=size)

        if self._at(TokenType.TABLE):
            return self._parse_table()

        if self._at(TokenType.LBRACKET):
            # [expr] — bracketed expression (alternate syntax)
            self._advance()
            expr = self._parse_expression()
            self._expect(TokenType.RBRACKET)
            return expr

        if self._at(TokenType.QUERY):
            self._advance()
            return NumberLit(
                range=Range(tok.line, tok.column, tok.line, tok.column + 1),
                value="?",
            )

        # Error recovery
        self._error(f"unexpected token '{tok.text}'")
        self._advance()
        return ErrorNode(
            range=Range(tok.line, tok.column, tok.line, tok.column + len(tok.text)),
            message=f"unexpected '{tok.text}'",
        )

    def _parse_table(self) -> TableExpr:
        start = self._advance()  # TABLE
        values: list[Node] = []
        values.append(self._parse_expression())
        while self._at(TokenType.COMMA):
            self._advance()
            values.append(self._parse_expression())
        return TableExpr(range=self._range_from(start), values=values)
