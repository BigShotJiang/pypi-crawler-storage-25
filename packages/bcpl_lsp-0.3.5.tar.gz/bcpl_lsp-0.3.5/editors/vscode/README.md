# BCPL Language Server

Language Server Protocol support for [Martin Richards' BCPL](https://www.cl.cam.ac.uk/~mr10/BCPL.html) in Visual Studio Code.

## Features

- **Syntax highlighting** — TextMate grammar for BCPL keywords, operators, strings, and comments
- **Completion** — keywords with snippets and document symbols
- **Go to Definition** — jump to function, variable, and global declarations
- **Find References** — locate all usages across files
- **Hover** — view symbol signatures and documentation
- **Rename** — rename symbols across files
- **Diagnostics** — unresolved symbols, duplicate globals, unused variables
- **Semantic Tokens** — context-aware highlighting
- **Document Symbols** — outline view of functions, globals, manifests
- **Workspace Symbols** — search symbols across the project
- **Call Hierarchy** — incoming and outgoing call graphs

## BCPL Dialect

Targets Martin Richards' canonical BCPL with uppercase keywords (`LET`, `IF`, `THEN`, `GET`, etc.). Also supports TRIPOS-era syntax variants.

## Known Limitations

This is an early-stage language server. Notable gaps:

- **No type checking.** BCPL is untyped (word-oriented), so diagnostics are limited to name resolution, unused variables, duplicate globals, and a handful of structural checks.
- **No formatter, code actions, signature help, inlay hints, or folding ranges.** Only the LSP features listed above are implemented.
- **Conditional compilation is not interpreted.** The `/*<TAG ... /*TAG>*/` convention used by some BCPL distributions is treated as plain block comments — symbols inside an inactive branch will not be indexed.
- **Macro / preprocessor-like constructs are not expanded.** Manifest constants are evaluated, but more elaborate compile-time tricks are not.
- **Header resolution is heuristic.** When a workspace contains multiple BCPL systems (e.g. Cintcode plus TRIPOS), the server picks the nearest `g/` directory by directory proximity. Unusual layouts may need an explicit `bcpl.searchPaths` setting.
- **Parser error recovery is best-effort.** Files with severe syntax errors may produce cascading or missing diagnostics until the error is fixed.
- **Workspace indexing is in-memory and runs at startup.** Very large codebases (hundreds of thousands of lines) will take a noticeable moment on first open.
- **Tested primarily against the Cintcode and TRIPOS sources.** Other BCPL dialects (e.g. Norcroft, Tripos PDP-11 variants) may expose parser gaps.

Bug reports and dialect samples that break the parser are welcome.

## Requirements

The language server is written in Python and requires:

- **Python 3.10+**
- **[uv](https://docs.astral.sh/uv/)** (recommended) or pip

### Install

```bash
# With uv (recommended)
uv tool install bcpl-lsp

# Or with pip
pip install bcpl-lsp
```

### Update

The language server is versioned independently from the extension. After the extension auto-updates, you also need to upgrade the server:

```bash
# With uv
uv tool upgrade bcpl-lsp

# Or with pip
pip install --upgrade bcpl-lsp
```

Then run **BCPL: Restart Language Server** from the command palette (or reload the window) so VS Code picks up the new server.

The extension looks for `bcpl-lsp` on your `PATH`. Alternatively, set `bcpl.server.path` in VS Code settings to point at a local clone of the project.

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `bcpl.server.path` | `""` | Path to the bcpl-lsp project directory. If empty, expects `bcpl-lsp` on PATH. |
| `bcpl.searchPaths` | `[]` | Extra directories to search for `GET` headers (e.g. a `g/` directory containing `libhdr`). When empty, the server auto-discovers `g/` directories in the workspace and picks the nearest one for each source file. |
| `bcpl.logLevel` | `"info"` | Log verbosity: `debug`, `info`, `warning`, or `error`. |

## Commands

- **BCPL: Language Server Menu** — quick access to all commands
- **BCPL: Restart Language Server** — restart the server
- **BCPL: Show Version** — display the current version

## File Associations

The extension associates `.b` and `.bcpl` files with BCPL. Extensionless files are auto-detected by sniffing for BCPL constructs (`GET`, `SECTION`, `LET`, `GLOBAL`, etc.).

## License

MIT
