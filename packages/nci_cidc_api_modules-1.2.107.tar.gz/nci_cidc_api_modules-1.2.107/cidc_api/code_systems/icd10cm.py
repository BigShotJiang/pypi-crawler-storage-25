from typing import Annotated

from pydantic import AfterValidator

from cidc_api.code_systems.sqlite_store import get_conn as _conn


def is_valid_code(v: str) -> str:
    if _conn().execute("SELECT 1 FROM icd10cm WHERE code = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid ICD-10-CM code")

    return v


def is_valid_term(v: str) -> str:
    if _conn().execute("SELECT 1 FROM icd10cm WHERE term = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid ICD-10-CM term")

    return v


def validate_code_term_match(code: str, term: str) -> None:
    row = _conn().execute("SELECT term FROM icd10cm WHERE code = ?", (code,)).fetchone()

    # row is None when the code doesn't exist — already rejected by is_valid_code
    if row is not None and row[0] != term:
        raise ValueError(f"code '{code}' does not match term '{term}'")


def lookup_code_from_term(term: str) -> str | None:
    row = _conn().execute("SELECT code FROM icd10cm WHERE term = ?", (term,)).fetchone()
    if row is not None:
        return row[0]


def lookup_term_from_code(code: str) -> str | None:
    row = _conn().execute("SELECT term FROM icd10cm WHERE code = ?", (code,)).fetchone()
    if row is not None:
        return row[0]


ComorbidityCode = Annotated[str, AfterValidator(is_valid_code)]
ComorbidityTerm = Annotated[str, AfterValidator(is_valid_term)]
