from typing import Literal

# AJCC / R-ISS / FIGO

CancerStageSystem = Literal[
    "AJCC",
    "R-ISS",
    "FIGO",
    "Not Applicable",
]

CancerStageSystemVersionAJCC = Literal["8th Edition",]
CancerStageSystemVersionRISS = Literal["10.1200/JCO.2015.61.2267"]

CancerStageSystemVersionFIGO = Literal[
    "10.1002/ijgo.14923",
    "10.1002/ijgo.13881",
    "10.1002/ijgo.13867",
    "10.1002/ijgo.13865",
    "10.1002/ijgo.13866",
    "10.1002/ijgo.13878",
    "10.1002/ijgo.13877",
    "10.1002/ijgo.12613",
]

CancerStageSystemVersion = Literal[
    CancerStageSystemVersionAJCC, CancerStageSystemVersionFIGO, CancerStageSystemVersionRISS
]

_CancerStageAJCC = Literal[
    "Stage 0",
    "Stage 0a",
    "Stage 0is",
    "Stage I",
    "Stage IA",
    "Stage IA1",
    "Stage IA2",
    "Stage IA3",
    "Stage IB",
    "Stage IB1",
    "Stage IB2",
    "Stage II",
    "Stage IIA",
    "Stage IIA1",
    "Stage IIA2",
    "Stage IIB",
    "Stage IIC",
    "Stage III",
    "Stage IIIA",
    "Stage IIIB",
    "Stage IIIC",
    "Stage IS",
    "Stage IV",
    "Stage IVA",
    "Stage IVB",
    "Stage IVC",
    "Stage occult carcinoma",
]

_CancerStageFIGO = Literal[
    "Stage I",
    "Stage IA",
    "Stage IA1",
    "Stage IA2",
    "Stage IA3",
    "Stage IB",
    "Stage IC",
    "Stage II",
    "Stage IIA",
    "Stage IIB",
    "Stage IIC",
    "Stage III",
    "Stage IIIA",
    "Stage IIIA1",
    "Stage IIIA2",
    "Stage IIIB",
    "Stage IIIB1",
    "Stage IIIB2",
    "Stage IIIC",
    "Stage IIIC1",
    "Stage IIIC1i",
    "Stage IIIC1ii",
    "Stage IIIC2",
    "Stage IIIC2i",
    "Stage IIIC2ii",
    "Stage IV",
    "Stage IVA",
    "Stage IVB",
    "Stage IVC",
    "Stage IB1",
    "Stage IB2",
    "Stage IB3",
    "Stage IIA1",
    "Stage IIA2",
    "Stage IC1",
    "Stage IC2",
    "Stage IC3",
    "Stage IIIA1(i)",
    "Stage IIIA1(ii)",
]

_CancerStageRISS = Literal[
    "Stage I",
    "Stage II",
    "Stage III",
]

CancerStage = Literal[_CancerStageAJCC, _CancerStageFIGO, _CancerStageRISS]

# RECIST / iRECIST

ResponseSystem = Literal["RECIST", "iRECIST"]

_ResponseSystemVersionRecist = Literal["1.1"]
_ResponseSystemVersionIrecist = Literal["10.1016/S1470-2045(17)30074-8"]  # DOI version
ResponseSystemVersion = Literal[_ResponseSystemVersionRecist, _ResponseSystemVersionIrecist]

_BestOverallResponseRecist = Literal[
    "Complete Response",
    "Partial Response",
    "Progressive Disease",
    "Stable Disease",
    "Not available",
    "Not assessed",
]

_BestOverallResponseIrecist = Literal[
    "immune Complete Response",
    "immune Partial Response",
    "immune Stable Disease",
    "immune Unconfirmed Progressive Disease",
    "immune Confirmed Progressive Disease",
    "Not available",
    "Not assessed",
]

BestOverallResponse = Literal[_BestOverallResponseRecist, _BestOverallResponseIrecist]

# Modified Glucksberg / MAGIC

_VersionModifiedGlucksberg = Literal["10.1038/s41409-018-0204-7"]
_VersionMagic = Literal["10.1038/s41409-018-0204-7"]
DiagnosisAcuteAssessmentSystemVersion = Literal[_VersionModifiedGlucksberg, _VersionMagic]

DiagnosisAcuteAssessmentSystem = Literal["Modified Glucksberg", "MAGIC"]

_DiagnosisAcuteGradeModifiedGlucksberg = Literal["0", "I", "II", "III", "IV"]
_DiagnosisAcuteGradeMagic = Literal["0", "I", "II", "III", "IV"]
DiagnosisAcuteGrade = Literal[_DiagnosisAcuteGradeModifiedGlucksberg, _DiagnosisAcuteGradeMagic]

Organ = Literal[
    "Skin",
    "Mouth",
    "Eyes",
    "Gastrointestinal tract",
    "Liver",
    "Lungs",
    "Joints and fascia",
    "Genital tract",
]

# They use the same stage PVs but we're explicit here to accommodate changes
# If these ever change to be different, be sure to add a test for the _mismatch condition
# with acute_assessment_system to check if a stage is provided that is valid for one
# assessment system but not the other.
_OrganAcuteStageModifiedGlucksberg = Literal["0", "1", "2", "3", "4"]
_OrganAcuteStageMagic = Literal["0", "1", "2", "3", "4"]
OrganAcuteStage = Literal[_OrganAcuteStageModifiedGlucksberg, _OrganAcuteStageMagic]

# NIH Consensus Criteria

DiagnosisChronicAssessmentSystem = Literal["NIH Consensus Criteria"]
DiagnosisChronicAssessmentSystemVersion = Literal["10.1016/j.bbmt.2014.12.001"]
DiagnosisChronicGlobalSeverity = Literal["Mild", "Moderate", "Severe"]
OrganChronicScore = Literal["0", "1", "2", "3"]

# MedDRA

SystemOrganClass = Literal[
    "Blood and lymphatic system disorders",
    "Cardiac disorders",
    "Congenital, familial and genetic disorders",
    "Ear and labyrinth disorders",
    "Endocrine disorders",
    "Eye disorders",
    "Gastrointestinal disorders",
    "General disorders and administration site conditions",
    "Hepatobiliary disorders",
    "Immune system disorders",
    "Infections and infestations",
    "Injury, poisoning and procedural complications",
    "Investigations",
    "Metabolism and nutrition disorders",
    "Musculoskeletal and connective tissue disorders",
    "Neoplasms benign, malignant and unspecified (incl cysts and polyps)",
    "Nervous system disorders",
    "Pregnancy, puerperium and perinatal conditions",
    "Psychiatric disorders",
    "Renal and urinary disorders",
    "Reproductive system and breast disorders",
    "Respiratory, thoracic and mediastinal disorders",
    "Skin and subcutaneous tissue disorders",
    "Social circumstances",
    "Surgical and medical procedures",
    "Vascular disorders",
]
