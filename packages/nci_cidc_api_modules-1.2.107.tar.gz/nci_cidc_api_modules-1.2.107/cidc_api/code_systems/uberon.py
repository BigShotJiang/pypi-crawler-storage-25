from typing import Annotated

from pydantic import AfterValidator

from cidc_api.code_systems.sqlite_store import get_conn as _conn


def is_valid_anatomical_term(v: str) -> str:
    if _conn().execute("SELECT 1 FROM uberon WHERE anatomical_term = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid UBERON anatomical term")

    return v


UberonAnatomicalTerm = Annotated[str, AfterValidator(is_valid_anatomical_term)]
