from typing import Literal

from cidc_api.code_systems.sqlite_store import get_conn as _conn

_VERSION_TO_TABLE = {"5.0": "ctcae50", "6.0": "ctcae60"}


def _table(version: str) -> str:
    table = _VERSION_TO_TABLE.get(version)

    if table is None:
        raise ValueError(f"unknown CTCAE version: {version}")

    return table


def is_valid_code(v: str, version: str) -> str:
    if _conn().execute(f"SELECT 1 FROM {_table(version)} WHERE code = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid CTCAE {version} code")

    return v


def is_valid_term(v: str, version: str) -> str:
    if _conn().execute(f"SELECT 1 FROM {_table(version)} WHERE term = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid CTCAE {version} term")

    return v


def validate_code_term_match(code: str, term: str, version: str) -> None:
    row = _conn().execute(f"SELECT term FROM {_table(version)} WHERE code = ?", (code,)).fetchone()

    # row is None when the code doesn't exist - already rejected by is_valid_code
    if row is not None and row[0] != term:
        raise ValueError(f"code '{code}' does not match term '{term}'")


def lookup_code_from_term(term: str, version: str) -> str | None:
    row = _conn().execute(f"SELECT code FROM {_table(version)} WHERE term = ?", (term,)).fetchone()

    if row is not None:
        return row[0]


def lookup_term_from_code(code: str, version: str) -> str | None:
    row = _conn().execute(f"SELECT term FROM {_table(version)} WHERE code = ?", (code,)).fetchone()

    if row is not None:
        return row[0]


# Determines if the CTCAE term is one of the "Other, specify" types of terms
# for which we include additional data about the AE.
def is_other_term(v) -> bool:
    if isinstance(v, str):
        return "Other, specify" in v

    return False


SeverityGradeSystem = Literal["CTCAE"]
SeverityGradeSystemVersion = Literal["5.0", "6.0"]
SeverityGrade = Literal["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5"]
