from typing import Annotated

from pydantic import AfterValidator

from cidc_api.code_systems.sqlite_store import get_conn as _conn


def is_valid_morphological_code(v):
    if _conn().execute("SELECT 1 FROM Icdo3 WHERE morphological_code = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid ICD-O-3 morphological code")

    return v


def is_valid_morphological_term(v):
    if _conn().execute("SELECT 1 FROM Icdo3 WHERE morphological_term = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid ICD-O-3 morphological term")

    return v


def validate_code_term_match(code: str, term: str) -> None:
    row = _conn().execute("SELECT morphological_term FROM Icdo3 WHERE morphological_code = ?", (code,)).fetchone()

    # row is None when the code doesn't exist — already rejected by is_valid_morphological_code
    if row is not None and row[0] != term:
        raise ValueError(f"morphological_code '{code}' does not match morphological_term '{term}'")


def lookup_code_from_term(term: str) -> str | None:
    row = _conn().execute("SELECT morphological_code FROM icdo3 WHERE morphological_term = ?", (term,)).fetchone()
    if row is not None:
        return row[0]


def lookup_term_from_code(code: str) -> str | None:
    row = _conn().execute("SELECT morphological_term FROM icdo3 WHERE morphological_code = ?", (code,)).fetchone()
    if row is not None:
        return row[0]


MorphologicalCode = Annotated[str, AfterValidator(is_valid_morphological_code)]
MorphologicalTerm = Annotated[str, AfterValidator(is_valid_morphological_term)]
