from pathlib import Path
import sqlite3

_process_conn: dict[str, sqlite3.Connection] = {}
_DATA_DIR = Path(__file__).parent / "data"
_DB_FILE = _DATA_DIR / "sqlite.db"


def _open_disk(db_file: Path) -> sqlite3.Connection:
    return sqlite3.connect(str(db_file), check_same_thread=False)


def _load_into_memory(db_file: Path) -> sqlite3.Connection:
    disk_conn = _open_disk(db_file)
    mem_conn = sqlite3.connect(":memory:", check_same_thread=False)
    disk_conn.backup(mem_conn)
    disk_conn.close()

    return mem_conn


def get_conn(in_memory: bool = False) -> sqlite3.Connection:
    """Return a SQLite connection shared across all code system tables.

    Uses the bundled sqlite.db. One connection is created per mode and shared
    across all threads in the process. For a read-only DB this is safe: SQLite
    supports concurrent readers without locking.

    Defaults to disk access. Pass in_memory=True to copy the DB into :memory: on
    first use — eliminates disk I/O for subsequent lookups at the cost of extra RAM
    (processes x db_size).
    """
    key = str(in_memory)

    if key not in _process_conn:
        _process_conn[key] = _load_into_memory(_DB_FILE) if in_memory else _open_disk(_DB_FILE)

    return _process_conn[key]
