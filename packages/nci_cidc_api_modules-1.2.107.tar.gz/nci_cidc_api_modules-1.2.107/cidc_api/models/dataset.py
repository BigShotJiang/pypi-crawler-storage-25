from collections import defaultdict
from enum import StrEnum
import json
from pprint import pformat
from typing import Any, Tuple, List, Mapping

from sqlalchemy import and_
from sqlalchemy.orm.session import Session

from cidc_api.models.pydantic.stage1 import all_models as stage1_all_models
from cidc_api.models.pydantic.stage2 import all_models as stage2_all_models
from cidc_api.models.db.stage1 import all_models as stage1_all_db_models
from cidc_api.models.db.stage2 import all_models as stage2_all_db_models
from cidc_api.models.db.stage1 import TrialORM as s1TrialORM
from cidc_api.models.db.stage2 import TrialORM as s2TrialORM

# Maps data categories like "treatment" to their associated pydantic model
data_category_to_model = {
    "stage1": {model.__data_category__: model for model in stage1_all_models if hasattr(model, "__data_category__")},
    "stage2": {model.__data_category__: model for model in stage2_all_models if hasattr(model, "__data_category__")},
}


data_category_to_db_model = {
    "stage1": {model.__data_category__: model for model in stage1_all_db_models if hasattr(model, "__data_category__")},
    "stage2": {model.__data_category__: model for model in stage2_all_db_models if hasattr(model, "__data_category__")},
}


EXTERNAL_TO_INTERNAL_DATA_CATEGORY_MAP = {"study": "trial"}


class Stages(StrEnum):
    STAGE1 = "stage1"
    STAGE2 = "stage2"
    STAGE3 = "stage3"

    @classmethod
    def members(cls):
        return list(v.value for v in cls.__members__.values())

    def next_stage(self):
        members = list(self.__class__)
        index = members.index(self) + 1
        if index >= len(members):
            raise StopIteration(f"Cannot determine next stage for stage={self.value}")
        return members[index]


class NoDataError(Exception):
    pass


# A class to hold the entire model representation of a trial's dataset
class Dataset(dict):
    def __init__(self, trial_id, version, stage, *args, **kwargs):
        if stage not in Stages:
            raise ValueError(f"value for 'stage' must be in {Stages.members()}")

        self.trial_id = trial_id
        self.version = version
        self.stage = stage
        for data_category in data_category_to_model[self.stage]:
            self[data_category] = []
        super().__init__(*args, **kwargs)

    def load(self, session: Session):
        for data_category, _ in self.items():
            db_model_cls = data_category_to_db_model[self.stage][data_category]
            db_models = self.load_db_models(db_model_cls, session)
            self[data_category] = db_models

        if not any(self.values()):
            raise NoDataError(f"No data found to load dataset {self.trial_id=} {self.version=} {self.stage=}")

    def load_db_models(self, db_model_cls: Any, session: Session):
        db_models = (
            session.query(db_model_cls)
            .filter(and_(db_model_cls.trial_id == self.trial_id, db_model_cls.version == self.version))
            .all()
        )
        return db_models

    def save(self, session: Session) -> None:
        for _, db_models in self.items():
            session.add_all(db_models)

    def __repr__(self):
        return pformat({(k, len(v)) for k, v in self.items()})

    def to_db_dataset(self):
        db_dataset = Dataset(self.trial_id, self.version, self.stage)
        for data_category, models in self.items():
            if not models:
                continue

            # A data category that is not a standard data category belongs in the "custom_data" data category when stored
            if data_category not in data_category_to_db_model[self.stage]:
                data_category = "custom_data"

            db_model_cls = data_category_to_db_model[self.stage][data_category]

            for model in models:
                db_model, extra = Dataset.model_to_db_model(model, db_model_cls)
                # Encode any extra fields on standard models when composing the orm model
                if extra:
                    db_model.custom_row_data = extra
                db_dataset[data_category].append(db_model)
        return db_dataset

    def to_dataset(self):
        dataset = Dataset(self.trial_id, self.version, self.stage)
        exclude = ["custom_row_data"]
        if self.stage == Stages.STAGE1:
            # NOTE participant_id not needed for stage1 and is of different type. This may be addressed separately.
            exclude.append("participant_id")

        for data_category, models in self.items():
            if not models:
                continue

            model_cls = data_category_to_model[dataset.stage][data_category]

            for db_model in models:
                model = Dataset.db_model_to_model(db_model, model_cls, exclude=exclude)
                # Decode any extra fields on standard models when composing the pydantic model
                if db_model.custom_row_data:
                    model.update(**db_model.custom_row_data)

                # If the model was part of a custom data category, e.g. "lesions", add to "lesions" instead of "custom_data"
                target_category = model.data_category if data_category == "custom_data" else data_category
                if target_category not in dataset:
                    dataset[target_category] = []
                dataset[target_category].append(model)
        return dataset

    @staticmethod
    def model_to_db_model(model: Any, db_model_cls: Any) -> Tuple[Any, dict]:
        """Transform a pydantic model into a db model of the specified class. Returns a tuple of the db model and
        a dict of the extra data that doesn't fit into the model (for linkage fields or custom data elements)"""

        exclude = list(model.model_extra.keys()) + getattr(model.__class__, "__exclude_during_conversion__", [])

        db_model = db_model_cls(**model.model_dump(exclude=exclude))
        return db_model, model.model_extra

    @staticmethod
    def db_model_to_model(db_model: Any, model_cls: Any, exclude: List[str] = None) -> Any:
        db_dict = db_model.to_dict(exclude=exclude)
        # Exclude None from the dict we're passing to pydantic, to ensure default values for non-provided
        # fields in the pydantic models are used
        db_dict = {k: v for k, v in db_dict.items() if v is not None}

        model = model_cls(**(db_dict))

        return model

    def build_index_for(self, index_key: str) -> Mapping[str, dict[str, list]]:
        """Index all records by the value of index_key they are linked to. For example, with
        index_key="participant_id" this lets you get from 'CXYZUJC' to all the records in all
        the sheets that have that participant_id."""
        index = defaultdict(lambda: defaultdict(list))
        for data_category, values in self.items():
            for value in values:
                if hasattr(value, index_key):  # Is model
                    index[getattr(value, index_key)][data_category].append(value)
                elif getattr(value, "__contains__", None) and index_key in value:  # Is dict
                    index[value[index_key]][data_category].append(value)

        return index

    @staticmethod
    def get_trial_orm_for_stage(stage: str) -> Any:
        if stage not in Stages:
            raise ValueError(f"value for 'stage' must be in {Stages.members()}")

        if stage == Stages.STAGE1:
            TrialORM = s1TrialORM
        elif stage == Stages.STAGE2:
            TrialORM = s2TrialORM
        elif stage == Stages.STAGE3:
            pass  # stub
        return TrialORM

    @staticmethod
    def trial_exists(trial_id: str, version: str, stage: str, session: Session) -> bool:
        if stage not in Stages:
            raise ValueError(f"value for 'stage' must be in {Stages.members()}")
        TrialORM = Dataset.get_trial_orm_for_stage(stage)

        trials = session.query(TrialORM).filter(and_(TrialORM.trial_id == trial_id, TrialORM.version == version)).all()
        return len(trials) == 1
