from __future__ import annotations

from typing import List

from pydantic import NonPositiveInt
from sqlalchemy import ForeignKey, ForeignKeyConstraint, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from cidc_api.code_systems.other import CancerStage, CancerStageSystem, CancerStageSystemVersion
from cidc_api.code_systems.icdo3 import MorphologicalCode, MorphologicalTerm
from cidc_api.code_systems.uberon import UberonAnatomicalTerm
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.models.types import MCategory, NCategory, TCategory, TumorGrade, YNU


class DiseaseORM(BaseORM):
    __tablename__ = "disease"
    __repr_attrs__ = [
        "disease_id",
        "participant_id",
    ]
    __data_category__ = "disease"
    __exclude_during_promotion__ = ["disease_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    disease_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    primary_disease_site: Mapped[UberonAnatomicalTerm]
    morphological_code: Mapped[MorphologicalCode | None]
    morphological_term: Mapped[MorphologicalTerm | None]
    cancer_type_description: Mapped[str | None]
    days_since_original_diagnosis: Mapped[NonPositiveInt | None]
    tumor_grade: Mapped[TumorGrade | None]
    cancer_stage_system: Mapped[CancerStageSystem]
    cancer_stage_system_version: Mapped[CancerStageSystemVersion | None] = mapped_column(String, nullable=True)
    cancer_stage: Mapped[CancerStage | None] = mapped_column(String)
    t_category: Mapped[TCategory | None]
    n_category: Mapped[NCategory | None]
    m_category: Mapped[MCategory | None]
    metastatic_organ: Mapped[List[UberonAnatomicalTerm] | None] = mapped_column(JSON, nullable=True)
    solely_extramedullary_disease: Mapped[YNU]
    extramedullary_organ: Mapped[List[UberonAnatomicalTerm]] = mapped_column(JSON, nullable=True)

    trial: Mapped[TrialORM] = relationship(back_populates="diseases", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="diseases", cascade="all, delete")
