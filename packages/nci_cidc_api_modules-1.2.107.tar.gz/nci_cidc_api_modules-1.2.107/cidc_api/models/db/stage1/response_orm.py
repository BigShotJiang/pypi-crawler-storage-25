from __future__ import annotations
from pydantic import NonNegativeInt

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.models.types import SurvivalStatus, CauseOfDeath, YNUNA, YN


class ResponseORM(BaseORM):
    __tablename__ = "response"
    __repr_attrs__ = ["response_id", "participant_id"]
    __data_category__ = "response"
    __exclude_during_promotion__ = ["response_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    response_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    survival_status: Mapped[SurvivalStatus]
    overall_survival: Mapped[NonNegativeInt | None]
    abscopal_response: Mapped[YNUNA | None]
    pathological_complete_response: Mapped[YNUNA | None]
    days_to_death: Mapped[NonNegativeInt | None]
    cause_of_death: Mapped[CauseOfDeath | None]
    evaluable_for_toxicity: Mapped[YN]
    evaluable_for_efficacy: Mapped[YN]
    days_to_last_vital_status: Mapped[NonNegativeInt | None]

    trial: Mapped[TrialORM] = relationship(back_populates="responses", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="response", cascade="all, delete")
