from __future__ import annotations

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.other import Organ, OrganAcuteStage
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.models.types import PreOrPostEnrollment


class GVHDOrganAcuteORM(BaseORM):
    __tablename__ = "gvhd_organ_acute"
    __repr_attrs__ = ["gvhd_organ_acute_id", "organ"]
    __data_category__ = "gvhd_organ_acute"
    __exclude_during_promotion__ = ["gvhd_organ_acute_id", "gvhd_diagnosis_acute_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    gvhd_organ_acute_id: Mapped[int] = mapped_column(primary_key=True)
    gvhd_diagnosis_acute_id: Mapped[int] = mapped_column(
        ForeignKey("stage1.gvhd_diagnosis_acute.gvhd_diagnosis_acute_id", ondelete="CASCADE")
    )
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    organ: Mapped[Organ]
    acute_stage: Mapped[OrganAcuteStage]
    pre_or_post_enrollment: Mapped[PreOrPostEnrollment]

    trial: Mapped[TrialORM] = relationship(back_populates="gvhd_organ_acutes", cascade="all, delete")
    gvhd_diagnosis_acute: Mapped[GVHDDiagnosisAcuteORM] = relationship(
        back_populates="gvhd_organ_acutes", cascade="all, delete"
    )
    participant: Mapped[ParticipantORM] = relationship(back_populates="gvhd_organ_acutes", cascade="all, delete")
