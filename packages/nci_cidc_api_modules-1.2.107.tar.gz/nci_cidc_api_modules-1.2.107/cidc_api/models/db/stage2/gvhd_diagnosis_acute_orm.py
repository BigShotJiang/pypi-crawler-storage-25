from __future__ import annotations

from typing import List

from sqlalchemy import ForeignKey, ForeignKeyConstraint, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.other import (
    DiagnosisAcuteAssessmentSystem,
    DiagnosisAcuteAssessmentSystemVersion,
    DiagnosisAcuteGrade,
)
from cidc_api.models.db.stage2.base_orm import BaseORM
from cidc_api.models.db.stage2.trial_orm import TrialORM
from cidc_api.models.types import PreOrPostEnrollment


class GVHDDiagnosisAcuteORM(BaseORM):
    __tablename__ = "gvhd_diagnosis_acute"
    __repr_attrs__ = ["gvhd_diagnosis_acute_id", "pre_or_post_enrollment"]
    __data_category__ = "gvhd_diagnosis_acute"
    __table_args__ = (
        UniqueConstraint("participant_id", "pre_or_post_enrollment", name="unique_ix_gvhd_diagnosis_acute_pre_or_post"),
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    gvhd_diagnosis_acute_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage2.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    acute_assessment_system: Mapped[DiagnosisAcuteAssessmentSystem]
    system_version: Mapped[DiagnosisAcuteAssessmentSystemVersion]
    acute_grade: Mapped[DiagnosisAcuteGrade]
    pre_or_post_enrollment: Mapped[PreOrPostEnrollment]

    trial: Mapped[TrialORM] = relationship(back_populates="gvhd_diagnosis_acutes", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="gvhd_diagnosis_acutes", cascade="all, delete")
    gvhd_organ_acutes: Mapped[List[GVHDOrganAcuteORM]] = relationship(
        back_populates="gvhd_diagnosis_acute", cascade="all, delete", passive_deletes=True
    )
