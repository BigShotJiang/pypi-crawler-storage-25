from pydantic import NonPositiveInt

from cidc_api.code_systems.icdo3 import (
    MorphologicalCode,
    MorphologicalTerm,
    validate_code_term_match,
    lookup_code_from_term,
    lookup_term_from_code,
)
from cidc_api.models.errors import ValueLocError
from cidc_api.models.pydantic.base import Base, forced_validator, forced_validators
from cidc_api.code_systems.uberon import UberonAnatomicalTerm
from cidc_api.models.types import MalignancyStatus


@forced_validators
class OtherMalignancy(Base):
    __data_category__ = "other_malignancy"
    __cardinality__ = "many"
    __exclude_during_export__ = [
        "trial_id",
        "version",
        "other_malignancy_id",
        "medical_history_id",
        "participant_id",
        "native_participant_id",
    ]

    # The unique internal identifier for the OtherMalignancy record
    other_malignancy_id: int | None = None

    # The unique internal identifier for the associated MedicalHistory record
    medical_history_id: int | None = None

    # The unique internal identifier of the associated participant
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # The location within the body from where the prior malignancy originated as captured in the Uberon anatomical term.
    other_malignancy_primary_disease_site: UberonAnatomicalTerm

    # The ICD-O-3 code which identifies the specific appearance of cells and tissues (normal and abnormal) used
    # to define the presence and nature of disease.
    other_malignancy_morphological_code: MorphologicalCode | None = None

    # The ICD-O-3 textual label which identifies the specific appearance of cells and tissues (normal and abnormal) used
    # to define the presence and nature of disease.
    other_malignancy_morphological_term: MorphologicalTerm | None = None

    # Description of the cancer type as recorded in the trial.
    other_malignancy_description: str | None = None

    # Number of days since original diagnosis from the enrollment date. This may be a negative number.
    other_malignancy_days_since_diagnosis: NonPositiveInt | None = None

    # Indicates the participant’s current clinical state regarding the cancer diagnosis.
    other_malignancy_status: MalignancyStatus | None = None

    # Note: This validator runs first by virtue of being declared first
    @forced_validator
    @classmethod
    def lookup_term_or_code(cls, data, info) -> None:
        code = data.get("other_malignancy_morphological_code", None)
        term = data.get("other_malignancy_morphological_term", None)

        if term and not code:
            data["other_malignancy_morphological_code"] = lookup_code_from_term(term)
        elif code and not term:
            data["other_malignancy_morphological_term"] = lookup_term_from_code(code)

    @forced_validator
    @classmethod
    def validate_code_or_term_or_description_cr(cls, data, info) -> None:
        other_malignancy_morphological_term = data.get("other_malignancy_morphological_term", None)
        other_malignancy_description = data.get("other_malignancy_description", None)
        other_malignancy_morphological_code = data.get("other_malignancy_morphological_code", None)

        if (
            not other_malignancy_morphological_code
            and not other_malignancy_morphological_term
            and not other_malignancy_description
        ):
            raise ValueLocError(
                'Please provide at least one of "morphological_code", "morphological_term" or "malignancy_description".',
                loc="other_malignancy_morphological_code",
            )

    @forced_validator
    @classmethod
    def validate_morphological_code_term_match(cls, data, info) -> None:
        code = data.get("other_malignancy_morphological_code")
        term = data.get("other_malignancy_morphological_term")

        if code is None or term is None:
            return

        try:
            validate_code_term_match(code, term)
        except ValueError as e:
            raise ValueLocError(str(e), loc="other_malignancy_morphological_term") from e
