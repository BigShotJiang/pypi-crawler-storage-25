from cidc_api.code_systems.other import Organ, OrganChronicScore
from cidc_api.models.pydantic.base import Base
from cidc_api.models.types import PreOrPostEnrollment


class GVHDOrganChronic(Base):
    __data_category__ = "gvhd_organ_chronic"
    __cardinality__ = "many"
    __exclude_during_export__ = [
        "trial_id",
        "version",
        "gvhd_organ_chronic_id",
        "gvhd_diagnosis_chronic_id",
        "participant_id",
        "native_participant_id",
    ]

    # The unique internal identifier for the GVHD Organ Chronic Record
    gvhd_organ_chronic_id: int | None = None

    # The unique internal identifier for the associated GVHD Diagnosis Chronic record
    gvhd_diagnosis_chronic_id: int | None = None

    # The unique internal identifier of the associated participant
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # An organ affected by chronic GVHD identified by its Uberon ontology ID
    # and evaluated for severity as part of the overall chronic GVHD assessment.
    organ: Organ

    # The severity score for an individual organ affected by chronic GVHD based on clinical criteria.
    chronic_score: OrganChronicScore

    # Indicator for whether the acute GVHD diagnosis was made before or after trial enrollment.
    pre_or_post_enrollment: PreOrPostEnrollment
