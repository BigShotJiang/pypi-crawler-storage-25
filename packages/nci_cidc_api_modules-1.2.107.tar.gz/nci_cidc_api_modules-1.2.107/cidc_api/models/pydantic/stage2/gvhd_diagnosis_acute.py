from typing import get_args

from cidc_api.code_systems.other import (
    DiagnosisAcuteAssessmentSystem,
    DiagnosisAcuteAssessmentSystemVersion,
    DiagnosisAcuteGrade,
    _VersionModifiedGlucksberg,
    _VersionMagic,
    _DiagnosisAcuteGradeModifiedGlucksberg,
    _DiagnosisAcuteGradeMagic,
)
from cidc_api.models.errors import ValueLocError
from cidc_api.models.pydantic.base import Base, forced_validator, forced_validators
from cidc_api.models.types import PreOrPostEnrollment


@forced_validators
class GVHDDiagnosisAcute(Base):
    __data_category__ = "gvhd_diagnosis_acute"
    __cardinality__ = "many"
    __exclude_during_export__ = [
        "trial_id",
        "version",
        "gvhd_diagnosis_acute_id",
        "participant_id",
        "native_participant_id",
    ]

    # The unique internal identifier for the GVHD Diagnosis Acute Record
    gvhd_diagnosis_acute_id: int | None = None

    # The unique internal identifier for the associated participant
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # The clinical grading system used to stage involvement of affected organs (skin, liver, GI tract)
    # in acute GVHD and assign an overall severity grade (I–IV) based on predefined criteria.
    acute_assessment_system: DiagnosisAcuteAssessmentSystem

    # Release version of the clinical grading system used in the evaluation of acute GVHD.
    system_version: DiagnosisAcuteAssessmentSystemVersion

    # The overall severity grade (I–IV) assigned to a patient with acute GVHD based on the extent of
    # involvement in affected organs (skin, liver, and GI tract), determined using a standardized
    # assessment system.
    acute_grade: DiagnosisAcuteGrade

    # Indicator for whether the acute GVHD diagnosis was made before or after trial enrollment.
    pre_or_post_enrollment: PreOrPostEnrollment

    @forced_validator
    @classmethod
    def validate_system_version(cls, data, info) -> None:
        acute_assessment_system = data.get("acute_assessment_system", None)
        system_version = data.get("system_version", None)

        msg = f"'{system_version}' is not applicable to '{acute_assessment_system}'"
        if acute_assessment_system == "MAGIC" and system_version not in get_args(_VersionMagic):
            raise ValueLocError(msg, loc="system_version")
        elif acute_assessment_system == "Modified Glucksberg" and system_version not in get_args(
            _VersionModifiedGlucksberg
        ):
            raise ValueLocError(msg, loc="system_version")

    @forced_validator
    @classmethod
    def validate_acute_grade(cls, data, info) -> None:
        acute_assessment_system = data.get("acute_assessment_system", None)
        acute_grade = data.get("acute_grade", None)

        msg = f"'{acute_grade}' is not applicable to '{acute_assessment_system}'"
        if acute_assessment_system == "MAGIC" and acute_grade not in get_args(_DiagnosisAcuteGradeMagic):
            raise ValueLocError(msg, loc="acute_grade")
        elif acute_assessment_system == "Modified Glucksberg" and acute_grade not in get_args(
            _DiagnosisAcuteGradeModifiedGlucksberg
        ):
            raise ValueLocError(msg, loc="acute_grade")
