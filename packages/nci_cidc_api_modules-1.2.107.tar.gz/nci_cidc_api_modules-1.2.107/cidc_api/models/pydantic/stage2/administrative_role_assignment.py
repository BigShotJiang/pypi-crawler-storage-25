from cidc_api.models.pydantic.base import Base
from cidc_api.models.types import AdministrativeRole


class AdministrativeRoleAssignment(Base):
    __data_category__ = "administrative_role_assignment"
    __exclude_during_export__ = ["trial_id", "version", "administrative_person_id"]

    # The unique identifier for the associated administrative person
    administrative_person_id: int

    # The role the administrative_person is performing for the associated trial
    administrative_role: AdministrativeRole
