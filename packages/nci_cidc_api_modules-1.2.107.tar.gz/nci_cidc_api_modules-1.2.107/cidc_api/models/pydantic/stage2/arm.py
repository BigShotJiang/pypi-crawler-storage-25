from cidc_api.models.pydantic.base import Base


class Arm(Base):
    __data_category__ = "arm"
    __exclude_during_export__ = ["trial_id", "version", "arm_id"]

    # The unique internal identifier for the arm
    arm_id: int | None = None

    # The name of the arm, e.g. "Arm A1"
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=2001626%20and%20ver_nr=3
    name: str
