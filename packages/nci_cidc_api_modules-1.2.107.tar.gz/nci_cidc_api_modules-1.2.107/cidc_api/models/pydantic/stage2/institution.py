from cidc_api.models.pydantic.base import Base


class Institution(Base):
    __data_category__ = "institution"
    __exclude_during_export__ = ["trial_id", "version", "institution_id"]

    # A unique internal identifier for the Institution
    institution_id: int | None = None

    # The name by which the institution is known, e.g. "MATCH Central Pathology Lab"
    name: str
