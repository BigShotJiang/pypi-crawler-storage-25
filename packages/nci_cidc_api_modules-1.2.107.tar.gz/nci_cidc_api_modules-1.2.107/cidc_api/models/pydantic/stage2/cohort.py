from cidc_api.models.pydantic.base import Base


class Cohort(Base):
    __data_category__ = "cohort"
    __exclude_during_export__ = ["trial_id", "version", "cohort_id"]

    # A unique internal identifier for the cohort
    cohort_id: int | None = None

    # The name of the cohort, e.g. "Cohort A"
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=7979585%20and%20ver_nr=1
    name: str
