from pydantic import NonNegativeInt

from cidc_api.models.pydantic.base import Base


class ConsentGroup(Base):
    __data_category__ = "consent_group"
    __cardinality__ = "one"
    __exclude_during_export__ = ["trial_id", "version", "consent_group_id", "participant_id", "native_participant_id"]

    # The unique internal identifier for the consent group record
    consent_group_id: int | None = None

    # The unique internal identifier for the associated participant
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=12220014%20and%20ver_nr=1
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # An abbreviated name for the consent group
    consent_group_short_name: str

    # The words or acronym which describe a set of study participants
    # who have signed the same consent agreement and that will be included in the dbGaP repository.
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=14534329%20and%20ver_nr=1.00
    consent_group_name: str

    # A numeral or string of numerals used to identify the set of study participants who have signed the same consent
    # agreement and that will be included in the dbGaP repository.
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=14534330%20and%20ver_nr=1.00
    consent_group_number: NonNegativeInt
