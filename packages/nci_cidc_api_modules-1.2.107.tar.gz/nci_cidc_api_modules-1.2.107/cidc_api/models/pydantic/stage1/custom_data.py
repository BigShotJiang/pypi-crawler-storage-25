from cidc_api.models.pydantic.base import Base
from cidc_api.models.pydantic.base import forced_validator, forced_validators
from cidc_api.models.errors import ValueLocError


@forced_validators
class CustomData(Base):
    __data_category__ = "custom_data"
    __cardinality__ = None

    custom_data_id: int | None = None

    # The custom data category this data belongs to. e.g. "lesions".
    data_category: str
