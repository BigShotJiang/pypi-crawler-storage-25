import copy
from contextlib import contextmanager
from datetime import datetime
from typing import Self, ClassVar
from pydantic import BaseModel, ConfigDict, model_validator, ValidationError
from pydantic_core import InitErrorDetails

from cidc_api.models.errors import ValueLocError

# pylint: disable=raise-missing-from


class Base(BaseModel):

    model_config = ConfigDict(
        validate_assignment=True,
        from_attributes=True,
        extra="allow",
    )
    forced_validators: ClassVar = []

    # The unique internal identifier for the associated Trial record
    trial_id: str | None = None

    # The version number of the trial dataset
    version: str | None = None

    # Validates the new state and updates the object if valid
    def update(self, **kwargs):
        with self.delay_validation():
            self.model_validate(self.__dict__ | kwargs)
            for k, v in kwargs.items():
                setattr(self, k, v)
        return self

    # CM that delays validation until all fields are applied.
    # If validation fails the original fields are restored and the ValidationError is raised.
    @contextmanager
    def delay_validation(self):
        original_dict = copy.deepcopy(self.__dict__)
        self.model_config["validate_assignment"] = False
        try:
            yield
        finally:
            self.model_config["validate_assignment"] = True
        try:
            self.model_validate(self.__dict__)
        except:
            self.__dict__.update(original_dict)
            raise

        # CM that delays validation until all fields are applied.

    @classmethod
    def to_list(cls, value):
        """Listify fields that are multi-valued in input data, e.g. 'lung|kidney'"""
        if isinstance(value, list):
            return value
        elif isinstance(value, str):
            if not value:
                return []
            return value.split("|")
        elif value is None:
            return []
        else:
            raise ValueError("Field value must be string or list")

    @classmethod
    def from_list(cls, value):
        return "|".join(value)

    @classmethod
    def to_datetime(cls, value):
        if isinstance(value, datetime) or value is None:
            return value
        elif not isinstance(value, str):
            raise ValueError("value must be a str")

        extra_formats = ["%m-%d-%Y", "%m-%d-%y", "%m/%d/%Y", "%m/%d/%y"]
        dt = None
        try:
            dt = datetime.fromisoformat(value)
        except ValueError:
            for dt_format in extra_formats:
                try:
                    dt = datetime.strptime(value, dt_format)
                except ValueError:
                    pass
            if not dt:
                raise ValueError(f"datetime value {value} is not a valid format")
        return dt

    @classmethod
    def from_datetime(cls, value):
        if value is None:
            return None
        return value.isoformat()

    @model_validator(mode="wrap")
    @classmethod
    def check_all_forced_validators(cls, data, handler, info) -> Self:
        """This base validator ensures all registered forced_validator(s) get called along with
        normal model field validators no matter what the outcome of either is. Normal field_validator
        and model_validator decorators don't guarantee this. We want to collect as many errors as we can.

        Collects errors from both attempts and raises them in a combined ValidationError."""

        validation_errors = []
        # When assigning attributes to an already-hydrated model, data is an instance of the model
        # instead of a dict and handler is an AssignmentValidatorCallable instead of a ValidatorCallable(!!)
        extracted_data = data.model_dump() if not isinstance(data, dict) else data

        for validator in cls.forced_validators:
            try:
                func_name = validator.__name__
                func = getattr(cls, func_name)
                func(extracted_data, info)
            except ValueLocError as e:
                validation_errors.append(
                    InitErrorDetails(
                        type="value_error",
                        loc=e.loc,
                        input=extracted_data,
                        ctx={"error": e},
                    )
                )
        try:
            # Instantiate the model to ensure all other normal field validations are called
            retval = handler(data)
        except ValidationError as e:
            validation_errors.extend(e.errors())
        if validation_errors:
            raise ValidationError.from_exception_data(title=cls.__name__, line_errors=validation_errors)
        return retval


def forced_validator(func):
    """A method marked with this decorator is added to the class list of forced_validators"""
    func._is_forced_validator = True  # Tag the function object with a custom attribute
    return func


def forced_validators(cls):
    """A class marked with this decorator accumulates its methods marked with force_validator into a list
    for later invocation."""

    cls.forced_validators = []
    for obj in cls.__dict__.values():
        if getattr(obj, "_is_forced_validator", False):
            cls.forced_validators.append(obj)
    return cls
