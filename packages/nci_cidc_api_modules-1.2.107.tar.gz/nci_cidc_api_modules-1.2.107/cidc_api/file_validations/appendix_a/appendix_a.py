from cidc_api.models import TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
from cidc_api.shared.file_handling import get_column_from_appendix_a
from cidc_api.telemetry import trace_


def validate_duplicate_data_elements(appendix_a_df, meta):
    """Returns errors for any duplicate (category, data element) pairs in Appendix A."""

    category_column = appendix_a_df.columns[0]
    element_column = get_column_from_appendix_a(appendix_a_df, "Data Element")
    header_condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    data_rows = appendix_a_df.iloc[appendix_a_df[header_condition].index[0] + 1 :]

    duplicate_rows: dict[tuple, list[int]] = {}

    for index, row in data_rows.iterrows():
        category = row[category_column]
        data_element = row[element_column]

        if not category or not data_element:
            continue

        key = (category, data_element)
        duplicate_rows.setdefault(key, []).append(index + 1)

    errors = []

    for (category, data_element), rows in duplicate_rows.items():
        if len(rows) <= 1:
            continue

        errors.append(
            {
                "error": f"Duplicate data element found in {category}.{data_element}",
                "value": {"row_numbers": rows},
            }
        )

    return {"errors": errors, "meta": meta}


@trace_()
def validate(appendix_a_df):
    appendix_a_df.fillna("", inplace=True)
    meta = {}
    errors = []

    # Pipeline mirrors custom_data_elements.validate - add new validators to the list below.
    for validate_ in [
        validate_duplicate_data_elements,
    ]:
        result = validate_(appendix_a_df, meta)
        meta.update(result["meta"])
        errors.extend(result["errors"])

    return {"errors": errors, "meta": meta}
