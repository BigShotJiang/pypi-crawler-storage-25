"""Shared utilities package."""
