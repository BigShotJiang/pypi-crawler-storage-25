from aimp_framework import Engine


class DemoEngine(Engine):
    def load(self):
        pass
