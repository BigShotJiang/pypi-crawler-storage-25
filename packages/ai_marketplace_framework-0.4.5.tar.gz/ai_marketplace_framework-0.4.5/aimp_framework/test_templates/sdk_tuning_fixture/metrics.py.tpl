from aimp_sdk import Metric, TuneMetrics


class DemoMetrics(TuneMetrics):
    validation_loss = Metric(goal="minimize")
