from aimp_sdk import AudioField, FineTuneSchema, ImageField, TuningTextField, VideoField


class ClipSchema(FineTuneSchema):
    query_image = ImageField(description="query")
    reference_audio = AudioField(required=False, description="audio")
    clip = VideoField(required=False, description="video")
    caption = TuningTextField(required=False)
