from aimp_sdk import Model

from internal.loader import DemoEngine
from tuning.runner import DemoTuning


class DemoModel(Model):
    engine = DemoEngine
    tuning = DemoTuning
