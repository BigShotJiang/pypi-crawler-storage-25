from aimp_sdk import FineTuneSchema, TuningTextField


def return_json(value):
    return {{"value": value}}


class DemoSchema(FineTuneSchema):
    caption = TuningTextField(preprocessors=[return_json])
