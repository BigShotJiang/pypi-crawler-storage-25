from aimp_sdk import FileArtifact, TuneArtifacts


class DemoArtifacts(TuneArtifacts):
    result = FileArtifact(required=True)
