from aimp_framework.base import IntegerField, Schema


class DemoHyperparams(Schema):
    epochs = IntegerField(required=False, default=3, min=1, max=5)
