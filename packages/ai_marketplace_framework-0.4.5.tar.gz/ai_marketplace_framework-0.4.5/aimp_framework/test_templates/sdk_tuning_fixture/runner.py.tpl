from aimp_sdk import TuneResult, TunedResult, TuningSession

from internal.loader import DemoEngine

from .artifacts import DemoArtifacts
from .dataset import DemoSchema
from .metrics import DemoMetrics


class DemoTuning:
    dataset_schema = DemoSchema
    artifacts_schema = DemoArtifacts
    metrics_schema = DemoMetrics
    materialization = {{
        "strategy": "replace_root",
        "result_kind": "root_bundle",
        "required_artifacts": ["result"],
        "chaining": "replace",
    }}
    supports_chaining = True

    async def run(self, session: TuningSession[DemoSchema, DemoArtifacts]) -> TuneResult[DemoArtifacts, DemoMetrics]:
        artifact = session.artifacts.result.write_bytes(
            b"demo-tuned-root",
            filename="result.tar.gz",
        )
        return TuneResult(
            artifacts=DemoArtifacts(result=artifact),
            metrics=DemoMetrics(validation_loss=0.0),
        )

    async def apply(self, engine: DemoEngine, result: TunedResult[DemoArtifacts, DemoMetrics]) -> None:
        _ = engine, result
