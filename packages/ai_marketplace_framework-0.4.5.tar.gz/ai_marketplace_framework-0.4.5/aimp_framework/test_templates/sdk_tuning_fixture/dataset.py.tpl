from aimp_sdk import FineTuneSchema, TextField


class DemoSchema(FineTuneSchema):
    prompt = TextField(required=True)
    completion = TextField(required=True)
