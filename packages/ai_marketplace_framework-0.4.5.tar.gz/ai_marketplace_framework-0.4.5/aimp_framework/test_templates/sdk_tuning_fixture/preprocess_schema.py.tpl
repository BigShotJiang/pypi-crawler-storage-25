from aimp_sdk import FineTuneSchema, ImageField, TuningJsonField, TuningTextField


def trim_text(value):
    return str(value).strip()


def require_png(value):
    if not str(value).lower().endswith(".png"):
        raise ValueError("Only PNG files are allowed")


def add_source(value):
    result = dict(value)
    result.setdefault("source", "sdk-test")
    return result


class DemoSchema(FineTuneSchema):
    gallery = ImageField(required=True, multiple=True, validators=[require_png])
    caption = TuningTextField(required=False, preprocessors=[trim_text])
    metadata = TuningJsonField(required=True, preprocessors=[add_source])
