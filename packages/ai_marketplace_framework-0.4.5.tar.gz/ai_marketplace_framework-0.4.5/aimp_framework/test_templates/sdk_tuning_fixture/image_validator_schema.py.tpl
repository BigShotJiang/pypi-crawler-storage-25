from aimp_sdk import FineTuneSchema, ImageField


def require_png(value):
    if not str(value).lower().endswith(".png"):
        raise ValueError("Only PNG files are allowed")


class DemoSchema(FineTuneSchema):
    gallery = ImageField(required=True, multiple=True, validators=[require_png])
