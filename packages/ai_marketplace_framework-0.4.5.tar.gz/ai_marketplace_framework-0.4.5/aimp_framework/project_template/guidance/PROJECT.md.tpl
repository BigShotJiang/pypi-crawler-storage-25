# PROJECT.md

This file is the primary instruction set for AI assistants working in this project.
Open the matching local skill before editing when the task clearly fits one.

## Mission

- One project is one model.
- Keep the scaffold architecture intact.
- Prefer the smallest correct change in existing files.
- Reject convenience changes that blur architecture boundaries.

## Architecture boundaries

- `main.py` is the only public execution entrypoint. It owns the `Model` subclass and public `@mode` methods.
- `schemas.py` owns public mode inputs, outputs, and params.
- `playground.py` owns Playground configuration only.
- `internal/` is internal-only implementation: loader (engine lifecycle), inference, providers, vectors, and helpers.
- `tuning/` owns optional fine-tuning code and is the only top-level exception to the public/internal split.
- `runtime/` owns the model runtime image build files.
- `studio/` owns marketplace-facing copy only.
- Published execution always uses `python -m aimp_sdk.model_runner --module /app/main.py`.
- Prefer `Stream.text(text=..., status=...)` and `StreamState` for streaming text and status; use execution-stream `emit()` only for custom streaming protocols.
- Playground-only wiring uses `PlaygroundSources` / `PlaygroundComputed` with `source.chat_history()` and `computed.asset_ref` / `asset_refs` — not storage-specific APIs.
- `ai push` is the canonical end-to-end publish command.

## Non-negotiable rules

- Do not download weights, datasets, binaries, or external files during import time, startup, request handling, `load()`, or other runtime paths.
- If a model needs heavyweight assets, prepare them during the model runtime image build, then load from local paths only.
- Do not hardcode hardware tiers, GPU assumptions, or deployment selections in Python code. Hardware is selected at `ai push` time.
- Do not add new files, helpers, folders, or abstractions unless the task clearly requires them.
- Do not recreate removed layouts or legacy concepts:
  - `agent.py`
  - root `model.py`
  - `models/`
  - `workers/`
  - `core/`
  - root `engine.py`
  - root `vectors.py`
- Do not invent `modes.py`, `workflows/`, or parallel model trees unless the scaffold already contains them.

## Editing defaults

- Prefer editing existing files over creating new ones.
- Start by reading `PROJECT.md`, `main.py`, `schemas.py`, `playground.py`, `.aimp/project.toml`, and `.aimp/publish.toml`.
- Keep `main.py` explicit and thin: modes and the model class stay there, but provider logic, helpers, and runtime internals move under `internal/`.
- Keep publish intent in `.aimp/publish.toml` and operational config in `.aimp/project.toml`.
- Use `ai push` in command examples.

## Decision rules

- New public mode: update `main.py`, `schemas.py`, and `playground.py`.
- Lifecycle and runtime loading: `internal/loader.py`.
- Provider adapters, inference helpers, vectors, and similar implementation details: `internal/`.
- Fine-tuning only: `tuning/`.
- Runtime image and packaging files: `runtime/`.
- Marketplace copy only: `studio/`.

## Use these skills

- `model-architecture`: changing `main.py`, `schemas.py`, `playground.py`, or `internal/`
- `publish-readiness`: changing `.aimp/publish.toml`, runtime packaging, or publish behavior
- `studio-content`: changing `studio/article.mdx`, `studio/cover.jpg`, or marketplace copy
- `tuning-development`: changing anything under `tuning/`
- `quality-gates`: verifying a change before finishing
