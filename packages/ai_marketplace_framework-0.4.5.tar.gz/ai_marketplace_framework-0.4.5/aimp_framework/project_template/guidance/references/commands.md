# Model project commands

Read and validate:

```bash
ai contract validate --json
ai contract show --json
```

Configure and publish:

```bash
ai publish --configure --json
ai push
```

Inspect remote build state:

```bash
ai jobs get --type build --job <job_id>
```

Current runtime entrypoint:

```bash
python -m aimp_sdk.model_runner --module /app/main.py
```
