# Model project layout

Canonical tree:

```text
my-model/
  main.py
  schemas.py
  playground.py
  internal/
    __init__.py
    loader.py
    inference.py
  tuning/
  runtime/
  studio/
  tests/
  PROJECT.md
  .agents/skills/
```

Placement rules:

- Public `@mode` methods on the `Model` subclass: `main.py`
- Public inputs, outputs, params: `schemas.py`
- Playground configuration only: `playground.py`
- Engine lifecycle and local runtime loading: `internal/loader.py`
- Providers, inference helpers, vectors, and internal helpers: `internal/`
- Fine-tuning code only: `tuning/`
- Runtime build files only: `runtime/`
- Marketplace copy only: `studio/`

Invalid legacy shapes:

- `agent.py`
- root `model.py`
- `models/`
- `workers/`
- `core/`
- root `engine.py`
- root `vectors.py`
