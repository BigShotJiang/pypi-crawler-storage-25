# Publish flow

Canonical publish path:

1. Extract the model contract from `main.py`.
2. Read publish intent from `.aimp/publish.toml`.
3. Upload the source bundle through the CLI.
4. Let the platform Build Service build the runtime image remotely.
5. Finalize the publish from the succeeded remote build output.

Rules:

- Publish is platform-built, not local-Docker-owned.
- If contract extraction fails, fix the project shape or code first.
- If the build fails, inspect the remote build job logs instead of inventing alternate commands or routes.
