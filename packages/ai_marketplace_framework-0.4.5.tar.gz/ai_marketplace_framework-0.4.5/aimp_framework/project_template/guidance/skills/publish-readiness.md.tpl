---
name: publish-readiness
description: Use when preparing or validating `ai push` for this model project.
---

# Publish readiness

Read `../references/commands.md` and `../references/publish-flow.md` before changing publish behavior.

## Required files

- `main.py`
- `.aimp/project.toml`
- `.aimp/publish.toml`
- `runtime/Dockerfile`
- `studio/article.mdx`

## Canonical commands

```bash
ai contract validate --json
ai contract show --json
ai publish --configure --json
ai push
ai jobs get --type build --job <job_id>
```

## Expectations

- Contract extraction comes from `main.py`.
- Published runtime entrypoint is `python -m aimp_sdk.model_runner --module /app/main.py`.
- Publish is platform-built. Do not treat local Docker as the source of truth for the real publish path.

## Failure handling

- If contract extraction fails, fix the project shape or code first.
- If the remote build fails, inspect the build job logs.
- Do not invent alternate publish commands, legacy routes, or legacy agent publish flows.
