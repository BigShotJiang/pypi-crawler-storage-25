---
name: model-architecture
description: Use when changing model layout, runtime ownership, modes, schemas, or engine boundaries.
---

# Model architecture

Read `../references/layout.md` before making structural changes.

## Core rules

- One project is one model.
- `main.py` is the only public execution entrypoint.
- Keep `main.py` thin: declare public modes as `@mode` decorated async methods on the `Model` subclass; move implementation details out of `main.py` when they grow.
- `internal/` is internal-only. Add a new file there only when an internal concern becomes large enough that keeping it in `main.py` would blur public boundaries.

- Do not download external assets at runtime.
- Do not hardcode deployment hardware in code.

## Streaming progressive outputs

- Prefer `Stream.text(text=Schema.Outputs.<text_field>, status=Schema.Outputs.<status>)` for token or chunk streaming instead of calling `get_current_execution_stream().emit()` directly.
- Use a `JsonField` on `Schema.Outputs` for status when the Playground or API clients should show progress; keep the JSON shape aligned with `canonical_status_payload` (state, label, done, error, metadata).
- Reserve low-level `emit(append/replace/...)` for custom protocols not covered by `Stream`.

## Placement

- Add or change a public mode: `main.py`, `schemas.py`, `playground.py`
- Add engine lifecycle or local load behavior: `internal/loader.py`
- Add provider adapters, inference helpers, vectors, or shared internal helpers: `internal/`
- Add fine-tuning code: `tuning/`
- Add runtime image or packaging files: `runtime/`

## Reject these anti-patterns

- Recreating `agent.py`, root `model.py`, `models/`, `workers/`, or `core/`
- Moving provider logic, vectors, or inference helpers into `main.py`
- Putting public contracts under `internal/`
- Adding parallel model trees inside one project

## Valid change examples

- Add a new mode: update `schemas.py`, expose it from `main.py`, and wire Playground state in `playground.py`
- Add a provider adapter: create or update an internal module under `internal/`
- Add vector or inference helpers: put them in `internal/inference.py` or another internal module
- Add engine lifecycle code: extend `internal/loader.py`

## Review checklist

- The change preserves the single-model scaffold shape.
- Public execution still targets `main.py` on `aimp_sdk.model_runner`.
- No legacy layout or extra model tree was introduced.
