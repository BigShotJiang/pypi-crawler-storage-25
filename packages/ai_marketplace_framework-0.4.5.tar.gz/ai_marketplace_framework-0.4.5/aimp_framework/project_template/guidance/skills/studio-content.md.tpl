---
name: studio-content
description: Use when editing Studio-facing article, cover, or marketplace copy for this model.
---

# Studio content

## Scope

- `studio/article.mdx` is the primary long-form description.
- Cover art should match Studio configuration in `.aimp/publish.toml`.

## Rules

- Describe only behavior actually implemented by `main.py`.
- Keep claims aligned with required runtime secrets and supported modes.
- Prefer concise, skimmable structure with clear headings.
- Review Studio copy whenever the public model contract changes.
