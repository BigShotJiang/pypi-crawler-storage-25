---
name: tuning-development
description: Use when editing fine-tuning datasets, hyperparameters, or training code under tuning/.
---

# Tuning development

## Core rules

- Tuning is model-owned and discovered from `main.py`.
- `tuning/runner.py` is the tuning execution surface.
- `tuning/` contains dataset schema, hyperparameters, and training logic.

## Guardrails

- Keep dataset schemas aligned with exported bundle formats.
- Keep hyperparameters aligned with the exported tuning contract.
- Do not silently change training defaults without updating documented behavior.
- Do not leak tuning-only changes into runtime mode contracts unless you are intentionally changing public behavior.
- If tuning schema changes, update the related tests and docs in the same change.
