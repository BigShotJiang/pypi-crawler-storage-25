---
name: quality-gates
description: Use before finishing a change to verify behavior, contracts, and project hygiene.
---

# Quality gates

## Before you stop

- Run the project test suite if one exists.
- Re-read diffs for accidental scaffolding drift.
- Confirm `main.py` still imports cleanly as the execution entrypoint.
- Verify no legacy layout paths were introduced: `agent.py`, root `model.py`, `models/`, `workers/`, `core/`, root `engine.py`, root `vectors.py`.
- Verify command examples still use `ai push`.
- Verify README and `studio/article.mdx` still match the actual public modes.

## Minimum acceptable verification

- Import check for `main.py`
- `ai contract validate --json`
- One targeted smoke command when the change affects execution, publish, or tuning
