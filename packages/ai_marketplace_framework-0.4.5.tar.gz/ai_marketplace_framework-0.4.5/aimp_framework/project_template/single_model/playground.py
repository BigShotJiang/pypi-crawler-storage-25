"""Playground specifications for public modes.

Playground specs define how the Playground UI renders mode inputs and outputs.
Each spec is linked from its mode via Mode.playground.
"""

from __future__ import annotations

from aimp_sdk.playground import (
    Markdown,
    PlaygroundChat,
    PlaygroundSources,
    PlaygroundSpec,
    SectionRole,
    When,
    source,
)

from schemas import ExampleSchema


class ExamplePlayground(PlaygroundSpec):
    """Playground spec for the example mode."""

    chat = PlaygroundChat(
        ExampleSchema.Inputs.message,
    )
    sources = PlaygroundSources(
        history=source.chat_history(),
    )
    response = Markdown(
        ExampleSchema.Outputs.result,
        when=When.ALWAYS,
        role=SectionRole.PRIMARY,
        stream=True,
    )
