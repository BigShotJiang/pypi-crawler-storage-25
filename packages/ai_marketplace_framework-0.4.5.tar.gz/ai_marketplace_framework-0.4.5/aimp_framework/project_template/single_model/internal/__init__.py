"""Internal implementation package for {{PROJECT_NAME}} (loader, inference, vectors)."""
