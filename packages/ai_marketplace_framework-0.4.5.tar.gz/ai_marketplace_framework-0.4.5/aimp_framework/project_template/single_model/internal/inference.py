"""Vector resources and inference-side declarations for {{MODEL_KEY}}."""

from __future__ import annotations

from aimp_framework.base import Metric
from aimp_sdk import TextField, Vector


class {{MODEL_CLASS_NAME}}DocsVector(Vector):
    alias = "docs"
    name = "Documents"
    description = "Document embeddings for {{MODEL_KEY}}."
    dimension = 1536
    metric = Metric.COSINE

    text = TextField(required=True)
