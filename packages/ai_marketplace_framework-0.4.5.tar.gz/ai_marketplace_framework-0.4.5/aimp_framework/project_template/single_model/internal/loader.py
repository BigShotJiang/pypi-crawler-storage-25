"""Lifecycle-owned engine loading for {{MODEL_KEY}}."""

from __future__ import annotations

from aimp_framework import Engine


class {{MODEL_CLASS_NAME}}Engine(Engine):
    """Loads and tears down runtime resources for the model."""

    def load(self) -> None:
        self._loaded = True

    def teardown(self) -> None:
        self._loaded = False
