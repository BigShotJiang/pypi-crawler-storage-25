"""Public modes and model implementation for {{PROJECT_NAME}}."""

from __future__ import annotations

from aimp_sdk import Model, Stream, StreamState, mode

from internal.inference import {{MODEL_CLASS_NAME}}DocsVector
from internal.loader import {{MODEL_CLASS_NAME}}Engine
from playground import ExamplePlayground
from schemas import ExampleSchema
from tuning.runner import {{MODEL_CLASS_NAME}}Tuning


class {{MODEL_CLASS_NAME}}(Model):
    """Model implementation."""

    engine = {{MODEL_CLASS_NAME}}Engine
    tuning = {{MODEL_CLASS_NAME}}Tuning
    vectors = [{{MODEL_CLASS_NAME}}DocsVector]

    async def _answer(self, query: str, history: list[dict[str, str]]) -> str:
        _ = history
        return query.strip()

    @mode(
        name="example",
        label="Example",
        description="Runs the example mode.",
        playground=ExamplePlayground,
    )
    async def example(
        self,
        inputs: ExampleSchema.Inputs,
        params: ExampleSchema.Params,
    ) -> ExampleSchema.Outputs:
        _ = params
        answer = await self._answer(inputs.message, inputs.history or [])
        stream = Stream.text(
            text=ExampleSchema.Outputs.result,
            status=ExampleSchema.Outputs.status,
        )
        stream.status(StreamState.QUEUED)
        stream.status(StreamState.GENERATING, label="Generating")
        mid = max(1, len(answer) // 2)
        stream.write(answer[:mid])
        stream.write(answer[mid:])
        return stream.done(final_text=answer)
