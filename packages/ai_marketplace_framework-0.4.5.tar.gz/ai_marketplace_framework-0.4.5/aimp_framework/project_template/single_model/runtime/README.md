# Runtime image (`runtime/`)

This directory defines the **production container image** for your model: everything the platform builds when you run `ai push`.

## Allowed contents

- `Dockerfile` — the only supported publish image definition (built from the project root as context)
- `pyproject.toml` — Python dependencies installed into the runtime image
- Optional small runtime-only helpers that belong in the image (not model weights)

## Do not bake model assets here

Do **not** download Hugging Face checkpoints, tokenizer trees, large weight files, or other execution assets inside `runtime/Dockerfile` for production publish. That duplicates what belongs in the execution bundle, inflates image layers, and breaks the publish contract.

Put weights, processors, configs, adapters, and other execution assets under **`artifacts/`** at the project root. The platform materializes that bundle at run time to `MODEL_ARTIFACTS_DIR`.

## Local reference builds

For local-only or CI smoke images you may still experiment with Docker-only flows, but **`ai push` validates the production Dockerfile** and rejects patterns that materialize production model assets in the image.
