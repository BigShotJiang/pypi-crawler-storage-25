# {{PROJECT_NAME}}

Single-model project layout for the AI Marketplace.

## Structure

- `main.py` — the `Model` subclass and `@mode`-decorated public mode methods
- `schemas.py` — public mode inputs, outputs, and params (including optional chat `history`)
- `playground.py` — Playground specs referenced from modes
- `internal/` — internal loader (`internal/loader.py`), inference and vectors (`internal/inference.py`)
- `tuning/` — optional fine-tuning code (top-level package)
- `tests/` — project tests (e.g. `tests/test_model.py`)
- `runtime/` — production container image only (`Dockerfile`, `pyproject.toml`, `README.md`); see `runtime/README.md`
- `artifacts/` — execution asset bundle source for publish (`artifacts/artifact.py` prepares assets remotely; see `artifacts/README.md`)
- `pyproject.toml` — project metadata and dependencies

## Authoring rules

- Stream partial text with `Stream.text(...)` (see `main.py`); use direct `emit()` only for advanced custom streaming.
- `ai push` requires `runtime/Dockerfile` and `runtime/pyproject.toml`; the remote image is always built from that Dockerfile (no alternate publish image).
- Use the same `runtime/Dockerfile` for local `docker build` workflows.
- Do not download weights, datasets, or binaries during import, startup, or request handling.
- Do not hardcode hardware tiers; hardware is selected at `ai push` time.
