"""Framework artifact preparation entrypoint.

Remote publish runs ``python artifacts/artifact.py`` from the project root before the
execution bundle is packaged. Materialize model weights and other runtime assets
under ``artifacts/`` (this script may write only within that directory).
"""

from __future__ import annotations

from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent
    marker = root / ".execution_bundle_ready"
    marker.write_text("ok\n", encoding="utf-8")


if __name__ == "__main__":
    main()
