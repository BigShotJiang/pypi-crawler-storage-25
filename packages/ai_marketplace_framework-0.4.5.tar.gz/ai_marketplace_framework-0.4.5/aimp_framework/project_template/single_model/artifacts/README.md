# Execution artifacts (`artifacts/`)

This directory is the **source of the execution artifact bundle** for publish. The build packages `publish.artifact_path` (by default this folder) separately from the runtime image.

## `artifact.py` (required)

**`artifacts/artifact.py`** is the only framework entrypoint for preparing execution assets. On `ai push`, the build service runs `python artifacts/artifact.py` from the project root **before** bundling; it must materialize final runtime assets under `artifacts/`. Do not rely on separate prep scripts or manual steps.

Framework control files **`artifact.py`** and **`README.md`** are excluded from the uploaded bundle; everything else under `artifacts/` is packaged.

## What belongs here

- Model weights (checkpoints, safetensors, PyTorch binaries, etc.)
- Tokenizer and model config files (`config.json`, tokenizer assets, `preprocessor_config.json`, …)
- Processor assets and small metadata needed at inference time
- Adapter bundles (LoRA and similar), when applicable, unless declared under `publish.adapters` as separate paths

## Platform behavior

At execution time the platform materializes the uploaded bundle under **`MODEL_ARTIFACTS_DIR`** inside the container. Load models and assets from that path (or env vars derived from it), not from paths baked into `/opt/models/...` in the image.

Keep large binaries out of Git when possible; use your own storage or have `artifact.py` download from authenticated sources (tokens configured in the platform environment).
