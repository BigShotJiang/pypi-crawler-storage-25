"""Schema definitions for public modes.

Public schemas (mode contracts) are defined here.
These are used by modes for validation and typed handler I/O.
"""

from __future__ import annotations

from aimp_sdk import JsonField, MessagesField, Schema, TextField


class ExampleSchema:
    """Contract schema for the example mode."""

    class Inputs(Schema.Inputs):
        message = TextField(
            description="The current user message to process.",
            required=True,
        )
        history = MessagesField(
            description="Structured conversation history from the Playground or direct API clients.",
            required=False,
        )

    class Outputs(Schema.Outputs):
        result = TextField(required=True)
        status = JsonField(
            required=False,
            description="Optional streaming status object for progress UI.",
        )

    class Params(Schema.Params):
        """Optional execution knobs for the example mode."""
