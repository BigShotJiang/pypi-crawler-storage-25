"""Tuning metrics for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_sdk import Metric, TuneMetrics


class {{MODEL_CLASS_NAME}}Metrics(TuneMetrics):
    """Metrics produced by model tuning."""

    score = Metric(goal="maximize", description="Primary tuning quality score")
