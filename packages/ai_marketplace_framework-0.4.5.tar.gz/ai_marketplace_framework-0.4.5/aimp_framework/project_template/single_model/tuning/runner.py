"""Tuning runner for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_sdk import TuneResult, TunedResult, TuningSession

from internal.loader import {{MODEL_CLASS_NAME}}Engine

from .artifacts import {{MODEL_CLASS_NAME}}Artifacts
from .dataset import {{MODEL_CLASS_NAME}}DatasetSchema
from .hyperparams import {{MODEL_CLASS_NAME}}Hyperparams
from .metrics import {{MODEL_CLASS_NAME}}Metrics


class {{MODEL_CLASS_NAME}}Tuning:
    """Model-scoped tuning capability."""

    dataset_schema = {{MODEL_CLASS_NAME}}DatasetSchema
    artifacts_schema = {{MODEL_CLASS_NAME}}Artifacts
    metrics_schema = {{MODEL_CLASS_NAME}}Metrics
    hyperparams_schema = {{MODEL_CLASS_NAME}}Hyperparams
    materialization = {
        "strategy": "replace_root",
        "result_kind": "root_bundle",
        "required_artifacts": ["result"],
        "chaining": "replace",
    }
    supports_chaining = True

    async def run(
        self,
        session: TuningSession[{{MODEL_CLASS_NAME}}DatasetSchema, {{MODEL_CLASS_NAME}}Artifacts],
    ) -> TuneResult[{{MODEL_CLASS_NAME}}Artifacts, {{MODEL_CLASS_NAME}}Metrics]:
        _ = session
        return TuneResult(
            artifacts={{MODEL_CLASS_NAME}}Artifacts(
                result=session.artifacts.result.write_bytes(
                    b"placeholder-tuned-root",
                    filename="result.tar.gz",
                )
            ),
            metrics={{MODEL_CLASS_NAME}}Metrics(score=0.0),
        )

    async def apply(
        self,
        engine: {{MODEL_CLASS_NAME}}Engine,
        result: TunedResult[{{MODEL_CLASS_NAME}}Artifacts, {{MODEL_CLASS_NAME}}Metrics],
    ) -> None:
        _ = engine
        _ = result
