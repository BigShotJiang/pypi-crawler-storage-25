"""Tuning artifacts for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_sdk import FileArtifact, TuneArtifacts


class {{MODEL_CLASS_NAME}}Artifacts(TuneArtifacts):
    """Artifacts produced by model tuning."""

    result = FileArtifact(required=True, description="Runnable tuned result bundle")
