"""Tuning dataset schema for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_sdk import FineTuneSchema, TextField


class {{MODEL_CLASS_NAME}}DatasetSchema(FineTuneSchema):
    prompt = TextField(required=True, description="Training prompt text")
    completion = TextField(required=True, description="Expected completion text")
