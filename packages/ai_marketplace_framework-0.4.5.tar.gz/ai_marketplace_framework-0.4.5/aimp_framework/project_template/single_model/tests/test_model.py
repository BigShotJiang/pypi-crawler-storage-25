"""Smoke tests for the model package."""

from __future__ import annotations


def test_model_class_importable() -> None:
    from model import {{MODEL_CLASS_NAME}}

    assert {{MODEL_CLASS_NAME}}.__name__ == "{{MODEL_CLASS_NAME}}"
