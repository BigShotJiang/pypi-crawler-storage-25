from aimp_framework.base import ImageField, Schema, SelectField, TextField
from aimp_sdk import Model, mode


class MediaEngine:
    def load(self):
        return None


class CompareSchema:
    class Inputs(Schema.Inputs):
        image = ImageField(description="Input image")
        notes = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        output_format = SelectField(options=["json", "text"], default="json")


class CompareModel(Model):
    engine = MediaEngine

    @mode(name="compare")
    async def compare(
        self,
        inputs: CompareSchema.Inputs,
        params: CompareSchema.Params,
    ) -> CompareSchema.Outputs:
        _ = inputs
        _ = params
        return CompareSchema.Outputs.validate({"result": "ok"})
