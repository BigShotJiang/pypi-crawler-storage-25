from aimp_framework.base import Schema, TextField
from aimp_sdk import Model, mode


class ValidEngine:
    def load(self):
        return None


class SampleSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        pass


class SampleModel(Model):
    engine = ValidEngine

    @mode(name="sample")
    async def sample(
        self,
        inputs: SampleSchema.Inputs,
        params: SampleSchema.Params,
    ) -> SampleSchema.Outputs:
        _ = params
        return SampleSchema.Outputs.validate({"result": inputs.query})
