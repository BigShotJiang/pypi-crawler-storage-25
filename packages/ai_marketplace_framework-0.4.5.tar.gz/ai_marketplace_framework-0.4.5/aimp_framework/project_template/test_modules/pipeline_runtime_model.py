from __future__ import annotations

from aimp_sdk import IntegerField, Metric, Model, Schema, TextField, Vector, mode


class EmbedEngine:
    def load(self):
        return None


class EmbedInput(Schema):
    text = TextField(required=True)


class EmbedOutput(Schema):
    embedding = IntegerField(required=True, multiple=True)


class DocsVector(Vector):
    alias = "docs"
    name = "Documents"
    description = "Document embeddings used by vector-backed modes."
    dimension = 1536
    metric = Metric.COSINE
    text = TextField(required=True)


class SearchSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        results = TextField(required=True, multiple=True)
        count = IntegerField(required=True)

    class Params(Schema.Params):
        top_k = IntegerField(default=5, min=1, max=20)


class IndexSchema:
    class Inputs(Schema.Inputs):
        items = TextField(required=True, multiple=True)

    class Outputs(Schema.Outputs):
        indexed = IntegerField(required=True)

    class Params(Schema.Params):
        pass


class EmbedModel(Model):
    engine = EmbedEngine
    vectors = [DocsVector]

    @mode(name="search")
    async def search(
        self,
        inputs: SearchSchema.Inputs,
        params: SearchSchema.Params,
    ) -> SearchSchema.Outputs:
        runtime = self._mode_runtime
        query_len = len(inputs.query)
        ordered = sorted(runtime._rows, key=lambda item: abs(len(item) - query_len))
        top_k = params.top_k if params is not None else 5
        hits = ordered[:top_k]
        return {"results": hits, "count": len(hits)}

    @mode(name="find")
    async def find(
        self,
        inputs: IndexSchema.Inputs,
        params: IndexSchema.Params,
    ) -> IndexSchema.Outputs:
        runtime = self._mode_runtime
        runtime._rows.extend(list(inputs.items))
        return {"indexed": len(inputs.items)}


_rows: list[str] = []
