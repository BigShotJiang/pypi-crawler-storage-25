from aimp_framework.base import Schema, TextField
from aimp_sdk import Model, mode


class GenEngine:
    def load(self):
        return None


class GenerateSchema:
    class Inputs(Schema.Inputs):
        input_data = TextField(description="Primary input")

    class Outputs(Schema.Outputs):
        ok = TextField(required=True)

    class Params(Schema.Params):
        pass


class GenerateModel(Model):
    engine = GenEngine

    @mode(name="generate")
    async def generate(
        self,
        inputs: GenerateSchema.Inputs,
        params: GenerateSchema.Params,
    ) -> GenerateSchema.Outputs:
        _ = params
        return GenerateSchema.Outputs.validate({"ok": "yes"})
