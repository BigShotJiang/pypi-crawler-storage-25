from aimp_framework.base import Schema, TextField
from aimp_sdk import Model, mode


class DupEngine:
    def load(self):
        return None


class Shared:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        pass


class DupModel(Model):
    engine = DupEngine

    @mode(name="search")
    async def first(
        self,
        inputs: Shared.Inputs,
        params: Shared.Params,
    ) -> Shared.Outputs:
        _ = params
        return Shared.Outputs.validate({"result": inputs.query})

    @mode(name="search")
    async def second(
        self,
        inputs: Shared.Inputs,
        params: Shared.Params,
    ) -> Shared.Outputs:
        _ = params
        return Shared.Outputs.validate({"result": inputs.query})
