from aimp_sdk import Model


class MissingEngine:
    def load(self):
        return None


class MissingModel(Model):
    engine = MissingEngine
