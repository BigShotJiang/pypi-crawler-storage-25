from __future__ import annotations

from aimp_framework.base import IntegerField, ListField, NumberField, Schema, StringField, TextField
from aimp_sdk import Model, mode


class ListEngine:
    def load(self):
        return None


class SearchSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        matches = ListField(
            item_schema={
                "image_id": StringField(),
                "filename": StringField(),
                "score": NumberField(),
            },
            required=True,
        )
        count = IntegerField(required=True)

    class Params(Schema.Params):
        pass


class ListModel(Model):
    engine = ListEngine

    @mode(name="search")
    async def search(
        self,
        inputs: SearchSchema.Inputs,
        params: SearchSchema.Params,
    ) -> SearchSchema.Outputs:
        _ = params
        query = inputs.query.strip() or "query"
        return {
            "matches": [
                {
                    "image_id": f"{query}-1",
                    "filename": f"{query}.png",
                    "score": 0.91,
                }
            ],
            "count": 1,
        }
