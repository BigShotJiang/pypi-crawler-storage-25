import json
import os
import glob
from datetime import datetime, timedelta, timezone


class CowrieLogParser:
    """Parse Cowrie JSON log files."""

    def __init__(self, log_path=None, days=7):
        self.log_path = log_path or self._default_path()
        self.days = days
        self.cutoff = datetime.now(timezone.utc) - timedelta(days=days)

    def _default_path(self):
        candidates = [
            "/var/lib/docker/volumes/cowrie-var/_data/log/cowrie/",
            "/var/lib/docker/volumes/cowrie-var-22222/_data/log/cowrie/",
            "/home/cowrie/cowrie-git/var/log/cowrie/",
            "./",
        ]
        for c in candidates:
            if os.path.isdir(c):
                jsons = glob.glob(os.path.join(c, "cowrie.json*"))
                if jsons:
                    return c
        return "./"

    def load(self):
        events = []

        if os.path.isdir(self.log_path):
            files = sorted(glob.glob(os.path.join(self.log_path, "cowrie.json*")))
        elif os.path.isfile(self.log_path):
            files = [self.log_path]
        else:
            return events

        for filepath in files:
            events.extend(self._parse_file(filepath))

        return events

    def _parse_file(self, filepath):
        events = []
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                        ts = self._parse_timestamp(event.get("timestamp", ""))
                        if ts and ts >= self.cutoff:
                            event["_ts"] = ts
                            events.append(event)
                    except json.JSONDecodeError:
                        continue
        except (IOError, OSError):
            pass
        return events

    def _parse_timestamp(self, ts_str):
        if not ts_str:
            return None
        for fmt in (
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S",
        ):
            try:
                return datetime.strptime(ts_str, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
        return None
