"""Behavioral flag definitions and threat scoring."""

import re
from collections import Counter

# Known default credentials
DEFAULT_CREDS = {
    ("root", "root"), ("root", "admin"), ("root", "password"), ("root", "123456"),
    ("root", "toor"), ("root", "1234"), ("root", "12345"), ("root", "123456789"),
    ("root", "changeme"), ("root", "default"), ("root", "letmein"), ("root", "master"),
    ("admin", "admin"), ("admin", "password"), ("admin", "1234"), ("admin", "admin123"),
    ("ubuntu", "ubuntu"), ("pi", "raspberry"), ("pi", "raspberrpi"),
    ("test", "test"), ("guest", "guest"), ("user", "user"), ("oracle", "oracle"),
    ("postgres", "postgres"), ("deploy", "deploy"), ("ftpuser", "ftpuser"),
    ("ubnt", "ubnt"), ("support", "support"), ("nagios", "nagios"),
}

# Known scanner user agents
KNOWN_SCANNERS = ["zgrab", "censys", "shodan", "masscan", "nmap"]

# Known VPS/cloud ASN keywords
VPS_PROVIDERS = [
    "digitalocean", "amazon", "aws", "hetzner", "ovh", "linode", "vultr",
    "contabo", "choopa", "akamai", "google cloud", "microsoft", "azure",
    "oracle cloud", "alibaba", "tencent",
]

# Malware indicators in commands
MALWARE_PATTERNS = [
    r"chmod\s+\+x",
    r"wget\s+http",
    r"curl\s+http.*\|\s*sh",
    r"curl\s+http.*\|\s*bash",
    r"nohup\s+\./",
    r"/tmp/.*&&.*chmod",
    r"base64\s+-d",
]

# Worm indicators
WORM_PATTERNS = [
    r"(\d{1,3}\.){3}\d{1,3}.*(\d{1,3}\.){3}\d{1,3}.*(\d{1,3}\.){3}\d{1,3}",  # 3+ IPs in one command
]

# Reverse shell patterns
REVERSE_SHELL_PATTERNS = [
    r"bash\s+-i\s+>&\s*/dev/tcp",
    r"nc\s+-e\s+/bin",
    r"python.*import\s+socket.*connect",
    r"perl.*socket.*connect",
    r"php.*fsockopen",
    r"mkfifo.*nc\s",
]

# Recon commands
RECON_COMMANDS = {"uname", "whoami", "id", "pwd", "hostname", "ifconfig", "ip addr", "cat /etc/issue"}

# Credential hunting targets
CREDENTIAL_TARGETS = [
    ".env", "credentials", ".aws", ".ssh/id_rsa", ".ssh/id_ed25519",
    ".gitconfig", ".npmrc", ".docker/config", ".kube/config",
    "shadow", ".mysql_history", ".psql_history", ".bash_history",
    "wp-config.php", "config.php", ".htpasswd",
]

# Crypto hunting targets
CRYPTO_TARGETS = [
    "bitcoin", "ethereum", "wallet", "seed", ".electrum",
    "monero", "crypto", "metamask", "keystore",
]

# Privilege escalation indicators
PRIV_ESC_PATTERNS = [
    r"\bsudo\b", r"\bsu\s", r"find.*-perm.*4000", r"find.*suid",
    r"cat.*/etc/shadow", r"getcap", r"linpeas", r"linenum",
]

# Log cleanup indicators
LOG_CLEANUP_PATTERNS = [
    r"rm.*(/var/log|/var/run/utmp|\.bash_history|/tmp/)",
    r"history\s+-c", r"unset\s+HISTFILE", r"export\s+HISTFILE=/dev/null",
    r"shred\b", r">/var/log",
]

# Lateral movement
LATERAL_PATTERNS = [
    r"\bssh\s+\w+@", r"\bscp\s", r"\brsync\s.*@",
]

# Data exfiltration
EXFIL_PATTERNS = [
    r"tar.*\|.*curl", r"tar.*\|.*nc\s", r"zip.*&&.*(curl|wget|scp)",
    r"curl.*-T\s", r"curl.*--upload",
]

# Crypto miner indicators
MINER_PATTERNS = [
    r"xmrig", r"stratum\+tcp", r"pool\.", r"minerd",
    r"cpuminer", r"ethminer", r"nicehash",
]

# SSH library identifiers (automated tools)
SSH_LIBRARIES = ["paramiko", "libssh", "golang", "go", "asyncssh", "jsch", "putty"]

# Threat score weights
THREAT_SCORES = {
    "RECON": 1,
    "DEFAULT_CREDS": 1,
    "BRUTE_FORCE": 2,
    "SPRAY_ATTACK": 2,
    "DICTIONARY_ATTACK": 2,
    "CREDENTIAL_STUFFING": 3,
    "LEAKED_DB": 3,
    "CREDENTIAL_HARVEST": 3,
    "CRYPTO_HUNT": 3,
    "LOG_CLEANUP": 3,
    "PRIV_ESC": 3,
    "LATERAL_MOVEMENT": 3,
    "MINER_INSTALL": 4,
    "DATA_EXFIL": 4,
    "MALWARE_DROP": 5,
    "WORM_SPREAD": 5,
    "REVERSE_SHELL": 5,
    "RANSOMWARE_PREP": 5,
    "SCHEDULED_SCAN": 1,
    "BURST_ATTACK": 2,
    "SLOW_AND_LOW": 2,
    "24_7_BOT": 1,
    "BUSINESS_HOURS": 0,
    "HIT_AND_RUN": 1,
    "PERSISTENT": 2,
    "REPEAT_OFFENDER": 2,
    "HONEYPOT_AWARE": 2,
    "KNOWN_SCANNER": 0,
    "VPS_HOSTED": 0,
    "SSH_LIBRARY": 1,
    "TOR_EXIT": 1,
}


def threat_level(score):
    if score >= 10:
        return "CRITICAL", "🔴"
    elif score >= 7:
        return "HIGH", "🟠"
    elif score >= 4:
        return "MEDIUM", "🟡"
    else:
        return "LOW", "🟢"


def _match_any(text, patterns):
    for p in patterns:
        if re.search(p, text, re.IGNORECASE):
            return True
    return False


def detect_login_flags(sessions_for_ip):
    """Detect flags based on login behavior."""
    flags = set()

    all_passwords = []
    all_usernames = []
    successful_logins = []

    for s in sessions_for_ip:
        for login in s.get("logins", []):
            user = login.get("username", "")
            pwd = login.get("password", "")
            success = login.get("success", False)
            all_passwords.append(pwd)
            all_usernames.append(user)
            if success:
                successful_logins.append(login)

            if (user, pwd) in DEFAULT_CREDS:
                flags.add("DEFAULT_CREDS")

    unique_passwords = set(all_passwords)
    unique_usernames = set(all_usernames)

    # Brute force: 5+ different passwords
    if len(unique_passwords) >= 5:
        flags.add("BRUTE_FORCE")

    # Spray attack: same password, multiple usernames
    if len(unique_usernames) >= 3:
        pwd_counts = Counter(all_passwords)
        for pwd, count in pwd_counts.items():
            if count >= 3:
                flags.add("SPRAY_ATTACK")
                break

    # Dictionary attack: passwords appear alphabetically ordered
    if len(all_passwords) >= 5:
        sorted_pwds = sorted(all_passwords)
        if all_passwords == sorted_pwds:
            flags.add("DICTIONARY_ATTACK")

    # Credential stuffing: complex password, single attempt, success
    if len(unique_passwords) == 1 and len(successful_logins) == 1:
        pwd = all_passwords[0]
        has_upper = any(c.isupper() for c in pwd)
        has_special = any(not c.isalnum() for c in pwd)
        if len(pwd) >= 8 and (has_upper or has_special):
            flags.add("CREDENTIAL_STUFFING")

    # Leaked DB pattern: email-like or site:pass format
    for pwd in all_passwords:
        if "@" in pwd or ":" in pwd:
            flags.add("LEAKED_DB")
            break

    return flags


def detect_timing_flags(sessions_for_ip):
    """Detect flags based on timing patterns."""
    flags = set()

    if len(sessions_for_ip) < 2:
        if len(sessions_for_ip) == 1:
            flags.add("HIT_AND_RUN")
        return flags

    timestamps = sorted(s["connect_time"] for s in sessions_for_ip if "connect_time" in s)

    if len(timestamps) < 2:
        return flags

    # Calculate intervals
    intervals = []
    for i in range(1, len(timestamps)):
        delta = (timestamps[i] - timestamps[i - 1]).total_seconds()
        intervals.append(delta)

    if not intervals:
        return flags

    avg_interval = sum(intervals) / len(intervals)

    # Scheduled scan: consistent intervals (std dev < 20% of mean)
    if len(intervals) >= 3 and avg_interval > 60:
        mean = avg_interval
        variance = sum((x - mean) ** 2 for x in intervals) / len(intervals)
        std_dev = variance ** 0.5
        if mean > 0 and std_dev / mean < 0.2:
            flags.add("SCHEDULED_SCAN")

    # Burst attack: 10+ connections within 1 minute
    for i, delta in enumerate(intervals):
        if delta < 60:
            burst_count = 1
            j = i
            while j < len(intervals) and intervals[j] < 60:
                burst_count += 1
                j += 1
            if burst_count >= 10:
                flags.add("BURST_ATTACK")
                break

    # 24/7 bot: connections across all hours
    hours = set(t.hour for t in timestamps)
    if len(hours) >= 18:
        flags.add("24_7_BOT")

    # Business hours: only 9-17
    if all(9 <= t.hour <= 17 for t in timestamps) and len(timestamps) >= 3:
        flags.add("BUSINESS_HOURS")

    # Persistent: spans 3+ days
    if timestamps:
        span = (timestamps[-1] - timestamps[0]).days
        if span >= 3:
            flags.add("PERSISTENT")

    # Hit and run with login: logged in, never came back
    has_login = any(s.get("logins") for s in sessions_for_ip)
    if has_login and len(sessions_for_ip) <= 2:
        last_had_login = any(s.get("logins") for s in sessions_for_ip[-1:])
        if last_had_login:
            flags.add("HIT_AND_RUN")

    return flags


def detect_command_flags(sessions_for_ip):
    """Detect flags based on commands executed."""
    flags = set()

    all_commands = []
    for s in sessions_for_ip:
        all_commands.extend(s.get("commands", []))

    if not all_commands:
        return flags

    combined = " ".join(all_commands)
    combined_lower = combined.lower()

    # Recon
    recon_count = sum(1 for cmd in all_commands if cmd.strip().split()[0] in RECON_COMMANDS)
    if recon_count > 0 and recon_count == len(all_commands):
        flags.add("RECON")

    # Credential harvest
    for target in CREDENTIAL_TARGETS:
        if target in combined_lower:
            flags.add("CREDENTIAL_HARVEST")
            break

    # Crypto hunt
    for target in CRYPTO_TARGETS:
        if target in combined_lower:
            flags.add("CRYPTO_HUNT")
            break

    # Malware drop
    if _match_any(combined, MALWARE_PATTERNS):
        flags.add("MALWARE_DROP")

    # Worm spread
    if _match_any(combined, WORM_PATTERNS):
        flags.add("WORM_SPREAD")

    # Reverse shell
    if _match_any(combined, REVERSE_SHELL_PATTERNS):
        flags.add("REVERSE_SHELL")

    # Privilege escalation
    if _match_any(combined, PRIV_ESC_PATTERNS):
        flags.add("PRIV_ESC")

    # Log cleanup
    if _match_any(combined, LOG_CLEANUP_PATTERNS):
        flags.add("LOG_CLEANUP")

    # Lateral movement
    if _match_any(combined, LATERAL_PATTERNS):
        flags.add("LATERAL_MOVEMENT")

    # Data exfiltration
    if _match_any(combined, EXFIL_PATTERNS):
        flags.add("DATA_EXFIL")

    # Crypto miner
    if _match_any(combined, MINER_PATTERNS):
        flags.add("MINER_INSTALL")

    # Ransomware prep
    if re.search(r"find\s+/.*-name.*\.(sql|db|sqlite|mdb|bak)", combined, re.IGNORECASE):
        flags.add("RANSOMWARE_PREP")

    return flags


def detect_identity_flags(sessions_for_ip):
    """Detect flags based on client identity."""
    flags = set()

    for s in sessions_for_ip:
        version = s.get("client_version", "").lower()

        # Known scanner
        for scanner in KNOWN_SCANNERS:
            if scanner in version:
                flags.add("KNOWN_SCANNER")
                break

        # SSH library (automated tool)
        for lib in SSH_LIBRARIES:
            if lib in version:
                flags.add("SSH_LIBRARY")
                break

    return flags


def detect_session_flags(sessions_for_ip):
    """Detect honeypot awareness and other session-level flags."""
    flags = set()

    successful_sessions = [s for s in sessions_for_ip if s.get("logged_in")]
    post_login_sessions = []

    if successful_sessions:
        last_login_time = max(s["connect_time"] for s in successful_sessions if "connect_time" in s)
        post_login_sessions = [
            s for s in sessions_for_ip
            if "connect_time" in s and s["connect_time"] > last_login_time
        ]

        # Honeypot aware: logged in successfully but commands were empty/minimal,
        # and came back without logging in or never came back
        for s in successful_sessions:
            cmds = s.get("commands", [])
            if len(cmds) == 0 and post_login_sessions:
                post_logins = [ps for ps in post_login_sessions if ps.get("logged_in")]
                if not post_logins:
                    flags.add("HONEYPOT_AWARE")

    return flags


def detect_all_flags(sessions_for_ip):
    """Run all flag detectors and return flags with threat score."""
    all_flags = set()
    all_flags.update(detect_login_flags(sessions_for_ip))
    all_flags.update(detect_timing_flags(sessions_for_ip))
    all_flags.update(detect_command_flags(sessions_for_ip))
    all_flags.update(detect_identity_flags(sessions_for_ip))
    all_flags.update(detect_session_flags(sessions_for_ip))

    score = sum(THREAT_SCORES.get(f, 0) for f in all_flags)
    level, icon = threat_level(score)

    return {
        "flags": sorted(all_flags),
        "score": score,
        "level": level,
        "icon": icon,
    }
