"""IP geolocation using free ipinfo.io API (no key required for basic lookups)."""

import json
import os
import time

_cache = {}
_CACHE_FILE = os.path.expanduser("~/.honeyscope_geocache.json")


def _load_cache():
    global _cache
    if _cache:
        return
    try:
        with open(_CACHE_FILE, "r") as f:
            _cache = json.load(f)
    except (IOError, json.JSONDecodeError):
        _cache = {}


def _save_cache():
    try:
        with open(_CACHE_FILE, "w") as f:
            json.dump(_cache, f)
    except IOError:
        pass


def lookup_ip(ip):
    """Look up IP geolocation. Returns dict with country, city, org."""
    _load_cache()

    if ip in _cache:
        return _cache[ip]

    try:
        import requests
        resp = requests.get(f"https://ipinfo.io/{ip}/json", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            result = {
                "country": data.get("country", "??"),
                "city": data.get("city", "Unknown"),
                "org": data.get("org", ""),
                "region": data.get("region", ""),
            }
            _cache[ip] = result
            _save_cache()
            return result
    except Exception:
        pass

    return {"country": "??", "city": "Unknown", "org": "", "region": ""}
