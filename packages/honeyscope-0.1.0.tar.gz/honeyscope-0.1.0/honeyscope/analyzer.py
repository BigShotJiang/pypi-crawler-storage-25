"""Build sessions from raw Cowrie events and run flag detection."""

from collections import defaultdict
from honeyscope.flags import detect_all_flags


class SessionAnalyzer:
    """Group events into sessions, extract per-IP summaries, detect flags."""

    def __init__(self, events):
        self.events = sorted(events, key=lambda e: e.get("timestamp", ""))

    def analyze(self):
        raw_sessions = self._build_sessions()
        ip_sessions = self._group_by_ip(raw_sessions)
        results = {}

        for ip, sessions in ip_sessions.items():
            flag_result = detect_all_flags(sessions)
            results[ip] = {
                "ip": ip,
                "sessions": sessions,
                "session_count": len(sessions),
                "first_seen": min((s["connect_time"] for s in sessions if "connect_time" in s), default=None),
                "last_seen": max((s["connect_time"] for s in sessions if "connect_time" in s), default=None),
                "total_commands": sum(len(s.get("commands", [])) for s in sessions),
                "unique_passwords": list(set(
                    login.get("password", "")
                    for s in sessions
                    for login in s.get("logins", [])
                )),
                "unique_usernames": list(set(
                    login.get("username", "")
                    for s in sessions
                    for login in s.get("logins", [])
                )),
                "client_versions": list(set(
                    s.get("client_version", "") for s in sessions if s.get("client_version")
                )),
                "commands": [
                    cmd for s in sessions for cmd in s.get("commands", [])
                ],
                "logged_in": any(s.get("logged_in") for s in sessions),
                **flag_result,
            }

        return results

    def _build_sessions(self):
        sessions = {}

        for event in self.events:
            sid = event.get("session", "")
            if not sid:
                continue

            if sid not in sessions:
                sessions[sid] = {
                    "session_id": sid,
                    "src_ip": event.get("src_ip", ""),
                    "logins": [],
                    "commands": [],
                    "downloads": [],
                    "client_version": "",
                    "hassh": "",
                    "duration": 0,
                    "logged_in": False,
                    "connect_time": None,
                }

            s = sessions[sid]
            eid = event.get("eventid", "")
            ts = event.get("_ts")

            if eid == "cowrie.session.connect":
                s["src_ip"] = event.get("src_ip", s["src_ip"])
                s["connect_time"] = ts

            elif eid == "cowrie.client.version":
                s["client_version"] = event.get("version", "")

            elif eid == "cowrie.client.kex":
                s["hassh"] = event.get("hassh", "")

            elif eid in ("cowrie.login.success", "cowrie.login.failed"):
                s["logins"].append({
                    "username": event.get("username", ""),
                    "password": event.get("password", ""),
                    "success": eid == "cowrie.login.success",
                })
                if eid == "cowrie.login.success":
                    s["logged_in"] = True

            elif eid == "cowrie.command.input":
                cmd = event.get("input", "")
                if cmd:
                    s["commands"].append(cmd)

            elif eid == "cowrie.session.file_download":
                s["downloads"].append({
                    "url": event.get("url", ""),
                    "destfile": event.get("destfile", ""),
                    "shasum": event.get("shasum", ""),
                })

            elif eid == "cowrie.session.closed":
                s["duration"] = event.get("duration", 0)

        return list(sessions.values())

    def _group_by_ip(self, sessions):
        grouped = defaultdict(list)
        for s in sessions:
            ip = s.get("src_ip", "")
            if ip and not ip.startswith("172.17."):  # skip docker internal
                grouped[ip].append(s)
        return dict(grouped)
