import argparse
import sys

from honeyscope.parser import CowrieLogParser
from honeyscope.analyzer import SessionAnalyzer
from honeyscope.commands import report, track, live, passwords, geo, commands, malware, repeat_offenders


def create_parser():
    parser = argparse.ArgumentParser(
        prog="honeyscope",
        description="Smart Cowrie honeypot log analyzer with behavioral threat detection",
    )
    parser.add_argument("--version", action="version", version="%(prog)s 0.1.0")
    parser.add_argument("--exclude-ip", action="append", default=[], help="Exclude IP(s) from analysis (e.g. your own IP)")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # report
    p = sub.add_parser("report", help="Summary report of honeypot activity")
    p.add_argument("--days", type=int, default=7, help="Number of days to analyze (default: 7)")
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")
    p.add_argument("--format", "-f", choices=["text", "json", "markdown"], default="text")

    # track
    p = sub.add_parser("track", help="Deep analysis of a specific IP address")
    p.add_argument("ip", help="IP address to track")
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")

    # live
    p = sub.add_parser("live", help="Live monitoring of honeypot activity")
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file")
    p.add_argument("--notify", choices=["telegram", "slack"], help="Send notifications")
    p.add_argument("--telegram-token", help="Telegram bot token")
    p.add_argument("--telegram-chat", help="Telegram chat ID")

    # passwords
    p = sub.add_parser("passwords", help="Most attempted passwords")
    p.add_argument("--top", type=int, default=20, help="Number of passwords to show (default: 20)")
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")
    p.add_argument("--days", type=int, default=7)

    # geo
    p = sub.add_parser("geo", help="Geographic distribution of attackers")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")

    # commands
    p = sub.add_parser("commands", help="Commands executed by attackers")
    p.add_argument("--days", type=int, default=7)
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")

    # malware
    p = sub.add_parser("malware", help="Malware download attempts")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")

    # repeat-offenders
    p = sub.add_parser("repeat-offenders", help="Recurring attackers analysis")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--min-visits", type=int, default=3, help="Minimum visits to qualify (default: 3)")
    p.add_argument("--log", "-l", help="Path to Cowrie JSON log file or directory")

    return parser


def main():
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    log_path = getattr(args, "log", None)
    days = getattr(args, "days", 7)

    log_parser = CowrieLogParser(log_path, days=days)
    events = log_parser.load()

    if not events:
        print("No events found. Check your log path or --days value.")
        sys.exit(1)

    analyzer = SessionAnalyzer(events)
    sessions = analyzer.analyze()

    for ip in args.exclude_ip:
        sessions.pop(ip, None)

    cmd_map = {
        "report": report.run,
        "track": track.run,
        "live": live.run,
        "passwords": passwords.run,
        "geo": geo.run,
        "commands": commands.run,
        "malware": malware.run,
        "repeat-offenders": repeat_offenders.run,
    }

    cmd_func = cmd_map.get(args.command)
    if cmd_func:
        cmd_func(args, sessions, events)


if __name__ == "__main__":
    main()
