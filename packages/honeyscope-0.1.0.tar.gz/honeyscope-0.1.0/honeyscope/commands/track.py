"""Deep analysis of a specific IP address."""

from honeyscope.geo import lookup_ip


def run(args, sessions, events):
    ip = args.ip

    if ip not in sessions:
        print(f"IP {ip} not found in logs.")
        return

    data = sessions[ip]
    info = lookup_ip(ip)

    print(f"\n{'='*60}")
    print(f"  TRACKING: {ip}")
    print(f"{'='*60}")

    print(f"\n  Location:   {info.get('city', '?')}, {info.get('country', '??')}")
    print(f"  ISP/Org:    {info.get('org', 'Unknown')}")
    print(f"  First seen: {data['first_seen']}")
    print(f"  Last seen:  {data['last_seen']}")
    print(f"  Sessions:   {data['session_count']}")
    print(f"  Logged in:  {'Yes' if data['logged_in'] else 'No'}")

    print(f"\n  Threat: {data['icon']} {data['level']} (score: {data['score']})")
    print(f"  Flags:  {', '.join(data['flags'])}")

    if data["client_versions"]:
        print(f"\n  SSH clients:")
        for v in data["client_versions"]:
            print(f"    {v}")

    if data["unique_passwords"]:
        print(f"\n  Passwords tried:")
        for pwd in data["unique_passwords"]:
            if pwd:
                print(f"    {pwd}")

    if data["commands"]:
        print(f"\n  Commands executed:")
        for cmd in data["commands"]:
            print(f"    $ {cmd}")

    # Timeline
    print(f"\n  Timeline:")
    for s in sorted(data["sessions"], key=lambda x: x.get("connect_time") or ""):
        ts = s.get("connect_time")
        if not ts:
            continue
        ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
        duration = s.get("duration", 0)
        try:
            duration = float(duration)
        except (TypeError, ValueError):
            duration = 0.0
        login_str = ""
        for login in s.get("logins", []):
            status = "OK" if login["success"] else "FAIL"
            login_str = f" LOGIN {status}: {login['username']}/{login['password']}"
        cmd_str = ""
        if s.get("commands"):
            cmd_str = f" CMD: {s['commands'][0]}"
            if len(s["commands"]) > 1:
                cmd_str += f" (+{len(s['commands'])-1} more)"
        print(f"    {ts_str} [{duration:.1f}s]{login_str}{cmd_str}")

    # Downloads
    downloads = [d for s in data["sessions"] for d in s.get("downloads", [])]
    if downloads:
        print(f"\n  Downloads:")
        for dl in downloads:
            print(f"    URL: {dl.get('url', 'N/A')}")
            print(f"    SHA: {dl.get('shasum', 'N/A')}")

    print(f"\n{'='*60}\n")
