"""Repeat offenders analysis."""

from honeyscope.geo import lookup_ip


def run(args, sessions, events):
    min_visits = getattr(args, "min_visits", 3)

    repeaters = {
        ip: data for ip, data in sessions.items()
        if data["session_count"] >= min_visits
    }

    repeaters = dict(sorted(repeaters.items(), key=lambda x: x[1]["session_count"], reverse=True))

    print(f"\n{'='*60}")
    print(f"  REPEAT OFFENDERS (min {min_visits} visits)")
    print(f"{'='*60}")

    if not repeaters:
        print(f"\n  No repeat offenders found.")
        print(f"\n{'='*60}\n")
        return

    print(f"\n  Found: {len(repeaters)} repeat offenders\n")

    for ip, data in repeaters.items():
        info = lookup_ip(ip)
        country = info.get("country", "??")
        org = info.get("org", "")

        first = data["first_seen"]
        last = data["last_seen"]
        span = ""
        if first and last:
            days = (last - first).days
            hours = (last - first).total_seconds() / 3600
            if days > 0:
                span = f"{days}d"
            else:
                span = f"{hours:.1f}h"

        # Calculate average interval
        timestamps = sorted(s.get("connect_time") for s in data["sessions"] if s.get("connect_time"))
        avg_interval = ""
        if len(timestamps) >= 2:
            intervals = [(timestamps[i+1] - timestamps[i]).total_seconds() / 60 for i in range(len(timestamps)-1)]
            avg_min = sum(intervals) / len(intervals)
            if avg_min >= 60:
                avg_interval = f"~{avg_min/60:.0f}h apart"
            else:
                avg_interval = f"~{avg_min:.0f}m apart"

        print(f"  {data['icon']} {ip} ({country})")
        print(f"    Sessions: {data['session_count']} over {span} {avg_interval}")
        if org:
            print(f"    Org: {org}")
        print(f"    Flags: {', '.join(data['flags'])}")
        if data["unique_passwords"]:
            pwds = [p for p in data["unique_passwords"] if p]
            if pwds:
                print(f"    Passwords: {', '.join(pwds[:5])}")
        if data["commands"]:
            print(f"    Commands: {len(data['commands'])}")
        print()

    print(f"{'='*60}\n")
