"""Password analysis command."""

from collections import Counter


def run(args, sessions, events):
    top_n = getattr(args, "top", 20)

    all_passwords = []
    all_usernames = []
    combos = []

    for data in sessions.values():
        for s in data["sessions"]:
            for login in s.get("logins", []):
                pwd = login.get("password", "")
                user = login.get("username", "")
                if pwd:
                    all_passwords.append(pwd)
                if user:
                    all_usernames.append(user)
                if user and pwd:
                    combos.append(f"{user}/{pwd}")

    pwd_counts = Counter(all_passwords)
    user_counts = Counter(all_usernames)
    combo_counts = Counter(combos)

    # Password complexity analysis
    simple = 0
    medium = 0
    complex_count = 0
    for pwd in set(all_passwords):
        score = 0
        if len(pwd) >= 8:
            score += 1
        if any(c.isupper() for c in pwd):
            score += 1
        if any(c.isdigit() for c in pwd):
            score += 1
        if any(not c.isalnum() for c in pwd):
            score += 1
        if score <= 1:
            simple += 1
        elif score <= 2:
            medium += 1
        else:
            complex_count += 1

    print(f"\n{'='*60}")
    print(f"  PASSWORD ANALYSIS")
    print(f"{'='*60}")

    print(f"\n  Total attempts: {len(all_passwords)}")
    print(f"  Unique passwords: {len(set(all_passwords))}")
    print(f"  Unique usernames: {len(set(all_usernames))}")

    print(f"\n  Complexity:")
    print(f"    Simple (weak):  {simple}")
    print(f"    Medium:         {medium}")
    print(f"    Complex:        {complex_count}")

    print(f"\n  Top {top_n} passwords:")
    for pwd, count in pwd_counts.most_common(top_n):
        bar = "█" * min(count, 30)
        print(f"    {pwd:<30s} {count:>4d}  {bar}")

    print(f"\n  Top usernames:")
    for user, count in user_counts.most_common(10):
        print(f"    {user:<20s} {count:>4d}")

    print(f"\n  Top combos:")
    for combo, count in combo_counts.most_common(10):
        print(f"    {combo:<40s} {count:>4d}")

    print(f"\n{'='*60}\n")
