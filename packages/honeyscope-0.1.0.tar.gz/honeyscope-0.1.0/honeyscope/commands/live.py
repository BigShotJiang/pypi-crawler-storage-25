"""Live monitoring command."""

import json
import time
import sys
import os
from datetime import datetime, timezone

from honeyscope.flags import (
    DEFAULT_CREDS, MALWARE_PATTERNS, REVERSE_SHELL_PATTERNS,
    MINER_PATTERNS, CREDENTIAL_TARGETS, _match_any,
)
from honeyscope.geo import lookup_ip


def run(args, sessions, events):
    log_path = getattr(args, "log", None)
    notify = getattr(args, "notify", None)
    tg_token = getattr(args, "telegram_token", None) or os.environ.get("HONEYSCOPE_TG_TOKEN", "")
    tg_chat = getattr(args, "telegram_chat", None) or os.environ.get("HONEYSCOPE_TG_CHAT", "")

    if not log_path:
        candidates = [
            "/var/lib/docker/volumes/cowrie-var/_data/log/cowrie/cowrie.json",
            "/var/lib/docker/volumes/cowrie-var-22222/_data/log/cowrie/cowrie.json",
            "/home/cowrie/cowrie-git/var/log/cowrie/cowrie.json",
        ]
        for c in candidates:
            if os.path.isfile(c):
                log_path = c
                break

    if not log_path or not os.path.isfile(log_path):
        print("Cannot find active cowrie.json for live monitoring.")
        print("Use --log to specify the path.")
        sys.exit(1)

    print(f"Monitoring: {log_path}")
    print("Press Ctrl+C to stop.\n")

    try:
        with open(log_path, "r") as f:
            f.seek(0, 2)  # go to end
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.5)
                    continue

                line = line.strip()
                if not line:
                    continue

                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                output = _format_event(event)
                if output:
                    print(output)
                    if notify == "telegram" and tg_token and tg_chat:
                        _send_telegram(tg_token, tg_chat, output)

    except KeyboardInterrupt:
        print("\nStopped.")


def _format_event(event):
    eid = event.get("eventid", "")
    ip = event.get("src_ip", "")
    ts = event.get("timestamp", "")[:19]

    if eid == "cowrie.session.connect":
        info = lookup_ip(ip)
        country = info.get("country", "??")
        return f"🔵 {ts} NEW {ip} ({country})"

    elif eid == "cowrie.login.success":
        user = event.get("username", "")
        pwd = event.get("password", "")
        marker = "🔴" if (user, pwd) in DEFAULT_CREDS else "🟡"
        return f"{marker} {ts} LOGIN {ip} {user}/{pwd}"

    elif eid == "cowrie.login.failed":
        user = event.get("username", "")
        pwd = event.get("password", "")
        return f"⚪ {ts} FAIL {ip} {user}/{pwd}"

    elif eid == "cowrie.command.input":
        cmd = event.get("input", "")
        if _match_any(cmd, MALWARE_PATTERNS + REVERSE_SHELL_PATTERNS + MINER_PATTERNS):
            marker = "🔴 DANGER"
        elif any(t in cmd.lower() for t in CREDENTIAL_TARGETS):
            marker = "🟠 CRED"
        else:
            marker = "🟡 CMD"
        display = cmd[:80] + "..." if len(cmd) > 80 else cmd
        return f"{marker} {ts} {ip} $ {display}"

    elif eid == "cowrie.session.file_download":
        url = event.get("url", "")
        return f"🔴 DOWNLOAD {ts} {ip} {url}"

    return None


def _send_telegram(token, chat_id, message):
    try:
        import requests
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        resp = requests.post(url, json={
            "chat_id": chat_id,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }, timeout=5)
        if resp.status_code != 200:
            print(f"  [TG error: {resp.status_code} {resp.text[:100]}]")
    except Exception as e:
        print(f"  [TG error: {e}]")
