"""Summary report command."""

import json
from collections import Counter
from honeyscope.flags import threat_level
from honeyscope.geo import lookup_ip


def run(args, sessions, events):
    fmt = getattr(args, "format", "text")
    days = getattr(args, "days", 7)

    if fmt == "json":
        _json_report(sessions, days)
    elif fmt == "markdown":
        _markdown_report(sessions, days)
    else:
        _text_report(sessions, days)


def _text_report(sessions, days):
    total_ips = len(sessions)
    total_sessions = sum(s["session_count"] for s in sessions.values())
    total_commands = sum(s["total_commands"] for s in sessions.values())
    logged_in = sum(1 for s in sessions.values() if s["logged_in"])

    # Country stats
    countries = Counter()
    for ip, data in sessions.items():
        info = lookup_ip(ip)
        countries[info.get("country", "??")] += 1

    # Threat breakdown
    threat_counts = Counter()
    for data in sessions.values():
        threat_counts[data["level"]] += 1

    # Top attackers by score
    top = sorted(sessions.values(), key=lambda x: x["score"], reverse=True)[:10]

    # All passwords
    all_passwords = []
    for data in sessions.values():
        all_passwords.extend(data["unique_passwords"])
    pwd_counts = Counter(all_passwords).most_common(10)

    # All flags
    all_flags = Counter()
    for data in sessions.values():
        for f in data["flags"]:
            all_flags[f] += 1

    print(f"\n{'='*60}")
    print(f"  HONEYSCOPE REPORT — Last {days} days")
    print(f"{'='*60}")
    print(f"\n  Unique IPs:    {total_ips}")
    print(f"  Total sessions: {total_sessions}")
    print(f"  Successful logins: {logged_in}")
    print(f"  Commands executed: {total_commands}")

    print(f"\n  Threat levels:")
    for level in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        count = threat_counts.get(level, 0)
        if count:
            _, icon = threat_level(100 if level == "CRITICAL" else 7 if level == "HIGH" else 4 if level == "MEDIUM" else 0)
            print(f"    {icon} {level}: {count}")

    if countries:
        print(f"\n  Countries:")
        for country, count in countries.most_common(10):
            print(f"    {country}: {count}")

    if top:
        print(f"\n  Top threats:")
        for data in top[:5]:
            info = lookup_ip(data["ip"])
            country = info.get("country", "??")
            org = info.get("org", "")
            print(f"    {data['icon']} {data['ip']} ({country}) score={data['score']}")
            print(f"      {', '.join(data['flags'][:5])}")
            if org:
                print(f"      {org}")

    if pwd_counts:
        print(f"\n  Top passwords:")
        for pwd, count in pwd_counts:
            if pwd:
                print(f"    {pwd} ({count}x)")

    if all_flags:
        print(f"\n  Detected behaviors:")
        for flag, count in all_flags.most_common(15):
            print(f"    {flag}: {count}")

    print(f"\n{'='*60}\n")


def _json_report(sessions, days):
    output = {
        "days": days,
        "total_ips": len(sessions),
        "total_sessions": sum(s["session_count"] for s in sessions.values()),
        "attackers": [],
    }
    for ip, data in sorted(sessions.items(), key=lambda x: x[1]["score"], reverse=True):
        info = lookup_ip(ip)
        output["attackers"].append({
            "ip": ip,
            "country": info.get("country", "??"),
            "org": info.get("org", ""),
            "sessions": data["session_count"],
            "score": data["score"],
            "level": data["level"],
            "flags": data["flags"],
            "passwords": data["unique_passwords"],
            "commands": data["commands"],
        })
    print(json.dumps(output, indent=2, default=str))


def _markdown_report(sessions, days):
    total_ips = len(sessions)
    top = sorted(sessions.values(), key=lambda x: x["score"], reverse=True)

    print(f"# Honeyscope Report — Last {days} days\n")
    print(f"**Unique IPs:** {total_ips}  ")
    print(f"**Total sessions:** {sum(s['session_count'] for s in sessions.values())}  ")
    print(f"**Successful logins:** {sum(1 for s in sessions.values() if s['logged_in'])}\n")

    print("## Top Threats\n")
    print("| IP | Country | Score | Level | Flags |")
    print("|---|---|---|---|---|")
    for data in top[:15]:
        info = lookup_ip(data["ip"])
        country = info.get("country", "??")
        flags = ", ".join(data["flags"][:4])
        print(f"| {data['ip']} | {country} | {data['score']} | {data['icon']} {data['level']} | {flags} |")
    print()
