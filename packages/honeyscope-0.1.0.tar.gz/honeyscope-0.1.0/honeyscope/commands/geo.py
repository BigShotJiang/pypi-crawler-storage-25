"""Geographic distribution command."""

from collections import Counter
from honeyscope.geo import lookup_ip


def run(args, sessions, events):
    countries = Counter()
    cities = Counter()
    orgs = Counter()

    for ip, data in sessions.items():
        info = lookup_ip(ip)
        country = info.get("country", "??")
        city = info.get("city", "Unknown")
        org = info.get("org", "Unknown")
        countries[country] += data["session_count"]
        cities[f"{city}, {country}"] += data["session_count"]
        orgs[org] += data["session_count"]

    print(f"\n{'='*60}")
    print(f"  GEOGRAPHIC DISTRIBUTION")
    print(f"{'='*60}")

    print(f"\n  Countries:")
    max_count = max(countries.values()) if countries else 1
    for country, count in countries.most_common(20):
        bar_len = int((count / max_count) * 30)
        bar = "█" * bar_len
        print(f"    {country:<6s} {count:>5d}  {bar}")

    print(f"\n  Cities:")
    for city, count in cities.most_common(15):
        print(f"    {city:<30s} {count:>5d}")

    print(f"\n  Organizations:")
    for org, count in orgs.most_common(15):
        print(f"    {org:<45s} {count:>5d}")

    print(f"\n{'='*60}\n")
