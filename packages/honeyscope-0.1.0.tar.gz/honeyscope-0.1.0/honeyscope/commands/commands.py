"""Command analysis."""

import re
from collections import Counter


COMMAND_CATEGORIES = {
    "RECON": ["uname", "whoami", "id", "pwd", "hostname", "ifconfig", "ip addr", "cat /etc/issue", "lsb_release"],
    "CREDENTIAL_HUNT": [".env", "credentials", ".ssh/id_rsa", ".aws", "shadow", ".ssh/authorized_keys"],
    "MALWARE": ["chmod +x", "wget http", "curl http", "nohup ./", "/tmp/"],
    "MINER": ["xmrig", "stratum", "pool.", "minerd", "cpuminer"],
    "PERSISTENCE": ["crontab", "authorized_keys", "rc.local", "systemctl enable", ".bashrc"],
    "DISCOVERY": ["find /", "ls -la", "cat /etc/passwd", "df -h", "free", "ps aux", "netstat"],
    "LATERAL": ["ssh ", "scp ", "rsync"],
    "CLEANUP": ["history -c", "rm /var/log", "unset HISTFILE"],
}


def _categorize(cmd):
    cmd_lower = cmd.lower()
    for category, patterns in COMMAND_CATEGORIES.items():
        for pattern in patterns:
            if pattern in cmd_lower:
                return category
    return "OTHER"


def run(args, sessions, events):
    all_commands = []
    cmd_by_ip = {}

    for ip, data in sessions.items():
        for cmd in data["commands"]:
            all_commands.append(cmd)
            if ip not in cmd_by_ip:
                cmd_by_ip[ip] = []
            cmd_by_ip[ip].append(cmd)

    cmd_counts = Counter(all_commands)
    cat_counts = Counter(_categorize(cmd) for cmd in all_commands)

    print(f"\n{'='*60}")
    print(f"  COMMAND ANALYSIS")
    print(f"{'='*60}")

    print(f"\n  Total commands: {len(all_commands)}")
    print(f"  Unique commands: {len(set(all_commands))}")
    print(f"  IPs that ran commands: {len(cmd_by_ip)}")

    print(f"\n  Categories:")
    for cat, count in cat_counts.most_common():
        bar = "█" * min(count, 30)
        print(f"    {cat:<20s} {count:>4d}  {bar}")

    print(f"\n  Most common commands:")
    for cmd, count in cmd_counts.most_common(20):
        display = cmd[:70] + "..." if len(cmd) > 70 else cmd
        category = _categorize(cmd)
        print(f"    [{category}] {display} ({count}x)")

    # Dangerous commands highlight
    dangerous = [cmd for cmd in all_commands if _categorize(cmd) in ("MALWARE", "MINER", "CLEANUP", "LATERAL")]
    if dangerous:
        print(f"\n  ⚠ Dangerous commands:")
        for cmd in set(dangerous):
            display = cmd[:80] + "..." if len(cmd) > 80 else cmd
            print(f"    {display}")

    print(f"\n{'='*60}\n")
