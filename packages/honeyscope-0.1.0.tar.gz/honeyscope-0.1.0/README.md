<p align="center">
  <img src="https://img.shields.io/badge/python-3.8+-blue.svg" alt="Python 3.8+">
  <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="MIT License">
  <img src="https://img.shields.io/badge/cowrie-compatible-orange.svg" alt="Cowrie Compatible">
</p>

# Honeyscope

**Smart Cowrie honeypot log analyzer with behavioral threat detection.**

Most honeypot log parsers just count connections and list passwords. Honeyscope goes further — it performs **behavioral analysis** on each attacker, detects attack patterns, calculates threat scores, and classifies intent. All rule-based, no AI required, fully offline.

```
$ honeyscope report --days 7

============================================================
  HONEYSCOPE REPORT — Last 7 days
============================================================

  Unique IPs:     153
  Total sessions: 867
  Successful logins: 28
  Commands executed: 380

  Threat levels:
    🔴 CRITICAL: 9
    🟠 HIGH: 3
    🟡 MEDIUM: 12
    🟢 LOW: 129

  Top threats:
    🔴 122.177.244.200 (IN) score=18
      BRUTE_FORCE, HONEYPOT_AWARE, LEAKED_DB, LOG_CLEANUP, MALWARE_DROP
    🔴 49.228.97.98 (TH) score=16
      BRUTE_FORCE, LEAKED_DB, LOG_CLEANUP, MALWARE_DROP, SPRAY_ATTACK
    🔴 185.251.192.6 (NO) score=12
      HIT_AND_RUN, MALWARE_DROP, SSH_LIBRARY, WORM_SPREAD
```

## Why Honeyscope?

| Feature | Basic parsers | Honeyscope |
|---|:---:|:---:|
| Count connections per IP | Yes | Yes |
| List attempted passwords | Yes | Yes |
| Detect credential stuffing vs brute force | - | Yes |
| Identify scheduled scanners (cron bots) | - | Yes |
| Flag malware droppers & worm propagation | - | Yes |
| Detect honeypot-aware attackers | - | Yes |
| Score and rank threats automatically | - | Yes |
| Track a single attacker across sessions | - | Yes |
| Real-time monitoring with Telegram alerts | - | Yes |
| Classify attacker intent (recon, exfil, mining...) | - | Yes |

## Install

```bash
pip install honeyscope
```

Or from source:

```bash
git clone https://github.com/fahrettinyilmaz/honeyscope.git
cd honeyscope
pip install -e .
```

## Quick Start

```bash
# Point to your Cowrie JSON log directory
honeyscope report --log /var/lib/docker/volumes/cowrie-var/_data/log/cowrie/

# Exclude your own IP from results
honeyscope --exclude-ip YOUR.IP.HERE report --days 30
```

## Commands

### `report` — Summary overview

```bash
honeyscope report --days 7 --log /path/to/logs/
honeyscope report --format json > report.json
honeyscope report --format markdown > report.md
```

### `track` — Deep dive into a specific attacker

```bash
$ honeyscope track 83.150.215.50

============================================================
  TRACKING: 83.150.215.50
============================================================

  Location:   Istanbul, TR
  ISP/Org:    AS203576 Onur Ekren
  Sessions:   20
  Logged in:  Yes

  Threat: 🔴 CRITICAL (score: 11)
  Flags:  24_7_BOT, CREDENTIAL_STUFFING, HONEYPOT_AWARE, SCHEDULED_SCAN, SSH_LIBRARY

  SSH clients:
    SSH-2.0-paramiko_3.5.1

  Passwords tried:
    eWE:~)B&Y0

  Timeline:
    2026-04-05 11:01:00 [10.6s]
    2026-04-05 12:24:22 [11.1s]
    ...18 more sessions, ~75min intervals...
    2026-04-06 10:13:04 [40.9s] LOGIN OK: root/eWE:~)B&Y0
    2026-04-06 11:21:18 [10.1s]   ← came back, didn't login, left
```

### `live` — Real-time monitoring

```bash
# Watch in terminal
honeyscope live --log /path/to/cowrie.json

# With Telegram alerts
honeyscope live --notify telegram \
  --telegram-token BOT_TOKEN \
  --telegram-chat CHAT_ID

# Or via environment variables
export HONEYSCOPE_TG_TOKEN=your_bot_token
export HONEYSCOPE_TG_CHAT=your_chat_id
honeyscope live --notify telegram
```

Output:
```
🔵 2026-04-09 12:00:00 NEW 161.97.180.220 (DE)
🔴 2026-04-09 12:00:01 LOGIN 161.97.180.220 root/admin1234
🟠 CRED 2026-04-09 12:00:02 161.97.180.220 $ cat /root/.env
🔴 DANGER 2026-04-09 12:00:03 161.97.180.220 $ chmod +x ./sshd; nohup ./sshd &
```

### `passwords` — Password intelligence

```bash
$ honeyscope passwords --top 20

============================================================
  PASSWORD ANALYSIS
============================================================

  Total attempts: 402
  Unique passwords: 289

  Complexity:
    Simple (weak):  169
    Medium:         48
    Complex:        72

  Top 20 passwords:
    345gs5662d34                       40  ██████████████████████████████
    3245gs5662d34                      36  ██████████████████████████████
    123456                             15  ███████████████
    ubuntu                              6  ██████
    admin                               4  ████
```

### `commands` — What attackers run

```bash
honeyscope commands --days 7
```

Categorizes every command: `RECON`, `CREDENTIAL_HUNT`, `MALWARE`, `MINER`, `PERSISTENCE`, `DISCOVERY`, `LATERAL`, `CLEANUP`.

### `malware` — Malware incidents

```bash
$ honeyscope malware

  --- Incident #1 ---
  IP:      2.27.152.131 (IN)
  Threat:  🔴 score=12
  Flags:   HIT_AND_RUN, MALWARE_DROP, SSH_LIBRARY, WORM_SPREAD
  Commands:
    $ chmod +x ./.155695/sshd;nohup ./.155695/sshd 156.231.116.108 106.75.71.120 ...
  Worm targets: 51 IPs
```

Includes VirusTotal links for downloaded files.

### `geo` — Geographic distribution

```bash
honeyscope geo --days 30
```

### `repeat-offenders` — Recurring attackers

```bash
honeyscope repeat-offenders --min-visits 5
```

## Behavioral Detection

Honeyscope detects **30+ behavioral flags** across 5 categories:

<details>
<summary><b>Login Analysis</b></summary>

| Flag | How it's detected |
|---|---|
| `CREDENTIAL_STUFFING` | Complex password, single attempt, immediate success |
| `BRUTE_FORCE` | 5+ different passwords from same IP |
| `SPRAY_ATTACK` | Same password tried across multiple usernames |
| `DICTIONARY_ATTACK` | Passwords arrive in alphabetical order |
| `DEFAULT_CREDS` | Known defaults: root/root, admin/admin, pi/raspberry... |
| `LEAKED_DB` | Password contains @ or : (credential dump format) |

</details>

<details>
<summary><b>Timing Patterns</b></summary>

| Flag | How it's detected |
|---|---|
| `SCHEDULED_SCAN` | Connection intervals have < 20% variance (cron job) |
| `BURST_ATTACK` | 10+ connections within 60 seconds |
| `24_7_BOT` | Active across 18+ different hours of day |
| `BUSINESS_HOURS` | Only active 09:00–17:00 (likely human) |
| `HIT_AND_RUN` | Single visit, never returned |
| `PERSISTENT` | Activity spanning 3+ days |

</details>

<details>
<summary><b>Command Analysis</b></summary>

| Flag | How it's detected |
|---|---|
| `RECON` | Only uname, whoami, id, pwd |
| `CREDENTIAL_HARVEST` | Reads .env, .ssh/id_rsa, .aws, /etc/shadow |
| `CRYPTO_HUNT` | Searches for bitcoin/ethereum/wallet files |
| `MALWARE_DROP` | wget/curl + chmod +x pattern |
| `WORM_SPREAD` | Command contains 3+ target IP addresses |
| `REVERSE_SHELL` | bash -i, nc -e, python socket connect |
| `MINER_INSTALL` | xmrig, stratum+tcp, pool references |
| `PRIV_ESC` | sudo, SUID search, shadow read attempts |
| `LOG_CLEANUP` | history -c, rm /var/log, unset HISTFILE |
| `LATERAL_MOVEMENT` | ssh/scp to other hosts from honeypot |
| `DATA_EXFIL` | tar + curl/scp upload patterns |
| `RANSOMWARE_PREP` | Searching for .sql, .db, .bak files |

</details>

<details>
<summary><b>Identity</b></summary>

| Flag | How it's detected |
|---|---|
| `KNOWN_SCANNER` | ZGrab, Censys, Shodan in SSH version string |
| `SSH_LIBRARY` | paramiko, libssh, Go (automated tool) |
| `HONEYPOT_AWARE` | Logged in successfully, ran nothing, never returned |

</details>

<details>
<summary><b>Threat Scoring</b></summary>

Each flag has a weight. Scores are summed per attacker:

```
+1  RECON, DEFAULT_CREDS, SCHEDULED_SCAN, SSH_LIBRARY
+2  BRUTE_FORCE, SPRAY_ATTACK, PERSISTENT, HONEYPOT_AWARE, BURST_ATTACK
+3  CREDENTIAL_STUFFING, CREDENTIAL_HARVEST, LOG_CLEANUP, PRIV_ESC, LEAKED_DB
+4  MINER_INSTALL, DATA_EXFIL
+5  MALWARE_DROP, WORM_SPREAD, REVERSE_SHELL, RANSOMWARE_PREP
```

| Score | Level | |
|---|---|---|
| 0–3 | LOW | 🟢 |
| 4–6 | MEDIUM | 🟡 |
| 7–9 | HIGH | 🟠 |
| 10+ | CRITICAL | 🔴 |

</details>

## Requirements

- Python 3.8+
- `requests` (for IP geolocation via ipinfo.io)
- Cowrie honeypot with JSON logging enabled

## License

MIT

## Contributing

Issues and PRs welcome. If you run a honeypot and find a pattern Honeyscope doesn't detect, open an issue with a (sanitized) log sample.
