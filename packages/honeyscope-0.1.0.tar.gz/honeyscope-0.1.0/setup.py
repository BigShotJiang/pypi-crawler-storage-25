from setuptools import setup, find_packages

setup(
    name="honeyscope",
    version="0.1.0",
    description="Smart Cowrie honeypot log analyzer with behavioral threat detection",
    author="Fahrettin Yilmaz",
    author_email="fahrettinyilmaz@users.noreply.github.com",
    url="https://github.com/fahrettinyilmaz/honeyscope",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "telegram": ["requests>=2.28.0"],
    },
    entry_points={
        "console_scripts": [
            "honeyscope=honeyscope.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Information Technology",
        "Intended Audience :: System Administrators",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
