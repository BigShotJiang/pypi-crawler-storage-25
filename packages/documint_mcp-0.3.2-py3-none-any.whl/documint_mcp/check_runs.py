"""
GitHub Check Runs API integration for Documint.
Posts non-blocking drift annotations on PRs (neutral conclusion — the Codecov model).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .github import _github_request, get_installation_access_token


@dataclass
class DriftAnnotation:
    path: str              # "docs/API_REFERENCE.md"
    start_line: int        # line in the doc that mentions the changed symbol
    end_line: int
    annotation_level: str  # "warning" (non-blocking)
    message: str           # "add_memory() gained parameter session_id: str — review §3.2"
    title: str             # "Documint: Documentation drift detected"
    raw_details: str = field(default="")  # full diff context (optional)


class CheckRunManager:
    """
    Manages GitHub Check Runs for drift detection.

    Flow:
    1. create_check_run() — called when PR is opened (status=in_progress)
    2. complete_check_run() — called when drift analysis finishes (conclusion=neutral)

    The existing GitHub client in github.py uses synchronous httpx calls via the
    module-level _github_request() helper and get_installation_access_token().
    This class wraps those helpers directly.
    """

    def create_check_run(
        self,
        owner: str,
        repo: str,
        head_sha: str,
        installation_id: str,
    ) -> int:
        """
        Create a check run in 'in_progress' state.
        Returns the check run ID.
        """
        token = get_installation_access_token(installation_id)
        resp = _github_request(
            "POST",
            f"/repos/{owner}/{repo}/check-runs",
            token=token,
            json_body={
                "name": "Documint",
                "head_sha": head_sha,
                "status": "in_progress",
                "output": {
                    "title": "Checking documentation drift...",
                    "summary": "Documint is analyzing your changes for documentation drift.",
                },
            },
        )
        return int(resp.json()["id"])

    def complete_check_run(
        self,
        owner: str,
        repo: str,
        check_run_id: int,
        installation_id: str,
        findings_count: int,
        annotations: list[DriftAnnotation],
    ) -> None:
        """
        Update check run with results.

        Always uses conclusion="neutral" (non-blocking — informational only).
        Annotation level is "warning" (not "failure").
        """
        if findings_count == 0:
            title = "No documentation drift detected"
            summary = "All documentation artifacts are synchronized with their source files."
        else:
            plural = "s" if findings_count > 1 else ""
            title = f"{findings_count} documentation artifact{plural} may be outdated"
            summary = (
                f"Documint detected structural changes in {findings_count} artifact definition(s). "
                "Review and update documentation to keep your agent context accurate.\n\n"
                "This check is informational and does not block merging."
            )

        # GitHub API limits: max 50 annotations per update
        annotation_payload = [
            {
                "path": a.path,
                "start_line": a.start_line,
                "end_line": a.end_line,
                "annotation_level": a.annotation_level,
                "message": a.message,
                "title": a.title,
                "raw_details": a.raw_details,
            }
            for a in annotations[:50]
        ]

        token = get_installation_access_token(installation_id)
        _github_request(
            "PATCH",
            f"/repos/{owner}/{repo}/check-runs/{check_run_id}",
            token=token,
            json_body={
                "status": "completed",
                "conclusion": "neutral",
                "output": {
                    "title": title,
                    "summary": summary,
                    "annotations": annotation_payload,
                },
            },
        )

    def fail_check_run(
        self,
        owner: str,
        repo: str,
        check_run_id: int,
        installation_id: str,
        error_message: str,
    ) -> None:
        """Mark check run as failed (internal error, not drift)."""
        token = get_installation_access_token(installation_id)
        _github_request(
            "PATCH",
            f"/repos/{owner}/{repo}/check-runs/{check_run_id}",
            token=token,
            json_body={
                "status": "completed",
                "conclusion": "neutral",  # still neutral — don't block for our own errors
                "output": {
                    "title": "Documint check encountered an error",
                    "summary": f"Internal error during drift analysis: {error_message}",
                },
            },
        )
