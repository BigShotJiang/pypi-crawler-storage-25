"""Slack notification connector using ``slack-sdk``.

Gracefully degrades to a no-op when the SDK is not installed or when
the required environment variables (``SLACK_BOT_TOKEN``, ``SLACK_CHANNEL``)
are not set.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from documint_mcp.models import DriftFinding, DocPatch, FindingSeverity, VerificationRun

from .base import ConnectorBase

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional import: slack-sdk is not a hard dependency
# ---------------------------------------------------------------------------
try:
    from slack_sdk.web.async_client import AsyncWebClient

    _HAS_SLACK_SDK = True
except ImportError:  # pragma: no cover
    _HAS_SLACK_SDK = False
    AsyncWebClient = None  # type: ignore[assignment, misc]

# ---------------------------------------------------------------------------
# Block Kit helpers
# ---------------------------------------------------------------------------
_SEVERITY_EMOJI: dict[str, str] = {
    "high": ":red_circle:",
    "medium": ":large_orange_circle:",
    "low": ":large_yellow_circle:",
}


def _severity_badge(severity: str) -> str:
    emoji = _SEVERITY_EMOJI.get(severity, ":white_circle:")
    return f"{emoji} {severity.upper()}"


def _truncate(text: str, limit: int = 2900) -> str:
    """Slack blocks have a 3000-char text limit; leave margin."""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n... (truncated)"


def _drift_alert_blocks(
    project_id: str,
    findings: list[DriftFinding],
) -> list[dict[str, Any]]:
    """Build Block Kit blocks for a drift alert message."""
    high = sum(1 for f in findings if f.severity == FindingSeverity.HIGH)
    medium = sum(1 for f in findings if f.severity == FindingSeverity.MEDIUM)
    low = sum(1 for f in findings if f.severity == FindingSeverity.LOW)

    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"Doc Drift Detected -- {project_id}",
                "emoji": True,
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"*{len(findings)}* finding{'s' if len(findings) != 1 else ''} detected\n"
                    f"{_SEVERITY_EMOJI['high']} {high} high  "
                    f"{_SEVERITY_EMOJI['medium']} {medium} medium  "
                    f"{_SEVERITY_EMOJI['low']} {low} low"
                ),
            },
        },
        {"type": "divider"},
    ]

    for finding in findings[:10]:
        badge = _severity_badge(finding.severity.value)
        stale_docs = ", ".join(f"`{p}`" for p in finding.doc_paths[:3])
        if len(finding.doc_paths) > 3:
            stale_docs += f" +{len(finding.doc_paths) - 3} more"

        section_text = (
            f"{badge}  *{finding.artifact_id}*\n"
            f"{finding.summary}\n"
            f"Stale docs: {stale_docs or '_none_'}"
        )

        blocks.append(
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": _truncate(section_text)},
                "accessory": {
                    "type": "overflow",
                    "action_id": f"drift_actions_{finding.id}",
                    "options": [
                        {
                            "text": {"type": "plain_text", "text": "Approve Patch"},
                            "value": f"approve_patch|{finding.id}",
                        },
                        {
                            "text": {"type": "plain_text", "text": "Show Diff"},
                            "value": f"show_diff|{finding.id}",
                        },
                        {
                            "text": {"type": "plain_text", "text": "Dismiss"},
                            "value": f"dismiss|{finding.id}",
                        },
                    ],
                },
            }
        )

    if len(findings) > 10:
        blocks.append(
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"_Showing 10 of {len(findings)} findings. View all in the dashboard._",
                    }
                ],
            }
        )

    return blocks


def _patch_preview_blocks(
    project_id: str,
    patch: DocPatch,
) -> list[dict[str, Any]]:
    """Build Block Kit blocks for a patch preview thread reply."""
    diff_preview = _truncate(patch.preview_markdown, limit=2800)

    blocks: list[dict[str, Any]] = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"*Patch Preview* -- `{patch.target_path}`\n"
                    f"_{patch.summary}_"
                ),
            },
        },
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"```\n{diff_preview}\n```"},
        },
    ]

    if patch.citations:
        cite_lines = "\n".join(
            f"- `{c.path}` @ `{c.ref}`: {c.note}" for c in patch.citations[:5]
        )
        blocks.append(
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": f"*Citations:*\n{cite_lines}"},
                ],
            }
        )

    blocks.append(
        {
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Approve"},
                    "style": "primary",
                    "action_id": f"approve_patch_{patch.id}",
                    "value": f"{project_id}|{patch.id}",
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Reject"},
                    "style": "danger",
                    "action_id": f"reject_patch_{patch.id}",
                    "value": f"{project_id}|{patch.id}",
                },
            ],
        }
    )

    return blocks


def _digest_blocks(
    project_id: str,
    report: VerificationRun,
) -> list[dict[str, Any]]:
    """Build Block Kit blocks for a periodic health digest."""
    high = sum(1 for f in report.findings if f.severity == FindingSeverity.HIGH)
    medium = sum(1 for f in report.findings if f.severity == FindingSeverity.MEDIUM)
    low = sum(1 for f in report.findings if f.severity == FindingSeverity.LOW)

    status_icon = ":white_check_mark:" if report.findings_count == 0 else ":warning:"

    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"Documentation Health Digest -- {project_id}",
                "emoji": True,
            },
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Status:*\n{status_icon} {report.status.value}"},
                {"type": "mrkdwn", "text": f"*Total findings:*\n{report.findings_count}"},
                {"type": "mrkdwn", "text": f"*High:* {high}"},
                {"type": "mrkdwn", "text": f"*Medium:* {medium}"},
                {"type": "mrkdwn", "text": f"*Low:* {low}"},
                {
                    "type": "mrkdwn",
                    "text": f"*Signal:*\n{report.signal.type.value} @ `{report.signal.ref[:12]}`",
                },
            ],
        },
    ]

    if report.completed_at:
        blocks.append(
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"Completed {report.completed_at.isoformat()}",
                    }
                ],
            }
        )

    return blocks


# ---------------------------------------------------------------------------
# Connector implementation
# ---------------------------------------------------------------------------


class SlackConnector(ConnectorBase):
    """Posts drift alerts, patch previews, and digests to a Slack channel.

    Requires:
    - ``slack-sdk`` installed (``pip install slack-sdk``)
    - ``SLACK_BOT_TOKEN`` env var with a valid Bot User OAuth Token
    - ``SLACK_CHANNEL`` env var with the target channel ID or name

    If any of the above are missing the connector silently degrades to
    a no-op, logging a warning on first call.
    """

    def __init__(self) -> None:
        self._token: str | None = os.getenv("SLACK_BOT_TOKEN")
        self._channel: str | None = os.getenv("SLACK_CHANNEL")
        self._client: Any | None = None
        self._warned = False

        if _HAS_SLACK_SDK and self._token:
            self._client = AsyncWebClient(token=self._token)

    @property
    def is_configured(self) -> bool:
        return self._client is not None and bool(self._channel)

    def _warn_once(self, reason: str) -> None:
        if not self._warned:
            logger.warning("SlackConnector disabled: %s", reason)
            self._warned = True

    # -- drift alert ---------------------------------------------------------

    async def send_drift_alert(
        self,
        project_id: str,
        findings: list[DriftFinding],
    ) -> None:
        if not self.is_configured:
            self._warn_once(
                "slack-sdk not installed"
                if not _HAS_SLACK_SDK
                else "SLACK_BOT_TOKEN or SLACK_CHANNEL not set"
            )
            return

        if not findings:
            return

        blocks = _drift_alert_blocks(project_id, findings)
        fallback = f"Doc drift detected: {len(findings)} finding(s) in {project_id}"

        try:
            await self._client.chat_postMessage(  # type: ignore[union-attr]
                channel=self._channel,
                text=fallback,
                blocks=blocks,
            )
        except Exception:
            logger.exception("Failed to send Slack drift alert for %s", project_id)

    # -- patch preview -------------------------------------------------------

    async def send_patch_preview(
        self,
        project_id: str,
        patch: DocPatch,
    ) -> None:
        if not self.is_configured:
            self._warn_once(
                "slack-sdk not installed"
                if not _HAS_SLACK_SDK
                else "SLACK_BOT_TOKEN or SLACK_CHANNEL not set"
            )
            return

        blocks = _patch_preview_blocks(project_id, patch)
        fallback = f"Patch preview for {patch.target_path} in {project_id}"

        try:
            await self._client.chat_postMessage(  # type: ignore[union-attr]
                channel=self._channel,
                text=fallback,
                blocks=blocks,
            )
        except Exception:
            logger.exception("Failed to send Slack patch preview for %s", project_id)

    # -- digest --------------------------------------------------------------

    async def send_digest(
        self,
        project_id: str,
        report: VerificationRun,
    ) -> None:
        if not self.is_configured:
            self._warn_once(
                "slack-sdk not installed"
                if not _HAS_SLACK_SDK
                else "SLACK_BOT_TOKEN or SLACK_CHANNEL not set"
            )
            return

        blocks = _digest_blocks(project_id, report)
        fallback = f"Doc health digest for {project_id}: {report.findings_count} findings"

        try:
            await self._client.chat_postMessage(  # type: ignore[union-attr]
                channel=self._channel,
                text=fallback,
                blocks=blocks,
            )
        except Exception:
            logger.exception("Failed to send Slack digest for %s", project_id)
