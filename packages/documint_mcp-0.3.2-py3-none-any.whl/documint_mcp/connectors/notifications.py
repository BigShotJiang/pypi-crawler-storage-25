"""Event dispatcher that routes lifecycle events to configured connectors.

Auto-detects available connectors at startup based on environment variables.
If no connectors are configured the dispatcher is a silent no-op -- zero
errors, zero overhead.
"""

from __future__ import annotations

import logging
import os

from documint_mcp.models import DriftFinding, DocPatch, VerificationRun

from .base import ConnectorBase

logger = logging.getLogger(__name__)


class NotificationDispatcher:
    """Fan-out dispatcher for notification events.

    On initialization, probes the environment for configured connectors
    and lazily imports only the ones that are available.  Each event
    method iterates over the active connectors, catching and logging
    per-connector errors so that one failure never blocks the others.
    """

    def __init__(self) -> None:
        self._connectors: list[ConnectorBase] = []
        self._detect_connectors()

    def _detect_connectors(self) -> None:
        # -- Slack -----------------------------------------------------------
        if os.getenv("SLACK_BOT_TOKEN"):
            try:
                from .slack import SlackConnector

                connector = SlackConnector()
                if connector.is_configured:
                    self._connectors.append(connector)
                    logger.info("NotificationDispatcher: Slack connector enabled")
                else:
                    logger.info(
                        "NotificationDispatcher: SLACK_BOT_TOKEN set but "
                        "SLACK_CHANNEL missing or slack-sdk not installed; skipping"
                    )
            except Exception:
                logger.exception(
                    "NotificationDispatcher: failed to initialize Slack connector"
                )

        if not self._connectors:
            logger.debug(
                "NotificationDispatcher: no connectors configured; "
                "notifications will be silent no-ops"
            )

    @property
    def active_connectors(self) -> int:
        return len(self._connectors)

    # -- event methods -------------------------------------------------------

    async def on_drift_detected(
        self,
        project_id: str,
        findings: list[DriftFinding],
    ) -> None:
        """Notify all connectors that drift findings have been detected."""
        if not self._connectors or not findings:
            return
        for connector in self._connectors:
            try:
                await connector.send_drift_alert(project_id, findings)
            except Exception:
                logger.exception(
                    "Connector %s failed on drift alert for %s",
                    type(connector).__name__,
                    project_id,
                )

    async def on_patch_drafted(
        self,
        project_id: str,
        patch: DocPatch,
    ) -> None:
        """Notify all connectors that a doc patch has been drafted."""
        if not self._connectors:
            return
        for connector in self._connectors:
            try:
                await connector.send_patch_preview(project_id, patch)
            except Exception:
                logger.exception(
                    "Connector %s failed on patch preview for %s",
                    type(connector).__name__,
                    project_id,
                )

    async def on_digest_ready(
        self,
        project_id: str,
        report: VerificationRun,
    ) -> None:
        """Notify all connectors with a periodic health digest."""
        if not self._connectors:
            return
        for connector in self._connectors:
            try:
                await connector.send_digest(project_id, report)
            except Exception:
                logger.exception(
                    "Connector %s failed on digest for %s",
                    type(connector).__name__,
                    project_id,
                )


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
_dispatcher: NotificationDispatcher | None = None


def get_notification_dispatcher() -> NotificationDispatcher:
    """Return the module-level dispatcher, creating it on first call."""
    global _dispatcher
    if _dispatcher is None:
        _dispatcher = NotificationDispatcher()
    return _dispatcher
