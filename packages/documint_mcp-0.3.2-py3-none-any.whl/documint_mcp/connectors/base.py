"""Abstract base class for notification connectors."""

from __future__ import annotations

from abc import ABC, abstractmethod

from documint_mcp.models import DriftFinding, DocPatch, VerificationRun


class ConnectorBase(ABC):
    """Interface that every notification connector must implement.

    Each method receives structured domain objects and is responsible for
    formatting and delivering a notification appropriate to the target
    channel (Slack, email, webhook, etc.).

    All methods are async and must be non-blocking.  Implementations
    should swallow transport errors internally so that a single
    connector failure never disrupts the pipeline.
    """

    @abstractmethod
    async def send_drift_alert(
        self,
        project_id: str,
        findings: list[DriftFinding],
    ) -> None:
        """Notify the channel that new drift findings have been detected."""

    @abstractmethod
    async def send_patch_preview(
        self,
        project_id: str,
        patch: DocPatch,
    ) -> None:
        """Post a patch diff preview, typically as a thread reply."""

    @abstractmethod
    async def send_digest(
        self,
        project_id: str,
        report: VerificationRun,
    ) -> None:
        """Deliver a periodic summary of documentation health."""
