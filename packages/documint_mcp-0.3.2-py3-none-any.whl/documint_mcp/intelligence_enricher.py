"""
Background enrichment pass for intelligence layer entries.

Enriches FixedEntry and DecisionEntry records that have needs_enrichment=True
by calling Claude with the commit diff as context.

Usage:
    from documint_mcp.intelligence_enricher import enrich_layer_background
    layer = await enrich_layer_background(layer, repo_path="/path/to/repo")

The enricher is always optional — the intelligence layer is useful without it.
A failed enrichment call logs a warning and leaves the entry as-is.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import structlog

from .intelligence import DecisionEntry, FixedEntry, IntelligenceLayer

logger = structlog.get_logger(__name__)

_ENRICH_SYSTEM = (
    "You analyze git commits for a software project and extract structured intelligence. "
    "Be concise — one tight sentence per field. Focus on the WHY, not just the WHAT."
)

_FIX_PROMPT = """\
Commit subject: {subject}
Commit body: {body}
Files changed: {files}

Diff (first 1500 chars):
{diff}

Extract structured fields as JSON (no markdown, just JSON):
{{
  "bug": "What was the specific bug? (one sentence, past tense)",
  "how_fixed": "How was it fixed? (one sentence, past tense)",
  "pattern": "A rule that prevents this bug. Start with 'always' or 'never'.",
  "never_again": "The specific prohibition: 'never do X because Y'"
}}"""

_DEC_PROMPT = """\
Commit subject: {subject}
Commit body: {body}
Files changed: {files}

Diff (first 1500 chars):
{diff}

Extract structured fields as JSON (no markdown, just JSON):
{{
  "decision": "What was decided? (one sentence)",
  "rationale": "Why was this decision made? What problem does it solve? (one sentence)"
}}"""


def _get_diff(commit_sha: str, repo_path: str) -> str:
    try:
        result = subprocess.run(
            ["git", "show", "--stat", "-p", "--no-color", commit_sha],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout[:1500]
    except Exception:
        return ""


async def _call_claude(prompt: str, api_key: str, model: str) -> dict:
    """Call Claude and return parsed JSON dict. Raises on failure."""
    import httpx

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": model,
        "max_tokens": 256,
        "system": _ENRICH_SYSTEM,
        "messages": [{"role": "user", "content": prompt}],
    }
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=payload,
        )
        resp.raise_for_status()
        text = resp.json()["content"][0]["text"].strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        return json.loads(text)


async def _enrich_fixed(
    entry: FixedEntry, repo_path: str, api_key: str, model: str
) -> FixedEntry:
    diff = _get_diff(entry.commit, repo_path)
    prompt = _FIX_PROMPT.format(
        subject=entry.bug,
        body=entry.how_fixed,
        files=", ".join(entry.files_affected[:5]),
        diff=diff,
    )
    try:
        data = await _call_claude(prompt, api_key, model)
        return FixedEntry(
            id=entry.id,
            date=entry.date,
            commit=entry.commit,
            bug=data.get("bug", entry.bug),
            how_fixed=data.get("how_fixed", entry.how_fixed),
            pattern=data.get("pattern", ""),
            files_affected=entry.files_affected,
            needs_enrichment=False,
            never_again=data.get("never_again", ""),
        )
    except Exception as exc:
        logger.warning("fixed entry enrichment failed", id=entry.id, error=str(exc))
        return FixedEntry(
            **{**entry.__dict__, "needs_enrichment": False}
        )


async def _enrich_decision(
    entry: DecisionEntry, repo_path: str, api_key: str, model: str
) -> DecisionEntry:
    diff = _get_diff(entry.commit, repo_path)
    prompt = _DEC_PROMPT.format(
        subject=entry.decision,
        body=entry.rationale,
        files=", ".join(entry.affects[:5]),
        diff=diff,
    )
    try:
        data = await _call_claude(prompt, api_key, model)
        return DecisionEntry(
            id=entry.id,
            date=entry.date,
            commit=entry.commit,
            decision=data.get("decision", entry.decision),
            rationale=data.get("rationale", entry.rationale),
            affects=entry.affects,
            status=entry.status,
            needs_enrichment=False,
        )
    except Exception as exc:
        logger.warning("decision entry enrichment failed", id=entry.id, error=str(exc))
        return DecisionEntry(
            **{**entry.__dict__, "needs_enrichment": False}
        )


async def enrich_layer_background(
    layer: IntelligenceLayer,
    *,
    repo_path: str,
    api_key: str,
    model: str = "claude-haiku-4-5-20251001",
    on_progress: "callable[[int, int], None] | None" = None,
) -> IntelligenceLayer:
    """
    Enrich all needs_enrichment=True entries in the layer.

    Uses claude-haiku (fast, cheap) by default — accuracy is sufficient
    for extracting patterns from commit messages + diffs.

    Args:
        layer:        The IntelligenceLayer to enrich (modified in place).
        repo_path:    Absolute path to the git repo (for diff extraction).
        api_key:      Anthropic API key.
        model:        Claude model ID to use. Defaults to haiku.
        on_progress:  Optional callback(completed, total) for progress reporting.

    Returns the mutated layer.
    """
    pending_fixed = [(i, e) for i, e in enumerate(layer.fixed) if e.needs_enrichment]
    pending_dec = [(i, e) for i, e in enumerate(layer.decisions) if e.needs_enrichment]
    total = len(pending_fixed) + len(pending_dec)
    completed = 0

    logger.info("starting enrichment", total=total, model=model)

    for i, entry in pending_fixed:
        layer.fixed[i] = await _enrich_fixed(entry, repo_path, api_key, model)
        completed += 1
        if on_progress:
            on_progress(completed, total)

    for i, entry in pending_dec:
        layer.decisions[i] = await _enrich_decision(entry, repo_path, api_key, model)
        completed += 1
        if on_progress:
            on_progress(completed, total)

    logger.info("enrichment complete", enriched=completed)
    return layer
