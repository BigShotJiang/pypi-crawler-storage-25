"""Typed models for the Documint control plane, drift engine, and publish workflows."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class ArtifactType(StrEnum):
    API_REFERENCE = "api_reference"
    SDK_GUIDES = "sdk_guides"
    MCP_REFERENCE = "mcp_reference"
    CHANGELOG = "changelog"
    MIGRATION_NOTES = "migration_notes"


class SourceSignalType(StrEnum):
    MANUAL = "manual"
    PUSH = "push"
    PULL_REQUEST = "pull_request"
    RELEASE = "release"


class FindingSeverity(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class JobStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class VerificationStatus(StrEnum):
    VERIFIED = "verified"
    STALE = "stale"
    MISSING = "missing"


class RepositoryRevision(BaseModel):
    ref: str
    touched_at: datetime
    committed: bool = True


class User(BaseModel):
    id: str
    external_id: str | None = None
    email: str | None = None
    name: str
    provider: str
    created_at: datetime


class Workspace(BaseModel):
    id: str
    slug: str
    name: str
    description: str = ""
    created_at: datetime


class WorkspaceMember(BaseModel):
    id: str
    workspace_id: str
    user_id: str
    role: str
    created_at: datetime


class ApiTokenSummary(BaseModel):
    id: str
    workspace_id: str
    user_id: str
    label: str
    token_prefix: str
    scopes: list[str] = Field(default_factory=list)
    created_at: datetime
    last_used_at: datetime | None = None
    revoked_at: datetime | None = None
    token: str | None = None


class GitHubInstallation(BaseModel):
    id: str
    workspace_id: str
    installation_id: str | None = None
    account_login: str | None = None
    account_type: str | None = None
    repository_selection: str = "selected"
    metadata_json: dict[str, object] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class GitHubRepository(BaseModel):
    id: str
    github_installation_id: str
    repository_id: str | None = None
    full_name: str
    owner: str
    name: str
    default_branch: str
    visibility: str = "private"
    is_private: bool = True
    is_archived: bool = False
    metadata_json: dict[str, object] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class RepositorySource(BaseModel):
    id: str
    project_id: str | None = None
    provider: str = "github"
    owner: str
    repo: str
    default_branch: str
    local_path: str
    current_ref: str
    docs_root: str
    installation_id: str | None = None


class ProjectSettings(BaseModel):
    id: str
    project_id: str
    docs_root: str
    config_version: int = 1
    config_json: dict[str, object] = Field(default_factory=dict)
    ai_policy: dict[str, object] = Field(default_factory=dict)
    publish_behavior: dict[str, object] = Field(default_factory=dict)
    pr_behavior: dict[str, object] = Field(default_factory=dict)
    updated_at: datetime


class Project(BaseModel):
    id: str
    workspace_id: str | None = None
    github_installation_id: str | None = None
    name: str
    slug: str
    description: str
    public_url: str
    dashboard_url: str
    onboarding_status: str = "connected"
    source: RepositorySource
    artifact_types: list[ArtifactType]


class RuntimeStatus(BaseModel):
    environment: str
    deployment_provider: str
    job_execution_mode: str
    api_base_url: str
    public_base_url: str
    app_base_url: str
    repo_root: str
    docs_root: str
    git_available: bool
    git_metadata_available: bool
    current_ref: str
    current_ref_source: str
    auth_required: bool
    github_app_ready: bool
    deploy_branch: str | None = None
    database_configured: bool = True
    clerk_configured: bool = False
    huggingface_configured: bool = False


class SourceSignal(BaseModel):
    id: str | None = None
    type: SourceSignalType
    ref: str
    changed_files: list[str] = Field(default_factory=list)
    created_at: datetime


class ArtifactTrace(BaseModel):
    id: str
    slug: str
    title: str
    artifact_type: ArtifactType
    summary: str
    doc_paths: list[str]
    source_paths: list[str]
    latest_source_revision: RepositoryRevision | None = None
    latest_doc_revision: RepositoryRevision | None = None
    verification_status: VerificationStatus


class ArtifactDefinition(BaseModel):
    id: str
    project_id: str
    artifact_key: str
    slug: str
    title: str
    artifact_type: ArtifactType
    summary: str
    doc_paths: list[str]
    source_patterns: list[str]


class DriftFinding(BaseModel):
    id: str
    project_id: str | None = None
    verification_run_id: str | None = None
    artifact_id: str
    artifact_type: ArtifactType
    severity: FindingSeverity
    summary: str
    rationale: str
    source_paths: list[str]
    doc_paths: list[str]
    suggested_actions: list[str]
    source_revision: RepositoryRevision | None = None
    doc_revision: RepositoryRevision | None = None
    status: str = "open"
    created_at: datetime | None = None
    updated_at: datetime | None = None
    changed_symbols: list[dict] = Field(default_factory=list)
    symbol_hash: str | None = None
    confidence_score: float = 0.5
    has_breaking_changes: bool = False
    cross_artifact_refs: dict[str, list[str]] = Field(default_factory=dict)
    """Maps artifact_id -> [symbol_names] for OTHER artifacts affected by the same symbol changes."""


class AgentRun(BaseModel):
    id: str
    project_id: str
    kind: str
    provider: str
    model: str | None = None
    status: str
    input_summary: str
    output_summary: str
    metadata_json: dict[str, object] = Field(default_factory=dict)
    created_at: datetime
    completed_at: datetime | None = None


class PatchCitation(BaseModel):
    path: str
    ref: str
    note: str


class DocPatch(BaseModel):
    id: str
    project_id: str | None = None
    finding_id: str | None = None
    artifact_id: str
    target_path: str
    summary: str
    rationale: str = ""
    proposed_sections: list[str]
    citations: list[PatchCitation] = Field(default_factory=list)
    preview_markdown: str
    ai_provider: str = "deterministic"
    model_name: str | None = None
    chain_steps_used: int | None = None
    confidence_score: float | None = None
    status: str = "draft"
    created_at: datetime | None = None
    updated_at: datetime | None = None


class PullRequestRecord(BaseModel):
    id: str
    project_id: str
    patch_id: str
    branch_name: str
    title: str
    url: str
    state: str
    created_at: datetime
    updated_at: datetime


class VerificationRun(BaseModel):
    id: str
    project_id: str
    status: JobStatus
    signal: SourceSignal
    findings_count: int
    findings: list[DriftFinding] = Field(default_factory=list)
    started_at: datetime
    completed_at: datetime | None = None


class PublishDeployment(BaseModel):
    id: str
    project_id: str
    status: JobStatus
    commit_ref: str
    site_url: str
    preview_url: str
    docs_count: int
    generated_at: datetime


class PublishedPage(BaseModel):
    id: str
    project_id: str
    deployment_id: str
    workspace_slug: str
    project_slug: str
    path: str
    title: str
    description: str
    content_markdown: str
    search_body: str
    source_path: str
    created_at: datetime
    updated_at: datetime


class ActivityEvent(BaseModel):
    id: str
    workspace_id: str
    project_id: str | None = None
    kind: str
    title: str
    body: str
    metadata_json: dict[str, object] = Field(default_factory=dict)
    created_at: datetime


class PublicDocPage(BaseModel):
    workspace_slug: str
    project_slug: str
    path: str
    title: str
    description: str
    content_markdown: str
    source_path: str
    deployment_id: str


class ProjectSnapshot(BaseModel):
    project: Project
    workspace: Workspace | None = None
    settings: ProjectSettings | None = None
    runtime: RuntimeStatus
    artifacts: list[ArtifactTrace]
    latest_run: VerificationRun | None = None
    latest_deployment: PublishDeployment | None = None
    findings: list[DriftFinding] = Field(default_factory=list)
    pull_requests: list[PullRequestRecord] = Field(default_factory=list)
    activity: list[ActivityEvent] = Field(default_factory=list)


class WorkspaceCreateRequest(BaseModel):
    name: str
    slug: str | None = None
    description: str = ""


class ProjectCreateRequest(BaseModel):
    workspace_id: str
    name: str
    slug: str | None = None
    description: str = ""
    owner: str
    repo: str
    default_branch: str = "main"
    installation_id: str | None = None
    local_path: str | None = None


class DriftJobRequest(BaseModel):
    project_id: str
    signal_type: SourceSignalType = SourceSignalType.MANUAL
    changed_files: list[str] | None = None


class PublishRequest(BaseModel):
    project_id: str


class QueuedJob(BaseModel):
    job_id: str
    job_kind: str
    project_id: str | None = None
    workspace_id: str | None = None
    status: JobStatus = JobStatus.PENDING
    attempt_count: int = 0
    error_summary: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    result_summary: str | None = None
    site_url: str | None = None
    created_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    updated_at: datetime | None = None


class PatchCreateRequest(BaseModel):
    policy: str = "on_demand"


class PullRequestCreateRequest(BaseModel):
    title: str | None = None


class TokenCreateRequest(BaseModel):
    workspace_id: str = ""
    label: str = "CLI token"
    scopes: list[str] = Field(
        default_factory=lambda: ["projects:read", "projects:write"]
    )


class CLIExchangeRequest(BaseModel):
    workspace_id: str
    label: str = "CLI token"
    scopes: list[str] = Field(
        default_factory=lambda: ["projects:read", "projects:write"]
    )


class RevalidateRequest(BaseModel):
    project_id: str
    deployment_id: str | None = None


class AuthenticatedUser(BaseModel):
    user: User
    workspaces: list[Workspace]


class MCPTool(BaseModel):
    name: str
    description: str
    input_schema: dict[str, Any]


class MCPRequest(BaseModel):
    jsonrpc: str = "2.0"
    id: str | int | None = None
    method: str
    params: dict[str, Any] = Field(default_factory=dict)
