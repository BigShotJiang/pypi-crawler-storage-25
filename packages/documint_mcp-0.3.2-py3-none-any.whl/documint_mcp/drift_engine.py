"""
Semantic drift detection engine.

Replaces timestamp-based drift detection with structural symbol hash comparison.
A hash change = exported symbol added/removed/changed = semantic drift.
Whitespace, comments, internal refactors: NO drift signal.

The engine also produces an ATTRIBUTED SymbolDiff that tells the downstream
AI chain exactly WHAT changed, not just THAT something changed.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

import structlog

from .symbol_extractor import SymbolEntry, extract_symbols_from_files

logger = structlog.get_logger(__name__)


class ChangeType(StrEnum):
    ADDED = "ADDED"  # new export appeared
    REMOVED = "REMOVED"  # export disappeared (BREAKING)
    PARAM_ADDED = "PARAM_ADDED"
    PARAM_REMOVED = "PARAM_REMOVED"  # BREAKING
    RETURN_CHANGED = "RETURN_CHANGED"  # BREAKING
    RENAMED = "RENAMED"  # symbol name changed (BREAKING)
    SIGNATURE_CHANGED = "SIGNATURE_CHANGED"  # catch-all for other sig changes


class Severity(StrEnum):
    BREAKING = "BREAKING"  # callers must update their code
    ADDITIVE = "ADDITIVE"  # backwards compatible
    COSMETIC = "COSMETIC"  # no functional impact on callers


@dataclass(frozen=True)
class SymbolChange:
    """A single attributed change to an exported symbol."""

    change_type: ChangeType
    symbol_name: str
    severity: Severity
    before: str | None = None
    after: str | None = None
    detail: str = ""

    def human_summary(self) -> str:
        match self.change_type:
            case ChangeType.ADDED:
                return f"New export: {self.symbol_name}"
            case ChangeType.REMOVED:
                return f"Removed: {self.symbol_name} (BREAKING)"
            case ChangeType.PARAM_ADDED:
                return f"{self.symbol_name}() gained parameter: {self.detail}"
            case ChangeType.PARAM_REMOVED:
                return f"{self.symbol_name}() lost parameter: {self.detail} (BREAKING)"
            case ChangeType.RETURN_CHANGED:
                return f"{self.symbol_name}() return type: {self.before} → {self.after}"
            case ChangeType.RENAMED:
                return f"Renamed: {self.before} → {self.after}"
            case _:
                return f"{self.symbol_name}: {self.detail}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.change_type.value,
            "symbol": self.symbol_name,
            "severity": self.severity.value,
            "before": self.before,
            "after": self.after,
            "detail": self.detail,
        }


@dataclass
class SymbolDiff:
    """Complete diff between two symbol states."""

    changes: list[SymbolChange] = field(default_factory=list)
    old_hash: str = ""
    new_hash: str = ""

    @property
    def has_breaking_changes(self) -> bool:
        return any(c.severity == Severity.BREAKING for c in self.changes)

    @property
    def is_additive_only(self) -> bool:
        return bool(self.changes) and all(c.severity == Severity.ADDITIVE for c in self.changes)

    @property
    def changed_symbol_names(self) -> list[str]:
        return list({c.symbol_name for c in self.changes})

    def confidence_score(self) -> float:
        """
        Confidence that an AI patch can handle this diff without human review.
        ADDITIVE-only changes = high confidence (0.9).
        BREAKING changes = lower confidence (0.5).
        Many changes at once = lower confidence.
        """
        if not self.changes:
            return 1.0
        base = 0.9 if self.is_additive_only else 0.5
        # Decay with number of changes
        decay = max(0.0, 1.0 - (len(self.changes) - 1) * 0.1)
        return round(base * decay, 2)

    def human_summary(self) -> str:
        if not self.changes:
            return "No structural changes detected."
        parts = [c.human_summary() for c in self.changes[:5]]
        if len(self.changes) > 5:
            parts.append(f"... and {len(self.changes) - 5} more changes")
        return "\n".join(f"  -> {p}" for p in parts)

    def to_dict(self) -> dict[str, Any]:
        return {
            "old_hash": self.old_hash,
            "new_hash": self.new_hash,
            "changes": [c.to_dict() for c in self.changes],
            "has_breaking_changes": self.has_breaking_changes,
            "confidence": self.confidence_score(),
        }


def compute_symbol_hash(symbols: list[SymbolEntry]) -> str:
    """
    SHA-256 hash of the normalized, sorted symbol list.

    Normalization ensures:
    - Order independence: symbols sorted by name
    - Whitespace independence: signatures are stripped
    - Comment independence: signatures only include semantic info

    The hash changes ONLY when a public symbol's name, params, or return type changes.
    Internal refactors, comment changes, formatting = same hash.
    """
    normalized = sorted(s.signature() for s in symbols)
    payload = "\n".join(normalized).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def diff_symbols(
    old_symbols: list[SymbolEntry], new_symbols: list[SymbolEntry]
) -> list[SymbolChange]:
    """
    Produce an attributed diff between two symbol lists.
    Returns a list of SymbolChange objects describing exactly what changed.
    """
    old_map = {s.name: s for s in old_symbols}
    new_map = {s.name: s for s in new_symbols}

    old_names = set(old_map)
    new_names = set(new_map)

    changes: list[SymbolChange] = []

    # Removed symbols (potentially BREAKING)
    for name in old_names - new_names:
        changes.append(
            SymbolChange(
                change_type=ChangeType.REMOVED,
                symbol_name=name,
                severity=Severity.BREAKING,
                before=old_map[name].signature(),
                detail=f"was: {old_map[name].kind} {name}",
            )
        )

    # Added symbols (ADDITIVE)
    for name in new_names - old_names:
        changes.append(
            SymbolChange(
                change_type=ChangeType.ADDED,
                symbol_name=name,
                severity=Severity.ADDITIVE,
                after=new_map[name].signature(),
                detail=f"new {new_map[name].kind}: {name}",
            )
        )

    # Changed symbols
    for name in old_names & new_names:
        old = old_map[name]
        new = new_map[name]

        if old.signature() == new.signature():
            continue  # no change

        # Check params
        old_params = set(old.params)
        new_params = set(new.params)

        for p in new_params - old_params:
            # New param — check if it has a default (heuristic: contains "=" or "None" or "Optional")
            has_default = "=" in p or "None" in p or "Optional" in p or "?" in p
            changes.append(
                SymbolChange(
                    change_type=ChangeType.PARAM_ADDED,
                    symbol_name=name,
                    severity=Severity.ADDITIVE if has_default else Severity.BREAKING,
                    detail=p,
                    before=str(old.params),
                    after=str(new.params),
                )
            )

        for p in old_params - new_params:
            changes.append(
                SymbolChange(
                    change_type=ChangeType.PARAM_REMOVED,
                    symbol_name=name,
                    severity=Severity.BREAKING,
                    detail=p,
                    before=str(old.params),
                    after=str(new.params),
                )
            )

        # Check return type
        if old.return_type != new.return_type and old.params == new.params:
            changes.append(
                SymbolChange(
                    change_type=ChangeType.RETURN_CHANGED,
                    symbol_name=name,
                    severity=Severity.BREAKING,
                    before=old.return_type or "void",
                    after=new.return_type or "void",
                )
            )

    return changes


@dataclass
class DriftResult:
    """Result of running the drift engine on an artifact."""

    artifact_key: str
    is_stale: bool
    diff: SymbolDiff
    new_symbol_hash: str
    old_symbol_hash: str
    new_symbols: list[SymbolEntry]

    @property
    def severity(self) -> str:
        if not self.is_stale:
            return "clean"
        if self.diff.has_breaking_changes:
            return "high"
        return "medium"

    def finding_summary(self) -> str:
        """Attributed summary for DriftFinding — replaces the generic timestamp message."""
        if not self.is_stale:
            return "Documentation is current."
        if not self.diff.changes:
            return "Source structure changed. Re-scan needed."
        return self.diff.human_summary()


class DriftEngine:
    """
    Semantic drift detection engine.

    Usage:
        engine = DriftEngine()
        result = engine.check(
            artifact_key="api-reference",
            source_contents={"src/api.py": "..."},
            stored_hash="sha256:abc123...",
        )
        if result.is_stale:
            print(result.finding_summary())
    """

    def check(
        self,
        artifact_key: str,
        source_contents: dict[str, str],
        stored_hash: str | None,
        stored_symbols_json: str | None = None,
    ) -> DriftResult:
        """
        Check if an artifact has drifted by comparing structural symbol hashes.

        Args:
            artifact_key: Unique identifier for this artifact
            source_contents: {path: content} for all source files in the artifact
            stored_hash: The previously stored symbol hash (or None if first scan)
            stored_symbols_json: Previously stored symbols as JSON (for diff generation)

        Returns:
            DriftResult with is_stale, diff, and new hash
        """
        new_symbols = extract_symbols_from_files(source_contents)
        new_hash = compute_symbol_hash(new_symbols)

        # First scan — always emit a "baseline established" non-stale result
        if stored_hash is None:
            logger.info("drift_baseline_established", artifact=artifact_key, hash=new_hash[:12])
            return DriftResult(
                artifact_key=artifact_key,
                is_stale=False,
                diff=SymbolDiff(old_hash="", new_hash=new_hash),
                new_symbol_hash=new_hash,
                old_symbol_hash="",
                new_symbols=new_symbols,
            )

        # No change — clean
        if new_hash == stored_hash:
            return DriftResult(
                artifact_key=artifact_key,
                is_stale=False,
                diff=SymbolDiff(old_hash=stored_hash, new_hash=new_hash),
                new_symbol_hash=new_hash,
                old_symbol_hash=stored_hash,
                new_symbols=new_symbols,
            )

        # Hash changed — compute attributed diff
        old_symbols: list[SymbolEntry] = []
        if stored_symbols_json:
            try:
                raw = json.loads(stored_symbols_json)
                old_symbols = [
                    SymbolEntry(
                        name=s["n"],
                        kind=s.get("k", "fn"),
                        params=s.get("p", []),
                        return_type=s.get("r"),
                        line=s.get("l", 0),
                    )
                    for s in raw
                ]
            except (json.JSONDecodeError, KeyError):
                old_symbols = []

        changes = diff_symbols(old_symbols, new_symbols) if old_symbols else []
        diff = SymbolDiff(changes=changes, old_hash=stored_hash, new_hash=new_hash)

        logger.info(
            "drift_detected",
            artifact=artifact_key,
            old_hash=stored_hash[:12],
            new_hash=new_hash[:12],
            changes=len(changes),
            has_breaking=diff.has_breaking_changes,
        )

        return DriftResult(
            artifact_key=artifact_key,
            is_stale=True,
            diff=diff,
            new_symbol_hash=new_hash,
            old_symbol_hash=stored_hash,
            new_symbols=new_symbols,
        )

    def symbols_to_json(self, symbols: list[SymbolEntry]) -> str:
        """Serialize symbols to LSIF-compact JSON for storage."""
        return json.dumps([s.to_lsif_compact() for s in symbols], separators=(",", ":"))


_engine = DriftEngine()


def get_drift_engine() -> DriftEngine:
    return _engine
