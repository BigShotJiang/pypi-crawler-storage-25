"""Documint V1 backend package."""

__version__ = "0.3.2"
__author__ = "Documint Team"
__email__ = "team@documint.xyz"


from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from fastapi import FastAPI


def create_app(*args: Any, **kwargs: Any) -> "FastAPI":
    """Lazily import and return the FastAPI application."""
    from .server import create_app as _create_app

    return _create_app(*args, **kwargs)


__all__ = ["create_app"]

# Production deploy marker
