"""Application configuration for the Documint V1 dogfooding stack."""

from __future__ import annotations

import os
from pathlib import Path

from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _looks_like_repo_root(path: Path) -> bool:
    return (path / "pyproject.toml").exists() and (path / "content" / "docs").exists()


def _discover_repo_root() -> Path:
    env_root = os.getenv("REPO_ROOT")
    if env_root:
        return Path(env_root).expanduser().resolve()

    candidates = [Path.cwd().resolve(), *Path(__file__).resolve().parents]
    for candidate in candidates:
        if _looks_like_repo_root(candidate):
            return candidate
    return Path(__file__).resolve().parents[2]


REPO_ROOT = _discover_repo_root()


class Settings(BaseSettings):
    """Runtime settings with sane defaults for local dogfooding."""

    host: str = Field(default="127.0.0.1", description="API host")
    port: int = Field(default=8000, ge=1, le=65535, description="API port")
    debug: bool = Field(default=False, description="Enable debug-only behaviors")
    auto_create_schema: bool = Field(
        default=(
            os.getenv("DOCUMINT_AUTO_CREATE_SCHEMA", "").lower() in {"1", "true", "yes"}
            if os.getenv("DOCUMINT_AUTO_CREATE_SCHEMA") is not None
            else (
                os.getenv("PYTEST_CURRENT_TEST") is not None
                or os.getenv("DOCUMINT_ENVIRONMENT") in {"local", "test"}
                or (
                    os.getenv("RAILWAY_ENVIRONMENT_NAME") is None
                    and os.getenv("VERCEL_ENV") is None
                )
            )
        ),
        description="Create database tables automatically for local development and tests.",
        validation_alias=AliasChoices(
            "DOCUMINT_AUTO_CREATE_SCHEMA",
            "DOCUMINT_DB_AUTO_CREATE",
        ),
    )
    auto_bootstrap_defaults: bool = Field(
        default=(
            os.getenv("DOCUMINT_AUTO_BOOTSTRAP_DEFAULTS", "").lower()
            in {"1", "true", "yes"}
            if os.getenv("DOCUMINT_AUTO_BOOTSTRAP_DEFAULTS") is not None
            else (
                os.getenv("PYTEST_CURRENT_TEST") is not None
                or os.getenv("DOCUMINT_ENVIRONMENT") in {"local", "test"}
                or (
                    os.getenv("RAILWAY_ENVIRONMENT_NAME") is None
                    and os.getenv("VERCEL_ENV") is None
                )
            )
        ),
        description="Seed the self-dogfood workspace automatically in local development and tests.",
        validation_alias=AliasChoices(
            "DOCUMINT_AUTO_BOOTSTRAP_DEFAULTS",
            "DOCUMINT_AUTO_BOOTSTRAP",
        ),
    )
    job_execution_mode: str = Field(
        default=(
            os.getenv("DOCUMINT_JOB_EXECUTION_MODE")
            or (
                "inline"
                if (
                    os.getenv("PYTEST_CURRENT_TEST") is not None
                    or os.getenv("DOCUMINT_ENVIRONMENT") in {"local", "test"}
                    or (
                        os.getenv("RAILWAY_ENVIRONMENT_NAME") is None
                        and os.getenv("VERCEL_ENV") is None
                    )
                )
                else "queue"
            )
        ),
        description="Execution mode for long-running jobs: inline or queue.",
        validation_alias=AliasChoices(
            "DOCUMINT_JOB_EXECUTION_MODE",
            "DOCUMINT_JOB_MODE",
        ),
    )

    secret_key: str = Field(
        default_factory=lambda: os.urandom(32).hex(),
        description="Secret key for session and token signing",
    )
    auth_token: str | None = Field(
        default=None,
        description="Optional bearer token for mutating API endpoints",
        validation_alias=AliasChoices("AUTH_TOKEN", "DOCUMINT_AUTH_TOKEN"),
    )
    access_token_expire_minutes: int = Field(
        default=30,
        ge=1,
        le=1440,
        description="Access token expiration time in minutes",
    )

    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL for cache and ephemeral state",
    )
    cache_ttl: int = Field(
        default=3600,
        ge=60,
        le=86400,
        description="Default cache TTL in seconds",
    )
    max_file_size: int = Field(
        default=10 * 1024 * 1024,
        description="Maximum file size supported by the API",
    )

    database_url: str = Field(
        default="sqlite:///./documint.db",
        description="Metadata database URL",
    )
    internal_revalidate_secret: str | None = Field(
        default=None,
        description="Shared secret used by trusted internal revalidation calls.",
        validation_alias=AliasChoices(
            "INTERNAL_REVALIDATE_SECRET",
            "DOCUMINT_INTERNAL_REVALIDATE_SECRET",
        ),
    )
    log_level: str = Field(default="INFO", description="Structured logging level")
    rate_limit_requests: int = Field(
        default=120,
        ge=1,
        description="Rate limit requests per minute",
    )
    deployment_environment: str = Field(
        default=os.getenv("RAILWAY_ENVIRONMENT_NAME")
        or os.getenv("VERCEL_ENV")
        or os.getenv("DOCUMINT_ENVIRONMENT")
        or "local",
        description="Current deployment environment label",
    )
    deployment_provider: str = Field(
        default=(
            "railway"
            if os.getenv("RAILWAY_PROJECT_ID")
            else (
                "vercel"
                if os.getenv("VERCEL")
                else os.getenv("DOCUMINT_DEPLOYMENT_PROVIDER", "local")
            )
        ),
        description="Active deployment provider",
    )
    deploy_commit_ref: str | None = Field(
        default=None,
        description="Commit ref supplied by the deployment platform when git metadata is unavailable.",
        validation_alias=AliasChoices(
            "DOCUMINT_DEPLOY_COMMIT",
            "RAILWAY_GIT_COMMIT_SHA",
            "VERCEL_GIT_COMMIT_SHA",
            "GITHUB_SHA",
        ),
    )
    deploy_branch: str | None = Field(
        default=None,
        description="Branch or ref supplied by the deployment platform.",
        validation_alias=AliasChoices(
            "DOCUMINT_DEPLOY_BRANCH",
            "RAILWAY_GIT_BRANCH",
            "VERCEL_GIT_COMMIT_REF",
            "GITHUB_REF_NAME",
        ),
    )

    repo_root: Path = Field(default=REPO_ROOT, description="Local repository root")
    docs_content_path: Path = Field(
        default=REPO_ROOT / "content" / "docs",
        description="Markdown docs used for the public site",
    )
    document_storage_path: Path = Field(
        default=REPO_ROOT / ".documint",
        description="Internal scratch space for previews and generated artifacts",
    )
    documint_config_filename: str = Field(
        default="documint.config.yaml",
        description="Repository config file name for artifact and publish configuration.",
    )

    project_id: str = Field(default="documint-self", description="Dogfood project id")
    project_name: str = Field(default="Documint", description="Dogfood project name")
    project_slug: str = Field(default="documint", description="Dogfood project slug")
    project_owner: str = Field(default="skeehn", description="GitHub owner")
    project_repo: str = Field(default="documint", description="GitHub repo name")
    default_branch: str = Field(default="main", description="Repository default branch")
    default_workspace_id: str = Field(
        default="workspace-documint",
        description="Bootstrap workspace id for self-dogfood mode",
    )
    default_workspace_name: str = Field(
        default="Documint Lab",
        description="Bootstrap workspace name for self-dogfood mode",
    )
    default_workspace_slug: str = Field(
        default="documint-lab",
        description="Bootstrap workspace slug for self-dogfood mode",
    )
    default_user_id: str = Field(
        default="user-documint",
        description="Bootstrap user id for self-dogfood mode",
    )
    default_user_name: str = Field(
        default="Documint Operator",
        description="Bootstrap user name for self-dogfood mode",
    )
    default_user_email: str = Field(
        default="operator@documint.xyz",
        description="Bootstrap user email for self-dogfood mode",
    )

    public_base_url: str = Field(
        default="https://documint.xyz",
        description="Public docs and marketing site URL",
    )
    api_base_url: str = Field(
        default="http://127.0.0.1:8000",
        description="Public backend base URL used by integrations and webhooks",
    )
    app_base_url: str = Field(
        default="http://localhost:3000",
        description="Dashboard base URL",
    )
    github_app_name: str = Field(
        default="Documint",
        description="GitHub App display name",
    )
    github_app_id: str | None = Field(
        default=None,
        description="GitHub App identifier used for installation metadata",
    )
    github_app_slug: str = Field(
        default="documint",
        description="GitHub App slug used to construct install URLs",
    )
    github_app_private_key: str | None = Field(
        default=None,
        description="PEM-encoded GitHub App private key used to mint installation tokens.",
        validation_alias=AliasChoices(
            "GITHUB_APP_PRIVATE_KEY",
            "DOCUMINT_GITHUB_APP_PRIVATE_KEY",
        ),
    )
    github_webhook_secret: str | None = Field(
        default=None,
        description="GitHub webhook secret for validating deliveries",
    )
    github_api_url: str = Field(
        default="https://api.github.com",
        description="GitHub REST API base URL for installation sync and PR automation.",
        validation_alias=AliasChoices("GITHUB_API_URL", "DOCUMINT_GITHUB_API_URL"),
    )
    github_api_version: str = Field(
        default="2022-11-28",
        description="GitHub REST API version header used for app automation requests.",
        validation_alias=AliasChoices(
            "GITHUB_API_VERSION",
            "DOCUMINT_GITHUB_API_VERSION",
        ),
    )
    self_bootstrap_installation_id: str | None = Field(
        default=None,
        description="External GitHub installation id used for the self-dogfood project.",
        validation_alias=AliasChoices(
            "DOCUMINT_SELF_BOOTSTRAP_INSTALLATION_ID",
            "GITHUB_SELF_INSTALLATION_ID",
        ),
    )
    clerk_jwks_url: str | None = Field(
        default=None,
        description="Optional Clerk JWKS URL for backend JWT verification.",
        validation_alias=AliasChoices("CLERK_JWKS_URL", "DOCUMINT_CLERK_JWKS_URL"),
    )
    clerk_issuer: str | None = Field(
        default=None,
        description="Expected Clerk token issuer.",
        validation_alias=AliasChoices("CLERK_ISSUER", "DOCUMINT_CLERK_ISSUER"),
    )
    clerk_audience: str | None = Field(
        default=None,
        description="Expected Clerk audience for backend JWT verification.",
        validation_alias=AliasChoices("CLERK_AUDIENCE", "DOCUMINT_CLERK_AUDIENCE"),
    )
    hf_api_token: str | None = Field(
        default=None,
        description="Hugging Face API token used for patch drafting and summarization.",
        validation_alias=AliasChoices("HF_API_TOKEN", "HUGGINGFACEHUB_API_TOKEN"),
    )
    hf_primary_model: str | None = Field(
        default=None,
        description="Primary instruct model used for patch drafting.",
        validation_alias=AliasChoices("HF_PRIMARY_MODEL", "DOCUMINT_HF_PRIMARY_MODEL"),
    )
    hf_fast_model: str | None = Field(
        default=None,
        description="Fast summarization model used for change triage.",
        validation_alias=AliasChoices("HF_FAST_MODEL", "DOCUMINT_HF_FAST_MODEL"),
    )
    anthropic_api_key: str | None = Field(
        default=None,
        description="Anthropic API key for Claude patch drafting.",
        validation_alias=AliasChoices("ANTHROPIC_API_KEY", "DOCUMINT_ANTHROPIC_API_KEY"),
    )
    openrouter_api_key: str | None = Field(
        default=None,
        description="OpenRouter API key for fallback patch drafting.",
        validation_alias=AliasChoices("OPENROUTER_API_KEY", "DOCUMINT_OPENROUTER_API_KEY"),
    )
    anthropic_model: str = Field(
        default="claude-sonnet-4-6",
        description="Anthropic model for patch drafting.",
    )
    openrouter_primary_model: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b:free",
        description="Primary OpenRouter fallback model.",
    )
    openrouter_secondary_model: str = Field(
        default="nvidia/nemotron-3-nano-30b-a3b:free",
        description="Secondary OpenRouter fallback model (lighter, faster).",
    )
    frontend_revalidate_url: str | None = Field(
        default=None,
        description="Optional web revalidation endpoint called after a publish succeeds.",
        validation_alias=AliasChoices(
            "DOCUMINT_FRONTEND_REVALIDATE_URL",
            "NEXT_REVALIDATE_URL",
        ),
    )
    frontend_revalidate_secret: str | None = Field(
        default=None,
        description="Shared secret for the web revalidation endpoint.",
        validation_alias=AliasChoices(
            "DOCUMINT_FRONTEND_REVALIDATE_SECRET",
            "NEXT_REVALIDATE_SECRET",
        ),
    )

    @field_validator("host")
    @classmethod
    def validate_host(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("Host cannot be empty")
        return value.strip()

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, value: str) -> str:
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = value.upper()
        if upper not in valid_levels:
            raise ValueError(f"Log level must be one of {valid_levels}")
        return upper

    @field_validator("repo_root", "docs_content_path", "document_storage_path")
    @classmethod
    def validate_paths(cls, value: Path) -> Path:
        resolved = value.resolve()
        resolved.mkdir(parents=True, exist_ok=True)
        return resolved

    @field_validator("deployment_environment", "deployment_provider")
    @classmethod
    def validate_runtime_labels(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("Runtime labels cannot be empty")
        return value.strip()

    @field_validator("job_execution_mode")
    @classmethod
    def validate_job_execution_mode(cls, value: str) -> str:
        normalized = value.strip().lower()
        if normalized not in {"inline", "queue"}:
            raise ValueError("job_execution_mode must be either 'inline' or 'queue'")
        return normalized

    @model_validator(mode="after")
    def validate_project_paths(self) -> Settings:
        repo_root = self.repo_root.resolve()
        docs_root = self.docs_content_path.resolve()
        storage_root = self.document_storage_path.resolve()

        if not str(docs_root).startswith(str(repo_root)):
            raise ValueError("docs_content_path must remain inside repo_root")
        if not str(storage_root).startswith(str(repo_root)):
            raise ValueError("document_storage_path must remain inside repo_root")
        return self

    model_config = SettingsConfigDict(
        extra="ignore",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    def is_local_runtime(self) -> bool:
        return self.deployment_environment in {"local", "test"} or (
            self.deployment_provider == "local"
        )

    def is_production_runtime(self) -> bool:
        return not self.is_local_runtime()

    def production_validation_errors(self) -> list[str]:
        if not self.is_production_runtime():
            return []

        errors: list[str] = []
        if self.debug:
            errors.append("debug must be disabled")
        if self.database_url.startswith("sqlite"):
            errors.append("Postgres is required; SQLite is only supported for local/test")
        if self.auto_create_schema:
            errors.append("auto_create_schema must be disabled")
        if self.auto_bootstrap_defaults:
            errors.append("auto_bootstrap_defaults must be disabled")
        if self.job_execution_mode != "queue":
            errors.append("job_execution_mode must be 'queue'")
        if not self.github_app_id:
            errors.append("github_app_id is required")
        if not self.github_app_slug:
            errors.append("github_app_slug is required")
        if not self.github_app_private_key:
            errors.append("github_app_private_key is required")
        if not self.github_webhook_secret:
            errors.append("github_webhook_secret is required")
        if not self.clerk_jwks_url:
            errors.append("clerk_jwks_url is required")
        if not self.clerk_issuer:
            errors.append("clerk_issuer is required")
        if not self.internal_revalidate_secret:
            errors.append("internal_revalidate_secret is required")
        if not self.frontend_revalidate_url:
            errors.append("frontend_revalidate_url is required")
        if not self.frontend_revalidate_secret:
            errors.append("frontend_revalidate_secret is required")
        if os.getenv("DOCUMINT_ENABLE_API_FALLBACK", "").lower() == "true":
            errors.append("DOCUMINT_ENABLE_API_FALLBACK must be disabled")
        return errors


settings = Settings()

CACHE_CONFIG = {
    "default_ttl": settings.cache_ttl,
    "max_connections": 20,
    "retry_on_timeout": True,
    "socket_connect_timeout": 5,
    "socket_timeout": 5,
}

SECURITY_CONFIG = {
    "algorithm": "HS256",
    "access_token_expire_minutes": settings.access_token_expire_minutes,
    "bcrypt_rounds": 12,
}
