"""
AI patch drafting pipeline for Documint — 4-step chain.

Step 1: Symbol diff characterization (haiku, structured output via instructor)
   → Given old/new symbols, produce typed DiffReport
   → Fast, cheap, machine-readable change description

Step 2: Stale section detection (haiku, parallel per section)
   → For each doc section: is it stale given the diff?
   → Skips unaffected sections in Step 3

Step 3: Patch generation (sonnet, surgical context)
   → Only stale sections + only relevant source excerpts
   → Produces full updated doc

Step 4: Patch verification (haiku)
   → Checks: did anything change? any hallucinated symbol names?
   → Retries Step 3 up to 3 times if verification says RETRY

Falls back to single-step Anthropic call, then OpenRouter, then deterministic if 4-step fails.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass
from textwrap import dedent
from typing import Any, Literal

import httpx
import structlog

from .config import settings
from .models import ArtifactTrace, ArtifactType, DriftFinding, PatchCitation, Project, ProjectSettings
from .rag import get_rag, format_few_shot_prompt

logger = structlog.get_logger(__name__)


# ── Chain config by artifact type ─────────────────────────────────────────

CHAIN_CONFIGS: dict[str, dict] = {
    "api_reference":   {"steps": 4, "breaking_detector": False},
    "changelog":       {"steps": 2, "breaking_detector": False},
    "migration_notes": {"steps": 4, "breaking_detector": True},
    "sdk_guides":      {"steps": 3, "breaking_detector": False},
    "mcp_reference":   {"steps": 4, "breaking_detector": False},
}
DEFAULT_CHAIN_CONFIG = {"steps": 4, "breaking_detector": False}


# ── Symbol diff LRU cache ──────────────────────────────────────────────────

_DIFF_REPORT_CACHE: dict[str, Any] = {}
_DIFF_REPORT_CACHE_MAX = 50


def _symbols_cache_key(changed_symbols: list[dict]) -> str:
    """Stable cache key for a list of changed symbols."""
    s = json.dumps(sorted(changed_symbols, key=lambda x: x.get("n", "")), sort_keys=True)
    return hashlib.sha256(s.encode()).hexdigest()


def _cache_get_diff_report(key: str) -> Any | None:
    return _DIFF_REPORT_CACHE.get(key)


def _cache_set_diff_report(key: str, report: Any) -> None:
    if len(_DIFF_REPORT_CACHE) >= _DIFF_REPORT_CACHE_MAX:
        # Evict the oldest entry (insertion-order in Python 3.7+)
        oldest = next(iter(_DIFF_REPORT_CACHE))
        del _DIFF_REPORT_CACHE[oldest]
    _DIFF_REPORT_CACHE[key] = report


# ── Section helpers ────────────────────────────────────────────────────────

def _split_into_sections(doc: str) -> dict[str, str]:
    """Returns {section_title: section_content} dict.

    Keys are the bare heading text (no leading #).  The preamble (text before
    the first ## heading) is stored under the key '_preamble'.
    Only ## headings are treated as section boundaries; deeper headings stay
    inside their parent section.
    """
    sections: dict[str, str] = {}
    current_title = "_preamble"
    current_lines: list[str] = []
    for line in doc.splitlines():
        if line.startswith("## "):
            if current_lines:
                sections[current_title] = "\n".join(current_lines)
            current_title = line.lstrip("# ").strip()
            current_lines = [line]
        else:
            current_lines.append(line)
    if current_lines:
        sections[current_title] = "\n".join(current_lines)
    return sections


def _apply_section_patches(original_doc: str, stale_titles: list[str], patched_sections: str) -> str:
    """Replace only the stale sections in the original doc with the patched versions.

    Parses *patched_sections* into individual ## sections and substitutes each
    one back into *original_doc*, leaving untouched sections intact.
    Returns the complete doc with only the stale sections updated.
    """
    original_sections = _split_into_sections(original_doc)
    patched_map = _split_into_sections(patched_sections)

    result_parts: list[str] = []
    for title, content in original_sections.items():
        if title in stale_titles and title in patched_map:
            result_parts.append(patched_map[title])
        else:
            result_parts.append(content)
    return "\n\n".join(result_parts)


def _detect_stale_sections(
    doc_content: str,
    changed_symbols: list[dict],
    use_semantic: bool = False,
) -> list[str]:
    """Return list of stale section titles.

    Checks three signals in order:
    1. Section title contains a changed symbol name
    2. Section body mentions a changed symbol name
    3. Section body contains an old/new symbol signature

    *use_semantic* is reserved for future Phase-6 ChromaDB embedding support.
    TODO: implement semantic staleness detection via ChromaDB embeddings (Phase 6).
    """
    if use_semantic:
        # TODO (Phase 6): embed each section and compute cosine similarity against
        # the changed-symbol descriptions using a ChromaDB ephemeral collection.
        pass

    sections = _split_into_sections(doc_content)
    stale: list[str] = []

    symbol_names = {s.get("n", "").lower() for s in changed_symbols if s.get("n")}
    symbol_signatures = {s.get("s", "").lower() for s in changed_symbols if s.get("s")}

    for title, content in sections.items():
        content_lower = content.lower()
        # Check 1: section title contains a changed symbol name
        if any(sym in title.lower() for sym in symbol_names):
            stale.append(title)
            continue
        # Check 2: section body mentions a changed symbol name
        if any(sym in content_lower for sym in symbol_names):
            stale.append(title)
            continue
        # Check 3: section body contains an old or new signature fragment
        if any(sig in content_lower for sig in symbol_signatures):
            stale.append(title)

    # Fallback: if nothing matched, treat every section as potentially stale
    return stale if stale else list(sections.keys())


# ── Structured output models ───────────────────────────────────────────────

try:
    from pydantic import BaseModel as PydanticBaseModel, Field as PydanticField

    class SymbolChange(PydanticBaseModel):
        symbol_name: str = PydanticField(
            description="Exact name of the function, class, method, or constant that changed — copy verbatim from the source code."
        )
        change_type: Literal["ADDED", "REMOVED", "PARAM_ADDED", "PARAM_REMOVED", "RETURN_CHANGED", "SIGNATURE_CHANGED"] = PydanticField(
            description=(
                "Category of change: ADDED=new symbol, REMOVED=deleted symbol, "
                "PARAM_ADDED=new parameter, PARAM_REMOVED=removed parameter, "
                "RETURN_CHANGED=return type changed, SIGNATURE_CHANGED=other signature change."
            )
        )
        severity: Literal["BREAKING", "ADDITIVE", "COSMETIC"] = PydanticField(
            description=(
                "Impact level: BREAKING=callers must update their code (removed param, removed symbol, "
                "incompatible return type), ADDITIVE=new optional behaviour callers may opt into, "
                "COSMETIC=rename or formatting only."
            )
        )
        detail: str = PydanticField(
            default="",
            description="One-sentence human-readable description of what changed and why it matters for documentation."
        )
        before: str | None = PydanticField(
            default=None,
            description="The old signature or value as it appeared in the previous version, if known."
        )
        after: str | None = PydanticField(
            default=None,
            description="The new signature or value as it appears in the current source code."
        )

    class DiffReport(PydanticBaseModel):
        changes: list[SymbolChange] = PydanticField(
            default_factory=list,
            description="List of every symbol that changed. Include only symbols with evidence from the source excerpt."
        )
        summary: str = PydanticField(
            default="",
            description="One or two sentences summarising the overall nature of this drift (e.g. 'Three functions renamed; one parameter removed from add_memory()')."
        )
        has_breaking_changes: bool = PydanticField(
            default=False,
            description="True if ANY change has severity=BREAKING, meaning existing callers will break."
        )
        affected_doc_sections: list[str] = PydanticField(
            default_factory=list,
            description="Markdown section headings (as they appear in the docs) that need to be updated. Use the exact heading text."
        )

    class StalenessCheck(PydanticBaseModel):
        section_name: str = PydanticField(
            description="Markdown heading of the documentation section being evaluated."
        )
        is_stale: bool = PydanticField(
            description="True if this section references any changed symbol and therefore needs to be rewritten."
        )
        reason: str = PydanticField(
            default="",
            description="Brief explanation of why the section is or is not stale."
        )

    class PatchVerification(PydanticBaseModel):
        patch_changed_content: bool = PydanticField(
            description="True if the proposed patch contains substantive differences from the original documentation (not just whitespace)."
        )
        hallucinated_symbols: list[str] = PydanticField(
            default_factory=list,
            description=(
                "List of function/class/method names referenced in the patch that do NOT appear in the "
                "provided source symbol list. Empty list if no hallucinations detected."
            )
        )
        issues_found: list[str] = PydanticField(
            default_factory=list,
            description=(
                "Specific problems with the patch, each as a short sentence. Examples: "
                "'patch is identical to original', 'uses foo() which is not in source', "
                "'missing update for removed parameter bar'. Empty list if no issues."
            )
        )
        verdict: Literal["PASS", "RETRY", "FAIL"] = PydanticField(
            default="PASS",
            description=(
                "PASS=patch is correct and substantive, ready to present to user. "
                "RETRY=patch has fixable issues (same as original, minor hallucinations) — regenerate. "
                "FAIL=patch has severe errors (contradicts source, major hallucinations) — escalate."
            )
        )

    _HAS_PYDANTIC = True
except ImportError:
    _HAS_PYDANTIC = False
    logger.info("pydantic_not_available", note="structured output models unavailable")

_instructor_client = None
_HAS_INSTRUCTOR = False


def _get_instructor_client():
    """Lazy instructor client initialization.

    Creates the instructor-wrapped Anthropic client on first use rather than at
    module import time.  This avoids conflating "packages not installed" with
    "API key not yet configured" — the old eager initialization set
    _HAS_INSTRUCTOR=False permanently if the key was missing at import time.
    """
    global _instructor_client, _HAS_INSTRUCTOR
    if _instructor_client is not None:
        return _instructor_client
    try:
        import instructor
        from anthropic import Anthropic

        key = settings.anthropic_api_key
        if not key:
            return None
        _instructor_client = instructor.from_anthropic(Anthropic(api_key=key))
        _HAS_INSTRUCTOR = True
        return _instructor_client
    except (ImportError, Exception) as exc:
        logger.info("instructor_init_failed", error=str(exc), note="falling back to single-step chain")
        return None


# ── Token cost helpers ─────────────────────────────────────────────────────

# Rates in USD per million tokens
_COST_PER_M: dict[str, dict[str, float]] = {
    "claude-haiku-4-5-20251001": {"in": 0.25, "out": 1.25},
    # Fallback for any sonnet-4-6 variant string
    "claude-sonnet-4-6": {"in": 3.0, "out": 15.0},
}


def _model_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Rough USD cost for a single call."""
    rates = None
    for key in _COST_PER_M:
        if key in model:
            rates = _COST_PER_M[key]
            break
    if rates is None:
        rates = {"in": 3.0, "out": 15.0}  # conservative default
    return (input_tokens / 1_000_000) * rates["in"] + (output_tokens / 1_000_000) * rates["out"]


def _extract_usage(raw_response: Any) -> tuple[int, int]:
    """Return (input_tokens, output_tokens) from an instructor response object.

    When using instructor with response_model, messages.create() returns the
    Pydantic model — not the raw Anthropic response.  The Pydantic model has
    no ``usage`` attribute, so the old code always returned (0, 0).

    Newer versions of the instructor library store the original API response
    on ``_raw_response``.  We check that first, then fall back to a direct
    ``.usage`` attribute (in case the caller passes the raw response directly),
    and finally accept (0, 0) with a debug log.
    """
    try:
        # instructor stores the raw Anthropic response here in newer versions
        raw = getattr(raw_response, "_raw_response", None)
        if raw is not None:
            usage = getattr(raw, "usage", None)
            if usage is not None:
                return int(getattr(usage, "input_tokens", 0)), int(getattr(usage, "output_tokens", 0))

        # Direct .usage (when caller passes the raw API response itself)
        usage = getattr(raw_response, "usage", None)
        if usage is not None:
            return int(getattr(usage, "input_tokens", 0)), int(getattr(usage, "output_tokens", 0))
    except Exception:
        pass

    logger.debug("token_usage_unavailable", response_type=type(raw_response).__name__)
    return 0, 0


# ── Result dataclass ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class DraftPatchResult:
    summary: str
    rationale: str
    proposed_sections: list[str]
    citations: list[PatchCitation]
    preview_markdown: str
    ai_provider: str
    model_name: str | None
    input_summary: str
    confidence_score: float = 0.5
    chain_steps_used: int = 1


# ── Main generator ─────────────────────────────────────────────────────────

class PatchGenerator:
    """Generate reviewable doc patches from deterministic drift findings."""

    def draft_patch(
        self,
        *,
        project: Project,
        trace: ArtifactTrace,
        finding: DriftFinding | None,
        current_doc: str,
        source_content: str = "",
        project_settings: ProjectSettings | None,
        policy: str,
    ) -> DraftPatchResult:
        # Attempt 4-step chain first (requires instructor + anthropic SDK)
        if _get_instructor_client() is not None and settings.anthropic_api_key:
            result = self._draft_4step(
                project=project,
                trace=trace,
                finding=finding,
                current_doc=current_doc,
                source_content=source_content,
            )
            if result is not None:
                return result

        # Fall back to single-step chain
        prompt = self._build_prompt(
            project=project, trace=trace, finding=finding,
            current_doc=current_doc, source_content=source_content,
            project_settings=project_settings, policy=policy,
        )

        for provider_fn, provider_name, model_name in [
            (lambda p: self._draft_with_anthropic(p), "anthropic", settings.anthropic_model),
            (lambda p: self._draft_with_openrouter(p, settings.openrouter_primary_model), "openrouter", settings.openrouter_primary_model),
            (lambda p: self._draft_with_openrouter(p, settings.openrouter_secondary_model), "openrouter", settings.openrouter_secondary_model),
        ]:
            text = provider_fn(prompt)
            if text is not None:
                citations = self._build_citations(trace=trace, finding=finding)
                sections = self._suggest_sections(trace=trace, finding=finding)
                return DraftPatchResult(
                    summary=f"{provider_name.capitalize()} patch for {trace.title}",
                    rationale=f"Generated by {provider_name} from drift context.",
                    proposed_sections=sections,
                    citations=citations,
                    preview_markdown=text,
                    ai_provider=provider_name,
                    model_name=model_name,
                    input_summary=prompt[:500],
                    chain_steps_used=1,
                )

        return self._deterministic_draft(
            project=project, trace=trace, finding=finding,
            current_doc=current_doc, project_settings=project_settings, policy=policy,
        )

    # ── 4-step chain ──────────────────────────────────────────────────────

    def _draft_4step(
        self,
        *,
        project: Project,
        trace: ArtifactTrace,
        finding: DriftFinding | None,
        current_doc: str,
        source_content: str,
    ) -> DraftPatchResult | None:
        """
        4-step AI chain with structured output and verification.

        The number of steps actually executed depends on the artifact type
        via CHAIN_CONFIGS (steps=2 skips steps 3+4; steps=3 skips step 4).

        Returns None if any critical step fails (caller falls back to single-step).
        """
        try:
            # Resolve chain config for this artifact type
            artifact_type_val = (
                trace.artifact_type.value
                if hasattr(trace, "artifact_type") and trace.artifact_type is not None
                else "unknown"
            )
            chain_cfg = CHAIN_CONFIGS.get(artifact_type_val, DEFAULT_CHAIN_CONFIG)
            max_steps: int = chain_cfg["steps"]
            breaking_detector: bool = chain_cfg["breaking_detector"]

            # Token accumulators
            total_input_tokens = 0
            total_output_tokens = 0

            # ── Step 1: Characterize the structural diff ──────────────────
            # Check the LRU cache first using the changed_symbols list as key.
            changed_symbols_raw: list[dict] = []
            if finding and hasattr(finding, "changed_symbols") and finding.changed_symbols:
                changed_symbols_raw = finding.changed_symbols

            cache_key = _symbols_cache_key(changed_symbols_raw) if changed_symbols_raw else None
            cached_report = _cache_get_diff_report(cache_key) if cache_key else None

            if cached_report is not None:
                diff_report = cached_report
                logger.info("step1_cache_hit", cache_key=cache_key[:12] if cache_key else None)
            else:
                diff_report, step1_in, step1_out = self._step1_diff_report(
                    finding=finding, source_content=source_content
                )
                total_input_tokens += step1_in
                total_output_tokens += step1_out
                if diff_report is None:
                    return None
                if cache_key:
                    _cache_set_diff_report(cache_key, diff_report)

            # ── Step 2: Identify stale sections ──────────────────────────
            stale_sections = self._step2_stale_sections(diff_report=diff_report, current_doc=current_doc)

            # For steps=2 we only needed the diff report + stale detection;
            # generate a lightweight haiku patch and return early.
            if max_steps <= 2:
                patch_text = self._step3_generate_patch(
                    project=project,
                    trace=trace,
                    diff_report=diff_report,
                    stale_sections=stale_sections,
                    current_doc=current_doc,
                    source_content=source_content,
                    use_haiku=True,
                )
                if patch_text is None:
                    return None
                if breaking_detector:
                    patch_text = self._inject_breaking_changes_section(patch_text, diff_report)
                citations = self._build_citations(trace=trace, finding=finding)
                sections = self._suggest_sections(trace=trace, finding=finding)
                confidence = self._compute_confidence(diff_report=diff_report, verification=None)
                return DraftPatchResult(
                    summary=diff_report.summary or f"2-step patch for {trace.title}",
                    rationale=self._format_rationale(diff_report),
                    proposed_sections=sections,
                    citations=citations,
                    preview_markdown=patch_text,
                    ai_provider="anthropic-2step",
                    model_name=settings.anthropic_model,
                    input_summary=f"2-step: {len(diff_report.changes)} changes, {len(stale_sections)} stale sections",
                    confidence_score=confidence,
                    chain_steps_used=2,
                )

            # ── Step 3: Generate patch with surgical context ──────────────
            patch_text = self._step3_generate_patch(
                project=project,
                trace=trace,
                diff_report=diff_report,
                stale_sections=stale_sections,
                current_doc=current_doc,
                source_content=source_content,
            )
            if patch_text is None:
                return None

            if breaking_detector:
                patch_text = self._inject_breaking_changes_section(patch_text, diff_report)

            # For steps=3 we skip verification entirely.
            if max_steps <= 3:
                citations = self._build_citations(trace=trace, finding=finding)
                sections = self._suggest_sections(trace=trace, finding=finding)
                confidence = self._compute_confidence(diff_report=diff_report, verification=None)
                return DraftPatchResult(
                    summary=diff_report.summary or f"3-step patch for {trace.title}",
                    rationale=self._format_rationale(diff_report),
                    proposed_sections=sections,
                    citations=citations,
                    preview_markdown=patch_text,
                    ai_provider="anthropic-3step",
                    model_name=settings.anthropic_model,
                    input_summary=f"3-step: {len(diff_report.changes)} changes, {len(stale_sections)} stale sections",
                    confidence_score=confidence,
                    chain_steps_used=3,
                )

            # ── Step 4: Verify the patch (up to 3 retry attempts) ─────────
            verification = None
            for attempt in range(3):
                verification, v_in, v_out = self._step4_verify(
                    current_doc=current_doc,
                    patch_text=patch_text,
                    source_content=source_content,
                    diff_report=diff_report,
                )
                total_input_tokens += v_in
                total_output_tokens += v_out

                if verification is None or verification.verdict in ("PASS", "FAIL"):
                    break

                # verdict == "RETRY"
                logger.info(
                    "patch_verification_retry",
                    artifact=trace.id,
                    attempt=attempt + 1,
                    issues=verification.issues_found,
                )
                if attempt < 2:
                    # TODO: Replace with `await asyncio.sleep()` when the chain
                    # is converted to async.  time.sleep() blocks the thread /
                    # event loop, which is harmful under async servers.
                    sleep_secs = min(2 ** attempt, 2)  # cap at 2s
                    logger.warning(
                        "blocking_sleep_in_retry_loop",
                        seconds=sleep_secs,
                        attempt=attempt + 1,
                        note="time.sleep blocks the thread; convert to async",
                    )
                    time.sleep(sleep_secs)
                    patch_text = self._step3_generate_patch(
                        project=project, trace=trace, diff_report=diff_report,
                        stale_sections=stale_sections, current_doc=current_doc,
                        source_content=source_content, retry=True,
                        retry_issues=verification.issues_found,
                    ) or patch_text
                    if breaking_detector:
                        patch_text = self._inject_breaking_changes_section(patch_text, diff_report)

            citations = self._build_citations(trace=trace, finding=finding)
            sections = self._suggest_sections(trace=trace, finding=finding)
            confidence = self._compute_confidence(diff_report=diff_report, verification=verification)

            # Append token/cost metadata to the input_summary field so callers
            # can surface it without a schema change.
            approx_cost_usd = _model_cost(
                settings.anthropic_model or "claude-sonnet-4-6",
                total_input_tokens,
                total_output_tokens,
            )
            token_meta = (
                f" | tokens in={total_input_tokens} out={total_output_tokens}"
                f" cost≈${approx_cost_usd:.5f}"
            )

            return DraftPatchResult(
                summary=diff_report.summary if diff_report.summary else f"4-step patch for {trace.title}",
                rationale=self._format_rationale(diff_report),
                proposed_sections=sections,
                citations=citations,
                preview_markdown=patch_text,
                ai_provider="anthropic-4step",
                model_name=settings.anthropic_model,
                input_summary=(
                    f"4-step: {len(diff_report.changes)} changes, {len(stale_sections)} stale sections"
                    + token_meta
                ),
                confidence_score=confidence,
                chain_steps_used=4,
            )
        except Exception as exc:
            logger.warning("4step_chain_failed", error=str(exc), artifact=trace.id)
            return None

    # ── Breaking-change injector ───────────────────────────────────────────

    def _inject_breaking_changes_section(self, patch_text: str, diff_report: Any) -> str:
        """Append a '## Breaking Changes' section if the diff has BREAKING severity changes."""
        if not diff_report or not diff_report.has_breaking_changes:
            return patch_text
        breaking = [c for c in diff_report.changes if c.severity == "BREAKING"]
        if not breaking:
            return patch_text
        lines = ["\n\n## Breaking Changes\n"]
        for c in breaking:
            before_str = f" (was: `{c.before}`)" if c.before else ""
            after_str = f" → `{c.after}`" if c.after else ""
            lines.append(f"- **`{c.symbol_name}`** ({c.change_type}){before_str}{after_str}: {c.detail}")
        return patch_text + "\n".join(lines)

    # ── Step implementations ───────────────────────────────────────────────

    def _step1_diff_report(
        self, *, finding: DriftFinding | None, source_content: str
    ) -> tuple[Any | None, int, int]:
        """Step 1: Structured diff report via instructor.

        Returns (DiffReport | None, input_tokens, output_tokens).
        """
        client = _get_instructor_client()
        if client is None:
            return None, 0, 0

        # Use changed_symbols from the finding if available (from drift_engine)
        changed_symbols_context = ""
        if finding and hasattr(finding, "changed_symbols") and finding.changed_symbols:
            changed_symbols_context = f"\nStructural changes detected:\n" + "\n".join(
                f"  - {c.get('type','?')}: {c.get('symbol','?')} — {c.get('detail','')}"
                for c in finding.changed_symbols[:10]
            )

        artifact_id = finding.artifact_id if finding else "unknown"
        drift_signal = finding.summary if finding else "source changed"
        artifact_type = finding.artifact_type.value if finding and hasattr(finding, "artifact_type") else "unknown"

        prompt = dedent(f"""
            You are a code-change analyst. Produce a structured DiffReport for a documentation drift event.

            ARTIFACT: {artifact_id}
            ARTIFACT TYPE: {artifact_type}
            DRIFT SIGNAL: {drift_signal}
            {changed_symbols_context}

            SOURCE CODE (ground truth — the current state of the code):
            {source_content[:6000]}

            INSTRUCTIONS:
            - Populate `changes` with every symbol that has evidence of change in the source above.
            - Use EXACT symbol names from the source — never invent or paraphrase names.
            - Severity guide: BREAKING = callers must change their code; ADDITIVE = new optional feature;
              COSMETIC = rename, docstring, or format change only.
            - Set `has_breaking_changes` = true if any change is BREAKING.
            - For `affected_doc_sections`, list the exact markdown headings from typical API reference docs
              that would need updating (e.g. "Parameters", "Return Value", "add_memory").
            - If you cannot determine what changed from the source excerpt, return an empty `changes` list
              and set `summary` to "Insufficient source context to characterise changes."
        """).strip()

        try:
            raw = client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=2048,
                response_model=DiffReport,
                messages=[{"role": "user", "content": prompt}],
            )
            in_tok, out_tok = _extract_usage(raw)
            return raw, in_tok, out_tok
        except Exception as exc:
            logger.warning("step1_diff_report_failed", error=str(exc))
            return None, 0, 0

    def _step2_stale_sections(self, *, diff_report: Any, current_doc: str) -> list[str]:
        """Step 2: Identify stale sections.

        Uses the improved _detect_stale_sections helper when the finding's
        changed_symbols list is available on the diff_report; falls back to the
        original symbol-name line-scan for backwards compatibility.
        """
        if not diff_report or not diff_report.changes:
            # No structured diff — mark all sections as potentially stale
            return self._extract_section_names(current_doc)

        # Build changed_symbols in the format expected by _detect_stale_sections
        changed_symbols_for_detect = [
            {"n": c.symbol_name, "s": (c.before or "") + " " + (c.after or "")}
            for c in diff_report.changes
        ]

        stale = _detect_stale_sections(current_doc, changed_symbols_for_detect)
        return stale[:8]  # Cap at 8 sections

    def _step3_generate_patch(
        self,
        *,
        project: Project,
        trace: ArtifactTrace,
        diff_report: Any,
        stale_sections: list[str],
        current_doc: str,
        source_content: str,
        retry: bool = False,
        retry_issues: list[str] | None = None,
        use_haiku: bool = False,
    ) -> str | None:
        """Step 3: Generate the actual patch with surgical context.

        When *use_haiku* is True (steps=2 path) the cheaper haiku model is used.
        Uses section-level patching: only the stale sections are sent to the
        model, and the result is stitched back into the original document.
        """
        changes_text = ""
        # Extract valid symbol names from diff report for explicit hallucination guard
        valid_symbol_names: list[str] = []
        if diff_report and diff_report.changes:
            valid_symbol_names = [c.symbol_name for c in diff_report.changes[:15]]
            changes_text = "VERIFIED SYMBOL CHANGES (copy these names exactly — do not paraphrase):\n" + "\n".join(
                f"  [{c.severity}] {c.change_type}: `{c.symbol_name}`"
                + (f"\n    Before: {c.before}" if c.before else "")
                + (f"\n    After:  {c.after}" if c.after else "")
                + (f"\n    Note:   {c.detail}" if c.detail else "")
                for c in diff_report.changes[:15]
            )

        # Also mine symbol names directly from source as a second guard
        source_symbols = re.findall(r'\b(?:def |fn |func |class |pub fn |pub struct )\s*(\w+)', source_content)
        all_valid_symbols = list(dict.fromkeys(valid_symbol_names + source_symbols[:30]))  # deduplicated, order preserved

        stale_text = (
            "SECTIONS TO UPDATE (update these and only these; leave other sections verbatim):\n"
            + "\n".join(f"  - {s}" for s in stale_sections)
        ) if stale_sections else "UPDATE ALL SECTIONS (no specific stale sections identified)."

        retry_instruction = ""
        if retry:
            issues_detail = "\n".join(f"  - {issue}" for issue in (retry_issues or [])) or "  - patch was identical to original or contained hallucinations"
            retry_instruction = dedent(f"""

                RETRY NOTICE: The previous draft was rejected for these reasons:
                {issues_detail}
                You MUST fix all listed issues before returning the updated document.
            """)

        valid_symbols_guard = (
            "\nVALID SYMBOL NAMES (ONLY use names from this list when referencing code):\n"
            + ", ".join(f"`{s}`" for s in all_valid_symbols)
        ) if all_valid_symbols else ""

        # ── Section-level patching: only send stale sections to the model ──
        sections_map = _split_into_sections(current_doc)
        stale_section_content = "\n\n".join(
            sections_map[title] for title in stale_sections if title in sections_map
        )
        # If we couldn't extract any stale content, fall back to the full doc
        doc_context = stale_section_content if stale_section_content.strip() else current_doc[:2500]
        section_instruction = (
            "You are rewriting ONLY the stale sections shown below. "
            "Return ONLY those sections as a complete markdown fragment (keep their ## headings). "
            "Do not reproduce unrelated sections."
            if stale_section_content.strip()
            else "Return the COMPLETE updated documentation as a single markdown document."
        )

        # ── RAG: retrieve few-shot examples from approved patches ──
        few_shot_block = ""
        try:
            rag = get_rag()
            if rag.available:
                few_shot_examples = rag.get_few_shot_examples(
                    artifact_id=trace.id,
                    stale_sections=stale_sections,
                    n=3,
                )
                few_shot_block = format_few_shot_prompt(few_shot_examples)
        except Exception:  # noqa: BLE001
            pass  # RAG is optional — never block the chain

        prompt = dedent(f"""
            You are a senior technical writer producing a precise documentation patch.

            PROJECT: {project.name}
            ARTIFACT: {trace.title} (type: {trace.artifact_type.value})

            {changes_text}

            {stale_text}
            {valid_symbols_guard}

            SOURCE CODE (ground truth — the canonical reference for all names and signatures):
            {source_content[:6000]}

            STALE DOCUMENTATION SECTIONS (the only content you should rewrite):
            {doc_context}

            {few_shot_block}

            RULES — follow every rule without exception:
            1. {section_instruction}
            2. Use ONLY symbol names that appear in the VALID SYMBOL NAMES list or verbatim in SOURCE CODE above.
               If you are unsure of a name, omit the code reference rather than guessing.
            3. Update ONLY the sections listed in SECTIONS TO UPDATE. Copy all other sections byte-for-byte.
            4. If a section has no changes, reproduce it exactly as-is.
            5. Append a "## Changes Made" section at the end that lists each change and the source evidence for it.
            6. Do NOT invent parameters, return types, or functions that are not in the source.{retry_instruction}

            Return ONLY the updated markdown content. No preamble, no commentary outside the document.
        """).strip()

        if use_haiku:
            # Lightweight path: call haiku directly via raw httpx (same as _draft_with_anthropic
            # but forces the haiku model regardless of settings.anthropic_model).
            if not settings.anthropic_api_key:
                return None
            try:
                with httpx.Client(timeout=60.0) as client:
                    response = client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": settings.anthropic_api_key,
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json",
                        },
                        json={
                            "model": "claude-haiku-4-5-20251001",
                            "max_tokens": 2048,
                            "system": "You are a senior technical writer. Draft precise, factual documentation patches based on code drift signals. Return only the updated markdown document.",
                            "messages": [{"role": "user", "content": prompt}],
                        },
                    )
                    response.raise_for_status()
                    patched_fragment = response.json()["content"][0]["text"]
            except Exception as exc:
                logger.warning("step3_haiku_failed", error=str(exc))
                return None
        else:
            patched_fragment = self._draft_with_anthropic(prompt)

        if patched_fragment is None:
            return None

        # Stitch the patched sections back into the full document
        if stale_section_content.strip() and stale_sections:
            return _apply_section_patches(current_doc, stale_sections, patched_fragment)
        return patched_fragment

    def _step4_verify(
        self,
        *,
        current_doc: str,
        patch_text: str,
        source_content: str,
        diff_report: Any,
    ) -> tuple[Any | None, int, int]:
        """Step 4: Verify the patch is correct, substantive, and free of hallucinations.

        Returns (PatchVerification | None, input_tokens, output_tokens).
        """
        client = _get_instructor_client()
        if client is None:
            return None, 0, 0

        # Extract all identifiers from source — this is the hallucination allowlist
        source_names = sorted(set(re.findall(r'\b(?:def |fn |func |class |pub fn |pub struct )\s*(\w+)', source_content)))
        # Also include names from the diff report (already validated in step 1)
        if diff_report and diff_report.changes:
            source_names = sorted(set(source_names + [c.symbol_name for c in diff_report.changes]))

        # Use generous windows: enough to catch hallucinated names that appear mid-document
        original_excerpt = current_doc[:1500]
        patch_excerpt = patch_text[:2000]

        prompt = dedent(f"""
            You are a documentation QA reviewer. Evaluate whether this documentation patch is correct.

            VALID SOURCE SYMBOLS (the only code names that should appear in the patch):
            {', '.join(source_names[:40]) or '(none extracted — skip hallucination check)'}

            ORIGINAL DOCUMENTATION (first 1500 chars):
            {original_excerpt}

            PROPOSED PATCH (first 2000 chars):
            {patch_excerpt}

            EVALUATION CHECKLIST:
            1. `patch_changed_content`: Is the patch substantively different from the original?
               (Ignore whitespace-only differences. True = real content changed.)
            2. `hallucinated_symbols`: List every function/class/method name in the patch that does NOT
               appear in VALID SOURCE SYMBOLS. Only list code identifiers, not prose words.
               Empty list = no hallucinations.
            3. `issues_found`: List each specific problem as a short sentence. Common issues:
               - "patch is nearly identical to original"
               - "uses `foo()` which is not in source symbols"
               - "missing '## Changes Made' section"
               - "updated wrong section"
               Empty list = no issues.
            4. `verdict`:
               - PASS: patch is substantive, no hallucinations, no major issues
               - RETRY: patch has fixable problems (same as original, minor hallucinations, missing section)
               - FAIL: patch is severely wrong (contradicts source, multiple major hallucinations)

            Be strict: any hallucinated symbol name that would mislead a developer = at minimum RETRY.
        """).strip()

        try:
            raw = client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=512,  # raised from 256 — issues_found list needs room
                response_model=PatchVerification,
                messages=[{"role": "user", "content": prompt}],
            )
            in_tok, out_tok = _extract_usage(raw)
            return raw, in_tok, out_tok
        except Exception as exc:
            logger.warning("step4_verification_failed", error=str(exc))
            return None, 0, 0

    def _compute_confidence(self, *, diff_report: Any, verification: Any) -> float:
        """
        Compute a meaningful confidence score (0.0–1.0) from chain signals.

        Scoring model:
          Base:      0.70  (4-step chain completed)
          +0.15     diff_report has changes and they are characterised
          -0.15     has_breaking_changes (higher uncertainty)
          +0.10     verification PASS
          -0.20     verification RETRY or hallucinations found
          -0.40     verification FAIL
        Score is clamped to [0.10, 0.95].
        """
        score = 0.70

        if diff_report:
            if diff_report.changes:
                score += 0.15
            if diff_report.has_breaking_changes:
                score -= 0.15

        if verification:
            if verification.verdict == "PASS" and not verification.hallucinated_symbols:
                score += 0.10
            elif verification.verdict == "RETRY" or verification.hallucinated_symbols:
                score -= 0.20
            elif verification.verdict == "FAIL":
                score -= 0.40

        return round(max(0.10, min(0.95, score)), 2)

    def _format_rationale(self, diff_report: Any) -> str:
        if not diff_report or not diff_report.changes:
            return "Generated by 4-step AI chain from deterministic drift signal."
        changes_str = "; ".join(
            f"{c.change_type} {c.symbol_name}" for c in diff_report.changes[:5]
        )
        suffix = f"... (+{len(diff_report.changes)-5} more)" if len(diff_report.changes) > 5 else ""
        return f"Structural changes: {changes_str}{suffix}. Confidence: {'HIGH' if not diff_report.has_breaking_changes else 'MEDIUM'}."

    def _extract_section_names(self, doc: str) -> list[str]:
        """Extract section heading names, matching only ## headings.

        Must stay consistent with _split_into_sections which only splits on
        '## ' boundaries.  Previously this matched all heading levels (#, ##,
        ###, ...) causing subsection names to appear in the stale-section list
        even though _split_into_sections never creates keys for them — patches
        for those subsections silently failed to apply.
        """
        return [
            line[3:].strip()
            for line in doc.splitlines()
            if line.startswith("## ") and not line.startswith("### ")
        ][:8]

    # ── Single-step providers (fallback) ──────────────────────────────────

    def _draft_with_anthropic(self, prompt: str) -> str | None:
        if not settings.anthropic_api_key:
            return None
        try:
            with httpx.Client(timeout=60.0) as client:
                response = client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": settings.anthropic_api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": settings.anthropic_model,
                        "max_tokens": 2048,
                        "system": "You are a senior technical writer. Draft precise, factual documentation patches based on code drift signals. Return only the updated markdown document.",
                        "messages": [{"role": "user", "content": prompt}],
                    },
                )
                response.raise_for_status()
                return response.json()["content"][0]["text"]
        except Exception as e:
            logger.warning("anthropic_draft_failed", error=str(e))
            return None

    def _draft_with_openrouter(self, prompt: str, model: str) -> str | None:
        if not settings.openrouter_api_key:
            return None
        try:
            with httpx.Client(timeout=60.0) as client:
                response = client.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {settings.openrouter_api_key}",
                        "HTTP-Referer": "https://documint.xyz",
                        "X-Title": "Documint",
                        "content-type": "application/json",
                    },
                    json={
                        "model": model,
                        "max_tokens": 2048,
                        "messages": [
                            {"role": "system", "content": "You are a senior technical writer. Return only updated markdown."},
                            {"role": "user", "content": prompt},
                        ],
                    },
                )
                response.raise_for_status()
                return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            logger.warning("openrouter_draft_failed", model=model, error=str(e))
            return None

    def _deterministic_draft(self, *, project, trace, finding, current_doc, project_settings, policy) -> DraftPatchResult:
        del project_settings, policy
        citations = self._build_citations(trace=trace, finding=finding)
        sections = self._suggest_sections(trace=trace, finding=finding)
        summary = finding.summary if finding is not None else f"Refresh {trace.title}"
        rationale = finding.rationale if finding is not None else "Documentation should be refreshed against latest source files."
        preview_markdown = "\n".join([
            f"# Proposed update for {trace.title}", "",
            f"- Project: `{project.slug}`",
            f"- Artifact: `{trace.artifact_type.value}`",
            f"- Existing doc: `{len(current_doc.splitlines())}` lines", "",
            "## Why this patch exists", rationale, "",
            "## Suggested sections", *[f"- {s}" for s in sections], "",
            "## Source citations",
            *[f"- `{c.path}` at `{c.ref}`: {c.note}" for c in citations],
        ])
        return DraftPatchResult(
            summary=summary, rationale=rationale, proposed_sections=sections,
            citations=citations, preview_markdown=preview_markdown,
            ai_provider="deterministic", model_name=None,
            input_summary=f"{trace.id}:{len(trace.source_paths)} sources",
            chain_steps_used=0,
        )

    def _build_prompt(self, *, project, trace, finding, current_doc, source_content="", project_settings, policy) -> str:
        finding_summary = finding.summary if finding else "manual refresh"
        source_paths = ", ".join(trace.source_paths[:10]) or "(none)"
        source_block = (
            f"\nSOURCE FILES (ground truth):\n{source_content[:4000]}\n"
            if source_content.strip() else ""
        )
        return dedent(f"""
            You are a senior technical writer drafting a precise documentation patch.

            CONTEXT:
            - Project: {project.name}
            - Artifact: {trace.title} (type: {trace.artifact_type.value})
            - Drift finding: {finding_summary}
            - Changed source files: {source_paths}
            {source_block}
            CURRENT DOCUMENTATION:
            {current_doc[:3000]}

            TASK:
            1. Write a complete updated version of the above documentation
            2. Incorporate ALL changes reflected in the source files above
            3. Preserve sections not affected by the change
            4. Use exact function names, types, and signatures from the source code
            5. End with a "## Changes Made" section listing what you updated and why

            Return ONLY the updated markdown document.
        """).strip()

    def _suggest_sections(self, *, trace, finding) -> list[str]:
        if finding is not None and finding.suggested_actions:
            return finding.suggested_actions
        return [
            "Refresh the artifact overview against the latest source files.",
            "Update examples, endpoint names, and linked flows that appear in the trace.",
            "Record the latest verification and publish metadata before merge.",
        ]

    def _build_citations(self, *, trace, finding) -> list[PatchCitation]:
        reference = (
            finding.source_revision.ref
            if finding is not None and finding.source_revision is not None
            else (trace.latest_source_revision.ref if trace.latest_source_revision is not None else "WORKTREE")
        )
        return [
            PatchCitation(path=path, ref=reference, note="Mapped source input for this artifact.")
            for path in trace.source_paths[:5]
        ]


_generator = PatchGenerator()


def get_patch_generator() -> PatchGenerator:
    return _generator
