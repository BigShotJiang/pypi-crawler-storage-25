"""FastAPI application for the Documint control plane."""

from __future__ import annotations

import hmac
import json
import time
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

import jwt
import structlog
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from prometheus_client import Counter, Histogram, generate_latest
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from .config import settings
from .db import EarlyAccessTokenRecord, WaitlistSignupRecord, get_engine, init_db
from .db import session_scope as db_session_scope
from .check_runs import CheckRunManager
from .github import analyze_github_webhook, github_app_manifest, verify_github_signature
from .jobs import (
    close_arq_pool,
    dispatch_drift,
    dispatch_installation_sync,
    dispatch_patch,
    dispatch_publish,
    dispatch_pull_request,
    get_arq_pool,
)
from .models import (
    CLIExchangeRequest,
    DriftJobRequest,
    MCPRequest,
    MCPTool,
    PatchCreateRequest,
    ProjectCreateRequest,
    PublishRequest,
    PullRequestCreateRequest,
    QueuedJob,
    RevalidateRequest,
    TokenCreateRequest,
    WorkspaceCreateRequest,
)
from .connectors.notifications import get_notification_dispatcher
from .repository import get_service
from .utils.cache import get_cache

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer(),
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()
REQUEST_COUNT = Counter(
    "http_requests_total", "Total HTTP requests", ["method", "endpoint"]
)
REQUEST_DURATION = Histogram("http_request_duration_seconds", "HTTP request duration")
limiter = Limiter(key_func=get_remote_address)
security = HTTPBearer(auto_error=False)
_jwks_clients: dict[str, jwt.PyJWKClient] = {}


@dataclass(frozen=True)
class AuthContext:
    credential_source: str
    user_id: str | None = None
    workspace_ids: tuple[str, ...] = ()
    scopes: tuple[str, ...] = ()
    is_service: bool = False


def _tool_definitions() -> list[MCPTool]:
    return [
        MCPTool(
            name="list_projects",
            description="List persisted Documint projects visible to the current workspace.",
            input_schema={
                "type": "object",
                "properties": {"workspace_id": {"type": "string"}},
            },
        ),
        MCPTool(
            name="analyze_repository",
            description="Return the current project snapshot, including findings, PRs, and publish history.",
            input_schema={
                "type": "object",
                "properties": {"project_id": {"type": "string"}},
            },
        ),
        MCPTool(
            name="detect_doc_drift",
            description="Run deterministic doc drift detection for a project.",
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "string"},
                    "signal_type": {"type": "string"},
                    "changed_files": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["project_id"],
            },
        ),
        MCPTool(
            name="generate_doc_patch",
            description="Draft a reviewable patch for a finding or artifact.",
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "string"},
                    "artifact_id": {"type": "string"},
                    "finding_id": {"type": "string"},
                    "policy": {"type": "string"},
                },
            },
        ),
        MCPTool(
            name="review_doc_patch",
            description="Return the stored patch draft and its linked artifact trace.",
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "string"},
                    "patch_id": {"type": "string"},
                    "artifact_id": {"type": "string"},
                },
                "required": ["project_id"],
            },
        ),
        MCPTool(
            name="publish_preview",
            description="Publish repo-backed markdown into Documint-hosted public docs pages.",
            input_schema={
                "type": "object",
                "properties": {"project_id": {"type": "string"}},
                "required": ["project_id"],
            },
        ),
        MCPTool(
            name="explain_doc_trace",
            description="Explain which source files drive a documentation artifact.",
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "string"},
                    "artifact_id": {"type": "string"},
                },
                "required": ["artifact_id"],
            },
        ),
        MCPTool(
            name="get_project_activity",
            description="Return the project activity timeline for scans, patches, PRs, and publishes.",
            input_schema={
                "type": "object",
                "properties": {"project_id": {"type": "string"}},
                "required": ["project_id"],
            },
        ),
    ]


async def verify_token(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
) -> AuthContext:
    """Verify operator credentials against service, API-token, or Clerk tokens."""

    if credentials is None or not credentials.credentials:
        _localhost_hosts = ("127.0.0.1", "::1", "localhost", "testclient")
        client_host = getattr(request.client, "host", "") if request.client else ""
        if settings.debug and client_host in _localhost_hosts:
            return AuthContext(
                credential_source="debug",
                user_id=(
                    settings.default_user_id
                    if settings.auto_bootstrap_defaults
                    else None
                ),
            )
        if not settings.auth_token and not settings.clerk_jwks_url:
            return AuthContext(
                credential_source="debug",
                user_id=(
                    settings.default_user_id
                    if settings.auto_bootstrap_defaults
                    else None
                ),
            )
        raise HTTPException(status_code=401, detail="Authentication required")

    token = credentials.credentials
    if settings.auth_token and hmac.compare_digest(token, settings.auth_token):
        return AuthContext(credential_source="service", is_service=True)
    api_token = get_service().authenticate_api_token(token)
    if api_token is not None:
        return AuthContext(
            credential_source="api",
            user_id=api_token.user_id,
            workspace_ids=(api_token.workspace_id,),
            scopes=tuple(api_token.scopes),
        )
    claims = _verify_clerk_jwt(token)
    if claims is not None:
        user = get_service().ensure_clerk_user(claims)
        workspaces = get_service().list_workspaces(user.id)
        return AuthContext(
            credential_source="clerk",
            user_id=user.id,
            workspace_ids=tuple(item.id for item in workspaces),
        )
    raise HTTPException(status_code=401, detail="Invalid token")


def _verify_clerk_jwt(token: str) -> dict[str, Any] | None:
    if not settings.clerk_jwks_url or not settings.clerk_issuer:
        return None
    client = _jwks_clients.get(settings.clerk_jwks_url)
    if client is None:
        client = jwt.PyJWKClient(settings.clerk_jwks_url)
        _jwks_clients[settings.clerk_jwks_url] = client
    try:
        signing_key = client.get_signing_key_from_jwt(token)
        decoded = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=settings.clerk_audience,
            issuer=settings.clerk_issuer,
        )
    except Exception:
        return None
    return decoded


def verify_internal_secret(
    x_documint_internal: str | None = Header(default=None),
) -> None:
    if not settings.internal_revalidate_secret:
        if settings.debug:
            return
        raise HTTPException(status_code=503, detail="Internal secret not configured")
    if not x_documint_internal or not hmac.compare_digest(
        x_documint_internal, settings.internal_revalidate_secret
    ):
        raise HTTPException(status_code=401, detail="Invalid internal secret")


async def _validate_runtime_dependencies() -> None:
    errors = settings.production_validation_errors()
    if errors:
        raise RuntimeError(
            "Production configuration is invalid: " + "; ".join(errors)
        )
    if not settings.is_production_runtime():
        return
    engine = get_engine()
    with engine.connect() as connection:
        connection.exec_driver_sql("SELECT 1")
    cache = await get_cache()
    redis_connected = bool(cache.get_stats()["redis_cache"].get("connected"))
    if not redis_connected:
        raise RuntimeError("Production requires a reachable Redis cache")
    await get_arq_pool()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    logger.info("starting_documint_backend", repo_root=str(settings.repo_root))
    await _validate_runtime_dependencies()
    init_db()
    cache = await get_cache()
    try:
        logger.info("cache_initialized", stats=cache.get_stats())
        yield
    finally:
        await close_arq_pool()
        await cache.close()
        logger.info("shutting_down_documint_backend")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Documint V1",
        description="Persistent control plane for repo-native documentation operations.",
        version="0.3.0",
        lifespan=lifespan,
        docs_url="/docs" if settings.debug else None,
        redoc_url="/redoc" if settings.debug else None,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=(
            ["http://localhost:3000", "http://127.0.0.1:3000"]
            if settings.debug
            else [
                "https://documint.xyz",
                "https://www.documint.xyz",
                settings.app_base_url,
            ]
        ),
        allow_credentials=True,
        allow_methods=["DELETE", "GET", "OPTIONS", "PATCH", "POST", "PUT"],
        allow_headers=["*"],
    )
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    app.state.limiter = limiter
    app.add_exception_handler(
        RateLimitExceeded,
        cast(Callable[[Request, Exception], Response], _rate_limit_exceeded_handler),
    )
    app.add_exception_handler(
        PermissionError,
        lambda _request, exc: Response(
            content=json.dumps({"detail": str(exc)}),
            status_code=403,
            media_type="application/json",
        ),
    )

    @app.middleware("http")
    async def security_headers(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        return response

    @app.middleware("http")
    async def metrics_middleware(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        start_time = time.time()
        response = await call_next(request)
        # Use route template to avoid high-cardinality labels from path params
        route = request.scope.get("route")
        endpoint = route.path if route is not None else request.url.path
        REQUEST_COUNT.labels(method=request.method, endpoint=endpoint).inc()
        REQUEST_DURATION.observe(time.time() - start_time)
        return response

    @app.get("/")
    async def root() -> dict[str, str]:
        return {
            "name": "Documint V1",
            "project": settings.project_name,
            "site": settings.public_base_url,
        }

    @app.get("/health")
    async def health_check() -> dict[str, Any]:
        cache = await get_cache()
        runtime = get_service().runtime_status()
        return {
            "status": "healthy",
            "project_id": settings.project_id,
            "repo_root": runtime.repo_root,
            "docs_root": runtime.docs_root,
            "cache": cache.get_stats(),
            "runtime": jsonable_encoder(runtime),
        }

    @app.post("/waitlist")
    @limiter.limit("5/minute")
    async def join_waitlist(request: Request) -> dict[str, str]:
        body = await request.json()
        email = body.get("email", "").strip().lower()
        source = body.get("source", "landing")[:64]
        if not email or "@" not in email:
            raise HTTPException(status_code=422, detail="Valid email required")
        try:
            from sqlalchemy import select as _select
            with db_session_scope() as session:
                existing = session.scalar(
                    _select(WaitlistSignupRecord).where(WaitlistSignupRecord.email == email)
                )
                if existing is None:
                    session.add(WaitlistSignupRecord(email=email, source=source))
                    logger.info("waitlist_signup", email=email, source=source)
        except Exception as exc:
            logger.warning("waitlist_db_error", error=str(exc))
        return {"status": "ok", "message": "You're on the list!"}

    @app.post("/early-access")
    @limiter.limit("10/minute")
    async def early_access(request: Request) -> dict[str, str]:
        import secrets as _secrets
        body = await request.json()
        email = body.get("email", "").strip().lower()
        answer = body.get("answer", "").strip().replace(" ", "")

        if not email or "@" not in email:
            raise HTTPException(status_code=422, detail="Valid email required.")

        # The Look and Say sequence: 1 → 11 → 21 → 1211 → 111221 → 312211
        correct_answer = "312211"

        if answer == correct_answer:
            token = "dm_early_" + _secrets.token_urlsafe(24)
            try:
                with db_session_scope() as session:
                    existing = session.query(EarlyAccessTokenRecord).filter_by(email=email).first()
                    if existing:
                        return {
                            "status": "access_granted",
                            "token": existing.token,
                            "message": "You already have access.",
                        }
                    import uuid as _uuid
                    record = EarlyAccessTokenRecord(
                        id=_uuid.uuid4().hex,
                        token=token,
                        email=email,
                        source="brain_teaser",
                    )
                    session.add(record)
                    logger.info("early_access_granted", email=email, token=token[:12])
            except Exception as exc:
                logger.warning("early_access_db_error", error=str(exc))
            return {
                "status": "access_granted",
                "token": token,
                "message": "You think recursively. Access granted.",
            }
        else:
            # Wrong answer → add to waitlist
            try:
                with db_session_scope() as session:
                    existing = session.query(WaitlistSignupRecord).filter_by(email=email).first()
                    if existing is None:
                        session.add(WaitlistSignupRecord(email=email, source="brain_teaser_failed"))
                        logger.info("waitlist_signup_from_teaser", email=email)
            except Exception as exc:
                logger.warning("waitlist_db_error", error=str(exc))
            return {
                "status": "waitlisted",
                "message": "Not quite. You're on the waitlist — we'll reach out when we expand access.",
            }

    @app.get("/metrics")
    async def metrics() -> Response:
        return Response(generate_latest(), media_type="text/plain")

    @app.get("/runtime")
    async def runtime() -> Any:
        return jsonable_encoder(get_service().runtime_status())

    @app.get("/snapshot")
    async def snapshot(
        project_id: str | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().snapshot(project_id=project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/me")
    async def me(actor: AuthContext = Depends(verify_token)) -> Any:
        return jsonable_encoder(get_service().me(user_id=_actor_user_id(actor)))

    @app.get("/workspaces")
    async def list_workspaces(actor: AuthContext = Depends(verify_token)) -> Any:
        return jsonable_encoder(
            get_service().list_workspaces(user_id=_actor_user_id(actor))
        )

    @app.post("/workspaces")
    @limiter.limit("10/minute")
    async def create_workspace(
        request: Request,
        payload: WorkspaceCreateRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            get_service().create_workspace(payload, user_id=_actor_user_id(actor))
        )

    @app.post("/admin/bootstrap-self")
    @limiter.limit("5/minute")
    async def bootstrap_self(
        request: Request,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        if not actor.is_service and not settings.debug:
            raise HTTPException(
                status_code=403, detail="Bootstrap requires service auth"
            )
        return jsonable_encoder(get_service().bootstrap_self())

    @app.get("/projects")
    async def list_projects(
        workspace_id: str | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_projects(
                workspace_id=workspace_id, user_id=_actor_user_id(actor)
            )
        )

    @app.post("/projects")
    @limiter.limit("10/minute")
    async def create_project(
        request: Request,
        payload: ProjectCreateRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            get_service().create_project(payload, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}")
    async def get_project(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().get_project(project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/jobs/{job_id}")
    async def get_job(
        job_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().get_job(job_id, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/jobs")
    async def list_project_jobs(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_jobs(project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/sources")
    async def list_sources(actor: AuthContext = Depends(verify_token)) -> Any:
        return jsonable_encoder(
            get_service().list_sources(user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/findings")
    async def list_findings(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_findings(project_id, user_id=_actor_user_id(actor))
        )

    @app.post("/projects/{project_id}/rescan")
    @limiter.limit("30/minute")
    async def rescan_project(
        request: Request,
        project_id: str,
        payload: DriftJobRequest | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        drift_request = payload or DriftJobRequest(project_id=project_id)
        drift_request.project_id = project_id
        return jsonable_encoder(
            await dispatch_drift(drift_request, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/patches")
    async def list_patches(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_patches(project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/patches/{patch_id}")
    async def get_patch(
        project_id: str,
        patch_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().get_patch(project_id, patch_id, user_id=_actor_user_id(actor))
        )

    @app.post("/projects/{project_id}/findings/{finding_id}/patch")
    @limiter.limit("20/minute")
    async def create_patch(
        request: Request,
        project_id: str,
        finding_id: str,
        payload: PatchCreateRequest | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            await dispatch_patch(
                project_id=project_id,
                finding_id=finding_id,
                policy=payload.policy if payload is not None else "on_demand",
                user_id=_actor_user_id(actor),
            )
        )

    @app.post("/projects/{project_id}/patches/{patch_id}/approve")
    @limiter.limit("20/minute")
    async def approve_patch(
        request: Request,
        project_id: str,
        patch_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        try:
            return jsonable_encoder(
                get_service().approve_patch(
                    project_id=project_id,
                    patch_id=patch_id,
                    user_id=_actor_user_id(actor),
                )
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.post("/projects/{project_id}/findings/{finding_id}/approve")
    @limiter.limit("20/minute")
    async def approve_patch_by_finding(
        request: Request,
        project_id: str,
        finding_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Approve the patch associated with a finding (convenience for MCP agents)."""
        del request
        from .db import DocPatchRecord as DPR

        with db_session_scope() as session:
            patch_record = session.query(DPR).filter_by(
                project_id=project_id, finding_id=finding_id,
            ).order_by(DPR.created_at.desc()).first()
            if patch_record is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"No patch found for finding {finding_id}",
                )
            patch_id = patch_record.id
        try:
            return jsonable_encoder(
                get_service().approve_patch(
                    project_id=project_id,
                    patch_id=patch_id,
                    user_id=_actor_user_id(actor),
                )
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/projects/{project_id}/findings/{finding_id}/symbol-diff")
    async def get_symbol_diff(
        project_id: str,
        finding_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Return the symbol-level diff for a specific drift finding."""
        from .db import DriftFindingRecord as DFR

        with db_session_scope() as session:
            finding = session.get(DFR, finding_id)
            if finding is None or finding.project_id != project_id:
                raise HTTPException(status_code=404, detail="Finding not found")
            changed = getattr(finding, "changed_symbols", None) or []
            return {
                "finding_id": finding_id,
                "project_id": project_id,
                "artifact_id": finding.artifact_key,
                "changes": changed,
            }

    @app.post("/projects/{project_id}/patches/{patch_id}/pr")
    @limiter.limit("20/minute")
    async def open_pr(
        request: Request,
        project_id: str,
        patch_id: str,
        payload: PullRequestCreateRequest | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            await dispatch_pull_request(
                project_id=project_id,
                patch_id=patch_id,
                title=payload.title if payload is not None else None,
                user_id=_actor_user_id(actor),
            )
        )

    @app.get("/projects/{project_id}/publishes")
    async def list_publishes(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_publishes(project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/publishes/{deployment_id}")
    async def get_publish(
        project_id: str,
        deployment_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().get_publish(
                project_id, deployment_id, user_id=_actor_user_id(actor)
            )
        )

    @app.get("/projects/{project_id}/activity")
    async def get_project_activity(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_activity(project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/projects/{project_id}/claude-md")
    async def get_claude_md(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Get current CLAUDE.md content for a project."""
        from .db import ProjectRecord

        with db_session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise HTTPException(status_code=404, detail="Project not found")
            content = project.claude_md_content or (
                "# CLAUDE.md\n\n> Generated by Documint\n\n"
                "No content yet — trigger a publish to generate."
            )
        return {"content": content, "project_id": project_id}

    @app.get("/projects/{project_id}/agents-md")
    async def get_agents_md(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Get current AGENTS.md content for a project."""
        from .db import ProjectRecord

        with db_session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise HTTPException(status_code=404, detail="Project not found")
            content = project.agents_md_content or (
                "# AGENTS.md\n\n> Generated by Documint\n\n"
                "No content yet — trigger a publish to generate."
            )
        return {"content": content, "project_id": project_id}

    @app.get("/projects/{project_id}/llms-txt")
    async def get_llms_txt(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Get the llms.txt content for a project (per llmstxt.org spec)."""
        from .db import ProjectRecord

        with db_session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise HTTPException(status_code=404, detail="Project not found")
            content = project.llms_txt_content or (
                "# Project\n\n> Generated by Documint\n\n"
                "No content yet — trigger a publish to generate."
            )
        return {"content": content, "project_id": project_id}

    @app.get("/projects/{project_id}/llms-full-txt")
    async def get_llms_full_txt(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Get the llms-full.txt content for a project (per llmstxt.org spec)."""
        from .db import ProjectRecord

        with db_session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise HTTPException(status_code=404, detail="Project not found")
            content = project.llms_full_txt_content or (
                "# Project (full)\n\n> Generated by Documint\n\n"
                "No content yet — trigger a publish to generate."
            )
        return {"content": content, "project_id": project_id}

    @app.get("/projects/{project_id}/status")
    async def get_project_status(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Get a summary of project health: drift status, last scan, open findings count."""
        from .db import DriftFindingRecord, ProjectRecord

        with db_session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise HTTPException(status_code=404, detail="Project not found")
            open_findings = (
                session.query(DriftFindingRecord)
                .filter_by(project_id=project_id, status="open")
                .count()
            )
        return {
            "project_id": project_id,
            "name": project.name,
            "open_findings": open_findings,
            "last_scan": (
                project.last_scanned_at.isoformat()
                if project.last_scanned_at
                else None
            ),
        }

    @app.get("/projects/{project_id}/coverage")
    async def get_coverage(
        project_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        """Return per-artifact documentation coverage: what % of symbols are documented."""
        from .repository import DEFAULT_ARTIFACT_SPECS
        from .symbol_extractor import extract_symbols

        _COVERAGE_EXTENSIONS = frozenset(
            {".py", ".rs", ".go", ".ts", ".tsx", ".js", ".jsx"}
        )

        service = get_service()
        # Verify project access (raises KeyError -> 404 if not found)
        try:
            service.snapshot(project_id=project_id, user_id=_actor_user_id(actor))
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        root = Path(settings.repo_root).resolve()
        total_documented = 0
        total_symbols = 0
        artifacts_result: list[dict[str, Any]] = []

        for spec in DEFAULT_ARTIFACT_SPECS:
            # Collect source files matching source_patterns
            source_files: dict[str, str] = {}
            for pattern in spec.source_patterns:
                for match_path in root.glob(pattern):
                    if match_path.is_file() and match_path.suffix in _COVERAGE_EXTENSIONS:
                        try:
                            content = match_path.read_text(encoding="utf-8", errors="replace")
                            rel = str(match_path.relative_to(root))
                            source_files[rel] = content
                        except (OSError, ValueError):
                            continue

            # Extract symbols from source files
            symbols: list[str] = []
            for path, content in source_files.items():
                for entry in extract_symbols(content, path=path):
                    if entry.name not in symbols:
                        symbols.append(entry.name)

            if not symbols:
                continue

            # Read documentation files and check symbol coverage
            doc_contents: list[str] = []
            for doc_path in spec.doc_paths:
                full_doc = root / doc_path
                try:
                    doc_contents.append(
                        full_doc.read_text(encoding="utf-8", errors="replace")
                    )
                except (FileNotFoundError, OSError):
                    continue

            merged_docs = "\n".join(doc_contents)
            documented_count = sum(1 for sym in symbols if sym in merged_docs)

            pct = (documented_count / len(symbols) * 100) if symbols else 0.0
            artifacts_result.append({
                "id": spec.artifact_key,
                "name": spec.title,
                "documented": documented_count,
                "total": len(symbols),
                "percentage": round(pct, 1),
            })
            total_documented += documented_count
            total_symbols += len(symbols)

        overall_pct = (
            round(total_documented / total_symbols * 100, 1)
            if total_symbols > 0
            else 0.0
        )
        return {
            "project_id": project_id,
            "artifacts": artifacts_result,
            "overall": {
                "documented": total_documented,
                "total": total_symbols,
                "percentage": overall_pct,
            },
        }

    @app.get("/workspaces/{workspace_id}/tokens")
    async def list_workspace_tokens(
        workspace_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_api_tokens(workspace_id, user_id=_actor_user_id(actor))
        )

    @app.post("/workspaces/{workspace_id}/tokens")
    @limiter.limit("10/minute")
    async def create_workspace_token(
        request: Request,
        workspace_id: str,
        payload: TokenCreateRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        payload.workspace_id = workspace_id
        return jsonable_encoder(
            get_service().create_api_token(payload, user_id=_actor_user_id(actor))
        )

    @app.post("/workspaces/{workspace_id}/tokens/{token_id}/revoke")
    @limiter.limit("20/minute")
    async def revoke_workspace_token(
        request: Request,
        workspace_id: str,
        token_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        try:
            return jsonable_encoder(
                get_service().revoke_api_token(workspace_id, token_id, user_id=_actor_user_id(actor))
            )
        except ValueError as exc:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/integrations/github/app")
    async def get_github_app() -> dict[str, Any]:
        return github_app_manifest()

    @app.get("/integrations/github/installations")
    async def list_github_installations(
        workspace_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_installations(
                workspace_id, user_id=_actor_user_id(actor)
            )
        )

    @app.get("/integrations/github/installations/{installation_id}/repositories")
    async def get_github_installation_repositories(
        installation_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        return jsonable_encoder(
            get_service().list_installation_repositories(
                installation_id, user_id=_actor_user_id(actor)
            )
        )

    @app.post("/integrations/github/installations/{installation_id}/sync")
    @limiter.limit("20/minute")
    async def sync_github_installation(
        request: Request,
        installation_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            await dispatch_installation_sync(
                installation_id, user_id=_actor_user_id(actor)
            )
        )

    @app.post("/jobs/drift")
    @limiter.limit("30/minute")
    async def run_drift_job(
        request: Request,
        payload: DriftJobRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            await dispatch_drift(payload, user_id=_actor_user_id(actor))
        )

    @app.post("/jobs/publish")
    @limiter.limit("20/minute")
    async def publish_preview(
        request: Request,
        payload: PublishRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            await dispatch_publish(payload.project_id, user_id=_actor_user_id(actor))
        )

    @app.get("/artifacts/{artifact_id}/trace")
    async def get_artifact_trace(
        artifact_id: str,
        project_id: str | None = None,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        try:
            return jsonable_encoder(
                get_service().get_artifact_trace(
                    artifact_id,
                    project_id=project_id,
                    user_id=_actor_user_id(actor),
                )
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/previews/{preview_id}")
    async def get_preview(
        preview_id: str,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        publishes = get_service().list_publishes(
            settings.project_id, user_id=_actor_user_id(actor)
        )
        for deployment in publishes:
            if deployment.id == preview_id:
                return jsonable_encoder(deployment)
        raise HTTPException(status_code=404, detail="Preview not found")

    @app.post("/auth/cli/exchange")
    @limiter.limit("10/minute")
    async def exchange_cli_token(
        request: Request,
        payload: CLIExchangeRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> Any:
        del request
        return jsonable_encoder(
            get_service().exchange_cli_token(payload, user_id=_actor_user_id(actor))
        )

    @app.post("/internal/revalidate")
    @limiter.limit("60/minute")
    async def revalidate_publish(
        request: Request,
        payload: RevalidateRequest,
        internal: None = Depends(verify_internal_secret),
    ) -> Any:
        del request, internal
        return jsonable_encoder(
            get_service().revalidate_project(payload.project_id, payload.deployment_id)
        )

    @app.get("/public/projects/{workspace_slug}/{project_slug}/docs")
    async def get_public_doc_index(workspace_slug: str, project_slug: str) -> Any:
        return jsonable_encoder(
            get_service().get_public_doc_page(workspace_slug, project_slug, "index")
        )

    @app.get("/public/projects/{workspace_slug}/{project_slug}/docs/{page_path:path}")
    async def get_public_doc_page(
        workspace_slug: str, project_slug: str, page_path: str
    ) -> Any:
        try:
            return jsonable_encoder(
                get_service().get_public_doc_page(
                    workspace_slug, project_slug, page_path
                )
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.post("/integrations/github/webhooks")
    @limiter.limit("60/minute")
    async def handle_github_webhook(request: Request) -> Any:
        body = await request.body()
        verify_github_signature(body, request.headers.get("x-hub-signature-256"))
        try:
            payload = json.loads(body.decode("utf-8")) if body else {}
        except json.JSONDecodeError as exc:
            raise HTTPException(
                status_code=400, detail="Invalid GitHub payload"
            ) from exc

        event_name = request.headers.get("x-github-event")
        if not event_name:
            raise HTTPException(status_code=400, detail="Missing GitHub event header")

        action = analyze_github_webhook(event_name=event_name, payload=payload)
        response: dict[str, Any] = {
            "delivery_id": request.headers.get("x-github-delivery"),
            "event": event_name,
            "repository": action.repository,
            "ref": action.ref,
            "installation_id": action.installation_id,
        }
        if not action.should_process:
            get_service().record_webhook_delivery(
                delivery_id=request.headers.get("x-github-delivery"),
                event_name=event_name,
                repository=action.repository,
                action=(
                    payload.get("action")
                    if isinstance(payload.get("action"), str)
                    else None
                ),
                ref=action.ref,
                payload=cast(dict[str, object], payload),
                status="ignored",
            )
            response["status"] = "ignored"
            response["reason"] = action.reason
            return response

        if action.kind == "installation_sync" and action.installation_id is not None:
            account = payload.get("installation", {}).get("account", {})
            repositories = payload.get("repositories")
            repository_list = (
                repositories
                if isinstance(repositories, list)
                else (
                    payload.get("repositories_added")
                    if isinstance(payload.get("repositories_added"), list)
                    else None
                )
            )
            installation = get_service().upsert_github_installation(
                external_installation_id=action.installation_id,
                account_login=(
                    account.get("login")
                    if isinstance(account, dict)
                    and isinstance(account.get("login"), str)
                    else None
                ),
                account_type=(
                    account.get("type")
                    if isinstance(account, dict)
                    and isinstance(account.get("type"), str)
                    else None
                ),
                repository_selection=str(
                    payload.get("repository_selection") or "selected"
                ),
                repositories=cast(list[dict[str, Any]] | None, repository_list),
            )
            sync_result = await dispatch_installation_sync(installation.id)
            get_service().record_webhook_delivery(
                delivery_id=request.headers.get("x-github-delivery"),
                event_name=event_name,
                repository=action.repository,
                action=(
                    payload.get("action")
                    if isinstance(payload.get("action"), str)
                    else None
                ),
                ref=action.ref,
                payload=cast(dict[str, object], payload),
                status="processed",
            )
            response.update(
                {
                    "status": "processed",
                    "kind": "installation_sync",
                    "installation_record_id": installation.id,
                    "sync": jsonable_encoder(sync_result),
                }
            )
            return response

        if action.drift_request is None or not action.repository:
            response["status"] = "ignored"
            response["reason"] = action.reason or "missing_drift_request"
            return response
        project_id = get_service().resolve_project_id_for_repository(action.repository)
        if project_id is None:
            get_service().record_webhook_delivery(
                delivery_id=request.headers.get("x-github-delivery"),
                event_name=event_name,
                repository=action.repository,
                action=(
                    payload.get("action")
                    if isinstance(payload.get("action"), str)
                    else None
                ),
                ref=action.ref,
                payload=cast(dict[str, object], payload),
                status="ignored",
            )
            response["status"] = "ignored"
            response["reason"] = "repository_not_onboarded"
            return response

        action.drift_request.project_id = project_id

        # Create an in-progress GitHub Check Run for pull_request events so that
        # drift findings surface as inline annotations on the PR.
        check_run_id: int | None = None
        if (
            event_name == "pull_request"
            and action.installation_id is not None
            and action.ref is not None
            and action.repository is not None
            and "/" in action.repository
        ):
            _repo_owner, _repo_name = action.repository.split("/", 1)
            try:
                check_run_id = CheckRunManager().create_check_run(
                    owner=_repo_owner,
                    repo=_repo_name,
                    head_sha=action.ref,
                    installation_id=action.installation_id,
                )
            except Exception as _check_run_err:
                # Non-fatal: proceed with drift dispatch even if check run creation fails
                logger.warning(
                    "check_run_create_failed",
                    error=str(_check_run_err),
                    repository=action.repository,
                )

        run = await dispatch_drift(action.drift_request)

        # Notify configured connectors (Slack, etc.) about new findings.
        # In inline mode the drift run has already completed so findings
        # are available in the database.  In queue mode the job is just
        # enqueued; worker-side notification would be a future enhancement.
        try:
            if isinstance(run, QueuedJob) and run.status == "completed":
                _findings = get_service().list_findings(project_id)
                if _findings:
                    dispatcher = get_notification_dispatcher()
                    await dispatcher.on_drift_detected(project_id, _findings)
        except Exception:
            # Non-fatal: never let a notification failure break the webhook.
            logger.warning(
                "notification_dispatch_failed",
                project_id=project_id,
                exc_info=True,
            )

        get_service().record_webhook_delivery(
            delivery_id=request.headers.get("x-github-delivery"),
            event_name=event_name,
            repository=action.repository,
            action=(
                payload.get("action")
                if isinstance(payload.get("action"), str)
                else None
            ),
            ref=action.ref,
            payload=cast(dict[str, object], payload),
            status="processed",
        )
        response.update(
            {
                "status": "processed",
                "kind": "drift",
                "processed_at": datetime.now(tz=UTC).isoformat(),
                "project_id": project_id,
                "changed_files_count": len(action.changed_files),
                "check_run_id": check_run_id,
            }
        )
        if isinstance(run, QueuedJob):
            response.update(
                {
                    "job_id": run.job_id,
                    "signal_type": action.drift_request.signal_type,
                    "job_status": run.status,
                }
            )
        else:
            response.update(
                {
                    "run_id": run.id,
                    "signal_type": run.signal.type,
                    "findings_count": run.findings_count,
                }
            )
        return jsonable_encoder(response)

    @app.get("/mcp")
    async def mcp_manifest() -> dict[str, Any]:
        return {
            "server": {"name": "documint", "version": "0.3.0"},
            "transport": "http-jsonrpc",
            "tools": jsonable_encoder(_tool_definitions()),
        }

    @app.post("/mcp")
    async def handle_mcp(
        payload: MCPRequest,
        actor: AuthContext = Depends(verify_token),
    ) -> dict[str, Any]:
        if payload.method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": payload.id,
                "result": {"tools": jsonable_encoder(_tool_definitions())},
            }
        if payload.method != "tools/call":
            raise HTTPException(status_code=400, detail="Unsupported MCP method")

        tool_name = payload.params.get("name")
        if not isinstance(tool_name, str) or not tool_name:
            raise HTTPException(status_code=400, detail="Missing MCP tool name")
        arguments = payload.params.get("arguments", {})
        if not isinstance(arguments, dict):
            raise HTTPException(
                status_code=400, detail="MCP tool arguments must be an object"
            )
        result = _call_tool(tool_name, arguments, user_id=_actor_user_id(actor))
        return {
            "jsonrpc": "2.0",
            "id": payload.id,
            "result": {
                "content": [{"type": "text", "text": json.dumps(result, indent=2)}],
                "structuredContent": result,
            },
        }

    return app


def _call_tool(
    tool_name: str, arguments: dict[str, Any], user_id: str | None = None
) -> dict[str, Any]:
    # TODO: Consider making this async and using asyncio.to_thread() for
    # long-running calls like generate_doc_patch to avoid blocking the event loop.
    service = get_service()
    if tool_name == "list_projects":
        return {
            "projects": jsonable_encoder(
                service.list_projects(arguments.get("workspace_id"), user_id=user_id)
            )
        }
    if tool_name == "analyze_repository":
        return jsonable_encoder(
            service.snapshot(arguments.get("project_id"), user_id=user_id)
        )
    if tool_name == "detect_doc_drift":
        request = DriftJobRequest(**arguments)
        return jsonable_encoder(service.run_drift(request, user_id=user_id))
    if tool_name == "generate_doc_patch":
        return jsonable_encoder(
            service.generate_doc_patch(
                project_id=arguments.get("project_id"),
                artifact_id=arguments.get("artifact_id"),
                finding_id=arguments.get("finding_id"),
                policy=arguments.get("policy", "on_demand"),
                user_id=user_id,
            )
        )
    if tool_name == "review_doc_patch":
        project_id = cast(str, arguments["project_id"])
        patch_id = arguments.get("patch_id")
        artifact_id = arguments.get("artifact_id")
        patch = (
            service.get_patch(project_id, patch_id, user_id=user_id)
            if isinstance(patch_id, str)
            else None
        )
        resolved_artifact_id = (
            artifact_id
            if isinstance(artifact_id, str)
            else patch.artifact_id if patch is not None else None
        )
        if resolved_artifact_id is None:
            raise HTTPException(
                status_code=400,
                detail="review_doc_patch requires patch_id or artifact_id",
            )
        trace = service.get_artifact_trace(
            resolved_artifact_id,
            project_id=project_id,
            user_id=user_id,
        )
        return {
            "patch": jsonable_encoder(patch) if patch is not None else None,
            "artifact": jsonable_encoder(trace),
            "checklist": [
                "Confirm the summary still matches the latest source interfaces.",
                "Check examples and code snippets against source files in the trace.",
                "Publish a preview before opening or merging a docs PR.",
            ],
        }
    if tool_name == "publish_preview":
        return jsonable_encoder(
            service.publish_preview(arguments["project_id"], user_id=user_id)
        )
    if tool_name == "explain_doc_trace":
        return jsonable_encoder(
            service.explain_trace(
                arguments["artifact_id"],
                project_id=arguments.get("project_id"),
                user_id=user_id,
            )
        )
    if tool_name == "get_project_activity":
        return {
            "activity": jsonable_encoder(
                service.list_activity(arguments["project_id"], user_id=user_id)
            )
        }
    raise HTTPException(status_code=404, detail=f"Unknown MCP tool: {tool_name}")


def _actor_user_id(actor: AuthContext | None) -> str | None:
    if actor is None or actor.is_service:
        return None
    return actor.user_id


def main() -> None:
    import uvicorn

    uvicorn.run(
        "documint_mcp.server:create_app",
        factory=True,
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.lower(),
        reload=settings.debug,
        workers=1 if settings.debug else 2,
    )


if __name__ == "__main__":
    main()
