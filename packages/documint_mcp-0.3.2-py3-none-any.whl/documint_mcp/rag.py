"""RAG-based patch style learning using LanceDB Cloud.

Uses approved patches as few-shot examples to improve patch quality
and teach the AI the team's documentation style over time.

LanceDB Cloud provides full-text search (FTS) as the primary retrieval
method.  When Voyage AI is available (optional), results are reranked
for improved relevance.

Integrate by calling:
    store_approved_patch(patch)  — in repository.py's patch-approval method
    get_few_shot_examples(...)   — in ai.py before the sonnet step-3 prompt
"""
from __future__ import annotations

import hashlib
import logging
import os
import time

logger = logging.getLogger(__name__)

# Minimum approved patches before RAG activates (cold-start grace period)
MIN_EXAMPLES = 5

_TABLE_NAME = "documint_approved_patches"


class PatchRAG:
    """Manages a LanceDB Cloud table of approved patches for style learning."""

    def __init__(
        self,
        uri: str | None = None,
        api_key: str | None = None,
        region: str | None = None,
    ) -> None:
        self.available = False
        self._db = None
        self._table = None
        try:
            import lancedb  # noqa: PLC0415

            _uri = uri or os.getenv("LANCEDB_URI", "")
            _key = api_key or os.getenv("LANCEDB_API_KEY", "")
            _region = region or os.getenv("LANCEDB_REGION", "us-east-1")

            if not _uri or not _key:
                logger.debug("LanceDB URI or API key not set — RAG disabled")
                return

            self._db = lancedb.connect(_uri, api_key=_key, region=_region)

            # Get or create the table
            existing = self._db.table_names()
            if _TABLE_NAME in existing:
                self._table = self._db.open_table(_TABLE_NAME)
            else:
                # Seed row required to create schema — will be filtered from results
                import pyarrow as pa  # noqa: PLC0415

                schema = pa.schema([
                    pa.field("id", pa.string()),
                    pa.field("document", pa.string()),
                    pa.field("artifact_id", pa.string()),
                    pa.field("project_id", pa.string()),
                    pa.field("patch_id", pa.string()),
                    pa.field("created_at", pa.float64()),
                ])
                self._table = self._db.create_table(
                    _TABLE_NAME,
                    data=[{
                        "id": "seed",
                        "document": "seed document for schema initialization",
                        "artifact_id": "",
                        "project_id": "",
                        "patch_id": "",
                        "created_at": 0.0,
                    }],
                    schema=schema,
                )
                # Build FTS index on the document field
                self._table.create_fts_index("document")

            self.available = True
            logger.info("LanceDB RAG connected: %s", _uri)
        except Exception as exc:  # noqa: BLE001
            logger.debug("LanceDB unavailable for RAG style learning: %s", exc)

    def store_approved_patch(
        self,
        patch_id: str,
        artifact_id: str,
        project_id: str,
        section_titles: list[str],
        patch_content: str,
    ) -> None:
        """Store an approved patch for future few-shot retrieval."""
        if not self.available or not self._table:
            return
        try:
            doc = f"{artifact_id}::{', '.join(section_titles)}::{patch_content[:500]}"
            doc_id = hashlib.sha256(doc.encode()).hexdigest()[:16]
            self._table.add([{
                "id": doc_id,
                "document": doc,
                "artifact_id": artifact_id,
                "project_id": project_id,
                "patch_id": patch_id,
                "created_at": time.time(),
            }])
        except Exception as exc:  # noqa: BLE001
            logger.debug("Failed to store patch in LanceDB: %s", exc)

    def get_few_shot_examples(
        self,
        artifact_id: str,
        stale_sections: list[str],
        n: int = 3,
    ) -> list[str]:
        """Return up to n similar approved patches as few-shot examples.

        Uses LanceDB full-text search (FTS) as the primary retrieval method.
        When Voyage AI is available, the FTS results are reranked for better
        relevance.  Falls back to raw FTS ordering if reranking is unavailable.

        Returns empty list if LanceDB unavailable or too few examples exist.
        """
        if not self.available or not self._table:
            return []
        try:
            count = self._table.count_rows()
            # Subtract 1 for the seed row
            real_count = max(0, count - 1)
            if real_count < MIN_EXAMPLES:
                return []

            query = f"{artifact_id} {' '.join(stale_sections)}"

            # Fetch a larger candidate pool so reranking has room to improve
            candidate_limit = min(max(n * 3, 10), real_count)
            results = (
                self._table
                .search(query, query_type="fts")
                .where("id != 'seed'", prefilter=True)
                .limit(candidate_limit)
                .to_list()
            )
            documents = [r["document"] for r in results if r.get("document")]
            if not documents:
                return []

            # ── Voyage reranking (optional enhancement) ──
            from . import embeddings  # noqa: PLC0415

            reranked = embeddings.rerank(query, documents, top_k=n)
            if reranked is not None:
                return reranked

            # Fall back to raw FTS order, trimmed to n
            return documents[:n]
        except Exception as exc:  # noqa: BLE001
            logger.debug("Failed to query LanceDB for few-shot examples: %s", exc)
            return []


def format_few_shot_prompt(examples: list[str]) -> str:
    """Format retrieved examples as a prompt block for the patch step."""
    if not examples:
        return ""
    lines = [
        "Here are examples of previously-approved documentation patches for similar changes.",
        "Match this style and level of detail:\n",
    ]
    for i, ex in enumerate(examples, 1):
        lines.append(f"---EXAMPLE {i}---")
        lines.append(ex[:800])
        lines.append("")
    lines.append("---")
    return "\n".join(lines)


_rag_instance: PatchRAG | None = None


def get_rag() -> PatchRAG:
    """Return the module-level PatchRAG singleton."""
    global _rag_instance  # noqa: PLW0603
    if _rag_instance is None:
        _rag_instance = PatchRAG()
    return _rag_instance
