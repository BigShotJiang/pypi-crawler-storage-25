"""Symbol knowledge graph for cross-artifact drift detection.

Tracks symbol → artifact relationships so that when a symbol changes,
ALL artifacts that reference it can be identified (not just the one being scanned).

Usage:
    graph = get_symbol_graph()
    graph.index_artifact("api-reference", "project-1", symbols)
    affected = graph.find_affected_artifacts(["execute", "retry"], "project-1")
    # Returns: {"api-reference": ["execute"], "sdk-guides": ["execute", "retry"]}
"""
from __future__ import annotations

import logging
import os
import sqlite3
import threading
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

_DB_DIR = Path(".documint")
_DB_FILE = _DB_DIR / "symbol_graph.db"

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS symbol_artifact_map (
    symbol_name TEXT NOT NULL,
    artifact_id TEXT NOT NULL,
    project_id  TEXT NOT NULL,
    last_seen   TEXT NOT NULL,
    PRIMARY KEY (symbol_name, artifact_id, project_id)
);
"""
_CREATE_INDEX = "CREATE INDEX IF NOT EXISTS idx_symbol ON symbol_artifact_map(symbol_name);"


class SymbolGraph:
    """SQLite-backed symbol → artifact index."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        path = Path(db_path) if db_path else _DB_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        with self._lock:
            self._conn.execute(_CREATE_TABLE)
            self._conn.execute(_CREATE_INDEX)
            self._conn.commit()

    def index_artifact(self, artifact_id: str, project_id: str,
                        symbols: list[dict]) -> None:
        """Register all symbols for an artifact (upsert)."""
        now = datetime.now(UTC).isoformat()
        rows = [
            (sym.get("n", ""), artifact_id, project_id, now)
            for sym in symbols
            if sym.get("n")
        ]
        if rows:
            with self._lock:
                self._conn.executemany(
                    "INSERT OR REPLACE INTO symbol_artifact_map VALUES (?, ?, ?, ?)",
                    rows,
                )
                self._conn.commit()

    def find_affected_artifacts(self, changed_symbol_names: list[str],
                                 project_id: str) -> dict[str, list[str]]:
        """Return {artifact_id: [symbol_names]} for all affected artifacts.

        Checks ALL artifacts that reference any of the changed symbols,
        enabling cross-artifact drift detection.
        """
        result: dict[str, list[str]] = {}
        with self._lock:
            for sym_name in changed_symbol_names:
                rows = self._conn.execute(
                    "SELECT artifact_id FROM symbol_artifact_map "
                    "WHERE symbol_name = ? AND project_id = ?",
                    (sym_name, project_id),
                ).fetchall()
                for (artifact_id,) in rows:
                    result.setdefault(artifact_id, []).append(sym_name)
        return result

    def get_symbol_artifacts(self, symbol_name: str, project_id: str) -> list[str]:
        """Return all artifact IDs that reference this symbol."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT artifact_id FROM symbol_artifact_map "
                "WHERE symbol_name = ? AND project_id = ?",
                (symbol_name, project_id),
            ).fetchall()
        return [r[0] for r in rows]

    def close(self) -> None:
        """Close the SQLite connection."""
        with self._lock:
            self._conn.close()


_graph_instance: SymbolGraph | None = None


def get_symbol_graph() -> SymbolGraph:
    """Return the module-level SymbolGraph singleton."""
    global _graph_instance  # noqa: PLW0603
    if _graph_instance is None:
        _graph_instance = SymbolGraph()
    return _graph_instance
