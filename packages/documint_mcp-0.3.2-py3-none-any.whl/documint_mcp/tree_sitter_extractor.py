"""
Tree-sitter based symbol extraction for multi-language support.

Uses py-tree-sitter (>=0.23) with per-language grammar packages to parse
source code into a concrete syntax tree and extract exported/public symbols.

This module is OPTIONAL. If tree-sitter or any language grammar is not
installed, all functions return empty lists and log a debug message.
The caller should fall back to regex-based extraction.

Supported languages:
- Python (tree-sitter-python)
- TypeScript / JavaScript (tree-sitter-typescript, tree-sitter-javascript)
- Rust (tree-sitter-rust)  [not yet wired — reserved for future grammar package]
- Go (tree-sitter-go)      [not yet wired — reserved for future grammar package]
"""
from __future__ import annotations

from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Lazy availability detection
# ---------------------------------------------------------------------------

_TS_AVAILABLE: bool | None = None  # None = not yet checked


def _check_tree_sitter() -> bool:
    """Return True if the core tree-sitter package is importable."""
    global _TS_AVAILABLE
    if _TS_AVAILABLE is None:
        try:
            import tree_sitter  # noqa: F401

            _TS_AVAILABLE = True
        except ImportError:
            _TS_AVAILABLE = False
            logger.debug("tree_sitter_not_installed")
    return _TS_AVAILABLE


def _get_language(lang: str) -> Any | None:
    """
    Return a tree-sitter Language object for the given language name.

    Uses the per-language grammar packages (tree-sitter-python, etc.)
    which expose a ``language()`` callable returning the Language pointer.
    Returns None if the grammar package is not installed.
    """
    try:
        if lang == "python":
            import tree_sitter_python as tspython

            return tspython.language()
        elif lang in ("typescript", "tsx"):
            import tree_sitter_typescript as tstypescript

            if lang == "tsx":
                return tstypescript.language_tsx()
            return tstypescript.language_typescript()
        elif lang == "javascript":
            import tree_sitter_javascript as tsjavascript

            return tsjavascript.language()
        elif lang == "rust":
            import tree_sitter_rust as tsrust  # noqa: F401

            return tsrust.language()
        elif lang == "go":
            import tree_sitter_go as tsgo  # noqa: F401

            return tsgo.language()
    except ImportError:
        logger.debug("tree_sitter_grammar_not_installed", language=lang)
    except Exception as exc:
        logger.debug("tree_sitter_grammar_load_error", language=lang, error=str(exc))
    return None


# ---------------------------------------------------------------------------
# Node text helper
# ---------------------------------------------------------------------------


def _node_text(node: Any, source_bytes: bytes) -> str:
    """Extract the text content of a tree-sitter node."""
    return source_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")


def _node_line(node: Any) -> int:
    """Return the 1-based line number for a node."""
    return node.start_point[0] + 1


# ---------------------------------------------------------------------------
# Language-specific symbol walkers
# ---------------------------------------------------------------------------


def _extract_python_symbols(root: Any, source_bytes: bytes) -> list[dict[str, Any]]:
    """Extract module-level public symbols from a Python CST."""
    symbols: list[dict[str, Any]] = []

    for node in root.children:
        # Decorated definitions — unwrap to the inner definition
        actual = node
        if node.type == "decorated_definition":
            for child in node.children:
                if child.type in ("function_definition", "class_definition"):
                    actual = child
                    break

        if actual.type in ("function_definition",):
            name_node = actual.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if not name.startswith("_"):
                    params = _extract_python_params(actual, source_bytes)
                    ret = _extract_python_return(actual, source_bytes)
                    symbols.append({
                        "n": name,
                        "k": "fn",
                        "p": params,
                        "r": ret,
                        "l": _node_line(actual),
                    })

        elif actual.type == "class_definition":
            name_node = actual.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if not name.startswith("_"):
                    methods = _extract_python_class_methods(actual, source_bytes)
                    symbols.append({
                        "n": name,
                        "k": "class",
                        "p": methods,
                        "l": _node_line(actual),
                    })

        elif actual.type == "expression_statement":
            # Type alias: MyType = ...
            for child in actual.children:
                if child.type == "assignment":
                    left = child.child_by_field_name("left")
                    if left and left.type == "identifier":
                        name = _node_text(left, source_bytes)
                        if not name.startswith("_") and name[0:1].isupper():
                            symbols.append({
                                "n": name,
                                "k": "type",
                                "l": _node_line(actual),
                            })

        elif actual.type == "type_alias_statement":
            # Python 3.12+: type MyType = ...
            name_node = actual.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if not name.startswith("_"):
                    symbols.append({
                        "n": name,
                        "k": "type",
                        "l": _node_line(actual),
                    })

    return symbols


def _extract_python_params(func_node: Any, source_bytes: bytes) -> list[str]:
    """Extract parameter names (excluding self/cls) from a Python function node."""
    params: list[str] = []
    parameters = func_node.child_by_field_name("parameters")
    if not parameters:
        return params

    for child in parameters.children:
        if child.type in ("identifier",):
            name = _node_text(child, source_bytes)
            if name not in ("self", "cls"):
                params.append(name)
        elif child.type in ("typed_parameter", "default_parameter", "typed_default_parameter"):
            name_node = child.child_by_field_name("name")
            if not name_node:
                # For some node types the first identifier child is the name
                for sub in child.children:
                    if sub.type == "identifier":
                        name_node = sub
                        break
            if name_node:
                name = _node_text(name_node, source_bytes)
                if name not in ("self", "cls"):
                    # Include type annotation if present
                    type_node = child.child_by_field_name("type")
                    if type_node:
                        params.append(f"{name}:{_node_text(type_node, source_bytes)}")
                    else:
                        params.append(name)
    return params


def _extract_python_return(func_node: Any, source_bytes: bytes) -> str | None:
    """Extract return type annotation from a Python function node."""
    ret_node = func_node.child_by_field_name("return_type")
    if ret_node:
        return _node_text(ret_node, source_bytes)
    return None


def _extract_python_class_methods(class_node: Any, source_bytes: bytes) -> list[str]:
    """Extract public method names from a Python class body."""
    methods: list[str] = []
    body = class_node.child_by_field_name("body")
    if not body:
        return methods

    for child in body.children:
        actual = child
        if child.type == "decorated_definition":
            for sub in child.children:
                if sub.type == "function_definition":
                    actual = sub
                    break
        if actual.type == "function_definition":
            name_node = actual.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if not name.startswith("_") or name in ("__init__", "__call__"):
                    methods.append(name)
    return methods


# ---------------------------------------------------------------------------
# TypeScript / JavaScript
# ---------------------------------------------------------------------------


def _extract_typescript_symbols(root: Any, source_bytes: bytes) -> list[dict[str, Any]]:
    """Extract exported symbols from TypeScript/JavaScript CST."""
    symbols: list[dict[str, Any]] = []

    for node in root.children:
        if node.type == "export_statement":
            _walk_ts_export(node, source_bytes, symbols)
        # Also catch: export default function/class
        elif node.type in (
            "function_declaration",
            "class_declaration",
            "interface_declaration",
            "type_alias_declaration",
        ):
            # Top-level declarations without export keyword are not exported
            pass

    return symbols


def _walk_ts_export(export_node: Any, source_bytes: bytes, out: list[dict[str, Any]]) -> None:
    """Walk children of an export_statement to find the declaration."""
    for child in export_node.children:
        if child.type in ("function_declaration", "function_signature"):
            name_node = child.child_by_field_name("name")
            if name_node:
                params = _extract_ts_params(child, source_bytes)
                ret = _extract_ts_return(child, source_bytes)
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "fn",
                    "p": params,
                    "r": ret,
                    "l": _node_line(child),
                })

        elif child.type in ("class_declaration", "abstract_class_declaration"):
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "class",
                    "l": _node_line(child),
                })

        elif child.type == "interface_declaration":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "interface",
                    "l": _node_line(child),
                })

        elif child.type == "type_alias_declaration":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "type",
                    "l": _node_line(child),
                })

        elif child.type == "lexical_declaration":
            # export const myFn = (...) => { ... }
            for decl in child.children:
                if decl.type == "variable_declarator":
                    name_node = decl.child_by_field_name("name")
                    value_node = decl.child_by_field_name("value")
                    if name_node and value_node:
                        name = _node_text(name_node, source_bytes)
                        if value_node.type in ("arrow_function", "function_expression"):
                            params = _extract_ts_params(value_node, source_bytes)
                            ret = _extract_ts_return(value_node, source_bytes)
                            out.append({
                                "n": name,
                                "k": "fn",
                                "p": params,
                                "r": ret,
                                "l": _node_line(decl),
                            })
                        else:
                            out.append({
                                "n": name,
                                "k": "const",
                                "l": _node_line(decl),
                            })

        elif child.type == "enum_declaration":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "enum",
                    "l": _node_line(child),
                })


def _extract_ts_params(node: Any, source_bytes: bytes) -> list[str]:
    """Extract parameter strings from a TS/JS function-like node."""
    params: list[str] = []
    parameters = node.child_by_field_name("parameters")
    if not parameters:
        # Arrow functions: look for formal_parameters child
        for child in node.children:
            if child.type == "formal_parameters":
                parameters = child
                break
    if not parameters:
        return params

    for child in parameters.children:
        if child.type in (
            "required_parameter",
            "optional_parameter",
            "rest_parameter",
        ):
            # The pattern/name is typically the first identifier-like child
            pattern = child.child_by_field_name("pattern")
            if pattern:
                name = _node_text(pattern, source_bytes)
            else:
                # Fallback: grab first identifier
                for sub in child.children:
                    if sub.type == "identifier":
                        name = _node_text(sub, source_bytes)
                        break
                else:
                    continue
            type_ann = child.child_by_field_name("type")
            if type_ann:
                params.append(f"{name}:{_node_text(type_ann, source_bytes).lstrip(': ')}")
            else:
                params.append(name)
        elif child.type == "identifier":
            params.append(_node_text(child, source_bytes))
    return params


def _extract_ts_return(node: Any, source_bytes: bytes) -> str | None:
    """Extract return type annotation from a TS function node."""
    ret_node = node.child_by_field_name("return_type")
    if ret_node:
        text = _node_text(ret_node, source_bytes).lstrip(": ")
        return text if text else None
    return None


# ---------------------------------------------------------------------------
# Rust
# ---------------------------------------------------------------------------


def _extract_rust_symbols(root: Any, source_bytes: bytes) -> list[dict[str, Any]]:
    """Extract pub symbols from Rust CST."""
    symbols: list[dict[str, Any]] = []
    _walk_rust_items(root, source_bytes, symbols)
    return symbols


def _walk_rust_items(node: Any, source_bytes: bytes, out: list[dict[str, Any]]) -> None:
    """Recursively walk Rust items looking for pub declarations."""
    for child in node.children:
        if not _is_rust_pub(child):
            # Also descend into impl blocks to find pub methods
            if child.type in ("impl_item",):
                _walk_rust_items(child, source_bytes, out)
            # And into declaration_list (body of impl)
            if child.type == "declaration_list":
                _walk_rust_items(child, source_bytes, out)
            continue

        if child.type == "function_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                params = _extract_rust_params(child, source_bytes)
                ret = _extract_rust_return(child, source_bytes)
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "fn",
                    "p": params[:8],
                    "r": ret,
                    "l": _node_line(child),
                })

        elif child.type == "struct_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "struct",
                    "l": _node_line(child),
                })

        elif child.type == "enum_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "enum",
                    "l": _node_line(child),
                })

        elif child.type == "trait_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "trait",
                    "l": _node_line(child),
                })

        elif child.type == "type_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "type",
                    "l": _node_line(child),
                })

        elif child.type == "const_item":
            name_node = child.child_by_field_name("name")
            if name_node:
                out.append({
                    "n": _node_text(name_node, source_bytes),
                    "k": "const",
                    "l": _node_line(child),
                })


def _is_rust_pub(node: Any) -> bool:
    """Check if a Rust item has a visibility_modifier child indicating pub."""
    for child in node.children:
        if child.type == "visibility_modifier":
            return True
    return False


def _extract_rust_params(func_node: Any, source_bytes: bytes) -> list[str]:
    """Extract parameter strings from a Rust function_item."""
    params: list[str] = []
    parameters = func_node.child_by_field_name("parameters")
    if not parameters:
        return params

    for child in parameters.children:
        if child.type == "parameter":
            pattern = child.child_by_field_name("pattern")
            if pattern:
                name = _node_text(pattern, source_bytes)
                if name in ("self", "&self", "&mut self", "mut self"):
                    continue
                type_node = child.child_by_field_name("type")
                if type_node:
                    params.append(f"{name}:{_node_text(type_node, source_bytes)}")
                else:
                    params.append(name)
        elif child.type == "self_parameter":
            continue
    return params


def _extract_rust_return(func_node: Any, source_bytes: bytes) -> str | None:
    """Extract return type from a Rust function_item."""
    ret_node = func_node.child_by_field_name("return_type")
    if ret_node:
        text = _node_text(ret_node, source_bytes).lstrip("-> ").strip()
        return text if text else None
    return None


# ---------------------------------------------------------------------------
# Go
# ---------------------------------------------------------------------------


def _extract_go_symbols(root: Any, source_bytes: bytes) -> list[dict[str, Any]]:
    """Extract exported (capitalized) symbols from Go CST."""
    symbols: list[dict[str, Any]] = []

    for node in root.children:
        if node.type == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if name[0:1].isupper():
                    params = _extract_go_params(node, source_bytes)
                    ret = _extract_go_return(node, source_bytes)
                    symbols.append({
                        "n": name,
                        "k": "fn",
                        "p": params,
                        "r": ret,
                        "l": _node_line(node),
                    })

        elif node.type == "method_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, source_bytes)
                if name[0:1].isupper():
                    params = _extract_go_params(node, source_bytes)
                    ret = _extract_go_return(node, source_bytes)
                    symbols.append({
                        "n": name,
                        "k": "fn",
                        "p": params,
                        "r": ret,
                        "l": _node_line(node),
                    })

        elif node.type == "type_declaration":
            for child in node.children:
                if child.type == "type_spec":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = _node_text(name_node, source_bytes)
                        if name[0:1].isupper():
                            # Determine kind from the type body
                            type_node = child.child_by_field_name("type")
                            kind = "struct"
                            if type_node and type_node.type == "interface_type":
                                kind = "interface"
                            symbols.append({
                                "n": name,
                                "k": kind,
                                "l": _node_line(child),
                            })

        elif node.type == "const_declaration":
            for child in node.children:
                if child.type == "const_spec":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = _node_text(name_node, source_bytes)
                        if name[0:1].isupper():
                            symbols.append({
                                "n": name,
                                "k": "const",
                                "l": _node_line(child),
                            })

        elif node.type == "var_declaration":
            for child in node.children:
                if child.type == "var_spec":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = _node_text(name_node, source_bytes)
                        if name[0:1].isupper():
                            symbols.append({
                                "n": name,
                                "k": "const",
                                "l": _node_line(child),
                            })

    return symbols


def _extract_go_params(func_node: Any, source_bytes: bytes) -> list[str]:
    """Extract parameter strings from a Go function/method node."""
    params: list[str] = []
    parameters = func_node.child_by_field_name("parameters")
    if not parameters:
        return params

    for child in parameters.children:
        if child.type == "parameter_declaration":
            param_text = _node_text(child, source_bytes).strip()
            if param_text:
                params.append(param_text)
    return params


def _extract_go_return(func_node: Any, source_bytes: bytes) -> str | None:
    """Extract return type from a Go function/method node."""
    result = func_node.child_by_field_name("result")
    if result:
        text = _node_text(result, source_bytes).strip()
        return text if text else None
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# Map from language names to (grammar_key, walker_fn) pairs
_LANG_MAP: dict[str, tuple[str, Any]] = {
    "python": ("python", _extract_python_symbols),
    "typescript": ("typescript", _extract_typescript_symbols),
    "tsx": ("tsx", _extract_typescript_symbols),
    "javascript": ("javascript", _extract_typescript_symbols),
    "rust": ("rust", _extract_rust_symbols),
    "go": ("go", _extract_go_symbols),
}


def extract_symbols_ts(source_code: str, language: str) -> list[dict[str, Any]]:
    """
    Parse *source_code* with tree-sitter and extract exported/public symbols.

    Args:
        source_code: The source file contents as a string.
        language: One of "python", "typescript", "javascript", "tsx", "rust", "go".

    Returns:
        A list of symbol dicts with keys matching SymbolEntry.to_lsif_compact():
        ``{n: name, k: kind, p: [params], r: return_type, l: line}``.
        Returns an empty list if tree-sitter or the language grammar is unavailable.
    """
    if not _check_tree_sitter():
        return []

    entry = _LANG_MAP.get(language)
    if entry is None:
        logger.debug("tree_sitter_unsupported_language", language=language)
        return []

    grammar_key, walker_fn = entry

    ts_language = _get_language(grammar_key)
    if ts_language is None:
        return []

    try:
        from tree_sitter import Language, Parser

        parser = Parser(Language(ts_language))
        source_bytes = source_code.encode("utf-8")
        tree = parser.parse(source_bytes)
        return walker_fn(tree.root_node, source_bytes)
    except Exception as exc:
        logger.warning(
            "tree_sitter_parse_error",
            language=language,
            error=str(exc),
        )
        return []


def is_language_supported(language: str) -> bool:
    """Check whether tree-sitter extraction is available for *language*."""
    if not _check_tree_sitter():
        return False
    if language not in _LANG_MAP:
        return False
    grammar_key, _ = _LANG_MAP[language]
    return _get_language(grammar_key) is not None
