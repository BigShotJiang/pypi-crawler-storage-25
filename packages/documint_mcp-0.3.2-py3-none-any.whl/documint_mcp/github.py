"""GitHub App metadata, repository sync, and PR automation for Documint V1."""

from __future__ import annotations

import base64
import hashlib
import hmac
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import quote

import httpx
import jwt
from fastapi import HTTPException

from .config import settings
from .models import DriftJobRequest, SourceSignalType

SUPPORTED_GITHUB_EVENTS = (
    "push",
    "pull_request",
    "release",
    "installation",
    "installation_repositories",
)
GITHUB_APP_PERMISSIONS = {
    "contents": "write",
    "metadata": "read",
    "pull_requests": "write",
}
GITHUB_PR_ACTIONS = {"opened", "reopened", "ready_for_review", "synchronize"}
GITHUB_RELEASE_ACTIONS = {"edited", "prereleased", "published", "released"}
GITHUB_INSTALLATION_ACTIONS = {"created", "new_permissions_accepted"}
GITHUB_INSTALLATION_REPO_ACTIONS = {"added", "removed"}


@dataclass(frozen=True)
class GitHubWebhookAction:
    """Normalized webhook decision used by the API layer."""

    should_process: bool
    kind: str
    event_name: str
    repository: str | None
    installation_id: str | None = None
    drift_request: DriftJobRequest | None = None
    changed_files: tuple[str, ...] = ()
    ref: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class GitHubPullRequestResult:
    """Persistable result from a GitHub PR create/update action."""

    branch_name: str
    title: str
    url: str
    state: str
    number: int | None = None


def github_app_manifest() -> dict[str, Any]:
    """Return the public GitHub App metadata exposed by the API."""

    install_url = (
        f"https://github.com/apps/{settings.github_app_slug}/installations/new"
        if settings.github_app_slug
        else None
    )
    return {
        "name": settings.github_app_name,
        "slug": settings.github_app_slug,
        "app_id": settings.github_app_id,
        "repository": f"{settings.project_owner}/{settings.project_repo}",
        "webhook_url": f"{settings.api_base_url.rstrip('/')}/integrations/github/webhooks",
        "setup_url": f"{settings.public_base_url.rstrip('/')}/app?setup=github-app",
        "install_url": install_url,
        "events": list(SUPPORTED_GITHUB_EVENTS),
        "permissions": GITHUB_APP_PERMISSIONS,
        "configured": bool(
            settings.github_app_id
            and settings.github_app_slug
            and settings.github_webhook_secret
            and settings.github_app_private_key
        ),
        "configured_fields": {
            "github_app_id": bool(settings.github_app_id),
            "github_app_slug": bool(settings.github_app_slug),
            "github_webhook_secret": bool(settings.github_webhook_secret),
            "github_app_private_key": bool(settings.github_app_private_key),
        },
    }


def verify_github_signature(body: bytes, signature_header: str | None) -> None:
    """Validate GitHub webhook signatures using the configured shared secret."""

    if not settings.github_webhook_secret:
        if settings.debug:
            return
        raise HTTPException(
            status_code=503,
            detail="GitHub webhook secret is not configured",
        )

    if not signature_header:
        raise HTTPException(status_code=401, detail="Missing GitHub webhook signature")
    if not signature_header.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Invalid GitHub webhook signature")

    expected = (
        "sha256="
        + hmac.new(
            settings.github_webhook_secret.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()
    )
    if not hmac.compare_digest(expected, signature_header):
        raise HTTPException(status_code=401, detail="Invalid GitHub webhook signature")


def analyze_github_webhook(
    event_name: str,
    payload: dict[str, Any],
) -> GitHubWebhookAction:
    """Translate a GitHub webhook payload into a Documint action."""

    repository = _repository_full_name(payload)
    installation_id = _installation_id(payload)
    if event_name == "ping":
        return GitHubWebhookAction(
            should_process=False,
            kind="ignored",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            reason="ping",
        )

    if event_name not in SUPPORTED_GITHUB_EVENTS:
        return GitHubWebhookAction(
            should_process=False,
            kind="ignored",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            reason="unsupported_event",
        )

    if event_name == "installation":
        action = payload.get("action")
        if action not in GITHUB_INSTALLATION_ACTIONS:
            return GitHubWebhookAction(
                should_process=False,
                kind="ignored",
                event_name=event_name,
                repository=repository,
                installation_id=installation_id,
                reason=f"ignored_installation_action:{action}",
            )
        return GitHubWebhookAction(
            should_process=True,
            kind="installation_sync",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            ref=installation_id,
        )

    if event_name == "installation_repositories":
        action = payload.get("action")
        if action not in GITHUB_INSTALLATION_REPO_ACTIONS:
            return GitHubWebhookAction(
                should_process=False,
                kind="ignored",
                event_name=event_name,
                repository=repository,
                installation_id=installation_id,
                reason=f"ignored_installation_repositories_action:{action}",
            )
        return GitHubWebhookAction(
            should_process=True,
            kind="installation_sync",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            ref=installation_id,
        )

    if event_name == "push":
        changed_files = tuple(_collect_push_files(payload))
        return GitHubWebhookAction(
            should_process=True,
            kind="drift",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            drift_request=DriftJobRequest(
                project_id="",
                signal_type=SourceSignalType.PUSH,
                changed_files=list(changed_files),
            ),
            changed_files=changed_files,
            ref=payload.get("after") or payload.get("ref"),
        )

    if event_name == "pull_request":
        action = payload.get("action")
        if action not in GITHUB_PR_ACTIONS:
            return GitHubWebhookAction(
                should_process=False,
                kind="ignored",
                event_name=event_name,
                repository=repository,
                installation_id=installation_id,
                reason=f"ignored_pull_request_action:{action}",
            )
        return GitHubWebhookAction(
            should_process=True,
            kind="drift",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            drift_request=DriftJobRequest(
                project_id="",
                signal_type=SourceSignalType.PULL_REQUEST,
                changed_files=[],
            ),
            ref=_nested_value(payload, "pull_request", "head", "sha"),
        )

    action = payload.get("action")
    if action not in GITHUB_RELEASE_ACTIONS:
        return GitHubWebhookAction(
            should_process=False,
            kind="ignored",
            event_name=event_name,
            repository=repository,
            installation_id=installation_id,
            reason=f"ignored_release_action:{action}",
        )
    return GitHubWebhookAction(
        should_process=True,
        kind="drift",
        event_name=event_name,
        repository=repository,
        installation_id=installation_id,
        drift_request=DriftJobRequest(
            project_id="",
            signal_type=SourceSignalType.RELEASE,
            changed_files=[],
        ),
        ref=_nested_value(payload, "release", "tag_name"),
    )


def list_installation_repositories(installation_id: str) -> list[dict[str, Any]]:
    """Fetch accessible repositories for a GitHub App installation."""

    token = get_installation_access_token(installation_id)
    repositories: list[dict[str, Any]] = []
    page = 1
    while True:
        response = _github_request(
            "GET",
            "/installation/repositories",
            token=token,
            params={"per_page": 100, "page": page},
        )
        payload = response.json()
        page_repositories = payload.get("repositories", [])
        if not isinstance(page_repositories, list):
            break
        repositories.extend(
            repo for repo in page_repositories if isinstance(repo, dict)
        )
        if len(page_repositories) < 100:
            break
        page += 1
    return repositories


def create_or_update_pull_request(
    *,
    installation_id: str,
    owner: str,
    repo: str,
    base_branch: str,
    branch_name: str,
    target_path: str,
    content_markdown: str,
    title: str,
    body: str,
    commit_message: str,
) -> GitHubPullRequestResult:
    """Create or update a PR backed by a committed branch on GitHub."""

    token = get_installation_access_token(installation_id)
    base_sha = _get_branch_sha(owner, repo, base_branch, token)
    _ensure_branch(owner, repo, branch_name, base_sha, token)
    existing_sha = _get_content_sha(owner, repo, target_path, branch_name, token)
    if existing_sha is None:
        existing_sha = _get_content_sha(owner, repo, target_path, base_branch, token)
    _upsert_file(
        owner=owner,
        repo=repo,
        path=target_path,
        branch=branch_name,
        content=content_markdown,
        message=commit_message,
        token=token,
        sha=existing_sha,
    )
    existing_pr = _find_existing_pull_request(
        owner=owner,
        repo=repo,
        base_branch=base_branch,
        branch_name=branch_name,
        token=token,
    )
    if existing_pr is not None:
        updated = _github_request(
            "PATCH",
            f"/repos/{owner}/{repo}/pulls/{existing_pr['number']}",
            token=token,
            json_body={"title": title, "body": body},
        ).json()
        return GitHubPullRequestResult(
            branch_name=branch_name,
            title=str(updated.get("title") or title),
            url=str(updated["html_url"]),
            state=str(updated.get("state") or "open"),
            number=int(updated.get("number")) if updated.get("number") else None,
        )
    created = _github_request(
        "POST",
        f"/repos/{owner}/{repo}/pulls",
        token=token,
        json_body={
            "title": title,
            "body": body,
            "head": branch_name,
            "base": base_branch,
            "maintainer_can_modify": True,
        },
    ).json()
    return GitHubPullRequestResult(
        branch_name=branch_name,
        title=str(created.get("title") or title),
        url=str(created["html_url"]),
        state=str(created.get("state") or "open"),
        number=int(created.get("number")) if created.get("number") else None,
    )


def get_installation_access_token(installation_id: str) -> str:
    """Mint a short-lived installation token for a GitHub App installation."""

    if not settings.github_app_id or not settings.github_app_private_key:
        raise HTTPException(
            status_code=503,
            detail="GitHub App credentials are not configured for installation automation",
        )
    issued_at = datetime.now(tz=UTC)
    payload = {
        "iat": int((issued_at - timedelta(seconds=60)).timestamp()),
        "exp": int((issued_at + timedelta(minutes=9)).timestamp()),
        "iss": settings.github_app_id,
    }
    encoded = jwt.encode(
        payload,
        _normalized_private_key(settings.github_app_private_key),
        algorithm="RS256",
    )
    response = _github_request(
        "POST",
        f"/app/installations/{installation_id}/access_tokens",
        bearer_token=encoded,
    )
    token = response.json().get("token")
    if not isinstance(token, str) or not token:
        raise HTTPException(
            status_code=502,
            detail="GitHub did not return an installation access token",
        )
    return token


def _github_request(
    method: str,
    path: str,
    *,
    token: str | None = None,
    bearer_token: str | None = None,
    json_body: dict[str, Any] | None = None,
    params: dict[str, str | int | float | bool | None] | None = None,
) -> httpx.Response:
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": settings.github_api_version,
        "User-Agent": "documint/0.3",
    }
    if token is not None:
        headers["Authorization"] = f"token {token}"
    if bearer_token is not None:
        headers["Authorization"] = f"Bearer {bearer_token}"

    with httpx.Client(base_url=settings.github_api_url, timeout=20.0) as client:
        response = client.request(
            method,
            path,
            headers=headers,
            json=json_body,
            params=params,
        )
    if response.status_code >= 400:
        detail = response.text
        raise HTTPException(
            status_code=502,
            detail=f"GitHub API error for {method} {path}: {response.status_code} {detail}",
        )
    return response


def _get_branch_sha(owner: str, repo: str, branch: str, token: str) -> str:
    ref = _github_request(
        "GET",
        f"/repos/{owner}/{repo}/git/ref/heads/{quote(branch, safe='')}",
        token=token,
    ).json()
    sha = ref.get("object", {}).get("sha")
    if not isinstance(sha, str) or not sha:
        raise HTTPException(
            status_code=502, detail="GitHub branch ref did not include a SHA"
        )
    return sha


def _ensure_branch(
    owner: str, repo: str, branch: str, base_sha: str, token: str
) -> None:
    try:
        _github_request(
            "GET",
            f"/repos/{owner}/{repo}/git/ref/heads/{quote(branch, safe='')}",
            token=token,
        )
        return
    except HTTPException as exc:
        if "404" not in str(exc.detail):
            raise
    _github_request(
        "POST",
        f"/repos/{owner}/{repo}/git/refs",
        token=token,
        json_body={"ref": f"refs/heads/{branch}", "sha": base_sha},
    )


def _get_content_sha(
    owner: str,
    repo: str,
    path: str,
    branch: str,
    token: str,
) -> str | None:
    try:
        payload = _github_request(
            "GET",
            f"/repos/{owner}/{repo}/contents/{quote(path, safe='/')}",
            token=token,
            params={"ref": branch},
        ).json()
    except HTTPException as exc:
        if "404" in str(exc.detail):
            return None
        raise
    sha = payload.get("sha")
    return sha if isinstance(sha, str) and sha else None


def _upsert_file(
    *,
    owner: str,
    repo: str,
    path: str,
    branch: str,
    content: str,
    message: str,
    token: str,
    sha: str | None,
) -> None:
    payload: dict[str, Any] = {
        "message": message,
        "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
        "branch": branch,
    }
    if sha:
        payload["sha"] = sha
    _github_request(
        "PUT",
        f"/repos/{owner}/{repo}/contents/{quote(path, safe='/')}",
        token=token,
        json_body=payload,
    )


def _find_existing_pull_request(
    *,
    owner: str,
    repo: str,
    base_branch: str,
    branch_name: str,
    token: str,
) -> dict[str, Any] | None:
    payload = _github_request(
        "GET",
        f"/repos/{owner}/{repo}/pulls",
        token=token,
        params={"state": "open", "base": base_branch, "head": f"{owner}:{branch_name}"},
    ).json()
    if not isinstance(payload, list) or not payload:
        return None
    first = payload[0]
    return first if isinstance(first, dict) else None


def _normalized_private_key(raw_private_key: str) -> str:
    return raw_private_key.replace("\\n", "\n").strip()


def _repository_full_name(payload: dict[str, Any]) -> str | None:
    repository = payload.get("repository")
    if not isinstance(repository, dict):
        return None
    full_name = repository.get("full_name")
    return full_name if isinstance(full_name, str) and full_name.strip() else None


def _installation_id(payload: dict[str, Any]) -> str | None:
    installation = payload.get("installation")
    if not isinstance(installation, dict):
        return None
    installation_id = installation.get("id")
    if isinstance(installation_id, int):
        return str(installation_id)
    if isinstance(installation_id, str) and installation_id.strip():
        return installation_id
    return None


def _collect_push_files(payload: dict[str, Any]) -> list[str]:
    changed_files: set[str] = set()
    commits = payload.get("commits")
    if not isinstance(commits, list):
        commits = []
    for commit in commits:
        if not isinstance(commit, dict):
            continue
        for key in ("added", "modified", "removed"):
            values = commit.get(key)
            if not isinstance(values, list):
                continue
            changed_files.update(
                path.strip()
                for path in values
                if isinstance(path, str) and path.strip()
            )
    return sorted(changed_files)


def _nested_value(payload: dict[str, Any], *keys: str) -> str | None:
    current: Any = payload
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current if isinstance(current, str) and current.strip() else None
