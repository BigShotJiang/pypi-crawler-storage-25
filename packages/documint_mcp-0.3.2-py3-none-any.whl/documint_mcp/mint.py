"""
.mint — AI-native documentation format for Documint v1.0.

A .mint file is a TOML document with structured sections:
  [mint]       — metadata header (includes drift_status)
  [symbols]    — LSIF-compact symbol index (functions, types, etc.)
  [narrative]  — human-readable markdown prose
  [references] — source file -> line numbers mapping
  [api_schema] — API endpoint/function signatures
  [ai_context] — instructions for AI agents consuming this doc
  [links]      — related files and URLs

Compression: sections > 2KB are gzip+base64 encoded automatically.
Exports: to_claude_md(), to_llms_txt(), to_llms_full_txt(), to_agents_md(),
         to_api_reference()

LSIF-compact symbol format (symbols_lsif):
  Each entry is a dict with keys:
    n  — name (str, required)
    k  — kind (str: "function"|"class"|"type"|"const"|"method")
    s  — signature (str, full type signature)
    d  — docstring (str, first line only)
    f  — file (str, relative path)
    l  — line (int, 1-based)

  Griffe-enriched entries may additionally include:
    params     — list of {name, type, default} dicts
    returns    — return type annotation (str)
    decorators — list of decorator names (str)
    bases      — list of base class names (str, classes only)
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import struct
import tomllib
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import tomli_w
    _HAS_TOMLI_W = True
except ImportError:
    _HAS_TOMLI_W = False

# Intelligence layer (optional, .mint v2 only)
try:
    from .intelligence import IntelligenceLayer
    _INTELLIGENCE_AVAILABLE = True
except ImportError:
    _INTELLIGENCE_AVAILABLE = False
    IntelligenceLayer = None  # type: ignore[assignment,misc]


_COMPRESS_THRESHOLD_BYTES = 2048


def _compress(text: str) -> str:
    return base64.b64encode(gzip.compress(text.encode())).decode()


def _decompress(data: str) -> str:
    return gzip.decompress(base64.b64decode(data)).decode()


def _maybe_compress(text: str) -> tuple[str, str]:
    if len(text.encode()) > _COMPRESS_THRESHOLD_BYTES:
        return "gzip+base64", _compress(text)
    return "raw", text


def _decode_section(encoding: str, data: str) -> str:
    if encoding == "gzip+base64":
        return _decompress(data)
    return data


def _try_griffe_extraction(source_files: list[str]) -> list[dict]:
    """Attempt to extract rich symbols from Python files using Griffe.

    Returns an LSIF-compatible symbol list enriched with params, returns,
    decorators, and base classes when Griffe is available.  Returns an empty
    list on failure so the caller can fall back to its existing symbols.
    """
    try:
        from documint_mcp.griffe_extractor import extract_symbols_from_file, is_available
    except ImportError:
        return []

    if not is_available():
        return []

    all_symbols: list[dict] = []
    for fpath in source_files:
        if not fpath.endswith(".py"):
            continue
        try:
            syms = extract_symbols_from_file(fpath)
            if syms:
                all_symbols.extend(syms)
        except Exception:
            continue
    return all_symbols


def _format_param(p: dict) -> str:
    """Format a single parameter dict into a signature fragment."""
    s = p.get("name", "")
    t = p.get("type")
    d = p.get("default")
    if t:
        s += f": {t}"
    if d:
        s += f" = {d}"
    return s


def _build_rich_signature(sym: dict) -> str:
    """Build a full signature string from enriched symbol data.

    Prefers the Griffe-enriched 'params' / 'returns' fields; falls back to
    the compact 's' signature when those are absent.
    """
    params = sym.get("params")
    if params is None:
        return sym.get("s", "")

    name = sym.get("n", "")
    kind = sym.get("k", "")

    if kind == "class":
        return sym.get("s", f"class {name}")

    parts = [_format_param(p) for p in params]
    sig = f"{name}({', '.join(parts)})"
    ret = sym.get("returns")
    if ret:
        sig += f" -> {ret}"
    return sig


@dataclass
class MintDocument:
    MINT_MAX_AGE_DAYS: int = 7

    version: str = "1.0"
    language: str = "unknown"
    codebase_hash: str = ""
    generated_at: str = ""
    source_files: list[str] = field(default_factory=list)
    # symbols is either a list[dict] (LSIF-compact) or a legacy dict
    symbols: Any = field(default_factory=dict)
    narrative: str = ""
    references: dict[str, list[int]] = field(default_factory=dict)
    api_schema: str = ""
    ai_context: dict[str, Any] = field(default_factory=dict)
    links: dict[str, str] = field(default_factory=dict)
    drift_status: str | dict = "CLEAN"
    drift_history: list[dict] = field(default_factory=list)
    # v2: project intelligence layer (bootstrapped from git history)
    intelligence: "IntelligenceLayer | None" = field(default=None)

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path) -> "MintDocument":
        """Load a MintDocument from a file, auto-detecting binary (.mint) vs TOML format."""
        path = Path(path)
        with open(path, "rb") as f:
            raw = f.read()

        # Auto-detect binary .mint format by magic bytes
        if raw[:4] == b"MINT":
            return cls.from_binary(raw)

        # Fall back to TOML parsing
        return cls._from_toml_bytes(raw)

    @classmethod
    def _from_toml_bytes(cls, raw: bytes) -> "MintDocument":
        """Parse a MintDocument from raw TOML bytes (extracted for reuse)."""
        data = tomllib.loads(raw.decode("utf-8"))
        mint_hdr = data.get("mint", {})
        symbols_raw = data.get("symbols", {})
        symbols_text = _decode_section(
            symbols_raw.get("encoding", "raw"),
            symbols_raw.get("data", "[]"),
        )
        try:
            symbols = json.loads(symbols_text)
        except json.JSONDecodeError:
            symbols = []
        narrative_raw = data.get("narrative", {})
        narrative = _decode_section(
            narrative_raw.get("encoding", "raw"),
            narrative_raw.get("content", ""),
        )
        api_raw = data.get("api_schema", {})
        api_schema = _decode_section(
            api_raw.get("encoding", "raw"),
            api_raw.get("content", ""),
        )
        intelligence_val = None
        if _INTELLIGENCE_AVAILABLE and "intelligence" in data:
            intel_raw = data["intelligence"]
            intel_text = _decode_section(
                intel_raw.get("encoding", "raw"),
                intel_raw.get("data", "{}"),
            )
            try:
                import json as _json
                intelligence_val = IntelligenceLayer.from_dict(_json.loads(intel_text))
            except Exception:
                intelligence_val = None

        return cls(
            version=mint_hdr.get("version", "1.0"),
            language=mint_hdr.get("language", "unknown"),
            codebase_hash=mint_hdr.get("codebase_hash", ""),
            generated_at=mint_hdr.get("generated_at", ""),
            source_files=mint_hdr.get("source_files", []),
            symbols=symbols,
            narrative=narrative,
            references=data.get("references", {}),
            api_schema=api_schema,
            ai_context=data.get("ai_context", {}),
            links=data.get("links", {}),
            drift_status=mint_hdr.get("drift_status", "CLEAN"),
            intelligence=intelligence_val,
        )

    @classmethod
    def from_artifact_trace(
        cls,
        *,
        artifact_key: str,
        artifact_type: str,
        title: str,
        source_files: list[str],
        narrative_md: str,
        symbols_lsif: list[dict] | None = None,
        api_schema: str = "",
        language: str = "unknown",
        agent_instructions: str = "",
        links: dict[str, str] | None = None,
        priority: str = "high",
        role: str = "",
        drift_status: str = "CLEAN",
    ) -> "MintDocument":
        """
        Create a MintDocument from an artifact trace.

        Args:
            artifact_key:        Unique key for this artifact (e.g. "cilow-api")
            artifact_type:       One of ArtifactType values (e.g. "api_reference")
            title:               Human-readable title
            source_files:        List of source file paths covered by this artifact
            narrative_md:        Markdown prose (supplementary, lower authority than symbols)
            symbols_lsif:        LSIF-compact symbol list from drift_engine. Each entry:
                                   {"n": name, "k": kind, "s": signature, "d": docstring,
                                    "f": file, "l": line}
            api_schema:          HTTP/function endpoint definitions (OpenAPI fragment, etc.)
            language:            Primary programming language
            agent_instructions:  Instructions for AI agents consuming this doc
            links:               Related URLs {"readme": "...", "changelog": "..."}
            priority:            Agent priority hint ("high"|"medium"|"low")
            role:                Short description of this artifact's role for agents
            drift_status:        "CLEAN" or "STALE"
        """
        codebase_hash = hashlib.sha256(
            "\n".join(sorted(source_files)).encode()
        ).hexdigest()[:16]

        # Build LSIF symbols list; include artifact metadata as the first entry
        # using a sentinel kind so loaders can reconstruct the artifact identity.
        lsif: list[dict] = []
        meta_entry: dict[str, Any] = {
            "n": title,
            "k": "__artifact__",
            "artifact_key": artifact_key,
            "artifact_type": artifact_type,
        }
        lsif.append(meta_entry)

        # Try Griffe enrichment for Python files when no symbols provided
        if not symbols_lsif and language == "python" and source_files:
            symbols_lsif = _try_griffe_extraction(source_files)

        if symbols_lsif:
            lsif.extend(symbols_lsif)

        default_role = role or f"Covers {title} ({artifact_type})"

        ground_truth_preamble = (
            "Ground truth priority (highest to lowest):\n"
            "1. [SYM] — always current, extracted from live AST\n"
            "2. [REF] — exact line numbers in source files\n"
            "3. [API] — API schema\n"
            "4. [NAR] — narrative docs (MAY BE STALE — check drift.stale_sections)\n"
            "\n"
            "If drift.any_stale = true: do not cite stale [NAR] sections as fact. "
            "Cite [SYM] signatures directly."
        )

        if agent_instructions:
            resolved_instructions = ground_truth_preamble + "\n\n" + agent_instructions
        else:
            resolved_instructions = (
                ground_truth_preamble + "\n\n"
                f"This document covers {title} ({artifact_type}). "
                "Use [symbols] for type signatures, [references] for code locations, "
                "[narrative] as supplementary prose."
            )

        return cls(
            language=language,
            codebase_hash=f"sha256:{codebase_hash}",
            generated_at=datetime.now(timezone.utc).isoformat(),
            source_files=source_files,
            symbols=lsif,
            narrative=narrative_md,
            api_schema=api_schema,
            ai_context={
                "model_hint": "claude-sonnet-4-6",
                "priority": priority,
                "role": default_role,
                "instructions": resolved_instructions,
            },
            links=links or {},
            drift_status=drift_status,
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def to_file(self, path: Path) -> None:
        if not _HAS_TOMLI_W:
            raise RuntimeError(
                "tomli-w is required to write .mint files. Install with: pip install tomli-w"
            )
        path.parent.mkdir(parents=True, exist_ok=True)
        symbols_json = json.dumps(self.symbols, separators=(",", ":"))
        sym_enc, sym_data = _maybe_compress(symbols_json)
        narr_enc, narr_data = _maybe_compress(self.narrative)
        api_enc, api_data = _maybe_compress(self.api_schema)
        doc: dict[str, Any] = {
            "mint": {
                "version": self.version,
                "language": self.language,
                "codebase_hash": self.codebase_hash,
                "generated_at": self.generated_at,
                "source_files": self.source_files,
                "drift_status": self.drift_status,
            },
            "symbols": {"encoding": sym_enc, "data": sym_data},
            "narrative": {"encoding": narr_enc, "content": narr_data},
            "references": self.references,
            "api_schema": {"encoding": api_enc, "content": api_data},
            "ai_context": self.ai_context,
            "links": self.links,
        }
        if self.intelligence is not None:
            import json as _json
            doc["intelligence"] = {
                "encoding": "raw",
                "data": _json.dumps(self.intelligence.to_dict(), separators=(",", ":")),
            }
        with open(path, "wb") as f:
            tomli_w.dump(doc, f)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _artifact_meta(self) -> dict[str, str]:
        """Extract artifact metadata from the LSIF sentinel entry or legacy dict."""
        if isinstance(self.symbols, list):
            for entry in self.symbols:
                if isinstance(entry, dict) and entry.get("k") == "__artifact__":
                    return entry
        if isinstance(self.symbols, dict):
            return self.symbols
        return {}

    def _title(self) -> str:
        meta = self._artifact_meta()
        return meta.get("n", meta.get("title", "Documentation"))

    def _artifact_key(self) -> str:
        meta = self._artifact_meta()
        return meta.get("artifact_key", "")

    def _artifact_type(self) -> str:
        meta = self._artifact_meta()
        return meta.get("artifact_type", "unknown")

    def _export_symbols(self) -> list[dict]:
        """Return non-sentinel LSIF entries."""
        if isinstance(self.symbols, list):
            return [s for s in self.symbols if isinstance(s, dict) and s.get("k") != "__artifact__"]
        return []

    def _agent_context_xml(self) -> str:
        """Render the [agent_context] section as Claude XML."""
        key = self._artifact_key()
        artifact_type = self._artifact_type()
        title = self._title()
        priority = self.ai_context.get("priority", "high")
        role = self.ai_context.get("role", f"Covers {title}")
        last_verified = self.generated_at or datetime.now(timezone.utc).isoformat()
        source_hash = self.codebase_hash

        lines = [
            "<documint-artifact>",
            f'  <artifact key="{key}" type="{artifact_type}" priority="{priority}">',
            f"    <role>{role}</role>",
            "    <sections>",
            "      <symbols>Exact type signatures — ground truth for code generation</symbols>",
            "      <api_schema>HTTP/function endpoint definitions</api_schema>",
            "      <narrative>Supplementary prose — lower authority than symbols</narrative>",
            "    </sections>",
            "    <freshness>",
            f"      <drift-status>{self.drift_status}</drift-status>",
            f"      <last-verified>{last_verified}</last-verified>",
            f"      <source-hash>{source_hash}</source-hash>",
            "    </freshness>",
            "  </artifact>",
            "</documint-artifact>",
        ]
        return "\n".join(lines)

    def _check_freshness(self) -> None:
        """Raise ValueError if the .mint file is older than MINT_MAX_AGE_DAYS."""
        if not self.generated_at:
            return
        try:
            generated = datetime.fromisoformat(
                self.generated_at.replace("Z", "+00:00")
            )
        except (ValueError, TypeError, AttributeError):
            return  # if parsing fails, allow export
        age = datetime.now(timezone.utc) - generated
        if age.days > self.MINT_MAX_AGE_DAYS:
            raise ValueError(
                f".mint file is {age.days} days old. "
                "Run 'documint publish' to refresh before exporting."
            )

    # ------------------------------------------------------------------
    # Export methods
    # ------------------------------------------------------------------

    def to_claude_md(self) -> str:
        """Emit CLAUDE.md format with agent_context XML block embedded."""
        self._check_freshness()
        title = self._title()
        artifact_type = self._artifact_type()
        export_syms = self._export_symbols()

        lines: list[str] = [
            f"# {title}",
            "",
            "<!-- agent_context: generated by documint.xyz -->",
            self._agent_context_xml(),
            "",
        ]

        if export_syms:
            lines += ["## Symbols", ""]
            for sym in export_syms:
                name = sym.get("n", "")
                kind = sym.get("k", "")
                sig = _build_rich_signature(sym)
                doc = sym.get("d", "")
                f = sym.get("f", "")
                l = sym.get("l", "")
                decorators = sym.get("decorators", [])
                bases = sym.get("bases", [])

                # Decorator annotations
                if decorators:
                    for dec in decorators:
                        lines.append(f"- `@{dec}`")

                entry = f"- `{name}`"
                if sig:
                    entry += f" -- `{sig}`"
                if bases:
                    entry += f"  \n  Bases: {', '.join(f'`{b}`' for b in bases)}"
                if doc:
                    first_line = doc.strip().split("\n")[0]
                    entry += f"  \n  _{first_line}_"
                if f:
                    loc = f"`{f}`"
                    if l:
                        loc += f":{l}"
                    entry += f"  \n  {loc}"
                lines.append(entry)
            lines.append("")

        if self.api_schema:
            lines += ["## API Reference", "", "```", self.api_schema.rstrip(), "```", ""]

        if self.narrative:
            lines += ["## Documentation", "", self.narrative, ""]

        if self.source_files:
            lines += ["## Source Files", ""]
            for sf in self.source_files:
                lines.append(f"- `{sf}`")
            lines.append("")

        if self.ai_context.get("instructions"):
            lines += ["## Agent Instructions", "", self.ai_context["instructions"], ""]

        # Stale-sections warning from drift_status
        stale_sections: list[str] = []
        if isinstance(self.drift_status, dict):
            stale_sections = self.drift_status.get("stale_sections", [])
        if stale_sections:
            lines.append("")
            lines.append("## Stale Sections")
            lines.append("The following narrative sections may not match the current code.")
            lines.append("Trust [SYM] signatures over these sections:")
            for s in stale_sections:
                lines.append(f"- {s}")
            lines.append("")

        return "\n".join(lines)

    def to_agents_md(self) -> str:
        """Emit AGENTS.md format — simpler, less prescriptive than CLAUDE.md."""
        self._check_freshness()
        title = self._title()
        artifact_type = self._artifact_type()
        export_syms = self._export_symbols()

        lines: list[str] = [
            f"# Agent Context: {title}",
            "",
            f"Type: `{artifact_type}` · Status: `{self.drift_status}`",
            "",
        ]

        if self.ai_context.get("instructions"):
            lines += ["## Instructions", "", self.ai_context["instructions"], ""]

        if export_syms:
            lines += ["## Exports", ""]
            for sym in export_syms:
                name = sym.get("n", "")
                kind = sym.get("k", "")
                sig = _build_rich_signature(sym)
                doc = sym.get("d", "")
                params = sym.get("params", [])
                returns = sym.get("returns")
                bases = sym.get("bases", [])

                entry = f"- `{name}`"
                if kind:
                    entry += f" ({kind})"
                if sig:
                    entry += f": `{sig}`"
                lines.append(entry)

                # Tool-style parameter descriptions
                if params:
                    for p in params:
                        pname = p.get("name", "")
                        ptype = p.get("type", "")
                        pdef = p.get("default", "")
                        pdesc = f"  - `{pname}`"
                        if ptype:
                            pdesc += f" ({ptype})"
                        if pdef:
                            pdesc += f" [default: {pdef}]"
                        lines.append(pdesc)
                if returns:
                    lines.append(f"  - Returns: `{returns}`")
                if bases:
                    lines.append(f"  - Inherits: {', '.join(f'`{b}`' for b in bases)}")
                if doc:
                    first_line = doc.strip().split("\n")[0]
                    lines.append(f"  - {first_line}")
            lines.append("")

        if self.narrative:
            lines += ["## Documentation", "", self.narrative, ""]

        if self.source_files:
            lines += ["## Source Files", ""]
            for sf in self.source_files:
                lines.append(f"- `{sf}`")
            lines.append("")

        return "\n".join(lines)

    def to_llms_txt(self) -> str:
        """
        Per llmstxt.org spec: title line + blank line + summary + links section.
        This is the compact index version (not full content).
        Enriched with a structured symbol index when Griffe data is present.
        """
        self._check_freshness()
        title = self._title()
        artifact_type = self._artifact_type()
        export_syms = self._export_symbols()

        lines: list[str] = [
            f"# {title}",
            "",
        ]

        # Summary: first paragraph of narrative or a generated one
        summary = ""
        if self.narrative:
            first_para = self.narrative.strip().split("\n\n")[0].strip()
            # Strip any markdown headings from the first paragraph
            summary_lines = [ln for ln in first_para.splitlines() if not ln.startswith("#")]
            summary = " ".join(summary_lines).strip()
        if not summary:
            summary = f"{title} -- {artifact_type} documentation."
        lines += [f"> {summary}", ""]

        # Structured symbol index for LLM consumption
        if export_syms:
            lines += ["## API Index", ""]
            for sym in export_syms:
                name = sym.get("n", "")
                sig = _build_rich_signature(sym)
                doc = sym.get("d", "")
                if sig:
                    lines.append(f"- `{sig}`")
                else:
                    lines.append(f"- `{name}`")
                if doc:
                    first_line = doc.strip().split("\n")[0]
                    lines.append(f"  {first_line}")
            lines.append("")

        if self.links:
            lines.append("## Links")
            lines.append("")
            for name, url in self.links.items():
                lines.append(f"- [{name}]({url})")
            lines.append("")

        return "\n".join(lines)

    def to_llms_full_txt(self) -> str:
        """
        Full content version of llms.txt — all narrative + api_schema included.
        Used for /llms-full.txt endpoints.
        """
        self._check_freshness()
        title = self._title()
        artifact_type = self._artifact_type()
        export_syms = self._export_symbols()

        lines: list[str] = [
            f"# {title}",
            "",
            f"Type: {artifact_type} · Language: {self.language} · Status: {self.drift_status}",
            "",
        ]

        if export_syms:
            lines += ["## Exports", ""]
            for sym in export_syms:
                name = sym.get("n", "")
                kind = sym.get("k", "")
                sig = _build_rich_signature(sym)
                doc = sym.get("d", "")
                decorators = sym.get("decorators", [])
                bases = sym.get("bases", [])
                params = sym.get("params", [])
                returns = sym.get("returns")

                entry = f"### `{name}`"
                if kind:
                    entry += f" ({kind})"
                lines.append(entry)

                if decorators:
                    lines.append("Decorators: " + ", ".join(f"`@{d}`" for d in decorators))
                if bases:
                    lines.append("Inherits: " + ", ".join(f"`{b}`" for b in bases))
                if sig:
                    lines += [f"```\n{sig}\n```"]
                if params:
                    lines.append("Parameters:")
                    for p in params:
                        pname = p.get("name", "")
                        ptype = p.get("type", "")
                        pdef = p.get("default", "")
                        pdesc = f"- `{pname}`"
                        if ptype:
                            pdesc += f": {ptype}"
                        if pdef:
                            pdesc += f" (default: {pdef})"
                        lines.append(pdesc)
                if returns:
                    lines.append(f"Returns: `{returns}`")
                if doc:
                    lines.append("")
                    lines.append(doc)
                lines.append("")

        if self.api_schema:
            lines += ["## API Schema", "", "```", self.api_schema.rstrip(), "```", ""]

        if self.narrative:
            lines += ["## Documentation", "", self.narrative, ""]

        if self.links:
            lines += ["## Links", ""]
            for lname, url in self.links.items():
                lines.append(f"- [{lname}]({url})")
            lines.append("")

        return "\n".join(lines)

    def to_api_reference(self) -> str:
        """Generate a complete API reference document from .mint data.

        Produces publication-quality markdown organized by module/file, with
        full signatures, parameter tables, return types, inheritance, and
        docstrings.  Designed to be directly publishable as developer docs.
        """
        self._check_freshness()
        title = self._title()
        export_syms = self._export_symbols()

        lines: list[str] = [
            f"# {title} -- API Reference",
            "",
            f"*Generated by [Documint](https://documint.xyz) "
            f"on {self.generated_at or 'unknown date'}*",
            "",
        ]

        if self.narrative:
            first_para = self.narrative.strip().split("\n\n")[0].strip()
            summary_lines = [ln for ln in first_para.splitlines() if not ln.startswith("#")]
            summary = " ".join(summary_lines).strip()
            if summary:
                lines += [f"> {summary}", ""]

        if not export_syms:
            lines.append("No exported symbols found.")
            return "\n".join(lines)

        # Group symbols by file
        by_file: dict[str, list[dict]] = {}
        for sym in export_syms:
            f = sym.get("f", "(unknown)")
            by_file.setdefault(f, []).append(sym)

        # Table of contents
        lines += ["## Table of Contents", ""]
        for fpath in sorted(by_file):
            anchor = fpath.replace("/", "").replace(".", "").replace(" ", "-").lower()
            lines.append(f"- [{fpath}](#{anchor})")
        lines.append("")

        # Sections per file
        for fpath in sorted(by_file):
            lines += [f"---", "", f"## `{fpath}`", ""]
            syms = by_file[fpath]

            # Separate classes and top-level functions
            classes = [s for s in syms if s.get("k") == "class"]
            functions = [s for s in syms if s.get("k") == "function"]
            methods = [s for s in syms if s.get("k") == "method"]
            other = [s for s in syms if s.get("k") not in ("class", "function", "method")]

            if classes:
                for cls_sym in classes:
                    cls_name = cls_sym.get("n", "")
                    bases = cls_sym.get("bases", [])
                    doc = cls_sym.get("d", "")
                    decorators = cls_sym.get("decorators", [])
                    lineno = cls_sym.get("l", "")

                    lines.append(f"### class `{cls_name}`")
                    if decorators:
                        for dec in decorators:
                            lines.append(f"`@{dec}`  ")
                    if bases:
                        lines.append(f"**Bases:** {', '.join(f'`{b}`' for b in bases)}")
                    if lineno:
                        lines.append(f"*Defined at line {lineno}*")
                    lines.append("")
                    if doc:
                        lines += [doc, ""]

                    # Find methods belonging to this class
                    cls_methods = [m for m in methods if m.get("n", "").startswith(f"{cls_name}.")]
                    if cls_methods:
                        lines.append("#### Methods")
                        lines.append("")
                        for m in cls_methods:
                            self._render_callable(lines, m, heading_level=5)

            if functions:
                if classes:
                    lines += ["### Module-level Functions", ""]
                for fn in functions:
                    self._render_callable(lines, fn, heading_level=3 if not classes else 4)

            if other:
                for sym in other:
                    name = sym.get("n", "")
                    kind = sym.get("k", "")
                    sig = _build_rich_signature(sym)
                    doc = sym.get("d", "")
                    lines.append(f"### `{name}` ({kind})")
                    if sig:
                        lines += [f"```python", sig, "```", ""]
                    if doc:
                        lines += [doc, ""]

        # Source files reference
        if self.source_files:
            lines += ["---", "", "## Source Files", ""]
            for sf in self.source_files:
                lines.append(f"- `{sf}`")
            lines.append("")

        return "\n".join(lines)

    def _render_callable(self, lines: list[str], sym: dict, heading_level: int = 4) -> None:
        """Render a function or method symbol into the API reference lines list."""
        prefix = "#" * heading_level
        name = sym.get("n", "")
        sig = _build_rich_signature(sym)
        doc = sym.get("d", "")
        params = sym.get("params", [])
        returns = sym.get("returns")
        decorators = sym.get("decorators", [])
        lineno = sym.get("l", "")

        # Short name for methods: "Class.method" -> "method"
        display_name = name.split(".")[-1] if "." in name else name

        lines.append(f"{prefix} `{display_name}`")
        if decorators:
            for dec in decorators:
                lines.append(f"`@{dec}`  ")
        if sig:
            lines += ["", f"```python", sig, "```", ""]
        if lineno:
            lines.append(f"*Line {lineno}*")
            lines.append("")

        if params:
            # Filter out 'self' and 'cls' for cleaner docs
            doc_params = [p for p in params if p.get("name") not in ("self", "cls")]
            if doc_params:
                lines.append("| Parameter | Type | Default |")
                lines.append("|-----------|------|---------|")
                for p in doc_params:
                    pname = p.get("name", "")
                    ptype = p.get("type") or "--"
                    pdef = p.get("default") or "--"
                    lines.append(f"| `{pname}` | `{ptype}` | `{pdef}` |")
                lines.append("")

        if returns:
            lines.append(f"**Returns:** `{returns}`")
            lines.append("")

        if doc:
            lines += [doc, ""]

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def compression_ratio(self) -> float:
        """
        Ratio of .mint serialized size vs equivalent markdown size.
        A ratio < 1.0 means .mint is smaller than plain markdown.
        """
        # Equivalent markdown = narrative + api_schema + symbols rendered as text
        md_equivalent = self.to_llms_full_txt()
        md_size = len(md_equivalent.encode())

        # .mint size: approximate as JSON of all raw fields
        mint_payload = json.dumps(
            {
                "symbols": self.symbols,
                "narrative": self.narrative,
                "api_schema": self.api_schema,
            },
            separators=(",", ":"),
        )
        mint_size = len(mint_payload.encode())

        if md_size == 0:
            return 1.0
        return mint_size / md_size

    # ------------------------------------------------------------------
    # Binary serialization (.mint v2 binary format)
    # ------------------------------------------------------------------

    _SECTION_HDR = 0x01
    _SECTION_SYM = 0x02
    _SECTION_NAR = 0x03
    _SECTION_REF = 0x04
    _SECTION_AIC = 0x05
    _SECTION_API = 0x06
    _SECTION_DIF = 0x07
    _FOOTER_MARKER = 0xFF

    def _build_section(self, section_type: int, payload: bytes) -> bytes:
        """Encode a single binary section: type (1B) + length (4B BE) + payload."""
        return bytes([section_type]) + struct.pack(">I", len(payload)) + payload

    def to_binary(self) -> bytes:
        """
        Serialize this MintDocument to the .mint v2 binary format.

        Layout:
            HEADER  (6B): b"MINT" + version(1B) + flags(1B)
            SECTIONS:     type(1B) + length(4B BE) + payload(NB)  (repeating)
            FOOTER  (33B): 0xFF + SHA-256(all preceding bytes)
        """
        buf = bytearray()

        # --- Header ---
        buf += b"MINT"
        buf += bytes([0x02, 0x00])

        # --- Section 0x01: HDR (metadata JSON) ---
        drift_obj: dict[str, Any]
        if isinstance(self.drift_status, dict):
            drift_obj = {
                "any_stale": self.drift_status.get("any_stale", False),
                "stale_sections": self.drift_status.get("stale_sections", []),
            }
        else:
            drift_obj = {
                "any_stale": self.drift_status == "STALE",
                "stale_sections": [],
            }

        hdr_payload = json.dumps(
            {
                "version": self.version,
                "language": self.language,
                "codebase_hash": self.codebase_hash,
                "source_files": self.source_files,
                "generated_at": self.generated_at,
                "drift": drift_obj,
            },
            separators=(",", ":"),
        ).encode("utf-8")
        buf += self._build_section(self._SECTION_HDR, hdr_payload)

        # --- Section 0x02: SYM (gzip-compressed LSIF-compact JSON) ---
        sym_list = self.symbols if isinstance(self.symbols, list) else []
        if sym_list:
            sym_json = json.dumps(sym_list, separators=(",", ":")).encode("utf-8")
            sym_compressed = gzip.compress(sym_json)
            buf += self._build_section(self._SECTION_SYM, sym_compressed)

        # --- Section 0x03: NAR (raw markdown UTF-8) ---
        if self.narrative:
            buf += self._build_section(self._SECTION_NAR, self.narrative.encode("utf-8"))

        # --- Section 0x04: REF (JSON) ---
        if self.references:
            ref_payload = json.dumps(self.references, separators=(",", ":")).encode("utf-8")
            buf += self._build_section(self._SECTION_REF, ref_payload)

        # --- Section 0x05: AIC (JSON) ---
        if self.ai_context:
            aic_payload = json.dumps(self.ai_context, separators=(",", ":")).encode("utf-8")
            buf += self._build_section(self._SECTION_AIC, aic_payload)

        # --- Section 0x06: API (raw text UTF-8) ---
        if self.api_schema:
            buf += self._build_section(self._SECTION_API, self.api_schema.encode("utf-8"))

        # --- Section 0x07: DIF (JSON drift history) ---
        if self.drift_history:
            dif_payload = json.dumps(self.drift_history, separators=(",", ":")).encode("utf-8")
            buf += self._build_section(self._SECTION_DIF, dif_payload)

        # --- Footer ---
        checksum = hashlib.sha256(bytes(buf)).digest()
        buf += bytes([self._FOOTER_MARKER])
        buf += checksum

        return bytes(buf)

    @classmethod
    def from_binary(cls, data: bytes) -> "MintDocument":
        """
        Parse a .mint v2 binary file and return a MintDocument.

        Validates the magic bytes and SHA-256 checksum. Raises ValueError
        on format errors or checksum mismatch.
        """
        if len(data) < 6 + 33:  # header + minimal footer
            raise ValueError("File too small to be a valid .mint file")

        # --- Validate magic ---
        if data[:4] != b"MINT":
            raise ValueError("Not a .mint file (bad magic bytes)")

        version_byte = data[4]
        if version_byte != 0x02:
            import warnings
            warnings.warn(
                f".mint file version {version_byte} differs from expected v2; "
                "parsing will proceed but may produce unexpected results.",
                stacklevel=2,
            )

        # --- Validate footer checksum ---
        if data[-33] != cls._FOOTER_MARKER:
            raise ValueError("Missing footer marker (0xFF)")
        stored_checksum = data[-32:]
        computed_checksum = hashlib.sha256(data[:-33]).digest()
        if stored_checksum != computed_checksum:
            raise ValueError(
                "Checksum mismatch: file may be corrupted or truncated"
            )

        # --- Parse sections ---
        sections: dict[int, bytes] = {}
        offset = 6  # after header
        end = len(data) - 33  # before footer

        while offset < end:
            if offset + 5 > end:
                raise ValueError(
                    f"Truncated section header at offset {offset}"
                )
            section_type = data[offset]
            payload_len = struct.unpack(">I", data[offset + 1 : offset + 5])[0]
            offset += 5
            if offset + payload_len > end:
                raise ValueError(
                    f"Section 0x{section_type:02X} payload extends past footer "
                    f"(need {payload_len} bytes, only {end - offset} available)"
                )
            sections[section_type] = data[offset : offset + payload_len]
            offset += payload_len

        # --- Reconstruct MintDocument ---
        doc = cls()

        # HDR (0x01)
        if cls._SECTION_HDR in sections:
            hdr = json.loads(sections[cls._SECTION_HDR].decode("utf-8"))
            doc.version = hdr.get("version", "2.0")
            doc.language = hdr.get("language", "unknown")
            doc.codebase_hash = hdr.get("codebase_hash", "")
            doc.source_files = hdr.get("source_files", [])
            doc.generated_at = hdr.get("generated_at", "")
            drift = hdr.get("drift", {})
            if isinstance(drift, dict):
                doc.drift_status = drift
            else:
                doc.drift_status = "CLEAN"

        # SYM (0x02)
        if cls._SECTION_SYM in sections:
            sym_json = gzip.decompress(sections[cls._SECTION_SYM])
            doc.symbols = json.loads(sym_json.decode("utf-8"))
        else:
            doc.symbols = []

        # NAR (0x03)
        if cls._SECTION_NAR in sections:
            doc.narrative = sections[cls._SECTION_NAR].decode("utf-8")

        # REF (0x04)
        if cls._SECTION_REF in sections:
            doc.references = json.loads(sections[cls._SECTION_REF].decode("utf-8"))

        # AIC (0x05)
        if cls._SECTION_AIC in sections:
            doc.ai_context = json.loads(sections[cls._SECTION_AIC].decode("utf-8"))

        # API (0x06)
        if cls._SECTION_API in sections:
            doc.api_schema = sections[cls._SECTION_API].decode("utf-8")

        # DIF (0x07)
        if cls._SECTION_DIF in sections:
            doc.drift_history = json.loads(sections[cls._SECTION_DIF].decode("utf-8"))

        return doc

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self) -> list[str]:
        """
        Return a list of validation error strings. An empty list means valid.

        Checks:
        - codebase_hash is a non-empty string
        - generated_at is a parseable ISO 8601 datetime
        - version is "1.0" or "2.0"
        - language is non-empty
        - If symbols is non-empty, each entry has at least {"n": str, "k": str}
        """
        errors: list[str] = []

        # codebase_hash
        if not self.codebase_hash or not isinstance(self.codebase_hash, str):
            errors.append("codebase_hash must be a non-empty string")

        # generated_at
        if not self.generated_at:
            errors.append("generated_at is missing")
        else:
            try:
                datetime.fromisoformat(self.generated_at.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                errors.append(
                    f"generated_at is not a valid ISO datetime: {self.generated_at!r}"
                )

        # version
        if self.version not in ("1.0", "2.0"):
            errors.append(
                f"version must be '1.0' or '2.0', got {self.version!r}"
            )

        # language
        if not self.language or not isinstance(self.language, str):
            errors.append("language must be a non-empty string")

        # symbols
        if isinstance(self.symbols, list) and self.symbols:
            for i, sym in enumerate(self.symbols):
                if not isinstance(sym, dict):
                    errors.append(f"symbols[{i}] is not a dict")
                    continue
                if "n" not in sym or not isinstance(sym.get("n"), str):
                    errors.append(f"symbols[{i}] missing required 'n' (name) string")
                if "k" not in sym or not isinstance(sym.get("k"), str):
                    errors.append(f"symbols[{i}] missing required 'k' (kind) string")

        return errors
