"""
Documint MCP Server -- exposes Documint tools to AI coding agents.

Uses the high-level FastMCP API from the MCP Python SDK (>=1.0).

Transports:
  stdio (default)  -- for Claude Code / local IDE integrations
  sse              -- for cloud-based agents (Manus, etc.)
  streamable-http  -- modern streamable HTTP transport

Usage:
  # stdio (default, for Claude Code)
  documint-mcp

  # SSE transport on port 8100
  DOCUMINT_MCP_TRANSPORT=sse DOCUMINT_MCP_PORT=8100 documint-mcp

  # Or via CLI flag
  documint-mcp --transport sse --port 8100

ASGI mounting (for embedding in the FastAPI control-plane):
  from documint_mcp.mcp_server import mcp
  app.mount("/mcp-sse", mcp.sse_app())

Configure in Claude Code ~/.claude/claude.json:
{
  "mcpServers": {
    "documint": {
      "command": "uvx",
      "args": ["documint-mcp"],
      "env": { "DOCUMINT_API_KEY": "dm_live_xxxx" }
    }
  }
}
"""

from __future__ import annotations

import argparse
import base64
import json
import logging
import os
import re
import urllib.parse
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

_logger = logging.getLogger("documint.mcp")
DEFAULT_API_BASE_URL = "https://api-production-285b.up.railway.app"

# ---- API client -------------------------------------------------------------


class DocumintClient:
    """Thin async HTTP wrapper around the Documint REST API."""

    def __init__(self, api_key: str, base_url: str = DEFAULT_API_BASE_URL) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=30,
        )

    async def get(self, path: str) -> Any:
        resp = await self._http.get(path)
        resp.raise_for_status()
        return resp.json()

    async def post(self, path: str, body: dict[str, Any] | None = None) -> Any:
        resp = await self._http.post(path, json=body or {})
        resp.raise_for_status()
        return resp.json()

    async def close(self) -> None:
        await self._http.aclose()


# ---- Lifespan (manages the HTTP client) -------------------------------------

_client: DocumintClient | None = None


def _get_client() -> DocumintClient:
    """Return the shared DocumintClient, creating it on first call."""
    global _client
    if _client is None:
        api_key = os.environ.get("DOCUMINT_API_KEY", "")
        if not api_key:
            raise RuntimeError("DOCUMINT_API_KEY environment variable not set")
        base_url = os.environ.get("DOCUMINT_API_URL", DEFAULT_API_BASE_URL)
        _client = DocumintClient(api_key=api_key, base_url=base_url)
    return _client


@asynccontextmanager
async def _lifespan(server: FastMCP) -> AsyncIterator[None]:  # noqa: ARG001
    """Startup / shutdown hook -- ensures the HTTP client is closed cleanly."""
    yield
    if _client is not None:
        await _client.close()


# ---- Helpers -----------------------------------------------------------------


def _pid(project_id: str) -> str:
    """URL-encode a project ID for path segments."""
    return urllib.parse.quote(project_id, safe="")


def _paginate(data: Any, key: str, offset: int = 0, limit: int = 20) -> str:
    """Extract a list from *data*, paginate, and return JSON."""
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = data.get(key, [])
    else:
        items = []
    total = len(items)
    items = items[offset : offset + limit]
    return json.dumps({"total": total, "offset": offset, "limit": limit, "items": items})


def _json(data: Any) -> str:
    return json.dumps(data)


# ---- FastMCP server ----------------------------------------------------------

mcp = FastMCP(
    "documint",
    instructions=(
        "Documint keeps documentation in sync with source code. "
        "Typical workflow: list_projects -> get_findings -> get_patch -> approve_patch."
    ),
    lifespan=_lifespan,
)


# ---- Tools (15 total -- same names and schemas as before) --------------------


@mcp.tool(
    name="documint_list_projects",
    description=(
        "List all Documint projects connected to this API key. "
        "Returns an array of project objects, each with: id (use as project_id in other tools), "
        "name, slug, github_repo (owner/name), and onboarding_status. "
        "Call this first when you need to discover project IDs. "
        "Typical workflow: list_projects -> get_findings -> get_patch -> approve_patch."
    ),
)
async def documint_list_projects(offset: int = 0, limit: int = 20) -> str:
    """List all Documint projects connected to this API key."""
    client = _get_client()
    data = await client.get("/projects")
    return _paginate(data, "projects", offset, limit)


@mcp.tool(
    name="documint_list_artifacts",
    description=(
        "List all artifact definitions for a project. Each artifact maps source files to a documentation file "
        "(e.g., 'src/memory.py' -> 'docs/api/memory.md'). "
        "Returns an array with: artifact_key (use in documint_get_mint), title, artifact_type "
        "(api_reference | sdk_guides | mcp_reference | changelog | migration_notes), "
        "doc_paths (docs being tracked), and source_patterns (source globs being watched). "
        "Use artifact_key with documint_get_mint to read the structured machine-readable docs."
    ),
)
async def documint_list_artifacts(project_id: str, offset: int = 0, limit: int = 20) -> str:
    """List artifact definitions for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/artifacts")
    return _paginate(data, "artifacts", offset, limit)


@mcp.tool(
    name="documint_get_findings",
    description=(
        "List open documentation drift findings for a project. A finding means source code changed "
        "but the corresponding documentation was not updated. "
        "Returns an array of finding objects with: id (finding_id for other tools), artifact_id, "
        "severity (high | medium | low), summary (human-readable description of the drift, e.g. "
        "'add_memory() gained a new required parameter `ttl` not documented'), "
        "has_breaking_changes (bool), changed_symbols (list of changed function/class names), "
        "and suggested_actions. "
        "Use finding.id with documint_get_patch and documint_approve_patch."
    ),
)
async def documint_get_findings(project_id: str) -> str:
    """List open documentation drift findings for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/findings")
    return _json(data)


@mcp.tool(
    name="documint_check_drift",
    description=(
        "Trigger a fresh documentation drift scan for a project. Compares current source code AST "
        "signatures (SHA-256 of symbol hashes via tree-sitter) against tracked documentation. "
        "This is an async operation: returns a job object with job_id and status. "
        "The scan typically completes in 5-30 seconds. "
        "After triggering, call documint_get_findings to retrieve the results -- findings are "
        "updated once the scan job completes. "
        "Use this when you want up-to-date drift data after a recent code change."
    ),
)
async def documint_check_drift(project_id: str) -> str:
    """Trigger a fresh documentation drift scan."""
    client = _get_client()
    data = await client.post(f"/projects/{_pid(project_id)}/rescan")
    return _json(data)


@mcp.tool(
    name="documint_get_patch",
    description=(
        "Get (or generate on demand) the AI-drafted documentation patch for a specific drift finding. "
        "If no patch exists yet, triggers the 4-step AI chain: "
        "(1) Haiku structured diff report, (2) stale section detection, "
        "(3) Sonnet surgical patch generation, (4) Haiku verification. "
        "Returns a patch object with: id, preview_markdown (the full updated documentation), "
        "summary, rationale, confidence_score (0.0-1.0), ai_provider, chain_steps_used, "
        "and citations (source files used). "
        "Always read preview_markdown before calling documint_approve_patch so you can "
        "show the user what will be committed."
    ),
)
async def documint_get_patch(project_id: str, finding_id: str) -> str:
    """Get (or generate) the AI-drafted documentation patch for a drift finding."""
    client = _get_client()
    pid = _pid(project_id)
    fid = urllib.parse.quote(finding_id, safe="")
    data = await client.get(f"/projects/{pid}/findings/{fid}/patch")
    return _json(data)


@mcp.tool(
    name="documint_approve_patch",
    description=(
        "Approve an AI-drafted patch and open a GitHub pull request with the documentation fix. "
        "The PR is created on the project's connected GitHub repository targeting the default branch. "
        "Returns a pull_request object with: id, branch_name, title, url (GitHub PR URL), and state. "
        "IMPORTANT: Always call documint_get_patch first and present preview_markdown to the user "
        "for review before calling this tool. Approval is irreversible -- it creates a real PR. "
        "Requires the project to have a connected GitHub installation."
    ),
)
async def documint_approve_patch(project_id: str, finding_id: str) -> str:
    """Approve an AI-drafted patch and open a GitHub PR."""
    client = _get_client()
    pid = _pid(project_id)
    fid = urllib.parse.quote(finding_id, safe="")
    data = await client.post(f"/projects/{pid}/findings/{fid}/approve")
    return _json(data)


@mcp.tool(
    name="documint_get_mint",
    description=(
        "Get the .mint file (machine-readable documentation) for a specific artifact. "
        "The .mint format is a structured JSON representation optimised for LLM consumption: "
        "it includes symbol inventory (all documented functions/classes with their signatures), "
        "section graph, cross-references, and verification metadata. "
        "Use this when you need to understand what an artifact currently documents "
        "without reading raw markdown. "
        "artifact_key comes from documint_list_artifacts."
    ),
)
async def documint_get_mint(project_id: str, artifact_key: str) -> str:
    """Get the .mint file for a specific artifact."""
    client = _get_client()
    pid = _pid(project_id)
    akey = urllib.parse.quote(artifact_key, safe="")
    data = await client.get(f"/projects/{pid}/artifacts/{akey}/mint")
    return _json(data)


@mcp.tool(
    name="documint_get_claude_md",
    description=(
        "Get the CLAUDE.md context file for a project. "
        "CLAUDE.md is a curated system-prompt insert that helps Claude-family LLMs understand "
        "the project's conventions, key modules, and coding patterns. "
        "Returns an object with a 'content' field containing the markdown text. "
        "Recommended: load this at the start of any session working on this project's codebase."
    ),
)
async def documint_get_claude_md(project_id: str) -> str:
    """Get the CLAUDE.md context file for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/claude-md")
    return _json(data)


@mcp.tool(
    name="documint_get_agents_md",
    description=(
        "Get the AGENTS.md guide for a project. "
        "AGENTS.md describes the AI agent roles, tool permissions, escalation rules, "
        "and task boundaries for this project's multi-agent setup. "
        "Returns an object with a 'content' field containing the markdown text. "
        "Load this when orchestrating sub-agents or deciding which agent should handle a task."
    ),
)
async def documint_get_agents_md(project_id: str) -> str:
    """Get the AGENTS.md guide for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/agents-md")
    return _json(data)


@mcp.tool(
    name="documint_get_llms_txt",
    description=(
        "Get the llms.txt index file for a project (per the llmstxt.org specification). "
        "llms.txt is a plain-text index of all project documentation with short summaries "
        "and URLs, optimised for LLM context windows. Use it to discover what documentation "
        "exists and decide which pages to fetch for a user's question. "
        "Returns an object with a 'content' field containing the plain text."
    ),
)
async def documint_get_llms_txt(project_id: str) -> str:
    """Get the llms.txt index file for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/llms-txt")
    return _json(data)


@mcp.tool(
    name="documint_get_symbol_diff",
    description=(
        "Get a detailed symbol-level diff for a specific drift finding. "
        "Shows exactly what changed in the source code signatures vs. what the documentation says, "
        "including: symbol_name, change_type (ADDED | REMOVED | PARAM_ADDED | PARAM_REMOVED | "
        "RETURN_CHANGED | SIGNATURE_CHANGED), severity (BREAKING | ADDITIVE | COSMETIC), "
        "and before/after signature strings. "
        "Use this before generating or reviewing a patch to understand the exact technical delta. "
        "More precise than the finding summary alone."
    ),
)
async def documint_get_symbol_diff(project_id: str, finding_id: str) -> str:
    """Get a symbol-level diff for a drift finding."""
    client = _get_client()
    pid = _pid(project_id)
    fid = urllib.parse.quote(finding_id, safe="")
    data = await client.get(f"/projects/{pid}/findings/{fid}/symbol-diff")
    return _json(data)


@mcp.tool(
    name="documint_status",
    description=(
        "Get a health summary for a project. "
        "Returns: drift_status (clean | drifted | unknown), open_findings_count (int), "
        "last_scan_at (ISO timestamp of most recent drift scan), "
        "onboarding_status (connected | pending | error), "
        "and a short human-readable health_message. "
        "Use this at the start of a session to decide whether to run documint_check_drift "
        "or go straight to documint_get_findings."
    ),
)
async def documint_status(project_id: str) -> str:
    """Get a health summary for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/status")
    return _json(data)


@mcp.tool(
    name="documint_watch_artifact",
    description=(
        "Returns the current drift status, last symbol hash, and staleness age for an artifact. "
        "Use this to check if documentation is stale before proposing changes. "
        "Returns: {artifact_id, verification_status, last_symbol_hash, stale_age_hours, "
        "findings_count, last_checked}"
    ),
)
async def documint_watch_artifact(project_id: str, artifact_id: str) -> str:
    """Get drift status for a specific artifact."""
    client = _get_client()
    pid = _pid(project_id)
    aid = urllib.parse.quote(artifact_id, safe="")
    trace = await client.get(f"/projects/{pid}/artifacts/{aid}/trace")
    result = {
        "artifact_id": trace.get("id") if isinstance(trace, dict) else artifact_id,
        "verification_status": trace.get("verification_status") if isinstance(trace, dict) else None,
        "latest_source_ref": (
            trace.get("latest_source_revision", {}).get("ref")
            if isinstance(trace, dict) and trace.get("latest_source_revision")
            else None
        ),
        "latest_doc_ref": (
            trace.get("latest_doc_revision", {}).get("ref")
            if isinstance(trace, dict) and trace.get("latest_doc_revision")
            else None
        ),
        "is_stale": (
            trace.get("verification_status") == "stale"
            if isinstance(trace, dict)
            else None
        ),
        "doc_paths": trace.get("doc_paths") if isinstance(trace, dict) else None,
        "source_paths": trace.get("source_paths") if isinstance(trace, dict) else None,
    }
    return _json(result)


@mcp.tool(
    name="documint_get_coverage",
    description=(
        "Returns documentation coverage report for a project -- what percentage of symbols "
        "are documented per artifact. "
        "Returns: {project_id, artifacts: [{artifact_id, coverage_pct, documented, total}], "
        "overall_pct}"
    ),
)
async def documint_get_coverage(project_id: str) -> str:
    """Get documentation coverage report for a project."""
    client = _get_client()
    data = await client.get(f"/projects/{_pid(project_id)}/coverage")
    return _json(data)


# ---- Resources (4 URI schemes -- dynamic per-project) ------------------------
#
# The FastMCP @resource() decorator uses URI *templates* with {param} syntax.
# These are registered as MCP ResourceTemplates and resolved on read.


@mcp.resource(
    "claude-md://{project_id}",
    name="CLAUDE.md",
    description="CLAUDE.md context file for a project (curated system-prompt insert for Claude-family LLMs).",
    mime_type="text/markdown",
)
async def read_claude_md(project_id: str) -> str:
    """Read the CLAUDE.md resource for a project."""
    client = _get_client()
    pid = _pid(project_id)
    data = await client.get(f"/projects/{pid}/claude-md")
    return data.get("content", _json(data)) if isinstance(data, dict) else _json(data)


@mcp.resource(
    "agents-md://{project_id}",
    name="AGENTS.md",
    description="AGENTS.md guide describing AI agent roles, permissions, and task boundaries.",
    mime_type="text/markdown",
)
async def read_agents_md(project_id: str) -> str:
    """Read the AGENTS.md resource for a project."""
    client = _get_client()
    pid = _pid(project_id)
    data = await client.get(f"/projects/{pid}/agents-md")
    return data.get("content", _json(data)) if isinstance(data, dict) else _json(data)


@mcp.resource(
    "llms-txt://{project_id}",
    name="llms.txt",
    description="llms.txt index of all project documentation with summaries and URLs (llmstxt.org spec).",
    mime_type="text/plain",
)
async def read_llms_txt(project_id: str) -> str:
    """Read the llms.txt resource for a project."""
    client = _get_client()
    pid = _pid(project_id)
    data = await client.get(f"/projects/{pid}/llms-txt")
    return data.get("content", _json(data)) if isinstance(data, dict) else _json(data)


@mcp.resource(
    "mint-binary://{project_id}/{artifact_id}",
    name=".mint binary",
    description="Binary .mint artifact file for a project (base64-encoded).",
    mime_type="application/octet-stream",
)
async def read_mint_binary(project_id: str, artifact_id: str) -> str:  # noqa: ARG001  (project_id required by URI template)
    """Read a local .mint binary file for an artifact."""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", artifact_id):
        return _json({"error": "Invalid artifact_id: must contain only alphanumeric characters, hyphens, and underscores."})
    docs_root = os.environ.get("DOCUMINT_DOCS_ROOT", ".")
    expected_parent = (Path(docs_root) / ".documint").resolve()
    mint_path = Path(docs_root) / ".documint" / f"{artifact_id}.mint"
    if not mint_path.resolve().is_relative_to(expected_parent):
        return _json({"error": "Invalid artifact path: path traversal detected."})
    if mint_path.exists():
        raw = mint_path.read_bytes()
        return _json({
            "artifact_id": artifact_id,
            "encoding": "base64",
            "data": base64.b64encode(raw).decode(),
        })
    return _json({"error": "No .mint file found. Run 'documint publish' first."})


# ---- Prompt (documint workflow guide) ----------------------------------------


@mcp.prompt(
    name="documint_workflow",
    title="Documint Drift-Fix Workflow",
    description="Step-by-step guide for using Documint to find and fix documentation drift.",
)
def documint_workflow(project_id: str = "") -> str:
    """Return a workflow prompt for fixing documentation drift."""
    pid_hint = f" (project: {project_id})" if project_id else ""
    return (
        f"Follow this workflow to fix documentation drift{pid_hint}:\n\n"
        "1. Call `documint_list_projects` to discover available projects and their IDs.\n"
        "2. Call `documint_status` with the project_id to check whether the project has drift.\n"
        "3. If drift_status is 'unknown' or stale, call `documint_check_drift` to trigger a fresh scan.\n"
        "4. Call `documint_get_findings` to list all open drift findings.\n"
        "5. For each finding, call `documint_get_symbol_diff` to understand what changed.\n"
        "6. Call `documint_get_patch` to get (or generate) the AI-drafted fix.\n"
        "7. Review the patch's `preview_markdown` with the user.\n"
        "8. If approved, call `documint_approve_patch` to open a GitHub PR.\n\n"
        "Tips:\n"
        "- Use `documint_get_claude_md` at session start for project context.\n"
        "- Use `documint_get_coverage` to understand documentation completeness.\n"
        "- Use `documint_watch_artifact` to check staleness of specific artifacts.\n"
    )


# ---- ASGI mounting helper for FastAPI integration ----------------------------


def mount_on_fastapi(app: Any, path: str = "/mcp-sse") -> None:
    """Mount the Documint MCP server as SSE on an existing FastAPI/Starlette app.

    Usage in server.py:
        from documint_mcp.mcp_server import mount_on_fastapi
        app = create_app()
        mount_on_fastapi(app, "/mcp-sse")

    Clients connect via:
        SSE endpoint:     GET  {path}/sse
        Message endpoint: POST {path}/messages/
    """
    sse_starlette = mcp.sse_app()
    app.mount(path, sse_starlette)


def get_streamable_http_app() -> Any:
    """Return a Starlette ASGI app for streamable-http transport.

    Usage:
        from documint_mcp.mcp_server import get_streamable_http_app
        app.mount("/mcp", get_streamable_http_app())
    """
    return mcp.streamable_http_app()


# ---- Entry point -------------------------------------------------------------


def main() -> None:
    """CLI entry point for the Documint MCP server.

    Supports transport selection via --transport flag or DOCUMINT_MCP_TRANSPORT env var.
    """
    parser = argparse.ArgumentParser(
        prog="documint-mcp",
        description="Documint MCP server for AI coding agents",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default=os.environ.get("DOCUMINT_MCP_TRANSPORT", "stdio"),
        help="Transport protocol (default: stdio, or set DOCUMINT_MCP_TRANSPORT env var)",
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("DOCUMINT_MCP_HOST", "127.0.0.1"),
        help="Host to bind for SSE/HTTP transport (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("DOCUMINT_MCP_PORT", "8100")),
        help="Port for SSE/HTTP transport (default: 8100)",
    )
    args = parser.parse_args()

    # Configure FastMCP settings for network transports
    if args.transport in ("sse", "streamable-http"):
        mcp.settings.host = args.host
        mcp.settings.port = args.port

    _logger.info(
        "Starting Documint MCP server (transport=%s, host=%s, port=%d)",
        args.transport,
        args.host,
        args.port,
    )

    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
