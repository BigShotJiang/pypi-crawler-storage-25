"""
Symbol extraction for semantic drift detection.

Extracts exported/public symbols from source files using language-specific parsers:
- Python: stdlib ast module (more reliable than tree-sitter for Python)
- TypeScript/JavaScript: tree-sitter-typescript
- Rust: tree-sitter-rust
- Go: tree-sitter-go
- Fallback: line-based heuristic regex for unsupported languages

Only exports/public symbols are extracted (not internal/private) because docs only
describe the public surface area. Private symbol changes should NOT trigger drift.
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass(frozen=True)
class SymbolEntry:
    """A single exported/public symbol extracted from source code."""

    name: str
    kind: str  # "fn", "class", "struct", "enum", "type", "const", "interface", "trait"
    params: list[str] = field(default_factory=list)
    return_type: str | None = None
    line: int = 0
    exported: bool = True

    def to_lsif_compact(self) -> dict[str, Any]:
        """LSIF-compact JSON representation with short keys for dense packing."""
        d: dict[str, Any] = {"n": self.name, "k": self.kind, "e": self.exported, "l": self.line}
        if self.params:
            d["p"] = self.params
        if self.return_type:
            d["r"] = self.return_type
        return d

    def signature(self) -> str:
        """Normalized string signature used for hashing. Order-stable."""
        params_str = ",".join(sorted(self.params))
        return f"{self.kind}:{self.name}({params_str})->{self.return_type or 'void'}"


class PythonExtractor:
    """Extract exported symbols from Python source using stdlib ast."""

    def extract(self, source: str) -> list[SymbolEntry]:
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return []

        symbols = []
        for node in ast.iter_child_nodes(tree):
            # Module-level functions
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if not node.name.startswith("_"):
                    symbols.append(self._from_funcdef(node))
            # Module-level classes
            elif isinstance(node, ast.ClassDef):
                if not node.name.startswith("_"):
                    symbols.append(self._from_classdef(node))
            # Type aliases: MyType = ... at module level (Python 3.12+: type MyType = ...)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and not target.id.startswith("_"):
                        if target.id[0].isupper():  # convention: uppercase = exported type alias
                            symbols.append(SymbolEntry(name=target.id, kind="type", line=node.lineno))

        return symbols

    def _from_funcdef(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> SymbolEntry:
        params = []
        for arg in node.args.args:
            if arg.arg in ("self", "cls"):
                continue
            if arg.annotation:
                try:
                    params.append(f"{arg.arg}:{ast.unparse(arg.annotation)}")
                except Exception:
                    params.append(arg.arg)
            else:
                params.append(arg.arg)

        return_type = None
        if node.returns:
            try:
                return_type = ast.unparse(node.returns)
            except Exception:
                return_type = "Any"

        return SymbolEntry(
            name=node.name,
            kind="fn",
            params=params,
            return_type=return_type,
            line=node.lineno,
        )

    def _from_classdef(self, node: ast.ClassDef) -> SymbolEntry:
        # Collect public methods
        methods = []
        for item in ast.iter_child_nodes(node):
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if not item.name.startswith("_") or item.name in ("__init__", "__call__"):
                    methods.append(item.name)

        return SymbolEntry(
            name=node.name,
            kind="class",
            params=methods,  # methods list stored in params for class entries
            line=node.lineno,
        )


class TreeSitterExtractor:
    """Base class for tree-sitter based extractors."""

    def _try_import_tree_sitter(self, language_name: str) -> Any | None:
        try:
            import tree_sitter  # noqa: F401

            return True
        except ImportError:
            logger.debug("tree_sitter_not_available", language=language_name)
            return None


class TypeScriptExtractor(TreeSitterExtractor):
    """Extract exported symbols from TypeScript/JavaScript using tree-sitter or regex fallback."""

    # Regex fallback patterns for when tree-sitter is not available
    _EXPORT_FUNC = re.compile(
        r"export\s+(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)\s*(?::\s*([^{;]+))?",
        re.MULTILINE,
    )
    _EXPORT_CLASS = re.compile(r"export\s+(?:abstract\s+)?class\s+(\w+)", re.MULTILINE)
    _EXPORT_INTERFACE = re.compile(r"export\s+interface\s+(\w+)", re.MULTILINE)
    _EXPORT_TYPE = re.compile(r"export\s+type\s+(\w+)", re.MULTILINE)
    _EXPORT_CONST_FN = re.compile(
        r"export\s+const\s+(\w+)\s*=\s*(?:async\s+)?\(([^)]*)\)\s*(?::\s*([^=>{]+))?=>",
        re.MULTILINE,
    )

    def extract(self, source: str) -> list[SymbolEntry]:
        symbols: list[SymbolEntry] = []

        for m in self._EXPORT_FUNC.finditer(source):
            name, raw_params, ret = m.group(1), m.group(2), m.group(3)
            params = [p.strip() for p in raw_params.split(",") if p.strip()]
            symbols.append(
                SymbolEntry(
                    name=name,
                    kind="fn",
                    params=params,
                    return_type=ret.strip() if ret else None,
                    line=source[: m.start()].count("\n") + 1,
                )
            )

        for m in self._EXPORT_CLASS.finditer(source):
            symbols.append(
                SymbolEntry(name=m.group(1), kind="class", line=source[: m.start()].count("\n") + 1)
            )

        for m in self._EXPORT_INTERFACE.finditer(source):
            symbols.append(
                SymbolEntry(
                    name=m.group(1), kind="interface", line=source[: m.start()].count("\n") + 1
                )
            )

        for m in self._EXPORT_TYPE.finditer(source):
            symbols.append(
                SymbolEntry(name=m.group(1), kind="type", line=source[: m.start()].count("\n") + 1)
            )

        for m in self._EXPORT_CONST_FN.finditer(source):
            name, raw_params, ret = m.group(1), m.group(2), m.group(3)
            params = [p.strip() for p in raw_params.split(",") if p.strip()]
            symbols.append(
                SymbolEntry(
                    name=name,
                    kind="fn",
                    params=params,
                    return_type=ret.strip() if ret else None,
                    line=source[: m.start()].count("\n") + 1,
                )
            )

        return symbols


class RustExtractor(TreeSitterExtractor):
    """Extract pub symbols from Rust source using regex fallback."""

    _PUB_FN = re.compile(
        r"^\s*pub(?:\s+(?:async|unsafe|extern[^f]*))?\s+fn\s+(\w+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)\s*(?:->\s*([^{;]+))?",
        re.MULTILINE,
    )
    _PUB_STRUCT = re.compile(r"^\s*pub\s+struct\s+(\w+)", re.MULTILINE)
    _PUB_ENUM = re.compile(r"^\s*pub\s+enum\s+(\w+)", re.MULTILINE)
    _PUB_TRAIT = re.compile(r"^\s*pub\s+trait\s+(\w+)", re.MULTILINE)
    _PUB_TYPE = re.compile(r"^\s*pub\s+type\s+(\w+)", re.MULTILINE)
    _PUB_CONST = re.compile(r"^\s*pub\s+const\s+(\w+)", re.MULTILINE)

    def extract(self, source: str) -> list[SymbolEntry]:
        symbols: list[SymbolEntry] = []

        for m in self._PUB_FN.finditer(source):
            name, raw_params, ret = m.group(1), m.group(2), m.group(3)
            params = [
                p.strip()
                for p in raw_params.split(",")
                if p.strip() and p.strip() != "&self" and p.strip() != "&mut self"
            ]
            symbols.append(
                SymbolEntry(
                    name=name,
                    kind="fn",
                    params=params[:8],  # cap at 8 params for hash stability
                    return_type=ret.strip() if ret else None,
                    line=source[: m.start()].count("\n") + 1,
                )
            )

        for pattern, kind in [
            (self._PUB_STRUCT, "struct"),
            (self._PUB_ENUM, "enum"),
            (self._PUB_TRAIT, "trait"),
            (self._PUB_TYPE, "type"),
            (self._PUB_CONST, "const"),
        ]:
            for m in pattern.finditer(source):
                symbols.append(
                    SymbolEntry(name=m.group(1), kind=kind, line=source[: m.start()].count("\n") + 1)
                )

        return symbols


class GoExtractor(TreeSitterExtractor):
    """Extract exported symbols from Go source (exported = capitalized name)."""

    _FUNC = re.compile(
        r"^func\s+(?:\([^)]+\)\s+)?([A-Z]\w*)\s*\(([^)]*)\)\s*(?:\(([^)]*)\)|(\w[\w*\[\]]+))?",
        re.MULTILINE,
    )
    _TYPE = re.compile(r"^type\s+([A-Z]\w*)\s+(?:struct|interface|\w)", re.MULTILINE)
    _CONST = re.compile(r"^\s+([A-Z]\w*)\s*(?:=|\w)", re.MULTILINE)  # exported const in const block

    def extract(self, source: str) -> list[SymbolEntry]:
        symbols: list[SymbolEntry] = []

        for m in self._FUNC.finditer(source):
            name = m.group(1)
            raw_params = m.group(2) or ""
            ret = m.group(3) or m.group(4)
            params = [p.strip() for p in raw_params.split(",") if p.strip()]
            symbols.append(
                SymbolEntry(
                    name=name,
                    kind="fn",
                    params=params,
                    return_type=ret.strip() if ret else None,
                    line=source[: m.start()].count("\n") + 1,
                )
            )

        for m in self._TYPE.finditer(source):
            symbols.append(
                SymbolEntry(name=m.group(1), kind="struct", line=source[: m.start()].count("\n") + 1)
            )

        return symbols


class HeuristicExtractor:
    """Fallback extractor for unsupported languages using line-based heuristics."""

    _DEF_PATTERNS = [
        re.compile(
            r"^(?:public\s+)?(?:static\s+)?(?:\w+\s+)?(\w+)\s*\([^)]*\)", re.MULTILINE
        ),  # generic method
        re.compile(r"^def\s+([a-z]\w*)\s*\(", re.MULTILINE),  # Ruby/Python style
        re.compile(r"^(?:export\s+)?(?:function|class|interface)\s+(\w+)", re.MULTILINE),
    ]

    def extract(self, source: str) -> list[SymbolEntry]:
        seen: set[str] = set()
        symbols: list[SymbolEntry] = []
        for pattern in self._DEF_PATTERNS:
            for m in pattern.finditer(source):
                name = m.group(1)
                if name not in seen and not name.startswith("_"):
                    seen.add(name)
                    symbols.append(
                        SymbolEntry(name=name, kind="fn", line=source[: m.start()].count("\n") + 1)
                    )
        return symbols


def _detect_language(path: str) -> str:
    ext = Path(path).suffix.lower()
    return {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".js": "javascript",
        ".jsx": "javascript",
        ".rs": "rust",
        ".go": "go",
    }.get(ext, "unknown")


def _try_tree_sitter(source: str, lang: str) -> list[SymbolEntry] | None:
    """
    Attempt tree-sitter extraction for *lang*.

    Returns a list of SymbolEntry on success, or None if tree-sitter is
    unavailable or the language grammar is missing (so the caller should
    fall back to regex).
    """
    try:
        from .tree_sitter_extractor import extract_symbols_ts, is_language_supported
    except ImportError:
        return None

    if not is_language_supported(lang):
        return None

    raw = extract_symbols_ts(source, lang)
    if not raw:
        return None

    entries: list[SymbolEntry] = []
    for sym in raw:
        entries.append(
            SymbolEntry(
                name=sym.get("n", ""),
                kind=sym.get("k", "fn"),
                params=sym.get("p", []),
                return_type=sym.get("r"),
                line=sym.get("l", 0),
                exported=sym.get("e", True),
            )
        )
    return entries


def extract_symbols(source: str, path: str = "", language: str = "") -> list[SymbolEntry]:
    """
    Extract exported/public symbols from source code.

    Extraction priority per language:
      - Python: ast module (stdlib) first, tree-sitter second
      - TypeScript/JavaScript: tree-sitter first, regex fallback
      - Rust: tree-sitter first, regex fallback
      - Go: tree-sitter first, regex fallback
      - Other: heuristic regex

    Args:
        source: Source code content
        path: File path (used to detect language if not specified)
        language: Override language detection

    Returns:
        List of SymbolEntry objects, deduplicated by name
    """
    lang = language or _detect_language(path)

    symbols: list[SymbolEntry] | None = None

    if lang == "python":
        # Python: prefer stdlib ast (more reliable for Python specifically),
        # fall back to tree-sitter if ast fails.
        try:
            symbols = PythonExtractor().extract(source)
        except Exception:
            symbols = None
        if not symbols:
            symbols = _try_tree_sitter(source, lang)
    elif lang in ("typescript", "javascript"):
        # TypeScript/JS: tree-sitter first, regex fallback
        symbols = _try_tree_sitter(source, lang)
        if symbols is None:
            try:
                symbols = TypeScriptExtractor().extract(source)
            except Exception as exc:
                logger.warning("symbol_extraction_failed", path=path, language=lang, error=str(exc))
                symbols = []
    elif lang == "rust":
        symbols = _try_tree_sitter(source, lang)
        if symbols is None:
            try:
                symbols = RustExtractor().extract(source)
            except Exception as exc:
                logger.warning("symbol_extraction_failed", path=path, language=lang, error=str(exc))
                symbols = []
    elif lang == "go":
        symbols = _try_tree_sitter(source, lang)
        if symbols is None:
            try:
                symbols = GoExtractor().extract(source)
            except Exception as exc:
                logger.warning("symbol_extraction_failed", path=path, language=lang, error=str(exc))
                symbols = []
    else:
        try:
            symbols = HeuristicExtractor().extract(source)
        except Exception as exc:
            logger.warning("symbol_extraction_failed", path=path, language=lang, error=str(exc))
            symbols = []

    if symbols is None:
        symbols = []

    # Deduplicate by name (keep first occurrence — usually the declaration)
    seen: set[str] = set()
    unique = []
    for s in symbols:
        if s.name not in seen:
            seen.add(s.name)
            unique.append(s)

    return unique


def extract_symbols_from_files(file_contents: dict[str, str]) -> list[SymbolEntry]:
    """Extract symbols from multiple files, merging results."""
    all_symbols: list[SymbolEntry] = []
    seen: set[str] = set()

    for path, content in file_contents.items():
        for sym in extract_symbols(content, path=path):
            if sym.name not in seen:
                seen.add(sym.name)
                all_symbols.append(sym)

    return all_symbols
