"""
Intelligence layer data classes for .mint v2.

HISTORY  — every commit, classified and optionally enriched
FIXED    — bug patterns derived from fix: commits; agents must never repeat these
DECISIONS — architectural choices derived from feat: commits
STATE    — logical project areas + their completion status
SESSIONS — agent session memory (written by agents during work, not bootstrap)
RULES    — patterns inferred from FIXED; get richer with enrichment

All entries support needs_enrichment=True to mark them for the background
Claude enrichment pass (intelligence_enricher.py). The bootstrap is immediately
useful without enrichment — enrichment adds WHY depth to the WHAT captured.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

CommitType = Literal["feat", "fix", "chore", "style", "ci", "refactor", "test", "docs"]
DecisionStatus = Literal["active", "superseded", "reconsidered"]
FeatureStatus = Literal["complete", "in_progress", "blocked", "planned"]


@dataclass
class HistoryEntry:
    commit: str           # short 8-char sha
    date: str             # YYYY-MM-DD
    subject: str          # commit subject line
    body: str             # commit body (may be empty)
    files_changed: list[str]
    commit_type: CommitType
    needs_enrichment: bool = True
    why_inferred: str = ""  # filled by enricher

    def to_dict(self) -> dict[str, Any]:
        return {
            "commit": self.commit,
            "date": self.date,
            "subject": self.subject,
            "body": self.body,
            "files_changed": self.files_changed,
            "commit_type": self.commit_type,
            "needs_enrichment": self.needs_enrichment,
            "why_inferred": self.why_inferred,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "HistoryEntry":
        return cls(
            commit=d["commit"],
            date=d["date"],
            subject=d["subject"],
            body=d.get("body", ""),
            files_changed=d.get("files_changed", []),
            commit_type=d.get("commit_type", "chore"),
            needs_enrichment=d.get("needs_enrichment", True),
            why_inferred=d.get("why_inferred", ""),
        )


@dataclass
class FixedEntry:
    id: str               # "FIX-001"
    date: str             # YYYY-MM-DD
    commit: str           # short sha
    bug: str              # what the bug was
    how_fixed: str        # how it was fixed
    pattern: str          # "always/never X" rule
    files_affected: list[str]
    needs_enrichment: bool = True
    never_again: str = ""  # specific prohibition from this fix

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "date": self.date,
            "commit": self.commit,
            "bug": self.bug,
            "how_fixed": self.how_fixed,
            "pattern": self.pattern,
            "files_affected": self.files_affected,
            "needs_enrichment": self.needs_enrichment,
            "never_again": self.never_again,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "FixedEntry":
        return cls(
            id=d["id"],
            date=d["date"],
            commit=d["commit"],
            bug=d.get("bug", ""),
            how_fixed=d.get("how_fixed", ""),
            pattern=d.get("pattern", ""),
            files_affected=d.get("files_affected", []),
            needs_enrichment=d.get("needs_enrichment", True),
            never_again=d.get("never_again", ""),
        )


@dataclass
class DecisionEntry:
    id: str               # "DEC-001"
    date: str             # YYYY-MM-DD
    commit: str           # short sha
    decision: str         # what was decided
    rationale: str        # why
    affects: list[str]    # file paths
    status: DecisionStatus = "active"
    needs_enrichment: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "date": self.date,
            "commit": self.commit,
            "decision": self.decision,
            "rationale": self.rationale,
            "affects": self.affects,
            "status": self.status,
            "needs_enrichment": self.needs_enrichment,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DecisionEntry":
        return cls(
            id=d["id"],
            date=d["date"],
            commit=d["commit"],
            decision=d.get("decision", ""),
            rationale=d.get("rationale", ""),
            affects=d.get("affects", []),
            status=d.get("status", "active"),
            needs_enrichment=d.get("needs_enrichment", True),
        )


@dataclass
class StateFeature:
    name: str             # logical area e.g. "drift-detection"
    status: FeatureStatus
    last_commit: str      # short sha
    last_date: str        # YYYY-MM-DD

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "last_commit": self.last_commit,
            "last_date": self.last_date,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "StateFeature":
        return cls(
            name=d["name"],
            status=d.get("status", "complete"),
            last_commit=d.get("last_commit", ""),
            last_date=d.get("last_date", ""),
        )


@dataclass
class IntelligenceLayer:
    bootstrapped_at: str = ""
    repo_path: str = ""
    total_commits_analyzed: int = 0
    history: list[HistoryEntry] = field(default_factory=list)
    fixed: list[FixedEntry] = field(default_factory=list)
    decisions: list[DecisionEntry] = field(default_factory=list)
    state: list[StateFeature] = field(default_factory=list)
    sessions: list[dict[str, Any]] = field(default_factory=list)
    rules: list[dict[str, Any]] = field(default_factory=list)

    def pending_enrichment_count(self) -> int:
        return (
            sum(1 for e in self.history if e.needs_enrichment)
            + sum(1 for e in self.fixed if e.needs_enrichment)
            + sum(1 for e in self.decisions if e.needs_enrichment)
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "bootstrapped_at": self.bootstrapped_at,
            "repo_path": self.repo_path,
            "total_commits_analyzed": self.total_commits_analyzed,
            "history": [e.to_dict() for e in self.history],
            "fixed": [e.to_dict() for e in self.fixed],
            "decisions": [e.to_dict() for e in self.decisions],
            "state": [e.to_dict() for e in self.state],
            "sessions": self.sessions,
            "rules": self.rules,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "IntelligenceLayer":
        layer = cls(
            bootstrapped_at=d.get("bootstrapped_at", ""),
            repo_path=d.get("repo_path", ""),
            total_commits_analyzed=d.get("total_commits_analyzed", 0),
            sessions=d.get("sessions", []),
            rules=d.get("rules", []),
        )
        layer.history = [HistoryEntry.from_dict(e) for e in d.get("history", [])]
        layer.fixed = [FixedEntry.from_dict(e) for e in d.get("fixed", [])]
        layer.decisions = [DecisionEntry.from_dict(e) for e in d.get("decisions", [])]
        layer.state = [StateFeature.from_dict(e) for e in d.get("state", [])]
        return layer
