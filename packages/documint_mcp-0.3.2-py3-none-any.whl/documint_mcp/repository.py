"""Persistent repository-backed services for Documint V1."""

from __future__ import annotations

import glob
import hashlib
import re
import secrets
import shutil
import subprocess
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast
from uuid import uuid4

import httpx
import structlog
from sqlalchemy import delete, desc, select
from sqlalchemy.orm import Session

logger = structlog.get_logger(__name__)

from .config import settings
from .rag import get_rag
from .db import (
    ActivityEventRecord,
    AgentRunRecord,
    ApiTokenRecord,
    ArtifactDefinitionRecord,
    ArtifactTraceRecord,
    BackgroundJobRecord,
    DocPatchRecord,
    DriftFindingRecord,
    GitHubInstallationRecord,
    GitHubRepositoryRecord,
    GitHubWebhookDeliveryRecord,
    ProjectRecord,
    ProjectSettingsRecord,
    PublishDeploymentRecord,
    PublishedPageRecord,
    PullRequestRecord,
    RepositorySourceRecord,
    SourceSignalRecord,
    UserRecord,
    VerificationRunRecord,
    WorkspaceMemberRecord,
    WorkspaceRecord,
    init_db,
    reset_db,
    session_scope,
)
from .models import (
    ActivityEvent,
    ApiTokenSummary,
    ArtifactTrace,
    ArtifactType,
    AuthenticatedUser,
    CLIExchangeRequest,
    DocPatch,
    DriftFinding,
    DriftJobRequest,
    FindingSeverity,
    GitHubInstallation,
    GitHubRepository,
    JobStatus,
    PatchCitation,
    Project,
    ProjectCreateRequest,
    ProjectSettings,
    ProjectSnapshot,
    PublicDocPage,
    PublishDeployment,
    PublishedPage,
    PullRequestCreateRequest,
    QueuedJob,
    RepositoryRevision,
    RepositorySource,
    RuntimeStatus,
    SourceSignal,
    SourceSignalType,
    TokenCreateRequest,
    User,
    VerificationRun,
    VerificationStatus,
    Workspace,
    WorkspaceCreateRequest,
)
from .models import (
    PullRequestRecord as PullRequestModel,
)

try:
    import yaml  # type: ignore[import-untyped]
except ModuleNotFoundError:  # pragma: no cover - dependency managed at install time.
    yaml = None

from .ai import DraftPatchResult, get_patch_generator
from .agent_files import AgentFileGenerator
from .cascade_detector import find_cascades
from .drift_engine import DriftResult, get_drift_engine
from .symbol_graph import get_symbol_graph
from .mint import MintDocument
from .github import (
    GitHubPullRequestResult,
    create_or_update_pull_request,
)
from .github import (
    list_installation_repositories as fetch_installation_repositories,
)


@dataclass(frozen=True)
class ArtifactSpec:
    artifact_key: str
    slug: str
    title: str
    artifact_type: ArtifactType
    summary: str
    doc_paths: tuple[str, ...]
    source_patterns: tuple[str, ...]


DEFAULT_ARTIFACT_SPECS: tuple[ArtifactSpec, ...] = (
    ArtifactSpec(
        artifact_key="api-reference",
        slug="api-reference",
        title="API Reference",
        artifact_type=ArtifactType.API_REFERENCE,
        summary="HTTP endpoints, project snapshot objects, and repo-backed control plane contracts.",
        doc_paths=("content/docs/api-reference.md",),
        source_patterns=("src/documint_mcp/**/*.py", "pyproject.toml"),
    ),
    ArtifactSpec(
        artifact_key="sdk-guides",
        slug="sdk-guides",
        title="SDK and Integration Guides",
        artifact_type=ArtifactType.SDK_GUIDES,
        summary="Repo-connected workflows for the web app, CLI, onboarding, and integration entrypoints.",
        doc_paths=("content/docs/sdk-guides.md",),
        source_patterns=("apps/web/**/*", "README.md", "package.json"),
    ),
    ArtifactSpec(
        artifact_key="mcp-reference",
        slug="mcp-reference",
        title="MCP Reference",
        artifact_type=ArtifactType.MCP_REFERENCE,
        summary="HTTP MCP tools for agents that inspect projects, drift, patches, publishes, and activity.",
        doc_paths=("content/docs/mcp-reference.md",),
        source_patterns=("src/documint_mcp/**/*.py", "mcp.json", "README.md"),
    ),
    ArtifactSpec(
        artifact_key="changelog",
        slug="changelog",
        title="Release Changelog",
        artifact_type=ArtifactType.CHANGELOG,
        summary="Current product milestones, releases, and repository-level change tracking.",
        doc_paths=("content/docs/changelog.md",),
        source_patterns=("README.md", "docs/**/*.md", ".github/workflows/*.yml"),
    ),
    ArtifactSpec(
        artifact_key="migration-notes",
        slug="migration-notes",
        title="Migration Notes",
        artifact_type=ArtifactType.MIGRATION_NOTES,
        summary="Notes for the shift from the dogfood stack to the persistent hosted-docs platform.",
        doc_paths=("content/docs/migration-notes.md",),
        source_patterns=(
            "README.md",
            "package.json",
            "pyproject.toml",
            "apps/web/**/*",
        ),
    ),
)

IGNORED_PATH_PARTS = {
    ".git",
    ".next",
    ".pytest_cache",
    "__pycache__",
    "htmlcov",
    "node_modules",
    ".documint",
}
IGNORED_SUFFIXES = {".pyc"}


def _utc_from_timestamp(timestamp: int | float) -> datetime:
    return datetime.fromtimestamp(timestamp, tz=UTC)


def _now() -> datetime:
    return datetime.now(tz=UTC)


def _slugify(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return normalized or f"item-{uuid4().hex[:8]}"


def _revision_to_payload(
    revision: RepositoryRevision | None,
) -> dict[str, object] | None:
    if revision is None:
        return None
    return {
        "ref": revision.ref,
        "touched_at": revision.touched_at.isoformat(),
        "committed": revision.committed,
    }


def _revision_from_payload(
    payload: dict[str, object] | None,
) -> RepositoryRevision | None:
    if not payload:
        return None
    ref = payload.get("ref")
    touched_at = payload.get("touched_at")
    committed = payload.get("committed", True)
    if not isinstance(ref, str) or not isinstance(touched_at, str):
        return None
    return RepositoryRevision(
        ref=ref,
        touched_at=datetime.fromisoformat(touched_at),
        committed=bool(committed),
    )


def _parse_frontmatter(raw: str) -> tuple[dict[str, str], str]:
    if not raw.startswith("---\n"):
        return {}, raw
    end_marker = "\n---\n"
    end_index = raw.find(end_marker, 4)
    if end_index == -1:
        return {}, raw
    header_text = raw[4:end_index]
    body = raw[end_index + len(end_marker) :]
    metadata: dict[str, str] = {}
    for line in header_text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip().strip("\"'")
    return metadata, body.strip()


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


class DocumintService:
    """Persistent service layer backed by SQLAlchemy metadata storage."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root.resolve()
        self._git_executable = shutil.which("git")
        self._head_ref = "HEAD"
        self._head_ref_source = "unknown"
        self._dirty_paths: set[str] = set()
        init_db()
        self._ensure_bootstrap_defaults()

    def _ensure_bootstrap_defaults(self) -> None:
        if settings.auto_bootstrap_defaults:
            self._bootstrap_defaults()

    def me(self, user_id: str | None = None) -> AuthenticatedUser:
        self._ensure_bootstrap_defaults()
        effective_user_id = user_id or settings.default_user_id
        with session_scope() as session:
            user_record = session.get(UserRecord, effective_user_id)
            if user_record is None:
                raise KeyError(f"Unknown user id: {effective_user_id}")
            workspace_records = self._workspace_records_for_user(
                session, effective_user_id
            )
            return AuthenticatedUser(
                user=self._user_model(user_record),
                workspaces=[self._workspace_model(item) for item in workspace_records],
            )

    def bootstrap_self(self) -> ProjectSnapshot:
        self._bootstrap_defaults()
        return self.snapshot(project_id=settings.project_id)

    def list_workspaces(self, user_id: str | None = None) -> list[Workspace]:
        self._ensure_bootstrap_defaults()
        with session_scope() as session:
            records = (
                self._workspace_records_for_user(session, user_id)
                if user_id is not None
                else session.scalars(
                    select(WorkspaceRecord).order_by(WorkspaceRecord.created_at.asc())
                ).all()
            )
            return [self._workspace_model(item) for item in records]

    def create_workspace(
        self, request: WorkspaceCreateRequest, user_id: str | None = None
    ) -> Workspace:
        slug = _slugify(request.slug or request.name)
        owner_id = user_id or settings.default_user_id
        with session_scope() as session:
            workspace = WorkspaceRecord(
                id=f"workspace-{uuid4().hex[:12]}",
                slug=slug,
                name=request.name,
                description=request.description,
            )
            session.add(workspace)
            session.add(
                WorkspaceMemberRecord(
                    id=f"wm-{uuid4().hex[:12]}",
                    workspace_id=workspace.id,
                    user_id=owner_id,
                    role="owner",
                )
            )
            self._record_activity(
                session,
                workspace.id,
                None,
                "workspace.created",
                f"Workspace {workspace.name} created",
                request.description
                or "Workspace added through the Documint operator API.",
                {"slug": workspace.slug},
            )
            session.flush()
            return self._workspace_model(workspace)

    def list_projects(
        self,
        workspace_id: str | None = None,
        user_id: str | None = None,
    ) -> list[Project]:
        self._ensure_bootstrap_defaults()
        self._refresh_repo_state()
        with session_scope() as session:
            statement = select(ProjectRecord).order_by(ProjectRecord.created_at.asc())
            if workspace_id:
                self._require_workspace_access(session, workspace_id, user_id)
                statement = statement.where(ProjectRecord.workspace_id == workspace_id)
            elif user_id is not None:
                allowed_workspace_ids = [
                    item.id
                    for item in self._workspace_records_for_user(session, user_id)
                ]
                statement = statement.where(
                    ProjectRecord.workspace_id.in_(allowed_workspace_ids)
                )
            projects = session.scalars(statement).all()
            return [self._project_model(session, record) for record in projects]

    def create_project(
        self,
        request: ProjectCreateRequest,
        user_id: str | None = None,
    ) -> Project:
        self._refresh_repo_state()
        slug = _slugify(request.slug or request.name)
        with session_scope() as session:
            workspace = session.get(WorkspaceRecord, request.workspace_id)
            if workspace is None:
                raise KeyError(f"Unknown workspace id: {request.workspace_id}")
            self._require_workspace_access(session, workspace.id, user_id)
            if request.installation_id is not None:
                installation = session.get(
                    GitHubInstallationRecord, request.installation_id
                )
                if installation is None:
                    raise KeyError(
                        f"Unknown installation id: {request.installation_id}"
                    )
                if installation.workspace_id != workspace.id:
                    raise PermissionError(
                        "Installation does not belong to the workspace"
                    )
                repo_full_name = f"{request.owner}/{request.repo}".lower()
                cached_repo = session.scalar(
                    select(GitHubRepositoryRecord).where(
                        GitHubRepositoryRecord.github_installation_id
                        == installation.id,
                        GitHubRepositoryRecord.full_name == repo_full_name,
                    )
                )
                if cached_repo is None and settings.job_execution_mode != "inline":
                    raise KeyError(
                        f"Repository {repo_full_name} is not synced for installation {request.installation_id}"
                    )
            project = ProjectRecord(
                id=f"project-{uuid4().hex[:12]}",
                workspace_id=request.workspace_id,
                github_installation_id=request.installation_id,
                name=request.name,
                slug=slug,
                description=request.description,
                public_url=(
                    f"{settings.public_base_url.rstrip('/')}/p/{workspace.slug}/{slug}/docs"
                ),
                dashboard_url=f"{settings.public_base_url.rstrip('/')}/app/projects",
                onboarding_status="connected",
            )
            session.add(project)
            source = RepositorySourceRecord(
                id=f"source-{project.id}",
                project_id=project.id,
                provider="github",
                owner=request.owner,
                repo=request.repo,
                default_branch=request.default_branch,
                local_path=request.local_path or str(self.repo_root),
                current_ref=self._head_ref,
                docs_root=str(settings.docs_content_path.relative_to(self.repo_root)),
                installation_id=request.installation_id,
            )
            session.add(source)
            config = self._load_repo_config()
            session.add(
                ProjectSettingsRecord(
                    id=f"settings-{project.id}",
                    project_id=project.id,
                    docs_root=str(config["docs"]["root"]),
                    config_version=int(config["version"]),
                    config_json=config,
                    ai_policy=dict(config["ai"]),
                    publish_behavior=dict(config["publish"]),
                    pr_behavior=dict(config["pull_requests"]),
                )
            )
            self._upsert_artifact_definitions(session, project.id, config)
            self._record_activity(
                session,
                workspace.id,
                project.id,
                "project.created",
                f"Project {project.name} created",
                f"Connected GitHub repository {request.owner}/{request.repo}.",
                {"slug": slug, "owner": request.owner, "repo": request.repo},
            )
            session.flush()
            return self._project_model(session, project)

    def get_project(
        self, project_id: str, user_id: str | None = None
    ) -> ProjectSnapshot:
        return self.snapshot(project_id=project_id, user_id=user_id)

    def snapshot(
        self,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> ProjectSnapshot:
        self._ensure_bootstrap_defaults()
        self._refresh_repo_state()
        target_project_id = project_id or settings.project_id
        with session_scope() as session:
            project_record = session.get(ProjectRecord, target_project_id)
            if project_record is None:
                raise KeyError(f"Unknown project id: {target_project_id}")
            self._require_project_access(session, target_project_id, user_id)
            workspace_record = session.get(WorkspaceRecord, project_record.workspace_id)
            if workspace_record is None:
                raise KeyError(f"Workspace missing for project {target_project_id}")
            self._sync_project_runtime(session, project_record)
            settings_record = session.get(
                ProjectSettingsRecord, f"settings-{project_record.id}"
            )
            self._ensure_project_artifacts(session, project_record.id, settings_record)
            traces = self._artifact_traces_for_project(session, project_record.id)
            findings = self.list_findings(project_record.id)
            latest_run = self._latest_run(session, project_record.id)
            latest_deployment = self._latest_deployment(session, project_record.id)
            pull_requests = self.list_pull_requests(project_record.id)
            activity = self.list_activity(project_record.id)
            return ProjectSnapshot(
                project=self._project_model(session, project_record),
                workspace=self._workspace_model(workspace_record),
                settings=(
                    self._project_settings_model(settings_record)
                    if settings_record
                    else None
                ),
                runtime=self.runtime_status(),
                artifacts=traces,
                latest_run=latest_run,
                latest_deployment=latest_deployment,
                findings=findings,
                pull_requests=pull_requests,
                activity=activity,
            )

    def list_sources(self, user_id: str | None = None) -> list[RepositorySource]:
        self._ensure_bootstrap_defaults()
        self._refresh_repo_state()
        with session_scope() as session:
            statement = select(RepositorySourceRecord).order_by(
                RepositorySourceRecord.created_at.asc()
            )
            if user_id is not None:
                allowed_project_ids = [
                    item.id
                    for item in session.scalars(
                        select(ProjectRecord).where(
                            ProjectRecord.workspace_id.in_(
                                [
                                    workspace.id
                                    for workspace in self._workspace_records_for_user(
                                        session, user_id
                                    )
                                ]
                            )
                        )
                    ).all()
                ]
                statement = statement.where(
                    RepositorySourceRecord.project_id.in_(allowed_project_ids)
                )
            return [
                self._source_model(record)
                for record in session.scalars(statement).all()
            ]

    def runtime_status(self) -> RuntimeStatus:
        self._refresh_repo_state()
        return RuntimeStatus(
            environment=settings.deployment_environment,
            deployment_provider=settings.deployment_provider,
            job_execution_mode=settings.job_execution_mode,
            api_base_url=settings.api_base_url,
            public_base_url=settings.public_base_url,
            app_base_url=settings.app_base_url,
            repo_root=str(self.repo_root),
            docs_root=str(settings.docs_content_path),
            git_available=self._git_executable is not None,
            git_metadata_available=(self.repo_root / ".git").exists(),
            current_ref=self._head_ref,
            current_ref_source=self._head_ref_source,
            auth_required=bool(
                (settings.auth_token or settings.clerk_jwks_url) and not settings.debug
            ),
            github_app_ready=bool(
                settings.github_app_id
                and settings.github_app_slug
                and settings.github_webhook_secret
            ),
            deploy_branch=settings.deploy_branch,
            database_configured=bool(settings.database_url),
            clerk_configured=bool(settings.clerk_jwks_url and settings.clerk_issuer),
            huggingface_configured=bool(
                settings.hf_api_token
                and settings.hf_primary_model
                and settings.hf_fast_model
            ),
        )

    def run_drift(
        self,
        request: DriftJobRequest,
        user_id: str | None = None,
    ) -> VerificationRun:
        self._ensure_bootstrap_defaults()
        self._refresh_repo_state()
        with session_scope() as session:
            project_record = session.get(ProjectRecord, request.project_id)
            if project_record is None:
                raise KeyError(f"Unknown project id: {request.project_id}")
            self._require_project_access(session, request.project_id, user_id)
            self._sync_project_runtime(session, project_record)
            settings_record = session.get(
                ProjectSettingsRecord, f"settings-{project_record.id}"
            )
            self._ensure_project_artifacts(session, project_record.id, settings_record)
            signal_record = SourceSignalRecord(
                id=f"signal-{uuid4().hex[:12]}",
                project_id=project_record.id,
                signal_type=request.signal_type.value,
                ref=self._head_ref,
                changed_files=(
                    self._worktree_changed_files()
                    if request.changed_files is None
                    else list(request.changed_files)
                ),
            )
            session.add(signal_record)
            session.flush()

            traces = self._artifact_traces_for_project(session, project_record.id)
            all_findings = self._compute_findings(session, project_record.id, traces)
            filtered_findings = self._filter_findings(
                all_findings, signal_record.changed_files
            )
            run_record = VerificationRunRecord(
                id=f"run-{uuid4().hex[:12]}",
                project_id=project_record.id,
                signal_id=signal_record.id,
                status=JobStatus.COMPLETED.value,
                findings_count=len(filtered_findings),
                started_at=_now(),
                completed_at=_now(),
            )
            session.add(run_record)
            session.execute(
                delete(DriftFindingRecord).where(
                    DriftFindingRecord.project_id == project_record.id
                )
            )
            for finding in all_findings:
                session.add(
                    DriftFindingRecord(
                        id=finding.id,
                        project_id=project_record.id,
                        verification_run_id=run_record.id,
                        artifact_key=finding.artifact_id,
                        artifact_type=finding.artifact_type.value,
                        severity=finding.severity.value,
                        summary=finding.summary,
                        rationale=finding.rationale,
                        source_paths=finding.source_paths,
                        doc_paths=finding.doc_paths,
                        suggested_actions=finding.suggested_actions,
                        source_revision=_revision_to_payload(finding.source_revision),
                        doc_revision=_revision_to_payload(finding.doc_revision),
                        status=finding.status,
                        changed_symbols=finding.changed_symbols,
                    )
                )
            self._record_activity(
                session,
                project_record.workspace_id,
                project_record.id,
                "verification.completed",
                f"Drift check completed for {project_record.name}",
                f"{len(all_findings)} open findings, {len(filtered_findings)} returned for this signal scope.",
                {
                    "signal_type": request.signal_type.value,
                    "changed_files": signal_record.changed_files,
                    "findings_count": len(all_findings),
                },
            )
            session.flush()
            return VerificationRun(
                id=run_record.id,
                project_id=project_record.id,
                status=JobStatus(run_record.status),
                signal=SourceSignal(
                    id=signal_record.id,
                    type=SourceSignalType(signal_record.signal_type),
                    ref=signal_record.ref,
                    changed_files=list(signal_record.changed_files),
                    created_at=signal_record.created_at,
                ),
                findings_count=len(filtered_findings),
                findings=filtered_findings,
                started_at=run_record.started_at,
                completed_at=run_record.completed_at,
            )

    def list_findings(
        self, project_id: str, user_id: str | None = None
    ) -> list[DriftFinding]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            findings = session.scalars(
                select(DriftFindingRecord)
                .where(DriftFindingRecord.project_id == project_id)
                .order_by(
                    desc(DriftFindingRecord.created_at),
                    DriftFindingRecord.severity.asc(),
                )
            ).all()
            return [self._finding_model(item) for item in findings]

    def generate_doc_patch(
        self,
        artifact_id: str | None = None,
        finding_id: str | None = None,
        project_id: str | None = None,
        policy: str = "on_demand",
        user_id: str | None = None,
    ) -> DocPatch:
        target_project_id = project_id or settings.project_id
        if finding_id is None and artifact_id is None:
            raise KeyError("Either artifact_id or finding_id is required")

        with session_scope() as session:
            project_record = session.get(ProjectRecord, target_project_id)
            if project_record is None:
                raise KeyError(f"Unknown project id: {target_project_id}")
            self._require_project_access(session, target_project_id, user_id)
            finding = (
                session.get(DriftFindingRecord, finding_id)
                if finding_id is not None
                else None
            )
            effective_artifact_id = artifact_id or (
                finding.artifact_key if finding is not None else None
            )
            if effective_artifact_id is None:
                raise KeyError("Artifact id could not be resolved")
            trace = self.get_artifact_trace(effective_artifact_id, target_project_id)
            current_doc = (
                self._read_doc_path(trace.doc_paths[0]) if trace.doc_paths else ""
            )
            source_content = self._read_source_content(trace.source_paths)
            patch_result = get_patch_generator().draft_patch(
                project=self._project_model(session, project_record),
                trace=trace,
                finding=self._finding_model(finding) if finding is not None else None,
                current_doc=current_doc,
                source_content=source_content,
                project_settings=self._project_settings_model(
                    session.get(ProjectSettingsRecord, f"settings-{project_record.id}")
                ),
                policy=policy,
            )
            patch_record = self._store_patch(
                session,
                project_record.id,
                effective_artifact_id,
                finding.id if finding is not None else None,
                (
                    trace.doc_paths[0]
                    if trace.doc_paths
                    else f"{settings.docs_content_path}/todo.md"
                ),
                patch_result,
            )
            self._record_activity(
                session,
                project_record.workspace_id,
                project_record.id,
                "patch.generated",
                f"Patch draft created for {trace.title}",
                patch_result.summary,
                {
                    "artifact_id": trace.id,
                    "finding_id": finding.id if finding is not None else None,
                    "provider": patch_result.ai_provider,
                    "model": patch_result.model_name,
                },
            )
            return self._patch_model(patch_record)

    def get_patch(
        self, project_id: str, patch_id: str, user_id: str | None = None
    ) -> DocPatch:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            patch = session.get(DocPatchRecord, patch_id)
            if patch is None or patch.project_id != project_id:
                raise KeyError(f"Unknown patch id: {patch_id}")
            return self._patch_model(patch)

    def list_patches(
        self, project_id: str, user_id: str | None = None
    ) -> list[DocPatch]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            patches = session.scalars(
                select(DocPatchRecord)
                .where(DocPatchRecord.project_id == project_id)
                .order_by(desc(DocPatchRecord.created_at))
            ).all()
            return [self._patch_model(item) for item in patches]

    def approve_patch(
        self,
        project_id: str,
        patch_id: str,
        user_id: str | None = None,
    ) -> DocPatch:
        """Mark a patch as approved and store it in RAG for style learning."""
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            patch_record = session.get(DocPatchRecord, patch_id)
            if patch_record is None or patch_record.project_id != project_id:
                raise KeyError(f"Unknown patch id: {patch_id}")
            patch_record.status = "approved"
            session.flush()

            # Store in RAG for few-shot style learning
            rag = get_rag()
            rag.store_approved_patch(
                patch_id=patch_record.id,
                artifact_id=patch_record.artifact_key,
                project_id=project_id,
                section_titles=list(patch_record.proposed_sections),
                patch_content=patch_record.preview_markdown,
            )

            project_record = session.get(ProjectRecord, project_id)
            if project_record is not None:
                self._record_activity(
                    session,
                    project_record.workspace_id,
                    project_id,
                    "patch.approved",
                    f"Patch approved for {patch_record.artifact_key}",
                    patch_record.summary,
                    {"patch_id": patch_id, "artifact_id": patch_record.artifact_key},
                )

            return self._patch_model(patch_record)

    def open_pull_request(
        self,
        project_id: str,
        patch_id: str,
        request: PullRequestCreateRequest | None = None,
        user_id: str | None = None,
    ) -> PullRequestModel:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            patch_record = session.get(DocPatchRecord, patch_id)
            if patch_record is None or patch_record.project_id != project_id:
                raise KeyError(f"Unknown patch id: {patch_id}")
            patch_review_error = self._patch_review_error(patch_record)
            if patch_review_error is not None:
                patch_record.status = "blocked"
                raise ValueError(patch_review_error)
            project_record = session.get(ProjectRecord, project_id)
            if project_record is None:
                raise KeyError(f"Unknown project id: {project_id}")
            source = session.get(RepositorySourceRecord, f"source-{project_id}")
            if source is None:
                raise KeyError(f"Missing source for project: {project_id}")
            branch_name = f"documint/{project_record.slug}/{patch_record.artifact_key}"
            existing = session.scalar(
                select(PullRequestRecord).where(
                    PullRequestRecord.project_id == project_id,
                    PullRequestRecord.branch_name == branch_name,
                    PullRequestRecord.state == "open",
                )
            )
            pr_title = (
                request.title if request and request.title else patch_record.summary
            )
            pr_result = self._open_pull_request_on_github(
                session=session,
                project=project_record,
                source=source,
                patch=patch_record,
                branch_name=branch_name,
                title=pr_title,
            )
            if existing is None:
                pr_record = PullRequestRecord(
                    id=f"pr-{uuid4().hex[:12]}",
                    project_id=project_id,
                    patch_id=patch_id,
                    branch_name=pr_result.branch_name,
                    title=pr_result.title,
                    url=pr_result.url,
                    state=pr_result.state,
                )
                session.add(pr_record)
            else:
                existing.patch_id = patch_id
                existing.branch_name = pr_result.branch_name
                existing.title = pr_result.title
                existing.url = pr_result.url
                existing.state = pr_result.state
                pr_record = existing
            patch_record.status = "pr_opened"
            # Store approved patch for RAG style learning (graceful — never blocks)
            try:
                rag = get_rag()
                if rag.available:
                    rag.store_approved_patch(
                        patch_id=patch_id,
                        artifact_id=patch_record.artifact_key,
                        project_id=project_id,
                        section_titles=patch_record.proposed_sections or [],
                        patch_content=patch_record.preview_markdown or "",
                    )
            except Exception:  # noqa: BLE001
                pass  # RAG storage is optional — never block the PR flow
            self._record_activity(
                session,
                project_record.workspace_id,
                project_record.id,
                "pull_request.opened",
                f"Review PR prepared for {project_record.name}",
                pr_title,
                {
                    "branch_name": pr_result.branch_name,
                    "url": pr_result.url,
                    "patch_id": patch_id,
                    "number": pr_result.number,
                },
            )
            session.flush()
            return self._pull_request_model(pr_record)

    def list_pull_requests(
        self, project_id: str, user_id: str | None = None
    ) -> list[PullRequestModel]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            prs = session.scalars(
                select(PullRequestRecord)
                .where(PullRequestRecord.project_id == project_id)
                .order_by(desc(PullRequestRecord.created_at))
            ).all()
            return [self._pull_request_model(item) for item in prs]

    def publish_preview(
        self, project_id: str, user_id: str | None = None
    ) -> PublishDeployment:
        self._refresh_repo_state()
        with session_scope() as session:
            project_record = session.get(ProjectRecord, project_id)
            if project_record is None:
                raise KeyError(f"Unknown project id: {project_id}")
            self._require_project_access(session, project_id, user_id)
            workspace = session.get(WorkspaceRecord, project_record.workspace_id)
            if workspace is None:
                raise KeyError(f"Workspace missing for project {project_id}")
            deployment_record = PublishDeploymentRecord(
                id=f"preview-{uuid4().hex[:12]}",
                project_id=project_id,
                status=JobStatus.COMPLETED.value,
                commit_ref=self._head_ref,
                site_url=self._public_docs_base_url(
                    workspace.slug, project_record.slug
                ),
                preview_url=(
                    f"{settings.public_base_url.rstrip('/')}/app/projects/"
                    f"{project_record.id}?preview={self._head_ref}"
                ),
                docs_count=0,
                generated_at=_now(),
            )
            session.add(deployment_record)
            session.flush()

            docs_root = self._project_docs_root(session, project_record.id)
            published_pages = self._publish_pages_for_project(
                session,
                workspace.slug,
                project_record.slug,
                project_record.id,
                deployment_record.id,
                docs_root,
            )
            deployment_record.docs_count = len(published_pages)
            self._record_activity(
                session,
                workspace.id,
                project_record.id,
                "publish.completed",
                f"Published {len(published_pages)} pages for {project_record.name}",
                deployment_record.site_url,
                {
                    "deployment_id": deployment_record.id,
                    "site_url": deployment_record.site_url,
                    "commit_ref": deployment_record.commit_ref,
                },
            )
            session.flush()
            publish = self._publish_model(deployment_record)
            # Collect artifact definitions for agent file generation (inside session scope)
            artifact_defs_for_agents = list(
                session.scalars(
                    select(ArtifactDefinitionRecord).where(
                        ArtifactDefinitionRecord.project_id == project_id
                    )
                ).all()
            )
        self.revalidate_project(project_id, publish.id)
        self._run_frontend_revalidation_job(project_id, publish.id)
        # --- Agent file generation (CLAUDE.md, AGENTS.md, llms.txt, llms-full.txt) ---
        # Build lightweight MintDocument stubs from artifact definitions and write agent files.
        # TODO: Phase 2 — open a PR with these files instead of writing them locally.
        try:
            mint_docs: list[MintDocument] = []
            for rec in artifact_defs_for_agents:
                sentinel: dict[str, object] = {
                    "k": "__artifact__",
                    "n": rec.title,
                    "artifact_key": rec.artifact_key,
                    "artifact_type": rec.artifact_type,
                }
                mint_docs.append(
                    MintDocument(
                        source_files=list(rec.source_patterns),
                        symbols=[sentinel],
                        narrative=rec.summary,
                        drift_status="CLEAN",
                    )
                )
            if mint_docs:
                output_dir = self.repo_root / ".mint" / project_record.slug
                AgentFileGenerator().write_to_directory(
                    output_dir=output_dir,
                    project_name=project_record.name,
                    artifacts=mint_docs,
                    project_description=project_record.description or "",
                )
                # Persist generated file content back to the project record
                file_col_map = [
                    ("CLAUDE.md", "claude_md_content"),
                    ("AGENTS.md", "agents_md_content"),
                    ("llms.txt", "llms_txt_content"),
                    ("llms-full.txt", "llms_full_txt_content"),
                ]
                with session_scope() as _save_session:
                    _proj = _save_session.get(ProjectRecord, project_id)
                    if _proj is not None:
                        for filename, col in file_col_map:
                            filepath = output_dir / filename
                            if filepath.exists():
                                setattr(_proj, col, filepath.read_text(encoding="utf-8"))
                        _proj.last_scanned_at = datetime.now(tz=UTC)
        except Exception:
            # Agent file generation is best-effort and must never fail a publish
            pass
        return publish

    def list_publishes(
        self, project_id: str, user_id: str | None = None
    ) -> list[PublishDeployment]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            publishes = session.scalars(
                select(PublishDeploymentRecord)
                .where(PublishDeploymentRecord.project_id == project_id)
                .order_by(desc(PublishDeploymentRecord.generated_at))
            ).all()
            return [self._publish_model(item) for item in publishes]

    def get_publish(
        self,
        project_id: str,
        deployment_id: str,
        user_id: str | None = None,
    ) -> PublishDeployment:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            deployment = session.get(PublishDeploymentRecord, deployment_id)
            if deployment is None or deployment.project_id != project_id:
                raise KeyError(f"Unknown deployment id: {deployment_id}")
            return self._publish_model(deployment)

    def list_activity(
        self, project_id: str, user_id: str | None = None
    ) -> list[ActivityEvent]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            events = session.scalars(
                select(ActivityEventRecord)
                .where(ActivityEventRecord.project_id == project_id)
                .order_by(desc(ActivityEventRecord.created_at))
            ).all()
            return [self._activity_model(item) for item in events]

    def create_job(
        self,
        *,
        job_kind: str,
        project_id: str | None = None,
        workspace_id: str | None = None,
        payload_json: dict[str, object] | None = None,
        user_id: str | None = None,
    ) -> QueuedJob:
        with session_scope() as session:
            resolved_workspace_id = workspace_id
            if project_id is not None:
                project = session.get(ProjectRecord, project_id)
                if project is None:
                    raise KeyError(f"Unknown project id: {project_id}")
                self._require_project_access(session, project_id, user_id)
                resolved_workspace_id = project.workspace_id
            elif workspace_id is not None:
                self._require_workspace_access(session, workspace_id, user_id)

            record = BackgroundJobRecord(
                id=f"job-{uuid4().hex[:12]}",
                workspace_id=resolved_workspace_id,
                project_id=project_id,
                job_kind=job_kind,
                status=JobStatus.PENDING.value,
                payload_json=payload_json or {},
            )
            session.add(record)
            session.flush()
            return self._job_model(record)

    def get_job(self, job_id: str, user_id: str | None = None) -> QueuedJob:
        with session_scope() as session:
            record = session.get(BackgroundJobRecord, job_id)
            if record is None:
                raise KeyError(f"Unknown job id: {job_id}")
            if record.project_id is not None:
                self._require_project_access(session, record.project_id, user_id)
            elif record.workspace_id is not None:
                self._require_workspace_access(session, record.workspace_id, user_id)
            return self._job_model(record)

    def list_jobs(
        self, project_id: str, user_id: str | None = None
    ) -> list[QueuedJob]:
        with session_scope() as session:
            self._require_project_access(session, project_id, user_id)
            records = session.scalars(
                select(BackgroundJobRecord)
                .where(BackgroundJobRecord.project_id == project_id)
                .order_by(desc(BackgroundJobRecord.created_at))
            ).all()
            return [self._job_model(record) for record in records]

    def mark_job_running(self, job_id: str) -> QueuedJob:
        with session_scope() as session:
            record = session.get(BackgroundJobRecord, job_id)
            if record is None:
                raise KeyError(f"Unknown job id: {job_id}")
            record.status = JobStatus.RUNNING.value
            record.attempt_count += 1
            record.started_at = _now()
            session.flush()
            return self._job_model(record)

    def mark_job_completed(
        self,
        job_id: str,
        *,
        resource_type: str | None = None,
        resource_id: str | None = None,
        result_summary: str | None = None,
        result_json: dict[str, object] | None = None,
    ) -> QueuedJob:
        with session_scope() as session:
            record = session.get(BackgroundJobRecord, job_id)
            if record is None:
                raise KeyError(f"Unknown job id: {job_id}")
            record.status = JobStatus.COMPLETED.value
            if record.started_at is None:
                record.started_at = _now()
                record.attempt_count = max(1, record.attempt_count)
            record.completed_at = _now()
            record.error_summary = None
            record.resource_type = resource_type
            record.resource_id = resource_id
            record.result_summary = result_summary
            record.result_json = result_json
            session.flush()
            return self._job_model(record)

    def mark_job_failed(
        self,
        job_id: str,
        *,
        error_summary: str,
        result_json: dict[str, object] | None = None,
    ) -> QueuedJob:
        with session_scope() as session:
            record = session.get(BackgroundJobRecord, job_id)
            if record is None:
                raise KeyError(f"Unknown job id: {job_id}")
            record.status = JobStatus.FAILED.value
            if record.started_at is None:
                record.started_at = _now()
                record.attempt_count = max(1, record.attempt_count)
            record.completed_at = _now()
            record.error_summary = error_summary[:500]
            record.result_json = result_json
            if record.workspace_id is not None:
                self._record_activity(
                    session,
                    record.workspace_id,
                    record.project_id,
                    f"job.{record.job_kind}.failed",
                    f"{record.job_kind.replace('_', ' ').title()} failed",
                    record.error_summary,
                    {"job_id": record.id},
                )
            session.flush()
            return self._job_model(record)

    def create_api_token(
        self,
        request: TokenCreateRequest,
        user_id: str | None = None,
    ) -> ApiTokenSummary:
        effective_user_id = user_id or settings.default_user_id
        raw_token = f"docu_{secrets.token_urlsafe(24)}"
        token_record = ApiTokenRecord(
            id=f"token-{uuid4().hex[:12]}",
            workspace_id=request.workspace_id,
            user_id=effective_user_id,
            label=request.label,
            token_prefix=raw_token[:12],
            token_hash=_token_hash(raw_token),
            scopes=request.scopes,
        )
        with session_scope() as session:
            self._require_workspace_access(session, request.workspace_id, user_id)
            session.add(token_record)
            self._record_activity(
                session,
                request.workspace_id,
                None,
                "token.created",
                f"API token {request.label} created",
                "Scoped API token generated for CLI or MCP access.",
                {"scopes": request.scopes},
            )
            session.flush()
            return self._api_token_model(token_record, raw_token)

    def list_api_tokens(
        self, workspace_id: str, user_id: str | None = None
    ) -> list[ApiTokenSummary]:
        with session_scope() as session:
            self._require_workspace_access(session, workspace_id, user_id)
            tokens = session.scalars(
                select(ApiTokenRecord)
                .where(ApiTokenRecord.workspace_id == workspace_id)
                .order_by(desc(ApiTokenRecord.created_at))
            ).all()
            return [self._api_token_model(item) for item in tokens]

    def exchange_cli_token(
        self, request: CLIExchangeRequest, user_id: str | None = None
    ) -> ApiTokenSummary:
        return self.create_api_token(
            TokenCreateRequest(
                workspace_id=request.workspace_id,
                label=request.label,
                scopes=request.scopes,
            ),
            user_id=user_id,
        )

    def revoke_api_token(
        self, workspace_id: str, token_id: str, user_id: str | None = None
    ) -> ApiTokenSummary:
        with session_scope() as session:
            self._require_workspace_access(session, workspace_id, user_id)
            record = session.scalar(
                select(ApiTokenRecord).where(
                    ApiTokenRecord.id == token_id,
                    ApiTokenRecord.workspace_id == workspace_id,
                )
            )
            if record is None:
                raise ValueError(f"Token {token_id} not found in workspace {workspace_id}")
            record.revoked_at = _now()
            session.flush()
            return self._api_token_model(record)

    def authenticate_api_token(self, raw_token: str) -> ApiTokenSummary | None:
        with session_scope() as session:
            record = session.scalar(
                select(ApiTokenRecord).where(
                    ApiTokenRecord.token_hash == _token_hash(raw_token),
                    ApiTokenRecord.revoked_at.is_(None),
                )
            )
            if record is None:
                return None
            record.last_used_at = _now()
            session.flush()
            return self._api_token_model(record)

    def get_artifact_trace(
        self,
        artifact_id: str,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> ArtifactTrace:
        target_project_id = project_id or settings.project_id
        self._ensure_bootstrap_defaults()
        self._refresh_repo_state()
        with session_scope() as session:
            self._require_project_access(session, target_project_id, user_id)
            settings_record = session.get(
                ProjectSettingsRecord, f"settings-{target_project_id}"
            )
            self._ensure_project_artifacts(session, target_project_id, settings_record)
            trace_record = session.scalar(
                select(ArtifactTraceRecord)
                .join(
                    ArtifactDefinitionRecord,
                    ArtifactTraceRecord.artifact_definition_id
                    == ArtifactDefinitionRecord.id,
                )
                .where(ArtifactTraceRecord.project_id == target_project_id)
                .where(ArtifactDefinitionRecord.artifact_key == artifact_id)
            )
            if trace_record is None:
                raise KeyError(f"Unknown artifact id: {artifact_id}")
            definition = session.get(
                ArtifactDefinitionRecord, trace_record.artifact_definition_id
            )
            if definition is None:
                raise KeyError(f"Artifact definition missing for {artifact_id}")
            return self._trace_model(trace_record, definition)

    def explain_trace(
        self,
        artifact_id: str,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> dict[str, object]:
        artifact = self.get_artifact_trace(
            artifact_id, project_id=project_id, user_id=user_id
        )
        return {
            "artifact": artifact.model_dump(mode="json"),
            "explanation": (
                f"{artifact.title} is driven by {len(artifact.source_paths)} source paths "
                f"and publishes to {', '.join(artifact.doc_paths)}."
            ),
        }

    def list_public_pages(self, project_id: str) -> list[PublishedPage]:
        with session_scope() as session:
            pages = session.scalars(
                select(PublishedPageRecord)
                .where(PublishedPageRecord.project_id == project_id)
                .order_by(PublishedPageRecord.path.asc())
            ).all()
            return [self._published_page_model(item) for item in pages]

    def list_installations(
        self,
        workspace_id: str,
        user_id: str | None = None,
    ) -> list[GitHubInstallation]:
        with session_scope() as session:
            self._require_workspace_access(session, workspace_id, user_id)
            records = session.scalars(
                select(GitHubInstallationRecord)
                .where(GitHubInstallationRecord.workspace_id == workspace_id)
                .order_by(GitHubInstallationRecord.created_at.asc())
            ).all()
            return [self._installation_model(item) for item in records]

    def list_installation_repositories(
        self,
        installation_id: str,
        user_id: str | None = None,
    ) -> list[GitHubRepository]:
        with session_scope() as session:
            installation = session.get(GitHubInstallationRecord, installation_id)
            if installation is None:
                raise KeyError(f"Unknown installation id: {installation_id}")
            self._require_workspace_access(session, installation.workspace_id, user_id)
            records = session.scalars(
                select(GitHubRepositoryRecord)
                .where(GitHubRepositoryRecord.github_installation_id == installation.id)
                .order_by(GitHubRepositoryRecord.full_name.asc())
            ).all()
            return [self._github_repository_model(item) for item in records]

    def get_installation_workspace_id(self, installation_id: str) -> str | None:
        with session_scope() as session:
            installation = session.get(GitHubInstallationRecord, installation_id)
            return installation.workspace_id if installation is not None else None

    def sync_installation(
        self,
        installation_id: str,
        user_id: str | None = None,
    ) -> list[GitHubRepository]:
        with session_scope() as session:
            installation = session.get(GitHubInstallationRecord, installation_id)
            if installation is None:
                raise KeyError(f"Unknown installation id: {installation_id}")
            self._require_workspace_access(session, installation.workspace_id, user_id)
            external_installation_id = installation.installation_id
            if (
                external_installation_id is None
                and installation.id == "github-install-documint"
                and settings.self_bootstrap_installation_id
            ):
                external_installation_id = settings.self_bootstrap_installation_id
            if external_installation_id is None:
                raise KeyError(
                    f"GitHub installation {installation_id} does not have an external installation_id yet"
                )
        repositories = fetch_installation_repositories(external_installation_id)
        with session_scope() as session:
            installation = session.get(GitHubInstallationRecord, installation_id)
            if installation is None:
                raise KeyError(f"Unknown installation id: {installation_id}")
            session.execute(
                delete(GitHubRepositoryRecord).where(
                    GitHubRepositoryRecord.github_installation_id == installation.id
                )
            )
            synced_records: list[GitHubRepositoryRecord] = []
            for repository in repositories:
                full_name = repository.get("full_name")
                owner_payload = repository.get("owner")
                owner_login = (
                    owner_payload.get("login")
                    if isinstance(owner_payload, dict)
                    else None
                )
                name = repository.get("name")
                if not all(
                    isinstance(item, str) and item
                    for item in (full_name, owner_login, name)
                ):
                    continue
                full_name_str = cast(str, full_name)
                owner_login_str = cast(str, owner_login)
                name_str = cast(str, name)
                record = GitHubRepositoryRecord(
                    id=f"ghrepo-{uuid4().hex[:12]}",
                    github_installation_id=installation.id,
                    repository_id=(
                        str(repository.get("id")) if repository.get("id") else None
                    ),
                    full_name=full_name_str.lower(),
                    owner=owner_login_str,
                    name=name_str,
                    default_branch=str(repository.get("default_branch") or "main"),
                    visibility=str(
                        repository.get("visibility")
                        or ("private" if repository.get("private") else "public")
                    ),
                    is_private=bool(repository.get("private")),
                    is_archived=bool(repository.get("archived")),
                    metadata_json={
                        "html_url": repository.get("html_url"),
                        "permissions": repository.get("permissions"),
                    },
                )
                session.add(record)
                synced_records.append(record)
            session.flush()
            synced = [self._github_repository_model(record) for record in synced_records]
            installation.account_login = (
                installation.account_login
                or str(installation.metadata_json.get("account_login") or "")
                or None
            )
            installation.metadata_json = {
                **installation.metadata_json,
                "synced_at": _now().isoformat(),
                "repository_count": len(synced),
            }
            self._record_activity(
                session,
                installation.workspace_id,
                None,
                "github.installation.synced",
                f"Synced installation {installation.id}",
                f"{len(synced)} repositories available for onboarding.",
                {"installation_id": installation.id, "repository_count": len(synced)},
            )
            session.flush()
            return synced

    def upsert_github_installation(
        self,
        *,
        external_installation_id: str,
        account_login: str | None,
        account_type: str | None,
        repository_selection: str,
        repositories: list[dict[str, Any]] | None = None,
        workspace_id: str | None = None,
    ) -> GitHubInstallation:
        target_workspace_id = workspace_id or settings.default_workspace_id
        with session_scope() as session:
            installation = session.scalar(
                select(GitHubInstallationRecord).where(
                    GitHubInstallationRecord.installation_id == external_installation_id
                )
            )
            if installation is None:
                bootstrap_installation = (
                    session.get(GitHubInstallationRecord, "github-install-documint")
                    if target_workspace_id == settings.default_workspace_id
                    else None
                )
                if bootstrap_installation is not None and (
                    bootstrap_installation.installation_id is None
                    or bootstrap_installation.installation_id == external_installation_id
                ):
                    installation = bootstrap_installation
                else:
                    installation = GitHubInstallationRecord(
                        id=f"ghinst-{uuid4().hex[:12]}",
                        workspace_id=target_workspace_id,
                        installation_id=external_installation_id,
                    )
                    session.add(installation)
            elif (
                target_workspace_id == settings.default_workspace_id
                and installation.id != "github-install-documint"
            ):
                bootstrap_installation = session.get(
                    GitHubInstallationRecord, "github-install-documint"
                )
                if bootstrap_installation is not None:
                    installation = self._merge_installation_records(
                        session,
                        target=bootstrap_installation,
                        source=installation,
                    )
            installation.workspace_id = target_workspace_id
            installation.installation_id = external_installation_id
            installation.account_login = account_login
            installation.account_type = account_type
            installation.repository_selection = repository_selection
            installation.metadata_json = {
                **(installation.metadata_json or {}),
                "account_login": account_login,
                "account_type": account_type,
            }
            session.flush()
            if repositories is not None:
                session.execute(
                    delete(GitHubRepositoryRecord).where(
                        GitHubRepositoryRecord.github_installation_id == installation.id
                    )
                )
                for repository in repositories:
                    full_name = repository.get("full_name")
                    owner_payload = repository.get("owner")
                    owner_login = (
                        owner_payload.get("login")
                        if isinstance(owner_payload, dict)
                        else None
                    )
                    name = repository.get("name")
                    if not all(
                        isinstance(item, str) and item
                        for item in (full_name, owner_login, name)
                    ):
                        continue
                    full_name_str = cast(str, full_name)
                    owner_login_str = cast(str, owner_login)
                    name_str = cast(str, name)
                    session.add(
                        GitHubRepositoryRecord(
                            id=f"ghrepo-{uuid4().hex[:12]}",
                            github_installation_id=installation.id,
                            repository_id=(
                                str(repository.get("id"))
                                if repository.get("id")
                                else None
                            ),
                            full_name=full_name_str.lower(),
                            owner=owner_login_str,
                            name=name_str,
                            default_branch=str(
                                repository.get("default_branch") or "main"
                            ),
                            visibility=str(
                                repository.get("visibility")
                                or (
                                    "private" if repository.get("private") else "public"
                                )
                            ),
                            is_private=bool(repository.get("private")),
                            is_archived=bool(repository.get("archived")),
                            metadata_json={"html_url": repository.get("html_url")},
                        )
                    )
            return self._installation_model(installation)

    def ensure_clerk_user(self, claims: dict[str, Any]) -> User:
        external_id = claims.get("sub")
        if not isinstance(external_id, str) or not external_id:
            raise KeyError("Clerk token missing subject")
        email = claims.get("email")
        first_name = claims.get("first_name")
        last_name = claims.get("last_name")
        full_name = claims.get("name")
        resolved_name = (
            full_name
            if isinstance(full_name, str) and full_name.strip()
            else " ".join(
                item.strip()
                for item in (first_name, last_name)
                if isinstance(item, str) and item.strip()
            ).strip()
            or "Documint Operator"
        )
        with session_scope() as session:
            user = session.scalar(
                select(UserRecord).where(UserRecord.external_id == external_id)
            )
            if user is None:
                user = UserRecord(
                    id=f"user-{uuid4().hex[:12]}",
                    external_id=external_id,
                    email=email if isinstance(email, str) else None,
                    name=resolved_name,
                    provider="clerk",
                )
                session.add(user)
                session.flush()
                self._assign_first_operator_workspace(session, user.id)
            else:
                user.email = email if isinstance(email, str) else user.email
                user.name = resolved_name
                user.provider = "clerk"
            session.flush()
            return self._user_model(user)

    def resolve_project_id_for_repository(
        self, repository_full_name: str
    ) -> str | None:
        normalized = repository_full_name.strip().lower()
        if not normalized or "/" not in normalized:
            return None
        owner, repo = normalized.split("/", 1)
        with session_scope() as session:
            source = session.scalar(
                select(RepositorySourceRecord).where(
                    RepositorySourceRecord.owner == owner,
                    RepositorySourceRecord.repo == repo,
                )
            )
            return source.project_id if source is not None else None

    def get_public_doc_page(
        self,
        workspace_slug: str,
        project_slug: str,
        page_path: str,
    ) -> PublicDocPage:
        normalized_path = page_path.strip("/") or "index"
        with session_scope() as session:
            page = session.scalar(
                select(PublishedPageRecord)
                .where(PublishedPageRecord.workspace_slug == workspace_slug)
                .where(PublishedPageRecord.project_slug == project_slug)
                .where(PublishedPageRecord.path == normalized_path)
            )
            if page is None:
                raise KeyError(
                    f"Unknown published page: {workspace_slug}/{project_slug}/{normalized_path}"
                )
            return PublicDocPage(
                workspace_slug=workspace_slug,
                project_slug=project_slug,
                path=page.path,
                title=page.title,
                description=page.description,
                content_markdown=page.content_markdown,
                source_path=page.source_path,
                deployment_id=page.deployment_id,
            )

    def record_webhook_delivery(
        self,
        *,
        delivery_id: str | None,
        event_name: str,
        repository: str | None,
        action: str | None,
        ref: str | None,
        payload: dict[str, object],
        status: str,
    ) -> None:
        with session_scope() as session:
            existing = (
                session.scalar(
                    select(GitHubWebhookDeliveryRecord).where(
                        GitHubWebhookDeliveryRecord.delivery_id == delivery_id
                    )
                )
                if delivery_id
                else None
            )
            if existing is None:
                existing = GitHubWebhookDeliveryRecord(
                    id=f"ghd-{uuid4().hex[:12]}",
                    delivery_id=delivery_id,
                    event_name=event_name,
                    repository=repository,
                    action=action,
                    ref=ref,
                    payload=payload,
                    status=status,
                    processed_at=_now() if status != "received" else None,
                )
                session.add(existing)
            else:
                existing.status = status
                existing.event_name = event_name
                existing.repository = repository
                existing.action = action
                existing.ref = ref
                existing.payload = payload
                existing.processed_at = _now()

    def revalidate_project(
        self, project_id: str, deployment_id: str | None = None
    ) -> dict[str, object]:
        with session_scope() as session:
            project = session.get(ProjectRecord, project_id)
            if project is None:
                raise KeyError(f"Unknown project id: {project_id}")
            payload: dict[str, object] = {
                "project_id": project_id,
                "deployment_id": deployment_id,
                "status": "accepted",
                "revalidated_at": _now().isoformat(),
                "route": f"/p/{self._workspace_slug(session, project.workspace_id)}/{project.slug}/docs",
            }
            self._record_activity(
                session,
                project.workspace_id,
                project_id,
                "publish.revalidated",
                f"Revalidation requested for {project.name}",
                str(payload["route"]),
                payload,
            )
            return payload

    def _bootstrap_defaults(self) -> None:
        self._refresh_repo_state()
        config = self._load_repo_config()
        with session_scope() as session:
            if session.get(UserRecord, settings.default_user_id) is None:
                session.add(
                    UserRecord(
                        id=settings.default_user_id,
                        email=settings.default_user_email,
                        name=settings.default_user_name,
                        provider="internal",
                    )
                )
            workspace = session.get(WorkspaceRecord, settings.default_workspace_id)
            if workspace is None:
                workspace = WorkspaceRecord(
                    id=settings.default_workspace_id,
                    slug=settings.default_workspace_slug,
                    name=settings.default_workspace_name,
                    description="Bootstrap workspace used to dogfood Documint against itself.",
                )
                session.add(workspace)
            membership = session.scalar(
                select(WorkspaceMemberRecord).where(
                    WorkspaceMemberRecord.workspace_id == workspace.id,
                    WorkspaceMemberRecord.user_id == settings.default_user_id,
                )
            )
            if membership is None:
                session.add(
                    WorkspaceMemberRecord(
                        id=f"wm-{uuid4().hex[:12]}",
                        workspace_id=workspace.id,
                        user_id=settings.default_user_id,
                        role="owner",
                    )
                )
            installation = session.get(
                GitHubInstallationRecord, "github-install-documint"
            )
            duplicate_installation = (
                session.scalar(
                    select(GitHubInstallationRecord).where(
                        GitHubInstallationRecord.installation_id
                        == settings.self_bootstrap_installation_id
                    )
                )
                if settings.self_bootstrap_installation_id
                else None
            )
            if installation is None:
                installation = GitHubInstallationRecord(
                    id="github-install-documint",
                    workspace_id=workspace.id,
                    installation_id=settings.self_bootstrap_installation_id,
                    account_login=settings.project_owner,
                    account_type="User",
                    repository_selection="selected",
                    metadata_json={
                        "repository": f"{settings.project_owner}/{settings.project_repo}"
                    },
                )
                session.add(installation)
                session.flush()
            if (
                duplicate_installation is not None
                and duplicate_installation.id != installation.id
            ):
                installation = self._merge_installation_records(
                    session,
                    target=installation,
                    source=duplicate_installation,
                )
            else:
                installation.workspace_id = workspace.id
                installation.account_login = settings.project_owner
                installation.account_type = "User"
                installation.repository_selection = "selected"
                installation.metadata_json = {
                    **(installation.metadata_json or {}),
                    "repository": f"{settings.project_owner}/{settings.project_repo}",
                }
            installation.installation_id = settings.self_bootstrap_installation_id
            installation.workspace_id = workspace.id
            installation.account_login = settings.project_owner
            installation.account_type = "User"
            installation.repository_selection = "selected"
            installation.metadata_json = {
                **(installation.metadata_json or {}),
                "repository": f"{settings.project_owner}/{settings.project_repo}",
            }
            project = session.get(ProjectRecord, settings.project_id)
            if project is None:
                project = ProjectRecord(
                    id=settings.project_id,
                    workspace_id=workspace.id,
                    github_installation_id="github-install-documint",
                    name=config["project"]["name"],
                    slug=config["project"]["slug"],
                    description=config["project"]["description"],
                    public_url=self._public_docs_base_url(
                        workspace.slug, config["project"]["slug"]
                    ),
                    dashboard_url=f"{settings.public_base_url.rstrip('/')}/app/projects/{settings.project_id}",
                    onboarding_status="connected",
                )
                session.add(project)
            source = session.get(
                RepositorySourceRecord, f"source-{settings.project_id}"
            )
            docs_root = str(config["docs"]["root"])
            if source is None:
                session.add(
                    RepositorySourceRecord(
                        id=f"source-{settings.project_id}",
                        project_id=settings.project_id,
                        provider="github",
                        owner=settings.project_owner,
                        repo=settings.project_repo,
                        default_branch=settings.default_branch,
                        local_path=str(self.repo_root),
                        current_ref=self._head_ref,
                        docs_root=docs_root,
                        installation_id="github-install-documint",
                    )
                )
            else:
                source.current_ref = self._head_ref
                source.docs_root = docs_root
                source.local_path = str(self.repo_root)
            repo_cache = session.scalar(
                select(GitHubRepositoryRecord).where(
                    GitHubRepositoryRecord.github_installation_id
                    == "github-install-documint",
                    GitHubRepositoryRecord.full_name
                    == f"{settings.project_owner}/{settings.project_repo}".lower(),
                )
            )
            if repo_cache is None:
                session.add(
                    GitHubRepositoryRecord(
                        id=f"ghrepo-{uuid4().hex[:12]}",
                        github_installation_id="github-install-documint",
                        repository_id=None,
                        full_name=f"{settings.project_owner}/{settings.project_repo}".lower(),
                        owner=settings.project_owner,
                        name=settings.project_repo,
                        default_branch=settings.default_branch,
                        visibility="public",
                        is_private=False,
                        is_archived=False,
                        metadata_json={
                            "bootstrap": True,
                            "html_url": f"https://github.com/{settings.project_owner}/{settings.project_repo}",
                        },
                    )
                )
            settings_record = session.get(
                ProjectSettingsRecord, f"settings-{settings.project_id}"
            )
            if settings_record is None:
                session.add(
                    ProjectSettingsRecord(
                        id=f"settings-{settings.project_id}",
                        project_id=settings.project_id,
                        docs_root=docs_root,
                        config_version=int(config["version"]),
                        config_json=config,
                        ai_policy=dict(config["ai"]),
                        publish_behavior=dict(config["publish"]),
                        pr_behavior=dict(config["pull_requests"]),
                    )
                )
            else:
                settings_record.docs_root = docs_root
                settings_record.config_version = int(config["version"])
                settings_record.config_json = config
                settings_record.ai_policy = dict(config["ai"])
                settings_record.publish_behavior = dict(config["publish"])
                settings_record.pr_behavior = dict(config["pull_requests"])
            self._upsert_artifact_definitions(session, settings.project_id, config)
            self._ensure_project_artifacts(
                session, settings.project_id, settings_record
            )

    def _merge_installation_records(
        self,
        session: Session,
        *,
        target: GitHubInstallationRecord,
        source: GitHubInstallationRecord,
    ) -> GitHubInstallationRecord:
        if target.id == source.id:
            return target
        source_installation_id = source.installation_id
        if source_installation_id and target.installation_id != source_installation_id:
            source.installation_id = None
        target.account_login = target.account_login or source.account_login
        target.account_type = target.account_type or source.account_type
        target.repository_selection = (
            target.repository_selection or source.repository_selection or "selected"
        )
        target.metadata_json = {
            **(source.metadata_json or {}),
            **(target.metadata_json or {}),
        }
        session.flush()
        for project in session.scalars(
            select(ProjectRecord).where(ProjectRecord.github_installation_id == source.id)
        ):
            project.github_installation_id = target.id
        for source_record in session.scalars(
            select(RepositorySourceRecord).where(
                RepositorySourceRecord.installation_id == source.id
            )
        ):
            source_record.installation_id = target.id
        existing_full_names = set(
            session.scalars(
                select(GitHubRepositoryRecord.full_name).where(
                    GitHubRepositoryRecord.github_installation_id == target.id
                )
            )
        )
        for repository in session.scalars(
            select(GitHubRepositoryRecord).where(
                GitHubRepositoryRecord.github_installation_id == source.id
            )
        ):
            if repository.full_name in existing_full_names:
                session.delete(repository)
                continue
            repository.github_installation_id = target.id
            existing_full_names.add(repository.full_name)
        session.delete(source)
        session.flush()
        return target

    def _load_repo_config(self) -> dict[str, Any]:
        path = self.repo_root / settings.documint_config_filename
        if not path.exists() or yaml is None:
            return self._default_project_config()
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return self._default_project_config()
        config = self._default_project_config()
        for key in ("version", "project", "docs", "publish", "pull_requests", "ai"):
            value = raw.get(key)
            if isinstance(value, dict):
                config[key].update(value)
            elif value is not None:
                config[key] = value
        artifacts = raw.get("artifacts")
        if isinstance(artifacts, list) and artifacts:
            config["artifacts"] = [
                artifact for artifact in artifacts if isinstance(artifact, dict)
            ]
        return config

    def _default_project_config(self) -> dict[str, Any]:
        return {
            "version": 1,
            "project": {
                "name": settings.project_name,
                "slug": settings.project_slug,
                "description": (
                    "Verified, repo-native documentation operations for AI infra teams "
                    "shipping APIs, SDKs, and MCP servers."
                ),
            },
            "docs": {"root": "content/docs"},
            "publish": {
                "public_subpath": True,
                "site_prefix": "/p",
                "revalidate_on_publish": True,
            },
            "pull_requests": {
                "branch_prefix": "documint",
                "strategy": "one_pr_per_artifact",
                "direct_default_branch_writes": False,
            },
            "ai": {
                "provider": "huggingface",
                "draft_policy": "on_demand",
                "review_policy": "human_required",
            },
            "artifacts": [
                {
                    "id": spec.artifact_key,
                    "slug": spec.slug,
                    "title": spec.title,
                    "type": spec.artifact_type.value,
                    "summary": spec.summary,
                    "doc_paths": list(spec.doc_paths),
                    "source_patterns": list(spec.source_patterns),
                }
                for spec in DEFAULT_ARTIFACT_SPECS
            ],
        }

    def _artifact_specs_from_config(self, config: dict[str, Any]) -> list[ArtifactSpec]:
        raw_artifacts = config.get("artifacts")
        if not isinstance(raw_artifacts, list):
            raw_artifacts = []
        specs: list[ArtifactSpec] = []
        for item in raw_artifacts:
            if not isinstance(item, dict):
                continue
            artifact_type = item.get("type")
            artifact_id = item.get("id")
            slug = item.get("slug")
            title = item.get("title")
            summary = item.get("summary")
            doc_paths = item.get("doc_paths")
            source_patterns = item.get("source_patterns")
            source_paths = item.get("source_paths")
            if not all(
                isinstance(value, str)
                for value in (artifact_type, artifact_id, slug, title, summary)
            ):
                continue
            if not isinstance(doc_paths, list):
                continue
            try:
                artifact_key = cast(str, artifact_id)
                artifact_slug = cast(str, slug)
                artifact_title = cast(str, title)
                artifact_type_name = cast(str, artifact_type)
                artifact_summary = cast(str, summary)
                normalized_patterns: list[str] = []
                if isinstance(source_patterns, list):
                    normalized_patterns.extend(
                        pattern
                        for pattern in source_patterns
                        if isinstance(pattern, str) and pattern.strip()
                    )
                if isinstance(source_paths, list):
                    normalized_patterns.extend(
                        path
                        for path in source_paths
                        if isinstance(path, str) and path.strip()
                    )
                specs.append(
                    ArtifactSpec(
                        artifact_key=artifact_key,
                        slug=artifact_slug,
                        title=artifact_title,
                        artifact_type=ArtifactType(artifact_type_name),
                        summary=artifact_summary,
                        doc_paths=tuple(
                            path for path in doc_paths if isinstance(path, str)
                        ),
                        source_patterns=tuple(normalized_patterns),
                    )
                )
            except ValueError:
                continue
        return specs or list(DEFAULT_ARTIFACT_SPECS)

    def _sync_project_runtime(self, session: Session, project: ProjectRecord) -> None:
        source = session.get(RepositorySourceRecord, f"source-{project.id}")
        if source is not None:
            source.current_ref = self._head_ref
            source.local_path = str(self.repo_root)

    def _upsert_artifact_definitions(
        self,
        session: Session,
        project_id: str,
        config: dict[str, object],
    ) -> None:
        specs = self._artifact_specs_from_config(config)
        existing = {
            item.artifact_key: item
            for item in session.scalars(
                select(ArtifactDefinitionRecord).where(
                    ArtifactDefinitionRecord.project_id == project_id
                )
            ).all()
        }
        for spec in specs:
            record = existing.get(spec.artifact_key)
            record_id = f"{project_id}:{spec.artifact_key}"
            if record is None:
                session.add(
                    ArtifactDefinitionRecord(
                        id=record_id,
                        project_id=project_id,
                        artifact_key=spec.artifact_key,
                        slug=spec.slug,
                        title=spec.title,
                        artifact_type=spec.artifact_type.value,
                        summary=spec.summary,
                        doc_paths=list(spec.doc_paths),
                        source_patterns=list(spec.source_patterns),
                    )
                )
                continue
            record.slug = spec.slug
            record.title = spec.title
            record.artifact_type = spec.artifact_type.value
            record.summary = spec.summary
            record.doc_paths = list(spec.doc_paths)
            record.source_patterns = list(spec.source_patterns)

    def _ensure_project_artifacts(
        self,
        session: Session,
        project_id: str,
        settings_record: ProjectSettingsRecord | None,
    ) -> None:
        config = (
            settings_record.config_json
            if settings_record is not None
            else self._load_repo_config()
        )
        self._upsert_artifact_definitions(session, project_id, config)
        definitions = session.scalars(
            select(ArtifactDefinitionRecord).where(
                ArtifactDefinitionRecord.project_id == project_id
            )
        ).all()
        for definition in definitions:
            trace = self._build_artifact_trace(definition)
            record = session.get(
                ArtifactTraceRecord, f"{project_id}:{definition.artifact_key}"
            )
            if record is None:
                session.add(
                    ArtifactTraceRecord(
                        id=f"{project_id}:{definition.artifact_key}",
                        project_id=project_id,
                        artifact_definition_id=definition.id,
                        doc_paths=trace.doc_paths,
                        source_paths=trace.source_paths,
                        latest_source_revision=_revision_to_payload(
                            trace.latest_source_revision
                        ),
                        latest_doc_revision=_revision_to_payload(
                            trace.latest_doc_revision
                        ),
                        verification_status=trace.verification_status.value,
                    )
                )
                continue
            record.doc_paths = trace.doc_paths
            record.source_paths = trace.source_paths
            record.latest_source_revision = _revision_to_payload(
                trace.latest_source_revision
            )
            record.latest_doc_revision = _revision_to_payload(trace.latest_doc_revision)
            record.verification_status = trace.verification_status.value

    def _artifact_traces_for_project(
        self, session: Session, project_id: str
    ) -> list[ArtifactTrace]:
        definitions = {
            item.id: item
            for item in session.scalars(
                select(ArtifactDefinitionRecord).where(
                    ArtifactDefinitionRecord.project_id == project_id
                )
            ).all()
        }
        traces = session.scalars(
            select(ArtifactTraceRecord)
            .where(ArtifactTraceRecord.project_id == project_id)
            .order_by(ArtifactTraceRecord.id.asc())
        ).all()
        return [
            self._trace_model(item, definitions[item.artifact_definition_id])
            for item in traces
            if item.artifact_definition_id in definitions
        ]

    def _build_artifact_trace(
        self, definition: ArtifactDefinitionRecord
    ) -> ArtifactTrace:
        source_paths = self._resolve_patterns(definition.source_patterns)
        doc_paths = [
            path for path in definition.doc_paths if (self.repo_root / path).exists()
        ]
        latest_source = self._latest_revision(source_paths)
        latest_doc = self._latest_revision(doc_paths)

        if not doc_paths:
            status = VerificationStatus.MISSING
        elif latest_source and (
            latest_doc is None or latest_source.touched_at > latest_doc.touched_at
        ):
            status = VerificationStatus.STALE
        else:
            status = VerificationStatus.VERIFIED

        return ArtifactTrace(
            id=definition.artifact_key,
            slug=definition.slug,
            title=definition.title,
            artifact_type=ArtifactType(definition.artifact_type),
            summary=definition.summary,
            doc_paths=doc_paths,
            source_paths=source_paths,
            latest_source_revision=latest_source,
            latest_doc_revision=latest_doc,
            verification_status=status,
        )

    def _compute_findings(
        self,
        session: Session,
        project_id: str,
        traces: list[ArtifactTrace],
    ) -> list[DriftFinding]:
        findings: list[DriftFinding] = []
        now = _now()
        drift_engine = get_drift_engine()

        # Collect per-artifact drift results for cascade detection
        drift_results: dict[str, DriftResult] = {}
        # Load all definition records once so we can read/write symbol_hash/symbols_json
        definition_records: dict[str, ArtifactDefinitionRecord] = {
            rec.artifact_key: rec
            for rec in session.scalars(
                select(ArtifactDefinitionRecord).where(
                    ArtifactDefinitionRecord.project_id == project_id
                )
            ).all()
        }

        for trace in traces:
            # --- Semantic drift check via DriftEngine ---
            definition = definition_records.get(trace.id)
            if definition is not None and trace.source_paths:
                # Read source file contents for this artifact
                source_contents: dict[str, str] = {}
                for rel_path in trace.source_paths:
                    abs_path = self.repo_root / rel_path
                    if abs_path.is_file():
                        try:
                            source_contents[rel_path] = abs_path.read_text(
                                encoding="utf-8", errors="replace"
                            )
                        except OSError:
                            pass

                if source_contents:
                    drift_result = drift_engine.check(
                        artifact_key=trace.id,
                        source_contents=source_contents,
                        stored_hash=definition.symbol_hash,
                        stored_symbols_json=definition.symbols_json,
                    )
                    # Persist updated hash and symbols back to DB
                    definition.symbol_hash = drift_result.new_symbol_hash
                    definition.symbols_json = drift_engine.symbols_to_json(
                        drift_result.new_symbols
                    )
                    drift_results[trace.id] = drift_result

                    # --- Index symbols in the knowledge graph (best-effort) ---
                    try:
                        sgraph = get_symbol_graph()
                        sgraph.index_artifact(
                            artifact_id=trace.id,
                            project_id=project_id,
                            symbols=[
                                s.to_lsif_compact() for s in drift_result.new_symbols
                            ],
                        )
                    except Exception:
                        logger.warning(
                            "symbol_graph_index_failed",
                            artifact=trace.id,
                            exc_info=True,
                        )

                    if drift_result.is_stale:
                        severity = (
                            FindingSeverity.HIGH
                            if drift_result.diff.has_breaking_changes
                            else FindingSeverity.MEDIUM
                        )
                        findings.append(
                            DriftFinding(
                                id=f"finding-{project_id}-{trace.id}",
                                project_id=project_id,
                                artifact_id=trace.id,
                                artifact_type=trace.artifact_type,
                                severity=severity,
                                summary=drift_result.finding_summary(),
                                rationale=(
                                    "Structural symbol changes detected: exported symbols"
                                    " were added, removed, or modified."
                                ),
                                source_paths=trace.source_paths,
                                doc_paths=trace.doc_paths,
                                suggested_actions=[
                                    "Review the latest source diff and capture any interface changes.",
                                    "Update the target markdown page with fresh examples, links, and API details.",
                                    "Re-run drift and publish a preview before opening the docs PR.",
                                ],
                                source_revision=trace.latest_source_revision,
                                doc_revision=trace.latest_doc_revision,
                                status="open",
                                created_at=now,
                                updated_at=now,
                                changed_symbols=(
                                    [c.to_dict() for c in drift_result.diff.changes]
                                    if drift_result.diff
                                    else []
                                ),
                                symbol_hash=drift_result.new_symbol_hash,
                                confidence_score=(
                                    drift_result.diff.confidence_score()
                                    if drift_result.diff
                                    else 0.5
                                ),
                                has_breaking_changes=(
                                    drift_result.diff.has_breaking_changes
                                    if drift_result.diff
                                    else False
                                ),
                            )
                        )

                        # --- Cross-artifact impact via symbol graph (best-effort) ---
                        try:
                            changed_names = drift_result.diff.changed_symbol_names
                            if changed_names:
                                sgraph = get_symbol_graph()
                                affected = sgraph.find_affected_artifacts(
                                    changed_names, project_id
                                )
                                # Keep only OTHER artifacts (exclude the current one)
                                cross_refs = {
                                    aid: syms
                                    for aid, syms in affected.items()
                                    if aid != trace.id
                                }
                                if cross_refs:
                                    findings[-1].cross_artifact_refs = cross_refs
                                    logger.info(
                                        "cross_artifact_drift_detected",
                                        source_artifact=trace.id,
                                        affected_artifacts=list(cross_refs.keys()),
                                        affected_symbols={
                                            aid: syms for aid, syms in cross_refs.items()
                                        },
                                    )
                        except Exception:
                            logger.warning(
                                "symbol_graph_cross_artifact_failed",
                                artifact=trace.id,
                                exc_info=True,
                            )

                    # Skip the timestamp-based check for this trace since we have semantic data
                    continue

            # --- Fallback: timestamp-based drift detection (no source files or no definition) ---
            if trace.verification_status == VerificationStatus.VERIFIED:
                continue
            severity = (
                FindingSeverity.HIGH
                if trace.verification_status == VerificationStatus.MISSING
                else FindingSeverity.MEDIUM
            )
            findings.append(
                DriftFinding(
                    id=f"finding-{project_id}-{trace.id}",
                    project_id=project_id,
                    artifact_id=trace.id,
                    artifact_type=trace.artifact_type,
                    severity=severity,
                    summary=f"{trace.title} needs refresh before the next publish.",
                    rationale=(
                        "Source files changed after the documentation artifact was last verified."
                        if trace.verification_status == VerificationStatus.STALE
                        else "The expected documentation page does not exist yet."
                    ),
                    source_paths=trace.source_paths,
                    doc_paths=trace.doc_paths,
                    suggested_actions=[
                        "Review the latest source diff and capture any interface changes.",
                        "Update the target markdown page with fresh examples, links, and API details.",
                        "Re-run drift and publish a preview before opening the docs PR.",
                    ],
                    source_revision=trace.latest_source_revision,
                    doc_revision=trace.latest_doc_revision,
                    status="open",
                    created_at=now,
                    updated_at=now,
                )
            )

        # --- Cascade detection: find cross-artifact ripple effects ---
        # Build a map of changed symbol names per artifact from drift results
        all_changed_symbols: dict[str, list[str]] = {}
        for artifact_key, dr in drift_results.items():
            if dr.is_stale and dr.diff and dr.diff.changes:
                all_changed_symbols[artifact_key] = dr.diff.changed_symbol_names

        if all_changed_symbols:
            # Build MintDocument stubs from artifact definitions for cascade text search.
            # Each stub needs:
            #   - symbols: list with a sentinel entry so _artifact_key() returns the key
            #   - narrative: the summary text to search for symbol mentions
            mint_stubs: list[MintDocument] = []
            for rec in definition_records.values():
                sentinel: dict[str, object] = {
                    "k": "__artifact__",
                    "n": rec.title,
                    "artifact_key": rec.artifact_key,
                    "artifact_type": rec.artifact_type,
                }
                stub = MintDocument(
                    source_files=list(rec.source_patterns),
                    symbols=[sentinel],
                    narrative=rec.summary,
                )
                mint_stubs.append(stub)

            cascade_finding_ids: set[str] = set()
            for source_key, symbol_names in all_changed_symbols.items():
                cascades = find_cascades(
                    changed_symbol_names=symbol_names,
                    source_artifact_key=source_key,
                    all_artifacts=mint_stubs,
                )
                for cascade in cascades:
                    if cascade.confidence not in ("HIGH", "MEDIUM"):
                        continue
                    cascade_id = f"cascade-{project_id}-{source_key}-{cascade.affected_artifact_key}"
                    if cascade_id in cascade_finding_ids:
                        continue
                    cascade_finding_ids.add(cascade_id)
                    # Determine artifact type for the affected artifact
                    affected_def = definition_records.get(cascade.affected_artifact_key)
                    affected_type = (
                        ArtifactType(affected_def.artifact_type)
                        if affected_def
                        else ArtifactType.API_REFERENCE
                    )
                    findings.append(
                        DriftFinding(
                            id=cascade_id,
                            project_id=project_id,
                            artifact_id=cascade.affected_artifact_key,
                            artifact_type=affected_type,
                            severity=FindingSeverity.MEDIUM,
                            summary=(
                                f"Cascade: symbols from {cascade.source_artifact_key}"
                                f" referenced in {cascade.affected_artifact_key}"
                            ),
                            rationale=(
                                f"Changed symbols ({', '.join(cascade.affected_symbol_names)})"
                                f" from {cascade.source_artifact_key} appear in this artifact's"
                                " narrative or API schema."
                            ),
                            source_paths=[],
                            doc_paths=[],
                            suggested_actions=[
                                "Review the affected sections for stale references.",
                                "Update any code examples or descriptions that mention the changed symbols.",
                            ],
                            status="open",
                            created_at=now,
                            updated_at=now,
                            changed_symbols=[
                                {"name": s, "kind": "cascade"}
                                for s in cascade.affected_symbol_names
                            ],
                            confidence_score=0.8 if cascade.confidence == "HIGH" else 0.5,
                        )
                    )

        return findings

    def _filter_findings(
        self,
        findings: list[DriftFinding],
        changed_files: list[str],
    ) -> list[DriftFinding]:
        if not changed_files:
            return findings
        changed = {path.strip() for path in changed_files if path.strip()}
        filtered: list[DriftFinding] = []
        for finding in findings:
            matching_sources = [path for path in finding.source_paths if path in changed]
            matching_docs = [path for path in finding.doc_paths if path in changed]
            if not matching_sources and not matching_docs:
                continue
            filtered.append(
                finding.model_copy(
                    update={
                        "source_paths": matching_sources or finding.source_paths,
                        "doc_paths": matching_docs or finding.doc_paths,
                        "rationale": (
                            f"{finding.rationale} Relevant changed files: "
                            + ", ".join(matching_sources + matching_docs)
                        )[:1000],
                    }
                )
            )
        return filtered

    def _latest_run(self, session: Session, project_id: str) -> VerificationRun | None:
        record = session.scalar(
            select(VerificationRunRecord)
            .where(VerificationRunRecord.project_id == project_id)
            .order_by(desc(VerificationRunRecord.started_at))
        )
        if record is None:
            return None
        signal_record = session.get(SourceSignalRecord, record.signal_id)
        if signal_record is None:
            return None
        findings = [
            self._finding_model(item)
            for item in session.scalars(
                select(DriftFindingRecord)
                .where(DriftFindingRecord.verification_run_id == record.id)
                .order_by(desc(DriftFindingRecord.created_at))
            ).all()
        ]
        return VerificationRun(
            id=record.id,
            project_id=record.project_id,
            status=JobStatus(record.status),
            signal=SourceSignal(
                id=signal_record.id,
                type=SourceSignalType(signal_record.signal_type),
                ref=signal_record.ref,
                changed_files=list(signal_record.changed_files),
                created_at=signal_record.created_at,
            ),
            findings_count=record.findings_count,
            findings=findings,
            started_at=record.started_at,
            completed_at=record.completed_at,
        )

    def _latest_deployment(
        self, session: Session, project_id: str
    ) -> PublishDeployment | None:
        record = session.scalar(
            select(PublishDeploymentRecord)
            .where(PublishDeploymentRecord.project_id == project_id)
            .order_by(desc(PublishDeploymentRecord.generated_at))
        )
        return self._publish_model(record) if record is not None else None

    def _project_docs_root(self, session: Session, project_id: str) -> Path:
        settings_record = session.get(ProjectSettingsRecord, f"settings-{project_id}")
        docs_root = (
            settings_record.docs_root
            if settings_record is not None
            else str(settings.docs_content_path.relative_to(self.repo_root))
        )
        return (self.repo_root / docs_root).resolve()

    def _publish_pages_for_project(
        self,
        session: Session,
        workspace_slug: str,
        project_slug: str,
        project_id: str,
        deployment_id: str,
        docs_root: Path,
    ) -> list[PublishedPage]:
        pages: list[PublishedPage] = []
        session.execute(
            delete(PublishedPageRecord).where(
                PublishedPageRecord.project_id == project_id
            )
        )
        for markdown_path in sorted(docs_root.rglob("*.md")):
            relative_source = str(markdown_path.relative_to(self.repo_root))
            raw = markdown_path.read_text(encoding="utf-8")
            metadata, body = _parse_frontmatter(raw)
            relative_doc = markdown_path.relative_to(docs_root)
            path_slug = str(relative_doc.with_suffix("")).replace("\\", "/")
            page_path = "index" if path_slug == "index" else path_slug
            title = metadata.get("title") or relative_doc.stem.replace("-", " ").title()
            description = metadata.get("description") or ""
            record = PublishedPageRecord(
                id=f"page-{uuid4().hex[:12]}",
                project_id=project_id,
                deployment_id=deployment_id,
                workspace_slug=workspace_slug,
                project_slug=project_slug,
                path=page_path,
                title=title,
                description=description,
                content_markdown=body,
                search_body=f"{title}\n{description}\n{body}",
                source_path=relative_source,
            )
            session.add(record)
            session.flush()
            pages.append(self._published_page_model(record))
        if not any(page.path == "index" for page in pages):
            title = f"{project_slug.replace('-', ' ').title()} Docs"
            summary = (
                "Published documentation generated by Documint for the latest "
                "successful deployment."
            )
            links = "\n".join(
                f"- [{page.title}](./{page.path})"
                for page in pages
                if page.path != "index"
            )
            body = "\n".join(
                line
                for line in (
                    f"# {title}",
                    "",
                    summary,
                    "",
                    "## Pages",
                    "",
                    links or "- No published pages are available yet.",
                )
                if line is not None
            )
            record = PublishedPageRecord(
                id=f"page-{uuid4().hex[:12]}",
                project_id=project_id,
                deployment_id=deployment_id,
                workspace_slug=workspace_slug,
                project_slug=project_slug,
                path="index",
                title=title,
                description=summary,
                content_markdown=body,
                search_body=f"{title}\n{summary}\n{body}",
                source_path=str(docs_root.relative_to(self.repo_root)),
            )
            session.add(record)
            session.flush()
            pages.append(self._published_page_model(record))
        return pages

    def _store_patch(
        self,
        session: Session,
        project_id: str,
        artifact_id: str,
        finding_id: str | None,
        target_path: str,
        result: DraftPatchResult,
    ) -> Any:
        patch_id = f"patch-{uuid4().hex[:12]}"
        patch_record = DocPatchRecord(
            id=patch_id,
            project_id=project_id,
            finding_id=finding_id,
            artifact_key=artifact_id,
            target_path=target_path,
            summary=result.summary,
            rationale=result.rationale,
            proposed_sections=result.proposed_sections,
            citations=[
                citation.model_dump(mode="json") for citation in result.citations
            ],
            preview_markdown=result.preview_markdown,
            ai_provider=result.ai_provider,
            model_name=result.model_name,
            chain_steps_used=result.chain_steps_used,
            confidence_score=result.confidence_score,
            status=self._patch_status_for_result(result),
        )
        session.add(patch_record)
        session.add(
            AgentRunRecord(
                id=f"agent-{uuid4().hex[:12]}",
                project_id=project_id,
                kind="patch_generation",
                provider=result.ai_provider,
                model=result.model_name,
                status="completed",
                input_summary=result.input_summary,
                output_summary=result.summary,
                metadata_json={"artifact_id": artifact_id, "finding_id": finding_id},
                created_at=_now(),
                completed_at=_now(),
            )
        )
        session.flush()
        return patch_record

    def _patch_status_for_result(self, result: DraftPatchResult) -> str:
        if not result.citations or not result.preview_markdown.strip():
            return "blocked"
        return "reviewable"

    def _patch_review_error(self, patch: DocPatchRecord) -> str | None:
        if not patch.citations:
            return "Patch draft is blocked because it has no source citations."
        if not patch.preview_markdown.strip():
            return "Patch draft is blocked because it has no markdown preview."
        return None

    def _record_activity(
        self,
        session: Session,
        workspace_id: str,
        project_id: str | None,
        kind: str,
        title: str,
        body: str,
        metadata_json: dict[str, object],
    ) -> None:
        session.add(
            ActivityEventRecord(
                id=f"evt-{uuid4().hex[:12]}",
                workspace_id=workspace_id,
                project_id=project_id,
                kind=kind,
                title=title,
                body=body,
                metadata_json=metadata_json,
            )
        )

    def _workspace_records_for_user(
        self, session: Session, user_id: str | None
    ) -> list[WorkspaceRecord]:
        if user_id is None:
            return list(
                session.scalars(
                    select(WorkspaceRecord).order_by(WorkspaceRecord.created_at.asc())
                ).all()
            )
        return list(
            session.scalars(
                select(WorkspaceRecord)
                .join(
                    WorkspaceMemberRecord,
                    WorkspaceMemberRecord.workspace_id == WorkspaceRecord.id,
                )
                .where(WorkspaceMemberRecord.user_id == user_id)
                .order_by(WorkspaceRecord.created_at.asc())
            ).all()
        )

    def _require_workspace_access(
        self, session: Session, workspace_id: str, user_id: str | None
    ) -> None:
        if user_id is None:
            return
        membership = session.scalar(
            select(WorkspaceMemberRecord).where(
                WorkspaceMemberRecord.workspace_id == workspace_id,
                WorkspaceMemberRecord.user_id == user_id,
            )
        )
        if membership is None:
            raise PermissionError(
                f"User {user_id} does not belong to workspace {workspace_id}"
            )

    def _require_project_access(
        self, session: Session, project_id: str, user_id: str | None
    ) -> None:
        if user_id is None:
            return
        project = session.get(ProjectRecord, project_id)
        if project is None:
            raise KeyError(f"Unknown project id: {project_id}")
        self._require_workspace_access(session, project.workspace_id, user_id)

    def _assign_first_operator_workspace(self, session: Session, user_id: str) -> None:
        existing_membership = session.scalar(
            select(WorkspaceMemberRecord).where(
                WorkspaceMemberRecord.user_id == user_id
            )
        )
        if existing_membership is not None:
            return
        existing_clerk_memberships = session.scalar(
            select(WorkspaceMemberRecord)
            .join(UserRecord, UserRecord.id == WorkspaceMemberRecord.user_id)
            .where(UserRecord.provider == "clerk")
        )
        if existing_clerk_memberships is not None:
            return
        workspace = session.get(WorkspaceRecord, settings.default_workspace_id)
        if workspace is None:
            return
        session.add(
            WorkspaceMemberRecord(
                id=f"wm-{uuid4().hex[:12]}",
                workspace_id=workspace.id,
                user_id=user_id,
                role="owner",
            )
        )

    def _run_frontend_revalidation_job(
        self, project_id: str, deployment_id: str | None = None
    ) -> QueuedJob | None:
        if (
            not settings.frontend_revalidate_url
            or not settings.frontend_revalidate_secret
        ):
            return None
        job = self.create_job(
            job_kind="frontend_revalidate",
            project_id=project_id,
            payload_json={"deployment_id": deployment_id},
            user_id=None,
        )
        self.mark_job_running(job.job_id)
        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.post(
                    settings.frontend_revalidate_url,
                    headers={
                        "X-Documint-Internal": settings.frontend_revalidate_secret
                    },
                    json={"project_id": project_id, "deployment_id": deployment_id},
                )
                response.raise_for_status()
        except httpx.HTTPError as exc:
            failed_job = self.mark_job_failed(
                job.job_id,
                error_summary=f"Frontend revalidation failed: {exc}",
                result_json={"deployment_id": deployment_id},
            )
            with session_scope() as session:
                project = session.get(ProjectRecord, project_id)
                if project is not None:
                    self._record_activity(
                        session,
                        project.workspace_id,
                        project_id,
                        "publish.revalidation.failed",
                        f"Frontend revalidation failed for {project.name}",
                        failed_job.error_summary or "Frontend revalidation failed.",
                        {"job_id": failed_job.job_id, "deployment_id": deployment_id},
                    )
            return failed_job
        return self.mark_job_completed(
            job.job_id,
            resource_type="publish_deployment",
            resource_id=deployment_id,
            result_summary="Frontend cache refreshed.",
            result_json={"deployment_id": deployment_id},
        )

    def _public_docs_base_url(self, workspace_slug: str, project_slug: str) -> str:
        return f"{settings.public_base_url.rstrip('/')}/p/{workspace_slug}/{project_slug}/docs"

    def _workspace_slug(self, session: Session, workspace_id: str) -> str:
        workspace = session.get(WorkspaceRecord, workspace_id)
        if workspace is None:
            return settings.default_workspace_slug
        return workspace.slug

    def _read_doc_path(self, relative_path: str) -> str:
        absolute_path = self.repo_root / relative_path
        if not absolute_path.exists():
            return ""
        return absolute_path.read_text(encoding="utf-8")

    def _read_source_content(self, source_paths: list[str], max_chars: int = 4000) -> str:
        """Read source files and return concatenated content for AI context, capped at max_chars."""
        parts: list[str] = []
        remaining = max_chars
        for path in source_paths[:5]:
            absolute_path = self.repo_root / path
            if not absolute_path.exists():
                continue
            try:
                text = absolute_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            snippet = text[:remaining]
            parts.append(f"### {path}\n```\n{snippet}\n```")
            remaining -= len(snippet)
            if remaining <= 0:
                break
        return "\n\n".join(parts)

    def _resolve_patterns(self, patterns: Iterable[str]) -> list[str]:
        matches: set[str] = set()
        for pattern in patterns:
            absolute_pattern = self.repo_root / pattern
            for match in glob.glob(str(absolute_pattern), recursive=True):
                path = Path(match)
                relative_path = path.relative_to(self.repo_root)
                if path.is_file() and self._should_track_relative_path(relative_path):
                    matches.add(str(relative_path))
            exact = self.repo_root / pattern
            if exact.is_file() and self._should_track_relative_path(
                exact.relative_to(self.repo_root)
            ):
                matches.add(str(exact.relative_to(self.repo_root)))
        return sorted(matches)

    def _latest_revision(self, paths: Iterable[str]) -> RepositoryRevision | None:
        normalized_paths = [
            path
            for path in paths
            if (self.repo_root / path).exists()
            and self._should_track_relative_path(Path(path))
        ]
        if not normalized_paths:
            return None
        candidates: list[RepositoryRevision] = []
        dirty_paths = [path for path in normalized_paths if path in self._dirty_paths]
        clean_paths = [
            path for path in normalized_paths if path not in self._dirty_paths
        ]
        if dirty_paths:
            latest_dirty = max(
                dirty_paths,
                key=lambda path: (self.repo_root / path).stat().st_mtime,
            )
            candidates.append(
                RepositoryRevision(
                    ref="WORKTREE",
                    touched_at=_utc_from_timestamp(
                        (self.repo_root / latest_dirty).stat().st_mtime
                    ),
                    committed=False,
                )
            )
        if clean_paths:
            result = self._run_git("log", "-1", "--format=%H|%ct", "--", *clean_paths)
            if result:
                commit_ref, _, timestamp = result.partition("|")
                if commit_ref and timestamp:
                    candidates.append(
                        RepositoryRevision(
                            ref=commit_ref,
                            touched_at=_utc_from_timestamp(int(timestamp)),
                            committed=True,
                        )
                    )
            else:
                latest_clean = max(
                    clean_paths,
                    key=lambda path: (self.repo_root / path).stat().st_mtime,
                )
                candidates.append(
                    RepositoryRevision(
                        ref=(
                            self._head_ref
                            if self._head_ref_source in {"git", "env"}
                            else "FILESYSTEM"
                        ),
                        touched_at=_utc_from_timestamp(
                            (self.repo_root / latest_clean).stat().st_mtime
                        ),
                        committed=self._head_ref_source in {"git", "env"},
                    )
                )
        if not candidates:
            return None
        return max(candidates, key=lambda item: item.touched_at)

    def _worktree_changed_files(self) -> list[str]:
        if self._dirty_paths:
            return sorted(self._dirty_paths)
        changed_files = self._read_worktree_changed_files()
        self._dirty_paths = set(changed_files)
        return changed_files

    def _refresh_repo_state(self) -> None:
        self._dirty_paths = set(self._read_worktree_changed_files())
        head = self._run_git("rev-parse", "--short", "HEAD")
        if head:
            clean_ref = head
            self._head_ref_source = "git"
        elif settings.deploy_commit_ref:
            clean_ref = settings.deploy_commit_ref[:12]
            self._head_ref_source = "env"
        else:
            clean_ref = "HEAD"
            self._head_ref_source = "unknown"
        if self._dirty_paths:
            self._head_ref = (
                f"{clean_ref}+WORKTREE" if clean_ref != "HEAD" else "WORKTREE"
            )
        else:
            self._head_ref = clean_ref

    def _read_worktree_changed_files(self) -> list[str]:
        result = self._run_git("status", "--porcelain")
        changed_files: list[str] = []
        for line in result.splitlines():
            if not line.strip():
                continue
            candidate = line[3:].strip()
            if " -> " in candidate:
                candidate = candidate.split(" -> ", 1)[1]
            relative_path = Path(candidate)
            if self._should_track_relative_path(relative_path):
                changed_files.append(candidate)
        return changed_files

    def _should_track_relative_path(self, relative_path: Path) -> bool:
        return not (
            any(part in IGNORED_PATH_PARTS for part in relative_path.parts)
            or relative_path.suffix in IGNORED_SUFFIXES
        )

    def _run_git(self, *args: str) -> str:
        if self._git_executable is None:
            return ""
        completed = subprocess.run(  # noqa: S603 - internal git invocation only.
            [self._git_executable, "-C", str(self.repo_root), *args],
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            return ""
        return completed.stdout.strip()

    def _user_model(self, record: UserRecord) -> User:
        return User(
            id=record.id,
            external_id=record.external_id,
            email=record.email,
            name=record.name,
            provider=record.provider,
            created_at=record.created_at,
        )

    def _workspace_model(self, record: WorkspaceRecord) -> Workspace:
        return Workspace(
            id=record.id,
            slug=record.slug,
            name=record.name,
            description=record.description,
            created_at=record.created_at,
        )

    def _source_model(self, record: RepositorySourceRecord) -> RepositorySource:
        return RepositorySource(
            id=record.id,
            project_id=record.project_id,
            provider=record.provider,
            owner=record.owner,
            repo=record.repo,
            default_branch=record.default_branch,
            local_path=record.local_path,
            current_ref=record.current_ref,
            docs_root=record.docs_root,
            installation_id=record.installation_id,
        )

    def _installation_model(
        self, record: GitHubInstallationRecord
    ) -> GitHubInstallation:
        return GitHubInstallation(
            id=record.id,
            workspace_id=record.workspace_id,
            installation_id=record.installation_id,
            account_login=record.account_login,
            account_type=record.account_type,
            repository_selection=record.repository_selection,
            metadata_json=record.metadata_json,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )

    def _github_repository_model(
        self, record: GitHubRepositoryRecord
    ) -> GitHubRepository:
        return GitHubRepository(
            id=record.id,
            github_installation_id=record.github_installation_id,
            repository_id=record.repository_id,
            full_name=record.full_name,
            owner=record.owner,
            name=record.name,
            default_branch=record.default_branch,
            visibility=record.visibility,
            is_private=record.is_private,
            is_archived=record.is_archived,
            metadata_json=record.metadata_json,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )

    def _project_settings_model(
        self, record: ProjectSettingsRecord | None
    ) -> ProjectSettings | None:
        if record is None:
            return None
        return ProjectSettings(
            id=record.id,
            project_id=record.project_id,
            docs_root=record.docs_root,
            config_version=record.config_version,
            config_json=record.config_json,
            ai_policy=record.ai_policy,
            publish_behavior=record.publish_behavior,
            pr_behavior=record.pr_behavior,
            updated_at=record.updated_at,
        )

    def _project_model(self, session: Session, record: ProjectRecord) -> Project:
        source = session.get(RepositorySourceRecord, f"source-{record.id}")
        if source is None:
            raise KeyError(f"Missing source for project {record.id}")
        definitions = session.scalars(
            select(ArtifactDefinitionRecord)
            .where(ArtifactDefinitionRecord.project_id == record.id)
            .order_by(ArtifactDefinitionRecord.slug.asc())
        ).all()
        return Project(
            id=record.id,
            workspace_id=record.workspace_id,
            github_installation_id=record.github_installation_id,
            name=record.name,
            slug=record.slug,
            description=record.description,
            public_url=record.public_url,
            dashboard_url=record.dashboard_url,
            onboarding_status=record.onboarding_status,
            source=self._source_model(source),
            artifact_types=[ArtifactType(item.artifact_type) for item in definitions],
        )

    def _trace_model(
        self,
        record: ArtifactTraceRecord,
        definition: ArtifactDefinitionRecord,
    ) -> ArtifactTrace:
        return ArtifactTrace(
            id=definition.artifact_key,
            slug=definition.slug,
            title=definition.title,
            artifact_type=ArtifactType(definition.artifact_type),
            summary=definition.summary,
            doc_paths=list(record.doc_paths),
            source_paths=list(record.source_paths),
            latest_source_revision=_revision_from_payload(
                record.latest_source_revision
            ),
            latest_doc_revision=_revision_from_payload(record.latest_doc_revision),
            verification_status=VerificationStatus(record.verification_status),
        )

    def _finding_model(self, record: DriftFindingRecord) -> DriftFinding:
        return DriftFinding(
            id=record.id,
            project_id=record.project_id,
            verification_run_id=record.verification_run_id,
            artifact_id=record.artifact_key,
            artifact_type=ArtifactType(record.artifact_type),
            severity=FindingSeverity(record.severity),
            summary=record.summary,
            rationale=record.rationale,
            source_paths=list(record.source_paths),
            doc_paths=list(record.doc_paths),
            suggested_actions=list(record.suggested_actions),
            source_revision=_revision_from_payload(record.source_revision),
            doc_revision=_revision_from_payload(record.doc_revision),
            status=record.status,
            created_at=record.created_at,
            updated_at=record.updated_at,
            changed_symbols=list(record.changed_symbols or []),
        )

    def _patch_model(self, record: Any) -> DocPatch:
        return DocPatch(
            id=record.id,
            project_id=record.project_id,
            finding_id=record.finding_id,
            artifact_id=record.artifact_key,
            target_path=record.target_path,
            summary=record.summary,
            rationale=record.rationale,
            proposed_sections=list(record.proposed_sections),
            citations=[
                PatchCitation(**citation) for citation in (record.citations or [])
            ],
            preview_markdown=record.preview_markdown,
            ai_provider=record.ai_provider,
            model_name=record.model_name,
            chain_steps_used=record.chain_steps_used,
            confidence_score=record.confidence_score,
            status=record.status,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )

    def _pull_request_model(self, record: PullRequestRecord) -> PullRequestModel:
        return PullRequestModel(
            id=record.id,
            project_id=record.project_id,
            patch_id=record.patch_id,
            branch_name=record.branch_name,
            title=record.title,
            url=record.url,
            state=record.state,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )

    def _open_pull_request_on_github(
        self,
        *,
        session: Session,
        project: ProjectRecord,
        source: RepositorySourceRecord,
        patch: DocPatchRecord,
        branch_name: str,
        title: str,
    ) -> GitHubPullRequestResult:
        installation_record = (
            session.get(GitHubInstallationRecord, project.github_installation_id)
            if project.github_installation_id
            else None
        )
        external_installation_id = (
            installation_record.installation_id
            if installation_record is not None
            else None
        )
        if (
            external_installation_id is None
            and project.id == settings.project_id
            and settings.self_bootstrap_installation_id
        ):
            external_installation_id = settings.self_bootstrap_installation_id
        if external_installation_id and settings.github_app_private_key:
            body = (
                "This PR was opened by Documint.\n\n"
                f"- Artifact: `{patch.artifact_key}`\n"
                f"- Target path: `{patch.target_path}`\n"
                f"- Patch id: `{patch.id}`\n"
            )
            return create_or_update_pull_request(
                installation_id=external_installation_id,
                owner=source.owner,
                repo=source.repo,
                base_branch=source.default_branch,
                branch_name=branch_name,
                target_path=patch.target_path,
                content_markdown=patch.preview_markdown,
                title=title,
                body=body,
                commit_message=f"docs: update {patch.artifact_key} via Documint",
            )
        return GitHubPullRequestResult(
            branch_name=branch_name,
            title=title,
            url=(
                f"https://github.com/{source.owner}/{source.repo}/compare/"
                f"{source.default_branch}...{branch_name}?expand=1"
            ),
            state="open",
        )

    def _publish_model(self, record: PublishDeploymentRecord) -> PublishDeployment:
        return PublishDeployment(
            id=record.id,
            project_id=record.project_id,
            status=JobStatus(record.status),
            commit_ref=record.commit_ref,
            site_url=record.site_url,
            preview_url=record.preview_url,
            docs_count=record.docs_count,
            generated_at=record.generated_at,
        )

    def _published_page_model(self, record: PublishedPageRecord) -> PublishedPage:
        return PublishedPage(
            id=record.id,
            project_id=record.project_id,
            deployment_id=record.deployment_id,
            workspace_slug=record.workspace_slug,
            project_slug=record.project_slug,
            path=record.path,
            title=record.title,
            description=record.description,
            content_markdown=record.content_markdown,
            search_body=record.search_body,
            source_path=record.source_path,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )

    def _activity_model(self, record: ActivityEventRecord) -> ActivityEvent:
        return ActivityEvent(
            id=record.id,
            workspace_id=record.workspace_id,
            project_id=record.project_id,
            kind=record.kind,
            title=record.title,
            body=record.body,
            metadata_json=record.metadata_json,
            created_at=record.created_at,
        )

    def _job_model(self, record: BackgroundJobRecord) -> QueuedJob:
        result_json: dict[str, object] = record.result_json or {}
        return QueuedJob(
            job_id=record.id,
            job_kind=record.job_kind,
            project_id=record.project_id,
            workspace_id=record.workspace_id,
            status=JobStatus(record.status),
            attempt_count=record.attempt_count,
            error_summary=record.error_summary,
            resource_type=record.resource_type,
            resource_id=record.resource_id,
            result_summary=record.result_summary,
            site_url=str(result_json["site_url"]) if "site_url" in result_json else None,
            created_at=record.created_at,
            started_at=record.started_at,
            completed_at=record.completed_at,
            updated_at=record.updated_at,
        )

    def _api_token_model(
        self,
        record: ApiTokenRecord,
        raw_token: str | None = None,
    ) -> ApiTokenSummary:
        return ApiTokenSummary(
            id=record.id,
            workspace_id=record.workspace_id,
            user_id=record.user_id,
            label=record.label,
            token_prefix=record.token_prefix,
            scopes=list(record.scopes),
            created_at=record.created_at,
            last_used_at=record.last_used_at,
            revoked_at=record.revoked_at,
            token=raw_token,
        )


_service: DocumintService | None = None
_service_key: tuple[str, str] | None = None


def get_service() -> DocumintService:
    global _service, _service_key
    key = (str(settings.repo_root), settings.database_url)
    if _service is None or _service_key != key:
        _service = DocumintService(settings.repo_root)
        _service_key = key
    return _service


def reset_service() -> None:
    global _service, _service_key
    _service = None
    _service_key = None
    reset_db()
