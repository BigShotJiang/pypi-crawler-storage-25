"""
Agent file synthesis — generates and maintains CLAUDE.md, AGENTS.md, llms.txt
from a collection of .mint artifact files.

The synthesis problem: when a project has 20+ .mint files, we need to produce
a CLAUDE.md that is under 300 lines and covers what matters most.
Solution: relevance scoring based on recency, type, cross-reference count, drift status.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import structlog

from .mint import MintDocument

logger = structlog.get_logger(__name__)

# Target lengths to stay within context window budgets
CLAUDE_MD_TARGET_LINES = 280
AGENTS_MD_TARGET_LINES = 200
LLMS_TXT_TARGET_LINES = 80


@dataclass
class ArtifactScore:
    artifact: MintDocument
    score: float
    reasons: list[str]


TYPE_WEIGHTS = {
    "api_reference": 1.0,
    "mcp_reference": 0.9,
    "sdk_guides": 0.8,
    "migration_notes": 0.6,
    "changelog": 0.4,
    "unknown": 0.2,
}


def score_artifact(artifact: MintDocument, all_artifacts: list[MintDocument]) -> ArtifactScore:
    """Score an artifact's relevance for synthesis. Higher = include more detail."""
    score = 0.0
    reasons = []

    # Type weight
    artifact_type = artifact._artifact_type()
    type_weight = TYPE_WEIGHTS.get(artifact_type, 0.2)
    score += type_weight
    reasons.append(f"type={artifact_type}({type_weight:.1f})")

    # Drift status boost — stale artifacts need attention
    if artifact.drift_status == "STALE":
        score += 0.5
        reasons.append("drift=STALE(+0.5)")

    # Recency — decay over 30 days
    if artifact.generated_at:
        try:
            generated = datetime.fromisoformat(artifact.generated_at.replace("Z", "+00:00"))
            age_days = (datetime.now(UTC) - generated).days
            recency = max(0.0, 1.0 - age_days / 30)
            score += recency * 0.3
            reasons.append(f"recency={recency:.2f}(+{recency*0.3:.2f})")
        except (ValueError, TypeError):
            pass

    # Cross-reference count — how many other artifacts mention this one's symbols
    own_symbols = _get_symbol_names(artifact)
    if own_symbols:
        ref_count = sum(
            1 for other in all_artifacts
            if other is not artifact
            and any(sym in other.narrative for sym in own_symbols[:5])
        )
        cross_ref_boost = min(0.3, ref_count * 0.1)
        if cross_ref_boost > 0:
            score += cross_ref_boost
            reasons.append(f"cross_refs={ref_count}(+{cross_ref_boost:.2f})")

    # Symbol count — more exports = more important
    symbol_count = len(own_symbols)
    symbol_boost = min(0.2, symbol_count * 0.01)
    score += symbol_boost

    return ArtifactScore(artifact=artifact, score=round(score, 3), reasons=reasons)


def _get_symbol_names(artifact: MintDocument) -> list[str]:
    """Extract symbol names from LSIF-compact symbol list."""
    return [s.get("n", "") for s in artifact._export_symbols() if s.get("n")]


class AgentFileGenerator:
    """
    Synthesizes agent-readable files from a collection of .mint artifacts.

    Usage:
        gen = AgentFileGenerator()
        claude_md = gen.generate_claude_md(project_name="Cilow", artifacts=[...])
        agents_md = gen.generate_agents_md(project_name="Cilow", artifacts=[...])
        llms_txt = gen.generate_llms_txt(project_name="Cilow", base_url="https://cilow.ai", artifacts=[...])
    """

    def generate_claude_md(
        self,
        project_name: str,
        artifacts: list[MintDocument],
        project_description: str = "",
        repo_url: str = "",
    ) -> str:
        """Generate a synthesized CLAUDE.md under 300 lines."""
        scored = sorted(
            [score_artifact(a, artifacts) for a in artifacts],
            key=lambda x: x.score,
            reverse=True,
        )

        stale = [s for s in scored if s.artifact.drift_status == "STALE"]
        clean = [s for s in scored if s.artifact.drift_status != "STALE"]

        lines = [
            f"# {project_name}",
            "",
        ]
        if project_description:
            lines += [project_description, ""]

        # Freshness header — the drift-status signal for coding agents
        lines += [
            "<!-- DOCUMINT FRESHNESS — auto-maintained by documint.xyz -->",
            f"<!-- overall: {_freshness_pct(stale, len(artifacts))}% -->",
        ]
        if stale:
            for s in stale:
                title = s.artifact._title()
                lines.append(f"<!-- STALE: {title} — {s.artifact.drift_status} -->")
        lines.append("")

        # Top artifacts — full detail (symbols + api_schema + narrative summary)
        lines += ["## Key APIs & Context", ""]
        lines_used = len(lines)

        for scored_artifact in scored[:3]:
            art = scored_artifact.artifact
            title = art._title()
            artifact_type = art._artifact_type()

            lines += [f"### {title}", ""]

            # Agent context XML block
            lines += [art._agent_context_xml(), ""]

            # Symbol signatures
            symbol_names = _get_symbol_names(art)
            if symbol_names:
                lines += ["**Exports:** " + ", ".join(f"`{n}`" for n in symbol_names[:12]), ""]

            # API schema (truncated)
            if art.api_schema:
                lines += ["```", art.api_schema[:600].rstrip(), "```", ""]

            # Narrative (first 400 chars)
            if art.narrative:
                lines += [art.narrative[:400].rstrip(), ""]

            # Source files
            if art.source_files:
                lines += ["**Source:** " + " · ".join(f"`{f}`" for f in art.source_files[:4]), ""]

            # Drift status inline
            lines += [f"*Freshness: {art.drift_status} · hash: {art.codebase_hash[:12]}*", ""]
            lines_used = len(lines)

            if lines_used > CLAUDE_MD_TARGET_LINES - 40:
                break

        # Remaining artifacts — summary only
        if len(scored) > 3:
            lines += ["## Additional Artifacts", ""]
            for scored_artifact in scored[3:]:
                art = scored_artifact.artifact
                title = art._title()
                symbol_names = _get_symbol_names(art)
                sym_str = ", ".join(f"`{n}`" for n in symbol_names[:6])
                lines.append(f"- **{title}** ({art.drift_status}): {sym_str}")
                if len(lines) > CLAUDE_MD_TARGET_LINES - 10:
                    remaining = len(scored) - scored.index(scored_artifact) - 1
                    lines.append(
                        f"  _(+ {remaining} more — see .mint/ directory)_"
                    )
                    break
            lines.append("")

        # Agent instructions from top artifact
        if scored and scored[0].artifact.ai_context.get("instructions"):
            instructions = scored[0].artifact.ai_context.get("instructions", "")
            if isinstance(instructions, str) and instructions:
                lines += ["## Agent Instructions", "", instructions, ""]

        if repo_url:
            lines += ["## Repository", "", f"Source: {repo_url}", ""]

        return "\n".join(lines)

    def generate_agents_md(
        self,
        project_name: str,
        artifacts: list[MintDocument],
        project_description: str = "",
    ) -> str:
        """Generate AGENTS.md — simpler, less prescriptive than CLAUDE.md."""
        scored = sorted(
            [score_artifact(a, artifacts) for a in artifacts],
            key=lambda x: x.score,
            reverse=True,
        )

        lines = [
            f"# {project_name} — Agent Context",
            "",
        ]
        if project_description:
            lines += [project_description, ""]

        lines += ["## Available APIs", ""]
        for s in scored:
            art = s.artifact
            title = art._title()
            artifact_type = art._artifact_type()
            symbol_names = _get_symbol_names(art)

            lines += [f"### {title}", ""]
            if artifact_type:
                lines.append(f"Type: `{artifact_type}`")
            if symbol_names:
                lines.append("Exports: " + ", ".join(f"`{n}`" for n in symbol_names[:10]))
            if art.source_files:
                lines.append("Source: " + ", ".join(f"`{f}`" for f in art.source_files[:3]))
            if art.narrative:
                lines.append(art.narrative[:300].rstrip())
            lines.append(f"Status: {art.drift_status}")
            lines.append("")

            if len(lines) > AGENTS_MD_TARGET_LINES:
                remaining = len(scored) - scored.index(s) - 1
                if remaining > 0:
                    lines.append(f"_({remaining} more artifacts in .mint/ directory)_")
                break

        return "\n".join(lines)

    def generate_llms_txt(
        self,
        project_name: str,
        artifacts: list[MintDocument],
        base_url: str = "",
        project_description: str = "",
    ) -> str:
        """Generate /llms.txt per llmstxt.org spec."""
        lines = [
            f"# {project_name}",
            "",
        ]
        if project_description:
            lines += [f"> {project_description}", ""]

        lines.append("## Documentation")
        lines.append("")

        for art in artifacts:
            title = art._title()
            if art.links.get("readme"):
                url = art.links["readme"]
                if base_url and not url.startswith("http"):
                    url = base_url.rstrip("/") + "/" + url.lstrip("/")
                lines.append(f"- [{title}]({url})")
            else:
                lines.append(f"- {title}")

        lines.append("")
        if base_url:
            lines += [
                "## Optional",
                "",
                f"- [Full context]({base_url.rstrip('/')}/llms-full.txt)",
                f"- [API schema]({base_url.rstrip('/')}/openapi.json)",
            ]

        return "\n".join(lines)

    def generate_llms_full_txt(
        self,
        project_name: str,
        artifacts: list[MintDocument],
        project_description: str = "",
    ) -> str:
        """Generate /llms-full.txt — complete content for all artifacts."""
        lines = [f"# {project_name}", ""]
        if project_description:
            lines += [project_description, ""]

        for art in artifacts:
            lines.append(art.to_llms_full_txt())
            lines.append("")

        return "\n".join(lines)

    def write_to_directory(
        self,
        output_dir: Path,
        project_name: str,
        artifacts: list[MintDocument],
        project_description: str = "",
        repo_url: str = "",
        base_url: str = "",
    ) -> dict[str, Path]:
        """Write all agent files to a directory. Returns dict of filename -> path."""
        output_dir.mkdir(parents=True, exist_ok=True)
        written: dict[str, Path] = {}

        for filename, content in [
            ("CLAUDE.md", self.generate_claude_md(project_name, artifacts, project_description, repo_url)),
            ("AGENTS.md", self.generate_agents_md(project_name, artifacts, project_description)),
            ("llms.txt", self.generate_llms_txt(project_name, artifacts, base_url, project_description)),
            ("llms-full.txt", self.generate_llms_full_txt(project_name, artifacts, project_description)),
        ]:
            path = output_dir / filename
            path.write_text(content, encoding="utf-8")
            written[filename] = path

        logger.info("agent_files_written", dir=str(output_dir), files=list(written.keys()))
        return written


def _freshness_pct(stale: list[ArtifactScore], total: int) -> int:
    if total == 0:
        return 100
    return round((total - len(stale)) / total * 100)


_generator = AgentFileGenerator()


def get_agent_file_generator() -> AgentFileGenerator:
    return _generator
