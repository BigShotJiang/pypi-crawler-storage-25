"""Queue-backed job dispatch for Documint long-running workflows."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .config import settings
from .models import DriftJobRequest, PullRequestCreateRequest, QueuedJob
from .repository import get_service

_redis_settings_factory: Any = None

try:
    from arq import create_pool
    from arq.connections import RedisSettings

    _redis_settings_factory = RedisSettings
except ModuleNotFoundError:  # pragma: no cover - dependency is installed in runtime.
    create_pool = None  # type: ignore[assignment]

_pool: Any | None = None


def _redis_settings() -> Any:
    if _redis_settings_factory is None:
        raise RuntimeError("arq is not installed")
    return _redis_settings_factory.from_dsn(settings.redis_url)


async def get_arq_pool() -> Any:
    global _pool
    if _pool is None:
        if create_pool is None:
            raise RuntimeError("arq is not installed")
        _pool = await create_pool(_redis_settings())
    return _pool


async def close_arq_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
    _pool = None


def _drift_result_payload(result: Any) -> tuple[str, str | None, str, dict[str, object]]:
    return (
        "verification_run",
        str(result.id),
        f"{result.findings_count} findings returned.",
        {"run_id": result.id, "findings_count": result.findings_count},
    )


def _patch_result_payload(result: Any) -> tuple[str, str | None, str, dict[str, object]]:
    return (
        "doc_patch",
        str(result.id),
        str(result.summary),
        {"patch_id": result.id, "status": result.status},
    )


def _publish_result_payload(
    result: Any,
) -> tuple[str, str | None, str, dict[str, object]]:
    return (
        "publish_deployment",
        str(result.id),
        f"Published {result.docs_count} pages.",
        {"deployment_id": result.id, "docs_count": result.docs_count, "site_url": result.site_url},
    )


def _pull_request_result_payload(
    result: Any,
) -> tuple[str, str | None, str, dict[str, object]]:
    return (
        "pull_request",
        str(result.id),
        str(result.title),
        {"pull_request_id": result.id, "state": result.state, "patch_id": result.patch_id},
    )


def _installation_result_payload(
    result: Any,
) -> tuple[str, str | None, str, dict[str, object]]:
    count = len(result) if isinstance(result, list) else 0
    return (
        "installation_sync",
        None,
        f"{count} repositories synced.",
        {"repository_count": count},
    )


async def _enqueue_or_fail(function_name: str, payload: dict[str, object]) -> None:
    pool = await get_arq_pool()
    job = await pool.enqueue_job(function_name, payload)
    if job is None:
        get_service().mark_job_failed(
            str(payload["job_id"]),
            error_summary=f"Failed to enqueue {function_name}",
        )
        raise RuntimeError(f"Failed to enqueue {function_name}")


def _complete_job(
    job_id: str,
    result: Any,
    payload_builder: Callable[[Any], tuple[str, str | None, str, dict[str, object]]],
) -> QueuedJob:
    resource_type, resource_id, result_summary, result_json = payload_builder(result)
    return get_service().mark_job_completed(
        job_id,
        resource_type=resource_type,
        resource_id=resource_id,
        result_summary=result_summary,
        result_json=result_json,
    )


def _fail_job(job_id: str, exc: Exception) -> QueuedJob:
    return get_service().mark_job_failed(job_id, error_summary=str(exc))


async def _run_inline_job(
    *,
    job_id: str,
    runner: Callable[[], Any],
    payload_builder: Callable[[Any], tuple[str, str | None, str, dict[str, object]]],
) -> QueuedJob:
    get_service().mark_job_running(job_id)
    try:
        result = runner()
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, payload_builder)


async def dispatch_drift(
    request: DriftJobRequest,
    *,
    user_id: str | None = None,
) -> QueuedJob:
    payload = request.model_dump(mode="json")
    job = get_service().create_job(
        job_kind="drift",
        project_id=request.project_id,
        payload_json=payload,
        user_id=user_id,
    )
    if settings.job_execution_mode == "inline":
        return await _run_inline_job(
            job_id=job.job_id,
            runner=lambda: get_service().run_drift(request, user_id=user_id),
            payload_builder=_drift_result_payload,
        )
    await _enqueue_or_fail("run_drift_job", {**payload, "job_id": job.job_id, "user_id": user_id})
    return get_service().get_job(job.job_id, user_id=user_id)


async def dispatch_patch(
    *,
    project_id: str,
    finding_id: str | None = None,
    artifact_id: str | None = None,
    policy: str = "on_demand",
    user_id: str | None = None,
) -> QueuedJob:
    payload = {
        "project_id": project_id,
        "finding_id": finding_id,
        "artifact_id": artifact_id,
        "policy": policy,
    }
    job = get_service().create_job(
        job_kind="patch",
        project_id=project_id,
        payload_json=payload,
        user_id=user_id,
    )
    if settings.job_execution_mode == "inline":
        return await _run_inline_job(
            job_id=job.job_id,
            runner=lambda: get_service().generate_doc_patch(
                project_id=project_id,
                finding_id=finding_id,
                artifact_id=artifact_id,
                policy=policy,
                user_id=user_id,
            ),
            payload_builder=_patch_result_payload,
        )
    await _enqueue_or_fail("generate_patch_job", {**payload, "job_id": job.job_id, "user_id": user_id})
    return get_service().get_job(job.job_id, user_id=user_id)


async def dispatch_publish(project_id: str, *, user_id: str | None = None) -> QueuedJob:
    payload = {"project_id": project_id}
    job = get_service().create_job(
        job_kind="publish",
        project_id=project_id,
        payload_json=payload,
        user_id=user_id,
    )
    if settings.job_execution_mode == "inline":
        return await _run_inline_job(
            job_id=job.job_id,
            runner=lambda: get_service().publish_preview(project_id, user_id=user_id),
            payload_builder=_publish_result_payload,
        )
    await _enqueue_or_fail("publish_job", {**payload, "job_id": job.job_id, "user_id": user_id})
    return get_service().get_job(job.job_id, user_id=user_id)


async def dispatch_pull_request(
    *,
    project_id: str,
    patch_id: str,
    title: str | None,
    user_id: str | None = None,
) -> QueuedJob:
    payload = {"project_id": project_id, "patch_id": patch_id, "title": title}
    job = get_service().create_job(
        job_kind="pull_request",
        project_id=project_id,
        payload_json=payload,
        user_id=user_id,
    )
    if settings.job_execution_mode == "inline":
        return await _run_inline_job(
            job_id=job.job_id,
            runner=lambda: get_service().open_pull_request(
                project_id,
                patch_id,
                PullRequestCreateRequest(title=title),
                user_id=user_id,
            ),
            payload_builder=_pull_request_result_payload,
        )
    await _enqueue_or_fail(
        "open_pull_request_job",
        {**payload, "job_id": job.job_id, "user_id": user_id},
    )
    return get_service().get_job(job.job_id, user_id=user_id)


async def dispatch_installation_sync(
    installation_id: str,
    *,
    user_id: str | None = None,
) -> QueuedJob:
    workspace_id = get_service().get_installation_workspace_id(installation_id)
    payload = {"installation_id": installation_id}
    job = get_service().create_job(
        job_kind="installation_sync",
        workspace_id=workspace_id,
        payload_json=payload,
        user_id=user_id,
    )
    if settings.job_execution_mode == "inline":
        return await _run_inline_job(
            job_id=job.job_id,
            runner=lambda: get_service().sync_installation(
                installation_id, user_id=user_id
            ),
            payload_builder=_installation_result_payload,
        )
    await _enqueue_or_fail(
        "sync_installation_job",
        {**payload, "job_id": job.job_id, "user_id": user_id},
    )
    return get_service().get_job(job.job_id, user_id=user_id)


async def run_drift_job(ctx: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    del ctx
    job_id = str(payload["job_id"])
    user_id = payload.get("user_id")
    get_service().mark_job_running(job_id)
    try:
        result = get_service().run_drift(
            DriftJobRequest(
                project_id=str(payload["project_id"]),
                signal_type=payload.get("signal_type", "manual"),
                changed_files=payload.get("changed_files"),
            ),
            user_id=str(user_id) if isinstance(user_id, str) else None,
        )
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, _drift_result_payload).model_dump(mode="json")


async def generate_patch_job(
    ctx: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    del ctx
    job_id = str(payload["job_id"])
    user_id = payload.get("user_id")
    get_service().mark_job_running(job_id)
    try:
        result = get_service().generate_doc_patch(
            project_id=payload.get("project_id"),
            finding_id=payload.get("finding_id"),
            artifact_id=payload.get("artifact_id"),
            policy=str(payload.get("policy") or "on_demand"),
            user_id=str(user_id) if isinstance(user_id, str) else None,
        )
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, _patch_result_payload).model_dump(mode="json")


async def publish_job(ctx: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    del ctx
    job_id = str(payload["job_id"])
    user_id = payload.get("user_id")
    get_service().mark_job_running(job_id)
    try:
        result = get_service().publish_preview(
            str(payload["project_id"]),
            user_id=str(user_id) if isinstance(user_id, str) else None,
        )
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, _publish_result_payload).model_dump(mode="json")


async def open_pull_request_job(
    ctx: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    del ctx
    job_id = str(payload["job_id"])
    user_id = payload.get("user_id")
    get_service().mark_job_running(job_id)
    try:
        result = get_service().open_pull_request(
            str(payload["project_id"]),
            str(payload["patch_id"]),
            PullRequestCreateRequest(title=payload.get("title")),
            user_id=str(user_id) if isinstance(user_id, str) else None,
        )
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, _pull_request_result_payload).model_dump(
        mode="json"
    )


async def sync_installation_job(
    ctx: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    del ctx
    job_id = str(payload["job_id"])
    user_id = payload.get("user_id")
    get_service().mark_job_running(job_id)
    try:
        result = get_service().sync_installation(
            str(payload["installation_id"]),
            user_id=str(user_id) if isinstance(user_id, str) else None,
        )
    except Exception as exc:
        _fail_job(job_id, exc)
        raise
    return _complete_job(job_id, result, _installation_result_payload).model_dump(
        mode="json"
    )


class WorkerSettings:
    functions = [
        run_drift_job,
        generate_patch_job,
        publish_job,
        open_pull_request_job,
        sync_installation_job,
    ]
    redis_settings = _redis_settings() if _redis_settings_factory is not None else None
