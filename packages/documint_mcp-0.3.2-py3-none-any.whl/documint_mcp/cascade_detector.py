"""
Cross-artifact cascade detection.

When artifact A's symbols change, finds all other artifacts whose narrative or
api_schema text references those changed symbol names. These artifacts may need
secondary review even if their own source files didn't change.

Example: add_memory() changes in cilow-api.mint
→ cascade detector finds sdk-quickstart.mint mentions "add_memory"
→ secondary drift finding created for sdk-quickstart

No embeddings or ML needed — pure text search on exported symbol names.
O(n × m) where n=changed symbols, m=artifacts. Fast for <100 artifacts.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import structlog

from .mint import MintDocument

logger = structlog.get_logger(__name__)


@dataclass
class CascadeFinding:
    """An artifact that may need secondary review due to a symbol change in another artifact."""
    source_artifact_key: str          # the artifact whose symbols changed
    affected_artifact_key: str        # the artifact that references those symbols
    affected_symbol_names: list[str]  # which changed symbols appear in the affected artifact
    confidence: str = "MEDIUM"        # HIGH (>2 symbols) or MEDIUM (1-2 symbols)
    affected_sections: list[str] = field(default_factory=list)  # which narrative sections are affected


def find_cascades(
    changed_symbol_names: list[str],
    source_artifact_key: str,
    all_artifacts: list[MintDocument],
) -> list[CascadeFinding]:
    """
    Find all artifacts that reference changed symbols in their narrative or api_schema.

    Args:
        changed_symbol_names: Symbol names from the diff (e.g. ["add_memory", "MemoryEngine"])
        source_artifact_key:  The artifact whose symbols changed (excluded from results)
        all_artifacts:        All artifacts to search

    Returns:
        List of CascadeFinding objects, sorted by number of affected symbols desc
    """
    if not changed_symbol_names:
        return []

    cascades: list[CascadeFinding] = []

    for artifact in all_artifacts:
        # Resolve artifact key via helper so both LSIF and legacy formats work
        artifact_key = artifact._artifact_key()
        if artifact_key == source_artifact_key:
            continue

        # Search narrative and api_schema for changed symbol names
        search_text = (artifact.narrative or "") + "\n" + (artifact.api_schema or "")

        affected_symbols = [
            sym for sym in changed_symbol_names
            if _symbol_mentioned(sym, search_text)
        ]

        if not affected_symbols:
            continue

        # Identify which narrative sections (by heading) contain the references
        affected_sections = _find_affected_sections(affected_symbols, artifact.narrative or "")

        confidence = "HIGH" if len(affected_symbols) > 2 else "MEDIUM"

        cascades.append(CascadeFinding(
            source_artifact_key=source_artifact_key,
            affected_artifact_key=artifact_key,
            affected_symbol_names=affected_symbols,
            confidence=confidence,
            affected_sections=affected_sections,
        ))

        logger.info(
            "cascade_found",
            source=source_artifact_key,
            affected=artifact_key,
            symbols=affected_symbols,
            confidence=confidence,
        )

    # Sort by number of affected symbols (most affected first)
    return sorted(cascades, key=lambda c: len(c.affected_symbol_names), reverse=True)


def _symbol_mentioned(symbol_name: str, text: str) -> bool:
    """Check if a symbol name appears as a word boundary in text."""
    if not symbol_name or not text:
        return False
    # Word-boundary heuristic: symbol must be preceded/followed by non-word chars
    pattern = r'\b' + re.escape(symbol_name) + r'\b'
    return bool(re.search(pattern, text))


def _find_affected_sections(symbol_names: list[str], narrative: str) -> list[str]:
    """Find which markdown sections (## headings) contain the affected symbols."""
    if not narrative or not symbol_names:
        return []

    sections: list[str] = []
    current_section = "Introduction"

    for line in narrative.splitlines():
        if line.startswith("#"):
            current_section = line.lstrip("#").strip()
        else:
            for sym in symbol_names:
                if sym in line and current_section not in sections:
                    sections.append(current_section)
                    break

    return sections
