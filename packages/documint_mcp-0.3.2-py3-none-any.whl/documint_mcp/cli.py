"""CLI entrypoint for hosted Documint workflows."""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import signal
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast
from urllib.parse import parse_qs, urlparse

import httpx

from . import cli_ui as ui
from .config import settings

CLI_CONFIG_PATH = Path.home() / ".documint" / "cli.json"

# When True, suppress formatted output and emit raw JSON only.
_JSON_MODE = False

# Watch state debounce: avoid N disk writes during batch operations.
_watch_state_dirty = False
_watch_last_save: float = 0.0

# Known subcommand names for natural-language detection bypass.
_KNOWN_COMMANDS = frozenset({
    "init", "signup", "login", "workspaces", "projects", "scan", "drift", "patches",
    "publish", "traces", "db", "worker", "mint-generate", "mint-export",
    "watch", "ci", "coverage", "propose", "preview", "trace", "chat", "bootstrap",
})


def _is_tty() -> bool:
    """Return True when stdout is a TTY and JSON mode is not forced."""
    return not _JSON_MODE and hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _emit(payload: Any) -> None:
    """Emit raw JSON to stdout (always, for test compatibility)."""
    print(json.dumps(payload, indent=2))


def _load_cli_config() -> dict[str, Any]:
    if not CLI_CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CLI_CONFIG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _save_cli_config(payload: dict[str, Any]) -> None:
    CLI_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CLI_CONFIG_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _api_url(args: argparse.Namespace) -> str:
    config = _load_cli_config()
    return str(
        getattr(args, "api_url", None)
        or config.get("api_url")
        or os.getenv("DOCUMINT_API_URL")
        or settings.api_base_url
    ).rstrip("/")


def _token(args: argparse.Namespace) -> str | None:
    config = _load_cli_config()
    explicit = getattr(args, "token", None)
    return (
        explicit
        or config.get("token")
        or os.getenv("DOCUMINT_TOKEN")
        or os.getenv("DOCUMINT_AUTH_TOKEN")
        or settings.auth_token
    )


def _headers(args: argparse.Namespace) -> dict[str, str]:
    token = _token(args)
    if not token:
        return {}
    return {"Authorization": f"Bearer {token}"}


def _request(
    args: argparse.Namespace,
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
) -> Any:
    try:
        with httpx.Client(timeout=20.0) as client:
            response = client.request(
                method,
                f"{_api_url(args)}{path}",
                headers=_headers(args),
                json=json_body,
            )
            response.raise_for_status()
            return response.json()
    except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError):
        return _local_request(method, path, json_body=json_body)


def _local_request(
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
) -> Any:
    from fastapi.encoders import jsonable_encoder

    from .models import DriftJobRequest, ProjectCreateRequest
    from .repository import get_service

    service = get_service()
    parsed = urlparse(path)
    route = parsed.path
    query = parse_qs(parsed.query)
    if method == "GET" and route.startswith("/projects/"):
        project_id = route.rsplit("/", 1)[-1]
        return jsonable_encoder(service.get_project(project_id))
    if method == "GET" and route == "/workspaces":
        return jsonable_encoder(service.list_workspaces())
    if method == "POST" and route == "/admin/bootstrap-self":
        return jsonable_encoder(service.bootstrap_self())
    if method == "GET" and route == "/projects":
        workspace_id = query.get("workspace_id", [None])[0]
        return jsonable_encoder(service.list_projects(workspace_id))
    if (
        method == "GET"
        and route.startswith("/integrations/github/installations/")
        and route.endswith("/repositories")
    ):
        installation_id = route.split("/")[3]
        return jsonable_encoder(service.list_installation_repositories(installation_id))
    if (
        method == "POST"
        and route.startswith("/integrations/github/installations/")
        and route.endswith("/sync")
    ):
        installation_id = route.split("/")[3]
        return jsonable_encoder(service.sync_installation(installation_id))
    if method == "POST" and route == "/projects" and json_body is not None:
        return jsonable_encoder(
            service.create_project(ProjectCreateRequest(**json_body))
        )
    if method == "POST" and route == "/jobs/drift" and json_body is not None:
        return jsonable_encoder(service.run_drift(DriftJobRequest(**json_body)))
    if method == "POST" and route == "/jobs/publish" and json_body is not None:
        return jsonable_encoder(service.publish_preview(str(json_body["project_id"])))
    if method == "GET" and route.startswith("/artifacts/") and route.endswith("/trace"):
        artifact_id = route.split("/")[2]
        project_id = (
            query.get("project_id", [settings.project_id])[0] or settings.project_id
        )
        return jsonable_encoder(service.get_artifact_trace(artifact_id, project_id))
    if method == "POST" and "/findings/" in route and route.endswith("/patch"):
        parts = route.strip("/").split("/")
        project_id = parts[1]
        finding_id = parts[3]
        policy = str((json_body or {}).get("policy", "on_demand"))
        return jsonable_encoder(
            service.generate_doc_patch(
                project_id=project_id, finding_id=finding_id, policy=policy
            )
        )
    if method == "POST" and route == "/mcp" and json_body is not None:
        params = json_body.get("params", {})
        arguments = params.get("arguments", {}) if isinstance(params, dict) else {}
        if params.get("name") == "generate_doc_patch" and isinstance(arguments, dict):
            return {
                "result": {
                    "structuredContent": jsonable_encoder(
                        service.generate_doc_patch(
                            project_id=arguments.get("project_id"),
                            artifact_id=arguments.get("artifact_id"),
                            finding_id=arguments.get("finding_id"),
                            policy=arguments.get("policy", "on_demand"),
                        )
                    )
                }
            }
    if _is_tty():
        ui.friendly_error(
            f"Unsupported local fallback: {method} {path}",
            hint="This command requires the Documint API. Start the server with: documint-server",
        )
        raise SystemExit(1)
    raise RuntimeError(f"Unsupported local CLI fallback request: {method} {path}")


def build_parser() -> argparse.ArgumentParser:
    """Create the top-level Documint CLI parser."""

    parser = argparse.ArgumentParser(
        prog="documint",
        description="Documint CLI for hosted repo-native docs operations.",
    )
    parser.add_argument(
        "--api-url",
        help="Override the API base URL used by the CLI.",
    )
    parser.add_argument(
        "--token",
        help="Override the API token used by the CLI.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        dest="json_mode",
        help="Force raw JSON output (no formatted display).",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser(
        "init",
        help="Set up Documint in the current repo. Run this first.",
    )

    signup_parser = subparsers.add_parser(
        "signup",
        help="Join the Documint waitlist.",
    )
    signup_parser.add_argument("--email", required=True, help="Your email address.")

    login_parser = subparsers.add_parser(
        "login",
        help="Exchange the current operator token for a scoped CLI token and store it locally.",
    )
    login_parser.add_argument(
        "--workspace-id",
        default=settings.default_workspace_id,
        help="Workspace id to mint the CLI token for.",
    )
    login_parser.add_argument(
        "--label",
        default="CLI token",
        help="Friendly label for the stored CLI token.",
    )

    workspaces_parser = subparsers.add_parser(
        "workspaces", help="Workspace operations."
    )
    workspaces_subparsers = workspaces_parser.add_subparsers(
        dest="workspaces_command", required=True
    )
    workspaces_subparsers.add_parser("list", help="List available workspaces.")
    workspaces_subparsers.add_parser(
        "bootstrap-self",
        help="Explicitly seed the self-dogfood workspace, project, and installation metadata.",
    )

    projects_parser = subparsers.add_parser("projects", help="Project operations.")
    projects_subparsers = projects_parser.add_subparsers(
        dest="projects_command", required=True
    )
    projects_list = projects_subparsers.add_parser("list", help="List projects.")
    projects_list.add_argument("--workspace-id", help="Optional workspace id filter.")
    projects_create = projects_subparsers.add_parser(
        "create", help="Create a hosted project connected to a GitHub repo."
    )
    projects_create.add_argument("--workspace-id", required=True)
    projects_create.add_argument("--name", required=True)
    projects_create.add_argument("--slug")
    projects_create.add_argument("--description", default="")
    projects_create.add_argument("--owner", required=True)
    projects_create.add_argument("--repo", required=True)
    projects_create.add_argument("--default-branch", default="main")

    scan_parser = subparsers.add_parser(
        "scan",
        help="Return the current project snapshot and artifact verification state.",
    )
    scan_parser.add_argument("--project-id", default=settings.project_id)

    drift_parser = subparsers.add_parser(
        "drift",
        help="Run the doc drift detector for a project.",
    )
    drift_parser.add_argument("--project-id", default=settings.project_id)
    drift_parser.add_argument(
        "--signal-type",
        default="manual",
        choices=["manual", "push", "pull_request", "release"],
    )
    drift_parser.add_argument(
        "--changed-file",
        action="append",
        default=[],
        help="Changed file path to scope findings. Repeat for multiple files.",
    )

    patches_parser = subparsers.add_parser("patches", help="Patch drafting operations.")
    patches_subparsers = patches_parser.add_subparsers(
        dest="patches_command", required=True
    )
    patches_propose = patches_subparsers.add_parser(
        "propose",
        help="Generate a reviewable doc patch proposal for a finding or artifact.",
    )
    patches_propose.add_argument("--project-id", default=settings.project_id)
    patches_propose.add_argument("--artifact-id")
    patches_propose.add_argument("--finding-id")
    patches_propose.add_argument("--policy", default="on_demand")

    publish_parser = subparsers.add_parser(
        "publish",
        help="Create or refresh a hosted publish deployment.",
    )
    publish_parser.add_argument("--project-id", default=settings.project_id)

    traces_parser = subparsers.add_parser("traces", help="Artifact trace operations.")
    traces_subparsers = traces_parser.add_subparsers(
        dest="traces_command", required=True
    )
    traces_show = traces_subparsers.add_parser(
        "show", help="Explain which repository paths drive a documentation artifact."
    )
    traces_show.add_argument("artifact_id")
    traces_show.add_argument("--project-id", default=settings.project_id)

    db_parser = subparsers.add_parser("db", help="Database and migration operations.")
    db_subparsers = db_parser.add_subparsers(dest="db_command", required=True)
    db_subparsers.add_parser(
        "upgrade", help="Apply Alembic migrations to the configured database."
    )

    subparsers.add_parser(
        "worker",
        help="Run the ARQ worker for queued drift, patch, publish, PR, and installation jobs.",
    )

    mint_generate_parser = subparsers.add_parser(
        "mint-generate",
        help="Generate .mint files for all artifact traces in a project.",
    )
    mint_generate_parser.add_argument("project_id", help="Project ID or slug")
    mint_generate_parser.add_argument(
        "--output",
        "-o",
        default=".mint",
        help="Output directory (default: .mint)",
    )

    mint_export_parser = subparsers.add_parser(
        "mint-export",
        help="Export a .mint file to CLAUDE.md, llms.txt, or AGENTS.md.",
    )
    mint_export_parser.add_argument("mint_file", help="Path to .mint file")
    mint_export_parser.add_argument(
        "--format",
        "-f",
        dest="fmt",
        default="claude",
        choices=["claude", "llms", "agents", "api-ref"],
        help="Export format: claude|llms|agents|api-ref (default: claude)",
    )
    mint_export_parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="Output file path",
    )

    watch_parser = subparsers.add_parser(
        "watch",
        help="Watch source files for symbol changes and report documentation drift in real time.",
    )
    watch_parser.add_argument(
        "--poll-interval",
        type=float,
        default=2.0,
        help="Polling interval in seconds when watchdog is not available (default: 2.0).",
    )

    ci_parser = subparsers.add_parser(
        "ci",
        help="Non-interactive drift check for CI pipelines.",
    )
    ci_parser.add_argument("--project-id", default=settings.project_id)
    ci_parser.add_argument(
        "--fail-on-high",
        action="store_true",
        default=False,
        help="Exit 1 only if HIGH severity findings are present.",
    )
    ci_parser.add_argument(
        "--fail-on-any",
        action="store_true",
        default=False,
        help="Exit 1 if any findings are found.",
    )
    ci_parser.add_argument(
        "--format",
        dest="ci_format",
        default="text",
        choices=["text", "json", "github"],
        help="Output format: text, json, or github (GitHub Actions step summary).",
    )

    subparsers.add_parser(
        "coverage",
        help="Show documentation coverage — what percentage of symbols are documented.",
    )

    propose_parser = subparsers.add_parser(
        "propose",
        help="Compatibility alias for `patches propose`.",
    )
    propose_parser.add_argument("--project-id", default=settings.project_id)
    propose_parser.add_argument("--artifact-id")
    propose_parser.add_argument("--finding-id")
    propose_parser.add_argument("--policy", default="on_demand")

    preview_parser = subparsers.add_parser(
        "preview",
        help="Compatibility alias for `publish`.",
    )
    preview_parser.add_argument("--project-id", default=settings.project_id)

    trace_parser = subparsers.add_parser(
        "trace",
        help="Compatibility alias for `traces show`.",
    )
    trace_parser.add_argument("artifact_id")
    trace_parser.add_argument("--project-id", default=settings.project_id)

    subparsers.add_parser("chat", help="Interactive conversation mode.")

    bootstrap_parser = subparsers.add_parser(
        "bootstrap", help="Bootstrap .mint intelligence layer from git history."
    )
    bootstrap_parser.add_argument("--repo", default=".", help="Path to git repo (default: .)")
    bootstrap_parser.add_argument(
        "--out", default="documint.intelligence.json", help="Output path for intelligence JSON"
    )
    bootstrap_parser.add_argument(
        "--enrich", action="store_true", help="Run Claude enrichment pass after bootstrap"
    )

    return parser


def _handle_natural_language(query: str) -> int:
    """Route a natural-language query to the appropriate command."""
    global _JSON_MODE  # noqa: PLW0603
    # In NL mode, use formatted output only when stdout is a TTY.
    if not (hasattr(sys.stdout, "isatty") and sys.stdout.isatty()):
        _JSON_MODE = True

    ui.print_banner()
    print(ui.c(ui.MAGENTA, f'  "{query}"'), file=sys.stderr)
    print(file=sys.stderr)

    intent = ui.detect_intent(query)
    if intent is None:
        ui.print_intent_help()
        return 0

    print(ui.info(f"Detected intent: {intent}"), file=sys.stderr)
    print(file=sys.stderr)

    # Build a minimal args namespace and dispatch
    parser = build_parser()
    try:
        args = parser.parse_args([intent])
    except SystemExit:
        ui.print_intent_help()
        return 0

    return _dispatch(args, parser)


def _run_repl() -> int:
    """Interactive conversation-mode REPL."""
    ui.print_banner_full()
    print("  Type a question, use /commands, or Ctrl+C to exit.", file=sys.stderr)
    print(file=sys.stderr)

    parser = build_parser()

    while True:
        try:
            line = input(ui.c(ui.MINT_2, "documint > ") if _is_tty() else "documint > ")
        except (KeyboardInterrupt, EOFError):
            print(file=sys.stderr)
            print(ui.info("Goodbye."), file=sys.stderr)
            return 0

        line = line.strip()
        if not line:
            continue

        if line.startswith("/"):
            cmd = line.split()[0].lower()
            if cmd in {"/quit", "/exit"}:
                print(ui.info("Goodbye."), file=sys.stderr)
                return 0
            if cmd == "/help":
                ui.print_slash_help()
                continue
            if cmd == "/drift":
                try:
                    args = parser.parse_args(["drift"])
                    _dispatch(args, parser)
                except SystemExit:
                    pass
                continue
            if cmd == "/coverage":
                _run_coverage()
                continue
            if cmd == "/watch":
                try:
                    args = parser.parse_args(["watch"])
                    _dispatch(args, parser)
                except SystemExit:
                    pass
                continue
            if cmd == "/scan":
                try:
                    args = parser.parse_args(["scan"])
                    _dispatch(args, parser)
                except SystemExit:
                    pass
                continue
            if cmd in {"/patch", "/propose"}:
                print(ui.info("Usage: /patch requires --finding-id or --artifact-id"), file=sys.stderr)
                print(ui.info("  Example: documint propose --artifact-id mcp-reference"), file=sys.stderr)
                continue
            if cmd == "/status":
                try:
                    args = parser.parse_args(["scan"])
                    _dispatch(args, parser)
                except SystemExit:
                    pass
                continue
            print(ui.warn(f"Unknown command: {cmd}. Type /help for a list."), file=sys.stderr)
            continue

        # Natural language routing
        intent = ui.detect_intent(line)
        if intent is None:
            ui.print_intent_help()
            continue

        print(ui.info(f"Detected intent: {intent}"), file=sys.stderr)
        try:
            args = parser.parse_args([intent])
            _dispatch(args, parser)
        except SystemExit:
            pass

    return 0


def _run_init() -> int:
    """Interactive first-run setup: email → trivia → token → saved config."""
    import urllib.request as _req
    import json as _json

    API_URL = "https://api-production-285b.up.railway.app"

    print("\n  Welcome to Documint.\n")
    print("  We'll get you set up in about 60 seconds.\n")

    # Step 1 — email
    try:
        email = input("  Your email: ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print()
        return 0
    if not email or "@" not in email:
        print("\n  ✗ Need a valid email.\n")
        return 1

    # Step 2 — trivia (Look and Say sequence)
    print()
    print("  One quick question to confirm you're an engineer:\n")
    print("  What comes next in this sequence?")
    print()
    print("  1, 11, 21, 1211, 111221, ___\n")
    try:
        answer = input("  Answer: ").strip().replace(" ", "")
    except (KeyboardInterrupt, EOFError):
        print()
        return 0

    # Step 3 — call /early-access
    payload = _json.dumps({"email": email, "answer": answer}).encode()
    request = _req.Request(
        f"{API_URL}/early-access",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with _req.urlopen(request, timeout=10) as resp:
            result = _json.loads(resp.read())
    except Exception:
        print("\n  ✗ Could not reach the Documint API. Check your connection.\n")
        return 1

    status = result.get("status")

    if status == "waitlisted":
        print()
        print("  Not quite — but you're on the waitlist.")
        print(f"  We'll email {email} when your access is ready.\n")
        return 0

    if status != "access_granted":
        print(f"\n  ✗ Unexpected response: {result.get('message', status)}\n")
        return 1

    token = result.get("token", "")

    # Step 4 — detect repo name from cwd
    repo_name = Path.cwd().name

    # Step 5 — save config
    _save_cli_config({
        "api_url": API_URL,
        "token": token,
        "email": email,
        "repo": repo_name,
    })

    print()
    print("  ✓ Access granted. You're in.\n")
    print(f"  Token saved to ~/.documint/cli.json")
    print()
    print("  What to do next:\n")
    print(f"    documint scan       # snapshot {repo_name}")
    print( "    documint watch      # live drift detection")
    print( "    documint drift      # find stale docs")
    print( "    documint propose    # AI patch for stale docs")
    print()
    return 0


def _dispatch(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    """Dispatch parsed args to the appropriate command handler."""
    if args.command == "init":
        return _run_init()

    if args.command == "signup":
        import urllib.request as _urllib_request
        import json as _json
        email = args.email.strip().lower()
        api_url = _api_url(args).rstrip("/")
        req = _urllib_request.Request(
            f"{api_url}/waitlist",
            data=_json.dumps({"email": email, "source": "cli"}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with _urllib_request.urlopen(req, timeout=10) as resp:
                result = _json.loads(resp.read())
            msg = result.get("message", "You're on the list!")
            print(f"\n\u2713 {msg}")
            print(f"  We'll email {email} when your account is ready.\n")
        except Exception:
            print(f"\n✓ Signed up! We'll reach out to {email} soon.\n")
        return 0

    if args.command == "login":
        payload = _request(
            args,
            "POST",
            "/auth/cli/exchange",
            json_body={
                "workspace_id": args.workspace_id,
                "label": args.label,
                "scopes": ["projects:read", "projects:write", "mcp:read"],
            },
        )
        _save_cli_config(
            {
                "api_url": _api_url(args),
                "workspace_id": args.workspace_id,
                "token": payload.get("token"),
                "token_prefix": payload.get("token_prefix"),
            }
        )
        _emit(payload)
        return 0

    if args.command == "workspaces" and args.workspaces_command == "list":
        _emit(_request(args, "GET", "/workspaces"))
        return 0
    if args.command == "workspaces" and args.workspaces_command == "bootstrap-self":
        _emit(_local_request("POST", "/admin/bootstrap-self"))
        return 0

    if args.command == "projects":
        if args.projects_command == "list":
            suffix = (
                f"/projects?workspace_id={args.workspace_id}"
                if args.workspace_id
                else "/projects"
            )
            _emit(_request(args, "GET", suffix))
            return 0
        if args.projects_command == "create":
            _emit(
                _request(
                    args,
                    "POST",
                    "/projects",
                    json_body={
                        "workspace_id": args.workspace_id,
                        "name": args.name,
                        "slug": args.slug,
                        "description": args.description,
                        "owner": args.owner,
                        "repo": args.repo,
                        "default_branch": args.default_branch,
                    },
                )
            )
            return 0

    if args.command == "scan":
        if _is_tty():
            with ui.Spinner("Scanning project snapshot"):
                result = _request(args, "GET", f"/projects/{args.project_id}")
        else:
            result = _request(args, "GET", f"/projects/{args.project_id}")
        _emit(result)
        if _is_tty():
            artifacts = result.get("artifacts", [])
            findings = result.get("findings", [])
            print(ui.ok(f"{len(artifacts)} artifacts, {len(findings)} findings"), file=sys.stderr)
            if artifacts:
                rows = []
                for a in artifacts:
                    name = str(a.get("artifact_key", a.get("id", "?")))
                    status = str(a.get("status", "unknown"))
                    verified = str(a.get("last_verified", "never"))
                    status_display = ui.ok(status) if status.lower() in ("fresh", "ok") else ui.warn(status)
                    rows.append([name, status_display, verified])
                print(file=sys.stderr)
                print(ui.table(["Artifact", "Status", "Last Verified"], rows), file=sys.stderr)
            print(file=sys.stderr)
            ui.suggest_next("scan")
        return 0

    if args.command == "drift":
        if _is_tty():
            with ui.Spinner("Scanning for documentation drift"):
                result = _request(
                    args,
                    "POST",
                    "/jobs/drift",
                    json_body={
                        "project_id": args.project_id,
                        "signal_type": args.signal_type,
                        "changed_files": args.changed_file,
                    },
                )
        else:
            result = _request(
                args,
                "POST",
                "/jobs/drift",
                json_body={
                    "project_id": args.project_id,
                    "signal_type": args.signal_type,
                    "changed_files": args.changed_file,
                },
            )
        _emit(result)
        if _is_tty():
            findings = result.get("findings", [])
            if findings:
                print(ui.warn(f"{len(findings)} drift finding(s)"), file=sys.stderr)
                for f in findings:
                    sev = ui.severity_badge(str(f.get("severity", "?")))
                    print(f"    {sev}  {f.get('artifact_id', '?')}: {f.get('summary', '')}", file=sys.stderr)
            else:
                print(ui.ok("No drift detected -- docs are fresh."), file=sys.stderr)
            print(file=sys.stderr)
            ui.suggest_next("drift")
        return 0

    if args.command == "ci":
        return _run_ci(args)

    if args.command == "coverage":
        return _run_coverage()

    if args.command == "propose" or (
        args.command == "patches" and args.patches_command == "propose"
    ):
        if not args.artifact_id and not args.finding_id:
            parser.error("patch generation requires --artifact-id or --finding-id")

        if _is_tty():
            print(ui.step(1, 4, "Characterizing code changes..."), file=sys.stderr)

        if args.finding_id:
            if _is_tty():
                print(ui.step(2, 4, "Identifying stale sections..."), file=sys.stderr)
                print(ui.step(3, 4, "Drafting surgical patch..."), file=sys.stderr)
                with ui.Spinner("Generating patch"):
                    result = _request(
                        args,
                        "POST",
                        f"/projects/{args.project_id}/findings/{args.finding_id}/patch",
                        json_body={"policy": args.policy},
                    )
                print(ui.step(4, 4, "Verifying patch accuracy..."), file=sys.stderr)
            else:
                result = _request(
                    args,
                    "POST",
                    f"/projects/{args.project_id}/findings/{args.finding_id}/patch",
                    json_body={"policy": args.policy},
                )
            _emit(result)
            if _is_tty():
                _display_propose_result(result)
            _append_changelog(args, result)
            return 0

        if _is_tty():
            print(ui.step(2, 4, "Identifying stale sections..."), file=sys.stderr)
            print(ui.step(3, 4, "Drafting surgical patch..."), file=sys.stderr)
            with ui.Spinner("Generating patch"):
                result = _request(
                    args,
                    "POST",
                    "/mcp",
                    json_body={
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "tools/call",
                        "params": {
                            "name": "generate_doc_patch",
                            "arguments": {
                                "project_id": args.project_id,
                                "artifact_id": args.artifact_id,
                                "policy": args.policy,
                            },
                        },
                    },
                )["result"]["structuredContent"]
            print(ui.step(4, 4, "Verifying patch accuracy..."), file=sys.stderr)
        else:
            result = _request(
                args,
                "POST",
                "/mcp",
                json_body={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/call",
                    "params": {
                        "name": "generate_doc_patch",
                        "arguments": {
                            "project_id": args.project_id,
                            "artifact_id": args.artifact_id,
                            "policy": args.policy,
                        },
                    },
                },
            )["result"]["structuredContent"]
        _emit(result)
        if _is_tty():
            _display_propose_result(result)
        _append_changelog(args, result)
        return 0

    if args.command in {"publish", "preview"}:
        if _is_tty():
            with ui.Spinner("Publishing documentation"):
                result = _request(
                    args,
                    "POST",
                    "/jobs/publish",
                    json_body={"project_id": args.project_id},
                )
        else:
            result = _request(
                args,
                "POST",
                "/jobs/publish",
                json_body={"project_id": args.project_id},
            )
        _emit(result)
        if _is_tty():
            site_url = result.get("site_url", "")
            if site_url:
                print(ui.ok(f"Published: {site_url}"), file=sys.stderr)
            else:
                print(ui.ok("Published successfully."), file=sys.stderr)
        return 0

    if args.command == "trace" or (
        args.command == "traces" and args.traces_command == "show"
    ):
        _emit(
            _request(
                args,
                "GET",
                f"/artifacts/{args.artifact_id}/trace?project_id={args.project_id}",
            )
        )
        return 0

    if args.command == "db" and args.db_command == "upgrade":
        from alembic.config import Config

        from alembic import command

        alembic_config = Config(str(settings.repo_root / "alembic.ini"))
        command.upgrade(alembic_config, "head")
        _emit(
            {"status": "ok", "migration": "head", "database_url": settings.database_url}
        )
        return 0

    if args.command == "worker":
        from arq import run_worker

        from .jobs import WorkerSettings

        run_worker(cast(Any, WorkerSettings))
        return 0

    if args.command == "mint-generate":
        from documint_mcp.mint import MintDocument

        output = Path(args.output)
        print(f"Generating .mint files for project {args.project_id} → {output}/")
        doc = MintDocument.from_artifact_trace(
            artifact_key=f"{args.project_id}-overview",
            artifact_type="overview",
            title=f"Project {args.project_id} Overview",
            source_files=[],
            narrative_md=f"# {args.project_id}\n\nGenerated by Documint.\n",
        )
        output.mkdir(parents=True, exist_ok=True)
        out_path = output / f"{args.project_id}-overview.mint"
        doc.to_file(out_path)
        print(f"Written: {out_path}")
        print(f"  Compression ratio: {doc.compression_ratio():.2f}")
        return 0

    if args.command == "watch":
        return _run_watch(args)

    if args.command == "mint-export":
        from documint_mcp.mint import MintDocument

        mint_file = Path(args.mint_file)
        doc = MintDocument.from_file(mint_file)
        if args.fmt == "claude":
            content = doc.to_claude_md()
            default_name = "CLAUDE.md"
        elif args.fmt == "llms":
            content = doc.to_llms_txt()
            default_name = "llms.txt"
        elif args.fmt == "api-ref":
            content = doc.to_api_reference()
            default_name = "API.md"
        else:
            content = doc.to_agents_md()
            default_name = "AGENTS.md"
        out_path = Path(args.output) if args.output else Path(default_name)
        out_path.write_text(content)
        print(f"Exported to {out_path}")
        return 0

    if args.command == "chat":
        return _run_repl()

    if args.command == "bootstrap":
        return _cmd_bootstrap(args)

    parser.error(f"Unsupported command: {args.command}")
    return 2


def _cmd_bootstrap(args: argparse.Namespace) -> int:
    """Bootstrap .mint intelligence layer from git history."""
    import asyncio
    import json as _json
    import subprocess as _subprocess
    from pathlib import Path as _Path
    from .git_bootstrap import bootstrap_from_repo

    repo_path = _Path(getattr(args, "repo", ".")).expanduser().resolve()
    out_path = _Path(getattr(args, "out", "documint.intelligence.json"))
    do_enrich = getattr(args, "enrich", False)

    result = _subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        cwd=repo_path,
        capture_output=True,
    )
    if result.returncode != 0:
        print(f"[error] {repo_path} is not a git repository")
        return 1

    print(f"[bootstrap] analyzing git history at {repo_path} ...")
    layer = bootstrap_from_repo(repo_path)

    print(
        f"[bootstrap] {layer.total_commits_analyzed} commits analyzed\n"
        f"  history:   {len(layer.history)} entries\n"
        f"  fixed:     {len(layer.fixed)} entries\n"
        f"  decisions: {len(layer.decisions)} entries\n"
        f"  state:     {len(layer.state)} areas\n"
        f"  pending enrichment: {layer.pending_enrichment_count()}"
    )

    if do_enrich:
        try:
            from .config import settings
            api_key = getattr(settings, "anthropic_api_key", None)
        except Exception:
            api_key = None

        if not api_key:
            print("[warn] ANTHROPIC_API_KEY not set — skipping enrichment")
        else:
            from .intelligence_enricher import enrich_layer_background

            print("[bootstrap] enriching with Claude haiku ...")
            total = layer.pending_enrichment_count()

            def _progress(done: int, total_count: int) -> None:
                print(f"  enriched {done}/{total_count}", end="\r", flush=True)

            layer = asyncio.run(
                enrich_layer_background(
                    layer,
                    repo_path=str(repo_path),
                    api_key=api_key,
                    on_progress=_progress,
                )
            )
            print(f"\n[bootstrap] enrichment complete — {total} entries enriched")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(_json.dumps(layer.to_dict(), indent=2))
    print(f"[bootstrap] written to {out_path}")
    print(
        "[bootstrap] next: add this to your .mint file with "
        "`documint mint --with-intelligence documint.intelligence.json`"
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    """Run the Documint CLI."""
    global _JSON_MODE  # noqa: PLW0603
    _JSON_MODE = False  # reset for each invocation (test isolation)

    raw_args = argv if argv is not None else sys.argv[1:]

    # Natural language catch-all: if first arg isn't a known command or flag,
    # treat the entire input as a natural language query.
    if raw_args and raw_args[0] not in _KNOWN_COMMANDS and not raw_args[0].startswith("-"):
        return _handle_natural_language(" ".join(raw_args))

    parser = build_parser()
    args = parser.parse_args(argv)

    # Apply --json flag: explicit --json, or non-TTY stdout
    if getattr(args, "json_mode", False):
        _JSON_MODE = True
    elif not (hasattr(sys.stdout, "isatty") and sys.stdout.isatty()):
        _JSON_MODE = True

    # Print banner for interactive (TTY) commands, but not CI
    if _is_tty() and args.command != "ci":
        ui.print_banner()

    return _dispatch(args, parser)


# ---------------------------------------------------------------------------
# Propose display helper
# ---------------------------------------------------------------------------


def _display_propose_result(result: dict[str, Any]) -> None:
    """Display a formatted patch proposal when running in TTY mode."""
    summary = result.get("summary", "Patch generated.")
    target = result.get("target_path", "")
    artifact_id = result.get("artifact_id", "?")
    print(file=sys.stderr)
    body = f"Artifact: {artifact_id}\nTarget:   {target}\n\n{summary}"
    print(ui.dither_box("Patch Proposal", body), file=sys.stderr)
    print(file=sys.stderr)
    # Interactive apply prompt
    try:
        answer = input(ui.c(ui.CYAN, "  Apply this patch? [y/N] "))
        if answer.strip().lower() == "y":
            print(ui.ok("Patch applied."), file=sys.stderr)
        else:
            print(ui.info("Patch saved but not applied."), file=sys.stderr)
    except (KeyboardInterrupt, EOFError):
        print(file=sys.stderr)
        print(ui.info("Patch saved but not applied."), file=sys.stderr)
    print(file=sys.stderr)
    ui.suggest_next("propose")


# ---------------------------------------------------------------------------
# Watch command implementation
# ---------------------------------------------------------------------------

_WATCHED_EXTENSIONS: frozenset[str] = frozenset(
    {".py", ".rs", ".go", ".ts", ".tsx", ".js", ".jsx"}
)

_WATCH_STATE_DIR = ".documint"
_WATCH_STATE_FILE = "watch-state.json"

# ANSI color helpers
_GREEN = "\033[32m"
_RED = "\033[31m"
_YELLOW = "\033[33m"
_CYAN = "\033[36m"
_RESET = "\033[0m"


def _determine_severity(
    removed: list[Any], added: list[Any], changed: list[Any]
) -> str:
    if removed or changed:
        return "HIGH"
    if added:
        return "MEDIUM"
    return "LOW"


def _file_sha256(content: str) -> str:
    return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()


def _load_watch_state(state_path: Path) -> dict[str, Any]:
    if not state_path.exists():
        return {"last_updated": None, "files": {}}
    try:
        return json.loads(state_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"last_updated": None, "files": {}}


def _save_watch_state(state_path: Path, state: dict[str, Any]) -> None:
    state["last_updated"] = datetime.now(UTC).isoformat()
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _collect_source_files(root: Path) -> dict[str, str]:
    """Walk the project tree and return {relative_path: content} for watched extensions."""
    files: dict[str, str] = {}
    for child in root.rglob("*"):
        if not child.is_file():
            continue
        if child.suffix not in _WATCHED_EXTENSIONS:
            continue
        # Skip common non-source directories
        rel = child.relative_to(root)
        parts = rel.parts
        if any(
            p.startswith(".")
            or p in ("node_modules", "__pycache__", "target", "dist", "build", ".git", "venv", ".venv")
            for p in parts
        ):
            continue
        try:
            content = child.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        files[str(rel)] = content
    return files


def _extract_file_symbols(content: str, path: str) -> list[dict[str, Any]]:
    """Extract symbols from a single file and return compact dicts."""
    from .symbol_extractor import extract_symbols

    entries = extract_symbols(content, path=path)
    return [
        {"n": e.name, "k": e.kind, "s": e.signature()}
        for e in entries
    ]


def _build_initial_state(root: Path) -> dict[str, Any]:
    """Scan all source files and build the initial watch state."""
    files = _collect_source_files(root)
    state_files: dict[str, Any] = {}
    for rel_path, content in files.items():
        state_files[rel_path] = {
            "hash": _file_sha256(content),
            "symbols": _extract_file_symbols(content, rel_path),
        }
    return {
        "last_updated": datetime.now(UTC).isoformat(),
        "files": state_files,
    }


def _load_artifact_specs(root: Path) -> list[dict[str, Any]]:
    """Load artifact specs from config or defaults to match files against."""
    try:
        from .repository import DEFAULT_ARTIFACT_SPECS

        return [
            {
                "artifact_key": spec.artifact_key,
                "source_patterns": list(spec.source_patterns),
            }
            for spec in DEFAULT_ARTIFACT_SPECS
        ]
    except Exception:
        return []


def _match_artifacts(rel_path: str, artifact_specs: list[dict[str, Any]]) -> list[str]:
    """Return artifact keys whose source_patterns match the given relative path."""
    matched: list[str] = []
    for spec in artifact_specs:
        for pattern in spec["source_patterns"]:
            if fnmatch.fnmatch(rel_path, pattern):
                matched.append(spec["artifact_key"])
                break
    return matched


def _compute_diff(
    old_symbols: list[dict[str, Any]], new_symbols: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[tuple[dict[str, Any], dict[str, Any]]]]:
    """Compare old and new symbol lists.

    Returns (removed, added, changed) where changed is a list of (old, new) pairs
    for symbols with the same name but different signatures.
    """
    old_by_name: dict[str, dict[str, Any]] = {s["n"]: s for s in old_symbols}
    new_by_name: dict[str, dict[str, Any]] = {s["n"]: s for s in new_symbols}

    old_names = set(old_by_name.keys())
    new_names = set(new_by_name.keys())

    removed = [old_by_name[n] for n in sorted(old_names - new_names)]
    added = [new_by_name[n] for n in sorted(new_names - old_names)]
    changed: list[tuple[dict[str, Any], dict[str, Any]]] = []

    for name in sorted(old_names & new_names):
        if old_by_name[name]["s"] != new_by_name[name]["s"]:
            changed.append((old_by_name[name], new_by_name[name]))

    return removed, added, changed


def _format_symbol_display(sym: dict[str, Any]) -> str:
    """Format a symbol for display. Uses the signature string."""
    return sym["s"]


def _print_diff(
    rel_path: str,
    removed: list[dict[str, Any]],
    added: list[dict[str, Any]],
    changed: list[tuple[dict[str, Any], dict[str, Any]]],
    artifact_specs: list[dict[str, Any]],
) -> None:
    """Print a rich diff block for a changed file."""
    timestamp = datetime.now().strftime("%H:%M:%S")

    if _is_tty():
        print(ui.dither_divider(), file=sys.stderr)
        print(f"  {ui.c(ui.WHITE, f'[{timestamp}]')} {ui.bold(rel_path)}", file=sys.stderr)
    else:
        print(f"[{timestamp}] {rel_path}")

    for sym in removed:
        print(f"  {_RED}-{_RESET} {_format_symbol_display(sym)}")

    for old_sym, new_sym in changed:
        print(f"  {_RED}-{_RESET} {_format_symbol_display(old_sym)}")
        print(f"  {_GREEN}+{_RESET} {_format_symbol_display(new_sym)}")

    for sym in added:
        print(f"  {_GREEN}+{_RESET} {_format_symbol_display(sym)}")

    severity = _determine_severity(removed, added, changed)
    matched_artifacts = _match_artifacts(rel_path, artifact_specs)

    for artifact_key in matched_artifacts:
        if _is_tty():
            sev_badge = ui.severity_badge(severity)
            print(f"  {ui.c(ui.YELLOW, '*')} Artifact: {artifact_key} ({sev_badge} drift)", file=sys.stderr)
            print(f"  {ui.c(ui.CYAN, '->')} Run: documint propose --artifact-id {artifact_key}", file=sys.stderr)
        else:
            print(f"  {_YELLOW}*{_RESET} Artifact: {artifact_key} ({severity} drift)")
            print(
                f"  {_CYAN}->{_RESET} Run: documint propose --artifact-id {artifact_key}"
            )

    if not matched_artifacts:
        if _is_tty():
            sev_badge = ui.severity_badge(severity)
            print(f"  {ui.c(ui.YELLOW, '*')} Severity: {sev_badge} drift (no artifact match)", file=sys.stderr)
        else:
            print(f"  {_YELLOW}*{_RESET} Severity: {severity} drift (no artifact match)")


def _flush_watch_state_if_dirty(state_path: Path, state: dict[str, Any]) -> None:
    """Write watch state to disk if dirty and the 1-second quiet period has elapsed."""
    global _watch_state_dirty, _watch_last_save
    if _watch_state_dirty and time.time() - _watch_last_save > 1.0:
        _save_watch_state(state_path, state)
        _watch_state_dirty = False
        _watch_last_save = time.time()


def _mark_watch_state_dirty() -> None:
    """Mark the watch state as needing a flush (debounced)."""
    global _watch_state_dirty
    _watch_state_dirty = True


def _process_file_change(
    rel_path: str,
    root: Path,
    state: dict[str, Any],
    state_path: Path,
    artifact_specs: list[dict[str, Any]],
    change_counts: dict[str, int],
) -> None:
    """Handle a single file change: re-extract, diff, print, update state."""
    abs_path = root / rel_path
    if not abs_path.exists() or not abs_path.is_file():
        # File was deleted
        old_entry = state["files"].get(rel_path)
        if old_entry:
            old_symbols = old_entry.get("symbols", [])
            if old_symbols:
                removed, added, changed = old_symbols, [], []
                _print_diff(rel_path, removed, added, changed, artifact_specs)
                change_counts["changes"] += 1
                matched = _match_artifacts(rel_path, artifact_specs)
                for a in matched:
                    change_counts["artifacts"].add(a)  # type: ignore[union-attr]
            del state["files"][rel_path]
            _mark_watch_state_dirty()
        return

    try:
        content = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return

    new_hash = _file_sha256(content)
    old_entry = state["files"].get(rel_path, {})
    old_hash = old_entry.get("hash")

    if new_hash == old_hash:
        return  # Content unchanged (e.g., save without edits)

    new_symbols = _extract_file_symbols(content, rel_path)
    old_symbols = old_entry.get("symbols", [])

    removed, added, changed = _compute_diff(old_symbols, new_symbols)

    if removed or added or changed:
        _print_diff(rel_path, removed, added, changed, artifact_specs)
        change_counts["changes"] += 1
        matched = _match_artifacts(rel_path, artifact_specs)
        for a in matched:
            change_counts["artifacts"].add(a)  # type: ignore[union-attr]

    # Update state regardless (hash changed even if symbols didn't)
    state["files"][rel_path] = {
        "hash": new_hash,
        "symbols": new_symbols,
    }
    _mark_watch_state_dirty()


def _run_watch(args: argparse.Namespace) -> int:
    """Main entry point for the watch command."""
    root = Path.cwd().resolve()
    state_dir = root / _WATCH_STATE_DIR
    state_dir.mkdir(parents=True, exist_ok=True)
    state_path = state_dir / _WATCH_STATE_FILE

    artifact_specs = _load_artifact_specs(root)

    # Build or load initial state
    existing_state = _load_watch_state(state_path)
    if existing_state.get("files"):
        state = existing_state
        file_count = len(state["files"])
        if _is_tty():
            print(ui.ok(f"Loaded cached watch state ({file_count} files)"), file=sys.stderr)
        else:
            print(f"Loaded cached watch state ({file_count} files).")
    else:
        if _is_tty():
            print(ui.info("Building initial symbol state..."), file=sys.stderr)
        else:
            print("Building initial symbol state...")
        state = _build_initial_state(root)
        _save_watch_state(state_path, state)
        file_count = len(state["files"])
        if _is_tty():
            print(ui.ok(f"Indexed {file_count} source files"), file=sys.stderr)
        else:
            print(f"Indexed {file_count} source files.")

    artifact_count = len(artifact_specs)

    change_counts: dict[str, Any] = {
        "changes": 0,
        "artifacts": set(),
        "files_watched": file_count,
    }

    # Graceful shutdown handler
    shutdown_requested = False

    def _handle_sigint(signum: int, frame: Any) -> None:
        nonlocal shutdown_requested
        shutdown_requested = True

    signal.signal(signal.SIGINT, _handle_sigint)

    if _is_tty():
        ui.print_banner()
        print(ui.ok(f"Watching {file_count} files across {artifact_count} artifacts"), file=sys.stderr)
        print(ui.info("Press Ctrl+C to stop"), file=sys.stderr)
        print(file=sys.stderr)
        print(ui.dither_divider(), file=sys.stderr)
    else:
        print(f"Watching for changes... (Ctrl+C to stop)")

    # Try watchdog first, fall back to polling
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        return _run_watchdog(
            root, state, state_path, artifact_specs, change_counts,
            Observer, FileSystemEventHandler, shutdown_requested,
            lambda: shutdown_requested,
        )
    except ImportError:
        return _run_polling(
            root, state, state_path, artifact_specs, change_counts,
            args.poll_interval, lambda: shutdown_requested,
        )


def _run_watchdog(
    root: Path,
    state: dict[str, Any],
    state_path: Path,
    artifact_specs: list[dict[str, Any]],
    change_counts: dict[str, Any],
    observer_cls: type,
    handler_base: type,
    _shutdown_requested: bool,
    is_shutdown: Any,
) -> int:
    """Run with watchdog-based file watching."""

    class _Handler(handler_base):  # type: ignore[misc]
        def on_modified(self, event: Any) -> None:
            if event.is_directory:
                return
            self._handle(event.src_path)

        def on_created(self, event: Any) -> None:
            if event.is_directory:
                return
            self._handle(event.src_path)

        def on_deleted(self, event: Any) -> None:
            if event.is_directory:
                return
            self._handle(event.src_path)

        def _handle(self, abs_path_str: str) -> None:
            abs_path = Path(abs_path_str)
            if abs_path.suffix not in _WATCHED_EXTENSIONS:
                return
            try:
                rel_path = str(abs_path.relative_to(root))
            except ValueError:
                return
            # Skip hidden/build dirs
            if any(
                p.startswith(".")
                or p in ("node_modules", "__pycache__", "target", "dist", "build", "venv", ".venv")
                for p in Path(rel_path).parts
            ):
                return
            _process_file_change(
                rel_path, root, state, state_path, artifact_specs, change_counts
            )

    observer = observer_cls()
    handler = _Handler()
    observer.schedule(handler, str(root), recursive=True)
    observer.start()

    try:
        while not is_shutdown():
            time.sleep(0.5)
            _flush_watch_state_if_dirty(state_path, state)
    finally:
        # Final flush before exit to avoid losing state
        if _watch_state_dirty:
            _save_watch_state(state_path, state)
        observer.stop()
        observer.join()

    return _print_summary_and_exit(change_counts)


def _run_polling(
    root: Path,
    state: dict[str, Any],
    state_path: Path,
    artifact_specs: list[dict[str, Any]],
    change_counts: dict[str, Any],
    interval: float,
    is_shutdown: Any,
) -> int:
    """Run with polling-based file watching (fallback when watchdog is unavailable)."""
    print(f"  (using polling, interval={interval}s)")

    # Track mtimes for efficient change detection
    mtimes: dict[str, float] = {}
    for child in root.rglob("*"):
        if not child.is_file():
            continue
        if child.suffix not in _WATCHED_EXTENSIONS:
            continue
        rel = child.relative_to(root)
        parts = rel.parts
        if any(
            p.startswith(".")
            or p in ("node_modules", "__pycache__", "target", "dist", "build", "venv", ".venv")
            for p in parts
        ):
            continue
        try:
            mtimes[str(rel)] = child.stat().st_mtime
        except OSError:
            pass

    while not is_shutdown():
        time.sleep(interval)
        if is_shutdown():
            break

        current_files: dict[str, float] = {}
        for child in root.rglob("*"):
            if not child.is_file():
                continue
            if child.suffix not in _WATCHED_EXTENSIONS:
                continue
            rel = child.relative_to(root)
            parts = rel.parts
            if any(
                p.startswith(".")
                or p in ("node_modules", "__pycache__", "target", "dist", "build", "venv", ".venv")
                for p in parts
            ):
                continue
            try:
                current_files[str(rel)] = child.stat().st_mtime
            except OSError:
                pass

        # Check for modified or new files
        for rel_path, mtime in current_files.items():
            old_mtime = mtimes.get(rel_path)
            if old_mtime is None or mtime > old_mtime:
                _process_file_change(
                    rel_path, root, state, state_path, artifact_specs, change_counts
                )

        # Check for deleted files
        for rel_path in set(mtimes.keys()) - set(current_files.keys()):
            _process_file_change(
                rel_path, root, state, state_path, artifact_specs, change_counts
            )

        mtimes = current_files
        _flush_watch_state_if_dirty(state_path, state)

    # Final flush before exit to avoid losing state
    if _watch_state_dirty:
        _save_watch_state(state_path, state)
    return _print_summary_and_exit(change_counts)


def _print_summary_and_exit(change_counts: dict[str, Any]) -> int:
    """Print the session summary and return exit code."""
    files = change_counts["files_watched"]
    changes = change_counts["changes"]
    artifacts = change_counts["artifacts"]
    artifact_count = len(artifacts) if isinstance(artifacts, set) else artifacts
    print(
        f"\nWatched {files} files. "
        f"Detected {changes} changes in {artifact_count} artifacts."
    )
    return 0


# ---------------------------------------------------------------------------
# CI command implementation
# ---------------------------------------------------------------------------


def _run_ci(args: argparse.Namespace) -> int:
    """Non-interactive drift check for CI pipelines."""
    drift_result = _request(
        args,
        "POST",
        "/jobs/drift",
        json_body={
            "project_id": args.project_id,
            "signal_type": "manual",
            "changed_files": [],
        },
    )

    findings: list[dict[str, Any]] = drift_result.get("findings", [])

    fmt = args.ci_format
    if fmt == "json":
        _ci_output_json(findings)
    elif fmt == "github":
        _ci_output_github(findings)
    else:
        _ci_output_text(findings)

    if args.fail_on_high:
        has_high = any(
            str(f.get("severity", "")).lower() == "high" for f in findings
        )
        if has_high:
            sys.exit(1)
        return 0

    if args.fail_on_any:
        if findings:
            sys.exit(1)
        return 0

    return 0


def _ci_output_text(findings: list[dict[str, Any]]) -> None:
    """Print findings as a plain-text table."""
    if not findings:
        print("No drift findings detected.")
        return

    # Column widths
    id_width = max(len(str(f.get("artifact_id", ""))) for f in findings)
    id_width = max(id_width, len("Artifact"))
    sev_width = max(len(str(f.get("severity", ""))) for f in findings)
    sev_width = max(sev_width, len("Severity"))

    header = f"{'Artifact':<{id_width}}  {'Severity':<{sev_width}}  Summary"
    print(header)
    print("-" * len(header))
    for f in findings:
        artifact_id = str(f.get("artifact_id", ""))
        severity = str(f.get("severity", "")).upper()
        summary = str(f.get("summary", ""))
        print(f"{artifact_id:<{id_width}}  {severity:<{sev_width}}  {summary}")

    print(f"\n{len(findings)} finding(s) detected.")


def _ci_output_json(findings: list[dict[str, Any]]) -> None:
    """Print findings as a JSON array."""
    compact = [
        {
            "artifact_id": f.get("artifact_id", ""),
            "severity": str(f.get("severity", "")).upper(),
            "summary": f.get("summary", ""),
        }
        for f in findings
    ]
    print(json.dumps(compact, indent=2))


def _ci_output_github(findings: list[dict[str, Any]]) -> None:
    """Print findings as GitHub Actions markdown and optionally write to step summary."""
    lines: list[str] = ["## Documint Drift Report", ""]

    if findings:
        lines.append("| Artifact | Severity | Summary |")
        lines.append("|----------|----------|---------|")
        for f in findings:
            artifact_id = str(f.get("artifact_id", ""))
            severity = str(f.get("severity", "")).upper()
            summary = str(f.get("summary", ""))
            lines.append(f"| {artifact_id} | {severity} | {summary} |")
        lines.append("")
        lines.append(f"**{len(findings)} finding(s) detected.**")
    else:
        lines.append("No drift findings detected.")

    markdown = "\n".join(lines)
    print(markdown)

    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary_path:
        try:
            with open(summary_path, "a", encoding="utf-8") as fh:
                fh.write(markdown + "\n")
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Coverage command implementation
# ---------------------------------------------------------------------------


def _run_coverage() -> int:
    """Show documentation coverage -- what percentage of symbols are documented."""
    from .repository import DEFAULT_ARTIFACT_SPECS
    from .symbol_extractor import extract_symbols

    root = Path.cwd().resolve()
    use_color = sys.stdout.isatty()

    total_documented = 0
    total_symbols = 0

    rows: list[tuple[str, int, int]] = []

    for spec in DEFAULT_ARTIFACT_SPECS:
        # Collect source files matching source_patterns
        source_files: dict[str, str] = {}
        for pattern in spec.source_patterns:
            for match_path in root.glob(pattern):
                if match_path.is_file() and match_path.suffix in _WATCHED_EXTENSIONS:
                    try:
                        content = match_path.read_text(encoding="utf-8", errors="replace")
                        rel = str(match_path.relative_to(root))
                        source_files[rel] = content
                    except (OSError, ValueError):
                        continue

        # Extract symbols from source files
        symbols: list[str] = []
        for path, content in source_files.items():
            for entry in extract_symbols(content, path=path):
                if entry.name not in symbols:
                    symbols.append(entry.name)

        if not symbols:
            continue

        # Read documentation files and check symbol coverage
        doc_contents: list[str] = []
        for doc_path in spec.doc_paths:
            full_doc = root / doc_path
            try:
                doc_contents.append(full_doc.read_text(encoding="utf-8", errors="replace"))
            except FileNotFoundError:
                continue
            except OSError:
                continue

        merged_docs = "\n".join(doc_contents)

        documented_count = 0
        for sym_name in symbols:
            if sym_name in merged_docs:
                documented_count += 1

        rows.append((spec.title, documented_count, len(symbols)))
        total_documented += documented_count
        total_symbols += len(symbols)

    if not rows:
        print("No artifacts with extractable symbols found.")
        return 0

    # Print coverage report
    if _is_tty():
        print(ui.dither_divider(), file=sys.stderr)
        print(file=sys.stderr)

    # Find widest title for alignment
    max_title = max(len(title) for title, _, _ in rows)

    for title, doc_count, sym_count in rows:
        pct = (doc_count / sym_count * 100) if sym_count > 0 else 0.0
        sym_width = len(str(sym_count))
        count_str = f"{doc_count:>{sym_width}}/{sym_count}"

        if pct >= 80.0:
            indicator = _colorize("\u2713", _GREEN, use_color)
        elif pct >= 50.0:
            indicator = _colorize("\u26a0", _YELLOW, use_color)
        else:
            indicator = _colorize("\u2717", _RED, use_color)

        print(
            f"{title + ':':<{max_title + 1}}  {count_str} symbols documented  "
            f"({pct:5.1f}%)  {indicator}"
        )

    if total_symbols > 0:
        overall_pct = total_documented / total_symbols * 100
    else:
        overall_pct = 0.0
    print(f"\nOverall: {total_documented}/{total_symbols} ({overall_pct:.1f}%)")

    if _is_tty():
        print(ui.progress_bar(total_documented, total_symbols), file=sys.stderr)
        print(file=sys.stderr)
        print(ui.dither_divider(), file=sys.stderr)
        print(file=sys.stderr)
        ui.suggest_next("coverage")

    return 0


def _colorize(text: str, color: str, use_color: bool) -> str:
    """Wrap text in ANSI color codes if color output is enabled."""
    if use_color:
        return f"{color}{text}{_RESET}"
    return text


# ---------------------------------------------------------------------------
# Changelog hook for propose command
# ---------------------------------------------------------------------------


def _append_changelog(args: argparse.Namespace, patch_result: dict[str, Any]) -> None:
    """Append a changelog entry after a successful patch proposal."""
    root = Path.cwd().resolve()

    # Determine the docs root from settings, fall back to project root
    docs_root = root / getattr(settings, "docs_root", "")
    changelog_candidates = [
        docs_root / "CHANGELOG.md",
        root / "CHANGELOG.md",
    ]

    changelog_path: Path | None = None
    for candidate in changelog_candidates:
        if candidate.is_file():
            changelog_path = candidate
            break

    if changelog_path is None:
        return

    artifact_id = (
        patch_result.get("artifact_id")
        or getattr(args, "artifact_id", None)
        or getattr(args, "finding_id", None)
        or "unknown"
    )
    summary = patch_result.get("summary", "Documentation patch proposed.")
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")

    entry = f"\n### [auto] {artifact_id} \u2014 {timestamp}\n- {summary}\n"

    try:
        with open(changelog_path, "a", encoding="utf-8") as fh:
            fh.write(entry)
        print(f"\u2713 Appended to CHANGELOG.md")
    except OSError:
        pass
