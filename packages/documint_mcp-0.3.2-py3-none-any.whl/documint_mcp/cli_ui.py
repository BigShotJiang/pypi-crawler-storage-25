"""CLI visual toolkit — branded output, spinners, dither, and formatting.

All terminal rendering lives here so cli.py stays focused on logic.
Zero external dependencies — uses only ANSI escape codes + stdlib.
"""
from __future__ import annotations

import itertools
import sys
import threading
import time

# ── ANSI palette ─────────────────────────────────────────────────────────────

_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_ITALIC = "\033[3m"
_UNDERLINE = "\033[4m"

# Semantic colors
GREEN = "\033[38;5;114m"
RED = "\033[38;5;203m"
YELLOW = "\033[38;5;221m"
CYAN = "\033[38;5;117m"
BLUE = "\033[38;5;75m"
MAGENTA = "\033[38;5;176m"
WHITE = "\033[38;5;255m"
GRAY = "\033[38;5;245m"
DARK_GRAY = "\033[38;5;240m"

# Brand gradient (mint/teal tones matching the leaf)
MINT_1 = "\033[38;5;48m"
MINT_2 = "\033[38;5;42m"
MINT_3 = "\033[38;5;36m"
MINT_4 = "\033[38;5;30m"

# Background colors
BG_GREEN = "\033[48;5;22m"
BG_RED = "\033[48;5;52m"
BG_YELLOW = "\033[48;5;58m"


def _is_tty() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def c(color: str, text: str) -> str:
    """Colorize text if stdout is a TTY."""
    if not _is_tty():
        return text
    return f"{color}{text}{_RESET}"


def bold(text: str) -> str:
    return c(_BOLD, text)


def dim(text: str) -> str:
    return c(_DIM, text)


# ── Banner ───────────────────────────────────────────────────────────────────

_VERSION = "0.3.0"


def print_banner(version: str = _VERSION) -> None:
    """Print the compact branded banner."""
    if not _is_tty():
        return
    print(f"""
{c(MINT_2, '  .')} {c(MINT_3, '. :')} {c(_BOLD, 'documint')} {c(DARK_GRAY, f'v{version}')}
{c(MINT_3, ' .:')}{c(MINT_4, '*:.')}{c(_RESET, '')}  {c(GRAY, 'AST-powered doc drift detection')}
{c(MINT_4, '  :.')}
""")


def print_banner_full(version: str = _VERSION) -> None:
    """Print the full ASCII art banner."""
    if not _is_tty():
        return
    print(f"""
{c(MINT_1, ' ____                            _       _   ')}
{c(MINT_2, '|  _ \\  ___   ___ _   _ _ __ ___ (_)_ __ | |_ ')}
{c(MINT_3, '| | | |/ _ \\ / __| | | |  _ ` _ \\| |  _ \\| __|')}
{c(MINT_3, '| |_| | (_) | (__| |_| | | | | | | | | | | |_ ')}
{c(MINT_4, '|____/ \\___/ \\___|\\__,_|_| |_| |_|_|_| |_|\\__|')}

  {c(GRAY, 'AST-powered doc drift detection')}  {dim(f'v{version}')}
""")


# ── Dither ───────────────────────────────────────────────────────────────────

_DITHER_PATTERN = "+ x * + x * + x * +"
_DITHER_LIGHT = "* + x + * + x + * +"


def dither_divider(width: int = 60) -> str:
    """Generate a dither divider line."""
    segment = _DITHER_PATTERN + " "
    repeated = (segment * ((width // len(segment)) + 1))[:width]
    return c(DARK_GRAY, repeated)


def dither_divider_mint(width: int = 60) -> str:
    """Dither divider with mint color gradient."""
    if not _is_tty():
        return dither_divider(width)
    segment_w = max(1, width // 7)
    parts = [
        f"{MINT_4}{'+ ' * (segment_w // 2)}",
        f"{MINT_3}{'x ' * (segment_w // 2)}",
        f"{MINT_2}{'* ' * (segment_w // 2)}",
        f"{MINT_1}{'x ' * (segment_w // 2)}",
        f"{MINT_2}{'* ' * (segment_w // 2)}",
        f"{MINT_3}{'x ' * (segment_w // 2)}",
        f"{MINT_4}{'+ ' * (segment_w // 2)}",
    ]
    return "".join(parts) + _RESET


def dither_light() -> str:
    """Subtle dither for between items."""
    return c(DARK_GRAY, "  " + _DITHER_LIGHT)


# ── Box drawing ──────────────────────────────────────────────────────────────

BOX_TL = "\u250c"
BOX_TR = "\u2510"
BOX_BL = "\u2514"
BOX_BR = "\u2518"
BOX_H = "\u2500"
BOX_V = "\u2502"
BOX_LT = "\u251c"
BOX_RT = "\u2524"


def box(title: str, content: str, width: int = 62, color: str = CYAN) -> str:
    """Wrap content in a box-drawn frame."""
    title_display = f" {title} "
    fill = max(0, width - len(title_display) - 2)
    top = c(color, f"{BOX_TL}{BOX_H}{title_display}{BOX_H * fill}{BOX_TR}")
    bottom = c(color, f"{BOX_BL}{BOX_H * (width)}{BOX_BR}")
    lines = content.split("\n")
    body_lines = []
    for line in lines:
        pad = max(0, width - 2 - len(line))
        body_lines.append(f"{c(color, BOX_V)} {line}{' ' * pad}{c(color, BOX_V)}")
    return f"{top}\n" + "\n".join(body_lines) + f"\n{bottom}"


def dither_box(title: str, content: str) -> str:
    """Render content with dithered borders."""
    border = c(DARK_GRAY, "+ x * + " + "x " * 20 + "* + x +")
    title_line = f"{c(DARK_GRAY, ':')} {bold(title)}"
    lines = content.split("\n")
    body = "\n".join(f"{c(DARK_GRAY, ':')} {line}" for line in lines)
    return f"{border}\n{title_line}\n{c(DARK_GRAY, ':')}\n{body}\n{border}"


# ── Table ────────────────────────────────────────────────────────────────────

def table(headers: list[str], rows: list[list[str]], col_colors: list[str] | None = None) -> str:
    """Render a simple aligned table."""
    if not rows:
        return ""
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                # Strip ANSI for width calculation
                clean = cell
                for code in [GREEN, RED, YELLOW, CYAN, BLUE, MAGENTA, WHITE, GRAY, DARK_GRAY,
                             MINT_1, MINT_2, MINT_3, MINT_4, _BOLD, _DIM, _ITALIC, _RESET]:
                    clean = clean.replace(code, "")
                widths[i] = max(widths[i], len(clean))

    header_line = "  ".join(f"{c(_BOLD, h):<{widths[i] + (len(c(_BOLD, '')) - len(''))}}" if _is_tty()
                            else f"{h:<{widths[i]}}"
                            for i, h in enumerate(headers))
    sep = "  ".join(BOX_H * w for w in widths)

    lines = [f"  {header_line}", f"  {c(DARK_GRAY, sep)}"]
    for row in rows:
        cells = []
        for i, cell in enumerate(row):
            cells.append(cell)
        lines.append("  " + "  ".join(cells))
    return "\n".join(lines)


# ── Spinner ──────────────────────────────────────────────────────────────────

class Spinner:
    """Minimal terminal spinner for long-running operations."""

    # Dither-themed frames
    _FRAMES = ["   ", "+  ", "+x ", "+x*", " x*", "  *", "   "]

    def __init__(self, message: str, color: str = CYAN) -> None:
        self._message = message
        self._color = color
        self._running = False
        self._thread: threading.Thread | None = None

    def __enter__(self) -> Spinner:
        self.start()
        return self

    def __exit__(self, *_: object) -> None:
        self.stop()

    def start(self) -> None:
        if not _is_tty():
            print(f"  {self._message}...")
            return
        self._running = True
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()

    def _spin(self) -> None:
        for frame in itertools.cycle(self._FRAMES):
            if not self._running:
                break
            sys.stdout.write(f"\r  {self._color}{frame}{_RESET} {self._message}")
            sys.stdout.flush()
            time.sleep(0.12)

    def stop(self, result: str = "") -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=1)
        if _is_tty():
            sys.stdout.write(f"\r  {GREEN}*{_RESET} {self._message}  {result}\n")
            sys.stdout.flush()
        elif result:
            print(f"  * {self._message}  {result}")


# ── Dither progress bar ─────────────────────────────────────────────────────

_DITHER_CHARS = " +x*x+*x+"


def progress_bar(current: int, total: int, width: int = 30) -> str:
    """Render a dither-style progress bar."""
    if total == 0:
        return ""
    ratio = min(current / total, 1.0)
    filled = int(ratio * width)
    bar_chars = ""
    for i in range(width):
        if i < filled:
            density = min(len(_DITHER_CHARS) - 1, int((i / width) * len(_DITHER_CHARS)))
            bar_chars += _DITHER_CHARS[density]
        else:
            bar_chars += " "
    pct = f"{ratio * 100:5.1f}%"
    return f"  {c(MINT_2, f'[{bar_chars}]')} {pct}"


# ── Status indicators ───────────────────────────────────────────────────────

def ok(msg: str) -> str:
    return f"  {c(GREEN, '*')} {msg}"


def warn(msg: str) -> str:
    return f"  {c(YELLOW, '!')} {msg}"


def err(msg: str) -> str:
    return f"  {c(RED, 'x')} {msg}"


def info(msg: str) -> str:
    return f"  {c(CYAN, '~')} {msg}"


def step(n: int, total: int, msg: str) -> str:
    return f"  {dim(f'Step {n}/{total}')} {c(CYAN, msg)}"


# ── Severity badges ─────────────────────────────────────────────────────────

def severity_badge(level: str) -> str:
    """Colored severity indicator."""
    level_up = level.upper()
    if level_up == "HIGH":
        return c(RED, "HIGH")
    elif level_up == "MEDIUM":
        return c(YELLOW, "MEDIUM")
    elif level_up == "LOW":
        return c(GRAY, "LOW")
    elif level_up in ("FRESH", "PASS", "OK"):
        return c(GREEN, level_up)
    return level_up


# ── Diff rendering ──────────────────────────────────────────────────────────

def render_diff(old_line: str, new_line: str) -> str:
    """Render a colored diff pair."""
    return f"    {c(RED, f'- {old_line}')}\n    {c(GREEN, f'+ {new_line}')}"


# ── Suggestions ─────────────────────────────────────────────────────────────

_NEXT_STEPS: dict[str, list[tuple[str, str]]] = {
    "scan": [
        ("Run drift detection", "documint drift"),
        ("Check doc coverage", "documint coverage"),
    ],
    "drift": [
        ("Draft a patch for a finding", "documint propose --finding-id <id>"),
        ("Start watching for changes", "documint watch"),
    ],
    "propose": [
        ("Publish updated docs", "documint publish"),
        ("Run full drift check", "documint drift"),
    ],
    "coverage": [
        ("Fix gaps with AI patches", "documint propose --artifact-id <id>"),
        ("Start watching", "documint watch"),
    ],
    "watch": [],
    "ci": [],
}


def suggest_next(command: str) -> None:
    """Print next-step suggestions for a command."""
    steps = _NEXT_STEPS.get(command, [])
    if not steps or not _is_tty():
        return
    print(f"\n  {c(GRAY, 'Next steps:')}")
    for desc, cmd in steps:
        print(f"    {c(CYAN, '->')} {desc}: {c(BLUE, cmd)}")
    print()


# ── Friendly errors ─────────────────────────────────────────────────────────

def friendly_error(message: str, hint: str = "") -> None:
    """Print a conversational error message."""
    print(f"\n{err(message)}")
    if hint:
        print(f"  {c(GRAY, 'Hint:')} {hint}")
    print()


def api_unreachable(url: str) -> None:
    """Print a friendly API connection error."""
    friendly_error(
        f"Could not reach the Documint API at {url}",
        hint="Is the server running? Try: documint-server",
    )


# ── Slash commands ───────────────────────────────────────────────────────────

SLASH_COMMANDS: dict[str, str] = {
    "/drift": "Run drift detection on the current project",
    "/patch": "Generate a doc patch for a finding",
    "/watch": "Start watching for file changes",
    "/status": "Show project status and recent activity",
    "/coverage": "Show documentation coverage report",
    "/scan": "Snapshot the current project state",
    "/help": "Show available commands",
    "/quit": "Exit interactive mode",
}


def print_slash_help() -> None:
    """Print slash command reference."""
    print(f"\n  {bold('Available commands:')}\n")
    for cmd, desc in SLASH_COMMANDS.items():
        print(f"    {c(CYAN, f'{cmd:<12}')} {desc}")
    print(f"\n  {c(GRAY, 'Or type a question in natural language:')}")
    print(f'    {c(MAGENTA, '"what docs are stale?"')}')
    print(f'    {c(MAGENTA, '"show me the drift for auth.py"')}')
    print()


# ── Natural language intent routing ──────────────────────────────────────────

def detect_intent(query: str) -> str | None:
    """Detect the user's intent from a natural language query.

    Returns a command name or None if unrecognized.
    """
    q = query.lower().strip()

    # Drift / staleness
    if any(w in q for w in ["stale", "drift", "outdated", "out of date", "lying", "wrong"]):
        return "drift"

    # Coverage
    if any(w in q for w in ["coverage", "documented", "how much", "undocumented", "missing"]):
        return "coverage"

    # Patch / fix
    if any(w in q for w in ["patch", "fix", "update docs", "propose", "draft"]):
        return "propose"

    # Watch
    if any(w in q for w in ["watch", "monitor", "live", "real-time", "realtime"]):
        return "watch"

    # Scan / snapshot
    if any(w in q for w in ["scan", "snapshot", "check", "analyze"]):
        return "scan"

    # Status
    if any(w in q for w in ["status", "health", "how are", "overview", "summary"]):
        return "scan"

    return None


def print_intent_help() -> None:
    """Print what the CLI understands."""
    print(f"  {c(GRAY, 'I understand questions about:')}")
    print(f"    {c(CYAN, '*')} documentation drift and staleness")
    print(f"    {c(CYAN, '*')} coverage and undocumented symbols")
    print(f"    {c(CYAN, '*')} patching and fixing stale docs")
    print(f"    {c(CYAN, '*')} watching for real-time changes")
    print(f"    {c(CYAN, '*')} project health and status")
    example1 = '"what docs are stale?"'
    example2 = '"show me coverage"'
    print(f"\n  {c(GRAY, 'Try:')} documint {c(MAGENTA, example1)}")
    print(f"       documint {c(MAGENTA, example2)}")
    print()
