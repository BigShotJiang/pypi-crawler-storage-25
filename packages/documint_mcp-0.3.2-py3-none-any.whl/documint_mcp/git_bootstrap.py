"""
Bootstrap the intelligence layer from a project's git history.

Algorithm:
  1. git log -z with \x1f field separators → list of commit dicts
  2. git diff-tree --name-only per commit → files changed
  3. Classify each commit via conventional commit regex
  4. fix: commits  → FixedEntry   (needs_enrichment=True)
     feat: commits → DecisionEntry (needs_enrichment=True)
     all commits   → HistoryEntry
  5. Infer StateFeature list from file-to-area mapping
  6. Return IntelligenceLayer — enrichment happens separately

The caller is responsible for enrichment (see intelligence_enricher.py).
"""
from __future__ import annotations

import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import structlog

from .intelligence import (
    DecisionEntry,
    FixedEntry,
    HistoryEntry,
    IntelligenceLayer,
    StateFeature,
)

logger = structlog.get_logger(__name__)

# Conventional commit regex: type(scope)!: summary
_CONVENTIONAL_RE = re.compile(
    r"^(?P<type>feat|fix|chore|style|ci|refactor|test|docs)"
    r"(?:\((?P<scope>[^)]+)\))?"
    r"(?P<breaking>!)?"
    r":\s*(?P<summary>.+)$"
)

# File-to-area rules — first match wins
_AREA_RULES: list[tuple[str, str]] = [
    ("drift_engine", "drift-detection"),
    ("symbol_extractor", "symbol-extraction"),
    ("tree_sitter", "symbol-extraction"),
    ("griffe", "symbol-extraction"),
    ("ai.py", "ai-chain"),
    ("rag.py", "ai-chain"),
    ("intelligence", "intelligence-layer"),
    ("mint.py", "mint-format"),
    (".github", "ci"),
    ("github", "github-integration"),
    ("webhook", "github-integration"),
    ("cli.py", "cli"),
    ("cli_ui", "cli"),
    ("mcp_server", "mcp-server"),
    ("server.py", "api-server"),
    ("repository.py", "api-server"),
    ("jobs.py", "api-server"),
    ("apps/web", "web-dashboard"),
    ("apps/mcp", "mcp-server"),
    ("Dockerfile", "infrastructure"),
    ("railway", "infrastructure"),
    ("docker", "infrastructure"),
    ("alembic", "database"),
    ("db.py", "database"),
    ("models.py", "database"),
    ("config.py", "core"),
]


def _run_git(args: list[str], cwd: Path) -> str:
    result = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout


def _classify_commit(subject: str, body: str, files: list[str]) -> dict:
    """Classify a commit using conventional commits format."""
    m = _CONVENTIONAL_RE.match(subject.strip())
    if not m:
        return {"type": "chore", "scope": None, "summary": subject.strip(), "breaking": False}
    return {
        "type": m.group("type"),
        "scope": m.group("scope"),
        "summary": m.group("summary").strip(),
        "breaking": m.group("breaking") == "!",
    }


def _file_to_area(filepath: str) -> str:
    """Map a file path to a logical project area."""
    for fragment, area in _AREA_RULES:
        if fragment in filepath:
            return area
    return "core"


def _infer_state(commits: list[dict]) -> list[StateFeature]:
    """
    Infer StateFeature list from commit file patterns.

    For each logical area, track the most recent commit date.
    All areas default to 'complete' — the agent can update this.
    """
    area_map: dict[str, dict] = {}

    for commit in commits:
        for f in commit.get("files", []):
            area = _file_to_area(f)
            existing = area_map.get(area)
            if existing is None or commit["date"] > existing["last_date"]:
                area_map[area] = {
                    "last_date": commit["date"],
                    "last_commit": commit["hash"][:8],
                }

    return [
        StateFeature(
            name=area,
            status="complete",
            last_commit=info["last_commit"],
            last_date=info["last_date"],
        )
        for area, info in sorted(area_map.items())
    ]


def _get_all_commits(repo_path: Path) -> list[dict]:
    """
    Return all commits as structured dicts.

    Uses \x1f (unit separator) to delimit fields within a record and
    -z (NUL) to separate records — both are safe against commit message content.
    """
    raw = _run_git(
        ["log", "-z", "--format=%H\x1f%ai\x1f%s\x1f%b"],
        repo_path,
    )

    commits = []
    for record in raw.split("\x00"):
        record = record.strip()
        if not record:
            continue
        parts = record.split("\x1f", 3)
        if len(parts) < 3:
            continue
        commits.append({
            "hash": parts[0].strip(),
            "date": parts[1].strip()[:10],  # YYYY-MM-DD
            "subject": parts[2].strip(),
            "body": parts[3].strip() if len(parts) > 3 else "",
            "files": [],
        })

    # Get changed files per commit
    for commit in commits:
        try:
            files_out = _run_git(
                ["diff-tree", "--no-commit-id", "-r", "--name-only", commit["hash"]],
                repo_path,
            )
            commit["files"] = [f for f in files_out.strip().splitlines() if f]
        except subprocess.CalledProcessError:
            commit["files"] = []

    return commits


def bootstrap_from_repo(repo_path: Path) -> IntelligenceLayer:
    """
    Parse the full git history of a repo and produce an IntelligenceLayer.

    All fix/feat entries are marked needs_enrichment=True — run
    intelligence_enricher.enrich_layer_background() to fill in the WHY.
    """
    logger.info("bootstrapping intelligence layer", repo=str(repo_path))
    commits = _get_all_commits(repo_path)

    layer = IntelligenceLayer(
        bootstrapped_at=datetime.now(timezone.utc).isoformat(),
        repo_path=str(repo_path),
        total_commits_analyzed=len(commits),
    )

    fix_count = 0
    dec_count = 0

    for commit in commits:
        classification = _classify_commit(
            commit["subject"], commit["body"], commit["files"]
        )
        commit_type = classification["type"]

        # Every commit goes into HISTORY
        layer.history.append(HistoryEntry(
            commit=commit["hash"][:8],
            date=commit["date"],
            subject=commit["subject"],
            body=commit["body"],
            files_changed=commit["files"],
            commit_type=commit_type,
            needs_enrichment=(commit_type in ("feat", "fix")),
        ))

        if commit_type == "fix":
            fix_count += 1
            layer.fixed.append(FixedEntry(
                id=f"FIX-{fix_count:03d}",
                date=commit["date"],
                commit=commit["hash"][:8],
                bug=classification["summary"],
                how_fixed=commit["body"] or classification["summary"],
                pattern="",
                files_affected=commit["files"][:10],
                needs_enrichment=True,
                never_again="",
            ))

        elif commit_type == "feat":
            dec_count += 1
            layer.decisions.append(DecisionEntry(
                id=f"DEC-{dec_count:03d}",
                date=commit["date"],
                commit=commit["hash"][:8],
                decision=classification["summary"],
                rationale=commit["body"] or classification["summary"],
                affects=commit["files"][:5],
                status="active",
                needs_enrichment=True,
            ))

    layer.state = _infer_state(commits)

    logger.info(
        "bootstrap complete",
        commits=len(commits),
        history=len(layer.history),
        fixed=len(layer.fixed),
        decisions=len(layer.decisions),
        state_areas=len(layer.state),
        pending_enrichment=layer.pending_enrichment_count(),
    )

    return layer
