"""
Input validation utilities to prevent security vulnerabilities.

Bug Fix #3: Input Validation and Sanitization
- Validates file paths to prevent directory traversal attacks
- Sanitizes user input to prevent injection attacks
- Validates file types and content
"""

import re
from pathlib import Path

from pydantic import BaseModel, Field, field_validator


class FilePathValidator:
    """
    Secure file path validation to prevent directory traversal attacks.

    Bug Fix #3: Prevents directory traversal and path injection vulnerabilities.
    """

    ALLOWED_EXTENSIONS = {".txt", ".md", ".rst", ".pdf", ".docx", ".html", ".json"}
    BLOCKED_PATTERNS = [
        r"\.\.[\\/]",  # Directory traversal
        r"^[\\/]",  # Absolute paths
        r"[<>:\"|?*]",  # Invalid filename characters
        r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$",  # Windows reserved names
    ]

    @classmethod
    def validate_path(cls, file_path: str | Path) -> Path:
        """
        Validate file path for security issues.

        Args:
            file_path: Path to validate

        Returns:
            Validated Path object

        Raises:
            ValueError: If path is invalid or insecure
        """
        if not file_path:
            raise ValueError("File path cannot be empty")

        path_str = str(file_path)

        # Check for blocked patterns
        for pattern in cls.BLOCKED_PATTERNS:
            if re.search(pattern, path_str, re.IGNORECASE):
                raise ValueError("Invalid file path: contains blocked pattern")

        # Convert to Path and resolve
        path = Path(path_str)

        # Check file extension
        if path.suffix.lower() not in cls.ALLOWED_EXTENSIONS:
            raise ValueError(f"File extension {path.suffix} not allowed")

        # Ensure path is within allowed directory
        try:
            resolved_path = path.resolve()
            # This prevents symlink attacks
            if not resolved_path.is_file() and not resolved_path.parent.exists():
                resolved_path.parent.mkdir(parents=True, exist_ok=True)
        except (OSError, ValueError) as e:
            raise ValueError(f"Invalid file path: {e}") from e

        return resolved_path

    @classmethod
    def validate_filename(cls, filename: str) -> str:
        """
        Validate filename for security issues.

        Args:
            filename: Filename to validate

        Returns:
            Validated filename

        Raises:
            ValueError: If filename is invalid
        """
        if not filename or not filename.strip():
            raise ValueError("Filename cannot be empty")

        filename = filename.strip()

        # Check length
        if len(filename) > 255:
            raise ValueError("Filename too long")

        # Check for invalid characters
        for pattern in cls.BLOCKED_PATTERNS[2:]:  # Skip path-specific patterns
            if re.search(pattern, filename, re.IGNORECASE):
                raise ValueError("Invalid filename: contains blocked characters")

        return filename


class ContentValidator:
    """
    Content validation to prevent injection attacks and ensure data integrity.

    Bug Fix #4: Prevents content-based security vulnerabilities.
    """

    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB
    ALLOWED_MIME_TYPES = {
        "text/plain",
        "text/markdown",
        "text/html",
        "application/json",
        "application/pdf",
    }

    @classmethod
    def validate_content(cls, content: str, content_type: str = "text/plain") -> str:
        """
        Validate content for security issues.

        Args:
            content: Content to validate
            content_type: MIME type of content

        Returns:
            Validated content

        Raises:
            ValueError: If content is invalid
        """
        if not isinstance(content, str):
            raise ValueError("Content must be a string")

        if len(content) > cls.MAX_CONTENT_LENGTH:
            raise ValueError(f"Content too large: {len(content)} bytes")

        if content_type not in cls.ALLOWED_MIME_TYPES:
            raise ValueError(f"Content type {content_type} not allowed")

        # Basic XSS prevention for HTML content
        if content_type == "text/html":
            content = cls._sanitize_html(content)

        return content

    @classmethod
    def _sanitize_html(cls, html_content: str) -> str:
        """
        Basic HTML sanitization to prevent XSS.

        Args:
            html_content: HTML content to sanitize

        Returns:
            Sanitized HTML content
        """
        # Remove script tags and their content
        html_content = re.sub(
            r"<script[^>]*>.*?</script>",
            "",
            html_content,
            flags=re.DOTALL | re.IGNORECASE,
        )

        # Remove dangerous attributes
        dangerous_attrs = ["onclick", "onload", "onerror", "onmouseover", "onfocus"]
        for attr in dangerous_attrs:
            html_content = re.sub(
                rf'{attr}="[^"]*"', "", html_content, flags=re.IGNORECASE
            )
            html_content = re.sub(
                rf"{attr}='[^']*'", "", html_content, flags=re.IGNORECASE
            )

        return html_content


class SearchQueryValidator:
    """
    Search query validation to prevent injection attacks.

    Bug Fix #5: Prevents search injection vulnerabilities.
    """

    MAX_QUERY_LENGTH = 1000
    BLOCKED_CHARS = ["<", ">", '"', "'", "&", ";", "|", "`", "$"]

    @classmethod
    def validate_query(cls, query: str) -> str:
        """
        Validate search query for security issues.

        Args:
            query: Search query to validate

        Returns:
            Validated query

        Raises:
            ValueError: If query is invalid
        """
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")

        query = query.strip()

        if len(query) > cls.MAX_QUERY_LENGTH:
            raise ValueError(f"Query too long: {len(query)} characters")

        # Check for blocked characters
        for char in cls.BLOCKED_CHARS:
            if char in query:
                raise ValueError(f"Query contains blocked character: {char}")

        # Basic SQL injection prevention
        sql_keywords = [
            "DROP",
            "DELETE",
            "UPDATE",
            "INSERT",
            "CREATE",
            "ALTER",
            "EXEC",
            "UNION",
            "SELECT",
        ]
        query_upper = query.upper()
        for keyword in sql_keywords:
            if keyword in query_upper:
                raise ValueError(f"Query contains blocked keyword: {keyword}")

        return query


class DocumentMetadata(BaseModel):
    """
    Document metadata model with validation.

    Performance Optimization: Uses Pydantic for fast validation and serialization.
    """

    title: str = Field(..., max_length=200)
    description: str | None = Field(None, max_length=1000)
    tags: list[str] = Field(default_factory=list, max_length=10)
    author: str | None = Field(None, max_length=100)
    file_path: str = Field(..., min_length=1)
    content_type: str = Field(default="text/plain")
    file_size: int = Field(..., ge=0)

    @field_validator("title")
    @classmethod
    def validate_title(cls, v: str) -> str:
        """Validate document title."""
        if not v or not v.strip():
            raise ValueError("Title cannot be empty")
        return v.strip()

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: list[str]) -> list[str]:
        """Validate document tags."""
        validated_tags = []
        for tag in v:
            if tag and tag.strip():
                validated_tag = tag.strip().lower()
                if len(validated_tag) <= 50 and validated_tag not in validated_tags:
                    validated_tags.append(validated_tag)
        return validated_tags

    @field_validator("file_path")
    @classmethod
    def validate_file_path(cls, v: str) -> str:
        """Validate file path."""
        FilePathValidator.validate_path(v)
        return v

    @field_validator("content_type")
    @classmethod
    def validate_content_type(cls, v: str) -> str:
        """Validate content type."""
        if v not in ContentValidator.ALLOWED_MIME_TYPES:
            raise ValueError(f"Content type {v} not allowed")
        return v
