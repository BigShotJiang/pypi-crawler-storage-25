"""
Utility modules for documint-mcp.

This package contains utility functions for caching, validation, and other
common operations used throughout the application.
"""

from typing import TYPE_CHECKING, Any

from .validators import (
    ContentValidator,
    DocumentMetadata,
    FilePathValidator,
    SearchQueryValidator,
)

if TYPE_CHECKING:
    from .cache import CacheManager


async def get_cache(*args: Any, **kwargs: Any) -> "CacheManager":
    """Lazily load and return the cache instance."""
    from .cache import get_cache as _get_cache

    return await _get_cache(*args, **kwargs)


__all__ = [
    "get_cache",
    "FilePathValidator",
    "ContentValidator",
    "SearchQueryValidator",
    "DocumentMetadata",
]
