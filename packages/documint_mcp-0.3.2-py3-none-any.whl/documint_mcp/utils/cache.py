"""High-performance caching module with memory management optimisations."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from sys import getsizeof
from types import ModuleType
from typing import Any
from urllib.parse import urlparse

from ..config import CACHE_CONFIG, settings

redis: ModuleType | None
try:
    import redis.asyncio as redis
except ImportError:
    redis = None

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Cache entry with metadata for efficient management."""

    value: Any
    timestamp: float
    ttl: int
    access_count: int = 0
    last_access: float = 0.0

    def is_expired(self) -> bool:
        """Check if cache entry is expired."""
        return time.time() - self.timestamp > self.ttl

    def update_access(self) -> None:
        """Update access statistics."""
        self.access_count += 1
        self.last_access = time.time()


class MemoryCache:
    """
    In-memory cache with LRU eviction and memory management.

    Performance Optimization #2: Efficient memory usage
    - LRU eviction policy
    - Memory usage monitoring
    - Automatic cleanup of expired entries
    """

    def __init__(self, max_size: int = 1000, default_ttl: int = 3600):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: dict[str, CacheEntry] = {}
        self._access_order: OrderedDict[str, None] = OrderedDict()
        self._lock = asyncio.Lock()
        self._cleanup_task: asyncio.Task[None] | None = None
        self._memory_threshold = 100 * 1024 * 1024  # 100MB
        self._cleanup_started = False
        self._hits = 0
        self._misses = 0

    def _start_cleanup_task(self) -> None:
        """Start background cleanup task if not already started."""
        if self._cleanup_started:
            return
        try:
            # Only start cleanup if there's a running event loop
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No event loop running yet, will start on first use
            return

        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = loop.create_task(self._cleanup_loop())
            self._cleanup_started = True

    async def _cleanup_loop(self) -> None:
        """Background cleanup loop to prevent memory leaks."""
        while True:
            try:
                await asyncio.sleep(60)  # Run every minute
                await self._cleanup_expired()
                await self._check_memory_usage()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup loop error: {e}")
        self._cleanup_started = False

    async def _cleanup_expired(self) -> None:
        """Remove expired entries from cache."""
        async with self._lock:
            expired_keys = []
            for key, entry in self._cache.items():
                if entry.is_expired():
                    expired_keys.append(key)

            for key in expired_keys:
                del self._cache[key]
                self._access_order.pop(key, None)

            if expired_keys:
                logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")

    async def _check_memory_usage(self) -> None:
        """Monitor memory usage and evict entries if needed."""
        async with self._lock:
            estimated_size = self._estimate_memory_usage()

            if estimated_size > self._memory_threshold and self._cache:
                await self._evict_lru_entries(max(1, int(len(self._cache) * 0.2)))

    async def _evict_lru_entries(self, count: int) -> None:
        """Evict least recently used entries."""
        if not self._cache:
            return

        evicted_count = 0
        while evicted_count < count and self._access_order:
            key, _ = self._access_order.popitem(last=False)
            if key in self._cache:
                del self._cache[key]
                evicted_count += 1

        if evicted_count:
            logger.debug(f"Evicted {evicted_count} LRU cache entries")

    def _estimate_memory_usage(self) -> int:
        """Estimate memory usage of the in-memory cache."""
        size = getsizeof(self._cache) + getsizeof(self._access_order)
        for key, entry in self._cache.items():
            size += getsizeof(key)
            size += getsizeof(entry)
            size += getsizeof(entry.value)
        for key in self._access_order.keys():
            size += getsizeof(key)
        return size

    async def get(self, key: str) -> Any | None:
        """Get value from cache."""
        # Start cleanup task on first use
        self._start_cleanup_task()

        async with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None

            if entry.is_expired():
                del self._cache[key]
                self._access_order.pop(key, None)
                self._misses += 1
                return None

            entry.update_access()
            self._access_order.pop(key, None)
            self._access_order[key] = None
            self._hits += 1
            return entry.value

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set value in cache."""
        # Start cleanup task on first use
        self._start_cleanup_task()

        async with self._lock:
            if len(self._cache) >= self.max_size:
                await self._evict_lru_entries(1)

            entry = CacheEntry(
                value=value, timestamp=time.time(), ttl=ttl or self.default_ttl
            )

            self._cache[key] = entry
            self._access_order.pop(key, None)
            self._access_order[key] = None

    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
                self._access_order.pop(key, None)
                return True
            return False

    async def clear(self) -> None:
        """Clear all cache entries."""
        async with self._lock:
            self._cache.clear()
            self._access_order.clear()
            self._hits = 0
            self._misses = 0

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "memory_usage": self._estimate_memory_usage(),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self._calculate_hit_rate(),
            "cleanup_active": bool(
                self._cleanup_task and not self._cleanup_task.done()
            ),
        }

    def _calculate_hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total_requests = self._hits + self._misses
        if total_requests == 0:
            return 0.0
        return self._hits / total_requests

    async def close(self) -> None:
        """Close cache and cleanup resources."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        await self.clear()
        self._cleanup_started = False

    async def force_cleanup(self) -> None:
        """Run cleanup routines immediately.

        Exposed primarily for unit testing and emergency maintenance tasks where we
        want deterministic cleanup behaviour without waiting for the background
        task interval.
        """

        await self._cleanup_expired()
        await self._check_memory_usage()


class RedisCache:
    """
    Redis-based distributed cache with connection pooling.

    Performance Optimization #3: Connection pooling and async operations
    - Connection pooling for better performance
    - Async operations to prevent blocking
    - Automatic reconnection handling
    """

    def __init__(self, redis_url: str | None = None) -> None:
        self.redis_url = redis_url or settings.redis_url
        self.pool: Any | None = None
        self.client: Any | None = None
        self._connected = False
        self._last_error: str | None = None

    async def connect(self) -> None:
        """Connect to Redis with connection pooling."""
        if redis is None:
            logger.warning("Redis not available, falling back to memory cache")
            return

        try:
            self.pool = redis.ConnectionPool.from_url(
                self.redis_url,
                max_connections=CACHE_CONFIG["max_connections"],
                retry_on_timeout=CACHE_CONFIG["retry_on_timeout"],
                socket_connect_timeout=CACHE_CONFIG["socket_connect_timeout"],
                socket_timeout=CACHE_CONFIG["socket_timeout"],
            )

            self.client = redis.Redis(connection_pool=self.pool)

            # Test connection
            await self.client.ping()
            self._connected = True
            self._last_error = None
            logger.info("Connected to Redis cache")

        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self._connected = False
            self._last_error = str(e)

    async def get(self, key: str) -> Any | None:
        """Get value from Redis cache."""
        if not self._connected or not self.client:
            return None

        try:
            value = await self.client.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            self._last_error = str(e)
            return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> bool:
        """Set value in Redis cache."""
        if not self._connected or not self.client:
            return False

        try:
            serialized = json.dumps(value)
            if ttl:
                await self.client.setex(key, ttl, serialized)
            else:
                await self.client.set(key, serialized)
            return True
        except Exception as e:
            logger.error(f"Redis set error: {e}")
            self._last_error = str(e)
            return False

    async def delete(self, key: str) -> bool:
        """Delete key from Redis cache."""
        if not self._connected or not self.client:
            return False

        try:
            result = await self.client.delete(key)
            return result > 0
        except Exception as e:
            logger.error(f"Redis delete error: {e}")
            self._last_error = str(e)
            return False

    async def clear(self) -> None:
        """Clear all cache entries."""
        if not self._connected or not self.client:
            return

        try:
            await self.client.flushdb()
        except Exception as e:
            logger.error(f"Redis clear error: {e}")
            self._last_error = str(e)

    async def close(self) -> None:
        """Close Redis connection."""
        if self.client:
            await self.client.close()
        if self.pool:
            await self.pool.disconnect()
        self._connected = False
        self._last_error = None

    def get_stats(self) -> dict[str, Any]:
        """Expose Redis cache health information without leaking secrets."""

        redacted_url = self._redact_url(self.redis_url)
        stats: dict[str, Any] = {"connected": self._connected, "url": redacted_url}
        if self._last_error:
            stats["last_error"] = self._last_error
        return stats

    def _redact_url(self, raw_url: str) -> str:
        parsed = urlparse(raw_url)
        hostname = parsed.hostname or "localhost"
        port = f":{parsed.port}" if parsed.port else ""
        path = parsed.path or ""
        return f"{parsed.scheme}://{hostname}{port}{path}"


class CacheManager:
    """
    Multi-level cache manager with automatic fallback.

    Performance Optimization #4: Multi-level caching strategy
    - Memory cache for hot data
    - Redis cache for shared data
    - Automatic fallback between cache levels
    """

    def __init__(self) -> None:
        self.memory_cache = MemoryCache()
        self.redis_cache = RedisCache()
        self._initialized = False

    async def initialize(self) -> None:
        """Initialize cache manager."""
        if self._initialized:
            return

        await self.redis_cache.connect()
        self._initialized = True

    async def get(self, key: str) -> Any | None:
        """Get value from cache with fallback strategy."""
        # Try memory cache first
        value = await self.memory_cache.get(key)
        if value is not None:
            return value

        # Try Redis cache
        value = await self.redis_cache.get(key)
        if value is not None:
            # Store in memory cache for faster access
            await self.memory_cache.set(key, value)
            return value

        return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set value in both cache levels."""
        # Set in memory cache
        await self.memory_cache.set(key, value, ttl)

        # Set in Redis cache
        await self.redis_cache.set(key, value, ttl)

    async def delete(self, key: str) -> None:
        """Delete key from both cache levels."""
        await self.memory_cache.delete(key)
        await self.redis_cache.delete(key)

    async def clear(self) -> None:
        """Clear both cache levels."""
        await self.memory_cache.clear()
        await self.redis_cache.clear()

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        return {
            "memory_cache": self.memory_cache.get_stats(),
            "redis_cache": self.redis_cache.get_stats(),
        }

    async def close(self) -> None:
        """Close cache manager."""
        await self.memory_cache.close()
        await self.redis_cache.close()
        self._initialized = False


# Global cache manager instance
cache_manager = CacheManager()


async def get_cache() -> CacheManager:
    """Get initialized cache manager."""
    if not cache_manager._initialized:
        await cache_manager.initialize()
    return cache_manager
