"""Voyage AI embeddings and reranking for RAG.

Optional enhancement layer — everything degrades gracefully to FTS-only
if the voyageai package is not installed or the API key is not set.
"""
from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

_HAS_VOYAGE = False
_client = None

try:
    import voyageai  # noqa: PLC0415

    _HAS_VOYAGE = True
except ImportError:
    pass


def get_client():  # noqa: ANN201
    """Return a cached Voyage AI client, or None if unavailable."""
    global _client  # noqa: PLW0603
    if not _HAS_VOYAGE:
        return None
    if _client is None:
        key = os.getenv("VOYAGE_API_KEY", "")
        if not key:
            return None
        _client = voyageai.Client(api_key=key)
    return _client


def embed(
    texts: list[str], model: str = "voyage-3-lite"
) -> list[list[float]] | None:
    """Embed a list of texts using Voyage AI.

    Returns None if Voyage is unavailable or the call fails.
    """
    client = get_client()
    if not client:
        return None
    try:
        result = client.embed(texts, model=model)
        return result.embeddings
    except Exception as exc:  # noqa: BLE001
        logger.debug("Voyage embed failed: %s", exc)
        return None


def rerank(
    query: str,
    documents: list[str],
    model: str = "rerank-2",
    top_k: int = 3,
) -> list[str] | None:
    """Rerank documents for a query using Voyage AI.

    Returns reranked document strings, or None if Voyage is unavailable.
    """
    client = get_client()
    if not client:
        return None
    try:
        result = client.rerank(query, documents, model=model, top_k=top_k)
        return [documents[r.index] for r in result.results]
    except Exception as exc:  # noqa: BLE001
        logger.debug("Voyage rerank failed: %s", exc)
        return None
