"""Manage and process documents"""
from argparse import ArgumentParser, Namespace
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.tree import Tree
from rich import box

from fissionbox.cli.utils.env import (
    get_document_client,
    get_idp_client,
    get_asset_client,
    resolve_namespace_id,
)

CONSOLE = Console()

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".docx"}


# ─── Arg registration ────────────────────────────────────────────────────────

def register(parser: ArgumentParser) -> None:
    """Register commands for the document namespace."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── upload ──────────────────────────────────────────────────────────────
    upload_parser = subparsers.add_parser("upload", help="Upload source document files")
    upload_parser.add_argument("--namespace-id", type=str, default=None)
    upload_parser.add_argument("--path", type=str, required=True, help="Path to a document file or folder")

    # ── process ─────────────────────────────────────────────────────────────
    process_parser = subparsers.add_parser("process", help="Process an uploaded source document")
    process_parser.add_argument("--namespace-id", type=str, default=None)
    process_parser.add_argument("--source-path", type=str, required=True)
    process_parser.add_argument("--name", type=str, default=None)
    process_parser.add_argument("--schema-json", type=json.loads, default=None)
    process_parser.add_argument("--schema-file", type=str, default=None)
    process_parser.add_argument("--extract-diagrams", action="store_true")
    process_parser.add_argument("--extract-images", action="store_true")
    process_parser.add_argument("--response-detail", choices=["full", "extracted_only"], default="full")

    # ── run ─────────────────────────────────────────────────────────────────
    run_parser = subparsers.add_parser("run", help="Upload a local document and process it")
    run_parser.add_argument("--namespace-id", type=str, default=None)
    run_parser.add_argument("--path", type=str, required=True)
    run_parser.add_argument("--name", type=str, default=None)
    run_parser.add_argument("--schema-json", type=json.loads, default=None)
    run_parser.add_argument("--schema-file", type=str, default=None)
    run_parser.add_argument("--extract-diagrams", action="store_true")
    run_parser.add_argument("--extract-images", action="store_true")
    run_parser.add_argument("--response-detail", choices=["full", "extracted_only"], default="full")

    # ── list ────────────────────────────────────────────────────────────────
    list_parser = subparsers.add_parser("list", help="List saved processed documents")
    list_parser.add_argument("--namespace-id", type=str, default=None)
    list_parser.add_argument("--page", type=int, default=0)
    list_parser.add_argument("--size", type=int, default=50)

    # ── export-chunks ────────────────────────────────────────────────────────
    export_chunks_parser = subparsers.add_parser("export-chunks", help="Export saved chunks as NDJSON")
    export_chunks_parser.add_argument("--namespace-id", type=str, default=None)
    export_chunks_parser.add_argument("--id", type=str, required=True)
    export_chunks_parser.add_argument("--output", type=str, required=True)

    # ── queue ────────────────────────────────────────────────────────────────
    queue_parser = subparsers.add_parser(
        "queue",
        help="Upload and queue one or more documents for async processing",
    )
    queue_parser.add_argument("--namespace-id", type=str, default=None)
    queue_parser.add_argument(
        "--path",
        type=str,
        action="append",
        dest="paths",
        required=True,
        metavar="PATH",
        help="Path to a document file or folder (repeat for multiple; folders are expanded recursively)",
    )
    queue_parser.add_argument("--schema-json", type=json.loads, default=None)
    queue_parser.add_argument("--schema-file", type=str, default=None)
    queue_parser.add_argument("--extract-diagrams", action="store_true")
    queue_parser.add_argument("--extract-images", action="store_true")
    queue_parser.add_argument("--response-detail", choices=["full", "extracted_only"], default="full")
    queue_parser.add_argument(
        "--queue-output",
        type=str,
        default="fissionbox-queue.json",
        help="File to save queue state for use with watch/download (default: fissionbox-queue.json)",
    )
    queue_parser.add_argument(
        "--no-watch",
        action="store_true",
        help="Skip the live status watch after queueing",
    )
    queue_parser.add_argument(
        "--output-dir",
        type=str,
        default="./fissionbox-output",
        help="Destination folder for downloads (default: ./fissionbox-output)",
    )

    # ── watch ────────────────────────────────────────────────────────────────
    watch_parser = subparsers.add_parser(
        "watch",
        help="Poll document processing status with a live table",
    )
    watch_parser.add_argument("--namespace-id", type=str, default=None)
    _add_id_args(watch_parser)
    watch_parser.add_argument("--poll-interval", type=int, default=5, metavar="SECONDS")
    watch_parser.add_argument(
        "--no-download",
        action="store_true",
        help="Skip downloading artifacts when all documents finish",
    )
    watch_parser.add_argument("--output-dir", type=str, default="./fissionbox-output")

    # ── download ─────────────────────────────────────────────────────────────
    download_parser = subparsers.add_parser(
        "download",
        help="Download results for processed documents into per-document folders",
    )
    download_parser.add_argument("--namespace-id", type=str, default=None)
    _add_id_args(download_parser)
    download_parser.add_argument("--output-dir", type=str, default="./fissionbox-output")

    # ── annotate ─────────────────────────────────────────────────────────────
    annotate_parser = subparsers.add_parser(
        "annotate",
        help="Generate an annotated PDF for a processed document",
    )
    annotate_parser.add_argument("--namespace-id", type=str, default=None)
    annotate_parser.add_argument("--id", type=str, required=True, help="Document ID")
    annotate_parser.add_argument(
        "--detail",
        choices=["chunks", "tables", "cells", "all"],
        default=None,
    )
    annotate_parser.add_argument("--no-labels", action="store_true")

    # ── retry ─────────────────────────────────────────────────────────────────
    retry_parser = subparsers.add_parser("retry", help="Retry a failed or ready document run")
    retry_parser.add_argument("--namespace-id", type=str, default=None)
    retry_parser.add_argument("--id", type=str, required=True, help="Document ID")


def _add_id_args(parser: ArgumentParser) -> None:
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--id",
        type=str,
        action="append",
        dest="ids",
        metavar="ID",
        help="Document ID (repeat for multiple)",
    )
    group.add_argument(
        "--queue-file",
        type=str,
        metavar="FILE",
        help="Queue JSON file saved by `fissionbox document queue`",
    )


# ─── Utilities ───────────────────────────────────────────────────────────────

def _print_json(payload) -> None:
    print(json.dumps(payload, indent=2))


def _resolve_schema(args: Namespace):
    if getattr(args, "schema_json", None) and getattr(args, "schema_file", None):
        raise ValueError("Use either --schema-json or --schema-file, not both.")
    if getattr(args, "schema_file", None):
        with open(args.schema_file, "r", encoding="utf-8") as handle:
            return json.load(handle)
    return getattr(args, "schema_json", None)


def _resolve_document_context(args: Namespace):
    namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
    return namespace_id, get_document_client(namespace_id)


def _confirm_folder_upload(path: str) -> bool:
    yes = input(
        f"The path {path} is a directory. Upload all supported documents? (y/n): "
    )
    return yes.lower() == "y"


def _upload_documents(client, namespace_id: str, path: str):
    if os.path.isdir(path):
        if not _confirm_folder_upload(path):
            print("Upload cancelled.")
            return None
        return client.upload_folder(namespace_id, path)
    return {path: client.upload(namespace_id, path)}


def _expand_paths(raw_paths: List[str]) -> List[Path]:
    """Resolve a mix of file and folder paths into a flat, sorted list of document files."""
    files: List[Path] = []
    for raw in raw_paths:
        p = Path(raw)
        if not p.exists():
            raise FileNotFoundError(f"Path not found: {raw}")
        if p.is_dir():
            found = sorted(
                c for c in p.rglob("*")
                if c.is_file() and c.suffix.lower() in ALLOWED_EXTENSIONS
            )
            if not found:
                raise ValueError(
                    f"No supported documents found in {raw} "
                    f"(supported: {', '.join(sorted(ALLOWED_EXTENSIONS))})"
                )
            files.extend(found)
        else:
            if p.suffix.lower() not in ALLOWED_EXTENSIONS:
                raise ValueError(
                    f"Unsupported file type: {p.name} "
                    f"(supported: {', '.join(sorted(ALLOWED_EXTENSIONS))})"
                )
            files.append(p)
    return files


def _load_ids_from_args(args: Namespace):
    """Return (namespace_id, document_ids) from --id / --queue-file args."""
    namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
    if getattr(args, "queue_file", None):
        with open(args.queue_file, "r", encoding="utf-8") as f:
            queue = json.load(f)
        ns_from_file = queue.get("namespace_id")
        if ns_from_file and ns_from_file != namespace_id:
            namespace_id = ns_from_file
        ids = [item["document_id"] for item in queue.get("items", [])]
        return namespace_id, ids
    return namespace_id, list(args.ids or [])


def _sanitize_dirname(name: str) -> str:
    return "".join(c if c.isalnum() or c in "-_ " else "_" for c in name).strip() or "document"


def _fmt_size(n_bytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n_bytes < 1024:
            return f"{n_bytes:.0f} {unit}"
        n_bytes /= 1024
    return f"{n_bytes:.1f} GB"


# ─── Upload progress ─────────────────────────────────────────────────────────

def _upload_with_progress(doc_client, namespace_id: str, all_files: List[Path]) -> List[str]:
    source_paths: List[str] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=CONSOLE,
    ) as progress:
        task = progress.add_task("[cyan]Uploading[/cyan]", total=len(all_files))
        for file_path in all_files:
            size_str = _fmt_size(file_path.stat().st_size)
            progress.update(
                task,
                description=f"[cyan]Uploading[/cyan]  {file_path.name} [dim]({size_str})[/dim]",
            )
            stored_path = doc_client.upload(namespace_id, str(file_path))
            source_paths.append(stored_path)
            progress.advance(task)
        progress.update(task, description="[green]Upload complete[/green]")

    return source_paths


# ─── Watch live table ────────────────────────────────────────────────────────

_STATUS_STYLE = {
    "queued":     ("⏸  queued",      "bold yellow"),
    "processing": ("⟳  processing",  "bold blue"),
    "ready":      ("✓  ready",        "bold green"),
    "failed":     ("✗  failed",       "bold red"),
}


def _status_text(status: str) -> Text:
    label, style = _STATUS_STYLE.get(status, (status or "unknown", "dim"))
    return Text(label, style=style)


def _elapsed_str(queued_at_iso: Optional[str]) -> str:
    if not queued_at_iso:
        return "—"
    try:
        queued_at = datetime.fromisoformat(queued_at_iso.replace("Z", "+00:00"))
        secs = int((datetime.now(timezone.utc) - queued_at).total_seconds())
        if secs < 60:
            return f"{secs}s"
        return f"{secs // 60}m {secs % 60}s"
    except Exception:
        return "—"


def _build_watch_table(doc_states: Dict[str, Any]) -> Table:
    table = Table(box=box.ROUNDED, expand=True, show_footer=False, border_style="dim blue")
    table.add_column("ID",        style="dim cyan",   no_wrap=True, width=18)
    table.add_column("Name",      style="bold",        min_width=14)
    table.add_column("File",      style="dim",         min_width=16)
    table.add_column("Status",    min_width=16)
    table.add_column("Elapsed",   justify="right",     width=9)
    table.add_column("Chunks",    justify="right",     width=7)
    table.add_column("Images",    justify="right",     width=7)
    table.add_column("Artifacts", style="dim green",   min_width=28)

    for doc_id, state in doc_states.items():
        status   = state.get("status", "unknown")
        metadata = state.get("metadata") or {}
        attrs    = state.get("attributes") or {}

        artifacts = []
        if metadata.get("responsePath"):    artifacts.append("response")
        if metadata.get("markdownPath"):    artifacts.append("markdown")
        if metadata.get("chunksNdjsonPath"):artifacts.append("chunks")
        if metadata.get("imageMetadataPath"):artifacts.append("images")
        if metadata.get("annotatedPdfPath"):artifacts.append("annotated-pdf")

        table.add_row(
            doc_id[-16:],
            attrs.get("name") or state.get("name") or "…",
            attrs.get("sourceFilename") or "…",
            _status_text(status),
            _elapsed_str(metadata.get("queuedAt") or state.get("queued_at")),
            str(attrs.get("chunkCount", 0)) if status == "ready" else "—",
            str(attrs.get("imageCount", 0)) if status == "ready" else "—",
            ", ".join(artifacts) if artifacts else "—",
        )

    return table


def _watch_header(doc_states: Dict[str, Any], namespace_id: str, poll_interval: int) -> Panel:
    ready   = sum(1 for s in doc_states.values() if s.get("status") == "ready")
    failed  = sum(1 for s in doc_states.values() if s.get("status") == "failed")
    pending = len(doc_states) - ready - failed
    ts      = datetime.now().strftime("%H:%M:%S")

    parts = [
        ("Namespace: ", "dim"), (namespace_id, "cyan bold"),
        ("   ·   ", "dim"),
        (f"{len(doc_states)} document{'s' if len(doc_states) != 1 else ''}",  "bold"),
        ("   ·   ", "dim"),
    ]
    if ready:
        parts.append((f"✓ {ready} ready  ", "green bold"))
    if failed:
        parts.append((f"✗ {failed} failed  ", "red bold"))
    if pending:
        parts.append((f"⟳ {pending} processing/queued  ", "yellow"))
    parts += [("   updated ", "dim"), (ts, "dim"), (f"  (poll every {poll_interval}s)", "dim")]

    return Panel(
        Text.assemble(*parts),
        title="[bold]FissionBox Document Queue[/bold]",
        border_style="blue",
    )


def _all_terminal(doc_states: Dict[str, Any]) -> bool:
    return all(s.get("status") in ("ready", "failed") for s in doc_states.values())


def _poll_once(document_client, namespace_id: str, doc_states: Dict[str, Any]) -> None:
    for doc_id in list(doc_states.keys()):
        try:
            doc = document_client.get(namespace_id, doc_id)
            metadata = doc.get("metadata") or {}
            attrs    = doc.get("attributes") or {}
            doc_states[doc_id].update({
                "status":     metadata.get("status", "unknown"),
                "metadata":   metadata,
                "attributes": attrs,
            })
        except Exception:
            pass


def _watch_live(
    namespace_id: str,
    document_ids: List[str],
    doc_states: Dict[str, Any],
    poll_interval: int,
) -> None:
    document_client = get_document_client(namespace_id)

    with Live(console=CONSOLE, refresh_per_second=4) as live:
        while True:
            _poll_once(document_client, namespace_id, doc_states)
            live.update(Group(
                _watch_header(doc_states, namespace_id, poll_interval),
                _build_watch_table(doc_states),
            ))
            if _all_terminal(doc_states):
                break
            time.sleep(poll_interval)

    # Final summary rule
    ready_count  = sum(1 for s in doc_states.values() if s.get("status") == "ready")
    failed_count = sum(1 for s in doc_states.values() if s.get("status") == "failed")
    summary = Text.assemble(
        ("  Done.  ", "bold"),
        (f"✓ {ready_count} ready", "green bold"),
        (f"   ✗ {failed_count} failed" if failed_count else "", "red bold"),
    )
    CONSOLE.print(Rule(summary, style="green" if not failed_count else "yellow"))


# ─── Download ────────────────────────────────────────────────────────────────

def _collect_download_tasks(
    namespace_id: str,
    doc_id: str,
    doc_state: Dict,
    output_dir: str,
) -> tuple[Path, List[tuple[str, str]]]:
    """Return (dest_folder, [(filename, asset_path), ...]) for one document."""
    metadata = doc_state.get("metadata") or {}
    attrs    = doc_state.get("attributes") or {}
    name     = attrs.get("name") or doc_state.get("name") or doc_id
    folder   = Path(output_dir) / _sanitize_dirname(name)

    tasks: List[tuple[str, str]] = []
    for filename, path in {
        "response.json":  metadata.get("responsePath"),
        "markdown.md":    metadata.get("markdownPath"),
        "extracted.json": metadata.get("extractedPath"),
        "chunks.ndjson":  metadata.get("chunksNdjsonPath"),
        "images.json":    metadata.get("imageMetadataPath"),
        "annotated.pdf":  metadata.get("annotatedPdfPath"),
    }.items():
        if path:
            tasks.append((filename, path))

    for img_path in (metadata.get("imagePaths") or []):
        tasks.append((f"images/{Path(img_path).name}", img_path))

    return folder, tasks


def _download_all(namespace_id: str, doc_states: Dict[str, Any], output_dir: str) -> None:
    asset_client = get_asset_client()

    # Tally everything up front so the progress bar has a correct total
    plan: List[tuple[str, Path, List[tuple[str, str]]]] = []
    for doc_id, state in doc_states.items():
        if state.get("status") != "ready":
            name = (state.get("attributes") or {}).get("name") or doc_id
            CONSOLE.print(
                f"  [yellow]⚠[/yellow]  Skipping [bold]{name}[/bold] "
                f"— status: [yellow]{state.get('status', 'unknown')}[/yellow]"
            )
            continue
        folder, tasks = _collect_download_tasks(namespace_id, doc_id, state, output_dir)
        plan.append((doc_id, folder, tasks))

    if not plan:
        return

    total_files = sum(len(tasks) for _, _, tasks in plan)

    CONSOLE.print()
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=CONSOLE,
    ) as progress:
        overall = progress.add_task(
            f"[cyan]Downloading[/cyan] {len(plan)} document(s)",
            total=total_files,
        )

        for doc_id, folder, tasks in plan:
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "images").mkdir(exist_ok=True)

            doc_task = progress.add_task(
                f"  [dim]{folder.name}[/dim]",
                total=len(tasks),
                visible=True,
            )

            doc_tree = Tree(
                f"[bold cyan]{folder.name}[/bold cyan]  [dim]({doc_id[-16:]})[/dim]",
                guide_style="dim blue",
            )

            for filename, asset_path in tasks:
                dest = folder / filename
                dest.parent.mkdir(parents=True, exist_ok=True)
                progress.update(
                    overall,
                    description=f"[cyan]Downloading[/cyan]  [dim]{filename}[/dim]",
                )
                try:
                    asset_client.download(namespace_id, asset_path, str(dest))
                    size_str = _fmt_size(dest.stat().st_size)
                    doc_tree.add(f"[green]✓[/green]  {filename}  [dim]{size_str}[/dim]")
                except Exception as exc:
                    doc_tree.add(f"[red]✗[/red]  {filename}  [dim red]{exc}[/dim red]")
                progress.advance(doc_task)
                progress.advance(overall)

            progress.update(doc_task, visible=False)
            CONSOLE.print(doc_tree)
            CONSOLE.print(f"  [dim]→ {folder.resolve()}[/dim]")

        progress.update(
            overall,
            description=f"[green]Downloaded {total_files} file(s)[/green]",
        )


# ─── Command handlers ────────────────────────────────────────────────────────

def main(args: Namespace) -> None:
    # ── upload ───────────────────────────────────────────────────────────────
    if args.command == "upload":
        namespace_id, client = _resolve_document_context(args)
        response = _upload_documents(client, namespace_id, args.path)
        if response is not None:
            _print_json(response)
        return

    # ── process ──────────────────────────────────────────────────────────────
    if args.command == "process":
        namespace_id, client = _resolve_document_context(args)
        response = client.process(
            namespace_id=namespace_id,
            source_path=args.source_path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            extract_images=args.extract_images,
            response_detail=args.response_detail,
        )
        _print_json(response)
        return

    # ── run ──────────────────────────────────────────────────────────────────
    if args.command == "run":
        namespace_id, client = _resolve_document_context(args)
        response = client.run(
            namespace_id=namespace_id,
            path=args.path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            extract_images=args.extract_images,
            response_detail=args.response_detail,
        )
        _print_json(response)
        return

    # ── list ─────────────────────────────────────────────────────────────────
    if args.command == "list":
        namespace_id, client = _resolve_document_context(args)
        response = client.list(namespace_id, page=args.page, size=args.size)
        _print_json(response)
        return

    # ── export-chunks ─────────────────────────────────────────────────────────
    if args.command == "export-chunks":
        namespace_id, client = _resolve_document_context(args)
        output = client.export_chunks(namespace_id, args.id, args.output)
        _print_json({"output": output})
        return

    # ── queue ─────────────────────────────────────────────────────────────────
    if args.command == "queue":
        namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
        doc_client   = get_document_client(namespace_id)
        idp_client   = get_idp_client()
        schema       = _resolve_schema(args)

        # Resolve paths
        try:
            all_files = _expand_paths(args.paths)
        except (FileNotFoundError, ValueError) as exc:
            CONSOLE.print(f"[red]Error:[/red] {exc}")
            raise SystemExit(1)

        CONSOLE.print(Rule("[bold]FissionBox — Queue Documents[/bold]", style="blue"))

        # Show what was found
        folder_count = sum(1 for p in args.paths if Path(p).is_dir())
        if folder_count:
            CONSOLE.print(
                f"  [dim]Found [bold]{len(all_files)}[/bold] document(s) "
                f"in {folder_count} folder(s)[/dim]"
            )
        for f in all_files:
            CONSOLE.print(f"  [dim cyan]·[/dim cyan]  {f.name}  [dim]({_fmt_size(f.stat().st_size)})[/dim]")
        CONSOLE.print()

        # Upload
        source_paths = _upload_with_progress(doc_client, namespace_id, all_files)
        CONSOLE.print(f"  [green]✓[/green]  Uploaded [bold]{len(source_paths)}[/bold] file(s)\n")

        # Queue
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=CONSOLE, transient=True) as p:
            t = p.add_task("[cyan]Sending to queue…[/cyan]")
            result = idp_client.queue_batch(
                namespace_id=namespace_id,
                source_paths=source_paths,
                extraction_schema=schema,
                extract_diagrams=args.extract_diagrams,
                extract_images=args.extract_images,
                response_detail=args.response_detail,
            )
            p.update(t, description="[green]Queued[/green]")

        items = result.get("items", [])
        CONSOLE.print(f"  [green]✓[/green]  Queued [bold]{len(items)}[/bold] document run(s)")

        # Save queue file
        queue_data = {
            "namespace_id": namespace_id,
            "queued_at": datetime.now(timezone.utc).isoformat(),
            "items": items,
        }
        with open(args.queue_output, "w", encoding="utf-8") as f:
            json.dump(queue_data, f, indent=2)
        CONSOLE.print(f"  [dim]Queue state saved → {args.queue_output}[/dim]\n")

        if args.no_watch:
            _print_json(queue_data)
            return

        # Watch
        doc_states = {
            item["document_id"]: {
                "name":       item.get("name"),
                "queued_at":  queue_data["queued_at"],
                "status":     item.get("status", "queued"),
                "metadata":   {},
                "attributes": {},
            }
            for item in items
        }
        _watch_live(namespace_id, [i["document_id"] for i in items], doc_states, poll_interval=5)

        # Download
        CONSOLE.print(Rule("[bold]Downloading Artifacts[/bold]", style="blue"))
        _download_all(namespace_id, doc_states, args.output_dir)
        CONSOLE.print()
        CONSOLE.print(Rule("[green]All done[/green]", style="green"))
        return

    # ── watch ─────────────────────────────────────────────────────────────────
    if args.command == "watch":
        namespace_id, document_ids = _load_ids_from_args(args)
        doc_states = {
            doc_id: {"status": "unknown", "metadata": {}, "attributes": {}}
            for doc_id in document_ids
        }
        _watch_live(namespace_id, document_ids, doc_states, args.poll_interval)

        if not getattr(args, "no_download", False):
            CONSOLE.print(Rule("[bold]Downloading Artifacts[/bold]", style="blue"))
            _download_all(namespace_id, doc_states, args.output_dir)
            CONSOLE.print(Rule("[green]All done[/green]", style="green"))
        return

    # ── download ──────────────────────────────────────────────────────────────
    if args.command == "download":
        namespace_id, document_ids = _load_ids_from_args(args)
        doc_client = get_document_client(namespace_id)

        doc_states: Dict[str, Any] = {}
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            MofNCompleteColumn(),
            console=CONSOLE,
            transient=True,
        ) as progress:
            task = progress.add_task("Fetching document info…", total=len(document_ids))
            for doc_id in document_ids:
                doc = doc_client.get(namespace_id, doc_id)
                doc_states[doc_id] = {
                    "status":     (doc.get("metadata") or {}).get("status", "unknown"),
                    "metadata":   doc.get("metadata") or {},
                    "attributes": doc.get("attributes") or {},
                }
                progress.advance(task)

        CONSOLE.print(Rule("[bold]Downloading Artifacts[/bold]", style="blue"))
        _download_all(namespace_id, doc_states, args.output_dir)
        CONSOLE.print(Rule("[green]All done[/green]", style="green"))
        return

    # ── annotate ──────────────────────────────────────────────────────────────
    if args.command == "annotate":
        namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
        idp_client = get_idp_client()
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=CONSOLE, transient=True) as p:
            t = p.add_task(f"[cyan]Generating annotated PDF for {args.id}…[/cyan]")
            result = idp_client.annotate_stored(
                namespace_id=namespace_id,
                document_id=args.id,
                detail=args.detail,
                show_labels=not args.no_labels,
            )
            p.update(t, description="[green]Done[/green]")
        CONSOLE.print(f"  [green]✓[/green]  {result.get('boxes_drawn', 0)} box(es) drawn")
        if result.get("annotated_pdf_path"):
            CONSOLE.print(f"  [dim]Path: {result['annotated_pdf_path']}[/dim]")
        return

    # ── retry ─────────────────────────────────────────────────────────────────
    if args.command == "retry":
        namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
        idp_client = get_idp_client()
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=CONSOLE, transient=True) as p:
            t = p.add_task(f"[cyan]Retrying {args.id}…[/cyan]")
            result = idp_client.retry_run(namespace_id=namespace_id, document_id=args.id)
            p.update(t, description="[green]Requeued[/green]")
        items = result.get("items", [])
        if items:
            CONSOLE.print(f"  [green]✓[/green]  Requeued as task [cyan]{items[0].get('task_id')}[/cyan]")
        return

    CONSOLE.print(f"[red]Unknown command:[/red] {args.command}")
