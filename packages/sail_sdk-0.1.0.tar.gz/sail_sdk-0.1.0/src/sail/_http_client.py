from __future__ import annotations

import json
import urllib.error
import urllib.request

from sail._config import Config


class HTTPClient:
    """Thin HTTP client for the Sail REST API."""

    _instance: HTTPClient | None = None

    def __init__(self, config: Config | None = None) -> None:
        self._config = config or Config.from_env()
        if not self._config.api_url:
            raise ValueError(
                "SAIL_API_URL must be set (e.g. https://api.sailresearch.com)"
            )

    @classmethod
    def get(cls) -> HTTPClient:
        """Return the singleton client, creating it on first call."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Close and discard the singleton (useful for tests)."""
        cls._instance = None

    def post(self, path: str, body: dict) -> tuple[int, dict]:
        """POST JSON to {api_url}{path}, return (status_code, parsed_json)."""
        url = self._config.api_url.rstrip("/") + path
        data = json.dumps(body).encode()
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Authorization": f"Bearer {self._config.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_bytes = e.read()
            try:
                return e.code, json.loads(body_bytes)
            except (json.JSONDecodeError, ValueError):
                return e.code, {
                    "error": {"message": body_bytes.decode(errors="replace")}
                }
