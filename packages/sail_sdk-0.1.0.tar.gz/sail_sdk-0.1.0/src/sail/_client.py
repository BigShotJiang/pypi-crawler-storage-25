from __future__ import annotations

import sys
from pathlib import Path

# The generated proto stubs use absolute imports (e.g. ``from scheduler.v1 import
# scheduler_pb2``). Adding the ``pb/`` directory to sys.path makes those imports
# resolve correctly.
_PB_DIR = str(Path(__file__).resolve().parent / "pb")
if _PB_DIR not in sys.path:
    sys.path.insert(0, _PB_DIR)

import grpc  # noqa: E402
from scheduler.v1 import scheduler_pb2_grpc  # noqa: E402

from sail._config import Config  # noqa: E402


def open_channel(target: str) -> grpc.Channel:
    if target.startswith(("localhost:", "127.0.0.1:", "[::1]:")):
        return grpc.insecure_channel(target)
    return grpc.secure_channel(target, grpc.ssl_channel_credentials())


class Client:
    """Manages the gRPC channel to the sailbox scheduler."""

    _instance: Client | None = None

    def __init__(self, config: Config | None = None) -> None:
        self._config = config or Config.from_env()
        self._channel = open_channel(self._config.scheduler_url)
        self._stub = scheduler_pb2_grpc.SchedulerServiceStub(self._channel)

    @classmethod
    def get(cls) -> Client:
        """Return the singleton client, creating it on first call."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Close and discard the singleton (useful for tests)."""
        if cls._instance is not None:
            cls._instance.close()
            cls._instance = None

    @property
    def stub(self) -> scheduler_pb2_grpc.SchedulerServiceStub:
        return self._stub

    def metadata(self) -> list[tuple[str, str]]:
        """Return gRPC call metadata with the authorization header."""
        return [("authorization", f"Bearer {self._config.api_key}")]

    def close(self) -> None:
        if self._channel is not None:
            self._channel.close()


def open_channel(target: str) -> grpc.Channel:
    if _is_local_target(target):
        return grpc.secure_channel(target, grpc.local_channel_credentials())
    return grpc.secure_channel(target, grpc.ssl_channel_credentials())


def _is_local_target(target: str) -> bool:
    host = target.split(":", 1)[0].strip().lower()
    return host in {"localhost", "127.0.0.1", "[::1]"}
