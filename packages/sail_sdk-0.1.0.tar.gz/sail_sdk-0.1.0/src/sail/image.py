from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

import sail._client  # noqa: F401
from sail._client import Client
from sail.errors import ImageBuildError
from scheduler.v1 import scheduler_pb2


@dataclass(frozen=True)
class ImageDefinition:
    _spec: scheduler_pb2.ImageSpec
    _image_id: str | None = field(default=None)

    def to_proto(self) -> scheduler_pb2.ImageSpec:
        return self._spec

    def apt_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "apt_install")
        step = scheduler_pb2.ImageBuildStep(
            apt_install=scheduler_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def pip_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "pip_install")
        step = scheduler_pb2.ImageBuildStep(
            pip_install=scheduler_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def run_commands(self, *cmd: str) -> ImageDefinition:
        if not cmd:
            raise ValueError("run_commands requires at least one command")
        steps = []
        for entry in cmd:
            cleaned = entry.strip()
            if not cleaned:
                raise ValueError("run_commands commands must be non-empty")
            steps.append(
                scheduler_pb2.ImageBuildStep(
                    run_command=scheduler_pb2.RunCommand(command=cleaned)
                )
            )
        image = self
        for step in steps:
            image = image._append_step(step)
        return image

    def env(self, env: dict[str, str]) -> ImageDefinition:
        if not env:
            raise ValueError("env requires at least one key")
        next_spec = scheduler_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        for key, value in env.items():
            clean_key = key.strip()
            if not clean_key:
                raise ValueError("env keys must be non-empty")
            next_spec.env[clean_key] = value
        return ImageDefinition(next_spec, _image_id=None)

    def build(self, *, timeout: int = 1800) -> ImageDefinition:
        if timeout <= 0:
            raise ValueError("timeout must be greater than 0")

        client = Client.get()
        spec = scheduler_pb2.ImageSpec()
        spec.CopyFrom(self.to_proto())
        resp = client.stub.BuildImage(
            scheduler_pb2.BuildImageRequest(image=spec),
            metadata=client.metadata(),
        )
        image_id = resp.image_id
        deadline = time.monotonic() + timeout

        while True:
            status = resp.status
            if status == scheduler_pb2.IMAGE_BUILD_STATUS_READY:
                return ImageDefinition(spec, _image_id=image_id)
            if status == scheduler_pb2.IMAGE_BUILD_STATUS_FAILED:
                raise ImageBuildError(resp.error_message or "image build failed")
            if time.monotonic() >= deadline:
                raise TimeoutError(f"timed out waiting for image build {image_id}")
            time.sleep(_next_build_poll_delay())
            resp = client.stub.GetImageBuildStatus(
                scheduler_pb2.GetImageBuildStatusRequest(image_id=image_id),
                metadata=client.metadata(),
            )

    def _append_step(self, step: scheduler_pb2.ImageBuildStep) -> ImageDefinition:
        next_spec = scheduler_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        next_spec.build_steps.append(step)
        return ImageDefinition(next_spec, _image_id=None)


def _clean_packages(packages: tuple[str, ...], method: str) -> list[str]:
    if not packages:
        raise ValueError(f"{method} requires at least one package")
    cleaned: list[str] = []
    for package in packages:
        entry = package.strip()
        if not entry:
            raise ValueError(f"{method} packages must be non-empty")
        cleaned.append(entry)
    return cleaned


def _next_build_poll_delay() -> float:
    return 1.0 + random.uniform(0.0, 0.25)


def _architecture_proto(architecture: str) -> scheduler_pb2.ImageArchitecture:
    if architecture == "amd64":
        return scheduler_pb2.IMAGE_ARCHITECTURE_AMD64
    if architecture == "arm64":
        return scheduler_pb2.IMAGE_ARCHITECTURE_ARM64
    raise ValueError(f"unsupported architecture {architecture!r}")


class _ImageNamespace:
    @property
    def debian_amd64(self) -> ImageDefinition:
        return ImageDefinition(
            scheduler_pb2.ImageSpec(
                base=scheduler_pb2.BASE_IMAGE_DEBIAN,
                architecture=scheduler_pb2.IMAGE_ARCHITECTURE_AMD64,
            )
        )

    @property
    def debian_amd(self) -> ImageDefinition:
        return self.debian_amd64

    @property
    def debian_arm64(self) -> ImageDefinition:
        return ImageDefinition(
            scheduler_pb2.ImageSpec(
                base=scheduler_pb2.BASE_IMAGE_DEBIAN,
                architecture=scheduler_pb2.IMAGE_ARCHITECTURE_ARM64,
            )
        )

    @property
    def debian_arm(self) -> ImageDefinition:
        return self.debian_arm64


Image = _ImageNamespace()
