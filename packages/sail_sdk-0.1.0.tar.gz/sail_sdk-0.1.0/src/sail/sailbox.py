from __future__ import annotations

import json
import shlex
from dataclasses import dataclass
from typing import Any

import grpc
from sail._client import Client, open_channel
from sail.image import ImageDefinition
from sail.errors import (
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
    SailboxWorkerLostError,
)

# Import after _client has set up sys.path for proto stubs.
from scheduler.v1 import scheduler_pb2  # noqa: E402
from workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc  # noqa: E402


@dataclass(frozen=True)
class SailboxExecResult:
    stdout: str
    stderr: str
    returncode: int


@dataclass(frozen=True)
class SailboxResponse:
    status_code: int
    headers: dict[str, str]
    content: bytes

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.text)


@dataclass(frozen=True)
class SailboxRequest:
    sailbox_id: str
    request_id: str
    exec_endpoint: str
    status: str
    response: SailboxResponse | None = None
    error_message: str = ""

    @property
    def id(self) -> str:
        return self.request_id

    def _apply_update(self, updated: SailboxRequest) -> SailboxRequest:
        object.__setattr__(self, "status", updated.status)
        object.__setattr__(self, "response", updated.response)
        object.__setattr__(self, "error_message", updated.error_message)
        return self

    def refresh(self) -> SailboxRequest:
        try:
            with open_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetNetworkRequest(
                    workerproxy_pb2.GetNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def wait(self, timeout: float | None = None) -> SailboxRequest:
        try:
            with open_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.WaitNetworkRequest(
                    workerproxy_pb2.WaitNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                    timeout=timeout,
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def cancel(self) -> SailboxRequest:
        try:
            with open_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.CancelNetworkRequest(
                    workerproxy_pb2.CancelNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )


@dataclass(frozen=True)
class SailboxListener:
    sailbox_id: str
    port: int
    url: str
    protocol: str
    route_status: str


@dataclass(frozen=True)
class SailboxExecRequest:
    sailbox_id: str
    exec_request_id: str
    exec_endpoint: str
    background: bool = False

    def wait(self) -> SailboxExecResult:
        """Wait for the exec request to complete.

        For foreground execs this waits for the command itself to finish.
        For background execs this waits only for the detached launcher shell to
        succeed or fail; it does not wait for the long-lived background process.
        """
        try:
            with open_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.WaitSailboxExec(
                    workerproxy_pb2.WaitSailboxExecRequest(
                        sailbox_id=self.sailbox_id,
                        exec_request_id=self.exec_request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_exec_rpc_error(exc) from exc
        if resp.status == workerproxy_pb2.SAILBOX_EXEC_STATUS_WORKER_LOST:
            raise SailboxWorkerLostError(
                resp.stderr or "assigned worker was lost; call start() and retry"
            )
        return SailboxExecResult(
            stdout=resp.stdout,
            stderr=resp.stderr,
            returncode=resp.return_code,
        )


from sail.app import App  # noqa: E402


@dataclass(frozen=True)
class Sailbox:
    """A sandbox instance on the Sail platform.

    Identifiers on this type:

    - ``sailbox_id`` is the stable Sail control-plane identifier for the
      sandbox. This is the main external ID and the one used for follow-up
      operations like terminate/status lookup.
    - ``worker_address`` is the scheduler's internal address for the worker
      currently hosting the sailbox. It is operational metadata, not a
      client-facing endpoint.
    - ``exec_endpoint`` is the client-reachable worker-proxy endpoint for exec
      requests.

    In practice, callers should treat ``sailbox_id`` as the primary ID. The
    other fields are useful to surface for debugging, but they are not the
    durable external handle for the resource.
    """

    sailbox_id: str
    name: str
    status: str
    worker_address: str
    exec_endpoint: str

    @classmethod
    def create(
        cls,
        *,
        image: ImageDefinition,
        app: App,
        name: str,
        memory: int = 512,
        cpu: int = 1,
        ingress_ports: list[int] | None = None,
    ) -> Sailbox:
        """Create a new sailbox.

        Sends a synchronous CreateSailbox RPC that returns once the VM is
        running or creation has failed.
        """
        if not isinstance(image, ImageDefinition):
            raise TypeError("image must be a sail.Image value")

        client = Client.get()
        try:
            resp = client.stub.CreateSailbox(
                scheduler_pb2.CreateSailboxRequest(
                    app_id=app.id,
                    name=name,
                    cpu=cpu,
                    memory_mib=memory,
                    image=image.to_proto(),
                    ingress_ports=ingress_ports or [],
                ),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc

        if resp.status == scheduler_pb2.SAILBOX_STATUS_FAILED:
            raise SailboxCreationError(f"Sailbox creation failed: {resp.error_message}")
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"Sailbox creation returned unexpected status: {resp.status}"
            )

        return cls(
            sailbox_id=resp.sailbox_id,
            name=name,
            status="running",
            worker_address=resp.worker_address,
            exec_endpoint=resp.exec_proxy_endpoint,
        )

    def terminate(self) -> None:
        """Permanently terminate this sailbox."""
        client = Client.get()
        try:
            resp = client.stub.TerminateSailbox(
                scheduler_pb2.TerminateSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            code = exc.code()
            details = exc.details() or ""
            if code == grpc.StatusCode.NOT_FOUND:
                return
            if code == grpc.StatusCode.FAILED_PRECONDITION and "TERMINATED" in details:
                return
            raise
        if resp.status == scheduler_pb2.SAILBOX_STATUS_TERMINATED:
            return

    def stop(self) -> None:
        """Checkpoint and stop this sailbox so it can be started again later."""
        client = Client.get()
        try:
            resp = client.stub.StopSailbox(
                scheduler_pb2.StopSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.status != scheduler_pb2.SAILBOX_STATUS_STOPPED:
            raise SailboxCreationError(
                f"StopSailbox returned unexpected status: {resp.status}"
            )
        object.__setattr__(self, "status", "stopped")
        object.__setattr__(self, "worker_address", "")

    def checkpoint(self) -> None:
        """Durably checkpoint this running sailbox without stopping it."""
        client = Client.get()
        try:
            resp = client.stub.CheckpointSailbox(
                scheduler_pb2.CheckpointSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"CheckpointSailbox returned unexpected status: {resp.status}"
            )

    def start(self) -> Sailbox:
        """Resume this sailbox through scheduler."""
        client = Client.get()
        try:
            resp = client.stub.ResumeSailbox(
                scheduler_pb2.ResumeSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.resume_state == scheduler_pb2.SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE:
            raise SailboxCreationError(
                resp.error_message or "sailbox cannot be resumed"
            )
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"ResumeSailbox returned unexpected status: {resp.status}"
            )
        # Sailbox is a frozen dataclass, so in-place refreshes must bypass normal
        # attribute assignment.
        object.__setattr__(self, "status", "running")
        object.__setattr__(
            self,
            "worker_address",
            resp.worker_internal_address or resp.worker_address,
        )
        return self

    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        data: bytes | str | None = None,
        json: Any | None = None,
        timeout: int | None = None,
        durability: str = "tracked",
        idempotency_key: str | None = None,
    ) -> SailboxRequest:
        if not method:
            raise ValueError("method must be non-empty")
        if not url:
            raise ValueError("url must be non-empty")
        if not idempotency_key or not idempotency_key.strip():
            raise ValueError("idempotency_key must be non-empty")
        if data is not None and json is not None:
            raise ValueError("data and json are mutually exclusive")

        body = b""
        request_headers = dict(headers or {})
        if json is not None:
            body = _json_dumps_bytes(json)
            request_headers.setdefault("Content-Type", "application/json")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        elif data is not None:
            body = data

        client = Client.get()
        with open_channel(self.exec_endpoint) as channel:
            stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
            resp = stub.CreateNetworkRequest(
                workerproxy_pb2.CreateNetworkRequestRequest(
                    sailbox_id=self.sailbox_id,
                    method=method,
                    url=url,
                    params=[
                        workerproxy_pb2.QueryParam(name=name, value=value)
                        for name, value in (params or {}).items()
                    ],
                    headers=[
                        workerproxy_pb2.HTTPHeader(name=name, value=value)
                        for name, value in request_headers.items()
                    ],
                    request_body=body,
                    timeout_seconds=timeout or 30,
                    durability_mode=durability,
                    idempotency_key=idempotency_key or "",
                ),
                metadata=client.metadata(),
            )
        return _sailbox_request_from_proto(
            resp.request,
            exec_endpoint=self.exec_endpoint,
        )

    def listener(self, port: int) -> SailboxListener:
        client = Client.get()
        with open_channel(self.exec_endpoint) as channel:
            stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
            resp = stub.GetListener(
                workerproxy_pb2.GetListenerRequest(
                    sailbox_id=self.sailbox_id,
                    guest_port=port,
                ),
                metadata=client.metadata(),
            )
        return SailboxListener(
            sailbox_id=self.sailbox_id,
            port=resp.listener.guest_port,
            url=resp.listener.public_url,
            protocol=resp.listener.protocol,
            route_status=workerproxy_pb2.ListenerRouteStatus.Name(
                resp.listener.route_status
            ),
        )

    def listeners(self) -> list[SailboxListener]:
        client = Client.get()
        with open_channel(self.exec_endpoint) as channel:
            stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
            resp = stub.ListListeners(
                workerproxy_pb2.ListListenersRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        return [
            SailboxListener(
                sailbox_id=self.sailbox_id,
                port=listener.guest_port,
                url=listener.public_url,
                protocol=listener.protocol,
                route_status=workerproxy_pb2.ListenerRouteStatus.Name(
                    listener.route_status
                ),
            )
            for listener in resp.listeners
        ]

    def stream(self, *args, **kwargs):
        raise NotImplementedError(
            "stream support is reserved for a future resumable session API"
        )

    def webhook(self, *args, **kwargs):
        raise NotImplementedError(
            "webhook support is reserved for a future stable inbound delivery API"
        )

    def exec(
        self,
        command: str,
        *,
        timeout: int | None = None,
        background: bool = False,
    ) -> SailboxExecRequest:
        """Run a shell command directly on the owning worker."""
        if not command:
            raise ValueError("command must be non-empty")
        if timeout is not None and timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if self.status == "stopped":
            raise SailboxExecutionError("sailbox is stopped. call start() before exec")

        if background:
            command = (
                f"nohup /bin/sh -lc {shlex.quote(command)} "
                "</dev/null >/dev/null 2>&1 &"
            )

        # TODO: Consider renaming timeout to expected_runtime if we later need
        # a separate transport timeout distinct from the command runtime budget.
        try:
            with open_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.ExecSailbox(
                    workerproxy_pb2.ExecSailboxRequest(
                        sailbox_id=self.sailbox_id,
                        argv=["/bin/sh", "-lc", command],
                        timeout_seconds=timeout or 0,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_exec_rpc_error(exc) from exc
        return SailboxExecRequest(
            sailbox_id=self.sailbox_id,
            exec_request_id=resp.exec_request_id,
            exec_endpoint=self.exec_endpoint,
            background=background,
        )


def _map_exec_rpc_error(exc: grpc.RpcError) -> SailboxExecutionError:
    details = exc.details() or "unknown sailbox exec error"
    code = exc.code()

    if code == grpc.StatusCode.FAILED_PRECONDITION and "already running" in details:
        return SailboxExecAlreadyRunningError(details)
    if code == grpc.StatusCode.NOT_FOUND:
        if "exec request" in details:
            return SailboxExecRequestNotFoundError(details)
        return SailboxTerminatedError(
            f"{details}; this is likely because this Sailbox is no longer running"
        )
    return SailboxExecutionError(f"{code.name}: {details}")


def _json_dumps_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _sailbox_request_from_proto(
    request: workerproxy_pb2.NetworkRequest,
    *,
    exec_endpoint: str,
) -> SailboxRequest:
    response = None
    if request.status == workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED:
        response = SailboxResponse(
            status_code=request.response_status_code,
            headers={header.name: header.value for header in request.response_headers},
            content=request.response_body,
        )
    return SailboxRequest(
        sailbox_id=request.sailbox_id,
        request_id=request.request_id,
        exec_endpoint=exec_endpoint,
        status=workerproxy_pb2.NetworkRequestStatus.Name(request.status),
        response=response,
        error_message=request.error_message,
    )
