from __future__ import annotations

import os

_PROD_SCHEDULER_URL = "sailbox-scheduler.sailresearch.com:443"
_DEV_SCHEDULER_URL = "sailbox-scheduler.dev.sailresearch.com:443"
_PROD_API_URL = "https://api.sailresearch.com"
_DEV_API_URL = "https://dev.sailresearch.com"


class Config:
    """SDK configuration loaded from environment variables."""

    def __init__(self, *, scheduler_url: str, api_key: str, api_url: str = "") -> None:
        self.scheduler_url = scheduler_url
        self.api_key = api_key
        self.api_url = api_url

    @classmethod
    def from_env(cls) -> Config:
        mode = os.environ.get("SAIL_MODE", "").strip().lower()
        if mode == "dev":
            default_scheduler_url = _DEV_SCHEDULER_URL
            default_api_url = _DEV_API_URL
        else:
            default_scheduler_url = _PROD_SCHEDULER_URL
            default_api_url = _PROD_API_URL

        scheduler_url = (
            os.environ.get("SAIL_SCHEDULER_URL", "").strip() or default_scheduler_url
        )
        api_key = os.environ.get("SAIL_API_KEY", "")
        if not api_key:
            raise ValueError("SAIL_API_KEY must be set")
        api_url = os.environ.get("SAIL_API_URL", "").strip() or default_api_url
        return cls(scheduler_url=scheduler_url, api_key=api_key, api_url=api_url)
