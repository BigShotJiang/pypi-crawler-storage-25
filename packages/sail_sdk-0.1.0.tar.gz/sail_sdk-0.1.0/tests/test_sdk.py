from __future__ import annotations

import json
import sys
import threading
from concurrent import futures
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import grpc
import pytest

# Make proto stubs importable.
_PB_DIR = str(Path(__file__).resolve().parent.parent / "src" / "sail" / "pb")
if _PB_DIR not in sys.path:
    sys.path.insert(0, _PB_DIR)

from scheduler.v1 import scheduler_pb2, scheduler_pb2_grpc  # noqa: E402
from workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc  # noqa: E402

from sail._client import Client  # noqa: E402
from sail._config import Config  # noqa: E402
from sail._http_client import HTTPClient  # noqa: E402
from sail.app import App  # noqa: E402
from sail.errors import (  # noqa: E402
    ImageBuildError,
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
)
from sail.sailbox import Sailbox, SailboxExecRequest  # noqa: E402
from sail.image import Image  # noqa: E402


class FakeScheduler(scheduler_pb2_grpc.SchedulerServiceServicer):
    """In-process gRPC server that simulates the scheduler."""

    def __init__(
        self,
        *,
        worker_address: str,
        create_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
        error_message: str = "",
        terminate_error: tuple[grpc.StatusCode, str] | None = None,
        stop_error: tuple[grpc.StatusCode, str] | None = None,
        checkpoint_error: tuple[grpc.StatusCode, str] | None = None,
        start_error: tuple[grpc.StatusCode, str] | None = None,
        start_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
    ):
        self.worker_address = worker_address
        self.create_status = create_status
        self.error_message = error_message
        self.terminate_error = terminate_error
        self.stop_error = stop_error
        self.checkpoint_error = checkpoint_error
        self.start_error = start_error
        self.start_status = start_status
        self.last_metadata: dict[str, str] = {}
        self.last_create_request: scheduler_pb2.CreateSailboxRequest | None = None
        self.last_build_request: scheduler_pb2.BuildImageRequest | None = None
        self.last_stop_request: scheduler_pb2.StopSailboxRequest | None = None
        self.last_checkpoint_request: scheduler_pb2.CheckpointSailboxRequest | None = (
            None
        )
        self.last_resume_request: scheduler_pb2.ResumeSailboxRequest | None = None
        self.build_status_sequence: list[int] = [
            scheduler_pb2.IMAGE_BUILD_STATUS_READY,
        ]
        self.build_error_message = ""
        self.image_id = "sha256:test-image"

    def CreateSailbox(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        self.last_create_request = request
        return scheduler_pb2.CreateSailboxResponse(
            sailbox_id="sb-test-123",
            status=self.create_status,
            worker_address=(
                self.worker_address
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            vm_id=(
                "vm-abc-123"
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            exec_proxy_endpoint=self.worker_address,
            error_message=(
                self.error_message
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_FAILED
                else ""
            ),
        )

    def BuildImage(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.last_build_request = request
        status = self.build_status_sequence[0]
        if len(self.build_status_sequence) > 1:
            self.build_status_sequence = self.build_status_sequence[1:]
        return scheduler_pb2.BuildImageResponse(
            image_id=self.image_id,
            status=status,
            error_message=self.build_error_message,
        )

    def GetImageBuildStatus(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        status = self.build_status_sequence[0]
        if len(self.build_status_sequence) > 1:
            self.build_status_sequence = self.build_status_sequence[1:]
        return scheduler_pb2.GetImageBuildStatusResponse(
            image_id=request.image_id,
            status=status,
            error_message=self.build_error_message,
        )

    def GetSailboxStatus(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        return scheduler_pb2.GetSailboxStatusResponse(
            sailbox_id=request.sailbox_id,
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            worker_address="10.0.0.1:8732",
            vm_id="vm-abc-123",
        )

    def TerminateSailbox(self, request, context):
        if self.terminate_error is not None:
            context.abort(self.terminate_error[0], self.terminate_error[1])
        return scheduler_pb2.TerminateSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_TERMINATED,
        )

    def StopSailbox(self, request, context):
        self.last_stop_request = request
        if self.stop_error is not None:
            context.abort(self.stop_error[0], self.stop_error[1])
        return scheduler_pb2.StopSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_STOPPED,
        )

    def CheckpointSailbox(self, request, context):
        self.last_checkpoint_request = request
        if self.checkpoint_error is not None:
            context.abort(self.checkpoint_error[0], self.checkpoint_error[1])
        return scheduler_pb2.CheckpointSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            checkpoint_generation=1,
        )

    def ResumeSailbox(self, request, context):
        self.last_resume_request = request
        if self.start_error is not None:
            context.abort(self.start_error[0], self.start_error[1])
        return scheduler_pb2.ResumeSailboxResponse(
            resume_state=scheduler_pb2.SAILBOX_RESUME_STATE_RUNNING,
            status=self.start_status,
            worker_address=self.worker_address,
            worker_internal_address=self.worker_address,
            vm_id="vm-restored-123",
        )

    def GetVMStats(self, request, context):
        return scheduler_pb2.GetVMStatsResponse(vm_stats=[])


class FakeWorker(workerproxy_pb2_grpc.WorkerProxyServiceServicer):
    def __init__(self, *, exec_error=None, wait_error=None):
        self.last_metadata: dict[str, str] = {}
        self.last_exec_request: workerproxy_pb2.ExecSailboxRequest | None = None
        self.exec_error = exec_error
        self.wait_error = wait_error
        self.network_requests: dict[str, workerproxy_pb2.NetworkRequest] = {}

    def ExecSailbox(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.last_exec_request = request
        if self.exec_error is not None:
            context.abort(self.exec_error[0], self.exec_error[1])
        return workerproxy_pb2.ExecSailboxResponse(exec_request_id="exec-123")

    def WaitSailboxExec(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        if self.wait_error is not None:
            context.abort(self.wait_error[0], self.wait_error[1])
        return workerproxy_pb2.WaitSailboxExecResponse(
            exec_request_id=request.exec_request_id,
            status=workerproxy_pb2.SAILBOX_EXEC_STATUS_SUCCEEDED,
            stdout="hi\n",
            stderr="",
            return_code=0,
        )

    def CreateNetworkRequest(self, request, context):
        self.last_network_request = request
        req = workerproxy_pb2.NetworkRequest(
            request_id="nr-test-123",
            sailbox_id=request.sailbox_id,
            method=request.method,
            url=request.url,
            params=request.params,
            headers=request.headers,
            request_body=request.request_body,
            timeout_seconds=request.timeout_seconds,
            durability_mode=request.durability_mode,
            idempotency_key=request.idempotency_key,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED,
            response_status_code=200,
            response_headers=[
                workerproxy_pb2.HTTPHeader(
                    name="Content-Type", value="application/json"
                )
            ],
            response_body=b'{"ok":true}',
        )
        self.network_requests[req.request_id] = req
        return workerproxy_pb2.CreateNetworkRequestResponse(request=req)

    def GetNetworkRequest(self, request, context):
        return workerproxy_pb2.GetNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def WaitNetworkRequest(self, request, context):
        return workerproxy_pb2.WaitNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def RetryNetworkRequest(self, request, context):
        original = self.network_requests[request.request_id]
        retried = workerproxy_pb2.NetworkRequest()
        retried.CopyFrom(original)
        retried.request_id = "nr-test-retry"
        self.network_requests[retried.request_id] = retried
        return workerproxy_pb2.RetryNetworkRequestResponse(request=retried)

    def CancelNetworkRequest(self, request, context):
        canceled = workerproxy_pb2.NetworkRequest(
            request_id=request.request_id,
            sailbox_id=request.sailbox_id,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED,
        )
        self.network_requests[request.request_id] = canceled
        return workerproxy_pb2.CancelNetworkRequestResponse(request=canceled)

    def GetListener(self, request, context):
        return workerproxy_pb2.GetListenerResponse(
            listener=workerproxy_pb2.Listener(
                guest_port=request.guest_port,
                public_url=f"https://{request.sailbox_id}-{request.guest_port}.sandbox.test",
                protocol="http",
                route_status=workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
            )
        )

    def ListListeners(self, request, context):
        return workerproxy_pb2.ListListenersResponse(
            listeners=[
                workerproxy_pb2.Listener(
                    guest_port=3000,
                    public_url=f"https://{request.sailbox_id}-3000.sandbox.test",
                    protocol="http",
                    route_status=workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
                )
            ]
        )


def _start_server(servicer):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    scheduler_pb2_grpc.add_SchedulerServiceServicer_to_server(servicer, server)
    port = server.add_insecure_port("localhost:0")
    server.start()
    return server, port


def _start_worker(worker):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    port = server.add_insecure_port("localhost:0")
    workerproxy_pb2_grpc.add_WorkerProxyServiceServicer_to_server(worker, server)
    server.start()
    return server, port


@pytest.fixture()
def fake_scheduler(monkeypatch):
    """Start a fake scheduler that immediately returns RUNNING on first poll."""
    worker = FakeWorker()
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def worker_error_scheduler(monkeypatch):
    worker = FakeWorker(
        exec_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "another exec request is already running for this sailbox",
        ),
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def missing_wait_scheduler(monkeypatch):
    worker = FakeWorker(
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def terminated_worker_scheduler(monkeypatch):
    worker = FakeWorker(
        exec_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found on this worker"),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def failing_scheduler(monkeypatch):
    """Start a fake scheduler that returns FAILED."""
    servicer = FakeScheduler(
        worker_address="localhost:0",
        create_status=scheduler_pb2.SAILBOX_STATUS_FAILED,
        error_message="no capacity available",
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def already_terminated_scheduler(monkeypatch):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "sailbox is SAILBOX_STATUS_TERMINATED and cannot be terminated",
        ),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def terminated_start_scheduler(monkeypatch):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        start_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "sailbox sb-test-123 is SAILBOX_STATUS_TERMINATED and cannot be restarted",
        ),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def missing_terminate_scheduler(monkeypatch):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found"),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture(autouse=True)
def _reset_client():
    """Ensure the singleton client is reset between tests."""
    yield
    Client.reset()
    HTTPClient.reset()


# --- Sailbox.create ---


def test_create_returns_sailbox(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.sailbox_id == "sb-test-123"
    assert sb.name == "sandbox-1"
    assert sb.status == "running"
    assert sb.worker_address == fake_scheduler.worker_address
    assert sb.exec_endpoint == fake_scheduler.worker_address


def test_create_with_all_args(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        memory=1024,
        cpu=2,
    )

    assert sb.sailbox_id == "sb-test-123"
    assert fake_scheduler.last_create_request.app_id == "app_test"
    assert fake_scheduler.last_create_request.cpu == 2
    assert fake_scheduler.last_create_request.memory_mib == 1024


def test_create_with_ingress_ports(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000, 8080],
    )

    assert sb.sailbox_id == "sb-test-123"
    assert list(fake_scheduler.last_create_request.ingress_ports) == [3000, 8080]


def test_create_returns_running_without_polling(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.status == "running"


def test_create_failed_raises(failing_scheduler):
    with pytest.raises(SailboxCreationError, match="no capacity available"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64,
            name="sandbox-1",
        )


def test_create_serializes_debian_image(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.base == scheduler_pb2.BASE_IMAGE_DEBIAN
    )


def test_create_requires_typed_image(fake_scheduler):
    with pytest.raises(TypeError, match="image must be a sail.Image value"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image="debian",  # type: ignore[arg-type]
            name="sandbox-1",
        )


def test_custom_image_serializes_steps_and_env(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    image = (
        Image.debian_amd64.apt_install("git", "curl")
        .pip_install("numpy")
        .run_commands("echo ready", "touch /tmp/test")
        .env({"FOO": "bar", "HELLO": "world"})
    )
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=image,
        name="sandbox-1",
    )

    req = fake_scheduler.last_create_request
    assert req is not None
    assert len(req.image.build_steps) == 4
    assert req.image.build_steps[0].apt_install.packages == ["git", "curl"]
    assert req.image.build_steps[1].pip_install.packages == ["numpy"]
    assert req.image.build_steps[2].run_command.command == "echo ready"
    assert req.image.build_steps[3].run_command.command == "touch /tmp/test"
    assert dict(req.image.env) == {"FOO": "bar", "HELLO": "world"}
    assert req.image.architecture == scheduler_pb2.IMAGE_ARCHITECTURE_AMD64


def test_image_build_polls_until_ready(fake_scheduler, monkeypatch):
    fake_scheduler, _ = fake_scheduler
    fake_scheduler.build_status_sequence = [
        scheduler_pb2.IMAGE_BUILD_STATUS_QUEUED,
        scheduler_pb2.IMAGE_BUILD_STATUS_BUILDING,
        scheduler_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = Image.debian_amd64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_scheduler.last_build_request is not None
    assert fake_scheduler.last_build_request.image.build_steps[
        0
    ].pip_install.packages == ["numpy"]
    assert (
        fake_scheduler.last_build_request.image.architecture
        == scheduler_pb2.IMAGE_ARCHITECTURE_AMD64
    )


def test_arm64_base_image_build_uses_arm64_architecture(fake_scheduler, monkeypatch):
    fake_scheduler, _ = fake_scheduler
    fake_scheduler.build_status_sequence = [scheduler_pb2.IMAGE_BUILD_STATUS_READY]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    Image.debian_arm64.pip_install("numpy").build(timeout=5)

    assert fake_scheduler.last_build_request is not None
    assert (
        fake_scheduler.last_build_request.image.architecture
        == scheduler_pb2.IMAGE_ARCHITECTURE_ARM64
    )


def test_image_build_failure_raises(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    fake_scheduler.build_status_sequence = [scheduler_pb2.IMAGE_BUILD_STATUS_FAILED]
    fake_scheduler.build_error_message = "apt-get failed"

    with pytest.raises(ImageBuildError, match="apt-get failed"):
        Image.debian_amd64.apt_install("git").build(timeout=5)


# --- terminate ---


def test_terminate(fake_scheduler):
    _, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    # Should not raise.
    sb.terminate()


def test_terminate_already_terminated_is_noop(already_terminated_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


def test_terminate_missing_sailbox_is_noop(missing_terminate_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


# --- stop/start ---


def test_stop_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.stop()

    assert scheduler.last_stop_request is not None
    assert scheduler.last_stop_request.sailbox_id == "sb-test-123"
    assert sb.status == "stopped"


def test_exec_rejects_stopped_handle(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.stop()

    with pytest.raises(SailboxExecutionError, match="call start\\(\\) before exec"):
        sb.exec("echo hi")


def test_checkpoint_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.checkpoint()

    assert scheduler.last_checkpoint_request is not None
    assert scheduler.last_checkpoint_request.sailbox_id == "sb-test-123"


def test_start_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    started = sb.start()

    assert scheduler.last_resume_request is not None
    assert scheduler.last_resume_request.sailbox_id == "sb-test-123"
    assert started is sb
    assert started.status == "running"
    assert sb.status == "running"


def test_start_terminated_sailbox_raises(terminated_start_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxCreationError, match="cannot be restarted"):
        sb.start()


# --- auth ---


def test_bearer_token_sent(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_metadata.get("authorization") == "Bearer test_key_123"


def test_exec_and_wait(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi", timeout=5)
    result = req.wait()

    assert req.exec_request_id == "exec-123"
    assert worker.last_exec_request.argv == ["/bin/sh", "-lc", "echo hi"]
    assert worker.last_metadata.get("authorization") == "Bearer test_key_123"
    assert result.stdout == "hi\n"
    assert result.stderr == ""
    assert result.returncode == 0


def test_exec_without_timeout_sends_zero(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi")

    assert req.background is False
    assert worker.last_exec_request.timeout_seconds == 0


def test_background_exec_wraps_command(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("python3 -m http.server 3000", background=True)

    assert req.background is True
    assert worker.last_exec_request.timeout_seconds == 0
    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "nohup /bin/sh -lc 'python3 -m http.server 3000' </dev/null >/dev/null 2>&1 &",
    ]


def test_exec_already_running_raises(worker_error_scheduler):
    _scheduler, _worker = worker_error_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxExecAlreadyRunningError):
        sb.exec("echo hi", timeout=5)


def test_wait_missing_exec_request_raises(missing_wait_scheduler):
    _scheduler, _worker = missing_wait_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    req = sb.exec("echo hi", timeout=5)
    missing_req = SailboxExecRequest(
        sailbox_id=req.sailbox_id,
        exec_request_id="missing",
        exec_endpoint=req.exec_endpoint,
    )

    with pytest.raises(SailboxExecRequestNotFoundError):
        missing_req.wait()


def test_exec_on_terminated_sailbox_raises(terminated_worker_scheduler):
    _scheduler, _worker = terminated_worker_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(
        SailboxTerminatedError,
        match="this is likely because this Sailbox is no longer running",
    ):
        sb.exec("echo hi", timeout=5)


# --- config ---


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "scheduler.example.com:9090")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "scheduler.example.com:9090"
    assert cfg.api_key == "key_abc"


def test_config_defaults_to_prod(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.sailresearch.com:443"
    assert cfg.api_url == "https://api.sailresearch.com"


def test_config_uses_dev_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.dev.sailresearch.com:443"
    assert cfg.api_url == "https://dev.sailresearch.com"


def test_config_missing_key_raises(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    with pytest.raises(ValueError, match="SAIL_API_KEY must be set"):
        Config.from_env()


# --- client singleton ---


def test_client_singleton(fake_scheduler):
    a = Client.get()
    b = Client.get()
    assert a is b

    Client.reset()
    assert Client._instance is None


class FakeAPIHandler(BaseHTTPRequestHandler):
    """HTTP handler that returns canned responses for /v1/apps/find."""

    server: HTTPServer
    response_status: int
    response_body: dict
    last_headers: dict
    last_body: dict

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(content_length)) if content_length else {}
        self.server.last_headers = dict(self.headers)
        self.server.last_body = body

        status = self.server.response_status
        resp = json.dumps(self.server.response_body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(resp)

    def log_message(self, format, *args):
        pass


@pytest.fixture()
def fake_api(monkeypatch):
    """Start a local HTTP server and configure SAIL_API_URL to point at it."""
    server = HTTPServer(("127.0.0.1", 0), FakeAPIHandler)
    server.response_status = 200
    server.response_body = {}
    server.last_headers = {}
    server.last_body = {}

    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()

    port = server.server_address[1]
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "localhost:0")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_456")
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{port}")
    yield server
    server.shutdown()


@pytest.fixture(autouse=True)
def _reset_http_client():
    """Ensure the HTTP singleton is reset between tests."""
    yield
    HTTPClient.reset()


def test_app_find_existing(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {
        "id": "app_abc",
        "name": "my-app",
        "created_at": 1712102400,
    }

    app = App.find(name="my-app")

    assert app.id == "app_abc"
    assert app.name == "my-app"
    assert app.created_at == 1712102400


def test_app_find_mint_if_missing(fake_api):
    fake_api.response_status = 201
    fake_api.response_body = {
        "id": "app_new",
        "name": "new-app",
        "created_at": 1712102500,
    }

    app = App.find(name="new-app", mint_if_missing=True)

    assert app.id == "app_new"
    assert app.name == "new-app"
    assert fake_api.last_body == {"name": "new-app", "mint_if_missing": True}


def test_app_find_not_found(fake_api):
    fake_api.response_status = 404
    fake_api.response_body = {"error": {"message": "app not found"}}

    with pytest.raises(LookupError, match="not found"):
        App.find(name="missing-app")


def test_app_find_auth_header(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {"id": "app_x", "name": "x", "created_at": 0}

    App.find(name="x")

    assert fake_api.last_headers.get("Authorization") == "Bearer test_key_456"


def test_config_api_url_optional(monkeypatch):
    """Config provides a default API URL when none is set."""
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    cfg = Config.from_env()
    assert cfg.api_url == "https://api.sailresearch.com"


def test_http_client_uses_default_api_url(monkeypatch):
    """HTTPClient falls back to the default API URL when none is set."""
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    client = HTTPClient()
    assert client._config.api_url == "https://api.sailresearch.com"


def test_request_returns_response(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request(
        "POST",
        "https://example.com/api",
        json={"hello": "world"},
        idempotency_key="req-1",
    )
    assert op.id == "nr-test-123"
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert worker.last_network_request.idempotency_key == "req-1"

    refreshed = op.refresh()
    assert refreshed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.json() == {"ok": True}
    assert refreshed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert refreshed.response is not None
    assert refreshed.response.json() == {"ok": True}

    completed = op.wait()
    assert completed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.status_code == 200
    assert op.response.json() == {"ok": True}
    assert completed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert completed.response is not None
    assert completed.response.status_code == 200
    assert completed.response.json() == {"ok": True}


def test_request_cancel_returns_updated_handle(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request("POST", "https://example.com/api", idempotency_key="req-2")
    canceled = op.cancel()

    assert canceled is op
    assert canceled.id == op.id
    assert canceled.status == "NETWORK_REQUEST_STATUS_CANCELED"
    assert canceled.response is None
    assert (
        worker.network_requests[op.id].status
        == workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED
    )


def test_request_requires_idempotency_key(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(ValueError, match="idempotency_key must be non-empty"):
        sb.request("POST", "https://example.com/api")


def test_listener_lookup(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)

    assert listener.port == 3000
    assert listener.url == "https://sb-test-123-3000.sandbox.test"


def test_sailbox_create_accepts_app_object(fake_scheduler):
    app = App(id="app_test", name="test-app", created_at=0)
    sb = Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1")
    assert sb.sailbox_id == "sb-test-123"
