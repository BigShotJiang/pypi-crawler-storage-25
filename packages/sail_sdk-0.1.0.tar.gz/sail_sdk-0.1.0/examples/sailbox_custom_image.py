from __future__ import annotations

"""Build and run a sailbox with a custom Debian image.

Usage:
    cd sdk/python
    export SAIL_MODE=dev
    export SAIL_API_KEY=your_api_key_here
    uv run python examples/sailbox_custom_image.py
"""

import os
import sys

import sail


def main() -> int:
    scheduler_url = os.environ.get("SAIL_SCHEDULER_URL", "")
    sail_mode = os.environ.get("SAIL_MODE", "")
    api_key = os.environ.get("SAIL_API_KEY", "")
    if not api_key:
        print(
            "Set SAIL_API_KEY before running this script. Optionally set SAIL_MODE=dev or override SAIL_SCHEDULER_URL.",
            file=sys.stderr,
        )
        return 2

    if not scheduler_url:
        scheduler_url = (
            "sailbox-scheduler.dev.sailresearch.com:443"
            if sail_mode.strip().lower() == "dev"
            else "sailbox-scheduler.sailresearch.com:443"
        )

    print("Finding or minting app...")
    app = sail.App.find(name="sailbox-custom-image", mint_if_missing=True)

    print("Defining custom image...")
    image = (
        sail.Image.debian_amd64.apt_install("git", "curl")
        .pip_install("requests")
        .run_commands(
            "git clone https://github.com/pallets/flask.git /opt/flask-src",
            "python3 -m pip show requests >/tmp/requests.txt",
        )
        .env(
            {
                "APP_ENV": "custom-image-demo",
                "DEMO_MESSAGE": "hello-from-custom-image",
            }
        )
    )

    print(f"Building image via scheduler {scheduler_url}...")
    built_image = image.build(timeout=1800)

    print("Creating sailbox from custom image...")
    sb = sail.Sailbox.create(
        app=app,
        image=built_image,
        name="custom-image-demo",
        cpu=1,
        memory=512,
    )

    print("Sailbox ready:")
    print(f"  sailbox_id: {sb.sailbox_id}")
    print(f"  worker:     {sb.worker_address}")
    print(f"  vm_id:      {sb.vm_id}")

    print("Verifying installed packages, build output, and runtime env...")
    result = sb.exec(
        "python3 - <<'PY'\n"
        "import os\n"
        "import requests\n"
        "print('requests=' + requests.__version__)\n"
        "print('app_env=' + os.environ['APP_ENV'])\n"
        "print('demo_message=' + os.environ['DEMO_MESSAGE'])\n"
        "PY\n"
        "test -d /opt/flask-src/.git\n"
        "cat /tmp/requests.txt | head -n 5\n",
        timeout=30,
    ).wait()
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    print(f"return code: {result.returncode}")

    print("Terminating sailbox...")
    sb.terminate()
    print("Terminated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
