"""Equivalence matrix for the graph-safe path.

Same coverage as `test_matrix.py` but with `graph_safe=True`: verify the
mask-weighted-mean loss reformulation matches FAIR's bool-indexed loss
across variants (T/S/B/L), mask ratios (0.5 / 0.6 / 0.75), dtypes
(fp32 / bf16), and q_pool (1 / 2 / 3).
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from hiera_optim.patch import optimize


def _load_2d(variant: str, in_chans: int = 8, img: int = 224, **kw):
    from models.hiera import (
        mae_hiera_tiny_224, mae_hiera_small_224, mae_hiera_base_224,
        mae_hiera_large_224,
    )
    fns = {"tiny": mae_hiera_tiny_224, "small": mae_hiera_small_224,
           "base": mae_hiera_base_224, "large": mae_hiera_large_224}
    return fns[variant](pretrained=False, in_chans=in_chans, input_size=(img, img), **kw)


def _tol(dtype):
    # Graph-safe loss reformulates the average; in bf16 the rounding chain
    # differs slightly. Same tolerance as test_matrix.py.
    return 0.05 if dtype == torch.bfloat16 else 1e-3


@pytest.mark.parametrize("variant", ["tiny", "small", "base"])
@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
@pytest.mark.parametrize("mask_ratio", [0.5, 0.6, 0.75])
def test_graph_safe_loss_matches_fair_2d(variant, dtype, mask_ratio):
    """`optimize(graph_safe=True)` loss == FAIR loss for the same mask."""
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    torch.manual_seed(0)
    base = _load_2d(variant).to(device, dtype).eval()
    torch.manual_seed(0)
    opt = _load_2d(variant).to(device, dtype).eval()
    optimize(opt, swap_attention=True, swap_gather=True, graph_safe=True, verbose=False)

    x = torch.randn(2, 8, 224, 224, device=device, dtype=dtype)
    mask = base.get_random_mask(x, mask_ratio)

    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=mask_ratio, mask=mask)
        l_o, *_ = opt(x, mask_ratio=mask_ratio, mask=mask)
    diff = (l_b - l_o).abs().item() / l_b.abs().item()
    assert diff < _tol(dtype), (
        f"{variant} {dtype} mr={mask_ratio} loss diff {diff}: "
        f"fair={l_b.item():.6f} graph_safe={l_o.item():.6f}"
    )


@pytest.mark.parametrize("q_pool", [1, 2, 3])
def test_graph_safe_q_pool(q_pool):
    """Graph-safe loss generalises to non-default q_pool counts."""
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    from models.hiera import MaskedAutoencoderHiera
    dtype = torch.float32
    torch.manual_seed(0)
    kw = dict(embed_dim=96, num_heads=1, stages=(2, 3, 16, 3),
              q_pool=q_pool, in_chans=8, input_size=(224, 224))
    base = MaskedAutoencoderHiera(**kw).to(device, dtype).eval()
    torch.manual_seed(0)
    opt = MaskedAutoencoderHiera(**kw).to(device, dtype).eval()
    optimize(opt, swap_attention=True, swap_gather=True, graph_safe=True, verbose=False)

    x = torch.randn(2, 8, 224, 224, device=device, dtype=dtype)
    mask = base.get_random_mask(x, 0.6)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)
    diff = (l_b - l_o).abs().item() / l_b.abs().item()
    assert diff < 1e-3, f"q_pool={q_pool} loss diff: {diff}"


@pytest.mark.parametrize("in_chans", [1, 3, 8])
@pytest.mark.parametrize("img", [128, 224])
def test_graph_safe_shapes(in_chans, img):
    """Graph-safe loss works across different input shapes (channels, sizes)."""
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    dtype = torch.float32
    torch.manual_seed(0)
    base = _load_2d("tiny", in_chans=in_chans, img=img).to(device, dtype).eval()
    torch.manual_seed(0)
    opt = _load_2d("tiny", in_chans=in_chans, img=img).to(device, dtype).eval()
    optimize(opt, swap_attention=True, swap_gather=True, graph_safe=True, verbose=False)

    x = torch.randn(2, in_chans, img, img, device=device, dtype=dtype)
    mask = base.get_random_mask(x, 0.6)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)
    diff = (l_b - l_o).abs().item() / l_b.abs().item()
    assert diff < 1e-3, f"in_chans={in_chans} img={img}: loss diff {diff}"


# Production config: raw_reshape_224 — 1D EEG reshaped to 224x224 and fed
# to a 2D MAE-Hiera-Base. This is what HieraMAEv5 actually does in v6_mm
# training. We test the full optimize(graph_safe=True) chain.
def test_graph_safe_production_v6_config():
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    dtype = torch.bfloat16
    torch.manual_seed(0)
    base = _load_2d("base", in_chans=8, img=224).to(device, dtype).eval()
    torch.manual_seed(0)
    opt = _load_2d("base", in_chans=8, img=224).to(device, dtype).eval()
    optimize(opt, swap_attention=True, swap_gather=True, graph_safe=True, verbose=False)

    # bs=8 (single-GPU subset of production bs=512)
    x = torch.randn(8, 8, 224, 224, device=device, dtype=dtype)
    mask = base.get_random_mask(x, 0.6)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)
    diff = (l_b - l_o).abs().item() / l_b.abs().item()
    assert diff < 0.05, f"production v6 config: loss diff {diff}"
