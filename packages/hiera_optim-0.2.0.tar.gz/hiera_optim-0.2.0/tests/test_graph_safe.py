"""Correctness for graph-safe MAE patches.

Validates that `optimize(model, graph_safe=True)` produces the same loss
value as the unpatched FAIR MAE forward, for the same input + mask. Tests
1D, 2D, 3D variants where available.
"""
import pytest
import torch
import torch.nn as nn

from models.hiera import (
    mae_hiera_tiny_224, mae_hiera_small_224, mae_hiera_base_224,
)
from hiera_optim.patch import (
    optimize as optimize_model,
    make_mae_mask,
    _enable_graph_safe,
    _get_pixel_label_2d_full,
    _get_pixel_label_1d_full,
    _mae_forward_loss_graph_safe,
)


def _build(variant, in_chans, device, dtype):
    fn = {"tiny": mae_hiera_tiny_224, "small": mae_hiera_small_224,
          "base": mae_hiera_base_224}[variant]
    return fn(pretrained=False, in_chans=in_chans, input_size=(224, 224)).to(device, dtype)


# -----------------------------------------------------------------------------
# Unit test: graph-safe label vs FAIR label, on the same input
# -----------------------------------------------------------------------------

@pytest.mark.parametrize("variant", ["tiny", "small", "base"])
def test_pixel_label_2d_full_matches_masked(variant):
    """label[mask] == _get_pixel_label_2d_full(...)[mask] for any patch-level mask."""
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    dtype = torch.float32
    torch.manual_seed(0)
    model = _build(variant, in_chans=3, device=device, dtype=dtype)
    B = 2
    x = torch.randn(B, 3, 224, 224, device=device, dtype=dtype)

    # Compute the patch-level shape `get_pixel_label_2d` expects by running
    # the full path once. Build a synthetic patch-level mask the same shape.
    label_full = _get_pixel_label_2d_full(model, x, norm=True)
    assert label_full.dim() == 3, label_full.shape
    num_patches = label_full.shape[1]
    # Half-and-half bool mask with same count per row.
    mask = torch.zeros(B, num_patches, device=device, dtype=torch.bool)
    mask[:, : num_patches // 2] = True

    label_fair = model.get_pixel_label_2d(x, mask, norm=True)   # (M, C*s*s)
    label_picked = label_full[mask]                              # (M, C*s*s)
    assert torch.allclose(label_fair, label_picked, atol=1e-5, rtol=1e-5), \
        f"max diff: {(label_fair - label_picked).abs().max()}"


# -----------------------------------------------------------------------------
# Loss equivalence: bool-indexed FAIR loss vs mask-weighted graph-safe loss
# -----------------------------------------------------------------------------

@pytest.mark.parametrize("variant", ["tiny", "small", "base"])
@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
def test_forward_loss_graph_safe_matches_fair(variant, dtype):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    torch.manual_seed(0)
    model = _build(variant, in_chans=3, device=device, dtype=dtype)
    model.eval()
    B = 2
    x = torch.randn(B, 3, 224, 224, device=device, dtype=dtype)
    mask, keep_idx = make_mae_mask(model, B, 0.6, device)

    # Run FAIR forward end-to-end (graph-unsafe path), capture loss.
    torch.manual_seed(1)
    with torch.no_grad():
        loss_fair, _, _, _ = model(x, mask_ratio=0.6, mask=mask)

    # Patch with optimize(graph_safe=True), rerun, compare.
    # Build a NEW model so the FAIR path above stays clean.
    torch.manual_seed(0)
    model2 = _build(variant, in_chans=3, device=device, dtype=dtype)
    model2.eval()
    optimize_model(model2, swap_attention=True, swap_gather=True,
                   graph_safe=True, verbose=False)
    torch.manual_seed(1)
    with torch.no_grad():
        loss_gs, _, _, _ = model2(x, mask_ratio=0.6, mask=mask, keep_idx=keep_idx)

    rel = (loss_fair - loss_gs).abs() / (loss_fair.abs().clamp_min(1e-9))
    print(f"\n[{variant} {dtype}] FAIR loss={loss_fair.item():.6f}  "
          f"graph-safe loss={loss_gs.item():.6f}  rel_diff={rel.item():.4e}")
    assert rel.item() < (0.05 if dtype == torch.bfloat16 else 1e-3), (
        f"loss diverges: FAIR {loss_fair.item()} vs graph-safe {loss_gs.item()} "
        f"rel diff {rel.item()}"
    )


# -----------------------------------------------------------------------------
# Backward: gradients should match too (within bf16 noise)
# -----------------------------------------------------------------------------

def test_graph_safe_backward_matches_fair():
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    dtype = torch.float32  # fp32 for tight tolerance on grads
    torch.manual_seed(0)
    B = 2
    x = torch.randn(B, 3, 224, 224, device=device, dtype=dtype, requires_grad=False)

    # Build TWO copies with identical init.
    torch.manual_seed(0); model1 = _build("tiny", in_chans=3, device=device, dtype=dtype)
    torch.manual_seed(0); model2 = _build("tiny", in_chans=3, device=device, dtype=dtype)
    optimize_model(model2, swap_attention=True, swap_gather=True,
                   graph_safe=True, verbose=False)

    mask, keep_idx = make_mae_mask(model1, B, 0.6, device)

    # FAIR path
    torch.manual_seed(1)
    loss1, *_ = model1(x, mask_ratio=0.6, mask=mask)
    loss1.backward()
    g1 = {n: p.grad.detach().clone() for n, p in model1.named_parameters() if p.grad is not None}

    # Graph-safe path (same init -> same weights -> grads should match)
    torch.manual_seed(1)
    loss2, *_ = model2(x, mask_ratio=0.6, mask=mask, keep_idx=keep_idx)
    loss2.backward()
    g2 = {n: p.grad.detach().clone() for n, p in model2.named_parameters() if p.grad is not None}

    # loss should match closely
    rel_loss = (loss1 - loss2).abs() / loss1.abs().clamp_min(1e-9)
    assert rel_loss.item() < 1e-3, f"loss rel diff {rel_loss.item():.4e}"

    # Gradients: compare relative RMS per parameter
    max_rel = 0.0
    worst = ""
    for n in g1:
        if n not in g2: continue
        a, b = g1[n].float(), g2[n].float()
        rms = (a - b).pow(2).mean().sqrt()
        ref = a.pow(2).mean().sqrt().clamp_min(1e-9)
        r = (rms / ref).item()
        if r > max_rel:
            max_rel = r; worst = n
    print(f"\nworst grad rel RMS: {worst} = {max_rel:.4e}")
    assert max_rel < 5e-3, f"grad mismatch on {worst}: {max_rel}"
