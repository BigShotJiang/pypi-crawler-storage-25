"""Equivalence matrix: across Hiera variants × shapes × mask ratios × dtypes.

For each `(variant, dtype, mask_ratio)` cell, we build the FAIR baseline and
an optimised copy (same weights), run forward with the SAME generated mask,
and assert the loss + masked prediction RMS error are within bf16/fp16 noise.

We also exercise non-default q_pool values to make sure the patched
forward_encoder / forward_decoder generalise beyond the default q_pool=2.
"""
from __future__ import annotations
import copy
import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from hiera_optim import optimize


# ---------------------------------------------------------------------------
# 2-D image MAE: T / S / B / L / H
# ---------------------------------------------------------------------------

def _load(variant: str, in_chans: int = 8, img: int = 224, **kw):
    from models.hiera import (
        mae_hiera_tiny_224, mae_hiera_small_224, mae_hiera_base_224,
        mae_hiera_large_224, mae_hiera_huge_224,
    )
    fns = {
        "tiny": mae_hiera_tiny_224,
        "small": mae_hiera_small_224,
        "base": mae_hiera_base_224,
        "large": mae_hiera_large_224,
        "huge": mae_hiera_huge_224,
    }
    return fns[variant](pretrained=False, in_chans=in_chans, input_size=(img, img), **kw)


@pytest.mark.parametrize("variant", ["tiny", "small", "base", "large", "huge"])
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.parametrize("mask_ratio", [0.5, 0.6, 0.75])
def test_2d_variants(variant, dtype, mask_ratio):
    """All five Hiera-2D variants match within bf16 noise across mask ratios."""
    torch.manual_seed(0)
    device = "cuda"
    B = 2
    in_chans = 8

    base = _load(variant, in_chans=in_chans).to(device, dtype)
    opt = copy.deepcopy(base)
    optimize(opt, verbose=False)

    x = torch.randn(B, in_chans, 224, 224, device=device, dtype=dtype)
    torch.manual_seed(123)
    mask = base.get_random_mask(x, mask_ratio)

    with torch.no_grad():
        l_b, _, _, _ = base(x, mask_ratio=mask_ratio, mask=mask)
        l_o, _, _, _ = opt(x, mask_ratio=mask_ratio, mask=mask)

    # bf16 noise: O(1e-2) is fine for the variants we have
    diff = (l_b.float() - l_o.float()).abs().item()
    assert diff < 0.05, f"{variant} {dtype} mask={mask_ratio} loss diff: {diff}"


@pytest.mark.parametrize("variant", ["tiny", "base"])
def test_2d_backward_grad_flow(variant):
    """Backward path is non-broken across variants."""
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16

    opt = _load(variant, in_chans=8).to(device, dtype)
    optimize(opt, verbose=False)

    x = torch.randn(2, 8, 224, 224, device=device, dtype=dtype)
    l, *_ = opt(x, mask_ratio=0.6)
    l.backward()

    grads = [p.grad for p in opt.parameters() if p.requires_grad and p.grad is not None]
    assert grads, f"{variant}: no parameter gradients flowed"
    assert all(torch.isfinite(g).all() for g in grads), f"{variant}: NaN/Inf in grads"


# ---------------------------------------------------------------------------
# q_pool variations (default is 2; test 1 and 3 too)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("q_pool", [1, 2, 3])
def test_q_pool_variations(q_pool):
    """Patched forward generalises to non-default q_pool counts."""
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16

    # Build MaskedAutoencoderHiera directly to override q_pool (factory hardcodes 2).
    from models.hiera import MaskedAutoencoderHiera
    base = MaskedAutoencoderHiera(
        embed_dim=96, num_heads=1, stages=(1, 2, 7, 2),
        q_pool=q_pool, in_chans=8, input_size=(224, 224),
    ).to(device, dtype)
    opt = copy.deepcopy(base)
    optimize(opt, verbose=False)

    x = torch.randn(2, 8, 224, 224, device=device, dtype=dtype)
    torch.manual_seed(7); mask = base.get_random_mask(x, 0.6)

    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)

    diff = (l_b.float() - l_o.float()).abs().item()
    assert diff < 0.05, f"q_pool={q_pool}: loss diff {diff}"


# ---------------------------------------------------------------------------
# Image size variations
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("img", [128, 224, 256])
def test_image_sizes(img):
    """Different input resolutions. img must be divisible by patch_stride."""
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16

    from models.hiera import mae_hiera_tiny_224
    base = mae_hiera_tiny_224(pretrained=False, in_chans=8, input_size=(img, img)).to(device, dtype)
    opt = copy.deepcopy(base)
    optimize(opt, verbose=False)

    x = torch.randn(2, 8, img, img, device=device, dtype=dtype)
    torch.manual_seed(11); mask = base.get_random_mask(x, 0.6)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)
    diff = (l_b.float() - l_o.float()).abs().item()
    assert diff < 0.05, f"img={img}: loss diff {diff}"


# ---------------------------------------------------------------------------
# In-channels variations
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("in_chans", [1, 3, 8, 16])
def test_in_chans(in_chans):
    """Different input channel counts."""
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16

    from models.hiera import mae_hiera_tiny_224
    base = mae_hiera_tiny_224(pretrained=False, in_chans=in_chans, input_size=(224, 224)).to(device, dtype)
    opt = copy.deepcopy(base)
    optimize(opt, verbose=False)

    x = torch.randn(2, in_chans, 224, 224, device=device, dtype=dtype)
    torch.manual_seed(13); mask = base.get_random_mask(x, 0.6)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.6, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.6, mask=mask)
    diff = (l_b.float() - l_o.float()).abs().item()
    assert diff < 0.05, f"in_chans={in_chans}: loss diff {diff}"


# ---------------------------------------------------------------------------
# 3-D video MAE
# ---------------------------------------------------------------------------

def test_3d_video_mae():
    """Hiera-Base on 16-frame video clips (16×224×224)."""
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16

    from models.hiera import mae_hiera_base_16x224
    base = mae_hiera_base_16x224(pretrained=False, in_chans=3).to(device, dtype)
    opt = copy.deepcopy(base)
    optimize(opt, verbose=False)

    x = torch.randn(1, 3, 16, 224, 224, device=device, dtype=dtype)
    torch.manual_seed(17); mask = base.get_random_mask(x, 0.9)
    with torch.no_grad():
        l_b, *_ = base(x, mask_ratio=0.9, mask=mask)
        l_o, *_ = opt(x, mask_ratio=0.9, mask=mask)
    diff = (l_b.float() - l_o.float()).abs().item()
    assert diff < 0.05, f"3d video: loss diff {diff}"


# ---------------------------------------------------------------------------
# Idempotency: re-applying optimize() is harmless
# ---------------------------------------------------------------------------

def test_optimize_idempotent():
    """Calling optimize() twice should be a no-op on the second call."""
    from models.hiera import mae_hiera_tiny_224
    m = mae_hiera_tiny_224(pretrained=False, in_chans=8, input_size=(224, 224)).cuda().to(torch.bfloat16)
    optimize(m, verbose=False)

    # Snapshot attention identities
    from hiera_optim.attention import MaskUnitAttentionFast
    attns = [(b, b.attn) for b in m.modules() if hasattr(b, "attn") and isinstance(b.attn, MaskUnitAttentionFast)]
    assert attns, "no swapped attention found"

    # Run again
    optimize(m, verbose=False)

    # Verify no double-swap: the FastAttn instances are still the same objects
    # OR we built fresh ones — both acceptable; what matters is correctness still holds.
    x = torch.randn(2, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
    out = m(x, mask_ratio=0.6)
    assert torch.isfinite(out[0]).item()


# ---------------------------------------------------------------------------
# Non-MAE (classification head) path
# ---------------------------------------------------------------------------

def test_classification_head():
    """The encoder-only Hiera (classification, no MAE) also benefits from the
    attention swap. The masked-gather path is skipped automatically since
    classification doesn't pass a mask."""
    from models.hiera import hiera_tiny_224

    m = hiera_tiny_224(pretrained=False, in_chans=8, input_size=(224, 224)).cuda().to(torch.bfloat16)
    # gather path is no-op without mask; attention swap is the real win
    optimize(m, swap_gather=False, verbose=False)

    x = torch.randn(2, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
    with torch.no_grad():
        out = m(x)
    assert out.shape == (2, m.head.projection.out_features), f"unexpected output shape {out.shape}"
    assert torch.isfinite(out).all().item()


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
