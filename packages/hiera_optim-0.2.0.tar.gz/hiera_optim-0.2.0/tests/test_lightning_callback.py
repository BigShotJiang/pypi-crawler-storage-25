"""Smoke test for MAEStaticInputsCallback under a minimal Lightning loop.

Verifies: buffers get attached, mask refreshes between steps, the compiled
model trains without illegal memory access (the failure mode pre-fix).
"""
import pytest
import torch
import torch.nn as nn

try:
    import lightning.pytorch as pl
    from lightning.pytorch import Trainer
    LIGHTNING = True
except ImportError:
    LIGHTNING = False

if LIGHTNING:
    from models.hiera import mae_hiera_tiny_224
    from hiera_optim.patch import optimize
    from hiera_optim.lightning import MAEStaticInputsCallback, feed_batch


class _MAEModule(pl.LightningModule if LIGHTNING else object):
    """Minimal LightningModule that wraps a Hiera MAE and uses the static
    buffers attached by MAEStaticInputsCallback."""
    def __init__(self, mask_ratio=0.6):
        super().__init__()
        self.mask_ratio = mask_ratio
        model = mae_hiera_tiny_224(pretrained=False, in_chans=3,
                                    input_size=(224, 224))
        optimize(model, graph_safe=True, verbose=False)
        self.model = model

    def training_step(self, batch, batch_idx):
        inputs = self._mae_inputs
        feed_batch(inputs, batch, batch_key=self._batch_key)
        out = self.model(inputs.x, mask_ratio=self.mask_ratio,
                          mask=inputs.mask, keep_idx=inputs.keep_idx)
        loss = out[0]
        return loss

    def configure_optimizers(self):
        return torch.optim.AdamW(self.parameters(), lr=3e-4, fused=True)


class _RandomDataset(torch.utils.data.IterableDataset):
    def __init__(self, n=4, B=4, C=3, H=224, W=224, dtype=torch.bfloat16):
        self.n = n; self.B = B; self.C = C; self.H = H; self.W = W; self.dtype = dtype
    def __iter__(self):
        for _ in range(self.n):
            yield torch.randn(self.C, self.H, self.W, dtype=self.dtype)


@pytest.mark.skipif(not LIGHTNING, reason="lightning not installed")
@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_callback_attaches_and_refreshes():
    """Callback should attach `_mae_inputs` and refresh the mask each step."""
    B = 4
    cb = MAEStaticInputsCallback(
        batch_size=B, in_chans=3, input_size=(224, 224),
        mask_ratio=0.6, dtype=torch.bfloat16, batch_key=None,
    )
    module = _MAEModule()
    ds = _RandomDataset(n=4, B=1)  # __iter__ yields per-sample
    loader = torch.utils.data.DataLoader(ds, batch_size=B, drop_last=True)

    trainer = Trainer(
        accelerator="gpu", devices=1, precision="bf16-mixed",
        max_steps=2, callbacks=[cb], logger=False,
        enable_progress_bar=False, enable_model_summary=False,
        num_sanity_val_steps=0,
    )
    trainer.fit(module, train_dataloaders=loader)

    # Callback should have allocated the static buffers
    assert module._mae_inputs is not None
    assert module._mae_inputs.x.shape == (B, 3, 224, 224)
    assert module._mae_inputs.mask.dtype == torch.bool
    assert module._batch_key is None


@pytest.mark.skipif(not LIGHTNING, reason="lightning not installed")
@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_callback_with_torch_compile():
    """End-to-end: compile + graph_safe + callback runs 3 steps."""
    B = 4
    cb = MAEStaticInputsCallback(
        batch_size=B, in_chans=3, input_size=(224, 224),
        mask_ratio=0.6, dtype=torch.bfloat16,
    )
    module = _MAEModule()
    # Compile the inner model (the LightningModule does this in production)
    module.model = torch.compile(module.model, mode="reduce-overhead", dynamic=False)
    ds = _RandomDataset(n=12, B=1)
    loader = torch.utils.data.DataLoader(ds, batch_size=B, drop_last=True)

    trainer = Trainer(
        accelerator="gpu", devices=1, precision="bf16-mixed",
        max_steps=3, callbacks=[cb], logger=False,
        enable_progress_bar=False, enable_model_summary=False,
        num_sanity_val_steps=0,
    )
    trainer.fit(module, train_dataloaders=loader)
    # If we got here without "illegal memory access", the path works.
