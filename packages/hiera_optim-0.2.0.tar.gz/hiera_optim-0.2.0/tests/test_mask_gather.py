"""Correctness + speed tests for the Triton mask-gather kernel."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from hiera_optim.kernels.mask_gather import (
    gather_mu_groups, gather_mu_groups_triton, keep_idx_from_bool_mask,
)


def _make_mask(B, num_mu, keep_frac, device, seed=0):
    g = torch.Generator(device=device); g.manual_seed(seed)
    noise = torch.rand(B, num_mu, device=device, generator=g)
    L = int(num_mu * keep_frac)
    ids = torch.argsort(noise, dim=1)
    keep_idx = ids[:, :L].contiguous()
    mask = torch.zeros(B, num_mu, dtype=torch.bool, device=device)
    mask.scatter_(1, keep_idx, True)
    return mask, keep_idx


# Hiera-B stage-0 shapes: 7x7 mask units, mu_size=64 (8x8 tokens)
CASES = [
    # (B, num_mu, mu_size, C, keep_frac)
    (32, 49, 64, 96, 0.4),
    (32, 49, 64, 96, 0.1),
    (64, 49, 64, 96, 0.4),
    (8, 196, 16, 384, 0.4),     # smaller-mu case
    (16, 49, 64, 8, 0.4),         # C < 16
    (4, 49, 64, 192, 0.4),
]


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16, torch.float16])
@pytest.mark.parametrize("case", CASES, ids=lambda c: f"B{c[0]}_M{c[1]}_mu{c[2]}_C{c[3]}_keep{c[4]}")
def test_fwd_matches_torch_gather(case, dtype):
    B, M, MU, C, keep = case
    torch.manual_seed(0)
    device = "cuda"

    mask, keep_idx = _make_mask(B, M, keep, device)
    x = torch.randn(B, M * MU, C, device=device, dtype=dtype)

    y_ref = gather_mu_groups(x, keep_idx, MU)
    y_tri = gather_mu_groups_triton(x, keep_idx, MU)

    assert y_ref.shape == y_tri.shape
    assert torch.equal(y_ref, y_tri), f"Triton fwd diverges from torch.gather, max diff={(y_ref-y_tri).abs().max().item()}"


@pytest.mark.parametrize("case", CASES[:3])
def test_fwd_matches_bool_indexing(case):
    """The Triton output must equal FAIR's boolean-indexing path exactly."""
    B, M, MU, C, keep = case
    torch.manual_seed(0)
    device = "cuda"
    dtype = torch.float32

    mask, keep_idx = _make_mask(B, M, keep, device)
    x = torch.randn(B, M * MU, C, device=device, dtype=dtype)

    # FAIR's boolean path (verbatim from models/hiera.py)
    y_fair = x[mask[..., None].tile(1, MU, x.shape[2])].view(B, -1, C)

    # Triton path needs keep_idx in mask-canonical order (ascending position).
    keep_idx_canon = keep_idx_from_bool_mask(mask)
    y_tri = gather_mu_groups_triton(x, keep_idx_canon, MU)

    assert y_fair.shape == y_tri.shape
    assert torch.equal(y_fair, y_tri), \
        f"Triton ≠ FAIR boolean, max diff={(y_fair-y_tri).abs().max().item()}"


@pytest.mark.parametrize("case", CASES[:3])
@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
def test_bwd_matches_torch_gather(case, dtype):
    B, M, MU, C, keep = case
    torch.manual_seed(0)
    device = "cuda"

    mask, keep_idx = _make_mask(B, M, keep, device)
    x1 = torch.randn(B, M * MU, C, device=device, dtype=dtype, requires_grad=True)
    x2 = x1.detach().clone().requires_grad_(True)

    y1 = gather_mu_groups(x1, keep_idx, MU)
    y2 = gather_mu_groups_triton(x2, keep_idx, MU)

    g = torch.randn_like(y1)
    y1.backward(g); y2.backward(g)

    assert x1.grad.shape == x2.grad.shape
    if dtype == torch.float32:
        assert torch.allclose(x1.grad, x2.grad, atol=1e-6), \
            f"bwd diff max={(x1.grad - x2.grad).abs().max().item()}"
    else:
        assert torch.allclose(x1.grad, x2.grad, atol=1e-2, rtol=1e-2)


def bench():
    """Quick speed comparison."""
    import time
    device = "cuda"
    print(f"\nGPU: {torch.cuda.get_device_name(0)}")
    for case in CASES[:4]:
        B, M, MU, C, keep = case
        mask, keep_idx = _make_mask(B, M, keep, device)
        x = torch.randn(B, M * MU, C, device=device, dtype=torch.bfloat16, requires_grad=True)

        def torch_path():
            y = x[mask[..., None].tile(1, MU, x.shape[2])].view(B, -1, C)
            return y
        def gather_path():
            return gather_mu_groups(x, keep_idx, MU)
        def triton_path():
            return gather_mu_groups_triton(x, keep_idx, MU)

        def time_fwd(fn, n=200):
            for _ in range(20): fn()
            torch.cuda.synchronize()
            s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
            s.record()
            for _ in range(n): fn()
            e.record(); torch.cuda.synchronize()
            return s.elapsed_time(e) / n

        def time_fwdbwd(fn, n=200):
            x.grad = None
            for _ in range(20):
                y = fn(); y.sum().backward(); x.grad = None
            torch.cuda.synchronize()
            s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
            s.record()
            for _ in range(n):
                y = fn(); y.sum().backward(); x.grad = None
            e.record(); torch.cuda.synchronize()
            return s.elapsed_time(e) / n

        t_bool = time_fwd(torch_path)
        t_gather = time_fwd(gather_path)
        t_triton = time_fwd(triton_path)
        t_bool_bw = time_fwdbwd(torch_path)
        t_gather_bw = time_fwdbwd(gather_path)
        t_triton_bw = time_fwdbwd(triton_path)
        print(f"  {case}:")
        print(f"    fwd  bool={t_bool*1000:7.1f}us  gather={t_gather*1000:7.1f}us  triton={t_triton*1000:7.1f}us  "
              f"speedup_vs_bool={t_bool/t_triton:.2f}x")
        print(f"    f+b  bool={t_bool_bw*1000:7.1f}us  gather={t_gather_bw*1000:7.1f}us  triton={t_triton_bw*1000:7.1f}us  "
              f"speedup_vs_bool={t_bool_bw/t_triton_bw:.2f}x")


if __name__ == "__main__":
    import sys
    if "--bench" in sys.argv:
        bench()
    else:
        sys.exit(pytest.main([__file__, "-v"]))
