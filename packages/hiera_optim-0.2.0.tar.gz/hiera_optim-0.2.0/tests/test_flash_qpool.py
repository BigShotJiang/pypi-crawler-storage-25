"""Correctness + speed tests for fused Q-pool + Flash Attention Triton kernel."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from hiera_optim.kernels.flash_qpool import flash_qpool_attention, qpool_attention_ref


# Shapes from Hiera-B q_pool blocks (after the (B, nw) flatten):
# stage-0->1 transition: (Bnw=B*20, H=2, T_full=64, D=96), q_stride=4 -> Tq=16
# stage-1->2 transition: (Bnw=B, H=4, T_full=80, D=96), q_stride=4 -> Tq=20  (global)
CASES = [
    # (B*nw, H, T_full, D, q_stride, T_kv)
    (160, 2, 64, 96, 4, 16),    # stage 0->1: kv has Tq=16
    (32, 4, 80, 96, 4, 20),     # stage 1->2: global, but q-pool happens
    (40, 2, 64, 96, 4, 16),     # smaller batch
    (160, 2, 64, 64, 4, 16),    # D=64 variant
    (160, 2, 32, 64, 2, 16),    # q_stride=2
]


@pytest.mark.parametrize("dtype", [torch.bfloat16, torch.float16])
@pytest.mark.parametrize("case", CASES, ids=lambda c: f"B{c[0]}_H{c[1]}_T{c[2]}_D{c[3]}_qs{c[4]}")
def test_fwd_matches_ref(case, dtype):
    B, H, T_full, D, qs, T_kv = case
    torch.manual_seed(0)
    device = "cuda"
    q_full = torch.randn(B, H, T_full, D, device=device, dtype=dtype)
    k = torch.randn(B, H, T_kv, D, device=device, dtype=dtype)
    v = torch.randn(B, H, T_kv, D, device=device, dtype=dtype)
    y_tri = flash_qpool_attention(q_full, k, v, qs)
    y_ref = qpool_attention_ref(q_full, k, v, qs)
    assert y_tri.shape == y_ref.shape
    diff = (y_tri.float() - y_ref.float()).abs()
    max_abs = diff.max().item()
    rms = diff.pow(2).mean().sqrt().item()
    ref_rms = y_ref.float().pow(2).mean().sqrt().item()
    rel = rms / (ref_rms + 1e-9)
    # bf16/fp16 attention with online softmax: ~1e-2 abs OK
    assert rel < 0.05, f"rel RMS diff {rel} max={max_abs}"


@pytest.mark.parametrize("case", CASES[:3])
def test_bwd_matches_ref(case):
    B, H, T_full, D, qs, T_kv = case
    torch.manual_seed(0)
    device = "cuda"; dtype = torch.bfloat16
    q1 = torch.randn(B, H, T_full, D, device=device, dtype=dtype, requires_grad=True)
    k1 = torch.randn(B, H, T_kv, D, device=device, dtype=dtype, requires_grad=True)
    v1 = torch.randn(B, H, T_kv, D, device=device, dtype=dtype, requires_grad=True)
    q2 = q1.detach().clone().requires_grad_(True)
    k2 = k1.detach().clone().requires_grad_(True)
    v2 = v1.detach().clone().requires_grad_(True)

    y_tri = flash_qpool_attention(q1, k1, v1, qs)
    y_ref = qpool_attention_ref(q2, k2, v2, qs)
    g = torch.randn_like(y_tri)
    y_tri.backward(g); y_ref.backward(g)

    for name, a, b in [("dQ", q1.grad, q2.grad), ("dK", k1.grad, k2.grad), ("dV", v1.grad, v2.grad)]:
        diff = (a.float() - b.float()).abs()
        rms = diff.pow(2).mean().sqrt().item()
        ref = b.float().pow(2).mean().sqrt().item()
        rel = rms / (ref + 1e-9)
        assert rel < 0.05, f"{name} rel RMS {rel}"


def bench():
    """Speed comparison vs the ref pipeline."""
    import time
    device = "cuda"
    print(f"\nGPU: {torch.cuda.get_device_name(0)}")
    for case in CASES:
        B, H, T_full, D, qs, T_kv = case
        for dtype in [torch.bfloat16]:
            q = torch.randn(B, H, T_full, D, device=device, dtype=dtype, requires_grad=True)
            k = torch.randn(B, H, T_kv, D, device=device, dtype=dtype, requires_grad=True)
            v = torch.randn(B, H, T_kv, D, device=device, dtype=dtype, requires_grad=True)

            def ref():
                return qpool_attention_ref(q, k, v, qs)
            def tri():
                return flash_qpool_attention(q, k, v, qs)

            def time_fwd(fn, n=500):
                for _ in range(20): fn()
                torch.cuda.synchronize()
                s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
                s.record()
                for _ in range(n): fn()
                e.record(); torch.cuda.synchronize()
                return s.elapsed_time(e) / n

            def time_fwdbwd(fn, n=200):
                q.grad = k.grad = v.grad = None
                for _ in range(20):
                    y = fn(); y.sum().backward()
                    q.grad = k.grad = v.grad = None
                torch.cuda.synchronize()
                s = torch.cuda.Event(enable_timing=True); e = torch.cuda.Event(enable_timing=True)
                s.record()
                for _ in range(n):
                    y = fn(); y.sum().backward()
                    q.grad = k.grad = v.grad = None
                e.record(); torch.cuda.synchronize()
                return s.elapsed_time(e) / n

            t_ref = time_fwd(ref); t_tri = time_fwd(tri)
            tb_ref = time_fwdbwd(ref); tb_tri = time_fwdbwd(tri)
            print(f"  {case} {dtype}:")
            print(f"    fwd   ref={t_ref*1000:7.1f}us  tri={t_tri*1000:7.1f}us  speedup={t_ref/t_tri:.2f}x")
            print(f"    f+b   ref={tb_ref*1000:7.1f}us  tri={tb_tri*1000:7.1f}us  speedup={tb_ref/tb_tri:.2f}x")


if __name__ == "__main__":
    if "--bench" in sys.argv:
        bench()
    else:
        sys.exit(pytest.main([__file__, "-v"]))
