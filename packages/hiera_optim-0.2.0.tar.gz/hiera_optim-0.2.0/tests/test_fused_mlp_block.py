"""Correctness for FusedMlpBlock (fwd + bwd) against a reference impl.

The reference is `x + fc2(GELU(fc1(LN(x))))` built from torch.nn ops.
We verify forward outputs and all parameter / input gradients match.
"""
import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

from hiera_optim.kernels.fused_mlp_block import FusedMlpBlock


class RefMlpBlock(nn.Module):
    def __init__(self, dim, hidden, eps=1e-6):
        super().__init__()
        self.norm = nn.LayerNorm(dim, eps=eps)
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)

    def forward(self, x):
        return x + self.fc2(F.gelu(self.fc1(self.norm(x)), approximate="tanh"))


@pytest.mark.parametrize("dtype,B,N,dim,hidden", [
    # fp32 only on the small case — wider K hits SMEM cap in fp32 path
    (torch.float32, 2, 64, 96, 384),
    (torch.bfloat16, 2, 64, 96, 384),
    (torch.bfloat16, 2, 32, 192, 768),
    (torch.bfloat16, 1, 16, 384, 1536),
])
def test_fwd_bwd_matches_ref(dtype, B, N, dim, hidden):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    torch.manual_seed(0)

    ref = RefMlpBlock(dim, hidden).to(device, dtype)
    fused = FusedMlpBlock(dim, hidden).to(device, dtype)
    with torch.no_grad():
        fused.ln_weight.copy_(ref.norm.weight)
        fused.ln_bias.copy_(ref.norm.bias)
        fused.fc1_weight.copy_(ref.fc1.weight)
        fused.fc1_bias.copy_(ref.fc1.bias)
        fused.fc2_weight.copy_(ref.fc2.weight)
        fused.fc2_bias.copy_(ref.fc2.bias)

    x_ref = torch.randn(B, N, dim, device=device, dtype=dtype, requires_grad=True)
    x_fused = x_ref.detach().clone().requires_grad_(True)
    grad_out = torch.randn_like(x_ref) * 0.1

    y_ref = ref(x_ref); y_ref.backward(grad_out)
    y_fused = fused(x_fused); y_fused.backward(grad_out)

    # Triton tl.dot uses TF32 for fp32 inputs; relax to rel RMS for fp32 too.
    atol = 5e-2 if dtype == torch.bfloat16 else 5e-3
    rtol = 5e-2 if dtype == torch.bfloat16 else 5e-3

    # Forward
    assert torch.allclose(y_ref, y_fused, atol=atol, rtol=rtol), \
        f"fwd diff max: {(y_ref - y_fused).abs().max()}"

    # Backward — input
    g_ref = x_ref.grad
    g_fused = x_fused.grad
    diff = (g_ref - g_fused).float().pow(2).mean().sqrt() / g_ref.float().pow(2).mean().sqrt().clamp_min(1e-12)
    assert diff < (5e-2 if dtype == torch.bfloat16 else 5e-3), f"grad_x rel RMS too large: {diff}"

    # Backward — params
    for (n_ref, p_ref), (n_fused, p_fused) in zip(
        [("norm.w", ref.norm.weight), ("norm.b", ref.norm.bias),
         ("fc1.w", ref.fc1.weight), ("fc1.b", ref.fc1.bias),
         ("fc2.w", ref.fc2.weight), ("fc2.b", ref.fc2.bias)],
        [("ln_w", fused.ln_weight), ("ln_b", fused.ln_bias),
         ("fc1_w", fused.fc1_weight), ("fc1_b", fused.fc1_bias),
         ("fc2_w", fused.fc2_weight), ("fc2_b", fused.fc2_bias)],
    ):
        gr = p_ref.grad.float()
        gf = p_fused.grad.float()
        rms = (gr - gf).pow(2).mean().sqrt() / gr.pow(2).mean().sqrt().clamp_min(1e-12)
        assert rms < (1e-1 if dtype == torch.bfloat16 else 5e-3), \
            f"{n_fused} rel RMS too large: {rms.item()}"
