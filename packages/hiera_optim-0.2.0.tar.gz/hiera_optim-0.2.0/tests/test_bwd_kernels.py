"""Numerical correctness for the fused-inverse bwd kernels.

These verify the two new layout-fused inverse matmuls match the unfused
ATen path (matmul + permute + reshape) within bf16/fp32 tolerance.
"""
import pytest
import torch

from hiera_optim.kernels.fused_qkv_preamble_bwd import inv_qkv_preamble
from hiera_optim.kernels.fused_proj_epilogue_bwd import inv_proj_epilogue


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
@pytest.mark.parametrize("B,N,dim,heads,window_size", [
    (2, 8 * 64, 96, 1, 8),    # stage 0 mask units
    (2, 4 * 64, 192, 2, 8),
    (2, 8 * 16, 96, 1, 16),
])
def test_inv_qkv_preamble_matches_ref(dtype, B, N, dim, heads, window_size):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    head_dim = dim // heads
    dim_out = heads * head_dim
    T = window_size
    nw = N // T
    assert N == T * nw

    torch.manual_seed(0)
    grad_q = torch.randn(B * nw, heads, T, head_dim, device=device, dtype=dtype) * 0.1
    grad_k = torch.randn_like(grad_q) * 0.1
    grad_v = torch.randn_like(grad_q) * 0.1
    qkv_w = torch.randn(3 * dim_out, dim, device=device, dtype=dtype) * 0.05

    # Reference: pack grads in (3, B*nw, H, T, D), permute back to (B, N, 3*dim_out), matmul w.
    grad_qkv_4d = torch.stack([grad_q, grad_k, grad_v], dim=0)
    grad_qkv = grad_qkv_4d.view(3, B, nw, heads, T, head_dim).permute(1, 4, 2, 0, 3, 5).contiguous()
    grad_qkv = grad_qkv.view(B, N, 3 * dim_out)
    ref_grad_y_ln = grad_qkv @ qkv_w

    fused_grad_y_ln = inv_qkv_preamble(grad_q, grad_k, grad_v, qkv_w, nw)

    # Triton tl.dot uses TF32 for fp32 inputs (matches PyTorch's default on Ampere+).
    # We rely on relative RMS rather than allclose for fp32 numerical agreement.
    diff = (fused_grad_y_ln - ref_grad_y_ln).float()
    rms = diff.pow(2).mean().sqrt()
    ref_rms = ref_grad_y_ln.float().pow(2).mean().sqrt()
    rel_rms = (rms / ref_rms.clamp_min(1e-12)).item()
    assert rel_rms < (5e-2 if dtype == torch.bfloat16 else 5e-3), \
        f"rel RMS too large: {rel_rms}"


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
@pytest.mark.parametrize("B,N,dim_out,heads,window_size", [
    (2, 8 * 64, 96, 1, 8),
    (2, 4 * 64, 192, 2, 8),
    (2, 8 * 16, 96, 1, 16),
])
def test_inv_proj_epilogue_matches_ref(dtype, B, N, dim_out, heads, window_size):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    device = "cuda"
    head_dim = dim_out // heads
    T = window_size
    nw = N // T

    torch.manual_seed(0)
    grad_out = torch.randn(B, N, dim_out, device=device, dtype=dtype) * 0.1
    proj_w = torch.randn(dim_out, dim_out, device=device, dtype=dtype) * 0.05

    # Reference: grad_z_packed = grad_out @ proj_w; reshape/permute to 4D.
    grad_z_packed = grad_out @ proj_w
    ref_grad_z = (grad_z_packed.view(B, T, nw, heads, head_dim)
                                .permute(0, 2, 3, 1, 4)
                                .reshape(B * nw, heads, T, head_dim)
                                .contiguous())

    fused_grad_z = inv_proj_epilogue(grad_out, proj_w, nw, heads, head_dim, T)

    diff = (fused_grad_z - ref_grad_z).float()
    rms = diff.pow(2).mean().sqrt()
    ref_rms = ref_grad_z.float().pow(2).mean().sqrt()
    rel_rms = (rms / ref_rms.clamp_min(1e-12)).item()
    assert rel_rms < (5e-2 if dtype == torch.bfloat16 else 5e-3), \
        f"rel RMS too large: {rel_rms}"
