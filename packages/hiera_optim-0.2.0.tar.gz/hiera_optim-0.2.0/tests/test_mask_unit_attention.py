"""Correctness test: MaskUnitAttentionFast vs FAIR's MaskUnitAttention."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import torch
import pytest

from models.hiera import MaskUnitAttention
from hiera_optim.attention.mask_unit import MaskUnitAttentionFast, copy_weights_from_orig


CASES = [
    # (dim, dim_out, heads, q_stride, window_size, use_mu, B, N) — Hiera-B stages with B=8
    # Stage 0: 96d, 1h, q=1, ws=64, mu-attn, after mask: B=8, N=20*64=1280
    (96, 96, 1, 1, 64, True, 8, 20 * 64),
    # Stage 1 first block: q_pool, dim 96->192, q=4, ws=16, mu-attn
    # input has N=1280 (still 64 tokens per window before pool)
    (96, 192, 2, 4, 16, True, 8, 20 * 64),
    # Stage 1 later: 192d, 2h, q=1, ws=16, mu-attn, N=20*16=320
    (192, 192, 2, 1, 16, True, 8, 20 * 16),
    # Stage 2 first block: dim 192->384, q=4, ws=4, GLOBAL attn
    (192, 384, 4, 4, 4, False, 8, 20 * 16),
    # Stage 2 later: 384d, 4h, global
    (384, 384, 4, 1, 4, False, 8, 20 * 4),
    # Stage 3 first block: 384->768, q=4, GLOBAL
    (384, 768, 8, 4, 1, False, 8, 20 * 4),
    # Stage 3 later: 768d, 8h, GLOBAL, ws=1
    (768, 768, 8, 1, 1, False, 8, 20),
]


@pytest.mark.parametrize("case", CASES, ids=lambda c: f"d{c[0]}->d{c[1]}_qs{c[3]}_ws{c[4]}_{'mu' if c[5] else 'g'}_N{c[7]}")
@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
def test_numerical_equivalence(case, dtype):
    dim, dim_out, heads, q_stride, ws, use_mu, B, N = case
    torch.manual_seed(0)
    device = "cuda"

    orig = MaskUnitAttention(dim, dim_out, heads, q_stride, ws, use_mu).to(device, dtype)
    fast = MaskUnitAttentionFast(dim, dim_out, heads, q_stride, ws, use_mu).to(device, dtype)
    copy_weights_from_orig(fast, orig)

    x = torch.randn(B, N, dim, device=device, dtype=dtype)

    with torch.no_grad():
        y_orig = orig(x)
        y_fast = fast(x)

    assert y_orig.shape == y_fast.shape, f"shape mismatch {y_orig.shape} vs {y_fast.shape}"

    diff = (y_orig.float() - y_fast.float()).abs()
    max_abs = diff.max().item()
    rms = diff.pow(2).mean().sqrt().item()
    ref_rms = y_orig.float().pow(2).mean().sqrt().item()
    # bf16 noise tolerance: SDPA backend switch is order ~1e-2 max, ~1e-3 RMS
    if dtype == torch.bfloat16:
        assert max_abs < 0.05, f"bf16 max diff too large: {max_abs}"
        assert rms / ref_rms < 0.02, f"bf16 RMS diff too large: rel={rms/ref_rms}"
    else:
        # fp32 may still differ a bit because flash uses fp32 accumulator with different reduce order
        assert max_abs < 1e-3, f"fp32 max diff: {max_abs}"
        assert rms / ref_rms < 1e-4, f"fp32 RMS rel diff: {rms/ref_rms}"


@pytest.mark.parametrize("case", CASES[:3], ids=lambda c: f"d{c[0]}_qs{c[3]}_ws{c[4]}")
def test_backward_equivalence(case):
    dim, dim_out, heads, q_stride, ws, use_mu, B, N = case
    torch.manual_seed(0)
    device = "cuda"
    dtype = torch.bfloat16

    orig = MaskUnitAttention(dim, dim_out, heads, q_stride, ws, use_mu).to(device, dtype)
    fast = MaskUnitAttentionFast(dim, dim_out, heads, q_stride, ws, use_mu).to(device, dtype)
    copy_weights_from_orig(fast, orig)

    x1 = torch.randn(B, N, dim, device=device, dtype=dtype, requires_grad=True)
    x2 = x1.detach().clone().requires_grad_(True)

    y1 = orig(x1); y2 = fast(x2)
    g = torch.randn_like(y1)
    y1.backward(g); y2.backward(g)

    diff = (x1.grad.float() - x2.grad.float()).abs()
    rms = diff.pow(2).mean().sqrt().item()
    ref_rms = x1.grad.float().pow(2).mean().sqrt().item()
    assert rms / ref_rms < 0.02, f"input-grad RMS rel diff: {rms/ref_rms}"
    # also check qkv grad
    diff_qkv = (orig.qkv.weight.grad.float() - fast.qkv.weight.grad.float()).abs()
    rms_qkv = diff_qkv.pow(2).mean().sqrt().item()
    ref_qkv = orig.qkv.weight.grad.float().pow(2).mean().sqrt().item()
    assert rms_qkv / ref_qkv < 0.02, f"qkv-grad RMS rel diff: {rms_qkv/ref_qkv}"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
