"""Verify torch.compile(mode='reduce-overhead') actually captures with the
graph-safe MAE.

Failure mode pre-fix: CUDA illegal memory access on the first replayed step.
"""
import os, sys, pytest, torch

from models.hiera import mae_hiera_tiny_224
from hiera_optim.patch import optimize as optimize_model, make_mae_mask


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_reduce_overhead_compile_runs_graph_safe():
    device = torch.device("cuda")
    dtype = torch.bfloat16
    torch.manual_seed(0)

    B = 4
    model = mae_hiera_tiny_224(pretrained=False, in_chans=3,
                               input_size=(224, 224)).to(device, dtype)
    optimize_model(model, swap_attention=True, swap_gather=True,
                   graph_safe=True, verbose=True)

    # Pre-allocate static buffers
    mask, keep_idx = make_mae_mask(model, B, 0.6, device)
    mask_buf = mask.clone()
    keep_idx_buf = keep_idx.clone()
    x_buf = torch.randn(B, 3, 224, 224, device=device, dtype=dtype)

    compiled = torch.compile(model, mode="reduce-overhead", dynamic=False)
    opt = torch.optim.AdamW(compiled.parameters(), lr=3e-4, fused=True)

    # Run a few steps. Each step: refresh mask in-place into the static buffer.
    for step in range(3):
        new_mask, new_keep_idx = make_mae_mask(model, B, 0.6, device)
        mask_buf.copy_(new_mask)
        keep_idx_buf.copy_(new_keep_idx)

        opt.zero_grad(set_to_none=True)
        out = compiled(x_buf, mask_ratio=0.6, mask=mask_buf, keep_idx=keep_idx_buf)
        out[0].backward()
        opt.step()
    torch.cuda.synchronize()
    print("3 steps under reduce-overhead compile succeeded (no illegal memory access)")
