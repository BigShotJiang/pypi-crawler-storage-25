"""End-to-end equivalence: optimized MAE-Hiera output matches FAIR within bf16 noise.

We seed the mask randomness, then run baseline and optimized with the SAME
mask. Compare encoder latent, decoder prediction, loss, and gradients.
"""
import sys
import copy
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from models.hiera import mae_hiera_base_224
from hiera_optim.patch import optimize as optimize_model


def _build(in_chans=8, img=224, dtype=torch.bfloat16, device="cuda", seed=0):
    torch.manual_seed(seed)
    m = mae_hiera_base_224(pretrained=False, in_chans=in_chans, input_size=(img, img))
    return m.to(device, dtype)


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
def test_forward_matches_with_same_mask(dtype):
    device = "cuda"
    B = 4
    base = _build(in_chans=8, dtype=dtype, device=device)
    opt = copy.deepcopy(base)
    optimize_model(opt)

    x = torch.randn(B, 8, 224, 224, device=device, dtype=dtype)

    # Same mask both runs
    torch.manual_seed(123)
    mask = base.get_random_mask(x, mask_ratio=0.6)
    torch.manual_seed(123)
    mask2 = base.get_random_mask(x, mask_ratio=0.6)
    assert torch.equal(mask, mask2)

    with torch.no_grad():
        l_base, pred_base, lab_base, mask_base = base(x, mask_ratio=0.6, mask=mask)
        l_opt, pred_opt, lab_opt, mask_opt = opt(x, mask_ratio=0.6, mask=mask)

    assert torch.equal(mask_base, mask_opt)
    assert torch.equal(lab_base, lab_opt), "pixel labels should match exactly (same input)"

    # Loss diff bound depends on dtype + SDPA-backend switch.
    diff = (l_base.float() - l_opt.float()).abs().item()
    if dtype == torch.float32:
        # fp32 keeps SDPA in math both ways; tiny diff from gather reorder if any.
        assert diff < 1e-4, f"fp32 loss diff: {diff}"
    else:
        # bf16: SDPA switches math→flash, so noise grows. Loss is a normalized MSE
        # so should still be very close.
        assert diff < 0.05, f"bf16 loss diff: {diff}"

    # Prediction diff
    pdiff = (pred_base.float() - pred_opt.float()).abs()
    rms = pdiff.pow(2).mean().sqrt().item()
    ref = pred_base.float().pow(2).mean().sqrt().item()
    rel = rms / ref
    tol = 1e-4 if dtype == torch.float32 else 0.05
    assert rel < tol, f"pred RMS rel diff: {rel}"


def test_backward_matches():
    """Gradients flow through and match within bf16 noise."""
    device = "cuda"
    dtype = torch.bfloat16
    B = 4
    base = _build(in_chans=8, dtype=dtype, device=device)
    opt = copy.deepcopy(base)
    optimize_model(opt)

    x = torch.randn(B, 8, 224, 224, device=device, dtype=dtype)
    torch.manual_seed(123)
    mask = base.get_random_mask(x, 0.6)

    l_base, _, _, _ = base(x, mask_ratio=0.6, mask=mask)
    l_opt, _, _, _ = opt(x, mask_ratio=0.6, mask=mask)
    l_base.backward(); l_opt.backward()

    # Compare a couple of key parameter grads
    keys = ["patch_embed.proj.weight", "blocks.0.norm1.weight", "blocks.0.attn.qkv.weight",
            "blocks.5.attn.qkv.weight", "blocks.23.mlp.fc2.weight",
            "decoder_pred.weight", "mask_token"]
    base_params = dict(base.named_parameters())
    opt_params = dict(opt.named_parameters())
    for k in keys:
        if k not in base_params or k not in opt_params:
            continue
        g_b = base_params[k].grad; g_o = opt_params[k].grad
        if g_b is None or g_o is None:
            continue
        diff = (g_b.float() - g_o.float()).abs()
        rms = diff.pow(2).mean().sqrt().item()
        ref = g_b.float().pow(2).mean().sqrt().item()
        if ref < 1e-9:
            continue
        rel = rms / ref
        # patch_embed sits 24 attn blocks downstream so bf16+SDPA-switch
        # noise compounds. ~10% RMS diff is within bf16 noise floor for
        # gradients that flow through that many flash-vs-math transitions.
        tol = 0.12 if "patch_embed" in k else 0.06
        assert rel < tol, f"grad RMS rel diff on {k}: {rel}"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v", "-s"]))
