"""Tests for pack_qkv_grad and pack_z (the bwd-side layout kernels)."""
import pytest
import torch

from hiera_optim.kernels.pack_qkv_grad import pack_qkv_grad
from hiera_optim.kernels.pack_z import pack_z


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
@pytest.mark.parametrize("B,dim,heads,T,nw", [
    (2, 96, 1, 64, 8),
    (4, 192, 2, 32, 16),
    (1, 768, 12, 16, 8),
    (3, 144, 3, 8, 8),     # head_dim=48 (non-pow2-aligned with stage tile)
])
def test_pack_qkv_grad_matches_aten(dtype, B, dim, heads, T, nw):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    head_dim = dim // heads
    dim_out = dim
    N = T * nw
    device = "cuda"

    torch.manual_seed(0)
    grad_q = torch.randn(B*nw, heads, T, head_dim, device=device, dtype=dtype)
    grad_k = torch.randn_like(grad_q)
    grad_v = torch.randn_like(grad_q)
    ref = (torch.stack([grad_q, grad_k, grad_v], 0)
           .view(3, B, nw, heads, T, head_dim)
           .permute(1, 4, 2, 0, 3, 5)
           .contiguous()
           .view(B, N, 3 * dim_out))
    out = pack_qkv_grad(grad_q, grad_k, grad_v, nw)
    assert torch.equal(out, ref)


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16])
@pytest.mark.parametrize("B,dim,heads,T,nw", [
    (2, 96, 1, 64, 8),
    (4, 192, 2, 32, 16),
    (1, 768, 12, 16, 8),
])
def test_pack_z_matches_aten(dtype, B, dim, heads, T, nw):
    if not torch.cuda.is_available():
        pytest.skip("no CUDA")
    head_dim = dim // heads
    dim_out = dim
    N = T * nw
    device = "cuda"

    torch.manual_seed(0)
    z = torch.randn(B*nw, heads, T, head_dim, device=device, dtype=dtype)
    ref = (z.view(B, nw, heads, T, head_dim)
            .permute(0, 3, 1, 2, 4)
            .reshape(B, N, dim_out)
            .contiguous())
    out = pack_z(z, nw)
    assert torch.equal(out, ref)
