"""Correctness + memory + speed tests for selective stage checkpointing."""
import sys, copy
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from models.hiera import mae_hiera_base_224
from hiera_optim.patch import optimize as optimize_model
from hiera_optim.checkpoint import (
    enable_stage_checkpointing, disable_stage_checkpointing, _CheckpointedBlock,
)


def _build(device="cuda", dtype=torch.bfloat16, seed=0):
    torch.manual_seed(seed)
    m = mae_hiera_base_224(pretrained=False, in_chans=8, input_size=(224, 224))
    return m.to(device, dtype)


def test_idempotent_and_count():
    m = _build()
    optimize_model(m)
    n = enable_stage_checkpointing(m, stages=(2,))
    assert n == 16, f"expected 16 stage-2 blocks; got {n}"
    # idempotent
    n2 = enable_stage_checkpointing(m, stages=(2,))
    assert n2 == 0
    # disable returns same count
    nd = disable_stage_checkpointing(m)
    assert nd == 16


def test_forward_matches_baseline():
    """fwd output with checkpointing matches without, given the same mask."""
    m_base = _build()
    optimize_model(m_base)
    m_chk = copy.deepcopy(m_base)
    enable_stage_checkpointing(m_chk, stages=(2,))

    x = torch.randn(2, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
    torch.manual_seed(123); mask = m_base.get_random_mask(x, 0.6)

    with torch.no_grad():
        l_base, _, _, _ = m_base(x, mask_ratio=0.6, mask=mask)
        l_chk, _, _, _ = m_chk(x, mask_ratio=0.6, mask=mask)

    assert torch.allclose(l_base.float(), l_chk.float(), atol=1e-3, rtol=1e-3), \
        f"loss diff: {(l_base - l_chk).abs().item()}"


def test_backward_matches_baseline():
    """Gradients with checkpointing match without (small B for fast test)."""
    m_base = _build()
    optimize_model(m_base)
    m_chk = copy.deepcopy(m_base)
    enable_stage_checkpointing(m_chk, stages=(2,))

    # Need same dropout state etc.; with no dropout this is straightforward
    x_base = torch.randn(2, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
    x_chk = x_base.detach().clone()
    torch.manual_seed(123); mask = m_base.get_random_mask(x_base, 0.6)

    l_base = m_base(x_base, mask_ratio=0.6, mask=mask)[0]
    l_chk = m_chk(x_chk, mask_ratio=0.6, mask=mask)[0]
    l_base.backward(); l_chk.backward()

    # Compare a few representative parameter grads
    keys = ["patch_embed.proj.weight", "blocks.10.attn.qkv.weight", "blocks.22.mlp.fc2.weight"]
    base_params = dict(m_base.named_parameters())
    chk_params = dict(m_chk.named_parameters())
    for k in keys:
        # NOTE: m_chk's blocks may be wrapped, so the key changes to "blocks.10.block.attn..."
        # Try both forms.
        if k in chk_params:
            g_chk = chk_params[k].grad
        else:
            alt = k.replace("blocks.", "blocks.").replace(".attn", ".block.attn").replace(".mlp", ".block.mlp")
            assert alt in chk_params, f"can't find {k} or {alt} in checkpointed model"
            g_chk = chk_params[alt].grad
        g_base = base_params[k].grad
        if g_base is None or g_chk is None:
            continue
        diff = (g_base.float() - g_chk.float()).abs()
        rms = diff.pow(2).mean().sqrt().item()
        ref = g_base.float().pow(2).mean().sqrt().item()
        if ref < 1e-9: continue
        rel = rms / ref
        tol = 0.12 if "patch_embed" in k else 0.06
        assert rel < tol, f"grad rel RMS for {k}: {rel}"


def test_memory_savings_grows_with_batch():
    """Memory savings from stage-2 checkpointing grow proportionally with B
    because activations scale linearly while parameter/workspace overhead is
    fixed. Test at B=32 and B=64 — savings ratio should grow."""
    saves = {}
    for B in (32, 64):
        torch.cuda.empty_cache()
        m1 = _build(); optimize_model(m1)
        x = torch.randn(B, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
        for _ in range(3): m1(x, mask_ratio=0.6)[0].backward(); m1.zero_grad(set_to_none=True)
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
        m1(x, mask_ratio=0.6)[0].backward(); m1.zero_grad(set_to_none=True)
        peak_nocheck = torch.cuda.max_memory_allocated()
        del m1; torch.cuda.empty_cache()

        m2 = _build(); optimize_model(m2)
        enable_stage_checkpointing(m2, stages=(2,))
        for _ in range(3): m2(x, mask_ratio=0.6)[0].backward(); m2.zero_grad(set_to_none=True)
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
        m2(x, mask_ratio=0.6)[0].backward(); m2.zero_grad(set_to_none=True)
        peak_check = torch.cuda.max_memory_allocated()
        del m2; torch.cuda.empty_cache()

        savings_pct = (1 - peak_check / peak_nocheck) * 100
        saves[B] = (peak_nocheck, peak_check, savings_pct)
        print(f"  B={B:3d}: peak {peak_nocheck/1e6:.0f}→{peak_check/1e6:.0f} MB ({savings_pct:.1f}% saved)")

    # At every batch, peak should drop meaningfully (>=10% on at least one)
    for B, (pn, pc, _) in saves.items():
        assert pc < pn, f"B={B}: checkpoint didn't reduce peak ({pn} -> {pc})"
    # At least one of the tested batches should show ≥10% savings
    assert max(s[2] for s in saves.values()) >= 10.0, \
        f"expected ≥10% savings at some B; got max {max(s[2] for s in saves.values()):.1f}%"


def test_max_batch_fits_more_with_checkpointing():
    """The real win: checkpointing should let us run a batch that OOMs without it.

    On RTX 4090 (24 GB), Hiera-Base without checkpointing OOMs around B≈320.
    Skip this test on small GPUs or just sanity-check that B=128 fits with
    checkpointing where it'd be tight without.
    """
    free_gb = torch.cuda.mem_get_info()[0] / 1e9
    if free_gb < 12:
        pytest.skip(f"need ≥12 GB free; have {free_gb:.1f} GB")

    B = 192
    torch.cuda.empty_cache()
    m = _build(); optimize_model(m)
    enable_stage_checkpointing(m, stages=(2,))
    x = torch.randn(B, 8, 224, 224, device="cuda", dtype=torch.bfloat16)
    try:
        m(x, mask_ratio=0.6)[0].backward()
    except torch.cuda.OutOfMemoryError as ex:
        pytest.fail(f"B={B} with checkpointing OOM'd: {ex}")
    print(f"  B={B} fit with stage-2 checkpointing; free now {torch.cuda.mem_get_info()[0]/1e9:.1f} GB")


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v", "-s"]))
