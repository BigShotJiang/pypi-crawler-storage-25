"""Per-backend correctness check: all backends produce numerically close output
to the default-backend reference for Hiera-style attention shapes.

Backends that don't support the shape (head_dim=96 not in cuDNN's 64/128 etc.)
fall back via PyTorch's error and that's flagged with a SkipTest.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest
import torch

from hiera_optim.attention.mask_unit import MaskUnitAttentionFast, copy_weights_from_orig
from models.hiera import MaskUnitAttention


# Hiera-B real stages, plus a head_dim=64 case which is the cuDNN sweet spot
CASES = [
    (96, 96, 1, 1, 64, True, 4, 20 * 64),
    (96, 192, 2, 4, 16, True, 4, 20 * 64),
    (192, 384, 4, 4, 4, False, 4, 20 * 16),
    (384, 768, 8, 4, 1, False, 4, 20 * 4),
    # head_dim=64 (cuDNN sweet spot): 128->128, 2h
    (128, 128, 2, 1, 64, True, 4, 20 * 64),
]


@pytest.mark.parametrize("backend", ["cudnn", "flash", "mem_efficient"])
@pytest.mark.parametrize("case", CASES, ids=lambda c: f"d{c[0]}->{c[1]}_qs{c[3]}")
def test_backend_matches_default(case, backend):
    dim, dim_out, heads, q_stride, ws, use_mu, B, N = case
    torch.manual_seed(0)
    device, dtype = "cuda", torch.bfloat16

    ref = MaskUnitAttentionFast(dim, dim_out, heads, q_stride, ws, use_mu).to(device, dtype)
    pinned = MaskUnitAttentionFast(dim, dim_out, heads, q_stride, ws, use_mu, sdpa_backend=backend).to(device, dtype)
    # Same weights
    pinned.qkv.load_state_dict(ref.qkv.state_dict())
    pinned.proj.load_state_dict(ref.proj.state_dict())

    x = torch.randn(B, N, dim, device=device, dtype=dtype)

    try:
        with torch.no_grad():
            y_ref = ref(x)
            y_pin = pinned(x)
    except RuntimeError as ex:
        if "No available kernel" in str(ex) or "not supported" in str(ex).lower():
            pytest.skip(f"backend={backend} unavailable for shape {case}: {str(ex)[:80]}")
        raise

    diff = (y_ref.float() - y_pin.float()).abs()
    max_abs = diff.max().item()
    rms = diff.pow(2).mean().sqrt().item()
    ref_rms = y_ref.float().pow(2).mean().sqrt().item()
    rel = rms / (ref_rms + 1e-9)
    # bf16 + different attention backend: small noise expected
    assert rel < 0.05, f"{backend} rel RMS diff {rel} max={max_abs}"


def test_invalid_backend_raises():
    with pytest.raises(ValueError):
        MaskUnitAttentionFast(96, 96, 1, sdpa_backend="bogus")


def test_callable_backend_hint():
    """patch_model.swap_mask_unit_attention should accept a callable that
    returns a per-block backend hint."""
    from models.hiera import mae_hiera_base_224
    from hiera_optim.patch import swap_mask_unit_attention

    m = mae_hiera_base_224(pretrained=False, in_chans=8, input_size=(224, 224)).cuda().to(torch.bfloat16)

    seen = []

    def picker(idx, block):
        seen.append((idx, block.attn.dim, block.attn.dim_out, block.attn.use_mask_unit_attn))
        # mu-attn → mem_efficient; global attn → flash. Stage 0 = first 2 blocks.
        return "mem_efficient" if block.attn.use_mask_unit_attn else "flash"

    n = swap_mask_unit_attention(m, sdpa_backend=picker)
    assert n == 32, f"expected 32 attention modules in MAE-Hiera-Base, got {n}"
    assert len(seen) == 32
    # First two blocks (stage 0) use mu-attn → mem_efficient
    assert all(b.attn.sdpa_backend == "mem_efficient" for b in m.modules() if hasattr(b, "attn") and getattr(b.attn, "use_mask_unit_attn", False))


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
