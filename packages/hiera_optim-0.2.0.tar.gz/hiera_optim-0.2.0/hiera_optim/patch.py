"""High-level entry points.

`optimize(model, ...)` is the only thing 99% of users need. It auto-detects
the model family via an adapter, swaps in the optimized attention modules,
optionally rewires the masked-gather / decoder-scatter to use explicit
indexing, and returns the same model object.

Everything below is intentionally model-name-free; FAIR-specific knowledge
lives in `hiera_optim.adapters.hiera`.
"""
from __future__ import annotations
from typing import Callable, Optional, Union
import math
import types

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint as torch_checkpoint

from .attention import MaskUnitAttentionFast, copy_weights_from_orig, BACKEND_NAMES
from .attention.mask_unit_fused import FusedMaskUnitAttention
from .kernels.fused_mlp_block import FusedMlpBlock
from .ops.mask_gather import (
    gather_mu_groups,
    scatter_decoder_tokens,
    keep_idx_from_bool_mask,
)
from .adapters import HieraAdapter, get_hiera_adapter


BackendHint = Union[
    str, None,
    Callable[[int, nn.Module], Optional[str]],
]


# ---------------------------------------------------------------------------
# Backend recommendation heuristic
# ---------------------------------------------------------------------------

def recommended_backend(model: nn.Module, compile_enabled: bool = True) -> BackendHint:
    """Empirical-best SDPA backend per Hiera variant on H100.

    Calibrated against the GH200 sweep in `hiera_optim/cluster/`:
      - Hiera-Base + compile + bf16: mu-attn → mem_efficient, global → cudnn
        (clean-state replication gives this no extra win over default).
      - Hiera-Large + compile + bf16: short-Tq (ws<=16) → cudnn, default else.
      - Eager: default dispatcher is fine — context-manager overhead per call
        scales with block count and often eats any backend gain.

    Returns None on Ada/4090 where cuDNN-attn is runtime-disabled.
    """
    if not compile_enabled:
        return None

    adapter = get_hiera_adapter(model)
    if adapter is None:
        return None

    BlockCls = adapter.block_class()
    n_blocks = sum(1 for _ in model.modules() if isinstance(_, BlockCls))

    if n_blocks <= 40:  # Hiera-Tiny/Small/Base territory
        def pick(idx, block):
            return "mem_efficient" if block.attn.use_mask_unit_attn else "cudnn"
        return pick
    else:  # Hiera-Large / Huge
        def pick(idx, block):
            return "cudnn" if (
                block.attn.use_mask_unit_attn and block.attn.window_size <= 16
            ) else None
        return pick


# ---------------------------------------------------------------------------
# Attention swap — generic over attention class
# ---------------------------------------------------------------------------

def swap_mask_unit_attention(
    model: nn.Module,
    sdpa_backend: BackendHint = None,
) -> int:
    """Public lower-level: walk the model and swap MaskUnitAttention only.

    No gather / forward patching, no auto-adapter resolution magic — the
    adapter is auto-found via `get_hiera_adapter`. For non-Hiera models or
    custom dispatch, call `_swap_attention(model, your_adapter, ...)` directly.
    """
    adapter = get_hiera_adapter(model)
    if adapter is None:
        raise TypeError(f"No adapter matched {type(model).__name__}")
    return _swap_attention(model, adapter, sdpa_backend=sdpa_backend)


def _swap_fused_mlp_block(model: nn.Module, adapter: HieraAdapter) -> int:
    """Replace LN2 + MLP + residual with FusedMlpBlock.

    Eligible: every HieraBlock has a norm2 + mlp + residual at the tail; we
    swap that step regardless of attention type. The fused MLP only wins at
    small input dims (K <= 96 on Ada). For larger K it falls back to ATen
    behind the same Function interface (still correct, just may not be faster).
    Caller decides whether to opt in via `fused_mlp=True`.
    """
    BlockCls = adapter.block_class()
    n = 0
    for block in model.modules():
        if not isinstance(block, BlockCls):
            continue
        if not hasattr(block, "norm2") or not hasattr(block, "mlp"):
            continue
        dim_out = block.norm2.weight.shape[0]
        hidden = block.mlp.fc1.weight.shape[0]
        fused = FusedMlpBlock(dim_out, hidden, eps=block.norm2.eps
                              ).to(block.norm2.weight.device).to(block.norm2.weight.dtype)
        fused.copy_from_hiera(block.norm2, block.mlp)
        block._fused_mlp = fused

        # Patch forward: replace the `x = x + drop_path(mlp(norm2(x)))` step.
        # The original attn / norm1 / residual path stays as-is (or as patched
        # by _swap_fused_attn_block earlier if both are enabled).
        orig_forward = block.forward
        def _patched(self, x, _orig=orig_forward):
            # Re-execute the attention step of the original forward, then run
            # our fused MLP. We do that by composing: original.forward minus
            # the MLP tail. Simpler: temporarily monkey-patch out the mlp tail.
            # Cleanest: just call the attn half explicitly.
            x_norm = self.norm1(x)
            if self.dim != self.dim_out:
                from models.hiera import do_pool  # FAIR helper for q_pool projection
                x = do_pool(self.proj(x_norm), stride=self.attn.q_stride)
            x = x + self.drop_path(self.attn(x_norm))
            x = self._fused_mlp(x)
            return x
        # If a fused-attn replaced this block's forward earlier, we need to
        # respect that — chain on top.
        if hasattr(block, "_fused_attn"):
            def _patched2(self, x):
                x = self._fused_attn(x, x)
                x = self._fused_mlp(x)
                return x
            block.forward = types.MethodType(_patched2, block)
        else:
            block.forward = types.MethodType(_patched, block)
        n += 1
    return n


def _swap_fused_attn_block(model: nn.Module, adapter: HieraAdapter) -> int:
    """Replace LN1 + MaskUnitAttention + residual with FusedMaskUnitAttention.

    Eligible blocks: dim == dim_out, q_stride == 1, use_mask_unit_attn == True.
    For non-eligible blocks the original LN1/attn path stays untouched.

    Patches `block.forward` so the fused module replaces three sub-steps in one
    call: `x_norm = norm1(x); x = x + attn(x_norm)`.
    """
    BlockCls = adapter.block_class()
    AttnCls = adapter.attention_class()
    n = 0
    for block in model.modules():
        if not isinstance(block, BlockCls):
            continue
        attn = block.attn
        if not isinstance(attn, AttnCls):
            continue
        if (attn.dim != attn.dim_out
                or attn.q_stride != 1
                or not attn.use_mask_unit_attn):
            continue

        fused = FusedMaskUnitAttention(
            dim=attn.dim, dim_out=attn.dim_out, heads=attn.heads,
            window_size=attn.window_size, q_stride=1,
            eps=block.norm1.eps,
        ).to(attn.qkv.weight.device).to(attn.qkv.weight.dtype)
        fused.copy_from_hiera(block.norm1, attn)

        # Stash references so the patched forward can call them.
        block._fused_attn = fused
        # Replace norm1+attn step. Keep norm2 + mlp as-is.
        def _patched_forward(self, x):
            x = self._fused_attn(x, x)
            x = x + self.drop_path(self.mlp(self.norm2(x)))
            return x
        block.forward = types.MethodType(_patched_forward, block)
        n += 1
    return n


def _swap_attention(
    model: nn.Module,
    adapter: HieraAdapter,
    sdpa_backend: BackendHint = None,
) -> int:
    """Walk the model, replace every adapter-recognised attention submodule
    with a MaskUnitAttentionFast copy that preserves weights.

    Returns the count of swapped modules.
    """
    BlockCls = adapter.block_class()
    AttnCls = adapter.attention_class()
    n = 0
    for module in model.modules():
        if not isinstance(module, BlockCls):
            continue
        orig = module.attn
        if not isinstance(orig, AttnCls):
            continue
        be = sdpa_backend(n, module) if callable(sdpa_backend) else sdpa_backend
        fast = MaskUnitAttentionFast(
            dim=orig.dim,
            dim_out=orig.dim_out,
            heads=orig.heads,
            q_stride=orig.q_stride,
            window_size=orig.window_size,
            use_mask_unit_attn=orig.use_mask_unit_attn,
            sdpa_backend=be,
        ).to(orig.qkv.weight.device).to(orig.qkv.weight.dtype)
        copy_weights_from_orig(fast, orig)
        module.attn = fast
        n += 1
    return n


# ---------------------------------------------------------------------------
# Patched forwards (Hiera-shape-aware, no FAIR imports)
# ---------------------------------------------------------------------------

def _get_random_mask_with_idx(model, x, mask_ratio):
    B = x.shape[0]
    num_mu = math.prod(model.mask_spatial_shape)
    L = int(num_mu * (1 - mask_ratio))
    noise = torch.rand(B, num_mu, device=x.device)
    ids_shuffle = torch.argsort(noise, dim=1)
    keep_positions = ids_shuffle[:, :L]
    mask = torch.zeros(B, num_mu, device=x.device, dtype=torch.bool)
    mask.scatter_(1, keep_positions, True)
    # Inline (avoids .item() graph break)
    pos = torch.arange(num_mu, device=x.device).expand(B, num_mu)
    sentinel = torch.full_like(pos, num_mu)
    masked_pos = torch.where(mask, pos, sentinel)
    sorted_pos, _ = masked_pos.sort(dim=1)
    keep_idx = sorted_pos[:, :L].contiguous()
    return mask, keep_idx


class MAEStepInputs:
    """Pre-allocated static buffers for a graph-safe MAE training step.

    Use this when wrapping a model under `torch.compile(mode="reduce-overhead")`
    so that captured CUDA Graphs see stable input tensor addresses across
    iterations. Refresh per step with `.refresh_mask()`; copy the raw input
    into `.x` via `.x.copy_(...)`.

    Example
    -------
        from hiera_optim import optimize, MAEStepInputs

        optimize(model, graph_safe=True)
        model = torch.compile(model, mode="reduce-overhead")
        inputs = MAEStepInputs(model, batch_size=B, in_chans=C,
                               input_size=(224, 224), mask_ratio=0.6,
                               device=device, dtype=torch.bfloat16)

        for batch in loader:
            inputs.x.copy_(batch)
            inputs.refresh_mask()
            out = model(inputs.x, mask_ratio=inputs.mask_ratio,
                        mask=inputs.mask, keep_idx=inputs.keep_idx)
            out[0].backward(); opt.step(); opt.zero_grad()
    """

    def __init__(self, model, batch_size: int, in_chans: int,
                 input_size: tuple[int, ...], mask_ratio: float,
                 device, dtype=torch.bfloat16,
                 generator: torch.Generator | None = None):
        self.model = model
        self.batch_size = batch_size
        self.mask_ratio = mask_ratio
        self.device = device
        self.dtype = dtype
        self.generator = generator

        # Static input buffer
        self.x = torch.empty(batch_size, in_chans, *input_size,
                             device=device, dtype=dtype)

        # Generate one mask to discover buffer shape, then store as static.
        mask, keep_idx = make_mae_mask(model, batch_size, mask_ratio,
                                       device, generator=generator)
        self.mask = mask.clone()
        self.keep_idx = keep_idx.clone()

    def refresh_mask(self) -> None:
        """Sample a fresh mask and copy into the static buffers."""
        new_mask, new_keep_idx = make_mae_mask(
            self.model, self.batch_size, self.mask_ratio,
            self.device, generator=self.generator,
        )
        self.mask.copy_(new_mask)
        self.keep_idx.copy_(new_keep_idx)


def make_mae_mask(model, batch_size: int, mask_ratio: float, device,
                  generator: torch.Generator | None = None):
    """Pre-generate the (mask, keep_idx) pair for one MAE step.

    Use this when training under `torch.compile(mode='reduce-overhead')` or
    CUDA Graph capture: the random generation runs outside the captured
    region, so the captured forward stays deterministic w.r.t. the inputs.

    Returns
    -------
    mask : (B, num_mu) bool — True = keep
    keep_idx : (B, L) int64 — sorted positions of the L kept mask units
    """
    num_mu = math.prod(model.mask_spatial_shape)
    L = int(num_mu * (1 - mask_ratio))
    noise = torch.rand(batch_size, num_mu, device=device, generator=generator)
    ids_shuffle = torch.argsort(noise, dim=1)
    keep_positions = ids_shuffle[:, :L]
    mask = torch.zeros(batch_size, num_mu, device=device, dtype=torch.bool)
    mask.scatter_(1, keep_positions, True)
    pos = torch.arange(num_mu, device=device).expand(batch_size, num_mu)
    sentinel = torch.full_like(pos, num_mu)
    masked_pos = torch.where(mask, pos, sentinel)
    sorted_pos, _ = masked_pos.sort(dim=1)
    keep_idx = sorted_pos[:, :L].contiguous()
    return mask, keep_idx


def _make_hiera_forward(adapter: HieraAdapter):
    def _hiera_forward(self, x, mask=None, keep_idx=None, return_intermediates=False):
        if isinstance(x, list):
            x = x[0]
        intermediates = []

        x = self.patch_embed(
            x,
            mask=mask.view(x.shape[0], 1, *self.mask_spatial_shape) if mask is not None else None,
        )
        x = x + self.get_pos_embed()
        x = self.unroll(x)

        if mask is not None and keep_idx is None:
            # Caller passed mask but not keep_idx — derive it (this hits .item()).
            keep_idx = keep_idx_from_bool_mask(mask)

        if mask is not None:
            x = gather_mu_groups(x, keep_idx, self.mu_size)

        for i, blk in enumerate(self.blocks):
            if self._grad_checkpointing and self.training:
                x = torch_checkpoint(blk, x, use_reentrant=False)
            else:
                x = blk(x)
            if return_intermediates and i in self.stage_ends:
                intermediates.append(self.reroll(x, i, mask=mask))

        if mask is None:
            x = x.mean(dim=1)
            x = self.norm(x)
            x = self.head(x)

        if return_intermediates:
            return x, intermediates
        return x
    return _hiera_forward


def _make_mae_forward_encoder(adapter: HieraAdapter):
    apply_fusion_head = adapter.apply_fusion_head
    hiera_fwd = _make_hiera_forward(adapter)

    def _mae_forward_encoder(self, x, mask_ratio, mask=None, keep_idx=None, return_intermediates=False):
        if mask is None:
            mask, keep_idx = _get_random_mask_with_idx(self, x, mask_ratio)
        # Run the Hiera forward up through the blocks
        _, intermediates = hiera_fwd(
            self, x, mask=mask, keep_idx=keep_idx, return_intermediates=True
        )
        intermediates = intermediates[: self.q_pool] + intermediates[-1:]
        x = 0.0
        for head, interm_x in zip(self.multi_scale_fusion_heads, intermediates):
            x = x + apply_fusion_head(head, interm_x)
        x = self.encoder_norm(x)
        if return_intermediates:
            return x, mask, tuple(intermediates)
        return x, mask
    return _mae_forward_encoder


def _make_mae_forward_decoder(adapter: HieraAdapter):
    undo_windowing = adapter.undo_windowing

    def _mae_forward_decoder(self, x, mask):
        x = self.decoder_embed(x)
        B = mask.shape[0]
        L = x.shape[1]
        MU = math.prod(self.mask_unit_spatial_shape_final)
        C = x.shape[-1]
        M = mask.shape[1]
        x_flat = x.reshape(B, L, MU, C)
        # `L` is already known statically (came from x.shape[1]); pass to avoid .item()
        keep_idx = keep_idx_from_bool_mask(mask, len_keep=L)
        full = scatter_decoder_tokens(x_flat, keep_idx, M, self.mask_token)
        full = full.view(B, M, *self.mask_unit_spatial_shape_final, C)
        x = undo_windowing(full, self.tokens_spatial_shape_final, self.mask_unit_spatial_shape_final)
        x = x.reshape(B, -1, C)

        pm = mask.view(B, M, 1).expand(B, M, MU).reshape(B, M, *self.mask_unit_spatial_shape_final)
        pm = undo_windowing(pm.unsqueeze(-1), self.tokens_spatial_shape_final, self.mask_unit_spatial_shape_final).squeeze(-1)
        pm = pm.view(B, -1)

        x = x + self.decoder_pos_embed
        for blk in self.decoder_blocks:
            x = blk(x)
        x = self.decoder_norm(x)
        x = self.decoder_pred(x)
        return x, pm
    return _mae_forward_decoder


# ---------------------------------------------------------------------------
# Graph-safe MAE: replace bool-indexing in loss + label paths
# ---------------------------------------------------------------------------
#
# FAIR's `MaskedAutoencoderHiera.forward_loss` / `get_pixel_label_*` call
# `pred[mask]` and `label[mask]`. Bool-indexing dispatches to `aten::nonzero`
# which produces a data-dependent shape — entirely forbidden inside CUDA
# Graphs and causes `torch.compile(mode="reduce-overhead")` to throw
# "illegal memory access" on replay.
#
# We replace the masked-mean with a mask-weighted mean over the *full*
# token grid. Algebra check (full == bool-indexed):
#   M = mask.sum()  (count of True tokens, scalar)
#   original: ((pred[mask] - label[mask])**2).mean()
#            = sum_{(b,n)∈True} ||pred[b,n]-label[b,n]||² / (M * C)
#   patched:  loss_per_token = ((pred - label)**2).mean(-1)   # (B, N)
#            = sum_c ||pred-label||² / C
#             mask_weighted = (loss_per_token * mask).sum() / mask.sum()
#            = sum_{(b,n)∈True} ||pred[b,n]-label[b,n]||² / (M * C)
# Equal up to numerical noise.

def _get_pixel_label_2d_full(self, input_img, norm=True):
    input_img = input_img.permute(0, 2, 3, 1)
    s = self.pred_stride
    label = input_img.unfold(1, s, s).unfold(2, s, s)
    label = label.flatten(1, 2).flatten(2)
    # NO label[mask] — full (B, num_patches, C*s*s) so the shape is static.
    if norm:
        mean = label.mean(dim=-1, keepdim=True)
        var = label.var(dim=-1, keepdim=True)
        label = (label - mean) / (var + 1.0e-6) ** 0.5
    return label


def _get_pixel_label_1d_full(self, input_sig, norm=True):
    s = self.pred_stride
    label = input_sig.unfold(2, s, s)        # (B, C, num_patches, size)
    label = label.permute(0, 2, 3, 1)        # (B, num_patches, size, C)
    label = label.flatten(2)                  # (B, num_patches, size*C)
    if norm:
        mean = label.mean(dim=-1, keepdim=True)
        var = label.var(dim=-1, keepdim=True)
        label = (label - mean) / (var + 1.0e-6) ** 0.5
    return label


def _get_pixel_label_3d_full(self, input_vid, norm=True):
    input_vid = input_vid[:, :, ::self.patch_stride[0], :, :]
    s = self.pred_stride
    label = input_vid.unfold(3, s, s).unfold(4, s, s)
    label = label.permute(0, 2, 3, 4, 5, 6, 1)
    label = label.flatten(1, 3).flatten(2)
    if norm:
        mean = label.mean(dim=-1, keepdim=True)
        var = label.var(dim=-1, keepdim=True)
        label = (label - mean) / (var + 1.0e-6) ** 0.5
    return label


def _mae_forward_loss_graph_safe(self, x, pred, mask):
    """Graph-safe replacement for `MaskedAutoencoderHiera.forward_loss`.

    No boolean indexing — instead, compute squared error per token over the
    full grid and average with a mask weight. Same result up to bf16 noise.

    Args
    ----
    x : (B, C, ...) raw input (image / 1d signal / video)
    pred : (B, num_patches, C*s*s) decoder output over the full grid
    mask : (B, num_patches) bool, True where loss should apply
    """
    if len(self.q_stride) == 1:
        label = _get_pixel_label_1d_full(self, x)
    elif len(self.q_stride) == 2:
        label = _get_pixel_label_2d_full(self, x)
    elif len(self.q_stride) == 3:
        label = _get_pixel_label_3d_full(self, x)
    else:
        raise NotImplementedError

    # `pred` and `label` are both (B, num_patches, F). Match shapes; pred may
    # be in lower precision under autocast.
    diff = pred.to(label.dtype) - label
    loss_per_token = (diff * diff).mean(dim=-1)             # (B, num_patches)
    mask_f = mask.to(loss_per_token.dtype)
    denom = mask_f.sum().clamp_min(1.0)
    loss = (loss_per_token * mask_f).sum() / denom

    # Match FAIR's return signature (loss, pred, label). The `pred`/`label`
    # we return here are the FULL (un-indexed) tensors; the training loop
    # typically only uses `loss`. Downstream code that consumes pred/label
    # in the old (M, F) shape will need to mask externally if it cares.
    return loss, pred, label


def _enable_graph_safe(model: nn.Module, verbose: bool = True) -> int:
    """Replace forward_loss + get_pixel_label_* on a Hiera-MAE model with
    graph-safe variants (no bool indexing). Returns 1 if applied, 0 if the
    model has no MAE methods.
    """
    if not hasattr(model, "forward_loss") or not hasattr(model, "get_pixel_label_2d"):
        return 0
    model.forward_loss = types.MethodType(_mae_forward_loss_graph_safe, model)
    model.get_pixel_label_1d = types.MethodType(_get_pixel_label_1d_full, model)
    model.get_pixel_label_2d = types.MethodType(_get_pixel_label_2d_full, model)
    model.get_pixel_label_3d = types.MethodType(_get_pixel_label_3d_full, model)
    if verbose:
        print(f"  [hiera_optim] graph-safe MAE loss + labels patched")
    return 1


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def optimize(
    model: nn.Module,
    *,
    swap_attention: bool = True,
    swap_gather: bool = True,
    fused_block: bool = False,
    fused_mlp: bool = False,
    graph_safe: bool = False,
    sdpa_backend: BackendHint = None,
    verbose: bool = True,
) -> nn.Module:
    """In-place optimisation of a Hiera-family model.

    Args:
        model: a built Hiera / MaskedAutoencoderHiera (FAIR or compatible).
        swap_attention: replace MaskUnitAttention with the 4-D / flash-friendly
            variant. Preserves weights. Default True.
        swap_gather: replace boolean mask-indexing in `forward_encoder` and
            decoder scatter with explicit-index gather/scatter (faster, no
            torch.compile graph break). Default True. No-op for non-MAE.
        sdpa_backend:
            None (default) → let PyTorch dispatcher pick.
            "auto" → use `recommended_backend(model)`.
            "cudnn" / "flash" / "mem_efficient" / "math" → pin all blocks.
            callable (idx, block) -> Optional[str] → per-block.
        verbose: log what was patched. Default True.

    Returns the same model object. Idempotent: re-applying does nothing
    surprising (existing fast-attn modules are skipped by isinstance check).
    """
    adapter = get_hiera_adapter(model)
    if adapter is None:
        raise TypeError(
            f"No adapter matched {type(model).__name__}. Bundled adapter is for "
            "FAIR Hiera; bring your own ModelAdapter for other architectures."
        )

    if sdpa_backend == "auto":
        sdpa_backend = recommended_backend(model, compile_enabled=True)

    # Hopper's cuDNN-attention backend is NOT CUDA Graph safe (illegal mem
    # access on reduce-overhead replay). Force a graph-safe backend when
    # graph_safe is requested and no explicit backend was given.
    if graph_safe and sdpa_backend is None:
        try:
            cap = torch.cuda.get_device_capability()
            if cap and cap[0] >= 9:  # Hopper or newer
                sdpa_backend = "mem_efficient"
                if verbose:
                    print("  [hiera_optim] graph_safe on Hopper: pinning sdpa_backend='mem_efficient'")
        except Exception:
            pass

    if fused_block:
        # Fused block first (replaces LN1+attn entirely for eligible blocks),
        # then layout-fast for the remaining (non-eligible) attention modules.
        n_fused = _swap_fused_attn_block(model, adapter)
        n_layout = _swap_attention(model, adapter, sdpa_backend=sdpa_backend)
        if verbose:
            print(f"  [hiera_optim] {n_fused} fused blocks + {n_layout} layout-fast attns")
    elif fused_mlp:
        # Apply layout-fast attn for all blocks first.
        n_layout = _swap_attention(model, adapter, sdpa_backend=sdpa_backend)
        n_mlp = _swap_fused_mlp_block(model, adapter)
        if verbose:
            print(f"  [hiera_optim] {n_layout} layout-fast attns + {n_mlp} fused MLP blocks")
    elif swap_attention:
        n = _swap_attention(model, adapter, sdpa_backend=sdpa_backend)
        if verbose:
            tag = ""
            if sdpa_backend is not None:
                tag = f" backend={'callable' if callable(sdpa_backend) else sdpa_backend!r}"
            print(f"  [hiera_optim] swapped {n} attention modules{tag}")

    if swap_gather:
        # Always patch Hiera.forward
        model.forward = types.MethodType(_make_hiera_forward(adapter), model)  # type: ignore[assignment]
        if adapter.is_mae(model):
            model.forward_encoder = types.MethodType(_make_mae_forward_encoder(adapter), model)
            model.forward_decoder = types.MethodType(_make_mae_forward_decoder(adapter), model)
            # Top-level MAE forward stays as FAIR's (calls forward_encoder/decoder).
            # We need to restore it because we overwrote model.forward above; for
            # MAE the high-level forward expects (x, mask_ratio, mask).
            model.forward = types.MethodType(_mae_forward_full, model)
        if verbose:
            kind = "MAE encoder+decoder" if adapter.is_mae(model) else "encoder"
            print(f"  [hiera_optim] swapped masked gather/scatter ({kind})")

    if graph_safe and adapter.is_mae(model):
        # Replace the bool-indexing in forward_loss + get_pixel_label_* with
        # mask-weighted-mean reductions. Required for torch.compile(mode=
        # "reduce-overhead") / CUDA Graph capture to not fault on replay.
        _enable_graph_safe(model, verbose=verbose)

    return model


def _mae_forward_full(self, x, mask_ratio=0.6, mask=None, keep_idx=None):
    """Replacement for MaskedAutoencoderHiera.forward.

    Accepts pre-generated `mask` and `keep_idx` for graph-safe training.
    See `make_mae_mask(...)`. When both are None (default), the encoder
    generates them internally (graph-unsafe path).
    """
    latent, mask = self.forward_encoder(x, mask_ratio, mask=mask, keep_idx=keep_idx)
    pred, pred_mask = self.forward_decoder(latent, mask)
    return *self.forward_loss(x, pred, ~pred_mask), mask


__all__ = [
    "optimize",
    "swap_mask_unit_attention",
    "recommended_backend",
    "make_mae_mask",
    "BACKEND_NAMES",
]
