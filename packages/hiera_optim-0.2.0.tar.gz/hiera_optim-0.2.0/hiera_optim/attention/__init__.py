"""Attention modules. Currently exports MaskUnitAttentionFast — the
FlashAttention/cuDNN-friendly 4-D variant of FAIR's MaskUnitAttention.
"""
from .mask_unit import MaskUnitAttentionFast, copy_weights_from_orig, BACKEND_NAMES

__all__ = ["MaskUnitAttentionFast", "copy_weights_from_orig", "BACKEND_NAMES"]
