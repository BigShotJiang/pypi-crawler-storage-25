"""End-to-end fused MaskUnitAttention block (LN1 + QKV + flash + proj + residual).

Forward path:
  1. `fused_qkv_preamble`  (Triton) → LN(x), QKV linear, direct write to 4-D layout.
  2. Optional Q max-pool for q_pool blocks (fast ATen `.amax`).
  3. `F.scaled_dot_product_attention` (PyTorch flash attention).
  4. `fused_proj_epilogue`  (Triton) → reshape + proj linear + residual add.

This collapses the original 6-step ATen path to 4 launches. Eliminates two
contiguous() memcpies (the 5D→4D reshape pre-flash, the 4D→5D reshape post-flash).

Backward currently uses autograd via a forward replay (ATen). A custom bwd
kernel is a follow-up.

Limits:
  - `q_stride=1` only (the q-pool case takes a different code path — fall back
    to the unfused 4-D-SDPA module in patch.py).
  - `use_mask_unit_attn=True` (windowed attention). For global attention
    (`use_mask_unit_attn=False`) the layout trick doesn't apply; fall back.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from hiera_optim.kernels.fused_qkv_preamble import fused_qkv_preamble
from hiera_optim.kernels.fused_proj_epilogue import fused_proj_epilogue
from hiera_optim.kernels.fused_qkv_preamble_bwd import inv_qkv_preamble
from hiera_optim.kernels.fused_proj_epilogue_bwd import inv_proj_epilogue
from hiera_optim.kernels.pack_qkv_grad import pack_qkv_grad
from hiera_optim.kernels.pack_z import pack_z


class _FusedMaskUnitAttention(torch.autograd.Function):
    @staticmethod
    def forward(ctx,
                x,                       # (B, N, dim)
                x_residual,              # (B, N, dim_out) — usually = x
                ln_w, ln_b,
                qkv_w, qkv_b,
                proj_w, proj_b,
                heads, nw, eps):
        # 1. Preamble (LN + QKV + 4D layout). y_ln is saved for bwd weight grad.
        q, k, v, mean, rstd, y_ln = fused_qkv_preamble(
            x, ln_w, ln_b, qkv_w, qkv_b, heads, nw, eps,
        )
        # 2. Flash attention — direct op so we can save lse + rng_state for bwd
        z, lse, cum_q, cum_k, max_q, max_k, rng_state, _, _ = (
            torch.ops.aten._scaled_dot_product_flash_attention(
                q, k, v, 0.0, False, False
            )
        )
        # 3. Epilogue (proj + residual)
        out = fused_proj_epilogue(z, proj_w, proj_b, x_residual, nw)

        # Save intermediates so bwd doesn't re-do the fwd.
        ctx.save_for_backward(x, ln_w, ln_b, qkv_w, proj_w, mean, rstd,
                               q, k, v, z, y_ln, lse, rng_state)
        ctx.cum_q = cum_q; ctx.cum_k = cum_k
        ctx.max_q = max_q; ctx.max_k = max_k
        ctx.heads = heads
        ctx.nw = nw
        ctx.eps = eps
        return out

    @staticmethod
    def backward(ctx, grad_out):
        (x, ln_w, ln_b, qkv_w, proj_w, mean, rstd,
         q, k, v, z, y_ln, lse, rng_state) = ctx.saved_tensors
        heads, nw, eps = ctx.heads, ctx.nw, ctx.eps
        B, N, dim = x.shape
        dim_out   = qkv_w.shape[0] // 3
        head_dim  = dim_out // heads
        T         = N // nw

        # ---- Residual + proj bwd ----
        # out = x_residual + (z_packed @ proj_w^T + proj_b)
        # The residual path uses fused inverse: grad_z_4d (in flash layout)
        # is built directly without materialising the inverse-permute.
        grad_x_residual = grad_out
        grad_proj_b = grad_out.reshape(-1, dim_out).sum(0)
        # Fused inverse: grad_out @ proj_w + 4D reshape in one launch.
        grad_z_4d = inv_proj_epilogue(grad_out, proj_w, nw, heads, head_dim, T)

        # Weight grad needs z packed (B, N, dim_out). Triton pack ~2x faster than ATen permute+contig.
        z_packed = pack_z(z, nw)
        grad_proj_w = grad_out.reshape(-1, dim_out).t() @ z_packed.reshape(-1, dim_out)

        # ---- Flash attention bwd ---- direct aten op; uses saved lse/rng.
        # Skips a redundant SDPA fwd that torch.autograd.grad would do.
        grad_q, grad_k, grad_v = torch.ops.aten._scaled_dot_product_flash_attention_backward(
            grad_z_4d, q, k, v, z, lse,
            ctx.cum_q, ctx.cum_k, ctx.max_q, ctx.max_k,
            0.0, False, rng_state, torch.tensor(0, device=z.device),
        )

        # ---- QKV-preamble bwd ----
        # Fused inverse: grad_y_ln = (inverse-permute of stacked grads) @ qkv_w.
        grad_y_ln = inv_qkv_preamble(grad_q, grad_k, grad_v, qkv_w, nw)

        # Weight & bias grads: Triton pack ~2x faster than ATen stack+permute+contig.
        grad_qkv = pack_qkv_grad(grad_q, grad_k, grad_v, nw)
        grad_qkv_b = grad_qkv.reshape(-1, 3 * dim_out).sum(0)
        grad_qkv_w = grad_qkv.reshape(-1, 3 * dim_out).t() @ y_ln.reshape(-1, dim)

        # ---- LN bwd via native fused op ----
        # PyTorch's native_layer_norm_backward is a single CUDA kernel; using
        # the saved mean/rstd avoids any LN forward recompute.
        grad_x, grad_ln_w, grad_ln_b = torch.ops.aten.native_layer_norm_backward(
            grad_y_ln, x, [dim],
            mean.view(B, N, 1), rstd.view(B, N, 1),
            ln_w, ln_b,
            [True, True, True],
        )

        return (grad_x, grad_x_residual,
                grad_ln_w, grad_ln_b,
                grad_qkv_w, grad_qkv_b,
                grad_proj_w, grad_proj_b,
                None, None, None)


class FusedMaskUnitAttention(nn.Module):
    """Replacement for MaskUnitAttention + the surrounding LN1 + residual.

    Unlike `MaskUnitAttentionFast`, this module fuses the LN, QKV, attention,
    proj and residual into 4 kernel launches (Triton + flash + Triton).

    Signature matches the FAIR module's interface but expects the residual
    stream explicitly: call as `out = block(x_after_proj_path, x_residual)`.
    For Hiera blocks where `dim == dim_out` and `q_stride == 1`, the typical
    call is `block(x, x)`.
    """

    def __init__(self, dim: int, dim_out: int, heads: int, window_size: int,
                 q_stride: int = 1, eps: float = 1e-6):
        super().__init__()
        assert dim == dim_out, (
            "FusedMaskUnitAttention requires dim == dim_out (no q_pool transition); "
            f"got dim={dim}, dim_out={dim_out}. Use MaskUnitAttentionFast for q_pool blocks."
        )
        assert q_stride == 1, (
            "FusedMaskUnitAttention requires q_stride == 1 (no q-pool). "
            f"Got q_stride={q_stride}. Use MaskUnitAttentionFast for q_pool blocks."
        )
        self.dim = dim
        self.dim_out = dim_out
        self.heads = heads
        self.head_dim = dim_out // heads
        self.window_size = window_size
        self.q_stride = q_stride
        self.eps = eps

        self.ln_weight = nn.Parameter(torch.ones(dim))
        self.ln_bias   = nn.Parameter(torch.zeros(dim))
        self.qkv_weight = nn.Parameter(torch.empty(3 * dim_out, dim))
        self.qkv_bias   = nn.Parameter(torch.zeros(3 * dim_out))
        self.proj_weight = nn.Parameter(torch.empty(dim_out, dim_out))
        self.proj_bias   = nn.Parameter(torch.zeros(dim_out))
        nn.init.xavier_uniform_(self.qkv_weight)
        nn.init.xavier_uniform_(self.proj_weight)

    def forward(self, x: torch.Tensor, x_residual: torch.Tensor | None = None) -> torch.Tensor:
        if x_residual is None:
            x_residual = x
        B, N, _ = x.shape
        nw = N // self.window_size
        return _FusedMaskUnitAttention.apply(
            x, x_residual,
            self.ln_weight, self.ln_bias,
            self.qkv_weight, self.qkv_bias,
            self.proj_weight, self.proj_bias,
            self.heads, nw, self.eps,
        )

    @torch.no_grad()
    def copy_from_hiera(self, norm1_module, attn_module):
        """Copy weights from a FAIR HieraBlock's (norm1, attn) pair."""
        self.ln_weight.copy_(norm1_module.weight)
        self.ln_bias.copy_(norm1_module.bias)
        self.qkv_weight.copy_(attn_module.qkv.weight)
        self.qkv_bias.copy_(attn_module.qkv.bias)
        self.proj_weight.copy_(attn_module.proj.weight)
        self.proj_bias.copy_(attn_module.proj.bias)
