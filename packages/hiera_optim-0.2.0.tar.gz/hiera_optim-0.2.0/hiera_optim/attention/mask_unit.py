"""Optimized MaskUnitAttention — drop-in replacement.

Key fixes vs FAIR original (models/hiera.py):
  - Reshape Q/K/V to 4D (B*num_windows, heads, T, D) so SDPA dispatches to
    FlashAttention (cuDNN/Flash). Original feeds 5D tensors which fall back
    to the math backend (12-13x slower on stage-0 shapes per microbench).
  - Match FAIR's N-axis layout exactly: token n in input has n = t*nw + w,
    so within-window positions are SLOW-varying and num_windows is FAST.
    That's because the upstream Unroll module produces this interleaved
    layout (and do_pool relies on the stride axis being outer).
  - Skip per-tensor .contiguous() — the permute lands flash-friendly.
  - Optional per-stage SDPA backend hint via `sdpa_backend` attribute. Set to
    one of {"cudnn", "flash", "mem_efficient", "math", None}; None lets the
    PyTorch dispatcher pick. Per-stage tuning is useful because Hiera's small
    Tq stages (stage-1 post q_pool: T=16) often favor mem-efficient while the
    long-seq global-attention stages favor cuDNN-attn or flash on Hopper.

Numerically identical to FAIR baseline up to bf16 noise (~1e-2 max abs diff,
~1e-3 rel RMS) — the noise is the difference between SDPA math vs flash.
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.attention import SDPBackend, sdpa_kernel


_BACKEND_MAP = {
    "cudnn": SDPBackend.CUDNN_ATTENTION,
    "flash": SDPBackend.FLASH_ATTENTION,
    "mem_efficient": SDPBackend.EFFICIENT_ATTENTION,
    "math": SDPBackend.MATH,
}

BACKEND_NAMES = tuple(_BACKEND_MAP.keys())


class MaskUnitAttentionFast(nn.Module):
    """Drop-in replacement for models.hiera.MaskUnitAttention with 4D SDPA.

    Args:
        sdpa_backend: optional SDPA backend hint. One of {"cudnn", "flash",
            "mem_efficient", "math", None}. None = default dispatcher.
    """

    def __init__(
        self,
        dim: int,
        dim_out: int,
        heads: int,
        q_stride: int = 1,
        window_size: int = 0,
        use_mask_unit_attn: bool = False,
        sdpa_backend: Optional[str] = None,
    ):
        super().__init__()
        self.dim = dim
        self.dim_out = dim_out
        self.heads = heads
        self.q_stride = q_stride
        self.head_dim = dim_out // heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Linear(dim, 3 * dim_out)
        self.proj = nn.Linear(dim_out, dim_out)
        self.window_size = window_size
        self.use_mask_unit_attn = use_mask_unit_attn
        if sdpa_backend is not None and sdpa_backend not in _BACKEND_MAP:
            raise ValueError(f"sdpa_backend must be one of {list(_BACKEND_MAP)} or None; got {sdpa_backend!r}")
        self.sdpa_backend = sdpa_backend

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, _ = x.shape
        H, D = self.heads, self.head_dim
        nw = (N // (self.q_stride * self.window_size)) if self.use_mask_unit_attn else 1
        T = N // nw  # tokens per window before q-pool

        # qkv: (B, N, 3*dim_out)
        # FAIR layout: N is interpreted as (T, nw) with nw fast-varying.
        # We want (3, B*nw, H, T, D) so SDPA gets a 4D Q/K/V.
        qkv = self.qkv(x).view(B, T, nw, 3, H, D)
        # permute -> (3, B, nw, H, T, D), then flatten (B, nw) into batch
        qkv = qkv.permute(3, 0, 2, 4, 1, 5).reshape(3, B * nw, H, T, D)
        q, k, v = qkv[0], qkv[1], qkv[2]

        if self.q_stride > 1:
            # Max-pool Q over the q_stride flat axis. T = q_stride * Tq.
            # FAIR's do_pool: view(B, stride, -1, C).max(dim=1) — stride is OUTER.
            # So inside T, q_stride is slow-varying. Mirror: view (.., q_stride, Tq, ..)
            Tq = T // self.q_stride
            q = q.view(B * nw, H, self.q_stride, Tq, D).amax(dim=2)

        # 4D SDPA → FlashAttention/cuDNN. Optionally pin a backend.
        if self.sdpa_backend is None:
            out = F.scaled_dot_product_attention(q, k, v)
        else:
            with sdpa_kernel([_BACKEND_MAP[self.sdpa_backend]]):
                out = F.scaled_dot_product_attention(q, k, v)
        # out: (B*nw, H, Tq, D)
        Tq_out = out.shape[2]

        # Back to (B, N_out, dim_out) with N_out indexed as (tq, w) tq slow / w fast
        # out: (B*nw, H, Tq, D) -> (B, nw, H, Tq, D) -> (B, Tq, nw, H, D) -> reshape
        out = out.view(B, nw, H, Tq_out, D).permute(0, 3, 1, 2, 4).reshape(B, Tq_out * nw, self.dim_out)
        return self.proj(out)


@torch.no_grad()
def copy_weights_from_orig(fast: MaskUnitAttentionFast, orig) -> None:
    """Copy parameters from FAIR's MaskUnitAttention into a fast one."""
    fast.qkv.weight.copy_(orig.qkv.weight)
    fast.qkv.bias.copy_(orig.qkv.bias)
    fast.proj.weight.copy_(orig.proj.weight)
    fast.proj.bias.copy_(orig.proj.bias)
