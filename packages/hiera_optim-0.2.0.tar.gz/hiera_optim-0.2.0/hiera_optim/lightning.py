"""Lightning callback for graph-safe MAE training.

`MAEStaticInputsCallback` owns the `MAEStepInputs` lifecycle: it allocates
the static (x, mask, keep_idx) buffers once at fit start, refreshes the
mask before each batch, and copies the real batch into the static buffer
so the captured CUDA Graph sees stable input addresses every step.

The user's `training_step` just calls `inputs.copy_from(batch)` once and
then uses `inputs.x`, `inputs.mask`, `inputs.keep_idx` instead of the
raw batch.

Example
-------
    from lightning.pytorch import Trainer
    from lightning.pytorch.strategies import DDPStrategy
    from hiera_optim import optimize
    from hiera_optim.lightning import MAEStaticInputsCallback

    optimize(self.model, graph_safe=True)
    self.model = torch.compile(self.model, mode="reduce-overhead", dynamic=False)

    cb = MAEStaticInputsCallback(
        batch_size=BATCH, in_chans=8, input_size=(224, 224),
        mask_ratio=0.6, dtype=torch.bfloat16,
        batch_key="eeg_raw",
    )
    trainer = Trainer(
        callbacks=[cb],
        strategy=DDPStrategy(static_graph=True),
        precision="bf16-mixed",
        ...
    )

    # In your LightningModule.training_step:
    def training_step(self, batch, batch_idx):
        inputs = self._mae_inputs                    # attached by callback
        inputs.copy_from(batch[self._batch_key])     # copy into static buf + refresh mask
        out = self.model(inputs.x, mask_ratio=self.mask_ratio,
                         mask=inputs.mask, keep_idx=inputs.keep_idx)
        loss = out[0]
        self.manual_backward(loss)
        ...
"""
from __future__ import annotations
import math
from typing import Optional, Union

import torch

try:
    import lightning.pytorch as pl  # Lightning 2.x
except ImportError:
    pl = None  # type: ignore


from .patch import MAEStepInputs, make_mae_mask


class MAEStaticInputsCallback(pl.Callback if pl is not None else object):  # type: ignore[misc]
    """Lightning Callback that maintains static buffers for graph-safe MAE.

    Attaches `pl_module._mae_inputs` (an `MAEStepInputs`) on fit start, and
    refreshes the mask before every train batch. The training_step reads
    from this attribute.

    Parameters
    ----------
    batch_size : int
        Per-GPU batch size. Must match `Trainer(devices=...)` + dataloader.
    in_chans : int
        Input channel count.
    input_size : tuple of int
        Spatial input size, e.g. (224, 224) for image MAE or (7500,) for 1D EEG.
    mask_ratio : float
        MAE mask ratio (proportion of mask units dropped).
    dtype : torch.dtype
        Activation dtype (typically torch.bfloat16).
    batch_key : str, optional
        If the dataloader emits a dict, the key to pull the input tensor from.
        If None, the batch itself is treated as the input tensor.
    refresh_mask_every_step : bool
        If True (default), `inputs.refresh_mask()` is called per batch. Set
        False if you want one fixed mask for the whole run (for debugging or
        cache-warm benchmarks).
    """

    def __init__(
        self,
        batch_size: int,
        in_chans: int,
        input_size: tuple,
        mask_ratio: float,
        dtype: torch.dtype = torch.bfloat16,
        batch_key: Optional[str] = None,
        refresh_mask_every_step: bool = True,
    ):
        if pl is None:
            raise ImportError("lightning.pytorch is required for MAEStaticInputsCallback")
        super().__init__()
        self.batch_size = batch_size
        self.in_chans = in_chans
        self.input_size = tuple(input_size)
        self.mask_ratio = mask_ratio
        self.dtype = dtype
        self.batch_key = batch_key
        self.refresh_mask_every_step = refresh_mask_every_step
        self.inputs: Optional[MAEStepInputs] = None

    def setup(self, trainer, pl_module, stage: str) -> None:
        if stage != "fit":
            return
        device = pl_module.device
        # The inner model has `mask_spatial_shape`. Unwrap compile if needed.
        inner = pl_module.model if hasattr(pl_module, "model") else pl_module
        while hasattr(inner, "_orig_mod"):
            inner = inner._orig_mod
        # If DDP-wrapped, unwrap
        while hasattr(inner, "module"):
            inner = inner.module

        self.inputs = MAEStepInputs(
            inner,
            batch_size=self.batch_size,
            in_chans=self.in_chans,
            input_size=self.input_size,
            mask_ratio=self.mask_ratio,
            device=device,
            dtype=self.dtype,
        )
        pl_module._mae_inputs = self.inputs
        pl_module._batch_key = self.batch_key  # for use in training_step
        if trainer.is_global_zero:
            print(f"  [hiera_optim.lightning] MAEStaticInputsCallback ready: "
                  f"B={self.batch_size} in_chans={self.in_chans} "
                  f"size={self.input_size} mask_ratio={self.mask_ratio}", flush=True)

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx) -> None:
        if not self.refresh_mask_every_step:
            return
        # Refresh mask (also covers keep_idx). The actual `x` copy is up to the
        # user's training_step (we don't know the batch schema in general).
        self.inputs.refresh_mask()


def feed_batch(inputs: MAEStepInputs, batch, batch_key: Optional[str] = None):
    """Copy `batch` into `inputs.x` and refresh the mask.

    Helper for the training_step. Accepts either a tensor or a dict (with
    `batch_key` selecting the input).
    """
    if isinstance(batch, dict):
        x = batch[batch_key] if batch_key is not None else batch[next(iter(batch))]
    elif isinstance(batch, (list, tuple)):
        x = batch[0]
    else:
        x = batch
    inputs.x.copy_(x.to(inputs.x.dtype, non_blocking=True))
    inputs.refresh_mask()


__all__ = ["MAEStaticInputsCallback", "feed_batch"]
