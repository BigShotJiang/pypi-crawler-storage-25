"""Adapter for FAIR Hiera (https://github.com/facebookresearch/hiera).

This is the ONE module in `hiera_optim` allowed to import FAIR classes by name.
Everything else works through this adapter's protocol so the package is
trivially portable to derivative architectures.

The adapter resolves at import time and degrades gracefully if FAIR Hiera
isn't installed — `get_hiera_adapter(model)` returns None instead of crashing.
"""
from __future__ import annotations
import importlib
from dataclasses import dataclass
from typing import Any, Optional, Type

import torch
import torch.nn as nn


@dataclass(frozen=True)
class _HieraSymbols:
    """Resolved references to the FAIR Hiera classes we touch."""
    Hiera: Type[nn.Module]
    MaskedAutoencoderHiera: Type[nn.Module]
    HieraBlock: Type[nn.Module]
    MaskUnitAttention: Type[nn.Module]
    apply_fusion_head: callable
    undo_windowing: callable


def _resolve() -> Optional[_HieraSymbols]:
    """Try a few import paths. Returns None if Hiera isn't available."""
    candidates = [
        # In-tree (brain_atlas, the development environment)
        ("models.hiera", "utils.hiera_utils"),
        # PyPI package (`pip install hiera-transformer`)
        ("hiera.hiera", "hiera.hiera_utils"),
        ("hiera", "hiera.hiera_utils"),
    ]
    for hmod, hutil in candidates:
        try:
            hm = importlib.import_module(hmod)
            hu = importlib.import_module(hutil)
            return _HieraSymbols(
                Hiera=hm.Hiera,
                MaskedAutoencoderHiera=hm.MaskedAutoencoderHiera,
                HieraBlock=hm.HieraBlock,
                MaskUnitAttention=hm.MaskUnitAttention,
                apply_fusion_head=hm.apply_fusion_head,
                undo_windowing=hu.undo_windowing,
            )
        except (ImportError, AttributeError):
            continue
    return None


_SYMS = _resolve()


def is_available() -> bool:
    return _SYMS is not None


def symbols() -> _HieraSymbols:
    """Return resolved FAIR symbols. Raises if Hiera isn't installed."""
    if _SYMS is None:
        raise ImportError(
            "FAIR Hiera not installed. Add `pip install hiera-transformer`, "
            "or ensure `models.hiera` is importable in this project."
        )
    return _SYMS


class HieraAdapter:
    """Describes how to introspect / patch a FAIR Hiera model.

    The adapter is the bridge between FAIR's class hierarchy and our
    framework-agnostic patching code. Methods are pure introspection — they
    do not import FAIR classes unless explicitly needed.
    """

    def __init__(self):
        if not is_available():
            raise ImportError(
                "HieraAdapter requires FAIR Hiera to be importable."
            )
        self._syms = symbols()

    # ---- Introspection -----------------------------------------------------

    def matches(self, model: nn.Module) -> bool:
        """True if `model` is a Hiera-family model."""
        return isinstance(model, (self._syms.Hiera, self._syms.MaskedAutoencoderHiera))

    def is_mae(self, model: nn.Module) -> bool:
        return isinstance(model, self._syms.MaskedAutoencoderHiera)

    def block_class(self) -> Type[nn.Module]:
        return self._syms.HieraBlock

    def attention_class(self) -> Type[nn.Module]:
        return self._syms.MaskUnitAttention

    def encoder_blocks(self, model: nn.Module) -> nn.ModuleList:
        """Returns the encoder block list (`model.blocks`)."""
        return model.blocks

    def decoder_blocks(self, model: nn.Module) -> Optional[nn.ModuleList]:
        """Returns the MAE decoder block list, or None for non-MAE models."""
        return getattr(model, "decoder_blocks", None)

    def stage_ends(self, model: nn.Module) -> list[int]:
        return list(model.stage_ends)

    # ---- Layout convention ------------------------------------------------
    #
    # FAIR's `Unroll` produces a (T outer, nw inner) token layout: token n in
    # the N axis maps to (t = n // nw, w = n % nw). This is what FAIR's
    # `do_pool(x, stride)` (which expects stride as the OUTER dim) and the
    # MaskUnitAttention reshape pattern both rely on.
    layout = "T_outer_nw_inner"

    # ---- Helpers used by the patched forwards -----------------------------

    def apply_fusion_head(self, head: nn.Module, x: torch.Tensor) -> torch.Tensor:
        return self._syms.apply_fusion_head(head, x)

    def undo_windowing(self, x, shape, mu_shape):
        return self._syms.undo_windowing(x, shape, mu_shape)


# Module-level singleton resolution (cheap; just an isinstance check)
_DEFAULT_ADAPTER: Optional[HieraAdapter] = None


def get_hiera_adapter(model: nn.Module) -> Optional[HieraAdapter]:
    """Return a HieraAdapter if the model is a Hiera-family model, else None."""
    global _DEFAULT_ADAPTER
    if not is_available():
        return None
    if _DEFAULT_ADAPTER is None:
        _DEFAULT_ADAPTER = HieraAdapter()
    return _DEFAULT_ADAPTER if _DEFAULT_ADAPTER.matches(model) else None
