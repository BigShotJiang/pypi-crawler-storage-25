"""Model adapters.

The rest of the package is intentionally model-name-free: it operates on
PyTorch `nn.Module` graphs and looks up attention/block classes through
adapters. Each adapter teaches `optimize()` how to find the right submodules
on a specific model family.

Currently bundled:
  - hiera: FAIR's Hiera / MaskedAutoencoderHiera (https://github.com/facebookresearch/hiera)

Other adapters (Swin, MViTv2, JEPA-Hiera, custom architectures) can plug in by
implementing the same `ModelAdapter` protocol.
"""
from __future__ import annotations
from typing import Optional
from .hiera import HieraAdapter, get_hiera_adapter

__all__ = ["HieraAdapter", "get_hiera_adapter", "auto_detect"]


def auto_detect(model) -> Optional["ModelAdapter"]:  # type: ignore[name-defined]
    """Best-effort: return the right adapter for a given model. Returns None
    if no bundled adapter matches.
    """
    a = get_hiera_adapter(model)
    if a is not None:
        return a
    return None
