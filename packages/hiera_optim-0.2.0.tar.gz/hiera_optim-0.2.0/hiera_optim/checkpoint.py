"""Selective gradient checkpointing for Hiera.

Wraps specific blocks (default: stage-2) with `torch.utils.checkpoint` so that
their activations are *not* stored during forward but recomputed on backward.
Costs ~33% extra compute on the checkpointed blocks; saves ~50% of activation
memory total in Hiera-Base (stage-2 holds 16 of 24 enc blocks).

Use case: fit larger per-GPU batch → climb out of launch-overhead regime →
higher MFU. Especially useful when going from B=128 → B=256 per GPU on H100.

Compatible with `torch.compile(mode="default")`. Use `use_reentrant=False`
(the modern checkpoint variant) to avoid known autograd issues with reentrant
checkpointing + compile.
"""
from __future__ import annotations
from typing import Iterable, Optional, Union

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint


class _CheckpointedBlock(nn.Module):
    """Wraps a block so its forward goes through `torch.utils.checkpoint`.

    Keeps a reference to the original block (for weight loading / state_dict
    compatibility) and forwards all attribute access to it. Works for any
    single-input single-output `nn.Module` whose forward is a function of
    its parameters and the input — typical for transformer blocks.
    """
    def __init__(self, block: HieraBlock):
        super().__init__()
        self.block = block

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return checkpoint(self.block, x, use_reentrant=False)

    # Pass-through for `.attn`, `.dim`, etc. that downstream code may inspect
    def __getattr__(self, name):
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.block, name)


def _block_to_stage(model: nn.Module) -> list[int]:
    """Returns a list mapping block_idx -> stage_idx based on model.stage_ends."""
    stage_ends = model.stage_ends
    mapping = []
    for i in range(stage_ends[-1] + 1):
        for s, end in enumerate(stage_ends):
            if i <= end:
                mapping.append(s)
                break
    return mapping


def enable_stage_checkpointing(
    model: nn.Module,
    stages: Union[Iterable[int], str] = (2,),
    decoder: bool = False,
) -> int:
    """In-place: wrap blocks in `stages` with checkpoint().

    Args:
        model: a built Hiera / MaskedAutoencoderHiera.
        stages: iterable of stage indices to checkpoint (default: just stage 2),
                or the string "all" to checkpoint every stage.
        decoder: if True (and model is MAE) also checkpoint decoder blocks.
                 Decoder blocks have a much smaller token count so this is rarely
                 worth it; default is False.

    Returns the count of wrapped blocks.
    """
    if isinstance(stages, str):
        if stages != "all":
            raise ValueError(f"stages must be an iterable or 'all'; got {stages!r}")
        stages = set(range(len(model.stage_ends)))
    else:
        stages = set(stages)

    mapping = _block_to_stage(model)
    n_wrapped = 0
    for i, b in enumerate(model.blocks):
        if isinstance(b, _CheckpointedBlock):
            continue  # idempotent
        if mapping[i] in stages:
            model.blocks[i] = _CheckpointedBlock(b)
            n_wrapped += 1

    if decoder and hasattr(model, "decoder_blocks"):
        for i, b in enumerate(model.decoder_blocks):
            if isinstance(b, _CheckpointedBlock):
                continue
            model.decoder_blocks[i] = _CheckpointedBlock(b)
            n_wrapped += 1

    return n_wrapped


def disable_stage_checkpointing(model: nn.Module) -> int:
    """Unwrap any _CheckpointedBlock wrappers. Returns count unwrapped."""
    n = 0
    for i, b in enumerate(model.blocks):
        if isinstance(b, _CheckpointedBlock):
            model.blocks[i] = b.block
            n += 1
    if hasattr(model, "decoder_blocks"):
        for i, b in enumerate(model.decoder_blocks):
            if isinstance(b, _CheckpointedBlock):
                model.decoder_blocks[i] = b.block
                n += 1
    return n
