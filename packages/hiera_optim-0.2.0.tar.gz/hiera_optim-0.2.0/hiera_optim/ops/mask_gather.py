"""Shape-parametric mask gather / scatter helpers.

These replace FAIR Hiera's boolean indexing (`x[mask.tile(...)]` and
`x_dec[mask] = ...`) with explicit-index gather/scatter, which (a) is faster
because it avoids `aten::nonzero` / `indexing_backward_kernel`, and (b)
unblocks torch.compile by removing the graph break those ops cause.

Layout assumption: token n in the N axis of an unrolled tensor maps to
(t = n // num_mu, w = n % num_mu) — i.e. mask-unit index is the FAST-varying
axis. This is FAIR Unroll's convention; if you bring a model with a different
layout, swap the gather to use the other interpretation.
"""
from __future__ import annotations
from typing import Tuple

import math
import torch


def gather_mu_groups(x: torch.Tensor, keep_idx: torch.Tensor, mu_size: int) -> torch.Tensor:
    """Gather kept mask-unit groups from an unrolled tensor.

    Args:
        x: shape (B, num_mu * mu_size, C). N is interpreted as (T=mu_size, num_mu)
           with num_mu the fast axis (FAIR convention).
        keep_idx: shape (B, len_keep), int64 indices into [0, num_mu).
        mu_size: tokens per mask unit.
    Returns:
        (B, len_keep * mu_size, C), same FAIR-style interleave with nw → len_keep.
    """
    B, N, C = x.shape
    num_mu = N // mu_size
    L = keep_idx.shape[1]
    x_view = x.view(B, mu_size, num_mu, C)
    idx = keep_idx.view(B, 1, L, 1).expand(B, mu_size, L, C)
    return torch.gather(x_view, dim=2, index=idx).reshape(B, mu_size * L, C)


def scatter_decoder_tokens(
    x_kept: torch.Tensor,
    keep_idx: torch.Tensor,
    num_mu: int,
    mask_token: torch.Tensor,
) -> torch.Tensor:
    """Inverse of `gather_mu_groups` for an MAE-style decoder.

    Builds (B, num_mu, MU, C) where kept positions hold values from x_kept
    and removed positions hold mask_token broadcast.

    Args:
        x_kept: (B, len_keep, MU, C)
        keep_idx: (B, len_keep)
        num_mu: total mask-unit count.
        mask_token: (1, 1, C) or broadcastable; filled at removed positions.
    """
    B, L, MU, C = x_kept.shape
    # mask_token is float32 (nn.Parameter default); x_kept is bf16 under
    # AMP autocast — scatter_ requires matching dtypes.
    out = (mask_token.view(1, 1, 1, C).expand(B, num_mu, MU, C)
                     .contiguous().to(x_kept.dtype))
    idx = keep_idx.view(B, L, 1, 1).expand(B, L, MU, C)
    out.scatter_(dim=1, index=idx, src=x_kept)
    return out


def make_mask_with_indices(
    B: int,
    num_mu: int,
    mask_ratio: float,
    device: torch.device,
    generator: torch.Generator | None = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Generate a Hiera-style boolean mask and matching kept-indices.

    The keep-indices are in ascending position order — i.e. they index into
    `range(num_mu)` in the natural order — to match what FAIR's boolean
    indexing iterates over. Compile-friendly: doesn't call `.item()`.

    Returns:
        mask:     (B, num_mu) bool, True = keep.
        keep_idx: (B, len_keep) int64.
    """
    len_keep = int(num_mu * (1 - mask_ratio))
    noise = torch.rand(B, num_mu, device=device, generator=generator)
    ids_shuffle = torch.argsort(noise, dim=1)
    keep_positions = ids_shuffle[:, :len_keep]
    mask = torch.zeros(B, num_mu, device=device, dtype=torch.bool)
    mask.scatter_(1, keep_positions, True)
    # Inline the canonical-order keep_idx: same as keep_idx_from_bool_mask
    # but L is known statically from mask_ratio (avoids the .item() graph break).
    pos = torch.arange(num_mu, device=device).expand(B, num_mu)
    sentinel = torch.full_like(pos, num_mu)
    masked_pos = torch.where(mask, pos, sentinel)
    sorted_pos, _ = masked_pos.sort(dim=1)
    keep_idx = sorted_pos[:, :len_keep].contiguous()
    return mask, keep_idx


def keep_idx_from_bool_mask(mask: torch.Tensor, len_keep: int | None = None) -> torch.Tensor:
    """mask: (B, num_mu) bool with the same number of True per row. Returns
    the kept positions sorted in ascending order — matching mask.nonzero()'s
    layout, which is what FAIR's boolean indexing produces.

    Pass `len_keep` to avoid a `.item()` call (which causes a torch.compile
    graph break). It is the number of True entries per row (FAIR invariant:
    uniform across batch).
    """
    B, M = mask.shape
    if len_keep is None:
        len_keep = int(mask[0].sum().item())  # FAIR invariant: uniform across batch
    pos = torch.arange(M, device=mask.device).expand(B, M)
    sentinel = torch.full_like(pos, M)
    masked_pos = torch.where(mask, pos, sentinel)
    keep_idx, _ = masked_pos.sort(dim=1)
    return keep_idx[:, :len_keep].contiguous()
