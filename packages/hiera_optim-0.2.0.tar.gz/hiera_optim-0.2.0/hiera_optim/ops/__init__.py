"""Pure tensor operations used by the patched forwards.

Nothing in this subpackage imports model classes — these are
shape-parametric helpers that take and return tensors.
"""
from .mask_gather import (
    gather_mu_groups,
    scatter_decoder_tokens,
    make_mask_with_indices,
    keep_idx_from_bool_mask,
)

__all__ = [
    "gather_mu_groups",
    "scatter_decoder_tokens",
    "make_mask_with_indices",
    "keep_idx_from_bool_mask",
]
