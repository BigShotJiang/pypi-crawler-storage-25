"""FP8 mixed-precision via NVIDIA TransformerEngine.

`fp8_optimize(model)` replaces `nn.Linear` modules with `te.Linear` so the
matmuls run in FP8 on Hopper (cc 9.0). Use under a single `fp8_autocast`
context manager.

Only enable on Hopper or newer — fails to import on Ada (4090 cc 8.9).

Example
-------
    from hiera_optim import optimize, fp8_optimize, fp8_autocast
    model = mae_hiera_base_224(...)
    optimize(model)        # layout fix (cheap)
    fp8_optimize(model)    # convert eligible Linears to FP8
    # In your training step:
    with fp8_autocast():
        out = model(x, mask_ratio=0.6, mask=premask)
        out[0].backward()
"""
from __future__ import annotations
import torch
import torch.nn as nn
from typing import Iterable


def _is_te_eligible(linear: nn.Linear, min_dim: int = 64) -> bool:
    """FP8 Linears need K, N both divisible by 16 (TE constraint) and large
    enough that FP8 overhead is amortised. We default min_dim=64."""
    K, N = linear.in_features, linear.out_features
    if K % 16 != 0 or N % 16 != 0:
        return False
    if K < min_dim or N < min_dim:
        return False
    return True


def _replace_linear(parent: nn.Module, name: str, linear: nn.Linear,
                    *, params_dtype: torch.dtype):
    """Swap parent.<name> from nn.Linear to te.Linear with weight-preserving copy."""
    import transformer_engine.pytorch as te
    te_lin = te.Linear(
        linear.in_features, linear.out_features,
        bias=linear.bias is not None,
        params_dtype=params_dtype,
    ).to(device=linear.weight.device)
    with torch.no_grad():
        te_lin.weight.copy_(linear.weight)
        if linear.bias is not None:
            te_lin.bias.copy_(linear.bias)
    setattr(parent, name, te_lin)


def fp8_optimize(
    model: nn.Module,
    *,
    min_dim: int = 64,
    skip_names: Iterable[str] = (
        # MAE-specific bits we never want to FP8:
        "decoder_pred",        # final projector to pixel space
        "patch_embed",         # conv-like layer
        "head",                # classifier head
    ),
    params_dtype: torch.dtype | None = None,
    verbose: bool = True,
) -> int:
    """Replace eligible `nn.Linear`s with `te.Linear` for FP8 matmul.

    Returns the number of layers replaced. Walks `model.named_modules()` and
    swaps in-place. Subsequent `fp8_autocast()` context activates FP8.

    Parameters
    ----------
    model : nn.Module
    min_dim : int
        Minimum in/out feature dim to FP8. Small layers don't benefit.
    skip_names : iterable of substrings
        Skip any module whose qualified name contains one of these.
    params_dtype : torch.dtype, optional
        Storage dtype for TE Linear weights. Defaults to the source dtype.
    """
    try:
        import transformer_engine.pytorch as te  # noqa: F401
    except ImportError as e:
        raise RuntimeError(
            "transformer_engine not installed. Required for FP8 optimisation. "
            f"({e})"
        ) from e

    if torch.cuda.get_device_capability()[0] < 9:
        raise RuntimeError(
            "FP8 requires Hopper (compute capability 9.0+); "
            f"current GPU is cc {torch.cuda.get_device_capability()}"
        )

    parents = {}
    for name, module in model.named_modules():
        for child_name, child in module.named_children():
            qualified = f"{name}.{child_name}" if name else child_name
            if not isinstance(child, nn.Linear):
                continue
            if any(skip in qualified for skip in skip_names):
                continue
            if not _is_te_eligible(child, min_dim=min_dim):
                continue
            parents[qualified] = (module, child_name, child)

    dtype = params_dtype
    if dtype is None:
        # Try to infer from the first eligible weight
        for _, (_, _, lin) in parents.items():
            dtype = lin.weight.dtype
            break
        else:
            dtype = torch.bfloat16

    n = 0
    for qualified, (parent, child_name, lin) in parents.items():
        _replace_linear(parent, child_name, lin, params_dtype=dtype)
        n += 1

    if verbose:
        print(f"  [hiera_optim.fp8] {n} Linear → te.Linear (params_dtype={dtype})")
    return n


def fp8_autocast(enabled: bool = True, recipe=None):
    """Convenience wrapper for `te.fp8_autocast`.

    Default recipe: DelayedScaling with HYBRID format (E4M3 fwd, E5M2 bwd),
    16-step amax history, max-of-history scaling. Production-tested.
    """
    import transformer_engine.pytorch as te
    from transformer_engine.common.recipe import DelayedScaling, Format
    if recipe is None:
        recipe = DelayedScaling(
            fp8_format=Format.HYBRID,
            amax_history_len=16,
            amax_compute_algo="max",
        )
    return te.fp8_autocast(enabled=enabled, fp8_recipe=recipe)


__all__ = ["fp8_optimize", "fp8_autocast"]
