"""Fused (residual + LayerNorm) kernel: `out, normed = LN(x + y)`.

This is the actual Hiera block pattern (`HieraBlock.forward`):

    x = x + drop_path(self.attn(self.norm1(x)))      # residual #1
    x = x + drop_path(self.mlp(self.norm2(x)))        # residual #2

ATen has no fused kernel for `LN(x + y)`: it dispatches `add` + `layer_norm`,
which reads `x` and `y` once, writes the sum, then reads the sum again, then
writes the LN output. That's 4 reads + 2 writes per call.

Our kernel does it in one pass: 2 reads + 2 writes (the post-residual sum is
saved for the next block's residual stream; LN's normalised output is the
input to the next sublayer's matmul).

Compatible with optional `drop_path` (`y *= keep_prob_mask`) by multiplying
`y` before adding; we accept either a scalar drop-path probability (skipped
at inference) or a pre-applied y.

API mirrors `nn.LayerNorm`:

    rln = FusedResidualLayerNorm(dim)
    new_x, normed = rln(x, y)   # new_x = x + y;  normed = LN(new_x)
"""
from __future__ import annotations

import torch
import torch.nn as nn
import triton
import triton.language as tl

from .layernorm import _heuristic_warps, _block_d


# ---------------------------------------------------------------------------
# Forward
# ---------------------------------------------------------------------------

@triton.jit
def _resln_fwd_kernel(
    X_ptr, Y_ptr,             # [M, D]
    Sum_ptr,                  # [M, D] = x + y (saved as new residual stream)
    Out_ptr,                  # [M, D] = LN(x + y)
    W_ptr, B_ptr,             # [D]
    Mean_ptr, Rstd_ptr,       # [M] saved for bwd
    stride_xm, stride_xd,
    stride_ym, stride_yd,
    stride_sm, stride_sd,
    stride_om, stride_od,
    eps,
    M: tl.constexpr,
    D: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    row = tl.program_id(0)
    if row >= M:
        return

    cols = tl.arange(0, BLOCK_D)
    mask = cols < D

    x = tl.load(X_ptr + row * stride_xm + cols * stride_xd, mask=mask, other=0.0).to(tl.float32)
    y = tl.load(Y_ptr + row * stride_ym + cols * stride_yd, mask=mask, other=0.0).to(tl.float32)
    s = x + y

    mean = tl.sum(s, axis=0) / D
    sm   = tl.where(mask, s - mean, 0.0)
    var  = tl.sum(sm * sm, axis=0) / D
    rstd = 1.0 / tl.sqrt(var + eps)

    w = tl.load(W_ptr + cols, mask=mask, other=1.0).to(tl.float32)
    b = tl.load(B_ptr + cols, mask=mask, other=0.0).to(tl.float32)
    out = (sm * rstd) * w + b

    tl.store(Sum_ptr + row * stride_sm + cols * stride_sd, s.to(Sum_ptr.dtype.element_ty), mask=mask)
    tl.store(Out_ptr + row * stride_om + cols * stride_od, out.to(Out_ptr.dtype.element_ty), mask=mask)
    tl.store(Mean_ptr + row, mean)
    tl.store(Rstd_ptr + row, rstd)


# ---------------------------------------------------------------------------
# Backward
#
# Given upstream gradients d_normed (for the LN output) and d_sum (for the
# saved residual stream — the *next* block's bwd writes into it), we need:
#   d_x = d_y = d_sum + d_(LN^-1)(d_normed)
# (so the bwd pattern is symmetric in x and y, identical to the standalone
# residual + LN math.)
# ---------------------------------------------------------------------------

@triton.jit
def _resln_bwd_kernel(
    D_normed_ptr,             # [M, D] upstream grad for normed
    D_sum_ptr,                # [M, D] upstream grad for sum (from the NEXT block's residual)
    Sum_ptr,                  # [M, D] saved x + y from fwd
    W_ptr,                    # [D]
    Mean_ptr, Rstd_ptr,       # [M]
    DX_ptr, DY_ptr,           # [M, D] outputs
    DW_partial, DB_partial,   # [M, D] partial reductions for affine grads
    stride_dnM, stride_dnD,
    stride_dsM, stride_dsD,
    stride_smM, stride_smD,
    stride_dxM, stride_dxD,
    stride_dyM, stride_dyD,
    stride_pM,  stride_pD,
    M: tl.constexpr,
    D: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    row = tl.program_id(0)
    if row >= M:
        return

    cols = tl.arange(0, BLOCK_D)
    mask = cols < D
    D_f: tl.constexpr = D + 0.0

    d_normed = tl.load(D_normed_ptr + row * stride_dnM + cols * stride_dnD, mask=mask, other=0.0).to(tl.float32)
    d_sum    = tl.load(D_sum_ptr    + row * stride_dsM + cols * stride_dsD, mask=mask, other=0.0).to(tl.float32)
    s        = tl.load(Sum_ptr      + row * stride_smM + cols * stride_smD, mask=mask, other=0.0).to(tl.float32)
    w        = tl.load(W_ptr + cols, mask=mask, other=1.0).to(tl.float32)
    mean     = tl.load(Mean_ptr + row).to(tl.float32)
    rstd     = tl.load(Rstd_ptr + row).to(tl.float32)

    xhat = (s - mean) * rstd
    gxhat = d_normed * w
    sum_g = tl.sum(tl.where(mask, gxhat, 0.0), axis=0)
    sum_g_xhat = tl.sum(tl.where(mask, gxhat * xhat, 0.0), axis=0)
    # d(LN^-1)(d_normed) wrt the post-residual input
    d_pre_ln = (gxhat - (sum_g + xhat * sum_g_xhat) / D_f) * rstd

    # Residual rule: d_x = d_y = d_sum_upstream + d_pre_ln
    d_input = d_sum + d_pre_ln

    tl.store(DX_ptr + row * stride_dxM + cols * stride_dxD, d_input.to(DX_ptr.dtype.element_ty), mask=mask)
    tl.store(DY_ptr + row * stride_dyM + cols * stride_dyD, d_input.to(DY_ptr.dtype.element_ty), mask=mask)
    tl.store(DW_partial + row * stride_pM + cols * stride_pD,
             (d_normed * xhat).to(DW_partial.dtype.element_ty), mask=mask)
    tl.store(DB_partial + row * stride_pM + cols * stride_pD,
             d_normed.to(DB_partial.dtype.element_ty), mask=mask)


# ---------------------------------------------------------------------------
# Autograd glue
# ---------------------------------------------------------------------------

class _FusedResidualLayerNorm(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, y: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor, eps: float):
        assert x.shape == y.shape, "x and y must match"
        assert x.is_cuda
        D = x.shape[-1]
        x2 = x.reshape(-1, D).contiguous()
        y2 = y.reshape(-1, D).contiguous()
        M = x2.shape[0]

        s = torch.empty_like(x2)
        out = torch.empty_like(x2)
        mean = torch.empty(M, device=x.device, dtype=torch.float32)
        rstd = torch.empty(M, device=x.device, dtype=torch.float32)

        BLOCK_D = _block_d(D)
        num_warps = _heuristic_warps(D)
        _resln_fwd_kernel[(M,)](
            x2, y2, s, out, weight, bias, mean, rstd,
            x2.stride(0), x2.stride(1),
            y2.stride(0), y2.stride(1),
            s.stride(0), s.stride(1),
            out.stride(0), out.stride(1),
            eps,
            M=M, D=D, BLOCK_D=BLOCK_D, num_warps=num_warps,
        )

        ctx.save_for_backward(s, weight, mean, rstd)
        ctx.eps = eps
        ctx.orig_shape = x.shape
        return s.reshape(x.shape), out.reshape(x.shape)

    @staticmethod
    def backward(ctx, d_sum_in: torch.Tensor, d_normed_in: torch.Tensor):
        s, weight, mean, rstd = ctx.saved_tensors
        D = s.shape[1]
        M = s.shape[0]
        d_normed = d_normed_in.reshape(M, D).contiguous()
        d_sum    = d_sum_in.reshape(M, D).contiguous()

        dx = torch.empty_like(s)
        dy = torch.empty_like(s)
        dw_partial = torch.empty(M, D, device=s.device, dtype=torch.float32)
        db_partial = torch.empty(M, D, device=s.device, dtype=torch.float32)

        BLOCK_D = _block_d(D)
        num_warps = _heuristic_warps(D)
        _resln_bwd_kernel[(M,)](
            d_normed, d_sum, s, weight, mean, rstd,
            dx, dy, dw_partial, db_partial,
            d_normed.stride(0), d_normed.stride(1),
            d_sum.stride(0), d_sum.stride(1),
            s.stride(0), s.stride(1),
            dx.stride(0), dx.stride(1),
            dy.stride(0), dy.stride(1),
            dw_partial.stride(0), dw_partial.stride(1),
            M=M, D=D, BLOCK_D=BLOCK_D, num_warps=num_warps,
        )

        dw = dw_partial.sum(dim=0).to(weight.dtype)
        db = db_partial.sum(dim=0).to(weight.dtype)
        return dx.reshape(ctx.orig_shape), dy.reshape(ctx.orig_shape), dw, db, None


def fused_residual_layernorm(
    x: torch.Tensor,
    y: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float = 1e-5,
):
    """Computes ``s = x + y`` and ``out = LN(s)`` in one Triton kernel.

    Returns both because Hiera's residual stream flows past the LN: the next
    sublayer adds another `y` to `s`, not to `out`.
    """
    return _FusedResidualLayerNorm.apply(x, y, weight, bias, eps)


class FusedResidualLayerNorm(nn.Module):
    """Drop-in for the (residual-add + LayerNorm) pair in a transformer block."""
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.bias   = nn.Parameter(torch.zeros(dim))
        self.eps = eps
        self.dim = dim

    def forward(self, x: torch.Tensor, y: torch.Tensor):
        return fused_residual_layernorm(x, y, self.weight, self.bias, self.eps)
