"""Triton fused mask-unit gather kernel.

Correct but **`torch.gather` is faster at the shapes we tested** — the kernel
is kept here for fusion experiments (e.g. gather + pos_embed in one pass) and
for documentation. The non-Triton reference (`gather_mu_groups`) and the
helper `keep_idx_from_bool_mask` both live in `hiera_optim.ops.mask_gather`.

Layout assumption: FAIR Unroll convention — after unroll, x has
N = num_mu * mu_size tokens with within-mask-unit position SLOW-varying and
mask-unit index FAST. So gather slices `x[:, t, kept_w, :]` over t and
kept_w in keep_idx.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

# Re-export the PyTorch reference and the bool-mask helper so users can
# import everything from this module if they prefer.
from hiera_optim.ops.mask_gather import (
    gather_mu_groups,
    keep_idx_from_bool_mask,
)

__all__ = [
    "gather_mu_groups",          # re-export (PyTorch reference)
    "gather_mu_groups_triton",   # Triton implementation
    "keep_idx_from_bool_mask",   # re-export
]


# ---------- Triton kernel ----------

@triton.jit
def _gather_mu_fwd(
    x_ptr,            # (B, mu_size, num_mu, C)
    out_ptr,          # (B, mu_size, L, C)
    keep_idx_ptr,     # (B, L) int64
    B, MU, NMU, L, C,
    stride_xb, stride_xm, stride_xw, stride_xc,
    stride_ob, stride_om, stride_ol, stride_oc,
    stride_ib, stride_il,
    BLOCK_C: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_lm = tl.program_id(1)       # encodes (k, m) = pid_lm // MU, pid_lm % MU
    pid_c = tl.program_id(2)
    k = pid_lm // MU
    m = pid_lm - k * MU

    # which source mask unit?
    src_w = tl.load(keep_idx_ptr + pid_b * stride_ib + k * stride_il)

    offs_c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    mask_c = offs_c < C

    x_addr = x_ptr + pid_b * stride_xb + m * stride_xm + src_w * stride_xw + offs_c * stride_xc
    o_addr = out_ptr + pid_b * stride_ob + m * stride_om + k * stride_ol + offs_c * stride_oc

    val = tl.load(x_addr, mask=mask_c, other=0.0)
    tl.store(o_addr, val, mask=mask_c)


@triton.jit
def _gather_mu_bwd(
    grad_in_ptr,      # (B, mu_size, num_mu, C)  full-size, zero-initialized
    grad_out_ptr,     # (B, mu_size, L, C)
    keep_idx_ptr,
    B, MU, NMU, L, C,
    stride_gib, stride_gim, stride_giw, stride_gic,
    stride_gob, stride_gom, stride_gol, stride_goc,
    stride_ib, stride_il,
    BLOCK_C: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_lm = tl.program_id(1)
    pid_c = tl.program_id(2)
    k = pid_lm // MU
    m = pid_lm - k * MU

    src_w = tl.load(keep_idx_ptr + pid_b * stride_ib + k * stride_il)

    offs_c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    mask_c = offs_c < C

    go_addr = grad_out_ptr + pid_b * stride_gob + m * stride_gom + k * stride_gol + offs_c * stride_goc
    gi_addr = grad_in_ptr + pid_b * stride_gib + m * stride_gim + src_w * stride_giw + offs_c * stride_gic

    val = tl.load(go_addr, mask=mask_c, other=0.0)
    # keep_idx has no duplicates per row, so a plain store is correct (no race).
    tl.store(gi_addr, val, mask=mask_c)


class _MaskGather(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, keep_idx: torch.Tensor, mu_size: int):
        assert x.is_cuda and keep_idx.is_cuda
        B, N, C = x.shape
        num_mu = N // mu_size
        L = keep_idx.shape[1]

        x_view = x.view(B, mu_size, num_mu, C)
        out = torch.empty(B, mu_size, L, C, device=x.device, dtype=x.dtype)

        BLOCK_C = 64 if C >= 64 else triton.next_power_of_2(max(C, 16))
        grid = (B, L * mu_size, triton.cdiv(C, BLOCK_C))
        _gather_mu_fwd[grid](
            x_view, out, keep_idx.contiguous(),
            B, mu_size, num_mu, L, C,
            *x_view.stride(), *out.stride(),
            *keep_idx.stride(),
            BLOCK_C=BLOCK_C,
        )
        ctx.save_for_backward(keep_idx)
        ctx.mu_size = mu_size
        ctx.num_mu = num_mu
        ctx.B = B
        ctx.C = C
        ctx.x_shape = x.shape
        ctx.x_dtype = x.dtype
        ctx.x_device = x.device
        # Output reshaped to (B, mu_size*L, C) — same as bool-indexing path's view
        return out.reshape(B, mu_size * L, C)

    @staticmethod
    def backward(ctx, grad_out: torch.Tensor):
        keep_idx, = ctx.saved_tensors
        B, MU, NMU, C, L = ctx.B, ctx.mu_size, ctx.num_mu, ctx.C, keep_idx.shape[1]
        grad_out_4d = grad_out.reshape(B, MU, L, C)

        # full-size zero-initialized grad
        grad_in = torch.zeros(B, MU, NMU, C, device=ctx.x_device, dtype=grad_out.dtype)

        BLOCK_C = 64 if C >= 64 else triton.next_power_of_2(max(C, 16))
        grid = (B, L * MU, triton.cdiv(C, BLOCK_C))
        _gather_mu_bwd[grid](
            grad_in, grad_out_4d.contiguous(), keep_idx,
            B, MU, NMU, L, C,
            *grad_in.stride(), *grad_out_4d.stride(),
            *keep_idx.stride(),
            BLOCK_C=BLOCK_C,
        )
        return grad_in.view(ctx.x_shape), None, None


def gather_mu_groups_triton(x: torch.Tensor, keep_idx: torch.Tensor, mu_size: int) -> torch.Tensor:
    return _MaskGather.apply(x, keep_idx, mu_size)
