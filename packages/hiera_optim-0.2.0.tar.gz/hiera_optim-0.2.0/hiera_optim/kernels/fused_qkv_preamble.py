"""Fused (LN + QKV linear + 4D-layout-write) kernel for Hiera mask-unit attention.

The standalone PyTorch sequence at Hiera-Base stage 0 (B=128) breaks down as:

    LN(x)                        184 us
    qkv_linear (cuBLAS)          155 us
    view+permute+reshape→contig  235 us   <-- biggest single cost
    flash_attn                   169 us
    ...

The reshape→contig step is a pure memcpy of `3*B*N*dim_out` elements: PyTorch's
permute lands non-contiguous and the reshape forces a copy. This kernel does
all three preceding steps in one launch and writes Q/K/V directly in the
flash-friendly (B*nw, heads, T, head_dim) contiguous layout. Saves ~570 us of
the 850-us attention block.

Layout convention: FAIR Unroll places tokens such that for input `x[b, n, :]`,
the (t, w) decomposition is `n = t*nw + w` (T outer, nw inner). One Triton
program handles one (b, w) and emits T tokens.

Output buffers Q, K, V are shape `(B*nw, heads, T, head_dim)`; each program
writes to indices `[b*nw + w, :, :, :]`.

Numerically equivalent to FAIR's MaskUnitAttention QKV preamble within
bf16 noise.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _fused_qkv_preamble_fwd_kernel(
    X_ptr,                  # [B, N, dim] = [B, T*nw, dim]
    W_qkv_ptr,              # [3*dim_out, dim]
    B_qkv_ptr,              # [3*dim_out]
    LN_w_ptr, LN_b_ptr,     # [dim], [dim]
    Q_ptr, K_ptr, V_ptr,    # [B*nw, heads, T, head_dim]  (heads * head_dim = dim_out)
    Mean_ptr, Rstd_ptr,     # [B*N] saved for bwd
    Yln_ptr,                # [B, N, dim] saved post-LN-affine for bwd weight grad
    stride_xB, stride_xN, stride_xD,
    stride_wQO, stride_wD,   # qkv weight strides
    stride_qB, stride_qH, stride_qT, stride_qD,  # same layout for K, V
    stride_yB, stride_yN, stride_yD,
    eps,
    B, nw, T, dim: tl.constexpr, dim_out: tl.constexpr,
    heads: tl.constexpr, head_dim: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_K: tl.constexpr,    # power-of-2 >= dim
    BLOCK_HD: tl.constexpr,   # power-of-2 >= head_dim
):
    """One program per (b, w). Handles T tokens.

    Each token: load x_row, do LN, then compute Q/K/V row via matmul with the
    three weight chunks. Write each into its head/T position.
    """
    pid = tl.program_id(0)
    pid_b = pid // nw
    pid_w = pid - pid_b * nw

    cols_d = tl.arange(0, BLOCK_K)
    d_mask = cols_d < dim

    ln_w = tl.load(LN_w_ptr + cols_d, mask=d_mask, other=1.0).to(tl.float32)
    ln_b = tl.load(LN_b_ptr + cols_d, mask=d_mask, other=0.0).to(tl.float32)

    # Tile over T (BLOCK_T tokens at a time).
    for t_start in range(0, T, BLOCK_T):
        t_offs = t_start + tl.arange(0, BLOCK_T)
        t_mask = t_offs < T

        # Source row in x: n = t*nw + w
        n_offs = t_offs * nw + pid_w
        # x_tile: [BLOCK_T, dim]
        x_ptrs = (X_ptr
                  + pid_b * stride_xB
                  + n_offs[:, None] * stride_xN
                  + cols_d[None, :] * stride_xD)
        full_mask = t_mask[:, None] & d_mask[None, :]
        x_tile = tl.load(x_ptrs, mask=full_mask, other=0.0).to(tl.float32)

        # LayerNorm
        mean = tl.sum(tl.where(d_mask[None, :], x_tile, 0.0), axis=1) / dim
        xm = tl.where(d_mask[None, :], x_tile - mean[:, None], 0.0)
        var = tl.sum(xm * xm, axis=1) / dim
        rstd = 1.0 / tl.sqrt(var + eps)
        xn = xm * rstd[:, None] * ln_w[None, :] + ln_b[None, :]
        xn_lo = xn.to(X_ptr.dtype.element_ty)

        # Save mean/rstd at index (b, n) — flat indexing across batch
        save_idx = pid_b * (T * nw) + n_offs
        tl.store(Mean_ptr + save_idx, mean, mask=t_mask)
        tl.store(Rstd_ptr + save_idx, rstd, mask=t_mask)

        # Save y_ln (post-LN affine) at (b, n, :) — needed for bwd grad_qkv_w
        yln_ptrs = (Yln_ptr
                    + pid_b * stride_yB
                    + n_offs[:, None] * stride_yN
                    + cols_d[None, :] * stride_yD)
        tl.store(yln_ptrs, xn_lo, mask=full_mask)

        # Compute Q/K/V via matmul with W_qkv.
        # W_qkv layout: rows [3*dim_out, dim]. First dim_out rows = Q, next dim_out = K, last = V.
        # We iterate over head h, and within each head over the D=head_dim cols
        # of W_qkv. To avoid 3 separate matmuls we do them sequentially per head.
        for h in tl.static_range(heads):
            # For this head, output dim is head_dim. The columns of W_qkv
            # contributing to Q[h,:] are rows [h*head_dim : (h+1)*head_dim].
            out_d = tl.arange(0, BLOCK_HD)
            d_out_mask = out_d < head_dim
            base_q = h * head_dim
            base_k = dim_out + h * head_dim
            base_v = 2 * dim_out + h * head_dim

            # W_q: [head_dim, dim]
            wq_ptrs = (W_qkv_ptr
                       + (base_q + out_d)[:, None] * stride_wQO
                       + cols_d[None, :] * stride_wD)
            wq = tl.load(wq_ptrs, mask=d_out_mask[:, None] & d_mask[None, :], other=0.0)
            bq = tl.load(B_qkv_ptr + base_q + out_d, mask=d_out_mask, other=0.0).to(tl.float32)
            q_tile = tl.dot(xn_lo, tl.trans(wq)) + bq[None, :]  # [BLOCK_T, head_dim]

            wk_ptrs = (W_qkv_ptr
                       + (base_k + out_d)[:, None] * stride_wQO
                       + cols_d[None, :] * stride_wD)
            wk = tl.load(wk_ptrs, mask=d_out_mask[:, None] & d_mask[None, :], other=0.0)
            bk = tl.load(B_qkv_ptr + base_k + out_d, mask=d_out_mask, other=0.0).to(tl.float32)
            k_tile = tl.dot(xn_lo, tl.trans(wk)) + bk[None, :]

            wv_ptrs = (W_qkv_ptr
                       + (base_v + out_d)[:, None] * stride_wQO
                       + cols_d[None, :] * stride_wD)
            wv = tl.load(wv_ptrs, mask=d_out_mask[:, None] & d_mask[None, :], other=0.0)
            bv = tl.load(B_qkv_ptr + base_v + out_d, mask=d_out_mask, other=0.0).to(tl.float32)
            v_tile = tl.dot(xn_lo, tl.trans(wv)) + bv[None, :]

            # Write to Q/K/V at (b*nw+w, h, t, d).
            out_b = pid_b * nw + pid_w
            q_dst = (Q_ptr
                     + out_b * stride_qB
                     + h * stride_qH
                     + t_offs[:, None] * stride_qT
                     + out_d[None, :] * stride_qD)
            wmask = t_mask[:, None] & d_out_mask[None, :]
            tl.store(q_dst, q_tile.to(Q_ptr.dtype.element_ty), mask=wmask)
            k_dst = (K_ptr
                     + out_b * stride_qB
                     + h * stride_qH
                     + t_offs[:, None] * stride_qT
                     + out_d[None, :] * stride_qD)
            tl.store(k_dst, k_tile.to(K_ptr.dtype.element_ty), mask=wmask)
            v_dst = (V_ptr
                     + out_b * stride_qB
                     + h * stride_qH
                     + t_offs[:, None] * stride_qT
                     + out_d[None, :] * stride_qD)
            tl.store(v_dst, v_tile.to(V_ptr.dtype.element_ty), mask=wmask)


def fused_qkv_preamble(
    x: torch.Tensor,                 # (B, N, dim)
    ln_w: torch.Tensor, ln_b: torch.Tensor,
    qkv_w: torch.Tensor, qkv_b: torch.Tensor,
    heads: int,
    nw: int,
    eps: float = 1e-6,
):
    """Returns (q, k, v) each shape (B*nw, heads, T, head_dim)."""
    assert x.is_cuda and x.is_contiguous()
    B, N, dim = x.shape
    T = N // nw
    assert N == T * nw, f"N={N} not divisible by nw={nw}"
    dim_out = qkv_w.shape[0] // 3
    head_dim = dim_out // heads
    assert qkv_w.shape == (3 * dim_out, dim)

    device = x.device
    dtype = x.dtype
    q = torch.empty(B * nw, heads, T, head_dim, device=device, dtype=dtype)
    k = torch.empty_like(q)
    v = torch.empty_like(q)
    mean = torch.empty(B * N, device=device, dtype=torch.float32)
    rstd = torch.empty(B * N, device=device, dtype=torch.float32)
    y_ln = torch.empty(B, N, dim, device=device, dtype=dtype)

    BLOCK_T = min(triton.next_power_of_2(T), 32)
    BLOCK_K = triton.next_power_of_2(dim)
    BLOCK_HD = triton.next_power_of_2(head_dim)
    num_warps = 4
    num_stages = 1

    grid = (B * nw,)
    _fused_qkv_preamble_fwd_kernel[grid](
        x, qkv_w, qkv_b, ln_w, ln_b, q, k, v, mean, rstd, y_ln,
        x.stride(0), x.stride(1), x.stride(2),
        qkv_w.stride(0), qkv_w.stride(1),
        q.stride(0), q.stride(1), q.stride(2), q.stride(3),
        y_ln.stride(0), y_ln.stride(1), y_ln.stride(2),
        eps,
        B, nw, T, dim, dim_out, heads, head_dim,
        BLOCK_T=BLOCK_T, BLOCK_K=BLOCK_K, BLOCK_HD=BLOCK_HD,
        num_warps=num_warps,
        num_stages=num_stages,
    )
    return q, k, v, mean, rstd, y_ln
