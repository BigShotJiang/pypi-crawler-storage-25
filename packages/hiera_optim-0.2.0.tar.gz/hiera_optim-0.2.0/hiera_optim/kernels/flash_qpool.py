"""Fused Q-pool + FlashAttention (Triton).

Hiera-specific: at stage transitions, Q is max-pooled across `q_stride`
consecutive positions BEFORE attention. The current pipeline is:

    q.view(Bnw, H, q_stride, Tq, D).amax(dim=2)        # max-pool
    out = F.scaled_dot_product_attention(q, k, v)       # 4D flash attn

This kernel fuses the two: it reads K, V once and Q's full T_full positions,
performs the q_stride max-pool *in registers / SRAM*, then runs flash attention.
Compared to the sequence above it saves a full pass of Q over HBM (write
post-pool, read for attention) — important on Hopper where HBM bandwidth is
the bottleneck on short-seq attention.

API mirrors `F.scaled_dot_product_attention` with an extra `q_stride` arg:

    out = flash_qpool_attention(q_full, k, v, q_stride)

  q_full: (B, H, T_full, D),  T_full = q_stride * Tq
  k:      (B, H, T, D)
  v:      (B, H, T, D)
  out:    (B, H, Tq, D)

Backward: gradient of max-pool is sparse (only the argmax position receives
the upstream gradient). We delegate the attention bwd to PyTorch flash via
saved q_pooled and re-do the max-pool to recover the argmax indices on bwd.

Constraints (for the fwd kernel):
  - D and T must be powers-of-2 in the supported set {16, 32, 64, 96, 128}
    (handled by autotune below).
  - q_stride in {2, 4}.
"""
from __future__ import annotations
import math
import torch
import triton
import triton.language as tl


# ---------- Reference: plain max-pool then SDPA ----------

def qpool_attention_ref(q_full: torch.Tensor, k: torch.Tensor, v: torch.Tensor, q_stride: int) -> torch.Tensor:
    B, H, T_full, D = q_full.shape
    Tq = T_full // q_stride
    q = q_full.view(B, H, q_stride, Tq, D).amax(dim=2)
    return torch.nn.functional.scaled_dot_product_attention(q, k, v)


# ---------- Triton fwd kernel (FlashAttention-style, with fused Q-pool) ----------

@triton.jit
def _flash_qpool_fwd(
    Q_ptr, K_ptr, V_ptr, O_ptr,
    L_ptr,  # log-sum-exp save for bwd (B, H, Tq)
    sqB, sqH, sqT, sqD,
    skB, skH, skT, skD,
    svB, svH, svT, svD,
    soB, soH, soT, soD,
    slB, slH, slT,
    B, H, T, Tq, D, q_stride: tl.constexpr,
    SCALE,
    BLOCK_T: tl.constexpr,
    BLOCK_TQ: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """One program handles one (b, h, tq_block).

    Q is read as (q_stride, BLOCK_TQ, D) tiles, max-reduced over q_stride.
    Then loops over T axis BLOCK_T at a time, accumulating softmax(QK^T / s) V.
    """
    pid_bh = tl.program_id(0)
    pid_tq = tl.program_id(1)
    pid_b = pid_bh // H
    pid_h = pid_bh - pid_b * H

    offs_tq = pid_tq * BLOCK_TQ + tl.arange(0, BLOCK_TQ)  # [BLOCK_TQ]
    mask_tq = offs_tq < Tq
    offs_d = tl.arange(0, BLOCK_D)
    mask_d = offs_d < D

    # Load Q_full at positions (s, tq) for s in 0..q_stride-1, take max.
    # T_full layout: token t_full = s * Tq + tq  (q_stride is OUTER per FAIR's do_pool)
    q_base = Q_ptr + pid_b * sqB + pid_h * sqH
    q = tl.full((BLOCK_TQ, BLOCK_D), -1e30, dtype=tl.float32)
    for s in tl.static_range(q_stride):
        t_full = s * Tq + offs_tq
        # Load (BLOCK_TQ, BLOCK_D), masking both tq and d
        q_off = q_base + t_full[:, None] * sqT + offs_d[None, :] * sqD
        m = mask_tq[:, None] & mask_d[None, :]
        q_tile = tl.load(q_off, mask=m, other=-1e30).to(tl.float32)
        q = tl.maximum(q, q_tile)
    # Mask out invalid tq rows and pad-d (so they contribute 0 to QK)
    q = tl.where(mask_tq[:, None] & mask_d[None, :], q, 0.0)
    # Apply scale up-front so QK^T already has it
    q = q * SCALE

    # Init running stats for flash softmax
    m_i = tl.full((BLOCK_TQ,), -1e30, dtype=tl.float32)
    l_i = tl.zeros((BLOCK_TQ,), dtype=tl.float32)
    acc = tl.zeros((BLOCK_TQ, BLOCK_D), dtype=tl.float32)

    k_base = K_ptr + pid_b * skB + pid_h * skH
    v_base = V_ptr + pid_b * svB + pid_h * svH

    # Iterate over T axis
    for t_start in range(0, T, BLOCK_T):
        offs_t = t_start + tl.arange(0, BLOCK_T)
        mask_t = offs_t < T

        # K tile: (BLOCK_T, BLOCK_D)
        k_off = k_base + offs_t[:, None] * skT + offs_d[None, :] * skD
        k_tile = tl.load(k_off, mask=mask_t[:, None] & mask_d[None, :], other=0.0).to(tl.float32)
        # V tile: (BLOCK_T, BLOCK_D)
        v_off = v_base + offs_t[:, None] * svT + offs_d[None, :] * svD
        v_tile = tl.load(v_off, mask=mask_t[:, None] & mask_d[None, :], other=0.0).to(tl.float32)

        # QK^T : (BLOCK_TQ, BLOCK_T)
        qk = tl.dot(q, tl.trans(k_tile))
        qk = tl.where(mask_t[None, :], qk, -1e30)

        # Online softmax update
        m_ij = tl.max(qk, axis=1)
        m_new = tl.maximum(m_i, m_ij)
        alpha = tl.exp(m_i - m_new)
        p = tl.exp(qk - m_new[:, None])
        l_new = alpha * l_i + tl.sum(p, axis=1)

        # Rescale accumulator
        acc = acc * alpha[:, None] + tl.dot(p.to(v_tile.dtype), v_tile)
        m_i = m_new
        l_i = l_new

    out = acc / l_i[:, None]
    # Store output and log-sum-exp
    o_base = O_ptr + pid_b * soB + pid_h * soH
    o_off = o_base + offs_tq[:, None] * soT + offs_d[None, :] * soD
    tl.store(o_off, out.to(O_ptr.dtype.element_ty), mask=mask_tq[:, None] & mask_d[None, :])

    # log-sum-exp = m_i + log(l_i)
    l_save = m_i + tl.log(l_i)
    l_addr = L_ptr + pid_b * slB + pid_h * slH + offs_tq * slT
    tl.store(l_addr, l_save, mask=mask_tq)


# ---------- Autograd glue ----------

def _supported_D(D: int) -> int:
    """Round D up to the next supported BLOCK_D. We support D <= 128 power-of-2."""
    for cand in [16, 32, 64, 96, 128]:
        if D <= cand:
            return cand
    raise NotImplementedError(f"Unsupported head_dim {D}")


class _FlashQPool(torch.autograd.Function):
    @staticmethod
    def forward(ctx, q_full: torch.Tensor, k: torch.Tensor, v: torch.Tensor, q_stride: int):
        assert q_full.is_cuda and k.is_cuda and v.is_cuda
        B, H, T_full, D = q_full.shape
        assert T_full % q_stride == 0, f"T_full {T_full} not divisible by q_stride {q_stride}"
        Tq = T_full // q_stride
        Bk, Hk, T, Dk = k.shape
        assert (B, H, D) == (Bk, Hk, Dk), "B/H/D mismatch q vs k"

        out = torch.empty(B, H, Tq, D, device=q_full.device, dtype=q_full.dtype)
        L = torch.empty(B, H, Tq, device=q_full.device, dtype=torch.float32)

        scale = 1.0 / math.sqrt(D)
        BLOCK_TQ = min(triton.next_power_of_2(max(Tq, 16)), 64)
        BLOCK_T = min(triton.next_power_of_2(max(T, 16)), 128)
        BLOCK_D = triton.next_power_of_2(D)

        grid = (B * H, triton.cdiv(Tq, BLOCK_TQ))
        _flash_qpool_fwd[grid](
            q_full, k, v, out, L,
            *q_full.stride(), *k.stride(), *v.stride(), *out.stride(), *L.stride(),
            B, H, T, Tq, D, q_stride,
            scale,
            BLOCK_T=BLOCK_T, BLOCK_TQ=BLOCK_TQ, BLOCK_D=BLOCK_D,
            num_warps=4, num_stages=2,
        )

        # For bwd: we need q_pooled (the max-pooled Q) to compute dQ.
        # Re-run the max-pool (cheap) instead of saving the giant T_full Q.
        ctx.save_for_backward(q_full, k, v, out, L)
        ctx.q_stride = q_stride
        ctx.scale = scale
        return out

    @staticmethod
    def backward(ctx, grad_out: torch.Tensor):
        q_full, k, v, out, L = ctx.saved_tensors
        qs = ctx.q_stride
        B, H, T_full, D = q_full.shape
        Tq = T_full // qs
        # Recompute argmax for the q-pool. Sparse routing: gradient flows only
        # to the argmax position along the q_stride axis.
        qv = q_full.view(B, H, qs, Tq, D)
        # q_pooled: (B, H, Tq, D)
        q_pooled, argmax = qv.max(dim=2)
        # Use PyTorch's flash attention bwd through F.scaled_dot_product_attention
        # via re-running with requires_grad. (We could call _flash_attention_backward
        # directly but the public API is more robust.)
        with torch.enable_grad():
            q_p = q_pooled.detach().requires_grad_(True)
            k_ = k.detach().requires_grad_(True)
            v_ = v.detach().requires_grad_(True)
            out_ref = torch.nn.functional.scaled_dot_product_attention(q_p, k_, v_)
            gq_p, gk, gv = torch.autograd.grad(out_ref, [q_p, k_, v_], grad_out)

        # Scatter dQ along q_stride according to argmax.
        gq_full = torch.zeros_like(q_full)
        gq_full_v = gq_full.view(B, H, qs, Tq, D)
        gq_full_v.scatter_(2, argmax.unsqueeze(2), gq_p.unsqueeze(2))
        return gq_full, gk, gv, None


def flash_qpool_attention(q_full: torch.Tensor, k: torch.Tensor, v: torch.Tensor, q_stride: int) -> torch.Tensor:
    """Fused Q-pool + Flash Attention. See module docstring."""
    return _FlashQPool.apply(q_full, k, v, q_stride)
