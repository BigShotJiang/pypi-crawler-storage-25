"""Backward-side fusion for `fused_proj_epilogue`.

Given grad_out (B, N, dim_out) and proj_w, produces grad_z in 4-D flash
layout (B*nw, H, T, head_dim) without materialising the inverse permute.

ATen would do: contiguous-permute (memcpy) then matmul. We fuse the layout
shuffle with the matmul read.

One program per (b, w). For each head h it produces grad_z[out_b, h, :, :]
by accumulating a [BLOCK_T, BLOCK_HD] tile via a K-tiled matmul over the
input dim. K-tiling keeps SMEM small across dtypes.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _inv_proj_epilogue_kernel(
    dOut_ptr,              # [B, N, dim_out]
    Proj_w_ptr,            # [dim_out, dim_out]
    dZ_ptr,                # [B*nw, H, T, head_dim]
    stride_doB, stride_doN, stride_doD,
    stride_pO, stride_pI,
    stride_dzB, stride_dzH, stride_dzT, stride_dzD,
    B, nw, T, dim_out: tl.constexpr,
    heads: tl.constexpr, head_dim: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_K: tl.constexpr,        # K-tile across dim_out (= sum dim)
    BLOCK_HD: tl.constexpr,
):
    pid = tl.program_id(0)
    pid_b = pid // nw
    pid_w = pid - pid_b * nw

    cols_hd = tl.arange(0, BLOCK_HD)
    hd_mask = cols_hd < head_dim

    out_b_idx = pid_b * nw + pid_w

    t_offs = tl.arange(0, BLOCK_T)
    t_mask = t_offs < T

    for h in tl.static_range(heads):
        acc = tl.zeros((BLOCK_T, BLOCK_HD), dtype=tl.float32)

        for k_start in range(0, dim_out, BLOCK_K):
            k_offs = k_start + tl.arange(0, BLOCK_K)
            k_mask = k_offs < dim_out

            # d_out[b, t*nw+w, k] -> [BLOCK_T, BLOCK_K]
            n_offs = t_offs * nw + pid_w
            do_ptrs = (dOut_ptr
                       + pid_b * stride_doB
                       + n_offs[:, None] * stride_doN
                       + k_offs[None, :] * stride_doD)
            d_out = tl.load(do_ptrs, mask=t_mask[:, None] & k_mask[None, :], other=0.0)

            # proj_w[k, h*head_dim + d] -> [BLOCK_K, BLOCK_HD]
            w_ptrs = (Proj_w_ptr
                      + k_offs[:, None] * stride_pO
                      + (h * head_dim + cols_hd[None, :]) * stride_pI)
            w_slice = tl.load(w_ptrs, mask=k_mask[:, None] & hd_mask[None, :], other=0.0)

            acc = tl.dot(d_out, w_slice, acc)

        dz_ptrs = (dZ_ptr
                   + out_b_idx * stride_dzB
                   + h * stride_dzH
                   + t_offs[:, None] * stride_dzT
                   + cols_hd[None, :] * stride_dzD)
        tl.store(dz_ptrs, acc.to(dZ_ptr.dtype.element_ty),
                 mask=t_mask[:, None] & hd_mask[None, :])


def inv_proj_epilogue(
    grad_out: torch.Tensor,         # (B, N, dim_out)
    proj_w: torch.Tensor,           # (dim_out, dim_out)
    nw: int,
    heads: int,
    head_dim: int,
    T: int,
) -> torch.Tensor:
    B, N, dim_out = grad_out.shape
    assert proj_w.shape == (dim_out, dim_out)
    assert N == T * nw
    assert heads * head_dim == dim_out

    grad_z = torch.empty(B * nw, heads, T, head_dim, device=grad_out.device, dtype=grad_out.dtype)

    BLOCK_T = max(triton.next_power_of_2(T), 16)
    BLOCK_HD = triton.next_power_of_2(head_dim)
    BLOCK_K = 64
    num_warps = 4

    grid = (B * nw,)
    _inv_proj_epilogue_kernel[grid](
        grad_out, proj_w, grad_z,
        grad_out.stride(0), grad_out.stride(1), grad_out.stride(2),
        proj_w.stride(0), proj_w.stride(1),
        grad_z.stride(0), grad_z.stride(1), grad_z.stride(2), grad_z.stride(3),
        B, nw, T, dim_out, heads, head_dim,
        BLOCK_T=BLOCK_T, BLOCK_K=BLOCK_K, BLOCK_HD=BLOCK_HD,
        num_warps=num_warps,
        num_stages=1,
    )
    return grad_z
