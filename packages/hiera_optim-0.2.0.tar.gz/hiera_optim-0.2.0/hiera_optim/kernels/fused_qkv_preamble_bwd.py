"""Backward-side fusion for `fused_qkv_preamble`.

Given grad_q, grad_k, grad_v in flash layout (B*nw, H, T, head_dim) and the
saved qkv_w, produce grad_y_ln (B, N, dim) — the gradient flowing to the
LN output — without first materialising the inverse-permute.

ATen would do this as a contiguous-permute (one big copy of 3*B*N*dim_out
elements) followed by a wide matmul. We fuse the layout shuffle with the
matmul read.

Strategy: one program per (b, w). It produces all T rows of grad_y_ln for
mask-unit w. The output dim is tiled in BLOCK_I chunks so each program loops
over output cols. For each chunk it sums q/k/v contributions across heads.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _inv_qkv_preamble_kernel(
    dQ_ptr, dK_ptr, dV_ptr,        # [B*nw, H, T, head_dim]
    QKV_w_ptr,                      # [3*dim_out, dim]
    dY_ln_ptr,                      # [B, N, dim] output
    stride_dqB, stride_dqH, stride_dqT, stride_dqD,
    stride_wO, stride_wI,
    stride_dyB, stride_dyN, stride_dyI,
    B, nw, T, dim: tl.constexpr, dim_out: tl.constexpr,
    heads: tl.constexpr, head_dim: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_I: tl.constexpr,        # tile size along output dim
    BLOCK_HD: tl.constexpr,
):
    pid = tl.program_id(0)
    pid_b = pid // nw
    pid_w = pid - pid_b * nw

    out_b_idx = pid_b * nw + pid_w

    t_offs = tl.arange(0, BLOCK_T)
    t_mask = t_offs < T

    cols_hd = tl.arange(0, BLOCK_HD)
    hd_mask = cols_hd < head_dim

    # Tile across output dim.
    for i_start in range(0, dim, BLOCK_I):
        i_offs = i_start + tl.arange(0, BLOCK_I)
        i_mask = i_offs < dim

        grad_y_chunk = tl.zeros((BLOCK_T, BLOCK_I), dtype=tl.float32)

        for h in tl.static_range(heads):
            base_off = (out_b_idx * stride_dqB + h * stride_dqH
                        + t_offs[:, None] * stride_dqT
                        + cols_hd[None, :] * stride_dqD)
            dq = tl.load(dQ_ptr + base_off, mask=t_mask[:, None] & hd_mask[None, :], other=0.0)
            dk = tl.load(dK_ptr + base_off, mask=t_mask[:, None] & hd_mask[None, :], other=0.0)
            dv = tl.load(dV_ptr + base_off, mask=t_mask[:, None] & hd_mask[None, :], other=0.0)

            head_d_lo = h * head_dim

            wq_ptrs = (QKV_w_ptr
                       + (head_d_lo + cols_hd)[:, None] * stride_wO
                       + i_offs[None, :] * stride_wI)
            wq = tl.load(wq_ptrs, mask=hd_mask[:, None] & i_mask[None, :], other=0.0)
            grad_y_chunk = tl.dot(dq, wq, grad_y_chunk)

            wk_ptrs = (QKV_w_ptr
                       + (dim_out + head_d_lo + cols_hd)[:, None] * stride_wO
                       + i_offs[None, :] * stride_wI)
            wk = tl.load(wk_ptrs, mask=hd_mask[:, None] & i_mask[None, :], other=0.0)
            grad_y_chunk = tl.dot(dk, wk, grad_y_chunk)

            wv_ptrs = (QKV_w_ptr
                       + (2 * dim_out + head_d_lo + cols_hd)[:, None] * stride_wO
                       + i_offs[None, :] * stride_wI)
            wv = tl.load(wv_ptrs, mask=hd_mask[:, None] & i_mask[None, :], other=0.0)
            grad_y_chunk = tl.dot(dv, wv, grad_y_chunk)

        n_offs = t_offs * nw + pid_w
        dy_ptrs = (dY_ln_ptr
                   + pid_b * stride_dyB
                   + n_offs[:, None] * stride_dyN
                   + i_offs[None, :] * stride_dyI)
        tl.store(dy_ptrs, grad_y_chunk.to(dY_ln_ptr.dtype.element_ty),
                 mask=t_mask[:, None] & i_mask[None, :])


def inv_qkv_preamble(
    grad_q: torch.Tensor,
    grad_k: torch.Tensor,
    grad_v: torch.Tensor,
    qkv_w: torch.Tensor,
    nw: int,
) -> torch.Tensor:
    """Returns grad_y_ln (B, N, dim). Layout-fused inverse of `fused_qkv_preamble`."""
    Bnw, heads, T, head_dim = grad_q.shape
    B = Bnw // nw
    dim_out = heads * head_dim
    dim = qkv_w.shape[1]
    assert qkv_w.shape == (3 * dim_out, dim)
    N = T * nw

    grad_y_ln = torch.empty(B, N, dim, device=grad_q.device, dtype=grad_q.dtype)

    BLOCK_T = max(triton.next_power_of_2(T), 16)
    BLOCK_HD = triton.next_power_of_2(head_dim)
    # Output-dim tile sized to keep SMEM in check across dtypes.
    BLOCK_I = 64
    num_warps = 4

    grid = (B * nw,)
    _inv_qkv_preamble_kernel[grid](
        grad_q, grad_k, grad_v, qkv_w, grad_y_ln,
        grad_q.stride(0), grad_q.stride(1), grad_q.stride(2), grad_q.stride(3),
        qkv_w.stride(0), qkv_w.stride(1),
        grad_y_ln.stride(0), grad_y_ln.stride(1), grad_y_ln.stride(2),
        B, nw, T, dim, dim_out, heads, head_dim,
        BLOCK_T=BLOCK_T, BLOCK_I=BLOCK_I, BLOCK_HD=BLOCK_HD,
        num_warps=num_warps,
        num_stages=1,
    )
    return grad_y_ln
