"""Fast Triton pack: (B*nw, H, T, D) → (B, N, dim_out).

Used to materialise the packed z for grad_proj_w cuBLAS matmul. ATen does
view + permute + contiguous; this kernel writes once.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _pack_z_kernel(
    Z_ptr,                     # [B*nw, H, T, head_dim]
    Out_ptr,                   # [B, N, dim_out]
    stride_zB, stride_zH, stride_zT, stride_zD,
    stride_oB, stride_oN, stride_oD,
    B, nw, T,
    heads: tl.constexpr,
    head_dim: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_HD: tl.constexpr,
):
    pid = tl.program_id(0)
    t_tiles = tl.cdiv(T, BLOCK_T)
    pid_b = pid // (nw * t_tiles)
    rem = pid - pid_b * (nw * t_tiles)
    pid_w = rem // t_tiles
    pid_tile = rem - pid_w * t_tiles

    out_b = pid_b * nw + pid_w
    cols_hd = tl.arange(0, BLOCK_HD)
    hd_mask = cols_hd < head_dim

    t_offs = pid_tile * BLOCK_T + tl.arange(0, BLOCK_T)
    t_mask = t_offs < T
    n_offs = t_offs * nw + pid_w

    for h in tl.static_range(heads):
        src_off = (out_b * stride_zB + h * stride_zH
                   + t_offs[:, None] * stride_zT
                   + cols_hd[None, :] * stride_zD)
        src_mask = t_mask[:, None] & hd_mask[None, :]
        dst_off = (pid_b * stride_oB
                   + n_offs[:, None] * stride_oN
                   + (h * head_dim + cols_hd[None, :]) * stride_oD)
        z_vals = tl.load(Z_ptr + src_off, mask=src_mask, other=0.0)
        tl.store(Out_ptr + dst_off, z_vals, mask=src_mask)


def pack_z(z: torch.Tensor, nw: int) -> torch.Tensor:
    """(B*nw, H, T, head_dim) → (B, N, heads*head_dim) contiguous."""
    Bnw, heads, T, head_dim = z.shape
    B = Bnw // nw
    dim_out = heads * head_dim
    N = T * nw
    out = torch.empty(B, N, dim_out, device=z.device, dtype=z.dtype)

    BLOCK_HD = triton.next_power_of_2(head_dim)
    BLOCK_T = min(triton.next_power_of_2(T), 32)
    t_tiles = (T + BLOCK_T - 1) // BLOCK_T
    grid = (B * nw * t_tiles,)
    _pack_z_kernel[grid](
        z, out,
        z.stride(0), z.stride(1), z.stride(2), z.stride(3),
        out.stride(0), out.stride(1), out.stride(2),
        B, nw, T,
        heads=heads, head_dim=head_dim,
        BLOCK_T=BLOCK_T, BLOCK_HD=BLOCK_HD,
        num_warps=4,
    )
    return out
