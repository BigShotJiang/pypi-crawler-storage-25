"""GPU architecture detection and per-arch autotune configs.

Mirrors the pattern used in siglip-kernel: detect SM version once, return
a curated list of `triton.Config` for each kernel/op, prune the obviously
wasteful ones at call time.
"""
from __future__ import annotations

import torch
import triton


def get_gpu_arch() -> int:
    """Return SM version as integer (e.g. 89 for Ada, 90 for Hopper)."""
    major, minor = torch.cuda.get_device_capability()
    return major * 10 + minor


def get_num_sms() -> int:
    return torch.cuda.get_device_properties(0).multi_processor_count


def get_smem_per_sm_kb() -> int:
    return torch.cuda.get_device_properties(0).shared_memory_per_multiprocessor // 1024


def supports_fp8() -> bool:
    return get_gpu_arch() >= 89


def supports_tma() -> bool:
    return get_gpu_arch() >= 90


def supports_clusters() -> bool:
    """Thread block clusters (num_ctas > 1) require SM90+, not SM120."""
    arch = get_gpu_arch()
    return 90 <= arch < 120


# ---------------------------------------------------------------------------
# Autotune configs — LayerNorm (row-parallel)
# ---------------------------------------------------------------------------

def get_layernorm_configs():
    """Configs for the row-parallel fused LayerNorm fwd/bwd kernels.

    The kernel processes one row per program along dim D. We want a
    `BLOCK_D >= D` so the whole row fits in registers / SRAM, and we want
    `num_warps` proportional to D / 128 to keep each warp busy.
    """
    arch = get_gpu_arch()

    if arch >= 100:  # Blackwell
        return [
            triton.Config({"BLOCK_D": 128},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 256},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 512},  num_warps=8, num_stages=3),
            triton.Config({"BLOCK_D": 1024}, num_warps=8, num_stages=3),
            triton.Config({"BLOCK_D": 2048}, num_warps=16, num_stages=3),
        ]
    if arch >= 90:  # Hopper
        return [
            triton.Config({"BLOCK_D": 128},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 256},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 512},  num_warps=8, num_stages=3),
            triton.Config({"BLOCK_D": 1024}, num_warps=8, num_stages=3),
            triton.Config({"BLOCK_D": 2048}, num_warps=16, num_stages=3),
        ]
    if arch >= 89:  # Ada (RTX 4090, L40)
        return [
            triton.Config({"BLOCK_D": 128},  num_warps=2, num_stages=2),
            triton.Config({"BLOCK_D": 256},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 512},  num_warps=4, num_stages=2),
            triton.Config({"BLOCK_D": 1024}, num_warps=8, num_stages=2),
            triton.Config({"BLOCK_D": 2048}, num_warps=8, num_stages=2),
        ]
    # Ampere and older
    return [
        triton.Config({"BLOCK_D": 128},  num_warps=2, num_stages=2),
        triton.Config({"BLOCK_D": 256},  num_warps=4, num_stages=2),
        triton.Config({"BLOCK_D": 512},  num_warps=4, num_stages=2),
        triton.Config({"BLOCK_D": 1024}, num_warps=8, num_stages=2),
    ]


def prune_layernorm_configs(configs, named_args, **kwargs):
    """Keep configs whose BLOCK_D is just big enough to cover D.

    We always pick the smallest BLOCK_D >= D (with one larger as a fallback)
    so we don't waste registers / time iterating an oversized block.
    """
    D = kwargs.get("D", named_args.get("D"))
    if D is None:
        return configs
    eligible = [c for c in configs if c.kwargs["BLOCK_D"] >= D]
    if not eligible:
        # D is bigger than every block we offer — keep the largest, masked at runtime
        return [max(configs, key=lambda c: c.kwargs["BLOCK_D"])]
    # Keep the two smallest eligible blocks (gives the autotuner room without explosion)
    eligible.sort(key=lambda c: c.kwargs["BLOCK_D"])
    return eligible[:2]
