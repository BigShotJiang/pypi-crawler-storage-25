"""Fused Triton LayerNorm (fwd + bwd) drop-in for `nn.LayerNorm`.

ATen's LayerNorm dispatches a sequence of small kernels for mean / var /
normalize / affine (in fwd) and an even worse pattern in bwd. On Hiera-sized
shapes (N rows from ~640 to 40k, D from 96 to 1152) that adds up: ~7% of
optimised step time on 4090.

This file provides a single-pass row-parallel Triton implementation that:
  - reads a row once and computes mean+rstd+affine in one kernel,
  - in bwd, also computes the per-row partial reductions in one pass
    AND emits the partial dW / dB tiles for a second small reduction.

Drop-in usage:
    from hiera_optim.kernels.layernorm import FusedLayerNorm
    ln = FusedLayerNorm(dim, eps=1e-6).cuda().to(dtype)
    y = ln(x)
"""
from __future__ import annotations

import torch
import torch.nn as nn
import triton
import triton.language as tl


def _heuristic_warps(D: int) -> int:
    """Pick num_warps for a row-parallel LN kernel given the row width D."""
    if D <= 128:
        return 2
    if D <= 512:
        return 4
    if D <= 1536:
        return 8
    return 16


def _block_d(D: int) -> int:
    """Pick BLOCK_D >= D, rounded to the next pow-2 (Triton arange requirement)."""
    return max(triton.next_power_of_2(D), 16)


# ---------------------------------------------------------------------------
# Forward
# ---------------------------------------------------------------------------

@triton.jit
def _ln_fwd_kernel(
    X_ptr,                  # [M, D]
    Y_ptr,                  # [M, D] output
    W_ptr,                  # [D]
    B_ptr,                  # [D]
    Mean_ptr,               # [M] saved for bwd
    Rstd_ptr,               # [M]
    stride_xm, stride_xd,
    stride_ym, stride_yd,
    eps,
    M: tl.constexpr,
    D: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    row = tl.program_id(0)
    if row >= M:
        return

    cols = tl.arange(0, BLOCK_D)
    mask = cols < D

    x_ptrs = X_ptr + row * stride_xm + cols * stride_xd
    x = tl.load(x_ptrs, mask=mask, other=0.0).to(tl.float32)

    # Welford-style single-pass: actually a simple mean then variance is fine
    # because the row fits in registers (BLOCK_D >= D guaranteed by tuner).
    mean = tl.sum(x, axis=0) / D
    xm = tl.where(mask, x - mean, 0.0)
    var = tl.sum(xm * xm, axis=0) / D
    rstd = 1.0 / tl.sqrt(var + eps)

    w = tl.load(W_ptr + cols, mask=mask, other=1.0).to(tl.float32)
    b = tl.load(B_ptr + cols, mask=mask, other=0.0).to(tl.float32)
    y = (xm * rstd) * w + b

    y_ptrs = Y_ptr + row * stride_ym + cols * stride_yd
    tl.store(y_ptrs, y.to(Y_ptr.dtype.element_ty), mask=mask)
    tl.store(Mean_ptr + row, mean)
    tl.store(Rstd_ptr + row, rstd)


# ---------------------------------------------------------------------------
# Backward: dX in one kernel, partial dW/dB in a second pass
# ---------------------------------------------------------------------------

@triton.jit
def _ln_bwd_dx_kernel(
    DY_ptr,                 # [M, D]
    X_ptr,                  # [M, D]
    DX_ptr,                 # [M, D] output
    W_ptr,                  # [D]
    Mean_ptr,               # [M]
    Rstd_ptr,               # [M]
    DW_partial_ptr,         # [M, D] partial dW (per-row gW * (x-mean)*rstd)
    DB_partial_ptr,         # [M, D] partial dB (per-row gW)
    stride_dyM, stride_dyD,
    stride_xM, stride_xD,
    stride_dxM, stride_dxD,
    stride_pM, stride_pD,
    M: tl.constexpr,
    D: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    row = tl.program_id(0)
    if row >= M:
        return

    cols = tl.arange(0, BLOCK_D)
    mask = cols < D
    D_f: tl.constexpr = D + 0.0   # constexpr float

    dy = tl.load(DY_ptr + row * stride_dyM + cols * stride_dyD, mask=mask, other=0.0).to(tl.float32)
    x  = tl.load(X_ptr  + row * stride_xM  + cols * stride_xD,  mask=mask, other=0.0).to(tl.float32)
    w  = tl.load(W_ptr + cols, mask=mask, other=1.0).to(tl.float32)
    mean = tl.load(Mean_ptr + row).to(tl.float32)
    rstd = tl.load(Rstd_ptr + row).to(tl.float32)

    xhat = (x - mean) * rstd               # normalised input
    gxhat = dy * w                         # d(loss)/d(xhat)

    # Standard LayerNorm bwd formula:
    # dx = (1/D) * rstd * ( D*gxhat - sum(gxhat) - xhat * sum(gxhat * xhat) )
    sum_g = tl.sum(tl.where(mask, gxhat, 0.0), axis=0)
    sum_g_xhat = tl.sum(tl.where(mask, gxhat * xhat, 0.0), axis=0)
    dx = (gxhat - (sum_g + xhat * sum_g_xhat) / D_f) * rstd

    tl.store(DX_ptr + row * stride_dxM + cols * stride_dxD, dx.to(DX_ptr.dtype.element_ty), mask=mask)
    # Partial dW / dB (per-row contribution). Reduced over rows in a second pass.
    tl.store(DW_partial_ptr + row * stride_pM + cols * stride_pD,
             (dy * xhat).to(DW_partial_ptr.dtype.element_ty), mask=mask)
    tl.store(DB_partial_ptr + row * stride_pM + cols * stride_pD,
             dy.to(DB_partial_ptr.dtype.element_ty), mask=mask)


# ---------------------------------------------------------------------------
# Autograd glue
# ---------------------------------------------------------------------------

class _FusedLayerNorm(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor, eps: float):
        assert x.is_cuda
        orig_shape = x.shape
        D = orig_shape[-1]
        x2 = x.reshape(-1, D).contiguous()
        M = x2.shape[0]

        y = torch.empty_like(x2)
        mean = torch.empty(M, device=x.device, dtype=torch.float32)
        rstd = torch.empty(M, device=x.device, dtype=torch.float32)

        BLOCK_D = _block_d(D)
        num_warps = _heuristic_warps(D)
        _ln_fwd_kernel[(M,)](
            x2, y, weight, bias, mean, rstd,
            x2.stride(0), x2.stride(1),
            y.stride(0), y.stride(1),
            eps,
            M=M, D=D,
            BLOCK_D=BLOCK_D,
            num_warps=num_warps,
        )
        ctx.save_for_backward(x2, weight, mean, rstd)
        ctx.orig_shape = orig_shape
        ctx.eps = eps
        return y.reshape(orig_shape)

    @staticmethod
    def backward(ctx, grad_y: torch.Tensor):
        x2, weight, mean, rstd = ctx.saved_tensors
        D = x2.shape[1]
        M = x2.shape[0]
        gy = grad_y.reshape(M, D).contiguous()

        dx = torch.empty_like(x2)
        # Per-row partials, fp32 to avoid bf16 reduction-of-many-rows precision loss
        dw_partial = torch.empty(M, D, device=x2.device, dtype=torch.float32)
        db_partial = torch.empty(M, D, device=x2.device, dtype=torch.float32)

        BLOCK_D = _block_d(D)
        num_warps = _heuristic_warps(D)
        _ln_bwd_dx_kernel[(M,)](
            gy, x2, dx, weight, mean, rstd, dw_partial, db_partial,
            gy.stride(0), gy.stride(1),
            x2.stride(0), x2.stride(1),
            dx.stride(0), dx.stride(1),
            dw_partial.stride(0), dw_partial.stride(1),
            M=M, D=D,
            BLOCK_D=BLOCK_D,
            num_warps=num_warps,
        )

        # Reduce per-row partials → [D] (let ATen handle this — it's a fast reduction)
        dweight = dw_partial.sum(dim=0).to(weight.dtype)
        dbias   = db_partial.sum(dim=0).to(weight.dtype)

        return dx.reshape(ctx.orig_shape), dweight, dbias, None


def fused_layernorm(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float = 1e-5,
) -> torch.Tensor:
    return _FusedLayerNorm.apply(x, weight, bias, eps)


class FusedLayerNorm(nn.Module):
    """Drop-in `nn.LayerNorm` replacement using the fused Triton kernel.

    Same constructor signature as `nn.LayerNorm`. Constraints: works on
    `normalized_shape == (D,)` (single trailing dim); doesn't support
    `elementwise_affine=False` (you almost always want affine).
    """

    def __init__(self, normalized_shape, eps: float = 1e-5, elementwise_affine: bool = True, **_):
        super().__init__()
        if isinstance(normalized_shape, int):
            normalized_shape = (normalized_shape,)
        if len(normalized_shape) != 1:
            raise NotImplementedError(
                "FusedLayerNorm only handles trailing-dim normalisation (D,)"
            )
        self.normalized_shape = tuple(normalized_shape)
        self.eps = eps
        if not elementwise_affine:
            raise NotImplementedError("elementwise_affine=False not supported")
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return fused_layernorm(x, self.weight, self.bias, self.eps)

    def extra_repr(self) -> str:
        return f"{self.normalized_shape[0]}, eps={self.eps}, elementwise_affine=True"


@torch.no_grad()
def copy_layernorm_weights(fused: FusedLayerNorm, orig: nn.LayerNorm) -> None:
    fused.weight.copy_(orig.weight)
    fused.bias.copy_(orig.bias)
    fused.eps = orig.eps
