"""Triton kernels.

These are pure shape-parametric kernels with no model dependencies. Each
provides a PyTorch reference implementation alongside the Triton kernel for
correctness testing.

Bundled:
  - mask_gather: Triton mask-unit gather. Correct, but `torch.gather` is
    faster at the shapes we tested — kept for fusion experiments.
  - flash_qpool: Triton fused Q-pool + FlashAttention. Correct, but loses
    to PyTorch's flash on RTX 4090 short-seq workloads. May be useful on
    Hopper with hand-tuned TMA paths.
"""
from .mask_gather import gather_mu_groups_triton, keep_idx_from_bool_mask
from .flash_qpool import flash_qpool_attention, qpool_attention_ref

__all__ = [
    "gather_mu_groups_triton",
    "keep_idx_from_bool_mask",
    "flash_qpool_attention",
    "qpool_attention_ref",
]
