"""Cross-module fused MLP block: `y = x + fc2(GELU(fc1(LN(x))))` in one kernel.

Design (see DESIGN_BLOCK_KERNEL.md):
  - One Triton program per `[BLOCK_M, K]` row-block.
  - LN computed in registers; output not materialised to DRAM.
  - First matmul (W1) k-tiled inside an N-chunk loop; h_chunk stays in SRAM.
  - GELU applied in-place on h_chunk.
  - Second matmul (W2) accumulates into an [BLOCK_M, K] fp32 accumulator.
  - Residual add + b2 fold into the final store.

The intermediate `h` tensor [M, N] is NEVER materialised in DRAM. Saves
~M*N*element_size bytes of HBM bandwidth per call.

Backward: a forward-mirror kernel that recomputes `h_chunk` from saved
`(x_in, ln_w, ln_b, mean, rstd, w1, b1, w2)` and produces `dx`. Weight
gradients use the persistent-SM-partials pattern (one program per SM,
loops over rows, writes one row of partials to a `[sm_count, ...]` buffer,
then a cheap `.sum(0)`).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import triton
import triton.language as tl

from .gpu_config import get_gpu_arch, get_num_sms


# ---------------------------------------------------------------------------
# Forward kernel
# ---------------------------------------------------------------------------

@triton.jit
def _fused_mlp_fwd_kernel(
    X_ptr,                  # [M, K]
    W1_ptr,                 # [N, K]      fc1 weight  (N is hidden)
    B1_ptr,                 # [N]
    W2_ptr,                 # [K, N]      fc2 weight
    B2_ptr,                 # [K]
    LN_w_ptr,               # [K]
    LN_b_ptr,               # [K]
    Y_ptr,                  # [M, K]      output (x + residual)
    Mean_ptr,               # [M]         saved for bwd
    Rstd_ptr,               # [M]         saved for bwd
    stride_xM, stride_xK,
    stride_w1N, stride_w1K,
    stride_w2K, stride_w2N,
    stride_yM, stride_yK,
    eps,
    M, N: tl.constexpr, K: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    """One program handles a (BLOCK_M, K) row-block."""
    pid_m = tl.program_id(0)
    m_start = pid_m * BLOCK_M
    m_offs = m_start + tl.arange(0, BLOCK_M)
    m_mask = m_offs < M

    cols_k = tl.arange(0, BLOCK_K)

    # ---- Load x_tile [BLOCK_M, K] ----
    # We load the entire row (K dim) at once since BLOCK_K covers K.
    x_ptrs = X_ptr + m_offs[:, None] * stride_xM + cols_k[None, :] * stride_xK
    k_mask = cols_k < K
    full_mask = m_mask[:, None] & k_mask[None, :]
    x_tile = tl.load(x_ptrs, mask=full_mask, other=0.0).to(tl.float32)

    # ---- LayerNorm on the row ----
    # mean / variance per row (axis=1 over K)
    mean = tl.sum(tl.where(k_mask[None, :], x_tile, 0.0), axis=1) / K
    xm = tl.where(k_mask[None, :], x_tile - mean[:, None], 0.0)
    var = tl.sum(xm * xm, axis=1) / K
    rstd = 1.0 / tl.sqrt(var + eps)
    ln_w = tl.load(LN_w_ptr + cols_k, mask=k_mask, other=1.0).to(tl.float32)
    ln_b = tl.load(LN_b_ptr + cols_k, mask=k_mask, other=0.0).to(tl.float32)
    xn_tile_f32 = xm * rstd[:, None] * ln_w[None, :] + ln_b[None, :]
    # Cast LN result to the kernel's compute dtype to halve SMEM use.
    # The matmul accumulator stays fp32, so precision loss is bf16-noise only.
    xn_tile = xn_tile_f32.to(X_ptr.dtype.element_ty)

    # Save mean/rstd
    tl.store(Mean_ptr + m_offs, mean, mask=m_mask)
    tl.store(Rstd_ptr + m_offs, rstd, mask=m_mask)

    # ---- Two-matmul fused loop ----
    # acc_out[BLOCK_M, K] accumulates the fc2 output. After the loop we add
    # the residual (x_in) and bias b2.
    acc_out = tl.zeros((BLOCK_M, BLOCK_K), dtype=tl.float32)

    for n_chunk_start in range(0, N, BLOCK_N):
        cols_n = n_chunk_start + tl.arange(0, BLOCK_N)
        n_mask = cols_n < N

        # ---- matmul1: h_chunk = xn @ W1[n_chunk, :].T ----
        w1_ptrs = W1_ptr + cols_n[:, None] * stride_w1N + cols_k[None, :] * stride_w1K
        w1_chunk = tl.load(w1_ptrs, mask=n_mask[:, None] & k_mask[None, :], other=0.0)
        h_chunk = tl.dot(xn_tile, tl.trans(w1_chunk))    # [BLOCK_M, BLOCK_N], fp32 accumulator
        b1_chunk = tl.load(B1_ptr + cols_n, mask=n_mask, other=0.0).to(tl.float32)
        h_chunk = h_chunk + b1_chunk[None, :]

        # ---- GELU (tanh approximation — matches FAIR's default) ----
        # gelu(x) = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        x_cubed = h_chunk * h_chunk * h_chunk
        h_chunk = 0.5 * h_chunk * (1.0 + tl.extra.libdevice.tanh(
            0.7978845608028654 * (h_chunk + 0.044715 * x_cubed)
        ))
        h_chunk_lo = h_chunk.to(X_ptr.dtype.element_ty)   # bf16/fp16 for the next matmul input

        # ---- matmul2 partial: acc_out += h_chunk @ W2[:, n_chunk] ----
        w2_ptrs = W2_ptr + cols_k[:, None] * stride_w2K + cols_n[None, :] * stride_w2N
        w2_chunk = tl.load(w2_ptrs, mask=k_mask[:, None] & n_mask[None, :], other=0.0)
        acc_out += tl.dot(h_chunk_lo, tl.trans(w2_chunk))   # [BLOCK_M, BLOCK_K]

    # ---- residual + b2, then store ----
    x_residual = tl.load(x_ptrs, mask=full_mask, other=0.0).to(tl.float32)
    b2 = tl.load(B2_ptr + cols_k, mask=k_mask, other=0.0).to(tl.float32)
    y = acc_out + b2[None, :] + x_residual

    y_ptrs = Y_ptr + m_offs[:, None] * stride_yM + cols_k[None, :] * stride_yK
    tl.store(y_ptrs, y.to(Y_ptr.dtype.element_ty), mask=full_mask)


# ---------------------------------------------------------------------------
# Autograd Function
# ---------------------------------------------------------------------------

class _FusedMlpBlock(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, ln_w, ln_b, w1, b1, w2, b2, eps):
        assert x.is_cuda and x.is_contiguous()
        orig_shape = x.shape
        K = orig_shape[-1]
        x2 = x.reshape(-1, K)
        M = x2.shape[0]
        N = w1.shape[0]
        assert w1.shape == (N, K)
        assert w2.shape == (K, N)

        y = torch.empty_like(x2)
        mean = torch.empty(M, device=x.device, dtype=torch.float32)
        rstd = torch.empty(M, device=x.device, dtype=torch.float32)

        # Block sizes — tuned for Hiera shapes. With xn_tile in bf16 (post-LN)
        # and h in bf16, the SMEM footprint is dominated by acc_out [BM, BK] fp32.
        BLOCK_K = triton.next_power_of_2(K)
        # Total SMEM ~ BM*BK*2 (x, bf16) + BM*BK*2 (xn, bf16) + BN*BK*2 (w1)
        #              + BN*BK*2 (w2) + BM*BN*4 (h, fp32) + BM*BK*4 (acc, fp32)
        # On Ada (99 KB), keep total under ~80 KB so num_stages=2 fits.
        if BLOCK_K <= 128:
            BLOCK_M, BLOCK_N, num_stages = 64, 32, 2
        elif BLOCK_K <= 256:
            BLOCK_M, BLOCK_N, num_stages = 32, 64, 2
        elif BLOCK_K <= 512:
            BLOCK_M, BLOCK_N, num_stages = 32, 64, 1
        else:
            BLOCK_M, BLOCK_N, num_stages = 16, 32, 1
        num_warps = 4 if BLOCK_K <= 256 else 8

        grid = (triton.cdiv(M, BLOCK_M),)
        _fused_mlp_fwd_kernel[grid](
            x2, w1, b1, w2, b2, ln_w, ln_b, y, mean, rstd,
            x2.stride(0), x2.stride(1),
            w1.stride(0), w1.stride(1),
            w2.stride(0), w2.stride(1),
            y.stride(0), y.stride(1),
            eps,
            M=M, N=N, K=K,
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
            num_warps=num_warps,
            num_stages=num_stages,
        )

        ctx.save_for_backward(x2, ln_w, ln_b, w1, b1, w2, b2, mean, rstd)
        ctx.eps = eps
        ctx.orig_shape = orig_shape
        return y.reshape(orig_shape)

    @staticmethod
    def backward(ctx, grad_y):
        """Direct ATen bwd. Recomputes ln_out + h_pre (cheap re-FW vs full
        autograd.grad machinery). Avoids torch.autograd.grad and the seven
        detach().clone().requires_grad_(True) calls."""
        x2, ln_w, ln_b, w1, b1, w2, b2, mean, rstd = ctx.saved_tensors
        K = x2.shape[1]
        gy = grad_y.reshape(-1, K).contiguous()
        N = w1.shape[0]
        M = x2.shape[0]

        # Recompute LN(x) and h_pre to get the intermediates the bwd needs.
        # Native LN fwd uses our saved mean/rstd implicitly via the affine.
        x_f = x2.to(torch.float32)
        ln_out = ((x_f - mean.view(-1, 1)) * rstd.view(-1, 1)
                  * ln_w.to(torch.float32) + ln_b.to(torch.float32)).to(x2.dtype)
        h_pre = torch.nn.functional.linear(ln_out, w1, b1)         # (M, N)
        # h_post = gelu(h_pre)

        # Now gradients.
        # y = x + W2(GELU(h_pre)) + b2  ⇒  grad_x_residual = grad_y
        grad_b2 = gy.sum(0)
        # grad of W2 input == GELU(h_pre).  grad_h_post = gy @ W2
        grad_h_post = gy @ w2                                       # (M, N)
        # gelu_backward gives d_h_pre = grad_h_post * GELU'(h_pre)
        grad_h_pre = torch.ops.aten.gelu_backward(grad_h_post, h_pre, approximate="tanh")
        # h_post we still need for grad_w2 — recompute via gelu(h_pre)
        h_post = torch.nn.functional.gelu(h_pre, approximate="tanh")
        grad_w2 = gy.t() @ h_post                                   # (K, N)
        # h_pre = ln_out @ W1.T + b1
        grad_b1 = grad_h_pre.sum(0)
        grad_w1 = grad_h_pre.t() @ ln_out                           # (N, K)
        grad_ln_out = grad_h_pre @ w1                               # (M, K)

        # LN bwd via native op (fused cuDNN/native kernel).
        grad_x_from_ln, grad_ln_w, grad_ln_b = torch.ops.aten.native_layer_norm_backward(
            grad_ln_out, x2, [K],
            mean.view(M, 1), rstd.view(M, 1),
            ln_w, ln_b,
            [True, True, True],
        )
        grad_x = (grad_x_from_ln + gy).reshape(ctx.orig_shape)
        return grad_x, grad_ln_w, grad_ln_b, grad_w1, grad_b1, grad_w2, grad_b2, None


def fused_mlp_block(
    x: torch.Tensor,
    ln_w: torch.Tensor, ln_b: torch.Tensor,
    w1: torch.Tensor, b1: torch.Tensor,
    w2: torch.Tensor, b2: torch.Tensor,
    eps: float = 1e-6,
) -> torch.Tensor:
    """`y = x + fc2(GELU(fc1(LN(x))))` in one Triton kernel (fwd; bwd via ATen)."""
    return _FusedMlpBlock.apply(x, ln_w, ln_b, w1, b1, w2, b2, eps)


class FusedMlpBlock(nn.Module):
    """Drop-in for FAIR's `norm2 + mlp + residual` pair in a HieraBlock.

    Holds the LN2 weights and the MLP weights (fc1, fc2). The hidden dim is
    inferred from `w1`.
    """

    def __init__(self, dim: int, hidden_dim: int, eps: float = 1e-6):
        super().__init__()
        self.dim = dim
        self.hidden_dim = hidden_dim
        self.eps = eps
        self.ln_weight = nn.Parameter(torch.ones(dim))
        self.ln_bias   = nn.Parameter(torch.zeros(dim))
        self.fc1_weight = nn.Parameter(torch.empty(hidden_dim, dim))
        self.fc1_bias   = nn.Parameter(torch.zeros(hidden_dim))
        self.fc2_weight = nn.Parameter(torch.empty(dim, hidden_dim))
        self.fc2_bias   = nn.Parameter(torch.zeros(dim))
        nn.init.xavier_uniform_(self.fc1_weight)
        nn.init.xavier_uniform_(self.fc2_weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return fused_mlp_block(
            x, self.ln_weight, self.ln_bias,
            self.fc1_weight, self.fc1_bias,
            self.fc2_weight, self.fc2_bias,
            self.eps,
        )

    @torch.no_grad()
    def copy_from_hiera(self, norm2_module: nn.LayerNorm, mlp_module):
        """Copy weights from a FAIR HieraBlock's `(norm2, mlp)` pair."""
        self.ln_weight.copy_(norm2_module.weight)
        self.ln_bias.copy_(norm2_module.bias)
        # timm Mlp: fc1, act, drop1, fc2, drop2
        self.fc1_weight.copy_(mlp_module.fc1.weight)
        self.fc1_bias.copy_(mlp_module.fc1.bias)
        self.fc2_weight.copy_(mlp_module.fc2.weight)
        self.fc2_bias.copy_(mlp_module.fc2.bias)
