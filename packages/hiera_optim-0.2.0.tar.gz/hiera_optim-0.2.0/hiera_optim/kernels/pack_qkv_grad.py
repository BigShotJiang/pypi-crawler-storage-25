"""Fast Triton pack: (3, B*nw, H, T, D) → (B, N, 3*dim_out).

ATen's `torch.stack + .view + .permute + .contiguous` for this shape costs
~150 us at Hiera-Base stage 0 (B=128). It writes the data twice (stack +
permute-contig). This kernel writes once.

We feed the result into cuBLAS for the wide grad_qkv_w matmul. The
alternative — a fully fused matmul that reads grad_q/k/v in 4D and
accumulates grad_qkv_w directly — needs split-K + atomic partials to be
worthwhile at this output size on a 128-SM device, which is a larger
project. The pack kernel is the 80%-solution that lands today.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _pack_qkv_grad_kernel(
    GQ_ptr, GK_ptr, GV_ptr,       # [B*nw, H, T, head_dim]
    Out_ptr,                       # [B, N, 3*dim_out]
    stride_gB, stride_gH, stride_gT, stride_gD,
    stride_oB, stride_oN, stride_oD,
    B, nw, T,
    heads: tl.constexpr,
    head_dim: tl.constexpr,
    dim_out: tl.constexpr,
    BLOCK_T: tl.constexpr,        # tokens per program along T
    BLOCK_HD: tl.constexpr,
):
    """One program per (b, w, t-tile). Writes BLOCK_T tokens × 3*dim_out values."""
    pid = tl.program_id(0)
    t_tiles = tl.cdiv(T, BLOCK_T)
    pid_b = pid // (nw * t_tiles)
    rem = pid - pid_b * (nw * t_tiles)
    pid_w = rem // t_tiles
    pid_tile = rem - pid_w * t_tiles

    out_b = pid_b * nw + pid_w  # index into grad_q/k/v
    cols_hd = tl.arange(0, BLOCK_HD)
    hd_mask = cols_hd < head_dim

    t_offs = pid_tile * BLOCK_T + tl.arange(0, BLOCK_T)
    t_mask = t_offs < T
    n_offs = t_offs * nw + pid_w

    for h in tl.static_range(heads):
        # Source: grad_X[out_b, h, t_offs, :]  -> [BLOCK_T, head_dim]
        src_off = (out_b * stride_gB + h * stride_gH
                   + t_offs[:, None] * stride_gT
                   + cols_hd[None, :] * stride_gD)
        src_mask = t_mask[:, None] & hd_mask[None, :]
        dst_off_base = (pid_b * stride_oB
                        + n_offs[:, None] * stride_oN
                        + (h * head_dim + cols_hd[None, :]) * stride_oD)

        gq = tl.load(GQ_ptr + src_off, mask=src_mask, other=0.0)
        tl.store(Out_ptr + dst_off_base, gq, mask=src_mask)

        gk = tl.load(GK_ptr + src_off, mask=src_mask, other=0.0)
        tl.store(Out_ptr + dst_off_base + dim_out * stride_oD, gk, mask=src_mask)

        gv = tl.load(GV_ptr + src_off, mask=src_mask, other=0.0)
        tl.store(Out_ptr + dst_off_base + 2 * dim_out * stride_oD, gv, mask=src_mask)


def pack_qkv_grad(
    grad_q: torch.Tensor,            # (B*nw, H, T, head_dim)
    grad_k: torch.Tensor,
    grad_v: torch.Tensor,
    nw: int,
) -> torch.Tensor:
    """Pack 4D grad tensors into the packed (B, N, 3*dim_out) layout cuBLAS expects."""
    Bnw, heads, T, head_dim = grad_q.shape
    B = Bnw // nw
    dim_out = heads * head_dim
    N = T * nw
    out = torch.empty(B, N, 3 * dim_out, device=grad_q.device, dtype=grad_q.dtype)

    BLOCK_HD = triton.next_power_of_2(head_dim)
    BLOCK_T = min(triton.next_power_of_2(T), 32)
    t_tiles = (T + BLOCK_T - 1) // BLOCK_T
    grid = (B * nw * t_tiles,)
    _pack_qkv_grad_kernel[grid](
        grad_q, grad_k, grad_v, out,
        grad_q.stride(0), grad_q.stride(1), grad_q.stride(2), grad_q.stride(3),
        out.stride(0), out.stride(1), out.stride(2),
        B, nw, T,
        heads=heads, head_dim=head_dim, dim_out=dim_out,
        BLOCK_T=BLOCK_T, BLOCK_HD=BLOCK_HD,
        num_warps=4,
    )
    return out
