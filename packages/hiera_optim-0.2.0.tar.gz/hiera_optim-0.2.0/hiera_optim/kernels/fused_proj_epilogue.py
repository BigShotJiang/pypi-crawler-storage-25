"""Fused post-attention epilogue: `reshape(z) → proj_linear → +residual` in one kernel.

Multi-head safe. PyTorch's MaskUnitAttention does:

    z = flash_attn(q, k, v)                    # (B*nw, H, T, head_dim)
    z = z.view(B, nw, H, T, head_dim).permute(0, 3, 1, 2, 4)
                                               # → (B, T, nw, H, head_dim)
    z = z.reshape(B, N, dim_out).contiguous()  # dim_out = H * head_dim
    o = F.linear(z, proj_w, proj_b)
    out = x_in + o

The proj matmul is `out[b, n, j] = sum_i z[b, n, i] * proj_w[j, i] + proj_b[j]`.

Decomposing the i sum across heads: `out[b, n, j] = sum_h sum_{d in head} z[b*nw+w, h, t, d] * proj_w[j, h*head_dim + d] + proj_b[j]`,
where `(t, w) = (n // nw, n % nw)`.

Per program (one per (b, w)): loop over heads h, load z[b*nw+w, h, :, :] and
the (head_dim, dim_out) slice of proj_w, accumulate into an out_tile.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _fused_proj_epilogue_kernel(
    Z_ptr,                  # [B*nw, H, T, head_dim]
    Proj_w_ptr,             # [dim_out, dim_out]   indexed as [j, h*head_dim + d]
    Proj_b_ptr,             # [dim_out]
    X_ptr,                  # [B, N, dim_out]      residual
    Out_ptr,                # [B, N, dim_out]
    stride_zB, stride_zH, stride_zT, stride_zD,
    stride_pO, stride_pI,
    stride_xB, stride_xN, stride_xD,
    stride_oB, stride_oN, stride_oD,
    B, nw, T, dim_out: tl.constexpr,
    heads: tl.constexpr, head_dim: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_D: tl.constexpr,       # >= dim_out, power-of-2
    BLOCK_HD: tl.constexpr,      # >= head_dim, power-of-2
):
    """One program per (b, w). Handles T tokens of mask-unit w in sample b."""
    pid = tl.program_id(0)
    pid_b = pid // nw
    pid_w = pid - pid_b * nw

    cols_d = tl.arange(0, BLOCK_D)
    d_mask = cols_d < dim_out
    cols_hd = tl.arange(0, BLOCK_HD)
    hd_mask = cols_hd < head_dim

    proj_b = tl.load(Proj_b_ptr + cols_d, mask=d_mask, other=0.0).to(tl.float32)
    out_b_idx = pid_b * nw + pid_w

    for t_start in range(0, T, BLOCK_T):
        t_offs = t_start + tl.arange(0, BLOCK_T)
        t_mask = t_offs < T

        # Accumulator over all heads
        out_tile = tl.zeros((BLOCK_T, BLOCK_D), dtype=tl.float32)

        for h in tl.static_range(heads):
            # z_chunk = z[out_b_idx, h, t_offs, :]  → [BLOCK_T, head_dim]
            z_ptrs = (Z_ptr
                      + out_b_idx * stride_zB
                      + h * stride_zH
                      + t_offs[:, None] * stride_zT
                      + cols_hd[None, :] * stride_zD)
            z_chunk = tl.load(z_ptrs, mask=t_mask[:, None] & hd_mask[None, :], other=0.0)

            # w_slice = proj_w[:, h*head_dim : (h+1)*head_dim]
            # Layout: w_slice[j, d] = proj_w[j, h*head_dim + d], shape [dim_out, head_dim]
            w_ptrs = (Proj_w_ptr
                      + cols_d[:, None] * stride_pO
                      + (h * head_dim + cols_hd[None, :]) * stride_pI)
            w_slice = tl.load(w_ptrs, mask=d_mask[:, None] & hd_mask[None, :], other=0.0)

            # out_tile += z_chunk @ w_slice.T   → [BLOCK_T, dim_out]
            out_tile = tl.dot(z_chunk, tl.trans(w_slice), out_tile)

        out_tile = out_tile + proj_b[None, :]

        # Residual add
        n_offs = t_offs * nw + pid_w
        x_ptrs = (X_ptr
                  + pid_b * stride_xB
                  + n_offs[:, None] * stride_xN
                  + cols_d[None, :] * stride_xD)
        x_res = tl.load(x_ptrs, mask=t_mask[:, None] & d_mask[None, :], other=0.0).to(tl.float32)
        out_val = out_tile + x_res

        out_ptrs = (Out_ptr
                    + pid_b * stride_oB
                    + n_offs[:, None] * stride_oN
                    + cols_d[None, :] * stride_oD)
        tl.store(out_ptrs, out_val.to(Out_ptr.dtype.element_ty),
                 mask=t_mask[:, None] & d_mask[None, :])


def fused_proj_epilogue(
    z: torch.Tensor,                # (B*nw, heads, T, head_dim)
    proj_w: torch.Tensor,           # (dim_out, dim_out)
    proj_b: torch.Tensor,           # (dim_out,)
    x_residual: torch.Tensor,       # (B, N, dim_out)
    nw: int,
) -> torch.Tensor:
    """Out = x_residual + proj(reshape(z))."""
    assert z.is_cuda and x_residual.is_cuda
    Bnw, heads, T, head_dim = z.shape
    B = Bnw // nw
    dim_out = heads * head_dim
    assert proj_w.shape == (dim_out, dim_out)
    N = T * nw
    assert x_residual.shape == (B, N, dim_out)

    out = torch.empty_like(x_residual)
    BLOCK_T = min(triton.next_power_of_2(T), 32)
    BLOCK_D = triton.next_power_of_2(dim_out)
    BLOCK_HD = triton.next_power_of_2(head_dim)
    num_warps = 4 if BLOCK_D <= 256 else 8

    grid = (B * nw,)
    _fused_proj_epilogue_kernel[grid](
        z, proj_w, proj_b, x_residual, out,
        z.stride(0), z.stride(1), z.stride(2), z.stride(3),
        proj_w.stride(0), proj_w.stride(1),
        x_residual.stride(0), x_residual.stride(1), x_residual.stride(2),
        out.stride(0), out.stride(1), out.stride(2),
        B, nw, T, dim_out, heads, head_dim,
        BLOCK_T=BLOCK_T, BLOCK_D=BLOCK_D, BLOCK_HD=BLOCK_HD,
        num_warps=num_warps,
        num_stages=1,
    )
    return out


# Backwards-compat alias for the prior h1 path
fused_proj_epilogue_h1 = fused_proj_epilogue
