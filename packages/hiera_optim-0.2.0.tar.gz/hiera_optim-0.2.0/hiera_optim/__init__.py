"""hiera_optim — training-throughput optimisations for FAIR's Hiera.

Quick start::

    from models.hiera import mae_hiera_base_224         # FAIR Hiera
    from hiera_optim import optimize

    model = mae_hiera_base_224(pretrained=False, in_chans=8)
    optimize(model)                                      # in-place
    # optionally: model = torch.compile(model, mode="default", dynamic=False)

What `optimize()` does:
  1. Swaps every `MaskUnitAttention` for a FlashAttention/cuDNN-friendly
     4-D variant (`MaskUnitAttentionFast`). Restores math-fallback SDPA to
     fused kernel paths — 5-12× per-call attention speedup.
  2. Replaces the boolean `x[mask.tile(...)]` and `x_dec[mask] = ...`
     indexing patterns with explicit `torch.gather` / `scatter_`. Removes
     the `aten::nonzero` graph break (compile-friendly).

Optional add-ons (opt-in, not invoked by default):
  - `optimize(model, sdpa_backend="auto" | "cudnn" | ...)`: pin the SDPA
    backend per-block. Sometimes helps, sometimes hurts — see RESULTS.md.
  - `enable_stage_checkpointing(model, stages=(2,))`: trade compute for
    activation memory at chosen stages. OOM lever, not a throughput tool.
"""
from .patch import optimize, swap_mask_unit_attention, recommended_backend, make_mae_mask, MAEStepInputs

# Lightning Callback for the static-buffer pattern. Imported lazily so the
# package still loads without lightning installed.
try:
    from .lightning import MAEStaticInputsCallback, feed_batch  # noqa: F401
    _LIGHTNING_AVAILABLE = True
except ImportError:
    _LIGHTNING_AVAILABLE = False
from .attention import MaskUnitAttentionFast, BACKEND_NAMES
from .checkpoint import enable_stage_checkpointing, disable_stage_checkpointing
from .adapters import HieraAdapter, get_hiera_adapter, auto_detect

# FP8 helpers — import lazily on use; module loads cleanly even if TE absent.
try:
    from .fp8 import fp8_optimize, fp8_autocast  # noqa: F401
    _FP8_AVAILABLE = True
except ImportError:
    _FP8_AVAILABLE = False

__version__ = "0.2.0"

__all__ = [
    "optimize",
    "swap_mask_unit_attention",
    "recommended_backend",
    "make_mae_mask",
    "MAEStepInputs",
    "MaskUnitAttentionFast",
    "BACKEND_NAMES",
    "enable_stage_checkpointing",
    "disable_stage_checkpointing",
    "HieraAdapter",
    "get_hiera_adapter",
    "auto_detect",
]
if _FP8_AVAILABLE:
    __all__ += ["fp8_optimize", "fp8_autocast"]
if _LIGHTNING_AVAILABLE:
    __all__ += ["MAEStaticInputsCallback", "feed_batch"]
