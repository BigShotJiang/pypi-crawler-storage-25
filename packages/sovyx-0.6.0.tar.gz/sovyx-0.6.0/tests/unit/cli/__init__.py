# CLI tests
