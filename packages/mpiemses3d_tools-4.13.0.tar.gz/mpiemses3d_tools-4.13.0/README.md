# mpiemses3d-tools

CLI utilities for [MPIEMSES3D](https://github.com/Nkzono99/mpiemses3d) plasma simulations.

## Installation

```bash
pip install mpiemses3d-tools
```

## Commands

| Command | Description |
|---------|-------------|
| `inp2toml` | Convert Fortran namelist (`plasma.inp`) to TOML format |
| `toml2inp` | Convert `plasma.toml` back to legacy Fortran namelist format |
| `emu` / `emses-unit` | Unit conversion, TOML/input linting, and parameter reference lookup |
| `toml-upgrade` | Upgrade `plasma.toml` from format v1 to v2 |
| `emses-cp` / `cpem` | Copy the mpiemses3D binary to a target directory |
| `mpiemses-codex-plugin` | Register/update the MPIEMSES3D Codex plugin marketplace |

Parameter reference lookup examples:

```bash
emu lint plasma.toml
emu lint plasma.inp --format inp --mpi-size 64
emu describe esorem
emu describe emflag
emu describe species --language en
```

Codex plugin setup:

```bash
mpiemses-codex-plugin install
codex
# Open /plugins, install "MPIEMSES3D Context", then restart Codex.
```

If the Codex CLI is not installed, `mpiemses-codex-plugin install` prints the Codex CLI install and login steps.

## Python API

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml
from mpiemses3d_tools.unit_system import UnitSystem
from mpiemses3d_tools.inp2toml import inp2toml
```
