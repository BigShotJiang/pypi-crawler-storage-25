Lang: [日本語](Customization.md) | [English](Customization.en.md)

# plasma.toml カスタマイズガイド

このガイドでは `plasma.toml` を物理単位で記述し、Python スクリプトで自動生成・カスタマイズする方法を説明します。

---

## 1. `[meta.physical]` による物理単位での記述

`[meta.physical]` テーブルにプラズマ条件を SI 単位で記述し、`emu apply` で正規化単位に変換できます。ソルバは `[meta.physical]` を直接読みません。

### 基本的な使い方

```toml
[meta]
format_version = 2

[meta.unit_conversion]
dx = 0.5        # グリッド間隔 [m]
to_c = 1000     # c_phys / cv_sim

[meta.physical]
density_m3 = 1e7               # プラズマ数密度 [m^-3]
magnetic_field_T = 0.0         # 背景磁場 [T]
particles_per_cell = 40      # 粒子数/セル

[[meta.physical.species]]
label = "electron"
mass_ratio = 1               # 電子質量比
qm_sign = -1
temperature_eV = 10.0           # [eV]
drift_velocity_m_s = -400000.0   # [m/s]

[[meta.physical.species]]
label = "ion"
mass_ratio = 1836.0
qm_sign = 1
temperature_eV = 10.0
drift_velocity_m_s = -400000.0

[[meta.physical.species]]
label = "photoelectron"
mass_ratio = 1
qm_sign = -1
temperature_eV = 2.2
emission_current_density_A_m2 = 4.5e-6  # [A/m^2]

[[meta.physical.conductors]]
group = "sphere"
potential_V = 10.0             # [V]
```

### 変換の実行

```bash
# 変換結果をプレビュー
emu apply plasma.toml --dry-run

# 変換を実行（in-place 更新）
emu apply plasma.toml

# 別ファイルに出力
emu apply plasma.toml -o output.toml
```

`emu apply` は `[meta.physical]` の値を読み取り、対応するシミュレーションパラメータ（`[[species]]` の `wp`, `qm`, `path`, `peth`, `vdri`, `npin` など）を計算して書き込みます。既存のフィールド（`ipahdf`, `injct`, `npr` など）は保持されます。

### 逆変換: シミュレーションパラメータから `[meta.physical]` を生成

既存の `plasma.toml` にシミュレーション値のみがある場合、`emu generate` で `[meta.physical]` を自動生成できます:

```bash
# [meta.physical] を生成（in-place）
emu generate plasma.toml

# 生成結果をプレビュー（JSON 表示）
emu generate plasma.toml --dry-run

# 別ファイルに出力
emu generate plasma.toml -o output.toml
```

既に `[meta.physical]` が存在する場合は、`label` などの既存キーを保持しつつ値を更新します。`inp2toml` でも変換時にデフォルトで `[meta.physical]` が自動生成されます。

### 変換マッピング一覧

詳細は [FormatV2.md](FormatV2.md#metaphysical--物理単位-si-でのプラズマ条件) を参照してください。

---

## 2. `[memo]` によるメタデータの保存

`[memo]` テーブルは任意のキー/値ペアを格納できるフリーフォーム領域です。ソルバは読みません。

Python スクリプトで `plasma.toml` を自動生成する際に、ケースの由来や生成条件を記録する用途に使えます:

```toml
[memo]
family = "lsurface"
description = "Workshop 光電子放出ケース"
created_by = "experiment_generator.py"
solar_zenith_angle_deg = 0.0
sphere_center = [32, 32, 220]
```

---

## 3. Python による `plasma.toml` の自動生成

### 基本ワークフロー: テンプレート + `[meta.physical]`

最もシンプルな方法は、テンプレートとなる `plasma.toml` を用意し、`[meta.physical]` の値だけを Python で書き換えて `emu apply` で変換する方法です:

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

# テンプレートを読み込み
toml = PlasmaToml.load("template.toml")

# 物理パラメータを変更
toml.meta.physical.density_m3 = 1e8
toml.meta.physical.species[0].temperature_eV = 5.0

# 変換を実行
toml.apply_physical()

# 書き出し
toml.write("plasma.toml")
```

### パラメータスキャン

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

base = PlasmaToml.load("template.toml")
for density_m3 in [1e7, 1e8, 1e9]:
    t = base.copy()
    t.meta.physical.density_m3 = density_m3
    t.apply_physical()
    t.write(f"plasma_n{density_m3:.0e}.toml")
```

### `[memo]` を使ったケース管理

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

toml = PlasmaToml.load("template.toml")

# memo にケース情報を記録
toml.apply({
    "memo": {
        "family": "lsurface",
        "density_cc": 10,
        "run_id": "exp_001",
        "created_by": "scan_script.py",
    }
})

# 物理パラメータ設定 + 変換
toml.meta.physical.density_m3 = 10 * 1e6  # 10 cm^-3
toml.apply_physical()
toml.write("plasma.toml")
```

---

## 4. 高度なカスタマイズ: Python API の直接利用

`[meta.physical]` でカバーされない特殊なパラメータを設定する場合や、`plasma.toml` を一から構築する場合には、`PlasmaToml` と `UnitSystem` の API を直接使用できます。

### 属性アクセスによる操作

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml
from mpiemses3d_tools.unit_system import UnitSystem

toml = PlasmaToml.load("plasma.toml")

# 属性スタイルでの読み書き
toml.tmgrid.nx = 256
toml.tmgrid.ny = 256
toml.tmgrid.nz = 512

# SI プロキシで物理値を直接設定
toml.species[0].si.path = 1.5e5   # 物理値 [m/s] → 自動変換
print(toml.species[0].si.path)     # 正規化値 → 物理値 [m/s]

# UnitSystem で手動変換
unit = toml.unit
toml.species[0].wp = unit.f.trans(UnitSystem.plasma_frequency(1e11))
```

### 種の追加

```python
unit = toml.unit
toml.species.append({
    "wp": unit.f.trans(UnitSystem.plasma_frequency(1e11)),
    "qm": -1.0,
    "path": unit.v.trans(UnitSystem.thermal_speed(10.0)),
    "peth": unit.v.trans(UnitSystem.thermal_speed(10.0)),
    "npin": 5242880,
    "inpf": 1,
    "inpb": 1,
    "injct": 1,
    "npr": 524288,
})
```

### 導体の追加

```python
toml.ptcond.objects.append({
    "conductor": "probe",
    "geotype": 3,
    "bdyradius": 0.5,
    "bdycoord": [32.0, 32.0, 100.0],
})
```

### `apply()` による一括差分適用

```python
toml = PlasmaToml.load("template.toml")
toml.apply({
    "tmgrid": {"nx": 256, "ny": 256, "nz": 512, "dt": 0.01},
    "jobcon": {"nstep": 50000},
    "mpi": {"nodes": [4, 4, 8]},
})
toml.write("plasma.toml")
```

### `[meta.physical]` の逆生成

シミュレーションパラメータから `[meta.physical]` を生成できます:

```python
toml = PlasmaToml.load("plasma.toml")

# [meta.physical] を生成（既存の label 等は保持）
toml.generate_physical()
toml.write("plasma.toml")
```

### 物理量の計算ヘルパー

`UnitSystem` には物理量の計算ヘルパーが用意されています:

```python
from mpiemses3d_tools.unit_system import UnitSystem

UnitSystem.plasma_frequency(1e11)          # プラズマ周波数 [rad/s]
UnitSystem.thermal_speed(10.0)             # 熱速度 [m/s] (10 eV)
UnitSystem.debye_length(10.0, 1e11)        # デバイ長 [m]
UnitSystem.cyclotron_frequency(5e-9)       # サイクロトロン周波数 [rad/s]
UnitSystem.larmor_radius(1e5, 5e-9)        # ラーモア半径 [m]
```

---

## 5. 実用例: ワークショップ用ケース生成スクリプト

以下は `[memo]` と `[meta.physical]` を組み合わせて、テンプレートからシミュレーションケースを生成するスクリプトの例です:

```python
#!/usr/bin/env python3
"""Generate simulation cases from a template with parameter variations."""

from mpiemses3d_tools.plasma_toml import PlasmaToml

TEMPLATE = "template.toml"

cases = [
    {"name": "low_density",  "density_cc": 1,   "etemp": 10, "potential_V": 5},
    {"name": "mid_density",  "density_cc": 10,  "etemp": 10, "potential_V": 10},
    {"name": "high_density", "density_cc": 100, "etemp": 10, "potential_V": 20},
]

base = PlasmaToml.load(TEMPLATE)

for case in cases:
    t = base.copy()

    # memo にケース情報を記録
    t.apply({"memo": case})

    # 物理パラメータを設定
    density_m3 = case["density_cc"] * 1e6
    t.meta.physical.density_m3 = density_m3
    for sp in t.meta.physical.species:
        sp.temperature_eV = case["etemp"]

    # 導体電位を更新
    for cond in t.data["meta"]["physical"].get("conductors", []):
        cond["potential_V"] = case["potential_V"]

    # 変換 + 書き出し
    t.apply_physical()
    t.write(f"{case['name']}/plasma.toml")
```
