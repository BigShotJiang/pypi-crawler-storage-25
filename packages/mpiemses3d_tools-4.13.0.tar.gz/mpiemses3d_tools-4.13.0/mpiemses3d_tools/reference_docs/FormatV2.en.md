Lang: [English](FormatV2.en.md) | [日本語](FormatV2.md)

## TOML New Format (format_version = 2)

Setting `format_version = 2` in `[meta]` enables structured input formats.
Full backward compatibility with legacy flat-array format is maintained. New and legacy formats can be mixed in a single file.

```bash
# Convert plasma.inp to format_version 2 TOML (default)
# [meta.physical] is auto-generated
inp2toml plasma.inp

# Disable auto-generation of [meta.physical]
inp2toml plasma.inp --no-generate-physical

# Upgrade existing format_version 1 TOML to 2
toml-upgrade plasma.toml
toml-upgrade plasma.toml -o new.toml
```

---

### `[meta.physical]` — Physical (SI-unit) Plasma Conditions

The `[meta.physical]` table stores plasma conditions in physical SI units. Use `emu apply` to convert them to simulation units and update `[[species]]`, `[plasma]`, etc. Not consumed by the solver.

```bash
# [meta.physical] -> simulation parameters
emu apply plasma.toml              # in-place update
emu apply plasma.toml --dry-run    # preview without writing
emu apply plasma.toml -o out.toml  # write to another file

# simulation parameters -> [meta.physical] (reverse conversion)
emu generate plasma.toml              # in-place generate/update
emu generate plasma.toml --dry-run    # preview as JSON
emu generate plasma.toml -o out.toml  # write to another file
```

`emu generate` is the reverse of `emu apply`. It reads `[[species]]`, `[plasma]`, and `[ptcond.conductor_groups]` simulation values and generates `[meta.physical]` with physical (SI) units. If `[meta.physical]` already exists, it updates the values while preserving existing keys such as `label`.

**Global parameters:**

| Parameter | Unit | Target | Description |
|---|---|---|---|
| `density_m3` | m⁻³ | `species.wp` | Default plasma number density (per-species override available) |
| `magnetic_field_T` | T | `plasma.wc` | Background magnetic field (sign = direction) |
| `magnetic_field_phiz_deg` | deg | `plasma.phiz` | B-field polar angle |
| `magnetic_field_phixy_deg` | deg | `plasma.phixy` | B-field azimuthal angle |
| `e0x_V_m`, `e0y_V_m`, `e0z_V_m` | V/m | `plasma.e0x` etc. | Background electric field |
| `particles_per_cell` | — | `species.npin` | Default particles per cell |

**Per-species `[[meta.physical.species]]`:**

| Parameter | Unit | Target | Description |
|---|---|---|---|
| `label` | — | — | Documentation label |
| `density_m3` | m⁻³ | `species.wp` | Per-species number density (overrides global) |
| `mass_ratio` | — | `species.qm` | Mass ratio to electron |
| `qm_sign` | — | `species.qm` | Charge sign (-1 or +1) |
| `temperature_eV` | eV | `species.path`, `species.peth` | Isotropic temperature |
| `path_temperature_eV` | eV | `species.path` | Parallel temperature |
| `peth_temperature_eV` | eV | `species.peth` | Perpendicular temperature |
| `drift_velocity_m_s` | m/s | `species.vdri` | Drift velocity |
| `particles_per_cell` | — | `species.npin` | Per-species override |
| `emission_current_density_A_m2` | A/m² | `species.curf`, `nflag_emit=2` | Emission current density |

**Per-conductor `[[meta.physical.conductors]]`:**

| Parameter | Unit | Target | Description |
|---|---|---|---|
| `group` | — | — | Key in `conductor_groups` |
| `potential_V` | V | `ptcond.conductor_groups.{group}.pfixed` | Fixed potential |
| `bias_potential_V` | V | `ptcond.conductor_groups.{group}.biasp` | Bias potential |

```toml
[meta.physical]
density_m3 = 1e7              # global default (per-species override available)
magnetic_field_T = 0.0
particles_per_cell = 40

[[meta.physical.species]]
label = "electron"
density_m3 = 1e7              # optional; falls back to global value
mass_ratio = 1
qm_sign = -1
temperature_eV = 10.0
drift_velocity_m_s = -400000.0

[[meta.physical.species]]
label = "ion"
mass_ratio = 1836.0
qm_sign = 1
temperature_eV = 10.0

[[meta.physical.conductors]]
group = "sphere"
potential_V = 10.0
```

---

### `[memo]` — Free-form Notes

The `[memo]` table accepts arbitrary key/value pairs for case-specific notes. Useful for Python scripts that generate or modify TOML files. Not consumed by the solver.

```toml
[memo]
family = "lsurface"
description = "Workshop photoelectron case"
created_by = "experiment_generator.py"
```

---

### Group Defaults — Parameter Inheritance for Array-of-Tables

Instead of repeating common parameters across `[[species]]` entries, you can define **groups** with default values and reference them from entries. Entry-level values override group defaults.

```toml
# ── Group definition (default values) ──
[species_groups.background]
particle_boundary_mode = [2, 2, 2]
lower_x_boundary_injection_enabled = 1
upper_x_boundary_injection_enabled = 1
injection_interval = 1
particle_hdf5_stride = 0
particle_output_interval = 1024
particle_output_flags = [0, 0, 0, 0, 0, 0, 0]

# ── Entries (reference group via group_id) ──
[[species]]  # electron
group_id = "background"
wp = 2.1
qm = -1.0
npin = 5242880
path = 44.24
peth = 44.24
# particle_boundary_mode, lower_x_boundary_injection_enabled, upper_x_boundary_injection_enabled, injection_interval, particle_hdf5_stride, particle_output_interval, particle_output_flags inherited from background

[[species]]  # ion
group_id = "background"
wp = 0.049
qm = 0.000545
npin = 5242880
path = 1.03
peth = 1.03
# same inheritance from background
```

**Merge priority:** Entry value > Group value

#### Group Table Names

| Array-of-Tables | Group Table | Reference Key |
|---|---|---|
| `[[species]]` | `[species_groups.<name>]` | `group_id` |
| `[[ptcond.objects]]` | `[ptcond.object_groups.<name>]` | `group_id` |
| `[[ptcond.boundaries]]` | `[ptcond.boundary_groups.<name>]` | `group_id` |
| `[[emissn.planes]]` | `[emissn.plane_groups.<name>]` | `group_id` |
| `[[dipole.sources]]` | `[dipole.source_groups.<name>]` | `group_id` |
| `[[testch.charges]]` | `[testch.charge_groups.<name>]` | `group_id` |
| `[[jsrc.sources]]` | `[jsrc.source_groups.<name>]` | `group_id` |
| `[[meta.physical.species]]` | `[meta.physical.species_groups.<name>]` | `group_id` |
| `[[meta.physical.conductors]]` | `[meta.physical.conductor_groups.<name>]` | `group_id` |

**Naming convention:** `{array_key}_groups`. Top-level `[[species]]` uses `[species_groups]`, nested `[[ptcond.boundaries]]` uses `[ptcond.boundary_groups]`.

`group_id` must reference a name that exists in the corresponding group table. Undefined `group_id` values, unknown top-level tables, and unsupported keys in `[[species]]` / `[species_groups]` are input errors.

---

### Overview

| New Format | Description | Implicitly Defined | Corresponding Legacy Groups |
|---|---|---|---|
| [`[[species]]`](#species--per-species-parameter-definition) | Per-species cross-group parameters | `nspec` = entry count | [`&plasma`](Parameters.en.md#plasma--plasma-and-field-parameters), [`&intp`](Parameters.en.md#intp--particle-integration-and-initialization), [`&inp`](Parameters.en.md#inp--particle-injection-boundaries), [`&emissn`](Parameters.en.md#emissn--particle-emission), [`&digcon`](Parameters.en.md#digcon), [`&system`](Parameters.en.md#system) |
| [`[[ptcond.boundaries]]`](#ptcondboundaries--complex-boundary-definition) | Per-element complex boundaries | `boundary_type` = `"complex"` | [`&ptcond`](Parameters.en.md#ptcond--surfaceconductor-boundaries) ([Finbound extension](Parameters.en.md#finbound-extension-additional-parameters)) |
| [`[[ptcond.objects]]`](#ptcondobjects--ptcondconductor_groups--conductor-definition) + `[ptcond.conductor_groups]` | Conductor groups and object geometry | `npc`, `npcg`, `pcgs`, `ccgs` | [`&ptcond`](Parameters.en.md#ptcond--surfaceconductor-boundaries) ([Basic settings](Parameters.en.md#basic-settings), [Body shapes](Parameters.en.md#body-shapes)) |
| [`[[emissn.planes]]`](#emissnplanes--emission-plane-definition) | Per-plane emission definition | `nepl` = entry count | [`&emissn`](Parameters.en.md#emissn--particle-emission) ([Explicit emission planes](Parameters.en.md#-explicit-emission-plane-parameters)) |
| [`[[dipole.sources]]`](#dipolesources--magnetic-dipole-definition) | Per-dipole definition | `nmd` = entry count | [`&dipole`](Parameters.en.md#dipole) |
| [`[[testch.charges]]`](#testchcharges--test-charge-definition) | Per-charge definition | `ntch` = entry count | [`&testch`](Parameters.en.md#testch--test-charges) |
| [`[[jsrc.sources]]`](#jsrcsources--current-source-definition) | Per-source definition | `njs` = entry count | [`&jsrc`](Parameters.en.md#jsrc--current-sources) |

---

### `[[species]]` — Per-species Parameter Definition

Species-dependent parameters scattered across groups can be defined per-species.

**Implicitly defined:** `nspec` = number of `[[species]]` entries. Overrides any `nspec` in `[system]`.

#### Available Parameters and Legacy Groups

| Parameter | Legacy Group | Description |
|---|---|---|
| `wp` | [`&plasma`](Parameters.en.md#plasma--plasma-and-field-parameters) | Plasma frequency |
| `qm` | [`&intp`](Parameters.en.md#intp--particle-integration-and-initialization) | Charge-to-mass ratio |
| `npin`, `np` | [`&intp`](Parameters.en.md#intp--particle-integration-and-initialization) | Particle count |
| `path`, `peth` | [`&intp`](Parameters.en.md#intp--particle-integration-and-initialization) | Parallel / perpendicular thermal velocity |
| `vdri`, `vdthz`, `vdthxy` | [`&intp`](Parameters.en.md#intp--particle-integration-and-initialization) | Drift velocity magnitude and direction |
| `lower_x_boundary_injection_enabled`, `upper_x_boundary_injection_enabled`, `injection_interval`, `injection_sample_count` | [`&inp`](Parameters.en.md#inp--particle-injection-boundaries) | Injection flags and interval |
| `curf`, `curb`, `dnsf`, `dnsb`, `nflag_emit`, `nepl` | [`&emissn`](Parameters.en.md#emissn--particle-emission) | Emission current, division, and type |
| `particle_output_interval` (`ipadig`), `particle_hdf5_stride` (`ipahdf`) | [`&digcon`](Parameters.en.md#digcon) | Output skip factors |
| `particle_output_flags` (`ipaxyz`) | [`&digcon`](Parameters.en.md#digcon) | Particle data storage options (7-element array) |
| `particle_boundary_mode` | [`&system`](Parameters.en.md#system) | Particle boundary conditions (3-element array) |

```toml
[[species]]  # 1: electron
wp = 2.1
qm = -1.0
npin = 5242880
path = 44.24
peth = 44.24
vdri = -13.34
particle_output_flags = [1, 1, 1, 1, 1, 1, 0]

[[species]]  # 2: ion
wp = 0.049
qm = 0.000545
npin = 5242880

[[species]]  # 3: photoelectron
wp = 2.1
qm = -1.0
curf = 829.4
dnsf = 10
nflag_emit = 2
```

---

### `[[ptcond.boundaries]]` — Complex Boundary Definition

**Implicitly defined:** `boundary_type` = `"complex"`

| `type` value | Required parameters | Reference |
|---|---|---|
| `"rectangle"` | `rectangle_shape` (6 elements) | [Complex mode](Parameters.en.md#c-complex-mode-composite-boundaries) |
| `"rectangle-corners"` | `rectangle_corners` (4 corners × 3 coordinates) | " |
| `"cuboid"` | `cuboid_shape` (6 elements) | " |
| `"sphere"` | `sphere_origin` (3), `sphere_radius` | " |
| `"circlex"` / `"circley"` / `"circlez"` | `circle_origin` (3), `circle_radius` | " |
| `"cylinderx"` / `"cylindery"` / `"cylinderz"` | `cylinder_origin` (3), `cylinder_radius`, `cylinder_height` | " |
| `"diskx"` / `"disky"` / `"diskz"` | `disk_origin` (3), `disk_radius`, `disk_inner_radius`, `disk_height` | " |

Each entry optionally accepts `boundary_conductor_id` or `conductor_object` (the `id` of a `[[ptcond.objects]]` entry). `conductor_object` is resolved to the final `boundary_conductor_id` while reading the input. Array values are per-species (`[species1, species2, ...]`).

| Parameter | Type | Description | Reference |
|---|---|---|---|
| `boundary_conductor_id` | integer | Conductor ID for charge accounting | [Complex mode](Parameters.en.md#c-complex-mode-composite-boundaries) |
| `conductor_object` | string | `[[ptcond.objects]].id` used for charge accounting; mutually exclusive with `boundary_conductor_id` | " |
| `conductivity` | number | Surface conductivity | " |
| `boundary_mirror_reflection_rate` | \[number\] | Specular reflection probability (0–1, per species) | [E. Surface reflection & SEE](Parameters.en.md#e-surface-reflection-and-secondary-electron-emission) |
| `boundary_reversal_reflection_rate` | \[number\] | Reversal (backscatter) reflection probability (0–1, per species) | " |
| `boundary_mirror_reflect_alpha` | \[number\] | Beckmann roughness α for specular reflection (regolith ≈ 0.3–0.5) | " |
| `boundary_reversal_reflect_alpha` | \[number\] | Beckmann roughness α for reversal reflection | " |
| `boundary_mirror_reflect_energy_loss_frac` | \[number\] | Kinetic energy loss fraction on specular reflection (v' = √(1−frac)·v) | " |
| `boundary_reversal_reflect_energy_loss_frac` | \[number\] | Energy loss fraction on reversal reflection | " |
| `enable_secondary_electron_emission` | \[boolean\] | Enable SEE for this boundary (per species) | " |
| `boundary_se_yield_max` | \[number\] | Maximum SEE yield δ_max | " |
| `boundary_se_energy_max` | \[number\] | Incident energy E_max at δ = δ_max \[EMSES eV\] | " |
| `boundary_se_species_id` | \[integer\] | Species ID for emitted secondary electrons (default: 1) | " |

```toml
[[ptcond.boundaries]]
type = "cuboid"
cuboid_shape = [1, 10, 1, 10, 1, 10]
conductor_object = "spacecraft_body"
boundary_mirror_reflection_rate = [0.3, 0.0]
enable_secondary_electron_emission = [true, false]
boundary_se_yield_max = [1.5, 0.0]
boundary_se_energy_max = [300.0, 0.0]

[[ptcond.boundaries]]
type = "sphere"
sphere_origin = [5, 5, 5]
sphere_radius = 3.0
```

---

### `[[ptcond.objects]]` + `[ptcond.conductor_groups]` — Conductor Definition

**Implicitly defined:** `npc`, `npcg`, `pcgs`, `ccgs` (all auto-computed from structure)

| `geotype` | Shape | Required parameters | Reference |
|---|---|---|---|
| `0` or `1` | Cuboid | `xlpc`, `xupc`, `ylpc`, `yupc`, `zlpc`, `zupc` | [Shape types](Parameters.en.md#shape-types-geotype) |
| `2` | Cylinder | `bdyalign`, `bdyradius`, `bdycoord`, `bdyedge` | " |
| `3` | Sphere | `bdyradius`, `bdycoord` | " |

| conductor_groups parameter | Description | Reference |
|---|---|---|
| `mtd_vchg` | Potential treatment (`0`=floating, `-1`=fixed) | [Basic settings](Parameters.en.md#basic-settings) |
| `pfixed` | Fixed potential value (when `mtd_vchg = -1`) | " |

Each `[[ptcond.objects]]` entry may define an optional `id`. Boundaries can then use `conductor_object = "<id>"` instead of spelling out the reordered integer `boundary_conductor_id`.

```toml
[ptcond.conductor_groups.spacecraft]
mtd_vchg = 0

[[ptcond.objects]]
id = "spacecraft_body"
conductor = "spacecraft"
geotype = 3
bdyradius = 0.5
bdycoord = [80.0, 110.0, 63.0]
```

---

### `[[emissn.planes]]` — Emission Plane Definition

**Implicitly defined:** `nepl` = entry count

| Parameter | Description | Reference |
|---|---|---|
| `nemd` | Emission normal (±1=x, ±2=y, ±3=z) | [Explicit planes](Parameters.en.md#-explicit-emission-plane-parameters) |
| `ipcpl` | Conductor ID for charge conservation | " |
| `xmine`–`zmaxe` | Spatial bounds | " |
| `curfs`, `curbs`, `dnsfs`, `dnsbs` | Per-plane current/division | " |

```toml
[[emissn.planes]]
nemd = 3
xmine = 0.0
xmaxe = 32.0
zmine = 60.0
zmaxe = 60.0
ipcpl = 1
```

---

### `[[dipole.sources]]` — Magnetic Dipole Definition

**Implicitly defined:** `nmd` = entry count

| Parameter | Description |
|---|---|
| `md` | Dipole moment magnitude |
| `mdx`, `mdy`, `mdz` | Position coordinates |
| `mddir` | Direction (`0`=x, `1`=y, `2`=z) |

```toml
[[dipole.sources]]
md = 1e-3
mdx = 80.0
mdy = 80.0
mdz = 63.0
mddir = 2
```

---

### `[[testch.charges]]` — Test Charge Definition

**Implicitly defined:** `ntch` = entry count

```toml
[[testch.charges]]
rtch = [64, 64, 63]
qtch = -1.0
rcutoff = 0.5
```

---

### `[[jsrc.sources]]` — Current Source Definition

**Implicitly defined:** `njs` = entry count

```toml
[[jsrc.sources]]
rjs = [64, 64, 63]
ajs = [0, 0, 1e-3]
wjs = 0.1
th0js = 0.0
```

---
