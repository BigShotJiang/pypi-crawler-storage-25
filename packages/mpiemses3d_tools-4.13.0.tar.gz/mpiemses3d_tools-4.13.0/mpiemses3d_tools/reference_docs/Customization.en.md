Lang: [English](Customization.en.md) | [日本語](Customization.md)

# plasma.toml Customization Guide

This guide explains how to write `plasma.toml` in physical units and automate case generation with Python scripts.

---

## 1. Writing Physical Parameters with `[meta.physical]`

The `[meta.physical]` table stores plasma conditions in SI units. Use `emu apply` to convert them to simulation units. The solver does not read `[meta.physical]` directly.

### Basic Usage

```toml
[meta]
format_version = 2

[meta.unit_conversion]
dx = 0.5        # Grid spacing [m]
to_c = 1000     # c_phys / cv_sim

[meta.physical]
density_m3 = 1e7               # Plasma number density [m^-3]
magnetic_field_T = 0.0         # Background B-field [T]
particles_per_cell = 40

[[meta.physical.species]]
label = "electron"
mass_ratio = 1
qm_sign = -1
temperature_eV = 10.0           # [eV]
drift_velocity_m_s = -400000.0   # [m/s]

[[meta.physical.species]]
label = "ion"
mass_ratio = 1836.0
qm_sign = 1
temperature_eV = 10.0
drift_velocity_m_s = -400000.0

[[meta.physical.species]]
label = "photoelectron"
mass_ratio = 1
qm_sign = -1
temperature_eV = 2.2
emission_current_density_A_m2 = 4.5e-6  # [A/m^2]

[[meta.physical.conductors]]
group = "sphere"
potential_V = 10.0             # [V]
```

### Running the Conversion

```bash
# Preview what would change
emu apply plasma.toml --dry-run

# Apply in-place
emu apply plasma.toml

# Write to a different file
emu apply plasma.toml -o output.toml
```

`emu apply` reads `[meta.physical]`, computes simulation-unit parameters (`wp`, `qm`, `path`, `peth`, `vdri`, `npin`, etc.), and writes them into `[[species]]`, `[plasma]`, and `[ptcond]`. Existing fields (`ipahdf`, `injct`, `npr`, etc.) are preserved.

### Reverse Conversion: Generating `[meta.physical]` from Simulation Parameters

If your `plasma.toml` only has simulation-unit values, use `emu generate` to auto-generate `[meta.physical]`:

```bash
# Generate [meta.physical] (in-place)
emu generate plasma.toml

# Preview generated values (JSON output)
emu generate plasma.toml --dry-run

# Write to a different file
emu generate plasma.toml -o output.toml
```

If `[meta.physical]` already exists, existing keys such as `label` are preserved while values are updated. `inp2toml` also auto-generates `[meta.physical]` by default during conversion.

### Conversion Mapping

See [FormatV2.en.md](FormatV2.en.md#metaphysical--physical-si-unit-plasma-conditions) for the complete mapping table.

---

## 2. Storing Metadata with `[memo]`

The `[memo]` table accepts arbitrary key/value pairs. The solver ignores it.

Use it to record case provenance and generation conditions when automating `plasma.toml` creation:

```toml
[memo]
family = "lsurface"
description = "Workshop photoelectron case"
created_by = "experiment_generator.py"
solar_zenith_angle_deg = 0.0
sphere_center = [32, 32, 220]
```

---

## 3. Automating plasma.toml with Python

### Basic Workflow: Template + `[meta.physical]`

The simplest approach is to prepare a template `plasma.toml`, modify `[meta.physical]` values in Python, and run `apply_physical()`:

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

# Load template
toml = PlasmaToml.load("template.toml")

# Modify physical parameters
toml.meta.physical.density_m3 = 1e8
toml.meta.physical.species[0].temperature_eV = 5.0

# Convert to simulation units
toml.apply_physical()

# Write output
toml.write("plasma.toml")
```

### Parameter Scans

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

base = PlasmaToml.load("template.toml")
for density_m3 in [1e7, 1e8, 1e9]:
    t = base.copy()
    t.meta.physical.density_m3 = density_m3
    t.apply_physical()
    t.write(f"plasma_n{density_m3:.0e}.toml")
```

### Case Management with `[memo]`

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml

toml = PlasmaToml.load("template.toml")

# Record case info in memo
toml.apply({
    "memo": {
        "family": "lsurface",
        "density_cc": 10,
        "run_id": "exp_001",
        "created_by": "scan_script.py",
    }
})

# Set physical parameters and convert
toml.meta.physical.density_m3 = 10 * 1e6  # 10 cm^-3
toml.apply_physical()
toml.write("plasma.toml")
```

---

## 4. Advanced Customization: Direct Python API

For parameters not covered by `[meta.physical]` or for building `plasma.toml` from scratch, use the `PlasmaToml` and `UnitSystem` APIs directly.

### Attribute-Style Access

```python
from mpiemses3d_tools.plasma_toml import PlasmaToml
from mpiemses3d_tools.unit_system import UnitSystem

toml = PlasmaToml.load("plasma.toml")

# Read/write via attributes
toml.tmgrid.nx = 256
toml.tmgrid.ny = 256
toml.tmgrid.nz = 512

# SI proxy for physical-unit access
toml.species[0].si.path = 1.5e5   # physical [m/s] -> auto-converted
print(toml.species[0].si.path)     # normalized -> physical [m/s]

# Manual conversion via UnitSystem
unit = toml.unit
toml.species[0].wp = unit.f.trans(UnitSystem.plasma_frequency(1e11))
```

### Adding Species

```python
unit = toml.unit
toml.species.append({
    "wp": unit.f.trans(UnitSystem.plasma_frequency(1e11)),
    "qm": -1.0,
    "path": unit.v.trans(UnitSystem.thermal_speed(10.0)),
    "peth": unit.v.trans(UnitSystem.thermal_speed(10.0)),
    "npin": 5242880,
    "inpf": 1,
    "inpb": 1,
    "injct": 1,
    "npr": 524288,
})
```

### Adding Conductor Objects

```python
toml.ptcond.objects.append({
    "conductor": "probe",
    "geotype": 3,
    "bdyradius": 0.5,
    "bdycoord": [32.0, 32.0, 100.0],
})
```

### Bulk Overrides with `apply()`

```python
toml = PlasmaToml.load("template.toml")
toml.apply({
    "tmgrid": {"nx": 256, "ny": 256, "nz": 512, "dt": 0.01},
    "jobcon": {"nstep": 50000},
    "mpi": {"nodes": [4, 4, 8]},
})
toml.write("plasma.toml")
```

### Reverse Generation of `[meta.physical]`

Generate `[meta.physical]` from simulation parameters:

```python
toml = PlasmaToml.load("plasma.toml")

# Generate [meta.physical] (preserves existing labels etc.)
toml.generate_physical()
toml.write("plasma.toml")
```

### Physics Helper Functions

`UnitSystem` provides helper functions for common plasma calculations:

```python
from mpiemses3d_tools.unit_system import UnitSystem

UnitSystem.plasma_frequency(1e11)          # plasma frequency [rad/s]
UnitSystem.thermal_speed(10.0)             # thermal speed [m/s] (10 eV)
UnitSystem.debye_length(10.0, 1e11)        # Debye length [m]
UnitSystem.cyclotron_frequency(5e-9)       # cyclotron frequency [rad/s]
UnitSystem.larmor_radius(1e5, 5e-9)        # Larmor radius [m]
```

---

## 5. Practical Example: Workshop Case Generator

A complete example combining `[memo]` and `[meta.physical]` to generate simulation cases from a template:

```python
#!/usr/bin/env python3
"""Generate simulation cases from a template with parameter variations."""

from mpiemses3d_tools.plasma_toml import PlasmaToml

TEMPLATE = "template.toml"

cases = [
    {"name": "low_density",  "density_cc": 1,   "etemp": 10, "potential_V": 5},
    {"name": "mid_density",  "density_cc": 10,  "etemp": 10, "potential_V": 10},
    {"name": "high_density", "density_cc": 100, "etemp": 10, "potential_V": 20},
]

base = PlasmaToml.load(TEMPLATE)

for case in cases:
    t = base.copy()

    # Record case info in memo
    t.apply({"memo": case})

    # Set physical parameters
    density_m3 = case["density_cc"] * 1e6
    t.meta.physical.density_m3 = density_m3
    for sp in t.meta.physical.species:
        sp.temperature_eV = case["etemp"]

    # Update conductor potential
    for cond in t.data["meta"]["physical"].get("conductors", []):
        cond["potential_V"] = case["potential_V"]

    # Convert and write
    t.apply_physical()
    t.write(f"{case['name']}/plasma.toml")
```
