Lang: [日本語](FormatV2.md) | [English](FormatV2.en.md)

## TOML 新形式（format_version = 2）

`[meta]` に `format_version = 2` を指定すると、以下の構造化された入力形式が使用できます。
旧形式（フラット配列）との後方互換性は完全に維持されます。既存の `format_version = 1`（または未指定）のファイルはそのまま動作します。新旧形式は 1 つのファイル内で混在可能です。

```bash
# plasma.inp → format_version 2 の TOML に変換（デフォルト）
# [meta.physical] も自動生成される
inp2toml plasma.inp

# [meta.physical] の自動生成を無効化
inp2toml plasma.inp --no-generate-physical

# 既存の format_version 1 TOML → 2 にアップグレード
toml-upgrade plasma.toml
toml-upgrade plasma.toml -o new.toml  # 別ファイルに出力
```

---

### `[meta.physical]` — 物理単位 (SI) でのプラズマ条件

`[meta.physical]` テーブルに物理単位（SI）でプラズマ条件を記述し、`emu apply` コマンドで正規化単位に変換して `[[species]]`、`[plasma]` 等に反映できます。ソルバは直接読みません。

```bash
# [meta.physical] → シミュレーションパラメータに変換
emu apply plasma.toml              # in-place 更新
emu apply plasma.toml --dry-run    # 変換結果を表示するのみ
emu apply plasma.toml -o out.toml  # 別ファイルに出力

# シミュレーションパラメータ → [meta.physical] を生成（逆変換）
emu generate plasma.toml              # in-place 生成/更新
emu generate plasma.toml --dry-run    # 生成結果を JSON で表示
emu generate plasma.toml -o out.toml  # 別ファイルに出力
```

`emu generate` は `emu apply` の逆変換です。`[[species]]`、`[plasma]`、`[ptcond.conductor_groups]` のシミュレーション値から物理単位（SI）の `[meta.physical]` を自動生成します。既に `[meta.physical]` が存在する場合は、`label` などの既存キーを保持しつつ更新します。

**グローバルパラメータ:**

| パラメータ | 単位 | 変換先 | 説明 |
|---|---|---|---|
| `density_m3` | m⁻³ | `species.wp` | プラズマ数密度の全種デフォルト（種ごとに上書き可） |
| `magnetic_field_T` | T | `plasma.wc` | 背景磁場（符号で方向指定） |
| `magnetic_field_phiz_deg` | deg | `plasma.phiz` | 磁場の仰角 |
| `magnetic_field_phixy_deg` | deg | `plasma.phixy` | 磁場の方位角 |
| `e0x_V_m`, `e0y_V_m`, `e0z_V_m` | V/m | `plasma.e0x` 等 | 背景電場 |
| `particles_per_cell` | — | `species.npin` | 1 セルあたりの粒子数（全種デフォルト） |

**種パラメータ `[[meta.physical.species]]`:**

| パラメータ | 単位 | 変換先 | 説明 |
|---|---|---|---|
| `label` | — | — | 文書化用ラベル |
| `density_m3` | m⁻³ | `species.wp` | 種固有の数密度（省略時はグローバル値） |
| `mass_ratio` | — | `species.qm` | 電子に対する質量比 |
| `qm_sign` | — | `species.qm` | 電荷符号（-1 or +1） |
| `temperature_eV` | eV | `species.path`, `species.peth` | 等方温度 |
| `path_temperature_eV` | eV | `species.path` | 平行温度（異方性用） |
| `peth_temperature_eV` | eV | `species.peth` | 垂直温度（異方性用） |
| `drift_velocity_m_s` | m/s | `species.vdri` | ドリフト速度 |
| `particles_per_cell` | — | `species.npin` | 種固有の粒子数/セル |
| `emission_current_density_A_m2` | A/m² | `species.curf`, `nflag_emit=2` | 放出電流密度 |

**導体パラメータ `[[meta.physical.conductors]]`:**

| パラメータ | 単位 | 変換先 | 説明 |
|---|---|---|---|
| `group` | — | — | `conductor_groups` のキー名 |
| `potential_V` | V | `ptcond.conductor_groups.{group}.pfixed` | 固定電位 |
| `bias_potential_V` | V | `ptcond.conductor_groups.{group}.biasp` | バイアス電位 |

```toml
[meta.physical]
density_m3 = 1e7              # 全種デフォルト（種ごとに上書き可）
magnetic_field_T = 0.0
particles_per_cell = 40

[[meta.physical.species]]
label = "electron"
density_m3 = 1e7              # 省略時はグローバル値を使用
mass_ratio = 1
qm_sign = -1
temperature_eV = 10.0
drift_velocity_m_s = -400000.0

[[meta.physical.species]]
label = "ion"
mass_ratio = 1836.0
qm_sign = 1
temperature_eV = 10.0

[[meta.physical.conductors]]
group = "sphere"
potential_V = 10.0
```

---

### `[memo]` — フリーフォームメモ

`[memo]` テーブルは任意のキー/値ペアを格納できるフリーフォーム領域です。Python スクリプトでの TOML 編集時にケース固有の情報を保存する用途に使えます。ソルバは読みません。

```toml
[memo]
family = "lsurface"
description = "Workshop用 光電子放出ケース"
created_by = "experiment_generator.py"
```

---

### グループデフォルト — 配列テーブルのパラメータ継承

`[[species]]` 等の配列テーブルで共通のパラメータを何度も繰り返す代わりに、**グループ**にデフォルト値を定義してエントリから参照できます。エントリの値はグループの値を上書きします。

```toml
# ── グループ定義（デフォルト値） ──
[species_groups.background]
particle_boundary_mode = [2, 2, 2]
lower_x_boundary_injection_enabled = 1
upper_x_boundary_injection_enabled = 1
injection_interval = 1
particle_hdf5_stride = 0
particle_output_interval = 1024
particle_output_flags = [0, 0, 0, 0, 0, 0, 0]

# ── エントリ（group_id でグループを参照） ──
[[species]]  # 電子
group_id = "background"
wp = 2.1
qm = -1.0
npin = 5242880
path = 44.24
peth = 44.24
# particle_boundary_mode, lower_x_boundary_injection_enabled, upper_x_boundary_injection_enabled, injection_interval, particle_hdf5_stride, particle_output_interval, particle_output_flags は background から継承

[[species]]  # イオン
group_id = "background"
wp = 0.049
qm = 0.000545
npin = 5242880
path = 1.03
peth = 1.03
# 同じく background から継承
```

**マージ優先順位:** エントリの値 > グループの値

#### グループテーブル名一覧

| 配列テーブル | グループテーブル | 参照キー |
|---|---|---|
| `[[species]]` | `[species_groups.<名前>]` | `group_id` |
| `[[ptcond.objects]]` | `[ptcond.object_groups.<名前>]` | `group_id` |
| `[[ptcond.boundaries]]` | `[ptcond.boundary_groups.<名前>]` | `group_id` |
| `[[emissn.planes]]` | `[emissn.plane_groups.<名前>]` | `group_id` |
| `[[dipole.sources]]` | `[dipole.source_groups.<名前>]` | `group_id` |
| `[[testch.charges]]` | `[testch.charge_groups.<名前>]` | `group_id` |
| `[[jsrc.sources]]` | `[jsrc.source_groups.<名前>]` | `group_id` |
| `[[meta.physical.species]]` | `[meta.physical.species_groups.<名前>]` | `group_id` |
| `[[meta.physical.conductors]]` | `[meta.physical.conductor_groups.<名前>]` | `group_id` |

**命名規則:** `{配列キー名}_groups`。トップレベルの `[[species]]` は `[species_groups]`、ネストされた `[[ptcond.boundaries]]` は `[ptcond.boundary_groups]` となります。

`group_id` は対応するグループテーブル内に存在する名前を参照してください。未定義の `group_id`、未知のトップレベルテーブル、`[[species]]` / `[species_groups]` 内の未対応キーは入力エラーになります。

---

### 新形式一覧

| 新形式 | 説明 | 旧カウント変数 | 暗黙定義される変数 | 対応する旧グループ |
|---|---|---|---|---|
| [`[[species]]`](#species--種ごとのパラメータ定義) | 種ごとにパラメータを横断的に定義 | `nspec` | `nspec` = エントリ数 | [`&plasma`](Parameters.md#plasma--プラズマおよび場のパラメータ), [`&intp`](Parameters.md#intp--粒子積分と初期化), [`&inp`](Parameters.md#inp--粒子注入境界), [`&emissn`](Parameters.md#emissn--粒子放出), [`&digcon`](Parameters.md#digcon), [`&system`](Parameters.md#system) |
| [`[[ptcond.boundaries]]`](#ptcondboundaries--複合境界の定義) | 複合境界要素を個別に定義 | — | `boundary_type` = `"complex"` | [`&ptcond`](Parameters.md#ptcond--表面導体境界)（[Finbound 拡張](Parameters.md#finbound-拡張追加パラメータ)） |
| [`[[ptcond.objects]]`](#ptcondobjects--ptcondconductor_groups--導体の定義) + `[ptcond.conductor_groups]` | 導体グループと物体形状をセットで定義 | `npc`, `npcg`, `pcgs`, `ccgs` | `npc`, `npcg`, `pcgs`, `ccgs` = 構造から自動計算 | [`&ptcond`](Parameters.md#ptcond--表面導体境界)（[基本設定](Parameters.md#基本設定)・[物体形状](Parameters.md#物体形状)） |
| [`[[emissn.planes]]`](#emissnplanes--放出面の定義) | 放出面を個別に定義 | `nepl` | `nepl` = エントリ数 | [`&emissn`](Parameters.md#emissn--粒子放出)（[明示的放出面](Parameters.md#-明示的放出面パラメータ)） |
| [`[[dipole.sources]]`](#dipolesources--磁気双極子の定義) | 磁気双極子を個別に定義 | `nmd` | `nmd` = エントリ数 | [`&dipole`](Parameters.md#dipole) |
| [`[[testch.charges]]`](#testchcharges--テスト電荷の定義) | テスト電荷を個別に定義 | `ntch` | `ntch` = エントリ数 | [`&testch`](Parameters.md#testch--テスト電荷) |
| [`[[jsrc.sources]]`](#jsrcsources--電流源の定義) | 電流源を個別に定義 | `njs` | `njs` = エントリ数 | [`&jsrc`](Parameters.md#jsrc--電流源) |

---

### `[[species]]` — 種ごとのパラメータ定義

従来はグループごとに散在していた種依存パラメータを、種単位でまとめて定義できます。

**暗黙定義:** `nspec` = `[[species]]` エントリ数。`[system]` に `nspec` を書いた場合はエントリ数が優先されます。

#### 使用可能なパラメータと対応グループ

| パラメータ | 旧グループ | 説明 |
|---|---|---|
| `wp` | [`&plasma`](Parameters.md#plasma--プラズマおよび場のパラメータ) | プラズマ周波数 |
| `denmod`, `denk`, `omegalw` | [`&plasma`](Parameters.md#plasma--プラズマおよび場のパラメータ) | 密度変調パラメータ |
| `qm` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 電荷質量比 |
| `npin`, `np` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 粒子数 |
| `path`, `peth` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 平行・垂直熱速度 |
| `vdri`, `vdthz`, `vdthxy` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | ドリフト速度・方向 |
| `vdx`, `vdy`, `vdz` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | ドリフト速度（デカルト） |
| `spa`, `spe`, `speth`, `f` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 分布関数パラメータ |
| `vpa`, `vpb`, `vpe` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 速度分布範囲 |
| `nphi`, `ndst`, `ioptd` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | 分布診断オプション |
| `lcgamma`, `lcbeta` | [`&intp`](Parameters.md#intp--粒子積分と初期化) | ロスコーンパラメータ |
| `lower_x_boundary_injection_enabled`, `upper_x_boundary_injection_enabled`, `injection_interval`, `injection_sample_count` | [`&inp`](Parameters.md#inp--粒子注入境界) | 粒子注入フラグ・間隔 |
| `curf`, `curb`, `nflag_emit`, `nepl` | [`&emissn`](Parameters.md#emissn--粒子放出) | 放出電流・タイプ |
| `flpf`, `flpb`, `qp`, `qpr`, `abvdem`, `dnsf`, `dnsb` | [`&emissn`](Parameters.md#emissn--粒子放出) | 放出フラックス・電荷・粒子分割 |
| `ray_zenith_angle_deg`, `ray_azimuth_angle_deg` | [`&emissn`](Parameters.md#emissn--粒子放出) | レイキャスト角度 |
| `emission_time_mode`, `emission_start_step`, `emission_end_step` | [`&emissn`](Parameters.md#emissn--粒子放出) | 放出時間制御 |
| `emission_time_sigma`, `emission_leave_anti_particle` | [`&emissn`](Parameters.md#emissn--粒子放出) | 放出時間・反粒子 |
| `particle_output_interval` (`ipadig`), `particle_hdf5_stride` (`ipahdf`) | [`&digcon`](Parameters.md#digcon) | 出力スキップ係数 |
| `particle_output_flags` (`ipaxyz`) | [`&digcon`](Parameters.md#digcon) | 粒子データ格納オプション（7要素配列） |
| `ildig`, `imdig`, `isort`, `irhsp` | [`&digcon`](Parameters.md#digcon) | 診断フラグ |
| `particle_boundary_mode` | [`&system`](Parameters.md#system) | 粒子境界条件（3要素配列） |
| `mfpath` | [`&system`](Parameters.md#system) | 平均自由行程 |
| `pemax`, `deltaemax` | [`&ptcond`](Parameters.md#ptcond--表面導体境界) | 二次電子エネルギー上限 |

```toml
[[species]]  # 1: 電子
wp = 2.1
qm = -1.0
npin = 5242880
path = 44.24
peth = 44.24
vdri = -13.34
vdthxy = 180.0
lower_x_boundary_injection_enabled = 1
upper_x_boundary_injection_enabled = 1
injection_interval = 1
injection_sample_count = 524288
particle_output_flags = [1, 1, 1, 1, 1, 1, 0]

[[species]]  # 2: イオン
wp = 0.049
qm = 0.000545
npin = 5242880
path = 1.03
peth = 1.03
vdri = -13.34
vdthxy = 180.0

[[species]]  # 3: 光電子
wp = 2.1
qm = -1.0
npin = 0
np = 52428800
curf = 829.4
dnsf = 10
nflag_emit = 2
```

---

### `[[ptcond.boundaries]]` — 複合境界の定義

[Finbound 拡張](Parameters.md#finbound-拡張追加パラメータ)で使う境界要素を個別に定義できます。

**暗黙定義:** `boundary_type` = `"complex"`（自動設定）

| `type` 値 | 必須パラメータ | 参照 |
|---|---|---|
| `"rectangle"` | `rectangle_shape` (6要素) | [C. Complex モード](Parameters.md#c-complex-モード複合境界) |
| `"rectangle-corners"` | `rectangle_corners` (4頂点 × 3座標) | 同上 |
| `"cuboid"` | `cuboid_shape` (6要素) | 同上 |
| `"sphere"` | `sphere_origin` (3要素), `sphere_radius` | 同上 |
| `"circlex"` / `"circley"` / `"circlez"` | `circle_origin` (3要素), `circle_radius` | 同上 |
| `"cylinderx"` / `"cylindery"` / `"cylinderz"` | `cylinder_origin` (3要素), `cylinder_radius`, `cylinder_height` | 同上 |
| `"open-cylinderx"` / `"open-cylindery"` / `"open-cylinderz"` | 同上（側壁のみ） | 同上 |
| `"diskx"` / `"disky"` / `"diskz"` | `disk_origin` (3要素), `disk_radius`, `disk_inner_radius`, `disk_height` | 同上 |
| `"plane-with-circlex"` / `"plane-with-circley"` / `"plane-with-circlez"` | `plane_with_circle_origin` (3要素), `plane_with_circle_radius` | 同上 |

各エントリには任意で `boundary_conductor_id`（導体 ID）または `conductor_object`（`[[ptcond.objects]]` の `id`）を指定できます。`conductor_object` は読み込み時に最終的な `boundary_conductor_id` に変換されます。配列値は種ごとの設定です（`[species1, species2, ...]`）。

| パラメータ | 型 | 説明 | 参照 |
|---|---|---|---|
| `boundary_conductor_id` | integer | 電荷計算用の導体 ID | [C. Complex モード](Parameters.md#c-complex-モード複合境界) |
| `conductor_object` | string | 電荷計算用に参照する `[[ptcond.objects]].id`。`boundary_conductor_id` と同時指定不可 | 同上 |
| `conductivity` | number | 表面導電率 | 同上 |
| `boundary_mirror_reflection_rate` | \[number\] | 鏡面反射（正反射）の確率（0–1、種ごと） | [E. 表面反射と二次電子放出](Parameters.md#e-表面反射と二次電子放出) |
| `boundary_reversal_reflection_rate` | \[number\] | 速度反転反射（後方散乱）の確率（0–1、種ごと） | 同上 |
| `boundary_mirror_reflect_alpha` | \[number\] | 鏡面反射の Beckmann 粗さパラメータ α（レゴリス ≈ 0.3–0.5） | 同上 |
| `boundary_reversal_reflect_alpha` | \[number\] | 反転型反射の粗さパラメータ α | 同上 |
| `boundary_mirror_reflect_energy_loss_frac` | \[number\] | 鏡面反射時のエネルギー損失割合（v' = √(1−frac)·v） | 同上 |
| `boundary_reversal_reflect_energy_loss_frac` | \[number\] | 反転反射時のエネルギー損失割合 | 同上 |
| `enable_secondary_electron_emission` | \[boolean\] | 二次電子放出（SEE）の有効化（種ごと） | 同上 |
| `boundary_se_yield_max` | \[number\] | 最大 SEE 収率 δ_max | 同上 |
| `boundary_se_energy_max` | \[number\] | δ = δ_max となる入射エネルギー E_max \[EMSES eV\] | 同上 |
| `boundary_se_species_id` | \[integer\] | 放出される二次電子の種 ID（デフォルト: 1） | 同上 |

```toml
[[ptcond.boundaries]]
type = "cuboid"
cuboid_shape = [1, 10, 1, 10, 1, 10]
conductor_object = "spacecraft_body"
boundary_mirror_reflection_rate = [0.3, 0.0]    # 種1: 30%, 種2: 0%
enable_secondary_electron_emission = [true, false]
boundary_se_yield_max = [1.5, 0.0]
boundary_se_energy_max = [300.0, 0.0]

[[ptcond.boundaries]]
type = "sphere"
sphere_origin = [5, 5, 5]
sphere_radius = 3.0
```

---

### `[[ptcond.objects]]` + `[ptcond.conductor_groups]` — 導体の定義

[物体形状](Parameters.md#物体形状)と導体グループの帰属をセットで定義します。

**暗黙定義:** `npc` = objects 数、`npcg` = conductor_groups 数、`pcgs` = `ccgs` = グループごとの物体数（自動計算）

| `geotype` 値 | 形状 | 必須パラメータ | 参照 |
|---|---|---|---|
| `0` または `1` | 直方体 | `xlpc`, `xupc`, `ylpc`, `yupc`, `zlpc`, `zupc` | [形状タイプ](Parameters.md#形状タイプ-geotype) |
| `2` | 円柱 | `bdyalign`, `bdyradius`, `bdycoord`, `bdyedge` | 同上 |
| `3` | 球 | `bdyradius`, `bdycoord` | 同上 |

`[ptcond.conductor_groups.<名前>]` で導体グループを定義し、各 `[[ptcond.objects]]` の `conductor` キーでグループ名を指定します。`id` は任意ですが、設定すると `[[ptcond.boundaries]]` の `conductor_object` から名前で参照できます。

| conductor_groups パラメータ | 説明 | 参照 |
|---|---|---|
| `mtd_vchg` | ポテンシャル制御方式（`0` = 浮遊、`-1` = 固定） | [基本設定](Parameters.md#基本設定) |
| `pfixed` | 固定ポテンシャル値（`mtd_vchg = -1` 時） | 同上 |

```toml
[ptcond.conductor_groups.spacecraft]
mtd_vchg = 0  # 浮遊電位

[[ptcond.objects]]
id = "spacecraft_body"
conductor = "spacecraft"
geotype = 3  # 球
bdyradius = 0.5
bdycoord = [80.0, 110.0, 63.0]
biasp = 0.0
```

---

### `[[emissn.planes]]` — 放出面の定義

[明示的放出面パラメータ](Parameters.md#-明示的放出面パラメータ)を面ごとに定義します。

**暗黙定義:** `nepl` = エントリ数

| パラメータ | 説明 | 参照 |
|---|---|---|
| `nemd` | 放出法線方向（`±1`=x, `±2`=y, `±3`=z） | [明示的放出面](Parameters.md#-明示的放出面パラメータ) |
| `ipcpl` | 電荷保存のための導体 ID | 同上 |
| `xmine`, `xmaxe`, `ymine`, `ymaxe`, `zmine`, `zmaxe` | 放出面の空間範囲 | 同上 |
| `curfs`, `curbs` | 面ごとの放出電流密度 | 同上 |
| `dnsfs`, `dnsbs` | 面ごとの粒子分割数 | 同上 |

```toml
[[emissn.planes]]
nemd = 3
xmine = 0.0
xmaxe = 32.0
ymine = 0.0
ymaxe = 32.0
zmine = 60.0
zmaxe = 60.0
ipcpl = 1
```

---

### `[[dipole.sources]]` — 磁気双極子の定義

[&dipole](Parameters.md#dipole) の双極子を個別に定義します。

**暗黙定義:** `nmd` = エントリ数

| パラメータ | 説明 |
|---|---|
| `md` | 磁気双極子モーメントの大きさ |
| `mdx`, `mdy`, `mdz` | 双極子の位置座標 |
| `mddir` | 双極子の方向（`0`=x, `1`=y, `2`=z） |

```toml
[[dipole.sources]]
md = 1e-3
mdx = 80.0
mdy = 80.0
mdz = 63.0
mddir = 2
```

---

### `[[testch.charges]]` — テスト電荷の定義

[&testch](Parameters.md#testch--テスト電荷) のテスト電荷を個別に定義します。

**暗黙定義:** `ntch` = エントリ数

| パラメータ | 説明 |
|---|---|
| `rtch` | 位置 `[x, y, z]` （グリッド座標） |
| `qtch` | 電荷量 |
| `e1tch` | 電場振幅パラメータ |
| `p1tch` | ポテンシャルパラメータ |
| `rcutoff` | カットオフ半径 |

```toml
[[testch.charges]]
rtch = [64, 64, 63]
qtch = -1.0
rcutoff = 0.5
```

---

### `[[jsrc.sources]]` — 電流源の定義

[&jsrc](Parameters.md#jsrc--電流源) の電流源を個別に定義します。

**暗黙定義:** `njs` = エントリ数

| パラメータ | 説明 |
|---|---|
| `rjs` | グリッド位置 `[x, y, z]` |
| `ajs` | 電流密度振幅 `[Jx, Jy, Jz]` |
| `wjs` | 振動角周波数 |
| `th0js` | 初期位相 [rad] |

```toml
[[jsrc.sources]]
rjs = [64, 64, 63]
ajs = [0, 0, 1e-3]
wjs = 0.1
th0js = 0.0
```

---
