Lang: [English](Parameters.en.md) | [日本語](Parameters.md)

# EMSES Input Parameters

This document is the complete reference for all EMSES input parameters. `plasma.toml` is recommended for new files; legacy `plasma.inp` remains supported.

| Related Document | Contents |
|---|---|
| [FormatV2.en.md](FormatV2.en.md) | TOML structured formats (`[[species]]`, `[[ptcond.objects]]`, etc.) and `[meta.physical]`, `[memo]` |
| [Customization.en.md](Customization.en.md) | Physical-unit input, Python automation, `emu apply` usage |

Unit conversion info goes in `[meta.unit_conversion]`. For physical-unit input, use `[meta.physical]` + `emu apply`:

```toml
[meta.unit_conversion]
dx = 0.5
to_c = 10000.0
```

Convert existing `plasma.inp` with `inp2toml plasma.inp`. For migrating from `plasma.preinp`, see [Customization.en.md](Customization.en.md).

---

## Table of Contents

- [EMSES Input Parameters](#emses-input-parameters)
  - [Table of Contents](#table-of-contents)
  - [Unit System and Conversion](#unit-system-and-conversion)
  - [Namelist Groups Overview](#namelist-groups-overview)
  - [Detailed Parameter Reference](#detailed-parameter-reference)
    - [\&esorem — Electromagnetic Solver Mode](#esorem--electromagnetic-solver-mode)
      - [Field Update Equations](#field-update-equations)
      - [Summary of Differences](#summary-of-differences)
    - [\&jobcon](#jobcon)
    - [\&digcon](#digcon)
    - [\&plasma — Plasma and Field Parameters](#plasma--plasma-and-field-parameters)
      - [Summary of Physical Relationships](#summary-of-physical-relationships)
      - [Notes](#notes)
    - [\&tmgrid — Temporal and Spatial Grid Parameters](#tmgrid--temporal-and-spatial-grid-parameters)
      - [Numerical and Physical Constraints](#numerical-and-physical-constraints)
      - [Practical Notes](#practical-notes)
    - [\&system](#system)
    - [Open / free-space boundary (`mtd_vbnd(i)=3`)](#open--free-space-boundary-mtd_vbndi3)
    - [\&mpi](#mpi)
    - [\&intp — Particle Integration and Initialization](#intp--particle-integration-and-initialization)
    - [\&ptcond — Surface and Conductor Boundaries](#ptcond--surface-and-conductor-boundaries)
      - [Basic Settings](#basic-settings)
      - [Body Geometry](#body-geometry)
      - [Geometry Types (`geotype`)](#geometry-types-geotype)
      - [Finbound Extension (Additional Parameters)](#finbound-extension-additional-parameters)
        - [A. Top-level selector](#a-top-level-selector)
        - [B. Parameters for `'****-surface' / '****-hole'` modes](#b-parameters-for--surface---hole-modes)
        - [C. Complex mode (composite boundaries)](#c-complex-mode-composite-boundaries)
        - [D. Plane-with-Circle Hole (non-complex vertical stack)](#d-plane-with-circle-hole-non-complex-vertical-stack)
      - [E. Surface Reflection and Secondary Electron Emission](#e-surface-reflection-and-secondary-electron-emission)
    - [\&gradema](#gradema)
    - [\&dipole](#dipole)
    - [\&emissn — Particle Emission](#emissn--particle-emission)
      - [① Common Parameters (always applicable)](#-common-parameters-always-applicable)
      - [② Explicit Emission-Surface Parameters](#-explicit-emission-surface-parameters)
      - [③ Ray-Casting Emission Parameters](#-ray-casting-emission-parameters)
      - [Notes](#notes-1)
    - [\&inp — Particle Injection Boundaries](#inp--particle-injection-boundaries)
    - [\&testch — Test Charges](#testch--test-charges)
    - [\&jsrc — Current Source](#jsrc--current-source)
    - [\&verbose — Verbosity and Debugging Control](#verbose--verbosity-and-debugging-control)
  - [Auxiliary and Legacy-Compatible Parameters Accepted by the Implementation](#auxiliary-and-legacy-compatible-parameters-accepted-by-the-implementation)
  - [Input File Examples](#input-file-examples)
      - [FFT-based free-space Poisson solvers (Open boundary)](#fft-based-free-space-poisson-solvers-open-boundary)
    - [Reference Models](#reference-models)

---

## Unit System and Conversion

EMSES adopts a **normalized unit system** to simplify computation and reduce numerical cost. The following base conversions are fixed:

| Quantity                              | Physical Unit | Normalized Value |
| ------------------------------------- | ------------- | ---------------- |
| Grid spacing (`dx`)                   | m             | 1                |
| Speed of light (`cv`)                 | m/s           | cv (e.g. 10000)  |
| Vacuum permittivity (`ε₀`)            | F/m           | 1                |
| Electron charge-to-mass ratio (`q/m`) | C/kg          | −1               |

All other quantities scale consistently according to these base definitions.
The general conversion formula is:

```text
X_EMSES = X_phys × C
```

where the conversion factor `C` is determined by the normalization key.
For explicit coefficients, refer to the **`emout` conversion module** or the provided **unit-conversion spreadsheet**.

In `plasma.toml`, the values corresponding to this normalization key can be stored as `dx` and `to_c` under `[meta.unit_conversion]`. These metadata are read together with the simulation setup so they can be reused later by visualization and conversion tools.

---

## Namelist Groups Overview

| Group      | Description                             |
| ---------- | --------------------------------------- |
| `&real`    | Legacy preinp physical-value settings   |
| `&realcv`  | Legacy preinp derived conversion values |
| `&esorem`  | Field solver configuration              |
| `&jobcon`  | Job execution control                   |
| `&digcon`  | Diagnostic and output control           |
| `&plasma`  | Plasma species and field parameters     |
| `&tmgrid`  | Temporal and spatial grid definition    |
| `&system`  | System-wide control flags               |
| `&mpi`     | MPI domain decomposition                |
| `&intp`    | Particle integration and initialization |
| `&others`  | Legacy collision-related parameters     |
| `&ptcond`  | Surface and conductor boundary settings |
| `&wave`    | Incident-wave parameters                |
| `&scrnt`   | Screen/current-drive parameters         |
| `&gradema` | Surface charging acceleration control   |
| `&dipole`  | Embedded dipole field configuration     |
| `&emissn`  | Particle emission settings              |
| `&inp`     | Particle injection boundaries           |
| `&testch`  | Test charge configuration               |
| `&jsrc`    | Current source configuration            |
| `&verbose` | Verbosity and debugging control         |

---

## Detailed Parameter Reference

### &esorem — Electromagnetic Solver Mode

**Defined in:** `src/main/config/input/namelist_reader.F90`

| Parameter | Type    | Description |
| --------- | ------- | ----------- |
| `emflag`  | integer | Specifies the field-solver mode.<br>`1` = **Full Electromagnetic (Maxwell)** — both electric and magnetic fields are updated via Maxwell's equations.<br>`0` = **Electrostatic (Poisson)** — magnetic fields are fixed and electric potential is updated by solving the Poisson equation.<br>`2` = **legacy implicit EM (`imses`)** — legacy-compatible implicit EM path. Use `0` or `1` for normal new cases. |
| `nflag_testp` | integer | Test-particle mode flag. `0` = normal run, `1` = track particles in externally supplied fields. |

CoToCoA requester / worker runs replace the `emflag = 0` electrostatic path through build-time macros (`make requester` / `make worker`). They are separate from `emflag = 2`.

---

#### Field Update Equations

**(1) Electromagnetic Mode (`emflag = 1`)**

The full set of Maxwell’s equations is solved to update the electric and magnetic fields:

$$\nabla \cdot \mathbf{E} = \frac{\rho}{\varepsilon_0}$$

$$\nabla \cdot \mathbf{B} = 0$$

$$\frac{\partial \mathbf{B}}{\partial t} = -\nabla \times \mathbf{E}$$

$$\frac{\partial \mathbf{E}}{\partial t} = c^2(\nabla \times \mathbf{B}) - \frac{\mathbf{J}}{\varepsilon_0}$$

This mode is used when the evolution of electromagnetic waves and inductive effects are important (e.g., high-frequency plasma phenomena or current-driven dynamics).

---

**(2) Electrostatic Mode (`emflag = 0`)**

In this approximation, magnetic fields are not updated, and the electric field is obtained from the scalar potential:

$$\mathbf{E} = -\nabla \phi$$

where the potential $\phi$ is determined by solving the **Poisson equation**:

$$\nabla^2 \phi = -\frac{\rho}{\varepsilon_0}$$

This mode neglects electromagnetic wave propagation and is suitable for **quasi-static plasma systems** such as surface charging or low-frequency phenomena.

---

#### Summary of Differences

| Mode         | Magnetic Field Update      | Electric Field Update                | Governing Equation          | Typical Use                                        |
| ------------ | -------------------------- | ------------------------------------ | --------------------------- | -------------------------------------------------- |
| `emflag = 1` | ✅ Solved via Faraday’s law | ✅ Solved via Ampère–Maxwell law      | Full Maxwell equations      | Electromagnetic wave propagation, transient fields |
| `emflag = 0` | ❌ Fixed / not updated      | ✅ From potential by Poisson equation | Electrostatic approximation | Surface charging, static field equilibrium         |
| `emflag = 2` | legacy `imses` path        | implicit EM path                     | legacy implicit EM          | Backward compatibility and existing cases          |


---

### &jobcon

| Parameter     | Type    | Description                                                                                                                                           |
| ------------- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `jobnum(1)`   | integer | Continue flag. Set to `1` to resume a simulation from a previous run (requires the `SNAPSHOT0` directory). Set to `0` to start a new simulation.      |
| `jobnum(2)`   | integer | Output flag. Set to `1` to save the final state of the current simulation to `SNAPSHOT1` for future continuation; set to `0` to skip snapshot output. |
| `nstep`       | integer | Total number of time steps                                                                                                                            |
| `random_seed` | integer | Seed value for the random number generator                                                                                                            |
### &digcon

Controls the frequency, range, and format of diagnostic outputs such as HDF5 data dumps, field maps, and current densities.
Short legacy names such as `ifdiag` remain as backward-compatible aliases. Prefer the explicit names for new inputs; specifying a legacy name and its explicit alias together is an input error.

| Main Parameter             | Description                                                |
| -------------------------- | ---------------------------------------------------------- |
| `hdfdigstart`, `hdfdigend` | Starting and ending time steps for HDF5 diagnostic output. |
| `field_output_interval` (`ifdiag`) | Output interval for field diagnostics.                     |
| `current_output_interval` (`ijdiag`) | Output interval for current diagnostics.                   |
| `hdf_output_size_limit_gb` | Estimated HDF5 diagnostic output size limit [GB]. Default: `100.0`. Input loading stops with an error when the estimated total of field, current, and particle HDF5 outputs exceeds this value. Set a larger value explicitly, or set `0` or a negative value to disable the guard. |
| `diagnostic_interval` (`intfoc`) | Main loop diagnostics interval (should be integer multiples of `field_substeps_per_particle_step`, legacy `mltstp`). Default: `128`. |
| `iediag`                   | Energy diagnostic interval. If negative, the damping region is excluded from energy calculation. |
| `isdiag`                   | Sub-diagnostics interval. If negative, no print-out is produced. |
| `iddiag`                   | Particle distribution diagnostic interval. |

| Sub Parameter                                           | Description                           |
| ------------------------------------------------------- | ------------------------------------- |
| `particle_output_interval(1:nspec)` (`ipadig`)          | Data skip of particle species is    |
| `particle_hdf5_stride(1:nspec)` (`ipahdf`)              | HDF5 particle data output stride    |
| `particle_output_flags(1:7, 1:nspec)` (`ipaxyz`)        | Option for particle data storage: [x, y, z, vx, vy, vz, id] |
| `field_output_flags(1:7)` (`ifxyz`)                     | Option for field data storage: [ex, ey, ez, bx, by, bz, rho/phi] |
| `current_output_flags(1:4)` (`ijxyz`)                   | Current data storage: [ajx, ajy, ajz, js]. Set element to `1` to store the corresponding component. |
| `kinetic_temperature_output_flags(1:7)` (`iTxyz`)       | Kinetic-temperature data storage (per species, per cell): `[T_iso, T_xx, T_yy, T_zz, T_xy, T_xz, T_yz]`. `1=store, 0=skip`. Default `[1,0,0,0,0,0,0]` (isotropic scalar only). Internal buffers auto-size to the minimal superset: L1 (scalar `⟨v²⟩`) / L2 (diagonal `⟨v_i²⟩`) / L3 (full tensor `⟨v_i v_j⟩`). |
| `isort`, `walltime_check_interval` (`itchck`)           | Sorting mode and checkpoint interval  |
| `ildig`, `ikdiag`, `ivdiag`, `irhsp`, `imdig`           | Specialized diagnostic flags          |

---

### &plasma — Plasma and Field Parameters

Defines the fundamental plasma and magnetic-field parameters in **normalized EMSES units**.
These quantities determine the plasma density, background magnetic field, and normalization of light speed.

---

| Parameter     | Type | Description                                                                                                                                                                                                                                                                         |
| ------------- | ---- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `wp(1:nspec)` | real | **Plasma frequency** for each species, indirectly specifying the plasma density. It is defined as:<br><br> $\omega_{p,s} = \sqrt{\frac{n_s q_s^2}{\varepsilon_0 m_s}}$ <br><br>where $n_s$, $q_s$, and $m_s$ are the number density, charge, and mass of species *s*, respectively. |
| `wc`          | real | **Cyclotron frequency** of electrons, indirectly determining the strength of the uniform background magnetic field. It is defined as:<br><br> $\omega_c = \frac{e B_0}{m_e}$ <br><br>where $B_0$ is the magnitude of the background magnetic field.                                 |
| `phixy`       | real | Direction of the static magnetic field projected on the *x–y* plane, measured counterclockwise from the x-axis (in degrees).                                                                                                                                                        |
| `phiz`        | real | Elevation angle of the static magnetic field measured from the z-axis (in degrees).                                                                                                                                                                                                 |
| `cv`          | real | **Normalized light speed**, specifying the value of the real speed of light $c$ after normalization. This parameter controls the relative time scale between electromagnetic and particle dynamics.                                                                                 |
| `gfactor`     | real | Implicit solver factor used in the field update (default: `0.5`). Controls the weighting between old and new time levels in the implicit time integration scheme. |
| `e0x`, `e0y`, `e0z` | real | Static background electric field components along x, y, and z directions, respectively (default: `0.0`). These represent a uniform, externally imposed electric field that is added to the self-consistent field. |
| `rho0`        | real | Reference charge density (default: `-1.0`, meaning auto-determined). When set to a positive value, it overrides the automatically computed background charge density for neutralization. |

---

#### Summary of Physical Relationships

| Quantity                      | Defined by                                         | Controlled Parameter | Physical Meaning                                            |
| ----------------------------- | -------------------------------------------------- | -------------------- | ----------------------------------------------------------- |
| Plasma density $n_s$          | $\omega_{p,s}^2 = n_s q_s^2 / (\varepsilon_0 m_s)$ | `wp(1:nspec)`        | Determines plasma frequency and Debye length                |
| Magnetic field strength $B_0$ | $\omega_c = e B_0 / m_e$                           | `wc`                 | Sets the magnitude of the uniform background magnetic field |
| Light speed $c$               | Normalized to `cv`                                 | `cv`                 | Adjusts EM–particle coupling scale                          |
| Magnetic field direction      | ![Orientation of B-field](assets/img/plasma/orientation_of_bfield.png)                                                  | `phixy`, `phiz`      | Sets 3D orientation of $\mathbf{B}_0$                       |

---

#### Notes

- The **magnetic field vector** $\mathbf{B}_0$ is automatically constructed from `wc`, `phixy`, and `phiz`.
- The **$-\mathbf{v} \times \mathbf{B}_0$** electric field is self-consistently included in the simulation.


---

### &tmgrid — Temporal and Spatial Grid Parameters

Defines the time step and spatial resolution of the simulation domain.
These parameters determine numerical stability, physical accuracy, and computational cost.

---

| Parameter    | Type    | Description                                                                                                                                                                                                                               |
| ------------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `dt`         | real    | **Time-step size**. Must satisfy stability conditions depending on the simulation mode (see below).                                                                                                                                       |
| `nx, ny, nz` | integer | Number of grid cells along each spatial direction (x, y, z). Determines the total grid resolution.                                                                                                                                        |
| `dr`         | real    | **Grid spacing** (delta-x = delta-y = `dr`), corresponding to one normalized length unit. Must be consistent with the normalization key (e.g., `!!key dx=[...]`). It should be smaller than the local **Debye length** to properly resolve electrostatic structures. **Note:** The actual namelist variable is `dr`. In `plasma.inp`, `dx` can be used as a preprocessing alias (via the `!!key dx=[...]` directive), but the Fortran namelist reads `dr`. |

---

#### Numerical and Physical Constraints

To ensure stability and sufficient spatial/temporal resolution, the following conditions should generally be satisfied:

1. **Spatial Resolution (Debye Length Condition)**
   The grid spacing must be smaller than or comparable to the local Debye length:
   $$\lambda_D = \frac{v_{\mathrm{th},e}}{\omega_{p,e}} \geq dx$$
   where $v_{\mathrm{th},e}$ is the electron thermal velocity and $\omega_{p,e}$ is the electron plasma frequency.
   This ensures that charge separation and sheath structures are physically resolved.

---

2. **Temporal Resolution (Time Step Conditions)**
   - **(a) Plasma Frequency Condition:**
     The time step should be sufficiently smaller than the inverse plasma frequency to resolve plasma oscillations:
     $$\omega_{p,e}\,dt < 1$$
   - **(b) Cyclotron Frequency Condition:**
     If a background magnetic field is present,
     $$\omega_c\,dt < 1$$
     must hold to resolve the gyro-motion of charged particles.
   - **(c) Courant (CFL) Condition — Electromagnetic Mode Only (`emflag = 1`):**
     When electromagnetic fields are evolved, the Courant–Friedrichs–Lewy (CFL) condition restricts the time step:
     $$c_v\,\frac{dt}{dx} < 1$$
     where $c_v$ is the normalized speed of light (`cv`).
     This ensures that electromagnetic waves do not propagate faster than one grid cell per time step.

---

3. **Temporal Resolution of Physical Phenomena**
   For good accuracy in capturing physical dynamics, the time step should also satisfy:
   $$\frac{dt}{T_{\mathrm{phenomenon}}} \ll 1$$
   where $T_{\mathrm{phenomenon}}$ is the characteristic period of the plasma process of interest (e.g., charging timescale, wave period).

---

#### Practical Notes

- Choosing smaller `dx` increases resolution but also decreases the allowable `dt` due to the above constraints.
- In electrostatic simulations (`emflag = 0`), the Poisson solver imposes no explicit CFL limit, but the plasma-frequency condition still applies.
- In electromagnetic simulations (`emflag = 1`), both plasma-frequency and Courant conditions must be satisfied simultaneously.


---

### &system

| Main Parameter  | Type    | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| --------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `nspec`         | integer | Number of particle species                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `field_substeps_per_particle_step` (`mltstp`) | integer | Number of field updating loops between particle pushing loops (multiple time step). Default: `1`. When `field_substeps_per_particle_step > 1`, the field is updated multiple times per particle push, which can improve accuracy for electromagnetic simulations. |
| `implicit_field_substep_factor` (`mltstpf`) | integer | Complementary field update multiplier (default: `1`). |
| `current_cancellation_mode` (`juncan`) | integer | Current cancellation option.<br>`0` = no cancellation (default)<br>`1` = uniform current components are subtracted<br>`2` = electrostatic component is not solved and uniform current is subtracted<br>`-2` = only electrostatic component is not solved (uniform current is retained)<br>`>=1000` = test particle simulation mode (wave fields E and B must be given externally). |
| `nxl`, `nxr`, `nyl`, `nyr`, `nzl`, `nzr` | integer | Sizes of the damping (absorbing) regions on each side of the simulation domain (in grid cells). `nxl`/`nxr` are the left/right damping widths along x, etc. Default: `2`. Used when `field_boundary_mode = 2` (legacy `nfbnd = 2`, damping boundary). |
| `field_mask_flags(1:7)` (`imask`) | integer | Field component masking flags. Controls which field components are enabled:<br>`field_mask_flags(1)` = B-field<br>`field_mask_flags(2)` = E-field (transverse)<br>`field_mask_flags(3)` = E-field (longitudinal)<br>`field_mask_flags(4)` = current<br>`field_mask_flags(5)` = charge<br>Set to `1` to enable, `0` to mask out. Default: `(1,1,1,0,0,0,0)`. |
| `field_boundary_mode(1:3)` (`nfbnd`) | integer | Specifies the **field boundary condition** for each spatial direction. <br>`field_boundary_mode(1)`, `field_boundary_mode(2)`, and `field_boundary_mode(3)` correspond to the **x**, **y**, and **z** directions, respectively. <br>Each element accepts one of the following values: <br>`0` = **Periodic** (fields repeat across opposite boundaries) <br>`1` = **Free** (open boundary with zero-gradient field) <br>`2` = **Damping** (absorbing boundary that suppresses outgoing waves).                |
| `particle_boundary_mode(1:3, 1:nspec)` (`npbnd`) | integer | Specifies the **particle boundary condition** for each spatial direction **and each species**. <br>`particle_boundary_mode(1,is)`, `particle_boundary_mode(2,is)`, and `particle_boundary_mode(3,is)` correspond to the **x**, **y**, and **z** directions for species `is`, respectively. <br>Each element accepts one of the following values: <br>`0` = **Periodic** (particles re-enter from the opposite side) <br>`1` = **Reflective** (particles are reflected at the boundary) <br>`2` = **Free** (particles are removed upon leaving the simulation domain) <br>`-1` = same as `field_boundary_mode` for that direction (default). |
| `potential_boundary_mode(1:3)` (`mtd_vbnd`) | integer | Specifies the potential boundary condition for each spatial direction: `potential_boundary_mode(1)`, `potential_boundary_mode(2)`, and `potential_boundary_mode(3)` correspond to the **x**, **y**, and **z** directions, respectively. <br>Each element accepts one of the following values: <br>`0` = **Periodic** (potential repeats across opposite faces) <br>`1` = **Dirichlet** (fixed potential at boundaries) <br>`2` = **Neumann** (zero-gradient or insulating boundary). <br>`3` = **Open / free-space** (isolated boundary solved via free-space Green-function convolution / FFT-based free-space Poisson solver).                             |

### Open / free-space boundary (`mtd_vbnd(i)=3`)

`potential_boundary_mode(i)=3` denotes an **open (free-space / isolated)** boundary condition. The Poisson equation is solved via convolution with the free-space Green’s function that decays to zero at infinity; in practice this is implemented with FFT-based convolution (i.e., pointwise multiplication in Fourier space).

In this codebase, we adopt the Vico–Greengard–Ferrando (VGF) approach to **windowed (truncated) free-space Poisson solvers**. To reduce aliasing in the kernel spectrum `Ĝ`, the kernel is **precomputed once on a 4N grid and then restricted to 2N for production runs**. During production, the solve uses 2N FFTs and pointwise multiplication by `Ĝ`, which can be cached.

Note: This belongs to the same family of FFT-based free-space solvers as the traditional Hockney–Eastwood (HE) approach (zero-padding + linear convolution). Zou et al. (2021) recommend replacing HE with VGF.

| Sub Parameter                           | Type    |                                                                                                                                                                                                                                                                                                                                                   |
| --------------------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `separate_accumulated_and_space_charge` | logical | If `.true.`, computes the electric-field contributions from accumulated (surface) charge and from space charge separately (default: `.true.`). This option prevents the spatial averaging process—used to avoid self-force effects—from being applied to accumulated surface charge, ensuring more accurate potential evaluation near boundaries. |

---

### &mpi

| Parameter    | Type    | Description                                                                                   |
| ------------ | ------- | --------------------------------------------------------------------------------------------- |
| `nodes(1:3)` | integer | MPI process counts along x, y, and z axes. The product must match the runtime MPI communicator |

---

### &intp — Particle Integration and Initialization

Defines particle species properties, initial loading conditions, and integration parameters in **normalized EMSES units**.
Angles are given in degrees unless otherwise noted.

| Parameter         | Type    | Description                                                                                                                                                                                                                                                                                                                                                 |
| ----------------- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `qm(1:nspec)`     | real    | Charge-to-mass ratio for each species.                                                                                                                                                                                                                                                                                                                      |
| `npin(1:nspec)`   | integer | Initial number of macro-particles per species inserted at the start of the run. Used to explicitly specify the total number of simulation particles (mutually exclusive with `[emissn].dnsf`).                                                                                                                                                                       |
| `np(1:nspec)`     | integer | Buffer or target particle count per species used during time advancement. If not explicitly set, this value defaults to `npin`. When the particle buffer becomes insufficient during the simulation (e.g., due to emission or boundary inflow), an error message will appear — in such cases, increase this parameter to allocate a larger particle buffer. |
| `path(1:nspec)`   | real    | Thermal velocity **parallel** to the background magnetic field **$\mathbf{B}_0$** (defined via `wc` and its orientation by `phixy`, `phiz`). Represents $v_{\mathrm{th},\parallel}$.                                                                                                                                                                        |
| `peth(1:nspec)`   | real    | Thermal velocity **perpendicular** to **$\mathbf{B}_0$**. Represents $v_{\mathrm{th},\perp}$.                                                                                                                                                                                                                                                               |
| `vdri(1:nspec)`   | real    | Magnitude of the bulk drift speed for each species.                                                                                                                                                                                                                                                                                                         |
| `vdthz(1:nspec)`  | real    | Zenith angle of the drift direction measured from the **z** axis (0° along +z).                                                                                                                                                                                                                                                                             |
| `vdthxy(1:nspec)` | real    | Azimuth of the drift direction in the **x–y** plane measured from the +x axis (counterclockwise).                                                                                                                                                                                                                                                           |
| `spa(1:nspec)`    | real    | Parallel drift velocity for each species in the distribution function (default: `0.0`). Enters the parallel distribution as: $f_\parallel \propto \exp\left(-\frac{(v - \mathrm{spa})^2}{2 \cdot \mathrm{path}^2}\right)$. |
| `spe(1:nspec)`    | real    | Perpendicular drift velocity for each species (default: `0.0`). |
| `speth(1:nspec)`  | real    | Direction (angle) of the perpendicular drift velocity (default: `0.0`). |
| `vdx(1:nspec)`, `vdy(1:nspec)`, `vdz(1:nspec)` | real | Cartesian components of the drift velocity for each species (default: `0.0`). An alternative to specifying drift via `vdri`/`vdthz`/`vdthxy`. |
| `vpa(1:nspec)`    | real    | Minimum of the parallel velocity distribution range (default: `-16.0`). Used for velocity-space binning in diagnostics. |
| `vpb(1:nspec)`    | real    | Maximum of the parallel velocity distribution range (default: `16.0`). |
| `vpe(1:nspec)`    | real    | Maximum of the perpendicular velocity distribution range (default: `32.0`). |
| `f(1:nspec)`      | real    | Loss cone factor (default: `1.0`). For isotropic distribution, `f = 1.0` and `peth = path`. If `0 < f < 1`, a loss-cone (subtracted Maxwellian) distribution is realized. |


---

### &ptcond — Surface and Conductor Boundaries

#### Basic Settings

| Parameter                    | Type          | Description                                                                                                                                                                                                                                                              |
| ---------------------------- | ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `npc(1:nspec)`, `npcg`                | integer       | Number of solid bodies (`npc`) and conducting bodies (`npcg`).                                                                                                                                                                                                           |
| `pcgs(1:npc)`, `ccgs(1:npc)` | integer array | Defines conductor grouping: indices of bodies that form a single electrically connected conductor. Each body is assigned to a conductor group via these arrays.                                                                                                          |
| `mtd_vchg(1:npc)`            | integer       | Specifies the potential treatment method for each body.<br>`0` = **floating** (potential evolves self-consistently through surface charging),<br>`-1` = **fixed** (held at a prescribed potential value).                                                                |
| `pfixed(1:npc)`              | real          | Fixed potential value applied when `mtd_vchg = -1`.                                                                                                                                                                                                                      |
| `biasp(1:npc)`               | real          | Alternative to `pfixed`, specifies a **bias potential** to be applied to each body. This parameter allows assigning a constant offset or bias voltage to conducting objects, effectively controlling their potential relative to other conductors or the ambient plasma. |
| `sfecrrct`                   | real          | Surface E-field correction factor (default: `0.0`). When non-zero, applies a correction to the electric field at the conductor surface. |
| `capacity_matrix_mode`       | integer       | Capacity matrix computation method (default: `5`, auto-derived from `modeww` if unset).<br>`1`: capacity matrix method is **not** used<br>`2`: build the capacity matrix from scratch at initialization<br>`3`: read a precomputed capacity matrix from `capacity_matrix.h5`<br>`4`: build in distributed row slices, invert on root rank, refresh `capacity_matrix.h5`, then reload in distributed form<br>`5`: keep a distributed LU factorization after the distributed build and use distributed solves at runtime<br>For large fixed-potential problems that may OOM with `2`, use `4` or `5`, or first generate `capacity_matrix.h5` with a smaller high-memory run and then use `3` for production runs. |
| `charge_accumulation`        | integer       | Whether to include charge accumulation on conductor surfaces (default: `1`, auto-derived from `modeww` if unset).<br>`1`: charge accumulation is considered<br>`0`: charge accumulation is not considered |
| `modeww`                     | integer       | **(Deprecated)** Capacity matrix mode. Retained for backward compatibility. A deprecation warning is printed when set. When `capacity_matrix_mode` and `charge_accumulation` are explicitly set, they take precedence over `modeww`.<br>`abs(modeww)` maps to `capacity_matrix_mode`; `modeww < 0` maps to `charge_accumulation = 1`; `modeww > 0` maps to `charge_accumulation = 0`. |
| `wirealign(1:npc)`           | integer       | Axis alignment for wire/boom geometry (`1`=x, `2`=y, `3`=z). Set to `0` (default) to disable wire geometry. |
| `wirehlength(1:npc)`         | real          | Half-length of the wire/boom along its alignment axis. |
| `wirerradius(1:npc)`         | real          | Physical (real) radius of the wire. |
| `wireeradius(1:npc)`         | real          | Effective (electrical) radius of the wire for potential computation. |
| `wireorigin(1:3, 1:npc)`     | real          | Origin coordinates (x, y, z) of each wire. |
| `boundary_se_model_type(nboundary_types, ispec)` | integer | SEE model type selector for each boundary and species (default: `0`).<br>`0` = Whipple (1981) empirical model (energy- and angle-dependent)<br>`1` = constant-yield model using `boundary_se_const_yield`. |
| `boundary_se_const_yield(nboundary_types, ispec)` | real   | Constant SEE yield (default: `0.0`). Used when a constant-yield model is selected via `boundary_se_model_type`. |

---

#### Body Geometry

Each solid or conducting body is defined by its **geometric type** (`geotype`) and corresponding parameters.

| Parameter        | Type    | Description                                                                                                             |
| ---------------- | ------- | ----------------------------------------------------------------------------------------------------------------------- |
| `id`             | string  | TOML only. Optional identifier for a `[[ptcond.objects]]` entry; `[[ptcond.boundaries]]` can reference it with `conductor_object`. |
| `geotype`        | integer | Specifies the geometric type of the body: <br>`0` or `1` = **Rectangular**, `2` = **Cylindrical**, `3` = **Spherical**. |
| `bdyalign`       | integer | Axis of symmetry for a cylindrical body (`1`=x, `2`=y, `3`=z). Ignored for other shapes.                                |
| `bdyradius`      | real(*) | Radius of the cylinder or sphere.                                                                                       |
| `bdyedge(1:2,*)` | real(*) | Lower and upper coordinates along the cylinder axis (for cylindrical bodies).                                           |
| `bdycoord`       | real(*) | Center coordinates of the cylinder or sphere.                                                                           |
| `{x,y,z}{l,u}pc` | real    | Lower (`l`) and upper (`u`) limits of the rectangular body along each direction (for `geotype = 0` or `1`).             |

---

#### Geometry Types (`geotype`)

The following table summarizes the geometric meaning and required parameters for each shape.

<table>
  <thead>
    <tr>
      <th style="text-align:center;">Geometry<br>(<code>geotype</code>)</th>
      <th style="text-align:center;">Illustration</th>
      <th style="text-align:left;">Description</th>
    </tr>
  </thead>
  <tbody>

  <!-- Rectangular -->
  <tr>
    <td style="text-align:center;"><b>Rectangular</b><br>(0 or 1)</td>
    <td style="text-align:center;">
      <img src="./assets/img/ptcond/rectangular.png" alt="Rectangular body" width="220"><br>
      <small>Defined by <code>{x,y,z}{l,u}pc</code></small>
    </td>
    <td>
      Defines a rectangular solid body extending from the lower bounds
      (<code>xlpc, ylpc, zlpc</code>) to the upper bounds
      (<code>xupc, yupc, zupc</code>).
      The enclosed region represents a solid or conducting object.
    </td>
  </tr>

  <!-- Cylindrical -->
  <tr>
    <td style="text-align:center;"><b>Cylindrical</b><br>(2)</td>
    <td style="text-align:center;">
      <img src="./assets/img/ptcond/cylinder.png" alt="Cylindrical body" width="220"><br>
      <small>Defined by <code>bdyalign, bdyedge, bdyradius, bdycoord</code></small>
    </td>
    <td>
      Defines a cylinder with axis orientation given by
      <code>bdyalign</code> (1 = x, 2 = y, 3 = z).
      The axial range is between <code>bdyedge(1,*)</code> and
      <code>bdyedge(2,*)</code>; radius = <code>bdyradius(*)</code>.
      The axis position in the perpendicular plane is specified by
      <code>bdycoord(1:2,*)</code>.
    </td>
  </tr>

  <!-- Spherical -->
  <tr>
    <td style="text-align:center;"><b>Spherical</b><br>(3)</td>
    <td style="text-align:center;">
      <img src="./assets/img/ptcond/sphere.png" alt="Spherical body" width="220"><br>
      <small>Defined by <code>bdycoord, bdyradius</code></small>
    </td>
    <td>
      Defines a spherical body centered at
      (<code>bdycoord(1,*)</code>, <code>bdycoord(2,*)</code>,
      <code>bdycoord(3,*)</code>) with radius
      <code>bdyradius(*)</code>.
      Typically used for isolated spherical conductors or dust particles.
    </td>
  </tr>

  </tbody>
</table>

---

#### Finbound Extension (Additional Parameters)

All parameters below belong to the **`&ptcond`** group and are provided by the `finbound` module.
They enable **fine-grained control** over complex internal boundaries and composite geometries, such as holes, cavities, and internal surfaces.

---

##### A. Top-level selector

| Parameter       | Type          | Description                                                                                                                                                                                                        |
| --------------- | ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `boundary_type` | character(30) | **(Deprecated)** Defines the overall inner-boundary type for a single body (default: `complex`). A deprecation warning is printed when set. Supported values:<br>`none`, `flat-surface`, `rectangle-hole`, `dent-rectangle-hole`, `cylinder-hole`, `hyperboloid-hole`, `ellipsoid-hole`, `complex`.<br>Use `boundary_types` (with `[[ptcond.boundaries]]`) instead. |

> Use `boundary_types` to construct multiple sub-boundaries (default mode, `boundary_type = 'complex'`).

---

##### B. Parameters for `'****-surface' / '****-hole'` modes

| Parameter        | Type | Used by                                                     | Description                                                                                                                                                                                       |
| ---------------- | ---- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `zssurf`         | real | `flat-surface`, `*-hole`                                    | Surface height along **z** (grid units). For holes, used as the upper plane position.                                                                                                             |
| `zsbuf`          | real | `flat-surface`, `*-hole`                                    | Define the region where particles are not initially placed as follows: `particle%z <= zssurf + zsbuf` |
| `[x/y/z][l/u]pc` | real | `*-hole`                                                    | Lower (`l`) and upper (`u`) limits of the hole along each axis (grid units), e.g., `xlpc, xupc, ylpc, yupc, zlpc, zupc`.                                                                          |
| `rcurv`          | real | `hyperboloid-hole`, `ellipsoid-hole`, `dent-rectangle-hole` | Curvature ratio that defines the **minimum radius** relative to the entrance radius of the hole. For example, `rcurv = 1.0` means `r_min = r_max`, and `rcurv = 0.5` means `r_min = 0.5 × r_max`. |

> **Notes**
> - The shapes `rectangle-hole`, `cylinder-hole`, `hyperboloid-hole`, and `ellipsoid-hole` automatically generate bottom, wall, and top surfaces.
> - `dent-rectangle-hole` represents a tapered or concave rectangular hole whose degree of contraction is controlled by `rcurv`.

---

##### C. Complex mode (composite boundaries)

When `boundary_type = 'complex'`, individual sub-boundaries are listed in `boundary_types(1:nboundary_types)` with corresponding geometry parameters.
This mode allows multiple simple primitives (planes, holes, disks, cylinders, etc.) to coexist in a single conductor.

**Supported entries for `boundary_types(*)`:**

- **Planes:** `rectangle`, `rectangle-corners`
- **Circles:** `circlex`, `circley`, `circlez`
- **Cuboid (closed box):** `cuboid`
- **Sphere:** `sphere`
- **Cylinders (closed):** `cylinderx`, `cylindery`, `cylinderz`
- **Cylinders (open wall only):** `open-cylinderx`, `open-cylindery`, `open-cylinderz`
- **Annular disks (finite thickness):** `diskx`, `disky`, `diskz`
- **Single plane with a circular hole:** `plane-with-circlex`, `plane-with-circley`, `plane-with-circlez`

| Parameter                                                                 | Type                | Applies to                            | Description                                                                                                                                                               |
| ------------------------------------------------------------------------- | ------------------- | ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `boundary_types(1:nboundary_types)`                                       | character(30) array | complex                               | List of sub-boundary types as described above.                                                                                                                            |
| `boundary_conductor_id(1:nboundary_types)`                                | integer             | complex                               | Conductor ID (`ipc`) associated with each sub-boundary for charge assignment.                                                                                             |
| `conductor_object`                                                        | string              | `[[ptcond.boundaries]]`               | TOML only. References a `[[ptcond.objects]]` `id` and is converted to `boundary_conductor_id` while reading the input. Mutually exclusive with `boundary_conductor_id`. |
| `rectangle_shape(6, nbt)`                                                 | real                | `rectangle`                           | Defines an axis-aligned planar rectangle by its extents `(xmin, xmax, ymin, ymax, zmin, zmax)`. One dimension must collapse (e.g., `zmin = zmax`), creating a flat face on that plane. |
| `rectangle_corners(3, 4, nbt)`                                            | real                | `rectangle-corners`                   | Defines an arbitrarily oriented planar rectangle using four corner points. Each corner is `[x, y, z]`; in TOML use `rectangle_corners = [[x1, y1, z1], ..., [x4, y4, z4]]`. |
| `cuboid_shape(6, nbt)`                                                    | real                | `cuboid`                              | Defines a closed box with bounds `(xmin, xmax, ymin, ymax, zmin, zmax)`. All six faces are automatically generated.                                                       |
| `sphere_origin(3, nbt)`, `sphere_radius(nbt)`                             | real                | `sphere`                              | Center coordinates and radius of a spherical object.                                                                                                                      |
| `circle_origin(3, nbt)`, `circle_radius(nbt)`                             | real                | `circlex/y/z`                         | Center and radius of a circular patch lying on a plane normal to x, y, or z.                                                                                              |
| `cylinder_origin(3, nbt)`, `cylinder_radius(nbt)`, `cylinder_height(nbt)` | real                | `cylinderx/y/z`, `open-cylinderx/y/z` | Base (lower) origin, radius, and height along the selected axis. `open-cylinder*` generates the **lateral wall only** (no end caps).                                      |
| `disk_origin(3, nbt)`, `disk_height(nbt)`                                 | real                | `diskx/y/z`                           | Base position and thickness (height) of an annular disk.                                                                                                                  |
| `disk_radius(nbt)`, `disk_inner_radius(nbt)`                              | real                | `diskx/y/z`                           | Outer and inner radii of the annular disk.                                                                                                                                |
| `plane_with_circle_origin(3, nbt)`, `plane_with_circle_radius(nbt)`       | real                | `plane-with-circlex/y/z`              | Center coordinates and radius of a plane that contains a circular hole, oriented normal to x, y, or z.                                                                    |

> **Implementation details:**
> - `cylinder*` creates the sidewall and both end caps.
> - `open-cylinder*` generates the sidewall only (no caps).
> - `disk*` constructs two annular surfaces and inner/outer cylindrical walls, representing a solid ring.
> - `plane-with-circle*` represents a single plane with a circular aperture — suitable for thin, perforated surfaces.
> - Use `cuboid` for finite-thickness rectangular blocks or plates. `rectangle` is a planar rectangle with exactly one collapsed axis.

---

##### D. Plane-with-Circle Hole (non-complex vertical stack)

When `boundary_type ≠ 'complex'`, a standalone configuration of stacked circular plates can be defined using the following parameters (used internally by `add_plane_with_circle_hole`):

| Parameter                            | Type | Description                                                       |
| ------------------------------------ | ---- | ----------------------------------------------------------------- |
| `plane_with_circle_hole_zlower(nbt)` | real | Lower z-position of the stack (grid units).                       |
| `plane_with_circle_hole_height(nbt)` | real | Vertical distance between the lower and upper planes (thickness). |
| `plane_with_circle_hole_radius(nbt)` | real | Radius of the circular hole on both upper and lower planes.       |

> This configuration automatically creates three surfaces: a **lower perforated plane**, a **cylindrical sidewall**, and an **upper perforated plane**.

#### E. Surface Reflection and Secondary Electron Emission

These parameters define **particle–surface interaction models** for each boundary element (`nboundary_types`) and particle species (`ispec`).
They include reflection characteristics and secondary electron emission (SEE) following particle impact.

| Parameter                                                    | Type    | Description                                                                                                                                           |
| ------------------------------------------------------------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `boundary_mirror_reflection_rate(nboundary_types, ispec)`    | real    | Probability (0–1) that an incident particle is reflected **specularly** (mirror-like).                                                                |
| `boundary_reversal_reflection_rate(nboundary_types, ispec)`  | real    | Probability (0–1) that an incident particle undergoes **velocity reversal** reflection (backscattering).                                              |
| `boundary_mirror_reflect_alpha(nboundary_types, ispec)`      | real    | Surface roughness parameter (α) for **specular reflection** following the Beckmann distribution. Typical regolith surfaces correspond to α ≈ 0.3–0.5. |
| `boundary_reversal_reflect_alpha(nboundary_types, ispec)`    | real    | Roughness parameter for the **reversal-type reflection**, similar in meaning to the above.                                                            |
| `boundary_mirror_reflect_energy_loss_frac(nboundary_types, ispec)` | real | Fraction of **kinetic energy lost** during specular reflection. The post-collision energy is reduced as $E' = (1 - \mathrm{loss\_frac}) E$, corresponding to a velocity scaling $v' = \sqrt{1 - \mathrm{loss\_frac}}v$. |
| `boundary_reversal_reflect_energy_loss_frac(nboundary_types, ispec)` | real | Fraction of **kinetic energy lost** during reversal (backscattering) reflection. Same scaling relation applies as above. |
| `enable_secondary_electron_emission(nboundary_types, ispec)` | logical | Enables **secondary electron emission (SEE)** for the specified surface and particle species.                                                         |
| `boundary_se_yield_max(nboundary_types, ispec)`              | real    | Maximum SEE yield $\delta_{max}$ (number of emitted electrons per incident electron at optimal energy).                                                         |
| `boundary_se_energy_max(nboundary_types, ispec)`             | real    | Incident energy $E_{max}$ [eV in EMSES Unit] at which δ = δₘₐₓ. eV.                                                                                        |
| `boundary_se_species_id(nboundary_types, ispec)` | integer | Particle-species ID to be used for emitted **secondary electrons**. Default is `1`, corresponding to the electron species. |

**Secondary electron yield model:**
When SEE is enabled, the yield $\delta(E, θ)$ is computed following the empirical expression proposed by **Whipple (1981)** and adopted in **Marchand et al. (2014, Phys. Plasmas 21, 062901)**, Eq. (2):

$$
\delta(E,\theta) =
\frac{1.114\delta_{\max}}{\cos\theta}
\left(\frac{E_{\max}}{E}\right)^{0.35}
\left\{1 - \exp\left[-2.28\cos\theta
\left(\frac{E}{E_{\max}}\right)^{1.35}\right]\right\}
$$

Here $\delta_{max}$ and $E_{max}$ correspond to `boundary_se_yield_max` and `boundary_se_energy_max`.
This model accounts for both the energy E and the incidence angle θ of incoming electrons, providing realistic SEE behavior across different surface materials.

> **Notes**
> - Reflection and SEE probabilities are applied after impact detection for each species.
> - The Beckmann parameter α controls the angular width of reflected distributions; smaller α → more diffuse scattering.
> - For lunar regolith–like surfaces, α ≈ 0.3–0.5 is typically appropriate (to be verified experimentally).
> - `boundary_mirror_reflect_energy_loss_frac` and `boundary_reversal_reflect_energy_loss_frac` allow modeling of inelastic surface interactions that dissipate particle energy upon reflection.
> - `boundary_se_species_id` allows flexibility when defining SEE emission from mixed-material or multi-species configurations.

---

### &gradema

| Parameter              | Type | Default | Description                                                                                                                                                                                                                                                                                                                                             |
| ---------------------- | ---- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `grad_coef(1:10)`     | real | 1.0     | Coefficient controlling the rate of surface-charging evolution (array of up to 10 segments, selected by `coef_start`). It scales the amount of charge accumulated or released on the surface per time step. In other words, the surface charge density is updated as <br><code>rhobk(t) = rhobk(t-1) + grad_coef * EMA(t)</code>, where `EMA(t)` is the exponential moving average of the current flowing into the surface. The same EMA and coefficient are also applied to influx/outflux charge increments added to conductor `chgacm`. |
| `smooth_coef(1:10)`   | real | 1.0     | EMA smoothing coefficient. Controls the smoothing weight applied to the incremental surface charge: <br><code>EMA(t) = (1 - smooth_coef) * EMA(t-1) + smooth_coef * drhobk(t)</code>. |
| `grad_coef2(1:10)`    | real | 1.0     | Secondary gradient coefficient used in `"linear"` and `"bezier"` gradient types for spatially varying acceleration. |
| `coef_start(1:10)`    | real | 1.0     | Fractional time thresholds (relative to `nstep`) that select which segment of `grad_coef`/`smooth_coef` to use. The first segment whose `coef_start(i) > istep/nstep` is applied. |
| `grad_type`           | character(30) | `"constant"` | Gradient mode: `"constant"` (spatially uniform), `"linear"` (linearly varying with z), or `"bezier"` (Bezier curve interpolation with z). Spatial-gradient endpoints use the whole simulation z range, not `zssurf` / `zlrechole`. |

---

### &dipole

Defines **embedded magnetic dipole sources** used to introduce localized magnetic fields inside the simulation domain.

| Parameter                                | Type    | Description                                                   |
| ---------------------------------------- | ------- | ------------------------------------------------------------- |
| `nmd`                                    | integer | Number of magnetic dipoles (maximum 10).                      |
| `md(1:nmd)`                              | real    | Magnetic dipole moment magnitude for each dipole.             |
| `mdx(1:nmd)`, `mdy(1:nmd)`, `mdz(1:nmd)` | real    | Coordinates specifying the position (center) of each dipole. |
| `mddir(1:nmd)`                           | integer | Dipole orientation: `0` = x-axis, `1` = y-axis, `2` = z-axis. |
| `mode_dipole`                            | integer | Dipole/gap-drive mode selector (default: `0`).<br>`0` = disabled<br>`1` = legacy gap-feed setup<br>`2` = current-source gap drive<br>`3` = lumped-element (`resc`/`capc`) gap drive. |
| `ngap`                                   | integer | Number of antenna gap feed points (default: `0`, maximum 4). |
| `i_gap(1:ngap)`, `j_gap(1:ngap)`, `k_gap(1:ngap)` | integer | Grid indices (x, y, z) specifying the position of each gap feed point. |
| `w_c`                                    | real    | Center frequency for pulsed excitation at the gap (default: `0.0`). If negative, a monochromatic frequency is used instead. |
| `resc(1:ngap)`                           | real    | Resistance at each gap feed point (default: `-1.0`). Negative values indicate no resistive loading. |
| `capc(1:ngap)`                           | real    | Capacitance at each gap feed point (default: `0.0`). |

---

### &emissn — Particle Emission

Defines the emission properties of charged particles (e.g., electrons or ions) from internal or external surfaces.

---

#### ① Common Parameters (always applicable)

| Parameter                                  | Type    | Description                                                                                                                                                                                                                                                                    |
| ------------------------------------------ | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `nflag_emit(1:nspec)`                      | integer | Specifies the emission type for each particle species.<br>`0` = external emission (from domain boundary)<br>`1` = internal emission (from internal surfaces)<br>`2` = internal emission with **ray-casting mode** (surface exposure to illumination determines emission area)<br>`3` = **secondary electron emission** (SEE: electrons emitted upon surface impact). |
| `curf(1:nspec)`                            | real    | Base emission current density for each species.                                                                                                                                                                                                                                |
| `dnsf(1:nspec)`                            | real    | Forward macro-particle division count for emission. Larger values create more particles with smaller weight. When `npin` is not set, it is also used to determine particle charge, so do not use it together with `npin`.                                                                                 |
| `emission_leave_anti_particle(1:nspec)`    | logical | If `.true.`, leaves an anti-particle (with opposite charge) at the emission site to maintain charge neutrality. Default is `.true.`.                                                                                                                                           |
| `emission_time_mode(1:nspec)`              | integer | Temporal variation mode of emission: `0` = constant, `1` = Gaussian.                                                                                                                                                                                                           |
| `emission_start_step(1:nspec)`, `emission_end_step(1:nspec)` | integer | Start and end time steps for particle emission.                                                                                                                                                                                                                                |
| `emission_time_sigma(1:nspec)`             | real    | Standard deviation for Gaussian emission-time variation.                                                                                                                                                                                                                       |

---

#### ② Explicit Emission-Surface Parameters
*(used when `(nflag_emit == 1)` **or** `(nflag_emit == 2 .and. pe_ray_cast = .false.)`)*

| Parameter                                  | Type           | Description                                                                                                                                                             |
| ------------------------------------------ | -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `nepl(1:nspec)`                                     | integer        | Number of emission surfaces.                                                                                                                                            |
| `curfs(1:nepl)`                            | real           | Per-surface emission current density. Takes precedence over `curf`.                                                                                                     |
| `nemd(1:nepl)` | integer | Emission direction: specifies the normal axis of the emission surface.<br>`±1` = x-normal, `±2` = y-normal, `±3` = z-normal.<br>The sign determines the emission direction (positive or negative along the axis). |
| `xmaxe(1:nepl)`, `xmine(1:nepl)`, `ymaxe(1:nepl)`, `ymine(1:nepl)`, `zmaxe(1:nepl)`, `zmine(1:nepl)` | integer | Defines the **rectangular bounds** of each emission surface in grid coordinates.<br>Each surface is defined as a flat rectangular region **perpendicular to the direction specified by `nemd`**.<br><br>For example:<br>- If `nemd = ±3` (surface normal along the z-axis), then set `zmine = zmaxe` to specify the z-plane position, and define the in-plane extent using `xmine/xmaxe` and `ymine/ymaxe`.<br>- Similarly, for `nemd = ±1`, set `xmine = xmaxe` and use y–z limits; for `nemd = ±2`, set `ymine = ymaxe` and use x–z limits.<br>This configuration allows defining multiple emission patches oriented along any of the three Cartesian directions. |
| `ipcpl(1:nepl)`                            | integer        | Conductor ID associated with each emission surface. When a particle is emitted, an equal and opposite charge is accumulated on this conductor to conserve total charge. |

---

#### ③ Ray-Casting Emission Parameters
*(used when `nflag_emit == 2` and `pe_ray_cast = .true.`)*

| Parameter                        | Type    | Description                                                                                                                                                                                                                                                                                                                                      |
| -------------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `pe_ray_cast`                    | logical | Enables **solar-illumination-based emission** using ray-casting. The emission position is determined by ray intersection with surfaces defined in `boundary_types`, allowing emission from complex geometries without explicit region specification.                                                                                             |
| `ray_zenith_angle_deg(1:nspec)`  | real    | Solar zenith angle in degrees. Defines the inclination of the incoming rays.                                                                                                                                                                                                                                                                     |
| `ray_azimuth_angle_deg(1:nspec)` | real    | Solar azimuth angle in degrees. Defines the horizontal orientation of the incoming rays.                                                                                                                                                                                                                                                         |
| `periodic_raycast`               | logical | If `.true.`, enables **periodic ray-casting**. During evaluation, boundaries defined by `boundary_types` (surface boundaries and objects) are virtually duplicated in the horizontal (xy) plane to simulate periodic shading. `plane-with-circle[x/y/z]` is treated as an infinite plane and is not duplicated. <br>The number of duplicates is determined by the smaller of <code>tan(zenith_angle) × max_boundary_height</code> and <code>max_periodic_shift</code>. |
| `max_boundary_height`            | real    | Maximum vertical height used to estimate the duplication count for periodic ray-casting.                                                                                                                                                                                                                                                         |
| `max_periodic_shift`             | real    | Maximum horizontal shift allowed when duplicating boundary objects for periodic ray-casting.                                                                                                                                                                                                                                                     |

---

#### Notes

- Parameters in group **(②)** and **(③)** are mutually exclusive depending on `pe_ray_cast`.
- When `nflag_emit = 0`, emission occurs only from the outer simulation boundary and parameters in (②) and (③) are ignored.

---

### &inp — Particle Injection Boundaries

Defines particle injection from the simulation domain boundaries along the x-axis.

| Parameter       | Type    | Description                                                                                                                                                |
| --------------- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lower_x_boundary_injection_enabled(1:nspec)` (`inpf`) | integer | Injection flag at the lower x-boundary (`x = 0`).<br>`0` = no injection (default)<br>`1` = particles are injected from the lower x-boundary.             |
| `upper_x_boundary_injection_enabled(1:nspec)` (`inpb`) | integer | Injection flag at the upper x-boundary (`x = slx`).<br>`0` = no injection (default)<br>`1` = particles are injected from the upper x-boundary.           |
| `injection_interval(1:nspec)` (`injct`) | integer | Time-step interval between successive particle injections for each species (default: `0`). A value of `0` disables periodic injection.                   |
| `injection_sample_count(1:nspec)` (`npr`) | integer | Number of standard distribution samples used for generating injected particles (default: `0`).                                                            |

---

### &testch — Test Charges

Defines static or distributed test charges placed in the simulation domain. Test charges impose a fixed charge distribution that contributes to the electrostatic potential without being moved by the fields.

| Parameter               | Type    | Description                                                                                                       |
| ----------------------- | ------- | ----------------------------------------------------------------------------------------------------------------- |
| `ntch`                  | integer | Number of test charge sources (default: `0`, maximum 4).                                                          |
| `rtch(1:3, 1:ntch)`     | real    | Position (x, y, z) of each test charge in grid coordinates.                                                       |
| `qtch(1:ntch)`          | real    | Charge magnitude of each test charge (default: `0.0`).                                                            |
| `e1tch(1:ntch)`         | real    | Electric field amplitude parameter for each test charge (default: `0.0`).                                         |
| `p1tch(1:ntch)`         | real    | Potential parameter for each test charge (default: `0.0`).                                                        |
| `rcutoff(1:ntch)`       | real    | Cutoff radius for the test charge potential (default: machine epsilon). Prevents singularity at the charge center. |
| `nqclst`                | integer | Number of charge cluster sources (default: `0`). Enables spatially distributed charge configurations.             |
| `dimclst(1:3, 1:ntch)`  | integer | Dimensions (nx, ny, nz) of each charge cluster in grid cells (default: `1,1,1`).                                  |
| `rclst(1:5, 1:ntch)`    | real    | Cluster geometry parameters: `(1:3)` = center position (x, y, z), `(4)` = spacing factor (default: `1.0`), `(5)` = extent parameter (default: `10.0`). |
| `rhopeak(1:ntch)`       | real    | Peak charge density of the cluster (default: `0.0`).                                                              |

---

### &jsrc — Current Source

Defines localized oscillating current sources placed at specific grid points. These sources inject a prescribed sinusoidal current density into the simulation.

| Parameter              | Type    | Description                                                                                       |
| ---------------------- | ------- | ------------------------------------------------------------------------------------------------- |
| `njs`                  | integer | Number of current sources (default: `0`, maximum 4).                                              |
| `rjs(1:3, 1:njs)`      | integer | Grid position (x, y, z) of each current source.                                                   |
| `ajs(1:3, 1:njs)`      | real    | Amplitude of the current density (Jx, Jy, Jz) for each source (default: `0.0`).                  |
| `wjs(1:njs)`           | real    | Angular frequency of the oscillating current source (default: `1.0`).                             |
| `th0js(1:njs)`         | real    | Initial phase (in radians) of the oscillating current (default: `0.0`).                           |

---

### &verbose — Verbosity and Debugging Control

Controls the level of diagnostic output printed during simulation execution.

| Parameter         | Type    | Default | Description                                                                         |
| ----------------- | ------- | ------- | ----------------------------------------------------------------------------------- |
| `EMSES_verbose`   | integer | `0`     | Verbosity level for the main EMSES simulation code. Higher values produce more output. |
| `OHHELP_verbose`  | integer | `0`     | Verbosity level for the OHHELP (Poisson solver) library.                            |
| `OHHELP_stats`    | integer | `0`     | If non-zero, prints performance statistics from the OHHELP solver.                  |
| `OHHELP_repiter`  | integer | `0`     | If non-zero, reports iteration counts from the OHHELP solver.                       |
| `hdf_io_trace`    | integer | `0`     | If non-zero, prints HDF5 diagnostic open/write/flush/close breadcrumbs from rank 0 to stderr. Use this to locate where HDF5 I/O stalls. |

---

## Auxiliary and Legacy-Compatible Parameters Accepted by the Implementation

The following parameters are currently accepted by `src/main/config/input/namelist_reader.F90` but are only summarized in the main sections above. They include legacy KEMPO/EMSES compatibility fields, special diagnostics, special boundaries, and antenna/wave-drive controls.

| Group | Parameters | Purpose |
|---|---|---|
| `&real` | `deltax`, `deltat`, `massratio`, `density`, `etemp`, `itemp`, `phtemp`, `flowvx`, `flowvy`, `flowvz`, `magb`, `jph` | Legacy `plasma.preinp` physical-value inputs. For normal `plasma.toml` workflows, prefer `[meta.physical]` plus `emu apply`. |
| `&realcv` | `cvsim`, `weightph` | Legacy preinp normalized light speed and photoelectron weight. |
| `&jobcon` | `lstep`, `maxt` | Continuation/stop controls. `lstep` is the already-completed step for restart; `maxt` is the maximum runtime [min]. |
| `&digcon` | `i1hdf`, `i2hdf`, `i3hdf`, `idim_sp`, `iadiag`, `field_average_window` (`daverg`), `nvx`, `nvy`, `nvz`, `ikxmax`, `ikymax`, `ikzmax`, `emarlxt` | Detailed output controls for HDF5 splitting, spatial/velocity/wavenumber diagnostics, time averaging, and current exponential moving averages. |
| `&plasma` | `denmod`, `denk`, `omegalw` | Per-species density and low-frequency modulation parameters. Also available through `[[species]]`. |
| `&tmgrid` | `dtf` | Auxiliary field-update timestep. |
| `&system` | `background_ion_charge_mode` (`ionchg`), `jxfltr`, `jyfltr`, `jzfltr`, `ipexfl`, `ipeyfl`, `ipezfl`, `nfltrx`, `nfltry`, `nfltrz`, `xlcol`, `xucol`, `ylcol`, `yucol`, `zlcol`, `zucol`, `mfpath`, `electrostatic_correction_mode` (`nflag_ecrct`), `poisson_solver_mode` (`pftmode`), `potential_reference_indices` (`iphiref`), `boundary_conditions` | Background charge, field/current filters, collision regions, mean free path, electric-field correction, reference potential, and detailed boundary-condition controls. |
| `&intp` | `nphi`, `ndst`, `ioptd`, `lcgamma`, `lcbeta` | Velocity-distribution diagnostics and loss-cone distribution controls. |
| `&others` | `tcs`, `cs` | Legacy collision cross-section parameters. |
| `&ptcond` | `epc2`, `amu2`, `sigma`, `nxpc1`, `nypc1`, `nzpc1`, `nxpc2`, `nypc2`, `nzpc2`, `nflag_subcell`, `biasc`, `dscaled`, `bcval`, `bcfrom`, `bcto`, `xc`, `yc`, `zc`, `rc`, `isse`, `pemax`, `deltaemax`, `mingap`, `pswper`, `pswstr`, `pswspn`, `pswini`, `v_omega`, `v_max`, `wrelax`, `oradius`, `xbowlc`, `ybowlc`, `zbowlc`, `rbowl`, `xdomec`, `ydomec`, `zdomec`, `rdome`, `xholec`, `yholec`, `rhole`, `lbhole`, `ubhole`, `flhole`, `xlrechole`, `ylrechole`, `zlrechole`, `xurechole`, `yurechole`, `zurechole`, `conductivity`, `max_bounce_count` | Legacy conductor-boundary geometry, subcells, conductor connections, fixed/oscillating potential, capacity matrix, surface conductivity, and maximum reflection iteration controls. For new complex geometry, prefer `[[ptcond.boundaries]]` / `[[ptcond.objects]]`. |
| `&wave` | `nwave`, `twave`, `ebamp`, `ldwv`, `orgwv`, `angwv` | Legacy incident-wave / external-wave settings. |
| `&scrnt` | `imode`, `omegatw`, `lambdatw`, `amptw`, `thetatw` | Legacy screen/current-drive and test-wave settings. |
| `&dipole` | `f_c`, `line_mode`, `n_shth_rgn`, `ajs_amp`, `pgamp`, `ifeedst`, `ifeeded`, `nstp_oe`, `xbpcc1`, `xbpcc2`, `ybpcc1`, `ybpcc2`, `zbpcc1`, `zbpcc2`, `zbpcc3`, `zbpcc4`, `zbpcc5`, `zbpcc6`, `zbpcc7`, `zbpcc8`, `xline`, `yline`, `Ew0`, `Ew`, `omegaw`, `ewmodel`, `nretard` | Antenna, feeding, sheath-region, external-wave, and retarded-waveform controls. |
| `&emissn` | `decrease_current_according_to_incident_angle`, `flpf`, `flpb`, `curb`, `qp`, `qpr`, `abvdem`, `dnsf`, `dnsb`, `imarea`, `omniemit`, `flpfs`, `flpbs`, `curbs`, `dnsfs`, `dnsbs`, `remf`, `remb`, `peject`, `thetaz`, `thetaxy`, `plreloc`, `mainprop` | Emission flux, backward emission, charge/weight, area mode, omni-directional emission, per-plane overrides, and emission velocity distribution controls. |
| `&testch` | `dimclst`, `rclst`, `rhopeak` | Charge-cluster source shape and peak density. |
| `&gradema` | `control_grad_coef` | Control coefficients for `"bezier"` and related gradient modes. |

---

## Input File Examples

### Recommended: `plasma.toml`

```toml
[meta.unit_conversion]
dx = 0.5
to_c = 10000.0

[esorem]
emflag = 0

[jobcon]
jobnum = [0, 1]
nstep = 100000

[plasma]
wp = [0.5950738, -1.0]
wc = 0.0
cv = 10000.0

[tmgrid]
dt = 0.01
nx = 128
ny = 128
nz = 128
dr = 1.0
```

A JSON Schema ([`schema/plasma.schema.json`](../schema/plasma.schema.json)) is available; editors can reference it with `#:schema ../schema/plasma.schema.json`. For schema publication details, see [SPEC.md](../SPEC.md).

### Backward-compatible: `plasma.inp`

```fortran
&esorem
  emflag = 0
/

&jobcon
  jobnum = 0, 1
  nstep  = 100000
/

&plasma
  wp = 0.5950738d0, -1.0d0
  wc = 0.0d0
  cv = 10000.0d0
/

&tmgrid
  dt = 0.01d0
  nx = 128; ny = 128; nz = 128
  dr = 1.0d0
/

... (continued)
```

---

**Further References:**
For detailed implementation notes and advanced configuration examples, refer to the *EMSES User Guide* and inline source-code comments, especially `src/main/config/input/input_parameters.F90`, `src/main/config/input/namelist_reader.F90`, `src/physics/collision/surfaces.F90`, and `src/physics/collision/particle_collision.F90`.


#### FFT-based free-space Poisson solvers (Open boundary)
- Zou, Junyi, Eugenia Kim, and Antoine J. Cerfon. 2021. “FFT-Based Free Space Poisson Solvers: Why Vico-Greengard-Ferrando Should Replace Hockney-Eastwood.” arXiv:2103.08531.
- Vico, Francesco, Leslie Greengard, and Miguel Ferrando. 2016. “Fast Convolution with Free-Space Green’s Functions.” *Journal of Computational Physics* 323: 191–203.
- Eastwood, James W., and David R. K. Brownrigg. 1979. “Remarks on the Solution of Poisson’s Equation for Isolated Systems.” *Journal of Computational Physics* 32: 24–38. (HE family)
- Hockney, R. W., and J. W. Eastwood. *Computer Simulation Using Particles*. McGraw-Hill (1981); Adam Hilger / IOP Publishing (1988).
---

### Reference Models

For practical examples of parameter configurations and typical simulation setups,
see [`cookbook/examples/`](../cookbook/examples/) and [`cookbook/index.toml`](../cookbook/index.toml) in this repository.
