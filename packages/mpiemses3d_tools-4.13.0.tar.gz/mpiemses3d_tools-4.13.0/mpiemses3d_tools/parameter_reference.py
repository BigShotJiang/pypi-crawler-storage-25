"""Lightweight parameter reference lookup for MPIEMSES3D tools.

The source of truth remains the bundled Markdown references copied from
``docs/Parameters*.md`` and ``docs/FormatV2*.md``.  This module parses just
enough of those tables to answer focused CLI queries without loading the full
documents into an agent prompt.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib import resources
import re
from typing import Iterable

REFERENCE_PACKAGE = "mpiemses3d_tools.reference_docs"


@dataclass
class ParameterEntry:
    """One parameter row extracted from a reference table."""

    name: str
    aliases: list[str] = field(default_factory=list)
    legacy_groups: list[str] = field(default_factory=list)
    v2_locations: list[str] = field(default_factory=list)
    type_name: str = ""
    description: str = ""


@dataclass
class GroupEntry:
    """One legacy namelist group or format_version=2 table."""

    name: str
    display_name: str
    description: str = ""
    kind: str = "legacy"
    parameters: list[str] = field(default_factory=list)


@dataclass
class ReferenceIndex:
    """Parsed parameter and group index."""

    language: str
    groups: dict[str, GroupEntry] = field(default_factory=dict)
    parameters: list[ParameterEntry] = field(default_factory=list)
    by_lookup: dict[str, list[ParameterEntry]] = field(default_factory=dict)

    def add_group(self, group: GroupEntry) -> None:
        self.groups.setdefault(_normalize_lookup(group.name), group)

    def add_parameter(self, entry: ParameterEntry) -> None:
        self.parameters.append(entry)
        for group_name in entry.legacy_groups:
            group = self.groups.get(_normalize_lookup(group_name))
            if group is not None and entry.name not in group.parameters:
                group.parameters.append(entry.name)
        for location in entry.v2_locations:
            group = self.groups.get(_normalize_lookup(location))
            if group is not None and entry.name not in group.parameters:
                group.parameters.append(entry.name)

        for name in _lookup_names(entry):
            self.by_lookup.setdefault(_normalize_lookup(name), []).append(entry)

    def find_group(self, target: str) -> GroupEntry | None:
        return self.groups.get(_normalize_lookup(_strip_group_syntax(target)))

    def find_parameters(self, target: str) -> list[ParameterEntry]:
        return self.by_lookup.get(_normalize_lookup(_strip_group_syntax(target)), [])


def load_reference(language: str = "ja") -> ReferenceIndex:
    """Load the bundled parameter reference index.

    ``language`` accepts ``"ja"``/``"en"`` prefixes.  Unknown languages fall
    back to Japanese because the project documentation is Japanese-first.
    """

    lang = "en" if language.lower().startswith("en") else "ja"
    params_name = "Parameters.en.md" if lang == "en" else "Parameters.md"
    format_name = "FormatV2.en.md" if lang == "en" else "FormatV2.md"

    index = ReferenceIndex(language=lang)
    _parse_parameters_md(_read_reference(params_name), index)
    _parse_format_v2_md(_read_reference(format_name), index)
    return index


def describe_target(target: str, language: str = "ja") -> str:
    """Return a user-facing description for a group or parameter."""

    index = load_reference(language)
    group = index.find_group(target)
    if group is not None:
        return _format_group(group, index)

    entries = index.find_parameters(target)
    if entries:
        return _format_parameter_entries(target, entries, index.language)

    return _not_found(target, index)


def _read_reference(name: str) -> str:
    files = getattr(resources, "files", None)
    if files is not None:
        return files(REFERENCE_PACKAGE).joinpath(name).read_text(encoding="utf-8")
    return resources.read_text(REFERENCE_PACKAGE, name, encoding="utf-8")


def _parse_parameters_md(text: str, index: ReferenceIndex) -> None:
    for group_name, description in _parse_namelist_group_overview(text):
        index.add_group(
            GroupEntry(
                name=group_name,
                display_name=f"&{group_name}",
                description=description,
                kind="legacy",
            )
        )

    for group_name, title, body in _iter_legacy_group_sections(text):
        if _normalize_lookup(group_name) not in index.groups:
            index.add_group(
                GroupEntry(
                    name=group_name,
                    display_name=f"&{group_name}",
                    description=_clean_text(title),
                    kind="legacy",
                )
            )

        for table in _iter_tables(body):
            if not table:
                continue
            header = table[0]
            if not header:
                continue
            first_header = _clean_text(header[0]).lower()
            if not _looks_like_parameter_header(first_header):
                continue
            type_index = _find_header_index(header, ("型", "type"))
            description_index = _find_header_index(header, ("説明", "description"))
            if description_index is None:
                description_index = len(header) - 1

            for row in table[1:]:
                if not row or _is_separator_row(row):
                    continue
                names = _extract_parameter_names(row[0])
                if not names:
                    continue
                type_name = (
                    _clean_text(row[type_index])
                    if type_index is not None and type_index < len(row)
                    else ""
                )
                description = (
                    _clean_text(row[description_index])
                    if description_index < len(row)
                    else ""
                )
                primary = names[0]
                aliases = _unique(
                    [
                        name
                        for name in names[1:] + [_base_name(name) for name in names]
                        if name != primary
                    ]
                )
                index.add_parameter(
                    ParameterEntry(
                        name=primary,
                        aliases=aliases,
                        legacy_groups=[group_name],
                        type_name=type_name,
                        description=description,
                    )
                )


def _parse_format_v2_md(text: str, index: ReferenceIndex) -> None:
    for table in _iter_tables(text):
        if not table:
            continue
        header = [_clean_text(cell).lower() for cell in table[0]]
        if not header:
            continue
        if header[0] not in {"新形式", "new format"}:
            continue
        for row in table[1:]:
            if not row or _is_separator_row(row):
                continue
            description = _clean_text(row[1]) if len(row) > 1 else ""
            for target in _extract_v2_locations(row[0]):
                index.add_group(
                    GroupEntry(
                        name=target,
                        display_name=_display_v2_location(target),
                        description=description,
                        kind="format_v2",
                    )
                )

    for targets, body in _iter_v2_sections(text):
        for target in targets:
            if _normalize_lookup(target) not in index.groups:
                index.add_group(
                    GroupEntry(
                        name=target,
                        display_name=_display_v2_location(target),
                        description="format_version = 2 table",
                        kind="format_v2",
                    )
                )

        for table in _iter_tables(body):
            if not table:
                continue
            header = [_clean_text(cell).lower() for cell in table[0]]
            if not header:
                continue
            required_index = _find_header_index(
                table[0], ("必須パラメータ", "required parameters")
            )
            if required_index is not None:
                _parse_v2_required_parameter_table(
                    table, targets, required_index, index
                )
                continue
            if not _looks_like_parameter_header(header[0]):
                continue
            legacy_index = _find_header_index(table[0], ("旧グループ", "legacy group"))
            description_index = _find_header_index(table[0], ("説明", "description"))
            if description_index is None:
                description_index = len(table[0]) - 1
            for row in table[1:]:
                if not row or _is_separator_row(row):
                    continue
                names = _extract_parameter_names(row[0])
                if not names:
                    continue
                legacy_groups = []
                if legacy_index is not None and legacy_index < len(row):
                    legacy_groups = [
                        name.lstrip("&")
                        for name in _extract_group_names(row[legacy_index])
                    ]
                description = (
                    _clean_text(row[description_index])
                    if description_index < len(row)
                    else ""
                )
                for name in names:
                    matches = index.find_parameters(name)
                    if matches:
                        for match in matches:
                            for target in targets:
                                if target not in match.v2_locations:
                                    match.v2_locations.append(target)
                                group = index.groups.get(_normalize_lookup(target))
                                if group and name not in group.parameters:
                                    group.parameters.append(name)
                            for legacy_group in legacy_groups:
                                if legacy_group not in match.legacy_groups:
                                    match.legacy_groups.append(legacy_group)
                    else:
                        index.add_parameter(
                            ParameterEntry(
                                name=name,
                                aliases=[_base_name(name)],
                                legacy_groups=legacy_groups,
                                v2_locations=list(targets),
                                description=description,
                            )
                        )


def _parse_v2_required_parameter_table(
    table: list[list[str]],
    targets: list[str],
    required_index: int,
    index: ReferenceIndex,
) -> None:
    selector_names = _extract_parameter_names(table[0][0])
    for selector_name in selector_names:
        _add_v2_parameter_if_missing(
            selector_name,
            targets,
            _clean_text(table[0][0]),
            index,
        )

    shape_index = _find_header_index(table[0], ("形状", "shape"))
    for row in table[1:]:
        if not row or _is_separator_row(row) or required_index >= len(row):
            continue
        context = (
            _clean_text(row[shape_index])
            if shape_index is not None and shape_index < len(row)
            else _clean_text(row[0])
        )
        for name in _extract_parameter_names(row[required_index]):
            _add_v2_parameter_if_missing(name, targets, context, index)


def _add_v2_parameter_if_missing(
    name: str,
    targets: list[str],
    description: str,
    index: ReferenceIndex,
) -> None:
    matches = index.find_parameters(name)
    if matches:
        for match in matches:
            for target in targets:
                if target not in match.v2_locations:
                    match.v2_locations.append(target)
                group = index.groups.get(_normalize_lookup(target))
                if group and name not in group.parameters:
                    group.parameters.append(name)
        return

    index.add_parameter(
        ParameterEntry(
            name=name,
            v2_locations=list(targets),
            description=description,
        )
    )


def _parse_namelist_group_overview(text: str) -> list[tuple[str, str]]:
    groups: list[tuple[str, str]] = []
    for table in _iter_tables(text):
        if not table:
            continue
        header = [_clean_text(cell).lower() for cell in table[0]]
        if not header or header[0] not in {"グループ", "group"}:
            continue
        for row in table[1:]:
            if not row or _is_separator_row(row):
                continue
            names = _extract_group_names(row[0])
            if not names:
                continue
            groups.append((names[0].lstrip("&"), _clean_text(row[-1])))
        if groups:
            break
    return groups


def _iter_legacy_group_sections(text: str) -> Iterable[tuple[str, str, str]]:
    pattern = re.compile(r"^###\s+&([A-Za-z0-9_]+)([^\n]*)$", re.MULTILINE)
    matches = list(pattern.finditer(text))
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        group_name = match.group(1)
        title = match.group(2).strip(" —-")
        yield group_name, title, text[start:end]


def _iter_v2_sections(text: str) -> Iterable[tuple[list[str], str]]:
    pattern = re.compile(r"^###\s+(.+)$", re.MULTILINE)
    matches = list(pattern.finditer(text))
    for index, match in enumerate(matches):
        heading = match.group(1)
        targets = _extract_v2_locations(heading)
        if not targets:
            continue
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        yield targets, text[start:end]


def _iter_tables(text: str) -> Iterable[list[list[str]]]:
    lines = text.splitlines()
    index = 0
    while index < len(lines):
        if not lines[index].lstrip().startswith("|"):
            index += 1
            continue
        block: list[str] = []
        while index < len(lines) and lines[index].lstrip().startswith("|"):
            block.append(lines[index])
            index += 1
        rows = [_split_table_row(line) for line in block]
        rows = [row for row in rows if row]
        if rows:
            yield rows


def _split_table_row(line: str) -> list[str]:
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [cell.strip() for cell in line.split("|")]


def _is_separator_row(row: list[str]) -> bool:
    return all(re.fullmatch(r":?-{3,}:?", cell.strip()) for cell in row)


def _looks_like_parameter_header(text: str) -> bool:
    return any(
        token in text
        for token in (
            "parameter",
            "パラメータ",
            "主要パラメータ",
            "副パラメータ",
        )
    )


def _find_header_index(header: list[str], candidates: tuple[str, ...]) -> int | None:
    for index, cell in enumerate(header):
        cleaned = _clean_text(cell).lower()
        if any(candidate.lower() in cleaned for candidate in candidates):
            return index
    return None


def _extract_parameter_names(cell: str) -> list[str]:
    names = []
    for code in re.findall(r"`([^`]+)`", cell):
        code = code.strip()
        if not _looks_like_parameter_name(code):
            continue
        names.append(code)
    return _unique(names)


def _extract_group_names(cell: str) -> list[str]:
    names = []
    for code in re.findall(r"`([^`]+)`", cell):
        code = code.strip()
        if code.startswith("&") and len(code) > 1:
            names.append(code)
    return _unique(names)


def _extract_v2_locations(text: str) -> list[str]:
    locations = []
    for code in re.findall(r"`([^`]+)`", text):
        code = code.strip()
        if code.startswith("[[") and code.endswith("]]"):
            locations.append(code[2:-2])
        elif code.startswith("[") and code.endswith("]"):
            locations.append(code[1:-1])
    return _unique(locations)


def _looks_like_parameter_name(name: str) -> bool:
    if name.startswith("&") or name.startswith("["):
        return False
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*(?:\([^`]*\))?$", name):
        return False
    return True


def _lookup_names(entry: ParameterEntry) -> list[str]:
    return _unique(
        [
            entry.name,
            _base_name(entry.name),
            *entry.aliases,
            *[_base_name(alias) for alias in entry.aliases],
        ]
    )


def _base_name(name: str) -> str:
    return re.sub(r"\(.*\)$", "", name.strip())


def _strip_group_syntax(target: str) -> str:
    target = target.strip()
    if target.startswith("&"):
        return target[1:]
    if target.startswith("[[") and target.endswith("]]"):
        return target[2:-2]
    if target.startswith("[") and target.endswith("]"):
        return target[1:-1]
    return target


def _normalize_lookup(value: str) -> str:
    return value.strip().lower().replace(" ", "")


def _display_v2_location(location: str) -> str:
    if "." in location:
        return f"[[{location}]]"
    if location in {"species"}:
        return f"[[{location}]]"
    return f"[{location}]"


def _clean_text(text: str) -> str:
    text = text.replace("<br>", " ").replace("<br/>", " ").replace("<br />", " ")
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("**", "")
    text = text.replace("\\[", "[").replace("\\]", "]")
    return re.sub(r"\s+", " ", text).strip()


def _unique(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        key = _normalize_lookup(value)
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def _format_group(group: GroupEntry, index: ReferenceIndex) -> str:
    labels = _labels(index.language)
    lines = [
        f"## {labels['group']}: {group.display_name}",
        "",
        f"- {labels['kind']}: {group.kind}",
    ]
    if group.description:
        lines.append(f"- {labels['description']}: {group.description}")
    lines.extend(
        [
            "",
            f"### {labels['parameters']}",
            "",
            f"| {labels['name']} | {labels['type']} | {labels['summary']} |",
            "| --- | --- | --- |",
        ]
    )

    rows = _rows_for_group(group, index)
    for display_name, entry in rows:
        lines.append(
            f"| `{display_name}` | {_table_cell(entry.type_name or '-')} | {_table_cell(_shorten(entry.description))} |"
        )
    if not rows:
        lines.append(f"| - | - | {labels['no_parameter_rows']} |")
    return "\n".join(lines)


def _rows_for_group(
    group: GroupEntry,
    index: ReferenceIndex,
) -> list[tuple[str, ParameterEntry]]:
    if group.kind == "format_v2" and group.parameters:
        rows: list[tuple[str, ParameterEntry]] = []
        for name in group.parameters:
            matches = index.find_parameters(name)
            entry = matches[0] if matches else ParameterEntry(name=name)
            rows.append((name, entry))
        return rows
    return [(entry.name, entry) for entry in _entries_for_group(group, index)]


def _entries_for_group(
    group: GroupEntry, index: ReferenceIndex
) -> list[ParameterEntry]:
    group_key = _normalize_lookup(group.name)
    result = []
    seen: set[int] = set()
    for entry in index.parameters:
        belongs = any(
            _normalize_lookup(value) == group_key for value in entry.legacy_groups
        )
        belongs = belongs or any(
            _normalize_lookup(value) == group_key for value in entry.v2_locations
        )
        if belongs and id(entry) not in seen:
            seen.add(id(entry))
            result.append(entry)
    return result


def _format_parameter_entries(
    target: str,
    entries: list[ParameterEntry],
    language: str,
) -> str:
    labels = _labels(language)
    lines = [f"## {labels['parameter']}: `{target}`"]
    for entry in _unique_entries(entries):
        lines.extend(["", f"### `{entry.name}`"])
        if entry.aliases:
            lines.append(
                f"- {labels['aliases']}: "
                + ", ".join(f"`{alias}`" for alias in entry.aliases)
            )
        if entry.type_name:
            lines.append(f"- {labels['type']}: {entry.type_name}")
        if entry.legacy_groups:
            lines.append(
                f"- {labels['legacy_groups']}: "
                + ", ".join(f"`&{group}`" for group in entry.legacy_groups)
            )
        if entry.v2_locations:
            lines.append(
                f"- {labels['v2_locations']}: "
                + ", ".join(
                    f"`{_display_v2_location(location)}`"
                    for location in entry.v2_locations
                )
            )
        if entry.description:
            lines.append(f"- {labels['description']}: {entry.description}")
        lines.extend(["", f"```toml\n{_example_for(entry)}\n```"])
    return "\n".join(lines)


def _unique_entries(entries: list[ParameterEntry]) -> list[ParameterEntry]:
    result = []
    seen: set[int] = set()
    for entry in entries:
        if id(entry) not in seen:
            seen.add(id(entry))
            result.append(entry)
    return result


def _example_for(entry: ParameterEntry) -> str:
    value = _placeholder_value(entry)
    if entry.v2_locations:
        location = entry.v2_locations[0]
        if location == "species":
            return f"[[species]]\n{_base_name(entry.name)} = {value}"
        if "." in location:
            return f"[[{location}]]\n{_base_name(entry.name)} = {value}"
        return f"[{location}]\n{_base_name(entry.name)} = {value}"
    if entry.legacy_groups:
        return f"[{entry.legacy_groups[0]}]\n{_base_name(entry.name)} = {value}"
    return f"{_base_name(entry.name)} = {value}"


def _placeholder_value(entry: ParameterEntry) -> str:
    type_text = entry.type_name.lower()
    if "logical" in type_text or "bool" in type_text:
        return "true"
    if "integer" in type_text or "int" in type_text:
        return "1"
    if "character" in type_text or "string" in type_text:
        return '"value"'
    if "array" in type_text or "[" in type_text:
        return "[1, 1, 1]"
    if "(" in entry.name and not entry.v2_locations:
        return "[1, 1, 1]"
    return "1.0"


def _table_cell(text: str) -> str:
    return text.replace("|", "\\|")


def _shorten(text: str, limit: int = 160) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "..."


def _not_found(target: str, index: ReferenceIndex) -> str:
    labels = _labels(index.language)
    groups = ", ".join(
        f"`{group.display_name}`" for group in list(index.groups.values())[:12]
    )
    return (
        f"## {labels['not_found']}: `{target}`\n\n"
        f"{labels['not_found_hint']}\n\n"
        f"{labels['known_groups']}: {groups}"
    )


def _labels(language: str) -> dict[str, str]:
    if language == "en":
        return {
            "group": "Group",
            "kind": "Kind",
            "description": "Description",
            "parameters": "Parameters",
            "name": "Name",
            "type": "Type",
            "summary": "Summary",
            "parameter": "Parameter",
            "aliases": "Aliases",
            "legacy_groups": "Legacy groups",
            "v2_locations": "format_version=2 locations",
            "no_parameter_rows": "No parameter rows were extracted from the bundled reference.",
            "not_found": "No reference found",
            "not_found_hint": "Check the spelling or try a namelist group such as `esorem`, a V2 table such as `species`, or a parameter such as `emflag`.",
            "known_groups": "Known groups include",
        }
    return {
        "group": "グループ",
        "kind": "種別",
        "description": "説明",
        "parameters": "パラメータ",
        "name": "名前",
        "type": "型",
        "summary": "概要",
        "parameter": "パラメータ",
        "aliases": "別名",
        "legacy_groups": "従来グループ",
        "v2_locations": "format_version=2 の配置",
        "no_parameter_rows": "同梱リファレンスからパラメータ行を抽出できませんでした。",
        "not_found": "リファレンスが見つかりません",
        "not_found_hint": "`esorem` のような namelist グループ、`species` のような V2 テーブル、または `emflag` のようなパラメータ名を指定してください。",
        "known_groups": "既知のグループ例",
    }
