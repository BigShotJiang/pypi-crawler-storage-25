"""``emu`` (EMSES Unit) CLI — unit conversion and TOML inspection tool.

Also available as ``emses-unit``.

Usage::

    emu convert v 1e5 --dx 0.005 --cv 10000
    emu convert -r v 4.107 --toml plasma.toml
    emu inspect plasma.toml
    emu lint plasma.toml
    emu info --toml plasma.toml
    emu describe emflag
    emu describe species
    emu calc wp 1e11
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import typer

from ..unit_system import MASSELE, UnitSystem

app = typer.Typer(
    help="EMSES unit conversion and TOML inspection tool.",
    no_args_is_help=True,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _make_unit(
    dx: Optional[float],
    cv: Optional[float],
    toml: Optional[Path],
) -> UnitSystem:
    """Build a UnitSystem from CLI options."""
    if toml is not None:
        from ..plasma_toml import PlasmaToml

        return PlasmaToml.load(toml).unit
    if dx is None or cv is None:
        typer.echo("ERROR: --dx and --cv are required (or use --toml).", err=True)
        raise typer.Exit(1)
    return UnitSystem(dx, cv)


# ---------------------------------------------------------------------------
# convert
# ---------------------------------------------------------------------------
@app.command()
def convert(
    quantity: str = typer.Argument(
        help="Quantity type: v, e, b, phi, f, j, rho, r, t, q, m, ec, energy, energy_ev, ..."
    ),
    value: float = typer.Argument(help="Value to convert."),
    dx: Optional[float] = typer.Option(None, help="Grid spacing [m]."),
    cv: Optional[float] = typer.Option(None, help="Simulation light speed (= to_c)."),
    toml: Optional[Path] = typer.Option(None, help="Read dx/cv from a plasma.toml."),
    reverse: bool = typer.Option(
        False,
        "--reverse",
        "-r",
        help="Simulation -> physical (default: physical -> simulation).",
    ),
) -> None:
    """Convert between physical SI units and EMSES simulation units."""
    unit = _make_unit(dx, cv, toml)
    conv = unit.converter(quantity)
    if reverse:
        result = conv.reverse(value)
        typer.echo(f"{value} [{quantity} sim] = {result:.10e} [{conv.unit}]")
    else:
        result = conv.trans(value)
        typer.echo(f"{value} [{conv.unit}] = {result:.10e} [{quantity} sim]")


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------
@app.command()
def inspect(
    toml_file: Path = typer.Argument(help="Path to plasma.toml."),
    key: Optional[List[str]] = typer.Option(
        None, "--key", "-k", help="Specific parameter names to inspect."
    ),
) -> None:
    """Show physical values of simulation parameters in a plasma.toml."""
    from ..plasma_toml import PlasmaToml

    pt = PlasmaToml.load(toml_file)
    typer.echo(pt.inspect(keys=key or None))


# ---------------------------------------------------------------------------
# lint
# ---------------------------------------------------------------------------
@app.command()
def lint(
    input_file: Path = typer.Argument(help="Path to plasma.toml or plasma.inp."),
    input_format: str = typer.Option(
        "auto",
        "--format",
        "-f",
        help="Input format: auto, toml, or inp.",
    ),
    output_size_limit_gb: Optional[float] = typer.Option(
        None,
        "--output-size-limit-gb",
        help=(
            "Override hdf_output_size_limit_gb for this lint run. "
            "Use <=0 to disable the size guard."
        ),
    ),
    mpi_size: Optional[int] = typer.Option(
        None,
        "--mpi-size",
        help="Expected MPI process count for product(mpi.nodes) validation.",
    ),
    warnings_as_errors: bool = typer.Option(
        False,
        "--warnings-as-errors",
        help="Exit with status 1 when warnings are present.",
    ),
) -> None:
    """Lint plasma.toml/plasma.inp and estimate HDF5 diagnostic output size."""
    from ..lint import format_lint_result, lint_file

    try:
        result = lint_file(
            input_file,
            input_format=input_format,
            output_size_limit_gb=output_size_limit_gb,
            mpi_size=mpi_size,
        )
    except ValueError as exc:
        typer.echo(f"ERROR [usage] {exc}", err=True)
        raise typer.Exit(2) from exc

    typer.echo(format_lint_result(result))
    if result.error_count > 0 or (warnings_as_errors and result.warning_count > 0):
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------
@app.command()
def info(
    dx: Optional[float] = typer.Option(None, help="Grid spacing [m]."),
    cv: Optional[float] = typer.Option(None, help="Simulation light speed (= to_c)."),
    toml: Optional[Path] = typer.Option(None, help="Read from plasma.toml."),
) -> None:
    """Show all unit conversion factors."""
    unit = _make_unit(dx, cv, toml)
    typer.echo(unit.summary())


# ---------------------------------------------------------------------------
# describe
# ---------------------------------------------------------------------------
@app.command()
def describe(
    target: str = typer.Argument(
        help=(
            "Namelist group, format_version=2 table, or parameter name "
            "(for example: esorem, species, emflag, ptcond.objects)."
        )
    ),
    language: str = typer.Option(
        "ja",
        "--language",
        "-l",
        help="Reference language: ja or en.",
    ),
) -> None:
    """Describe MPIEMSES3D input parameters from bundled references."""
    from ..parameter_reference import describe_target

    typer.echo(describe_target(target, language=language))


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------
@app.command()
def apply(
    toml_file: Path = typer.Argument(help="Path to plasma.toml."),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show what would change without writing."
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Output path (default: overwrite in-place)."
    ),
) -> None:
    """Convert [meta.physical] SI parameters to simulation units.

    Reads physical parameters from [meta.physical], converts them using
    UnitSystem, and updates [[species]], [plasma], and [ptcond] fields.
    """
    from ..plasma_toml import PlasmaToml

    pt = PlasmaToml.load(toml_file)
    summary = pt.apply_physical(dry_run=dry_run)
    if dry_run:
        typer.echo(summary)
    else:
        out = output or toml_file
        pt.write(out)
        typer.echo(f"Applied [meta.physical] -> {out}")


# ---------------------------------------------------------------------------
# generate
# ---------------------------------------------------------------------------
@app.command()
def generate(
    toml_file: Path = typer.Argument(help="Path to plasma.toml."),
    update: bool = typer.Option(
        False,
        "--update",
        "-u",
        help="Update existing [meta.physical] (preserve labels and extra keys).",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show generated values without writing."
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Output path (default: overwrite in-place)."
    ),
) -> None:
    """Generate [meta.physical] from simulation parameters.

    Reverse of ``emu apply``: reads [[species]], [plasma], and
    [ptcond.conductor_groups] and computes SI-unit values for
    [meta.physical].
    """
    from ..plasma_toml import PlasmaToml

    pt = PlasmaToml.load(toml_file)
    pt.generate_physical(update=update)
    if dry_run:
        import json

        phys = pt.data.get("meta", {}).get("physical", {})
        typer.echo(json.dumps(phys, indent=2, ensure_ascii=False))
    else:
        out = output or toml_file
        pt.write(out)
        typer.echo(f"Generated [meta.physical] -> {out}")


# ---------------------------------------------------------------------------
# calc
# ---------------------------------------------------------------------------
@app.command()
def calc(
    function: str = typer.Argument(
        help="Physical function: wp, vth, debye, wc, larmor."
    ),
    args: List[float] = typer.Argument(help="Function arguments."),
) -> None:
    """Calculate plasma physical quantities.

    Examples::

        emu calc wp 1e11           # plasma_frequency(1e11 m^-3)
        emu calc vth 10            # thermal_speed(10 eV)
        emu calc debye 10 1e11     # debye_length(10 eV, 1e11 m^-3)
        emu calc wc 5e-9           # cyclotron_frequency(5e-9 T)
        emu calc larmor 1e5 5e-9   # larmor_radius(1e5 m/s, 5e-9 T)
    """
    if function == "wp":
        if len(args) < 1:
            typer.echo("Usage: calc wp <density_m3> [mass_kg]", err=True)
            raise typer.Exit(1)
        mass = args[1] if len(args) > 1 else MASSELE
        result = UnitSystem.plasma_frequency(args[0], mass)
        typer.echo(f"plasma_frequency({args[0]:.3e} m^-3) = {result:.6e} rad/s")
    elif function == "vth":
        if len(args) < 1:
            typer.echo("Usage: calc vth <temperature_eV> [mass_kg]", err=True)
            raise typer.Exit(1)
        mass = args[1] if len(args) > 1 else MASSELE
        result = UnitSystem.thermal_speed(args[0], mass)
        typer.echo(f"thermal_speed({args[0]:.3e} eV) = {result:.6e} m/s")
    elif function == "debye":
        if len(args) < 2:
            typer.echo("Usage: calc debye <temperature_eV> <density_m3>", err=True)
            raise typer.Exit(1)
        result = UnitSystem.debye_length(args[0], args[1])
        typer.echo(
            f"debye_length({args[0]:.3e} eV, {args[1]:.3e} m^-3) = {result:.6e} m"
        )
    elif function == "wc":
        if len(args) < 1:
            typer.echo("Usage: calc wc <B_tesla> [mass_kg]", err=True)
            raise typer.Exit(1)
        mass = args[1] if len(args) > 1 else MASSELE
        result = UnitSystem.cyclotron_frequency(args[0], mass)
        typer.echo(f"cyclotron_frequency({args[0]:.3e} T) = {result:.6e} rad/s")
    elif function == "larmor":
        if len(args) < 2:
            typer.echo("Usage: calc larmor <v_perp_m/s> <B_tesla> [mass_kg]", err=True)
            raise typer.Exit(1)
        mass = args[2] if len(args) > 2 else MASSELE
        result = UnitSystem.larmor_radius(args[0], args[1], mass)
        typer.echo(
            f"larmor_radius({args[0]:.3e} m/s, {args[1]:.3e} T) = {result:.6e} m"
        )
    else:
        typer.echo(
            f"Unknown function: {function!r}. Available: wp, vth, debye, wc, larmor",
            err=True,
        )
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> None:
    app()


if __name__ == "__main__":
    main()
