"""MPIEMSES3D Codex plugin helper CLI."""

from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional

import typer

DEFAULT_MARKETPLACE_SOURCE = "CS12-Laboratory/MPIEMSES3D"
DEFAULT_MARKETPLACE_REF = "main"
DEFAULT_MARKETPLACE_NAME = "mpiemses3d"
PLUGIN_DISPLAY_NAME = "MPIEMSES3D Context"
SPARSE_PATHS = (".agents/plugins", "plugins/mpiemses3d-context")
CODEX_INSTALL_URL = (
    "https://help.openai.com/en/articles/11096431-openai-codex-cli-getting-started"
)

app = typer.Typer(
    help="Install or update the MPIEMSES3D Codex plugin marketplace.",
    no_args_is_help=True,
)


def _is_local_source(source: str) -> bool:
    expanded = source.strip()
    return (
        expanded.startswith("/")
        or expanded.startswith(".")
        or expanded.startswith("~")
        or Path(expanded).expanduser().exists()
    )


def _source_argument(source: str) -> str:
    if source.startswith("~"):
        return str(Path(source).expanduser())
    return source


def _quote_command(command: List[str]) -> str:
    return " ".join(shlex.quote(part) for part in command)


def _codex_exists(codex_bin: str) -> bool:
    candidate = Path(codex_bin).expanduser()
    if candidate.is_file():
        return True
    return shutil.which(codex_bin) is not None


def _require_codex(codex_bin: str) -> None:
    if _codex_exists(codex_bin):
        return

    typer.echo("ERROR: Codex CLI was not found in PATH.", err=True)
    typer.echo("", err=True)
    typer.echo("Install OpenAI Codex CLI first:", err=True)
    typer.echo("  npm install -g @openai/codex", err=True)
    typer.echo("", err=True)
    typer.echo("Then authenticate and rerun this command:", err=True)
    typer.echo("  codex login", err=True)
    typer.echo("  mpiemses-codex-plugin install", err=True)
    typer.echo("", err=True)
    typer.echo(f"Reference: {CODEX_INSTALL_URL}", err=True)
    raise typer.Exit(1)


def _build_install_command(
    codex_bin: str,
    source: str,
    ref: Optional[str],
    sparse: bool,
) -> List[str]:
    command = [codex_bin, "plugin", "marketplace", "add", _source_argument(source)]
    if _is_local_source(source):
        return command

    if ref:
        command.extend(["--ref", ref])
    if sparse:
        for sparse_path in SPARSE_PATHS:
            command.extend(["--sparse", sparse_path])
    return command


def _build_upgrade_command(codex_bin: str, marketplace_name: str) -> List[str]:
    return [codex_bin, "plugin", "marketplace", "upgrade", marketplace_name]


def _activation_instructions() -> str:
    return "\n".join(
        [
            "Next steps:",
            "  1. Start Codex:",
            "       codex",
            "  2. Open /plugins.",
            f"  3. Install {PLUGIN_DISPLAY_NAME}.",
            "  4. Restart Codex.",
            "",
            "After restart, the MPIEMSES3D plugin skills are available outside the repository too.",
        ]
    )


def _run(command: List[str]) -> None:
    result = subprocess.run(command)
    if result.returncode != 0:
        raise typer.Exit(result.returncode)


@app.command()
def install(
    source: str = typer.Option(
        DEFAULT_MARKETPLACE_SOURCE,
        "--source",
        help=(
            "Codex marketplace source. Use the default GitHub repository, "
            "or pass a local MPIEMSES3D checkout path."
        ),
    ),
    ref: Optional[str] = typer.Option(
        DEFAULT_MARKETPLACE_REF,
        "--ref",
        help="Git ref used for the default GitHub marketplace source.",
    ),
    sparse: bool = typer.Option(
        True,
        "--sparse/--no-sparse",
        help="Sparse-install only the marketplace metadata and context plugin.",
    ),
    codex_bin: str = typer.Option(
        "codex",
        "--codex-bin",
        help="Codex CLI executable name or path.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Print the Codex command without running it.",
    ),
) -> None:
    """Register the MPIEMSES3D Codex plugin marketplace."""
    command = _build_install_command(codex_bin, source, ref, sparse)
    if dry_run:
        typer.echo("Would run:")
        typer.echo(f"  {_quote_command(command)}")
        typer.echo("")
        typer.echo(_activation_instructions())
        return

    _require_codex(codex_bin)
    _run(command)
    typer.echo("")
    typer.echo("Registered the MPIEMSES3D Codex plugin marketplace.")
    typer.echo("")
    typer.echo(_activation_instructions())


@app.command()
def upgrade(
    marketplace_name: str = typer.Argument(
        DEFAULT_MARKETPLACE_NAME,
        help="Registered Codex marketplace name.",
    ),
    codex_bin: str = typer.Option(
        "codex",
        "--codex-bin",
        help="Codex CLI executable name or path.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Print the Codex command without running it.",
    ),
) -> None:
    """Update an already registered MPIEMSES3D Codex marketplace."""
    command = _build_upgrade_command(codex_bin, marketplace_name)
    if dry_run:
        typer.echo("Would run:")
        typer.echo(f"  {_quote_command(command)}")
        return

    _require_codex(codex_bin)
    _run(command)
    typer.echo("")
    typer.echo("Updated the MPIEMSES3D Codex plugin marketplace.")


@app.command()
def instructions() -> None:
    """Print the post-registration plugin activation steps."""
    typer.echo(_activation_instructions())


def main() -> None:
    app()


if __name__ == "__main__":
    main()
