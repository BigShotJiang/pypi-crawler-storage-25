"""Lint MPIEMSES3D plasma input files.

The linter is intentionally lightweight: it parses ``plasma.toml`` or
``plasma.inp``, checks common structural mistakes, and mirrors the simulator's
raw HDF5 diagnostic output-size estimate so large-output cases can be caught
before submitting a run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ._inp_parser import parse_inp
from .inp2toml import to_toml
from .toml2inp import ALL_NAMELIST_GROUPS, to_inp

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


DECIMAL_GB = 1.0e9


@dataclass
class LintMessage:
    """One lint diagnostic."""

    severity: str
    code: str
    message: str


@dataclass
class HdfOutputEstimate:
    """Raw HDF5 output-size estimate, matching the simulator guard."""

    field_bytes: float = 0.0
    current_bytes: float = 0.0
    particle_bytes: float = 0.0
    limit_gb: float = 100.0

    @property
    def total_bytes(self) -> float:
        return self.field_bytes + self.current_bytes + self.particle_bytes

    @property
    def total_gb(self) -> float:
        return self.total_bytes / DECIMAL_GB

    @property
    def field_gb(self) -> float:
        return self.field_bytes / DECIMAL_GB

    @property
    def current_gb(self) -> float:
        return self.current_bytes / DECIMAL_GB

    @property
    def particle_gb(self) -> float:
        return self.particle_bytes / DECIMAL_GB

    @property
    def enabled(self) -> bool:
        return self.limit_gb > 0.0


@dataclass
class LintResult:
    """Result returned by :func:`lint_file`."""

    path: Path
    input_format: str
    messages: list[LintMessage] = field(default_factory=list)
    hdf_estimate: HdfOutputEstimate | None = None

    @property
    def error_count(self) -> int:
        return sum(1 for msg in self.messages if msg.severity == "ERROR")

    @property
    def warning_count(self) -> int:
        return sum(1 for msg in self.messages if msg.severity == "WARNING")


def lint_file(
    path: str | Path,
    *,
    input_format: str = "auto",
    output_size_limit_gb: float | None = None,
    mpi_size: int | None = None,
) -> LintResult:
    """Lint one ``plasma.toml`` or ``plasma.inp`` file."""

    input_path = Path(path)
    detected_format = _detect_format(input_path, input_format)
    result = LintResult(path=input_path, input_format=detected_format)

    if not input_path.exists():
        result.messages.append(
            LintMessage(
                "ERROR", "file-not-found", f"Input file not found: {input_path}"
            )
        )
        return result

    try:
        groups = _load_groups(input_path, detected_format)
    except Exception as exc:
        result.messages.append(
            LintMessage("ERROR", "parse", f"Failed to parse input: {exc}")
        )
        return result

    messages = result.messages
    _lint_groups(groups, messages, mpi_size=mpi_size)

    estimate = estimate_hdf_output_size(
        groups,
        messages=messages,
        output_size_limit_gb=output_size_limit_gb,
    )
    result.hdf_estimate = estimate
    _lint_hdf_estimate(estimate, messages)

    return result


def format_lint_result(result: LintResult) -> str:
    """Format a lint result as human-readable English text."""

    lines = [
        f"File: {result.path}",
        f"Format: {result.input_format}",
    ]

    estimate = result.hdf_estimate
    if estimate is not None:
        status = "enabled" if estimate.enabled else "disabled"
        lines.append(
            "HDF5 estimate: "
            f"total={estimate.total_gb:.3f} GB "
            f"(field={estimate.field_gb:.3f}, "
            f"current={estimate.current_gb:.3f}, "
            f"particle={estimate.particle_gb:.3f}); "
            f"limit={estimate.limit_gb:.3f} GB ({status})"
        )

    if result.messages:
        for msg in result.messages:
            lines.append(f"{msg.severity} [{msg.code}] {msg.message}")
    else:
        lines.append("OK: no lint issues found.")

    lines.append(
        f"Summary: {result.error_count} error(s), {result.warning_count} warning(s)."
    )
    return "\n".join(lines)


def estimate_hdf_output_size(
    groups: dict[str, dict[str, Any]],
    *,
    messages: list[LintMessage] | None = None,
    output_size_limit_gb: float | None = None,
) -> HdfOutputEstimate:
    """Estimate HDF5 output bytes from parsed namelist-style groups."""

    messages = messages if messages is not None else []
    jobcon = groups.get("jobcon", {})
    tmgrid = groups.get("tmgrid", {})
    system = groups.get("system", {})
    digcon = groups.get("digcon", {})
    intp = groups.get("intp", {})

    nspec = max(1, _as_int(_scalar(system, "nspec", 1), "system.nspec", messages, 1))
    nx = max(0, _as_int(_scalar(tmgrid, "nx", 8), "tmgrid.nx", messages, 8))
    ny = max(0, _as_int(_scalar(tmgrid, "ny", 8), "tmgrid.ny", messages, 8))
    nz = max(0, _as_int(_scalar(tmgrid, "nz", 8), "tmgrid.nz", messages, 8))
    nstep = max(
        0, _as_int(_scalar(jobcon, "nstep", 128), "jobcon.nstep", messages, 128)
    )

    hdfdigstart = _as_int(
        _scalar(digcon, "hdfdigstart", 0),
        "digcon.hdfdigstart",
        messages,
        0,
    )
    hdfdigend = _as_int(
        _scalar(digcon, "hdfdigend", -2),
        "digcon.hdfdigend",
        messages,
        -2,
    )
    if hdfdigend == -2:
        hdfdigend = nstep
    if hdfdigstart < 0:
        hdfdigstart = hdfdigend + hdfdigstart + 1

    limit_gb = (
        float(output_size_limit_gb)
        if output_size_limit_gb is not None
        else _as_float(
            _scalar(digcon, "hdf_output_size_limit_gb", 100.0),
            "digcon.hdf_output_size_limit_gb",
            messages,
            100.0,
        )
    )

    field_output_interval = _resolve_scalar_alias(
        digcon,
        "field_output_interval",
        "ifdiag",
        1,
        messages,
        group_name="digcon",
    )
    current_output_interval = _resolve_scalar_alias(
        digcon,
        "current_output_interval",
        "ijdiag",
        0,
        messages,
        group_name="digcon",
    )

    field_output_flags = _resolve_vector_alias(
        digcon,
        "field_output_flags",
        "ifxyz",
        7,
        1,
        messages,
        group_name="digcon",
    )
    current_output_flags = _resolve_vector_alias(
        digcon,
        "current_output_flags",
        "ijxyz",
        4,
        0,
        messages,
        group_name="digcon",
    )
    kinetic_temperature_output_flags = _resolve_vector_alias(
        digcon,
        "kinetic_temperature_output_flags",
        "iTxyz",
        7,
        [1, 0, 0, 0, 0, 0, 0],
        messages,
        group_name="digcon",
    )
    irhsp = _vector(digcon.get("irhsp"), nspec, 1, "digcon.irhsp", messages)
    particle_output_interval = _resolve_vector_alias(
        digcon,
        "particle_output_interval",
        "ipadig",
        nspec,
        0,
        messages,
        group_name="digcon",
    )
    particle_hdf5_stride = _resolve_vector_alias(
        digcon,
        "particle_hdf5_stride",
        "ipahdf",
        nspec,
        0,
        messages,
        group_name="digcon",
    )
    particle_output_flags = _resolve_matrix_alias(
        digcon,
        "particle_output_flags",
        "ipaxyz",
        7,
        nspec,
        0,
        messages,
        group_name="digcon",
    )
    np_values = _vector(intp.get("np"), nspec, 0, "intp.np", messages)
    npin_values = _vector(intp.get("npin"), nspec, 0, "intp.npin", messages)

    separate_charge = _as_bool(
        _scalar(system, "separate_accumulated_and_space_charge", True),
        "system.separate_accumulated_and_space_charge",
        messages,
        True,
    )

    cell_dataset_bytes = float(nx + 1) * float(ny + 1) * float(nz + 1) * 8.0
    enabled_density_species = sum(1 for value in irhsp if value >= 1)

    field_dataset_count = sum(1 for value in field_output_flags[:6] if value >= 1)
    if separate_charge:
        field_dataset_count += sum(1 for value in field_output_flags[:3] if value >= 1)
    if field_output_flags[6] >= 1:
        field_dataset_count += 3 + enabled_density_species + 2 * nspec
        if separate_charge:
            field_dataset_count += 1
    field_dataset_count += nspec * sum(
        1 for value in kinetic_temperature_output_flags[:7] if value >= 1
    )
    field_bytes = (
        cell_dataset_bytes
        * float(field_dataset_count)
        * float(
            _count_hdf_output_steps(
                field_output_interval, hdfdigstart, hdfdigend, nstep
            )
        )
    )

    current_dataset_count = 0
    for value in current_output_flags[:3]:
        if value >= 1:
            current_dataset_count += 1 + nspec
    if current_output_flags[3] >= 1:
        current_dataset_count += 1 + enabled_density_species
    current_bytes = (
        cell_dataset_bytes
        * float(current_dataset_count)
        * float(
            _count_hdf_output_steps(
                current_output_interval, hdfdigstart, hdfdigend, nstep
            )
        )
    )

    particle_bytes = 0.0
    for species_index in range(nspec):
        if particle_hdf5_stride[species_index] <= 0:
            continue
        particle_components = sum(
            1 for row in range(7) if particle_output_flags[row][species_index] >= 1
        )
        if particle_components <= 0:
            continue
        particle_count = max(0, np_values[species_index], npin_values[species_index])
        particle_stride = max(1, particle_output_interval[species_index])
        if particle_count > 0:
            particle_samples = (particle_count + particle_stride - 1) // particle_stride
        else:
            particle_samples = 1
        particle_bytes += (
            float(particle_components)
            * float(particle_samples)
            * 8.0
            * float(
                _count_hdf_output_steps(
                    particle_hdf5_stride[species_index],
                    hdfdigstart,
                    hdfdigend,
                    nstep,
                )
            )
        )

    return HdfOutputEstimate(
        field_bytes=field_bytes,
        current_bytes=current_bytes,
        particle_bytes=particle_bytes,
        limit_gb=limit_gb,
    )


def _detect_format(path: Path, input_format: str) -> str:
    fmt = input_format.lower()
    if fmt not in {"auto", "toml", "inp"}:
        raise ValueError("--format must be one of: auto, toml, inp")
    if fmt != "auto":
        return fmt
    suffix = path.suffix.lower()
    if suffix == ".toml":
        return "toml"
    return "inp"


def _load_groups(path: Path, input_format: str) -> dict[str, dict[str, Any]]:
    if input_format == "toml":
        if tomllib is None:
            raise ImportError("Python 3.11+ or the 'tomli' package is required")
        with path.open("rb") as handle:
            data = tomllib.load(handle)
        to_inp(data)
        return _groups_from_toml_data(data)

    text = path.read_text(encoding="utf-8")
    meta, parsed_groups = parse_inp(text)
    _validate_namelist_groups(parsed_groups)
    # Convert once through the TOML path for structural validation. Keep the
    # original parsed namelist groups for linting so repeated/indexed legacy
    # assignments keep their original shape.
    toml_text = to_toml(meta, parsed_groups, schema=None, format_version=2)
    if tomllib is None:
        raise ImportError("Python 3.11+ or the 'tomli' package is required")
    data = tomllib.loads(toml_text)
    to_inp(data)
    return {name: dict(params) for name, params in parsed_groups}


def _groups_from_toml_data(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    groups: dict[str, dict[str, Any]] = {}
    for name in ALL_NAMELIST_GROUPS:
        value = data.get(name)
        if isinstance(value, dict):
            groups[name] = dict(value)

    species = data.get("species")
    if not isinstance(species, list) or not species:
        return groups

    system = groups.setdefault("system", {})
    # The simulator derives nspec from [[species]] in TOML v2, so keep the
    # run-time-effective value here even if [system].nspec is present.
    system["nspec"] = len(species)

    try:
        from .plasma_toml import PlasmaToml

        resolved_species = PlasmaToml.from_dict(data).resolved_species
    except Exception:
        resolved_species = [entry for entry in species if isinstance(entry, dict)]

    intp = groups.setdefault("intp", {})
    digcon = groups.setdefault("digcon", {})

    _fill_species_vector(intp, "np", resolved_species)
    _fill_species_vector(intp, "npin", resolved_species)
    _fill_species_vector(digcon, "particle_output_interval", resolved_species)
    _fill_species_vector(digcon, "particle_hdf5_stride", resolved_species)
    _fill_species_vector(digcon, "irhsp", resolved_species)
    _fill_species_matrix(digcon, "particle_output_flags", resolved_species, rows=7)

    return groups


def _fill_species_vector(
    group: dict[str, Any],
    key: str,
    species: list[dict[str, Any]],
) -> None:
    if key in group:
        return
    values = [entry.get(key, 0) for entry in species]
    if any(value != 0 and value is not False for value in values):
        group[key] = values


def _fill_species_matrix(
    group: dict[str, Any],
    key: str,
    species: list[dict[str, Any]],
    *,
    rows: int,
) -> None:
    if key in group:
        return
    matrix = [[0 for _entry in species] for _row in range(rows)]
    has_value = False
    for col_index, entry in enumerate(species):
        value = entry.get(key)
        if not isinstance(value, list):
            continue
        for row_index, item in enumerate(value[:rows]):
            matrix[row_index][col_index] = item
            if item != 0 and item is not False:
                has_value = True
    if has_value:
        group[key] = matrix


def _validate_namelist_groups(groups: list[tuple[str, dict[str, Any]]]) -> None:
    allowed = set(ALL_NAMELIST_GROUPS)
    unknown = [name for name, _params in groups if name not in allowed]
    if unknown:
        raise ValueError(f"unknown namelist group(s): {', '.join(unknown)}")


def _lint_groups(
    groups: dict[str, dict[str, Any]],
    messages: list[LintMessage],
    *,
    mpi_size: int | None,
) -> None:
    jobcon = groups.get("jobcon", {})
    tmgrid = groups.get("tmgrid", {})
    system = groups.get("system", {})
    mpi = groups.get("mpi", {})

    nspec = _as_int(_scalar(system, "nspec", 1), "system.nspec", messages, 1)
    if nspec < 1:
        messages.append(
            LintMessage(
                "ERROR", "value", "system.nspec must be greater than or equal to 1."
            )
        )

    nstep = _as_int(_scalar(jobcon, "nstep", 128), "jobcon.nstep", messages, 128)
    if nstep < 0:
        messages.append(
            LintMessage("ERROR", "value", "jobcon.nstep must be non-negative.")
        )

    nxyz = [
        _as_int(_scalar(tmgrid, "nx", 8), "tmgrid.nx", messages, 8),
        _as_int(_scalar(tmgrid, "ny", 8), "tmgrid.ny", messages, 8),
        _as_int(_scalar(tmgrid, "nz", 8), "tmgrid.nz", messages, 8),
    ]
    for axis, value in zip(("nx", "ny", "nz"), nxyz):
        if value <= 0:
            messages.append(
                LintMessage("ERROR", "value", f"tmgrid.{axis} must be positive.")
            )

    nodes = _vector(mpi.get("nodes"), 3, [1, 1, 1], "mpi.nodes", messages)
    for axis, value in zip(("x", "y", "z"), nodes):
        if value <= 0:
            messages.append(
                LintMessage("ERROR", "mpi", f"mpi.nodes for {axis} must be positive.")
            )

    if mpi_size is not None and mpi_size <= 0:
        messages.append(
            LintMessage("ERROR", "mpi", "--mpi-size must be greater than zero.")
        )

    if all(value > 0 for value in nodes):
        node_product = nodes[0] * nodes[1] * nodes[2]
        if mpi_size is not None and mpi_size > 0 and node_product != mpi_size:
            messages.append(
                LintMessage(
                    "ERROR",
                    "mpi",
                    f"product(mpi.nodes) is {node_product}, but --mpi-size is {mpi_size}.",
                )
            )
        for axis, cells, parts in zip(("x", "y", "z"), nxyz, nodes):
            if cells > 0 and parts > 0 and cells % parts != 0:
                messages.append(
                    LintMessage(
                        "ERROR",
                        "mpi",
                        f"tmgrid.n{axis}={cells} is not divisible by mpi.nodes[{axis}]={parts}.",
                    )
                )


def _lint_hdf_estimate(
    estimate: HdfOutputEstimate,
    messages: list[LintMessage],
) -> None:
    if not estimate.enabled:
        messages.append(
            LintMessage(
                "WARNING",
                "output-size",
                "HDF5 output-size guard is disabled because hdf_output_size_limit_gb <= 0.",
            )
        )
        return

    limit_bytes = estimate.limit_gb * DECIMAL_GB
    if estimate.total_bytes > limit_bytes:
        messages.append(
            LintMessage(
                "ERROR",
                "output-size",
                "Estimated HDF5 diagnostic output is "
                f"{estimate.total_gb:.3f} GB, above the "
                f"{estimate.limit_gb:.3f} GB limit. Increase hdf_output_size_limit_gb "
                "explicitly, reduce HDF5 output cadence/flags, or set the limit <= 0 "
                "to disable the guard.",
            )
        )
    elif estimate.total_bytes > 0.8 * limit_bytes:
        messages.append(
            LintMessage(
                "WARNING",
                "output-size",
                "Estimated HDF5 diagnostic output is "
                f"{estimate.total_gb:.3f} GB, above 80% of the "
                f"{estimate.limit_gb:.3f} GB limit.",
            )
        )


def _count_hdf_output_steps(
    interval: int,
    hdfdigstart: int,
    hdfdigend: int,
    nstep: int,
) -> int:
    if interval <= 0:
        return 0
    start_step = max(0, hdfdigstart)
    last_step = min(nstep, hdfdigend)
    if last_step < start_step:
        return 0
    first_step = ((start_step + interval - 1) // interval) * interval
    if first_step > last_step:
        return 0
    return (last_step - first_step) // interval + 1


def _resolve_scalar_alias(
    group: dict[str, Any],
    canonical: str,
    legacy: str,
    default: int,
    messages: list[LintMessage],
    *,
    group_name: str,
) -> int:
    if canonical in group and legacy in group:
        messages.append(
            LintMessage(
                "ERROR",
                "alias",
                f"{group_name} must not set both {canonical} and {legacy}.",
            )
        )
    value = group.get(canonical, group.get(legacy, default))
    return _as_int(value, f"{group_name}.{canonical}", messages, default)


def _resolve_vector_alias(
    group: dict[str, Any],
    canonical: str,
    legacy: str,
    length: int,
    default: int | list[int],
    messages: list[LintMessage],
    *,
    group_name: str,
) -> list[int]:
    if canonical in group and legacy in group:
        messages.append(
            LintMessage(
                "ERROR",
                "alias",
                f"{group_name} must not set both {canonical} and {legacy}.",
            )
        )
    value = group.get(canonical, group.get(legacy))
    return _vector(value, length, default, f"{group_name}.{canonical}", messages)


def _resolve_matrix_alias(
    group: dict[str, Any],
    canonical: str,
    legacy: str,
    rows: int,
    cols: int,
    default: int,
    messages: list[LintMessage],
    *,
    group_name: str,
) -> list[list[int]]:
    if canonical in group and legacy in group:
        messages.append(
            LintMessage(
                "ERROR",
                "alias",
                f"{group_name} must not set both {canonical} and {legacy}.",
            )
        )
    value = group.get(canonical, group.get(legacy))
    return _matrix(value, rows, cols, default, f"{group_name}.{canonical}", messages)


def _scalar(group: dict[str, Any], name: str, default: Any) -> Any:
    value = group.get(name, default)
    if isinstance(value, list):
        return value[0] if value else default
    return value


def _vector(
    value: Any,
    length: int,
    default: int | list[int],
    name: str,
    messages: list[LintMessage],
) -> list[int]:
    if isinstance(default, list):
        result = list(default[:length])
        while len(result) < length:
            result.append(0)
    else:
        result = [default for _ in range(length)]

    if value is None:
        return result

    raw_values: list[Any]
    if isinstance(value, list):
        if value and isinstance(value[0], list):
            raw_values = [item for row in value for item in row]
        else:
            raw_values = value
    else:
        raw_values = [value]

    for index, item in enumerate(raw_values[:length]):
        result[index] = _as_int(item, f"{name}[{index + 1}]", messages, result[index])
    if len(raw_values) > length:
        messages.append(
            LintMessage(
                "WARNING",
                "shape",
                f"{name} has {len(raw_values)} values; only the first {length} are used by this lint check.",
            )
        )
    return result


def _matrix(
    value: Any,
    rows: int,
    cols: int,
    default: int,
    name: str,
    messages: list[LintMessage],
) -> list[list[int]]:
    result = [[default for _col in range(cols)] for _row in range(rows)]
    if value is None:
        return result

    if isinstance(value, list) and value and isinstance(value[0], list):
        for row_index, row in enumerate(value[:rows]):
            for col_index, item in enumerate(row[:cols]):
                result[row_index][col_index] = _as_int(
                    item,
                    f"{name}[{row_index + 1},{col_index + 1}]",
                    messages,
                    result[row_index][col_index],
                )
        return result

    raw_values = value if isinstance(value, list) else [value]
    if len(raw_values) == rows * cols:
        for col_index in range(cols):
            for row_index in range(rows):
                flat_index = col_index * rows + row_index
                result[row_index][col_index] = _as_int(
                    raw_values[flat_index],
                    f"{name}[{row_index + 1},{col_index + 1}]",
                    messages,
                    result[row_index][col_index],
                )
    else:
        for row_index, item in enumerate(raw_values[:rows]):
            result[row_index][0] = _as_int(
                item,
                f"{name}[{row_index + 1},1]",
                messages,
                result[row_index][0],
            )
        if len(raw_values) not in {rows, rows * cols}:
            messages.append(
                LintMessage(
                    "WARNING",
                    "shape",
                    f"{name} has {len(raw_values)} flat values; expected {rows} or {rows * cols}.",
                )
            )
    return result


def _as_int(
    value: Any,
    name: str,
    messages: list[LintMessage],
    default: int,
) -> int:
    try:
        if isinstance(value, bool):
            return int(value)
        return int(value)
    except (TypeError, ValueError):
        messages.append(
            LintMessage(
                "ERROR",
                "type",
                f"{name} must be an integer-compatible value; got {value!r}.",
            )
        )
        return default


def _as_float(
    value: Any,
    name: str,
    messages: list[LintMessage],
    default: float,
) -> float:
    try:
        if isinstance(value, bool):
            raise TypeError
        return float(value)
    except (TypeError, ValueError):
        messages.append(
            LintMessage(
                "ERROR",
                "type",
                f"{name} must be a numeric value; got {value!r}.",
            )
        )
        return default


def _as_bool(
    value: Any,
    name: str,
    messages: list[LintMessage],
    default: bool,
) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", ".true.", "t", "1"}:
            return True
        if lowered in {"false", ".false.", "f", "0"}:
            return False
    messages.append(
        LintMessage(
            "ERROR",
            "type",
            f"{name} must be boolean-compatible; got {value!r}.",
        )
    )
    return default
