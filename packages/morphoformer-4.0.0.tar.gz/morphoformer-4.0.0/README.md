# morphoformer

`morphoformer` is the application package for the Morph_v4 stack.

It builds on:

- `celmoe-vp` for generic hierarchical expert orchestration
- `torchblocks-vp` for reusable neural modules
- `chartoken-vp` and `sigmorphon-vp` for morphology data pipelines
- `trainkit-vp` for training and checkpoint utilities

Install:

```bash
pip install morphoformer
```
