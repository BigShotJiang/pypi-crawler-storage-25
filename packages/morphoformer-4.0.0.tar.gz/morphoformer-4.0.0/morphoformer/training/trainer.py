from __future__ import annotations

from pathlib import Path
from typing import TypedDict, cast

import torch

from chartoken import CharVocab, FeatureVocab, PAD
from chartoken.feature_vocab import FeatureVocabState
from chartoken.vocab import CharVocabState
from morphoformer.config.schema import DataConfig, MorphoformerConfig, OptimizerConfig, TrainConfig
from morphoformer.model.model import Morphoformer
from sigmorphon import MorphDataset, load_tsv_pattern
from sigmorphon.dataset import MorphRow
from trainkit import MultiLevelSequenceLoss, create_cosine_schedule, freeze_stages, load_checkpoint, save_checkpoint


class MorphoformerCheckpoint(TypedDict):
    model_state: dict[str, torch.Tensor]
    optimizer_state: dict[str, object]
    char_vocab: CharVocabState
    feature_vocab: FeatureVocabState
    language_to_id: dict[str, int]
    epoch: int


def _create_grad_scaler(device_type: str, enabled: bool) -> torch.GradScaler:
    return torch.GradScaler(device_type, enabled=enabled)


class MorphoformerTrainer:
    def __init__(self, config: MorphoformerConfig) -> None:
        self.config: MorphoformerConfig = config
        self.data_config: DataConfig = config.data
        self.train_config: TrainConfig = config.train
        self.optimizer_config: OptimizerConfig = config.optimizer
        self.device = torch.device(
            self.train_config.device if self.train_config.device != "cuda" or torch.cuda.is_available() else "cpu"
        )

    def _build_vocabs(self, rows: list[MorphRow]) -> tuple[CharVocab, FeatureVocab]:
        texts = [lemma for lemma, _, _, _ in rows] + [surface for _, _, surface, _ in rows]
        tags = [features for _, features, _, _ in rows]
        return CharVocab.from_texts(texts), FeatureVocab.from_tags(tags)

    def _build_language_map(self) -> dict[str, int]:
        return {language: idx for idx, language in enumerate(sorted(self.config.languages))}

    def _create_dataset(
        self,
        rows: list[MorphRow],
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        language_to_id: dict[str, int],
    ) -> MorphDataset:
        return MorphDataset(
            rows,
            char_vocab,
            feature_vocab,
            language_to_id,
            max_len=self.data_config.max_len,
            max_features=self.data_config.max_features,
        )

    def _checkpoint_payload(
        self,
        model: Morphoformer,
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        optimizer: torch.optim.Optimizer,
        epoch: int,
    ) -> MorphoformerCheckpoint:
        return {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "char_vocab": char_vocab.to_dict(),
            "feature_vocab": feature_vocab.to_dict(),
            "language_to_id": model.language_to_id,
            "epoch": epoch,
        }

    def train(self) -> Path:
        train_config = self.train_config
        optimizer_config = self.optimizer_config
        train_rows = load_tsv_pattern(self.data_config.train_path)
        dev_rows = load_tsv_pattern(self.data_config.dev_path)
        char_vocab, feature_vocab = self._build_vocabs(train_rows + dev_rows)
        language_to_id = self._build_language_map()
        train_data = self._create_dataset(train_rows, char_vocab, feature_vocab, language_to_id)
        dev_data = self._create_dataset(dev_rows, char_vocab, feature_vocab, language_to_id)

        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        freeze_stages(model, train_config.stage)

        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=optimizer_config.lr,
            betas=optimizer_config.betas,
            weight_decay=optimizer_config.weight_decay,
        )
        scheduler = create_cosine_schedule(
            optimizer,
            warmup_steps=train_config.warmup_steps,
            total_steps=train_config.total_steps,
        )
        criterion = MultiLevelSequenceLoss(
            pad_id=PAD,
            final_weight=train_config.final_loss_weight,
            universal_weight=train_config.universal_loss_weight,
            family_weight=train_config.family_loss_weight,
            language_weight=train_config.language_loss_weight,
        )

        scaler = _create_grad_scaler(
            self.device.type,
            self.device.type == "cuda" and train_config.mixed_precision,
        )
        output_dir = Path(train_config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        best_path = output_dir / "best.pt"
        best_dev_loss = float("inf")
        global_step = 0

        for epoch in range(1, train_config.epochs + 1):
            model.train()
            batch_size: int = train_config.batch_size
            for batch in train_data.epoch_batches(batch_size, self.device):
                source, target, language_ids, feature_ids, feature_mask = batch
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=self.device.type, enabled=scaler.is_enabled()):
                    output = model(source, language_ids, feature_ids, feature_mask)
                    losses = criterion(output, target)
                scaler.scale(losses.total).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), train_config.clip_grad_norm)
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                global_step += 1
                if global_step % train_config.log_interval == 0:
                    stats = losses.as_scalars()
                    print(
                        f"step={global_step} loss={stats['loss']:.4f} "
                        f"final={stats['loss_final']:.4f} universal={stats['loss_universal']:.4f} "
                        f"family={stats['loss_family']:.4f} language={stats['loss_language']:.4f}",
                        flush=True,
                    )

            dev_loss = self.evaluate(model, dev_data, criterion)
            print(f"epoch={epoch} dev_loss={dev_loss:.4f}", flush=True)
            if dev_loss < best_dev_loss:
                best_dev_loss = dev_loss
                save_checkpoint(best_path, self._checkpoint_payload(model, char_vocab, feature_vocab, optimizer, epoch))

        return best_path

    def evaluate(self, model: Morphoformer, dataset: MorphDataset, criterion: MultiLevelSequenceLoss) -> float:
        model.eval()
        losses: list[float] = []
        with torch.no_grad():
            batch_size: int = self.train_config.batch_size
            for source, target, language_ids, feature_ids, feature_mask in dataset.epoch_batches(
                batch_size,
                self.device,
            ):
                output = model(source, language_ids, feature_ids, feature_mask)
                losses.append(float(criterion(output, target).total.detach().cpu()))
        return sum(losses) / max(1, len(losses))

    def load_model(self, checkpoint_path: str | Path) -> tuple[Morphoformer, CharVocab, FeatureVocab]:
        checkpoint = cast(MorphoformerCheckpoint, load_checkpoint(checkpoint_path, map_location=self.device))
        char_vocab = CharVocab.from_dict(checkpoint["char_vocab"])
        feature_vocab = FeatureVocab.from_dict(checkpoint["feature_vocab"])
        language_to_id = checkpoint["language_to_id"]
        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        model.load_state_dict(checkpoint["model_state"])
        model.eval()
        return model, char_vocab, feature_vocab
