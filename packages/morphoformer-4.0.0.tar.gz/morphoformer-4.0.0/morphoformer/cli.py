from __future__ import annotations

import argparse
from pprint import pprint

from morphoformer.config.loader import load_config
from morphoformer.inference.predict import predict_form
from morphoformer.training.trainer import MorphoformerTrainer


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="morphoformer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser("inspect-config")
    inspect_parser.add_argument("--config", required=True)

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--config", required=True)

    infer_parser = subparsers.add_parser("infer")
    infer_parser.add_argument("--config", required=True)
    infer_parser.add_argument("--checkpoint", required=True)
    infer_parser.add_argument("--lemma", required=True)
    infer_parser.add_argument("--tags", required=True, help="Semicolon-separated UniMorph tags")
    infer_parser.add_argument("--lang", required=True)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    config = load_config(args.config)

    if args.command == "inspect-config":
        pprint(config)
        return

    trainer = MorphoformerTrainer(config)

    if args.command == "train":
        checkpoint = trainer.train()
        print(checkpoint, flush=True)
        return

    model, char_vocab, feature_vocab = trainer.load_model(args.checkpoint)
    result = predict_form(
        model,
        char_vocab,
        feature_vocab,
        lemma=args.lemma,
        tags=[tag for tag in args.tags.split(";") if tag],
        language=args.lang,
        max_len=config.data.max_len,
        max_features=config.data.max_features,
        device=trainer.device,
    )
    print(result, flush=True)


if __name__ == "__main__":
    main()
