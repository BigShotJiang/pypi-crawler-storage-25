# PRD: Fechar gap B1 do LoCoMo — dedup agressivo + reranker específico + composed facts

> **STATUS: DESCARTADO PÓS-BENCHMARK (2026-05-16).** A part 1 (intra-subject aggressive dedup, v0.14.0/v0.14.1) foi implementada e benchmarkada no LoCoMo. Resultado dividido: single-hop +9.4pp (validou o diagnóstico B1-real), open-domain **-23.1pp** (regressão catastrófica), overall -1.5pp. Hipótese: dedup remove facts tematicamente complementares que open-domain precisa pra síntese ("Melanie attends LGBTQ group" + "Melanie has trans friends" são reforços, não duplicatas). **Parts 2 e 3 nunca foram implementadas.** Toda a v0.14.x foi revertida em v0.14.2. A abordagem por dedup/reranker incremental foi pausada em favor da proposta arquitetural v2 (5 propriedades computacionais, vault). Mantido como histórico do experimento que não deu — não usar como ponto de partida sem repensar a interação com open-domain.

> Generated on 2026-04-18 based on cross-ref analysis of 47 LoCoMo errors (v0.13.7 diagnostic)

## Problem

O Arandu v0.13.7 alcança **76.4% de accuracy no LoCoMo** (152/199), enquanto o SOTA público é EverMemOS a 92.3%. O gap de 16pp levou a uma investigação profunda (8 relatórios de pesquisa + cross-ref manual dos 47 erros no JSON diagnóstico `arandu-inspector/docs/locomo-diagnostic-v0137-gpt41-2026-04-11.json`).

A tentativa anterior de melhorar via prompt (v0.13.8 com verbatim + inventory) regrediu pra 71.4% por inflar o grafo (+34% facts) sem melhorar ranking. A tentativa v0.13.9/v0.13.10 (regras abstratas de "PRESERVE SPECIFIC DETAILS" + preferência por específico no reranker) **também regrediu** pra 73.4% — regras abstratas sem exemplos concretos não ancoraram.

O cross-ref refinado dos 47 erros mostra que o problema real **não é extração** (só 2/47 = 4% são "extração perdeu detalhe"). O padrão dominante é:

1. **B1-real (9 erros, 19%)** — O fato específico **existe no DB** mas **perdeu no ranking** pra um fato abstrato/tematicamente relacionado criado pelo mesmo extractor na mesma mensagem. Exemplos verificados no DB:
   - Turn 288: LLM extraiu tanto "Caroline's necklace is a gift from Caroline's grandma **in Sweden**" quanto "Caroline moved from Caroline's **home country**" — o abstrato ranqueou top-1 (0.567), o específico ficou fora do top-5. Query "Where did Caroline move from 4 years ago?" foi respondida "Caroline's home country".
   - Turn 114: LLM extraiu "Caroline made a **stained glass window** to serve as a reminder..." — mas o reranker puxou "Caroline created an **artwork** for a local church" (0.752) acima. Query "What did Caroline make for a local church?" foi respondida "an artwork".
   - Turn 31: 3 facts sobre **Perseid meteor shower** existem no DB. Nenhum chegou ao top-5 do retrieve (os top-5 são outros facts sobre o mesmo camping trip, sem mencionar Perseid).

2. **B0 (8 erros, 17%)** — Enumerações co-ocorrentes na mesma mensagem viram facts atômicos separados. Retrieval traz 1, LLM nunca vê o conjunto. Exemplos:
   - Turn 158: "Melanie plays the clarinet" + "Melanie started playing the clarinet when she was young" + "Melanie uses clarinet as self-expression" — mas o **violino** (mencionado na mesma mensagem original) virou fato atômico separado que não chegou ao top-5. Query "What instruments does Melanie play?" → "clarinet" (perdeu violino).
   - 2 cats + 1 dog extraídos como facts separados → query "What pets does Melanie have?" → "A dog and a cat" (contagem errada).
   - "Summer Sounds, Matt Patterson" viraram facts separados — só um vem no retrieve.

3. **A (2 erros, 4%)** — Regra verbatim direta. Extractor descartou o detalhe (raro).

Total atacável por essas 3 intervenções: **19 dos 47 erros (40%)**. O restante é adversarial (9 casos onde GT é sobre pessoa X mas query pergunta sobre Y), inferência/síntese open-domain (12 casos — teto do sistema), e espúrios/borderline (4-6 casos).

## Target Audience

- **Imediato:** o benchmark LoCoMo / Arandu Inspector. A régua concreta de performance do SDK.
- **Médio prazo:** consumidores em produção (Personal Genius, Chief of Staff) que hoje sofrem do mesmo padrão: fato específico existe mas perde pro abstrato no retrieval.
- **Longo prazo:** outros benchmarks (MemoryArena, LoCoMo-Plus) onde a mesma patologia arquitetural aparece.

## Proposed Solution

Três intervenções cirúrgicas em módulos existentes, sem mudança estrutural de schema ou pipeline. Ordem de implementação:

### P1 — Dedup semântico agressivo no write pipeline (ALVO PRINCIPAL)

**Raiz do problema:** o `extract.py` e `informed_extract.py` hoje fazem **dedup exato** (lowercase + strip punctuation, keys `(subject, fact_text)`) e **dedup semântico** (coseno > 0.85) via `semantic_dedup.py`. Mas o threshold 0.85 é conservador demais — os pares "stained glass window" vs "artwork for local church" têm cosseno em torno de 0.6-0.7, passam no filtro atual e coexistem no DB.

**Mudança:**
1. Adicionar dedup **intra-mensagem** focado em facts do mesmo subject: quando 2+ facts do mesmo subject foram extraídos do mesmo turn, aplicar um passo LLM leve ("qual deles é mais específico — mantém o específico, descarta o genérico, ou merge?").
2. Alternativamente: baixar threshold de semantic_dedup de 0.85 pra 0.75-0.80 apenas quando os facts compartilham o mesmo `source_event_id`. Entre mensagens diferentes, manter 0.85 (evita apagar histórico legítimo).
3. Log verbose indicando quais facts foram descartados por dedup agressivo (pra auditoria).

### P2 — Reranker específico > abstrato com exemplos sintéticos

**Raiz:** a tentativa v0.13.10 adicionou a regra `Prefer SPECIFIC facts over ABSTRACT ones` mas em formato abstrato (sem exemplos). O LLM não aterrou.

**Mudança:** adicionar ao prompt do reranker (`src/arandu/read/reranker.py:_RERANKER_SYSTEM_PROMPT`) exemplos **sintéticos genéricos** (não do LoCoMo — nada de "Caroline", "Melanie", "Sweden"). Exemplos tipo:
```
Query: "What did X visit last week?"
Fact A: "X visited the Eiffel Tower on Tuesday" → score 0.9 (specific)
Fact B: "X had an interesting trip" → score 0.3 (abstract)

Query: "What book did X read?"
Fact A: "X read 'The Great Gatsby' in March" → score 0.9
Fact B: "X enjoys reading" → score 0.3
```

### P3 — Composed facts na extração

**Raiz:** quando o usuário menciona uma enumeração ("I play clarinet and violin"), o extractor quebra em N fatos atômicos. No retrieval, só 1 vem. Gerador nunca vê o conjunto.

**Mudança:** adicionar regra no prompt de extração (blind + informed): enumerações co-ocorrentes na mesma mensagem, pertencentes à mesma propriedade do mesmo subject, devem virar 1 fato composto. Exemplos sintéticos:
```
Input: "I play piano and guitar"
Output: 1 fato: "X plays piano and guitar"
NOT: 2 fatos "X plays piano" + "X plays guitar"

Input: "I have two cats and a dog"
Output: 1 fato: "X has two cats and a dog"
```

## Success Criteria

1. **Benchmark primário:** Arandu LoCoMo v0.14.x (nova versão) atinge **≥82%** (baseline 76.4% + ganho mínimo 5.6pp). Target realista 84-86%. Stretch 88%+.
2. **Nenhuma regressão grave por categoria:** com a lição da v0.13.8/v0.13.10, cada categoria (single-hop, multi-hop, temporal, open-domain, adversarial) deve ficar a no máximo -2pp da baseline v0.13.7. Regressão de -5pp como v0.13.10 single-hop é critério de revert.
3. **Tamanho do grafo controlado:** facts não crescem >10% (baseline 846). Evita o erro v0.13.8 que foi a 1137 facts (+34%) e degradou ranking.
4. **Ablação por intervenção:** cada uma (P1, P2, P3) roda em release separada. Se P1 não mover ≥2pp isolado, o diagnóstico está errado — parar antes de P2/P3.
5. **CI verde:** ruff + ruff format + mypy + pytest todos passando antes de cada bump de versão.
6. **Docs atualizados:** docs/en + docs/pt-BR refletindo mudanças. Sem data leakage do LoCoMo nos prompts.

## Scope v0

**P1 (release v0.14.0):**
- Alterar `src/arandu/write/semantic_dedup.py` ou criar `src/arandu/write/intra_event_dedup.py` com dedup intra-event mais agressivo.
- Alternativa considerada: dedup LLM leve ("escolhe o mais específico") — só se o threshold baixado sozinho não resolver.
- Testes unitários do comportamento novo (pares de fatos do mesmo event com similaridade 0.75-0.85).
- Ablação: rodar LoCoMo v0.14.0 via arandu-inspector. Se subir ≥2pp, ok. Se não, investigar antes de P2.

**P2 (release v0.14.1):**
- Alterar `src/arandu/read/reranker.py` — adicionar 2-3 exemplos sintéticos ao `_RERANKER_SYSTEM_PROMPT`. Nenhum exemplo envolve entidades do LoCoMo.
- Ablação: LoCoMo v0.14.1. Se subir ≥1pp adicional sobre v0.14.0, ok.

**P3 (release v0.14.2):**
- Alterar `src/arandu/write/extract.py` (FACT_EXTRACTION_PROMPT_TEMPLATE) e `src/arandu/write/informed_extract.py` (INFORMED_EXTRACTION_PROMPT) com regra de composed facts + 2 exemplos sintéticos.
- Testes unitários de extração com input contendo enumerações.
- Ablação: LoCoMo v0.14.2. Se subir ≥1pp adicional, ok.

**Fix A (consolidado em uma das releases acima ou v0.14.3 dedicada):**
- Regra verbatim no extraction (já parcialmente presente). Revisitar se precisa reforço.

Cada release tem:
- Bump de versão no `pyproject.toml`
- Docs EN + PT-BR atualizados
- Notificação ao usuário pra disparar release manual no GitHub Actions
- Cross-post em `Projetos/Arandu/Conversas Agentes/` pro Inspector rodar benchmark

## Anti-scope

- **Episódio como primitiva / reframing estrutural** — cross-ref mostrou que só resolveria 2/47 erros. Custo-benefício péssimo. Descartado.
- **Os 13 mecanismos neurocientíficos** do documento `Estudos/Memória/Memória - Altas Habilidades & Arquitetura.md` (RIF, reconsolidation PE, replay estocástico, state-dependent retrieval, grid cells, hash mnemônico, etc) — continuam úteis **pra outros benchmarks** (MemoryArena) e **pesquisa futura**, mas não pra fechar o gap LoCoMo atual. Descartados desta release.
- **Mexer no prompt de generation** — quebra comparação justa com Backboard/Mem0/Zep que usam prompt comum do LoCoMo. Descartado.
- **Mudança de schema do banco** — não é necessária pras 3 intervenções. Todas são mudanças em prompts + lógica de filtro no pipeline existente.
- **Adversarial fix (P4)** — os 9 casos adversarial_fix_outro precisam de intervenção dedicada no retrieval (filtro estrito de entidade). Fica pra spec futura — tem risco de regressão de recall, precisa ablação cuidadosa.
- **Chunking episódico à la MemCell+MemScene do EverMemOS** — pra cruzar 90%+ provavelmente precisaria, mas é escopo grande. Meta dessa release é 84-86%, não SOTA absoluto.
- **Date-cue multi-granular, suppression gate, hash mnemônico** — LoCoMo temporal tá em 97.3%, não é gargalo. Ficam pra benchmarks onde temporal é o alvo.

## Technical Context

### Arquivos que provavelmente serão tocados (confirmar no spec):
- `src/arandu/write/semantic_dedup.py` (existe? verificar — código de dedup atual)
- `src/arandu/write/extract.py:55` (FACT_EXTRACTION_PROMPT_TEMPLATE — P3)
- `src/arandu/write/informed_extract.py:50` (INFORMED_EXTRACTION_PROMPT — P3)
- `src/arandu/read/reranker.py:23` (_RERANKER_SYSTEM_PROMPT — P2)
- `src/arandu/write/reconcile.py` (possivelmente — se dedup intra-event for lá)
- Testes correspondentes em `tests/`

### Patterns do projeto a seguir:
- `.vibeflow/patterns/llm-interaction.md` — LLM call com temperature=0, JSON mode, timeouts, fail-safe com fallback.
- `.vibeflow/patterns/pipeline-orchestration.md` — write path passa por extract → semantic_dedup → entity_resolution → reconcile → upsert.
- `.vibeflow/patterns/testing.md` — mock-based, fake providers, sem DB.
- `.vibeflow/conventions.md` — async SQLAlchemy com savepoints, Pydantic models, type hints completos.

### Constraints conhecidos:
- **Comparação justa com concorrentes:** prompts de generation não podem ser alterados. Mudanças ficam restritas a write pipeline + retrieval/reranker.
- **Sem data leakage:** nenhum exemplo nos prompts pode conter entidades do LoCoMo (Caroline, Melanie, Sweden, Perseid, Stained Glass, Matt Patterson, Becoming Nicole, clarinet, violin). Exemplos devem ser sintéticos genéricos.
- **Rodar full CI antes de qualquer commit** (ruff + ruff format + mypy + pytest). Já quebrou CI 3+ vezes por pular mypy.
- **Bump de versão a cada release**, docs EN + PT-BR atualizados, avisar Pedro pra disparar release manual.
- **Ablação por release:** v0.14.0 (P1), v0.14.1 (P2), v0.14.2 (P3). Se uma delas regredir, revert antes de seguir.

### Lições das tentativas anteriores:
- **v0.13.8 (verbatim + inventory + remover known-info filter):** regrediu -5pp. Causa: inflou grafo +34%. **Nunca mais misturar múltiplas mudanças numa release.**
- **v0.13.10 (regras abstratas de específico > abstrato):** regrediu -3pp. Causa: regras abstratas sem exemplos não ancoram. **Usar sempre exemplos concretos nos prompts**, sintéticos genéricos pra evitar data leakage.

## Open Questions

1. **Threshold do dedup semântico intra-event:** 0.75? 0.80? Começar com 0.78 e ajustar? Depende de medir impacto em casos reais do LoCoMo — pode virar decisão da spec.
2. **Dedup LLM vs baixar threshold:** se baixar threshold sozinho não resolver os casos reais (stained glass vs artwork, etc), vale adicionar passo LLM "qual é mais específico?". Mas isso adiciona custo. Decidir na spec com base no custo-benefício medido.
3. **Composed facts e reconcile:** se "Melanie plays clarinet and violin" virar 1 fato composto, como fica a reconciliação se depois ela disser "I also play the piano"? Vira fato novo "Melanie plays piano" separado, ou faz UPDATE composto pra "clarinet, violin and piano"? Provavelmente separado é mais seguro. Decidir na spec.
4. **Ordem de execução P1 → P2 → P3 vs paralelo:** ablação exige sequencial. Mas tempo total é 2-3 semanas sequencial vs ~1 semana paralelo. Sequencial é o correto pela lição da v0.13.8. **Decisão: sequencial com ablação por versão.**
