# Spec: P1 — Dedup semântico intra-event agressivo

> **STATUS: DESCARTADO PÓS-BENCHMARK (2026-05-16).** Implementação rodou v0.14.0/v0.14.1 e foi revertida em v0.14.2. Benchmark LoCoMo: single-hop +9.4pp (65.6%→75.0%, validou diagnóstico) **mas** open-domain -23.1pp (84.6%→61.5%, regressão catastrófica), overall -1.5pp. Grafo encolheu -23.5% facts. Mantido como histórico — não re-implementar sem resolver o trade-off com open-domain (provavelmente requer dedup ciente de contexto temático, não só similaridade textual). Ver PRD pai pra contexto.

> Generated from PRD: `.vibeflow/prds/fix-b1-dedup-reranker-composed.md` (part 1/3)
> Target release: v0.14.0

## Objective

Adicionar uma segunda passada de dedup semântico com threshold mais agressivo (0.78) **aplicada apenas entre facts do mesmo `source_event` e mesmo `subject`**, pra eliminar duplicatas tipo "Caroline made a stained glass window" + "Caroline created an artwork for a local church" que hoje coexistem no DB e fazem o abstrato ganhar no ranking.

## Context

Hoje o write pipeline (`src/arandu/write/pipeline.py:83 _semantic_dedup_facts`) faz dedup pairwise com threshold 0.85 **uniforme** entre todos os facts extraídos da mesma mensagem. Pares abstrato/específico do mesmo evento (cosseno ~0.65-0.80) passam o filtro e viram facts separados no DB.

Análise cross-ref dos 47 erros LoCoMo v0.13.7 identificou 9 casos (19%) onde o fato específico **existe no DB** (confirmado no write_trace) mas não chega ao top-5 do retrieve porque um fato abstrato do mesmo turn ganha o ranking. Casos concretos verificados:

- Turn 288: "Caroline's necklace is a gift from Caroline's grandma **in Sweden**" (específico) coexiste com "Caroline moved from Caroline's **home country**" (abstrato). Top-1 do retrieve pra query "Where did Caroline move from?" foi o abstrato. GT: "Sweden". GEN: "home country".
- Turn 114: "Caroline made a **stained glass window**" coexiste com "Caroline created an **artwork** for a local church". Top-1 foi o abstrato. GT: "stained glass window". GEN: "an artwork".
- Turn 31: 3 facts sobre "**Perseid meteor shower**" coexistem com facts genéricos do mesmo camping trip. Nenhum Perseid chegou ao top-5.

Não é fix de prompt (v0.13.10 tentou e regrediu -3pp). É fix de arquitetura: facts duplicados **não deveriam coexistir** no DB em primeiro lugar.

## Definition of Done

1. Pipeline de write aplica **dedup em duas fases** após extração: (a) dedup uniforme existente com threshold 0.85 entre todos os facts do turn; (b) **nova fase** — dedup agressivo com threshold configurável (default 0.78) aplicado apenas entre facts com o mesmo `subject` (case-insensitive, pós-normalização de alias).
2. Quando dois facts do mesmo subject com similaridade ≥ threshold agressivo são detectados, o **mais específico é mantido** (heurística determinística: maior `len(fact.fact)` como proxy de especificidade, documentado em docstring). Empate (mesmo tamanho) mantém o primeiro.
3. Config `MemoryConfig` ganha campo `intra_subject_dedup_threshold: float = 0.78` e `intra_subject_dedup_enabled: bool = True`. Flag permite rollback rápido se regredir.
4. Trace verbose (`write(verbose=True)`) inclui novo step `intra_subject_dedup` com lista de `(kept_fact, discarded_fact, similarity)` pra auditoria.
5. Testes unitários cobrem: (a) par stained-glass-vs-artwork simulado é deduplicado; (b) dois facts de subjects diferentes NÃO são deduplicados mesmo com similaridade alta; (c) facts do mesmo subject abaixo do threshold agressivo são preservados; (d) flag `enabled=False` desabilita a fase nova sem afetar a fase uniforme.
6. **Craftsmanship gate:** implementação segue o pattern de [llm-interaction.md](../patterns/llm-interaction.md) (fail-safe — erro na nova fase retorna facts originais, não propaga exceção) e [pipeline-orchestration.md](../patterns/pipeline-orchestration.md) (função async isolada, caller gerencia savepoint se aplicável). Sem novos `type: ignore` ou `Any`. Ruff + ruff format + mypy + pytest verdes.
7. Bump versão pra **0.14.0** (minor — comportamento observável muda). Docs EN + PT-BR em `concepts/write-pipeline.md` refletem a nova fase. Avisar usuário pra disparar release.

## Scope

- Modificar `src/arandu/write/pipeline.py`:
  - Criar função `_intra_subject_dedup_facts(facts, embeddings, threshold)` análoga a `_semantic_dedup_facts` mas agrupando por `subject` primeiro, depois fazendo dedup pairwise dentro do grupo.
  - Chamar a nova fase **depois** da `_semantic_dedup_facts` existente no `run_write_pipeline`.
  - Heurística de "mais específico = maior `len(fact)`" — fácil e determinística. Alternativa LLM foi considerada no PRD e descartada por custo.
  - Trace step adicional no verbose.
- Modificar `src/arandu/config.py` (ou onde `MemoryConfig` mora) pra adicionar os 2 campos novos.
- Testes novos em `tests/test_write_pipeline.py` ou `tests/test_intra_subject_dedup.py` (decidir conforme convenção do projeto — olhar outros test files similares).
- Atualizar `docs/en/concepts/write-pipeline.md` e `docs/pt-BR/concepts/write-pipeline.md` com descrição da nova fase.
- Bump `pyproject.toml` pra 0.14.0.

## Anti-scope

- **Dedup baseado em LLM** ("qual é mais específico?") — considerado no PRD, descartado pra v0 por custo. Se heurística `len()` não performar, abrir spec separada.
- **Dedup cross-event** (entre turns diferentes) — risco de apagar histórico legítimo. Mantém threshold 0.85 uniforme pra isso, como hoje.
- **Reconciliação LLM durante dedup** — o reconcile existente em `reconcile.py` roda depois e continua fazendo sua parte. Esta spec **não** mexe em reconcile.
- **Mexer nos prompts de extração** — Fix de prompt é parte do P3 (composed facts). Desta spec não.
- **Reranker changes** — é P2, spec separada.
- **Ablação cross-version** — cada release roda isolada. Esta spec entrega v0.14.0 pronta pra ablação; a análise do benchmark é trabalho separado do Inspector.

## Technical Decisions

**Threshold 0.78** (default):
- PRD propôs 0.75-0.80. Escolhi 0.78 como meio-termo.
- Trade-off: mais baixo elimina mais duplicatas (bom pra B1) mas pode apagar facts distintos do mesmo subject que compartilham vocabulário (e.g., "Melanie plays clarinet" vs "Melanie plays violin" pode ter cosseno ~0.75 — indesejável apagar). Filtro por mesmo-subject reduz esse risco mas não elimina.
- Mitigação: flag `intra_subject_dedup_threshold` permite tuning empírico após primeira rodada de benchmark. Se 0.78 apagar casos legítimos, subir pra 0.80.

**Heurística "maior fact text = mais específico":**
- Trade-off: proxy imperfeito. "Caroline moved from Caroline's home country" (46 chars) vs "Caroline's necklace is a gift from Caroline's grandma in Sweden" (66 chars) — sortudo que o específico é mais longo.
- Alternativa considerada: LLM escolhe. Custo adicional ~1 call por turn com duplicatas. Descartado pra v0 (pode virar spec separada se heurística falhar).
- Empate: mantém primeiro (comportamento estável/determinístico).

**Nova fase vs. alterar existente:**
- Poderia alterar `_semantic_dedup_facts` existente pra ter dois thresholds condicionais. Escolhi fase nova separada porque:
  1. Rollback é trivial (`intra_subject_dedup_enabled=False`).
  2. Ablação A/B é mais limpa (desabilita a fase nova, compara com baseline).
  3. Código mais legível — uma responsabilidade por função.

**Flag enabled por default:**
- PRD quer subir performance imediata. Default `True` entrega isso. Se regredir, usuário pode desabilitar via `MemoryConfig(intra_subject_dedup_enabled=False)` sem downgrade.

## Applicable Patterns

- **[pipeline-orchestration.md](../patterns/pipeline-orchestration.md)** — função async isolada no pipeline, fail-safe, caller gerencia transação. Seguir estritamente.
- **[dependency-injection.md](../patterns/dependency-injection.md)** — usar `EmbeddingProvider` via DI, não criar instância.
- **[error-handling.md](../patterns/error-handling.md)** — try/except retornando input original em caso de falha (já é o padrão do `_semantic_dedup_facts` atual — imitar).
- **[testing.md](../patterns/testing.md)** — mock `EmbeddingProvider` com vetores fixos, sem DB.

## Risks

**R1: Threshold 0.78 apaga facts legítimos distintos do mesmo subject.**
- Exemplo: "Melanie plays clarinet" + "Melanie plays violin" podem ter cosseno alto por compartilhar estrutura.
- Probabilidade: média.
- Mitigação: P3 (composed facts) ataca esses casos pela origem, preferindo extração composta. Se os dois convergirem, o risco evapora. Curto prazo: flag pra tunar threshold; teste de regressão bem desenhado pra pegar casos assim.

**R2: Heurística `len()` mantém o errado.**
- Probabilidade: baixa — casos reais do LoCoMo têm específico mais longo que abstrato. Mas possível.
- Mitigação: trace verbose documenta o par descartado. Se ablação mostrar regressão, trocar por LLM.

**R3: Regressão em outras categorias LoCoMo por remover fatos que eram úteis em queries específicas.**
- Probabilidade: baixa-média.
- Mitigação: benchmark **por categoria** (single-hop, multi-hop, temporal, open-domain, adversarial). Se qualquer categoria regredir >2pp, revert via flag.
- Lição v0.13.8/v0.13.10: não seguir pro P2 sem confirmar ganho isolado do P1.

**R4: Regressão em accuracy global mesmo com ganho nos 9 casos B1-real.**
- Probabilidade: baixa se R1 e R3 forem controlados.
- Mitigação: critério de abort claro — se v0.14.0 não subir ≥2pp isolado, investigar antes de seguir pro P2.

**R5: Performance (nova fase adiciona embed + pairwise cossine).**
- Probabilidade: baixa. Embed já é chamado na fase existente (cache idêntico). Pairwise é O(n²) mas n típico ≤10 facts/turn.
- Mitigação: reusar embeddings já calculados da fase 1 se possível (otimização opcional — não bloquear release).

## Dependencies

Nenhuma spec prévia. Esta é a primeira da sequência. Part 2 e Part 3 dependem **da ablação bem-sucedida** desta.
