# Spec: P3 — Composed facts na extração

> **STATUS: NUNCA IMPLEMENTADO — DESCARTADO (2026-05-16).** Dependia das parts 1 e 2. Cadeia inteira descartada após v0.14.1 regredir e ser revertida em v0.14.2. Mantido como histórico da hipótese (instruir extração a emitir composed facts ao invés de pares abstrato+específico).

> Generated from PRD: `.vibeflow/prds/fix-b1-dedup-reranker-composed.md` (part 3/3)
> Target release: v0.14.2
> Dependencies: `.vibeflow/specs/fix-b1-part-1-intra-event-dedup.md` + `.vibeflow/specs/fix-b1-part-2-reranker-specificity.md` mergeados, com ganho cumulativo confirmado por benchmark.

## Objective

Adicionar regra explícita no prompt de extração (blind + informed) instruindo o LLM a emitir **1 fato composto** para enumerações co-ocorrentes da mesma propriedade do mesmo subject numa mesma mensagem, ao invés de N facts atômicos. Alvo direto: casos B0 onde enumerações viram facts separados e o retrieval traz só um.

## Context

Cross-ref dos 47 erros LoCoMo mostra 8 casos (17%) classificados como B0 — enumerações fragmentadas. Exemplos verificados no DB:

- Turn 158: usuário disse "I play clarinet and violin" (approximadamente). LLM extraiu "Melanie plays the clarinet" + facts acessórios sobre clarinet. O violino virou fato atômico separado que não chegou ao top-5. Query "What instruments does Melanie play?" → "clarinet" (violino perdido).
- Similar pra "Summer Sounds, Matt Patterson" (concertos), "Figurines, shoes" (itens comprados), "Two cats and a dog" (pets — LLM gerou contagem errada por ver só parte).

Composed facts força o LLM a manter a enumeração coesa num único fato, garantindo que o retrieval traga o conjunto completo. Isso converge conceitualmente com:

- Chunking episódico (Chase & Simon 1973, Cowan 2018) — padrões coerentes são armazenados como unidade
- EverMemOS MemCell (SOTA 92.3% LoCoMo) faz algo similar via narrativa
- Gifted adults chunkam melhor (Lemaire 2021)

Diferença de P1/P2: P1 é dedup de **facts duplicados** do MESMO evento. P3 é evitar **fragmentação** de enumerações durante a extração. São ortogonais — P1 não atacaria a fragmentação de clarinet/violin porque os dois facts são diferentes, não duplicados.

## Definition of Done

1. `FACT_EXTRACTION_PROMPT_TEMPLATE` em `src/arandu/write/extract.py` tem regra nova "COMPOSE ENUMERATIONS" com 2 exemplos sintéticos genéricos (sem entidades LoCoMo).
2. `INFORMED_EXTRACTION_PROMPT` em `src/arandu/write/informed_extract.py` tem a mesma regra + mesmos exemplos (consistência entre blind e informed).
3. Regra instrui explicitamente: quando a mesma mensagem contém múltiplos itens pertencentes à mesma propriedade do mesmo subject (instruments played, pets owned, items bought, activities done, people met), emitir **1 fato composto** ao invés de N atômicos. Exemplo no prompt usa formato didático tipo:
   ```
   Input: "I play piano and guitar, and I own a cat"
   Correct extraction:
     - X plays piano and guitar  ← composed
     - X owns a cat              ← atomic (sem enumeração)
   Wrong extraction:
     - X plays piano
     - X plays guitar
     - X owns a cat
   ```
4. **Regex/test de data leakage** (mesmo do Part 2, estendido pra extract.py e informed_extract.py) — guarda contra exemplos do LoCoMo.
5. Testes unitários simulados: mock do `LLMProvider` retorna JSON com enumeração composta (1 fato "X plays piano and guitar") — pipeline deve aceitar e armazenar corretamente. O teste **não** valida que o LLM "obedeceu" a regra (isso é empírico via benchmark) — valida que o pipeline downstream (reconcile, upsert, retrieval) aceita o formato composto sem quebrar.
6. **Craftsmanship gate:** prompts continuam respeitando pattern de [llm-interaction.md](../patterns/llm-interaction.md). Ruff/ruff format/mypy/pytest verdes. Sem regressão em testes existentes de extração.
7. Bump versão pra **0.14.2** (patch — só prompt change). Docs EN + PT-BR em `concepts/write-pipeline.md` documentam a regra de composição com 1 exemplo. Avisar usuário.

## Scope

- Modificar `src/arandu/write/extract.py:FACT_EXTRACTION_PROMPT_TEMPLATE` (linha ~55-77). Adicionar a regra.
- Modificar `src/arandu/write/informed_extract.py:INFORMED_EXTRACTION_PROMPT` (linha ~50-115). Adicionar a mesma regra.
- Estender o teste de leakage do Part 2 pra cobrir os 2 prompts de extração também, OU criar `tests/test_extraction_prompt_no_leakage.py` dedicado (decidir conforme limpeza — se o do Part 2 fica genérico, estender é mais DRY).
- Teste de integração com mock LLM retornando fato composto — verifica que reconcile+upsert aceitam (sem quebrar schema ou validation).
- Docs EN + PT-BR em `concepts/write-pipeline.md`.
- Bump `pyproject.toml` pra 0.14.2.

## Anti-scope

- **Refatoração de schema pra expressar "enumeração composta" como first-class** (campo dedicado) — fora. Vai como texto único no campo `fact` existente.
- **Mudança em reconcile pra detectar enumerações já compostas** — não é necessário. O reconcile trabalha sobre texto do fato como hoje.
- **Forçar composição via regex/post-processing** (parse a saída do LLM e detectar "X plays piano" + "X plays guitar" pra mergear) — descartado por fragilidade. Confiamos no LLM com a instrução + exemplos. Se falhar empiricamente, abrir spec separada.
- **Tratar "also plays piano" como UPDATE do fato composto existente** — tricky e fora deste escopo. O reconcile atual trata como fato novo ou NOOP. Se virar problema, spec separada.
- **Examples LoCoMo** — explicitamente proibido pelo DoD 4.
- **Mexer em reranker, dedup, ou outros componentes** — partes 1 e 2.

## Technical Decisions

**Composição dentro do campo `fact` existente (sem schema change):**
- Simplicidade. "Melanie plays clarinet and violin" é texto válido pro `fact_text`.
- Downstream (reconcile, upsert, embedding, retrieval) trata como qualquer fato — não precisa saber que é composto.
- Trade-off: perdemos estrutura pra queries tipo "quantos instrumentos?" via grafo. Mas LoCoMo não exige isso, e o LLM-gerador responde a partir do texto composto sem precisar de estrutura.

**Instrução via prompt + 2 exemplos (não 1, não 4+):**
- 1 é pouco (não demonstra variação — item enumerado vs item singular na mesma mensagem).
- 4+ infla prompt. 2 mostra: caso COM enumeração (composto) + caso SEM (atômico normal) na mesma extração.

**Aplicação em blind E informed extraction:**
- Consistência. Ambos devem produzir facts no mesmo formato — o pipeline downstream não distingue.
- Custo: dobra do esforço de edição, mas é trivial (copy-paste-adapt do texto). Mantém superfície de comportamento uniforme.

**Escopo de "mesma propriedade":**
- Prompt enumera explicitamente: instruments, pets, items bought, activities, people met. Lista indicativa, não exaustiva — LLM generaliza.
- Não vale forçar composição pra propriedades distintas: "I play piano and went hiking" deve virar 2 fatos (piano; hiking), não 1. Exemplo negativo no prompt cobre isso.

**Por que não forçar composição no DB (post-LLM):**
- Parseria texto via regex — frágil. "I play the clarinet and the violin" vs "I play both clarinet and violin, but not the piano" requer NLP, não regex.
- Confiar no LLM é mais escalável, mesmo que imperfeito. Benchmark valida.

## Applicable Patterns

- **[llm-interaction.md](../patterns/llm-interaction.md)** — prompts como constantes module-level, template com f-string de `{speaker_name}`. Seguir.
- **[pipeline-orchestration.md](../patterns/pipeline-orchestration.md)** — extração é etapa isolada; downstream (reconcile, upsert) continua idempotente.
- **[testing.md](../patterns/testing.md)** — mock do `LLMProvider` retornando JSON fixtures. Seguir.

## Risks

**R1: LLM ignora a regra e continua fragmentando.**
- Probabilidade: média — modelos podem aderir parcialmente a regras novas.
- Mitigação: exemplos claros ajudam. Se empírico mostrar <50% de adesão, considerar post-processing via regex como fallback em spec futura.

**R2: LLM **over-compõe** — mergeia propriedades que deveriam ficar separadas.**
- Exemplo: "X plays piano and likes music" vira 1 fato "X plays piano and likes music" (propriedades diferentes mescladas).
- Probabilidade: média.
- Mitigação: exemplo negativo explícito no prompt ("plays piano and went hiking" → 2 fatos). Testes de benchmark devem capturar.

**R3: Reconciliação trata fato composto novo como contradição de fato composto antigo.**
- Exemplo: turn 10: "Melanie plays clarinet and violin". Turn 200: "I'm learning piano too". Reconciliação vê dois facts (composto vs. novo singular) e fica confusa.
- Probabilidade: média.
- Mitigação: no curto prazo, o reconcile atual trata como fatos distintos (não contradição explícita) — ambos convivem. Não é ideal mas não quebra. Se virar problema concreto, spec futura pra "UPDATE composto".

**R4: Inflação do grafo (cada enumeração virou 1 fato mais longo, pode ter mais embed tokens).**
- Probabilidade: baixa. Redução de N facts → 1 fato é REDUÇÃO do tamanho do grafo, não aumento.
- Risco revertido: compor REDUZ número de facts. Bom pra saturação de retrieve.

**R5: Regressão em queries que dependiam de fact atômico (ex: "does X play clarinet?" retorna o composto "plays clarinet and violin" — OK porque contém "clarinet", mas o score semântico do específico caiu).**
- Probabilidade: baixa. Query "does X play clarinet?" vs fact "X plays clarinet and violin" tem similaridade alta mesmo composto.
- Mitigação: benchmark por categoria.

**R6: Adesão varia entre blind e informed extraction (inconsistência no DB).**
- Probabilidade: baixa — mesma regra em ambos prompts.
- Mitigação: regra + exemplos idênticos em ambos (DoD 2).

## Dependencies

- `.vibeflow/specs/fix-b1-part-1-intra-event-dedup.md` + `.vibeflow/specs/fix-b1-part-2-reranker-specificity.md` — ambos mergeados, com benchmarks confirmando ganhos.
- Lição v0.13.8: **não empilhar 3 mudanças numa mesma release sem ablação**. Esta spec só é executada após P1 + P2 demonstrarem ganho isolado.
