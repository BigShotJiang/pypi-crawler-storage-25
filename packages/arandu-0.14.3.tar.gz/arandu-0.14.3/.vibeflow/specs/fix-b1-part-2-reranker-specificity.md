# Spec: P2 — Reranker prefere específico com exemplos sintéticos

> **STATUS: NUNCA IMPLEMENTADO — DESCARTADO (2026-05-16).** Dependia da part 1, que regrediu no benchmark e foi revertida em v0.14.2. Cadeia inteira descartada. Mantido como histórico da hipótese (preferir específico no reranker via exemplos sintéticos), pode ser revisitada em outra forma se a proposta arquitetural v2 a justificar.

> Generated from PRD: `.vibeflow/prds/fix-b1-dedup-reranker-composed.md` (part 2/3)
> Target release: v0.14.1
> Dependencies: `.vibeflow/specs/fix-b1-part-1-intra-event-dedup.md` deve estar mergeado e com benchmark ≥+2pp vs v0.13.7.

## Objective

Retomar a regra "prefer specific over abstract" no prompt do reranker (`_RERANKER_SYSTEM_PROMPT`) **com exemplos sintéticos genéricos** (não do LoCoMo), resolvendo o problema de ancoragem que fez a v0.13.10 regredir -3pp.

## Context

A v0.13.10 adicionou ao `_RERANKER_SYSTEM_PROMPT` a regra:

```
- Prefer SPECIFIC facts over ABSTRACT ones when both could answer the query.
  A fact that names a concrete object, place, person, date, or number is more
  likely to directly answer a question than a fact about feelings, themes,
  or general abstractions about the same topic. Only rank the abstract fact
  higher when no specific fact is available to answer the query.
```

A regra **conceitualmente está certa** — o próprio cross-ref dos 47 erros confirma que o padrão B1 é exatamente "abstrato ganhou do específico". Mas sem exemplos concretos, o LLM não ancorou e o resultado foi regressão.

EverMemOS e outros sistemas SOTA usam exemplos em todos os prompts críticos. Pesquisa confirma (dual coding theory, few-shot learning): regras abstratas são instruções vagas, exemplos ancoram.

Mas tem uma armadilha: se os exemplos forem tirados do LoCoMo ("Caroline", "stained glass window"), vira **data leakage** — o sistema fica tunado pro benchmark, não generaliza. A v0.13.10 evitou isso corretamente. O fix é: exemplos **sintéticos genéricos**, entidades inventadas.

## Definition of Done

1. `src/arandu/read/reranker.py:_RERANKER_SYSTEM_PROMPT` tem 2-3 exemplos sintéticos na seção de preferência por específico. Exemplos usam entidades **inventadas** (placeholders tipo "X", "Person A", ou nomes claramente fictícios como "Ada Lovelace", "Turing", "Lisbon") — **não** Caroline, Melanie, Sweden, Perseid, stained glass, clarinet, Matt Patterson, Becoming Nicole.
2. Cada exemplo mostra: query, fact específico com score alto (0.8-0.95), fact abstrato com score baixo (0.2-0.4), breve racional. Formato compacto (≤3 linhas por exemplo).
3. **Regex/test de data leakage:** test que varre `_RERANKER_SYSTEM_PROMPT` procurando qualquer string em uma lista de termos LoCoMo proibidos (Caroline, Melanie, Sweden, Perseid, stained glass, clarinet, violin, Matt Patterson, Becoming Nicole, Mount Rainier). Falha se encontrar. Esse teste vira guardrail permanente.
4. Testes existentes de reranker (`tests/test_reranker*.py` se existirem) continuam verdes. Nenhum novo teste funcional de comportamento (comportamento é o mesmo — só prompt mudou; efeito é empírico no benchmark).
5. **Craftsmanship gate:** prompt segue pattern de [llm-interaction.md](../patterns/llm-interaction.md) — constante module-level, template com f-string se aplicável, documentação clara no docstring do módulo. Sem regressão em testes existentes. Ruff/ruff format/mypy/pytest verdes.
6. Bump versão pra **0.14.1** (patch — só prompt change). Docs EN + PT-BR em `concepts/read-pipeline.md` mencionam a preferência por específico com 1 exemplo abstrato. Avisar usuário pra disparar release.

## Scope

- Modificar `src/arandu/read/reranker.py`:
  - Expandir bullet "Prefer SPECIFIC over ABSTRACT" no prompt com 2-3 exemplos sintéticos
  - Nenhuma mudança em lógica de blend, threshold, filter — só o texto do prompt
- Adicionar `tests/test_reranker_prompt_no_leakage.py` com o regex guard contra data leakage
- Atualizar `docs/en/concepts/read-pipeline.md` e `docs/pt-BR/concepts/read-pipeline.md` (seção sobre reranker) com mais detalhe sobre a preferência
- Bump `pyproject.toml` pra 0.14.1

## Anti-scope

- **Mudanças em reranker_weight, min_reranker_score, topk ou qualquer scoring** — fora desta spec.
- **Dedup, extração, reconcile** — partes 1 e 3.
- **Mudar formato da chamada LLM** (temperature, response_format) — fora.
- **Exemplos do LoCoMo mesmo que "seriam úteis"** — explicitamente proibido pelo DoD 3.
- **Adicionar regra nova além de "prefer specific"** — qualquer regra adicional deve ser spec separada.

## Technical Decisions

**Escolha dos exemplos sintéticos:**
- Usar contextos que provavelmente NÃO aparecem em LoCoMo mas são familiares ao LLM: tecnologia (programming language, framework), geografia genérica (cidades famosas não-LoCoMo tipo "Lisbon", "Tokyo"), livros/filmes clássicos ("1984", "The Odyssey"), números/datas claramente fictícios.
- **Evitar:** qualquer entidade que apareça em LoCoMo (lista no DoD 3). Se em dúvida, usar placeholder literal ("Person A", "Book X", "City Y").

**Formato dos exemplos:**
```
Example — query "What language does X code in?":
  Fact A: "X primarily codes in Rust" → 0.9 (names the language)
  Fact B: "X enjoys programming" → 0.3 (abstract about the activity)
```
Compacto, direto, mostra o racional sem explicação extra.

**Quantidade: 2-3 exemplos**:
- 1 é pouco (LLM pode ver como caso único); 4+ é inflar prompt sem ganho.
- 2-3 cobre variação de domínios (geografia, livros, atividades) sem redundância.

**Regex guard contra data leakage**:
- Defendível como "teste de processo" — garante que futuros edits do prompt não introduzam vazamento.
- Lista de termos LoCoMo é conhecida (do cross-ref dos 47 erros). Se crescer, fácil adicionar.

## Applicable Patterns

- **[llm-interaction.md](../patterns/llm-interaction.md)** — prompt como constante module-level. Já segue, manter.
- **[testing.md](../patterns/testing.md)** — novo teste é puro (sem mock, só string search no prompt). Segue convenção simples.

## Risks

**R1: Exemplos sintéticos ancoram demais pra domínios específicos.**
- Probabilidade: baixa se os exemplos variam de domínio (como especificado acima).
- Mitigação: ter 2-3 exemplos de domínios diferentes. Se algum resultado empírico mostrar overfit pra domínio do exemplo, trocar.

**R2: LLM continua não aterrando mesmo com exemplos, benchmark não sobe.**
- Probabilidade: média.
- Mitigação: se v0.14.1 não subir ≥0.5pp sobre v0.14.0 isolado, considerar que o reranker atual já é suficiente e a maior parte do ganho veio do P1. Não seguir cegamente pro P3. Investigar.

**R3: Regressão em queries onde o **abstrato realmente era a melhor resposta** (ex: open-domain que exige síntese).**
- Probabilidade: baixa — a regra diz "when both could answer the query", deixando espaço pro abstrato ganhar em queries synthesis-oriented.
- Mitigação: benchmark por categoria. Open-domain é só 2 erros no baseline (13 corretos); se cair 1-2 pts é tolerável. Se cair 5+ pts, revert.

**R4: Data leakage introduzido acidentalmente no futuro.**
- Probabilidade: média ao longo do tempo.
- Mitigação: o regex guard do DoD 3 protege permanentemente.

**R5: Documentação EN/PT-BR "vaza" os exemplos sintéticos pra docs públicas**.
- Probabilidade: baixa (os exemplos são sintéticos, não são problema por si só).
- Não é risco real — os exemplos sintéticos podem ir pros docs sem problema. É o **oposto** que é risco (exemplos do LoCoMo).

## Dependencies

- `.vibeflow/specs/fix-b1-part-1-intra-event-dedup.md` — **precisa estar mergeado e com benchmark isolado mostrando ≥+2pp vs v0.13.7** antes desta spec ser executada.
- Sem isso, não há como isolar o efeito do reranker.
