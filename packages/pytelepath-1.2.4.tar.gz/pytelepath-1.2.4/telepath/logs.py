import traceback

import telegram


def _user_str(user: telegram.User | None) -> str:
    if user is None:
        return "Unknown"
    name = (user.first_name or "") + (" " + user.last_name if user.last_name else "")
    name = name.strip() or "User"
    tag = f"@{user.username}" if user.username else f"id={user.id}"
    return f"{name}({user.id} {tag})"


def _chat_str(chat: telegram.Chat | None) -> str:
    if chat is None:
        return "?"
    title = chat.title or chat.username or chat.first_name or str(chat.id)
    return f"{title}({chat.id})"


def _thread_str(msg: telegram.Message) -> str:
    if msg.is_topic_message and msg.message_thread_id:
        return f" #topic({msg.message_thread_id})"
    return ""


def _preview(text: str | None, n: int = 35) -> str:
    if not text:
        return '""'
    flat = text.replace("\n", " ")
    return f'"{flat[:n]}{"…" if len(flat) > n else ""}"'


def _reaction_str(rxns) -> str:
    parts = []
    for r in rxns:
        if isinstance(r, telegram.ReactionTypeEmoji):
            parts.append(r.emoji)
        else:
            parts.append("[custom]")
    return "".join(parts)


def _forward_str(msg: telegram.Message) -> str:
    fo = msg.forward_origin
    if fo is None:
        return ""
    if isinstance(fo, telegram.MessageOriginUser):
        return f" fwd:{_user_str(fo.sender_user)}"
    if isinstance(fo, telegram.MessageOriginChat):
        return f" fwd:{_chat_str(fo.sender_chat)}"
    if isinstance(fo, telegram.MessageOriginChannel):
        return f" fwd:{_chat_str(fo.chat)}#{fo.message_id}"
    if isinstance(fo, telegram.MessageOriginHiddenUser):
        return f" fwd:{fo.sender_user_name}"
    return " fwd:?"


def _reply_str(msg: telegram.Message) -> str:
    r = msg.reply_to_message
    if r is None:
        return ""
    preview = _preview(r.text or r.caption, 20)
    return f" re→#{r.message_id} {preview}"


def _msg_line(kind: str, user: telegram.User | None, chat: telegram.Chat | None,
              msg: telegram.Message, extra: str = "") -> str:
    user_str = _user_str(user)
    chat_str = _chat_str(chat)
    thread = _thread_str(msg)
    fwd = _forward_str(msg)
    reply = _reply_str(msg)
    text = _preview(msg.text or msg.caption)
    return f"[{kind}] {user_str} → {chat_str}{thread}{fwd}{reply}{extra} | {text}\n"


def log_str_upd(u: telegram.Update) -> str:
    try:
        if u.message_reaction:
            r = u.message_reaction
            user_str = _user_str(r.user) if r.user else f"Chat:{_chat_str(r.actor_chat)}"
            added = [x for x in r.new_reaction if x not in r.old_reaction]
            removed = [x for x in r.old_reaction if x not in r.new_reaction]
            parts = []
            if added:
                parts.append(f"+{_reaction_str(added)}")
            if removed:
                parts.append(f"-{_reaction_str(removed)}")
            rxn = " ".join(parts) or "(cleared)"
            return f"[REACT] {user_str} → {_chat_str(r.chat)} | {rxn} | msg#{r.message_id}\n"

        if u.callback_query:
            cbq = u.callback_query
            msg = u.effective_message
            thread = _thread_str(msg) if msg else ""
            text_preview = _preview(msg.text if msg else None)
            return (f"[CBQ] {_user_str(u.effective_user)} → {_chat_str(u.effective_chat)}{thread}"
                    f" | {cbq.data!r} | {text_preview}\n")

        if u.edited_message or u.edited_channel_post:
            msg = u.edited_message or u.edited_channel_post
            return _msg_line("EDIT", u.effective_user, u.effective_chat, msg)

        if u.message or u.channel_post:
            msg = u.message or u.channel_post
            kind = "MSG" if u.message else "POST"
            return _msg_line(kind, u.effective_user, u.effective_chat, msg)

        return f"[UPD] #{u.update_id} {u!r}\n"

    except Exception:
        traceback.print_exc()
        return f"[UPD?] {u!r}\n"
