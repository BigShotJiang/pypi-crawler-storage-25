import functools
import inspect
import json
import logging
import traceback

import telegram
import telegram.ext as te

from . import logs



def answers_callback_query(func):
    @functools.wraps(func)
    async def wrapper(update: telegram.Update, context: te.ContextTypes.DEFAULT_TYPE):
        try:
            return await func(update, context)
        except:
            traceback.print_exc()
        finally:
            await context.bot.answerCallbackQuery(update.callback_query.id)
    
    
    return wrapper


def self_answers_callback_query(func):
    @functools.wraps(func)
    async def wrapper(self, update: telegram.Update, context: te.ContextTypes.DEFAULT_TYPE):
        try:
            return await func(self, update, context)
        except:
            traceback.print_exc()
        finally:
            await context.bot.answerCallbackQuery(update.callback_query.id)
    
    
    return wrapper


def log_update(name: str | None = None):
    def decor(func):
        _logger = logging.getLogger(name or func.__module__)
        
        
        def _log(update: telegram.Update):
            _logger.info(logs.log_str_upd(update))
            if _logger.isEnabledFor(logging.DEBUG):
                _logger.debug(json.dumps(update.to_dict(), ensure_ascii=False))
        
        
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def wrapper(*args, **kwargs):
                _log(args[-2])
                return await func(*args, **kwargs)
        else:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                _log(args[-2])
                return func(*args, **kwargs)
        
        return wrapper
    
    
    return decor


alog_update = log_update


def answers_callback_query_vargs(func):
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except:
            traceback.print_exc()
        finally:
            d = {type(arg): arg for arg in args}
            d.update({type(kw): kw for kw in kwargs.values()})
            update = d[telegram.Update]
            ctx = d[telegram.ext.ContextTypes.DEFAULT_TYPE]
            await ctx.bot.answerCallbackQuery(update.callback_query.id)
    
    
    return wrapper


def debounce(recharge_time=None):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    
    
    return wrapper
