ByQuant.com

安装:
pip install byquant_core==*

import byquant as by 不变

支持Windows、Linux、MacOS、鸿蒙等操作系统。

数据源API、大模型接口API（可选）、CPT接口API（可选）

更多数据源、大模型、柜台接口请联系管理员。

社群沟通：加入ByQuant量化投研群，QQ群：870702877 获取更多支持。

更多支持请访问: https://byquant.com/