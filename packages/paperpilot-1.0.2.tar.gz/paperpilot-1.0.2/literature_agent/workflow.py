from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from .corpus import corpus_items_from_papers, enhanced_deduplicate, split_corpus
from .pdf import attach_fulltext_paths, download_pdfs, enrich_unpaywall, extract_downloaded_fulltext
from .pdf_report import write_pdf_report
from .planner import make_plan
from .processing import apply_github_filter, enrich_github_links, rank_papers, resolve_code_links
from .protocol import build_protocol
from .query import understand_query
from .reflection import reflect
from .report import build_canonical_report, render_html_reports, render_reports
from .searchers import search_all
from .synthesis import build_literature_matrix, build_synthesis
from .utils import create_task_dir, write_json
from .verification import build_quality_gate, verify_corpus, verification_to_dict


STAGES = [
    "intake",
    "protocol",
    "search",
    "corpus",
    "screening",
    "verification",
    "synthesis",
    "review",
    "report",
]


def run_v1_workflow(args: argparse.Namespace, client) -> int:
    output_dir, task_id = prepare_output_dir(args)
    state = init_state(task_id, args, output_dir, client)
    write_state(output_dir, state)
    write_json(output_dir / "task.json", task_payload(task_id, args, output_dir))
    print(f"Task ID: {task_id}", flush=True)
    print(f"Output directory: {output_dir.resolve()}", flush=True)

    mark_stage(output_dir, state, "intake", "running")
    print(f"[1/9] Intake and query understanding: {args.keyword}", flush=True)
    understanding = understand_query(args.keyword, client)
    (output_dir / "query_understanding.md").write_text(understanding.to_markdown(), encoding="utf-8")
    if understanding.needs_confirmation and not args.auto_confirm and getattr(args, "interaction", "auto") != "auto":
        answer = input("Keyword is broad or ambiguous. Continue with the recommended query? [y/N] ").strip().lower()
        if answer not in {"y", "yes"}:
            mark_stage(output_dir, state, "intake", "needs_user_attention")
            print("Stopped before search. Review query_understanding.md and rerun with a more specific keyword.")
            return 2
    mark_stage(output_dir, state, "intake", "completed")

    mark_stage(output_dir, state, "protocol", "running")
    print("[2/9] Creating protocol and search plan", flush=True)
    plan = make_plan(understanding, args.max_papers, args.since_year, client, seed_search_terms=getattr(args, "seed_search_terms", None))
    protocol = build_protocol(understanding, plan, args.github_filter, client)
    write_json(output_dir / "plan.json", plan.to_dict())
    write_json(output_dir / "protocol.json", protocol.to_dict())
    mark_stage(output_dir, state, "protocol", "completed")

    mark_stage(output_dir, state, "search", "running")
    print("[3/9] Searching paper sources", flush=True)
    per_query_limit = candidate_limit(args.max_papers, len(plan.search_queries), args.github_filter)
    raw_papers = search_all(plan, per_query_limit=per_query_limit)
    write_json(output_dir / "metadata.json", [paper.to_dict() for paper in raw_papers])
    mark_stage(output_dir, state, "search", "completed", {"raw_count": len(raw_papers)})

    mark_stage(output_dir, state, "corpus", "running")
    print("[4/9] Normalizing, deduplicating, and resolving code links", flush=True)
    resolved = resolve_code_links(raw_papers)
    deduped, dedup_stats = enhanced_deduplicate(resolved)
    rank_papers(deduped, plan.recommended_query, args.since_year)
    github_enrichment = {"checked": 0, "enriched": 0, "skipped_existing_code": 0}
    if args.github_search_limit and args.github_filter in {"required", "any"}:
        print("[4/9] Searching GitHub for missing code links", flush=True)
        github_enrichment = enrich_github_links(deduped, max_checks=args.github_search_limit)
        rank_papers(deduped, plan.recommended_query, args.since_year)
    mark_stage(output_dir, state, "corpus", "completed", {"dedup": dedup_stats, "github_enrichment": github_enrichment})

    mark_stage(output_dir, state, "screening", "running")
    print("[5/9] Screening corpus relevance", flush=True)
    items = corpus_items_from_papers(deduped, plan, protocol, client)
    core_items, adjacent_items, excluded_items = split_corpus(items)
    final_core_items = final_view(core_items, args.github_filter, args.max_papers)
    if not final_core_items and core_items:
        final_core_items = core_items[: args.max_papers]
    write_json(output_dir / "corpus.json", [item.to_dict() for item in items])
    write_json(output_dir / "core_papers.json", [item.to_dict() for item in core_items])
    write_json(output_dir / "adjacent_papers.json", [item.to_dict() for item in adjacent_items])
    write_json(output_dir / "excluded_papers.json", [item.to_dict() for item in excluded_items])
    mark_stage(
        output_dir,
        state,
        "screening",
        "completed",
        {"core": len(core_items), "adjacent": len(adjacent_items), "excluded": len(excluded_items), "final": len(final_core_items)},
    )

    mark_stage(output_dir, state, "verification", "running")
    print("[6/9] Enriching and downloading open PDFs", flush=True)
    final_papers = [item.paper for item in final_core_items]
    enrich_unpaywall(final_papers, args.unpaywall_email)
    if args.no_download:
        download_log = [{"title": paper.title, "status": "skipped", "reason": "--no-download"} for paper in final_papers]
    else:
        download_log = download_pdfs(final_papers, output_dir / "pdfs", limit=args.pdf_limit)
    write_json(output_dir / "download_log.json", download_log)
    paper_notes = extract_downloaded_fulltext(download_log, output_dir)
    attach_fulltext_paths(final_papers, paper_notes)
    write_json(output_dir / "ranked_papers.json", [item.paper.to_dict() for item in final_core_items])
    verification = verify_corpus(items, download_log)
    write_json(output_dir / "verification.json", verification_to_dict(verification))
    mark_stage(output_dir, state, "verification", "completed")

    mark_stage(output_dir, state, "synthesis", "running")
    print("[7/9] Building literature matrix and synthesis", flush=True)
    matrix_items = core_items + (adjacent_items if args.include_adjacent else [])
    literature_matrix = build_literature_matrix(matrix_items)
    synthesis = build_synthesis(core_items, adjacent_items, literature_matrix, plan, protocol, client)
    write_json(output_dir / "literature_matrix.json", literature_matrix)
    write_json(output_dir / "synthesis.json", synthesis)
    mark_stage(output_dir, state, "synthesis", "completed")

    mark_stage(output_dir, state, "review", "running")
    print("[8/9] Running quality gate and reflection", flush=True)
    quality_gate = build_quality_gate(
        items,
        final_core_items,
        verification,
        download_log,
        max_papers=args.max_papers,
        github_filter=args.github_filter,
        quality=args.quality,
        dedup_stats=dedup_stats,
    )
    reflection = reflect(final_papers, plan, download_log, args.github_filter, client)
    reflection.update(
        {
            "verdict": quality_gate.verdict,
            "quality_gate_issues": quality_gate.issues,
            "quality_gate_recommendations": quality_gate.recommendations,
            "before_github_filter_count": len(core_items),
            "after_github_filter_count": len(final_core_items),
            "github_enrichment": github_enrichment,
            "task_id": task_id,
            "retry_performed": False,
        }
    )
    write_json(output_dir / "quality_gate.json", quality_gate.to_dict())
    write_json(output_dir / "reflection.json", reflection)
    mark_stage(output_dir, state, "review", "completed", {"verdict": quality_gate.verdict})

    mark_stage(output_dir, state, "report", "running")
    print("[9/9] Writing canonical, bilingual Markdown, HTML, and PDF reports", flush=True)
    canonical = build_canonical_report(
        understanding,
        plan,
        protocol,
        final_core_items,
        core_items,
        adjacent_items,
        excluded_items,
        literature_matrix,
        synthesis,
        verification,
        quality_gate,
        download_log,
        reflection,
        mode=args.mode,
        include_adjacent=args.include_adjacent,
        client=client,
    )
    write_json(output_dir / "report.canonical.json", canonical)
    zh, en = render_reports(canonical)
    (output_dir / "report.zh.md").write_text(zh, encoding="utf-8")
    (output_dir / "report.en.md").write_text(en, encoding="utf-8")
    zh_html, en_html = render_html_reports(canonical)
    (output_dir / "report.zh.html").write_text(zh_html, encoding="utf-8")
    (output_dir / "report.en.html").write_text(en_html, encoding="utf-8")
    write_pdf_report(zh, output_dir / "report.zh.pdf", title=canonical["title_zh"])
    write_pdf_report(en, output_dir / "report.en.pdf", title=canonical["title"])
    mark_stage(output_dir, state, "report", "completed")
    write_manifest(output_dir, state, client)
    print(f"Done. Output: {output_dir.resolve()}")
    return 0


def prepare_output_dir(args: argparse.Namespace) -> tuple[Path, str]:
    if args.output_dir:
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir, output_dir.name
    task_id, output_dir = create_task_dir(args.keyword)
    return output_dir, task_id


def task_payload(task_id: str, args: argparse.Namespace, output_dir: Path) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "keyword": args.keyword,
        "output_dir": str(output_dir.resolve()),
        "max_papers": args.max_papers,
        "since_year": args.since_year,
        "github_filter": args.github_filter,
        "no_download": args.no_download,
        "github_search_limit": args.github_search_limit,
        "mode": getattr(args, "mode", "apa"),
        "interaction": getattr(args, "interaction", "auto"),
        "quality": getattr(args, "quality", "balanced"),
        "include_adjacent": getattr(args, "include_adjacent", False),
    }


def init_state(task_id: str, args: argparse.Namespace, output_dir: Path, client) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "keyword": args.keyword,
        "output_dir": str(output_dir.resolve()),
        "model": getattr(client, "model", None),
        "stages": {stage: {"status": "pending"} for stage in STAGES},
    }


def mark_stage(output_dir: Path, state: dict[str, Any], stage: str, status: str, extra: dict[str, Any] | None = None) -> None:
    state["updated_at"] = datetime.now().isoformat(timespec="seconds")
    state["stages"].setdefault(stage, {})
    state["stages"][stage].update({"status": status, "updated_at": state["updated_at"]})
    if extra:
        state["stages"][stage].update(extra)
    write_state(output_dir, state)


def write_state(output_dir: Path, state: dict[str, Any]) -> None:
    write_json(output_dir / "state.json", state)


def write_manifest(output_dir: Path, state: dict[str, Any], client) -> None:
    files = sorted(str(path.relative_to(output_dir)) for path in output_dir.rglob("*") if path.is_file())
    manifest = {
        "task_id": state["task_id"],
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "paperpilot_version": "1.0.2",
        "model": getattr(client, "model", None),
        "files": files,
    }
    write_json(output_dir / "manifest.json", manifest)


def final_view(core_items, github_filter: str, max_papers: int):
    papers = apply_github_filter([item.paper for item in core_items], github_filter)
    allowed = {id(paper) for paper in papers}
    return [item for item in core_items if id(item.paper) in allowed][:max_papers]


def candidate_limit(max_papers: int, query_count: int, github_filter: str) -> int:
    query_count = max(1, query_count)
    if github_filter == "required":
        return max(12, min(35, (max_papers * 4) // query_count))
    return max(10, min(30, (max_papers * 3) // query_count))


def inspect_run(path_or_id: str) -> int:
    run_dir = resolve_run_dir(path_or_id)
    if not run_dir:
        print(f"Run not found: {path_or_id}")
        return 1
    print(f"Run: {run_dir.resolve()}")
    for filename in ["state.json", "quality_gate.json", "reflection.json", "manifest.json"]:
        path = run_dir / filename
        if not path.exists():
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        print(f"\n== {filename} ==")
        if filename == "state.json":
            for stage, info in data.get("stages", {}).items():
                print(f"{stage}: {info.get('status')}")
        elif filename == "quality_gate.json":
            print(f"verdict: {data.get('verdict')}")
            print(f"issues: {', '.join(data.get('issues') or []) or 'none'}")
            print(f"metrics: {json.dumps(data.get('metrics') or {}, ensure_ascii=False)[:1200]}")
        elif filename == "reflection.json":
            print(f"verdict: {data.get('verdict')}")
            print(f"issues: {', '.join(data.get('issues') or []) or 'none'}")
        else:
            print(f"files: {len(data.get('files') or [])}")
    return 0


def resolve_run_dir(path_or_id: str) -> Path | None:
    candidate = Path(path_or_id).expanduser()
    if candidate.exists() and candidate.is_dir():
        return candidate
    for base in [Path("runs"), Path.cwd() / "runs"]:
        path = base / path_or_id
        if path.exists() and path.is_dir():
            return path
    return None
