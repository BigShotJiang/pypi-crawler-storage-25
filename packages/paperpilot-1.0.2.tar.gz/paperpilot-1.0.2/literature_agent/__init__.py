"""AI literature search agent."""

__version__ = "1.0.2"
