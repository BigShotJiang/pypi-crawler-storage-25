from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from .context_index import load_repo_context_index, lookup_file_summary
from .device_sources import ensure_devices_registry, format_device_registry_prompt
from .runtime_limits import MemorySnapshot, estimate_tokens
from .skills_registry import available_skill_names as registry_available_skill_names
from .skills_registry import render_skills_manifest
from .skills_registry import skill_summaries, sync_skills_manifest
from .tools.registry import TOOL_MODES, confirmation_required_tool_names, tool_bundle_names_for_mode, tool_names_with_tag


ROLE_BY_MODE = {
    "chat": "chat",
    "code": "coder",
    "review": "reviewer",
    "debug": "debugger",
}

CONFIRMATION_GATED_TOOLS = set(confirmation_required_tool_names())
DEVICE_TOOLS = set(tool_names_with_tag("device"))
READ_DEVICE_TOOLS = DEVICE_TOOLS & set(tool_names_with_tag("read"))
TOOL_BUNDLES = {mode: set(tool_bundle_names_for_mode(mode)) for mode in TOOL_MODES}

TODO_STATUSES = frozenset({"pending", "in_progress", "completed", "blocked"})
TODO_KINDS = frozenset({"inspect", "change", "verify", "review", "report"})


@dataclass
class TodoItem:
    id: str
    content: str
    status: str
    kind: str
    files: list[str] = field(default_factory=list)
    skill: str | None = None
    acceptance: str = ""

    @property
    def title(self) -> str:
        return self.content


@dataclass
class HarnessState:
    goal: str = ""
    mode: str | None = None
    stage: str | None = None
    plan_mode: bool = False
    plan_approved: bool = True
    plan_summary: str = ""
    preferred_skills: list[str] = field(default_factory=list)
    todos: list[TodoItem] = field(default_factory=list)
    active_todo_id: str | None = None
    files_in_play: list[str] = field(default_factory=list)
    last_action: dict[str, Any] = field(default_factory=dict)
    last_verification: dict[str, Any] = field(default_factory=dict)
    verification_required: bool = False
    verification_enabled: bool = True
    verification_skip_reason: str = ""
    verification_status: str = "none"
    verification_blocker: str = ""
    verification_next_command: str = ""
    open_questions: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=lambda: ["local-first", "small focused turns"])
    next_action: str = ""
    failure_count_for_active_step: int = 0
    updated_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["todos"] = [asdict(todo) for todo in self.todos]
        return data

    @classmethod
    def from_dict(cls, payload: dict[str, Any] | None) -> HarnessState:
        if not isinstance(payload, dict):
            return cls()
        todos_payload = payload.get("todos")
        todos: list[TodoItem] = []
        if isinstance(todos_payload, list):
            for item in todos_payload:
                if not isinstance(item, dict):
                    continue
                try:
                    todos.append(
                        TodoItem(
                            id=str(item.get("id", "")),
                            content=str(item.get("content", "")),
                            status=str(item.get("status", "pending")),
                            kind=str(item.get("kind", "inspect")),
                            files=[str(path) for path in item.get("files", []) if str(path)],
                            skill=str(item["skill"]) if item.get("skill") else None,
                            acceptance=str(item.get("acceptance", "")),
                        )
                    )
                except Exception:
                    continue
        elif isinstance(payload.get("plan"), list):
            for item in payload.get("plan", []):
                if not isinstance(item, dict):
                    continue
                try:
                    step_status = str(item.get("status", "pending"))
                    todos.append(
                        TodoItem(
                            id=str(item.get("id", "")),
                            content=str(item.get("title", "")),
                            status="completed" if step_status == "done" else "in_progress" if step_status == "active" else "pending",
                            kind=str(item.get("kind", "inspect")),
                            files=[str(path) for path in item.get("files", []) if str(path)],
                            skill=str(item["skill"]) if item.get("skill") else None,
                            acceptance=str(item.get("acceptance", "")),
                        )
                    )
                except Exception:
                    continue
        return cls(
            goal=str(payload.get("goal", "")),
            mode=str(payload["mode"]) if payload.get("mode") else None,
            stage=str(payload["stage"]) if payload.get("stage") else None,
            plan_mode=bool(payload.get("plan_mode", False)),
            plan_approved=bool(payload.get("plan_approved", True)),
            plan_summary=str(payload.get("plan_summary", "")),
            preferred_skills=[str(item) for item in payload.get("preferred_skills", []) if str(item)],
            todos=todos,
            active_todo_id=str(payload["active_todo_id"]) if payload.get("active_todo_id") else None,
            files_in_play=[str(path) for path in payload.get("files_in_play", []) if str(path)],
            last_action=dict(payload.get("last_action", {})) if isinstance(payload.get("last_action"), dict) else {},
            last_verification=dict(payload.get("last_verification", {})) if isinstance(payload.get("last_verification"), dict) else {},
            verification_required=bool(payload.get("verification_required", False)),
            verification_enabled=bool(payload.get("verification_enabled", True)),
            verification_skip_reason=str(payload.get("verification_skip_reason", "")),
            verification_status=str(payload.get("verification_status", "none")),
            verification_blocker=str(payload.get("verification_blocker", "")),
            verification_next_command=str(payload.get("verification_next_command", "")),
            open_questions=[str(item) for item in payload.get("open_questions", []) if str(item)],
            constraints=[str(item) for item in payload.get("constraints", []) if str(item)] or ["local-first", "small focused turns"],
            next_action=str(payload.get("next_action", "")),
            failure_count_for_active_step=int(payload.get("failure_count_for_active_step", 0) or 0),
            updated_at=float(payload.get("updated_at", 0.0) or 0.0),
        )


@dataclass(frozen=True)
class TurnBudget:
    effective_window: int
    generation_reserve: int
    tool_reserve: int
    system_reserve: int
    base_prompt_budget: int
    ram_factor: float
    usable_prompt_budget: int
    current_context_tokens: int
    remaining_budget: int
    docs_budget: int
    layer1_budget: int
    layer2_budget: int
    layer3_budget: int
    layer_alert_tokens: int


@dataclass(frozen=True)
class LayeredContextConfig:
    enabled: bool
    layer1_enabled: bool
    layer2_enabled: bool
    layer3_enabled: bool
    layer1_ratio: float
    layer2_ratio: float
    layer3_ratio: float
    alert_ratio: float


@dataclass(frozen=True)
class HarnessContext:
    messages: list[dict[str, str]]
    state_summary: str
    state_summary_tokens: int
    docs_loaded: list[str]
    docs_tokens: int
    budget: TurnBudget
    layer_tokens: dict[str, int]
    layer_docs: dict[str, list[str]]
    budget_alerts: list[str]
    candidate_decisions: list[dict[str, Any]]


@dataclass(frozen=True)
class HarnessPolicy:
    tier: str
    max_skill_docs: int
    include_stage_doc: bool
    include_framework_doc: bool
    compact_state_rendering: bool


@dataclass(frozen=True)
class HarnessDocCandidate:
    layer: str
    label: str
    body: str
    token_count: int


@dataclass(frozen=True)
class HarnessDocDecision:
    layer: str
    label: str
    token_count: int
    admitted: bool
    skipped_reason: str | None = None


class HarnessSessionStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (Path.cwd() / ".openjet" / "state" / "session.json")

    def load(self) -> HarnessState:
        if not self.path.exists():
            return HarnessState()
        try:
            return HarnessState.from_dict(json.loads(self.path.read_text(encoding="utf-8")))
        except Exception:
            return HarnessState()

    def save(self, state: HarnessState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(state.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)


def _merge_files(existing: Sequence[str], incoming: Sequence[str]) -> list[str]:
    merged: list[str] = []
    seen: set[str] = set()
    for raw in [*existing, *incoming]:
        path = str(raw).strip()
        if not path or path in seen:
            continue
        seen.add(path)
        merged.append(path)
    return merged


def _clone_todos(todos: Sequence[TodoItem]) -> list[TodoItem]:
    return [
        TodoItem(
            id=todo.id,
            content=todo.content,
            status=todo.status,
            kind=todo.kind,
            files=list(todo.files),
            skill=todo.skill,
            acceptance=todo.acceptance,
        )
        for todo in todos
    ]


def update_state_for_user_message(
    state: HarnessState,
    text: str,
    *,
    mode: str | None = None,
    files: list[str] | None = None,
) -> HarnessState:
    chosen_mode = mode or state.mode
    mentioned_files = [path for path in (files or []) if path]
    preserve_plan_mode = bool(state.plan_mode and not state.plan_approved)
    current_active = active_todo(state)
    is_follow_up = (
        not preserve_plan_mode
        and current_active is not None
        and text.strip().lower() in {"continue", "keep going", "carry on", "resume"}
        and (not mentioned_files or set(mentioned_files) <= set(state.files_in_play))
    )
    next_state = HarnessState.from_dict(state.to_dict())
    if preserve_plan_mode or is_follow_up:
        next_state.goal = next_state.goal or text.strip()
    else:
        next_state.goal = text.strip()
    next_state.mode = chosen_mode
    next_state.stage = None
    next_state.plan_mode = preserve_plan_mode
    next_state.plan_approved = False if preserve_plan_mode else True
    next_state.plan_summary = next_state.plan_summary if preserve_plan_mode or is_follow_up else ""
    next_state.preferred_skills = next_state.preferred_skills[:]
    next_state.files_in_play = _merge_files(next_state.files_in_play, mentioned_files) if preserve_plan_mode or is_follow_up else mentioned_files
    if preserve_plan_mode or is_follow_up:
        next_state.todos = _clone_todos(next_state.todos)
        next_state.active_todo_id = active_todo(next_state).id if active_todo(next_state) else None
        next_state.next_action = active_todo(next_state).title if active_todo(next_state) else "Await the next user instruction."
    else:
        next_state.todos = []
        next_state.active_todo_id = None
        next_state.last_action = {}
        next_state.last_verification = {}
        next_state.verification_required = False
        next_state.verification_skip_reason = ""
        next_state.verification_status = "none"
        next_state.verification_blocker = ""
        next_state.verification_next_command = ""
        next_state.next_action = ""
        next_state.failure_count_for_active_step = 0
        if chosen_mode in {"code", "debug", "review"} and mentioned_files:
            next_state.todos = [
                TodoItem(
                    id="inspect",
                    content=f"Inspect {', '.join(mentioned_files)}",
                    status="in_progress",
                    kind="inspect",
                    files=list(mentioned_files),
                )
            ]
            next_state.active_todo_id = "inspect"
            next_state.next_action = next_state.todos[0].title
    next_state.stage = infer_stage(next_state)
    next_state.updated_at = time.time()
    return next_state


def compute_turn_budget(
    *,
    effective_window: int,
    current_context_tokens: int,
    memory_snapshot: MemorySnapshot | None,
    layered_config: LayeredContextConfig | None = None,
) -> TurnBudget:
    config = layered_config or layered_context_config(None)
    generation_reserve = max(512, int(effective_window * 0.18))
    tool_reserve = max(128, int(effective_window * 0.04))
    system_reserve = 300 if effective_window <= 8192 else 500
    base_prompt_budget = max(512, effective_window - generation_reserve - tool_reserve - system_reserve)
    mem_available_mb = memory_snapshot.available_mb if memory_snapshot else None
    if mem_available_mb is None:
        ram_factor = 1.0
    elif mem_available_mb < 700:
        ram_factor = 0.35
    elif mem_available_mb < 1000:
        ram_factor = 0.50
    elif mem_available_mb < 1500:
        ram_factor = 0.65
    elif mem_available_mb < 2500:
        ram_factor = 0.80
    else:
        ram_factor = 1.00
    usable_prompt_budget = max(512, int(base_prompt_budget * ram_factor))
    remaining_budget = usable_prompt_budget - max(0, current_context_tokens)
    docs_budget = max(192, min(int(usable_prompt_budget * 0.28), max(192, remaining_budget // 2 if remaining_budget > 0 else 192)))
    layer1_budget = max(0, min(docs_budget, int(effective_window * config.layer1_ratio))) if config.layer1_enabled else 0
    layer2_budget = max(0, min(docs_budget, int(effective_window * config.layer2_ratio))) if config.layer2_enabled else 0
    layer3_budget = max(0, min(docs_budget, int(effective_window * config.layer3_ratio))) if config.layer3_enabled else 0
    layer_alert_tokens = max(96, int(effective_window * config.alert_ratio))
    return TurnBudget(
        effective_window=effective_window,
        generation_reserve=generation_reserve,
        tool_reserve=tool_reserve,
        system_reserve=system_reserve,
        base_prompt_budget=base_prompt_budget,
        ram_factor=ram_factor,
        usable_prompt_budget=usable_prompt_budget,
        current_context_tokens=current_context_tokens,
        remaining_budget=remaining_budget,
        docs_budget=docs_budget,
        layer1_budget=layer1_budget,
        layer2_budget=layer2_budget,
        layer3_budget=layer3_budget,
        layer_alert_tokens=layer_alert_tokens,
    )


def build_turn_context(
    *,
    root: Path,
    state: HarnessState,
    current_context_tokens: int,
    effective_window: int,
    memory_snapshot: MemorySnapshot | None,
    layered_config: dict[str, Any] | None = None,
    cfg: Mapping[str, object] | None = None,
    referenced_device_ids: Sequence[str] | None = None,
    device_registry_path: str | Path | None = None,
    extra_system_messages: Sequence[dict[str, str]] | None = None,
    extra_docs_loaded: Sequence[str] | None = None,
) -> HarnessContext:
    config = layered_context_config(layered_config)
    budget = compute_turn_budget(
        effective_window=effective_window,
        current_context_tokens=current_context_tokens,
        memory_snapshot=memory_snapshot,
        layered_config=config,
    )
    messages: list[dict[str, str]] = []
    docs_loaded: list[str] = []
    docs_tokens = 0
    layer_tokens = {"layer1": 0, "layer2": 0, "layer3": 0}
    layer_docs = {"layer1": [], "layer2": [], "layer3": []}
    budget_alerts: list[str] = []
    candidate_decisions: list[dict[str, Any]] = []

    state_summary = build_state_summary(state, budget)
    policy = select_harness_policy(state=state, budget=budget)
    state_summary_tokens = estimate_tokens(state_summary)
    messages.append({"role": "system", "content": state_summary})

    remaining = max(0, budget.docs_budget - state_summary_tokens)
    if remaining <= 0:
        for candidate in _candidate_docs(root, state, effective_window, policy=policy):
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=candidate.layer,
                        label=candidate.label,
                        token_count=candidate.token_count,
                        admitted=False,
                        skipped_reason="exceeds_remaining_global_budget",
                    )
                )
            )
        return HarnessContext(
            messages=messages,
            state_summary=state_summary,
            state_summary_tokens=state_summary_tokens,
            docs_loaded=docs_loaded,
            docs_tokens=state_summary_tokens,
            budget=budget,
            layer_tokens=layer_tokens,
            layer_docs=layer_docs,
            budget_alerts=budget_alerts,
            candidate_decisions=candidate_decisions,
        )

    per_layer_remaining = {
        "layer1": min(remaining, budget.layer1_budget),
        "layer2": min(remaining, budget.layer2_budget),
        "layer3": min(remaining, budget.layer3_budget),
    }
    stop_after_global_floor = False

    candidates = _candidate_docs(root, state, effective_window, policy=policy)
    admission_candidates = list(candidates)
    if policy.compact_state_rendering:
        admission_candidates.sort(key=lambda candidate: 0 if candidate.label.startswith("[stage:") else 1)
    if state.last_verification or state.verification_required:
        admission_candidates.sort(
            key=lambda candidate: (
                0 if candidate.label.startswith("[stage:") else 1 if candidate.label == "recent-context" else 2
            )
        )

    for candidate in admission_candidates:
        if not candidate.body.strip():
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=candidate.layer,
                        label=candidate.label,
                        token_count=candidate.token_count,
                        admitted=False,
                        skipped_reason="empty_body",
                    )
                )
            )
            continue
        if stop_after_global_floor:
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=candidate.layer,
                        label=candidate.label,
                        token_count=candidate.token_count,
                        admitted=False,
                        skipped_reason="remaining_global_floor_reached",
                    )
                )
            )
            continue
        layer_name = candidate.layer
        if not _layer_enabled(config, layer_name):
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=layer_name,
                        label=candidate.label,
                        token_count=candidate.token_count,
                        admitted=False,
                        skipped_reason="disabled_layer",
                    )
                )
            )
            continue
        doc_tokens = candidate.token_count
        if doc_tokens > remaining:
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=layer_name,
                        label=candidate.label,
                        token_count=doc_tokens,
                        admitted=False,
                        skipped_reason="exceeds_remaining_global_budget",
                    )
                )
            )
            continue
        if doc_tokens > per_layer_remaining.get(layer_name, remaining):
            candidate_decisions.append(
                asdict(
                    HarnessDocDecision(
                        layer=layer_name,
                        label=candidate.label,
                        token_count=doc_tokens,
                        admitted=False,
                        skipped_reason="exceeds_remaining_per_layer_budget",
                    )
                )
            )
            continue
        messages.append({"role": "system", "content": candidate.body})
        docs_loaded.append(candidate.label)
        docs_tokens += doc_tokens
        layer_tokens[layer_name] = layer_tokens.get(layer_name, 0) + doc_tokens
        layer_docs.setdefault(layer_name, []).append(candidate.label)
        candidate_decisions.append(
            asdict(
                HarnessDocDecision(
                    layer=layer_name,
                    label=candidate.label,
                    token_count=doc_tokens,
                    admitted=True,
                )
            )
        )
        remaining -= doc_tokens
        per_layer_remaining[layer_name] = max(0, per_layer_remaining.get(layer_name, 0) - doc_tokens)
        if remaining < 128:
            stop_after_global_floor = True

    for layer_name, used in layer_tokens.items():
        if used > budget.layer_alert_tokens:
            budget_alerts.append(
                f"{layer_name} exceeded 40% of the context window: used={used} threshold={budget.layer_alert_tokens}"
            )

    referenced_ids = _normalize_context_device_refs(referenced_device_ids)
    if referenced_ids:
        registry_path = (
            Path(device_registry_path).expanduser().resolve()
            if device_registry_path is not None
            else ensure_devices_registry(root, cfg=cfg)
        )
        if registry_path is not None:
            registry_prompt = format_device_registry_prompt(
                registry_path,
                referenced_ids=referenced_ids,
            )
            messages.append({"role": "system", "content": registry_prompt})
            docs_tokens += estimate_tokens(registry_prompt)

    for message in extra_system_messages or ():
        if not isinstance(message, dict):
            continue
        if str(message.get("role", "")).strip().lower() != "system":
            continue
        content = str(message.get("content", "")).strip()
        if not content:
            continue
        messages.append({"role": "system", "content": content})
        docs_tokens += estimate_tokens(content)

    for label in extra_docs_loaded or ():
        text = str(label).strip()
        if text:
            docs_loaded.append(text)

    docs_tokens += state_summary_tokens
    return HarnessContext(
        messages=messages,
        state_summary=state_summary,
        state_summary_tokens=state_summary_tokens,
        docs_loaded=docs_loaded,
        docs_tokens=docs_tokens,
        budget=budget,
        layer_tokens=layer_tokens,
        layer_docs=layer_docs,
        budget_alerts=budget_alerts,
        candidate_decisions=candidate_decisions,
    )


def _normalize_context_device_refs(referenced_device_ids: Sequence[str] | None) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for raw in referenced_device_ids or ():
        text = str(raw).strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(text)
    return normalized


def build_state_summary(state: HarnessState, budget: TurnBudget | None = None) -> str:
    active = active_step(state)
    current_todo = active_todo(state)
    completed = [todo.content for todo in state.todos if todo.status == "completed"]
    stage = infer_stage(state)
    lines = [
        "OPEN-JET HARNESS STATE",
        f"MODE: {state.mode}",
        f"STAGE: {stage}",
        f"PLAN_MODE: {'on' if state.plan_mode else 'off'}",
        f"PLAN_APPROVED: {'yes' if state.plan_approved else 'no'}",
        f"GOAL: {state.goal or 'n/a'}",
        f"ACTIVE_TODO: {current_todo.content if current_todo else 'n/a'}",
        f"FILES_IN_PLAY: {', '.join(state.files_in_play) if state.files_in_play else 'n/a'}",
        f"COMPLETED_TODOS: {', '.join(completed) if completed else 'none'}",
        f"LAST_ACTION: {_compact_json(state.last_action) if state.last_action else 'n/a'}",
        f"LAST_VERIFICATION: {_compact_json(state.last_verification) if state.last_verification else 'n/a'}",
        f"VERIFICATION_REQUIRED: {'yes' if state.verification_required else 'no'}",
        f"VERIFICATION_STATUS: {state.verification_status}",
        f"NEXT_ACTION: {state.next_action or (active.title if active else 'n/a')}",
        f"OPEN_QUESTIONS: {', '.join(state.open_questions) if state.open_questions else 'none'}",
    ]
    if state.plan_summary:
        lines.append(f"PLAN_SUMMARY: {state.plan_summary}")
    if state.verification_skip_reason:
        lines.append(f"VERIFICATION_SKIP_REASON: {state.verification_skip_reason}")
    if state.verification_blocker:
        lines.append(f"VERIFICATION_BLOCKER: {state.verification_blocker}")
    if state.verification_next_command:
        lines.append(f"VERIFICATION_NEXT_COMMAND: {state.verification_next_command}")
    if budget is not None:
        lines.append(
            "PROMPT_BUDGET: "
            f"usable={budget.usable_prompt_budget} "
            f"remaining={max(0, budget.remaining_budget)} "
            f"docs={budget.docs_budget} "
            f"layer1={budget.layer1_budget} "
            f"layer2={budget.layer2_budget} "
            f"layer3={budget.layer3_budget}"
        )
    lines.append("Work on the active todo only. Keep the change narrow and move to verification when the edit is done.")
    if state.verification_required:
        lines.append("A code edit has not been verified yet. The next action must be verification or an explicit verification skip.")
    return "\n".join(lines)


def update_state_after_turn(
    state: HarnessState,
    *,
    tool_events: list[dict[str, Any]],
    assistant_text: str,
) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.stage = None
    read_ops = {"read_file", "load_file", "glob", "grep", "list_directory"}
    write_ops = {"write_file", "edit_file"}
    saw_read = any(event.get("tool") in read_ops and event.get("ok", True) for event in tool_events)
    saw_write = any(event.get("tool") in write_ops and event.get("ok", True) for event in tool_events)
    verification = next((event for event in tool_events if event.get("verification")), None)

    if tool_events:
        last = tool_events[-1]
        next_state.last_action = {
            "type": last.get("tool"),
            "target": last.get("target"),
            "summary": last.get("summary"),
        }

    if verification:
        next_state = record_verification_result(
            next_state,
            ok=bool(verification.get("ok")),
            summary=str(verification.get("summary", "")),
            command=str(verification.get("command", "")) or None,
        )

    active_before_progress = active_todo(next_state)
    if saw_read and active_before_progress is not None and active_before_progress.kind == "inspect":
        next_state = complete_todo(next_state, active_before_progress.id)

    active_before_write = active_todo(next_state)
    if saw_write and active_before_write is not None and active_before_write.kind in {"change", "fix"}:
        next_state = complete_todo(next_state, active_before_write.id)

    if saw_write and next_state.verification_enabled:
        next_state = mark_verification_pending(next_state)

    todo = active_todo(next_state)
    if todo is not None:
        if verification and not verification.get("ok"):
            next_state.failure_count_for_active_step += 1

    if verification and verification.get("ok"):
        next_state.verification_required = False
        active_after_verification = active_todo(next_state)
        if active_after_verification is not None and active_after_verification.kind == "verify":
            next_state = complete_todo(next_state, active_after_verification.id)

    active = active_todo(next_state)
    next_state.stage = infer_stage(next_state)
    next_state.next_action = active.title if active else "Await the next user instruction."
    next_state.updated_at = time.time()
    return next_state


def available_skill_names(root: Path) -> list[str]:
    return registry_available_skill_names(root)


def set_mode(state: HarnessState, mode: str) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.mode = mode
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def enter_plan_mode(state: HarnessState) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.plan_mode = True
    next_state.plan_approved = False
    next_state.stage = "plan"
    next_state.updated_at = time.time()
    return next_state


def exit_plan_mode(
    state: HarnessState,
    *,
    plan_summary: str,
    approved: bool = False,
) -> HarnessState:
    summary = str(plan_summary).strip()
    if not summary:
        raise ValueError("plan_summary is required")
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.plan_summary = summary
    next_state.plan_mode = not approved
    next_state.plan_approved = bool(approved)
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def set_plan_approved(state: HarnessState, approved: bool) -> HarnessState:
    if approved and not str(state.plan_summary).strip():
        raise ValueError("cannot approve plan mode without a recorded plan summary")
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.plan_approved = bool(approved)
    next_state.plan_mode = not bool(approved)
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def set_preferred_skills(state: HarnessState, skill_names: list[str]) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    normalized: list[str] = []
    seen: set[str] = set()
    for name in skill_names:
        key = normalize_skill_name(name)
        if not key or key in seen:
            continue
        seen.add(key)
        normalized.append(key)
    next_state.preferred_skills = normalized
    next_state.updated_at = time.time()
    return next_state


def clear_preferred_skills(state: HarnessState) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.preferred_skills = []
    next_state.updated_at = time.time()
    return next_state


def active_todo(state: HarnessState) -> TodoItem | None:
    if state.active_todo_id:
        for todo in state.todos:
            if todo.id == state.active_todo_id:
                return todo
    for todo in state.todos:
        if todo.status == "in_progress":
            return todo
    return None


def upsert_todos(state: HarnessState, todos_payload: Sequence[Mapping[str, Any]]) -> HarnessState:
    todos: list[TodoItem] = []
    in_progress_ids: list[str] = []
    seen_ids: set[str] = set()
    for item in todos_payload:
        todo_id = str(item.get("id", "")).strip()
        content = str(item.get("content", "")).strip()
        status = str(item.get("status", "pending")).strip()
        kind = str(item.get("kind", "inspect")).strip()
        if not todo_id or not content:
            raise ValueError("todo items require id and content")
        if todo_id in seen_ids:
            raise ValueError(f"duplicate todo id: {todo_id}")
        seen_ids.add(todo_id)
        if status not in TODO_STATUSES:
            raise ValueError(f"invalid todo status: {status}")
        if kind not in TODO_KINDS:
            raise ValueError(f"invalid todo kind: {kind}")
        todo = TodoItem(
            id=todo_id,
            content=content,
            status=status,
            kind=kind,
            files=[str(path) for path in item.get("files", []) if str(path)],
            skill=str(item["skill"]) if item.get("skill") else None,
            acceptance=str(item.get("acceptance", "")),
        )
        todos.append(todo)
        if status == "in_progress":
            in_progress_ids.append(todo_id)
    if len(in_progress_ids) > 1:
        raise ValueError("only one todo may be in_progress")
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.todos = todos
    next_state.active_todo_id = in_progress_ids[0] if in_progress_ids else None
    next_state.next_action = active_todo(next_state).title if active_todo(next_state) else "Await the next user instruction."
    next_state.updated_at = time.time()
    return next_state


def clear_todos(state: HarnessState) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.todos = []
    next_state.active_todo_id = None
    next_state.updated_at = time.time()
    return next_state


def complete_todo(state: HarnessState, todo_id: str) -> HarnessState:
    needle = str(todo_id).strip()
    if not needle:
        raise ValueError("todo id is required")
    next_state = HarnessState.from_dict(state.to_dict())
    found = False
    activate_next = False
    target_was_active = False
    for todo in next_state.todos:
        if todo.id == needle:
            found = True
            target_was_active = todo.status == "in_progress" or next_state.active_todo_id == needle
            todo.status = "completed"
            activate_next = target_was_active
            continue
        if activate_next and todo.status == "pending":
            todo.status = "in_progress"
            next_state.active_todo_id = todo.id
            activate_next = False
            break
    if not found:
        raise ValueError(f"todo not found: {needle}")
    if target_was_active and activate_next:
        next_state.active_todo_id = None
    next_state.next_action = active_todo(next_state).title if active_todo(next_state) else "Await the next user instruction."
    next_state.updated_at = time.time()
    return next_state


def record_verification_result(
    state: HarnessState,
    *,
    ok: bool,
    summary: str,
    command: str | None,
) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.last_verification = {
        "status": "pass" if ok else "fail",
        "summary": str(summary).strip(),
        "command": str(command or "").strip() or None,
    }
    next_state.verification_required = not ok
    next_state.verification_status = "passed" if ok else "failed"
    next_state.verification_skip_reason = ""
    next_state.verification_blocker = ""
    next_state.verification_next_command = str(command or "").strip()
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def mark_verification_pending(state: HarnessState) -> HarnessState:
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.verification_required = bool(next_state.verification_enabled)
    next_state.verification_skip_reason = ""
    next_state.verification_status = "pending" if next_state.verification_enabled else "none"
    next_state.verification_blocker = ""
    next_state.verification_next_command = ""
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def record_verification_skip(
    state: HarnessState,
    *,
    reason: str,
    next_command: str,
) -> HarnessState:
    reason_text = str(reason).strip()
    next_command_text = str(next_command).strip()
    if not reason_text:
        raise ValueError("verification skip reason is required")
    if not next_command_text:
        raise ValueError("verification next_command is required")
    next_state = HarnessState.from_dict(state.to_dict())
    next_state.verification_required = False
    next_state.verification_status = "skipped"
    next_state.verification_skip_reason = reason_text
    next_state.verification_blocker = reason_text
    next_state.verification_next_command = next_command_text
    next_state.stage = None
    next_state.updated_at = time.time()
    return next_state


def verification_gate_message(state: HarnessState) -> str | None:
    if not getattr(state, "verification_enabled", True) or not getattr(state, "verification_required", False):
        return None
    command = str(state.verification_next_command or "").strip()
    suffix = f" Run or propose `{command}` if it is still valid." if command else ""
    return (
        "A code edit has not been verified yet. "
        "Do not finish the task until you run focused verification or explicitly skip it with a reason and next command."
        f"{suffix}"
    )


def pre_edit_gate_message(state: HarnessState, *, tool_name: str) -> str | None:
    if tool_name not in {"edit_file", "write_file"}:
        return None
    if getattr(state, "plan_mode", False) and not getattr(state, "plan_approved", True):
        return "Plan mode is active. Stay read-only until the plan is approved."
    active = active_todo(state)
    if active is None:
        if str(state.last_action.get("type", "")).strip() in {"read_file", "load_file", "glob", "grep", "list_directory"}:
            return None
        return "No in-progress todo is active. Create or activate an in-progress todo before editing."
    if active.kind == "inspect":
        return "Inspect the target area before editing. Use read/search tools first, then retry the edit."
    return None


def quality_gate_messages(state: HarnessState) -> list[dict[str, str]]:
    messages: list[dict[str, str]] = []
    verification_message = verification_gate_message(state)
    if verification_message:
        messages.append(
            {
                "role": "system",
                "content": "QUALITY GATE\n" + verification_message,
            }
        )
    if getattr(state, "plan_mode", False) and not getattr(state, "plan_approved", True):
        messages.append(
            {
                "role": "system",
                "content": (
                    "PLAN MODE\n"
                    "Read and inspect only. Do not request edit or write tools until the plan is approved."
                ),
            }
        )
    return messages


def quality_gate_doc_labels(state: HarnessState) -> list[str]:
    labels: list[str] = []
    if verification_gate_message(state):
        labels.append("[quality-gate]")
    if getattr(state, "plan_mode", False) and not getattr(state, "plan_approved", True):
        labels.append("[plan-gate]")
    return labels


def normalize_skill_name(name: str) -> str:
    return Path(str(name).strip()).stem


def allowed_tools_for_mode(mode: str | None) -> set[str]:
    allowed = set(CONFIRMATION_GATED_TOOLS)
    if mode:
        return allowed | set(TOOL_BUNDLES.get(str(mode).strip().lower(), set()))
    for bundle in TOOL_BUNDLES.values():
        allowed |= set(bundle)
    return allowed


def allowed_tools_for_state(state: HarnessState | None) -> set[str]:
    if state is None:
        return allowed_tools_for_mode(None)
    allowed = allowed_tools_for_mode(state.mode)
    if (state.plan_mode or infer_stage(state) == "plan") and not state.plan_approved:
        return {
            name
            for name in allowed
            if name in {"read_file", "load_file", "glob", "grep", "list_directory", "system_info", "todo_write", "exit_plan_mode", *READ_DEVICE_TOOLS}
        }
    return allowed


def shell_command_is_verification(command: str) -> bool:
    lowered = command.lower()
    return any(token in lowered for token in ("pytest", "unittest", "py_compile", "ruff", "mypy", "cargo test", "go test", "npm test"))


def max_skill_docs_for_window(window_tokens: int) -> int:
    if window_tokens <= 4096:
        return 1
    if window_tokens <= 8192:
        return 1
    if window_tokens <= 16384:
        return 2
    return 3


def select_harness_policy(*, state: HarnessState, budget: TurnBudget) -> HarnessPolicy:
    usable = max(0, int(budget.remaining_budget))
    if usable < 700:
        return HarnessPolicy(
            tier="minimal",
            max_skill_docs=0,
            include_stage_doc=False,
            include_framework_doc=False,
            compact_state_rendering=True,
        )
    if usable < 1800:
        return HarnessPolicy(
            tier="compact",
            max_skill_docs=1,
            include_stage_doc=True,
            include_framework_doc=False,
            compact_state_rendering=False,
        )
    return HarnessPolicy(
        tier="rich",
        max_skill_docs=max_skill_docs_for_window(budget.effective_window),
        include_stage_doc=True,
        include_framework_doc=True,
        compact_state_rendering=False,
    )


def active_step(state: HarnessState) -> TodoItem | None:
    return active_todo(state)


def infer_stage(state: HarnessState) -> str:
    explicit = str(state.stage or "").strip().lower()
    if explicit:
        return explicit
    if state.plan_mode and not state.plan_approved:
        return "plan"
    if state.verification_required:
        return "verify"
    active = active_step(state)
    if active is None:
        if state.files_in_play:
            return "implement"
        return "implement" if state.mode in {"code", "debug"} else str(state.mode or "chat")
    if active.kind == "inspect":
        return "review" if state.mode == "review" else "implement"
    if active.kind in {"change", "fix"}:
        return "implement"
    if active.kind == "verify":
        return "verify"
    if active.kind in {"review", "report"}:
        return "review"
    return str(state.mode or "chat")


def _candidate_docs(
    root: Path,
    state: HarnessState,
    window_tokens: int,
    *,
    policy: HarnessPolicy | None = None,
) -> list[HarnessDocCandidate]:
    candidates: list[tuple[str, str, str]] = []
    resolved_policy = policy or HarnessPolicy(
        tier="rich",
        max_skill_docs=max_skill_docs_for_window(window_tokens),
        include_stage_doc=True,
        include_framework_doc=True,
        compact_state_rendering=False,
    )
    repo_index = load_repo_context_index(root)
    if repo_index.project_summary:
        candidates.append(("layer1", "[project summary]", repo_index.project_summary))
    base_doc = _load_doc(root / ".openjet" / "agents" / "base.md")
    if base_doc:
        candidates.append(("layer1", ".openjet/agents/base.md", base_doc))
    skills_index = render_skills_manifest(root)
    if skills_index:
        candidates.append(("layer1", "skills.md", skills_index))
    role_name = ROLE_BY_MODE.get(state.mode) if state.mode else None
    role_doc = _load_doc(root / ".openjet" / "agents" / f"{role_name}.md") if role_name else ""
    if role_name and role_doc:
        candidates.append(("layer2", f".openjet/agents/{role_name}.md", role_doc))
    stage_doc = _stage_doc_candidate(root, state, resolved_policy)
    if stage_doc is not None:
        candidates.append(stage_doc)
    project_doc = _load_doc(root / ".openjet" / "projects" / "default.md")
    if project_doc:
        candidates.append(("layer1", ".openjet/projects/default.md", project_doc))
    framework_doc = _framework_doc_candidate(root, state, resolved_policy)
    if framework_doc is not None:
        candidates.append(framework_doc)

    for file_summary in _file_context_docs(repo_index, state):
        candidates.append(("layer2", file_summary[0], file_summary[1]))

    selected_skills = _select_skills(root, state, window_tokens, policy=resolved_policy)
    candidates.extend(selected_skills)
    candidates.extend(_recent_context_docs(state))

    formatted: list[HarnessDocCandidate] = []
    for layer_name, label, body in candidates:
        rendered = _format_doc(label, body) if body.strip() else ""
        formatted.append(
            HarnessDocCandidate(
                layer=layer_name,
                label=label,
                body=rendered,
                token_count=estimate_tokens(rendered),
            )
        )
    return formatted


def _select_skills(
    root: Path,
    state: HarnessState,
    window_tokens: int,
    *,
    policy: HarnessPolicy | None = None,
) -> list[tuple[str, str, str]]:
    query = " ".join(
        part
        for part in [
            state.goal,
            active_step(state).title if active_step(state) else "",
            " ".join(state.files_in_play),
        ]
        if part
    ).lower()
    query_terms = set(re.findall(r"[a-z0-9_+-]+", query))
    scored: list[tuple[int, str, str]] = []
    preferred = {normalize_skill_name(name) for name in state.preferred_skills}
    for summary in skill_summaries(root):
        body = _load_doc(summary.path)
        metadata, content = _split_frontmatter(body)
        score = 0
        name_terms = set(re.findall(r"[a-z0-9_+-]+", summary.name.lower()))
        tags = {str(tag).lower() for tag in metadata.get("tags", [])} if isinstance(metadata.get("tags"), list) else set()
        score += len(query_terms & name_terms) * 4
        score += len(query_terms & tags) * 5
        if state.mode and metadata.get("mode") == state.mode:
            score += 3
        if summary.name in preferred:
            score += 100
        if score <= 0:
            continue
        scored.append((score, summary.path.name, content.strip()))
    scored.sort(key=lambda item: (-item[0], item[1]))
    resolved_policy = policy or HarnessPolicy(
        tier="rich",
        max_skill_docs=max_skill_docs_for_window(window_tokens),
        include_stage_doc=True,
        include_framework_doc=True,
        compact_state_rendering=False,
    )
    limit = min(max_skill_docs_for_window(window_tokens), resolved_policy.max_skill_docs)
    active = active_step(state)
    if active and active.skill:
        limit = max(limit, 1)
    return [("layer2", f"skills/{name}", body) for _, name, body in scored[:limit]]


def _file_context_docs(index: Any, state: HarnessState) -> list[tuple[str, str]]:
    docs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for raw_path in state.files_in_play:
        normalized = str(raw_path).strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        summary = lookup_file_summary(index, normalized)
        if summary is None:
            continue
        lines = [
            f"FILE CONTEXT: {summary.path}",
            f"Purpose: {summary.purpose}",
        ]
        if summary.related_tests:
            lines.append(f"Related tests: {', '.join(summary.related_tests)}")
        docs.append((f"file-context:{summary.path}", "\n".join(lines)))
    return docs


def _recent_context_docs(state: HarnessState) -> list[tuple[str, str, str]]:
    if not state.last_action and not state.last_verification and not state.verification_required:
        return []
    lines = ["RECENT TASK CONTEXT"]
    if state.last_action:
        lines.append(f"Last action: {_compact_json(state.last_action)}")
    if state.last_verification:
        lines.append(f"Last verification: {_compact_json(state.last_verification)}")
    if state.verification_required:
        lines.append("Verification is required before the task can be considered complete.")
    todo = active_todo(state)
    if todo is not None:
        lines.append(f"Active todo: {todo.content} ({todo.kind})")
    if state.files_in_play:
        lines.append(f"Files in play: {', '.join(state.files_in_play[:4])}")
    if len(lines) == 1:
        return []
    return [("layer3", "recent-context", "\n".join(lines))]


def _stage_doc_candidate(
    root: Path,
    state: HarnessState,
    policy: HarnessPolicy,
) -> tuple[str, str, str] | None:
    stage = infer_stage(state)
    if policy.include_stage_doc:
        path = root / ".openjet" / "stages" / f"{stage}.md"
        body = _load_doc(path)
        if body:
            return ("layer2", f".openjet/stages/{stage}.md", body)
    if policy.compact_state_rendering:
        return (
            "layer2",
            f"[stage:{stage}]",
            f"CURRENT STAGE\nStage: {stage}\nFocus only on the active {stage} work for this turn.",
        )
    return None


def _framework_doc_candidate(
    root: Path,
    state: HarnessState,
    policy: HarnessPolicy,
) -> tuple[str, str, str] | None:
    if not policy.include_framework_doc:
        return None
    if infer_stage(state) not in {"implement", "verify"}:
        return None
    framework = _infer_framework_name(root, state)
    if not framework:
        return None
    path = root / ".openjet" / "frameworks" / f"{framework}.md"
    body = _load_doc(path)
    if not body:
        return None
    return ("layer2", f".openjet/frameworks/{framework}.md", body)


def _infer_framework_name(root: Path, state: HarnessState) -> str | None:
    suffixes = {Path(path).suffix.lower() for path in state.files_in_play if str(path).strip()}
    if ".py" in suffixes or (root / "pyproject.toml").exists():
        return "python"
    if suffixes & {".ts", ".tsx", ".js", ".jsx"}:
        if any("react" in path.lower() for path in state.files_in_play) or (root / "package.json").exists():
            return "react"
    if ".rs" in suffixes or (root / "Cargo.toml").exists():
        return "rust"
    return None


def layered_context_config(raw: dict[str, Any] | None) -> LayeredContextConfig:
    payload = dict(raw or {})
    enabled = bool(payload.get("enabled", True))
    return LayeredContextConfig(
        enabled=enabled,
        layer1_enabled=enabled and bool(payload.get("layer1_enabled", True)),
        layer2_enabled=enabled and bool(payload.get("layer2_enabled", True)),
        layer3_enabled=enabled and bool(payload.get("layer3_enabled", True)),
        layer1_ratio=_clamp_ratio(payload.get("layer1_ratio"), default=0.15),
        layer2_ratio=_clamp_ratio(payload.get("layer2_ratio"), default=0.20),
        layer3_ratio=_clamp_ratio(payload.get("layer3_ratio"), default=0.10),
        alert_ratio=_clamp_ratio(payload.get("alert_ratio"), default=0.40),
    )


def _layer_enabled(config: LayeredContextConfig, layer_name: str) -> bool:
    if not config.enabled:
        return False
    if layer_name == "layer1":
        return config.layer1_enabled
    if layer_name == "layer2":
        return config.layer2_enabled
    if layer_name == "layer3":
        return config.layer3_enabled
    return True


def _clamp_ratio(value: Any, *, default: float) -> float:
    try:
        ratio = float(value)
    except (TypeError, ValueError):
        return default
    return max(0.0, min(ratio, 1.0))


def _load_doc(path: Path) -> str:
    try:
        if path.exists():
            return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""
    return ""


def _split_frontmatter(body: str) -> tuple[dict[str, Any], str]:
    if not body.startswith("---\n"):
        return {}, body
    try:
        _, rest = body.split("---\n", 1)
        frontmatter, content = rest.split("\n---\n", 1)
        loaded = yaml.safe_load(frontmatter) or {}
        if isinstance(loaded, dict):
            return loaded, content
    except Exception:
        return {}, body
    return {}, body


def _format_doc(label: str, body: str) -> str:
    title = _doc_title(label)
    return f"{title}\nSource: {label}\n\n{body.strip()}"


def _doc_title(label: str) -> str:
    if label == ".openjet/agents/base.md":
        return "BASE AGENT GUIDANCE"
    if label.startswith(".openjet/agents/"):
        return "ROLE-SPECIFIC AGENT GUIDANCE"
    if label == ".openjet/projects/default.md":
        return "PROJECT GUIDANCE"
    if label == "skills.md":
        return "AVAILABLE SKILLS"
    if label.startswith("skills/"):
        return "LOADED SKILL GUIDANCE"
    if label.startswith(".openjet/stages/"):
        return "CURRENT STAGE GUIDANCE"
    if label.startswith(".openjet/frameworks/"):
        return "FRAMEWORK GUIDANCE"
    if label.startswith("[stage:"):
        return "CURRENT STAGE"
    if label.startswith("file-context:"):
        return "FILE CONTEXT"
    if label == "recent-context":
        return "RECENT TURN CONTEXT"
    if label == "[project summary]":
        return "PROJECT SUMMARY"
    return "HARNESS CONTEXT"


def _compact_json(payload: dict[str, Any]) -> str:
    try:
        return json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
    except Exception:
        return str(payload)


def _shorten(text: str, max_len: int) -> str:
    compact = " ".join(text.split())
    if len(compact) <= max_len:
        return compact
    return compact[: max_len - 3] + "..."
