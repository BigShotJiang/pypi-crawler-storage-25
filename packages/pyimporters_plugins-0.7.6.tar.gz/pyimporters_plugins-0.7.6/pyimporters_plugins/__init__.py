"""Sherpa knowledge import plugins"""
__version__ = "0.7.6"
