"""Official model configurations."""
