// Copyright (c) 2025 Charlie Vanaret
// Licensed under the MIT license. See LICENSE file in the project directory for details.

#ifndef UNO_NORELAXATION_H
#define UNO_NORELAXATION_H

#include <memory>
#include "ConstraintRelaxationStrategy.hpp"
#include "ingredients/globalization_strategies/MeritFunction.hpp"
#include "optimization/OptimizationProblem.hpp"
#include "optimization/Parameterization.hpp"

namespace uno {
   // forward declarations
   class HessianModel;
   class InequalityHandlingMethod;
   class InertiaCorrectionStrategy;
   class SubproblemSolver;

   class NoRelaxation : public ConstraintRelaxationStrategy {
   public:
      NoRelaxation(const Model& model, Options& options);
      ~NoRelaxation() override;

      void initialize(Statistics& statistics, const Model& model, Iterate& initial_iterate, Direction& direction,
         bool uses_trust_region, EvaluationCache& evaluation_cache, Options& options) override;

      // direction computation
      void compute_feasible_direction(Statistics& statistics, Iterate& current_iterate, Direction& direction,
         double trust_region_radius, Evaluations& current_evaluations, WarmstartInformation& warmstart_information) override;
      [[nodiscard]] bool solving_feasibility_problem() const override;
      void switch_to_feasibility_problem(Statistics& statistics, Iterate& current_iterate, Direction& direction,
         Evaluations& current_evaluations, WarmstartInformation& warmstart_information) override;

      // trial iterate acceptance
      [[nodiscard]] bool is_iterate_acceptable(Statistics& statistics, const Model& model, Iterate& current_iterate,
         Iterate& trial_iterate, const Direction& direction, double step_length, bool uses_trust_region,
         EvaluationCache& evaluation_cache, WarmstartInformation& warmstart_information, UserCallbacks& user_callbacks) override;

      [[nodiscard]] std::string get_name() const override;

   private:
      const OptimizationProblem original_problem;
      std::unique_ptr<InequalityHandlingMethod> inequality_handling_method;
      std::unique_ptr<HessianModel> hessian_model;
      std::unique_ptr<InertiaCorrectionStrategy> inertia_correction_strategy;
      MeritFunction globalization_strategy;
      std::unique_ptr<OptimizationProblem> reformulated_problem{};
      std::unique_ptr<SubproblemSolver> subproblem_solver{};
      Parameterization parameterization;
      Vector<double> initial_point;
   };
} // namespace

#endif //UNO_NORELAXATION_H