// Copyright (c) 2025-2026 Charlie Vanaret
// Licensed under the MIT license. See LICENSE file in the project directory for details.

#include "LBFGSHessian.hpp"
#include "model/Model.hpp"
#include "options/Options.hpp"
#include "linear_algebra/BLAS.hpp"
#include "linear_algebra/Vector.hpp"
#include "linear_algebra/VectorView.hpp"
#include "optimization/Iterate.hpp"
#include "symbolic/Inverse.hpp"
#include "symbolic/Multiplication.hpp"
#include "symbolic/Range.hpp"
#include "symbolic/ScalarMultiple.hpp"
#include "symbolic/Sum.hpp"
#include "symbolic/Transpose.hpp"
#include "tools/Logger.hpp"
#include "tools/Statistics.hpp"

namespace uno {
   LBFGSHessian::LBFGSHessian(const Model& model, double objective_multiplier, const Options& options):
         DirectQuasiNewtonHessian("L-BFGS", model, objective_multiplier, options),
         // matrices
         L(this->memory_size, this->memory_size),
         D(this->memory_size),
         invsqrt_D(this->memory_size),
         L_invsqrt_D(this->memory_size, this->memory_size),
         M(this->memory_size, this->memory_size),
         U(this->model.number_variables, this->memory_size),
         V(this->model.number_variables, this->memory_size),
         delta_upper_bound(options.get_double("LBFGS_delta_upper_bound")) {
   }

   bool LBFGSHessian::is_positive_definite() const {
      return true;
   }

   void LBFGSHessian::initialize_statistics(Statistics& statistics) const {
      statistics.add_column("|BFGS|", Statistics::double_width - 2, 2, Statistics::column_order.at("|BFGS|"));
      statistics.set("|BFGS|", this->number_entries_in_memory);
   }

   void LBFGSHessian::notify_trial_iterate(Statistics& statistics, const Iterate& current_iterate, const Iterate& trial_iterate,
         EvaluationCache& evaluation_cache) {
      statistics.set("|BFGS|", this->number_entries_in_memory);
      DEBUG << "\n*** Adding entries to the BFGS memory at slot " << this->current_index << '\n';
      // update the matrices S and Y
      this->update_memory_entries(current_iterate, trial_iterate, evaluation_cache);

      // safeguard: if dot(sk, yk) is too small relative to sk and yk, skip the update
      const auto sk = this->S.column(this->current_index);
      const auto yk = this->Y.column(this->current_index);
      const double norm_sk = dot(sk, sk);
      const double norm_yk = dot(yk, yk);
      // tolerance is √(machine epsilon)
      if (dot(sk, yk) < std::sqrt(std::numeric_limits<double>::epsilon()) * norm_sk * norm_yk) {
         DEBUG << "dot(sk, yk) is too small, skipping the update\n";
      }
      else {
         // notify_accepted_iterate is called at the end of a major iteration. Since we don't know yet whether the
         // Hessian approximation will be used, we delay the update to the beginning of the next major iteration
         this->hessian_recomputation_required = true;
      }
   }

   // Hessian-vector product where the Hessian approximation is Bk = B0 - U Uᵀ + V Vᵀ and B0 = δ I
   // Bk v = (B0 - U Uᵀ + V Vᵀ) v = δ v - U (Uᵀ v) + V (Vᵀ v)
   void LBFGSHessian::compute_hessian_vector_product(const double* /*x*/, const double* vector,
         double objective_multiplier, const Vector<double>& /*constraint_multipliers*/, double* result) {
      if (objective_multiplier != this->fixed_objective_multiplier) {
         throw std::runtime_error("The quasi-Newton Hessian model was initialized with a different objective multiplier");
      }

      // recompute the Hessian representation if the limited memory was updated
      if (this->hessian_recomputation_required) {
         this->recompute_hessian_representation();
         this->hessian_recomputation_required = false;
      }

      // diagonal contribution δ I
      for (size_t variable_index: Range(this->model.number_variables)) {
         result[variable_index] = this->delta * vector[variable_index];
      }

      // rank-2 contribution
      // (U, V) in R^{n x m}
      // work on each column of U (Uᵀ v)
      for (size_t column_index: Range(this->number_entries_in_memory)) {
         const auto current_U_column = this->U.column(column_index);
         const double U_coefficient = -dot(current_U_column, vector); // minus sign for U
         // result += coefficient * current_column
         blas1::add(this->model.number_variables, U_coefficient, current_U_column.data(), result);
      }
      // work on each column of V (Vᵀ v)
      for (size_t column_index: Range(this->number_entries_in_memory)) {
         const auto current_V_column = this->V.column(column_index);
         const double V_coefficient = dot(current_V_column, vector); // plus sign for V
         // result += coefficient * current_column
         blas1::add(this->model.number_variables, V_coefficient, current_V_column.data(), result);
      }
   }

   size_t LBFGSHessian::get_correction_rank() const {
      return 2 * this->number_entries_in_memory;
   }

   // get a column of (U V)
   VectorView<std::vector<double>> LBFGSHessian::get_correction_column(size_t column_index) const {
      if (column_index < this->number_entries_in_memory) {
         return this->U.column(column_index);
      }
      else {
         return this->V.column(column_index - this->number_entries_in_memory);
      }
   }

   // get the scaling of a given column (-1 for U, +1 for V)
   double LBFGSHessian::get_correction_column_scaling(size_t column_index) const {
      if (column_index < this->number_entries_in_memory) {
         return -1.;
      }
      else {
         return 1.;
      }
   }

   // protected member functions

   void LBFGSHessian::update_D() {
      this->D[this->current_index] = dot(this->S.column(this->current_index), this->Y.column(this->current_index));
      DEBUG << "> diag(D): "; print_vector(DEBUG, this->D);
   }

   void LBFGSHessian::recompute_hessian_representation() {
      // check that the latest D entry sᵀ y is > 0
      // TODO implement Procedure 18.2 (Damped BFGS Updating) from Numerical Optimization
      this->update_D();
      if (this->D[this->current_index] <= 0.) {
         DEBUG << "Skipping the update\n";
         return;
      }

      this->validate_update();
      assert(0 < this->number_entries_in_memory);

      DEBUG << "\n*** Recomputing the Hessian representation with " << this->number_entries_in_memory << " entries\n";
      // note: some matrices were allocated with the maximum memory size. We will work with submatrices instead (of size
      // this->number_entries_in_memory, not this->memory_size)
      const auto Sk = this->S.submatrix(this->model.number_variables, this->number_entries_in_memory);
      const auto L_invsqrt_Dk = this->L_invsqrt_D.submatrix(this->number_entries_in_memory, this->number_entries_in_memory);
      auto Mk = this->M.submatrix(this->number_entries_in_memory, this->number_entries_in_memory);

      /* update the initial Hessian approximation δ I */
      this->delta = this->compute_delta();
      DEBUG << "Initial identity multiple: " << this->delta << "\n";

      /* update the entries of L and L_invsqrt_D = L D^{-1/2} */
      // update invsqrt_D = 1/sqrt_D
      this->invsqrt_D[this->current_index] = 1./std::sqrt(this->D[this->current_index]);
      // the entries of L and L_invsqrt_D depend on this->current_index (1 row and 1 column, possibly empty)
      // row this->current_index
      for (size_t column_index: Range(this->current_index)) {
         this->L.entry(this->current_index, column_index) = dot(this->S.column(this->current_index), this->Y.column(column_index));
         this->L_invsqrt_D.entry(this->current_index, column_index) = this->invsqrt_D[column_index] * this->L.entry(this->current_index, column_index);
      }
      // column this->current_index (excluding the diagonal)
      for (size_t row_index: Range(this->current_index+1, this->number_entries_in_memory)) {
         this->L.entry(row_index, this->current_index) = dot(this->S.column(row_index), this->Y.column(this->current_index));
         this->L_invsqrt_D.entry(row_index, this->current_index) = this->invsqrt_D[this->current_index] * this->L.entry(row_index, this->current_index);
      }
      DEBUG << "> L: " << this->L;
      DEBUG << "> L_invsqrt_D: " << this->L_invsqrt_D;

      /* form M = L D⁻¹ Lᵀ + Sᵀ B0 S = L_invsqrt_D L_invsqrt_Dᵀ + δ Sᵀ S */
      Mk = L_invsqrt_Dk * transpose(L_invsqrt_Dk);
      Mk += this->delta * (transpose(Sk) * Sk);
      DEBUG << "> M: " << this->M;

      /* compute the Cholesky factor J of M = J Jᵀ */
      const bool success = Mk.compute_cholesky_factorization(); // J overwrites M
      DEBUG << "Cholesky success: " << success << '\n';
      DEBUG << "> J: " << this->M;

      /* form V and U */
      // update the current column of V = Y D^{-1/2}
      this->V.column(this->current_index) = this->invsqrt_D[this->current_index] * this->Y.column(this->current_index);
      // form U = (δ S + Y D⁻¹ Lᵀ) J⁻ᵀ
      const auto Jk = this->M.submatrix(this->number_entries_in_memory, this->number_entries_in_memory); // J overwrites M
      auto Uk = this->U.submatrix(this->model.number_variables, this->number_entries_in_memory);
      const auto Vk = this->V.submatrix(this->model.number_variables, this->number_entries_in_memory);
      Uk = Sk;
      Uk = this->delta * Uk + Vk * transpose(L_invsqrt_Dk);
      Uk *= transpose(inverse(lower_triangular(Jk)));
      DEBUG << "> U: " << this->U;
      DEBUG << "> V: " << this->V << '\n';

      // increment the slot: if we exceed the size of the memory, we start over and replace the oldest point in memory
      this->current_index = (this->current_index + 1) % this->memory_size;
   }

   // compute δ = yᵀy / sᵀy at the last entry
   double LBFGSHessian::compute_delta() const {
      assert(0 < this->number_entries_in_memory);
      const auto y = this->Y.column(this->current_index);
      const double yTy = dot(y, y);
      const double sTy = this->D[this->current_index]; // > 0 by the update rule
      // TODO safeguard
      return std::min(this->delta_upper_bound, yTy/sTy);
   }
} // namespace