import sys
import unittest
import os
import json
import io
import base64
import tempfile
from contextlib import redirect_stdout
from types import SimpleNamespace
from unittest.mock import patch

from sciveo import cli
from sciveo.agents.base import AgentBase, LLMClientBase, ToolApprovalRequest, ToolBase, parse_agent_blocks
from sciveo.agents.console import AgentConsole, ApprovalSession, ConsoleRenderer, GenericToolAgent, _AgentStreamTextFilter, _resolve_llm_base_url, create_llm_client, run_agent_cli
from sciveo.agents.clients.anthropic import _parse_json_blocks_text
from sciveo.agents.clients.gemini import GeminiClient
from sciveo.agents.clients.hf import HuggingFaceRuntimeClient
from sciveo.agents.clients.ollama import OllamaClient
from sciveo.agents.clients.openai import OpenAIClient
from sciveo.agents.media import normalize_image_input, normalize_image_inputs
from sciveo.agents.render import _quantize_rgb, terminal_image_preview
from sciveo.agents.runtime import HuggingFaceLocalRuntime, _find_gguf_file, pull_model
from sciveo.agents.tools.images import ToolDescribeImages, ToolRenderImages
from sciveo.agents.tools.os import ToolBash, ToolWriteFile
from sciveo.agents.tools.web import ToolHttpRead, _browser_headers, _html_to_text, _parse_duckduckgo_results


class FakeLLM(LLMClientBase):
  def __init__(self, responses):
    self.responses = list(responses)
    self.calls = []

  def chat(self, messages, tools=None, system_prompt=None):
    self.calls.append({
      "messages": list(messages),
      "tools": list(tools or []),
      "system_prompt": system_prompt,
    })
    return self.responses.pop(0)


class EchoTool(ToolBase):
  schema = {
    "name": "echo_tool",
    "description": "Echo the given value",
    "input_schema": {
      "type": "object",
      "properties": {
        "value": {"type": "string"},
      },
      "required": ["value"],
    },
  }

  def __init__(self):
    self.inputs = []

  def run(self, tool_input, agent):
    self.inputs.append(tool_input)
    return {"echo": tool_input.get("value")}


class ApprovalTool(ToolBase):
  schema = {
    "name": "approval_tool",
    "description": "Tool that requires approval",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": [],
    },
  }

  def __init__(self):
    self.ran = False

  def approval_request(self, tool_input, agent):
    return ToolApprovalRequest(
      tool_name=self.schema["name"],
      scope="shell",
      summary="Run approval-only tool",
      details=["command: demo"],
    )

  def run(self, tool_input, agent):
    self.ran = True
    return {"status": "ok"}


class StubAgent:
  def __init__(self):
    self.clear_calls = 0
    self.asked = []
    self.llm = None

  def clear(self):
    self.clear_calls += 1

  def ask(self, text, reset=False, attachments=None):
    if attachments:
      self.asked.append((text, reset, attachments))
    else:
      self.asked.append((text, reset))
    return f"AGENT:{text}"

  def call_tool(self, name, tool_input):
    if name == "help":
      return "bash: Run a shell command"
    raise AssertionError(f"Unexpected tool {name}")


class StubLLM:
  def __init__(self):
    self.calls = []
    self.last_metrics = None

  def chat(self, messages, tools=None, system_prompt=None):
    self.calls.append((messages, tools, system_prompt))
    self.last_metrics = {"request_seconds": 0.1}
    return "LLM:describe"


class FakeConfig(dict):
  def __init__(self):
    super().__init__({"secret_access_key": None})
    self.name = "sciveo"


class TestAgentBase(unittest.TestCase):
  def test_normalize_image_inputs_accepts_path_and_base64_json(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      images = normalize_image_inputs(
        input_path=path,
        data_json={
          "images": [{
            "data": "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii"),
            "name": "inline.png",
          }],
        },
      )

    self.assertEqual(len(images), 2)
    self.assertEqual(images[0]["mime_type"], "image/png")
    self.assertEqual(images[0]["name"], "demo.png")
    self.assertEqual(images[1]["name"], "inline.png")

  def test_parse_agent_blocks_accepts_single_block_object(self):
    blocks = parse_agent_blocks({"type": "text", "text": "done"})

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "text")
    self.assertEqual(blocks[0].content, "done")

  def test_parse_agent_blocks_accepts_fenced_json_tool_object(self):
    blocks = parse_agent_blocks(
      '```json\n{"type":"tool_use","name":"list_dir","input":{}}\n```'
    )

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "tool_use")
    self.assertEqual(blocks[0].content.name, "list_dir")

  def test_parse_agent_blocks_accepts_fenced_json_tool_list(self):
    blocks = parse_agent_blocks(
      '```json\n[{"type":"tool_use","name":"list_dir","input":{}}]\n```'
    )

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "tool_use")
    self.assertEqual(blocks[0].content.name, "list_dir")

  def test_parse_agent_blocks_accepts_thought_prefixed_tool_json(self):
    blocks = parse_agent_blocks(
      '<think>\nI should list the directory.\n</think>\n'
      '{"type":"tool_use","name":"list_dir","input":{"path":"/tmp"}}'
    )

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "tool_use")
    self.assertEqual(blocks[0].content.name, "list_dir")
    self.assertEqual(blocks[0].content.input["path"], "/tmp")

  def test_parse_agent_blocks_preserves_think_in_text_blocks(self):
    blocks = parse_agent_blocks(
      '{"type":"text","text":"<think>private scratchpad</think>\\ndone"}'
    )

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "text")
    self.assertEqual(blocks[0].content, "<think>private scratchpad</think>\ndone")

  def test_parse_agent_blocks_rejects_malformed_tool_json(self):
    with self.assertRaisesRegex(ValueError, "looked like tool JSON"):
      parse_agent_blocks(
        '```json\n[{"type":"tool_use","name":"bash","input":{"command":"echo "bad""}}]\n```'
      )

  def test_parse_agent_blocks_accepts_adjacent_json_documents(self):
    blocks = parse_agent_blocks(
      '[{"type":"tool_use","name":"pwd","input":{}}]'
      '[{"type":"text","text":"done"}]'
    )

    self.assertEqual(len(blocks), 2)
    self.assertEqual(blocks[0].type, "tool_use")
    self.assertEqual(blocks[0].content.name, "pwd")
    self.assertEqual(blocks[1].type, "text")
    self.assertEqual(blocks[1].content, "done")

  def test_parse_agent_blocks_accepts_tool_json_with_trailing_text(self):
    blocks = parse_agent_blocks(
      '[{"type":"tool_use","name":"pwd","input":{}}]'
      'Which package name should I check on public PyPI?'
    )

    self.assertEqual(len(blocks), 2)
    self.assertEqual(blocks[0].type, "tool_use")
    self.assertEqual(blocks[0].content.name, "pwd")
    self.assertEqual(blocks[1].type, "text")
    self.assertEqual(blocks[1].content, "Which package name should I check on public PyPI?")

  def test_parse_agent_blocks_keeps_non_agent_json_as_text(self):
    blocks = parse_agent_blocks('{"plain": true}')

    self.assertEqual(len(blocks), 1)
    self.assertEqual(blocks[0].type, "text")
    self.assertEqual(blocks[0].content, '{"plain": true}')

  def test_agent_uses_structured_tool_input(self):
    llm = FakeLLM([
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "abc"}}],
      [{"type": "text", "text": "done"}],
    ])
    tool = EchoTool()
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(tool)

    result = agent.ask("run the tool")

    self.assertEqual(result, "done")
    self.assertEqual(tool.inputs, [{"value": "abc"}])
    self.assertIn("Available tools", llm.calls[0]["system_prompt"])
    self.assertIn("Test prompt", llm.calls[0]["system_prompt"])
    self.assertIn("Tool result for echo_tool", agent.messages[-2]["content"])

  def test_agent_executes_markdown_wrapped_tool_json(self):
    llm = FakeLLM([
      'json\n{"type":"tool_use","name":"echo_tool","input":{"value":"abc"}}',
      [{"type": "text", "text": "done"}],
    ])
    tool = EchoTool()
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(tool)

    result = agent.ask("run the tool")

    self.assertEqual(result, "done")
    self.assertEqual(tool.inputs, [{"value": "abc"}])

  def test_agent_retries_after_malformed_tool_json(self):
    malformed = '```json\n[{"type":"tool_use","name":"bash","input":{"command":"echo "bad""}}]\n```'
    llm = FakeLLM([
      malformed,
      [{"type": "text", "text": "done"}],
    ])
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(ToolBash())

    result = agent.ask("write code")

    self.assertEqual(result, "done")
    self.assertEqual(len(llm.calls), 2)
    self.assertIn("could not be parsed", llm.calls[1]["messages"][-1]["content"])

  def test_agent_discards_text_from_tool_use_rounds(self):
    llm = FakeLLM([
      [
        {"type": "tool_use", "name": "echo_tool", "input": {"value": "abc"}},
        {"type": "text", "text": "speculative answer"},
      ],
      [{"type": "text", "text": "final answer"}],
    ])
    tool = EchoTool()
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(tool)

    result = agent.ask("run the tool")

    self.assertEqual(result, "final answer")
    self.assertEqual(tool.inputs, [{"value": "abc"}])

  def test_agent_resolves_loose_tool_names(self):
    llm = FakeLLM([])
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(EchoTool())
    agent.register_tool(ToolBash())

    self.assertEqual(agent._resolve_tool_name("echo_tool extra"), "echo_tool")
    self.assertEqual(agent._resolve_tool_name("bash python"), "bash")
    self.assertEqual(agent._resolve_tool_name("python python"), "python python")

  def test_bash_tool_accepts_cmd_and_workdir_aliases(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      result = ToolBash().run({"cmd": "pwd", "workdir": tmpdir}, None)

    self.assertEqual(result["code"], 0)
    self.assertEqual(result["cwd"], tmpdir)
    self.assertEqual(os.path.realpath(result["stdout"].strip()), os.path.realpath(tmpdir))

  def test_agent_does_not_execute_unknown_tool_name(self):
    payload = 'json\n{"type":"tool_use","name":"python python","input":{"command":"print(1)"}}'
    llm = FakeLLM([payload])
    agent = AgentBase(llm=llm, system_prompt="Test prompt")
    agent.register_tool(ToolBash())

    result = agent.ask("write code")

    self.assertEqual(result, payload)
    self.assertEqual(len(llm.calls), 1)

  def test_anthropic_text_parser_handles_multiple_json_documents(self):
    text = """
    [{"type": "tool_use", "name": "bash", "input": {"command": "mkdir -p demo"}}]

    [{"type": "tool_use", "name": "write_file", "input": {"path": "demo.txt", "content": "ok"}}]

    [{"type": "text", "text": "done"}]
    """

    result = _parse_json_blocks_text(text)

    self.assertEqual(result, [
      {"type": "tool_use", "name": "bash", "input": {"command": "mkdir -p demo"}},
      {"type": "tool_use", "name": "write_file", "input": {"path": "demo.txt", "content": "ok"}},
      {"type": "text", "text": "done"},
    ])

  def test_call_tool_denies_when_approval_callback_rejects(self):
    tool = ApprovalTool()
    agent = AgentBase(llm=FakeLLM([]), approval_callback=lambda request, agent: False)
    agent.register_tool(tool)

    result = agent.call_tool("approval_tool", {})

    self.assertEqual(result["error"], "Tool approval_tool denied by approval policy")
    self.assertFalse(tool.ran)

  def test_write_file_approval_scope_tracks_external_paths(self):
    tool = ToolWriteFile()
    with tempfile.TemporaryDirectory() as tmpdir:
      local_path = os.path.join(tmpdir, "local.txt")
      external_path = os.path.join(os.path.dirname(tmpdir), "external.txt")
      agent = AgentBase(llm=FakeLLM([]), approval_root=tmpdir)

      local_request = tool.approval_request({"path": local_path, "content": "ok"}, agent)
      external_request = tool.approval_request({"path": external_path, "content": "ok"}, agent)

    self.assertEqual(local_request.scope, "local_write")
    self.assertEqual(external_request.scope, "external_write")

  def test_agent_can_continue_after_tool_round_checkpoint(self):
    llm = FakeLLM([
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "one"}}],
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "two"}}],
      [{"type": "text", "text": "done"}],
    ])
    approvals = []
    tool = EchoTool()
    agent = AgentBase(
      llm=llm,
      system_prompt="Test prompt",
      max_tool_rounds=1,
      approval_callback=lambda request, agent: approvals.append((request.tool_name, request.scope)) or True,
    )
    agent.register_tool(tool)

    result = agent.ask("run the tool twice")

    self.assertEqual(result, "done")
    self.assertEqual(tool.inputs, [{"value": "one"}, {"value": "two"}])
    self.assertIn(("agent", "tool_rounds"), approvals)

  def test_agent_stops_cleanly_when_tool_round_continuation_is_declined(self):
    llm = FakeLLM([
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "one"}}],
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "two"}}],
    ])
    approvals = []
    tool = EchoTool()
    agent = AgentBase(
      llm=llm,
      system_prompt="Test prompt",
      max_tool_rounds=1,
      approval_callback=lambda request, agent: approvals.append((request.tool_name, request.scope)) and False,
    )
    agent.register_tool(tool)

    result = agent.ask("run the tool twice")

    self.assertEqual(result, "[Agent stopped] Additional tool rounds were declined.")
    self.assertEqual(tool.inputs, [{"value": "one"}])
    self.assertEqual(approvals, [("agent", "tool_rounds")])

  def test_agent_emits_activity_events_for_llm_and_tools(self):
    llm = FakeLLM([
      [{"type": "tool_use", "name": "echo_tool", "input": {"value": "abc"}}],
      [{"type": "text", "text": "done"}],
    ])
    events = []
    tool = EchoTool()
    agent = AgentBase(
      llm=llm,
      system_prompt="Test prompt",
      activity_callback=lambda kind, data, agent: events.append((kind, dict(data))),
    )
    agent.register_tool(tool)

    result = agent.ask("run the tool")

    self.assertEqual(result, "done")
    self.assertEqual(
      [event[0] for event in events],
      ["llm_start", "llm_end", "tool_start", "tool_end", "llm_start", "llm_end"],
    )

  def test_agent_emits_llm_elapsed_time_without_provider_metrics(self):
    llm = FakeLLM([
      [{"type": "text", "text": "done"}],
    ])
    events = []
    agent = AgentBase(
      llm=llm,
      system_prompt="Test prompt",
      activity_callback=lambda kind, data, agent: events.append((kind, dict(data))),
    )

    with patch("sciveo.agents.base.time.perf_counter", side_effect=[10.0, 12.49]):
      result = agent.ask("hello")

    self.assertEqual(result, "done")
    self.assertEqual(events[1][0], "llm_end")
    self.assertAlmostEqual(events[1][1]["metrics"]["request_seconds"], 2.49)

  def test_agent_prompt_discourages_tool_use_for_plain_code_answers(self):
    agent = AgentBase(llm=FakeLLM([]), system_prompt="Test prompt")
    agent.register_tool(ToolBash())

    prompt = agent._build_system_prompt()

    self.assertIn("For pure explanations or code snippets", prompt)
    self.assertIn("Do not call bash with echo", prompt)

  def test_agent_sends_image_attachments_once_and_stores_placeholder(self):
    image = {
      "type": "image",
      "mime_type": "image/png",
      "data": "iVBORw0KGgo=",
      "name": "demo.png",
    }
    llm = FakeLLM([
      [{"type": "text", "text": "seen"}],
      [{"type": "text", "text": "again"}],
    ])
    agent = AgentBase(llm=llm, system_prompt="Test prompt")

    first = agent.ask("describe", attachments=[image])
    second = agent.ask("follow up")

    self.assertEqual(first, "seen")
    self.assertEqual(second, "again")
    self.assertIsInstance(llm.calls[0]["messages"][0]["content"], list)
    self.assertEqual(llm.calls[0]["messages"][0]["content"][1]["type"], "image")
    self.assertIsInstance(llm.calls[1]["messages"][0]["content"], str)
    self.assertIn("[Image: demo.png", llm.calls[1]["messages"][0]["content"])

  def test_describe_images_tool_sends_file_as_structured_image(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      llm = FakeLLM(["a small demo image"])
      agent = AgentBase(llm=llm, system_prompt="Test prompt")
      tool = ToolDescribeImages()

      result = tool.run({"path": path, "prompt": "Describe it."}, agent)

      self.assertEqual(result["count"], 1)
      self.assertEqual(result["descriptions"][0]["description"], "a small demo image")
      content = llm.calls[0]["messages"][0]["content"]
      self.assertEqual(content[0]["text"], "Describe it.")
      self.assertEqual(content[1]["type"], "image")
      self.assertEqual(content[1]["name"], "demo.png")

  def test_describe_images_tool_preserves_model_result_blocks(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      llm = FakeLLM(["<think>\n\n</think>\n\nA clean description."])
      agent = AgentBase(llm=llm, system_prompt="Test prompt")
      result = ToolDescribeImages().run({"path": path}, agent)

      self.assertEqual(result["descriptions"][0]["description"], "<think>\n\n</think>\n\nA clean description.")

  def test_describe_images_tool_scans_directory_with_limit(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    with tempfile.TemporaryDirectory() as tmpdir:
      for name in ("b.png", "a.png"):
        with open(os.path.join(tmpdir, name), "wb") as fp:
          fp.write(png_bytes)
      with open(os.path.join(tmpdir, "notes.txt"), "w", encoding="utf-8") as fp:
        fp.write("not an image")

      llm = FakeLLM(["first"])
      agent = AgentBase(llm=llm, system_prompt="Test prompt")
      result = ToolDescribeImages().run({"path": tmpdir, "limit": 1}, agent)

      self.assertEqual(result["count"], 1)
      self.assertTrue(result["truncated"])
      self.assertEqual(result["descriptions"][0]["name"], "a.png")
      self.assertEqual(len(llm.calls), 1)

  def test_render_images_tool_emits_image_preview_activity(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    events = []
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      agent = AgentBase(llm=FakeLLM([]), system_prompt="Test prompt")
      agent.activity_callback = lambda kind, data, agent_ref: events.append((kind, data))
      result = ToolRenderImages().run({"path": tmpdir}, agent)

    self.assertEqual(result["count"], 1)
    self.assertEqual(result["images"][0]["name"], "demo.png")
    self.assertEqual(events[0][0], "image_preview")
    self.assertEqual(events[0][1]["image"]["name"], "demo.png")

  def test_generic_tool_agent_registers_describe_images(self):
    agent = GenericToolAgent(llm=FakeLLM([]))

    self.assertIn("describe_images", agent.tools)
    self.assertIn("render_images", agent.tools)


class TestAgentConsole(unittest.TestCase):
  def test_console_clear_command_clears_history(self):
    console = AgentConsole(StubAgent())

    is_continue, output = console.process_line("/clear")

    self.assertTrue(is_continue)
    self.assertEqual(output, "Conversation cleared.")
    self.assertEqual(console.agent.clear_calls, 1)

  def test_console_regular_input_uses_agent(self):
    console = AgentConsole(StubAgent())

    is_continue, output = console.process_line("hello")

    self.assertTrue(is_continue)
    self.assertEqual(output, "AGENT:hello")
    self.assertEqual(console.agent.asked, [("hello", False)])

  def test_console_image_command_attaches_to_next_prompt_once(self):
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      agent = StubAgent()
      agent.llm = StubLLM()
      console = AgentConsole(agent, output_func=lambda value: None)
      is_continue, output = console.process_line(f"/image {path}")
      self.assertTrue(is_continue)
      self.assertIn("Attached image", output)

      is_continue, output = console.process_line("describe")
      self.assertTrue(is_continue)
      self.assertEqual(output, "LLM:describe")
      self.assertEqual(agent.llm.calls[0][0][0]["content"][0]["text"], "describe")
      self.assertEqual(agent.llm.calls[0][0][0]["content"][1]["name"], "demo.png")
      self.assertEqual(console.agent.asked, [])

      console.process_line("again")
      self.assertEqual(console.agent.asked[-1], ("again", False))

  def test_terminal_image_preview_renders_ascii_preview(self):
    try:
      from PIL import Image
    except ImportError:
      self.skipTest("Pillow is not installed")

    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      image = Image.new("RGB", (4, 2))
      image.putdata([
        (0, 0, 0), (80, 80, 80), (180, 180, 180), (255, 255, 255),
        (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0),
      ])
      image.save(path)

      preview = terminal_image_preview(
        normalize_image_input({"path": path}),
        width=4,
        max_width=4,
        color=False,
      )

    self.assertIn("Image preview: demo.png", preview)
    self.assertNotIn("\033[", preview)
    self.assertGreaterEqual(len(preview.splitlines()), 2)

  def test_terminal_image_preview_quantizes_rgb_channels(self):
    self.assertEqual(_quantize_rgb((12, 52, 255), levels=4), (0, 85, 255))
    self.assertEqual(_quantize_rgb((12, 52, 255), levels=16), (17, 51, 255))

  def test_terminal_image_preview_uses_color_cells_when_color_enabled(self):
    try:
      from PIL import Image
    except ImportError:
      self.skipTest("Pillow is not installed")

    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      image = Image.new("RGB", (2, 1))
      image.putdata([(255, 0, 0), (0, 255, 0)])
      image.save(path)

      preview = terminal_image_preview(
        normalize_image_input({"path": path}),
        width=2,
        max_width=2,
        color=True,
      )

    self.assertIn("\033[38;2;", preview)
    self.assertGreaterEqual(preview.count("█"), 2)

  def test_terminal_image_preview_keeps_full_rgb_when_color_enabled(self):
    try:
      from PIL import Image
    except ImportError:
      self.skipTest("Pillow is not installed")

    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      image = Image.new("RGB", (1, 1), (12, 52, 255))
      image.save(path)

      preview = terminal_image_preview(
        normalize_image_input({"path": path}),
        width=4,
        max_width=4,
        color=True,
      )

    self.assertIn("\033[38;2;12;52;255m", preview)

  def test_renderer_header_includes_softel_labs(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.header("hf", "demo")

    self.assertGreaterEqual(len(lines), 3)
    self.assertEqual(lines[0], "sciveo agent")
    self.assertEqual(lines[1], "SOFTEL labs")
    self.assertEqual(lines[2], "provider hf  model demo")

  def test_renderer_formats_fenced_code_blocks(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message("assistant", "Run this:\n\n```bash\nls -la\n```")

    self.assertEqual(lines, [
      "assistant",
      "│ Run this:",
      "│ bash",
      "│ ls -la",
    ])

  def test_renderer_formats_markdown_sections(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message(
      "assistant",
      "# Title\n\n"
      "A **bold** word and `code`.\n\n"
      "- first\n"
      "- second\n\n"
      "1. one\n"
      "2. two\n\n"
      "> quoted\n\n"
      "---"
    )

    self.assertEqual(lines, [
      "assistant",
      "│ # Title",
      "│ A bold word and code.",
      "│ • first",
      "│ • second",
      "│ 1. one",
      "│ 2. two",
      "│ ▏ quoted",
      "│ ──────────────────────────────────",
    ])

  def test_renderer_preserves_underscores_inside_filenames(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message("assistant", "File: laion_coco_aesthetic_1k_1.jpg")

    self.assertIn("│ File: laion_coco_aesthetic_1k_1.jpg", lines)

  def test_renderer_preserves_markdown_heading_depth(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message("assistant", "## Conclusion\n\n### 6. Logging\n\n#### Details")

    self.assertEqual(lines, [
      "assistant",
      "│ ## Conclusion",
      "│ ### 6. Logging",
      "│ #### Details",
    ])

  def test_renderer_uses_stronger_color_for_higher_markdown_headings(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=True)

    renderer.render_message("assistant", "## Conclusion\n\n### 6. Logging")

    self.assertIn("\033[1;38;5;250m## Conclusion", lines[1])
    self.assertIn("\033[1;38;5;245m### 6. Logging", lines[2])

  def test_renderer_uses_python_code_section_renderer(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message("assistant", "Example:\n\n```python\nprint('hi')\n```")

    self.assertEqual(lines, [
      "assistant",
      "│ Example:",
      "│ python",
      "│ print('hi')",
    ])

  def test_renderer_uses_json_code_section_renderer(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_message("assistant", 'Payload:\n\n```json\n{"b":2,"a":1}\n```')

    self.assertEqual(lines, [
      "assistant",
      "│ Payload:",
      "│ json",
      "│ {",
      '│   "b": 2,',
      '│   "a": 1',
      "│ }",
    ])

  def test_renderer_formats_activity_lines(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_activity("tool_start", name="bash", input={"command": "rg --files"})
    renderer.render_activity("tool_end", name="bash", result={"code": 0})

    self.assertEqual(lines, [
      "running bash: rg --files",
      "bash done",
    ])

  def test_renderer_formats_llm_speed_metrics(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_activity("llm_end", metrics={
      "input_tokens": 120,
      "output_tokens": 8,
      "request_seconds": 3.14159,
      "context_tokens_per_second": 240.123,
      "generation_tokens_per_second": 12.345,
    })

    self.assertEqual(lines, [
      "thought complete  took 3.14 seconds  ctx 240.1 tok/s (120 tok)  gen 12.3 tok/s (8 tok)",
    ])

  def test_renderer_streams_llm_tokens_before_final_metrics(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_activity("llm_token", text="he")
    renderer.render_activity("llm_token", text="llo")
    renderer.render_activity("llm_end", metrics={
      "request_seconds": 1.0,
      "generation_tokens_per_second": 2.0,
      "output_tokens": 2,
    })

    self.assertEqual(lines, [
      "generation",
      "│ ",
      "he",
      "llo",
      "\n",
      "thought complete  took 1.00 seconds  gen 2.0 tok/s (2 tok)",
    ])

  def test_renderer_streams_fenced_python_raw_until_final_render(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_activity("llm_token", text="```py")
    renderer.render_activity("llm_token", text="thon\nprint('hi')\n```")
    renderer.render_activity("llm_end", metrics={
      "request_seconds": 1.0,
      "generation_tokens_per_second": 2.0,
      "output_tokens": 6,
    })

    self.assertEqual(lines, [
      "generation",
      "│ ",
      "```py",
      "thon\n│ print('hi')\n│ ```",
      "\n",
      "thought complete  took 1.00 seconds  gen 2.0 tok/s (6 tok)",
    ])

  def test_agent_stream_text_filter_passes_json_wrapper_raw(self):
    stream_filter = _AgentStreamTextFilter()

    first = stream_filter.feed('{"type": "text", "text": "Hel')
    second = stream_filter.feed('lo \\"there\\""}')

    self.assertEqual(first, '{"type": "text", "text": "Hel')
    self.assertEqual(second, 'lo \\"there\\""}')

  def test_agent_stream_text_filter_passes_tool_json_wrappers_raw(self):
    stream_filter = _AgentStreamTextFilter()

    first = stream_filter.feed("```json\n{")
    second = stream_filter.feed('"type": "tool_use", "name": "list_dir", "input": {}}\n```')

    self.assertEqual(first, "```json\n{")
    self.assertEqual(second, '"type": "tool_use", "name": "list_dir", "input": {}}\n```')

  def test_agent_stream_text_filter_does_not_drop_plain_prefix_after_probe(self):
    stream_filter = _AgentStreamTextFilter()

    self.assertEqual(stream_filter.feed("j"), "j")
    self.assertEqual(stream_filter.feed("ust hello"), "ust hello")

  def test_agent_stream_text_filter_passes_plain_text(self):
    stream_filter = _AgentStreamTextFilter()

    self.assertEqual(stream_filter.feed("Hel"), "Hel")
    self.assertEqual(stream_filter.feed("lo"), "lo")

  def test_console_streams_raw_agent_text(self):
    lines = []
    console = AgentConsole(StubAgent(), output_func=lines.append, use_prompt_session=False)

    console._handle_activity("llm_token", {"text": '{"type": "text", "text": "Hel'}, console.agent)
    console._handle_activity("llm_token", {"text": 'lo"}'}, console.agent)

    self.assertEqual(console._streamed_text, '{"type": "text", "text": "Hello"}')
    self.assertTrue(console._should_render_output("assistant", "Hello"))
    self.assertIn('{"type"', "".join(lines))
    self.assertIn("Hel", "".join(lines))
    self.assertIn("lo", "".join(lines))

  def test_console_suppresses_final_output_when_stream_differs_only_by_markdown_spacing(self):
    console = AgentConsole(StubAgent(), output_func=lambda text: None, use_prompt_session=False)
    console._streamed_text = "Intro:\n\n- one\n\n- two\n\nDone."

    self.assertFalse(console._should_render_output("assistant", "Intro:\n- one\n- two\nDone."))

  def test_console_renders_final_message_when_stream_has_code_fence(self):
    console = AgentConsole(StubAgent(), output_func=lambda text: None, use_prompt_session=False)
    console._streamed_text = "```python\nprint('hi')\n```"

    self.assertTrue(console._should_render_output("assistant", "```python\nprint('hi')\n```"))

  def test_renderer_can_replace_raw_stream_on_tty(self):
    class FakeStdout:
      def __init__(self):
        self.writes = []

      def write(self, text):
        self.writes.append(str(text))

      def flush(self):
        pass

      def isatty(self):
        return True

    fake_stdout = FakeStdout()
    with patch.object(sys, "stdout", fake_stdout):
      with patch.dict(os.environ, {"TERM": "xterm-256color"}, clear=False):
        renderer = ConsoleRenderer()
        renderer.render_activity("llm_token", text="```python\nprint('hi')\n```")
        renderer.render_activity("llm_end", metrics={
          "request_seconds": 1.0,
          "generation_tokens_per_second": 2.0,
          "output_tokens": 6,
        })
        replaced = renderer.replace_stream_with_message("assistant", "```python\nprint('hi')\n```")

    output = "".join(fake_stdout.writes)
    self.assertTrue(replaced)
    self.assertIn("\033[", output)
    self.assertIn("assistant", output)
    self.assertIn("python", output)
    self.assertIn("thought complete", output)

  def test_renderer_includes_latest_progress_metrics_in_generation_header(self):
    lines = []
    renderer = ConsoleRenderer(output_func=lines.append, color=False)

    renderer.render_activity("llm_progress", metrics={
      "context_tokens_per_second": 123.4,
      "generation_tokens_per_second": 5.6,
      "input_tokens": 10,
      "output_tokens": 2,
    })
    renderer.render_activity("llm_token", text="hi")

    self.assertIn("generation  ctx 123.4 tok/s (10 tok)  gen 5.6 tok/s (2 tok)", lines)

  def test_approval_session_remembers_scope(self):
    prompts = []
    session = ApprovalSession(
      mode="ask",
      input_func=lambda prompt: prompts.append(prompt) or "a",
      output_func=lambda text: None,
      is_tty=True,
    )
    request = ToolApprovalRequest("bash", "shell", "Run shell command", ["command: pwd"])

    first = session(request, None)
    second = session(request, None)

    self.assertTrue(first)
    self.assertTrue(second)
    self.assertEqual(len(prompts), 1)

  def test_approval_session_labels_agent_requests(self):
    lines = []
    prompts = []
    session = ApprovalSession(
      mode="ask",
      input_func=lambda prompt: prompts.append(prompt) or "y",
      output_func=lines.append,
      is_tty=True,
    )

    allowed = session(
      ToolApprovalRequest("agent", "tool_rounds", "Continue after 8 tool rounds", ["round_limit: 8"]),
      None,
    )

    self.assertTrue(allowed)
    self.assertIn("approval required", lines)
    self.assertIn("  tool    agent", lines)


class TestWebTools(unittest.TestCase):
  def test_browser_headers_include_user_agent_and_allow_overrides(self):
    headers = _browser_headers({"user-agent": "custom-agent", "X-Test": "1"})

    self.assertEqual(headers["user-agent"], "custom-agent")
    self.assertEqual(headers["X-Test"], "1")
    self.assertIn("Accept", headers)
    self.assertNotIn("User-Agent", headers)

  def test_http_read_uses_browser_headers(self):
    captured = {}

    class FakeResponse:
      url = "https://example.com"
      status_code = 200
      headers = {"Content-Type": "text/html; charset=utf-8"}
      text = "<html><head><title>Example</title></head><body>Hello</body></html>"

      def raise_for_status(self):
        pass

    class FakeRequests:
      class RequestException(Exception):
        pass

      @staticmethod
      def get(url, headers, timeout):
        captured["url"] = url
        captured["headers"] = headers
        captured["timeout"] = timeout
        return FakeResponse()

    with patch.dict(sys.modules, {"requests": FakeRequests}):
      result = ToolHttpRead().run({"url": "https://example.com"}, None)

    self.assertEqual(result["title"], "Example")
    self.assertEqual(result["text"], "Hello")
    self.assertIn("Mozilla/5.0", captured["headers"]["User-Agent"])
    self.assertIn("text/html", captured["headers"]["Accept"])

  def test_html_to_text_skips_script_and_style_content(self):
    html = """
    <html>
      <head>
        <title>Example</title>
        <style>.hidden { display: none; }</style>
        <script>console.log("ignore me")</script>
      </head>
      <body>
        <h1>Docs</h1>
        <p>Read <b>this</b> page.</p>
      </body>
    </html>
    """

    text = _html_to_text(html)

    self.assertIn("Docs", text)
    self.assertIn("Read this page.", text)
    self.assertNotIn("ignore me", text)
    self.assertNotIn("display: none", text)

  def test_parse_duckduckgo_results_extracts_title_url_and_snippet(self):
    html = """
    <html>
      <body>
        <a class="result__a" href="https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fdocs">Example Docs</a>
        <a class="result__snippet">Helpful guide for setup.</a>
        <a class="result__a" href="https://example.com/other">Other Result</a>
        <div class="result__snippet">Another snippet</div>
      </body>
    </html>
    """

    results = _parse_duckduckgo_results(html, limit=5)

    self.assertEqual(results, [
      {
        "title": "Example Docs",
        "url": "https://example.com/docs",
        "snippet": "Helpful guide for setup.",
      },
      {
        "title": "Other Result",
        "url": "https://example.com/other",
        "snippet": "Another snippet",
      },
    ])


class TestAgentCli(unittest.TestCase):
  def test_main_cli_dispatches_agent_command(self):
    captured = {}

    def fake_run_agent_cli(provider, model, prompt, system_prompt, approve, approval_root, url, host, port, auth_token, mode, interactive, input_path, data_json):
      captured["provider"] = provider
      captured["model"] = model
      captured["prompt"] = prompt
      captured["system_prompt"] = system_prompt
      captured["approve"] = approve
      captured["approval_root"] = approval_root
      captured["url"] = url
      captured["host"] = host
      captured["port"] = port
      captured["auth_token"] = auth_token
      captured["mode"] = mode
      captured["interactive"] = interactive
      captured["input_path"] = input_path
      captured["data_json"] = data_json

    argv = [
      "sciveo",
      "agent",
      "--provider", "auto",
      "--model", "demo-model",
      "--prompt", "hello world",
      "--system-prompt", "be careful",
      "--approve", "all",
      "--approval-root", "/tmp/agent-root",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.console.run_agent_cli", side_effect=fake_run_agent_cli):
          cli.main()

    self.assertEqual(captured, {
      "provider": "auto",
      "model": "demo-model",
      "prompt": "hello world",
      "system_prompt": "be careful",
      "approve": "all",
      "approval_root": "/tmp/agent-root",
      "url": None,
      "host": None,
      "port": 22,
      "auth_token": None,
      "mode": None,
      "interactive": None,
      "input_path": None,
      "data_json": {},
    })

  def test_main_cli_dispatches_agent_mode(self):
    captured = {}

    def fake_run_agent_cli(**kwargs):
      captured.update(kwargs)

    argv = [
      "sciveo",
      "agent",
      "--prompt", "hello",
      "--mode", "batch",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.console.run_agent_cli", side_effect=fake_run_agent_cli):
          cli.main()

    self.assertEqual(captured["mode"], "batch")

  def test_main_cli_dispatches_agent_interactive_flag(self):
    captured = {}

    def fake_run_agent_cli(**kwargs):
      captured.update(kwargs)

    argv = [
      "sciveo",
      "agent",
      "--prompt", "hello",
      "--interactive", "0",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.console.run_agent_cli", side_effect=fake_run_agent_cli):
          cli.main()

    self.assertFalse(captured["interactive"])

  def test_run_agent_cli_noninteractive_prints_raw_final_output(self):
    class FakeAgent:
      def ask(self, text, reset=False):
        self.asked = (text, reset)
        return "done"

    fake_agent = FakeAgent()
    with patch("sciveo.agents.console.create_default_agent", return_value=fake_agent):
      with patch("builtins.print") as mock_print:
        output = run_agent_cli(prompt="hello", interactive=False)

    self.assertEqual(output, "done")
    self.assertEqual(fake_agent.asked, ("hello", False))
    mock_print.assert_called_once_with("done")

  def test_run_agent_cli_noninteractive_image_prompt_uses_direct_llm_client(self):
    class FakeLLM:
      def chat(self, messages, system_prompt=None, tools=None):
        self.called = (messages, system_prompt, tools)
        return "done"

    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 8
    fake_llm = FakeLLM()
    with tempfile.TemporaryDirectory() as tmpdir:
      path = os.path.join(tmpdir, "demo.png")
      with open(path, "wb") as fp:
        fp.write(png_bytes)

      with patch("sciveo.agents.console.create_llm_client", return_value=fake_llm) as mock_client:
        with patch("sciveo.agents.console.create_default_agent") as mock_agent:
          with patch("builtins.print"):
            output = run_agent_cli(prompt="hello", interactive=False, input_path=path)

    self.assertEqual(output, "done")
    mock_client.assert_called_once()
    mock_agent.assert_not_called()
    self.assertEqual(fake_llm.called[0][0]["role"], "user")
    self.assertEqual(fake_llm.called[0][0]["content"][0]["text"], "hello")
    self.assertEqual(fake_llm.called[0][0]["content"][1]["name"], "demo.png")

  def test_run_agent_cli_noninteractive_direct_mode_uses_direct_llm_client(self):
    class FakeLLM:
      def chat(self, messages, system_prompt=None, tools=None):
        self.called = (messages, system_prompt, tools)
        return "done"

    fake_llm = FakeLLM()
    with patch("sciveo.agents.console.create_llm_client", return_value=fake_llm) as mock_client:
      with patch("sciveo.agents.console.create_default_agent") as mock_agent:
        with patch("builtins.print"):
          output = run_agent_cli(prompt="hello", interactive=False, mode="direct")

    self.assertEqual(output, "done")
    mock_client.assert_called_once()
    mock_agent.assert_not_called()
    self.assertEqual(fake_llm.called[0], [{"role": "user", "content": "hello"}])

  def test_run_agent_cli_batch_prompt_prints_elapsed_time(self):
    class FakeAgent:
      def ask(self, text, reset=False):
        self.asked = (text, reset)
        self.activity_callback("llm_start", {"round": 1}, self)
        self.activity_callback("llm_end", {"round": 1, "metrics": {"request_seconds": 2.5}}, self)
        return "done"

    fake_agent = FakeAgent()
    buffer = io.StringIO()
    with patch("sciveo.agents.console.create_default_agent", return_value=fake_agent):
      with redirect_stdout(buffer):
        output = run_agent_cli(prompt="hello", mode="batch")

    printed = buffer.getvalue()
    self.assertEqual(output, "done")
    self.assertEqual(fake_agent.asked, ("hello", False))
    self.assertIn("thought complete  took 2.50 seconds", printed)

  def test_create_llm_client_auto_prefers_openai(self):
    fake_client = SimpleNamespace(model="gpt-5.4")

    with patch.dict(os.environ, {
      "OPENAI_API_KEY": "openai-key",
      "ANTHROPIC_API_KEY": "anthropic-key",
    }, clear=False):
      with patch("sciveo.agents.clients.openai.OpenAIClient", return_value=fake_client) as mock_openai:
        llm = create_llm_client(provider="auto")

    mock_openai.assert_called_once_with(
      api_key="openai-key",
      model="gpt-5.4",
      base_url=None,
    )
    self.assertEqual(llm.provider, "openai")

  def test_create_llm_client_supports_hf_and_local_alias(self):
    fake_client = SimpleNamespace(model="demo")

    with patch("sciveo.agents.clients.hf.HuggingFaceRuntimeClient", return_value=fake_client) as mock_hf:
      llm = create_llm_client(
        provider="local",
        model="demo",
        url="http://127.0.0.1:9999",
        auth_token="secret",
      )

    mock_hf.assert_called_once_with(
      base_url="http://127.0.0.1:9999",
      model="demo",
      auth_token="secret",
      stream=True,
    )
    self.assertEqual(llm.provider, "hf")

  def test_create_llm_client_uses_batch_mode_for_hf_when_requested(self):
    fake_client = SimpleNamespace(model="demo")

    with patch("sciveo.agents.clients.hf.HuggingFaceRuntimeClient", return_value=fake_client) as mock_hf:
      create_llm_client(
        provider="hf",
        model="demo",
        mode="batch",
      )

    mock_hf.assert_called_once_with(
      base_url="http://127.0.0.1:8910",
      model="demo",
      auth_token=None,
      stream=False,
    )

  def test_create_llm_client_supports_ollama_typo_alias(self):
    fake_client = SimpleNamespace(model="demo")

    with patch("sciveo.agents.clients.ollama.OllamaClient", return_value=fake_client) as mock_ollama:
      llm = create_llm_client(
        provider="olama",
        model="demo",
        host="192.168.1.10",
        port=1234,
      )

    mock_ollama.assert_called_once_with(
      base_url="http://192.168.1.10:1234",
      model="demo",
    )
    self.assertEqual(llm.provider, "ollama")

  def test_provider_base_url_precedence(self):
    self.assertEqual(
      _resolve_llm_base_url("hf", url="http://demo:1", host="ignored", port=1234),
      "http://demo:1",
    )
    self.assertEqual(
      _resolve_llm_base_url("hf", host="demo.local", port=1234),
      "http://demo.local:1234",
    )
    self.assertEqual(
      _resolve_llm_base_url("hf"),
      "http://127.0.0.1:8910",
    )

  def test_create_llm_client_rejects_custom_endpoint_for_non_http_provider(self):
    with self.assertRaises(RuntimeError):
      create_llm_client(provider="anthropic", url="http://localhost:9999")

  def test_main_cli_dispatches_agent_pull(self):
    captured = {}

    def fake_pull_model(model, alias, file, mmproj_file):
      captured["model"] = model
      captured["alias"] = alias
      captured["file"] = file
      captured["mmproj_file"] = mmproj_file
      return {"alias": alias, "model": model, "file": file}

    argv = [
      "sciveo",
      "agent",
      "--action", "pull",
      "--model", "Qwen/Qwen2.5-Coder-3B-Instruct",
      "--alias", "qwen-coder-3b",
      "--file", "model.gguf",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.runtime.pull_model", side_effect=fake_pull_model):
          cli.main()

    self.assertEqual(captured, {
      "model": "Qwen/Qwen2.5-Coder-3B-Instruct",
      "alias": "qwen-coder-3b",
      "file": "model.gguf",
      "mmproj_file": None,
    })

  def test_main_cli_dispatches_agent_pull_mmproj_from_data_json(self):
    captured = {}

    def fake_pull_model(model, alias, file, mmproj_file):
      captured["model"] = model
      captured["alias"] = alias
      captured["file"] = file
      captured["mmproj_file"] = mmproj_file
      return captured

    argv = [
      "sciveo",
      "agent",
      "--action", "pull",
      "--model", "some/vlm-gguf",
      "--file", "model-q4.gguf",
      "--data-json", '{"mmproj_file":"mmproj-model.gguf"}',
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.runtime.pull_model", side_effect=fake_pull_model):
          cli.main()

    self.assertEqual(captured["mmproj_file"], "mmproj-model.gguf")

  def test_main_cli_dispatches_agent_run(self):
    captured = {}

    def fake_run_hf_runtime_server(model, host, port, auth_token, device, context):
      captured["model"] = model
      captured["host"] = host
      captured["port"] = port
      captured["auth_token"] = auth_token
      captured["device"] = device
      captured["context"] = context

    argv = [
      "sciveo",
      "agent",
      "--action", "run",
      "--model", "qwen-coder-3b",
      "--host", "0.0.0.0",
      "--port", "9999",
      "--auth", "secret",
      "--device", "mps",
      "--context", "8192",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.runtime.run_hf_runtime_server", side_effect=fake_run_hf_runtime_server):
          cli.main()

    self.assertEqual(captured, {
      "model": "qwen-coder-3b",
      "host": "0.0.0.0",
      "port": 9999,
      "auth_token": "secret",
      "device": "mps",
      "context": 8192,
    })

  def test_main_cli_dispatches_agent_models(self):
    argv = [
      "sciveo",
      "agent",
      "--action", "models",
    ]

    with patch.object(sys, "argv", argv):
      with patch("sciveo.cli.GlobalConfiguration.get", return_value=FakeConfig()):
        with patch("sciveo.agents.runtime.list_models", return_value=[{"alias": "demo"}]) as mock_models:
          cli.main()

    mock_models.assert_called_once_with()


class TestAgentRuntime(unittest.TestCase):
  def test_pull_model_writes_manifest_with_snapshot_path(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      snapshot_path = os.path.join(tmpdir, "snapshot")
      with patch("sciveo.agents.runtime._snapshot_download", return_value=snapshot_path) as mock_download:
        manifest = pull_model(
          model="Qwen/Qwen2.5-Coder-3B-Instruct",
          alias="qwen-coder-3b",
          base_path=tmpdir,
          token="hf-token",
        )

      mock_download.assert_called_once()
      self.assertEqual(manifest["alias"], "qwen-coder-3b")
      self.assertEqual(manifest["model"], "Qwen/Qwen2.5-Coder-3B-Instruct")
      self.assertEqual(manifest["local_path"], snapshot_path)
      self.assertTrue(os.path.isfile(manifest["manifest_path"]))

  def test_pull_model_can_download_single_file_pattern(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      snapshot_path = os.path.join(tmpdir, "snapshot")
      with patch("sciveo.agents.runtime._snapshot_download", return_value=snapshot_path) as mock_download:
        manifest = pull_model(
          model="unsloth/Qwen3.5-4B-GGUF",
          alias="qwen3.5-4b-q4",
          base_path=tmpdir,
          file="Qwen3.5-4B-Q4_K_M.gguf",
        )

      mock_download.assert_called_once()
      self.assertEqual(
        mock_download.call_args.kwargs["allow_patterns"],
        ["Qwen3.5-4B-Q4_K_M.gguf"],
      )
      self.assertEqual(manifest["file"], "Qwen3.5-4B-Q4_K_M.gguf")

  def test_pull_model_can_download_model_and_mmproj_patterns(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      snapshot_path = os.path.join(tmpdir, "snapshot")
      with patch("sciveo.agents.runtime._snapshot_download", return_value=snapshot_path) as mock_download:
        manifest = pull_model(
          model="some/vlm-gguf",
          alias="vlm-q4",
          base_path=tmpdir,
          file="model-q4.gguf",
          mmproj_file="mmproj-model.gguf",
        )

      self.assertEqual(mock_download.call_args.kwargs["allow_patterns"], ["model-q4.gguf", "mmproj-model.gguf"])
      self.assertEqual(manifest["mmproj_file"], "mmproj-model.gguf")
      self.assertTrue(manifest["vision"])

  def test_hf_runtime_uses_chat_template_and_generates_text(self):
    captured = {}

    class FakeTokenizer:
      def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True):
        captured["messages"] = messages
        captured["tokenize"] = tokenize
        captured["add_generation_prompt"] = add_generation_prompt
        return "PROMPT"

      def __call__(self, prompt, return_tensors):
        captured["prompt"] = prompt
        return {"input_ids": [[1, 2]]}

      def decode(self, output_ids, skip_special_tokens=True):
        captured["output_ids"] = list(output_ids)
        return "done"

    class FakeModel:
      device = None

      def eval(self):
        captured["eval"] = True

      def generate(self, **kwargs):
        captured["generate_kwargs"] = kwargs
        return [[1, 2, 3, 4]]

    class FakeAutoTokenizer:
      @staticmethod
      def from_pretrained(model_path, trust_remote_code):
        captured["tokenizer_model_path"] = model_path
        return FakeTokenizer()

    class FakeAutoModel:
      @staticmethod
      def from_pretrained(model_path, **kwargs):
        captured["model_path"] = model_path
        captured["model_kwargs"] = kwargs
        return FakeModel()

    with patch("sciveo.agents.runtime._load_transformer_classes", return_value=(None, FakeAutoTokenizer, FakeAutoModel)):
      runtime = HuggingFaceLocalRuntime(model="demo-model", device="cpu")
      result = runtime.generate(
        messages=[{"role": "user", "content": "hello"}],
        system_prompt="be brief",
        max_new_tokens=8,
        temperature=0,
      )

    self.assertEqual(result, "done")
    self.assertEqual(captured["messages"][0], {"role": "system", "content": "be brief"})
    self.assertEqual(captured["prompt"], "PROMPT")
    self.assertEqual(captured["output_ids"], [3, 4])
    self.assertEqual(captured["generate_kwargs"]["max_new_tokens"], 8)

  def test_find_gguf_file_prefers_largest_non_mmproj_file(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      small_path = os.path.join(tmpdir, "model-q4.gguf")
      large_path = os.path.join(tmpdir, "nested", "model-q8.gguf")
      mmproj_path = os.path.join(tmpdir, "mmproj-model.gguf")
      os.makedirs(os.path.dirname(large_path))
      with open(small_path, "wb") as fp:
        fp.write(b"small")
      with open(large_path, "wb") as fp:
        fp.write(b"larger model file")
      with open(mmproj_path, "wb") as fp:
        fp.write(b"very large but not the language model" * 10)

      self.assertEqual(_find_gguf_file(tmpdir), large_path)

  def test_hf_runtime_uses_llama_cpp_for_gguf_model(self):
    captured = {}

    class FakeLlama:
      def __init__(self, **kwargs):
        captured["llama_kwargs"] = kwargs

      def tokenize(self, data, add_bos=False):
        captured.setdefault("tokenize_calls", []).append((data, add_bos))
        return [1, 2, 3]

      def create_chat_completion(self, **kwargs):
        captured["completion_kwargs"] = kwargs
        return {
          "choices": [{"message": {"content": "done"}}],
          "usage": {"prompt_tokens": 5, "completion_tokens": 2},
        }

    with tempfile.TemporaryDirectory() as tmpdir:
      gguf_path = os.path.join(tmpdir, "model.gguf")
      with open(gguf_path, "wb") as fp:
        fp.write(b"gguf")

      with patch.dict(sys.modules, {"llama_cpp": SimpleNamespace(Llama=FakeLlama)}):
        runtime = HuggingFaceLocalRuntime(model=tmpdir, device="mps", context=8192)
        result = runtime.generate_with_metrics(
          messages=[{"role": "user", "content": "hello"}],
          system_prompt="be brief",
          max_new_tokens=8,
          temperature=0,
        )

    self.assertEqual(result["text"], "done")
    self.assertEqual(result["metrics"]["backend"], "gguf")
    self.assertEqual(result["metrics"]["input_tokens"], 5)
    self.assertEqual(result["metrics"]["output_tokens"], 2)
    self.assertEqual(captured["llama_kwargs"]["model_path"], gguf_path)
    self.assertEqual(captured["llama_kwargs"]["n_ctx"], 8192)
    self.assertEqual(captured["llama_kwargs"]["n_gpu_layers"], -1)
    self.assertEqual(captured["completion_kwargs"]["max_tokens"], 8)
    self.assertFalse(captured["completion_kwargs"]["stream"])
    self.assertEqual(captured["completion_kwargs"]["messages"][0], {"role": "system", "content": "be brief"})

  def test_hf_runtime_rejects_gguf_images_without_mmproj(self):
    with tempfile.TemporaryDirectory() as tmpdir:
      gguf_path = os.path.join(tmpdir, "model.gguf")
      with open(gguf_path, "wb") as fp:
        fp.write(b"gguf")

      runtime = HuggingFaceLocalRuntime(model=tmpdir, device="cpu")
      with self.assertRaisesRegex(RuntimeError, "mmproj_file"):
        runtime.generate_with_metrics(
          messages=[{"role": "user", "content": [
            {"type": "text", "text": "describe"},
            {"type": "image", "mime_type": "image/png", "data": "iVBORw0KGgo=", "name": "demo.png"},
          ]}],
          max_new_tokens=8,
          temperature=0,
        )

  def test_hf_runtime_passes_mmproj_to_llama_cpp_for_gguf_images(self):
    captured = {}

    class FakeLlava15ChatHandler:
      def __init__(self, clip_model_path):
        captured["clip_model_path"] = clip_model_path

    class FakeLlama:
      def __init__(self, **kwargs):
        captured["llama_kwargs"] = kwargs

      def tokenize(self, data, add_bos=False):
        return [1, 2]

      def create_chat_completion(self, **kwargs):
        captured["completion_kwargs"] = kwargs
        return {
          "choices": [{"message": {"content": "seen"}}],
          "usage": {"prompt_tokens": 3, "completion_tokens": 1},
        }

    with tempfile.TemporaryDirectory() as tmpdir:
      snapshot_path = os.path.join(tmpdir, "snapshot")
      os.makedirs(snapshot_path)
      gguf_path = os.path.join(snapshot_path, "model.gguf")
      mmproj_path = os.path.join(snapshot_path, "mmproj.gguf")
      with open(gguf_path, "wb") as fp:
        fp.write(b"gguf")
      with open(mmproj_path, "wb") as fp:
        fp.write(b"mmproj")
      with patch("sciveo.agents.runtime._snapshot_download", return_value=snapshot_path):
        pull_model("some/vlm", alias="vlm", base_path=tmpdir, file="model.gguf", mmproj_file="mmproj.gguf")

      module = SimpleNamespace(Llama=FakeLlama, Llava15ChatHandler=FakeLlava15ChatHandler)
      with patch.dict(sys.modules, {"llama_cpp": module}):
        runtime = HuggingFaceLocalRuntime(model="vlm", base_path=tmpdir, device="cpu")
        result = runtime.generate_with_metrics(
          messages=[{"role": "user", "content": [
            {"type": "text", "text": "describe"},
            {"type": "image", "mime_type": "image/png", "data": "iVBORw0KGgo=", "name": "demo.png"},
          ]}],
          max_new_tokens=8,
          temperature=0,
        )

    self.assertEqual(result["text"], "seen")
    self.assertEqual(captured["clip_model_path"], mmproj_path)
    self.assertIn("chat_handler", captured["llama_kwargs"])
    self.assertEqual(captured["completion_kwargs"]["messages"][0]["content"][0]["type"], "image_url")
    self.assertEqual(captured["completion_kwargs"]["messages"][0]["content"][1]["type"], "text")
    self.assertEqual(result["metrics"]["image_count"], 1)
    self.assertEqual(result["metrics"]["reported_input_tokens"], 3)

  def test_hf_runtime_uses_qwen_vision_handler_from_chat_format(self):
    captured = {}

    class FakeQwen25VLChatHandler:
      def __init__(self, clip_model_path):
        captured["clip_model_path"] = clip_model_path
        captured["handler"] = "qwen"

    class FakeLlama:
      def __init__(self, **kwargs):
        captured["llama_kwargs"] = kwargs

      def tokenize(self, data, add_bos=False):
        return [1, 2]

      def create_chat_completion(self, **kwargs):
        captured["completion_kwargs"] = kwargs
        return {
          "choices": [{"message": {"content": "seen"}}],
          "usage": {"prompt_tokens": 3, "completion_tokens": 1},
        }

    with tempfile.TemporaryDirectory() as tmpdir:
      snapshot_path = os.path.join(tmpdir, "snapshot")
      os.makedirs(snapshot_path)
      gguf_path = os.path.join(snapshot_path, "model.gguf")
      mmproj_path = os.path.join(snapshot_path, "mmproj.gguf")
      with open(gguf_path, "wb") as fp:
        fp.write(b"gguf")
      with open(mmproj_path, "wb") as fp:
        fp.write(b"mmproj")
      with patch("sciveo.agents.runtime._snapshot_download", return_value=snapshot_path):
        pull_model(
          "unsloth/Qwen3.5-4B-GGUF",
          alias="qwen3.5-4b-q4",
          base_path=tmpdir,
          file="model.gguf",
          mmproj_file="mmproj.gguf",
        )

      module = SimpleNamespace(
        Llama=FakeLlama,
        llama_chat_format=SimpleNamespace(Qwen25VLChatHandler=FakeQwen25VLChatHandler),
      )
      with patch.dict(sys.modules, {"llama_cpp": module}):
        runtime = HuggingFaceLocalRuntime(model="qwen3.5-4b-q4", base_path=tmpdir, device="cpu")
        result = runtime.generate_with_metrics(
          messages=[{"role": "user", "content": [
            {"type": "text", "text": "describe"},
            {"type": "image", "mime_type": "image/png", "data": "iVBORw0KGgo=", "name": "demo.png"},
          ]}],
          max_new_tokens=8,
          temperature=0,
        )

    self.assertEqual(result["text"], "seen")
    self.assertEqual(captured["handler"], "qwen")
    self.assertEqual(captured["clip_model_path"], mmproj_path)
    self.assertIn("chat_handler", captured["llama_kwargs"])
    self.assertEqual(result["metrics"]["image_count"], 1)
    self.assertEqual(result["metrics"]["gguf_image_min_tokens"], 1024)
    self.assertEqual(result["metrics"]["reported_input_tokens"], 3)
    self.assertGreaterEqual(result["metrics"]["input_tokens"], 1027)

  def test_hf_runtime_streams_llama_cpp_gguf_tokens(self):
    captured = {}

    class FakeLlama:
      def __init__(self, **kwargs):
        captured["llama_kwargs"] = kwargs

      def tokenize(self, data, add_bos=False):
        return [1]

      def create_chat_completion(self, **kwargs):
        captured["completion_kwargs"] = kwargs
        return iter([
          {"choices": [{"delta": {"content": "he"}}]},
          {"choices": [{"delta": {"content": "llo"}}]},
        ])

    with tempfile.TemporaryDirectory() as tmpdir:
      gguf_path = os.path.join(tmpdir, "model.gguf")
      with open(gguf_path, "wb") as fp:
        fp.write(b"gguf")

      with patch.dict(sys.modules, {"llama_cpp": SimpleNamespace(Llama=FakeLlama)}):
        runtime = HuggingFaceLocalRuntime(model=tmpdir, device="cpu")
        events = list(runtime.stream_with_metrics(
          messages=[{"role": "user", "content": "hello"}],
          max_new_tokens=8,
          temperature=0,
        ))

    self.assertEqual(captured["llama_kwargs"]["model_path"], gguf_path)
    self.assertEqual(captured["llama_kwargs"]["n_gpu_layers"], 0)
    self.assertTrue(captured["completion_kwargs"]["stream"])
    self.assertEqual([event["type"] for event in events], ["progress", "token", "progress", "token", "done"])
    self.assertEqual(events[1]["text"], "he")
    self.assertEqual(events[3]["text"], "llo")
    self.assertEqual(events[-1]["text"], "hello")
    self.assertEqual(events[-1]["metrics"]["backend"], "gguf")


class TestAgentHttpClients(unittest.TestCase):
  def test_openai_client_formats_assistant_history_as_output_text(self):
    captured = {}

    class FakeResponses:
      @staticmethod
      def create(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(output_text="done")

    client = OpenAIClient.__new__(OpenAIClient)
    client.client = SimpleNamespace(responses=FakeResponses())
    client.model = "gpt-test"
    client.reasoning_effort = "medium"
    client.verbosity = "low"
    client.max_output_tokens = 123

    result = client.chat(
      messages=[
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi back"},
        {"role": "user", "content": "Tool result for http_read:\n{}"},
      ],
      system_prompt="be brief",
    )

    self.assertEqual(result, "done")
    self.assertEqual(captured["input"][0]["role"], "system")
    self.assertEqual(captured["input"][0]["content"][0]["type"], "input_text")
    self.assertEqual(captured["input"][1]["role"], "user")
    self.assertEqual(captured["input"][1]["content"][0]["type"], "input_text")
    self.assertEqual(captured["input"][2]["role"], "assistant")
    self.assertEqual(captured["input"][2]["content"][0]["type"], "output_text")
    self.assertEqual(captured["input"][3]["role"], "user")
    self.assertEqual(captured["input"][3]["content"][0]["type"], "input_text")

  def test_openai_client_formats_image_parts(self):
    captured = {}

    class FakeResponses:
      @staticmethod
      def create(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(output_text="done")

    client = OpenAIClient.__new__(OpenAIClient)
    client.client = SimpleNamespace(responses=FakeResponses())
    client.model = "gpt-test"
    client.reasoning_effort = "medium"
    client.verbosity = "low"
    client.max_output_tokens = 123

    result = client.chat(
      messages=[{"role": "user", "content": [
        {"type": "text", "text": "describe"},
        {"type": "image", "mime_type": "image/png", "data": "iVBORw0KGgo=", "name": "demo.png"},
      ]}],
    )

    self.assertEqual(result, "done")
    self.assertEqual(captured["input"][0]["content"][0]["type"], "input_text")
    self.assertEqual(captured["input"][0]["content"][1]["type"], "input_image")
    self.assertTrue(captured["input"][0]["content"][1]["image_url"].startswith("data:image/png;base64,"))

  def test_hf_client_posts_chat_payload(self):
    captured = {}

    class FakeResponse:
      status_code = 200
      text = ""

      def json(self):
        return {
          "text": "done",
          "metrics": {
            "input_tokens": 2,
            "output_tokens": 1,
            "generation_tokens_per_second": 5,
          },
        }

    class FakeRequests:
      @staticmethod
      def post(url, json, headers, timeout):
        captured["url"] = url
        captured["json"] = json
        captured["headers"] = headers
        captured["timeout"] = timeout
        return FakeResponse()

    with patch.dict(sys.modules, {"requests": FakeRequests}):
      client = HuggingFaceRuntimeClient(
        base_url="http://runtime.local:8910",
        model="qwen-coder-3b",
        auth_token="secret",
        stream=False,
      )
      result = client.chat(
        messages=[{"role": "user", "content": "hello"}],
        system_prompt="be brief",
      )

    self.assertEqual(result, "done")
    self.assertEqual(captured["url"], "http://runtime.local:8910/chat")
    self.assertEqual(captured["headers"], {"Authorization": "Bearer secret"})
    self.assertEqual(captured["json"]["model"], "qwen-coder-3b")
    self.assertEqual(captured["json"]["system_prompt"], "be brief")
    self.assertEqual(captured["json"]["messages"], [{"role": "user", "content": "hello"}])
    self.assertEqual(client.last_metrics["input_tokens"], 2)
    self.assertIn("request_seconds", client.last_metrics)

  def test_hf_client_streams_chat_events(self):
    captured = {}

    class FakeResponse:
      status_code = 200
      text = ""

      def iter_lines(self, decode_unicode=True):
        events = [
          {"type": "token", "text": "he", "metrics": {"output_tokens": 1}},
          {"type": "progress", "metrics": {"generation_tokens_per_second": 5.0}},
          {"type": "token", "text": "llo", "metrics": {"output_tokens": 2}},
          {"type": "done", "text": "hello", "metrics": {"input_tokens": 2, "output_tokens": 2}},
        ]
        for event in events:
          yield json.dumps(event)

    class FakeRequests:
      @staticmethod
      def post(url, json, headers, timeout, stream):
        captured["url"] = url
        captured["json"] = json
        captured["headers"] = headers
        captured["timeout"] = timeout
        captured["stream"] = stream
        return FakeResponse()

    events = []
    with patch.dict(sys.modules, {"requests": FakeRequests}):
      client = HuggingFaceRuntimeClient(
        base_url="http://runtime.local:8910",
        model="qwen-coder-3b",
        auth_token="secret",
      )
      client.stream_callback = lambda kind, data: events.append((kind, data))
      result = client.chat(
        messages=[{"role": "user", "content": "hello"}],
        system_prompt="be brief",
      )

    self.assertEqual(result, "hello")
    self.assertEqual(captured["url"], "http://runtime.local:8910/chat/stream")
    self.assertTrue(captured["stream"])
    self.assertEqual(events[0][0], "llm_token")
    self.assertEqual(events[0][1]["text"], "he")
    self.assertEqual(events[1][0], "llm_progress")
    self.assertEqual(events[2][1]["text"], "llo")
    self.assertEqual(client.last_metrics["input_tokens"], 2)
    self.assertIn("request_seconds", client.last_metrics)

  def test_ollama_client_posts_non_streaming_chat_payload(self):
    captured = {}

    class FakeResponse:
      status_code = 200
      text = ""

      def json(self):
        return {"message": {"content": "done"}}

    class FakeRequests:
      @staticmethod
      def post(url, json, timeout):
        captured["url"] = url
        captured["json"] = json
        captured["timeout"] = timeout
        return FakeResponse()

    with patch.dict(sys.modules, {"requests": FakeRequests}):
      client = OllamaClient(base_url="http://ollama.local:11434", model="demo")
      result = client.chat(
        messages=[{"role": "user", "content": "hello"}],
        system_prompt="be brief",
      )

    self.assertEqual(result, "done")
    self.assertEqual(captured["url"], "http://ollama.local:11434/api/chat")
    self.assertFalse(captured["json"]["stream"])
    self.assertEqual(captured["json"]["model"], "demo")
    self.assertEqual(captured["json"]["messages"][0], {"role": "system", "content": "be brief"})

  def test_ollama_client_formats_image_parts(self):
    captured = {}

    class FakeResponse:
      status_code = 200
      text = ""

      def json(self):
        return {"message": {"content": "done"}}

    class FakeRequests:
      @staticmethod
      def post(url, json, timeout):
        captured["json"] = json
        return FakeResponse()

    with patch.dict(sys.modules, {"requests": FakeRequests}):
      client = OllamaClient(base_url="http://ollama.local:11434", model="demo")
      result = client.chat(
        messages=[{"role": "user", "content": [
          {"type": "text", "text": "describe"},
          {"type": "image", "mime_type": "image/png", "data": "abc", "name": "demo.png"},
        ]}],
      )

    self.assertEqual(result, "done")
    self.assertEqual(captured["json"]["messages"][0]["content"], "describe")
    self.assertEqual(captured["json"]["messages"][0]["images"], ["abc"])


class TestGeminiClient(unittest.TestCase):
  def test_chat_passes_string_prompt_to_generate_content(self):
    captured = {}

    class FakeModels:
      def generate_content(self, model, contents, config):
        captured["model"] = model
        captured["contents"] = contents
        captured["config"] = config
        return SimpleNamespace(text="hello back")

    client = GeminiClient.__new__(GeminiClient)
    client.client = SimpleNamespace(models=FakeModels())
    client.model = "gemini-2.5-flash"
    client.temperature = 0.2
    client.max_output_tokens = 4096

    result = client.chat(
      messages=[{"role": "user", "content": "what are you?"}],
      system_prompt="be concise",
    )

    self.assertEqual(result, "hello back")
    self.assertEqual(captured["model"], "gemini-2.5-flash")
    self.assertEqual(captured["contents"], "system: be concise\nuser: what are you?\n")


if __name__ == "__main__":
  unittest.main()
