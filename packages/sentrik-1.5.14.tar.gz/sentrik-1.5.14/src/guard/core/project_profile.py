"""Project profile builder — analyzes codebase to extract design constraints.

Detects frameworks, libraries, architectural patterns, ADRs, and coding
conventions. Used by the MCP ``get_design_constraints`` tool to provide
context to AI agents before they generate code.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Framework/library detection patterns
# ---------------------------------------------------------------------------

_PYTHON_FRAMEWORKS: dict[str, list[str]] = {
    "FastAPI": ["fastapi"],
    "Django": ["django"],
    "Flask": ["flask"],
    "SQLAlchemy": ["sqlalchemy"],
    "Pydantic": ["pydantic"],
    "Celery": ["celery"],
    "Pytest": ["pytest"],
    "NumPy": ["numpy"],
    "Pandas": ["pandas"],
    "PyTorch": ["torch"],
    "TensorFlow": ["tensorflow"],
    "Requests": ["requests"],
    "httpx": ["httpx"],
    "Typer": ["typer"],
    "Click": ["click"],
    "Rich": ["rich"],
    "asyncio": ["asyncio"],
    "aiohttp": ["aiohttp"],
}

_JS_FRAMEWORKS: dict[str, list[str]] = {
    "React": ["react", "react-dom"],
    "Next.js": ["next"],
    "Vue": ["vue"],
    "Express": ["express"],
    "Fastify": ["fastify"],
    "Prisma": ["@prisma/client"],
    "TypeORM": ["typeorm"],
    "Jest": ["jest"],
    "Vitest": ["vitest"],
    "Tailwind CSS": ["tailwindcss"],
}

_GO_PATTERNS: dict[str, str] = {
    "Gin": "github.com/gin-gonic/gin",
    "Echo": "github.com/labstack/echo",
    "GORM": "gorm.io/gorm",
    "Cobra": "github.com/spf13/cobra",
}

# ---------------------------------------------------------------------------
# Architectural pattern detection
# ---------------------------------------------------------------------------

_ARCH_PATTERNS: list[tuple[str, list[str]]] = [
    ("MVC", ["controller", "model", "view"]),
    ("Repository Pattern", ["repository", "repositories"]),
    ("Service Layer", ["service", "services"]),
    ("Domain-Driven Design", ["domain", "aggregate", "value_object"]),
    ("Event-Driven", ["event", "handler", "listener", "subscriber"]),
    ("Middleware", ["middleware"]),
    ("API Gateway", ["gateway", "proxy"]),
]


# ---------------------------------------------------------------------------
# Profile builder
# ---------------------------------------------------------------------------


def build_project_profile(repo_root: str) -> dict[str, Any]:
    """Analyze the codebase and return a project profile.

    The profile includes:
    - ``languages``: detected programming languages
    - ``frameworks``: frameworks and libraries in use
    - ``architecture``: detected architectural patterns
    - ``adrs``: Architecture Decision Records found
    - ``conventions``: coding conventions inferred from code
    - ``module_map``: top-level directory structure with purposes
    - ``tech_stack``: consolidated list of technologies
    """
    root = Path(repo_root)
    profile: dict[str, Any] = {
        "languages": [],
        "frameworks": [],
        "architecture": [],
        "adrs": [],
        "conventions": {},
        "module_map": [],
        "tech_stack": [],
    }

    # Detect languages
    profile["languages"] = _detect_languages(root)

    # Detect frameworks from manifests and imports
    profile["frameworks"] = _detect_frameworks(root)

    # Detect architectural patterns from directory structure
    profile["architecture"] = _detect_architecture(root)

    # Find ADRs
    profile["adrs"] = _find_adrs(root)

    # Infer conventions
    profile["conventions"] = _infer_conventions(root)

    # Build module map
    profile["module_map"] = _build_module_map(root)

    # Consolidate tech stack
    profile["tech_stack"] = (
        profile["languages"]
        + [f["name"] for f in profile["frameworks"]]
    )

    return profile


def _detect_languages(root: Path) -> list[str]:
    """Detect programming languages from file extensions."""
    ext_count: dict[str, int] = {}
    ext_lang = {
        ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
        ".go": "Go", ".rs": "Rust", ".java": "Java", ".kt": "Kotlin",
        ".rb": "Ruby", ".php": "PHP", ".cs": "C#", ".cpp": "C++",
        ".c": "C", ".swift": "Swift", ".dart": "Dart",
    }

    for f in root.rglob("*"):
        if any(skip in str(f) for skip in ("node_modules", "__pycache__", ".venv", ".git", "out/")):
            continue
        ext = f.suffix.lower()
        if ext in ext_lang:
            lang = ext_lang[ext]
            ext_count[lang] = ext_count.get(lang, 0) + 1

    return sorted(ext_count, key=ext_count.get, reverse=True)


def _detect_frameworks(root: Path) -> list[dict[str, str]]:
    """Detect frameworks from manifests and import statements."""
    frameworks = []
    seen = set()

    # Check Python requirements
    for req_file in ("requirements.txt", "pyproject.toml", "setup.cfg", "Pipfile"):
        path = root / req_file
        if path.is_file():
            try:
                content = path.read_text(encoding="utf-8", errors="replace").lower()
                for name, patterns in _PYTHON_FRAMEWORKS.items():
                    if name not in seen and any(p in content for p in patterns):
                        frameworks.append({"name": name, "source": req_file})
                        seen.add(name)
            except OSError:
                pass

    # Check package.json
    pkg_json = root / "package.json"
    if pkg_json.is_file():
        try:
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
            all_deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            for name, patterns in _JS_FRAMEWORKS.items():
                if name not in seen and any(p in all_deps for p in patterns):
                    frameworks.append({"name": name, "source": "package.json"})
                    seen.add(name)
        except (json.JSONDecodeError, OSError):
            pass

    # Check go.mod
    go_mod = root / "go.mod"
    if go_mod.is_file():
        try:
            content = go_mod.read_text(encoding="utf-8", errors="replace")
            for name, pattern in _GO_PATTERNS.items():
                if name not in seen and pattern in content:
                    frameworks.append({"name": name, "source": "go.mod"})
                    seen.add(name)
        except OSError:
            pass

    return frameworks


def _detect_architecture(root: Path) -> list[dict[str, str]]:
    """Detect architectural patterns from directory structure."""
    patterns = []
    dirs = set()
    for d in root.iterdir():
        if d.is_dir() and not d.name.startswith("."):
            dirs.add(d.name.lower())
    # Also check src/ subdirs
    src = root / "src"
    if src.is_dir():
        for d in src.iterdir():
            if d.is_dir():
                dirs.add(d.name.lower())

    for pattern_name, keywords in _ARCH_PATTERNS:
        if any(kw in dirs for kw in keywords):
            matched = [kw for kw in keywords if kw in dirs]
            patterns.append({"pattern": pattern_name, "evidence": ", ".join(matched)})

    return patterns


def _find_adrs(root: Path) -> list[dict[str, str]]:
    """Find Architecture Decision Records."""
    adrs = []
    adr_dirs = ["docs/adr", "docs/decisions", "adr", "decisions", "docs/architecture"]

    for adr_dir in adr_dirs:
        path = root / adr_dir
        if path.is_dir():
            for f in sorted(path.iterdir()):
                if f.suffix.lower() == ".md":
                    try:
                        first_line = f.read_text(encoding="utf-8", errors="replace").split("\n")[0]
                        title = first_line.lstrip("# ").strip()
                    except OSError:
                        title = f.name
                    adrs.append({"file": str(f.relative_to(root)), "title": title})

    # Also check for ADR-*.md or adr-*.md in root
    for f in root.glob("ADR-*.md"):
        adrs.append({"file": f.name, "title": f.stem})
    for f in root.glob("adr-*.md"):
        adrs.append({"file": f.name, "title": f.stem})

    return adrs


def _infer_conventions(root: Path) -> dict[str, Any]:
    """Infer coding conventions from existing code."""
    conventions: dict[str, Any] = {}

    # Check for convention files
    for name in ("CONVENTIONS.md", "CONTRIBUTING.md", ".editorconfig", ".prettierrc", ".eslintrc"):
        if (root / name).is_file():
            conventions["convention_files"] = conventions.get("convention_files", [])
            conventions["convention_files"].append(name)

    # Infer Python style
    py_files = list(root.rglob("*.py"))
    py_files = [f for f in py_files if "node_modules" not in str(f)
                and "__pycache__" not in str(f) and ".venv" not in str(f)][:50]

    if py_files:
        uses_type_hints = 0
        uses_docstrings = 0
        for f in py_files[:20]:
            try:
                content = f.read_text(encoding="utf-8", errors="replace")
                if "->" in content or ": str" in content or ": int" in content:
                    uses_type_hints += 1
                if '"""' in content or "'''" in content:
                    uses_docstrings += 1
            except OSError:
                pass
        if uses_type_hints > len(py_files[:20]) // 2:
            conventions["type_hints"] = "widely used"
        if uses_docstrings > len(py_files[:20]) // 2:
            conventions["docstrings"] = "widely used"
        conventions["naming"] = "snake_case"  # Python convention

    return conventions


def _build_module_map(root: Path) -> list[dict[str, str]]:
    """Map top-level directories to their purposes."""
    module_map = []

    known_dirs = {
        "src": "Source code",
        "lib": "Library code",
        "app": "Application code",
        "api": "API endpoints",
        "tests": "Test suite",
        "test": "Test suite",
        "docs": "Documentation",
        "scripts": "Build/utility scripts",
        "config": "Configuration files",
        "migrations": "Database migrations",
        "static": "Static assets",
        "public": "Public assets",
        "templates": "HTML templates",
    }

    for d in sorted(root.iterdir()):
        if d.is_dir() and not d.name.startswith(".") and d.name not in ("node_modules", "__pycache__", "out", ".venv", "dist", "build"):
            purpose = known_dirs.get(d.name.lower(), "")
            file_count = sum(1 for _ in d.rglob("*") if _.is_file())
            if file_count > 0:
                module_map.append({
                    "directory": d.name,
                    "purpose": purpose,
                    "files": file_count,
                })

    return module_map


def get_design_constraints(
    profile: dict[str, Any],
    file_path: str | None = None,
    intent: str | None = None,
) -> dict[str, Any]:
    """Return design constraints relevant to a specific file or intent.

    Used by the MCP tool to provide context to AI agents.
    """
    constraints: dict[str, Any] = {
        "tech_stack": profile.get("tech_stack", []),
        "established_patterns": [],
        "architectural_rules": profile.get("architecture", []),
        "adrs": profile.get("adrs", []),
        "conventions": profile.get("conventions", {}),
    }

    # Add framework-specific guidance
    frameworks = {f["name"] for f in profile.get("frameworks", [])}

    if file_path:
        # Provide context based on where the file is
        parts = Path(file_path).parts
        if any(p in ("api", "routes", "endpoints", "views") for p in parts):
            if "FastAPI" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses FastAPI for API endpoints. Use APIRouter, Depends for DI, and Pydantic models for request/response."
                )
            elif "Express" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses Express.js. Use Router, middleware pattern, and async error handling."
                )
            elif "Django" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses Django. Use class-based views or DRF serializers for API endpoints."
                )

        if any(p in ("db", "database", "repositories", "models") for p in parts):
            if "SQLAlchemy" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses SQLAlchemy for database access. Use the existing session pattern and declarative models."
                )
            elif "Prisma" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses Prisma. Use the Prisma client for all database operations."
                )

        if any(p in ("test", "tests") for p in parts):
            if "Pytest" in frameworks:
                constraints["established_patterns"].append(
                    "This project uses pytest. Use fixtures, parametrize, and the existing conftest.py patterns."
                )

    if intent:
        intent_lower = intent.lower()
        if "auth" in intent_lower:
            constraints["established_patterns"].append(
                "Check existing auth patterns in the codebase before implementing authentication."
            )
        if "database" in intent_lower or "migration" in intent_lower:
            constraints["established_patterns"].append(
                "Use the project's established ORM/database library. Do not introduce a new one."
            )
        if "test" in intent_lower:
            constraints["established_patterns"].append(
                "Follow the existing test file naming and structure conventions."
            )

    # Tech stack lock warnings
    constraints["tech_stack_warnings"] = []
    if frameworks:
        constraints["tech_stack_warnings"].append(
            f"This project uses: {', '.join(f['name'] for f in profile.get('frameworks', []))}. "
            f"Do not introduce conflicting frameworks."
        )

    return constraints


def save_profile(profile: dict[str, Any], output_dir: str = "out") -> Path:
    """Save profile to out/project-profile.json."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "project-profile.json"
    path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    return path


def load_profile(output_dir: str = "out") -> dict[str, Any] | None:
    """Load cached profile from out/project-profile.json."""
    path = Path(output_dir) / "project-profile.json"
    if path.is_file():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None
