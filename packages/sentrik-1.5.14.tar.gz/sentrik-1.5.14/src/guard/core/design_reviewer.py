"""Design Decision Auditing — surface implicit design decisions in AI-generated code.

Uses LLM analysis to identify significant design decisions (framework choices,
data structures, auth patterns, API design tradeoffs) and present them as
questions for developer review rather than pass/fail findings.
"""

from __future__ import annotations

import json
import logging
import subprocess
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from guard.core.project_profile import load_profile
from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_CATEGORIES = [
    "architecture",
    "data-model",
    "security-pattern",
    "dependency-choice",
    "performance-tradeoff",
    "error-handling",
    "state-management",
]

_REVIEW_PROMPT = """\
You are a senior software architect reviewing code changes. Identify significant \
design decisions — choices that a thoughtful engineer would want to consciously \
make rather than accept from AI-generated code.

Focus on decisions that:
- Choose one approach over reasonable alternatives
- Have implications at scale or over time
- Affect security, performance, or maintainability
- Introduce new patterns not established in the project

Do NOT flag:
- Trivial formatting or naming choices
- Standard library usage
- Obvious best practices

PROJECT CONTEXT:
{project_context}

CODE CHANGES:
{code_changes}

Return ONLY valid JSON:
{{
  "decisions": [
    {{
      "category": "architecture|data-model|security-pattern|dependency-choice|performance-tradeoff|error-handling|state-management",
      "summary": "One-line description of the decision",
      "file": "path/to/file.py",
      "line_start": 10,
      "line_end": 25,
      "alternatives": ["Alternative approach 1", "Alternative approach 2"],
      "risk": "What could go wrong with this choice at scale or over time",
      "question": "A specific question to prompt developer review"
    }}
  ]
}}

If no significant decisions are found, return {{"decisions": []}}.
"""


@dataclass
class DesignDecision:
    decision_id: str
    category: str
    summary: str
    file: str
    line_start: int = 0
    line_end: int = 0
    alternatives: list[str] = field(default_factory=list)
    risk: str = ""
    question: str = ""
    acknowledged: bool = False
    acknowledgment_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "category": self.category,
            "summary": self.summary,
            "file": self.file,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "alternatives": self.alternatives,
            "risk": self.risk,
            "question": self.question,
            "acknowledged": self.acknowledged,
            "acknowledgment_note": self.acknowledgment_note,
        }


_MAX_DIFF_BYTES = 50_000


def get_diff(git_range: str | None = None, file_path: str | None = None, repo_root: str = ".") -> str:
    """Get code changes as a diff string."""
    if file_path:
        path = Path(repo_root) / file_path
        if path.is_file():
            return f"--- {file_path} ---\n{path.read_text(encoding='utf-8', errors='replace')}"
        return ""

    if git_range:
        try:
            result = subprocess.run(
                ["git", "diff", git_range],
                capture_output=True, text=True, timeout=15, cwd=repo_root,
            )
            if result.returncode == 0:
                diff = result.stdout
                if len(diff.encode()) > _MAX_DIFF_BYTES:
                    diff = diff[:_MAX_DIFF_BYTES] + "\n... (truncated)"
                return diff
        except (OSError, subprocess.TimeoutExpired):
            pass

    # Default: staged changes
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, timeout=15, cwd=repo_root,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout[:_MAX_DIFF_BYTES]
    except (OSError, subprocess.TimeoutExpired):
        pass

    # Fallback: unstaged changes
    try:
        result = subprocess.run(
            ["git", "diff"],
            capture_output=True, text=True, timeout=15, cwd=repo_root,
        )
        if result.returncode == 0:
            return result.stdout[:_MAX_DIFF_BYTES]
    except (OSError, subprocess.TimeoutExpired):
        pass

    return ""


def review_design(
    llm: LLMProvider,
    code_changes: str,
    output_dir: str = "out",
    repo_root: str = ".",
) -> list[DesignDecision]:
    """Analyze code changes for design decisions using LLM."""
    if not code_changes.strip():
        return []

    # Build project context
    profile = load_profile(output_dir)
    if profile:
        ctx_parts = []
        if profile.get("frameworks"):
            ctx_parts.append(f"Frameworks: {', '.join(f['name'] for f in profile['frameworks'])}")
        if profile.get("architecture"):
            ctx_parts.append(f"Patterns: {', '.join(p['pattern'] for p in profile['architecture'])}")
        if profile.get("conventions"):
            ctx_parts.append(f"Conventions: {json.dumps(profile['conventions'])}")
        project_context = "\n".join(ctx_parts) or "No project profile available."
    else:
        project_context = "No project profile available. Run 'sentrik profile' to build one."

    prompt = _REVIEW_PROMPT.format(
        project_context=project_context,
        code_changes=code_changes,
    )

    try:
        response = llm.analyze(prompt, {"type": "design_review"})
        return _parse_response(response)
    except Exception as exc:
        logger.warning("Design review failed: %s", exc)
        return []


def _parse_response(response: dict[str, Any]) -> list[DesignDecision]:
    """Parse LLM response into DesignDecision objects."""
    data = response
    if "summary" in response and isinstance(response["summary"], str):
        try:
            data = json.loads(response["summary"])
        except (json.JSONDecodeError, TypeError):
            pass

    decisions_raw = data.get("decisions", [])
    decisions = []

    for d in decisions_raw:
        if not isinstance(d, dict):
            continue
        category = d.get("category", "architecture")
        if category not in _CATEGORIES:
            category = "architecture"

        decisions.append(DesignDecision(
            decision_id=f"DD-{uuid.uuid4().hex[:6].upper()}",
            category=category,
            summary=d.get("summary", "Design decision detected"),
            file=d.get("file", ""),
            line_start=d.get("line_start", 0),
            line_end=d.get("line_end", 0),
            alternatives=d.get("alternatives", []),
            risk=d.get("risk", ""),
            question=d.get("question", ""),
        ))

    return decisions


def format_decisions(decisions: list[DesignDecision]) -> str:
    """Format design decisions as human-readable text."""
    if not decisions:
        return "\nNo significant design decisions detected.\n"

    lines = [f"\n{len(decisions)} design decision(s) found:\n"]

    for i, d in enumerate(decisions, 1):
        lines.append(f"  {i}. [{d.category.upper()}] {d.summary}")
        if d.file:
            loc = d.file
            if d.line_start:
                loc += f":{d.line_start}"
                if d.line_end and d.line_end != d.line_start:
                    loc += f"-{d.line_end}"
            lines.append(f"     File: {loc}")
        if d.alternatives:
            lines.append(f"     Alternatives:")
            for alt in d.alternatives:
                lines.append(f"       - {alt}")
        if d.risk:
            lines.append(f"     Risk: {d.risk}")
        if d.question:
            lines.append(f"     ? {d.question}")
        lines.append("")

    return "\n".join(lines)


def save_decisions(decisions: list[DesignDecision], output_dir: str = "out") -> Path:
    """Save decisions to out/design_decisions.json."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "design_decisions.json"
    data = [d.to_dict() for d in decisions]
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_decisions(output_dir: str = "out") -> list[DesignDecision]:
    """Load decisions from out/design_decisions.json."""
    path = Path(output_dir) / "design_decisions.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return [DesignDecision(**d) for d in data]
    except (json.JSONDecodeError, OSError, TypeError):
        return []


def acknowledge_decision(
    decision_id: str,
    note: str = "",
    output_dir: str = "out",
) -> bool:
    """Mark a decision as acknowledged."""
    decisions = load_decisions(output_dir)
    for d in decisions:
        if d.decision_id == decision_id:
            d.acknowledged = True
            d.acknowledgment_note = note
            save_decisions(decisions, output_dir)
            return True
    return False
