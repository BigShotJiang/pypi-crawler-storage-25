from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Dict, List, Optional

from datahub.api.entities.dataprocess.dataprocess_instance import (
    DataProcessInstance,
    InstanceRunResult,
)
from datahub.metadata.schema_classes import DataProcessTypeClass

from aileron_datahub_manager.exceptions import InvalidEntityError, ProcessInstanceError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)

# 사용자 문자열 → InstanceRunResult 매핑
_RESULT_MAP: Dict[str, InstanceRunResult] = {
    "SUCCESS": InstanceRunResult.SUCCESS,
    "FAILURE": InstanceRunResult.FAILURE,
    "SKIPPED": InstanceRunResult.SKIPPED,
    "UP_FOR_RETRY": InstanceRunResult.UP_FOR_RETRY,
}

# 사용자 문자열 → DataProcessTypeClass 매핑
_TYPE_MAP: Dict[str, str] = {
    "BATCH_SCHEDULED": DataProcessTypeClass.BATCH_SCHEDULED,
    "BATCH_AD_HOC": DataProcessTypeClass.BATCH_AD_HOC,
    "STREAMING": DataProcessTypeClass.STREAMING,
}


class ProcessInstanceManager:
    """DataProcessInstance 실행 이력 관리.

    DataJob의 실제 실행 건(런)을 등록·추적합니다.

    계층 구조::

        DataFlow (파이프라인 정의)
            └── DataJob (태스크 정의)
                    └── DataProcessInstance (실제 실행 건)

    DAG run → Task run 계층 구조::

        DataProcessInstance (DAG run)
            └── DataProcessInstance (Task run 1)  ← parent_instance_urn = DAG run URN
            └── DataProcessInstance (Task run 2)  ← parent_instance_urn = DAG run URN

    사용 예 — 실행 전후 감싸기::

        run_id = f"transform_orders__{int(time.time())}"

        manager.process_instances.emit_start(
            instance_id=run_id,
            orchestrator="aileron-pipeline",
            cluster="PROD",
            job_urn="urn:li:dataJob:(...)",
            inlets=["urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"],
            outlets=["urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_daily,PROD)"],
            silent=True,
        )
        try:
            do_transform()
            result = "SUCCESS"
        except Exception:
            result = "FAILURE"
            raise
        finally:
            manager.process_instances.emit_end(
                instance_id=run_id,
                orchestrator="aileron-pipeline",
                cluster="PROD",
                result=result,
                silent=True,
            )

    사용 예 — 완료된 실행 소급 등록::

        manager.process_instances.run(
            instance_id="transform_orders__1713312000",
            orchestrator="aileron-pipeline",
            cluster="PROD",
            result="SUCCESS",
            job_urn="urn:li:dataJob:(...)",
            inlets=[...],
            outlets=[...],
            start_timestamp_millis=1713312000000,
            end_timestamp_millis=1713312600000,
            silent=True,
        )
    """

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # URN 헬퍼
    # ------------------------------------------------------------------

    @staticmethod
    def sanitize_instance_id(instance_id: str) -> str:
        """instance_id에서 URN 예약 문자를 제거합니다.

        DataHub URN에서 사용 불가한 예약 문자: : , ( )
        해당 문자는 '_'로 자동 치환됩니다.

        Args:
            instance_id: 실행 고유 ID (원본)

        Returns:
            예약 문자가 치환된 안전한 instance_id
        """
        import re
        sanitized = re.sub(r"[:(,)]", "_", instance_id)
        if sanitized != instance_id:
            logger.warning(
                "instance_id에 URN 예약 문자가 포함되어 자동 치환되었습니다. "
                "원본: '%s' → 변환: '%s' (예약 문자: : , ( ))",
                instance_id,
                sanitized,
            )
        return sanitized

    @staticmethod
    def make_urn(instance_id: str) -> str:
        """DataProcessInstance URN을 생성합니다.

        Args:
            instance_id: 실행 고유 ID. URN 예약 문자(: , ( ))는 자동으로 '_'로 치환됩니다.

        Returns:
            urn:li:dataProcessInstance:{instance_id} 형식의 문자열
        """
        safe_id = ProcessInstanceManager.sanitize_instance_id(instance_id)
        return f"urn:li:dataProcessInstance:{safe_id}"

    # ------------------------------------------------------------------
    # 실행 시작
    # ------------------------------------------------------------------

    def emit_start(
        self,
        instance_id: str,
        orchestrator: str,
        cluster: str,
        *,
        job_urn: Optional[str] = None,
        inlets: Optional[List[str]] = None,
        outlets: Optional[List[str]] = None,
        upstream_urns: Optional[List[str]] = None,
        parent_instance_urn: Optional[str] = None,
        properties: Optional[Dict[str, str]] = None,
        process_type: str = "BATCH_SCHEDULED",
        start_timestamp_millis: Optional[int] = None,
        silent: bool = False,
    ) -> str:
        """실행 시작 이벤트를 등록합니다.

        Args:
            instance_id:             실행 고유 ID (예: dag_id__execution_date)
            orchestrator:            오케스트레이터 이름 (예: airflow, aileron-pipeline)
            cluster:                 클러스터 / 환경 이름 (예: PROD, aileron-mwaa-prod)
            job_urn:                 부모 DataJob URN
            inlets:                  이 실행에서 읽은 Dataset URN 목록
            outlets:                 이 실행에서 쓴 Dataset URN 목록
            upstream_urns:           선행 DataProcessInstance URN 목록 (의존 관계)
            parent_instance_urn:     부모 DataProcessInstance URN (계층 관계, 예: DAG run URN)
            properties:              커스텀 속성 key-value
            process_type:            실행 타입 (BATCH_SCHEDULED / BATCH_AD_HOC / STREAMING)
            start_timestamp_millis:  시작 시각 ms (기본값: 현재 시각)
            silent:                  True이면 GMS 오류 시 예외 없이 WARNING 로그만 남김

        Returns:
            DataProcessInstance URN 문자열
        """
        if not instance_id or not orchestrator:
            raise InvalidEntityError("instance_id와 orchestrator는 필수입니다.")

        instance_id = self.sanitize_instance_id(instance_id)
        urn = self.make_urn(instance_id)
        ts = start_timestamp_millis or int(time.time() * 1000)

        try:
            instance = self._build(
                instance_id=instance_id,
                orchestrator=orchestrator,
                cluster=cluster,
                job_urn=job_urn,
                inlets=inlets,
                outlets=outlets,
                upstream_urns=upstream_urns,
                parent_instance_urn=parent_instance_urn,
                properties=properties,
                process_type=process_type,
            )
            instance.emit_process_start(
                emitter=self._manager._datahub_graph,
                start_timestamp_millis=ts,
                emit_template=False,  # DataJob을 빈 상태로 재emit하여 기존 리니지를 덮어쓰는 것을 방지
            )
            logger.info("DataProcessInstance 시작 등록: %s", urn)
        except Exception as exc:
            if silent:
                logger.warning(
                    "DataProcessInstance 시작 등록 실패 (silent=True, 무시됨): %s — %s", urn, exc
                )
            else:
                raise ProcessInstanceError(
                    f"DataProcessInstance 시작 등록 실패 ({urn}): {exc}"
                ) from exc
        return urn

    # ------------------------------------------------------------------
    # 실행 종료
    # ------------------------------------------------------------------

    def emit_end(
        self,
        instance_id: str,
        orchestrator: str,
        cluster: str,
        result: str,
        *,
        job_urn: Optional[str] = None,
        upstream_urns: Optional[List[str]] = None,
        parent_instance_urn: Optional[str] = None,
        end_timestamp_millis: Optional[int] = None,
        silent: bool = False,
    ) -> None:
        """실행 종료 이벤트를 등록합니다.

        Args:
            instance_id:            실행 고유 ID
            orchestrator:           오케스트레이터 이름
            cluster:                클러스터 / 환경 이름
            result:                 실행 결과 (SUCCESS / FAILURE / SKIPPED / UP_FOR_RETRY)
            job_urn:                부모 DataJob URN (관계 유지를 위해 emit_start와 동일 값 전달 권장)
            upstream_urns:          선행 DataProcessInstance URN 목록 (관계 덮어쓰기 방지)
            parent_instance_urn:    부모 DataProcessInstance URN (관계 덮어쓰기 방지)
            end_timestamp_millis:   종료 시각 ms (기본값: 현재 시각)
            silent:                 True이면 GMS 오류 시 예외 없이 WARNING 로그만 남김
        """
        instance_id = self.sanitize_instance_id(instance_id)
        urn = self.make_urn(instance_id)
        ts = end_timestamp_millis or int(time.time() * 1000)
        run_result = self._resolve_result(result)

        try:
            instance = self._build(
                instance_id=instance_id,
                orchestrator=orchestrator,
                cluster=cluster,
                job_urn=job_urn,
                upstream_urns=upstream_urns,
                parent_instance_urn=parent_instance_urn,
            )
            instance.emit_process_end(
                emitter=self._manager._datahub_graph,
                end_timestamp_millis=ts,
                result=run_result,
            )
            logger.info("DataProcessInstance 종료 등록 (result=%s): %s", result, urn)
        except Exception as exc:
            if silent:
                logger.warning(
                    "DataProcessInstance 종료 등록 실패 (silent=True, 무시됨): %s — %s", urn, exc
                )
            else:
                raise ProcessInstanceError(
                    f"DataProcessInstance 종료 등록 실패 ({urn}): {exc}"
                ) from exc

    # ------------------------------------------------------------------
    # run — start + end 한번에 (소급 등록용)
    # ------------------------------------------------------------------

    def run(
        self,
        instance_id: str,
        orchestrator: str,
        cluster: str,
        result: str,
        *,
        job_urn: Optional[str] = None,
        inlets: Optional[List[str]] = None,
        outlets: Optional[List[str]] = None,
        upstream_urns: Optional[List[str]] = None,
        parent_instance_urn: Optional[str] = None,
        properties: Optional[Dict[str, str]] = None,
        process_type: str = "BATCH_SCHEDULED",
        start_timestamp_millis: Optional[int] = None,
        end_timestamp_millis: Optional[int] = None,
        silent: bool = False,
    ) -> str:
        """실행 시작 + 종료 이벤트를 한번에 등록합니다.

        이미 완료된 실행을 소급해서 등록하거나,
        짧은 실행을 단번에 기록할 때 사용합니다.

        Args:
            instance_id:             실행 고유 ID
            orchestrator:            오케스트레이터 이름
            cluster:                 클러스터 / 환경 이름
            result:                  실행 결과 (SUCCESS / FAILURE / SKIPPED / UP_FOR_RETRY)
            job_urn:                 부모 DataJob URN
            inlets:                  이 실행에서 읽은 Dataset URN 목록
            outlets:                 이 실행에서 쓴 Dataset URN 목록
            upstream_urns:           선행 DataProcessInstance URN 목록 (의존 관계)
            parent_instance_urn:     부모 DataProcessInstance URN (계층 관계, 예: DAG run URN)
            properties:              커스텀 속성
            process_type:            실행 타입 (BATCH_SCHEDULED / BATCH_AD_HOC / STREAMING)
            start_timestamp_millis:  시작 시각 ms
            end_timestamp_millis:    종료 시각 ms
            silent:                  True이면 GMS 오류 시 예외 없이 WARNING 로그만 남김

        Returns:
            DataProcessInstance URN 문자열
        """
        urn = self.emit_start(
            instance_id=instance_id,
            orchestrator=orchestrator,
            cluster=cluster,
            job_urn=job_urn,
            inlets=inlets,
            outlets=outlets,
            upstream_urns=upstream_urns,
            parent_instance_urn=parent_instance_urn,
            properties=properties,
            process_type=process_type,
            start_timestamp_millis=start_timestamp_millis,
            silent=silent,
        )
        self.emit_end(
            instance_id=instance_id,
            orchestrator=orchestrator,
            cluster=cluster,
            job_urn=job_urn,
            upstream_urns=upstream_urns,
            parent_instance_urn=parent_instance_urn,
            result=result,
            end_timestamp_millis=end_timestamp_millis,
            silent=silent,
        )
        return urn

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build(
        instance_id: str,
        orchestrator: str,
        cluster: str,
        job_urn: Optional[str] = None,
        inlets: Optional[List[str]] = None,
        outlets: Optional[List[str]] = None,
        upstream_urns: Optional[List[str]] = None,
        parent_instance_urn: Optional[str] = None,
        properties: Optional[Dict[str, str]] = None,
        process_type: str = "BATCH_SCHEDULED",
    ) -> DataProcessInstance:
        from datahub.metadata.urns import DataJobUrn, DatasetUrn, DataProcessInstanceUrn

        template_urn = DataJobUrn.from_string(job_urn) if job_urn else None

        inlet_urns = [DatasetUrn.from_string(u) for u in inlets] if inlets else []
        outlet_urns = [DatasetUrn.from_string(u) for u in outlets] if outlets else []

        # upstream_urns: 문자열 또는 리스트 → DataProcessInstanceUrn 변환
        # 문자열을 직접 전달한 경우(리스트로 감싸지 않은 경우) 자동 보정
        if isinstance(upstream_urns, str):
            logger.warning(
                "upstream_urns에 문자열이 직접 전달되었습니다. 리스트로 자동 변환합니다. "
                "올바른 사용법: upstream_urns=['%s']",
                upstream_urns,
            )
            upstream_urns = [upstream_urns]
        up_urns = (
            [DataProcessInstanceUrn.from_string(u) for u in upstream_urns]
            if upstream_urns else []
        )

        # parent_instance: 문자열 → DataProcessInstanceUrn 변환
        parent_urn = (
            DataProcessInstanceUrn.from_string(parent_instance_urn)
            if parent_instance_urn else None
        )

        resolved_type = _TYPE_MAP.get(process_type.upper(), DataProcessTypeClass.BATCH_SCHEDULED)

        return DataProcessInstance(
            id=instance_id,
            orchestrator=orchestrator,
            cluster=cluster,
            template_urn=template_urn,
            type=resolved_type,
            properties=properties or {},
            inlets=inlet_urns,
            outlets=outlet_urns,
            upstream_urns=up_urns,
            parent_instance=parent_urn,   # 생성자에 직접 전달
        )

    @staticmethod
    def _resolve_result(result: str) -> InstanceRunResult:
        resolved = _RESULT_MAP.get(result.upper())
        if resolved is None:
            raise InvalidEntityError(
                f"result 값이 올바르지 않습니다: '{result}'. "
                f"허용값: {list(_RESULT_MAP.keys())}"
            )
        return resolved
