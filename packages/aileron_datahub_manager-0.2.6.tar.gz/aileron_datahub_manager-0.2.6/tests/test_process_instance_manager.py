from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import InvalidEntityError, ProcessInstanceError

JOB_URN = "urn:li:dataJob:(urn:li:dataFlow:(airflow,orders_etl,PROD),transform)"
DS_IN = "urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"
DS_OUT = "urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_daily,PROD)"
DAG_RUN_URN = "urn:li:dataProcessInstance:orders_etl__2024-04-17"
TASK_RUN_URN = "urn:li:dataProcessInstance:orders_etl__2024-04-17__transform"
UPSTREAM_URN = "urn:li:dataProcessInstance:orders_etl__2024-04-17__extract"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# sanitize_instance_id (v0.2.3 신규)
# ------------------------------------------------------------------

def test_sanitize_instance_id_no_reserved_chars():
    """예약 문자가 없으면 원본 그대로 반환해야 한다."""
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    assert ProcessInstanceManager.sanitize_instance_id("orders_etl__2024-04-17") == \
           "orders_etl__2024-04-17"


def test_sanitize_instance_id_replaces_colon():
    """콜론(:)은 밑줄(_)로 치환되어야 한다."""
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    result = ProcessInstanceManager.sanitize_instance_id("run:2024-04-17T12:00:00")
    assert ":" not in result
    assert result == "run_2024-04-17T12_00_00"


def test_sanitize_instance_id_replaces_all_reserved_chars():
    """콜론(:), 쉼표(,), 괄호((), )) 모두 밑줄(_)로 치환되어야 한다."""
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    result = ProcessInstanceManager.sanitize_instance_id("run:(2024,04,17)")
    assert ":" not in result
    assert "," not in result
    assert "(" not in result
    assert ")" not in result


def test_sanitize_instance_id_logs_warning_on_replacement(caplog):
    """예약 문자 치환 시 WARNING 로그가 남아야 한다."""
    import logging
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    with caplog.at_level(logging.WARNING, logger="aileron_datahub_manager.entities.process_instance"):
        ProcessInstanceManager.sanitize_instance_id("run:2024")

    assert len(caplog.records) > 0
    assert any("run:2024" in r.message for r in caplog.records)


def test_sanitize_instance_id_no_warning_when_clean(caplog):
    """예약 문자가 없으면 WARNING이 발생하지 않아야 한다."""
    import logging
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    with caplog.at_level(logging.WARNING, logger="aileron_datahub_manager.entities.process_instance"):
        ProcessInstanceManager.sanitize_instance_id("clean_id__2024-04-17")

    assert len(caplog.records) == 0


# ------------------------------------------------------------------
# make_urn (v0.2.3: 예약 문자 자동 치환)
# ------------------------------------------------------------------

def test_make_urn_format():
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    urn = ProcessInstanceManager.make_urn("orders_etl__2024-04-17")
    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"


def test_make_urn_sanitizes_reserved_chars():
    """make_urn이 예약 문자를 자동 치환하여 URN을 생성해야 한다."""
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    urn = ProcessInstanceManager.make_urn("run:2024-04-17T12:00:00")
    assert ":" not in urn.split("dataProcessInstance:")[-1]
    assert urn.startswith("urn:li:dataProcessInstance:")


def test_make_urn_iso_timestamp_sanitized():
    """ISO 8601 타임스탬프가 포함된 instance_id도 안전하게 변환되어야 한다."""
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager

    urn = ProcessInstanceManager.make_urn("my_job__2024-04-17T12:30:00Z")
    assert urn == "urn:li:dataProcessInstance:my_job__2024-04-17T12_30_00Z"


# ------------------------------------------------------------------
# emit_start
# ------------------------------------------------------------------

def test_emit_start_returns_urn(manager):
    """emit_start가 DataProcessInstance URN을 반환해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"
    mock_instance.emit_process_start.assert_called_once()


def test_emit_start_uses_emit_template_false(manager):
    """emit_process_start가 emit_template=False로 호출되어야 한다.

    핵심 버그 수정 검증 (v0.2.5):
    - emit_template=True(기본값) 시 SDK가 DataJob을 빈 상태로 재생성하여 emit하므로
      upsert_job()이 등록한 inlets/outlets/upstream_jobs 리니지가 전부 소실됨
    - emit_template=False로 설정하면 DataJob 재emit을 건너뛰어 리니지를 보존함
    """
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            job_urn=JOB_URN,
        )

    call_kwargs = mock_instance.emit_process_start.call_args.kwargs
    assert call_kwargs.get("emit_template") is False, (
        "emit_template=False가 전달되지 않으면 DataJob 리니지가 덮어써짐"
    )


def test_emit_start_sanitizes_instance_id(manager):
    """emit_start가 instance_id의 예약 문자를 자동 치환해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        urn = manager.process_instances.emit_start(
            instance_id="run:2024-04-17T12:00:00",
            orchestrator="airflow",
            cluster="PROD",
        )

    assert ":" not in urn.split("dataProcessInstance:")[-1]
    assert urn.startswith("urn:li:dataProcessInstance:")


def test_emit_start_with_job_urn(manager):
    """job_urn 전달 시 DataJobUrn 변환 후 template_urn으로 전달되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            job_urn=JOB_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["template_urn"] is not None
    assert str(call_kwargs["template_urn"]) == JOB_URN


def test_emit_start_with_inlets_outlets(manager):
    """inlets/outlets가 DatasetUrn 객체로 변환되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            inlets=[DS_IN],
            outlets=[DS_OUT],
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert len(call_kwargs["inlets"]) == 1
    assert str(call_kwargs["inlets"][0]) == DS_IN
    assert len(call_kwargs["outlets"]) == 1
    assert str(call_kwargs["outlets"][0]) == DS_OUT


def test_emit_start_with_parent_instance_urn(manager):
    """parent_instance_urn이 DataProcessInstanceUrn 객체로 변환되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            parent_instance_urn=DAG_RUN_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["parent_instance"] is not None
    assert str(call_kwargs["parent_instance"]) == DAG_RUN_URN


def test_emit_start_with_upstream_urns(manager):
    """upstream_urns가 DataProcessInstanceUrn 객체 목록으로 변환되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            upstream_urns=[UPSTREAM_URN],
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert len(call_kwargs["upstream_urns"]) == 1
    assert str(call_kwargs["upstream_urns"][0]) == UPSTREAM_URN


def test_emit_start_upstream_urns_string_auto_converted(manager):
    """upstream_urns에 리스트 대신 문자열을 직접 전달해도 자동 변환되어야 한다 (v0.2.3 버그 수정)."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        # 문자열을 직접 전달 (리스트로 감싸지 않음)
        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            upstream_urns=UPSTREAM_URN,  # 실수로 str 전달
        )

    call_kwargs = mock_cls.call_args.kwargs
    # 자동으로 리스트로 변환되어 정상 처리되어야 함
    assert len(call_kwargs["upstream_urns"]) == 1
    assert str(call_kwargs["upstream_urns"][0]) == UPSTREAM_URN


def test_emit_start_missing_instance_id_raises(manager):
    """instance_id 없으면 InvalidEntityError."""
    with pytest.raises(InvalidEntityError):
        manager.process_instances.emit_start(
            instance_id="",
            orchestrator="airflow",
            cluster="PROD",
        )


def test_emit_start_missing_orchestrator_raises(manager):
    """orchestrator 없으면 InvalidEntityError."""
    with pytest.raises(InvalidEntityError):
        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="",
            cluster="PROD",
        )


# ------------------------------------------------------------------
# silent 옵션 (emit_start)
# ------------------------------------------------------------------

def test_emit_start_silent_suppresses_exception(manager):
    """silent=True 시 GMS 오류가 발생해도 예외 없이 URN을 반환해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_start.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            silent=True,
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"


def test_emit_start_silent_false_raises_on_error(manager):
    """silent=False(기본) 시 GMS 오류가 ProcessInstanceError로 raise되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_start.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        with pytest.raises(ProcessInstanceError):
            manager.process_instances.emit_start(
                instance_id="orders_etl__2024-04-17",
                orchestrator="airflow",
                cluster="PROD",
                silent=False,
            )


# ------------------------------------------------------------------
# emit_end
# ------------------------------------------------------------------

def test_emit_end_calls_emit_process_end(manager):
    """emit_end가 emit_process_end를 호출해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
        )

    mock_instance.emit_process_end.assert_called_once()
    call_kwargs = mock_instance.emit_process_end.call_args.kwargs
    from datahub.api.entities.dataprocess.dataprocess_instance import InstanceRunResult
    assert call_kwargs["result"] == InstanceRunResult.SUCCESS


def test_emit_end_invalid_result_raises(manager):
    """잘못된 result 값은 InvalidEntityError를 발생시켜야 한다."""
    with pytest.raises(InvalidEntityError, match="result"):
        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="INVALID_STATUS",
        )


def test_emit_end_all_result_values(manager):
    """SUCCESS / FAILURE / SKIPPED / UP_FOR_RETRY 모두 허용되어야 한다."""
    from datahub.api.entities.dataprocess.dataprocess_instance import InstanceRunResult

    result_map = {
        "SUCCESS": InstanceRunResult.SUCCESS,
        "FAILURE": InstanceRunResult.FAILURE,
        "SKIPPED": InstanceRunResult.SKIPPED,
        "UP_FOR_RETRY": InstanceRunResult.UP_FOR_RETRY,
    }

    for result_str, expected in result_map.items():
        with patch(
            "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
        ) as mock_cls:
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance

            manager.process_instances.emit_end(
                instance_id="orders_etl__2024-04-17",
                orchestrator="airflow",
                cluster="PROD",
                result=result_str,
            )

        call_kwargs = mock_instance.emit_process_end.call_args.kwargs
        assert call_kwargs["result"] == expected, f"{result_str} 매핑 실패"


def test_emit_end_with_job_urn_preserves_relationship(manager):
    """emit_end에 job_urn 전달 시 template_urn이 설정되어야 한다 (관계 보존).

    v0.2.3 버그 수정 검증:
    - 이전: emit_end가 관계 파라미터 없이 DataProcessInstance를 생성하여
             emit_start에서 설정한 관계를 덮어씀
    - 수정: emit_end도 job_urn, upstream_urns, parent_instance_urn을 받아
             동일한 관계 정보를 포함한 객체를 emit함
    """
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            job_urn=JOB_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["template_urn"] is not None
    assert str(call_kwargs["template_urn"]) == JOB_URN


def test_emit_end_with_parent_instance_urn_preserves_relationship(manager):
    """emit_end에 parent_instance_urn 전달 시 parent_instance가 설정되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            parent_instance_urn=DAG_RUN_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["parent_instance"] is not None
    assert str(call_kwargs["parent_instance"]) == DAG_RUN_URN


def test_emit_end_with_upstream_urns_preserves_relationship(manager):
    """emit_end에 upstream_urns 전달 시 upstream_urns가 설정되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            upstream_urns=[UPSTREAM_URN],
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert len(call_kwargs["upstream_urns"]) == 1
    assert str(call_kwargs["upstream_urns"][0]) == UPSTREAM_URN


def test_emit_end_silent_suppresses_exception(manager):
    """silent=True 시 emit_end 오류가 억제되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_end.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        # 예외 없이 통과해야 함
        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            silent=True,
        )


# ------------------------------------------------------------------
# run (start + end 한번에)
# ------------------------------------------------------------------

def test_run_calls_both_emit_start_and_end(manager):
    """run이 emit_process_start와 emit_process_end를 모두 호출해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.run(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"
    mock_instance.emit_process_start.assert_called_once()
    mock_instance.emit_process_end.assert_called_once()


def test_run_passes_parent_instance_to_both_start_and_end(manager):
    """run이 parent_instance_urn을 emit_start와 emit_end 양쪽에 전달해야 한다 (v0.2.3 수정)."""
    call_kwargs_list = []

    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        def capture(*args, **kwargs):
            call_kwargs_list.append(kwargs)
            return MagicMock()

        mock_cls.side_effect = capture

        manager.process_instances.run(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            parent_instance_urn=DAG_RUN_URN,
        )

    # emit_start와 emit_end 각각 DataProcessInstance 생성 → 2회 호출
    assert len(call_kwargs_list) == 2
    for kwargs in call_kwargs_list:
        assert kwargs["parent_instance"] is not None
        assert str(kwargs["parent_instance"]) == DAG_RUN_URN


def test_run_passes_job_urn_to_both_start_and_end(manager):
    """run이 job_urn을 emit_start와 emit_end 양쪽에 전달해야 한다."""
    call_kwargs_list = []

    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        def capture(*args, **kwargs):
            call_kwargs_list.append(kwargs)
            return MagicMock()

        mock_cls.side_effect = capture

        manager.process_instances.run(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            job_urn=JOB_URN,
        )

    assert len(call_kwargs_list) == 2
    for kwargs in call_kwargs_list:
        assert str(kwargs["template_urn"]) == JOB_URN


def test_run_passes_upstream_urns_to_both_start_and_end(manager):
    """run이 upstream_urns를 emit_start와 emit_end 양쪽에 전달해야 한다."""
    call_kwargs_list = []

    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        def capture(*args, **kwargs):
            call_kwargs_list.append(kwargs)
            return MagicMock()

        mock_cls.side_effect = capture

        manager.process_instances.run(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            upstream_urns=[UPSTREAM_URN],
        )

    assert len(call_kwargs_list) == 2
    for kwargs in call_kwargs_list:
        assert len(kwargs["upstream_urns"]) == 1
        assert str(kwargs["upstream_urns"][0]) == UPSTREAM_URN
