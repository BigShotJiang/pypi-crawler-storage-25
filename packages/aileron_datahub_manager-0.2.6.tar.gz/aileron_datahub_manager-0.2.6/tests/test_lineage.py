from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from datahub.sdk.lineage_client import LineageClient

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import LineageError

DS_UP = "urn:li:dataset:(urn:li:dataPlatform:hive,db.upstream,PROD)"
DS_DOWN = "urn:li:dataset:(urn:li:dataPlatform:hive,db.downstream,PROD)"
JOB_URN = "urn:li:dataJob:(urn:li:dataFlow:(airflow,my_dag,PROD),my_task)"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        # spec=LineageClient 으로 지정 → 존재하지 않는 메서드 호출 시 AttributeError
        mock_client.lineage = MagicMock(spec=LineageClient)
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# Dataset 리니지
# ------------------------------------------------------------------

def test_add_dataset_lineage_calls_add_lineage(manager):
    """add_dataset_lineage → LineageClient.add_lineage 호출 검증."""
    manager.lineage.add_dataset_lineage(upstream=DS_UP, downstream=DS_DOWN)

    manager._client.lineage.add_lineage.assert_called_once()
    call_kwargs = manager._client.lineage.add_lineage.call_args.kwargs
    assert str(call_kwargs["upstream"]) == DS_UP
    assert str(call_kwargs["downstream"]) == DS_DOWN


def test_add_dataset_lineage_with_column_lineage(manager):
    """column_lineage 있을 때 각 upstream마다 add_lineage 호출 검증."""
    col_map = {"total_amount": ["amount"]}
    manager.lineage.add_dataset_lineage(
        upstream=DS_UP,
        downstream=DS_DOWN,
        column_lineage={DS_UP: col_map},
    )

    manager._client.lineage.add_lineage.assert_called_once()
    call_kwargs = manager._client.lineage.add_lineage.call_args.kwargs
    assert call_kwargs["column_lineage"] == col_map


def test_add_dataset_lineage_wrong_method_raises(manager):
    """존재하지 않는 메서드(add_dataset_lineage)를 직접 호출하면 AttributeError."""
    with pytest.raises(AttributeError):
        manager._client.lineage.add_dataset_lineage()


# ------------------------------------------------------------------
# DataJob 리니지
# ------------------------------------------------------------------

def test_add_job_io_calls_add_datajob_lineage(manager):
    """add_job_io → LineageClient.add_datajob_lineage(upstreams, downstreams) 호출 검증."""
    manager.lineage.add_job_io(
        job_urn=JOB_URN,
        inlets=[DS_UP],
        outlets=[DS_DOWN],
    )

    manager._client.lineage.add_datajob_lineage.assert_called_once()
    call_kwargs = manager._client.lineage.add_datajob_lineage.call_args.kwargs
    assert len(call_kwargs["upstreams"]) == 1
    assert len(call_kwargs["downstreams"]) == 1


def test_add_job_io_no_datasets_skips(manager):
    """input/output 모두 없으면 add_datajob_lineage 호출되지 않아야 한다."""
    manager.lineage.add_job_io(job_urn=JOB_URN)
    manager._client.lineage.add_datajob_lineage.assert_not_called()
