from __future__ import annotations

"""silent=True/False 옵션 동작 검증 — 모든 쓰기 작업 대상."""

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import LineageError

DS_URN = "urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"
DS_URN2 = "urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_daily,PROD)"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# Dataset
# ------------------------------------------------------------------

def test_dataset_upsert_silent_suppresses(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    # 예외 없이 URN 반환
    urn = manager.datasets.upsert(platform="hive", name="db.table", env="PROD", silent=True)
    assert "hive" in urn


def test_dataset_upsert_silent_false_raises(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    with pytest.raises(Exception):
        manager.datasets.upsert(platform="hive", name="db.table", env="PROD", silent=False)


def test_dataset_delete_silent_suppresses(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    manager.datasets.delete(DS_URN, silent=True)  # 예외 없이 통과


def test_dataset_delete_silent_false_raises(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    with pytest.raises(Exception):
        manager.datasets.delete(DS_URN, silent=False)


# ------------------------------------------------------------------
# Pipeline (DataFlow / DataJob)
# ------------------------------------------------------------------

def test_upsert_flow_silent_suppresses(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    urn = manager.pipelines.upsert_flow(
        orchestrator="airflow", flow_id="my_dag", cluster="PROD", silent=True
    )
    assert "airflow" in urn


def test_upsert_flow_silent_false_raises(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    with pytest.raises(Exception):
        manager.pipelines.upsert_flow(
            orchestrator="airflow", flow_id="my_dag", cluster="PROD", silent=False
        )


def test_upsert_job_silent_suppresses(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    urn = manager.pipelines.upsert_job(
        orchestrator="airflow", flow_id="my_dag", job_id="my_task", cluster="PROD", silent=True
    )
    assert "my_task" in urn


def test_delete_flow_silent_suppresses(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    manager.pipelines.delete_flow(
        "urn:li:dataFlow:(airflow,my_dag,PROD)", silent=True
    )


def test_delete_job_silent_suppresses(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    manager.pipelines.delete_job(
        "urn:li:dataJob:(urn:li:dataFlow:(airflow,my_dag,PROD),my_task)", silent=True
    )


# ------------------------------------------------------------------
# Container
# ------------------------------------------------------------------

def test_container_upsert_database_silent_suppresses(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    urn = manager.containers.upsert_database(
        platform="hive", database="analytics", silent=True
    )
    assert urn.startswith("urn:li:container:")


def test_container_delete_silent_suppresses(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    manager.containers.delete("urn:li:container:abc123", silent=True)


# ------------------------------------------------------------------
# Tag
# ------------------------------------------------------------------

def test_tag_upsert_silent_suppresses(manager):
    manager._client.entities.upsert.side_effect = Exception("GMS down")
    urn = manager.tags.upsert(name="pii", silent=True)
    assert "pii" in urn


def test_tag_delete_silent_suppresses(manager):
    manager._client.entities.delete.side_effect = Exception("GMS down")
    manager.tags.delete("pii", silent=True)


# ------------------------------------------------------------------
# Lineage
# ------------------------------------------------------------------

def test_add_dataset_lineage_silent_suppresses(manager):
    manager._client.lineage.add_lineage.side_effect = Exception("GMS down")
    manager.lineage.add_dataset_lineage(
        upstream=DS_URN, downstream=DS_URN2, silent=True
    )  # 예외 없이 통과


def test_add_dataset_lineage_silent_false_raises(manager):
    manager._client.lineage.add_lineage.side_effect = Exception("GMS down")
    with pytest.raises(LineageError):
        manager.lineage.add_dataset_lineage(
            upstream=DS_URN, downstream=DS_URN2, silent=False
        )


def test_add_dataset_lineage_batch_silent_suppresses(manager):
    manager._client.lineage.add_lineage.side_effect = Exception("GMS down")
    manager.lineage.add_dataset_lineage_batch(
        [(DS_URN, DS_URN2)], silent=True
    )


def test_add_job_io_silent_suppresses(manager):
    manager._client.lineage.add_datajob_lineage.side_effect = Exception("GMS down")
    manager.lineage.add_job_io(
        job_urn="urn:li:dataJob:(urn:li:dataFlow:(airflow,my_dag,PROD),my_task)",
        inlets=[DS_URN],
        outlets=[DS_URN2],
        silent=True,
    )
