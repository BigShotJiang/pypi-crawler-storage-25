from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import InvalidEntityError

DS_IN = "urn:li:dataset:(urn:li:dataPlatform:hive,db.input,PROD)"
DS_OUT = "urn:li:dataset:(urn:li:dataPlatform:hive,db.output,PROD)"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# _resolve_env — cluster 유효성 검사 (v0.2.2 신규)
# ------------------------------------------------------------------

def test_resolve_env_valid_values(manager):
    """유효한 FabricTypeClass 값은 그대로 반환되어야 한다."""
    from aileron_datahub_manager.entities.pipeline import _resolve_env

    for valid in ("PROD", "DEV", "TEST", "STAGING", "QA", "CORP", "EI"):
        assert _resolve_env(valid) == valid
        assert _resolve_env(valid.lower()) == valid  # 대소문자 무관


def test_resolve_env_invalid_cluster_returns_prod(manager):
    """유효하지 않은 cluster 값은 'PROD'로 대체되어야 한다."""
    from aileron_datahub_manager.entities.pipeline import _resolve_env

    assert _resolve_env("cv") == "PROD"
    assert _resolve_env("aileron-mwaa-prod") == "PROD"
    assert _resolve_env("custom-cluster-name") == "PROD"


def test_resolve_env_invalid_cluster_logs_warning(manager, caplog):
    """유효하지 않은 cluster 값 사용 시 WARNING 로그가 남아야 한다."""
    import logging
    from aileron_datahub_manager.entities.pipeline import _resolve_env

    with caplog.at_level(logging.WARNING, logger="aileron_datahub_manager.entities.pipeline"):
        _resolve_env("cv")

    assert any("cv" in r.message for r in caplog.records)
    assert any("PROD" in r.message for r in caplog.records)


# ------------------------------------------------------------------
# upsert_flow
# ------------------------------------------------------------------

def test_upsert_flow_returns_urn(manager):
    urn = manager.pipelines.upsert_flow(
        orchestrator="airflow", flow_id="my_dag", cluster="PROD"
    )
    assert "airflow" in urn
    assert "my_dag" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_flow_missing_required_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.pipelines.upsert_flow(orchestrator="", flow_id="my_dag", cluster="PROD")


def test_upsert_flow_invalid_cluster_does_not_raise(manager):
    """유효하지 않은 cluster 값도 PROD로 대체되어 정상 동작해야 한다 (avroTypeException 방지)."""
    urn = manager.pipelines.upsert_flow(
        orchestrator="cv_pipeline", flow_id="my_dag", cluster="cv"
    )
    assert urn is not None
    manager._client.entities.upsert.assert_called_once()


def test_upsert_flow_invalid_cluster_stores_original_in_properties(manager):
    """유효하지 않은 cluster 값은 custom_properties['cluster']에 원본 값이 저장되어야 한다."""
    captured = {}

    def capture(entity):
        captured["flow"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_flow(
        orchestrator="cv_pipeline", flow_id="my_dag", cluster="cv"
    )

    # DataFlow 객체가 전달되었는지 확인
    assert "flow" in captured


# ------------------------------------------------------------------
# upsert_job — 기본
# ------------------------------------------------------------------

def test_upsert_job_returns_urn(manager):
    urn = manager.pipelines.upsert_job(
        orchestrator="airflow", flow_id="my_dag", job_id="my_task", cluster="PROD"
    )
    assert "my_task" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_job_missing_required_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.pipelines.upsert_job(
            orchestrator="airflow", flow_id="my_dag", job_id="", cluster="PROD"
        )


def test_upsert_job_invalid_cluster_does_not_raise(manager):
    """유효하지 않은 cluster 값도 PROD로 대체되어 정상 동작해야 한다."""
    urn = manager.pipelines.upsert_job(
        orchestrator="cv_pipeline", flow_id="my_dag", job_id="my_task", cluster="cv"
    )
    assert urn is not None
    manager._client.entities.upsert.assert_called_once()


# ------------------------------------------------------------------
# upsert_job — inlets / outlets
# ------------------------------------------------------------------

def test_upsert_job_with_inlets(manager):
    """inlets 전달 시 DataJob이 inlets를 포함해 upsert되어야 한다."""
    captured = {}

    def capture(entity):
        captured["job"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        inlets=[DS_IN],
    )

    job = captured["job"]
    # DataJob 생성자에 inlets 전달 검증 — inlets는 내부 aspect에 저장됨
    manager._client.entities.upsert.assert_called_once()


def test_upsert_job_with_outlets(manager):
    """outlets 전달 시 DataJob이 outlets를 포함해 upsert되어야 한다."""
    captured = {}

    def capture(entity):
        captured["job"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        outlets=[DS_OUT],
    )

    manager._client.entities.upsert.assert_called_once()


# ------------------------------------------------------------------
# upsert_job — upstream_jobs (DataJob 간 리니지, v0.2.4 버그 수정)
# ------------------------------------------------------------------

def test_upsert_job_upstream_jobs_sets_input_datajobs(manager):
    """upstream_jobs → DataJobInputOutputClass.inputDatajobs에 설정되어야 한다."""
    upstream_urn = manager.pipelines.make_job_urn("airflow", "my_dag", "upstream_task", "PROD")

    captured = {}

    def capture(entity):
        captured["job"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        upstream_jobs=[upstream_urn],
    )

    job = captured["job"]
    props = job._ensure_datajob_inputoutput_props()
    assert props is not None
    assert props.inputDatajobs is not None
    assert upstream_urn in props.inputDatajobs


def test_upsert_job_upstream_jobs_not_overwritten_by_inlets(manager):
    """upstream_jobs와 inlets를 동시에 전달해도 inputDatajobs가 덮어쓰여지지 않아야 한다.

    핵심 버그 수정 검증:
    - 이전: set_inlets() 호출이 _ensure_datajob_inputoutput_props() props를 덮어써
             upstream_jobs(inputDatajobs)가 소실됨
    - 수정: inlets/outlets를 DataJob 생성자에 직접 전달하고,
             upstream_jobs는 생성자 호출 이후 별도로 설정함
    """
    upstream_urn = manager.pipelines.make_job_urn("airflow", "my_dag", "upstream_task", "PROD")

    captured = {}

    def capture(entity):
        captured["job"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        inlets=[DS_IN],     # 동시에 inlets도 전달
        outlets=[DS_OUT],   # 동시에 outlets도 전달
        upstream_jobs=[upstream_urn],  # upstream_jobs가 소실되지 않아야 함
    )

    job = captured["job"]
    props = job._ensure_datajob_inputoutput_props()
    assert props is not None
    assert props.inputDatajobs is not None
    assert upstream_urn in props.inputDatajobs, (
        "upstream_jobs가 inlets 설정으로 인해 소실됨 — 버그 재현"
    )


def test_upsert_job_multiple_upstream_jobs(manager):
    """여러 upstream_jobs를 모두 inputDatajobs에 등록할 수 있어야 한다."""
    upstream_a = manager.pipelines.make_job_urn("airflow", "my_dag", "task_a", "PROD")
    upstream_b = manager.pipelines.make_job_urn("airflow", "my_dag", "task_b", "PROD")

    captured = {}
    manager._client.entities.upsert.side_effect = lambda e: captured.update({"job": e})

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        upstream_jobs=[upstream_a, upstream_b],
    )

    props = captured["job"]._ensure_datajob_inputoutput_props()
    assert upstream_a in props.inputDatajobs
    assert upstream_b in props.inputDatajobs


# ------------------------------------------------------------------
# make_urn 헬퍼
# ------------------------------------------------------------------

def test_make_flow_urn_contains_orchestrator_and_flow_id(manager):
    urn = manager.pipelines.make_flow_urn("airflow", "orders_etl", "PROD")
    assert "airflow" in urn
    assert "orders_etl" in urn
    assert "PROD" in urn


def test_make_flow_urn_invalid_cluster_uses_prod(manager):
    """유효하지 않은 cluster는 PROD로 대체되어 URN에 포함되어야 한다."""
    urn = manager.pipelines.make_flow_urn("airflow", "orders_etl", "cv")
    assert "PROD" in urn
    assert "cv" not in urn  # 원본 invalid cluster 값은 URN에 포함되지 않음


def test_make_job_urn_contains_all_components(manager):
    urn = manager.pipelines.make_job_urn("airflow", "orders_etl", "transform", "PROD")
    assert "transform" in urn
    assert "orders_etl" in urn


# ------------------------------------------------------------------
# delete
# ------------------------------------------------------------------

def test_delete_flow_calls_sdk(manager):
    urn = manager.pipelines.make_flow_urn("airflow", "my_dag", "PROD")
    manager.pipelines.delete_flow(urn)
    manager._client.entities.delete.assert_called_once_with(urn, hard=False)


def test_delete_job_calls_sdk(manager):
    urn = manager.pipelines.make_job_urn("airflow", "my_dag", "my_task", "PROD")
    manager.pipelines.delete_job(urn)
    manager._client.entities.delete.assert_called_once_with(urn, hard=False)
