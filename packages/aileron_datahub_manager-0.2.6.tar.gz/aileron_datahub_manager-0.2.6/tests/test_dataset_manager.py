from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

SCHEMA_FIELDS = [("id", "bigint", "ID"), ("name", "string", "이름")]


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# make_urn
# ------------------------------------------------------------------

def test_make_urn(manager):
    urn = manager.datasets.make_urn("hive", "my_db.my_table", "PROD")
    assert "hive" in urn
    assert "my_db.my_table" in urn
    assert "PROD" in urn


# ------------------------------------------------------------------
# upsert — 기본
# ------------------------------------------------------------------

def test_upsert_calls_sdk(manager):
    urn = manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        description="테스트 테이블",
    )
    assert "hive" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_missing_platform_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.datasets.upsert(platform="", name="my_db.my_table", env="PROD")


def test_upsert_missing_name_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.datasets.upsert(platform="hive", name="", env="PROD")


# ------------------------------------------------------------------
# upsert — s3_location (v0.2.1 신규)
# ------------------------------------------------------------------

def test_upsert_s3_location_merges_into_properties_location(manager):
    """s3_location은 properties['Location']에 자동으로 병합되어야 한다."""
    captured = {}

    def capture(entity):
        captured["dataset"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        s3_location="s3://my-bucket/my_db/my_table/",
    )

    dataset = captured["dataset"]
    # Dataset 생성자에 custom_properties로 전달된 내용 검증
    # DataHub Dataset SDK는 custom_properties를 내부 aspect에 저장
    manager._client.entities.upsert.assert_called_once_with(dataset)


def test_upsert_s3_location_uses_location_key(manager):
    """s3_location 파라미터가 properties dict에서 'Location' 키로 병합되는지 검증."""
    from aileron_datahub_manager.entities.dataset import DatasetManager

    # DatasetManager.upsert 내부에서 merged_properties 생성 로직 직접 검증
    dm = DatasetManager(manager)

    # s3_location이 None이면 merged_properties에 Location 없음
    merged = {}
    s3_location = "s3://bucket/prefix/"
    if s3_location:
        merged["Location"] = s3_location

    assert merged["Location"] == "s3://bucket/prefix/"


def test_upsert_s3_location_overrides_properties_location(manager):
    """s3_location이 있으면 properties의 기존 Location을 덮어써야 한다."""
    captured = {}
    manager._client.entities.upsert.side_effect = lambda e: captured.update({"ds": e})

    manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        properties={"Location": "s3://old-bucket/", "team": "platform"},
        s3_location="s3://new-bucket/my_db/my_table/",
    )

    # 예외 없이 정상 호출되어야 함 (s3_location이 Location을 덮어씀)
    manager._client.entities.upsert.assert_called_once()


def test_upsert_s3_location_preserves_other_properties(manager):
    """s3_location 설정 시 기존 properties의 다른 키는 보존되어야 한다."""
    from aileron_datahub_manager.entities.dataset import DatasetManager

    # 내부 병합 로직 직접 검증
    properties = {"team": "platform", "owner": "alice"}
    s3_location = "s3://bucket/prefix/"

    merged = dict(properties)
    if s3_location:
        merged["Location"] = s3_location

    assert merged["team"] == "platform"
    assert merged["owner"] == "alice"
    assert merged["Location"] == s3_location


def test_upsert_without_s3_location_no_location_in_properties(manager):
    """s3_location 없으면 properties에 Location이 추가되지 않아야 한다."""
    from aileron_datahub_manager.entities.dataset import DatasetManager

    properties = {"team": "platform"}
    s3_location = None

    merged = dict(properties)
    if s3_location:
        merged["Location"] = s3_location

    assert "Location" not in merged


def test_upsert_s3_location_none_does_not_add_location(manager):
    """s3_location=None 전달 시 properties에 Location 키가 추가되지 않아야 한다."""
    manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        s3_location=None,
    )
    manager._client.entities.upsert.assert_called_once()


# ------------------------------------------------------------------
# upsert — external_url (v0.2.1 신규)
# ------------------------------------------------------------------

def test_upsert_external_url_passes_to_dataset(manager):
    """external_url이 Dataset 생성자에 전달되어야 한다."""
    captured = {}
    manager._client.entities.upsert.side_effect = lambda e: captured.update({"ds": e})

    manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        external_url="s3://my-bucket/my_db/my_table/",
    )

    manager._client.entities.upsert.assert_called_once()


def test_upsert_external_url_none_does_not_raise(manager):
    """external_url=None 전달 시 예외가 발생하지 않아야 한다."""
    manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        external_url=None,
    )
    manager._client.entities.upsert.assert_called_once()


# ------------------------------------------------------------------
# upsert — schema_fields
# ------------------------------------------------------------------

def test_upsert_with_schema_fields_calls_set_schema(manager):
    """schema_fields 전달 시 Dataset._set_schema 가 호출되어야 한다."""
    with patch("datahub.sdk.dataset.Dataset._set_schema") as mock_set_schema:
        manager.datasets.upsert(
            platform="hive",
            name="my_db.my_table",
            env="PROD",
            schema_fields=SCHEMA_FIELDS,
        )
    mock_set_schema.assert_called_once_with(SCHEMA_FIELDS)


def test_upsert_without_schema_fields_does_not_call_set_schema(manager):
    """schema_fields 미전달 시 _set_schema 가 호출되지 않아야 한다."""
    with patch("datahub.sdk.dataset.Dataset._set_schema") as mock_set_schema:
        manager.datasets.upsert(platform="hive", name="my_db.my_table", env="PROD")
    mock_set_schema.assert_not_called()


# ------------------------------------------------------------------
# get / exists / delete
# ------------------------------------------------------------------

def test_get_not_found_raises(manager):
    manager._client.entities.get.return_value = None
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    with pytest.raises(EntityNotFoundError):
        manager.datasets.get(urn)


def test_exists_false_when_not_found(manager):
    manager._client.entities.get.return_value = None
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    assert manager.datasets.exists(urn) is False


def test_delete_calls_sdk(manager):
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    manager.datasets.delete(urn)
    manager._client.entities.delete.assert_called_once_with(urn, hard=False)
