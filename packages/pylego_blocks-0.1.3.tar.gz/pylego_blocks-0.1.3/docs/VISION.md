# pylego — 비전 및 방향 재정립

*작성일: 2026-04-27 | 기준 버전: v0.1.3*

---

## 1. 원래 아이디어

> **AI가 업무를 빠르게 분석하고, 새로운 업무를 빠르게 개발할 수 있는 프레임워크.**

구체적으로는:

- 기존에 만들어진 블록을 AI가 발견하고 **조합**한다
- 필요한 경우 AI가 새 블록·유닛 코드를 **직접 작성**한다
- 이 두 가지로 실제 업무 파이프라인을 **빠르게 수행**한다

pylego는 AI가 사용하는 도구다. 사람이 직접 쓰는 것도 가능하지만, **주 사용자는 AI 에이전트**다.

---

## 2. 지금까지 만든 것 (v0.1.3)

### 코어 레이어 (완성도 높음)

| 컴포넌트 | 역할 | 상태 |
|----------|------|------|
| `Block` / `Stud` / `Assembly` | 단일 책임 실행 단위 + I/O 계약 + 체인 | ✅ 견고 |
| `EventBus` / `CollectingEventBus` / `NestedEventBus` | 실행 관측성 | ✅ 완성 |
| `PipelineHealth` / `build_health_summary` | 헬스 드릴다운 | ✅ 완성 |
| `RetryBlock` / `FallbackBlock` / `CircuitBreakerBlock` | 복원력 패턴 | ✅ 완성 |
| `SemanticRetryBlock` | AI 의미론적 재시도 | ✅ 완성 |
| `LlmRouter` / `BaseLlmBlock` | LLM 백엔드 추상화 | ✅ 완성 |
| `pylego.compat` | extras 의존성 검사 | ✅ 완성 |
| `to_html()` / `to_mermaid()` / `to_dot()` | 파이프라인 시각화 | ✅ 완성 |

### 블록 생태계 (폭은 넓지만 목적이 흐릿)

DB, LLM, 파일, 알림, 검색, 번역, 벡터 등 다양한 블록이 있다.  
문제는 "생각나는 대로 만든" 측면이 있어 **AI의 업무 수행에 실제로 필요한 블록인지 검증이 없었다.**

### 문서 (AI 에이전트 친화적)

`CLAUDE.md`는 AI가 즉시 블록을 작성하고 조합할 수 있도록 설계됐다.  
이 방향은 정확히 맞다.

---

## 3. 무엇이 빗나갔나

블록 카탈로그를 늘리는 것이 목적이 되어버렸다.

pylego가 해결해야 할 문제는 **"블록을 제공하는 것"이 아니라 "AI가 블록을 쉽게 만들고 조합할 수 있는 구조를 제공하는 것"** 이다.

외부 API 블록(Slack, Telegram, Gmail...)을 pylego가 계속 만드는 건 langchain과 같은 방향으로 가는 것이다.  
사용자의 도메인 블록 — `SalesReportBlock`, `CustomerQueryBlock`, `OrderPipelineBlock` — 은 사용자 코드베이스에 있어야 한다.

---

## 4. AI가 업무를 수행하려면 실제로 필요한 것

AI가 "매일 오전 9시에 MySQL 매출 데이터를 뽑아 Excel로 저장하고 Slack 알림" 같은 업무를 수행하려면:

```
1. 어떤 블록이 있는지 파악
2. 블록 조합 가능 여부 사전 확인 (Stud 계약)
3. 없는 블록은 직접 작성
4. 파이프라인 실행
5. 결과를 받고 문제 시 수정
```

현재 pylego에서 **막히는 지점:**

| 단계 | 부족한 것 |
|------|-----------|
| 블록 발견 | `BlockRegistry`가 빈약 — 태그·설명·Stud 정보 검색 없음 |
| 사전 검증 | 조합 가능 여부를 조립 시점 전에 확인할 수단 없음 |
| 실행 환경 | 스케줄러·트리거가 없음. `asyncio.run()` 직접 작성 필요 |
| 피드백 루프 | 실행 결과(PipelineHealth)가 AI에게 다시 전달되는 루프 없음 |

---

## 5. 다음 방향 — AI 인터페이스 레이어

코어(Block/Assembly/EventBus/Health)는 기반으로 좋다.  
그 위에 **"AI가 사용하는 인터페이스 레이어"** 가 필요하다.

### 우선순위

**P1 — BlockRegistry 강화**

AI가 쓸 수 있는 블록을 스스로 발견할 수 있어야 한다.

```python
# 현재: 수동 등록, 검색 없음
# 목표:
registry.search("DB 조회")       # → [DuckDbBlock, SqliteBlock, MySqlBlock]
registry.compatible_with(QueryResult)  # → QueryResult를 입력으로 받는 블록 목록
registry.describe(DuckDbBlock)   # → 블록 설명, 입출력 Stud, 예시 코드
```

**P2 — Stud 호환성 사전 검사**

AI가 파이프라인을 조합하기 전에 계약이 맞는지 확인할 수 있어야 한다.

```python
# 현재: Assembly([A, B]) 시점에 오류
# 목표:
check_chain([BlockA, BlockB, BlockC])
# → {"compatible": True} 또는 {"error": "BlockB.output ≠ BlockC.input", "at": 1}
```

**P3 — 실행 런처**

만든 파이프라인을 바로 배포하고 실행할 수 있어야 한다.

```python
# 스케줄 실행
schedule(pipeline, cron="0 9 * * *", input=MyInput(...))

# 이벤트 트리거
on_event("file.uploaded", pipeline)

# 간단한 CLI 등록
pylego run my_pipeline.py --input '{"query": "..."}'
```

**P4 — AI 피드백 루프**

실행 결과가 AI에게 구조화된 형태로 전달되어야 한다.

```python
# PipelineHealth → AI가 읽을 수 있는 진단 요약
health.to_ai_summary()
# → "WrapperBlock 실패. 원인: DBBlock 타임아웃 (2.3s). 권장 조치: timeout_sec 조정 또는 FallbackBlock 추가"
```

---

## 6. 블록 추가 기준 재정립

앞으로 새 블록을 추가할 때는 이 기준을 먼저 확인한다:

1. **AI의 업무 수행에 실제로 필요한가?** — 단순히 "이런 블록도 있으면 좋겠다"가 아니라 구체적인 유스케이스가 있어야 한다
2. **사용자 도메인 블록의 예시가 되는가?** — pylego 자체 블록보다 "이런 식으로 만들면 된다"는 패턴 제시가 더 가치 있다
3. **코어 레이어가 미완성인데 편의 블록을 먼저 만드는 건 아닌가?** — P1~P4가 완성되기 전에 블록 카탈로그를 늘리는 건 우선순위 역전이다

---

## 7. 요약

| 구분 | 내용 |
|------|------|
| **비전** | AI가 업무를 빠르게 분석하고 파이프라인을 조합·실행하는 프레임워크 |
| **주 사용자** | AI 에이전트 (사람도 사용 가능하지만 설계 기준은 AI) |
| **코어** | 완성도 높음 — 유지하며 개선 |
| **블록 생태계** | 추가 기준 재정립 — 유스케이스 먼저 |
| **다음 과제** | AI 인터페이스 레이어 (BlockRegistry·호환성 검사·런처·피드백 루프) |

---

## 8. Zero-Ops Boundary (v0.1.3+)

`pylego.core` 는 **Builder 계층**이다.

`PipelineHealth`, `build_health_summary`, `CausalFactor` 등 진단·운영 도구는
**`pylego.ops.*`** 에서만 임포트한다.

`pylego.core.graph` 에서의 임포트는 **v1.0.0에서 제거**된다.

| 계층 | 패키지 | 역할 |
|------|--------|------|
| **Builder** | `pylego.core` / `pylego` | 블록·파이프라인 구성 |
| **Operator** | `pylego.ops` | 진단·비교·인과 분석 |

```python
# ✅ 권장 — Operator 계층 직접 임포트
from pylego.ops.health import PipelineHealth, build_health_summary
from pylego.ops.causal import CausalFactor
from pylego.ops.diff import HealthDiff

# ⚠️ 비권장 — v1.0.0에서 제거 예정 (DeprecationWarning 발생)
from pylego.core.graph import PipelineHealth  # deprecated
```

> **설계 원칙 59 — 경계 없는 설계는 책임 없는 설계다.**
> 하위 호환 브릿지는 경고와 함께 유지기한을 선언한다.
