# 시작하기

## 설치

```bash
pip install pylego-blocks
```

## 핵심 개념

pylego는 세 가지 기본 요소로 구성됩니다.

### Stud — I/O 계약

블록 사이에 오가는 데이터 타입입니다. pydantic `BaseModel`을 상속하며 `extra="forbid"`, `frozen=True`가 강제됩니다.

```python
from pylego import Stud

class Request(Stud):
    value: int

class Response(Stud):
    result: int
```

### Block — 실행 단위

`Block[Input, Output]`을 상속하고 `async def run()`을 구현합니다.

```python
from pylego import Block

class DoubleBlock(Block[Request, Response]):
    input_model = Request
    output_model = Response

    async def run(self, inp: Request) -> Response:
        return Response(result=inp.value * 2)
```

### Assembly — 체인 조립

블록 목록으로 파이프라인을 구성합니다. 조립 시점에 I/O 계약을 자동 검증합니다.

```python
from pylego import Assembly

pipeline = Assembly([DoubleBlock(), DoubleBlock()])
result = pipeline.run_sync(Request(value=3))
print(result.result)  # 12
```

---

## YAML 선언형 조립

```yaml
# pipeline.yaml
assembly:
  name: DoublePipeline
  blocks:
    - class: myapp.blocks.DoubleBlock
    - class: myapp.blocks.DoubleBlock
```

```bash
pylego assemble pipeline.yaml --dry-run
```

---

## HTTP API 서빙

`pylego[serve]` 설치 후:

```bash
pylego serve pipeline.yaml --port 8000
```

```bash
curl -X POST http://localhost:8000/run \
  -H "Content-Type: application/json" \
  -d '{"value": 5}'
# {"result": 20, "_meta": {"elapsed_sec": 0.001}}
```

---

## 다음 단계

- [튜토리얼 1: Hello World](tutorial/01-hello-world.md) — 첫 파이프라인 만들기
- [튜토리얼 5: 분산 파이프라인](tutorial/05-distributed.md) — Redis 큐 기반 분산 처리
- [API 레퍼런스](api/index.md) — 전체 API 문서
