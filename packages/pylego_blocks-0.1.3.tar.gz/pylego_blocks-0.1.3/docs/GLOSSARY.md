# pylego 용어 사전

pylego에서 사용하는 핵심 용어를 정의한다.

---

## Stud

**레고 대응:** 브릭의 돌기(stud)와 홈(tube) — 맞아야만 붙는 표준 인터페이스.

블록 간 경계에서 오가는 데이터의 타입. pydantic v2 `BaseModel`을 상속한다.

```python
class TextInput(Stud):
    text: str
```

**불변식:**
- `extra="forbid"`: 선언되지 않은 필드 거부.
- `frozen=True`: 생성 후 변경 불가 (값 의미론).

모든 블록의 입력과 출력은 반드시 `Stud` 서브클래스여야 한다.

---

## Block

**레고 대응:** 단일 브릭 — 단일 책임, 단독 조립 가능한 최소 단위.

`Block[InputT, OutputT]`를 상속해 정의한다. `input_model`, `output_model`, `async def run()`을 반드시 선언해야 한다.

```python
class UpperBlock(Block[TextInput, TextOutput]):
    input_model = TextInput
    output_model = TextOutput

    async def run(self, inp: TextInput) -> TextOutput:
        return TextOutput(text=inp.text.upper())
```

블록은 다른 블록의 내부를 참조하지 않는다. 외부 의존은 생성자 주입으로 받는다.

---

## Assembly

**레고 대응:** Plate — 여러 브릭을 붙인 중간 조립체. 외부에선 하나의 브릭처럼 보인다.

블록 리스트를 선형으로 체인한 조립체. `Assembly` 자체도 `Block`이므로 다른 `Assembly`에 포함할 수 있다 (재귀적 합성).

```python
pipeline = Assembly([UpperBlock(), LengthBlock()])
result = pipeline.run_sync(TextInput(text="hello"))
```

조립 시점에 인접 블록의 `output_model ↔ input_model` 일치를 검증한다. 불일치 시 `IncompatibleSnapError`.

---

## Snap

블록과 블록이 연결되는 행위. `prev.output_model is nxt.input_model`이 참이어야 스냅이 성립한다.

`Assembly` 생성 시 자동으로 검증되며, 실패하면 즉시 에러를 발생시킨다.

---

## FanOut

**레고 대응:** 팬 모양 조각 — 하나의 입력이 여러 방향으로 나뉘는 구조.

동일한 입력을 N개 브랜치에 동시에 전달하고 `asyncio.gather`로 병렬 실행한다. 결과는 `Gathered`로 묶인다.

```python
fan = FanOut([BranchA(), BranchB(), BranchC()])
result: Gathered = await fan.run(inp)
# result.results == (outA, outB, outC)
```

최소 2개 브랜치 필요. 모든 브랜치의 `input_model`이 동일해야 한다.

---

## Gathered

`FanOut`의 출력 타입. 각 브랜치의 결과를 선언 순서대로 보관하는 `Stud` 서브클래스.

```python
class Gathered(Stud):
    results: tuple[Any, ...]
```

---

## Branch

**레고 대응:** 철도 전환기 — 조건에 따라 두 방향 중 하나로 진행.

`predicate(inp)` 결과에 따라 `on_true` 또는 `on_false` 블록을 실행한다.

```python
branch = Branch(
    predicate=lambda inp: inp.value > 0,
    on_true=PositiveBlock(),
    on_false=NegativeBlock(),
)
```

`on_true`와 `on_false`는 `input_model`, `output_model`이 모두 동일해야 한다.

---

## BlockRegistry

**레고 대응:** 레고 카탈로그 — 이름으로 브릭을 찾는다.

블록 클래스를 이름으로 등록하고 조회하는 레지스트리.

```python
@register
class MyBlock(Block[A, B]): ...

cls = default_registry.get("MyBlock")
all_blocks = default_registry.all()
default_registry.load_entry_points("pylego.blocks")
```

`register(cls)`는 `cls`를 그대로 반환하므로 데코레이터·직접 호출 양쪽에서 사용 가능하다.

---

## IncompatibleSnapError

스냅이 성립하지 않을 때 발생하는 예외. `Assembly` 조립 시점에 발생한다.

```
prev.output_model != nxt.input_model → IncompatibleSnapError
```

---

## CyclicAssemblyError

`Assembly` 구성 시 순환 참조 또는 중복 인스턴스가 감지되면 발생하는 예외. `IncompatibleSnapError`의 서브클래스.

두 가지 경우에 발생:
- 동일 블록 인스턴스가 두 번 포함된 경우 (`Assembly([b, b])`)
- 중첩 Assembly에서 DFS 사이클이 발견된 경우

---

## run_sync

`Assembly.run_sync(inp)`의 약칭. `asyncio.run(self.run(inp))`의 얇은 래퍼.

동기 컨텍스트(스크립트, 테스트)에서 비동기 파이프라인을 실행할 때 사용한다. 이미 실행 중인 이벤트 루프가 있으면 사용할 수 없다.

---

## load_assembly

YAML 파일에서 `Assembly`를 로드하는 함수. `pylego.declarative` 모듈에 있다.

```python
from pylego.declarative import load_assembly
pipeline = load_assembly("pipeline.yaml")
```

블록 참조 형식: `"module.ClassName"`, `"module:ClassName"`, `"ClassName"` (레지스트리).

---

## Stud 계약 (Stud Contract)

블록이 선언하는 `input_model`과 `output_model`의 쌍. "이 블록은 X를 받아 Y를 반환한다"는 명시적 약속이다.

계약은 조립 시점에 기계적으로 검증된다. 계약이 맞는 블록끼리만 스냅할 수 있다.
