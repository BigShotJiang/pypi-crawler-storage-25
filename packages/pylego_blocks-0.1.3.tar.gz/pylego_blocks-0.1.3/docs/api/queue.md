# Queue & WorkerPool

## Queue

::: pylego.core.queue.Queue

---

## WorkerPool

::: pylego.core.queue.WorkerPool

---

## DeadLetterQueue

::: pylego.core.queue.DeadLetterQueue

---

## RedisQueue

```bash
pip install pylego-blocks[redis]
```

::: pylego.core.redis_queue.RedisQueue

---

## RedisWorkerPool

::: pylego.core.redis_queue.RedisWorkerPool

---

## RedisDeadLetterQueue

::: pylego.core.redis_queue.RedisDeadLetterQueue

---

## make_queue

::: pylego.core.redis_queue.make_queue
