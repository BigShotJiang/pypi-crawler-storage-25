# Block & Stud

## Stud

::: pylego.core.stud.Stud

---

## Block

::: pylego.core.block.Block

---

## 사용 예시

```python
from pylego import Block, Stud

class MyInput(Stud):
    value: int

class MyOutput(Stud):
    result: str

class MyBlock(Block[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput

    async def run(self, inp: MyInput) -> MyOutput:
        return MyOutput(result=str(inp.value * 2))
```
