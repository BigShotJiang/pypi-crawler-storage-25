# HTTP API (serve)

```bash
pip install pylego-blocks[serve]
```

## build_app

::: pylego.serve.build_app

---

## serve

::: pylego.serve.serve

---

## CLI

```bash
pylego serve pipeline.yaml --host 0.0.0.0 --port 8000
pylego serve pipeline.yaml --reload  # 개발 모드 자동 재시작
```

## 엔드포인트

| 경로 | 메서드 | 설명 |
|------|--------|------|
| `/run` | POST | Assembly 실행 (Stud JSON → Stud JSON) |
| `/health` | GET | 헬스체크 (assembly 이름, 모델명) |
| `/openapi.json` | GET | OpenAPI 스키마 자동 생성 |
| `/docs` | GET | Swagger UI |

## 예시

```bash
# 서버 시작
pylego serve pipeline.yaml --port 8000

# 실행 요청
curl -X POST http://localhost:8000/run \
  -H "Content-Type: application/json" \
  -d '{"value": 42}'
# {"result": 84, "_meta": {"elapsed_sec": 0.0012}}

# 헬스체크
curl http://localhost:8000/health
# {"status": "ok", "assembly": "MyPipeline", "input_model": "MyInput", "output_model": "MyOutput"}
```
