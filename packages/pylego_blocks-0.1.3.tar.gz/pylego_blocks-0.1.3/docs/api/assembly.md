# Assembly

::: pylego.core.assembly.Assembly

---

## FanOut

::: pylego.core.fanout.FanOut

---

## Branch

::: pylego.core.branch.Branch

---

## 시각화

```python
from pylego import Assembly, to_mermaid, to_dot, to_html

pipeline = Assembly([BlockA(), BlockB()])

# Mermaid
print(to_mermaid(pipeline))

# DOT (Graphviz)
print(to_dot(pipeline))

# HTML 리포트
html = to_html(pipeline)
```

::: pylego.core.graph.to_mermaid

::: pylego.core.graph.to_dot

::: pylego.core.graph.to_html
