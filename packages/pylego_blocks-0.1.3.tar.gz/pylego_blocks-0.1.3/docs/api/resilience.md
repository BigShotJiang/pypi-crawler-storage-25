# Resilience (에러 복구)

## RetryPolicy

::: pylego.core.resilience.RetryPolicy

---

## RetryBlock

::: pylego.core.resilience.RetryBlock

---

## FallbackBlock

::: pylego.core.resilience.FallbackBlock

---

## TimeoutBlock

::: pylego.core.resilience.TimeoutBlock

---

## CircuitBreakerBlock

::: pylego.core.resilience.CircuitBreakerBlock
