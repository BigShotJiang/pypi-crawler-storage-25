# 튜토리얼 3: 에러 복구

RetryBlock, FallbackBlock, CircuitBreakerBlock, TimeoutBlock으로 견고한 파이프라인을 만듭니다.

## RetryBlock

일시적 실패 시 자동 재시도합니다.

```python
from pylego import RetryBlock, RetryPolicy, Block, Assembly, Stud

class ApiIn(Stud):
    query: str

class ApiOut(Stud):
    answer: str

class FlakyApiBlock(Block[ApiIn, ApiOut]):
    input_model = ApiIn
    output_model = ApiOut
    _call_count = 0

    async def run(self, inp: ApiIn) -> ApiOut:
        self._call_count += 1
        if self._call_count < 3:
            raise ConnectionError("일시적 연결 오류")
        return ApiOut(answer=f"result for {inp.query}")

# 최대 5회, 초기 1초 대기, 2배 백오프
policy = RetryPolicy(max_attempts=5, delay_sec=1.0, backoff=2.0)
resilient = RetryBlock(FlakyApiBlock(), policy=policy)

pipeline = Assembly([resilient])
result = pipeline.run_sync(ApiIn(query="test"))
print(result.answer)  # result for test
```

## FallbackBlock

primary 실패 시 fallback으로 전환합니다.

```python
from pylego import FallbackBlock

class CachedBlock(Block[ApiIn, ApiOut]):
    input_model = ApiIn
    output_model = ApiOut
    async def run(self, inp: ApiIn) -> ApiOut:
        return ApiOut(answer="cached answer")

# primary 실패 → cached 반환
safe = FallbackBlock(primary=FlakyApiBlock(), fallback=CachedBlock())
```

## TimeoutBlock

블록 단위 타임아웃을 설정합니다.

```python
from pylego import TimeoutBlock

# 2초 초과 시 TimeoutError
timed = TimeoutBlock(FlakyApiBlock(), timeout_sec=2.0)
```

## CircuitBreakerBlock

연속 실패 시 빠른 실패(fast-fail)로 전환하고 일정 시간 후 복구합니다.

```python
from pylego import CircuitBreakerBlock

# 3번 연속 실패 → circuit OPEN (fast-fail)
# 10초 후 → circuit HALF-OPEN (1회 시도)
breaker = CircuitBreakerBlock(
    FlakyApiBlock(),
    failure_threshold=3,
    reset_timeout=10.0,
)
```

## DeadLetterQueue

최종 실패 항목을 격리합니다.

```python
from pylego import DeadLetterQueue, Queue, WorkerPool

dlq: DeadLetterQueue[ApiIn] = DeadLetterQueue()

async def process_with_dlq(item: ApiIn) -> None:
    try:
        await resilient.run(item)
    except Exception as e:
        await dlq.put_failed(item, reason=str(e))

# 재처리
retry_q: Queue[ApiIn] = Queue()
async for item, reason in dlq.failed_items():
    print(f"실패 원인: {reason}")
    await dlq.retry(item, retry_q)
```

## 다음

[튜토리얼 4: 관찰 가능성 →](04-observability.md)
