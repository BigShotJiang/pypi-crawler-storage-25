# 7. 알림 블록 — Telegram / Gmail

파이프라인 실행 결과를 외부 채널로 전달하는 알림 블록입니다.
두 블록 모두 `TapBlock` 과 함께 사용하면 파이프라인 흐름을 방해하지 않고
사이드 채널 알림을 보낼 수 있습니다.

---

## 설치

```bash
pip install pylego-blocks[telegram]   # TelegramBlock
pip install pylego-blocks[gmail]      # GmailBlock
pip install pylego-blocks[telegram,gmail]  # 둘 다
```

---

## TelegramBlock

Telegram Bot API `sendMessage` 를 통해 메시지를 전송합니다.

### Stud 계약

```python
class TelegramInput(Stud):
    chat_id: str        # 수신 채팅 ID (사용자 또는 그룹)
    text: str           # 메시지 내용
    parse_mode: str     # "HTML" (기본) | "Markdown" | "MarkdownV2"

class TelegramResult(Stud):
    message_id: int     # 전송된 메시지 ID
    chat_id: str        # 실제 전송된 채팅 ID
```

### 설정 주입

| 방법 | 코드 |
|------|------|
| 생성자 직접 주입 | `TelegramBlock(token="BOT_TOKEN")` |
| 환경변수 | `PYLEGO_TELEGRAM_TOKEN=BOT_TOKEN` |

```python
from pylego import TelegramBlock, TelegramInput

# 생성자 주입
block = TelegramBlock(token="1234567890:AAF...")

# 환경변수 (token 인수 생략)
# export PYLEGO_TELEGRAM_TOKEN="1234567890:AAF..."
block = TelegramBlock()
```

### 기본 사용

```python
from pylego import TelegramBlock, TelegramInput

block = TelegramBlock(token="BOT_TOKEN")
result = await block.run(TelegramInput(
    chat_id="123456789",
    text="<b>파이프라인 완료</b>",
    parse_mode="HTML",
))
print(result.message_id)  # 전송된 메시지 ID
```

### 파이프라인 사이드채널 알림

```python
from pylego import Assembly, TapBlock, TelegramBlock

# 파이프라인 흐름 유지 — 알림 실패는 무시됨(기본값)
pipeline = Assembly([
    ProcessBlock(),
    TapBlock(TelegramBlock(token="BOT_TOKEN")),
    NextBlock(),
])

# 알림 실패를 파이프라인 오류로 처리하려면
TapBlock(TelegramBlock(token="BOT_TOKEN"), ignore_errors=False)
```

### 재시도 포함

```python
from pylego import RetryBlock, RetryPolicy, TelegramBlock

resilient = RetryBlock(
    TelegramBlock(token="BOT_TOKEN"),
    policy=RetryPolicy(max_attempts=3, delay_sec=1.0),
)
```

---

## GmailBlock

Gmail SMTP(STARTTLS, port 587)를 통해 이메일을 전송합니다.
Gmail **앱 비밀번호**를 사용합니다 (계정 비밀번호 아님).

> **앱 비밀번호 발급:**
> Google 계정 → 보안 → 2단계 인증 활성화 후
> 앱 비밀번호 → 앱: 메일, 기기: 기타 → 생성

### Stud 계약

```python
class GmailInput(Stud):
    to: str             # 수신자 이메일 주소
    subject: str        # 제목
    body: str           # 본문 (plain text 또는 HTML)
    html: bool          # True 시 HTML 본문 (기본: False)

class GmailResult(Stud):
    accepted: list[str] # 전송 수락된 수신자 목록
```

### 설정 주입

| 방법 | 코드 |
|------|------|
| 생성자 직접 주입 | `GmailBlock(smtp_user="...", smtp_password="...")` |
| 환경변수 | `PYLEGO_GMAIL_USER` / `PYLEGO_GMAIL_PASSWORD` |

```python
from pylego import GmailBlock

# 생성자 주입
block = GmailBlock(
    smtp_user="myapp@gmail.com",
    smtp_password="abcd efgh ijkl mnop",  # 앱 비밀번호 (공백 포함 가능)
)

# 환경변수
# export PYLEGO_GMAIL_USER="myapp@gmail.com"
# export PYLEGO_GMAIL_PASSWORD="abcd efgh ijkl mnop"
block = GmailBlock()
```

### 기본 사용

```python
from pylego import GmailBlock, GmailInput

block = GmailBlock(smtp_user="sender@gmail.com", smtp_password="APP_PW")

# plain text
result = await block.run(GmailInput(
    to="receiver@example.com",
    subject="파이프라인 완료",
    body="처리가 완료되었습니다.",
))

# HTML 메일
result = await block.run(GmailInput(
    to="receiver@example.com",
    subject="파이프라인 완료",
    body="<h1>완료</h1><p>처리가 <b>완료</b>되었습니다.</p>",
    html=True,
))
```

### 파이프라인 사이드채널 알림

```python
from pylego import Assembly, GmailBlock, TapBlock

pipeline = Assembly([
    ProcessBlock(),
    TapBlock(GmailBlock(smtp_user="s@gmail.com", smtp_password="APP_PW")),
])
```

---

## 두 채널 동시 알림

```python
from pylego import Assembly, FanOut, GmailBlock, TapBlock, TelegramBlock

# FanOut 으로 Telegram + Gmail 병렬 전송
# (입출력 Stud 가 다르므로 각각 TapBlock 으로 분리)
pipeline = Assembly([
    ProcessBlock(),                                        # 결과 생성
    TapBlock(TelegramNotifyBlock()),                       # Telegram 변환 + 전송
    TapBlock(GmailNotifyBlock()),                          # Gmail 변환 + 전송
])
```

---

## 환경변수 일람

| 변수 | 블록 | 설명 |
|------|------|------|
| `PYLEGO_TELEGRAM_TOKEN` | `TelegramBlock` | Bot API 토큰 |
| `PYLEGO_GMAIL_USER` | `GmailBlock` | Gmail 계정 주소 |
| `PYLEGO_GMAIL_PASSWORD` | `GmailBlock` | Gmail 앱 비밀번호 |
