# 튜토리얼 4: 관찰 가능성

로깅, OpenTelemetry, DAG 시각화로 파이프라인을 투명하게 만듭니다.

## 구조화 로깅

```python
import os
from pylego import Assembly, observe, LoggingEventBus

os.environ["PYLEGO_LOG_LEVEL"] = "DEBUG"

# 또는 명시적으로 이벤트 버스 지정
with observe(LoggingEventBus()):
    result = await pipeline.run(inp)
    # 각 블록의 진입·완료·소요시간이 로그에 기록됨
```

## CollectingEventBus — 이벤트 수집

```python
from pylego import CollectingEventBus, observe, build_stats

bus = CollectingEventBus()
with observe(bus):
    result = await pipeline.run(inp)

stats = build_stats(bus.events)
for name, stat in stats.items():
    print(f"{name}: {stat.status} ({stat.elapsed_sec:.3f}s)")
```

## OpenTelemetry 통합

```bash
pip install pylego-blocks[otel]
```

```python
from pylego import configure_otel_from_env, OtelEventBus, observe
import os

# 환경변수로 OTLP 익스포터 설정
os.environ["PYLEGO_OTEL_ENDPOINT"] = "http://localhost:4318"
os.environ["PYLEGO_OTEL_SERVICE_NAME"] = "my-pipeline"
configure_otel_from_env()

with observe(OtelEventBus()):
    result = await pipeline.run(inp)
    # Jaeger / Grafana Tempo 등에서 trace 확인 가능
```

## DAG 시각화

```python
from pylego import Assembly, to_mermaid, to_dot, to_html

pipeline = Assembly([BlockA(), BlockB(), BlockC()])

# Mermaid 플로우차트
print(to_mermaid(pipeline))

# Graphviz DOT
print(to_dot(pipeline))

# 실행 통계 포함 HTML 리포트
bus = CollectingEventBus()
with observe(bus):
    result = await pipeline.run(inp)

html = to_html(pipeline, stats=build_stats(bus.events))
with open("report.html", "w") as f:
    f.write(html)
```

```bash
# CLI로 그래프 출력
pylego inspect graph pipeline.yaml --format mermaid
pylego inspect graph pipeline.yaml --format html --output report.html
```

## 다음

[튜토리얼 5: 분산 파이프라인 →](05-distributed.md)
