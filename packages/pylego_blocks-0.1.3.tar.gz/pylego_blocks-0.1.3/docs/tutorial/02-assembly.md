# 튜토리얼 2: Assembly 체인

Assembly를 중첩하고 FanOut으로 병렬 분기하는 방법을 알아봅니다.

## 중첩 Assembly

Assembly 자체가 Block과 동일한 인터페이스를 가집니다. Assembly를 다른 Assembly에 넣을 수 있습니다.

```python
from pylego import Assembly, Block, Stud

class Num(Stud):
    value: int

class AddOneBlock(Block[Num, Num]):
    input_model = output_model = Num
    async def run(self, inp: Num) -> Num:
        return Num(value=inp.value + 1)

# 서브 Assembly
add_two = Assembly([AddOneBlock(), AddOneBlock()], name="AddTwo")

# 메인 Assembly에 서브 Assembly 삽입
pipeline = Assembly([add_two, AddOneBlock()], name="AddThree")
result = pipeline.run_sync(Num(value=0))
print(result.value)  # 3
```

## FanOut — 병렬 분기

```python
from pylego import FanOut, Gathered, Stud

class Score(Stud):
    value: float

class Label(Stud):
    tag: str

class NormalizeBlock(Block[Score, Score]):
    input_model = output_model = Score
    async def run(self, inp: Score) -> Score:
        return Score(value=round(inp.value / 100, 2))

class ClassifyBlock(Block[Score, Label]):
    input_model = Score
    output_model = Label
    async def run(self, inp: Score) -> Label:
        return Label(tag="high" if inp.value >= 0.7 else "low")

# FanOut: 동일 입력을 두 블록에 병렬 전달
fan = FanOut([NormalizeBlock(), ClassifyBlock()])
result = fan.run_sync(Score(value=85.0))
# result.results = (Score(value=0.85), Label(tag="high"))
print(result.results)
```

## YAML 조립

```yaml
assembly:
  name: ScoringPipeline
  blocks:
    - class: myapp.blocks.NormalizeBlock
    - class: myapp.blocks.ClassifyBlock
```

## Branch — 조건 분기

```python
from pylego import Branch

class Flag(Stud):
    enabled: bool
    value: int

def selector(inp: Flag) -> int:
    return 0 if inp.enabled else 1

branch = Branch(selector, [DoubleBlock(), TripleBlock()])
```

## 다음

[튜토리얼 3: 에러 복구 →](03-resilience.md)
