"""M15 CircuitBreakerBlock 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego.core.assembly import Assembly
from pylego.core.block import Block
from pylego.core.events import CircuitBreakerStateEvent, observe
from pylego.core.resilience import CircuitBreakerBlock, CircuitOpenError
from pylego.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _In(Stud):
    value: int


class _Out(Stud):
    result: int


class _DoubleBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.value * 2)


class _AlwaysFailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("항상 실패")


class _FailNTimesBlock(Block[_In, _Out]):
    """처음 n 번 실패 후 성공하는 블록."""

    input_model = _In
    output_model = _Out

    def __init__(self, fail_times: int) -> None:
        self._fail_times = fail_times
        self._calls = 0

    async def run(self, inp: _In) -> _Out:
        self._calls += 1
        if self._calls <= self._fail_times:
            raise RuntimeError(f"의도된 실패 #{self._calls}")
        return _Out(result=inp.value)


class _CollectorBus:
    def __init__(self) -> None:
        self.events: list[object] = []

    def emit(self, event: object) -> None:
        self.events.append(event)


# ── 생성 검증 ────────────────────────────────────────────────────────────────


class TestCircuitBreakerBlockInit:
    def test_initial_state_is_closed(self) -> None:
        cb = CircuitBreakerBlock(_DoubleBlock())
        assert cb.state == "closed"

    def test_inherits_inner_models(self) -> None:
        cb = CircuitBreakerBlock(_DoubleBlock())
        assert cb.input_model is _In
        assert cb.output_model is _Out

    def test_name_includes_inner(self) -> None:
        cb = CircuitBreakerBlock(_DoubleBlock())
        assert "_DoubleBlock" in cb.name

    def test_invalid_threshold_raises(self) -> None:
        with pytest.raises(ValueError, match="failure_threshold"):
            CircuitBreakerBlock(_DoubleBlock(), failure_threshold=0)

    def test_invalid_reset_timeout_raises(self) -> None:
        with pytest.raises(ValueError, match="reset_timeout"):
            CircuitBreakerBlock(_DoubleBlock(), reset_timeout=0.0)

    def test_negative_reset_timeout_raises(self) -> None:
        with pytest.raises(ValueError, match="reset_timeout"):
            CircuitBreakerBlock(_DoubleBlock(), reset_timeout=-1.0)


# ── closed 상태 정상 동작 ──────────────────────────────────────────────────


class TestCircuitBreakerClosed:
    def test_success_in_closed_state(self) -> None:
        cb = CircuitBreakerBlock(_DoubleBlock(), failure_threshold=3)
        asm: Assembly[_In, _Out] = Assembly([cb])
        result = asm.run_sync(_In(value=5))
        assert result.result == 10
        assert cb.state == "closed"

    def test_single_failure_stays_closed(self) -> None:
        cb = CircuitBreakerBlock(_AlwaysFailBlock(), failure_threshold=3)
        with pytest.raises(RuntimeError):
            asyncio.run(cb.run(_In(value=1)))
        assert cb.state == "closed"

    def test_failure_count_resets_after_success(self) -> None:
        inner = _FailNTimesBlock(fail_times=2)
        cb = CircuitBreakerBlock(inner, failure_threshold=5)
        with pytest.raises(RuntimeError):
            asyncio.run(cb.run(_In(value=1)))
        with pytest.raises(RuntimeError):
            asyncio.run(cb.run(_In(value=1)))
        # 성공 시 카운트 리셋
        result = asyncio.run(cb.run(_In(value=4)))
        assert result.result == 4
        assert cb.state == "closed"


# ── closed → open 전이 ────────────────────────────────────────────────────


class TestCircuitBreakerOpens:
    def test_opens_after_threshold_failures(self) -> None:
        cb = CircuitBreakerBlock(_AlwaysFailBlock(), failure_threshold=3)
        for _ in range(3):
            with pytest.raises(RuntimeError):
                asyncio.run(cb.run(_In(value=1)))
        assert cb.state == "open"

    def test_fast_fail_when_open(self) -> None:
        cb = CircuitBreakerBlock(_AlwaysFailBlock(), failure_threshold=2)
        for _ in range(2):
            with pytest.raises(RuntimeError):
                asyncio.run(cb.run(_In(value=1)))
        assert cb.state == "open"
        with pytest.raises(CircuitOpenError):
            asyncio.run(cb.run(_In(value=1)))

    def test_state_event_emitted_on_open(self) -> None:
        bus = _CollectorBus()
        cb = CircuitBreakerBlock(_AlwaysFailBlock(), failure_threshold=2)
        with observe(bus):  # type: ignore[arg-type]
            for _ in range(2):
                with pytest.raises(RuntimeError):
                    asyncio.run(cb.run(_In(value=1)))
        state_events = [
            e for e in bus.events if isinstance(e, CircuitBreakerStateEvent)
        ]
        assert any(e.new_state == "open" for e in state_events)


# ── open → half-open → closed 전이 ────────────────────────────────────────


class TestCircuitBreakerHalfOpen:
    @pytest.mark.asyncio
    async def test_transitions_to_half_open_after_timeout(self) -> None:
        cb = CircuitBreakerBlock(
            _AlwaysFailBlock(), failure_threshold=2, reset_timeout=0.01
        )
        for _ in range(2):
            with pytest.raises(RuntimeError):
                await cb.run(_In(value=1))
        assert cb.state == "open"

        await asyncio.sleep(0.05)
        # 다음 호출 시 half-open 로 전환 후 즉시 실패 → 다시 open
        with pytest.raises(RuntimeError):
            await cb.run(_In(value=1))
        assert cb.state == "open"

    @pytest.mark.asyncio
    async def test_recovers_to_closed_after_success(self) -> None:
        inner = _FailNTimesBlock(fail_times=2)
        cb = CircuitBreakerBlock(inner, failure_threshold=2, reset_timeout=0.01)
        for _ in range(2):
            with pytest.raises(RuntimeError):
                await cb.run(_In(value=1))
        assert cb.state == "open"

        await asyncio.sleep(0.05)
        # half-open 에서 성공하면 closed 복구
        result = await cb.run(_In(value=7))
        assert result.result == 7
        assert cb.state == "closed"

    @pytest.mark.asyncio
    async def test_state_event_emitted_on_closed_recovery(self) -> None:
        bus = _CollectorBus()
        inner = _FailNTimesBlock(fail_times=2)
        cb = CircuitBreakerBlock(inner, failure_threshold=2, reset_timeout=0.01)
        with observe(bus):  # type: ignore[arg-type]
            for _ in range(2):
                with pytest.raises(RuntimeError):
                    await cb.run(_In(value=1))
            await asyncio.sleep(0.05)
            await cb.run(_In(value=3))

        state_events = [
            e for e in bus.events if isinstance(e, CircuitBreakerStateEvent)
        ]
        states = [(e.previous_state, e.new_state) for e in state_events]
        assert ("closed", "open") in states
        assert ("half-open", "closed") in states


# ── Assembly 통합 ─────────────────────────────────────────────────────────


class TestCircuitBreakerInAssembly:
    def test_normal_flow_in_assembly(self) -> None:
        cb = CircuitBreakerBlock(_DoubleBlock(), failure_threshold=3)
        asm: Assembly[_In, _Out] = Assembly([cb])
        result = asm.run_sync(_In(value=3))
        assert result.result == 6

    def test_open_circuit_propagates_in_assembly(self) -> None:
        cb = CircuitBreakerBlock(_AlwaysFailBlock(), failure_threshold=2)
        asm: Assembly[_In, _Out] = Assembly([cb])
        for _ in range(2):
            with pytest.raises(RuntimeError):
                asm.run_sync(_In(value=1))
        with pytest.raises(CircuitOpenError):
            asm.run_sync(_In(value=1))
