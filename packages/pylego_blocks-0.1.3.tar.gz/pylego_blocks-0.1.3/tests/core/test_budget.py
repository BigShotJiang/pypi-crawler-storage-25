"""ExecutionBudget 테스트."""

from __future__ import annotations

import asyncio
import time

import pytest

from pylego import Assembly, BudgetExceededError, ExecutionBudget, Stud, observe
from pylego.core.block import Block
from pylego.core.events import BlockCompletedEvent, BlockFailedEvent, BlockRetryEvent


# ---------------------------------------------------------------------------
# 픽스처 블록
# ---------------------------------------------------------------------------


class Num(Stud):
    value: int


class PassBlock(Block[Num, Num]):
    input_model = Num
    output_model = Num

    async def run(self, inp: Num) -> Num:
        return Num(value=inp.value + 1)


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_requires_at_least_one_limit() -> None:
    with pytest.raises(ValueError, match="하나 이상"):
        ExecutionBudget()


def test_max_block_calls_zero_invalid() -> None:
    with pytest.raises(ValueError, match="1 이상"):
        ExecutionBudget(max_block_calls=0)


def test_max_total_seconds_zero_invalid() -> None:
    with pytest.raises(ValueError, match="0 보다"):
        ExecutionBudget(max_total_seconds=0.0)


def test_max_total_seconds_negative_invalid() -> None:
    with pytest.raises(ValueError, match="0 보다"):
        ExecutionBudget(max_total_seconds=-1.0)


def test_valid_only_max_block_calls() -> None:
    b = ExecutionBudget(max_block_calls=5)
    assert b.call_count == 0


def test_valid_only_max_total_seconds() -> None:
    b = ExecutionBudget(max_total_seconds=10.0)
    assert b.call_count == 0


def test_valid_both_limits() -> None:
    b = ExecutionBudget(max_block_calls=5, max_total_seconds=10.0)
    assert b.call_count == 0


# ---------------------------------------------------------------------------
# emit() — 비-BlockStartedEvent 무시
# ---------------------------------------------------------------------------


def test_non_started_events_ignored() -> None:
    b = ExecutionBudget(max_block_calls=1)
    from pylego.core.events import BlockStartedEvent

    started = BlockStartedEvent(block_name="X", input=None)
    b.emit(started)

    completed = BlockCompletedEvent(block_name="X", output=None, elapsed_sec=0.1)
    b.emit(completed)  # 무시

    failed = BlockFailedEvent(block_name="X", error=RuntimeError(), elapsed_sec=0.1)
    b.emit(failed)  # 무시

    retry = BlockRetryEvent(
        block_name="X", attempt=1, max_attempts=3, error=RuntimeError(), delay_sec=0.0
    )
    b.emit(retry)  # 무시

    assert b.call_count == 1  # started 하나만 카운트


# ---------------------------------------------------------------------------
# call_count 초과
# ---------------------------------------------------------------------------


def test_call_count_within_limit_ok() -> None:
    b = ExecutionBudget(max_block_calls=3)
    from pylego.core.events import BlockStartedEvent

    for _ in range(3):
        b.emit(BlockStartedEvent(block_name="X", input=None))
    assert b.call_count == 3


def test_call_count_exceeded_raises() -> None:
    b = ExecutionBudget(max_block_calls=3)
    from pylego.core.events import BlockStartedEvent

    for _ in range(3):
        b.emit(BlockStartedEvent(block_name="X", input=None))

    with pytest.raises(BudgetExceededError, match="block call limit exceeded"):
        b.emit(BlockStartedEvent(block_name="X", input=None))


def test_call_count_one_limit() -> None:
    b = ExecutionBudget(max_block_calls=1)
    from pylego.core.events import BlockStartedEvent

    b.emit(BlockStartedEvent(block_name="X", input=None))
    with pytest.raises(BudgetExceededError):
        b.emit(BlockStartedEvent(block_name="X", input=None))


# ---------------------------------------------------------------------------
# 시간 초과
# ---------------------------------------------------------------------------


def test_time_exceeded_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """단조 시계를 모킹하여 시간 초과를 시뮬레이션."""
    from pylego.core.events import BlockStartedEvent
    import pylego.core.budget as budget_module

    calls: list[float] = [0.0, 100.0]
    idx = 0

    def fake_monotonic() -> float:
        nonlocal idx
        val = calls[idx]
        idx = min(idx + 1, len(calls) - 1)
        return val

    monkeypatch.setattr(budget_module.time, "monotonic", fake_monotonic)

    b = ExecutionBudget(max_total_seconds=10.0)
    b.emit(BlockStartedEvent(block_name="X", input=None))  # start_time = 0.0

    with pytest.raises(BudgetExceededError, match="time budget exceeded"):
        b.emit(BlockStartedEvent(block_name="Y", input=None))  # elapsed = 100.0


def test_time_within_limit_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    from pylego.core.events import BlockStartedEvent
    import pylego.core.budget as budget_module

    calls: list[float] = [0.0, 5.0]
    idx = 0

    def fake_monotonic() -> float:
        nonlocal idx
        val = calls[idx]
        idx = min(idx + 1, len(calls) - 1)
        return val

    monkeypatch.setattr(budget_module.time, "monotonic", fake_monotonic)

    b = ExecutionBudget(max_total_seconds=10.0)
    b.emit(BlockStartedEvent(block_name="X", input=None))
    b.emit(BlockStartedEvent(block_name="Y", input=None))  # elapsed=9.9 < 10.0
    assert b.call_count == 2


# ---------------------------------------------------------------------------
# reset()
# ---------------------------------------------------------------------------


def test_reset_clears_state() -> None:
    from pylego.core.events import BlockStartedEvent

    b = ExecutionBudget(max_block_calls=2)
    b.emit(BlockStartedEvent(block_name="X", input=None))
    b.emit(BlockStartedEvent(block_name="Y", input=None))
    assert b.call_count == 2

    b.reset()
    assert b.call_count == 0
    assert b.elapsed_seconds == 0.0

    b.emit(BlockStartedEvent(block_name="X", input=None))
    assert b.call_count == 1


def test_reset_allows_reuse() -> None:
    from pylego.core.events import BlockStartedEvent

    b = ExecutionBudget(max_block_calls=1)
    b.emit(BlockStartedEvent(block_name="X", input=None))
    with pytest.raises(BudgetExceededError):
        b.emit(BlockStartedEvent(block_name="X", input=None))

    b.reset()
    b.emit(BlockStartedEvent(block_name="X", input=None))  # 초기화 후 성공
    assert b.call_count == 1


# ---------------------------------------------------------------------------
# elapsed_seconds
# ---------------------------------------------------------------------------


def test_elapsed_seconds_zero_before_first_emit() -> None:
    b = ExecutionBudget(max_block_calls=5)
    assert b.elapsed_seconds == 0.0


def test_elapsed_seconds_positive_after_emit() -> None:
    from pylego.core.events import BlockStartedEvent

    b = ExecutionBudget(max_block_calls=5)
    b.emit(BlockStartedEvent(block_name="X", input=None))
    assert b.elapsed_seconds >= 0.0


# ---------------------------------------------------------------------------
# Assembly 통합
# ---------------------------------------------------------------------------


async def test_assembly_budget_exceeded() -> None:
    pipeline = Assembly([PassBlock(), PassBlock(), PassBlock()])

    budget = ExecutionBudget(max_block_calls=2)
    with pytest.raises(BudgetExceededError):
        with observe(budget):
            await pipeline.run(Num(value=0))


async def test_assembly_within_budget() -> None:
    pipeline = Assembly([PassBlock(), PassBlock()])

    budget = ExecutionBudget(max_block_calls=2)
    with observe(budget):
        result = await pipeline.run(Num(value=0))
    assert result.value == 2
    assert budget.call_count == 2


async def test_assembly_budget_reset_between_runs() -> None:
    pipeline = Assembly([PassBlock()])

    budget = ExecutionBudget(max_block_calls=1)

    with observe(budget):
        result = await pipeline.run(Num(value=0))
    assert result.value == 1

    budget.reset()

    with observe(budget):
        result = await pipeline.run(Num(value=10))
    assert result.value == 11


async def test_budget_exception_propagates_from_assembly() -> None:
    """BudgetExceededError 가 Assembly 를 통해 전파되어야 한다."""
    pipeline = Assembly([PassBlock(), PassBlock(), PassBlock(), PassBlock()])

    budget = ExecutionBudget(max_block_calls=3)
    with pytest.raises(BudgetExceededError):
        with observe(budget):
            await pipeline.run(Num(value=0))
