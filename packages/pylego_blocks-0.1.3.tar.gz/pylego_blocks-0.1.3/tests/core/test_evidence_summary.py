"""M96 — Evidence-Based to_ai_summary() 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego import Assembly, Block, Stud, observe
from pylego.core.events import BlockFailedEvent, CollectingEventBus
from pylego.core.graph import PipelineHealth, build_health_summary


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    query: str


class _Out(Stud):
    result: str


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.query)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise ValueError("field required")


class _TimeoutBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise TimeoutError("timed out")


class _ConnBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise ConnectionError("connection refused")


# ── BlockFailedEvent 필드 ────────────────────────────────────────────────────


def test_block_failed_event_has_input_sample_and_error_type() -> None:
    ev = BlockFailedEvent(
        block_name="B",
        error=ValueError("oops"),
        elapsed_sec=0.1,
        timestamp=0.0,
        input_sample="{'query': ''}",
        error_type="ValueError",
    )
    assert ev.input_sample == "{'query': ''}"
    assert ev.error_type == "ValueError"


def test_block_failed_event_defaults_none() -> None:
    ev = BlockFailedEvent(block_name="B", error=RuntimeError("x"), elapsed_sec=0.1, timestamp=0.0)
    assert ev.input_sample is None
    assert ev.error_type is None


# ── Assembly가 error_type, input_sample 을 자동 채움 ──────────────────────────


async def test_assembly_populates_error_type_and_input_sample() -> None:
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query="hello"))
        except ValueError:
            pass
    failed = bus.failed_events()
    assert len(failed) == 1
    ev = failed[0]
    assert ev.error_type == "ValueError"
    assert ev.input_sample is not None
    assert "hello" in ev.input_sample


async def test_assembly_input_sample_truncated_to_200() -> None:
    long_query = "x" * 300

    class _LongFailBlock(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            raise RuntimeError("boom")

    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_LongFailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query=long_query))
        except RuntimeError:
            pass
    ev = bus.failed_events()[0]
    assert ev.input_sample is not None
    assert len(ev.input_sample) <= 200


# ── include_payload=True 시 입력 샘플 포함 ────────────────────────────────────


async def test_include_payload_true_shows_sample() -> None:
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query="test-query"))
        except ValueError:
            pass
    health = build_health_summary(bus.events, bus=bus)
    summary = health.to_ai_summary(include_payload=True)
    assert "입력 샘플" in summary
    assert "test-query" in summary


# ── include_payload=False (기본) — 샘플 미포함 ────────────────────────────────


async def test_include_payload_false_hides_sample() -> None:
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query="secret"))
        except ValueError:
            pass
    health = build_health_summary(bus.events, bus=bus)
    summary = health.to_ai_summary()
    assert "입력 샘플" not in summary


# ── error_type 별 권장 조치 ───────────────────────────────────────────────────


def _make_health_with_event(ev: BlockFailedEvent) -> PipelineHealth:
    bus = CollectingEventBus()
    bus._events.append(ev)
    return build_health_summary(bus.events, bus=bus)


@pytest.mark.parametrize(
    ("error_type", "expected_keyword"),
    [
        ("ValidationError", "@field_validator"),
        ("TimeoutError", "timeout_sec"),
        ("ConnectionError", "RetryBlock"),
        ("OSError", "FallbackBlock"),
        ("CircuitOpenError", "CircuitBreakerBlock"),
        ("RuntimeError", "오류 로그"),
        (None, "오류 로그"),
    ],
)
def test_recommendation_per_error_type(error_type: str | None, expected_keyword: str) -> None:
    ev = BlockFailedEvent(
        block_name="B",
        error=RuntimeError("x"),
        elapsed_sec=0.1,
        timestamp=0.0,
        error_type=error_type,
    )
    health = _make_health_with_event(ev)
    summary = health.to_ai_summary()
    assert expected_keyword in summary


# ── error_type 이 summary에 prefix로 표시됨 ───────────────────────────────────


def test_error_type_shown_as_prefix_in_summary() -> None:
    ev = BlockFailedEvent(
        block_name="B",
        error=ValueError("field required"),
        elapsed_sec=0.1,
        timestamp=0.0,
        error_type="ValueError",
    )
    health = _make_health_with_event(ev)
    summary = health.to_ai_summary()
    assert "[ValueError]" in summary


# ── 기존 to_ai_summary() 시그니처 호환 유지 ──────────────────────────────────


def test_to_ai_summary_no_args_still_works() -> None:
    health = build_health_summary([])
    summary = health.to_ai_summary()
    assert "정상" in summary
    assert "권장 조치: 없음" in summary


# ── to_dict() 에 input_sample, error_type 포함 ───────────────────────────────


def test_to_dict_includes_input_sample_and_error_type() -> None:
    ev = BlockFailedEvent(
        block_name="B",
        error=RuntimeError("x"),
        elapsed_sec=0.1,
        timestamp=0.0,
        input_sample="sample",
        error_type="RuntimeError",
    )
    health = _make_health_with_event(ev)
    d = health.to_dict()
    assert d["error_details"] is not None
    detail = d["error_details"]["B"]
    assert detail["input_sample"] == "sample"
    assert detail["error_type"] == "RuntimeError"
