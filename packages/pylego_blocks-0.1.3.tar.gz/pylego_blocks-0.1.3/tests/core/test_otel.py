"""OtelEventBus 단위 테스트 — opentelemetry-api 없이 Mock으로 검증."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, call, patch

import pytest

from pylego.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
)


# ─── opentelemetry 모듈 stub ─────────────────────────────────────────────────

def _make_otel_stub() -> types.ModuleType:
    """opentelemetry.* 패키지 전체를 인메모리 stub 으로 구성해 반환한다."""
    root = types.ModuleType("opentelemetry")

    # opentelemetry.trace
    trace_mod = types.ModuleType("opentelemetry.trace")

    class _StatusCode:
        OK = "OK"
        ERROR = "ERROR"

    trace_mod.StatusCode = _StatusCode  # type: ignore[attr-defined]

    mock_span = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span

    def _get_tracer(name: str) -> MagicMock:
        return mock_tracer

    trace_mod.get_tracer = _get_tracer  # type: ignore[attr-defined]
    trace_mod.set_tracer_provider = MagicMock()  # type: ignore[attr-defined]

    root.trace = trace_mod  # type: ignore[attr-defined]

    # sub-modules that configure_otel_from_env imports
    sdk_trace = types.ModuleType("opentelemetry.sdk.trace")
    sdk_trace.TracerProvider = MagicMock()  # type: ignore[attr-defined]

    sdk_resources = types.ModuleType("opentelemetry.sdk.resources")
    sdk_resources.Resource = MagicMock()  # type: ignore[attr-defined]

    sdk_export = types.ModuleType("opentelemetry.sdk.trace.export")
    sdk_export.BatchSpanProcessor = MagicMock()  # type: ignore[attr-defined]

    exporter_mod = types.ModuleType("opentelemetry.exporter.otlp.proto.http.trace_exporter")
    exporter_mod.OTLPSpanExporter = MagicMock()  # type: ignore[attr-defined]

    # register all modules
    for name, mod in [
        ("opentelemetry", root),
        ("opentelemetry.trace", trace_mod),
        ("opentelemetry.sdk", types.ModuleType("opentelemetry.sdk")),
        ("opentelemetry.sdk.trace", sdk_trace),
        ("opentelemetry.sdk.resources", sdk_resources),
        ("opentelemetry.sdk.trace.export", sdk_export),
        ("opentelemetry.exporter", types.ModuleType("opentelemetry.exporter")),
        ("opentelemetry.exporter.otlp", types.ModuleType("opentelemetry.exporter.otlp")),
        ("opentelemetry.exporter.otlp.proto", types.ModuleType("opentelemetry.exporter.otlp.proto")),
        ("opentelemetry.exporter.otlp.proto.http", types.ModuleType("opentelemetry.exporter.otlp.proto.http")),
        ("opentelemetry.exporter.otlp.proto.http.trace_exporter", exporter_mod),
    ]:
        sys.modules[name] = mod

    return root


@pytest.fixture(autouse=True)
def _patch_otel(monkeypatch: pytest.MonkeyPatch) -> None:
    """각 테스트마다 opentelemetry stub 을 sys.modules 에 주입한다."""
    _make_otel_stub()
    # otel.py 가 이미 임포트된 경우 내부 캐시를 무효화
    if "pylego.core.otel" in sys.modules:
        del sys.modules["pylego.core.otel"]


# ─── 테스트 ──────────────────────────────────────────────────────────────────

class TestOtelEventBusInit:
    def test_import_error_without_otel(self) -> None:
        saved = {k: v for k, v in sys.modules.items() if k.startswith("opentelemetry")}
        for k in list(sys.modules.keys()):
            if k.startswith("opentelemetry"):
                del sys.modules[k]
        if "pylego.core.otel" in sys.modules:
            del sys.modules["pylego.core.otel"]
        try:
            with pytest.raises(ImportError, match="opentelemetry-api"):
                from pylego.core.otel import OtelEventBus
                OtelEventBus()
        finally:
            sys.modules.update(saved)
            if "pylego.core.otel" in sys.modules:
                del sys.modules["pylego.core.otel"]

    def test_default_service_name(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("PYLEGO_OTEL_SERVICE_NAME", raising=False)
        from pylego.core.otel import OtelEventBus
        bus = OtelEventBus()
        assert bus._service_name == "pylego"

    def test_custom_service_name_arg(self) -> None:
        from pylego.core.otel import OtelEventBus
        bus = OtelEventBus(service_name="my-svc")
        assert bus._service_name == "my-svc"

    def test_service_name_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PYLEGO_OTEL_SERVICE_NAME", "env-svc")
        from pylego.core.otel import OtelEventBus
        bus = OtelEventBus()
        assert bus._service_name == "env-svc"


class TestOtelEventBusEmit:
    def _bus(self) -> object:
        from pylego.core.otel import OtelEventBus
        return OtelEventBus()

    def test_block_started_creates_span(self) -> None:
        bus = self._bus()
        event = BlockStartedEvent(block_name="b1", input={"x": 1})
        bus.emit(event)  # type: ignore[attr-defined]
        tracer = sys.modules["opentelemetry.trace"].get_tracer("pylego")
        tracer.start_span.assert_called_once()
        assert "block.b1" == tracer.start_span.call_args[0][0]

    def test_block_completed_ends_span_ok(self) -> None:
        bus = self._bus()
        bus.emit(BlockStartedEvent(block_name="b1", input=None))  # type: ignore[attr-defined]
        bus.emit(BlockCompletedEvent(block_name="b1", output="done", elapsed_sec=0.1))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        span.set_status.assert_called_once()
        span.end.assert_called_once()
        assert not bus._active_spans  # type: ignore[attr-defined]

    def test_block_failed_ends_span_error(self) -> None:
        bus = self._bus()
        bus.emit(BlockStartedEvent(block_name="b2", input=None))  # type: ignore[attr-defined]
        err = ValueError("boom")
        bus.emit(BlockFailedEvent(block_name="b2", error=err, elapsed_sec=0.2))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        span.record_exception.assert_called_once_with(err)
        span.end.assert_called_once()

    def test_block_retry_adds_event(self) -> None:
        bus = self._bus()
        bus.emit(BlockStartedEvent(block_name="b3", input=None))  # type: ignore[attr-defined]
        bus.emit(BlockRetryEvent(  # type: ignore[attr-defined]
            block_name="b3", attempt=1, max_attempts=3, error=RuntimeError("e"), delay_sec=0.5
        ))
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        span.add_event.assert_called_once()
        assert span.add_event.call_args[0][0] == "block.retry"

    def test_circuit_breaker_state_adds_event(self) -> None:
        bus = self._bus()
        bus.emit(BlockStartedEvent(block_name="b4", input=None))  # type: ignore[attr-defined]
        bus.emit(CircuitBreakerStateEvent(  # type: ignore[attr-defined]
            block_name="b4", previous_state="closed", new_state="open"
        ))
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        span.add_event.assert_called_once()
        assert span.add_event.call_args[0][0] == "circuit_breaker.state_change"

    def test_completed_without_started_is_noop(self) -> None:
        bus = self._bus()
        bus.emit(BlockCompletedEvent(block_name="ghost", output=None, elapsed_sec=0.0))  # type: ignore[attr-defined]

    def test_retry_without_started_is_noop(self) -> None:
        bus = self._bus()
        bus.emit(BlockRetryEvent(  # type: ignore[attr-defined]
            block_name="ghost", attempt=1, max_attempts=3, error=RuntimeError(), delay_sec=0.0
        ))


class TestOtelFailedPayload:
    """include_failed_payload=True 시 실제 입력 내용을 span에 기록한다."""

    def _bus(self, **kwargs: object) -> object:
        from pylego.core.otel import OtelEventBus
        return OtelEventBus(**kwargs)  # type: ignore[arg-type]

    def test_failed_payload_recorded_when_enabled(self) -> None:
        bus = self._bus(include_failed_payload=True)
        bus.emit(BlockStartedEvent(block_name="b1", input={"key": "secret"}))  # type: ignore[attr-defined]
        err = ValueError("의미 실패")
        bus.emit(BlockFailedEvent(block_name="b1", error=err, elapsed_sec=0.1))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        # block.failed_input 속성이 설정되어야 함
        calls = {k: v for call in span.set_attribute.call_args_list
                 for k, v in [call[0]]}
        assert "block.failed_input" in calls
        assert "secret" in calls["block.failed_input"]

    def test_failed_payload_not_recorded_by_default(self) -> None:
        bus = self._bus()
        bus.emit(BlockStartedEvent(block_name="b2", input={"key": "secret"}))  # type: ignore[attr-defined]
        err = ValueError("오류")
        bus.emit(BlockFailedEvent(block_name="b2", error=err, elapsed_sec=0.1))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        calls = {k: v for call in span.set_attribute.call_args_list
                 for k, v in [call[0]]}
        assert "block.failed_input" not in calls

    def test_payload_truncated_at_max_chars(self) -> None:
        bus = self._bus(include_failed_payload=True, max_payload_chars=10)
        long_input = {"data": "x" * 200}
        bus.emit(BlockStartedEvent(block_name="b3", input=long_input))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="b3", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        calls = {k: v for call in span.set_attribute.call_args_list
                 for k, v in [call[0]]}
        payload = calls.get("block.failed_input", "")
        assert len(payload) <= 10 + len("…[truncated]")

    def test_hash_still_recorded_with_payload_enabled(self) -> None:
        bus = self._bus(include_failed_payload=True)
        bus.emit(BlockStartedEvent(block_name="b4", input={"v": 1}))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="b4", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        # start_span 시 hash가 attributes에 포함됨
        start_attrs = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.call_args[1].get("attributes", {})
        assert "block.input_hash" in start_attrs


class TestOtelPayloadFilter:
    """payload_filter 콜백 — 선택적 페이로드 기록."""

    def _fresh_bus(self, **kwargs: object) -> object:
        """매 호출마다 otel 모듈 캐시를 무효화하여 stub span을 새로 생성한다."""
        if "pylego.core.otel" in sys.modules:
            del sys.modules["pylego.core.otel"]
        _make_otel_stub()
        from pylego.core.otel import OtelEventBus
        return OtelEventBus(**kwargs)  # type: ignore[arg-type]

    def _attr_calls(self) -> dict[str, object]:
        span = sys.modules["opentelemetry.trace"].get_tracer("pylego").start_span.return_value
        return {k: v for call in span.set_attribute.call_args_list for k, v in [call[0]]}

    def test_filter_none_default_records_all(self) -> None:
        bus = self._fresh_bus(include_failed_payload=True)
        bus.emit(BlockStartedEvent(block_name="X", input={"v": 1}))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="X", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        assert "block.failed_input" in self._attr_calls()

    def test_filter_returns_true_records_payload(self) -> None:
        bus = self._fresh_bus(
            include_failed_payload=True,
            payload_filter=lambda e: True,
        )
        bus.emit(BlockStartedEvent(block_name="Y", input={"v": 2}))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="Y", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        assert "block.failed_input" in self._attr_calls()

    def test_filter_returns_false_blocks_payload(self) -> None:
        bus = self._fresh_bus(
            include_failed_payload=True,
            payload_filter=lambda e: False,
        )
        bus.emit(BlockStartedEvent(block_name="Z", input={"v": 3}))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="Z", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        assert "block.failed_input" not in self._attr_calls()

    def test_filter_by_block_name(self) -> None:
        bus = self._fresh_bus(
            include_failed_payload=True,
            payload_filter=lambda e: "RetryInner" not in e.block_name,
        )
        # RetryInner 블록 — 차단
        bus.emit(BlockStartedEvent(block_name="RetryInner", input={"v": 4}))  # type: ignore[attr-defined]
        bus.emit(BlockFailedEvent(block_name="RetryInner", error=ValueError(), elapsed_sec=0.0))  # type: ignore[attr-defined]
        attrs = self._attr_calls()
        assert "block.failed_input" not in attrs

    def test_filter_passes_correct_event_to_callback(self) -> None:
        received: list[object] = []

        def capture(event: object) -> bool:
            received.append(event)
            return True

        bus = self._fresh_bus(include_failed_payload=True, payload_filter=capture)
        bus.emit(BlockStartedEvent(block_name="C", input=None))  # type: ignore[attr-defined]
        err = RuntimeError("test")
        bus.emit(BlockFailedEvent(block_name="C", error=err, elapsed_sec=0.1))  # type: ignore[attr-defined]

        assert len(received) == 1
        event = received[0]
        assert isinstance(event, BlockFailedEvent)
        assert event.block_name == "C"
        assert event.error is err


class TestConfigureOtelFromEnv:
    def test_returns_none_without_endpoint(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("PYLEGO_OTEL_ENDPOINT", raising=False)
        from pylego.core.otel import configure_otel_from_env
        assert configure_otel_from_env() is None

    def test_returns_bus_with_endpoint(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PYLEGO_OTEL_ENDPOINT", "http://localhost:4318")
        from pylego.core.otel import OtelEventBus, configure_otel_from_env
        result = configure_otel_from_env()
        assert isinstance(result, OtelEventBus)

    def test_endpoint_trailing_slash_stripped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PYLEGO_OTEL_ENDPOINT", "http://localhost:4318/")
        exporter_cls = sys.modules["opentelemetry.exporter.otlp.proto.http.trace_exporter"].OTLPSpanExporter
        from pylego.core.otel import configure_otel_from_env
        configure_otel_from_env()
        exporter_cls.assert_called_once_with(endpoint="http://localhost:4318/v1/traces")
