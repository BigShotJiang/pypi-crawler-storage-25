"""SyncRuntime · AsyncRuntime 상호 호환 검증.

동일 Assembly 가 sync / async 런타임 양쪽에서 같은 결과를 내는지 확인 —
"런타임 교체가 블록 수정 없이 가능" 불변 원칙의 실증.
"""

from __future__ import annotations

from pylego.core import Assembly, AsyncRuntime, Block, Stud, SyncRuntime


class _In(Stud):
    n: int


class _Out(Stud):
    n: int


class _Double(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(n=inp.n * 2)


class _AddOne(Block[_Out, _Out]):
    # output == input 타입으로 체인 길이 2 구성.
    input_model = _Out
    output_model = _Out

    async def run(self, inp: _Out) -> _Out:
        return _Out(n=inp.n + 1)


def _build_assembly() -> Assembly[_In, _Out]:
    return Assembly([_Double(), _AddOne()])


class TestSyncRuntime:
    def test_execute_single_block(self) -> None:
        rt = SyncRuntime()
        result = rt.execute(_Double(), _In(n=3))
        assert isinstance(result, _Out)
        assert result.n == 6

    def test_execute_assembly(self) -> None:
        rt = SyncRuntime()
        result = rt.execute(_build_assembly(), _In(n=3))
        assert isinstance(result, _Out)
        assert result.n == 7  # (3*2) + 1


class TestAsyncRuntime:
    async def test_execute_single_block(self) -> None:
        rt = AsyncRuntime()
        result = await rt.execute(_Double(), _In(n=3))
        assert isinstance(result, _Out)
        assert result.n == 6

    async def test_execute_assembly(self) -> None:
        rt = AsyncRuntime()
        result = await rt.execute(_build_assembly(), _In(n=3))
        assert isinstance(result, _Out)
        assert result.n == 7


class TestRuntimeEquivalence:
    def test_sync_and_async_agree(self) -> None:
        """동일 Assembly 를 두 런타임으로 돌려 같은 결과가 나오는지 확인.

        테스트는 sync 컨텍스트에서 실행 (SyncRuntime 이 내부에서 asyncio.run 을 쓰므로
        이미 루프가 돌고 있는 async 테스트에서는 직접 호출 불가).
        """
        import asyncio

        asm: Assembly[_In, _Out] = _build_assembly()
        inp = _In(n=10)
        sync_result = SyncRuntime().execute(asm, inp)
        async_result = asyncio.run(AsyncRuntime().execute(asm, inp))
        assert isinstance(sync_result, _Out)
        assert isinstance(async_result, _Out)
        assert sync_result.n == async_result.n == 21
