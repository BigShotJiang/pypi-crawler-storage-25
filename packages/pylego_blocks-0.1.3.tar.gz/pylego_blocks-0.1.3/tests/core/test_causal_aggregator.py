"""M113 — Causal Aggregator 테스트."""

from __future__ import annotations

import pytest

from pylego.core.graph import (
    CausalFactor,
    EnvironmentContext,
    HealthDiff,
    PipelineHealth,
    VersionContext,
)


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────

def _h(
    overall: str = "ok",
    error_blocks: list[str] | None = None,
    version_context: VersionContext | None = None,
) -> PipelineHealth:
    eb = error_blocks or []
    return PipelineHealth(
        overall=overall,  # type: ignore[arg-type]
        total_blocks=max(len(eb), 1),
        error_blocks=eb,
        slowest_block=None,
        slowest_elapsed_sec=None,
        avg_elapsed_sec=None,
        version_context=version_context,
    )


def _diff_with_factors(*factors: CausalFactor) -> HealthDiff:
    d = HealthDiff()
    d.causal_factors = list(factors)
    return d


# ── CausalFactor.recurrence_count 기본값 ─────────────────────────────────────


def test_causal_factor_recurrence_count_default() -> None:
    cf = CausalFactor(source="code", name="BlockA", confidence_score=0.7)
    assert cf.recurrence_count == 0


def test_causal_factor_recurrence_count_custom() -> None:
    cf = CausalFactor(source="code", name="BlockA", confidence_score=0.7, recurrence_count=3)
    assert cf.recurrence_count == 3


# ── aggregate_causes() 기본 동작 ─────────────────────────────────────────────


def test_aggregate_causes_returns_highest_score() -> None:
    """가장 높은 점수를 가진 요인이 primary_cause 가 된다."""
    d = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.7),   # code×1.2=0.84
        CausalFactor(source="metric", name="latency", confidence_score=0.6),  # metric×1.0=0.60
        CausalFactor(source="env", name="Redis", confidence_score=0.5),       # env×0.8=0.40
    )
    result = d.aggregate_causes()
    assert result is not None
    assert result.name == "BlockA"
    assert d.primary_cause is result


def test_aggregate_causes_none_when_no_factors() -> None:
    """causal_factors 가 비어 있으면 None 을 반환하고 primary_cause 도 None."""
    d = HealthDiff()
    result = d.aggregate_causes()
    assert result is None
    assert d.primary_cause is None


def test_primary_cause_not_set_by_diff() -> None:
    """diff() 는 primary_cause 를 자동으로 설정하지 않는다."""
    vc = VersionContext(version="2.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    assert diff.causal_factors  # 요인은 계산됨
    assert diff.primary_cause is None  # 하지만 자동 결론 없음


def test_primary_cause_set_by_aggregate() -> None:
    """aggregate_causes() 호출 후 primary_cause 가 설정된다."""
    vc = VersionContext(version="2.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    diff.aggregate_causes()
    assert diff.primary_cause is not None
    assert diff.primary_cause.name == "BlockA"


# ── source 가중치 ─────────────────────────────────────────────────────────────


def test_aggregate_causes_code_source_weight() -> None:
    """code(×1.2) 는 동점일 때 metric(×1.0) 보다 우선한다."""
    d = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.5),   # 0.5×1.2=0.60
        CausalFactor(source="metric", name="latency", confidence_score=0.6), # 0.6×1.0=0.60
    )
    result = d.aggregate_causes()
    # 둘 다 0.60 이지만 code 가 먼저 처리되므로 code 선택 (동점 첫 번째)
    assert result is not None
    assert result.source == "code"


def test_aggregate_causes_env_source_weight_penalty() -> None:
    """env(×0.8) 는 동일 confidence 에서 metric(×1.0) 보다 낮은 점수를 갖는다."""
    d = _diff_with_factors(
        CausalFactor(source="env", name="Redis", confidence_score=0.6),    # 0.6×0.8=0.48
        CausalFactor(source="metric", name="latency", confidence_score=0.5), # 0.5×1.0=0.50
    )
    result = d.aggregate_causes()
    assert result is not None
    assert result.name == "latency"


# ── recurrence_count 상향 ────────────────────────────────────────────────────


def test_recurrence_count_increases_score() -> None:
    """이력에서 등장한 요인은 confidence_score 가 상향 조정된다."""
    prev_diff = _diff_with_factors(
        CausalFactor(source="env", name="Redis", confidence_score=0.5),
    )
    curr = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.7),  # code×1.2=0.84
        CausalFactor(source="env", name="Redis", confidence_score=0.5),    # 반복 1회: 0.5×1.1×0.8=0.44
    )
    # Redis 반복 없을 때: env=0.5×0.8=0.40 < code=0.7×1.2=0.84 → BlockA 선택
    # Redis 반복 있어도 BlockA 가 여전히 높아야 함
    result = curr.aggregate_causes(history=[prev_diff])
    assert result is not None
    assert result.name == "BlockA"


def test_recurrence_count_wins_over_lower_confidence() -> None:
    """반복 등장으로 낮은 confidence 요인이 높은 confidence 를 이길 수 있다."""
    # env 요인이 10번 반복 → ×2.0 캡 적용 → 0.5×2.0×0.8=0.80
    # code 요인 confidence=0.6 → 0.6×1.2=0.72
    history = [
        _diff_with_factors(CausalFactor(source="env", name="Redis", confidence_score=0.5))
        for _ in range(10)
    ]
    curr = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.6),
        CausalFactor(source="env", name="Redis", confidence_score=0.5),
    )
    result = curr.aggregate_causes(history=history)
    assert result is not None
    assert result.name == "Redis"
    assert result.recurrence_count == 10


def test_recurrence_count_capped_at_double() -> None:
    """confidence_score 는 최대 2.0× (100%) 까지만 상향된다."""
    # 1 + 0.1 × 100 = 11.0 → min(2.0, 11.0) = 2.0
    history = [
        _diff_with_factors(CausalFactor(source="code", name="BlockA", confidence_score=0.5))
        for _ in range(100)
    ]
    curr = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.5),
    )
    result = curr.aggregate_causes(history=history)
    assert result is not None
    # adjusted = 0.5 × min(2.0, 1 + 0.1×100) = 0.5 × 2.0 = 1.0
    # source weight code = 1.2 → final = 1.2
    assert result.recurrence_count == 100


def test_history_none_uses_zero_recurrence() -> None:
    """history=None 이면 모든 recurrence_count=0."""
    d = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.7),
    )
    result = d.aggregate_causes(history=None)
    assert result is not None
    assert result.recurrence_count == 0


# ── to_ai_summary primary_cause 출력 ─────────────────────────────────────────


def test_to_ai_summary_shows_primary_cause() -> None:
    """aggregate_causes() 후 to_ai_summary() 에 [최유력 원인] 섹션이 출력된다."""
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    diff.aggregate_causes()

    summary = curr.to_ai_summary(diff=diff)
    assert "[최유력 원인]" in summary
    assert "BlockA" in summary
    assert "[code/" in summary


def test_to_ai_summary_no_primary_cause_section_without_aggregate() -> None:
    """aggregate_causes() 를 호출하지 않으면 [최유력 원인] 섹션이 없다."""
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    # aggregate_causes() 미호출

    summary = curr.to_ai_summary(diff=diff)
    assert "[최유력 원인]" not in summary
    assert "[인과 후보 목록]" in summary  # 후보 목록은 여전히 출력


def test_to_ai_summary_primary_cause_shows_recurrence() -> None:
    """primary_cause 의 recurrence_count > 0 이면 '반복 등장 N회' 가 출력된다."""
    history_diff = _diff_with_factors(
        CausalFactor(source="code", name="BlockA", confidence_score=0.7),
    )
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    diff.aggregate_causes(history=[history_diff])

    summary = curr.to_ai_summary(diff=diff)
    assert "반복 등장 1회" in summary
