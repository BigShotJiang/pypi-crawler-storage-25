"""SemanticRetryBlock 테스트."""

import asyncio

import pytest

from pylego import Assembly, Block, SemanticRetryBlock, Stud
from pylego.core.events import BlockRetryEvent, CollectingEventBus, observe


class Request(Stud):
    prompt: str
    attempt_hint: str = ""


class Response(Stud):
    verdict: str
    content: str


class FlakyAiBlock(Block[Request, Response]):
    """처음 N번은 UNKNOWN을 반환하고 이후엔 PASS를 반환하는 목업 블록."""

    input_model = Request
    output_model = Response

    def __init__(self, fail_times: int = 1) -> None:
        self._fail_times = fail_times
        self._calls: list[Request] = []

    async def run(self, inp: Request) -> Response:
        self._calls.append(inp)
        if len(self._calls) <= self._fail_times:
            return Response(verdict="UNKNOWN", content="형식 오류")
        return Response(verdict="PASS", content="정상 응답")


def _verify(inp: Request, out: Response) -> None:
    if out.verdict != "PASS":
        raise ValueError(f"판정 불가: {out.verdict}")


def _enrich(inp: Request, out: Response, error: str) -> Request:
    return inp.model_copy(update={"attempt_hint": f"[오류: {error}]"})


# ── 성공 경로 ──────────────────────────────────────────────────────────────────

def test_success_on_first_try() -> None:
    inner = FlakyAiBlock(fail_times=0)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich)
    result = asyncio.run(block.run(Request(prompt="질문")))
    assert result.verdict == "PASS"
    assert len(inner._calls) == 1


def test_succeeds_after_one_retry() -> None:
    inner = FlakyAiBlock(fail_times=1)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=3)
    result = asyncio.run(block.run(Request(prompt="질문")))
    assert result.verdict == "PASS"
    assert len(inner._calls) == 2


def test_enrich_fn_injects_error_context() -> None:
    inner = FlakyAiBlock(fail_times=1)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=3)
    asyncio.run(block.run(Request(prompt="질문")))
    # 두 번째 시도의 입력에 오류 컨텍스트가 포함되어야 함
    assert "오류" in inner._calls[1].attempt_hint


# ── 실패 경로 ──────────────────────────────────────────────────────────────────

def test_raises_after_max_attempts_exhausted() -> None:
    inner = FlakyAiBlock(fail_times=10)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=3)
    with pytest.raises(ValueError, match="판정 불가"):
        asyncio.run(block.run(Request(prompt="질문")))
    assert len(inner._calls) == 3


def test_max_attempts_one_raises_immediately() -> None:
    inner = FlakyAiBlock(fail_times=1)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=1)
    with pytest.raises(ValueError):
        asyncio.run(block.run(Request(prompt="질문")))
    assert len(inner._calls) == 1


# ── 이벤트 발행 ────────────────────────────────────────────────────────────────

def test_retry_events_emitted() -> None:
    inner = FlakyAiBlock(fail_times=2)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=3)

    bus = CollectingEventBus()
    with observe(bus):
        asyncio.run(block.run(Request(prompt="질문")))

    retry_events = [e for e in bus.events if isinstance(e, BlockRetryEvent)]
    assert len(retry_events) == 2
    assert retry_events[0].attempt == 1
    assert retry_events[1].attempt == 2


# ── 모델 속성 ──────────────────────────────────────────────────────────────────

def test_io_models_inherited_from_inner() -> None:
    inner = FlakyAiBlock(fail_times=0)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich)
    assert block.input_model is Request
    assert block.output_model is Response


def test_name_wraps_inner() -> None:
    inner = FlakyAiBlock(fail_times=0)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich)
    assert "FlakyAiBlock" in block.name
    assert "SemanticRetry" in block.name


def test_invalid_max_attempts() -> None:
    inner = FlakyAiBlock()
    with pytest.raises(ValueError, match="1 이상"):
        SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=0)


# ── Assembly 통합 ──────────────────────────────────────────────────────────────

def test_in_assembly_pipeline() -> None:
    inner = FlakyAiBlock(fail_times=1)
    block = SemanticRetryBlock(inner, verify_fn=_verify, enrich_fn=_enrich, max_attempts=3)
    pipeline = Assembly([block])
    result = pipeline.run_sync(Request(prompt="파이프라인 테스트"))
    assert result.verdict == "PASS"
