"""graph.py — to_mermaid 래퍼 깊이 ≥3 경고 주석 삽입 테스트 (M33)."""

from __future__ import annotations

from pylego.core.assembly import Assembly
from pylego.core.block import Block
from pylego.core.graph import to_mermaid
from pylego.core.stud import Stud

# ─── 공통 Stud ────────────────────────────────────────────────────────────────


class _S(Stud):
    v: int = 0


# ─── 일반 더미 블록 ────────────────────────────────────────────────────────────


class _PlainA(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _PlainB(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _PlainC(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


# ─── 래퍼 더미 블록 (이름에 _WRAPPER_NAMES 포함) ─────────────────────────────


class _WrapDepth1(Block[_S, _S]):
    """이름에 래퍼 식별자 1개 포함 (깊이=1)."""

    name = "RetryBlock(PlainA)"
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _WrapDepth2(Block[_S, _S]):
    """이름에 래퍼 식별자 2개 포함 (깊이=2)."""

    name = "RetryBlock(FallbackBlock(PlainA))"
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _WrapDepth3(Block[_S, _S]):
    """이름에 래퍼 식별자 3개 포함 (깊이=3) — 경고 대상."""

    name = "RetryBlock(FallbackBlock(TimeoutBlock(PlainA)))"
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _SemanticWrapDepth3(Block[_S, _S]):
    """SemanticRetryBlock 포함 3단 중첩 — 경고 대상."""

    name = "SemanticRetryBlock(FallbackBlock(TimeoutBlock(PlainA)))"
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


# ─── 테스트 케이스 ─────────────────────────────────────────────────────────────


class TestWrapperDepthWarning:
    def test_no_warning_depth_2(self) -> None:
        """래퍼 2단 중첩은 경고가 삽입되지 않아야 한다."""
        asm: Assembly[_S, _S] = Assembly([_WrapDepth2()], name="Asm2")
        text = to_mermaid(asm)
        assert "⚠️" not in text
        assert "WARNING" not in text

    def test_warning_depth_3(self) -> None:
        """래퍼 3단 중첩이면 ⚠️ 접두어와 WARNING 주석이 삽입된다."""
        asm: Assembly[_S, _S] = Assembly([_WrapDepth3()], name="Asm3")
        text = to_mermaid(asm)
        assert "⚠️" in text
        assert "WARNING" in text
        assert "wrapper depth >= 3" in text

    def test_warning_semantic_retry_depth_3(self) -> None:
        """SemanticRetryBlock 포함 3단 중첩도 경고가 삽입된다."""
        asm: Assembly[_S, _S] = Assembly([_SemanticWrapDepth3()], name="AsmSR3")
        text = to_mermaid(asm)
        assert "⚠️" in text
        assert "WARNING" in text

    def test_non_wrapper_no_warning(self) -> None:
        """일반 블록 3단 중첩(Assembly 안에 Assembly)은 경고 없음."""
        inner: Assembly[_S, _S] = Assembly([_PlainC()], name="InnerAsm")
        middle: Assembly[_S, _S] = Assembly([_PlainB(), inner], name="MiddleAsm")
        outer: Assembly[_S, _S] = Assembly([_PlainA(), middle], name="OuterAsm")
        text = to_mermaid(outer)
        assert "⚠️" not in text
        assert "WARNING" not in text

    def test_existing_output_unchanged(self) -> None:
        """래퍼 없는 일반 Assembly 의 출력이 M33 변경 전과 동일하다."""
        asm: Assembly[_S, _S] = Assembly([_PlainA(), _PlainB()], name="PlainAsm")
        text = to_mermaid(asm)
        # 기본 구조 검증 (변경 전과 동일한 출력 형식)
        assert text.startswith("flowchart LR\n")
        assert "PlainAsm" in text
        assert "_PlainA" in text
        assert "_PlainB" in text
        assert "-->" in text
        # 경고 없음
        assert "⚠️" not in text
        assert "WARNING" not in text

    def test_depth_1_no_warning(self) -> None:
        """래퍼 1단만 있는 경우 경고 없음."""
        asm: Assembly[_S, _S] = Assembly([_WrapDepth1()], name="Asm1")
        text = to_mermaid(asm)
        assert "⚠️" not in text
        assert "WARNING" not in text

    def test_warning_node_label_prefix(self) -> None:
        """경고 시 노드 레이블에 ⚠️ 가 블록 이름 앞에 붙는다."""
        block = _WrapDepth3()
        text = to_mermaid(block)
        assert f'⚠️ {block.name}' in text

    def test_warning_comment_format(self) -> None:
        """경고 주석의 형식이 정확히 맞아야 한다."""
        block = _WrapDepth3()
        text = to_mermaid(block)
        assert "%% WARNING: wrapper depth >= 3, consider refactoring" in text
