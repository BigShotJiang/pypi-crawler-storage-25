"""Assembly 조립 검증·선형 실행 테스트."""

from __future__ import annotations

import pytest

from pylego.core import Assembly, Block, CyclicAssemblyError, IncompatibleSnapError, Stud


class _A(Stud):
    text: str


class _B(Stud):
    text: str


class _C(Stud):
    length: int


class _Upper(Block[_A, _B]):
    input_model = _A
    output_model = _B

    async def run(self, inp: _A) -> _B:
        return _B(text=inp.text.upper())


class _Length(Block[_B, _C]):
    input_model = _B
    output_model = _C

    async def run(self, inp: _B) -> _C:
        return _C(length=len(inp.text))


class _WrongInput(Block[_C, _A]):
    input_model = _C
    output_model = _A

    async def run(self, inp: _C) -> _A:  # pragma: no cover
        return _A(text="")


class TestAssemblyBuild:
    def test_empty_raises(self) -> None:
        with pytest.raises(ValueError, match="최소 한 개"):
            Assembly([])

    def test_exposes_first_input_and_last_output(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()])
        assert asm.input_model is _A
        assert asm.output_model is _C

    def test_incompatible_snap_at_build_time(self) -> None:
        with pytest.raises(IncompatibleSnapError):
            Assembly([_Upper(), _WrongInput()])

    def test_single_block(self) -> None:
        asm: Assembly[_A, _B] = Assembly([_Upper()])
        assert asm.input_model is _A
        assert asm.output_model is _B

    def test_assembly_is_block_typed(self) -> None:
        asm: Block[_A, _C] = Assembly([_Upper(), _Length()])
        assert isinstance(asm, Assembly)

    def test_single_block_repr(self) -> None:
        asm: Assembly[_A, _B] = Assembly([_Upper()])
        assert repr(asm) == "Assembly[_Upper]"

    def test_multi_block_repr(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()])
        assert repr(asm) == "Assembly[_Upper → _Length]"

    def test_custom_name_repr(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()], name="MyPipeline")
        assert repr(asm) == "MyPipeline[_Upper → _Length]"

    def test_recursive_assembly_repr(self) -> None:
        inner: Assembly[_A, _B] = Assembly([_Upper()])
        outer: Assembly[_A, _C] = Assembly([inner, _Length()])
        assert repr(outer) == "Assembly[Assembly[_Upper] → _Length]"


class TestAssemblyRun:
    async def test_linear_pipeline(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()])
        result = await asm.run(_A(text="hello"))
        assert isinstance(result, _C)
        assert result.length == 5

    async def test_assembly_is_block(self) -> None:
        # Assembly 자체가 Block 이므로 다른 Assembly 의 구성 요소로 사용 가능.
        inner: Assembly[_A, _B] = Assembly([_Upper()], name="inner")
        outer: Assembly[_A, _C] = Assembly([inner, _Length()], name="outer")
        result = await outer.run(_A(text="hi"))
        assert isinstance(result, _C)
        assert result.length == 2
        assert outer.name == "outer"
        assert outer.blocks == (inner, outer.blocks[1])


class TestCyclicAssembly:
    def test_duplicate_block_instance_raises(self) -> None:
        b = _Upper()
        with pytest.raises(CyclicAssemblyError):
            Assembly([b, b])

    def test_different_instances_same_class_ok(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()])
        assert asm.input_model is _A

    def test_duplicate_assembly_instance_raises(self) -> None:
        inner: Assembly[_A, _B] = Assembly([_Upper()])
        with pytest.raises(CyclicAssemblyError):
            Assembly([inner, inner])

    def test_true_cycle_via_mutation_raises(self) -> None:
        inner: Assembly[_A, _B] = Assembly([_Upper()])
        outer: Assembly[_A, _C] = Assembly([inner, _Length()])
        # _blocks 직접 변경으로 asm1 → asm2 → asm1 사이클 생성
        inner._blocks = [outer]  # type: ignore[assignment]
        with pytest.raises(CyclicAssemblyError):
            Assembly([inner], name="Top")

class TestAssemblySyncRun:
    def test_sync_execution(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_Upper(), _Length()])
        result = asm.run_sync(_A(text="synchronous"))
        assert isinstance(result, _C)
        assert result.length == 11

    def test_mixed_sync_async_blocks(self) -> None:
        class _SyncBlock(Block[_A, _B]):
            input_model = _A
            output_model = _B
            async def run(self, inp: _A) -> _B:  # Async wrapper for sync
                return _B(text=inp.text + "sync")

        asm: Assembly[_A, _C] = Assembly([_SyncBlock(), _Length()])
        result = asm.run_sync(_A(text="mixed"))
        assert isinstance(result, _C)
        assert result.length == len("mixed") + 4
