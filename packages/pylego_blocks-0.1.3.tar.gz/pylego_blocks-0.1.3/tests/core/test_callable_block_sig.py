"""CallableBlock fn 시그니처 생성 시점 검증 테스트 (M52)."""

from __future__ import annotations

import pytest

from pylego.core.callable_block import CallableBlock
from pylego.core.stud import Stud


class _In(Stud):
    v: int


class _Out(Stud):
    r: str


class _OtherIn(Stud):
    x: float


class _OtherOut(Stud):
    y: float


async def _correct_fn(inp: _In) -> _Out:
    return _Out(r=str(inp.v))


async def _wrong_input_fn(inp: _OtherIn) -> _Out:
    return _Out(r=str(inp.x))


async def _wrong_output_fn(inp: _In) -> _OtherOut:
    return _OtherOut(y=float(inp.v))


async def _no_annotations(inp: _In):  # type: ignore[no-untyped-def]
    return _Out(r="x")


def test_correct_signature_accepted() -> None:
    """일치하는 시그니처는 오류 없이 생성된다."""
    block = CallableBlock(fn=_correct_fn, input_model=_In, output_model=_Out)
    assert block.name == "_correct_fn"


def test_wrong_input_type_raises() -> None:
    """fn 첫 파라미터 타입 불일치 시 TypeError가 발생한다."""
    with pytest.raises(TypeError, match="input_model"):
        CallableBlock(fn=_wrong_input_fn, input_model=_In, output_model=_Out)


def test_wrong_output_type_raises() -> None:
    """fn 반환 타입 불일치 시 TypeError가 발생한다."""
    with pytest.raises(TypeError, match="output_model"):
        CallableBlock(fn=_wrong_output_fn, input_model=_In, output_model=_Out)


def test_no_annotations_skips_validation() -> None:
    """타입 어노테이션이 없는 fn은 검증을 건너뛴다."""
    block = CallableBlock(fn=_no_annotations, input_model=_In, output_model=_Out)
    assert block is not None
