"""M11 분산 런타임 — ProcessRuntime + FanOut 병렬 실행 테스트."""

from __future__ import annotations

import os

import pytest

from pylego.core.block import Block
from pylego.core.fanout import FanOut, Gathered
from pylego.core.runtime.process import ProcessRuntime
from pylego.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _In(Stud):
    value: int


class _Out(Stud):
    result: int
    pid: int  # 실행 프로세스 PID 기록


class _DoubleBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.value * 2, pid=os.getpid())


class _TripleBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.value * 3, pid=os.getpid())


class _QuadBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.value * 4, pid=os.getpid())


class _UnpicklableBlock(Block[_In, _Out]):
    """pickle 불가 블록 (lambda 속성 포함)."""

    input_model = _In
    output_model = _Out

    def __init__(self) -> None:
        self._fn = lambda x: x  # lambda는 pickle 불가

    async def run(self, inp: _In) -> _Out:
        return _Out(result=self._fn(inp.value), pid=os.getpid())


# ── ProcessRuntime ────────────────────────────────────────────────────────────


class TestProcessRuntime:
    def test_validate_picklable_blocks(self) -> None:
        runtime = ProcessRuntime(workers=2)
        # pickle 가능한 블록 — 에러 없음
        runtime.validate([_DoubleBlock(), _TripleBlock()])

    def test_validate_raises_for_unpicklable(self) -> None:
        runtime = ProcessRuntime(workers=2)
        with pytest.raises(TypeError, match="pickle 불가"):
            runtime.validate([_UnpicklableBlock()])

    def test_default_workers_is_cpu_count(self) -> None:
        runtime = ProcessRuntime()
        assert runtime._workers >= 1

    def test_explicit_workers(self) -> None:
        runtime = ProcessRuntime(workers=3)
        assert runtime._workers == 3

    @pytest.mark.asyncio
    async def test_run_parallel_results(self) -> None:
        runtime = ProcessRuntime(workers=2)
        branches = [_DoubleBlock(), _TripleBlock()]
        inp = _In(value=5)
        results = await runtime.run_parallel(branches, inp)

        assert len(results) == 2
        values = {r.result for r in results}  # type: ignore[union-attr]
        assert values == {10, 15}  # 5*2=10, 5*3=15


# ── FanOut + ProcessRuntime ───────────────────────────────────────────────────


class TestFanOutWithProcessRuntime:
    @pytest.mark.asyncio
    async def test_same_result_as_asyncio(self) -> None:
        """ProcessRuntime 과 기본 asyncio 가 동일 결과를 반환해야 한다."""
        inp = _In(value=7)

        # asyncio 런타임 (기본)
        fanout_async = FanOut([_DoubleBlock(), _TripleBlock()])
        result_async: Gathered = await fanout_async.run(inp)

        # ProcessRuntime
        fanout_proc = FanOut([_DoubleBlock(), _TripleBlock()], runtime=ProcessRuntime(workers=2))
        result_proc: Gathered = await fanout_proc.run(inp)

        async_values = {r.result for r in result_async.results}  # type: ignore[union-attr]
        proc_values = {r.result for r in result_proc.results}  # type: ignore[union-attr]
        assert async_values == proc_values == {14, 21}

    @pytest.mark.asyncio
    async def test_branches_run_in_separate_processes(self) -> None:
        """각 브랜치가 현재 프로세스와 다른 PID 에서 실행되어야 한다."""
        fanout = FanOut([_DoubleBlock(), _TripleBlock()], runtime=ProcessRuntime(workers=2))
        result: Gathered = await fanout.run(_In(value=1))

        current_pid = os.getpid()
        branch_pids = {r.pid for r in result.results}  # type: ignore[union-attr]
        # subprocess 는 현재 프로세스와 다른 PID 를 가져야 한다
        assert all(pid != current_pid for pid in branch_pids)

    def test_unpicklable_block_raises_at_init(self) -> None:
        """pickle 불가 블록은 FanOut 조립 시점에 에러가 발생해야 한다."""
        with pytest.raises(TypeError, match="pickle 불가"):
            FanOut([_UnpicklableBlock(), _DoubleBlock()], runtime=ProcessRuntime(workers=2))

    @pytest.mark.asyncio
    async def test_fanout_without_runtime_unchanged(self) -> None:
        """runtime 미지정 FanOut 은 기존 동작을 유지해야 한다."""
        fanout = FanOut([_DoubleBlock(), _TripleBlock()])
        result: Gathered = await fanout.run(_In(value=4))
        values = {r.result for r in result.results}  # type: ignore[union-attr]
        assert values == {8, 12}

    @pytest.mark.asyncio
    async def test_three_branches_process_runtime(self) -> None:
        fanout = FanOut(
            [_DoubleBlock(), _TripleBlock(), _QuadBlock()],
            runtime=ProcessRuntime(workers=3),
        )
        result: Gathered = await fanout.run(_In(value=3))
        values = {r.result for r in result.results}  # type: ignore[union-attr]
        assert values == {6, 9, 12}
