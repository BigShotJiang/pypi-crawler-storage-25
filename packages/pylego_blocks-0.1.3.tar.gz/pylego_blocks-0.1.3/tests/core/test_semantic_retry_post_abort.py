"""SemanticRetryBlock Post-Abort Verification 테스트 (M69)."""

import asyncio

import pytest

from pylego import Block, SemanticRetryBlock, Stud
from pylego.core.semantic_retry import AbortVerificationError


class Req(Stud):
    prompt: str


class Resp(Stud):
    verdict: str


class AlwaysFailBlock(Block[Req, Resp]):
    input_model = Req
    output_model = Resp

    def __init__(self, verdict: str = "FAIL") -> None:
        self._verdict = verdict

    async def run(self, inp: Req) -> Resp:
        return Resp(verdict=self._verdict)


def _verify(inp: Req, out: Resp) -> None:
    if out.verdict != "PASS":
        raise ValueError(f"검증 실패: {out.verdict}")


def _enrich(inp: Req, out: Resp, error: str) -> Req:
    return inp.model_copy(update={"prompt": f"[retry] {inp.prompt}"})


# ── verify_after_abort=True (기본값) ──────────────────────────────────────────


def test_abort_fn_result_fails_verify_raises_abort_verification_error() -> None:
    """on_abort_fn 결과가 verify_fn을 통과하지 못하면 AbortVerificationError."""

    async def bad_fallback(inp: Req, error: str) -> Resp:
        return Resp(verdict="STILL_FAIL")

    block = SemanticRetryBlock(
        AlwaysFailBlock(),
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=bad_fallback,
        verify_after_abort=True,
    )
    with pytest.raises(AbortVerificationError, match="검증 실패"):
        asyncio.run(block.run(Req(prompt="테스트")))


def test_abort_fn_result_passes_verify_returns_normally() -> None:
    """on_abort_fn 결과가 verify_fn을 통과하면 정상 반환."""

    async def good_fallback(inp: Req, error: str) -> Resp:
        return Resp(verdict="PASS")

    block = SemanticRetryBlock(
        AlwaysFailBlock(),
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=good_fallback,
        verify_after_abort=True,
    )
    result = asyncio.run(block.run(Req(prompt="테스트")))
    assert result.verdict == "PASS"


# ── verify_after_abort=False ──────────────────────────────────────────────────


def test_verify_after_abort_false_skips_verification() -> None:
    """verify_after_abort=False 이면 on_abort_fn 결과 검증 없이 그대로 반환."""

    async def bad_fallback(inp: Req, error: str) -> Resp:
        return Resp(verdict="STILL_FAIL")

    block = SemanticRetryBlock(
        AlwaysFailBlock(),
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=bad_fallback,
        verify_after_abort=False,
    )
    result = asyncio.run(block.run(Req(prompt="테스트")))
    assert result.verdict == "STILL_FAIL"


def test_abort_verification_error_wraps_original_exception() -> None:
    """AbortVerificationError 의 __cause__ 가 verify_fn 예외를 감싼다."""

    async def bad_fallback(inp: Req, error: str) -> Resp:
        return Resp(verdict="BAD")

    block = SemanticRetryBlock(
        AlwaysFailBlock(),
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=bad_fallback,
    )
    with pytest.raises(AbortVerificationError) as exc_info:
        asyncio.run(block.run(Req(prompt="테스트")))
    assert exc_info.value.__cause__ is not None
    assert isinstance(exc_info.value.__cause__, ValueError)
