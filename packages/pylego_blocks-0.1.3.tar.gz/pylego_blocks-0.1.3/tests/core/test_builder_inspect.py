"""BlockBuilder.inspect() + to_mermaid expand_wrappers 테스트."""

from __future__ import annotations

import asyncio
from typing import Any

from pylego.core.block import Block
from pylego.core.builder import wrap
from pylego.core.graph import to_dot, to_mermaid
from pylego.core.stud import Stud


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _Blk(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


def test_inspect_single_block() -> None:
    """래퍼 없이 블록만 있으면 클래스명 하나를 반환한다."""
    result = wrap(_Blk()).inspect()
    assert result == ["_Blk"]


def test_inspect_retry() -> None:
    """retry 추가 시 RetryBlock이 맨 앞에 온다."""
    result = wrap(_Blk()).retry().inspect()
    assert result == ["RetryBlock", "_Blk"]


def test_inspect_timeout_retry_order() -> None:
    """체인 순서대로 바깥→안쪽 스택이 쌓인다."""
    result = wrap(_Blk()).retry().timeout(5.0).inspect()
    assert result == ["TimeoutBlock", "RetryBlock", "_Blk"]


def test_inspect_all_wrappers() -> None:
    """모든 래퍼를 체인하면 스택이 올바른 순서를 유지한다."""
    result = wrap(_Blk()).retry().timeout(5.0).circuit_breaker().inspect()
    assert result[0] == "CircuitBreakerBlock"
    assert result[-1] == "_Blk"
    assert len(result) == 4


def test_inspect_returns_copy() -> None:
    """inspect()는 복사본을 반환하므로 수정이 내부에 영향을 주지 않는다."""
    builder = wrap(_Blk()).retry()
    stack = builder.inspect()
    stack.clear()
    assert builder.inspect() == ["RetryBlock", "_Blk"]


def test_to_mermaid_expand_wrappers_default() -> None:
    """기본값(expand_wrappers=False)은 기존 출력과 동일하다."""
    block = wrap(_Blk()).retry().build()
    default_out = to_mermaid(block)
    explicit_out = to_mermaid(block, expand_wrappers=False)
    assert default_out == explicit_out


def test_to_mermaid_expand_wrappers_true() -> None:
    """expand_wrappers=True 시 래퍼가 서브그래프로 전개된다."""
    block = wrap(_Blk()).retry().timeout(5.0).build()
    expanded = to_mermaid(block, expand_wrappers=True)
    assert "subgraph" in expanded


def test_to_dot_expand_wrappers_true() -> None:
    """to_dot expand_wrappers=True 시 cluster 서브그래프가 포함된다."""
    block = wrap(_Blk()).retry().build()
    expanded = to_dot(block, expand_wrappers=True)
    assert "subgraph" in expanded
