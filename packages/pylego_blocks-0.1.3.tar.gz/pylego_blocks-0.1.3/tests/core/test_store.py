"""Store — InMemoryStore / FileStore / StoreBlock 테스트."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pylego.core.store import FileStore, InMemoryStore, StoreBlock
from pylego.core.stud import Stud


class _Num(Stud):
    value: int


class _Text(Stud):
    text: str


# ---------------------------------------------------------------------------
# InMemoryStore
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_in_memory_store_set_get() -> None:
    store = InMemoryStore()
    await store.set("k", {"value": 1})
    assert await store.get("k") == {"value": 1}


@pytest.mark.asyncio
async def test_in_memory_store_has() -> None:
    store = InMemoryStore()
    assert not await store.has("k")
    await store.set("k", 42)
    assert await store.has("k")


@pytest.mark.asyncio
async def test_in_memory_store_delete() -> None:
    store = InMemoryStore()
    await store.set("k", 1)
    await store.delete("k")
    assert not await store.has("k")


@pytest.mark.asyncio
async def test_in_memory_store_clear() -> None:
    store = InMemoryStore()
    await store.set("a", 1)
    await store.set("b", 2)
    await store.clear()
    assert not await store.has("a")
    assert not await store.has("b")


@pytest.mark.asyncio
async def test_in_memory_store_get_missing_returns_none() -> None:
    store = InMemoryStore()
    assert await store.get("missing") is None


# ---------------------------------------------------------------------------
# FileStore
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_file_store_set_get(tmp_path: Path) -> None:
    store = FileStore(tmp_path / "state.json")
    await store.set("k", {"value": 99})
    assert await store.get("k") == {"value": 99}


@pytest.mark.asyncio
async def test_file_store_persists_between_instances(tmp_path: Path) -> None:
    path = tmp_path / "state.json"
    store1 = FileStore(path)
    await store1.set("x", "hello")

    store2 = FileStore(path)
    assert await store2.get("x") == "hello"


@pytest.mark.asyncio
async def test_file_store_has(tmp_path: Path) -> None:
    store = FileStore(tmp_path / "s.json")
    assert not await store.has("k")
    await store.set("k", 1)
    assert await store.has("k")


@pytest.mark.asyncio
async def test_file_store_delete(tmp_path: Path) -> None:
    store = FileStore(tmp_path / "s.json")
    await store.set("k", 1)
    await store.delete("k")
    assert not await store.has("k")


@pytest.mark.asyncio
async def test_file_store_clear_removes_file(tmp_path: Path) -> None:
    path = tmp_path / "s.json"
    store = FileStore(path)
    await store.set("k", 1)
    await store.clear()
    assert not path.exists()


@pytest.mark.asyncio
async def test_file_store_get_missing_returns_none(tmp_path: Path) -> None:
    store = FileStore(tmp_path / "s.json")
    assert await store.get("missing") is None


@pytest.mark.asyncio
async def test_file_store_creates_parent_dirs(tmp_path: Path) -> None:
    store = FileStore(tmp_path / "deep" / "nested" / "state.json")
    await store.set("k", 1)
    assert await store.has("k")


@pytest.mark.asyncio
async def test_file_store_json_human_readable(tmp_path: Path) -> None:
    path = tmp_path / "s.json"
    store = FileStore(path)
    await store.set("key", {"value": 42})
    text = path.read_text(encoding="utf-8")
    parsed = json.loads(text)
    assert parsed == {"key": {"value": 42}}
    assert "\n" in text  # indent=2 확인


# ---------------------------------------------------------------------------
# StoreBlock
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_block_pass_through() -> None:
    store = InMemoryStore()
    blk: StoreBlock[_Num] = StoreBlock(store, "num", _Num)
    inp = _Num(value=7)
    out = await blk.run(inp)
    assert out == inp


@pytest.mark.asyncio
async def test_store_block_saves_to_store() -> None:
    store = InMemoryStore()
    blk: StoreBlock[_Num] = StoreBlock(store, "num", _Num)
    await blk.run(_Num(value=42))
    raw = await store.get("num")
    assert raw == {"value": 42}


@pytest.mark.asyncio
async def test_store_block_model_contract() -> None:
    store = InMemoryStore()
    blk: StoreBlock[_Text] = StoreBlock(store, "txt", _Text)
    assert blk.input_model is _Text
    assert blk.output_model is _Text
