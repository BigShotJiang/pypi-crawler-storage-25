"""M121 — Probabilistic Causal Graph 테스트."""

from __future__ import annotations

import pytest

from pylego.core.graph import CausalFactor, HealthDiff


def _diff(*names: str, source: str = "code", confidence: float = 0.7) -> HealthDiff:
    """causal_factors 가 채워진 HealthDiff 픽스처."""
    d = HealthDiff()
    d.causal_factors = [
        CausalFactor(source=source, name=n, confidence_score=confidence)  # type: ignore[arg-type]
        for n in names
    ]
    return d


# ── compute_correlation ───────────────────────────────────────────────────────


def test_compute_correlation_true_sets_nonzero() -> None:
    """compute_correlation=True이면 factor.correlation이 0이 아니다."""
    history = [_diff("A", "B"), _diff("A", "B"), _diff("A", "B")]
    curr = _diff("A", "B")
    curr.aggregate_causes(history=history, compute_correlation=True)
    assert any(f.correlation > 0 for f in curr.causal_factors)


def test_compute_correlation_false_keeps_zero() -> None:
    """compute_correlation=False(기본)이면 factor.correlation은 0 유지."""
    history = [_diff("A", "B"), _diff("A", "B")]
    curr = _diff("A", "B")
    curr.aggregate_causes(history=history, compute_correlation=False)
    assert all(f.correlation == 0.0 for f in curr.causal_factors)


def test_always_together_correlation_near_one() -> None:
    """항상 함께 등장한 두 factor의 상관계수는 1.0에 가깝다."""
    history = [_diff("A", "B") for _ in range(5)]
    curr = _diff("A", "B")
    curr.compute_correlations(history)
    a = next(f for f in curr.causal_factors if f.name == "A")
    b = next(f for f in curr.causal_factors if f.name == "B")
    assert a.correlation == pytest.approx(1.0)
    assert b.correlation == pytest.approx(1.0)


def test_always_alone_correlation_near_zero() -> None:
    """독립적으로 등장한 factor의 상관계수는 0.0에 가깝다."""
    history = [_diff("A"), _diff("A"), _diff("A")]
    curr = _diff("A", "B")
    curr.compute_correlations(history)
    a = next(f for f in curr.causal_factors if f.name == "A")
    assert a.correlation == pytest.approx(0.0)


# ── residual_decay_factor ─────────────────────────────────────────────────────


def test_residual_decay_factor_nonzero_reflects_old_history() -> None:
    """residual_decay_factor=0.1이면 window 밖 이력이 0.1 가중치로 반영된다."""
    # window=1 → 마지막 1개만 window, 그 이전은 residual
    old_hist = [_diff("A"), _diff("A"), _diff("A")]   # residual (3회)
    recent_hist = [_diff("B")]                         # window (1개)
    history = old_hist + recent_hist

    curr = _diff("A", "B")
    primary = curr.aggregate_causes(
        history=history,
        recurrence_window=1,
        residual_decay_factor=0.1,
        top_k=5,
    )
    assert primary is not None
    a_factor = primary if primary.name == "A" else None
    # A는 window 에 없지만 residual 3회 × 0.1 = 0.3 가산 → B보다 높을 수 있음
    a_primary = curr.aggregate_causes(history=history, recurrence_window=1,
                                       residual_decay_factor=0.1, top_k=5)
    # residual weight 가 반영됐으면 A 의 primary.residual_weight > 0
    if a_primary and a_primary.name == "A":
        assert a_primary.residual_weight == pytest.approx(0.3)


def test_residual_decay_factor_zero_ignores_old_history() -> None:
    """residual_decay_factor=0.0이면 window 밖 이력은 완전 무시된다."""
    old_hist = [_diff("A") for _ in range(10)]   # residual (많음)
    recent_hist = [_diff("B")]                    # window
    history = old_hist + recent_hist

    curr = _diff("A", "B")
    primary = curr.aggregate_causes(
        history=history,
        recurrence_window=1,
        residual_decay_factor=0.0,
        top_k=5,
    )
    # residual 무시 → A 의 residual_weight == 0
    if primary and primary.name == "A":
        assert primary.residual_weight == pytest.approx(0.0)
    # B 가 window 에 있으므로 B 가 primary 가 됨 (recurrence_count=1)
    assert primary is not None
    assert primary.name == "B"


# ── to_causal_mermaid ─────────────────────────────────────────────────────────


def test_to_causal_mermaid_includes_correlation_label() -> None:
    """to_causal_mermaid()가 correlation 레이블을 엣지에 포함한다."""
    curr = _diff("A", "B")
    # B 의 correlation 을 수동으로 설정
    curr.causal_factors[1].correlation = 0.5
    diagram = curr.to_causal_mermaid()
    assert "corr=" in diagram


def test_to_causal_mermaid_low_correlation_dashed_edge() -> None:
    """correlation < 0.3이면 점선 엣지 표시 (-. ... .->)."""
    curr = _diff("A", "B")
    curr.causal_factors[0].confidence_score = 0.9  # A 가 첫 번째 노드
    curr.causal_factors[1].confidence_score = 0.5
    curr.causal_factors[1].correlation = 0.1       # < 0.3 → 점선
    diagram = curr.to_causal_mermaid()
    assert ".->" in diagram


def test_to_causal_mermaid_residual_label_shown() -> None:
    """residual_weight > 0인 factor에 (잔류) 레이블이 표시된다."""
    curr = _diff("A", "B")
    curr.causal_factors[0].residual_weight = 0.3
    diagram = curr.to_causal_mermaid()
    assert "(잔류)" in diagram


# ── compute_correlations 독립 호출 ────────────────────────────────────────────


def test_compute_correlations_callable_independently() -> None:
    """compute_correlations()가 aggregate 없이 독립 호출 가능하다."""
    history = [_diff("A", "B"), _diff("A", "B")]
    curr = _diff("A", "B")
    # aggregate_causes 없이 직접 호출
    curr.compute_correlations(history)
    a = next(f for f in curr.causal_factors if f.name == "A")
    assert a.correlation == pytest.approx(1.0)
