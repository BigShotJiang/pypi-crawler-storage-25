"""M32 NoopEventBus — 제로 오버헤드 이벤트 버스 테스트."""

from __future__ import annotations

import asyncio

from pylego.core.assembly import Assembly
from pylego.core.block import Block
from pylego.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
    NoopEventBus,
    observe,
)
from pylego.core.stud import Stud


# ── 픽스처 ────────────────────────────────────────────────────────────────────


class _In(Stud):
    value: int


class _Out(Stud):
    result: str


class _SimpleBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=str(inp.value))


# ── 테스트 ────────────────────────────────────────────────────────────────────


def test_noop_emits_nothing() -> None:
    """이벤트를 emit해도 오류 없이 통과한다."""
    bus = NoopEventBus()
    event = BlockStartedEvent(block_name="test", input=_In(value=1))
    bus.emit(event)  # 오류 없이 통과해야 함


def test_noop_with_observe() -> None:
    """`observe(NoopEventBus())`로 Assembly 실행 시 정상 동작한다."""
    asm: Assembly[_In, _Out] = Assembly([_SimpleBlock()])
    with observe(NoopEventBus()):
        result = asm.run_sync(_In(value=42))
    assert result.result == "42"


def test_noop_implements_protocol() -> None:
    """`NoopEventBus`가 `EventBus` 프로토콜과 duck typing 호환된다."""
    bus = NoopEventBus()
    # duck typing: emit 메서드가 존재하며 callable이어야 함
    assert callable(bus.emit)


def test_noop_all_event_types() -> None:
    """모든 BlockEvent 타입을 emit해도 오류 없음."""
    bus = NoopEventBus()

    dummy_error = ValueError("test error")

    bus.emit(BlockStartedEvent(block_name="b", input=_In(value=0)))
    bus.emit(
        BlockCompletedEvent(block_name="b", output=_Out(result="x"), elapsed_sec=0.001)
    )
    bus.emit(
        BlockFailedEvent(block_name="b", error=dummy_error, elapsed_sec=0.001)
    )
    bus.emit(
        BlockRetryEvent(
            block_name="b",
            attempt=1,
            max_attempts=3,
            error=dummy_error,
            delay_sec=0.5,
        )
    )
    bus.emit(
        CircuitBreakerStateEvent(
            block_name="b",
            previous_state="closed",
            new_state="open",
        )
    )
    # 위의 모든 emit이 예외 없이 완료되어야 함


async def _run_async(asm: Assembly[_In, _Out], inp: _In) -> _Out:
    return await asm.run(inp)


def test_noop_with_observe_async() -> None:
    """`observe(NoopEventBus())`로 비동기 Assembly 실행도 정상 동작한다."""
    asm: Assembly[_In, _Out] = Assembly([_SimpleBlock()])
    with observe(NoopEventBus()):
        result = asyncio.run(_run_async(asm, _In(value=7)))
    assert result.result == "7"
