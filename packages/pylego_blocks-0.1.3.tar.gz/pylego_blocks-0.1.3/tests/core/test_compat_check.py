"""pylego.core.compat — check_chain / check_connection 테스트 (M89)."""

from __future__ import annotations

import pytest

from pylego import Block, Stud
from pylego.core.compat import (
    CompatibilityError,
    CompatibilityResult,
    check_chain,
    check_connection,
)


class _A(Stud):
    a: int


class _B(Stud):
    b: str


class _C(Stud):
    c: float


class _AB(Block[_A, _B]):
    input_model = _A
    output_model = _B

    async def run(self, inp: _A) -> _B:
        return _B(b=str(inp.a))


class _BC(Block[_B, _C]):
    input_model = _B
    output_model = _C

    async def run(self, inp: _B) -> _C:
        return _C(c=float(inp.b))


class _AC(Block[_A, _C]):
    input_model = _A
    output_model = _C

    async def run(self, inp: _A) -> _C:
        return _C(c=float(inp.a))


# ── check_connection ──────────────────────────────────────────────────────────

def test_check_connection_compatible_classes() -> None:
    assert check_connection(_AB, _BC) is True


def test_check_connection_incompatible_classes() -> None:
    assert check_connection(_BC, _AB) is False


def test_check_connection_compatible_instances() -> None:
    assert check_connection(_AB(), _BC()) is True


def test_check_connection_incompatible_instances() -> None:
    assert check_connection(_BC(), _AB()) is False


def test_check_connection_mixed_class_and_instance() -> None:
    assert check_connection(_AB, _BC()) is True
    assert check_connection(_AB(), _BC) is True


def test_check_connection_same_output_input() -> None:
    assert check_connection(_AB, _BC) is True


def test_check_connection_no_shared_stud() -> None:
    assert check_connection(_AC, _AB) is False


# ── check_chain ───────────────────────────────────────────────────────────────

def test_check_chain_single_block_is_compatible() -> None:
    result = check_chain([_AB()])
    assert isinstance(result, CompatibilityResult)
    assert result.compatible is True
    assert result.errors == []


def test_check_chain_empty_list_is_compatible() -> None:
    result = check_chain([])
    assert result.compatible is True
    assert result.errors == []


def test_check_chain_two_compatible_blocks() -> None:
    result = check_chain([_AB(), _BC()])
    assert result.compatible is True
    assert result.errors == []


def test_check_chain_three_compatible_blocks() -> None:
    result = check_chain([_AB(), _BC(), _AB()])
    # _BC output (_C) != _AB input (_A) — last pair is incompatible
    assert result.compatible is False
    assert len(result.errors) == 1


def test_check_chain_three_fully_compatible_blocks() -> None:
    class _CA(Block[_C, _A]):
        input_model = _C
        output_model = _A

        async def run(self, inp: _C) -> _A:
            return _A(a=int(inp.c))

    result = check_chain([_AB(), _BC(), _CA()])
    assert result.compatible is True
    assert result.errors == []


def test_check_chain_incompatible_pair_error_info() -> None:
    result = check_chain([_BC(), _AB()])
    assert result.compatible is False
    assert len(result.errors) == 1
    err = result.errors[0]
    assert isinstance(err, CompatibilityError)
    assert err.position == 0
    assert err.left_block == "_BC"
    assert err.right_block == "_AB"
    assert err.expected == "_C"
    assert err.got == "_A"


def test_check_chain_multiple_errors() -> None:
    # _BC→_AB: _C != _A, _AB→_AC: _B != _A
    result = check_chain([_BC(), _AB(), _AC()])
    assert result.compatible is False
    assert len(result.errors) == 2
    assert result.errors[0].position == 0
    assert result.errors[1].position == 1


def test_check_chain_accepts_classes() -> None:
    result = check_chain([_AB, _BC])
    assert result.compatible is True


def test_check_chain_accepts_mixed() -> None:
    result = check_chain([_AB(), _BC])
    assert result.compatible is True


def test_check_chain_result_is_compatibility_result() -> None:
    result = check_chain([_AB(), _BC()])
    assert isinstance(result, CompatibilityResult)


def test_check_chain_error_fields_are_block_names() -> None:
    result = check_chain([_AC(), _AB()])
    err = result.errors[0]
    assert "_AC" in err.left_block
    assert "_AB" in err.right_block


# ── top-level import ──────────────────────────────────────────────────────────

def test_top_level_import() -> None:
    from pylego import check_chain as cc, check_connection as con
    from pylego import CompatibilityError as CE, CompatibilityResult as CR
    assert cc is check_chain
    assert con is check_connection
    assert CE is CompatibilityError
    assert CR is CompatibilityResult
