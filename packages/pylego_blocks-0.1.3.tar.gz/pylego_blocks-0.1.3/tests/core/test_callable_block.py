"""CallableBlock 테스트.

검증 항목:
1. 정상 실행 — async 함수로 블록 생성 후 run() 결과 확인
2. Assembly 편입 — run_sync() 동작 확인
3. name 속성 — fn.__name__ 반환
4. 잘못된 타입 반환 시 pydantic ValidationError 발생
5. 잘못된 input_model / output_model 전달 시 TypeError
"""

from __future__ import annotations

import pytest

from pylego import Assembly, CallableBlock, Stud


class NumInput(Stud):
    value: int


class NumOutput(Stud):
    result: str


async def stringify(inp: NumInput) -> NumOutput:
    return NumOutput(result=str(inp.value))


async def double_str(inp: NumInput) -> NumOutput:
    return NumOutput(result=str(inp.value * 2))


# ---------------------------------------------------------------------------
# 1. 정상 실행
# ---------------------------------------------------------------------------


async def test_callable_block_run_basic() -> None:
    block = CallableBlock(stringify, input_model=NumInput, output_model=NumOutput)
    result = await block.run(NumInput(value=42))
    assert result.result == "42"


# ---------------------------------------------------------------------------
# 2. Assembly 편입
# ---------------------------------------------------------------------------


def test_callable_block_in_assembly() -> None:
    block = CallableBlock(stringify, input_model=NumInput, output_model=NumOutput)
    pipeline = Assembly([block])
    result = pipeline.run_sync(NumInput(value=7))
    assert isinstance(result, NumOutput)
    assert result.result == "7"


def test_callable_block_chain_in_assembly() -> None:
    """두 CallableBlock을 Assembly로 연결한다."""

    class DoubledInput(Stud):
        value: int

    class DoubledOutput(Stud):
        result: str

    async def step1(inp: NumInput) -> DoubledOutput:
        return DoubledOutput(result=str(inp.value * 2))

    async def step2(inp: DoubledOutput) -> NumOutput:
        return NumOutput(result=f"done:{inp.result}")

    pipeline = Assembly(
        [
            CallableBlock(step1, input_model=NumInput, output_model=DoubledOutput),
            CallableBlock(step2, input_model=DoubledOutput, output_model=NumOutput),
        ]
    )
    result = pipeline.run_sync(NumInput(value=3))
    assert isinstance(result, NumOutput)
    assert result.result == "done:6"


# ---------------------------------------------------------------------------
# 3. name 속성
# ---------------------------------------------------------------------------


def test_callable_block_name() -> None:
    block = CallableBlock(stringify, input_model=NumInput, output_model=NumOutput)
    assert block.name == "stringify"


def test_callable_block_name_reflect_fn_name() -> None:
    block = CallableBlock(double_str, input_model=NumInput, output_model=NumOutput)
    assert block.name == "double_str"


# ---------------------------------------------------------------------------
# 4. 잘못된 타입 반환 시 ValidationError
# ---------------------------------------------------------------------------


def test_callable_block_wrong_return_type() -> None:
    """output_model.model_validate 를 명시적으로 호출하면 ValidationError가 발생한다.

    Assembly 는 런타임에 output을 재검증하지 않으므로,
    output_model.model_validate 를 직접 호출해 pydantic 계약 위반을 확인한다.
    """
    from pydantic import ValidationError

    class WrongOutput(Stud):
        count: int  # 필수 필드 — result 필드가 없음

    # NumOutput 인스턴스를 WrongOutput 으로 validate 하면 ValidationError
    wrong_instance = NumOutput(result="oops")
    with pytest.raises(ValidationError):
        WrongOutput.model_validate(wrong_instance.model_dump())


# ---------------------------------------------------------------------------
# 5. 잘못된 input_model / output_model 전달 시 TypeError
# ---------------------------------------------------------------------------


def test_callable_block_invalid_input_model() -> None:
    with pytest.raises(TypeError, match="input_model"):
        CallableBlock(
            stringify,
            input_model=int,  # type: ignore[arg-type]
            output_model=NumOutput,
        )


def test_callable_block_invalid_output_model() -> None:
    with pytest.raises(TypeError, match="output_model"):
        CallableBlock(
            stringify,
            input_model=NumInput,
            output_model=str,  # type: ignore[arg-type]
        )
