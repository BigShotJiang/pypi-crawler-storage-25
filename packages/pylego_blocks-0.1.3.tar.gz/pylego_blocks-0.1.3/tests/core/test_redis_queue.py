"""M19 Redis 분산 작업 큐 테스트.

실제 Redis 서버 없이 redis.asyncio 클라이언트를 인메모리 mock 으로 대체한다.
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego.core.block import Block
from pylego.core.stud import Stud


# ─── 픽스처 ──────────────────────────────────────────────────────────────────


class _Num(Stud):
    value: int


class _Result(Stud):
    doubled: int


class _DoubleBlock(Block[_Num, _Result]):
    input_model = _Num
    output_model = _Result

    async def run(self, inp: _Num) -> _Result:
        return _Result(doubled=inp.value * 2)


# ─── 인메모리 Mock Redis 클라이언트 ─────────────────────────────────────────


class _MockRedisClient:
    """asyncio.Queue 기반 인메모리 Redis mock.

    실제 Redis BLPOP / RPUSH / LLEN / LRANGE / LREM 동작을 모사한다.
    """

    def __init__(self) -> None:
        self._queues: dict[str | bytes, asyncio.Queue[bytes]] = {}
        self._closed = False

    def _get_q(self, key: str | bytes) -> asyncio.Queue[bytes]:
        if key not in self._queues:
            self._queues[key] = asyncio.Queue()
        return self._queues[key]

    async def rpush(self, key: str | bytes, value: bytes) -> int:
        q = self._get_q(key)
        await q.put(value)
        return q.qsize()

    async def blpop(
        self, keys: list[str | bytes], timeout: int = 0
    ) -> tuple[bytes, bytes] | None:
        key = keys[0]
        q = self._get_q(key)
        try:
            item = await asyncio.wait_for(q.get(), timeout=1.0)
            return (key if isinstance(key, bytes) else key.encode(), item)
        except asyncio.TimeoutError:
            return None

    async def llen(self, key: str | bytes) -> int:
        return self._get_q(key).qsize()

    async def lrange(self, key: str | bytes, start: int, end: int) -> list[bytes]:
        q = self._get_q(key)
        items = list(q._queue)  # type: ignore[attr-defined]
        if end == -1:
            return items[start:]
        return items[start : end + 1]

    async def lrem(self, key: str | bytes, count: int, value: bytes) -> int:
        q = self._get_q(key)
        old_items = list(q._queue)  # type: ignore[attr-defined]
        removed = 0
        new_items = []
        for item in old_items:
            if item == value and (count == 0 or removed < abs(count)):
                removed += 1
            else:
                new_items.append(item)
        q._queue.clear()  # type: ignore[attr-defined]
        for item in new_items:
            q.put_nowait(item)
        return removed

    async def aclose(self) -> None:
        self._closed = True


@pytest.fixture()
def mock_redis() -> _MockRedisClient:
    return _MockRedisClient()


@pytest.fixture()
def patch_redis(mock_redis: _MockRedisClient):  # type: ignore[no-untyped-def]
    """redis.asyncio 모듈을 sys.modules 에 직접 주입해 실제 패키지 없이 테스트한다."""
    import types

    redis_mod = types.ModuleType("redis")
    asyncio_mod = types.ModuleType("redis.asyncio")
    asyncio_mod.from_url = lambda url, **kw: mock_redis  # type: ignore[attr-defined]
    redis_mod.asyncio = asyncio_mod  # type: ignore[attr-defined]

    saved = {k: sys.modules[k] for k in ("redis", "redis.asyncio") if k in sys.modules}
    if "pylego.core.redis_queue" in sys.modules:
        del sys.modules["pylego.core.redis_queue"]
    sys.modules["redis"] = redis_mod
    sys.modules["redis.asyncio"] = asyncio_mod
    try:
        yield mock_redis
    finally:
        for k in ("redis", "redis.asyncio"):
            if k in saved:
                sys.modules[k] = saved[k]
            elif k in sys.modules:
                del sys.modules[k]
        if "pylego.core.redis_queue" in sys.modules:
            del sys.modules["pylego.core.redis_queue"]


# ─── ImportError ─────────────────────────────────────────────────────────────


class TestImportError:
    def test_redis_queue_import_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        saved = {k: v for k, v in sys.modules.items() if k.startswith("redis")}
        for k in list(sys.modules.keys()):
            if k.startswith("redis"):
                del sys.modules[k]
        if "pylego.core.redis_queue" in sys.modules:
            del sys.modules["pylego.core.redis_queue"]

        import builtins

        real_import = builtins.__import__

        def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name.startswith("redis"):
                raise ImportError(f"No module named '{name}'")
            return real_import(name, *args, **kwargs)

        try:
            monkeypatch.setattr(builtins, "__import__", mock_import)
            from pylego.core.redis_queue import RedisQueue as _RQ

            with pytest.raises(ImportError, match="redis"):
                _RQ(_Num, url="redis://localhost", queue_name="test")
        finally:
            sys.modules.update(saved)
            if "pylego.core.redis_queue" in sys.modules:
                del sys.modules["pylego.core.redis_queue"]


# ─── RedisQueue ──────────────────────────────────────────────────────────────


class TestRedisQueue:
    @pytest.mark.asyncio
    async def test_put_and_consume(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q.put(_Num(value=1))
        await q.put(_Num(value=2))
        await q.close()

        items = [item async for item in q]
        assert [i.value for i in items] == [1, 2]

    @pytest.mark.asyncio
    async def test_close_stops_iteration(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q.close()
        items = [item async for item in q]
        assert items == []

    @pytest.mark.asyncio
    async def test_put_after_close_raises(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q.close()
        with pytest.raises(RuntimeError, match="닫힌 큐"):
            await q.put(_Num(value=1))

    def test_put_nowait_raises(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        with pytest.raises(NotImplementedError):
            q.put_nowait(_Num(value=1))

    def test_close_nowait_raises(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        with pytest.raises(NotImplementedError):
            q.close_nowait()

    @pytest.mark.asyncio
    async def test_closed_property(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        assert not q.closed
        await q.close()
        assert q.closed

    @pytest.mark.asyncio
    async def test_asize(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        assert await q.asize() == 0
        await q.put(_Num(value=1))
        assert await q.asize() == 1

    @pytest.mark.asyncio
    async def test_aclose_client(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q._conn()  # 연결 초기화
        await q.aclose_client()
        assert q._client is None
        assert patch_redis._closed

    @pytest.mark.asyncio
    async def test_double_close_is_idempotent(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q.close()
        await q.close()  # 두 번 close 해도 sentinel 하나만 추가
        items = [item async for item in q]
        assert items == []

    @pytest.mark.asyncio
    async def test_serialization_roundtrip(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="test")
        await q.put(_Num(value=42))
        await q.close()

        items = [item async for item in q]
        assert len(items) == 1
        assert items[0].value == 42
        assert isinstance(items[0], _Num)


# ─── RedisWorkerPool ─────────────────────────────────────────────────────────


class TestRedisWorkerPool:
    @pytest.mark.asyncio
    async def test_basic_processing(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisQueue, RedisWorkerPool

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="src")
        for i in range(3):
            await q.put(_Num(value=i))
        await q.close()

        pool: RedisWorkerPool[_Num, _Result] = RedisWorkerPool(
            _DoubleBlock(), concurrency=1
        )
        results = await pool.run(q)
        assert sorted(r.doubled for r in results) == [0, 2, 4]

    @pytest.mark.asyncio
    async def test_output_queue_receives_results(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, RedisWorkerPool

        src: RedisQueue[_Num] = RedisQueue(_Num, queue_name="src")
        dst: RedisQueue[_Result] = RedisQueue(_Result, queue_name="dst")
        for i in [1, 2, 3]:
            await src.put(_Num(value=i))
        await src.close()

        pool: RedisWorkerPool[_Num, _Result] = RedisWorkerPool(
            _DoubleBlock(), concurrency=2
        )
        await pool.run(src, output=dst)

        assert dst.closed
        items = [item async for item in dst]
        assert sorted(r.doubled for r in items) == [2, 4, 6]

    @pytest.mark.asyncio
    async def test_empty_queue_returns_empty(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, RedisWorkerPool

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="empty")
        await q.close()

        pool: RedisWorkerPool[_Num, _Result] = RedisWorkerPool(_DoubleBlock())
        results = await pool.run(q)
        assert results == []

    def test_invalid_concurrency_raises(self) -> None:
        from pylego.core.redis_queue import RedisWorkerPool

        with pytest.raises(ValueError, match="concurrency"):
            RedisWorkerPool(_DoubleBlock(), concurrency=0)

    @pytest.mark.asyncio
    async def test_concurrency_parallel_processing(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, RedisWorkerPool

        class _SlowBlock(Block[_Num, _Result]):
            input_model = _Num
            output_model = _Result

            async def run(self, inp: _Num) -> _Result:
                await asyncio.sleep(0.05)
                return _Result(doubled=inp.value * 2)

        q: RedisQueue[_Num] = RedisQueue(_Num, queue_name="slow")
        for i in range(4):
            await q.put(_Num(value=i))
        await q.close()

        import time

        pool: RedisWorkerPool[_Num, _Result] = RedisWorkerPool(
            _SlowBlock(), concurrency=4
        )
        t0 = time.monotonic()
        results = await pool.run(q)
        elapsed = time.monotonic() - t0

        assert len(results) == 4
        assert elapsed < 0.3  # 병렬: ~0.05s, 순차: ~0.2s


# ─── RedisDeadLetterQueue ─────────────────────────────────────────────────────


class TestRedisDeadLetterQueue:
    @pytest.mark.asyncio
    async def test_put_failed_and_iterate(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisDeadLetterQueue

        dlq: RedisDeadLetterQueue[_Num] = RedisDeadLetterQueue(
            _Num, queue_name="dlq"
        )
        await dlq.put_failed(_Num(value=1), reason="error A")
        await dlq.put_failed(_Num(value=2), reason="error B")

        items = [(item, reason) async for item, reason in dlq.failed_items()]
        assert len(items) == 2
        assert items[0][0].value == 1
        assert items[0][1] == "error A"
        assert items[1][0].value == 2
        assert items[1][1] == "error B"

    @pytest.mark.asyncio
    async def test_failed_count(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisDeadLetterQueue

        dlq: RedisDeadLetterQueue[_Num] = RedisDeadLetterQueue(
            _Num, queue_name="dlq"
        )
        assert await dlq.failed_count() == 0
        await dlq.put_failed(_Num(value=1), reason="e1")
        assert await dlq.failed_count() == 1

    @pytest.mark.asyncio
    async def test_retry_moves_item(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisDeadLetterQueue, RedisQueue

        dlq: RedisDeadLetterQueue[_Num] = RedisDeadLetterQueue(
            _Num, queue_name="dlq"
        )
        target: RedisQueue[_Num] = RedisQueue(_Num, queue_name="retry")
        item = _Num(value=42)
        await dlq.put_failed(item, reason="retry me")
        await dlq.retry(item, target)

        assert await dlq.failed_count() == 0
        await target.close()
        results = [i async for i in target]
        assert len(results) == 1
        assert results[0].value == 42

    @pytest.mark.asyncio
    async def test_retry_missing_item_raises(
        self, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisDeadLetterQueue, RedisQueue

        dlq: RedisDeadLetterQueue[_Num] = RedisDeadLetterQueue(
            _Num, queue_name="dlq"
        )
        target: RedisQueue[_Num] = RedisQueue(_Num, queue_name="retry")
        with pytest.raises(KeyError):
            await dlq.retry(_Num(value=99), target)

    @pytest.mark.asyncio
    async def test_aclose_client(self, patch_redis: _MockRedisClient) -> None:
        from pylego.core.redis_queue import RedisDeadLetterQueue

        dlq: RedisDeadLetterQueue[_Num] = RedisDeadLetterQueue(
            _Num, queue_name="dlq"
        )
        await dlq._conn()
        await dlq.aclose_client()
        assert dlq._client is None


# ─── make_queue 팩토리 ────────────────────────────────────────────────────────


class TestMakeQueue:
    def test_asyncio_backend_by_default(self) -> None:
        from pylego.core.queue import Queue
        from pylego.core.redis_queue import make_queue

        q = make_queue(_Num)
        assert isinstance(q, Queue)

    def test_redis_backend_via_env(
        self, monkeypatch: pytest.MonkeyPatch, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, make_queue

        monkeypatch.setenv("PYLEGO_QUEUE_BACKEND", "redis")
        monkeypatch.setenv("PYLEGO_REDIS_URL", "redis://localhost:6379")
        q = make_queue(_Num, queue_name="env-test")
        assert isinstance(q, RedisQueue)

    def test_redis_url_default(
        self, monkeypatch: pytest.MonkeyPatch, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, make_queue

        monkeypatch.setenv("PYLEGO_QUEUE_BACKEND", "redis")
        monkeypatch.delenv("PYLEGO_REDIS_URL", raising=False)
        q = make_queue(_Num)
        assert isinstance(q, RedisQueue)
        assert q._url == "redis://localhost:6379"

    def test_queue_name_passed(
        self, monkeypatch: pytest.MonkeyPatch, patch_redis: _MockRedisClient
    ) -> None:
        from pylego.core.redis_queue import RedisQueue, make_queue

        monkeypatch.setenv("PYLEGO_QUEUE_BACKEND", "redis")
        q = make_queue(_Num, queue_name="custom:queue")
        assert isinstance(q, RedisQueue)
        assert q._queue_name == "custom:queue"
