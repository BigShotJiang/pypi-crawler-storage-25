"""M105 — HealthDiff priority scoring + VersionContext 테스트."""

from __future__ import annotations

from pylego.core.events import BlockFailedEvent
from pylego.core.graph import (
    HealthDiff,
    PipelineHealth,
    VersionContext,
    build_health_summary,
)


# ── helpers ──────────────────────────────────────────────────────────────────


def _h(
    overall: str = "ok",
    error_blocks: list[str] | None = None,
    block_elapsed: dict[str, float] | None = None,
    error_details: dict[str, BlockFailedEvent] | None = None,
    version_context: VersionContext | None = None,
) -> PipelineHealth:
    eb = error_blocks or []
    be = block_elapsed or {}
    total = max(len(eb), len(be), 1)
    return PipelineHealth(  # type: ignore[arg-type]
        overall=overall,  # type: ignore[arg-type]
        total_blocks=total,
        error_blocks=eb,
        slowest_block=None,
        slowest_elapsed_sec=None,
        avg_elapsed_sec=None,
        error_details=error_details,
        block_elapsed=be or None,
        version_context=version_context,
    )


def _failed_event(name: str, error_type: str | None = None) -> BlockFailedEvent:
    return BlockFailedEvent(
        block_name=name,
        error=RuntimeError("err"),
        elapsed_sec=0.1,
        timestamp=0.0,
        error_type=error_type,
    )


# ── VersionContext ─────────────────────────────────────────────────────────


def test_version_context_defaults() -> None:
    vc = VersionContext(version="1.2.3")
    assert vc.version == "1.2.3"
    assert vc.deployed_at is None
    assert vc.changed_blocks == []
    assert vc.notes is None


def test_version_context_fields() -> None:
    vc = VersionContext(
        version="2.0.0",
        deployed_at="2026-04-27T12:00:00Z",
        changed_blocks=["BlockA", "BlockB"],
        notes="DB 연결 풀 교체",
    )
    assert vc.deployed_at == "2026-04-27T12:00:00Z"
    assert vc.changed_blocks == ["BlockA", "BlockB"]
    assert vc.notes == "DB 연결 풀 교체"


# ── HealthDiff 기본값 ──────────────────────────────────────────────────────


def test_health_diff_default_severity() -> None:
    d = HealthDiff()
    assert d.severity == "ok"
    assert d.critical_changes == []


# ── severity 판정 ─────────────────────────────────────────────────────────


def test_severity_critical_on_new_failure() -> None:
    prev = _h(overall="ok")
    curr = _h(overall="critical", error_blocks=["BlockA"])
    diff = curr.diff(prev)
    assert diff.severity == "critical"
    assert diff.new_failures == ["BlockA"]


def test_severity_major_on_error_type_change() -> None:
    ev_prev = _failed_event("BlockA", error_type="ConnectionError")
    ev_curr = _failed_event("BlockA", error_type="TimeoutError")
    prev = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev_prev})
    curr = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev_curr})
    diff = curr.diff(prev)
    assert diff.severity == "major"
    assert "BlockA" in diff.error_type_changes


def test_severity_major_on_50pct_slowdown() -> None:
    prev = _h(block_elapsed={"BlockA": 1.0})
    curr = _h(block_elapsed={"BlockA": 1.5})
    diff = curr.diff(prev)
    assert diff.severity == "major"


def test_severity_minor_on_small_slowdown() -> None:
    prev = _h(block_elapsed={"BlockA": 1.0})
    curr = _h(block_elapsed={"BlockA": 1.3})
    diff = curr.diff(prev)
    assert diff.severity == "minor"


def test_severity_ok_when_only_recovered() -> None:
    ev = _failed_event("BlockA")
    prev = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev})
    curr = _h(overall="ok")
    diff = curr.diff(prev)
    assert diff.severity == "ok"
    assert diff.recovered == ["BlockA"]


def test_severity_ok_when_no_changes() -> None:
    prev = _h(overall="ok", block_elapsed={"B": 1.0})
    curr = _h(overall="ok", block_elapsed={"B": 1.0})
    diff = curr.diff(prev)
    assert diff.severity == "ok"
    assert diff.critical_changes == []


# ── critical_changes 내용 ─────────────────────────────────────────────────


def test_critical_changes_new_failure_label() -> None:
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockX"])
    diff = curr.diff(prev)
    assert any("[CRITICAL]" in c and "BlockX" in c for c in diff.critical_changes)


def test_critical_changes_error_type_label() -> None:
    ev_prev = _failed_event("BlockA", error_type="ConnectionError")
    ev_curr = _failed_event("BlockA", error_type="TimeoutError")
    prev = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev_prev})
    curr = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev_curr})
    diff = curr.diff(prev)
    assert any("[MAJOR]" in c and "BlockA" in c for c in diff.critical_changes)


def test_critical_changes_major_slowdown_label() -> None:
    prev = _h(block_elapsed={"B": 1.0})
    curr = _h(block_elapsed={"B": 2.0})
    diff = curr.diff(prev)
    assert any("[MAJOR]" in c and "B" in c for c in diff.critical_changes)


def test_critical_changes_minor_slowdown_label() -> None:
    prev = _h(block_elapsed={"B": 1.0})
    curr = _h(block_elapsed={"B": 1.3})
    diff = curr.diff(prev)
    assert any("[MINOR]" in c and "B" in c for c in diff.critical_changes)


def test_critical_changes_recovered_label() -> None:
    ev = _failed_event("BlockA")
    prev = _h(overall="critical", error_blocks=["BlockA"], error_details={"BlockA": ev})
    curr = _h(overall="ok")
    diff = curr.diff(prev)
    assert any("[OK]" in c and "BlockA" in c for c in diff.critical_changes)


def test_critical_changes_capped_at_5() -> None:
    prev = _h()
    error_blocks = [f"Block{i}" for i in range(10)]
    curr = _h(overall="critical", error_blocks=error_blocks)
    diff = curr.diff(prev)
    assert len(diff.critical_changes) <= 5


def test_critical_changes_priority_new_failures_first() -> None:
    ev_prev = _failed_event("BlockA", error_type="ConnectionError")
    ev_curr = _failed_event("BlockA", error_type="TimeoutError")
    prev = _h(
        overall="ok",
        error_blocks=["BlockA"],
        error_details={"BlockA": ev_prev},
        block_elapsed={"BlockA": 1.0},
    )
    curr = _h(
        overall="critical",
        error_blocks=["BlockA", "BlockB"],
        error_details={"BlockA": ev_curr},
        block_elapsed={"BlockA": 1.3},
    )
    diff = curr.diff(prev)
    # BlockB가 신규 실패이므로 첫 번째 항목이 [CRITICAL] 이어야 함
    assert diff.critical_changes[0].startswith("[CRITICAL]")


# ── to_ai_summary diff 섹션 ───────────────────────────────────────────────


def test_to_ai_summary_shows_severity() -> None:
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"])
    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)
    assert "위험" in summary
    assert "이전 대비 변화" in summary


def test_to_ai_summary_shows_critical_changes() -> None:
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockX"])
    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)
    assert "BlockX" in summary
    assert "[CRITICAL]" in summary


def test_to_ai_summary_no_changes_message() -> None:
    prev = _h(overall="ok", block_elapsed={"B": 1.0})
    curr = _h(overall="ok", block_elapsed={"B": 1.0})
    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)
    assert "변화 없음" in summary


# ── to_ai_summary version_context ────────────────────────────────────────


def test_to_ai_summary_version_context_causal_hint() -> None:
    vc = VersionContext(version="3.1.0", changed_blocks=["BlockA"])
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    summary = curr.to_ai_summary()
    assert "3.1.0" in summary
    assert "BlockA" in summary


def test_to_ai_summary_version_context_no_overlap() -> None:
    vc = VersionContext(version="3.1.0", changed_blocks=["BlockC"])
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    summary = curr.to_ai_summary()
    assert "3.1.0" in summary


def test_to_ai_summary_version_context_notes() -> None:
    vc = VersionContext(version="4.0.0", notes="Redis 연결 풀 변경")
    curr = _h(overall="ok", version_context=vc)
    summary = curr.to_ai_summary()
    assert "Redis 연결 풀 변경" in summary


# ── build_health_summary version_context 전달 ─────────────────────────────


def test_build_health_summary_accepts_version_context() -> None:
    vc = VersionContext(version="5.0.0")
    health = build_health_summary([], version_context=vc)
    assert health.version_context is vc
    assert health.version_context.version == "5.0.0"


def test_build_health_summary_version_context_not_on_sub() -> None:
    from pylego.core.events import BlockCompletedEvent

    vc = VersionContext(version="1.0.0")
    ev = BlockCompletedEvent(
        block_name="ns/BlockA", output=None, elapsed_sec=0.1, timestamp=0.0
    )
    health = build_health_summary([ev], version_context=vc)
    assert health.version_context is vc
    # sub_health 는 version_context를 전달받지 않음
    assert health.sub_health is not None
    sub = health.sub_health["ns"]
    assert sub.version_context is None
