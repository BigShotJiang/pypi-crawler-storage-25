"""BlockBuilder / wrap() 플루언트 빌더 테스트."""

import asyncio

from pylego import Block, Stud
from pylego.core.builder import BlockBuilder, wrap
from pylego.core.resilience import (
    CircuitBreakerBlock,
    FallbackBlock,
    RetryBlock,
    TimeoutBlock,
)


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v + 1)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("fail")


def test_wrap_returns_builder() -> None:
    b = wrap(_OkBlock())
    assert isinstance(b, BlockBuilder)


def test_build_identity() -> None:
    inner = _OkBlock()
    result = wrap(inner).build()
    assert result is inner


def test_retry_wraps() -> None:
    block = wrap(_OkBlock()).retry().build()
    assert isinstance(block, RetryBlock)


def test_circuit_breaker_wraps() -> None:
    block = wrap(_OkBlock()).circuit_breaker(failure_threshold=3).build()
    assert isinstance(block, CircuitBreakerBlock)


def test_timeout_wraps() -> None:
    block = wrap(_OkBlock()).timeout(5.0).build()
    assert isinstance(block, TimeoutBlock)


def test_fallback_wraps() -> None:
    block = wrap(_FailBlock()).fallback(_OkBlock()).build()
    assert isinstance(block, FallbackBlock)


def test_chain_and_run() -> None:
    block = wrap(_OkBlock()).retry().build()
    result = asyncio.run(block.run(_In(v=1)))
    assert result.v == 2


def test_multi_chain() -> None:
    block = (
        wrap(_OkBlock())
        .retry()
        .circuit_breaker(failure_threshold=5)
        .build()
    )
    result = asyncio.run(block.run(_In(v=10)))
    assert result.v == 11
