"""Stud 기본 동작 검증."""

from __future__ import annotations

from pydantic import ConfigDict

from pylego.core import Stud


class _DefaultStud(Stud):
    value: str


class _MutableStud(Stud):
    model_config = ConfigDict(extra="forbid", frozen=False)
    value: str


class _ExplicitFrozenStud(Stud):
    model_config = ConfigDict(extra="forbid", frozen=True)
    value: str


class TestStudIsFrozen:
    def test_base_class_is_frozen(self) -> None:
        assert Stud.is_frozen is True

    def test_default_subclass_is_frozen(self) -> None:
        assert _DefaultStud.is_frozen is True

    def test_override_to_mutable(self) -> None:
        assert _MutableStud.is_frozen is False

    def test_explicit_frozen_override(self) -> None:
        assert _ExplicitFrozenStud.is_frozen is True
