"""graph.py — Mermaid / DOT / HTML 렌더링 단위 테스트."""

from __future__ import annotations

import pytest

from pylego.core.assembly import Assembly
from pylego.core.block import Block
from pylego.core.branch import Branch
from pylego.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockStartedEvent,
    CollectingEventBus,
)
from pylego.core.fanout import FanOut
from pylego.core.graph import BlockStat, build_stats, to_dot, to_html, to_mermaid
from pylego.core.stud import Stud


# ─── fixtures ────────────────────────────────────────────────────────────────

class _S(Stud):
    v: int = 0


class _BlockA(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _BlockB(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


class _BlockC(Block[_S, _S]):
    input_model = _S
    output_model = _S

    async def run(self, inp: _S) -> _S:
        return inp


@pytest.fixture()
def linear_asm() -> Assembly[_S, _S]:
    return Assembly([_BlockA(), _BlockB(), _BlockC()], name="LinearAsm")


@pytest.fixture()
def nested_asm() -> Assembly[_S, _S]:
    inner = Assembly([_BlockB(), _BlockC()], name="InnerAsm")
    return Assembly([_BlockA(), inner], name="OuterAsm")


@pytest.fixture()
def fanout_asm() -> Assembly[_S, _S]:
    fo: FanOut = FanOut([_BlockA(), _BlockB()], name="MyFanOut")
    return Assembly([fo], name="FanOutAsm")


@pytest.fixture()
def branch_asm() -> Assembly[_S, _S]:
    br: Branch[_S, _S] = Branch(
        lambda s: s.v > 0,
        _BlockA(),
        _BlockB(),
        name="MyBranch",
    )
    return Assembly([br], name="BranchAsm")


# ─── to_mermaid ──────────────────────────────────────────────────────────────

class TestToMermaid:
    def test_starts_with_flowchart_lr(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(linear_asm)
        assert text.startswith("flowchart LR\n")

    def test_linear_contains_block_names(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(linear_asm)
        assert "_BlockA" in text
        assert "_BlockB" in text
        assert "_BlockC" in text

    def test_linear_has_assembly_subgraph(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(linear_asm)
        assert 'subgraph' in text
        assert "LinearAsm" in text

    def test_linear_has_edges(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(linear_asm)
        assert "-->" in text

    def test_nested_shows_inner_and_outer(self, nested_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(nested_asm)
        assert "OuterAsm" in text
        assert "InnerAsm" in text
        assert "_BlockA" in text
        assert "_BlockB" in text
        assert "_BlockC" in text

    def test_fanout_shows_fanout_and_gathered(self, fanout_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(fanout_asm)
        assert "MyFanOut" in text
        assert "Gathered" in text

    def test_branch_shows_true_false_labels(self, branch_asm: Assembly[_S, _S]) -> None:
        text = to_mermaid(branch_asm)
        assert "true" in text
        assert "false" in text
        assert "MyBranch" in text

    def test_plain_block(self) -> None:
        text = to_mermaid(_BlockA())
        assert "flowchart LR" in text
        assert "_BlockA" in text

    def test_special_chars_escaped(self) -> None:
        class _Special(Block[_S, _S]):
            name = 'A"B<C>'
            input_model = _S
            output_model = _S

            async def run(self, inp: _S) -> _S:
                return inp

        text = to_mermaid(_Special())
        # The special chars inside the label should be escaped
        assert "#quot;" in text  # " → #quot;
        assert "#lt;" in text    # < → #lt;
        assert "#gt;" in text    # > → #gt;


# ─── to_dot ──────────────────────────────────────────────────────────────────

class TestToDot:
    def test_starts_with_digraph(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_dot(linear_asm)
        assert text.startswith("digraph G {")

    def test_rankdir_lr(self, linear_asm: Assembly[_S, _S]) -> None:
        assert "rankdir=LR" in to_dot(linear_asm)

    def test_contains_block_names(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_dot(linear_asm)
        assert "_BlockA" in text
        assert "_BlockB" in text

    def test_has_arrows(self, linear_asm: Assembly[_S, _S]) -> None:
        assert "->" in to_dot(linear_asm)

    def test_assembly_cluster(self, linear_asm: Assembly[_S, _S]) -> None:
        text = to_dot(linear_asm)
        assert "subgraph cluster_" in text
        assert "LinearAsm" in text

    def test_fanout_shows_circles(self, fanout_asm: Assembly[_S, _S]) -> None:
        text = to_dot(fanout_asm)
        assert "shape=circle" in text
        assert "Gathered" in text

    def test_branch_shows_diamond(self, branch_asm: Assembly[_S, _S]) -> None:
        text = to_dot(branch_asm)
        assert "shape=diamond" in text


# ─── build_stats ─────────────────────────────────────────────────────────────

class TestBuildStats:
    def test_completed_event(self) -> None:
        events = [
            BlockStartedEvent(block_name="A", input=None),
            BlockCompletedEvent(block_name="A", output=None, elapsed_sec=0.1),
        ]
        stats = build_stats(events)
        assert stats["A"].status == "ok"
        assert stats["A"].elapsed_sec == pytest.approx(0.1)

    def test_failed_event(self) -> None:
        events = [
            BlockStartedEvent(block_name="B", input=None),
            BlockFailedEvent(block_name="B", error=ValueError("boom"), elapsed_sec=0.2),
        ]
        stats = build_stats(events)
        assert stats["B"].status == "error"
        assert stats["B"].error_msg == "boom"

    def test_started_only_not_in_stats(self) -> None:
        events = [BlockStartedEvent(block_name="C", input=None)]
        stats = build_stats(events)
        assert "C" not in stats

    def test_multiple_blocks(self) -> None:
        events = [
            BlockCompletedEvent(block_name="A", output=None, elapsed_sec=0.1),
            BlockCompletedEvent(block_name="B", output=None, elapsed_sec=0.2),
        ]
        stats = build_stats(events)
        assert len(stats) == 2


# ─── CollectingEventBus ───────────────────────────────────────────────────────

class TestCollectingEventBus:
    def test_collects_events(self) -> None:
        bus = CollectingEventBus()
        e1 = BlockStartedEvent(block_name="X", input=None)
        e2 = BlockCompletedEvent(block_name="X", output=None, elapsed_sec=0.5)
        bus.emit(e1)
        bus.emit(e2)
        assert len(bus.events) == 2

    def test_events_returns_copy(self) -> None:
        bus = CollectingEventBus()
        bus.emit(BlockStartedEvent(block_name="X", input=None))
        events = bus.events
        events.clear()
        assert len(bus.events) == 1

    def test_combined_with_build_stats(self) -> None:
        bus = CollectingEventBus()
        bus.emit(BlockStartedEvent(block_name="A", input=None))
        bus.emit(BlockCompletedEvent(block_name="A", output=None, elapsed_sec=1.0))
        stats = build_stats(bus.events)
        assert stats["A"].status == "ok"


# ─── to_html ─────────────────────────────────────────────────────────────────

class TestToHtml:
    def test_contains_mermaid_script(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm)
        assert "mermaid" in html

    def test_contains_block_names(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm)
        assert "_BlockA" in html

    def test_custom_title(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm, title="My Report")
        assert "My Report" in html

    def test_default_title_is_assembly_name(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm)
        assert "LinearAsm" in html

    def test_stats_shown_when_provided(self, linear_asm: Assembly[_S, _S]) -> None:
        stats = {
            "_BlockA": BlockStat(name="_BlockA", status="ok", elapsed_sec=0.1),
            "_BlockB": BlockStat(name="_BlockB", status="error", error_msg="oops"),
        }
        html = to_html(linear_asm, stats)
        assert "ok" in html
        assert "error" in html
        assert "oops" in html
        assert "0.100" in html

    def test_no_stats_html_without_stats(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm)
        assert "<table>" not in html

    def test_xss_escaped_in_title(self, linear_asm: Assembly[_S, _S]) -> None:
        html = to_html(linear_asm, title="<script>alert(1)</script>")
        assert "<script>alert(1)</script>" not in html


# ─── Assembly repr methods ────────────────────────────────────────────────────

class TestAssemblyReprMethods:
    def test_repr_mermaid(self, linear_asm: Assembly[_S, _S]) -> None:
        text = linear_asm.__repr_mermaid__()
        assert "flowchart LR" in text
        assert "_BlockA" in text

    def test_repr_dot(self, linear_asm: Assembly[_S, _S]) -> None:
        text = linear_asm.__repr_dot__()
        assert "digraph G" in text
        assert "_BlockA" in text
