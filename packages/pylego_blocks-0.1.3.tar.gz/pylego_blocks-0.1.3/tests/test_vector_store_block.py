"""VectorUpsertBlock / VectorQueryBlock 단위 테스트 — chromadb sys.modules mock."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego import VectorQueryBlock, VectorQueryInput, VectorUpsertBlock, VectorUpsertInput
from pylego.blocks.vector.chromadb_store import VectorQueryResult, VectorUpsertResult


@pytest.fixture()
def mock_chroma() -> Any:
    """chromadb 를 sys.modules mock 으로 교체."""
    collection = MagicMock()
    collection.upsert = MagicMock()
    collection.query = MagicMock(
        return_value={
            "ids": [["id1", "id2"]],
            "distances": [[0.1, 0.3]],
            "documents": [["doc1", "doc2"]],
        }
    )
    client = MagicMock()
    client.get_or_create_collection.return_value = collection

    module = MagicMock()
    module.EphemeralClient.return_value = client
    module.PersistentClient.return_value = client

    with patch.dict("sys.modules", {"chromadb": module}):
        yield {"client": client, "collection": collection}


async def test_upsert_basic(mock_chroma: Any) -> None:
    block = VectorUpsertBlock()
    result = await block.run(
        VectorUpsertInput(
            ids=["a", "b"],
            embeddings=[[0.1, 0.2], [0.3, 0.4]],
            documents=["doc a", "doc b"],
        )
    )
    assert isinstance(result, VectorUpsertResult)
    assert result.upserted_count == 2
    assert result.collection == "default"


async def test_upsert_with_metadatas(mock_chroma: Any) -> None:
    block = VectorUpsertBlock()
    await block.run(
        VectorUpsertInput(
            ids=["x"],
            embeddings=[[0.5, 0.6]],
            metadatas=[{"source": "wiki"}],
        )
    )
    call_kwargs: dict[str, Any] = mock_chroma["collection"].upsert.call_args.kwargs
    assert call_kwargs["metadatas"] == [{"source": "wiki"}]


async def test_upsert_custom_collection(mock_chroma: Any) -> None:
    block = VectorUpsertBlock()
    result = await block.run(
        VectorUpsertInput(collection="my_col", ids=["1"], embeddings=[[0.1]])
    )
    assert result.collection == "my_col"
    mock_chroma["client"].get_or_create_collection.assert_called_with("my_col")


async def test_query_basic(mock_chroma: Any) -> None:
    block = VectorQueryBlock()
    result = await block.run(
        VectorQueryInput(query_embeddings=[[0.1, 0.2]], top_k=2)
    )
    assert isinstance(result, VectorQueryResult)
    assert result.ids == [["id1", "id2"]]
    assert result.distances == [[0.1, 0.3]]
    assert result.documents == [["doc1", "doc2"]]


async def test_query_where_filter(mock_chroma: Any) -> None:
    block = VectorQueryBlock()
    await block.run(
        VectorQueryInput(
            query_embeddings=[[0.1]],
            where={"source": {"$eq": "wiki"}},
        )
    )
    call_kwargs: dict[str, Any] = mock_chroma["collection"].query.call_args.kwargs
    assert call_kwargs["where"] == {"source": {"$eq": "wiki"}}


async def test_persistent_client_used(mock_chroma: Any) -> None:
    block = VectorUpsertBlock(persist_directory="./db")
    await block.run(VectorUpsertInput(ids=["z"], embeddings=[[0.0]]))
    import chromadb  # type: ignore[import]
    chromadb.PersistentClient.assert_called_once_with(path="./db")


async def test_import_error_without_chromadb() -> None:
    with patch.dict("sys.modules", {"chromadb": None}):  # type: ignore[dict-item]
        block = VectorUpsertBlock()
        with pytest.raises(ImportError, match="pylego\\[chromadb\\]"):
            await block.run(VectorUpsertInput(ids=["x"], embeddings=[[0.1]]))
