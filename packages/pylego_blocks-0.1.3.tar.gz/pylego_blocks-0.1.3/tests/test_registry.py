"""BlockRegistry 테스트."""

from __future__ import annotations

import importlib.metadata
from typing import Any
from unittest.mock import patch

import pytest

from pylego.registry import BlockRegistry, default_registry, register
from pylego.core.block import Block
from pylego.core.stud import Stud


class _In(Stud):
    v: int = 0


class _Out(Stud):
    ok: bool = True


class _BlockA(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out()


class _BlockB(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out()


def test_register_and_get() -> None:
    reg = BlockRegistry()
    reg.register(_BlockA)
    assert reg.get("_BlockA") is _BlockA


def test_register_as_decorator() -> None:
    reg = BlockRegistry()

    @reg.register
    class _Decorated(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:  # pragma: no cover
            return _Out()

    assert isinstance(_Decorated, type)
    assert reg.get("_Decorated") is _Decorated


def test_get_unknown_raises() -> None:
    reg = BlockRegistry()
    with pytest.raises(KeyError):
        reg.get("NoSuchBlock")


def test_all_sorted() -> None:
    reg = BlockRegistry()
    reg.register(_BlockB)
    reg.register(_BlockA)
    names = [cls.__name__ for cls in reg.all()]
    assert names == sorted(names)


def test_duplicate_register_overwrites() -> None:
    reg = BlockRegistry()
    reg.register(_BlockA)
    reg.register(_BlockA)
    assert len(reg.all()) == 1


def test_load_entry_points_no_group() -> None:
    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[]):
        reg.load_entry_points(group="nonexistent.group")
    assert reg.all() == []


def test_load_entry_points_loads_block() -> None:
    class _FakeEP:
        def load(self) -> Any:
            return _BlockA

    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]):
        reg.load_entry_points()
    assert reg.get("_BlockA") is _BlockA


def test_default_registry_and_register_convenience() -> None:
    assert isinstance(default_registry, BlockRegistry)
    assert callable(register)


# ── discover() 테스트 ─────────────────────────────────────────────────────────


def test_discover_no_entry_points_returns_empty_list() -> None:
    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[]):
        result = reg.discover(group="nonexistent.group")
    assert result == []


def test_discover_loads_and_registers_block() -> None:
    class _FakeEP:
        name = "fake_ep"

        def load(self) -> Any:
            return _BlockA

    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]):
        newly = reg.discover()
    assert reg.get("_BlockA") is _BlockA
    assert _BlockA in newly


def test_discover_skips_non_block_entry_point(capsys: pytest.CaptureFixture[str]) -> None:
    class _FakeEP:
        name = "not_a_block"

        def load(self) -> Any:
            return object  # Block 서브클래스가 아님

    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]):
        result = reg.discover()
    assert result == []
    assert "not_a_block" in capsys.readouterr().err


def test_discover_skips_load_failure(capsys: pytest.CaptureFixture[str]) -> None:
    class _BrokenEP:
        name = "broken_ep"

        def load(self) -> Any:
            raise ImportError("module not found")

    reg = BlockRegistry()
    with patch.object(importlib.metadata, "entry_points", return_value=[_BrokenEP()]):
        result = reg.discover()
    assert result == []
    assert "broken_ep" in capsys.readouterr().err


def test_discover_returns_only_newly_added() -> None:
    class _FakeEP:
        name = "fake_ep_a"

        def load(self) -> Any:
            return _BlockA

    reg = BlockRegistry()
    reg.register(_BlockA)  # 미리 등록

    with patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]):
        newly = reg.discover()
    # 이미 등록된 블록은 newly 에 포함되지 않는다
    assert newly == []
    # 레지스트리에는 여전히 있다
    assert reg.get("_BlockA") is _BlockA
