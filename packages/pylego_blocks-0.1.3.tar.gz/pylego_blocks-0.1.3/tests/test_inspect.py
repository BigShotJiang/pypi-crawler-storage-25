"""pylego inspect CLI tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pylego.inspect.cli import inspect_list, inspect_show
from pylego.inspect.discovery import iter_blocks


def test_list_defaults_include_registered_blocks(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert inspect_list() == 0
    output = capsys.readouterr().out
    assert "pylego.blocks.ai.acp.AcpPromptBlock" in output
    assert "pylego.blocks.git.merge.MergeToMainBlock" in output


def test_list_json_format(capsys: pytest.CaptureFixture[str]) -> None:
    assert inspect_list(output_format="json") == 0
    payload = json.loads(capsys.readouterr().out)
    names = {item["name"] for item in payload["blocks"]}
    assert "AcpPromptBlock" in names
    assert "MergeToMainBlock" in names


def test_show_prints_contract_table(capsys: pytest.CaptureFixture[str]) -> None:
    assert inspect_show("MergeToMainBlock", root="pylego.blocks.git") == 0
    output = capsys.readouterr().out
    assert "pylego.blocks.git.merge.MergeToMainBlock" in output
    assert "MergeRequest" in output
    assert "Field | Type | Required" in output
    assert "base_branch | str | yes" in output


def test_discovery_continues_after_import_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    package = tmp_path / "sampleblocks"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "good.py").write_text(
        """
from pylego.core import Block, Stud


class SampleInput(Stud):
    value: str


class SampleOutput(Stud):
    value: str


class SampleBlock(Block[SampleInput, SampleOutput]):
    input_model = SampleInput
    output_model = SampleOutput

    async def run(self, inp: SampleInput) -> SampleOutput:
        return SampleOutput(value=inp.value)
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (package / "broken.py").write_text("raise RuntimeError('boom')\n", encoding="utf-8")

    monkeypatch.syspath_prepend(str(tmp_path))
    blocks = list(iter_blocks("sampleblocks"))

    output = capsys.readouterr()
    assert "warning: failed to import sampleblocks.broken" in output.err
    assert any(block.__name__ == "SampleBlock" for block in blocks)
