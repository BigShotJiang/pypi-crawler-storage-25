"""M112 — Post-thaw Observation Period + Smart Canary 테스트."""

from __future__ import annotations

import importlib
import sys
import time
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego import Assembly, Block, Stud
from pylego.scheduler import GlobalSchedulerPolicy, SchedulerPolicy, ThawPolicy


# ── 더미 블록 ──────────────────────────────────────────────────────────────────


class _In(Stud):
    x: int


class _Out(Stud):
    y: int


class _Ok(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


def _pipeline() -> Assembly[_In, _Out]:
    return Assembly([_Ok()])


# ── apscheduler mock 헬퍼 ─────────────────────────────────────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


# ── SchedulerPolicy.canary_priority 기본값 ───────────────────────────────────


def test_canary_priority_default() -> None:
    p = SchedulerPolicy()
    assert p.canary_priority == 0


def test_canary_priority_custom() -> None:
    p = SchedulerPolicy(canary_priority=5)
    assert p.canary_priority == 5


# ── GlobalSchedulerPolicy 확장 필드 ─────────────────────────────────────────


def test_global_policy_post_thaw_defaults() -> None:
    gp = GlobalSchedulerPolicy()
    assert gp.post_thaw_observation_sec == 0.0
    assert gp.post_thaw_max_failure_rate == 0.3
    assert gp.on_recovering is None


def test_global_policy_post_thaw_custom() -> None:
    cb: list[str] = []
    gp = GlobalSchedulerPolicy(
        post_thaw_observation_sec=60.0,
        post_thaw_max_failure_rate=0.1,
        on_recovering=cb.append,
    )
    assert gp.post_thaw_observation_sec == 60.0
    assert gp.post_thaw_max_failure_rate == 0.1


# ── recovering 상태 진입 ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_recovering_state_entered_after_thaw() -> None:
    """post_thaw_observation_sec > 0 이면 threshold 달성 시 recovering 상태로 진입한다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._frozen is False
        assert sched._recovering is True


@pytest.mark.asyncio
async def test_recovering_state_not_entered_when_obs_zero() -> None:
    """post_thaw_observation_sec == 0 이면 즉시 완전 해제."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        calls: list[str] = []
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=0.0,
            on_thaw=calls.append,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._frozen is False
        assert sched._recovering is False
        assert len(calls) == 1


@pytest.mark.asyncio
async def test_on_recovering_callback_called() -> None:
    """recovering 진입 시 on_recovering 콜백이 호출된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        cb: list[str] = []
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            on_recovering=cb.append,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert len(cb) == 1
        assert "recovering" in cb[0]


# ── recovering → active 전환 ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_recovering_to_active_after_observation() -> None:
    """관찰 기간 경과 + 실패율 OK → recovering 해제."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        thaw_calls: list[str] = []
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=0.001,  # 1ms — 즉시 경과
            on_thaw=thaw_calls.append,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        # recovering 상태에서 성공 실행 시뮬레이션
        sched._recovery_runs = 1
        sched._recovery_failures = 0
        sched._recovery_start_at = time.monotonic() - 1.0  # 이미 경과

        # _run 내부 로직을 직접 호출하여 관찰 기간 완료 확인
        if sched._recovering:
            failure_rate = sched._recovery_failures / sched._recovery_runs
            if (
                time.monotonic() - sched._recovery_start_at
                >= gp.post_thaw_observation_sec
            ):
                if failure_rate <= gp.post_thaw_max_failure_rate:
                    sched._recovering = False
                    if gp.on_thaw is not None:
                        gp.on_thaw("복구 관찰 기간 완료 — 완전 복귀")

        assert sched._recovering is False
        assert len(thaw_calls) == 1
        assert "완전 복귀" in thaw_calls[0]


# ── recovering → frozen 재진입 ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_recovering_to_frozen_on_high_failure() -> None:
    """recovering 중 실패율 초과 시 자동 재동결."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            post_thaw_max_failure_rate=0.2,  # 20% 임계
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        # 실패율 50% 시뮬레이션 (임계 20% 초과)
        sched._recovery_runs = 2
        sched._recovery_failures = 1
        failure_rate = sched._recovery_failures / sched._recovery_runs  # 0.5

        if failure_rate > gp.post_thaw_max_failure_rate:
            sched._recovering = False
            sched.freeze(f"복구 관찰 기간 중 실패율 {failure_rate:.1%} 초과 — 재동결")

        assert sched._recovering is False
        assert sched._frozen is True


# ── unfreeze() 시 recovering 초기화 ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_unfreeze_clears_recovering() -> None:
    """unfreeze() 호출 시 recovering 상태도 초기화된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        sched.unfreeze()
        assert sched._frozen is False
        assert sched._recovering is False


# ── global_status() recovering 필드 ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_global_status_includes_recovering() -> None:
    """global_status() 에 recovering 필드가 포함된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        sched = sched_mod.Scheduler()
        status = sched.global_status()
        assert "recovering" in status
        assert status["recovering"] is False


# ── Smart Canary 선택 ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_smart_canary_selects_lowest_priority() -> None:
    """canary_priority 가 낮은 잡이 카나리로 선택된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        ran: list[str] = []

        class _TrackA(Block[_In, _Out]):
            input_model = _In
            output_model = _Out

            async def run(self, inp: _In) -> _Out:
                ran.append("A")
                return _Out(y=inp.x)

        class _TrackB(Block[_In, _Out]):
            input_model = _In
            output_model = _Out

            async def run(self, inp: _In) -> _Out:
                ran.append("B")
                return _Out(y=inp.x)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp)
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)

        # A는 priority=10 (낮은 우선순위), B는 priority=1 (높은 우선순위 → 카나리 선택)
        policy_a = sched_mod.SchedulerPolicy(canary_priority=10)
        policy_b = sched_mod.SchedulerPolicy(canary_priority=1)
        sched.add(Assembly([_TrackA()]), input=_In(x=1), interval_seconds=60.0, job_id="A", policy=policy_a)
        sched.add(Assembly([_TrackB()]), input=_In(x=1), interval_seconds=60.0, job_id="B", policy=policy_b)
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert ran == ["B"]  # B(priority=1)가 카나리로 선택됨
