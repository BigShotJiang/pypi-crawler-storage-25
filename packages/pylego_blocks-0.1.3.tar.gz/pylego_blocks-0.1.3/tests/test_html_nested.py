"""HTML 리포트 v2 — caused_by 점선 화살표 + sub_health details 마크업 (M86)."""

from __future__ import annotations

from unittest.mock import MagicMock

import pylego.core.graph as _g
from pylego.core.events import BlockCompletedEvent, BlockFailedEvent, BlockStartedEvent
from pylego.core.graph import build_health_summary, to_html
from pylego.core.events import CollectingEventBus


def _completed(name: str) -> BlockCompletedEvent:
    return BlockCompletedEvent(block_name=name, output=None, elapsed_sec=0.1, timestamp=0.0)


def _failed(name: str, cause: BlockFailedEvent | None = None) -> BlockFailedEvent:
    return BlockFailedEvent(
        block_name=name,
        error=RuntimeError("err"),
        elapsed_sec=0.1,
        timestamp=0.0,
        caused_by=cause,
    )


def _started(name: str) -> BlockStartedEvent:
    return BlockStartedEvent(block_name=name, input=None, timestamp=0.0)


def _make_block() -> MagicMock:
    block = MagicMock()
    block.name = "TestPipeline"
    return block


def _patch_mermaid(monkeypatch: object) -> None:
    import pytest
    if not isinstance(monkeypatch, pytest.MonkeyPatch):
        return
    monkeypatch.setattr(_g, "to_mermaid", lambda *a, **kw: "graph LR\n  A --> B")


# ── caused_by 점선 화살표 ─────────────────────────────────────────────────────

def test_html_contains_stroke_dasharray_for_caused_by(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    root_failure = _failed("RootBlock")
    derived_failure = _failed("WrapperBlock", cause=root_failure)

    events = [
        _started("RootBlock"), root_failure,
        _started("WrapperBlock"), derived_failure,
    ]
    bus = CollectingEventBus()
    for e in events:
        bus.emit(e)
    health = build_health_summary(events, bus=bus)
    html = to_html(_make_block(), health=health)

    assert "stroke-dasharray" in html
    assert "caused-arrow" in html
    assert "RootBlock" in html


def test_html_no_dasharray_without_caused_by(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    events = [_started("BlockA"), _failed("BlockA")]
    health = build_health_summary(events)
    html = to_html(_make_block(), health=health)
    assert "stroke-dasharray" not in html


def test_html_caused_by_shows_cause_block_name(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    root = _failed("CauseBlock")
    derived = _failed("EffectBlock", cause=root)
    events = [_started("CauseBlock"), root, _started("EffectBlock"), derived]
    health = build_health_summary(events)
    html = to_html(_make_block(), health=health)

    assert "CauseBlock" in html
    assert "EffectBlock" in html


# ── sub_health details 태그 ───────────────────────────────────────────────────

def test_html_contains_details_for_sub_health(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    events = [
        _started("Top"), _completed("Top"),
        _started("sub/Child"), _completed("sub/Child"),
    ]
    health = build_health_summary(events)
    html = to_html(_make_block(), health=health)

    assert "<details" in html
    assert 'class="sub-health"' in html
    assert "sub" in html


def test_html_sub_health_badge_shows_status(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    events = [
        _started("Top"), _completed("Top"),
        _started("fallback/Child"), _failed("fallback/Child"),
    ]
    health = build_health_summary(events)
    html = to_html(_make_block(), health=health)

    assert "health-critical" in html or "health-degraded" in html
    assert "fallback" in html


def test_html_no_details_without_sub_health(monkeypatch: object) -> None:
    import pytest
    assert isinstance(monkeypatch, pytest.MonkeyPatch)
    _patch_mermaid(monkeypatch)

    events = [_started("BlockA"), _completed("BlockA")]
    health = build_health_summary(events)
    html = to_html(_make_block(), health=health)

    assert 'class="sub-health"' not in html
