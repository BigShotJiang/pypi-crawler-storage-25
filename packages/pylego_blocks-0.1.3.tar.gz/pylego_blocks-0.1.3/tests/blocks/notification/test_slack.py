"""SlackBlock 단위 테스트 — httpx 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego import Assembly, TapBlock
from pylego.blocks.notification.slack import SlackBlock, SlackInput, SlackResult


# ---------------------------------------------------------------------------
# httpx stub
# ---------------------------------------------------------------------------


class _FakeHTTPStatusError(Exception):
    """httpx.HTTPStatusError 대역 예외."""

    def __init__(
        self,
        message: str,
        *,
        request: object,
        response: object,
    ) -> None:
        super().__init__(message)


def _make_httpx_stub(
    response_body: str | dict[str, object] = "ok",
    status_code: int = 200,
) -> types.ModuleType:
    mod = types.ModuleType("httpx")
    mod.HTTPStatusError = _FakeHTTPStatusError  # type: ignore[attr-defined]

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = response_body
    if status_code >= 400:
        resp.raise_for_status.side_effect = _FakeHTTPStatusError(
            f"HTTP {status_code}",
            request=MagicMock(),
            response=resp,
        )
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    async_client_cls = MagicMock(return_value=client)
    mod.AsyncClient = async_client_cls  # type: ignore[attr-defined]

    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    real_httpx = importlib.import_module("httpx")
    saved_slack = sys.modules.get("pylego.blocks.notification.slack")
    saved_http = sys.modules.get("pylego.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_slack is not None:
        sys.modules["pylego.blocks.notification.slack"] = saved_slack
    else:
        sys.modules.pop("pylego.blocks.notification.slack", None)
    if saved_http is not None:
        sys.modules["pylego.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego.blocks.http", None)


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_slack_missing_webhook_url() -> None:
    import os

    os.environ.pop("PYLEGO_SLACK_WEBHOOK_URL", None)
    with pytest.raises(ValueError, match="webhook_url"):
        SlackBlock()


def test_slack_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_SLACK_WEBHOOK_URL", "https://hooks.slack.com/env")
    block = SlackBlock()
    assert block._webhook_url == "https://hooks.slack.com/env"


def test_webhook_url_from_arg() -> None:
    block = SlackBlock(webhook_url="https://hooks.slack.com/arg")
    assert block._webhook_url == "https://hooks.slack.com/arg"


def test_arg_takes_precedence_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_SLACK_WEBHOOK_URL", "https://hooks.slack.com/env")
    block = SlackBlock(webhook_url="https://hooks.slack.com/arg")
    assert block._webhook_url == "https://hooks.slack.com/arg"


# ---------------------------------------------------------------------------
# 정상 전송
# ---------------------------------------------------------------------------


async def test_slack_send_success() -> None:
    _make_httpx_stub(response_body="ok")
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    result = await block.run(SlackInput(text="파이프라인 완료"))
    assert isinstance(result, SlackResult)
    assert result.ok is True


async def test_slack_send_with_channel() -> None:
    stub = _make_httpx_stub(response_body="ok")
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    await block.run(
        SlackInput(
            text="배포 완료",
            channel="#deploy",
            username="pylego-bot",
            icon_emoji=":rocket:",
        )
    )

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    assert call_args[0][0] == "POST"
    body = call_args[1]["json"]
    assert body["text"] == "배포 완료"
    assert body["channel"] == "#deploy"
    assert body["username"] == "pylego-bot"
    assert body["icon_emoji"] == ":rocket:"


async def test_none_fields_excluded_from_payload() -> None:
    stub = _make_httpx_stub(response_body="ok")
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    await block.run(SlackInput(text="안녕"))

    client_instance = stub.AsyncClient.return_value
    body = client_instance.request.call_args[1]["json"]
    assert "channel" not in body
    assert "username" not in body
    assert "icon_emoji" not in body


# ---------------------------------------------------------------------------
# 오류 처리
# ---------------------------------------------------------------------------


async def test_slack_http_error() -> None:
    _make_httpx_stub(status_code=400)
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    with pytest.raises(Exception):
        await block.run(SlackInput(text="hi"))


async def test_slack_json_error_response() -> None:
    _make_httpx_stub(response_body={"error": "invalid_payload"})
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    result = await block.run(SlackInput(text="hi"))
    # dict 응답에 ok 키가 없으면 ok=True 로 기본 처리
    assert isinstance(result, SlackResult)
    assert result.ok is True


async def test_slack_json_ok_false_response() -> None:
    _make_httpx_stub(response_body={"ok": False, "error": "no_service"})
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/test")
    result = await block.run(SlackInput(text="hi"))
    assert result.ok is False


# ---------------------------------------------------------------------------
# TapBlock 통합
# ---------------------------------------------------------------------------


async def test_slack_tapblock_integration() -> None:
    from pylego import Stud
    from pylego.core.block import Block

    class Msg(Stud):
        content: str

    class SourceBlock(Block[Msg, SlackInput]):
        input_model = Msg
        output_model = SlackInput

        async def run(self, inp: Msg) -> SlackInput:
            return SlackInput(text=inp.content)

    _make_httpx_stub(response_body="ok")

    pipeline: Assembly[Msg, SlackInput] = Assembly([
        SourceBlock(),
        TapBlock(SlackBlock(webhook_url="https://hooks.slack.com/services/test")),
    ])
    result = await pipeline.run(Msg(content="알림"))
    # TapBlock 은 원본 SlackInput 을 그대로 통과시킨다
    assert isinstance(result, SlackInput)
    assert result.text == "알림"
