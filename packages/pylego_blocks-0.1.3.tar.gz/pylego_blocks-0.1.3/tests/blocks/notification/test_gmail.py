"""GmailBlock 단위 테스트 — aiosmtplib 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego import Assembly, TapBlock
from pylego.blocks.notification.gmail import GmailBlock, GmailInput, GmailResult


# ---------------------------------------------------------------------------
# aiosmtplib stub
# ---------------------------------------------------------------------------

def _make_smtp_stub(errors: dict[str, object] | None = None) -> types.ModuleType:
    mod = types.ModuleType("aiosmtplib")
    send_mock = AsyncMock(return_value=(errors or {}, "OK"))
    mod.send = send_mock  # type: ignore[attr-defined]
    sys.modules["aiosmtplib"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_smtp() -> None:
    yield
    sys.modules.pop("aiosmtplib", None)
    sys.modules.pop("pylego.blocks.notification.gmail", None)


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_credentials_required_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PYLEGO_GMAIL_USER", raising=False)
    monkeypatch.delenv("PYLEGO_GMAIL_PASSWORD", raising=False)
    with pytest.raises(ValueError, match="smtp_user"):
        GmailBlock()


def test_missing_password_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_GMAIL_USER", "u@gmail.com")
    monkeypatch.delenv("PYLEGO_GMAIL_PASSWORD", raising=False)
    with pytest.raises(ValueError):
        GmailBlock()


def test_credentials_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_GMAIL_USER", "u@gmail.com")
    monkeypatch.setenv("PYLEGO_GMAIL_PASSWORD", "pw")
    block = GmailBlock()
    assert block._user == "u@gmail.com"
    assert block._password == "pw"


def test_credentials_from_args() -> None:
    block = GmailBlock(smtp_user="a@gmail.com", smtp_password="secret")
    assert block._user == "a@gmail.com"
    assert block._password == "secret"


def test_args_take_precedence_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_GMAIL_USER", "env@gmail.com")
    monkeypatch.setenv("PYLEGO_GMAIL_PASSWORD", "envpw")
    block = GmailBlock(smtp_user="arg@gmail.com", smtp_password="argpw")
    assert block._user == "arg@gmail.com"


# ---------------------------------------------------------------------------
# 정상 전송
# ---------------------------------------------------------------------------


async def test_run_returns_gmail_result() -> None:
    _make_smtp_stub()
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")
    result = await block.run(GmailInput(to="r@example.com", subject="제목", body="내용"))
    assert isinstance(result, GmailResult)
    assert result.accepted == ["r@example.com"]


async def test_run_calls_send_with_correct_params() -> None:
    stub = _make_smtp_stub()
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="mypw")
    await block.run(GmailInput(to="r@example.com", subject="S", body="B"))

    call_kwargs = stub.send.call_args[1]
    assert call_kwargs["hostname"] == "smtp.gmail.com"
    assert call_kwargs["port"] == 587
    assert call_kwargs["username"] == "s@gmail.com"
    assert call_kwargs["password"] == "mypw"
    assert call_kwargs["start_tls"] is True


async def test_plain_text_message() -> None:
    stub = _make_smtp_stub()
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")
    await block.run(GmailInput(to="r@example.com", subject="제목", body="본문"))

    msg = stub.send.call_args[0][0]
    assert isinstance(msg, MIMEText)
    assert msg["Subject"] == "제목"
    assert msg["To"] == "r@example.com"


async def test_html_message_uses_multipart() -> None:
    stub = _make_smtp_stub()
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")
    await block.run(GmailInput(to="r@example.com", subject="S", body="<b>HTML</b>", html=True))

    msg = stub.send.call_args[0][0]
    assert isinstance(msg, MIMEMultipart)


# ---------------------------------------------------------------------------
# 오류 처리
# ---------------------------------------------------------------------------


async def test_smtp_errors_raises_runtime_error() -> None:
    _make_smtp_stub(errors={"r@example.com": (550, "User unknown")})
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")
    with pytest.raises(RuntimeError, match="Gmail 전송 오류"):
        await block.run(GmailInput(to="r@example.com", subject="S", body="B"))


async def test_import_error_without_aiosmtplib() -> None:
    sys.modules["aiosmtplib"] = None  # type: ignore[assignment]
    block = GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")
    with pytest.raises(ImportError, match="aiosmtplib"):
        await block.run(GmailInput(to="r@example.com", subject="S", body="B"))


# ---------------------------------------------------------------------------
# TapBlock 통합
# ---------------------------------------------------------------------------


async def test_tapblock_integration() -> None:
    from pylego import Stud
    from pylego.core.block import Block

    class Payload(Stud):
        content: str

    class SourceBlock(Block[Payload, GmailInput]):
        input_model = Payload
        output_model = GmailInput

        async def run(self, inp: Payload) -> GmailInput:
            return GmailInput(to="r@example.com", subject="알림", body=inp.content)

    _make_smtp_stub()

    pipeline = Assembly([
        SourceBlock(),
        TapBlock(GmailBlock(smtp_user="s@gmail.com", smtp_password="pw")),
    ])
    result = await pipeline.run(Payload(content="파이프라인 완료"))
    # TapBlock 은 원본 GmailInput 을 그대로 통과시킨다
    assert isinstance(result, GmailInput)
    assert result.body == "파이프라인 완료"
