"""ExcelReadBlock / ExcelWriteBlock 단위 테스트."""

from __future__ import annotations

import asyncio
import importlib.util
from typing import Any

import pytest

from pylego.blocks.file.excel import (
    ExcelReadBlock,
    ExcelReadInput,
    ExcelWriteBlock,
    ExcelWriteInput,
)

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("openpyxl") is None,
    reason="openpyxl not installed",
)


def test_write_and_read_roundtrip(tmp_path: Any) -> None:
    """쓰기 후 읽기 결과가 원본과 일치해야 한다."""
    path = str(tmp_path / "test.xlsx")
    rows = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]

    write_result = asyncio.run(
        ExcelWriteBlock().run(ExcelWriteInput(path=path, rows=rows))
    )
    assert write_result.row_count == 2
    assert write_result.path == path

    read_result = asyncio.run(
        ExcelReadBlock().run(ExcelReadInput(path=path, sheet=0))
    )
    assert read_result.row_count == 2
    assert read_result.rows[0]["name"] == "Alice"
    assert read_result.rows[1]["name"] == "Bob"


def test_write_empty_rows(tmp_path: Any) -> None:
    """빈 rows 쓰기는 오류 없이 완료되어야 한다."""
    path = str(tmp_path / "empty.xlsx")
    result = asyncio.run(
        ExcelWriteBlock().run(ExcelWriteInput(path=path, rows=[]))
    )
    assert result.row_count == 0


def test_read_sheet_by_name(tmp_path: Any) -> None:
    """시트 이름으로 특정 시트를 읽을 수 있어야 한다."""
    path = str(tmp_path / "named.xlsx")
    rows = [{"x": 1}]
    asyncio.run(
        ExcelWriteBlock().run(
            ExcelWriteInput(path=path, rows=rows, sheet_name="Data")
        )
    )
    result = asyncio.run(
        ExcelReadBlock().run(ExcelReadInput(path=path, sheet="Data"))
    )
    assert result.sheet_name == "Data"
    assert result.rows[0]["x"] == 1


def test_read_nonexistent_file() -> None:
    """존재하지 않는 파일 읽기 시 예외가 전파되어야 한다."""
    with pytest.raises(Exception):
        asyncio.run(
            ExcelReadBlock().run(ExcelReadInput(path="/no/such/file.xlsx"))
        )


def test_write_custom_sheet_name(tmp_path: Any) -> None:
    """사용자 정의 시트 이름이 결과에 반영되어야 한다."""
    path = str(tmp_path / "custom.xlsx")
    asyncio.run(
        ExcelWriteBlock().run(
            ExcelWriteInput(path=path, rows=[{"v": 42}], sheet_name="MySheet")
        )
    )
    result = asyncio.run(
        ExcelReadBlock().run(ExcelReadInput(path=path, sheet="MySheet"))
    )
    assert result.sheet_name == "MySheet"
    assert result.rows[0]["v"] == 42
