"""PdfReadBlock / PdfWriteBlock 단위 테스트."""

from __future__ import annotations

import asyncio
import importlib.util
from typing import Any

import pytest

from pylego.blocks.file.pdf import (
    PdfReadBlock,
    PdfReadInput,
    PdfWriteBlock,
    PdfWriteInput,
)

_pypdf_installed = importlib.util.find_spec("pypdf") is not None
_reportlab_installed = importlib.util.find_spec("reportlab") is not None
_all_installed = _pypdf_installed and _reportlab_installed

pytestmark = pytest.mark.skipif(
    not _all_installed,
    reason="pypdf or reportlab not installed",
)


def test_write_and_read_roundtrip(tmp_path: Any) -> None:
    """쓰기 후 읽기 시 페이지 수가 일치해야 한다."""
    path = str(tmp_path / "test.pdf")
    content = ["첫 번째 페이지 내용", "두 번째 페이지 내용"]

    write_result = asyncio.run(
        PdfWriteBlock().run(PdfWriteInput(path=path, content=content, title="Test"))
    )
    assert write_result.page_count == 2
    assert write_result.path == path

    read_result = asyncio.run(PdfReadBlock().run(PdfReadInput(path=path)))
    assert read_result.page_count == 2
    assert len(read_result.page_texts) == 2


def test_write_single_page(tmp_path: Any) -> None:
    """단일 페이지 PDF가 올바르게 생성되어야 한다."""
    path = str(tmp_path / "single.pdf")
    result = asyncio.run(
        PdfWriteBlock().run(PdfWriteInput(path=path, content=["Hello"]))
    )
    assert result.page_count == 1


def test_read_specific_pages(tmp_path: Any) -> None:
    """특정 페이지만 읽을 수 있어야 한다."""
    path = str(tmp_path / "pages.pdf")
    asyncio.run(
        PdfWriteBlock().run(
            PdfWriteInput(path=path, content=["Page 1", "Page 2", "Page 3"])
        )
    )
    result = asyncio.run(
        PdfReadBlock().run(PdfReadInput(path=path, pages=[0, 2]))
    )
    assert len(result.page_texts) == 2
    assert result.page_count == 3  # 파일 전체 페이지 수


def test_read_returns_combined_text(tmp_path: Any) -> None:
    """`text` 필드는 모든 페이지 텍스트를 합친 결과여야 한다."""
    path = str(tmp_path / "combined.pdf")
    asyncio.run(
        PdfWriteBlock().run(PdfWriteInput(path=path, content=["Alpha", "Beta"]))
    )
    result = asyncio.run(PdfReadBlock().run(PdfReadInput(path=path)))
    assert isinstance(result.text, str)
    assert len(result.text) >= 0  # 텍스트 추출 성공 (내용은 렌더링 의존)


def test_read_nonexistent_file() -> None:
    """존재하지 않는 파일 읽기 시 예외가 전파되어야 한다."""
    with pytest.raises(Exception):
        asyncio.run(PdfReadBlock().run(PdfReadInput(path="/no/such/file.pdf")))
