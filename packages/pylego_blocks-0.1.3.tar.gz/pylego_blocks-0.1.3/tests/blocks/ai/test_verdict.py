"""VerdictParseBlock — pipeline.sh §6 엄격 매칭 동작 검증."""

from __future__ import annotations

import pytest

from pylego.blocks.ai import Verdict, VerdictParseBlock, VerdictParseRequest


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("설명...\nVERDICT: PASS", "PASS"),
        ("상세 실패 사유\nVERDICT: FAIL", "FAIL"),
        # 마지막 줄이 정확 포맷이 아니면 UNKNOWN — 기존 정규식 오판정(PASS) 버그 방지
        ("VERDICT: FAIL — this is not PASS", "UNKNOWN"),
        ("여러 줄\n이 사유는 PASS 가 아님\nVERDICT: FAIL", "FAIL"),
        ("  VERDICT: PASS  ", "PASS"),  # 좌우 공백은 strip 으로 제거
        ("VERDICT: PASS\n\n", "PASS"),  # 후행 공백 줄
        ("some noise only", "UNKNOWN"),
        ("VERDICT: MAYBE", "UNKNOWN"),
        ("", "UNKNOWN"),
    ],
)
async def test_verdict_matching(text: str, expected: str) -> None:
    block = VerdictParseBlock()
    result = await block.run(VerdictParseRequest(text=text))
    assert isinstance(result, Verdict)
    assert result.result == expected
