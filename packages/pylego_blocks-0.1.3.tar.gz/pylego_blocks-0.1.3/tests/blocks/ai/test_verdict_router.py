"""VerdictRouter + VerdictParseBlock(strict=False) 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego.blocks.ai import (
    UnknownPolicy,
    UnknownVerdictError,
    Verdict,
    VerdictParseBlock,
    VerdictParseRequest,
    VerdictRouter,
)
from pylego.core.block import Block
from pylego.core.stud import Stud


# ── VerdictParseBlock strict=False ──────────────────────────────────────────

@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("verdict: pass", "PASS"),
        ("VERDICT: PASS", "PASS"),
        ("verdict: FAIL", "FAIL"),
        ("Verdict: Fail", "FAIL"),
        ("verdict: maybe", "UNKNOWN"),
        ("", "UNKNOWN"),
    ],
)
async def test_verdict_parse_block_non_strict(text: str, expected: str) -> None:
    block = VerdictParseBlock(strict=False)
    result = await block.run(VerdictParseRequest(text=text))
    assert result.result == expected


async def test_verdict_parse_block_strict_rejects_lowercase() -> None:
    block = VerdictParseBlock(strict=True)
    result = await block.run(VerdictParseRequest(text="verdict: pass"))
    assert result.result == "UNKNOWN"


# ── VerdictRouter — 기본 동작 ────────────────────────────────────────────────

async def test_router_returns_pass() -> None:
    router = VerdictRouter()
    result = await router.run(VerdictParseRequest(text="VERDICT: PASS"))
    assert result == Verdict(result="PASS")


async def test_router_returns_fail() -> None:
    router = VerdictRouter()
    result = await router.run(VerdictParseRequest(text="VERDICT: FAIL"))
    assert result == Verdict(result="FAIL")


async def test_router_returns_unknown_by_default() -> None:
    router = VerdictRouter()
    result = await router.run(VerdictParseRequest(text="no verdict here"))
    assert result == Verdict(result="UNKNOWN")


# ── UnknownPolicy: raise_error ───────────────────────────────────────────────

async def test_router_raises_on_unknown() -> None:
    router = VerdictRouter(unknown_policy=UnknownPolicy(raise_error=True))
    with pytest.raises(UnknownVerdictError):
        await router.run(VerdictParseRequest(text="no verdict here"))


async def test_router_does_not_raise_on_pass() -> None:
    router = VerdictRouter(unknown_policy=UnknownPolicy(raise_error=True))
    result = await router.run(VerdictParseRequest(text="VERDICT: PASS"))
    assert result.result == "PASS"


# ── UnknownPolicy: fallback ──────────────────────────────────────────────────

class AlwaysPassBlock(Block[VerdictParseRequest, Verdict]):
    input_model = VerdictParseRequest
    output_model = Verdict

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        return Verdict(result="PASS")


async def test_router_uses_fallback_on_unknown() -> None:
    router = VerdictRouter(unknown_policy=UnknownPolicy(fallback=AlwaysPassBlock()))
    result = await router.run(VerdictParseRequest(text="no verdict"))
    assert result == Verdict(result="PASS")


async def test_router_fallback_not_called_on_pass() -> None:
    called: list[bool] = []

    class TrackBlock(Block[VerdictParseRequest, Verdict]):
        input_model = VerdictParseRequest
        output_model = Verdict

        async def run(self, inp: VerdictParseRequest) -> Verdict:
            called.append(True)
            return Verdict(result="FAIL")

    router = VerdictRouter(unknown_policy=UnknownPolicy(fallback=TrackBlock()))
    await router.run(VerdictParseRequest(text="VERDICT: PASS"))
    assert called == []


# ── UnknownPolicy: escalate_to ───────────────────────────────────────────────

class SideEffectBlock(Block[VerdictParseRequest, Stud]):
    input_model = VerdictParseRequest
    output_model = Verdict

    def __init__(self) -> None:
        self.calls: list[str] = []

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        self.calls.append(inp.text)
        return Verdict(result="UNKNOWN")


async def test_router_escalates_and_returns_unknown() -> None:
    side = SideEffectBlock()
    router = VerdictRouter(unknown_policy=UnknownPolicy(escalate_to=side))
    result = await router.run(VerdictParseRequest(text="no verdict"))
    assert result.result == "UNKNOWN"
    assert side.calls == ["no verdict"]


async def test_router_escalate_not_called_on_fail() -> None:
    side = SideEffectBlock()
    router = VerdictRouter(unknown_policy=UnknownPolicy(escalate_to=side))
    await router.run(VerdictParseRequest(text="VERDICT: FAIL"))
    assert side.calls == []


# ── custom verdict_block ─────────────────────────────────────────────────────

async def test_router_uses_custom_verdict_block() -> None:
    non_strict = VerdictParseBlock(strict=False)
    router = VerdictRouter(verdict_block=non_strict)
    result = await router.run(VerdictParseRequest(text="verdict: pass"))
    assert result.result == "PASS"


# ── 이름 ────────────────────────────────────────────────────────────────────

def test_router_name_contains_inner_name() -> None:
    router = VerdictRouter()
    assert "VerdictParseBlock" in router.name


# ── IO models ───────────────────────────────────────────────────────────────

def test_router_io_models() -> None:
    router = VerdictRouter()
    assert router.input_model is VerdictParseRequest
    assert router.output_model is Verdict


# ── raise_error error message contains input text ───────────────────────────

async def test_raise_error_message_contains_input_text() -> None:
    router = VerdictRouter(unknown_policy=UnknownPolicy(raise_error=True))
    text = "ambiguous response from AI"
    with pytest.raises(UnknownVerdictError, match="UNKNOWN"):
        await router.run(VerdictParseRequest(text=text))
