"""TransactionalQueryBlock 단위 테스트 — mock Pool 기반 (M63)."""

from __future__ import annotations

import asyncio
import importlib.util
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego.blocks.db.base import QueryInput
from pylego.blocks.db.transactional import (
    TransactionalInput,
    TransactionalQueryBlock,
)

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("aiomysql") is None,
    reason="aiomysql not installed",
)


def _make_cursor_mock(rows: list[dict]) -> AsyncMock:
    cur = AsyncMock()
    cur.execute = AsyncMock()
    cur.fetchall = AsyncMock(return_value=rows)
    cur.__aenter__ = AsyncMock(return_value=cur)
    cur.__aexit__ = AsyncMock(return_value=None)
    return cur


def _make_conn_mock(cursor: AsyncMock) -> MagicMock:
    conn = MagicMock()
    conn.cursor = MagicMock(return_value=cursor)
    conn.begin = AsyncMock()
    conn.commit = AsyncMock()
    conn.rollback = AsyncMock()
    return conn


def _make_pool_mock(conn: MagicMock) -> MagicMock:
    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=conn)
    cm.__aexit__ = AsyncMock(return_value=None)

    pool = MagicMock()
    pool.acquire = MagicMock(return_value=cm)
    pool.close = MagicMock()
    pool.wait_closed = AsyncMock()
    return pool


def test_all_queries_committed() -> None:
    """모든 쿼리 성공 시 committed=True 반환."""
    block = TransactionalQueryBlock(host="h", user="u", password="p", db="d")
    cursor = _make_cursor_mock([{"id": 1}])
    conn = _make_conn_mock(cursor)
    pool = _make_pool_mock(conn)

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=pool)):
        result = asyncio.run(
            block.run(TransactionalInput(queries=[
                QueryInput(query="SELECT id FROM t"),
                QueryInput(query="UPDATE t SET x=1"),
            ]))
        )

    assert result.committed is True
    assert len(result.results) == 2
    conn.commit.assert_called_once()
    conn.rollback.assert_not_called()


def test_rollback_on_execute_error() -> None:
    """쿼리 실행 중 예외 발생 시 ROLLBACK 후 예외가 전파된다."""
    block = TransactionalQueryBlock(host="h", user="u", password="p", db="d")
    cursor = _make_cursor_mock([])
    cursor.execute = AsyncMock(side_effect=RuntimeError("DB error"))
    conn = _make_conn_mock(cursor)
    pool = _make_pool_mock(conn)

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=pool)):
        with pytest.raises(RuntimeError, match="DB error"):
            asyncio.run(
                block.run(TransactionalInput(queries=[
                    QueryInput(query="INSERT INTO t VALUES (%s)", params=[1]),
                ]))
            )

    conn.rollback.assert_called_once()
    conn.commit.assert_not_called()


def test_results_per_query() -> None:
    """각 쿼리마다 결과가 개별 QueryResult로 수집된다."""
    block = TransactionalQueryBlock(host="h", user="u", password="p", db="d")
    cursor = _make_cursor_mock([{"n": 42}])
    conn = _make_conn_mock(cursor)
    pool = _make_pool_mock(conn)

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=pool)):
        result = asyncio.run(
            block.run(TransactionalInput(queries=[
                QueryInput(query="SELECT 42 AS n"),
            ]))
        )

    assert result.results[0].rows == [{"n": 42}]
    assert result.results[0].row_count == 1


def test_close_releases_pool() -> None:
    """close() 호출 후 pool이 None으로 초기화된다."""
    block = TransactionalQueryBlock(host="h", user="u", password="p", db="d")
    cursor = _make_cursor_mock([])
    conn = _make_conn_mock(cursor)
    pool = _make_pool_mock(conn)

    async def _run_and_close() -> None:
        await block.run(TransactionalInput(queries=[QueryInput(query="SELECT 1")]))
        await block.close()

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=pool)):
        asyncio.run(_run_and_close())

    assert block._pool is None
    pool.close.assert_called_once()
    pool.wait_closed.assert_called_once()
