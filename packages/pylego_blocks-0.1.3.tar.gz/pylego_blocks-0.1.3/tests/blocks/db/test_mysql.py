"""MySqlBlock 단위 테스트 — 실제 MySQL 없이 mock으로 검증."""

from __future__ import annotations

import asyncio
import importlib.util
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego.blocks.db.base import QueryInput
from pylego.blocks.db.mysql import MySqlBlock

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("aiomysql") is None,
    reason="aiomysql not installed",
)


def test_env_var_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    """환경변수로 연결 파라미터를 설정할 수 있어야 한다."""
    monkeypatch.setenv("PYLEGO_MYSQL_HOST", "myhost")
    monkeypatch.setenv("PYLEGO_MYSQL_USER", "myuser")
    monkeypatch.setenv("PYLEGO_MYSQL_PASSWORD", "mypass")
    monkeypatch.setenv("PYLEGO_MYSQL_DB", "mydb")
    block = MySqlBlock()
    assert block._host == "myhost"
    assert block._user == "myuser"
    assert block._password == "mypass"
    assert block._db == "mydb"


def test_explicit_params() -> None:
    """생성자 인수가 환경변수보다 우선해야 한다."""
    block = MySqlBlock(host="h", port=3307, user="u", password="p", db="d")
    assert block._host == "h"
    assert block._port == 3307
    assert block._user == "u"
    assert block._password == "p"
    assert block._db == "d"


def test_port_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    """PYLEGO_MYSQL_PORT 환경변수는 int로 변환되어야 한다."""
    monkeypatch.setenv("PYLEGO_MYSQL_PORT", "3308")
    block = MySqlBlock()
    assert block._port == 3308
    assert isinstance(block._port, int)


def test_query_mock() -> None:
    """mock된 aiomysql.connect로 쿼리 실행 결과를 검증한다."""
    block = MySqlBlock(host="localhost", user="root", password="", db="test")

    mock_row = {"id": 1, "name": "test"}
    mock_cursor = AsyncMock()
    mock_cursor.execute = AsyncMock()
    mock_cursor.fetchall = AsyncMock(return_value=[mock_row])
    mock_cursor.__aenter__ = AsyncMock(return_value=mock_cursor)
    mock_cursor.__aexit__ = AsyncMock(return_value=None)

    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)
    mock_conn.close = MagicMock()

    with patch("aiomysql.connect", new=AsyncMock(return_value=mock_conn)):
        result = asyncio.run(block.run(QueryInput(query="SELECT id, name FROM t")))

    assert result.rows == [{"id": 1, "name": "test"}]
    assert result.row_count == 1


def test_query_with_params() -> None:
    """파라미터가 있는 쿼리도 올바르게 전달되어야 한다."""
    block = MySqlBlock(host="localhost", user="root", password="", db="test")

    mock_row = {"id": 1, "name": "alice"}
    mock_cursor = AsyncMock()
    mock_cursor.execute = AsyncMock()
    mock_cursor.fetchall = AsyncMock(return_value=[mock_row])
    mock_cursor.__aenter__ = AsyncMock(return_value=mock_cursor)
    mock_cursor.__aexit__ = AsyncMock(return_value=None)

    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)
    mock_conn.close = MagicMock()

    with patch("aiomysql.connect", new=AsyncMock(return_value=mock_conn)):
        result = asyncio.run(
            block.run(QueryInput(query="SELECT id, name FROM t WHERE id = %s", params=[1]))
        )

    mock_cursor.execute.assert_called_once_with(
        "SELECT id, name FROM t WHERE id = %s", [1]
    )
    assert result.rows == [{"id": 1, "name": "alice"}]
    assert result.row_count == 1


def test_empty_result() -> None:
    """결과가 없는 쿼리는 빈 rows와 row_count=0을 반환해야 한다."""
    block = MySqlBlock(host="localhost", user="root", password="", db="test")

    mock_cursor = AsyncMock()
    mock_cursor.execute = AsyncMock()
    mock_cursor.fetchall = AsyncMock(return_value=[])
    mock_cursor.__aenter__ = AsyncMock(return_value=mock_cursor)
    mock_cursor.__aexit__ = AsyncMock(return_value=None)

    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)
    mock_conn.close = MagicMock()

    with patch("aiomysql.connect", new=AsyncMock(return_value=mock_conn)):
        result = asyncio.run(block.run(QueryInput(query="SELECT 1 WHERE 1=0")))

    assert result.rows == []
    assert result.row_count == 0


def test_connection_error() -> None:
    """연결 오류는 예외로 전파되어야 한다."""
    block = MySqlBlock(host="localhost", user="root", password="", db="test")
    with patch("aiomysql.connect", new=AsyncMock(side_effect=Exception("connection refused"))):
        with pytest.raises(Exception, match="connection refused"):
            asyncio.run(block.run(QueryInput(query="SELECT 1")))


def test_connection_closed_on_error() -> None:
    """쿼리 실행 오류가 발생해도 conn.close()가 호출되어야 한다."""
    block = MySqlBlock(host="localhost", user="root", password="", db="test")

    mock_cursor = AsyncMock()
    mock_cursor.execute = AsyncMock(side_effect=RuntimeError("query failed"))
    mock_cursor.__aenter__ = AsyncMock(return_value=mock_cursor)
    mock_cursor.__aexit__ = AsyncMock(return_value=None)

    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)
    mock_conn.close = MagicMock()

    with patch("aiomysql.connect", new=AsyncMock(return_value=mock_conn)):
        with pytest.raises(RuntimeError, match="query failed"):
            asyncio.run(block.run(QueryInput(query="SELECT 1")))

    mock_conn.close.assert_called_once()
