"""DuckDbBlock 단위 테스트 — asyncio.to_thread 기반 DuckDB 쿼리 검증."""

from __future__ import annotations

import asyncio
import importlib.util

import pytest

from pylego.blocks.db.base import QueryInput
from pylego.blocks.db.duckdb import DuckDbBlock

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("duckdb") is None,
    reason="duckdb not installed",
)


def test_select_basic() -> None:
    """인메모리 DB에서 SELECT 1 AS n 이 올바르게 반환되어야 한다."""
    block = DuckDbBlock()
    result = asyncio.run(block.run(QueryInput(query="SELECT 1 AS n")))
    assert result.rows == [{"n": 1}]
    assert result.row_count == 1


def test_param_binding() -> None:
    """위치 파라미터($1) 바인딩이 올바르게 동작해야 한다."""
    block = DuckDbBlock()
    result = asyncio.run(
        block.run(QueryInput(query="SELECT $1 AS v", params=[42]))
    )
    assert result.rows[0]["v"] == 42


def test_multiple_rows() -> None:
    """VALUES 절로 여러 행을 반환할 수 있어야 한다."""
    block = DuckDbBlock()
    result = asyncio.run(
        block.run(QueryInput(query="SELECT * FROM (VALUES (1), (2), (3)) t(n)"))
    )
    assert result.row_count == 3
    assert [r["n"] for r in result.rows] == [1, 2, 3]


def test_query_error_propagates() -> None:
    """존재하지 않는 테이블 조회 시 예외가 전파되어야 한다."""
    block = DuckDbBlock()
    with pytest.raises(Exception):
        asyncio.run(block.run(QueryInput(query="SELECT * FROM no_such_table")))


def test_default_database_is_memory() -> None:
    """기본 database 인수가 ':memory:' 이어야 한다."""
    block = DuckDbBlock()
    assert block._database == ":memory:"
