"""QueryBlock 공통 베이스 단위 테스트."""

from __future__ import annotations

from typing import Any

import pytest

from pylego.blocks.db.base import QueryBlock, QueryInput, QueryResult
from pylego.core.stud import Stud


# ---------------------------------------------------------------------------
# 테스트용 구체 구현체
# ---------------------------------------------------------------------------


class FakeQueryBlock(QueryBlock):
    """테스트용 인메모리 QueryBlock 구현체."""

    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        return self._rows


class EchoParamsBlock(QueryBlock):
    """params 를 rows 에 그대로 반환하는 테스트용 블록."""

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        return [{"param": p} for p in params]


# ---------------------------------------------------------------------------
# QueryInput / QueryResult Stud 검증
# ---------------------------------------------------------------------------


def test_query_input_defaults() -> None:
    """params 기본값은 빈 리스트여야 한다."""
    inp = QueryInput(query="SELECT 1")
    assert inp.query == "SELECT 1"
    assert inp.params == []


def test_query_input_with_params() -> None:
    """params 에 임의 값을 넣을 수 있다."""
    inp = QueryInput(query="SELECT ?", params=[42, "hello"])
    assert inp.params == [42, "hello"]


def test_query_input_is_frozen() -> None:
    """QueryInput 은 Stud 상속으로 frozen=True 이어야 한다."""
    inp = QueryInput(query="SELECT 1")
    with pytest.raises(Exception):  # pydantic ValidationError (frozen)
        inp.query = "MODIFIED"  # type: ignore[misc]


def test_query_result_fields() -> None:
    """QueryResult 필드가 올바르게 설정된다."""
    result = QueryResult(rows=[{"id": 1}], row_count=1)
    assert result.row_count == 1
    assert result.rows == [{"id": 1}]


def test_query_result_is_frozen() -> None:
    """QueryResult 는 frozen=True 이어야 한다."""
    result = QueryResult(rows=[], row_count=0)
    with pytest.raises(Exception):  # pydantic ValidationError (frozen)
        result.row_count = 99  # type: ignore[misc]


def test_query_input_is_stud_subclass() -> None:
    """QueryInput 은 Stud 서브클래스여야 한다."""
    assert issubclass(QueryInput, Stud)


def test_query_result_is_stud_subclass() -> None:
    """QueryResult 는 Stud 서브클래스여야 한다."""
    assert issubclass(QueryResult, Stud)


# ---------------------------------------------------------------------------
# QueryBlock 추상 클래스 검증
# ---------------------------------------------------------------------------


def test_query_block_abstract() -> None:
    """_execute 미구현 시 인스턴스화할 수 없다."""

    class IncompleteBlock(QueryBlock):
        pass

    with pytest.raises(TypeError):
        IncompleteBlock()  # type: ignore[abstract]


def test_query_block_input_output_model() -> None:
    """QueryBlock 의 input_model / output_model 이 올바르게 선언된다."""
    assert QueryBlock.input_model is QueryInput
    assert QueryBlock.output_model is QueryResult


# ---------------------------------------------------------------------------
# run() 동작 검증
# ---------------------------------------------------------------------------


async def test_run_returns_query_result() -> None:
    """run() 은 QueryResult 인스턴스를 반환한다."""
    rows = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
    block = FakeQueryBlock(rows)
    result = await block.run(QueryInput(query="SELECT * FROM users"))
    assert isinstance(result, QueryResult)


async def test_run_row_count_matches_rows() -> None:
    """row_count 는 rows 의 길이와 일치한다."""
    rows = [{"x": i} for i in range(5)]
    block = FakeQueryBlock(rows)
    result = await block.run(QueryInput(query="SELECT x FROM t"))
    assert result.row_count == 5
    assert len(result.rows) == 5


async def test_run_empty_result() -> None:
    """결과가 없을 때 rows=[], row_count=0 이어야 한다."""
    block = FakeQueryBlock([])
    result = await block.run(QueryInput(query="SELECT 1 WHERE FALSE"))
    assert result.rows == []
    assert result.row_count == 0


async def test_run_passes_query_and_params_to_execute() -> None:
    """run() 이 query / params 를 _execute() 에 그대로 전달한다."""
    block = EchoParamsBlock()
    result = await block.run(QueryInput(query="SELECT ?", params=[10, 20]))
    assert result.rows == [{"param": 10}, {"param": 20}]
    assert result.row_count == 2


async def test_run_default_params_empty() -> None:
    """params 미지정 시 _execute 에 빈 리스트가 전달된다."""
    received_params: list[list[Any]] = []

    class CapturingBlock(QueryBlock):
        async def _execute(
            self, query: str, params: list[Any]
        ) -> list[dict[str, Any]]:
            received_params.append(params)
            return []

    block = CapturingBlock()
    await block.run(QueryInput(query="SELECT 1"))
    assert received_params == [[]]
