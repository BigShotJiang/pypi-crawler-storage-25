"""HttpRequestBlock 단위 테스트 — httpx mock 기반."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego.blocks.http_request import HttpRequestBlock, HttpRequestInput


def _make_response(
    status_code: int = 200,
    text: str = '{"ok": true}',
    headers: dict[str, str] | None = None,
) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text
    resp.headers = headers or {"content-type": "application/json"}
    resp.json = MagicMock(return_value={"ok": True})
    resp.raise_for_status = MagicMock()
    return resp


def _make_client_mock(resp: MagicMock) -> MagicMock:
    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


def test_get_request_returns_result() -> None:
    """GET 요청 결과가 HttpRequestResult로 반환된다."""
    block = HttpRequestBlock()
    resp = _make_response()
    client = _make_client_mock(resp)

    with patch("httpx.AsyncClient", return_value=client):
        result = asyncio.run(
            block.run(HttpRequestInput(url="https://example.com/api"))
        )

    assert result.status_code == 200
    assert result.ok is True
    assert result.json_data == {"ok": True}


def test_post_with_body() -> None:
    """POST 요청 시 body가 전달된다."""
    block = HttpRequestBlock()
    resp = _make_response(status_code=201, text='{"id": 1}')
    resp.json = MagicMock(return_value={"id": 1})
    client = _make_client_mock(resp)

    with patch("httpx.AsyncClient", return_value=client):
        result = asyncio.run(
            block.run(
                HttpRequestInput(
                    method="POST",
                    url="https://example.com/items",
                    body={"name": "test"},
                )
            )
        )

    assert result.status_code == 201
    client.request.assert_called_once()
    call_kwargs = client.request.call_args
    assert call_kwargs.kwargs["json"] == {"name": "test"}


def test_4xx_ok_false() -> None:
    """4xx 응답이면 ok=False 이다."""
    block = HttpRequestBlock()
    resp = _make_response(status_code=404, text="Not Found")
    resp.json = MagicMock(side_effect=Exception("not json"))
    client = _make_client_mock(resp)

    with patch("httpx.AsyncClient", return_value=client):
        result = asyncio.run(
            block.run(HttpRequestInput(url="https://example.com/missing"))
        )

    assert result.ok is False
    assert result.status_code == 404
    assert result.json_data is None


def test_raise_for_status_flag() -> None:
    """raise_for_status=True 이면 4xx에서 httpx.HTTPStatusError가 발생한다."""
    import httpx

    block = HttpRequestBlock()
    resp = _make_response(status_code=403, text="Forbidden")
    resp.raise_for_status = MagicMock(
        side_effect=httpx.HTTPStatusError("403", request=MagicMock(), response=resp)
    )
    client = _make_client_mock(resp)

    with patch("httpx.AsyncClient", return_value=client):
        with pytest.raises(httpx.HTTPStatusError):
            asyncio.run(
                block.run(
                    HttpRequestInput(
                        url="https://example.com/secret",
                        raise_for_status=True,
                    )
                )
            )


def test_headers_and_params_passed() -> None:
    """headers와 params가 httpx.request에 전달된다."""
    block = HttpRequestBlock()
    resp = _make_response()
    client = _make_client_mock(resp)

    with patch("httpx.AsyncClient", return_value=client):
        asyncio.run(
            block.run(
                HttpRequestInput(
                    url="https://api.example.com/search",
                    headers={"Authorization": "Bearer tok"},
                    params={"q": "pylego"},
                )
            )
        )

    kwargs = client.request.call_args.kwargs
    assert kwargs["headers"] == {"Authorization": "Bearer tok"}
    assert kwargs["params"] == {"q": "pylego"}
