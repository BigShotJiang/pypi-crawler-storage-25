"""BranchPrepareBlock 테스트."""

from __future__ import annotations

import pytest

from pylego.blocks.git import BranchPrepareBlock, BranchSpec


class _FakeGit:
    """프로그래머블 git runner. responses 리스트에서 순서대로 응답 반환."""

    def __init__(self, responses: list[tuple[int, str, str]]) -> None:
        self._responses = list(responses)
        self.calls: list[list[str]] = []

    async def __call__(self, args: list[str]) -> tuple[int, str, str]:
        self.calls.append(args)
        if not self._responses:
            return (0, "", "")  # 기본: 성공
        return self._responses.pop(0)


class TestBranchPrepare:
    async def test_creates_new_branch_when_not_existing(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # checkout main
                (0, "", ""),  # pull origin main
                (1, "", ""),  # show-ref (not found)
                (0, "", ""),  # checkout -b feature/x
                (0, "", ""),  # push -u origin feature/x
            ]
        )
        block = BranchPrepareBlock(git_runner=git)
        result = await block.run(BranchSpec(base_branch="main", feature_branch="feature/x"))
        assert result.reused is False
        assert result.feature_branch == "feature/x"
        assert ["checkout", "main"] in git.calls
        assert ["checkout", "-b", "feature/x"] in git.calls
        assert ["push", "-u", "origin", "feature/x"] in git.calls

    async def test_reuses_existing_branch(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # checkout main
                (0, "", ""),  # pull
                (0, "", ""),  # show-ref (exists)
                (0, "", ""),  # checkout feature/x
            ]
        )
        result = await BranchPrepareBlock(git_runner=git).run(
            BranchSpec(base_branch="main", feature_branch="feature/x")
        )
        assert result.reused is True
        # -b 로 새로 만들지 않았는지 확인
        assert ["checkout", "-b", "feature/x"] not in git.calls

    async def test_pull_failure_is_tolerated(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # checkout
                (1, "", "no upstream"),  # pull (best-effort, 허용)
                (1, "", ""),  # show-ref (not found)
                (0, "", ""),  # checkout -b
                (1, "", "no remote"),  # push (best-effort, 허용)
            ]
        )
        # pull / push 실패해도 예외 없어야 함
        await BranchPrepareBlock(git_runner=git).run(
            BranchSpec(base_branch="main", feature_branch="feature/x")
        )

    async def test_checkout_failure_raises(self) -> None:
        git = _FakeGit([(1, "", "dirty working tree")])
        with pytest.raises(RuntimeError, match="dirty working tree"):
            await BranchPrepareBlock(git_runner=git).run(
                BranchSpec(base_branch="main", feature_branch="feature/x")
            )

    async def test_push_origin_false_skips_push(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # checkout main
                (0, "", ""),  # pull
                (1, "", ""),  # show-ref (not found)
                (0, "", ""),  # checkout -b
            ]
        )
        await BranchPrepareBlock(git_runner=git).run(
            BranchSpec(base_branch="main", feature_branch="feature/x", push_origin=False)
        )
        assert not any(c[0] == "push" for c in git.calls)
