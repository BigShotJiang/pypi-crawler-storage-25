"""DuckDuckGoSearchBlock 단위 테스트 — duckduckgo_search 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from unittest.mock import MagicMock

import pytest

from pylego.blocks.search.duckduckgo import (
    DuckDuckGoSearchBlock,
    DuckDuckGoSearchInput,
)
from pylego.blocks.search.google import GoogleSearchResult, SearchItem
from pylego.core.resilience import FallbackBlock


# ---------------------------------------------------------------------------
# duckduckgo_search 모듈 stub 헬퍼
# ---------------------------------------------------------------------------


def _install_ddgs_stub(
    results: list[dict[str, str]] | None = None,
) -> MagicMock:
    """sys.modules 에 duckduckgo_search 스텁을 주입하고 DDGS mock 반환."""
    if results is None:
        results = [
            {"title": "Result A", "href": "https://a.example.com", "body": "Snippet A"},
            {"title": "Result B", "href": "https://b.example.com", "body": "Snippet B"},
        ]

    ddgs_instance = MagicMock()
    ddgs_instance.text.return_value = results

    ddgs_cls = MagicMock(return_value=ddgs_instance)

    mod = types.ModuleType("duckduckgo_search")
    mod.DDGS = ddgs_cls  # type: ignore[attr-defined]
    sys.modules["duckduckgo_search"] = mod

    return ddgs_cls


@pytest.fixture(autouse=True)
def _clear_ddgs() -> Generator[None, None, None]:
    """각 테스트 후 duckduckgo_search 스텁 제거."""
    yield
    sys.modules.pop("duckduckgo_search", None)
    sys.modules.pop("pylego.blocks.search.duckduckgo", None)


# ---------------------------------------------------------------------------
# 정상 검색
# ---------------------------------------------------------------------------


async def test_search_success() -> None:
    """정상 검색 — items 2개 응답."""
    _install_ddgs_stub()
    block = DuckDuckGoSearchBlock()
    result = await block.run(DuckDuckGoSearchInput(query="pylego"))

    assert isinstance(result, GoogleSearchResult)
    assert len(result.items) == 2
    assert isinstance(result.items[0], SearchItem)
    assert result.items[0].title == "Result A"
    assert result.items[0].link == "https://a.example.com"
    assert result.items[0].snippet == "Snippet A"
    assert result.total_results == "2"


async def test_search_passes_correct_params() -> None:
    """DDGS().text() 에 올바른 인자가 전달되는지 검증."""
    ddgs_cls = _install_ddgs_stub()
    block = DuckDuckGoSearchBlock()
    await block.run(DuckDuckGoSearchInput(query="hello world", num=3))

    ddgs_cls.return_value.text.assert_called_once_with("hello world", max_results=3)


# ---------------------------------------------------------------------------
# 빈 결과 처리
# ---------------------------------------------------------------------------


async def test_search_empty_results() -> None:
    """빈 결과 리스트 처리 — items=[], total_results='0'."""
    _install_ddgs_stub(results=[])
    block = DuckDuckGoSearchBlock()
    result = await block.run(DuckDuckGoSearchInput(query="nothing"))

    assert isinstance(result, GoogleSearchResult)
    assert result.items == []
    assert result.total_results == "0"


# ---------------------------------------------------------------------------
# ImportError
# ---------------------------------------------------------------------------


async def test_import_error_without_duckduckgo_search() -> None:
    """duckduckgo-search 미설치 시 ImportError — 메시지에 pylego[duckduckgo] 포함."""
    sys.modules["duckduckgo_search"] = None  # type: ignore[assignment]
    block = DuckDuckGoSearchBlock()
    with pytest.raises(ImportError, match="pylego\\[duckduckgo\\]"):
        await block.run(DuckDuckGoSearchInput(query="test"))


# ---------------------------------------------------------------------------
# FallbackBlock 조합 — GoogleSearchBlock 실패 시 DuckDuckGo 사용
# ---------------------------------------------------------------------------


async def test_fallback_output_compatible_with_google_result() -> None:
    """DuckDuckGoSearchBlock 출력이 GoogleSearchResult 타입 — FallbackBlock 조합 호환 증명.

    FallbackBlock 은 동일 input_model 을 요구하므로 GoogleSearchInput 을 받는
    래퍼 블록과 조합할 때 사용한다. 여기서는 출력 타입 호환성을 검증한다.
    """
    _install_ddgs_stub(
        results=[
            {"title": "DDG Title", "href": "https://ddg.example.com", "body": "DDG Snippet"},
        ]
    )

    ddg_block = DuckDuckGoSearchBlock()
    result = await ddg_block.run(DuckDuckGoSearchInput(query="fallback test"))

    # 출력이 GoogleSearchResult 와 동일 타입 — FallbackBlock 다운스트림과 호환
    assert isinstance(result, GoogleSearchResult)
    assert len(result.items) == 1
    assert result.items[0].title == "DDG Title"
    assert result.items[0].link == "https://ddg.example.com"
    assert result.total_results == "1"


async def test_fallback_block_with_same_input_model() -> None:
    """FallbackBlock: primary 실패 시 DuckDuckGoSearchBlock 폴백 (동일 input_model 사용)."""
    _install_ddgs_stub(
        results=[
            {"title": "DDG Fallback", "href": "https://ddg.example.com", "body": "DDG Body"},
        ]
    )

    # DuckDuckGoSearchBlock 두 개 — primary 는 항상 실패
    class _FailingDDGBlock(DuckDuckGoSearchBlock):
        async def run(self, inp: DuckDuckGoSearchInput) -> GoogleSearchResult:
            raise RuntimeError("primary 실패")

    primary = _FailingDDGBlock()
    fallback_block = DuckDuckGoSearchBlock()

    fb = FallbackBlock(primary=primary, fallback=fallback_block)
    result = await fb.run(DuckDuckGoSearchInput(query="test"))

    assert isinstance(result, GoogleSearchResult)
    assert result.items[0].title == "DDG Fallback"
