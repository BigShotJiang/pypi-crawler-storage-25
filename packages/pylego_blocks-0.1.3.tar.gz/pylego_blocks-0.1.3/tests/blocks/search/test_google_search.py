"""GoogleSearchBlock 단위 테스트 — httpx 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import ValidationError

from pylego.blocks.search.google import (
    GoogleSearchBlock,
    GoogleSearchInput,
    GoogleSearchResult,
    SearchItem,
)


# ---------------------------------------------------------------------------
# httpx stub
# ---------------------------------------------------------------------------

def _make_httpx_stub(
    items: list[dict[str, str]] | None = None,
    total_results: str = "2",
    status_code: int = 200,
) -> types.ModuleType:
    if items is None:
        items = [
            {"title": "Title A", "link": "https://a.example.com", "snippet": "Snippet A"},
            {"title": "Title B", "link": "https://b.example.com", "snippet": "Snippet B"},
        ]

    mod = types.ModuleType("httpx")

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = {
        "items": items,
        "searchInformation": {"totalResults": total_results},
    }
    if status_code >= 400:
        import httpx as real_httpx  # noqa: F401 — HTTPStatusError 는 실제 타입 불필요
        error = Exception(f"HTTP {status_code}")
        resp.raise_for_status.side_effect = error
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.get = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    async_client_cls = MagicMock(return_value=client)
    mod.AsyncClient = async_client_cls  # type: ignore[attr-defined]

    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    # Force-import real httpx so we always have a reference to restore.
    # google.py imports httpx lazily (inside run()), so it may not be in
    # sys.modules yet — we cannot rely on sys.modules.get("httpx") here.
    real_httpx = importlib.import_module("httpx")
    saved_google = sys.modules.get("pylego.blocks.search.google")
    saved_http = sys.modules.get("pylego.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_google is not None:
        sys.modules["pylego.blocks.search.google"] = saved_google
    else:
        sys.modules.pop("pylego.blocks.search.google", None)
    if saved_http is not None:
        sys.modules["pylego.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego.blocks.http", None)


# ---------------------------------------------------------------------------
# 정상 검색
# ---------------------------------------------------------------------------


async def test_search_success() -> None:
    """정상 검색 — items 2개 응답."""
    _make_httpx_stub()
    block = GoogleSearchBlock(api_key="test_key", search_engine_id="test_cx")
    result = await block.run(GoogleSearchInput(query="pylego"))

    assert isinstance(result, GoogleSearchResult)
    assert len(result.items) == 2
    assert isinstance(result.items[0], SearchItem)
    assert result.items[0].title == "Title A"
    assert result.items[0].link == "https://a.example.com"
    assert result.items[0].snippet == "Snippet A"
    assert result.total_results == "2"


async def test_search_passes_correct_params() -> None:
    """GET 요청에 올바른 params 가 전달되는지 검증."""
    stub = _make_httpx_stub()
    block = GoogleSearchBlock(api_key="mykey", search_engine_id="mycx")
    await block.run(GoogleSearchInput(query="test query", num=3, lang="en"))

    client_instance = stub.AsyncClient.return_value
    call_kwargs = client_instance.get.call_args[1]["params"]
    assert call_kwargs["key"] == "mykey"
    assert call_kwargs["cx"] == "mycx"
    assert call_kwargs["q"] == "test query"
    assert call_kwargs["num"] == 3
    assert call_kwargs["lr"] == "lang_en"


# ---------------------------------------------------------------------------
# 빈 결과 처리
# ---------------------------------------------------------------------------


async def test_search_empty_results() -> None:
    """items 없는 응답 처리 — items=[] 반환."""
    mod = types.ModuleType("httpx")
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "searchInformation": {"totalResults": "0"},
    }
    resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.get = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    mod.AsyncClient = MagicMock(return_value=client)  # type: ignore[attr-defined]
    sys.modules["httpx"] = mod

    block = GoogleSearchBlock(api_key="k", search_engine_id="cx")
    result = await block.run(GoogleSearchInput(query="nothing"))

    assert isinstance(result, GoogleSearchResult)
    assert result.items == []
    assert result.total_results == "0"


# ---------------------------------------------------------------------------
# 입력 검증
# ---------------------------------------------------------------------------


def test_search_num_validation_zero() -> None:
    """num=0 → ValidationError."""
    with pytest.raises(ValidationError):
        GoogleSearchInput(query="test", num=0)


def test_search_num_validation_eleven() -> None:
    """num=11 → ValidationError."""
    with pytest.raises(ValidationError):
        GoogleSearchInput(query="test", num=11)


def test_search_num_boundary_valid() -> None:
    """num=1, num=10 은 유효."""
    inp_min = GoogleSearchInput(query="test", num=1)
    inp_max = GoogleSearchInput(query="test", num=10)
    assert inp_min.num == 1
    assert inp_max.num == 10


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_search_missing_api_key() -> None:
    """api_key 없고 환경변수도 없으면 ValueError."""
    import os
    os.environ.pop("PYLEGO_GOOGLE_SEARCH_API_KEY", None)
    os.environ.pop("PYLEGO_GOOGLE_SEARCH_ENGINE_ID", None)
    with pytest.raises(ValueError, match="api_key"):
        GoogleSearchBlock(search_engine_id="cx")


def test_search_missing_engine_id() -> None:
    """search_engine_id 없고 환경변수도 없으면 ValueError."""
    import os
    os.environ.pop("PYLEGO_GOOGLE_SEARCH_ENGINE_ID", None)
    with pytest.raises(ValueError, match="search_engine_id"):
        GoogleSearchBlock(api_key="key")


# ---------------------------------------------------------------------------
# 환경변수 fallback
# ---------------------------------------------------------------------------


def test_search_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    """환경변수로 api_key / search_engine_id 를 주입할 수 있다."""
    monkeypatch.setenv("PYLEGO_GOOGLE_SEARCH_API_KEY", "env_key")
    monkeypatch.setenv("PYLEGO_GOOGLE_SEARCH_ENGINE_ID", "env_cx")

    block = GoogleSearchBlock()
    assert block._api_key == "env_key"
    assert block._search_engine_id == "env_cx"


def test_search_arg_takes_precedence_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """생성자 인자가 환경변수보다 우선한다."""
    monkeypatch.setenv("PYLEGO_GOOGLE_SEARCH_API_KEY", "env_key")
    monkeypatch.setenv("PYLEGO_GOOGLE_SEARCH_ENGINE_ID", "env_cx")

    block = GoogleSearchBlock(api_key="arg_key", search_engine_id="arg_cx")
    assert block._api_key == "arg_key"
    assert block._search_engine_id == "arg_cx"


# ---------------------------------------------------------------------------
# HTTP 오류 전파
# ---------------------------------------------------------------------------


async def test_search_http_error() -> None:
    """4xx 오류가 예외로 전파된다."""
    _make_httpx_stub(status_code=403)
    block = GoogleSearchBlock(api_key="k", search_engine_id="cx")
    with pytest.raises(Exception):
        await block.run(GoogleSearchInput(query="test"))


# ---------------------------------------------------------------------------
# ImportError
# ---------------------------------------------------------------------------


async def test_import_error_without_httpx() -> None:
    """httpx 미설치 시 ImportError 발생."""
    sys.modules["httpx"] = None  # type: ignore[assignment]
    block = GoogleSearchBlock(api_key="k", search_engine_id="cx")
    with pytest.raises(ImportError, match="httpx"):
        await block.run(GoogleSearchInput(query="test"))
