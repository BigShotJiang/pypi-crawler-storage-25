"""SubprocessBlock 단위 테스트."""

from __future__ import annotations

import sys

import pytest

from pylego import SubprocessBlock, SubprocessInput, SubprocessResult


async def test_success() -> None:
    block = SubprocessBlock()
    result = await block.run(
        SubprocessInput(cmd=[sys.executable, "-c", "print('hello')"])
    )
    assert isinstance(result, SubprocessResult)
    assert result.success is True
    assert result.returncode == 0
    assert "hello" in result.stdout


async def test_stderr_captured() -> None:
    block = SubprocessBlock()
    result = await block.run(
        SubprocessInput(
            cmd=[sys.executable, "-c", "import sys; sys.stderr.write('err\\n')"]
        )
    )
    assert result.success is True
    assert "err" in result.stderr


async def test_failure_returncode() -> None:
    block = SubprocessBlock()
    result = await block.run(
        SubprocessInput(cmd=[sys.executable, "-c", "raise SystemExit(1)"])
    )
    assert result.success is False
    assert result.returncode == 1


async def test_stdin_data() -> None:
    block = SubprocessBlock()
    result = await block.run(
        SubprocessInput(
            cmd=[sys.executable, "-c", "import sys; print(sys.stdin.read().strip())"],
            stdin_data="hello stdin",
        )
    )
    assert result.success is True
    assert "hello stdin" in result.stdout


async def test_timeout_raises() -> None:
    block = SubprocessBlock()
    with pytest.raises(Exception):
        await block.run(
            SubprocessInput(
                cmd=[sys.executable, "-c", "import time; time.sleep(60)"],
                timeout=0.1,
            )
        )
