"""CsvReadBlock / CsvWriteBlock 단위 테스트."""

from __future__ import annotations

import os
import tempfile

import pytest

from pylego import CsvReadBlock, CsvReadInput, CsvWriteBlock, CsvWriteInput, CsvWriteResult
from pylego.blocks.file.csv import CsvReadResult


async def test_write_then_read_roundtrip() -> None:
    rows = [
        {"name": "홍길동", "age": "30"},
        {"name": "김철수", "age": "25"},
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        path = f.name
    try:
        write_result = await CsvWriteBlock().run(CsvWriteInput(path=path, rows=rows))
        assert isinstance(write_result, CsvWriteResult)
        assert write_result.row_count == 2
        assert write_result.path == path

        read_result = await CsvReadBlock().run(CsvReadInput(path=path))
        assert isinstance(read_result, CsvReadResult)
        assert read_result.row_count == 2
        assert read_result.rows[0]["name"] == "홍길동"
        assert read_result.rows[1]["age"] == "25"
    finally:
        os.unlink(path)


async def test_write_empty_rows() -> None:
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        path = f.name
    try:
        result = await CsvWriteBlock().run(CsvWriteInput(path=path, rows=[]))
        assert result.row_count == 0
    finally:
        os.unlink(path)


async def test_custom_delimiter() -> None:
    rows = [{"a": "1", "b": "2"}]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        path = f.name
    try:
        await CsvWriteBlock().run(CsvWriteInput(path=path, rows=rows, delimiter=";"))
        result = await CsvReadBlock().run(CsvReadInput(path=path, delimiter=";"))
        assert result.rows[0]["a"] == "1"
    finally:
        os.unlink(path)


async def test_no_header_mode() -> None:
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, encoding="utf-8"
    ) as f:
        f.write("alpha,beta\ngamma,delta\n")
        path = f.name
    try:
        result = await CsvReadBlock().run(CsvReadInput(path=path, has_header=False))
        assert result.row_count == 2
        assert result.rows[0]["0"] == "alpha"
        assert result.rows[1]["1"] == "delta"
    finally:
        os.unlink(path)


async def test_explicit_fieldnames() -> None:
    rows = [{"x": "10", "y": "20"}]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        path = f.name
    try:
        result = await CsvWriteBlock().run(
            CsvWriteInput(path=path, rows=rows, fieldnames=["y", "x"])
        )
        assert result.row_count == 1
        # header order matches explicit fieldnames
        with open(path, encoding="utf-8") as fh:
            header_line = fh.readline().strip()
        assert header_line == "y,x"
    finally:
        os.unlink(path)
