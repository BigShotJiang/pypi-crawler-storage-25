"""M124 — graph.py 책임 분리 검증 테스트."""

from __future__ import annotations


def test_visualize_exports_block_stat() -> None:
    from pylego.core.visualize import BlockStat, build_stats
    assert BlockStat is not None
    assert build_stats is not None


def test_visualize_exports_graph_fns() -> None:
    from pylego.core.visualize import to_dot, to_html, to_mermaid
    assert to_mermaid is not None
    assert to_dot is not None
    assert to_html is not None


def test_ops_causal_exports() -> None:
    from pylego.ops.causal import CausalFactor, EnvironmentContext, VersionContext
    assert CausalFactor is not None
    assert EnvironmentContext is not None
    assert VersionContext is not None


def test_ops_diff_exports() -> None:
    from pylego.ops.diff import HealthDiff
    assert HealthDiff is not None


def test_ops_health_exports() -> None:
    from pylego.ops.health import PipelineHealth, build_health_summary
    assert PipelineHealth is not None
    assert build_health_summary is not None


def test_graph_shim_backward_compat() -> None:
    import warnings
    from pylego.core import graph
    from pylego.core.visualize import BlockStat as VisualizeStat
    from pylego.ops.causal import CausalFactor as OpsCausal
    from pylego.ops.diff import HealthDiff as OpsDiff
    from pylego.ops.health import PipelineHealth as OpsHealth

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        assert graph.BlockStat is VisualizeStat
        assert graph.CausalFactor is OpsCausal
        assert graph.HealthDiff is OpsDiff
        assert graph.PipelineHealth is OpsHealth


# M130 — Zero-Ops Boundary 집행 테스트 (설계 원칙 59)

def test_core_graph_pipeline_health_raises_deprecation_warning() -> None:
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        from pylego.core.graph import PipelineHealth  # noqa: F401
        _ = PipelineHealth
    deprecations = [w for w in caught if issubclass(w.category, DeprecationWarning)]
    assert deprecations, "DeprecationWarning이 발생해야 합니다"


def test_core_graph_build_health_summary_raises_deprecation_warning() -> None:
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        from pylego.core import graph as _g
        _ = _g.build_health_summary
    deprecations = [w for w in caught if issubclass(w.category, DeprecationWarning)]
    assert deprecations, "DeprecationWarning이 발생해야 합니다"


def test_ops_health_pipeline_health_no_warning() -> None:
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        from pylego.ops.health import PipelineHealth  # noqa: F401
        _ = PipelineHealth
    deprecations = [w for w in caught if issubclass(w.category, DeprecationWarning)]
    assert not deprecations, "pylego.ops.health는 경고 없어야 합니다"


def test_ops_diff_health_diff_no_warning() -> None:
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        from pylego.ops.diff import HealthDiff  # noqa: F401
        _ = HealthDiff
    deprecations = [w for w in caught if issubclass(w.category, DeprecationWarning)]
    assert not deprecations, "pylego.ops.diff는 경고 없어야 합니다"


def test_deprecation_warning_message_contains_v6() -> None:
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        from pylego.core import graph as _g
        _ = _g.PipelineHealth
    msgs = [str(w.message) for w in caught if issubclass(w.category, DeprecationWarning)]
    assert any("v6.0.0" in m for m in msgs), f"경고 메시지에 'v6.0.0'이 없음: {msgs}"
