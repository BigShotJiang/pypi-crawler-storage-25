"""LlmRouter 단위 테스트 — 백엔드 라우팅·환경변수·에러 케이스."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego.blocks.llm.base import LlmInput, LlmResult


def _make_anthropic_mock() -> Any:
    usage = MagicMock(input_tokens=1, output_tokens=2)
    content_block = MagicMock(text="ok")
    msg = MagicMock(
        content=[content_block], model="claude-opus-4-5",
        stop_reason="end_turn", usage=usage,
    )
    client = MagicMock()
    client.messages.create = AsyncMock(return_value=msg)
    mod = MagicMock()
    mod.AsyncAnthropic = MagicMock(return_value=client)
    return mod


def _make_openai_mock() -> Any:
    usage = MagicMock(prompt_tokens=1, completion_tokens=2)
    choice = MagicMock()
    choice.message.content = "ok"
    choice.finish_reason = "stop"
    resp = MagicMock(choices=[choice], model="gpt-4o", usage=usage)
    client = MagicMock()
    client.chat.completions.create = AsyncMock(return_value=resp)
    mod = MagicMock()
    mod.AsyncOpenAI = MagicMock(return_value=client)
    return mod


def _make_ollama_mock() -> tuple[Any, Any]:
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    resp.json.return_value = {
        "response": "ok", "model": "llama3.2", "done": True,
        "prompt_eval_count": 1, "eval_count": 2,
    }
    async_client = AsyncMock()
    async_client.post = AsyncMock(return_value=resp)
    async_client.__aenter__ = AsyncMock(return_value=async_client)
    async_client.__aexit__ = AsyncMock(return_value=False)
    return async_client, resp


async def test_router_explicit_anthropic() -> None:
    from pylego.blocks.llm.router import LlmRouter

    with patch.dict("sys.modules", {"anthropic": _make_anthropic_mock()}):
        router = LlmRouter(backend="anthropic")
        result = await router.run(LlmInput(prompt="test"))
    assert isinstance(result, LlmResult)
    assert result.content == "ok"


async def test_router_explicit_openai() -> None:
    from pylego.blocks.llm.router import LlmRouter

    with patch.dict("sys.modules", {"openai": _make_openai_mock()}):
        router = LlmRouter(backend="openai")
        result = await router.run(LlmInput(prompt="test"))
    assert isinstance(result, LlmResult)


async def test_router_env_var_backend(monkeypatch: pytest.MonkeyPatch) -> None:
    from pylego.blocks.llm.router import LlmRouter

    monkeypatch.setenv("PYLEGO_LLM_BACKEND", "anthropic")
    with patch.dict("sys.modules", {"anthropic": _make_anthropic_mock()}):
        router = LlmRouter()
        result = await router.run(LlmInput(prompt="test"))
    assert result.content == "ok"


async def test_router_env_model_applied(monkeypatch: pytest.MonkeyPatch) -> None:
    from pylego.blocks.llm.router import LlmRouter

    monkeypatch.setenv("PYLEGO_LLM_BACKEND", "anthropic")
    monkeypatch.setenv("PYLEGO_LLM_MODEL", "claude-haiku-4-5-20251001")

    anthropic_mod = _make_anthropic_mock()
    with patch.dict("sys.modules", {"anthropic": anthropic_mod}):
        router = LlmRouter()
        await router.run(LlmInput(prompt="test"))
        call_kwargs = anthropic_mod.AsyncAnthropic.return_value.messages.create.call_args.kwargs
    assert call_kwargs["model"] == "claude-haiku-4-5-20251001"


async def test_router_no_backend_raises() -> None:
    from pylego.blocks.llm.router import LlmRouter

    router = LlmRouter()
    with pytest.raises(ValueError, match="백엔드가 지정되지 않았습니다"):
        await router.run(LlmInput(prompt="test"))


async def test_router_invalid_backend_raises() -> None:
    from pylego.blocks.llm.router import LlmRouter

    router = LlmRouter(backend="nonexistent")
    with pytest.raises(ValueError, match="지원하지 않는"):
        await router.run(LlmInput(prompt="test"))


async def test_router_caches_backend_instance() -> None:
    from pylego.blocks.llm.router import LlmRouter

    with patch.dict("sys.modules", {"anthropic": _make_anthropic_mock()}):
        router = LlmRouter(backend="anthropic")
        await router.run(LlmInput(prompt="first"))
        await router.run(LlmInput(prompt="second"))

    assert len(router._cache) == 1


async def test_router_ollama() -> None:
    from pylego.blocks.llm.router import LlmRouter

    async_client, _ = _make_ollama_mock()
    with patch("httpx.AsyncClient", return_value=async_client):
        router = LlmRouter(backend="ollama")
        result = await router.run(LlmInput(prompt="hi"))
    assert result.content == "ok"
