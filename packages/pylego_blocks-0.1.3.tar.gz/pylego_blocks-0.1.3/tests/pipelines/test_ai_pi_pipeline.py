"""ai-pi 파이프라인 조립 및 실행 테스트."""

from __future__ import annotations

import json
import os

import pytest

_TEST_REPO = os.environ.get("PYLEGO_TEST_REPO", "test-owner/test-repo")

from pylego.pipelines.ai_pi import (
    AiPiPipelineConfig,
    PipelineResult,
    build_ai_pi_pipeline,
    run_ai_pi,
)


class _FakeRunner:
    def __init__(
        self,
        responses: list[tuple[int, str, str]],
        log: list[str],
        prefix: str,
    ) -> None:
        self._responses = list(responses)
        self._log = log
        self._prefix = prefix

    async def __call__(self, args: list[str]) -> tuple[int, str, str]:
        self._log.append(f"{self._prefix}:{' '.join(args)}")
        # #37: 새 커밋 질의는 기본적으로 "1 commit exists" 로 응답 —
        # 대부분 테스트가 "Dev 가 정상 커밋" 을 가정하기 때문. 실패 경로는
        # 전용 sub-runner 로 override.
        if len(args) >= 2 and args[0] == "rev-list" and args[1] == "--count":
            return (0, "1\n", "")
        # #37 R3: `git log --oneline <base>..<feature>` 는 merge 전 empty-diff
        # 가드에 쓰인다. 빈 응답을 내면 빈 diff 로 해석돼 머지가 skip 됨.
        # 기본값으로 가짜 commit 한 줄을 돌려 PASS 경로가 유지되도록 한다.
        if len(args) >= 2 and args[0] == "log" and "--oneline" in args:
            return (0, "abc1234 feat: dummy\n", "")
        if self._responses:
            return self._responses.pop(0)
        return (0, "", "")


class _FakeSender:
    def __init__(self, responses: list[str], log: list[str]) -> None:
        self._responses = list(responses)
        self._log = log
        self.calls: list[tuple[str, str, float]] = []

    async def __call__(self, sock_path: str, message: str, timeout: float) -> str:
        self.calls.append((sock_path, message, timeout))
        self._log.append(f"sock:{sock_path}|{message}|{timeout}")
        if not self._responses:
            return ""
        return self._responses.pop(0)


def _inspect_json(labels: tuple[str, ...]) -> str:
    return json.dumps(
        {
            "number": 8,
            "title": "ai-pi 파이프라인",
            "state": "OPEN",
            "labels": [{"name": label} for label in labels],
        }
    )


def _comments_json(fail_count: int) -> str:
    return json.dumps(
        {"comments": [{"body": "## QA 검증 결과: FAIL"} for _ in range(fail_count)]}
    )


class TestAiPiPipeline:
    async def test_build_pipeline_contract(self) -> None:
        config = AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8)
        pipeline = build_ai_pi_pipeline(config)

        assert pipeline.input_model is AiPiPipelineConfig
        assert pipeline.output_model is PipelineResult

    async def test_pass_flow_merges_and_closes(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner(
            [
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "git",
        )
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: PASS"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="merged",
            fail_count=0,
            verdict="PASS",
        )
        # #37: LabelTransitionBlock 가 remove+add 2 회로 분리. 2 회 전이 × 2 = 4.
        # #39: _PassFinalizeBlock 이 close 전 status:review remove 1회 추가 → 총 5.
        assert sum(entry.startswith("gh:issue edit 8") for entry in log) == 5
        assert any("--remove-label status:review" in entry for entry in log)
        assert any("gh:issue close 8" in entry for entry in log)

    async def test_dev_prompt_expands_for_rework(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(1), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 8, log, "git")
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: PASS"], log)

        await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        dev_prompt = sender.calls[0][1]
        assert len(dev_prompt) >= 500
        assert "재작업 지시 (1차 FAIL 이후 재개)" in dev_prompt
        assert "Bug Issue 번호" in dev_prompt
        assert "@QA 재검증 요청" in dev_prompt
        assert "git add / commit / push" in dev_prompt
        assert "범위 외 문제가 보이면" in dev_prompt

    async def test_pass_but_empty_diff_skips_merge(self) -> None:
        """#37 R3: QA PASS 지만 feature 가 base 대비 빈 diff 면 머지 skip + FAIL 전환."""
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
            ],
            log,
            "gh",
        )

        class _GitEmptyDiff:
            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                log.append(f"git:{' '.join(args)}")
                if len(args) >= 2 and args[0] == "rev-list" and args[1] == "--count":
                    return (0, "1\n", "")   # Dev 는 1 커밋을 남긴 것처럼 보임
                if len(args) >= 2 and args[0] == "log" and "--oneline" in args:
                    return (0, "", "")       # 그러나 base..feature 는 빈 결과 → R3 발동
                return (0, "", "")

        # Dev + QA 모두 정상 응답 (R3 guard 만 발동시키기 위함).
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: PASS"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=_GitEmptyDiff(),
            socket_sender=sender,
        )

        assert result.final_state == "failed"
        assert result.verdict == "FAIL"
        assert any("빈 diff, 머지 skip" in entry for entry in log)
        # merge 나 close 로 이어지는 gh 호출이 없어야 함.
        assert not any("gh:issue close" in entry for entry in log)
        # git merge 도 호출 안 됨.
        assert not any(entry.startswith("git:merge") for entry in log)

    async def test_pass_but_dirty_worktree_skips_merge(self) -> None:
        """#53 Hotfix: QA PASS 지만 merge 직전 working tree dirty → 머지 skip + FAIL 전환.

        Copilot ACP 의 async 쓰기가 Dev 응답 후에도 landing 되어 merge 시점에 working
        tree 가 dirty 인 race 케이스. _DevCommitCheckBlock 은 Dev 직후 clean 을 확인
        했으므로 통과하고, _PassFinalizeBlock 의 신규 dirty guard 가 발동해야 한다.
        """

        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
            ],
            log,
            "gh",
        )

        class _GitDirtyAtMerge:
            def __init__(self) -> None:
                self._status_calls = 0

            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                log.append(f"git:{' '.join(args)}")
                if args[0] == "status" and "--porcelain" in args:
                    self._status_calls += 1
                    if self._status_calls == 1:
                        # Dev 단계: clean → _DevCommitCheckBlock 통과
                        return (0, "", "")
                    # merge 단계: dirty → _PassFinalizeBlock dirty guard 발동
                    return (0, " M src/pylego/testing/contracts.py\n", "")
                if len(args) >= 2 and args[0] == "rev-list" and args[1] == "--count":
                    return (0, "1\n", "")
                if len(args) >= 2 and args[0] == "log" and "--oneline" in args:
                    # dirty guard 가 먼저 발동하므로 여기까지 오지 않아야 하나, 도달할
                    # 경우에도 empty-diff 로 전환되지 않도록 가짜 commit 을 돌려준다.
                    return (0, "abc1234 feat: dummy\n", "")
                return (0, "", "")

        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: PASS"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=_GitDirtyAtMerge(),
            socket_sender=sender,
        )

        assert result.final_state == "failed"
        assert result.verdict == "FAIL"
        assert result.fail_count == 1
        assert any("merge 직전 dirty working tree" in entry for entry in log)
        assert any("#53 Hotfix" in entry for entry in log)
        # empty-diff 가드까지는 도달하지 않아야 한다 (dirty guard 가 먼저).
        assert not any("빈 diff, 머지 skip" in entry for entry in log)
        # merge/close 로 이어지는 git/gh 호출이 없어야 한다.
        assert not any(entry.startswith("git:merge") for entry in log)
        assert not any("gh:issue close" in entry for entry in log)

    async def test_dev_no_commits_short_circuits_to_fail(self) -> None:
        """#37 R2: Dev 가 성공 응답했지만 새 커밋 0개면 즉시 FAIL."""
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
            ],
            log,
            "gh",
        )

        # git runner: rev-list --count 만 "0" 반환, 나머지는 정상.
        class _GitNoCommits:
            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                log.append(f"git:{' '.join(args)}")
                if len(args) >= 2 and args[0] == "rev-list" and args[1] == "--count":
                    return (0, "0\n", "")
                return (0, "", "")

        sender = _FakeSender(["dev returned ok but did nothing"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=_GitNoCommits(),
            socket_sender=sender,
        )

        assert result.final_state == "failed"
        assert result.verdict == "FAIL"
        assert result.fail_count == 1
        assert any("새 커밋 없음" in entry for entry in log)
        # QA 는 호출되지 않았어야 함.
        assert len(sender.calls) == 1

    async def test_dev_dirty_worktree_short_circuits_to_fail(self) -> None:
        """#37 R2: Dev 가 커밋 안 하고 파일만 수정 → dirty tree → FAIL."""
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
            ],
            log,
            "gh",
        )

        class _GitDirty:
            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                log.append(f"git:{' '.join(args)}")
                if args[0] == "status" and "--porcelain" in args:
                    return (0, " M src/pylego/foo.py\n?? new.py\n", "")
                if len(args) >= 2 and args[0] == "rev-list" and args[1] == "--count":
                    return (0, "0\n", "")
                return (0, "", "")

        sender = _FakeSender(["dev left files uncommitted"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=_GitDirty(),
            socket_sender=sender,
        )

        assert result.final_state == "failed"
        assert result.verdict == "FAIL"
        assert any("커밋 누락" in entry for entry in log)
        # dirty 가 "새 커밋 없음" 보다 우선이므로 후자 메시지는 없어야 함.
        assert not any("새 커밋 없음" in entry for entry in log)

    async def test_dev_daemon_error_short_circuits_to_fail(self) -> None:
        """#35: Dev daemon 이 'ERROR: ...' 응답 → FAIL 즉시 확정, QA 호출 skip."""
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),   # status:ready → in-progress
                (0, "", ""),   # Dev FAIL 댓글
                (0, "", ""),   # status:in-progress → review (여전히 진행)
                (0, "", ""),   # FAIL 1차: status:review → in-progress
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 5, log, "git")
        # Dev 응답이 ERROR 이면 AcpPromptBlock 이 AcpDaemonError 를 raise → _DevPromptBlock
        # 이 catch. QA sender 호출이 없어야 하므로 qa 응답은 넣지 않음.
        sender = _FakeSender(["ERROR: Prompt timeout"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        assert result.final_state == "failed"
        assert result.verdict == "FAIL"
        assert result.fail_count == 1
        # sender 는 Dev 한 번만 호출됐어야 함 (QA skip)
        assert len(sender.calls) == 1
        assert sender.calls[0][0].endswith("copilot-acp.sock")
        # Dev FAIL 자동 판정 댓글이 달렸는지
        assert any("Dev daemon 실패" in entry for entry in log)

    async def test_first_fail_returns_to_in_progress(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner(
            [
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "git",
        )
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: FAIL"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="failed",
            fail_count=1,
            verdict="FAIL",
        )
        # #37: remove+add 분리로 3 회 전이 × 2 = 6.
        assert sum(entry.startswith("gh:issue edit 8") for entry in log) == 6
        assert any("status:in-progress" in entry for entry in log)
        assert not any("status:blocked" in entry for entry in log)
        assert not any("Architect 리뷰 요청" in entry for entry in log)

    async def test_third_fail_escalates_and_blocks(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(2), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner(
            [
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "git",
        )
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: FAIL"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="escalated",
            fail_count=3,
            verdict="FAIL",
        )
        # #37: remove+add 분리로 3 회 전이 × 2 = 6.
        assert sum(entry.startswith("gh:issue edit 8") for entry in log) == 6
        assert any("status:blocked" in entry for entry in log)
        assert any("3차 누적 FAIL" in entry for entry in log)

    async def test_hotfix_fail_escalates_without_label_change(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:hotfix")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner(
            [
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "git",
        )
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: FAIL"], log)

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="escalated",
            fail_count=1,
            verdict="FAIL",
        )
        # #37: Hotfix 는 FAIL 시 라벨 전이 없음. ready→in-progress, in-progress→review 2 회 × 2 = 4.
        assert sum(entry.startswith("gh:issue edit 8") for entry in log) == 4
        assert not any("status:blocked" in entry for entry in log)
        assert any("Hotfix FAIL 전략 결정 필요" in entry for entry in log)

    async def test_qa_prompt_marks_hotfix_gate_b_exception(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:hotfix")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 5, log, "git")
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: FAIL"], log)

        await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
        )

        qa_prompt = sender.calls[1][1]
        assert len(qa_prompt) >= 500
        assert "Hotfix 이슈입니다. Gate B(프로젝트 전역 위반 검사)는 면제" in qa_prompt
        assert "§8 PASS/FAIL 템플릿" in qa_prompt
        assert "VERDICT: PASS" in qa_prompt
        assert "VERDICT: FAIL" in qa_prompt

    async def test_auto_verdict_fallback_turns_unknown_into_pass(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("PYLEGO_AUTO_VERDICT_CMD", "python -m pytest -q --tb=short")
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 8, log, "git")
        sender = _FakeSender(["dev ok", "qa ok"], log)
        auto_runner = _FakeRunner([(0, "tests passed", "")], log, "auto")

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
            auto_verdict_runner=auto_runner,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="merged",
            fail_count=0,
            verdict="PASS",
        )
        assert any("auto:python -m pytest -q --tb=short" in entry for entry in log)
        assert any("QA 검증 결과: PASS (자동 판정)" in entry for entry in log)

    async def test_auto_verdict_fallback_turns_unknown_into_fail(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 5, log, "git")
        sender = _FakeSender(["dev ok", "qa ok"], log)
        auto_runner = _FakeRunner([(1, "", "tests failed")], log, "auto")

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
            auto_verdict_runner=auto_runner,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="failed",
            fail_count=1,
            verdict="FAIL",
        )
        assert any("QA 검증 결과: FAIL (자동 판정)" in entry for entry in log)
        assert any("status:in-progress" in entry for entry in log)

    async def test_auto_verdict_skips_when_verdict_known(self) -> None:
        log: list[str] = []
        gh = _FakeRunner(
            [
                (0, _inspect_json(("status:ready", "type:feature")), ""),
                (0, _comments_json(0), ""),
                (0, "", ""),
                (0, "", ""),
                (0, "", ""),
            ],
            log,
            "gh",
        )
        git = _FakeRunner([(0, "", "")] * 8, log, "git")
        sender = _FakeSender(["dev ok", "qa ok\nVERDICT: PASS"], log)
        auto_runner = _FakeRunner([(0, "should not run", "")], log, "auto")

        result = await run_ai_pi(
            AiPiPipelineConfig(repo=_TEST_REPO, issue_number=8),
            gh_runner=gh,
            git_runner=git,
            socket_sender=sender,
            auto_verdict_runner=auto_runner,
        )

        assert result == PipelineResult(
            issue_number=8,
            final_state="merged",
            fail_count=0,
            verdict="PASS",
        )
        assert not any(entry.startswith("auto:") for entry in log)
