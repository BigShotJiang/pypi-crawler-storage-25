"""Unit.SemanticRetryPolicy + enrich() 생명주기 테스트."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from pylego.core.stud import Stud
from pylego.unit import (
    ResultUnit,
    SemanticRetryPolicy,
    Unit,
    UnitPipeline,
    UnitResult,
)


# ── fixtures ────────────────────────────────────────────────────────────────

class _Req(Stud):
    value: int
    context: str = ""


class _Res(Stud):
    output: str


class _PassthroughResult(ResultUnit):
    async def on_success(self, result: Any) -> UnitResult:
        return UnitResult(status="success", result=result)

    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)


# ── SemanticRetryPolicy 기본값 검증 ──────────────────────────────────────────

def test_policy_default_values() -> None:
    p = SemanticRetryPolicy()
    assert p.max_attempts == 3
    assert p.retry_on_verify_failure is True


def test_policy_custom_values() -> None:
    p = SemanticRetryPolicy(max_attempts=5, retry_on_verify_failure=False)
    assert p.max_attempts == 5
    assert p.retry_on_verify_failure is False


def test_policy_rejects_zero_max_attempts() -> None:
    with pytest.raises(ValueError, match="1 이상"):
        SemanticRetryPolicy(max_attempts=0)


# ── 재시도 없는 정상 흐름 ────────────────────────────────────────────────────

class _SimpleUnit(Unit[_Req]):
    input_model = _Req

    async def run(self, inp: _Req) -> _Res:
        return _Res(output=f"ok:{inp.value}")


async def test_no_retry_policy_success() -> None:
    unit = _SimpleUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "success"
    assert result.result == _Res(output="ok:1")


# ── verify 실패 → retry_policy 없으면 즉시 failure ───────────────────────────

class _VerifyAlwaysFailUnit(Unit[_Req]):
    input_model = _Req

    async def run(self, inp: _Req) -> _Res:
        return _Res(output="bad")

    async def verify(self, inp: _Req, result: _Res) -> None:  # type: ignore[override]
        raise ValueError("항상 실패")


async def test_verify_failure_no_policy_returns_failure() -> None:
    unit = _VerifyAlwaysFailUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "failure"
    assert result.failed_at == "_VerifyAlwaysFailUnit"
    assert "verify" in (result.reason or "")


# ── retry_policy: max_attempts 재시도 횟수 확인 ───────────────────────────────

class _CountingUnit(Unit[_Req]):
    """run() 호출 횟수를 기록하고, max_calls 이후부터 verify 통과."""

    input_model = _Req
    retry_policy = SemanticRetryPolicy(max_attempts=3)

    def __init__(self, pass_on_attempt: int = 3) -> None:
        self.calls: list[int] = []
        self._pass_on = pass_on_attempt
        self._attempt = 0

    async def run(self, inp: _Req) -> _Res:
        self._attempt += 1
        self.calls.append(self._attempt)
        return _Res(output=f"attempt:{self._attempt}")

    async def verify(self, inp: _Req, result: _Res) -> None:  # type: ignore[override]
        attempt_num = int(result.output.split(":")[1])
        if attempt_num < self._pass_on:
            raise ValueError(f"시도 {attempt_num} 실패")


async def test_retries_until_verify_passes() -> None:
    unit = _CountingUnit(pass_on_attempt=2)
    result = await unit.execute(_Req(value=1))
    assert result.status == "success"
    assert unit.calls == [1, 2]


async def test_retries_exhausted_returns_failure() -> None:
    unit = _CountingUnit(pass_on_attempt=99)
    result = await unit.execute(_Req(value=1))
    assert result.status == "failure"
    assert unit.calls == [1, 2, 3]


async def test_succeeds_first_attempt_no_extra_runs() -> None:
    unit = _CountingUnit(pass_on_attempt=1)
    result = await unit.execute(_Req(value=1))
    assert result.status == "success"
    assert unit.calls == [1]


# ── enrich(): 컨텍스트 주입 확인 ────────────────────────────────────────────

class _EnrichUnit(Unit[_Req]):
    """verify 실패 시 enrich()가 context 필드에 오류를 기록."""

    input_model = _Req
    retry_policy = SemanticRetryPolicy(max_attempts=3)

    def __init__(self) -> None:
        self.inputs_received: list[str] = []

    async def run(self, inp: _Req) -> _Res:
        self.inputs_received.append(inp.context)
        if not inp.context:
            return _Res(output="unverified")
        return _Res(output="verified")

    async def verify(self, inp: _Req, result: _Res) -> None:  # type: ignore[override]
        if result.output != "verified":
            raise ValueError("출력 검증 실패")

    async def enrich(self, inp: _Req, result: _Res, error: str) -> _Req:  # type: ignore[override]
        return inp.model_copy(update={"context": f"이전 오류: {error}"})


async def test_enrich_injects_context_on_retry() -> None:
    unit = _EnrichUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "success"
    assert unit.inputs_received[0] == ""
    assert "이전 오류" in unit.inputs_received[1]


# ── retry_on_verify_failure=False — 재시도 비활성화 ─────────────────────────

class _NoRetryOnVerifyUnit(Unit[_Req]):
    input_model = _Req
    retry_policy = SemanticRetryPolicy(max_attempts=3, retry_on_verify_failure=False)

    def __init__(self) -> None:
        self.calls: int = 0

    async def run(self, inp: _Req) -> _Res:
        self.calls += 1
        return _Res(output="bad")

    async def verify(self, inp: _Req, result: _Res) -> None:  # type: ignore[override]
        raise ValueError("검증 실패")


async def test_retry_on_verify_failure_false_does_not_retry() -> None:
    unit = _NoRetryOnVerifyUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "failure"
    assert unit.calls == 1


# ── run() 예외는 재시도 없이 즉시 failure ────────────────────────────────────

class _RunFailsUnit(Unit[_Req]):
    input_model = _Req
    retry_policy = SemanticRetryPolicy(max_attempts=3)

    def __init__(self) -> None:
        self.calls: int = 0

    async def run(self, inp: _Req) -> _Res:
        self.calls += 1
        raise RuntimeError("run 예외")


async def test_run_exception_no_retry() -> None:
    unit = _RunFailsUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "failure"
    assert unit.calls == 1
    assert "run 예외" in (result.reason or "")


# ── validate() 실패는 재시도 없이 즉시 failure ───────────────────────────────

class _ValidateFailRetryUnit(Unit[_Req]):
    input_model = _Req
    retry_policy = SemanticRetryPolicy(max_attempts=3)

    def __init__(self) -> None:
        self.run_calls: int = 0

    async def validate(self, inp: _Req) -> None:
        raise ValueError("validate 실패")

    async def run(self, inp: _Req) -> _Res:
        self.run_calls += 1
        return _Res(output="ok")


async def test_validate_failure_skips_retry() -> None:
    unit = _ValidateFailRetryUnit()
    result = await unit.execute(_Req(value=1))
    assert result.status == "failure"
    assert unit.run_calls == 0
    assert "validate" in (result.reason or "")


# ── UnitPipeline 에서 재시도 투명 지원 ──────────────────────────────────────

async def test_pipeline_with_retry_unit() -> None:
    unit = _CountingUnit(pass_on_attempt=2)
    pipeline = UnitPipeline([unit], result_unit=_PassthroughResult())
    result = await pipeline.run(_Req(value=1))
    assert result.status == "success"
    assert unit.calls == [1, 2]


# ── SemanticRetryPolicy 공개 API 노출 확인 ──────────────────────────────────

def test_semantic_retry_policy_importable_from_pylego() -> None:
    from pylego import SemanticRetryPolicy as SRP  # noqa: PLC0415
    assert SRP is SemanticRetryPolicy
