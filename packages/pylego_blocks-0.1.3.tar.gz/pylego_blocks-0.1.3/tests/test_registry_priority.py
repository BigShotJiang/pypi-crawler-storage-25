"""M111 — Priority-weighted Severity 테스트."""

from __future__ import annotations

import math

import pytest

from pylego import Block, Stud
from pylego.registry import BlockRegistry, BlockRuntimeStat, RegistryPolicy


class _In(Stud):
    x: int


class _Out(Stud):
    y: int


class _A(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


class _B(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


# ── priority 기본값 ───────────────────────────────────────────────────────────


def test_priority_defaults_to_one() -> None:
    """priority 미지정 시 1.0이 적용된다 — priority_adjusted_risk == weighted_failure_sum."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.6)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.priority_adjusted_risk == pytest.approx(0.6)
    assert info.runtime.priority_adjusted_risk == pytest.approx(info.runtime.weighted_failure_sum)


def test_priority_from_policy_map() -> None:
    """block_priority_map 에서 우선순위를 추론한다."""
    policy = RegistryPolicy(block_priority_map={"_A": 2.0})
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.5)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.priority_adjusted_risk == pytest.approx(1.0)  # 0.5 × 2.0


def test_explicit_priority_overrides_map() -> None:
    """명시적 priority 가 block_priority_map 보다 우선한다."""
    policy = RegistryPolicy(block_priority_map={"_A": 2.0})
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.5, priority=0.5)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.priority_adjusted_risk == pytest.approx(0.25)  # 0.5 × 0.5


def test_priority_adjusted_risk_accumulates() -> None:
    """여러 실패가 누적된다."""
    policy = RegistryPolicy(block_priority_map={"_A": 3.0})
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    for _ in range(3):
        reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.4)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.priority_adjusted_risk == pytest.approx(3.6)  # 3 × 0.4 × 3.0


def test_priority_no_accumulation_on_success() -> None:
    """성공 시 priority_adjusted_risk 는 갱신되지 않는다."""
    policy = RegistryPolicy(block_priority_map={"_A": 5.0})
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.update_stat("_A", success=True, elapsed_sec=0.1)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.priority_adjusted_risk == pytest.approx(0.0)


# ── cumulative_risk_threshold 경보 ────────────────────────────────────────────


def test_cumulative_risk_threshold_triggers_first_time() -> None:
    """임계값 초과 즉시 경보가 발생한다."""
    alerts: list[tuple[str, float]] = []
    policy = RegistryPolicy(
        block_priority_map={"_A": 2.0},
        cumulative_risk_threshold=1.0,
    )
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.set_risk_alert(lambda name, risk: alerts.append((name, risk)))
    reg.register(_A)

    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.6)
    assert len(alerts) == 1
    assert alerts[0][0] == "_A"
    assert alerts[0][1] == pytest.approx(1.2)


def test_cumulative_risk_no_alert_below_threshold() -> None:
    """임계값 이하이면 경보 없음."""
    alerts: list[str] = []
    policy = RegistryPolicy(
        block_priority_map={"_A": 1.0},
        cumulative_risk_threshold=5.0,
    )
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.set_risk_alert(lambda name, _: alerts.append(name))
    reg.register(_A)

    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.3)
    assert alerts == []


def test_alert_not_triggered_on_success() -> None:
    """성공 시 경보가 발생하지 않는다."""
    alerts: list[str] = []
    policy = RegistryPolicy(cumulative_risk_threshold=0.0)
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.set_risk_alert(lambda name, _: alerts.append(name))
    reg.register(_A)

    reg.update_stat("_A", success=True, elapsed_sec=0.1)
    assert alerts == []


def test_no_alert_without_callback() -> None:
    """set_risk_alert 미설정 시 threshold 초과해도 에러 없음."""
    policy = RegistryPolicy(
        block_priority_map={"_A": 10.0},
        cumulative_risk_threshold=0.1,
    )
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=1.0)  # 에러 없어야 함


# ── risk_adjusted_confidence 우선순위 반영 ────────────────────────────────────


def test_risk_adjusted_confidence_with_high_priority() -> None:
    """높은 우선순위 블록은 동일 실패에서 낮은 신뢰도를 갖는다."""
    reg_low = BlockRegistry()
    reg_low.register(_A)
    reg_high = BlockRegistry()
    reg_high.set_policy(RegistryPolicy(block_priority_map={"_A": 3.0}))
    reg_high.register(_A)

    for reg in (reg_low, reg_high):
        for _ in range(10):
            reg.update_stat("_A", success=True, elapsed_sec=0.1)
        reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.5)

    low_conf = reg_low.describe("_A").runtime
    high_conf = reg_high.describe("_A").runtime
    assert low_conf is not None and high_conf is not None
    assert high_conf.risk_adjusted_confidence < low_conf.risk_adjusted_confidence


def test_risk_adjusted_confidence_no_failure() -> None:
    """실패 없으면 risk_adjusted_confidence == confidence."""
    reg = BlockRegistry()
    reg.register(_A)
    for _ in range(10):
        reg.update_stat("_A", success=True, elapsed_sec=0.1)

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.risk_adjusted_confidence == pytest.approx(info.runtime.confidence)


def test_high_priority_block_penalized_more() -> None:
    """priority=2.0 블록은 priority=1.0 블록보다 ucb_score가 낮다."""
    reg1 = BlockRegistry()
    reg1.register(_A)

    reg2 = BlockRegistry()
    reg2.set_policy(RegistryPolicy(block_priority_map={"_A": 2.0}))
    reg2.register(_A)

    for reg in (reg1, reg2):
        for _ in range(10):
            reg.update_stat("_A", success=True, elapsed_sec=0.1)
        reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.8)

    score1 = reg1.describe("_A").runtime
    score2 = reg2.describe("_A").runtime
    assert score1 is not None and score2 is not None
    assert score2.ucb_score < score1.ucb_score


def test_low_priority_block_penalized_less() -> None:
    """priority=0.5 블록은 priority=1.0 블록보다 ucb_score가 높다."""
    reg1 = BlockRegistry()
    reg1.register(_A)

    reg2 = BlockRegistry()
    reg2.set_policy(RegistryPolicy(block_priority_map={"_A": 0.5}))
    reg2.register(_A)

    for reg in (reg1, reg2):
        for _ in range(10):
            reg.update_stat("_A", success=True, elapsed_sec=0.1)
        reg.update_stat("_A", success=False, elapsed_sec=0.1, severity=0.8)

    score1 = reg1.describe("_A").runtime
    score2 = reg2.describe("_A").runtime
    assert score1 is not None and score2 is not None
    assert score2.ucb_score > score1.ucb_score
