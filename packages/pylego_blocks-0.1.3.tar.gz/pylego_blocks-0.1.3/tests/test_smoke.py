"""패키지 로드·버전 확인 스모크 테스트."""

from __future__ import annotations

import pylego


def test_package_importable() -> None:
    assert pylego is not None


def test_version_is_string() -> None:
    assert isinstance(pylego.__version__, str)
    assert len(pylego.__version__) > 0
