"""Contract tests marked with @pytest.mark.pylego_contracts.

These are minimal runtime contract checks that call the async
`assert_block_contract` helper exported by pylego.testing.contracts.
"""

from __future__ import annotations

import json
import pytest

from pylego.testing.contracts import assert_block_contract

# Blocks under test
from pylego.blocks.ai.verdict import VerdictParseBlock, VerdictParseRequest
from pylego.blocks.ai.acp import AcpPromptBlock, AcpPromptRequest
from pylego.blocks.github.issue import IssueInspectBlock, IssueRef
from pylego.blocks.git.branch import BranchPrepareBlock, BranchSpec
from pylego.blocks.git.merge import MergeToMainBlock, MergeRequest


@pytest.mark.pylego_contracts
@pytest.mark.asyncio
async def test_verdict_parse_block_contract() -> None:
    block = VerdictParseBlock()
    sample = VerdictParseRequest(text="line\nVERDICT: PASS")
    res = await assert_block_contract(VerdictParseBlock, sample_input=sample, block=block)
    assert res.ok, res.reason


@pytest.mark.pylego_contracts
@pytest.mark.asyncio
async def test_acp_prompt_block_contract() -> None:
    async def _fake_sender(path: str, message: str, timeout: float) -> str:
        return "OK RESPONSE"

    block = AcpPromptBlock(sender=_fake_sender)
    sample = AcpPromptRequest(socket_path="/tmp/fake", prompt="hi", timeout_sec=1.0)
    res = await assert_block_contract(AcpPromptBlock, sample_input=sample, block=block)
    assert res.ok, res.reason


@pytest.mark.pylego_contracts
@pytest.mark.asyncio
async def test_issue_inspect_block_contract() -> None:
    async def _fake_gh(args: list[str]) -> tuple[int, str, str]:
        payload = {"number": 1, "title": "t", "state": "OPEN", "labels": [{"name": "a"}]}
        return 0, json.dumps(payload), ""

    block = IssueInspectBlock(gh_runner=_fake_gh)
    sample = IssueRef(repo="owner/repo", number=1)
    res = await assert_block_contract(IssueInspectBlock, sample_input=sample, block=block)
    assert res.ok, res.reason


@pytest.mark.pylego_contracts
@pytest.mark.asyncio
async def test_branch_prepare_block_contract() -> None:
    async def _fake_git(args: list[str]) -> tuple[int, str, str]:
        # simulate: show-ref not found -> create branch path
        if args and args[0] == "show-ref":
            return 1, "", ""
        return 0, "", ""

    block = BranchPrepareBlock(git_runner=_fake_git)
    sample = BranchSpec(base_branch="main", feature_branch="feature/x", push_origin=False)
    res = await assert_block_contract(BranchPrepareBlock, sample_input=sample, block=block)
    assert res.ok, res.reason


@pytest.mark.pylego_contracts
@pytest.mark.asyncio
async def test_merge_to_main_block_contract() -> None:
    async def _fake_git(args: list[str]) -> tuple[int, str, str]:
        # status -> return clean tree (empty stdout)
        if args == ["status", "--porcelain"]:
            return 0, "", ""
        return 0, "", ""

    block = MergeToMainBlock(git_runner=_fake_git)
    sample = MergeRequest(base_branch="main", feature_branch="feature/x", message="merge")
    res = await assert_block_contract(MergeToMainBlock, sample_input=sample, block=block)
    assert res.ok, res.reason
