"""OpenAiBlock 단위 테스트 — openai SDK 를 sys.modules mock 으로 대체."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego import OpenAiBlock, OpenAiInput, OpenAiResult


def _make_completion(text: str, model: str = "gpt-4o") -> MagicMock:
    choice = MagicMock()
    choice.message.content = text
    choice.finish_reason = "stop"
    usage = MagicMock()
    usage.prompt_tokens = 8
    usage.completion_tokens = 16
    resp = MagicMock()
    resp.choices = [choice]
    resp.model = model
    resp.usage = usage
    return resp


@pytest.fixture()
def mock_client() -> Any:
    """openai SDK 를 sys.modules 에서 mock 으로 교체 (lazy import 대응)."""
    module = MagicMock()
    client = AsyncMock()
    module.AsyncOpenAI.return_value = client
    client.chat.completions.create = AsyncMock(return_value=_make_completion("Hello!"))
    with patch.dict("sys.modules", {"openai": module}):
        yield client


async def test_basic_call(mock_client: Any) -> None:
    block = OpenAiBlock(api_key="test-key")
    result = await block.run(
        OpenAiInput(
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=32,
        )
    )
    assert isinstance(result, OpenAiResult)
    assert result.content == "Hello!"
    assert result.finish_reason == "stop"
    assert result.prompt_tokens == 8
    assert result.completion_tokens == 16


async def test_system_prepended(mock_client: Any) -> None:
    block = OpenAiBlock(api_key="test-key")
    await block.run(
        OpenAiInput(
            messages=[{"role": "user", "content": "hi"}],
            system="Be concise.",
        )
    )
    call_kwargs: dict[str, Any] = mock_client.chat.completions.create.call_args.kwargs
    messages: list[dict[str, str]] = call_kwargs["messages"]
    assert messages[0] == {"role": "system", "content": "Be concise."}
    assert messages[1] == {"role": "user", "content": "hi"}


async def test_no_system_when_not_set(mock_client: Any) -> None:
    block = OpenAiBlock(api_key="test-key")
    await block.run(OpenAiInput(messages=[{"role": "user", "content": "hi"}]))
    call_kwargs: dict[str, Any] = mock_client.chat.completions.create.call_args.kwargs
    messages: list[dict[str, Any]] = call_kwargs["messages"]
    assert all(m.get("role") != "system" for m in messages)


async def test_import_error_without_package() -> None:
    with patch.dict("sys.modules", {"openai": None}):  # type: ignore[dict-item]
        block = OpenAiBlock(api_key="x")
        with pytest.raises(ImportError, match="pylego\\[openai\\]"):
            await block.run(OpenAiInput(messages=[], max_tokens=1))
