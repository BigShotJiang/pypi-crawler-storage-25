"""M93 — BlockRegistry 런타임 통계 통합 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego import Assembly, Block, Stud, observe
from pylego.core.events import CollectingEventBus
from pylego.registry import BlockRegistry, BlockRuntimeStat


# ── 픽스처용 더미 Stud / Block ───────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("boom")


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────


def _reg() -> BlockRegistry:
    r = BlockRegistry()
    r.register(_OkBlock, tags=["ok"], description="ok block")
    r.register(_FailBlock, tags=["fail"], description="fail block")
    return r


# ── 초기 상태 ────────────────────────────────────────────────────────────────


def test_initial_runtime_is_none() -> None:
    r = _reg()
    assert r.describe("_OkBlock").runtime is None
    assert r.describe("_FailBlock").runtime is None


# ── update_stat ───────────────────────────────────────────────────────────────


def test_update_stat_success() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=True, elapsed_sec=1.0)
    stat = r.describe("_OkBlock").runtime
    assert stat is not None
    assert stat.success_count == 1
    assert stat.failure_count == 0
    assert stat.avg_elapsed_sec == pytest.approx(1.0)
    assert stat.last_error is None


def test_update_stat_failure() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=False, elapsed_sec=0.5, error="oops")
    stat = r.describe("_OkBlock").runtime
    assert stat is not None
    assert stat.success_count == 0
    assert stat.failure_count == 1
    assert stat.last_error == "oops"


def test_update_stat_accumulation() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=True, elapsed_sec=1.0)
    r.update_stat("_OkBlock", success=True, elapsed_sec=3.0)
    r.update_stat("_OkBlock", success=False, elapsed_sec=2.0, error="err")
    stat = r.describe("_OkBlock").runtime
    assert stat is not None
    assert stat.success_count == 2
    assert stat.failure_count == 1
    assert stat.avg_elapsed_sec == pytest.approx(2.0)
    assert stat.last_error == "err"
    assert stat.success_rate == pytest.approx(2 / 3)


def test_update_stat_unknown_block_ignored() -> None:
    r = _reg()
    r.update_stat("NoSuchBlock", success=True, elapsed_sec=1.0)  # must not raise


def test_success_rate_zero_when_no_events() -> None:
    stat = BlockRuntimeStat()
    assert stat.success_rate == 0.0


# ── ingest_events ─────────────────────────────────────────────────────────────


async def test_ingest_events_ok_block() -> None:
    r = _reg()
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
    with observe(bus):
        await pipeline.run(_In(v=1))
    r.ingest_events(bus.events)
    stat = r.describe("_OkBlock").runtime
    assert stat is not None
    assert stat.success_count == 1
    assert stat.failure_count == 0


async def test_ingest_events_fail_block() -> None:
    r = _reg()
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(v=1))
        except RuntimeError:
            pass
    r.ingest_events(bus.events)
    stat = r.describe("_FailBlock").runtime
    assert stat is not None
    assert stat.failure_count == 1
    assert stat.last_error == "boom"


async def test_ingest_events_multiple_runs() -> None:
    r = _reg()
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
    with observe(bus):
        for _ in range(3):
            await pipeline.run(_In(v=1))
    r.ingest_events(bus.events)
    stat = r.describe("_OkBlock").runtime
    assert stat is not None
    assert stat.success_count == 3


# ── search sort_by ────────────────────────────────────────────────────────────


def test_search_sort_by_success_rate() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=True, elapsed_sec=1.0)
    r.update_stat("_OkBlock", success=True, elapsed_sec=1.0)
    r.update_stat("_FailBlock", success=True, elapsed_sec=1.0)
    r.update_stat("_FailBlock", success=False, elapsed_sec=1.0)

    results = r.search("Block", sort_by="success_rate")
    assert results[0].name == "_OkBlock"   # 1.0 > 0.5
    assert results[1].name == "_FailBlock"


def test_search_sort_by_latency() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=True, elapsed_sec=2.0)
    r.update_stat("_FailBlock", success=True, elapsed_sec=0.5)

    results = r.search("Block", sort_by="latency")
    assert results[0].name == "_FailBlock"  # 0.5 < 2.0
    assert results[1].name == "_OkBlock"


def test_search_sort_by_none_is_name_order() -> None:
    r = _reg()
    results = r.search("Block")
    names = [i.name for i in results]
    assert names == sorted(names)


def test_search_sort_by_success_rate_no_runtime_last() -> None:
    r = _reg()
    r.update_stat("_OkBlock", success=True, elapsed_sec=1.0)
    # _FailBlock has no runtime → success_rate treated as 0.0
    results = r.search("Block", sort_by="success_rate")
    assert results[0].name == "_OkBlock"
