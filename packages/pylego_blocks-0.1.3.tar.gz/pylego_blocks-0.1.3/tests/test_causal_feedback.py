"""M129 — Causal Feedback API 테스트 (설계 원칙 58)."""

from __future__ import annotations

import pytest

from pylego.ops.causal import CausalFactor
from pylego.ops.diff import HealthDiff


def _factor(name: str, score: float = 0.7) -> CausalFactor:
    return CausalFactor(source="code", name=name, confidence_score=score)


def _diff(*factors: CausalFactor) -> HealthDiff:
    diff = HealthDiff()
    diff.causal_factors = list(factors)
    return diff


# 1. apply_feedback()가 CausalFactor.feedback_delta를 갱신한다
def test_apply_feedback_updates_delta() -> None:
    diff = _diff(_factor("BlockA", 0.7))
    diff.apply_feedback("BlockA", delta=-0.2)
    assert diff.causal_factors[0].feedback_delta == pytest.approx(-0.2)


# 2. adjusted_confidence = confidence_score + feedback_delta
def test_adjusted_confidence_calculation() -> None:
    f = _factor("BlockA", 0.6)
    f.feedback_delta = 0.2
    assert f.adjusted_confidence == pytest.approx(0.8)


# 3. adjusted_confidence는 0.0~1.0 범위를 벗어나지 않는다
def test_adjusted_confidence_clamped() -> None:
    f = _factor("BlockA", 0.9)
    f.feedback_delta = 0.5   # 1.4 → 클램핑 → 1.0
    assert f.adjusted_confidence == pytest.approx(1.0)

    f2 = _factor("BlockB", 0.2)
    f2.feedback_delta = -0.5  # -0.3 → 클램핑 → 0.0
    assert f2.adjusted_confidence == pytest.approx(0.0)


# 4. feedback_log에 감사 이력이 추가된다
def test_feedback_log_appended() -> None:
    diff = _diff(_factor("BlockA"))
    diff.apply_feedback("BlockA", delta=0.1, source="human", reason="테스트")
    assert len(diff.feedback_log) == 1
    entry = diff.feedback_log[0]
    assert entry["factor_name"] == "BlockA"
    assert entry["delta"] == pytest.approx(0.1)
    assert entry["reason"] == "테스트"


# 5. source 파라미터가 feedback_log에 기록된다
def test_feedback_log_source_recorded() -> None:
    diff = _diff(_factor("BlockA"))
    diff.apply_feedback("BlockA", delta=0.1, source="ai")
    assert diff.feedback_log[0]["source"] == "ai"
    assert diff.causal_factors[0].feedback_source == "ai"


# 6. 동일 요인에 여러 번 피드백 적용 시 feedback_delta가 누적된다
def test_feedback_delta_accumulated() -> None:
    diff = _diff(_factor("BlockA", 0.5))
    diff.apply_feedback("BlockA", delta=0.1)
    diff.apply_feedback("BlockA", delta=0.1)
    diff.apply_feedback("BlockA", delta=-0.05)
    assert diff.causal_factors[0].feedback_delta == pytest.approx(0.15)
    assert len(diff.feedback_log) == 3


# 7. apply_feedback()에 없는 factor_name 지정 시 KeyError
def test_apply_feedback_unknown_factor_raises() -> None:
    diff = _diff(_factor("BlockA"))
    with pytest.raises(KeyError):
        diff.apply_feedback("NoSuchBlock", delta=0.1)


# 8. to_ai_summary()에서 adjusted_confidence 기준으로 요인이 재정렬된다
def test_to_ai_summary_sorted_by_adjusted_confidence() -> None:
    from pylego.ops.health import PipelineHealth

    fa = _factor("BlockA", 0.9)  # adjusted = 0.9 (피드백 없음)
    fb = _factor("BlockB", 0.5)  # adjusted = 0.5 + 0.4 = 0.9 → 동점, 원점수 낮음
    fb.feedback_delta = 0.4
    fc = _factor("BlockC", 0.3)  # adjusted = 0.3

    diff = _diff(fa, fb, fc)

    health = PipelineHealth(
        overall="ok", total_blocks=3,
        error_blocks=[], slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
    )
    summary = health.to_ai_summary(diff=diff)

    # [인과 후보 목록] 이후 행 순서 확인
    lines = summary.splitlines()
    list_start = next(i for i, l in enumerate(lines) if "[인과 후보 목록]" in l)
    factor_lines = [l for l in lines[list_start + 1:] if l.strip().startswith("[")]
    # BlockA(0.9), BlockB(0.9→adjusted 0.9), BlockC(0.3) — BlockC가 마지막
    assert "BlockC" in factor_lines[-1]


# 9. feedback_delta != 0인 요인에 "[피드백 반영]" 레이블이 표시된다
def test_to_ai_summary_feedback_label() -> None:
    from pylego.ops.health import PipelineHealth

    fa = _factor("BlockA", 0.7)
    fa.feedback_delta = -0.2

    diff = _diff(fa)
    health = PipelineHealth(
        overall="ok", total_blocks=1,
        error_blocks=[], slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
    )
    summary = health.to_ai_summary(diff=diff)

    assert "[피드백 반영: -0.20]" in summary


# 10. apply_feedback(delta=0.0)은 feedback_log에 이력을 남기지 않는다
def test_apply_feedback_zero_delta_no_log() -> None:
    diff = _diff(_factor("BlockA"))
    diff.apply_feedback("BlockA", delta=0.0)
    assert len(diff.feedback_log) == 0
    assert diff.causal_factors[0].feedback_delta == pytest.approx(0.0)
