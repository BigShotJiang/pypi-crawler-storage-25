"""선언형 Assembly 로더 테스트."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest
import yaml

from pylego.core.assembly import IncompatibleSnapError
from pylego.declarative import load_assembly
from pylego.registry import BlockRegistry

_ECHO = "tests.fixtures.sample_blocks.EchoBlock"
_LEN = "tests.fixtures.sample_blocks.LengthBlock"


def _yaml_file(tmp_path: Path, data: object, name: str = "asm.yml") -> Path:
    p = tmp_path / name
    p.write_text(yaml.dump(data), encoding="utf-8")
    return p


def test_load_linear_assembly(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, {"name": "pipe", "blocks": [_ECHO, _LEN]})
    asm = load_assembly(p)
    assert asm.name == "pipe"
    assert len(asm.blocks) == 2


def test_load_by_module_dot_class(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, [_ECHO, _LEN])
    asm = load_assembly(p)
    from tests.fixtures.sample_blocks import EchoBlock, LengthBlock
    assert asm.input_model is EchoBlock.input_model
    assert asm.output_model is LengthBlock.output_model


def test_load_by_module_colon_class(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, ["tests.fixtures.sample_blocks:EchoBlock",
                               "tests.fixtures.sample_blocks:LengthBlock"])
    asm = load_assembly(p)
    assert len(asm.blocks) == 2


def test_load_by_registry_name(tmp_path: Path) -> None:
    from tests.fixtures.sample_blocks import EchoBlock, LengthBlock
    reg = BlockRegistry()
    reg.register(EchoBlock)
    reg.register(LengthBlock)
    p = _yaml_file(tmp_path, ["EchoBlock", "LengthBlock"])
    asm = load_assembly(p, registry=reg)
    assert len(asm.blocks) == 2


def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_assembly(tmp_path / "no_such.yml")


def test_missing_name_key_raises(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, {"no_blocks_here": 1})
    with pytest.raises(ValueError, match="blocks"):
        load_assembly(p)


def test_empty_blocks_raises(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, {"name": "x", "blocks": []})
    with pytest.raises(ValueError, match="비어있"):
        load_assembly(p)


def test_unknown_block_raises(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, ["NoSuchBlock"])
    with pytest.raises(KeyError):
        load_assembly(p)


def test_incompatible_snap_raises(tmp_path: Path) -> None:
    # LengthBlock → EchoBlock: NumberOutput → TextInput 불일치
    p = _yaml_file(tmp_path, [_LEN, _ECHO])
    with pytest.raises(IncompatibleSnapError):
        load_assembly(p)


def test_cli_assemble_prints_repr(tmp_path: Path) -> None:
    p = _yaml_file(tmp_path, {"name": "cli-test", "blocks": [_ECHO, _LEN]})
    result = subprocess.run(
        [sys.executable, "-m", "pylego", "assemble", str(p)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "cli-test" in result.stdout
