"""EmbeddingBlock 단위 테스트 — 외부 SDK 를 sys.modules mock 으로 대체."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego import EmbeddingBlock, EmbeddingInput, EmbeddingResult


# ── OpenAI backend ────────────────────────────────────────────────────────────

@pytest.fixture()
def mock_openai() -> Any:
    module = MagicMock()
    client = AsyncMock()
    module.AsyncOpenAI.return_value = client

    item1, item2 = MagicMock(), MagicMock()
    item1.embedding = [0.1, 0.2, 0.3]
    item2.embedding = [0.4, 0.5, 0.6]
    resp = MagicMock()
    resp.data = [item1, item2]
    resp.model = "text-embedding-3-small"
    resp.usage.total_tokens = 10
    client.embeddings.create = AsyncMock(return_value=resp)

    with patch.dict("sys.modules", {"openai": module}):
        yield client


async def test_openai_basic(mock_openai: Any) -> None:
    block = EmbeddingBlock(api_key="test")
    result = await block.run(EmbeddingInput(texts=["hello", "world"]))
    assert isinstance(result, EmbeddingResult)
    assert len(result.embeddings) == 2
    assert result.embeddings[0] == [0.1, 0.2, 0.3]
    assert result.total_tokens == 10


async def test_openai_model_passed(mock_openai: Any) -> None:
    block = EmbeddingBlock(api_key="test")
    await block.run(EmbeddingInput(texts=["x"], model="text-embedding-3-large"))
    call_kwargs: dict[str, Any] = mock_openai.embeddings.create.call_args.kwargs
    assert call_kwargs["model"] == "text-embedding-3-large"


# ── Ollama backend ────────────────────────────────────────────────────────────

@pytest.fixture()
def mock_ollama_http() -> Any:
    resp = MagicMock()
    resp.json.return_value = {"embedding": [0.7, 0.8, 0.9]}
    resp.raise_for_status = MagicMock()
    client = AsyncMock()
    client.post = AsyncMock(return_value=resp)
    with patch("httpx.AsyncClient") as mock_cls:
        ctx = MagicMock()
        ctx.__aenter__ = AsyncMock(return_value=client)
        ctx.__aexit__ = AsyncMock(return_value=None)
        mock_cls.return_value = ctx
        yield client


async def test_ollama_basic(mock_ollama_http: Any) -> None:
    block = EmbeddingBlock()
    result = await block.run(
        EmbeddingInput(texts=["hello"], model="nomic-embed-text", backend="ollama")
    )
    assert result.embeddings == [[0.7, 0.8, 0.9]]
    assert result.model == "nomic-embed-text"
    assert result.total_tokens == 0


async def test_openai_import_error() -> None:
    with patch.dict("sys.modules", {"openai": None}):  # type: ignore[dict-item]
        block = EmbeddingBlock()
        with pytest.raises(ImportError, match="pylego\\[openai\\]"):
            await block.run(EmbeddingInput(texts=["x"]))
