"""BaseLlmBlock / LlmInput / LlmResult 단위 테스트."""

from __future__ import annotations

import pytest

from pylego.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult, _LLM_REGISTRY


def test_llm_input_defaults() -> None:
    inp = LlmInput(prompt="hi")
    assert inp.prompt == "hi"
    assert inp.system is None
    assert inp.model is None
    assert inp.max_tokens == 1024
    assert inp.temperature == 1.0


def test_llm_result_fields() -> None:
    r = LlmResult(content="ok", model="m", input_tokens=1, output_tokens=2)
    assert r.content == "ok"
    assert r.input_tokens == 1


def test_subclass_registration() -> None:
    class _TestLlmBlock(BaseLlmBlock):
        backend_name = "_pytest_backend"

        async def run(self, inp: LlmInput) -> LlmResult:
            return LlmResult(content="x", model="m", input_tokens=0, output_tokens=0)

    assert "_pytest_backend" in _LLM_REGISTRY
    assert _LLM_REGISTRY["_pytest_backend"] is _TestLlmBlock


async def test_base_run_raises_not_implemented() -> None:
    class _NoRunBlock(BaseLlmBlock):
        pass

    with pytest.raises(NotImplementedError):
        await _NoRunBlock().run(LlmInput(prompt="test"))


def test_no_backend_name_not_registered() -> None:
    before = set(_LLM_REGISTRY.keys())

    class _AnonBlock(BaseLlmBlock):
        pass

    after = set(_LLM_REGISTRY.keys())
    assert after == before
