"""M108 — Autonomous Thaw + Probe-Registry Bridge 테스트."""

from __future__ import annotations

import importlib
import sys
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego import Assembly, Block, Stud
from pylego.scheduler import GlobalSchedulerPolicy, SchedulerPolicy, ThawPolicy


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    x: int


class _Out(Stud):
    y: int


class _Ok(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


def _pipeline() -> Assembly[_In, _Out]:
    return Assembly([_Ok()])


# ── apscheduler mock 헬퍼 (기존 test_scheduler.py 와 동일) ────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def _make_scheduler() -> Any:
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)
        return sched_mod.Scheduler()


# ── ThawPolicy 기본값 ─────────────────────────────────────────────────────────


def test_thaw_policy_defaults() -> None:
    tp = ThawPolicy()
    assert tp.strategy == "manual"
    assert tp.canary_interval_sec == 300.0
    assert tp.success_threshold == 3


def test_thaw_policy_canary_strategy() -> None:
    tp = ThawPolicy(strategy="canary", canary_interval_sec=60.0, success_threshold=2)
    assert tp.strategy == "canary"
    assert tp.canary_interval_sec == 60.0
    assert tp.success_threshold == 2


def test_thaw_policy_gradual_strategy() -> None:
    tp = ThawPolicy(strategy="gradual")
    assert tp.strategy == "gradual"


# ── GlobalSchedulerPolicy 확장 ────────────────────────────────────────────────


def test_global_policy_thaw_defaults() -> None:
    gp = GlobalSchedulerPolicy()
    assert gp.thaw_policy is None
    assert gp.on_thaw is None


def test_global_policy_with_thaw_policy() -> None:
    tp = ThawPolicy(strategy="canary", success_threshold=2)
    gp = GlobalSchedulerPolicy(thaw_policy=tp)
    assert gp.thaw_policy is tp


# ── SchedulerPolicy 확장 ──────────────────────────────────────────────────────


def test_scheduler_policy_probe_updates_registry_default() -> None:
    p = SchedulerPolicy()
    assert p.probe_updates_registry is False


def test_scheduler_policy_probe_updates_registry_enabled() -> None:
    p = SchedulerPolicy(probe_updates_registry=True)
    assert p.probe_updates_registry is True


# ── _maybe_auto_thaw — manual 전략 ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_manual_strategy_no_auto_thaw() -> None:
    """strategy='manual' 이면 자율 해제 없음."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="manual")
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.freeze("test freeze")
        await sched._maybe_auto_thaw()
        assert sched._frozen is True


# ── _maybe_auto_thaw — canary 전략 ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_canary_strategy_thaws_after_threshold() -> None:
    """success_threshold=2 → 2회 연속 성공 후 동결 해제."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        thaw_calls: list[str] = []
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=2)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp, on_thaw=thaw_calls.append)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("initial freeze")

        # 1회 성공 → threshold 미달
        await sched._maybe_auto_thaw()
        assert sched._frozen is True
        assert sched._thaw_consecutive_successes == 1

        # 2회 성공 → threshold 달성, 동결 해제
        await sched._maybe_auto_thaw()
        assert sched._frozen is False
        assert sched._thaw_consecutive_successes == 0
        assert len(thaw_calls) == 1
        assert "2회" in thaw_calls[0]


@pytest.mark.asyncio
async def test_canary_strategy_resets_on_failure() -> None:
    """중간 실패 시 카나리 카운터 리셋 + 재동결."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        fail_next = [False]

        class _Flaky(Block[_In, _Out]):
            input_model = _In
            output_model = _Out

            async def run(self, inp: _In) -> _Out:
                if fail_next[0]:
                    raise RuntimeError("flaky")
                return _Out(y=inp.x)

        pipeline: Assembly[_In, _Out] = Assembly([_Flaky()])
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=3)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(pipeline, input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        # 1회 성공 → 카운터 1
        await sched._maybe_auto_thaw()
        assert sched._thaw_consecutive_successes == 1

        # 실패 → 카운터 리셋, 재동결
        fail_next[0] = True
        await sched._maybe_auto_thaw()
        assert sched._frozen is True
        assert sched._thaw_consecutive_successes == 0


@pytest.mark.asyncio
async def test_canary_interval_respected() -> None:
    """canary_interval_sec 경과 전에는 재시도하지 않는다."""
    import time

    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=9999.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        # _last_canary_at 을 현재로 설정 → interval 미달
        sched._last_canary_at = time.monotonic()

        await sched._maybe_auto_thaw()
        assert sched._frozen is True
        assert sched._thaw_consecutive_successes == 0


@pytest.mark.asyncio
async def test_on_thaw_callback_called() -> None:
    """on_thaw 콜백이 자율 해제 시 호출된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        calls: list[str] = []
        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp, on_thaw=calls.append)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert len(calls) == 1
        assert "자율 해제" in calls[0]


# ── gradual 전략 ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_gradual_strategy_partial_release() -> None:
    """gradual 전략은 threshold 달성 전까지 카운터만 증가, 달성 시 해제."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="gradual", canary_interval_sec=0.0, success_threshold=3)
        gp = sched_mod.GlobalSchedulerPolicy(thaw_policy=tp)

        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._frozen is True
        assert sched._thaw_consecutive_successes == 1

        await sched._maybe_auto_thaw()
        assert sched._frozen is True
        assert sched._thaw_consecutive_successes == 2

        await sched._maybe_auto_thaw()
        assert sched._frozen is False
        assert sched._thaw_consecutive_successes == 0


# ── probe_updates_registry ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_probe_updates_registry_on_success() -> None:
    """probe_ok=True → registry 성공 기록."""
    from pylego.registry import BlockRegistry
    import pylego.registry as reg_module

    class PipelineJob(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            return _Out(y=inp.x)

    orig = reg_module.default_registry
    try:
        test_reg = BlockRegistry()
        test_reg.register(PipelineJob)
        reg_module.default_registry = test_reg  # type: ignore[assignment]

        probe_result = [True]

        async def probe() -> bool:
            return probe_result[0]

        policy = SchedulerPolicy(
            probe_fn=probe,
            probe_updates_registry=True,
        )

        # probe 결과를 registry에 기록하는 로직 직접 검증
        probe_ok = await probe()
        if policy.probe_updates_registry:
            test_reg.update_stat(
                "PipelineJob",
                success=probe_ok,
                elapsed_sec=0.0,
                error_type=None if probe_ok else "ProbeFailure",
                severity=0.0 if probe_ok else 0.5,
            )

        info = test_reg.describe("PipelineJob")
        assert info.runtime is not None
        assert info.runtime.success_count == 1
        assert info.runtime.weighted_failure_sum == 0.0

    finally:
        reg_module.default_registry = orig  # type: ignore[assignment]


@pytest.mark.asyncio
async def test_probe_updates_registry_on_failure() -> None:
    """probe_ok=False → registry 실패 기록 (error_type=ProbeFailure, severity=0.5)."""
    from pylego.registry import BlockRegistry
    import pylego.registry as reg_module

    class PipelineC(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            return _Out(y=inp.x)

    orig = reg_module.default_registry
    try:
        test_reg = BlockRegistry()
        test_reg.register(PipelineC)
        reg_module.default_registry = test_reg  # type: ignore[assignment]

        policy = SchedulerPolicy(probe_updates_registry=True)

        probe_ok = False
        if policy.probe_updates_registry:
            test_reg.update_stat(
                "PipelineC",
                success=probe_ok,
                elapsed_sec=0.0,
                error_type="ProbeFailure",
                severity=0.5,
            )

        info = test_reg.describe("PipelineC")
        assert info.runtime is not None
        assert info.runtime.failure_count == 1
        assert info.runtime.weighted_failure_sum == pytest.approx(0.5)

    finally:
        reg_module.default_registry = orig  # type: ignore[assignment]
