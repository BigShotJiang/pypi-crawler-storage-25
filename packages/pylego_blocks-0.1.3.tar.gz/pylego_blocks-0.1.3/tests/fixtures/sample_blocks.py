"""Declarative loader 테스트용 최소 fixture 블록."""

from __future__ import annotations

from pylego.core.block import Block
from pylego.core.stud import Stud


class TextInput(Stud):
    text: str = ""


class TextOutput(Stud):
    text: str = ""


class NumberOutput(Stud):
    length: int = 0


class EchoBlock(Block[TextInput, TextOutput]):
    input_model = TextInput
    output_model = TextOutput

    async def run(self, inp: TextInput) -> TextOutput:  # pragma: no cover
        return TextOutput(text=inp.text)


class LengthBlock(Block[TextOutput, NumberOutput]):
    input_model = TextOutput
    output_model = NumberOutput

    async def run(self, inp: TextOutput) -> NumberOutput:  # pragma: no cover
        return NumberOutput(length=len(inp.text))
