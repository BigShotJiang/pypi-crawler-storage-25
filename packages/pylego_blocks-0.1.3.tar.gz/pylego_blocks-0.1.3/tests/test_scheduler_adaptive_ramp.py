"""M120 — Adaptive Ramp-up + Global Recovery Quota 테스트."""

from __future__ import annotations

import importlib
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego import Assembly, Block, Stud


# ── 더미 블록 ──────────────────────────────────────────────────────────────────


class _In(Stud):
    x: int


class _Out(Stud):
    y: int


class _Ok(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


def _pipeline() -> Assembly[_In, _Out]:
    return Assembly([_Ok()])


# ── apscheduler mock 헬퍼 ─────────────────────────────────────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def _extract_run_fn(mock_instance: MagicMock, idx: int = 0) -> Any:
    return mock_instance.add_job.call_args_list[idx][0][0]


# ── max_global_recovery_ratio ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_max_global_recovery_ratio_limits_per_job_ratio() -> None:
    """max_global_recovery_ratio 가 개별 ratio를 상한 제한한다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            recovery_traffic_ratio=1.0,       # 개별 잡 100%
            max_global_recovery_ratio=0.5,    # 전체 상한 50%
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j1")
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j2")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        run_fn = _extract_run_fn(mock_instance, 0)
        executed = 0
        for _ in range(10):
            await run_fn()
            executed = sched._job_states["j1"].total_runs

        # 50% 제한 → 약 5/10 실행 (±1 허용)
        assert executed <= 6


# ── adaptive_ramp_up 상향 ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ramp_up_increases_ratio_on_success() -> None:
    """adaptive_ramp_up=True + 성공 → ratio가 step_up만큼 증가한다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            adaptive_ramp_up=True,
            adaptive_min_ratio=0.1,
            adaptive_step_up=0.1,
            adaptive_step_down=0.2,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        ratio_before = sched._current_recovery_ratio
        run_fn = _extract_run_fn(mock_instance)
        await run_fn()

        assert sched._current_recovery_ratio == pytest.approx(ratio_before + 0.1)


# ── adaptive_ramp_up 하향 ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ramp_up_decreases_ratio_on_failure() -> None:
    """adaptive_ramp_up=True + 실패 → ratio가 step_down만큼 감소한다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            adaptive_ramp_up=True,
            adaptive_min_ratio=0.05,
            adaptive_step_up=0.1,
            adaptive_step_down=0.2,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)

        fail_pipeline = AsyncMock(spec=Assembly)
        # 첫 번째 호출(카나리)은 성공, 이후 호출은 실패
        fail_pipeline.run = AsyncMock(side_effect=[_Out(y=1), RuntimeError("fail")])
        sched.add(fail_pipeline, input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True

        ratio_before = sched._current_recovery_ratio
        run_fn = _extract_run_fn(mock_instance)
        await run_fn()

        assert sched._current_recovery_ratio == pytest.approx(
            max(0.05, ratio_before - 0.2)
        )


# ── ratio 하한 ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ratio_not_below_min() -> None:
    """ratio는 adaptive_min_ratio 아래로 내려가지 않는다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            adaptive_ramp_up=True,
            adaptive_min_ratio=0.1,
            adaptive_step_down=0.5,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)

        fail_pipeline = AsyncMock(spec=Assembly)
        fail_pipeline.run = AsyncMock(side_effect=RuntimeError("fail"))
        sched.add(fail_pipeline, input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        run_fn = _extract_run_fn(mock_instance)
        # 여러 번 실패해도 min_ratio 이하로 떨어지지 않음
        for _ in range(5):
            await run_fn()

        assert sched._current_recovery_ratio >= 0.1


# ── ratio 상한 ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ratio_not_above_one() -> None:
    """ratio는 1.0 위로 올라가지 않는다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            adaptive_ramp_up=True,
            adaptive_min_ratio=0.9,
            adaptive_step_up=0.5,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        run_fn = _extract_run_fn(mock_instance)
        for _ in range(5):
            await run_fn()

        assert sched._current_recovery_ratio <= 1.0


# ── adaptive_ramp_up 우선 ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ramp_up_overrides_recovery_ramp_up() -> None:
    """adaptive_ramp_up=True이면 recovery_ramp_up은 무시된다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            recovery_ramp_up=True,    # 선형 상향 (무시됨)
            adaptive_ramp_up=True,    # 우선
            adaptive_min_ratio=0.1,
            adaptive_step_up=0.2,
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        assert sched._recovering is True
        # adaptive_ramp_up=True → 초기값은 adaptive_min_ratio
        assert sched._current_recovery_ratio == pytest.approx(0.1)

        run_fn = _extract_run_fn(mock_instance)
        await run_fn()
        # adaptive step_up 적용 (not linear ramp_up)
        assert sched._current_recovery_ratio == pytest.approx(0.1 + 0.2)


# ── adaptive_ramp_up=False 하위 호환 ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_adaptive_ramp_up_false_uses_fixed_ratio() -> None:
    """adaptive_ramp_up=False이면 ratio가 recovery_traffic_ratio 고정값으로 유지된다."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
        gp = sched_mod.GlobalSchedulerPolicy(
            thaw_policy=tp,
            post_thaw_observation_sec=9999.0,
            recovery_traffic_ratio=0.5,  # 고정 50%
            adaptive_ramp_up=False,      # adaptive 비활성
        )
        sched = sched_mod.Scheduler()
        sched.set_global_policy(gp)
        sched.add(_pipeline(), input=_In(x=1), interval_seconds=60.0, job_id="j")
        sched.freeze("test")

        await sched._maybe_auto_thaw()
        ratio_after_enter = sched._current_recovery_ratio

        run_fn = _extract_run_fn(mock_instance)
        for _ in range(3):
            await run_fn()

        # adaptive 비활성 → ratio 변동 없음
        assert sched._current_recovery_ratio == pytest.approx(ratio_after_enter)


# ── global_status effective_recovery_ratio ────────────────────────────────────


@pytest.mark.asyncio
async def test_global_status_includes_effective_recovery_ratio() -> None:
    """global_status()에 effective_recovery_ratio 필드가 포함된다."""
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego.scheduler as sched_mod
        importlib.reload(sched_mod)

        sched = sched_mod.Scheduler()
        status = sched.global_status()
        assert "effective_recovery_ratio" in status
        assert status["effective_recovery_ratio"] == pytest.approx(1.0)
        assert "max_global_recovery_ratio" in status
