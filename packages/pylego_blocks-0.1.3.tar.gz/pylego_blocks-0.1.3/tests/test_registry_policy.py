"""M103 — RegistryPolicy + BlockRuntimeStat.confidence 테스트."""

from __future__ import annotations

import math

import pytest

from pylego import Block, RegistryPolicy, Stud
from pylego.registry import BlockRegistry, BlockRuntimeStat


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _BlockA(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _BlockB(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


# ── RegistryPolicy 기본값 ─────────────────────────────────────────────────────


def test_registry_policy_defaults() -> None:
    p = RegistryPolicy()
    assert p.min_samples == 5
    assert p.trend_window == 20
    assert p.trend_worsening_threshold == pytest.approx(0.2)
    assert p.trend_improvement_threshold == pytest.approx(0.1)


# ── BlockRuntimeStat.confidence ───────────────────────────────────────────────


def test_confidence_zero_runs() -> None:
    stat = BlockRuntimeStat()
    assert stat.confidence == 0.0


def test_confidence_reaches_1_at_threshold() -> None:
    """total_runs == min_samples × 2 이면 confidence == 1.0."""
    stat = BlockRuntimeStat(success_count=10)  # default min_samples=5, threshold=10
    assert stat.confidence == pytest.approx(1.0)


def test_confidence_above_threshold_stays_1() -> None:
    stat = BlockRuntimeStat(success_count=100)
    assert stat.confidence == pytest.approx(1.0)


def test_confidence_partial() -> None:
    """total_runs=5, min_samples=5 → confidence = 5/10 = 0.5."""
    stat = BlockRuntimeStat(success_count=5)
    assert stat.confidence == pytest.approx(0.5)


def test_confidence_uses_custom_policy() -> None:
    """min_samples=10 → threshold=20 에서 confidence 1.0."""
    policy = RegistryPolicy(min_samples=10)
    stat = BlockRuntimeStat(_policy=policy, success_count=10)  # 10/20 = 0.5
    assert stat.confidence == pytest.approx(0.5)
    stat2 = BlockRuntimeStat(_policy=policy, success_count=20)  # 20/20 = 1.0
    assert stat2.confidence == pytest.approx(1.0)


def test_confidence_min_samples_zero_returns_1() -> None:
    policy = RegistryPolicy(min_samples=0)
    stat = BlockRuntimeStat(_policy=policy)
    assert stat.confidence == pytest.approx(1.0)


# ── ucb_score 신뢰도 반영 ──────────────────────────────────────────────────────


def test_ucb_score_low_sample_penalized() -> None:
    """5회 100% 성공 블록은 1000회 90% 블록보다 UCB 낮아야 한다."""
    established = BlockRuntimeStat(success_count=900, failure_count=100)
    new_block = BlockRuntimeStat(success_count=5)
    assert established.ucb_score > new_block.ucb_score


def test_ucb_score_full_confidence_formula() -> None:
    """total_runs=10, weighted_failure_sum=0 → ucb = confidence × log1p(total)."""
    stat = BlockRuntimeStat(success_count=8, failure_count=2)  # total=10, conf=1.0
    # weighted_failure_sum=0(직접 생성) → risk_adjusted_confidence=confidence=1.0
    expected = 1.0 * math.log1p(10)
    assert stat.ucb_score == pytest.approx(expected)


def test_ucb_score_confidence_weighted() -> None:
    """total_runs=5, min_samples=5 → confidence=0.5."""
    stat = BlockRuntimeStat(success_count=5)  # rate=1.0, conf=0.5
    expected = (1.0 * 0.5) * math.log1p(5)
    assert stat.ucb_score == pytest.approx(expected)


# ── trend — 정책 임계치 적용 ──────────────────────────────────────────────────


def test_trend_degrading_absolute_diff() -> None:
    """recent_fail - overall_fail >= 0.2 → degrading."""
    stat = BlockRuntimeStat(success_count=90, failure_count=10)  # overall=0.1
    for _ in range(5):
        stat.recent_runs.append(True)
    for _ in range(5):
        stat.recent_runs.append(False)  # recent=0.5 → diff=0.4 >= 0.2
    assert stat.trend == "degrading"


def test_trend_improving_absolute_diff() -> None:
    """overall_fail - recent_fail >= 0.1 → improving."""
    stat = BlockRuntimeStat(success_count=50, failure_count=50)  # overall=0.5
    for _ in range(10):
        stat.recent_runs.append(True)  # recent=0.0 → diff=0.5 >= 0.1
    assert stat.trend == "improving"


def test_trend_stable_diff_below_threshold() -> None:
    """차이가 임계치 미달이면 stable."""
    stat = BlockRuntimeStat(success_count=90, failure_count=10)  # overall=0.1
    for _ in range(9):
        stat.recent_runs.append(True)
    stat.recent_runs.append(False)  # recent=0.1 → diff=0.0
    assert stat.trend == "stable"


def test_trend_degrading_custom_threshold() -> None:
    """worsening_threshold=0.05: 작은 차이에도 degrading 판정."""
    policy = RegistryPolicy(trend_worsening_threshold=0.05)
    stat = BlockRuntimeStat(_policy=policy, success_count=90, failure_count=10)
    for _ in range(4):
        stat.recent_runs.append(True)
    for _ in range(1):
        stat.recent_runs.append(False)  # recent=0.2, overall=0.1, diff=0.1 >= 0.05
    assert stat.trend == "degrading"


def test_trend_degrading_strict_threshold_stays_stable() -> None:
    """worsening_threshold=0.5: 차이 0.4는 stable."""
    policy = RegistryPolicy(trend_worsening_threshold=0.5)
    stat = BlockRuntimeStat(_policy=policy, success_count=90, failure_count=10)
    for _ in range(5):
        stat.recent_runs.append(True)
    for _ in range(5):
        stat.recent_runs.append(False)  # diff=0.4 < 0.5 → stable
    assert stat.trend != "degrading"


# ── BlockRegistry.set_policy ──────────────────────────────────────────────────


def test_registry_set_policy_updates_existing_stats() -> None:
    """set_policy 호출 시 기존 stat 의 _policy 도 갱신된다."""
    reg = BlockRegistry()
    reg.register(_BlockA, description="a")
    reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)

    new_policy = RegistryPolicy(min_samples=20)
    reg.set_policy(new_policy)

    stat = reg.describe("_BlockA").runtime
    assert stat is not None
    assert stat._policy is new_policy


def test_registry_new_stat_uses_policy() -> None:
    """set_policy 후 새로 생성된 stat 도 정책을 따른다."""
    reg = BlockRegistry()
    reg.register(_BlockA, description="a")
    reg.register(_BlockB, description="b")

    policy = RegistryPolicy(min_samples=20)
    reg.set_policy(policy)

    reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    stat = reg.describe("_BlockA").runtime
    assert stat is not None
    # min_samples=20 → confidence = 1/(20*2) = 0.025
    assert stat.confidence == pytest.approx(1 / 40)


def test_registry_default_policy_is_registry_policy() -> None:
    reg = BlockRegistry()
    assert isinstance(reg._policy, RegistryPolicy)


def test_search_sort_by_smart_penalizes_low_sample() -> None:
    """confidence 패널티로 소수 샘플 블록은 하위로 밀린다."""
    reg = BlockRegistry()
    reg.register(_BlockA, tags=["test"], description="a")
    reg.register(_BlockB, tags=["test"], description="b")

    # _BlockA: 1000회 90% → confidence=1.0, high ucb
    for _ in range(900):
        reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    for _ in range(100):
        reg.update_stat("_BlockA", success=False, elapsed_sec=0.2, error="e")

    # _BlockB: 3회 100% → confidence=0.3 (3/10), low ucb
    for _ in range(3):
        reg.update_stat("_BlockB", success=True, elapsed_sec=0.05)

    results = reg.search("", sort_by="smart")
    names = [r.name for r in results]
    assert names.index("_BlockA") < names.index("_BlockB")
