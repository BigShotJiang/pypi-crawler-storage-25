"""NestedEventBus / BlockFailedEvent.caused_by 단위 테스트 (M83)."""

from __future__ import annotations

import pytest

from pylego import CollectingEventBus, NestedEventBus, observe
from pylego.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
)


def _started(name: str = "A") -> BlockStartedEvent:
    return BlockStartedEvent(block_name=name, input=None, timestamp=0.0)


def _completed(name: str = "A") -> BlockCompletedEvent:
    return BlockCompletedEvent(block_name=name, output=None, elapsed_sec=0.1, timestamp=0.0)


def _failed(name: str = "A") -> BlockFailedEvent:
    return BlockFailedEvent(
        block_name=name, error=RuntimeError("oops"), elapsed_sec=0.1, timestamp=0.0
    )


def _retry(name: str = "A") -> BlockRetryEvent:
    return BlockRetryEvent(
        block_name=name, attempt=1, max_attempts=3,
        error=RuntimeError("e"), delay_sec=0.5, timestamp=0.0,
    )


def _circuit(name: str = "A") -> CircuitBreakerStateEvent:
    return CircuitBreakerStateEvent(
        block_name=name, previous_state="closed", new_state="open", timestamp=0.0
    )


# ── 기본 포워딩 ───────────────────────────────────────────────────────────────

def test_nested_bus_stores_locally() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="ns")
    inner.emit(_started())
    assert len(inner.events) == 1
    assert inner.events[0].block_name == "A"


def test_nested_bus_forwards_with_prefix() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="sub")
    inner.emit(_started("Block"))
    assert outer.events[0].block_name == "sub/Block"


def test_nested_bus_no_namespace_forwards_as_is() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="")
    inner.emit(_started("X"))
    assert outer.events[0].block_name == "X"


# ── 각 이벤트 타입 프리픽스 ───────────────────────────────────────────────────

def test_prefix_completed_event() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="layer")
    inner.emit(_completed("B"))
    assert outer.events[0].block_name == "layer/B"


def test_prefix_failed_event() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="layer")
    inner.emit(_failed("C"))
    assert outer.events[0].block_name == "layer/C"


def test_prefix_retry_event() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="ns")
    inner.emit(_retry("D"))
    assert outer.events[0].block_name == "ns/D"


def test_prefix_circuit_breaker_event() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="ns")
    inner.emit(_circuit("E"))
    assert outer.events[0].block_name == "ns/E"


# ── failed_events 헬퍼 ────────────────────────────────────────────────────────

def test_nested_bus_failed_events() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="ns")
    inner.emit(_started())
    inner.emit(_failed())
    assert len(inner.failed_events()) == 1


# ── observe() 통합 ───────────────────────────────────────────────────────────

def test_observe_with_nested_bus() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="inner")
    with observe(inner):
        inner.emit(_started("MyBlock"))
    assert any(e.block_name == "inner/MyBlock" for e in outer.events)


# ── BlockFailedEvent.caused_by 필드 ─────────────────────────────────────────

def test_block_failed_event_caused_by_default_none() -> None:
    ev = _failed("F")
    assert ev.caused_by is None


def test_block_failed_event_caused_by_set() -> None:
    cause = _failed("Root")
    derived = BlockFailedEvent(
        block_name="Wrapper",
        error=RuntimeError("chain"),
        elapsed_sec=0.2,
        timestamp=0.0,
        caused_by=cause,
    )
    assert derived.caused_by is cause
    assert derived.caused_by.block_name == "Root"


def test_nested_bus_preserves_caused_by_on_prefix() -> None:
    outer = CollectingEventBus()
    inner = NestedEventBus(parent=outer, namespace="ns")
    cause = _failed("Root")
    ev = BlockFailedEvent(
        block_name="Child", error=RuntimeError("x"), elapsed_sec=0.0,
        timestamp=0.0, caused_by=cause,
    )
    inner.emit(ev)
    forwarded = outer.failed_events()[0]
    assert forwarded.block_name == "ns/Child"
    assert forwarded.caused_by is cause
