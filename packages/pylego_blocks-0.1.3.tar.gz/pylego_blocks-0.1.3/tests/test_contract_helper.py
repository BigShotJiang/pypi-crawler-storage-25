"""Tests for contract assertion helpers (#49)."""

from __future__ import annotations

from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud
from pylego.testing.contracts import (
    assert_block_contract,
    blocks_with_compatible_pairs,
)


class _TextIn(Stud):
    text: str


class _TextOut(Stud):
    text: str


class _UpperBlock(Block[_TextIn, _TextOut]):
    input_model = _TextIn
    output_model = _TextOut

    async def run(self, inp: _TextIn) -> _TextOut:
        return _TextOut(text=inp.text.upper())


class _WrongReturnBlock(Block[_TextIn, _TextOut]):
    input_model = _TextIn
    output_model = _TextOut

    async def run(self, inp: _TextIn) -> _TextOut:
        wrong: Any = _TextIn(text=inp.text)
        return wrong  # type: ignore[no-any-return]


class _UpperToOutInBlock(Block[_TextOut, _TextIn]):
    """Bridge block (_TextOut → _TextIn) so that ``_UpperBlock → _UpperToOutInBlock``
    forms a compatible pair for ``blocks_with_compatible_pairs``.
    """

    input_model = _TextOut
    output_model = _TextIn

    async def run(self, inp: _TextOut) -> _TextIn:
        return _TextIn(text=inp.text)


async def test_assert_block_contract_passes_for_valid_block() -> None:
    result = await assert_block_contract(
        _UpperBlock,
        sample_input=_TextIn(text="hi"),
        block=_UpperBlock(),
    )
    assert result.ok is True
    assert result.reason == ""


async def test_assert_block_contract_fails_on_output_type_mismatch() -> None:
    result = await assert_block_contract(
        _WrongReturnBlock,
        sample_input=_TextIn(text="hi"),
        block=_WrongReturnBlock(),
    )
    assert result.ok is False
    assert "output" in result.reason.lower()


async def test_assert_block_contract_fails_when_sample_not_stud() -> None:
    not_a_stud: Any = "not-a-stud"
    result = await assert_block_contract(
        _UpperBlock,
        sample_input=not_a_stud,
        block=_UpperBlock(),
    )
    assert result.ok is False
    assert "sample_input" in result.reason or "type mismatch" in result.reason


def test_blocks_with_compatible_pairs_detects_known_pair() -> None:
    pairs = list(blocks_with_compatible_pairs([_UpperBlock, _UpperToOutInBlock]))
    assert (_UpperBlock, _UpperToOutInBlock) in pairs
