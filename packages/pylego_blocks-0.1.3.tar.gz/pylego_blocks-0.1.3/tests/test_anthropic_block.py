"""AnthropicBlock 단위 테스트 — anthropic SDK 를 sys.modules mock 으로 대체."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego import AnthropicBlock, AnthropicInput, AnthropicResult


def _make_message(text: str, model: str = "claude-opus-4-5") -> MagicMock:
    content_block = MagicMock()
    content_block.text = text
    msg = MagicMock()
    msg.content = [content_block]
    msg.model = model
    msg.stop_reason = "end_turn"
    msg.usage.input_tokens = 10
    msg.usage.output_tokens = 20
    return msg


@pytest.fixture()
def mock_client() -> Any:
    """anthropic SDK 를 sys.modules 에서 mock 으로 교체 (lazy import 대응)."""
    module = MagicMock()
    client = AsyncMock()
    module.AsyncAnthropic.return_value = client
    client.messages.create = AsyncMock(return_value=_make_message("안녕하세요!"))
    with patch.dict("sys.modules", {"anthropic": module}):
        yield client


async def test_basic_call(mock_client: Any) -> None:
    block = AnthropicBlock(api_key="test-key")
    result = await block.run(
        AnthropicInput(
            messages=[{"role": "user", "content": "안녕"}],
            max_tokens=64,
        )
    )
    assert isinstance(result, AnthropicResult)
    assert result.content == "안녕하세요!"
    assert result.stop_reason == "end_turn"
    assert result.input_tokens == 10
    assert result.output_tokens == 20


async def test_system_prompt_passed(mock_client: Any) -> None:
    block = AnthropicBlock(api_key="test-key")
    await block.run(
        AnthropicInput(
            messages=[{"role": "user", "content": "hi"}],
            system="You are helpful.",
            max_tokens=32,
        )
    )
    call_kwargs: dict[str, Any] = mock_client.messages.create.call_args.kwargs
    assert call_kwargs.get("system") == "You are helpful."


async def test_no_system_when_not_set(mock_client: Any) -> None:
    block = AnthropicBlock(api_key="test-key")
    await block.run(AnthropicInput(messages=[{"role": "user", "content": "hi"}]))
    call_kwargs: dict[str, Any] = mock_client.messages.create.call_args.kwargs
    assert "system" not in call_kwargs


async def test_import_error_without_package() -> None:
    with patch.dict("sys.modules", {"anthropic": None}):  # type: ignore[dict-item]
        block = AnthropicBlock(api_key="x")
        with pytest.raises(ImportError, match="pylego\\[anthropic\\]"):
            await block.run(AnthropicInput(messages=[], max_tokens=1))
