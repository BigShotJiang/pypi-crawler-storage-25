"""TemplateBlock 단위 테스트."""

from __future__ import annotations

import pytest

from pylego import TemplateBlock, TemplateInput, TemplateResult


async def test_simple_render() -> None:
    block = TemplateBlock()
    result = await block.run(
        TemplateInput(
            template="안녕하세요, {{ name }}님!",
            context={"name": "홍길동"},
        )
    )
    assert isinstance(result, TemplateResult)
    assert result.rendered == "안녕하세요, 홍길동님!"


async def test_multiple_variables() -> None:
    block = TemplateBlock()
    result = await block.run(
        TemplateInput(
            template="{{ greeting }}, {{ name }}! 총 {{ count }}개.",
            context={"greeting": "Hello", "name": "World", "count": 3},
        )
    )
    assert result.rendered == "Hello, World! 총 3개."


async def test_empty_context() -> None:
    block = TemplateBlock()
    result = await block.run(TemplateInput(template="정적 텍스트"))
    assert result.rendered == "정적 텍스트"


async def test_jinja2_loop() -> None:
    block = TemplateBlock()
    result = await block.run(
        TemplateInput(
            template="{% for item in items %}{{ item }},{% endfor %}",
            context={"items": ["a", "b", "c"]},
        )
    )
    assert result.rendered == "a,b,c,"


async def test_jinja2_conditional() -> None:
    block = TemplateBlock()
    result = await block.run(
        TemplateInput(
            template="{% if flag %}YES{% else %}NO{% endif %}",
            context={"flag": True},
        )
    )
    assert result.rendered == "YES"


async def test_import_error_without_package() -> None:
    from unittest.mock import patch

    with patch.dict("sys.modules", {"jinja2": None}):  # type: ignore[dict-item]
        block = TemplateBlock()
        with pytest.raises(ImportError, match="pylego\\[jinja2\\]"):
            await block.run(TemplateInput(template="hi"))
