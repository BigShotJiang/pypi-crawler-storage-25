from __future__ import annotations

import pytest

from pylego.core.assembly import Assembly, CyclicAssemblyError
from pylego.core.block import Block
from pylego.core.stud import Stud


class A(Stud):
    x: int = 0


class B(Stud):
    y: int = 0


class FirstBlock(Block[A, B]):
    input_model = A
    output_model = B

    async def run(self, inp: A) -> B:  # pragma: no cover - trivial
        return B()


class SecondBlock(Block[B, A]):
    input_model = B
    output_model = A

    async def run(self, inp: B) -> A:  # pragma: no cover - trivial
        return A()


def test_nested_assembly_without_cycle_allowed() -> None:
    inner = Assembly([FirstBlock()])
    outer = Assembly([inner])
    assert outer.input_model is inner.input_model


def test_detects_cycle_among_existing_assemblies() -> None:
    inner = Assembly([FirstBlock()])
    outer = Assembly([inner])
    # Inject a cycle: inner now contains outer
    inner._blocks.append(outer)  # simulate accidental cycle in graph

    with pytest.raises(CyclicAssemblyError):
        Assembly([inner])
