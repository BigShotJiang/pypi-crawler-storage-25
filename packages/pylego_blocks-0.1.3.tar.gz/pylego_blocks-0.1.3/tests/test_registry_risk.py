"""M107 — Risk-Adjusted Confidence 테스트."""

from __future__ import annotations

import pytest

from pylego import Block, Stud
from pylego.registry import BlockRegistry, BlockRuntimeStat, RegistryPolicy


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    x: int


class _Out(Stud):
    y: int


class _A(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


class _B(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────


def _reg(policy: RegistryPolicy | None = None) -> BlockRegistry:
    r = BlockRegistry()
    if policy:
        r.set_policy(policy)
    r.register(_A)
    r.register(_B)
    return r


def _fail(
    reg: BlockRegistry,
    name: str,
    n: int,
    error_type: str | None = None,
    severity: float | None = None,
) -> None:
    for _ in range(n):
        reg.update_stat(
            name,
            success=False,
            elapsed_sec=0.1,
            error_type=error_type,
            severity=severity,
        )


def _ok(reg: BlockRegistry, name: str, n: int) -> None:
    for _ in range(n):
        reg.update_stat(name, success=True, elapsed_sec=0.1)


# ── RegistryPolicy 기본값 ─────────────────────────────────────────────────────


def test_registry_policy_defaults() -> None:
    p = RegistryPolicy()
    assert p.error_severity_map == {}
    assert p.default_error_severity == 1.0


def test_registry_policy_custom_severity_map() -> None:
    p = RegistryPolicy(
        error_severity_map={"ValidationError": 0.2, "ConnectionError": 0.8}
    )
    assert p.error_severity_map["ValidationError"] == 0.2
    assert p.error_severity_map["ConnectionError"] == 0.8


# ── weighted_failure_rate ─────────────────────────────────────────────────────


def test_weighted_failure_rate_zero_when_no_runs() -> None:
    stat = BlockRuntimeStat()
    assert stat.weighted_failure_rate == 0.0


def test_weighted_failure_rate_low_severity() -> None:
    """ValidationError(0.2) 10회 실패 → weighted_rate < plain_failure_rate(1.0)."""
    policy = RegistryPolicy(error_severity_map={"ValidationError": 0.2})
    reg = _reg(policy)
    _fail(reg, "_A", 10, error_type="ValidationError")
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_rate == pytest.approx(0.2)
    assert stat.weighted_failure_rate < 1.0  # 이진 실패율(1.0)보다 낮음


def test_weighted_failure_rate_high_severity() -> None:
    """ConnectionError(0.8) 10회 실패 → weighted_rate == 0.8."""
    policy = RegistryPolicy(error_severity_map={"ConnectionError": 0.8})
    reg = _reg(policy)
    _fail(reg, "_A", 10, error_type="ConnectionError")
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_rate == pytest.approx(0.8)


def test_weighted_failure_rate_mixed_runs() -> None:
    """5회 성공 + 5회 실패(severity=0.4) → weighted_sum=2.0, total=10 → rate=0.2."""
    policy = RegistryPolicy(error_severity_map={"TimeoutError": 0.4})
    reg = _reg(policy)
    _ok(reg, "_A", 5)
    _fail(reg, "_A", 5, error_type="TimeoutError")
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_rate == pytest.approx(0.2)


def test_weighted_failure_rate_capped_at_1() -> None:
    """severity > 1.0 이 누적되어도 weighted_failure_rate 는 1.0 을 초과하지 않는다."""
    stat = BlockRuntimeStat()
    stat.failure_count = 1
    stat.weighted_failure_sum = 5.0  # 비정상 누적
    assert stat.weighted_failure_rate == 1.0


# ── risk_adjusted_confidence ──────────────────────────────────────────────────


def test_risk_adjusted_confidence_perfect() -> None:
    """성공만 있으면 risk_adjusted_confidence == confidence."""
    policy = RegistryPolicy(min_samples=5)
    reg = _reg(policy)
    _ok(reg, "_A", 10)
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.risk_adjusted_confidence == pytest.approx(stat.confidence)


def test_risk_adjusted_confidence_penalized_by_severity() -> None:
    """심각한 실패(severity=1.0) 가 있으면 risk_adjusted_confidence < confidence."""
    policy = RegistryPolicy(min_samples=5)
    reg = _reg(policy)
    _ok(reg, "_A", 8)
    _fail(reg, "_A", 2, severity=1.0)  # plain failure rate = 0.2, weighted = 1.0
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.risk_adjusted_confidence < stat.confidence


def test_risk_adjusted_confidence_less_penalized_for_low_severity() -> None:
    """경미한 실패(severity=0.1) 는 risk_adjusted_confidence 페널티가 작다."""
    policy = RegistryPolicy(min_samples=5, error_severity_map={"ValidationError": 0.1})
    reg = _reg(policy)
    _ok(reg, "_A", 8)
    _fail(reg, "_A", 2, error_type="ValidationError")  # weighted_rate = 0.02

    policy2 = RegistryPolicy(min_samples=5)
    reg2 = _reg(policy2)
    _ok(reg2, "_B", 8)
    _fail(reg2, "_B", 2, severity=1.0)  # weighted_rate = 0.2

    stat_low = reg.describe("_A").runtime
    stat_high = reg2.describe("_B").runtime
    assert stat_low is not None and stat_high is not None
    assert stat_low.risk_adjusted_confidence > stat_high.risk_adjusted_confidence


# ── ucb_score — risk_adjusted_confidence 기반 ────────────────────────────────


def test_ucb_score_penalizes_severe_failures() -> None:
    """동일 실패율, 심각도가 다른 두 블록: 심각한 쪽이 ucb_score 낮음."""
    policy = RegistryPolicy(
        min_samples=5,
        error_severity_map={"ValidationError": 0.1, "RuntimeError": 1.0},
    )
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.register(_B)

    _ok(reg, "_A", 8)
    _fail(reg, "_A", 2, error_type="ValidationError")

    _ok(reg, "_B", 8)
    _fail(reg, "_B", 2, error_type="RuntimeError")

    stat_a = reg.describe("_A").runtime
    stat_b = reg.describe("_B").runtime
    assert stat_a is not None and stat_b is not None
    assert stat_a.ucb_score > stat_b.ucb_score


def test_ucb_score_zero_when_no_runs() -> None:
    reg = _reg()
    stat = reg.describe("_A").runtime
    assert stat is None or stat.ucb_score == 0.0


# ── severity 추론 — error_type → policy ──────────────────────────────────────


def test_severity_inferred_from_error_type() -> None:
    policy = RegistryPolicy(error_severity_map={"TimeoutError": 0.5})
    reg = _reg(policy)
    _fail(reg, "_A", 4, error_type="TimeoutError")
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_sum == pytest.approx(4 * 0.5)


def test_explicit_severity_overrides_policy() -> None:
    """명시적 severity 파라미터는 policy 추론보다 우선한다."""
    policy = RegistryPolicy(error_severity_map={"TimeoutError": 0.5})
    reg = _reg(policy)
    reg.update_stat(
        "_A", success=False, elapsed_sec=0.1, error_type="TimeoutError", severity=0.9
    )
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_sum == pytest.approx(0.9)


def test_default_severity_fallback() -> None:
    """error_severity_map 에 없는 오류 타입 → default_error_severity(1.0) 적용."""
    policy = RegistryPolicy(
        error_severity_map={"ValidationError": 0.2},
        default_error_severity=1.0,
    )
    reg = _reg(policy)
    _fail(reg, "_A", 3, error_type="UnknownError")
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_sum == pytest.approx(3.0)


def test_no_error_type_uses_default_severity() -> None:
    """error_type 미전달 → default_error_severity 적용."""
    policy = RegistryPolicy(default_error_severity=0.7)
    reg = _reg(policy)
    reg.update_stat("_A", success=False, elapsed_sec=0.1)
    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_sum == pytest.approx(0.7)


# ── sort_by="smart" — risk_adjusted UCB 기반 ─────────────────────────────────


def test_sort_by_smart_uses_risk_adjusted_ucb() -> None:
    """sort_by='smart' 는 ucb_score(risk_adjusted) 내림차순이다."""
    policy = RegistryPolicy(
        min_samples=5,
        error_severity_map={"RuntimeError": 1.0, "ValidationError": 0.1},
    )
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_A)
    reg.register(_B)

    _ok(reg, "_A", 9)
    _fail(reg, "_A", 1, error_type="ValidationError")  # 낮은 심각도

    _ok(reg, "_B", 9)
    _fail(reg, "_B", 1, error_type="RuntimeError")  # 높은 심각도

    results = reg.search("", sort_by="smart")
    names = [i.name for i in results]
    assert names.index("_A") < names.index("_B")


# ── ingest_events error_type 연동 ─────────────────────────────────────────────


def test_ingest_events_passes_error_type() -> None:
    """ingest_events 가 BlockFailedEvent.error_type 을 update_stat 에 전달한다."""
    from pylego.core.events import BlockFailedEvent

    policy = RegistryPolicy(error_severity_map={"ValueError": 0.3})
    reg = _reg(policy)

    ev = BlockFailedEvent(
        block_name="_A",
        error=ValueError("bad"),
        elapsed_sec=0.1,
        timestamp=0.0,
        error_type="ValueError",
    )
    reg.ingest_events([ev])

    stat = reg.describe("_A").runtime
    assert stat is not None
    assert stat.weighted_failure_sum == pytest.approx(0.3)
