"""pylego.scheduler — cron/interval 실행 런처."""

from __future__ import annotations

import asyncio
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Literal, cast

from pylego.core.assembly import Assembly
from pylego.core.stud import Stud


def run_once(pipeline: Assembly[Any, Any], *, input: Stud) -> Stud:
    """파이프라인을 동기적으로 단 1회 실행한다."""
    return cast(Stud, pipeline.run_sync(input))


@dataclass
class ThawPolicy:
    """자율 동결 해제 정책 (설계 원칙 42).

    strategy:
      "manual"  — 기존 동작 유지. unfreeze() 직접 호출 필요 (기본값, 하위 호환).
      "canary"  — 동결 후 canary_interval_sec 마다 단일 잡 시험 실행.
                  success_threshold 회 연속 성공 시 전체 해제.
      "gradual" — canary 와 동일하게 시도하되, 매 성공마다 해제 비율을 높임
                  (현재 구현에서는 카운터 기반으로 canary 와 동일하게 동작).
    """

    strategy: Literal["manual", "canary", "gradual"] = "manual"
    canary_interval_sec: float = 300.0
    """카나리 시도 간격 (초)."""
    success_threshold: int = 3
    """연속 성공 횟수 → 전체 해제."""


@dataclass
class GlobalSchedulerPolicy:
    """전역 스케줄러 정책.

    max_killed_ratio                — killed 잡 비율이 이 값 이상이면 신규 잡 등록 차단.
    max_global_consecutive_failures — 전체 잡의 연속 실패 합산 한계. 초과 시 on_global_alert 호출.
    on_global_alert                 — 전역 경보 콜백. ``on_global_alert(message: str) -> None``
    freeze_on_alert                 — True 이면 전역 경보 발생 시 스케줄러를 자동 동결한다.
    on_freeze                       — 동결 시 콜백. ``on_freeze(reason: str) -> None``
    thaw_policy                     — 자율 해제 정책. None(기본값)이면 수동 해제만 가능.
    on_thaw                         — 자율 해제 시 콜백. ``on_thaw(reason: str) -> None``
    """

    max_killed_ratio: float | None = None
    max_global_consecutive_failures: int | None = None
    on_global_alert: Callable[[str], None] | None = None
    freeze_on_alert: bool = False
    on_freeze: Callable[[str], None] | None = None
    # M108 — Autonomous Thaw (설계 원칙 42)
    thaw_policy: ThawPolicy | None = None
    on_thaw: Callable[[str], None] | None = None
    # M112 — Post-thaw Observation Period (설계 원칙 45)
    post_thaw_observation_sec: float = 0.0
    """0.0 = 관찰 기간 없음 (기존 동작 유지). 양수이면 해제 후 recovering 상태 진입."""
    post_thaw_max_failure_rate: float = 0.3
    """recovering 기간 중 실패율이 이 값 초과 시 자동 재동결."""
    on_recovering: Callable[[str], None] | None = None
    """recovering 상태 진입 시 콜백."""
    # M116/M120 — Canary Throttling + Adaptive Ramp-up (설계 원칙 48/51)
    recovery_traffic_ratio: float = 1.0
    """recovering 상태에서 잡 실행 허용 비율 (0.0~1.0). adaptive_ramp_up=False 시 고정값."""
    recovery_ramp_up: bool = False
    """True이면 선형 상향. adaptive_ramp_up=True 이면 무시된다."""
    max_global_recovery_ratio: float = 1.0
    """전체 recovering 잡 동시 실행 허용 비율 상한. 1.0 = 상한 없음."""
    adaptive_ramp_up: bool = False
    """True이면 실시간 성공률로 recovery_traffic_ratio를 동적 조정한다."""
    adaptive_target_success_rate: float = 0.95
    """adaptive_ramp_up 목표 성공률. 초과 시 step_up, 미달 시 step_down."""
    adaptive_step_up: float = 0.1
    """성공 시 ratio 상향폭."""
    adaptive_step_down: float = 0.2
    """실패 시 ratio 하향폭 (빠른 제동)."""
    adaptive_min_ratio: float = 0.05
    """adaptive_ramp_up 시작값·하한값 (0 방지)."""


@dataclass
class SchedulerPolicy:
    """스케줄러 잡 제어 정책.

    max_consecutive_failures  — N회 연속 실패 시 잡을 비활성화한다.
    max_runs_per_hour         — 시간당 최대 실행 횟수. 초과하면 해당 실행을 건너뛴다.
    on_kill                   — 잡이 비활성화될 때 호출되는 콜백.
    suspended_retry_seconds   — 비활성화 후 자동 재시도 간격(초). None이면 수동 복구만 가능.
    max_recovery_attempts     — 자동 복구 최대 시도 횟수.
    probe_fn                  — 복구 시도 전 호출하는 라이브니스 체크 함수.
                                True 반환 시 진행, False 반환 시 이번 주기 건너뜀.
                                None(기본값)이면 체크 없이 바로 재시도한다 (하위 호환).
    probe_updates_registry    — True 이면 probe_fn 결과를 default_registry.update_stat()
                                에 반영한다. job_id 를 블록명으로 사용한다.
    """

    max_consecutive_failures: int | None = None
    max_runs_per_hour: int | None = None
    on_kill: Callable[[str, str], None] | None = None
    suspended_retry_seconds: float | None = None
    max_recovery_attempts: int = 1
    probe_fn: Callable[[], Awaitable[bool]] | None = None
    # M108 — Probe-Registry Bridge (설계 원칙 42)
    probe_updates_registry: bool = False
    # M112 — Smart Canary (설계 원칙 45)
    canary_priority: int = 0
    """낮을수록 카나리 선택 우선 (기본 0 = 우선순위 없음)."""


@dataclass
class JobStatus:
    """잡 실행 상태 스냅샷."""

    state: Literal["active", "suspended", "killed", "frozen"] = "active"
    consecutive_failures: int = 0
    total_runs: int = 0
    recovery_attempts: int = 0


class _JobState:
    """Scheduler 내부 잡 추적 상태."""

    def __init__(self, policy: SchedulerPolicy | None) -> None:
        self.policy = policy
        self.state: Literal["active", "suspended", "killed"] = "active"
        self.consecutive_failures: int = 0
        self.total_runs: int = 0
        self.recovery_attempts: int = 0
        self._run_timestamps: list[float] = []
        self._killed_at: float = 0.0

    def to_status(self) -> JobStatus:
        return JobStatus(
            state=self.state,
            consecutive_failures=self.consecutive_failures,
            total_runs=self.total_runs,
            recovery_attempts=self.recovery_attempts,
        )


def _require_apscheduler() -> Any:
    try:
        from apscheduler.schedulers.asyncio import AsyncIOScheduler
        return AsyncIOScheduler
    except ImportError as exc:
        raise ImportError(
            "apscheduler 가 설치되어 있지 않습니다. `pip install pylego[scheduler]`"
        ) from exc


class Scheduler:
    """cron 또는 interval 트리거로 파이프라인을 반복 실행한다."""

    def __init__(self) -> None:
        cls = _require_apscheduler()
        self._sched: Any = cls()
        self._pending: list[dict[str, Any]] = []
        self._job_states: dict[str, _JobState] = {}
        self._global_policy: GlobalSchedulerPolicy | None = None
        self._global_consecutive_failures: int = 0
        self._frozen: bool = False
        self._freeze_reason: str | None = None
        # M108 — Autonomous Thaw 상태
        self._thaw_consecutive_successes: int = 0
        self._last_canary_at: float = 0.0
        # _maybe_auto_thaw 에서 카나리 실행에 필요한 파이프라인·입력 맵
        self._job_entries: dict[str, tuple[Assembly[Any, Any], Stud]] = {}
        # M112 — Post-thaw Observation Period 상태
        self._recovering: bool = False
        self._recovery_start_at: float = 0.0
        self._recovery_runs: int = 0
        self._recovery_failures: int = 0
        # M120 — Canary Throttling / Adaptive Ramp-up 상태
        self._current_recovery_ratio: float = 1.0
        self._recovery_tick: int = 0

    def set_global_policy(self, policy: GlobalSchedulerPolicy) -> None:
        """전역 스케줄러 정책을 설정한다."""
        self._global_policy = policy

    def freeze(self, reason: str = "수동 동결") -> None:
        """스케줄러를 동결한다.

        동결 상태에서는 모든 잡의 신규 실행이 차단된다.
        진행 중인 실행은 완료까지 허용된다.
        """
        self._frozen = True
        self._freeze_reason = reason
        gp = self._global_policy
        if gp is not None and gp.on_freeze is not None:
            gp.on_freeze(reason)

    def unfreeze(self) -> None:
        """스케줄러 동결을 해제한다."""
        self._frozen = False
        self._freeze_reason = None
        self._recovering = False
        self._current_recovery_ratio = 1.0
        self._recovery_tick = 0

    def global_status(self) -> dict[str, Any]:
        """전체 잡의 상태 분포를 반환한다.

        Returns:
            ``{"active": n, "killed": n, "suspended": n, "total": n,
               "frozen": bool, "freeze_reason": str | None}``
        """
        gp_status = self._global_policy
        effective_ratio = self._current_recovery_ratio if self._recovering else 1.0
        counts: dict[str, Any] = {
            "active": 0,
            "killed": 0,
            "suspended": 0,
            "total": 0,
            "frozen": self._frozen,
            "freeze_reason": self._freeze_reason,
            "recovering": self._recovering,
            "max_global_recovery_ratio": (
                gp_status.max_global_recovery_ratio if gp_status is not None else 1.0
            ),
            "effective_recovery_ratio": effective_ratio,
        }
        for s in self._job_states.values():
            counts[s.state] += 1
            counts["total"] += 1
        return counts

    def add(
        self,
        pipeline: Assembly[Any, Any],
        *,
        input: Stud,
        cron: str | None = None,
        interval_seconds: float | None = None,
        job_id: str | None = None,
        policy: SchedulerPolicy | None = None,
    ) -> None:
        """파이프라인 실행 잡을 추가한다.

        ``cron`` 또는 ``interval_seconds`` 중 하나를 지정해야 한다.
        ``policy`` 를 지정하면 연속 실패 격리 및 시간당 실행 제한이 활성화된다.
        전역 정책의 ``max_killed_ratio`` 를 초과하면 ``ValueError`` 를 발생시킨다.
        """
        if cron is None and interval_seconds is None:
            raise ValueError("cron 또는 interval_seconds 중 하나를 지정해야 합니다")
        if cron is not None and interval_seconds is not None:
            raise ValueError("cron 과 interval_seconds 를 동시에 지정할 수 없습니다")

        # 전역 killed 비율 검사
        gp = self._global_policy
        if gp is not None and gp.max_killed_ratio is not None:
            total = len(self._job_states)
            if total > 0:
                killed_count = sum(
                    1 for s in self._job_states.values() if s.state == "killed"
                )
                ratio = killed_count / total
                if ratio >= gp.max_killed_ratio:
                    raise ValueError(
                        f"전역 killed 비율({ratio:.0%})이 최대치"
                        f"({gp.max_killed_ratio:.0%})를 초과하여 신규 잡 등록 불가"
                    )

        resolved_id: str = job_id if job_id is not None else str(uuid.uuid4())
        job_state = _JobState(policy)
        self._job_states[resolved_id] = job_state
        self._job_entries[resolved_id] = (pipeline, input)

        async def _run() -> None:
            # 동결 상태: 자율 해제 시도 후 여전히 동결이면 차단
            if self._frozen:
                await self._maybe_auto_thaw()
                if self._frozen:
                    return

            is_recovery = job_state.state == "suspended"

            if job_state.state == "killed":
                return

            if job_state.state == "suspended":
                if policy is None or policy.suspended_retry_seconds is None:
                    return
                if time.monotonic() - job_state._killed_at < policy.suspended_retry_seconds:
                    return
                # Circuit Probe: 복구 실행 전 라이브니스 체크
                if policy.probe_fn is not None:
                    probe_ok = await policy.probe_fn()
                    # M108 — probe_updates_registry: probe 결과를 registry 에 반영
                    if policy.probe_updates_registry:
                        from pylego.registry import default_registry  # noqa: PLC0415
                        default_registry.update_stat(
                            resolved_id,
                            success=probe_ok,
                            elapsed_sec=0.0,
                            error_type=None if probe_ok else "ProbeFailure",
                            severity=0.0 if probe_ok else 0.5,
                        )
                    if not probe_ok:
                        job_state._killed_at = time.monotonic()  # 타이머 리셋
                        return
                # 복구 시도 타이머 경과 — 실행 진행

            # 시간당 실행 제한 (복구 시도는 제한 미적용)
            if not is_recovery and policy is not None and policy.max_runs_per_hour is not None:
                now = time.monotonic()
                cutoff = now - 3600.0
                job_state._run_timestamps = [
                    t for t in job_state._run_timestamps if t > cutoff
                ]
                if len(job_state._run_timestamps) >= policy.max_runs_per_hour:
                    return
                job_state._run_timestamps.append(now)

            # M120 — Canary Throttling: recovering 상태에서 트래픽 비율 제어
            if self._recovering:
                gp4 = self._global_policy
                if gp4 is not None:
                    per_job = self._current_recovery_ratio
                    if gp4.max_global_recovery_ratio < 1.0:
                        active_count = max(
                            1, sum(1 for s in self._job_states.values() if s.state == "active")
                        )
                        global_per_job = gp4.max_global_recovery_ratio / active_count
                        per_job = min(per_job, global_per_job)
                    if per_job < 1.0:
                        step = max(1, round(1.0 / per_job))
                        should_skip = self._recovery_tick % step != 0
                        self._recovery_tick += 1
                        if should_skip:
                            return

            job_state.total_runs += 1

            _run_ok = False
            try:
                await pipeline.run(input)
                _run_ok = True
                job_state.consecutive_failures = 0
                if is_recovery:
                    job_state.state = "active"
                    job_state.recovery_attempts = 0
                # 전역 연속 실패 카운터 초기화
                self._global_consecutive_failures = 0
            except Exception:
                if is_recovery:
                    job_state.recovery_attempts += 1
                    max_rec = policy.max_recovery_attempts if policy is not None else 1
                    if job_state.recovery_attempts >= max_rec:
                        job_state.state = "killed"
                    else:
                        job_state._killed_at = time.monotonic()
                else:
                    job_state.consecutive_failures += 1
                    if (
                        policy is not None
                        and policy.max_consecutive_failures is not None
                        and job_state.consecutive_failures >= policy.max_consecutive_failures
                    ):
                        if policy.suspended_retry_seconds is not None:
                            job_state.state = "suspended"
                            job_state._killed_at = time.monotonic()
                        else:
                            job_state.state = "killed"
                        if policy.on_kill is not None:
                            reason = f"{job_state.consecutive_failures}회 연속 실패"
                            policy.on_kill(resolved_id, reason)

                # 전역 연속 실패 카운터 증가 및 경보
                self._global_consecutive_failures += 1
                gp2 = self._global_policy
                if (
                    gp2 is not None
                    and gp2.max_global_consecutive_failures is not None
                    and self._global_consecutive_failures
                    >= gp2.max_global_consecutive_failures
                ):
                    alert_msg = f"전역 연속 실패 {self._global_consecutive_failures}회 초과"
                    if gp2.on_global_alert is not None:
                        gp2.on_global_alert(alert_msg)
                    if gp2.freeze_on_alert:
                        self.freeze(alert_msg)

            # M112 — Post-thaw recovery tracking (설계 원칙 45)
            if self._recovering:
                self._recovery_runs += 1
                if not _run_ok:
                    self._recovery_failures += 1
                gp3 = self._global_policy
                if gp3 is not None and gp3.post_thaw_observation_sec > 0.0:
                    failure_rate = self._recovery_failures / self._recovery_runs
                    if failure_rate > gp3.post_thaw_max_failure_rate:
                        self._recovering = False
                        refreeze_reason = (
                            f"복구 관찰 기간 중 실패율 {failure_rate:.1%} 초과 — 재동결"
                        )
                        self.freeze(refreeze_reason)
                    elif (
                        time.monotonic() - self._recovery_start_at
                        >= gp3.post_thaw_observation_sec
                    ):
                        self._recovering = False
                        if gp3.on_thaw is not None:
                            gp3.on_thaw("복구 관찰 기간 완료 — 완전 복귀")
                    # M120 — Adaptive Ramp-up 조정 (adaptive_ramp_up=True일 때만)
                    if self._recovering and gp3.adaptive_ramp_up:
                        if _run_ok:
                            self._current_recovery_ratio = min(
                                1.0, self._current_recovery_ratio + gp3.adaptive_step_up
                            )
                        else:
                            self._current_recovery_ratio = max(
                                gp3.adaptive_min_ratio,
                                self._current_recovery_ratio - gp3.adaptive_step_down,
                            )

        if interval_seconds is not None:
            self._sched.add_job(
                _run,
                trigger="interval",
                seconds=interval_seconds,
                id=resolved_id,
            )
        else:
            from apscheduler.triggers.cron import CronTrigger  # noqa: PLC0415
            trigger = CronTrigger.from_crontab(cron)
            self._sched.add_job(_run, trigger=trigger, id=resolved_id)

    async def _maybe_auto_thaw(self) -> None:
        """동결 상태에서 ThawPolicy 에 따라 자율 해제를 시도한다."""
        if not self._frozen:
            return
        gp = self._global_policy
        if gp is None or gp.thaw_policy is None:
            return
        tp = gp.thaw_policy
        if tp.strategy == "manual":
            return

        now = time.monotonic()
        if now - self._last_canary_at < tp.canary_interval_sec:
            return
        self._last_canary_at = now

        # M112 — Smart Canary: canary_priority(낮을수록 우선) → 평균 지연(낮을수록 우선)
        active_ids = [jid for jid, s in self._job_states.items() if s.state == "active"]
        if not active_ids:
            return

        def _canary_key(jid: str) -> tuple[int, float]:
            js = self._job_states[jid]
            prio = js.policy.canary_priority if js.policy is not None else 0
            try:
                from pylego.registry import default_registry  # noqa: PLC0415
                info = default_registry.describe(jid)
                latency = info.runtime.avg_elapsed_sec if info.runtime else float("inf")
            except KeyError:
                latency = float("inf")
            return (prio, latency)

        canary_id = min(active_ids, key=_canary_key)
        entry = self._job_entries.get(canary_id)
        if entry is None:
            return
        canary_pipeline, canary_input = entry

        # 임시 해제 후 단일 실행
        self._frozen = False
        try:
            await canary_pipeline.run(canary_input)
            self._thaw_consecutive_successes += 1
        except Exception:
            self._thaw_consecutive_successes = 0
            self._frozen = True
            return

        if self._thaw_consecutive_successes >= tp.success_threshold:
            self._thaw_consecutive_successes = 0
            obs_sec = gp.post_thaw_observation_sec
            if obs_sec > 0.0:
                # M112 — recovering 상태 진입
                self._recovering = True
                self._recovery_start_at = time.monotonic()
                self._recovery_runs = 0
                self._recovery_failures = 0
                # M120 — 초기 ratio: adaptive이면 min_ratio, 아니면 recovery_traffic_ratio
                self._current_recovery_ratio = (
                    gp.adaptive_min_ratio if gp.adaptive_ramp_up else gp.recovery_traffic_ratio
                )
                self._recovery_tick = 0
                reason = (
                    f"recovering 진입: {tp.success_threshold}회 카나리 성공, "
                    f"관찰 기간 {obs_sec}초"
                )
                if gp.on_recovering is not None:
                    gp.on_recovering(reason)
            else:
                # 관찰 기간 없음 — 즉시 완전 해제 (기존 동작)
                self._frozen = False
                reason = f"자율 해제: {tp.success_threshold}회 연속 카나리 성공"
                if gp.on_thaw is not None:
                    gp.on_thaw(reason)
        else:
            # threshold 미달 — 재동결
            self._frozen = True

    def job_status(self, job_id: str) -> JobStatus:
        """잡 상태를 반환한다. 등록되지 않은 job_id 면 KeyError."""
        return self._job_states[job_id].to_status()

    async def start(self) -> None:
        """스케줄러를 시작한다 (현재 이벤트 루프에 부착)."""
        self._sched.start()

    async def stop(self) -> None:
        """스케줄러를 중단한다."""
        self._sched.shutdown(wait=False)
