"""TemplateBlock — Jinja2 템플릿 렌더링 블록.

pylego[jinja2] 설치 필요: `pip install pylego[jinja2]`
"""

from __future__ import annotations

from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class TemplateInput(Stud):
    """Jinja2 템플릿 렌더링 입력 계약."""

    template: str
    context: dict[str, Any] = {}


class TemplateResult(Stud):
    """Jinja2 템플릿 렌더링 결과 계약."""

    rendered: str


class TemplateBlock(Block[TemplateInput, TemplateResult]):
    """Jinja2 템플릿 문자열을 렌더링하는 블록.

    `context` 딕셔너리의 값을 템플릿 변수로 주입한다.
    파이프라인에서 AI 출력이나 DB 결과를 프롬프트·메시지·HTML 등으로
    변환할 때 사용한다.

    Example:
        ```python
        block = TemplateBlock()
        result = await block.run(TemplateInput(
            template="안녕하세요, {{ name }}님! 총 {{ count }}개의 항목이 있습니다.",
            context={"name": "홍길동", "count": 42},
        ))
        print(result.rendered)
        # → 안녕하세요, 홍길동님! 총 42개의 항목이 있습니다.
        ```
    """

    input_model = TemplateInput
    output_model = TemplateResult

    async def run(self, inp: TemplateInput) -> TemplateResult:
        try:
            from jinja2 import Template
        except ImportError as exc:
            raise ImportError(
                "jinja2 가 설치되어 있지 않습니다. `pip install pylego[jinja2]`"
            ) from exc

        tmpl = Template(inp.template)
        rendered: str = tmpl.render(**inp.context)
        return TemplateResult(rendered=rendered)
