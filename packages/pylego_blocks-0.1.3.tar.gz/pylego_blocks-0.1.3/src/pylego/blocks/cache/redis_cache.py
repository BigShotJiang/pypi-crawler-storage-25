"""RedisCacheBlock — Redis 캐시 읽기/쓰기/삭제 블록.

pylego[redis] 설치 필요: `pip install pylego[redis]`
"""

from __future__ import annotations

import os
from typing import Literal

from pylego.core.block import Block
from pylego.core.stud import Stud


class CacheInput(Stud):
    """Redis 캐시 연산 입력 계약.

    operation:
        - "get"    : key 조회. 없으면 hit=False, value=None.
        - "set"    : key 저장. value 필수, ttl(초) 선택.
        - "delete" : key 삭제.
    """

    operation: Literal["get", "set", "delete"]
    key: str
    value: str | None = None
    ttl: int | None = None
    namespace: str = ""


class CacheResult(Stud):
    """Redis 캐시 연산 결과 계약."""

    value: str | None
    hit: bool
    ok: bool


class RedisCacheBlock(Block[CacheInput, CacheResult]):
    """Redis 캐시 get/set/delete 블록.

    Args:
        url: Redis 연결 URL. 미설정 시 PYLEGO_REDIS_URL 또는 redis://localhost:6379.

    Example:
        ```python
        cache = RedisCacheBlock()

        # 저장
        await cache.run(CacheInput(operation="set", key="user:1", value="홍길동", ttl=300))

        # 조회
        result = await cache.run(CacheInput(operation="get", key="user:1"))
        print(result.value, result.hit)  # 홍길동 True

        # 삭제
        await cache.run(CacheInput(operation="delete", key="user:1"))
        ```
    """

    input_model = CacheInput
    output_model = CacheResult

    def __init__(self, url: str | None = None) -> None:
        self._url = url or os.getenv("PYLEGO_REDIS_URL", "redis://localhost:6379")

    async def run(self, inp: CacheInput) -> CacheResult:
        try:
            from redis.asyncio import Redis
        except ImportError as exc:
            raise ImportError(
                "redis 가 설치되어 있지 않습니다. `pip install pylego[redis]`"
            ) from exc

        full_key = f"{inp.namespace}:{inp.key}" if inp.namespace else inp.key

        async with Redis.from_url(self._url) as client:
            if inp.operation == "get":
                raw: bytes | None = await client.get(full_key)
                if raw is None:
                    return CacheResult(value=None, hit=False, ok=True)
                return CacheResult(value=raw.decode("utf-8"), hit=True, ok=True)

            if inp.operation == "set":
                if inp.value is None:
                    raise ValueError("set 연산에는 value 가 필요합니다")
                await client.set(full_key, inp.value, ex=inp.ttl)
                return CacheResult(value=inp.value, hit=False, ok=True)

            # delete
            await client.delete(full_key)
            return CacheResult(value=None, hit=False, ok=True)
