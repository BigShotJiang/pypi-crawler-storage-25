"""EmbeddingBlock — 텍스트 임베딩 생성 블록.

OpenAI text-embedding API 와 Ollama /api/embeddings 를 지원한다.
pylego[openai] 또는 pylego[ollama] 설치 필요.
"""

from __future__ import annotations

import os
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class EmbeddingInput(Stud):
    """텍스트 임베딩 입력 계약."""

    texts: list[str]
    model: str = "text-embedding-3-small"
    backend: str = "openai"


class EmbeddingResult(Stud):
    """텍스트 임베딩 결과 계약."""

    embeddings: list[list[float]]
    model: str
    total_tokens: int


class EmbeddingBlock(Block[EmbeddingInput, EmbeddingResult]):
    """텍스트 → 임베딩 벡터 변환 블록.

    Args:
        api_key: API 키. 미설정 시 환경변수 사용.
        base_url: Ollama 백엔드 URL (backend="ollama" 시 사용).

    Example:
        ```python
        # OpenAI 임베딩 (기본)
        block = EmbeddingBlock()
        result = await block.run(EmbeddingInput(
            texts=["안녕하세요", "파이썬이란?"],
            model="text-embedding-3-small",
        ))
        # result.embeddings: list[list[float]]  길이 2, 각 벡터 차원 1536

        # Ollama 임베딩
        result = await block.run(EmbeddingInput(
            texts=["Hello world"],
            model="nomic-embed-text",
            backend="ollama",
        ))
        ```
    """

    input_model = EmbeddingInput
    output_model = EmbeddingResult

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "http://localhost:11434",
    ) -> None:
        self._api_key = api_key
        self._ollama_base_url = base_url

    async def run(self, inp: EmbeddingInput) -> EmbeddingResult:
        if inp.backend == "ollama":
            return await self._run_ollama(inp)
        return await self._run_openai(inp)

    async def _run_openai(self, inp: EmbeddingInput) -> EmbeddingResult:
        try:
            import openai
        except ImportError as exc:
            raise ImportError(
                "openai 가 설치되어 있지 않습니다. `pip install pylego[openai]`"
            ) from exc

        key = self._api_key or os.getenv("OPENAI_API_KEY")
        client = openai.AsyncOpenAI(api_key=key)
        resp = await client.embeddings.create(input=inp.texts, model=inp.model)
        embeddings = [item.embedding for item in resp.data]
        total = resp.usage.total_tokens if resp.usage else 0
        return EmbeddingResult(
            embeddings=embeddings,
            model=resp.model,
            total_tokens=total,
        )

    async def _run_ollama(self, inp: EmbeddingInput) -> EmbeddingResult:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx 가 설치되어 있지 않습니다. `pip install pylego[ollama]`"
            ) from exc

        embeddings: list[list[float]] = []
        async with httpx.AsyncClient(timeout=60.0) as client:
            for text in inp.texts:
                resp = await client.post(
                    f"{self._ollama_base_url}/api/embeddings",
                    json={"model": inp.model, "prompt": text},
                )
                resp.raise_for_status()
                data: dict[str, Any] = resp.json()
                embeddings.append(data["embedding"])

        return EmbeddingResult(
            embeddings=embeddings,
            model=inp.model,
            total_tokens=0,
        )
