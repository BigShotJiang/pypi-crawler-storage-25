"""AnthropicBlock — Anthropic Claude API 블록.

pylego[anthropic] 설치 필요: `pip install pylego[anthropic]`
"""

from __future__ import annotations

import os
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class AnthropicInput(Stud):
    """Anthropic 메시지 API 입력 계약."""

    model: str = "claude-opus-4-5"
    messages: list[dict[str, Any]]
    system: str | None = None
    max_tokens: int = 1024
    temperature: float = 1.0


class AnthropicResult(Stud):
    """Anthropic 메시지 API 결과 계약."""

    content: str
    model: str
    stop_reason: str | None
    input_tokens: int
    output_tokens: int


class AnthropicBlock(Block[AnthropicInput, AnthropicResult]):
    """Anthropic Claude Messages API 블록.

    Args:
        api_key: Anthropic API 키. 미설정 시 ANTHROPIC_API_KEY 환경변수 사용.

    Example:
        ```python
        block = AnthropicBlock()
        result = await block.run(AnthropicInput(
            model="claude-opus-4-5",
            messages=[{"role": "user", "content": "안녕하세요"}],
            max_tokens=256,
        ))
        print(result.content)
        ```
    """

    input_model = AnthropicInput
    output_model = AnthropicResult

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key or os.getenv("ANTHROPIC_API_KEY")

    async def run(self, inp: AnthropicInput) -> AnthropicResult:
        try:
            import anthropic
        except ImportError as exc:
            raise ImportError(
                "anthropic 가 설치되어 있지 않습니다. `pip install pylego[anthropic]`"
            ) from exc

        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        kwargs: dict[str, Any] = {
            "model": inp.model,
            "messages": list(inp.messages),
            "max_tokens": inp.max_tokens,
            "temperature": inp.temperature,
        }
        if inp.system is not None:
            kwargs["system"] = inp.system

        msg = await client.messages.create(**kwargs)

        text_parts: list[str] = []
        for block in msg.content:
            text = getattr(block, "text", None)
            if isinstance(text, str):
                text_parts.append(text)

        return AnthropicResult(
            content="\n".join(text_parts),
            model=msg.model,
            stop_reason=msg.stop_reason,
            input_tokens=msg.usage.input_tokens,
            output_tokens=msg.usage.output_tokens,
        )
