"""OpenAiBlock — OpenAI Chat Completions API 블록.

pylego[openai] 설치 필요: `pip install pylego[openai]`
"""

from __future__ import annotations

import os
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class OpenAiInput(Stud):
    """OpenAI Chat Completions 입력 계약."""

    model: str = "gpt-4o"
    messages: list[dict[str, Any]]
    temperature: float = 1.0
    max_tokens: int | None = None
    system: str | None = None


class OpenAiResult(Stud):
    """OpenAI Chat Completions 결과 계약."""

    content: str
    model: str
    finish_reason: str | None
    prompt_tokens: int
    completion_tokens: int


class OpenAiBlock(Block[OpenAiInput, OpenAiResult]):
    """OpenAI Chat Completions API 블록.

    Args:
        api_key: OpenAI API 키. 미설정 시 OPENAI_API_KEY 환경변수 사용.
        base_url: API 엔드포인트. 커스텀 호환 API(예: Azure, 로컬 LLM) 지원.

    Example:
        ```python
        block = OpenAiBlock()
        result = await block.run(OpenAiInput(
            model="gpt-4o",
            messages=[{"role": "user", "content": "안녕하세요"}],
            max_tokens=256,
        ))
        print(result.content)
        ```
    """

    input_model = OpenAiInput
    output_model = OpenAiResult

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._api_key = api_key or os.getenv("OPENAI_API_KEY")
        self._base_url = base_url

    async def run(self, inp: OpenAiInput) -> OpenAiResult:
        try:
            import openai
        except ImportError as exc:
            raise ImportError(
                "openai 가 설치되어 있지 않습니다. `pip install pylego[openai]`"
            ) from exc

        kwargs: dict[str, Any] = {}
        if self._base_url is not None:
            kwargs["base_url"] = self._base_url

        client = openai.AsyncOpenAI(api_key=self._api_key, **kwargs)

        messages: list[dict[str, Any]] = []
        if inp.system is not None:
            messages.append({"role": "system", "content": inp.system})
        messages.extend(inp.messages)

        create_kwargs: dict[str, Any] = {
            "model": inp.model,
            "messages": messages,
            "temperature": inp.temperature,
        }
        if inp.max_tokens is not None:
            create_kwargs["max_tokens"] = inp.max_tokens

        resp = await client.chat.completions.create(**create_kwargs)
        choice = resp.choices[0]
        content = choice.message.content or ""
        usage = resp.usage

        return OpenAiResult(
            content=content,
            model=resp.model,
            finish_reason=choice.finish_reason,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
        )
