"""DuckDuckGoSearchBlock — API 키 없이 DuckDuckGo 텍스트 검색 블록.

설치:
    pip install pylego[duckduckgo]

기본 사용:
    block = DuckDuckGoSearchBlock()
    result = await block.run(DuckDuckGoSearchInput(query="pylego python"))

GoogleSearchResult / SearchItem 을 재사용하므로 FallbackBlock 으로
GoogleSearchBlock 과 투명하게 교체할 수 있다.
"""

from __future__ import annotations

import asyncio
from typing import Any

from pylego.blocks.search.google import GoogleSearchResult, SearchItem
from pylego.core.block import Block
from pylego.core.stud import Stud


class DuckDuckGoSearchInput(Stud):
    """DuckDuckGo 검색 요청 입력."""

    query: str
    num: int = 5


# GoogleSearchResult 와 동일 구조 재사용 — FallbackBlock 조합 시 타입 호환
DuckDuckGoSearchResult = GoogleSearchResult


class DuckDuckGoSearchBlock(Block[DuckDuckGoSearchInput, GoogleSearchResult]):
    """API 키 없이 DuckDuckGo 텍스트 검색을 수행하는 블록.

    ``duckduckgo-search`` 패키지의 동기 ``DDGS().text()`` 를
    ``asyncio.to_thread`` 로 감싸 비동기 환경에서 실행한다.

    Raises:
        ImportError: ``duckduckgo-search`` 미설치 시.
    """

    input_model = DuckDuckGoSearchInput
    output_model = GoogleSearchResult
    _extra = "pylego[duckduckgo]"

    async def run(self, inp: DuckDuckGoSearchInput) -> GoogleSearchResult:
        """DuckDuckGo 텍스트 검색을 실행하고 결과를 반환.

        Args:
            inp: 검색 요청 입력.

        Returns:
            ``GoogleSearchResult`` Stud 인스턴스 (SearchItem 목록 포함).

        Raises:
            ImportError: ``duckduckgo-search`` 가 설치되어 있지 않을 때.
        """
        try:
            from duckduckgo_search import DDGS
        except ImportError:
            raise ImportError(
                "duckduckgo-search 가 설치되어 있지 않습니다. "
                "`pip install pylego[duckduckgo]`"
            ) from None

        def _search() -> list[dict[str, Any]]:
            return list(DDGS().text(inp.query, max_results=inp.num))

        results: list[dict[str, Any]] = await asyncio.to_thread(_search)
        items = [
            SearchItem(
                title=r.get("title", ""),
                link=r.get("href", ""),
                snippet=r.get("body", ""),
            )
            for r in results
        ]
        return GoogleSearchResult(items=items, total_results=str(len(items)))
