"""GoogleSearchBlock — Google Custom Search JSON API 블록.

설치:
    pip install pylego[google-search]

기본 사용:
    block = GoogleSearchBlock(api_key="KEY", search_engine_id="CX")
    result = await block.run(GoogleSearchInput(query="pylego python"))

환경변수:
    PYLEGO_GOOGLE_SEARCH_API_KEY    — api_key 미지정 시 fallback
    PYLEGO_GOOGLE_SEARCH_ENGINE_ID  — search_engine_id 미지정 시 fallback
"""

from __future__ import annotations

import os
from typing import Any

from pydantic import field_validator

from pylego.blocks.http import HttpBlock
from pylego.core.stud import Stud

_SEARCH_API_URL = "https://www.googleapis.com/customsearch/v1"


class SearchItem(Stud):
    """검색 결과 단건."""

    title: str
    link: str
    snippet: str


class GoogleSearchInput(Stud):
    """Google Custom Search 요청 입력."""

    query: str
    num: int = 5
    lang: str = "ko"

    @field_validator("num")
    @classmethod
    def num_in_range(cls, v: int) -> int:
        if not (1 <= v <= 10):
            raise ValueError(f"num 은 1~10 범위이어야 합니다: {v}")
        return v


class GoogleSearchResult(Stud):
    """Google Custom Search 응답 결과."""

    items: list[SearchItem]
    total_results: str


class GoogleSearchBlock(HttpBlock[GoogleSearchInput, GoogleSearchResult]):
    """Google Custom Search JSON API 를 호출하는 블록.

    Args:
        api_key: Google API 키.
                 None 이면 ``PYLEGO_GOOGLE_SEARCH_API_KEY`` 환경변수 사용.
        search_engine_id: Custom Search 엔진 ID (cx).
                          None 이면 ``PYLEGO_GOOGLE_SEARCH_ENGINE_ID`` 환경변수 사용.

    Raises:
        ValueError: api_key 또는 search_engine_id 가 없을 때.
    """

    input_model = GoogleSearchInput
    output_model = GoogleSearchResult
    _extra = "pylego[google-search]"

    def __init__(
        self,
        api_key: str | None = None,
        search_engine_id: str | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("PYLEGO_GOOGLE_SEARCH_API_KEY")
        if not resolved_key:
            raise ValueError(
                "api_key 또는 PYLEGO_GOOGLE_SEARCH_API_KEY 환경변수가 필요합니다."
            )

        resolved_cx = search_engine_id or os.environ.get("PYLEGO_GOOGLE_SEARCH_ENGINE_ID")
        if not resolved_cx:
            raise ValueError(
                "search_engine_id 또는 PYLEGO_GOOGLE_SEARCH_ENGINE_ID 환경변수가 필요합니다."
            )

        self._api_key = resolved_key
        self._search_engine_id = resolved_cx

    def _build_request(
        self, inp: GoogleSearchInput
    ) -> tuple[str, str, dict[str, Any]]:
        # GET 요청이므로 json body 는 사용하지 않는다.
        # run() 을 override 하여 params 로 전달한다.
        return "GET", _SEARCH_API_URL, {}

    def _parse_response(self, data: dict[str, Any]) -> GoogleSearchResult:
        raw_items: list[dict[str, Any]] = data.get("items") or []
        items = [
            SearchItem(
                title=str(item.get("title", "")),
                link=str(item.get("link", "")),
                snippet=str(item.get("snippet", "")),
            )
            for item in raw_items
        ]
        total_results: str = (
            data.get("searchInformation", {}).get("totalResults", "0")
        )
        return GoogleSearchResult(items=items, total_results=total_results)

    async def run(self, inp: GoogleSearchInput) -> GoogleSearchResult:
        """GET 요청으로 Google Custom Search API 를 호출하고 결과를 반환.

        Args:
            inp: 검색 요청 입력.

        Returns:
            검색 결과 Stud 인스턴스.

        Raises:
            ImportError: httpx 가 설치되어 있지 않을 때.
            httpx.HTTPStatusError: 4xx / 5xx 응답일 때 (raise_for_status).
        """
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                f"httpx 가 설치되어 있지 않습니다. `pip install {self._extra}`"
            ) from exc

        params: dict[str, str | int] = {
            "key": self._api_key,
            "cx": self._search_engine_id,
            "q": inp.query,
            "num": inp.num,
            "lr": f"lang_{inp.lang}",
        }
        async with httpx.AsyncClient() as client:
            resp = await client.get(_SEARCH_API_URL, params=params)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return self._parse_response(data)
