"""SlackBlock — Slack Incoming Webhook 메시지 전송 블록.

설치:
    pip install pylego[slack]

기본 사용:
    block = SlackBlock(webhook_url="https://hooks.slack.com/services/...")
    result = await block.run(SlackInput(text="파이프라인 완료"))

환경변수:
    PYLEGO_SLACK_WEBHOOK_URL — webhook_url 미지정 시 fallback
"""

from __future__ import annotations

import os
from typing import Any

from pylego.blocks.http import HttpBlock
from pylego.core.stud import Stud


class SlackInput(Stud):
    text: str
    channel: str | None = None
    username: str | None = None
    icon_emoji: str | None = None


class SlackResult(Stud):
    ok: bool


class SlackBlock(HttpBlock[SlackInput, SlackResult]):
    """Slack Incoming Webhook API 로 메시지를 전송하는 블록.

    Args:
        webhook_url: Slack Incoming Webhook URL.
                     None 이면 ``PYLEGO_SLACK_WEBHOOK_URL`` 환경변수 사용.
    """

    input_model = SlackInput
    output_model = SlackResult
    _extra = "pylego[slack]"

    def __init__(self, webhook_url: str | None = None) -> None:
        resolved = webhook_url or os.environ.get("PYLEGO_SLACK_WEBHOOK_URL")
        if not resolved:
            raise ValueError(
                "webhook_url 또는 PYLEGO_SLACK_WEBHOOK_URL 환경변수가 필요합니다."
            )
        self._webhook_url = resolved

    def _build_request(
        self, inp: SlackInput
    ) -> tuple[str, str, dict[str, Any]]:
        body: dict[str, Any] = {"text": inp.text}
        if inp.channel is not None:
            body["channel"] = inp.channel
        if inp.username is not None:
            body["username"] = inp.username
        if inp.icon_emoji is not None:
            body["icon_emoji"] = inp.icon_emoji
        return "POST", self._webhook_url, body

    def _parse_response(self, data: dict[str, Any]) -> SlackResult:
        # Slack Webhook 성공 응답은 "ok" 문자열(str).
        # 실패 응답은 JSON dict ({"error": "..."}).
        # resp.json() 은 런타임에서 str 또는 dict 를 반환할 수 있으므로
        # isinstance 분기로 처리한다.
        raw: Any = data
        if isinstance(raw, str):
            return SlackResult(ok=raw == "ok")
        return SlackResult(ok=bool(raw.get("ok", True)))
