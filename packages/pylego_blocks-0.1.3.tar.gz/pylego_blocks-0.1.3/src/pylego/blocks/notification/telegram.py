"""TelegramBlock — Telegram Bot API 메시지 전송 블록.

설치:
    pip install pylego[telegram]

기본 사용:
    block = TelegramBlock(token="BOT_TOKEN")
    result = await block.run(TelegramInput(chat_id="123456", text="완료"))

사이드채널 알림 (파이프라인 흐름 유지):
    pipeline = Assembly([ProcessBlock(), TapBlock(TelegramBlock(token="BOT_TOKEN"))])

환경변수:
    PYLEGO_TELEGRAM_TOKEN  — 토큰 미지정 시 fallback
"""

from __future__ import annotations

import os
from typing import Any

from pylego.blocks.http import HttpBlock
from pylego.core.stud import Stud

_API_BASE = "https://api.telegram.org"


class TelegramInput(Stud):
    chat_id: str
    text: str
    parse_mode: str = "HTML"


class TelegramResult(Stud):
    message_id: int
    chat_id: str


class TelegramBlock(HttpBlock[TelegramInput, TelegramResult]):
    """`sendMessage` API 로 텔레그램 메시지를 전송하는 블록.

    Args:
        token: Telegram Bot API 토큰.
               None 이면 ``PYLEGO_TELEGRAM_TOKEN`` 환경변수 사용.
    """

    input_model = TelegramInput
    output_model = TelegramResult
    _extra = "pylego[telegram]"

    def __init__(self, token: str | None = None) -> None:
        resolved = token or os.environ.get("PYLEGO_TELEGRAM_TOKEN")
        if not resolved:
            raise ValueError(
                "token 또는 PYLEGO_TELEGRAM_TOKEN 환경변수가 필요합니다."
            )
        self._token = resolved

    def _build_request(
        self, inp: TelegramInput
    ) -> tuple[str, str, dict[str, Any]]:
        url = f"{_API_BASE}/bot{self._token}/sendMessage"
        body: dict[str, Any] = {
            "chat_id": inp.chat_id,
            "text": inp.text,
            "parse_mode": inp.parse_mode,
        }
        return "POST", url, body

    def _parse_response(self, data: dict[str, Any]) -> TelegramResult:
        if not data.get("ok"):
            raise RuntimeError(f"Telegram API 오류: {data}")
        result = data["result"]
        assert isinstance(result, dict)
        return TelegramResult(
            message_id=int(result["message_id"]),
            chat_id=str(result["chat"]["id"]),
        )
