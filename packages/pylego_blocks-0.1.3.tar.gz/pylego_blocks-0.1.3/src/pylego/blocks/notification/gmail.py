"""GmailBlock — Gmail SMTP 메일 전송 블록.

설치:
    pip install pylego[gmail]

기본 사용:
    block = GmailBlock(smtp_user="user@gmail.com", smtp_password="APP_PW")
    result = await block.run(GmailInput(to="recv@example.com", subject="제목", body="내용"))

사이드채널 알림 (파이프라인 흐름 유지):
    pipeline = Assembly([ProcessBlock(), TapBlock(GmailBlock(...))])

환경변수:
    PYLEGO_GMAIL_USER      — smtp_user 미지정 시 fallback
    PYLEGO_GMAIL_PASSWORD  — smtp_password 미지정 시 fallback
"""

from __future__ import annotations

import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from pylego.core.block import Block
from pylego.core.stud import Stud

_SMTP_HOST = "smtp.gmail.com"
_SMTP_PORT = 587


class GmailInput(Stud):
    to: str
    subject: str
    body: str
    html: bool = False


class GmailResult(Stud):
    accepted: list[str]


class GmailBlock(Block[GmailInput, GmailResult]):
    """Gmail SMTP(STARTTLS) 로 메일을 전송하는 블록.

    Args:
        smtp_user: Gmail 계정 주소.
                   None 이면 ``PYLEGO_GMAIL_USER`` 환경변수 사용.
        smtp_password: Gmail 앱 비밀번호.
                       None 이면 ``PYLEGO_GMAIL_PASSWORD`` 환경변수 사용.
    """

    input_model = GmailInput
    output_model = GmailResult

    def __init__(
        self,
        smtp_user: str | None = None,
        smtp_password: str | None = None,
    ) -> None:
        resolved_user = smtp_user or os.environ.get("PYLEGO_GMAIL_USER")
        resolved_pw = smtp_password or os.environ.get("PYLEGO_GMAIL_PASSWORD")
        if not resolved_user or not resolved_pw:
            raise ValueError(
                "smtp_user/smtp_password 또는 "
                "PYLEGO_GMAIL_USER/PYLEGO_GMAIL_PASSWORD 환경변수가 필요합니다."
            )
        self._user = resolved_user
        self._password = resolved_pw

    async def run(self, inp: GmailInput) -> GmailResult:
        try:
            import aiosmtplib
        except ImportError as exc:
            raise ImportError(
                "aiosmtplib 이 설치되어 있지 않습니다. `pip install pylego[gmail]`"
            ) from exc

        msg: MIMEMultipart | MIMEText
        if inp.html:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = inp.subject
            msg["From"] = self._user
            msg["To"] = inp.to
            msg.attach(MIMEText(inp.body, "html", "utf-8"))
        else:
            msg = MIMEText(inp.body, "plain", "utf-8")
            msg["Subject"] = inp.subject
            msg["From"] = self._user
            msg["To"] = inp.to

        errors, _ = await aiosmtplib.send(
            msg,
            hostname=_SMTP_HOST,
            port=_SMTP_PORT,
            username=self._user,
            password=self._password,
            start_tls=True,
        )

        if errors:
            raise RuntimeError(f"Gmail 전송 오류: {errors}")

        return GmailResult(accepted=[inp.to])
