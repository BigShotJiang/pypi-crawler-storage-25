"""ChunkTextBlock — 재귀적 텍스트 청킹 블록.

표준 라이브러리만 사용 — 추가 의존성 없음.
LangChain RecursiveCharacterTextSplitter 와 동일한 알고리즘.
"""

from __future__ import annotations

from pylego.core.block import Block
from pylego.core.stud import Stud


class ChunkTextInput(Stud):
    """텍스트 청킹 입력 계약."""

    text: str
    chunk_size: int = 1000
    chunk_overlap: int = 200
    separators: list[str] = ["\n\n", "\n", " ", ""]


class ChunkTextResult(Stud):
    """텍스트 청킹 결과 계약."""

    chunks: list[str]
    chunk_count: int


def _merge_splits(
    splits: list[str],
    separator: str,
    chunk_size: int,
    chunk_overlap: int,
) -> list[str]:
    """분리된 조각들을 chunk_size 이하의 청크로 합친다. 연속 청크 간 chunk_overlap 유지."""
    chunks: list[str] = []
    buf: list[str] = []
    buf_len: int = 0
    sep_len = len(separator)

    for piece in splits:
        piece_len = len(piece)
        addition = (sep_len if buf else 0) + piece_len

        if buf_len + addition > chunk_size and buf:
            chunks.append(separator.join(buf))
            # 오버랩 유지: 앞쪽 조각을 제거해 buf_len <= chunk_overlap 이 될 때까지
            while buf and buf_len > chunk_overlap:
                removed = buf.pop(0)
                buf_len -= len(removed) + sep_len
            buf_len = max(0, buf_len)

        buf.append(piece)
        buf_len += (sep_len if len(buf) > 1 else 0) + piece_len

    if buf:
        chunks.append(separator.join(buf))

    return chunks


def _split_text(
    text: str,
    chunk_size: int,
    chunk_overlap: int,
    separators: list[str],
) -> list[str]:
    """구분자 목록을 순서대로 시도하며 재귀적으로 텍스트를 청킹한다."""
    final: list[str] = []

    # 현재 레벨에서 사용할 구분자 선택
    sep = separators[-1]
    remaining: list[str] = []
    for idx, s in enumerate(separators):
        if s == "" or s in text:
            sep = s
            remaining = separators[idx + 1 :]
            break

    # 선택한 구분자로 분리
    raw = text.split(sep) if sep else list(text)
    good: list[str] = []

    for piece in raw:
        if not piece:
            continue
        if len(piece) < chunk_size:
            good.append(piece)
        else:
            # 현재까지 쌓인 작은 조각 먼저 처리
            if good:
                final.extend(_merge_splits(good, sep, chunk_size, chunk_overlap))
                good = []
            # 큰 조각은 남은 구분자로 재귀 분리
            if remaining:
                final.extend(_split_text(piece, chunk_size, chunk_overlap, remaining))
            else:
                # 문자 단위 강제 분리
                step = max(1, chunk_size - chunk_overlap)
                final.extend(piece[i : i + chunk_size] for i in range(0, len(piece), step))

    if good:
        final.extend(_merge_splits(good, sep, chunk_size, chunk_overlap))

    return [c for c in final if c.strip()]


class ChunkTextBlock(Block[ChunkTextInput, ChunkTextResult]):
    """긴 텍스트를 오버랩 있는 청크 목록으로 분리하는 블록.

    RAG 파이프라인에서 문서를 임베딩하기 전 전처리 단계로 사용한다.
    단락(\\n\\n) → 줄(\\n) → 단어( ) → 문자 순서로 구분자를 시도한다.

    Example:
        ```python
        block = ChunkTextBlock()
        result = await block.run(ChunkTextInput(
            text=long_document,
            chunk_size=1000,
            chunk_overlap=200,
        ))
        for chunk in result.chunks:
            print(len(chunk))
        ```
    """

    input_model = ChunkTextInput
    output_model = ChunkTextResult

    async def run(self, inp: ChunkTextInput) -> ChunkTextResult:
        if not inp.text.strip():
            return ChunkTextResult(chunks=[], chunk_count=0)

        if len(inp.text) <= inp.chunk_size:
            return ChunkTextResult(chunks=[inp.text], chunk_count=1)

        chunks = _split_text(
            inp.text,
            inp.chunk_size,
            inp.chunk_overlap,
            inp.separators,
        )
        return ChunkTextResult(chunks=chunks, chunk_count=len(chunks))
