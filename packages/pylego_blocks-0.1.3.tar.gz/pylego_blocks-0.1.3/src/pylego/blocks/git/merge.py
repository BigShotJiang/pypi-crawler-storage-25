"""MergeToMainBlock — feature 브랜치를 main 으로 non-ff 머지 + push + cleanup."""

from __future__ import annotations

from pylego.blocks.git._runner import GitRunner, default_git_runner
from pylego.core.block import Block
from pylego.core.stud import Stud


class MergeRequest(Stud):
    base_branch: str
    feature_branch: str
    message: str
    push_origin: bool = True
    delete_remote: bool = True
    delete_local: bool = True


class MergeResult(Stud):
    base_branch: str
    feature_branch: str
    local_branch_deleted: bool
    remote_branch_deleted: bool


class MergeToMainBlock(Block[MergeRequest, MergeResult]):
    """feature → base(=main) 머지. pipeline.sh §7 PASS 처리 경로를 이식.

    실패 시 예외를 올려 상위 Assembly 가 처리한다. --no-ff 로 머지 커밋 보존.
    """

    input_model = MergeRequest
    output_model = MergeResult

    def __init__(self, git_runner: GitRunner | None = None) -> None:
        self._git = git_runner if git_runner is not None else default_git_runner

    async def _must(self, args: list[str]) -> None:
        exit_code, stdout, stderr = await self._git(args)
        if exit_code != 0:
            raise RuntimeError(
                f"git {' '.join(args)} 실패 (exit={exit_code}): "
                f"{stderr.strip() or stdout.strip()}"
            )

    async def _best_effort(self, args: list[str]) -> bool:
        exit_code, _stdout, _stderr = await self._git(args)
        return exit_code == 0

    async def run(self, inp: MergeRequest) -> MergeResult:
        exit_code, stdout, stderr = await self._git(["status", "--porcelain"])
        if exit_code != 0:
            raise RuntimeError(
                f"git status --porcelain 실패 (exit={exit_code}): "
                f"{stderr.strip() or stdout.strip()}"
            )
        if stdout.strip():
            raise RuntimeError(
                "working tree not clean: commit the current changes before merging"
            )
        await self._must(["checkout", inp.base_branch])
        # pull 실패는 허용 (로컬 전용 리포의 경우).
        await self._best_effort(["pull", "origin", inp.base_branch])
        await self._must(
            ["merge", inp.feature_branch, "--no-ff", "-m", inp.message]
        )
        if inp.push_origin:
            await self._must(["push", "origin", inp.base_branch])

        local_deleted = False
        if inp.delete_local:
            local_deleted = await self._best_effort(["branch", "-d", inp.feature_branch])

        remote_deleted = False
        if inp.delete_remote:
            remote_deleted = await self._best_effort(
                ["push", "origin", "--delete", inp.feature_branch]
            )

        return MergeResult(
            base_branch=inp.base_branch,
            feature_branch=inp.feature_branch,
            local_branch_deleted=local_deleted,
            remote_branch_deleted=remote_deleted,
        )
