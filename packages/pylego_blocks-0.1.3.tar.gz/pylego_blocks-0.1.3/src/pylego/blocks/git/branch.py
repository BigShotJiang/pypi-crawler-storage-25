"""BranchPrepareBlock — feature 브랜치 준비.

pipeline.sh §3 로직: base(main) 체크아웃 → pull → feature 브랜치 존재하면 재사용, 없으면 생성.
"""

from __future__ import annotations

from pylego.blocks.git._runner import GitRunner, default_git_runner
from pylego.core.block import Block
from pylego.core.stud import Stud

__all__ = ["BranchPrepareBlock", "BranchReady", "BranchSpec", "GitRunner"]


class BranchSpec(Stud):
    base_branch: str
    feature_branch: str
    push_origin: bool = True


class BranchReady(Stud):
    feature_branch: str
    reused: bool  # True 면 기존 브랜치를 체크아웃, False 면 새로 생성


class BranchPrepareBlock(Block[BranchSpec, BranchReady]):
    """base 브랜치에서 feature 브랜치를 생성 또는 재사용 상태로 전환한다."""

    input_model = BranchSpec
    output_model = BranchReady

    def __init__(self, git_runner: GitRunner | None = None) -> None:
        self._git = git_runner if git_runner is not None else default_git_runner

    async def _run(self, args: list[str]) -> tuple[int, str, str]:
        return await self._git(args)

    async def _must(self, args: list[str]) -> str:
        exit_code, stdout, stderr = await self._run(args)
        if exit_code != 0:
            raise RuntimeError(
                f"git {' '.join(args)} 실패 (exit={exit_code}): "
                f"{stderr.strip() or stdout.strip()}"
            )
        return stdout

    async def run(self, inp: BranchSpec) -> BranchReady:
        await self._must(["checkout", inp.base_branch])
        # pull 실패는 경고 수준 — 로컬에서 막 만든 경우 upstream 이 없을 수 있음.
        await self._run(["pull", "origin", inp.base_branch])

        exit_code, _stdout, _stderr = await self._run(
            ["show-ref", "--verify", "--quiet", f"refs/heads/{inp.feature_branch}"]
        )
        if exit_code == 0:
            await self._must(["checkout", inp.feature_branch])
            return BranchReady(feature_branch=inp.feature_branch, reused=True)

        await self._must(["checkout", "-b", inp.feature_branch])
        if inp.push_origin:
            # push 실패는 허용 (원격이 없거나 권한 없는 테스트 환경).
            await self._run(["push", "-u", "origin", inp.feature_branch])
        return BranchReady(feature_branch=inp.feature_branch, reused=False)
