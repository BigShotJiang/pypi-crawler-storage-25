"""DuckDbBlock — asyncio.to_thread 기반 DuckDB 쿼리 블록."""

from __future__ import annotations

import asyncio
from typing import Any

from pylego.blocks.db.base import QueryBlock


class DuckDbBlock(QueryBlock):
    """asyncio.to_thread으로 DuckDB 동기 드라이버를 래핑한 쿼리 블록.

    ``duckdb`` 는 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[duckdb]

    Args:
        database: DuckDB 데이터베이스 파일 경로. 기본값 ``:memory:`` 는 인메모리 DB.

    Example:
        ```python
        from pylego.blocks.db.duckdb import DuckDbBlock
        from pylego.blocks.db.base import QueryInput

        block = DuckDbBlock()
        result = await block.run(QueryInput(query="SELECT 1 AS n"))
        # result.rows == [{"n": 1}]
        ```
    """

    def __init__(self, database: str = ":memory:") -> None:
        self._database = database

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        """asyncio.to_thread으로 DuckDB 동기 쿼리를 비동기로 실행한다.

        Args:
            query: 실행할 SQL 문자열.
            params: 쿼리 파라미터 목록.

        Returns:
            각 행이 ``{컬럼명: 값}`` dict 인 리스트.

        Raises:
            ImportError: ``duckdb`` 패키지가 설치되지 않은 경우.
        """
        database = self._database

        def _run() -> list[dict[str, Any]]:
            import duckdb  # lazy import — optional dependency

            con = duckdb.connect(database)
            try:
                rel = con.execute(query, params)
                cols = [d[0] for d in rel.description]
                return [dict(zip(cols, row)) for row in rel.fetchall()]
            finally:
                con.close()

        return await asyncio.to_thread(_run)
