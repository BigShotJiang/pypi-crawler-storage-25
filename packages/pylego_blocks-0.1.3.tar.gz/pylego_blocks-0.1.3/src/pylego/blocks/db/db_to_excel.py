"""DbToExcelUnit — 대용량 DB 조회 결과를 Excel 파일로 저장하는 Unit.

청크 단위 fetchmany + openpyxl write_only 모드로 메모리 사용량을 최소화한다.

의존성: pylego[mysql,excel]
"""

from __future__ import annotations

import asyncio
import os
from typing import Any

from pylego.core.stud import Stud
from pylego.unit import Unit


class DbToExcelInput(Stud):
    """DbToExcelUnit 입력."""

    query: str
    params: list[Any] = []
    output_path: str
    sheet_name: str = "Sheet1"
    chunk_size: int = 1000


class DbToExcelResult(Stud):
    """DbToExcelUnit 출력."""

    path: str
    row_count: int


class DbToExcelUnit(Unit[DbToExcelInput]):
    """DB 쿼리 결과를 청크 단위로 읽어 Excel 파일로 저장한다.

    - validate: 출력 디렉터리 쓰기 가능 여부, chunk_size 범위 검증
    - run: fetchmany 루프 + openpyxl write_only 모드로 메모리 최소화
    - verify: 파일 생성 여부 및 비어 있지 않음 확인

    Args:
        host: MySQL 호스트 (기본 PYLEGO_MYSQL_HOST 또는 "localhost")
        port: MySQL 포트 (기본 PYLEGO_MYSQL_PORT 또는 3306)
        user: MySQL 사용자명 (기본 PYLEGO_MYSQL_USER 또는 "root")
        password: MySQL 비밀번호 (기본 PYLEGO_MYSQL_PASSWORD 또는 "")
        db: MySQL 데이터베이스명 (기본 PYLEGO_MYSQL_DB 또는 "")

    Example::

        unit = DbToExcelUnit(host="localhost", user="root", password="secret", db="mydb")
        pipeline = UnitPipeline([unit], result_unit=MyResult())
        result = pipeline.run_sync(DbToExcelInput(
            query="SELECT id, name FROM users",
            output_path="/tmp/users.xlsx",
            chunk_size=2000,
        ))
    """

    name = "DbToExcelUnit"
    input_model = DbToExcelInput

    def __init__(
        self,
        host: str | None = None,
        port: int | None = None,
        user: str | None = None,
        password: str | None = None,
        db: str | None = None,
    ) -> None:
        self._host = host or os.environ.get("PYLEGO_MYSQL_HOST", "localhost")
        self._port = port or int(os.environ.get("PYLEGO_MYSQL_PORT", "3306"))
        self._user = user or os.environ.get("PYLEGO_MYSQL_USER", "root")
        self._password = password or os.environ.get("PYLEGO_MYSQL_PASSWORD", "")
        self._db = db or os.environ.get("PYLEGO_MYSQL_DB", "")

    async def validate(self, inp: DbToExcelInput) -> None:
        if inp.chunk_size < 1:
            raise ValueError(f"chunk_size 는 1 이상이어야 합니다: {inp.chunk_size}")
        out_dir = os.path.dirname(os.path.abspath(inp.output_path))
        if not os.path.isdir(out_dir):
            raise ValueError(f"출력 디렉터리가 존재하지 않습니다: {out_dir}")
        if not os.access(out_dir, os.W_OK):
            raise ValueError(f"출력 디렉터리에 쓰기 권한이 없습니다: {out_dir}")

    async def run(self, inp: DbToExcelInput) -> DbToExcelResult:
        try:
            import aiomysql
        except ImportError as e:
            raise ImportError("pip install pylego[mysql]") from e
        try:
            import openpyxl
        except ImportError as e:
            raise ImportError("pip install pylego[excel]") from e

        conn = await aiomysql.connect(
            host=self._host,
            port=self._port,
            user=self._user,
            password=self._password,
            db=self._db,
        )
        try:
            wb = openpyxl.Workbook(write_only=True)
            ws = wb.create_sheet(inp.sheet_name)
            total = 0
            header_written = False

            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(inp.query, inp.params or None)
                while True:
                    rows = await cur.fetchmany(inp.chunk_size)
                    if not rows:
                        break
                    if not header_written:
                        ws.append(list(rows[0].keys()))
                        header_written = True
                    for row in rows:
                        ws.append(list(row.values()))
                        total += 1

            await asyncio.to_thread(wb.save, inp.output_path)
            return DbToExcelResult(path=inp.output_path, row_count=total)
        finally:
            conn.close()

    async def verify(self, inp: DbToExcelInput, result: DbToExcelResult) -> None:
        if not os.path.isfile(result.path):
            raise RuntimeError(f"Excel 파일이 생성되지 않았습니다: {result.path}")
        if os.path.getsize(result.path) == 0:
            raise RuntimeError(f"Excel 파일이 비어 있습니다: {result.path}")
