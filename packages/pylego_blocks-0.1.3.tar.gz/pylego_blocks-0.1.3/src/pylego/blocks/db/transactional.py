"""TransactionalQueryBlock — 단일 DB 트랜잭션 내 다중 쿼리 실행 블록.

모든 쿼리가 성공하면 COMMIT, 하나라도 실패하면 ROLLBACK 한다.
분산 2PC / SAGA 는 범위 외 — 단일 MySQL 커넥션 내 원자성만 보장한다.

Note:
    pip install pylego[mysql]
"""

from __future__ import annotations

import asyncio
import os
from typing import Any

from pylego.blocks.db.base import QueryInput, QueryResult
from pylego.core.block import Block
from pylego.core.stud import Stud


class TransactionalInput(Stud):
    """트랜잭션 입력 — 순서대로 실행할 쿼리 목록."""

    queries: list[QueryInput]


class TransactionalResult(Stud):
    """트랜잭션 결과."""

    results: list[QueryResult]
    committed: bool


class TransactionalQueryBlock(Block[TransactionalInput, TransactionalResult]):
    """단일 MySQL 커넥션 내에서 여러 쿼리를 트랜잭션으로 실행한다.

    모든 쿼리 성공 시 COMMIT, 하나라도 예외 발생 시 ROLLBACK.

    Args:
        host: MySQL 호스트. 기본값: PYLEGO_MYSQL_HOST 또는 "localhost".
        port: MySQL 포트. 기본값: PYLEGO_MYSQL_PORT 또는 3306.
        user: MySQL 사용자명. 기본값: PYLEGO_MYSQL_USER 또는 "root".
        password: MySQL 비밀번호. 기본값: PYLEGO_MYSQL_PASSWORD 또는 "".
        db: 데이터베이스명. 기본값: PYLEGO_MYSQL_DB 또는 "".
        min_size: 풀 최소 커넥션 수. 기본값 1.
        max_size: 풀 최대 커넥션 수. 기본값 10.

    Example:
        ```python
        block = TransactionalQueryBlock(
            host="localhost", user="root", password="secret", db="mydb"
        )
        result = await block.run(TransactionalInput(queries=[
            QueryInput(query="INSERT INTO log (msg) VALUES (%s)", params=["start"]),
            QueryInput(query="UPDATE counter SET n = n + 1 WHERE id = %s", params=[1]),
        ]))
        # result.committed == True (모두 성공)
        await block.close()
        ```
    """

    input_model = TransactionalInput
    output_model = TransactionalResult

    def __init__(
        self,
        host: str | None = None,
        port: int = 3306,
        user: str | None = None,
        password: str | None = None,
        db: str | None = None,
        min_size: int = 1,
        max_size: int = 10,
    ) -> None:
        self._host: str = host or os.environ.get("PYLEGO_MYSQL_HOST", "localhost")
        self._port: int = (
            int(os.environ.get("PYLEGO_MYSQL_PORT", str(port)))
            if host is None
            else port
        )
        self._user: str = user or os.environ.get("PYLEGO_MYSQL_USER", "root")
        self._password: str = password or os.environ.get("PYLEGO_MYSQL_PASSWORD", "")
        self._db: str = db or os.environ.get("PYLEGO_MYSQL_DB", "")
        self._min_size = min_size
        self._max_size = max_size
        self._pool: Any = None
        self._pool_lock = asyncio.Lock()

    async def _get_pool(self) -> Any:
        if self._pool is None:
            async with self._pool_lock:
                if self._pool is None:
                    import aiomysql

                    self._pool = await aiomysql.create_pool(
                        host=self._host,
                        port=self._port,
                        user=self._user,
                        password=self._password,
                        db=self._db,
                        minsize=self._min_size,
                        maxsize=self._max_size,
                        cursorclass=aiomysql.DictCursor,
                        autocommit=False,
                    )
        return self._pool

    async def run(self, inp: TransactionalInput) -> TransactionalResult:
        import aiomysql

        pool = await self._get_pool()
        results: list[QueryResult] = []

        async with pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    for q in inp.queries:
                        await cur.execute(q.query, q.params or None)
                        rows: list[dict[str, Any]] = list(await cur.fetchall())
                        results.append(QueryResult(rows=rows, row_count=len(rows)))
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise

        return TransactionalResult(results=results, committed=True)

    async def close(self) -> None:
        """커넥션 풀을 닫고 자원을 해제한다."""
        if self._pool is not None:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
