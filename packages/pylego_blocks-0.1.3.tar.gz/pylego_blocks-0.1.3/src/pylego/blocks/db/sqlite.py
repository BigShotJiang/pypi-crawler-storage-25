"""SqliteBlock — aiosqlite 기반 SQLite 쿼리 블록."""

from __future__ import annotations

from typing import Any

from pylego.blocks.db.base import QueryBlock


class SqliteBlock(QueryBlock):
    """aiosqlite를 사용하는 비동기 SQLite 쿼리 블록.

    ``aiosqlite`` 는 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[sqlite]

    Args:
        database: SQLite 데이터베이스 파일 경로. 인메모리 DB는 ``:memory:`` 를 전달.

    Example:
        ```python
        from pylego.blocks.db.sqlite import SqliteBlock
        from pylego.blocks.db.base import QueryInput

        block = SqliteBlock(database=":memory:")
        result = await block.run(QueryInput(query="SELECT 1 AS n"))
        # result.rows == [{"n": 1}]
        ```
    """

    def __init__(self, database: str) -> None:
        self._database = database

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        """aiosqlite로 쿼리를 실행하고 결과를 dict 리스트로 반환한다.

        Args:
            query: 실행할 SQL 문자열.
            params: 쿼리 파라미터 목록.

        Returns:
            각 행이 ``{컬럼명: 값}`` dict 인 리스트.

        Raises:
            ImportError: ``aiosqlite`` 가 설치되지 않은 경우.
        """
        import aiosqlite  # lazy import — optional dependency

        async with aiosqlite.connect(self._database) as conn:
            conn.row_factory = aiosqlite.Row
            async with conn.execute(query, params) as cur:
                rows = await cur.fetchall()
                return [dict(row) for row in rows]
