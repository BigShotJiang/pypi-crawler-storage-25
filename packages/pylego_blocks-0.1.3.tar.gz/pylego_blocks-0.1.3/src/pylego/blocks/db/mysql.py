"""MySqlBlock — aiomysql 기반 MySQL 쿼리 블록."""

from __future__ import annotations

import os
from typing import Any

from pylego.blocks.db.base import QueryBlock


class MySqlBlock(QueryBlock):
    """aiomysql을 사용하는 MySQL 쿼리 블록.

    연결 파라미터는 생성자 인수 또는 환경변수(PYLEGO_MYSQL_*)로 설정할 수 있다.

    Args:
        host: MySQL 호스트. 기본값: PYLEGO_MYSQL_HOST 환경변수 또는 "localhost".
        port: MySQL 포트. 기본값: PYLEGO_MYSQL_PORT 환경변수 또는 3306.
        user: MySQL 사용자명. 기본값: PYLEGO_MYSQL_USER 환경변수 또는 "root".
        password: MySQL 비밀번호. 기본값: PYLEGO_MYSQL_PASSWORD 환경변수 또는 "".
        db: 데이터베이스명. 기본값: PYLEGO_MYSQL_DB 환경변수 또는 "".

    Example:
        ```python
        block = MySqlBlock(host="localhost", user="root", password="secret", db="mydb")
        result = await block.run(QueryInput(query="SELECT * FROM users WHERE id = %s", params=[1]))
        ```
    """

    def __init__(
        self,
        host: str | None = None,
        port: int = 3306,
        user: str | None = None,
        password: str | None = None,
        db: str | None = None,
    ) -> None:
        self._host: str = host or os.environ.get("PYLEGO_MYSQL_HOST", "localhost")
        self._port: int = (
            int(os.environ.get("PYLEGO_MYSQL_PORT", str(port)))
            if host is None
            else port
        )
        self._user: str = user or os.environ.get("PYLEGO_MYSQL_USER", "root")
        self._password: str = password or os.environ.get("PYLEGO_MYSQL_PASSWORD", "")
        self._db: str = db or os.environ.get("PYLEGO_MYSQL_DB", "")

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        """aiomysql을 사용하여 쿼리를 실행한다.

        Args:
            query: 실행할 SQL 문자열.
            params: 쿼리 파라미터 목록.

        Returns:
            각 행이 ``{컬럼명: 값}`` dict 인 리스트.

        Raises:
            ImportError: aiomysql 패키지가 설치되지 않은 경우.
            Exception: DB 연결 또는 쿼리 실행 오류.
        """
        import aiomysql  # noqa: PLC0415  # lazy import — optional dep

        conn: aiomysql.Connection = await aiomysql.connect(
            host=self._host,
            port=self._port,
            user=self._user,
            password=self._password,
            db=self._db,
            cursorclass=aiomysql.DictCursor,
        )
        try:
            async with conn.cursor() as cur:
                await cur.execute(query, params or None)
                rows: list[dict[str, Any]] = list(await cur.fetchall())
                return rows
        finally:
            conn.close()
