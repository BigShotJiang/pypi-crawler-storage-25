"""PooledMySqlBlock — aiomysql Pool 기반 커넥션 풀 MySQL 쿼리 블록."""

from __future__ import annotations

import asyncio
import os
from typing import Any

from pylego.blocks.db.base import QueryBlock


class PooledMySqlBlock(QueryBlock):
    """aiomysql.create_pool()을 사용한 커넥션 풀 MySQL 쿼리 블록.

    매 쿼리마다 커넥션을 생성/파괴하는 ``MySqlBlock`` 과 달리,
    커넥션 풀을 재사용하여 고부하 환경의 성능을 개선한다.

    풀은 첫 ``_execute()`` 호출 시 lazy하게 초기화된다.
    사용 완료 후에는 ``await block.close()`` 를 호출하여 풀을 해제한다.

    ``aiomysql`` 은 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[mysql]

    Args:
        host: MySQL 호스트. 기본값: PYLEGO_MYSQL_HOST 환경변수 또는 "localhost".
        port: MySQL 포트. 기본값: PYLEGO_MYSQL_PORT 환경변수 또는 3306.
        user: MySQL 사용자명. 기본값: PYLEGO_MYSQL_USER 환경변수 또는 "root".
        password: MySQL 비밀번호. 기본값: PYLEGO_MYSQL_PASSWORD 환경변수 또는 "".
        db: 데이터베이스명. 기본값: PYLEGO_MYSQL_DB 환경변수 또는 "".
        min_size: 풀 최소 커넥션 수. 기본값 1.
        max_size: 풀 최대 커넥션 수. 기본값 10.

    Example:
        ```python
        block = PooledMySqlBlock(
            host="localhost", user="root", password="secret", db="mydb",
            min_size=2, max_size=20,
        )
        try:
            result = await block.run(QueryInput(query="SELECT * FROM users"))
        finally:
            await block.close()
        ```
    """

    def __init__(
        self,
        host: str | None = None,
        port: int = 3306,
        user: str | None = None,
        password: str | None = None,
        db: str | None = None,
        min_size: int = 1,
        max_size: int = 10,
    ) -> None:
        self._host: str = host or os.environ.get("PYLEGO_MYSQL_HOST", "localhost")
        self._port: int = (
            int(os.environ.get("PYLEGO_MYSQL_PORT", str(port)))
            if host is None
            else port
        )
        self._user: str = user or os.environ.get("PYLEGO_MYSQL_USER", "root")
        self._password: str = password or os.environ.get("PYLEGO_MYSQL_PASSWORD", "")
        self._db: str = db or os.environ.get("PYLEGO_MYSQL_DB", "")
        self._min_size = min_size
        self._max_size = max_size
        self._pool: Any = None  # aiomysql.Pool (optional dep, typed as Any)
        self._pool_lock = asyncio.Lock()

    async def _get_pool(self) -> Any:
        """풀이 없으면 생성하고 반환한다 (lazy init, thread-safe)."""
        if self._pool is None:
            async with self._pool_lock:
                if self._pool is None:
                    import aiomysql  # lazy import — optional dependency

                    self._pool = await aiomysql.create_pool(
                        host=self._host,
                        port=self._port,
                        user=self._user,
                        password=self._password,
                        db=self._db,
                        minsize=self._min_size,
                        maxsize=self._max_size,
                        cursorclass=aiomysql.DictCursor,
                    )
        return self._pool

    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        """커넥션 풀에서 커넥션을 획득하여 쿼리를 실행한다."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, params or None)
                rows: list[dict[str, Any]] = list(await cur.fetchall())
                return rows

    async def close(self) -> None:
        """커넥션 풀을 닫고 자원을 해제한다."""
        if self._pool is not None:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
