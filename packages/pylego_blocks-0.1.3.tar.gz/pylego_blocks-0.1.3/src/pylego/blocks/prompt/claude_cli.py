"""ClaudeCliBlock — `claude --print` CLI를 통한 프롬프트 실행 블록.

AcpPromptBlock(Copilot 소켓)의 교체 가능한 대안.
API 키 불필요, Claude Code 구독으로 동작.
"""

from __future__ import annotations

import asyncio

from pylego.blocks.prompt.base import PromptRequest, PromptResponse
from pylego.core.block import Block


class ClaudeCliBlock(Block[PromptRequest, PromptResponse]):
    """`claude --print` subprocess 호출로 프롬프트를 실행한다.

    Args:
        allowed_tools: claude --allowedTools 에 전달할 도구 목록.
                       Dev용: ["Bash", "Edit", "Write"]
                       QA용: [] (기본값, 도구 없음)
        model: claude --model 에 전달할 모델명. None 이면 구독 기본 모델 사용.
    """

    input_model = PromptRequest
    output_model = PromptResponse

    def __init__(
        self,
        allowed_tools: list[str] | None = None,
        model: str | None = None,
    ) -> None:
        self._allowed_tools = allowed_tools or []
        self._model = model

    async def run(self, inp: PromptRequest) -> PromptResponse:
        cmd = ["claude", "--print"]
        if self._allowed_tools:
            cmd += ["--allowedTools", ",".join(self._allowed_tools)]
        if self._model:
            cmd += ["--model", self._model]
        # --allowedTools 지정 시 positional arg 불가 → 항상 stdin 으로 전달
        prompt_bytes = inp.prompt.encode()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=prompt_bytes),
                timeout=inp.timeout_sec,
            )
        except asyncio.TimeoutError as exc:
            raise RuntimeError(f"Claude CLI timeout after {inp.timeout_sec}s") from exc

        if proc.returncode != 0:
            err = stderr.decode(errors="replace").strip()
            raise RuntimeError(f"Claude CLI exited with code {proc.returncode}: {err}")

        return PromptResponse(text=stdout.decode(errors="replace"))
