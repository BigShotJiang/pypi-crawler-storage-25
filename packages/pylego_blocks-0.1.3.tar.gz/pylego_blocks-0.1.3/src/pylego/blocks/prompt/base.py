"""공통 프롬프트 Stud 계약."""

from __future__ import annotations

from pylego.core.stud import Stud


class PromptRequest(Stud):
    prompt: str
    timeout_sec: float = 600.0


class PromptResponse(Stud):
    text: str
