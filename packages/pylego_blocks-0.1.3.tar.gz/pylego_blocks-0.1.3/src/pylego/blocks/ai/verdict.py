"""VerdictParseBlock — QA 응답 텍스트에서 PASS/FAIL/UNKNOWN 판정.

pipeline.sh §6 의 엄격 매칭 로직을 이식한다. 응답의 **마지막 비어있지 않은 줄**이
정확히 ``VERDICT: PASS`` 또는 ``VERDICT: FAIL`` 일 때만 해당 판정을 내리고, 그 외에는
UNKNOWN 으로 분류해 상위 로직이 자동 판정 폴백(테스트 명령 실행)을 결정한다.
"""

from __future__ import annotations

from typing import Literal

from pylego.core.block import Block
from pylego.core.stud import Stud

VerdictResult = Literal["PASS", "FAIL", "UNKNOWN"]


class VerdictParseRequest(Stud):
    text: str


class Verdict(Stud):
    result: VerdictResult


class VerdictParseBlock(Block[VerdictParseRequest, Verdict]):
    """QA 응답 텍스트를 파싱해 PASS/FAIL/UNKNOWN 반환.

    Args:
        strict: True(기본)이면 마지막 줄이 정확히 ``VERDICT: PASS`` /
                ``VERDICT: FAIL`` 일 때만 해당 판정을 반환한다.
                False 이면 대소문자 무관 매칭을 허용한다.

    Note:
        strict=True(기본값)는 AI가 프롬프트 형식 명세를 준수하지 않은 경우를
        UNKNOWN으로 분류해 거짓 양성을 방지한다.
        strict=False는 AI 응답 형식이 느슨한 환경(프롬프트 제어 불가)에서 사용한다.
    """

    input_model = VerdictParseRequest
    output_model = Verdict

    def __init__(self, *, strict: bool = True) -> None:
        self._strict = strict

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        last_line = ""
        for raw in inp.text.splitlines():
            if raw.strip():
                last_line = raw.strip()

        compare = last_line if self._strict else last_line.upper()
        if compare == "VERDICT: PASS":
            return Verdict(result="PASS")
        if compare == "VERDICT: FAIL":
            return Verdict(result="FAIL")
        return Verdict(result="UNKNOWN")
