"""이슈 라벨 전이·댓글·close 블록."""

from __future__ import annotations

from pylego.blocks.github.issue import GhRunner, _default_gh_runner
from pylego.core.block import Block
from pylego.core.stud import Stud

# ── LabelTransition ──────────────────────────────────────────────────────────


class LabelTransitionRequest(Stud):
    """라벨 전이 요청. 이전 라벨 제거 + 새 라벨 부여를 동시에 수행 (단일성 보장).

    from_label 이 None 이면 제거 단계 생략 (초기 라벨 부여 등).
    """

    repo: str
    number: int
    from_label: str | None
    to_label: str


class LabelTransitionResult(Stud):
    repo: str
    number: int
    current_label: str


class LabelTransitionBlock(Block[LabelTransitionRequest, LabelTransitionResult]):
    """`gh issue edit` 로 status 라벨 전이 — 이전 라벨 remove + 새 라벨 add.

    이슈가 항상 정확히 하나의 `status:*` 를 갖도록 페르소나 규칙(architect.md §5
    "상태 라벨 단일성") 을 강제한다.

    #37: 기존에는 `--add-label X --remove-label Y` 를 한 번의 호출에 섞었으나
    현장에서 remove 가 적용되지 않아 이중 라벨이 남는 사례 관측. gh 가 복합
    인자를 처리할 때 add/remove 의 순서·병합 규칙이 불안정한 것으로 추정.
    **remove → add 의 2회 순차 호출로 분리** 하여 각 단계가 확정되도록 한다.
    """

    input_model = LabelTransitionRequest
    output_model = LabelTransitionResult

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner

    async def _gh_must(self, args: list[str]) -> None:
        exit_code, stdout, stderr = await self._gh(args)
        if exit_code != 0:
            raise RuntimeError(
                f"gh {' '.join(args)} 실패 (exit={exit_code}): "
                f"{stderr.strip() or stdout.strip()}"
            )

    async def run(self, inp: LabelTransitionRequest) -> LabelTransitionResult:
        # 1. from_label 제거 — best-effort. 이미 부재한 라벨이면 gh 가 non-zero 를
        #    반환하지만 순(net) 목표 ("to_label 단일 상태") 에는 영향 없음.
        #    Dev 실패로 review 까지 못 간 상태에서 review → in-progress 전이처럼
        #    "상태 복구" 성격 호출을 허용하기 위함. (#37)
        if inp.from_label is not None:
            exit_code, stdout, stderr = await self._gh([
                "issue", "edit", str(inp.number),
                "--repo", inp.repo,
                "--remove-label", inp.from_label,
            ])
            # exit != 0 이어도 raise 하지 않음 — 라벨이 이미 없는 정상 사례 포괄.
            # stderr 는 버리지 않고 pipeline 로그로 보이도록 그대로 둔다.
            _ = exit_code, stdout, stderr

        # 2. to_label 부여 — 이 단계는 반드시 성공해야 한다.
        await self._gh_must([
            "issue", "edit", str(inp.number),
            "--repo", inp.repo,
            "--add-label", inp.to_label,
        ])
        return LabelTransitionResult(repo=inp.repo, number=inp.number, current_label=inp.to_label)


# ── IssueComment ─────────────────────────────────────────────────────────────


class IssueCommentRequest(Stud):
    repo: str
    number: int
    body: str


class IssueCommentResult(Stud):
    repo: str
    number: int


class IssueCommentBlock(Block[IssueCommentRequest, IssueCommentResult]):
    """이슈에 댓글 작성."""

    input_model = IssueCommentRequest
    output_model = IssueCommentResult

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner

    async def run(self, inp: IssueCommentRequest) -> IssueCommentResult:
        exit_code, stdout, stderr = await self._gh(
            ["issue", "comment", str(inp.number), "--repo", inp.repo, "--body", inp.body]
        )
        if exit_code != 0:
            raise RuntimeError(
                f"gh issue comment 실패 (exit={exit_code}): {stderr.strip() or stdout.strip()}"
            )
        return IssueCommentResult(repo=inp.repo, number=inp.number)


# ── IssueClose ───────────────────────────────────────────────────────────────


class IssueCloseRequest(Stud):
    repo: str
    number: int
    comment: str | None = None


class IssueCloseResult(Stud):
    repo: str
    number: int


class IssueCloseBlock(Block[IssueCloseRequest, IssueCloseResult]):
    """이슈 close — 선택적 코멘트 포함."""

    input_model = IssueCloseRequest
    output_model = IssueCloseResult

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner

    async def run(self, inp: IssueCloseRequest) -> IssueCloseResult:
        args = ["issue", "close", str(inp.number), "--repo", inp.repo]
        if inp.comment is not None:
            args.extend(["--comment", inp.comment])
        exit_code, stdout, stderr = await self._gh(args)
        if exit_code != 0:
            raise RuntimeError(
                f"gh issue close 실패 (exit={exit_code}): {stderr.strip() or stdout.strip()}"
            )
        return IssueCloseResult(repo=inp.repo, number=inp.number)
