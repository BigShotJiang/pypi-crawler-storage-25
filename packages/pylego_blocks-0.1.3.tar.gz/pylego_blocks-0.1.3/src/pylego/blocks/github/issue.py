"""IssueInspectBlock — `gh issue view` 로 이슈 메타데이터를 가져온다.

ai-pi/pipeline.sh 의 §1 이슈 정보 수집 단계(파이프라인 첫 블록)에 대응.
블록은 `gh` CLI 를 호출하는 subprocess 래퍼를 생성자 주입 받으므로 테스트에서 쉽게 모킹된다.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from collections.abc import Awaitable, Callable
from typing import Literal, cast

from pylego.core.block import Block
from pylego.core.stud import Stud


class IssueRef(Stud):
    """이슈 참조 — 저장소 + 이슈 번호."""

    repo: str
    number: int


IssueState = Literal["OPEN", "CLOSED"]


class IssueMetadata(Stud):
    """`gh issue view --json` 응답에서 필요한 필드만 추출한 계약."""

    repo: str
    number: int
    title: str
    state: IssueState
    labels: tuple[str, ...]


# subprocess 호출을 추상화한 콜러블 — (cmd, args, stdin) → (exit_code, stdout, stderr).
# 기본 구현은 `gh` 바이너리를 호출하지만, 테스트에서는 가짜 콜러블을 주입해 외부 의존 제거.
GhRunner = Callable[[list[str]], Awaitable[tuple[int, str, str]]]


async def _default_gh_runner(args: list[str]) -> tuple[int, str, str]:
    """실제 `gh` 바이너리 호출. 없으면 FileNotFoundError 대신 명시적 에러."""
    binary = shutil.which("gh")
    if binary is None:
        raise RuntimeError(
            "gh CLI 를 찾을 수 없습니다. GitHub 블록을 사용하려면 gh CLI 설치·인증이 필요합니다."
        )
    proc = await asyncio.create_subprocess_exec(
        binary,
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_b, stderr_b = await proc.communicate()
    return (
        proc.returncode if proc.returncode is not None else -1,
        stdout_b.decode(errors="replace"),
        stderr_b.decode(errors="replace"),
    )


class IssueInspectBlock(Block[IssueRef, IssueMetadata]):
    """이슈 번호를 받아 제목·상태·라벨을 담은 메타데이터를 반환."""

    input_model = IssueRef
    output_model = IssueMetadata

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner

    async def run(self, inp: IssueRef) -> IssueMetadata:
        exit_code, stdout, stderr = await self._gh(
            [
                "issue",
                "view",
                str(inp.number),
                "--repo",
                inp.repo,
                "--json",
                "number,title,state,labels",
            ]
        )
        if exit_code != 0:
            raise RuntimeError(
                f"gh issue view 실패 (exit={exit_code}): {stderr.strip() or stdout.strip()}"
            )
        raw = json.loads(stdout)
        labels_raw = cast(list[dict[str, object]], raw.get("labels") or [])
        labels = tuple(str(label.get("name", "")) for label in labels_raw if label.get("name"))
        state_raw = str(raw.get("state", "")).upper()
        if state_raw not in ("OPEN", "CLOSED"):
            raise RuntimeError(f"알 수 없는 이슈 state: {state_raw!r}")
        return IssueMetadata(
            repo=inp.repo,
            number=int(raw.get("number", inp.number)),
            title=str(raw.get("title", "")),
            state=cast(IssueState, state_raw),
            labels=labels,
        )
