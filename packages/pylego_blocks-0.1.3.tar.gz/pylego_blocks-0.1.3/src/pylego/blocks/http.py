"""HttpBlock — HTTP API 블록 공통 추상 베이스.

httpx 기반 HTTP 요청의 공통 boilerplate(ImportError 처리, AsyncClient 수명주기,
raise_for_status)를 캡슐화한다. 서브클래스는 _build_request()와 _parse_response()만
구현하면 된다.
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class HttpBlock[I: Stud, O: Stud](Block[I, O]):
    """httpx 기반 HTTP API 블록의 추상 베이스.

    서브클래스는 ``_build_request()`` 와 ``_parse_response()`` 만 구현하면 된다.
    httpx ImportError 처리, AsyncClient 수명주기, raise_for_status 는 공통 처리.

    Class attributes:
        _extra: ImportError 메시지에 포함할 pip install 힌트 (예: ``"pylego[telegram]"``).

    Example:
        ```python
        class MyBlock(HttpBlock[MyInput, MyOutput]):
            input_model = MyInput
            output_model = MyOutput
            _extra = "pylego[myextra]"

            def _build_request(self, inp: MyInput) -> tuple[str, str, dict[str, Any]]:
                return "POST", "https://example.com/api", {"key": inp.value}

            def _parse_response(self, data: dict[str, Any]) -> MyOutput:
                return MyOutput(result=data["value"])
        ```
    """

    # Block.__init_subclass__ 의 구체 클래스 검증을 통과하기 위해 sentinel 선언.
    # 서브클래스는 반드시 실제 Stud 타입으로 오버라이드해야 한다.
    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    _extra: str = "pylego"

    @abstractmethod
    def _build_request(self, inp: I) -> tuple[str, str, dict[str, Any]]:
        """HTTP 요청 정보를 (method, url, json_body) 튜플로 반환.

        Args:
            inp: 블록 입력 Stud 인스턴스.

        Returns:
            ``(method, url, json_body)`` 튜플.
            method 는 ``"GET"``, ``"POST"`` 등 HTTP 메서드 문자열.
        """
        ...

    @abstractmethod
    def _parse_response(self, data: dict[str, Any]) -> O:
        """응답 JSON dict 를 Output Stud 로 변환.

        Args:
            data: ``resp.json()`` 결과 dict.

        Returns:
            ``output_model`` 에 해당하는 Stud 인스턴스.
        """
        ...

    async def run(self, inp: I) -> O:
        """HTTP 요청을 실행하고 응답을 파싱하여 반환.

        Args:
            inp: 블록 입력 Stud 인스턴스.

        Returns:
            ``_parse_response()`` 가 반환하는 Output Stud 인스턴스.

        Raises:
            ImportError: httpx 가 설치되어 있지 않을 때.
            httpx.HTTPStatusError: 4xx / 5xx 응답일 때 (raise_for_status).
        """
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                f"httpx 가 설치되어 있지 않습니다. `pip install {self._extra}`"
            ) from exc

        method, url, body = self._build_request(inp)
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=body)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return self._parse_response(data)
