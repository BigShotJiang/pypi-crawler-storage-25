"""HTTP API 게이트웨이 — Assembly 를 FastAPI REST 엔드포인트로 서빙한다.

optional 의존성:
    pip install pylego[serve]   # fastapi + uvicorn

사용:
    pylego serve pipeline.yaml --port 8000

    # 또는 Python에서 직접
    from pylego.serve import build_app
    import uvicorn
    app = build_app(assembly)
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""

import time
from typing import Any


def _require_fastapi() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "fastapi / uvicorn 가 설치되어 있지 않습니다. "
            "`pip install pylego[serve]` 로 설치하세요."
        ) from exc


def build_app(assembly: Any) -> Any:
    """Assembly 를 서빙하는 FastAPI 앱을 생성한다.

    Args:
        assembly: pylego Assembly 인스턴스.

    Returns:
        FastAPI application instance.

    Raises:
        ImportError: fastapi 또는 uvicorn 이 설치되지 않은 경우.
    """
    _require_fastapi()

    from fastapi import FastAPI, HTTPException
    from fastapi.responses import JSONResponse
    from pydantic import ValidationError

    input_model = assembly.input_model
    output_model = assembly.output_model

    app = FastAPI(
        title=f"pylego — {assembly.name}",
        description=(
            f"Assembly **{assembly.name}** HTTP API.  \n"
            f"Input: `{input_model.__name__}` → Output: `{output_model.__name__}`"
        ),
        version="1.0.0",
    )

    @app.post(
        "/run",
        response_model=output_model,
        summary="Execute the assembly",
        description=f"Send a `{input_model.__name__}` payload, receive `{output_model.__name__}`.",
    )
    async def run_endpoint(body: input_model) -> Any:  # type: ignore[valid-type]
        try:
            t0 = time.monotonic()
            result = await assembly.run(body)
            elapsed = time.monotonic() - t0
            data = result.model_dump()
            data["_meta"] = {"elapsed_sec": round(elapsed, 4)}
            return JSONResponse(content=data)
        except ValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()) from exc
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc


    @app.get(
        "/health",
        summary="Assembly health check",
    )
    async def health_endpoint() -> dict[str, Any]:
        return {
            "status": "ok",
            "assembly": assembly.name,
            "input_model": input_model.__name__,
            "output_model": output_model.__name__,
        }

    return app


def serve(
    assembly: Any,
    *,
    host: str = "0.0.0.0",
    port: int = 8000,
    reload: bool = False,
) -> None:
    """Assembly 를 uvicorn 으로 서빙한다 (블로킹).

    Args:
        assembly: pylego Assembly 인스턴스.
        host: 바인딩 호스트.
        port: 리스닝 포트.
        reload: 소스 변경 시 자동 재시작 (개발 전용).
    """
    _require_fastapi()
    import uvicorn

    app = build_app(assembly)
    uvicorn.run(app, host=host, port=port, reload=reload)
