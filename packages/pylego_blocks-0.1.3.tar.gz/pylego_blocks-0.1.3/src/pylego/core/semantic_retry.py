"""SemanticRetryBlock — 의미론적 실패 시 에러 컨텍스트를 주입하여 재시도하는 블록."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


class MaxRepeatedErrorError(RuntimeError):
    """동일 오류가 연속 N회 반복되어 SemanticRetryBlock이 조기 중단됨."""


class AbortVerificationError(RuntimeError):
    """on_abort_fn 결과가 verify_fn을 통과하지 못함 (Post-Abort Verification 실패)."""


class SemanticRetryBlock[I: Stud, O: Stud](Block[I, O]):
    """의미론적 실패를 감지하고 에러 컨텍스트를 주입하여 재시도하는 래퍼 블록.

    ``verify_fn``이 예외를 raise하면 의미론적 실패로 간주한다.
    ``enrich_fn``이 원본 입력·실패 출력·에러 메시지를 받아 새 입력을 만들고,
    프레임워크가 재시도 루프를 실행한다.

    모든 재시도는 ``BlockRetryEvent``로 관찰 가능하다.
    최대 시도 횟수 소진 시 마지막 예외를 재전파한다.

    Args:
        inner: 래핑할 블록.
        verify_fn: ``(inp, out) -> None``. 의미 불충족 시 예외 raise.
        enrich_fn: ``(inp, out, error) -> new_inp``. 에러 컨텍스트를 포함한 새 입력 반환.
        max_attempts: 최초 시도 포함 총 시도 횟수 (기본 3).
        error_similarity_fn: ``(prev_error, curr_error) -> bool``.
            두 오류 문자열이 "동일"로 간주되는지 판단하는 사용자 정의 함수.
            ``None``이면 완전 동일 문자열 비교(``==``)를 사용한다.

    Example:
        ```python
        class AiRequest(Stud):
            prompt: str
            error_context: str = ""

        def check(inp: AiRequest, out: AiResponse) -> None:
            if out.verdict == "UNKNOWN":
                raise ValueError("판정 불가 — 형식을 지켜 재응답하라")

        def inject(inp: AiRequest, out: AiResponse, error: str) -> AiRequest:
            return inp.model_copy(update={
                "error_context": f"이전 시도 실패: {error}"
            })

        block = SemanticRetryBlock(AiBlock(), verify_fn=check, enrich_fn=inject)
        ```
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        inner: Block[I, O],
        *,
        verify_fn: Callable[[I, O], None],
        enrich_fn: Callable[[I, O, str], I],
        max_attempts: int = 3,
        abort_on_repeated_error: int | None = None,
        error_similarity_fn: Callable[[str, str], bool] | None = None,
        on_abort_fn: Callable[[I, str], Awaitable[O]] | None = None,
        verify_after_abort: bool = True,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts는 1 이상이어야 합니다.")
        if abort_on_repeated_error is not None and abort_on_repeated_error < 1:
            raise ValueError("abort_on_repeated_error는 1 이상이어야 합니다.")
        self._inner = inner
        self._verify_fn = verify_fn
        self._enrich_fn = enrich_fn
        self._max_attempts = max_attempts
        self._abort_on_repeated = abort_on_repeated_error
        self._error_similarity_fn = error_similarity_fn
        self._on_abort_fn = on_abort_fn
        self._verify_after_abort = verify_after_abort
        self.input_model = inner.input_model
        self.output_model = inner.output_model
        self.name = f"SemanticRetry({inner.name})"

    def _is_same_error(self, prev: str, curr: str) -> bool:
        """두 오류 문자열이 동일한 반복 오류인지 판단한다."""
        if self._error_similarity_fn is not None:
            return self._error_similarity_fn(prev, curr)
        return prev == curr

    async def run(self, inp: Any) -> Any:
        from pylego.core.events import BlockRetryEvent, _resolve_bus

        bus = _resolve_bus()
        current_inp: Any = inp
        last_exc: Exception = RuntimeError("unreachable")
        repeated_count: int = 0
        last_error_str: str = ""

        for attempt in range(self._max_attempts):
            out: Any = await self._inner.run(current_inp)
            try:
                self._verify_fn(current_inp, out)
                return out
            except Exception as exc:
                error_str = str(exc)
                if self._abort_on_repeated is not None:
                    if self._is_same_error(last_error_str, error_str):
                        repeated_count += 1
                    else:
                        repeated_count = 1
                        last_error_str = error_str
                    if repeated_count >= self._abort_on_repeated:
                        if self._on_abort_fn is not None:
                            if bus is not None:
                                from pylego.core.events import NestedEventBus, observe
                                with observe(NestedEventBus(parent=bus, namespace="abort_fn")):
                                    abort_result = await self._on_abort_fn(current_inp, error_str)
                            else:
                                abort_result = await self._on_abort_fn(current_inp, error_str)
                            if self._verify_after_abort:
                                try:
                                    self._verify_fn(current_inp, abort_result)
                                except Exception as verify_exc:
                                    raise AbortVerificationError(
                                        f"on_abort_fn 결과 검증 실패: {verify_exc}"
                                    ) from verify_exc
                            return abort_result
                        raise MaxRepeatedErrorError(
                            f"동일 오류가 {repeated_count}회 반복됨: {error_str}"
                        ) from exc
                last_exc = exc
                remaining = self._max_attempts - attempt - 1
                if remaining == 0:
                    break
                if bus is not None:
                    bus.emit(
                        BlockRetryEvent(
                            block_name=self._inner.name,
                            attempt=attempt + 1,
                            max_attempts=self._max_attempts,
                            error=exc,
                            delay_sec=0.0,
                        )
                    )
                current_inp = self._enrich_fn(current_inp, out, str(exc))

        raise last_exc
