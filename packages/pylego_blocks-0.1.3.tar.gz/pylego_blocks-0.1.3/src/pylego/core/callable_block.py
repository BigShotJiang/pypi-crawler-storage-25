"""CallableBlock — async 함수로 블록을 생성하는 경량 래퍼.

클래스 보일러플레이트 없이 ``async def fn(inp: I) -> O`` 함수를 바로
블록으로 사용할 수 있다.

Example::

    from pylego import CallableBlock, Assembly

    class MyInput(Stud):
        value: int

    class MyOutput(Stud):
        result: str

    async def double(inp: MyInput) -> MyOutput:
        return MyOutput(result=str(inp.value * 2))

    block = CallableBlock(double, input_model=MyInput, output_model=MyOutput)
    result = block.run_sync(MyInput(value=3))
    # result.result == "6"
"""

from __future__ import annotations

import inspect as _inspect
import typing
from collections.abc import Awaitable, Callable
from typing import Any

from pylego.core.block import Block
from pylego.core.stud import Stud


def _validate_fn_signature(
    fn: Callable[..., Any],
    input_model: type[Stud],
    output_model: type[Stud],
) -> None:
    """fn 시그니처와 input_model/output_model 일치 여부를 검증한다.

    타입 어노테이션이 없으면 검증을 생략한다.
    불일치 시 TypeError 를 발생시킨다.
    """
    try:
        hints = typing.get_type_hints(fn)
    except Exception:
        try:
            hints = _inspect.get_annotations(fn, eval_str=True)
        except Exception:
            return  # 타입 정보를 읽을 수 없으면 검증 생략

    params = list(_inspect.signature(fn).parameters.keys())
    if params:
        annotated_input = hints.get(params[0])
        if annotated_input is not None and annotated_input is not input_model:
            raise TypeError(
                f"CallableBlock: fn 첫 파라미터 타입 {annotated_input!r}이 "
                f"input_model={input_model!r}과 일치하지 않습니다."
            )

    annotated_return = hints.get("return")
    if annotated_return is not None and annotated_return is not output_model:
        raise TypeError(
            f"CallableBlock: fn 반환 타입 {annotated_return!r}이 "
            f"output_model={output_model!r}과 일치하지 않습니다."
        )


class CallableBlock[I: Stud, O: Stud](Block[I, O]):
    """async 함수를 블록으로 감싸는 경량 래퍼.

    Args:
        fn: ``async def (I) -> O`` 시그니처를 갖는 비동기 함수.
        input_model: 입력 Stud 서브클래스.
        output_model: 출력 Stud 서브클래스.

    Raises:
        TypeError: ``input_model`` / ``output_model`` 이 Stud 서브클래스가 아닌 경우.

    Note:
        ``name`` 은 ``fn.__name__`` 을 사용하며, 인스턴스 생성 후 변경할 수 없다.
    """

    input_model: type[Stud] = Stud  # sentinel — __init__ 에서 인스턴스 속성으로 오버라이드
    output_model: type[Stud] = Stud  # sentinel

    def __init__(
        self,
        fn: Callable[[I], Awaitable[O]],
        *,
        input_model: type[I],
        output_model: type[O],
    ) -> None:
        if not (isinstance(input_model, type) and issubclass(input_model, Stud)):
            raise TypeError(
                f"CallableBlock.input_model 은 Stud 서브클래스여야 합니다: {input_model!r}"
            )
        if not (isinstance(output_model, type) and issubclass(output_model, Stud)):
            raise TypeError(
                f"CallableBlock.output_model 은 Stud 서브클래스여야 합니다: {output_model!r}"
            )
        # fn 시그니처가 input_model/output_model과 일치하는지 생성 시점에 검증
        _validate_fn_signature(fn, input_model, output_model)
        self._fn = fn
        # 인스턴스 속성으로 설정하여 Assembly의 Stud 호환 검사에 사용
        self.input_model = input_model
        self.output_model = output_model
        self.name = fn.__name__

    async def run(self, inp: I) -> O:
        return await self._fn(inp)
