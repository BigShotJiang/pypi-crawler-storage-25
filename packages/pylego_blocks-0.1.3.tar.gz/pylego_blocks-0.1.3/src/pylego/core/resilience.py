"""에러 복구 래퍼 블록 — RetryBlock / FallbackBlock / TimeoutBlock / CircuitBreakerBlock.

모두 기존 Block[I, O] 를 감싸는 데코레이터 패턴이므로 Assembly 안에서
다른 블록과 동일하게 조립된다.

    asm = Assembly([
        RetryBlock(UnstableBlock(), RetryPolicy(max_attempts=3, delay_sec=0.5, backoff=2.0)),
        FallbackBlock(SlowBlock(), FastFallbackBlock()),
        TimeoutBlock(NetworkBlock(), timeout_sec=5.0),
        CircuitBreakerBlock(UnreliableBlock(), failure_threshold=3, reset_timeout=60.0),
    ])
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Literal

from pylego.core.assembly import IncompatibleSnapError
from pylego.core.block import Block
from pylego.core.stud import Stud


@dataclass(frozen=True)
class RetryPolicy:
    """재시도 정책.

    Args:
        max_attempts: 최초 시도 포함 총 시도 횟수. 기본 3 (= 최대 2회 재시도).
        delay_sec: 첫 재시도 전 대기 시간(초).
        backoff: 재시도마다 delay 에 곱하는 배수. 1.0 = 고정 간격.
    """

    max_attempts: int = 3
    delay_sec: float = 0.0
    backoff: float = 1.0

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts 는 1 이상이어야 합니다.")
        if self.delay_sec < 0:
            raise ValueError("delay_sec 는 0 이상이어야 합니다.")
        if self.backoff < 1.0:
            raise ValueError("backoff 는 1.0 이상이어야 합니다.")


class RetryBlock(Block[Any, Any]):
    """실패 시 RetryPolicy 에 따라 재시도하는 래퍼 블록.

    모든 재시도 시도는 M8 BlockRetryEvent 로 관찰 가능하다.
    최대 시도 횟수 소진 후 마지막 예외를 재전파한다.
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        inner: Block[Any, Any],
        policy: RetryPolicy | None = None,
    ) -> None:
        self._inner = inner
        self._policy = policy if policy is not None else RetryPolicy()
        self.input_model = inner.input_model
        self.output_model = inner.output_model
        self.name = f"Retry({inner.name})"

    async def run(self, inp: Any) -> Any:
        from pylego.core.events import BlockRetryEvent, _resolve_bus

        bus = _resolve_bus()
        policy = self._policy
        exc: Exception = RuntimeError("unreachable")

        for attempt in range(policy.max_attempts):
            try:
                return await self._inner.run(inp)
            except Exception as e:
                exc = e
                remaining = policy.max_attempts - attempt - 1
                if remaining == 0:
                    break
                delay = policy.delay_sec * (policy.backoff**attempt)
                if bus is not None:
                    bus.emit(
                        BlockRetryEvent(
                            block_name=self._inner.name,
                            attempt=attempt + 1,
                            max_attempts=policy.max_attempts,
                            error=e,
                            delay_sec=delay,
                        )
                    )
                if delay > 0:
                    await asyncio.sleep(delay)

        raise exc


class FallbackBlock(Block[Any, Any]):
    """primary 블록 실패 시 fallback 블록을 실행하는 래퍼 블록.

    두 블록은 동일한 input_model / output_model 을 가져야 한다.
    조립 시점에 계약 불일치를 검증한다.
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        primary: Block[Any, Any],
        fallback: Block[Any, Any],
    ) -> None:
        if primary.input_model is not fallback.input_model:
            raise IncompatibleSnapError(
                f"FallbackBlock: primary.input({primary.input_model.__name__}) "
                f"!= fallback.input({fallback.input_model.__name__})"
            )
        if primary.output_model is not fallback.output_model:
            raise IncompatibleSnapError(
                f"FallbackBlock: primary.output({primary.output_model.__name__}) "
                f"!= fallback.output({fallback.output_model.__name__})"
            )
        self._primary = primary
        self._fallback = fallback
        self.input_model = primary.input_model
        self.output_model = primary.output_model
        self.name = f"Fallback({primary.name}→{fallback.name})"

    async def run(self, inp: Any) -> Any:
        try:
            return await self._primary.run(inp)
        except Exception:
            return await self._fallback.run(inp)


class TimeoutBlock(Block[Any, Any]):
    """지정 시간 내에 응답하지 않으면 asyncio.TimeoutError 를 발생시키는 래퍼 블록."""

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(self, inner: Block[Any, Any], timeout_sec: float) -> None:
        if timeout_sec <= 0:
            raise ValueError("timeout_sec 는 0 초과여야 합니다.")
        self._inner = inner
        self._timeout_sec = timeout_sec
        self.input_model = inner.input_model
        self.output_model = inner.output_model
        self.name = f"Timeout({inner.name}, {timeout_sec}s)"

    async def run(self, inp: Any) -> Any:
        return await asyncio.wait_for(
            self._inner.run(inp),
            timeout=self._timeout_sec,
        )


# ── 서킷 브레이커 상태 타입 ──────────────────────────────────────────────────

CircuitState = Literal["closed", "open", "half-open"]


class CircuitOpenError(RuntimeError):
    """CircuitBreakerBlock 이 open 상태일 때 fast-fail 시 발생한다."""


class CircuitBreakerBlock(Block[Any, Any]):
    """연속 실패가 threshold 를 초과하면 회로를 열어 fast-fail 하는 래퍼 블록.

    상태 전이:
        closed  → open      : 연속 실패 횟수가 failure_threshold 에 도달
        open    → half-open : reset_timeout 초 경과 후 첫 요청 시
        half-open → closed  : 시도 성공 시
        half-open → open    : 시도 실패 시

    상태 변경 시 CircuitBreakerStateEvent 를 EventBus 로 발행한다.
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        inner: Block[Any, Any],
        *,
        failure_threshold: int = 3,
        reset_timeout: float = 60.0,
    ) -> None:
        if failure_threshold < 1:
            raise ValueError("failure_threshold 는 1 이상이어야 합니다.")
        if reset_timeout <= 0:
            raise ValueError("reset_timeout 은 0 초과여야 합니다.")
        self._inner = inner
        self._failure_threshold = failure_threshold
        self._reset_timeout = reset_timeout
        self._state: CircuitState = "closed"
        self._failure_count: int = 0
        self._opened_at: float | None = None
        self.input_model = inner.input_model
        self.output_model = inner.output_model
        self.name = f"CircuitBreaker({inner.name})"

    @property
    def state(self) -> CircuitState:
        return self._state

    def _transition(self, new_state: CircuitState) -> None:
        from pylego.core.events import CircuitBreakerStateEvent, _resolve_bus

        prev = self._state
        self._state = new_state
        bus = _resolve_bus()
        if bus is not None:
            bus.emit(
                CircuitBreakerStateEvent(
                    block_name=self.name,
                    previous_state=prev,
                    new_state=new_state,
                )
            )

    async def run(self, inp: Any) -> Any:
        # open 상태에서 reset_timeout 이 지났으면 half-open 으로 전환
        if self._state == "open":
            assert self._opened_at is not None
            if time.monotonic() - self._opened_at >= self._reset_timeout:
                self._transition("half-open")
            else:
                raise CircuitOpenError(
                    f"{self.name}: 회로가 열려 있어 요청을 차단합니다 (fast-fail)."
                )

        try:
            result: Any = await self._inner.run(inp)
        except Exception:
            self._failure_count += 1
            if self._state == "half-open":
                self._opened_at = time.monotonic()
                self._transition("open")
            elif self._failure_count >= self._failure_threshold:
                self._opened_at = time.monotonic()
                self._transition("open")
            raise

        # 성공 경로
        if self._state == "half-open":
            self._failure_count = 0
            self._opened_at = None
            self._transition("closed")
        elif self._state == "closed":
            self._failure_count = 0

        return result
