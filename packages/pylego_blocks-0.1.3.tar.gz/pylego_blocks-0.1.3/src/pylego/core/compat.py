"""pylego.core.compat — Stud 호환성 사전 검사."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from pylego.core.block import Block


@dataclass
class CompatibilityError:
    """두 블록 사이의 Stud 불일치 정보."""

    position: int
    left_block: str
    right_block: str
    expected: str
    got: str


@dataclass
class CompatibilityResult:
    """check_chain() 결과."""

    compatible: bool
    errors: list[CompatibilityError] = field(default_factory=list)


class SemanticCompatibilityError(Exception):
    """AssemblyValidator 검증 실패 시 발생하는 오류."""

    def __init__(self, *, position: int, reason: str) -> None:
        super().__init__(f"position {position}: {reason}")
        self.position = position
        self.reason = reason


class AssemblyValidator:
    """블록별 시맨틱 검증 함수를 보관하고 호출한다.

    ``validators`` 는 ``{position: callable}`` 형태의 딕셔너리이며,
    callable 은 ``(inp: Any) -> None`` 시그니처를 가진다.
    검증 실패 시 callable 이 예외를 raise 하면
    :class:`SemanticCompatibilityError` 로 변환된다.
    """

    def __init__(self, validators: dict[int, Callable[[Any], None]]) -> None:
        self._validators = dict(validators)

    @property
    def positions(self) -> frozenset[int]:
        return frozenset(self._validators)

    def validate(self, position: int, inp: Any) -> None:
        """position 에 등록된 검증 함수를 호출한다. 미등록이면 무시."""
        fn = self._validators.get(position)
        if fn is None:
            return
        try:
            fn(inp)
        except Exception as exc:
            raise SemanticCompatibilityError(position=position, reason=str(exc)) from exc

    def merge(self, other: "AssemblyValidator") -> "AssemblyValidator":
        """other 를 기반으로 self 를 덮어쓴 새 AssemblyValidator 를 반환한다.

        동일 위치에서 충돌 시 self 가 우선한다.
        """
        merged = dict(other._validators)
        merged.update(self._validators)
        return AssemblyValidator(merged)


def _block_name(b: type[Block[Any, Any]] | Block[Any, Any]) -> str:
    return type(b).__name__ if isinstance(b, Block) else b.__name__


def _output_model_name(b: type[Block[Any, Any]] | Block[Any, Any]) -> str:
    cls = type(b) if isinstance(b, Block) else b
    m = getattr(cls, "output_model", None)
    return m.__name__ if isinstance(m, type) else ""


def _input_model(b: type[Block[Any, Any]] | Block[Any, Any]) -> type | None:
    cls = type(b) if isinstance(b, Block) else b
    m = getattr(cls, "input_model", None)
    return m if isinstance(m, type) else None


def _input_model_name(b: type[Block[Any, Any]] | Block[Any, Any]) -> str:
    m = _input_model(b)
    return m.__name__ if m is not None else ""


def _output_model(b: type[Block[Any, Any]] | Block[Any, Any]) -> type | None:
    cls = type(b) if isinstance(b, Block) else b
    m = getattr(cls, "output_model", None)
    return m if isinstance(m, type) else None


def check_connection(
    left: type[Block[Any, Any]] | Block[Any, Any],
    right: type[Block[Any, Any]] | Block[Any, Any],
) -> bool:
    """두 블록의 연결 가능 여부를 반환한다.

    ``left.output_model`` 이 ``right.input_model`` 과 동일하면 ``True``.
    """
    return _output_model(left) is _input_model(right)


def check_chain(
    blocks: list[type[Block[Any, Any]] | Block[Any, Any]],
    *,
    validator: AssemblyValidator | None = None,
) -> CompatibilityResult:
    """블록 체인의 Stud 호환성을 사전에 검사한다.

    인접한 두 블록 사이에서 ``left.output_model == right.input_model`` 인지 확인한다.
    클래스 또는 인스턴스를 혼용해도 된다.

    ``validator`` 를 지정하면 validator 의 위치 인덱스가 체인 범위 내인지 검사한다.
    범위를 벗어난 위치가 있으면 :class:`SemanticCompatibilityError` 를 발생시킨다.

    Args:
        blocks: 검사할 블록 목록 (인스턴스 또는 클래스).
        validator: 조립 시점 시맨틱 검증기 (선택).

    Returns:
        :class:`CompatibilityResult` — 호환 여부와 오류 목록.

    Raises:
        SemanticCompatibilityError: validator 위치가 블록 체인 범위를 벗어난 경우.
    """
    if validator is not None:
        n = len(blocks)
        for pos in sorted(validator.positions):
            if pos < 0 or pos >= n:
                raise SemanticCompatibilityError(
                    position=pos,
                    reason=f"블록 체인 길이({n})를 벗어난 validator 위치입니다",
                )

    if len(blocks) <= 1:
        return CompatibilityResult(compatible=True)

    errors: list[CompatibilityError] = []
    for i, (left, right) in enumerate(zip(blocks, blocks[1:])):
        if not check_connection(left, right):
            errors.append(
                CompatibilityError(
                    position=i,
                    left_block=_block_name(left),
                    right_block=_block_name(right),
                    expected=_output_model_name(left),
                    got=_input_model_name(right),
                )
            )

    return CompatibilityResult(compatible=len(errors) == 0, errors=errors)
