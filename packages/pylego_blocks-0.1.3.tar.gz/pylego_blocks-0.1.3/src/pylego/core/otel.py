"""OtelEventBus — BlockEvent → OpenTelemetry span 변환.

`opentelemetry-api` 가 설치된 경우에만 동작한다.
미설치 시 생성자에서 ImportError 를 발생시킨다.

    pip install pylego[otel]

기본 사용:
    with observe(OtelEventBus()):
        result = await assembly.run(inp)

환경변수 자동 설정:
    PYLEGO_OTEL_ENDPOINT=http://localhost:4318 python -m pylego run 1
    → configure_otel_from_env() 호출로 TracerProvider 자동 초기화
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Callable
from typing import Any

from pylego.core.events import (
    BlockCompletedEvent,
    BlockEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
)


def _hash_obj(obj: object) -> str:
    """객체를 8자리 SHA-256 해시로 변환 (span attribute 용)."""
    try:
        serialized = json.dumps(obj, default=str, sort_keys=True)
    except Exception:
        serialized = repr(obj)
    return hashlib.sha256(serialized.encode()).hexdigest()[:8]


def _serialize_payload(obj: object, max_chars: int) -> str:
    """객체를 JSON 문자열로 직렬화하고 max_chars로 자른다."""
    try:
        text = json.dumps(obj, default=str, sort_keys=True, ensure_ascii=False)
    except Exception:
        text = repr(obj)
    if len(text) > max_chars:
        return text[:max_chars] + "…[truncated]"
    return text


class OtelEventBus:
    """`BlockEvent` 를 OpenTelemetry span 으로 변환하는 이벤트 버스.

    Args:
        tracer_name: OTEL tracer 이름 (기본: "pylego").
        service_name: 서비스 이름. None 이면 PYLEGO_OTEL_SERVICE_NAME 환경변수,
                      둘 다 없으면 "pylego" 사용.
        include_failed_payload: True 이면 ``BlockFailedEvent`` 발생 시
            ``block.failed_input`` span attribute에 실제 입력 내용을 기록한다.
            기본 False (해시만 기록, 프라이버시 보호).
        max_payload_chars: ``include_failed_payload=True`` 시 기록할 최대 문자 수.
            기본 500.
        payload_filter: ``include_failed_payload=True`` 시 페이로드를 기록할
            이벤트를 선별하는 콜백. None(기본)이면 모든 실패 이벤트에 기록.
            callable 제공 시 True 반환 이벤트만 페이로드 기록.
    """

    def __init__(
        self,
        tracer_name: str = "pylego",
        service_name: str | None = None,
        *,
        include_failed_payload: bool = False,
        max_payload_chars: int = 500,
        payload_filter: Callable[[BlockFailedEvent], bool] | None = None,
    ) -> None:
        try:
            from opentelemetry import trace as _trace
        except ImportError as exc:
            raise ImportError(
                "opentelemetry-api 가 설치되어 있지 않습니다. "
                "`pip install pylego[otel]` 로 설치하세요."
            ) from exc

        self._tracer = _trace.get_tracer(tracer_name)
        self._service_name = (
            service_name or os.environ.get("PYLEGO_OTEL_SERVICE_NAME", "pylego")
        )
        self._include_failed_payload = include_failed_payload
        self._max_payload_chars = max_payload_chars
        self._payload_filter = payload_filter
        # block_name → (span, input_obj) — input 보관은 실패 페이로드 기록에 사용
        self._active_spans: dict[str, tuple[Any, object]] = {}

    def emit(self, event: BlockEvent) -> None:
        try:
            from opentelemetry import trace as _trace
        except ImportError:
            return

        if isinstance(event, BlockStartedEvent):
            span = self._tracer.start_span(
                f"block.{event.block_name}",
                attributes={
                    "block.name": event.block_name,
                    "block.input_hash": _hash_obj(event.input),
                    "service.name": self._service_name,
                },
            )
            self._active_spans[event.block_name] = (span, event.input)

        elif isinstance(event, BlockCompletedEvent):
            entry = self._active_spans.pop(event.block_name, None)
            if entry is not None:
                span, _ = entry
                span.set_attribute("block.elapsed_sec", event.elapsed_sec)
                span.set_attribute("block.output_hash", _hash_obj(event.output))
                span.set_status(_trace.StatusCode.OK)
                span.end()

        elif isinstance(event, BlockFailedEvent):
            entry = self._active_spans.pop(event.block_name, None)
            if entry is not None:
                span, input_obj = entry
                span.set_attribute("block.elapsed_sec", event.elapsed_sec)
                if self._include_failed_payload:
                    should_record = (
                        self._payload_filter is None
                        or self._payload_filter(event)
                    )
                    if should_record:
                        span.set_attribute(
                            "block.failed_input",
                            _serialize_payload(input_obj, self._max_payload_chars),
                        )
                span.set_status(
                    _trace.StatusCode.ERROR,
                    description=str(event.error),
                )
                span.record_exception(event.error)
                span.end()

        elif isinstance(event, BlockRetryEvent):
            entry = self._active_spans.get(event.block_name)
            if entry is not None:
                span, _ = entry
                span.add_event(
                    "block.retry",
                    attributes={
                        "attempt": event.attempt,
                        "max_attempts": event.max_attempts,
                        "delay_sec": event.delay_sec,
                        "error": str(event.error),
                    },
                )

        elif isinstance(event, CircuitBreakerStateEvent):
            entry = self._active_spans.get(event.block_name)
            if entry is not None:
                span, _ = entry
                span.add_event(
                    "circuit_breaker.state_change",
                    attributes={
                        "previous_state": event.previous_state,
                        "new_state": event.new_state,
                    },
                )


def configure_otel_from_env() -> OtelEventBus | None:
    """PYLEGO_OTEL_ENDPOINT 환경변수가 설정된 경우 OtelEventBus 를 자동 구성.

    OTLP HTTP exporter 를 설정하고 글로벌 TracerProvider 를 초기화한다.
    `opentelemetry-exporter-otlp-proto-http` 패키지가 필요하다.

    Returns:
        OtelEventBus 인스턴스. PYLEGO_OTEL_ENDPOINT 미설정 시 None.

    Raises:
        ImportError: PYLEGO_OTEL_ENDPOINT 가 설정됐지만 OTEL SDK 가 없는 경우.
    """
    endpoint = os.environ.get("PYLEGO_OTEL_ENDPOINT")
    if endpoint is None:
        return None

    service_name = os.environ.get("PYLEGO_OTEL_SERVICE_NAME", "pylego")

    try:
        from opentelemetry import trace as _trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError as exc:
        raise ImportError(
            "PYLEGO_OTEL_ENDPOINT 가 설정됐지만 opentelemetry SDK 가 없습니다. "
            "`pip install pylego[otel]` 로 설치하세요."
        ) from exc

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)
    exporter = OTLPSpanExporter(endpoint=f"{endpoint.rstrip('/')}/v1/traces")
    provider.add_span_processor(BatchSpanProcessor(exporter))
    _trace.set_tracer_provider(provider)

    return OtelEventBus(service_name=service_name)
