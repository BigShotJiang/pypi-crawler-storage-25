"""pylego.core.graph — 하위 호환 re-export 심(M124).

실제 구현은 각 담당 모듈로 분리됐다:
  - 시각화: pylego.core.visualize (to_mermaid / to_dot / to_html / BlockStat / build_stats)
  - 원인 분석: pylego.ops.causal (CausalFactor / VersionContext / EnvironmentContext)
  - 차이 분석: pylego.ops.diff (HealthDiff)
  - 헬스 요약: pylego.ops.health (PipelineHealth / build_health_summary)

.. deprecated::
    이 모듈의 모든 임포트는 v6.0.0에서 제거된다.
    신규 코드에서는 pylego.ops.* 또는 pylego.core.visualize를 직접 임포트하라.
"""

from __future__ import annotations

import importlib
import warnings as _warnings

# M130 — Zero-Ops Boundary 집행 (설계 원칙 59)
# name → (module_path, attr_name)
_REDIRECT: dict[str, tuple[str, str]] = {
    "BlockStat":            ("pylego.core.visualize", "BlockStat"),
    "build_stats":          ("pylego.core.visualize", "build_stats"),
    "to_mermaid":           ("pylego.core.visualize", "to_mermaid"),
    "to_dot":               ("pylego.core.visualize", "to_dot"),
    "to_html":              ("pylego.core.visualize", "to_html"),
    "CausalFactor":         ("pylego.ops.causal",     "CausalFactor"),
    "EnvironmentContext":   ("pylego.ops.causal",     "EnvironmentContext"),
    "VersionContext":       ("pylego.ops.causal",     "VersionContext"),
    "HealthDiff":           ("pylego.ops.diff",       "HealthDiff"),
    "PipelineHealth":       ("pylego.ops.health",     "PipelineHealth"),
    "build_health_summary": ("pylego.ops.health",     "build_health_summary"),
}


def __getattr__(name: str) -> object:
    if name in _REDIRECT:
        mod_path, attr = _REDIRECT[name]
        _warnings.warn(
            f"'pylego.core.graph.{name}' is deprecated and will be removed in v6.0.0. "
            f"Use 'pylego.ops.*' or 'pylego.core.visualize' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        mod = importlib.import_module(mod_path)
        return getattr(mod, attr)
    raise AttributeError(f"module 'pylego.core.graph' has no attribute {name!r}")


__all__ = list(_REDIRECT.keys())
