"""pylego 코어 — Stud / Block / Assembly / Runtime 공용 API."""

from __future__ import annotations

from pylego.core.assembly import Assembly, CyclicAssemblyError, IncompatibleSnapError
from pylego.core.block import Block
from pylego.core.builder import BlockBuilder, wrap
from pylego.core.callable_block import CallableBlock
from pylego.core.budget import BudgetExceededError, ExecutionBudget
from pylego.core.branch import Branch
from pylego.core.checkpoint import Checkpoint, FileCheckpoint, MemoryCheckpoint
from pylego.core.events import (
    BlockEvent,
    BlockRetryEvent,
    CircuitBreakerStateEvent,
    CollectingEventBus,
    EventBus,
    LoggingEventBus,
    NestedEventBus,
    NoopEventBus,
    observe,
)
from pylego.core.fanout import FanOut, Gathered
from pylego.core.visualize import BlockStat, build_stats, to_dot, to_html, to_mermaid
from pylego.ops.causal import CausalFactor, EnvironmentContext, VersionContext
from pylego.ops.diff import HealthDiff
from pylego.ops.health import PipelineHealth, build_health_summary
from pylego.core.otel import OtelEventBus, configure_otel_from_env
from pylego.core.queue import DeadLetterQueue, Queue, WorkerPool
from pylego.core.redis_queue import RedisDeadLetterQueue, RedisQueue, RedisWorkerPool, make_queue
from pylego.core.resilience import (
    CircuitBreakerBlock,
    CircuitOpenError,
    FallbackBlock,
    RetryBlock,
    RetryPolicy,
    TimeoutBlock,
)
from pylego.core.runtime import AsyncRuntime, ProcessRuntime, SyncRuntime
from pylego.core.multi_perspective import (
    ConfidenceWeighted,
    ConsensusError,
    ConsensusPolicy,
    MajorityVote,
    MultiPerspectiveBlock,
    UnanimousRequired,
)
from pylego.core.semantic_retry import AbortVerificationError, MaxRepeatedErrorError, SemanticRetryBlock
from pylego.core.signal import AggregationStrategy, SignalAggregator, SignalScore
from pylego.core.tap import TapBlock
from pylego.core.store import FileStore, InMemoryStore, Store, StoreBlock
from pylego.core.stream import StreamBlock
from pylego.core.stud import Stud
from pylego.core.compat import (
    AssemblyValidator,
    CompatibilityError,
    CompatibilityResult,
    SemanticCompatibilityError,
    check_chain,
    check_connection,
)

__all__ = [
    "Assembly",
    "AsyncRuntime",
    "Block",
"BlockBuilder",
"CallableBlock",
    "BudgetExceededError",
    "ExecutionBudget",
    "BlockEvent",
    "BlockRetryEvent",
    "BlockStat",
    "CausalFactor",
    "EnvironmentContext",
    "HealthDiff",
    "PipelineHealth",
    "VersionContext",
    "Branch",
    "Checkpoint",
    "CircuitBreakerBlock",
    "CircuitBreakerStateEvent",
    "CircuitOpenError",
    "CollectingEventBus",
    "CyclicAssemblyError",
    "DeadLetterQueue",
    "EventBus",
    "FallbackBlock",
    "FanOut",
    "FileCheckpoint",
    "FileStore",
    "Gathered",
    "InMemoryStore",
    "IncompatibleSnapError",
    "LoggingEventBus",
    "MemoryCheckpoint",
    "NestedEventBus",
    "NoopEventBus",
    "OtelEventBus",
    "ProcessRuntime",
    "Queue",
    "RedisDeadLetterQueue",
    "RedisQueue",
    "RedisWorkerPool",
    "RetryBlock",
    "RetryPolicy",
    "Store",
    "StoreBlock",
    "AggregationStrategy",
    "ConfidenceWeighted",
    "ConsensusError",
    "ConsensusPolicy",
    "MajorityVote",
    "MultiPerspectiveBlock",
    "AbortVerificationError",
    "MaxRepeatedErrorError",
    "SemanticRetryBlock",
    "UnanimousRequired",
    "SignalAggregator",
    "SignalScore",
    "StreamBlock",
    "Stud",
    "SyncRuntime",
    "TapBlock",
    "TimeoutBlock",
    "WorkerPool",
    "build_health_summary",
    "build_stats",
    "configure_otel_from_env",
    "observe",
    "make_queue",
    "to_dot",
    "to_html",
    "to_mermaid",
    "wrap",
    "AssemblyValidator",
    "CompatibilityError",
    "CompatibilityResult",
    "SemanticCompatibilityError",
    "check_chain",
    "check_connection",
]
