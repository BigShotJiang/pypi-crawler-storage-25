"""Checkpoint — Assembly 실행 중간 상태 저장·복원."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, TypeVar

from pylego.core.store import FileStore, InMemoryStore, Store
from pylego.core.stud import Stud

_CHECKPOINT_DIR_ENV = "PYLEGO_CHECKPOINT_DIR"

_T = TypeVar("_T", bound=Stud)


class Checkpoint:
    """Assembly 블록 출력을 저장·복원하는 체크포인트.

    Store 를 주입받아 직렬화·역직렬화를 담당한다.
    """

    def __init__(self, store: Store) -> None:
        self._store = store

    async def save(self, key: str, value: Stud) -> None:
        """블록 출력을 JSON dict 로 직렬화하여 저장."""
        import json

        await self._store.set(key, json.loads(value.model_dump_json()))

    async def load(self, key: str, model: type[_T]) -> _T | None:
        """저장된 값을 역직렬화하여 반환. 없으면 None."""
        raw: Any = await self._store.get(key)
        if raw is None:
            return None
        return model.model_validate(raw)

    async def has(self, key: str) -> bool:
        return await self._store.has(key)

    async def clear(self) -> None:
        await self._store.clear()


class MemoryCheckpoint(Checkpoint):
    """인메모리 체크포인트 (테스트·임시 실행용)."""

    def __init__(self) -> None:
        super().__init__(InMemoryStore())


class FileCheckpoint(Checkpoint):
    """JSON 파일 기반 영속 체크포인트.

    Args:
        path: 체크포인트 파일 경로 (.json).
              부모 디렉터리가 없으면 자동 생성된다.
    """

    def __init__(self, path: Path | str) -> None:
        super().__init__(FileStore(path))


def _default_checkpoint(name: str) -> FileCheckpoint | None:
    """PYLEGO_CHECKPOINT_DIR 환경변수가 설정된 경우 FileCheckpoint 반환."""
    dir_env = os.environ.get(_CHECKPOINT_DIR_ENV)
    if dir_env is None:
        return None
    return FileCheckpoint(Path(dir_env) / f"{name}.json")
