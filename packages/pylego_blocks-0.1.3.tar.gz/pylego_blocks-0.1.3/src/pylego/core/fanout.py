"""FanOut — run multiple blocks concurrently with the same input."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from pylego.core.assembly import IncompatibleSnapError
from pylego.core.block import Block
from pylego.core.stud import Stud

if TYPE_CHECKING:
    from pylego.core.runtime.process import ProcessRuntime


class Gathered(Stud):
    """FanOut 결과 컨테이너. 각 브랜치 출력을 순서대로 보관."""

    results: tuple[Any, ...]


class FanOut(Block[Stud, Gathered]):
    """동일 input_model 을 가진 N개 블록을 동시 실행.

    조립 시점 검증:
    - 최소 2개 브랜치 필요
    - 모든 브랜치의 input_model 동일

    runtime 을 지정하면 ProcessRuntime 등 별도 프로세스에서 병렬 실행 가능.
    미지정 시 기본 asyncio.gather 동작 (하위 호환).
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Gathered

    def __init__(
        self,
        branches: Sequence[Block[Any, Any]],
        *,
        name: str | None = None,
        runtime: ProcessRuntime | None = None,
    ) -> None:
        if len(branches) < 2:
            raise ValueError("FanOut 은 최소 2개 브랜치가 필요합니다.")
        first_inp = branches[0].input_model
        for b in branches[1:]:
            if b.input_model is not first_inp:
                raise IncompatibleSnapError(
                    f"{branches[0].name}.input({first_inp.__name__}) "
                    f"!= {b.name}.input({b.input_model.__name__})"
                )
        # ProcessRuntime: 조립 시점에 pickle 가능 여부 검증
        if runtime is not None:
            runtime.validate(branches)
        self._branches = list(branches)
        self._runtime = runtime
        self.input_model = first_inp
        if name is not None:
            self.name = name

    async def run(self, inp: Stud) -> Gathered:
        if self._runtime is not None:
            results = await self._runtime.run_parallel(self._branches, inp)
        else:
            results = list(await asyncio.gather(*(b.run(inp) for b in self._branches)))
        return Gathered(results=tuple(results))
