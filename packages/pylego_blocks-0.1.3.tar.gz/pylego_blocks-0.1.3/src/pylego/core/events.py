"""BlockEvent 시스템 — Assembly 실행의 관찰 가능성(Observability).

사용 예:
    with observe(LoggingEventBus()):
        result = await assembly.run(inp)

    # 커스텀 핸들러
    class MyBus:
        def emit(self, event: BlockEvent) -> None: ...

    with observe(MyBus()):
        result = assembly.run_sync(inp)

환경변수로 자동 활성화:
    PYLEGO_LOG_LEVEL=DEBUG python -m pylego run 1
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Generator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Protocol

logger = logging.getLogger("pylego.events")


@dataclass(frozen=True)
class BlockStartedEvent:
    block_name: str
    input: object
    timestamp: float = field(default_factory=time.monotonic)


@dataclass(frozen=True)
class BlockCompletedEvent:
    block_name: str
    output: object
    elapsed_sec: float
    timestamp: float = field(default_factory=time.monotonic)


@dataclass(frozen=True)
class BlockFailedEvent:
    block_name: str
    error: Exception
    elapsed_sec: float
    timestamp: float = field(default_factory=time.monotonic)
    caused_by: BlockFailedEvent | None = None
    input_sample: str | None = None   # 실패 시 입력 요약 (최대 200자)
    error_type: str | None = None     # type(error).__name__


@dataclass(frozen=True)
class BlockRetryEvent:
    """RetryBlock 이 재시도할 때 발행된다."""

    block_name: str
    attempt: int
    max_attempts: int
    error: Exception
    delay_sec: float
    timestamp: float = field(default_factory=time.monotonic)


@dataclass(frozen=True)
class CircuitBreakerStateEvent:
    """CircuitBreakerBlock 의 상태가 변경될 때 발행된다."""

    block_name: str
    previous_state: str
    new_state: str
    timestamp: float = field(default_factory=time.monotonic)


BlockEvent = (
    BlockStartedEvent
    | BlockCompletedEvent
    | BlockFailedEvent
    | BlockRetryEvent
    | CircuitBreakerStateEvent
)


class EventBus(Protocol):
    """이벤트 수신자 계약. emit() 하나만 구현하면 된다."""

    def emit(self, event: BlockEvent) -> None: ...


class LoggingEventBus:
    """`pylego.events` logger 에 구조화 텍스트를 출력하는 기본 버스."""

    def emit(self, event: BlockEvent) -> None:
        if isinstance(event, BlockStartedEvent):
            logger.debug(
                "block_started name=%s input=%r",
                event.block_name,
                event.input,
            )
        elif isinstance(event, BlockCompletedEvent):
            logger.debug(
                "block_completed name=%s elapsed=%.3fs output=%r",
                event.block_name,
                event.elapsed_sec,
                event.output,
            )
        elif isinstance(event, BlockRetryEvent):
            logger.warning(
                "block_retry name=%s attempt=%d/%d delay=%.1fs error=%r",
                event.block_name,
                event.attempt,
                event.max_attempts,
                event.delay_sec,
                event.error,
            )
        elif isinstance(event, BlockFailedEvent):
            logger.warning(
                "block_failed name=%s elapsed=%.3fs error=%r",
                event.block_name,
                event.elapsed_sec,
                event.error,
            )
        elif isinstance(event, CircuitBreakerStateEvent):
            logger.warning(
                "circuit_breaker_state name=%s %s→%s",
                event.block_name,
                event.previous_state,
                event.new_state,
            )


class CollectingEventBus:
    """실행 중 발생한 모든 BlockEvent 를 수집한다. HTML 리포트 생성에 사용한다."""

    def __init__(self) -> None:
        self._events: list[BlockEvent] = []

    def emit(self, event: BlockEvent) -> None:
        self._events.append(event)

    @property
    def events(self) -> list[BlockEvent]:
        return list(self._events)

    def events_for(self, block_name: str) -> list[BlockEvent]:
        """특정 블록의 이벤트만 반환한다."""
        return [e for e in self._events if e.block_name == block_name]

    def failed_events(self) -> list[BlockFailedEvent]:
        """실패 이벤트만 반환한다."""
        return [e for e in self._events if isinstance(e, BlockFailedEvent)]

    def completed_events(self) -> list[BlockCompletedEvent]:
        """완료 이벤트만 반환한다."""
        return [e for e in self._events if isinstance(e, BlockCompletedEvent)]


class NoopEventBus:
    """이벤트를 즉시 버리는 제로 오버헤드 버스. 프로파일링 베이스라인 측정용."""

    def emit(self, event: BlockEvent) -> None:
        pass


class NestedEventBus:
    """중첩 파이프라인 이벤트를 parent 버스에 namespace 프리픽스를 붙여 포워딩한다.

    중첩 Assembly / on_abort_fn 내부 파이프라인의 이벤트를
    외부 CollectingEventBus 로 전파하면서 네임스페이스로 구분한다.

    Args:
        parent: 이벤트를 포워딩할 상위 버스.
        namespace: 포워딩 시 block_name 앞에 붙는 프리픽스.

    Example:
        ```python
        outer_bus = CollectingEventBus()
        with observe(outer_bus):
            inner_bus = NestedEventBus(parent=outer_bus, namespace="fallback")
            with observe(inner_bus):
                result = await fallback_pipeline.run(inp)
        # outer_bus.events 에 "fallback/FallbackBlock" 이벤트 포함
        ```
    """

    def __init__(self, parent: EventBus, namespace: str = "") -> None:
        self._parent = parent
        self._namespace = namespace
        self._events: list[BlockEvent] = []

    def emit(self, event: BlockEvent) -> None:
        self._events.append(event)
        forwarded = self._prefix(event) if self._namespace else event
        self._parent.emit(forwarded)

    def _prefix(self, event: BlockEvent) -> BlockEvent:
        name = f"{self._namespace}/{event.block_name}"
        if isinstance(event, BlockStartedEvent):
            return BlockStartedEvent(
                block_name=name, input=event.input, timestamp=event.timestamp
            )
        if isinstance(event, BlockCompletedEvent):
            return BlockCompletedEvent(
                block_name=name,
                output=event.output,
                elapsed_sec=event.elapsed_sec,
                timestamp=event.timestamp,
            )
        if isinstance(event, BlockFailedEvent):
            return BlockFailedEvent(
                block_name=name,
                error=event.error,
                elapsed_sec=event.elapsed_sec,
                timestamp=event.timestamp,
                caused_by=event.caused_by,
            )
        if isinstance(event, BlockRetryEvent):
            return BlockRetryEvent(
                block_name=name,
                attempt=event.attempt,
                max_attempts=event.max_attempts,
                error=event.error,
                delay_sec=event.delay_sec,
                timestamp=event.timestamp,
            )
        if isinstance(event, CircuitBreakerStateEvent):
            return CircuitBreakerStateEvent(
                block_name=name,
                previous_state=event.previous_state,
                new_state=event.new_state,
                timestamp=event.timestamp,
            )
        return event  # pragma: no cover

    @property
    def events(self) -> list[BlockEvent]:
        return list(self._events)

    def failed_events(self) -> list[BlockFailedEvent]:
        return [e for e in self._events if isinstance(e, BlockFailedEvent)]


_event_bus_var: ContextVar[EventBus | None] = ContextVar("_event_bus_var", default=None)


def _resolve_bus(explicit: EventBus | None = None) -> EventBus | None:
    """우선순위: 명시 > ContextVar > PYLEGO_LOG_LEVEL 환경변수."""
    if explicit is not None:
        return explicit
    ctx = _event_bus_var.get()
    if ctx is not None:
        return ctx
    if os.getenv("PYLEGO_LOG_LEVEL"):
        return LoggingEventBus()
    return None


@contextmanager
def observe(bus: EventBus) -> Generator[None, None, None]:
    """실행 범위 내 모든 Assembly.run() 에 bus 를 주입한다.

    중첩 Assembly 는 ContextVar 를 통해 자동으로 같은 bus 를 사용한다.
    """
    token = _event_bus_var.set(bus)
    try:
        yield
    finally:
        _event_bus_var.reset(token)
