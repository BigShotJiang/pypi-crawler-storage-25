"""Assembly → Mermaid / DOT / HTML 그래프 변환.

사용:
    mermaid_text = to_mermaid(assembly)
    dot_text     = to_dot(assembly)
    html_text    = to_html(assembly, stats)
"""

from __future__ import annotations

import html as _html
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from pylego.core.block import Block
from pylego.core.events import (
    BlockCompletedEvent,
    BlockEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
)

if TYPE_CHECKING:
    from pylego.ops.health import PipelineHealth


# ─── BlockStat ───────────────────────────────────────────────────────────────

@dataclass
class BlockStat:
    """블록 한 번 실행의 결과 요약."""

    name: str
    status: Literal["ok", "error"]
    elapsed_sec: float | None = None
    error_msg: str | None = None


def build_stats(events: list[BlockEvent]) -> dict[str, BlockStat]:
    """BlockEvent 목록에서 블록별 최종 실행 결과를 추출한다."""
    stats: dict[str, BlockStat] = {}
    for event in events:
        if isinstance(event, BlockCompletedEvent):
            stats[event.block_name] = BlockStat(
                name=event.block_name,
                status="ok",
                elapsed_sec=event.elapsed_sec,
            )
        elif isinstance(event, BlockFailedEvent):
            stats[event.block_name] = BlockStat(
                name=event.block_name,
                status="error",
                elapsed_sec=event.elapsed_sec,
                error_msg=str(event.error),
            )
    return stats


# ─── 내부 컨텍스트 ────────────────────────────────────────────────────────────

@dataclass
class _Ctx:
    """그래프 빌드 상태를 담는 컨텍스트."""

    node_lines: list[str] = field(default_factory=list)
    edge_lines: list[str] = field(default_factory=list)
    _counter: int = 0

    def new_id(self, prefix: str = "n") -> str:
        self._counter += 1
        return f"{prefix}_{self._counter}"


# ─── Mermaid ─────────────────────────────────────────────────────────────────

_WRAPPER_NAMES: frozenset[str] = frozenset({
    "RetryBlock",
    "SemanticRetryBlock",
    "FallbackBlock",
    "TimeoutBlock",
    "CircuitBreakerBlock",
    "TapBlock",
})

_WARNING_COMMENT: str = "%% WARNING: wrapper depth >= 3, consider refactoring"


def _is_wrapper(block: Block[Any, Any]) -> bool:
    """블록 이름에 래퍼 식별자가 포함되면 True."""
    return any(w in block.name for w in _WRAPPER_NAMES)


def _count_wrapper_depth(name: str) -> int:
    """블록 이름에서 래퍼 중첩 깊이를 계산한다."""
    remaining = name
    count = 0
    for w in sorted(_WRAPPER_NAMES, key=len, reverse=True):
        occurrences = remaining.count(w)
        if occurrences > 0:
            count += occurrences
            remaining = remaining.replace(w, "X" * len(w))
    return count


def _mermaid_esc(s: str) -> str:
    return s.replace('"', "#quot;").replace("<", "#lt;").replace(">", "#gt;")


def _walk_mermaid(
    block: Block[Any, Any],
    ctx: _Ctx,
    indent: int = 0,
    wrapper_depth: int = 0,
    expand_wrappers: bool = False,
) -> tuple[str, str]:
    """블록 트리를 재귀 탐색하여 ctx 에 Mermaid 라인을 추가한다."""
    from pylego.core.assembly import Assembly
    from pylego.core.branch import Branch
    from pylego.core.fanout import FanOut

    pad = "    " * indent

    if isinstance(block, Assembly):
        sg_id = ctx.new_id("asm")
        ctx.node_lines.append(f'{pad}subgraph {sg_id}["{_mermaid_esc(block.name)}"]')
        ctx.node_lines.append(f"{pad}    direction LR")

        first_entry: str | None = None
        last_exit: str | None = None
        prev_exit: str | None = None

        for b in block.blocks:
            b_entry, b_exit = _walk_mermaid(b, ctx, indent + 1, wrapper_depth, expand_wrappers)
            if first_entry is None:
                first_entry = b_entry
            if prev_exit is not None:
                ctx.edge_lines.append(f"    {prev_exit} --> {b_entry}")
            prev_exit = b_exit
            last_exit = b_exit

        ctx.node_lines.append(f"{pad}end")
        return first_entry or sg_id, last_exit or sg_id

    if isinstance(block, FanOut):
        fo_id = ctx.new_id("fo")
        gather_id = ctx.new_id("gather")
        ctx.node_lines.append(f'{pad}{fo_id}(("{_mermaid_esc(block.name)}"))')

        branch_exits: list[str] = []
        for branch in block._branches:
            b_entry, b_exit = _walk_mermaid(branch, ctx, indent, wrapper_depth, expand_wrappers)
            ctx.edge_lines.append(f"    {fo_id} --> {b_entry}")
            branch_exits.append(b_exit)

        ctx.node_lines.append(f'{pad}{gather_id}(("Gathered"))')
        for bx in branch_exits:
            ctx.edge_lines.append(f"    {bx} --> {gather_id}")

        return fo_id, gather_id

    if isinstance(block, Branch):
        br_id = ctx.new_id("br")
        merge_id = ctx.new_id("merge")
        ctx.node_lines.append(f'{pad}{br_id}{{"{_mermaid_esc(block.name)}"}}')

        te, tx = _walk_mermaid(block._on_true, ctx, indent, wrapper_depth, expand_wrappers)
        fe, fx = _walk_mermaid(block._on_false, ctx, indent, wrapper_depth, expand_wrappers)

        ctx.edge_lines.append(f'    {br_id} -- "true" --> {te}')
        ctx.edge_lines.append(f'    {br_id} -- "false" --> {fe}')

        ctx.node_lines.append(f'{pad}{merge_id}([ ])')
        ctx.edge_lines.append(f"    {tx} --> {merge_id}")
        ctx.edge_lines.append(f"    {fx} --> {merge_id}")

        return br_id, merge_id

    if expand_wrappers:
        inner: Block[Any, Any] | None = None
        _raw = (
            getattr(block, "_block", None)
            or getattr(block, "_inner", None)
            or getattr(block, "_primary", None)
        )
        if isinstance(_raw, Block):
            inner = _raw
        if inner is not None:
            sg_id = ctx.new_id("wr")
            ctx.node_lines.append(
                f'{pad}subgraph {sg_id}["{_mermaid_esc(block.name)}"]'
            )
            ctx.node_lines.append(f"{pad}    direction LR")
            ie, ix = _walk_mermaid(inner, ctx, indent + 1, wrapper_depth, expand_wrappers)
            _fallback: Block[Any, Any] | None = None
            _fb = getattr(block, "_fallback", None)
            if isinstance(_fb, Block):
                _fallback = _fb
            if _fallback is not None:
                fe2, _ = _walk_mermaid(_fallback, ctx, indent + 1, wrapper_depth, expand_wrappers)
                ctx.edge_lines.append(f'    {ix} -. "fallback" .-> {fe2}')
            ctx.node_lines.append(f"{pad}end")
            return ie, ix

    node_id = ctx.new_id("b")
    total_depth = wrapper_depth + _count_wrapper_depth(block.name)
    label = f"⚠️ {block.name}" if total_depth >= 3 else block.name
    ctx.node_lines.append(f'{pad}{node_id}["{_mermaid_esc(label)}"]')
    if total_depth >= 3:
        ctx.node_lines.append(f"{pad}{_WARNING_COMMENT}")
    return node_id, node_id


def to_mermaid(block: Block[Any, Any], *, expand_wrappers: bool = False) -> str:
    """블록/어셈블리를 Mermaid flowchart 텍스트로 변환한다."""
    ctx = _Ctx()
    _walk_mermaid(block, ctx, indent=0, expand_wrappers=expand_wrappers)
    lines = ["flowchart LR"]
    lines.extend(ctx.node_lines)
    lines.extend(ctx.edge_lines)
    return "\n".join(lines) + "\n"


# ─── DOT (Graphviz) ──────────────────────────────────────────────────────────

def _dot_esc(s: str) -> str:
    return s.replace('"', r"\"").replace("\n", r"\n")


@dataclass
class _DotCtx:
    """DOT 빌드 상태."""

    node_lines: list[str] = field(default_factory=list)
    edge_lines: list[str] = field(default_factory=list)
    _counter: int = 0

    def new_id(self, prefix: str = "n") -> str:
        self._counter += 1
        return f"{prefix}_{self._counter}"


def _walk_dot(
    block: Block[Any, Any],
    ctx: _DotCtx,
    indent: int = 1,
    expand_wrappers: bool = False,
) -> tuple[str, str]:
    """블록 트리를 재귀 탐색하여 ctx 에 DOT 라인을 추가한다."""
    from pylego.core.assembly import Assembly
    from pylego.core.branch import Branch
    from pylego.core.fanout import FanOut

    pad = "    " * indent

    if isinstance(block, Assembly):
        sg_id = ctx.new_id("asm")
        ctx.node_lines.append(f"{pad}subgraph cluster_{sg_id} {{")
        ctx.node_lines.append(f'{pad}    label="{_dot_esc(block.name)}";')
        ctx.node_lines.append(f"{pad}    style=dashed;")

        first_entry: str | None = None
        last_exit: str | None = None
        prev_exit: str | None = None

        for b in block.blocks:
            b_entry, b_exit = _walk_dot(b, ctx, indent + 1, expand_wrappers)
            if first_entry is None:
                first_entry = b_entry
            if prev_exit is not None:
                ctx.edge_lines.append(f"    {prev_exit} -> {b_entry};")
            prev_exit = b_exit
            last_exit = b_exit

        ctx.node_lines.append(f"{pad}}}")
        return first_entry or sg_id, last_exit or sg_id

    if isinstance(block, FanOut):
        fo_id = ctx.new_id("fo")
        gather_id = ctx.new_id("gather")
        ctx.node_lines.append(f'{pad}{fo_id} [shape=circle, label="{_dot_esc(block.name)}"];')

        branch_exits: list[str] = []
        for branch in block._branches:
            b_entry, b_exit = _walk_dot(branch, ctx, indent, expand_wrappers)
            ctx.edge_lines.append(f"    {fo_id} -> {b_entry};")
            branch_exits.append(b_exit)

        ctx.node_lines.append(f'{pad}{gather_id} [shape=circle, label="Gathered"];')
        for bx in branch_exits:
            ctx.edge_lines.append(f"    {bx} -> {gather_id};")

        return fo_id, gather_id

    if isinstance(block, Branch):
        br_id = ctx.new_id("br")
        merge_id = ctx.new_id("merge")
        ctx.node_lines.append(f'{pad}{br_id} [shape=diamond, label="{_dot_esc(block.name)}"];')

        te, tx = _walk_dot(block._on_true, ctx, indent, expand_wrappers)
        fe, fx = _walk_dot(block._on_false, ctx, indent, expand_wrappers)

        ctx.edge_lines.append(f'    {br_id} -> {te} [label="true"];')
        ctx.edge_lines.append(f'    {br_id} -> {fe} [label="false"];')

        ctx.node_lines.append(f'{pad}{merge_id} [shape=point, label=""];')
        ctx.edge_lines.append(f"    {tx} -> {merge_id};")
        ctx.edge_lines.append(f"    {fx} -> {merge_id};")

        return br_id, merge_id

    if expand_wrappers:
        _dot_inner: Block[Any, Any] | None = None
        _di = (
            getattr(block, "_block", None)
            or getattr(block, "_inner", None)
            or getattr(block, "_primary", None)
        )
        if isinstance(_di, Block):
            _dot_inner = _di
        if _dot_inner is not None:
            sg_id = ctx.new_id("wr")
            ctx.node_lines.append(f"{pad}subgraph cluster_{sg_id} {{")
            ctx.node_lines.append(f'{pad}    label="{_dot_esc(block.name)}";')
            ctx.node_lines.append(f"{pad}    style=dotted;")
            ie, ix = _walk_dot(_dot_inner, ctx, indent + 1, expand_wrappers)
            ctx.node_lines.append(f"{pad}}}")
            return ie, ix

    node_id = ctx.new_id("b")
    ctx.node_lines.append(f'{pad}{node_id} [label="{_dot_esc(block.name)}"];')
    return node_id, node_id


def to_dot(block: Block[Any, Any], *, expand_wrappers: bool = False) -> str:
    """블록/어셈블리를 Graphviz DOT 텍스트로 변환한다."""
    ctx = _DotCtx()
    _walk_dot(block, ctx, indent=1, expand_wrappers=expand_wrappers)
    lines = ["digraph G {", "    rankdir=LR;", '    node [shape=box];']
    lines.extend(ctx.node_lines)
    lines.extend(ctx.edge_lines)
    lines.append("}")
    return "\n".join(lines) + "\n"


# ─── HTML ────────────────────────────────────────────────────────────────────

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"></script>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #1a1a1a; }}
h1 {{ font-size: 1.4rem; margin-bottom: 0.5rem; }}
.graph-wrap {{ border: 1px solid #ddd; border-radius: 6px; padding: 1.5rem;
               background: #fafafa; margin-bottom: 2rem; overflow-x: auto; }}
table {{ border-collapse: collapse; width: 100%; font-size: 0.9rem; }}
th {{ background: #f0f0f0; text-align: left; padding: 0.5rem 0.75rem;
      border-bottom: 2px solid #ccc; }}
td {{ padding: 0.4rem 0.75rem; border-bottom: 1px solid #eee; }}
.ok   {{ color: #166534; background: #dcfce7; border-radius: 4px;
         padding: 2px 6px; font-weight: 600; }}
.error {{ color: #991b1b; background: #fee2e2; border-radius: 4px;
          padding: 2px 6px; font-weight: 600; }}
.health-badge {{ display:inline-block; border-radius:6px; padding:4px 12px;
                 font-weight:700; font-size:0.85rem; margin-bottom:1rem; }}
.health-ok       {{ color:#166534; background:#dcfce7; border:1px solid #86efac; }}
.health-degraded {{ color:#92400e; background:#fef3c7; border:1px solid #fcd34d; }}
.health-critical {{ color:#991b1b; background:#fee2e2; border:1px solid #fca5a5; }}
details.sub-health {{ margin:0.25rem 0 0.25rem 0; }}
details.sub-health summary {{ cursor:pointer; list-style:none; }}
details.sub-health summary::-webkit-details-marker {{ display:none; }}
details.sub-health > p {{ margin:0.3rem 0 0.3rem 1rem; font-size:0.85rem; color:#555; }}
.caused-arrow {{ display:inline-flex; align-items:center; gap:3px;
                 font-size:0.8em; color:#777; margin-left:6px; }}
</style>
</head>
<body>
<h1>{title}</h1>
{health_html}
<div class="graph-wrap">
<pre class="mermaid">
{mermaid}
</pre>
</div>
{stats_html}
<script>mermaid.initialize({{ startOnLoad: true }});</script>
</body>
</html>
"""

_STATS_TABLE = """\
<table>
<thead><tr><th>Block</th><th>Status</th><th>Elapsed (s)</th><th>Error</th></tr></thead>
<tbody>
{rows}
</tbody>
</table>
"""


def _stats_rows(stats: dict[str, BlockStat]) -> str:
    rows: list[str] = []
    for stat in stats.values():
        elapsed = f"{stat.elapsed_sec:.3f}" if stat.elapsed_sec is not None else "—"
        error = _html.escape(stat.error_msg) if stat.error_msg else ""
        status_cls = "ok" if stat.status == "ok" else "error"
        status_label = "✓ ok" if stat.status == "ok" else "✗ error"
        rows.append(
            f"<tr>"
            f"<td>{_html.escape(stat.name)}</td>"
            f'<td><span class="{status_cls}">{status_label}</span></td>'
            f"<td>{elapsed}</td>"
            f"<td>{error}</td>"
            f"</tr>"
        )
    return "\n".join(rows)


def to_html(
    block: Block[Any, Any],
    stats: dict[str, BlockStat] | None = None,
    *,
    title: str | None = None,
    expand_wrappers: bool = False,
    health: PipelineHealth | None = None,
) -> str:
    """블록/어셈블리를 자체 완결(standalone) HTML 리포트로 변환한다."""
    resolved_title = _html.escape(title or block.name)
    mermaid_text = to_mermaid(block, expand_wrappers=expand_wrappers)

    health_html = ""
    if health is not None:
        label_map = {"ok": "✓ ok", "degraded": "⚠ degraded", "critical": "✗ critical"}
        label = label_map.get(health.overall, health.overall)
        _dash_arrow = (
            '<svg width="18" height="10" style="vertical-align:middle">'
            '<line x1="0" y1="5" x2="14" y2="5" stroke="#999" stroke-width="1.5"'
            ' stroke-dasharray="3,2"/>'
            '<polygon points="11,2 16,5 11,8" fill="#999"/>'
            "</svg>"
        )
        error_parts: list[str] = []
        for name in health.error_blocks:
            detail = (health.error_details or {}).get(name)
            if detail is not None:
                msg = _html.escape(str(detail.error))
                caused_html = ""
                if detail.caused_by is not None:
                    cb_name = _html.escape(detail.caused_by.block_name)
                    caused_html = (
                        f'<span class="caused-arrow"'
                        f' title="caused by {cb_name}">'
                        f"{_dash_arrow}{cb_name}</span>"
                    )
                error_parts.append(
                    f'<span title="{msg}">{_html.escape(name)}{caused_html}</span>'
                )
            else:
                error_parts.append(_html.escape(name))
        errors_str = (", errors: " + ", ".join(error_parts)) if error_parts else ""
        health_html = (
            f'<div class="health-badge health-{health.overall}">{label} '
            f"— {health.total_blocks} blocks{errors_str}"
            f"</div>"
        )
        if health.sub_health:
            sub_parts: list[str] = []
            for ns, sh in health.sub_health.items():
                sh_label = label_map.get(sh.overall, sh.overall)
                sh_errors = (
                    ", ".join(_html.escape(b) for b in sh.error_blocks) or "none"
                )
                sub_parts.append(
                    f'<details class="sub-health">'
                    f'<summary class="health-badge health-{sh.overall}">'
                    f"{_html.escape(ns)}: {sh_label}"
                    f" — {sh.total_blocks} blocks"
                    f"</summary>"
                    f"<p>errors: {sh_errors}</p>"
                    f"</details>"
                )
            health_html += "\n" + "\n".join(sub_parts)

    stats_html = ""
    if stats:
        rows = _stats_rows(stats)
        stats_html = _STATS_TABLE.format(rows=rows)

    return _HTML_TEMPLATE.format(
        title=resolved_title,
        health_html=health_html,
        mermaid=mermaid_text,
        stats_html=stats_html,
    )
