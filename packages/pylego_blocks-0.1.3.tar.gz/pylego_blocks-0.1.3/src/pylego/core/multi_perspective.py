"""MultiPerspectiveBlock — 복수 AI 관점 병렬 실행 및 합의 패턴."""

from __future__ import annotations

import asyncio
from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

from pylego.core.assembly import IncompatibleSnapError
from pylego.core.block import Block
from pylego.core.stud import Stud


class ConsensusError(RuntimeError):
    """MultiPerspectiveBlock 에서 합의 실패 시 발생."""


@dataclass
class ConsensusPolicy:
    """합의 실패 시 처리 정책.

    우선순위: raise_error → fallback → escalate_to → ConsensusError 재전파.

    Args:
        raise_error: True 이면 ConsensusError 를 즉시 재전파한다.
        fallback: 합의 실패 시 실행할 블록. 그 결과가 최종 출력이 된다.
        escalate_to: 사이드채널 알림 블록. 실행 후 ConsensusError 재전파.
    """

    raise_error: bool = False
    fallback: Block[Any, Any] | None = field(default=None)
    escalate_to: Block[Any, Any] | None = field(default=None)


# ── 내장 합의 전략 ─────────────────────────────────────────────────────────────

class MajorityVote:
    """최다 득표 결과를 반환하는 합의 전략.

    Args:
        min_agreement: 최소 동의 횟수. 미충족 시 ``ConsensusError``.

    Note:
        출력 Stud 가 ``frozen=True`` (기본) 이면 해시 가능하므로 Counter 로 집계한다.

    Example:
        ```python
        block = MultiPerspectiveBlock(
            perspectives=[...],
            vote_fn=MajorityVote(min_agreement=2),
        )
        ```
    """

    def __init__(self, min_agreement: int = 1) -> None:
        self._min = min_agreement

    def __call__(self, results: list[Any]) -> Any:
        if not results:
            raise ConsensusError("결과 없음")
        counts: Counter[Any] = Counter(results)
        top, count = counts.most_common(1)[0]
        if count < self._min:
            raise ConsensusError(
                f"최소 합의 수({self._min}) 미충족: 최다 득표={count}"
            )
        return top


class ConfidenceWeighted:
    """가중치 기반 합의 전략. 가중치가 가장 높은 관점의 결과를 채택한다.

    낮은 의심도(SignalScore.score)를 역가중치로 활용하면 신뢰도가 높은 관점이 우선된다.

    Args:
        weights: 각 관점의 가중치 목록 (관점 순서와 일치해야 함).

    Example:
        ```python
        weights = [1.0 - s.score for s in aggregator.scores]
        block = MultiPerspectiveBlock(
            perspectives=[...],
            vote_fn=ConfidenceWeighted(weights),
        )
        ```
    """

    def __init__(self, weights: list[float]) -> None:
        self._weights = weights

    def __call__(self, results: list[Any]) -> Any:
        if len(self._weights) != len(results):
            raise ValueError(
                f"가중치 수({len(self._weights)})와 결과 수({len(results)})가 일치하지 않습니다."
            )
        _, best = max(zip(self._weights, results), key=lambda x: x[0])
        return best


class UnanimousRequired:
    """전원 일치 시 결과를 반환. 하나라도 다르면 ``ConsensusError``.

    Example:
        ```python
        block = MultiPerspectiveBlock(
            perspectives=[...],
            vote_fn=UnanimousRequired(),
        )
        ```
    """

    def __call__(self, results: list[Any]) -> Any:
        if not results:
            raise ConsensusError("결과 없음")
        first = results[0]
        if any(r != first for r in results[1:]):
            raise ConsensusError("전원 일치 필요 — 불일치 발생")
        return first


# ── MultiPerspectiveBlock ─────────────────────────────────────────────────────

class MultiPerspectiveBlock[I: Stud, O: Stud](Block[I, O]):
    """복수 AI 관점을 병렬 실행하고 합의 결과를 반환하는 블록.

    모든 관점 블록은 동일한 ``input_model`` 과 ``output_model`` 을 가져야 한다.
    합의 실패 시 ``ConsensusPolicy`` 에 따라 처리된다.

    Args:
        perspectives: 병렬 실행할 블록 목록 (최소 2개).
        vote_fn: 합의 전략. ``list[O] → O``. 실패 시 ``ConsensusError`` raise.
        consensus_policy: 합의 실패 처리 정책 (기본: ``ConsensusError`` 재전파).
        name: 블록 이름 (기본: 관점 이름 조합).

    Example:
        ```python
        from pylego.core.multi_perspective import (
            ConsensusPolicy, MultiPerspectiveBlock, majority_vote
        )

        block = MultiPerspectiveBlock(
            perspectives=[StrictReviewerBlock(), LenientReviewerBlock(), NeutralBlock()],
            vote_fn=majority_vote(min_agreement=2),
            consensus_policy=ConsensusPolicy(raise_error=True),
        )
        result = await block.run(inp)
        ```
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        perspectives: Sequence[Block[Any, Any]],
        vote_fn: Callable[[list[Any]], Any],
        *,
        consensus_policy: ConsensusPolicy | None = None,
        name: str | None = None,
    ) -> None:
        if len(perspectives) < 2:
            raise ValueError("MultiPerspectiveBlock 은 최소 2개 관점이 필요합니다.")
        first_in = perspectives[0].input_model
        first_out = perspectives[0].output_model
        for p in perspectives[1:]:
            if p.input_model is not first_in:
                raise IncompatibleSnapError(
                    f"{perspectives[0].name}.input({first_in.__name__}) "
                    f"!= {p.name}.input({p.input_model.__name__})"
                )
            if p.output_model is not first_out:
                raise IncompatibleSnapError(
                    f"{perspectives[0].name}.output({first_out.__name__}) "
                    f"!= {p.name}.output({p.output_model.__name__})"
                )
        self._perspectives = list(perspectives)
        self._vote_fn = vote_fn
        self._policy = consensus_policy if consensus_policy is not None else ConsensusPolicy()
        self.input_model = first_in
        self.output_model = first_out
        if name is not None:
            self.name = name
        else:
            names = "/".join(p.name for p in perspectives)
            self.name = f"MultiPerspective({names})"

    async def run(self, inp: Any) -> Any:
        results: list[Any] = list(
            await asyncio.gather(*(p.run(inp) for p in self._perspectives))
        )
        try:
            return self._vote_fn(results)
        except ConsensusError as exc:
            return await self._apply_policy(inp, exc)

    async def _apply_policy(self, inp: Any, exc: ConsensusError) -> Any:
        policy = self._policy
        if policy.raise_error:
            raise exc
        if policy.fallback is not None:
            return await policy.fallback.run(inp)
        if policy.escalate_to is not None:
            await policy.escalate_to.run(inp)
        raise exc
