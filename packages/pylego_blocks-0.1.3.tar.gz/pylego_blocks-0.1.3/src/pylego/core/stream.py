"""StreamBlock — AsyncGenerator 로 값을 점진적으로 생성하는 블록.

일반적인 Block[I, O] 가 run() 한 번에 값 하나를 반환하는 반면,
StreamBlock 은 stream() 을 통해 여러 값을 순차적으로 yield 한다.

LLM token-by-token 스트리밍, 대용량 파일 청크 처리 등에 사용한다.

    class TokenBlock(StreamBlock[Prompt, Token]):
        input_model = Prompt
        output_model = Token

        async def stream(self, inp: Prompt) -> AsyncGenerator[Token, None]:
            async for chunk in llm.stream(inp.text):
                yield Token(text=chunk)

        # run() 은 자동으로 마지막 Token 반환
"""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import AsyncGenerator

from pylego.core.block import Block
from pylego.core.stud import Stud


class StreamBlock[InputT: Stud, OutputT: Stud](Block[InputT, OutputT]):
    """AsyncGenerator 로 값을 점진적으로 생성하는 블록.

    `stream()` 을 구현하면 `run()` 은 자동으로 마지막 항목을 반환한다.
    중간 결과를 직접 소비하려면 `stream()` 을 호출한다.
    """

    # Assembly 와 동일한 sentinel 패턴 — Block.__init_subclass__ 검증 통과용.
    # 구체 서브클래스는 반드시 실제 Stud 타입으로 재정의해야 한다.
    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    @abstractmethod
    def stream(self, inp: InputT) -> AsyncGenerator[OutputT, None]:
        """값을 점진적으로 yield 한다.

        `async def stream(self, inp): yield item` 형태로 구현한다.
        """

    async def run(self, inp: InputT) -> OutputT:
        last: OutputT | None = None
        async for item in self.stream(inp):
            last = item
        if last is None:
            raise RuntimeError(f"{self.name}: 스트림이 빈 값을 반환했습니다.")
        return last
