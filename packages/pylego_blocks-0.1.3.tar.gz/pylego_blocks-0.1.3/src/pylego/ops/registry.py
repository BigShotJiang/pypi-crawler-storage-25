"""pylego.ops.registry — BlockRegistry / RegistryPolicy / BlockRuntimeStat re-exports."""

from pylego.registry import (
    BlockInfo,
    BlockRegistry,
    BlockRuntimeStat,
    RegistryPolicy,
    default_registry,
    register,
)

__all__ = [
    "BlockInfo",
    "BlockRegistry",
    "BlockRuntimeStat",
    "RegistryPolicy",
    "default_registry",
    "register",
]
