"""pylego.ops — Operator 도구 패키지.

파이프라인을 작성하는 Builder 인터페이스(pylego 코어)와 달리,
이 패키지는 만들어진 파이프라인을 운영하는 Operator 도구를 제공한다.

    from pylego import Block, Stud, Assembly      # Builder — 파이프라인 작성
    from pylego.ops import BlockRegistry, Scheduler  # Operator — 운영 도구
"""

from pylego.ops.causal import CausalFactor, EnvironmentContext, VersionContext
from pylego.ops.diff import HealthDiff
from pylego.ops.health import BlockStat, PipelineHealth, build_health_summary, build_stats
from pylego.ops.registry import (
    BlockInfo,
    BlockRegistry,
    BlockRuntimeStat,
    RegistryPolicy,
    default_registry,
    register,
)
from pylego.ops.scheduler import (
    GlobalSchedulerPolicy,
    JobStatus,
    Scheduler,
    SchedulerPolicy,
    ThawPolicy,
    run_once,
)

__all__ = [
    # registry
    "BlockInfo",
    "BlockRegistry",
    "BlockRuntimeStat",
    "RegistryPolicy",
    "default_registry",
    "register",
    # scheduler
    "GlobalSchedulerPolicy",
    "JobStatus",
    "Scheduler",
    "SchedulerPolicy",
    "ThawPolicy",
    "run_once",
    # health
    "BlockStat",
    "PipelineHealth",
    "build_health_summary",
    "build_stats",
    # diff
    "HealthDiff",
    # causal
    "CausalFactor",
    "EnvironmentContext",
    "VersionContext",
]
