"""CLI helpers for block inspection."""

from __future__ import annotations

import json
from typing import Any

from pylego.core import Block, Stud
from pylego.inspect.discovery import iter_blocks
from pylego.inspect.matrix import inspect_matrix as _inspect_matrix
from pylego.registry import default_registry

BlockType = type[Block[Stud, Stud]]
_AnyBlockType = type[Block[Any, Any]]


def _collect_blocks(root: str, installed: bool) -> list[_AnyBlockType]:
    """루트 패키지 + 선택적으로 entry-points 블록을 수집해 반환."""
    blocks: list[_AnyBlockType] = list(iter_blocks(root))

    if not installed:
        return blocks

    # entry-points 에서 새 블록을 발견·등록
    default_registry.discover()
    installed_blocks: list[_AnyBlockType] = default_registry.all()

    existing = {f"{b.__module__}.{b.__name__}" for b in blocks}
    for blk in installed_blocks:
        qname = f"{blk.__module__}.{blk.__name__}"
        if qname not in existing:
            blocks.append(blk)
            existing.add(qname)

    return sorted(blocks, key=lambda b: f"{b.__module__}.{b.__name__}")


def inspect_list(
    root: str = "pylego.blocks",
    output_format: str = "tty",
    *,
    installed: bool = False,
) -> int:
    """Print the registered blocks under ``root``.

    Args:
        root: 탐색할 패키지 루트.
        output_format: 출력 형식 (``"tty"`` 또는 ``"json"``).
        installed: ``True`` 이면 ``entry-points(pylego.blocks)`` 로 설치된
            블록도 함께 표시한다.
    """
    blocks = _collect_blocks(root, installed)

    if output_format == "json":
        payload = {
            "blocks": [
                {
                    "qualified_name": f"{block.__module__}.{block.__name__}",
                    "name": block.__name__,
                    "input_model": block.input_model.__name__,
                    "output_model": block.output_model.__name__,
                    "description": block.describe(),
                }
                for block in blocks
            ]
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    for block in blocks:
        print(
            f"{block.__module__}.{block.__name__} | "
            f"{block.input_model.__name__} -> {block.output_model.__name__}"
        )
    return 0


def inspect_show(name: str, root: str = "pylego.blocks") -> int:
    """Print details for a single block."""

    block = _resolve_block(name, root)
    print(f"{block.__module__}.{block.__name__}")
    print(block.describe())
    print()
    print("Field | Type | Required")
    print("--- | --- | ---")
    for field_name, field in block.input_model.model_fields.items():
        print(
            f"{field_name} | {_annotation_label(field.annotation)} | "
            f"{'yes' if field.is_required() else 'no'}"
        )
    return 0


def inspect_matrix(root: str = "pylego.blocks", output_format: str = "tty") -> int:
    """Print the compatibility matrix for registered blocks."""

    return _inspect_matrix(root=root, output_format=output_format)


def _resolve_block(name: str, root: str) -> BlockType:
    matches = [
        block
        for block in iter_blocks(root)
        if block.__name__ == name or f"{block.__module__}.{block.__name__}" == name
    ]
    if not matches:
        raise ValueError(f"unknown block: {name}")
    if len(matches) > 1:
        raise ValueError(f"ambiguous block name: {name}")
    return matches[0]


def _annotation_label(annotation: object) -> str:
    if isinstance(annotation, type):
        if annotation.__module__ == "builtins":
            return annotation.__name__
        return f"{annotation.__module__}.{annotation.__name__}"
    return str(annotation).replace("typing.", "")
