"""Registered block discovery helpers."""

from __future__ import annotations

import importlib
import inspect
import pkgutil
import sys
from collections.abc import Iterable
from types import ModuleType

from pylego.core import Block, Stud

BlockType = type[Block[Stud, Stud]]


def iter_blocks(root: str = "pylego.blocks") -> Iterable[BlockType]:
    """Yield concrete Block subclasses under ``root``.

    Import failures are reported to stderr and skipped so one broken module does
    not hide the rest of the registry.
    """

    modules = _load_modules(root)
    blocks: dict[str, BlockType] = {}
    for module in modules:
        for block in _iter_block_types(module):
            key = f"{block.__module__}.{block.__name__}"
            blocks[key] = block
    for key in sorted(blocks):
        yield blocks[key]


def _load_modules(root: str) -> list[ModuleType]:
    module = importlib.import_module(root)
    modules = [module]
    if not hasattr(module, "__path__"):
        return modules

    for info in pkgutil.walk_packages(module.__path__, module.__name__ + "."):
        try:
            modules.append(importlib.import_module(info.name))
        except Exception as exc:
            print(f"warning: failed to import {info.name}: {exc}", file=sys.stderr)
    return modules


def _iter_block_types(module: ModuleType) -> Iterable[BlockType]:
    for _, candidate in inspect.getmembers(module, inspect.isclass):
        if candidate is Block:
            continue
        if not issubclass(candidate, Block):
            continue
        if inspect.isabstract(candidate):
            continue
        yield candidate
