"""Compatibility matrix helpers for blocks."""

from __future__ import annotations

import json

from pylego.core import Block, Stud
from pylego.inspect.discovery import iter_blocks

BlockType = type[Block[Stud, Stud]]


def inspect_matrix(root: str = "pylego.blocks", output_format: str = "tty") -> int:
    """Print block compatibility pairs under ``root``."""

    blocks = list(iter_blocks(root))
    edges = _compatibility_edges(blocks)

    if output_format == "json":
        payload = {
            "blocks": [_block_payload(block) for block in blocks],
            "edges": [
                [_qualified_name(source), _qualified_name(target)]
                for source, target in edges
            ],
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    if not blocks:
        print("no registered blocks")
        return 0
    if len(blocks) >= 10:
        print(f"{len(edges)} compatible pairs")
        return 0

    _print_grid(blocks, edges)
    return 0


def _compatibility_edges(blocks: list[BlockType]) -> list[tuple[BlockType, BlockType]]:
    return [
        (source, target)
        for source in blocks
        for target in blocks
        if source.output_model is target.input_model
    ]


def _block_payload(block: BlockType) -> dict[str, str]:
    return {
        "qualified_name": _qualified_name(block),
        "name": block.__name__,
        "input_model": block.input_model.__name__,
        "output_model": block.output_model.__name__,
        "description": block.describe(),
    }


def _qualified_name(block: BlockType) -> str:
    return f"{block.__module__}.{block.__name__}"


def _print_grid(blocks: list[BlockType], edges: list[tuple[BlockType, BlockType]]) -> None:
    names = [block.__name__ for block in blocks]
    width = max(len(name) for name in names)
    cell_width = max(width, 1)
    edge_set = {(source, target) for source, target in edges}

    print(f"{'':{cell_width}} " + " ".join(f"{name:>{cell_width}}" for name in names))
    for source in blocks:
        row = [
            "✓" if (source, target) in edge_set else "—"
            for target in blocks
        ]
        line = " ".join(f"{cell:>{cell_width}}" for cell in row)
        print(f"{source.__name__:>{cell_width}} {line}")
