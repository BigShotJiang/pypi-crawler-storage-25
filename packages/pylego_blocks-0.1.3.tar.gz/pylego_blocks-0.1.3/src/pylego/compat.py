"""pylego.compat — extras 설치 검사 헬퍼.

커스텀 블록에서 optional 의존성 선언을 표준화한다.

Example:
    ```python
    from pylego.compat import is_available, requires

    if is_available("anthropic"):
        from pylego import AnthropicBlock

    class MyBlock(Block[MyInput, MyOutput]):
        @requires("mypackage")
        async def run(self, inp: MyInput) -> MyOutput:
            import mypackage
            ...
    ```
"""

from __future__ import annotations

import functools
import importlib.util
from collections.abc import Awaitable, Callable
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")

PYLEGO_EXTRAS_MAP: dict[str, str] = {
    "anthropic": "anthropic",
    "openai": "openai",
    "ollama": "httpx",
    "redis": "redis",
    "chromadb": "chromadb",
    "jinja2": "jinja2",
    "duckduckgo": "duckduckgo_search",
    "duckdb": "duckdb",
    "sqlite": "aiosqlite",
    "mysql": "aiomysql",
    "excel": "openpyxl",
    "pdf": "pypdf",
    "telegram": "httpx",
    "gmail": "aiosmtplib",
    "slack": "httpx",
    "discord": "httpx",
    "google-search": "httpx",
    "google-translate": "httpx",
    "serve": "fastapi",
    "otel": "opentelemetry",
    "http": "httpx",
}


def is_available(extra: str) -> bool:
    """extra 또는 패키지 이름으로 설치 여부를 반환한다.

    Args:
        extra: pylego extras 이름 (예: ``"anthropic"``) 또는 Python 패키지 이름.

    Returns:
        설치되어 있으면 ``True``, 아니면 ``False``.
    """
    package = PYLEGO_EXTRAS_MAP.get(extra, extra)
    return importlib.util.find_spec(package) is not None


def requires(
    *extras: str,
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """async 함수에 extras 의존성 선언 데코레이터.

    함수 실행 전에 지정된 extras 가 모두 설치되어 있는지 검사한다.
    미설치 시 ``ImportError`` 를 명확한 메시지와 함께 발생시킨다.

    Args:
        *extras: 필요한 extras 이름 목록.

    Example:
        ```python
        @requires("anthropic", "redis")
        async def run(self, inp: MyInput) -> MyOutput:
            import anthropic, redis
            ...
        ```
    """

    def decorator(fn: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @functools.wraps(fn)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            for extra in extras:
                if not is_available(extra):
                    package = PYLEGO_EXTRAS_MAP.get(extra, extra)
                    raise ImportError(
                        f"{package} 가 설치되어 있지 않습니다. "
                        f"`pip install pylego[{extra}]`"
                    )
            return await fn(*args, **kwargs)

        return wrapper

    return decorator
