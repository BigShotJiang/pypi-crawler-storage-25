"""YAML 선언형 Assembly 로더.

지원 포맷:
  # 리스트 형식 (짧은 형식)
  - tests.fixtures.sample_blocks.EchoBlock
  - tests.fixtures.sample_blocks.LengthBlock

  # 매핑 형식 (긴 형식)
  name: my-pipeline
  blocks:
    - class: tests.fixtures.sample_blocks.EchoBlock
    - class: tests.fixtures.sample_blocks.LengthBlock

블록 클래스 지정:
  - "module.path.ClassName"  (마지막 . 기준 분리)
  - "module.path:ClassName"  (: 기준 분리, 우선)
"""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

try:
    import yaml as _yaml
    _YAML_AVAILABLE = True
except ImportError:  # pragma: no cover
    _yaml = None  # type: ignore[assignment]
    _YAML_AVAILABLE = False

from pylego.core.assembly import Assembly
from pylego.core.block import Block
from pylego.core.stud import Stud
from pylego.registry import BlockRegistry


def _resolve_class(ref: str, registry: BlockRegistry | None) -> type[Block[Any, Any]]:
    """블록 클래스 참조 문자열을 해석해 클래스를 반환.

    우선 순위: `module:ClassName` > `module.ClassName` > registry 조회.
    """
    if ":" in ref:
        module_name, class_name = ref.split(":", 1)
    elif "." in ref:
        module_name, _, class_name = ref.rpartition(".")
    else:
        # 단순 이름 — 레지스트리 조회
        if registry is None:
            from pylego.registry import default_registry
            registry = default_registry
        return registry.get(ref)

    mod = importlib.import_module(module_name)
    try:
        cls = getattr(mod, class_name)
    except AttributeError as exc:
        raise KeyError(f"module {module_name!r} has no attribute {class_name!r}") from exc
    if not (isinstance(cls, type) and issubclass(cls, Block)):
        raise TypeError(f"{ref!r} 는 Block 서브클래스가 아닙니다.")
    return cls


def load_assembly(
    path: str | Path,
    *,
    registry: BlockRegistry | None = None,
) -> Assembly[Stud, Stud]:
    """YAML 파일에서 Assembly 를 로드한다."""
    if not _YAML_AVAILABLE:
        raise RuntimeError(
            "PyYAML 이 필요합니다. `pip install pyyaml` 또는 `uv add pyyaml` 로 설치하세요."
        )

    yaml_path = Path(path)
    if not yaml_path.exists():
        raise FileNotFoundError(f"YAML 파일을 찾을 수 없습니다: {yaml_path}")

    import yaml  # guaranteed available after _YAML_AVAILABLE check
    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))

    name: str | None = None
    block_refs: list[str] = []

    if isinstance(data, list):
        for item in data:
            if isinstance(item, str):
                block_refs.append(item)
            elif isinstance(item, dict) and "class" in item:
                block_refs.append(item["class"])
            else:
                raise ValueError(f"지원하지 않는 블록 항목: {item!r}")
    elif isinstance(data, dict):
        name = data.get("name")
        raw = data.get("blocks")
        if raw is None:
            raise ValueError("YAML 매핑에 'blocks' 키가 필요합니다.")
        if not raw:
            raise ValueError("'blocks' 목록이 비어있습니다.")
        for item in raw:
            if isinstance(item, str):
                block_refs.append(item)
            elif isinstance(item, dict) and "class" in item:
                block_refs.append(item["class"])
            else:
                raise ValueError(f"지원하지 않는 블록 항목: {item!r}")
    else:
        raise ValueError("YAML 은 리스트 또는 'blocks' 키를 가진 매핑이어야 합니다.")

    if not block_refs:
        raise ValueError("'blocks' 목록이 비어있습니다.")

    instances: list[Block[Any, Any]] = []
    for ref in block_refs:
        cls = _resolve_class(ref, registry)
        instances.append(cls())

    return Assembly(instances, name=name)


# 이전 이름 호환 별칭
load_assembly_from_yaml = load_assembly
