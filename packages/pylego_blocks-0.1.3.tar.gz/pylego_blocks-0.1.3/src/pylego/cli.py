"""pylego CLI."""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from collections.abc import Sequence

from pydantic import ValidationError

from pylego.inspect.cli import inspect_list, inspect_matrix, inspect_show
from pylego.inspect.graph import inspect_graph
from pylego.pipelines import AiPiPipelineConfig, build_ai_pi_pipeline, run_ai_pi
from pylego.pipelines.ai_pi import DEFAULT_COPILOT_SOCKET_PATH, DEFAULT_GEMINI_SOCKET_PATH


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m pylego")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run the ai-pi pipeline")
    run_parser.add_argument("issue_number", type=int)
    run_parser.add_argument("--dry-run", action="store_true", help="Build without executing")

    run_unit_parser = subparsers.add_parser("run-unit", help="Run a Unit standalone")
    run_unit_parser.add_argument("unit", help="Fully-qualified class name (e.g. mypackage.MyUnit)")
    run_unit_parser.add_argument("--input", default=None, help="JSON input string")
    run_unit_parser.add_argument("--schema", action="store_true", help="Print input JSON Schema")

    inspect_parser = subparsers.add_parser("inspect", help="Inspect registered blocks")
    inspect_subparsers = inspect_parser.add_subparsers(dest="inspect_command", required=True)

    list_parser = inspect_subparsers.add_parser("list", help="List registered blocks")
    list_parser.add_argument("--module", default="pylego.blocks")
    list_parser.add_argument("--format", choices=("tty", "json"), default="tty")
    list_parser.add_argument(
        "--installed",
        action="store_true",
        help="entry-points(pylego.blocks)로 설치된 모든 블록 포함",
    )

    show_parser = inspect_subparsers.add_parser("show", help="Show a block contract")
    show_parser.add_argument("name")
    show_parser.add_argument("--module", default="pylego.blocks")

    matrix_parser = inspect_subparsers.add_parser("matrix", help="Show compatibility matrix")
    matrix_parser.add_argument("--module", default="pylego.blocks")
    matrix_parser.add_argument("--format", choices=("tty", "json"), default="tty")

    graph_parser = inspect_subparsers.add_parser("graph", help="Visualize assembly graph")
    graph_parser.add_argument("file", help="YAML file describing the assembly")
    graph_parser.add_argument(
        "--format",
        choices=("mermaid", "dot", "html"),
        default="mermaid",
        help="Output format (default: mermaid)",
    )
    graph_parser.add_argument("--output", default=None, help="Output file (default: stdout)")

    assemble_parser = subparsers.add_parser("assemble", help="Load Assembly from YAML")
    assemble_parser.add_argument("file", help="YAML file describing the assembly")
    assemble_parser.add_argument("--dry-run", action="store_true", help="Parse and print assembly without executing")

    serve_parser = subparsers.add_parser("serve", help="Serve an Assembly as HTTP API")
    serve_parser.add_argument("file", help="YAML file describing the assembly")
    serve_parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    serve_parser.add_argument("--port", type=int, default=8000, help="Listen port (default: 8000)")
    serve_parser.add_argument("--reload", action="store_true", help="Auto-reload on code change (dev)")

    schedule_parser = subparsers.add_parser("schedule", help="Run a YAML assembly on a schedule")
    schedule_subparsers = schedule_parser.add_subparsers(dest="schedule_command", required=True)

    schedule_once_parser = schedule_subparsers.add_parser("run-once", help="Execute assembly once synchronously")
    schedule_once_parser.add_argument("file", help="YAML file describing the assembly")
    schedule_once_parser.add_argument("--input", default=None, help="JSON input for the first block")

    return parser


# #35/#37 후속: env var fallback 을 AiPiPipelineConfig 기본값(600s) 과 동일하게
# 맞춤. 이전엔 여기서 300.0 을 하드코딩해 모델 기본값이 덮어써져 운영 시 5 min
# 시점에 Dev timeout 이 발동 → #27 false FAIL 의 직접 원인.
_DEFAULT_DEV_TIMEOUT_SEC = 600.0
_DEFAULT_QA_TIMEOUT_SEC = 600.0


def _read_float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    return float(raw)


def _load_config(issue_number: int) -> AiPiPipelineConfig:
    repo = os.getenv("GITHUB_REPO")
    if repo is None or repo == "":
        raise ValueError("GITHUB_REPO 환경변수를 설정하세요.")

    return AiPiPipelineConfig(
        repo=repo,
        issue_number=issue_number,
        copilot_socket_path=os.getenv("COPILOT_DAEMON_SOCK", DEFAULT_COPILOT_SOCKET_PATH),
        gemini_socket_path=os.getenv("GEMINI_DAEMON_SOCK", DEFAULT_GEMINI_SOCKET_PATH),
        base_branch=os.getenv("PYLEGO_BASE_BRANCH", "main"),
        dev_prompt_timeout_sec=_read_float_env("PYLEGO_DEV_TIMEOUT", _DEFAULT_DEV_TIMEOUT_SEC),
        qa_prompt_timeout_sec=_read_float_env("PYLEGO_QA_TIMEOUT", _DEFAULT_QA_TIMEOUT_SEC),
        prompt_backend=os.getenv("PYLEGO_PROMPT_BACKEND", "copilot"),  # type: ignore[arg-type]
    )


def _run_command(args: argparse.Namespace) -> int:
    config = _load_config(args.issue_number)

    if args.dry_run:
        pipeline = build_ai_pi_pipeline(config)
        print(repr(pipeline))
        return 0

    result = asyncio.run(run_ai_pi(config))
    if result.final_state == "merged":
        return 0
    if result.final_state == "failed":
        return 1
    if result.final_state == "escalated":
        return 2
    raise RuntimeError(f"알 수 없는 final_state: {result.final_state!r}")

def _assemble_command(args: argparse.Namespace) -> int:
    # Lazy import to avoid pulling pyyaml requirement unless used.
    try:
        from pylego.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: cannot load declarative loader: {exc}")
        return 2
    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to parse assembly: {exc}")
        return 2
    if args.dry_run:
        print(repr(assembly))
        return 0
    # For now, assemble command only parses and prints the assembly.
    print(repr(assembly))
    return 0


def _inspect_command(args: argparse.Namespace) -> int:
    if args.inspect_command == "list":
        installed: bool = getattr(args, "installed", False)
        return inspect_list(root=args.module, output_format=args.format, installed=installed)
    if args.inspect_command == "show":
        return inspect_show(args.name, root=args.module)
    if args.inspect_command == "matrix":
        return inspect_matrix(root=args.module, output_format=args.format)
    if args.inspect_command == "graph":
        return inspect_graph(args.file, output_format=args.format, output_file=args.output)
    raise ValueError(f"알 수 없는 inspect 명령: {args.inspect_command}")


def _serve_command(args: argparse.Namespace) -> int:
    """pylego serve <yaml> [--host H] [--port P] [--reload]"""
    try:
        from pylego.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to load assembly: {exc}", file=sys.stderr)
        return 2
    try:
        from pylego.serve import serve
    except ImportError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    serve(assembly, host=args.host, port=args.port, reload=args.reload)
    return 0


def _run_unit_command(args: argparse.Namespace) -> int:
    """pylego run-unit <module.Class> [--input '{}'] [--schema]"""
    import importlib

    qualified = args.unit
    parts = qualified.rsplit(".", 1)
    if len(parts) != 2:
        print(f"error: expected module.ClassName, got {qualified!r}", file=sys.stderr)
        return 2

    module_name, class_name = parts
    try:
        mod = importlib.import_module(module_name)
    except ImportError as exc:
        print(f"error: cannot import {module_name!r}: {exc}", file=sys.stderr)
        return 2

    cls = getattr(mod, class_name, None)
    if cls is None:
        print(f"error: {class_name!r} not found in {module_name!r}", file=sys.stderr)
        return 2

    from pylego.unit import Unit, run_unit_main, unit_schema

    if not (isinstance(cls, type) and issubclass(cls, Unit)):
        print(f"error: {qualified!r} is not a Unit subclass", file=sys.stderr)
        return 2

    unit = cls()

    if args.schema:
        import json
        print(json.dumps(unit_schema(unit), ensure_ascii=False, indent=2))
        return 0

    if args.input is None:
        print("error: --input JSON is required (or use --schema)", file=sys.stderr)
        return 2

    run_unit_main(unit, argv=[args.input])
    return 0


def _schedule_command(args: argparse.Namespace) -> int:
    """pylego schedule run-once <yaml> [--input '{}']"""
    import json

    try:
        from pylego.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: cannot load declarative loader: {exc}", file=sys.stderr)
        return 2

    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to load assembly: {exc}", file=sys.stderr)
        return 2

    if args.schedule_command == "run-once":
        from pylego.scheduler import run_once

        first_block = assembly._blocks[0]
        input_model = getattr(first_block, "input_model", None)
        if input_model is None:
            print("error: first block has no input_model", file=sys.stderr)
            return 2
        raw = args.input or "{}"
        try:
            inp = input_model.model_validate(json.loads(raw))
        except Exception as exc:
            print(f"error: invalid input: {exc}", file=sys.stderr)
            return 2
        result = run_once(assembly, input=inp)
        print(result.model_dump_json(indent=2))
        return 0

    print(f"error: unknown schedule subcommand: {args.schedule_command!r}", file=sys.stderr)
    return 2


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        try:
            return _run_command(args)
        except ValueError as exc:
            parser.error(str(exc))
        except ValidationError as exc:
            parser.error(str(exc))
    if args.command == "run-unit":
        return _run_unit_command(args)
    if args.command == "inspect":
        try:
            return _inspect_command(args)
        except ValueError as exc:
            parser.error(str(exc))
    if args.command == "assemble":
        return _assemble_command(args)
    if args.command == "serve":
        return _serve_command(args)
    if args.command == "schedule":
        return _schedule_command(args)
    parser.error(f"알 수 없는 명령: {args.command}")
