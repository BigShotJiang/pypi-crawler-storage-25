"""패턴 04: 관찰 가능성 — 로깅 / 이벤트 수집 / DAG 시각화.

OpenTelemetry 통합은 `pip install pylego[otel]` 후 사용.
"""

import asyncio
from pylego import (
    Assembly, Block, CollectingEventBus, LoggingEventBus,
    Stud, build_stats, observe, to_html, to_mermaid,
)


class Num(Stud):
    value: int

class Doubled(Stud):
    value: int


class DoubleBlock(Block[Num, Doubled]):
    input_model = Num
    output_model = Doubled

    async def run(self, inp: Num) -> Doubled:
        return Doubled(value=inp.value * 2)

class AddOneBlock(Block[Doubled, Doubled]):
    input_model = Doubled
    output_model = Doubled

    async def run(self, inp: Doubled) -> Doubled:
        return Doubled(value=inp.value + 1)


pipeline = Assembly([DoubleBlock(), AddOneBlock()], name="MyPipeline")


# ─── 1. 구조화 로깅 ───────────────────────────────────────────────────────────

async def run_with_logging() -> None:
    with observe(LoggingEventBus()):
        result = await pipeline.run(Num(value=5))
    # 로그: DoubleBlock started/completed (elapsed), AddOneBlock started/completed


# ─── 2. 이벤트 수집 + 통계 ───────────────────────────────────────────────────

async def run_with_stats() -> None:
    bus = CollectingEventBus()
    with observe(bus):
        result = await pipeline.run(Num(value=5))

    stats = build_stats(bus.events)
    for name, stat in stats.items():
        elapsed = f"{stat.elapsed_sec:.4f}s" if stat.elapsed_sec else "N/A"
        print(f"{name}: {stat.status} ({elapsed})")
    # DoubleBlock: ok (0.0001s)
    # AddOneBlock: ok (0.0001s)


# ─── 3. Mermaid DAG 시각화 ────────────────────────────────────────────────────

def print_mermaid() -> None:
    print(to_mermaid(pipeline))
    # flowchart LR
    #   b_0["DoubleBlock"] --> b_1["AddOneBlock"]


# ─── 4. HTML 실행 리포트 ──────────────────────────────────────────────────────

async def save_html_report() -> None:
    bus = CollectingEventBus()
    with observe(bus):
        await pipeline.run(Num(value=5))

    html = to_html(pipeline, stats=build_stats(bus.events), title="실행 리포트")
    with open("/tmp/report.html", "w") as f:
        f.write(html)
    print("리포트 저장: /tmp/report.html")


# ─── 5. OpenTelemetry (pylego[otel] 필요) ────────────────────────────────────

def run_with_otel() -> None:
    import os
    os.environ["PYLEGO_OTEL_ENDPOINT"] = "http://localhost:4318"
    os.environ["PYLEGO_OTEL_SERVICE_NAME"] = "my-pipeline"

    from pylego import OtelEventBus, configure_otel_from_env
    configure_otel_from_env()

    async def _run() -> None:
        with observe(OtelEventBus()):
            await pipeline.run(Num(value=5))
        # Jaeger / Grafana Tempo 에서 trace 확인

    asyncio.run(_run())


if __name__ == "__main__":
    asyncio.run(run_with_logging())
    asyncio.run(run_with_stats())
    print_mermaid()
    asyncio.run(save_html_report())
