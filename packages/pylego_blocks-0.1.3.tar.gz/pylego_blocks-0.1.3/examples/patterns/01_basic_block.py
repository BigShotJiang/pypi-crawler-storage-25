"""패턴 01: 기본 블록 — 최소 구현 템플릿.

AI 사용법: 이 파일을 그대로 복사한 뒤 클래스명·필드·로직만 교체한다.
"""

import asyncio
from pylego import Block, Assembly, Stud


# ─── 1. Stud (I/O 계약) ──────────────────────────────────────────────────────

class TextIn(Stud):
    text: str

class TextOut(Stud):
    result: str


# ─── 2. Block (실행 단위) ─────────────────────────────────────────────────────

class UpperBlock(Block[TextIn, TextOut]):
    input_model = TextIn
    output_model = TextOut

    async def run(self, inp: TextIn) -> TextOut:
        return TextOut(result=inp.text.upper())


class ExclamBlock(Block[TextOut, TextOut]):
    input_model = TextOut
    output_model = TextOut

    async def run(self, inp: TextOut) -> TextOut:
        return TextOut(result=inp.result + "!")


# ─── 3. 단독 실행 ─────────────────────────────────────────────────────────────

async def run_single() -> None:
    block = UpperBlock()
    result = await block.run(TextIn(text="hello"))
    print(result.result)  # HELLO


# ─── 4. Assembly 체인 ─────────────────────────────────────────────────────────

def run_pipeline() -> None:
    pipeline = Assembly([UpperBlock(), ExclamBlock()])
    result = pipeline.run_sync(TextIn(text="hello world"))
    print(result.result)  # HELLO WORLD!


if __name__ == "__main__":
    asyncio.run(run_single())
    run_pipeline()
