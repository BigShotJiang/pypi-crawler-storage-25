"""패턴 05: HTTP API 서빙 — Assembly → FastAPI REST 엔드포인트.

pip install pylego[serve]

실행:
    python examples/patterns/05_http_serve.py
    # 또는
    pylego serve my_pipeline.yaml --port 8000

테스트:
    curl -X POST http://localhost:8000/run -H "Content-Type: application/json" -d '{"value": 5}'
    curl http://localhost:8000/health
    curl http://localhost:8000/openapi.json
"""

from pylego import Assembly, Block, Stud
from pylego.serve import build_app, serve


class CalcIn(Stud):
    value: int
    multiplier: int = 2

class CalcOut(Stud):
    result: int
    original: int


class MultiplyBlock(Block[CalcIn, CalcOut]):
    input_model = CalcIn
    output_model = CalcOut

    async def run(self, inp: CalcIn) -> CalcOut:
        return CalcOut(result=inp.value * inp.multiplier, original=inp.value)


pipeline = Assembly([MultiplyBlock()], name="CalcPipeline")


# ─── 방법 1: uvicorn 직접 실행 ────────────────────────────────────────────────

def run_server() -> None:
    serve(pipeline, host="0.0.0.0", port=8000)  # 블로킹


# ─── 방법 2: FastAPI 앱 객체 취득 (ASGI 프레임워크 통합) ──────────────────────

app = build_app(pipeline)
# uvicorn.run(app, host="0.0.0.0", port=8000)
# gunicorn -k uvicorn.workers.UvicornWorker mymodule:app

# ─── 방법 3: pytest + TestClient 테스트 ──────────────────────────────────────

def test_endpoint() -> None:
    from fastapi.testclient import TestClient

    client = TestClient(app)

    resp = client.post("/run", json={"value": 7})
    assert resp.status_code == 200
    data = resp.json()
    assert data["result"] == 14
    assert "_meta" in data and "elapsed_sec" in data["_meta"]

    health = client.get("/health")
    assert health.json()["status"] == "ok"
    assert health.json()["assembly"] == "CalcPipeline"

    print("테스트 통과")


if __name__ == "__main__":
    # test_endpoint()  # 테스트 실행
    run_server()      # 서버 실행
