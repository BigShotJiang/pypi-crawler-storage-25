"""
Taken, changed and adopted from:
    https://github.com/bernardopires/django-tenant-schemas/blob/master/tenant_schemas/postgresql_backend/base.py
Credits goes to bernardopires

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.
"""

import logging
import re

from django.conf import settings
from django.db.backends.base.base import NO_DB_ALIAS
from django.db.backends.postgresql.base import DatabaseWrapper as BaseDatabaseWrapper
from django.db.utils import DatabaseError, IntegrityError
from django.utils.module_loading import import_string
from psycopg import sql
from psycopg.errors import InternalError

from djanquiltdb.postgresql_backend.introspection import DatabaseSchemaIntrospection
from djanquiltdb.postgresql_backend.utils import CursorDebugWrapper, CursorWrapper

logger = logging.getLogger(__name__)

# Clone function is from the PostgreSQL wiki by Emanuel '3manuek'.
# Adjusted to set the value of the created sequences to the same value as those we clone.
clone_function = """
CREATE OR REPLACE FUNCTION clone_schema(source_schema TEXT, dest_schema TEXT) RETURNS VOID AS
$BODY$
DECLARE
  default_ TEXT;
  column_ TEXT;
  name_ TEXT;
  child_column_ TEXT;
  dest_table TEXT;
  dest_table_path TEXT;
  parent_table_ TEXT;
  parent_schema_ TEXT;
  parent_column_ TEXT;
  seq_name TEXT;
  tbl_name TEXT;
  max_id_val BIGINT;
  trigger_def TEXT;
  trigger_name TEXT;
  adapted_trigger_def TEXT;
  func_name TEXT;
  func_schema TEXT;
  func_def TEXT;
  adapted_func_def TEXT;

BEGIN
  /* Set search_path to include source_schema and public so information_schema queries work correctly.
   * We need source_schema in search_path so that column_default expressions referencing sequences
   * in source_schema are visible.
   */
  EXECUTE 'SET LOCAL search_path = ' || quote_ident(source_schema) || ',public,pg_catalog';

  /* Create all sequences that exist on the source schema on the target schema. */
  FOR dest_table IN
    SELECT sequence_name::text FROM information_schema.SEQUENCES WHERE sequence_schema = source_schema
  LOOP
    EXECUTE 'CREATE SEQUENCE IF NOT EXISTS ' || dest_schema || '.' || dest_table;
    /* Set sequence value based on source sequence last_value.
     * After tables are cloned, we'll update sequences to ensure they're higher than any existing IDs.
     */
    EXECUTE format('SELECT setval(%L, (SELECT last_value FROM %I.%I), (SELECT is_called FROM %I.%I))',
      dest_schema || '.' || dest_table, source_schema, dest_table, source_schema, dest_table);
  END LOOP;

  FOR dest_table IN
    SELECT TABLE_NAME::text FROM information_schema.TABLES WHERE table_schema = source_schema
  LOOP
    dest_table_path := dest_schema || '.' || dest_table;
    /* Create all tables on the target schema. */
    EXECUTE 'CREATE TABLE ' || dest_table_path || ' (LIKE ' || source_schema || '.' || dest_table || ' INCLUDING ALL)';
    EXECUTE 'INSERT INTO ' || dest_table_path || '(SELECT * FROM ' || source_schema || '.' || dest_table || ')';

    /* For all tables, link the fields default value to their respective sequences made earlier. */
    FOR column_, default_ IN
      SELECT column_name::TEXT, regexp_replace(column_default::TEXT, source_schema, dest_schema)
        FROM information_schema.COLUMNS WHERE table_schema = dest_schema AND TABLE_NAME = dest_table
        AND column_default LIKE 'nextval(%' || source_schema || '%)'
    LOOP
      EXECUTE 'ALTER TABLE ' || dest_table_path || ' ALTER COLUMN ' || column_ || ' SET DEFAULT ' || default_;
    END LOOP;
  END LOOP;

  /* For all tables, create their foreign key constraints.
   * Do not use the information_schema for this. The views there are very slow. We use pg_catalog directly.
   * This endeavor has two sources:
   * hielkehoeve on feb 2014 - for the constraint cloning loop: https://gist.github.com/hielkehoeve/8818562 .
   * Cervo on may 2015 - for the pg_catalog query: https://stackoverflow.com/a/30178351 .
   */
  FOR dest_table IN
    SELECT TABLE_NAME::text FROM information_schema.TABLES WHERE table_schema = source_schema
  LOOP
    dest_table_path := dest_schema || '.' || dest_table;
    FOR name_, child_column_, parent_schema_, parent_table_, parent_column_ IN
      SELECT
        con.constraint_name AS "name_",
        pg_attribute2.attname AS "child_column_",
        /* Replace the source schema with destination schema. Keep others schema's (like 'public') intact. */
        REPLACE (pg_namespace_outer.nspname, source_schema, dest_schema) AS "parent_schema_",
        pg_class.relname AS "parent_table_",
        pg_attribute1.attname AS "parent_column_"
      FROM
        ( SELECT
            unnest(pg_constraint.conkey) as "parent",
            unnest(pg_constraint.confkey) as "child",
            pg_constraint.conname as constraint_name,
            pg_constraint.confrelid,
            pg_constraint.conrelid
          FROM pg_catalog.pg_class AS pg_class
            JOIN pg_catalog.pg_namespace AS pg_namespace_inner ON pg_namespace_inner.oid = pg_class.relnamespace
            JOIN pg_catalog.pg_constraint AS pg_constraint ON pg_constraint.conrelid = pg_class.oid
          WHERE pg_constraint.contype = 'f'  /* foreign key */
            AND pg_namespace_inner.nspname = source_schema
            AND pg_class.relname = dest_table  /* child_table */
            AND pg_class.relkind = 'r'  /* ordinary table */
        ) AS con
        JOIN pg_catalog.pg_attribute AS pg_attribute1 ON pg_attribute1.attrelid = con.confrelid
                                                      AND pg_attribute1.attnum = con.child
        JOIN pg_catalog.pg_class AS pg_class ON pg_class.oid = con.confrelid
        JOIN pg_catalog.pg_attribute AS pg_attribute2 ON pg_attribute2.attrelid = con.conrelid
                                                      AND pg_attribute2.attnum = con.parent
        JOIN pg_catalog.pg_namespace AS pg_namespace_outer ON pg_namespace_outer.oid = pg_class.relnamespace
    LOOP
      EXECUTE 'ALTER TABLE ' || dest_table_path || ' ADD CONSTRAINT ' || name_ || '
        FOREIGN KEY (' || child_column_ || ')
        REFERENCES ' || parent_schema_ || '.' || parent_table_ || ' (' || parent_column_ || ')
        DEFERRABLE INITIALLY DEFERRED';
    END LOOP;
  END LOOP;

  /* Clone all functions from the source schema to the destination schema.
   * This must be done after tables are cloned, because functions may reference tables.
   * This is also necessary because triggers (cloned next) may reference functions in the same schema.
   */
  FOR func_name, func_def IN
    SELECT
      p.proname::text AS func_name,
      pg_get_functiondef(p.oid) AS func_def
    FROM pg_catalog.pg_proc p
    JOIN pg_catalog.pg_namespace n ON p.pronamespace = n.oid
    WHERE n.nspname = source_schema
  LOOP
    /* Replace schema names in the function definition */
    adapted_func_def := REPLACE(func_def, source_schema || '.', dest_schema || '.');
    /* Replace the function name and schema in CREATE FUNCTION statement */
    adapted_func_def := REPLACE(adapted_func_def,
      'CREATE FUNCTION ' || source_schema || '.' || func_name,
      'CREATE FUNCTION ' || dest_schema || '.' || func_name);
    adapted_func_def := REPLACE(adapted_func_def,
      'CREATE OR REPLACE FUNCTION ' || source_schema || '.' || func_name,
      'CREATE OR REPLACE FUNCTION ' || dest_schema || '.' || func_name);
    /* Execute the adapted function definition */
    EXECUTE adapted_func_def;
  END LOOP;

  /* For all tables, clone their triggers.
   * We query pg_trigger to get all triggers from the source schema tables,
   * then use pg_get_triggerdef to get the CREATE TRIGGER statement and adapt it for the destination schema.
   */
  FOR dest_table IN
    SELECT TABLE_NAME::text FROM information_schema.TABLES WHERE table_schema = source_schema
  LOOP
    dest_table_path := dest_schema || '.' || dest_table;
    FOR trigger_name, trigger_def, func_schema, func_name IN
      SELECT
        tg.tgname::text AS trigger_name,
        pg_get_triggerdef(tg.oid) AS trigger_def,
        nsp_func.nspname::text AS func_schema,
        p.proname::text AS func_name
      FROM pg_catalog.pg_trigger tg
      JOIN pg_catalog.pg_class cls ON tg.tgrelid = cls.oid
      JOIN pg_catalog.pg_namespace nsp ON cls.relnamespace = nsp.oid
      JOIN pg_catalog.pg_proc p ON tg.tgfoid = p.oid
      JOIN pg_catalog.pg_namespace nsp_func ON p.pronamespace = nsp_func.oid
      WHERE nsp.nspname = source_schema
        AND cls.relname = dest_table
        AND NOT tg.tgisinternal  /* Exclude internal triggers (e.g., for foreign keys) */
    LOOP
      /* Replace schema names in the trigger definition.
       * pg_get_triggerdef returns a CREATE TRIGGER statement that may include schema-qualified names.
       * We need to replace:
       * 1. Schema-qualified table names in ON clause
       * 2. Function names in EXECUTE FUNCTION clause (with or without schema qualification)
       * 3. Any other schema references
       */
      adapted_trigger_def := trigger_def;
      /* Replace schema-qualified table name in ON clause (with and without quotes) */
      adapted_trigger_def := REPLACE(adapted_trigger_def,
        'ON ' || source_schema || '.' || dest_table || ' ',
        'ON ' || dest_table_path || ' ');
      adapted_trigger_def := REPLACE(adapted_trigger_def,
        'ON ' || quote_ident(source_schema) || '.' || quote_ident(dest_table) || ' ',
        'ON ' || dest_table_path || ' ');

      /* Replace function name in EXECUTE FUNCTION clause.
       * pg_get_triggerdef may or may not include schema qualification, so we handle both cases:
       * 1. If function is in source_schema, replace with dest_schema (whether qualified or not)
       * 2. If function is in another schema (like public), keep it as is
       */
      IF func_schema = source_schema THEN
        /* Function is in source schema - replace with dest schema */
        /* First, replace schema-qualified function name (with and without quotes) */
        adapted_trigger_def := REPLACE(adapted_trigger_def,
          'EXECUTE FUNCTION ' || source_schema || '.' || func_name || '()',
          'EXECUTE FUNCTION ' || dest_schema || '.' || func_name || '()');
        adapted_trigger_def := REPLACE(adapted_trigger_def,
          'EXECUTE FUNCTION ' || quote_ident(source_schema) || '.' || quote_ident(func_name) || '()',
          'EXECUTE FUNCTION ' || dest_schema || '.' || func_name || '()');
        /* Replace unqualified function name (when function is in same schema, pg_get_triggerdef may omit schema).
         * We need to be careful to match the exact function name, not a substring.
         * Use a regex-like approach: match 'EXECUTE FUNCTION ' followed by func_name and '()'
         */
        adapted_trigger_def := regexp_replace(adapted_trigger_def,
          'EXECUTE FUNCTION ' || quote_ident(func_name) || '\\(\\)',
          'EXECUTE FUNCTION ' || dest_schema || '.' || func_name || '()',
          'g');
        /* Also handle unquoted function name */
        adapted_trigger_def := regexp_replace(adapted_trigger_def,
          'EXECUTE FUNCTION ' || func_name || '\\(\\)',
          'EXECUTE FUNCTION ' || dest_schema || '.' || func_name || '()',
          'g');
      ELSE
        /* Function is in another schema (like public) - only replace if it incorrectly references source_schema */
        adapted_trigger_def := REPLACE(adapted_trigger_def,
          'EXECUTE FUNCTION ' || source_schema || '.' || func_name || '()',
          'EXECUTE FUNCTION ' || func_schema || '.' || func_name || '()');
        adapted_trigger_def := REPLACE(adapted_trigger_def,
          'EXECUTE FUNCTION ' || quote_ident(source_schema) || '.' || quote_ident(func_name) || '()',
          'EXECUTE FUNCTION ' || func_schema || '.' || func_name || '()');
      END IF;

      /* Replace any remaining schema references */
      adapted_trigger_def := REPLACE(adapted_trigger_def, source_schema || '.', dest_schema || '.');

      /* Execute the adapted trigger definition */
      EXECUTE adapted_trigger_def;
    END LOOP;
  END LOOP;

  /* After cloning all tables, update sequences/identity columns to be higher than any existing IDs.
   * This prevents ID conflicts when inserting new records after cloning.
   * Handle both:
   * - Sequences (older Django versions)
   * - Identity columns (Django 6.0+)
   */
  FOR dest_table IN
    SELECT TABLE_NAME::text FROM information_schema.TABLES WHERE table_schema = dest_schema
  LOOP
    BEGIN
      /* Check if table has an id column and get max ID */
      EXECUTE format('SELECT COALESCE(MAX(id), 0) FROM %I.%I WHERE id IS NOT NULL',
        dest_schema, dest_table) INTO max_id_val;

      IF max_id_val > 0 THEN
        /* Try to get the sequence/identity sequence name */
        DECLARE
          seq_name_val TEXT;
        BEGIN
          seq_name_val := pg_get_serial_sequence(dest_schema || '.' || dest_table, 'id');
          IF seq_name_val IS NOT NULL THEN
            /* Reset sequence/identity to continue from max_id_val + 1 */
            EXECUTE format('SELECT setval(%L, %s, false)',
              seq_name_val, max_id_val + 1);
          END IF;
        END;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        /* If table doesn't have id column or other error, skip */
        NULL;
    END;
  END LOOP;
END;
$BODY$
LANGUAGE plpgsql VOLATILE;
"""

PUBLIC_SCHEMA_NAME = 'public'


def get_validated_schema_name(schema_name, is_template=False):
    from djanquiltdb.utils import get_template_name  # Prevent cyclic imports

    if not isinstance(schema_name, str):
        raise ValueError("Schema name '{}' needs to be a string".format(schema_name))

    if not re.match(r'^[A-Za-z][0-9A-Za-z_]*$', schema_name):
        raise ValueError(
            "Schema name '{}' contains illegal characters and/or does not start with a letter".format(schema_name)
        )

    if not is_template and schema_name == get_template_name():
        raise ValueError(
            "Schema name '{}' cannot be the same as the template name '{}' ".format(schema_name, get_template_name())
        )
    if schema_name in [PUBLIC_SCHEMA_NAME, 'information_schema', 'default']:
        raise ValueError("Schema name '{}' is not allowed ".format(schema_name))

    if schema_name.startswith('pg_'):
        raise ValueError(
            "Schema name '{}' is not allowed to mimic PostgreSQL native schema names (starting with 'pg_')".format(
                schema_name
            )
        )

    return schema_name


def get_database_creation_class():
    return import_string(
        settings.QUILT_DB.get('DATABASE_CREATION_CLASS', 'djanquiltdb.postgresql_backend.creation.DatabaseCreation')
    )


class DatabaseWrapper(BaseDatabaseWrapper):
    """
    Adds the capability to manipulate the search_path using set_schema and set_schema_to_public
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Replace the default introspection with a patched version of
        # the DatabaseIntrospection that only returns the table list
        # for the currently selected schema.
        self.introspection = DatabaseSchemaIntrospection(self)

        # Give the library user the possibility to overwrite the database creation class. This allows them to adjust the
        # creation of the test database, to make a default shard for example.
        self.creation = get_database_creation_class()(self)

        self.current_search_paths = [PUBLIC_SCHEMA_NAME]

        self.schema_name = PUBLIC_SCHEMA_NAME
        self.include_public_schema = True

        # Django < 2.0 require this attribute set, in our case it should be just a noop.
        if hasattr(self, '_start_transaction_under_autocommit'):
            self._start_transaction_under_autocommit = lambda x: None

    def __str__(self):
        return self.alias

    def close(self):
        self.current_search_paths = [PUBLIC_SCHEMA_NAME]
        super().close()

    def rollback(self):
        super().rollback()
        self.current_search_paths = [PUBLIC_SCHEMA_NAME]

    def commit(self):
        # Reset current_search_paths so the next _cursor() call re-issues SET search_path. This is necessary for
        # PgBouncer in transaction-pooling mode: after a commit, the next transaction may be handed a different physical
        # connection that has no search_path set, so we must not skip the SET even if the schema hasn't changed.
        try:
            super().commit()
        finally:
            self.current_search_paths = [PUBLIC_SCHEMA_NAME]

    def get_schema(self):
        return self.schema_name

    def is_public_schema(self):
        return self.schema_name == PUBLIC_SCHEMA_NAME

    def get_ps_schema(self, schema_name, _cursor=None):
        cursor = _cursor or self.cursor()
        cursor.execute('SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_namespace WHERE nspname = %s);', [schema_name])
        if cursor.fetchall()[0][0]:
            return schema_name

    def get_all_pg_schemas(self, _cursor=None):
        return self.introspection.get_schema_names(_cursor or self.cursor())

    def get_all_table_headers(self, schema_name=None, _cursor=None):
        cursor = _cursor or self.cursor()
        schema = schema_name or self.get_schema()
        cursor.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema=%s AND table_type='BASE TABLE';",
            [schema],
        )
        return [x[0] for x in cursor.fetchall()]  # We get a list of single tuples

    def get_all_table_sequences(self, schema_name=None, _cursor=None):
        cursor = _cursor or self.cursor()
        schema = schema_name or self.get_schema()
        cursor.execute(
            """
            SELECT cls.relname::text 
            FROM pg_catalog.pg_sequence seq
            JOIN pg_catalog.pg_class cls ON seq.seqrelid = cls.oid
            JOIN pg_catalog.pg_namespace nsp ON cls.relnamespace = nsp.oid
            WHERE nsp.nspname = %s
        """,
            [schema],
        )
        return [x[0] for x in cursor.fetchall()]  # We get a list of single tuples

    def truncate_all_tables(self, schema_name=None, _cursor=None):
        cursor = _cursor or self.cursor()
        table_headers = self.get_all_table_headers(schema_name, cursor)
        cursor.execute('TRUNCATE ONLY {} CASCADE;'.format(', '.join('"{}"'.format(header) for header in table_headers)))

    def flush_schema(self, schema_name=None, _cursor=None):
        """
        Drops all tables on the given schema
        """
        cursor = _cursor or self.cursor()
        schema = schema_name or self.get_schema()
        # Get all sequences first, before dropping tables
        sequences = self.get_all_table_sequences(schema_name=schema)
        # Drop tables with CASCADE (this will also drop sequences owned by tables)
        # Use schema-qualified table names to ensure we drop from the correct schema
        for table in self.get_all_table_headers(schema_name=schema):
            cursor.execute('DROP TABLE "{schema}"."{table}" CASCADE'.format(schema=schema, table=table))
        # Drop any remaining sequences that weren't owned by tables
        # (DROP TABLE CASCADE drops sequences owned by tables, but sequences can exist independently)
        for sequence in sequences:
            cursor.execute(
                'DROP SEQUENCE IF EXISTS "{schema}"."{sequence}" CASCADE'.format(schema=schema, sequence=sequence)
            )

    def get_schema_for_model(self, model, _cursor=None):
        """
        Returns the schema the given model lives on.
        """
        cursor = _cursor or self.cursor()
        cursor.execute(
            'SELECT table_schema FROM information_schema.tables WHERE table_name=%s;', [model._meta.db_table]
        )
        return cursor.fetchall()

    def get_schema_for_sequence(self, sequence_name, _cursor=None):
        cursor = _cursor or self.cursor()
        cursor.execute(
            """
            SELECT nspname::text 
            FROM pg_catalog.pg_sequence seq
            JOIN pg_catalog.pg_class cls ON seq.seqrelid = cls.oid
            JOIN pg_catalog.pg_namespace nsp ON cls.relnamespace = nsp.oid
            WHERE cls.relname = %s
        """,
            [sequence_name],
        )
        return cursor.fetchall()

    def create_schema(self, schema_name, is_template=False):
        schema_name = get_validated_schema_name(schema_name, is_template=is_template)
        cursor = self.cursor()
        cursor.execute(
            'CREATE SCHEMA IF NOT EXISTS "{}";'.format(schema_name)
        )  # Params cannot be used for schema names

    def delete_schema(self, schema_name, is_template=False):
        schema_name = get_validated_schema_name(schema_name, is_template=is_template)
        cursor = self.cursor()
        cursor.execute('DROP SCHEMA "{}" CASCADE;'.format(schema_name))  # Params cannot be used for schema names

    def clone_schema(self, from_schema, to_schema):
        cursor = self.cursor()
        if not self.get_ps_schema(from_schema, cursor):
            raise ValueError("Schema '{}' does not exist on node '{}'.".format(from_schema, self))
        if not self.get_ps_schema(to_schema, cursor):
            raise ValueError("Schema '{}' does not exist on node '{}'.".format(to_schema, self))

        self.set_clone_function()

        cursor.execute('SELECT clone_schema(%s, %s);', [from_schema, to_schema])

    def set_clone_function(self, _cursor=None):
        cursor = _cursor or self.cursor()
        cursor.execute(clone_function)

    def reset_sequence(self, model_list, _cursor=None):
        from django.db import models

        cursor = _cursor or self.cursor()
        statements = []
        qn = self.ops.quote_name
        for model in model_list:
            # Use `coalesce` to set the sequence for each model to the max pk value if there are records,
            # or 1 if there are none. Set the `is_called` property (the third argument to `setval`) to true
            # if there are records (as the max pk value is already in use), otherwise set it to false.

            for f in model._meta.local_fields:
                if isinstance(f, models.AutoField):
                    statements.append(
                        "SELECT setval('{s}', coalesce(max({f}), 1), max({f}) IS NOT null) FROM {qnm}".format(  # nosec
                            s='{}_{}_seq'.format(model._meta.db_table, f.column),
                            f=qn(f.column),
                            qnm=qn(model._meta.db_table),
                        )
                    )
                    break  # Only one AutoField is allowed per model, so don't bother continuing.
            for f in model._meta.many_to_many:
                # Django < 2.0
                remote_field = 'rel' if hasattr(f, 'rel') else 'remote_field'
                if not getattr(f, remote_field).through:
                    statements.append(
                        "SELECT setval('{s}', coalesce(max({f}), 1), max({f}) IS NOT null) FROM {qnm}".format(  # nosec
                            s='{}_{}_seq'.format(f.m2m_db_table(), 'id'), f=qn('id'), qnm=qn(f.m2m_db_table())
                        )
                    )
        cursor.execute(';\n'.join(statements))

    def make_debug_cursor(self, cursor, skip_lock=False):
        """
        Creates a cursor that logs all queries in self.queries_log, and that can set advisory locks as well.
        """
        return CursorDebugWrapper(cursor, self, lock=getattr(self, 'lock_on_execute', False) and not skip_lock)

    def make_cursor(self, cursor, skip_lock=False):
        """
        Creates a cursor without debug logging, and that can set advisory locks as well.
        """
        return CursorWrapper(cursor, self, lock=getattr(self, 'lock_on_execute', False) and not skip_lock)

    def acquire_advisory_lock(self, key, shared=True, _cursor=None):
        """
        Set a shared or exclusive advisory lock on a given key.
        """
        cursor = _cursor or self.cursor()
        cursor.acquire_advisory_lock(key, shared=shared)

    def release_advisory_lock(self, key, shared=True, _cursor=None):
        """
        Release a shared or exclusive advisory lock on a given key.
        """
        cursor = _cursor or self.cursor()
        cursor.release_advisory_lock(key, shared=shared)

    def cursor(self):
        """
        Note that this is backported from Django 1.11 to have the same behaviour between Django 1.8 to Django 1.11.
        """
        return self._cursor()

    def _cursor(self, name=None):
        """Database cursor to write whatever we want.

        Typically used for migrations, this function will check
        to see if SCHEMA_NAME is set or not. If it is, then it
        will create it if it doesn't yet exist. Finally, it will
        point to that schema.

        Check for a connection and see if it is usable. If not: close the connection and the Super() class will
        automatically reconnect in its _cursor() function.
        """
        if self.connection is not None and self.errors_occurred:
            if not self.is_usable():
                logger.warning('Database connection is unusable. Reconnecting and continuing.')
                self.close()

        cursor = self._get_cursor(name=name)

        if self.include_public_schema and self.schema_name != PUBLIC_SCHEMA_NAME:
            search_paths = [self.schema_name, PUBLIC_SCHEMA_NAME]
        else:
            search_paths = [self.schema_name]

        # No need to set search paths for operations without a database,
        # or when there are no changes to the selected schemas.
        if self.alias == NO_DB_ALIAS or self.current_search_paths == search_paths:
            return cursor

        # Use unnamed cursors for schema operations - named cursors require SELECT statements
        # and cannot execute SET commands like SET search_path
        with self._get_cursor(name=None, skip_lock=True) as cursor_for_get_ps_schema:
            if self.schema_name != PUBLIC_SCHEMA_NAME and not self.get_ps_schema(
                self.schema_name, cursor_for_get_ps_schema
            ):
                raise IntegrityError("Schema '{}' does not exist.".format(self.schema_name))

        with self._get_cursor(name=None, skip_lock=True) as cursor_for_search_path:
            # In the event that an error already happened in this transaction and we are going
            # to rollback we should just ignore database error when setting the search_path
            # if the next instruction is not a rollback it will just fail also, so
            # we do not have to worry that it's not the good one
            try:
                identifiers = [sql.Identifier(x) for x in search_paths]
                sql_ = sql.SQL('SET search_path = {}').format(sql.SQL(', ').join(identifiers))
                cursor_for_search_path.execute(sql_)
                logger.debug(str(sql_))
            except (DatabaseError, InternalError):
                logger.warning('Something went wrong with setting the search path.', exc_info=True)
            else:
                self.current_search_paths = search_paths

        return cursor

    def _get_cursor(self, name=None, skip_lock=False):
        """
        Copied from Django 1.11's _cursor() method with the addition of `skip_lock`. Note that this is different from
        the _cursor() method from previous versions. For this library to work easily with multiple Django versions, we
        backported this from Django 1.11.
        """
        self.ensure_connection()
        with self.wrap_database_errors:
            cursor = self.create_cursor(name)
            return self._prepare_cursor(cursor, skip_lock=skip_lock)

    def _prepare_cursor(self, cursor, skip_lock=False):
        """
        Validate the connection is usable and perform database cursor wrapping. Copied from Django 1.11, but with an
        addition of `skip_lock`, which will return a cursor that doesn't do locking if `skip_lock` is True.
        """
        self.validate_thread_sharing()
        if self.queries_logged:
            wrapped_cursor = self.make_debug_cursor(cursor, skip_lock=skip_lock)
        else:
            wrapped_cursor = self.make_cursor(cursor, skip_lock=skip_lock)
        return wrapped_cursor


class ShardDatabaseWrapper(DatabaseWrapper):
    """
    Wrapper around DatabaseWrapper that handles shard routing. This class shares the connection of the database wrapper
    it wraps (from now one called the main connection). This ensures that we are not making a new connection to the
    database each time we switch to a certain schema name. In order to do this, we route all calls to the properties
    defined in _PROXY_FIELDS to the main connection instance (which are the same fields as in the constructor of
    DjangoBaseDatabaseWrapper, excluding `alias`, but including `current_search_paths`).

    Note that this class should not be used for connections to the public schema. You can use the main connection for
    that one.
    """

    _PROXY_FIELDS = (
        'connection',
        'settings_dict',
        'queries_log',
        'force_debug_cursor',
        'autocommit',
        'in_atomic_block',
        'atomic_blocks',
        'savepoint_state',
        'savepoint_ids',
        'commit_on_exit',
        'needs_rollback',
        'close_at',
        'closed_in_transaction',
        'errors_occurred',
        '_thread_ident',
        'current_search_paths',
        'run_on_commit',
        'run_commit_hooks_on_set_autocommit_on',
        'rollback_exc',
        'health_check_enabled',
        'health_check_done',
        'execute_wrappers',
    )

    _present_shard_options_as_alias = False

    def __init__(self, main_connection, options):
        self._main_connection = main_connection
        self.shard_options = options

        # We proxy the fields specified in _PROXY_FIELDS to the main connection. Because we call the super().__init__
        # here, that means that we would reset the values of the fields we proxy. We don't want that here, so we keep
        # track whether we are in the initialization state and only set the proxy values outside of the __init__ method.
        self._initialized = False
        super().__init__(
            settings_dict=main_connection.settings_dict,
            alias=main_connection.alias,
        )
        self._initialized = True

        if self.shard_options.schema_name == PUBLIC_SCHEMA_NAME:
            raise ValueError('Connection to the public schema should be handled by the default DatabaseWrapper.')

        self.schema_name = options.schema_name
        self.include_public_schema = options.kwargs.get('include_public', True)

        # Determine whether we need to set an advisory lock or not. If use_shard on the options is True, this means that
        # we activated this connection in a context manager, meaning that we already activated the lock and we don't
        # have to do that in the cursor's execute method.
        self.lock_on_execute = bool(options.lock and not options.use_shard and options.lock_keys)

    @property
    def alias(self):
        # See postgresql_backend.operations.patch_in_lookup() for information on this switch
        if self._present_shard_options_as_alias:
            return self.shard_options

        return '{}|{}'.format(self._main_connection.alias, self.schema_name)

    @alias.setter
    def alias(self, value):
        if value != self._main_connection.alias:
            raise ValueError('The alias is managed by the main connection and cannot be changed.')

    def __getattribute__(self, item):
        if item in ShardDatabaseWrapper._PROXY_FIELDS:
            return getattr(self._main_connection, item)
        return super().__getattribute__(item)

    def __setattr__(self, key, value):
        # We don’t want to reset the attributes on the main connection when initializing this class instance, hence we
        # check on the value of self._initialized here.
        if key in ShardDatabaseWrapper._PROXY_FIELDS and self._initialized:
            return setattr(self._main_connection, key, value)
        return super().__setattr__(key, value)

    def acquire_locks(self, shared=True):
        for key in self.shard_options.lock_keys:
            self.acquire_advisory_lock(key, shared=shared)

    def release_locks(self, shared=True):
        for key in self.shard_options.lock_keys:
            self.release_advisory_lock(key, shared=shared)
