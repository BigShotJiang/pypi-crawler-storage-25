class ShardingError(Exception):
    pass
