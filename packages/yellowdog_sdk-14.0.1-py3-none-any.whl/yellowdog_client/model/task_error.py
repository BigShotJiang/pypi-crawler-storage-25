from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from .task_status import TaskStatus


@dataclass
class TaskError:
    """Holds details of an error that occurred during execution of the task."""
    timestamp: datetime
    """The time at which the error occurred."""
    error: str
    """A description of the error."""
    nodeId: Optional[str] = None
    """The ID of the node where the error occurred."""
    workerId: Optional[str] = None
    """The ID of the worker where the error occurred."""
    errorType: str = "UNKNOWN_ERROR"
    statusAtFailure: Optional[TaskStatus] = None
    processExitCode: Optional[int] = None
