from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional

from .identified import Identified
from .named import Named
from .run_specification import RunSpecification
from .tagged import Tagged
from .task_group_status import TaskGroupStatus
from .task_summary import TaskSummary
from .task_template import TaskTemplate


@dataclass
class TaskGroup(Identified, Named, Tagged):
    """Defines a group of tasks to be executed as part of a WorkRequirement."""
    id: Optional[str] = field(default=None, init=False)
    status: Optional[TaskGroupStatus] = field(default=None, init=False)
    """The task group status."""
    statusChangedTime: Optional[datetime] = field(default=None, init=False)
    """The date and time when the status last changed"""
    taskSummary: Optional[TaskSummary] = field(default=None, init=False)
    name: str
    """The user allocated name used to uniquely identify the task group within its work requirement."""
    runSpecification: RunSpecification
    """The run specification which determines the YellowDog Scheduler behaviours when it is executing the tasks within the task group."""
    tag: Optional[str] = None
    priority: float = 0
    """The task group priority."""
    dependentOn: Optional[str] = None
    """
    The name of another task group within the same WorkRequirement that must be successfully completed before the task group is started.

    .. deprecated:: (unknown)
        use :attr:`dependencies` instead
    """

    dependencies: Optional[List[str]] = None
    """The names of other task groups within the same WorkRequirement that must be successfully completed before the task group is started."""
    starved: bool = False
    """Indicates if the task group is unable to claim any workers."""
    waitingOnDependency: bool = False
    """Indicates if the task group is waiting for a dependency task group to finish."""
    finishIfAllTasksFinished: bool = True
    """If true, the task group will finish automatically once all contained tasks are finished."""
    finishIfAnyTaskFailed: bool = False
    """If true, the task group will finish automatically if any contained tasks fail."""
    completedTaskTtl: Optional[timedelta] = None
    """The time to live for completed tasks. If set, tasks that have been completed for longer than this period will be deleted."""
    taskTemplate: Optional[TaskTemplate] = None
