"""
Async agent: connects to the FirmHook WebSocket, receives forwarded events,
and POSTs them to the developer's local server.
"""

import asyncio
import contextlib
import json
import signal
import sys
import time

import httpx
import websockets
from rich.console import Console

console = Console()


async def run_agent(
    *,
    server: str,
    api_key: str,
    org_slug: str,
    endpoint_id: str,
    forward_to: str,
    reconnect: bool = True,
) -> None:
    ws_url = f"{server}/ws/dev/{org_slug}/{endpoint_id}?api_key={api_key}"

    while True:
        try:
            console.print(f"[cyan]Connecting to {server}...[/cyan]")
            async with websockets.connect(ws_url, ping_interval=30, ping_timeout=10) as ws:
                console.print(
                    f"[green]Connected.[/green] Forwarding events → [bold]{forward_to}[/bold]\n"
                    f"[dim]Endpoint ID: {endpoint_id}[/dim]\n"
                )
                async for raw in ws:
                    await _handle_event(raw, forward_to, ws)

        except websockets.exceptions.ConnectionClosedError as exc:
            code = exc.rcvd.code
            reason = exc.rcvd.reason or "unknown"
            if code == 4001:
                # Auth failure — do not retry
                console.print(f"[red]Authentication failed: {reason}[/red]")
                sys.exit(1)
            console.print(f"[yellow]Connection closed ({code}): {reason}[/yellow]")
        except OSError as exc:
            console.print(f"[yellow]Connection error: {exc}[/yellow]")
        except asyncio.CancelledError:
            break
        except Exception as exc:  # noqa: BLE001
            # Catches e.g. websockets handshake failures when server returns 5xx
            msg = str(exc)
            if any(str(code) in msg for code in range(500, 600)):
                console.print(f"[red]Server error: {exc}[/red]")
            else:
                console.print(f"[red]Unexpected error: {exc}[/red]")

        if not reconnect:
            break

        console.print("[dim]Reconnecting in 5 seconds...[/dim]")
        await asyncio.sleep(5)


async def _handle_event(raw: str, forward_to: str, ws) -> None:
    try:
        msg = json.loads(raw)
    except json.JSONDecodeError:
        console.print(f"[red]Received non-JSON message:[/red] {raw[:200]}")
        return

    event_id = msg.get("event_id", "?")
    payload = msg.get("payload", {})
    method = msg.get("method", "POST")
    path = msg.get("path") or ""
    attempt = msg.get("attempt_number", 1)

    # If the endpoint has forward_path enabled the worker sends the captured path
    # suffix; append it to the local base-URL so the local server sees the full path.
    effective_url = forward_to.rstrip("/") + "/" + path.lstrip("/") if path else forward_to

    console.print(
        f"[bold blue]→[/bold blue] Event [bold]{event_id}[/bold] "
        f"(attempt {attempt}) — forwarding to [bold]{effective_url}[/bold]"
    )

    ack: dict = {"event_id": event_id, "success": False, "status_code": None}
    start = time.monotonic()
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            if method.upper() in ("GET", "HEAD"):
                response = await client.request(method, effective_url)
            else:
                response = await client.request(method, effective_url, json=payload)
        duration_ms = int((time.monotonic() - start) * 1000)
        status_color = "green" if response.is_success else "red"
        console.print(f"  [bold {status_color}]{response.status_code}[/bold {status_color}] [dim]{duration_ms}ms[/dim]")
        ack["success"] = response.is_success
        ack["status_code"] = response.status_code
        ack["response_body"] = response.text[:4096]
    except (httpx.HTTPError, OSError) as exc:
        duration_ms = int((time.monotonic() - start) * 1000)
        console.print(f"  [red]Error:[/red] {exc} [dim]({duration_ms}ms)[/dim]")
        ack["error"] = str(exc)
    finally:
        await ws.send(json.dumps(ack))


def run_sync(
    *,
    server: str,
    api_key: str,
    org_slug: str,
    endpoint_id: str,
    forward_to: str,
    reconnect: bool = True,
) -> None:
    """Blocking entry point — runs the agent loop until interrupted."""
    loop = asyncio.new_event_loop()

    task = loop.create_task(
        run_agent(
            server=server,
            api_key=api_key,
            org_slug=org_slug,
            endpoint_id=endpoint_id,
            forward_to=forward_to,
            reconnect=reconnect,
        )
    )

    def _shutdown(signum, frame):  # noqa: ARG001
        task.cancel()

    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(OSError, ValueError):
            signal.signal(sig, _shutdown)

    try:
        loop.run_until_complete(task)
    except asyncio.CancelledError:
        pass
    finally:
        loop.close()
