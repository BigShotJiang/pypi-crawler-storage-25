"""
firmhook — FirmHook local dev agent CLI

Commands:
  firmhook config -------- Save API key and server URL
  firmhook start -------- Connect and forward webhook events to localhost
  firmhook stop -------- Stop a detached agent
  firmhook status -------- Show whether the agent is running
  firmhook logs -------- Print recent agent logs
"""

import os
import signal
import subprocess
import sys
import time

import typer
from rich.console import Console

from . import __version__
from . import config as cfg

app = typer.Typer(
    name="firmhook",
    help="FirmHook local dev agent — forward live webhook events to localhost",
    add_completion=False,
)
console = Console()


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------


@app.command()
def config(
    api_key: str | None = typer.Option(None, "--api-key", help="Your FirmHook API key"),
    show: bool = typer.Option(False, "--show", help="Print the currently saved API key"),
):
    """Save your API key to ~/.firmhook/config.json."""
    if show:
        stored = cfg.get_api_key()
        if stored:
            console.print(f"[bold]api_key[/bold] = {stored}")
        else:
            console.print("[yellow]No API key saved. Run:[/yellow]  firmhook config --api-key <key>")
        return

    cfg.set_values(api_key=api_key)
    console.print(f"[green]Config saved to[/green] {cfg.config_path()}")
    if api_key:
        console.print(f"  api_key = {api_key[:8]}...")


# ---------------------------------------------------------------------------
# start
# ---------------------------------------------------------------------------


@app.command()
def start(
    org_slug: str = typer.Argument(..., help="Organisation slug"),
    endpoint_id: str = typer.Argument(..., help="Endpoint UUID to listen on"),
    forward_to: str | None = typer.Option(
        None,
        "--forward-to",
        "-f",
        help="Local URL to forward events to (defaults to dev_forward_url set on the endpoint)",
    ),
    api_key: str | None = typer.Option(None, "--api-key", help="API key (overrides saved config)"),
    detach: bool = typer.Option(False, "--detach", "-d", help="Run in background"),
):
    """Connect to FirmHook and forward events to a local URL."""
    resolved_key = api_key or cfg.get_api_key()
    resolved_server = cfg.get_server()

    if not resolved_key:
        console.print("[red]No API key found. Run:[/red]  firmhook config --api-key <key>")
        raise typer.Exit(1)

    if not forward_to:
        forward_to = _fetch_dev_forward_url(org_slug, endpoint_id, resolved_key)

    if detach:
        _start_detached(
            org_slug=org_slug,
            endpoint_id=endpoint_id,
            forward_to=forward_to,
            api_key=resolved_key,
        )
        return

    # Foreground — import here so startup is fast for --help
    from .agent import run_sync

    console.print(f"[bold]firmhook[/bold] {__version__}  |  Press Ctrl+C to stop\n")
    run_sync(
        server=resolved_server,
        api_key=resolved_key,
        org_slug=org_slug,
        endpoint_id=endpoint_id,
        forward_to=forward_to,
    )


def _fetch_dev_forward_url(org_slug: str, endpoint_id: str, api_key: str) -> str:
    """Fetch dev_forward_url from the endpoint via the API."""
    import httpx

    base = cfg.get_http_base_url()
    url = f"{base}/dev/{org_slug}/endpoints/{endpoint_id}"
    try:
        response = httpx.get(url, params={"api_key": api_key}, timeout=10)
        response.raise_for_status()
        dev_forward_url = response.json().get("dev_forward_url")
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            console.print(
                f"[red]Server error ({exc.response.status_code}): the FirmHook server encountered an error. "
                f"Try again later.[/red]"
            )
        else:
            try:
                detail = exc.response.json().get("detail")
            except Exception:  # noqa: BLE001
                detail = None
            console.print(f"[red]{detail or exc}[/red]")
        raise typer.Exit(1)  # noqa: B904
    except httpx.HTTPError as exc:
        console.print(f"[red]Failed to fetch endpoint details: {exc}[/red]")
        raise typer.Exit(1)  # noqa: B904

    if not dev_forward_url:
        console.print(
            "[red]No --forward-to URL provided and the endpoint has no dev_forward_url set.[/red]\n"
            "Either pass [bold]--forward-to <url>[/bold] or update the endpoint with a dev_forward_url."
        )
        raise typer.Exit(1)

    return dev_forward_url


def _start_detached(*, org_slug, endpoint_id, forward_to, api_key):
    if cfg.PID_FILE.exists():
        pid = _read_pid()
        if pid and _is_running(pid):
            console.print(f"[yellow]Agent already running (PID {pid}). Run `firmhook stop` first.[/yellow]")
            raise typer.Exit(1)

    cfg.LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    log_fh = open(cfg.LOG_FILE, "a")  # noqa: SIM115

    cmd = [
        sys.executable,
        "-m",
        "firmhook_cli.main",
        "start",
        org_slug,
        endpoint_id,
        "--forward-to",
        forward_to,
        "--api-key",
        api_key,
    ]

    proc = subprocess.Popen(  # noqa: S603
        cmd,
        stdout=log_fh,
        stderr=log_fh,
        start_new_session=True,  # detach from the terminal on all platforms
    )

    cfg.PID_FILE.write_text(str(proc.pid))
    console.print(f"[green]Agent started in background (PID {proc.pid})[/green]\n[dim]Logs → {cfg.LOG_FILE}[/dim]")


# ---------------------------------------------------------------------------
# stop
# ---------------------------------------------------------------------------


@app.command()
def stop():
    """Stop the background agent."""
    pid = _read_pid()
    if not pid:
        console.print("[yellow]No agent PID file found — agent may not be running.[/yellow]")
        raise typer.Exit(1)

    if not _is_running(pid):
        console.print(f"[yellow]Agent (PID {pid}) is not running.[/yellow]")
        cfg.PID_FILE.unlink(missing_ok=True)
        raise typer.Exit(1)

    try:
        os.kill(pid, signal.SIGTERM)
        cfg.PID_FILE.unlink(missing_ok=True)
        console.print(f"[green]Agent (PID {pid}) stopped.[/green]")
    except ProcessLookupError:
        console.print(f"[yellow]Process {pid} not found.[/yellow]")
        cfg.PID_FILE.unlink(missing_ok=True)
    except PermissionError as exc:
        console.print(f"[red]Permission denied to stop PID {pid}.[/red]")
        raise typer.Exit(1) from exc


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@app.command()
def status():
    """Show whether the background agent is running."""
    pid = _read_pid()
    if not pid:
        console.print("[yellow]●[/yellow] Agent not running")
        return

    if _is_running(pid):
        console.print(f"[green]●[/green] Agent running  [dim](PID {pid})[/dim]")
        console.print(f"  Config  → {cfg.config_path()}")
        console.print(f"  Logs    → {cfg.LOG_FILE}")
    else:
        console.print(f"[yellow]●[/yellow] Agent not running  [dim](stale PID file: {pid})[/dim]")
        cfg.PID_FILE.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


@app.command()
def logs(
    tail: int = typer.Option(50, "--tail", "-t", "-n", help="Number of recent lines to show"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output in real time (like tail -f)"),
):
    """Print recent agent log output."""
    if not cfg.LOG_FILE.exists():
        console.print("[yellow]No log file found. Has the agent been started with --detach?[/yellow]")
        raise typer.Exit(1)

    lines = cfg.LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    for line in lines[-tail:]:
        console.print(line)

    if follow:
        console.print("[dim]--- following (Ctrl+C to stop) ---[/dim]")
        try:
            with cfg.LOG_FILE.open(encoding="utf-8", errors="replace") as fh:
                fh.seek(0, 2)  # seek to end
                while True:
                    line = fh.readline()
                    if line:
                        console.print(line, end="")
                    else:
                        time.sleep(0.2)
        except KeyboardInterrupt:
            pass


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command()
def version():
    """Print the firmhook version."""
    console.print(f"firmhook {__version__}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_pid() -> int | None:
    if not cfg.PID_FILE.exists():
        return None
    try:
        return int(cfg.PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def _is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, PermissionError):
        return False
    return True


if __name__ == "__main__":
    app()
