"""Manages ~/.firmhook/config.json and the agent PID/log files."""

import json
from pathlib import Path

_CONFIG_DIR = Path.home() / ".firmhook"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
PID_FILE = _CONFIG_DIR / "agent.pid"
LOG_FILE = _CONFIG_DIR / "agent.log"


def _load() -> dict:
    if _CONFIG_FILE.exists():
        return json.loads(_CONFIG_FILE.read_text())
    return {}


def _save(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))


def get(key: str, fallback=None):
    return _load().get(key, fallback)


def set_values(**kwargs) -> None:
    data = _load()
    data.update({k: v for k, v in kwargs.items() if v is not None})
    _save(data)


def get_api_key() -> str | None:
    return get("api_key")


def get_server() -> str:
    return get("server", "wss://api.firmhook.com")


def get_http_base_url() -> str:
    """Return the HTTP(S) base URL derived from the configured WebSocket server URL."""
    ws = get_server()
    if ws.startswith("wss://"):
        return "https://" + ws[len("wss://") :]
    if ws.startswith("ws://"):
        return "http://" + ws[len("ws://") :]
    return ws


def config_path() -> Path:
    return _CONFIG_FILE
