"""
Translate SDK exceptions into actionable, model-readable error messages.

The Agimus SDK already classifies HTTP failures into typed exceptions
(``AuthenticationError``, ``NotFoundError``, ``RateLimitError`` …). The MCP
server's job here is just to produce a short, instructive string the LLM can
read and recover from — usually by suggesting a discovery tool to call next.
"""

from __future__ import annotations

from agimus import (
    AccessDeniedError,
    AgimusError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def to_error_message(exc: Exception) -> str:
    """Render any exception as a single-line, model-readable error string."""
    if isinstance(exc, AuthenticationError):
        return (
            "Error: Invalid or missing Agimus API key. "
            "Set AGIMUS_API_KEY to a key starting with 'agm_'."
        )
    if isinstance(exc, AccessDeniedError):
        return (
            "Error: Permission denied. The current API key does not have "
            "access to this resource."
        )
    if isinstance(exc, NotFoundError):
        return (
            f"Error: Not found — {exc}. "
            f"Use a discovery tool (agimus_list_entities, agimus_list_links, "
            f"or agimus_list_datasets) to find valid names."
        )
    if isinstance(exc, ValidationError):
        return f"Error: Invalid request — {exc}"
    if isinstance(exc, RateLimitError):
        retry = getattr(exc, "retry_after", None)
        suffix = f" Retry after {retry}s." if retry else ""
        return f"Error: Rate limit exceeded.{suffix}"
    if isinstance(exc, ServerError):
        return f"Error: Agimus server error — {exc}"
    if isinstance(exc, AgimusError):
        return f"Error: {exc}"
    return f"Error: Unexpected failure ({type(exc).__name__}): {exc}"
