"""
Markdown rendering for Agimus responses.

The model can ingest JSON, but compact markdown tables save tokens and are
easier to skim. Each ``format_*`` function takes plain Python data (dicts
or SDK dataclasses already converted to dicts) and returns a markdown
string ready to send back as tool output.

These helpers are pure functions: data in, string out, no side effects,
no SDK dependency.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

_DOCS_DIR = Path(__file__).parent / "docs"

# Dev-mode fallback: when running out of the monorepo source tree (no built
# wheel), the bundled docs/ folder is empty. The SDK README lives next door,
# so we look it up there as a second-chance lookup. In an installed wheel
# the file is shipped via hatchling force-include and the fallback is never
# hit.
_DEV_SDK_README = (
    Path(__file__).resolve().parents[3] / "python" / "README.md"
)
_DEV_FALLBACKS = {"sdk_reference.md": _DEV_SDK_README}


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------


def load_doc(filename: str) -> str:
    """Load a bundled doc, falling back to its monorepo source in dev."""
    path = _DOCS_DIR / filename
    if path.exists():
        return path.read_text(encoding="utf-8")
    fallback = _DEV_FALLBACKS.get(filename)
    if fallback is not None and fallback.exists():
        return fallback.read_text(encoding="utf-8")
    return f"Documentation file '{filename}' not found."


def _md_cell(value: Any) -> str:
    """Format a single value for inclusion in a markdown table cell."""
    if value is None:
        return ""
    cell = str(value)
    if len(cell) > 120:
        cell = cell[:117] + "..."
    # Pipes break table layout; escape them. Newlines collapse to spaces.
    return cell.replace("|", "\\|").replace("\n", " ")


def _format_size(size_bytes: int | None) -> str:
    if size_bytes is None:
        return "?"
    mb = size_bytes / 1_048_576
    if mb >= 1024:
        return f"{mb / 1024:.1f} GB"
    return f"{mb:.1f} MB"


def _format_property_type(prop: dict) -> str:
    base = prop.get("baseType") or "unknown"
    return f"{base}[]" if prop.get("isArray") else base


def _format_property_flags(prop: dict) -> str:
    flags = []
    if prop.get("isPrimaryKey"):
        flags.append("PK")
    if not prop.get("nullable", True):
        flags.append("required")
    if not prop.get("isEditable", True):
        flags.append("read-only")
    return ", ".join(flags)


def _collect_keys(records: Iterable[dict]) -> list[str]:
    """Stable union of all keys across records (preserves first-seen order)."""
    seen: set[str] = set()
    keys: list[str] = []
    for record in records:
        for k in record:
            if k not in seen:
                seen.add(k)
                keys.append(k)
    return keys


def _records_table(records: list[dict]) -> str:
    """Render a list of homogeneous-ish dicts as a markdown table."""
    keys = _collect_keys(records)
    lines = [
        "| " + " | ".join(keys) + " |",
        "| " + " | ".join("---" for _ in keys) + " |",
    ]
    for record in records:
        lines.append(
            "| " + " | ".join(_md_cell(record.get(k)) for k in keys) + " |"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


def format_entity_list(entities: list[dict]) -> str:
    """Render the list-entities response (compact summaries with counts)."""
    if not entities:
        return (
            "No entities found. The ontology may be empty or this API key "
            "may lack access to any entities."
        )

    lines = [
        f"Found {len(entities)} "
        f"entit{'ies' if len(entities) != 1 else 'y'}:",
        "",
        "| API Name | Display Name | PK | Props | Links | Description |",
        "|----------|--------------|----|-------|-------|-------------|",
    ]
    for e in entities:
        pk = e.get("primaryKey")
        pk_cell = f"`{pk}`" if pk else "—"
        lines.append(
            f"| `{_md_cell(e.get('apiName'))}` "
            f"| {_md_cell(e.get('displayName'))} "
            f"| {pk_cell} "
            f"| {e.get('propertyCount', 0)} "
            f"| {e.get('linkCount', 0)} "
            f"| {_md_cell(e.get('description'))} |"
        )
    return "\n".join(lines)


def format_entity_schema(schema: dict) -> str:
    """Render a single entity's full schema (properties + rich links)."""
    api_name = schema.get("apiName", "?")
    display = schema.get("displayName", api_name)
    plural = schema.get("pluralName", display)
    desc = schema.get("description") or ""
    pk = schema.get("primaryKey", "—")
    properties = schema.get("properties", [])
    links = schema.get("links", [])

    lines = [
        f"# {display}",
        "",
        f"- **API name**: `{api_name}`",
        f"- **Plural name**: {plural}",
    ]
    if desc:
        lines.append(f"- **Description**: {desc}")
    lines.append(f"- **Primary key**: `{pk}`")
    lines.append(f"- **Properties**: {len(properties)}")
    lines.append(f"- **Links**: {len(links)}")

    lines += [
        "",
        "## Properties",
        "",
        "| API Name | Display Name | Type | Flags | Description |",
        "|----------|--------------|------|-------|-------------|",
    ]
    for p in properties:
        lines.append(
            f"| `{_md_cell(p.get('apiName'))}` "
            f"| {_md_cell(p.get('displayName'))} "
            f"| {_md_cell(_format_property_type(p))} "
            f"| {_md_cell(_format_property_flags(p))} "
            f"| {_md_cell(p.get('description'))} |"
        )

    if links:
        lines += [
            "",
            "## Links",
            "",
        ]
        for link in links:
            lines.append(_format_link_block(link, include_source=False))
            lines.append("")

    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------------------
# Links (global list + per-link details)
# ---------------------------------------------------------------------------


def format_link_list(links: list[dict]) -> str:
    """Render the global list-links response (compact rows, both directions)."""
    if not links:
        return "No links found in the ontology."

    lines = [
        f"Found {len(links)} link direction"
        f"{'s' if len(links) != 1 else ''}:",
        "",
        "| Source | API Name | → | Target | Cardinality | Direction |",
        "|--------|----------|---|--------|-------------|-----------|",
    ]
    for link in links:
        lines.append(
            f"| `{_md_cell(link.get('sourceEntity'))}` "
            f"| `{_md_cell(link.get('apiName'))}` "
            f"| → "
            f"| `{_md_cell(link.get('targetEntity'))}` "
            f"| {_md_cell(link.get('cardinality'))} "
            f"| {_md_cell(link.get('direction'))} |"
        )
    return "\n".join(lines)


def format_link_details(matches: list[dict]) -> str:
    """Render full details for one or more matching links."""
    if not matches:
        return "No matching links found."

    header = (
        f"Found {len(matches)} matching link direction"
        f"{'s' if len(matches) != 1 else ''}:"
    )
    parts = [header, ""]
    for link in matches:
        parts.append(_format_link_block(link, include_source=True))
        parts.append("")
    return "\n".join(parts).rstrip() + "\n"


def _format_link_block(link: dict, *, include_source: bool) -> str:
    """Render one link as a markdown details block.

    ``include_source`` adds a Source line — useful when the link is shown
    out of an entity-schema context (e.g., from the get_link tool); it would
    be redundant when rendered under an entity's own schema.
    """
    api_name = link.get("apiName", "?")
    display = link.get("displayName") or api_name
    plural = link.get("pluralDisplayName")
    desc = link.get("description")
    target = link.get("targetEntity", "?")
    cardinality = link.get("cardinality", "?")
    direction = link.get("direction", "?")
    impl = link.get("implementationType", "?")
    fk_entity = link.get("foreignKeyEntity")
    fk_property = link.get("foreignKeyProperty")
    on_source_delete = link.get("onSourceDelete", "?")
    on_target_delete = link.get("onTargetDelete", "?")

    lines = [f"### `{api_name}` — {display} ({direction})"]
    if include_source:
        lines.append(f"- **Source entity**: `{link.get('sourceEntity', '?')}`")
    lines.append(f"- **Target entity**: `{target}`")
    lines.append(f"- **Cardinality**: {cardinality}")
    if plural and plural != display:
        lines.append(f"- **Plural display name**: {plural}")
    if desc:
        lines.append(f"- **Description**: {desc}")
    lines.append(f"- **Implementation**: {impl}")
    if impl == "foreign_key" and fk_entity:
        fk_part = f"`{fk_entity}`"
        if fk_property:
            fk_part += f".`{fk_property}`"
        lines.append(f"- **Foreign key**: {fk_part}")
    lines.append(
        f"- **On delete**: source={on_source_delete}, target={on_target_delete}"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Datasets
# ---------------------------------------------------------------------------


def format_dataset_list(datasets: list[dict]) -> str:
    """Render the list-datasets response."""
    if not datasets:
        return "No datasets found."

    lines = [
        f"Found {len(datasets)} dataset"
        + ("s:" if len(datasets) != 1 else ":"),
        "",
        "| Name | Source | Rows | Size | Description |",
        "|------|--------|------|------|-------------|",
    ]
    for ds in datasets:
        rows = ds.get("totalRows")
        rows_str = f"{rows:,}" if rows is not None else "?"
        lines.append(
            f"| `{_md_cell(ds.get('name'))}` "
            f"| {_md_cell(ds.get('sourceType'))} "
            f"| {rows_str} "
            f"| {_format_size(ds.get('totalSizeBytes'))} "
            f"| {_md_cell(ds.get('description'))} |"
        )
    return "\n".join(lines)


def format_dataset_schema(ds: dict) -> str:
    """Render full dataset metadata + an SDK usage snippet."""
    name = ds.get("name", "?")
    rows = ds.get("totalRows")
    rows_str = f"{rows:,}" if rows is not None else "?"
    columns = ds.get("columns") or []

    lines = [
        f"# Dataset: {name}",
        "",
        f"- **ID**: `{ds.get('id', '?')}`",
        f"- **Source type**: {ds.get('sourceType', '?')}",
        f"- **Rows**: {rows_str}",
        f"- **Size**: {_format_size(ds.get('totalSizeBytes'))}",
        f"- **Last synced**: {ds.get('lastSyncedAt') or '—'}",
    ]
    if ds.get("description"):
        lines.append(f"- **Description**: {ds['description']}")

    lines += [
        "",
        "## Columns",
        "",
        "| Name | Type | Nullable |",
        "|------|------|----------|",
    ]
    for col in columns:
        lines.append(
            f"| `{_md_cell(col.get('name'))}` "
            f"| {_md_cell(col.get('type'))} "
            f"| {'yes' if col.get('nullable', True) else 'no'} |"
        )

    sample_cols = [c.get("name") for c in columns[:3] if c.get("name")]
    sample = repr(sample_cols) if sample_cols else "[...]"
    lines += [
        "",
        "## SDK usage (run in the user's environment)",
        "",
        "```python",
        "from agimus import AgimusClient",
        "",
        "client = AgimusClient(api_key=\"agm_...\")",
        f"dataset = client.datasets.get(\"{name}\")",
        "",
        "# Load as pandas DataFrame",
        "df = dataset.to_pandas()",
        "",
        "# Read only the columns you need",
        f"df = dataset.to_pandas(columns={sample})",
        "",
        "# Stream large datasets in batches",
        "for batch in dataset.iter_batches():",
        "    chunk = batch.to_pandas()",
        "```",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Read responses (objects, related, distinct, aggregate, count)
# ---------------------------------------------------------------------------


def format_records(
    entity: str,
    records: list[dict],
    *,
    cursor: str | None = None,
    has_more: bool = False,
) -> str:
    """Render an object query result."""
    if not records:
        return f"No records found for entity `{entity}`."

    header = (
        f"## `{entity}` — {len(records)} record"
        f"{'s' if len(records) != 1 else ''}"
    )
    if has_more:
        header += " (more available — pass `cursor` to continue)"
    lines = [header, "", _records_table(records)]
    if has_more and cursor:
        lines += ["", f"**Next cursor**: `{cursor}`"]
    return "\n".join(lines)


def format_object(entity: str, obj: dict) -> str:
    """Render a single object as a key/value list."""
    if not obj:
        return f"No object returned for entity `{entity}`."
    lines = [f"## `{entity}` — single object", ""]
    for k, v in obj.items():
        lines.append(f"- **{k}**: {_md_cell(v)}")
    return "\n".join(lines)


def format_related_objects(
    source_entity: str,
    pk: str,
    link: str,
    records: list[dict],
    *,
    cursor: str | None = None,
    has_more: bool = False,
) -> str:
    """Render get_related_objects response."""
    header = (
        f"## `{source_entity}/{pk}` → `{link}` — "
        f"{len(records)} related record"
        f"{'s' if len(records) != 1 else ''}"
    )
    if not records:
        return header + "\n\nNo related objects."

    if has_more:
        header += " (more available — pass `cursor` to continue)"
    lines = [header, "", _records_table(records)]
    if has_more and cursor:
        lines += ["", f"**Next cursor**: `{cursor}`"]
    return "\n".join(lines)


def format_count(entity: str, count: int) -> str:
    return f"`{entity}`: **{count:,}** matching object{'s' if count != 1 else ''}"


def format_distinct_values(field: str, values: list[Any]) -> str:
    """
    Render distinct values. Two shapes accepted:
      - bare list:    ["active", "inactive"]
      - with counts:  [{"value": "active", "count": 1245}, ...]
    """
    if not values:
        return f"No distinct values found for field `{field}`."

    has_counts = bool(values) and isinstance(values[0], dict) and "value" in values[0]

    lines = [
        f"## Distinct values for `{field}` "
        f"({len(values)} found, sorted by frequency)",
        "",
    ]
    if has_counts:
        lines += [
            "| Value | Count |",
            "|-------|-------|",
        ]
        for entry in values:
            lines.append(
                f"| {_md_cell(entry.get('value'))} | {entry.get('count', 0):,} |"
            )
    else:
        lines += [
            "| Value |",
            "|-------|",
        ]
        for value in values:
            lines.append(f"| {_md_cell(value)} |")
    return "\n".join(lines)


def format_aggregation(entity: str, result: dict) -> str:
    """Render aggregation response."""
    rows = result.get("data") or []
    total_groups = result.get("totalGroups", len(rows))
    if not rows:
        return f"No aggregation rows for entity `{entity}`."
    lines = [
        f"## `{entity}` — {len(rows)} group{'s' if len(rows) != 1 else ''} "
        f"(of {total_groups:,} total)",
        "",
        _records_table(rows),
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Whoami
# ---------------------------------------------------------------------------


def format_whoami(info: dict) -> str:
    lines = [
        "## API key info",
        "",
        f"- **Tenant**: {info.get('tenantName', '?')}",
        f"- **Scope**: {info.get('scope', '?')}",
    ]
    rate_limit = info.get("rateLimitPerMinute")
    if rate_limit is not None:
        lines.append(f"- **Rate limit**: {rate_limit:,} requests/minute")
    request_id = info.get("requestId")
    if request_id:
        lines.append(f"- **Request ID**: `{request_id}`")
    return "\n".join(lines)
