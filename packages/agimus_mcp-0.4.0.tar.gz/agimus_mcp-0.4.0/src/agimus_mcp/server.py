"""
Agimus MCP server factory.

Wires up FastMCP with a lifespan-managed Agimus SDK client. The SDK is
opened once on startup, shared across every tool/resource call, and closed
cleanly on shutdown — so we never pay TCP-handshake or auth-setup cost
per request.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator, TypedDict

from agimus import AsyncAgimusClient
from mcp.server.fastmcp import FastMCP

from .resources import register_resources
from .tools import register_tools

INSTRUCTIONS = (
    "You are connected to the Agimus data platform.\n\n"
    "DISCOVERY (call before writing any code that names entities, properties, or links):\n"
    "  - agimus_list_entities — every entity you can see, with property/link counts and PK\n"
    "  - agimus_list_links — every link in the ontology (both directions per link)\n"
    "  - agimus_get_entity_schema — full per-entity schema with rich link details\n"
    "  - agimus_get_link — full details for a single link by api_name\n"
    "  - agimus_list_datasets / agimus_get_dataset_schema — raw datasets backing the ontology\n\n"
    "READ (use these to answer questions about live data):\n"
    "  - agimus_query_objects — filter/sort/expand/paginate\n"
    "  - agimus_get_object — single object by primary key\n"
    "  - agimus_get_related_objects — traverse a link from one object\n"
    "  - agimus_count_objects — fast COUNT(*) with filter\n"
    "  - agimus_distinct_values — distinct values, optionally with frequency counts\n"
    "  - agimus_aggregate — group_by + metrics (sum/avg/count/min/max…)\n\n"
    "When the user wants to download dataset rows or write data, write Python "
    "code that uses the synchronous `agimus.AgimusClient` in their environment — "
    "this MCP server is read-only and never streams dataset bytes itself."
)


class ServerContext(TypedDict):
    """Lifespan-scoped state injected into every tool/resource call."""

    agimus: AsyncAgimusClient


def create_server(
    api_key: str,
    base_url: str = "https://api.agimus.ai",
    timeout: float = 30.0,
) -> FastMCP:
    """Build a fully wired MCP server bound to one Agimus API key."""

    @asynccontextmanager
    async def lifespan(_server: FastMCP) -> AsyncIterator[ServerContext]:
        async with AsyncAgimusClient(
            api_key=api_key, base_url=base_url, timeout=timeout
        ) as client:
            yield {"agimus": client}

    mcp = FastMCP(
        "agimus",
        instructions=INSTRUCTIONS,
        lifespan=lifespan,
    )
    register_tools(mcp)
    register_resources(mcp)
    return mcp
