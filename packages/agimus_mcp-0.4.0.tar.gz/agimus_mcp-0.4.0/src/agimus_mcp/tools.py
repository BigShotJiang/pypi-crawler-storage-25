"""
Agimus MCP tools.

Each tool is a thin shim: the FastMCP framework validates inputs against
the function signature (using Annotated + Pydantic Field defaults), the
function calls the Agimus SDK, and the result is rendered as markdown
(or JSON if the model asks).

All HTTP, auth, retries, error classification, and pagination live in the
SDK — this module deliberately contains no HTTP plumbing.

There are 13 tools total: 12 base + the optional whoami.

  Discovery: list_entities, get_entity_schema, list_links, get_link,
             list_datasets, get_dataset_schema, whoami
  Read:      query_objects, get_object, get_related_objects,
             count_objects, distinct_values, aggregate
"""

from __future__ import annotations

import json
from enum import Enum
from typing import Annotated, Any, Optional

from agimus import AsyncAgimusClient
from mcp.server.fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from .errors import to_error_message
from .formatters import (
    format_aggregation,
    format_count,
    format_dataset_list,
    format_dataset_schema,
    format_distinct_values,
    format_entity_list,
    format_entity_schema,
    format_link_details,
    format_link_list,
    format_object,
    format_records,
    format_related_objects,
    format_whoami,
)


# ---------------------------------------------------------------------------
# Shared
# ---------------------------------------------------------------------------


class ResponseFormat(str, Enum):
    MARKDOWN = "markdown"
    JSON = "json"


def _client(ctx: Context) -> AsyncAgimusClient:
    """Pull the SDK client out of lifespan-scoped state."""
    return ctx.request_context.lifespan_context["agimus"]


def _read_only(title: str) -> ToolAnnotations:
    """Annotations every read-only tool shares."""
    return ToolAnnotations(
        title=title,
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    )


def _render(payload: Any, fmt: ResponseFormat, markdown_fn) -> str:
    """Render either the JSON payload or its markdown rendering."""
    if fmt is ResponseFormat.JSON:
        return json.dumps(payload, indent=2, default=str)
    return markdown_fn(payload)


# Reusable parameter aliases (so the same description shows up everywhere).
_RESPONSE_FORMAT_DESC = (
    "Output format: 'markdown' (compact, model-friendly tables) or 'json' "
    "(raw structured data)."
)
_FILTER_DESC = (
    'Filter clause. Either a single condition {"field": str, "op": str, '
    '"value": Any} or a logical combination {"and": [...]} / {"or": [...]} / '
    '{"not": <clause>}. Operators: eq, ne, gt, gte, lt, lte, between, like, '
    "ilike, starts_with, ends_with, in, nin, is_null, is_not_null, is_empty, "
    "is_not_empty, contains, overlaps."
)


# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


def register_tools(mcp: FastMCP) -> None:  # noqa: PLR0915 (one big registration block is fine)
    """Register all Agimus tools on the given MCP instance."""

    # === Discovery ========================================================

    @mcp.tool(
        name="agimus_list_entities",
        annotations=_read_only("List Agimus Entities"),
    )
    async def agimus_list_entities(
        ctx: Context,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """List every entity accessible to the current API key.

        Each entry includes the api_name, display name, description, the
        primary-key property name, and counts of accessible properties and
        links. Call this before any code that names an entity.
        """
        try:
            entities = await _client(ctx).list_entities()
            return _render(entities, response_format, format_entity_list)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_get_entity_schema",
        annotations=_read_only("Get Entity Schema"),
    )
    async def agimus_get_entity_schema(
        ctx: Context,
        entity: Annotated[
            str,
            Field(
                description=(
                    "Entity API name (e.g. 'Product'). "
                    "Use agimus_list_entities to discover."
                ),
                min_length=1,
                max_length=200,
            ),
        ],
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Full schema for a single entity.

        Returns properties (api name, base type, array flag, nullable, PK,
        editability) and links (with description, plural display name,
        cardinality, direction, FK entity/property, and on-delete behavior).
        Call this before writing any code that names properties or links.
        """
        try:
            schema = await _client(ctx).get_entity_schema(entity)
            return _render(schema, response_format, format_entity_schema)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_list_links",
        annotations=_read_only("List Ontology Links"),
    )
    async def agimus_list_links(
        ctx: Context,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """List every link in the ontology, both directions per link.

        Compact summaries: source entity, link api_name, target entity,
        cardinality, direction. Use this to understand the relationship
        graph at a glance, then drill into specific links via
        ``agimus_get_link`` or via ``agimus_get_entity_schema``.
        """
        try:
            links = await _client(ctx).list_links()
            return _render(links, response_format, format_link_list)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_get_link",
        annotations=_read_only("Get Link Details"),
    )
    async def agimus_get_link(
        ctx: Context,
        link: Annotated[
            str,
            Field(
                description=(
                    "Link api_name (forward or reverse). May match more than "
                    "one direction; all matches are returned. Use "
                    "agimus_list_links to discover."
                ),
                min_length=1,
                max_length=200,
            ),
        ],
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Look up link(s) by api_name across the ontology.

        Returns a list because a name can match more than one direction
        (forward + reverse of one link, or distinct links sharing an
        api_name). Each entry has full details: description, FK property,
        on-delete behavior, etc.
        """
        try:
            matches = await _client(ctx).get_link_schema(link)
            return _render(matches, response_format, format_link_details)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    # === Object reads =====================================================

    @mcp.tool(
        name="agimus_query_objects",
        annotations=_read_only("Query Objects"),
    )
    async def agimus_query_objects(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        filter: Annotated[
            Optional[dict[str, Any]], Field(description=_FILTER_DESC)
        ] = None,
        sort: Annotated[
            Optional[list[str]],
            Field(
                description=(
                    "Sort fields; prefix with '-' for DESC. "
                    "e.g. ['-createdAt', 'name']."
                )
            ),
        ] = None,
        fields: Annotated[
            Optional[list[str]],
            Field(
                description=(
                    "Property api_names to return. Omit to return everything "
                    "accessible."
                )
            ),
        ] = None,
        expand: Annotated[
            Optional[list[str]],
            Field(
                description=(
                    "Link api_names to expand inline (e.g. "
                    "['orders', 'orders.items']). Max nesting depth: 3."
                )
            ),
        ] = None,
        limit: Annotated[
            int,
            Field(
                ge=1,
                le=100,
                description=(
                    "Max records to return on this call (1–100, server-enforced). "
                    "Use the returned `cursor` to fetch more."
                ),
            ),
        ] = 50,
        cursor: Annotated[
            Optional[str],
            Field(
                description=(
                    "Opaque pagination cursor from a previous call. "
                    "Omit for first page."
                )
            ),
        ] = None,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Query objects with filter, sort, projection, expand, and pagination.

        The filter language and operators are documented in the parameter
        description and in ``agimus://docs/sdk-reference``. Set ``cursor``
        to the value returned in a previous call's response to fetch the
        next page.
        """
        try:
            qb = _client(ctx).objects(entity).page_size(limit)
            if filter is not None:
                qb = qb.with_filter(filter)
            if sort:
                qb = qb.sort(*sort)
            if fields:
                qb = qb.fields(*fields)
            if expand:
                qb = qb.expand(*expand)

            response = await qb.execute_page(cursor=cursor)
            records = response.get("data", [])
            next_cursor = response.get("cursor") or None
            has_more = bool(response.get("hasMore", False))

            if response_format is ResponseFormat.JSON:
                return json.dumps(
                    {"data": records, "cursor": next_cursor, "hasMore": has_more},
                    indent=2,
                    default=str,
                )
            return format_records(
                entity, records, cursor=next_cursor, has_more=has_more,
            )
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_get_object",
        annotations=_read_only("Get Object by Primary Key"),
    )
    async def agimus_get_object(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        pk: Annotated[
            str, Field(min_length=1, max_length=500, description="Primary key value.")
        ],
        fields: Annotated[
            Optional[list[str]],
            Field(description="Property api_names to return. Omit for all."),
        ] = None,
        expand: Annotated[
            Optional[list[str]],
            Field(description="Link api_names to expand inline."),
        ] = None,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Fetch a single object by primary key.

        Optionally project a subset of fields and/or expand related objects
        inline.
        """
        try:
            obj = await _client(ctx).objects(entity).get(
                pk, fields=fields, expand=expand
            )
            if response_format is ResponseFormat.JSON:
                return json.dumps(obj, indent=2, default=str)
            return format_object(entity, obj)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_get_related_objects",
        annotations=_read_only("Traverse Link"),
    )
    async def agimus_get_related_objects(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        pk: Annotated[str, Field(min_length=1, max_length=500)],
        link: Annotated[
            str,
            Field(
                min_length=1,
                max_length=200,
                description="Link api_name as it appears on the source entity.",
            ),
        ],
        page_size: Annotated[int, Field(ge=1, le=100)] = 50,
        cursor: Annotated[
            Optional[str],
            Field(description="Opaque pagination cursor from a previous call."),
        ] = None,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Traverse a link from a single source object to its related objects.

        Cursor-paginated (keyset on the target's primary key) — set ``cursor``
        to the value returned by a previous call to fetch the next page.
        """
        try:
            response = await _client(ctx).objects(entity).links(
                pk, link, page_size=page_size, cursor=cursor,
            )
            records = response.get("data", [])
            next_cursor = response.get("cursor") or None
            has_more = bool(response.get("hasMore", False))
            if response_format is ResponseFormat.JSON:
                return json.dumps(
                    {"data": records, "cursor": next_cursor, "hasMore": has_more},
                    indent=2,
                    default=str,
                )
            return format_related_objects(
                entity, pk, link, records, cursor=next_cursor, has_more=has_more,
            )
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_count_objects",
        annotations=_read_only("Count Objects"),
    )
    async def agimus_count_objects(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        filter: Annotated[
            Optional[dict[str, Any]],
            Field(description=f"{_FILTER_DESC} Omit for total count."),
        ] = None,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Count objects matching an optional filter.

        Cheap — does not pull rows. Without a filter, returns the total
        object count for the entity.
        """
        try:
            qb = _client(ctx).objects(entity)
            if filter is not None:
                qb = qb.with_filter(filter)
            count = await qb.count()
            if response_format is ResponseFormat.JSON:
                return json.dumps({"entity": entity, "count": count})
            return format_count(entity, count)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_distinct_values",
        annotations=_read_only("Distinct Values"),
    )
    async def agimus_distinct_values(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        field: Annotated[
            str,
            Field(
                min_length=1,
                max_length=200,
                description="Property api_name whose distinct values you want.",
            ),
        ],
        filter: Annotated[
            Optional[dict[str, Any]], Field(description=f"Optional. {_FILTER_DESC}"),
        ] = None,
        limit: Annotated[int, Field(ge=1, le=10_000)] = 1000,
        with_counts: Annotated[
            bool,
            Field(
                description=(
                    "When True, return [{value, count}] sorted by frequency. "
                    "When False (default), return a bare list of values."
                ),
            ),
        ] = False,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Distinct values for a field, sorted by frequency (most common first).

        Set ``with_counts=true`` to also return the count of each value
        (returns ``[{value, count}, ...]``); otherwise returns a bare value
        list.
        """
        try:
            qb = _client(ctx).objects(entity)
            if filter is not None:
                qb = qb.with_filter(filter)
            values = await qb.distinct(field, limit=limit, with_counts=with_counts)
            if response_format is ResponseFormat.JSON:
                return json.dumps({"field": field, "values": values}, default=str)
            return format_distinct_values(field, values)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_aggregate",
        annotations=_read_only("Aggregate"),
    )
    async def agimus_aggregate(
        ctx: Context,
        entity: Annotated[str, Field(min_length=1, max_length=200)],
        metrics: Annotated[
            list[dict[str, Any]],
            Field(
                min_length=1,
                description=(
                    'List of metrics. Each: {"op": "count|count_distinct|sum|'
                    'avg|min|max|first|last", "field": "<api_name>" '
                    '(omit for count), "alias": "<output name>"}.'
                ),
            ),
        ],
        group_by: Annotated[
            Optional[list[dict[str, Any]]],
            Field(
                description=(
                    'Optional groupings. Each: {"field": "<api_name>", '
                    '"granularity": "year|quarter|month|week|day|hour"} '
                    "for date fields."
                )
            ),
        ] = None,
        filter: Annotated[
            Optional[dict[str, Any]],
            Field(description=f"Pre-aggregation filter. {_FILTER_DESC}"),
        ] = None,
        having: Annotated[
            Optional[dict[str, Any]],
            Field(
                description=(
                    "Post-aggregation filter; references metric aliases "
                    "instead of property names."
                )
            ),
        ] = None,
        sort: Annotated[
            Optional[list[str]],
            Field(
                description="Sort spec; can reference metric aliases (e.g. '-revenue')."
            ),
        ] = None,
        limit: Annotated[int, Field(ge=1, le=10_000)] = 1000,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Aggregate objects: group_by + metrics with optional filter and having.

        Operators: count, count_distinct, sum, avg, min, max, first, last.
        Time granularities for date group_by fields: year, quarter, month,
        week, day, hour.
        """
        try:
            qb = _client(ctx).objects(entity)
            if filter is not None:
                qb = qb.with_filter(filter)
            result = await qb.aggregate(
                metrics=metrics,
                group_by=group_by,
                having=having,
                sort=sort,
                limit=limit,
            )
            return _render(
                result,
                response_format,
                lambda r: format_aggregation(entity, r),
            )
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    # === Datasets =========================================================

    @mcp.tool(
        name="agimus_list_datasets",
        annotations=_read_only("List Datasets"),
    )
    async def agimus_list_datasets(
        ctx: Context,
        source_type: Annotated[
            Optional[str],
            Field(
                description=(
                    "Filter by source: 'external', 'file_upload', or 'pipeline'."
                ),
                pattern="^(external|file_upload|pipeline)$",
            ),
        ] = None,
        search: Annotated[
            Optional[str],
            Field(
                description="Substring filter on dataset name.", max_length=200,
            ),
        ] = None,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """List datasets accessible to the current API key.

        Datasets are the raw data backing the ontology. For actual data
        downloads, write code that uses the synchronous AgimusClient with
        Arrow Flight in the user's environment.
        """
        try:
            datasets = await _client(ctx).datasets.list(
                search=search, source_type=source_type
            )
            payload = [
                {
                    "id": d.id,
                    "name": d.name,
                    "description": d.description,
                    "sourceType": d.source_type,
                    "totalRows": d.total_rows,
                    "totalSizeBytes": d.total_size_bytes,
                    "lastSyncedAt": d.last_synced_at,
                    "flightUrl": d.flight_url,
                }
                for d in datasets
            ]
            return _render(payload, response_format, format_dataset_list)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    @mcp.tool(
        name="agimus_get_dataset_schema",
        annotations=_read_only("Get Dataset Schema"),
    )
    async def agimus_get_dataset_schema(
        ctx: Context,
        dataset: Annotated[
            str,
            Field(
                min_length=1,
                max_length=200,
                description=(
                    "Dataset name or UUID. Use agimus_list_datasets to discover."
                ),
            ),
        ],
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Columns, types, row count, and metadata for a dataset.

        Accepts the dataset name or UUID. The response includes an SDK
        usage snippet the LLM can adapt for the user's project.
        """
        try:
            ds = await _client(ctx).datasets.get_metadata(dataset)
            payload = {
                "id": ds.id,
                "name": ds.name,
                "description": ds.description,
                "sourceType": ds.source_type,
                "totalRows": ds.total_rows,
                "totalSizeBytes": ds.total_size_bytes,
                "lastSyncedAt": ds.last_synced_at,
                "columns": ds.columns,
                "flightUrl": ds.flight_url,
            }
            return _render(payload, response_format, format_dataset_schema)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)

    # === Diagnostic =======================================================

    @mcp.tool(
        name="agimus_whoami",
        annotations=_read_only("API Key Info"),
    )
    async def agimus_whoami(
        ctx: Context,
        response_format: Annotated[
            ResponseFormat, Field(description=_RESPONSE_FORMAT_DESC)
        ] = ResponseFormat.MARKDOWN,
    ) -> str:
        """Identify the current API key: tenant name, scope, rate limit.

        Use this on first connection to confirm which Agimus tenant you're
        talking to and whether the key has read-only or read-write scope.
        """
        try:
            info = await _client(ctx).me()
            return _render(info, response_format, format_whoami)
        except Exception as exc:  # noqa: BLE001
            return to_error_message(exc)
