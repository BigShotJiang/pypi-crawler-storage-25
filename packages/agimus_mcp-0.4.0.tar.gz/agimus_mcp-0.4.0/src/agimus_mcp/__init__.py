"""
Agimus MCP Server.

Exposes the Agimus data platform to MCP-aware AI tools (Claude Desktop,
Claude Code, Cursor, OpenAI Codex, …) so the LLM can discover entities,
inspect schemas, traverse the link graph, query the object store, and write
correct code against the Agimus Python SDK.

Programmatic use::

    from agimus_mcp import create_server
    create_server(api_key="agm_...").run()
"""

from .server import create_server

__version__ = "0.4.0"

__all__ = ["create_server", "__version__"]
