"""
Agimus MCP resources.

Resources are read-only context blobs identified by URI. The MCP client
(Claude Desktop, Cursor, etc.) lets the user attach them to a conversation
as persistent context — useful for keeping the SDK reference visible across
many turns.

Two flavors:

* **Dynamic** — computed against the user's live ontology each call. Backed
  by the SDK.
* **Static** — bundled markdown files (SDK reference). Same content every
  read.
"""

from __future__ import annotations

import logging

from agimus import AsyncAgimusClient
from mcp.server.fastmcp import Context, FastMCP

from .formatters import format_entity_schema, load_doc

logger = logging.getLogger("agimus_mcp.resources")


def _client(ctx: Context) -> AsyncAgimusClient:
    return ctx.request_context.lifespan_context["agimus"]


_STATIC_DOCS: tuple[tuple[str, str, str, str], ...] = (
    (
        "agimus://docs/sdk-reference",
        "Agimus SDK Reference",
        (
            "Full Agimus Python SDK reference — installation, querying, "
            "filtering, aggregation, link traversal, write operations, "
            "datasets/Flight downloads, error handling, async usage. "
            "Sourced from the SDK's own README so it never drifts."
        ),
        "sdk_reference.md",
    ),
)


def register_resources(mcp: FastMCP) -> None:
    """Register all Agimus resources on the given MCP instance."""

    # --- Dynamic: live per-entity schema ----------------------------------

    @mcp.resource(
        "agimus://schema/entities/{entity}",
        name="Entity Schema",
        description="Full schema (properties, types, links) for a single entity.",
        mime_type="text/markdown",
    )
    async def entity_schema_resource(entity: str, ctx: Context) -> str:
        schema = await _client(ctx).get_entity_schema(entity)
        return format_entity_schema(schema)

    # --- Static: bundled SDK reference docs -------------------------------

    for uri, name, description, filename in _STATIC_DOCS:
        _register_static_doc(mcp, uri, name, description, filename)


def _register_static_doc(
    mcp: FastMCP,
    uri: str,
    name: str,
    description: str,
    filename: str,
) -> None:
    """Register one bundled markdown file as a resource.

    Defined out-of-line so each loop iteration captures its own ``filename``;
    a closure inside the loop would have every resource serve the last
    filename in the list.
    """

    @mcp.resource(uri, name=name, description=description, mime_type="text/markdown")
    def _doc() -> str:
        return load_doc(filename)
