"""
CLI entry point for the Agimus MCP server.

Usage::

    agimus-mcp                                         # reads AGIMUS_API_KEY
    agimus-mcp --api-key agm_xxx
    agimus-mcp --api-key agm_xxx --base-url https://staging-api.agimus.ai

Wired in pyproject.toml as the ``agimus-mcp`` console script and runnable
as ``python -m agimus_mcp``.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="agimus-mcp",
        description="MCP server for the Agimus data platform.",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("AGIMUS_API_KEY"),
        help="Agimus API key (starts with 'agm_'). Can also be set via AGIMUS_API_KEY.",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("AGIMUS_BASE_URL", "https://api.agimus.ai"),
        help=(
            "Agimus API base URL (default: https://api.agimus.ai). "
            "Can also be set via AGIMUS_BASE_URL."
        ),
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=float(os.environ.get("AGIMUS_TIMEOUT", "30")),
        help="Per-request timeout in seconds (default: 30).",
    )
    parser.add_argument(
        "--log-level",
        default=os.environ.get("AGIMUS_LOG_LEVEL", "WARNING"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help=(
            "Log level. Logs go to stderr (stdout is reserved for the MCP "
            "stdio protocol)."
        ),
    )
    args = parser.parse_args()

    if not args.api_key:
        sys.exit(
            "Error: API key is required.\n"
            "Set AGIMUS_API_KEY or pass --api-key agm_your_key_here."
        )
    if not args.api_key.startswith("agm_"):
        sys.exit("Error: Invalid API key format. Agimus keys start with 'agm_'.")

    logging.basicConfig(
        level=args.log_level,
        stream=sys.stderr,
        format="%(asctime)s %(name)s %(levelname)s: %(message)s",
    )

    # Lazy import so --help doesn't pay the SDK + MCP import cost.
    from .server import create_server

    create_server(
        api_key=args.api_key,
        base_url=args.base_url,
        timeout=args.timeout,
    ).run()


if __name__ == "__main__":
    main()
