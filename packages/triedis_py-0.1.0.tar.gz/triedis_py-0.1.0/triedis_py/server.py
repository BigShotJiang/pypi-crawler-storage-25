from __future__ import annotations
import importlib.resources
import socket
import subprocess
import time
from pathlib import Path


class TriedisServerStartupError(Exception):
    """Raised when the bundled triedis server fails to start."""


class TriedisServer:
    """Manages a bundled triedis subprocess."""

    def __init__(self, host: str = "localhost", port: int = 4657) -> None:
        self._host = host
        self._port = port
        self._process: subprocess.Popen | None = None

    @property
    def port(self) -> int:
        return self._port

    def start(self, timeout: float = 5.0) -> None:
        """Start the bundled triedis binary and wait until it accepts connections."""
        binary = self._find_binary()
        self._process = subprocess.Popen(
            [str(binary)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        self._wait_until_ready(timeout)

    def stop(self) -> None:
        """Terminate the triedis process."""
        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None

    def _find_binary(self) -> Path:
        pkg = importlib.resources.files("triedis_py")
        return Path(str(pkg)) / "bin" / "triedis"

    def _wait_until_ready(self, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                with socket.create_connection((self._host, self._port), timeout=0.1):
                    return
            except OSError:
                time.sleep(0.05)
        raise TriedisServerStartupError(
            f"triedis server did not accept connections within {timeout}s"
        )
