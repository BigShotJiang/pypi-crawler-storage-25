from __future__ import annotations
import socket
import time
from triedis_py.resp import encode_command, read_response
from triedis_py.server import TriedisServer
from triedis_py.trie import Trie


class TriedisConnectionError(Exception):
    """Raised when the client cannot connect to the server."""


class TriedisClient:
    """Synchronous client for the triedis server.

    The triedis server processes exactly one command per TCP buffer read and
    does not support command pipelining.  Commands that expect a response
    (GET, TPREFIX, PING) are sent on the main persistent connection and the
    response is read back before returning.  Commands that have no response
    (SET) are sent on a short-lived dedicated connection so they are always
    delivered in isolation, guaranteeing the server has processed the command
    before the next one is issued on the main connection.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 4657,
        auto_start: bool = True,
    ) -> None:
        self._host = host
        self._port = port
        self._auto_start = auto_start
        self._server: TriedisServer | None = None
        self._sock: socket.socket | None = None
        self._file = None

    def __enter__(self) -> TriedisClient:
        if self._auto_start:
            self._server = TriedisServer(host=self._host, port=self._port)
            self._server.start()
        try:
            self._sock = socket.create_connection((self._host, self._port))
            self._file = self._sock.makefile("rb")
        except OSError as e:
            if self._server:
                self._server.stop()
            raise TriedisConnectionError(
                f"Cannot connect to triedis at {self._host}:{self._port}"
            ) from e
        return self

    def __exit__(self, *_) -> None:
        if self._file:
            self._file.close()
        if self._sock:
            self._sock.close()
        if self._server:
            self._server.stop()

    def _send_fire_and_forget(self, args: list[str]) -> None:
        """Send a command that has no server response on a short-lived connection.

        A fresh TCP connection is used so the command is delivered in its own
        TCP segment.  This works around the server's single-command-per-read
        limitation and ensures the command is fully processed before the next
        command is issued on the main connection.
        """
        with socket.create_connection((self._host, self._port)) as s:
            s.sendall(encode_command(args))
            # Signal end-of-write so the server sees EOF after processing
            s.shutdown(socket.SHUT_WR)
            try:
                s.recv(1024)  # drain any unexpected data / wait for close
            except OSError:
                pass
        # Brief pause to allow the server's event loop to complete the insert
        # before a subsequent command queries the modified trie state.
        time.sleep(0.01)

    def send_command(
        self, args: list[str], expect_response: bool = True
    ) -> list[str]:
        """Send a RESP command and optionally read the response.

        When expect_response is False the command is sent on a dedicated
        short-lived connection (see _send_fire_and_forget).  When
        expect_response is True the command is sent on the persistent main
        connection and the response is read back before returning.
        """
        if not expect_response:
            self._send_fire_and_forget(args)
            return []
        assert self._sock is not None, "Client not connected — use as context manager"
        self._sock.sendall(encode_command(args))
        return read_response(self._file)

    def trie(self, name: str) -> Trie:
        """Return a Trie proxy for the named trie."""
        return Trie(self, name)

    def ping(self, message: str = "") -> str:
        """Send PING, return the server's reply string.

        The server wraps the pong/echo reply in a RESP bulk string that
        includes the simple-string prefix and trailing CRLF, e.g. '+pong\\r\\n'
        or '+hello \\r\\n' (with a trailing space before CRLF).  This method
        strips both artefacts to return just the bare message.
        """
        args = ["PING"] if not message else ["PING", message]
        result = self.send_command(args)
        if not result:
            return ""
        raw = result[0]
        # Strip leading RESP type prefix character (+, -, :, $, *)
        if raw.startswith(("+", "-", ":", "$", "*")):
            raw = raw[1:]
        # Strip trailing \r\n and any trailing whitespace the server appended
        return raw.rstrip("\r\n").rstrip()
