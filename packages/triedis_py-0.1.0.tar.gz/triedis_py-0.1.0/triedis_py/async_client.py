from __future__ import annotations
import asyncio
from triedis_py.resp import encode_command, TriedisCommandError, TriedisProtocolError
from triedis_py.server import TriedisServer
from triedis_py.trie import AsyncTrie


class AsyncTriedisClient:
    """Asynchronous client for the triedis server using asyncio."""

    def __init__(
        self,
        host: str = "localhost",
        port: int = 4657,
        auto_start: bool = True,
    ) -> None:
        self._host = host
        self._port = port
        self._auto_start = auto_start
        self._server: TriedisServer | None = None
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None

    async def __aenter__(self) -> AsyncTriedisClient:
        if self._auto_start:
            self._server = TriedisServer(host=self._host, port=self._port)
            self._server.start()
        self._reader, self._writer = await asyncio.open_connection(
            self._host, self._port
        )
        return self

    async def __aexit__(self, *_) -> None:
        if self._writer:
            self._writer.close()
            await self._writer.wait_closed()
        if self._server:
            self._server.stop()

    async def _send_fire_and_forget(self, args: list[str]) -> None:
        """Send a command with no response on a short-lived connection."""
        reader, writer = await asyncio.open_connection(self._host, self._port)
        writer.write(encode_command(args))
        await writer.drain()
        writer.write_eof()
        try:
            await asyncio.wait_for(reader.read(1024), timeout=1.0)
        except (asyncio.TimeoutError, OSError):
            pass
        writer.close()
        await writer.wait_closed()
        await asyncio.sleep(0.01)

    async def send_command(
        self, args: list[str], expect_response: bool = True
    ) -> list[str]:
        if not expect_response:
            await self._send_fire_and_forget(args)
            return []
        assert self._writer is not None, "Client not connected — use as async context manager"
        self._writer.write(encode_command(args))
        await self._writer.drain()
        return await self._read_response()

    async def _read_response(self) -> list[str]:
        assert self._reader is not None
        line = await self._reader.readline()
        if not line:
            return []

        prefix = line[0:1]
        body = line[1:].rstrip(b"\r\n")

        if prefix == b"+":
            return [body.decode()]

        if prefix == b"-":
            raise TriedisCommandError(body.decode())

        if prefix == b"*":
            try:
                count = int(body)
            except ValueError:
                raise TriedisProtocolError(f"Invalid array count: {body!r}")
            result: list[str] = []
            for _ in range(count):
                bulk_header = await self._reader.readline()
                if not bulk_header or not bulk_header.startswith(b"$"):
                    raise TriedisProtocolError(f"Expected bulk string header: {bulk_header!r}")
                try:
                    size = int(bulk_header[1:].rstrip(b"\r\n"))
                except ValueError:
                    raise TriedisProtocolError(f"Invalid bulk length: {bulk_header!r}")
                data = await self._reader.readexactly(size + 2)
                result.append(data[:-2].decode())
            return result

        raise ValueError(f"Unexpected RESP prefix: {prefix!r}")

    def trie(self, name: str) -> AsyncTrie:
        return AsyncTrie(self, name)

    async def ping(self, message: str = "") -> str:
        args = ["PING"] if not message else ["PING", message]
        result = await self.send_command(args)
        if not result:
            return ""
        raw = result[0]
        if raw.startswith(("+", "-", ":", "$", "*")):
            raw = raw[1:]
        return raw.rstrip("\r\n").rstrip()
