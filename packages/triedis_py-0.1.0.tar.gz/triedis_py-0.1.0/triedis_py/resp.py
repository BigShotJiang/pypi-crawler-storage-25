from __future__ import annotations
from typing import BinaryIO


class TriedisCommandError(Exception):
    """Raised when the server returns a RESP error response."""


class TriedisProtocolError(Exception):
    """Raised when a malformed or incomplete RESP response is received."""


def encode_command(args: list[str]) -> bytes:
    """Encode a list of string arguments as a RESP array of bulk strings."""
    parts: list[bytes] = [f"*{len(args)}\r\n".encode()]
    for arg in args:
        encoded = arg.encode()
        parts.append(f"${len(encoded)}\r\n".encode())
        parts.append(encoded)
        parts.append(b"\r\n")
    return b"".join(parts)


def read_response(f: BinaryIO) -> list[str]:
    """Read one complete RESP response from a binary file-like object.

    Returns a list of strings. Simple strings are returned as a one-element list.
    Raises TriedisCommandError on RESP error responses.
    Raises TriedisProtocolError on malformed or incomplete responses.
    """
    line = f.readline()
    if not line:
        return []

    prefix = line[0:1]
    body = line[1:].rstrip(b"\r\n")

    if prefix == b"+":
        return [body.decode()]

    if prefix == b"-":
        raise TriedisCommandError(body.decode())

    if prefix == b"*":
        try:
            count = int(body)
        except ValueError:
            raise TriedisProtocolError(f"Invalid array count in RESP: {body!r}")
        result: list[str] = []
        for _ in range(count):
            bulk_header = f.readline()
            if not bulk_header or not bulk_header.startswith(b"$"):
                raise TriedisProtocolError(
                    f"Expected bulk string header, got: {bulk_header!r}"
                )
            try:
                size = int(bulk_header[1:].rstrip(b"\r\n"))
            except ValueError:
                raise TriedisProtocolError(
                    f"Invalid bulk string length in RESP: {bulk_header!r}"
                )
            data = f.read(size + 2)  # bulk data + \r\n
            if len(data) < size + 2:
                raise TriedisProtocolError(
                    f"Incomplete bulk string: expected {size} bytes, got {len(data) - 2}"
                )
            result.append(data[:-2].decode())
        return result

    raise ValueError(f"Unexpected RESP prefix: {prefix!r} in line {line!r}")
