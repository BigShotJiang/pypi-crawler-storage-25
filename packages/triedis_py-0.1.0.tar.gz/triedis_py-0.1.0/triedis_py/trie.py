from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from triedis_py.client import TriedisClient


class Trie:
    """Proxy for a named trie on the triedis server."""

    def __init__(self, client: TriedisClient, name: str) -> None:
        self._client = client
        self._name = name

    def insert(self, word: str) -> None:
        """Insert a word into this trie. No response from server."""
        self._client.send_command(["SET", self._name, word], expect_response=False)

    def contains(self, word: str) -> bool:
        """Return True if this trie contains the exact word."""
        result = self._client.send_command(["GET", self._name, word])
        return result == ["t"]

    def prefix_search(self, prefix: str) -> list[str]:
        """Return all words in this trie that start with prefix."""
        return self._client.send_command(["TPREFIX", self._name, prefix])


if TYPE_CHECKING:
    from triedis_py.async_client import AsyncTriedisClient


class AsyncTrie:
    """Async proxy for a named trie on the triedis server."""

    def __init__(self, client: AsyncTriedisClient, name: str) -> None:
        self._client = client
        self._name = name

    async def insert(self, word: str) -> None:
        await self._client.send_command(["SET", self._name, word], expect_response=False)

    async def contains(self, word: str) -> bool:
        result = await self._client.send_command(["GET", self._name, word])
        return result == ["t"]

    async def prefix_search(self, prefix: str) -> list[str]:
        return await self._client.send_command(["TPREFIX", self._name, prefix])
