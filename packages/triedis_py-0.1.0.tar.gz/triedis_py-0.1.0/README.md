# triedis-py

Python client for [triedis](../triedis/), an in-memory trie server.

Bundles the triedis Linux binary — no separate server install needed.

## Installation

```bash
uv add triedis-py
```

## Usage

### Sync

```python
from triedis_py import TriedisClient

with TriedisClient() as client:           # auto-starts bundled server
    trie = client.trie("words")
    trie.insert("cat")
    trie.insert("category")
    print(trie.contains("cat"))           # True
    print(trie.prefix_search("cat"))      # ["cat", "category"]
```

### Async

```python
from triedis_py import AsyncTriedisClient

async with AsyncTriedisClient() as client:
    trie = client.trie("words")
    await trie.insert("cat")
    print(await trie.prefix_search("ca")) # ["cat"]
```

### Connect to existing server

```python
with TriedisClient(auto_start=False, host="localhost", port=4657) as client:
    ...
```

## Commands

| Trie method | Server command | Returns |
|---|---|---|
| `insert(word)` | `SET <trie> <word>` | `None` |
| `contains(word)` | `GET <trie> <word>` | `bool` |
| `prefix_search(prefix)` | `TPREFIX <trie> <prefix>` | `list[str]` |
