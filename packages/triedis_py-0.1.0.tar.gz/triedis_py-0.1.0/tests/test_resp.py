import pytest
from triedis_py.resp import encode_command, read_response, TriedisCommandError
import io


# --- encode_command ---

def test_encode_single_arg():
    assert encode_command(["PING"]) == b"*1\r\n$4\r\nPING\r\n"


def test_encode_three_args():
    result = encode_command(["SET", "mytrie", "cat"])
    assert result == b"*3\r\n$3\r\nSET\r\n$6\r\nmytrie\r\n$3\r\ncat\r\n"


def test_encode_two_args():
    result = encode_command(["TPREFIX", "mytrie"])
    assert result == b"*2\r\n$7\r\nTPREFIX\r\n$6\r\nmytrie\r\n"


# --- read_response ---

def _buf(data: bytes):
    """Wrap bytes as a readable file-like object."""
    return io.BytesIO(data)


def test_read_simple_string():
    result = read_response(_buf(b"+pong\r\n"))
    assert result == ["pong"]


def test_read_array_single_element():
    result = read_response(_buf(b"*1\r\n$1\r\nt\r\n"))
    assert result == ["t"]


def test_read_array_multiple_elements():
    data = b"*3\r\n$3\r\ncat\r\n$8\r\ncategory\r\n$9\r\ncathedral\r\n"
    result = read_response(_buf(data))
    assert result == ["cat", "category", "cathedral"]


def test_read_empty_array():
    result = read_response(_buf(b"*0\r\n"))
    assert result == []


def test_read_error_raises():
    with pytest.raises(TriedisCommandError, match="trie not found"):
        read_response(_buf(b"-ERR trie not found\r\n"))
