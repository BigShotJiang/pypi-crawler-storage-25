import pytest
from triedis_py import TriedisClient
from triedis_py.resp import TriedisCommandError


@pytest.fixture(scope="module")
def client():
    """Start a single triedis server for the entire test module."""
    with TriedisClient() as c:
        yield c


def test_ping(client):
    assert client.ping() == "pong"


def test_ping_with_message(client):
    assert client.ping("hello") == "hello"


def test_insert_and_contains(client):
    trie = client.trie("test_contains")
    trie.insert("apple")
    assert trie.contains("apple") is True


def test_contains_missing_word(client):
    trie = client.trie("test_contains_missing")
    trie.insert("apple")
    assert trie.contains("banana") is False


def test_prefix_search(client):
    trie = client.trie("test_prefix")
    trie.insert("cat")
    trie.insert("category")
    trie.insert("cathedral")
    trie.insert("dog")
    result = trie.prefix_search("cat")
    assert sorted(result) == ["cat", "category", "cathedral"]


def test_prefix_search_no_matches(client):
    trie = client.trie("test_prefix_no_matches")
    trie.insert("apple")
    result = trie.prefix_search("xyz")
    assert result == []


def test_trie_not_found_raises(client):
    trie = client.trie("nonexistent_trie_xyz")
    with pytest.raises(TriedisCommandError):
        trie.contains("anything")


from triedis_py import AsyncTriedisClient


@pytest.fixture
async def async_client():
    async with AsyncTriedisClient() as c:
        yield c


@pytest.mark.asyncio
async def test_async_ping(async_client):
    assert await async_client.ping() == "pong"


@pytest.mark.asyncio
async def test_async_insert_and_contains(async_client):
    trie = async_client.trie("async_test_contains")
    await trie.insert("apple")
    assert await trie.contains("apple") is True


@pytest.mark.asyncio
async def test_async_prefix_search(async_client):
    trie = async_client.trie("async_test_prefix")
    await trie.insert("cat")
    await trie.insert("category")
    result = await trie.prefix_search("cat")
    assert sorted(result) == ["cat", "category"]
