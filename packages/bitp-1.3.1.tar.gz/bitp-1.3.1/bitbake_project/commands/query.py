#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""JSON query interface — reusable data functions for web API and CLI.

``bit query <path>`` outputs JSON to stdout, allowing the web server to
call ``ssh bit query repos/NAME/commits --project /path`` on remote hosts
and get the exact same data as the local web API.

Supported query paths::

    repos                              — list of repo dicts
    repos/<name>/branches              — branch list with filtering
    repos/<name>/commits               — local/upstream commits + branch
    repos/<name>/commits/<hash>/show   — commit metadata + diff + stat
    repos/<name>/commits/<hash>/lore   — lore.kernel.org search results
    repos/<name>/commits/<hash>/changed-files — files changed in commit
    repos/<name>/diff                  — uncommitted changes
    repos/<name>/tree                  — file tree (ls-tree)
    repos/<name>/files/<path>/commits  — per-file commit history
    repos/<name>/layers                — layers in a repo
    repos/<name>/checkout/<branch>     — checkout branch (mutation)
    repos/<name>/fetch                 — fetch upstream (mutation)
    repos/<name>/update[/<action>]     — update repo (mutation)
    repos/<name>/track                 — track repo (mutation)
    repos/<name>/hide                  — hide repo (mutation)
    repos/<name>/prune-backups         — prune backup branches (mutation)
    repos/<name>/rebase-prepare[/<base>] — prepare interactive rebase
    repos/<name>/drop                  — drop commits with backup (POST)
    repos/<name>/graph[?count=N]       — git log --graph output
    repos/<name>/export-patches        — export commits as patches (POST)
    repos/branches/union               — union of branches across repos
    repos/branch-all/<branch>          — switch all repos to branch
    refresh                            — fetch all repos
    fragments                          — all fragments with enabled/disabled status
    fragments/enable                   — enable a fragment (POST)
    fragments/disable                  — disable a fragment (POST)
    fragments/builtin                  — set builtin prefix value (POST)
    export/preview                     — exportable commits per repo
    export/prepare                     — prepare export (branch + patches)
    export/patches                     — batch patch export with options (POST)
"""

import json
import os
import re
import subprocess
import sys


def _resolve_repos(project: str, discover: bool = False,
                    include_hidden: bool = False):
    """Resolve repos, defaults, and layer map for a project path.

    Uses the project's configured persona so non-Yocto projects
    (generic, etc.) discover repos correctly — matching the TUI's
    ``run_explore()`` behaviour.

    When *discover* is True (yocto persona only), all peer repos are
    discovered — equivalent to pressing 'A' (discover) in the TUI.

    When *include_hidden* is True, hidden repos that exist on disk are
    appended to the result — equivalent to pressing 'H' in the TUI.
    """
    from .projects import get_current_project, load_projects
    from .common import dedupe_preserve_order
    from ..core import load_defaults
    from ..persona import get_persona

    project_path = project or get_current_project()
    if not project_path or not os.path.isdir(project_path):
        return [], {}, {}, set(), set(), set(), set()

    from .common import set_message_log
    set_message_log(project_path)

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # Look up the project's persona from the registry
    projects = load_projects()
    proj_info = projects.get(project_path, {})
    persona = get_persona(project=proj_info)

    try:
        if persona.name != "yocto":
            pairs, repo_sets = persona.resolve_repos(
                None, defaults,
                include_external=True, discover_all=True,
                project_path=project_path)
        else:
            from .common import resolve_base_and_layers
            bblayers = None
            for cand in ("conf/bblayers.conf", "build/conf/bblayers.conf"):
                full = os.path.join(project_path, cand)
                if os.path.exists(full):
                    bblayers = full
                    break
            # include_external=False and discover_all=False match the TUI
            # default — only repos backing layers in bblayers.conf, not
            # every git repo or layer.conf found in peer directories.
            pairs, repo_sets = resolve_base_and_layers(
                bblayers, defaults, include_external=discover,
                discover_all=discover)
    except Exception:
        return [], {}, {}, set(), set(), set(), set()

    repos = dedupe_preserve_order(
        repo for _, repo in pairs if repo not in repo_sets.hidden
    )
    for ext_repo in repo_sets.external:
        if ext_repo not in repos and ext_repo not in repo_sets.hidden:
            repos.append(ext_repo)

    # When include_hidden is requested, re-add hidden repos that still exist
    hidden_repos = repo_sets.hidden
    if include_hidden:
        for h in hidden_repos:
            if h not in repos and os.path.isdir(h):
                repos.append(h)

    repo_layers = {}
    for layer, repo in pairs:
        repo_layers.setdefault(repo, []).append(layer)

    # Use the bblayers.conf-derived set from repo_sets, not all resolved layers
    configured_layers = getattr(repo_sets, 'configured_layers', set())
    discovered_repos = getattr(repo_sets, 'discovered', set())
    external_repos = getattr(repo_sets, 'external', set())
    return repos, defaults, repo_layers, configured_layers, discovered_repos, external_repos, hidden_repos


def _find_repo(repos, repo_name, defaults):
    """Find a repo by display name, path, or identifier."""
    from .common import find_repo_by_identifier
    return find_repo_by_identifier(repos, repo_name, defaults)


def query_repos(project: str, discover: bool = False,
                include_hidden: bool = False) -> dict:
    """Return list of repo dicts (same shape as /api/repos)."""
    from .explore import gather_repo_status

    repos, defaults, repo_layers, configured_layers, discovered_repos, external_repos, hidden_repos = _resolve_repos(
        project, discover=discover, include_hidden=include_hidden)
    result = []
    for repo in repos:
        info = gather_repo_status(repo, defaults, status_mode=True,
                                  repo_layers=repo_layers)
        info["path"] = repo
        info["layers"] = repo_layers.get(repo, [])
        info["is_discovered"] = repo in discovered_repos
        info["is_external"] = repo in external_repos
        info["is_hidden"] = repo in hidden_repos
        if info.get("head_commit"):
            info["head_commit"] = {
                "sha": info["head_commit"][0],
                "subject": info["head_commit"][1],
            }
        result.append(info)
    return {"repos": result, "configured_layers": sorted(configured_layers)}


def _get_commit_refs(repo: str) -> dict:
    """Build commit SHA → ref decorations map (branches, remotes, tags)."""
    commit_refs: dict = {}
    for ref_glob, ref_type in [("refs/heads/", "local"),
                                ("refs/remotes/", "remote"),
                                ("refs/tags/", "tag")]:
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "for-each-ref",
                 "--format=%(objectname) %(refname:short)", ref_glob],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            for line in out.splitlines():
                if not line:
                    continue
                sha, ref = line.split(" ", 1)
                commit_refs.setdefault(sha, []).append(
                    {"name": ref, "type": ref_type})
        except Exception:
            pass
    return commit_refs


def query_repo_commits(repo_name: str, project: str,
                       upstream_limit: int = 500,
                       context_limit: int = 20,
                       layer: str = "") -> dict:
    """Return {local, upstream, context, base_ref, branch, refs} for a repo.

    Mirrors the TUI's ``fzf_explore_commits`` data model:
    * **local** — commits ahead of upstream (newest-first, display order)
    * **upstream** — commits to pull (newest-first, capped by *upstream_limit*)
    * **context** — commits *below* the merge base for reference
      (capped by *context_limit*)
    * **base_ref** — the merge base (upstream tracking ref)

    When *layer* is set (relative path, e.g. ``meta-core``), commits are
    filtered to only those touching files under that subdirectory.
    """
    from .branch import (get_local_commits, get_upstream_to_pull,
                         get_upstream_context_commits,
                         get_local_commits_for_layer,
                         get_upstream_to_pull_for_layer)
    from .update import fetch_repo
    from ..core import current_branch

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    # Resolve layer to absolute path when filtering
    layer_path = os.path.join(repo, layer) if layer else ""

    branch = current_branch(repo)
    local: list = []
    upstream: list = []
    context: list = []
    base_ref = ""
    base_sha = ""
    if branch:
        try:
            if layer_path:
                commits_list, bref = get_local_commits_for_layer(
                    repo, branch, layer_path)
            else:
                commits_list, bref = get_local_commits(repo, branch)
            # Reverse to newest-first (display order) — get_local_commits
            # returns oldest-first; the TUI reverses in fzf_explore_commits.
            local = [f"{h} {s}" for h, s in reversed(commits_list or [])]
            base_ref = bref or ""
            # Resolve the ref to a SHA *before* fetching — the fetch may
            # move the ref forward, but the SHA is stable.
            if base_ref:
                try:
                    base_sha = subprocess.check_output(
                        ["git", "-C", repo, "rev-parse", base_ref],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                except Exception:
                    pass
            # Fallback: parent of oldest local commit is always a valid
            # rebase base and doesn't depend on symbolic ref resolution.
            if not base_sha and commits_list:
                try:
                    base_sha = subprocess.check_output(
                        ["git", "-C", repo, "rev-parse",
                         f"{commits_list[0][0]}^"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                except Exception:
                    pass
        except Exception:
            pass
        # Fetch so upstream refs are current (matches TUI behaviour)
        try:
            fetch_repo(repo)
        except Exception:
            pass
        try:
            if layer_path:
                up = get_upstream_to_pull_for_layer(
                    repo, branch, layer_path, count=upstream_limit)
            else:
                up = get_upstream_to_pull(repo, branch, count=upstream_limit)
            upstream = [f"{h} {s}" for h, s in up]
        except Exception:
            pass
        # Context commits below merge base
        if base_ref:
            try:
                ctx = get_upstream_context_commits(
                    repo, base_ref, count=context_limit)
                context = [f"{h} {s}" for h, s in ctx]
            except Exception:
                pass

    # Build ref decorations map
    refs = _get_commit_refs(repo) if repo else {}

    result = {"local": local, "upstream": upstream, "context": context,
              "base_ref": base_ref, "branch": branch or "", "refs": refs}
    if base_sha:
        result["base_sha"] = base_sha
    if layer:
        result["layer"] = layer
    return result


def query_commit_show(repo_name: str, commit_hash: str,
                      project: str) -> dict:
    """Return commit metadata + diff + stat."""
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        meta = subprocess.check_output(
            ["git", "-C", repo, "show", "--no-patch",
             "--format=%H%n%an%n%ae%n%ai%n%s%n%b", commit_hash],
            text=True, stderr=subprocess.DEVNULL, timeout=10
        ).strip().split("\n", 5)
        diff = subprocess.check_output(
            ["git", "-C", repo, "show", "--format=", "--patch", commit_hash],
            text=True, stderr=subprocess.DEVNULL, timeout=30
        )
        stat = subprocess.check_output(
            ["git", "-C", repo, "show", "--format=", "--stat", commit_hash],
            text=True, stderr=subprocess.DEVNULL, timeout=10
        ).strip()
        return {
            "sha": meta[0] if len(meta) > 0 else "",
            "author": meta[1] if len(meta) > 1 else "",
            "email": meta[2] if len(meta) > 2 else "",
            "date": meta[3] if len(meta) > 3 else "",
            "subject": meta[4] if len(meta) > 4 else "",
            "body": meta[5].strip() if len(meta) > 5 else "",
            "diff": diff,
            "stat": stat,
        }
    except subprocess.CalledProcessError:
        return {"error": f"Commit not found: {commit_hash}"}


def query_repo_diff(repo_name: str, project: str) -> dict:
    """Return uncommitted changes."""
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        diff = subprocess.check_output(
            ["git", "-C", repo, "diff"],
            text=True, stderr=subprocess.DEVNULL, timeout=10
        )
    except Exception:
        diff = ""
    return {"diff": diff}


def query_commit_lore(repo_name: str, commit_hash: str,
                      project: str) -> dict:
    """Return lore.kernel.org search results for a commit."""
    from .b4 import lore_search_for_commit

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        direct_msgid, results = lore_search_for_commit(
            repo, commit_hash, defaults)
    except Exception as e:
        return {"error": f"Lore search failed: {e}"}

    result_list = []
    for r in results:
        result_list.append({
            "msgid": r.msgid,
            "subject": r.subject,
            "author": r.author,
            "date": r.date,
            "url": r.url,
        })
    return {"direct_msgid": direct_msgid, "results": result_list}


def query_file_tree(repo_name: str, ref: str, project: str) -> dict:
    """Return nested file tree for a repo at a given ref."""
    from .explore import _build_file_tree

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        out = subprocess.check_output(
            ["git", "-C", repo, "ls-tree", "-r", "--name-only", ref],
            text=True, stderr=subprocess.DEVNULL, timeout=15,
        ).strip()
    except subprocess.CalledProcessError:
        return {"error": f"Failed to list tree for ref: {ref}"}

    file_list = out.splitlines() if out else []
    raw_tree = _build_file_tree(file_list)
    # Convert (name, is_dir) tuples to dicts for JSON
    tree = {}
    for parent, entries in raw_tree.items():
        tree[parent] = [{"name": n, "is_dir": d} for n, d in entries]
    return {"tree": tree, "file_count": len(file_list)}


def query_file_commits(repo_name: str, filepath: str, ref: str,
                       limit: int, project: str) -> dict:
    """Return recent commits touching a file."""
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    log_cmd = ["git", "-C", repo, "log", "--oneline", f"-{limit}"]
    if ref:
        log_cmd.append(ref)
    log_cmd.extend(["--", filepath])

    try:
        out = subprocess.check_output(
            log_cmd, text=True, stderr=subprocess.DEVNULL, timeout=15,
        ).strip()
    except subprocess.CalledProcessError:
        return {"commits": [], "has_more": False}

    commits = []
    for line in out.splitlines():
        if " " in line:
            h, s = line.split(" ", 1)
            commits.append({"hash": h, "subject": s})
        elif line:
            commits.append({"hash": line, "subject": ""})
    return {"commits": commits, "has_more": len(commits) >= limit}


def query_commit_changed_files(repo_name: str, commit_hash: str,
                               project: str) -> dict:
    """Return list of files changed in a commit."""
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        out = subprocess.check_output(
            ["git", "-C", repo, "diff-tree", "--no-commit-id", "-r",
             "--name-only", commit_hash],
            text=True, stderr=subprocess.DEVNULL, timeout=10,
        ).strip()
    except subprocess.CalledProcessError:
        return {"files": []}

    files = out.splitlines() if out else []
    return {"files": files}


def query_repo_log(repo: str, count: int = 50) -> list:
    """Return a list of commit dicts (sha, author, email, date, subject)."""
    try:
        log = subprocess.check_output(
            ["git", "-C", repo, "log", f"-{count}",
             "--format=%H|%an|%ae|%ai|%s"],
            text=True, stderr=subprocess.DEVNULL, timeout=10,
        )
        commits = []
        for line in log.strip().split("\n"):
            if not line:
                continue
            parts = line.split("|", 4)
            if len(parts) == 5:
                commits.append({
                    "sha": parts[0], "author": parts[1], "email": parts[2],
                    "date": parts[3], "subject": parts[4],
                })
        return commits
    except Exception:
        return []


def query_export_patch(repo: str, sha: str) -> dict:
    """Export a single commit as a patch, returning filename + content."""
    try:
        content = subprocess.check_output(
            ["git", "-C", repo, "format-patch", "-1", sha, "--stdout"],
            text=True, stderr=subprocess.DEVNULL, timeout=10,
        )
        subject = subprocess.check_output(
            ["git", "-C", repo, "log", "-1", "--format=%f", sha],
            text=True, stderr=subprocess.DEVNULL, timeout=5,
        ).strip()
        filename = f"0001-{subject}.patch" if subject else f"{sha[:12]}.patch"
        return {"filename": filename, "content": content}
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return {"filename": f"{sha[:12]}.patch", "content": "",
                "error": f"Failed to export {sha[:12]}"}


def _rewrite_subject_in_content(content: str, display_name: str,
                                prefix_tag: str, version_str: str,
                                idx: int, total: int) -> str:
    """In-memory equivalent of TUI's file-based subject rewriting.

    Finds the Subject: line, strips existing bracket tags via clean_title,
    and rebuilds as:
        Subject: [display_name][prefix_tag][PATCH vN XX/YY] title
    """
    from .common import clean_title

    lines = content.split("\n")
    for i, line in enumerate(lines):
        if line.lower().startswith("subject:"):
            # Extract the raw subject text after "Subject: "
            raw = line.split(":", 1)[1].strip()
            title = clean_title(raw)
            parts = [f"[{display_name}]"]
            if prefix_tag:
                parts.append(f"[{prefix_tag}]")
            parts.append(f"[PATCH {version_str}{idx:02d}/{total:02d}]")
            lines[i] = f"Subject: {''.join(parts)} {title}"
            break
    return "\n".join(lines)


def query_export_patches(project: str, repo_requests: list,
                         numbering: str = "global",
                         subject_prefix: str = "",
                         series_version: int = 0,
                         cover_letter: bool = True,
                         target_dir: str = "",
                         layout: str = "flat",
                         keep_content: bool = False) -> dict:
    """Export commits as patches with subject rewriting and optional cover letter.

    *repo_requests* is a list of dicts: {repo_name, commits: [sha]}
    *numbering*: "global" (single counter across all repos) or "per-repo"
    *target_dir*: if set, save patches to this directory on the local machine
    *layout*: "flat" (all patches in target_dir) or "per-repo" (subdirs)
    """
    from .common import repo_display_name, clean_title, author_ident

    repos, defaults, *_ = _resolve_repos(project)
    version_str = f"v{series_version} " if series_version else ""
    prefix_tag = subject_prefix

    # First pass: collect raw patches grouped by display_name
    raw_patches = []  # [(display_name, repo_name, filename_slug, content, error)]
    for req in repo_requests:
        repo_name = req.get("repo_name", "")
        commits = req.get("commits", [])
        repo = _find_repo(repos, repo_name, defaults)
        if not repo:
            for sha in commits:
                raw_patches.append((repo_name, repo_name, "", "",
                                    f"Repo not found: {repo_name}"))
            continue
        display_name = repo_display_name(repo)
        for sha in commits:
            try:
                content = subprocess.check_output(
                    ["git", "-C", repo, "format-patch", "-1", sha, "--stdout"],
                    text=True, stderr=subprocess.DEVNULL, timeout=10,
                )
                slug = subprocess.check_output(
                    ["git", "-C", repo, "log", "-1", "--format=%f", sha],
                    text=True, stderr=subprocess.DEVNULL, timeout=5,
                ).strip()
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                raw_patches.append((display_name, repo_name, "", "",
                                    f"Failed to export {sha[:12]}"))
                continue
            raw_patches.append((display_name, repo_name, slug, content, None))

    # Second pass: apply numbering and subject rewriting
    if numbering == "per-repo":
        # Count totals per display_name
        totals = {}
        for dn, _rn, _slug, _content, err in raw_patches:
            if not err:
                totals[dn] = totals.get(dn, 0) + 1
        counters = {}
        patches = []
        for dn, rn, slug, content, err in raw_patches:
            if err:
                patches.append({"repo_name": rn, "filename": "", "content": "",
                                "error": err})
                continue
            counters[dn] = counters.get(dn, 0) + 1
            idx = counters[dn]
            total = totals[dn]
            content = _rewrite_subject_in_content(
                content, dn, prefix_tag, version_str, idx, total)
            filename = f"{idx:04d}-{slug}.patch" if slug else f"{idx:04d}.patch"
            patches.append({"repo_name": rn, "filename": filename,
                            "content": content})
    else:
        # Global numbering
        total = sum(1 for _, _, _, _, err in raw_patches if not err)
        idx = 0
        patches = []
        for dn, rn, slug, content, err in raw_patches:
            if err:
                patches.append({"repo_name": rn, "filename": "", "content": "",
                                "error": err})
                continue
            idx += 1
            content = _rewrite_subject_in_content(
                content, dn, prefix_tag, version_str, idx, total)
            filename = f"{idx:04d}-{slug}.patch" if slug else f"{idx:04d}.patch"
            patches.append({"repo_name": rn, "filename": filename,
                            "content": content})

    # Cover letter
    if cover_letter and any(not p.get("error") for p in patches):
        # Find first valid repo for author info
        first_repo = None
        for req in repo_requests:
            r = _find_repo(repos, req.get("repo_name", ""), defaults)
            if r:
                first_repo = r
                break
        author_name, author_email = author_ident(first_repo or ".")
        from datetime import datetime
        date_str = datetime.now().astimezone().strftime(
            "%a, %d %b %Y %H:%M:%S %z")
        cl_total = sum(1 for p in patches if not p.get("error"))
        subj_parts = []
        if prefix_tag:
            subj_parts.append(f"[{prefix_tag}]")
        subj_parts.append(f"[PATCH {version_str}0/{cl_total}]")
        cl_subject = f"{''.join(subj_parts)} *** SUBJECT HERE ***"

        cl_lines = [
            "From 0000000000000000000000000000000000000000 Mon Sep 17 00:00:00 2001",
            f"From: {author_name} <{author_email}>",
            f"Date: {date_str}",
            f"Subject: {cl_subject}",
            "",
            "*** BLURB HERE ***",
            "",
        ]
        # Shortlog — cleaned subjects per patch
        for p in patches:
            if not p.get("error") and p["content"]:
                # Extract subject from content
                for line in p["content"].split("\n"):
                    if line.lower().startswith("subject:"):
                        subj = clean_title(line.split(":", 1)[1].strip())
                        cl_lines.append(f"  {subj}")
                        break
        cl_lines.append("")
        cl_lines.append("---")
        cl_lines.append("")
        cl_content = "\n".join(cl_lines)
        patches.insert(0, {"repo_name": "", "filename": "0000-cover-letter.patch",
                           "content": cl_content})

    result = {"patches": patches}

    # Save to local directory if requested (runs on the machine with the repos)
    if target_dir:
        import socket
        target_dir = os.path.expanduser(target_dir)
        real_dir = os.path.realpath(target_dir)
        saved = 0
        saved_files = []
        try:
            for p in patches:
                if p.get("error") or not p.get("content"):
                    continue
                if layout == "per-repo" and p.get("repo_name"):
                    out_dir = os.path.join(real_dir, p["repo_name"])
                else:
                    out_dir = real_dir
                os.makedirs(out_dir, exist_ok=True)
                out_path = os.path.join(out_dir, p["filename"])
                with open(out_path, "w", encoding="utf-8") as f:
                    f.write(p["content"])
                    f.flush()
                    os.fsync(f.fileno())
                saved_files.append(out_path)
                saved += 1
            hostname = socket.gethostname()
            result["saved_to"] = real_dir
            result["saved_count"] = saved
            result["saved_files"] = saved_files
            result["saved_host"] = hostname
            # Strip content unless caller also needs it (e.g. browser download).
            if not keep_content:
                for p in patches:
                    p.pop("content", None)
        except Exception as e:
            result["save_error"] = str(e)

    return result


def query_repo_graph(repo: str, count: int = 50) -> str:
    """Return git log --graph --oneline --decorate output."""
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "log", "--graph", "--oneline", "--decorate",
             f"-{count}"],
            text=True, stderr=subprocess.DEVNULL, timeout=10,
        )
    except Exception:
        return ""


def query_repo_graph_by_name(repo_name: str, count: int,
                             project: str) -> dict:
    """Graph output resolved by repo display name.

    Used by the web API (locally and via SSH for remote projects).
    """
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}
    return {"graph": query_repo_graph(repo, count)}


def query_export_patches_by_name(repo_name: str, commit_shas: list,
                                 project: str,
                                 target_dir: str = None) -> dict:
    """Export patches resolved by repo display name.

    Used by the web API (locally and via SSH for remote projects).
    If *target_dir* is given, write patches to that directory on the server
    and return filenames (no content).  Otherwise return content for browser
    download.
    """
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    if target_dir:
        import os
        os.makedirs(target_dir, exist_ok=True)
        patches = []
        for i, sha in enumerate(commit_shas, 1):
            try:
                output = subprocess.check_output(
                    ["git", "-C", repo, "format-patch", "-1", sha,
                     "-o", target_dir, f"--start-number={i}"],
                    text=True, stderr=subprocess.DEVNULL, timeout=10,
                ).strip()
                patches.append({"filename": os.path.basename(output)})
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                patches.append({"filename": f"{sha[:12]}.patch",
                                "error": f"Failed to export {sha[:12]}"})
        return {"patches": patches, "target_dir": target_dir}

    patches = [query_export_patch(repo, sha) for sha in commit_shas]
    return {"patches": patches}


def query_rebase_prepare(repo_name: str, project: str,
                         base_override: str = "") -> dict:
    """Create a backup branch for interactive rebase, return base + repo path.

    Used by the web API (locally and via SSH for remote projects).

    *base_override* lets the caller specify a custom rebase base (e.g.
    ``SHA^`` when the user selected a commit range).  When empty the
    upstream tracking ref is used.
    """
    from .branch import get_local_commits
    from .explore import create_rebase_backup
    from ..core import current_branch

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    branch = current_branch(repo)
    if not branch:
        return {"error": "Detached HEAD — cannot rebase"}

    try:
        local_commits, base_ref = get_local_commits(repo, branch)
    except Exception as e:
        return {"error": f"Failed to get local commits: {e}"}

    if not local_commits or not base_ref:
        return {"error": "No local commits to rebase"}

    # Use the caller-supplied base when a commit range was selected.
    # If neither is available, fall back to parent of oldest local commit.
    rebase_base = base_override if base_override else base_ref

    # Always resolve to a concrete SHA so the rebase base won't shift if a
    # symbolic ref (e.g. origin/scarthgap) is updated between now and when
    # the terminal executes the command.  Also normalises SHA^ to the
    # parent's full hash.
    if rebase_base:
        try:
            resolved = subprocess.check_output(
                ["git", "-C", repo, "rev-parse", rebase_base],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            if resolved:
                rebase_base = resolved
        except Exception:
            pass

    # Detect commits git rebase will silently exclude (already upstream)
    from .explore import _count_cherry_picks
    cherry_picked = _count_cherry_picks(repo, rebase_base)

    ok, backup_branch, err = create_rebase_backup(repo, base_ref, branch)
    if not ok:
        return {"error": err}

    result = {
        "ok": True,
        "backup_branch": backup_branch,
        "base": rebase_base,
        "repo_path": repo,
    }
    if cherry_picked > 0:
        result["cherry_picked"] = cherry_picked
    return result


def query_drop_commits(repo_name: str, project: str,
                       commit_shas: list) -> dict:
    """Drop commits with backup branch.

    Used by the web API (locally and via SSH for remote projects).
    """
    from .branch import get_local_commits
    from .explore import drop_commits_with_backup
    from ..core import current_branch

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    branch = current_branch(repo)
    if not branch:
        return {"error": "Detached HEAD — cannot drop commits"}

    try:
        local_commits, base_ref = get_local_commits(repo, branch)
    except Exception as e:
        return {"error": f"Failed to get local commits: {e}"}

    if not local_commits or not base_ref:
        return {"error": "No local commits to drop"}

    # Build (hash, subject) tuples for requested commits, matching by prefix
    commits_to_drop = []
    for sha in commit_shas:
        for h, s in local_commits:
            if h.startswith(sha) or sha.startswith(h):
                commits_to_drop.append((h, s))
                break
    if not commits_to_drop:
        return {"error": "None of the specified commits are local"}

    ok, msg = drop_commits_with_backup(
        repo, commits_to_drop, branch, base_ref, confirm=False)

    if ok:
        backup = ""
        if "Backup:" in msg:
            backup = msg.split("Backup:")[-1].strip()
        return {
            "ok": True,
            "backup_branch": backup,
            "dropped_count": len(commits_to_drop),
            "message": msg,
        }
    else:
        return {"error": msg}


def query_repo_branches(repo_name: str, project: str) -> dict:
    """Return branch list for a repo, current branch first.

    Applies the same stale/priority/exclude filters as the TUI explore view
    (loaded from .bit.defaults).
    """
    from .branch import get_branches_by_recency
    from ..core import current_branch

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    stale_days = defaults.get("__branch_stale_days__", 365)
    priorities = defaults.get("__branch_priorities__", [])
    excludes = defaults.get("__branch_excludes__", [])
    max_age = stale_days * 86400 if stale_days else 0
    branches = get_branches_by_recency(
        repo, max_age_secs=max_age,
        priorities=priorities or None, excludes=excludes or None)
    cur = current_branch(repo) or ""
    return [{"name": b, "current": b == cur} for b in branches]


def query_checkout_branch(repo_name: str, branch: str, project: str) -> dict:
    """Checkout a branch on a repo."""
    from .branch import checkout_branch
    from .common import log_message

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    ok, msg = checkout_branch(repo, branch)
    if ok:
        log_message(f"\u2713 Checked out: {branch}")
    else:
        log_message(f"\u2717 Checkout failed: {branch}")
    return {"ok": ok, "branch": branch, "message": msg}


def query_fetch_repo(repo_name: str, project: str) -> dict:
    """Fetch upstream for a repo."""
    from .update import fetch_repo
    from .common import log_message

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    try:
        fetch_repo(repo)
        log_message(f"\u2713 Fetched: {repo_name}")
    except Exception:
        log_message(f"\u2717 Fetch failed: {repo_name}")
        raise
    return {"ok": True}


def query_update_repo(repo_name: str, action: str, project: str) -> dict:
    """Update (rebase or merge) a repo."""
    from .update import run_single_repo_update
    from ..core import current_branch
    from ..daemon import RepoLock
    from .common import log_message

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    if not action:
        action = defaults.get(repo, "rebase")
    branch = current_branch(repo)

    lock = RepoLock(repo, actor="web")
    if not lock.acquire(blocking=True, timeout=10.0):
        return {"error": f"Repo '{repo_name}' is locked by another process"}

    # Redirect stdout so git/print output doesn't pollute JSON response
    import io, contextlib
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            result = run_single_repo_update(repo, branch, action)
        log_message(f"\u2713 Updated: {repo_name}")
    except Exception:
        log_message(f"\u2717 Update failed: {repo_name}")
        raise
    finally:
        lock.release()
    return {"ok": True, "result": str(result)}


def query_refresh_all(project: str) -> dict:
    """Fetch all repos (non-skip)."""
    from .update import fetch_repo
    from ..daemon import RepoLock
    from .common import log_message

    repos, defaults, *_ = _resolve_repos(project)
    log_message("Refreshing all repos...")
    count = 0
    for repo in repos:
        if defaults.get(repo, "rebase") != "skip":
            lock = RepoLock(repo, actor="web")
            if not lock.acquire(blocking=False):
                continue  # skip locked repos
            try:
                fetch_repo(repo)
                count += 1
            except Exception:
                pass
            finally:
                lock.release()
    log_message(f"\u2713 Refresh complete ({count} repos)")
    return {"ok": True, "count": count}


def query_export_preview(project: str) -> list:
    """Exportable commits per repo.

    Commits are returned **newest-first** (display order), matching
    ``query_repo_commits``.  ``get_local_commits`` returns oldest-first
    so we reverse here.
    """
    from .explore import gather_repo_status

    repos, defaults, repo_layers, *_ = _resolve_repos(project)
    result = []
    for repo in repos:
        info = gather_repo_status(repo, defaults, repo_layers=repo_layers)
        if info["local_count"] > 0:
            result.append({
                "path": repo,
                "display_name": info["display_name"],
                "branch": info["branch"],
                "local_count": info["local_count"],
                "commits": list(reversed(info["commits"])),
                "base_ref": info.get("base_ref", ""),
            })
    return result


def query_export_prepare(project: str, repo_configs: list,
                         branch_name: str = "",
                         force_replace: bool = False,
                         backup: bool = True) -> dict:
    """Prepare repos for export — reorder commits and optionally create branch.

    *repo_configs* is a list of dicts:
        {repo_name, selected_commits: [sha], insertion_point: str}
    """
    from .branch import get_local_commits
    from .export import prepare_repo, create_branch_at_cut_point
    from ..core import current_branch, save_prep_state

    repos, defaults, *_ = _resolve_repos(project)
    results = []
    processed = []  # (repo_path, cut_point) for branch creation / prep state

    for cfg in repo_configs:
        repo_name = cfg.get("repo_name", "")
        selected = cfg.get("selected_commits", [])
        insertion_pt = cfg.get("insertion_point", "")

        repo = _find_repo(repos, repo_name, defaults)
        if not repo:
            results.append({"repo": repo_name, "status": "error",
                            "message": f"Repo not found: {repo_name}"})
            continue

        branch = current_branch(repo)
        if not branch:
            results.append({"repo": repo_name, "status": "error",
                            "message": "Detached HEAD"})
            continue

        try:
            commits, base_ref = get_local_commits(repo, branch)
        except Exception as e:
            results.append({"repo": repo_name, "status": "error",
                            "message": str(e)})
            continue

        if not commits or not base_ref:
            results.append({"repo": repo_name, "status": "error",
                            "message": "No local commits"})
            continue

        if not insertion_pt:
            insertion_pt = base_ref

        ok, msg, cut_point = prepare_repo(
            repo, branch, commits, base_ref, selected,
            insertion_pt, backup)

        entry = {"repo": repo_name, "status": "ok" if ok else "error",
                 "message": msg, "cut_point": cut_point or ""}
        if ok:
            processed.append((repo, cut_point, branch))
        results.append(entry)

    # Create branches if requested
    if branch_name:
        for repo, cut_point, _ in processed:
            if not cut_point:
                continue
            ok, msg = create_branch_at_cut_point(
                repo, branch_name, cut_point, force_replace)
            # Find matching result entry and annotate
            display = os.path.basename(repo)
            for r in results:
                if r["repo"] == display or repo.endswith(r["repo"]):
                    r["branch_message"] = msg
                    r["branch_ok"] = ok
                    break

    # Save prep state
    prep_state_data = {}
    for repo, cut_point, working_branch in processed:
        if cut_point:
            prep_state_data[repo] = {
                "working_branch": working_branch,
                "prep_branch": branch_name or None,
                "cut_point": cut_point,
            }
    prep_saved = False
    if prep_state_data:
        project_path = project or _get_project_path()
        if project_path:
            state_file = os.path.join(project_path, ".bit.prep-state.json")
            save_prep_state(state_file, prep_state_data)
            prep_saved = True

    return {"ok": True, "results": results, "prep_state_saved": prep_saved}


def query_prep_state(project: str) -> dict:
    """Load prep state for a project."""
    from ..core import load_prep_state

    project_path = project or _get_project_path()
    if not project_path:
        return {"repos": {}}

    state_file = os.path.join(project_path, ".bit.prep-state.json")
    data = load_prep_state(state_file)
    if data:
        return data
    return {"repos": {}}


def query_union_branches(project: str) -> dict:
    """Union of branches across all repos with counts."""
    from .branch import collect_union_branches

    repos, defaults, *_ = _resolve_repos(project)
    union = collect_union_branches(repos)
    total = len(repos)
    return [{"name": name, "count": count, "total": total}
            for name, count in union]


def query_branch_all(branch: str, project: str) -> dict:
    """Switch all repos to the same branch."""
    from .branch import checkout_branch
    from .common import log_message
    from ..core import current_branch

    repos, defaults, *_ = _resolve_repos(project)
    results = []
    for repo in repos:
        name = os.path.basename(repo)
        cur = current_branch(repo)
        if cur == branch:
            results.append({"repo": name, "status": "already",
                            "message": f"already on {branch}"})
            continue
        ok, msg = checkout_branch(repo, branch)
        results.append({"repo": name, "status": "ok" if ok else "error",
                         "message": msg})
    log_message(f"\u2713 Switched all to: {branch}")
    return {"results": results}


def query_track_repo(repo_name: str, project: str) -> dict:
    """Track a repo (add to extra repos, unhide)."""
    from .common import add_extra_repo, remove_hidden_repo
    from ..core import load_defaults

    project_path = project or _get_project_path()
    if not project_path:
        return {"error": "No project selected"}
    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    repos, *_ = _resolve_repos(project, discover=True, include_hidden=True)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    add_extra_repo(defaults_file, defaults, repo)
    remove_hidden_repo(defaults_file, defaults, repo)
    from .common import log_message
    log_message(f"\u2713 Tracked: {repo_name}")
    return {"ok": True, "repo": repo_name}


def query_hide_repo(repo_name: str, project: str) -> dict:
    """Hide a repo."""
    from .common import add_hidden_repo
    from ..core import load_defaults

    project_path = project or _get_project_path()
    if not project_path:
        return {"error": "No project selected"}
    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    repos, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    add_hidden_repo(defaults_file, defaults, repo)
    from .common import log_message
    log_message(f"\u2713 Hidden: {repo_name}")
    return {"ok": True, "repo": repo_name}


def query_prune_backups(repo_name: str, project: str) -> dict:
    """Prune backup branches for a repo."""
    from .explore import prune_backup_branches

    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    pruned = prune_backup_branches(repo, max_age_days=0)
    from .common import log_message
    log_message(f"\u2713 Pruned backups: {repo_name}")
    return {"ok": True, "pruned": pruned, "repo": repo_name}


def query_repo_layers(repo_name: str, project: str) -> dict:
    """Return layers for a repo."""
    repos, defaults, repo_layers_map, configured, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}

    layers = repo_layers_map.get(repo, [])
    result = []
    for lp in layers:
        result.append({
            "name": os.path.basename(lp),
            "path": lp,
            "configured": lp in configured,
        })
    return {"layers": result}


def query_add_layer(layer_path: str, project: str) -> dict:
    """Add a layer to bblayers.conf."""
    from .projects import get_current_project
    from ..personas.yocto.layers import add_layer_direct, build_layer_collection_map

    project_path = project or get_current_project()
    if not project_path:
        return {"error": "No active project"}

    bblayers = None
    for cand in ("conf/bblayers.conf", "build/conf/bblayers.conf"):
        full = os.path.join(project_path, cand)
        if os.path.exists(full):
            bblayers = full
            break
    if not bblayers:
        return {"error": "bblayers.conf not found"}

    repos, defaults, repo_layers_map, *_ = _resolve_repos(project, discover=True)
    all_layer_paths = []
    for layer_list in repo_layers_map.values():
        all_layer_paths.extend(layer_list)
    collection_map = build_layer_collection_map(all_layer_paths)

    ok, msg, added = add_layer_direct(layer_path, bblayers, collection_map)
    if ok:
        return {"ok": True, "message": msg, "layers_added": added}
    return {"error": msg}


def query_remove_layer(layer_path: str, project: str) -> dict:
    """Remove a layer from bblayers.conf."""
    from .projects import get_current_project
    from ..personas.yocto.layers import remove_layer_direct

    project_path = project or get_current_project()
    if not project_path:
        return {"error": "No active project"}

    bblayers = None
    for cand in ("conf/bblayers.conf", "build/conf/bblayers.conf"):
        full = os.path.join(project_path, cand)
        if os.path.exists(full):
            bblayers = full
            break
    if not bblayers:
        return {"error": "bblayers.conf not found"}

    ok, msg = remove_layer_direct(layer_path, bblayers)
    if ok:
        return {"ok": True, "message": msg}
    return {"error": msg}


def query_repo_log_by_name(repo_name: str, count: int,
                           project: str) -> dict:
    """Return recent commits for a repo by display name."""
    repos, defaults, *_ = _resolve_repos(project)
    repo = _find_repo(repos, repo_name, defaults)
    if not repo:
        return {"error": f"Repo not found: {repo_name}"}
    return {"commits": query_repo_log(repo, count)}


def query_repo_log(repo: str, count: int = 50) -> list:
    """Return recent commits for a repo path (not name — called directly)."""
    try:
        out = subprocess.check_output(
            ["git", "-C", repo, "log", f"-{count}",
             "--pretty=format:%H%n%an%n%ae%n%ai%n%s"],
            text=True, stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []
    commits = []
    lines = out.strip().split("\n")
    for i in range(0, len(lines), 5):
        if i + 4 >= len(lines):
            break
        commits.append({
            "sha": lines[i],
            "author": lines[i + 1],
            "email": lines[i + 2],
            "date": lines[i + 3],
            "subject": lines[i + 4],
        })
    return commits


def query_messages(project: str) -> dict:
    """Return recent messages from the project message log."""
    from .common import read_message_log

    project_path = project or _get_project_path()
    if not project_path:
        return {"messages": []}
    return {"messages": read_message_log(project_path)}


def _get_project_path():
    """Helper to get current project path."""
    from .projects import get_current_project
    return get_current_project()


# --- Pull patches queries ---

def query_pull_remotes() -> list:
    """Return registered remote projects for pull-patches selection."""
    from .projects import load_projects_for_display
    from .ssh_remote import is_remote_project

    projects = load_projects_for_display()
    remotes = []
    for path, pinfo in projects.items():
        if is_remote_project(pinfo):
            remotes.append({
                "path": path,
                "name": pinfo.get("name", os.path.basename(path)),
                "user": pinfo.get("user", ""),
                "host": pinfo.get("host", ""),
                "remote_path": pinfo.get("remote_path", path),
                "label": f"{pinfo.get('user', '')}@{pinfo.get('host', '')}:{pinfo.get('remote_path', path)}",
            })
    return remotes


def query_pull_match_repo(remote_project: str, local_repo_name: str,
                          project: str) -> dict:
    """SSH to remote project, find repos, try basename match.

    Returns::

        {"matched": bool, "remote_repo": str|None, "branch": str,
         "all_repos": [str, ...], "user": str, "host": str, "port": int}
    """
    from .projects import load_projects
    from .ssh_remote import (is_remote_project, ssh_resolve_address,
                             ssh_check_connection, ssh_get_git_repos,
                             ssh_current_branch)

    projects = load_projects()
    pinfo = projects.get(remote_project, {})
    if not is_remote_project(pinfo):
        return {"error": f"Not a remote project: {remote_project}"}

    user = pinfo.get("user", "")
    host = pinfo.get("host", "")
    remote_path = pinfo.get("remote_path", remote_project)

    address, port = ssh_resolve_address(user, host)
    if not ssh_check_connection(user, address, port=port):
        return {"error": f"Cannot connect to {host}"}

    repos = ssh_get_git_repos(user, address, remote_path, port=port)
    if not repos:
        return {"error": f"No repos found on {host}:{remote_path}"}

    # Try basename match
    local_base = os.path.basename(local_repo_name.rstrip("/"))
    matched_repo = None
    for r in repos:
        if os.path.basename(r.rstrip("/")) == local_base:
            matched_repo = r
            break

    branch = ""
    if matched_repo:
        branch = ssh_current_branch(user, address, matched_repo, port=port) or ""

    return {
        "matched": matched_repo is not None,
        "remote_repo": matched_repo,
        "branch": branch,
        "all_repos": repos,
        "user": user,
        "host": address,
        "port": port,
    }


def query_pull_commits(remote_project: str, remote_repo: str,
                       local_repo_name: str, project: str) -> dict:
    """Get commits the remote has that local doesn't.

    Returns::

        {"commits": [[hash, subject], ...], "local_branch": str,
         "remote_branch": str, "count": int}
    """
    from .projects import load_projects
    from .ssh_remote import (is_remote_project, ssh_resolve_address,
                             ssh_get_commit_log, ssh_current_branch)
    from ..core import current_head

    projects = load_projects()
    pinfo = projects.get(remote_project, {})
    if not is_remote_project(pinfo):
        return {"error": f"Not a remote project: {remote_project}"}

    user = pinfo.get("user", "")
    host = pinfo.get("host", "")
    address, port = ssh_resolve_address(user, host)

    # Resolve local repo
    project_path = project or _get_project_path()
    repos, defaults, *_ = _resolve_repos(project_path)
    local_repo = _find_repo(repos, local_repo_name, defaults)
    if not local_repo:
        return {"error": f"Local repo not found: {local_repo_name}"}

    local_head = current_head(local_repo) or ""
    local_branch_name = ""
    try:
        import subprocess as _sp
        local_branch_name = _sp.check_output(
            ["git", "-C", local_repo, "rev-parse", "--abbrev-ref", "HEAD"],
            text=True, stderr=_sp.DEVNULL, timeout=5
        ).strip()
    except Exception:
        pass

    remote_branch = ssh_current_branch(user, address, remote_repo, port=port) or ""
    commits_raw = ssh_get_commit_log(user, address, remote_repo,
                                     since=local_head, port=port)
    commits = [[h, s] for h, s in commits_raw]

    return {
        "commits": commits,
        "local_branch": local_branch_name,
        "remote_branch": remote_branch,
        "count": len(commits),
    }


def query_pull_apply(remote_project: str, remote_repo: str,
                     local_repo_name: str, commits: list,
                     method: str, project: str) -> dict:
    """Execute import of selected commits.

    Returns ``{"status": "ok"|"error", "message": str}``.
    """
    from .projects import load_projects
    from .ssh_remote import is_remote_project, ssh_resolve_address, ssh_current_branch
    from .common import import_remote_patches, strip_ansi

    projects = load_projects()
    pinfo = projects.get(remote_project, {})
    if not is_remote_project(pinfo):
        return {"status": "error", "message": f"Not a remote project: {remote_project}"}

    user = pinfo.get("user", "")
    host = pinfo.get("host", "")
    address, port = ssh_resolve_address(user, host)

    # Resolve local repo
    project_path = project or _get_project_path()
    repos, defaults, *_ = _resolve_repos(project_path)
    local_repo = _find_repo(repos, local_repo_name, defaults)
    if not local_repo:
        return {"status": "error", "message": f"Local repo not found: {local_repo_name}"}

    branch = ssh_current_branch(user, address, remote_repo, port=port) or ""

    if method == "save":
        target_dir = os.path.expanduser("~/patches/")
        os.makedirs(target_dir, exist_ok=True)
        result = import_remote_patches(user, address, remote_repo, commits,
                                       target_dir, method, port=port)
    else:
        result = import_remote_patches(user, address, remote_repo, commits,
                                       local_repo, method, branch=branch,
                                       port=port)

    clean = strip_ansi(result)
    is_error = "\u2717" in result or "failed" in clean.lower() or "error" in clean.lower()
    return {
        "status": "error" if is_error else "ok",
        "message": clean,
    }


def query_setup_apply_layers(project: str, config_file: str,
                              config_name: str, layers_dir: str = "layers",
                              one_of_choices: dict = None) -> dict:
    """Apply layers and fragments from a .conf.json config to bblayers.conf.

    Uses ``add_layer_to_bblayers()`` with dependency resolution (matching TUI
    ``run_setup_apply``), instead of naive string manipulation.

    Returns ``{"ok": true, "added_layers": [...], "config_name": "..."}``.
    """
    from .confjson import parse_conf_json
    from .common import (add_layer_to_bblayers, build_layer_collection_map,
                         extract_layer_paths, resolve_bblayers_path)

    if not project or not os.path.isdir(project):
        return {"error": "No project selected"}

    if not config_file or not config_name:
        return {"error": "No configuration specified"}

    try:
        conf = parse_conf_json(config_file)
    except Exception as e:
        return {"error": f"Failed to parse config: {e}"}

    selected = None
    for c in conf.configurations:
        if c.name == config_name:
            selected = c
            break
    if not selected:
        return {"error": f"Configuration '{config_name}' not found"}

    saved = os.getcwd()
    try:
        os.chdir(project)
        bblayers_path = os.path.join("build", "conf", "bblayers.conf")

        # Create build dir if needed
        os.makedirs(os.path.join("build", "conf"), exist_ok=True)
        if not os.path.exists(bblayers_path):
            topdir = os.path.abspath(".")
            meta = os.path.join(topdir, layers_dir, "openembedded-core", "meta")
            with open(bblayers_path, "w") as f:
                f.write(f'BBLAYERS ?= " \\\n  {meta} \\\n  "\n')

        # Build collection map from existing + all available layers
        try:
            existing = extract_layer_paths(bblayers_path)
        except SystemExit:
            existing = []

        all_layer_paths = list(existing)
        abs_layers_dir = os.path.abspath(layers_dir)
        if os.path.isdir(abs_layers_dir):
            for root, dirs, files in os.walk(abs_layers_dir):
                if "conf" in dirs:
                    layer_conf = os.path.join(root, "conf", "layer.conf")
                    if os.path.isfile(layer_conf) and root not in all_layer_paths:
                        all_layer_paths.append(root)
                depth = root[len(abs_layers_dir):].count(os.sep)
                if depth >= 3:
                    dirs[:] = []

        collection_map = build_layer_collection_map(all_layer_paths)

        # Add layers using proper dependency resolution
        added_layers = []
        for layer_rel in selected.bb_layers:
            layer_path = os.path.abspath(os.path.join(layers_dir, layer_rel))
            if not os.path.isdir(layer_path):
                continue
            success, msg, layers_added = add_layer_to_bblayers(
                layer_path, bblayers_path, collection_map,
            )
            if success:
                added_layers.append(layer_rel)
                for lp in layers_added:
                    new_map = build_layer_collection_map([lp])
                    collection_map.update(new_map)

        # Apply fragments if any
        fragments_applied = []
        fragments_to_add = list(selected.oe_fragments)

        # Handle one-of choices
        if one_of_choices and selected.oe_fragments_one_of:
            for cat_name, frag_name in one_of_choices.items():
                if frag_name:
                    fragments_to_add.append(frag_name)

        if fragments_to_add:
            try:
                from .fragment import (_update_oe_fragments, _get_toolcfg_path,
                                       DEFAULT_BUILTIN_PREFIXES)
                toolcfg_path = _get_toolcfg_path(bblayers_path)
                _update_oe_fragments(toolcfg_path, fragments_to_add, [],
                                     DEFAULT_BUILTIN_PREFIXES)
                fragments_applied = fragments_to_add
            except (ImportError, OSError):
                pass

        return {
            "ok": True,
            "added_layers": added_layers,
            "config_name": config_name,
            "fragments_applied": fragments_applied,
        }
    except Exception as e:
        return {"error": str(e)}
    finally:
        os.chdir(saved)


def query_setup_export_preview(project: str) -> dict:
    """Gather export data for the current project and return it as JSON.

    Returns project_name, sources, relative_layers, fragments for the
    web UI to render before the user submits an export.
    """
    from .setup import gather_export_data

    if not project or not os.path.isdir(project):
        return {"error": "No project selected"}

    saved = os.getcwd()
    try:
        os.chdir(project)
        data = gather_export_data(layers_dir="layers")
        if data is None:
            return {"error": "Could not gather export data (no bblayers.conf?)"}
        return {
            "project_name": data["project_name"],
            "sources": data["sources"],
            "relative_layers": data["relative_layers"],
            "fragments": data["fragments"],
        }
    except Exception as e:
        return {"error": str(e)}
    finally:
        os.chdir(saved)


def query_setup_export_execute(project: str, name: str,
                                description: str, fragments: list,
                                registry: bool) -> dict:
    """Execute a config export using the proper _write_export() function.

    Returns ``{"ok": true, "path": "...", "registry_path": "..." or null}``.
    """
    import contextlib
    import io
    from .setup import gather_export_data, _write_export

    if not project or not os.path.isdir(project):
        return {"error": "No project selected"}

    saved = os.getcwd()
    try:
        os.chdir(project)
        data = gather_export_data(layers_dir="layers")
        if data is None:
            return {"error": "Could not gather export data (no bblayers.conf?)"}

        # Filter fragments to only those selected by the user
        selected_fragments = [f for f in data["fragments"] if f in fragments]

        output_path = os.path.abspath(f"{name}.conf.json")

        # Capture stdout from _write_export (it prints status messages)
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture):
            _write_export(name, data["sources"], data["relative_layers"],
                          selected_fragments, output_path,
                          to_registry=registry, description=description)

        result = {"ok": True, "path": output_path, "registry_path": None,
                  "message": capture.getvalue().strip()}
        if registry:
            registry_dir = os.path.expanduser("~/.config/bit/registry")
            basename = os.path.basename(output_path)
            if not basename.endswith(".conf.json"):
                basename += ".conf.json"
            result["registry_path"] = os.path.join(registry_dir, basename)
        return result
    except Exception as e:
        return {"error": str(e)}
    finally:
        os.chdir(saved)


# --- Query path dispatch ---

# Patterns: repos, repos/<name>/commits, repos/<name>/commits/<hash>/show,
#           repos/<name>/diff
_REPOS_RE = re.compile(r'^repos$')
_COMMITS_RE = re.compile(r'^repos/([^/]+)/commits$')
_COMMITS_LAYER_RE = re.compile(r'^repos/([^/]+)/commits/layer/(.+)$')
_SHOW_RE = re.compile(r'^repos/([^/]+)/commits/([^/]+)/show$')
_DIFF_RE = re.compile(r'^repos/([^/]+)/diff$')
_LORE_RE = re.compile(r'^repos/([^/]+)/commits/([^/]+)/lore$')
_TREE_RE = re.compile(r'^repos/([^/]+)/tree$')
_FILE_COMMITS_RE = re.compile(r'^repos/([^/]+)/files/(.+)/commits$')
_CHANGED_FILES_RE = re.compile(r'^repos/([^/]+)/commits/([^/]+)/changed-files$')
_BRANCHES_RE = re.compile(r'^repos/([^/]+)/branches$')
_CHECKOUT_RE = re.compile(r'^repos/([^/]+)/checkout/(.+)$')
_FETCH_RE = re.compile(r'^repos/([^/]+)/fetch$')
_UPDATE_RE = re.compile(r'^repos/([^/]+)/update(?:/(.+))?$')
_REFRESH_RE = re.compile(r'^refresh$')
_UNION_BRANCHES_RE = re.compile(r'^repos/branches/union$')
_BRANCH_ALL_RE = re.compile(r'^repos/branch-all/(.+)$')
_TRACK_RE = re.compile(r'^repos/([^/]+)/track$')
_HIDE_RE = re.compile(r'^repos/([^/]+)/hide$')
_PRUNE_RE = re.compile(r'^repos/([^/]+)/prune-backups$')
_REPO_LAYERS_RE = re.compile(r'^repos/([^/]+)/layers$')
_REPO_LOG_RE = re.compile(r'^repos/([^/]+)/log(?:\?count=(\d+))?$')
_ADD_LAYER_RE = re.compile(r'^layers/add/(.+)$')
_REMOVE_LAYER_RE = re.compile(r'^layers/remove/(.+)$')
_REBASE_PREPARE_RE = re.compile(r'^repos/([^/]+)/rebase-prepare(?:/(.+))?$')
_DROP_COMMITS_RE = re.compile(r'^repos/([^/]+)/drop$')
_GRAPH_RE = re.compile(r'^repos/([^/]+)/graph(?:\?count=(\d+))?$')
_EXPORT_SINGLE_PATCHES_RE = re.compile(r'^repos/([^/]+)/export-patches$')
_EXPORT_PREVIEW_RE = re.compile(r'^export/preview$')
_EXPORT_PREPARE_RE = re.compile(r'^export/prepare(?:\?data=(.+))?$')
_EXPORT_PATCHES_RE = re.compile(r'^export/patches$')
_PREP_STATE_RE = re.compile(r'^export/prep-state$')
_MESSAGES_RE = re.compile(r'^messages$')
_FRAGMENTS_RE = re.compile(r'^fragments$')
_FRAGMENTS_ENABLE_RE = re.compile(r'^fragments/enable$')
_FRAGMENTS_DISABLE_RE = re.compile(r'^fragments/disable$')
_FRAGMENTS_BUILTIN_RE = re.compile(r'^fragments/builtin$')


def query_fragments(project: str) -> dict:
    """Return all fragments with enabled/disabled status."""
    from .fragment import (
        _discover_fragments, _parse_enabled_fragments,
        DEFAULT_BUILTIN_PREFIXES, _get_enabled_builtin_values,
        _get_toolcfg_path,
    )
    from ..personas.yocto.bblayers import resolve_bblayers_path, extract_layer_paths

    saved = os.getcwd()
    try:
        if project:
            os.chdir(project)
        bblayers_path = resolve_bblayers_path(None)
        if not bblayers_path:
            return {"error": "No bblayers.conf found"}
        all_layers = extract_layer_paths(bblayers_path)
        toolcfg_path = _get_toolcfg_path(bblayers_path)

        fragments = _discover_fragments(all_layers, progress=False)
        enabled_list = _parse_enabled_fragments(toolcfg_path) if os.path.exists(toolcfg_path) else []
        enabled_builtins = _get_enabled_builtin_values(enabled_list, DEFAULT_BUILTIN_PREFIXES)

        result = []
        for f in fragments:
            result.append({
                "name": f.name,
                "path": f.path,
                "layer": f.layer,
                "domain": f.domain,
                "summary": f.summary,
                "description": f.description,
                "enabled": f.name in enabled_list,
                "is_builtin": f.is_builtin,
            })

        for prefix in DEFAULT_BUILTIN_PREFIXES:
            val = enabled_builtins.get(prefix.prefix, "")
            result.append({
                "name": f"{prefix.prefix}:{prefix.variable}",
                "layer": "",
                "domain": "builtin",
                "summary": f"Current {prefix.variable}: {val}" if val else f"No {prefix.variable} set",
                "description": "",
                "enabled": bool(val),
                "is_builtin": True,
                "builtin_prefix": prefix.prefix,
                "builtin_value": val,
            })
        return result
    finally:
        os.chdir(saved)


def query_fragments_enable(project: str, data: dict) -> dict:
    """Enable a fragment."""
    from .fragment import _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES
    from ..personas.yocto.bblayers import resolve_bblayers_path

    name = data.get("name", "")
    if not name:
        return {"error": "Missing 'name'"}

    saved = os.getcwd()
    try:
        if project:
            os.chdir(project)
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        _update_oe_fragments(toolcfg_path, [name], [], DEFAULT_BUILTIN_PREFIXES)
        return {"ok": True}
    finally:
        os.chdir(saved)


def query_fragments_disable(project: str, data: dict) -> dict:
    """Disable a fragment."""
    from .fragment import _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES
    from ..personas.yocto.bblayers import resolve_bblayers_path

    name = data.get("name", "")
    if not name:
        return {"error": "Missing 'name'"}

    saved = os.getcwd()
    try:
        if project:
            os.chdir(project)
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        _update_oe_fragments(toolcfg_path, [], [name], DEFAULT_BUILTIN_PREFIXES)
        return {"ok": True}
    finally:
        os.chdir(saved)


def query_fragments_builtin(project: str, data: dict) -> dict:
    """Set a builtin prefix value (machine/distro)."""
    from .fragment import _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES
    from ..personas.yocto.bblayers import resolve_bblayers_path

    prefix = data.get("prefix", "")
    value = data.get("value", "")
    if not prefix or not value:
        return {"error": "Missing 'prefix' or 'value'"}

    saved = os.getcwd()
    try:
        if project:
            os.chdir(project)
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        frag_name = f"{prefix}/{value}"
        _update_oe_fragments(toolcfg_path, [frag_name], [], DEFAULT_BUILTIN_PREFIXES)
        return {"ok": True}
    finally:
        os.chdir(saved)


def dispatch_query(path: str, project: str, stdin_data: dict = None) -> dict:
    """Dispatch a query path to the appropriate function."""
    path = path.strip("/")

    m = _REPOS_RE.match(path)
    if m:
        return query_repos(project)

    # Check multi-segment paths before single-segment repo patterns
    # (repos/branches/union must match before repos/<name>/branches)
    m = _UNION_BRANCHES_RE.match(path)
    if m:
        return query_union_branches(project)

    m = _BRANCH_ALL_RE.match(path)
    if m:
        return query_branch_all(m.group(1), project)

    m = _BRANCHES_RE.match(path)
    if m:
        return query_repo_branches(m.group(1), project)

    m = _COMMITS_LAYER_RE.match(path)
    if m:
        return query_repo_commits(m.group(1), project, layer=m.group(2))

    m = _COMMITS_RE.match(path)
    if m:
        return query_repo_commits(m.group(1), project)

    m = _SHOW_RE.match(path)
    if m:
        return query_commit_show(m.group(1), m.group(2), project)

    m = _DIFF_RE.match(path)
    if m:
        return query_repo_diff(m.group(1), project)

    m = _LORE_RE.match(path)
    if m:
        return query_commit_lore(m.group(1), m.group(2), project)

    m = _TREE_RE.match(path)
    if m:
        return query_file_tree(m.group(1), "HEAD", project)

    m = _FILE_COMMITS_RE.match(path)
    if m:
        return query_file_commits(m.group(1), m.group(2), "HEAD", 30,
                                  project)

    m = _CHANGED_FILES_RE.match(path)
    if m:
        return query_commit_changed_files(m.group(1), m.group(2), project)

    m = _CHECKOUT_RE.match(path)
    if m:
        return query_checkout_branch(m.group(1), m.group(2), project)

    m = _FETCH_RE.match(path)
    if m:
        return query_fetch_repo(m.group(1), project)

    m = _UPDATE_RE.match(path)
    if m:
        return query_update_repo(m.group(1), m.group(2) or "", project)

    m = _REFRESH_RE.match(path)
    if m:
        return query_refresh_all(project)

    m = _TRACK_RE.match(path)
    if m:
        return query_track_repo(m.group(1), project)

    m = _HIDE_RE.match(path)
    if m:
        return query_hide_repo(m.group(1), project)

    m = _PRUNE_RE.match(path)
    if m:
        return query_prune_backups(m.group(1), project)

    m = _REPO_LAYERS_RE.match(path)
    if m:
        return query_repo_layers(m.group(1), project)

    m = _REPO_LOG_RE.match(path)
    if m:
        count = int(m.group(2)) if m.group(2) else 50
        return query_repo_log_by_name(m.group(1), count, project)

    m = _ADD_LAYER_RE.match(path)
    if m:
        from urllib.parse import unquote
        return query_add_layer(unquote(m.group(1)), project)

    m = _REMOVE_LAYER_RE.match(path)
    if m:
        from urllib.parse import unquote
        return query_remove_layer(unquote(m.group(1)), project)

    m = _REBASE_PREPARE_RE.match(path)
    if m:
        return query_rebase_prepare(m.group(1), project,
                                    base_override=m.group(2) or "")

    m = _DROP_COMMITS_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "repos/<name>/drop requires POST body (--stdin)"}
        return query_drop_commits(m.group(1), project,
                                  commit_shas=stdin_data.get("commits", []))

    m = _GRAPH_RE.match(path)
    if m:
        count = int(m.group(2)) if m.group(2) else 50
        return query_repo_graph_by_name(m.group(1), count, project)

    m = _EXPORT_SINGLE_PATCHES_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "repos/<name>/export-patches requires POST body (--stdin)"}
        return query_export_patches_by_name(
            m.group(1), stdin_data.get("commits", []), project)

    m = _EXPORT_PREVIEW_RE.match(path)
    if m:
        return query_export_preview(project)

    m = _EXPORT_PREPARE_RE.match(path)
    if m:
        # Prefer stdin_data (from --stdin) over URL-encoded data in path
        if stdin_data:
            data = stdin_data
        else:
            from urllib.parse import unquote
            raw = unquote(m.group(1)) if m.group(1) else "{}"
            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                return {"error": "Invalid JSON in export/prepare data"}
        return query_export_prepare(
            project,
            repo_configs=data.get("repos", []),
            branch_name=data.get("branch_name", ""),
            force_replace=data.get("force_replace", False),
            backup=data.get("backup", True),
        )

    m = _EXPORT_PATCHES_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "export/patches requires POST body (--stdin)"}
        return query_export_patches(
            project,
            repo_requests=stdin_data.get("repos", []),
            numbering=stdin_data.get("numbering", "global"),
            subject_prefix=stdin_data.get("subject_prefix", ""),
            series_version=stdin_data.get("series_version", 0),
            cover_letter=stdin_data.get("cover_letter", True),
            target_dir=stdin_data.get("target_dir", ""),
            layout=stdin_data.get("layout", "flat"),
            keep_content=stdin_data.get("keep_content", False),
        )

    m = _PREP_STATE_RE.match(path)
    if m:
        return query_prep_state(project)

    m = _MESSAGES_RE.match(path)
    if m:
        return query_messages(project)

    m = _FRAGMENTS_RE.match(path)
    if m:
        return query_fragments(project)

    m = _FRAGMENTS_ENABLE_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "fragments/enable requires POST body (--stdin)"}
        return query_fragments_enable(project, stdin_data)

    m = _FRAGMENTS_DISABLE_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "fragments/disable requires POST body (--stdin)"}
        return query_fragments_disable(project, stdin_data)

    m = _FRAGMENTS_BUILTIN_RE.match(path)
    if m:
        if not stdin_data:
            return {"error": "fragments/builtin requires POST body (--stdin)"}
        return query_fragments_builtin(project, stdin_data)

    return {"error": f"Unknown query path: {path}"}


def run_query(args) -> int:
    """CLI entry point for ``bit query <path>``."""
    from .projects import get_current_project

    query_path = args.query_path
    # --project-path takes a raw filesystem path (used by SSH);
    # falls back to the resolved --project flag or current project.
    project = (getattr(args, "project_path", None)
               or getattr(args, "project", None)
               or get_current_project())
    if not project:
        print(json.dumps({"error": "No project selected"}))
        return 1

    # --stdin: read JSON from stdin and attach to dispatch context
    stdin_data = None
    if getattr(args, "stdin", False):
        try:
            stdin_data = json.load(sys.stdin)
        except Exception:
            print(json.dumps({"error": "Failed to read JSON from stdin"}))
            return 1

    result = dispatch_query(query_path, project, stdin_data=stdin_data)
    json.dump(result, sys.stdout, default=str)
    print()  # trailing newline
    return 1 if isinstance(result, dict) and "error" in result else 0
