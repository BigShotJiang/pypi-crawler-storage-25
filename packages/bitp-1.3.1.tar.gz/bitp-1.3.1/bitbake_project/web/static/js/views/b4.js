/* B4/Lore view — search, browse, apply, diff, mbox */
const B4View = {
  _nav: KeyboardNav(),
  _lists: null,
  _mode: 'search',  // 'search' or 'browse'

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'v/Enter', desc: 'View message body'},
    {key: 'a', desc: 'Apply patch'},
    {key: 'd', desc: 'Diff versions'},
    {key: 'm', desc: 'Download mbox'},
    {key: '/', desc: 'Search', action: '/'},
    {key: 'Tab', desc: 'Search/Browse'},
    {key: 'l', desc: 'Focus list picker'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    var row = this._nav.activeRow();
    if ((e.key === 'v' || e.key === 'Enter') && row) {
      e.preventDefault();
      this._toggleDetail(row);
    } else if (e.key === 'a' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-apply');
      if (btn) btn.click();
    } else if (e.key === 'd' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-diff');
      if (btn) btn.click();
    } else if (e.key === 'm' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-mbox');
      if (btn) btn.click();
    } else if (e.key === '/') {
      e.preventDefault();
      var input = document.getElementById('b4-search');
      if (input) input.focus();
    } else if (e.key === 'Tab') {
      e.preventDefault();
      this._toggleMode();
    } else if (e.key === 'l') {
      e.preventDefault();
      var sel = document.getElementById('b4-list');
      if (sel) sel.focus();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>B4 / Lore</h2>
      </div>
      <div class="tab-bar">
        <button class="tab active" data-tab="search">Search</button>
        <button class="tab" data-tab="browse">Browse</button>
      </div>
      <div id="b4-search-panel" class="tab-panel" style="display:block">
        <div class="search-bar">
          <input type="text" id="b4-search" placeholder="Search lore.kernel.org...">
          <button class="btn btn-primary" id="b4-go">Search</button>
        </div>
        <div class="search-bar" style="gap:8px;margin-top:4px;flex-wrap:wrap">
          <label style="color:var(--text-muted);font-size:var(--font-size-sm)">List:</label>
          <select id="b4-list" class="input" style="max-width:220px"><option value="">All</option></select>
          <label style="color:var(--text-muted);font-size:var(--font-size-sm)">Type:</label>
          <select id="b4-type" class="input" style="max-width:120px">
            <option value="subject">Subject</option>
            <option value="body">Body</option>
            <option value="all">All</option>
          </select>
          <label style="color:var(--text-muted);font-size:var(--font-size-sm)">Range:</label>
          <select id="b4-range" class="input" style="max-width:120px">
            <option value="1.week.ago..">1 week</option>
            <option value="1.month.ago..">1 month</option>
            <option value="3.months.ago..">3 months</option>
            <option value="1.year.ago..">1 year</option>
            <option value="2.years.ago.." selected>2 years</option>
          </select>
          <label style="display:flex;align-items:center;gap:4px;color:var(--text-muted);font-size:var(--font-size-sm)">
            <input type="checkbox" id="b4-threads"> Threads
          </label>
        </div>
        <div id="b4-search-results" class="empty-state"><h3>Enter a search term to find patches on lore</h3></div>
      </div>
      <div id="b4-browse-panel" class="tab-panel">
        <div class="search-bar" style="gap:8px">
          <label style="color:var(--text-muted);font-size:var(--font-size-sm)">List:</label>
          <select id="b4-browse-list" class="input" style="max-width:280px"><option value="">Select a mailing list...</option></select>
          <label style="color:var(--text-muted);font-size:var(--font-size-sm)">Days:</label>
          <select id="b4-browse-days" class="input" style="max-width:80px">
            <option value="7">7</option>
            <option value="14" selected>14</option>
            <option value="30">30</option>
          </select>
          <button class="btn btn-primary" id="b4-browse-go">Browse</button>
        </div>
        <div id="b4-browse-results" class="empty-state"><h3>Select a mailing list to browse recent activity</h3></div>
      </div>
    `;

    // Tab switching
    container.querySelectorAll('.tab-bar .tab').forEach(tab => {
      tab.addEventListener('click', () => {
        this._mode = tab.dataset.tab;
        this._updateTabs();
      });
    });

    // Search handlers
    const doSearch = () => this._search();
    document.getElementById('b4-go').addEventListener('click', doSearch);
    document.getElementById('b4-search').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

    // Browse handlers
    document.getElementById('b4-browse-go').addEventListener('click', () => this._browse());
    document.getElementById('b4-browse-list').addEventListener('change', () => this._browse());
    document.getElementById('b4-browse-days').addEventListener('change', () => this._browse());

    // Load mailing lists
    this._loadLists();

    // Cross-view lore search: pre-fill from patches view
    if (App.state.b4SearchQuery) {
      document.getElementById('b4-search').value = App.state.b4SearchQuery;
      App.state.b4SearchQuery = null;
      this._search();
    }
  },

  async _loadLists() {
    try {
      this._lists = await API.b4Lists();
      var opts = this._lists.map(l =>
        `<option value="${esc(l.lore_name)}">${esc(l.lore_name)}${l.description ? ' \u2014 ' + esc(l.description) : ''}</option>`
      ).join('');
      document.getElementById('b4-list').innerHTML = '<option value="">All</option>' + opts;
      document.getElementById('b4-browse-list').innerHTML = '<option value="">Select a mailing list...</option>' + opts;
    } catch (e) {
      // Non-critical — filters just won't have list options
    }
  },

  _updateTabs() {
    document.querySelectorAll('.tab-bar .tab').forEach(t => {
      t.classList.toggle('active', t.dataset.tab === this._mode);
    });
    document.getElementById('b4-search-panel').style.display = this._mode === 'search' ? 'block' : 'none';
    document.getElementById('b4-browse-panel').style.display = this._mode === 'browse' ? 'block' : 'none';
  },

  _toggleMode() {
    this._mode = this._mode === 'search' ? 'browse' : 'search';
    this._updateTabs();
  },

  async _search() {
    const q = document.getElementById('b4-search').value.trim();
    if (!q) return;
    const el = document.getElementById('b4-search-results');
    el.className = 'loading';
    el.textContent = 'Searching lore...';

    var opts = {};
    var list = document.getElementById('b4-list').value;
    var type = document.getElementById('b4-type').value;
    var range = document.getElementById('b4-range').value;
    var threads = document.getElementById('b4-threads').checked;
    if (list) opts.list = list;
    if (type && type !== 'subject') opts.type = type;
    if (range && range !== '2.years.ago..') opts.range = range;
    if (threads) opts.threads = true;

    try {
      const results = await API.b4Search(q, Object.keys(opts).length ? opts : undefined);
      this._renderResults(results, 'b4-search-results');
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Search error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  async _browse() {
    var list = document.getElementById('b4-browse-list').value;
    if (!list) return;
    var days = parseInt(document.getElementById('b4-browse-days').value) || 14;
    var el = document.getElementById('b4-browse-results');
    el.className = 'loading';
    el.textContent = 'Loading recent messages...';

    try {
      var results = await API.b4Browse(list, days);
      this._renderResults(results, 'b4-browse-results');
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Browse error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _renderResults(results, containerId) {
    const el = document.getElementById(containerId);
    if (!results || !results.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No results</h3></div>';
      return;
    }

    el.className = '';
    el.innerHTML = `<table class="data-table">
      <thead><tr><th>Subject</th><th>From</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>${results.map((r, i) => {
        const subject = r.subject || r.title || '';
        const from = r.from || r.author || '';
        const date = r.date || '';
        const msgid = r.msgid || r.message_id || '';
        const url = r.url || '';
        const content = r.content || '';
        return `<tr data-idx="${i}" data-msgid="${esc(msgid)}" data-url="${esc(url)}" style="cursor:pointer">
          <td>${esc(subject)}</td>
          <td style="color:var(--text-muted)">${esc(from)}</td>
          <td style="color:var(--text-muted);white-space:nowrap">${esc(date)}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-primary b4-apply" data-msgid="${esc(msgid)}" title="Apply patch">Apply</button>
            <button class="btn b4-diff" data-msgid="${esc(msgid)}" title="Diff versions">Diff</button>
            <button class="btn b4-mbox" data-msgid="${esc(msgid)}" title="Download mbox">Mbox</button>
          </td>
        </tr>
        <tr class="b4-detail" data-for="${i}" style="display:none">
          <td colspan="4" style="padding:0">
            <pre class="b4-body" style="margin:0;padding:12px 16px;background:var(--bg-secondary);border-top:1px solid var(--border);white-space:pre-wrap;word-break:break-word;font-size:var(--font-size-sm);max-height:400px;overflow:auto">${content ? esc(content) : 'Click to load message body...'}</pre>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;

    // Keyboard nav — only on main rows, skip detail rows
    this._nav.setRows(el.querySelectorAll('tbody tr:not(.b4-detail)'));

    // Row click → toggle detail
    el.querySelectorAll('tr[data-idx]').forEach(row => {
      row.addEventListener('click', (e) => {
        // Don't toggle when clicking buttons
        if (e.target.closest('button')) return;
        this._toggleDetail(row);
      });
    });

    // Apply buttons
    el.querySelectorAll('.b4-apply').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Applying: ${btn.dataset.msgid}`);
        try {
          await API.b4Apply(btn.dataset.msgid);
          App.showToast('Apply started \u2014 see terminal', 'success');
        } catch (e) {
          App.showToast(e.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Diff buttons
    el.querySelectorAll('.b4-diff').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Diffing: ${btn.dataset.msgid}`);
        try {
          await API.b4Diff(btn.dataset.msgid);
          App.showToast('Diff started \u2014 see terminal', 'success');
        } catch (e) {
          App.showToast(e.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Mbox buttons
    el.querySelectorAll('.b4-mbox').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        try {
          var res = await API.b4Mbox(btn.dataset.msgid);
          App.showToast(`Mbox saved to ${res.path}`, 'success');
        } catch (e) {
          App.showToast(e.message, 'error');
        }
        btn.disabled = false;
      });
    });
  },

  async _toggleDetail(row) {
    var idx = row.dataset.idx;
    if (!idx) return;
    var detailRow = row.parentElement.querySelector(`.b4-detail[data-for="${idx}"]`);
    if (!detailRow) return;

    var isVisible = detailRow.style.display !== 'none';
    if (isVisible) {
      detailRow.style.display = 'none';
      return;
    }

    detailRow.style.display = '';
    var body = detailRow.querySelector('.b4-body');

    // If already loaded full body, just show
    if (body.dataset.loaded) return;

    // Fetch full message body from lore
    var msgid = row.dataset.msgid;
    var url = row.dataset.url;
    body.textContent = 'Loading message...';
    try {
      var msg = await API.b4Message(msgid, url);
      var text = '';
      if (msg.headers) {
        var hdrOrder = ['From', 'To', 'Cc', 'Subject', 'Date', 'Message-Id', 'In-Reply-To', 'List-Id'];
        hdrOrder.forEach(h => {
          if (msg.headers[h]) text += h + ': ' + msg.headers[h] + '\n';
        });
        text += '\n';
      }
      text += msg.body || '(no body)';
      body.textContent = text;
      body.dataset.loaded = '1';
    } catch (e) {
      body.textContent = 'Failed to load message: ' + e.message;
    }
  },

};
