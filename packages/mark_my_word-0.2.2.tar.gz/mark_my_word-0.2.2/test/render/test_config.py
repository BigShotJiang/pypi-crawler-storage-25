"""Tests for mark_my_word.config."""

import pytest

from mark_my_word.render.config import extract_title, merge_config, resolve_output_path, strip_first_h1


class TestMergeConfig:
    def test_applies_defaults(self):
        assert merge_config({}, {}, {})["subtitle"] == ""

    def test_global_overrides_defaults(self):
        assert merge_config({"subtitle": "Global"}, {}, {})["subtitle"] == "Global"

    def test_frontmatter_overrides_global(self):
        assert merge_config({"subtitle": "Global"}, {"subtitle": "Doc"}, {})["subtitle"] == "Doc"

    def test_set_flags_override_frontmatter(self):
        assert merge_config({}, {"author": "Alice"}, {"author": "Bob"})["author"] == "Bob"

    def test_set_flags_add_new_keys(self):
        assert merge_config({}, {}, {"company": "Acme"})["company"] == "Acme"


class TestExtractTitle:
    def test_uses_frontmatter_title(self, tmp_path):
        assert extract_title({"title": "FM Title"}, "<h1>H1</h1>", tmp_path / "doc.md") == "FM Title"

    def test_falls_back_to_h1(self, tmp_path):
        assert extract_title({}, "<h1>Body Title</h1>", tmp_path / "doc.md") == "Body Title"

    def test_strips_inner_tags_from_h1(self, tmp_path):
        assert extract_title({}, "<h1><em>Styled</em></h1>", tmp_path / "doc.md") == "Styled"

    def test_falls_back_to_filename_stem(self, tmp_path):
        assert extract_title({}, "<p>no heading</p>", tmp_path / "my-document.md") == "my-document"

    def test_frontmatter_takes_precedence_over_h1(self, tmp_path):
        assert extract_title({"title": "FM"}, "<h1>H1</h1>", tmp_path / "doc.md") == "FM"


class TestStripFirstH1:
    def test_removes_first_h1(self):
        html = "<h1>Title</h1>\n<p>Body</p>"
        assert strip_first_h1(html) == "<p>Body</p>"

    def test_leaves_body_intact_when_no_h1(self):
        html = "<p>Body</p>"
        assert strip_first_h1(html) == "<p>Body</p>"

    def test_removes_only_first_h1(self):
        html = "<h1>First</h1>\n<p>Body</p>\n<h1>Second</h1>"
        result = strip_first_h1(html)
        assert "First" not in result
        assert "Second" in result

    def test_handles_h1_with_attributes(self):
        html = '<h1 id="my-title">Title</h1>\n<p>Body</p>'
        assert "Title" not in strip_first_h1(html)


class TestResolveOutputPath:
    def test_uses_input_stem_when_none(self, tmp_path):
        assert resolve_output_path(None, tmp_path / "doc.md") == tmp_path / "doc.pdf"

    def test_uses_stem_for_existing_dir(self, tmp_path):
        out_dir = tmp_path / "out"
        out_dir.mkdir()
        assert resolve_output_path(out_dir, tmp_path / "doc.md") == out_dir / "doc.pdf"

    def test_dir_without_trailing_slash_same_as_with(self, tmp_path):
        assert resolve_output_path(tmp_path, tmp_path / "doc.md") == tmp_path / "doc.pdf"

    def test_explicit_file_path_returned_as_is(self, tmp_path):
        out = tmp_path / "custom.pdf"
        assert resolve_output_path(out, tmp_path / "doc.md") == out

    def test_fails_when_parent_does_not_exist(self, tmp_path):
        with pytest.raises(ValueError, match="output directory does not exist"):
            resolve_output_path(tmp_path / "missing" / "out.pdf", tmp_path / "doc.md")


