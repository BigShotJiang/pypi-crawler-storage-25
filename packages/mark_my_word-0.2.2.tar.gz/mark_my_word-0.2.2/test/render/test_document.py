"""Tests for mark_my_word.document."""

from mark_my_word.render.document import parse, to_html

# ── parse ─────────────────────────────────────────────────────────────────────

def test_parse_extracts_frontmatter_fields(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("---\ntitle: Hello\nauthor: Dan\n---\n\nBody text.")
    meta, body = parse(f)
    assert meta["title"] == "Hello"
    assert meta["author"] == "Dan"
    assert "Body text." in body


def test_parse_returns_empty_dict_when_no_frontmatter(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("Just a paragraph.")
    meta, body = parse(f)
    assert meta == {}
    assert "Just a paragraph." in body


def test_parse_body_excludes_frontmatter_keys(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("---\ntitle: T\n---\n\nContent.")
    _, body = parse(f)
    assert "title:" not in body


# ── more separator ────────────────────────────────────────────────────────────

def test_parse_strips_content_before_more_separator(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("@tags(work)\n\n<!--more-->\n\n# Real content")
    _, body = parse(f)
    assert "@tags" not in body
    assert "# Real content" in body


def test_parse_keeps_full_body_when_no_more_separator(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("# Title\n\nBody text.")
    _, body = parse(f)
    assert "# Title" in body
    assert "Body text." in body


def test_parse_more_separator_works_with_frontmatter(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("---\ntitle: T\n---\n\n@tags\n\n<!--more-->\n\nActual body.")
    _, body = parse(f)
    assert "@tags" not in body
    assert "Actual body." in body



def test_parse_more_separator_must_be_on_own_line(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("text <!--more--> still preamble\n\nBody.")
    _, body = parse(f)
    assert "text <!--more-->" in body


# ── to_html ───────────────────────────────────────────────────────────────────

def test_to_html_renders_paragraph():
    html = to_html("Hello world.")
    assert "<p>Hello world.</p>" in html


def test_to_html_renders_heading():
    html = to_html("# My Title")
    assert "<h1" in html
    assert "My Title" in html


def test_to_html_renders_fenced_code_block():
    html = to_html("```python\nprint('hi')\n```")
    assert "<code" in html
    assert "print" in html


def test_to_html_renders_table():
    html = to_html("| A | B |\n|---|---|\n| 1 | 2 |")
    assert "<table" in html
    assert "<td" in html


def test_to_html_renders_strikethrough():
    html = to_html("~~struck~~")
    assert "<s>" in html or "strikethrough" in html or "del" in html
