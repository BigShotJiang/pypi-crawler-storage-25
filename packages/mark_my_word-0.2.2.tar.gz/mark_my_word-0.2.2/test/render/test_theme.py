"""Tests for mark_my_word.theme."""

import pytest

from mark_my_word.render.theme import Theme, assemble_html, load, substitute


def _minimal_theme(first_header=None, cont_header=None,
                   first_footer=None, cont_footer=None) -> Theme:
    return Theme(
        css="body {}",
        first_header=first_header,
        cont_header=cont_header,
        first_footer=first_footer,
        cont_footer=cont_footer,
    )


# ── substitute ────────────────────────────────────────────────────────────────

def test_substitute_replaces_known_key():
    assert substitute("Hello {{name}}!", {"name": "World"}) == "Hello World!"


def test_substitute_replaces_multiple_keys():
    result = substitute("{{title}} by {{author}}", {"title": "Doc", "author": "Dan"})
    assert result == "Doc by Dan"


def test_substitute_raises_on_unknown_key():
    with pytest.raises(KeyError):
        substitute("{{unknown}}", {})


def test_substitute_ignores_extra_vars():
    result = substitute("{{title}}", {"title": "T", "extra": "X"})
    assert result == "T"


def test_substitute_leaves_single_braces_untouched():
    result = substitute("div { color: red; } {{title}}", {"title": "T"})
    assert "div { color: red; }" in result
    assert result.endswith("T")


# ── load ─────────────────────────────────────────────────────────────────────

def test_load_reads_css_from_theme_directory(tmp_path):
    (tmp_path / "style.css").write_text("body { color: red; }")
    theme = load(tmp_path)
    assert "color: red" in theme.css


def test_load_optional_fragments_are_none_when_absent(tmp_path):
    (tmp_path / "style.css").write_text("")
    theme = load(tmp_path)
    assert theme.first_header is None
    assert theme.cont_footer is None


def test_load_reads_html_fragments_when_present(tmp_path):
    (tmp_path / "style.css").write_text("")
    (tmp_path / "first-header.html").write_text("<div>Header</div>")
    (tmp_path / "cont-footer.html").write_text("<div>Footer</div>")
    theme = load(tmp_path)
    assert theme.first_header == "<div>Header</div>"
    assert theme.cont_footer == "<div>Footer</div>"


class TestLoadFallback:
    def test_header_used_for_both_slots_when_named_files_absent(self, tmp_path):
        (tmp_path / "style.css").write_text("")
        (tmp_path / "header.html").write_text("<div>H</div>")
        theme = load(tmp_path)
        assert theme.first_header == "<div>H</div>"
        assert theme.cont_header == "<div>H</div>"

    def test_footer_used_for_both_slots_when_named_files_absent(self, tmp_path):
        (tmp_path / "style.css").write_text("")
        (tmp_path / "footer.html").write_text("<div>F</div>")
        theme = load(tmp_path)
        assert theme.first_footer == "<div>F</div>"
        assert theme.cont_footer == "<div>F</div>"

    def test_named_file_takes_precedence_over_fallback(self, tmp_path):
        (tmp_path / "style.css").write_text("")
        (tmp_path / "header.html").write_text("<div>Generic</div>")
        (tmp_path / "first-header.html").write_text("<div>Specific</div>")
        theme = load(tmp_path)
        assert theme.first_header == "<div>Specific</div>"
        assert theme.cont_header == "<div>Generic</div>"


def test_load_patches_watermark_url_into_css(tmp_path):
    (tmp_path / "style.css").write_text("--watermark-url: url('placeholder');")
    (tmp_path / "watermark.png").write_bytes(b"\x89PNG\r\n")
    theme = load(tmp_path)
    assert "data:image/png;base64," in theme.css
    assert "placeholder" not in theme.css


# ── assemble_html ─────────────────────────────────────────────────────────────

def test_assemble_html_includes_body_content(tmp_path):
    theme = _minimal_theme()
    html = assemble_html("<p>Content</p>", theme, {}, tmp_path)
    assert "<p>Content</p>" in html


def test_assemble_html_includes_theme_css(tmp_path):
    theme = _minimal_theme()
    html = assemble_html("", theme, {}, tmp_path)
    assert "<style>body {}</style>" in html


def test_substitute_uses_default_when_key_missing():
    assert substitute("{{name: World}}", {}) == "World"


def test_substitute_prefers_var_over_default():
    assert substitute("{{name: fallback}}", {"name": "actual"}) == "actual"


def test_substitute_default_trims_whitespace():
    assert substitute("{{name:  The Grand Circus  }}", {}) == "The Grand Circus"


def test_substitute_raises_when_no_default_and_key_missing():
    with pytest.raises(KeyError):
        substitute("{{unknown}}", {})


def test_substitute_is_case_insensitive():
    result = substitute("{{Title}}", {"title": "T"})
    assert result == "T"


def test_assemble_html_substitutes_variables_in_fragments(tmp_path):
    theme = _minimal_theme(first_header="<div>{{title}}</div>")
    html = assemble_html("", theme, {"title": "My Doc"}, tmp_path)
    assert "<div>My Doc</div>" in html


def test_assemble_html_absent_fragments_leave_no_placeholders(tmp_path):
    theme = _minimal_theme()
    html = assemble_html("", theme, {}, tmp_path)
    assert "{title}" not in html
