"""Tests for mark_my_word.render."""

from pathlib import Path

import pytest

from mark_my_word import render

_ADCB_MD    = Path.home() / "Downloads" / "ADCB.md"
_GOALWARDS_DOTX = (
    Path(__file__).parent.parent.parent.parent
    / "goalwards-themes" / "mark-my-word" / "resources" / "Goalwards letter.dotx"
)


class TestRunValidation:
    def test_fails_without_theme_or_template(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        with pytest.raises(ValueError, match="theme_path or template_path"):
            render.run(md)

    def test_fails_with_both_theme_and_template(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        (tmp_path / "style.css").write_text("body {}")
        with pytest.raises(ValueError, match="mutually exclusive"):
            render.run(md, theme_path=tmp_path, template_path=tmp_path / "t.dotx")

    def test_fails_with_save_theme_but_no_template(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        (tmp_path / "style.css").write_text("body {}")
        with pytest.raises(ValueError, match="--save-theme requires --template"):
            render.run(md, theme_path=tmp_path, save_theme=tmp_path / "out")


class TestRunWithTemplate:
    def test_save_theme_is_populated_from_template(self, tmp_path):
        from docx import Document
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        dotx = tmp_path / "test.dotx"
        Document().save(str(dotx))
        save_dir = tmp_path / "saved-theme"

        out = render.run(md, template_path=dotx, save_theme=save_dir)

        assert (save_dir / "style.css").exists()
        assert out.exists()
        assert out.read_bytes()[:4] == b"%PDF"

    def test_template_without_save_theme_produces_pdf(self, tmp_path):
        from docx import Document
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        dotx = tmp_path / "test.dotx"
        Document().save(str(dotx))

        out = render.run(md, template_path=dotx)

        assert out.exists()
        assert out.read_bytes()[:4] == b"%PDF"

    def test_save_theme_fails_when_target_is_non_empty(self, tmp_path):
        from docx import Document
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        dotx = tmp_path / "test.dotx"
        Document().save(str(dotx))
        save_dir = tmp_path / "dirty"
        save_dir.mkdir()
        (save_dir / "existing.txt").write_text("old")

        with pytest.raises(ValueError, match="save-theme directory is not empty"):
            render.run(md, template_path=dotx, save_theme=save_dir)

    def test_save_theme_fails_when_parent_does_not_exist(self, tmp_path):
        from docx import Document
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        dotx = tmp_path / "test.dotx"
        Document().save(str(dotx))

        with pytest.raises(ValueError, match="save-theme parent directory does not exist"):
            render.run(md, template_path=dotx, save_theme=tmp_path / "missing" / "theme")


class TestOutputNaming:
    def _make_theme(self, path):
        path.mkdir()
        (path / "style.css").write_text("body {}")
        return path

    def test_explicit_file_path_used_exactly(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        theme = self._make_theme(tmp_path / "theme")
        out = tmp_path / "result.pdf"

        result = render.run(md, theme_path=theme, output=out)

        assert result == out

    def test_no_output_uses_input_stem(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        theme = self._make_theme(tmp_path / "theme")

        result = render.run(md, theme_path=theme)

        assert result == tmp_path / "doc.pdf"

    def test_dir_output_uses_input_stem(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        theme = self._make_theme(tmp_path / "theme")
        out_dir = tmp_path / "out"
        out_dir.mkdir()

        result = render.run(md, theme_path=theme, output=out_dir)

        assert result == out_dir / "doc.pdf"

    def test_refuses_to_overwrite_existing_file(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        theme = self._make_theme(tmp_path / "theme")
        (tmp_path / "doc.pdf").write_bytes(b"old")

        with pytest.raises(FileExistsError):
            render.run(md, theme_path=theme)

    def test_force_overwrites_existing_file(self, tmp_path):
        md = tmp_path / "doc.md"
        md.write_text("# Hello")
        theme = self._make_theme(tmp_path / "theme")
        (tmp_path / "doc.pdf").write_bytes(b"old")

        result = render.run(md, theme_path=theme, force=True)

        assert result.read_bytes()[:4] == b"%PDF"


class TestSymlinkInput:
    def test_output_named_after_symlink_not_target(self, tmp_path):
        target = tmp_path / "target.md"
        target.write_text("# Hello")
        link = tmp_path / "link.md"
        link.symlink_to(target)
        (tmp_path / "style.css").write_text("body {}")

        out = render.run(link, theme_path=tmp_path)

        assert out.stem.startswith("link")
        assert "target" not in out.name


class TestGoalwardsIntegration:
    def test_title_from_h1_substituted_and_stripped_from_body(self, tmp_path):
        if not _ADCB_MD.exists():
            pytest.skip("ADCB.md not available")
        (tmp_path / "style.css").write_text("body {}")
        (tmp_path / "first-header.html").write_text(
            '<div class="header-first">{{title}}</div>'
        )
        out = render.run(_ADCB_MD, theme_path=tmp_path,
                         output=tmp_path / "out.pdf", save_html=True)
        html = out.with_suffix(".html").read_text()

        assert out.read_bytes()[:4] == b"%PDF"
        assert "Goalwards engagement proposal" in html   # title substituted into header
        assert "<h1" not in html                       # H1 stripped from body
        assert "ADCB proposal" not in html             # preamble discarded by <!--more-->

    def test_renders_with_goalwards_template(self, tmp_path):
        if not _ADCB_MD.exists():
            pytest.skip("ADCB.md not available")
        if not _GOALWARDS_DOTX.exists():
            pytest.skip("Goalwards template not available")
        out = render.run(_ADCB_MD, template_path=_GOALWARDS_DOTX,
                         output=tmp_path / "out.pdf")
        assert out.exists()
        assert out.read_bytes()[:4] == b"%PDF"


class TestToPdf:
    def test_produces_output_file(self, tmp_path):
        output = tmp_path / "out.pdf"
        render.to_pdf(
            html="<html><body><p>Hello</p></body></html>",
            base_url=tmp_path,
            output_path=output,
        )
        assert output.exists()
        assert output.stat().st_size > 0

    def test_output_starts_with_pdf_magic_bytes(self, tmp_path):
        output = tmp_path / "out.pdf"
        render.to_pdf(
            html="<html><body><p>Hello</p></body></html>",
            base_url=tmp_path,
            output_path=output,
        )
        assert output.read_bytes()[:4] == b"%PDF"
