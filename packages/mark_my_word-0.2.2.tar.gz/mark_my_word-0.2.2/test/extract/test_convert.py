"""Tests for word2theme.convert."""

import itertools

import pytest
from docx import Document
from docx.oxml import parse_xml
from docx.oxml.ns import qn

from mark_my_word.extract import convert

# ── Builder helpers ───────────────────────────────────────────────────────────

@pytest.fixture
def counter():
    return itertools.count(1)


def _header_with_text(text: str):
    """Return a document section header containing a single paragraph."""
    doc = Document()
    section = doc.sections[0]
    section.different_first_page_header_footer = False
    hdr = section.header
    hdr.paragraphs[0].text = text
    return hdr


def _header_with_tab_paragraph(left: str, right: str):
    """Return a header with a paragraph containing left TAB right."""
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.clear()
    para.add_run(left)
    para.add_run("\t")
    para.add_run(right)
    return hdr


def _header_empty():
    doc = Document()
    hdr = doc.sections[0].header
    for para in hdr.paragraphs:
        for run in para.runs:
            run.text = ""
    return hdr


def _inject_field_run(para, field_instr: str):
    """Add a PAGE/NUMPAGES instrText run to a paragraph via raw XML."""
    instr_xml = (
        f'<w:r xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f'<w:instrText xml:space="preserve"> {field_instr} </w:instrText>'
        f'</w:r>'
    )
    para._element.append(parse_xml(instr_xml))


def _hdr_with_table(rows: int, cols: int, cell_texts: list[str] | None = None):
    """Build a header containing a table (no other paragraphs)."""
    doc = Document()
    hdr = doc.sections[0].header
    hdr_elem = hdr._element  # CT_HdrFtr — IS the body, no .body child

    for p in hdr_elem.findall(qn("w:p")):
        hdr_elem.remove(p)

    table = doc.add_table(rows=rows, cols=cols)
    tbl_elem = table._element
    doc.element.body.remove(tbl_elem)
    hdr_elem.append(tbl_elem)

    if cell_texts:
        flat = [cell for row in table.rows for cell in row.cells]
        for cell, text in zip(flat, cell_texts):
            cell.paragraphs[0].text = text

    return hdr


# ── Empty fragment ────────────────────────────────────────────────────────────

def test_empty_header_returns_none_and_empty_images(counter):
    hdr = _header_empty()
    html, images = convert.fragment_to_html(hdr, counter)
    assert html is None
    assert images == {}


# ── Plain text ────────────────────────────────────────────────────────────────

def test_plain_text_is_wrapped_in_p(counter):
    hdr = _header_with_text("Hello World")
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "Hello World" in html
    assert "<p" in html


def test_html_special_characters_are_escaped(counter):
    hdr = _header_with_text("A & B <test>")
    html, _ = convert.fragment_to_html(hdr, counter)
    assert "&amp;" in html
    assert "&lt;" in html


# ── Tab-split → flex-row ─────────────────────────────────────────────────────

def test_tab_paragraph_produces_flex_row(counter):
    hdr = _header_with_tab_paragraph("Left Content", "Right Content")
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert 'class="flex-row"' in html
    assert "Left Content" in html
    assert "Right Content" in html


def test_tab_paragraph_flex_row_contains_two_spans(counter):
    hdr = _header_with_tab_paragraph("Brand", "Page")
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html.count("<span>") == 2


# ── PAGE / NUMPAGES fields ────────────────────────────────────────────────────

def test_page_field_produces_page_number_span(counter):
    doc = Document()
    para = doc.sections[0].header.paragraphs[0]
    para.clear()
    _inject_field_run(para, "PAGE")
    html, _ = convert.fragment_to_html(doc.sections[0].header, counter)
    assert html is not None
    assert 'class="page-number"' in html


def test_numpages_field_produces_page_count_span(counter):
    doc = Document()
    para = doc.sections[0].header.paragraphs[0]
    para.clear()
    _inject_field_run(para, "NUMPAGES")
    html, _ = convert.fragment_to_html(doc.sections[0].header, counter)
    assert html is not None
    assert 'class="page-count"' in html


# ── Table → flex-row ─────────────────────────────────────────────────────────

def test_single_row_two_col_table_becomes_flex_row(counter):
    hdr = _hdr_with_table(1, 2, ["Left", "Right"])
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert 'class="flex-row"' in html
    assert "Left" in html
    assert "Right" in html


def test_multi_row_table_becomes_html_table(counter):
    hdr = _hdr_with_table(2, 2)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "<table>" in html


# ── Paragraph bottom border ──────────────────────────────────────────────────

def _inject_para_border(para, color: str = "4AA38B", sz: int = 6, space: int = 1):
    """Add a bottom border to para via raw XML injection into w:pPr."""
    ppr = para._element.find(qn("w:pPr"))
    if ppr is None:
        ppr_xml = '<w:pPr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'
        ppr = parse_xml(ppr_xml)
        para._element.insert(0, ppr)
    bdr_xml = (
        f'<w:pBdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f'<w:bottom w:val="single" w:sz="{sz}" w:space="{space}" w:color="{color}"/>'
        f'</w:pBdr>'
    )
    ppr.append(parse_xml(bdr_xml))


def test_para_with_bottom_border_emits_border_style(counter):
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.add_run("Header text")
    _inject_para_border(para, color="4AA38B", sz=6, space=1)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "border-bottom" in html


def test_empty_para_border_uses_margin_bottom_for_space_after(counter):
    """w:spacing > w:after on the empty paragraph should become margin-bottom, not padding."""
    from docx.oxml import parse_xml as _px
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    _inject_para_border(para, space=0)  # space=0 so no padding-bottom from border itself
    # Inject w:spacing w:after="240" (12pt) into pPr
    ppr = para._element.find(qn("w:pPr"))
    if ppr is None:
        ppr = _px('<w:pPr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>')
        para._element.insert(0, ppr)
    ppr.append(_px('<w:spacing xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:after="240"/>'))
    html, _ = convert.fragment_to_html(hdr, counter)
    assert "12.0pt" in html          # space-after expressed as margin
    assert "padding-bottom" not in html


def test_empty_para_with_border_emits_border_element(counter):
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    # no text added — paragraph stays empty
    _inject_para_border(para, color="4AA38B", sz=6, space=1)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "border-bottom" in html


def test_para_border_uses_correct_color(counter):
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.add_run("Header text")
    _inject_para_border(para, color="CC2200", sz=4, space=2)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert "#CC2200" in html or "cc2200" in html.lower()


def test_style_level_border_is_extracted(counter):
    """Border defined on the paragraph style (not paragraph) should be extracted."""
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.add_run("Header text")
    # Inject border into the style's pPr instead of the paragraph's pPr
    style_elem = para.style._element
    ppr = style_elem.find(qn("w:pPr"))
    if ppr is None:
        from docx.oxml import parse_xml as _px
        ppr = _px('<w:pPr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>')
        style_elem.append(ppr)
    bdr_xml = (
        '<w:pBdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:bottom w:val="single" w:sz="6" w:space="1" w:color="336699"/>'
        '</w:pBdr>'
    )
    ppr.append(parse_xml(bdr_xml))
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "border-bottom" in html


# ── Paragraph top border ─────────────────────────────────────────────────────

def _inject_para_top_border(para, color: str = "4AA38B", sz: int = 6, space: int = 1):
    ppr = para._element.find(qn("w:pPr"))
    if ppr is None:
        ppr = parse_xml('<w:pPr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>')
        para._element.insert(0, ppr)
    bdr_xml = (
        f'<w:pBdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f'<w:top w:val="single" w:sz="{sz}" w:space="{space}" w:color="{color}"/>'
        f'</w:pBdr>'
    )
    ppr.append(parse_xml(bdr_xml))


def test_para_with_top_border_emits_border_top_style(counter):
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.add_run("Header text")
    _inject_para_top_border(para, color="4AA38B", sz=6, space=1)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert html is not None
    assert "border-top" in html


def test_para_top_border_uses_correct_color(counter):
    doc = Document()
    hdr = doc.sections[0].header
    para = hdr.paragraphs[0]
    para.add_run("Header text")
    _inject_para_top_border(para, color="CC2200", sz=4, space=2)
    html, _ = convert.fragment_to_html(hdr, counter)
    assert "#CC2200" in html or "cc2200" in html.lower()


# ── Image counter ─────────────────────────────────────────────────────────────

def test_image_counter_increments_across_calls():
    counter = itertools.count(1)
    assert next(counter) == 1
    assert next(counter) == 2
