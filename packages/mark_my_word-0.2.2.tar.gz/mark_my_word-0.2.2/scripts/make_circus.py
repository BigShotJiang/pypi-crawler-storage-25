#!/usr/bin/env python3
"""Generate circus example .dotx variants and extract their themes.

Run from the repo root:
    uv run python scripts/make_circus.py

Variants generated inside examples/circus/:
    circus-everything/     — first-page header/footer, cont header/footer, watermark
    circus-header-footer/  — same header/footer on all pages, no watermark
    circus-cont-header/    — cont header only, no watermark
    circus-watermark/      — watermark only, no headers/footers
"""

import io
import shutil
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor

from mark_my_word.extract.doc import load_doc
from mark_my_word import extract

ROOT   = Path(__file__).parent.parent
CIRCUS = ROOT / "examples" / "circus"

BASE      = CIRCUS / "base.dotx"
WATERMARK = CIRCUS / "watermark.dotx"

RED   = "CC2200"
COBALT = "003F8A"
FONT  = "Trebuchet MS"

HEADER_LEFT = "The Grand Circus"
FOOTER_TEXT = "Roll up! Roll up! • Guaranteed to Astound • Est. 1842"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _rgb(hex6: str) -> RGBColor:
    return RGBColor(int(hex6[0:2], 16), int(hex6[2:4], 16), int(hex6[4:6], 16))


def _set_font(run, size_pt: float, bold=False, color_hex: str | None = None):
    run.font.name = FONT
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    if color_hex:
        run.font.color.rgb = _rgb(color_hex)


def _add_field(para, field_type: str):
    for fld_type, tag in [("begin", None), (None, field_type), ("end", None)]:
        run = OxmlElement("w:r")
        el = OxmlElement("w:fldChar" if fld_type else "w:instrText")
        if fld_type:
            el.set(qn("w:fldCharType"), fld_type)
        else:
            el.set(qn("xml:space"), "preserve")
            el.text = f" {tag} "
        run.append(el)
        para._p.append(run)


def _tab_header(header, left_text: str):
    para = header.add_paragraph()
    para.paragraph_format.tab_stops.add_tab_stop(Mm(165), WD_ALIGN_PARAGRAPH.RIGHT)
    run = para.add_run(left_text)
    _set_font(run, 10, bold=True, color_hex=RED)
    tab = OxmlElement("w:r")
    tab.append(OxmlElement("w:tab"))
    para._p.append(tab)
    _add_field(para, "PAGE")
    sep = para.add_run(" / ")
    _set_font(sep, 10, color_hex=RED)
    _add_field(para, "NUMPAGES")


def _centered_footer(footer, text: str):
    para = footer.paragraphs[0]
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run(text)
    _set_font(run, 8, color_hex=COBALT)


def _apply_styles(doc: Document):
    normal = doc.styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(11)
    normal.font.color.rgb = _rgb(COBALT)

    specs = [
        (1, 22, True,  False, RED),
        (2, 18, False, False, RED),
        (3, 14, True,  False, COBALT),
        (4, 12, False, True,  COBALT),
        (5, 11, False, False, COBALT),
        (6, 11, False, False, COBALT),
    ]
    for level, size, bold, italic, color in specs:
        try:
            style = doc.styles[f"Heading {level}"]
            style.font.name = FONT
            style.font.size = Pt(size)
            style.font.bold = bold
            style.font.italic = italic
            style.font.color.rgb = _rgb(color)
        except KeyError:
            pass


def _save_as_dotx(doc: Document, path: Path) -> None:
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    out = io.BytesIO()
    with zipfile.ZipFile(buf, "r") as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "[Content_Types].xml":
                data = data.replace(
                    b"wordprocessingml.document.main+xml",
                    b"wordprocessingml.template.main+xml",
                )
            zout.writestr(item, data)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(out.getvalue())


# ── Variants ──────────────────────────────────────────────────────────────────

def build_everything(out_dir: Path) -> Path:
    doc = load_doc(WATERMARK)
    _apply_styles(doc)
    section = doc.sections[0]
    section.different_first_page_header_footer = True

    first_para = section.first_page_header.add_paragraph()
    first_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = first_para.add_run(HEADER_LEFT)
    _set_font(run, 12, bold=True, color_hex=RED)

    _centered_footer(section.first_page_footer, FOOTER_TEXT)
    _tab_header(section.header, HEADER_LEFT)
    _centered_footer(section.footer, FOOTER_TEXT)

    path = out_dir / "circus-everything.dotx"
    _save_as_dotx(doc, path)
    return path


def build_header_footer(out_dir: Path) -> Path:
    doc = load_doc(BASE)
    _apply_styles(doc)
    section = doc.sections[0]
    section.different_first_page_header_footer = False
    _tab_header(section.header, HEADER_LEFT)
    _centered_footer(section.footer, FOOTER_TEXT)
    path = out_dir / "circus-header-footer.dotx"
    _save_as_dotx(doc, path)
    return path


def build_cont_header(out_dir: Path) -> Path:
    doc = load_doc(BASE)
    _apply_styles(doc)
    section = doc.sections[0]
    section.different_first_page_header_footer = False
    _tab_header(section.header, HEADER_LEFT)
    path = out_dir / "circus-cont-header.dotx"
    _save_as_dotx(doc, path)
    return path


def build_watermark(out_dir: Path) -> Path:
    doc = load_doc(WATERMARK)
    _apply_styles(doc)
    path = out_dir / "circus-watermark.dotx"
    _save_as_dotx(doc, path)
    return path


# ── Main ──────────────────────────────────────────────────────────────────────

VARIANTS = [
    ("circus-everything",    build_everything),
    ("circus-header-footer", build_header_footer),
    ("circus-cont-header",   build_cont_header),
    ("circus-watermark",     build_watermark),
]

if __name__ == "__main__":
    for name, builder in VARIANTS:
        variant_dir = CIRCUS / name
        if variant_dir.exists():
            shutil.rmtree(variant_dir)
        variant_dir.mkdir(parents=True)

        print(f"\n{'='*60}\n  {name}\n{'='*60}")
        dotx = builder(variant_dir)
        print(f"  wrote {dotx.relative_to(ROOT)}")
        extract.run(dotx, variant_dir / "theme")
