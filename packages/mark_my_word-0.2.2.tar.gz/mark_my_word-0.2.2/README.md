# mark-my-word

You have a Word template — the right fonts, colours, headers, footers. You have a Markdown file you want to print. `mark-my-word` connects the two: it reads your Word template and uses it to render your Markdown as a styled PDF.

## Is this for me?

It's a good fit if:

- You have a `.docx` or `.dotx` Word template with the styling you want
- You want your PDFs to match that template without manual CSS work
- You're happy running a command-line tool

It's probably not for you if you need pixel-perfect fidelity to complex Word layouts (tables with merged cells, tracked changes, etc.) or if you need to render Word documents directly — this tool works with Markdown input.

## Install

```shell
uv tool install mark-my-word
# or
pipx install mark-my-word
```

Requires Python 3.11+. WeasyPrint (the PDF engine) needs some system libraries — see the [WeasyPrint docs](https://doc.courtbouillon.org/weasyprint/stable/first_steps.html#installation) if the install fails.

## Basic usage

### Step 1 — extract a theme from your Word template

```shell
mark-my-word extract my-template.dotx --output themes/my-theme/
```

This reads your Word template and writes a theme directory containing a stylesheet and HTML fragments for your headers and footers. You only need to do this once (or whenever your template changes).

### Step 2 — render your Markdown to PDF

```shell
mark-my-word render document.md --theme themes/my-theme/
```

Output lands next to the input file by default (`document.pdf`). Use `--output` to put it somewhere else:

```shell
mark-my-word render document.md --theme themes/my-theme/ --output /tmp/document.pdf
```

If the output file already exists, the command refuses rather than silently overwriting. Use `--force` (or `-f`) to overwrite:

```shell
mark-my-word render document.md --theme themes/my-theme/ --force
```

### Or do it in one step

If you don't want to keep the extracted theme around, you can pass the Word template directly:

```shell
mark-my-word render document.md --template my-template.dotx
```

The theme is extracted on the fly and discarded. Add `--save-theme themes/my-theme/` if you change your mind later.

## Document frontmatter

Headers and footers in your theme can include placeholders like `{{title}}` or `{{author}}`. You can also supply a fallback: `{{title: Untitled}}` is used when `title` is not set. Matching is case-insensitive.

Set values in your Markdown file's YAML frontmatter:

```markdown
---
title: Q1 Report
author: Daniel
---

# Introduction

...
```

Pass extra values on the command line with `--set`:

```shell
mark-my-word render document.md --theme themes/my-theme/ --set version=draft
```

## Skipping preamble

If you write notes in an app like NotePlan, there's often metadata at the top — tags, links, app-specific syntax — that you don't want in the PDF. Put `<!--more-->` on its own line to mark where your real content starts:

```markdown
@project(Quarterly Review)
[[linked-note]]

<!--more-->

# Q1 Report

...
```

Everything before `<!--more-->` is ignored. Everything after renders normally. If `<!--more-->` appears inside a code block in the body, put a second one at the top of the document to act as the separator instead.

## What gets extracted

From your Word template, `mark-my-word extract` pulls:

- Page margins
- Theme colours → CSS custom properties (`--color-body`, `--color-heading`, etc.)
- Base font and heading styles (H1–H6)
- Header and footer content, including tab-separated left/right layouts, page numbers, and paragraph borders (top and bottom)
- Watermark images

The result is a plain directory you can inspect and edit. The stylesheet uses CSS custom properties throughout, so tweaking colours or fonts is a one-line change.

## Theme directory layout

```
themes/my-theme/
  style.css           required
  header.html         header on all pages (or cont-header.html / first-header.html)
  footer.html         footer on all pages (or cont-footer.html / first-footer.html)
  watermark.png       optional full-page background image
```

If your Word template has a different header on the first page, `extract` writes `first-header.html` and `cont-header.html` separately. `render` handles both layouts automatically.

## Options

```
mark-my-word render --help
mark-my-word extract --help
```

## Changelog

### 0.2.2

- README updated with 0.2.1 changes (should have shipped with the release)

### 0.2.1

- Paragraph borders (top and bottom) in Word headers and footers are now extracted and rendered with correct spacing
- Empty paragraphs used as horizontal rules extract at natural line height, matching Word's visual spacing
- Footer height estimation fixed: `<p>` elements inside flex-row cells are no longer counted as separate lines, preventing over-large body margins
- Page break orphan/widow protection relaxed from 3 lines to 2

### 0.2.0

- First-page header/footer fallback: if no distinct first-page fragments exist, the running header/footer is used on all pages
- `<!--more-->` preamble separator support
- `{{variable: default}}` syntax for fragment placeholders
- H1 extracted as document title and removed from body when no `title:` frontmatter is set
- `--force` flag to overwrite existing output files
- Watermark extraction from Word VML `<w:pict>` elements

## Links

- [Repository](https://gitlab.com/tastapod/mark-my-word)
- [Issue tracker](https://gitlab.com/tastapod/mark-my-word/-/issues)
