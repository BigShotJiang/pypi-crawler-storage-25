"""mark-my-word CLI — render Markdown to PDF, or extract a theme from a Word template."""

from pathlib import Path

import click

from . import extract, render


def _parse_set_flags(set_flags: tuple[str, ...]) -> dict:
    result = {}
    for item in set_flags:
        if "=" not in item:
            raise click.UsageError(f"--set requires KEY=VALUE, got: {item!r}")
        k, _, v = item.partition("=")
        result[k.strip()] = v.strip()
    return result


@click.group()
def cli() -> None:
    """Convert Markdown to PDF, or extract a theme from a Word template."""


@cli.command()
@click.argument("input", type=click.Path(exists=True, path_type=Path))
@click.option("--theme", "theme_path", default=None, type=click.Path(file_okay=False, path_type=Path),
              help="Theme directory")
@click.option("--template", "template_path", default=None, type=click.Path(exists=True, path_type=Path),
              help="Word template (.docx/.dotx); extract theme on the fly")
@click.option("--save-theme", default=None, type=click.Path(path_type=Path),
              help="With --template: persist extracted theme to this directory")
@click.option("--out", "--output", "output", default=None, type=click.Path(path_type=Path),
              help="Output PDF path or directory (default: alongside input)")
@click.option("--set", "set_flags", metavar="KEY=VALUE", multiple=True, help="Set a template variable (repeatable)")
@click.option("--save-html", is_flag=True, help="Save intermediate HTML alongside the PDF")
@click.option("--force", "-f", is_flag=True, help="Overwrite output file if it already exists")
def render_cmd(input: Path, theme_path: Path | None, template_path: Path | None,
               save_theme: Path | None, output: Path | None,
               set_flags: tuple[str, ...], save_html: bool, force: bool) -> None:
    """Render INPUT (Markdown) to a PDF using a theme or Word template."""
    if not theme_path and not template_path:
        raise click.UsageError("one of --theme or --template is required")
    if theme_path and template_path:
        raise click.UsageError("--theme and --template are mutually exclusive")
    if save_theme and not template_path:
        raise click.UsageError("--save-theme requires --template")
    set_vars = _parse_set_flags(set_flags)
    try:
        output_path = render.run(input, theme_path, template_path, save_theme, output, set_vars, save_html, force)
    except FileExistsError as e:
        raise click.UsageError(str(e)) from e
    except ValueError as e:
        raise click.UsageError(str(e)) from e
    click.echo(f"Written: {output_path}")
    if save_html:
        click.echo(f"HTML saved: {output_path.with_suffix('.html')}")


@cli.command()
@click.argument("template", type=click.Path(exists=True, path_type=Path))
@click.option("--output", required=True, type=click.Path(file_okay=False, path_type=Path),
              help="Output theme directory")
def extract_cmd(template: Path, output: Path) -> None:
    """Extract a theme from TEMPLATE (.docx or .dotx) into OUTPUT directory."""
    if template.suffix.lower() not in (".docx", ".dotx"):
        raise click.BadParameter(f"expected .docx or .dotx, got: {template.suffix}", param_hint="'TEMPLATE'")
    extract.run(template.resolve(), output.resolve())
