"""Word document loading and style extraction."""

import io
import zipfile
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

_EMU_PER_MM = 36000  # 1 mm = 36000 EMU
_THEME_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"

_DEFAULT_COLORS = {
    "color_body":        "#1d3742",
    "color_heading":     "#4AA38B",
    "color_blockquote":  "#04A68A",
    "color_link":        "#89AAD3",
    "color_footer":      "rgba(29, 55, 66, 0.5)",
    "color_rule":        "rgba(29, 55, 66, 0.3)",
}


def load_doc(path: Path) -> Document:
    """Load a .docx or .dotx file (same OOXML format, python-docx handles both)."""
    if path.suffix.lower() == ".dotx":
        buf = io.BytesIO()
        with zipfile.ZipFile(path, "r") as zin, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename == "[Content_Types].xml":
                    data = data.replace(
                        b"wordprocessingml.template.main+xml",
                        b"wordprocessingml.document.main+xml",
                    )
                zout.writestr(item, data)
        buf.seek(0)
        return Document(buf)
    return Document(str(path))


def extract_margins(doc: Document) -> dict:
    """Return page margin values in mm from the first section.

    Includes top/right/bottom/left for body content, plus footer_dist — the
    distance from the page bottom edge to the footer, used to position the
    running footer correctly in the @page margin box.
    """
    section = doc.sections[0]

    def emu_to_mm(emu) -> float:
        if emu is None:
            return 0.0
        return round(int(emu) / _EMU_PER_MM, 1)

    footer_dist = emu_to_mm(section.footer_distance) or 12.7  # default 0.5 in
    return {
        "top":         emu_to_mm(section.top_margin),
        "right":       emu_to_mm(section.right_margin),
        "bottom":      emu_to_mm(section.bottom_margin),
        "left":        emu_to_mm(section.left_margin),
        "footer_dist": footer_dist,
    }


def extract_colors(doc: Document) -> dict:
    """Extract colours from the Word theme XML.

    Maps Word theme slots to CSS custom property names.
    Falls back to _DEFAULT_COLORS if theme XML is absent or incomplete.
    """
    raw = _parse_theme_colors(doc)
    if not raw:
        return dict(_DEFAULT_COLORS)

    dk1 = raw.get("dk1", "")
    colors: dict[str, str] = {}

    colors["color_body"]       = _hex(dk1) if dk1 else _DEFAULT_COLORS["color_body"]
    colors["color_heading"]    = _hex(raw.get("accent1", "")) or _DEFAULT_COLORS["color_heading"]
    colors["color_blockquote"] = _hex(raw.get("accent2", "")) or _DEFAULT_COLORS["color_blockquote"]
    colors["color_link"]       = _hex(raw.get("accent3", "")) or _DEFAULT_COLORS["color_link"]

    if dk1:
        r, g, b = _hex_to_rgb(dk1)
        colors["color_footer"] = f"rgba({r}, {g}, {b}, 0.5)"
        colors["color_rule"]   = f"rgba({r}, {g}, {b}, 0.3)"
    else:
        colors["color_footer"] = _DEFAULT_COLORS["color_footer"]
        colors["color_rule"]   = _DEFAULT_COLORS["color_rule"]

    return colors


def extract_fonts(doc: Document) -> dict:
    """Return {font_base} from the Normal paragraph style."""
    try:
        normal = doc.styles["Normal"]
        name = normal.font.name
        if name:
            return {"font_base": name}
    except (KeyError, AttributeError):
        pass
    return {"font_base": "Helvetica Neue"}


def extract_heading_styles(doc: Document) -> list[dict]:
    """Return one dict per heading level (1–6) with resolved style values."""
    results = []
    for level in range(1, 7):
        style_name = f"Heading {level}"
        try:
            style = doc.styles[style_name]
        except KeyError:
            results.append(_default_heading(level))
            continue
        results.append(_resolve_heading(style, level))
    return results


def extract_named_styles(doc: Document) -> dict:
    """Extract properties of named paragraph styles used in headers/footers.

    Currently extracts 'Title'. Returns a dict keyed by lower-case style name,
    each value being a dict with size_pt, color, border_bottom_pt, border_color,
    border_space, and space_after_pt where present.
    """
    result = {}
    for style in doc.styles:
        if style.name in ("Title",):
            result[style.name.lower()] = _extract_para_style_props(style)
    return result


def _extract_para_style_props(style) -> dict:
    """Return a dict of CSS-relevant properties from a paragraph style element."""
    elem = style._element
    props: dict = {}

    rpr = elem.find(qn("w:rPr"))
    if rpr is not None:
        sz = rpr.find(qn("w:sz"))
        if sz is not None:
            try:
                props["size_pt"] = int(sz.get(qn("w:val"), "24")) // 2
            except ValueError:
                pass
        color_elem = rpr.find(qn("w:color"))
        if color_elem is not None:
            val = color_elem.get(qn("w:val"), "")
            if val and val.upper() not in ("AUTO", ""):
                props["color"] = f"#{val.upper()}"

    ppr = elem.find(qn("w:pPr"))
    if ppr is not None:
        pbdr = ppr.find(qn("w:pBdr"))
        if pbdr is not None:
            bottom = pbdr.find(qn("w:bottom"))
            if bottom is not None:
                try:
                    # w:sz is in 1/8 pt; divide by 16 so a typical sz=8 hairline
                    # maps to 0.5pt CSS (matching other separator lines in the template).
                    props["border_bottom_pt"] = int(bottom.get(qn("w:sz"), "8")) / 16
                except ValueError:
                    pass
                bc = bottom.get(qn("w:color"), "")
                if bc and bc.upper() not in ("AUTO", ""):
                    props["border_color"] = f"#{bc.upper()}"
                try:
                    props["border_space"] = int(bottom.get(qn("w:space"), "4"))
                except ValueError:
                    pass
        spacing = ppr.find(qn("w:spacing"))
        if spacing is not None:
            after = spacing.get(qn("w:after"), "")
            if after:
                try:
                    props["space_after_pt"] = int(after) / 20
                except ValueError:
                    pass

    return props


def _parse_theme_colors(doc: Document) -> dict:
    """Return raw hex strings keyed by Word theme slot name (e.g. 'accent1')."""
    try:
        theme_part = doc.part.theme_color_map
        if theme_part:
            return theme_part
    except AttributeError:
        pass

    try:
        theme_rel = next(
            (r for r in doc.part.rels.values() if "theme" in r.reltype.lower()),
            None,
        )
        if theme_rel is None:
            return {}
        theme_elem = theme_rel.target_part._element
        result = {}
        for slot in ("dk1", "lt1", "dk2", "lt2",
                     "accent1", "accent2", "accent3",
                     "accent4", "accent5", "accent6"):
            theme_elem.find(
                f".//{{{_THEME_NS}}}srgbClr",
                namespaces={"a": _THEME_NS},
            )
            clr_scheme = theme_elem.find(f".//{{{_THEME_NS}}}clrScheme")
            if clr_scheme is None:
                break
            slot_elem = clr_scheme.find(f"{{{_THEME_NS}}}{slot}")
            if slot_elem is None:
                continue
            srgb = slot_elem.find(f"{{{_THEME_NS}}}srgbClr")
            if srgb is not None:
                result[slot] = srgb.get("val", "")
                continue
            sys_clr = slot_elem.find(f"{{{_THEME_NS}}}sysClr")
            if sys_clr is not None:
                result[slot] = sys_clr.get("lastClr", "")
        return result
    except Exception:
        return {}


def _resolve_heading(style, level: int) -> dict:
    """Walk the style inheritance chain to resolve font size, colour, weight."""
    size_pt = bold = italic = color_hex = space_before = space_after = None

    current = style
    while current is not None:
        font = current.font
        pf   = current.paragraph_format

        if size_pt is None and font.size:
            size_pt = round(font.size.pt, 1)
        if bold is None and font.bold is not None:
            bold = font.bold
        if italic is None and font.italic is not None:
            italic = font.italic
        if color_hex is None and font.color and font.color.type is not None:
            try:
                color_hex = f"#{str(font.color.rgb).upper()}"
            except Exception:
                pass
        if space_before is None and pf.space_before:
            space_before = round(pf.space_before.pt, 1)
        if space_after is None and pf.space_after:
            space_after = round(pf.space_after.pt, 1)

        current = getattr(current, "base_style", None)

    defaults = _default_heading(level)
    return {
        "level":        level,
        "size_pt":      size_pt      or defaults["size_pt"],
        "bold":         bold         if bold is not None else defaults["bold"],
        "italic":       italic       if italic is not None else defaults["italic"],
        "color_hex":    color_hex    or None,
        "space_before": space_before or defaults["space_before"],
        "space_after":  space_after  or defaults["space_after"],
    }


def _default_heading(level: int) -> dict:
    defaults = {
        1: {"size_pt": 18, "bold": True,  "italic": False, "space_before": 20, "space_after": 6},
        2: {"size_pt": 16, "bold": False, "italic": False, "space_before": 16, "space_after": 6},
        3: {"size_pt": 14, "bold": False, "italic": False, "space_before": 12, "space_after": 6},
        4: {"size_pt": 12, "bold": False, "italic": True,  "space_before":  8, "space_after": 4},
        5: {"size_pt": 11, "bold": False, "italic": False, "space_before":  6, "space_after": 4},
        6: {"size_pt": 11, "bold": False, "italic": False, "space_before":  6, "space_after": 4},
    }
    d = defaults[level]
    return {"level": level, "color_hex": None, **d}


def _hex(value: str) -> str:
    """Normalise a 6-char hex string to #rrggbb, or return '' if invalid."""
    v = value.strip().lstrip("#")
    return f"#{v.upper()}" if len(v) == 6 else ""


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    v = value.strip().lstrip("#")
    return int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16)
