"""convert.py — Word XML → HTML conversion for headers and footers.

Converts a python-docx header/footer object to an HTML string suitable
for use as a theme fragment. Images are extracted as bytes and returned
alongside the HTML so callers can write them to disk.
"""


import html
import itertools
from typing import Iterator

from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph

# VML namespace for background/watermark image extraction
_VML_NS  = "urn:schemas-microsoft-com:vml"
_RELS_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

# ── Public API ───────────────────────────────────────────────────────────────

def extract_background_image(section_part) -> tuple[bytes, str, float, float] | None:
    """Extract a VML background/watermark image from a header or footer part.

    Looks for a <w:pict> element containing a <v:imagedata r:id="..."> and
    retrieves the image bytes and the shape's rendered dimensions.

    Returns (image_bytes, content_type, width_pt, height_pt) or None.
    The width/height are the VML shape dimensions (in pt) which control how
    large the watermark should appear on the page.
    """
    element = section_part._element
    body = element.body if hasattr(element, "body") else element
    for pict in body.iter(qn("w:pict")):
        shape = pict.find(f"{{{_VML_NS}}}shape")
        w_pt, h_pt = 0.0, 0.0
        if shape is not None:
            w_pt, h_pt = _parse_vml_dimensions(shape.get("style", ""))
        for imagedata in pict.iter(f"{{{_VML_NS}}}imagedata"):
            r_id = imagedata.get(f"{{{_RELS_NS}}}id")
            if r_id and r_id in section_part.part.rels:
                try:
                    img_part = section_part.part.rels[r_id].target_part
                    return img_part.blob, img_part.content_type, w_pt, h_pt
                except Exception:
                    pass
    return None


def _parse_vml_dimensions(style: str) -> tuple[float, float]:
    """Parse width and height in pt from a VML style string.

    e.g. 'width:1035pt;height:1035pt;...' → (1035.0, 1035.0).
    Returns (0.0, 0.0) if not found or unparseable.
    """
    import re
    w = h = 0.0
    m = re.search(r"width\s*:\s*([\d.]+)pt", style)
    if m:
        w = float(m.group(1))
    m = re.search(r"height\s*:\s*([\d.]+)pt", style)
    if m:
        h = float(m.group(1))
    return w, h


def fragment_to_html(
    section_part,
    image_counter: itertools.count,
) -> tuple[str | None, dict[str, bytes]]:
    """Convert a Word header or footer to an HTML string.

    Args:
        section_part: A python-docx _Header or _Footer object.
        image_counter: Shared counter for generating unique image filenames.

    Returns:
        (html_string, {filename: image_bytes}).
        Returns (None, {}) if the fragment contains no visible content.
    """
    images: dict[str, bytes] = {}
    parts: list[str] = []

    for block in _iter_blocks(section_part):
        if isinstance(block, Paragraph):
            chunk = _paragraph_to_html(block, section_part, image_counter, images)
            if chunk:
                parts.append(chunk)
        elif isinstance(block, Table):
            chunk = _table_to_html(block, section_part, image_counter, images)
            if chunk:
                parts.append(chunk)

    if not parts:
        return None, {}

    return "\n".join(parts), images


# ── Block iteration ──────────────────────────────────────────────────────────

def _iter_blocks(section_part) -> Iterator[Paragraph | Table]:
    """Yield Paragraph and Table objects from a header/footer body."""
    body = section_part._element.body if hasattr(section_part._element, "body") else section_part._element
    for child in body:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
        if tag == "p":
            yield Paragraph(child, section_part)
        elif tag == "tbl":
            yield Table(child, section_part)


# ── Paragraph conversion ─────────────────────────────────────────────────────

_ALIGN_MAP = {"center": "center", "right": "right", "both": "justify"}


def _para_align(para: Paragraph) -> str | None:
    """Return CSS text-align value from paragraph justification, or None."""
    ppr = para._element.find(qn("w:pPr"))
    if ppr is None:
        return None
    jc = ppr.find(qn("w:jc"))
    if jc is None:
        return None
    return _ALIGN_MAP.get(jc.get(qn("w:val"), ""))


def _para_style_class(para: Paragraph) -> str | None:
    """Return a CSS class derived from the paragraph's Word style name, or None.

    Converts the Word style name to kebab-case with a 'para-' prefix:
    'Title' → 'para-title', 'Heading 1' → 'para-heading-1'.
    Returns None for paragraphs with no explicit style.
    """
    ppr = para._element.find(qn("w:pPr"))
    if ppr is None:
        return None
    ps = ppr.find(qn("w:pStyle"))
    if ps is None:
        return None
    val = ps.get(qn("w:val"), "")
    if not val:
        return None
    return f"para-{val.lower().replace(' ', '-')}"


def _para_border(para: Paragraph, side: str) -> str | None:
    """Return a CSS border string for the given side ('top' or 'bottom'), or None.

    Checks paragraph-level w:pBdr first, then walks the paragraph style chain.
    """
    elem = _find_para_border_elem(para._element, side)
    if elem is None:
        try:
            style = para.style
            while style is not None:
                elem = _find_para_border_elem(style._element, side)
                if elem is not None:
                    break
                style = style.base_style
        except Exception:
            pass
    if elem is None:
        return None
    return _border_elem_to_css(elem, side)


def _find_para_border_elem(elem, side: str):
    """Return the w:<side> element inside w:pBdr inside w:pPr of elem, or None."""
    ppr = elem.find(qn("w:pPr"))
    if ppr is None:
        return None
    bdr = ppr.find(qn("w:pBdr"))
    if bdr is None:
        return None
    return bdr.find(qn(f"w:{side}"))


def _border_elem_to_css(elem, side: str) -> str:
    """Convert a w:top/w:bottom element to a CSS border string."""
    color = elem.get(qn("w:color"), "auto")
    if color == "auto" or not color:
        color = "currentColor"
    else:
        color = f"#{color.upper()}"
    sz_str = elem.get(qn("w:sz"), "4")
    try:
        width_pt = int(sz_str) / 8
    except (ValueError, TypeError):
        width_pt = 0.5
    space_str = elem.get(qn("w:space"), "0")
    try:
        padding_pt = int(space_str)
    except (ValueError, TypeError):
        padding_pt = 0
    pad_side = "bottom" if side == "bottom" else "top"
    style = f"border-{side}: {width_pt}pt solid {color};"
    if padding_pt:
        style += f" padding-{pad_side}: {padding_pt}pt;"
    return style


def _para_bottom_border(para: Paragraph) -> str | None:
    return _para_border(para, "bottom")


def _para_space_after_pt(para: Paragraph) -> float:
    return _para_spacing_pt(para, "after")


def _para_space_before_pt(para: Paragraph) -> float:
    return _para_spacing_pt(para, "before")


def _para_spacing_pt(para: Paragraph, attr: str) -> float:
    """Return w:spacing > w:{attr} in pt, walking the style chain, or 0 if absent."""
    def _from_elem(elem) -> float | None:
        ppr = elem.find(qn("w:pPr"))
        if ppr is None:
            return None
        spacing = ppr.find(qn("w:spacing"))
        if spacing is None:
            return None
        raw = spacing.get(qn(f"w:{attr}"))
        if raw is None:
            return None
        try:
            return int(raw) / 20
        except (ValueError, TypeError):
            return None

    result = _from_elem(para._element)
    if result is not None:
        return result
    try:
        style = para.style
        while style is not None:
            result = _from_elem(style._element)
            if result is not None:
                return result
            style = style.base_style
    except Exception:
        pass
    return 0.0


def _strip_padding(css: str | None) -> str | None:
    """Remove padding-* declarations from a CSS string."""
    if not css:
        return css
    import re
    return re.sub(r"\s*padding-\w+:\s*[\d.]+pt;?", "", css).strip() or None


def _paragraph_to_html(
    para: Paragraph,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    """Convert a paragraph to HTML.

    A paragraph containing a tab character is treated as a two-column
    flex row (left content | right content). Otherwise it becomes a <p>.
    """
    # Collect inline content, splitting on tab runs
    segments = _collect_segments(para, parent, image_counter, images)
    border_top    = _para_border(para, "top")
    border_bottom = _para_border(para, "bottom")

    if not segments:
        # Empty paragraph: only emit if it carries a border (Word "horizontal line" pattern).
        # The gap above a bottom border comes from the paragraph's natural line height — Word
        # renders the empty line at full line height, border at the bottom. Don't force height: 0.
        borders = " ".join(filter(None, [border_top, border_bottom]))
        if borders:
            space_after = _para_space_after_pt(para)
            extra = f" margin-bottom: {space_after}pt;" if space_after > 0 else ""
            return f'<p style="{borders}{extra}"></p>'
        return ""

    # Split into left/right on the first tab segment
    tab_idx = next((i for i, s in enumerate(segments) if s == "\t"), None)
    if tab_idx is not None:
        left_html  = "".join(segments[:tab_idx]).strip()
        right_html = "".join(segments[tab_idx + 1:]).strip()
        if left_html or right_html:
            borders = " ".join(filter(None, [border_top, border_bottom]))
            style = f' style="{borders}"' if borders else ""
            return (
                f'<div class="flex-row"{style}>'
                f"<span>{left_html}</span>"
                f"<span>{right_html}</span>"
                f"</div>"
            )
        return ""

    inner = "".join(segments).strip()
    if not inner:
        return ""
    align = _para_align(para)
    style_class = _para_style_class(para)
    cls   = f' class="{style_class}"' if style_class else ""
    style_parts = []
    if align:
        style_parts.append(f"text-align: {align};")
    space_before = _para_space_before_pt(para)
    space_after  = _para_space_after_pt(para)
    if space_before > 0:
        style_parts.append(f"margin-top: {space_before}pt;")
    if space_after > 0:
        style_parts.append(f"margin-bottom: {space_after}pt;")
    style_parts.extend(filter(None, [border_top, border_bottom]))
    style = f' style="{" ".join(style_parts)}"' if style_parts else ""
    return f"<p{cls}{style}>{inner}</p>"


def _collect_segments(
    para: Paragraph,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> list[str]:
    """Return a flat list of HTML strings and raw '\t' markers for tab runs.

    Iterates raw XML children to handle both w:r runs and w:fldSimple elements.
    """
    segments: list[str] = []
    in_field_value = False  # True between fldChar separate and end (cached display value)

    for child in para._element:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag

        # w:fldSimple — e.g. <w:fldSimple w:instr=" NUMPAGES ">
        if tag == "fldSimple":
            instr = child.get(qn("w:instr"), "").strip()
            if "PAGE" in instr and "NUMPAGES" not in instr:
                segments.append('<span class="page-number"></span>')
            elif "NUMPAGES" in instr or "SECTIONPAGES" in instr:
                segments.append('<span class="page-count"></span>')
            # skip the cached child runs
            continue

        if tag != "r":
            continue  # ignore non-run, non-fldSimple children

        # w:r run handling
        elem = child

        # Track fldChar state to skip cached field display values
        fld = elem.find(f".//{qn('w:fldChar')}")
        if fld is not None:
            fld_type = fld.get(qn("w:fldCharType"), "")
            if fld_type == "begin":
                in_field_value = False
            elif fld_type == "separate":
                in_field_value = True
            elif fld_type == "end":
                in_field_value = False
            continue

        if in_field_value:
            continue  # skip cached field display value

        # Check for field instructions (PAGE, NUMPAGES) — instrText in its own run
        instr_elem = elem.find(f".//{qn('w:instrText')}")
        if instr_elem is not None and instr_elem.text:
            instr = instr_elem.text.strip()
            if "PAGE" in instr and "NUMPAGES" not in instr:
                segments.append('<span class="page-number"></span>')
            elif "NUMPAGES" in instr or "SECTIONPAGES" in instr:
                segments.append('<span class="page-count"></span>')
            continue

        # Check for inline images
        drawing = elem.find(f".//{qn('wp:inline')}")
        if drawing is None:
            drawing = elem.find(f".//{qn('wp:anchor')}")
        if drawing is not None:
            img_html = _image_element_to_html(drawing, parent, image_counter, images)
            if img_html:
                segments.append(img_html)
            continue

        # Tab element (<w:tab/>) signals left/right split
        if elem.find(qn("w:tab")) is not None:
            segments.append("\t")
            continue

        # Get text from w:t elements
        text_elems = elem.findall(qn("w:t"))
        text = "".join(t.text or "" for t in text_elems)
        if not text:
            continue

        # Apply text formatting using a lightweight wrapper
        segments.append(_format_run_elem(text, elem))

    return segments


def _format_run_elem(text: str, elem) -> str:
    """Wrap text in <strong>/<em> and colour span based on run XML element."""
    escaped = html.escape(text)
    rpr = elem.find(qn("w:rPr"))
    if rpr is not None:
        if rpr.find(qn("w:b")) is not None:
            escaped = f"<strong>{escaped}</strong>"
        if rpr.find(qn("w:i")) is not None:
            escaped = f"<em>{escaped}</em>"
        color_elem = rpr.find(qn("w:color"))
        if color_elem is not None:
            val = color_elem.get(qn("w:val"), "")
            if val and val.upper() not in ("AUTO", ""):
                escaped = f'<span style="color: #{val.upper()}">{escaped}</span>'
    return escaped


# ── Image conversion ─────────────────────────────────────────────────────────

def _image_element_to_html(
    drawing_elem,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    """Extract an inline image and return an <img> tag."""
    try:
        # Find the relationship ID
        blip = drawing_elem.find(f".//{qn('a:blip')}")
        if blip is None:
            return ""
        r_embed = blip.get(qn("r:embed"))
        if not r_embed:
            return ""

        # Retrieve image bytes via the parent part's relationships
        img_part = parent.part.rels[r_embed].target_part
        img_bytes = img_part.blob
        content_type = img_part.content_type

        ext = _ext_from_content_type(content_type)
        idx = next(image_counter)
        filename = f"image-{idx}{ext}"
        images[filename] = img_bytes

        return f'<img src="{filename}">'
    except Exception:
        return ""


def _ext_from_content_type(ct: str) -> str:
    mapping = {
        "image/png":  ".png",
        "image/jpeg": ".jpg",
        "image/gif":  ".gif",
        "image/svg+xml": ".svg",
        "image/webp": ".webp",
        "image/x-emf": ".emf",
        "image/x-wmf": ".wmf",
    }
    return mapping.get(ct, ".png")


# ── Table conversion ─────────────────────────────────────────────────────────

def _table_to_html(
    table: Table,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    """Convert a table to HTML.

    A single-row table with exactly two non-empty cells becomes a flex-row div
    (the common Word pattern for left/right footer layout, including 3-column
    tables where the middle cell is a spacer). Everything else becomes a <table>.
    """
    rows = table.rows
    if len(rows) == 1:
        non_empty = [c for c in rows[0].cells if _cell_has_content(c)]
        if len(non_empty) == 2:
            return _two_col_row_to_flex_cells(non_empty, parent, image_counter, images)
    return _table_to_html_table(table, parent, image_counter, images)


def _cell_has_content(cell) -> bool:
    """Return True if any paragraph in the cell has visible text."""
    return any(para.text.strip() for para in cell.paragraphs)


def _two_col_row_to_flex_cells(
    cells: list,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    left  = _cell_to_html(cells[0], parent, image_counter, images)
    right = _cell_to_html(cells[1], parent, image_counter, images)
    return (
        f'<div class="flex-row">'
        f"<div>{left}</div>"
        f"<div>{right}</div>"
        f"</div>"
    )


def _two_col_row_to_flex(
    row,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    cells = row.cells
    left  = _cell_to_html(cells[0], parent, image_counter, images)
    right = _cell_to_html(cells[1], parent, image_counter, images)
    return (
        f'<div class="flex-row">'
        f"<div>{left}</div>"
        f"<div>{right}</div>"
        f"</div>"
    )


def _cell_to_html(
    cell,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    parts = []
    for para in cell.paragraphs:
        chunk = _paragraph_to_html(para, parent, image_counter, images)
        if chunk:
            parts.append(chunk)
    return " ".join(parts)


def _table_to_html_table(
    table: Table,
    parent,
    image_counter: itertools.count,
    images: dict[str, bytes],
) -> str:
    rows_html = []
    for i, row in enumerate(table.rows):
        cells_html = []
        for cell in row.cells:
            tag = "th" if i == 0 else "td"
            content = _cell_to_html(cell, parent, image_counter, images)
            cells_html.append(f"<{tag}>{content}</{tag}>")
        rows_html.append(f"<tr>{''.join(cells_html)}</tr>")
    return f"<table>{''.join(rows_html)}</table>"
