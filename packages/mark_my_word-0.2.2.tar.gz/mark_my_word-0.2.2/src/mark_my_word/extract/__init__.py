"""Theme extraction from Word documents."""

import itertools
import math
import re
from pathlib import Path

from . import convert
from .doc import (
    extract_colors,
    extract_fonts,
    extract_heading_styles,
    extract_margins,
    extract_named_styles,
    load_doc,
)
from .render import render_style_css


_PT_PER_MM        = 2.8346
_LINE_HEIGHT_PT   = 9.0 * 1.15  # footer font-size × line-height
_FOOTER_FONT_PT   = 9.0
_CHAR_WIDTH_RATIO = 0.55         # typical char width as a fraction of font-size (sans-serif)
_A4_WIDTH_MM      = 210.0


def _chars_per_line(margins: dict) -> float:
    width_pt = (_A4_WIDTH_MM - margins.get("left", 25.4) - margins.get("right", 25.4)) * _PT_PER_MM
    return width_pt / (_FOOTER_FONT_PT * _CHAR_WIDTH_RATIO)


def _count_footer_lines(html: str | None, chars_per_line: float = 80) -> int:
    if not html:
        return 0
    # Count visual lines: top-level <p> elements plus <div class="flex-row"> blocks.
    # <p> elements inside <div> wrappers (flex-row cells) are not counted separately.
    p_count    = 0
    flex_count = 0
    div_depth  = 0
    height_zero = html.count("height: 0")
    for m in re.finditer(r'<(?P<slash>/?)(?P<tag>p|div)(?P<attrs>[^>]*)>', html):
        closing = m.group("slash") == "/"
        tag     = m.group("tag")
        attrs   = m.group("attrs")
        if tag == "div":
            if not closing:
                if div_depth == 0 and "flex-row" in attrs:
                    flex_count += 1
                div_depth += 1
            else:
                div_depth = max(0, div_depth - 1)
        elif tag == "p" and not closing and div_depth == 0:
            p_count += 1
    p_count = max(0, p_count - height_zero)
    element_lines = max(p_count + flex_count, 0)
    plain_text = re.sub(r"<[^>]+>", "", html)
    char_lines = math.ceil(len(plain_text.strip()) / chars_per_line) if plain_text.strip() else 0
    return max(element_lines, char_lines)


def run(template_path: Path, output_dir: Path) -> None:
    """Extract a theme from a Word template and write it to output_dir."""
    output_dir.mkdir(parents=True, exist_ok=True)
    doc = load_doc(template_path)

    margins      = extract_margins(doc)
    colors       = extract_colors(doc)
    fonts        = extract_fonts(doc)
    headings     = extract_heading_styles(doc)
    named_styles = extract_named_styles(doc)

    image_counter = itertools.count(1)
    section = doc.sections[0]
    has_first_page = section.different_first_page_header_footer

    if has_first_page:
        fragment_parts = {
            "first-header": section.first_page_header,
            "first-footer": section.first_page_footer,
            "cont-header":  section.header,
            "cont-footer":  section.footer,
        }
        css_classes = {
            "first-header": "header-first",
            "first-footer": "footer-first",
            "cont-header":  "header-cont",
            "cont-footer":  "footer-cont",
        }
    else:
        fragment_parts = {
            "header": section.header,
            "footer": section.footer,
        }
        css_classes = {
            "header": "header-cont",
            "footer": "footer-cont",
        }

    fragment_results: dict[str, tuple[str | None, dict]] = {}
    for name, part in fragment_parts.items():
        fragment_results[name] = convert.fragment_to_html(part, image_counter)

    watermark_bytes = None
    watermark_ext = ".png"
    watermark_size_pt: tuple[float, float] | None = None
    watermark_source = section.first_page_header if has_first_page else section.header
    result = convert.extract_background_image(watermark_source)
    if result:
        watermark_bytes, content_type, w_pt, h_pt = result
        watermark_ext = convert._ext_from_content_type(content_type)
        if w_pt > 0 and h_pt > 0:
            watermark_size_pt = (w_pt, h_pt)

    if has_first_page:
        first_footer_html = fragment_results.get("first-footer", (None, {}))[0]
        cont_footer_html  = fragment_results.get("cont-footer",  (None, {}))[0]
    else:
        first_footer_html = cont_footer_html = fragment_results.get("footer", (None, {}))[0]

    cpl = _chars_per_line(margins)
    footer_height_first_pt = _count_footer_lines(first_footer_html, cpl) * _LINE_HEIGHT_PT
    footer_height_cont_pt  = _count_footer_lines(cont_footer_html,  cpl) * _LINE_HEIGHT_PT

    css = render_style_css(margins, colors, fonts, headings,
                           named_styles=named_styles, watermark_size_pt=watermark_size_pt,
                           has_first_page=has_first_page,
                           footer_height_first_pt=footer_height_first_pt,
                           footer_height_cont_pt=footer_height_cont_pt)
    (output_dir / "style.css").write_text(css, encoding="utf-8")
    _report("style.css", True)

    if watermark_bytes is not None:
        watermark_filename = f"watermark{watermark_ext}"
        (output_dir / watermark_filename).write_bytes(watermark_bytes)
        _report(watermark_filename, True, "watermark")

    for name, (html_str, images) in fragment_results.items():
        if html_str is None:
            _report(f"{name}.html", False, "empty")
            continue
        cls = css_classes[name]
        html_str = f'<div class="{cls}">\n{html_str}\n</div>'
        (output_dir / f"{name}.html").write_text(html_str, encoding="utf-8")
        _report(f"{name}.html", True)
        for filename, data in images.items():
            (output_dir / filename).write_bytes(data)
            _report(filename, True, "image")

    print(f"\nTheme written to: {output_dir}")


def _report(filename: str, written: bool, note: str = "") -> None:
    status = "  wrote" if written else "skipped"
    suffix = f"  ({note})" if note else ""
    print(f"  {status}  {filename}{suffix}")
