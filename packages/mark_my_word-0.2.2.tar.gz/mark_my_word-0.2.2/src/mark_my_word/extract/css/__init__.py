from importlib.resources import files as _files


def _load(name: str) -> str:
    return _files(__name__).joinpath(f"{name}.css").read_text(encoding="utf-8")


lists            = _load("lists")
code             = _load("code")
table            = _load("table")
blockquote       = _load("blockquote")
running_elements = _load("running_elements")
watermark        = _load("watermark")
