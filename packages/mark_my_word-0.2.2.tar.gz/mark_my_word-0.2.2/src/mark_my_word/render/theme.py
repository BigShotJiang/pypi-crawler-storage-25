"""Theme loading, variable substitution, and HTML assembly."""


import base64
import re

from dataclasses import dataclass
from pathlib import Path


@dataclass
class Theme:
    css: str
    first_header: str | None = None
    first_footer: str | None = None
    cont_header: str | None = None
    cont_footer: str | None = None
    watermark_uri: str | None = None


def load(theme_dir: Path) -> Theme:
    """Load all theme assets from theme_dir."""
    css = (theme_dir / "style.css").read_text()

    def read(filename: str) -> str | None:
        p = theme_dir / filename
        return p.read_text() if p.exists() else None

    header  = read("header.html")
    footer  = read("footer.html")
    fragments = {
        "first_header": read("first-header.html") or header,
        "first_footer": read("first-footer.html") or footer,
        "cont_header":  read("cont-header.html")  or header,
        "cont_footer":  read("cont-footer.html")  or footer,
    }

    watermark_path = theme_dir / "watermark.png"
    watermark_uri = None
    if watermark_path.exists():
        data = base64.b64encode(watermark_path.read_bytes()).decode()
        watermark_uri = f"data:image/png;base64,{data}"
        css = re.sub(
            r"--watermark-url\s*:[^;]+;",
            f"--watermark-url: url('{watermark_uri}');",
            css,
        )

    return Theme(css=css, watermark_uri=watermark_uri, **fragments)


_PLACEHOLDER = re.compile(r"\{\{(\w+?)(?:\s*:\s*([^}]*?))?\}\}", re.IGNORECASE)


def substitute(template: str, vars: dict) -> str:
    """Replace {{key}} or {{key: default}} placeholders using vars."""
    def _replace(m: re.Match) -> str:
        key = m.group(1).lower()
        default = m.group(2).strip() if m.group(2) is not None else None
        if key in vars:
            return str(vars[key])
        if default is not None:
            return default
        raise KeyError(key)
    return _PLACEHOLDER.sub(_replace, template)


def assemble_html(body_html: str, theme: Theme, vars: dict, base_url: Path) -> str:
    """Build a single HTML document with all header/footer elements present."""

    def render_fragment(html: str | None) -> str:
        if not html:
            return ""
        return substitute(html, vars)

    first_header = render_fragment(theme.first_header)
    first_footer = render_fragment(theme.first_footer)
    cont_header = render_fragment(theme.cont_header)
    cont_footer = render_fragment(theme.cont_footer)

    # All running elements must appear BEFORE body content so WeasyPrint
    # registers their values on page 1 and carries them through subsequent pages.
    # Watermark div (position: fixed) repeats on every page in WeasyPrint.
    watermark = '<div class="watermark"></div>' if theme.watermark_uri else ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <base href="{base_url.as_uri()}/">
  <style>{theme.css}</style>
</head>
<body>
{watermark}
{first_header}
{cont_header}
{first_footer}
{cont_footer}
{body_html}
</body>
</html>"""
