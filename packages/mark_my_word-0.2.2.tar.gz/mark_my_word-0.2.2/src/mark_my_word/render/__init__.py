"""WeasyPrint PDF rendering and output file handling."""

import shutil
import tempfile
from pathlib import Path

from weasyprint import HTML

from .. import extract as _extract
from . import config, document, theme

_GLOBAL_CONFIG_PATH = Path.home() / ".config" / "mark-my-word" / "config.yaml"


def run(
    input_path: Path,
    theme_path: Path | None = None,
    template_path: Path | None = None,
    save_theme: Path | None = None,
    output: Path | None = None,
    set_vars: dict | None = None,
    save_html: bool = False,
    force: bool = False,
) -> Path:
    """Render a Markdown file to PDF using a theme directory. Returns the output path."""
    if not theme_path and not template_path:
        raise ValueError("one of theme_path or template_path is required")
    if theme_path and template_path:
        raise ValueError("theme_path and template_path are mutually exclusive")
    if save_theme and not template_path:
        raise ValueError("--save-theme requires --template")
    if save_theme:
        _validate_save_theme(save_theme)

    output_name_path = input_path.absolute()  # preserve symlink name for output
    input_path = input_path.resolve()

    if template_path:
        theme_dir = _extract_template(template_path.resolve(), save_theme)
    else:
        theme_dir = theme_path.resolve()

    try:
        return _render(input_path, output_name_path, theme_dir, output, set_vars or {}, save_html, force)
    finally:
        if template_path and not save_theme:
            shutil.rmtree(theme_dir, ignore_errors=True)


def _validate_save_theme(save_theme: Path) -> None:
    if not save_theme.parent.exists():
        raise ValueError(f"save-theme parent directory does not exist: {save_theme.parent}")
    if save_theme.exists() and any(save_theme.iterdir()):
        raise ValueError(f"save-theme directory is not empty: {save_theme}")


def _extract_template(template_path: Path, save_theme: Path | None) -> Path:
    if save_theme:
        save_theme.mkdir(exist_ok=True)
        _extract.run(template_path, save_theme)
        return save_theme
    tmp = Path(tempfile.mkdtemp())
    _extract.run(template_path, tmp)
    return tmp


def _render(
    input_path: Path,
    output_name_path: Path,
    theme_dir: Path,
    output: Path | None,
    set_vars: dict,
    save_html: bool,
    force: bool,
) -> Path:
    global_config = config.load_global_config(_GLOBAL_CONFIG_PATH)
    meta, markdown_body = document.parse(input_path)
    merged = config.merge_config(global_config, meta, set_vars)

    body_html = document.to_html(markdown_body)
    title = config.extract_title(merged, body_html, input_path)
    if not merged.get("title"):
        body_html = config.strip_first_h1(body_html)
    template_vars = {**merged, "title": title}

    loaded_theme = theme.load(theme_dir)
    html = theme.assemble_html(body_html, loaded_theme, template_vars, base_url=input_path.parent)

    output_path = config.resolve_output_path(output, output_name_path)
    if output_path.exists() and not force:
        raise FileExistsError(f"output already exists (use --force to overwrite): {output_path}")

    if save_html:
        _save_html(html, output_path)

    to_pdf(html, base_url=input_path.parent, output_path=output_path)
    return output_path


def to_pdf(html: str, base_url: Path, output_path: Path) -> None:
    """Render HTML to PDF via WeasyPrint."""
    HTML(string=html, base_url=str(base_url)).write_pdf(str(output_path))


def _save_html(html: str, output_path: Path) -> None:
    output_path.with_suffix(".html").write_text(html)
