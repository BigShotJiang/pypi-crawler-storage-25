"""Frontmatter parsing and Markdown → HTML conversion."""

import re
from pathlib import Path

import frontmatter
import markdown2

_MARKDOWN_EXTRAS = [
    "fenced-code-blocks",
    "tables",
    "strike",
    "header-ids",
]

_MORE = re.compile(r'^<!--more-->$', re.MULTILINE)


def parse(path: Path) -> tuple[dict, str]:
    """Parse a Markdown file, returning (frontmatter_dict, markdown_body)."""
    post = frontmatter.load(str(path))
    content = post.content
    if m := _MORE.search(content):
        content = content[m.end():]
    return dict(post.metadata), content


def to_html(markdown: str) -> str:
    """Convert Markdown to HTML with standard extras."""
    return markdown2.markdown(markdown, extras=_MARKDOWN_EXTRAS)
