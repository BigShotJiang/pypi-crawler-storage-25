"""Config loading, merging, title extraction, and output path handling."""


import re
from pathlib import Path

import yaml

DEFAULTS: dict = {
    "theme": None,
    "subtitle": "",
}


def load_global_config(path: Path) -> dict:
    """Read ~/.config/mark-my-word/config.yaml, returning {} if absent."""
    if not path.exists():
        return {}
    with path.open() as f:
        return yaml.safe_load(f) or {}


def merge_config(
    global_cfg: dict,
    frontmatter: dict,
    set_flags: dict,
) -> dict:
    """Merge config layers: defaults < global < frontmatter < --set flags."""
    result = {**DEFAULTS}
    result.update(global_cfg)
    result.update(frontmatter)
    result.update(set_flags)
    return result


def extract_title(meta: dict, body_html: str, input_path: Path) -> str:
    """Return title from frontmatter, first H1 in body HTML, or filename stem."""
    if meta.get("title"):
        return str(meta["title"])
    match = re.search(r"<h1[^>]*>(.*?)</h1>", body_html, re.IGNORECASE | re.DOTALL)
    if match:
        # Strip any inner tags (e.g. <em>)
        return re.sub(r"<[^>]+>", "", match.group(1)).strip()
    return input_path.stem


def strip_first_h1(html: str) -> str:
    """Remove the first <h1> element from body HTML."""
    return re.sub(r"<h1[^>]*>.*?</h1>\n?", "", html, count=1, flags=re.DOTALL).lstrip("\n")


def resolve_output_path(output: Path | None, input_path: Path) -> Path:
    """Resolve --out value to a base PDF path (before auto-increment).

    None          → alongside input with .pdf suffix
    existing dir  → dir / input_stem.pdf
    non-existing  → use as-is; fail if parent does not exist
    """
    if output is None:
        return input_path.with_suffix(".pdf")
    if output.is_dir():
        return output / f"{input_path.stem}.pdf"
    if not output.parent.exists():
        raise ValueError(f"output directory does not exist: {output.parent}")
    return output


