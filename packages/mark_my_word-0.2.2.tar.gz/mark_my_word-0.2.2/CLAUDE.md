# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository layout

- `src/mark_my_word/` — Python package source
- `test/` — pytest test suite
- `examples/` — example Word templates and extracted themes (e.g. `circus-everything/`)
- `scripts/` — one-off generators (e.g. `make_circus.py`)
- `docs/` — `NOTES.md` (architecture decisions), `JOURNAL.md` (session log)
- `themes/` — gitignored; symlink target for a local private themes repo

## Commands

Run from the repo root:

```shell
uv run pytest                              # all tests
uv run pytest test/render/test_config.py  # single file
uv run pytest -k test_merge_config        # single test by name
uv run ruff check .                        # lint
uv run ruff format .                       # format
uv run mark-my-word render doc.md --theme themes/goalwards/ --output /tmp/out.pdf
uv run mark-my-word extract template.dotx --output themes/my-theme/
```

## Architecture

Two CLI subcommands, each with its own pipeline:

### `render` (Markdown → PDF)

`render/__init__.py::run` orchestrates:

1. **Config** (`render/config.py`): layers merge in priority order — `DEFAULTS` < `~/.config/mark-my-word/config.yaml` < document frontmatter < `--set` flags. The merged dict becomes the template variable namespace (e.g. `{title}`, `{subtitle}`).
2. **Document** (`render/document.py`): parses YAML frontmatter, converts Markdown body to HTML via `markdown2`.
3. **Theme** (`render/theme.py`): loads `style.css` and optional HTML fragments (`first-header.html`, `first-footer.html`, `cont-header.html`, `cont-footer.html`) from the theme directory; if `watermark.png` is present, base64-encodes it and patches its URL into the CSS. `assemble_html` builds a single HTML document with all running elements before the body content (WeasyPrint requirement).
4. **PDF**: `render.to_pdf` passes the assembled HTML to WeasyPrint. Output path auto-increments (`out-1.pdf`, `out-2.pdf`, …) to avoid overwrites.

### `extract` (Word template → theme directory)

`extract/__init__.py::run` orchestrates:

1. **Document loading** (`extract/doc.py::load_doc`): `.dotx` files require a content-type patch before `python-docx` will open them.
2. **Style extraction** (`extract/doc.py`): pulls margins (EMU → mm), theme colors (mapped to CSS custom property names), base font, and heading styles (levels 1–6, walking the inheritance chain).
3. **Header/footer conversion** (`extract/convert.py`): converts Word paragraphs and tables to HTML fragments. Tab characters become `flex-row` divs (left/right split). Field codes (`PAGE`, `NUMPAGES`) become `<span class="page-number">` / `<span class="page-count">`. Watermark images are extracted from VML `<w:pict>` elements.
4. **CSS generation** (`extract/render.py`): assembles `style.css` from extracted values plus static CSS partials in `extract/css/` (blockquote, code, lists, running elements, table, watermark).

### Theme directory format

A theme is a plain directory containing:

- `style.css` — required; uses CSS custom properties as design tokens (`--color-body`, `--font-base`, `--page-margin`, etc.)
- `first-header.html`, `first-footer.html`, `cont-header.html`, `cont-footer.html` — optional HTML fragments; support `{variable}` placeholders substituted from the config namespace
- `watermark.png` — optional; loaded and base64-inlined at render time

HTML fragments are wrapped in `<div class="header-first">` etc. and positioned via CSS `running()` / `element()` in `@page` rules.
