# Journal

## 2026-03-23

### Session start

New project: `md2pdf` — a tool to convert Markdown files to styled PDFs with headers, footers, and background graphics.

### Word template analysis (first pass)

Extracted styling from a client Word template (`.dotx` ZIP/XML). Found:

- Theme: "Thermal", font scheme: Gill Sans MT
- Color palette: teal, lavender, dark navy, orange
- Headers: VML watermark image covering full page, z-index behind content
- Footer (default): left/right columns — company name | Page X of Y
- Footer (first page): centered legal text — company address, registration, contact
- Page: A4, 25.4mm margins, different first page enabled

### Tool approach settled (JS era)

Settled on `md-to-pdf` (Puppeteer-based npm package) + thin JS wrapper for two-pass first-page handling.

### Repo split into app/ and themes/

- `app/` — public, contains the tool
- `themes/` — private, contains client theme files

## 2026-03-25 (JS era)

### Renamed template files

`header.html` → `front-header.html`, `header-first.html` → `continuation-header.html`, etc.
Renamed `--color-teal` → `--color-blockquote` for semantic clarity.

### Chrome/Puppeteer color bug

Chrome overrides `color` in Puppeteer `headerTemplate`/`footerTemplate`. Worked around by injecting header/footer HTML into `<body>` with `position: fixed`. Page counters via CSS `counter(page)` were untested and unresolved.

### Discovered Chrome @page / position:fixed constraint

`position: fixed` elements are confined to the `@page` content area — negative offsets to reach margin zones cause wrapping. Fixed with `@page { margin: 0 }` and absolute `top:` values for footer positioning. `bottom: 0` doesn't work in Chrome PDF print — use `top: Xmm` instead.

### Built automated layout diagnostic

`diagnose.js` uses `pdftotext -bbox-layout` to check header/footer positions in a debug PDF without manual review. Debug theme uses solid colored blocks per element.

## 2026-03-26

### Switched to Python + WeasyPrint

Rewrote the tool from scratch in Python. WeasyPrint implements CSS Paged Media natively (`@page`, `@top-left`, `@bottom-left`, running elements, `counter(page)`). Eliminates all Puppeteer workarounds and two-pass PDF stitching — one render, correct output.

### Theme structure revised

Theme files renamed to match WeasyPrint's CSS Paged Media model:

- `first-header.html` / `first-footer.html` — page 1 only
- `cont-header.html` / `cont-footer.html` — continuation pages
- `watermark.png` — base64-embedded at load time; rendered via `<div class="watermark">` injected into body (`html::before { position: fixed }` does not work in WeasyPrint)

### word2theme built

New subcommand `extract` extracts a complete md2pdf theme from a `.docx` or `.dotx` file in one pass:

- Margins from `w:pgMar` — `w:bottom` (body area) and `w:footer` (footer-from-edge) are independent
- Colors from `/word/theme/theme1.xml` OOXML theme tokens
- Fonts from Normal style
- Headings H1–H6 via style inheritance chain
- Named paragraph styles (e.g. `Title`) → `.para-title` CSS class + matching HTML class on `<p>` elements
- Header/footer fragments: paragraphs, runs (bold/italic/color), tab→flex-row, fields (PAGE/NUMPAGES), inline images, VML watermark
- VML watermark: extracted from `<w:pict>` via relationship table; display size from VML `style="width:Xpt;height:Ypt"` attribute; full-bleed via negative CSS offsets with `calc()`

## 2026-03-27

### Faithfulness principle established for word2theme

Removed hardcoded `border-top` from `@bottom-left` / `@bottom-center` in generated CSS. `extract` only emits styling present in the source Word document. Border rules belong on the element's CSS class so they only render when the element is in the HTML.

### End-to-end test passed

Full pipeline verified:

```shell
md2pdf extract template.dotx --output themes/client/
md2pdf render content.md --theme themes/client/ --output out.pdf
```

Output matches source Word template styling.

## 2026-04-09

### CLI restructured as single package with click subcommands

Merged `md2pdf` and `word2theme` into one package with two subcommands:

- `md2pdf render` — was the standalone `md2pdf` command
- `md2pdf extract` — was the standalone `word2theme` command

Entry point: `md2pdf = "md2pdf.cli:cli"`. `cli.py` is pure parse-and-dispatch; business logic lives in `render.run()` and `extract.run()`. Used click for idiomatic help text and arg parsing.

### Package namespace restructured for symmetry

```text
md2pdf/
  cli.py
  render/        __init__.py (to_pdf, run), config.py, document.py, theme.py
  extract/       __init__.py (run), render.py, doc.py, convert.py, css/
```

Both subcommands are symmetric: `md2pdf.render` and `md2pdf.extract` each have a `run()` entry point callable without going through click.

### extract package split into logical modules

`extract/__init__.py` was getting large. Split into:

- `doc.py` — Word document loading and style extraction
- `render.py` — dynamic CSS generation (tokens, page layout, headings)
- `css/` — static CSS fragment files (`lists.css`, `code.css`, `table.css`, etc.)
- `css/__init__.py` — loads each file via `importlib.resources.files()`, exposes as `css.lists`, `css.code`, etc.
- `convert.py` — Word XML → HTML fragment conversion (unchanged)

Static CSS strings moved out of Python and into real `.css` files. `importlib.resources.files()` is the packaging-safe way to load them (stdlib, Python 3.9+, works in zip installs).

### Ruff added as linter

`ruff` added to dev dependencies with `line-length = 120` and `select = ["E", "F", "W", "I"]`. Clean on all source files.

## 2026-05-22

### Renamed to `mark-my-word`

Package and CLI renamed from `md2pdf` to `mark-my-word`. Repo restructured into `src/` layout with `test/`, `docs/`, and `scripts/`.

### Render API tightened

- `--set` flag parsing moved from `render.run()` into `cli.py`; render now takes `set_vars: dict` directly
- `vars` renamed to `template_vars` to avoid shadowing the Python builtin
- `--name` option removed from `extract` (was silently ignored)
- `print` removed from `_save_html` (library code should not print)

### `--template` and `--save-theme` flags added to render

`render --template template.dotx` extracts a theme from a Word template on the fly and uses it for the current render. `--save-theme path/` persists the extracted theme for reuse.

### Single header/footer when first page not distinct

`extract` now writes `header.html` / `footer.html` (two files) when `different_first_page_header_footer` is false, and the full four-file set (`first-header.html`, `first-footer.html`, `cont-header.html`, `cont-footer.html`) only when it is true. The theme loader already had fallback logic for both layouts. Watermark extraction bug fixed: source was looking in `fragment_parts["first-header"]` (could be `None`) instead of directly at `section.first_page_header` / `section.header`.

### Circus example variants

`scripts/make_circus.py` generates four `.dotx` variants from Word-created base files (`examples/circus/base.dotx`, `examples/circus/watermark.dotx`) and extracts a theme from each:

- `circus-everything` — first-page header (centered), cont header (tab + page numbers), footer, watermark
- `circus-header-footer` — same tab header and footer on all pages, no watermark
- `circus-cont-header` — tab header only
- `circus-watermark` — watermark only

Key finding: watermark VML lives in `<w:pict>` inside a header paragraph. Calling `para.clear()` before adding text destroys the watermark. Fixed by using `header.add_paragraph()` to append a new text paragraph instead of clearing the existing one.

### `<!--more-->` preamble separator

`render` now strips everything before a `<!--more-->` line from the Markdown body before parsing. Designed for notes from apps like NotePlan that prepend tags or metadata. Anchored to a full line (`^<!--more-->$` with `re.MULTILINE`).

### `{{variable}}` template syntax with defaults

Switched fragment substitution from Python `str.format_map` (`{var}`) to a regex-based `{{var}}` syntax. Benefits: double braces are unambiguous in CSS contexts; supports `{{var: default}}` fallback values; case-insensitive. Written directly in Word template headers/footers — passes through extraction verbatim and is substituted at render time.

### H1 used as title and stripped from body

When no `title:` is set in frontmatter, `render` extracts the first H1 from the body as the document title (available as `{{title}}` in fragments) and removes it from the rendered body to avoid duplication.

### Output file handling simplified

Dropped auto-incrementing output names (`doc-1.pdf`, `doc-2.pdf`, …). Output is now exactly the resolved path. If the file already exists, `render` refuses with an error — use `--force` / `-f` to overwrite. Symlink inputs now use the link name (not the resolved target) for the default output filename.

### Paragraph bottom border extraction

`extract` now extracts `<w:pBdr><w:bottom>` from Word header/footer paragraphs and emits the border as an inline CSS `border-bottom` on the `<p>` or flex-row `<div>`. Walks the paragraph's style inheritance chain so borders defined at the style level (e.g. the built-in Word "Header" style) are picked up. Empty paragraphs that carry only a border (Word "horizontal line" pattern) are preserved as `<p style="border-bottom: ...; height: 0; margin: 0;"></p>` instead of being silently dropped.

## 2026-05-22

### Footer border spacing and height estimation overhaul

End goal: extract the Goalwards Word template and render a PDF one-shot, without editing CSS. The main obstacles were (a) border lines appearing with wrong spacing and (b) the footer height estimate being wildly off, causing a large gap between body text and the footer.

**Top and bottom border extraction generalised.** `_para_border(para, side)` now handles both `"top"` and `"bottom"`, replacing the bottom-only implementation. `w:space` on the border element maps to `padding-top`/`padding-bottom` (the gap between content and border line).

**Empty border paragraphs now render at natural line height.** Previously emitted with `height: 0` to "collapse" the box, but that removed the visual gap above the border that Word provides from the paragraph's natural line height. Fixed: the empty `<p>` now has no explicit height, rendering at the footer's natural line height (~10pt for a 9pt font at single spacing). `w:spacing w:after` on the paragraph becomes `margin-bottom`.

**`display: flex` removed from `.footer-cont`.** It was making the empty border `<p>` a flex sibling of the flex-row `<div>`, laying them side by side instead of stacking. `.footer-cont` is now a block container; the `flex-row` inside handles the left/right layout.

**Footer height estimate fixed.** `_count_footer_lines` was counting every `<p>` in the HTML string including those nested inside flex-row `<div>` wrappers. This counted each flex-row as 3 lines (the two inner `<p>` elements plus the flex-row itself), ballooning the margin. Fixed by tracking `<div>` nesting depth with a regex scanner and only counting `<p>` at depth 0.

**Footer height computed from page width.** `_chars_per_line` derives the line-wrap character count from the actual page width minus margins, using 9pt footer font and a 0.55 char-width ratio. This gives ~91 chars/line for Goalwards (A4, 25.4mm margins) versus the previous hardcoded 80.

**Page margin computed in Python, not CSS `calc()`.** WeasyPrint cannot evaluate `calc(var(--a) + var(--b))` in `@page` margin rules. The bottom margin is pre-computed in Python as `FOOTER_GAP + footer_dist + footer_height` and written as a plain `pt` value.

**Paragraph spacing (`w:before`/`w:after`) extracted.** Non-empty paragraphs now emit `margin-top`/`margin-bottom` from `w:spacing w:before/w:after`, walking the style inheritance chain.

**Orphans/widows relaxed to 2+2.** Default was 3; changed to 2 for a less aggressive page-break policy.
