# Notes

## Architecture

### Renderer: Python + WeasyPrint

The tool is a Python CLI using WeasyPrint for PDF generation. WeasyPrint implements CSS Paged Media (`@page`, `@top-left`, `@bottom-left`, running elements), which is the correct model for headers/footers — no hacks required.

**Why WeasyPrint over Puppeteer/Chrome:** Chrome does not support CSS Paged Media running elements. Puppeteer's `headerTemplate` overrides text color and has no first-page support. WeasyPrint supports running elements, page counters, and all `@page` features natively.

### Two subcommands: `render` and `extract`

- `mark-my-word render` — converts Markdown to PDF using a theme directory
- `mark-my-word extract` — extracts a theme from a `.docx` or `.dotx` Word template

Single package, single entry point (`mark_my_word.cli:cli`). `cli.py` is pure parse-and-dispatch. Each subcommand delegates to `render.run()` / `extract.run()`, which are callable without going through click.

### Package structure

```text
src/mark_my_word/
  cli.py
  render/
    __init__.py   ← run(), to_pdf()
    config.py
    document.py
    theme.py
  extract/
    __init__.py   ← run()
    doc.py        ← Word document loading and style extraction
    render.py     ← dynamic CSS generation
    convert.py    ← Word XML → HTML fragment conversion
    css/
      __init__.py ← loads CSS files via importlib.resources, exposes as css.lists etc.
      *.css       ← static CSS fragments (lists, code, table, blockquote, running_elements, watermark)
```

### Static CSS as real files

Static CSS strings live in `extract/css/*.css` — real CSS files editable in any editor. Loaded at import time via `importlib.resources.files()` (stdlib, Python 3.9+, packaging-safe). Accessed as `css.lists`, `css.code`, etc.

## Theming

### Theme structure

```text
themes/<name>/
  style.css          # required — all styling, CSS custom properties
  first-header.html  # optional — page 1 header fragment
  first-footer.html  # optional — page 1 footer fragment
  cont-header.html   # optional — continuation pages header fragment
  cont-footer.html   # optional — continuation pages footer fragment
  watermark.png      # optional — full-page background image
  image-*.png        # optional — images referenced from header/footer HTML
```

When `different_first_page_header_footer` is false in the Word template, `extract` writes `header.html` / `footer.html` instead of the four `first-` / `cont-` files. The theme loader handles both layouts via fallback: `cont-header.html` falls back to `header.html`, etc.

Only files with content need exist. Missing fragments are silently treated as empty.

### Template variables in fragment HTML

Fragment HTML files (and Word template headers/footers) use `{{variable}}` double-brace syntax. Variables come from document frontmatter, global config, and `--set` flags. A default can be supplied: `{{title: Untitled}}` — used when the variable is not set. Unknown variables with no default raise `KeyError`. Matching is case-insensitive. Single braces pass through untouched (safe for CSS).

### Watermark

`watermark.png` is base64-encoded and embedded into `style.css` at load time. The `.watermark` div is injected into the HTML body by the renderer; WeasyPrint renders `position: fixed` divs on every page.

## CSS Paged Media

### Running elements (headers/footers)

```css
.header-cont { position: running(running-header); }
@page { @top-left { content: element(running-header); } }
```

Running elements are removed from normal flow and placed in `@page` margin boxes. They repeat on every page automatically. WeasyPrint supports this fully.

### First-page vs continuation

`@page :first` overrides specific margin boxes for page 1. `first-header` / `first-footer` use separate named running positions so they don't bleed onto continuation pages.

### Footer distance from page edge

Word separates `margin-bottom` (body content area) from `footer` (footer-from-bottom-edge). These map to:

- `@page { margin-bottom: <w:bottom in mm> }` — keeps content clear of footer
- `@bottom-left { padding-bottom: <w:footer in mm>; vertical-align: bottom; }` — positions footer relative to page edge

### Border on running elements, not margin boxes

Borders on `@top-left` / `@bottom-left` render even when the running element content is absent. Borders belong on the element's CSS class (`.header-cont { border-bottom: ... }`) so they only appear when the element is in the HTML.

### Watermark via body div (not pseudo-element)

WeasyPrint does not render `background-image` on `html::before { position: fixed }`. Working approach: inject `<div class="watermark"></div>` into the HTML body.

Full-bleed watermark (past page margins) requires negative offsets:

```css
.watermark {
  position: fixed;
  top: -{top}mm; left: -{left}mm;
  width: calc(100% + {left}mm + {right}mm);
  height: calc(100% + {top}mm + {bot}mm);
}
```

## extract

### Faithfulness principle

`extract` aims to reproduce the Word template as closely as possible in CSS/HTML. It does NOT add decorative styling not present in the Word document (e.g. no footer `border-top` unless the Word template has one).

### Color extraction

Colors come from `/word/theme/theme1.xml` inside the `.docx` ZIP. Tokens map to CSS variables:

| Word token | CSS variable         |
|------------|----------------------|
| `dk1`      | `--color-body`       |
| `accent1`  | `--color-heading`    |
| `accent2`  | `--color-blockquote` |
| `accent3`  | `--color-link`       |
| `dk1` @50% | `--color-footer`     |
| `dk1` @30% | `--color-rule`       |

### Heading style inheritance

`extract_heading_styles()` walks `style.base_style` up the inheritance chain to resolve font size, color, bold, italic, and spacing. Falls back to sensible defaults if a value is not found anywhere in the chain.

### Named paragraph styles

`extract_named_styles()` extracts named paragraph styles used in headers/footers (e.g. `Title`). These are emitted as `.para-<name>` CSS classes. The convert step emits `class="para-title"` etc. on `<p>` elements, so the extracted CSS applies automatically.

### VML watermark extraction

Some Word templates embed a background image as a VML `<w:pict>` element inside a header. `extract` extracts this via the relationship table and writes it as `watermark.png`. The VML shape's `style="width:Xpt;height:Ypt"` attribute gives the intended display size, used to set `background-size` in CSS.

### Output file handling

`render` writes the output alongside the input by default (`doc.pdf`), or to the path/directory given with `--output`. If the output file already exists, the command refuses rather than overwriting — use `--force` / `-f` to overwrite. No auto-increment suffixes.

### `<!--more-->` preamble separator

If `<!--more-->` appears on its own line in the Markdown body, everything before it is discarded. Designed for notes from apps like NotePlan that prepend tags or metadata. Multiple occurrences are handled correctly — only the first is treated as the separator; everything after passes through verbatim.

### Custom stylesheet overlay (TODO — maybe)

A possible future feature: `--css custom.css` appended after `theme/style.css` at render time, for per-render overrides without modifying the extracted theme. Deferred — may be over-engineering.
