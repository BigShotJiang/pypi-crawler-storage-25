# ScreenSolver

ScreenSolver is a lightweight CLI tool that automatically downloads and runs the ScreenSolver Windows application.

---

## 🚀 Installation

```bash
pip install screensolver
## Usage
After installation, run:

screensolver