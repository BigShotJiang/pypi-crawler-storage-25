import os
import requests
import subprocess
from tqdm import tqdm  
from dotenv import load_dotenv
import sys

OWNER = "amanksingh678"
REPO = "ScreenSolver"
TAG = "v1.1.0"
APP_NAME = "ScreenSolver.exe"
INSTALL_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ScreenSolver")
EXE_PATH = os.path.join(INSTALL_DIR, APP_NAME)

load_dotenv()
def get_asset_api_url(headers):
    url = f"https://api.github.com/repos/{OWNER}/{REPO}/releases/tags/{TAG}"
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    for asset in response.json()["assets"]:
        if asset["name"].endswith(".exe"):
            return asset["url"] 
    raise Exception("No EXE found in release")


def download_exe(headers):
    print("Downloading ScreenSolver...")
    os.makedirs(INSTALL_DIR, exist_ok=True)

    asset_url = get_asset_api_url(headers)
    
    download_headers = {**headers, "Accept": "application/octet-stream"}

    with requests.get(asset_url, headers=download_headers,
                      stream=True, allow_redirects=True) as r:
        r.raise_for_status()
        total_size = int(r.headers.get("content-length", 0))

        # ✅ Fix 3: correct tqdm indentation and total size
        with open(EXE_PATH, "wb") as f, tqdm(
            desc="Downloading ScreenSolver.exe",
            total=total_size,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
        ) as bar:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    bar.update(len(chunk))

    print("Download complete.")

def run_exe():
    print("Launching ScreenSolver...")
    subprocess.Popen(EXE_PATH, shell=True)

def show_help():
    print("""
ScreenSolver CLI

Usage:
  screensolver        Run the application
  screensolver --help Show this help message

Description:
  Downloads and runs the ScreenSolver executable.
  On first run, it installs the app automatically.
""")

def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        show_help()
        return  
    
    TOKEN = os.environ.get("GITHUB_TOKEN")
    if not TOKEN:
        print("Error: GITHUB_TOKEN not set in .env file")
        sys.exit(1)
        
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github+json"
    }

    if not os.path.exists(EXE_PATH):
        download_exe(headers)
    else:
        print("Already installed.")
    run_exe()

if __name__ == "__main__":
    main()