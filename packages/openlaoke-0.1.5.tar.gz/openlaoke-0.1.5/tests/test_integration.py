"""Integration tests for OpenLaoKe."""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openlaoke.core.state import create_app_state, AppState
from openlaoke.core.multi_provider_api import MultiProviderClient
from openlaoke.core.tool import ToolRegistry
from openlaoke.tools.register import register_all_tools
from openlaoke.types.providers import MultiProviderConfig
from openlaoke.utils.config import AppConfig, save_config, load_config


class TestEndToEnd:
    """End-to-end integration tests."""
    
    def test_full_state_workflow(self):
        """Test complete state management workflow."""
        with tempfile.TemporaryDirectory() as tmpdir:
            persist_path = Path(tmpdir) / "session.json"
            
            state = create_app_state(
                cwd=tmpdir,
                model="test-model",
                persist_path=str(persist_path),
            )
            
            state.set_cwd("/new/path")
            
            from openlaoke.types.core_types import TokenUsage
            usage = TokenUsage(input_tokens=100, output_tokens=50)
            state.accumulate_tokens(usage)
            
            assert state.cwd == "/new/path"
            assert state.token_usage.input_tokens == 100
    
    def test_config_save_load(self):
        """Test saving and loading configuration."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.json"
            
            with patch("openlaoke.utils.config.CONFIG_PATH", config_path):
                config = AppConfig()
                config.max_tokens = 4096
                config.temperature = 0.8
                config.permission_mode = "auto"
                config.auto_approve_all = True
                save_config(config)
                
                loaded = load_config()
                
                assert loaded.max_tokens == 4096
                assert loaded.temperature == 0.8
                assert loaded.permission_mode == "auto"
                assert loaded.auto_approve_all is True
    
    def test_tool_registry_complete(self):
        """Test that all tools are registered."""
        registry = ToolRegistry()
        register_all_tools(registry)
        
        tools = registry.get_all()
        tool_names = [t.name for t in tools]
        
        assert "Bash" in tool_names
        assert "Read" in tool_names
        assert "Write" in tool_names
        assert "Edit" in tool_names
        assert "Glob" in tool_names
        assert "Grep" in tool_names
        assert "Agent" in tool_names
    
    def test_provider_config_complete(self):
        """Test that all providers are configured."""
        config = MultiProviderConfig.defaults()
        
        required_providers = [
            "anthropic",
            "openai", 
            "minimax",
            "aliyun_coding_plan",
            "ollama",
            "lm_studio",
        ]
        
        for provider in required_providers:
            assert provider in config.providers, f"Missing provider: {provider}"
            p = config.providers[provider]
            assert p.provider_type is not None
            assert p.base_url or p.is_local


class TestMessageFlow:
    """Tests for message flow through the system."""
    
    @pytest.mark.asyncio
    async def test_message_conversion_flow(self):
        """Test that messages are properly converted."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "tool_calls": [
                {"id": "call_1", "type": "function", "function": {"name": "Bash", "arguments": '{"command":"ls"}'}}
            ]},
            {"role": "tool", "tool_call_id": "call_1", "content": "file.txt"},
        ]
        
        openai_format = client._convert_to_openai_format(messages)
        
        assert openai_format[0]["role"] == "user"
        assert openai_format[1]["role"] == "assistant"
        assert openai_format[2]["role"] == "tool"
        assert openai_format[2]["tool_call_id"] == "call_1"
        
        anthropic_format = client._convert_to_anthropic_format(messages)
        
        assert anthropic_format[0]["role"] == "user"
        assert anthropic_format[1]["role"] == "assistant"
        assert anthropic_format[2]["role"] == "user"
    
    @pytest.mark.asyncio
    async def test_tool_format_conversion(self):
        """Test tool format conversion for different providers."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        tools = [
            {
                "name": "Write",
                "description": "Write a file",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string"},
                        "content": {"type": "string"},
                    },
                    "required": ["file_path", "content"],
                },
            }
        ]
        
        openai_tools = client._convert_tools_to_openai_format(tools)
        
        assert openai_tools[0]["type"] == "function"
        assert openai_tools[0]["function"]["name"] == "Write"
        assert "parameters" in openai_tools[0]["function"]


class TestAutoApprove:
    """Tests for auto-approve functionality."""
    
    def test_auto_approve_enabled(self):
        """Test that auto-approve is enabled by default."""
        config = AppConfig()
        assert config.auto_approve_all is True
        assert config.permission_mode == "auto"
    
    def test_permission_config_auto_allows(self):
        """Test that AUTO mode allows all tools."""
        from openlaoke.types.permissions import PermissionConfig
        from openlaoke.types.core_types import PermissionMode, PermissionResult
        
        config = PermissionConfig.defaults()
        config.mode = PermissionMode.AUTO
        
        assert config.check_tool("Bash") == PermissionResult.ALLOW
        assert config.check_tool("Write") == PermissionResult.ALLOW
        assert config.check_tool("Edit") == PermissionResult.ALLOW
    
    def test_permission_config_bypass_allows(self):
        """Test that BYPASS mode allows all tools."""
        from openlaoke.types.permissions import PermissionConfig
        from openlaoke.types.core_types import PermissionMode, PermissionResult
        
        config = PermissionConfig.defaults()
        config.mode = PermissionMode.BYPASS
        
        assert config.check_tool("Bash") == PermissionResult.ALLOW
        assert config.check_tool("Write") == PermissionResult.ALLOW


class TestSkillIntegration:
    """Tests for skill system integration."""
    
    def test_skill_loading_from_directory(self):
        """Test loading skills from directory."""
        from openlaoke.core.skill_system import SkillRegistry
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            skill_dir = tmpdir / "test_skill"
            skill_dir.mkdir()
            (skill_dir / "SKILL.md").write_text("""---
name: test_skill
description: Test skill
allowed-tools:
  - Bash
---

# Test Skill

Instructions here.
""")
            
            registry = SkillRegistry()
            count = registry.add_skill_directory(tmpdir)
            
            assert count == 1
            assert registry.has_skill("test_skill")
    
    def test_active_skills_in_state(self):
        """Test that active skills are stored in state."""
        state = AppState()
        
        assert hasattr(state, "active_skills")
        assert state.active_skills == []
        
        state.active_skills.append("browse")
        assert "browse" in state.active_skills


class TestProviderSwitching:
    """Tests for switching between providers."""
    
    def test_switch_provider(self):
        """Test switching active provider."""
        config = MultiProviderConfig.defaults()
        
        config.active_provider = "minimax"
        assert config.active_provider == "minimax"
        
        config.active_provider = "ollama"
        assert config.active_provider == "ollama"
    
    def test_get_active_model(self):
        """Test getting active model."""
        config = MultiProviderConfig.defaults()
        config.active_provider = "minimax"
        
        model = config.get_active_model()
        assert model == "MiniMax-M2.7-highspeed"
        
        config.active_provider = "ollama"
        model = config.get_active_model()
        assert model == "gemma4:e2b"


class TestTokenAndCost:
    """Tests for token and cost tracking."""
    
    def test_token_accumulation(self):
        """Test accumulating tokens."""
        state = AppState()
        
        usage = type("TokenUsage", (), {
            "input_tokens": 100,
            "output_tokens": 50,
            "cache_read_tokens": 0,
            "cache_creation_tokens": 0,
        })()
        
        state.accumulate_tokens(usage)
        
        assert state.token_usage.input_tokens == 100
        assert state.token_usage.output_tokens == 50
        
        state.accumulate_tokens(usage)
        
        assert state.token_usage.input_tokens == 200
        assert state.token_usage.output_tokens == 100
    
    def test_cost_accumulation(self):
        """Test accumulating costs."""
        state = AppState()
        
        from openlaoke.types.core_types import CostInfo
        cost = CostInfo(input_cost=0.005, output_cost=0.005)
        
        state.accumulate_cost(cost)
        assert state.cost_info.total_cost == 0.01
        
        state.accumulate_cost(cost)
        assert state.cost_info.total_cost == 0.02