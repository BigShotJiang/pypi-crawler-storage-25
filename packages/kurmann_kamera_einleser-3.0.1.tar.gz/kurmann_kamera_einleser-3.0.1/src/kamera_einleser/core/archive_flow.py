"""Archive-Flow: Orchestriert den Tages-Archiv-Bau pro Quell-Verzeichnis.

Komponiert die Services zum kompletten Pipeline-Ablauf:

  Source-Scan → Disk-Space-Check → Idempotenz (Fall A/C) → ZIP-Bau
  → Manifest → Verifikation → Upload (upstream).

`.zip` (`ZIP_STORED`) ist seit 2.2.0 das Default-Format. Ab 3.0.0 wird
der ISO-Code-Pfad nicht mehr unterhalten — der Subset-Check läuft
ausschliesslich über `zip_inspector`; etwaige Legacy-`.iso`-Files im
lokalen Cache werden ignoriert.

Die Funktion bekommt ein fertiges `output_dir` rein — Working-Dir-Resolver
und Pull-Schritt passieren eine Ebene darüber in `api._process_source`.
"""

from __future__ import annotations

import unicodedata
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..config import get_config
from ..services.file_scanner import (
    calculate_directory_size,
    check_disk_space,
    get_all_files_with_day,
    get_existing_isos,
)
from ..services.manifest_cache import (
    filenames_archived_for_day,
    iso_names_archived,
    working_dirs_from_config,
)
from ..services.zip_builder import (
    ZipMember,
    create_zip,
    get_unique_archive_path,
)
from ..services.zip_inspector import check_files_in_existing_archive
from ..utils import format_size

if TYPE_CHECKING:
    from ..config import Config
    from ..services.file_scanner import FileInfo

console = Console()

# Disk-Space-Sicherheit beim Output-Dir-Check (ZIP-Build selbst — kein
# Staging mehr, deswegen ist 1.1× ausreichend).
SAFETY_MARGIN_FACTOR = 1.1


def create_archive(
    source_path: Path,
    output_dir: Path,
    archive_name: str | None = None,
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> tuple[bool, list[Path], set[Path]]:
    """Erstellt ZIP-Archive aus einem Quell-Verzeichnis — eines pro Tag.

    Dateien werden nach `recorded_at`-Day-Key gruppiert und pro Tag in eine
    `Originalmedien-YYYY-MM-DD.zip` verpackt (ZIP_STORED, ohne Kompression,
    streamingfähig direkt aus den Source-Pfaden).

    **Drei Fälle pro Tag**:

    1. **Kein lokales Archiv** → klassischer Fresh-Bau (neue `.zip`).
    2. **Bestehendes ZIP + neue Source-Files** → Append-Use-Case:
       `plan_append` (Lazy-Check gegen Server, Subset-Garantie), dann
       in-place Rebuild des ZIPs (alte Members per Stream-Copy + neue
       Files von Disk). Diese ZIP landet im `replace_archives`-Set,
       damit der Upload mit `--immutable=False` läuft.
    3. **Bestehende ISO + neue Source-Files** → eine separate `.zip`
       daneben wird gebaut (kein Append in die ISO; ISO bleibt
       unangetastet).

    Args:
        source_path: Quellverzeichnis.
        output_dir: Ziel für die Archive (vom Resolver vorgegeben).
        archive_name: Historischer Parameter, wird ignoriert.
        verbose: Steuert CLI-Ausgabe.
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        Tripel `(success, all_built, replace_archives)`:
        - `success`: Gesamterfolg
        - `all_built`: Liste aller neu erzeugten/aktualisierten Archive
        - `replace_archives`: Subset von `all_built`, das beim Upload
          den Server-Bestand ersetzen darf (`immutable=False`).
    """
    config = cfg if cfg is not None else get_config()
    excludes = config.get_excludes()

    if not source_path.exists():
        if verbose:
            console.print(
                f"[red]❌ Fehler: Quellverzeichnis existiert nicht: {source_path}[/red]"
            )
        return False, [], set()

    if not source_path.is_dir():
        if verbose:
            console.print(
                f"[red]❌ Fehler: Quelle ist kein Verzeichnis: {source_path}[/red]"
            )
        return False, [], set()

    if verbose:
        console.print(f"\n[bold]📊 Analysiere {source_path.name}...[/bold]")

    source_size_bytes = calculate_directory_size(source_path)
    if verbose:
        console.print(f"   Gesamtgröße: {format_size(source_size_bytes)}")

    if verbose:
        console.print(
            "\n[bold]📁 Gruppiere Dateien nach Aufnahmedatum (EXIF)...[/bold]"
        )

    files_by_day = get_all_files_with_day(source_path, excludes)

    if not files_by_day:
        if verbose:
            console.print(
                "[dim]ℹ️  Keine Dateien zum Archivieren (Quelle ist leer "
                "oder enthält nur ausgeschlossene Dateien)[/dim]"
            )
            console.print("[dim]   Quelle wird übersprungen[/dim]")
        return True, [], set()

    if verbose:
        console.print(
            f"   Gefunden: {sum(len(f) for f in files_by_day.values())} "
            f"Datei(en) in {len(files_by_day)} Tag(en)"
        )
        for day_key in sorted(files_by_day.keys()):
            files = files_by_day[day_key]
            day_size = sum(f.size for f in files)
            console.print(
                f"   - {day_key}: {len(files)} Datei(en) ({format_size(day_size)})"
            )

    # Disk-Space-Check (Output-Dir).
    if verbose:
        console.print("\n[bold]💾 Prüfe verfügbaren Speicherplatz...[/bold]")

    required_space = int(source_size_bytes * SAFETY_MARGIN_FACTOR)
    has_space, available_space = check_disk_space(output_dir, required_space)

    if verbose:
        console.print(f"   Verfügbar: {format_size(available_space)}")
        console.print(
            f"   Benötigt: {format_size(required_space)} (inkl. 10% Sicherheitsmarge)"
        )

    if not has_space:
        if verbose:
            console.print("[red]❌ Nicht genug Speicherplatz[/red]")
        return False, [], set()

    if verbose:
        console.print("   [green]✅ Genug Speicherplatz vorhanden[/green]")

    output_dir.mkdir(parents=True, exist_ok=True)

    # Existing Archives (.iso + .zip) für Fall-A.
    existing_archives = get_existing_isos(output_dir)

    if verbose:
        console.print("\n[bold]🔍 Prüfe bestehende Archive...[/bold]")

    archive_working_dirs = working_dirs_from_config(config)
    all_known_archive_names = iso_names_archived(archive_working_dirs)

    if verbose:
        if all_known_archive_names:
            console.print(
                f"   📋 {len(all_known_archive_names)} Archiv(e) mit lokalem "
                f"Manifest gefunden"
            )
        else:
            console.print("   📋 Keine Archiv-Manifests im Cache")
        console.print(
            "   ℹ️  Kollisionserkennung basiert auf lokalen Manifest-Sidecars"
        )

    # Tages-Schleife
    all_built: list[Path] = []
    replace_archives: set[Path] = set()
    skipped_days = 0

    for day_key in sorted(files_by_day.keys()):
        files = files_by_day[day_key]

        if verbose:
            console.print(f"\n{'=' * 60}")
            console.print(f"[bold]📅 Verarbeite Tag: {day_key}[/bold]")
            console.print(f"{'=' * 60}")

        # Append-Kandidat: lokales ZIP für diesen Tag (nur ZIPs lassen sich
        # ergänzen; ISO-Bestand bleibt unangetastet).
        existing_zip_for_day: Path | None = None

        # Auto-Fetch (Design C, ab 2.3.0): kein lokales Archiv für den Tag,
        # aber der Manifest-Cache kennt einen Archiv-Namen → wahrscheinlich
        # aus Cache-Window gepruned. Vor dem Fresh-Bau erst versuchen, das
        # Archiv vom Server zu holen, damit Append funktioniert statt
        # gegen --immutable zu laufen.
        if (
            day_key not in existing_archives
            and config.get_archive_auto_fetch()
            and _server_has_archive_for_day(day_key, config, verbose=verbose)
        ):
            fetched = _try_auto_fetch_for_day(
                day_key, output_dir, config, verbose=verbose
            )
            if fetched:
                existing_archives[day_key] = fetched
                if verbose:
                    console.print(
                        f"[green]   📥 Auto-Fetch: {len(fetched)} Archiv(e) "
                        f"vom Server geholt → wechsele in Fall-A-Pfad[/green]"
                    )

        # Fall A: lokales Archiv (ISO oder ZIP) vorhanden → Subset-Check
        if day_key in existing_archives:
            if verbose:
                console.print(
                    f"\n[bold]🔍 Prüfe bestehendes Archiv(e) für {day_key}...[/bold]"
                )
            missing_files = check_files_in_existing_archive(
                files, existing_archives[day_key], verbose=verbose
            )
            if not missing_files:
                if verbose:
                    console.print(
                        f"[green]✅ Alle {len(files)} Datei(en) bereits "
                        f"archiviert – überspringe Tag {day_key}[/green]"
                    )
                skipped_days += 1
                continue
            files = missing_files

            # ZIP für diesen Tag im lokalen Cache? → Append-Pfad
            existing_zip_for_day = next(
                (p for p in existing_archives[day_key] if p.suffix == ".zip"),
                None,
            )
            if verbose:
                if existing_zip_for_day is not None:
                    console.print(
                        f"[yellow]⚠️  {len(missing_files)} neue Datei(en) — "
                        f"erweitere bestehendes ZIP "
                        f"({existing_zip_for_day.name})[/yellow]"
                    )
                else:
                    console.print(
                        f"[yellow]⚠️  {len(missing_files)} neue Datei(en) — "
                        f"erstelle ZIP daneben zur bestehenden ISO[/yellow]"
                    )
        else:
            # Fall C: kein lokales Archiv, aber lokales Manifest deckt den
            # Tag bereits ab → überspringen.
            indexed_filenames = filenames_archived_for_day(
                archive_working_dirs, day_key
            )
            if indexed_filenames:
                source_filenames = {
                    unicodedata.normalize("NFC", f.path.name) for f in files
                }
                if source_filenames.issubset(indexed_filenames):
                    if verbose:
                        console.print(
                            f"[dim]📋 Alle {len(files)} Datei(en) laut "
                            f"Manifest archiviert (Archiv lokal nicht "
                            f"präsent) – überspringe Tag {day_key}[/dim]"
                        )
                    skipped_days += 1
                    continue

        # Build entscheiden: Append-Pfad oder Fresh-Bau?
        if existing_zip_for_day is not None:
            zip_path = _do_append_build(
                day_key=day_key,
                existing_zip=existing_zip_for_day,
                new_source_files=files,
                cfg=config,
                verbose=verbose,
            )
            if zip_path is None:
                return False, all_built, replace_archives
            all_built.append(zip_path)
            replace_archives.add(zip_path)
        else:
            zip_path = _do_fresh_build(
                day_key=day_key,
                source_files=files,
                output_dir=output_dir,
                known_names=all_known_archive_names,
                verbose=verbose,
            )
            if zip_path is None:
                return False, all_built, replace_archives
            all_built.append(zip_path)

        if verbose:
            console.print(f"[green]✅ Tag {day_key} verarbeitet[/green]")

    if verbose:
        created_count = len(all_built)
        if skipped_days > 0:
            console.print(
                f"\n[bold green]✅ {created_count} Archiv(e) erstellt, "
                f"{skipped_days} Tag(e) übersprungen (bereits archiviert)[/bold green]"
            )
        else:
            console.print(
                f"\n[bold green]✅ {created_count} Archiv(e) erstellt[/bold green]"
            )

    return True, all_built, replace_archives


def _do_fresh_build(
    *,
    day_key: str,
    source_files: list["FileInfo"],
    output_dir: Path,
    known_names: set[str],
    verbose: bool,
) -> Path | None:
    """Fresh-Bau: neue `.zip` mit allen Source-Files für diesen Tag.

    Returns:
        Pfad zur erzeugten ZIP, oder `None` bei Build-Fehler.
    """
    zip_path = get_unique_archive_path(
        output_dir, day_key, extension="zip", known_names=known_names
    )

    members = [
        ZipMember(
            source_path=f.path,
            arcname=str(f.relative_path).replace("\\", "/"),
            size=f.size,
        )
        for f in source_files
    ]

    if not create_zip(members, zip_path, verbose=verbose):
        return None

    try:
        _build_and_write_manifest(zip_path, members, verbose=verbose)
    except Exception as exc:
        if verbose:
            console.print(
                f"[yellow]⚠️  Manifest-Bau fehlgeschlagen für "
                f"{zip_path.name}: {exc}[/yellow]\n"
                f"   [dim]Archiv ist gut, Manifest kann via "
                f"`kamera-einleser manifest build {zip_path.name}` "
                f"nachgeholt werden.[/dim]"
            )

    return zip_path


def _do_append_build(
    *,
    day_key: str,
    existing_zip: Path,
    new_source_files: list["FileInfo"],
    cfg: "Config",
    verbose: bool,
) -> Path | None:
    """Append-Bau: bestehendes ZIP wird in-place ersetzt — alte Members
    werden per Stream-Copy übernommen, neue Source-Files angehängt.

    Schritte:

    1. `plan_append` (Lazy-Check gegen Server, Subset-Garantie).
    2. Old Manifest lesen (für Reuse der FileEntry-Objekte).
    3. ZIP in-place rebuilden (atomar via tempfile + os.replace).
    4. Manifest neu schreiben (alte Entries + neue Files).

    Returns:
        Pfad zur erweiterten ZIP, oder `None` bei Abort/Build-Fehler.
    """
    from ..services.archive_appender import plan_append
    from ..services.manifest_builder import (
        build_manifest_for_appended_zip,
        manifest_path_for_archive,
    )
    from ..services.manifest_io import read_manifest, write_manifest

    # 1. Plan-Check
    plan = plan_append(
        day_key=day_key,
        archive_name=existing_zip.name,
        new_source_files=new_source_files,
        local_archive_path=existing_zip,
        cfg=cfg,
        verbose=verbose,
    )

    if verbose:
        console.print(f"[dim]   {plan.safety.diagnostic}[/dim]")

    if not plan.proceed:
        console.print(
            f"[red]❌ Tag {day_key}: Append blockiert.[/red]\n"
            f"   [red]{plan.safety.diagnostic}[/red]"
        )
        return None

    # 2. Old-Manifest lesen für Entry-Reuse
    old_manifest_path = manifest_path_for_archive(existing_zip)
    reused_entries = []
    old_by_arcname: dict[str, object] = {}
    if old_manifest_path.exists():
        try:
            _, entries = read_manifest(old_manifest_path)
            old_by_arcname = {e.relative_path: e for e in entries}
        except Exception as exc:
            if verbose:
                console.print(
                    f"[yellow]⚠️  Altes Manifest unleserlich, baue Entries neu: {exc}[/yellow]"
                )

    # 3. Member-Liste: alte aus ZIP, neue von Disk
    members: list[ZipMember] = []
    new_sources: list[tuple[Path, str]] = []
    for f in plan.final_files:
        arc = str(f.relative_path).replace("\\", "/")
        if f.path == existing_zip:
            members.append(
                ZipMember(
                    source_path=existing_zip,
                    arcname=arc,
                    size=f.size,
                    source_arcname=arc,
                )
            )
            if arc in old_by_arcname:
                reused_entries.append(old_by_arcname[arc])
        else:
            members.append(
                ZipMember(
                    source_path=f.path,
                    arcname=arc,
                    size=f.size,
                )
            )
            new_sources.append((f.path, arc))

    # 4. In-place Rebuild
    if not create_zip(members, existing_zip, verbose=verbose):
        return None

    # 5. Manifest neu schreiben (reused + neue Entries)
    try:
        result = build_manifest_for_appended_zip(
            existing_zip,
            reused_entries=reused_entries,
            new_sources=new_sources,
            console=console,
            verbose=verbose,
        )
        if result.header is None:
            raise RuntimeError("Manifest-Builder lieferte keinen Header")
        write_manifest(old_manifest_path, result.header, result.entries)
    except Exception as exc:
        if verbose:
            console.print(
                f"[yellow]⚠️  Manifest-Bau fehlgeschlagen für "
                f"{existing_zip.name}: {exc}[/yellow]"
            )

    return existing_zip


def _build_and_write_manifest(
    zip_path: Path,
    members: list[ZipMember],
    *,
    verbose: bool = True,
) -> None:
    """Baut das Manifest für ein frisches ZIP und schreibt es daneben.

    SHA-256 + medien-leser-Metadaten kommen direkt aus den lokalen Source-
    Files (`ZIP_STORED` ist transparenter Container — Bytes identisch).
    """
    from ..services.manifest_builder import (
        build_manifest_for_zip_from_sources,
        manifest_path_for_archive,
    )
    from ..services.manifest_io import write_manifest

    out_path = manifest_path_for_archive(zip_path)
    if verbose:
        console.print(f"[dim]📋 Erzeuge Manifest:[/dim] {out_path.name}")

    sources = [(m.source_path, m.arcname) for m in members]
    result = build_manifest_for_zip_from_sources(
        zip_path, sources, console=console, verbose=verbose
    )

    if result.header is None:
        raise RuntimeError("Manifest-Builder lieferte keinen Header")

    write_manifest(out_path, result.header, result.entries)


def _server_has_archive_for_day(
    day_key: str,
    config: "Config",
    *,
    verbose: bool,
) -> bool:
    """Schnell-Check: hat das erste konfigurierte Target ein Archiv für
    diesen Tag? Sub-Sekunde, `rclone lsf` mit Include-Filter.

    Wird vor dem Auto-Fetch aufgerufen, damit wir nur dann den Listing-
    Aufruf machen, wenn überhaupt was zu holen ist.
    """
    from ..services.cache_fetch import _list_remote_archives_for_day
    from ..services.remote_manifest import first_target

    target = first_target(config)
    if target is None:
        return False
    archives = _list_remote_archives_for_day(target, day_key, verbose=verbose)
    return bool(archives)


def _try_auto_fetch_for_day(
    day_key: str,
    output_dir: Path,
    config: "Config",
    *,
    verbose: bool,
) -> list[Path]:
    """Versucht, alle Archive eines Tages vom ersten Target zu fetchen.

    Returns:
        Liste lokal verfügbarer Archiv-Pfade nach dem Fetch.
        Leer wenn Fetch fehlschlug oder das Target nichts hatte.
    """
    from ..services.cache_fetch import fetch_archives_for_day

    if verbose:
        console.print(
            f"[dim]   📥 Auto-Fetch versucht: Tag {day_key} ist nicht "
            f"im lokalen Cache, aber Server hat Archive…[/dim]"
        )
    fetch_result = fetch_archives_for_day(
        day_key, cfg=config, console=console
    )
    return fetch_result.fetched + fetch_result.skipped
