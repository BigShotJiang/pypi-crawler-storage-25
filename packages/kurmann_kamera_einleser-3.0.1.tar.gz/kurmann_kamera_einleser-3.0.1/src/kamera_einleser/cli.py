"""Command-line interface for kamera-einleser."""

from pathlib import Path
from typing import Annotated, Optional

import typer
from InquirerPy import inquirer
from rich.console import Console

from . import __version__
from .config import Config, get_config
from .interactive import (
    interactive_settings,
    manage_rclone_targets,
    manage_source_directories,
    show_current_config,
)
from .models import LocalSource, RuntimeOptions, SourceRef, parse_source_spec
from .rclone import check_rclone_available, list_iso_names_on_all_targets
from .services.file_scanner import cleanup_source_files

app = typer.Typer(
    name="kamera-einleser",
    help="Einfacher & solider Medien-Importeur. Archiviert Videoaufnahmen von SSD/iPhone/NAS in ZIP-Dateien pro Aufnahmetag.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"kamera-einleser version {__version__}")
        raise typer.Exit()


# Prozessweite Laufzeitoptionen, von --verbose/--quiet befüllt.
_runtime_options = RuntimeOptions()


def get_runtime_options() -> RuntimeOptions:
    """Liefert die aktuellen, prozessweiten RuntimeOptions (Root-CLI-Flags)."""
    return _runtime_options


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Zeige Version an",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            help="Ausführliche Ausgabe (zusätzliche Debug-Informationen).",
        ),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option(
            "--quiet",
            "-q",
            help="Stille Ausgabe (nur Fehler auf stderr).",
        ),
    ] = False,
) -> None:
    """Kamera-Einleser: Archiviert Videoaufnahmen von SSD/iPhone/NAS in ZIP-Dateien pro Aufnahmetag."""
    global _runtime_options
    try:
        _runtime_options = RuntimeOptions(verbose=verbose, quiet=quiet)
    except ValueError as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc


@app.command()
def settings() -> None:
    """
    Öffne die interaktiven Einstellungen.

    Ermöglicht die Konfiguration von:
    - Quellverzeichnissen
    - rclone Zielen
    - Arbeitsverzeichnis
    - Archiv-Einstellungen
    """
    interactive_settings()


config_app = typer.Typer(
    name="config",
    help="Konfiguration anzeigen, setzen und auflisten.",
    no_args_is_help=False,
    invoke_without_command=True,
)
app.add_typer(config_app, name="config")


@config_app.callback()
def _config_root(ctx: typer.Context) -> None:
    """Ohne Subcommand: aktuelle Konfiguration ausgeben (wie bisher)."""
    if ctx.invoked_subcommand is None:
        show_current_config()


@config_app.command("show")
def config_show() -> None:
    """Zeigt die aktuelle Konfiguration in Tabellen-Form an."""
    show_current_config()


@config_app.command("path")
def config_path() -> None:
    """Gibt den Pfad der aktiven Konfigurationsdatei auf stdout aus."""
    typer.echo(str(get_config().config_path))


@config_app.command("list")
def config_list() -> None:
    """Listet alle Config-Schlüssel und -Werte als TOML auf stdout."""
    import tomli_w

    cfg = get_config()
    from .config import _sanitize_for_toml

    typer.echo(tomli_w.dumps(_sanitize_for_toml(cfg.list_all())).rstrip())


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config-Schlüssel, z.B. 'working_directory'")],
) -> None:
    """Gibt den Wert eines Config-Schlüssels auf stdout aus."""
    cfg = get_config()
    try:
        value = cfg.get_value(key)
    except KeyError as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc
    typer.echo(value if not isinstance(value, (list, dict)) else repr(value))


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="Config-Schlüssel")],
    value: Annotated[str, typer.Argument(help="Neuer Wert (String, Zahl, Boolean)")],
) -> None:
    """Setzt einen Config-Schlüssel und persistiert die Änderung."""
    cfg = get_config()
    try:
        coerced = cfg.set_value(key, value)
    except (KeyError, TypeError, ValueError) as exc:
        err_console.print(f"[red]❌ {exc}[/red]")
        raise typer.Exit(2) from exc
    cfg.save()
    console.print(f"[green]✅[/green] {key} = {coerced!r}")


# Hinweis: `_process_single_source` wurde in 1.5.0 entfernt; die Archive-
# Pipeline läuft ausschliesslich über `api._process_source`, das zusätzlich
# RcloneSource + per-source Workdir-Resolver abdeckt.


def _startup_guard_against_empty_cache(cfg: "Config") -> None:
    """Hartes Abbruch-Signal, wenn der Manifest-Cache leer ist aber Remotes
    bereits Archive haben.

    Motivation: auf einem frisch eingerichteten zweiten Rechner ohne lokale
    Manifest-Sidecars würde `archive` alle Dateien neu archivieren, Base-
    Namen vergeben und beim Upload an `rclone --immutable` scheitern.
    Stunden verschwendet, für nichts.

    Der Guard fängt das vor dem ersten Byte Netz-Transfer ab. Recovery:
    Manifests vom Server in den lokalen Cache pullen (z.B. via `rclone copy`
    der `*.manifest.jsonl`-Files). Mit `--force` lässt sich der Guard bewusst
    überstimmen.
    """
    from .services.manifest_cache import (
        iso_names_archived,
        working_dirs_from_config,
    )

    local_known = iso_names_archived(working_dirs_from_config(cfg))
    if local_known:
        return

    # Cache leer → Remote-Ziele fragen
    remote_names = list_iso_names_on_all_targets(verbose=False)
    if not remote_names:
        # Cache leer UND Remote leer → erster Lauf auf neuem Setup,
        # alles korrekt. Kein Guard nötig.
        return

    err_console.print(
        "[red]❌ Abbruch: kein lokales Manifest, aber auf den konfigurierten "
        f"Targets existieren {len(remote_names)} Archiv(e).[/red]"
    )
    err_console.print(
        "\n[yellow]Ohne Manifest-Cache würden alle Dateien neu archiviert, Base-"
        "Namen vergeben und beim Upload an rclone --immutable abgelehnt.[/yellow]"
    )
    err_console.print(
        "\n[bold green]Empfohlen[/bold green] — alle Manifests vom ersten Target holen:\n"
        "    [bold]kamera-einleser cache sync-manifests[/bold]\n"
        "\n[dim](pullt sub-Sekunde pro Manifest, KBs jeweils — danach läuft "
        "der Pre-Filter normal.)\n"
        "\nOder, wenn du bewusst von vorne archivieren willst (z.B. nach "
        "kompletter Remote-Löschung): [bold]--force[/bold].[/dim]"
    )
    raise typer.Exit(2)


# 2.2.0: Die `index push/pull/rebuild`-Subapp ist entfernt. Manifests sind
# selbst die Cross-Machine-Wahrheit (werden mit der ISO/ZIP zum Target hochgeladen),
# `*.uploaded.json`-Marker liefert die Replikations-Garantie pro Maschine.


# ---------------------------------------------------------------------------
# `kamera-einleser manifest ...` — Sidecar-Manifests pro ISO (ab 2.0.0)
# ---------------------------------------------------------------------------
manifest_app = typer.Typer(
    name="manifest",
    help="Manifest-Sidecars anzeigen.",
    no_args_is_help=True,
)
app.add_typer(manifest_app, name="manifest")


# 3.0.0: `manifest build` (Single-ISO-Indexierung via hdiutil-Mount) ist
# entfernt. Manifests werden ausschliesslich beim ZIP-Bau im `archive`-Flow
# erzeugt; verlorene Sidecars holt man via `cache fetch <day>` oder
# rebuildet sie durch erneutes Archivieren der Source.


@manifest_app.command("show")
def manifest_show(
    manifest_path: Annotated[
        Path,
        typer.Argument(
            help="Pfad zur Manifest-Datei (.manifest.jsonl).",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            resolve_path=True,
        ),
    ],
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-n",
            help="Maximale Anzahl angezeigter File-Einträge (0 = alle).",
        ),
    ] = 5,
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            "-f",
            help=(
                "Zeige jedes File-Entry als vollständigen, syntax-"
                "highlighted JSON-Block — wie 'jq' es ausgeben würde. "
                "Default ist eine kuratierte Übersicht."
            ),
        ),
    ] = False,
) -> None:
    """Zeigt ein Manifest in lesbarer Form an (Header + Einträge).

    Default-Modus zeigt eine kuratierte Übersicht der wichtigsten Felder.
    Mit `--full` kommt pro Entry der ganze JSON-Block mit allen ~30
    Feldern raus, syntax-highlighted (wie `jq | head` aber schöner).
    """
    import json

    from rich.json import JSON

    from .services.manifest_io import read_manifest
    from .utils import format_size

    try:
        header, entries = read_manifest(manifest_path)
    except Exception as exc:
        err_console.print(f"[red]❌ Manifest unlesbar: {exc}[/red]")
        raise typer.Exit(2) from exc

    console.print(f"\n[bold]📋 {header.iso_name}[/bold]")
    console.print(f"   Format-Version: {header.manifest_version}")
    console.print(f"   Archiv-Grösse:  {format_size(header.iso_size)}")
    console.print(f"   Archiv-SHA-256: {header.iso_sha256[:16]}…")
    console.print(f"   Dateien:        {header.file_count}")
    console.print(f"   Total Bytes:    {format_size(header.total_bytes)}")
    console.print(f"   Erstellt:       {header.created_at}")
    console.print(f"   Tool-Version:   {header.tool_version}")

    if not entries:
        console.print("\n[dim](keine File-Einträge)[/dim]")
        return

    show = entries if limit <= 0 else entries[:limit]

    if full:
        console.print(
            f"\n[bold]Datei-Einträge[/bold] (zeige {len(show)}/{len(entries)}, "
            "vollständiger JSON):"
        )
        for entry in show:
            console.print()
            console.print(
                JSON(json.dumps(entry.to_dict(), ensure_ascii=False))
            )
        return

    console.print(f"\n[bold]Datei-Einträge[/bold] (zeige {len(show)}/{len(entries)}):")
    for entry in show:
        console.print(f"\n  [cyan]{entry.relative_path}[/cyan]")
        if entry.source_app:
            console.print(f"    [bold magenta]source_app:[/bold magenta]    {entry.source_app}")
        console.print(f"    sha256:        {entry.sha256[:16]}…")
        console.print(f"    size:          {format_size(entry.size)}")
        if entry.recorded_at:
            console.print(
                f"    recorded_at:   {entry.recorded_at}  "
                f"[dim]({entry.recorded_at_source})[/dim]"
            )
        if entry.video.codec or entry.video.resolution:
            console.print(
                f"    video:         {entry.video.codec or '?'}  "
                f"{entry.video.resolution or ''}  "
                f"{(str(entry.video.fps) + ' fps') if entry.video.fps else ''}"
            )
        if entry.camera.make or entry.camera.model:
            cam_line = (
                f"    camera:        {entry.camera.make or ''} "
                f"{entry.camera.model or ''}"
            )
            if entry.camera.lens:
                cam_line += f"  [dim]· {entry.camera.lens}[/dim]"
            console.print(cam_line)
        if entry.gps:
            alt = (
                f", {entry.gps.altitude_m:.0f}m" if entry.gps.altitude_m else ""
            )
            console.print(
                f"    gps:           {entry.gps.lat:.5f}, {entry.gps.lon:.5f}{alt}"
            )
        if entry.production.project or entry.production.clip_id:
            console.print(
                f"    production:    project={entry.production.project!r} "
                f"clip={entry.production.clip_id!r}"
            )

    if limit > 0 and len(entries) > limit:
        console.print(
            f"\n[dim]… {len(entries) - limit} weitere Einträge "
            f"(mit --limit 0 alle anzeigen)[/dim]"
        )


# ---------------------------------------------------------------------------
# `kamera-einleser audit ...` — Diagnose-Befehle über bestehende Manifests
# (ab 2.0.0). Read-only, ändern nichts.
# ---------------------------------------------------------------------------
audit_app = typer.Typer(
    name="audit",
    help="Diagnose-Befehle über bestehende Archiv-Manifests.",
    no_args_is_help=True,
)
app.add_typer(audit_app, name="audit")


# ---------------------------------------------------------------------------
# 3.0.0: Die `convert iso-to-zip`-Sub-App und der ISO-Konverter sind entfernt.
# Bestand-Migration (1.x/2.0.x ISOs → 2.2.x/2.3.x ZIPs) war ein Übergangs-
# Tool, das in 2.3.0/2.3.1 verfügbar war. Ab 3.0.0 wird der ISO-Code-Pfad
# nicht mehr unterhalten — verbliebene ISO-Bestände müssen vor dem Update
# auf einer 2.3.x-Installation konvertiert werden.
# ---------------------------------------------------------------------------


@audit_app.command("archive-grouping")
def audit_archive_grouping(
    paths: Annotated[
        list[Path],
        typer.Argument(
            help=(
                "Pfade zu Manifest-Dateien (.manifest.jsonl) ODER zu "
                "Verzeichnissen mit solchen. Verzeichnisse werden rekursiv "
                "abgesucht."
            ),
            exists=True,
            resolve_path=True,
        ),
    ],
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Maschinenlesbarer JSON-Output statt formatierter Tabelle.",
        ),
    ] = False,
    verbose_clean: Annotated[
        bool,
        typer.Option(
            "--verbose-clean",
            help=(
                "Auch Archive mit korrekter Tag-Gruppierung im Detail anzeigen. "
                "Default: nur als '✅ ok' in der Übersicht."
            ),
        ),
    ] = False,
) -> None:
    """Prüft pro Archiv, ob alle Files zum erwarteten Tag im Archiv-Namen gehören.

    Hintergrund: bis 1.x gruppierte kamera-einleser nach Filesystem-`mtime`,
    das oft die Übertragungs-Zeit ist und nicht das echte Aufnahmedatum.
    Resultat: ein Archiv `Originalmedien-2026-04-29.zip` (oder vor 3.0.0
    auch .iso) kann Files aus dem März/April enthalten — der Audit zeigt,
    wie schlimm das ist.

    Funktioniert auf einem einzelnen Manifest:
        kamera-einleser audit archive-grouping ~/Downloads/X.zip.manifest.jsonl

    Oder auf einem ganzen Verzeichnis (rekursiv):
        kamera-einleser audit archive-grouping ~/Downloads/2026-Test-Auszug/

    Mit --json kannst du den Output in andere Tools pipen.
    """
    import json as _json

    from .services.audit import (
        audit_iso_grouping as run_audit,
    )
    from .services.audit import (
        discover_manifests,
    )

    # Manifests einsammeln
    manifests: list[Path] = []
    for p in paths:
        found = discover_manifests(p)
        if not found:
            err_console.print(
                f"[yellow]⚠️  Keine Manifests gefunden unter: {p}[/yellow]"
            )
        manifests.extend(found)

    if not manifests:
        err_console.print(
            "[red]❌ Keine Manifests zu prüfen.[/red] "
            "Erst mit [bold]manifest build[/bold] indexieren."
        )
        raise typer.Exit(2)

    report = run_audit(manifests)

    if json_output:
        # Maschinen-Output
        out = {
            "summary": {
                "total": report.total,
                "clean": report.clean_count,
                "mixed": report.mixed_count,
                "unparsable": report.unparsable_count,
            },
            "findings": [_finding_to_dict(f) for f in report.findings],
        }
        typer.echo(_json.dumps(out, ensure_ascii=False, indent=2))
        if report.mixed_count > 0:
            raise typer.Exit(1)
        return

    # Lesbar
    console.print(
        f"\n[bold]🔍 Archiv-Grouping-Audit[/bold] "
        f"({report.total} Manifest{'s' if report.total != 1 else ''})\n"
    )

    for f in report.findings:
        # Saubere Archive in Übersicht stark verkürzen, ausser --verbose-clean
        if f.is_clean and not verbose_clean:
            console.print(
                f"  {f.status_emoji} [green]{f.iso_name}[/green] "
                f"— {f.file_count} File(s), alle vom {f.expected_day}"
            )
            continue
        _print_finding_detail(f)

    console.print(
        f"\n[bold]Zusammenfassung:[/bold]"
        f"\n   ✅ Sauber gruppiert: {report.clean_count}"
        f"\n   ⚠️  Misch-Tag-Archive: {report.mixed_count}"
        f"\n   ❓ Nicht parsbar:    {report.unparsable_count}"
    )

    if report.mixed_count > 0:
        console.print(
            "\n[dim]Misch-Tag-Archive entstehen typisch durch mtime-basierte "
            "Gruppierung in 1.x — Files vom 15.04. wurden am 29.04. kopiert "
            "(mtime=29.04.), landeten in Originalmedien-2026-04-29.iso.[/dim]"
        )
        # Exit 1 → Skripte können das auswerten
        raise typer.Exit(1)


def _print_finding_detail(f) -> None:  # type: IsoGroupingFinding
    from rich.table import Table

    header = (
        f"\n  {f.status_emoji} [bold]{f.iso_name}[/bold]"
        f" — {f.file_count} File(s)"
    )
    if f.expected_day is None:
        header += "  [dim](Archiv-Name nicht parsbar — kein erwarteter Tag)[/dim]"
    console.print(header)

    if f.files_without_recorded_at > 0:
        console.print(
            f"     [yellow]{f.files_without_recorded_at} File(s) ohne "
            "recorded_at[/yellow]"
        )

    if f.expected_day:
        console.print(
            f"     erwartet: [cyan]{f.expected_day}[/cyan]  "
            f"·  passend: {f.files_matching_expected}  "
            f"·  off-day: {f.files_off_day}"
        )

    if f.earliest_recorded_at:
        console.print(
            f"     ältest:  {f.earliest_recorded_at}  "
            f"·  jüngst: {f.latest_recorded_at}"
        )

    # Tag-Verteilung als kompakte Tabelle
    if f.days_seen:
        table = Table(show_header=True, header_style="bold", padding=(0, 1))
        table.add_column("Tag", style="cyan")
        table.add_column("Files", justify="right")
        table.add_column("", style="dim")
        for day, count in sorted(f.days_seen.items()):
            marker = "← Archiv-Tag" if day == f.expected_day else ""
            table.add_row(day, str(count), marker)
        console.print("    ", table)


def _finding_to_dict(f) -> dict:  # type: IsoGroupingFinding
    return {
        "iso_name": f.iso_name,
        "expected_day": f.expected_day,
        "file_count": f.file_count,
        "files_matching_expected": f.files_matching_expected,
        "files_off_day": f.files_off_day,
        "files_without_recorded_at": f.files_without_recorded_at,
        "days_seen": dict(f.days_seen),
        "earliest_recorded_at": f.earliest_recorded_at,
        "latest_recorded_at": f.latest_recorded_at,
        "is_clean": f.is_clean,
        "manifest_path": str(f.manifest_path),
    }


# 3.0.0: Der deprecated `audit iso-grouping`-Alias (Synonym für
# `audit archive-grouping`) wurde wie in 2.3.0 angekündigt entfernt.
# Verwende ab sofort den kanonischen Namen `audit archive-grouping`.


# ---------------------------------------------------------------------------
# `kamera-einleser cache ...` — Operator-Kommandos rund um den lokalen
# Archiv-Cache (ab 1.8.0)
# ---------------------------------------------------------------------------
cache_app = typer.Typer(
    name="cache",
    help="Lokaler Archiv-Cache verwalten (list, prune, fetch, sync-manifests, resync).",
    no_args_is_help=True,
)
app.add_typer(cache_app, name="cache")


@cache_app.command("list")
def cache_list() -> None:
    """Listet alle lokalen Archive mit Grösse, Alter und Replikations-Status."""
    from rich.table import Table

    from .cache_ops import list_local_iso_cache
    from .utils import format_size

    cfg = get_config()
    entries = list_local_iso_cache(cfg=cfg)

    if not entries:
        console.print("[dim]Keine Archive im lokalen Cache.[/dim]")
        return

    table = Table(title="Lokaler Archiv-Cache (älteste zuerst)")
    table.add_column("Archiv", style="cyan")
    table.add_column("Tag", style="dim")
    table.add_column("Grösse", justify="right")
    table.add_column("mtime", style="dim")
    table.add_column("Repliziert")

    total = 0
    for e in entries:
        total += e.size
        marker = "[green]✓[/green]" if e.is_replicated else "[yellow]—[/yellow]"
        table.add_row(
            e.path.name,
            e.day_key,
            format_size(e.size),
            e.mtime.strftime("%Y-%m-%d %H:%M"),
            marker,
        )

    console.print(table)
    limit = cfg.get_archive_cache_max_bytes()
    limit_str = format_size(limit) if limit > 0 else "[dim]unlimited[/dim]"
    console.print(
        f"\n[bold]Total:[/bold] {format_size(total)} in {len(entries)} "
        f"Archiv(e)  |  Limit: {limit_str}"
    )


@cache_app.command("prune")
def cache_prune(
    max_size_gb: Annotated[
        float,
        typer.Option(
            "--max-size-gb",
            help="Bytes-Obergrenze in GB (Default: aus Config archive_cache_max_bytes).",
        ),
    ] = 0.0,
    max_days: Annotated[
        int,
        typer.Option(
            "--max-days",
            help="Cache-Window in Tagen (Default: aus Config archive_cache_max_days).",
        ),
    ] = -1,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Nur zeigen, was gelöscht würde — Filesystem bleibt unberührt.",
        ),
    ] = False,
) -> None:
    """Entfernt replizierte Archive: Tag-basiert (Variante C, 7 Tage Default)
    plus Bytes-Backstop.

    Ohne Flags greifen die Config-Defaults (`archive_cache_max_days`,
    `archive_cache_max_bytes`). Nur Archive mit vollständigem
    `*.uploaded.json`-Marker werden gelöscht.
    """
    from .cache_ops import prune_local_iso_cache

    cfg = get_config()
    effective_bytes = (
        int(max_size_gb * 10**9) if max_size_gb > 0 else cfg.get_archive_cache_max_bytes()
    )
    effective_days = (
        max_days if max_days >= 0 else cfg.get_archive_cache_max_days()
    )

    prune_local_iso_cache(
        max_bytes=effective_bytes,
        max_days=effective_days,
        dry_run=dry_run,
        cfg=cfg,
        console=console,
    )


@cache_app.command("resync")
def cache_resync(
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Nur zeigen, was getan würde — kein Upload, kein Index-Update.",
        ),
    ] = False,
) -> None:
    """Lädt nicht-replizierte Cache-Archive erneut zu allen Targets hoch.

    Recovery-Pfad nach partial-upload (z.B. Mega.nz war down beim letzten
    `archive`-Lauf): das Archiv liegt noch lokal im Cache, aber sein
    `*.uploaded.json`-Marker bestätigt nicht alle aktuell konfigurierten
    Targets.

    `cache resync` versucht für jedes solche Archiv erneut den Upload zu
    allen Targets. `rclone --immutable` schützt OK-Targets vor Doppel-
    Upload, fehlende Targets kriegen das Archiv. Bei vollständigem Erfolg
    wird der Marker aktualisiert. Kein erneuter Pull aus der Source nötig.
    """
    from .cache_ops import resync_cache_to_targets

    result = resync_cache_to_targets(
        dry_run=dry_run, cfg=get_config(), console=console
    )
    if result.isos_failed:
        raise typer.Exit(1)


@cache_app.command("fetch")
def cache_fetch(
    target_arg: Annotated[
        str,
        typer.Argument(
            metavar="DAY-OR-ARCHIVE",
            help=(
                "Entweder ein Tag (YYYY-MM-DD) — dann werden alle Archive für "
                "diesen Tag gepullt — oder ein expliziter Archiv-Name "
                "(Originalmedien-YYYY-MM-DD[-Teil-N].zip)."
            ),
        ),
    ],
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Nur zeigen, was gepullt würde — kein rclone copy.",
        ),
    ] = False,
) -> None:
    """Holt Archive vom ersten konfigurierten rclone-Target in den lokalen Cache.

    Nützlich, wenn ein Tag aus dem Cache-Window gepruned wurde und du wieder
    Zugriff brauchst (Audit, Konvertierung, etc.). Archiv + Manifest-Sidecar
    wandern ins primary working_directory.

    `*.uploaded.json`-Marker werden NICHT gepullt (maschinenlokal). Gefetched
    Archive werden also nicht automatisch geprunt, bevor du sie ggf. mit
    `cache resync` neu replizierst.
    """
    import re

    from .services.cache_fetch import fetch_archive, fetch_archives_for_day

    cfg = get_config()

    if re.match(r"^\d{4}-\d{2}-\d{2}$", target_arg):
        result = fetch_archives_for_day(
            target_arg, cfg=cfg, dry_run=dry_run, console=console
        )
    else:
        result = fetch_archive(
            target_arg, cfg=cfg, dry_run=dry_run, console=console
        )

    if result.failed:
        raise typer.Exit(1)


@cache_app.command("sync-manifests")
def cache_sync_manifests(
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Nur zeigen, was gepullt würde — kein rclone copy.",
        ),
    ] = False,
) -> None:
    """Holt **alle** Manifest-Sidecars vom ersten konfigurierten rclone-Target
    in den lokalen Cache.

    Foundation-Befehl für neue Rechner: macht den lokalen Manifest-Cache
    sofort vollständig, ohne dass du jeden Tag einzeln via `cache fetch`
    holen musst. Damit passiert der Startup-Guard, Pre-Filter funktioniert,
    und der Konverter findet vorhandene Manifest-Info beim Bauen.

    Pro Manifest ein rclone-Aufruf, KB-Pulls in Sub-Sekunden. Bei 100+
    Archiven dauert das ein bis zwei Minuten total.

    Sidecars werden FLAT ins primary working_directory gelegt — analog
    zum 2.x-Layout (keine Jahres-Unterordner).
    """
    from .services.cache_fetch import sync_all_manifests_from_target

    result = sync_all_manifests_from_target(
        cfg=get_config(),
        dry_run=dry_run,
        console=console,
    )
    if result.failed:
        raise typer.Exit(1)


@app.command()
def archive(
    source: Annotated[
        Optional[Path],
        typer.Argument(
            help="Quellverzeichnis zum Archivieren (optional, sonst alle konfigurierten Quellen)",
        ),
    ] = None,
    name: Annotated[
        Optional[str],
        typer.Option(
            "--name",
            "-n",
            help="Name für das Archiv (ignoriert, Tag wird verwendet)",
        ),
    ] = None,
    no_upload: Annotated[
        bool,
        typer.Option(
            "--no-upload",
            help="Nur Archiv erstellen, nicht hochladen",
        ),
    ] = False,
    no_cleanup: Annotated[
        bool,
        typer.Option(
            "--no-cleanup",
            help="Archive nach Upload nicht löschen (Standard: bleiben erhalten)",
        ),
    ] = False,
    delete_source: Annotated[
        bool,
        typer.Option(
            "--delete-source",
            help="Originaldateien nach erfolgreichem Backup löschen (fragt am Ende interaktiv nach)",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            help=(
                "Startup-Guard umgehen: auch archivieren, wenn der lokale "
                "Manifest-Cache leer ist obwohl auf Targets Archive liegen. "
                "Nur bewusst verwenden — sonst droht massenhafter "
                "immutable-Upload-Fehler."
            ),
        ),
    ] = False,
    full_pull: Annotated[
        bool,
        typer.Option(
            "--full-pull",
            help=(
                "Für rclone-Quellen: Manifest-Pre-Filter umgehen und alle Dateien "
                "erneut pullen. Standard ist effizienter Diff-Pull."
            ),
        ),
    ] = False,
    prune_cache: Annotated[
        Optional[bool],
        typer.Option(
            "--prune-cache/--no-prune-cache",
            help=(
                "Nach erfolgreichem Lauf den lokalen Archiv-Cache auto-prunen "
                "(Default: folgt Config archive_cache_max_days + archive_cache_max_bytes). "
                "--prune-cache erzwingt auch bei beiden Limits=0, --no-prune-cache "
                "überspringt selbst bei gesetzten Limits."
            ),
        ),
    ] = None,
    auto_fetch: Annotated[
        Optional[bool],
        typer.Option(
            "--auto-fetch/--no-auto-fetch",
            help=(
                "Wenn Files für einen Tag auftauchen, dessen Archiv nicht lokal "
                "im Cache liegt (z.B. ausserhalb der Cache-Window), automatisch "
                "vom ersten Target fetchen statt am --immutable zu scheitern. "
                "Default: folgt Config archive_auto_fetch (True)."
            ),
        ),
    ] = None,
) -> None:
    """
    Archiviere Kameraaufnahmen und synchronisiere sie zu den konfigurierten Zielen.

    Dieser Befehl:
    1. Erstellt ZIP-Archive pro Tag (gruppiert nach echtem Aufnahmedatum aus EXIF)
    2. Schreibt ein Manifest-Sidecar (`*.zip.manifest.jsonl`) pro Archiv
    3. Führt Integritätsprüfung durch (ZIP-CRC32 pro Member)
    4. Synchronisiert zu allen konfigurierten rclone-Zielen (in Jahresordner)
    5. Fragt am Ende optional nach dem Löschen der Originaldateien

    Bei mehreren konfigurierten Quellen werden diese sequenziell verarbeitet.
    Die Frage nach dem Löschen kommt erst ganz am Ende, nachdem alle Quellen
    erfolgreich archiviert wurden.
    """
    cfg = get_config()

    # Check rclone availability
    if not no_upload:
        if not check_rclone_available():
            console.print(
                "[red]❌ Fehler: rclone ist nicht installiert oder nicht im PATH[/red]"
            )
            raise typer.Exit(1)

    # Startup-Guard (ab 2.2.0 manifest-basiert): leerer Manifest-Cache + bereits
    # gefüllte Remotes → harter Abort. Verhindert das "Second-Mac"-Problem:
    # frisch geklonter Rechner ohne lokale Manifests, archive würde Base-Namen
    # neu vergeben und an rclone --immutable abprallen.
    if not no_upload and not force:
        _startup_guard_against_empty_cache(cfg)

    # Determine source directories to process (lokal + rclone)
    sources_to_process: list[SourceRef] = []

    if source:
        source_path = source.resolve()
        if not source_path.exists():
            console.print(f"[red]❌ Fehler: Quellverzeichnis existiert nicht: {source_path}[/red]")
            raise typer.Exit(1)
        sources_to_process = [LocalSource(path=source_path)]
    else:
        source_dirs = cfg.get_source_directories()
        if not source_dirs:
            console.print(
                "[red]❌ Fehler: Kein Quellverzeichnis angegeben und keines konfiguriert[/red]"
            )
            console.print("Verwende 'kamera-einleser settings' um Quellverzeichnisse zu konfigurieren.")
            raise typer.Exit(1)

        parsed: list[SourceRef] = []
        for entry in source_dirs:
            try:
                ref = parse_source_spec(entry)
            except ValueError as exc:
                console.print(f"[red]❌ Ungültige Quelle '{entry}': {exc}[/red]")
                continue
            if isinstance(ref, LocalSource) and not ref.path.exists():
                # Info-Level: es ist normal, dass Wechselmedien (SD, SSD)
                # nicht permanent am Rechner hängen.
                console.print(
                    f"[dim]ℹ️  Lokal-Quelle nicht angeschlossen (übersprungen): {ref.path}[/dim]"
                )
                continue
            parsed.append(ref)

        if not parsed:
            console.print(
                "[red]❌ Fehler: Keine der konfigurierten Quellen ist aktuell erreichbar[/red]"
            )
            raise typer.Exit(1)

        sources_to_process = parsed
        if len(parsed) > 1:
            console.print(
                f"\nℹ️  Verarbeite automatisch alle {len(parsed)} konfigurierten Quellen"
            )

    # Check targets configuration
    if not no_upload:
        targets = cfg.get_rclone_targets()
        if not targets:
            console.print(
                "[red]❌ Fehler: Keine rclone-Ziele konfiguriert[/red]"
            )
            console.print("Verwende 'kamera-einleser settings' um Ziele zu konfigurieren.")
            raise typer.Exit(1)

    # Arbeitsverzeichnisse (Primär + optional Fallback) werden pro Quelle
    # nach Platzbedarf aufgelöst (siehe Config.resolve_working_directory).
    primary_wd = cfg.get_working_directory()
    fallback_wd = cfg.get_working_directory_fallback()

    console.print("\n" + "=" * 60)
    console.print("[bold]🎬 Kamera-Einleser: Archivierung starten[/bold]")
    console.print("=" * 60)
    console.print(f"\n[bold]Quellen:[/bold] {len(sources_to_process)} zu verarbeiten")
    for s in sources_to_process:
        console.print(f"   - {s.describe()}")
    console.print(f"[bold]Arbeitsverzeichnis (primär):[/bold] {primary_wd or '(Temp)'}")
    if fallback_wd:
        console.print(f"[bold]Arbeitsverzeichnis (Fallback):[/bold] {fallback_wd}")
    if not no_upload:
        console.print(f"[bold]Ziele:[/bold] {len(cfg.get_rclone_targets())} konfiguriert")

    # Process each source sequentially
    all_success = True
    # CLI-Override des Auto-Fetch-Verhaltens vor api.archive (mutiert die
    # Process-lokale Config — der Prozess endet eh nach diesem Lauf).
    if auto_fetch is not None:
        cfg.set_value(
            "archive_auto_fetch", "true" if auto_fetch else "false"
        )

    all_archive_files: list[Path] = []
    successful_sources: list[SourceRef] = []
    failed_sources: list[SourceRef] = []

    for i, src in enumerate(sources_to_process, 1):
        console.print(f"\n{'#' * 60}")
        console.print(f"[bold]Quelle {i}/{len(sources_to_process)}: {src.describe()}[/bold]")
        console.print(f"{'#' * 60}")

        # Alle Quellen laufen durch api._process_source; der Resolver dort
        # wählt pro Quelle den passenden Arbeitsordner (primär → Fallback).
        from .api import _process_source as _api_process_source

        success, archive_files = _api_process_source(
            source=src,
            working_dir_override=None,
            no_upload=no_upload,
            verbose=True,
            full_pull=full_pull,
            cfg=cfg,
        )

        all_archive_files.extend(archive_files)

        if success:
            successful_sources.append(src)
        else:
            failed_sources.append(src)
            all_success = False

    # Summary
    console.print("\n" + "=" * 60)
    console.print("[bold]📊 Zusammenfassung[/bold]")
    console.print("=" * 60)
    console.print(f"   Erfolgreich: {len(successful_sources)}/{len(sources_to_process)}")

    if successful_sources:
        for s in successful_sources:
            console.print(f"   [green]✅ {s.describe()}[/green]")

    if failed_sources:
        for s in failed_sources:
            console.print(f"   [red]❌ {s.describe()}[/red]")

    # Originaldateien löschen: nur bei lokalen Quellen sinnvoll
    local_successful = [s for s in successful_sources if isinstance(s, LocalSource)]
    if delete_source and all_success and local_successful:
        console.print("\n" + "-" * 60)
        console.print("[bold]Originaldateien löschen?[/bold]")
        console.print("-" * 60)

        for src in local_successful:
            should_delete = inquirer.confirm(
                message=f"Originaldateien löschen? ({src.path})",
                default=False,
            ).execute()

            if should_delete:
                cleanup_source_files(src.path, verbose=True)
            else:
                console.print(f"[yellow]⚠️ Originaldateien behalten: {src.path}[/yellow]")

    # Auto-Prune des lokalen Cache:
    # - 1.8.0: Bytes-basiert (archive_cache_max_bytes, 3.0.0 umbenannt)
    # - 2.2.0: zusätzlich Tag-basiert (archive_cache_max_days, Variante C)
    # CLI-Flag --prune-cache / --no-prune-cache überstimmt beide Defaults.
    if all_success:
        cache_max_bytes = cfg.get_archive_cache_max_bytes()
        cache_max_days = cfg.get_archive_cache_max_days()

        if prune_cache is True:
            should_prune = True
            eff_bytes = cache_max_bytes
            eff_days = cache_max_days
        elif prune_cache is False:
            should_prune = False
            eff_bytes = 0
            eff_days = 0
        else:
            should_prune = cache_max_bytes > 0 or cache_max_days > 0
            eff_bytes = cache_max_bytes
            eff_days = cache_max_days

        if should_prune and (eff_bytes > 0 or eff_days > 0):
            from .cache_ops import prune_local_iso_cache

            prune_local_iso_cache(
                max_bytes=eff_bytes,
                max_days=eff_days,
                dry_run=False,
                cfg=cfg,
                console=console,
            )

    # Final message
    console.print("\n" + "=" * 60)
    if all_success:
        console.print("[bold green]🎉 Alles erfolgreich erledigt![/bold green]")
    else:
        console.print("[bold yellow]⚠️ Abgeschlossen mit Fehlern[/bold yellow]")
    console.print("=" * 60 + "\n")

    if not all_success:
        raise typer.Exit(1)


@app.command()
def sources() -> None:
    """Zeige und verwalte Quellverzeichnisse."""
    manage_source_directories()


@app.command()
def targets() -> None:
    """Zeige und verwalte rclone Ziele."""
    manage_rclone_targets()




if __name__ == "__main__":
    app()

