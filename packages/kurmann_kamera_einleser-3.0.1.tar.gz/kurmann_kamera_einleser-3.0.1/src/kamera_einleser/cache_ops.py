"""Operator-Befehle rund um den lokalen Archiv-Cache (ab 1.8.0).

Der lokale Archiv-Cache ist *kein* echtes Backup. Die Sicherungen liegen
auf den rclone-Targets (NAS, Cloud). Der lokale Cache existiert nur,
damit Folge-Läufe schnell bleiben (Fall A: Subset-Check ohne Server-
Roundtrip) und Teil-Uploads wiederholt werden können, ohne die Pipeline
neu zu bauen.

Um zu verhindern, dass die Arbeits-Festplatte überläuft, kann ein
grössenbasiertes Limit gesetzt werden (`Config.get_archive_cache_max_bytes`,
ab 3.0.0 — Auto-Migration von `iso_cache_max_bytes` aus 1.x–2.3.x).
Wird es überschritten, prunt dieser Service die ältesten Archive — aber
**nur** solche, deren `*.uploaded.json`-Replikations-Marker bestätigt,
dass sie auf **allen** konfigurierten Targets liegen.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from .config import get_config
from .services.file_scanner import get_existing_isos
from .services.replication_marker import is_replicated_to_all
from .utils import format_size

if TYPE_CHECKING:
    from .config import Config


@dataclass
class CacheEntry:
    """Ein einzelner Eintrag im lokalen ISO-Cache."""

    path: Path
    size: int
    mtime: datetime
    is_replicated: bool  # Marker bestätigt Replikation auf alle Targets
    day_key: str  # "YYYY-MM-DD" aus Dateinamen


@dataclass
class ResyncResult:
    """Ergebnis von `resync_cache_to_targets`."""

    isos_uploaded: list[Path] = field(default_factory=list)
    isos_now_replicated: list[Path] = field(default_factory=list)
    isos_failed: list[tuple[Path, str]] = field(default_factory=list)
    isos_skipped_already_replicated: list[Path] = field(default_factory=list)
    dry_run: bool = False


@dataclass
class PruneResult:
    """Ergebnis von `prune_local_iso_cache`."""

    deleted: list[Path] = field(default_factory=list)
    freed_bytes: int = 0
    kept_unreplicated: list[Path] = field(default_factory=list)
    skipped_too_large: Path | None = None
    total_before: int = 0
    total_after: int = 0
    dry_run: bool = False


def list_local_iso_cache(cfg: "Config | None" = None) -> list[CacheEntry]:
    """Sammelt alle `.iso`-Dateien aus Primary- und Fallback-Working-Dir.

    Für jede ISO:
    - Dateigrösse und mtime aus dem Filesystem
    - `is_replicated`-Flag via `*.uploaded.json`-Marker
      (alle aktuell konfigurierten Targets müssen im Marker stehen)
    - `day_key` aus dem Dateinamen (`Originalmedien-YYYY-MM-DD[...].iso`)

    Returns:
        Liste, aufsteigend sortiert nach mtime (älteste zuerst).
    """
    config = cfg if cfg is not None else get_config()

    expected_targets = [t["name"] for t in config.get_rclone_targets()]

    entries: list[CacheEntry] = []
    seen_paths: set[Path] = set()

    for volume_path_str in (
        config.get_working_directory(),
        config.get_working_directory_fallback(),
    ):
        if not volume_path_str:
            continue
        volume = Path(volume_path_str).expanduser()
        if not volume.exists():
            continue

        by_day = get_existing_isos(volume)
        for day_key, paths in by_day.items():
            for p in paths:
                if p in seen_paths:
                    continue
                seen_paths.add(p)
                try:
                    stat = p.stat()
                except OSError:
                    continue
                entries.append(
                    CacheEntry(
                        path=p,
                        size=stat.st_size,
                        mtime=datetime.fromtimestamp(stat.st_mtime),
                        is_replicated=is_replicated_to_all(p, expected_targets),
                        day_key=day_key,
                    )
                )

    entries.sort(key=lambda e: e.mtime)
    return entries


def prune_local_iso_cache(
    *,
    max_bytes: int = 0,
    max_days: int = 0,
    dry_run: bool = False,
    cfg: "Config | None" = None,
    console: Console | None = None,
) -> PruneResult:
    """Entfernt replizierte Archive aus dem lokalen Cache, gemäss zwei Limits.

    **Variante-C-Pruning (2.2.0)**: zwei orthogonale Schwellen, die beide
    aktiv sein können:

    - `max_days`: Tag-basiert. Jeder Archiv-Eintrag, dessen `day_key`
      älter ist als heute − `max_days` Tage, wird zum Prune-Kandidaten.
      Ist die zentrale Variante-C-Logik: "ZIPs der letzten N Tage bleiben
      lokal, ältere fliegen raus".
    - `max_bytes`: Grössen-basiert (Belt-and-Suspenders). Nach dem Tag-
      basierten Prune wird geprüft, ob die verbleibende Cache-Summe noch
      über `max_bytes` liegt; falls ja, werden die ältesten verbleibenden
      Archive zusätzlich entfernt.

    Safety in beiden Pfaden: nur Archive mit vollständigem `.uploaded.json`-
    Marker werden gelöscht. Archive ohne Marker landen in
    `result.kept_unreplicated` — auch wenn sie ältere `day_key` haben.

    Args:
        max_bytes: Obergrenze für die Summe aller Cache-Archive. `0` =
            kein Bytes-Limit.
        max_days: Maximale Tage rückwärts (gemessen am `day_key`), die
            Archive im Cache bleiben dürfen. `0` = kein Tag-Limit.
        dry_run: Trocken-Lauf.
        cfg: Explicit Config instance (DI).
        console: rich-Console für Output; Default neuer Console.

    Returns:
        PruneResult mit Detail-Infos.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()

    entries = list_local_iso_cache(cfg=config)
    total = sum(e.size for e in entries)
    result = PruneResult(total_before=total, total_after=total, dry_run=dry_run)

    if max_bytes <= 0 and max_days <= 0:
        cons.print(
            "[dim]Cache-Limits deaktiviert "
            "(archive_cache_max_bytes=0, archive_cache_max_days=0) — nichts zu tun.[/dim]"
        )
        return result

    cons.print(
        f"[bold]🧹 Cache-Prune[/bold] — aktuell {format_size(total)}"
        + (
            f", Limit {format_size(max_bytes)}" if max_bytes > 0 else ""
        )
        + (
            f", max {max_days} Tag(e) rückwärts" if max_days > 0 else ""
        )
    )

    # Oversized-Archive vom Pruning ausschliessen (sonst würde das einzige
    # Mega-ZIP eines Tages zuerst wegfliegen, ohne Ersatz).
    if max_bytes > 0:
        oversized = [e for e in entries if e.size > max_bytes]
        if oversized:
            result.skipped_too_large = oversized[0].path
            cons.print(
                f"[yellow]⚠️  Archiv grösser als Limit — wird nicht geprunt: "
                f"{oversized[0].path.name} ({format_size(oversized[0].size)})[/yellow]"
            )

    current = total

    # PHASE 1: Tag-basiertes Pruning (Variante-C-Kern).
    if max_days > 0:
        from datetime import datetime, timedelta

        cutoff_date = datetime.now().date() - timedelta(days=max_days)
        for entry in entries:
            if max_bytes > 0 and entry.size > max_bytes:
                continue  # oversized bleibt

            try:
                day = datetime.strptime(entry.day_key, "%Y-%m-%d").date()
            except ValueError:
                continue  # day_key nicht parsbar → konservativ skippen

            if day >= cutoff_date:
                continue  # innerhalb Window, bleibt

            if not entry.is_replicated:
                if entry.path not in result.kept_unreplicated:
                    result.kept_unreplicated.append(entry.path)
                cons.print(
                    f"[yellow]   ⏭  {entry.day_key} alt ({_age(day)}), "
                    f"aber nicht repliziert: {entry.path.name}[/yellow]"
                )
                continue

            cons.print(
                f"   {'📋 ' if dry_run else '🗑️  '}"
                f"{entry.path.name} ({format_size(entry.size)}, "
                f"Tag {entry.day_key}, {_age(day)} alt)"
            )
            if not dry_run:
                try:
                    entry.path.unlink()
                except OSError as exc:
                    cons.print(f"[red]   ❌ {entry.path.name}: {exc}[/red]")
                    continue

            result.deleted.append(entry.path)
            result.freed_bytes += entry.size
            current -= entry.size

    # PHASE 2: Bytes-basierter Backstop. Falls noch zu viel da, älteste
    # weiter rauswerfen — auch wenn sie noch im Cache-Window wären
    # (Schutz gegen volle Disk bei einem extrem grossen Tag).
    if max_bytes > 0 and current > max_bytes:
        cons.print(
            f"[dim]Bytes-Backstop aktiv: noch {format_size(current)} > "
            f"{format_size(max_bytes)}, prune älteste replizierte Archive…[/dim]"
        )
        already_deleted = set(result.deleted)
        for entry in entries:
            if current <= max_bytes:
                break
            if entry.path in already_deleted:
                continue
            if entry.size > max_bytes:
                continue  # oversized
            if not entry.is_replicated:
                if entry.path not in result.kept_unreplicated:
                    result.kept_unreplicated.append(entry.path)
                continue

            cons.print(
                f"   {'📋 ' if dry_run else '🗑️  '}"
                f"{entry.path.name} ({format_size(entry.size)}, "
                f"{entry.mtime.strftime('%Y-%m-%d %H:%M')})"
            )
            if not dry_run:
                try:
                    entry.path.unlink()
                except OSError as exc:
                    cons.print(f"[red]   ❌ {entry.path.name}: {exc}[/red]")
                    continue

            result.deleted.append(entry.path)
            result.freed_bytes += entry.size
            current -= entry.size

    result.total_after = current

    if not result.deleted and not result.kept_unreplicated:
        cons.print(
            "[dim]Nichts zu prunen — alle Archive innerhalb Limits.[/dim]"
        )
    else:
        cons.print(
            f"\n[bold]✓ Prune {'geplant' if dry_run else 'abgeschlossen'}[/bold] "
            f"(gelöscht={len(result.deleted)}, "
            f"freigegeben={format_size(result.freed_bytes)}, "
            f"übrig={format_size(result.total_after)}, "
            f"übersprungen_nicht_repliziert={len(result.kept_unreplicated)})"
        )
    return result


def _age(day) -> str:  # noqa: ANN001
    """Menschen-lesbares Alter ('14 Tag(e)')."""
    from datetime import date

    delta = date.today() - day
    days = delta.days
    return f"{days} Tag(e)"


def resync_cache_to_targets(
    *,
    dry_run: bool = False,
    cfg: "Config | None" = None,
    console: Console | None = None,
) -> ResyncResult:
    """Lädt alle nicht-vollständig-replizierten Cache-ISOs nochmal an alle Targets.

    Recovery-Pfad für partial-upload Situationen: nach einem `archive`-Lauf
    mit fehlgeschlagenem Target liegen ISOs lokal im Cache, aber ihr Marker
    listet nicht alle aktuell konfigurierten Targets (oder existiert nicht).
    `cache resync` holt die fehlenden Target-Uploads nach, **ohne erneuten
    Pull aus der Source**.

    Vorgang pro nicht-vollständig-replizierter Cache-ISO:
    1. `upload_to_all_targets` → rclone --immutable schützt OK-Targets,
       fehlende Targets kriegen die ISO
    2. Bei vollständigem Erfolg → Replikations-Marker wird neu geschrieben
       mit aktueller Target-Liste + CSV-Index aktualisiert (Legacy)
    3. Bei weiterem Teilausfall → ISO bleibt im Cache, kein Marker-Update,
       Lauf macht mit der nächsten ISO weiter

    Args:
        dry_run: Listet, was getan würde, ohne Upload-Calls.
        cfg: Explicit Config-Instanz (DI).
        console: rich-Console für Output.

    Returns:
        ResyncResult mit Detail-Listen.
    """
    cons = console or Console()
    config = cfg if cfg is not None else get_config()

    entries = list_local_iso_cache(cfg=config)
    needs_resync = [e for e in entries if not e.is_replicated]

    result = ResyncResult(dry_run=dry_run)

    if not needs_resync:
        cons.print(
            "[dim]Nichts zu re-synchronisieren — alle Cache-ISOs sind "
            "vollständig repliziert (Marker bestätigt alle Targets).[/dim]"
        )
        return result

    cons.print(
        f"[bold]🔄 Cache-Resync[/bold] — {len(needs_resync)} nicht vollständig "
        "replizierte ISO(s) gefunden, versuche fehlende Target-Uploads:"
    )
    for entry in needs_resync:
        cons.print(f"   • {entry.path.name}")

    if dry_run:
        cons.print(
            "\n[dim](dry-run — kein Upload, kein Marker-Update)[/dim]"
        )
        result.isos_uploaded = [e.path for e in needs_resync]
        return result

    # Lokal-Imports vermeiden Zirkular-Import api → cache_ops
    from . import __version__
    from .rclone import upload_to_all_targets
    from .services.replication_marker import write_marker

    for entry in needs_resync:
        cons.print(f"\n[cyan]→ {entry.path.name}[/cyan]")
        all_ok, ok_targets, failed_targets = upload_to_all_targets(
            [entry.path], verbose=True, cfg=config
        )
        if all_ok:
            # Marker neu schreiben — Replikations-Garantie gilt
            write_marker(entry.path, targets=ok_targets, tool_version=__version__)
            result.isos_uploaded.append(entry.path)
            result.isos_now_replicated.append(entry.path)
            cons.print(
                "   [green]✅ Vollständig repliziert + Marker geschrieben[/green]"
            )
        else:
            failure_msg = (
                f"Fehlend: {', '.join(failed_targets)}"
                if failed_targets
                else "Upload fehlgeschlagen"
            )
            result.isos_failed.append((entry.path, failure_msg))
            cons.print(f"   [yellow]⚠️  {failure_msg}[/yellow]")

    cons.print(
        f"\n[bold]✓ Cache-Resync abgeschlossen[/bold] "
        f"(uploaded={len(result.isos_uploaded)}, "
        f"jetzt_repliziert={len(result.isos_now_replicated)}, "
        f"fehlgeschlagen={len(result.isos_failed)})"
    )
    return result
