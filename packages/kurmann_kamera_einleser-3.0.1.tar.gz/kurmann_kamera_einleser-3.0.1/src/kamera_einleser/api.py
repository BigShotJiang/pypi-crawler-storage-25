"""Public API: Facade über den bestehenden Archivierungs-Workflow.

Folgt dem kurmann-python-api Skill:
- Einstieg via Request/Result
- Laufzeit-Optionen getrennt via RuntimeOptions
- Event-Callbacks via ArchiveEvents
- Teiloperationen (`build_isos`, `verify`, `upload`) bleiben im service-Layer
  aufrufbar und werden von `archive()` orchestriert.

Bestehende Module (`archive.py`, `rclone.py`, `restore.py`) dienen aktuell
als Service-Schicht. Eine physische Aufteilung in `services/` folgt in einem
späteren PR; das hier ist der stabile Public-API-Einstiegspunkt.
"""

from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import Config

from .config import (
    LOCAL_WORKDIR_SAFETY,
    WorkingDirectoryUnavailableError,
    get_config,
)
from .core.archive_flow import create_archive
from .models import (
    ArchiveEvents,
    ArchiveRequest,
    ArchiveResult,
    LocalSource,
    RcloneSource,
    RuntimeOptions,
    SourceRef,
)
from .rclone import (
    check_rclone_available,
    get_rclone_source_size,
    pull_rclone_source_to_dir,
    upload_to_all_targets,
)
from .services.file_scanner import (
    calculate_directory_size,
    cleanup_source_files,
    get_existing_isos,
)
from .services.manifest_cache import (
    all_archived_filenames,
    working_dirs_from_config,
)
from .services.zip_builder import verify_archives as verify_archive

# Pipeline-Footprint-Konstanten leben in config.py; siehe dort die Begründung
# für LOCAL_WORKDIR_SAFETY, REMOTE_PIPELINE_SAFETY, SPLIT_PIPELINE_PER_VOLUME_SAFETY.


def archive(
    request: ArchiveRequest,
    options: RuntimeOptions | None = None,
    events: ArchiveEvents | None = None,
    cfg: "Config | None" = None,
) -> ArchiveResult:
    """Orchestriert einen kompletten Archivierungs-Lauf über N Quellen.

    `cfg` ist eine explizite Config-Instanz (DI ab 1.7.0). Fällt auf
    `get_config()` zurück, damit bestehende Aufrufer ohne Anpassung
    weiterlaufen. Neue Aufrufer (Tests, Integrations) sollten die
    Config bewusst injizieren.
    """
    options = options or RuntimeOptions()
    events = events or ArchiveEvents()
    verbose = options.is_verbose
    config = cfg if cfg is not None else get_config()

    if not request.no_upload and not check_rclone_available():
        return ArchiveResult(success=False, message="rclone ist nicht installiert")

    result = ArchiveResult(success=True)

    for source in request.sources:
        if events.on_source_started:
            events.on_source_started(source)

        # request.working_dir (falls explizit gesetzt) überstimmt den Resolver.
        ok, isos = _process_source(
            source,
            request.working_dir,
            request.no_upload,
            verbose,
            full_pull=request.full_pull,
            cfg=config,
        )

        result.iso_files.extend(isos)
        if ok:
            result.processed_sources.append(source)
        else:
            result.failed_sources.append(source)
            result.success = False

        if events.on_source_finished:
            events.on_source_finished(source, ok)

    if (
        result.success
        and request.delete_source
        and not options.dry_run
    ):
        for source in result.processed_sources:
            if isinstance(source, LocalSource):
                cleanup_source_files(source.path, verbose=verbose)

    # 2.2.0: kein Remote-Index mehr — Manifests sind selbst die Cross-Machine-
    # Wahrheit (werden mit der ISO/ZIP zum Target hochgeladen).

    return result


def _process_source(
    source: SourceRef,
    working_dir_override: Path | None,
    no_upload: bool,
    verbose: bool,
    full_pull: bool = False,
    cfg: "Config | None" = None,
) -> tuple[bool, list[Path]]:
    """Verarbeitet eine einzelne Quelle: (Pull) → ZIP-Bau → Verify → Upload.

    `working_dir_override` hat Vorrang; sonst wird via
    `Config.resolve_working_directory` anhand der Quell-Grösse und des
    Quell-Typs ein Pfad gewählt (primär → fallback → ggf. Temp).

    `full_pull=True` übergeht den Manifest-Pre-Filter für rclone-Quellen und zieht
    jede Datei erneut. Für lokale Quellen ist der Flag irrelevant.

    `cfg` ist eine explizite Config-Instanz (DI). Fallback auf `get_config()`.
    """
    pull_dir: Path | None = None
    cfg = cfg if cfg is not None else get_config()

    try:
        if isinstance(source, RcloneSource):
            source_bytes = get_rclone_source_size(source.rclone_path) or 0
            # Split-Pipeline (1.6.0): Pull → Primary, ISO → Fallback wenn beide
            # mit ~1.5× source frei sind. Sonst Single-Volume (3.5× source auf
            # einer Disk). Beides via Config-Resolver gekapselt.
            try:
                if working_dir_override is not None:
                    pull_root = iso_dir = working_dir_override
                else:
                    pull_root, iso_dir = cfg.resolve_split_pipeline(
                        source_bytes, is_rclone_source=True
                    )
            except WorkingDirectoryUnavailableError as exc:
                from rich.console import Console

                Console(stderr=True).print(f"[red]❌ {exc}[/red]")
                return False, []

            if verbose and pull_root != iso_dir:
                from rich.console import Console

                Console().print(
                    f"[dim]🔀 Split-Pipeline: Pull → {pull_root} | "
                    f"Archiv → {iso_dir}[/dim]"
                )

            working_dir = iso_dir  # für create_archive (output_dir)

            excludes = cfg.get_excludes() if hasattr(cfg, "get_excludes") else None
            pull_dir = Path(
                tempfile.mkdtemp(
                    prefix=f"rclone-pull-{_slugify(source.remote)}-",
                    dir=str(pull_root),
                )
            )

            # Pre-Filter beim rclone-Pull: bekannte Dateinamen aus den lokalen
            # Manifest-Sidecars (services/manifest_cache.py) werden übersprungen,
            # damit bereits archivierte Files nicht erneut übers Netz gezogen
            # werden. Mit full_pull=True wird der Filter explizit deaktiviert.
            skip_names: set[str] | None = None
            if not full_pull:
                skip_names = all_archived_filenames(working_dirs_from_config(cfg))

            if not pull_rclone_source_to_dir(
                source,
                pull_dir,
                excludes,
                verbose,
                skip_filenames=skip_names,
            ):
                return False, []
            source_path = pull_dir
        elif isinstance(source, LocalSource):
            source_bytes = (
                calculate_directory_size(source.path) if source.path.exists() else 0
            )
            required = int(source_bytes * LOCAL_WORKDIR_SAFETY) if source_bytes else 0
            try:
                working_dir = working_dir_override or cfg.resolve_working_directory(
                    required,
                    is_rclone_source=False,
                    source_bytes_for_error=source_bytes,
                    safety_factor_for_error=LOCAL_WORKDIR_SAFETY,
                )
            except WorkingDirectoryUnavailableError as exc:
                from rich.console import Console

                Console(stderr=True).print(f"[red]❌ {exc}[/red]")
                return False, []
            source_path = source.path
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unbekannter Source-Typ: {type(source).__name__}")

        success, archive_files, replace_archives = create_archive(
            source_path=source_path,
            output_dir=working_dir,
            archive_name=None,
            verbose=verbose,
            cfg=cfg,
        )
        if not success:
            return False, []

        if not archive_files:
            existing = get_existing_isos(working_dir)
            all_isos: list[Path] = []
            for iso_list in existing.values():
                all_isos.extend(iso_list)
            archive_files = sorted(all_isos)
            if not archive_files:
                return True, []

        if not verify_archive(archive_files, verbose=verbose):
            return False, archive_files

        if not no_upload:
            # Append-Replace-Archive bekommen --immutable=False, alle anderen
            # bleiben beim sicheren Default --immutable=True.
            overrides: dict[Path, bool] = {p: False for p in replace_archives}
            all_ok, ok_targets, failed_targets = upload_to_all_targets(
                archive_files,
                verbose=verbose,
                cfg=cfg,
                immutable_overrides=overrides or None,
            )
            if not all_ok:
                # Kein Index-Write bei fehlgeschlagenem Upload — verhindert
                # Phantom-Einträge (Index kennt ISO, aber kein Target hat sie).
                # Garantie "Index = überall repliziert" bleibt damit erhalten.
                _print_partial_upload_recovery_hint(
                    ok_targets=ok_targets,
                    failed_targets=failed_targets,
                    iso_count=len(archive_files),
                )
                return False, archive_files

        # Replikation gesichert (all_ok=True oder no_upload). CSV-Index-Write
        # (Legacy 2.0.x) und neuer .uploaded.json-Marker (2.2.0) werden hier
        # geschrieben. Beides idempotent — re-runs einer bereits indexierten
        # ISO sind kein Problem.
        if not no_upload:
            _index_after_upload(
                archive_files,
                ok_targets=ok_targets,
                verbose=verbose,
                cfg=cfg,
            )

        return True, archive_files
    finally:
        if pull_dir is not None and pull_dir.exists():
            shutil.rmtree(pull_dir, ignore_errors=True)


def _slugify(name: str) -> str:
    """Dateisystem-sichere Kurzform eines Remote-Namens."""
    return re.sub(r"[^A-Za-z0-9_-]+", "-", name).strip("-") or "remote"


def _index_after_upload(
    archive_paths: list[Path],
    *,
    ok_targets: list[str],
    verbose: bool = True,
    cfg: "Config | None" = None,
) -> None:
    """Schreibt `*.uploaded.json`-Replikations-Marker für jedes Archiv.

    Wird ausschliesslich nach erfolgreichem Upload zu **allen** Targets
    aufgerufen (`all_ok=True`). Der Marker ist ab 2.2.0 die einzige
    Wahrheit für die "auf allen Targets vorhanden"-Garantie, die
    `cache prune` benötigt.

    Args:
        archive_paths: alle in diesem Lauf gebauten Archive.
        ok_targets: Liste der Target-Namen, an die erfolgreich repliziert wurde.
        verbose: CLI-Logging.
        cfg: explizite Config-Instanz (DI) — aktuell ungenutzt, bleibt für
            künftige Erweiterungen (z.B. Target-Cross-Check) in der Signatur.
    """
    from . import __version__
    from .services.replication_marker import write_marker

    _ = cfg  # cfg ist Teil der DI-Signatur, hier aktuell nicht genutzt

    for archive_path in archive_paths:
        try:
            write_marker(archive_path, targets=ok_targets, tool_version=__version__)
        except OSError as exc:
            # Marker-Schreibe-Fehler kippen den Lauf nicht — das Archiv ist
            # ja erfolgreich hochgeladen. Cache-prune wird im Zweifel
            # konservativer (= Archiv bleibt im Cache, bis Marker da ist).
            if verbose:
                from rich.console import Console

                Console(stderr=True).print(
                    f"[yellow]⚠️  Konnte Replikations-Marker für "
                    f"{archive_path.name} nicht schreiben: {exc}[/yellow]"
                )


def _print_partial_upload_recovery_hint(
    *,
    ok_targets: list[str],
    failed_targets: list[str],
    iso_count: int,
) -> None:
    """Klare Recovery-Anleitung, wenn ein Lauf teilweise hochgeladen hat.

    Wir zeigen explizit, dass der Cache die Archive noch hat, der
    Replikations-Marker NICHT aktualisiert wurde (Daten-Sicherheits-
    Garantie!), und dass `cache resync` ohne erneuten Pull die
    fehlenden Targets nachholt.
    """
    from rich.console import Console

    err = Console(stderr=True)
    err.print(
        f"\n[yellow]⚠️  Partial-Upload: {len(ok_targets)}/"
        f"{len(ok_targets) + len(failed_targets)} Ziele erfolgreich.[/yellow]"
    )
    if ok_targets:
        err.print(f"   ✅ {', '.join(ok_targets)}")
    if failed_targets:
        err.print(f"   ❌ {', '.join(failed_targets)}")
    err.print(
        f"\n[yellow]   {iso_count} Archiv(e) bleiben lokal im Cache, der "
        "Replikations-Marker wurde NICHT geschrieben.[/yellow]"
    )
    err.print(
        "\n[bold green]Recovery (kein erneuter Pull nötig):[/bold green]\n"
        "   ▸ [bold]kamera-einleser cache resync[/bold]"
    )
    err.print(
        "\n[dim]Alternative: regulärer 'archive'-Lauf re-pullt die Quelle "
        "und baut neu.[/dim]"
    )


__all__ = [
    "archive",
    "ArchiveRequest",
    "ArchiveResult",
    "ArchiveEvents",
    "RuntimeOptions",
    "LocalSource",
    "SourceRef",
]
