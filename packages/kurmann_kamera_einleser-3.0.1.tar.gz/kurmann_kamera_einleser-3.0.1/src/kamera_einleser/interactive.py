"""Interactive configuration module with arrow key navigation."""

from pathlib import Path

from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from InquirerPy.separator import Separator
from rich.console import Console
from rich.table import Table

from .config import get_config, strip_quotes

console = Console()


def show_current_config() -> None:
    """Display the current configuration in a formatted table."""
    config = get_config()

    console.print("\n[bold]📋 Aktuelle Konfiguration[/bold]\n")

    # Source directories table
    source_dirs = config.get_source_directories()
    table = Table(title="Quellverzeichnisse")
    table.add_column("Nr.", style="cyan")
    table.add_column("Pfad", style="green")
    table.add_column("Status", style="yellow")

    if source_dirs:
        for i, d in enumerate(source_dirs, 1):
            exists = "✅ Existiert" if Path(d).exists() else "❌ Nicht gefunden"
            table.add_row(str(i), d, exists)
    else:
        table.add_row("-", "Keine Quellverzeichnisse konfiguriert", "-")

    console.print(table)

    # rclone targets table
    targets = config.get_rclone_targets()
    table = Table(title="\nrclone Ziele (in Reihenfolge)")
    table.add_column("Nr.", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Pfad", style="blue")

    if targets:
        for i, t in enumerate(targets, 1):
            table.add_row(str(i), t.get("name", "-"), t.get("path", "-"))
    else:
        table.add_row("-", "Keine Ziele konfiguriert", "-")

    console.print(table)

    # Other settings
    console.print(
        f"\n[bold]Arbeitsverzeichnis (primär):[/bold] "
        f"{config.get_working_directory() or '(Standard: Temp)'}"
    )
    fallback = config.get_working_directory_fallback()
    if fallback:
        console.print(f"[bold]Arbeitsverzeichnis (Fallback):[/bold] {fallback}")
    console.print(f"[bold]Ausschluss-Muster:[/bold] {', '.join(config.get_excludes())}")
    console.print(f"\n[bold]Konfigurationsdatei:[/bold] {config.config_path}")


def manage_source_directories() -> None:
    """Interactive menu for managing source directories."""
    while True:
        config = get_config()
        source_dirs = config.get_source_directories()

        choices = [
            Choice(value="add", name="➕ Quellverzeichnis hinzufügen"),
        ]

        if source_dirs:
            choices.append(Choice(value="remove", name="➖ Quellverzeichnis entfernen"))
            choices.append(Separator())
            for d in source_dirs:
                exists = "✅" if Path(d).exists() else "❌"
                choices.append(Choice(value=None, name=f"   {exists} {d}", enabled=False))

        choices.append(Separator())
        choices.append(Choice(value="back", name="⬅️  Zurück"))

        action = inquirer.select(
            message="Quellverzeichnisse verwalten:",
            choices=choices,
        ).execute()

        if action == "back":
            break
        elif action == "add":
            path = inquirer.filepath(
                message="Pfad zum Quellverzeichnis:",
                validate=lambda x: Path(x).exists() or "Verzeichnis existiert nicht",
                only_directories=True,
            ).execute()
            if path:
                if config.add_source_directory(str(path)):
                    config.save()
                    console.print(f"[green]✅ Hinzugefügt: {path}[/green]")
                else:
                    console.print("[yellow]⚠️ Verzeichnis bereits vorhanden[/yellow]")
        elif action == "remove":
            if source_dirs:
                dir_choices = [Choice(value=d, name=d) for d in source_dirs]
                dir_choices.append(Choice(value=None, name="Abbrechen"))
                to_remove = inquirer.select(
                    message="Welches Verzeichnis entfernen?",
                    choices=dir_choices,
                ).execute()
                if to_remove:
                    config.remove_source_directory(to_remove)
                    config.save()
                    console.print(f"[green]✅ Entfernt: {to_remove}[/green]")


def manage_rclone_targets() -> None:
    """Interactive menu for managing rclone targets."""
    while True:
        config = get_config()
        targets = config.get_rclone_targets()

        choices = [
            Choice(value="add", name="➕ Ziel hinzufügen"),
        ]

        if targets:
            choices.append(Choice(value="edit", name="✏️  Ziel bearbeiten"))
            choices.append(Choice(value="remove", name="➖ Ziel entfernen"))
            choices.append(Choice(value="reorder", name="🔄 Reihenfolge ändern"))
            choices.append(Separator())
            for i, t in enumerate(targets, 1):
                display_text = f"   {i}. {t.get('name', '-')} → {t.get('path', '-')}"
                choices.append(
                    Choice(
                        value=None,
                        name=display_text,
                        enabled=False,
                    )
                )

        choices.append(Separator())
        choices.append(Choice(value="back", name="⬅️  Zurück"))

        action = inquirer.select(
            message="rclone Ziele verwalten:",
            choices=choices,
        ).execute()

        if action == "back":
            break
        elif action == "add":
            name = inquirer.text(
                message="Name für das Ziel (z.B. 'NAS', 'Mega.nz'):",
                validate=lambda x: len(x) > 0 or "Name darf nicht leer sein",
            ).execute()

            path = inquirer.text(
                message="rclone Zielpfad (z.B. 'nas:/backup' oder 'mega:Backup'):",
                validate=lambda x: ":" in x or "Ungültiger rclone-Pfad (muss ':' enthalten)",
            ).execute()

            if name and path:
                # Remove quotes from input
                name = strip_quotes(name)
                path = strip_quotes(path)
                if config.add_rclone_target(name, path):
                    config.save()
                    console.print(f"[green]✅ Hinzugefügt: {name} → {path}[/green]")
                else:
                    console.print("[yellow]⚠️ Ziel mit diesem Pfad bereits vorhanden[/yellow]")

        elif action == "edit":
            if targets:
                target_choices = [
                    Choice(value=i, name=f"{t.get('name', '-')} → {t.get('path', '-')}")
                    for i, t in enumerate(targets)
                ]
                target_choices.append(Choice(value=None, name="Abbrechen"))
                target_idx = inquirer.select(
                    message="Welches Ziel bearbeiten?",
                    choices=target_choices,
                ).execute()

                if target_idx is not None:
                    target = targets[target_idx]

                    # Edit name
                    new_name = inquirer.text(
                        message="Neuer Name (oder Enter für unverändert):",
                        default=target.get('name', ''),
                    ).execute()

                    # Edit path
                    new_path = inquirer.text(
                        message="Neuer Pfad (oder Enter für unverändert):",
                        default=target.get('path', ''),
                        validate=lambda x: ":" in x or "Ungültiger rclone-Pfad (muss ':' enthalten)",
                    ).execute()

                    if new_name and new_path:
                        # Remove quotes from input
                        new_name = strip_quotes(new_name)
                        new_path = strip_quotes(new_path)

                        if config.update_rclone_target(target_idx, new_name, new_path):
                            config.save()
                            console.print(
                                f"[green]✅ Ziel aktualisiert: {new_name} → {new_path}[/green]"
                            )
                        else:
                            console.print("[yellow]⚠️ Fehler beim Aktualisieren[/yellow]")

        elif action == "remove":
            if targets:
                target_choices = [
                    Choice(value=t.get("path"), name=f"{t.get('name', '-')} → {t.get('path', '-')}")
                    for t in targets
                ]
                target_choices.append(Choice(value=None, name="Abbrechen"))
                to_remove = inquirer.select(
                    message="Welches Ziel entfernen?",
                    choices=target_choices,
                ).execute()
                if to_remove:
                    config.remove_rclone_target(to_remove)
                    config.save()
                    console.print("[green]✅ Ziel entfernt[/green]")

        elif action == "reorder":
            if len(targets) >= 2:
                reorder_targets()


def reorder_targets() -> None:
    """Interactive menu for reordering rclone targets."""
    while True:
        config = get_config()
        targets = config.get_rclone_targets()

        if len(targets) < 2:
            console.print("[yellow]⚠️ Mindestens 2 Ziele erforderlich zum Umsortieren[/yellow]")
            break

        choices = []
        for i, t in enumerate(targets):
            name = f"{i + 1}. {t.get('name', '-')} → {t.get('path', '-')}"
            choices.append(Choice(value=t.get("path"), name=name))
        choices.append(Separator())
        choices.append(Choice(value="done", name="✅ Fertig"))

        selected = inquirer.select(
            message="Ziel auswählen zum Verschieben (oder Fertig):",
            choices=choices,
        ).execute()

        if selected == "done":
            break

        # Ask for direction
        direction = inquirer.select(
            message="In welche Richtung verschieben?",
            choices=[
                Choice(value=-1, name="⬆️  Nach oben"),
                Choice(value=1, name="⬇️  Nach unten"),
                Choice(value=0, name="Abbrechen"),
            ],
        ).execute()

        if direction != 0:
            if config.move_rclone_target(selected, direction):
                config.save()
                console.print("[green]✅ Reihenfolge geändert[/green]")
            else:
                console.print("[yellow]⚠️ Kann nicht weiter verschoben werden[/yellow]")


def configure_working_directory() -> None:
    """Configure the working directory for ZIP archive creation."""
    config = get_config()
    current = config.get_working_directory()

    console.print(f"\n[bold]Aktuelles Arbeitsverzeichnis:[/bold] {current or '(Standard: Temp)'}")

    action = inquirer.select(
        message="Was möchtest du tun?",
        choices=[
            Choice(value="set", name="📁 Arbeitsverzeichnis festlegen"),
            Choice(value="clear", name="🗑️  Zurücksetzen (Standard verwenden)"),
            Choice(value="back", name="⬅️  Zurück"),
        ],
    ).execute()

    if action == "set":
        path = inquirer.filepath(
            message="Pfad zum Arbeitsverzeichnis:",
            validate=lambda x: Path(x).exists() and Path(x).is_dir() or "Verzeichnis existiert nicht",
            only_directories=True,
        ).execute()
        if path:
            config.set_working_directory(str(path))
            config.save()
            console.print(f"[green]✅ Arbeitsverzeichnis gesetzt: {path}[/green]")
    elif action == "clear":
        config.set_working_directory("")
        config.save()
        console.print("[green]✅ Arbeitsverzeichnis zurückgesetzt[/green]")


def configure_excludes() -> None:
    """Interactive editor for the exclude patterns list."""
    config = get_config()
    current = config.get_excludes()
    console.print(f"\n[bold]Aktuelle Ausschluss-Muster:[/bold] {', '.join(current)}")

    excludes_str = inquirer.text(
        message="Ausschluss-Muster (kommagetrennt, z.B. '._*,.DS_Store'):",
        default=",".join(current),
    ).execute()

    if excludes_str:
        excludes = [
            strip_quotes(e.strip()) for e in excludes_str.split(",") if e.strip()
        ]
        config.set_excludes(excludes)
        config.save()
        console.print(f"[green]✅ Ausschluss-Muster gesetzt: {', '.join(excludes)}[/green]")


def interactive_settings() -> None:
    """Main interactive settings menu."""
    while True:
        config = get_config()

        # Show quick status
        source_count = len(config.get_source_directories())
        target_count = len(config.get_rclone_targets())

        choices = [
            Choice(value="show", name="📋 Aktuelle Konfiguration anzeigen"),
            Separator(),
            Choice(
                value="sources",
                name=f"📂 Quellverzeichnisse verwalten ({source_count} konfiguriert)",
            ),
            Choice(
                value="targets",
                name=f"☁️  rclone Ziele verwalten ({target_count} konfiguriert)",
            ),
            Choice(value="workdir", name="📁 Arbeitsverzeichnis festlegen"),
            Choice(value="excludes", name="🚫 Ausschluss-Muster bearbeiten"),
            Separator(),
            Choice(value="exit", name="🚪 Beenden"),
        ]

        action = inquirer.select(
            message="[bold]Kamera-Einleser Einstellungen[/bold]",
            choices=choices,
            default="show",
        ).execute()

        if action == "exit":
            break
        elif action == "show":
            show_current_config()
        elif action == "sources":
            manage_source_directories()
        elif action == "targets":
            manage_rclone_targets()
        elif action == "workdir":
            configure_working_directory()
        elif action == "excludes":
            configure_excludes()

    console.print("\n[bold]Auf Wiedersehen! 👋[/bold]\n")


