"""Shared utility functions for kamera-einleser."""

import hashlib
from fnmatch import fnmatch
from pathlib import Path


def compute_sha256(file_path: Path) -> str:
    """SHA-256-Hash einer Datei als hex-String.

    Liest in 64-KB-Chunks, damit auch mehr-Gigabyte-Files (typische
    HEVC-Clips) ohne speicherproblematische Vollkopien hashbar bleiben.

    Bis 2.1.0 lebte diese Funktion im separaten Modul `checksum.py`
    (dort zusammen mit der CSV-Index-Logik). Mit dem CSV-Index-Removal
    in 2.2.0 wurde `checksum.py` zur 1-Funktions-Datei; in 3.0.0 ist
    sie nach `utils.py` eingefaltet.
    """
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()


def format_size(size_bytes: int) -> str:
    """Format bytes into human-readable string.

    Uses binary units (GiB, MiB, KiB) for accurate representation
    of file and disk sizes based on powers of 1024.

    Args:
        size_bytes: Size in bytes

    Returns:
        Human-readable size string
    """
    if size_bytes >= 1024**3:
        return f"{size_bytes / (1024**3):.2f} GiB"
    elif size_bytes >= 1024**2:
        return f"{size_bytes / (1024**2):.2f} MiB"
    elif size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KiB"
    return f"{size_bytes} Bytes"


def should_exclude(filename: str, excludes: list[str]) -> bool:
    """Check if a filename matches any of the exclude patterns.

    Args:
        filename: The filename to check (just the name, not the full path)
        excludes: List of glob patterns to exclude (e.g. ['._*', '.DS_Store'])

    Returns:
        True if the filename matches any exclude pattern, False otherwise
    """
    for pattern in excludes:
        if fnmatch(filename, pattern):
            return True
    return False
