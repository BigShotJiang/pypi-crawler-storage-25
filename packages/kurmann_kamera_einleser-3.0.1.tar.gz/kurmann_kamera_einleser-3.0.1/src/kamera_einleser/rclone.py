"""Rclone upload module for transferring archives to remote targets."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.console import Console

from .config import get_config
from .utils import format_size

if TYPE_CHECKING:
    from .config import Config
    from .models import RcloneSource

console = Console()

# Mindest-Freiplatz-Puffer relativ zur Quellen-Grösse. Hintergrund: rclone
# schreibt .partial-Dateien und braucht während Multi-Thread-Copies kurz
# zusätzlichen Platz; ein 10%-Puffer hat sich in der Praxis bewährt.
PULL_FREE_SPACE_SAFETY = 1.10


def check_rclone_available() -> bool:
    """Check if rclone is installed and available."""
    result = subprocess.run(
        ["rclone", "version"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_rclone_source_size(rclone_path: str) -> int | None:
    """Liefert die Gesamt-Bytezahl einer rclone-Quelle via `rclone size --json`.

    Args:
        rclone_path: rclone-Pfad, z.B. "synology:/volume1/Fotos".

    Returns:
        Anzahl Bytes, oder None bei Fehler / ungültigem JSON.
    """
    result = subprocess.run(
        ["rclone", "size", "--json", rclone_path],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    try:
        data = json.loads(result.stdout)
        return int(data.get("bytes", 0))
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def pull_rclone_source_to_dir(
    source: "RcloneSource",
    destination_dir: Path,
    excludes: list[str] | None = None,
    verbose: bool = True,
    skip_filenames: set[str] | None = None,
) -> bool:
    """Zieht eine rclone-Quelle (z.B. Synology-NAS) nach `destination_dir`.

    Nutzt `rclone copy` mit Metadaten-Erhalt (mtime, wo unterstützt). Der
    Zielordner wird angelegt, falls er nicht existiert. Ausschluss-Muster
    werden als `--exclude` weitergereicht (Glob-Syntax wie rclone sie kennt).

    `skip_filenames` aktiviert den **Manifest-Pre-Filter** (1.5.0 Fix 3, ab
    2.2.0 manifest-basiert): alle darin enthaltenen Dateinamen werden via
    `rclone --filter-from` remote-seitig übersprungen. Dadurch wird bei
    wiederholten Läufen nur übertragen, was noch nicht archiviert ist.
    Passe-partout für jedes rclone-Backend, weil rein auf Dateinamen
    basierend (keine Server-Hashes nötig).

    Args:
        source: RcloneSource-Instanz aus `kamera_einleser.models`.
        destination_dir: lokales Zielverzeichnis (wird angelegt).
        excludes: optionale Liste von rclone-Glob-Excludes.
        verbose: bei True wird rclone stdout/stderr durchgereicht.
        skip_filenames: Set bereits indexierter Dateinamen (NFC-normalisiert).
            Wenn gesetzt und non-empty, wird eine Filter-Datei generiert und
            an rclone übergeben. Auf `None` oder leer = kein Prefilter (voller
            Pull, äquivalent zum `--full-pull`-Modus der CLI).

    Returns:
        True bei erfolgreichem Kopieren, False bei Fehler.
    """
    # Import lokal, um Zirkular-Import mit models → archive → rclone zu
    # vermeiden. Der Typ-Hint im Signatur ist ein String (forward ref).
    destination_dir.mkdir(parents=True, exist_ok=True)

    # Pre-flight: Grösse der Quelle ermitteln und mit freiem Platz vergleichen.
    # rclone size --json dauert ~1 s und verhindert "no space left on device"
    # mitten im Kopier-Lauf (Reliability-Fix 1.4.0).
    source_bytes = get_rclone_source_size(source.rclone_path)
    if source_bytes is not None:
        free_bytes = shutil.disk_usage(destination_dir).free
        required = int(source_bytes * PULL_FREE_SPACE_SAFETY)
        if verbose:
            console.print(
                f"[dim]💾 Quell-Grösse: {format_size(source_bytes)} | "
                f"Frei am Ziel: {format_size(free_bytes)} | "
                f"Benötigt (inkl. 10 % Puffer): {format_size(required)}[/dim]"
            )
        if free_bytes < required:
            if verbose:
                console.print(
                    f"[red]❌ Zu wenig Speicherplatz in {destination_dir}.[/red]\n"
                    f"   Benötigt: {format_size(required)} "
                    f"(Quelle {format_size(source_bytes)} + 10 % Puffer)\n"
                    f"   Verfügbar: {format_size(free_bytes)}"
                )
            return False
    elif verbose:
        console.print(
            "[yellow]⚠️ Konnte Quell-Grösse nicht ermitteln — "
            "überspringe Speicherplatz-Check.[/yellow]"
        )

    cmd: list[str] = [
        "rclone",
        "copy",
        "--metadata",
        source.rclone_path,
        str(destination_dir),
    ]
    for pattern in excludes or []:
        cmd.extend(["--exclude", pattern])

    # Fix 3 (1.5.0, 2.2.0 manifest-basiert): Pre-Filter. Schreibt eine Liste
    # bereits archivierter
    # Dateinamen in eine Temp-Datei und übergibt sie rclone via --filter-from.
    # rclone skippt diese Files dann bereits am Remote, d.h. sie werden nie
    # übertragen und verbrauchen kein Netz.
    filter_path: Path | None = None
    if skip_filenames:
        filter_path = destination_dir.parent / f".rclone-filter-{destination_dir.name}.txt"
        _write_exclude_filter_file(filter_path, skip_filenames)
        cmd.extend(["--filter-from", str(filter_path)])
        if verbose:
            console.print(
                f"[dim]📋 Manifest-Prefilter aktiv: {len(skip_filenames)} "
                f"bereits archivierte Dateinamen werden übersprungen.[/dim]"
            )

    if verbose:
        cmd.extend(["-v", "--stats", "5s", "--stats-one-line"])

    if verbose:
        console.print(f"\n[bold]📥 Ziehe rclone-Quelle:[/bold] {source.rclone_path}")
        console.print(f"   → {destination_dir}")

    try:
        result = (
            subprocess.run(cmd)
            if verbose
            else subprocess.run(cmd, capture_output=True)
        )
    finally:
        if filter_path is not None and filter_path.exists():
            try:
                filter_path.unlink()
            except OSError:
                pass

    if result.returncode != 0:
        if verbose:
            console.print("[red]❌ rclone copy fehlgeschlagen[/red]")
        return False

    if verbose:
        console.print("[green]✅ rclone-Quelle ins Staging übernommen[/green]")
    return True


def _get_year_from_archive_name(archive_name: str) -> str:
    """Extract year from an archive filename.

    Args:
        archive_name: Archive filename, z.B. "Originalmedien-2025-12-24.zip"

    Returns:
        Year string (e.g., "2025")
    """
    # Originalmedien-YYYY-MM-DD.zip oder Originalmedien-YYYY-MM-DD-Teil-N.zip
    stem = Path(archive_name).stem  # e.g., Originalmedien-2025-12-24
    key_part = stem.replace("Originalmedien-", "")  # e.g., 2025-12-24 oder 2025-12-24-Teil-2
    return key_part[:4]  # Erste 4 Zeichen = Jahr


def copy_archive_to_target(
    archive_path: Path,
    target: dict[str, Any],
    *,
    immutable: bool = True,
    verbose: bool = True,
) -> bool:
    """Kopiert ein Archiv (`.iso` oder `.zip`) inkl. Manifest-Sidecar auf ein Target.

    Layout auf dem Target: `<target_path>/<year>/<archive_name>` —
    same wie in 2.0.x, format-agnostisch.

    `--immutable` ist konfigurierbar (ab 2.2.0): für eingefrorene Archive
    (out of Append-Window) ist `True` der Standard. Beim Append innerhalb
    des Append-Fensters muss explizit `False` übergeben werden, damit
    rclone das Server-Archiv überschreiben darf. Der Caller entscheidet
    (siehe `archive_appender.AppendPlan.is_replace`).

    Das Manifest-Sidecar wandert immer mit (im selben Verzeichnis, KEIN
    `--immutable` — bei Append-Replace MUSS das Manifest neu drüber).
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        if verbose:
            console.print("[red]❌ Fehler: Ungültiges Ziel (kein Pfad)[/red]")
        return False

    year = _get_year_from_archive_name(archive_path.name)
    remote_path = f"{target_path}/{year}"

    if verbose:
        file_size = archive_path.stat().st_size
        formatted_size = format_size(file_size)

        console.print(f"\n[bold]📤 Kopiere zu: {target_name}[/bold]")
        console.print(f"   Archiv: {archive_path.name}")
        console.print(f"   Grösse: {formatted_size}")
        console.print(f"   Ziel: {remote_path}/{archive_path.name}")
        if not immutable:
            console.print(
                "   [yellow]⚠️  --immutable AUS (Append-Replace im Cache-Fenster)[/yellow]"
            )

    try:
        # WARNUNG: `--immutable` ist die einzige Schicht, die eine bereits
        # archivierte Datei vor Überschreiben schützt. NUR ausschalten,
        # wenn der Caller einen Lazy-Check (Stufe 2: Manifest-Pull +
        # Size-Match) bestanden hat und ein bewusster Append-Replace
        # vorliegt. Out-of-Window → immer immutable=True.
        cmd = [
            "rclone",
            "copyto",
            str(archive_path),
            f"{remote_path}/{archive_path.name}",
        ]
        if immutable:
            cmd.append("--immutable")
        cmd.extend(["--stats", "5s", "--stats-one-line", "-v"])

        if verbose:
            result = subprocess.run(cmd)
        else:
            result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            if verbose:
                console.print(
                    f"[red]❌ Fehler beim Kopieren von {archive_path.name}[/red]"
                )
            return False

        # Manifest-Sidecar: bei Append-Replace MUSS es überschrieben werden
        # (neuer Inhalt = neues Manifest), daher nie --immutable.
        manifest_path = archive_path.with_name(
            archive_path.name + ".manifest.jsonl"
        )
        if manifest_path.exists():
            if verbose:
                console.print(f"   📋 Manifest: {manifest_path.name}")
            manifest_cmd = [
                "rclone",
                "copyto",
                str(manifest_path),
                f"{remote_path}/{manifest_path.name}",
                "--stats", "5s",
                "--stats-one-line",
            ]
            try:
                if verbose:
                    mf_result = subprocess.run(manifest_cmd)
                else:
                    mf_result = subprocess.run(
                        manifest_cmd, capture_output=True, text=True
                    )
                if mf_result.returncode != 0 and verbose:
                    console.print(
                        f"[yellow]⚠️  Manifest-Upload fehlgeschlagen: "
                        f"{manifest_path.name} "
                        f"(Archiv ist trotzdem hochgeladen)[/yellow]"
                    )
            except Exception as exc:
                if verbose:
                    console.print(
                        f"[yellow]⚠️  Manifest-Upload-Exception: {exc}[/yellow]"
                    )

        if verbose:
            console.print("[green]✅ Kopie abgeschlossen[/green]")
        return True

    except Exception as e:
        if verbose:
            console.print(f"[red]❌ Fehler beim Kopieren: {e}[/red]")
        return False


# Backwards-Compat-Alias — bestehende Aufrufer (z.B. cache_resync) können
# zunächst weiter `copy_iso_to_target` rufen.
def copy_iso_to_target(
    iso_path: Path,
    target: dict[str, Any],
    verbose: bool = True,
) -> bool:
    """Backwards-Compat (vor 2.2.0): leitet auf `copy_archive_to_target` mit
    `immutable=True` (Standard für ISOs ohne Append-Logik)."""
    return copy_archive_to_target(
        iso_path, target, immutable=True, verbose=verbose
    )


def upload_to_target(
    archive_files: list[Path],
    target: dict[str, Any],
    *,
    immutable_overrides: dict[Path, bool] | None = None,
    verbose: bool = True,
) -> bool:
    """Upload ZIP-Archive zu einem einzelnen rclone-Target.

    Ab 3.0.0 ZIP-only — `.iso`-Endungen werden als Fehler abgewiesen
    (siehe 3.0.0-Removal des ISO-Code-Pfads).

    `immutable_overrides`: optionale Map `{archive_path: immutable_bool}`.
    Wenn ein Pfad explizit `False` enthält, wird der zugehörige Upload
    OHNE `--immutable` ausgeführt (Append-Replace im Cache-Fenster).
    Default für jedes Archiv ohne Override: `True` (Standard-Safety).
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        if verbose:
            console.print("[red]❌ Fehler: Ungültiges Ziel (kein Pfad)[/red]")
        return False

    if verbose:
        console.print(f"\n[bold]🔄 Übertrage zu: {target_name}[/bold]")
        console.print(f"   Ziel: {target_path}")

    # immutable_overrides ist eine optionale Map archive_path → bool (False
    # = Append-Replace im Cache-Fenster). Wenn die Map fehlt oder ein Eintrag
    # fehlt, gilt der konservative Default (immutable=True).
    overrides: dict[Path, bool] = immutable_overrides or {}

    try:
        for archive_file in archive_files:
            if archive_file.suffix != ".zip":
                if verbose:
                    console.print(
                        f"[red]❌ Nicht-ZIP-Archiv abgelehnt: "
                        f"{archive_file.name} (ab 3.0.0 sind nur noch ZIPs "
                        "unterstützt)[/red]"
                    )
                return False
            immutable = overrides.get(archive_file, True)
            if not copy_archive_to_target(
                archive_file, target, immutable=immutable, verbose=verbose
            ):
                return False

        if verbose:
            console.print("[green]✅ Transfer abgeschlossen[/green]")
        return True

    except Exception as e:
        if verbose:
            console.print(f"[red]❌ Fehler beim Transfer: {e}[/red]")
        return False


def upload_to_all_targets(
    archive_files: list[Path],
    verbose: bool = True,
    cfg: "Config | None" = None,
    *,
    immutable_overrides: dict[Path, bool] | None = None,
) -> tuple[bool, list[str], list[str]]:
    """Upload archive files to all configured rclone targets in order.

    `immutable_overrides` wird an `upload_to_target` durchgereicht (siehe
    dort). Standard für jedes Archiv: `immutable=True` (Daten-Sicherheits-
    Default). Caller, die eine Append-Replace-Situation kennen (siehe
    `archive_appender.AppendPlan.is_replace`), übergeben pro betroffenes
    Archiv `False`.

    Returns:
        (all_successful, ok_target_names, failed_target_names)
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()

    if not targets:
        if verbose:
            console.print(
                "[red]❌ Fehler: Keine rclone-Ziele konfiguriert[/red]"
            )
        return False, [], []

    if verbose:
        console.print(f"\n[bold]📤 Starte Upload zu {len(targets)} Ziel(en)...[/bold]")
        for i, target in enumerate(targets, 1):
            console.print(f"   {i}. {target.get('name', target.get('path', 'Unknown'))}")

    successful_targets: list[str] = []
    failed_targets: list[str] = []

    for target in targets:
        target_name = target.get("name", target.get("path", "Unknown"))

        success = upload_to_target(
            archive_files,
            target,
            immutable_overrides=immutable_overrides,
            verbose=verbose,
        )

        if success:
            successful_targets.append(target_name)
        else:
            failed_targets.append(target_name)
            if verbose:
                console.print(f"[red]❌ {target_name} fehlgeschlagen![/red]")
            # Continue with next target even if one fails

    all_successful = len(failed_targets) == 0

    if verbose:
        console.print(f"\n{'=' * 50}")
        console.print("[bold]📊 Upload-Zusammenfassung[/bold]")
        console.print(f"{'=' * 50}")
        console.print(f"   Erfolgreich: {len(successful_targets)}/{len(targets)}")
        if successful_targets:
            for name in successful_targets:
                console.print(f"   [green]✅ {name}[/green]")
        if failed_targets:
            for name in failed_targets:
                console.print(f"   [red]❌ {name}[/red]")

    return all_successful, successful_targets, failed_targets


def list_archive_names_on_target(
    target: dict[str, Any],
    verbose: bool = False,
) -> set[str]:
    """Listet alle Archiv-Dateinamen (`.zip` + Legacy `.iso`) auf einem Target.

    Sucht rekursiv. Beide Endungen werden gelistet, damit der Startup-Guard
    auch Bestand-ISOs aus 1.x/2.0.x-Setups erkennt (und nicht fälschlich
    "Server leer" sagt, wenn da nur Legacy-ISOs liegen).

    Args:
        target: rclone target configuration dict with 'name' and 'path' keys
        verbose: If True, print progress messages

    Returns:
        Set of archive filenames found on the target.
    """
    target_name = target.get("name", target.get("path", "Unknown"))
    target_path = target.get("path", "")

    if not target_path:
        return set()

    try:
        cmd = [
            "rclone", "lsf",
            "--include", "*.zip",
            "--include", "*.iso",
            "--recursive",
            target_path,
        ]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            if verbose:
                console.print(f"[yellow]⚠️  Konnte Ziel {target_name} nicht prüfen[/yellow]")
            return set()

        names: set[str] = set()
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line and (line.endswith(".zip") or line.endswith(".iso")):
                # lsf returns paths like "2025/Originalmedien-2025-12-24.zip"
                names.add(Path(line).name)
        return names
    except Exception as e:
        if verbose:
            console.print(f"[yellow]⚠️  Fehler beim Prüfen von {target_name}: {e}[/yellow]")
        return set()


# Backwards-Compat-Alias (Tests, älterer DI-Test, schnittprojekt-Konsumenten).
list_iso_names_on_target = list_archive_names_on_target


def list_archive_names_on_all_targets(
    verbose: bool = False,
    cfg: "Config | None" = None,
) -> set[str]:
    """Listet alle Archiv-Dateinamen über alle konfigurierten rclone-Targets.

    Args:
        verbose: If True, print progress messages
        cfg: Explicit Config instance (DI). Fallback auf `get_config()`.

    Returns:
        Set of archive filenames found across all targets.
    """
    config = cfg if cfg is not None else get_config()
    targets = config.get_rclone_targets()

    if not targets:
        return set()

    all_names: set[str] = set()
    for target in targets:
        target_name = target.get("name", target.get("path", "Unknown"))
        if verbose:
            console.print(f"   🔍 Prüfe Ziel: {target_name}...")
        names = list_archive_names_on_target(target, verbose=verbose)
        if verbose:
            console.print(f"      {len(names)} Archiv(e) gefunden")
        all_names.update(names)

    return all_names


# Backwards-Compat-Alias.
list_iso_names_on_all_targets = list_archive_names_on_all_targets


def _write_exclude_filter_file(path: Path, filenames: set[str]) -> None:
    """Schreibt eine rclone-Filter-Datei: eine Zeile pro Dateiname als Exclude.

    Format: `- filename.ext` (Glob wird von rclone interpretiert). Die Muster
    sind absichtlich NICHT pfad-verankert (kein führender `/`), so matchen sie
    den Dateinamen in jedem Unterordner der Quelle. Das deckt Projekt­strukturen
    mit Unter­ordnern (`Media/`, `Media 2/` etc.) automatisch mit ab.

    Für rclone-Glob-Metazeichen (`*`, `?`, `[`, `]`, `{`, `}`) in Filenames wird
    via `[x]`-Klassen escaped, sodass Literal-Match garantiert ist.
    """
    def _escape(name: str) -> str:
        # rclone-Filter nutzt Glob. Jedes Metazeichen in `[]`-Class einpacken.
        special = set("*?[]{}!")
        return "".join(f"[{c}]" if c in special else c for c in name)

    with open(path, "w", encoding="utf-8") as f:
        for name in sorted(filenames):
            f.write(f"- {_escape(name)}\n")
