"""Manifest-Cache: scannt lokale `*.iso.manifest.jsonl`-Sidecars und
liefert Pre-Filter-Daten (was wurde schon archiviert?) für den Archive-Flow.

In 2.0.x übernahm der CSV-Index (`checksum_index.csv`) drei Aufgaben:

1. **Pre-Filter beim rclone-Pull**: bekannte Dateinamen überspringen, damit
   bereits archivierte Files nicht erneut übers Netz gezogen werden.
2. **Fall-C-Skip**: ein Tag wird vollständig übersprungen, wenn alle
   Quell-Dateinamen schon archiviert sind (lokale ISO nicht nötig).
3. **ISO-Namens-Kollisions-Check**: `get_unique_iso_path` muss wissen,
   welche ISO-Namen schon vergeben sind (für `-Teil-N`-Suffix).

Ab 2.1.0 sind genau diese drei Aufgaben Manifest-basiert: jede gebaute ISO
hat einen Sidecar `*.iso.manifest.jsonl` neben sich liegen, der alle
enthaltenen Dateien (mit Filename + SHA256) sowie Header (ISO-Name,
file_count etc.) auflistet. Damit ist der CSV-Index redundant — wir lesen
direkt aus den Sidecars.

**Wichtig**: Der Manifest-Cache lebt im Working-Dir (Primary + Fallback).
Sidecars bleiben auch dann liegen, wenn die ISO selbst via `cache prune`
entfernt wird — sie sind klein und dokumentieren dauerhaft, was archiviert
wurde. Pre-Filter funktionieren weiter, auch wenn die ISO physisch weg ist.
"""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import TYPE_CHECKING, Iterable

from .manifest_io import ManifestFormatError, iter_manifest_entries, read_manifest_header
from .manifest_schema import ManifestHeader

if TYPE_CHECKING:
    from ..config import Config

# Sidecars heissen `<archiv-name>.manifest.jsonl` — sowohl für `.iso` als
# auch für `.zip`. Wir scannen ab 2.2.0 beide Formate.
_MANIFEST_SUFFIXES = (".iso.manifest.jsonl", ".zip.manifest.jsonl")
_ARCHIVE_DAY_PATTERN = re.compile(
    r"^Originalmedien-(\d{4}-\d{2}-\d{2})(?:-Teil-\d+)?\.(?:iso|zip)$"
)


def working_dirs_from_config(cfg: "Config") -> list[Path]:
    """Liefert Primary + Fallback Working-Dirs als Liste für Manifest-Scan.

    Reihenfolge: Primary zuerst, dann Fallback. Leere Konfig-Werte und
    nicht existierende Pfade werden im Scan still übersprungen (siehe
    `_iter_manifest_paths`), die hier zurückgegebene Liste enthält nur
    konfigurierte Pfade.
    """
    dirs: list[Path] = []
    for getter in (cfg.get_working_directory, cfg.get_working_directory_fallback):
        path_str = getter()
        if path_str:
            dirs.append(Path(path_str).expanduser())
    return dirs


def _iter_manifest_paths(working_dirs: Iterable[Path]) -> Iterable[Path]:
    """Yieldet alle Manifest-Sidecar-Pfade aus den Working-Dirs (dedupliziert)."""
    seen: set[Path] = set()
    for wd in working_dirs:
        if wd is None:
            continue
        wd_path = Path(wd).expanduser()
        if not wd_path.exists() or not wd_path.is_dir():
            continue
        for path in wd_path.iterdir():
            if not path.is_file():
                continue
            if not any(path.name.endswith(s) for s in _MANIFEST_SUFFIXES):
                continue
            if path in seen:
                continue
            seen.add(path)
            yield path


def _archive_name_from_manifest_path(manifest_path: Path) -> str:
    """Aus `Originalmedien-X.iso.manifest.jsonl` wird `Originalmedien-X.iso`
    (analog für `.zip`)."""
    return manifest_path.name[: -len(".manifest.jsonl")]


def _day_from_archive_name(archive_name: str) -> str | None:
    """Extrahiert `YYYY-MM-DD` aus `Originalmedien-YYYY-MM-DD[-Teil-N].(iso|zip)`."""
    match = _ARCHIVE_DAY_PATTERN.match(archive_name)
    return match.group(1) if match else None


def iso_names_archived(working_dirs: Iterable[Path]) -> set[str]:
    """Set aller Archiv-Namen (`.iso` ODER `.zip`), für die ein lokales
    Manifest existiert.

    Ersetzt `checksum.get_iso_names_from_index` für den Namens-Kollisions-
    Check in `get_unique_archive_path` (Teil-N-Suffix-Wahl).
    """
    return {
        _archive_name_from_manifest_path(p)
        for p in _iter_manifest_paths(working_dirs)
    }


def all_archived_filenames(working_dirs: Iterable[Path]) -> set[str]:
    """Alle Dateinamen aus allen lokalen Manifests, NFC-normalisiert.

    Ersetzt `checksum.all_indexed_filenames` für den rclone-Pull-Pre-Filter.
    Beschädigte/unlesbare Manifests werden still übersprungen (Best-Effort —
    Pre-Filter ist eine Optimierung, kein Korrektheits-Garant).
    """
    result: set[str] = set()
    for manifest_path in _iter_manifest_paths(working_dirs):
        try:
            for entry in iter_manifest_entries(manifest_path):
                result.add(unicodedata.normalize("NFC", entry.filename))
        except (ManifestFormatError, OSError):
            continue
    return result


def filenames_archived_for_day(
    working_dirs: Iterable[Path], day_key: str
) -> set[str]:
    """Dateinamen aus Manifests, deren Archiv zum angegebenen Tag gehört.

    Ersetzt `checksum.filenames_indexed_for_day` für den Fall-C-Skip
    (Tag komplett überspringen, wenn alle Quell-Files bereits in einem
    archivierten Archiv sind — auch wenn das Archiv lokal nicht mehr da ist).

    Berücksichtigt sowohl `.iso` als auch `.zip` und alle `-Teil-N`-
    Varianten desselben Tages.
    """
    result: set[str] = set()
    for manifest_path in _iter_manifest_paths(working_dirs):
        archive_name = _archive_name_from_manifest_path(manifest_path)
        if _day_from_archive_name(archive_name) != day_key:
            continue
        try:
            for entry in iter_manifest_entries(manifest_path):
                result.add(unicodedata.normalize("NFC", entry.filename))
        except (ManifestFormatError, OSError):
            continue
    return result


def read_manifest_header_safe(manifest_path: Path) -> ManifestHeader | None:
    """Liest den Header eines Manifests; gibt `None` bei Fehler zurück.

    Hilfsfunktion für `cache list` und ähnliche Operator-Befehle, die
    Header-Infos (file_count, total_bytes, …) tabellarisch ausgeben.
    """
    import json

    try:
        return read_manifest_header(manifest_path)
    except (ManifestFormatError, OSError, json.JSONDecodeError):
        return None
