"""Remote-Manifest-Primitive für Append-Safety (2.2.0, Stufe-2-Lazy-Check).

Bevor wir ein bereits auf dem Server liegendes Archiv per Append modifizieren,
prüfen wir mit minimalem Aufwand, ob das, was lokal liegt, ein verlässliches
Superset des Server-Standes ist. Vorgehen:

1. **Manifest-Sidecar pullen** (`rclone copy …manifest.jsonl`): wenige KBs, in
   Sub-Sekunden über jedes rclone-Backend. Enthält Filename + SHA-256 pro
   File und den Archiv-Hash im Header. Das ist unsere autoritative
   "was-liegt-im-Server-Archiv"-Liste.
2. **Archiv-Grösse abfragen** (`rclone size …archive`): Sub-Sekunde, ein
   Metadata-Call. Vergleich gegen `manifest.iso_size` fängt offensichtliche
   Inkonsistenzen (partial-uploaded Archiv) ab.
3. **Subset-Check** lokal: ist jeder (filename, sha256) aus dem Server-
   Manifest auch im lokal geplanten neuen Archiv enthalten? Wenn ja → safe to
   replace. Wenn nein → Hard-Abort mit Diagnose, weil ein Replace einen
   Datenverlust bedeuten würde.

Stufe-3-Verify (komplette SHA-256-Verifikation des Server-Archivs) ist hier
nicht implementiert; das ist eine opt-in Audit-Operation für später.
"""

from __future__ import annotations

import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from .manifest_io import ManifestFormatError, read_manifest
from .manifest_schema import FileEntry, ManifestHeader

if TYPE_CHECKING:
    from ..config import Config

console = Console()


def remote_archive_dir(target: dict, day_key: str) -> str:
    """Liefert das Remote-Verzeichnis für ein Archiv eines bestimmten Tages.

    Layout konsistent mit `rclone.copy_iso_to_target` und `copy_archive_to_target`:
    `<target_path>/<year>/`. Beispiel:
    `lyssach-nas:/Originalmedien/2026/`.
    """
    target_path = target.get("path", "").rstrip("/")
    year = day_key[:4]
    return f"{target_path}/{year}"


def remote_archive_path(target: dict, archive_name: str) -> str:
    """Voller rclone-Pfad eines Archivs (z.B. `nas:/Originalmedien/2026/Originalmedien-2026-05-12.zip`)."""
    # Day-Key aus dem Archiv-Namen ableiten (Originalmedien-YYYY-MM-DD[-Teil-N].(iso|zip))
    stem = Path(archive_name).stem
    day_key = stem.replace("Originalmedien-", "")[:10]
    return f"{remote_archive_dir(target, day_key)}/{archive_name}"


def remote_manifest_path(target: dict, archive_name: str) -> str:
    """Pfad zum Manifest-Sidecar eines Archivs auf dem Remote."""
    return f"{remote_archive_path(target, archive_name)}.manifest.jsonl"


@dataclass
class RemoteArchiveState:
    """Was der Server zu einem Archiv weiss — alles aus dem Lazy-Check."""

    archive_name: str
    target_name: str
    exists: bool
    size: int | None
    manifest_header: ManifestHeader | None
    manifest_entries: list[FileEntry]

    @property
    def filenames_with_sha256(self) -> set[tuple[str, str]]:
        """`{(filename, sha256)}` für jeden Manifest-Eintrag — Schlüssel
        für den Subset-Check."""
        return {(e.filename, e.sha256) for e in self.manifest_entries}


def _run_rclone(cmd: list[str]) -> subprocess.CompletedProcess:
    """Wrapper um `subprocess.run` für rclone-Aufrufe mit konsistenten Defaults."""
    return subprocess.run(cmd, capture_output=True, text=True)


def remote_file_exists(remote_path: str) -> bool:
    """Prüft via `rclone lsf`, ob das File auf dem Remote existiert."""
    # `rclone lsf --files-only "path/"` listet den Ordner; alternativ:
    # `rclone lsf "remote:path/file"` listet den File-Namen, wenn er existiert.
    proc = _run_rclone(["rclone", "lsf", remote_path])
    if proc.returncode != 0:
        return False
    return bool(proc.stdout.strip())


def remote_file_size(remote_path: str) -> int | None:
    """Grösse via `rclone size --json`, oder None bei Fehler/nicht-existent."""
    proc = _run_rclone(["rclone", "size", "--json", remote_path])
    if proc.returncode != 0:
        return None
    try:
        data = json.loads(proc.stdout)
        bytes_total = data.get("bytes")
        if isinstance(bytes_total, int):
            return bytes_total
    except (json.JSONDecodeError, ValueError):
        return None
    return None


def pull_remote_manifest(
    remote_manifest_full_path: str,
    *,
    verbose: bool = False,
) -> tuple[ManifestHeader, list[FileEntry]] | None:
    """Lädt das Manifest-Sidecar vom Remote in ein Temp-File und parst es.

    Returns:
        `(header, entries)` bei Erfolg. `None` wenn das Manifest auf dem
        Remote nicht existiert oder beim Pull/Parse ein Fehler auftrat.
    """
    if verbose:
        console.print(f"[dim]   📥 Pulle Manifest: {remote_manifest_full_path}[/dim]")

    with tempfile.TemporaryDirectory(prefix="kamera-einleser-remote-manifest-") as tmp:
        proc = _run_rclone(
            ["rclone", "copy", remote_manifest_full_path, tmp]
        )
        if proc.returncode != 0:
            if verbose:
                err = (proc.stderr or proc.stdout).strip()
                console.print(
                    f"[yellow]   ⚠️  Manifest-Pull fehlgeschlagen: {err}[/yellow]"
                )
            return None

        # rclone copy legt das File mit dem Original-Namen in tmp ab
        filename = remote_manifest_full_path.rsplit("/", 1)[-1]
        local_path = Path(tmp) / filename
        if not local_path.exists():
            return None

        try:
            return read_manifest(local_path)
        except ManifestFormatError as exc:
            if verbose:
                console.print(
                    f"[yellow]   ⚠️  Manifest unleserlich: {exc}[/yellow]"
                )
            return None


def fetch_remote_state(
    target: dict,
    archive_name: str,
    *,
    verbose: bool = False,
) -> RemoteArchiveState:
    """Komplette Lazy-Check-Abfrage für ein Archiv auf einem Target.

    Macht in der Reihenfolge:
    1. Archiv-Existenz + Grösse via `rclone size`
    2. Wenn Archiv existiert: Manifest pullen + parsen

    Returns:
        `RemoteArchiveState` — auch wenn das Archiv nicht existiert
        (`exists=False`, `size=None`, `manifest_header=None`,
        `manifest_entries=[]`).
    """
    target_name = target.get("name", target.get("path", "?"))

    full_archive_path = remote_archive_path(target, archive_name)
    size = remote_file_size(full_archive_path)
    exists = size is not None and size > 0

    state = RemoteArchiveState(
        archive_name=archive_name,
        target_name=target_name,
        exists=exists,
        size=size,
        manifest_header=None,
        manifest_entries=[],
    )

    if not exists:
        return state

    full_manifest_path = remote_manifest_path(target, archive_name)
    pulled = pull_remote_manifest(full_manifest_path, verbose=verbose)
    if pulled is None:
        return state  # exists=True, aber Manifest fehlt → wird im verify als ABORT-Grund auftauchen

    state.manifest_header, state.manifest_entries = pulled
    return state


@dataclass
class AppendSafetyResult:
    """Ergebnis des Append-Safety-Checks."""

    safe: bool
    """True genau dann, wenn das geplante neue Archiv den Server-Stand
    sicher ersetzen darf (Subset-Garantie + konsistente Metadaten)."""

    diagnostic: str
    """Erklärung in Klartext — wird bei `safe=False` dem User gezeigt."""


def verify_append_safe(
    *,
    server_state: RemoteArchiveState,
    new_filename_shas: set[tuple[str, str]],
) -> AppendSafetyResult:
    """Prüft, ob das geplante neue Archiv das Server-Archiv sicher ersetzen darf.

    Vertrag: alle (filename, sha256)-Tupel aus dem Server-Manifest müssen in
    `new_filename_shas` enthalten sein. Sonst wäre der Upload ein Replace
    mit Datenverlust.

    Args:
        server_state: aus `fetch_remote_state()`.
        new_filename_shas: was wir lokal in das neue Archiv schreiben werden
            (Set von `(filename, sha256)`).

    Returns:
        `AppendSafetyResult` mit `safe` und Klartext-Begründung.
    """
    if not server_state.exists:
        # Kein bestehendes Server-Archiv → kein Konflikt, neu schreiben OK.
        return AppendSafetyResult(safe=True, diagnostic="Server hat noch kein Archiv für diesen Tag.")

    if server_state.manifest_header is None:
        return AppendSafetyResult(
            safe=False,
            diagnostic=(
                f"Server-Archiv {server_state.archive_name} existiert "
                f"({server_state.size} Bytes), aber Manifest-Sidecar fehlt "
                "oder ist unleserlich. Append zu blind wäre unsicher. "
                "Manueller Eingriff nötig (z.B. cache resync)."
            ),
        )

    if server_state.size != server_state.manifest_header.iso_size:
        return AppendSafetyResult(
            safe=False,
            diagnostic=(
                f"Server-Archiv-Grösse ({server_state.size} Bytes) "
                f"weicht von Manifest-Header ab "
                f"({server_state.manifest_header.iso_size} Bytes). "
                "Server-Stand ist inkonsistent — Append blockiert."
            ),
        )

    server_set = server_state.filenames_with_sha256
    missing = server_set - new_filename_shas

    if missing:
        sample = list(missing)[:3]
        return AppendSafetyResult(
            safe=False,
            diagnostic=(
                f"{len(missing)} Datei(en) im Server-Archiv würden durch "
                f"den geplanten Upload VERLOREN gehen. Beispiele: "
                f"{', '.join(name for name, _ in sample)}"
                f"{' …' if len(missing) > 3 else ''}."
            ),
        )

    return AppendSafetyResult(
        safe=True,
        diagnostic=(
            f"Subset-Check OK: alle {len(server_set)} Server-Files werden "
            f"im neuen Archiv erhalten bleiben."
        ),
    )


def first_target(cfg: "Config") -> dict | None:
    """Das erste konfigurierte rclone-Target (Convention: das ist die
    primäre Quelle für Lazy-Checks und `cache fetch`)."""
    targets = cfg.get_rclone_targets()
    return targets[0] if targets else None
