"""Replikations-Marker — lokaler Beleg "Archiv erfolgreich auf allen Targets".

Hintergrund: In 2.0.x signalisierte der zentrale CSV-Index `checksum_index.csv`
nach erfolgreichem Upload-zu-allen-Targets, dass eine ISO sicher repliziert ist
("Index = überall vorhanden"). Ab 2.2.0 fällt der CSV-Index weg; stattdessen
liegt neben jedem Archiv ein winziger Sidecar `*.uploaded.json`, der genau
diese Info pro-Archiv lokal hält.

**Lokal-only**: der Marker wird NICHT auf den Server hochgeladen. Er ist
maschinen-spezifisches Wissen ("DIESER Rechner hat zu DIESEN Targets erfolgreich
gepusht"). Auf einer anderen Maschine mit anderer Target-Liste wäre der Marker
nicht aussagekräftig. Cross-Machine-Wahrheit ist das Manifest, nicht der Marker.

**Use-Cases**:
- `cache prune` löscht ein Archiv nur, wenn ein Marker existiert und alle
  konfigurierten Targets darin aufgelistet sind (Belt-and-Suspenders).
- `cache resync` (Recovery nach Partial-Upload) lädt nochmal zu fehlenden
  Targets und schreibt den Marker erst nach vollständiger Replikation.

Format:

    {
      "_type": "replication_marker",
      "marker_version": 1,
      "archive_name": "Originalmedien-2026-04-22.iso",
      "uploaded_to": ["Lyssach NAS", "Mega.nz"],
      "completed_at": "2026-05-12T18:30:00+02:00",
      "tool_version": "2.2.0"
    }
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

_MARKER_SUFFIX = ".uploaded.json"
_MARKER_VERSION = 1


@dataclass
class ReplicationMarker:
    """Inhalt eines `*.uploaded.json`-Sidecars."""

    archive_name: str
    uploaded_to: list[str]
    completed_at: str  # ISO-8601-Zeitstempel
    tool_version: str
    marker_version: int = _MARKER_VERSION

    def to_dict(self) -> dict:
        return {
            "_type": "replication_marker",
            "marker_version": self.marker_version,
            "archive_name": self.archive_name,
            "uploaded_to": list(self.uploaded_to),
            "completed_at": self.completed_at,
            "tool_version": self.tool_version,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ReplicationMarker":
        return cls(
            archive_name=data["archive_name"],
            uploaded_to=list(data.get("uploaded_to", [])),
            completed_at=data.get("completed_at", ""),
            tool_version=data.get("tool_version", ""),
            marker_version=int(data.get("marker_version", _MARKER_VERSION)),
        )


def marker_path_for_archive(archive_path: Path) -> Path:
    """Liefert den Sidecar-Pfad: `<archive>.uploaded.json` neben dem Archiv."""
    return archive_path.with_name(archive_path.name + _MARKER_SUFFIX)


def write_marker(
    archive_path: Path,
    targets: list[str],
    tool_version: str,
    *,
    completed_at: str | None = None,
) -> Path:
    """Schreibt den Marker atomisch (tempfile + os.replace) neben das Archiv.

    Args:
        archive_path: Pfad zum Archiv (`.iso` oder `.zip`); muss nicht existieren.
        targets: Namen aller Targets, an die erfolgreich repliziert wurde.
        tool_version: aktuelle kamera-einleser-Version (für Audit).
        completed_at: ISO-8601-Zeitstempel; Default = jetzt (lokal).

    Returns:
        Pfad zum geschriebenen Marker.
    """
    if completed_at is None:
        completed_at = datetime.now().astimezone().isoformat(timespec="seconds")

    marker = ReplicationMarker(
        archive_name=archive_path.name,
        uploaded_to=list(targets),
        completed_at=completed_at,
        tool_version=tool_version,
    )

    out_path = marker_path_for_archive(archive_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    tmp_fd, tmp_path = tempfile.mkstemp(
        prefix=f".{out_path.name}.", suffix=".tmp", dir=str(out_path.parent)
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            json.dump(marker.to_dict(), f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp_path, out_path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise

    return out_path


def read_marker(archive_path: Path) -> ReplicationMarker | None:
    """Liest den Marker für ein Archiv; `None` wenn nicht vorhanden / kaputt."""
    marker_path = marker_path_for_archive(archive_path)
    if not marker_path.exists():
        return None
    try:
        with open(marker_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return ReplicationMarker.from_dict(data)
    except (json.JSONDecodeError, OSError, KeyError):
        return None


def is_replicated_to_all(
    archive_path: Path, expected_targets: list[str]
) -> bool:
    """Prüft, ob das Archiv laut Marker zu **allen** erwarteten Targets repliziert ist.

    Vergleich ist Set-basiert (Reihenfolge irrelevant). Zusätzliche Targets im
    Marker, die nicht mehr in der aktuellen Config stehen, schaden nicht.

    Returns:
        True wenn Marker existiert und `set(expected_targets) ⊆ set(marker.uploaded_to)`,
        sonst False.
    """
    marker = read_marker(archive_path)
    if marker is None:
        return False
    return set(expected_targets).issubset(set(marker.uploaded_to))
