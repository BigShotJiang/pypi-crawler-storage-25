"""ZIP-Inspector — schneller Fall-A-Subset-Check ohne Mount.

Liest das Central Directory am Ende der ZIP-Datei via `ZipFile.namelist()`
in Millisekunden — kein Mount, kein Filesystem-Scan, keine Detach-Cleanup-
Sorgen. Ab 3.0.0 ist der ISO-Mount-Pfad entfernt; Legacy-ISO-Files im
Cache werden ignoriert (Verantwortung des Operators, sie vorher zu
migrieren oder zu löschen).
"""

from __future__ import annotations

import unicodedata
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

if TYPE_CHECKING:
    from .file_scanner import FileInfo

console = Console()


def check_files_in_existing_zip(
    files: list["FileInfo"],
    existing_zip_paths: list[Path],
    *,
    verbose: bool = True,
) -> list["FileInfo"]:
    """Liefert die Teilmenge von `files`, die NICHT in den ZIPs liegt.

    Vergleich basiert auf dem **relativen Pfad** (NFC-normalisiert), wie in
    der bestehenden ISO-Variante. Member-Grösse wird im ZIP-Header geprüft
    (Stored-CompressedSize == UncompressedSize == Original-Bytes), kommt aber
    in `FileInfo.size` an, sodass Diff-Erkennung "gleicher Name, andere
    Grösse" auch bei ZIP geht.

    Args:
        files: Liste der zu prüfenden Quell-Files.
        existing_zip_paths: ein oder mehrere bestehende `*.zip`-Dateien.
        verbose: steuert CLI-Ausgabe.

    Returns:
        Files, die in keiner der ZIPs mit identischem (relative_path, size)
        existieren. Reihenfolge wie in `files` übergeben.
    """
    if not existing_zip_paths:
        return list(files)

    known: set[tuple[str, int]] = set()
    for zip_path in existing_zip_paths:
        if verbose:
            console.print(f"   📂 Lese ZIP-Index: {zip_path.name}")
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    rel = unicodedata.normalize("NFC", info.filename)
                    known.add((rel, info.file_size))
        except (zipfile.BadZipFile, OSError) as exc:
            if verbose:
                console.print(
                    f"[yellow]   ⚠️  ZIP unleserlich, überspringe: "
                    f"{zip_path.name} ({exc})[/yellow]"
                )
            continue

    missing: list["FileInfo"] = []
    for f in files:
        rel = unicodedata.normalize("NFC", str(f.relative_path))
        if (rel, f.size) not in known:
            missing.append(f)

    if verbose:
        present = len(files) - len(missing)
        console.print(
            f"   📊 {present}/{len(files)} Datei(en) bereits in ZIP(s), "
            f"{len(missing)} fehlen"
        )

    return missing


def check_files_in_existing_archive(
    files: list["FileInfo"],
    existing_archive_paths: list[Path],
    *,
    verbose: bool = True,
) -> list["FileInfo"]:
    """Subset-Check gegen ZIP-Archive (ab 3.0.0 ZIP-only).

    Legacy-`.iso`-Dateien in der Liste werden ignoriert mit einem Hinweis.
    """
    if not existing_archive_paths:
        return list(files)

    zips = [p for p in existing_archive_paths if p.suffix.lower() == ".zip"]
    others = [p for p in existing_archive_paths if p.suffix.lower() != ".zip"]
    if others and verbose:
        for p in others:
            console.print(
                f"[yellow]   ⚠️  Nicht-ZIP-Archiv im Cache, ignoriere: "
                f"{p.name} (vor 3.0.0-Update migrieren)[/yellow]"
            )

    if zips:
        files = check_files_in_existing_zip(files, zips, verbose=verbose)

    return list(files)
