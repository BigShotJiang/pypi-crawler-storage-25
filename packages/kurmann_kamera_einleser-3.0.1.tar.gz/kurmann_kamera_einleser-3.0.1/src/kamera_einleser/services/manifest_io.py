"""JSONL-IO für ISO-Manifests + Best-Guess-Aufnahmedatum.

`*.iso.manifest.jsonl`-Format:

    {"_type":"header", "manifest_version":1, "iso_name":"...", ...}
    {"filename":"clip1.mov", ...}
    {"filename":"clip2.mov", ...}

Eine Zeile = ein JSON-Objekt. Header ist Pflicht und muss erste Zeile sein.
Streamt sauber bei grossen ISOs (1000+ Files).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator

# Re-Export für Backwards-Compat — pick_recorded_at und normalize_iso_date
# leben ab 2.1.0 in kurmann-medien-leser. Re-Export hier hält bestehenden
# Code funktional, der diese Symbole aus manifest_io importierte
# (z.B. Tests).
from kurmann_medien_leser import (  # noqa: F401
    normalize_iso_date,
    pick_recorded_at,
)

from .manifest_schema import (
    FileEntry,
    ManifestHeader,
)


class ManifestFormatError(ValueError):
    """Manifest-Datei ist syntaktisch oder semantisch kaputt."""


def write_manifest(
    path: Path, header: ManifestHeader, entries: list[FileEntry]
) -> None:
    """Schreibt ein vollständiges Manifest atomisch (Temp + os.replace)."""
    import os
    import tempfile

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_path = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(header.to_dict(), ensure_ascii=False))
            f.write("\n")
            for entry in entries:
                f.write(json.dumps(entry.to_dict(), ensure_ascii=False))
                f.write("\n")
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def read_manifest(path: Path) -> tuple[ManifestHeader, list[FileEntry]]:
    """Liest ein vollständiges Manifest komplett in den Speicher.

    Für grosse Manifests (>10'000 Einträge) lieber `iter_manifest_entries`
    nutzen, das streamt zeilenweise.
    """
    header: ManifestHeader | None = None
    entries: list[FileEntry] = []
    for line_num, obj in _iter_jsonl(path):
        if line_num == 1:
            if obj.get("_type") != "header":
                raise ManifestFormatError(
                    f"{path}: Erste Zeile muss ein Header sein "
                    f"(`_type: \"header\"`), war {obj.get('_type')!r}"
                )
            header = ManifestHeader.from_dict(obj)
        else:
            entries.append(FileEntry.from_dict(obj))
    if header is None:
        raise ManifestFormatError(f"{path}: leeres Manifest, kein Header gefunden")
    return header, entries


def iter_manifest_entries(path: Path) -> Iterator[FileEntry]:
    """Streamt Datei-Einträge (ohne Header) für Speicher-Effizienz."""
    for line_num, obj in _iter_jsonl(path):
        if line_num == 1:
            continue  # Header überspringen
        yield FileEntry.from_dict(obj)


def read_manifest_header(path: Path) -> ManifestHeader:
    """Liest nur den Header (= erste Zeile). Praktisch für Übersichts-Listings."""
    with open(path, "r", encoding="utf-8") as f:
        first = f.readline()
    if not first.strip():
        raise ManifestFormatError(f"{path}: leer")
    obj = json.loads(first)
    if obj.get("_type") != "header":
        raise ManifestFormatError(
            f"{path}: Erste Zeile ist kein Header (`_type: \"header\"`)"
        )
    return ManifestHeader.from_dict(obj)


def _iter_jsonl(path: Path) -> Iterator[tuple[int, dict]]:
    """Generator: (line_number, parsed_obj) je non-leerer Zeile."""
    with open(path, "r", encoding="utf-8") as f:
        for n, raw in enumerate(f, start=1):
            line = raw.strip()
            if not line:
                continue
            try:
                yield n, json.loads(line)
            except json.JSONDecodeError as exc:
                raise ManifestFormatError(
                    f"{path}:{n}: ungültiges JSON: {exc}"
                ) from exc

