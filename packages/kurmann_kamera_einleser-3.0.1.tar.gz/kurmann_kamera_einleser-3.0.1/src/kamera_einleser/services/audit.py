"""Audit-Funktionen über bestehende ISO-Manifests (ab 2.0.0).

Aktuell ein Befund: **iso-grouping**. Beantwortet die Frage "passen die
Aufnahmedaten der Files in einer ISO zum Tag, der im ISO-Namen steht?".

Hintergrund: bis und mit 1.x gruppierte kamera-einleser ISOs nach
`stat.st_mtime` (Filesystem-Modification-Time, oft Übertragungs-Zeitpunkt),
nicht nach echtem Aufnahmedatum aus EXIF. Das produziert "Misch-Tag-ISOs":
am 29.04. wurden Files vom 15.04. kopiert (mtime = 29.04.), ISO trägt 29.04.
im Namen, Inhalt ist 14 Tage älter. Mit den Manifests aus 2.0.0
(`recorded_at` mit Provenance) lässt sich das rückwirkend sichtbar machen.

Der Audit ist read-only — er ändert nichts, sondern berichtet. Aktionen
(Re-Pack o.ä.) sind Sache eines späteren, expliziten Befehls.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from .manifest_io import iter_manifest_entries, read_manifest_header
from .manifest_schema import FileEntry, ManifestHeader

# `Originalmedien-YYYY-MM-DD[-Teil-N].iso` — zieht den `YYYY-MM-DD`-Anteil raus
_ISO_DAY_RE = re.compile(r"Originalmedien-(\d{4}-\d{2}-\d{2})(?:-Teil-\d+)?\.iso$")


@dataclass
class IsoGroupingFinding:
    """Befund für eine einzelne ISO."""

    iso_name: str
    expected_day: str | None  # aus dem ISO-Namen extrahiert (None wenn nicht parsbar)
    file_count: int
    files_matching_expected: int
    files_off_day: int
    files_without_recorded_at: int
    days_seen: Counter  # day_key → count (alle Tage, die in der ISO auftauchen)
    earliest_recorded_at: str | None
    latest_recorded_at: str | None
    manifest_path: Path

    @property
    def is_clean(self) -> bool:
        """True, wenn alle Files mit `recorded_at` zum erwarteten Tag passen."""
        if self.expected_day is None:
            return False  # können wir nicht beurteilen
        return self.files_off_day == 0 and self.files_matching_expected > 0

    @property
    def status_emoji(self) -> str:
        if self.expected_day is None:
            return "❓"
        if self.is_clean:
            return "✅"
        return "⚠️"


@dataclass
class IsoGroupingReport:
    """Aggregat aller Befunde."""

    findings: list[IsoGroupingFinding] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.findings)

    @property
    def clean_count(self) -> int:
        return sum(1 for f in self.findings if f.is_clean)

    @property
    def mixed_count(self) -> int:
        return sum(
            1
            for f in self.findings
            if f.expected_day is not None and not f.is_clean
        )

    @property
    def unparsable_count(self) -> int:
        return sum(1 for f in self.findings if f.expected_day is None)


def expected_day_from_iso_name(iso_name: str) -> str | None:
    """Extrahiert den erwarteten Tag (YYYY-MM-DD) aus dem ISO-Namen.

    Beispiele:
        "Originalmedien-2026-04-22.iso"        → "2026-04-22"
        "Originalmedien-2026-04-22-Teil-2.iso" → "2026-04-22"
        "MeineEigene.iso"                      → None
    """
    m = _ISO_DAY_RE.search(iso_name)
    return m.group(1) if m else None


def audit_iso_grouping(
    manifest_paths: list[Path],
) -> IsoGroupingReport:
    """Vergleicht pro Manifest die `recorded_at`-Tage gegen den ISO-Namen-Tag.

    Args:
        manifest_paths: Liste von `*.manifest.jsonl`-Pfaden. Jeder Pfad wird
            individuell ausgewertet — Reihenfolge bleibt erhalten.

    Returns:
        Ein `IsoGroupingReport` mit einem Finding pro Manifest. Manifests,
        die nicht lesbar sind, werden mit `expected_day=None` und Counter()
        eingetragen — der Caller entscheidet, wie damit umgegangen wird.
    """
    report = IsoGroupingReport()

    for path in manifest_paths:
        try:
            header = read_manifest_header(path)
            entries = list(iter_manifest_entries(path))
        except Exception:
            # Beschädigtes Manifest — als "unparsbar" markieren, ohne den
            # Gesamt-Audit zu kippen.
            report.findings.append(
                IsoGroupingFinding(
                    iso_name=path.stem.replace(".iso.manifest", ".iso"),
                    expected_day=None,
                    file_count=0,
                    files_matching_expected=0,
                    files_off_day=0,
                    files_without_recorded_at=0,
                    days_seen=Counter(),
                    earliest_recorded_at=None,
                    latest_recorded_at=None,
                    manifest_path=path,
                )
            )
            continue

        finding = _analyze_one(header, entries, path)
        report.findings.append(finding)

    return report


def _analyze_one(
    header: ManifestHeader, entries: list[FileEntry], manifest_path: Path
) -> IsoGroupingFinding:
    expected = expected_day_from_iso_name(header.iso_name)

    days: Counter = Counter()
    no_recorded = 0
    matching = 0
    off_day = 0
    earliest: str | None = None
    latest: str | None = None

    for entry in entries:
        if not entry.recorded_at:
            no_recorded += 1
            continue
        # Wir gruppieren nach den ersten 10 Zeichen (`YYYY-MM-DD`) — robust
        # gegen unterschiedliche TZ-Suffixe und Format-Varianten.
        day = entry.recorded_at[:10]
        days[day] += 1

        # earliest / latest auf String-Vergleichsbasis (ISO-8601 ist
        # lexikographisch sortierbar)
        if earliest is None or entry.recorded_at < earliest:
            earliest = entry.recorded_at
        if latest is None or entry.recorded_at > latest:
            latest = entry.recorded_at

        if expected:
            if day == expected:
                matching += 1
            else:
                off_day += 1

    return IsoGroupingFinding(
        iso_name=header.iso_name,
        expected_day=expected,
        file_count=len(entries),
        files_matching_expected=matching,
        files_off_day=off_day,
        files_without_recorded_at=no_recorded,
        days_seen=days,
        earliest_recorded_at=earliest,
        latest_recorded_at=latest,
        manifest_path=manifest_path,
    )


def discover_manifests(path: Path) -> list[Path]:
    """Findet `*.manifest.jsonl`-Files in einem Pfad.

    - Wenn `path` eine Datei ist und auf `.manifest.jsonl` endet: nur diese
    - Wenn `path` ein Verzeichnis ist: rekursiv alle `*.manifest.jsonl`
    - Sonst: leere Liste

    Sortiert alphabetisch, damit der Output stabil ist.
    """
    if path.is_file() and path.name.endswith(".manifest.jsonl"):
        return [path]
    if path.is_dir():
        return sorted(path.rglob("*.manifest.jsonl"))
    return []
