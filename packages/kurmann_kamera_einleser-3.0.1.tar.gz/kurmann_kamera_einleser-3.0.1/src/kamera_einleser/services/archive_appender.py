"""Append-Orchestrator (2.2.0).

Wenn `archive` für einen Tag aufgerufen wird, der **bereits** ein Archiv hat
(lokal oder remote), entscheidet dieser Modul, ob und wie das bestehende
Archiv um die neuen Files ergänzt wird. Workflow:

1. **Bestand erkennen**: ist ein ZIP für diesen Tag lokal im Cache? Oder
   auf einem konfigurierten Remote-Target?
2. **Sicherheits-Vorab-Check (Stufe 2)**: das Remote-Manifest pullen
   (sub-Sekunde, KBs) und gegen den geplanten neuen Inhalt prüfen. Wenn
   Server-Files im neuen Plan fehlen oder Grössen-Mismatch besteht →
   Hard-Abort mit klarer Diagnose.
3. **Build entscheiden**: was geht in das neue ZIP rein?
   - Wenn der Server-Stand voll im neuen Plan enthalten ist → bauen +
     ersetzen (rclone OHNE --immutable für diesen Tag innerhalb des
     Append-Window).
   - Wenn Server leer ist (kein bestehendes Archiv) → frisch bauen.

Das Modul selbst bewegt **keine Daten**; es liefert nur die Entscheidung,
welche Files in das neue Archiv gehören und ob das Upload-Ergebnis den
Server-Stand überschreiben darf. Der tatsächliche ZIP-Bau passiert in
`zip_builder.create_zip`, der Upload in `rclone.copy_archive_to_target`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from .manifest_io import iter_manifest_entries
from .manifest_schema import ManifestHeader
from .remote_manifest import (
    AppendSafetyResult,
    RemoteArchiveState,
    fetch_remote_state,
)

if TYPE_CHECKING:
    from ..config import Config
    from .file_scanner import FileInfo

console = Console()


@dataclass
class AppendPlan:
    """Resultat des Append-Planungs-Schritts.

    Wenn `proceed=True`, kann der Caller mit `final_files` ein neues Archiv
    bauen. `is_replace` zeigt an, ob das Upload-Ergebnis ein Server-Replace
    sein wird (dann muss `--immutable` für diesen Upload deaktiviert sein).

    Wenn `proceed=False`, ist `safety` der Grund: entweder `safety.safe=False`
    (Lazy-Check-Konflikt) oder ein anderes Hindernis. `safety.diagnostic`
    enthält die Klartext-Begründung für den User.
    """

    proceed: bool
    """Darf ein neues Archiv gebaut und (ggf. Server-überschreibend) hochgeladen werden?"""

    final_files: list["FileInfo"]
    """Files, die in das neue Archiv geschrieben werden sollen.
    Bei Replace-Fall: Server-Bestand UND neue Source-Files (sofern der
    Caller den Server-Bestand schon lokal materialisiert hat — sonst nur
    die Source-Files, was dann der frisch-Bau-Fall ist)."""

    is_replace: bool
    """True wenn das Upload das Server-ZIP überschreiben wird (Append).
    False wenn das Server-ZIP neu erstellt wird (Fresh-Bau, kein Konflikt)."""

    safety: AppendSafetyResult
    """Begründung — bei `proceed=False` ist `safety.diagnostic` die Diagnose."""


def plan_append(
    *,
    day_key: str,
    archive_name: str,
    new_source_files: list["FileInfo"],
    local_archive_path: Path | None,
    cfg: "Config",
    verbose: bool = True,
) -> AppendPlan:
    """Plant den Bau für einen Tag mit potenziell bereits existierendem Archiv.

    Wenn weder lokal noch auf dem (ersten) Remote ein Archiv für `day_key`
    existiert → klassischer Fresh-Bau.

    Wenn lokal ein Archiv liegt → Files aus dessen Manifest ergänzen die
    Source-Files (Append-Use-Case innerhalb der Cache-Window). Vorher Lazy-
    Check gegen den Remote-Stand: ist der Server konsistent mit dem lokal
    bekannten Stand? Falls der Server auseinandergelaufen ist (z.B. anderer
    Rechner hat in der Zwischenzeit was geuploaded), wird hart abgebrochen.

    Args:
        day_key: Tag im Format YYYY-MM-DD.
        archive_name: Ziel-Dateiname (z.B. "Originalmedien-2026-05-12.zip").
        new_source_files: frisch eingelesene Files für diesen Tag.
        local_archive_path: Pfad zum lokal vorhandenen Archiv, falls existent;
            sonst None. Manifest-Sidecar wird daneben erwartet.
        cfg: aktuelle Config (für Target-Liste).
        verbose: CLI-Logging.

    Returns:
        AppendPlan; siehe Doku oben.
    """
    from .remote_manifest import first_target

    target = first_target(cfg)

    # Server-Stand erfragen (Lazy-Check Stufe 2)
    if target is None:
        server_state = _empty_server_state(archive_name)
    else:
        server_state = fetch_remote_state(target, archive_name, verbose=verbose)

    # File-Plan zusammenstellen:
    # - Local-Archiv-Inhalt (falls vorhanden) zuerst, dann neue Source-Files.
    # - Duplikate über (filename, size) auflösen — der erste Eintrag gewinnt.
    plan_files: list["FileInfo"] = []
    local_known: set[tuple[str, int]] = set()

    if local_archive_path is not None:
        local_known = _load_local_archive_files(local_archive_path, plan_files, new_source_files)

    # Source-Files nachschieben, falls noch nicht im Plan
    for f in new_source_files:
        key = (str(f.relative_path), f.size)
        if key in local_known:
            continue
        plan_files.append(f)
        local_known.add(key)

    # Coarse Pre-Check (filename-only): jeder Server-Filename muss im Plan
    # vorkommen. SHA-256-Verifikation kommt erst nach dem Build, weil wir
    # erst dann die SHAs der neuen Archiv-Members kennen — siehe
    # `verify_append_safe` in remote_manifest.py.
    plan_filenames = {str(f.relative_path) for f in plan_files}
    server_filenames = {fn for fn, _ in server_state.filenames_with_sha256}
    if not server_filenames.issubset(plan_filenames):
        missing = server_filenames - plan_filenames
        sample = sorted(missing)[:3]
        return AppendPlan(
            proceed=False,
            final_files=[],
            is_replace=server_state.exists,
            safety=AppendSafetyResult(
                safe=False,
                diagnostic=(
                    f"{len(missing)} Datei(en) im Server-Archiv "
                    f"({server_state.archive_name}) würden durch den geplanten "
                    f"Upload VERLOREN gehen. Beispiele: {', '.join(sample)}"
                    f"{' …' if len(missing) > 3 else ''}. "
                    "Manueller Eingriff nötig: `kamera-einleser cache fetch "
                    f"{day_key}` und dann nochmal versuchen."
                ),
            ),
        )

    # Auch die Manifest-Konsistenz (Grösse) prüfen
    safety = _verify_metadata_consistency(server_state)
    if not safety.safe:
        return AppendPlan(
            proceed=False,
            final_files=[],
            is_replace=server_state.exists,
            safety=safety,
        )

    return AppendPlan(
        proceed=True,
        final_files=plan_files,
        is_replace=server_state.exists,
        safety=AppendSafetyResult(
            safe=True,
            diagnostic=(
                "Bereit zum Bau"
                + (
                    f" (Append: {len(plan_files) - len(new_source_files)} alte + "
                    f"{len(new_source_files)} neue Files)"
                    if server_state.exists
                    else f" ({len(new_source_files)} neue Files)"
                )
            ),
        ),
    )


def _empty_server_state(archive_name: str) -> RemoteArchiveState:
    """Bilder eines "kein Server, kein Konflikt"-Standes."""
    return RemoteArchiveState(
        archive_name=archive_name,
        target_name="(kein Target)",
        exists=False,
        size=None,
        manifest_header=None,
        manifest_entries=[],
    )


def _verify_metadata_consistency(
    server_state: RemoteArchiveState,
) -> AppendSafetyResult:
    """Server-Konsistenz: Grösse stimmt mit Manifest-Header, Manifest da."""
    if not server_state.exists:
        return AppendSafetyResult(safe=True, diagnostic="(kein Server-Archiv)")
    if server_state.manifest_header is None:
        return AppendSafetyResult(
            safe=False,
            diagnostic=(
                f"Server-Archiv {server_state.archive_name} existiert, "
                f"aber Manifest-Sidecar fehlt/unleserlich. Append zu blind "
                "wäre unsicher. Manueller Eingriff nötig."
            ),
        )
    if server_state.size != server_state.manifest_header.iso_size:
        return AppendSafetyResult(
            safe=False,
            diagnostic=(
                f"Server-Archiv-Grösse ({server_state.size} Bytes) "
                f"weicht von Manifest-Header ab "
                f"({server_state.manifest_header.iso_size} Bytes). "
                "Server-Stand ist inkonsistent — Append blockiert."
            ),
        )
    return AppendSafetyResult(safe=True, diagnostic="Server konsistent.")


def _load_local_archive_files(
    local_archive_path: Path,
    plan_files: list["FileInfo"],
    _new_source_files: list["FileInfo"],
) -> set[tuple[str, int]]:
    """Liest das lokale Archiv-Manifest und fügt seine Files dem Plan hinzu.

    Members des bestehenden Archivs werden in den Plan eingefügt mit
    `path=<archiv-pfad>` als Marker — der Caller (archive_flow) erkennt
    daran, dass beim Append die Files **aus dem alten Archiv** kopiert
    werden müssen, nicht aus der Source.

    Returns:
        Set `(relative_path, size)` der bereits aus dem Archiv geplanten
        Files. Der Caller nutzt das, um beim Hinzufügen der Source-Files
        Duplikate (gleicher Name + Grösse) zu unterdrücken.
    """
    from datetime import datetime

    from ..services.file_scanner import FileInfo

    known: set[tuple[str, int]] = set()
    manifest_path = local_archive_path.with_name(
        local_archive_path.name + ".manifest.jsonl"
    )
    if not manifest_path.exists():
        return known  # Kein Manifest → behandeln wie "leeres Archiv"

    try:
        for entry in iter_manifest_entries(manifest_path):
            key = (entry.relative_path, entry.size)
            if key in known:
                continue
            known.add(key)
            plan_files.append(
                FileInfo(
                    path=local_archive_path,  # Marker: kommt aus dem Archiv selbst
                    relative_path=Path(entry.relative_path),
                    size=entry.size,
                    timestamp=datetime.fromtimestamp(0),
                    month_key=entry.relative_path[:7],
                    day_key=entry.relative_path[:10],
                )
            )
    except Exception:
        # Manifest unleserlich → wie "leeres Archiv" behandeln, Lazy-Check
        # weiter unten wird das auf Server-Seite nochmal prüfen.
        pass

    return known


def header_for_local_archive(archive_path: Path) -> ManifestHeader | None:
    """Liest den Manifest-Header neben einem lokalen Archiv (Convenience)."""
    from .manifest_io import read_manifest_header

    manifest_path = archive_path.with_name(archive_path.name + ".manifest.jsonl")
    if not manifest_path.exists():
        return None
    try:
        return read_manifest_header(manifest_path)
    except Exception:
        return None
