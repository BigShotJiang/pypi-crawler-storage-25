"""Baut ein komplettes Manifest für eine gemountete ISO (ab 2.0.0).

Workflow pro ISO:

    iso_path  = Pfad zur .iso-Datei (für ISO-SHA-256 + Header-Felder)
    mount_path = Pfad zum hdiutil-Mount der ISO (für Datei-Walk)

    1. ISO-SHA-256 berechnen (Header-Pflichtfeld)
    2. Über `mount_path.rglob("*")` iterieren
    3. Pro nicht-versteckter Datei:
       a. SHA-256 berechnen (für FileEntry + Subset-Check Fall A)
       b. `kurmann_medien_leser.read_metadata()` aufrufen — liefert
          die vollen Metadaten inkl. Best-Guess-Aufnahmedatum mit Provenance
       c. FileEntry komponieren (Identitäts-Felder + MediaFileMetadata)
    4. Header mit aggregierten Werten (file_count, total_bytes)
    5. (header, entries) zurückgeben — der Caller schreibt's via
       `manifest_io.write_manifest`

Fehler-Verhalten: einzelne Datei-Fehler (z.B. exiftool crashed) werden
gesammelt in `BuildResult.failed`, der Build geht für die anderen
weiter. Der Aufrufer entscheidet, ob das Manifest trotzdem geschrieben
werden soll (typisch: ja, wenn die meisten Files OK sind).

**Ab 2.1.0**: Die EXIF-Extraktion + Datums-Logik lebt in
`kurmann-medien-leser`. Wir orchestrieren hier nur den ISO-spezifischen
Teil (Mount-Walk, SHA-256, Header).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from kurmann_medien_leser import (
    ExiftoolError,
    ExiftoolUnavailableError,
    MediaFileMetadata,
    read_metadata,
)
from rich.console import Console

from .. import __version__
from ..utils import compute_sha256
from .manifest_schema import FileEntry, ManifestHeader


@dataclass
class BuildResult:
    """Ergebnis eines Manifest-Builds (Fresh-ZIP, Append-ZIP)."""

    header: ManifestHeader | None = None
    entries: list[FileEntry] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)  # (rel_path, reason)

    @property
    def ok(self) -> bool:
        """True, wenn der Header steht UND mindestens ein Entry erfasst wurde."""
        return self.header is not None and bool(self.entries)


# 3.0.0: `build_manifest_for_iso` ist entfernt — der ISO-Mount-Pfad
# (hdiutil) lebt nicht mehr im Tool. Manifests entstehen ausschliesslich
# beim ZIP-Bau (`build_manifest_for_zip_from_sources`) bzw. Append
# (`build_manifest_for_appended_zip`).


def build_manifest_for_appended_zip(
    zip_path: Path,
    reused_entries: list[FileEntry],
    new_sources: list[tuple[Path, str]],
    *,
    console: Console | None = None,
    verbose: bool = True,
) -> BuildResult:
    """Manifest für ein appended ZIP: alte Entries werden 1:1 übernommen,
    neue Files werden frisch via SHA + medien-leser-Metadaten erfasst.

    Begründung "Reuse alter Entries": beim Append wird das alte ZIP via
    Stream-Copy in das neue ZIP übertragen — ZIP_STORED + Stream-Copy =
    bit-identische Bytes. SHA + Metadata der Members ändern sich also
    nicht. Re-Berechnen wäre Verschwendung von Disk-Reads.

    Der Archive-Hash selbst (`iso_sha256`-Header) wird natürlich neu
    berechnet, weil das neue ZIP eine neue Container-Struktur hat
    (Central-Directory am Ende).

    Args:
        zip_path: Pfad zum FERTIG gebauten neuen ZIP.
        reused_entries: FileEntry-Liste aus dem alten Manifest, die im
            neuen Archiv erhalten bleiben.
        new_sources: `[(source_disk_path, arcname)]` für Files, die NEU
            ins Archiv kommen.
        console: rich-Console für Progress.
        verbose: bei False Per-File-Log unterdrückt.
    """
    cons = console or Console()

    if verbose:
        cons.print(f"[bold]📋 Baue Manifest für {zip_path.name} (Append)[/bold]")

    result = BuildResult()

    if verbose:
        size_gib = zip_path.stat().st_size / (1024**3)
        cons.print(f"   🔑 Berechne ZIP-SHA-256 ({size_gib:.2f} GiB)…")
    try:
        archive_sha = compute_sha256(zip_path)
    except OSError as exc:
        cons.print(f"[red]❌ ZIP-Hash fehlgeschlagen: {exc}[/red]")
        return result

    # 1. Alte Entries 1:1 übernehmen
    if verbose and reused_entries:
        cons.print(
            f"   ♻️  {len(reused_entries)} Entry(s) aus altem Manifest übernommen"
        )
    result.entries.extend(reused_entries)

    # 2. Neue Files frisch erfassen
    total_bytes = sum(e.size for e in reused_entries)
    for idx, (source_path, arcname) in enumerate(new_sources, start=1):
        try:
            sha = compute_sha256(source_path)
        except OSError as exc:
            result.failed.append((arcname, f"SHA-256: {exc}"))
            if verbose:
                cons.print(
                    f"   [red]❌ {arcname}: SHA-256 fehlgeschlagen — {exc}[/red]"
                )
            continue

        try:
            metadata: MediaFileMetadata = read_metadata(source_path)
        except ExiftoolUnavailableError:
            raise
        except ExiftoolError as exc:
            metadata = MediaFileMetadata()
            if verbose:
                cons.print(
                    f"   [yellow]⚠️  {arcname}: exiftool-Warnung — {exc}[/yellow]"
                )
        except Exception as exc:  # pragma: no cover - defensive
            result.failed.append((arcname, f"read_metadata: {exc}"))
            continue

        try:
            file_size = source_path.stat().st_size
        except OSError as exc:
            result.failed.append((arcname, f"stat: {exc}"))
            continue

        entry = FileEntry(
            filename=Path(arcname).name,
            relative_path=arcname,
            size=file_size,
            sha256=sha,
            metadata=metadata,
        )
        result.entries.append(entry)
        total_bytes += file_size

        if verbose:
            recorded = entry.recorded_at or "?"
            cons.print(
                f"   [{idx}/{len(new_sources)}] (neu) {arcname}  "
                f"[dim]({recorded})[/dim]"
            )

    # Entries für deterministisches Manifest alphabetisch nach arcname sortieren
    result.entries.sort(key=lambda e: e.relative_path)

    zip_stat = zip_path.stat()
    result.header = ManifestHeader(
        iso_name=zip_path.name,
        iso_size=zip_stat.st_size,
        iso_sha256=archive_sha,
        file_count=len(result.entries),
        total_bytes=total_bytes,
        created_at=_now_iso8601_local(),
        tool_version=__version__,
    )

    if verbose:
        cons.print(
            f"[green]   ✅ Manifest-Bau abgeschlossen "
            f"(reused={len(reused_entries)}, neu={len(new_sources) - len(result.failed)}, "
            f"fehlgeschlagen={len(result.failed)})[/green]"
        )

    return result


def manifest_path_for_iso(iso_path: Path) -> Path:
    """Konvention: Manifest liegt direkt neben dem Archiv mit `.manifest.jsonl`.

    Heisst weiterhin `manifest_path_for_iso` aus Backwards-Compat-Gründen,
    funktioniert aber für jeden Archiv-Pfad (`.iso` oder `.zip`).
    """
    return iso_path.with_name(iso_path.name + ".manifest.jsonl")


# Alias mit klarem Namen für künftigen Code
manifest_path_for_archive = manifest_path_for_iso


def build_manifest_for_zip_from_sources(
    zip_path: Path,
    sources: list[tuple[Path, str]],
    *,
    console: Console | None = None,
    verbose: bool = True,
) -> BuildResult:
    """Baut Manifest für ein soeben geschriebenes ZIP — SHA aus Source-Files.

    Begründung: bei `ZIP_STORED` (keine Kompression) sind die Bytes im Archive
    bit-identisch zu den Source-Bytes. Wir können SHA-256 + medien-leser-
    Metadaten daher direkt aus den lokalen Source-Pfaden lesen, ohne das
    ZIP aufzumachen oder zu mounten. Der Archive-Hash selbst (`iso_sha256`-
    Feld, historisch so benannt) wird über den ZIP-Pfad berechnet — das ist
    der Audit-Anchor.

    Args:
        zip_path: Pfad zum fertig geschriebenen `.zip`.
        sources: Liste `[(source_path, arcname)]` — `source_path` ist der
            File-Pfad auf der Disk, `arcname` der Name im ZIP (mit `/`-
            Separator). Members in der gleichen Reihenfolge wie beim Build.
        console: rich-Console für Progress (Default: neu).
        verbose: bei False Per-File-Log unterdrückt.

    Returns:
        BuildResult. Bei Erfolg sind `header` und `entries` gefüllt;
        einzelne Datei-Fehler landen in `failed`.
    """
    cons = console or Console()

    if verbose:
        cons.print(f"[bold]📋 Baue Manifest für {zip_path.name}[/bold]")

    result = BuildResult()

    if verbose:
        size_gib = zip_path.stat().st_size / (1024**3)
        cons.print(f"   🔑 Berechne ZIP-SHA-256 ({size_gib:.2f} GiB)…")
    try:
        archive_sha = compute_sha256(zip_path)
    except OSError as exc:
        cons.print(
            f"[red]❌ ZIP-Hash fehlgeschlagen für {zip_path.name}: {exc}[/red]"
        )
        return result

    if verbose:
        cons.print(f"   📂 {len(sources)} Datei(en) zu indexieren")

    total_bytes = 0
    for idx, (source_path, arcname) in enumerate(sources, start=1):
        try:
            sha = compute_sha256(source_path)
        except OSError as exc:
            result.failed.append((arcname, f"SHA-256: {exc}"))
            if verbose:
                cons.print(
                    f"   [red]❌ {arcname}: SHA-256 fehlgeschlagen — {exc}[/red]"
                )
            continue

        try:
            metadata: MediaFileMetadata = read_metadata(source_path)
        except ExiftoolUnavailableError:
            raise
        except ExiftoolError as exc:
            metadata = MediaFileMetadata()
            if verbose:
                cons.print(
                    f"   [yellow]⚠️  {arcname}: exiftool-Warnung — {exc}[/yellow]"
                )
        except Exception as exc:  # pragma: no cover - defensive
            result.failed.append((arcname, f"read_metadata: {exc}"))
            if verbose:
                cons.print(
                    f"   [red]❌ {arcname}: Manifest-Bau fehlgeschlagen — {exc}[/red]"
                )
            continue

        try:
            file_size = source_path.stat().st_size
        except OSError as exc:
            result.failed.append((arcname, f"stat: {exc}"))
            continue

        entry = FileEntry(
            filename=Path(arcname).name,
            relative_path=arcname,
            size=file_size,
            sha256=sha,
            metadata=metadata,
        )
        result.entries.append(entry)
        total_bytes += file_size

        if verbose:
            recorded = entry.recorded_at or "?"
            cons.print(
                f"   [{idx}/{len(sources)}] {arcname}  [dim]({recorded})[/dim]"
            )

    zip_stat = zip_path.stat()
    result.header = ManifestHeader(
        iso_name=zip_path.name,  # historisches Feld; speichert hier den ZIP-Namen
        iso_size=zip_stat.st_size,
        iso_sha256=archive_sha,
        file_count=len(result.entries),
        total_bytes=total_bytes,
        created_at=_now_iso8601_local(),
        tool_version=__version__,
    )

    if verbose:
        cons.print(
            f"[green]   ✅ Manifest-Bau abgeschlossen "
            f"(erfasst={len(result.entries)}, fehlgeschlagen={len(result.failed)})[/green]"
        )

    return result


def _now_iso8601_local() -> str:
    """Aktueller Zeitstempel als ISO-8601 mit lokaler Zeitzone."""
    return (
        datetime.now(tz=timezone.utc)
        .astimezone()
        .isoformat(timespec="seconds")
    )
