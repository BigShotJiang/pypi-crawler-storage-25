"""File-Scanner-Service: Quell-Verzeichnis-Scan, Tag-/Monat-Gruppierung,
Disk-Space-Check, Existing-ISOs-Scan und Source-Cleanup.

Stellt die Datenstruktur `FileInfo` und alle rein-lokalen Filesystem-
Operationen bereit, die im Archive-Flow gebraucht werden. Kein Netzwerk,
kein `hdiutil`.
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from rich.console import Console

from ..utils import should_exclude

console = Console()


def _is_iso_date(name: str) -> bool:
    """Prüft, ob `name` genau das Muster `YYYY-MM-DD` hat (als Datum gültig)."""
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", name):
        return False
    try:
        datetime.strptime(name, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def _pick_day_key(
    file_path: Path,
    stat_result,
    exif_metadata: dict | None,
) -> str:
    """Bestimmt den `day_key` (YYYY-MM-DD) für eine Datei.

    Ab 3.0.0 hardcoded auf `recorded_at` — nutzt das gleiche Best-Guess-
    System wie der Manifest-Builder. Damit ist garantiert, dass beim
    späteren Manifest-Bau dieselbe Datums-Quelle gewählt wird wie bei
    der Gruppierung. Wenn kein EXIF-Datum verfügbar: fällt auf mtime
    zurück (extrem selten, vor allem bei Files ohne Metadaten).
    """
    from kurmann_medien_leser import build_date_sources, pick_recorded_at

    dates = build_date_sources(exif_metadata or {}, stat_result)
    recorded_at, _ = pick_recorded_at(dates)
    if recorded_at:
        # ISO-8601-Datum: erste 10 Zeichen sind YYYY-MM-DD
        return recorded_at[:10]

    return datetime.fromtimestamp(stat_result.st_mtime).strftime("%Y-%m-%d")


@dataclass
class FileInfo:
    """Informationen über eine zu archivierende Datei."""

    path: Path  # Absoluter Pfad
    relative_path: Path  # Pfad relativ zum Quell-Root
    size: int
    timestamp: datetime
    month_key: str  # "YYYY-MM"
    day_key: str  # "YYYY-MM-DD"


# --- Grössen / Disk-Space ----------------------------------------------------


def calculate_directory_size(directory: Path) -> int:
    """Summe aller Dateigrössen unterhalb `directory` (rekursiv).

    Lese-Fehler bei einzelnen Dateien werden still übersprungen, damit der
    Lauf nicht an Meta-Files scheitert.
    """
    total_size = 0
    for item in directory.rglob("*"):
        if item.is_file():
            try:
                total_size += item.stat().st_size
            except OSError:
                pass
    return total_size


def check_disk_space(path: Path, required_bytes: int) -> tuple[bool, int]:
    """Ist genug Platz an `path` (oder nächstem existierendem Ahn) frei?

    Returns:
        (genug_platz, frei_in_bytes).
    """
    try:
        check_path = path
        while not check_path.exists() and check_path.parent != check_path:
            check_path = check_path.parent

        disk_usage = shutil.disk_usage(check_path)
        return disk_usage.free >= required_bytes, disk_usage.free
    except OSError:
        return False, 0


# --- Timestamps + Scan -------------------------------------------------------


def get_newest_file_timestamp(
    directory: Path, excludes: list[str] | None = None
) -> datetime:
    """`mtime` der neusten nicht-excluded Datei unter `directory`.

    Fallback: aktueller Zeitpunkt, wenn nichts gefunden wurde.
    """
    if excludes is None:
        excludes = []

    newest_time = 0.0

    for item in directory.rglob("*"):
        if item.is_file() and not should_exclude(item.name, excludes):
            try:
                mtime = item.stat().st_mtime
                if mtime > newest_time:
                    newest_time = mtime
            except OSError:
                pass

    if newest_time == 0.0:
        return datetime.now()

    return datetime.fromtimestamp(newest_time)


def get_all_files_with_month(
    source_path: Path,
    excludes: list[str] | None = None,
) -> dict[str, list[FileInfo]]:
    """Alle Dateien rekursiv, gruppiert nach `YYYY-MM`."""
    if excludes is None:
        excludes = []

    files_by_month: dict[str, list[FileInfo]] = {}

    for item in source_path.rglob("*"):
        if item.is_file() and not should_exclude(item.name, excludes):
            try:
                stat = item.stat()
                timestamp = datetime.fromtimestamp(stat.st_mtime)
                month_key = timestamp.strftime("%Y-%m")
                day_key = timestamp.strftime("%Y-%m-%d")

                file_info = FileInfo(
                    path=item,
                    relative_path=item.relative_to(source_path),
                    size=stat.st_size,
                    timestamp=timestamp,
                    month_key=month_key,
                    day_key=day_key,
                )

                if month_key not in files_by_month:
                    files_by_month[month_key] = []
                files_by_month[month_key].append(file_info)
            except OSError:
                pass

    for key in files_by_month:
        files_by_month[key].sort(key=lambda f: str(f.relative_path))

    return files_by_month


def get_all_files_with_day(
    source_path: Path,
    excludes: list[str] | None = None,
) -> dict[str, list[FileInfo]]:
    """Alle Dateien rekursiv, gruppiert nach `YYYY-MM-DD` (Aufnahmedatum).

    Ab 3.0.0: hardcoded `recorded_at`-Gruppierung — echtes Aufnahmedatum
    aus EXIF, mit dokumentierter Fallback-Chain. Verhindert die Misch-
    Tag-Archive aus 1.x, wo nach `mtime` gruppiert wurde. Performance:
    ein einziger exiftool-Batch-Aufruf für alle Files vorab, danach
    O(N)-Gruppierung ohne weitere Subprocess-Calls.

    **Sonderfall**: liegt die Quelle unterhalb eines Top-Level-Ordners,
    der exakt auf `YYYY-MM-DD` matcht (z.B. `2026-04-23/…`), wird dieses
    Datum als `day_key` verwendet — Vorrang vor EXIF. So bleiben schon
    vorsortierte Projekte stabil.

    Args:
        source_path: zu scannendes Wurzel-Verzeichnis.
        excludes: Glob-Patterns für zu überspringende Filenames.
    """
    if excludes is None:
        excludes = []

    # Erst alle relevanten File-Paths einsammeln, dann für die `recorded_at`-
    # Strategie EINEN Batch-EXIF-Aufruf machen, danach gruppieren.
    candidates: list[tuple[Path, Path]] = []  # (item, relative_path)
    for item in source_path.rglob("*"):
        if not item.is_file():
            continue
        if should_exclude(item.name, excludes):
            continue
        try:
            relative_path = item.relative_to(source_path)
        except ValueError:
            continue
        # Hidden-Component-Filter: jeder Pfad-Bestandteil, der mit `.` beginnt
        # (z.B. `.fseventsd/`, `.Spotlight-V100/`), filtert das ganze File raus.
        # Schützt davor, dass macOS-Volume-Metadaten in den Archiven landen.
        if any(part.startswith(".") for part in relative_path.parts):
            continue
        candidates.append((item, relative_path))

    # Batch-EXIF nur für Files, deren Tag NICHT schon aus dem Pfad ableitbar
    # ist (Pfad-Spezialfall hat Vorrang).
    exif_batch: dict[Path, dict] = {}
    files_needing_exif = [
        item
        for item, rel in candidates
        if not (
            len(rel.parts) > 1 and _is_iso_date(rel.parts[0])
        )
    ]
    if files_needing_exif:
        from kurmann_medien_leser import extract_metadata_for_files

        exif_batch = extract_metadata_for_files(files_needing_exif)

    files_by_day: dict[str, list[FileInfo]] = {}

    for item, relative_path in candidates:
        try:
            stat = item.stat()
            timestamp = datetime.fromtimestamp(stat.st_mtime)

            # Pfad-Spezialfall: Top-Level-Ordner ist YYYY-MM-DD
            if (
                len(relative_path.parts) > 1
                and _is_iso_date(relative_path.parts[0])
            ):
                day_key = relative_path.parts[0]
                remaining = Path(*relative_path.parts[1:])
                relative_path = remaining
                month_key = day_key[:7]
            else:
                day_key = _pick_day_key(
                    item, stat, exif_batch.get(item)
                )
                month_key = day_key[:7]

            file_info = FileInfo(
                path=item,
                relative_path=relative_path,
                size=stat.st_size,
                timestamp=timestamp,
                month_key=month_key,
                day_key=day_key,
            )

            if day_key not in files_by_day:
                files_by_day[day_key] = []
            files_by_day[day_key].append(file_info)
        except OSError:
            pass

    for key in files_by_day:
        files_by_day[key].sort(key=lambda f: str(f.relative_path))

    return files_by_day


# --- Existing-ISOs-Scan ------------------------------------------------------


def get_existing_isos(working_dir: Path) -> dict[str, list[Path]]:
    """Findet lokal bereits gebaute Archive (`.iso` und `.zip`) im Arbeits-Dir.

    Liefert beide Formate, damit der Archive-Flow Bestands-ISOs aus 2.0.x
    weiterhin als Fall-A-Subset-Quelle nutzen kann und gleichzeitig neue
    ZIP-Archive ab 2.2.0 erkennt.

    Returns:
        `{day_key: [Path, ...]}`. Mehrere Paths pro Tag sind möglich (Mix
        ISO + ZIP, Teil-2 …).
    """
    archives: dict[str, list[Path]] = {}

    if not working_dir.exists():
        return archives

    for item in working_dir.iterdir():
        if item.suffix not in (".iso", ".zip"):
            continue
        if not item.name.startswith("Originalmedien-"):
            continue
        stem = item.stem
        key_part = stem.replace("Originalmedien-", "")
        if "-Teil-" in key_part:
            day_key = key_part.split("-Teil-")[0]
        else:
            day_key = key_part
        archives.setdefault(day_key, []).append(item)

    return archives


# --- Source-Cleanup ----------------------------------------------------------


def cleanup_source_files(source_path: Path, verbose: bool = True) -> bool:
    """Löscht das Quell-Verzeichnis (nach erfolgreichem Archive + Upload).

    Returns:
        True auch wenn das Verzeichnis gar nicht mehr existiert (idempotent).
        False nur bei echten OS-Fehlern.
    """
    if verbose:
        console.print(f"\n[bold]🗑️ Lösche Originaldateien: {source_path}[/bold]")

    try:
        if source_path.exists() and source_path.is_dir():
            shutil.rmtree(source_path)
            if verbose:
                console.print("   [green]✅ Originaldateien gelöscht[/green]")
            return True
        if verbose:
            console.print("   [yellow]⚠️ Verzeichnis existiert nicht mehr[/yellow]")
        return True
    except Exception as e:
        if verbose:
            console.print(f"   [red]❌ Fehler beim Löschen: {e}[/red]")
        return False
