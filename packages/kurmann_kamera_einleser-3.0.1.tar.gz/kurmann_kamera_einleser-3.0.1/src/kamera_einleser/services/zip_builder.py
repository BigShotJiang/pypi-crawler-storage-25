"""ZIP-Builder — baut ZIP-Store-Container für Tages-Archive (2.2.0).

ZIP_STORED (= keine Kompression) hat drei harte Vorteile gegenüber dem
bisherigen `hdiutil makehybrid -udf`-Pfad:

1. **Streaming ohne Staging**: der Builder schreibt direkt aus den Quell-
   Pfaden in die ZIP-Datei — kein temporäres `ditto`-Staging mehr nötig.
   Spart bei einer 100-GB-Quelle eine zweite 100-GB-Kopie auf der Disk.
2. **Plattform-unabhängig**: `zipfile` ist Python-Stdlib. Kein macOS-
   spezifisches `hdiutil` mehr, keine Mount/Unmount-Tänze.
3. **Random-Access**: ZIP-Central-Directory am Ende erlaubt `namelist()`
   ohne Mount in Millisekunden — der Fall-A-Subset-Check ist trivial.

Design-Entscheidungen:

- **Determinismus**: Member werden alphabetisch sortiert geschrieben.
  Gleicher Tag, gleiche Files → byte-identisches ZIP → SHA-256 stabil.
- **ZIP64 implizit**: `allowZip64=True` (Default seit Python 3.4) — Files
  > 4 GB und ZIPs > 4 GB total sind kein Problem.
- **Atomarität**: Build geht in `<target>.tmp.<pid>`, am Ende `os.replace`.
  Crash mittendrin lässt das Ziel-File unangetastet.
- **mtime erhalten**: Source-mtime jedes Files wandert in den ZIP-
  Member-Header (FAT-Format, 2-Sekunden-Granularität).
"""

from __future__ import annotations

import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console

from ..utils import format_size

console = Console()


@dataclass
class ZipMember:
    """Ein File, das in das ZIP geschrieben werden soll.

    Zwei Quell-Modi:

    - **Disk-File** (default): `source_path` ist eine reguläre Datei auf der
      Disk. `source_arcname` bleibt `None`. Wird über `ZipFile.write` ins
      Archiv aufgenommen.

    - **ZIP-to-ZIP-Stream** (für Append): `source_path` ist eine andere
      ZIP-Datei, `source_arcname` ist der Name des Members darin. Beim Bau
      wird der Member-Inhalt streamingfähig in das neue ZIP übertragen
      (ohne RAM-Spike bei Multi-GB-Members; ZIP_STORED → byte-identisch).
    """

    source_path: Path  # Disk-File ODER ZIP-Datei (wenn source_arcname gesetzt)
    arcname: str  # Name im neuen ZIP (mit `/` als Separator)
    size: int  # erwartete Grösse in Bytes (für Logging)
    source_arcname: str | None = None  # gesetzt → source_path ist ein ZIP


def create_zip(
    members: list[ZipMember],
    zip_path: Path,
    *,
    verbose: bool = True,
) -> bool:
    """Baut eine ZIP-Store-Datei aus den angegebenen Members.

    Atomisch: schreibt in `<zip_path>.tmp.<random>`, dann `os.replace`.
    Member-Reihenfolge wird alphabetisch nach `arcname` sortiert, damit der
    Build deterministisch wird (gleicher Input → gleicher SHA-256).

    Args:
        members: Liste der Files, die in das ZIP wandern sollen.
        zip_path: Ziel-Pfad (`.zip`). Existierende Datei wird beim
            erfolgreichen Build atomisch ersetzt.
        verbose: steuert CLI-Ausgabe.

    Returns:
        True bei Erfolg, False bei OS-Fehler (Disk-full, Permission-Denied …).
        Bei False bleibt eine eventuell vorhandene Vorgängerversion am Ziel-
        Pfad unangetastet.
    """
    if verbose:
        total_size = sum(m.size for m in members)
        console.print(
            f"\n[bold]🗜  Erstelle ZIP: {zip_path.name}[/bold]"
            f" ({len(members)} Datei(en), {format_size(total_size)})"
        )

    zip_path.parent.mkdir(parents=True, exist_ok=True)

    # Alphabetisch sortieren für Determinismus
    sorted_members = sorted(members, key=lambda m: m.arcname)

    tmp_fd, tmp_path = tempfile.mkstemp(
        prefix=f".{zip_path.name}.",
        suffix=".tmp",
        dir=str(zip_path.parent),
    )
    os.close(tmp_fd)

    # Source-ZIPs für ZIP-to-ZIP-Member werden EINMAL geöffnet (statt pro
    # Member), damit der Append-Bau bei 27+ Members nicht 27× das gleiche
    # ZIP öffnet. Wichtig: vor dem `os.replace` müssen alle Quell-Handles
    # geschlossen sein (auch wenn source_path == zip_path).
    source_zip_paths = {
        m.source_path for m in sorted_members if m.source_arcname is not None
    }
    source_zips: dict[Path, zipfile.ZipFile] = {}

    try:
        for sp in source_zip_paths:
            source_zips[sp] = zipfile.ZipFile(sp, "r")

        with zipfile.ZipFile(
            tmp_path,
            mode="w",
            compression=zipfile.ZIP_STORED,
            allowZip64=True,
        ) as zf:
            for member in sorted_members:
                if member.source_arcname is not None:
                    # Stream-Copy aus bestehendem ZIP (Append-Use-Case)
                    src_zip = source_zips[member.source_path]
                    with src_zip.open(member.source_arcname) as src:
                        with zf.open(
                            member.arcname, mode="w", force_zip64=True
                        ) as dst:
                            shutil.copyfileobj(src, dst)
                else:
                    # Regular Disk-File (Fresh-Bau)
                    zf.write(member.source_path, arcname=member.arcname)
                if verbose:
                    size_gib = member.size / (1024**3)
                    origin = " (← bestehendes ZIP)" if member.source_arcname else ""
                    console.print(
                        f"   {member.arcname} ({size_gib:.2f} GiB){origin}"
                    )

        # Source-ZIPs schliessen BEVOR os.replace (Quell könnte Ziel sein).
        for z in source_zips.values():
            z.close()
        source_zips.clear()

        os.replace(tmp_path, zip_path)
    except (OSError, zipfile.BadZipFile) as exc:
        if verbose:
            console.print(f"[red]❌ ZIP-Build fehlgeschlagen: {exc}[/red]")
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        # Source-ZIPs schliessen auch im Fehlerfall
        for z in source_zips.values():
            try:
                z.close()
            except Exception:
                pass
        return False

    if verbose:
        zip_size = zip_path.stat().st_size
        console.print(
            f"[green]✅ ZIP erstellt: {zip_path.name} "
            f"({format_size(zip_size)})[/green]"
        )

    return True


def verify_zip(zip_path: Path, *, verbose: bool = True) -> bool:
    """Prüft ein ZIP via `ZipFile.testzip()` — Central-Directory + CRC32 jedes Members.

    Returns:
        True wenn alle Members lesbar sind und ihre CRCs stimmen. False bei
        unlesbarer Zip-Struktur ODER mindestens einem corrupted Member.
    """
    if verbose:
        console.print(f"   Prüfe: {zip_path.name}")

    if not zip_path.exists():
        if verbose:
            console.print(f"[red]   ❌ {zip_path.name} existiert nicht[/red]")
        return False
    if zip_path.stat().st_size == 0:
        if verbose:
            console.print(f"[red]   ❌ {zip_path.name} ist leer[/red]")
        return False

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            bad = zf.testzip()
    except (zipfile.BadZipFile, OSError) as exc:
        if verbose:
            console.print(
                f"[red]   ❌ {zip_path.name} unleserlich: {exc}[/red]"
            )
        return False

    if bad is not None:
        if verbose:
            console.print(
                f"[red]   ❌ {zip_path.name}: corrupted member '{bad}'[/red]"
            )
        return False

    if verbose:
        console.print(f"   [green]✅ {zip_path.name} ist intakt[/green]")
    return True


def verify_archives(archive_files: list[Path], *, verbose: bool = True) -> bool:
    """Prüft eine Liste von ZIP-Archiven auf Integrität.

    Ab 3.0.0 ist `verify_archives` ZIP-only (ISO-Mount-Pfad entfällt mit
    dem ISO-Code-Pfad-Removal). Andere Endungen liefern False.
    """
    if not archive_files:
        return False

    if verbose:
        console.print("\n[bold]🔍 Führe Integritätstest durch...[/bold]")

    for archive in archive_files:
        if archive.suffix.lower() == ".zip":
            if not verify_zip(archive, verbose=verbose):
                return False
        else:
            if verbose:
                console.print(
                    f"[red]   ❌ {archive.name}: unbekanntes Format "
                    "(seit 3.0.0 sind nur noch ZIPs unterstützt)[/red]"
                )
            return False

    if verbose:
        console.print(
            f"   [green]✅ Alle {len(archive_files)} Archive intakt[/green]"
        )
    return True


# --- Naming-Helper für ZIP-Archive (aus iso_builder.py übernommen in 3.0.0) ---


def get_unique_archive_path(
    output_dir: Path,
    day_key: str,
    *,
    extension: str = "zip",
    known_names: set[str] | None = None,
) -> Path:
    """Liefert einen freien Archiv-Pfad für den Tag.

    `-Teil-N` ist ein Notnagel und sollte im normalen Flow nicht mehr
    vorkommen — wenn ein ZIP für den Tag schon existiert, wird der
    `archive_appender` aufgerufen, nicht ein zweites Archiv angelegt.

    Args:
        output_dir: Ziel-Verzeichnis.
        day_key: `YYYY-MM-DD`.
        extension: Datei-Endung ohne Punkt; Default `"zip"`.
        known_names: bereits vergebene Namen (aus Manifest-Cache, inkl.
            Remote-Bestand).
    """
    if known_names is None:
        known_names = set()

    base_name = f"Originalmedien-{day_key}"
    name = f"{base_name}.{extension}"
    path = output_dir / name

    if not path.exists() and name not in known_names:
        return path

    suffix = 2
    while True:
        name = f"{base_name}-Teil-{suffix}.{extension}"
        path = output_dir / name
        if not path.exists() and name not in known_names:
            original_name = f"{base_name}.{extension}"
            if (output_dir / original_name).exists():
                reason = "im Arbeitsverzeichnis"
            elif original_name in known_names:
                reason = "auf einem Ziel"
            else:
                reason = "bereits vergeben"
            console.print(
                f"[yellow]⚠️  Archiv für {day_key} existiert bereits ({reason}). "
                f"Verwende Suffix: {name}[/yellow]"
            )
            return path
        suffix += 1
