"""Cache-Fetch: holt Archive vom Remote zurück in den lokalen Cache (2.3.0).

Use-Cases:

- **Audit an einem alten Tag**: ein vor Wochen archivierter Tag liegt nicht
  mehr im 7-Tage-Cache — du willst aber rein. `cache fetch 2026-04-15`
  holt Archiv + Manifest-Sidecar zurück.
- **Foundation für den Konverter** (`convert iso-to-zip`): die alte ISO muss
  lokal gemountet werden können. Konverter ruft intern `fetch_archive_*`.
- **Out-of-Window-Append** (vorgesehen für 2.3.0 Auto-Fetch): `archive`-Lauf
  trifft auf Files für einen eingefrorenen Tag → automatisch fetchen, dann
  appenden.

Was wird gepullt:

- Archiv-Datei (`*.iso` und/oder `*.zip`) für den angegebenen Tag/Namen
- Manifest-Sidecar (`*.manifest.jsonl`) daneben

Was wird NICHT gepullt:

- `*.uploaded.json`-Marker — die sind maschinenlokal, dürfen nicht von einem
  fremden Marker überschrieben werden. Folge: ein gefetched Archiv ist
  zunächst "nicht repliziert" aus Sicht des Caches und wird vom Auto-Prune
  geschont. Wer das ändern will, muss explizit re-uploaden (z.B. via
  `cache resync`).
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

from ..utils import format_size

if TYPE_CHECKING:
    from ..config import Config

console = Console()

_DAY_KEY_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ARCHIVE_NAME_PATTERN = re.compile(
    r"^Originalmedien-(\d{4}-\d{2}-\d{2})(?:-Teil-\d+)?\.(?:iso|zip)$"
)


@dataclass
class FetchResult:
    """Ergebnis eines `cache fetch`-Laufs."""

    fetched: list[Path] = field(default_factory=list)
    skipped: list[Path] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)
    dry_run: bool = False


def _day_key_from_archive_name(archive_name: str) -> str | None:
    """Extrahiert `YYYY-MM-DD` aus einem Archiv-Dateinamen."""
    m = _ARCHIVE_NAME_PATTERN.match(archive_name)
    return m.group(1) if m else None


def _remote_year_path(target: dict, day_key: str) -> str:
    """`<target_path>/<year>` — konsistent zum Upload-Layout."""
    return f"{target.get('path', '').rstrip('/')}/{day_key[:4]}"


def _list_remote_archives_for_day(
    target: dict,
    day_key: str,
    *,
    verbose: bool,
) -> list[str]:
    """Listet alle Archive-Namen (ohne Sidecars) für einen Tag auf dem Target.

    Returns:
        Sortierte Liste von ZIP-Dateinamen wie
        `Originalmedien-2026-04-15.zip`, `Originalmedien-2026-04-15-Teil-2.zip`.
        Leer wenn nichts gefunden.

    Ab 3.0.0 werden Legacy-ISO-Archive ignoriert. Wer noch ISOs auf dem
    Server hat, muss vor dem Update auf einer 2.3.x-Installation migrieren.
    """
    year_path = _remote_year_path(target, day_key)
    cmd = [
        "rclone",
        "lsf",
        "--files-only",
        f"--include=Originalmedien-{day_key}*.zip",
        year_path,
    ]
    if verbose:
        console.print(f"[dim]   🔍 Liste Archive für {day_key} auf {target.get('name', '?')}…[/dim]")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (subprocess.SubprocessError, OSError) as exc:
        if verbose:
            console.print(f"[yellow]   ⚠️  rclone-lsf fehlgeschlagen: {exc}[/yellow]")
        return []
    if proc.returncode != 0:
        return []
    names = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    # Manifest- und Marker-Sidecars filtern (lsf-Includes matchen prefix-weise)
    archives = [n for n in names if n.endswith(".zip")]
    return sorted(archives)


def _rclone_copy_file(
    remote_path: str,
    local_dest_dir: Path,
    *,
    verbose: bool,
) -> bool:
    """Kopiert eine einzelne Remote-Datei ins lokale Ziel-Verzeichnis."""
    cmd = ["rclone", "copy", remote_path, str(local_dest_dir)]
    if verbose:
        cmd.extend(["--stats", "5s", "--stats-one-line", "-v"])
    try:
        if verbose:
            result = subprocess.run(cmd)
        else:
            result = subprocess.run(cmd, capture_output=True, text=True)
    except (subprocess.SubprocessError, OSError):
        return False
    return result.returncode == 0


def sync_all_manifests_from_target(
    *,
    cfg: "Config | None" = None,
    target_index: int = 0,
    dry_run: bool = False,
    console: Console | None = None,
) -> FetchResult:
    """Pullt **alle** `*.manifest.jsonl`-Sidecars vom Target in den lokalen Cache.

    Use-Case: frisch eingerichteter Rechner, lokaler Manifest-Cache ist leer,
    Server hat aber 100+ Archive. Statt für jedes einzeln `cache fetch` zu
    rufen, holt dieser Befehl alle Sidecars (KBs pro Stück, sub-Sekunde) auf
    einen Schlag.

    Nach dem Sync passiert der Startup-Guard, Pre-Filter funktioniert, und
    der Konverter findet vorhandene Manifest-Info beim Bauen.

    Sidecars werden **flat** ins Working-Dir gelegt (analog zum 2.x-Layout —
    keine Jahres-Unterverzeichnisse lokal), damit `manifest_cache._iter_manifest_paths`
    sie findet.
    """
    from ..config import get_config

    cons = console or globals()["console"]
    config = cfg if cfg is not None else get_config()
    result = FetchResult(dry_run=dry_run)

    targets = config.get_rclone_targets()
    if not targets:
        cons.print("[red]❌ Kein rclone-Target konfiguriert[/red]")
        return result
    if target_index >= len(targets):
        cons.print(
            f"[red]❌ Target-Index {target_index} out-of-range "
            f"({len(targets)} Targets konfiguriert)[/red]"
        )
        return result
    target = targets[target_index]
    target_path = target.get("path", "").rstrip("/")

    primary = config.get_working_directory()
    if not primary:
        cons.print("[red]❌ Kein primary working_directory konfiguriert[/red]")
        return result
    local_dest = Path(primary).expanduser()
    local_dest.mkdir(parents=True, exist_ok=True)

    cons.print(
        f"\n[bold]📥 Manifest-Sync von {target.get('name', '?')}[/bold]"
    )

    # Schritt 1: alle Manifest-Pfade rekursiv listen
    cons.print("[dim]   🔍 Liste Manifest-Sidecars auf dem Target…[/dim]")
    cmd_list = [
        "rclone",
        "lsf",
        target_path,
        "--recursive",
        "--include",
        "*.manifest.jsonl",
        "--files-only",
    ]
    try:
        proc = subprocess.run(
            cmd_list, capture_output=True, text=True, timeout=120
        )
    except (subprocess.SubprocessError, OSError) as exc:
        cons.print(f"[red]   ❌ rclone-lsf fehlgeschlagen: {exc}[/red]")
        return result

    if proc.returncode != 0:
        cons.print(
            f"[red]   ❌ rclone-lsf returncode={proc.returncode}: "
            f"{(proc.stderr or '').strip()}[/red]"
        )
        return result

    manifest_paths = [
        line.strip() for line in proc.stdout.splitlines() if line.strip()
    ]
    cons.print(
        f"   {len(manifest_paths)} Manifest-Sidecar(s) auf dem Server gefunden"
    )

    if not manifest_paths:
        cons.print(
            "[dim]   (Server hat keine Manifests — leerer Bestand oder "
            "ausschliesslich pre-2.0.0-Archive)[/dim]"
        )
        return result

    # Schritt 2: per Manifest flat-pull (rclone copy <single-file> <dir> macht
    # automatisch flat, ohne Year-Unterordner)
    for idx, rel_path in enumerate(manifest_paths, start=1):
        filename = rel_path.rsplit("/", 1)[-1]
        local_path = local_dest / filename

        if local_path.exists():
            result.skipped.append(local_path)
            cons.print(
                f"   [dim]⏭  [{idx}/{len(manifest_paths)}] {filename} (lokal)[/dim]"
            )
            continue

        if dry_run:
            cons.print(
                f"   [dim]📋 [{idx}/{len(manifest_paths)}] (dry-run) "
                f"würde ziehen: {filename}[/dim]"
            )
            result.fetched.append(local_path)
            continue

        full_remote = f"{target_path}/{rel_path}"
        cmd_copy = ["rclone", "copy", full_remote, str(local_dest)]
        try:
            proc = subprocess.run(
                cmd_copy, capture_output=True, text=True, timeout=60
            )
        except (subprocess.SubprocessError, OSError) as exc:
            result.failed.append((filename, str(exc)))
            cons.print(
                f"   [red]❌ [{idx}/{len(manifest_paths)}] {filename}: {exc}[/red]"
            )
            continue

        if proc.returncode != 0:
            err = (proc.stderr or "").strip() or f"rc={proc.returncode}"
            result.failed.append((filename, err))
            cons.print(
                f"   [red]❌ [{idx}/{len(manifest_paths)}] {filename}: {err}[/red]"
            )
            continue

        result.fetched.append(local_path)
        cons.print(
            f"   [green]✓ [{idx}/{len(manifest_paths)}] {filename}[/green]"
        )

    cons.print(
        f"\n[bold]✓ Manifest-Sync {'geplant' if dry_run else 'abgeschlossen'}[/bold] "
        f"(geholt={len(result.fetched)}, "
        f"schon_da={len(result.skipped)}, "
        f"fehlgeschlagen={len(result.failed)})"
    )
    return result


def fetch_archive(
    archive_name: str,
    *,
    cfg: "Config | None" = None,
    target_index: int = 0,
    dry_run: bool = False,
    console: Console | None = None,
) -> FetchResult:
    """Pullt **ein einzelnes** Archiv (Name explizit) + Manifest-Sidecar."""
    from ..config import get_config

    cons = console or globals()["console"]
    config = cfg if cfg is not None else get_config()
    result = FetchResult(dry_run=dry_run)

    targets = config.get_rclone_targets()
    if not targets:
        cons.print("[red]❌ Kein rclone-Target konfiguriert[/red]")
        return result
    if target_index >= len(targets):
        cons.print(
            f"[red]❌ Target-Index {target_index} out-of-range "
            f"({len(targets)} Targets konfiguriert)[/red]"
        )
        return result
    target = targets[target_index]

    day_key = _day_key_from_archive_name(archive_name)
    if day_key is None:
        cons.print(
            f"[red]❌ Ungültiger Archiv-Name '{archive_name}' — "
            f"erwartet Originalmedien-YYYY-MM-DD[-Teil-N].(iso|zip)[/red]"
        )
        result.failed.append((archive_name, "ungültiger Name"))
        return result

    primary = config.get_working_directory()
    if not primary:
        cons.print("[red]❌ Kein primary working_directory konfiguriert[/red]")
        return result
    local_dest = Path(primary).expanduser()
    local_dest.mkdir(parents=True, exist_ok=True)

    year_path = _remote_year_path(target, day_key)
    archive_remote_path = f"{year_path}/{archive_name}"
    manifest_remote_path = f"{archive_remote_path}.manifest.jsonl"
    archive_local_path = local_dest / archive_name

    cons.print(
        f"\n[bold]📥 Fetche {archive_name} von {target.get('name', '?')}[/bold]"
    )

    if archive_local_path.exists():
        size = archive_local_path.stat().st_size
        cons.print(
            f"[dim]   ⏭  Bereits lokal: {archive_name} ({format_size(size)})[/dim]"
        )
        result.skipped.append(archive_local_path)
    elif dry_run:
        cons.print(f"[dim]   📋 (dry-run) würde Archiv ziehen: {archive_remote_path}[/dim]")
        result.fetched.append(archive_local_path)
    else:
        cons.print(f"   Archiv: {archive_remote_path}")
        if not _rclone_copy_file(archive_remote_path, local_dest, verbose=True):
            cons.print("[red]   ❌ Archiv-Pull fehlgeschlagen[/red]")
            result.failed.append((archive_name, "rclone copy archive failed"))
            return result
        result.fetched.append(archive_local_path)

    # Manifest-Sidecar daneben. Ab 3.0.0 sollten alle Archive auf dem
    # Server ZIPs mit Sidecar sein (Legacy-ISO-Migration vorausgesetzt).
    manifest_local_path = local_dest / f"{archive_name}.manifest.jsonl"
    if manifest_local_path.exists():
        cons.print("[dim]   ⏭  Manifest bereits lokal[/dim]")
    elif dry_run:
        cons.print("[dim]   📋 (dry-run) würde Manifest ziehen[/dim]")
    elif not _rclone_copy_file(manifest_remote_path, local_dest, verbose=False):
        cons.print(
            "[yellow]   ⚠️  Manifest-Pull fehlgeschlagen "
            f"({manifest_remote_path})[/yellow]"
        )
    else:
        cons.print(f"   📋 Manifest gepullt: {manifest_remote_path}")

    return result


def fetch_archives_for_day(
    day_key: str,
    *,
    cfg: "Config | None" = None,
    target_index: int = 0,
    dry_run: bool = False,
    console: Console | None = None,
) -> FetchResult:
    """Pullt **alle Archive eines Tages** (Mix `.iso` + `.zip` + `-Teil-N`)
    vom konfigurierten Target ins lokale Working-Dir.
    """
    from ..config import get_config

    cons = console or globals()["console"]
    config = cfg if cfg is not None else get_config()
    result = FetchResult(dry_run=dry_run)

    if not _DAY_KEY_PATTERN.match(day_key):
        cons.print(f"[red]❌ Ungültiger day_key '{day_key}' — erwartet YYYY-MM-DD[/red]")
        return result

    targets = config.get_rclone_targets()
    if not targets:
        cons.print("[red]❌ Kein rclone-Target konfiguriert[/red]")
        return result
    if target_index >= len(targets):
        cons.print(
            f"[red]❌ Target-Index {target_index} out-of-range "
            f"({len(targets)} Targets konfiguriert)[/red]"
        )
        return result
    target = targets[target_index]

    cons.print(
        f"\n[bold]📥 Cache-Fetch für Tag {day_key} "
        f"von {target.get('name', '?')}[/bold]"
    )

    archive_names = _list_remote_archives_for_day(target, day_key, verbose=True)
    if not archive_names:
        cons.print(
            f"[yellow]   ⚠️  Kein Archiv für {day_key} auf dem Target gefunden[/yellow]"
        )
        return result

    cons.print(f"   {len(archive_names)} Archiv(e) gefunden: {', '.join(archive_names)}")

    for archive_name in archive_names:
        sub_result = fetch_archive(
            archive_name,
            cfg=config,
            target_index=target_index,
            dry_run=dry_run,
            console=cons,
        )
        result.fetched.extend(sub_result.fetched)
        result.skipped.extend(sub_result.skipped)
        result.failed.extend(sub_result.failed)

    cons.print(
        f"\n[bold]✓ Cache-Fetch {'geplant' if dry_run else 'abgeschlossen'}[/bold] "
        f"(geholt={len(result.fetched)}, "
        f"schon_da={len(result.skipped)}, "
        f"fehlgeschlagen={len(result.failed)})"
    )
    return result
