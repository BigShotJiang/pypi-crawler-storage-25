"""Manifest-Schema für ISO-Sidecars (`*.iso.manifest.jsonl`).

Hier wohnt **nur noch** das ISO-Manifest-spezifische Schema:
- `ManifestHeader` — erste Zeile, Header der ganzen ISO
- `FileEntry` — eine Zeile pro Datei in der ISO, mit Identitäts-Feldern
  (filename/relative_path/size/sha256) und einer eingebetteten
  `MediaFileMetadata` aus `kurmann-medien-leser`

Die generischen Metadaten-Schemas (`DateSources`, `VideoInfo`, `AudioInfo`,
`CameraInfo`, `GpsInfo`, `ProductionInfo`) leben ab 2.1.0 in
`kurmann-medien-leser`, weil sie dort auch von `schnittprojekt-leser`
konsumiert werden. Für Backwards-Compat re-exportieren wir sie hier
weiter.

**JSONL-Format** auf Disk: erste Zeile Header, dann eine File-Entry-
Zeile pro Datei. Das `to_dict()` von `FileEntry` flacht die
`MediaFileMetadata`-Felder direkt auf die Top-Ebene aus (Backwards-
Compat mit 2.0.0-Manifests, die das schon so geschrieben haben).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

# Re-Exports aus dem neuen medien-leser-Paket — Backwards-Compat für
# Aufrufer, die diese Symbole bisher aus `manifest_schema` importierten.
from kurmann_medien_leser import (
    SOURCE_APP_BLACKMAGIC_CAM,
    SOURCE_APP_FINAL_CUT_CAMERA,
    SOURCE_APP_IPHONE_CAMERA,
    SOURCE_FILE_BIRTHTIME,
    SOURCE_FILE_MTIME,
    SUPPORTED_SOURCE_APPS,
    AudioInfo,
    CameraInfo,
    DateSources,
    GpsInfo,
    MediaFileMetadata,
    ProductionInfo,
    VideoInfo,
)

__all__ = [
    # Manifest-spezifisch (bleibt hier)
    "MANIFEST_FORMAT_VERSION",
    "ManifestHeader",
    "FileEntry",
    # Re-Exports aus medien-leser (Backwards-Compat)
    "DateSources",
    "VideoInfo",
    "AudioInfo",
    "CameraInfo",
    "GpsInfo",
    "ProductionInfo",
    "MediaFileMetadata",
    "SOURCE_FILE_MTIME",
    "SOURCE_FILE_BIRTHTIME",
    "SOURCE_APP_BLACKMAGIC_CAM",
    "SOURCE_APP_IPHONE_CAMERA",
    "SOURCE_APP_FINAL_CUT_CAMERA",
    "SUPPORTED_SOURCE_APPS",
]

# Format-Versionierung im Manifest-Header. Wenn wir das Schema später
# erweitern oder umbauen, kommt hier eine 2 dazu — Migrationen werden
# einfacher, weil der Reader die Version kennt.
MANIFEST_FORMAT_VERSION = 1


@dataclass
class ManifestHeader:
    """Erste Zeile eines Manifests. Beschreibt die ISO als Ganzes."""

    iso_name: str
    iso_size: int
    iso_sha256: str
    file_count: int
    total_bytes: int
    created_at: str  # ISO-8601 mit TZ
    tool_version: str
    manifest_version: int = MANIFEST_FORMAT_VERSION
    type: Literal["header"] = "header"

    def to_dict(self) -> dict:
        return {
            "_type": self.type,
            "manifest_version": self.manifest_version,
            "iso_name": self.iso_name,
            "iso_size": self.iso_size,
            "iso_sha256": self.iso_sha256,
            "file_count": self.file_count,
            "total_bytes": self.total_bytes,
            "created_at": self.created_at,
            "tool_version": self.tool_version,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ManifestHeader":
        return cls(
            iso_name=data["iso_name"],
            iso_size=data["iso_size"],
            iso_sha256=data["iso_sha256"],
            file_count=data["file_count"],
            total_bytes=data["total_bytes"],
            created_at=data["created_at"],
            tool_version=data.get("tool_version", "unknown"),
            manifest_version=data.get("manifest_version", 1),
        )


@dataclass
class FileEntry:
    """Eine Datei innerhalb der ISO.

    Identitäts-Felder (`filename`, `relative_path`, `size`, `sha256`) sind
    Manifest-spezifisch. Alle Metadaten kommen aus `MediaFileMetadata`
    (medien-leser): Aufnahmedatum mit Provenance, source_app, Video/Audio/
    Camera/GPS/Production-Sub-Schemas.

    Auf Disk wird die `MediaFileMetadata` flach auf die Top-Ebene
    ausgeflacht (recorded_at, recorded_at_source, source_app, dates,
    video, audio, camera, gps, production sind alle Top-Level-Felder
    der JSON-Zeile). Backwards-Compat mit 2.0.0-Manifests, die das
    schon so geschrieben haben.
    """

    filename: str
    relative_path: str
    size: int
    sha256: str

    # Reichhaltige Metadaten aus medien-leser. Default = leere
    # MediaFileMetadata (für Files ohne EXIF, z.B. Notes/Logs).
    metadata: MediaFileMetadata = field(default_factory=MediaFileMetadata)

    def to_dict(self) -> dict:
        """Serialisiert in flaches dict (kompatibel zu 2.0.0-Manifests).

        Identitäts-Felder kommen zuerst, dann die `MediaFileMetadata`-
        Felder ausgeflacht (recorded_at, source_app, dates, video, etc.).
        """
        d: dict = {
            "filename": self.filename,
            "relative_path": self.relative_path,
            "size": self.size,
            "sha256": self.sha256,
        }
        # MediaFileMetadata ausflachen — schon to_dict() lässt leere
        # Sub-Blöcke weg, das passt zum Backwards-Compat-Format.
        d.update(self.metadata.to_dict())
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "FileEntry":
        # MediaFileMetadata aus den flach-ausgeflachten Feldern
        # rekonstruieren — die nicht-Manifest-Felder sind genau die
        # MediaFileMetadata-Felder.
        metadata_keys = {
            "recorded_at",
            "recorded_at_source",
            "source_app",
            "dates",
            "video",
            "audio",
            "camera",
            "gps",
            "production",
        }
        metadata_dict = {k: v for k, v in data.items() if k in metadata_keys}
        return cls(
            filename=data["filename"],
            relative_path=data["relative_path"],
            size=data["size"],
            sha256=data["sha256"],
            metadata=MediaFileMetadata.from_dict(metadata_dict),
        )

    # -------------------------------------------------------------------
    # Convenience-Properties für Backwards-Compat mit Code, der direkt
    # `entry.recorded_at` / `entry.source_app` / `entry.video.codec` etc.
    # zugreift. Delegiert auf `self.metadata`.
    # -------------------------------------------------------------------

    @property
    def recorded_at(self) -> str | None:
        return self.metadata.recorded_at

    @property
    def recorded_at_source(self) -> str | None:
        return self.metadata.recorded_at_source

    @property
    def source_app(self) -> str | None:
        return self.metadata.source_app

    @property
    def dates(self) -> DateSources:
        return self.metadata.dates

    @property
    def video(self) -> VideoInfo:
        return self.metadata.video

    @property
    def audio(self) -> AudioInfo:
        return self.metadata.audio

    @property
    def camera(self) -> CameraInfo:
        return self.metadata.camera

    @property
    def gps(self) -> GpsInfo | None:
        return self.metadata.gps

    @property
    def production(self) -> ProductionInfo:
        return self.metadata.production
