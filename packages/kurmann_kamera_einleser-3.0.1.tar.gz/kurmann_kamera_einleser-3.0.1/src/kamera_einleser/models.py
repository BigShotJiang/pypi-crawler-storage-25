"""Datenmodelle: Request/Result, RuntimeOptions, SourceRefs, Events.

Zentrale Stelle für sämtliche Public-API-Datenstrukturen. Folgt dem
kurmann-python-api Skill: Request und RuntimeOptions sind strikt getrennt.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Union


class SourceKind(str, Enum):
    LOCAL = "local"
    RCLONE = "rclone"


@dataclass(frozen=True)
class LocalSource:
    """Quelle auf dem lokalen Dateisystem (SD-Karte, SSD, iPhone-Mount etc.)."""

    path: Path
    kind: SourceKind = SourceKind.LOCAL

    def describe(self) -> str:
        return str(self.path)


@dataclass(frozen=True)
class RcloneSource:
    """Quelle auf einem rclone-Remote (z.B. Synology NAS via SMB/SFTP).

    Beispiel: `RcloneSource(remote="synology", path="/volume1/Fotos/Eingang")`
    entspricht dem rclone-Pfad `synology:/volume1/Fotos/Eingang`.
    """

    remote: str
    path: str
    kind: SourceKind = SourceKind.RCLONE

    def describe(self) -> str:
        return f"{self.remote}:{self.path}"

    @property
    def rclone_path(self) -> str:
        return f"{self.remote}:{self.path}"


SourceRef = Union[LocalSource, RcloneSource]


def parse_source_spec(spec: str) -> SourceRef:
    """Parst einen Config-String in eine `SourceRef`.

    Regeln:
    - Beginnt mit `/`, `~` oder einem Laufwerksbuchstaben → `LocalSource`.
    - Enthält `:` an Position ≥ 1 (und kein Windows-Drive-Letter) → `RcloneSource`,
      Form `remote:/path` oder `remote:path`.

    Beispiele:
    - `/Volumes/Card` → LocalSource
    - `synology:/volume1/Fotos/Eingang` → RcloneSource("synology", "/volume1/Fotos/Eingang")
    - `mega:Backup` → RcloneSource("mega", "Backup")
    """
    spec = spec.strip()
    if not spec:
        raise ValueError("Leere Quell-Spezifikation")

    # Windows-Drive-Letter (C:/...) als lokal erkennen
    if len(spec) >= 2 and spec[1] == ":" and spec[0].isalpha() and (
        len(spec) == 2 or spec[2] in ("/", "\\")
    ):
        return LocalSource(path=Path(spec).expanduser())

    if spec.startswith(("/", "~", "./", "../")):
        return LocalSource(path=Path(spec).expanduser())

    if ":" in spec:
        remote, _, remote_path = spec.partition(":")
        if not remote:
            raise ValueError(f"Ungültige rclone-Quelle: {spec!r}")
        return RcloneSource(remote=remote, path=remote_path)

    # Fallback: behandle als lokalen relativen Pfad
    return LocalSource(path=Path(spec).expanduser())


@dataclass
class RuntimeOptions:
    """Prozess-/Aufruf-spezifische Laufzeitoptionen.

    Bewusst getrennt von fachlichen Requests — was sich zur Laufzeit ändert
    (Ausgabeverhalten, Dry-Run, Parallelität) gehört hier rein.
    """

    verbose: bool = False
    quiet: bool = False
    dry_run: bool = False

    def __post_init__(self) -> None:
        if self.verbose and self.quiet:
            raise ValueError("verbose und quiet schliessen sich gegenseitig aus")

    @property
    def is_verbose(self) -> bool:
        return self.verbose and not self.quiet

    @property
    def is_quiet(self) -> bool:
        return self.quiet


@dataclass
class ArchiveEvents:
    """Optionale Event-Callbacks, die während der Archivierung gefeuert werden.

    Alle Felder sind optional. CLI-Aufrufer hängt typischerweise Rich-Progress-
    Handler an; programmatische Nutzer können eigene Hooks anbinden.
    """

    on_source_started: Callable[[SourceRef], None] | None = None
    on_file_staged: Callable[[Path], None] | None = None
    on_iso_built: Callable[[Path], None] | None = None
    on_collision_detected: Callable[[Path, str], None] | None = None
    on_upload_progress: Callable[[str, float], None] | None = None
    on_source_finished: Callable[[SourceRef, bool], None] | None = None


@dataclass
class ArchiveRequest:
    """Fachlicher Request für eine Archivierungs-Operation."""

    sources: list[SourceRef] = field(default_factory=list)
    working_dir: Path | None = None
    no_upload: bool = False
    no_cleanup: bool = False
    delete_source: bool = False
    full_pull: bool = False
    """Wenn True, rclone-Pull übergeht den Manifest-Pre-Filter und zieht alle
    Dateien der Remote-Quelle erneut. Default False = nur Unbekannte pullen."""


@dataclass
class ArchiveResult:
    """Ergebnis einer Archivierungs-Operation."""

    success: bool
    iso_files: list[Path] = field(default_factory=list)
    uploaded_targets: list[str] = field(default_factory=list)
    failed_targets: list[str] = field(default_factory=list)
    processed_sources: list[SourceRef] = field(default_factory=list)
    failed_sources: list[SourceRef] = field(default_factory=list)
    message: str | None = None
