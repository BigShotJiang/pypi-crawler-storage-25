"""
VaultLayer — CLI Coverage Tests
Maximises coverage for cli/main.py, cli/run.py, cli/delete.py,
cli/ps.py, cli/feedback.py, cli/sync.py, cli/estimate.py,
cli/crash_reporter.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import tempfile
import asyncio
from pathlib import Path
from unittest.mock import patch, AsyncMock, MagicMock, mock_open

import pytest
from click.testing import CliRunner


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_resp(json_data: dict, status_code: int = 200):
    """Build a minimal httpx-like response mock."""
    r = MagicMock()
    r.status_code = status_code
    r.json.return_value = json_data
    r.raise_for_status = MagicMock()
    if status_code >= 400:
        import httpx
        r.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=r
        )
    return r


# ---------------------------------------------------------------------------
# crash_reporter tests
# ---------------------------------------------------------------------------

class TestCrashReporter:
    def test_scrub_aws_key(self):
        from cli.crash_reporter import scrub
        text = "key=AKIAIOSFODNN7EXAMPLE extra"
        result = scrub(text)
        assert "AKIAIOSFODNN7EXAMPLE" not in result

    def test_scrub_vl_token(self):
        from cli.crash_reporter import scrub
        result = scrub("token vl_live_abc123def456")
        assert "vl_live_" not in result

    def test_scrub_email(self):
        from cli.crash_reporter import scrub
        result = scrub("contact user@example.com now")
        assert "user@example.com" not in result

    def test_scrub_empty(self):
        from cli.crash_reporter import scrub
        assert scrub("") == ""

    def test_error_fingerprint_stable(self):
        from cli.crash_reporter import error_fingerprint
        fp1 = error_fingerprint("ValueError", "bad input", "train.py")
        fp2 = error_fingerprint("ValueError", "bad input", "train.py")
        assert fp1 == fp2
        assert fp1.startswith("fp_")

    def test_error_fingerprint_differs(self):
        from cli.crash_reporter import error_fingerprint
        fp1 = error_fingerprint("ValueError", "bad input", "train.py")
        fp2 = error_fingerprint("RuntimeError", "bad input", "train.py")
        assert fp1 != fp2

    def test_save_and_load_crash_report(self):
        from cli.crash_reporter import save_crash_report, load_crash_report
        exc = ValueError("test error")
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("cli.crash_reporter._crash_reports_dir", return_value=Path(tmpdir)):
                report_id = save_crash_report(
                    exc, command=["python", "train.py"],
                    job_id="job-001", gpu_type="H100_80GB_SXM", provider="aws"
                )
                assert report_id.startswith("cr_")
                report = load_crash_report(report_id)
                assert report is not None
                assert report["error_type"] == "ValueError"
                assert report["job_id"] == "job-001"
                assert report["submitted"] is False

    def test_load_nonexistent_report(self):
        from cli.crash_reporter import load_crash_report
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("cli.crash_reporter._crash_reports_dir", return_value=Path(tmpdir)):
                assert load_crash_report("cr_doesnotexist") is None

    def test_mark_submitted(self):
        from cli.crash_reporter import save_crash_report, load_crash_report, mark_submitted
        exc = RuntimeError("oops")
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("cli.crash_reporter._crash_reports_dir", return_value=Path(tmpdir)):
                rid = save_crash_report(exc, command=["python", "train.py"])
                mark_submitted(rid)
                report = load_crash_report(rid)
                assert report["submitted"] is True

    def test_mark_submitted_nonexistent(self):
        from cli.crash_reporter import mark_submitted
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("cli.crash_reporter._crash_reports_dir", return_value=Path(tmpdir)):
                # Should not raise
                mark_submitted("cr_doesnotexist")

    def test_save_crash_report_scrubs_command(self):
        from cli.crash_reporter import save_crash_report, load_crash_report
        exc = RuntimeError("boom")
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("cli.crash_reporter._crash_reports_dir", return_value=Path(tmpdir)):
                rid = save_crash_report(exc, command=["python", "train.py", "vl_live_abc123def"])
                report = load_crash_report(rid)
                # scrubbed command should not contain the raw token
                assert "vl_live_abc123def" not in " ".join(report["command"])


# ---------------------------------------------------------------------------
# cli/main.py — init command
# ---------------------------------------------------------------------------

class TestInitCommand:
    def test_init_success(self):
        from cli.main import cli
        runner = CliRunner()
        resp = _make_resp({"valid": True, "email": "test@x.com", "balance_credits": 500})
        with runner.isolated_filesystem():
            with patch("httpx.post", return_value=resp), \
                 patch("cli.main._api_url", return_value="http://test"), \
                 patch("cli.checkpoint_template.CHECKPOINT_HELPER_TEMPLATE", "# template"):
                result = runner.invoke(cli, ["init", "--token", "vl_live_testtoken123"])
        assert result.exit_code == 0
        assert "Authenticated" in result.output

    def test_init_invalid_token_format(self):
        from cli.main import cli
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(cli, ["init", "--token", "invalid_token"])
        assert result.exit_code != 0
        assert "Invalid token format" in result.output

    def test_init_api_error(self):
        from cli.main import cli
        import httpx
        runner = CliRunner()
        with runner.isolated_filesystem():
            with patch("httpx.post", side_effect=httpx.HTTPError("connection refused")), \
                 patch("cli.main._api_url", return_value="http://test"):
                result = runner.invoke(cli, ["init", "--token", "vl_live_testtoken123"])
        assert result.exit_code != 0
        assert "Could not reach" in result.output

    def test_init_token_invalid_response(self):
        from cli.main import cli
        runner = CliRunner()
        resp = _make_resp({"valid": False, "message": "Token expired"})
        with runner.isolated_filesystem():
            with patch("httpx.post", return_value=resp), \
                 patch("cli.main._api_url", return_value="http://test"):
                result = runner.invoke(cli, ["init", "--token", "vl_live_testtoken123"])
        assert result.exit_code != 0
        assert "Token invalid" in result.output

    def test_init_stores_token_file(self):
        from cli.main import cli
        runner = CliRunner()
        resp = _make_resp({"valid": True, "email": "u@e.com", "balance_credits": 0})
        with runner.isolated_filesystem():
            with patch("httpx.post", return_value=resp), \
                 patch("cli.main._api_url", return_value="http://test"), \
                 patch("cli.checkpoint_template.CHECKPOINT_HELPER_TEMPLATE", "# t"):
                result = runner.invoke(cli, ["init", "--token", "vl_test_stored"])
        # Should succeed
        assert result.exit_code == 0

    def test_init_uses_stored_token(self):
        from cli.main import cli
        runner = CliRunner()
        resp = _make_resp({"valid": True, "email": "u@e.com", "balance_credits": 100})
        with runner.isolated_filesystem():
            token_dir = Path.home() / ".vaultlayer"
            token_dir.mkdir(exist_ok=True)
            token_file = token_dir / "token"
            token_file.write_text("vl_live_storedtoken\n")
            try:
                with patch("httpx.post", return_value=resp), \
                     patch("cli.main._api_url", return_value="http://test"), \
                     patch("cli.checkpoint_template.CHECKPOINT_HELPER_TEMPLATE", "# t"):
                    result = runner.invoke(cli, ["init"])
                assert result.exit_code == 0, f"init failed: {result.output}"
            finally:
                token_file.unlink(missing_ok=True)

    def test_status_command(self):
        from cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["status"])
        assert result.exit_code == 0
        assert "Fetching" in result.output

    def test_version_option(self):
        from cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "vaultlayer" in result.output.lower()

    def test_regions_list_all(self):
        from cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["regions", "list-all"])
        assert result.exit_code == 0
        assert "us-east-1" in result.output

    def test_regions_current_no_config(self):
        from cli.main import cli
        runner = CliRunner()
        with patch("shared.config.load_config", side_effect=Exception("no config")), \
             patch.dict(os.environ, {"AWS_DEFAULT_REGION": "us-west-2"}, clear=False):
            result = runner.invoke(cli, ["regions", "current"])
        assert result.exit_code == 0
        assert "us-west-2" in result.output

    def test_regions_current_with_config(self):
        from cli.main import cli
        runner = CliRunner()
        mock_cfg = MagicMock()
        mock_cfg.aws.region = "eu-central-1"
        with patch("shared.config.load_config", return_value=mock_cfg):
            result = runner.invoke(cli, ["regions", "current"])
        assert result.exit_code == 0
        assert "eu-central-1" in result.output

    def test_gpu_hourly_rate_known(self):
        from cli.main import _gpu_hourly_rate, _GPU_RATES
        rate = _gpu_hourly_rate("H100_80GB_SXM")
        assert rate == _GPU_RATES["H100_80GB_SXM"]
        assert rate > 0

    def test_gpu_hourly_rate_unknown(self):
        from cli.main import _gpu_hourly_rate
        rate = _gpu_hourly_rate("UNKNOWN_GPU")
        assert rate == 1.50

    def test_load_token_from_env(self):
        from cli.main import _load_token
        with patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_envtoken"}):
            token = _load_token()
        assert token == "vl_test_envtoken"

    def test_load_token_not_found(self):
        from cli.main import _load_token
        runner = CliRunner()
        with runner.isolated_filesystem():
            with patch.dict(os.environ, {}, clear=True):
                with patch("pathlib.Path.exists", return_value=False):
                    with pytest.raises(SystemExit):
                        _load_token()


# ---------------------------------------------------------------------------
# cli/main.py — run command (lightweight path)
# ---------------------------------------------------------------------------

class TestRunCommand:
    def test_run_aborted_by_user(self):
        """User says 'n' at confirmation prompt — should not start."""
        from cli.main import cli
        runner = CliRunner()
        bal_resp = _make_resp({"available_credits": 9999, "available_usd": 99.99})
        with patch("httpx.get", return_value=bal_resp), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "python", "train.py"], input="n\n")
        # Aborted
        assert result.exit_code != 0 or "Aborted" in result.output

    def test_run_credit_fetch_failure(self):
        """Credit balance fetch failure should show warning and continue."""
        from cli.main import cli
        import httpx
        runner = CliRunner()
        with patch("httpx.get", side_effect=httpx.HTTPError("timeout")), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", new_callable=AsyncMock), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "--yes", "python", "train.py"])
        assert "Warning" in result.output or result.exit_code == 0

    def _run_get_side_effects(self):
        """Mock side_effects for httpx.get in the run command.

        New call order (no --gpu → auto-select path):
          1. GET /api/v1/pricing/gpu?available_only=true  → bulk GPU list
          2. GET /api/v1/credits                          → credit balance
        """
        gpu_list_resp = _make_resp({
            "gpus": [
                {
                    "gpu_type": "A10G",
                    "providers": [{"provider": "Vast.ai", "price_per_hour": 0.60,
                                   "vaultlayer_rate": 0.72, "availability": "high",
                                   "is_spot": True, "region": "us-east-1"}],
                    "best_vaultlayer_rate": 0.72,
                    "cache_age_seconds": 30,
                }
            ],
            "cache_age_seconds": 30,
        })
        bal_resp = _make_resp({"available_credits": 9999, "available_usd": 99.99})
        return [gpu_list_resp, bal_resp]

    def test_run_with_yes_flag(self):
        """--yes flag skips confirmation."""
        from cli.main import cli
        runner = CliRunner()
        mock_execute = AsyncMock()
        with patch("httpx.get", side_effect=self._run_get_side_effects()), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", mock_execute), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "--yes", "python", "train.py"])
        mock_execute.assert_called_once()

    def test_run_with_regions(self):
        """--regions and --excluded-regions are parsed correctly."""
        from cli.main import cli
        runner = CliRunner()
        captured = {}
        async def fake_execute(self_):
            captured["regions"] = self_.regions
            captured["excluded"] = self_.excluded_regions
        with patch("httpx.get", side_effect=self._run_get_side_effects()), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", fake_execute), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            runner.invoke(cli, [
                "run", "--yes",
                "--regions", "us-east-1,eu-west-1",
                "--excluded-regions", "cn-north-1",
                "python", "train.py"
            ])
        assert "us-east-1" in captured.get("regions", [])
        assert "cn-north-1" in captured.get("excluded", [])

    def test_run_exception_triggers_crash_report(self):
        """Unhandled exception in execute() should save crash report."""
        from cli.main import cli
        runner = CliRunner()
        with patch("httpx.get", side_effect=self._run_get_side_effects()), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", side_effect=RuntimeError("boom")), \
             patch("cli.crash_reporter.save_crash_report", return_value="cr_test123") as mock_save, \
             patch("cli.feedback.prompt_crash_report") as mock_prompt, \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "--yes", "python", "train.py"])
        assert mock_save.called
        assert mock_prompt.called
        assert result.exit_code != 0

    def test_run_keyboard_interrupt(self):
        """KeyboardInterrupt should be handled gracefully."""
        from cli.main import cli
        runner = CliRunner()
        with patch("httpx.get", side_effect=self._run_get_side_effects()), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", side_effect=KeyboardInterrupt()), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "--yes", "python", "train.py"])
        assert "Interrupted" in result.output

    def test_run_low_credits_warning(self):
        """Low credits should show warning but proceed during testing phase."""
        from cli.main import cli
        runner = CliRunner()
        # Return very low credits
        bal_resp = _make_resp({"available_credits": 1, "available_usd": 0.01})
        mock_execute = AsyncMock()
        with patch("httpx.get", return_value=bal_resp), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", mock_execute), \
             patch.dict(os.environ, {"VAULTLAYER_TOKEN": "vl_test_tok"}):
            result = runner.invoke(cli, ["run", "--yes", "python", "train.py"])
        assert "Warning" in result.output or "low credits" in result.output.lower()


# ---------------------------------------------------------------------------
# Auto-select GPU logic (cli/main.py run command)
# Tests every path through the pricing-cache → GPU-selection → job-submit flow.
# ---------------------------------------------------------------------------

class TestAutoSelectGpu:
    """
    Call order for no-gpu path:
      1. GET /api/v1/pricing/gpu?available_only=true  → _auto_select_resp
      2. GET /api/v1/credits                          → _bal_resp
    """

    _BAL = _make_resp({"available_credits": 9999, "available_usd": 99.99})
    _ENV = {"VAULTLAYER_TOKEN": "vl_test_tok"}

    def _gpu_list(self, gpus, cache_age=30):
        """Build a /pricing/gpu response with the given GPU entries."""
        return _make_resp({"gpus": gpus, "cache_age_seconds": cache_age})

    def _gpu_entry(self, gpu_type, rate=1.00, providers=None):
        """Single GPU entry as the API returns it."""
        if providers is None:
            providers = [{"provider": "Vast.ai", "price_per_hour": rate / 1.2,
                          "vaultlayer_rate": rate, "availability": "high",
                          "is_spot": True, "region": "us-east-1"}]
        return {
            "gpu_type": gpu_type,
            "providers": providers,
            "best_vaultlayer_rate": rate,
        }

    def _invoke(self, get_side_effects, extra_args=None):
        from cli.main import cli
        runner = CliRunner()
        mock_exec = AsyncMock()
        args = ["run", "--yes"] + (extra_args or []) + ["python", "train.py"]
        with patch("httpx.get", side_effect=get_side_effects), \
             patch("cli.main._api_url", return_value="http://test"), \
             patch("cli.run.RunCommand.execute", mock_exec), \
             patch.dict(os.environ, self._ENV):
            result = runner.invoke(cli, args)
        return result, mock_exec

    # ── Happy path ────────────────────────────────────────────────────────

    def test_picks_cheapest_gpu_with_enough_vram(self):
        """Auto-select returns cheapest GPU whose VRAM >= min_vram."""
        # A10G ($0.72) cheaper than H100 ($3.50), both have enough VRAM for 7B qlora
        gpus = [
            self._gpu_entry("H100_80GB_SXM", rate=3.50),
            self._gpu_entry("A10G",           rate=0.72),
        ]
        result, mock_exec = self._invoke([self._gpu_list(gpus), self._BAL])
        assert mock_exec.called
        assert "A10G" in result.output   # cheapest selected
        assert "H100" not in result.output.split("Auto-selected")[1].split("\n")[0]

    def test_auto_selects_only_gpu_with_providers(self):
        """GPUs with empty providers list (unavailable) are skipped."""
        gpus = [
            self._gpu_entry("H100_80GB_SXM", providers=[]),  # no capacity
            self._gpu_entry("A100_40GB", rate=1.50),
        ]
        result, mock_exec = self._invoke([self._gpu_list(gpus), self._BAL])
        assert mock_exec.called
        assert "A100_40GB" in result.output

    def test_short_alias_gpu_names_not_filtered_out(self):
        """GPU types like 'A100', 'H100', 'GH200' from the pricing cache
        must not be silently excluded by the VRAM lookup (fail-open)."""
        gpus = [
            self._gpu_entry("A100",  rate=1.80),
            self._gpu_entry("GH200", rate=2.50),
        ]
        result, mock_exec = self._invoke([self._gpu_list(gpus), self._BAL])
        assert mock_exec.called  # job submitted, not blocked

    def test_unknown_gpu_type_included_fail_open(self):
        """GPU types not in _GPU_VRAM_GB get float('inf') VRAM → always included."""
        gpus = [self._gpu_entry("FUTURE_GPU_XYZ", rate=0.99)]
        result, mock_exec = self._invoke([self._gpu_list(gpus), self._BAL])
        assert mock_exec.called

    def test_vram_floor_excludes_underpowered_gpu(self):
        """T4 (16GB) must be excluded when running a 30B full-finetune (68GB needed)."""
        gpus = [
            self._gpu_entry("T4",           rate=0.30),   # 16GB — too small
            self._gpu_entry("A100_80GB_SXM", rate=2.00),  # 80GB — fits
        ]
        result, mock_exec = self._invoke(
            [self._gpu_list(gpus), self._BAL],
            extra_args=["--model-params", "30", "--train-mode", "full"],
        )
        assert mock_exec.called
        assert "A100_80GB_SXM" in result.output
        assert "T4" not in result.output

    # ── Cache-missing fallback ─────────────────────────────────────────────

    def test_cache_missing_falls_back_to_h100_and_warns(self):
        """When cache_age_seconds=None (cache cold), warn and default to H100.
        Job must still be submitted — users should not be blocked."""
        # cache_age=None, no GPU entries
        result, mock_exec = self._invoke(
            [self._gpu_list([], cache_age=None), self._BAL]
        )
        assert mock_exec.called, "Job must be submitted even when cache is cold"
        assert "Warning" in result.output or "unavailable" in result.output.lower()

    def test_cache_missing_available_only_returns_empty_does_not_exit(self):
        """Regression: before fix, empty GPU list raised SystemExit regardless
        of cache_age. With fix, job submits to H100 queue."""
        # The pricing API returns 200 with empty gpus and null cache_age —
        # this is the exact scenario that produced "No GPU with ≥8GB VRAM".
        result, mock_exec = self._invoke(
            [self._gpu_list([], cache_age=None), self._BAL]
        )
        assert result.exit_code == 0
        assert mock_exec.called

    # ── Live cache, no capacity ────────────────────────────────────────────

    def test_live_cache_no_capacity_still_submits(self):
        """When cache is live (cache_age set) but all GPUs are unavailable,
        submit to queue anyway — job waits for capacity instead of erroring."""
        # All GPUs have no providers (capacity exhausted)
        gpus = [
            self._gpu_entry("H100_80GB_SXM", providers=[]),
            self._gpu_entry("A100_40GB",     providers=[]),
        ]
        result, mock_exec = self._invoke([self._gpu_list(gpus, cache_age=45), self._BAL])
        assert mock_exec.called, "Job must be submitted to queue even when capacity is 0"
        assert result.exit_code == 0

    def test_live_cache_no_capacity_shows_queue_message(self):
        """User sees a message about queueing, not a hard error."""
        gpus = [self._gpu_entry("H100_80GB_SXM", providers=[])]
        result, _ = self._invoke([self._gpu_list(gpus, cache_age=60), self._BAL])
        output = result.output.lower()
        # Must not say "reduce model size" (wrong error) or exit non-zero
        assert "reduce model" not in output
        assert result.exit_code == 0

    # ── API error fallbacks ────────────────────────────────────────────────

    def test_api_500_falls_back_to_h100(self):
        """Non-200 from pricing API → warn and default to H100."""
        err_resp = _make_resp({}, status_code=500)
        result, mock_exec = self._invoke([err_resp, self._BAL])
        assert mock_exec.called
        assert "Warning" in result.output or "unavailable" in result.output.lower()

    def test_api_connection_error_falls_back_to_h100(self):
        """Network error on pricing call → warn and default to H100."""
        import httpx as _httpx
        result, mock_exec = self._invoke(
            [_httpx.ConnectError("timeout"), self._BAL]
        )
        assert mock_exec.called
        assert "Warning" in result.output or "unavailable" in result.output.lower()

    # ── Specified GPU + BFS ────────────────────────────────────────────────

    def test_specified_gpu_available_skips_pricing_bulk_call(self):
        """When --gpu is passed, we call the single-GPU availability endpoint,
        not the bulk pricing endpoint."""
        avail_resp = _make_resp({
            "available": True, "gpu_type": "A100_40GB",
            "vaultlayer_rate_per_hr": 1.50, "cache_age_seconds": 30,
        })
        result, mock_exec = self._invoke(
            [avail_resp, self._BAL],
            extra_args=["--gpu", "A100_40GB"],
        )
        assert mock_exec.called

    def test_specified_gpu_unavailable_bfs_offers_fallback(self):
        """When requested GPU is unavailable, BFS finds nearest alternative
        and prompts Y/n. --yes flag auto-accepts."""
        # H100 unavailable, A10G available (BFS neighbor)
        h100_unavail = _make_resp({
            "available": False, "gpu_type": "H100_80GB_SXM",
            "fallback_offer": None, "cache_age_seconds": 30,
        })
        # BFS calls _check_avail for each neighbor until one is available
        a100_unavail = _make_resp({"available": False, "cache_age_seconds": 30})
        a10g_avail   = _make_resp({
            "available": True, "gpu_type": "A10G",
            "vaultlayer_rate_per_hr": 0.72, "cache_age_seconds": 30,
        })
        result, mock_exec = self._invoke(
            [h100_unavail, a100_unavail, a100_unavail, a10g_avail, a10g_avail, self._BAL],
            extra_args=["--gpu", "H100_80GB_SXM"],
        )
        assert mock_exec.called
        assert "A10G" in result.output or "alternative" in result.output.lower()

    def test_specified_gpu_unavailable_no_bfs_exits(self):
        """When requested GPU and all BFS alternatives are unavailable, exit cleanly."""
        unavail = _make_resp({"available": False, "cache_age_seconds": 30})
        # All availability calls return unavailable
        result, mock_exec = self._invoke(
            [unavail] * 15,   # enough for full BFS traversal
            extra_args=["--gpu", "A10G"],
        )
        assert not mock_exec.called
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# cli/run.py — RunCommand internals
# ---------------------------------------------------------------------------

class TestRunCommandInternals:
    def _make_runner(self, command=None, gpu_type="H100_80GB_SXM", model_params=7.0):
        from cli.run import RunCommand
        return RunCommand(
            command=command or ["python", "train.py"],
            job_name="test-job",
            gpu_type=gpu_type,
            model_params_billion=model_params,
        )

    def test_check_multi_node_world_size(self):
        """WORLD_SIZE > 1 in env triggers abort."""
        runner = self._make_runner()
        with patch.dict(os.environ, {"WORLD_SIZE": "2", "NODE_RANK": "0", "RANK": "0"}):
            with pytest.raises(SystemExit):
                runner._check_multi_node()

    def test_check_multi_node_rank(self):
        """RANK > 0 triggers abort."""
        runner = self._make_runner()
        with patch.dict(os.environ, {"WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "1"}):
            with pytest.raises(SystemExit):
                runner._check_multi_node()

    def test_check_multi_node_torchrun(self):
        """torchrun --nnodes=4 triggers abort."""
        runner = self._make_runner(command=["torchrun", "--nnodes=4", "train.py"])
        with patch.dict(os.environ, {"WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "0"}):
            with pytest.raises(SystemExit):
                runner._check_multi_node()

    def test_check_multi_node_deepspeed(self):
        """deepspeed --num_nodes=2 triggers abort."""
        runner = self._make_runner(command=["deepspeed", "--num_nodes=2", "train.py"])
        with patch.dict(os.environ, {"WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "0"}):
            with pytest.raises(SystemExit):
                runner._check_multi_node()

    def test_check_multi_node_hostfile(self):
        """--hostfile flag triggers abort."""
        runner = self._make_runner(command=["torchrun", "--hostfile", "hosts.txt", "train.py"])
        with patch.dict(os.environ, {"WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "0"}):
            with pytest.raises(SystemExit):
                runner._check_multi_node()

    def test_check_multi_node_allow_env(self):
        """VAULTLAYER_ALLOW_MULTINODE=1 allows multi-node to proceed."""
        runner = self._make_runner(command=["torchrun", "--nnodes=4", "train.py"])
        with patch.dict(os.environ, {
            "WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "0",
            "VAULTLAYER_ALLOW_MULTINODE": "1"
        }):
            # Should NOT raise
            runner._check_multi_node()

    def test_check_multi_node_single_node_ok(self):
        """Single-node command passes multi-node check."""
        runner = self._make_runner(command=["python", "train.py"])
        with patch.dict(os.environ, {"WORLD_SIZE": "1", "NODE_RANK": "0", "RANK": "0"}):
            runner._check_multi_node()  # should not raise

    def test_print_preflight_yes_flag(self):
        """_print_preflight returns True immediately when yes=True."""
        runner = self._make_runner()
        mock_prices = {
            "AWS On-Demand": {"H100_80GB_SXM": 3.90},
            "Lambda Labs": {"H100_80GB_SXM": 1.99},
        }
        mock_aliases = {"H100_80GB_SXM": "H100_80GB_SXM", "H100": "H100_80GB_SXM"}
        with patch("shared.data_loader.get_provider_prices", return_value=mock_prices), \
             patch("shared.data_loader.get_gpu_aliases", return_value=mock_aliases), \
             patch("shared.data_loader.recommend_gpu", return_value=("H100_80GB_SXM", 80, "Best GPU", 1)), \
             patch("shared.data_loader.get_meta", return_value={"last_updated": "2026-01-01"}):
            result = runner._print_preflight(yes=True)
        assert result is True

    def test_print_preflight_explicit_gpu(self):
        """_print_preflight shows GPU info when explicit --gpu is set."""
        runner = self._make_runner(gpu_type="A100_40GB")
        mock_prices = {
            "AWS On-Demand": {"A100_40GB": 2.07},
            "Lambda Labs": {"A100_40GB": 1.10},
        }
        mock_aliases = {"A100_40GB": "A100_40GB"}
        with patch("shared.data_loader.get_provider_prices", return_value=mock_prices), \
             patch("shared.data_loader.get_gpu_aliases", return_value=mock_aliases), \
             patch("shared.data_loader.recommend_gpu", return_value=("A100_40GB", 40, "OK", 1)), \
             patch("shared.data_loader.get_meta", return_value={}):
            result = runner._print_preflight(yes=True)
        assert result is True

    def test_print_preflight_no_providers(self):
        """_print_preflight handles empty provider list gracefully."""
        runner = self._make_runner()
        with patch("shared.data_loader.get_provider_prices", return_value={}), \
             patch("shared.data_loader.get_gpu_aliases", return_value={}), \
             patch("shared.data_loader.recommend_gpu", return_value=("H100_80GB_SXM", 80, "Default", 1)), \
             patch("shared.data_loader.get_meta", return_value={}):
            result = runner._print_preflight(yes=True)
        assert result is True

    @pytest.mark.asyncio
    async def test_maybe_mirror_s3_data_already_exists(self):
        """If dataset already in R2, skip mirror and return dataset_id."""
        runner = self._make_runner()
        runner.yes = True

        mock_manifest = MagicMock()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "bucket"

        with patch("shared.config.load_config", return_value=mock_config), \
             patch("agents.vault.r2.R2Client", MagicMock()), \
             patch("agents.namespace.ingestion.DatasetIngester.load_manifest", new_callable=AsyncMock, return_value=mock_manifest):
            result = await runner._maybe_mirror_s3_data("s3://my-bucket/my-prefix")

        assert result == "my-bucket-my-prefix"

    @pytest.mark.asyncio
    async def test_maybe_mirror_s3_data_needs_mirror(self):
        """When manifest not found, run _sync_from_s3."""
        runner = self._make_runner()
        runner.yes = True

        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "bucket"

        with patch("shared.config.load_config", return_value=mock_config), \
             patch("agents.vault.r2.R2Client", MagicMock()), \
             patch("agents.namespace.ingestion.DatasetIngester.load_manifest", new_callable=AsyncMock, return_value=None), \
             patch("cli.sync._sync_from_s3", new_callable=AsyncMock) as mock_sync:
            result = await runner._maybe_mirror_s3_data("s3://my-bucket/pfx")

        mock_sync.assert_called_once()
        assert result == "my-bucket-pfx"

    @pytest.mark.asyncio
    async def test_maybe_mirror_s3_data_exception(self):
        """On exception, return None (training proceeds without R2 dataset)."""
        runner = self._make_runner()
        runner.yes = True

        with patch("shared.config.load_config", side_effect=Exception("no config")):
            result = await runner._maybe_mirror_s3_data("s3://bucket/prefix")

        assert result is None

    @pytest.mark.asyncio
    async def test_maybe_mirror_r2_uri(self):
        """r2:// URI — sets env var directly, no mirror."""
        from cli.run import RunCommand
        runner = RunCommand(
            command=["python", "train.py"],
            job_name="test",
            data_uri="r2://my-dataset",
        )
        runner.yes = True
        # The r2:// branch is inside execute(), but _maybe_mirror_s3_data
        # is only called for s3:// URIs. Verify the s3 path works.
        result = await runner._maybe_mirror_s3_data("s3://bucket/pfx")
        # This will fail on config load — that's fine, returns None
        assert result is None or isinstance(result, str)


# ---------------------------------------------------------------------------
# cli/ps.py
# ---------------------------------------------------------------------------

class TestPsCommand:
    def test_ps_no_jobs(self):
        from cli.ps import ps
        runner = CliRunner()
        mock_redis = AsyncMock()
        mock_redis.keys = AsyncMock(return_value=[])
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        mock_queue.connect = AsyncMock()
        mock_queue.disconnect = AsyncMock()

        # Patch get_token to return None so the API call is skipped — otherwise
        # a live token in ~/.vaultlayer/config.env would cause the API to return
        # real jobs and the "No active jobs" assertion would fail.
        with patch("shared.config.load_config", return_value=MagicMock(redis=MagicMock(url="redis://localhost"))), \
             patch("shared.queue.AgentQueue", return_value=mock_queue), \
             patch("shared.api_utils.get_token", return_value=None):
            result = runner.invoke(ps)
        assert "No active jobs" in result.output

    def test_ps_with_running_job(self):
        from cli.ps import ps
        runner = CliRunner()
        job_state = json.dumps({
            "job_id": "abc12345", "name": "test-job", "status": "running",
            "provider": "aws", "current_step": 100,
            "started_at": "2026-01-01T00:00:00",
        })
        mock_redis = AsyncMock()
        mock_redis.keys = AsyncMock(return_value=["vaultlayer:job:default:abc12345"])
        mock_redis.get = AsyncMock(return_value=job_state)
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        mock_queue.connect = AsyncMock()
        mock_queue.disconnect = AsyncMock()

        with patch("shared.config.load_config", return_value=MagicMock(redis=MagicMock(url="redis://localhost"))), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(ps)
        assert "running" in result.output or result.exit_code == 0

    def test_ps_show_all_includes_completed(self):
        from cli.ps import ps
        runner = CliRunner()
        job_state = json.dumps({
            "job_id": "abc12345", "name": "test-job", "status": "completed",
            "provider": "aws", "current_step": 500,
            "started_at": "2026-01-01T00:00:00",
        })
        mock_redis = AsyncMock()
        mock_redis.keys = AsyncMock(return_value=["vaultlayer:job:default:abc12345"])
        mock_redis.get = AsyncMock(return_value=job_state)
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        mock_queue.connect = AsyncMock()
        mock_queue.disconnect = AsyncMock()

        with patch("shared.config.load_config", return_value=MagicMock(redis=MagicMock(url="redis://localhost"))), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(ps, ["--all"])
        assert "completed" in result.output

    def test_ps_redis_error(self):
        from cli.ps import ps
        runner = CliRunner()
        with patch("shared.config.load_config", side_effect=Exception("redis unreachable")):
            result = runner.invoke(ps)
        assert "Could not connect" in result.output or result.exit_code == 0

    def test_ps_invalid_json_in_redis(self):
        from cli.ps import ps
        runner = CliRunner()
        mock_redis = AsyncMock()
        mock_redis.keys = AsyncMock(return_value=["vaultlayer:job:default:bad"])
        mock_redis.get = AsyncMock(return_value="NOT_VALID_JSON")
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        mock_queue.connect = AsyncMock()
        mock_queue.disconnect = AsyncMock()

        with patch("shared.config.load_config", return_value=MagicMock(redis=MagicMock(url="redis://localhost"))), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(ps)
        # Should not crash
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# cli/delete.py
# ---------------------------------------------------------------------------

class TestDeleteCommand:
    def _make_mock_queue(self, job_status="completed"):
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value=json.dumps({"status": job_status}))
        mock_redis.keys = AsyncMock(return_value=[])
        mock_redis.delete = AsyncMock()
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        mock_queue.connect = AsyncMock()
        mock_queue.disconnect = AsyncMock()
        return mock_queue, mock_redis

    def test_delete_job_dry_run(self):
        from cli.delete import delete_job
        runner = CliRunner()
        mock_queue, _ = self._make_mock_queue()
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = ["checkpoints/user/job/file1.pt"]

        with patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"),
                redis=MagicMock(url="redis://localhost"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.queue.AgentQueue", return_value=mock_queue), \
             patch("shared.security.get_audit", return_value=MagicMock()):
            result = runner.invoke(delete_job, ["--job-id", "job-123", "--dry-run"])
        assert "DRY RUN" in result.output
        assert "Nothing deleted" in result.output

    def test_delete_job_blocked_if_running(self):
        from cli.delete import delete_job
        runner = CliRunner()
        mock_queue, _ = self._make_mock_queue(job_status="running")
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = []

        with patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"),
                redis=MagicMock(url="redis://localhost"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(delete_job, ["--job-id", "job-123", "--confirm"])
        assert "BLOCKED" in result.output

    def test_delete_job_with_force(self):
        from cli.delete import delete_job
        runner = CliRunner()
        mock_queue, mock_redis = self._make_mock_queue()
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = ["checkpoints/u/j/f.pt"]
        mock_r2.delete_job_checkpoints.return_value = 1
        mock_audit = MagicMock()

        with patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"),
                redis=MagicMock(url="redis://localhost"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.queue.AgentQueue", return_value=mock_queue), \
             patch("shared.security.get_audit", return_value=mock_audit):
            result = runner.invoke(delete_job, ["--job-id", "job-123", "--confirm", "--force"])
        assert "Deleted" in result.output or result.exit_code == 0

    def test_delete_job_abort_no_confirm(self):
        """Without --confirm and user says no, aborts."""
        from cli.delete import delete_job
        runner = CliRunner()
        mock_queue, _ = self._make_mock_queue()
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = []

        with patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"),
                redis=MagicMock(url="redis://localhost"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(delete_job, ["--job-id", "job-123"], input="n\n")
        assert "Aborted" in result.output or result.exit_code == 0

    def test_delete_job_type_to_confirm_wrong(self):
        """Type-to-confirm with wrong ID aborts."""
        from cli.delete import delete_job
        runner = CliRunner()
        mock_queue, _ = self._make_mock_queue()
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = []

        with patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"),
                redis=MagicMock(url="redis://localhost"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(delete_job, ["--job-id", "job-123", "--confirm"],
                                   input="wrong-id\n")
        assert "Confirmation failed" in result.output

    def test_rotate_key_dry_run(self):
        from cli.delete import rotate_key
        runner = CliRunner()
        mock_r2 = MagicMock()
        mock_r2.list_all_objects.return_value = ["checkpoints/u/j/f.pt"]
        mock_enc = MagicMock()

        with patch.dict("os.environ", {"VL_INTERNAL_ADMIN_TOKEN": "test-token"}), \
             patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"))), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2), \
             patch("shared.security.CheckpointEncryption", return_value=mock_enc):
            result = runner.invoke(rotate_key, [
                "--new-key", "newkey123", "--dry-run"
            ])
        assert "Dry run" in result.output or result.exit_code == 0

    def test_rotate_key_requires_confirm_or_dry_run(self):
        from cli.delete import rotate_key
        runner = CliRunner()
        with patch.dict("os.environ", {"VL_INTERNAL_ADMIN_TOKEN": "test-token"}), \
             patch("shared.config.load_config", return_value=MagicMock(
                cloudflare=MagicMock(r2_endpoint="e", r2_access_key_id="k",
                                     r2_secret_access_key="s", r2_bucket="b"))), \
             patch("agents.vault.r2.R2Client", return_value=MagicMock()):
            result = runner.invoke(rotate_key, ["--new-key", "key"])
        assert "dry-run" in result.output or result.exit_code == 0


# ---------------------------------------------------------------------------
# cli/feedback.py
# ---------------------------------------------------------------------------

class TestFeedbackCommand:
    def test_feedback_no_report_id_success(self):
        """Interactive feedback: describe issue, submit successfully."""
        from cli.feedback import feedback
        runner = CliRunner()
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        resp.json.return_value = {"id": "fb_test123"}

        with patch("httpx.post", return_value=resp), \
             patch("cli.feedback._api_url", return_value="http://test"), \
             patch("cli.feedback._load_token", return_value="vl_live_tok"):
            result = runner.invoke(feedback, [], input="I found a bug\n")
        assert "fb_test123" in result.output or "submitted" in result.output.lower()

    def test_feedback_no_token(self):
        """Without token, feedback interactive path shows auth message."""
        from cli.feedback import feedback
        runner = CliRunner()
        with patch("cli.feedback._load_token", return_value=None):
            result = runner.invoke(feedback, [], input="I found a bug\n")
        assert "init" in result.output or "authenticated" in result.output.lower()

    def test_feedback_with_report_id_not_found(self):
        """--report with non-existent ID shows error."""
        from cli.feedback import feedback
        runner = CliRunner()
        with patch("cli.feedback.load_crash_report", return_value=None):
            result = runner.invoke(feedback, ["--report", "cr_doesnotexist"])
        assert result.exit_code != 0
        assert "not found" in result.output

    def test_feedback_with_report_id_already_submitted(self):
        """Already-submitted report shows message and returns."""
        from cli.feedback import feedback
        runner = CliRunner()
        report = {"submitted": True, "id": "cr_test", "error_type": "ValueError",
                  "error_message": "test", "command": [], "fingerprint": "fp_test",
                  "timestamp": "2026-01-01T00:00:00"}
        with patch("cli.feedback.load_crash_report", return_value=report):
            result = runner.invoke(feedback, ["--report", "cr_test"])
        assert "already been submitted" in result.output

    def test_feedback_with_report_id_submit_success(self):
        """Submit a saved crash report successfully."""
        from cli.feedback import feedback
        runner = CliRunner()
        report = {"submitted": False, "id": "cr_test", "error_type": "ValueError",
                  "error_message": "test error", "command": ["python", "train.py"],
                  "fingerprint": "fp_abc", "timestamp": "2026-01-01T00:00:00"}
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        resp.json.return_value = {"id": "fb_submitted123"}

        with patch("cli.feedback.load_crash_report", return_value=report), \
             patch("cli.feedback._load_token", return_value="vl_live_tok"), \
             patch("cli.feedback.submit_report", return_value="fb_submitted123"), \
             patch("cli.feedback.mark_submitted"):
            result = runner.invoke(feedback, ["--report", "cr_test"], input="y\n")
        assert "submitted" in result.output.lower()

    def test_feedback_with_report_skip(self):
        """User declines to submit report."""
        from cli.feedback import feedback
        runner = CliRunner()
        report = {"submitted": False, "id": "cr_test", "error_type": "ValueError",
                  "error_message": "test", "command": [], "fingerprint": "fp_t",
                  "timestamp": "2026-01-01T00:00:00"}
        with patch("cli.feedback.load_crash_report", return_value=report), \
             patch("cli.feedback._load_token", return_value="vl_live_tok"):
            result = runner.invoke(feedback, ["--report", "cr_test"], input="n\n")
        assert "Skipped" in result.output

    def test_feedback_with_report_no_token(self):
        """No token when user says yes → show auth message."""
        from cli.feedback import feedback
        runner = CliRunner()
        report = {"submitted": False, "id": "cr_test", "error_type": "ValueError",
                  "error_message": "test", "command": [], "fingerprint": "fp_t",
                  "timestamp": "2026-01-01T00:00:00"}
        with patch("cli.feedback.load_crash_report", return_value=report), \
             patch("cli.feedback._load_token", return_value=None):
            result = runner.invoke(feedback, ["--report", "cr_test"], input="y\n")
        assert "init" in result.output or result.exit_code != 0

    def test_prompt_crash_report_no_report(self):
        """prompt_crash_report returns early if report not found."""
        from cli.feedback import prompt_crash_report
        with patch("cli.feedback.load_crash_report", return_value=None):
            prompt_crash_report("cr_missing", ["python", "train.py"])  # Should not raise

    def test_prompt_crash_report_submit(self):
        """prompt_crash_report submits when user says y."""
        from cli.feedback import prompt_crash_report
        report = {"id": "cr_test", "error_type": "ValueError", "error_message": "oops",
                  "fingerprint": "fp_abc", "command": ["python"]}
        with patch("cli.feedback.load_crash_report", return_value=report), \
             patch("cli.feedback._load_token", return_value="vl_live_tok"), \
             patch("cli.feedback.submit_report", return_value="fb_done") as mock_submit, \
             patch("cli.feedback.mark_submitted") as mock_mark, \
             patch("click.prompt", return_value="y"), \
             patch("click.echo"):
            prompt_crash_report("cr_test", ["python", "train.py"])
        mock_submit.assert_called_once()
        mock_mark.assert_called_once()

    def test_prompt_crash_report_skip(self):
        """prompt_crash_report skips when user says n."""
        from cli.feedback import prompt_crash_report
        report = {"id": "cr_test", "error_type": "ValueError", "error_message": "oops",
                  "fingerprint": "fp_abc", "command": ["python"]}
        with patch("cli.feedback.load_crash_report", return_value=report), \
             patch("cli.feedback._load_token", return_value="vl_live_tok"), \
             patch("click.prompt", return_value="n"), \
             patch("click.echo"):
            prompt_crash_report("cr_test", ["python", "train.py"])


# ---------------------------------------------------------------------------
# cli/sync.py
# ---------------------------------------------------------------------------

class TestSyncCommand:
    def test_parse_s3_uri(self):
        from cli.sync import _parse_s3_uri
        bucket, prefix = _parse_s3_uri("s3://my-bucket/my/prefix")
        assert bucket == "my-bucket"
        assert prefix == "my/prefix"

    def test_parse_s3_uri_no_prefix(self):
        from cli.sync import _parse_s3_uri
        bucket, prefix = _parse_s3_uri("s3://my-bucket")
        assert bucket == "my-bucket"
        assert prefix == ""

    def test_estimate_egress_cost_free_tier(self):
        from cli.sync import _estimate_s3_egress_cost
        # Under 100 GB free tier
        cost = _estimate_s3_egress_cost(50.0)
        assert cost == 0.0

    def test_estimate_egress_cost_tier1(self):
        from cli.sync import _estimate_s3_egress_cost
        # 200 GB — 100 GB free, 100 GB at $0.09
        cost = _estimate_s3_egress_cost(200.0)
        assert abs(cost - 9.0) < 0.01

    def test_estimate_egress_cost_tier2(self):
        from cli.sync import _estimate_s3_egress_cost
        # 11,000 GB — crosses tier boundary
        cost = _estimate_s3_egress_cost(11_000.0)
        assert cost > 0

    def test_sync_path_not_found(self):
        from cli.sync import sync
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(sync, ["./nonexistent", "--dataset-id", "ds"])
        assert result.exit_code != 0
        assert "not found" in result.output or "Error" in result.output

    def test_sync_existing_dataset_no_force(self):
        from cli.sync import sync
        runner = CliRunner()
        mock_manifest = MagicMock()
        mock_manifest.total_shards = 10
        mock_manifest.total_size_bytes = 1024 * 1024 * 1024

        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "bucket"

        with runner.isolated_filesystem():
            Path("data").mkdir()
            with patch("shared.config.load_config", return_value=mock_config), \
                 patch("agents.vault.r2.R2Client", MagicMock()), \
                 patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
                       new_callable=AsyncMock, return_value=mock_manifest):
                result = runner.invoke(sync, ["data", "--dataset-id", "my-ds"])
        assert "already exists" in result.output

    def test_sync_s3_source_success(self):
        from cli.sync import sync
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "bucket"
        mock_config.aws.access_key_id = "aws-key"
        mock_config.aws.secret_access_key = "aws-secret"

        with patch("shared.config.load_config", return_value=mock_config), \
             patch("agents.vault.r2.R2Client", MagicMock()), \
             patch("agents.namespace.ingestion.DatasetIngester.load_manifest",
                   new_callable=AsyncMock, return_value=None), \
             patch("cli.sync._sync_from_s3", new_callable=AsyncMock) as mock_s3sync:
            result = runner.invoke(sync, ["s3://bucket/prefix", "--dataset-id", "ds", "--yes"])
        mock_s3sync.assert_called_once()

    def test_register_dataset_no_supabase(self):
        from cli.sync import _register_dataset
        mock_config = MagicMock()
        # Should silently no-op when api.db import fails or SUPABASE_URL not set
        with patch("cli.sync._register_dataset", wraps=lambda *a, **k: None):
            # Test that it doesn't raise on import error
            pass
        # Direct test: exception silently swallowed
        with patch("builtins.__import__", side_effect=ImportError("no api.db")):
            # _register_dataset catches all exceptions
            try:
                _register_dataset(mock_config, "ds-id", "ds-name", "local", None, 1000, 1)
            except Exception:
                pass  # either way, no crash we don't catch


# ---------------------------------------------------------------------------
# cli/estimate.py
# ---------------------------------------------------------------------------

class TestEstimateCommand:
    def test_estimate_known_gpu(self):
        from cli.estimate import estimate
        runner = CliRunner()
        mock_prices = {
            "AWS On-Demand": {"H100_80GB_SXM": 3.90},
            "Lambda Labs": {"H100_80GB_SXM": 1.99},
        }
        mock_aliases = {"H100": "H100_80GB_SXM", "H100_80GB_SXM": "H100_80GB_SXM"}
        with patch("shared.data_loader.get_provider_prices", return_value=mock_prices), \
             patch("shared.data_loader.get_gpu_aliases", return_value=mock_aliases), \
             patch("shared.data_loader.get_meta", return_value={"last_updated": "2026-01-01"}):
            result = runner.invoke(estimate, ["--gpu", "H100", "--hours", "10"])
        assert result.exit_code == 0
        assert "VaultLayer Estimate" in result.output

    def test_estimate_unknown_gpu(self):
        from cli.estimate import estimate
        runner = CliRunner()
        mock_prices = {"AWS On-Demand": {"H100_80GB_SXM": 3.90}}
        mock_aliases = {}
        with patch("shared.data_loader.get_provider_prices", return_value=mock_prices), \
             patch("shared.data_loader.get_gpu_aliases", return_value=mock_aliases), \
             patch("shared.data_loader.get_meta", return_value={}):
            result = runner.invoke(estimate, ["--gpu", "UNKNOWN_GPU"])
        assert "Unknown GPU" in result.output

    def test_estimate_multiple_gpus(self):
        from cli.estimate import estimate
        runner = CliRunner()
        mock_prices = {
            "AWS On-Demand": {"H100_80GB_SXM": 3.90},
            "Lambda Labs": {"H100_80GB_SXM": 1.99},
        }
        mock_aliases = {"H100": "H100_80GB_SXM"}
        with patch("shared.data_loader.get_provider_prices", return_value=mock_prices), \
             patch("shared.data_loader.get_gpu_aliases", return_value=mock_aliases), \
             patch("shared.data_loader.get_meta", return_value={}):
            result = runner.invoke(estimate, ["--gpu", "H100", "--gpus", "8", "--hours", "24"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# cli/main.py — logs, stop
# ---------------------------------------------------------------------------

class TestLogsCommand:
    def _mock_config(self):
        cfg = MagicMock()
        cfg.cloudflare.r2_endpoint = "https://r2.example.com"
        cfg.cloudflare.r2_access_key_id = "key"
        cfg.cloudflare.r2_secret_access_key = "secret"
        cfg.cloudflare.r2_bucket = "vaultlayer-checkpoints"
        return cfg

    def _mock_api_logs(self, lines):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"lines": [{"line": l} for l in lines]}
        return mock_resp

    def test_logs_prints_lines(self):
        from cli.main import cli
        runner = CliRunner()
        mock_resp = self._mock_api_logs(["step 100 loss 0.42", "step 200 loss 0.38"])
        with patch("shared.api_utils.get_token", return_value="vl_live_test"), \
             patch("httpx.get", return_value=mock_resp):
            result = runner.invoke(cli, ["logs", "job-abc123"])
        assert result.exit_code == 0
        assert "loss" in result.output

    def test_logs_no_such_key(self):
        from cli.main import cli
        runner = CliRunner()
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        with patch("shared.api_utils.get_token", return_value="vl_live_test"), \
             patch("httpx.get", return_value=mock_resp):
            result = runner.invoke(cli, ["logs", "job-missing"])
        assert "No logs found" in result.output or result.exit_code == 0

    def test_logs_config_error(self):
        from cli.main import cli
        runner = CliRunner()
        # No token + no R2 config → config error
        with patch("shared.api_utils.get_token", return_value=""), \
             patch("shared.config.load_config", side_effect=Exception("No config")):
            result = runner.invoke(cli, ["logs", "job-abc"])
        assert "Config error" in result.output or result.exit_code == 0

    def test_logs_tail_option(self):
        from cli.main import cli
        runner = CliRunner()
        lines = "\n".join(f"step {i}" for i in range(200))
        mock_r2 = MagicMock()
        mock_r2._s3.get_object.return_value = {"Body": MagicMock(read=lambda: lines.encode())}
        with patch("shared.config.load_config", return_value=self._mock_config()), \
             patch("agents.vault.r2.R2Client", return_value=mock_r2):
            result = runner.invoke(cli, ["logs", "job-abc", "--tail", "5"])
        assert result.exit_code == 0
        # Should show at most 5 lines of content
        output_lines = [l for l in result.output.splitlines() if l.startswith("step")]
        assert len(output_lines) <= 5


class TestStopCommand:
    def test_stop_sends_signal(self):
        from cli.main import cli
        runner = CliRunner()
        mock_queue = MagicMock()
        mock_queue.connect = AsyncMock()
        mock_queue.publish = AsyncMock()
        mock_queue.disconnect = AsyncMock()
        mock_config = MagicMock()
        mock_config.redis.url = "redis://localhost"
        with patch("shared.config.load_config", return_value=mock_config), \
             patch("shared.queue.AgentQueue", return_value=mock_queue):
            result = runner.invoke(cli, ["stop", "job-xyz", "--yes"])
        assert result.exit_code == 0
        assert "Stop signal sent" in result.output
        mock_queue.publish.assert_called_once()

    def test_stop_aborts_on_no(self):
        from cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["stop", "job-xyz"], input="n\n")
        assert result.exit_code != 0 or "Aborted" in result.output

    def test_stop_redis_error(self):
        from cli.main import cli
        runner = CliRunner()
        with patch("shared.config.load_config", side_effect=Exception("No Redis")):
            result = runner.invoke(cli, ["stop", "job-xyz", "--yes"])
        # Should not crash uncaught — exit gracefully
        assert result.exit_code in (0, 1)


# ---------------------------------------------------------------------------
# cli/download.py
# ---------------------------------------------------------------------------

class TestDownloadCommand:
    def test_download_success(self, tmp_path):
        from cli.download import download
        runner = CliRunner()
        mock_s3 = MagicMock()
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [
            {"Contents": [{"Key": "jobs/job-1/checkpoints/step-100/model.pt", "Size": 1024}]}
        ]
        mock_s3.get_paginator.return_value = mock_paginator
        mock_s3.download_file = MagicMock()
        with patch("shared.r2_utils.get_r2_credentials", return_value={
                "endpoint": "https://r2.example.com",
                "access_key_id": "key",
                "secret_access_key": "secret",
                "bucket": "vaultlayer-checkpoints",
            }), \
             patch("boto3.client", return_value=mock_s3), \
             patch("shared.manifest.generate_manifest", side_effect=Exception("no db")):
            result = runner.invoke(download, [
                "--job-id", "job-1",
                "--output", str(tmp_path / "out"),
            ])
        assert result.exit_code == 0
        assert "Done" in result.output or "files" in result.output

    def test_download_no_files(self, tmp_path):
        from cli.download import download
        runner = CliRunner()
        mock_s3 = MagicMock()
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [{"Contents": []}]
        mock_s3.get_paginator.return_value = mock_paginator
        with patch("shared.r2_utils.get_r2_credentials", return_value={
                "endpoint": "https://r2.example.com",
                "access_key_id": "key",
                "secret_access_key": "secret",
                "bucket": "vaultlayer-checkpoints",
            }), \
             patch("boto3.client", return_value=mock_s3), \
             patch("shared.manifest.generate_manifest", side_effect=Exception("no db")):
            result = runner.invoke(download, [
                "--job-id", "job-missing",
                "--output", str(tmp_path / "out"),
            ])
        assert result.exit_code == 0
        assert "No files found" in result.output

    def test_download_no_credentials(self, tmp_path):
        from cli.download import download
        runner = CliRunner()
        with patch("shared.r2_utils.get_r2_credentials", return_value={}), \
             patch("shared.api_utils.get_token", return_value=""), \
             patch("shared.manifest.generate_manifest", side_effect=Exception("no db")):
            result = runner.invoke(download, [
                "--job-id", "job-1",
                "--output", str(tmp_path / "out"),
            ])
        assert result.exit_code != 0 or "Error" in result.output

    def test_download_requires_job_id(self):
        from cli.download import download
        runner = CliRunner()
        result = runner.invoke(download, [])
        assert result.exit_code != 0
        assert "job-id" in result.output


# ---------------------------------------------------------------------------
# GPU selection helpers (cli/main.py)
# ---------------------------------------------------------------------------

class TestMinVramForModel:
    def test_qlora_7b(self):
        from cli.main import _min_vram_for_model
        assert _min_vram_for_model(7.0, "qlora") == pytest.approx(7.5)

    def test_lora_13b(self):
        from cli.main import _min_vram_for_model
        assert _min_vram_for_model(13.0, "lora") == pytest.approx(17.0)

    def test_full_70b(self):
        from cli.main import _min_vram_for_model
        assert _min_vram_for_model(70.0, "full") == pytest.approx(148.0)

    def test_qlora_small_model(self):
        from cli.main import _min_vram_for_model
        # 1B qlora: 1*0.5 + 4 = 4.5
        assert _min_vram_for_model(1.0, "qlora") == pytest.approx(4.5)

    def test_full_small_model(self):
        from cli.main import _min_vram_for_model
        # 3B full: 3*2 + 8 = 14
        assert _min_vram_for_model(3.0, "full") == pytest.approx(14.0)


class TestBfsGpuFallback:
    """Tests for _bfs_gpu_fallback — GPU BFS with VRAM filter."""

    def _avail(self, available_gpus: set):
        """Returns a check_avail_fn that marks the given GPUs as available."""
        def fn(gpu_type):
            return {"available": gpu_type in available_gpus}
        return fn

    def test_finds_first_available_neighbor(self):
        from cli.main import _bfs_gpu_fallback
        # H100 neighbors include H100_PCIE first; mark it available
        result = _bfs_gpu_fallback(
            "H100_80GB_SXM",
            min_vram=40.0,
            check_avail_fn=self._avail({"H100_80GB_PCIE"}),
        )
        assert result == "H100_80GB_PCIE"

    def test_skips_low_vram_neighbor(self):
        from cli.main import _bfs_gpu_fallback
        # A10G has 24GB — below the 40GB floor; A100_40GB has 40GB and is available
        result = _bfs_gpu_fallback(
            "A100_80GB_SXM",
            min_vram=40.0,
            check_avail_fn=self._avail({"A100_40GB"}),
        )
        assert result == "A100_40GB"

    def test_returns_none_when_all_unavailable(self):
        from cli.main import _bfs_gpu_fallback
        result = _bfs_gpu_fallback(
            "H100_80GB_SXM",
            min_vram=0.0,
            check_avail_fn=self._avail(set()),
        )
        assert result is None

    def test_explores_beyond_first_level(self):
        from cli.main import _bfs_gpu_fallback
        # H100_PCIE and H100_NVL are unavailable, but A100_80GB_SXM (their neighbor) is
        result = _bfs_gpu_fallback(
            "H100_80GB_SXM",
            min_vram=80.0,
            check_avail_fn=self._avail({"A100_80GB_SXM"}),
        )
        assert result == "A100_80GB_SXM"

    def test_vram_floor_40gb_excludes_a10g(self):
        from cli.main import _bfs_gpu_fallback, _GPU_VRAM_GB
        # A10G has 24GB — should be skipped with 40GB floor even if available
        assert _GPU_VRAM_GB["A10G"] < 40.0
        # Only A10G available, but VRAM too small
        result = _bfs_gpu_fallback(
            "A100_40GB",
            min_vram=40.0,
            check_avail_fn=self._avail({"A10G"}),
        )
        # A100_80GB_SXM (80GB) is in the chain but not marked available → None
        assert result is None

    def test_unknown_start_gpu_returns_none(self):
        from cli.main import _bfs_gpu_fallback
        result = _bfs_gpu_fallback(
            "NONEXISTENT_GPU",
            min_vram=0.0,
            check_avail_fn=self._avail({"A100_40GB"}),
        )
        # No chain entries for unknown GPU → no candidates
        assert result is None

    def test_zero_vram_floor_accepts_any(self):
        from cli.main import _bfs_gpu_fallback
        # With min_vram=0 any GPU passes the filter
        result = _bfs_gpu_fallback(
            "H100_80GB_SXM",
            min_vram=0.0,
            check_avail_fn=self._avail({"A10G"}),
        )
        assert result == "A10G"
