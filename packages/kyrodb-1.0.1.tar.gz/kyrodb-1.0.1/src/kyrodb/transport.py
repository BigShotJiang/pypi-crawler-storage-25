from __future__ import annotations

import hashlib
import ipaddress
import json
from collections.abc import AsyncIterator, Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from ._routes import ADMIN_PLANE, DATA_PLANE, OBSERVABILITY_PLANE
from .errors import (
    KyroDBAPIError,
    KyroDBAuthError,
    KyroDBConfigurationError,
    KyroDBDecodeError,
    KyroDBEvidenceError,
    KyroDBOverloadedError,
    KyroDBRateLimitError,
    KyroDBRedirectBlockedError,
    KyroDBResponseTooLargeError,
    KyroDBServerError,
    KyroDBTransportError,
    KyroDBValidationError,
)
from .models import JsonObject

DEFAULT_TIMEOUT_SECONDS = 10.0
DEFAULT_MAX_RESPONSE_BYTES = 16 * 1024 * 1024
DEFAULT_MAX_REQUEST_BYTES = 4 * 1024 * 1024
DEFAULT_USER_AGENT = "kyrodb-python/1.0.1"
MAX_SHADOW_SESSION_ID_BYTES = 96
MAX_ERROR_FIELD_BYTES = 1_024
PROTECTED_HEADERS = {
    "accept",
    "authorization",
    "content-type",
    "kyro-shadow-session-id",
    "user-agent",
}
EVIDENCE_ERROR_CODES = {
    "CAPTURE_EVIDENCE_UNHEALTHY",
    "CAPTURE_PERSISTENCE_FAILED",
    "FEEDBACK_EVIDENCE_UNHEALTHY",
    "FEEDBACK_PERSISTENCE_FAILED",
    "PLANNER_STATE_EVIDENCE_UNHEALTHY",
    "PLANNER_STATE_PERSISTENCE_FAILED",
    "REPLAY_CAPTURE_EVIDENCE_UNHEALTHY",
    "TRACE_EVIDENCE_UNHEALTHY",
    "TRACE_PERSISTENCE_FAILED",
}


@dataclass(frozen=True)
class TransportConfig:
    base_url: str
    data_plane_token: str
    observability_token: Optional[str] = None
    shadow_session_id: Optional[str] = None
    allow_insecure_http: bool = False
    allow_shared_tokens: bool = False
    timeout: float = DEFAULT_TIMEOUT_SECONDS
    max_response_bytes: int = DEFAULT_MAX_RESPONSE_BYTES
    max_request_bytes: int = DEFAULT_MAX_REQUEST_BYTES
    user_agent: str = DEFAULT_USER_AGENT


def validate_base_url(base_url: str, *, allow_insecure_http: bool) -> str:
    url = httpx.URL(base_url)
    if url.scheme not in {"http", "https"}:
        raise KyroDBConfigurationError("base_url must use http or https")
    if getattr(url, "userinfo", b""):
        raise KyroDBConfigurationError("base_url must not contain credentials")
    if url.query or url.fragment:
        raise KyroDBConfigurationError("base_url must not contain query strings or fragments")
    host = url.host
    if not host:
        raise KyroDBConfigurationError("base_url must include a host")
    if url.scheme == "http" and not allow_insecure_http and not _is_loopback_host(host):
        raise KyroDBConfigurationError(
            "plaintext HTTP is only allowed for loopback hosts unless "
            "allow_insecure_http=True is set explicitly"
        )
    return str(url).rstrip("/")


def validate_token(label: str, token: Optional[str]) -> Optional[str]:
    if token is None:
        return None
    if not token:
        raise KyroDBConfigurationError(f"{label} token must be non-empty")
    if token != token.strip():
        raise KyroDBConfigurationError(f"{label} token must not contain surrounding whitespace")
    if any(ord(character) <= 0x20 or ord(character) > 0x7E for character in token):
        raise KyroDBConfigurationError(
            f"{label} token must contain only non-whitespace printable ASCII characters"
        )
    return token


def validate_required_token(label: str, token: Optional[str]) -> str:
    validated = validate_token(label, token)
    if validated is None:
        raise KyroDBConfigurationError(f"{label} token is required")
    return validated


def validate_header_value(label: str, value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if not value:
        raise KyroDBConfigurationError(f"{label} must be non-empty")
    if value != value.strip():
        raise KyroDBConfigurationError(f"{label} must not contain surrounding whitespace")
    if any(ord(character) <= 0x20 or ord(character) > 0x7E for character in value):
        raise KyroDBConfigurationError(
            f"{label} must contain only non-whitespace printable ASCII characters"
        )
    return value


def validate_shadow_session_id(value: Optional[str]) -> Optional[str]:
    value = validate_header_value("kyro-shadow-session-id", value)
    if value is None:
        return None
    if len(value) > MAX_SHADOW_SESSION_ID_BYTES:
        raise KyroDBConfigurationError("kyro-shadow-session-id must be at most 96 bytes")
    if not all(
        character.isascii() and (character.isalnum() or character in "-_") for character in value
    ):
        raise KyroDBConfigurationError(
            "kyro-shadow-session-id must contain only ASCII letters, numbers, '-' or '_'"
        )
    return value


def _is_loopback_host(host: str) -> bool:
    if host in {"localhost", "localhost."}:
        return True
    try:
        return ipaddress.ip_address(host.strip("[]")).is_loopback
    except ValueError:
        return False


def _join_url(base_url: str, path: str) -> str:
    if not path.startswith("/"):
        raise KyroDBConfigurationError("route paths must be absolute")
    return f"{base_url}{path}"


class _BaseTransport:
    def __init__(self, config: TransportConfig) -> None:
        self._base_url = validate_base_url(
            config.base_url,
            allow_insecure_http=config.allow_insecure_http,
        )
        self._data_plane_token = validate_required_token("data-plane", config.data_plane_token)
        self._observability_token = validate_token("observability", config.observability_token)
        self._shadow_session_id = validate_shadow_session_id(config.shadow_session_id)
        if (
            self._observability_token is not None
            and self._observability_token == self._data_plane_token
            and not config.allow_shared_tokens
        ):
            raise KyroDBConfigurationError(
                "data-plane and observability tokens must be distinct unless "
                "allow_shared_tokens=True is set explicitly"
            )
        if config.timeout <= 0:
            raise KyroDBConfigurationError("timeout must be positive")
        if config.max_response_bytes <= 0:
            raise KyroDBConfigurationError("max_response_bytes must be positive")
        if config.max_request_bytes <= 0:
            raise KyroDBConfigurationError("max_request_bytes must be positive")
        self._timeout = config.timeout
        self._max_response_bytes = config.max_response_bytes
        self._max_request_bytes = config.max_request_bytes
        self._user_agent = config.user_agent

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def has_observability_token(self) -> bool:
        return self._observability_token is not None

    def require_observability_token(self) -> None:
        if self._observability_token is None:
            raise KyroDBConfigurationError(
                "observability_token is required before accessing observability or admin APIs"
            )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(base_url={self._base_url!r}, "
            "data_plane_token=<redacted>, observability_token=<redacted>)"
        )

    def _headers_for_plane(self, plane: str) -> dict[str, str]:
        token: Optional[str]
        if plane == DATA_PLANE:
            token = self._data_plane_token
        elif plane in {OBSERVABILITY_PLANE, ADMIN_PLANE}:
            token = self._observability_token
            if token is None:
                raise KyroDBConfigurationError(
                    "observability_token is required for observability and admin evidence APIs"
                )
        else:
            raise KyroDBConfigurationError(f"unknown KyroDB auth plane: {plane}")
        return {
            "accept": "application/json",
            "authorization": f"Bearer {token}",
            "user-agent": self._user_agent,
            **self._shadow_session_header(),
        }

    def _safe_transport_message(self, error: Exception) -> str:
        return _redact(str(error), self._sensitive_values())

    def _sensitive_values(self) -> tuple[str, ...]:
        return tuple(
            token
            for token in (
                self._data_plane_token,
                self._observability_token,
                self._shadow_session_id,
            )
            if token
        )

    def _shadow_session_header(self) -> dict[str, str]:
        if self._shadow_session_id is None:
            return {}
        return {"kyro-shadow-session-id": self._shadow_session_id}


class SyncKyroTransport(_BaseTransport):
    def __init__(
        self,
        config: TransportConfig,
        *,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(config)
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            timeout=self._timeout,
            follow_redirects=False,
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
        )

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def request_json(
        self,
        method: str,
        path: str,
        *,
        plane: str,
        json_payload: Optional[Mapping[str, Any]] = None,
        params: Optional[Mapping[str, Any]] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        headers = self._headers_for_plane(plane)
        if json_payload is not None:
            headers["content-type"] = "application/json"
        if extra_headers:
            _apply_extra_headers(headers, extra_headers)
        url = _join_url(self._base_url, path)
        body = _encode_json_payload(json_payload, self._max_request_bytes)
        try:
            with self._client.stream(
                method,
                url,
                headers=headers,
                params=_clean_params(params),
                content=body,
                timeout=self._timeout,
                follow_redirects=False,
            ) as response:
                if _is_redirect(response.status_code):
                    raise _redirect_error(response)
                body = _read_bounded(response.iter_bytes(), self._max_response_bytes)
                return _decode_or_raise(response, body, self._sensitive_values())
        except KyroDBTransportError:
            raise
        except httpx.TimeoutException as error:
            raise KyroDBTransportError(
                f"KyroDB request timed out: {self._safe_transport_message(error)}"
            ) from error
        except httpx.TransportError as error:
            raise KyroDBTransportError(
                f"KyroDB transport failed: {self._safe_transport_message(error)}"
            ) from error


class AsyncKyroTransport(_BaseTransport):
    def __init__(
        self,
        config: TransportConfig,
        *,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(config)
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=False,
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
        )

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def request_json(
        self,
        method: str,
        path: str,
        *,
        plane: str,
        json_payload: Optional[Mapping[str, Any]] = None,
        params: Optional[Mapping[str, Any]] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        headers = self._headers_for_plane(plane)
        if json_payload is not None:
            headers["content-type"] = "application/json"
        if extra_headers:
            _apply_extra_headers(headers, extra_headers)
        url = _join_url(self._base_url, path)
        body = _encode_json_payload(json_payload, self._max_request_bytes)
        try:
            async with self._client.stream(
                method,
                url,
                headers=headers,
                params=_clean_params(params),
                content=body,
                timeout=self._timeout,
                follow_redirects=False,
            ) as response:
                if _is_redirect(response.status_code):
                    raise _redirect_error(response)
                body = await _aread_bounded(response.aiter_bytes(), self._max_response_bytes)
                return _decode_or_raise(response, body, self._sensitive_values())
        except KyroDBTransportError:
            raise
        except httpx.TimeoutException as error:
            raise KyroDBTransportError(
                f"KyroDB request timed out: {self._safe_transport_message(error)}"
            ) from error
        except httpx.TransportError as error:
            raise KyroDBTransportError(
                f"KyroDB transport failed: {self._safe_transport_message(error)}"
            ) from error


def _clean_params(params: Optional[Mapping[str, Any]]) -> Optional[dict[str, Any]]:
    if not params:
        return None
    return {key: value for key, value in params.items() if value is not None}


def _apply_extra_headers(headers: dict[str, str], extra_headers: Mapping[str, str]) -> None:
    for key, value in extra_headers.items():
        normalized = key.lower()
        if normalized in PROTECTED_HEADERS:
            raise KyroDBConfigurationError(f"cannot override protected KyroDB header {key!r}")
        headers[key] = value


def _encode_json_payload(payload: Optional[Mapping[str, Any]], limit: int) -> Optional[bytes]:
    if payload is None:
        return None
    body = json.dumps(
        payload,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    if len(body) > limit:
        raise KyroDBValidationError(
            status_code=0,
            code="REQUEST_TOO_LARGE",
            message=f"KyroDB request exceeded configured limit of {limit} bytes",
            body_length=len(body),
            body_sha256=hashlib.sha256(body).hexdigest(),
        )
    return body


def _is_redirect(status_code: int) -> bool:
    return 300 <= status_code <= 399


def _redirect_error(response: httpx.Response) -> KyroDBRedirectBlockedError:
    return KyroDBRedirectBlockedError(
        f"KyroDB redirect blocked: status={response.status_code} location=<omitted-for-safety>"
    )


def _read_bounded(chunks: Iterable[bytes], limit: int) -> bytes:
    total = 0
    body = bytearray()
    for chunk in chunks:
        total += len(chunk)
        if total > limit:
            raise KyroDBResponseTooLargeError(
                f"KyroDB response exceeded configured limit of {limit} bytes"
            )
        body.extend(chunk)
    return bytes(body)


async def _aread_bounded(chunks: AsyncIterator[bytes], limit: int) -> bytes:
    total = 0
    body = bytearray()
    async for chunk in chunks:
        total += len(chunk)
        if total > limit:
            raise KyroDBResponseTooLargeError(
                f"KyroDB response exceeded configured limit of {limit} bytes"
            )
        body.extend(chunk)
    return bytes(body)


def _decode_or_raise(
    response: httpx.Response,
    body: bytes,
    sensitive_values: tuple[str, ...],
) -> Any:
    if response.status_code >= 400:
        raise _api_error(response, body, sensitive_values)
    if not body:
        return {}
    try:
        return _loads_strict_json(body)
    except ValueError as error:
        raise KyroDBDecodeError("KyroDB runtime returned invalid JSON") from error


def _api_error(
    response: httpx.Response,
    body: bytes,
    sensitive_values: tuple[str, ...],
) -> KyroDBAPIError:
    body_hash = hashlib.sha256(body).hexdigest() if body else None
    body_length = len(body)
    code = f"HTTP_{response.status_code}"
    message = f"KyroDB runtime returned HTTP {response.status_code}"
    acknowledged = None
    if body:
        try:
            payload = _loads_strict_json(body)
        except ValueError:
            payload = {}
        if isinstance(payload, dict):
            code = _public_error_field(payload.get("code"), code, sensitive_values)
            message = _public_error_field(payload.get("error"), message, sensitive_values)
            acknowledged_value = payload.get("acknowledged")
            if isinstance(acknowledged_value, bool):
                acknowledged = acknowledged_value
    retry_after = _redact_optional(response.headers.get("retry-after"), sensitive_values)
    request_id = _redact_optional(response.headers.get("x-request-id"), sensitive_values)
    kwargs: JsonObject = {
        "status_code": response.status_code,
        "code": code,
        "message": message,
        "acknowledged": acknowledged,
        "retry_after": retry_after,
        "request_id": request_id,
        "body_sha256": body_hash,
        "body_length": body_length,
    }
    if response.status_code in {401, 403}:
        return KyroDBAuthError(**kwargs)
    if response.status_code == 429:
        return KyroDBRateLimitError(**kwargs)
    if code in EVIDENCE_ERROR_CODES or code.endswith("_EVIDENCE_UNHEALTHY"):
        return KyroDBEvidenceError(**kwargs)
    if "OVERLOAD" in code:
        return KyroDBOverloadedError(**kwargs)
    if 400 <= response.status_code < 500:
        return KyroDBValidationError(**kwargs)
    if response.status_code >= 500:
        return KyroDBServerError(**kwargs)
    return KyroDBAPIError(**kwargs)


def _loads_strict_json(body: bytes) -> Any:
    return json.loads(body, parse_constant=_reject_json_constant)


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"invalid JSON constant {value}")


def _public_error_field(
    value: object,
    default: str,
    sensitive_values: tuple[str, ...],
) -> str:
    if not isinstance(value, str):
        return default
    if not value or len(value.encode("utf-8")) > MAX_ERROR_FIELD_BYTES:
        return default
    return _redact(value, sensitive_values)


def _redact(value: str, sensitive_values: tuple[str, ...]) -> str:
    redacted = value
    for sensitive in sensitive_values:
        redacted = redacted.replace(sensitive, "<redacted>")
    return redacted


def _redact_optional(value: Optional[str], sensitive_values: tuple[str, ...]) -> Optional[str]:
    if value is None:
        return None
    return _redact(value, sensitive_values)
