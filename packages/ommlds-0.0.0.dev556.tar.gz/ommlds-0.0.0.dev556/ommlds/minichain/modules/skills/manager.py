class SkillsManager:
    pass
