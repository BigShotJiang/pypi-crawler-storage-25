from __future__ import annotations

from django.utils.translation import gettext_lazy as _
from drf_spectacular.utils import extend_schema_view
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from core.api.serializers import ErrorResponseSerializer
from core.api.views import BaseModelViewSet

from core.utils.serializers import (
    ActionConfig,
    SerializersConfig,
    create_schema_view_config,
    crud_config,
)
from notification.filters import NotificationUserFilter
from notification.models.user import NotificationUser
from notification.serializers.user import (
    NotificationCountResponseSerializer,
    NotificationSuccessResponseSerializer,
    NotificationUserActionSerializer,
    NotificationUserDetailSerializer,
    NotificationUserSerializer,
    NotificationUserWriteSerializer,
)

serializers_config: SerializersConfig = {
    **crud_config(
        list=NotificationUserSerializer,
        detail=NotificationUserDetailSerializer,
        write=NotificationUserWriteSerializer,
    ),
    "unseen_count": ActionConfig(
        response=NotificationCountResponseSerializer,
        operation_id="getNotificationUserUnseenCount",
        summary=_("Get unseen notifications count"),
        description=_(
            "Get the count of unseen notifications for the authenticated user."
        ),
        tags=["Notification Users"],
    ),
    "mark_all_as_seen": ActionConfig(
        response=NotificationSuccessResponseSerializer,
        operation_id="markAllNotificationUsersAsSeen",
        summary=_("Mark all notifications as seen"),
        description=_(
            "Mark all of the authenticated user's notifications as seen."
        ),
        tags=["Notification Users"],
    ),
    "mark_all_as_unseen": ActionConfig(
        response=NotificationSuccessResponseSerializer,
        operation_id="markAllNotificationUsersAsUnseen",
        summary=_("Mark all notifications as unseen"),
        description=_(
            "Mark all of the authenticated user's notifications as unseen."
        ),
        tags=["Notification Users"],
    ),
    "mark_as_seen": ActionConfig(
        request=NotificationUserActionSerializer,
        response=NotificationSuccessResponseSerializer,
        operation_id="markNotificationUsersAsSeen",
        summary=_("Mark specific notifications as seen"),
        description=_(
            "Mark specific notifications as seen for the authenticated user."
        ),
        tags=["Notification Users"],
    ),
    "mark_as_unseen": ActionConfig(
        request=NotificationUserActionSerializer,
        response=NotificationSuccessResponseSerializer,
        operation_id="markNotificationUsersAsUnseen",
        summary=_("Mark specific notifications as unseen"),
        description=_(
            "Mark specific notifications as unseen for the authenticated user."
        ),
        tags=["Notification Users"],
    ),
}


@extend_schema_view(
    **create_schema_view_config(
        model_class=NotificationUser,
        display_config={
            "tag": "Notification Users",
        },
        serializers_config=serializers_config,
        error_serializer=ErrorResponseSerializer,
    )
)
class NotificationUserViewSet(BaseModelViewSet):
    queryset = NotificationUser.objects.for_list()
    serializers_config = serializers_config

    def get_permissions(self):
        return [IsAuthenticated()]

    def get_queryset(self):
        if self.request.user.is_staff:
            return super().get_queryset()
        return super().get_queryset().filter(user=self.request.user)

    filterset_class = NotificationUserFilter
    ordering_fields = [
        "id",
        "user",
        "user__email",
        "user__first_name",
        "user__last_name",
        "notification",
        "notification__kind",
        "notification__category",
        "notification__priority",
        "notification__created_at",
        "seen",
        "seen_at",
        "created_at",
        "updated_at",
    ]
    ordering = ["-created_at", "-notification__created_at"]
    search_fields = [
        "user__first_name",
        "user__last_name",
        "user__email",
        "user__username",
        "notification__translations__title",
        "notification__translations__message",
        "notification__notification_type",
        "notification__link",
    ]

    @action(detail=False, methods=["GET"])
    def unseen_count(self, request):
        if request.user.is_anonymous:
            return Response(
                {
                    "error": _("User is not authenticated."),
                    "count": 0,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        count = (
            self.get_queryset().filter(user=request.user, seen=False).count()
        )
        if count == 0:
            return Response(
                {
                    "count": 0,
                },
            )

        response_data = {"count": count}

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(response_data)
        return Response(response_serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["POST"])
    def mark_all_as_seen(self, request):
        if request.user.is_anonymous:
            return Response(
                {
                    "error": _("User is not authenticated."),
                    "success": False,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        self.get_queryset().filter(user=request.user, seen=False).update(
            seen=True
        )

        response_data = {"success": True}

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(response_data)
        return Response(response_serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["POST"])
    def mark_all_as_unseen(self, request):
        if request.user.is_anonymous:
            return Response(
                {
                    "error": _("User is not authenticated."),
                    "success": False,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        self.get_queryset().filter(user=request.user, seen=True).update(
            seen=False
        )

        response_data = {"success": True}

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(response_data)
        return Response(response_serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["POST"])
    def mark_as_seen(self, request):
        if request.user.is_anonymous:
            return Response(
                {
                    "error": _("User is not authenticated."),
                    "success": False,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        request_serializer_class = self.get_request_serializer()
        serializer = request_serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        notification_user_ids = serializer.validated_data.get(
            "notification_user_ids"
        )

        if not notification_user_ids:
            return Response(
                {
                    "error": _("No notification user ids provided."),
                    "success": False,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        self.get_queryset().filter(
            id__in=notification_user_ids, user=request.user
        ).update(seen=True)

        response_data = {"success": True}

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(response_data)
        return Response(response_serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["POST"])
    def mark_as_unseen(self, request):
        if request.user.is_anonymous:
            return Response(
                {
                    "error": _("User is not authenticated."),
                    "success": False,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        request_serializer_class = self.get_request_serializer()
        serializer = request_serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        notification_user_ids = serializer.validated_data.get(
            "notification_user_ids"
        )

        if not notification_user_ids:
            return Response(
                {
                    "error": _("No notification user ids provided."),
                    "success": False,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        self.get_queryset().filter(
            id__in=notification_user_ids, user=request.user
        ).update(seen=False)

        response_data = {"success": True}

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(response_data)
        return Response(response_serializer.data, status=status.HTTP_200_OK)
