import os
import httpx
from typing import List, Optional
from mcp.server.fastmcp import FastMCP

# Create the MCP server
mcp = FastMCP("Yellow Pages Scraper")

# Define the base Outscraper API endpoint for Yellow Pages
# For standard search it is usually https://api.app.outscraper.com/yellowpages-search
OUTSCRAPER_API_URL = "https://api.app.outscraper.com/yellowpages-search"

@mcp.tool()
async def search_yellow_pages(
    query: List[str],
    location: str = "New York, NY",
    limit: int = 500,
    region: Optional[str] = None,
    enrichment: Optional[List[str]] = None,
    fields: Optional[str] = None,
    outscraper_api_key: Optional[str] = None,
) -> str:
    """
    Search Yellow Pages via Outscraper.
    
    Args:
        query: Categories to search for (e.g., ["bars", "restaurants"]). Supports up to 1000 categories.
        location: The parameter specifies where to search.
        limit: The limit of items to get from one query.
        region: The country to use for website (e.g., US, UK, CA).
        enrichment: Data enrichments to apply (e.g., ["contacts_n_leads", "company_websites_finder"]). 
                   Note applying enrichments will increase response time.
        fields: Which fields to include with each item. E.g. "name,phone,website"
        outscraper_api_key: The API key for Outscraper. If not provided here, it will look for the OUTSCRAPER_API_KEY environment variable.
    """
    api_key = outscraper_api_key or os.environ.get("OUTSCRAPER_API_KEY")
    if not api_key:
        return "Error: Outscraper API key is required. Please provide it via the 'outscraper_api_key' parameter or 'OUTSCRAPER_API_KEY' environment variable."

    params = []
    
    # Add queries (multiple query parameters with the same name 'query')
    for q in query:
        params.append(("query", q))
        
    params.append(("location", location))
    params.append(("limit", str(limit)))
    
    # We enforce sync behavior because MCP tools should return data back directly 
    # (unless the client explicitly handles async Task IDs).
    params.append(("async", "false"))
    
    if region:
        params.append(("region", region))
        
    if enrichment:
        for e in enrichment:
            params.append(("enrichment", e))
            
    if fields:
        params.append(("fields", fields))

    headers = {
        "X-API-KEY": api_key,
        "Accept": "application/json"
    }

    try:
        # Given Outscraper's async results limit when sync is forced, we use a generous timeout
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.get(
                OUTSCRAPER_API_URL,
                params=params,
                headers=headers
            )
            response.raise_for_status()
            data = response.json()
            
            # The API usually wraps the results in a 'data' array. We can format it nicely
            import json
            return json.dumps(data, indent=2, ensure_ascii=False)
            
    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP Error {e.response.status_code}: {e.response.text}"
        return f"Error executing Yellow Pages search: {error_msg}"
    except Exception as e:
        return f"Error executing Yellow Pages search: {str(e)}"
        
    return "Error: Unexpected execution path."

def main():
    """Main entry point for running the server."""
    mcp.run()

if __name__ == "__main__":
    main()
