"""Pipeline orchestration: process_wish, run_loop, and supporting functions."""

import os, sys, json, time, subprocess, ast, shutil
from pathlib import Path
from checkpoint import (
    log, MCP_SOURCE_DIR, SAFE_WRITE_ROOT, WISHES_FILE, META_WISHES_FILE,
    MAX_ITERATIONS, DEBATE_ROUNDS, WATCH_INTERVAL, SCRIPTS_DIR,
    save_debate, record_wish, get_source_files, load_checkpoint, save_checkpoint,
    read_file_content, get_file_map, read_target_files, format_codebase_snapshot,
    track_metric, save_rejection_reason, load_rejection_reasons,
    save_meta_wish, load_locks, save_locks, claim_files, release_files,
    adaptive_debate_rounds, DRY_RUN,
)
from api_clients import call_minimax
from agents import (
    agent_proposer, agent_critic, agent_defender,
    agent_synthesizer, agent_judge, agent_auditor,
    extract_code_from_proposal,
)
from scout import scout_generate_wish, _try_architect_scout, convert_meta_wishes

# ── File utilities ────────────────────────────────────────────────────────
def syntax_check(content: str) -> tuple[bool, str]:
    """Returns (is_valid, error_message)."""
    try:
        ast.parse(content)
        return True, ""
    except SyntaxError as e:
        return False, f"line {e.lineno}: {e.msg}"


def syntax_check_file(path: Path) -> bool:
    try:
        ast.parse(path.read_text())
        return True
    except Exception:
        return False


# ── Layer 1: Import dependency verification ─────────────────────────────────────
# Fast, no-LLM checks that run after code is written but before git commit.
# Catches: ModuleNotFoundError, syntax errors in import chains, broken dependencies.

def find_dependent_files(target_module: str) -> list[Path]:
    """Find all files under MCP_SOURCE_DIR that import target_module.

    target_module example: "noesis.minimax_client" or "minimax_client"
    Strips 'noesis.' prefix to match bare module names in source.
    """
    # Normalize: "noesis.minimax_client" -> "minimax_client"
    bare = target_module.removeprefix("noesis.")
    patterns = [
        f"from {re.escape(bare)}",
        f"import {re.escape(bare)}",
    ]
    if bare != target_module:
        # Also search for qualified imports: from noesis.minimax_client
        patterns.extend([
            f"from {re.escape(target_module)}",
            f"import {re.escape(target_module)}",
        ])
    dependents = []
    for py_file in MCP_SOURCE_DIR.rglob("*.py"):
        try:
            text = py_file.read_text(errors="ignore")
            if any(re.search(p, text) for p in patterns):
                dependents.append(py_file)
        except Exception:
            pass
    return dependents


def check_imports(file_path: Path) -> tuple[bool, str]:
    """Check a Python file's imports resolve without ModuleNotFoundError.

    Returns (ok, error_message). Runs as subprocess with clean import environment.
    """
    parent_dir = file_path.parent
    module_name = file_path.stem
    if module_name != "__init__":
        cmd = [sys.executable, "-c", f"import sys; sys.path.insert(0,{str(parent_dir)!r}); exec(open({str(file_path)!r}).read())"]
    else:
        cmd = [sys.executable, "-c", f"import sys; sys.path.insert(0,{str(parent_dir.parent)!r}); import {parent_dir.name}"]

    try:
        r = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=15,
            cwd=str(parent_dir.parent),
        )
        if r.returncode == 0:
            return True, ""
        # Filter to only import-related errors
        err_lines = [l for l in r.stderr.splitlines() if "ModuleNotFoundError" in l or "ImportError" in l]
        if err_lines:
            return False, "; ".join(err_lines[:3])
        return False, r.stderr.splitlines()[0] if r.stderr else "unknown error"
    except subprocess.TimeoutExpired:
        return False, "import check timed out"
    except Exception as e:
        return False, str(e)


def run_pytest_for_module(file_path: Path) -> tuple[bool, str]:
    """Run pytest on file_path if tests exist nearby, else return (False, '').

    Looks for: same_dir/test_X.py, tests/ dir sibling, conftest.py nearby.
    Returns (ran, result_summary). ran=False means no tests found.
    """
    dir_path = file_path.parent
    stem = file_path.stem

    # Find test files that reference this module
    test_dirs = [
        dir_path / "tests",
        dir_path,
        MCP_SOURCE_DIR.parent / "tests",
        MCP_SOURCE_DIR.parent,
    ]
    pytest_args = []

    for td in test_dirs:
        if not td.exists():
            continue
        for pattern in [f"test_{stem}.py", f"*{stem}*test*.py", f"test_*.py"]:
            matches = list(td.glob(pattern))
            if matches:
                pytest_args.extend([str(m) for m in matches[:3]])

    if not pytest_args:
        # No specific tests found — try running all tests in the test dir
        # if this module is under a tests/ directory
        if (dir_path).name in ("tests", "test"):
            pytest_args = [str(dir_path)]

    if not pytest_args:
        return False, ""

    try:
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "--tb=short"] + pytest_args,
            capture_output=True, text=True, timeout=60,
            cwd=str(MCP_SOURCE_DIR.parent),
        )
        ok = r.returncode == 0
        summary = r.stdout.splitlines()
        last_lines = [l for l in summary if l.strip()]
        summary_text = last_lines[-1] if last_lines else r.stderr.splitlines()[0] if r.stderr else ""
        return ok, summary_text
    except subprocess.TimeoutExpired:
        return False, "pytest timed out"
    except Exception as e:
        return False, str(e)


# ── Git helpers ────────────────────────────────────────────────────────────────
def git_create_branch(branch_name: str, cwd: Path = None) -> bool:
    """Create and checkout a new git branch for wish isolation."""
    cwd = cwd or MCP_SOURCE_DIR
    try:
        subprocess.run(["git", "stash", "--quiet"], cwd=str(cwd), capture_output=True, timeout=10)
        r = subprocess.run(
            ["git", "checkout", "-b", branch_name],
            cwd=str(cwd), capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0:
            log(f"[GIT] branch creation failed: {r.stderr[:100]}")
            subprocess.run(["git", "stash", "pop", "--quiet"], cwd=str(cwd), capture_output=True, timeout=10)
            return False
        log(f"[GIT] created branch: {branch_name}")
        return True
    except Exception as e:
        log(f"[GIT] branch error: {e}")
        return False


def git_merge_branch(branch_name: str, cwd: Path = None) -> bool:
    """Merge wish branch back to main."""
    cwd = cwd or MCP_SOURCE_DIR
    try:
        subprocess.run(["git", "checkout", "main"], cwd=str(cwd), capture_output=True, timeout=10)
        r = subprocess.run(
            ["git", "merge", "--no-ff", "-m", f"Merge wish branch: {branch_name}", branch_name],
            cwd=str(cwd), capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0:
            log(f"[GIT] merge failed: {r.stderr[:100]}")
            subprocess.run(["git", "merge", "--abort"], cwd=str(cwd), capture_output=True, timeout=10)
            return False
        log(f"[GIT] merged: {branch_name} -> main")
        subprocess.run(["git", "branch", "-d", branch_name], cwd=str(cwd), capture_output=True, timeout=10)
        return True
    except Exception as e:
        log(f"[GIT] merge error: {e}")
        return False


def git_abandon_branch(branch_name: str, cwd: Path = None):
    """Abandon wish branch and return to main."""
    cwd = cwd or MCP_SOURCE_DIR
    try:
        subprocess.run(["git", "checkout", "main"], cwd=str(cwd), capture_output=True, timeout=10)
        subprocess.run(["git", "branch", "-D", branch_name], cwd=str(cwd), capture_output=True, timeout=10)
        subprocess.run(["git", "stash", "pop", "--quiet"], cwd=str(cwd), capture_output=True, timeout=10)
        log(f"[GIT] abandoned branch: {branch_name}")
    except Exception as e:
        log(f"[GIT] abandon error: {e}")


def git_cleanup_old_wish_branches(cwd: Path = None, keep: int = 10):
    """Remove old wish branches, keeping the most recent N."""
    cwd = cwd or MCP_SOURCE_DIR
    try:
        r = subprocess.run(
            ["git", "branch", "--list", "wish/*"],
            cwd=str(cwd), capture_output=True, text=True, timeout=10,
        )
        branches = [b.strip().replace("* ", "") for b in r.stdout.strip().split("\n") if b.strip()]
        if len(branches) > keep:
            for old_branch in branches[:-keep]:
                subprocess.run(["git", "branch", "-D", old_branch], cwd=str(cwd), capture_output=True, timeout=10)
    except Exception:
        pass


def git_commit(message: str, cwd: Path = None) -> bool:
    """Git add + commit. Returns True on success."""
    try:
        subprocess.run(["git", "add", "-A"], capture_output=True, cwd=cwd, timeout=10)
        r = subprocess.run(
            ["git", "commit", "-m", message],
            capture_output=True, text=True, cwd=cwd, timeout=10,
        )
        if r.returncode == 0:
            log(f"[GIT] committed: {message[:80]}")
            return True
        else:
            #"No changes" is ok
            if "nothing to commit" in r.stdout.lower():
                return True
            log(f"[GIT WARN] {r.stderr[:200]}")
            return False
    except Exception as e:
        log(f"[GIT ERROR] {e}")
        return False


def git_revert_last(cwd: Path = None) -> bool:
    """Reset --hard HEAD~1. Returns True on success."""
    try:
        r = subprocess.run(
            ["git", "reset", "--hard", "HEAD~1"],
            capture_output=True, text=True, cwd=cwd, timeout=15,
        )
        ok = r.returncode == 0
        log(f"[GIT] {'reverted' if ok else 'revert failed'}: {r.stderr[:100]}")
        return ok
    except Exception as e:
        log(f"[GIT ERROR] {e}")
        return False


# ── Service restart ────────────────────────────────────────────────────────────
def check_daemon_health() -> tuple[bool, dict]:
    """Verify the daemon process is healthy after code changes.

    Checks: syntax of all modules, imports resolve, no runtime errors.
    Returns (healthy: bool, details: dict).
    """
    modules = ["checkpoint", "api_clients", "prompts", "agents", "scout", "pipeline"]
    for mod in modules:
        mod_path = SCRIPTS_DIR / f"{mod}.py"
        if not mod_path.exists():
            log(f"[HEALTH] missing module: {mod_path}")
            return False, {"error": f"missing {mod}.py"}
        try:
            result = subprocess.run(
                [sys.executable, "-m", "py_compile", str(mod_path)],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode != 0:
                log(f"[HEALTH] syntax error in {mod}: {result.stderr[:200]}")
                return False, {"error": f"syntax error in {mod}"}
        except Exception as e:
            log(f"[HEALTH] check failed for {mod}: {e}")
            return False, {"error": str(e)}

    log("[HEALTH] all modules OK")
    return True, {"modules": len(modules)}


# ── Wish loader ────────────────────────────────────────────────────────────────


# ── Wish loader ───────────────────────────────────────────────────────────
def load_wishes(path: Path) -> list[str]:
    """Load wishes from a file, one per line. Skips empty/comment/bracket lines."""
    if not path.exists():
        log(f"[WISHES] {path} not found — creating template")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            "# wishes.txt — one wish per line, # for comments\n"
            "# Example:\n"
            "# Add a --verbose flag to the CLI\n"
            "# Add type hints to all functions in mcp_core.py\n"
            "# Refactor the memory.py session index to use an LRU cache\n"
        )
        return []
    wishes = []
    for line in path.read_text().splitlines():
        line = line.strip()
        # Skip empty lines, comment lines, and empty bracket notation
        if line and not line.startswith("#") and line not in ("[]", "[", "]"):
            wishes.append(line)
    log(f"[WISHES] loaded {len(wishes)} wishes from {path}")
    return wishes




# ── Pipeline: process_wish ────────────────────────────────────────────────
def process_wish(wish: str, wish_index: int, debate_round: int) -> tuple[bool, int, int]:
    """
    Process a single wish through the 5-agent debate.
    Returns (made_progress, new_debate_round, next_wish_index).
    Retries up to DEBATE_ROUNDS times on Judge rejection.
    
    Meta-wishes (wish.startswith("[META]")) use a short-circuit pipeline:
    Proposer → Critic → Judge → (save to meta_wish_approved.json) → advance
    Skips: Defender, Gate 1, Synthesizer, Gate 2, Gate 4
    """
    transcript = []  # Collect debate for transcript viewer
    log(f"\n{'='*60}")
    log(f"WISH [{wish_index}] (round {debate_round}/{DEBATE_ROUNDS}): {wish[:100]}")
    log(f"{'='*60}")

    is_meta = wish.startswith("[META]")

    # Retry loop: judge rejection → reprocess same wish with feedback
    for round_num in range(debate_round, DEBATE_ROUNDS):
        messages = []  # fresh conversation per attempt

        # ── Step 1: Proposer ───────────────────────────────────────────────
        log(f"[PROPOSER] drafting implementation (round {round_num+1})...")
        try:
            proposal_raw, _ = agent_proposer(wish, messages)
            transcript.append({"agent": "Proposer", "content": proposal_raw[:500]})
        except Exception as e:
            log(f"[ERROR] Proposer failed: {e}")
            return False, 0, wish_index + 1

        # Extract code blocks from the raw response
        code_blocks = extract_code_from_proposal(proposal_raw)

        # ── META-WISH PATH: no code blocks = MiniMax reasoning leak → extract prose
        if is_meta and not code_blocks:
            prose = proposal_raw
            # Strip reasoning prefix to get markdown body
            if "##" in proposal_raw:
                idx = proposal_raw.index("##")
                prose = proposal_raw[idx:]
            elif "\n\n" in prose and "##" not in prose:
                parts = prose.split("\n\n", 1)
                if len(parts) > 1:
                    prose = parts[1]
            log(f"[PROPOSER] 🧪 Meta-wish — treating prose as proposal ({len(prose)} chars)")
            code_blocks = [{"file": "PROPOSAL.md", "content": prose}]

        if not code_blocks:
            log(f"[PROPOSER] no code produced, skipping")
            log(f"[PROPOSER] response: {proposal_raw[:300]}...")
            return False, 0, wish_index + 1

        # ── Step 2: Critic ──────────────────────────────────────────────────
        log("[CRITIC] analyzing for flaws...")
        try:
            critique_raw, _ = agent_critic(proposal_raw, messages)
            transcript.append({"agent": "Critic", "content": critique_raw[:500]})
        except Exception as e:
            log(f"[ERROR] Critic failed: {e}")
            return False, 0, wish_index

        critique_lower = critique_raw.lower()
        is_approved = "verdict: approved" in critique_lower
        is_rejected = "verdict: rejected" in critique_lower
        severity = "medium"
        for line in critique_raw.splitlines():
            if "severity:" in line.lower():
                severity = line.lower().split("severity:")[-1].strip()

        log(f"[CRITIC] verdict: {'APPROVED' if is_approved else 'REJECTED' if is_rejected else 'UNCLEAR'} | severity: {severity}")

        # Update effective rounds based on current severity (captured once per round)
        effective_rounds = adaptive_debate_rounds(severity)

        # ── Gate 3: Hard stop on blocker ───────────────────────────────────────
        if is_rejected and "blocker" in severity.lower():
            reason = critique_raw
            log(f"[GATE 3] BLOCKER detected — stopping pipeline immediately")
            save_rejection_reason(wish, f"BLOCKER: {reason[:500]}")
            return False, 0, wish_index + 1  # advance to next wish (don't retry blocker)

        # ── META-WISH SHORT-CIRCUIT: Proposer → Critic → Judge (skip Defender/Gate1/Synthesizer/Gate2/Gate4)
        if is_meta:
            log("[JUDGE] 🧪 Meta-wish — short-circuit pipeline → Judge")
            try:
                verdict_raw, _ = agent_judge(proposal_raw, proposal_raw, messages, severity=severity)
            except Exception as e:
                log(f"[ERROR] Judge failed: {e}")
                return False, 0, wish_index

            verdict_lower = verdict_raw.lower()
            judge_approved = "verdict: approved" in verdict_lower
            log(f"[JUDGE] {verdict_raw[:200]}")

            if not judge_approved:
                effective_rounds = adaptive_debate_rounds(severity)
                if round_num < effective_rounds - 1:
                    log(f"[JUDGE] REJECTED — retrying round {round_num + 2}/{effective_rounds} (severity={severity})")
                    continue  # retry same wish in next loop iteration
                else:
                    log(f"[JUDGE] REJECTED after {effective_rounds} rounds — giving up (severity={severity})")
                    return False, 0, wish_index + 1

            # Judge approved — save meta-wish and advance
            track_metric("wish_approved")
            log(f"[JUDGE] 🧪 APPROVED meta-wish → saving to {META_WISHES_FILE}")
            save_meta_wish(wish, proposal_raw)
            return True, 0, wish_index + 1

        # ── REGULAR WISH PIPELINE ──────────────────────────────────────────────

        # If Critic approves immediately, skip to Judge
        if is_approved:
            synthesis_raw = proposal_raw
        else:
            # ── Step 3: Defender ──────────────────────────────────────────────
            log("[DEFENDER] formulating rebuttals...")
            try:
                defense_raw, _ = agent_defender(proposal_raw, critique_raw, messages)
                transcript.append({"agent": "Defender", "content": defense_raw[:500]})
            except Exception as e:
                log(f"[ERROR] Defender failed: {e}")
                return False, 0, wish_index

            # Extract updated code from defender
            updated_blocks = extract_code_from_proposal(defense_raw)

            # ── Gate 1: Defender stub / concession check ─────────────────────
            defense_lower = defense_raw.lower().strip()
            is_concession = (
                "file: none" in defense_lower
                or defense_lower.startswith("no ")
                or "cannot be fixed" in defense_lower
                or "fundamental" in defense_lower
            )
            is_stub = (
                (updated_blocks and len(updated_blocks) > 0 and len(updated_blocks[0].get("content", "")) < 200)
                or (not updated_blocks and len(defense_raw) < 200)
            )
            if is_concession or is_stub:
                reason = f"Defender {'conceded' if is_concession else 'produced stub'} (severity={severity})"
                log(f"[GATE 1] REJECTED: {reason}")
                save_rejection_reason(wish, reason)
                return False, 0, wish_index

            if updated_blocks:
                code_blocks = updated_blocks
                log(f"[DEFENDER] updated code: {[c['file'] for c in updated_blocks]}")

            # ── Step 4: Synthesizer ───────────────────────────────────────────
            log("[SYNTHESIZER] writing final plan...")
            try:
                synthesis_raw, _ = agent_synthesizer(proposal_raw, defense_raw, messages)
                transcript.append({"agent": "Synthesizer", "content": synthesis_raw[:500]})
            except Exception as e:
                log(f"[ERROR] Synthesizer failed: {e}")
                return False, 0, wish_index

            updated_blocks = extract_code_from_proposal(synthesis_raw)
            if updated_blocks:
                code_blocks = updated_blocks
                log(f"[SYNTHESIZER] final code: {[c['file'] for c in updated_blocks]}")

        # ── Gate 2: Pre-Judge synthesis stub check ─────────────────────────
        # Only applies when Critic rejected (went through Defender/Synthesizer).
        # If Critic approved immediately, we skip to Judge without synthesis gate.
        if not is_approved:
            if not synthesis_raw or len(synthesis_raw.strip()) < 200:
                log(f"[GATE 2] REJECTED: synthesis is a stub ({len(synthesis_raw) if synthesis_raw else 0} chars) — not calling Judge")
                save_rejection_reason(wish, f"Gate 2: synthesis stub ({len(synthesis_raw) if synthesis_raw else 0} chars)")
                return False, 0, wish_index

        # ── Step 5: Judge ───────────────────────────────────────────────────
        log("[JUDGE] passing verdict...")
        try:
            verdict_raw, _ = agent_judge(proposal_raw, synthesis_raw, messages, severity=severity)
        except Exception as e:
            log(f"[ERROR] Judge failed: {e}")
            return False, 0, wish_index

        verdict_lower = verdict_raw.lower()
        judge_approved = "verdict: approved" in verdict_lower

        log(f"[JUDGE] {verdict_raw[:200]}")

        if not judge_approved:
            effective_rounds = adaptive_debate_rounds(severity)
            if round_num < effective_rounds - 1:
                log(f"[JUDGE] REJECTED — retrying round {round_num + 2}/{effective_rounds} (severity={severity})")
                continue  # retry same wish in next loop iteration
            else:
                log(f"[JUDGE] REJECTED after {effective_rounds} rounds — giving up (severity={severity})")
                return False, 0, wish_index + 1  # move to next wish

        # ── Gate 4: Auditor — logic/runtime correctness check (LLM-powered) ─────
        # Skip for .md meta-proposals (meta-wishes already handled above)
        # and low-severity changes (light touch)
        py_blocks = [b for b in code_blocks if not b["file"].endswith(".md")]
        if py_blocks and severity != "low":
            for block in py_blocks:
                filename = block["file"].strip()
                patched_content = block["content"]

                # Resolve the original file path
                original = MCP_SOURCE_DIR / filename
                if not original.exists():
                    original = MCP_SOURCE_DIR.parent / filename

                if original.exists() and original.suffix == ".py":
                    log(f"[AUDITOR] reviewing logic/runtime for {filename}...")
                    try:
                        auditor_raw, _ = agent_auditor(original, patched_content, wish, severity=severity)
                    except Exception as e:
                        log(f"[ERROR] Auditor failed: {e}, skipping Gate 4")
                        auditor_raw = ""

                    log(f"[AUDITOR] {auditor_raw[:200]}")
                    auditor_approved = "verdict: approved" in auditor_raw.lower()

                    if not auditor_approved:
                        # Consume one debate round like Judge rejection would
                        if round_num < effective_rounds - 1:
                            log(f"[GATE 4] REJECTED — Auditor found concerns, retrying round {round_num + 2}/{effective_rounds}")
                            continue  # retry same wish in next loop iteration
                        else:
                            log(f"[GATE 4] REJECTED after {effective_rounds} rounds — giving up (severity={severity})")
                            save_rejection_reason(wish, f"Gate 4: Auditor rejected — {auditor_raw[:100]}")
                            return False, 0, wish_index + 1

        # ── Step 6: Validate + Write ─────────────────────────────────────────
        log(f"[IMPLEMENTER] validating {len(code_blocks)} file(s)...")

        # Create wish branch for isolation
        import hashlib as _hashlib
        wish_hash = _hashlib.md5(wish.encode()).hexdigest()[:8]
        wish_branch = f"wish/{wish_hash}"
        git_create_branch(wish_branch, cwd=MCP_SOURCE_DIR)

        written = []
        for block in code_blocks:
            filename = block["file"].strip()
            content = block["content"]

            # Validate AST before writing (skip for .md meta-proposals)
            if filename.endswith('.md'):
                log(f"[IMPLEMENTER] 🧪 skipping AST check for {filename}")
            else:
                valid, err = syntax_check(content)
                if not valid:
                    log(f"[IMPLEMENTER] ❌ {filename} has syntax error: {err}")
                    git_revert_last(cwd=MCP_SOURCE_DIR)
                    return False, 0, wish_index

            # Write file — with path validation to prevent traversal
            target = validate_write_path(filename)
            if target is None:
                log(f"[IMPLEMENTER] ❌ {filename} rejected: path escapes project directory")
                git_abandon_branch(wish_branch, cwd=MCP_SOURCE_DIR)
                return False, 0, wish_index
            target.parent.mkdir(parents=True, exist_ok=True)
            # Atomic write: temp + fsync + rename
            tmp = target.with_suffix(target.suffix + ".tmp")
            with open(tmp, "w") as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
            tmp.rename(target)
            written.append(filename)
            log(f"[IMPLEMENTER] ✓ wrote {filename}")

        # ── Layer 1 checks: import/dep/pytest after write, before restart ─────────
        layer1_passed = True
        for filename in written:
            if filename.endswith('.md') or filename.endswith('.txt'):
                continue
            fpath = MCP_SOURCE_DIR / filename
            if not fpath.exists():
                fpath = MCP_SOURCE_DIR.parent / filename
            if not fpath.exists() or not fpath.suffix == '.py':
                continue
            # Check imports
            ok, err = check_imports(str(fpath))
            if not ok:
                track_metric("layer1_failed")
                log(f"[LAYER 1] ❌ {filename}: import error — reverting")
                git_revert_last(cwd=MCP_SOURCE_DIR)
                return False, 0, wish_index
            # Find and run dependent tests
            deps = find_dependent_files(fpath.name)
            for dep in deps:
                if dep.endswith('.py') and '_test' in dep:
                    t_ok, t_err = run_pytest_for_module(dep)
                    if not t_ok:
                        log(f"[LAYER 1] ❌ test {dep} failed — reverting")
                        git_revert_last(cwd=MCP_SOURCE_DIR)
                        return False, 0, wish_index

        # Verify module health after write — rollback if broken
        if DRY_RUN:
            log("[DRY-RUN] Skipping health check")
        else:
            log("[IMPLEMENTER] verifying module health...")
            health_ok, health_data = check_daemon_health()
            if not health_ok:
                log(f"[IMPLEMENTER] ❌ health check failed: {health_data} — reverting")
                git_revert_last(cwd=MCP_SOURCE_DIR)
                return False, 0, wish_index

        # Save debate transcript
        if transcript:
            save_debate(wish, transcript)
            record_wish(wish, "applied")

        # Merge wish branch back to main
        git_merge_branch(wish_branch, cwd=MCP_SOURCE_DIR)
        git_cleanup_old_wish_branches(cwd=MCP_SOURCE_DIR)

        # Mark as applied
        log(f"[IMPLEMENTER] ✅ Wish applied: {wish[:80]}")
        return True, 0, wish_index + 1  # advance to next wish

    # Should never reach here, but safety net
    return False, 0, wish_index + 1



def run_loop(watch: bool = False, resume: bool = False) -> None:
    cp = load_checkpoint()
    iterations = cp.get("iterations", 0)
    applied = cp.get("applied_patches", [])
    wish_index = cp.get("wish_index", 0)
    debate_round = cp.get("debate_round", 0)
    done = cp.get("done", False)
    
    wishes = load_wishes(WISHES_FILE)

    log(f"Starting: wish_index={wish_index}/{len(wishes)}, applied={len(applied)}, "
        f"debate_round={debate_round}, iterations={iterations}/{MAX_ITERATIONS})")

    # Try Architect-Scout first (fires once per hour, only when queue is empty)
    if not wishes:
        arch_wish = _try_architect_scout()
        if arch_wish:
            log(f"  [Architect] Wish generated: {arch_wish}")
            with open(WISHES_FILE, "a") as f:
                f.write(arch_wish + "\n")
            wishes = load_wishes(WISHES_FILE)
            log(f"  [Architect] Appended to queue ({len(wishes)} wishes)")
        else:
            log("No wishes found. Scout is hunting...")
            scout_wish = scout_generate_wish()
            if scout_wish:
                log(f"  [Scout] Found: {scout_wish}")
                with open(WISHES_FILE, "a") as f:
                    f.write(scout_wish + "\n")
                wishes = load_wishes(WISHES_FILE)
                log(f"  [Scout] Appended to queue ({len(wishes)} wishes)")
            else:
                log("  [Scout] Nothing found. Sleeping...")
                time.sleep(WATCH_INTERVAL)
                return cp
            return cp

    while not done and iterations < MAX_ITERATIONS:
        # Guard: if we've exhausted all wishes, let Scout hunt
        if wish_index >= len(wishes):
            log(f"\n=== OUT OF WISHES — Architect/Scout taking over ===")
            # Convert approved meta-wishes into concrete code wishes
            converted = convert_meta_wishes()
            if converted:
                wishes = load_wishes(WISHES_FILE)
                if wishes:
                    log(f"  [Convert] {len(converted)} meta-wishes converted to concrete wishes")
                    wish_index = 0
                    debate_round = 0
                    continue

            # Try Architect first
            arch_wish = _try_architect_scout()
            if arch_wish:
                log(f"  [Architect] Wish generated: {arch_wish}")
                with open(WISHES_FILE, "a") as f:
                    f.write(arch_wish + "\n")
                wishes = load_wishes(WISHES_FILE)
                wish_index = len(wishes) - 1
                debate_round = 0
                cp["wish_index"] = 0
                cp["debate_round"] = 0
                cp["done"] = False
                cp["iterations"] = 0  # Reset counter so new cycle has full budget
                save_checkpoint(cp)
                time.sleep(2)
                continue
            # Fall back to Scout
            scout_wish = scout_generate_wish()
            if scout_wish:
                log(f"  [Scout] Found: {scout_wish}")
                with open(WISHES_FILE, "a") as f:
                    f.write(scout_wish + "\n")
                wishes = load_wishes(WISHES_FILE)
                wish_index = 0
                debate_round = 0
                # Update checkpoint: reset wish_index and clear done flag so
                # a restarted instance starts fresh rather than re-running Scout
                cp["wish_index"] = 0
                cp["debate_round"] = 0
                cp["done"] = False
                cp["iterations"] = 0  # Reset counter so new cycle has full budget
                save_checkpoint(cp)
                time.sleep(2)
                continue
            else:
                log("  [Scout] Nothing found. Sleeping until next cycle...")
                time.sleep(WATCH_INTERVAL)
                # Don't set done=True — let watch-mode handle the restart naturally
                # without creating a restart loop with the same checkpoint
                return cp

        wish = wishes[wish_index]
        
        # Guard: skip empty wish strings
        if not wish or not wish.strip():
            log(f"[WARN] empty wish at index {wish_index}, advancing")
            wish_index += 1
            cp["wish_index"] = wish_index
            save_checkpoint(cp)
            time.sleep(1)
            continue
        
        made_progress, new_round, next_idx = process_wish(wish, wish_index, debate_round)
        
        debate_round = new_round
        iterations += 1
        
        if made_progress:
            applied.append(wish[:80])
            wish_index = next_idx
            debate_round = 0  # reset for next wish
            cp["wish_index"] = wish_index
            cp["applied_patches"] = applied
        else:
            if debate_round == 0:
                # Fully rejected — move to next wish
                wish_index = next_idx
                cp["wish_index"] = wish_index
            # else retry same wish with updated round
        
        cp["iterations"] = iterations
        cp["debate_round"] = debate_round
        save_checkpoint(cp)
        
        # Handle iteration cap
        # Handle iteration cap: reset counter on meaningful progress,
        # but don't set done=True — that prevents architect wishes from being processed
        if iterations >= MAX_ITERATIONS - 2:
            if made_progress:
                log(f"Near cap ({iterations}/{MAX_ITERATIONS}) — resetting counter on progress")
                iterations = 0
                cp["iterations"] = iterations
                save_checkpoint(cp)
            else:
                log(f"Near cap ({iterations}/{MAX_ITERATIONS}) — pausing to let Architect/Scout refill queue")
                done = True
        
        time.sleep(2)
    
    cp["done"] = done
    cp["iterations"] = iterations
    save_checkpoint(cp)
    
    log(f"\n=== LOOP DONE (iterations={iterations}, wishes_done={wish_index}/{len(wishes)}) ===")
    log(f"Applied: {len(applied)}")
    for w in applied:
        log(f"  - {w}")
    
    # Never wipe wishes.txt — it destroys architect-generated wishes
    # that haven't been processed yet, causing restart loops.

    if watch:
        log("Watch mode: restarting loop...")
        time.sleep(5)
        run_loop(watch=True, resume=True)
    
    return cp




__all__ = ['process_wish', 'run_loop', 'load_wishes']
