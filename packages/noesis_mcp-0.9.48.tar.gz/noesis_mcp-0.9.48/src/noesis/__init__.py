"""Noesis — self-improving AI agent framework with autonomous code refinement."""

__version__ = "0.9.48"

__all__ = [
    "__version__",
    "bind_correlation_id",
    "configure_logging",
    "get_correlation_id",
    "logger",
    "new_correlation_id",
    "set_correlation_id",
]

from .logging_config import (
    bind_correlation_id,
    configure_logging,
    get_correlation_id,
    logger,
    new_correlation_id,
    set_correlation_id,
)
