# amt_augmentor/__init__.py
__version__ = "1.2.0"
