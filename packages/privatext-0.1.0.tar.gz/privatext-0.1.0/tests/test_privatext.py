"""Unit tests for PrivaText module."""

import unittest
from privatext import PrivaText


class TestPrivaTextConfig(unittest.TestCase):
    """Test configuration functionality."""
    
    def test_default_config(self):
        """Test default configuration values."""
        pt = PrivaText()
        self.assertTrue(pt.config['phone'])
        self.assertTrue(pt.config['email'])
        self.assertTrue(pt.config['id_card'])
        self.assertFalse(pt.config['address'])
        self.assertTrue(pt.config['secret_key'])
        self.assertFalse(pt.config['custom_tag_only'])
    
    def test_update_config_single(self):
        """Test updating a single config item."""
        pt = PrivaText()
        pt.config['email'] = False
        self.assertFalse(pt.config['email'])
        self.assertTrue(pt.config['phone'])  # Other items unchanged
    
    def test_update_config_batch(self):
        """Test batch updating multiple config items."""
        pt = PrivaText()
        pt.update_config({
            'email': False,
            'address': True,
            'phone': False
        })
        self.assertFalse(pt.config['email'])
        self.assertTrue(pt.config['address'])
        self.assertFalse(pt.config['phone'])
        self.assertTrue(pt.config['id_card'])  # Unchanged
    
    def test_invalid_config_key(self):
        """Test that invalid config keys raise error."""
        pt = PrivaText()
        with self.assertRaises(ValueError):
            pt.update_config({'invalid_key': True})


class TestPrivaTextMasking(unittest.TestCase):
    """Test masking functionality."""
    
    def test_mask_phone(self):
        """Test phone number masking."""
        pt = PrivaText()
        text = "拨打13800138000联系我"
        masked = pt.mask(text)
        self.assertIn('__PRIV_PHONE_', masked)
        self.assertNotIn('13800138000', masked)
        self.assertEqual(pt.vault['__PRIV_PHONE_1__'], '13800138000')
    
    def test_mask_email(self):
        """Test email masking."""
        pt = PrivaText()
        text = "发邮件到 test@example.com"
        masked = pt.mask(text)
        self.assertIn('__PRIV_EMAIL_', masked)
        self.assertNotIn('test@example.com', masked)
    
    def test_mask_id_card(self):
        """Test ID card number masking."""
        pt = PrivaText()
        text = "身份证号是110101199003076019"
        masked = pt.mask(text)
        self.assertIn('__PRIV_ID_CARD_', masked)
        self.assertNotIn('110101199003076019', masked)
    
    def test_mask_manual_tags(self):
        """Test manual marking with [[[ ]]] has priority."""
        pt = PrivaText()
        text = "我的暗号是 [[[天王盖地虎]]]"
        masked = pt.mask(text)
        self.assertIn('__PRIV_CUSTOM_1__', masked)
        self.assertNotIn('天王盖地虎', masked)
        self.assertEqual(pt.vault['__PRIV_CUSTOM_1__'], '[[[天王盖地虎]]]')
    
    def test_manual_tags_priority_over_auto(self):
        """Test that manually marked content is not auto-detected."""
        pt = PrivaText()
        # Email inside manual tags should not be double-masked
        text = "My secret is [[[admin@secret.com]]]"
        masked = pt.mask(text)
        # Should have only one placeholder for the manual tag
        placeholder_count = masked.count('__PRIV_')
        self.assertEqual(placeholder_count, 1)
        self.assertEqual(pt.vault['__PRIV_CUSTOM_1__'], '[[[admin@secret.com]]]')
    
    def test_multiple_masking_same_text(self):
        """Test masking multiple instances in same text."""
        pt = PrivaText()
        text = "拨打13800138000或15900009999"
        masked = pt.mask(text)
        self.assertIn('__PRIV_PHONE_1__', masked)
        self.assertIn('__PRIV_PHONE_2__', masked)
        self.assertEqual(len(pt.vault), 2)
    
    def test_escaped_tags(self):
        """Test that escaped [[[ is not treated as manual tag."""
        pt = PrivaText()
        text = r"Code example: \[\[\[secret\]\]\]"
        masked = pt.mask(text)
        # Should not have any placeholders if only escape sequence present
        self.assertIn('[[[secret]]]', masked)  # Unescape should restore
    
    def test_config_affects_masking(self):
        """Test that config settings affect what gets masked."""
        pt = PrivaText()
        pt.config['email'] = False
        text = "拨打13800138000，或者发邮件到 test@me.com"
        masked = pt.mask(text)
        
        # Phone should be masked
        self.assertIn('__PRIV_PHONE_', masked)
        self.assertNotIn('13800138000', masked)
        
        # Email should NOT be masked
        self.assertIn('test@me.com', masked)
    
    def test_custom_tag_only_mode(self):
        """Test custom_tag_only mode - only manual tags are masked."""
        pt = PrivaText()
        pt.config['custom_tag_only'] = True
        text = "拨打13800138000，暗号 [[[天王盖地虎]]]"
        masked = pt.mask(text)
        
        # Phone should NOT be masked
        self.assertIn('13800138000', masked)
        
        # Manual tag SHOULD be masked
        self.assertIn('__PRIV_CUSTOM_1__', masked)
        self.assertNotIn('天王盖地虎', masked)


class TestPrivaTextUnmasking(unittest.TestCase):
    """Test unmasking functionality."""
    
    def test_unmask_single_placeholder(self):
        """Test unmasking a single placeholder."""
        pt = PrivaText()
        text = "拨打13800138000联系我"
        masked = pt.mask(text)
        unmasked = pt.unmask(masked)
        self.assertEqual(unmasked, text)
    
    def test_unmask_multiple_placeholders(self):
        """Test unmasking multiple placeholders."""
        pt = PrivaText()
        text = "拨打13800138000或15900009999，邮件test@example.com"
        masked = pt.mask(text)
        unmasked = pt.unmask(masked)
        self.assertEqual(unmasked, text)
    
    def test_unmask_case_insensitive(self):
        """Test that unmask handles case variations (LLM might change case)."""
        pt = PrivaText()
        text = "拨打13800138000联系我"
        masked = pt.mask(text)
        
        # Simulate LLM changing placeholder case
        modified = masked.lower()
        unmasked = pt.unmask(modified)
        # Should still restore correctly
        self.assertNotIn('__priv_', unmasked)  # Original should be restored
        self.assertIn('138', unmasked)  # Some part of the phone should be there
    
    def test_unmask_with_manual_tags(self):
        """Test unmasking manually tagged content."""
        pt = PrivaText()
        text = "我的暗号是 [[[天王盖地虎]]]"
        masked = pt.mask(text)
        unmasked = pt.unmask(masked)
        self.assertEqual(unmasked, text)
    
    def test_unmask_preserves_context(self):
        """Test that unmasking preserves surrounding context."""
        pt = PrivaText()
        text = "请拨打13800138000，这很重要"
        masked = pt.mask(text)
        unmasked = pt.unmask(masked)
        self.assertEqual(unmasked, text)
        self.assertIn('请', unmasked)
        self.assertIn('这很重要', unmasked)


class TestPrivaTextVault(unittest.TestCase):
    """Test vault functionality."""
    
    def test_vault_initialization(self):
        """Test vault starts empty."""
        pt = PrivaText()
        self.assertEqual(len(pt.vault), 0)
    
    def test_vault_after_masking(self):
        """Test vault contains correct mappings after masking."""
        pt = PrivaText()
        text = "拨打13800138000，邮件test@example.com"
        pt.mask(text)
        
        self.assertEqual(len(pt.vault), 2)
        self.assertEqual(pt.vault['__PRIV_PHONE_1__'], '13800138000')
        self.assertEqual(pt.vault['__PRIV_EMAIL_1__'], 'test@example.com')
    
    def test_get_vault(self):
        """Test get_vault returns a copy, not reference."""
        pt = PrivaText()
        pt.mask("拨打13800138000")
        
        vault_copy = pt.get_vault()
        vault_copy['__PRIV_PHONE_1__'] = 'modified'
        
        # Original vault should be unchanged
        self.assertEqual(pt.vault['__PRIV_PHONE_1__'], '13800138000')
    
    def test_vault_clears_on_new_mask(self):
        """Test vault is cleared when masking new text."""
        pt = PrivaText()
        pt.mask("拨打13800138000")
        self.assertEqual(len(pt.vault), 1)
        
        pt.mask("拨打15900009999")  # New mask operation
        self.assertEqual(len(pt.vault), 1)  # Old entry should be gone
        self.assertIn('__PRIV_PHONE_1__', pt.vault)
        self.assertNotIn('13800138000', pt.vault.values())


class TestPrivaTextIntegration(unittest.TestCase):
    """Integration tests for complete workflows."""
    
    def test_example_usage_from_readme(self):
        """Test the example from README works correctly."""
        pt = PrivaText()
        
        # Modify config: disable email, enable address
        pt.config['email'] = False
        pt.config['address'] = True
        
        raw_text = "拨打13800138000，或者发邮件到 test@me.com，我的暗号是 [[[天王盖地虎]]]"
        masked = pt.mask(raw_text)
        
        # Phone should be masked
        self.assertNotIn('13800138000', masked)
        self.assertIn('__PRIV_PHONE_', masked)
        
        # Custom tag should be masked
        self.assertNotIn('天王盖地虎', masked)
        self.assertIn('__PRIV_CUSTOM_', masked)
        
        # Email should NOT be masked (config disabled it)
        self.assertIn('test@me.com', masked)
        
        # Get vault
        vault = pt.get_vault()
        self.assertGreaterEqual(len(vault), 2)  # At least phone and custom tag
    
    def test_roundtrip_mask_unmask(self):
        """Test complete mask->unmask roundtrip."""
        pt = PrivaText()
        original = "Call 13800138000 or email test@example.com. Secret: [[[password123]]]"
        
        masked = pt.mask(original)
        unmasked = pt.unmask(masked)
        
        self.assertEqual(unmasked, original)
        self.assertNotEqual(masked, original)
        # Placeholders should appear in masked version
        self.assertIn('__PRIV_', masked)
    
    def test_multiple_instances_same_type(self):
        """Test handling multiple instances of same PII type."""
        pt = PrivaText()
        text = "联系方式：13800138000 或 13900009999 或 15800008888"
        masked = pt.mask(text)
        
        self.assertIn('__PRIV_PHONE_1__', masked)
        self.assertIn('__PRIV_PHONE_2__', masked)
        self.assertIn('__PRIV_PHONE_3__', masked)
        
        unmasked = pt.unmask(masked)
        self.assertEqual(unmasked, text)


if __name__ == '__main__':
    unittest.main()
