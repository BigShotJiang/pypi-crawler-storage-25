"""Tests for PrivaText package."""
