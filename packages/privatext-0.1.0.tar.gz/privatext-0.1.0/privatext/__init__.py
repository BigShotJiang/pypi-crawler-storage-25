"""PrivaText - Privacy text masking and unmasking tool."""

from .core import PrivaText

__version__ = "0.1.0"
__author__ = "PrivaText Team"
__all__ = ["PrivaText"]
