"""
PrivaText - Privacy text masking and unmasking tool.
Automatically or manually redact personally identifiable information (PII) before sending to LLMs,
and restore after receiving responses.
"""

import re
from typing import Dict, Optional, Any
from copy import deepcopy


class PrivaText:
    """
    Tool for masking and unmasking personally identifiable information (PII) in text.
    
    Attributes:
        vault: Dictionary storing {placeholder: original_value} mappings
        config: Configuration dict for enabling/disabling PII type detection
        patterns: Regular expression patterns for different PII types
    """
    
    def __init__(self):
        """Initialize PrivaText with default configuration and patterns."""
        self.vault: Dict[str, str] = {}
        
        # Default configuration
        self.config = {
            'phone': True,           # Chinese phone number recognition
            'email': True,           # Email pattern
            'id_card': True,         # ID card number
            'address': False,        # Address pattern (disabled by default, hard to match accurately)
            'secret_key': True,      # API Key/Token pattern
            'custom_tag_only': False # Only recognize manually marked [[[ ]]] content
        }
        
        # Regular expression patterns for different PII types
        self.patterns = {
            # 扩展后的手机号正则
            'phone': r'(?:\+?86)?(?:\s?|[-ー]?)1[3-9]\d{9}|(?:\+1|001)?(?:\s?|[-ー]?)?\(?\d{3}\)?(?:\s?|[-ー]?)\d{3}(?:\s?|[-ー]?)\d{4}',
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # Email pattern
            'id_card': r'(?<!\d)(?:\d{15}|\d{18}|\d{17}[0-9Xx])(?!\d)|[A-Z][0-9]{6}\([0-9A]\)|[157][0-9]{6}\([0-9]\)|[A-Z][0-9]{8,10}',
            'address': r'(?:北京|上海|广州|深圳|杭州|成都|西安|武汉|重庆|南京|苏州|蘇州|天津|淄博|宁波|寧波|南昌|长沙|長沙|青岛|青島|郑州|鄭州|沈阳|瀋陽|香港|澳门|澳門|台湾|臺灣)[市区區]?\S{2,}',
            'secret_key': r'(?:sk_|api_|token_|key_)[a-zA-Z0-9_\-]{32,}|(?<![a-zA-Z0-9_\-])[a-zA-Z0-9_\-]{32,}(?:key|token|secret)(?![a-zA-Z0-9_\-])',
        }
        
        # Counter for each PII type to ensure unique placeholder indices
        self._counters: Dict[str, int] = {key: 0 for key in self.patterns.keys()}
    
    def mask(self, text: str) -> str:
        """
        Mask personally identifiable information in text.
        
        Process:
        1. First identify manually marked [[[ ]]] content with highest priority
        2. Then traverse config items set to True and use regex to auto-identify
        3. Replace with placeholder format: __PRIV_{TYPE}_{INDEX}__
        4. Store mapping in vault
        
        Args:
            text: Input text to mask
            
        Returns:
            Text with PII replaced by placeholders
        """
        # Reset counters for fresh masking
        self._counters = {key: 0 for key in self.patterns.keys()}
        self.vault.clear()
        
        # Step 1: Handle manually marked [[[ ]]] content (highest priority)
        text = self._mask_manual_tags(text)
        
        # Step 2: Auto-detect PII based on config (skip if custom_tag_only is True)
        if not self.config.get('custom_tag_only', False):
            text = self._mask_auto_detect(text)
        
        return text
    
    def _mask_manual_tags(self, text: str) -> str:
        """
        Handle manually marked [[[ ]]] content.
        Supports escaping with \[\[\[ and \]\]\]
        
        Args:
            text: Input text
            
        Returns:
            Text with manual tags replaced by placeholders
        """
        # Handle escaped tags: \[\[\[ -> temporary marker
        # First, save escaped opening tags
        escaped_open = '\x00ESCAPED_OPEN\x00'
        escaped_close = '\x00ESCAPED_CLOSE\x00'
        text = text.replace(r'\[\[\[', escaped_open)
        text = text.replace(r'\]\]\]', escaped_close)
        
        # Find all [[[ ... ]]] patterns
        # Pattern: [[[ any_content ]]]
        pattern = r'\[\[\[([^\[\]]*(?:\[[^\[\]]*\][^\[\]]*)*?)\]\]\]'
        
        def replace_manual_tag(match):
            # Save the ENTIRE matched text including [[[ ]]]
            full_match = match.group(0)
            placeholder = self._create_placeholder('manual_tag')
            self.vault[placeholder] = full_match
            return placeholder
        
        text = re.sub(pattern, replace_manual_tag, text)
        
        # Restore escaped tags to actual brackets (unescape them)
        text = text.replace(escaped_open, '[[[')
        text = text.replace(escaped_close, ']]]')
        
        return text
    
    def _mask_auto_detect(self, text: str) -> str:
        """
        Auto-detect PII based on enabled config items.
        
        Args:
            text: Input text
            
        Returns:
            Text with auto-detected PII replaced by placeholders
        """
        # Iterate through config items in order: more specific patterns first
        # id_card should come before phone to avoid partial matches
        for pii_type in ['id_card', 'phone', 'email', 'address', 'secret_key']:
            if self.config.get(pii_type, False) and pii_type in self.patterns:
                pattern = self.patterns[pii_type]
                
                def replace_match(match):
                    original = match.group(0)
                    placeholder = self._create_placeholder(pii_type)
                    self.vault[placeholder] = original
                    return placeholder
                
                text = re.sub(pattern, replace_match, text)
        
        return text
    
    def _create_placeholder(self, pii_type: str) -> str:
        """
        Create a unique placeholder for a PII item.
        Format: __PRIV_{TYPE}_{INDEX}__
        
        Args:
            pii_type: Type of PII (phone, email, id_card, etc.)
            
        Returns:
            Unique placeholder string
        """
        # Handle special case for manual tags
        counter_key = pii_type
        if pii_type == 'manual_tag':
            display_type = 'CUSTOM'
            counter_key = 'manual_tag'
        else:
            display_type = pii_type.upper()
            counter_key = pii_type
        
        # Increment counter for this type
        self._counters[counter_key] = self._counters.get(counter_key, 0) + 1
        index = self._counters[counter_key]
        
        return f'__PRIV_{display_type}_{index}__'
    
    def unmask(self, text: str) -> str:
        """
        Restore original values from placeholders.
        Supports case-insensitive matching to handle LLM modifications.
        
        Args:
            text: Text containing placeholders to restore
            
        Returns:
            Text with placeholders replaced by original values
        """
        # Create a case-insensitive mapping for robustness
        case_insensitive_vault = {}
        for placeholder, original in self.vault.items():
            # Store both the original placeholder and lowercase version
            case_insensitive_vault[placeholder] = original
            case_insensitive_vault[placeholder.lower()] = original
        
        # Replace all placeholders (both exact and case-insensitive)
        result = text
        for placeholder, original in self.vault.items():
            # First try exact match
            result = result.replace(placeholder, original)
            
            # Then try case-insensitive match
            pattern = re.compile(re.escape(placeholder), re.IGNORECASE)
            result = pattern.sub(original, result)
        
        return result
    
    def get_vault(self) -> Dict[str, str]:
        """
        Get a copy of the current vault mapping.
        
        Returns:
            Dictionary of {placeholder: original_value} mappings
        """
        return deepcopy(self.vault)
    
    def update_config(self, new_config: Dict[str, Any]) -> None:
        """
        Batch update configuration items.
        
        Args:
            new_config: Dictionary with config items to update
        """
        for key, value in new_config.items():
            if key in self.config:
                self.config[key] = value
            else:
                raise ValueError(f"Unknown config key: {key}")
    
    def __repr__(self) -> str:
        """String representation showing current config."""
        config_str = ', '.join(f'{k}={v}' for k, v in self.config.items())
        return f"PrivaText(config={{{config_str}}})"
