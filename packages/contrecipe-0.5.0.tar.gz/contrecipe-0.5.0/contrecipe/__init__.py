# v5 | 2026-05-03 | Sprint R5 — version bump 0.5.0 (quarantine + lifecycle land)
"""contrecipe — Procedural DNA curator for the Cont Hive.

This package does not chat. It inspects, validates, compiles, quarantines, and
evolves recipes. See README.md for the design rationale.
"""

__version__ = "0.5.0"
__all__ = ["__version__"]
