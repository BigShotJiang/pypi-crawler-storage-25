# v5 | 2026-05-03 | Sprint R5 — `quarantine` stub removed (now covered by test_quarantine.py)
"""Sprint R1 + R2 + R3 + R4 + R5 smoke tests.

These tests verify only what the skeleton commits to:
  - the package imports
  - __version__ is set and looks like a version
  - the CLI parser builds without error
  - the canonical schema YAML parses
  - all subcommand stubs return EXIT_NOT_IMPLEMENTED (uniformly)

They do NOT exercise inspector / validator / compiler logic — those land
in their own sprints with their own test files.
"""

from __future__ import annotations

import io
import re
from pathlib import Path

import pytest
import yaml

import contrecipe
from contrecipe import cli


# --------------------------------------------------------------------------
# Package import / version
# --------------------------------------------------------------------------

def test_package_imports() -> None:
    assert contrecipe.__version__


def test_version_format() -> None:
    # Loose semver-ish check; we only commit to "looks like a version".
    assert re.match(r"^\d+\.\d+\.\d+", contrecipe.__version__)


# --------------------------------------------------------------------------
# CLI parser
# --------------------------------------------------------------------------

def test_parser_builds() -> None:
    parser = cli._build_parser()
    assert parser.prog == "contrecipe"


def test_version_flag_exits_zero(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        cli.main(["--version"])
    assert exc.value.code == 0
    captured = capsys.readouterr()
    assert contrecipe.__version__ in captured.out


def test_no_command_prints_help(capsys: pytest.CaptureFixture[str]) -> None:
    rc = cli.main([])
    assert rc == cli.EXIT_USAGE
    captured = capsys.readouterr()
    assert "usage:" in captured.out.lower()


@pytest.mark.parametrize(
    "argv",
    [
        # 'inspect'    implemented in R2 — see test_inspector.py
        # 'validate'   implemented in R3 — see test_validator.py
        # 'compile'    implemented in R4 — see test_compiler.py
        # 'quarantine' implemented in R5 — see test_quarantine.py
        ["watch", "/tmp/inbox"],
        ["test", "/tmp/r.yaml"],
    ],
)
def test_subcommands_stub_uniformly(argv: list[str]) -> None:
    rc = cli.main(argv)
    assert rc == cli.EXIT_NOT_IMPLEMENTED, (
        f"subcommand {argv[0]!r} should return NOT_IMPLEMENTED until its sprint"
    )


# --------------------------------------------------------------------------
# Canonical schema
# --------------------------------------------------------------------------

SCHEMA_PATH = (
    Path(contrecipe.__file__).parent / "schemas" / "recipe_v1.schema.yaml"
)


def test_schema_file_exists() -> None:
    assert SCHEMA_PATH.is_file(), f"schema not found at {SCHEMA_PATH}"


def test_schema_parses() -> None:
    data = yaml.safe_load(SCHEMA_PATH.read_text())
    assert isinstance(data, dict)
    assert data["schema_version"] == 1


def test_schema_required_top_level_sections() -> None:
    data = yaml.safe_load(SCHEMA_PATH.read_text())
    for section in (
        "recipe",
        "step",
        "verify",
        "forbidden_workers",
        "defaults",
        "lifecycle_states",
        "allowed_transitions",
    ):
        assert section in data, f"missing schema section: {section}"


def test_schema_verify_methods_match_brief() -> None:
    """The brief commits to exactly these deterministic verify methods."""
    expected = {
        "output_matches",
        "output_contains",
        "exit_code",
        "not_empty",
        "equals",
        "test_passes",
    }
    data = yaml.safe_load(SCHEMA_PATH.read_text())
    actual = set(data["verify"]["allowed_methods"].keys())
    assert actual == expected, (
        f"verify methods drifted from brief: missing={expected - actual}, "
        f"extra={actual - expected}"
    )


def test_schema_forbidden_workers_match_audit() -> None:
    """Audit 2026-05-03 listed these contamination signatures."""
    expected = {"find_file", "where", "query_ews", "report_failure"}
    data = yaml.safe_load(SCHEMA_PATH.read_text())
    assert set(data["forbidden_workers"]) == expected


def test_schema_default_on_fail_is_abort() -> None:
    data = yaml.safe_load(SCHEMA_PATH.read_text())
    assert data["defaults"]["step.on_fail"] == "abort"
