# bude_whisper_api.py
import httpx
from .base_api import BaseModel
from agentforge.apis.mixins.audio_input_mixin import AudioInputMixin

BUDE_WHISPER_BASE_URL = "http://localhost:8100"


class BudeWhisperRuntime:
    def __init__(self, base_url: str = BUDE_WHISPER_BASE_URL):
        self.base_url = base_url.rstrip("/")

    def stt(self, model: str, audio_blob: bytes, params: dict) -> str:
        url = f"{self.base_url}/v1/audio/transcriptions"
        files = {"file": ("audio.wav", audio_blob, "audio/wav")}
        data = {"model": model, **params}
        response = httpx.post(url, files=files, data=data, timeout=60)
        response.raise_for_status()
        return response.json().get("text", "")


class STT(AudioInputMixin, BaseModel):
    """Speech-to-Text wrapper for the local BUD-E-Whisper server."""

    def __init__(self, model_name, **kwargs):
        super().__init__(model_name, **kwargs)
        base_url = kwargs.get("base_url", BUDE_WHISPER_BASE_URL)
        self.runtime = BudeWhisperRuntime(base_url=base_url)

    def _merge_parts(self, parts):
        return {"audio": parts.get("audio")}

    def _do_api_call(self, prompt, **filtered_params):
        audio_blob = prompt.get("audio")
        return self.runtime.stt(
            model=self.model_name,
            audio_blob=audio_blob,
            params=filtered_params,
        )

    def _process_response(self, raw_response):
        return raw_response
