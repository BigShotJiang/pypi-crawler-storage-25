# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

import json
import os
import shutil
import sys

import geopandas as gpd
import shapely
from stoptools import gtfs, ptsa, zhv

import utils


def export_points(df, layer_name, tmp_path, lat_lon_crs='EPSG:4326'):
    """
    Export points to MBTILES file.
    
    Parameters
    ----------
    df : geopandas.GeoDataFrame
        Data to export (columns "geo" and "info").
    layer_name : str
        Name of layer in in MBTILES file and file name.
    tmp_path : str
        Path of directory for storing intermediate GeoJSON files (won't be
        deleted by this script).
    lat_lon_crs : str
        GeoPandas compatible CRS string for export.
        
    Returns
    -------
    None
    
    """

    # write GeoJSON file
    geojson_path = os.path.join(tmp_path, f'{layer_name}.geojson')
    export_df = df[['geo', 'info']].reset_index().to_crs(lat_lon_crs)
    export_df.to_file(geojson_path, index=False, driver='GeoJSON')

    # convert to MBTILES file
    mbtiles_path = geojson_path.replace('.geojson', '.mbtiles')
    utils.shell_command(
        f'tippecanoe --base-zoom=11 --minimum-zoom=0 --maximum-zoom=19 ' \
        f'--buffer=20 --drop-densest-as-needed --no-clipping ' \
        f'--no-tile-compression --force -t {tmp_path} ' \
        f'--layer={layer_name} --output={mbtiles_path} {geojson_path}',
    )


def export_lines(pairs, layer_name, tmp_path, lat_lon_crs='EPSG:4326'):
    """
    Export lines to MBTILES file.
    
    Parameters
    ----------
    pairs : list of (stops.StopObject, stops.StopObject)
        Data to export (one line per pair).
    layer_name : str
        Name of layer in in MBTILES file and file name.
    tmp_path : str
        Path of directory for storing intermediate GeoJSON files (won't be
        deleted by this script).
    lat_lon_crs : str
        GeoPandas compatible CRS string for export.
        
    Returns
    -------
    None
    
    """

    # GeoJSON
    geojson_path = os.path.join(tmp_path, f'{layer_name}.geojson')
    gpd.GeoSeries(
        [
            shapely.LineString([(o1.lon, o1.lat), (o2.lon, o2.lat)]) \
            for o1, o2 in pairs
        ],
        crs=lat_lon_crs
    ).to_file(geojson_path, index=False, driver='GeoJSON')

    # mbtiles
    mbtiles_path = geojson_path.replace('.geojson', '.mbtiles')
    utils.shell_command(
        f'tippecanoe --base-zoom=18 --minimum-zoom=16 --maximum-zoom=19 ' \
        f'--buffer=20 --drop-densest-as-needed --no-clipping ' \
        f'--no-tile-compression --force -t {tmp_path} ' \
        f'--layer={layer_name} --output={mbtiles_path} {geojson_path}'
    )
    
    
def process_data(data):
    """
    Generate tiles, info files, HTML code, JS code for one data source.
    
    Parameters
    ----------
    data : dict
        JSON dict with configuration for data source.
    
    Returns
    -------
    (str, str, str) or None
        Tuple of HTML code, JS code for layers, JS code for styler functions, if
        everything is okay. None else.
    
    """

    # load data
    logger.debug('Loading data from JSON file(s)...')
    if data['type'] == 'zhv':
        places, areas, quays = zhv.gdf_from_json(data['json_path'])
    elif data['type'] == 'gtfs':
        stations, platforms, miscs = gtfs.gdf_from_json(data['json_path'])
        if data.get('stop_routes_path'):
            stop_routes = gtfs.stop_routes_from_json(data['stop_routes_path'])
        else:
            stop_routes = dict()
    elif data['type'] == 'ptsa':
        places, stops = ptsa.gdf_from_json(data['json_path'])
        if data.get('stop_routes_path'):
            stop_routes = ptsa.stop_routes_from_json(data['stop_routes_path'])
        else:
            stop_routes = dict()
    logger.debug('...done loading data.')
        
    # generate info strings
    logger.debug(f'Generating info strings...')
    if data['type'] == 'zhv':
        dfs = [places, areas, quays]
    elif data['type'] == 'gtfs':
        dfs = [stations, platforms, miscs]
    elif data['type'] == 'ptsa':
        dfs = [places, stops]
    def info(obj):
        json_dict = obj.to_json()
        if data['type'] in ['gtfs', 'ptsa']:
            json_dict['stop_routes'] = stop_routes.get(obj.uid)
        return json.dumps(json_dict)
    for df in dfs:
        df['info'] = df['obj'].apply(info)
    logger.debug(f'...done generating info strings.')
    
    # export geometry
    for item in data['items']:
        layer_name = f'x{item['order']}_{data['id']}_{item['id']}'
        logger.info(f'Exporting geometry layer "{layer_name}" to file...')
        match (data['type'], item['id']):
            case ('zhv', 'places'):
                export_points(places, layer_name, config['tmp_path'])
            case ('zhv', 'places_lines'):
                pairs = []
                for place in places['obj']:
                    pairs.extend([(place, area) for area in place.child_areas])
                    pairs.extend([(place, quay) for quay in place.child_quays])
                export_lines(pairs, layer_name, config['tmp_path'])
            case ('zhv', 'areas'):
                export_points(areas, layer_name, config['tmp_path'])
            case ('zhv', 'areas_lines'):
                pairs = []
                for area in areas['obj']:
                    pairs.extend([(area, quay) for quay in area.child_quays])
                export_lines(pairs, layer_name, config['tmp_path'])
            case ('zhv', 'quays'):
                export_points(quays, layer_name, config['tmp_path'])
            case ('gtfs', 'stations'):
                export_points(stations, layer_name, config['tmp_path'])
            case ('gtfs', 'stations_lines'):
                pairs = []
                for station in stations['obj']:
                    pairs.extend([(station, platform) for platform in station.child_platforms])
                    pairs.extend([(station, misc) for misc in station.child_miscs])
                export_lines(pairs, layer_name, config['tmp_path'])
            case ('gtfs', 'platforms'):
                export_points(platforms, layer_name, config['tmp_path'])
            case ('gtfs', 'miscs'):
                export_points(miscs, layer_name, config['tmp_path'])
            case ('ptsa', 'places'):
                export_points(places, layer_name, config['tmp_path'])
            case ('ptsa', 'places_lines'):
                pairs = []
                for place in places['obj']:
                    pairs.extend([(place, stop) for stop in place.stops])
                export_lines(pairs, layer_name, config['tmp_path'])
            case ('ptsa', 'stops'):
                export_points(stops, layer_name, config['tmp_path'])
            case _:
                logger.warning(f'No data for item "{item['id']}" in data source "{data['id']}"!')
        logger.info('...done exporting geometry.')    

    # generate HTML code
    html = ''
    html += f'<div style="font-weight: bold;">{data['title']}\n'
    item_list = ', '.join([f'\'{data['id']}_{i['id']}\'' for i in data['items']])
    html += f'<button type="button" onclick="set_check([{item_list}], true)">all</button>\n'
    html += f'<button type="button" onclick="set_check([{item_list}], false)">none</button>\n'
    html += f'</div>\n'
    for item in data['items']:
        name = f'{data['id']}_{item['id']}'
        html += f'<div onclick="redraw()">\n'
        html += f'<input id="{name}" type="checkbox" name="{name}" {'checked' if item['visible'] else ''} />\n'
        html += f'<label for="{name}"><span style="color: {item['color']}"> ●</span> {item['title']}</label>\n'
        html += f'</div>\n'
    
    # generate JS code
    js_layer_list = ''
    js_styler_funcs = ''
    for item in data['items']:
        layer_name = f'x{item['order']}_{data['id']}_{item['id']}'
        name = f'{data['id']}_{item['id']}'
        js_layer_list += f'{layer_name}: {name}Styler,\n'
        js_styler_funcs += f'function {name}Styler(props, zoom) {{\n'
        js_styler_funcs += f'    if (document.getElementById("{name}").checked == true) {{\n'
        js_styler_funcs += '        return({\n'
        if item['id'].endswith('lines'):
            js_styler_funcs += f'        opacity: 1.0,\n'
            js_styler_funcs += f'        weight: {item['size']},\n'
            js_styler_funcs += f'        color: "{item['color']}",\n'
        else:
            js_styler_funcs += f'        radius: {item['size']},\n'
            js_styler_funcs += f'        color: "#000000",\n'
            js_styler_funcs += f'        opacity: 1.0,\n'
            js_styler_funcs += f'        weight: 1,\n'
            js_styler_funcs += f'        fill: true,\n'
            js_styler_funcs += f'        fillColor: "{item['color']}",\n'
            js_styler_funcs += f'        fillOpacity: 1.0,\n'
        js_styler_funcs += '        });\n'
        js_styler_funcs += '    } else {\n'
        js_styler_funcs += '        return [];\n'
        js_styler_funcs += '    }\n'
        js_styler_funcs += '}\n'

    return html, js_layer_list, js_styler_funcs


# load config file
if len(sys.argv) > 1:
    config_path = sys.argv[1]
else:
    config_path = 'viewer_config.json'
with open(config_path) as f:
    config = json.load(f)

# initialize logging
logger = utils.init_logger(
    path=config['log_path'],
    debug=config.get('debug', False)
)
logger.info(f'Using config file "{config_path}".')

# JS code for WMS layers
js_wms_layers = ''
js_wms_layers_control = ''
for name, wms_config in config['wms_layers'].items():
    leaflet_layer_name = f'{name}dopLayer'
    js_wms_layers += f'var {leaflet_layer_name} = L.tileLayer.wms(\n'
    js_wms_layers += f'    "{wms_config['url']}",\n'
    js_wms_layers += f'    {{\n'
    js_wms_layers += f'    layers: "{wms_config['layer']}",\n'
    js_wms_layers += f'    format: "{wms_config['format']}",\n'
    js_wms_layers += f'    attribution: \'{wms_config['attribution']}\',\n'
    js_wms_layers += f'    crs: L.CRS.EPSG3857,\n'
    js_wms_layers += f'    transparent: true,\n'
    js_wms_layers += f'    maxNativeZoom: 20,\n'
    js_wms_layers += f'    maxZoom: 21\n'
    js_wms_layers += f'    }}\n'
    js_wms_layers += f');\n'
    js_wms_layers_control += f'    "{wms_config['title']}": {leaflet_layer_name},'

# process each data source
html = ''
js_layer_list = ''
js_styler_funcs = ''
fail = False
for data in config['data']:
    if data['id'] in config['skip_data']:
        logger.info(f'Skipping data "{data['id']}".')
        continue
    logger.info(f'Processing data "{data['id']}"...')
    result = process_data(data) 
    if result:
        html += result[0]
        js_layer_list += result[1]
        js_styler_funcs += result[2]
    else:
        fail = True
    logger.info(f'...done processing data "{data['id']}".')
if fail:
    logger.info('Processing failed for at least one data source.')
else:
    logger.info('All data processed successfully.')

# join tiles from all layers
logger.info('Joining tiles...')
src_mbtiles_path = os.path.join(config['tmp_path'], '*.mbtiles')
utils.shell_command(
    f'tile-join --no-tile-size-limit --output={config['tiles_path']} ' \
    f'--force --no-tile-compression {src_mbtiles_path}'
)
logger.info('...done.')

# write HTML file
html_template_path = os.path.join(
    config['template_path'], config['html_template_name']
)
html_path = os.path.join(
    config['html_path'], config['html_name']
)
logger.debug(f'Generating HTML file "{html_path}" from template "{html_template_path}".')
with open(html_template_path) as f:
    html_replaced = f.read().replace('<!--AUTOGENERATED-->', html)
with open(html_path, 'w') as f:
    f.write(html_replaced)
    
# write JS file
js_template_path = os.path.join(
    config['template_path'], config['js_template_name']
)
js_path = os.path.join(
    config['html_path'], config['js_name']
)
logger.debug(f'Generating JS file "{js_path}" from template "{js_template_path}".')
with open(js_template_path) as f:
    js_replaced = f.read() \
        .replace('/*AUTOGENERATED_LAYER_LIST*/', js_layer_list) \
        .replace('/*AUTOGENERATED_STYLER_FUNCS*/', js_styler_funcs) \
        .replace('/*AUTOGENERATED_WMS_LAYERS*/', js_wms_layers) \
        .replace('/*AUTOGENERATED_WMS_LAYERS_CONTROL*/', js_wms_layers_control) \
        .replace('/*AUTOGENERATED_TILES_URL*/', config['tiles_url']) \
        .replace('/*AUTOGENERATED_PTSA_TILES_URL*/', config['ptsa_tiles_url']) \
        .replace('/*AUTOGENERATED_PTSA_URL*/', config['ptsa_url']) \
        .replace('/*AUTOGENERATED_ATTRIBUTION*/', config['attribution'])
with open(js_path, 'w') as f:
    f.write(js_replaced)

# copy template files
logger.debug(f'Copying additional template files from "{config['template_path']}" to "{config['html_path']}".')
copy_files = config.get('copy_files', [])
for filename in copy_files:
    shutil.copy(
        os.path.join(config['template_path'], filename),
        os.path.join(config['html_path'], filename)
    )
