# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

import datetime
import glob
import json
import os
import re
import shutil
import sys

import requests
from stoptools import datafiles, gtfs, ptsa, zhv

import utils


def process_provider(provider):
    """
    Download and process data provided somewhere on the internet.

    Parameters
    ----------
    provider : dict
        JSON dict with provider configuration.

    Returns
    -------
    bool
        True if everything is okay. False if something went wrong.

    """
    
    # download data
    if provider['type'] in ['gtfs', 'zhv']:
        try:
            new_data = datafiles.download(
                provider['url'],
                provider['zip_path'],
                f'{provider['name']}_{{date}}.zip',
                scrape_regex=provider.get('url_regex'),
                check_new=True
            )
        except Exception as e:
            logger.error(f'Download failed with exception {e}! Skipping provider.')
            return False
        if not new_data:
            return True

    # process data
    full_json_path = os.path.join(
        provider['json_path'], f'{provider['name']}_{{subset}}.json'
    )
    if provider['type'] == 'zhv':
        places_df, areas_df, quays_df = zhv.df_from_zip(provider['zip_path'])
        places, areas, quays = zhv.gdf_from_df(
            places_df, areas_df, quays_df, source=provider['name']
        )
        zhv.json_from_gdf(
            places, areas, quays,
            path=full_json_path,
            subsets=provider['subsets']
        )
    elif provider['type'] == 'gtfs':
        stops, times, trips, routes = gtfs.df_from_zip(
            provider['zip_path'],
            subset=['stops', 'stop_times', 'trips', 'routes']
        )
        stations_df, platforms_df, miscs_df = gtfs.separate_stops_by_type(stops)
        stations, platforms, miscs = gtfs.gdf_from_df(
            stations_df, platforms_df, miscs_df, source=provider['name']
        )
        gtfs.json_from_gdf(
            stations, platforms, miscs,
            path=full_json_path,
            subsets=provider['subsets']
        )
        id_to_uid = dict(
            platforms['obj'].apply(lambda obj: (obj.id, obj.uid)).to_numpy()
        )
        stop_routes = gtfs.get_stop_routes(id_to_uid, times, trips, routes)
        gtfs.json_from_stop_routes(
            stop_routes,
            os.path.join(
                provider['json_path'], f'{provider['name']}_stop_routes.json'
            )
        )
    elif provider['type'] == 'ptsa':
        places_df, stops_df = ptsa.df_from_ptsa(
            provider['url'], provider['regions'], provider['overpass_url'],
            provider['overpass_api_key'], provider['overpass_timeout']
        )
        places, stops = ptsa.gdf_from_df(places_df, stops_df)
        ptsa.json_from_gdf(
            places, stops,
            path=full_json_path,
            subsets=provider['subsets']
        )
        stop_routes = ptsa.get_stop_routes(
            stops, provider['overpass_url'], provider['overpass_api_key'],
            provider['overpass_timeout']
        )
        ptsa.json_from_stop_routes(
            stop_routes,
            os.path.join(
                provider['json_path'], f'{provider['name']}_stop_routes.json'
            )
        )

    else:
        logger.error(f'Unknown provider type "{provider['type']}"! Skipping processing data from this provider.')
    
    return True


# load config file
if len(sys.argv) > 1:
    config_path = sys.argv[1]
else:
    config_path = 'update_config.json'
with open(config_path) as f:
    config = json.load(f)

# initialize logging
logger = utils.init_logger(
    path=config['log_path'],
    debug=config.get('debug', False)
)
logger.info(f'Using config file "{config_path}".')

# process each provider
fail = False
for provider in config['providers']:
    if provider['name'] in config['skip_providers']:
        logger.info(f'Skipping provider "{provider['name']}".')
        continue
    logger.info(f'Processing provider "{provider['name']}"...')
    if not process_provider(provider):
        fail = True
    logger.info(f'...done processing provider "{provider['name']}".')

if fail:
    logger.info('Processing failed for at least one provider.')
else:
    logger.info('All providers processed successfully.')
