# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Utility functions used in additional scripts for the stoPTools package

init_logger:
    Set log level, format and destination of a logger
shell_command:
    Run a command in a shell.

"""

import logging
import subprocess


def init_logger(path=None, name=None, debug=False):
    """
    Set log level, format and destination of a logger.

    Each call to this function clears the log file (if it exists). Messages are
    written to the logfile and to stdout. Messages do not propagate to parent
    loggers.

    Parameters
    ----------
    path : str or None, optional
        Path of file to write log output to. Set to None to avoid creating a log
        file. Default is None.
    name : str or None, optional
        Name of the logger. Set to None to initialize the root logger. Default
        is None.
    debug : bool, optional
        Set log level to DEBUG (if True) or INFO (if False). Defult is False.

    Returns
    -------
    logging.Logger
        Object representing the logger. Same as obtained from
        logging.getLogger(name).

    """

    logger = logging.getLogger(name)

    logger.setLevel(logging.DEBUG if debug else logging.INFO)

    formatter = logging.Formatter('%(asctime)s %(filename)s:%(levelno)s %(levelname)s %(message)s')

    # logging to stdout
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # logging to file
    if path:
        handler = logging.FileHandler(path, mode='w')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # Usually a logger is initalized via this function if we want to have a
    # separate log file for the logger. Thus, the logger's messages should not
    # appear in any parent logger's output.
    logger.propagate = False

    # initial log message
    if debug:
        logger.info('Started logging in debug mode.')
    else:
        logger.info('Started logging with debug mode turned off.')

    return logger


def shell_command(cmd):
    """
    Run a command in a shell.

    Parameters
    ----------
    cmd : str
        Shell command including arguments.

    Returns
    -------
    bool
        True if succesful. False if negative return code ro OSError.

    """
    
    try:
        retcode = subprocess.call(cmd, shell=True)
        if retcode < 0:
            logger.error(f'Shell command "{cmd}" failed with code {-retcode}.')
            return False
    except OSError as e:
        logger.error(f'Shell command "{cmd}" failed with exception {e}.')
        return False
    
    return True
