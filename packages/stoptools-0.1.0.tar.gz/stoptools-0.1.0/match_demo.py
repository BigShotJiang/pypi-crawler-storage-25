# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

import json
import sys

import numpy as np
import pandas as pd
from stoptools import zhv, gtfs, ptsa, matching

import utils


# load config file
if len(sys.argv) > 1:
    config_path = sys.argv[1]
else:
    config_path = 'match_demo_config.json'
with open(config_path) as f:
    config = json.load(f)

# initialize logging
logger = utils.init_logger(
    path=config['log_path'],
    debug=config.get('debug', False)
)
logger.info(f'Using config file "{config_path}".')

# load data (written by update_all.py)
logger.info('Loading data...')
zhv_places, zhv_areas, zhv_quays = zhv.gdf_from_json(config['zhv_path'])
zhv_places, zhv_areas, zhv_quays \
    = zhv.drop_inactive_gdf(zhv_places, zhv_areas, zhv_quays)
delfi_stations, delfi_platforms, delfi_miscs \
    = gtfs.gdf_from_json(config['delfi_path'])
delfi_stop_routes = gtfs.stop_routes_from_json(config['delfi_stop_routes_path'])
ptsa_places, ptsa_stops = ptsa.gdf_from_json(config['ptsa_path'])
logger.info('...done loading data.')

# create data frame with all passenger wait objects
pws = pd.concat([zhv_quays, delfi_platforms, ptsa_stops], axis=0)
pws = pws.to_crs(config['meters_crs'])

# skip prematching if done in a previous run to save time while testing
# different matching variants
if config['prematch']:

    # prematching (collect all candidates for matching)
    logger.info('Prepare data for prematching...')
    matching.pw_prepare_data(pws, delfi_stop_routes)
    logger.info('...done preparing date for prematching.')
    logger.info('Prematching...')
    matching.pw_prematch(pws, 500)
    logger.info('...done prematching.')

    # compute scores for each prematched stop pair
    logger.info('Computing scores...')
    pw_scores = matching.pw_get_scores(pws, 50)
    logger.info('...done computing scores.')

    # save prematch data and scores to CSV files
    matching.pw_save_data_and_scores(
        pws, pw_scores, config['match_data_path'], config['match_scores_path']
    )

else:  # skip prematching
    
    logger.info('Using existing prematch data and scores.')

    # load prematch data and scores from CSV files
    pw_data, pw_scores = matching.pw_load_data_and_scores(
        config['match_data_path'], config['match_scores_path']
    )
    pws = pd.concat([pws, pw_data], axis=1)

# compute total scores for prematched stop pairs
pw_scores['total'] = \
    100 * pw_scores['ifopt'] + \
    10 * pw_scores['name'] + \
    20 * pw_scores['ref'] + \
    1 * pw_scores['mods'] + \
    10 * pw_scores['distance'] + \
    0 * pw_scores['parent_ifopt'] + \
    0 * pw_scores['dparent_ifopt']
min_score = 0  # minimum total score to consider a stop pair as matching

# increase total scores to ensure that zhv-delfi pairs are matched first, then
# delfi-ptsa pairs, then all other pairs
sources = pws['obj'].apply(lambda obj: obj.source)
sources1 = sources.loc[pw_scores.index.get_level_values(0)].to_numpy()
sources2 = sources.loc[pw_scores.index.get_level_values(1)].to_numpy()
del sources
zhv_delfi_mask = np.logical_or(
    np.logical_and(sources1 == 'zhv', sources2 == 'delfi'),
    np.logical_and(sources1 == 'delfi', sources2 == 'zhv')
)
delfi_ptsa_mask = np.logical_or(
    np.logical_and(sources1 == 'delfi', sources2 == 'ptsa'),
    np.logical_and(sources1 == 'ptsa', sources2 == 'delfi')
)
pos_mask = pw_scores['total'] > min_score
pw_scores.loc[np.logical_and(zhv_delfi_mask, pos_mask), 'total'] += 2000.0
pw_scores.loc[np.logical_and(delfi_ptsa_mask, pos_mask), 'total'] += 1000.0
del zhv_delfi_mask, delfi_ptsa_mask, pos_mask

# group stops by score
logger.info('Matching...')
gids, final_groups = matching.group_by_score(
    pws.index, pw_scores['total'], join_func='min', all_groups=False,
    min_score=min_score, progress=True
)
pws['gid'] = gids
del gids
logger.info(f'...done matching. Made {len(final_groups)} groups.')

#-------------------------------------------------------------------------------
# Following code shows statistics on matched stops.
# Matching has been done already above.
#-------------------------------------------------------------------------------

# show statistics on group sizes
logger.info('Calculating group sizes...')
sizes = []
for group in final_groups.values():
    sizes.append(len(group))
sizes = pd.Series(sizes)
print(sizes.value_counts())

# sources of stops in each group
stats = dict(gid=[], zhv=[], delfi=[], ptsa=[])
for gid, group in final_groups.items():
    stats['gid'].append(gid)
    n_zhv = 0
    n_delfi = 0
    n_ptsa = 0
    for uid in group:
        obj = pws.at[uid, 'obj']
        if isinstance(obj, zhv.ZHVObject):
            n_zhv += 1
        elif isinstance(obj, gtfs.GTFSObject):
            n_delfi += 1
        elif isinstance(obj, ptsa.PTSAObject):
            n_ptsa += 1
    stats['zhv'].append(n_zhv)
    stats['delfi'].append(n_delfi)
    stats['ptsa'].append(n_ptsa)
stats = pd.DataFrame(stats).set_index('gid')
print(f'groups:             {len(stats):7d}')
print()
print(f'111 groups:         {((stats['zhv'] == 1) & (stats['delfi'] == 1) & (stats['ptsa'] == 1)).sum():7d}')
print(f'011 groups:         {((stats['zhv'] == 0) & (stats['delfi'] == 1) & (stats['ptsa'] == 1)).sum():7d}')
print(f'0 or 1 per source:  {((stats['zhv'] <= 1) & (stats['delfi'] <= 1) & (stats['ptsa'] <= 1)).sum():7d}')
print()
print(f'no-ptsa groups:     {((stats['zhv'] > 0) & (stats['delfi'] > 0) & (stats['ptsa'] == 0)).sum():7d}')
print(f'ptsa-only groups:   {((stats['zhv'] == 0) & (stats['delfi'] == 0) & (stats['ptsa'] > 0)).sum():7d}')
print()
print(f'multi zhv groups:   {(stats['zhv'] > 1).sum():7d}')
print(f'multi delfi groups: {(stats['delfi'] > 1).sum():7d}')
print(f'multi ptsa groups:  {(stats['ptsa'] > 1).sum():7d}')

# prepare route direction checks for groups
logger.info('Preparing direction checks...')
def stops_to_gids(stops):
    return set(pws.loc[list(stops), 'gid']) if stops else None
pws['prev_gids'] = pws['prev_stops'].apply(stops_to_gids)
pws['next_gids'] = pws['next_stops'].apply(stops_to_gids)
prev_gids_map = dict()
next_gids_map = dict()
for gid, group in final_groups.items():
    prev_gids_sets = [gids for gids in pws.loc[list(group), 'prev_gids']
                           if gids is not None and len(gids) > 0]
    prev_gids_map[gid] = set.union(*prev_gids_sets) if len(prev_gids_sets) > 0 \
                                                    else set()
    next_gids_sets = [gids for gids in pws.loc[list(group), 'next_gids']
                           if gids is not None and len(gids) > 0]
    next_gids_map[gid] = set.union(*next_gids_sets) if len(next_gids_sets) > 0 \
                                                    else set()
logger.info('...done preparing direction checks.')

# check route directions for groups with multiple DELFI GTFS stops
logger.info('Checking directions for groups with DELFI GTFS stops...')
for gid in stats.index[stats['delfi'] > 1]:
    prev_gids = prev_gids_map.get(gid)
    next_gids = next_gids_map.get(gid)
    if not prev_gids or not next_gids:
        continue
    if prev_gids & next_gids == set():
        continue
    group = final_groups[gid]
    for uid1 in group:
        if not isinstance(pws.at[uid1, 'obj'], gtfs.GTFSPlatform):
            continue
        for uid2 in group:
            if uid1 == uid2:
                continue
            if not isinstance(pws.at[uid2, 'obj'], gtfs.GTFSPlatform):
                continue
            prev_gids1 = pws.at[uid1, 'prev_gids']
            next_gids1 = pws.at[uid1, 'next_gids']
            prev_gids2 = pws.at[uid2, 'prev_gids']
            next_gids2 = pws.at[uid2, 'next_gids']
            if prev_gids1 is None or next_gids1 is None \
            or prev_gids1 & next_gids1 != set():
                continue  # only look at stops appearing in one route direction
            if prev_gids2 is None or next_gids2 is None:
                continue
            if prev_gids2 & next_gids2 == set():  # stop 2 in one route dir only
                if uid1 > uid2:
                    continue  # pair already processed
                if prev_gids1 & next_gids2 != set():
                    logger.warning(f'opposite directions in group {gid}: UID1 {uid1}, UID2 {uid2}, prev1&next2 {prev_gids1 & next_gids2}')
                if next_gids1 & prev_gids2 != set():
                    logger.warning(f'opposite directions in group {gid}: UID1 {uid1}, UID2 {uid2}, prev1&next2 {next_gids1 & prev_gids2}')
            if prev_gids2 & next_gids2 != set():  # stop 2 in both route dirs
                logger.warning(f'group {gid}: stop {uid1} serves 1 direction, stop {uid2} serves both')
