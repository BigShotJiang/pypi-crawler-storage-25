# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Download and handle GTFS and ZHV data files

get_most_recent_zip(path):
    Return file name of most recent ZIP file in directory
get_last_modified_in_zip(f):
    Get last-modified date of most recent file in ZIP file
download:
    Download file

"""

import datetime
import glob
import io
import logging
import os
import re
import zipfile

import requests


logger = logging.getLogger(__name__)


def get_most_recent_zip(path):
    """
    Return file name of most recent ZIP file in directory.

    Parameters
    ----------
    path : str
        Path of directory.

    Returns
    -------
    str or None
        Path of most recent ZIP file or None, if there are no ZIP files.

    """
    
    zip_paths = glob.glob(os.path.join(path, '*.zip'))
    if len(zip_paths) == 0:
        return None
    last_mod_times = [os.path.getmtime(p) for p in zip_paths]
    path = max(zip(zip_paths, last_mod_times), key=lambda x: x[1])[0]
    return path
    

def get_last_modified_in_zip(f):
    """
    Get last-modified date of most recent file in ZIP file.

    Parameters
    ----------
    f : str or file-like
        ZIP file (something zipfile.ZipFile understands)

    Returns
    -------
    datetime.date or None
        Last-modified date. None, if opening as ZIP file fails.

    """

    try:
        with zipfile.ZipFile(f) as zf:
            last_mod_dates = [datetime.date(*zf.getinfo(name).date_time[:3])
                              for name in zf.namelist()]
            date = max(last_mod_dates)
    except Exception:
        date = None
        
    return date


def download(src, dest, name, scrape_regex=None, check_new=True):
    """
    Download GTFS or ZHV data file.

    Parameters
    ----------
    src : str
        URL of file to download or of HTML file to scrape URL from.
    dest : str
        Path of directory to save file to.
    name : str
        Name of file to write. {date} will be replaced by last-modified date of
        ZIP file's contents or buy today's date if file is not a ZIP file.
    scrape_regex : str, optional
        Regex to extract download link from HTML file pointed to by src. Use
        None, if src points directly to the file to download.
    check_new : bool, optional
        Only write file if differs from most recent file in dest.

    Returns
    -------
    bool
        True if data file has been written. False if an error occured or
        downloaded data is not new (if check_new is True).

    """

    # get data URL
    if scrape_regex:
        logger.debug(f'Looking for data URL at {src}.')
        try:
            response = requests.get(
                src,
                headers={'User-Agent': 'some browser'}
            )
        except Exception as e:
            logger.error(f'Request failed with exception "{e}".')
            return False
        if response.status_code != 200:
            logger.error(f'Download failed with status code {response.status_code}.')
            return False
        m = re.search(scrape_regex, response.text)
        if m:
            src = m.string[m.start():m.end()]
        else:
            logger.error(f'Couldn\'t find an URL matching the regex r"{scrape_regex}".')
            return False
    
    # download data
    logger.debug(f'Downloading data from {src}.')
    try:
        response = requests.get(
            src,
            headers={'User-Agent': 'some browser'}
        )
    except Exception as e:
        logger.error(f'Request faild with exception "{e}".')
        return False
    if response.status_code != 200:
        logger.error(f'Download failed with status code {response.status_code}.')
        return False
    data = response.content
        
    # check whether data is new
    if check_new:
        most_recent_zip_path = get_most_recent_zip(dest)
        if most_recent_zip_path:
            with open(most_recent_zip_path, 'rb') as f:
                zip_data = f.read()
            if zip_data == data:
                logger.info(f'Downloaded data is not new.')
                return False
            else:
                logger.info(f'Downloaded data is new.')
        else:
            logger.info(f'Downloaded data is new.')
        
    # save downloaded data
    date = get_last_modified_in_zip(io.BytesIO(data))
    if not date:
        date = datetime.datetime.today()
    date_string = date.strftime('%Y%m%d')
    file_name = name.format(date=date_string)
    path = os.path.join(dest, file_name)
    logger.debug(f'Writing new data to "{path}".')
    with open(path, 'wb') as f:
        f.write(data)

    return True
