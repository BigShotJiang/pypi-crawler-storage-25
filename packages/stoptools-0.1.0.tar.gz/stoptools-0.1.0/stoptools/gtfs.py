# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Load and process DELFI-style GTFS data from https://www.opendata-oepnv.de

df_from_zip:
    Load GTFS data from ZIP file to DataFrame
df_from_feed_info:
    Read data from feed_info.txt file
df_from_stops:
    Read data from stops.txt file
df_from_routes:
    Read data from routes.txt file
df_from_trips:
    Read data from trips.txt file
df_from_stop_times:
    Read data from stop_times.txt file
df_from_agency:
    Read data from agency.txt file
df_from_shapes:
    Read data from shapes.txt file
df_from_calendar:
    Read data from calendar.txt file
df_from_calendar_dates:
    Read data from calendar_dates.txt file
separate_stops_by_type:
    Separate stops into platforms, stations, misc objects
GTFSObject:
    Represent a GTFS stop object
GTFSStation:
    Represent a GTFS station
GTFSPlatform:
    Represent a GTFS platform
GTFSMisc:
    Represent a misc GTFS object
gdf_from_df:
    Create GeoDataFrame of GTFSObject objects from DataFrame
json_from_gdf:
    Write data from GeoDataFrames of GTFSObject objects to JSON file
gdf_from_json:
    Create GeoDataFrames of GTFSObject objects from JSON file
get_stop_routes:
    Get route information for each stop
json_from_stop_routes:
    Write route information for stops to JSON file
stop_routes_from_json:
    Read route information for stops from JSON file
calendar_to_date_lists:
    Make lists of all service dates
shapes_to_geo:
    Convert shapes data to shapely geometries

"""

import datetime
import glob
import json
import logging
import os
import zipfile

import geopandas as gpd
import numpy as np
import pandas as pd
import shapely

from . import stops


logger = logging.getLogger(__name__)


def df_from_zip(path, subset=None, return_date=False):
    """
    Read GTFS data from specified ZIP file. Return list of data frames in same
    order as subset argument lists GTFS filenames (without .txt). If subset is
    None, only contents of feed_info.txt are written to the logs.

    Only very basic data validation is performed here. See code for details and
    https://github.com/mfdz/gtfs-issues/issues for a list of issues with the
    data source. Validation failures will result in warnings in the logs.

    For each GTFS file the function calls corresponding df_from_TABLENAME
    function. See there for information on columns, data types and general
    behavior.

    Parameters
    ----------
    path : str
        Path of ZIP file to read from. If the string points to a directory, the
        most recent (last-modified date) ZIP file (ending with .zip) is read.
    subset : list of str or None, optional
        GTFS file names (without .txt) to read.
    return_date : bool, optional
        If True, return last-modified date of the most recent file in the ZIP
        archive.

    Returns
    -------
    pandas.DataFrame or list of pandas.DataFrame or None
        Data read. One DataFrame per item in the subset parameter. Is subset is
        None, returns None. If subset contains only one item, the DataFrame is
        returned instead of a list with one item.
    datetime.date
        Last-modification date of the most recent file in the ZIP archive (only
        if return_date parameter is True).

    Raises
    ------
    FileNotFoundError
        Path does not point to a file and not to a directory containing ZIP
        files.

    """

    # find most recent ZIP file (if path points to a directory)
    if not path:
        logger.debug('Path not set, using ".".')
        path = '.'
    if os.path.isdir(path):
        logger.debug(f'Path "{path}" is a directory. Looking for most recent ZIP file.')
        zip_paths = glob.glob(os.path.join(path, '*.zip'))
        logger.debug(f'Found {len(zip_paths)} ZIP files.')
        if len(zip_paths) == 0:
            raise FileNotFoundError(f'Directory "{path}" does not contain any ZIP file!')
        last_mod_times = [os.path.getmtime(p) for p in zip_paths]
        path = max(zip(zip_paths, last_mod_times), key=lambda x: x[1])[0]
        del zip_paths, last_mod_times
    elif not os.path.isfile(path):
        raise FileNotFoundError(f'Path "{path}" neither points to a directory nor to a regular file!')

    # read file
    logger.info(f'Reading GTFS data from file "{path}".')
    df_list = []
    with zipfile.ZipFile(path) as zf:

        # get last-mod date of most recent file in archive
        last_mod_dates = [datetime.date(*zf.getinfo(name).date_time[:3])
                          for name in zf.namelist()]
        date = max(last_mod_dates)
        logger.info(f'ZIP file content\'s last-modification date is {date}.')

        # always read feed_info.txt
        if 'feed_info.txt' in zf.namelist():
            logger.debug('Reading "feed_info.txt" from ZIP file...')
            with zf.open('feed_info.txt') as f:
                feed_info = df_from_feed_info(f)
            logger.debug('...done reading "feed_info.txt".')
        else:
            logger.warning('No "feed_info.txt" found!')
            feed_info = None
 
        # read table by table
        if subset is None:
            return
        funcs = {
            'stops': df_from_stops,
            'routes': df_from_routes,
            'trips': df_from_trips,
            'stop_times': df_from_stop_times,
            'agency': df_from_agency,
            'shapes': df_from_shapes,
            'calendar': df_from_calendar,
            'calendar_dates': df_from_calendar_dates
        }
        for table in subset:
            if table == 'feed_info':
                df_list.append(feed_info)
            elif f'{table}.txt' in zf.namelist():
                if table in funcs:
                    logger.debug(f'Reading "{table}.txt" from ZIP file...')
                    with zf.open(f'{table}.txt') as f:
                        df_list.append(funcs[table](f))
                    logger.debug(f'...done reading "{table}.txt".')
                else:
                    logger.error(f'No loader available for GTFS table {table}!')
                    df_list.append(None)
            else:
                logger.error(f'No "{table}.txt" found!')
                df_list.append(None)
    
    if len(df_list) == 1:
        df_list = df_list[0]
    if return_date:
        return df_list, date
    else:
        return df_list


def df_from_feed_info(f):
    """
    Read data from feed_info.txt file.
    
    All columns are read as strings. Columns get renamed (see corresponding dict
    in the code).
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    feed_info = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'feed_publisher_name': str,
            'feed_publisher_url': str,
            'feed_lang': str,
            'feed_start_date': str,
            'feed_end_date': str,
            'feed_version': str,
            'feed_contact_mail': str,
            'feed_contact_url': str
        }
    )
    
    # rename columns
    feed_info = feed_info.rename(columns={
        'feed_publisher_name': 'publisher_name',
        'feed_publisher_url': 'publisher_url',
        'feed_lang': 'lang',
        'feed_start_date': 'start_date',
        'feed_end_date': 'end_date',
        'feed_version': 'version',
        'feed_contact_mail': 'contact_mail',
        'feed_contact_url': 'contact_url'
    })
    
    # write feed info to logs
    if len(feed_info) > 0:
        if 'publisher_name' not in feed_info.columns:
            logger.error(f'Required column "publisher_name" missing!')
        else:
            logger.info(f'Feed publisher: {feed_info.loc[0, 'publisher_name']}.')
        if 'version' in feed_info.columns:
            logger.info(f'Feed version: {feed_info.loc[0, 'version']}.')
    else:
        logger.error(f'File "feed_info.txt" does not contain any data rows!')
    
    return feed_info


def df_from_stops(f):
    """
    Read data from stops.txt file.
    
    All columns are read as strings except for stop_lat (float64), stop_lon
    (float64), location_type (uint8, empty values are set to 0),
    wheelchair_boarding (uint8). Columns get renamed (see corresponding dict in
    the code). Column stop_id is used as index. Column code is dropped.
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
   
    # read file
    stops = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'stop_id': str,
            'stop_code': str,
            'stop_name': str,
            'stop_desc': str,
            'stop_lat': np.float64,
            'stop_lon': np.float64,
            'location_type': str,
            'parent_station': str,
            'wheelchair_boarding': np.uint8,
            'platform_code': str,
            'level_id': str
        }
    )
    logger.info(f'Stop data has {len(stops)} items.')

    # rename columns
    stops = stops.rename(columns={
        'stop_id': 'id',
        'stop_code': 'code',
        'stop_name': 'name',
        'stop_desc': 'desc',
        'stop_lat': 'lat',
        'stop_lon': 'lon',
        'location_type': 'type',
        'parent_station': 'parent_id',
        'wheelchair_boarding': 'wheelchair',
        'platform_code': 'platform_code',
        'level_id': 'level_id'
    })

    # fill empty values in type column and set dtype
    if 'type' in stops.columns:
        stops.loc[stops['type'] == '', 'type'] = '0'
    else:
        stops['type'] = 0
    stops['type'] = stops['type'].astype(np.uint8)

    # use "id" column for index
    if stops['id'].duplicated().any():
        logger.warning('Column "id" contains duplicates!')
    stops = stops.set_index('id')

    # drop "code" column
    if 'code' in stops.columns:
        if (stops['code'] != '').any():
            logger.warning('Column "code" contains data! Dropping nevertheless.')
        stops = stops.drop(columns=['code'])

    return stops


def df_from_routes(f):
    """
    Read data from routes.txt file.
    
    All columns are read as strings except for route_type (uint16). Columns get
    renamed (see corresponding dict in the code). Column route_id is used as
    index.
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    routes = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'route_id': str,
            'agency_id': str,
            'route_short_name': str,
            'route_long_name': str,
            'route_type': np.uint16,
            'route_color': str,
            'route_text_color': str,
            'route_desc': str
        }
    )
    logger.info(f'Routes data has {len(routes)} items.')

    # rename columns
    routes = routes.rename(columns={
        'route_id': 'id',
        'agency_id': 'agency_id',
        'route_short_name': 'short_name',
        'route_long_name': 'long_name',
        'route_type': 'type',
        'route_color': 'color',
        'route_text_color': 'text_color',
        'route_desc': 'desc'
    })
    
    # use "id" column for index
    if routes['id'].duplicated().any():
        logger.error('Duplicate values in "id" column! Dropping nevertheless.')
    routes = routes.set_index('id')

    return routes


def df_from_trips(f):
    """
    Read data from trips.txt file.
    
    All columns are read as strings except for direction_id (uint8),
    wheelchair_accessible (uint8), bikes_allowed (uint8). Columns get renamed
    (see corresponding dict in the code). Column trip_id is used as index.
    Column wheelchair_accessible is dropped.
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    trips = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'route_id': str,
            'service_id': str,
            'trip_id': str,
            'trip_headsign': str,
            'trip_short_name': str,
            'direction_id': np.uint8,
            'block_id': str,
            'shape_id': str,
            'wheelchair_accessible': str,
            'bikes_allowed': str
        }
    )
    logger.info(f'Trips data has {len(trips)} items.')

    trips = trips.rename(columns={
        'route_id': 'route_id',
        'service_id': 'service_id',
        'trip_id': 'id',
        'trip_headsign': 'headsign',
        'trip_short_name': 'name',
        'direction_id': 'direction',
        'block_id': 'block',
        'shape_id': 'shape_id',
        'wheelchair_accessible': 'wheelchair',
        'bikes_allowed': 'bikes'
    })

    # use "id" column for index
    if trips['id'].duplicated().any():
        logger.error('Duplicate values in "id" column!')
    trips = trips.set_index('id')

    # drop "wheelchair" column
    if 'wheelchair' in trips.columns:
        if trips['wheelchair'].nunique(dropna=False) > 1:
            logger.warning('Data in "wheelchair" column! Dropping nevertheless.')
        trips = trips.drop(columns=['wheelchair'])

    # drop "bikes" column
    if 'bikes' in trips.columns:
        if trips['bikes'].nunique(dropna=False) > 1:
            logger.warning('Data in "bikes" column! Dropping nevertheless.')
        trips = trips.drop(columns=['bikes'])

    return trips


def df_from_stop_times(f):
    """
    Read data from stop_times.txt file.
    
    All columns are read as strings except for stop_sequence (uint16),
    pickup_type (uint8). Columns get renamed (see corresponding dict in the
    code).
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    stop_times = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'trip_id': str,
            'arrival_time': str,
            'departure_time': str,
            'stop_id': str,
            'stop_sequence': np.uint16,
            'pickup_type': np.uint8,
            'drop_off_type': str,
            'stop_headsign': str
        }
    )
    logger.info(f'Stop times data has {len(stop_times)} items.')

    # rename columns
    stop_times = stop_times.rename(columns={
        'trip_id': 'trip_id',
        'arrival_time': 'arrival',
        'departure_time': 'departure',
        'stop_id': 'stop_id',
        'stop_sequence': 'seq',
        'pickup_type': 'pickup',
        'drop_off_type': 'drop_off',
        'stop_headsign': 'headsign'
    })

    return stop_times


def df_from_agency(f):
    """
    Read data from agency.txt file.
    
    All columns are read as strings. Columns get renamed (see corresponding dict
    in the code). Column agency_id is used as index. Column lang is dropped.
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    agencies = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'agency_id': str,
            'agency_name': str,
            'agency_url': str,
            'agency_timezone': str,
            'agency_lang': str,
            'agency_phone': str
        }
    )
    logger.info(f'Agency data has {len(agencies)} items.')

    # rename columns
    agencies = agencies.rename(columns={
        'agency_id': 'id',
        'agency_name': 'name',
        'agency_url': 'url',
        'agency_timezone': 'timezone',
        'agency_lang': 'lang',
        'agency_phone': 'phone'
    })

    # use "id" column for index
    if agencies['id'].duplicated().any():
        logger.error('Duplicate values in "id" column!')
    agencies = agencies.set_index('id')

    # drop "lang" column
    if 'lang' in agencies.columns:
        if (agencies['lang'] != '').any():
            logger.warning('Column "lang" contains data! Dropping nevertheless.')
        agencies = agencies.drop(columns=['lang'])

    return agencies


def df_from_shapes(f):
    """
    Read data from shapes.txt file.
    
    All columns are read as float64 except for shape_id (str), shape_pt_sequence
    (uint16). Columns get renamed (see corresponding dict in the code).
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    shapes = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'shape_id': str,
            'shape_pt_lat': np.float64,
            'shape_pt_lon': np.float64,
            'shape_pt_sequence': np.uint16,
            'shape_dist_traveled': np.float64
        }
    )
    logger.info(f'Shapes data has {len(shapes)} items.')
    
    # rename columns
    shapes = shapes.rename(columns={
        'shape_id': 'id',
        'shape_pt_lat': 'lat',
        'shape_pt_lon': 'lon',
        'shape_pt_sequence': 'seq',
        'shape_dist_traveled': 'dist'
    })

    return shapes


def df_from_calendar(f):
    """
    Read data from calendar.txt file.
    
    All columns are read as uint8 except for service_id (str), start_date
    (datetime64), end_date (datetime64). Columns get renamed (see corresponding
    dict in the code). Column service_id is used as index.
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """

    # read file
    calendar = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'service_id': str,
            'monday': np.uint8,
            'tuesday': np.uint8,
            'wednesday': np.uint8,
            'thursday': np.uint8,
            'friday': np.uint8,
            'saturday': np.uint8,
            'sunday': np.uint8,
            'start_date': str,
            'end_date': str
        }
    )
    logger.info(f'Calendar data has {len(calendar)} items.')

    # rename columns
    calendar = calendar.rename(columns={
        'service_id': 'id',
        'monday': 'mon',
        'tuesday': 'tue',
        'wednesday': 'wed',
        'thursday': 'thu',
        'friday': 'fri',
        'saturday': 'sat',
        'sunday': 'sun',
        'start_date': 'start',
        'end_date': 'end'
    })

    # use "id" column for index
    if calendar['id'].duplicated().any():
        logger.error('Duplicate values in "id" column!')
    calendar = calendar.set_index('id')

    # str to datetime64
    calendar['start'] = pd.to_datetime(calendar['start'], format='%Y%m%d')
    calendar['end'] = pd.to_datetime(calendar['end'], format='%Y%m%d')

    return calendar


def df_from_calendar_dates(f):
    """
    Read data from calendar_dates.txt file.
    
    Column service_id is read as str, column date as datetime64 column
    exception_type as uint8. Columns get renamed (see corresponding dict in the
    code).
    
    Parameters
    ----------
    f : file object
        The file to read from.
    
    Returns
    -------
    pandas.DataFrame
        Data read.
    
    """
    
    # read file
    calendar_dates = pd.read_csv(
        f,
        keep_default_na=False,
        dtype={
            'service_id': str,
            'date': str,
            'exception_type': np.uint8
        }
    )
    logger.info(f'Calendar dates data has {len(calendar_dates)} items.')

    # rename columns
    calendar_dates = calendar_dates.rename(columns={
        'service_id': 'id',
        'date': 'date',
        'exception_type': 'type'
    })

    # str to datetime
    calendar_dates['date'] = pd.to_datetime(
        calendar_dates['date'], format='%Y%m%d'
    )

    return calendar_dates


def separate_stops_by_type(stops):
    """
    Separate stops into platforms, stations, misc objects.
    
    Location types are interpreted as follow:
    0 - platform,
    1 - station,
    2 - misc,
    3 - misc.
    
    Column type is dropped for platforms and stations. For stations columns
    parent_id, platform_code, level_id, desc are dropped, too.
    
    Parameters
    ----------
    stops : pandas.DataFrame
        Stops data as returned by df_from_zip.
    
    Returns
    -------
    tuple of 3 pandas.DataFrame
        Subsets of input DataFrame for platforms, stations, misc objects.
    """
    
    
    # separate
    if 'type' in stops.columns:
        platforms = stops.loc[stops['type'] == 0, :]
        stations = stops.loc[stops['type'] == 1, :]
        miscs = stops.loc[stops['type'].isin([2, 3]), :]
        platforms = platforms.drop(columns=['type'])
        stations = stations.drop(columns=['type'])
    else:
        platforms = stops
        stations = stops.loc[[], :]
        miscs = stops.loc[[], :]
    logger.info(f'{len(stops)} stops contain {len(stations)} stations, {len(platforms)} platforms, '
                f'{len(miscs)} misc objects, {len(stops) - len(stations) - len(platforms) - len(miscs)} unhandled objects.')
        
    # stations: drop unused columns
    cols = ['parent_id', 'platform_code', 'level_id', 'desc']
    cols = list(stations.columns.intersection(cols))
    for col in cols:
        if stations[col].nunique(dropna=False) > 1:
            logger.warning(f'Column "{col}" contains data for stations! Dropping nevertheless.')
    stations = stations.drop(columns=cols)

    return stations, platforms, miscs


class GTFSObject(stops.StopObject):
    """
    Represent a GTFS stop object.
    
    Attributes
    ----------
    all attributes of stops.StopObject objects and
    wheelchair : int
        Value of wheelchair_boarding column in GTFS stops.txt
    gtfs_name : str
        Stop name given in stops.txt. Attribute name may be set to a different
        value if more sensible for processing.
    
    """
    
    def __init__(self, type_, id_, name, lat, lon, wheelchair, source='gtfs'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon
            See stops.StopObject
        wheelchair : int
            Value of wheelchair_boarding column in GTFS stops.txt
    
        """

        super().__init__(source, type_, id_, name, lat, lon)

        self.wheelchair = int(wheelchair)
        
        self.gtfs_name = name

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['wheelchair'] = self.wheelchair
        data['gtfs_name'] = self.gtfs_name

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.wheelchair = json_dict['wheelchair']
        self.gtfs_name = json_dict['gtfs_name']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = GTFSObject('', '', '', 0, 0, 0, False)
        obj.fill_from_json(json_dict)
        return obj


class GTFSStation(GTFSObject):
    """
    Represent a GTFS station.
    
    Attributes
    ----------
    all attributes of GTFSObject objects and
    child_platforms : list of GTFSPlatform objects
        Platforms that have this station as parent
    child_miscs : list of GTFSMisc objects
        Misc objects that have this station as parent
    
    """

    def __init__(self, id_, name, lat, lon, wheelchair, source='gtfs'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon, wheelchair
            See GTFSObject
    
        """

        super().__init__('sp', id_, name, lat, lon, wheelchair,source=source)

        self.child_platforms = []
        self.child_miscs = []

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['child_platforms'] = [obj.uid for obj in self.child_platforms]
        data['child_miscs'] = [obj.uid for obj in self.child_miscs]

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.child_platforms = json_dict['child_platforms']
        self.child_miscs = json_dict['child_miscs']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = GTFSStation('', '', 0, 0, 0)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.child_platforms = \
            [stop_objs.loc[uid] for uid in self.child_platforms]
        self.child_miscs = [stop_objs.loc[uid] for uid in self.child_miscs]


class GTFSPlatform(GTFSObject):
    """
    Represent a GTFS platform.
    
    Attributes
    ----------
    all attributes of GTFSObject objects and
    parent : GTFSStation or None
        Parent station of the platform
    desc : str
        Value of stop_desc column in GTFS stops.txt
    platform_code : str
        Value of platform_code column in GTFS stops.txt
    level_id : str
        Value of level_id column in GTFS stops.txt
    
    """

    def __init__(self, id_, parent, name, lat, lon, desc, wheelchair,
                 platform_code, level_id, source='gtfs'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon, wheelchair
            See GTFSObject
        parent : GTFSStation or None
            Parent station of the platform
        desc : str
            Value of stop_desc column in GTFS stops.txt
        platform_code : str
            Value of platform_code column in GTFS stops.txt
        level_id : str
            Value of level_id column in GTFS stops.txt
    
        """

        super().__init__('pw', id_, name, lat, lon, wheelchair, source=source)

        self.parent = parent
        self.desc = desc
        self.platform_code = platform_code
        self.level_id = level_id

        if self.parent:
            self.parent.child_platforms.append(self)
        
        if self.platform_code != '':
            self.name = f'{self.gtfs_name}; {self.platform_code}'


    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['parent'] = self.parent.uid if self.parent else ''
        data['desc'] = self.desc
        data['platform_code'] = self.platform_code
        data['level_id'] = self.level_id

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.parent = json_dict['parent']
        self.desc = json_dict['desc']
        self.platform_code = json_dict['platform_code']
        self.level_id = json_dict['level_id']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = GTFSPlatform('', None, '', 0, 0, '', 0, '', '')
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.parent = stop_objs.loc[self.parent] if self.parent != '' else None


class GTFSMisc(GTFSObject):
    """
    Represent a misc GTFS stop object.
    
    Attributes
    ----------
    all attributes of GTFSObject objects and
    parent : GTFSStation or None
        Parent station of the platform
    desc : str
        Value of stop_desc column in GTFS stops.txt
    platform_code : str
        Value of platform_code column in GTFS stops.txt
    level_id : str
        Value of level_id column in GTFS stops.txt
    gtfs_type: int
        Value of location_type column in GTFS stops.txt
    
    """

    def __init__(self, id_, parent, name, lat, lon, desc, wheelchair, 
                 platform_code, level_id, gtfs_type, source='gtfs'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon, wheelchair
            See GTFSObject
        parent : GTFSStation or None
            Parent station of the platform
        desc : str
            Value of stop_desc column in GTFS stops.txt
        platform_code : str
            Value of platform_code column in GTFS stops.txt
        level_id : str
            Value of level_id column in GTFS stops.txt
        gtfs_type: int
            Value of location_type column in GTFS stops.txt
    
        """

        super().__init__('misc', id_, name, lat, lon, wheelchair, source=source)

        self.parent = parent
        self.desc = desc
        self.platform_code = platform_code
        self.level_id = level_id
        self.gtfs_type = int(gtfs_type)

        if self.parent:
            self.parent.child_miscs.append(self)
        
        if self.platform_code != '':
            self.name = f'{self.gtfs_name}; {self.platform_code}'

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['parent'] = self.parent.uid if self.parent else ''
        data['desc'] = self.desc
        data['platform_code'] = self.platform_code
        data['level_id'] = self.level_id
        data['gtfs_type'] = self.gtfs_type

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.parent = json_dict['parent']
        self.desc = json_dict['desc']
        self.platform_code = json_dict['platform_code']
        self.level_id = json_dict['level_id']
        self.gtfs_type = json_dict['gtfs_type']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = GTFSMisc('', None, '', 0, 0, '', 0, '', '', 2)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """

        self.parent = stop_objs.loc[self.parent] if self.parent != '' else None


def gdf_from_df(stations_df, platforms_df, miscs_df, source='gtfs'):
    """
    Create GeoDataFrame of GTFSObject objects from DataFrame.
        
    Parameters
    ----------
    stations_df : pandas.DataFrame
        DataFrame with GTFS stations data as returned by df_from_zip
    platforms_df : pandas.DataFrame
        DataFrame with GTFS platforms data as returned by df_from_zip
    miscs_df : pandas.DataFrame
        DataFrame with GTFS misc objects data as returned by df_from_zip
    source : str, optional
        Identifier for the data source. Should be unique within all sources
        used in a project.
        
    Returns
    -------
    tuple of 3 GeoDataFrames
        One GeoDataFrame for stations, one for platforms, one for misc objects.
        Index consists of UIDs. Columns are 'obj' holding corresponding
        GTFSObjects and 'geo' holding a shapely.Point with the object's
        geolocation.

    """

    logger.debug('Creating station objects...')

    # make station objects
    if 'wheelchair' not in stations_df.columns:
        stations_df = pd.concat((
            stations_df,
            pd.Series(index=stations_df.index, data=0, name='wheelchair')
        ), axis=1)
    cols = ['name', 'lat', 'lon', 'wheelchair']
    station_objs = stations_df[cols].apply(
        lambda x: GTFSStation(x.name, *x, source=source), axis=1
    )
    stations = stops.gdf_from_objects(station_objs)

    logger.debug('...done creating station objects.')

    logger.debug('Creating platform objects...')

    # get parent objects for platforms
    if 'parent_id' not in platforms_df.columns:
        platforms_df = pd.concat((
            platforms_df,
            pd.Series(index=platforms_df.index, data='', name='parent_id')
        ), axis=1)
    platforms_parents = platforms_df['parent_id'].apply(
        lambda pid: station_objs.loc[pid] \
                    if pid != '' and pid in station_objs.index else None
    )  # (redundant pid != '' test for performance reasons)
    platforms_parents.name = 'parent'

    # make platform objects
    if 'wheelchair' not in platforms_df.columns:
        platforms_df = pd.concat((
            platforms_df,
            pd.Series(index=platforms_df.index, data=0, name='wheelchair')
        ), axis=1)
    if 'desc' not in platforms_df.columns:
        platforms_df = pd.concat((
            platforms_df,
            pd.Series(index=platforms_df.index, data='', name='desc')
        ), axis=1)
    if 'level_id' not in platforms_df.columns:
        platforms_df = pd.concat((
            platforms_df,
            pd.Series(index=platforms_df.index, data='', name='level_id')
        ), axis=1)
    if 'platform_code' not in platforms_df.columns:
        platforms_df = pd.concat((
            platforms_df,
            pd.Series(index=platforms_df.index, data='', name='platform_code')
        ), axis=1)
    cols = ['parent', 'name', 'lat', 'lon', 'desc', 'wheelchair',
            'platform_code', 'level_id']
    platform_objs = pd.concat((platforms_parents, platforms_df), axis=1)[cols] \
        .apply(lambda x: GTFSPlatform(x.name, *x, source=source), axis=1)
    platforms = stops.gdf_from_objects(platform_objs)

    # add note to platforms with invalid parent ID
    no_parent_mask = platforms_parents.isna() & (platforms_df['parent_id'] != '')
    for id_ in platforms_df.index[no_parent_mask]:
        platform_objs.loc[id_].add_note(f'Has invalid parent ID "{platforms_df.loc[id_, 'parent_id']}" in GTFS data!')
    del no_parent_mask
    
    del platforms_parents
    
    logger.debug('...done creating platform objects.')

    logger.debug('Creating misc objects...')

    # get parent objects for miscs
    if 'parent_id' not in miscs_df.columns:
        miscs_df = pd.concat((
            miscs_df,
            pd.Series(index=miscs_df.index, data='', name='parent_id')
        ), axis=1)
    miscs_parents = miscs_df['parent_id'].apply(
        lambda pid: station_objs.loc[pid] \
                    if pid != '' and pid in station_objs.index else None
    )  # (redundant pid != '' test for performance reasons)
    miscs_parents.name = 'parent'

    # make misc objects
    if 'wheelchair' not in miscs_df.columns:
        miscs_df = pd.concat((
            miscs_df,
            pd.Series(index=miscs_df.index, data=0, name='wheelchair')
        ), axis=1)
    if 'desc' not in miscs_df.columns:
        miscs_df = pd.concat((
            miscs_df,
            pd.Series(index=miscs_df.index, data='', name='desc')
        ), axis=1)
    if 'level_id' not in miscs_df.columns:
        miscs_df = pd.concat((
            miscs_df,
            pd.Series(index=miscs_df.index, data='', name='level_id')
        ), axis=1)
    if 'platform_code' not in miscs_df.columns:
        miscs_df = pd.concat((
            miscs_df,
            pd.Series(index=miscs_df.index, data='', name='platform_code')
        ), axis=1)
    cols = ['parent', 'name', 'lat', 'lon', 'desc', 'wheelchair',
            'platform_code', 'level_id', 'type']
    misc_objs = pd.concat((miscs_parents, miscs_df), axis=1)[cols].apply(
        lambda x: GTFSMisc(x.name, *x, source=source), axis=1
    )
    miscs = stops.gdf_from_objects(misc_objs)

    # add note to misc objects with invalid parent ID
    no_parent_mask = miscs_parents.isna() & (miscs_df['parent_id'] != '')
    for id_ in miscs_df.index[no_parent_mask]:
        misc_objs.loc[id_].add_note(f'Has invalid parent ID "{miscs_df.loc[id_, 'parent_id']}" in GTFS data!')
    del no_parent_mask
    
    del miscs_parents
    
    logger.debug('...done creating misc objects.')

    return stations, platforms, miscs


def json_from_gdf(stations, platforms, miscs, path='gtfs_{subset}.json',
                  subsets=[('all', 'all', None)]):
    """
    Write data from GeoDataFrames of GTFSObject objects to JSON file.
        
    Subsets of the data may be chosen via subsets parameter. For each subset a
    separate JSON file will be written.
    
    Parameters
    ----------
    stations : geopandas.GeoDataFrame
        GeoDataFrame with GTFSStation objects as returned by df_to_gdf function.
    platforms : geopandas.GeoDataFrame
        GeoDataFrame with GTFSPlatform objects as returned by df_to_gdf
        function.
    miscs : geopandas.GeoDataFrame
        GeoDataFrame with GTFSMisc objects as returned by df_to_gdf function.
    path : str, optional
        Path of JSON file to write. The string has to contain "{subset}" which
        will be replaced by the subset name for each subset provided in the
        subsets parameter.
    subsets: list of (str, str, arbitrary type)
        For each item in the list a separate JSON file will be written. First
        item in each tupel is a subset's name (used for file name only), the
        second item is the subset type, the third is a parameter depending on
        the chosen type. Available types are:
        * 'all' - use all data (third tuple item is ignored)
        * 'bbox' - only include data covered by a bounding box (third tuple item
                   is a tuple (ymin, xmin, ymax, xmax) defining the bbox in the
                   data's CRS)
        
    Returns
    -------
    None

    """

    for subset_name, subset_mode, subset_param in subsets:

        logger.debug(f'Creating subset "{subset_name}"...')

        # filter data
        if subset_mode == 'bbox':
            subset_stations = stops.filter_by_bbox(stations, subset_param)
            subset_platforms = stops.filter_by_bbox(platforms, subset_param)
            subset_miscs = stops.filter_by_bbox(miscs, subset_param)
        else:  # all
            subset_stations = stations 
            subset_platforms = platforms
            subset_miscs = miscs

        # ensure that each subset's object's children and parent are in subset
        if subset_mode != 'all':

            # add parent stations for all platforms and misc objects
            def parent_uid(obj):
                return obj.parent.uid if obj.parent else None
            if len(subset_platforms) > 0:
                p_uids = set(subset_platforms['obj'].apply(parent_uid))
            else:
                p_uids = set()
            if len(subset_miscs) > 0:
                m_uids = set(subset_miscs['obj'].apply(parent_uid))
            else:
                m_uids = set()
            if len(p_uids) + len(m_uids) > 0:
                s_uids = (p_uids | m_uids) - {np.nan} - set(subset_stations.index)
                subset_stations = gpd.pd.concat(
                    (subset_stations, stations.loc[list(s_uids), :])
                )
                logger.debug(f'Added {len(s_uids)} parent stations not matching the subset\'s filter.')
        
            # add child platforms and misc objects for all stations
            if len(subset_stations) > 0:
                p_uids = set(subset_stations['obj']
                             .apply(lambda obj:
                                    [c.uid for c in obj.child_platforms])
                             .sum()) \
                         - set(subset_platforms.index)
                subset_platforms = gpd.pd.concat(
                    (subset_platforms, platforms.loc[list(p_uids), :])
                )
                logger.debug(f'Added {len(p_uids)} child platforms not matching the subset\'s filter.')
                m_uids = set(subset_stations['obj']
                            .apply(lambda obj: [c.uid for c in obj.child_miscs])
                            .sum()) \
                        - set(subset_miscs.index)
                subset_nodes = gpd.pd.concat(
                    (subset_miscs, miscs.loc[list(m_uids), :])
                )
                logger.debug(f'Added {len(p_uids)} child misc objects not matching the subset\'s filter.')
            
        # export as JSON
        data = {
            'stations': list(subset_stations['obj'] \
                        .apply(lambda obj: obj.to_json())),
            'platforms': list(subset_platforms['obj'] \
                         .apply(lambda obj: obj.to_json())),
            'miscs': list(subset_miscs['obj'].apply(lambda obj: obj.to_json()))
        }
        subset_path = path.format(subset=subset_name)
        with open(subset_path, 'w') as f:
            json.dump(data, f, indent=2)

        logger.debug(f'...done creating subset "{subset_name}".')
        logger.info(f'{len(subset_stations)} stations, {len(subset_platforms)} platforms, {len(subset_miscs)} misc objects written to "{subset_path}".')

    logger.info('...done creating subsets.')


def gdf_from_json(path):
    """
    Create GeoDataFrames of GTFSObject objects from JSON file.
        
    JSON file has to have the structure produced by json_from_gdf.
    
    Parameters
    ----------
    path : str
        Path of JSON file to read from.
        
    Returns
    -------
    (geopandas.GeoDataFrame, geopandas.GeoDataFrame, geopandas.GeoDataFrame)
        Stations, platforms, misc objects as GeoDataFrames of corresponding
        objects.

    """

    # read JSON file
    with open(path) as f:
        json_data = json.load(f)
        
    # make GeoDataFrames
    stations = stops.gdf_from_objects(
        [GTFSStation.from_json(obj_dict) for obj_dict in json_data['stations']]
    )
    platforms = stops.gdf_from_objects(
        [GTFSPlatform.from_json(obj_dict)
         for obj_dict in json_data['platforms']]
    )
    miscs = stops.gdf_from_objects(
        [GTFSMisc.from_json(obj_dict) for obj_dict in json_data['miscs']]
    )

    # replace object IDs by objects
    all_objs = pd.concat(
        (stations['obj'], platforms['obj'], miscs['obj']), axis=0
    )
    stations['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))
    platforms['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))
    miscs['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))

    logger.info(f'Found {len(stations)} stations, {len(platforms)} platforms, {len(miscs)} misc objects in "{path}".')
    
    return stations, platforms, miscs


def get_stop_routes(id_to_uid, times, trips, routes):
    """
    Get route information for each stop.
    
    Parameters
    ----------
    id_to_uid : dict
        Mapping of object IDs to object UIDs.
    times : pandas.DataFrame
        DataFrame of stop times as returned by df_from_zip.
    trips : pandas.DataFrame
        DataFrame of trips as returned by df_from_zip.
    routes : pandas.DataFrame
        DataFrame of routes as returned by df_from_zip.
    
    Returns
    -------
    dict of dicts
        Route information for each stop. Keys are stop UIDs, values are dicts
        with keys
        * 'routes' - set of route IDs,
        * 'route_types' - set of route types,
        * 'prev_stops' - set of stops appearing in routes before the stop,
        * 'next_stops' - set of stops appearing in routes after the stop.
    
    """

    logger.debug('Generating route information for stops...')

    # initialize dict with empty sets
    stop_routes = {
        id_to_uid.get(id_):dict(
            routes=set(), route_types=set(), prev_stops=set(), next_stops=set()
        )
        for id_ in times['stop_id'].unique()
    }
    if None in stop_routes.keys():  # only relevant if id_to_uid misses some IDs
        del stop_routes[None]

    # iterate over trips
    for trip_id, trip_times in times.groupby('trip_id', sort=False):

        route = trips.loc[trip_id, 'route_id']
        route_type = int(routes.loc[route, 'type'])
        stop_list = trip_times.sort_values('seq')['stop_id'].to_list()
        stop_list = [id_to_uid.get(id_) for id_ in stop_list]
        stop_list = [uid for uid in stop_list if uid]

        # set data for each stop in trip
        for i in range(len(stop_list)):
            stop_route = stop_routes[stop_list[i]]
            stop_route['routes'].add(route)
            stop_route['route_types'].add(route_type)
            if i > 0:
                stop_route['prev_stops'].add(stop_list[i - 1])
            if i < len(stop_list) - 1:
                stop_route['next_stops'].add(stop_list[i + 1])                

    logger.debug('...done generating route information for stops.')
    
    return stop_routes


def json_from_stop_routes(stop_routes, path):
    """
    Write route information for stops to JSON file.
    
    Parameters
    ----------
    stop_routes : dict
        Route information for stops as returned by get_stop_routes.
    path : str
        Path to write to.
    
    """
    
    # make lists from sets (JSON does not support sets)
    stop_routes = {uid: {k: list(v) for k, v in info.items()}
                                    for uid, info in stop_routes.items()}

    logger.info(f'Writing route information for stops to "{path}".')
    with open(path, 'w') as f:
        json.dump(stop_routes, f, indent=2)    


def stop_routes_from_json(path):
    """
    Read route information for stops from JSON file.
    
    Parameters
    ----------
    path : str
        Path to read from.
    
    Returns
    -------
    dict
        Route information for stops as dict of dicts like returned by
        get_stop_routes.
    
    """

    logger.info(f'Reading route information for stops from "{path}".')
    with open(path) as f:
        stop_routes = json.load(f)
        
    return stop_routes


def calendar_to_date_lists(calendar, calendar_dates):
    """
    Make lists of all service dates.
    
    Parameters
    ----------
    calendar: pandas.DataFrame
        Calendar data as returned by df_from_zip.
    calendar_dates: pandas.DataFrame
        Calendar dates data as returned by df_from_zip.
    
    Returns
    -------
    pandas.Series
        Each item is a list of datetime64 values. Index is like for calendar
        parameter.
    
    """
    
    date_lists = pd.Series(data=[[] for _ in calendar.index], index=calendar.index.copy())

    exception_dates = calendar_dates.groupby(['id', 'type'])
    weekday_cols = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']

    for id_ in date_lists.index:

        # collect weekdays with service
        service_weekdays = \
            calendar.loc[id_, weekday_cols].to_numpy().nonzero()[0]
        
        # collect all dates with service in service date range
        service_range = pd.date_range(
            calendar.loc[id_, 'start'], calendar.loc[id_, 'end']
        )
        service_dates = service_range[
            service_range.weekday.isin(service_weekdays)
        ]
 
        # add/remove exceptions
        if (id_, 1) in exception_dates.groups:
            service_dates = service_dates.union(
                exception_dates.get_group((id_, 1))['date']
            )
        if (id_, 2) in exception_dates.groups:
            service_dates = service_dates.difference(
                exception_dates.get_group((id_, 2))['date']
            )
        
        date_lists.loc[id_].extend(list(service_dates))
    
    return date_lists


def shapes_to_geo(shapes, mode='lines', crs='EPSG:4326'):
    """
    Convert shapes data to shapely geometries.
    
    Parameters
    ----------
    shapes : pandas.DataFrame
        Shapes data as returned by df_from_zip.
    mode : str, optional
        If 'lines', LineStrings are returned. If 'points', MultiPoints are
        returned. If 'both', both variants are returned.
    crs : str, optional
        CRS of input data's lat/lon columns. Everything understood by GeoPandas
        is allowed.
    
    Returns
    -------
    geopandas.GeoSeries or tuple of 2 geopandas.GeoSeries
        Generated geometries with same index as input DataFrame. If mode is
        'both', a tuple (points, lines) is returned.

    """
    
    if mode not in ['lines', 'points', 'both']:
        raise ValueError(f'Invalid value "{mode}" for mode argument!')
    
    shapes_grouped = (
        shapes.sort_values(['id', 'seq'])
        .groupby('id', sort=False)[['lon', 'lat']]
    )

    if mode in ['lines', 'both']:
        lines = shapes_grouped.apply(lambda coords:
            shapely.LineString(zip(list(coords['lon']), list(coords['lat'])))
        )
        lines = gpd.GeoSeries(lines, crs=crs)

    if mode in ['points', 'both']:
        points = shapes_grouped.apply(lambda coords: shapely.unary_union(
            [shapely.Point(lon, lat)
             for lon, lat in zip(list(coords['lon']), list(coords['lat']))]
        ))
        points = gpd.GeoSeries(points, crs=crs)
    
    if mode == 'lines':
        return lines
    if mode == 'points':
        return points
    if mode == 'both':
        return points, lines


