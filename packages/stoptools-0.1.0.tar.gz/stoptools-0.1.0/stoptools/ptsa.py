# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Load OSM stop data from PTSA.

OSMObject:
    Represent an OSM object (node, way, relation)
filesize2str:
    Make human-readable file size
overpass:
    Send query to Overpass API
df_from_ptsa:
    Download stop data from PTSA
PTSAObject:
    Represent a PTSA object
PTSAStopPlace:
    Represent a PTSA stop place object
PTSAStop:
    Represent a PTSA stop object
gdf_from_df:
    Create GeoDataFrames of PTSAObject objects from DataFrames
json_from_gdf:
    Write data from GeoDataFrames of PTSAObject objects to JSON file
gdf_from_json:
    Create GeoDataFrames of PTSAObject objects from JSON file
get_stop_routes:
    Get route information for each stop
json_from_stop_routes:
    Write route information for stops to JSON file
stop_routes_from_json:
    Read route information for stops from JSON file

"""

import collections
import json
import logging

import geopandas as gpd
import numpy as np
import pandas as pd
import requests
import shapely

from . import stops as stoptools_stops


logger = logging.getLogger(__name__)


class OSMObject:
    """
    Represent an OSM object (node, way, relation).

    Attributes
    ----------
    type : str
        Object type ('node' or 'way' or 'relation').
    id : int
        OSM ID of the object.
    tags : dict
        Tags associated with the object.
    members : list or None
        List of member IDs (None if node).

    """

    def __init__(self, j):
        """
        Parameters
        ----------
        j : dict
            The object's JSON data obtained from Overpass API.

        """

        self.type = j['type']
        self.id = j['id']
        self.tags = j['tags'] if j.get('tags') else dict()
        self.members = j.get('members')

    def __str__(self):

        return f'{self.type} {self.id}'

    def __repr__(self):

        return f'{self.type} {self.id}'
    
    def has_tag(self, key, value):
        """
        Check wether object has specified key value combination.
    
        Also works if a key is has multiple values. First compares the whole tag
        value to the passed value. If this doesn't match, tag value is split at
        ';' and each part is compared to the passed value string.
        
        Parameters
        ----------
        key : str
            Tag name.
        value : str
            Tab value.
        
        Returns
        -------
        bool
            True, if object has specified tag. False else.

        """

        # key exists?
        obj_value = self.tags.get(key)
        if not obj_value:
            return False

        # correct value?
        if obj_value == value:
            return True

        # correct value if we allow for multiple values?
        if value in obj_value.split(';'):
            return True

        # no match
        return False


def filesize2str(size):
    """
    Make human-readable file size (byte, kb, MB, GB).
    
    Parameters
    ----------
    size : int
        File size in bytes.
    value : str
        Tab value.
    
    Returns
    -------
    str
        String '123 kB' where 123 is som integer and kB is some unit.

    """

    if size < 1000:
        return f'{size} byte'
    elif size < 1000 ** 2:
        return f'{size / 1000:.0f} kB'
    elif size < 1000 ** 3:
        return f'{size / (1000 ** 2):.0f} MB'
    else:
        return f'{size / (1000 ** 3):.0f} GB'
    

def overpass(query, url=None, api_key=None, timeout=None):
    """
    Send query to Overpass API.
    
    Parameters
    ----------
    query : str
        Overpass query without preamble.
    url : str, optional
        Overpass URL. Defaults to overpass-api.de.
    api_key : str, optional
        API key for Overpass API. Defaults to '' (no API key required by
        server).
    timeout : int, optional
        Timeout setting to use in Overpass query. Defaults to 120 seconds.
    
    Returns
    -------
    list of OSMObject
        All OSM objects returned by Overpass API.

    """

    # default Overpass config
    if url is None:
        url = 'https://overpass-api.de/api/interpreter'
    if api_key is None:
        api_key = ''
    if timeout is None:
        timeout = 120

    # request
    preamble = f'[output: json][timeout: {timeout}];\n'
    r = requests.post(
        url, data={'data': preamble + query}, headers={'X-API-Key': api_key}
    )
    logger.debug(f'Overpass download size: {filesize2str(len(r.content))}')
    if r.status_code != 200:
        logger.error(f'Overpass server returned {r.status_code} for query\n{query}')
        return []
    
    # extract data from response
    j = r.json()
    objs = j['elements']

    # check for errors in response
    if j.get('remarks'):
        logger.warning(f'Overpass remarks: {j['remarks']}')
        return []
    if len(objs) == 0:
        logger.error(f'Overpass did not return any objects. Instead it returned\n{r.content.decode()}')

    return [OSMObject(obj) for obj in objs]


def df_from_ptsa(ptsa_url, regions, overpass_url=None, overpass_api_key=None,
                 overpass_timeout=None):
    """
    Download stop data from PTSA and return as DataFrames.
    
    Note that as long as PTSA does not support stop places, stop places objects
    are generated directly from OSM stop area relations.

    Parameters
    ----------
    ptsa_url : str
        URL of PTSA service to use.
    regions : list of str
        List of PTSA region codes to download data for.
    overpass_url : str, optional
        URL of Overpass API (see function overpass for default value).
    overpass_api_key : str, optional
        API key Overpass API (see function overpass for default value).
    overpass_timeout : str, optional
        Timeout setting for Overpass query (see function overpass for default
        value).
    
    Returns
    -------
    pandas.DataFrame
        DataFrame of stop places with columns
        * id - region code plus PTSA stop place ID,
        * lon - longitude of stop place,
        * lat - latitude,
        * stop_ids - list of PTSA stop IDs,
        * osm_obj - OSMObject of stop area.
    pandas.DataFrame
        DataFrame of stops with columns
        * id - region code plus PTSA stop ID,
        * lon - longitude of stop,
        * lat - latitude,
        * mods - list of modalities,
        * maybe_mods - list of maybe modalities,
        * plafo - OSMObject of platform,
        * pole - OSMObject of pole,
        * stopo - OSMObject of stop position,
        * stop_place_id - ID of stop place.

    """

    # download stop data from PTSA
    dfs = []
    for code in regions:
        code = code.lower()
        try:
            df = pd.read_csv(
                f'{ptsa_url}/data/{code}_stops.csv',
                keep_default_na=False,
                dtype={
                    'id': np.uint32,
                    'lon': np.float64,
                    'lat': np.float64,
                    'plafo_id': np.int64,
                    'pole_id': np.int64,
                    'stopo_id': np.int64,
                    'mods': str,
                    'maybe_mods': str
                }
            )
        except Exception as e:
            logger.exception(e)
            continue
        logger.debug(f'PTSA region "{code}" has {len(df)} stops.')
        df['id'] = df['id'].apply(lambda i: f'{code.replace('-', '_')}_{i}')
        df = df.set_index('id')
        dfs.append(df)
    if len(dfs) > 0:
        stops = pd.concat(dfs, axis=0)
    else:
        logger.error('Could not retrieve any stops from PTSA!')
        return None, None
    
    # mods strings to lists
    mods_list = lambda mods: mods.split(', ') if mods != 'NO_MODALITY' else []
    stops['mods'] = stops['mods'].apply(mods_list)
    stops['maybe_mods'] = stops['maybe_mods'].apply(mods_list)    

    # stop position and pole IDs to OSMObject
    logger.info('Downloading OSM data for stop positions and poles...')
    node_ids = list(stops.loc[stops['pole_id'] > 0, 'pole_id'].unique()) \
               + list(stops.loc[stops['stopo_id'] > 0, 'stopo_id'].unique())
    if len(node_ids) > 0:
        query = f'node(id: {','.join([str(id_) for id_ in node_ids])});out tags;'
        osm_objects = overpass(
            query, overpass_url, overpass_api_key, overpass_timeout
        )
        if len(osm_objects) != len(node_ids):
            logger.warning(f'From {len(node_ids)} nodes only {len(osm_objects)} have been found by Overpass!')
        nodes_dict = {obj.id: obj for obj in osm_objects}
        id_to_node = lambda i: nodes_dict.get(i) if i > 0 else None
        stops['pole'] = stops['pole_id'].apply(id_to_node)
        stops['stopo'] = stops['stopo_id'].apply(id_to_node)    
    logger.info('...done downloading OSM data.')

    # platform IDs to OSMObject
    logger.info('Downloading OSM data for platforms...')
    way_ids = list(stops.loc[stops['plafo_id'] > 0, 'plafo_id'].unique())
    rel_ids = list(-stops.loc[stops['plafo_id'] < 0, 'plafo_id'].unique())
    if len(way_ids) > 0:
        query = f'way(id: {','.join([str(id_) for id_ in way_ids])});out tags;'
        osm_objects = overpass(
            query, overpass_url, overpass_api_key, overpass_timeout
        )
        if len(osm_objects) != len(way_ids):
            logger.warning(f'From {len(way_ids)} ways only {len(osm_objects)} have been found by Overpass!')
        ways_dict = {obj.id: obj for obj in osm_objects}
    else:
        ways_dict = dict()
    if len(rel_ids) > 0:
        query = f'relation(id: {','.join([str(id_) for id_ in rel_ids])});out tags;'
        osm_objects = overpass(
            query, overpass_url, overpass_api_key, overpass_timeout
        )
        if len(osm_objects) != len(rel_ids):
            logger.warning(f'From {len(rel_ids)} relations only {len(osm_objects)} have been found by Overpass!')
        rels_dict = {obj.id: obj for obj in osm_objects}
    else:
        rels_dict = dict()
    stops['plafo'] = stops['plafo_id'].apply(lambda i:
        ways_dict.get(i) if i > 0 else (rels_dict.get(i) if i < 0 else None)
    )
    logger.info('...done downloading OSM data.')
    
    # drop unused columns
    stops = stops.drop(columns=['plafo_id', 'pole_id', 'stopo_id'])
    
    # get OSM IDs of region relations (preparation for downloading stop areas)
    try:
        regions_df = pd.read_csv(
            f'{ptsa_url}/data/regions.csv',
            keep_default_na=False,
            usecols=['osm_id', 'code'],
            dtype={
                'osm_id': np.uint64,
                'code': str
            }
        )
    except Exception as e:
        logger.exception(e)
    regions_df['code'] = regions_df['code'].str.lower()
    regions_df = regions_df.set_index('code')
    
    # download stop areas from OSM
    dfs = []
    for code in regions:
        code = code.lower()
        logger.info(f'Downloading OSM stop areas for region "{code}"...')
        query = f'''
        area({regions_df.loc[code, 'osm_id'] + 3600000000})->.roi;
        relation[public_transport=stop_area](area.roi);
        out;
        '''
        osm_objects = overpass(
            query, overpass_url, overpass_api_key, overpass_timeout
        )
        logger.info('...done downloading OSM data.')
        df = pd.DataFrame(
            index=[f'{code.replace('-', '_')}_{obj.id}' for obj in osm_objects],
            data={'osm_obj': osm_objects}
        )
        df.index.name = 'id'
        dfs.append(df)
        logger.debug(f'PTSA region "{code}" has {len(df)} stop places.')
    if len(dfs) > 0:
        places = pd.concat(dfs, axis=0)
    else:
        logger.error('Could not retrieve any stop places from PTSA!')
        places = None

    # assign stops to stop places
    stops['stop_place_id'] = ''
    places['stop_ids'] = [[] for _ in places.index]
    nodes_to_areas = {m['ref']: r for r in places['osm_obj'] for m in r.members
                                  if r.members and m['type'] == 'node'}
    ways_to_areas = {m['ref']: r for r in places['osm_obj'] for m in r.members
                                 if r.members and m['type'] == 'way'}
    rels_to_areas = {m['ref']: r for r in places['osm_obj'] for m in r.members
                                 if r.members and m['type'] == 'relation'}
    osm_id_to_place_id = {places.loc[place_id, 'osm_obj'].id: place_id
                          for place_id in places.index}
    for stop_id in stops.index:
        stop = stops.loc[stop_id, :]
        areas = set()
        if stop['pole']:
            areas.add(nodes_to_areas.get(stop['pole'].id))
        if stop['plafo']:
            if stop['plafo'].type == 'way':
                areas.add(ways_to_areas.get(stop['plafo'].id))
            elif stop['plafo'].type == 'relation':
                areas.add(rels_to_areas.get(stop['plafo'].id))
        if stop['stopo']:
            areas.add(nodes_to_areas.get(stop['stopo'].id))
        areas -= {None}
        if len(areas) > 1:
            logger.warning(f'Stop {stop_id} has components from different stop areas! Choosing one at random.')
        if len(areas) > 0:
            stop_place_id = osm_id_to_place_id[next(iter(areas)).id]
            stops.loc[stop_id, 'stop_place_id'] = stop_place_id
            places.loc[stop_place_id, 'stop_ids'].append(stop_id)

    # drop stop places without members
    mask = places['stop_ids'].apply(lambda s: len(s) > 0)
    places = places.loc[mask, :]
    if mask.sum() < len(places):
        logger.info(f'Dropping {len(places) - mask.sum()} stop places that do not have any stop.')

    # set lat/lon of stop places
    def get_coords(stop_ids):
        stops_coords = stops.loc[stop_ids, ['lon', 'lat']]
        coords = list(zip(stops_coords['lon'], stops_coords['lat']))
        centroid = shapely.centroid(shapely.MultiPoint(coords))
        return (centroid.x, centroid.y)
    coords = places['stop_ids'].apply(get_coords)
    places['lon'] = coords.apply(lambda c: c[0])
    places['lat'] = coords.apply(lambda c: c[1])

    return places, stops


class PTSAObject(stoptools_stops.StopObject):
    """
    Represent a PTSA object.
    
    Attributes
    ----------
    all attributes of stoptools_stops.StopObject objects and
    
    """
    
    def __init__(self, type_, id_, name, lat, lon, source='ptsa'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon
            See stops.StopObject
    
        """

        super().__init__(source, type_, id_, name, lat, lon)

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = PTSAObject('', '', '', 0, 0)
        obj.fill_from_json(json_dict)
        return obj


class PTSAStopPlace(PTSAObject):
    """
    Represent a PTSA stop place.
    
    Attributes
    ----------
    all attributes of PTSAObject objects and
    stops : list of PTSAStop objects
        PTSA stop objects for this stop place.
    ref : str
        ref value.
    iftop : str
        IFOPT of stop area.
    
    """
    
    def __init__(self, id_, name, lat, lon, ref, ifopt, source='ptsa'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon
            See stoptools_stops.StopObject
        ref : str
            OSM's ref value.
        ifopt : str
            OSM's ref:IFOPT value.
    
        """

        super().__init__('sp', id_, name, lat, lon, source=source)
        
        self.stops = []
        self.ref = ref
        self.ifopt = ifopt
        
    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['stops'] = [obj.uid for obj in self.stops]
        data['ref'] = self.ref if self.ref else ''
        data['ifopt'] = self.ifopt if self.ifopt else ''

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.stops = json_dict['stops']
        self.ref = json_dict['ref'] if json_dict['ref'] != '' else None
        self.ifopt = json_dict['ifopt'] if json_dict['ifopt'] != '' else None

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = PTSAStopPlace('', '', 0, 0, None, None)
        obj.fill_from_json(json_dict)
        return obj


    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.stops = [stop_objs.loc[uid] for uid in self.stops]


class PTSAStop(PTSAObject):
    """
    Represent a PTSA stop object.
    
    Attributes
    ----------
    all attributes of PTSAObject objects and
    names : list of str
        name values of stop's OSM objects.
    mods : list of str
        Modalities of stop.
    maybe_mods : list of str
        Maybe modalities of stop.
    stopo_id : int
        OSM ID of stop position.
    pole_id : int
        OSM ID of pole.
    plafo_id : int
        OSM ID of platform.
    refs : list of str
        ref values of stop's OSM objects.
    iftop : str
        IFOPT of stop (deduced from OSM objects' IFOPTs).
    shelter : int
        Stop has shelter (0 for "unknown", -1/1 for "no"/"yes")?
    tactile : int
        Stop has tactile paving (0 for "unknown", -1/1 for "no"/"yes")?
    stop_place : PTSAStopPlace
        Stop place the stop belongs to.
    
    """
    
    def __init__(self, id_, lat, lon, plafo, pole, stopo, mods, maybe_mods, 
                 stop_place, source='ptsa'):
        """
        Parameters
        ----------
        source, type_, id_, lat, lon
            See stops.StopObject
        plafo : OSMObject
            OSM object for platform.
        pole : OSMObject
            OSM object for pole.
        stopo : OSMObject
            OSM object for sotp position.
        mods : list of str
            Modalities of stop.
        maybe_mods : list of str
            Maybe modalities of stop.
        stop_place : PTSAStopPlace
            Stop place the stop belongs to.
    
        """

        # collect names
        self.names = []
        if pole and 'name' in pole.tags:
            self.names.append(pole.tags['name'])
        if plafo and 'name' in plafo.tags:
            self.names.append(plafo.tags['name'])
        if stopo and 'name' in stopo.tags:
            self.names.append(stopo.tags['name'])
        if pole and 'ref_name' in pole.tags:
            self.names.append(pole.tags['ref_name'])
        if plafo and 'ref_name' in plafo.tags:
            self.names.append(plafo.tags['ref_name'])
        if stopo and 'ref_name' in stopo.tags:
            self.names.append(stopo.tags['ref_name'])
        if stop_place and stop_place.name:
            self.names.append(stop_place.name)

        # get name for stop and clean up names list
        if len(self.names) > 0:
            name = self.names[0]
            self.names = list(set(self.names))
        else:
            name = ''

        # fill common stop object fields
        super().__init__('pw', id_, name, lat, lon, source=source)
        
        # check for missing name
        if name == '' and (plafo or pole or stopo):
            # note: creating an OSMStop object from JSON will call the
            #       constructor with plafo, pole, stopo all None
            self.add_note('No stop component has a name tag!', log=False)

        # modalities and OSM IDs
        self.mods = mods
        self.maybe_mods = maybe_mods
        self.stopo_id = stopo.id if stopo else 0
        self.pole_id = pole.id if pole else 0
        self.plafo_id = (plafo.id if plafo.type == 'way' else -plafo.id) \
                        if plafo else 0

        # stop place
        self.stop_place = stop_place
        if stop_place:
            stop_place.stops.append(self)

        # refs
        self.refs = set()
        pole_refs = set()
        stopo_refs = set()
        plafo_refs = set()
        if pole and 'ref' in pole.tags:
            pole_refs |= set(pole.tags['ref'].split(';'))
        if pole and 'local_ref' in pole.tags:
            pole_refs |= set(pole.tags['local_ref'].split(';'))
        if stopo and 'ref' in stopo.tags:
            stopo_refs |= set(stopo.tags['ref'].split(';'))
        if stopo and 'local_ref' in stopo.tags:
            stopo_refs |= set(stopo.tags['local_ref'].split(';'))
        if plafo and 'ref' in plafo.tags:
            plafo_refs |= set(plafo.tags['ref'].split(';'))
        if plafo and 'local_ref' in plafo.tags:
            plafo_refs |= set(plafo.tags['local_ref'].split(';'))
        if len(pole_refs) > 0:
            self.refs = pole_refs
        if len(stopo_refs) > 0 and stopo_refs & self.refs != set():
            self.refs = stopo_refs & self.refs
        else:
            self.refs |= stopo_refs
        if len(plafo_refs) > 0 and plafo_refs & self.refs != set():
            self.refs = plafo_refs & self.refs
        else:
            self.refs |= plafo_refs
        self.refs = list(self.refs)

        # IFOPT
        ifopts = []
        if pole and 'ref:IFOPT' in pole.tags:
            ifopts.extend(pole.tags['ref:IFOPT'].split(';'))
        if plafo and 'ref:IFOPT' in plafo.tags:
            ifopts.extend(plafo.tags['ref:IFOPT'].split(';'))
        if stopo and 'ref:IFOPT' in stopo.tags:
            ifopts.extend(stopo.tags['ref:IFOPT'].split(';'))
        if len(ifopts) == 0:
            self.ifopt = None
        else:
            ifopt_set = set(ifopts)
            if len(ifopt_set) == 1:
                self.ifopt = next(iter(ifopt_set))
            else:
                # remove IFOPTs that are parents of other IFOPTs
                ifopts = [
                    i1 for i1 in ifopt_set \
                    if all([not i2.startswith(i1) for i2 in ifopt_set - {i1}])
                ]
                # choose most common IFOPT
                self.ifopt = collections.Counter(ifopts).most_common(1)[0][0]
        
        # shelter
        self.shelter = 0
        if pole and pole.has_tag('shelter', 'yes'):
            self.shelter = 1
        if pole and pole.has_tag('shelter', 'no'):
            self.shelter = -1
        if plafo and plafo.has_tag('shelter', 'yes'):
            self.shelter = 1
        if plafo and plafo.has_tag('shelter', 'no'):
            self.shelter = -1
        
        # tactile paving
        self.tactile = 0
        if pole and pole.has_tag('tactile_paving', 'yes'):
            self.tactile = 1
        if pole and pole.has_tag('tactile_paving', 'incorrect'):
            self.tactile = 1
        if pole and pole.has_tag('tactile_paving', 'no'):
            self.tactile = -1
        if plafo and plafo.has_tag('tactile_paving', 'yes'):
            self.tactile = 1
        if plafo and plafo.has_tag('tactile_paving', 'incorrect'):
            self.tactile = 1
        if plafo and plafo.has_tag('tactile_paving', 'no'):
            self.tactile = -1
        
    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['names'] = self.names
        data['mods'] = self.mods
        data['maybe_mods'] = self.maybe_mods
        data['stopo_id'] = self.stopo_id
        data['pole_id'] = self.pole_id
        data['plafo_id'] = self.plafo_id
        data['refs'] = self.refs
        data['ifopt'] = self.ifopt if self.ifopt else ''
        data['shelter'] = self.shelter
        data['tactile'] = self.tactile
        data['stop_place'] = self.stop_place.uid if self.stop_place else ''

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.names = json_dict['names']
        self.mods = json_dict['mods']
        self.maybe_mods = json_dict['maybe_mods']
        self.stopo_id= json_dict['stopo_id']
        self.pole_id= json_dict['pole_id']
        self.plafo_id= json_dict['plafo_id']
        self.refs = json_dict['refs']
        self.ifopt = json_dict['ifopt'] if json_dict['ifopt'] != '' else None
        self.shelter = json_dict['shelter']
        self.tactile = json_dict['tactile']
        self.stop_place= json_dict['stop_place']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = PTSAStop('', 0, 0, None, None, None, [], [], None)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.stop_place = stop_objs.loc[self.stop_place] \
                          if self.stop_place != '' else None


def gdf_from_df(places_df, stops_df, source='ptsa'):
    """
    Create GeoDataFrames of PTSAObject objects from DataFrames.

    Parameters
    ----------
    places_df : pandas.DataFrame
        DataFrame with PTSA stop place data returned by df_from_ptsa.
    stops_df : pandas.DataFrame
        DataFrame with PTSA stop data returned by df_from_ptsa.
    source : str, optional
        Identifier for the data source. Should be unique within all sources
        used in a project.
        
    Returns
    -------
    GeoDataFrame
        GeoDataFrame of PTSAStopPlace objects. Index consists of UIDs. Columns
        are 'obj' holding corresponding PTSAObject objects and 'geo' holding a
        shapely.Point with the object's geolocation.
    GeoDataFrame
        GeoDataFrame of PTSAStop objects. Index consists of UIDs. Columns are
        'obj' holding corresponding PTSAObject objects and 'geo' holding a
        shapely.Point with the object's geolocation.

    """

    logger.debug('Creating stop place objects...')

    # make place objects
    def get_tag_value(obj, key):
        value = obj.tags.get(key)
        return value if value else ''
    names_col = places_df['osm_obj'].apply(
        lambda obj: get_tag_value(obj, 'name')
    )
    names_col.name = 'name'
    refs_col = places_df['osm_obj'].apply(
        lambda obj: get_tag_value(obj, 'ref')
    )
    refs_col.name = 'ref'
    ifopts_col = places_df['osm_obj'].apply(
        lambda obj: get_tag_value(obj, 'ref:IFOPT')
    )
    ifopts_col.name = 'ifopt'
    cols = ['name', 'lat', 'lon', 'ref', 'ifopt']
    place_objs = pd.concat(
        (names_col, refs_col, ifopts_col, places_df), axis=1
    )[cols].apply(lambda x: PTSAStopPlace(x.name, *x, source=source), axis=1)
    places = stoptools_stops.gdf_from_objects(place_objs)

    logger.debug('...done creating stop place objects.')

    logger.debug('Creating stop objects...')

    # make stop objects
    places_col = stops_df['stop_place_id'].apply(
        lambda pid: place_objs.loc[pid] if pid in place_objs.index else None
    )
    places_col.name = 'stop_place'
    cols = [
        'lat', 'lon', 'plafo', 'pole', 'stopo', 'mods', 'maybe_mods',
        'stop_place'
    ]
    stop_objs = pd.concat((places_col, stops_df), axis=1)[cols].apply(
        lambda x: PTSAStop(x.name, *x, source=source), axis=1
    )
    stops = stoptools_stops.gdf_from_objects(stop_objs)
    
    logger.debug('...done creating stop objects.')

    return places, stops


def json_from_gdf(places, stops, path='ptsa_{subset}.json',
                  subsets=[('all', 'all', None)]):
    """
    Write data from GeoDataFrames of GTFSObject objects to JSON file.
        
    Subsets of the data may be chosen via subsets parameter. For each subset a
    separate JSON file will be written.
    
    Parameters
    ----------
    places : geopandas.GeoDataFrame
        GeoDataFrame with PTSAStopPlace objects as returned by df_to_gdf
        function.
    stops : geopandas.GeoDataFrame
        GeoDataFrame with PTSAStop objects as returned by df_to_gdf function.
    path : str, optional
        Path of JSON file to write. The string has to contain "{subset}" which
        will be replaced by the subset name for each subset provided in the
        subsets parameter.
    subsets: list of (str, str, arbitrary type)
        For each item in the list a separate JSON file will be written. First
        item in each tupel is a subset's name (used for file name only), the
        second item is the subset type, the third is a parameter depending on
        the chosen type. Available types are:
        * 'all' - use all data (third tuple item is ignored)
        * 'bbox' - only include data covered by a bounding box (third tuple item
                   is a tuple (ymin, xmin, ymax, xmax) defining the bbox in the
                   data's CRS)
        
    Returns
    -------
    None

    """

    for subset_name, subset_mode, subset_param in subsets:

        logger.debug(f'Creating subset "{subset_name}"...')

        # filter data
        if subset_mode == 'bbox':
            subset_places = stoptools_stops.filter_by_bbox(places, subset_param)
            subset_stops = stoptools_stops.filter_by_bbox(stops, subset_param)
        else:  # all
            subset_places = places
            subset_stops = stops

        # ensure that each subset's object's children and parent are in subset
        if subset_mode != 'all':

            # add stop places for all stops
            if len(subset_stops) > 0:
                def place_uid(obj):
                    return obj.stop_place.uid if obj.stop_place else None
                p_uids = set(subset_stops['obj'].apply(place_uid)) - {None} \
                        - set(subset_places.index)
                subset_places = gpd.pd.concat(
                    (subset_places, places.loc[list(p_uids), :])
                )
                logger.debug(f'Added {len(p_uids)} stop places not matching the subset\'s filter.')
        
            # add stops for all stop places
            if len(subset_places) > 0:
                s_uids = set(subset_places['obj']
                            .apply(lambda obj: [s.uid for s in obj.stops])
                            .sum()) \
                        - set(subset_stops.index)
                subset_stops = gpd.pd.concat(
                    (subset_stops, stops.loc[list(s_uids), :])
                )
                logger.debug(f'Added {len(s_uids)} stops not matching the subset\'s filter.')
            
        # export as JSON
        data = {
            'places': list(subset_places['obj'] \
                      .apply(lambda obj: obj.to_json())),
            'stops': list(subset_stops['obj'].apply(lambda obj: obj.to_json()))
        }
        subset_path = path.format(subset=subset_name)
        with open(subset_path, 'w') as f:
            json.dump(data, f, indent=2)

        logger.debug(f'...done creating subset "{subset_name}".')
        logger.info(f'{len(subset_places)} places, {len(subset_stops)} stops written to "{subset_path}".')

    logger.info('...done creating subsets.')


def gdf_from_json(path):
    """
    Create GeoDataFrames of PTSAObject objects from JSON file.
        
    JSON file has to have the structure produced by json_from_gdf.
    
    Parameters
    ----------
    path : str
        Path of JSON file to read from.
        
    Returns
    -------
    (geopandas.GeoDataFrame, geopandas.GeoDataFrame)
        Stop places and stops as GeoDataFrames of corresponding objects.

    """

    # read JSON file
    with open(path) as f:
        json_data = json.load(f)
        
    # make GeoDataFrames
    places = stoptools_stops.gdf_from_objects(
        [PTSAStopPlace.from_json(obj_dict) for obj_dict in json_data['places']]
    )
    stops = stoptools_stops.gdf_from_objects(
        [PTSAStop.from_json(obj_dict)
         for obj_dict in json_data['stops']]
    )

    # replace object IDs by objects
    all_objs = pd.concat((places['obj'], stops['obj']), axis=0)
    places['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))
    stops['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))

    logger.info(f'Found {len(places)} stop places, {len(stops)} stops in "{path}".')
    
    return places, stops


def get_stop_routes(stops, overpass_url=None, overpass_api_key=None,
                    overpass_timeout=None, route_download_chunks=10):
    """
    Get route information for each stop.
    
    Parameters
    ----------
    stops : geopandas.GeoDataFrame
        Stops as returned by gdf_from_df
    overpass_url : str, optional
        URL of Overpass API (see function overpass for default value).
    overpass_api_key : str, optional
        API key Overpass API (see function overpass for default value).
    overpass_timeout : str, optional
        Timeout setting for Overpass query (see function overpass for default
        value).
    route_download_chunks : int, optional
        Number of chunks for downloading route data via Overpass. The more
        chunks the smaller the requests.
    
    Returns
    -------
    dict of dicts
        Route information for each stop. Keys are stop IDs, values are dicts
        with keys
        * 'routes' - set of route IDs (OSM ID of corresponding relation),
        * 'route_types' - set of route types (OSM route type string),
        * 'prev_stops' - set of stops appearing in routes before the stop,
        * 'next_stops' - set of stops appearing in routes after the stop.
    
    """

    logger.info('Generating route information for stops...')

    relevant_route_types = [
        'bus', 'trolleybus', 'ferry', 'train', 'subway', 'light_rail', 'tram',
        'funicular', 'aerialway', 'share_taxi', 'monorail'
    ]

    # map stop components to stops (also consider combinations that may appear
    # in routes; PTv2 allows for one or two stop components in routes)
    # stopo+pole --> stop
    # stopo+plafo --> stop
    # stopo --> stop
    # pole --> stop
    # plafo --> stop
    stopos_poles_to_stops = dict()
    stopos_plafos_to_stops = dict()
    stopos_to_stops = dict()
    poles_to_stops = dict()
    plafos_to_stops = dict()
    for uid in stops.index:
        stopo_id = stops.loc[uid, 'obj'].stopo_id
        pole_id = stops.loc[uid, 'obj'].pole_id
        plafo_id = stops.loc[uid, 'obj'].plafo_id
        if stopo_id > 0 and pole_id > 0:
            if (stopo_id, pole_id) not in stopos_poles_to_stops:
                stopos_poles_to_stops[(stopo_id, pole_id)] = set()
            stopos_poles_to_stops[(stopo_id, pole_id)].add(uid)
        if stopo_id > 0 and plafo_id != 0:
            if (stopo_id, plafo_id) not in stopos_plafos_to_stops:
                stopos_plafos_to_stops[(stopo_id, plafo_id)] = set()
            stopos_plafos_to_stops[(stopo_id, plafo_id)].add(uid)
        if stopo_id > 0:
            if stopo_id not in stopos_to_stops:
                stopos_to_stops[stopo_id] = set()
            stopos_to_stops[stopo_id].add(uid)
        if pole_id > 0:
            if pole_id not in poles_to_stops:
                poles_to_stops[pole_id] = set()
            poles_to_stops[pole_id].add(uid)
        if plafo_id != 0:
            if plafo_id not in plafos_to_stops:
                plafos_to_stops[plafo_id] = set()
            plafos_to_stops[plafo_id].add(uid)

    # initialize dict with empty sets
    stop_routes = {
        uid: dict(routes=set(), route_types=set(), prev_stops=set(),
                  next_stops=set())
        for uid in stops.index
    }

    # download and process OSM routes chunk by chunk
    # (all in one is too much for one Overpass request)
    bbox_all = stops['geo'].total_bounds[[1, 0, 3, 2]]
    bbox = bbox_all.copy()
    chunk_height = (bbox_all[2] - bbox_all[0]) / route_download_chunks
    for chunk in range(route_download_chunks):
        logger.debug(f'Processing chunk {chunk + 1} of {route_download_chunks}...')
        bbox[0] = bbox_all[0] + chunk * chunk_height
        bbox[2] = bbox_all[0] + (chunk + 1) * chunk_height
        query = f'''
            relation
            [type=route]
            [route~"{'|'.join(relevant_route_types)}"]
            ({','.join([str(x) for x in bbox])});
            out;
        '''
        osm_objects = overpass(
            query, overpass_url, overpass_api_key, overpass_timeout
        )
        logger.info(f'Chunk has {len(osm_objects)} routes.')

        # get stop lists from route relations
        stop_lists = []
        routes = []
        route_types = []
        for rel in osm_objects:
            stop_list = []
            skip_next = False  # True, if two route members belong to one stop
            for i in range(len(rel.members)):
                if skip_next:
                    skip_next = False
                    continue
                m = rel.members[i]
                next_m = rel.members[i + 1] if i + 1 < len(rel.members) \
                         else None
                if m['role'] not in ['stop', 'platform']:
                    continue
                if next_m and next_m['role'] not in ['stop', 'platform']:
                    next_m = None
                stop = None  # will be a set of stops (mostly with one or two
                             # items)!
                trtr = (m['type'], m['role'], next_m['type'], next_m['role']) \
                       if next_m else None
                if next_m and trtr == ('node', 'stop', 'node', 'platform'):
                    stop = stopos_poles_to_stops.get((m['ref'], next_m['ref']))
                    skip_next = True
                elif next_m and trtr == ('node', 'stop', 'way', 'platform'):
                    stop = stopos_plafos_to_stops.get((m['ref'], next_m['ref']))
                    skip_next = True
                elif next_m and trtr == ('node', 'stop', 'relation', 'platform'):
                    stop = stopos_plafos_to_stops.get((m['ref'], -next_m['ref']))
                    skip_next = True
                elif (m['type'], m['role']) == ('node', 'stop'):
                    stop = stopos_to_stops.get(m['ref'])
                elif (m['type'], m['role']) == ('node', 'platform'):
                    stop = poles_to_stops.get(m['ref'])
                elif (m['type'], m['role']) == ('way', 'platform'):
                    stop = plafos_to_stops.get(m['ref'])
                elif (m['type'], m['role']) == ('relation', 'platform'):
                    stop = plafos_to_stops.get(-m['ref'])
                if stop and (len(stop_list) == 0 or stop != stop_list[-1]):
                    stop_list.append(stop)
            if len(stop_list) == 0:
                continue  # route is in bbox but does not contain any PTSA stop
            stop_lists.append(stop_list)
            routes.append(rel.id)
            route_types.append(rel.tags.get('route'))

        # set prev/next stops and route infos
        for route, route_type, stop_list in zip(routes, route_types, stop_lists):
            for i in range(len(stop_list)):
                for stop in stop_list[i]:  # each item in stop_list is a set of (mostly) 1 or 2 stops
                    if stop not in stop_routes:
                        stop_routes[stop] = dict(
                            routes=set(), route_types=set(), prev_stops=set(),
                            next_stops=set()
                        )
                    stop_routes[stop]['routes'].add(route)
                    stop_routes[stop]['route_types'].add(route_type)
                    if i > 0:
                        stop_routes[stop]['prev_stops'].update(stop_list[i - 1])
                    if i < len(stop_list) - 1:
                        stop_routes[stop]['next_stops'].update(stop_list[i + 1])                

    logger.info(f'...done generating route information.')
    
    return stop_routes


def json_from_stop_routes(stop_routes, path):
    """
    Write route information for stops to JSON file.
    
    Parameters
    ----------
    stop_routes : dict
        Route information for stops as returned by get_stop_routes.
    path : str
        Path to write to.
    
    """
    
    # make lists from sets (JSON does not support sets)
    stop_routes = {uid: {k: list(v) for k, v in info.items()}
                                    for uid, info in stop_routes.items()}

    logger.info(f'Writing route information for stops to "{path}".')
    with open(path, 'w') as f:
        json.dump(stop_routes, f, indent=2)    


def stop_routes_from_json(path):
    """
    Read route information for stops from JSON file.
    
    Parameters
    ----------
    path : str
        Path to read from.
    
    Returns
    -------
    dict
        Route information for stops as dict of dicts like returned by
        get_stop_routes.
    
    """

    logger.info(f'Reading route information for stops from "{path}".')
    with open(path) as f:
        stop_routes = json.load(f)
        
    return stop_routes
