# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Load and process DELFI ZVH data from https://www.opendata-oepnv.de

df_from_zip:
    Load ZHV data from ZIP file to DataFrame
ZHVObject:
    Represent a ZHV stop object
ZHVPlace:
    Represent a ZHV stop place
ZHVArea:
    Represent a ZHV area
ZHVQuay:
    Represent a ZHV quay
gdf_from_df:
    Create GeoDataFrame of ZHVObject objects from DataFrame
filter_by_auth:
    Filter rows of GeoDataFrame by ZHV Authority
json_from_gdf:
    Write data from GeoDataFrames of ZHVObject objects to JSON file
gdf_from_json:
    Create GeoDataFrames of ZHVObject objects from JSON file
drop_inactive_gdf:
    Drop inactive places/areas/quays from geo data frames

"""

import datetime
import glob
import json
import logging
import os
import zipfile

import geopandas as gpd
import numpy as np
import pandas as pd

from . import stops


logger = logging.getLogger(__name__)


def df_from_zip(path, separate=True, return_date=False):
    """
    Read ZHV data from specified zipped CSV file and return three data frames
    for stop places, areas, quays (if separate is True) or one data frame with
    all objects (if separate is False). If there are more than one file in the
    ZIP archive, the first file listed by zipfile.namelist() and ending with
    ".csv" is chosen.

    Only very basic data validation is performed here. See code for details and
    https://github.com/mfdz/zhv-issues/issues for a list of issues with the
    data source. Validation failures will result in warnings in the logs.

    All columns are read as strings except for SeqNo (uint32), Latitude
    (float64), Longitude (float64). Columns get renamed (see corresponding dict
    in the code) and columns known to be empty are dropped to increase
    usability. Some data normalization is performed like replacing '-' values by
    '' or 'ja'/'nein' by True/False (see code for details). DHID is used for
    index.

    Parameters
    ----------
    path : str
        Path of ZIP file to read from. If the string points to a directory, the
        most recent (last-modified date) ZIP file (ending with .zip) is read.
    separate : bool, optional
        Separate data into stop places, areas, quays (if True) or keep them
        joined (if False).
    return_date : bool, optional
        If True, return last-modified date of CSV file.

    Returns
    -------
    pandas.DataFrame or tuple of three pandas.DataFrame
        Data read. Either one or three DataFrames depending on the separate.
    datetime.date
        Last-modification date of read CSV file (only if return_date parameter
        is True).

    Raises
    ------
    FileNotFoundError
        Path does not point to a file and not to a directory containing ZIP
        files.

    """
    
    # find most recent ZIP file (if path points to a directory)
    if not path:
        logger.debug('Path not set, using ".".')
        path = '.'
    if os.path.isdir(path):
        logger.debug(f'Path "{path}" is a directory. Looking for most recent ZIP file.')
        zip_paths = glob.glob(os.path.join(path, '*.zip'))
        logger.debug(f'Found {len(zip_paths)} ZIP files.')
        if len(zip_paths) == 0:
            raise FileNotFoundError(f'Directory "{path}" does not contain any ZIP file!')
        last_mod_times = [os.path.getmtime(p) for p in zip_paths]
        path = max(zip(zip_paths, last_mod_times), key=lambda x: x[1])[0]
        del zip_paths, last_mod_times
    elif not os.path.isfile(path):
        raise FileNotFoundError(f'Path "{path}" neither points to a directory nor to a regular file!')
    
    # read file
    logger.info(f'Reading ZHV data from file "{path}".')
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        if len(names) == 1:
            name = names[0]
        else:
            csv_names = [name for name in names if name.endswith('.csv')]
            if len(csv_names) == 0:
                raise FileNotFoundError(f'File "{path}" does not contain any CSV file!')
            else:
                name = csv_names[0]
        date = datetime.date(*zf.getinfo(name).date_time[:3])
        logger.info(f'CSV file\'s last-modification date is {date}.')
        with zf.open(name) as f:
            data = pd.read_csv(
                f,
                sep=';',
                decimal=',',
                keep_default_na=False,
                dtype={
                    'SeqNo': np.uint32,
                    'Type': str,
                    'DHID': str,
                    'Parent': str,
                    'Name': str,
                    'Latitude': np.float64,
                    'Longitude': np.float64,
                    'MunicipalityCode': str,
                    'Municipality': str,
                    'DistrictCode': str,
                    'District': str,
                    'Description': str,
                    'Authority': str,
                    'DelfiName': str,
                    'THID': str,
                    'TariffProvider': str,
                    'LastOperationDate': str,
                    'SEV': str
                }
            )
    logger.info(f'ZHV data has {len(data)} items.')

    # rename columns
    data = data.rename(columns={
        'SeqNo': 'seq_no',
        'Type': 'type',
        'DHID': 'dhid',
        'Parent': 'parent_id',
        'Name': 'name',
        'Latitude': 'lat',
        'Longitude': 'lon',
        'MunicipalityCode': 'mun_code',
        'Municipality': 'mun',
        'DistrictCode': 'dist_code',
        'District': 'dist',
        'Description': 'desc',
        'Authority': 'auth',
        'DelfiName': 'delfi_name',
        'THID': 'thid',
        'TariffProvider': 'tar_pro',
        'LastOperationDate': 'last_date',
        'SEV': 'sev'
    })

    # drop seq_no column
    if (data['seq_no'] != data.index).any():
        logger.warning('Unexpected values in column "seq_no"! Dropping nevertheless.')
    data = data.drop(columns=['seq_no'])

    # drop dist column
    dist_values = set(data['dist'].unique())
    if not dist_values <= {'', '-'}:
        logger.warning(f'Column "dist" contains data! Found values {dist_values}. Dropping nevertheless.')
    data = data.drop(columns=['dist'])

    # replace ja/nein by True/False in sev column
    sev_values = set(data['sev'].unique())
    if sev_values == {'ja', 'nein'}:
        data['sev'] = data['sev'] == 'ja'
    else:
        logger.warning(f'Unexpected values in "sev" column! Found values {sev_values}. Treating all except "ja" as False.')

    # use dhid column for index
    if data['dhid'].duplicated().any():
        logger.warning('Dulicates in "dhid" column! Resulting DataFrame(s) will have duplicate index values.')
    data = data.set_index('dhid')

    # replace empty values by ''
    cols = [
        'mun_code',
        'mun',
        'dist_code',
        'auth',
        'delfi_name',
        'thid',
        'tar_pro'
    ]
    for col in cols:
        data.loc[data[col] == '-', col] = ''
   
    # separate by type?
    if not separate:
        return data
   
    # separate data by type
    type_values = set(data['type'].unique())
    if not type_values <= {'S', 'A', 'Q'}:
        logger.warning(f'Unexpected values in "type" column! Found values {type_values}. Dropping all but "S", "A", "Q".')
    places = data.loc[data['type'] == 'S', :]
    areas = data.loc[data['type'] == 'A', :]
    quays = data.loc[data['type'] == 'Q', :]
    logger.info(f'Found {len(places)} places, {len(areas)} areas, {len(quays)} quays.')

    # remove unused columns from places
    if (places.index != places['parent_id']).any():
        logger.warning('Some places have invalid value in "parent_id" column! Does not matter for processing, but shouldn\'t happen.')
    places = places.drop(columns=['type', 'parent_id'])

    # remove unused columns from areas
    cols=[
        'type',
        'mun_code',
        'mun',
        'dist_code',
        'delfi_name',
        'thid',
        'tar_pro',
        'last_date'
    ]
    for col in cols:
        if areas[col].nunique(dropna=False) > 1:
            logger.warning(f'Column "{col}" contains data for some areas! Dropping nevertheless.')
    areas = areas.drop(columns=cols)

    # remove unused columns from quays
    cols = [
        'type',
        'mun_code',
        'mun',
        'dist_code',
        'delfi_name',
        'thid',
        'tar_pro',
        'last_date'
    ]
    for col in cols:
        if quays[col].nunique(dropna=False) > 1:
            logger(f'Column "{col}" contains data for some quays! Dropping nevertheless.')
    quays = quays.drop(columns=cols)

    if return_date:
        return places, areas, quays, date
    else:
        return places, areas, quays


class ZHVObject(stops.StopObject):
    """
    Represent a ZHV stop object.
    
    Attributes
    ----------
    all attributes of stops.StopObject objects and
    desc : str
        Description of the stop
    auth : str
        Authority of the stop
    sev : bool
        Stop related to SEV (rail replacement service)?
    zhv_name : str
        Stop name given in ZHV. Attribute name may be set to a different value
        if more sensible for processing.
    
    """
    
    def __init__(self, type_, id_, name, lat, lon, desc, auth, sev,
                 source='zhv'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon
            See stops.StopObject
        desc : str
            Description of the stop
        auth : str
            Authority of the stop
        sev : bool
            Stop related to SEV (rail replacement service)?
    
        """

        super().__init__(source, type_, id_, name, lat, lon)

        self.desc = desc
        self.auth = auth
        self.sev = bool(sev)
        
        self.zhv_name = self.name

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['desc'] = self.desc
        data['auth'] = self.auth
        data['sev'] = self.sev
        data['zhv_name'] = self.zhv_name

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.desc = json_dict['desc']
        self.auth = json_dict['auth']
        self.sev = json_dict['sev']
        self.zhv_name = json_dict['zhv_name']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = ZHVObject('', '', '', 0, 0, '', '', False)
        obj.fill_from_json(json_dict)
        return obj


class ZHVPlace(ZHVObject):
    """
    Represent a ZHV stop place created from ZHV data.
    
    Attributes
    ----------
    all attributes of ZHVObject objects and
    mun_code : str
        MunicipalityCode value of the stop place
    mun : str
        Municipality value of the stop place
    dist_code : str
        DistrictCode value of the stop place
    delfi_name : str
        DelfiName value of the stop place
    thid : str
        THID value of the stop place
    tar_pro : str
        TariffProvider value of the stop place
    last_date : datetime.date
        Last operation date derived from LastOperationDate value of the stop
        place
    child_areas : list of ZHVArea objects
        Areas that have this stop place as parent
    child_quays : list of ZHVQuay objects
        Quays that have this stop place as parent
    
    """

    def __init__(self, id_, name, lat, lon, mun_code, mun, dist_code, desc,
                 auth, delfi_name, thid, tar_pro, last_date, sev, source='zhv'):
        """
        Parameters
        ----------
        source, type_, id_, name, lat, lon, desc, auth, sev
            See ZVHObject
        mun_code : str
            MunicipalityCode value of the stop place
        mun : str
            Municipality value of the stop place
        dist_code : str
            DistrictCode value of the stop place
        delfi_name : str
            DelfiName value of the stop place
        thid : str
            THID value of the stop place
        tar_pro : str
            TariffProvider value of the stop place
        last_date : str
            LastOperationDate value of the stop place
            
        Raises
        ------
        ValueError
            last_date has invalid value
    
        """

        super().__init__(
            'sp', id_, name, lat, lon, desc, auth, sev, source=source
        )

        self.mun_code = mun_code
        self.mun = mun
        self.dist_code = dist_code
        self.delfi_name = delfi_name
        self.thid = thid
        self.tar_pro = tar_pro
        self.last_date = last_date

        self.child_areas = []
        self.child_quays = []

        # date str to datetime.date (ZHV value "31.12.1999" means "unknown")
        if self.last_date and self.last_date != '1999-12-31T00:00:00':
            try:
                self.last_date = datetime.datetime.strptime(
                    self.last_date, '%Y-%m-%dT%H:%M:%S'
                ).date()
            except ValueError:
                self.add_note(f'Invalid last_date! Value in ZHV is "{self.last_date}".')
                self.last_date = None
        else:
            self.last_date = None

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['mun_code'] = self.mun_code
        data['mun'] = self.mun
        data['dist_code'] = self.dist_code
        data['delfi_name'] = self.delfi_name
        data['thid'] = self.thid
        data['tar_pro'] = self.tar_pro
        data['last_date'] = str(self.last_date) if self.last_date else ''
        data['child_areas'] = [obj.uid for obj in self.child_areas]
        data['child_quays'] = [obj.uid for obj in self.child_quays]

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.mun_code = json_dict['mun_code']
        self.mun = json_dict['mun']
        self.dist_code = json_dict['dist_code']
        self.delfi_name = json_dict['delfi_name']
        self.thid = json_dict['thid']
        self.tar_pro = json_dict['tar_pro']

        self.last_date = datetime.datetime.strptime(
            json_dict['last_date'], '%Y-%m-%d'
        ).date() if json_dict['last_date'] else None

        self.child_areas = json_dict['child_areas']
        self.child_quays = json_dict['child_quays']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = ZHVPlace('', '', 0, 0, '', '', '', '', '', '', '', '', '', False)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.child_areas = [stop_objs.loc[uid] for uid in self.child_areas]
        self.child_quays = [stop_objs.loc[uid] for uid in self.child_quays]


class ZHVArea(ZHVObject):
    """
    Represent a ZHV area created from ZHV data.
    
    Attributes
    ----------
    all attributes of ZHVObject objects and
    parent : ZHVPlace or None
        Parent stop place of the area
    child_quays : list of ZHVQuay objects
        Quays that have this area as parent
    """

    def __init__(self, id_, parent, name, lat, lon, desc, auth, sev, source='zhv'):
        """
        Parameters
        ----------
        source, id_, name, lat, lon, desc, auth, sev
            See ZVHObject
        parent : ZHVPlace or None
            Parent stop place of the area
                
        """

        super().__init__(
            'mc', id_, name, lat, lon, desc, auth, sev, source=source
        )

        self.parent = parent
        if self.parent:
            self.parent.child_areas.append(self)

        self.child_quays = []
        
        if self.parent:
            self.name = f'{parent.zhv_name}; {self.zhv_name}'

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['parent'] = self.parent.uid if self.parent else ''
        data['child_quays'] = [obj.uid for obj in self.child_quays]

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.parent = json_dict['parent']
        self.child_quays = json_dict['child_quays']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = ZHVArea('', None, '', 0, 0, '', '', False)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.parent = stop_objs.loc[self.parent] if self.parent != '' else None
        self.child_quays = [stop_objs.loc[uid] for uid in self.child_quays]


class ZHVQuay(ZHVObject):
    """
    Represent a ZHV quay created from ZHV data.
    
    Attributes
    ----------
    all attributes of ZHVObject objects and
    parent : ZHVPlace or ZHVArea or None
        Parent stop place or area of the quay
    
    """

    def __init__(self, id_, parent, name, lat, lon, desc, auth, sev, source='zhv'):
        """
        Parameters
        ----------
        source, id_, name, lat, lon, desc, auth, sev
            See ZVHObject
        parent : ZHVPlace or ZHVArea or None
            Parent stop place or area of the quay
                
        """

        super().__init__(
            'pw', id_, name, lat, lon, desc, auth, sev, source=source
        )

        self.parent = parent
        if self.parent:
            self.parent.child_quays.append(self)

        if isinstance(self.parent, ZHVPlace):
            self.name = f'{parent.name}; {name}'
        elif isinstance(self.parent, ZHVArea):
            if self.parent.parent:
                self.name = f'{parent.parent.zhv_name}; {parent.zhv_name}; {self.zhv_name}'
            else:
                self.name = f'{parent.zhv_name}; {self.zhv_name}'

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = super().to_json()

        data['parent'] = self.parent.uid if self.parent else ''

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        super().fill_from_json(json_dict)

        self.parent = json_dict['parent']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """

        obj = ZHVQuay('', None, '', 0, 0, '', '', False)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self, stop_objs):
        """
        For member variables refering to other objects replace UID strings by
        objects. Call this method after creating an object from JSON data.
        
        Parameters
        ----------
        stop_objs : pandas.Series
            A Series with UIDs as index and objects as values.
        
        """
        
        self.parent = stop_objs.loc[self.parent] if self.parent != '' else None


def gdf_from_df(places_df, areas_df, quays_df, source='zhv'):
    """
    Create GeoDataFrame of ZHVObject objects from DataFrame.

    Parameters
    ----------
    places_df : pandas.DataFrame
        DataFrame with ZHV stop places data as returned by df_from_zip
    areas_df : pandas.DataFrame
        DataFrame with ZHV areas data as returned by df_from_zip
    quays_df : pandas.DataFrame
        DataFrame with ZHV quays data as returned by df_from_zip
    source : str, optional
        Identifier for the data source. Should be unique within all sources
        used in a project.
        
    Returns
    -------
    tuple of 3 GeoDataFrames
        One GeoDataFrame for stop places, one for areas, one for quays. Index
        consists of UIDs. Columns are 'obj' holding corresponding ZHVObjects and
        'geo' holding a shapely.Point with the object's geolocation.

    """

    logger.debug('Creating stop place objects...')

    # make place objects
    cols = [
        'name', 'lat', 'lon', 'mun_code', 'mun', 'dist_code', 'desc', 'auth',
        'delfi_name', 'thid', 'tar_pro', 'last_date', 'sev'
    ]
    place_objs = places_df[cols].apply(
        lambda x: ZHVPlace(x.name, *x, source=source), axis=1
    )
    places = stops.gdf_from_objects(place_objs)

    logger.debug('...done creating stop place objects.')

    logger.debug('Creating area objects...')

    # get parent objects for areas
    areas_parents = areas_df['parent_id'].apply(
        lambda pid: place_objs.loc[pid] if pid in place_objs.index else None
    )
    areas_parents.name = 'parent'

    # make area objects
    cols = ['parent', 'name', 'lat', 'lon', 'desc', 'auth', 'sev']
    area_objs = pd.concat((areas_parents, areas_df), axis=1)[cols].apply(
        lambda x: ZHVArea(x.name, *x, source=source), axis=1
    )
    areas = stops.gdf_from_objects(area_objs)

    # add note to areas with invalid parent ID
    for id_ in areas_df.index[areas_parents.isna()]:
        area_objs.loc[id_].add_note(f'Has invalid parent ID "{areas_df.loc[id_, 'parent_id']}" in ZHV data!')

    del areas_parents
    
    logger.debug('...done creating area objects.')

    logger.debug('Creating quay objects...')

    # get parent objects for quays ('parent' column will be removed below)
    def quay_parent_obj_from_id(pid):
        """Get a quay's parent object from parent ID. """
        if pid in place_objs.index:
            return place_objs.loc[pid]
        elif pid in area_objs.index:
            return area_objs.loc[pid]
        else:
            return None
    quays_parents = quays_df['parent_id'].apply(quay_parent_obj_from_id)
    quays_parents.name = 'parent'

    # make quay objects
    cols = ['parent', 'name', 'lat', 'lon', 'desc', 'auth', 'sev']
    quay_objs = pd.concat((quays_parents, quays_df), axis=1)[cols].apply(
        lambda x: ZHVQuay(x.name, *x, source=source), axis=1
    )
    quays = stops.gdf_from_objects(quay_objs)

    # add note to quays with invalid parent ID
    for id_ in quays_df.index[quays_parents.isna()]:
        quay_objs.loc[id_].add_note(f'Has invalid parent ID "{quays_df.loc[id_, 'parent_id']}" in ZHV data!')

    del quays_parents
    
    logger.debug('...done creating quay objects.')

    return places, areas, quays


def filter_by_auth(gdf, auth):
    """
    Filter rows of GeoDataFrame by ZHV Authority.
    
    Parameters
    ----------
    gdf : GeoDataFrame
        The GeoDataFrame to be filtered as returned by df_to_gdf.
    auth : str
        Name of the ZHV Authority.
    
    Returns
    -------
    GeoDataFrame
        subset of the rows of the original GeoDataFrame
    """
    return gdf.loc[gdf['obj'].apply(lambda obj: obj.auth == auth), :]


def json_from_gdf(places, areas, quays, path='zhv_{subset}.json',
                  subsets=[('all', 'all', None)]):
    """
    Write data from GeoDataFrames of ZHVObject objects to JSON file.
        
    Subsets of the data may be chosen via subsets parameter. For each subset a
    separate JSON file will be written.
    
    Parameters
    ----------
    places : geopandas.GeoDataFrame
        GeoDataFrame with ZHVPlace objects as returned by df_to_gdf function.
    areas : geopandas.GeoDataFrame
        GeoDataFrame with ZHVArea objects as returned by df_to_gdf function.
    quays : geopandas.GeoDataFrame
        GeoDataFrame with ZHVQuay objects as returned by df_to_gdf function.
    path : str, optional
        Path of JSON file to write. The string has to contain "{subset}" which
        will be replaced by the subset name for each subset provided in the
        subsets parameter.
    subsets: list of (str, str, arbitrary type)
        For each item in the list a separate JSON file will be written. First
        item in each tupel is a subset's name (used for file name only), the
        second item is the subset type, the third is a parameter depending on
        the chosen type. Available types are:
        * 'all' - use all data (third tuple item is ignored)
        * 'bbox' - only include data covered by a bounding box (third tuple item
                   is a tuple (ymin, xmin, ymax, xmax) defining the bbox in the
                   data's CRS)
        * 'auth' - only include data with specified ZHV Authority value (third
                   tuple item is a string specifying the authority to use)
        
    Returns
    -------
    None

    """

    for subset_name, subset_mode, subset_param in subsets:

        logger.debug(f'Creating subset "{subset_name}"...')

        # filter data
        if subset_mode == 'auth':
            subset_places = filter_by_auth(places, subset_param)
            subset_areas = filter_by_auth(areas, subset_param)
            subset_quays = filter_by_auth(quays, subset_param)
        elif subset_mode == 'bbox':
            subset_places = stops.filter_by_bbox(places, subset_param)
            subset_areas = stops.filter_by_bbox(areas, subset_param)
            subset_quays = stops.filter_by_bbox(quays, subset_param)
        else:  # all
            subset_places = places 
            subset_areas = areas
            subset_quays = quays

        # ensure that each subset's object's children and parent are in subset
        if subset_mode != 'all':
            
            # add parent areas for all quays
            def parent_area_uid(obj):
                if isinstance(obj.parent, ZHVArea):
                    return obj.parent.uid
                else:
                    return None
            if len(subset_quays) > 0:
                a_uids = set(subset_quays['obj'].apply(parent_area_uid)) \
                         - {np.nan} - set(subset_areas.index)
                subset_areas = gpd.pd.concat(
                    (subset_areas, areas.loc[list(a_uids), :])
                )
                logger.debug(f'Added {len(a_uids)} parent areas not matching the subset\'s filter.')
            
            # add parent places for all quays and all areas
            def parent_place_uid(obj):
                if isinstance(obj.parent, ZHVPlace):
                    return obj.parent.uid
                else:
                    return None
            if len(subset_quays) > 0:
                q_uids = set(subset_quays['obj'].apply(parent_place_uid))
            else:
                q_uids = set()
            if len(subset_areas) > 0:
                a_uids = set(subset_areas['obj'].apply(parent_place_uid))
            else:
                a_uids = set()
            if len(q_uids) + len(a_uids) > 0:
                p_uids = (q_uids | a_uids) - {np.nan} - set(subset_places.index)
                subset_places = gpd.pd.concat(
                    (subset_places, places.loc[list(p_uids), :])
                )
                logger.debug(f'Added {len(p_uids)} parent places not matching the subset\'s filter.')
            
            # add child areas for all places
            def get_child_areas(obj):
                return [c.uid for c in obj.child_areas]
            if len(subset_places) > 0:
                a_uids = set(subset_places['obj'].apply(get_child_areas).sum()) \
                        - set(subset_areas.index)
                subset_areas = gpd.pd.concat(
                    (subset_areas, areas.loc[list(a_uids), :])
                )
                logger.debug(f'Added {len(a_uids)} child areas not matching the subset\'s filter.')
            
            # add child quays for all places and all areas
            def get_child_quays(obj):
                return [c.uid for c in obj.child_quays]
            if len(subset_places) > 0:
                p_uids = set(subset_places['obj'].apply(get_child_quays).sum())
            else:
                p_uids = set()
            if len(subset_areas) > 0:
                a_uids = set(subset_areas['obj'].apply(get_child_quays).sum())
            else:
                a_uids = set()
            if len(p_uids) + len(a_uids) > 0:
                q_uids = (p_uids | a_uids) - set(subset_quays.index)
                subset_quays = gpd.pd.concat(
                    (subset_quays, quays.loc[list(q_uids), :])
                )
                logger.debug(f'Added {len(q_uids)} child quays not matching the subset\'s filter.')
            
        # export as JSON
        data = {
            'places': list(subset_places['obj'] \
                      .apply(lambda obj: obj.to_json())),
            'areas': list(subset_areas['obj'].apply(lambda obj: obj.to_json())),
            'quays': list(subset_quays['obj'].apply(lambda obj: obj.to_json()))
        }
        subset_path = path.format(subset=subset_name)
        with open(subset_path, 'w') as f:
            json.dump(data, f, indent=2)

        logger.debug(f'...done creating subset "{subset_name}".')
        logger.info(f'{len(subset_places)} places, {len(subset_areas)} areas, {len(subset_quays)} quays written to "{subset_path}".')


def gdf_from_json(path):
    """
    Create GeoDataFrames of ZHVObject objects from JSON file.
        
    JSON file has to have the structure produced by json_from_gdf.
    
    Parameters
    ----------
    path : str
        Path of JSON file to read from.
        
    Returns
    -------
    (geopandas.GeoDataFrame, geopandas.GeoDataFrame, geopandas.GeoDataFrame)
        Stop places, areas, quays as GeoDataFrames of corresponding objects.

    """

    # read JSON file
    with open(path) as f:
        json_data = json.load(f)
        
    # make GeoDataFrames
    places = stops.gdf_from_objects(
        [ZHVPlace.from_json(obj_dict) for obj_dict in json_data['places']]
    )
    areas = stops.gdf_from_objects(
        [ZHVArea.from_json(obj_dict) for obj_dict in json_data['areas']]
    )
    quays = stops.gdf_from_objects(
        [ZHVQuay.from_json(obj_dict) for obj_dict in json_data['quays']]
    )

    # replace object IDs by objects
    all_objs = pd.concat((places['obj'], areas['obj'], quays['obj']), axis=0)
    places['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))
    areas['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))
    quays['obj'].apply(lambda obj: obj.ids_to_objects(all_objs))

    logger.info(f'Found {len(places)} places, {len(areas)} areas, {len(quays)} quays in "{path}".')
    
    return places, areas, quays


def drop_inactive_gdf(places, areas, quays, today=None):
    """
    Drop inactive places/areas/quays from geo data frames.
        
    Remove all objects whose parent place has last operation date older than
    today or unset.
    
    Parameters
    ----------
    places : geopandas.GeoDataFrame
        GeoDataFrame with ZHVPlace objects as returned by df_to_gdf function.
    areas : geopandas.GeoDataFrame
        GeoDataFrame with ZHVArea objects as returned by df_to_gdf function.
    quays : geopandas.GeoDataFrame
        GeoDataFrame with ZHVQuay objects as returned by df_to_gdf function.
    today : datetime.date or None, optional
        Date to consider as first day of the activity. If None, todays date is
        used.
        
    Returns
    -------
    (geopandas.GeoDataFrame, geopandas.GeoDataFrame, geopandas.GeoDataFrame)
        Stop places, areas, quays as GeoDataFrames of corresponding objects.

    """

    if not today:
        today = datetime.date.today()

    places_mask = places['obj'].apply(
        lambda obj: obj.last_date >= today if obj.last_date else False
    )
    active_places = places.loc[places_mask]
    
    areas_mask = pd.Series(data=False, index=areas.index)
    quays_mask = pd.Series(data=False, index=quays.index)
    for place in active_places['obj']:
        child_quays = []
        for area in place.child_areas:
            areas_mask.at[area.uid] = True
            child_quays.extend(area.child_quays)
        child_quays.extend(place.child_quays)
        for quay in child_quays:
            quays_mask.at[quay.uid] = True
    active_areas = areas.loc[areas_mask]
    active_quays = quays.loc[quays_mask]
    
    return active_places, active_areas, active_quays
