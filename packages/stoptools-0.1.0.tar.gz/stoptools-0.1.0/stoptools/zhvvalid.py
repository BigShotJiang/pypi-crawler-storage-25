# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Validate DELFI ZVH data from https://www.opendata-oepnv.de

not_in_area:
    Check whether points are in a given area
same_location:
    Find objects with (almost) identical location
last_operation_dates:
    Separate stop places by LastOperationDate values
invalid_ids:
    Check format of object IDs
no_parent:
    Check whether there is a parent object
quay_parent:
    Check whether parent object is an area or a stop place (not a quay)
wrong_parent:
    Find areas/quays with possibly wrong parent stop place
large_distance:
    Find areas or quays with large distance to their parent stop place
    
"""

import datetime
import re

import pandas as pd

from . import zhv
from .stopsvalid import not_in_area, same_location


def last_operation_dates(date_strings, today=None):
    """
    Separate stop places by LastOperationDate values. Values may be
    * "unknown" - "1999-12-31T00:00:00" in the data),
    * "past" - valid date in the past,
    * "future" - valid date in the future,
    * "invalid" - all other values

    Parameters
    ----------
    date_strings : pandas.Series
        Series with ZHV date strings from LastOperationDate column.
    today : datetime.date or None, optional
        The date to be considered as today. All days before are considered as
        past. The day and all days after are the future. If None, today's date
        is used.

    Returns
    -------
    dict of pandas.Index
        Dict of items "date value": Index of places with this value.
    """

    if not today:
        today = datetime.date.today()
    
    datetimes = pd.to_datetime(
        date_strings, format='%Y-%m-%dT%H:%M:%S', errors='coerce'
    ).dt.date

    result = dict()
    
    unknown_mask = date_strings == '1999-12-31T00:00:00'
    result['unknown'] = date_strings.index[unknown_mask]

    invalid_mask = datetimes.isna()
    result['invalid'] = date_strings.index[~unknown_mask & invalid_mask]
    valid_mask = ~unknown_mask & ~invalid_mask
    del invalid_mask

    result['past'] = date_strings.index[valid_mask & (datetimes < today)]
    result['future'] = date_strings.index[valid_mask & (datetimes >= today)]
    
    return result
    
    
def invalid_ids(ids):
    """
    Check format of object IDs.

    Expected format is "de:0123:uvw" or "de:123:uvw:xyz", where 123 is some
    integer, uvw is some non-empty string without ":" or white-space and xyz is
    some non-empty string.
    
    Parameters
    ----------
    ids : iterable of str
        IDs to check
    
    Returns
    -------
    list of str
        invalid IDs

    """
    
    regex_id = re.compile(r'de:[0-9]+:[^:\s]+(?=:|$)')

    return [id_ for id_ in ids if not regex_id.match(id_.lower())]


def no_parent(objs):
    """
    Check whether there is a parent object.
    
    Parameters
    ----------
    objs : pandas.Series
        Series of zhv.ZHVArea and zhv.ZHVQuay objects.
    
    Returns
    -------
    pandas.Index
        Indices of objects without parent.
    
    """
    
    return objs.index[objs.apply(lambda obj: True if not obj.parent else False)]


def quay_parent(objs):
    """
    Check whether parent object is an area or a stop place (not a quay)
    
    Parameters
    ----------
    objs : pandas.Series
        Series of zhv.ZHVArea and zhv.ZHVQuay objects.
    
    Returns
    -------
    pandas.Index
        Indices of objects with wrong parent type.
    
    """
    
    def check(obj):
        if obj.parent \
        and not isinstance(obj.parent, (zhv.ZHVPlace, zhv.ZHVArea)):
            return True
        else:
            return False
    
    return objs.index[objs.apply(check)]


def wrong_parent(objs, places, meters_crs=None):
    """
    Find areas or quays with parent stop places that are farther away than the
    DHID parent stop place.
    
    Parameters
    ----------
    objs : geopandas.GeoDataFrame
        GeoDataFrame of zhv.ZVHArea or zhv.ZHVQuay objects as returned by
        zhv.gdf_from_df.
    places : geopandas.GeoDataFrame
        GeoDataFrame of zhv.ZVHPlace objects as returned by zhv.gdf_from_df.
    meters_crs : str
        CRS used for computing (Euclidean) distances in meters. Everything
        understood by GeoPandas is allowed. If None, coordinates in objs and
        places are used as is (should already be in meters).
    
    Returns
    -------
    pandas.DataFrame
        DataFrame with areas/quays that have the wrong parent stop place. Index
        is like index of objs parameter. Columns are 
        * 'parent_id' - parent ID as given in ZHV,
        * 'dparent_id' - parent ID as derived from DHID,
        * 'dist_parent' - distance to ZHV parent in meters,
        * 'dist_dparent' - distance to DHID parent in meters.
    
    """

    def get_parent_uid(obj):
        """Get parent stop place's UID for quay or area. """
        if isinstance(obj, (zhv.ZHVArea, zhv.ZHVQuay)) and obj.parent:
            if isinstance(obj.parent, zhv.ZHVArea) and obj.parent.parent:
                return obj.parent.parent.uid
            elif isinstance(obj.parent, zhv.ZHVPlace):
                return obj.parent.uid
            else:  # obj.parent is ZHVArea without parent
                return ''
        else:
            return ''

    # get parent UIDs and dparent UIDs
    results = pd.DataFrame(index=objs.index, data={
        'parent_uid': objs['obj'].apply(get_parent_uid),
        'dparent_id': objs['obj'].apply(
            lambda obj: ':'.join(obj.id.split(':')[:3])
        )
    })
    
    # select objects with valid parent and dparent (note that places may be a
    # subset of all ZHV places, for instance if only places with
    # LastOperationDate in the future are considered)
    parent_mask = results['parent_uid'].isin(places.index)
    dparent_mask = results['dparent_id'].isin(places['obj'].apply(
        lambda obj: obj.id)
    )
    results = results.loc[parent_mask & dparent_mask, :]
    
    # dparent_id to dparent_uid
    id_uid_map = {place.id: place.uid for place in places['obj']}
    results['dparent_uid'] = results['dparent_id'].apply(
        lambda id_: id_uid_map[id_]
    )
    del id_uid_map

    # drop objects where parent_uid == dparent_uid
    results = results.loc[results['parent_uid'] != results['dparent_uid'], :]

    # distances
    def to_meters(s):
        return s.to_crs(meters_crs) if meters_crs else s
    objs_meters = to_meters(objs.loc[results.index, 'geo'])
    results['dist_parent'] = objs_meters.distance(
        to_meters(places.loc[results['parent_uid'], 'geo']),
        align=False
    )
    results['dist_dparent'] = objs_meters.distance(
        to_meters(places.loc[results['dparent_uid'], 'geo']),
        align=False
    )
    results = results.loc[results['dist_parent'] > results['dist_dparent'], :]
    
    # parent_uid to parent_id, drop UID columns
    results['parent_id'] = places.loc[results['parent_uid'], 'obj'].apply(
        lambda obj: obj.id
    ).to_numpy()
    results = results.drop(columns=['parent_uid', 'dparent_uid'])
    
    return results
    

def large_distance(objs, places, min_dist=1000, meters_crs=None):
    """
    Find areas or quays with large distance to their parent stop place.
    
    Parameters
    ----------
    objs : geopandas.GeoDataFrame
        GeoDataFrame of zhv.ZVHArea or zhv.ZHVQuay objects as returned by
        zhv.gdf_from_df.
    places : geopandas.GeoDataFrame
        GeoDataFrame of zhv.ZVHPlace objects as returned by zhv.gdf_from_df.
    min_dist : float
        Distance in meters to be considered large.
    meters_crs : str
        CRS used for computing (Euclidean) distances in meters. Everything
        understood by GeoPandas is allowed. If None, coordinates in objs and
        places are used as is (should already be in meters).
    
    Returns
    -------
    pandas.DataFrame
        DataFrame with areas/quays that have large distance to their parent stop
        place. Index is like index of objs parameter. Columns are 
        * 'parent_id' - parent ID as given in ZHV,
        * 'dist_parent' - distance to ZHV parent in meters.
    
    """

    def get_parent_uid(obj):
        """Get parent stop place's UID for quay or area. """
        if isinstance(obj, (zhv.ZHVArea, zhv.ZHVQuay)) and obj.parent:
            if isinstance(obj.parent, zhv.ZHVArea) and obj.parent.parent:
                return obj.parent.parent.uid
            elif isinstance(obj.parent, zhv.ZHVPlace):
                return obj.parent.uid
            else:  # obj.parent is ZHVArea without parent
                return ''
        else:
            return ''

    # get parent UIDs
    results = pd.DataFrame(index=objs.index, data={
        'parent_uid': objs['obj'].apply(get_parent_uid),
    })
    
    # select objects with valid parent (note that places may be a subset of all
    # ZHV places, for instance if only places with LastOperationDate in the
    # future are considered)
    results = results.loc[results['parent_uid'].isin(places.index), :]
    
    # distances
    def to_meters(s):
        return s.to_crs(meters_crs) if meters_crs else s
    objs_meters = to_meters(objs.loc[results.index, 'geo'])
    results['dist_parent'] = objs_meters.distance(
        to_meters(places.loc[results['parent_uid'], 'geo']),
        align=False
    )
    results = results.loc[results['dist_parent'] >= min_dist, :]
    
    # parent_uid to parent_id, drop UID column
    results['parent_id'] = places.loc[results['parent_uid'], 'obj'].apply(
        lambda obj: obj.id
    ).to_numpy()
    results = results.drop(columns=['parent_uid'])
    
    return results

