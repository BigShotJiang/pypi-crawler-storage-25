# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Validate stop data (mainly location related)

not_in_area:
    Check whether points are in a given area
same_location:
    Find stop objects with (almost) identical location
    
"""

import pandas as pd


def not_in_area(points, shape):
    """
    Check whether points are in a given area.
    
    Parameters
    ----------
    points : geopandas.GeoSeries
        Series of points to check.
    shape : shapely.Geometry
        Shape of the area.
    
    Returns
    -------
    pandas.Index
        Indices of points not in the area.
    
    """
    
    return points.index[~points.within(shape)]


def same_location(objs, max_dist=0, meters_crs=None):
    """
    Find objects with (almost) identical location.
    
    Distance between two objects in a group may be greater than max_dist. But
    there always are intermediate objects such that one can hop from one object
    to any other with hop distance below max_dist.
    
    Parameters
    ----------
    objs : geopandas.GeoSeries
        GeoSeries of points.
    max_dist : float
        Maximum distance in meters two points are allowed to have to be
        considered as identical.
    meters_crs : str
        CRS used for computing (Euclidean) distances in meters. Everything
        understood by GeoPandas is allowed. If None, coordinates in objs are
        used as is (should already be in meters).
    
    Returns
    -------
    pandas.Series
        Series with same index as objs. Data is an integer. All objects with
        same location have the same integer.
    
    """

    if meters_crs:
        objs = objs.to_crs(meters_crs)
    
    # pairs or nearby objects
    pairs = objs.sindex.query(
        objs['geo'], predicate='dwithin', distance=max_dist
    )
    pairs = [(objs.index[a], objs.index[b]) for a, b in pairs.T if a < b]

    # join nearby objects to groups
    groups = {gid: {uid} for gid, uid in enumerate(objs.index)}
    obj_gids = {uid: gid for gid, uid in enumerate(objs.index)}
    for uid1, uid2 in pairs:
        gid1 = obj_gids[uid1]
        gid2 = obj_gids[uid2]
        if gid1 == gid2:
            continue
        groups[gid1] |= groups[gid2]
        for uid in groups[gid2]:
            obj_gids[uid] = gid1
        del groups[gid2]

    # make Series from groups dict
    series_list = [pd.Series(index=list(group), data=gid)
                   for gid, group in groups.items() if len(group) > 1]
    if len(series_list) > 0:
        groups = pd.concat(series_list, axis=0)
    else:
        groups = pd.Series()

    return groups
