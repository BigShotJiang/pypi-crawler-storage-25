# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Represent different kinds of geolocated PT stops in a unified manner

StopObject:
    Represent a geolocated stop
gdf_from_objects:
    Make GeoDataFrame from list of StopObjects
filter_by_bbox:
    Filter rows of GeoDataFrame by bounding box
get_neighbors:
    Group objects by distance

"""

import logging
import re

import geopandas as gpd
import pandas as pd
import shapely


logger = logging.getLogger(__name__)
 

class StopObject:
    """
    Represent a geolocated stop in way suitable for all kinds of stops.

    Attributes
    ----------
    source : str
        Identifier for the source of the object like 'gtfs' or 'osm'.
    type_ : str
        Identifier for the object type. One of
        * 'sp' - stop place (group of other stop objects)
        * 'pw' - waiting position/area for passengers
        * 'vw' - waiting position for vehicles
        * 'mc' - misc
    id_ : str
        Unique identifier for the object within the given combination of
        source and type.
    name : str
        Name of the stop.
    lat : float
        Latitude of the stop.
    lon : float
        Longitude of the stop.
    uid : str
        Unique identifier for the object within all sources and types of the
        form source_type_id, where non-word characters in id are replaced by _.
    notes : list of str
        Human readable notes added during processing the stop.

    """
    
    def __init__(self, source, type_, id_, name, lat, lon):
        """
        Parameters
        ----------
        source : str
            Identifier for the source of the object like 'gtfs' or 'osm'.
        type_ : str
            Identifier for the object type. Use one of
            * 'sp' - stop place (group of other stop objects)
            * 'pw' - waiting position/area for passengers
            * 'vw' - waiting position for vehicles
            * 'mc' - misc
        id_ : str
            Unique identifier for the object within the given combination of
            source and type.
        name : str
            Name of the stop.
        lat : float
            Latitude of the stop.
        lon : float
            Longitude of the stop.

        """

        self.source = source
        self.type = type_
        self.id = id_
        self.name = name
        self.lat = float(lat)
        self.lon = float(lon)

        self.uid = f'{self.source}_{self.type}_{re.sub(r'[\W]', '_', self.id)}'
        self.notes = []

    def add_note(self, text, log=True):
        """
        Add a note to the stop object.
        
        Parameters
        ----------
        text : str
            The note's content.
        log : bool, optional
            If True, log an info about adding a note including the note's text.
        
        """

        self.notes.append(text)
        if log:
            logger.info(f'Note for stop object "{self.uid}": {text}')

    def to_json(self):
        """Return dict with all attributes of the stop object. """

        data = dict()

        data['source'] = self.source
        data['type'] = self.type
        data['id'] = self.id
        data['name'] = self.name
        data['lat'] = self.lat
        data['lon'] = self.lon
        data['notes'] = self.notes
        data['uid'] = self.uid

        return data

    def fill_from_json(self, json_dict):
        """
        Overwrite all attributes with values from dict like created by to_json.
        
        """
        
        self.source = json_dict['source']
        self.type = json_dict['type']
        self.id = json_dict['id']
        self.name = json_dict['name']
        self.lat = json_dict['lat']
        self.lon = json_dict['lon']
        self.notes = json_dict['notes']
        self.uid = json_dict['uid']

    def from_json(json_dict):
        """Create stop object from dict like created by to_json. """
        
        obj = PTObject('', '', '', '', 0, 0)
        obj.fill_from_json(json_dict)
        return obj

    def ids_to_objects(self):
        """
        For member variables refering to other objects replace ID strings by
        objects. Call this method after creating an object from JSON data.
        
        Only relevant for derived classes, because StopObject objects do not
        refer to other objects in their attributes.
        
        """
        
        pass


def gdf_from_objects(objs, crs='EPSG:4326'):
    """
    Make GeoDataFrame from list of StopObjects.
    
    Parameters
    ----------
    objs : iterable of StopObject objects
        Objects to create the GeoDataFrame from
    crs : str or anything else understood by GeoPandas
        CRS used for the objects' lat/lon attributes
        
    Returns
    -------
    geopandas.GeoDataFrame
        GeoDataFrame with columns "obj" and "geo". Index contains UIDs.
        
    """

    if len(objs) == 0:
        return gpd.GeoDataFrame(
            {'obj': [], 'geo': []}, index=[], geometry='geo', crs=crs
        )
    
    uids, objs, geos = zip(*[
        (obj.uid, obj, shapely.Point(obj.lon, obj.lat)) for obj in objs
    ])
    
    gdf = gpd.GeoDataFrame(
        {'obj': objs, 'geo': geos},
        index=uids,
        geometry='geo',
        crs=crs
    )
    gdf.index.name = 'uid'
    
    return gdf


def filter_by_bbox(gdf, bbox):
    """
    Filter rows of GeoDataFrame by bounding box.
    
    Parameters
    ----------
    gdf : GeoDataFrame
        The GeoDataFrame to be filtered.
    bbox : (float, float, float, float)
        Tuple (ymin, xmin, ymax, xmax) defining the bbox in the data's CRS.
    
    Returns
    -------
    GeoDataFrame
        subset of the rows of the original GeoDataFrame
    """
    
    return gdf.cx[bbox[1]:bbox[3], bbox[0]:bbox[2]]


def get_neighbors(objs, max_dist, meters_crs=None):
    """
    Group objects by distance. Assigns each object all nearby objects.

    Each object is considered its own neighbor. Thus, if there are no neighbors,
    the object's group still contains an item (the object itself).
    
    Parameters
    ----------
    objs : geopandas.GeoSeries
        GeoSeries of points to group
    max_dist : float
        Maximum distance points are allowed to have within a group.
    meters_crs : str or None
        CRS used for computing (Euclidean) distances in meters. Everything
        understood by GeoPandas is allowed. If None, coordinates in objs are
        used as is (should already be in meters).
    
    Returns
    -------
    pandas.SeriesGroupBy
        GroupBy object assigning each object its neighbors (indices from objs
        parameter are used for identifying the objects).
        
    """

    if len(objs) == 0:
        return pd.Series(index=objs.index, data=[], dtype=int)

    if meters_crs:
        objs = objs.to_crs(meters_crs)
        
    result = objs.sindex.query(
        objs['geo'], predicate='dwithin', distance=max_dist
    )
    result = pd.Series(index=objs.index[result[0]], data=objs.index[result[1]])
    result = result.groupby(result.index, sort=False)

    return result
