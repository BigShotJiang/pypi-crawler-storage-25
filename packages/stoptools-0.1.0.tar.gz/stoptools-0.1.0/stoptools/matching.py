# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Load and process DELFI ZVH data from https://www.opendata-oepnv.de

pw_prepare_data:
    Generate data relevant for computing scores
sp_prepare_data:
    Generate data relevant for computing scores
pw_prematch:
    Find all candidates for matches
sp_prematch:
    Find all candidates for matches
pw_get_scores:
    Compute similarity scores
sp_get_scores:
    Compute similarity scores
pw_save_data_and_scores:
    Write relevant data and scores to CSV file
sp_save_data_and_scores:
    Write relevant data and scores to CSV file
pw_load_data_and_scores:
    Read relevant data and scores from CSV file
sp_load_data_and_scores:
    Read relevant data and scores from CSV file
sort_pair:
    Sort a 2-tuple.
group_by_score:
    Group objects by scores for object pairs
"""

import heapq
import logging
import re

import numpy as np
import pandas as pd
import shapely

from . import zhv, gtfs, ptsa


logger = logging.getLogger(__name__)


_REGEX_NONWORD = re.compile(r'\w+')
_REGEX_IFOPT_PW = re.compile(r'[a-zA-Z]+:[0-9]+:[0-9]+:')
_REGEX_IFOPT_SP = re.compile(r'[a-zA-Z]+:[0-9]+:[0-9]+$')
_REGEX_TRAILING_G = re.compile(r'(_G)*$')

def _names_refs_to_tokens(names, refs):
    """
    Generate sets of tokens for stop name and ref values.

    Parameters
    ----------
    names : str
        All names known for a stop separated by some non-word character.
    refs : str
        All ref values known for a stop separated by some non-word character.

    Returns
    -------
    set of str
        All bigrams contained in the names argument.
    set of str
        All character combinations in the ref argument which look like a
        sensible ref value.
    """

    # make set of bigrams from names (word characters only)
    ntokens = _REGEX_NONWORD.findall(names.lower())
    bigrams = [{a + b for a, b in zip(t[:-1], t[1:])} for t in ntokens]
    ntokens = set.union(*bigrams) if len(bigrams) > 0 else set()

    # make set of (sensible) ref values
    rtokens = _REGEX_NONWORD.findall(refs.lower())
    rtokens = {t for t in rtokens if (
        t.isnumeric() or
        t[:-1].isnumeric() or
        len(t) == 1 or
        (len(t) > 1 and t[1:].isnumeric())
    )}
    
    return ntokens, rtokens


def _is_ifopt(ifopt, place=False):
    """
    Check format of IFOPT.

    Parameters
    ----------
    ifopt : str
        IFOPT to check.
    place : bool, optional
        Check for place IFOPT (True) or passenger wait IFOPT (False).

    Returns
    -------
    bool
        True if IFOPT, else False.
    """

    regex = _REGEX_IFOPT_SP if place else _REGEX_IFOPT_PW
    
    if regex.match(ifopt):
        return True
    else:
        return False


def _get_dparent_ifopt(ifopt):
    """
    Check parent part of IFOPT.

    Parameters
    ----------
    ifopt : str
        IFOPT to extract parent part from.

    Returns
    -------
    str or None
        IFOPT's parent part. None if no valid IFOPT could ne extracted.
    """

    dparent_ifopt = ':'.join(ifopt.split(':')[:3])

    if _is_ifopt(dparent_ifopt, place=True):
        return dparent_ifopt
    else:
        return None


def _gtfs_route_type_to_osm_mod(rt):
    """
    Convert GTFS route type to corresponding OSM modality.
    
    Sources:
    - https://gtfs.org/documentation/schedule/reference/#routestxt
    - https://developers.google.com/transit/gtfs/reference/extended-route-types
    - https://gist.github.com/derhuerst/b0243339e22c310bee2386388151e11e

    Conversion table:
      OSM mod     GTFS route types
      ----------------------------
      bus         3, 200-209, 700-716
      trolleybus  11, 800
      share_taxi  1500-1507, 300 (DELFI only)
      tram        0, 900-906
      light_rail  (0)
      train       2, 100-117
      monorail    12, 405
      subway      1, 400-404, 500, 600
      funicular   5, 7, 1400-1402
      ferry       4, 1000-1021, 1200
      aerialway   6, 1300-1307

    Parameters
    ----------
    rt : int
        GTFS route type.

    Returns
    -------
    str
        OSM modality.
    """

    if rt == 3 or 200 <= rt <= 209 or 700 <= rt <= 716:
        return 'bus'
    if rt == 2 or 100 <= rt <= 117:
        return 'train'
    if rt == 0 or 900 <= rt <= 906:
        return 'tram'
    if rt == 11 or rt == 800:
        return 'trolleybus'
    if 1500 <= rt <= 1507 or rt == 300:
        return 'share_taxi'
    if rt == 12 or rt == 405:
        return 'monorail'
    if rt == 1 or 400 <= rt <= 404 or rt == 500 or rt == 600:
        return 'subway'
    if rt == 5 or rt == 7 or 1400 <= rt <= 1402:
        return 'funicular'
    if rt == 4 or 1000 <= rt <= 1021 or rt == 1200:
        return 'ferry'
    if rt == 6 or 1300 <= rt <= 1307:
        return 'aerialway'

    logger.warning(f'unknown GTFS route type: {rt}')
    return None


def _get_neighbors(df, col, radius):
    """
    Find neighbors in a set of points.
    
    Expects a column of sets in the passed data frame to add found neighbors to.

    Parameters
    ----------
    df : geopandas.GeoDataFrame
        GeoDataFrame of points.
    col : str
        Name of column of sets to add neighbor UIDs to.
    radius : int
        Maximum distance of points to be considered neighbors.

    """

    if len(df) == 0:
        return

    result = df.sindex.query(df['geo'], predicate='dwithin', distance=radius)
    neighbors = (
        pd.Series(df.index[result[1]])
        .groupby(df.index[result[0]], sort=False)
        .aggregate(set)
    )
    for center_id in neighbors.index:
        df.at[center_id, col].update(neighbors.at[center_id])


def _get_name_score(tokens1, tokens2, neutral=0.6):
    """
    Get similarity score for names of two stop objects.
    
    Range is -1 (different names) to 1 (identical names). Zero represents a
    neutral result (e.g. "no names available").
    
    Parameters
    ----------
    tokens1 : set of str
        Name tokens, e.g. bigrams.
    tokens2 : set of str
        Name tokens, e.g. bigrams.
    neutral : int, optional
        Which score is to be mapped to 0 (original score has range 0...1).

    Returns
    -------
    float
        Score.

    """

    if tokens1 == set() or tokens2 == set():
        return 0.0
        
    score = len(tokens1 & tokens2) / min([len(tokens1), len(tokens2)])
    if score < neutral:
        return (score - neutral) / neutral
    else:
        return (score - neutral) / (1 - neutral)


def _get_ref_score(tokens1, tokens2):
    """
    Get similarity score for ref values of two stop objects.
    
    Range is -1 (no common ref values) to 1 (at least one common ref value).
    Zero represents a neutral result (e.g. "no ref values available").
    
    Parameters
    ----------
    tokens1 : set of str
        Ref values.
    tokens2 : set of str
        Ref values.

    Returns
    -------
    float
        Score.

    """

    if tokens1 == set() or tokens2 == set():
        return 0.0
    
    if tokens1 & tokens2 != set():
        return 1.0
    else:
        return -1.0  # both have tokens, but empty intersection


def _get_ifopt_score(ifopt1, ifopt2):
    """
    Get similarity score for IFOPTs of two stop objects.
    
    Range is -1 (different IFOPTs) to 1 (identical IFOPTs). Zero represents a
    neutral result (e.g. "no IFOPTs available").
    
    Parameters
    ----------
    ifopt1 : str
        IFOPT.
    ifopt2 : str
        IFOPT.

    Returns
    -------
    float
        Score.

    """

    if ifopt1 is None or ifopt2 is None:
        return 0.0

    if ifopt1 == ifopt2:
        return 1.0
    else:
        return -1.0


def _get_mods_score(mods1, mods2):
    """
    Get similarity score for modalities of two stop objects.
    
    Range is -1 (no common modalities) to 1 (identical modalities). Zero
    represents a neutral result (e.g. "no modalities available").
    
    Parameters
    ----------
    mods1 : set of str
        Modalities.
    mods2 : set of str
        Modalities.

    Returns
    -------
    float
        Score.

    """

    if mods1 is None or mods2 is None:
        return 0.0

    intersection = mods1 & mods2
    if intersection == set():
        return -1.0
    else:
        return len(intersection) / len(mods1 | mods2)


def _get_distance_score(geo1, geo2, radius):
    """
    Get score for distance between two stop objects.
    
    Range is -1 (distance at least radius) to 1 (distance 0). Score decreases
    linearly with distance.
    
    Parameters
    ----------
    geo1 : shapely.Point
        Point describing the stop's location.
    geo1 : shapely.Point
        Point describing the stop's location.
    radius : int
        Maximum distance yielding a score above -1.

    Returns
    -------
    float
        Score.

    """

    d = shapely.distance(geo1, geo2)

    if d > radius:
        return -1.0
    return (radius - d) / radius
        
        
def pw_prepare_data(pws, gtfs_stop_routes=None, ptsa_stop_routes=None):
    """
    Generate data relevant for computing scores (for passenger wait objects).

    Following new columns will be added to the input data frame in-place:
    - 'name_tokens': set of bigrams obtained from object's name
    - 'ref_tokens': set of ref values
    - 'ifopt': object's IFOPT or None
    - 'parent_iftop': IFOPT of parent place or None
    - 'dparent_ifopt': parent part if object's IFOPT or None
    - 'mods': set of OSM modalities
    - 'prev_stops': set of UIDs of previous stops in routes
    - 'next_stops': set of UIDs of next stops in routes

    Parameters
    ----------
    pws : geopandas.GeoDataFrame
        GeoDataFrame of stop objects.
    gtfs_stop_routes : dict or None, optional
        Route information for stops generated by gtfs.get_stop_routes.
    ptsa_stop_routes : dict or None, optional
        Route information for stops generated by ptsa.get_stop_routes.

    """

    pws['name_tokens'] = None
    pws['ref_tokens'] = None
    pws['ifopt'] = None
    pws['parent_ifopt'] = None
    pws['dparent_ifopt'] = None
    pws['mods'] = None
    pws['prev_stops'] = None
    pws['next_stops'] = None

    for uid in pws.index:
        pw = pws.at[uid, 'obj']
        
        if isinstance(pw, zhv.ZHVQuay):
            names = pw.name
            refs = pw.zhv_name
            ifopt = pw.id
            if isinstance(pw.parent, zhv.ZHVPlace):
                parent_ifopt = pw.parent.id
            elif isinstance(pw.parent, zhv.ZHVArea) and pw.parent.parent:
                parent_ifopt = pw.parent.parent.id
            else:
                parent_ifopt = None
            stop_routes = None
        elif isinstance(pw, gtfs.GTFSPlatform):
            names = pw.name
            refs = pw.platform_code
            ifopt = _REGEX_TRAILING_G.sub('', pw.id)
            if isinstance(pw.parent, gtfs.GTFSStation):
                parent_ifopt = _REGEX_TRAILING_G.sub('', pw.parent.id)
            else:
                parent_ifopt = None
            if gtfs_stop_routes:
                stop_routes = gtfs_stop_routes.get(uid)
            else:
                stop_routes = None
            if stop_routes:
                pws.at[uid, 'mods'] = {
                    _gtfs_route_type_to_osm_mod(rt)
                    for rt in stop_routes['route_types']
                }
        elif isinstance(pw, ptsa.PTSAStop):
            names = ';'.join(pw.names + pw.refs)
            refs = ';'.join(pw.refs)
            ifopt = pw.ifopt
            if pw.stop_place:
                parent_ifopt = pw.stop_place.ifopt
            else:
                parent_ifopt = None
            pws.at[uid, 'mods'] = set(pw.mods)
            if ptsa_stop_routes:
                stop_routes = ptsa_stop_routes.get(uid)
            else:
                stop_routes = None
        else:
            logger.warning(f'Object with UID "{uid}" is not a passenger wait object!')

        name_tokens, ref_tokens = _names_refs_to_tokens(names, refs)
        pws.at[uid, 'name_tokens'] = name_tokens
        pws.at[uid, 'ref_tokens'] = ref_tokens
        if ifopt and _is_ifopt(ifopt):
            pws.at[uid, 'ifopt'] = ifopt
            pws.at[uid, 'dparent_ifopt'] = _get_dparent_ifopt(ifopt)
        if parent_ifopt and _is_ifopt(parent_ifopt, place=True):
            pws.at[uid, 'parent_ifopt'] = parent_ifopt
        if stop_routes:
            pws.at[uid, 'prev_stops'] = set(
                pws.index.intersection(stop_routes['prev_stops'])
            )
            pws.at[uid, 'next_stops'] = set(
                pws.index.intersection(stop_routes['next_stops'])
            )


def sp_prepare_data(sps):
    """
    Generate data relevant for computing scores (for stop place objects).

    Following new columns will be added to the input data frame in-place:
    - 'name_tokens': set of bigrams obtained from object's name
    - 'ifopt': object's IFOPT or None

    Parameters
    ----------
    sps : geopandas.GeoDataFrame
        GeoDataFrame of stop place objects.

    """

    sps['name_tokens'] = None
    sps['ifopt'] = None

    for uid in sps.index:
        sp = sps.at[uid, 'obj']
        
        if isinstance(sp, zhv.ZHVPlace):
            names = sp.name
            ifopt = sp.id
        elif isinstance(sp, gtfs.GTFSStation):
            names = sp.name
            ifopt = _REGEX_TRAILING_G.sub('', sp.id)
        elif isinstance(sp, ptsa.PTSAStopPlace):
            if sp.name != '':
                names = sp.name
            else:
                names = ';'.join([stop.name for stop in sp.stops])
            ifopt = sp.ifopt
        else:
            logger.warning(f'Object with UID "{uid}" is not a stop place object!')

        name_tokens, _ = _names_refs_to_tokens(names, '')
        sps.at[uid, 'name_tokens'] = name_tokens
        if ifopt and _is_ifopt(ifopt, place=True):
            sps.at[uid, 'ifopt'] = ifopt


def pw_prematch(pws, radius):
    """
    Find all candidates for matches.
    
    Candidates are neighbors and stops with same parent. Neightbor search
    assumes that the data frame's CRS is in meters (Euclidean distances).
    
    A new column "prematches" with sets of candidate UIDs for each stop will be
    added in-place to the data frame.

    Parameters
    ----------
    pws : geopandas.GeoDataFrame
        GeoDataFrame of stop objects.
    radius : int
        Maximum distance of stops to be considered neighbors.
    
    """

    # find neighbors
    pws['prematches'] = [set() for _ in pws.index]
    _get_neighbors(pws, 'prematches', radius)

    # add stops with same parent place
    same_parent_groups = (
        pws['parent_ifopt']
        .reset_index()
        .groupby('parent_ifopt', sort=False)
        .aggregate(set)
    )
    for parent_ifopt, group in same_parent_groups['uid'].items():
        for uid in group:
            pws.at[uid, 'prematches'].update(group)
    del same_parent_groups

    # add stops with same dparent place
    same_dparent_groups = (
        pws['dparent_ifopt']
        .reset_index()
        .groupby('dparent_ifopt', sort=False)
        .aggregate(set)
    )
    for dparent_ifopt, group in same_dparent_groups['uid'].items():
        for uid in group:
            pws.at[uid, 'prematches'].update(group)
    del same_dparent_groups

    # from each candidates group remove the stop itself
    for uid in pws.index:
        pws.loc[uid, 'prematches'].discard(uid)
    

def sp_prematch(sps, radius):
    """
    Find all candidates for matches.
    
    Candidates are neighbors only. Neightbor search assumes that the data
    frame's CRS is in meters (Euclidean distances).
    
    A new column "prematches" with sets of candidate UIDs for each stop place
    will be added in-place to the data frame.

    Parameters
    ----------
    sps : geopandas.GeoDataFrame
        GeoDataFrame of stop place objects.
    radius : int
        Maximum distance of stop places to be considered neighbors.
    
    """

    # find neighbors
    sps['prematches'] = [set() for _ in sps.index]
    _get_neighbors(sps, 'prematches', radius)

    # from each candidates group remove the stop place itself
    for uid in sps.index:
        sps.loc[uid, 'prematches'].discard(uid)
    

def pw_get_scores(pws, radius):
    """
    Compute similarity scores for passenger wait objects.
    
    Parameters
    ----------
    pws : geopandas.GeoDataFrame
        GeoDataFrame of passenger wait objects with columns added by
        pw_prepare_data and pw_prematch.
    radius : int
        Maximum distance of stops to yield non-minimal distance score.
    
    Returns
    -------
    pandas.DataFrame
        Data frame with different categories of scores for each pair of
        (prematched) objects. Index is a MultiIndex of two UIDs.
    
    """
    
    index = dict(uid1=[], uid2=[])
    scores = dict(
        name=[], ref=[], ifopt=[], parent_ifopt=[], dparent_ifopt=[], mods=[],
        distance=[]
    )

    for uid1 in pws.index:
        for uid2 in {uid2 for uid2 in pws.at[uid1, 'prematches'] if uid1 < uid2}:
            index['uid1'].append(uid1)
            index['uid2'].append(uid2)
            scores['name'].append(_get_name_score(
                pws.at[uid1, 'name_tokens'], pws.at[uid2, 'name_tokens']
            ))
            scores['ref'].append(_get_ref_score(
                pws.at[uid1, 'ref_tokens'], pws.at[uid2, 'ref_tokens']
            ))
            scores['ifopt'].append(_get_ifopt_score(
                pws.at[uid1, 'ifopt'], pws.at[uid2, 'ifopt']
            ))
            scores['parent_ifopt'].append(_get_ifopt_score(
                pws.at[uid1, 'parent_ifopt'], pws.at[uid2, 'parent_ifopt']
            ))
            scores['dparent_ifopt'].append(_get_ifopt_score(
                pws.at[uid1, 'dparent_ifopt'], pws.at[uid2, 'dparent_ifopt']
            ))
            scores['mods'].append(_get_mods_score(
                pws.at[uid1, 'mods'], pws.at[uid2, 'mods']
            ))
            scores['distance'].append(_get_distance_score(
                pws.at[uid1, 'geo'], pws.at[uid2, 'geo'], radius
            ))
            
    index = pd.MultiIndex.from_frame(pd.DataFrame(data=index))
    scores = pd.DataFrame(data=scores, index=index, dtype=np.float16)

    return scores


def sp_get_scores(sps, radius):
    """
    Compute similarity scores for stop place objects.
    
    Parameters
    ----------
    sps : geopandas.GeoDataFrame
        GeoDataFrame of stop place objects with columns added by sp_prepare_data
        and sp_prematch.
    radius : int
        Maximum distance of stop places to yield non-minimal distance score.
    
    Returns
    -------
    pandas.DataFrame
        Data frame with different categories of scores for each pair of
        (prematched) objects. Index is a MultiIndex of two UIDs.
    
    """
    
    index = dict(uid1=[], uid2=[])
    scores = dict(name=[], ifopt=[], distance=[])

    for uid1 in sps.index:
        for uid2 in {uid2 for uid2 in sps.at[uid1, 'prematches'] if uid1 < uid2}:
            index['uid1'].append(uid1)
            index['uid2'].append(uid2)
            scores['name'].append(_get_name_score(
                sps.at[uid1, 'name_tokens'], sps.at[uid2, 'name_tokens']
            ))
            scores['ifopt'].append(_get_ifopt_score(
                sps.at[uid1, 'ifopt'], sps.at[uid2, 'ifopt']
            ))
            scores['distance'].append(_get_distance_score(
                sps.at[uid1, 'geo'], sps.at[uid2, 'geo'], radius
            ))
            
    index = pd.MultiIndex.from_frame(pd.DataFrame(data=index))
    scores = pd.DataFrame(data=scores, index=index, dtype=np.float16)

    return scores


def pw_save_data_and_scores(data, scores, data_path, scores_path):
    """
    Write data and scores returned by pw_prepare_data and pw_get_scores,
    respectively, to CSV file.
    
    Parameters
    ----------
    data : pandas.DataFrame
        DataFrame with columns added by pw_prepare data.
    scores : pandas.DataFrame
        DataFrame returned by pw_get_scores.
    data_path : str
        Path of CSV file to write data to.
    scores_path : str
        Path of CSV file to write scores to.
        
    """

    def set_to_str(s):
        return ';'.join(s) if s is not None else 'NONE'
    pd.concat([
        data['name_tokens'].apply(set_to_str),
        data['ref_tokens'].apply(set_to_str),
        data['ifopt'],
        data['parent_ifopt'],
        data['dparent_ifopt'],
        data['mods'].apply(set_to_str),
        data['prev_stops'].apply(set_to_str),
        data['next_stops'].apply(set_to_str)
    ], axis=1).to_csv(data_path)

    scores.to_csv(scores_path)


def sp_save_data_and_scores(data, scores, data_path, scores_path):
    """
    Write data and scores returned by sp_prepare_data and sp_get_scores,
    respectively, to CSV file.
    
    Parameters
    ----------
    data : pandas.DataFrame
        DataFrame with columns added by sp_prepare data.
    scores : pandas.DataFrame
        DataFrame returned by sp_get_scores.
    data_path : str
        Path of CSV file to write data to.
    scores_path : str
        Path of CSV file to write scores to.
        
    """

    pd.concat([
        data['name_tokens'].apply(lambda t: ';'.join(t)),
        data['ifopt'],
    ], axis=1).to_csv(data_path)

    scores.to_csv(scores_path)


def pw_load_data_and_scores(data_path, scores_path):
    """
    Read data and scores written with pw_save_data_and_scores.
    
    Parameters
    ----------
    data_path : str
        Path of CSV file to read data from.
    scores_path : str
        Path of CSV file to read scores from.

    Returns
    -------
    data : pandas.DataFrame
        DataFrame with columns like added by pw_prepare data.
    scores : pandas.DataFrame
        DataFrame like returned by pw_get_scores.
        
    """

    data = pd.read_csv(
        data_path, index_col='uid', dtype=str, keep_default_na=False
    )

    def str_to_set(s):
        if s == '':
            return set()
        elif s == 'NONE':
            return None
        else:
            return set(s.split(';'))
    data['name_tokens'] = data['name_tokens'].apply(str_to_set)
    data['ref_tokens'] = data['ref_tokens'].apply(str_to_set)
    data['mods'] = data['mods'].apply(str_to_set)
    data['prev_stops'] = data['prev_stops'].apply(str_to_set)
    data['next_stops'] = data['next_stops'].apply(str_to_set)

    scores = pd.read_csv(scores_path, index_col=['uid1', 'uid2'])
    scores = scores.astype(np.float16)

    return data, scores


def sp_load_data_and_scores(data_path, scores_path):
    """
    Read data and scores written with sp_save_data_and_scores.
    
    Parameters
    ----------
    data_path : str
        Path of CSV file to read data from.
    scores_path : str
        Path of CSV file to read scores from.

    Returns
    -------
    data : pandas.DataFrame
        DataFrame with columns like added by sp_prepare data.
    scores : pandas.DataFrame
        DataFrame like returned by sp_get_scores.
        
    """

    data = pd.read_csv(
        data_path, index_col='uid', dtype=str, keep_default_na=False
    )

    data['name_tokens'] = data['name_tokens'].apply(
        lambda s: set(s.split(';')) if s != '' else set()
    )

    scores = pd.read_csv(scores_path, index_col=['uid1', 'uid2'])
    scores = scores.astype(np.float16)

    return data, scores


def sort_pair(a, b):
    """
    Sort a 2-tuple.
    
    Parameters
    ----------
    2-tuple
        Tuple to sort.
    
    Returns
    -------
    2-tuple
        Sorted tuple.
    
    """
    
    return tuple(sorted((a, b)))


def group_by_score(uids, scores, join_func='max', min_score=0,
                   all_groups=False, progress=False):
    """
    Group objects by scores for object pairs.
    
    Objects are grouped starting with singleton groups by joining pairs of
    groups with highest score. Scores for pairs of groups are computed everytime
    two groups get joined; either as min or max of the corresponding group-group
    scores (for join D=A+B score of pair DC will be min/max of AC score and BC
    score).
    
    Parameters
    ----------
    uids : iterable of str
        List of all UIDs to group.
    scores : pandas.Series
        Score for UID-UID pairs to group by. Index is a MultiIndex (UID, UID).
        Data are floats.
    join_func : on of 'min', 'max', optional
        How to compute new group-group scores after joining two groups.
    min_score : float
        Ignore scores below this value (such pairs are considered non-matching).
    all_groups: bool, optional
        If False return final groups only. If True, return all groups including
        intermediate groups, together with information which (intermediate)
        groups got joined.
    progress: bool, optional
        If True, write progress to the logs (DEBUG).
    
    Returns
    -------
    pandas.Series
        Index is like uids argument. Data are group IDs indicating which UIDs
        belong to the same group.
    dict of str: set of str
        For each group ID (key) the dict contains the set of all UIDs belonging
        to the group (for fast access to group members). If all_groups is False,
        only group IDs appearing in the first return value are contained. Else,
        intermediate groups created during the join process are contained, too.
    dict of str: str
        Only returned if all_groups is True. The dict maps each (intermediate)
        group ID to the group ID resulting from joining the group with another
        group. If key and value coincide, the group is a final group (not joined
        with any other group). From this dict the complete join process can be
        reconstructed.
    dict of (str, str): float
        Only returned if all_groups is True. The dict maps GID pairs to the
        pair's score.
    
    """
    
    # initial singleton groups
    logger.debug('Creating initial singleton groups...')
    gids = pd.Series(index=uids, data=range(1, len(uids) + 1))
    groups = dict(zip(gids, map(lambda x: {x}, gids.index)))
    joined_gids = dict(zip(gids, gids))
    next_gid = len(gids) + 1
    logger.debug('...done creating initial singleton groups.')

    # initial group-group scores
    # (ggscores maps GID pairs to score; ggscores_queue is a priority queue
    # yielding the group-group match with highest score; matching_gids maps GIDs
    # to sets of matching GIDs (provides fast access to all matches for a
    # group))
    logger.debug('Generating initial group-group scores...')
    good_scores = scores.loc[scores >= min_score]
    gid_pairs = zip(
        gids.loc[good_scores.index.get_level_values(0)],
        gids.loc[good_scores.index.get_level_values(1)]
    )
    gid_pairs = list(map(lambda x: sort_pair(*x), gid_pairs))
    ggscores_queue = list(zip((-good_scores).array, gid_pairs))
    ggscores = dict(zip(gid_pairs, (-good_scores).array))
    heapq.heapify(ggscores_queue)
    matching_gids = dict(zip(gids, [set() for _ in range(len(gids))]))
    for gid1, gid2 in gid_pairs:
        matching_gids[gid1].add(gid2)
        matching_gids[gid2].add(gid1)    
    del good_scores, gid_pairs
    logger.debug('...done generating initial group-group scores.')

    # match groups
    logger.debug('Grouping...')
    output_counter = 0
    output_every = len(ggscores_queue) / 100
    while len(ggscores_queue) > 0:

        # progress
        if progress:
            output_counter += 1
            if output_counter >= output_every:
                logger.debug(f'remaining group pairs to process: {len(ggscores_queue)}')
                output_counter = 0

        # get next group-group score
        _, (gid1, gid2) = heapq.heappop(ggscores_queue)
        if gid1 != joined_gids[gid1] or gid2 != joined_gids[gid2]:
            continue  # at least one of the groups already got joined with
                      # another group (one of the groups doesn't exist anymore)
        group1 = groups[gid1]
        group2 = groups[gid2]
        
        # join groups
        gid = next_gid
        next_gid += 1
        group = group1 | group2
        groups[gid] = group
        if not all_groups:
            del groups[gid1], groups[gid2]
        gids.loc[list(group1) + list(group2)] = gid
        joined_gids[gid1] = gid
        joined_gids[gid2] = gid
        joined_gids[gid] = gid
        mgids1 = matching_gids[gid1]
        mgids2 = matching_gids[gid2]
        if join_func == 'min':
            mgids = matching_gids[gid1] & matching_gids[gid2]
        else:
            mgids = matching_gids[gid1] | matching_gids[gid2]
        matching_gids[gid] = mgids
        for mgid in mgids:
            matching_gids[mgid] = (matching_gids[mgid] | {gid}) - {gid1, gid2}
            score1 = ggscores.get(sort_pair(gid1, mgid), min_score - 1)
            score2 = ggscores.get(sort_pair(gid2, mgid), min_score - 1)
            if join_func == 'min':
                score = min(score1, score2)  # both are > min_score
            else:
                score = max(score1, score2)  # at least one is > min_score
            ggscores[sort_pair(gid, mgid)] = score
            heapq.heappush(ggscores_queue, (score, (gid, mgid)))

    if all_groups:
        return gids, groups, joined_gids, ggscores
    else:
        final_groups = {
            gid_new: groups[gid_new]
            for gid_old, gid_new in joined_gids.items()
            if gid_old == gid_new
        }
        return gids, final_groups
