# Copyright (C) 2025-present by Jens Flemming, https://whz.de/~jef19jdw
#
# This file is part of the stoPTools Python package.
#
# The stoPTools Python package is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the License,
# or any later version.
#
# The stoPTools Python package is distributed in the hope that it will be
# useful, but WITHOUT # ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero
# General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see https://www.gnu.org/licenses/agpl.html. 

"""Validate DELFI GTFS data from https://www.opendata-oepnv.de

not_in_area:
    Check whether points are in a given area
same_location:
    Find stations/platforms/misc objects with (almost) identical location
invalid_ids:
    Extract invalid object IDs
valid_ids:
    Extract valid object IDs
not_in_zhv:
    Check whether stops are listed in ZHV
dparent_not_in_zhv:
    Find stop IDs whoes derived parent station ID is not listed in ZHV
duplicate_trips:
    Find trips with identical stops and times having overlapping service dates
    
"""

import itertools
import re

import pandas as pd

from .stopsvalid import not_in_area, same_location

 
def invalid_ids(ids, accept_g=False):
    """
    Extract invalid object IDs.

    Expected format is "de:0123:uvw" or "de:123:uvw:xyz", where 123 is some
    integer, uvw is some non-empty string without ":" or white-space and xyz is
    some non-empty string.
    
    Parameters
    ----------
    ids : iterable of str
        IDs to check
    accept_g: bool
        If True, consider IDs ending with _G, _G_G aso. as valid.
    
    Returns
    -------
    list of str or (list of str, list of str)
        If accept_g is False, return list of invalid IDs. If accept_g is True,
        return two lists of IDs, one list of IDs even invalid if _G suffixes are
        ignored and one list of IDs correct only if _G suffixes are ignored.

    """
    

    # all invalid IDs
    regex_valid = re.compile(r'\w+:\w+:\w+(:+[^:]+)*$')
    invalid_ids = [id_ for id_ in ids
                   if id_.endswith('_G') or not regex_valid.match(id_)]
    if not accept_g:
        return invalid_ids
    
    # invalid IDs that are valid after dropping _G suffixes
    regex_g = re.compile(r'.*?(?=(_G)+$)')
    def valid_after_dropping_g(id_):
        m = regex_g.match(id_)
        return bool(regex_valid.match(m[0])) if m else False
    valid_g_ids = [id_ for id_ in ids if valid_after_dropping_g(id_)]
    
    return invalid_ids, valid_g_ids


def valid_ids(ids, accept_g=False):
    """
    Extract valid object IDs.

    Expected format is "de:0123:uvw" or "de:123:uvw:xyz", where 123 is some
    integer, uvw is some non-empty string without ":" or white-space and xyz is
    some non-empty string.
    
    Parameters
    ----------
    ids : iterable of str
        IDs to check
    accept_g: bool
        If True, consider IDs ending with _G, _G_G aso. as valid.
    
    Returns
    -------
    list of str
        If accept_g is False, return list of valid IDs. If accept_g is True,
        return a list containing all valid IDs and all IDs valid after removing
        _G suffixes (list items will be without _G). Note the due to removing
        _G the list may contain duplicate IDs!

    """
    
    # all valid IDs (including the ones with _G)
    regex_valid = re.compile(r'\w+:\w+:\w+(:+[^:]+)*$')
    valid_ids = [id_ for id_ in ids if regex_valid.match(id_)]
    
    if not accept_g:
        return [id_ for id_ in valid_ids if not id_.endswith('G')]
    else:
        regex_g = re.compile(r'(_G)+$')
        return [regex_g.sub('', id_) for id_ in valid_ids]


def not_in_zhv(ids, zhv_ids):
    """
    Find stop IDs not listed in ZHV.

    Parameters
    ----------
    ids : iterable of str
        IDs to check
    zhv_ids: iterable of str
        All IDs from ZHV.
    
    Returns
    -------
    list of str
        IDs not found in ZHV.

    """

    return list(set(ids) - set(zhv_ids))


def dparent_not_in_zhv(ids, zhv_ids):
    """
    Find stop IDs whoes derived parent station ID is not listed in ZHV.

    Parameters
    ----------
    ids : iterable of str
        IDs to check
    zhv_ids: iterable of str
        All IDs from ZHV.
    
    Returns
    -------
    list of (str, str)
        Stop IDs without parent station ID in ZHV. List of tuples
        (ID, parent ID).

    """

    dparent_ids = [':'.join(id_.split(':')[:3]) for id_ in ids]
    zhv_ids = set(zhv_ids)
    return [(id_, dparent_id) for id_, dparent_id in zip(ids, dparent_ids)
            if dparent_id not in zhv_ids]


def duplicate_trips(trips, times, date_lists, objs, max_dist, meters_crs=None):
    """
    Find trips with identical stops and times having overlapping service dates.
    
    Parameters
    ----------
    trips : pandas.DataFrame
        Trips data as returned by gtfs.df_from_zip.
    times : pandas.DataFrame
        Stop times as returned by gtfs.df_from_zip.
    date_lists : pandas.Series
        Series of date lists as returned by gtfs.calendar_to_date_lists. Index
        has to contain GTFS service IDs.
    objs : geopandas.GeoDataFrame
        GeoDataFrame of all stop objects that may appear in trips as returned by
        gtfs.gdf_from_df.
    meters_crs : str, optional
        CRS used for computing (Euclidean) distances in meters. Everything
        understood by GeoPandas is allowed. If None, coordinates in objs are
        used as is (should already be in meters).

    Returns
    -------
    list of (str, str, list of datetime64, bool)
        List of trip pairs that have same first departure and last arrival time
        as well as same number of stops, where distance in each stop pair is at
        most max_dist. Each tuple contains the two trip IDs, a list of dates
        both trips are serviced, and a flag. The flag is True if all stops of
        both trips are identical (same ID) and False, if at least one stop pair
        consists of two different stops.
    set of (str, str)
        Set of non-identical stop pairs appearing in trip pairs at the same
        position. Both stop IDs seem to refer to the same stop.

    """
    
    # add information to trips
    trip_times = times.sort_values(['trip_id', 'seq']) \
                      .groupby('trip_id', sort=False)
    stop_lists = trip_times['stop_id'].aggregate(lambda stops: list(stops))
    trip_infos = pd.concat({
        'stops': stop_lists,
        'len_stops': stop_lists.apply(len),
        'departure': trip_times['departure'].first(),
        'arrival': trip_times['arrival'].last()
    }, axis=1)
    del stop_lists

    # replace index of stop objects by ID index
    obj_ids = objs['obj'].apply(lambda obj: obj.id)
    objs = objs.set_index(obj_ids)
    del obj_ids
    
    # set CRS
    if meters_crs:
        objs = objs.to_crs(meters_crs)
    
    # group trips by (number of stops, departure time, arrival time),
    # then check for duplicates in each group
    date_sets = date_lists.apply(lambda l: set(l))
    trip_pairs = []
    stop_pairs = set()
    for (len_stops, departure, arrival), group \
    in trip_infos.groupby(['len_stops', 'departure', 'arrival']):
        for trip_id1, trip_id2 in itertools.combinations(group.index, 2):

            # usual trip with stops and times (GTFS allows for empty values here
            # in certain situations)?
            stops1 = trip_infos.at[trip_id1, 'stops']
            stops2 = trip_infos.at[trip_id2, 'stops']
            if not departure or not arrival or '' in stops1 or '' in stops2:
                continue
        
            # date overlap?
            dates1 = date_sets.at[trips.at[trip_id1, 'service_id']]
            dates2 = date_sets.at[trips.at[trip_id2, 'service_id']]
            date_overlap = dates1 & dates2
            if len(date_overlap) == 0:
                continue

            # identical stops?
            identical = True if stops1 == stops2 else False

            # almost identical stops?
            if not identical:
                dists = objs.loc[stops1, 'geo'] \
                            .distance(objs.loc[stops2, 'geo'], align=False)
                if dists.max() > max_dist:  # different trips
                    continue
            
            # check for trip pair with all stops close together (e.g. ferries
            # crossing narrow rivers), which would result in a false positive
            # if trips have opposite directions
            dists = objs.loc[stops1, 'geo'] \
                        .distance(objs.loc[stops2[::-1], 'geo'], align=False)
            if dists.max() <= max_dist:
                # start 1 close to end 2 and vice versa
                continue

            trip_pairs.append((trip_id1, trip_id2, date_overlap, identical))

            # stop pairs
            for stop_id1, stop_id2 in zip(trip_infos.at[trip_id1, 'stops'],
                                            trip_infos.at[trip_id2, 'stops']):
                if stop_id1 == stop_id2:
                    continue
                pair = (stop_id1, stop_id2) if stop_id1 < stop_id2 \
                        else (stop_id2, stop_id1)
                stop_pairs.add(pair)
    
    return trip_pairs, stop_pairs
