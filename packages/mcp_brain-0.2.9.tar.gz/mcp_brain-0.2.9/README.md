# MCP-Brain: Multi-agent Cognitive Processing Framework

A lightweight AI framework that runs **locally** on your machine using **MiniMax API**. Three specialized agents — Analyst, Creator, and Critic — collaborate through a structured cognitive pipeline to solve complex problems.

```
User Task
   │
   ▼
┌──────────┐   Analyst breaks it down
│ Analyst ├─────────────────────────┐
└──────────┘                       │
   │                                │
   ▼                                │
┌──────────┐   Creator drafts   ┌──────────┐
│ Creator  │◄──────────────────┤ Analyst  │
└──────────┘                    │ Context  │
   │                            └──────────┘
   │                                │
   ▼                                │
┌──────────┐   Critic evaluates  ┌──────────┐
│ Critic   │◄────────────────────┤ Creator  │
└──────────┘                     │ Draft    │
   │                            └──────────┘
   │                                │
   ▼                                │
┌──────────┐   Creator improves   ┌──────────┐
│ Creator  │◄────────────────────┤ Critic   │
└──────────┘                     │ Feedback │
   │                            └──────────┘
   │
   ▼
┌──────────┐   Critic final     ┌──────────┐
│ Critic   │◄──────eval─────────│ Improved │
└──────────┘                    │ Solution │
   │                            └──────────┘
   ▼
Final Solution + Evaluation
```

## Features

- **Local-only** — API key and data never leave your machine
- **Multi-agent cognition** — mimics human collaborative problem-solving
- **Persistent memory** — sessions saved to `~/.mcp/` for review
- **Simple CLI** — `mcp setup`, `mcp process`, `mcp sessions`
- **Streaming support** — stream responses token-by-token

## Installation

```bash
# Download and run installer
curl -fsSL https://raw.githubusercontent.com/MC80s/mcp/main/install.sh | bash
```
# Or manually install from source
git clone https://github.com/MC80s/mcp.git
cd mcp
bash install.sh

# Or install with pip
pip install mcp-brain
```

## Quick Start

```bash
# 1. Configure your MiniMax API key
mcp setup

# 2. Process your first task
mcp process "Design a logo for a tech startup called Quantum Leap"

# 3. View previous sessions
mcp sessions

# 4. Check config status
mcp status
```

## How It Works

| Step | Agent | Role |
|------|-------|------|
| 1 | Analyst | Breaks down the problem into components |
| 2 | Creator | Generates an initial creative solution |
| 3 | Critic | Evaluates the draft, identifies flaws |
| 4 | Creator | Improves the solution based on critique |
| 5 | Critic | Final evaluation and rating |

## Cost Estimation

MiniMax API is pay-per-use. Each task runs 5 agent calls.

| Complexity | Est. Cost |
|------------|-----------|
| Simple task | ~$0.02–0.05 |
| Medium task | ~$0.05–0.15 |
| Complex task | ~$0.15–0.30 |

No subscription fees. You control your usage.

## Project Structure

```
mcp-brain/
├── src/mcp/
│   ├── minimax_client.py   # MiniMax API client
│   ├── agents.py            # Creator/Critic/Analyst agents
│   ├── memory.py            # Working memory
│   ├── mcp_core.py          # Orchestration engine
│   └── cli.py               # CLI commands
├── scripts/
├── tests/
├── setup.py
├── pyproject.toml
├── install.sh
└── README.md
```

## CLI Commands

```
mcp setup              Interactively configure API key
mcp process "task"    Run a task through the cognitive pipeline
mcp sessions          List recent sessions
mcp session <id>      View full session details
mcp status            Check configuration
```

## Hermes Integration

Connect `mcp-brain` as a native tool server inside Hermes (your AI agent framework). Once connected, Hermes can delegate complex reasoning tasks to the multi-agent pipeline.

### Requirements
- Hermes gateway installed (`hermes setup`)
- `mcp-brain` installed (`pip install mcp-brain`)

### Setup

**Step 1:** Add to your Hermes config at `~/.hermes/config.yaml`:

```yaml
mcp_servers:
  mcp-brain:
    command: "/home/YOUR_USERNAME/.local/bin/mcp-brain-server"
```

Find your username with `whoami` and substitute the path accordingly.

**Step 2:** Restart the Hermes gateway:
```bash
systemctl --user restart hermes-gateway
```

**Step 3:** Verify:
```bash
hermes status
```
You should see `mcp_mcp_brain_process_task` listed as an available tool.

### Usage

Once connected, just ask Hermes to think through something complex — it will automatically use the multi-agent pipeline when appropriate:

```
You: "Explain why volatility clustering occurs in financial markets"
Hermes → mcp-brain Creator/Critic/Analyst pipeline → detailed answer
```

No cloud hosting, no separate processes to manage. Hermes starts the server on demand.

## Privacy

- All API calls go directly from your machine to MiniMax
- No intermediary servers
- Session logs stored locally in `~/.mcp/logs/`
- Your API key stored in `~/.mcp/config.json` (keep this file private)
