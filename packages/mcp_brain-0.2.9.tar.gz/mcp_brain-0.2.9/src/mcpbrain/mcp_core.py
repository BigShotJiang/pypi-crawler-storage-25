"""MCP Core — orchestrates multi-agent cognitive processing."""

import os
import json
import time
import uuid
import threading
from pathlib import Path
from typing import Optional, Dict, Any, Iterator

from .minimax_client import MiniMaxClient, MiniMaxError
from .agents import CreatorAgent, CriticAgent, AnalystAgent
from .memory import WorkingMemory


DEFAULT_CONFIG_PATH = Path("~/.mcp/config.json").expanduser()
DEFAULT_LOG_DIR = Path("~/.mcp/logs").expanduser()
DEFAULT_MEMORY_DIR = Path("~/.mcp/memory").expanduser()
DEFAULT_RESULTS_DIR = Path("~/.mcp/results").expanduser()  # NEW: background results


class MCP:
    """Multi-agent Cognitive Processing engine."""

    # Class-level store for background results (session_id -> result dict)
    _results: Dict[str, Optional[Dict[str, Any]]] = {}
    _results_lock = threading.Lock()

    def __init__(self, config_path: Optional[str] = None, skip_api_key_check: bool = False):
        self.config_path = Path(config_path or DEFAULT_CONFIG_PATH)
        self.log_dir = Path(DEFAULT_LOG_DIR)
        self.memory_dir = Path(DEFAULT_MEMORY_DIR)
        self.results_dir = Path(DEFAULT_RESULTS_DIR)

        self.config = self._load_config()
        self.session_id = str(uuid.uuid4())[:8]
        self.llm = None
        self.agents = {}

        # Ensure directories exist
        for d in (self.log_dir, self.memory_dir, self.results_dir):
            d.mkdir(parents=True, exist_ok=True)

        # Initialize LLM
        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not api_key and not skip_api_key_check:
            raise ValueError("No API key configured. Run: mcp setup")

        if api_key:
            self.llm = MiniMaxClient(api_key)
            model = self.config.get("model", "MiniMax-M2.7")
            self.agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }

        self.memory = WorkingMemory(storage_path=str(self.memory_dir))

    def _load_config(self) -> Dict[str, Any]:
        """Load or create default config."""
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)

        # Create default config
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        default = {
            "api_key": "",
            "model": "MiniMax-M2.7",
            "max_tokens": 2000,
            "temperature": 0.7,
        }
        with open(self.config_path, "w") as f:
            json.dump(default, f, indent=2)
        return default

    def is_setup(self) -> bool:
        """Check if API key is configured."""
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "MiniMax-M2.7") -> bool:
        """Configure API key and model, reinitialize components."""
        self.config["api_key"] = api_key
        self.config["model"] = model
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=2)

        # Reinitialize with new key
        self.llm = MiniMaxClient(api_key)
        self.agents = {
            "creator": CreatorAgent(api_key, model=model),
            "critic": CriticAgent(api_key, model=model),
            "analyst": AnalystAgent(api_key, model=model),
        }
        return True

    @classmethod
    def get_result(cls, session_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a completed background result by session ID."""
        with cls._results_lock:
            return cls._results.get(session_id)

    # ── Cognitive pipeline (streaming) ───────────────────────────────────────────

    def process_task_stream(self, task: str) -> Iterator[Dict[str, Any]]:
        """Run the cognitive pipeline with streaming token output.

        Yields step events:
            {"type": "start", "step": 1, "agent": "analyst", "task": "..."}
            {"type": "token", "agent": "analyst", "content": "..."}
            {"type": "step_done", "step": 1, "agent": "analyst", "response": "..."}
            ... (continues for each step)
            {"type": "done", "session_id": "...", "duration_seconds": ...}
        """
        if not self.is_setup():
            yield {"type": "error", "message": "MCP not set up. Run: mcp setup"}
            return

        start_time = time.time()
        step_num = 0

        yield {
            "type": "start",
            "task": task,
            "session_id": self.session_id,
        }

        # Step 1 — Analyst breaks it down
        step_num = 1
        agent_name = "analyst"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, ""):
            if event["type"] == "start":
                pass  # already know agent name from step_start
            elif event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                analysis_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": analysis_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": analysis_response}

        # Step 2 — Creator generates a first draft
        step_num = 2
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                creation_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": creation_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

        # Step 3 — Critic evaluates
        step_num = 3
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                critique_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": critique_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": critique_response}

        # Step 4 — Creator improves based on critique
        step_num = 4
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        improve_task = f"Improve your previous solution based on this criticism: {critique_response}"
        for event in agent.process_stream(improve_task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                improvement_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": improvement_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": improvement_response}

        # Step 5 — Critic final evaluation
        step_num = 5
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        final_task = f"Provide a final evaluation of this improved solution. Rate it and note any remaining issues: {improvement_response}"
        for event in agent.process_stream(final_task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                final_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": final_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": final_response}

        duration = time.time() - start_time

        result = {
            "task": task,
            "session_id": self.session_id,
            "duration_seconds": round(duration, 2),
            "analysis": analysis_response,
            "solution": improvement_response,
            "evaluation": final_response,
        }

        # Store result for async retrieval
        with self.__class__._results_lock:
            self.__class__._results[self.session_id] = result

        # Save session log
        self._save_session_log(task, result)

        yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2)}

    def process_task(self, task: str, verbose: bool = True) -> Dict[str, Any]:
        """Run the full 5-step cognitive pipeline (blocking, for CLI)."""
        result = None
        for event in self.process_task_stream(task):
            if event["type"] == "step_done" and verbose:
                role = event["agent"].capitalize()
                preview = event["response"][:80].replace("\n", " ")
                print(f"  [✓] {role}: {preview}...")
            elif event["type"] == "start" and verbose:
                print(f"[MCP] Task: {task}")
            elif event["type"] == "done" and verbose:
                print(f"[MCP] Done in {event['duration_seconds']:.2f}s  session={event['session_id']}")
            elif event["type"] == "done":
                result = self.get_result(event["session_id"])

        return result or {}

    # ── Background processing ────────────────────────────────────────────────────

    def process_task_background(self, task: str) -> str:
        """Start processing in a background thread. Returns session_id immediately."""
        session_id = self.session_id
        # Store a placeholder so get_result() returns None until done
        with self.__class__._results_lock:
            self.__class__._results[session_id] = None

        def run():
            # Re-create agents in this thread (they hold API key references)
            api_key = self.config.get("api_key")
            model = self.config.get("model", "MiniMax-M2.7")
            agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }
            # Drain the stream to complete the pipeline
            for _ in self.process_task_stream(task):
                pass

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return session_id

    # ── Legacy helpers ──────────────────────────────────────────────────────────

    def _run_step(self, agent_name: str, task: str, context: str) -> Dict[str, Any]:
        """Run one agent step and store result in memory (blocking)."""
        agent = self.agents[agent_name]
        result = agent.process(task, context)
        self.memory.add(result)
        return result

    def _save_session_log(self, task: str, result: Dict[str, Any]) -> str:
        """Persist session to disk."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        path = self.log_dir / f"session_{ts}_{self.session_id}.json"
        with open(path, "w") as f:
            json.dump({
                "task": task,
                "session_id": self.session_id,
                "timestamp": ts,
                "result": result,
            }, f, indent=2)
        return str(path)
