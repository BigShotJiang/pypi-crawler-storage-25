"""MiniMax AI API client."""

import json
import os
import requests
from typing import Optional, List, Dict, Any


class MiniMaxError(Exception):
    """Raised when MiniMax API returns an error."""
    pass


class MiniMaxClient:
    """Client for MiniMax Chat API."""

    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://api.minimax.io/v1"):
        self.api_key = api_key or os.environ.get("MINIMAX_API_KEY")
        if not self.api_key:
            raise ValueError("MiniMax API key not found. Set MINIMAX_API_KEY env var or pass api_key.")
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        })

    def generate(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[list] = None,
    ) -> str:
        """Generate a response from MiniMax."""
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools

        resp = self._session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            timeout=120,
        )

        if resp.status_code != 200:
            raise MiniMaxError(f"API Error {resp.status_code}: {resp.text}")

        result = resp.json()
        return result["choices"][0]["message"]["content"]

    def generate_stream(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
    ):
        """Stream a response from MiniMax."""
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        resp = self._session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            stream=True,
            timeout=120,
        )

        if resp.status_code != 200:
            raise MiniMaxError(f"API Error {resp.status_code}: {resp.text}")

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        break
                    chunk = json.loads(data)
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    if "content" in delta:
                        yield delta["content"]

    # Known MiniMax chat models (fallback when /v1/models is unavailable)
    KNOWN_MODELS = [
        "MiniMax-M2.7",
        "MiniMax-M2",
        "MiniMax-M2.5",
    ]

    def list_models(self) -> List[Dict[str, Any]]:
        """List available models — tries /v1/models, falls back to known models."""
        try:
            resp = self._session.get(
                f"{self.base_url}/models",
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", [])
        except Exception:
            pass
        # Fallback: return known models as synthetic entries
        return [{"id": m, "object": "model"} for m in self.KNOWN_MODELS]

