# Ozekai GPU CLI

Three commands to connect, disconnect, and upload files to your GPU machine.

## Install

```bash
pip install ozekai
```

Requires Python 3.10+ and SSH access to your Ozekai GPU host.

## Commands

### `connect-gpu`

Connect to your GPU machine. Prompts for username and password, then drops you into a shell with full GPU access. JupyterLab auto-starts at `http://localhost:8888`.

```bash
$ connect-gpu
Username: alice
Password: ****
Session ready.
Jupyter: http://localhost:8888
Connecting...
```

### `disconnect-gpu`

Stop your GPU machine and end billing. Your `/workspace` files are preserved.

```bash
$ disconnect-gpu
Username: alice
Password: ****
Session stopped. Usage: 3842 seconds.
```

> **Important:** Typing `exit` in the shell disconnects your terminal but does **not** stop billing. Always run `disconnect-gpu` when you're done, or use the stop button on your [Dashboard](https://ozekai.com/dashboard.html).

### `upload-gpu`

Upload files from your local machine into your container's `/workspace`.

```bash
upload-gpu file.py                  # → /workspace/file.py
upload-gpu file.py models/          # → /workspace/models/file.py
upload-gpu *.py src/ experiments/   # → /workspace/experiments/{files}
```

## Configuration

Override defaults with environment variables:

| Variable | Default | Description |
|---|---|---|
| `OZEKAI_API_URL` | `https://ozekai.com` | Backend API URL |
| `OZEKAI_GPU_HOST` | `ozekai.com` | GPU host for SSH |
| `OZEKAI_SSH_USER` | `$USER` | SSH username |

## Links

- [Getting Started](https://ozekai.com/getting-started.html)
- [Help & Reference](https://ozekai.com/help.html)
- [Support](mailto:ozekai.support@gmail.com)
