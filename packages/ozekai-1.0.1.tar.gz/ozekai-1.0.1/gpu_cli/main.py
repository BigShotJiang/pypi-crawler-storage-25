import os
import click
from .commands.connect import connect_command
from .commands.disconnect import disconnect_command
from .commands.upload import upload_command

# ── User-facing standalone entry points ─────────────────────────

@click.command()
def connect_gpu():
    """Connect to your GPU container"""
    connect_command()

@click.command()
def disconnect_gpu():
    """Stop your GPU container"""
    disconnect_command()

@click.command()
@click.argument("args", nargs=-1, required=True)
def upload_gpu(args):
    """Upload files to your GPU container.

    \b
    Usage (scp-like):
      upload-gpu file.py                  → /workspace/file.py
      upload-gpu file.py models/          → /workspace/models/file.py
      upload-gpu *.py src/ models/        → /workspace/models/{files}
    """
    if len(args) >= 2 and not os.path.exists(args[-1]):
        sources, dest = args[:-1], args[-1]
    else:
        sources, dest = args, ""
    upload_command(sources, dest)
