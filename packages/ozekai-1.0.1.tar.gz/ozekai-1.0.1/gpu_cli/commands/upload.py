"""Client-side upload-gpu command.

Syntax (scp-like):
    upload-gpu file.py                      → /workspace/file.py
    upload-gpu file.py models/              → /workspace/models/file.py
    upload-gpu *.py src/ models/            → /workspace/models/{*.py, src/}
"""

import os
import subprocess
import click
import requests
from ..config import API_URL, GPU_HOST, SSH_USER


def upload_command(sources, dest):
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)

    if not sources:
        click.echo("Error: no files specified", err=True)
        raise SystemExit(1)

    for p in sources:
        if not os.path.exists(p):
            click.echo(f"Error: {p} not found", err=True)
            raise SystemExit(1)

    # ── Authenticate + get session ID ──
    click.echo(f"Authenticating as {username}...")
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/connect",
            json={"username": username, "password": password},
            timeout=30,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)

    if resp.status_code == 401:
        click.echo("Authentication failed: invalid username or password", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: upload authentication failed. Please try again.", err=True)
        raise SystemExit(1)

    sid = resp.json()["session_id"]

    # ── Upload each path ──
    target = f"/workspace/{dest}".rstrip("/")
    ssh_common = ["-o", "StrictHostKeyChecking=no", "-o", "LogLevel=FATAL"]
    ssh_dest = f"{SSH_USER}@{GPU_HOST}"

    # Ensure destination directory exists
    if dest:
        subprocess.run(
            ["ssh", *ssh_common, ssh_dest,
             f"docker exec {sid} mkdir -p {target}"],
            check=False,
        )

    for p in sources:
        name = os.path.basename(p.rstrip("/"))
        click.echo(f"Uploading {name}...")

        tar_cmd = ["tar", "cf", "-", "-C", os.path.dirname(os.path.abspath(p)), name]
        ssh_cmd = [
            "ssh", *ssh_common, ssh_dest,
            f"docker cp - {sid}:{target}",
        ]

        tar_proc = subprocess.Popen(tar_cmd, stdout=subprocess.PIPE)
        ssh_proc = subprocess.Popen(ssh_cmd, stdin=tar_proc.stdout)
        tar_proc.stdout.close()
        rc = ssh_proc.wait()
        tar_proc.wait()

        if rc != 0:
            click.echo(f"Error uploading {name} (exit {rc})", err=True)
            raise SystemExit(1)

        click.echo(f"  → {target}/{name}")

    click.echo("Done.")
