"""Client-side connect-gpu command."""

import os
import signal
import socket
import subprocess
import sys
import click
import requests
from ..config import API_URL, GPU_HOST, SSH_USER


def _find_free_port(start, count):
    """Return the first local port where `count` consecutive ports are all free."""
    port = start
    while port < 65536 - count:
        if all(_port_free(port + i) for i in range(count)):
            return port
        port += 1
    return start  # fallback


def _port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def connect_command():
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)

    # ── Step 1: Authenticate ──
    click.echo(f"Authenticating as {username}...")
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/connect",
            json={"username": username, "password": password},
            timeout=30,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)

    if resp.status_code == 401:
        click.echo("Authentication failed: invalid username/email or password", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not connect. Please try again later.", err=True)
        raise SystemExit(1)

    data = resp.json()
    container_id = data["session_id"]
    host_port = data["host_port"]
    plan_id = data.get("plan_id", "gpu")
    jupyter_port_count = data.get("port_count", 1)
    actual_username = data.get("username", username)

    click.echo("Session ready.")

    # ── Step 2: Open interactive session with port forwarding ──
    display_plan = (plan_id or "gpu").strip() or "gpu"
    prompt = f"{actual_username}@{display_plan}:\\w$ "

    local_base = _find_free_port(8888, jupyter_port_count)
    port_forward_args = []
    for i in range(jupyter_port_count):
        local_port = local_base + i
        remote_port = host_port + i
        port_forward_args.extend(["-L", f"{local_port}:localhost:{remote_port}"])

    click.echo(f"Jupyter: http://localhost:{local_base}")
    click.echo("Connecting... (type 'exit' to disconnect)")

    # Split into two SSH connections:
    # 1) Background master handles port forwarding only (-fNM)
    # 2) Foreground slave handles interactive session
    control_path = f"/tmp/gpu-ssh-{os.getpid()}"
    ssh_common = ["-o", "StrictHostKeyChecking=no", "-o", "LogLevel=FATAL"]
    ssh_dest = f"{SSH_USER}@{GPU_HOST}"

    subprocess.run(
        ["ssh", "-fNM", "-S", control_path, *port_forward_args,
         *ssh_common, ssh_dest],
        check=False,
    )

    def _cleanup_master(*_args):
        subprocess.run(
            ["ssh", "-S", control_path, "-O", "exit", ssh_dest],
            capture_output=True,
        )

    signal.signal(signal.SIGTERM, lambda *a: (_cleanup_master(), sys.exit(1)))

    # Build remote command as a single shell string so that the local
    # process list doesn't expose individual arguments.
    import shlex
    remote_cmd = (
        f"exec docker exec -it"
        f" -e GPU_PLAN_ID={shlex.quote(display_plan)}"
        f" -e PS1={shlex.quote(prompt)}"
        f" -w /workspace"
        f" {container_id}"
        f" /bin/bash --noprofile --norc -i"
    )

    try:
        ret = subprocess.call([
            "ssh", "-t",
            "-S", control_path,
            *ssh_common,
            ssh_dest,
            remote_cmd,
        ])
    except KeyboardInterrupt:
        ret = 130
    finally:
        _cleanup_master()

    raise SystemExit(ret)
