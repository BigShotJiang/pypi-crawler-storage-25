"""Client-side disconnect-gpu command."""

import click
import requests
from ..config import API_URL


def disconnect_command():
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)

    # Step 1: Login to get JWT
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/login",
            json={"username": username, "password": password},
            timeout=10,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)

    if resp.status_code == 401:
        click.echo("Authentication failed", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not disconnect. Please try again later.", err=True)
        raise SystemExit(1)

    token = resp.json()["access_token"]

    # Step 2: Stop session
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/me/stop-session",
            headers={"Authorization": f"Bearer {token}"},
            timeout=30,
        )
    except requests.ConnectionError:
        click.echo("Error: lost connection to API", err=True)
        raise SystemExit(1)

    if not resp.ok:
        click.echo("Error: could not stop session. Please try again later.", err=True)
        raise SystemExit(1)

    data = resp.json()
    if data.get("status") == "stopped":
        secs = data.get("total_seconds", 0)
        click.echo(f"Session stopped. Usage: {secs} seconds.")
    else:
        click.echo("No active session found.")
