import os

API_URL = os.getenv("OZEKAI_API_URL", "https://ozekai.com")
GPU_HOST = os.getenv("OZEKAI_GPU_HOST", "ozekai.com")
SSH_USER = os.getenv("OZEKAI_SSH_USER", os.getenv("USER", "gpu"))
