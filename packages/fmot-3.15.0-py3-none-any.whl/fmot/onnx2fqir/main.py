from __future__ import annotations

from pathlib import Path
import shutil
import tempfile
from typing import Literal

import numpy as np
import onnx
from onnxruntime.quantization import CalibrationDataReader
import tensorflow as tf
import tf2onnx

from fmot.onnx2fqir.converters import (
    convert_streaming_tdnn_to_fqir,
    convert_tdnn_tflite_to_onnx,
    quantize_to_QOperator,
)
from fmot.onnx2fqir.converters.custom_rewriters import (
    rewrite_bias_squeeze_conv2d_expand_with_fused_conv1d,
)


SourceFormat = Literal["auto", "keras", "tflite", "onnx"]
ConversionBackend = Literal[
    "auto", "keras_tf2onnx", "keras_via_tflite", "tflite_custom", "onnx_direct"
]


class SimpleCalibrationDataReader(CalibrationDataReader):
    def __init__(self, representative_data: list[np.ndarray], input_name: str):
        super().__init__()
        self.dataset = representative_data
        self.iterator = iter(self.dataset)
        self.input_name = input_name

    def get_next(self) -> dict[str, np.ndarray] | None:
        try:
            return {self.input_name: next(self.iterator)}
        except Exception:
            return None


def _infer_source_format(
    source, source_format: SourceFormat
) -> Literal["keras", "tflite", "onnx"]:
    if source_format != "auto":
        return source_format

    if isinstance(source, tf.keras.Model):
        return "keras"
    if isinstance(source, onnx.ModelProto):
        return "onnx"
    if isinstance(source, (bytes, bytearray)):
        return "tflite"
    if isinstance(source, (str, Path)):
        suffix = Path(source).suffix.lower()
        if suffix == ".tflite":
            return "tflite"
        if suffix == ".onnx":
            return "onnx"
        if suffix in {".keras", ".h5", ".hdf5"}:
            return "keras"

    raise ValueError(
        "Could not infer source format. Please pass source_format='keras', 'tflite', or 'onnx'."
    )


def _load_keras_model(source) -> tf.keras.Model:
    if isinstance(source, tf.keras.Model):
        return source
    if isinstance(source, (str, Path)):
        return tf.keras.models.load_model(source)
    raise TypeError(
        "Keras source must be a tf.keras.Model or a path to a serialized Keras model."
    )


def _load_onnx_model(source) -> onnx.ModelProto:
    if isinstance(source, onnx.ModelProto):
        return source
    if isinstance(source, (str, Path)):
        return onnx.load(str(source))
    raise TypeError(
        "ONNX source must be an onnx.ModelProto or a path to a .onnx model."
    )


def _export_keras_to_tflite_bytes(model: tf.keras.Model) -> bytes:
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    return converter.convert()


def _infer_conversion_backend(
    resolved_format: Literal["keras", "tflite", "onnx"],
    conversion_backend: ConversionBackend,
) -> Literal["keras_tf2onnx", "keras_via_tflite", "tflite_custom", "onnx_direct"]:
    if conversion_backend != "auto":
        return conversion_backend

    if resolved_format == "keras":
        return "keras_via_tflite"
    if resolved_format == "onnx":
        return "onnx_direct"
    return "tflite_custom"


def _resolve_intermediate_graph_dir(save_intermediate_graphs) -> Path | None:
    if not save_intermediate_graphs:
        return None

    if save_intermediate_graphs is True:
        out_dir = Path.cwd() / "intermediate_graphs"
    else:
        out_dir = Path(save_intermediate_graphs)

    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def _save_materialized_source_graph(
    source,
    *,
    resolved_format: Literal["keras", "tflite", "onnx"],
    out_dir: Path | None,
    materialized_tflite: bytes | None = None,
) -> None:
    if out_dir is None:
        return

    if resolved_format == "tflite":
        tflite_path = out_dir / "source_model.tflite"
        if isinstance(source, (bytes, bytearray)):
            tflite_path.write_bytes(bytes(source))
        elif isinstance(source, (str, Path)):
            shutil.copyfile(str(source), tflite_path)
    elif resolved_format == "onnx":
        onnx_path = out_dir / "source_model.onnx"
        if isinstance(source, onnx.ModelProto):
            onnx.save(source, onnx_path)
        elif isinstance(source, (str, Path)):
            shutil.copyfile(str(source), onnx_path)
    elif materialized_tflite is not None:
        (out_dir / "source_model.tflite").write_bytes(materialized_tflite)


def _save_onnx_graph(
    model: onnx.ModelProto, out_dir: Path | None, filename: str
) -> None:
    if out_dir is None:
        return
    onnx.save(model, out_dir / filename)


def convert_tdnn_to_onnx(
    source,
    *,
    source_format: SourceFormat = "auto",
    opset: int = 18,
    conversion_backend: ConversionBackend = "auto",
) -> onnx.ModelProto:
    resolved_format = _infer_source_format(source, source_format)
    resolved_backend = _infer_conversion_backend(resolved_format, conversion_backend)

    if resolved_backend == "keras_tf2onnx":
        keras_model = _load_keras_model(source)
        input_signature = [
            tf.TensorSpec(
                keras_model.inputs[0].shape,
                keras_model.inputs[0].dtype,
                name=keras_model.inputs[0].name.split(":")[0],
            )
        ]
        onnx_model, _ = tf2onnx.convert.from_keras(
            keras_model,
            input_signature=input_signature,
            opset=opset,
            custom_rewriter=[rewrite_bias_squeeze_conv2d_expand_with_fused_conv1d],
        )
        return onnx_model

    if resolved_backend == "keras_via_tflite":
        keras_model = _load_keras_model(source)
        tflite_model = _export_keras_to_tflite_bytes(keras_model)
        return convert_tdnn_tflite_to_onnx(
            model_content=tflite_model, opset_version=opset
        )

    if resolved_backend == "onnx_direct":
        return _load_onnx_model(source)

    if resolved_backend == "tflite_custom":
        if isinstance(source, (bytes, bytearray)):
            return convert_tdnn_tflite_to_onnx(
                model_content=bytes(source), opset_version=opset
            )
        if isinstance(source, (str, Path)):
            return convert_tdnn_tflite_to_onnx(
                model_path=str(source), opset_version=opset
            )

    raise TypeError(
        "Unsupported source/backend combination. "
        "TFLite backends require bytes/bytearray or a path to a .tflite model."
    )


def quantize_tdnn_onnx(
    onnx_model: onnx.ModelProto,
    *,
    representative_data: list[np.ndarray],
) -> onnx.ModelProto:
    input_name = onnx_model.graph.input[0].name
    calib_data_reader = SimpleCalibrationDataReader(representative_data, input_name)

    with tempfile.NamedTemporaryFile(suffix=".onnx") as f:
        onnx.save(onnx_model, f.name)
        quantize_to_QOperator(
            model_input=f.name,
            model_output=f.name,
            calibration_data_reader=calib_data_reader,
        )
        quant_onnx_model = onnx.load(f.name)

    return quant_onnx_model


def convert_tdnn_to_cstate(
    source,
    representative_data: list[np.ndarray],
    *,
    source_format: SourceFormat = "auto",
    batch_dim: int = 0,
    seq_dim: int = 1,
    feature_dim: int = 2,
    options: list[str] | None = None,
    save_intermediate_graphs: bool | str | Path = False,
    conversion_backend: ConversionBackend = "auto",
):
    if options is None:
        options = ["conv1d_via_unfold"]

    resolved_format = _infer_source_format(source, source_format)
    resolved_backend = _infer_conversion_backend(resolved_format, conversion_backend)
    out_dir = _resolve_intermediate_graph_dir(save_intermediate_graphs)
    materialized_tflite = None
    if resolved_backend == "keras_via_tflite":
        materialized_tflite = _export_keras_to_tflite_bytes(_load_keras_model(source))
    _save_materialized_source_graph(
        source,
        resolved_format=resolved_format,
        out_dir=out_dir,
        materialized_tflite=materialized_tflite,
    )

    if resolved_backend == "keras_via_tflite":
        onnx_model = convert_tdnn_tflite_to_onnx(
            model_content=materialized_tflite, opset_version=18
        )
    else:
        onnx_model = convert_tdnn_to_onnx(
            source,
            source_format=resolved_format,
            conversion_backend=resolved_backend,
        )
    _save_onnx_graph(onnx_model, out_dir, "model.onnx")
    quant_onnx_model = quantize_tdnn_onnx(
        onnx_model, representative_data=representative_data
    )
    _save_onnx_graph(quant_onnx_model, out_dir, "model_qoperator.onnx")
    return convert_streaming_tdnn_to_fqir(
        quant_onnx_model,
        batch_dim=batch_dim,
        seq_dim=seq_dim,
        feature_dim=feature_dim,
        options=options,
    )


def convert_tdnn_to_fqir(
    source,
    representative_data: list[np.ndarray],
    *,
    source_format: SourceFormat = "auto",
    batch_dim: int = 0,
    seq_dim: int = 1,
    feature_dim: int = 2,
    options: list[str] | None = None,
    save_intermediate_graphs: bool | str | Path = False,
    conversion_backend: ConversionBackend = "auto",
):
    cstate = convert_tdnn_to_cstate(
        source,
        representative_data,
        source_format=source_format,
        batch_dim=batch_dim,
        seq_dim=seq_dim,
        feature_dim=feature_dim,
        options=options,
        save_intermediate_graphs=save_intermediate_graphs,
        conversion_backend=conversion_backend,
    )
    return cstate.fqir


def convert_keras_tdnn_to_fqir(
    model_path: str,
    representative_data: list[np.ndarray],
    *,
    save_intermediate_graphs: bool | str | Path = False,
    conversion_backend: ConversionBackend = "auto",
):
    return convert_tdnn_to_fqir(
        model_path,
        representative_data,
        source_format="keras",
        save_intermediate_graphs=save_intermediate_graphs,
        conversion_backend=conversion_backend,
    )


def convert_tflite_tdnn_to_fqir(
    model,
    representative_data: list[np.ndarray],
    *,
    save_intermediate_graphs: bool | str | Path = False,
    conversion_backend: ConversionBackend = "auto",
):
    return convert_tdnn_to_fqir(
        model,
        representative_data,
        source_format="tflite",
        save_intermediate_graphs=save_intermediate_graphs,
        conversion_backend=conversion_backend,
    )


def convert_onnx_tdnn_to_fqir(
    model,
    representative_data: list[np.ndarray],
    *,
    save_intermediate_graphs: bool | str | Path = False,
):
    return convert_tdnn_to_fqir(
        model,
        representative_data,
        source_format="onnx",
        save_intermediate_graphs=save_intermediate_graphs,
        conversion_backend="onnx_direct",
    )
