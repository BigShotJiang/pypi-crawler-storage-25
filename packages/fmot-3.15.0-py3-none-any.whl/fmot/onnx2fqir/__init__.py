def _get_dir():
    import pathlib

    return pathlib.Path(__file__).parent.resolve()


# __version__ = (_get_dir() / "VERSION").read_text(encoding="utf-8").strip()

from .parsing import ParsedTensor, ParsedOperator, ParsedGraph, parse_onnx_graph
from .converters import convert_streaming_tdnn_to_fqir, convert_tdnn_tflite_to_onnx
from .add_debug_outputs import add_intermediate_outputs_to_model
from .tflite_digraph import (
    DiGraphPatternMatch,
    add_pattern_node,
    build_path_pattern,
    find_subgraph_pattern_matches,
    load_tflite_digraph,
    op_name_is,
)

from .main import (
    convert_keras_tdnn_to_fqir,
    convert_onnx_tdnn_to_fqir,
    convert_tflite_tdnn_to_fqir,
    convert_tdnn_to_cstate,
    convert_tdnn_to_fqir,
    convert_tdnn_to_onnx,
    quantize_tdnn_onnx,
)
