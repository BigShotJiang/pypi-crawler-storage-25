from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import networkx as nx
import tensorflow as tf

from .tflite_digraph import (
    add_pattern_node,
    find_subgraph_pattern_matches,
    load_tflite_digraph,
)


DILATED_CONV1D_TFLITE_PATTERN = "dilated_conv1d"


@dataclass
class DilatedConv1dTFLitePatternMatch:
    match_start_op_index: int
    match_end_op_index: int
    ops: list[dict[str, Any]]
    space_to_batch: dict[str, Any]
    singleton_lift: dict[str, Any]
    conv2d: dict[str, Any]
    bias_add: dict[str, Any] | None
    reshape: dict[str, Any]
    batch_to_space: dict[str, Any]
    derived: dict[str, Any]


def _tensor_detail_map(interpreter: tf.lite.Interpreter) -> dict[int, dict[str, Any]]:
    return {int(detail["index"]): detail for detail in interpreter.get_tensor_details()}


def _jsonify(value: Any) -> Any:
    try:
        import numpy as np
    except ImportError:  # pragma: no cover
        np = None

    if np is not None:
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
    if isinstance(value, (list, tuple)):
        return [_jsonify(v) for v in value]
    if isinstance(value, dict):
        return {k: _jsonify(v) for k, v in value.items()}
    return value


def _const_tensor_value(
    interpreter: tf.lite.Interpreter, tensor_index: int
) -> Any | None:
    try:
        return _jsonify(interpreter.get_tensor(tensor_index))
    except ValueError:
        return None


def _build_dilated_conv1d_patterns() -> list[nx.DiGraph]:
    patterns = []

    without_bias_add = nx.DiGraph()
    add_pattern_node(without_bias_add, "space_to_batch", op_name="SPACE_TO_BATCH_ND")
    add_pattern_node(
        without_bias_add,
        "singleton_lift",
        verifier=lambda node: node["op_name"] in {"EXPAND_DIMS", "RESHAPE"},
    )
    add_pattern_node(without_bias_add, "conv2d", op_name="CONV_2D")
    add_pattern_node(without_bias_add, "reshape", op_name="RESHAPE")
    add_pattern_node(without_bias_add, "batch_to_space", op_name="BATCH_TO_SPACE_ND")
    without_bias_add.add_edges_from(
        [
            ("space_to_batch", "singleton_lift"),
            ("singleton_lift", "conv2d"),
            ("conv2d", "reshape"),
            ("reshape", "batch_to_space"),
        ]
    )
    patterns.append(without_bias_add)

    with_bias_add = nx.DiGraph()
    add_pattern_node(with_bias_add, "space_to_batch", op_name="SPACE_TO_BATCH_ND")
    add_pattern_node(
        with_bias_add,
        "singleton_lift",
        verifier=lambda node: node["op_name"] in {"EXPAND_DIMS", "RESHAPE"},
    )
    add_pattern_node(with_bias_add, "conv2d", op_name="CONV_2D")
    add_pattern_node(with_bias_add, "bias_add", op_name="ADD")
    add_pattern_node(with_bias_add, "reshape", op_name="RESHAPE")
    add_pattern_node(with_bias_add, "batch_to_space", op_name="BATCH_TO_SPACE_ND")
    with_bias_add.add_edges_from(
        [
            ("space_to_batch", "singleton_lift"),
            ("singleton_lift", "conv2d"),
            ("conv2d", "bias_add"),
            ("bias_add", "reshape"),
            ("reshape", "batch_to_space"),
        ]
    )
    patterns.append(with_bias_add)

    return patterns


def _serialize_op(
    interpreter: tf.lite.Interpreter,
    tensor_map: dict[int, dict[str, Any]],
    op: dict[str, Any],
    op_index: int,
) -> dict[str, Any]:
    inputs = []
    outputs = []

    for tensor_index_raw in op["inputs"]:
        tensor_index = int(tensor_index_raw)
        tensor = tensor_map[tensor_index]
        tensor_record = {
            "tensor_index": tensor_index,
            "name": tensor["name"],
            "shape": _jsonify(tensor["shape"]),
            "dtype": str(tensor["dtype"]),
        }
        value = _const_tensor_value(interpreter, tensor_index)
        if value is not None:
            tensor_record["value"] = value
        inputs.append(tensor_record)

    for tensor_index_raw in op["outputs"]:
        tensor_index = int(tensor_index_raw)
        tensor = tensor_map[tensor_index]
        outputs.append(
            {
                "tensor_index": tensor_index,
                "name": tensor["name"],
                "shape": _jsonify(tensor["shape"]),
                "dtype": str(tensor["dtype"]),
            }
        )

    return {
        "op_index": op_index,
        "op_name": op["op_name"],
        "inputs": inputs,
        "outputs": outputs,
    }


def _first_non_singleton(values: Any) -> int | None:
    if not isinstance(values, list):
        return None
    for value in values:
        if int(value) != 1:
            return int(value)
    return None


def _extract_time_axis_padding(paddings_value: Any) -> list[int] | None:
    if not isinstance(paddings_value, list):
        return None

    candidate_rows = []
    for row in paddings_value:
        if isinstance(row, list) and len(row) == 2:
            candidate_rows.append([int(row[0]), int(row[1])])

    if len(candidate_rows) == 1:
        return candidate_rows[0]

    if len(candidate_rows) != 2:
        return None

    non_zero_rows = [row for row in candidate_rows if row != [0, 0]]
    if len(non_zero_rows) == 1:
        return non_zero_rows[0]

    if len(non_zero_rows) == 0:
        return candidate_rows[-1]

    return None


def _build_dilated_conv1d_match(
    *,
    interpreter: tf.lite.Interpreter,
    tensor_map: dict[int, dict[str, Any]],
    ops: list[dict[str, Any]],
    graph_match: dict[str, int],
) -> DilatedConv1dTFLitePatternMatch:
    stob_index = int(graph_match["space_to_batch"])
    lift_index = int(graph_match["singleton_lift"])
    conv_index = int(graph_match["conv2d"])
    reshape_index = int(graph_match["reshape"])
    btos_index = int(graph_match["batch_to_space"])
    bias_add_index = (
        None if "bias_add" not in graph_match else int(graph_match["bias_add"])
    )

    stob_op = ops[stob_index]
    lift_op = ops[lift_index]
    conv_op = ops[conv_index]
    reshape_op = ops[reshape_index]
    btos_op = ops[btos_index]
    bias_add_op = None if bias_add_index is None else ops[bias_add_index]

    stob_block_shape_idx = int(stob_op["inputs"][1])
    stob_paddings_idx = int(stob_op["inputs"][2])
    conv_filter_idx = int(conv_op["inputs"][1])
    conv_bias_idx = int(conv_op["inputs"][2]) if len(conv_op["inputs"]) > 2 else None
    reshape_shape_idx = int(reshape_op["inputs"][1])
    btos_block_shape_idx = int(btos_op["inputs"][1])
    btos_crops_idx = int(btos_op["inputs"][2])

    stob_block_shape = _const_tensor_value(interpreter, stob_block_shape_idx)
    stob_paddings = _const_tensor_value(interpreter, stob_paddings_idx)
    btos_block_shape = _const_tensor_value(interpreter, btos_block_shape_idx)
    btos_crops = _const_tensor_value(interpreter, btos_crops_idx)
    conv_filter = tensor_map[conv_filter_idx]
    conv_filter_shape = _jsonify(conv_filter["shape"])

    inferred_dilation = _first_non_singleton(stob_block_shape)
    inferred_time_padding = _extract_time_axis_padding(stob_paddings)
    inferred_time_cropping = _extract_time_axis_padding(btos_crops)

    op_indices = [stob_index, lift_index, conv_index]
    if bias_add_index is not None:
        op_indices.append(bias_add_index)
    op_indices.extend([reshape_index, btos_index])
    op_indices = sorted(op_indices)

    return DilatedConv1dTFLitePatternMatch(
        match_start_op_index=min(op_indices),
        match_end_op_index=max(op_indices),
        ops=[
            _serialize_op(interpreter, tensor_map, ops[op_index], op_index)
            for op_index in op_indices
        ],
        space_to_batch={
            "data_tensor": tensor_map[int(stob_op["inputs"][0])]["name"],
            "block_shape_tensor": tensor_map[stob_block_shape_idx]["name"],
            "block_shape_value": stob_block_shape,
            "paddings_tensor": tensor_map[stob_paddings_idx]["name"],
            "paddings_value": stob_paddings,
            "output_tensor": tensor_map[int(stob_op["outputs"][0])]["name"],
            "output_shape": _jsonify(tensor_map[int(stob_op["outputs"][0])]["shape"]),
        },
        singleton_lift={
            "op_name": lift_op["op_name"],
            "shape_or_axis_tensor": tensor_map[int(lift_op["inputs"][1])]["name"],
            "shape_or_axis_value": _const_tensor_value(
                interpreter, int(lift_op["inputs"][1])
            ),
            "output_tensor": tensor_map[int(lift_op["outputs"][0])]["name"],
            "output_shape": _jsonify(tensor_map[int(lift_op["outputs"][0])]["shape"]),
        },
        conv2d={
            "input_tensor": tensor_map[int(conv_op["inputs"][0])]["name"],
            "filter_tensor": conv_filter["name"],
            "filter_shape": conv_filter_shape,
            "bias_tensor": None
            if conv_bias_idx is None
            else tensor_map[conv_bias_idx]["name"],
            "bias_shape": None
            if conv_bias_idx is None
            else _jsonify(tensor_map[conv_bias_idx]["shape"]),
            "output_tensor": tensor_map[int(conv_op["outputs"][0])]["name"],
            "output_shape": _jsonify(tensor_map[int(conv_op["outputs"][0])]["shape"]),
        },
        bias_add=None
        if bias_add_op is None
        else {
            "input_tensor": tensor_map[int(bias_add_op["inputs"][0])]["name"],
            "bias_tensor": tensor_map[int(bias_add_op["inputs"][1])]["name"],
            "bias_shape": _jsonify(tensor_map[int(bias_add_op["inputs"][1])]["shape"]),
            "output_tensor": tensor_map[int(bias_add_op["outputs"][0])]["name"],
            "output_shape": _jsonify(
                tensor_map[int(bias_add_op["outputs"][0])]["shape"]
            ),
        },
        reshape={
            "shape_tensor": tensor_map[reshape_shape_idx]["name"],
            "shape_value": _const_tensor_value(interpreter, reshape_shape_idx),
            "output_tensor": tensor_map[int(reshape_op["outputs"][0])]["name"],
            "output_shape": _jsonify(
                tensor_map[int(reshape_op["outputs"][0])]["shape"]
            ),
        },
        batch_to_space={
            "data_tensor": tensor_map[int(btos_op["inputs"][0])]["name"],
            "block_shape_tensor": tensor_map[btos_block_shape_idx]["name"],
            "block_shape_value": btos_block_shape,
            "crops_tensor": tensor_map[btos_crops_idx]["name"],
            "crops_value": btos_crops,
            "output_tensor": tensor_map[int(btos_op["outputs"][0])]["name"],
            "output_shape": _jsonify(tensor_map[int(btos_op["outputs"][0])]["shape"]),
        },
        derived={
            "inferred_dilation": inferred_dilation,
            "inferred_dilation_rate": inferred_dilation,
            "inferred_time_axis_padding": inferred_time_padding,
            "inferred_time_axis_padding_total": None
            if inferred_time_padding is None
            else sum(inferred_time_padding),
            "inferred_time_axis_cropping": inferred_time_cropping,
        },
    )


def _analyze_dilated_conv1d_pattern(
    *,
    interpreter: tf.lite.Interpreter,
    tensor_map: dict[int, dict[str, Any]],
    ops: list[dict[str, Any]],
    graph: nx.DiGraph,
) -> list[dict[str, Any]]:
    matches_by_signature = {}
    for pattern in _build_dilated_conv1d_patterns():
        for match in find_subgraph_pattern_matches(graph, pattern):
            pattern_to_graph = {
                str(pattern_node): int(graph_node)
                for pattern_node, graph_node in match.pattern_node_to_graph_node.items()
            }
            signature = tuple(sorted(pattern_to_graph.values()))
            built_match = _build_dilated_conv1d_match(
                interpreter=interpreter,
                tensor_map=tensor_map,
                ops=ops,
                graph_match=pattern_to_graph,
            )
            matches_by_signature.setdefault(signature, asdict(built_match))

    return [
        matches_by_signature[signature]
        for signature in sorted(matches_by_signature, key=lambda values: tuple(values))
    ]


def analyze_tflite_patterns(
    *,
    model_path: str | None = None,
    model_content: bytes | None = None,
    built_in_patterns: Iterable[str] = (DILATED_CONV1D_TFLITE_PATTERN,),
) -> dict[str, Any]:
    if (model_path is None) == (model_content is None):
        raise ValueError("Provide exactly one of model_path or model_content")

    interpreter = tf.lite.Interpreter(
        model_path=model_path,
        model_content=model_content,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()

    tensor_map = _tensor_detail_map(interpreter)
    ops = interpreter._get_ops_details()
    graph = load_tflite_digraph(model_path=model_path, model_content=model_content)

    matches_by_pattern = {}
    for pattern_name in built_in_patterns:
        if pattern_name == DILATED_CONV1D_TFLITE_PATTERN:
            matches_by_pattern[pattern_name] = _analyze_dilated_conv1d_pattern(
                interpreter=interpreter,
                tensor_map=tensor_map,
                ops=ops,
                graph=graph,
            )
            continue
        raise ValueError(f"Unknown built-in TFLite pattern: {pattern_name}")

    return {
        "all_op_names": [op["op_name"] for op in ops],
        "matches_by_pattern": matches_by_pattern,
    }


def analyze_dilated_conv1d_tflite_patterns(
    *,
    model_path: str | None = None,
    model_content: bytes | None = None,
) -> dict[str, Any]:
    result = analyze_tflite_patterns(
        model_path=model_path,
        model_content=model_content,
        built_in_patterns=(DILATED_CONV1D_TFLITE_PATTERN,),
    )
    return {
        "all_op_names": result["all_op_names"],
        "pattern_matches": result["matches_by_pattern"][DILATED_CONV1D_TFLITE_PATTERN],
    }
