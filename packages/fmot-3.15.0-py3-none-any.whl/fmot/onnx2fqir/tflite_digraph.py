from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Hashable, Iterable

import networkx as nx
import numpy as np
import tensorflow as tf


NodeVerifier = Callable[[dict[str, Any]], bool]
EdgeVerifier = Callable[[dict[str, Any]], bool]

_PATTERN_RESERVED_NODE_KEYS = {"verifier", "description", "label"}
_PATTERN_RESERVED_EDGE_KEYS = {"verifier", "description", "label"}


@dataclass(frozen=True)
class DiGraphPatternMatch:
    pattern_node_to_graph_node: dict[Hashable, Hashable]
    graph_node_to_pattern_node: dict[Hashable, Hashable]


def _jsonify(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (list, tuple)):
        return [_jsonify(v) for v in value]
    if isinstance(value, dict):
        return {k: _jsonify(v) for k, v in value.items()}
    return value


def _const_tensor_value(
    interpreter: tf.lite.Interpreter, tensor_index: int
) -> Any | None:
    try:
        return _jsonify(interpreter.get_tensor(tensor_index))
    except ValueError:
        return None


def _tensor_detail_map(interpreter: tf.lite.Interpreter) -> dict[int, dict[str, Any]]:
    return {int(detail["index"]): detail for detail in interpreter.get_tensor_details()}


def load_tflite_digraph(
    *,
    model_path: str | None = None,
    model_content: bytes | None = None,
    max_const_elements: int = 16,
) -> nx.DiGraph:
    if (model_path is None) == (model_content is None):
        raise ValueError("Provide exactly one of model_path or model_content")

    interpreter = tf.lite.Interpreter(
        model_path=model_path,
        model_content=model_content,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()

    tensor_map = _tensor_detail_map(interpreter)
    ops = interpreter._get_ops_details()
    graph = nx.DiGraph()

    tensor_producers: dict[int, int] = {}
    tensor_consumers: dict[int, list[int]] = {}

    for op_index, op in enumerate(ops):
        inputs = []
        outputs = []

        for tensor_index_raw in op["inputs"]:
            tensor_index = int(tensor_index_raw)
            if tensor_index < 0:
                continue
            detail = tensor_map[tensor_index]
            tensor_record = {
                "tensor_index": tensor_index,
                "name": detail["name"],
                "shape": _jsonify(detail["shape"]),
                "dtype": str(detail["dtype"]),
            }

            value = _const_tensor_value(interpreter, tensor_index)
            if value is not None and np.asarray(value).size <= max_const_elements:
                tensor_record["value"] = value

            inputs.append(tensor_record)
            tensor_consumers.setdefault(tensor_index, []).append(op_index)

        for tensor_index_raw in op["outputs"]:
            tensor_index = int(tensor_index_raw)
            if tensor_index < 0:
                continue
            detail = tensor_map[tensor_index]
            tensor_record = {
                "tensor_index": tensor_index,
                "name": detail["name"],
                "shape": _jsonify(detail["shape"]),
                "dtype": str(detail["dtype"]),
            }
            outputs.append(tensor_record)
            tensor_producers[tensor_index] = op_index

        graph.add_node(
            op_index,
            op_index=op_index,
            op_name=op["op_name"],
            label=f"{op_index}: {op['op_name']}",
            inputs=inputs,
            outputs=outputs,
            op_details={
                "op_name": op["op_name"],
                "inputs": [int(t) for t in op["inputs"]],
                "outputs": [int(t) for t in op["outputs"]],
            },
        )

    for tensor_index, producer_op_index in tensor_producers.items():
        detail = tensor_map[tensor_index]
        for consumer_op_index in tensor_consumers.get(tensor_index, []):
            if producer_op_index == consumer_op_index:
                continue

            if graph.has_edge(producer_op_index, consumer_op_index):
                edge_data = graph[producer_op_index][consumer_op_index]
                edge_data["tensor_indices"].append(tensor_index)
                edge_data["tensor_names"].append(detail["name"])
                edge_data["tensor_shapes"].append(_jsonify(detail["shape"]))
                edge_data["labels"].append(f"t{tensor_index}: {detail['name']}")
            else:
                graph.add_edge(
                    producer_op_index,
                    consumer_op_index,
                    tensor_indices=[tensor_index],
                    tensor_names=[detail["name"]],
                    tensor_shapes=[_jsonify(detail["shape"])],
                    labels=[f"t{tensor_index}: {detail['name']}"],
                )

    graph.graph["all_op_names"] = [op["op_name"] for op in ops]
    graph.graph["model_path"] = model_path
    graph.graph["num_tensors"] = len(tensor_map)
    return graph


def op_name_is(expected_op_name: str) -> NodeVerifier:
    return lambda node_data: node_data.get("op_name") == expected_op_name


def add_pattern_node(
    pattern: nx.DiGraph,
    node_id: Hashable,
    *,
    op_name: str | None = None,
    verifier: NodeVerifier | None = None,
    description: str | None = None,
    **attrs: Any,
) -> None:
    pattern.add_node(
        node_id,
        op_name=op_name,
        verifier=verifier,
        description=description,
        **attrs,
    )


def build_path_pattern(
    op_names: Iterable[str], *, node_ids: Iterable[Hashable] | None = None
) -> nx.DiGraph:
    op_names = list(op_names)
    pattern = nx.DiGraph()
    pattern_node_ids = (
        list(range(len(op_names))) if node_ids is None else list(node_ids)
    )
    if len(pattern_node_ids) != len(op_names):
        raise ValueError("node_ids must have the same length as op_names")

    for node_id, op_name in zip(pattern_node_ids, op_names):
        add_pattern_node(pattern, node_id, op_name=op_name)

    for src, dst in zip(pattern_node_ids, pattern_node_ids[1:]):
        pattern.add_edge(src, dst)

    return pattern


def _pattern_node_matches(
    graph_node_attrs: dict[str, Any], pattern_node_attrs: dict[str, Any]
) -> bool:
    expected_op_name = pattern_node_attrs.get("op_name")
    if (
        expected_op_name is not None
        and graph_node_attrs.get("op_name") != expected_op_name
    ):
        return False

    verifier = pattern_node_attrs.get("verifier")
    if verifier is not None and not verifier(graph_node_attrs):
        return False

    for key, expected_value in pattern_node_attrs.items():
        if key in _PATTERN_RESERVED_NODE_KEYS or key == "op_name":
            continue
        if graph_node_attrs.get(key) != expected_value:
            return False

    return True


def _pattern_edge_matches(
    graph_edge_attrs: dict[str, Any], pattern_edge_attrs: dict[str, Any]
) -> bool:
    verifier = pattern_edge_attrs.get("verifier")
    if verifier is not None and not verifier(graph_edge_attrs):
        return False

    for key, expected_value in pattern_edge_attrs.items():
        if key in _PATTERN_RESERVED_EDGE_KEYS:
            continue
        if graph_edge_attrs.get(key) != expected_value:
            return False

    return True


def find_subgraph_pattern_matches(
    graph: nx.DiGraph, pattern: nx.DiGraph
) -> list[DiGraphPatternMatch]:
    matcher = nx.algorithms.isomorphism.DiGraphMatcher(
        graph,
        pattern,
        node_match=_pattern_node_matches,
        edge_match=_pattern_edge_matches,
    )

    matches = []
    for graph_to_pattern in matcher.subgraph_isomorphisms_iter():
        pattern_to_graph = {
            pattern_node: graph_node
            for graph_node, pattern_node in graph_to_pattern.items()
        }
        matches.append(
            DiGraphPatternMatch(
                pattern_node_to_graph_node=pattern_to_graph,
                graph_node_to_pattern_node=dict(graph_to_pattern),
            )
        )

    matches.sort(
        key=lambda match: tuple(
            match.pattern_node_to_graph_node[node_id] for node_id in pattern.nodes
        )
    )
    return matches
