import numpy as np
import pytest

from fmot.fqir.writer import FQIRWriter, new_fqir_graph


def _reference_softmax(x: np.ndarray) -> np.ndarray:
    x = x - np.max(x, axis=-1, keepdims=True)
    exp_x = np.exp(x)
    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)


@pytest.mark.parametrize("n_chan", [2, 8])
@pytest.mark.parametrize("quanta", range(-20, 21))
def test_softmax_i16_quanta_sweep(quanta: int, n_chan: int):
    rng = np.random.default_rng(0)

    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)

    x = writer.add_input(n_chan, quanta=quanta, precision="int16")
    y = writer.softmax(x)
    writer.add_outputs([y])

    # Build inputs from a small real-valued logit range, then quantize them into
    # the requested input quanta. This keeps the represented logits in a numerically
    # useful regime across the full quanta sweep.
    logits = rng.uniform(-0.125, 0.125, size=(64, n_chan))
    x_int = np.rint(logits / (2**quanta)).astype(np.int64)
    x_int = np.clip(x_int, -(2**15), 2**15 - 1).astype(np.int32)
    y_fqir = graph.run(x_int) * 2**y.quanta

    x_float = x_int * 2**quanta
    y_ref = _reference_softmax(x_float)

    max_err = np.max(np.abs(y_fqir - y_ref))
    sum_err = np.max(np.abs(np.sum(y_fqir, axis=-1) - 1.0))

    assert max_err < 1e-1
    assert sum_err < 5e-3
