import numpy as np
import pytest
import torch

from fmot.fqir.writer import FQIRWriter, new_fqir_graph
from fmot.nn.functional import temporal_conv2d


def _n_band_out(n_band_in, kernel_band, dilation_band, stride_band, padding_band):
    n_band_out = n_band_in + 2 * padding_band - dilation_band * (kernel_band - 1) - 1
    return int(np.floor(n_band_out / stride_band + 1))


@pytest.mark.parametrize(
    "d_band_in,n_band_in,d_band_out,kernel_band,dilation_band,stride_band,padding_band",
    [
        (3, 4, 2, 3, 1, 2, 1),
        (5, 6, 4, 2, 2, 1, 1),
    ],
)
def test_writer_temporal_conv2d_output_shape(
    d_band_in,
    n_band_in,
    d_band_out,
    kernel_band,
    dilation_band,
    stride_band,
    padding_band,
):
    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)

    x = writer.add_input(d_band_in * n_band_in, quanta=0, precision="int16")
    weight = writer.add_parameter(
        np.zeros((d_band_out, d_band_in, kernel_band, 1), dtype=np.int32),
        quanta=0,
        precision="int16",
    )

    y = writer.temporal_conv2d(
        weight=weight,
        x=x,
        quanta=0,
        kernel_size_t=1,
        kernel_size_band=kernel_band,
        n_band_in=n_band_in,
        dilation_t=1,
        dilation_band=dilation_band,
        stride_band=stride_band,
        padding_band=padding_band,
        groups=1,
        bias=None,
    )

    assert y.shape == [
        d_band_out
        * _n_band_out(
            n_band_in=n_band_in,
            kernel_band=kernel_band,
            dilation_band=dilation_band,
            stride_band=stride_band,
            padding_band=padding_band,
        )
    ]


@pytest.mark.parametrize(
    "cfg",
    [
        dict(
            d_band_in=3,
            n_band_in=4,
            d_band_out=2,
            kernel_t=1,
            kernel_band=3,
            dilation_t=1,
            dilation_band=1,
            stride_band=2,
            padding_band=1,
            groups=1,
            use_bias=True,
        ),
        dict(
            d_band_in=4,
            n_band_in=5,
            d_band_out=4,
            kernel_t=3,
            kernel_band=3,
            dilation_t=2,
            dilation_band=1,
            stride_band=1,
            padding_band=1,
            groups=4,
            use_bias=False,
        ),
    ],
)
def test_writer_temporal_conv2d_matches_functional_reference(cfg):
    np.random.seed(0)

    d_band_in = cfg["d_band_in"]
    n_band_in = cfg["n_band_in"]
    d_band_out = cfg["d_band_out"]
    kernel_t = cfg["kernel_t"]
    kernel_band = cfg["kernel_band"]
    dilation_t = cfg["dilation_t"]
    dilation_band = cfg["dilation_band"]
    stride_band = cfg["stride_band"]
    padding_band = cfg["padding_band"]
    groups = cfg["groups"]
    use_bias = cfg["use_bias"]

    time = 9
    channels_in = d_band_in * n_band_in
    n_band_out = _n_band_out(
        n_band_in=n_band_in,
        kernel_band=kernel_band,
        dilation_band=dilation_band,
        stride_band=stride_band,
        padding_band=padding_band,
    )

    weight_vals = np.random.randint(
        -2,
        3,
        size=(d_band_out, d_band_in // groups, kernel_band, kernel_t),
        dtype=np.int32,
    )
    if use_bias:
        bias_vals = np.random.randint(-2, 3, size=(d_band_out,), dtype=np.int32)
    else:
        bias_vals = None

    x_vals = np.random.randint(-3, 4, size=(time, channels_in), dtype=np.int32)

    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(channels_in, quanta=0, precision="int16")
    weight = writer.add_parameter(weight_vals, quanta=0, precision="int16")
    bias = (
        writer.add_parameter(bias_vals, quanta=0, precision="int16")
        if bias_vals is not None
        else None
    )

    y = writer.temporal_conv2d(
        weight=weight,
        x=x,
        quanta=0,
        kernel_size_t=kernel_t,
        kernel_size_band=kernel_band,
        n_band_in=n_band_in,
        dilation_t=dilation_t,
        dilation_band=dilation_band,
        stride_band=stride_band,
        padding_band=padding_band,
        groups=groups,
        bias=bias,
    )
    writer.add_outputs([y])

    y_fqir = graph.run(x_vals, dequant=False)

    x_torch = torch.as_tensor(x_vals.T[None, ...], dtype=torch.float32)
    weight_torch = torch.as_tensor(weight_vals, dtype=torch.float32)
    bias_torch = (
        torch.as_tensor(bias_vals, dtype=torch.float32)
        if bias_vals is not None
        else None
    )
    y_ref = temporal_conv2d(
        x_torch,
        weight_torch,
        dilation_t=dilation_t,
        dilation_band=dilation_band,
        padding_band=padding_band,
        stride_band=stride_band,
        stride_t=1,
        bias=bias_torch,
        groups=groups,
    )
    y_ref = y_ref.squeeze(0).transpose(0, 1).numpy().astype(np.int32)

    assert y_fqir.shape == (time, d_band_out * n_band_out)
    assert np.array_equal(y_fqir, y_ref)
