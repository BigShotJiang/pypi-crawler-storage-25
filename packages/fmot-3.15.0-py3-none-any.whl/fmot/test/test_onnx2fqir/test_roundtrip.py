from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import numpy as np
import onnx
import onnxruntime as ort
import pytest
import tensorflow as tf

from fmot.onnx2fqir.main import (
    convert_tdnn_to_cstate,
    convert_tdnn_to_onnx,
    quantize_tdnn_onnx,
)

TEST_DIR = Path(__file__).resolve().parent
FAILURE_DUMP_DIR = TEST_DIR / "failed_main_api_roundtrip_graphs"


@dataclass(frozen=True)
class MainAPITestCase:
    name: str
    source_format: str
    input_shape: tuple[int, ...]
    source_factory: object
    conversion_backend: str = "auto"
    fqir_rel_error_tol: float = 0.15
    marks: Any = ()


def create_keras_tdnn_batchnorm_model():
    input_layer = tf.keras.Input(shape=(10, 4), name="input")
    x = tf.keras.layers.Conv1D(
        filters=6,
        kernel_size=3,
        padding="valid",
        use_bias=False,
    )(input_layer)
    x = tf.keras.layers.BatchNormalization()(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_doc_example_model():
    input_layer = tf.keras.Input(shape=(10, 16), name="input")
    x = input_layer
    for _ in range(2):
        x = tf.keras.layers.Conv1D(
            filters=32,
            kernel_size=3,
            padding="valid",
            use_bias=True,
            activation="relu",
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-0.1, maxval=0.1, seed=None
            ),
        )(x)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation="softmax")(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_custom_rewriter_tdnn_model(final_act="softmax", use_bias=True):
    input_layer = tf.keras.Input(shape=(10, 16), name="input")
    x = input_layer

    for _ in range(2):
        x = tf.keras.layers.Conv1D(
            filters=32,
            kernel_size=3,
            padding="valid",
            use_bias=use_bias,
            activation="relu",
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-0.1, maxval=0.1, seed=None
            ),
        )(x)

    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation=final_act)(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_custom_rewriter_tdnn_mixed_bias_model(final_act="softmax", use_bias=True):
    input_layer = tf.keras.Input(shape=(10, 16), name="input")

    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(input_layer)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=not use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(x)

    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation=final_act)(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def freeze_batchnorm_statistics(model: tf.keras.Model) -> tf.keras.Model:
    warmup_shape = [8] + list(model.input_shape[1:])
    for _ in range(10):
        _ = model(np.random.rand(*warmup_shape).astype(np.float32), training=True)
    for layer in model.layers:
        if isinstance(layer, tf.keras.layers.BatchNormalization):
            layer.trainable = False
    return model


def export_tflite_model(model: tf.keras.Model) -> bytes:
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    return converter.convert()


def run_onnx_model(model_path: Path, x: np.ndarray) -> np.ndarray:
    session = ort.InferenceSession(str(model_path))
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    return session.run([output_name], {input_name: x})[0]


def dump_intermediate_onnx_graphs_for_failure(
    case_name: str,
    onnx_model: onnx.ModelProto,
    quantized_onnx_model: onnx.ModelProto,
) -> tuple[Path, Path]:
    FAILURE_DUMP_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = case_name.replace("/", "_").replace(" ", "_")
    fp_path = FAILURE_DUMP_DIR / f"{safe_name}.onnx"
    quant_path = FAILURE_DUMP_DIR / f"{safe_name}.qoperator.onnx"
    onnx.save(onnx_model, fp_path)
    onnx.save(quantized_onnx_model, quant_path)
    return fp_path, quant_path


def model_v3_0(
    num_class,
    feat_dim=40,
    convert_wav_to_fbank=False,
    num_frame=None,
    sample_rate=16000,
):
    tdnn1 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=8,
        dilation_rate=1,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn1",
    )
    tdnn1_bn = tf.keras.layers.BatchNormalization(name="tdnn1_bn")
    tdnn2 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=2,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn2",
    )
    tdnn2_bn = tf.keras.layers.BatchNormalization(name="tdnn2_bn")
    tdnn3 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn3",
    )
    tdnn3_bn = tf.keras.layers.BatchNormalization(name="tdnn3_bn")
    tdnn4 = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn4",
    )
    tdnn4_bn = tf.keras.layers.BatchNormalization(name="tdnn4_bn")
    tdnn5 = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=12,
        dilation_rate=4,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn5",
    )
    tdnn5_bn = tf.keras.layers.BatchNormalization(name="tdnn5_bn")
    if convert_wav_to_fbank:
        raise NotImplementedError("MelFilterBank")
        # input = tf.keras.Input(shape=(num_frame,), name='input_sample')
        # x = MelFilterBank(feat_dim, name='mel_filterbank_layer')(input)
        # x = tf.squeeze(x, axis=-1)
    else:
        input = tf.keras.Input(shape=(num_frame, feat_dim), name="input")
        x = input
    x = tdnn1_bn(tdnn1(x))
    x = tdnn2_bn(tdnn2(x))
    x = tdnn3_bn(tdnn3(x))
    x = tdnn4_bn(tdnn4(x))
    x = tdnn5_bn(tdnn5(x))
    e2e_out = tf.keras.layers.Dense(
        num_class, activation="softmax", use_bias=False, name="e2e_out"
    )(x)
    model = tf.keras.Model(inputs=input, outputs=e2e_out)
    return model


MAIN_API_TEST_CASES = [
    MainAPITestCase(
        name="batchnorm_keras",
        source_format="keras",
        conversion_backend="keras_tf2onnx",
        input_shape=(1, 10, 4),
        source_factory=lambda: freeze_batchnorm_statistics(
            create_keras_tdnn_batchnorm_model()
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="doc_example_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=create_doc_example_model,
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_bias_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_model(use_bias=True),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_nobias_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_model(use_bias=False),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_mixed_bias_true_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_mixed_bias_model(
            use_bias=True
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_mixed_bias_false_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_mixed_bias_model(
            use_bias=False
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="model_v3_0_keras_tf2onnx",
        source_format="keras",
        conversion_backend="keras_tf2onnx",
        input_shape=(1, 120, 40),
        source_factory=lambda: freeze_batchnorm_statistics(
            model_v3_0(
                num_class=4,
                feat_dim=40,
                convert_wav_to_fbank=False,
                num_frame=120,
            )
        ),
        fqir_rel_error_tol=0.15,
        marks=pytest.mark.xfail(
            strict=False,
            reason="Legacy keras_tf2onnx export for model_v3_0 is flaky; prefer keras_via_tflite.",
        ),
    ),
    MainAPITestCase(
        name="model_v3_0_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 120, 40),
        source_factory=lambda: freeze_batchnorm_statistics(
            model_v3_0(
                num_class=4,
                feat_dim=40,
                convert_wav_to_fbank=False,
                num_frame=120,
            )
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="user_example_tflite",
        source_format="tflite",
        conversion_backend="tflite_custom",
        input_shape=(1, 120, 40),
        source_factory=lambda: TEST_DIR / "user_example_conv1d_output.tflite",
        fqir_rel_error_tol=0.15,
    ),
]


@pytest.mark.parametrize(
    "case",
    [
        pytest.param(case, id=case.name, marks=case.marks)
        if case.marks
        else pytest.param(case, id=case.name)
        for case in MAIN_API_TEST_CASES
    ],
)
def test_main_api_roundtrip(case: MainAPITestCase, save_graphs=False):
    print(case.name)
    tf.random.set_seed(0)
    np.random.seed(0)

    representative_data = [
        np.random.rand(*case.input_shape).astype(np.float32) for _ in range(25)
    ]
    source = case.source_factory()
    if case.source_format == "tflite" and isinstance(source, Path):
        source = str(source)

    onnx_model = convert_tdnn_to_onnx(
        source,
        source_format=case.source_format,
        conversion_backend=case.conversion_backend,
    )
    quantized_onnx_model = quantize_tdnn_onnx(
        onnx_model, representative_data=representative_data
    )
    try:
        cstate = convert_tdnn_to_cstate(
            source,
            representative_data,
            source_format=case.source_format,
            options=["conv1d_via_unfold"],
            conversion_backend=case.conversion_backend,
        )
    except Exception as exc:
        fp_path, quant_path = dump_intermediate_onnx_graphs_for_failure(
            case.name, onnx_model, quantized_onnx_model
        )
        raise RuntimeError(
            f"convert_tdnn_to_cstate failed for {case.name}. "
            f"Saved floating-point ONNX to {fp_path} and quantized ONNX to {quant_path}."
        ) from exc

    if save_graphs:
        outdir = Path(__file__).parent
        onnx.save(onnx_model, outdir / "model_onnx.onnx")
        onnx.save(quantized_onnx_model, outdir / "quantized_model_onnx.onnx")

    with NamedTemporaryFile(suffix=".onnx") as temp:
        onnx.save(quantized_onnx_model, temp.name)

        sample_input = np.random.rand(*case.input_shape).astype(np.float32)
        onnx_output = run_onnx_model(Path(temp.name), sample_input)

        (x_quant,) = cstate.quantize_inputs([sample_input[0]])
        fqir_output = cstate.fqir.run(x_quant)
        (fqir_output,) = cstate.dequantize_outputs([fqir_output])
        fqir_output = fqir_output[cstate.receptive_field :]

    error = np.mean((fqir_output - onnx_output[0]) ** 2)
    error = np.sqrt(error / np.mean(onnx_output[0] ** 2))

    assert error < case.fqir_rel_error_tol


if __name__ == "__main__":
    test_main_api_roundtrip(case=MAIN_API_TEST_CASES[1], save_graphs=True)
