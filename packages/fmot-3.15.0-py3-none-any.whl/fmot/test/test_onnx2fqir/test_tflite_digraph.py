from __future__ import annotations

from pathlib import Path

from fmot.onnx2fqir.tflite_digraph import (
    add_pattern_node,
    find_subgraph_pattern_matches,
    load_tflite_digraph,
)
from fmot.onnx2fqir.tflite_patterns import analyze_dilated_conv1d_tflite_patterns

import networkx as nx


TEST_DIR = Path(__file__).resolve().parent
USER_EXAMPLE_TFLITE = TEST_DIR / "user_example_conv1d_output.tflite"


def test_load_tflite_digraph_preserves_operator_metadata():
    graph = load_tflite_digraph(model_path=str(USER_EXAMPLE_TFLITE))

    assert graph.number_of_nodes() == 41
    assert graph.number_of_edges() == 40

    assert graph.nodes[5]["op_name"] == "SPACE_TO_BATCH_ND"
    assert graph.nodes[6]["op_name"] == "EXPAND_DIMS"
    assert graph.nodes[7]["op_name"] == "CONV_2D"
    assert graph.nodes[8]["op_name"] == "RESHAPE"
    assert graph.nodes[9]["op_name"] == "BATCH_TO_SPACE_ND"

    edge = graph[5][6]
    assert edge["tensor_indices"] == [38]
    assert len(edge["tensor_names"]) == 1
    assert "SpaceToBatchND" in edge["tensor_names"][0]


def test_find_subgraph_pattern_matches_with_default_op_name_matching():
    graph = load_tflite_digraph(model_path=str(USER_EXAMPLE_TFLITE))

    pattern = nx.DiGraph()
    add_pattern_node(pattern, "stob", op_name="SPACE_TO_BATCH_ND")
    add_pattern_node(pattern, "lift", op_name="EXPAND_DIMS")
    add_pattern_node(pattern, "conv", op_name="CONV_2D")
    add_pattern_node(pattern, "reshape", op_name="RESHAPE")
    add_pattern_node(pattern, "btos", op_name="BATCH_TO_SPACE_ND")
    pattern.add_edges_from(
        [
            ("stob", "lift"),
            ("lift", "conv"),
            ("conv", "reshape"),
            ("reshape", "btos"),
        ]
    )

    matches = find_subgraph_pattern_matches(graph, pattern)

    assert [
        tuple(match.pattern_node_to_graph_node[node_id] for node_id in pattern.nodes)
        for match in matches
    ] == [
        (5, 6, 7, 8, 9),
        (13, 14, 15, 16, 17),
        (21, 22, 23, 24, 25),
        (29, 30, 31, 32, 33),
    ]


def test_find_subgraph_pattern_matches_supports_custom_verifiers():
    graph = load_tflite_digraph(model_path=str(USER_EXAMPLE_TFLITE))

    pattern = nx.DiGraph()
    add_pattern_node(pattern, "stob", op_name="SPACE_TO_BATCH_ND")
    add_pattern_node(
        pattern,
        "lift",
        verifier=lambda node: node["op_name"] in {"EXPAND_DIMS", "RESHAPE"},
        description="singleton-lift op",
    )
    add_pattern_node(pattern, "conv", op_name="CONV_2D")
    add_pattern_node(pattern, "reshape", op_name="RESHAPE")
    add_pattern_node(pattern, "btos", op_name="BATCH_TO_SPACE_ND")
    pattern.add_edges_from(
        [
            ("stob", "lift"),
            ("lift", "conv"),
            ("conv", "reshape"),
            ("reshape", "btos"),
        ]
    )

    matches = find_subgraph_pattern_matches(graph, pattern)

    assert len(matches) == 4
    assert matches[0].pattern_node_to_graph_node["lift"] == 6


def test_example_tflite_reports_expected_dilated_conv_matches():
    annotations = analyze_dilated_conv1d_tflite_patterns(
        model_path=str(USER_EXAMPLE_TFLITE)
    )

    matches = annotations["pattern_matches"]
    assert len(matches) == 4
    assert [match["derived"]["inferred_dilation"] for match in matches] == [2, 5, 5, 4]
    assert [
        (match["match_start_op_index"], match["match_end_op_index"])
        for match in matches
    ] == [(5, 9), (13, 17), (21, 25), (29, 33)]
