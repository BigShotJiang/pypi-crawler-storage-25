def test_onnx2fqir_doc_example():
    # CELL 0

    import tensorflow as tf
    import numpy as np

    input_layer = tf.keras.Input(shape=(10, 16))  # (time, channels)

    input_shape = input_layer.shape[1:]

    x = input_layer
    for _ in range(2):
        x = tf.keras.layers.Conv1D(
            filters=32,
            kernel_size=3,
            padding="valid",
            use_bias=True,
            activation="relu",
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-0.1, maxval=0.1, seed=None
            ),
        )(x)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation="softmax")(x)

    output_layer = x
    model = tf.keras.Model(inputs=input_layer, outputs=output_layer)

    # CELL 1

    from fmot.onnx2fqir.main import (
        convert_tdnn_to_onnx,
        quantize_tdnn_onnx,
        convert_tdnn_to_cstate,
    )

    representative_data = [
        np.random.rand(1, *input_shape).astype(np.float32) for _ in range(100)
    ]

    onnx_model = convert_tdnn_to_onnx(
        model,
        source_format="keras",
    )

    # CELL 2

    import onnx

    quantized_onnx_model = quantize_tdnn_onnx(
        onnx_model,
        representative_data=representative_data,
    )

    # CELL 3

    converted_state = convert_tdnn_to_cstate(
        model,
        representative_data,
        source_format="keras",
        options=["conv1d_via_unfold"],
    )

    fqir_graph = converted_state.fqir

    print(fqir_graph)

    # CELL 4
    import onnxruntime as ort

    # running the onnx graph
    input = np.random.rand(1, *input_shape).astype(np.float32)

    QOPERATOR_FILE = "my_qoperator_model.onnx"
    onnx.save(quantized_onnx_model, QOPERATOR_FILE)

    session = ort.InferenceSession(QOPERATOR_FILE)
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    (onnx_output,) = session.run([output_name], {input_name: input})
    print("Optimized ONNX model output:")
    print(onnx_output[0])

    # running the FQIR graph
    # - we must remove the batch dimension to run the FQIR, and run it through the converted_state's quantize method
    (fqir_input,) = converted_state.quantize_inputs([input[0]])
    fqir_output = fqir_graph.run(fqir_input)
    (fqir_output,) = converted_state.dequantize_outputs([fqir_output])

    # the FQIR returns an incremental output for each input time-step, so let's print just the final step
    print("FQIR Output (last time-step):")
    print(fqir_output[-1])


if __name__ == "__main__":
    test_onnx2fqir_doc_example()
