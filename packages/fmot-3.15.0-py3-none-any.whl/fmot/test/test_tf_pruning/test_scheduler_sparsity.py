import os

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import numpy as np
import pytest
from tensorflow import keras

tf = pytest.importorskip("tensorflow")

from fmot.tf.sparse.prune import (
    FemtoTFPruningUpdateStep,
    PruneHelper,
    strip_all_pruning,
)


class NoBackpropModel(keras.Model):
    def train_step(self, data):
        x, y, sample_weight = keras.utils.unpack_x_y_sample_weight(data)

        # Forward only
        y_pred = self(x, training=True)

        # Compute the compiled loss so logs/metrics behave normally
        loss = self.compiled_loss(
            y,
            y_pred,
            sample_weight=sample_weight,
            regularization_losses=self.losses,
        )

        # Update compiled metrics
        self.compiled_metrics.update_state(y, y_pred, sample_weight=sample_weight)

        # Return what fit() should log
        results = {m.name: m.result() for m in self.metrics}
        results["loss"] = loss
        return results


def _layer_weight_sparsities(layer):
    weights = [w for w in layer.weights if w.shape.ndims >= 2 and "bias" not in w.name]
    if not weights:
        return []
    sparsities = []
    for w in weights:
        arr = w.numpy()
        zeros = arr == 0.0
        sparsities.append(float(np.sum(zeros)) / float(arr.size))
    return sparsities


def _train_and_measure(
    build_model,
    input_shape,
    prune_layer_cls,
    output_shape,
    target_sparsity,
    prune_scheduler,
    power=None,
    layer_name="pruned",
):
    tf.keras.backend.clear_session()
    np.random.seed(0)
    tf.random.set_seed(0)

    model = build_model()
    pruned_layer = model.get_layer(layer_name)
    initial_bias = None
    if hasattr(pruned_layer, "bias") and pruned_layer.bias is not None:
        initial_bias = pruned_layer.bias.numpy().copy()

    helper = PruneHelper(
        pencil_size=4,
        prune_scheduler=prune_scheduler,
        min_parameter_thresh=0,
    )

    batch_size = 1
    steps_per_epoch = 20
    epochs = 5
    total_steps = steps_per_epoch * epochs

    pruned_kwargs = {}
    if power is not None:
        pruned_kwargs["power"] = power

    pruned = helper(
        model,
        layers_to_prune=[prune_layer_cls],
        initial_sparsity=0.0,
        final_sparsity=target_sparsity,
        begin_step=0,
        end_step=total_steps - 1,
        prune_frequency=1,
        **pruned_kwargs,
    )

    pruned.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=0.0), loss="mse")

    num_samples = batch_size * steps_per_epoch
    x = np.random.randn(num_samples, *input_shape).astype(np.float32)
    if isinstance(output_shape, int):
        output_shape = (output_shape,)
    y = np.random.randn(num_samples, *output_shape).astype(np.float32)

    pruned.fit(
        x,
        y,
        batch_size=batch_size,
        epochs=epochs,
        verbose=0,
        callbacks=[helper.get_pruning_callback()],
    )

    stripped = strip_all_pruning(pruned)
    pruned_layer = stripped.get_layer(layer_name)

    bias_ok = True
    if (
        hasattr(pruned_layer, "bias")
        and pruned_layer.bias is not None
        and initial_bias is not None
    ):
        bias_ok = np.allclose(pruned_layer.bias.numpy(), initial_bias, atol=1e-6)

    return _layer_weight_sparsities(pruned_layer), bias_ok


def _post_training_prune_and_measure(
    build_model,
    prune_layer_cls,
    target_sparsity,
    layer_name="pruned",
):
    tf.keras.backend.clear_session()
    np.random.seed(0)
    tf.random.set_seed(0)

    model = build_model()
    pruned_layer = model.get_layer(layer_name)
    initial_bias = None
    if hasattr(pruned_layer, "bias") and pruned_layer.bias is not None:
        initial_bias = pruned_layer.bias.numpy().copy()

    helper = PruneHelper(
        pencil_size=4,
        prune_scheduler="constant",
        min_parameter_thresh=0,
    )

    pruned = helper(
        model,
        layers_to_prune=[prune_layer_cls],
        initial_sparsity=0.0,
        final_sparsity=target_sparsity,
        begin_step=0,
        end_step=1,
        prune_frequency=1,
    )

    prune_step = FemtoTFPruningUpdateStep()
    prune_step.set_model(pruned)
    prune_step.on_train_begin()
    prune_step.on_train_batch_begin(batch=-1)
    prune_step.on_epoch_end(batch=-1)

    stripped = strip_all_pruning(pruned)
    pruned_layer = stripped.get_layer(layer_name)

    bias_ok = True
    if (
        hasattr(pruned_layer, "bias")
        and pruned_layer.bias is not None
        and initial_bias is not None
    ):
        bias_ok = np.allclose(pruned_layer.bias.numpy(), initial_bias, atol=1e-6)

    return _layer_weight_sparsities(pruned_layer), bias_ok


def _build_dense(output_dim):
    inputs = tf.keras.Input(shape=(64,))
    x = tf.keras.layers.Dense(
        32,
        activation="relu",
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(inputs)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_dense_out_dim(out_dim, use_bias=True):
    inputs = tf.keras.Input(shape=(64,))
    x = tf.keras.layers.Dense(32, activation="relu", use_bias=use_bias, name="pruned")(
        inputs
    )
    outputs = tf.keras.layers.Dense(out_dim, use_bias=use_bias)(x)
    return tf.keras.Model(inputs, outputs)


def _build_conv1d(output_dim):
    inputs = tf.keras.Input(shape=(32, 8))
    x = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=4,
        padding="same",
        activation="relu",
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(inputs)
    x = tf.keras.layers.Flatten()(x)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_conv2d(output_dim):
    inputs = tf.keras.Input(shape=(16, 16, 4))
    x = tf.keras.layers.Conv2D(
        filters=16,
        kernel_size=(3, 3),
        padding="same",
        activation="relu",
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(inputs)
    x = tf.keras.layers.Flatten()(x)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_rnn(output_dim):
    inputs = tf.keras.Input(shape=(10, 16))
    x = tf.keras.layers.Dense(16, activation="relu", name="pre_dense")(inputs)
    x = tf.keras.layers.SimpleRNN(
        32,
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(x)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_gru(output_dim):
    inputs = tf.keras.Input(shape=(10, 16))
    x = tf.keras.layers.Dense(16, activation="relu", name="pre_dense")(inputs)
    x = tf.keras.layers.GRU(
        128,
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(x)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_lstm(output_dim):
    inputs = tf.keras.Input(shape=(10, 16))
    x = tf.keras.layers.Dense(16, activation="relu", name="pre_dense")(inputs)
    x = tf.keras.layers.LSTM(
        32,
        use_bias=True,
        bias_initializer="ones",
        name="pruned",
    )(x)
    outputs = tf.keras.layers.Dense(output_dim)(x)
    return tf.keras.Model(inputs, outputs)


def _build_roundtrip_batchnorm_model():
    inputs = tf.keras.Input(shape=(10, 4), name="input")
    x = tf.keras.layers.Conv1D(
        filters=6,
        kernel_size=3,
        padding="valid",
        use_bias=False,
        name="pruned",
    )(inputs)
    x = tf.keras.layers.BatchNormalization()(x)
    return tf.keras.Model(inputs, x)


def _build_roundtrip_doc_example_model():
    inputs = tf.keras.Input(shape=(10, 16), name="input")
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=True,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
        name="pruned",
    )(inputs)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=True,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(x)
    x = tf.keras.layers.Flatten()(x)
    outputs = tf.keras.layers.Dense(10, activation="softmax")(x)
    return NoBackpropModel(inputs, outputs)


def _build_roundtrip_custom_rewriter_tdnn_model(use_bias=True):
    inputs = tf.keras.Input(shape=(10, 16), name="input")
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
        name="pruned",
    )(inputs)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(x)
    x = tf.keras.layers.Flatten()(x)
    outputs = tf.keras.layers.Dense(10, activation="softmax")(x)
    return tf.keras.Model(inputs, outputs)


def _build_roundtrip_custom_rewriter_tdnn_mixed_bias_model(use_bias=True):
    inputs = tf.keras.Input(shape=(10, 16), name="input")
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
        name="pruned",
    )(inputs)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=not use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(x)
    x = tf.keras.layers.Flatten()(x)
    outputs = tf.keras.layers.Dense(10, activation="softmax")(x)
    return tf.keras.Model(inputs, outputs)


def _build_roundtrip_model_v3_0():
    inputs = tf.keras.Input(shape=(120, 40), name="input")
    x = inputs
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=8,
        dilation_rate=1,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="pruned",
    )(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=2,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn2",
    )(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn3",
    )(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn4",
    )(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=12,
        dilation_rate=4,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn5",
    )(x)
    x = tf.keras.layers.BatchNormalization()(x)
    outputs = tf.keras.layers.Dense(4, activation="softmax", use_bias=False)(x)
    return tf.keras.Model(inputs, outputs)


@pytest.mark.parametrize(
    "build_model,input_shape,prune_layer_cls,output_shape,layer_name",
    [
        (
            lambda: _build_conv1d(output_dim=5),
            (32, 8),
            tf.keras.layers.Conv1D,
            (5,),
            "pruned",
        ),
        (
            lambda: _build_dense(output_dim=5),
            (64,),
            tf.keras.layers.Dense,
            (5,),
            "pruned",
        ),
        (
            lambda: _build_conv2d(output_dim=5),
            (16, 16, 4),
            tf.keras.layers.Conv2D,
            (5,),
            "pruned",
        ),
        (
            lambda: _build_rnn(output_dim=5),
            (10, 16),
            tf.keras.layers.SimpleRNN,
            (5,),
            "pruned",
        ),
        (
            lambda: _build_gru(output_dim=5),
            (10, 16),
            tf.keras.layers.GRU,
            (5,),
            "pruned",
        ),
        (
            lambda: _build_lstm(output_dim=5),
            (10, 16),
            tf.keras.layers.LSTM,
            (5,),
            "pruned",
        ),
        (
            _build_roundtrip_batchnorm_model,
            (10, 4),
            tf.keras.layers.Conv1D,
            (8, 6),
            "pruned",
        ),
        (
            _build_roundtrip_doc_example_model,
            (10, 16),
            tf.keras.layers.Conv1D,
            (10,),
            "pruned",
        ),
        (
            lambda: _build_roundtrip_custom_rewriter_tdnn_model(use_bias=True),
            (10, 16),
            tf.keras.layers.Conv1D,
            (10,),
            "pruned",
        ),
        (
            lambda: _build_roundtrip_custom_rewriter_tdnn_model(use_bias=False),
            (10, 16),
            tf.keras.layers.Conv1D,
            (10,),
            "pruned",
        ),
        (
            lambda: _build_roundtrip_custom_rewriter_tdnn_mixed_bias_model(
                use_bias=True
            ),
            (10, 16),
            tf.keras.layers.Conv1D,
            (10,),
            "pruned",
        ),
        (
            lambda: _build_roundtrip_custom_rewriter_tdnn_mixed_bias_model(
                use_bias=False
            ),
            (10, 16),
            tf.keras.layers.Conv1D,
            (10,),
            "pruned",
        ),
        # this doesn't work on cpu -- no cpu kernel for dilated conv1d in tensorflow
        # (_build_roundtrip_model_v3_0, (120, 40), tf.keras.layers.Conv1D, (21, 4), "pruned"),
    ],
)
@pytest.mark.parametrize(
    "prune_scheduler,power",
    [
        ("linear", None),
        ("poly_decay", 3),
        ("constant", None),
        ("sine", None),
    ],
)
def test_schedule_reaches_target_sparsity(
    build_model,
    input_shape,
    prune_layer_cls,
    output_shape,
    layer_name,
    prune_scheduler,
    power,
):
    target_sparsity = 0.7
    sparsity_tol = 0.1

    sparsities, bias_ok = _train_and_measure(
        build_model,
        input_shape,
        prune_layer_cls,
        output_shape,
        target_sparsity,
        prune_scheduler=prune_scheduler,
        power=power,
        layer_name=layer_name,
    )
    assert (
        sparsities
    ), "Expected pruned layer to have at least one prunable weight matrix."
    for sparsity in sparsities:
        assert sparsity >= target_sparsity - sparsity_tol
        assert sparsity <= target_sparsity + sparsity_tol
    assert bias_ok, "Bias values should remain unchanged by pruning."


def test_dense_out_dim_le_pencil_size_raises():
    target_sparsity = 0.7

    tf.keras.backend.clear_session()
    np.random.seed(0)
    tf.random.set_seed(0)

    model = _build_dense_out_dim(out_dim=4, use_bias=False)
    helper = PruneHelper(
        pencil_size=4,
        prune_scheduler="linear",
        min_parameter_thresh=0,
    )

    pruned = helper(
        model,
        layers_to_prune=[tf.keras.layers.Dense],
        initial_sparsity=0.0,
        final_sparsity=target_sparsity,
        begin_step=0,
        end_step=1,
        prune_frequency=1,
    )
    pruned.compile(optimizer="adam", loss="mse")

    x = np.random.randn(8, 64).astype(np.float32)
    y = np.random.randn(8, 4).astype(np.float32)

    with pytest.raises(ValueError, match="Input tensor must be rank 2"):
        pruned.fit(
            x,
            y,
            batch_size=4,
            epochs=1,
            verbose=0,
            callbacks=[helper.get_pruning_callback()],
        )


def test_post_training_pruning_api_roundtrip_model_v3_0_cpu_safe():
    target_sparsity = 0.7
    sparsity_tol = 0.1

    sparsities, bias_ok = _post_training_prune_and_measure(
        _build_roundtrip_model_v3_0,
        tf.keras.layers.Conv1D,
        target_sparsity,
        layer_name="pruned",
    )

    assert (
        sparsities
    ), "Expected pruned layer to have at least one prunable weight matrix."
    for sparsity in sparsities:
        assert sparsity >= target_sparsity - sparsity_tol
        assert sparsity <= target_sparsity + sparsity_tol
    assert bias_ok, "Bias values should remain unchanged by pruning."
