"""
Implementation of softmax kernels
(and sigmoid fall-back)
"""

from typing import TYPE_CHECKING
import numpy as np
from fmot.fqir import TensorProto

if TYPE_CHECKING:
    from fmot.fqir.writer import FQIRWriter


def exp_clip1(x):
    x = np.clip(x, None, 0)
    y = np.exp(x)
    return y


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def _softmax(writer: "FQIRWriter", x: TensorProto):
    x_max = writer.max(x)
    x_normed = writer.sub(x, x_max, quanta=x.quanta)

    exp_x = writer.interpolating_lut(x_normed, func=exp_clip1, name="exp")
    sum_exp = writer.sum(exp_x)
    y = writer.divide(exp_x, sum_exp, pos_only=True, quanta=-15)

    return y


def _softmax_via_sigmoid(writer: "FQIRWriter", x: TensorProto):
    if x.shape[0] != 2:
        raise ValueError(f"softmax-via-sigmoid requires 2 channels, got {x.shape[0]}")
    a, b = writer.split(x, [1, 1])
    d = writer.sub(a, b, quanta=a.quanta + 1)

    sig = writer.interpolating_lut(d, sigmoid, name="sigmoid")
    om_sig = writer.add(1, writer.multiply(sig, -1), quanta=-15)
    sig = writer.add(sig, 0, quanta=-15)
    res = writer.cat([sig, om_sig])
    return res


def write_softmax(writer: "FQIRWriter", x: TensorProto):
    if x.shape[0] == 2:
        return _softmax_via_sigmoid(writer, x)
    else:
        return _softmax(writer, x)
