from fmot.fqir import TensorProto
import math
import typing

if typing.TYPE_CHECKING:
    from fmot.fqir.writer import FQIRWriter


def barni_magnitude(
    writer: "FQIRWriter", x: TensorProto, y: TensorProto, quanta=None
) -> TensorProto:
    # determine the output quanta
    if quanta is None:
        q_out = max(x.quanta, y.quanta)
    else:
        q_out = quanta

    # calculate Barni coefficients
    k0 = 1
    k1 = math.sqrt(2) - 1
    d = 2 / (1 + math.sqrt(k0**2 + k1**2))

    c0 = d * k0
    c1 = d * k1

    x = writer.abs(x)
    y = writer.abs(y)

    ramp = writer.relu(writer.sub(x, y))
    a0 = writer.add(y, ramp, quanta=q_out)
    a1 = writer.sub(x, ramp, quanta=q_out)

    res = writer.add(
        writer.multiply(a0, c0, quanta=q_out),
        writer.multiply(a1, c1, quanta=q_out),
        quanta=q_out + 1,
    )

    return res
