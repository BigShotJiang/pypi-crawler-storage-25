from fmot.fqir import TensorProto
from typing import TYPE_CHECKING, Literal
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

if TYPE_CHECKING:
    from fmot.fqir.writer import FQIRWriter


def write_pooling(
    writer: "FQIRWriter",
    x: TensorProto,
    kernel_size: int,
    mode: Literal["min", "max"],
    dilation: int,
):
    from fmot.fqir.writer.fqir_writer import get_bw

    if kernel_size == 1:
        return x

    bw = get_bw(x.dtype)
    if mode == "max":
        pad_value = -(2 ** (bw - 1))
    elif mode == "min":
        pad_value = 2 ** (bw - 1) - 1
    else:
        raise ValueError(f"Unexpected mode {mode}")
    init_value = np.ones(x.shape[0]) * pad_value * 2**x.quanta

    buff = []
    for i in range((kernel_size - 1) * dilation):
        buff.append(
            writer.add_init_buffer(init_value, quanta=x.quanta, precision=x.dtype)
        )

    res = x
    for k in range(kernel_size - 1):
        if mode == "min":
            res = writer.minimum(res, buff[k * dilation])
        elif mode == "max":
            res = writer.maximum(res, buff[k * dilation])

    if len(buff) >= 2:
        for b_next, b_prev in zip(buff[:-1], buff[1:]):
            writer.assign(b_next, b_prev)

    writer.assign(buff[-1], x)

    return res


def causal_pool1d_np(
    x: np.ndarray, kernel_size: int, dilation: int = 1, mode: str = "max"
) -> np.ndarray:
    """
    Causal pool over axis 0 with stride 1.

    Args:
        x: Input array of shape (L, C) or more generally (L, ...),
           where pooling is applied over the first dimension.
        kernel_size: Number of pooled elements.
        dilation: Spacing between pooled elements.

    Returns:
        Array with the same shape as x.

    Notes:
        - Causal means output[t] only depends on x[:t+1].
        - Left padding of size (kernel_size - 1) * dilation is applied.
        - Padding value is -inf, so padded values do not affect max-pooling.
    """
    if kernel_size <= 0:
        raise ValueError("kernel_size must be >= 1")
    if dilation <= 0:
        raise ValueError("dilation must be >= 1")
    if x.shape[0] == 0:
        return x.copy()

    pad = (kernel_size - 1) * dilation

    # Use -inf padding so it does not affect max pooling.
    # Convert ints to float if needed, since -inf is a float sentinel.
    if not np.issubdtype(x.dtype, np.floating):
        x = x.astype(np.float32)

    pad_width = [(0, 0)] * x.ndim
    pad_width[0] = (pad, 0)
    if mode == "max":
        x_pad = np.pad(x, pad_width, mode="constant", constant_values=-np.inf)
    else:
        x_pad = np.pad(x, pad_width, mode="constant", constant_values=np.inf)

    # Sliding windows of full receptive field size along axis 0
    window_len = pad + 1
    windows = sliding_window_view(x_pad, window_shape=window_len, axis=0)
    # windows shape: (L, ..., window_len)

    # Take dilated positions: [0, D, 2D, ..., (K-1)D]
    idx = np.arange(0, window_len, dilation)
    if mode == "max":
        pooled = windows[..., idx].max(axis=-1)
    elif mode == "min":
        pooled = windows[..., idx].min(axis=-1)

    return pooled
