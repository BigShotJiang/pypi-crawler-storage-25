import datetime

from pydantic import Field

from kubex.k8s.v1_32.core.v1.container_status import ContainerStatus
from kubex.k8s.v1_32.core.v1.host_ip import HostIP
from kubex.k8s.v1_32.core.v1.pod_condition import PodCondition
from kubex.k8s.v1_32.core.v1.pod_ip import PodIP
from kubex.k8s.v1_32.core.v1.pod_resource_claim_status import PodResourceClaimStatus
from kubex_core.models.base import BaseK8sModel


class PodStatus(BaseK8sModel):
    """PodStatus represents information about the status of a pod. Status may trail the actual state of a system, especially if the node that hosts the pod cannot contact the control plane."""

    conditions: list[PodCondition] | None = Field(
        default=None,
        alias="conditions",
        description="Current service state of pod. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#pod-conditions",
    )
    container_statuses: list[ContainerStatus] | None = Field(
        default=None,
        alias="containerStatuses",
        description="Statuses of containers in this pod. Each container in the pod should have at most one status in this list, and all statuses should be for containers in the pod. However this is not enforced. If a status for a non-existent container is present in the list, or the list has duplicate names, the behavior of various Kubernetes components is not defined and those statuses might be ignored. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#pod-and-container-status",
    )
    ephemeral_container_statuses: list[ContainerStatus] | None = Field(
        default=None,
        alias="ephemeralContainerStatuses",
        description="Statuses for any ephemeral containers that have run in this pod. Each ephemeral container in the pod should have at most one status in this list, and all statuses should be for containers in the pod. However this is not enforced. If a status for a non-existent container is present in the list, or the list has duplicate names, the behavior of various Kubernetes components is not defined and those statuses might be ignored. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#pod-and-container-status",
    )
    host_ip: str | None = Field(
        default=None,
        alias="hostIP",
        description="hostIP holds the IP address of the host to which the pod is assigned. Empty if the pod has not started yet. A pod can be assigned to a node that has a problem in kubelet which in turns mean that HostIP will not be updated even if there is a node is assigned to pod",
    )
    host_ips: list[HostIP] | None = Field(
        default=None,
        alias="hostIPs",
        description="hostIPs holds the IP addresses allocated to the host. If this field is specified, the first entry must match the hostIP field. This list is empty if the pod has not started yet. A pod can be assigned to a node that has a problem in kubelet which in turns means that HostIPs will not be updated even if there is a node is assigned to this pod.",
    )
    init_container_statuses: list[ContainerStatus] | None = Field(
        default=None,
        alias="initContainerStatuses",
        description="Statuses of init containers in this pod. The most recent successful non-restartable init container will have ready = true, the most recently started container will have startTime set. Each init container in the pod should have at most one status in this list, and all statuses should be for containers in the pod. However this is not enforced. If a status for a non-existent container is present in the list, or the list has duplicate names, the behavior of various Kubernetes components is not defined and those statuses might be ignored. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#pod-and-container-status",
    )
    message: str | None = Field(
        default=None,
        alias="message",
        description="A human readable message indicating details about why the pod is in this condition.",
    )
    nominated_node_name: str | None = Field(
        default=None,
        alias="nominatedNodeName",
        description="nominatedNodeName is set only when this pod preempts other pods on the node, but it cannot be scheduled right away as preemption victims receive their graceful termination periods. This field does not guarantee that the pod will be scheduled on this node. Scheduler may decide to place the pod elsewhere if other nodes become available sooner. Scheduler may also decide to give the resources on this node to a higher priority pod that is created after preemption. As a result, this field may be different than PodSpec.nodeName when the pod is scheduled.",
    )
    phase: str | None = Field(
        default=None,
        alias="phase",
        description="The phase of a Pod is a simple, high-level summary of where the Pod is in its lifecycle. The conditions array, the reason and message fields, and the individual container status arrays contain more detail about the pod's status. There are five possible phase values: Pending: The pod has been accepted by the Kubernetes system, but one or more of the container images has not been created. This includes time before being scheduled as well as time spent downloading images over the network, which could take a while. Running: The pod has been bound to a node, and all of the containers have been created. At least one container is still running, or is in the process of starting or restarting. Succeeded: All containers in the pod have terminated in success, and will not be restarted. Failed: All containers in the pod have terminated, and at least one container has terminated in failure. The container either exited with non-zero status or was terminated by the system. Unknown: For some reason the state of the pod could not be obtained, typically due to an error in communicating with the host of the pod. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#pod-phase",
    )
    pod_ip: str | None = Field(
        default=None,
        alias="podIP",
        description="podIP address allocated to the pod. Routable at least within the cluster. Empty if not yet allocated.",
    )
    pod_ips: list[PodIP] | None = Field(
        default=None,
        alias="podIPs",
        description="podIPs holds the IP addresses allocated to the pod. If this field is specified, the 0th entry must match the podIP field. Pods may be allocated at most 1 value for each of IPv4 and IPv6. This list is empty if no IPs have been allocated yet.",
    )
    qos_class: str | None = Field(
        default=None,
        alias="qosClass",
        description="The Quality of Service (QOS) classification assigned to the pod based on resource requirements See PodQOSClass type for available QOS classes More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-qos/#quality-of-service-classes",
    )
    reason: str | None = Field(
        default=None,
        alias="reason",
        description="A brief CamelCase message indicating details about why the pod is in this state. e.g. 'Evicted'",
    )
    resize: str | None = Field(
        default=None,
        alias="resize",
        description='Status of resources resize desired for pod\'s containers. It is empty if no resources resize is pending. Any changes to container resources will automatically set this to "Proposed"',
    )
    resource_claim_statuses: list[PodResourceClaimStatus] | None = Field(
        default=None,
        alias="resourceClaimStatuses",
        description="Status of resource claims.",
    )
    start_time: datetime.datetime | None = Field(
        default=None,
        alias="startTime",
        description="RFC 3339 date and time at which the object was acknowledged by the Kubelet. This is before the Kubelet pulled the container image(s) for the pod.",
    )
