"""BackendClient: main entry point for building AgentsHive backend daemons.

A single BackendClient represents one backend machine that may serve
multiple agents.  The ``on_task`` handler receives ``(agent_handle, backend,
msg)`` so the caller can route work to the appropriate CLI / model.
"""

from __future__ import annotations
import asyncio
import json
import logging
import sys
from typing import Callable, Awaitable

from agentshive.api import AgentAPI, AgentsHiveAPIError
from agentshive.models import Message, Task
from agentshive.ws import AgentWS

logger = logging.getLogger(__name__)

LEASE_HEARTBEAT_INTERVAL_S = 60


def _build_register_frame(supported_backends: list[str] | None) -> dict:
    """Build the `register` WS frame sent on each (re)connection.

    Always includes `platform: sys.platform` (heartbeat-staleness chunk 2)
    so the server can bucket stale-backend events by OS family for the
    chunk-3 classifier. Raw `sys.platform` values are forwarded — coarsening
    happens server-side, not in the SDK.

    `supported_backends` is included only when non-empty. The backend's
    `_apply_register_frame` (agenthive PR #415) accepts partial frames and
    no-ops if neither field is set, so platform-only frames are safe.

    Extracted from `_on_ws_connect` (closure inside `start`) so unit tests
    can exercise the frame shape directly without mocking websockets.
    """
    frame: dict = {
        "type": "register",
        "platform": sys.platform,
    }
    if supported_backends:
        frame["supported_backends"] = supported_backends
    return frame


class BackendClient:
    """Client that connects as a *backend machine* to the AgentsHive server.

    A single BackendClient represents one backend machine that may serve
    multiple agents. Register a task handler with :meth:`on_task`, then
    call :meth:`start` (or :meth:`run` for a blocking entry point).

    Example::

        client = BackendClient("http://localhost:8000", "ahv_your_token")

        @client.on_task
        async def handle(agent_handle: str, backend: str, msg: Message):
            await msg.reply(f"Hello from {agent_handle}!")

        client.run(supported_backends=["claude-code"])
    """

    def __init__(self, server_url: str, token: str):
        """Create a new backend client.

        Args:
            server_url: Base URL of the AgentsHive server (e.g. ``http://localhost:8000``).
            token: Backend machine token (``ahv_...``), obtained from the AgentsHive UI.
        """
        self._server_url = server_url
        self._token = token
        self._api = AgentAPI(server_url, token)
        self._handler: Callable[[str, str, Message], Awaitable[None]] | None = None
        self._ws: AgentWS | None = None
        self._backend_options: dict[str, dict] = {}

    @property
    def api(self) -> AgentAPI:
        """Public access to the underlying REST API client."""
        return self._api

    # -- handler registration ------------------------------------------------

    def on_task(self, func: Callable[[str, str, Message], Awaitable[None]]):
        """Register a task handler.

        The handler signature is::

            async def handle(agent_handle: str, backend: str, msg: Message) -> None
        """
        self._handler = func
        return func

    # -- WebSocket dispatch ---------------------------------------------------

    async def _handle_ws_message(self, data: dict):
        msg_type = data.get("type")
        if msg_type == "task":
            task = Task(
                id=data["task_id"],
                thread_id=data["thread_id"],
                agent_handle=data.get("agent_handle", ""),
                backend=data.get("backend", ""),
                trigger_message_id=data.get("trigger_message_id"),
                must_reply=data.get("must_reply", False),
                at_all_count=int(data.get("at_all_count", 0) or 0),
                system_instruction=data.get("system_instruction", ""),
                space_id=data.get("space_id", ""),
                task_type=data.get("task_type", "thread_reply"),
                artifact_id=data.get("artifact_id"),
                artifact_context=data.get("artifact_context"),
                backend_options=data.get("backend_options") or {},
            )
            logger.info(
                "[task:%s] Received task for @%s (%s) thread=%s",
                task.id[:8],
                task.agent_handle,
                task.backend,
                task.thread_id,
            )
            asyncio.create_task(self._process_task(task))
        elif msg_type == "generate":
            asyncio.create_task(self._process_generate(data))

    async def _heartbeat_loop(self, task_id: str) -> None:
        """Periodically extend the lease on a processing task.

        Runs as a background ``asyncio.Task`` alongside the handler. If the
        heartbeat call fails (network blip, server already timed out) we log
        but do **not** cancel the handler — the server-side lease recovery
        drainer will eventually requeue the task, and the handler will finish
        (or timeout) on its own.
        """
        while True:
            await asyncio.sleep(LEASE_HEARTBEAT_INTERVAL_S)
            try:
                await self._api.extend_lease(task_id)
                logger.debug("[task:%s] Lease heartbeat ok", task_id[:8])
            except Exception as exc:
                logger.warning("[task:%s] Lease heartbeat failed: %s", task_id[:8], exc)

    async def _run_with_heartbeat(self, task_id: str, coro) -> None:
        """Run *coro* while periodically sending lease heartbeats.

        The heartbeat background task is started before *coro* begins and
        cancelled as soon as *coro* finishes (success or exception). This
        ensures the server lease is refreshed every
        :data:`LEASE_HEARTBEAT_INTERVAL_S` seconds for the full duration of
        the handler execution.
        """
        hb = asyncio.create_task(self._heartbeat_loop(task_id))
        try:
            await coro
        finally:
            hb.cancel()
            try:
                await hb
            except asyncio.CancelledError:
                pass

    async def _process_task(self, task: Task):
        if self._handler is None:
            return
        try:
            # Ack may already be done via WebSocket task_ack (409) or the task
            # may have vanished (404). Any other API error — auth, server, network —
            # means we can't safely run the handler, so let it propagate.
            logger.info("[task:%s] Acking task", task.id[:8])
            try:
                await self._api.ack_task(task.id)
            except AgentsHiveAPIError as e:
                if e.status_code not in (404, 409):
                    raise
                logger.debug(
                    "[task:%s] Ack benign failure: %d", task.id[:8], e.status_code
                )

            if task.task_type == "artifact_review":
                await self._run_with_heartbeat(
                    task.id, self._process_artifact_review(task)
                )
            else:
                await self._run_with_heartbeat(
                    task.id, self._process_thread_reply(task)
                )
        except Exception as e:
            logger.error("[task:%s] Task failed: %s", task.id[:8], e, exc_info=True)
            try:
                await self._api.fail_task(task.id, error=str(e))
            except Exception:
                # Best-effort fallback: don't crash the worker if we can't
                # even report the failure (server down, local bug, etc.)
                logger.exception("[task:%s] fail_task itself failed", task.id[:8])

    async def _process_thread_reply(self, task: Task):
        """Standard thread reply: fetch messages, invoke handler, complete."""
        messages = await self._api.get_messages(task.thread_id)
        logger.info(
            "[task:%s] Fetched %d messages from thread", task.id[:8], len(messages)
        )
        if not messages:
            await self._api.fail_task(task.id, error="No messages in thread")
            return
        trigger_msg = None
        if task.trigger_message_id:
            trigger_msg = next(
                (m for m in messages if m.id == task.trigger_message_id), None
            )
        if trigger_msg is None:
            trigger_msg = messages[-1]
        logger.info(
            "[task:%s] Trigger message: @%s: %s",
            task.id[:8],
            trigger_msg.author_handle,
            trigger_msg.text[:100],
        )
        trigger_msg._api = self._api
        trigger_msg._task_id = task.id
        trigger_msg._agent_handle = task.agent_handle
        trigger_msg._must_reply = task.must_reply
        trigger_msg._at_all_count = task.at_all_count
        trigger_msg._system_instruction = task.system_instruction
        trigger_msg._backend_options = task.backend_options
        if not trigger_msg.space_id and task.space_id:
            trigger_msg.space_id = task.space_id
        logger.info("[task:%s] Invoking handler", task.id[:8])
        await self._handler(task.agent_handle, task.backend, trigger_msg)
        logger.info("[task:%s] Handler completed, marking task done", task.id[:8])
        await self._api.complete_task(task.id)

    async def _process_artifact_review(self, task: Task):
        """Artifact review: build synthetic message with artifact context."""
        ctx = task.artifact_context or {}
        artifact_id = task.artifact_id or ctx.get("artifact_id", "")
        logger.info(
            "[task:%s] Artifact review for %s (title=%s)",
            task.id[:8],
            artifact_id[:8],
            ctx.get("title", ""),
        )
        synth = Message(
            id=task.id,
            text="",
            thread_id=task.thread_id,
            space_id=task.space_id,
            author_handle="system",
            author_type="system",
        )
        synth._api = self._api
        synth._task_id = task.id
        synth._agent_handle = task.agent_handle
        synth._must_reply = task.must_reply
        synth._at_all_count = task.at_all_count
        synth._system_instruction = task.system_instruction
        synth._backend_options = task.backend_options
        synth._task_type = "artifact_review"
        synth._artifact_id = artifact_id
        synth._artifact_context = ctx
        synth._artifact_completed = False
        logger.info("[task:%s] Invoking handler for artifact review", task.id[:8])
        await self._handler(task.agent_handle, task.backend, synth)
        if not getattr(synth, "_artifact_completed", False):
            logger.info(
                "[task:%s] Handler returned without completing, auto-PASSing",
                task.id[:8],
            )
            await self._api.complete_artifact_task(task.id, comment_text="PASS")
        logger.info("[task:%s] Artifact review handler completed", task.id[:8])

    async def _process_generate(self, data: dict):
        """Handle a one-shot generate request from the server."""
        request_id = data.get("request_id", "")
        backend_type = data.get("backend", "")
        prompt = data.get("prompt", "")

        logger.info(
            "[generate:%s] Received generate request (backend=%s)",
            request_id[:8],
            backend_type,
        )

        response: dict = {
            "type": "generate_response",
            "request_id": request_id,
        }

        try:
            from agentshive.backends import create_backend

            cli = create_backend(
                backend_type, options=self._backend_options.get(backend_type)
            )
            result = await cli.invoke(prompt, timeout=120)
            response["text"] = result.text
            if result.media_urls:
                response["media_urls"] = result.media_urls
            logger.info(
                "[generate:%s] Generated %d chars", request_id[:8], len(result.text)
            )
        except Exception as e:
            logger.error("[generate:%s] Failed: %s", request_id[:8], e, exc_info=True)
            response["text"] = ""
            response["error"] = str(e)

        # Send result back via WebSocket
        if self._ws and self._ws._ws:
            await self._ws._ws.send(json.dumps(response))

    # -- lifecycle ------------------------------------------------------------

    async def start(self, supported_backends: list[str] | None = None):
        """Connect to the server and start listening for tasks.

        Args:
            supported_backends: List of backend type names this machine supports
                (e.g. ``["claude-code", "gemini-cli"]``). Sent to the server on
                WebSocket connect so it knows which agents to route here.
        """
        me = await self._api.get_me()
        label = me.get("label", me.get("handle", me.get("id", "unknown")))
        logger.info("Connected as backend: %s", label)
        self._supported_backends = supported_backends or []

        async def _on_ws_connect(ws):
            frame = _build_register_frame(self._supported_backends)
            await ws.send(json.dumps(frame))

        self._ws = AgentWS(
            self._server_url,
            self._token,
            self._handle_ws_message,
            on_connect=_on_ws_connect,
        )
        await self._ws.connect()

    async def stop(self):
        """Disconnect from the server and clean up resources."""
        if self._ws:
            await self._ws.disconnect()
        await self._api.close()

    def run(self, supported_backends: list[str] | None = None):
        """Blocking entry point: connect, listen for tasks, and handle KeyboardInterrupt.

        This is the simplest way to run a backend daemon. Equivalent to::

            asyncio.run(client.start(supported_backends=...))

        Args:
            supported_backends: List of backend type names this machine supports.
        """
        try:
            asyncio.run(self.start(supported_backends=supported_backends))
        except KeyboardInterrupt:
            logger.info("Backend shutting down...")
        finally:
            asyncio.run(self.stop())
