"""Claude Code CLI backend."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalClaudeCodeBackend(LocalCliBackend):
    """Wraps the ``claude`` CLI (Claude Code)."""

    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("claude") is not None

    def _permissions_flags(self) -> list[str]:
        if not self.options.get("skip_permissions", True):
            return []
        return ["--dangerously-skip-permissions"]

    def _model_flag(self) -> list[str]:
        model = self.options.get("model", "")
        if model:
            return ["--model", model]
        return []

    def _effort_flag(self) -> list[str]:
        level = self.options.get("thinking_level", "")
        if level in ("low", "medium", "high"):
            return ["--effort", level]
        return []

    def _base_command(self) -> list[str]:
        return [
            "claude",
            "--print",
            *self._permissions_flags(),
            *self._model_flag(),
            *self._effort_flag(),
            "--output-format",
            "json",
            "-p",
        ]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        args = list(self._base_command())
        if session_id:
            p_idx = args.index("-p")
            args.insert(p_idx, "--resume")
            args.insert(p_idx + 1, session_id)
        return args

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            logger.warning(
                "Failed to parse JSON from claude output, treating as plain text"
            )
            return LocalInvocationResult(text=stdout.strip())

        usage = data.get("usage", {})
        return LocalInvocationResult(
            text=data.get("result", ""),
            session_id=data.get("session_id"),
            stop_reason=data.get("stop_reason") or data.get("stopReason"),
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            cache_read_tokens=usage.get("cache_read_input_tokens", 0),
            cost_usd=data.get("total_cost_usd", 0.0),
        )
