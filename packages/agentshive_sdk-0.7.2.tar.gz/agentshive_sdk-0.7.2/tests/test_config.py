"""Tests for agentshive.config module."""

from __future__ import annotations


import pytest

from agentshive.config import (
    Config,
    ConfigError,
    detect_backends,
    load_config,
    save_config,
    validate_config,
)


@pytest.fixture
def config_dir(tmp_path, monkeypatch):
    """Redirect config paths to a temp directory."""
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    return tmp_path


class TestSaveAndLoad:
    def test_round_trip(self, config_dir):
        config = Config(
            server_url="https://example.com",
            token="ahv_abc123",
            backends={"claude_code": True, "codex": False},
            auto_start=True,
            log_level="debug",
            repo_path="/home/user/project",
        )
        save_config(config)
        loaded = load_config()
        assert loaded.server_url == "https://example.com"
        assert loaded.token == "ahv_abc123"
        assert loaded.backends == {"claude_code": True, "codex": False}
        assert loaded.auto_start is True
        assert loaded.log_level == "debug"
        assert loaded.repo_path == "/home/user/project"

    def test_load_missing_file(self, config_dir):
        with pytest.raises(ConfigError, match="Config not found"):
            load_config()

    def test_load_invalid_json(self, config_dir):
        (config_dir / "config.json").write_text("not json{")
        with pytest.raises(ConfigError, match="Invalid config"):
            load_config()

    def test_save_creates_directory(self, tmp_path, monkeypatch):
        nested = tmp_path / "a" / "b"
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", nested)
        monkeypatch.setattr("agentshive.config.CONFIG_FILE", nested / "config.json")
        save_config(Config(server_url="http://x", token="ahv_t"))
        assert (nested / "config.json").exists()

    def test_load_defaults(self, config_dir):
        """Missing fields in JSON get defaults."""
        (config_dir / "config.json").write_text('{"server_url": "http://x"}')
        config = load_config()
        assert config.server_url == "http://x"
        assert config.token == ""
        assert config.backends == {}
        assert config.auto_start is False
        assert config.repo_path is None
        # New install (no timeout in JSON) should pick up the bumped default.
        assert config.timeout == 3600

    def test_dataclass_default_timeout_is_60min(self):
        """Fresh Config() must default to 3600s (60 min). Regression guard
        for the 2026-05-14 bump from 300s — solo-founder dogfood usage was
        seeing model invocations killed at 5 min."""
        assert Config().timeout == 3600

    def test_load_preserves_explicit_timeout(self, config_dir):
        """An existing config.json with an explicit timeout value must be
        preserved on read — auto-migrating disk values would silently
        override user intent."""
        (config_dir / "config.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "timeout": 300}'
        )
        config = load_config()
        assert config.timeout == 300

    def test_load_repo_path_null(self, config_dir):
        (config_dir / "config.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "repo_path": null}'
        )
        config = load_config()
        assert config.repo_path is None

    def test_load_repo_path_string(self, config_dir):
        (config_dir / "config.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "repo_path": "/tmp/repo"}'
        )
        config = load_config()
        assert config.repo_path == "/tmp/repo"


class TestValidate:
    def test_valid_config(self):
        config = Config(
            server_url="https://agentshive.agency/",
            token="ahv_abc123",
            backends={"claude_code": True},
        )
        assert validate_config(config) == []

    # Note: `test_missing_server` was removed because ``Config.server_url``
    # has a default of ``"https://agentshive.agency/"``, so a ``Config``
    # constructed without ``server_url`` is not actually missing one. The
    # test asserted behaviour that can no longer exist with the current
    # default; keeping it would require either removing the default (a
    # product decision we are not making here) or asserting something the
    # validator does not do.

    def test_missing_token(self):
        config = Config(server_url="http://x", backends={"claude_code": True})
        errors = validate_config(config)
        assert any("token is required" in e for e in errors)

    def test_bad_token_prefix(self):
        config = Config(
            server_url="http://x", token="bad_token", backends={"claude_code": True}
        )
        errors = validate_config(config)
        assert any("ahv_" in e for e in errors)

    def test_no_backends_enabled(self):
        config = Config(
            server_url="http://x", token="ahv_abc", backends={"codex": False}
        )
        errors = validate_config(config)
        assert any("backend" in e.lower() for e in errors)


class TestDetectBackends:
    def test_returns_dict(self):
        result = detect_backends()
        assert isinstance(result, dict)
        # Should have at least the registered backends
        assert "claude_code" in result
        assert "opencode" in result

    def test_values_are_bools(self):
        result = detect_backends()
        for v in result.values():
            assert isinstance(v, bool)


class TestSetupPreservesRepoPath:
    """Regression: setup must not drop repo_path when rewriting config."""

    @pytest.fixture
    def config_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
        monkeypatch.setattr(
            "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
        )
        return tmp_path

    def test_non_interactive_preserves_repo_path(self, config_dir):
        save_config(
            Config(
                server_url="https://example.com",
                token="ahv_test123",
                backends={"claude_code": True},
                repo_path="/repo/keep",
            )
        )
        from agentshive.commands.setup import _run_non_interactive
        import argparse

        args = argparse.Namespace(
            server=None, token=None, no_interactive=True, check=False
        )
        existing = load_config()
        _run_non_interactive(args, existing)
        loaded = load_config()
        assert loaded.repo_path == "/repo/keep"
