//! Error types for the DataFusion OLAP backend.

use datafusion::error::DataFusionError;

/// Errors that can occur in the DataFusion OLAP backend.
///
/// This enum consolidates errors from DataFusion, Arrow, Vortex I/O, and
/// (when the `cloud-storage` feature is enabled) the `object_store` crate.
#[derive(Debug, thiserror::Error)]
pub enum DfOlapError {
    /// An error originating inside the DataFusion query engine.
    #[error("DataFusion error: {0}")]
    DataFusion(#[from] DataFusionError),

    /// An Arrow-level error (e.g. schema mismatch during array construction).
    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    /// A Vortex serialisation or deserialisation error.
    #[error("Vortex error: {0}")]
    Vortex(String),

    /// A query or DML statement referenced a table that has not been registered.
    #[error("table not found: {0}")]
    TableNotFound(String),

    /// The supplied data schema does not match the registered table schema.
    #[error("schema mismatch: {0}")]
    SchemaMismatch(String),

    /// A file-system I/O error (e.g. creating the table directory or writing a file).
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    /// A `tokio::task::JoinError` from a `spawn_blocking` call.
    #[error("task join error: {0}")]
    Join(String),

    /// An error from the `object_store` crate (cloud storage operations).
    ///
    /// Available on crate feature `cloud-storage` only.
    #[cfg(feature = "cloud-storage")]
    #[error("object store error: {0}")]
    ObjectStore(#[from] object_store::Error),

    /// A URL parse error encountered when constructing cloud storage URLs.
    ///
    /// Available on crate feature `cloud-storage` only.
    #[cfg(feature = "cloud-storage")]
    #[error("invalid URL: {0}")]
    UrlParse(#[from] url::ParseError),

    /// An unsupported or invalid storage URL/path.
    #[error("storage configuration error: {0}")]
    StorageConfig(String),

    /// A catch-all error for situations not covered by the other variants.
    #[error("{0}")]
    Other(String),
}

impl DfOlapError {
    /// Wrap a `tokio::task::JoinError` from `spawn_blocking`.
    pub(crate) fn from_join(e: tokio::task::JoinError) -> Self {
        Self::Join(e.to_string())
    }
}
