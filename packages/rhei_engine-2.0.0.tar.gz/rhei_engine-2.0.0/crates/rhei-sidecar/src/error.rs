//! Error types for the `rhei-sidecar` crate.

/// Errors produced by the sidecar CDC consumer and its dependencies.
#[derive(Debug, thiserror::Error)]
pub enum SidecarError {
    /// An error returned by the underlying `connector_arrow` query layer
    /// (e.g. SQL syntax error, connection failure, schema mismatch).
    #[error("connector error: {0}")]
    Connector(String),

    /// A Tokio `spawn_blocking` task was dropped before it could produce a
    /// result, typically because the runtime is shutting down.
    #[error("task join error: {0}")]
    Join(String),

    /// A [`crate::WatermarkStore`] operation (load or save) failed.
    ///
    /// When raised by [`crate::TimestampCdcConsumer::try_with_watermark_store`]
    /// at construction time it indicates a corrupt or inaccessible store.
    /// When raised during a poll cycle the consumer rolls back its in-memory
    /// watermark so the same rows will be re-fetched on the next poll.
    #[error("watermark store error: {0}")]
    WatermarkStore(String),

    /// A catch-all variant for errors that do not fit the other categories.
    #[error("{0}")]
    Other(String),
}

impl From<connector_arrow::ConnectorError> for SidecarError {
    fn from(e: connector_arrow::ConnectorError) -> Self {
        SidecarError::Connector(e.to_string())
    }
}
