//! Vortex storage cross-mode performance benchmark.
//!
//! Compares InMemory / Vortex-local / Vortex-S3 on the same sidecar workload
//! (SQLite → CDC → DataFusion, temporal mode). Surfaces the durability-vs-
//! throughput tradeoff so callers can pick a storage mode against their latency
//! and cost budget.
//!
//! Run (no S3):
//!   cargo bench -p rhei --all-features --bench vortex_storage_bench
//!
//! JSON output:
//!   RHEI_BENCH_JSON=vortex.json \
//!     cargo bench -p rhei --all-features --bench vortex_storage_bench
//!
//! With S3 (default prefix: s3://pixai-rec-sys/dev/rhei; override with
//! RHEI_BENCH_S3_URL):
//!   RHEI_TEST_S3=1 cargo bench -p rhei --all-features \
//!       --bench vortex_storage_bench

#![cfg(all(feature = "datafusion-backend", feature = "sidecar"))]

#[path = "bench_utils.rs"]
mod bench_utils;

use std::time::Instant;

use tempfile::TempDir;

use rhei::{StorageMode, SyncEngine};

use bench_utils::{
    build_engine, setup_sqlite_source, warmup, BenchReport, LatencyStats, ThroughputResult,
    MEASUREMENT_BASE_TS,
};

const WARMUP_CYCLES: usize = 5;
const STEADY_STATE_CYCLES: usize = 50;
const ROWS_PER_CYCLE: usize = 10;

// ---------------------------------------------------------------------------
// Storage-mode factory helpers
// ---------------------------------------------------------------------------

fn vortex_local(tmp: &TempDir, name: &str) -> StorageMode {
    let dir = tmp.path().join(name);
    std::fs::create_dir_all(&dir).unwrap();
    StorageMode::Vortex {
        url: dir.to_string_lossy().to_string(),
    }
}

fn vortex_s3() -> Option<StorageMode> {
    if std::env::var("RHEI_TEST_S3").is_err() {
        return None;
    }
    let base = std::env::var("RHEI_BENCH_S3_URL")
        .unwrap_or_else(|_| "s3://pixai-rec-sys/dev/rhei".to_string());
    let nonce = format!("vortex-bench-{}", std::process::id());
    Some(StorageMode::Vortex {
        url: format!("{}/{}", base.trim_end_matches('/'), nonce),
    })
}

// ---------------------------------------------------------------------------
// Bench 1: Steady-state latency per storage mode
// ---------------------------------------------------------------------------

async fn bench_steady_state(label: &str, storage: StorageMode, report: &mut BenchReport) {
    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("source.db");
    let ext_str = ext_path.to_str().unwrap();
    setup_sqlite_source(ext_str, 0);

    let (engine, _olap) = build_engine(ext_str, storage).await;
    let conn = rusqlite::Connection::open(ext_str).unwrap();

    warmup(&engine, &conn, WARMUP_CYCLES).await;

    let mut stats = LatencyStats::new(label);

    for cycle in 0..STEADY_STATE_CYCLES {
        // Measured rows live at ts >= MEASUREMENT_BASE_TS so they survive the
        // post-warmup watermark filter (`updated_at > warmup_max`).
        let base = MEASUREMENT_BASE_TS + (cycle * ROWS_PER_CYCLE) as i64 + 1;
        let tx = conn.unchecked_transaction().unwrap();
        for i in 0..ROWS_PER_CYCLE as i64 {
            let id = base + i;
            let ts = base + i;
            tx.execute(
                "INSERT INTO orders VALUES (?, ?, ?, ?, ?)",
                rusqlite::params![id, format!("c_{id}"), id * 3, ts, ts],
            )
            .unwrap();
        }
        tx.commit().unwrap();

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();
        assert!(result.events_processed >= ROWS_PER_CYCLE as u64);
        stats.record(elapsed);
    }

    stats.print();
    report.add_latency(&stats);
}

// ---------------------------------------------------------------------------
// Bench 2: Initial-sync throughput per storage mode
// ---------------------------------------------------------------------------

async fn bench_initial_sync(
    label: &str,
    storage: StorageMode,
    row_count: i64,
    report: &mut BenchReport,
) {
    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("source.db");
    let ext_str = ext_path.to_str().unwrap();
    setup_sqlite_source(ext_str, row_count);

    let (engine, _olap) = build_engine(ext_str, storage).await;

    let t = Instant::now();
    let result = engine.sync_once().await.unwrap();
    let elapsed = t.elapsed();

    let r = ThroughputResult {
        label: label.to_string(),
        rows: row_count,
        elapsed,
        events_processed: result.events_processed,
    };
    r.print();
    report.add_throughput(&r);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

#[tokio::main]
async fn main() {
    println!("\n{}", "=".repeat(72));
    println!("  Rhei Vortex Storage Cross-Mode Benchmark");
    println!("  Warmup: {WARMUP_CYCLES} cycles  |  Steady-state: {STEADY_STATE_CYCLES} cycles");
    println!("{}\n", "=".repeat(72));

    let mut report = BenchReport::new("vortex_storage");
    let tmp = TempDir::new().unwrap();

    let modes: Vec<(&str, StorageMode)> = {
        let mut v = vec![
            ("InMemory", StorageMode::InMemory),
            ("Vortex local", vortex_local(&tmp, "vortex-local")),
        ];
        if let Some(s3) = vortex_s3() {
            v.push(("Vortex S3-compatible", s3));
        } else {
            println!("(Vortex S3 skipped — set RHEI_TEST_S3=1 to include)\n");
        }
        v
    };

    // ------------------------------------------------------------------
    // Bench 1: Steady-state sync latency
    // ------------------------------------------------------------------
    println!("--- Bench 1: Steady-state Sync Latency ({STEADY_STATE_CYCLES} cycles, {ROWS_PER_CYCLE} rows each) ---\n");
    for (label, mode) in &modes {
        bench_steady_state(label, mode.clone(), &mut report).await;
    }

    // ------------------------------------------------------------------
    // Bench 2: Initial-sync throughput scaling
    // ------------------------------------------------------------------
    println!("\n--- Bench 2: Initial-sync Throughput Scaling ---\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}",
        "Label", "Rows", "Time", "Events/sec"
    );
    println!("  {:-<32} {:-<8}  {:-<10}  {:-<14}", "", "", "", "");

    for &count in &[1_000_i64, 10_000, 100_000] {
        for (label, mode) in &modes {
            let full_label = format!("{label} / {count}");
            bench_initial_sync(&full_label, mode.clone(), count, &mut report).await;
        }
        println!();
    }

    report.flush();
    println!("Done.");
}
