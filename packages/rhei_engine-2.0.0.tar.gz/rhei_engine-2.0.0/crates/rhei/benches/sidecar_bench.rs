//! Sidecar performance benchmark.
//!
//! Measures sync latency percentiles, throughput scaling, delete throughput,
//! mixed read/write concurrency, and peak memory across dataset sizes. Uses a
//! custom statistics harness (no Criterion dependency) with warmup cycles, full
//! percentile suite (p50/p95/p99), stddev, min/max, and optional JSON output.
//!
//! Run:
//!   cargo bench -p rhei --all-features --bench sidecar_bench
//!
//! JSON output (for CI regression tracking):
//!   RHEI_BENCH_JSON=results.json \
//!     cargo bench -p rhei --all-features --bench sidecar_bench
//!
//! With Docker Postgres (Bench 7):
//!   docker compose up -d
//!   RHEI_TEST_POSTGRES=1 cargo bench -p rhei --all-features --bench sidecar_bench
//!   docker compose down
//!
//! With a locally installed Postgres — no Docker required (Bench 8):
//!   RHEI_BENCH_PG_CONN='host=localhost user=postgres dbname=mydb' \
//!     cargo bench -p rhei --all-features --bench sidecar_bench
//!
//!   The bench creates table `rhei_bench_orders` and drops it on exit.
//!   If the process is killed mid-run, drop it manually:
//!     psql "$RHEI_BENCH_PG_CONN" -c "DROP TABLE IF EXISTS rhei_bench_orders"

#![cfg(all(feature = "datafusion-backend", feature = "sidecar"))]

#[path = "bench_utils.rs"]
mod bench_utils;

use std::sync::Arc;
use std::time::Instant;

use tempfile::TempDir;

use rhei::{DeleteDetection, OlapEngine, StorageMode, SyncEngine};

use bench_utils::{
    build_engine, build_engine_with, orders_schema, peak_rss_kb, setup_sqlite_source, warmup,
    BenchReport, LatencyStats, ThroughputResult,
};

const WARMUP_CYCLES: usize = 5;
const STEADY_STATE_CYCLES: usize = 50;
const ROWS_PER_CYCLE: usize = 10;

// ---------------------------------------------------------------------------
// Bench 1: Steady-state sync latency (INSERT / UPDATE / no-op)
// ---------------------------------------------------------------------------

async fn bench_latency(report: &mut BenchReport) {
    println!("--- Bench 1: Steady-state Sync Latency ({STEADY_STATE_CYCLES} cycles, {ROWS_PER_CYCLE} rows each) ---\n");

    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("bench1.db");
    let ext = ext_path.to_str().unwrap();
    setup_sqlite_source(ext, 0);

    let (engine, _olap) = build_engine(ext, StorageMode::InMemory).await;
    let src_conn = rusqlite::Connection::open(ext).unwrap();

    warmup(&engine, &src_conn, WARMUP_CYCLES).await;

    let mut insert_stats = LatencyStats::new("INSERT (10 rows/cycle)");
    let mut update_stats = LatencyStats::new("UPDATE (10 rows/cycle)");
    let mut noop_stats = LatencyStats::new("No-op sync");

    let mut insert_stmt = src_conn
        .prepare("INSERT INTO orders VALUES (?, ?, ?, ?, ?)")
        .unwrap();

    for cycle in 0..STEADY_STATE_CYCLES {
        let base_id = cycle as i64 * ROWS_PER_CYCLE as i64 + 1;
        let ts = 2000_i64 + cycle as i64;

        for i in 0..ROWS_PER_CYCLE as i64 {
            let id = base_id + i;
            insert_stmt
                .execute(rusqlite::params![id, format!("c_{id}"), id * 100, ts, ts])
                .unwrap();
        }
        let t = Instant::now();
        engine.sync_once().await.unwrap();
        insert_stats.record(t.elapsed());

        src_conn
            .execute(
                &format!(
                    "UPDATE orders SET amount = amount + 1, updated_at = {} \
                     WHERE id BETWEEN {} AND {}",
                    ts + 1000,
                    base_id,
                    base_id + ROWS_PER_CYCLE as i64 - 1
                ),
                [],
            )
            .unwrap();
        let t = Instant::now();
        engine.sync_once().await.unwrap();
        update_stats.record(t.elapsed());

        let t = Instant::now();
        engine.sync_once().await.unwrap();
        noop_stats.record(t.elapsed());
    }

    insert_stats.print();
    update_stats.print();
    noop_stats.print();

    report.add_latency(&insert_stats);
    report.add_latency(&update_stats);
    report.add_latency(&noop_stats);
}

// ---------------------------------------------------------------------------
// Bench 2: Initial-sync throughput scaling
// ---------------------------------------------------------------------------

async fn bench_initial_sync_throughput(report: &mut BenchReport) {
    println!("\n--- Bench 2: Initial-sync Throughput Scaling ---\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}  {:>10}",
        "Label", "Rows", "Time", "Events/sec", "RSS (KB)"
    );
    println!(
        "  {:-<32} {:-<8}  {:-<10}  {:-<14}  {:-<10}",
        "", "", "", "", ""
    );

    for &row_count in &[1_000_i64, 10_000, 50_000, 100_000] {
        let tmp = TempDir::new().unwrap();
        let ext_path = tmp.path().join("bench2.db");
        let ext = ext_path.to_str().unwrap();
        setup_sqlite_source(ext, row_count);

        let (engine, _olap) = build_engine(ext, StorageMode::InMemory).await;

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();
        let rss = peak_rss_kb().unwrap_or(0);

        let r = ThroughputResult {
            label: format!("initial-sync-{row_count}"),
            rows: row_count,
            elapsed,
            events_processed: result.events_processed,
        };
        println!(
            "  {:<32} {:>8}  {:>10.3?}  ({:>10.0} /s)  {:>8} KB",
            r.label,
            r.rows,
            r.elapsed,
            r.rows_per_sec(),
            rss
        );
        report.add_throughput(&r);
    }
}

// ---------------------------------------------------------------------------
// Bench 3: Update throughput + OLAP row count (temporal versioning)
// ---------------------------------------------------------------------------

async fn bench_update_throughput(report: &mut BenchReport) {
    println!("\n--- Bench 3: Update Throughput (temporal versioning) ---\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}  {:>12}",
        "Label", "Updates", "Time", "Events/sec", "OLAP rows"
    );
    println!(
        "  {:-<32} {:-<8}  {:-<10}  {:-<14}  {:-<12}",
        "", "", "", "", ""
    );

    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("bench3.db");
    let ext = ext_path.to_str().unwrap();
    setup_sqlite_source(ext, 1_000);

    let (engine, olap) = build_engine(ext, StorageMode::InMemory).await;
    engine.sync_once().await.unwrap();

    let src_conn = rusqlite::Connection::open(ext).unwrap();

    for &update_count in &[100_i64, 500, 1_000] {
        src_conn
            .execute(
                &format!(
                    "UPDATE orders SET amount = amount + 1, updated_at = {} \
                     WHERE id BETWEEN 1 AND {}",
                    5000 + update_count,
                    update_count
                ),
                [],
            )
            .unwrap();

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();

        let batches = olap.query("SELECT COUNT(*) FROM orders").await.unwrap();
        let total_rows = batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<arrow::array::Int64Array>()
            .unwrap()
            .value(0);

        let r = ThroughputResult {
            label: format!("update-{update_count}"),
            rows: update_count,
            elapsed,
            events_processed: result.events_processed,
        };
        println!(
            "  {:<32} {:>8}  {:>10.3?}  ({:>10.0} /s)  {:>10}",
            r.label,
            r.rows,
            r.elapsed,
            r.rows_per_sec(),
            total_rows
        );
        report.add_throughput(&r);
    }
}

// ---------------------------------------------------------------------------
// Bench 4: Delete throughput (temporal tombstones)
// ---------------------------------------------------------------------------

async fn bench_delete_throughput(report: &mut BenchReport) {
    println!("\n--- Bench 4: Delete Throughput (temporal tombstones) ---\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}  {:>12}",
        "Label", "Deletes", "Time", "Events/sec", "OLAP rows"
    );
    println!(
        "  {:-<32} {:-<8}  {:-<10}  {:-<14}  {:-<12}",
        "", "", "", "", ""
    );

    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("bench4.db");
    let ext = ext_path.to_str().unwrap();
    setup_sqlite_source(ext, 1_000);

    // Hard `DELETE` on the source — surface those as CDC delete events via
    // a per-cycle full-diff scan. Without this the consumer's
    // `DeleteDetection::Disabled` (the default) silently drops the deletes
    // and the bench would report meaningless near-zero sync timings.
    let (engine, olap) = build_engine_with(
        ext,
        StorageMode::InMemory,
        DeleteDetection::FullDiff { every_n_cycles: 1 },
    )
    .await;
    engine.sync_once().await.unwrap();

    let src_conn = rusqlite::Connection::open(ext).unwrap();
    let mut deleted_so_far = 0_i64;

    for &delete_count in &[50_i64, 200, 500] {
        let from_id = deleted_so_far + 1;
        let to_id = deleted_so_far + delete_count;
        src_conn
            .execute(
                &format!("DELETE FROM orders WHERE id BETWEEN {from_id} AND {to_id}"),
                [],
            )
            .unwrap();
        deleted_so_far += delete_count;

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();

        let batches = olap.query("SELECT COUNT(*) FROM orders").await.unwrap();
        let total_rows = batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<arrow::array::Int64Array>()
            .unwrap()
            .value(0);

        let r = ThroughputResult {
            label: format!("delete-{delete_count}"),
            rows: delete_count,
            elapsed,
            events_processed: result.events_processed,
        };
        println!(
            "  {:<32} {:>8}  {:>10.3?}  ({:>10.0} /s)  {:>10}",
            r.label,
            r.rows,
            r.elapsed,
            r.rows_per_sec(),
            total_rows
        );
        report.add_throughput(&r);
    }
}

// ---------------------------------------------------------------------------
// Bench 5: Mixed read/write concurrency (HTAP)
// ---------------------------------------------------------------------------
//
// Runs concurrent analytical queries against the OLAP backend while the sync
// engine is continuously ingesting new rows.  Measures both sync latency and
// query latency under load to expose head-of-line blocking.

async fn bench_mixed_concurrency(report: &mut BenchReport) {
    println!("\n--- Bench 5: Mixed Read/Write Concurrency (HTAP) ---\n");

    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("bench5.db");
    let ext_str = ext_path.to_str().unwrap().to_string();
    setup_sqlite_source(&ext_str, 500);

    let (engine, olap) = build_engine(&ext_str, StorageMode::InMemory).await;

    // Seed OLAP before the mixed phase.
    engine.sync_once().await.unwrap();

    let src_conn = rusqlite::Connection::open(&ext_str).unwrap();

    let mut sync_stats = LatencyStats::new("sync (under query load)");
    let mut query_stats = LatencyStats::new("COUNT(*) query (under sync)");

    const MIXED_CYCLES: usize = 30;
    const MIXED_ROWS: usize = 20;

    for cycle in 0..MIXED_CYCLES {
        let base_id = 600_i64 + cycle as i64 * MIXED_ROWS as i64;
        let ts = 10_000_i64 + cycle as i64;

        // Insert new rows into the source.
        let tx = src_conn.unchecked_transaction().unwrap();
        for i in 0..MIXED_ROWS as i64 {
            let id = base_id + i;
            tx.execute(
                "INSERT INTO orders VALUES (?, ?, ?, ?, ?)",
                rusqlite::params![id, format!("mx_{id}"), id, ts, ts],
            )
            .unwrap();
        }
        tx.commit().unwrap();

        // Fire sync and a concurrent analytical query in parallel.
        let olap_q = olap.clone();
        let engine_c = Arc::clone(&engine);

        let (sync_res, query_res) = tokio::join!(
            async {
                let t = Instant::now();
                let r = engine_c.sync_once().await.unwrap();
                (t.elapsed(), r)
            },
            async {
                let t = Instant::now();
                let b = olap_q
                    .query("SELECT COUNT(*), SUM(amount) FROM orders WHERE _rhei_valid_to IS NULL")
                    .await
                    .unwrap();
                (t.elapsed(), b)
            }
        );

        sync_stats.record(sync_res.0);
        query_stats.record(query_res.0);
    }

    sync_stats.print();
    query_stats.print();

    report.add_latency(&sync_stats);
    report.add_latency(&query_stats);
}

// ---------------------------------------------------------------------------
// Bench 6: Analytical query throughput (post-sync)
// ---------------------------------------------------------------------------

async fn bench_query_throughput(report: &mut BenchReport) {
    println!("\n--- Bench 6: Analytical Query Throughput (post-sync, 100k rows) ---\n");

    let tmp = TempDir::new().unwrap();
    let ext_path = tmp.path().join("bench6.db");
    let ext = ext_path.to_str().unwrap();
    setup_sqlite_source(ext, 100_000);

    let (engine, olap) = build_engine(ext, StorageMode::InMemory).await;
    engine.sync_once().await.unwrap();

    let queries: &[(&str, &str)] = &[
        ("full-scan COUNT", "SELECT COUNT(*) FROM orders"),
        (
            "GROUP BY customer",
            "SELECT customer, SUM(amount) FROM orders GROUP BY customer LIMIT 100",
        ),
        (
            "filtered scan",
            "SELECT * FROM orders WHERE amount > 50000 AND _rhei_valid_to IS NULL LIMIT 1000",
        ),
        (
            "point-in-time snapshot",
            "SELECT COUNT(*) FROM orders WHERE _rhei_valid_from <= 50000 \
             AND (_rhei_valid_to IS NULL OR _rhei_valid_to > 50000)",
        ),
    ];

    const QUERY_REPS: usize = 10;

    for (label, sql) in queries {
        let mut stats = LatencyStats::new(*label);
        // warmup
        for _ in 0..3 {
            let _ = olap.query(sql).await;
        }
        for _ in 0..QUERY_REPS {
            let t = Instant::now();
            olap.query(sql).await.unwrap();
            stats.record(t.elapsed());
        }
        stats.print();
        report.add_latency(&stats);
    }
}

// ---------------------------------------------------------------------------
// Bench 7: Postgres (optional)
// ---------------------------------------------------------------------------

async fn bench_postgres(report: &mut BenchReport) {
    if std::env::var("RHEI_TEST_POSTGRES").is_err() {
        println!("\n--- Bench 7: Postgres (SKIPPED — set RHEI_TEST_POSTGRES=1) ---");
        return;
    }

    println!("\n--- Bench 7: Postgres Throughput Scaling ---\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}",
        "Label", "Rows", "Time", "Events/sec"
    );
    println!("  {:-<32} {:-<8}  {:-<10}  {:-<14}", "", "", "", "");

    use rhei::{
        CdcSyncEngine, DataFusionEngine, SchemaRegistry, SharedDataFusionEngine, SyncMode,
        TimestampCdcConfig, TimestampCdcConsumer, TimestampTableConfig,
    };

    for &row_count in &[100_i64, 1_000, 5_000] {
        let consumer = tokio::task::spawn_blocking(move || {
            use connector_arrow::postgres::PostgresConnection;
            use postgres::{Client, NoTls};

            let mut client = Client::connect(
                "host=localhost port=5432 user=rhei password=rhei_test dbname=rhei_test",
                NoTls,
            )
            .unwrap();
            client
                .batch_execute(
                    "DROP TABLE IF EXISTS orders;
                     CREATE TABLE orders (
                         id BIGINT PRIMARY KEY,
                         customer TEXT NOT NULL,
                         amount BIGINT NOT NULL,
                         created_at BIGINT NOT NULL,
                         updated_at BIGINT NOT NULL
                     )",
                )
                .unwrap();
            let stmt = client
                .prepare("INSERT INTO orders VALUES ($1, $2, $3, $4, $4)")
                .unwrap();
            for i in 1..=row_count {
                client
                    .execute(&stmt, &[&i, &format!("cust_{i}"), &(i * 100), &(1000 + i)])
                    .unwrap();
            }
            let pg_conn = PostgresConnection::new(client);
            TimestampCdcConsumer::new(
                pg_conn,
                TimestampCdcConfig {
                    tables: vec![TimestampTableConfig {
                        table_name: "orders".into(),
                        created_at_column: "created_at".into(),
                        updated_at_column: "updated_at".into(),
                        primary_key: vec!["id".into()],
                        columns: vec![],
                    }],
                    poll_batch_size: 100_000,
                    delete_detection: rhei::DeleteDetection::Disabled,
                },
            )
        })
        .await
        .unwrap();

        let olap = SharedDataFusionEngine::new(DataFusionEngine::new());
        let registry = SchemaRegistry::new();
        registry.register(orders_schema()).unwrap();
        let temporal_schema = rhei::temporalize_schema(&orders_schema().arrow_schema);
        olap.create_table("orders", &temporal_schema, &orders_schema().primary_key)
            .await
            .unwrap();
        let engine = Arc::new(
            CdcSyncEngine::new(consumer, olap.clone(), registry, 100_000)
                .with_sync_mode(SyncMode::Temporal),
        );

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();
        let r = ThroughputResult {
            label: format!("postgres-{row_count}"),
            rows: row_count,
            elapsed,
            events_processed: result.events_processed,
        };
        r.print();
        report.add_throughput(&r);

        tokio::task::spawn_blocking(move || drop(engine))
            .await
            .unwrap();
    }

    tokio::task::spawn_blocking(|| {
        use postgres::{Client, NoTls};
        let mut client = Client::connect(
            "host=localhost port=5432 user=rhei password=rhei_test dbname=rhei_test",
            NoTls,
        )
        .unwrap();
        client.batch_execute("DROP TABLE IF EXISTS orders").unwrap();
    })
    .await
    .unwrap();
}

// ---------------------------------------------------------------------------
// Bench 8: Local Postgres (no Docker)
// ---------------------------------------------------------------------------
//
// Triggered by RHEI_BENCH_PG_CONN=<connstr>. Uses a dedicated table
// `rhei_bench_orders` (never touches any existing table). Cleanup is
// guaranteed via a Drop guard even if the benchmark panics.

const PG_BENCH_TABLE: &str = "rhei_bench_orders";

fn pg_bench_schema() -> rhei::TableSchema {
    use arrow::datatypes::{DataType, Field, Schema};
    use std::sync::Arc as StdArc;
    rhei::TableSchema::new(
        PG_BENCH_TABLE,
        StdArc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("customer", DataType::Utf8, false),
            Field::new("amount", DataType::Int64, false),
            Field::new("created_at", DataType::Int64, false),
            Field::new("updated_at", DataType::Int64, false),
        ])),
        vec!["id".into()],
    )
}

/// Drops `rhei_bench_orders` from Postgres on `Drop`, blocking the calling
/// thread. Safe to use from both sync and async contexts in benchmarks.
struct PgTableGuard {
    conn_str: String,
}

impl Drop for PgTableGuard {
    fn drop(&mut self) {
        // Covers two cases:
        //   1. Normal function exit — _guard drops at the end of bench_postgres_local.
        //   2. Ctrl+C via tokio::select! in main — select! drops the running future
        //      synchronously before entering the signal arm, so this fires before
        //      any post-select! code runs.
        //
        // Does NOT cover SIGTERM / SIGKILL (no unwinding), or panics in bench
        // builds (profile.release has panic = "abort", which bench inherits).
        // Those cases fall back to the manual psql one-liner in the module doc.
        //
        // Blocks the calling thread briefly (one connect + one DDL statement).
        // Acceptable here because the benchmark is either completing or exiting.
        use postgres::{Client, NoTls};
        match Client::connect(&self.conn_str, NoTls) {
            Ok(mut c) => {
                if let Err(e) = c.batch_execute(&format!("DROP TABLE IF EXISTS {PG_BENCH_TABLE}")) {
                    eprintln!("  Cleanup WARNING: could not drop {PG_BENCH_TABLE}: {e}");
                } else {
                    println!("  Cleanup: {PG_BENCH_TABLE} dropped.");
                }
            }
            Err(e) => {
                eprintln!("  Cleanup WARNING: could not connect to Postgres for cleanup: {e}")
            }
        }
    }
}

/// Mask `password=…` tokens (key=value style) and `:password@` (URI style).
fn mask_pg_password(s: &str) -> String {
    // URI: postgres://user:password@host/db  →  postgres://user:***@host/db
    let s = if let Some(at) = s.find('@') {
        if let Some(colon) = s[..at].rfind(':') {
            if s[..colon].contains("://") {
                format!("{}:***{}", &s[..colon], &s[at..])
            } else {
                s.to_string()
            }
        } else {
            s.to_string()
        }
    } else {
        s.to_string()
    };
    // Key=value: password=secret  →  password=***
    s.split_whitespace()
        .map(|tok| {
            if tok.to_lowercase().starts_with("password=") {
                "password=***".to_string()
            } else {
                tok.to_string()
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

async fn bench_postgres_local(report: &mut BenchReport) {
    let conn_str = match std::env::var("RHEI_BENCH_PG_CONN") {
        Ok(s) => s,
        Err(_) => {
            println!(
                "\n--- Bench 8: Local Postgres (SKIPPED) ---\
                 \n    Set RHEI_BENCH_PG_CONN='host=localhost user=postgres dbname=mydb' to enable."
            );
            return;
        }
    };

    println!("\n--- Bench 8: Local Postgres Throughput Scaling (no Docker) ---\n");
    println!("  Connection : {}", mask_pg_password(&conn_str));
    println!("  Table      : {PG_BENCH_TABLE}  (dropped on completion)\n");
    println!(
        "  {:<32} {:>8}  {:>10}  {:>14}",
        "Label", "Rows", "Time", "Events/sec"
    );
    println!("  {:-<32} {:-<8}  {:-<10}  {:-<14}", "", "", "", "");

    use rhei::{
        CdcSyncEngine, DataFusionEngine, SchemaRegistry, SharedDataFusionEngine, SyncMode,
        TimestampCdcConfig, TimestampCdcConsumer, TimestampTableConfig,
    };

    // Guard ensures DROP TABLE even if a sync panics.
    let _guard = PgTableGuard {
        conn_str: conn_str.clone(),
    };

    for &row_count in &[100_i64, 1_000, 5_000] {
        let cs = conn_str.clone();
        let consumer = tokio::task::spawn_blocking(move || {
            use connector_arrow::postgres::PostgresConnection;
            use postgres::{Client, NoTls};

            let mut client = Client::connect(&cs, NoTls).unwrap();
            client
                .batch_execute(&format!(
                    "DROP TABLE IF EXISTS {PG_BENCH_TABLE};
                     CREATE TABLE {PG_BENCH_TABLE} (
                         id BIGINT PRIMARY KEY,
                         customer TEXT NOT NULL,
                         amount BIGINT NOT NULL,
                         created_at BIGINT NOT NULL,
                         updated_at BIGINT NOT NULL
                     )"
                ))
                .unwrap();
            let stmt = client
                .prepare(&format!(
                    "INSERT INTO {PG_BENCH_TABLE} VALUES ($1, $2, $3, $4, $4)"
                ))
                .unwrap();
            for i in 1..=row_count {
                client
                    .execute(&stmt, &[&i, &format!("cust_{i}"), &(i * 100), &(1000 + i)])
                    .unwrap();
            }
            let pg_conn = PostgresConnection::new(client);
            TimestampCdcConsumer::new(
                pg_conn,
                TimestampCdcConfig {
                    tables: vec![TimestampTableConfig {
                        table_name: PG_BENCH_TABLE.into(),
                        created_at_column: "created_at".into(),
                        updated_at_column: "updated_at".into(),
                        primary_key: vec!["id".into()],
                        columns: vec![],
                    }],
                    poll_batch_size: 100_000,
                    delete_detection: rhei::DeleteDetection::Disabled,
                },
            )
        })
        .await
        .unwrap();

        let schema = pg_bench_schema();
        let olap = SharedDataFusionEngine::new(DataFusionEngine::new());
        let registry = SchemaRegistry::new();
        registry.register(pg_bench_schema()).unwrap();
        let temporal_schema = rhei::temporalize_schema(&schema.arrow_schema);
        olap.create_table(PG_BENCH_TABLE, &temporal_schema, &schema.primary_key)
            .await
            .unwrap();
        let engine = Arc::new(
            CdcSyncEngine::new(consumer, olap.clone(), registry, 100_000)
                .with_sync_mode(SyncMode::Temporal),
        );

        let t = Instant::now();
        let result = engine.sync_once().await.unwrap();
        let elapsed = t.elapsed();
        let r = ThroughputResult {
            label: format!("local-pg-{row_count}"),
            rows: row_count,
            elapsed,
            events_processed: result.events_processed,
        };
        r.print();
        report.add_throughput(&r);

        tokio::task::spawn_blocking(move || drop(engine))
            .await
            .unwrap();
    }

    // _guard drops here → DROP TABLE IF EXISTS rhei_bench_orders
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async fn run_all_benches(report: &mut BenchReport) {
    bench_latency(report).await;
    bench_initial_sync_throughput(report).await;
    bench_update_throughput(report).await;
    bench_delete_throughput(report).await;
    bench_mixed_concurrency(report).await;
    bench_query_throughput(report).await;
    bench_postgres(report).await;
    bench_postgres_local(report).await;
}

#[tokio::main]
async fn main() {
    println!("\n{}", "=".repeat(72));
    println!("  Rhei Sidecar Performance Benchmark");
    println!("  Warmup: {WARMUP_CYCLES} cycles  |  Steady-state: {STEADY_STATE_CYCLES} cycles");
    println!("{}\n", "=".repeat(72));

    let rss_start = peak_rss_kb();
    let mut report = BenchReport::new("sidecar");

    // Race all benchmarks against Ctrl+C.  When the signal fires, select!
    // drops run_all_benches synchronously — which drops PgTableGuard and
    // triggers the blocking DROP TABLE — before entering the signal arm.
    let interrupted = tokio::select! {
        _ = run_all_benches(&mut report) => false,
        _ = tokio::signal::ctrl_c() => true,
    };

    if interrupted {
        eprintln!("\nInterrupted (Ctrl+C) — database cleanup complete.");
    }

    let rss_end = peak_rss_kb();
    println!("\n--- Resource Summary ---");
    if let (Some(start), Some(end)) = (rss_start, rss_end) {
        println!("  Peak RSS start : {start} KB");
        println!("  Peak RSS end   : {end} KB");
        println!("  Delta          : {} KB", end.saturating_sub(start));
    }

    report.flush();
    println!("\nDone.\n");
}
