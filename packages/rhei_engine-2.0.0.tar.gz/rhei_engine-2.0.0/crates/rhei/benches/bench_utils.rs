//! Shared utilities for Rhei benchmarks.
//!
//! Provides `LatencyStats`, `ThroughputResult`, schema/source helpers,
//! engine builder, warmup, RSS helper, and optional JSON report output
//! (`RHEI_BENCH_JSON=path/to/output.json`).

#![allow(dead_code)]

use std::sync::Arc;
use std::time::Duration;

use arrow::datatypes::{DataType, Field, Schema};
use serde_json::{json, Value};

use rhei::{
    CdcSyncEngine, DataFusionEngine, DeleteDetection, OlapEngine, SchemaRegistry,
    SharedDataFusionEngine, StorageMode, SyncEngine, SyncMode, TableSchema, TimestampCdcConfig,
    TimestampCdcConsumer, TimestampTableConfig,
};

// ---------------------------------------------------------------------------
// Schema + source helpers
// ---------------------------------------------------------------------------

pub fn orders_schema() -> TableSchema {
    TableSchema::new(
        "orders",
        Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("customer", DataType::Utf8, false),
            Field::new("amount", DataType::Int64, false),
            Field::new("created_at", DataType::Int64, false),
            Field::new("updated_at", DataType::Int64, false),
        ])),
        vec!["id".into()],
    )
}

pub fn setup_sqlite_source(path: &str, row_count: i64) {
    let conn = rusqlite::Connection::open(path).unwrap();
    conn.execute_batch(
        "CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            customer TEXT NOT NULL,
            amount INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )",
    )
    .unwrap();
    if row_count == 0 {
        return;
    }
    let tx = conn.unchecked_transaction().unwrap();
    let mut stmt = tx
        .prepare("INSERT INTO orders VALUES (?, ?, ?, ?, ?)")
        .unwrap();
    for i in 1..=row_count {
        stmt.execute(rusqlite::params![
            i,
            format!("customer_{i}"),
            (i % 10_000) * 7,
            i,
            i
        ])
        .unwrap();
    }
    drop(stmt);
    tx.commit().unwrap();
}

// ---------------------------------------------------------------------------
// Engine builder
// ---------------------------------------------------------------------------

pub type SqliteEngine = CdcSyncEngine<
    TimestampCdcConsumer<connector_arrow::rusqlite::SQLiteConnection>,
    SharedDataFusionEngine,
>;

pub async fn build_engine(
    ext_path: &str,
    storage: StorageMode,
) -> (Arc<SqliteEngine>, SharedDataFusionEngine) {
    build_engine_with(ext_path, storage, DeleteDetection::Disabled).await
}

/// Same as [`build_engine`] but lets the caller pick a [`DeleteDetection`]
/// mode. Used by benches that measure delete-throughput on a hard-DELETE
/// source (default `Disabled` would silently drop those events).
pub async fn build_engine_with(
    ext_path: &str,
    storage: StorageMode,
    delete_detection: DeleteDetection,
) -> (Arc<SqliteEngine>, SharedDataFusionEngine) {
    let raw = connector_arrow::rusqlite::rusqlite::Connection::open(ext_path).unwrap();
    let sqlite_conn = connector_arrow::rusqlite::SQLiteConnection::new(raw);

    let consumer = TimestampCdcConsumer::new(
        sqlite_conn,
        TimestampCdcConfig {
            tables: vec![TimestampTableConfig {
                table_name: "orders".into(),
                created_at_column: "created_at".into(),
                updated_at_column: "updated_at".into(),
                primary_key: vec!["id".into()],
                columns: vec![],
            }],
            poll_batch_size: 100_000,
            delete_detection,
        },
    );

    let df = DataFusionEngine::with_storage(storage).expect("DataFusionEngine::with_storage");
    let olap = SharedDataFusionEngine::new(df);
    let registry = SchemaRegistry::new();
    registry.register(orders_schema()).unwrap();

    let temporal_schema = rhei::temporalize_schema(&orders_schema().arrow_schema);
    olap.create_table("orders", &temporal_schema, &orders_schema().primary_key)
        .await
        .unwrap();

    let engine = Arc::new(
        CdcSyncEngine::new(consumer, olap.clone(), registry, 100_000)
            .with_sync_mode(SyncMode::Temporal),
    );

    (engine, olap)
}

// ---------------------------------------------------------------------------
// Warmup
// ---------------------------------------------------------------------------

/// Lowest `updated_at` value benchmark *measured* phases should use.
///
/// The CDC consumer's table watermark initialises at `0` and polls with
/// `WHERE updated_at > watermark`. So warmup rows must use ts in
/// `1..MEASUREMENT_BASE_TS` (visible to CDC, watermark ends below this);
/// measured rows must use ts `>= MEASUREMENT_BASE_TS` so they survive the
/// `> watermark` filter after warmup has advanced it.
///
/// `1_000` is well above any realistic `WARMUP_CYCLES` (we use 5).
pub const MEASUREMENT_BASE_TS: i64 = 1_000;

/// Run `cycles` sync iterations without recording to warm up caches.
///
/// **Timestamp invariant.** The CDC consumer starts table watermarks at
/// `0` and polls `WHERE updated_at > watermark`. Warmup must:
///
/// 1. Use `updated_at >= 1` so warmup rows are visible to CDC — the
///    engine then exercises the row-processing hot path (JIT-compiles
///    code, primes page caches, spins tokio worker threads). Negative
///    or zero ts would be silently filtered, making warmup a no-op for
///    CDC ingestion and leaving cold-start cost on the first measured
///    iteration.
///
/// 2. Use `updated_at < MEASUREMENT_BASE_TS` so the watermark ends well
///    below where measured-phase rows begin — measured rows then survive
///    the `> watermark` filter.
///
/// IDs use a high range (`900_000 + i`) to avoid PK collisions with
/// measured-phase IDs that typically start at 1.
pub async fn warmup(engine: &Arc<SqliteEngine>, src_conn: &rusqlite::Connection, cycles: usize) {
    assert!(
        (cycles as i64) < MEASUREMENT_BASE_TS,
        "warmup cycles ({cycles}) must be < MEASUREMENT_BASE_TS ({MEASUREMENT_BASE_TS})"
    );
    for i in 0..cycles {
        let id = 900_000_i64 + i as i64;
        let ts = (i + 1) as i64; // 1..=cycles, strictly above watermark 0
        src_conn
            .execute(
                "INSERT OR REPLACE INTO orders VALUES (?, 'warmup', 0, ?, ?)",
                rusqlite::params![id, ts, ts],
            )
            .unwrap();
        // Unwrap — a failed warmup sync would leave the engine in an
        // unknown state and produce misleading downstream numbers.
        engine.sync_once().await.unwrap();
    }
}

// ---------------------------------------------------------------------------
// LatencyStats
// ---------------------------------------------------------------------------

pub struct LatencyStats {
    pub label: String,
    pub samples: Vec<Duration>,
}

impl LatencyStats {
    pub fn new(label: impl Into<String>) -> Self {
        Self {
            label: label.into(),
            samples: Vec::new(),
        }
    }

    pub fn record(&mut self, d: Duration) {
        self.samples.push(d);
    }

    pub fn len(&self) -> usize {
        self.samples.len()
    }

    pub fn is_empty(&self) -> bool {
        self.samples.is_empty()
    }

    pub fn percentile(&self, p: f64) -> Duration {
        if self.samples.is_empty() {
            return Duration::ZERO;
        }
        let mut s = self.samples.clone();
        s.sort();
        let idx = ((p / 100.0) * (s.len() as f64 - 1.0)).round() as usize;
        s[idx.min(s.len() - 1)]
    }

    pub fn mean(&self) -> Duration {
        if self.samples.is_empty() {
            return Duration::ZERO;
        }
        self.samples.iter().sum::<Duration>() / self.samples.len() as u32
    }

    pub fn min(&self) -> Duration {
        self.samples.iter().copied().min().unwrap_or(Duration::ZERO)
    }

    pub fn max(&self) -> Duration {
        self.samples.iter().copied().max().unwrap_or(Duration::ZERO)
    }

    pub fn stddev(&self) -> Duration {
        if self.samples.len() < 2 {
            return Duration::ZERO;
        }
        let mean_ns = self.mean().as_nanos() as f64;
        let variance = self
            .samples
            .iter()
            .map(|d| {
                let diff = d.as_nanos() as f64 - mean_ns;
                diff * diff
            })
            .sum::<f64>()
            / (self.samples.len() - 1) as f64;
        Duration::from_nanos(variance.sqrt() as u64)
    }

    pub fn print(&self) {
        println!(
            "  {:<32} mean={:>9.3?}  p50={:>9.3?}  p95={:>9.3?}  p99={:>9.3?}  \
             min={:>9.3?}  max={:>9.3?}  stddev={:>9.3?}  n={}",
            self.label,
            self.mean(),
            self.percentile(50.0),
            self.percentile(95.0),
            self.percentile(99.0),
            self.min(),
            self.max(),
            self.stddev(),
            self.samples.len(),
        );
    }

    pub fn to_json(&self) -> Value {
        json!({
            "label": self.label,
            "n": self.samples.len(),
            "mean_us":   self.mean().as_micros(),
            "p50_us":    self.percentile(50.0).as_micros(),
            "p95_us":    self.percentile(95.0).as_micros(),
            "p99_us":    self.percentile(99.0).as_micros(),
            "min_us":    self.min().as_micros(),
            "max_us":    self.max().as_micros(),
            "stddev_us": self.stddev().as_micros(),
        })
    }
}

// ---------------------------------------------------------------------------
// ThroughputResult
// ---------------------------------------------------------------------------

pub struct ThroughputResult {
    pub label: String,
    pub rows: i64,
    pub elapsed: Duration,
    pub events_processed: u64,
}

impl ThroughputResult {
    pub fn rows_per_sec(&self) -> f64 {
        self.events_processed as f64 / self.elapsed.as_secs_f64()
    }

    pub fn print(&self) {
        let drift = self.rows - self.events_processed as i64;
        let drift_note = if drift == 0 {
            String::new()
        } else {
            format!("  ⚠ synced {}/{}", self.events_processed, self.rows)
        };
        println!(
            "  {:<32} {:>8} rows  {:>10.3?}  ({:>10.0} rows/s){}",
            self.label,
            self.rows,
            self.elapsed,
            self.rows_per_sec(),
            drift_note,
        );
    }

    pub fn to_json(&self) -> Value {
        json!({
            "label": self.label,
            "rows": self.rows,
            "elapsed_ms": self.elapsed.as_millis(),
            "events_processed": self.events_processed,
            "rows_per_sec": self.rows_per_sec() as u64,
        })
    }
}

// ---------------------------------------------------------------------------
// BenchReport — JSON output
// ---------------------------------------------------------------------------

pub struct BenchReport {
    pub suite: String,
    pub latency: Vec<Value>,
    pub throughput: Vec<Value>,
}

impl BenchReport {
    pub fn new(suite: impl Into<String>) -> Self {
        Self {
            suite: suite.into(),
            latency: Vec::new(),
            throughput: Vec::new(),
        }
    }

    pub fn add_latency(&mut self, s: &LatencyStats) {
        self.latency.push(s.to_json());
    }

    pub fn add_throughput(&mut self, r: &ThroughputResult) {
        self.throughput.push(r.to_json());
    }

    /// Write JSON to `RHEI_BENCH_JSON` env var path. No-op if unset.
    pub fn flush(&self) {
        let Ok(path) = std::env::var("RHEI_BENCH_JSON") else {
            return;
        };
        let unix_secs = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let v = json!({
            "suite": self.suite,
            "timestamp_unix": unix_secs,
            "latency": self.latency,
            "throughput": self.throughput,
        });
        match std::fs::write(&path, serde_json::to_string_pretty(&v).unwrap()) {
            Ok(()) => println!("\n  Results written to {path}"),
            Err(e) => eprintln!("RHEI_BENCH_JSON: failed to write {path}: {e}"),
        }
    }
}

// ---------------------------------------------------------------------------
// RSS helper
// ---------------------------------------------------------------------------

pub fn peak_rss_kb() -> Option<u64> {
    std::fs::read_to_string("/proc/self/status")
        .ok()?
        .lines()
        .find(|l| l.starts_with("VmHWM:"))
        .and_then(|l| l.split_whitespace().nth(1))
        .and_then(|v| v.parse().ok())
}
