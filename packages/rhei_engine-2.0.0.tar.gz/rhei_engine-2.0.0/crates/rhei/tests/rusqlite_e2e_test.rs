//! E2E tests for the Rusqlite OLTP backend.
//!
//! Exercises the same HTAP pipeline as htap_e2e_test.rs.
//! Gated behind the `datafusion-backend` feature.

#![cfg(feature = "datafusion-backend")]

use std::sync::Arc;
use std::time::Instant;

use arrow::array::{Float64Array, Int64Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use tempfile::TempDir;

use rhei::{HtapConfig, HtapEngine, OlapEngine, TableSchema};

fn users_schema() -> TableSchema {
    TableSchema::new(
        "users",
        Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("name", DataType::Utf8, true),
            Field::new("age", DataType::Int64, true),
        ])),
        vec!["id".to_string()],
    )
}

async fn make_rusqlite_engine(tmp: &TempDir) -> HtapEngine {
    let config = HtapConfig {
        oltp_path: tmp
            .path()
            .join("rusqlite_e2e.db")
            .to_str()
            .unwrap()
            .to_string(),
        ..Default::default()
    };
    HtapEngine::new(config).await.unwrap()
}

async fn olap_count(engine: &HtapEngine, table: &str) -> i64 {
    let batches = engine
        .olap()
        .query(&format!("SELECT COUNT(*) FROM {table}"))
        .await
        .unwrap();
    batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap()
        .value(0)
}

#[tokio::test]
async fn e2e_crud_lifecycle() {
    let tmp = TempDir::new().unwrap();
    let engine = make_rusqlite_engine(&tmp).await;

    engine
        .execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)",
            &[],
        )
        .await
        .unwrap();
    engine.register_table(users_schema()).await.unwrap();

    // INSERT
    engine
        .execute("INSERT INTO users VALUES (1, 'Alice', 30)", &[])
        .await
        .unwrap();
    engine
        .execute("INSERT INTO users VALUES (2, 'Bob', 25)", &[])
        .await
        .unwrap();
    engine
        .execute("INSERT INTO users VALUES (3, 'Charlie', 35)", &[])
        .await
        .unwrap();

    let result = engine.sync_now().await.unwrap();
    assert_eq!(result.rows_inserted, 3);
    assert_eq!(olap_count(&engine, "users").await, 3);

    // Verify values
    let batches = engine
        .olap()
        .query("SELECT name FROM users WHERE id = 1")
        .await
        .unwrap();
    assert_eq!(
        batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<StringArray>()
            .unwrap()
            .value(0),
        "Alice"
    );

    // UPDATE
    engine
        .execute("UPDATE users SET age = 31 WHERE id = 1", &[])
        .await
        .unwrap();
    let result = engine.sync_now().await.unwrap();
    assert_eq!(result.rows_updated, 1);

    let batches = engine
        .olap()
        .query("SELECT age FROM users WHERE id = 1")
        .await
        .unwrap();
    assert_eq!(
        batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<Int64Array>()
            .unwrap()
            .value(0),
        31
    );

    // DELETE
    engine
        .execute("DELETE FROM users WHERE id = 2", &[])
        .await
        .unwrap();
    let result = engine.sync_now().await.unwrap();
    assert_eq!(result.rows_deleted, 1);
    assert_eq!(olap_count(&engine, "users").await, 2);
}

#[tokio::test]
async fn e2e_query_routing() {
    let tmp = TempDir::new().unwrap();
    let engine = make_rusqlite_engine(&tmp).await;

    engine
        .execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)",
            &[],
        )
        .await
        .unwrap();
    engine.register_table(users_schema()).await.unwrap();

    engine
        .execute("INSERT INTO users VALUES (1, 'Alice', 30)", &[])
        .await
        .unwrap();
    engine
        .execute("INSERT INTO users VALUES (2, 'Bob', 25)", &[])
        .await
        .unwrap();
    engine
        .execute("INSERT INTO users VALUES (3, 'Charlie', 35)", &[])
        .await
        .unwrap();
    engine.sync_now().await.unwrap();

    // Analytical → OLAP
    let batches = engine
        .query("SELECT AVG(age) as avg_age FROM users")
        .await
        .unwrap();
    let avg = batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<Float64Array>()
        .unwrap()
        .value(0);
    assert!((avg - 30.0).abs() < 0.01);

    // Point → OLTP
    let batches = engine
        .query("SELECT name FROM users WHERE id = 1")
        .await
        .unwrap();
    assert_eq!(
        batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<StringArray>()
            .unwrap()
            .value(0),
        "Alice"
    );
}

#[tokio::test]
async fn e2e_schema_evolution() {
    let tmp = TempDir::new().unwrap();
    let engine = make_rusqlite_engine(&tmp).await;

    engine
        .execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)",
            &[],
        )
        .await
        .unwrap();
    engine
        .register_table(TableSchema::new(
            "users",
            Arc::new(Schema::new(vec![
                Field::new("id", DataType::Int64, false),
                Field::new("name", DataType::Utf8, true),
            ])),
            vec!["id".to_string()],
        ))
        .await
        .unwrap();

    engine
        .execute("INSERT INTO users VALUES (1, 'Alice')", &[])
        .await
        .unwrap();
    engine.sync_now().await.unwrap();

    // ADD COLUMN
    engine
        .execute("ALTER TABLE users ADD COLUMN age INTEGER", &[])
        .await
        .unwrap();
    engine
        .add_column("users", "age", DataType::Int64)
        .await
        .unwrap();

    engine
        .execute("INSERT INTO users VALUES (2, 'Bob', 25)", &[])
        .await
        .unwrap();
    engine.sync_now().await.unwrap();

    let batches = engine
        .olap()
        .query("SELECT age FROM users WHERE id = 2")
        .await
        .unwrap();
    assert_eq!(
        batches[0]
            .column(0)
            .as_any()
            .downcast_ref::<Int64Array>()
            .unwrap()
            .value(0),
        25
    );

    // DROP COLUMN
    engine.drop_column("users", "age").await.unwrap();
    engine
        .execute("INSERT INTO users VALUES (3, 'Charlie')", &[])
        .await
        .unwrap();
    engine.sync_now().await.unwrap();

    let batches = engine
        .olap()
        .query("SELECT * FROM users WHERE id = 3")
        .await
        .unwrap();
    assert!(batches[0].schema().index_of("age").is_err());
}

/// SoP-style benchmark: measures throughput of the Rusqlite OLTP backend.
#[tokio::test]
async fn sop_benchmark() {
    if std::env::var("RHEI_TEST_E2E").is_err() {
        eprintln!("skipping rusqlite SoP benchmark (set RHEI_TEST_E2E=1 to run)");
        return;
    }

    let tmp = TempDir::new().unwrap();
    let engine = make_rusqlite_engine(&tmp).await;

    engine
        .execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER, score REAL)",
            &[],
        )
        .await
        .unwrap();
    engine
        .register_table(TableSchema::new(
            "users",
            Arc::new(Schema::new(vec![
                Field::new("id", DataType::Int64, false),
                Field::new("name", DataType::Utf8, true),
                Field::new("age", DataType::Int64, true),
                Field::new("score", DataType::Float64, true),
            ])),
            vec!["id".to_string()],
        ))
        .await
        .unwrap();

    // Phase 2: Insert 500 rows
    let t0 = Instant::now();
    for i in 1..=500 {
        engine
            .execute(
                &format!(
                    "INSERT INTO users VALUES ({i}, 'User{i}', {}, {:.1})",
                    20 + (i % 50),
                    (i % 100) as f64 * 0.1
                ),
                &[],
            )
            .await
            .unwrap();
    }
    let insert_elapsed = t0.elapsed();
    println!(
        "  [Rusqlite] Insert 500 rows: {:?} ({:.0} rows/sec)",
        insert_elapsed,
        500.0 / insert_elapsed.as_secs_f64()
    );

    let t0 = Instant::now();
    let result = engine.sync_now().await.unwrap();
    println!(
        "  [Rusqlite] Sync: {:?} ({:.0} events/sec)",
        t0.elapsed(),
        result.events_processed as f64 / t0.elapsed().as_secs_f64()
    );

    assert_eq!(olap_count(&engine, "users").await, 500);

    // Phase 3: CRUD
    let t0 = Instant::now();
    for i in 501..=600 {
        engine
            .execute(
                &format!(
                    "INSERT INTO users VALUES ({i}, 'New{i}', {}, 0.0)",
                    25 + (i % 30)
                ),
                &[],
            )
            .await
            .unwrap();
    }
    for i in 1..=100 {
        engine
            .execute(
                &format!("UPDATE users SET name = 'Upd{i}' WHERE id = {i}"),
                &[],
            )
            .await
            .unwrap();
    }
    for i in 101..=125 {
        engine
            .execute(&format!("DELETE FROM users WHERE id = {i}"), &[])
            .await
            .unwrap();
    }
    let crud_elapsed = t0.elapsed();
    println!(
        "  [Rusqlite] CRUD 225 ops: {:?} ({:.0} ops/sec)",
        crud_elapsed,
        225.0 / crud_elapsed.as_secs_f64()
    );

    let t0 = Instant::now();
    let result = engine.sync_now().await.unwrap();
    println!(
        "  [Rusqlite] Sync CRUD: {:?} (ins={}, upd={}, del={})",
        t0.elapsed(),
        result.rows_inserted,
        result.rows_updated,
        result.rows_deleted
    );

    assert_eq!(olap_count(&engine, "users").await, 575);

    // Phase 4: Batch insert
    let t0 = Instant::now();
    let stmts: Vec<(String, Vec<serde_json::Value>)> = (1000..1400)
        .map(|i| {
            (
                format!(
                    "INSERT INTO users VALUES ({i}, 'Batch{i}', {}, 0.0)",
                    20 + (i % 40)
                ),
                vec![],
            )
        })
        .collect();
    engine.execute_batch(&stmts).await.unwrap();
    let batch_elapsed = t0.elapsed();
    println!(
        "  [Rusqlite] Batch 400 rows: {:?} ({:.0} rows/sec)",
        batch_elapsed,
        400.0 / batch_elapsed.as_secs_f64()
    );

    engine.sync_now().await.unwrap();
    assert!(olap_count(&engine, "users").await >= 975);

    println!("  [Rusqlite] === ALL PHASES PASS ===");
}
