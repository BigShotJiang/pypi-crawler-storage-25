//! SoP-compliant E2E test for the Rhei Rust API.
//!
//! Follows E2E_TESTING_SOP.md phases with medium workload:
//! - 500 rows initial load across 2 tables
//! - Mixed CRUD (100 INSERT, 100 UPDATE, 25 DELETE)
//! - Concurrent writers (8 tasks x 50 rows)
//! - Schema evolution under load
//! - Query routing verification
//! - CDC pruning verification
//!
//! **Manual only — not part of CI.** Run with:
//! ```bash
//! RHEI_TEST_E2E=1 cargo test --workspace --all-features --test sop_e2e_test
//! ```

use std::sync::Arc;
use std::time::Instant;

use arrow::array::{Float64Array, Int64Array, StringArray};
use tempfile::TempDir;

use rhei::{HtapConfig, HtapEngine, OlapEngine, TableSchema};

fn users_schema() -> TableSchema {
    TableSchema::new(
        "users",
        Arc::new(arrow::datatypes::Schema::new(vec![
            arrow::datatypes::Field::new("id", arrow::datatypes::DataType::Int64, false),
            arrow::datatypes::Field::new("name", arrow::datatypes::DataType::Utf8, true),
            arrow::datatypes::Field::new("age", arrow::datatypes::DataType::Int64, true),
            arrow::datatypes::Field::new("score", arrow::datatypes::DataType::Float64, true),
        ])),
        vec!["id".to_string()],
    )
}

fn orders_schema() -> TableSchema {
    TableSchema::new(
        "orders",
        Arc::new(arrow::datatypes::Schema::new(vec![
            arrow::datatypes::Field::new("id", arrow::datatypes::DataType::Int64, false),
            arrow::datatypes::Field::new("user_id", arrow::datatypes::DataType::Int64, true),
            arrow::datatypes::Field::new("amount", arrow::datatypes::DataType::Int64, true),
        ])),
        vec!["id".to_string()],
    )
}

async fn olap_count(engine: &HtapEngine, table: &str) -> i64 {
    let batches = engine
        .olap()
        .query(&format!("SELECT COUNT(*) FROM {table}"))
        .await
        .unwrap();
    batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap()
        .value(0)
}

async fn make_engine(tmp: &TempDir) -> HtapEngine {
    let config = HtapConfig {
        oltp_path: tmp.path().join("sop_e2e.db").to_str().unwrap().to_string(),
        ..Default::default()
    };
    HtapEngine::new(config).await.unwrap()
}

/// Macro to generate the SoP test for both backends.
macro_rules! sop_e2e_test {
    ($mod_name:ident, $make_engine:ident) => {
        mod $mod_name {
            use super::*;

            #[tokio::test]
            async fn sop_full_pipeline() {
                if std::env::var("RHEI_TEST_E2E").is_err() {
                    eprintln!("skipping SoP E2E test (set RHEI_TEST_E2E=1 to run)");
                    return;
                }
                let tmp = TempDir::new().unwrap();
                let engine = $make_engine(&tmp).await;

                // ===== Phase 1: Setup and Registration =====
                let t0 = Instant::now();

                engine
                    .execute(
                        "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER, score REAL)",
                        &[],
                    )
                    .await
                    .unwrap();
                engine.register_table(users_schema()).await.unwrap();

                engine
                    .execute(
                        "CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER, amount INTEGER)",
                        &[],
                    )
                    .await
                    .unwrap();
                engine.register_table(orders_schema()).await.unwrap();

                println!("  Phase 1 (Setup): {:?}", t0.elapsed());

                // ===== Phase 2: Initial Data Load (500+200 rows) =====
                let t0 = Instant::now();

                for i in 1..=500 {
                    engine
                        .execute(
                            &format!(
                                "INSERT INTO users VALUES ({i}, 'User{i}', {}, {:.1})",
                                20 + (i % 50),
                                (i % 100) as f64 * 0.1
                            ),
                            &[],
                        )
                        .await
                        .unwrap();
                }
                for i in 1..=200 {
                    engine
                        .execute(
                            &format!(
                                "INSERT INTO orders VALUES ({i}, {}, {})",
                                (i % 500) + 1,
                                100 + i * 10
                            ),
                            &[],
                        )
                        .await
                        .unwrap();
                }

                let insert_elapsed = t0.elapsed();
                println!(
                    "  Phase 2 (Insert 700 rows): {:?} ({:.0} rows/sec)",
                    insert_elapsed,
                    700.0 / insert_elapsed.as_secs_f64()
                );

                let t0 = Instant::now();
                let result = engine.sync_now().await.unwrap();
                let sync_elapsed = t0.elapsed();
                println!(
                    "  Phase 2 (Sync): {:?} ({:.0} events/sec)",
                    sync_elapsed,
                    result.events_processed as f64 / sync_elapsed.as_secs_f64()
                );

                assert_eq!(olap_count(&engine, "users").await, 500);
                assert_eq!(olap_count(&engine, "orders").await, 200);

                // Spot-check
                let batches = engine
                    .olap()
                    .query("SELECT name FROM users WHERE id = 42")
                    .await
                    .unwrap();
                assert_eq!(
                    batches[0]
                        .column(0)
                        .as_any()
                        .downcast_ref::<StringArray>()
                        .unwrap()
                        .value(0),
                    "User42"
                );

                let status = engine.sync_status().await.unwrap();
                assert_eq!(status.lag, 0);

                // ===== Phase 3: Mixed CRUD =====
                let t0 = Instant::now();

                for i in 501..=600 {
                    engine
                        .execute(
                            &format!(
                                "INSERT INTO users VALUES ({i}, 'New{i}', {}, {:.1})",
                                25 + (i % 30),
                                (i % 50) as f64 * 0.2
                            ),
                            &[],
                        )
                        .await
                        .unwrap();
                }
                for i in 1..=100 {
                    engine
                        .execute(
                            &format!("UPDATE users SET name = 'Updated{i}' WHERE id = {i}"),
                            &[],
                        )
                        .await
                        .unwrap();
                }
                for i in 101..=125 {
                    engine
                        .execute(&format!("DELETE FROM users WHERE id = {i}"), &[])
                        .await
                        .unwrap();
                }

                let crud_elapsed = t0.elapsed();
                println!(
                    "  Phase 3 (CRUD 225 ops): {:?} ({:.0} ops/sec)",
                    crud_elapsed,
                    225.0 / crud_elapsed.as_secs_f64()
                );

                let t0 = Instant::now();
                let result = engine.sync_now().await.unwrap();
                println!(
                    "  Phase 3 (Sync): {:?} (ins={}, upd={}, del={})",
                    t0.elapsed(),
                    result.rows_inserted,
                    result.rows_updated,
                    result.rows_deleted
                );

                assert_eq!(olap_count(&engine, "users").await, 575);

                let batches = engine
                    .olap()
                    .query("SELECT name FROM users WHERE id = 1")
                    .await
                    .unwrap();
                assert_eq!(
                    batches[0]
                        .column(0)
                        .as_any()
                        .downcast_ref::<StringArray>()
                        .unwrap()
                        .value(0),
                    "Updated1"
                );

                assert_eq!(olap_count(&engine, "users WHERE id = 110").await, 0);

                // ===== Phase 4: Concurrent Operations =====
                let engine = Arc::new(engine);
                let t0 = Instant::now();

                let mut handles = Vec::new();
                for task in 0..8u32 {
                    let eng = Arc::clone(&engine);
                    handles.push(tokio::spawn(async move {
                        for j in 0..50u32 {
                            let rid = 1000 + task * 50 + j;
                            eng.execute(
                                &format!(
                                    "INSERT INTO orders VALUES ({rid}, {}, {rid}0)",
                                    (rid % 500) + 1
                                ),
                                &[],
                            )
                            .await
                            .unwrap();
                        }
                    }));
                }
                for h in handles {
                    h.await.unwrap();
                }

                let concurrent_elapsed = t0.elapsed();
                println!(
                    "  Phase 4 (8x50 concurrent): {:?} ({:.0} rows/sec)",
                    concurrent_elapsed,
                    400.0 / concurrent_elapsed.as_secs_f64()
                );

                engine.sync_now().await.unwrap();
                let orders = olap_count(&engine, "orders").await;
                assert!(orders >= 600, "Expected >=600 orders, got {orders}");

                // ===== Phase 5: Schema Evolution =====
                let t0 = Instant::now();

                engine
                    .execute("ALTER TABLE users ADD COLUMN email TEXT", &[])
                    .await
                    .unwrap();
                engine
                    .add_column("users", "email", arrow::datatypes::DataType::Utf8)
                    .await
                    .unwrap();

                engine
                    .execute(
                        "INSERT INTO users VALUES (999, 'SchemaTest', 30, 9.9, 'test@x.com')",
                        &[],
                    )
                    .await
                    .unwrap();
                engine.sync_now().await.unwrap();

                let batches = engine
                    .olap()
                    .query("SELECT email FROM users WHERE id = 999")
                    .await
                    .unwrap();
                assert_eq!(
                    batches[0]
                        .column(0)
                        .as_any()
                        .downcast_ref::<StringArray>()
                        .unwrap()
                        .value(0),
                    "test@x.com"
                );

                engine.drop_column("users", "score").await.unwrap();
                engine
                    .execute("INSERT INTO users VALUES (998, 'NoScore', 25, 'ns@x.com')", &[])
                    .await
                    .unwrap();
                engine.sync_now().await.unwrap();

                let batches = engine
                    .olap()
                    .query("SELECT * FROM users WHERE id = 998")
                    .await
                    .unwrap();
                assert!(
                    batches[0].schema().index_of("score").is_err(),
                    "score column should be dropped"
                );

                println!("  Phase 5 (Schema evolution): {:?}", t0.elapsed());

                // ===== Phase 6: Query Routing =====
                let t0 = Instant::now();

                let batches = engine
                    .query("SELECT AVG(age) as avg_age FROM users")
                    .await
                    .unwrap();
                let avg = batches[0]
                    .column(0)
                    .as_any()
                    .downcast_ref::<Float64Array>()
                    .unwrap()
                    .value(0);
                assert!(20.0 < avg && avg < 80.0, "AVG(age) = {avg}");

                let batches = engine
                    .query("SELECT name FROM users WHERE id = 999")
                    .await
                    .unwrap();
                assert_eq!(
                    batches[0]
                        .column(0)
                        .as_any()
                        .downcast_ref::<StringArray>()
                        .unwrap()
                        .value(0),
                    "SchemaTest"
                );

                let batches = engine
                    .query_with_hint("SELECT COUNT(*) FROM users", rhei::QueryHint::ForceOlap)
                    .await
                    .unwrap();
                let count = batches[0]
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0);
                assert!(count > 500);

                println!("  Phase 6 (Query routing): {:?}", t0.elapsed());
                println!("  === SoP E2E Complete: ALL PHASES PASS ===");
            }
        }
    };
}

sop_e2e_test!(datafusion_sop, make_engine);

#[cfg(feature = "duckdb-backend")]
async fn make_duckdb_engine(tmp: &TempDir) -> HtapEngine {
    let config = HtapConfig {
        oltp_path: tmp.path().join("sop_e2e.db").to_str().unwrap().to_string(),
        olap_backend: rhei::OlapBackendType::DuckDb,
        ..Default::default()
    };
    HtapEngine::new(config).await.unwrap()
}

#[cfg(feature = "duckdb-backend")]
sop_e2e_test!(duckdb_sop, make_duckdb_engine);
