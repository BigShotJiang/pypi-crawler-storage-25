//! Error types for the CDC sync pipeline.

use thiserror::Error;

/// Errors that can occur during CDC-to-OLAP synchronisation.
#[derive(Debug, Error)]
pub enum SyncError {
    /// An error returned by the CDC consumer (e.g. polling or pruning failed).
    #[error("CDC consumer error: {0}")]
    Cdc(String),

    /// An error returned by the OLAP engine while executing DML or loading Arrow data.
    #[error("OLAP engine error: {0}")]
    Olap(String),

    /// A schema-registry error (e.g. table not registered, reserved column name).
    ///
    /// Converted automatically from [`rhei_core::CoreError`].
    #[error("schema error: {0}")]
    Schema(#[from] rhei_core::CoreError),

    /// A CDC event could not be converted to DML (e.g. missing primary key, NULL PK value).
    #[error("conversion error: {0}")]
    Conversion(String),

    /// A column type in the CDC event or Arrow schema is not supported by the
    /// Arrow batch path.  The caller should fall back to the SQL path.
    #[error("unsupported type in CDC event: {0}")]
    UnsupportedType(String),

    /// JSON serialisation / deserialisation failed.
    ///
    /// Converted automatically from [`serde_json::Error`].
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    /// A catch-all variant for errors that do not fit the categories above.
    #[error("{0}")]
    Other(String),
}
