//! Error types for the `rhei-oltp-rusqlite` crate.
//!
//! All fallible operations in this crate return [`RusqliteOltpError`].

use thiserror::Error;

/// Unified error type for the Rusqlite OLTP engine.
///
/// Aggregates errors from the underlying async rusqlite wrapper
/// ([`rhei_tokio_rusqlite`]), Arrow conversion, the shared core layer
/// ([`rhei_core`]), and CDC-specific setup failures.
#[derive(Debug, Error)]
pub enum RusqliteOltpError {
    /// Wraps errors from the [`rhei_tokio_rusqlite`] async connection layer,
    /// which in turn surfaces `rusqlite::Error` and channel-level failures.
    #[error("rusqlite error: {0}")]
    Rusqlite(#[from] rhei_tokio_rusqlite::Error),

    /// An error occurred while converting between rusqlite values and Apache
    /// Arrow arrays or record batches.
    #[error("arrow conversion error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    /// Wraps a [`rhei_core::CoreError`], typically produced by identifier
    /// validation or schema-registry operations.
    #[error("core error: {0}")]
    Core(#[from] rhei_core::CoreError),

    /// CDC trigger setup or teardown failed.  The string carries a
    /// human-readable description of the failure (e.g., table not found, SQL
    /// execution error).
    #[error("CDC setup error: {0}")]
    CdcSetup(String),

    /// A catch-all variant for errors that do not fit the other categories.
    #[error("{0}")]
    Other(String),
}
