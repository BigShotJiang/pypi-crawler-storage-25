//! Rusqlite-backed OLTP engine for the Rhei HTAP database.
//!
//! # Position in the HTAP pipeline
//!
//! `rhei-oltp-rusqlite` is the transactional layer of Rhei. It sits between
//! application clients and a local SQLite database file, and acts as a CDC
//! source for the `rhei-sync` crate's `CdcSyncEngine`, which replicates mutations into
//! the OLAP backend (DuckDB or DataFusion).
//!
//! ```text
//! Client SQL
//!    │
//!    ▼
//! RusqliteEngine  (implements rhei_core::OltpEngine)
//!    ├── write connection  ─ all INSERT / UPDATE / DELETE / DDL
//!    ├── read pool (N connections, round-robin) ─ SELECT
//!    └── CDC connection  ─ polls _rhei_cdc_log
//!           │
//!           ▼
//!        RusqliteCdcProducer  (implements rhei_core::CdcConsumer)
//!           │
//!           ▼
//!        CdcSyncEngine  ──▶  OlapBackend
//! ```
//!
//! # Threading model
//!
//! `rusqlite::Connection` is not `Send`, so every connection is pinned to its
//! own dedicated OS thread (via [`rhei_tokio_rusqlite`]).  Async callers
//! dispatch closures through a `crossbeam_channel` and receive results on a
//! `tokio::sync::oneshot` channel — no `unsafe` code required.
//!
//! [`RusqliteEngine`] opens connections with the following SQLite pragmas:
//!
//! - `journal_mode=WAL` — readers never block the writer.
//! - `synchronous=NORMAL` — durable on most workloads without full fsync.
//! - `busy_timeout=5000` — retry for up to 5 s when the database is locked.
//!
//! # Trigger-based CDC
//!
//! When [`cdc_setup::setup_cdc`] is called for a table, three SQLite triggers
//! are installed (`AFTER INSERT`, `AFTER UPDATE`, `AFTER DELETE`).  Each
//! trigger appends one row to the `_rhei_cdc_log` table.
//!
//! Row data is serialised as a **`json_array()`** expression rather than
//! `json_object()` because the array form skips key serialisation, yielding
//! roughly a 10 % reduction in trigger write overhead.  [`RusqliteCdcProducer`]
//! reconstructs the keyed JSON object at poll time by fetching the column order
//! from `PRAGMA table_info` — this also handles schema evolution correctly,
//! since column names are never stored in the log itself.
//!
//! # Key public types
//!
//! | Type | Role |
//! |------|------|
//! | [`RusqliteEngine`] | OLTP engine: write connection + read pool |
//! | [`RusqliteCdcProducer`] | CDC consumer: polls `_rhei_cdc_log` |
//! | [`RusqliteOltpError`] | Unified error type for this crate |

pub mod cdc_producer;
pub mod cdc_setup;
pub mod engine;
pub mod error;

pub use cdc_producer::RusqliteCdcProducer;
pub use engine::RusqliteEngine;
pub use error::RusqliteOltpError;
