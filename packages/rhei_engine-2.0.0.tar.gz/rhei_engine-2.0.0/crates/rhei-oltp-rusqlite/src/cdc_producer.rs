//! CDC event consumer backed by the `_rhei_cdc_log` SQLite table.
//!
//! [`RusqliteCdcProducer`] implements [`rhei_core::CdcConsumer`] by polling
//! the `_rhei_cdc_log` table that is maintained by the triggers installed in
//! [`crate::cdc_setup`].
//!
//! ## `json_array` → `json_object` reconstruction
//!
//! Trigger payloads are stored as `json_array()` values (column values only,
//! no keys) for write efficiency.  [`RusqliteCdcProducer`] transparently (in its `poll` method)
//! converts each array back into a keyed JSON object before returning the
//! events.  Column names are fetched from `PRAGMA table_info` once per table
//! per poll cycle and cached for the duration of that cycle, so schema
//! evolution is picked up on the next cycle without any manual invalidation.

use rhei_core::types::{CdcEvent, CdcOperation};
use tracing::debug;

use crate::error::RusqliteOltpError;

/// SQL used to page through unprocessed CDC events in sequence order.
const POLL_SQL: &str = "SELECT seq, ts, op, tbl, row_id, old_data, new_data \
                         FROM _rhei_cdc_log \
                         WHERE seq > ?1 \
                         ORDER BY seq ASC \
                         LIMIT ?2";

/// SQL used to determine the highest sequence number currently in the log.
const LATEST_SEQ_SQL: &str = "SELECT MAX(seq) FROM _rhei_cdc_log";

/// SQL used to delete all log rows up to and including a given sequence number.
const PRUNE_SQL: &str = "DELETE FROM _rhei_cdc_log WHERE seq <= ?1";

/// Reads CDC events from the `_rhei_cdc_log` table in the OLTP database.
///
/// CDC triggers use `json_array()` for ~10% faster writes. The producer
/// reconstructs keyed JSON objects using the column list from `PRAGMA table_info`
/// (fetched fresh each poll cycle to handle schema evolution correctly).
pub struct RusqliteCdcProducer {
    conn: rhei_tokio_rusqlite::Connection,
}

impl RusqliteCdcProducer {
    /// Create a new producer that will poll `_rhei_cdc_log` on `conn`.
    ///
    /// The connection should be a *dedicated* connection obtained from
    /// [`RusqliteEngine::new_connection`][crate::RusqliteEngine::new_connection]
    /// so that CDC polling does not compete with application reads or writes.
    pub fn new(conn: rhei_tokio_rusqlite::Connection) -> Self {
        Self { conn }
    }

    /// Convert a `json_array` payload into a `json_object` using `columns` as keys.
    ///
    /// Triggers store row data as `json_array(col1, col2, …)` for efficiency.
    /// This function pairs each array element with the corresponding column name
    /// to produce `{"col1": val1, "col2": val2, …}`.
    ///
    /// If `array_val` is already a JSON object (legacy format), it is returned
    /// unchanged.  Any other non-array value is also passed through as-is.
    fn array_to_object(columns: &[String], array_val: serde_json::Value) -> serde_json::Value {
        match array_val {
            serde_json::Value::Array(arr) => {
                let mut map = serde_json::Map::with_capacity(columns.len());
                for (col, val) in columns.iter().zip(arr) {
                    map.insert(col.clone(), val);
                }
                serde_json::Value::Object(map)
            }
            // If it's already an object (legacy format), pass through
            obj @ serde_json::Value::Object(_) => obj,
            other => other,
        }
    }
}

impl rhei_core::CdcConsumer for RusqliteCdcProducer {
    type Error = RusqliteOltpError;

    /// Fetch up to `limit` CDC events with sequence number greater than
    /// `after_seq`.
    ///
    /// Pass `after_seq = None` to start from the beginning of the log.
    /// Events are returned in ascending sequence order.
    ///
    /// `json_array()` payloads are converted to keyed JSON objects before
    /// returning (via the internal `array_to_object` helper).  Column names are fetched
    /// from `PRAGMA table_info` once per distinct table per call.
    ///
    /// # Errors
    ///
    /// Returns [`RusqliteOltpError`] if the SQL query or JSON parsing fails.
    async fn poll(&self, after_seq: Option<i64>, limit: u32) -> Result<Vec<CdcEvent>, Self::Error> {
        let after = after_seq.unwrap_or(0);
        let limit_i64 = limit as i64;

        // Raw events with json_array data
        let raw_events = self
            .conn
            .call(move |c| {
                let mut stmt = c.prepare(POLL_SQL)?;
                let mut rows = stmt.query(rusqlite::params![after, limit_i64])?;

                let mut events = Vec::new();
                while let Some(row) = rows.next()? {
                    let seq: i64 = row.get(0)?;
                    let timestamp: i64 = row.get(1)?;
                    let op_str: String = row.get(2)?;
                    let table: String = row.get(3)?;
                    let row_id: Option<i64> = row.get::<_, Option<i64>>(4)?;
                    let old_data_str: Option<String> = row.get::<_, Option<String>>(5)?;
                    let new_data_str: Option<String> = row.get::<_, Option<String>>(6)?;

                    let operation = match CdcOperation::from_code(&op_str) {
                        Some(op) => op,
                        None => {
                            return Err(rhei_tokio_rusqlite::Error::Other(format!(
                                "unknown CDC operation code: {op_str}"
                            )))
                        }
                    };

                    let old_data: Option<serde_json::Value> = match old_data_str {
                        Some(ref s) => Some(serde_json::from_str(s).map_err(|e| {
                            rhei_tokio_rusqlite::Error::Other(format!("CDC JSON parse error: {e}"))
                        })?),
                        None => None,
                    };
                    let new_data: Option<serde_json::Value> = match new_data_str {
                        Some(ref s) => Some(serde_json::from_str(s).map_err(|e| {
                            rhei_tokio_rusqlite::Error::Other(format!("CDC JSON parse error: {e}"))
                        })?),
                        None => None,
                    };

                    events.push(CdcEvent {
                        seq,
                        timestamp,
                        operation,
                        table,
                        row_id,
                        old_data,
                        new_data,
                    });
                }

                Ok(events)
            })
            .await?;

        // Convert json_array data to json_object using column names.
        // Fetch column list per distinct table (fresh each cycle for schema evolution).
        let mut col_map: std::collections::HashMap<String, Vec<String>> =
            std::collections::HashMap::new();
        let mut events = Vec::with_capacity(raw_events.len());
        for mut event in raw_events {
            let columns = match col_map.get(&event.table) {
                Some(cols) => cols.clone(),
                None => {
                    let cols = crate::cdc_setup::table_columns(&self.conn, &event.table).await?;
                    col_map.insert(event.table.clone(), cols.clone());
                    cols
                }
            };

            if let Some(data) = event.new_data.take() {
                event.new_data = Some(Self::array_to_object(&columns, data));
            }
            if let Some(data) = event.old_data.take() {
                event.old_data = Some(Self::array_to_object(&columns, data));
            }

            events.push(event);
        }

        debug!(
            count = events.len(),
            after_seq = after,
            "polled CDC events (rusqlite)"
        );
        Ok(events)
    }

    /// Return the highest sequence number currently in `_rhei_cdc_log`, or
    /// `None` if the log is empty.
    ///
    /// # Errors
    ///
    /// Returns [`RusqliteOltpError`] if the `SELECT MAX(seq)` query fails.
    async fn latest_seq(&self) -> Result<Option<i64>, Self::Error> {
        let seq = self
            .conn
            .call(|c| {
                let result: rusqlite::Result<Option<i64>> =
                    c.query_row(LATEST_SEQ_SQL, [], |row| row.get(0));
                match result {
                    Ok(val) => Ok(val),
                    Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
                    Err(e) => Err(rhei_tokio_rusqlite::Error::from(e)),
                }
            })
            .await?;
        Ok(seq)
    }

    /// Delete all `_rhei_cdc_log` rows with `seq <= up_to_seq`.
    ///
    /// Returns the number of rows deleted.  This is typically called by the
    /// sync engine after all events up to a certain watermark have been
    /// successfully applied to the OLAP backend.
    ///
    /// # Errors
    ///
    /// Returns [`RusqliteOltpError`] if the `DELETE` statement fails.
    async fn prune(&self, up_to_seq: i64) -> Result<u64, Self::Error> {
        let deleted = self
            .conn
            .call(move |c| {
                let changed = c.execute(PRUNE_SQL, rusqlite::params![up_to_seq])?;
                Ok(changed as u64)
            })
            .await?;
        debug!(up_to_seq, deleted, "pruned CDC events (rusqlite)");
        Ok(deleted)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cdc_setup::CDC_LOG_TABLE;
    use rhei_core::CdcConsumer;

    #[tokio::test]
    async fn test_cdc_roundtrip() {
        let conn = rhei_tokio_rusqlite::Connection::open_in_memory()
            .await
            .unwrap();

        // Set up CDC log table and a source table with triggers
        conn.call(|c| {
            c.execute_batch(&format!(
                "CREATE TABLE {CDC_LOG_TABLE} (
                    seq    INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts     INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    op     TEXT    NOT NULL CHECK(op IN ('I','U','D')),
                    tbl    TEXT    NOT NULL,
                    row_id INTEGER,
                    old_data TEXT,
                    new_data TEXT
                );
                CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);
                CREATE TRIGGER _rhei_cdc_users_insert
                AFTER INSERT ON users
                BEGIN
                  INSERT INTO {CDC_LOG_TABLE} (op, tbl, row_id, new_data)
                  VALUES ('I', 'users', NEW.rowid, json_array(NEW.id, NEW.name));
                END;"
            ))?;
            Ok(())
        })
        .await
        .unwrap();

        // Insert a row to trigger CDC
        conn.call(|c| {
            c.execute("INSERT INTO users (id, name) VALUES (1, 'Alice')", [])?;
            Ok(())
        })
        .await
        .unwrap();

        let producer = RusqliteCdcProducer::new(conn);

        // Poll
        let events = producer.poll(None, 100).await.unwrap();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].table, "users");
        assert_eq!(events[0].operation, CdcOperation::Insert);
        assert!(events[0].new_data.is_some());

        // latest_seq
        let seq = producer.latest_seq().await.unwrap();
        assert_eq!(seq, Some(1));

        // prune
        let pruned = producer.prune(1).await.unwrap();
        assert_eq!(pruned, 1);

        let events_after = producer.poll(None, 100).await.unwrap();
        assert!(events_after.is_empty());
    }
}
