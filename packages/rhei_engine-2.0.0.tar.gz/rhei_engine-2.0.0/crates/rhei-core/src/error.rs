//! Error types for the `rhei-core` crate.
//!
//! All fallible operations in this crate return [`CoreError`]. Concrete engine
//! crates define their own error types but map into `CoreError` when crossing
//! the shared trait boundary.

use thiserror::Error;

/// Top-level error type for `rhei-core` operations.
///
/// Variants cover schema-registry operations and Arrow type conversions.
/// Concrete engine errors (OLTP/OLAP) are defined in their respective crates
/// and do **not** flow through this type unless explicitly wrapped.
#[derive(Debug, Error)]
pub enum CoreError {
    /// A lookup was performed for a table that has not been registered in the
    /// [`crate::SchemaRegistry`].
    #[error("table '{0}' not found in schema registry")]
    TableNotFound(String),

    /// An attempt was made to [`crate::SchemaRegistry::register`] a table name
    /// that is already present. The caller should use
    /// [`crate::SchemaRegistry::update`] for schema evolution instead.
    #[error("table '{0}' already registered")]
    TableAlreadyRegistered(String),

    /// A schema or identifier failed validation. The inner string contains a
    /// human-readable explanation suitable for surfacing to callers.
    ///
    /// Validation checks include: empty identifier, disallowed characters,
    /// missing primary key, and duplicate column names.
    #[error("schema validation failed: {0}")]
    SchemaValidation(String),

    /// An Arrow `DataType` could not be mapped to or from a SQL type string.
    ///
    /// The inner [`std::error::Error`] carries the upstream failure.
    #[error("type mapping failed: {source}")]
    TypeMapping {
        /// The underlying mapping error.
        #[source]
        source: Box<dyn std::error::Error + Send + Sync>,
    },

    /// Transparent wrapper around [`arrow::error::ArrowError`].
    #[error("arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),
}
