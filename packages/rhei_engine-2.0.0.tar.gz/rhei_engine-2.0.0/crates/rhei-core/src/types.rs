//! Core domain types shared across all Rhei crates.
//!
//! This module contains lightweight value types that cross crate boundaries.
//! They have no dependencies on database drivers and are `Clone` + `Send +
//! Sync` so they can be passed freely between async tasks.

use serde::{Deserialize, Serialize};
use std::fmt;

/// The engine that should execute a given SQL statement.
///
/// Returned by [`crate::QueryRouter::route`] and consumed by `HtapEngine` to
/// dispatch work to either [`crate::OltpEngine`] or [`crate::OlapEngine`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueryTarget {
    /// Route to the OLTP engine (Rusqlite).
    Oltp,
    /// Route to the OLAP engine (DuckDB, DataFusion, etc.).
    Olap,
}

/// Optional caller hint to override automatic SQL routing.
///
/// Pass this alongside a SQL statement to bypass the [`crate::QueryRouter`]
/// heuristic when the caller knows better (e.g., forcing an aggregate to run
/// on OLTP for testing, or forcing a write to the OLAP engine for a bulk
/// migration).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum QueryHint {
    /// Let the [`crate::QueryRouter`] decide.
    #[default]
    Auto,
    /// Force execution on the OLTP engine regardless of SQL shape.
    ForceOltp,
    /// Force execution on the OLAP engine regardless of SQL shape.
    ForceOlap,
}

/// The type of a single CDC (Change Data Capture) operation.
///
/// Serialised to/from the single-character codes `"I"`, `"U"`, `"D"` that the
/// SQLite trigger writes into `_rhei_cdc_log` and that
/// [`CdcOperation::from_code`] parses back.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CdcOperation {
    /// A new row was inserted.
    Insert,
    /// An existing row was updated.
    Update,
    /// A row was deleted.
    Delete,
}

impl fmt::Display for CdcOperation {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Insert => write!(f, "I"),
            Self::Update => write!(f, "U"),
            Self::Delete => write!(f, "D"),
        }
    }
}

impl CdcOperation {
    /// Parse a [`CdcOperation`] from the single-character code written by the
    /// SQLite trigger (`"I"`, `"U"`, or `"D"`).
    ///
    /// Returns `None` for any other input, including the empty string.
    pub fn from_code(code: &str) -> Option<Self> {
        match code {
            "I" => Some(Self::Insert),
            "U" => Some(Self::Update),
            "D" => Some(Self::Delete),
            _ => None,
        }
    }
}

/// A single CDC event captured from the OLTP engine.
///
/// Events are written to `_rhei_cdc_log` by SQLite triggers and polled by
/// [`crate::CdcConsumer::poll`]. The [`crate::SyncEngine`] converts them to
/// OLAP DML operations via the sync converter in `rhei-sync`.
///
/// `seq` values are monotonically increasing integers. The sentinel value
/// `-1` (`NEVER_SYNCED`) indicates that no event has been synced yet.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CdcEvent {
    /// Monotonically increasing sequence number assigned by the CDC log.
    ///
    /// Used as a stable watermark: the sync engine records the last processed
    /// `seq` so it can resume after a restart without re-applying old events.
    pub seq: i64,
    /// Unix timestamp in seconds when the change occurred, as recorded by
    /// the SQLite trigger.
    pub timestamp: i64,
    /// The type of DML operation that produced this event.
    pub operation: CdcOperation,
    /// Name of the OLTP table that was modified.
    pub table: String,
    /// The SQLite internal `rowid` of the affected row, when available.
    pub row_id: Option<i64>,
    /// JSON object snapshot of the row **before** the change.
    ///
    /// Present for `Update` and `Delete` events; `None` for `Insert`.
    pub old_data: Option<serde_json::Value>,
    /// JSON object snapshot of the row **after** the change.
    ///
    /// Present for `Insert` and `Update` events; `None` for `Delete`.
    pub new_data: Option<serde_json::Value>,
}

/// Summary of a single [`crate::SyncEngine::sync_once`] cycle.
///
/// Callers can use this to track replication progress, emit metrics, or decide
/// whether to sleep before the next poll.
#[derive(Debug, Clone)]
pub struct SyncResult {
    /// Total number of [`CdcEvent`]s consumed during this cycle.
    pub events_processed: u64,
    /// Number of rows written to the OLAP engine via INSERT (or Arrow bulk-load).
    pub rows_inserted: u64,
    /// Number of rows updated in the OLAP engine via UPDATE or close+reinsert.
    pub rows_updated: u64,
    /// Number of rows removed from the OLAP engine via DELETE.
    pub rows_deleted: u64,
    /// The highest [`CdcEvent::seq`] that was successfully applied in this
    /// cycle, or `None` if no events were processed.
    pub last_seq: Option<i64>,
    /// Number of [`CdcEvent`]s pruned from the CDC log after a successful
    /// sync, or `None` if pruning is disabled.
    pub pruned_count: Option<u64>,
}

/// A point-in-time snapshot of the [`crate::SyncEngine`]'s replication state.
///
/// Returned by [`crate::SyncEngine::status`] and surfaced by the CLI
/// `rh status` command and the TUI dashboard.
#[derive(Debug, Clone)]
pub struct SyncStatus {
    /// `true` while the background sync loop is active.
    pub running: bool,
    /// The [`CdcEvent::seq`] of the most recently applied event, or `None`
    /// if the engine has not synced any events yet.
    pub last_synced_seq: Option<i64>,
    /// The highest [`CdcEvent::seq`] currently available in the OLTP CDC log,
    /// or `None` if the log is empty.
    pub latest_available_seq: Option<i64>,
    /// Replication lag expressed as the number of un-synced CDC events.
    ///
    /// `lag = latest_available_seq - last_synced_seq` (clamped to zero).
    pub lag: u64,
}

/// Controls how the [`crate::SyncEngine`] applies CDC events to the OLAP engine.
///
/// Set via `HtapConfig` before starting the engine. The mode cannot be changed
/// at runtime without re-creating the OLAP tables.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum SyncMode {
    /// **Mirror mode** (default): the OLAP table is kept as a current-state
    /// mirror of the OLTP table. UPDATE overwrites the existing row; DELETE
    /// removes it. Fast and space-efficient, but no history is retained.
    #[default]
    Destructive,
    /// **Temporal mode** (SCD Type 2): every CDC event appends a new row.
    /// Updates close the previous version (`_rhei_valid_to = ts`) and insert a
    /// new open-ended version (`_rhei_valid_to IS NULL`). Deletes insert a
    /// tombstone row. Three columns are added to every OLAP table:
    /// `_rhei_valid_from`, `_rhei_valid_to`, and `_rhei_operation`.
    ///
    /// Point-in-time queries:
    /// `WHERE _rhei_valid_from <= T AND (_rhei_valid_to IS NULL OR _rhei_valid_to > T)`
    Temporal,
}

/// Discriminant for the active OLAP engine backend.
///
/// Returned by introspection APIs so callers can adapt behaviour (e.g., the
/// CLI `rh info` command) without needing a feature-flag conditional.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OlapEngineType {
    /// The DuckDB backend (`crates/rhei-duckdb`).
    ///
    /// Supports ACID transactions, native Arrow `Appender` bulk-load, and
    /// primary-key enforcement.
    DuckDB,
    /// The DataFusion backend (`crates/rhei-datafusion`).
    ///
    /// Natively async, pluggable storage modes (InMemory / ArrowIpc / Parquet),
    /// and optional S3/GCS object-store backends.
    DataFusion,
}

impl fmt::Display for OlapEngineType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DuckDB => write!(f, "DuckDB"),
            Self::DataFusion => write!(f, "DataFusion"),
        }
    }
}
