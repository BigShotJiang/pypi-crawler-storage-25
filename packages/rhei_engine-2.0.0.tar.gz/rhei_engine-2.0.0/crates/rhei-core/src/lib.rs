//! Core traits and types for the Rhei HTAP engine.
//!
//! `rhei-core` is the **foundation crate** of the Rhei workspace. Every other
//! crate depends on it for shared abstractions. It deliberately has no
//! dependencies on concrete database drivers so that it can be compiled
//! quickly and used as a pure trait/type boundary.
//!
//! # Position in the HTAP pipeline
//!
//! ```text
//! Client
//!   |
//!   v
//! HtapEngine  (crates/rhei)
//!   |-- QueryRouter  ──────────────────── routes SQL to OLTP or OLAP
//!   |-- OltpEngine   ──────────────────── transactional reads/writes
//!   |-- OlapEngine   ──────────────────── analytical queries
//!   |-- CdcConsumer  ──────────────────── polls change-data-capture events
//!   +-- SyncEngine   ──────────────────── applies CDC events to OLAP
//! ```
//!
//! # Key types
//!
//! | Item | Description |
//! |------|-------------|
//! | [`OltpEngine`] | Async trait for transactional SQL execution |
//! | [`OlapEngine`] | Async trait for analytical SQL + Arrow bulk-load |
//! | [`CdcConsumer`] | Async trait for polling CDC events |
//! | [`SyncEngine`] | Async trait for the CDC→OLAP sync loop |
//! | [`QueryRouter`] | Sync trait that classifies SQL to [`QueryTarget`] |
//! | [`SchemaRegistry`] | Thread-safe registry of [`TableSchema`]s |
//! | [`CdcEvent`] | A single change-data-capture event |
//! | [`SyncMode`] | Destructive mirror vs. SCD Type 2 temporal history |
//! | [`RecordBatchBoxStream`] | Streaming Arrow record-batch type |

pub mod error;
pub mod schema;
pub mod traits;
pub mod types;

pub use error::CoreError;
pub use schema::{validate_identifier, SchemaRegistry, TableSchema};
pub use traits::cdc::CdcConsumer;
pub use traits::olap::{vec_to_stream, OlapEngine, RecordBatchBoxStream};
pub use traits::oltp::OltpEngine;
pub use traits::router::QueryRouter;
pub use traits::sync::SyncEngine;
pub use types::*;
