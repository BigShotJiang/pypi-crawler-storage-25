//! Async trait definitions for all major Rhei engine components.
//!
//! Each sub-module defines one trait. Concrete implementations live in the
//! engine crates (`rhei-oltp-rusqlite`, `rhei-duckdb`, `rhei-datafusion`,
//! etc.) and are wired together by `HtapEngine` in the top-level `rhei` crate.
//!
//! | Module | Trait | Purpose |
//! |--------|-------|---------|
//! | [`cdc`] | [`crate::CdcConsumer`] | Poll CDC events from the OLTP log |
//! | [`olap`] | [`crate::OlapEngine`] | Analytical SQL + Arrow bulk-load |
//! | [`oltp`] | [`crate::OltpEngine`] | Transactional SQL execution |
//! | [`router`] | [`crate::QueryRouter`] | Classify SQL to OLTP or OLAP |
//! | [`sync`] | [`crate::SyncEngine`] | Apply CDC events to the OLAP engine |

pub mod cdc;
pub mod olap;
pub mod oltp;
pub mod router;
pub mod sync;
