//! [`QueryRouter`] trait — SQL routing to OLTP or OLAP.
//!
//! The production implementation (`SqlParserRouter` in `rhei-sync`) uses an
//! AST-based approach via `sqlparser-rs`. A keyword-heuristic fallback fires
//! when the parser cannot classify the statement.

use crate::types::QueryTarget;

/// Classifies SQL statements and routes them to the correct engine.
///
/// The default implementation (`SqlParserRouter` in `rhei-sync`) parses the
/// SQL AST and applies the following heuristic:
///
/// - Writes (INSERT/UPDATE/DELETE), DDL, and simple point-lookups → OLTP
/// - Aggregates, GROUP BY, JOINs, window functions, CTEs, subqueries → OLAP
///
/// # Contract for implementors
///
/// - `route` must be infallible and synchronous (no I/O).
/// - When uncertain, prefer `QueryTarget::Oltp` (safety-first: writes must
///   never accidentally go to the read-only OLAP engine).
pub trait QueryRouter: Send + Sync {
    /// Classify `sql` and return the engine that should execute it.
    fn route(&self, sql: &str) -> QueryTarget;
}
