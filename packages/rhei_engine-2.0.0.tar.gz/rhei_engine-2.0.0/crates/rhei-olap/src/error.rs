//! Unified error types for the OLAP and OLTP backend dispatchers.
//!
//! [`OlapError`] and [`OltpError`] wrap the backend-specific error types produced by
//! `rhei-duckdb`, `rhei-datafusion`, and `rhei-oltp-rusqlite`.  The `From` conversions are
//! derived by [`thiserror`] so that `.map_err(OlapError::from)` in each dispatch arm compiles
//! without boilerplate.

use thiserror::Error;

/// Error type returned by [`crate::OlapBackend`] method implementations.
///
/// Each variant corresponds to one supported OLAP backend plus a catch-all [`OlapError::Other`]
/// for errors that do not originate from a specific engine.
#[derive(Debug, Error)]
pub enum OlapError {
    /// An error returned by the DuckDB backend.
    ///
    /// Available on crate feature `duckdb-backend` only.
    #[cfg(feature = "duckdb-backend")]
    #[error("DuckDB error: {0}")]
    DuckDb(#[from] rhei_duckdb::DuckDbError),

    /// An error returned by the DataFusion backend.
    ///
    /// Available on crate feature `datafusion-backend` only.
    #[cfg(feature = "datafusion-backend")]
    #[error("DataFusion error: {0}")]
    DataFusion(#[from] rhei_datafusion::DfOlapError),

    /// A generic OLAP error not tied to a specific backend.
    #[error("{0}")]
    Other(String),
}

/// Error type returned by [`crate::OltpBackend`] method implementations.
///
/// Each variant corresponds to one supported OLTP backend plus a catch-all [`OltpError::Other`]
/// for errors that do not originate from a specific engine.
#[derive(Debug, Error)]
pub enum OltpError {
    /// An error returned by the Rusqlite (SQLite) backend.
    #[error("rusqlite OLTP error: {0}")]
    Rusqlite(#[from] rhei_oltp_rusqlite::RusqliteOltpError),

    /// A generic OLTP error not tied to a specific backend.
    #[error("{0}")]
    Other(String),
}
