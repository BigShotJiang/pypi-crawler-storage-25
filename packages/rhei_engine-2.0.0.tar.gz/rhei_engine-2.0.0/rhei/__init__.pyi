"""Type stubs for the rhei Python package."""

from __future__ import annotations

import pyarrow as pa

from rhei._rhei import (
    HtapConfig as HtapConfig,
    SyncResult as SyncResult,
    SyncStatus as SyncStatus,
    TableSchema as TableSchema,
    TimestampTableConfig as TimestampTableConfig,
)

__version__: str
__all__: list[str]


class HtapEngine:
    """Async HTAP engine.

    Provides an async context manager and an async factory for
    non-blocking initialization.
    """

    def __init__(self, config: HtapConfig | None = None) -> None: ...

    @classmethod
    async def create(cls, config: HtapConfig | None = None) -> HtapEngine: ...

    async def __aenter__(self) -> HtapEngine: ...
    async def __aexit__(self, *exc: object) -> None: ...

    # -- Write operations --

    async def execute(self, sql: str, params: list[str] | None = None) -> int: ...
    async def execute_batch(self, statements: list[str]) -> None: ...

    # -- Query operations --

    async def query(self, sql: str) -> list[pa.RecordBatch]: ...
    async def query_olap(self, sql: str) -> list[pa.RecordBatch]: ...

    # -- Sync operations --

    async def sync_now(self) -> SyncResult: ...
    async def sync_status(self) -> SyncStatus: ...
    async def initial_sync(self, table_name: str) -> int: ...

    # -- Schema operations --

    async def register_table(self, schema: TableSchema) -> None: ...
    async def add_column(self, table_name: str, column_name: str, data_type: str) -> None: ...
    async def drop_column(self, table_name: str, column_name: str) -> None: ...

    # -- Lifecycle --

    def shutdown(self) -> None: ...


async def open(
    oltp_path: str = "rhei.db",
    *,
    sync_mode: str = "destructive",
    olap_backend: str = "datafusion",
    storage_mode: str = "inmemory",
    storage_path: str | None = None,
    prune_after_sync: bool = True,
    sync_batch_size: int = 1000,
    read_pool_size: int = 4,
    sidecar_source: str | None = None,
    sidecar_tables: list[TimestampTableConfig] | None = None,
    sidecar_poll_batch_size: int = 500,
    sidecar_delete_detection: str = "disabled",
    sidecar_enable_oltp: bool = False,
) -> HtapEngine:
    """Async factory for HtapEngine — non-blocking initialization."""
    ...
