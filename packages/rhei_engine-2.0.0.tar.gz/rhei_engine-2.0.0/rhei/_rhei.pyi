"""Type stubs for the native Rust extension module (rhei._rhei).

These stubs provide type information for IDE autocompletion, type checkers
(mypy, pyright, ty), and documentation tools. The actual implementation
is in python/src/lib.rs via PyO3.
"""

from __future__ import annotations

from collections.abc import Coroutine
from typing import Any

import pyarrow as pa


class SyncResult:
    """Result of a CDC sync cycle."""

    @property
    def events_processed(self) -> int: ...
    @property
    def rows_inserted(self) -> int: ...
    @property
    def rows_updated(self) -> int: ...
    @property
    def rows_deleted(self) -> int: ...
    @property
    def pruned_count(self) -> int | None: ...
    def __repr__(self) -> str: ...


class SyncStatus:
    """Status of the sync engine."""

    @property
    def lag(self) -> int: ...
    @property
    def last_synced_seq(self) -> int | None: ...
    def __repr__(self) -> str: ...


class TableSchema:
    """Schema definition for table registration.

    Args:
        name: Table name.
        columns: List of (column_name, type_string) tuples.
            Supported types: "int8", "int16", "int32", "int", "int64", "bigint",
            "uint8", "uint16", "uint32", "uint64", "float16", "half",
            "float32", "float", "float64", "double", "utf8", "string", "text",
            "bool", "boolean", "binary", "bytes".
        pk: List of primary key column names.

    Example::

        schema = TableSchema(
            "users",
            [("id", "int64"), ("name", "utf8"), ("age", "int64")],
            ["id"],
        )
    """

    def __init__(
        self,
        name: str,
        columns: list[tuple[str, str]],
        pk: list[str],
    ) -> None: ...
    def __repr__(self) -> str: ...


class TimestampTableConfig:
    """Configuration for a single table in sidecar timestamp-based CDC.

    Args:
        table_name: External source table name.
        primary_key: List of primary key column names.
        created_at_column: Column for creation timestamp.
        updated_at_column: Column for update timestamp.
        columns: Columns to SELECT (empty list = SELECT *).
    """

    def __init__(
        self,
        table_name: str,
        primary_key: list[str],
        created_at_column: str = "created_at",
        updated_at_column: str = "updated_at",
        columns: list[str] = ...,
    ) -> None: ...
    def __repr__(self) -> str: ...


class HtapConfig:
    """Configuration for the HTAP engine.

    Args:
        oltp_path: Path to the SQLite database file.
        prune_after_sync: Whether to prune CDC log after each sync cycle.
        sync_batch_size: Number of CDC events to process per sync batch.
        read_pool_size: Number of OLTP read connections.
        sync_mode: "destructive" (default) or "temporal" (SCD Type 2).
        olap_backend: "datafusion" (default) or "duckdb".
        storage_mode: DataFusion storage: "inmemory" (default) or "vortex".
        storage_path: Path or URL for `vortex` storage. Local filesystem path
            (e.g. "/var/lib/rhei") for native disk; "s3://bucket/prefix" for
            S3-compatible object storage (requires the `cloud-storage` Cargo
            feature). Required for "vortex"; ignored for "inmemory".
        sidecar_source: Path to external DB for sidecar mode (activates sidecar).
        sidecar_tables: List of TimestampTableConfig for sidecar CDC polling.
        sidecar_poll_batch_size: Rows per sidecar poll cycle.
        sidecar_delete_detection: "disabled" (default) or "soft_delete:<column>".
        sidecar_enable_oltp: Whether to also create local OLTP in sidecar mode.
    """

    def __init__(
        self,
        oltp_path: str = "rhei.db",
        prune_after_sync: bool = True,
        sync_batch_size: int = 1000,
        read_pool_size: int = 4,
        sync_mode: str = "destructive",
        olap_backend: str = "datafusion",
        storage_mode: str = "inmemory",
        storage_path: str | None = None,
        sidecar_source: str | None = None,
        sidecar_tables: list[TimestampTableConfig] | None = None,
        sidecar_poll_batch_size: int = 500,
        sidecar_delete_detection: str = "disabled",
        sidecar_enable_oltp: bool = False,
    ) -> None: ...
    def __repr__(self) -> str: ...


class HtapEngine:
    """Native HTAP engine (low-level, prefer rhei.HtapEngine wrapper).

    All I/O methods return Python awaitables. Use with ``await``.
    """

    def __init__(self, config: HtapConfig | None = None) -> None: ...

    def register_table(
        self, schema: TableSchema
    ) -> Coroutine[Any, Any, None]: ...

    def execute(
        self, sql: str, params: list[str] | None = None
    ) -> Coroutine[Any, Any, int]: ...

    def execute_batch(
        self, statements: list[str]
    ) -> Coroutine[Any, Any, None]: ...

    def query(
        self, sql: str
    ) -> Coroutine[Any, Any, list[pa.RecordBatch]]: ...

    def query_olap(
        self, sql: str
    ) -> Coroutine[Any, Any, list[pa.RecordBatch]]: ...

    def sync_now(self) -> Coroutine[Any, Any, SyncResult]: ...

    def sync_status(self) -> Coroutine[Any, Any, SyncStatus]: ...

    def initial_sync(
        self, table_name: str
    ) -> Coroutine[Any, Any, int]: ...

    def add_column(
        self, table_name: str, column_name: str, data_type: str
    ) -> Coroutine[Any, Any, None]: ...

    def drop_column(
        self, table_name: str, column_name: str
    ) -> Coroutine[Any, Any, None]: ...

    def shutdown(self) -> None: ...
