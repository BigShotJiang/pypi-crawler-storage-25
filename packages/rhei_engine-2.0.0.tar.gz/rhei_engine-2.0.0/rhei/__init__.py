"""Rhei — Lightweight serverless HTAP engine.

Python bindings for the Rhei Rust library. All engine methods are async
and return Python awaitables, compatible with asyncio and anyio.

Usage::

    import anyio
    import rhei

    async def main():
        async with await rhei.open(oltp_path="my.db") as engine:
            await engine.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)")
            await engine.register_table(rhei.TableSchema("users", [("id", "int64"), ("name", "utf8")], ["id"]))
            await engine.execute("INSERT INTO users VALUES (1, 'Alice')")
            result = await engine.sync_now()
            batches = await engine.query("SELECT * FROM users")

    anyio.run(main)
"""

from __future__ import annotations

import anyio
from rhei._rhei import (
    HtapConfig,
    HtapEngine as _HtapEngine,
    SyncResult,
    SyncStatus,
    TableSchema,
    TimestampTableConfig,
)


class HtapEngine:
    """Async HTAP engine wrapping the native Rust engine.

    Provides an async context manager and an async factory for
    non-blocking initialization (recommended by anyio for library authors).

    The sync constructor ``HtapEngine(config)`` blocks the event loop during
    database initialization. Prefer ``await rhei.open(...)`` or
    ``await HtapEngine.create(config)`` from async code.
    """

    def __init__(self, config: HtapConfig | None = None):
        """Create engine (sync — blocks during DB init).

        Prefer ``await HtapEngine.create(config)`` from async code.
        """
        self._inner = _HtapEngine(config)

    @classmethod
    async def create(cls, config: HtapConfig | None = None) -> HtapEngine:
        """Create engine without blocking the event loop.

        Offloads the blocking DB initialization to a worker thread
        via ``anyio.to_thread.run_sync``.
        """
        obj = cls.__new__(cls)
        obj._inner = await anyio.to_thread.run_sync(lambda: _HtapEngine(config))
        return obj

    async def __aenter__(self) -> HtapEngine:
        return self

    async def __aexit__(self, *exc: object) -> None:
        self._inner.shutdown()

    # -- Write operations --

    async def execute(self, sql: str, params: list[str] | None = None) -> int:
        """Execute a write statement (routed to OLTP)."""
        return await self._inner.execute(sql, params)

    async def execute_batch(self, statements: list[str]) -> None:
        """Execute multiple writes in a single transaction.

        Much faster than calling execute() in a loop (~18K ops/sec vs ~400).
        """
        return await self._inner.execute_batch(statements)

    # -- Query operations --

    async def query(self, sql: str) -> list:
        """Auto-routed query. Returns list[pyarrow.RecordBatch]."""
        return await self._inner.query(sql)

    async def query_olap(self, sql: str) -> list:
        """Force query to OLAP. Returns list[pyarrow.RecordBatch]."""
        return await self._inner.query_olap(sql)

    # -- Sync operations --

    async def sync_now(self) -> SyncResult:
        """Sync CDC events to OLAP."""
        return await self._inner.sync_now()

    async def sync_status(self) -> SyncStatus:
        """Get sync status (CDC lag, last synced sequence)."""
        return await self._inner.sync_status()

    async def initial_sync(self, table_name: str) -> int:
        """Bulk-load existing OLTP rows into OLAP."""
        return await self._inner.initial_sync(table_name)

    # -- Schema operations --

    async def register_table(self, schema: TableSchema) -> None:
        """Register a table for HTAP replication."""
        return await self._inner.register_table(schema)

    async def add_column(self, table_name: str, column_name: str, data_type: str) -> None:
        """Add a column to a registered table."""
        return await self._inner.add_column(table_name, column_name, data_type)

    async def drop_column(self, table_name: str, column_name: str) -> None:
        """Drop a column from a registered table."""
        return await self._inner.drop_column(table_name, column_name)

    # -- Lifecycle --

    def shutdown(self) -> None:
        """Shut down the engine. Resources released on GC."""
        self._inner.shutdown()


async def open(
    oltp_path: str = "rhei.db",
    *,
    sync_mode: str = "destructive",
    olap_backend: str = "datafusion",
    storage_mode: str = "inmemory",
    storage_path: str | None = None,
    prune_after_sync: bool = True,
    sync_batch_size: int = 1000,
    read_pool_size: int = 4,
    sidecar_source: str | None = None,
    sidecar_tables: list[TimestampTableConfig] | None = None,
    sidecar_poll_batch_size: int = 500,
    sidecar_delete_detection: str = "disabled",
    sidecar_enable_oltp: bool = False,
) -> HtapEngine:
    """Async factory for HtapEngine -- non-blocking initialization.

    This is the recommended way to create an engine from async code.
    All config options are keyword arguments with sensible defaults.

    Example::

        async with await rhei.open(oltp_path="my.db") as engine:
            await engine.execute("INSERT INTO users VALUES (1, 'Alice')")
            result = await engine.sync_now()
    """
    config = HtapConfig(
        oltp_path=oltp_path,
        sync_mode=sync_mode,
        olap_backend=olap_backend,
        storage_mode=storage_mode,
        storage_path=storage_path,
        prune_after_sync=prune_after_sync,
        sync_batch_size=sync_batch_size,
        read_pool_size=read_pool_size,
        sidecar_source=sidecar_source,
        sidecar_tables=sidecar_tables,
        sidecar_poll_batch_size=sidecar_poll_batch_size,
        sidecar_delete_detection=sidecar_delete_detection,
        sidecar_enable_oltp=sidecar_enable_oltp,
    )
    return await HtapEngine.create(config)


__all__ = [
    "HtapConfig",
    "HtapEngine",
    "SyncResult",
    "SyncStatus",
    "TableSchema",
    "TimestampTableConfig",
    "open",
]

__version__ = "2.0.0"
