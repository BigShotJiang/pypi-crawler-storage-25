"""E2E tests for Rhei Python sidecar mode (SQLite source).

These tests are gated behind RHEI_TEST_E2E=1 since they exercise the full
sidecar pipeline: external SQLite DB -> timestamp CDC -> OLAP sync.

Usage:
    RHEI_TEST_E2E=1 uv run pytest tests/test_sidecar.py -v
"""

import os
import shutil
import sqlite3
import tempfile
import pyarrow as pa
import pytest

import rhei

_skip_e2e = pytest.mark.skipif(
    os.environ.get("RHEI_TEST_E2E") != "1",
    reason="RHEI_TEST_E2E=1 not set; skipping sidecar E2E tests",
)


_ts_counter = 0


def _next_ts():
    """Return a monotonically increasing integer timestamp.

    The sidecar INSERT/UPDATE heuristic compares created_at and updated_at
    as integers (via JSON `as_i64()`). Using integer timestamps ensures the
    heuristic correctly distinguishes inserts from updates.
    """
    global _ts_counter
    _ts_counter += 1
    return _ts_counter


@pytest.fixture
def tmp_dir():
    d = tempfile.mkdtemp()
    yield d
    shutil.rmtree(d, ignore_errors=True)


def _create_external_db(path):
    """Create an external SQLite database with a users table.

    Uses INTEGER timestamps so the sidecar INSERT/UPDATE heuristic
    (which compares created_at and updated_at as i64) works correctly.
    """
    conn = sqlite3.connect(path)
    conn.execute(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            age INTEGER,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    return conn


@_skip_e2e
class TestSidecarDestructive:
    @pytest.mark.anyio
    async def test_sidecar_basic_sync(self, tmp_dir):
        """Insert rows into external DB, sync to OLAP, verify data."""
        ext_path = os.path.join(tmp_dir, "external.db")
        ext_conn = _create_external_db(ext_path)

        now = _next_ts()
        ext_conn.execute(
            "INSERT INTO users VALUES (1, 'Alice', 30, ?, ?)", (now, now)
        )
        ext_conn.execute(
            "INSERT INTO users VALUES (2, 'Bob', 25, ?, ?)", (now, now)
        )
        ext_conn.commit()

        config = rhei.HtapConfig(
            oltp_path=os.path.join(tmp_dir, "local.db"),
            sidecar_source=ext_path,
            sidecar_tables=[
                rhei.TimestampTableConfig(
                    table_name="users",
                    primary_key=["id"],
                    columns=["id", "name", "age", "created_at", "updated_at"],
                )
            ],
            sidecar_poll_batch_size=100,
            sidecar_enable_oltp=False,
        )
        engine = rhei.HtapEngine(config)

        # Register the OLAP schema
        schema = rhei.TableSchema(
            "users",
            [
                ("id", "int64"),
                ("name", "utf8"),
                ("age", "int64"),
                ("created_at", "int64"),
                ("updated_at", "int64"),
            ],
            ["id"],
        )
        await engine.register_table(schema)

        # Sync
        result = await engine.sync_now()
        assert result.events_processed >= 2
        assert result.rows_inserted >= 2

        # Verify OLAP data
        batches = await engine.query_olap(
            "SELECT name FROM users ORDER BY id"
        )
        table = pa.Table.from_batches(batches)
        assert table.column("name").to_pylist() == ["Alice", "Bob"]

        ext_conn.close()
        engine.shutdown()

    @pytest.mark.anyio
    async def test_sidecar_update_sync(self, tmp_dir):
        """Update a row in external DB, sync, verify OLAP reflects change."""
        ext_path = os.path.join(tmp_dir, "external.db")
        ext_conn = _create_external_db(ext_path)

        now = _next_ts()
        ext_conn.execute(
            "INSERT INTO users VALUES (1, 'Alice', 30, ?, ?)", (now, now)
        )
        ext_conn.commit()

        config = rhei.HtapConfig(
            oltp_path=os.path.join(tmp_dir, "local.db"),
            sidecar_source=ext_path,
            sidecar_tables=[
                rhei.TimestampTableConfig(
                    table_name="users",
                    primary_key=["id"],
                    columns=["id", "name", "age", "created_at", "updated_at"],
                )
            ],
        )
        engine = rhei.HtapEngine(config)

        schema = rhei.TableSchema(
            "users",
            [
                ("id", "int64"),
                ("name", "utf8"),
                ("age", "int64"),
                ("created_at", "int64"),
                ("updated_at", "int64"),
            ],
            ["id"],
        )
        await engine.register_table(schema)
        await engine.sync_now()

        # Update the row in the external DB
        later = _next_ts()
        ext_conn.execute(
            "UPDATE users SET age = 31, updated_at = ? WHERE id = 1", (later,)
        )
        ext_conn.commit()

        result = await engine.sync_now()
        assert result.events_processed >= 1

        # The key assertion: OLAP has the updated value
        batches = await engine.query_olap("SELECT age FROM users WHERE id = 1")
        assert batches[0].to_pydict()["age"] == [31]

        ext_conn.close()
        engine.shutdown()


@_skip_e2e
class TestSidecarTemporal:
    @pytest.mark.anyio
    async def test_temporal_insert_and_update(self, tmp_dir):
        """Temporal mode: inserts + updates produce versioned rows."""
        ext_path = os.path.join(tmp_dir, "external.db")
        ext_conn = _create_external_db(ext_path)

        now = _next_ts()
        ext_conn.execute(
            "INSERT INTO users VALUES (1, 'Alice', 30, ?, ?)", (now, now)
        )
        ext_conn.commit()

        config = rhei.HtapConfig(
            oltp_path=os.path.join(tmp_dir, "local.db"),
            sync_mode="temporal",
            sidecar_source=ext_path,
            sidecar_tables=[
                rhei.TimestampTableConfig(
                    table_name="users",
                    primary_key=["id"],
                    columns=["id", "name", "age", "created_at", "updated_at"],
                )
            ],
        )
        engine = rhei.HtapEngine(config)

        # Temporal schemas get extra columns added by register_table
        schema = rhei.TableSchema(
            "users",
            [
                ("id", "int64"),
                ("name", "utf8"),
                ("age", "int64"),
                ("created_at", "int64"),
                ("updated_at", "int64"),
            ],
            ["id"],
        )
        await engine.register_table(schema)

        # First sync: initial insert
        result = await engine.sync_now()
        assert result.rows_inserted >= 1

        # Update the row
        later = _next_ts()
        ext_conn.execute(
            "UPDATE users SET age = 31, updated_at = ? WHERE id = 1", (later,)
        )
        ext_conn.commit()

        # Second sync: should create a new version
        result = await engine.sync_now()
        assert result.events_processed >= 1

        # Query all versions — temporal mode keeps history
        batches = await engine.query_olap(
            "SELECT id, age, _rhei_operation FROM users ORDER BY _rhei_valid_from"
        )
        table = pa.Table.from_batches(batches)
        # Should have at least 2 rows: the original insert and the update version
        assert table.num_rows >= 2

        # Current version query (point-in-time: valid_to IS NULL)
        batches = await engine.query_olap(
            "SELECT age FROM users WHERE id = 1 AND _rhei_valid_to IS NULL"
        )
        table = pa.Table.from_batches(batches)
        ages = table.column("age").to_pylist()
        assert 31 in ages

        ext_conn.close()
        engine.shutdown()


class TestConfigValidation:
    def test_timestamp_table_config_repr(self):
        tc = rhei.TimestampTableConfig(
            table_name="orders", primary_key=["order_id"]
        )
        assert "TimestampTableConfig" in repr(tc)
        assert "orders" in repr(tc)

    def test_config_with_sidecar_repr(self):
        config = rhei.HtapConfig(
            sidecar_source="/tmp/ext.db",
            sidecar_tables=[
                rhei.TimestampTableConfig(
                    table_name="t1", primary_key=["id"]
                )
            ],
        )
        assert "datafusion" in repr(config)

    def test_invalid_sync_mode(self):
        with pytest.raises(ValueError, match="invalid sync_mode"):
            rhei.HtapConfig(sync_mode="bad")

    def test_invalid_olap_backend(self):
        with pytest.raises(ValueError, match="invalid olap_backend"):
            rhei.HtapConfig(olap_backend="sqlite")

    def test_invalid_storage_mode(self):
        with pytest.raises(ValueError, match="invalid storage_mode"):
            rhei.HtapConfig(storage_mode="rocks")

    def test_legacy_storage_mode_arrow_ipc_rejected(self):
        # v2.0 dropped arrow_ipc / parquet / s3-parquet / gcs-parquet —
        # they're now subsumed by the unified `vortex` mode.
        with pytest.raises(ValueError, match="invalid storage_mode"):
            rhei.HtapConfig(storage_mode="arrow_ipc")

    def test_legacy_storage_mode_parquet_rejected(self):
        with pytest.raises(ValueError, match="invalid storage_mode"):
            rhei.HtapConfig(storage_mode="parquet")

    def test_storage_path_required_for_vortex(self):
        with pytest.raises(ValueError, match="storage_path is required"):
            rhei.HtapConfig(storage_mode="vortex")

    def test_vortex_local_path_accepted(self):
        config = rhei.HtapConfig(
            storage_mode="vortex",
            storage_path="/var/lib/rhei/data",
        )
        assert "vortex" in repr(config)

    def test_invalid_delete_detection(self):
        with pytest.raises(ValueError, match="invalid sidecar_delete_detection"):
            rhei.HtapConfig(sidecar_delete_detection="bad")

    def test_valid_soft_delete(self):
        config = rhei.HtapConfig(
            sidecar_delete_detection="soft_delete:deleted_at"
        )
        assert config is not None
