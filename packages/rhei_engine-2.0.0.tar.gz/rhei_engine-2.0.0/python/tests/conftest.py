import pytest


@pytest.fixture(params=["asyncio"])
def anyio_backend(request):
    """Only test with asyncio backend (pyo3-async-runtimes requires asyncio)."""
    return request.param
