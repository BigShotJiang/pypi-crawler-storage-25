"""E2E tests for Rhei Python bindings (async API via anyio)."""

import os
import shutil
import tempfile

import anyio
import pyarrow as pa
import pytest

import rhei


@pytest.fixture
async def engine():
    """Create a fresh HtapEngine with a temp database (non-blocking init)."""
    tmp = tempfile.mkdtemp()
    async with await rhei.open(oltp_path=os.path.join(tmp, "test.db")) as eng:
        yield eng
    shutil.rmtree(tmp, ignore_errors=True)


@pytest.fixture
async def users_engine(engine):
    """Engine with a `users` table registered."""
    await engine.execute(
        "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)"
    )
    schema = rhei.TableSchema(
        "users",
        [("id", "int64"), ("name", "utf8"), ("age", "int64")],
        ["id"],
    )
    await engine.register_table(schema)
    return engine


class TestBasic:
    def test_version(self):
        assert rhei.__version__ == "2.0.0"

    def test_config_defaults(self):
        config = rhei.HtapConfig()
        assert repr(config).startswith("HtapConfig(")

    def test_schema_repr(self):
        schema = rhei.TableSchema(
            "t", [("id", "int64"), ("val", "utf8")], ["id"]
        )
        assert "TableSchema" in repr(schema)

    @pytest.mark.anyio
    async def test_open_factory(self):
        """Test rhei.open() async factory + context manager."""
        import tempfile, shutil
        tmp = tempfile.mkdtemp()
        try:
            async with await rhei.open(oltp_path=os.path.join(tmp, "test.db")) as engine:
                await engine.execute(
                    "CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)"
                )
                schema = rhei.TableSchema("t", [("id", "int64"), ("v", "utf8")], ["id"])
                await engine.register_table(schema)
                await engine.execute("INSERT INTO t VALUES (1, 'hello')")
                result = await engine.sync_now()
                assert result.events_processed >= 1
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @pytest.mark.anyio
    async def test_execute_batch(self, users_engine):
        """Test batch execution (single transaction, much faster)."""
        engine = users_engine
        stmts = [f"INSERT INTO users VALUES ({i}, 'User{i}', {20+i})" for i in range(1, 51)]
        await engine.execute_batch(stmts)
        result = await engine.sync_now()
        assert result.rows_inserted >= 50


class TestCRUD:
    @pytest.mark.anyio
    async def test_insert_sync_query(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")

        result = await engine.sync_now()
        assert result.rows_inserted >= 2

        batches = await engine.query("SELECT name FROM users WHERE id = 1")
        assert len(batches) == 1
        assert batches[0].to_pydict()["name"] == ["Alice"]

    @pytest.mark.anyio
    async def test_update_sync(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.sync_now()

        await engine.execute("UPDATE users SET age = 31 WHERE id = 1")
        result = await engine.sync_now()
        assert result.rows_updated == 1

        batches = await engine.query_olap("SELECT age FROM users WHERE id = 1")
        assert batches[0].to_pydict()["age"] == [31]

    @pytest.mark.anyio
    async def test_delete_sync(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")
        await engine.sync_now()

        await engine.execute("DELETE FROM users WHERE id = 1")
        result = await engine.sync_now()
        assert result.rows_deleted == 1

        batches = await engine.query_olap("SELECT COUNT(*) as cnt FROM users")
        assert batches[0].to_pydict()["cnt"] == [1]


class TestAnalytics:
    @pytest.mark.anyio
    async def test_aggregate_query(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")
        await engine.execute("INSERT INTO users VALUES (3, 'Charlie', 35)")
        await engine.sync_now()

        batches = await engine.query("SELECT AVG(age) as avg_age FROM users")
        avg = batches[0].to_pydict()["avg_age"][0]
        assert abs(avg - 30.0) < 0.01

    @pytest.mark.anyio
    async def test_min_max(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")
        await engine.execute("INSERT INTO users VALUES (3, 'Charlie', 35)")
        await engine.sync_now()

        batches = await engine.query(
            "SELECT MIN(age) as min_age, MAX(age) as max_age FROM users"
        )
        data = batches[0].to_pydict()
        assert data["min_age"] == [25]
        assert data["max_age"] == [35]


class TestArrowInterop:
    @pytest.mark.anyio
    async def test_returns_pyarrow_recordbatch(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.sync_now()

        batches = await engine.query_olap("SELECT * FROM users")
        assert len(batches) >= 1
        batch = batches[0]
        assert isinstance(batch, pa.RecordBatch)
        assert "id" in batch.schema.names
        assert "name" in batch.schema.names
        assert "age" in batch.schema.names

    @pytest.mark.anyio
    async def test_pyarrow_to_table(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")
        await engine.sync_now()

        batches = await engine.query_olap("SELECT * FROM users ORDER BY id")
        table = pa.Table.from_batches(batches)
        assert table.num_rows == 2
        assert table.column("name").to_pylist() == ["Alice", "Bob"]


class TestSchemaEvolution:
    @pytest.mark.anyio
    async def test_add_column(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.sync_now()

        await engine.execute("ALTER TABLE users ADD COLUMN email TEXT")
        await engine.add_column("users", "email", "utf8")

        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25, 'bob@x.com')")
        await engine.sync_now()

        batches = await engine.query_olap("SELECT email FROM users WHERE id = 2")
        assert batches[0].to_pydict()["email"] == ["bob@x.com"]

    @pytest.mark.anyio
    async def test_drop_column(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.sync_now()

        await engine.drop_column("users", "age")

        await engine.execute("INSERT INTO users VALUES (2, 'Bob')")
        await engine.sync_now()

        batches = await engine.query_olap("SELECT * FROM users WHERE id = 2")
        assert "age" not in batches[0].schema.names


class TestSyncStatus:
    @pytest.mark.anyio
    async def test_sync_result_repr(self, users_engine):
        engine = users_engine
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        result = await engine.sync_now()
        assert "SyncResult" in repr(result)
        assert result.events_processed >= 1

    @pytest.mark.anyio
    async def test_sync_status(self, users_engine):
        engine = users_engine
        status = await engine.sync_status()
        assert "SyncStatus" in repr(status)
        assert hasattr(status, "lag")


class TestInitialSync:
    @pytest.mark.anyio
    async def test_initial_sync(self, engine):
        await engine.execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)"
        )
        await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
        await engine.execute("INSERT INTO users VALUES (2, 'Bob', 25)")

        schema = rhei.TableSchema(
            "users",
            [("id", "int64"), ("name", "utf8"), ("age", "int64")],
            ["id"],
        )
        await engine.register_table(schema)

        rows = await engine.initial_sync("users")
        assert rows == 2

        batches = await engine.query_olap("SELECT COUNT(*) as cnt FROM users")
        assert batches[0].to_pydict()["cnt"] == [2]


class TestErrorHandling:
    @pytest.mark.anyio
    async def test_duplicate_registration_matching_schema_is_idempotent(self, users_engine):
        # Re-registering the exact same schema must succeed (rh-serve restart case).
        same = rhei.TableSchema(
            "users",
            [("id", "int64"), ("name", "utf8"), ("age", "int64")],
            ["id"],
        )
        await users_engine.register_table(same)

    @pytest.mark.anyio
    async def test_duplicate_registration_conflicting_schema_errors(self, users_engine):
        # A schema with a different column type for an existing column must error.
        conflicting = rhei.TableSchema(
            "users",
            [("id", "int64"), ("name", "utf8"), ("age", "float64")],  # age was int64
            ["id"],
        )
        with pytest.raises(Exception, match="different schema"):
            await users_engine.register_table(conflicting)

    @pytest.mark.anyio
    async def test_drop_pk_column(self, users_engine):
        with pytest.raises(Exception, match="primary key"):
            await users_engine.drop_column("users", "id")

    def test_invalid_type(self):
        with pytest.raises(Exception, match="unknown type"):
            rhei.TableSchema("t", [("id", "nonexistent_type")], ["id"])
