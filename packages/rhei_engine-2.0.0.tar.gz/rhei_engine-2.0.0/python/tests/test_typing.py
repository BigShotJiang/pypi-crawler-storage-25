"""Tests that verify Python type stubs (.pyi) match the runtime API."""

import inspect
import os
import pathlib
import shutil
import tempfile

import pyarrow as pa
import pytest

import rhei


class TestPep561:
    """Verify PEP 561 type stub infrastructure."""

    def test_py_typed_marker_exists(self):
        pkg_dir = pathlib.Path(rhei.__file__).parent
        assert (pkg_dir / "py.typed").exists(), "py.typed marker missing"

    def test_init_pyi_exists(self):
        pkg_dir = pathlib.Path(rhei.__file__).parent
        assert (pkg_dir / "__init__.pyi").exists(), "__init__.pyi stub missing"

    def test_rhei_pyi_exists(self):
        pkg_dir = pathlib.Path(rhei.__file__).parent
        assert (pkg_dir / "_rhei.pyi").exists(), "_rhei.pyi stub missing"


class TestTypeAnnotations:
    """Verify runtime annotations match stub declarations."""

    def test_htap_engine_execute_annotations(self):
        hints = inspect.get_annotations(rhei.HtapEngine.execute)
        assert "str" in str(hints.get("sql", ""))
        assert "int" in str(hints.get("return", ""))

    def test_htap_engine_execute_batch_annotations(self):
        hints = inspect.get_annotations(rhei.HtapEngine.execute_batch)
        assert "None" in str(hints.get("return", ""))

    def test_htap_engine_sync_now_return(self):
        hints = inspect.get_annotations(rhei.HtapEngine.sync_now)
        assert "SyncResult" in str(hints.get("return", ""))

    def test_htap_engine_query_annotations(self):
        hints = inspect.get_annotations(rhei.HtapEngine.query)
        assert "str" in str(hints.get("sql", ""))

    def test_htap_engine_create_classmethod(self):
        assert hasattr(rhei.HtapEngine, "create")
        assert inspect.iscoroutinefunction(rhei.HtapEngine.create)

    def test_htap_engine_is_async_context_manager(self):
        assert hasattr(rhei.HtapEngine, "__aenter__")
        assert hasattr(rhei.HtapEngine, "__aexit__")

    def test_open_is_coroutine_function(self):
        assert inspect.iscoroutinefunction(rhei.open)

    def test_open_annotations(self):
        hints = inspect.get_annotations(rhei.open)
        assert "str" in str(hints.get("oltp_path", ""))
        assert "bool" in str(hints.get("prune_after_sync", ""))
        assert "int" in str(hints.get("sync_batch_size", ""))
        assert "HtapEngine" in str(hints.get("return", ""))


class TestSyncResultProperties:
    """Verify SyncResult has all typed properties."""

    @pytest.mark.anyio
    async def test_sync_result_fields(self):
        tmp = tempfile.mkdtemp()
        try:
            async with await rhei.open(oltp_path=os.path.join(tmp, "t.db")) as engine:
                await engine.execute("CREATE TABLE t (id INTEGER PRIMARY KEY)")
                await engine.register_table(
                    rhei.TableSchema("t", [("id", "int64")], ["id"])
                )
                await engine.execute("INSERT INTO t VALUES (1)")
                result = await engine.sync_now()

                # All properties exist and have correct types
                assert isinstance(result.events_processed, int)
                assert isinstance(result.rows_inserted, int)
                assert isinstance(result.rows_updated, int)
                assert isinstance(result.rows_deleted, int)
                assert result.pruned_count is None or isinstance(result.pruned_count, int)
                assert isinstance(repr(result), str)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class TestSyncStatusProperties:
    """Verify SyncStatus has all typed properties."""

    @pytest.mark.anyio
    async def test_sync_status_fields(self):
        tmp = tempfile.mkdtemp()
        try:
            async with await rhei.open(oltp_path=os.path.join(tmp, "t.db")) as engine:
                status = await engine.sync_status()
                assert isinstance(status.lag, int)
                assert status.last_synced_seq is None or isinstance(status.last_synced_seq, int)
                assert isinstance(repr(status), str)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class TestQueryReturnTypes:
    """Verify query methods return pyarrow.RecordBatch."""

    @pytest.mark.anyio
    async def test_query_returns_recordbatch_list(self):
        tmp = tempfile.mkdtemp()
        try:
            async with await rhei.open(oltp_path=os.path.join(tmp, "t.db")) as engine:
                await engine.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)")
                await engine.register_table(
                    rhei.TableSchema("t", [("id", "int64"), ("v", "utf8")], ["id"])
                )
                await engine.execute("INSERT INTO t VALUES (1, 'hello')")
                await engine.sync_now()

                batches = await engine.query_olap("SELECT * FROM t")
                assert isinstance(batches, list)
                assert len(batches) >= 1
                assert isinstance(batches[0], pa.RecordBatch)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class TestConfigTypes:
    """Verify config constructors accept correct types."""

    def test_htap_config_all_defaults(self):
        config = rhei.HtapConfig()
        assert isinstance(repr(config), str)

    def test_table_schema_types(self):
        schema = rhei.TableSchema("t", [("id", "int64"), ("name", "utf8")], ["id"])
        assert isinstance(repr(schema), str)

    def test_timestamp_table_config_types(self):
        ttc = rhei.TimestampTableConfig("users", ["id"])
        assert isinstance(repr(ttc), str)

    def test_timestamp_table_config_with_all_args(self):
        ttc = rhei.TimestampTableConfig(
            "users",
            ["id"],
            created_at_column="created_at",
            updated_at_column="updated_at",
            columns=["id", "name"],
        )
        assert isinstance(repr(ttc), str)
