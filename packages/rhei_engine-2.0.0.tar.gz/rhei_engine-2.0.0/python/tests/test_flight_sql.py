"""
FlightSQL client tests for Rhei's Arrow Flight SQL server.

These tests start a Rhei HTAP engine with FlightSQL enabled, then connect
with the Python ADBC FlightSQL driver to verify queries work end-to-end.

Requirements:
    pip install adbc-driver-flightsql pyarrow

Run:
    RHEI_TEST_FLIGHT=1 uv run pytest python/tests/test_flight_sql.py -v -s
"""

import os
import subprocess
import time
import signal
import socket
import tempfile

import pyarrow as pa
import pytest

# Skip all tests unless RHEI_TEST_FLIGHT is set
pytestmark = pytest.mark.skipif(
    os.environ.get("RHEI_TEST_FLIGHT") != "1",
    reason="set RHEI_TEST_FLIGHT=1 to run FlightSQL tests",
)


def find_free_port() -> int:
    """Find a free TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def flight_server():
    """Start a rh serve process with FlightSQL enabled."""
    port = find_free_port()
    tmpdir = tempfile.mkdtemp()
    db_path = os.path.join(tmpdir, "test.db")

    config_content = f"""
[engine]
oltp_path = "{db_path}"
olap_backend = "datafusion"
olap_in_memory = true
sync_interval_ms = 200
flight_port = {port}

[[tables]]
name = "users"
ddl = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, age INTEGER NOT NULL)"

[[tables.columns]]
name = "id"
type = "int64"
primary_key = true

[[tables.columns]]
name = "name"
type = "utf8"

[[tables.columns]]
name = "age"
type = "int64"
"""
    config_path = os.path.join(tmpdir, "config.toml")
    with open(config_path, "w") as f:
        f.write(config_content)

    # Find the rh binary
    rh_bin = os.path.join(
        os.path.dirname(__file__), "..", "..", "target", "release", "rh"
    )
    if not os.path.exists(rh_bin):
        rh_bin = os.path.join(
            os.path.dirname(__file__), "..", "..", "target", "debug", "rh"
        )
    if not os.path.exists(rh_bin):
        pytest.skip("rh binary not found (run cargo build -p rhei-tui --features flight-sql)")

    proc = subprocess.Popen(
        [rh_bin, "serve", "--config", config_path, "--headless"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    # Wait for server to start
    for _ in range(50):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.1):
                break
        except (ConnectionRefusedError, OSError):
            time.sleep(0.1)
    else:
        proc.kill()
        pytest.fail("FlightSQL server failed to start")

    # Insert test data via rh exec
    for i in range(1, 11):
        subprocess.run(
            [
                rh_bin,
                "exec",
                "--db",
                db_path,
                f"INSERT INTO users VALUES ({i}, 'user_{i}', {20 + i})",
            ],
            capture_output=True,
        )

    # Wait for background sync to replicate all rows (200ms interval)
    time.sleep(2.0)

    yield {"port": port, "db_path": db_path, "rh_bin": rh_bin}

    proc.send_signal(signal.SIGTERM)
    proc.wait(timeout=5)


@pytest.fixture
def conn(flight_server):
    """Create an ADBC FlightSQL connection."""
    import adbc_driver_flightsql.dbapi as flight_sql

    uri = f"grpc://127.0.0.1:{flight_server['port']}"
    connection = flight_sql.connect(uri)
    yield connection
    connection.close()


class TestFlightSqlAdbc:
    """Tests using the ADBC FlightSQL driver (DB-API 2)."""

    def test_simple_query(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users")
        table = cursor.fetch_arrow_table()
        assert table.num_rows >= 10
        assert table.num_columns == 3
        assert table.column_names == ["id", "name", "age"]

    def test_filtered_query(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM users WHERE id = 1")
        table = cursor.fetch_arrow_table()
        assert table.num_rows == 1
        assert table.column("name")[0].as_py() == "user_1"

    def test_aggregate_query(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt, AVG(age) as avg_age FROM users WHERE id <= 10")
        table = cursor.fetch_arrow_table()
        assert table.num_rows == 1
        assert table.column("cnt")[0].as_py() == 10

    def test_filtered_count(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM users WHERE id <= 10")
        table = cursor.fetch_arrow_table()
        assert table.column("cnt")[0].as_py() == 10

    def test_arrow_types(self, conn):
        """Verify Arrow types are preserved through FlightSQL."""
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, age FROM users LIMIT 1")
        table = cursor.fetch_arrow_table()
        assert table.schema.field("id").type == pa.int64()
        assert table.schema.field("name").type == pa.utf8()
        assert table.schema.field("age").type == pa.int64()

    def test_order_by(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM users ORDER BY id DESC LIMIT 3")
        table = cursor.fetch_arrow_table()
        names = [table.column("name")[i].as_py() for i in range(3)]
        assert names == ["user_10", "user_9", "user_8"]

    def test_group_by(self, conn):
        cursor = conn.cursor()
        cursor.execute(
            "SELECT age, COUNT(*) as cnt FROM users WHERE id <= 10 GROUP BY age ORDER BY age"
        )
        table = cursor.fetch_arrow_table()
        assert table.num_rows == 10  # Each of the first 10 users has a unique age

    def test_write_rejected(self, conn):
        """Write operations should fail or produce no effect (OLAP is read-only)."""
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users VALUES (99, 'hacker', 99)")
            # If it doesn't raise, verify the row wasn't actually inserted
            cursor.execute("SELECT COUNT(*) as cnt FROM users WHERE id = 99")
            table = cursor.fetch_arrow_table()
            assert table.column("cnt")[0].as_py() == 0
        except Exception:
            pass  # Expected: server rejects writes

    def test_fetchall(self, conn):
        """Test DB-API fetchall() method."""
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM users WHERE id <= 3 ORDER BY id")
        rows = cursor.fetchall()
        assert len(rows) == 3
        assert rows[0][1] == "user_1"

    def test_to_pydict(self, conn):
        """Test conversion to Python dict."""
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, age FROM users WHERE id <= 10 ORDER BY id")
        table = cursor.fetch_arrow_table()
        d = table.to_pydict()
        assert len(d["id"]) == 10
        assert d["name"][0] == "user_1"
        assert d["age"][0] == 21


class TestFlightSqlBenchmark:
    """OLAP benchmark: measures FlightSQL query + data transfer throughput."""

    def test_aggregate_throughput(self, conn):
        """Aggregate queries — measures query overhead (small result)."""
        import time

        cursor = conn.cursor()
        sql = "SELECT age, COUNT(*) as cnt FROM users WHERE id <= 10 GROUP BY age"

        # Warmup
        cursor.execute(sql)
        cursor.fetch_arrow_table()

        iterations = 200
        start = time.perf_counter()
        for _ in range(iterations):
            cursor.execute(sql)
            cursor.fetch_arrow_table()
        elapsed = time.perf_counter() - start

        print(f"\n  Aggregate (GROUP BY, 10 result rows):")
        print(f"    {iterations / elapsed:.0f} queries/sec ({elapsed * 1000 / iterations:.1f}ms/query)")

    def test_full_scan_throughput(self, conn):
        """Full scan — measures data transfer throughput."""
        import time

        cursor = conn.cursor()
        sql = "SELECT * FROM users"

        # Warmup
        cursor.execute(sql)
        cursor.fetch_arrow_table()

        iterations = 100
        total_rows = 0
        total_bytes = 0
        start = time.perf_counter()
        for _ in range(iterations):
            cursor.execute(sql)
            table = cursor.fetch_arrow_table()
            total_rows += table.num_rows
            total_bytes += table.nbytes
        elapsed = time.perf_counter() - start

        mb = total_bytes / 1_048_576
        print(f"\n  Full scan ({total_rows // iterations} rows/query):")
        print(f"    {iterations / elapsed:.0f} queries/sec, {total_rows / elapsed:.0f} rows/sec")
        print(f"    {mb / elapsed:.1f} MB/sec transferred")
