//! # rhei-python — PyO3 bindings for the Rhei HTAP engine
//!
//! This crate exposes Rhei's HTAP (Hybrid Transactional/Analytical Processing)
//! engine to Python via [PyO3](https://pyo3.rs/) and
//! [`pyo3-async-runtimes`](https://docs.rs/pyo3-async-runtimes/) with a fully
//! async API compatible with both `asyncio` and `anyio`.
//!
//! ## Rust-contributor overview
//!
//! The public surface is a single `cdylib` (`_rhei`) that is imported by the
//! Python `rhei` package.  Every I/O method on `PyHtapEngine` is an async
//! Python awaitable, bridged to Rust's Tokio runtime via
//! `pyo3_async_runtimes::tokio::future_into_py`.
//!
//! The crate does **not** use `unsafe` beyond the `unsafe impl Send/Sync` that
//! is hidden inside the `rhei-duckdb` dependency — this crate itself is safe.
//!
//! ### Runtime initialisation
//!
//! A single multi-threaded Tokio runtime is created at module import time by
//! `init_runtime` (called from the `#[pymodule]` entry point) and leaked
//! as a `'static` reference so that `pyo3-async-runtimes` can hold it.
//! Subsequent calls are no-ops thanks to `std::sync::Once`.
//!
//! ### Type mapping
//!
//! | Python value | Rust representation |
//! |---|---|
//! | `bool` | `serde_json::Value::Bool` |
//! | `int` | `serde_json::Value::Number(i64)` (falls back to `String` for wide ints) |
//! | `float` | `serde_json::Value::Number` (`NaN`/`Inf` → `String`) |
//! | `None` | `serde_json::Value::Null` |
//! | anything else | `serde_json::Value::String` via `__str__` |
//!
//! Arrow schema columns use a small string-to-`arrow::datatypes::DataType`
//! mapping in `parse_arrow_type`.  Only scalar types are supported; Date,
//! Timestamp, Decimal, List, and Struct columns fall back to the SQL path in
//! the sync engine.
//!
//! ### Query results
//!
//! `PyHtapEngine::query` and `PyHtapEngine::query_olap` return a Python
//! `list[pyarrow.RecordBatch]` via the Arrow PyArrow FFI bridge
//! (`arrow::pyarrow::ToPyArrow`).  The conversion requires the GIL and is
//! performed inside `Python::attach` after the async Tokio future completes.
//!
//! ## Building
//!
//! ```sh
//! uv run maturin develop          # editable install
//! uv run maturin develop --release  # optimised build
//! ```
//!
//! ## Testing
//!
//! ```sh
//! uv run pytest -v                 # 33 tests (async via anyio)
//! RHEI_TEST_E2E=1 uv run pytest -v -s  # includes SoP + sidecar E2E
//! ```
//!
//! **Note:** `cargo test --doc` is unsupported here because the crate is a
//! `cdylib` — cargo emits `error: doc tests are not supported for crate
//! type(s) cdylib` regardless of environment.  Python-facing documentation
//! lives in `README.md` and `.pyi` stubs; the Rust `///` docs here are for
//! Rust-side contributors only.
//!
//! ## Feature flags
//!
//! | Feature | Default | Description |
//! |---|---|---|
//! | `datafusion-backend` | yes | Enables the DataFusion OLAP backend |
//! | `duckdb-backend` | no | Enables the DuckDB OLAP backend |
//! | `sidecar` | yes | Enables timestamp-based CDC from external DBs |

use std::sync::Arc;

use arrow::datatypes::{DataType, Field, Schema, SchemaRef};
use arrow::pyarrow::ToPyArrow;
use arrow::record_batch::RecordBatch;
use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyList;

use rhei::{HtapConfig, HtapEngine, OlapBackendType, OlapEngine};
use rhei_core::TableSchema;

// ---------------------------------------------------------------------------
// Tokio runtime — shared with pyo3-async-runtimes
// ---------------------------------------------------------------------------

/// Initialize the tokio runtime and register it with pyo3-async-runtimes.
/// Called once from the module init. The runtime is leaked to get a 'static ref.
fn init_runtime() {
    static INIT: std::sync::Once = std::sync::Once::new();
    INIT.call_once(|| {
        let rt = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("failed to create Tokio runtime");
        let rt_static: &'static tokio::runtime::Runtime = Box::leak(Box::new(rt));
        pyo3_async_runtimes::tokio::init_with_runtime(rt_static)
            .expect("tokio runtime already initialized");
    });
}

/// Get the shared tokio runtime (must call init_runtime first).
fn runtime() -> &'static tokio::runtime::Runtime {
    pyo3_async_runtimes::tokio::get_runtime()
}

// ---------------------------------------------------------------------------
// Arrow DataType mapping from Python strings
// ---------------------------------------------------------------------------

fn parse_arrow_type(s: &str) -> PyResult<DataType> {
    match s.to_lowercase().as_str() {
        "int8" => Ok(DataType::Int8),
        "int16" => Ok(DataType::Int16),
        "int32" | "int" => Ok(DataType::Int32),
        "int64" | "bigint" => Ok(DataType::Int64),
        "uint8" => Ok(DataType::UInt8),
        "uint16" => Ok(DataType::UInt16),
        "uint32" => Ok(DataType::UInt32),
        "uint64" => Ok(DataType::UInt64),
        "float16" | "half" => Ok(DataType::Float16),
        "float32" | "float" => Ok(DataType::Float32),
        "float64" | "double" => Ok(DataType::Float64),
        "utf8" | "string" | "text" => Ok(DataType::Utf8),
        "bool" | "boolean" => Ok(DataType::Boolean),
        "binary" | "bytes" => Ok(DataType::Binary),
        _ => Err(PyValueError::new_err(format!("unknown type: {s}"))),
    }
}

// ---------------------------------------------------------------------------
// SyncResult
// ---------------------------------------------------------------------------

/// Result of a CDC sync cycle.
#[pyclass(frozen, skip_from_py_object)]
#[derive(Clone)]
struct SyncResult {
    #[pyo3(get)]
    events_processed: u64,
    #[pyo3(get)]
    rows_inserted: u64,
    #[pyo3(get)]
    rows_updated: u64,
    #[pyo3(get)]
    rows_deleted: u64,
    #[pyo3(get)]
    pruned_count: Option<u64>,
}

#[pymethods]
impl SyncResult {
    fn __repr__(&self) -> String {
        format!(
            "SyncResult(events={}, inserted={}, updated={}, deleted={}, pruned={:?})",
            self.events_processed,
            self.rows_inserted,
            self.rows_updated,
            self.rows_deleted,
            self.pruned_count,
        )
    }
}

impl From<rhei_core::types::SyncResult> for SyncResult {
    fn from(r: rhei_core::types::SyncResult) -> Self {
        Self {
            events_processed: r.events_processed,
            rows_inserted: r.rows_inserted,
            rows_updated: r.rows_updated,
            rows_deleted: r.rows_deleted,
            pruned_count: r.pruned_count,
        }
    }
}

// ---------------------------------------------------------------------------
// SyncStatus
// ---------------------------------------------------------------------------

/// Status of the sync engine.
#[pyclass(frozen, skip_from_py_object)]
#[derive(Clone)]
struct SyncStatus {
    #[pyo3(get)]
    lag: u64,
    #[pyo3(get)]
    last_synced_seq: Option<i64>,
}

#[pymethods]
impl SyncStatus {
    fn __repr__(&self) -> String {
        format!(
            "SyncStatus(lag={}, last_seq={:?})",
            self.lag, self.last_synced_seq,
        )
    }
}

impl From<rhei_core::types::SyncStatus> for SyncStatus {
    fn from(s: rhei_core::types::SyncStatus) -> Self {
        Self {
            lag: s.lag,
            last_synced_seq: s.last_synced_seq,
        }
    }
}

// ---------------------------------------------------------------------------
// TableSchema
// ---------------------------------------------------------------------------

/// Schema definition for table registration.
///
/// Args:
///     name: Table name
///     columns: List of (column_name, type_string) tuples
///     pk: List of primary key column names
#[pyclass(name = "TableSchema", frozen, from_py_object)]
#[derive(Clone)]
struct PyTableSchema {
    name: String,
    columns: Vec<(String, DataType)>,
    pk: Vec<String>,
}

#[pymethods]
impl PyTableSchema {
    #[new]
    #[pyo3(signature = (name, columns, pk))]
    fn new(name: String, columns: Vec<(String, String)>, pk: Vec<String>) -> PyResult<Self> {
        let parsed: Vec<(String, DataType)> = columns
            .into_iter()
            .map(|(col, ty)| {
                let dt = parse_arrow_type(&ty)?;
                Ok((col, dt))
            })
            .collect::<PyResult<_>>()?;
        Ok(Self {
            name,
            columns: parsed,
            pk,
        })
    }

    fn __repr__(&self) -> String {
        format!(
            "TableSchema(name='{}', columns={}, pk={:?})",
            self.name,
            self.columns.len(),
            self.pk,
        )
    }
}

impl PyTableSchema {
    fn to_core(&self) -> TableSchema {
        let fields: Vec<Field> = self
            .columns
            .iter()
            .map(|(name, dt)| {
                let nullable = !self.pk.contains(name);
                Field::new(name, dt.clone(), nullable)
            })
            .collect();
        let schema: SchemaRef = Arc::new(Schema::new(fields));
        TableSchema::new(&self.name, schema, self.pk.clone())
    }
}

// ---------------------------------------------------------------------------
// TimestampTableConfig — always defined; sidecar conversion is gated
// ---------------------------------------------------------------------------

/// Per-table configuration for sidecar timestamp-based CDC polling.
///
/// Args:
///     table_name: Table name in the external source
///     primary_key: Primary key column names
///     created_at_column: Column name for creation timestamp (default: "created_at")
///     updated_at_column: Column name for update timestamp (default: "updated_at")
///     columns: Column names to SELECT (empty = SELECT *)
#[pyclass(name = "TimestampTableConfig", frozen, from_py_object)]
#[derive(Clone)]
struct PyTimestampTableConfig {
    table_name: String,
    created_at_column: String,
    updated_at_column: String,
    primary_key: Vec<String>,
    columns: Vec<String>,
}

#[pymethods]
impl PyTimestampTableConfig {
    #[new]
    #[pyo3(signature = (table_name, primary_key, created_at_column="created_at", updated_at_column="updated_at", columns=vec![]))]
    fn new(
        table_name: String,
        primary_key: Vec<String>,
        created_at_column: &str,
        updated_at_column: &str,
        columns: Vec<String>,
    ) -> Self {
        Self {
            table_name,
            created_at_column: created_at_column.to_string(),
            updated_at_column: updated_at_column.to_string(),
            primary_key,
            columns,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "TimestampTableConfig(table='{}', pk={:?})",
            self.table_name, self.primary_key,
        )
    }
}

#[cfg(feature = "sidecar")]
impl PyTimestampTableConfig {
    fn to_rust(&self) -> rhei::TimestampTableConfig {
        rhei::TimestampTableConfig {
            table_name: self.table_name.clone(),
            created_at_column: self.created_at_column.clone(),
            updated_at_column: self.updated_at_column.clone(),
            primary_key: self.primary_key.clone(),
            columns: self.columns.clone(),
        }
    }
}

// ---------------------------------------------------------------------------
// HtapConfig
// ---------------------------------------------------------------------------

/// Configuration for the HTAP engine.
///
/// Supports standard HTAP mode (OLTP + CDC + OLAP) and sidecar mode
/// (external DB polling). Configure the OLAP backend, storage mode,
/// sync mode, and sidecar settings.
#[pyclass(name = "HtapConfig", frozen, from_py_object)]
#[derive(Clone)]
struct PyHtapConfig {
    oltp_path: String,
    prune_after_sync: bool,
    sync_batch_size: u32,
    read_pool_size: usize,
    sync_mode: String,
    olap_backend: String,
    storage_mode: String,
    storage_path: Option<String>,
    sidecar_source: Option<String>,
    sidecar_source_type: String,
    sidecar_tables: Option<Vec<PyTimestampTableConfig>>,
    sidecar_poll_batch_size: u32,
    sidecar_delete_detection: String,
    sidecar_enable_oltp: bool,
}

#[pymethods]
impl PyHtapConfig {
    #[new]
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (
        oltp_path="rhei.db",
        prune_after_sync=true,
        sync_batch_size=1000,
        read_pool_size=4,
        sync_mode="destructive",
        olap_backend="datafusion",
        storage_mode="inmemory",
        storage_path=None,
        sidecar_source=None,
        sidecar_tables=None,
        sidecar_poll_batch_size=500,
        sidecar_delete_detection="disabled",
        sidecar_enable_oltp=false,
        sidecar_source_type="sqlite",
    ))]
    fn new(
        oltp_path: &str,
        prune_after_sync: bool,
        sync_batch_size: u32,
        read_pool_size: usize,
        sync_mode: &str,
        olap_backend: &str,
        storage_mode: &str,
        storage_path: Option<String>,
        sidecar_source: Option<String>,
        sidecar_tables: Option<Vec<PyTimestampTableConfig>>,
        sidecar_poll_batch_size: u32,
        sidecar_delete_detection: &str,
        sidecar_enable_oltp: bool,
        sidecar_source_type: &str,
    ) -> PyResult<Self> {
        // Validate sync_mode eagerly
        match sync_mode.to_lowercase().as_str() {
            "destructive" | "temporal" => {}
            _ => {
                return Err(PyValueError::new_err(format!(
                    "invalid sync_mode '{}': must be 'destructive' or 'temporal'",
                    sync_mode
                )));
            }
        }
        // Validate olap_backend eagerly
        match olap_backend.to_lowercase().as_str() {
            "datafusion" => {
                #[cfg(not(feature = "datafusion-backend"))]
                return Err(PyValueError::new_err(
                    "olap_backend 'datafusion' requires the 'datafusion-backend' feature",
                ));
            }
            "duckdb" => {
                #[cfg(not(feature = "duckdb-backend"))]
                return Err(PyValueError::new_err(
                    "olap_backend 'duckdb' requires the 'duckdb-backend' feature",
                ));
            }
            _ => {
                return Err(PyValueError::new_err(format!(
                    "invalid olap_backend '{}': must be 'datafusion' or 'duckdb'",
                    olap_backend
                )));
            }
        }
        // Validate storage_mode eagerly. v2.0 collapses the previous five
        // file-format modes into two: 'inmemory' and 'vortex'. The Vortex
        // mode auto-classifies its location as local vs. S3 from the URL
        // prefix (see crates/rhei-datafusion/src/storage.rs).
        match storage_mode.to_lowercase().as_str() {
            "inmemory" | "in_memory" | "memory" => {}
            "vortex" => {
                if storage_path.is_none() {
                    return Err(PyValueError::new_err(
                        "storage_path is required for storage_mode 'vortex' \
                         (use a filesystem path like '/var/lib/rhei' or an \
                         S3 URL like 's3://bucket/prefix')",
                    ));
                }
            }
            _ => {
                return Err(PyValueError::new_err(format!(
                    "invalid storage_mode '{}': must be 'inmemory' or 'vortex'",
                    storage_mode
                )));
            }
        }
        // Validate sidecar_delete_detection eagerly
        let dd_lower = sidecar_delete_detection.to_lowercase();
        if dd_lower != "disabled" && !dd_lower.starts_with("soft_delete:") {
            return Err(PyValueError::new_err(format!(
                "invalid sidecar_delete_detection '{}': must be 'disabled' or 'soft_delete:<column_name>'",
                sidecar_delete_detection
            )));
        }
        // Validate sidecar_source requires sidecar feature
        #[cfg(not(feature = "sidecar"))]
        if sidecar_source.is_some() {
            return Err(PyValueError::new_err(
                "sidecar_source requires the 'sidecar' feature to be enabled",
            ));
        }
        // Validate sidecar_source_type
        match sidecar_source_type.to_lowercase().as_str() {
            "sqlite" | "postgres" => {}
            _ => {
                return Err(PyValueError::new_err(format!(
                    "invalid sidecar_source_type '{}': must be 'sqlite' or 'postgres'",
                    sidecar_source_type
                )));
            }
        }

        Ok(Self {
            oltp_path: oltp_path.to_string(),
            prune_after_sync,
            sync_batch_size,
            read_pool_size,
            sync_mode: sync_mode.to_string(),
            olap_backend: olap_backend.to_string(),
            storage_mode: storage_mode.to_string(),
            storage_path,
            sidecar_source,
            sidecar_source_type: sidecar_source_type.to_string(),
            sidecar_tables,
            sidecar_poll_batch_size,
            sidecar_delete_detection: sidecar_delete_detection.to_string(),
            sidecar_enable_oltp,
        })
    }

    fn __repr__(&self) -> String {
        format!(
            "HtapConfig(oltp_path='{}', olap_backend='{}', storage_mode='{}')",
            self.oltp_path, self.olap_backend, self.storage_mode,
        )
    }
}

impl PyHtapConfig {
    fn to_rust_config(&self) -> PyResult<HtapConfig> {
        let sync_mode = match self.sync_mode.to_lowercase().as_str() {
            "temporal" => rhei_core::types::SyncMode::Temporal,
            _ => rhei_core::types::SyncMode::Destructive,
        };

        let olap_backend = match self.olap_backend.to_lowercase().as_str() {
            #[cfg(feature = "duckdb-backend")]
            "duckdb" => OlapBackendType::DuckDb,
            #[cfg(feature = "datafusion-backend")]
            "datafusion" => OlapBackendType::DataFusion,
            other => {
                return Err(PyValueError::new_err(format!(
                    "unsupported olap_backend '{}'",
                    other
                )));
            }
        };

        #[cfg(feature = "datafusion-backend")]
        let datafusion_storage = match self.storage_mode.to_lowercase().as_str() {
            "vortex" => rhei::StorageMode::Vortex {
                url: self
                    .storage_path
                    .as_deref()
                    .expect("storage_path is required for vortex mode (validated in __new__)")
                    .to_string(),
            },
            _ => rhei::StorageMode::InMemory,
        };

        // Determine if we need a file-backed OLAP (DuckDB)
        let (olap_in_memory, olap_path) = match self.olap_backend.to_lowercase().as_str() {
            "duckdb" => {
                if let Some(ref p) = self.storage_path {
                    (false, Some(p.clone()))
                } else {
                    (true, None)
                }
            }
            _ => (true, None), // DataFusion uses its own StorageMode
        };

        // Build sidecar config if sidecar_source is set
        #[cfg(feature = "sidecar")]
        let sidecar = if let Some(ref source_path) = self.sidecar_source {
            let tables: Vec<rhei::TimestampTableConfig> = self
                .sidecar_tables
                .as_ref()
                .map(|ts| ts.iter().map(|t| t.to_rust()).collect())
                .unwrap_or_default();

            let delete_detection = {
                let dd = self.sidecar_delete_detection.to_lowercase();
                if let Some(col) = dd.strip_prefix("soft_delete:") {
                    rhei::DeleteDetection::SoftDelete {
                        column: col.to_string(),
                    }
                } else {
                    rhei::DeleteDetection::Disabled
                }
            };

            let source = match self.sidecar_source_type.to_lowercase().as_str() {
                "postgres" => rhei::SidecarSource::Postgres(source_path.clone()),
                _ => rhei::SidecarSource::Sqlite(source_path.clone()),
            };

            Some(rhei::SidecarConfig {
                source,
                timestamp_config: rhei::TimestampCdcConfig {
                    tables,
                    poll_batch_size: self.sidecar_poll_batch_size,
                    delete_detection,
                },
                enable_local_oltp: self.sidecar_enable_oltp,
                watermark_path: None,
            })
        } else {
            None
        };

        Ok(HtapConfig {
            oltp_path: self.oltp_path.clone(),
            olap_in_memory,
            olap_path,
            sync_batch_size: self.sync_batch_size,
            prune_after_sync: self.prune_after_sync,
            sync_interval: None,
            olap_backend,
            read_pool_size: self.read_pool_size,
            sync_mode,
            schema_registry_path: None,
            #[cfg(feature = "datafusion-backend")]
            datafusion_storage,
            #[cfg(feature = "sidecar")]
            sidecar,
        })
    }
}

// ---------------------------------------------------------------------------
// HtapEngine — wraps rhei::HtapEngine
// ---------------------------------------------------------------------------

/// Shared engine state that can be moved into `Send + 'static` futures.
struct EngineInner {
    engine: HtapEngine,
}

/// Main HTAP engine — manages OLTP, OLAP, CDC sync, and query routing.
///
/// All I/O methods are async (return Python awaitables). Use with `await`:
///
///     engine = rhei.HtapEngine()
///     await engine.execute("INSERT INTO users VALUES (1, 'Alice', 30)")
///     result = await engine.sync_now()
///     batches = await engine.query("SELECT AVG(age) FROM users")
#[pyclass(name = "HtapEngine")]
struct PyHtapEngine {
    inner: Arc<EngineInner>,
}

#[pymethods]
impl PyHtapEngine {
    /// Create a new HTAP engine (sync — constructor cannot be async).
    #[new]
    #[pyo3(signature = (config=None))]
    fn new(config: Option<PyHtapConfig>) -> PyResult<Self> {
        let config = config.unwrap_or_else(|| {
            PyHtapConfig::new(
                "rhei.db",
                true,
                1000,
                4,
                "destructive",
                "datafusion",
                "inmemory",
                None,
                None,
                None,
                500,
                "disabled",
                false,
                "sqlite",
            )
            .unwrap()
        });

        let rust_config = config.to_rust_config()?;
        let engine = runtime()
            .block_on(HtapEngine::new(rust_config))
            .map_err(to_py_err)?;

        Ok(Self {
            inner: Arc::new(EngineInner { engine }),
        })
    }

    /// Register a table for HTAP replication.
    fn register_table<'py>(
        &self,
        py: Python<'py>,
        schema: PyTableSchema,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);
        let core_schema = schema.to_core();

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            inner
                .engine
                .register_table(core_schema)
                .await
                .map_err(to_py_err)?;
            Ok(())
        })
    }

    /// Execute a write statement (routed to OLTP).
    ///
    /// Parameters are typed: bool, int, float, None, and str are preserved as
    /// their JSON equivalents. Previously all params were stringified.
    #[pyo3(signature = (sql, params=None))]
    fn execute<'py>(
        &self,
        py: Python<'py>,
        sql: String,
        params: Option<Vec<Bound<'py, PyAny>>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);
        let json_params: Vec<serde_json::Value> = params
            .unwrap_or_default()
            .into_iter()
            .map(|val| py_to_json(&val))
            .collect::<PyResult<Vec<_>>>()?;

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let rows: u64 = inner
                .engine
                .execute(&sql, &json_params)
                .await
                .map_err(to_py_err)?;
            Ok(rows)
        })
    }

    /// Execute multiple write statements in a single transaction.
    ///
    /// Much faster than calling execute() in a loop — batching avoids per-statement
    /// fsync overhead (~350 ops/sec → ~18,000+ ops/sec with CDC triggers).
    ///
    /// Args:
    ///     statements: List of SQL strings to execute in one transaction.
    fn execute_batch<'py>(
        &self,
        py: Python<'py>,
        statements: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let stmts: Vec<(String, Vec<serde_json::Value>)> =
                statements.into_iter().map(|s| (s, vec![])).collect();
            inner
                .engine
                .execute_batch(&stmts)
                .await
                .map_err(to_py_err)?;
            Ok(())
        })
    }

    /// Execute a query. Returns a list of PyArrow RecordBatches.
    ///
    /// Analytical queries (aggregates, GROUP BY) route to OLAP.
    /// Point queries (WHERE pk=) route to OLTP.
    fn query<'py>(&self, py: Python<'py>, sql: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let batches: Vec<RecordBatch> = inner.engine.query(&sql).await.map_err(to_py_err)?;
            Python::attach(|py| batches_to_pyarrow_obj(py, &batches))
        })
    }

    /// Force a query to OLAP. Returns a list of PyArrow RecordBatches.
    fn query_olap<'py>(&self, py: Python<'py>, sql: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let batches: Vec<RecordBatch> = OlapEngine::query(inner.engine.olap(), &sql)
                .await
                .map_err(to_py_err)?;
            Python::attach(|py| batches_to_pyarrow_obj(py, &batches))
        })
    }

    /// Sync CDC events to OLAP.
    fn sync_now<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let result: rhei_core::types::SyncResult =
                inner.engine.sync_now().await.map_err(to_py_err)?;
            Ok(SyncResult::from(result))
        })
    }

    /// Get sync status (CDC lag, last synced sequence).
    fn sync_status<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let status: rhei_core::types::SyncStatus =
                inner.engine.sync_status().await.map_err(to_py_err)?;
            Ok(SyncStatus::from(status))
        })
    }

    /// Bulk-load existing OLTP rows into OLAP for a single table.
    fn initial_sync<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            let rows = inner
                .engine
                .initial_sync(&table_name)
                .await
                .map_err(to_py_err)?;
            Ok(rows)
        })
    }

    /// Add a column to a registered table.
    fn add_column<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        column_name: String,
        data_type: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let dt = parse_arrow_type(&data_type)?;
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            inner
                .engine
                .add_column(&table_name, &column_name, dt)
                .await
                .map_err(to_py_err)?;
            Ok(())
        })
    }

    /// Drop a column from a registered table.
    fn drop_column<'py>(
        &self,
        py: Python<'py>,
        table_name: String,
        column_name: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = Arc::clone(&self.inner);

        pyo3_async_runtimes::tokio::future_into_py(py, async move {
            inner
                .engine
                .drop_column(&table_name, &column_name)
                .await
                .map_err(to_py_err)?;
            Ok(())
        })
    }

    /// Shut down the engine.
    ///
    /// Currently a no-op — engine resources (database connections, OLAP state)
    /// are released when the Python object is garbage collected. Safe to call
    /// in cleanup blocks.
    fn shutdown(&self) -> PyResult<()> {
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn to_py_err(e: impl std::fmt::Display) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

/// Convert a Python value to a serde_json::Value, preserving types.
///
/// - bool (checked before int — Python bool is a subclass of int)
/// - int -> Number
/// - float -> Number
/// - None -> Null
/// - anything else -> String via __str__
fn py_to_json(val: &Bound<'_, PyAny>) -> PyResult<serde_json::Value> {
    // Check bool before int since Python bool is a subclass of int
    if val.is_instance_of::<pyo3::types::PyBool>() {
        let b: bool = val.extract()?;
        return Ok(serde_json::Value::Bool(b));
    }
    if val.is_instance_of::<pyo3::types::PyInt>() {
        // Try i64 first, fall back to stringified representation so that
        // Python ints outside signed 64-bit range don't regress against the
        // prior stringified-params behavior.
        return match val.extract::<i64>() {
            Ok(i) => Ok(serde_json::Value::Number(i.into())),
            Err(_) => Ok(serde_json::Value::String(val.str()?.to_string())),
        };
    }
    if val.is_instance_of::<pyo3::types::PyFloat>() {
        let f: f64 = val.extract()?;
        // serde_json::Number cannot hold NaN or Inf — `json!(nan)` would panic.
        // Encode them as strings so they round-trip through SQLite's REAL
        // affinity ("nan"/"inf") instead of crashing.
        if !f.is_finite() {
            return Ok(serde_json::Value::String(val.str()?.to_string()));
        }
        return Ok(serde_json::json!(f));
    }
    if val.is_none() {
        return Ok(serde_json::Value::Null);
    }
    // Fallback: convert to string
    let s: String = val.str()?.to_string();
    Ok(serde_json::Value::String(s))
}

/// Convert RecordBatches to a Python list of PyArrow objects (for use inside futures).
fn batches_to_pyarrow_obj(py: Python<'_>, batches: &[RecordBatch]) -> PyResult<Py<PyAny>> {
    let py_batches: Vec<Py<PyAny>> = batches
        .iter()
        .map(|batch| Ok(batch.to_pyarrow(py).map_err(to_py_err)?.unbind()))
        .collect::<PyResult<_>>()?;
    Ok(PyList::new(py, &py_batches)?.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Module definition
// ---------------------------------------------------------------------------

#[pymodule]
fn _rhei(m: &Bound<'_, PyModule>) -> PyResult<()> {
    init_runtime();
    m.add_class::<PyHtapEngine>()?;
    m.add_class::<PyHtapConfig>()?;
    m.add_class::<PyTableSchema>()?;
    m.add_class::<PyTimestampTableConfig>()?;
    m.add_class::<SyncResult>()?;
    m.add_class::<SyncStatus>()?;
    Ok(())
}
