# CombAero Network Solver — Project Roadmap

## Vision

A Python-based thermodynamic network solver with a React GUI, built on top of
CombAero's C++ physics kernels. Users draw networks of combustion system
elements, specify boundary conditions, and solve for pressures, temperatures,
mass flows, and compositions throughout the system.

> **Architectural References:**
> - [**METHODS_REFERENCE.md**](METHODS_REFERENCE.md): Physics kernel profiling and execution latencies.
> - [**SOLVER.md**](SOLVER.md): Graph state data structures, Jacobian stability, and numerical framework options.

---

## Tech Stack

| Layer | Technology | License | Rationale |
|---|---|---|---|
| Physics kernels | C++ / CombAero | yours | Thermodynamics, transport, acoustics — already exists |
| Python bindings | pybind11 | BSD | Already exists |
| Network solver | Python + SciPy `root` | BSD | Phase 1–2; upgrade to CasADi for exact Jacobians in Phase 3+ |
| Auto-differentiation | CasADi (Phase 3+) | LGPL | Exact sparse Jacobians through element residuals |
| Graph topology | NetworkX | BSD | Incidence matrix, traversal, validation |
| Regression elements | scikit-learn / PyTorch | BSD / BSD | Custom element pressure loss maps |
| API backend | FastAPI | MIT | Exposes solver as `POST /solve` |
| GUI frontend | React + React Flow | MIT | Node-graph editor |
| UI components | Tailwind + shadcn/ui | MIT | Controls, panels, results display |
| Packaging | Docker or PyInstaller | — | Standalone app or server deployment |

---

## Scope Separation: C++ vs Python

```
┌──────────────────────────────────────────────────────┐
│  PYTHON — network layer                              │
│                                                      │
│  NetworkSolver      Newton iteration, convergence    │
│  NetworkGraph       topology, validation, assembly   │
│  NetworkNode ABC    PlenumNode, MomentumChamber,     │
│                     JunctionNode, BoundaryNode       │
│  NetworkElement ABC OrificeElement, ChannelElement,     │
│                     CombustionElement, HeatExchanger,│
│                     RegressionElement, MixingElement │
│  BoundaryCondition  PressureBC, MassFlowBC           │
│  MixtureState       P, T, m_dot, X[14]              │
└────────────────────────┬─────────────────────────────┘
                         │ pybind11
┌────────────────────────▼─────────────────────────────┐
│  C++ — CombAero physics kernels                      │
│                                                      │
│  h(), cp(), cv()         mixture enthalpy/heat cap   │
│  density()               ideal gas law               │
│  speed_of_sound()        isentropic                  │
│  transport_state()       all transport props (bundle) │
│  calc_T_from_h()         Newton inversion            │
│  mole_to_mass()          composition conversion      │
│  orifice_mdot()          incompressible Cd·A          │
│  channel_flow()             Darcy-Weisbach + thermo       │
│  fanno_channel()            compressible Fanno flow       │
│  cooling_correlations    Nusselt, friction factor    │
│  can_annular_eigenmodes  acoustics (Phase 4)         │
└──────────────────────────────────────────────────────┘
```

**Rule:** C++ owns property evaluation and correlations. Python owns equation
assembly, graph logic, and solver orchestration. The solver never calls C++
directly — always through element `residuals()`.

### The Analytical `(f, J)` Mandate & Sparse Matrix Registry

As established, the solver requires tightly bounded Jacobians to avoid instability resulting from finite-difference numerical noise on empirical correlations. While we have implemented `solver_interface` wrappers for flow, friction, and basic thermodynamics (Orifice, K-Factor, Haaland, Density, Viscosity), **Stagnation conversions and complex Heat Transfer/Cooling correlations** currently lack this interface.
*   **Missing API:** Methods passing into `stagnation.cpp`, `heat_transfer.cpp`, and `cooling_correlations.cpp` must be wrapped into `(f, J)` tuple-returning functions.

**The C++ Registry & Sparse Assembly Strategy:**
To fully leverage the `(f, J)` analytical gradients and scale the solver to massive networks, the project will implement a centralized C++ Function Registry (Phase 3):
1. **Serialization:** Python components will string-address their underlying physics (e.g., `"friction_model": "haaland"`), making the network natively serializable into YAML/JSON without pickling Python objects.
2. **Sparse Jacobians:** Python's `NetworkSolver` will query this registry to extract analytical local Jacobian blocks ($\mathbf{J}_{local}$) and construct a global `scipy.sparse.csr_matrix`. This eliminates dense $O(N^3)$ operations and allows SciPy root-finding algorithms to evaluate the global system exponentially faster.

### The Configuration `Literal` Mandate

To preserve GUI introspectability while avoiding class fragmentation, **all configurable C++ backend physics models must be exposed to Python components via `typing.Literal`.** This permits the React GUI to programmatically read `typing.get_args()` and auto-generate dropdown menus without duplicating standard logic.

**Identified Application Domains:**
1.  **Combustion Models (`CombustorNode`):** `Literal["complete", "equilibrium"]` $\rightarrow$ `cb.CombustionMethod.Complete | Equilibrium`.
2.  **Channel Friction Models (`ChannelElement`):** `Literal["haaland", "colebrook", "serghides", "petukhov"]` $\rightarrow$ Routes to respective `friction_*` C++ algorithms.
3.  **Smooth Channel Heat Transfer (`HeatExchangerElement`):** `Literal["gnielinski", "dittus_boelter", "sieder_tate", "petukhov"]` $\rightarrow$ Proxied dynamically into `cb.channel_smooth(..., correlation=X)`.
4.  **Flow Compressibility Regimes:** `Literal["incompressible", "compressible_fanno"]` $\rightarrow$ Gates `channel_flow_rough()` vs `fanno_channel_rough()`.

*DO NOT split an element into multiple Python classes just to swap an underlying empirical correlation.*

---

## Incremental Component Testing Strategy

Before diving into the full, generalized graph solver class, we will test basic combinations of standard network blocks to solidify the momentum, mass, and energy constraints iteratively:

1.  **Block 1 (Mass/Pressure):** `Boundary Plenum` $\rightarrow$ `Channel` $\rightarrow$ `Orifice` $\rightarrow$ `Sink Plenum`. Test with both rigid Pressure boundary conditions and rigid Mass Flow boundaries.
2.  **Block 2 (Momentum Recovery):** Pass the flow through a `Momentum Chamber` (which must have an explicit cross-sectional area for momentum transport) and then into a `Plenum`. Plenums must recover static pressure to total pressure assuming zero discharge losses.
3.  **Topology Discovery:** Orifice blocks must be coded to autonomously "discover" the channel diameters upstream and downstream during network initialization to correctly evaluate dynamic pressure recovery.

This modular, incremental approach will also be strictly followed when introducing highly complex new nodes, such as Combustion elements.

---

## Node Types

### Interior Nodes (unknowns solved by Newton)

| Node | Unknowns | Physics |
|---|---|---|
| `PlenumNode` | P, T, X | P_total = P_static (v ≈ 0), energy balance |
| `MomentumChamberNode` | P_static, P_total, v | Isentropic total/static relation, momentum flux, requires flow area |
| `JunctionNode` | P, T | Massless split/merge, Σṁ = 0 |

> **⚠️ Chamber Automatic Mixing Requirement**
>
> All chamber-type nodes (`PlenumNode`, `MomentumChamberNode`, `CombustorNode`, and any
> future chamber variants) with multiple upstream connections must **automatically**
> act as mixing nodes. This is not optional — the solver must enforce:
>
> 1. **Species mass conservation**: $X_{\text{node},k} = \frac{\sum_{\text{in}} \dot{m}_i X_{i,k}}{\sum_{\text{in}} \dot{m}_i}$
> 2. **Energy conservation**: $\sum_{\text{in}} \dot{m}_i h_i = \sum_{\text{out}} \dot{m}_j h_j$
>
> The C++ `cb.mix(streams)` function implements both balances correctly and should
> be used for computing the mixed state. For solver residuals, decompose into
> `cb.enthalpy_and_jacobian()` calls per the design rule (see SOLVER.md Section 4).
>
> **Implication**: Every interior chamber node with >1 upstream element implicitly
> adds energy and species residuals to the system. The solver must detect this
> topology and inject the appropriate conservation equations automatically.

### Boundary Nodes (fixed values, contribute no residuals)

| BC | Fixed inputs | Free (solved) | Typical use |
|---|---|---|---|
| `PressureBoundary` | P_total, T_total, X | ṁ | Inlet reservoir, atmosphere exit |
| `MassFlowBoundary` | ṁ, T_total, X | P | Fuel injector, compressor delivery |

**Constraint:** every network requires at least one `PressureBoundary` for
well-posedness. The solver validates this at setup.

---

## Element Catalogue

### Flow Elements

| Element | Residual | CombAero call |
|---|---|---|
| `OrificeElement` | `ṁ = Cd·A·√(2ρΔP)` | `orifice_flow_thermo()` — accepts fixed `Cd` or `cd_fn(T,P,X,Re)→Cd` callable |
| `EffectiveAreaConnectionElement` | `ṁ = A_eff·√(2ρΔP)` (Cd=1.0) | `orifice_flow_thermo()` with `Cd=1.0` — user specifies effective area (Cd·A product) directly |
| `ChannelElement` (incompressible) | `ΔP = f·(L/D)·½ρv²` + K·½ρv² | `channel_flow_rough()` — accepts optional `k_loss_fn(T,P,X,Re)→K` for fittings/bends |
| `ChannelElement` (compressible) | Fanno adiabatic friction | `fanno_channel()` / `fanno_channel_rough()` |
| `MomentumChamberElement` | Momentum + area change | `density()`, `speed_of_sound()` |

**User-correlation hooks for flow elements** are loop-free: `cd_fn` and `k_loss_fn` receive only inlet state `(T, P, X, Re)` — never outlet pressure — so they are safe inside Newton solvers.

### Thermal Elements

| Element | Residual | CombAero call |
|---|---|---|
| `HeatExchangerElement` | `Q = h·A·(T_aw − T_wall)`, solves T_wall | `channel_smooth()` / `channel_ribbed()` / `channel_dimpled()` / `channel_pin_fin()` / `channel_impingement()` — all return `ChannelResult` with `h`, `dP`, `T_aw`, `q` in one call |
| `AdiabaticWallElement` | `Q = 0` | — |

**`ChannelResult` for network elements:** The `channel_*` functions compute HTC, pressure drop, Mach, and `T_aw` in a single pass from `(T, P, X, velocity, geometry)`. Use `sol.h` and `sol.T_aw` for the heat flux residual; use `sol.dP` for the momentum residual. `T_aw` is always continuous (no M threshold) — safe for Newton/CasADi Jacobians.

### Reaction / Mixing Elements

| Element | Residual | CombAero call |
|---|---|---|
| `MixingElement` | Mass + species + enthalpy balance | `h()`, `mole_to_mass()` |
| `CombustionElement` | Atom balance + energy | `h()`, `calc_T_from_h()` — see `COMBUSTION_ELEMENTS.md` |

### Custom / Data-Driven Elements

| Element | Residual | Backend |
|---|---|---|
| `RegressionElement` | `ΔP = model(ṁ, T, ...)` | sklearn / PyTorch |

---

## MixtureState Dataclass

The common currency between all nodes and elements. This is the **canonical
definition** — `COMBUSTION_ELEMENTS.md` uses a simplified subset for Phase 1.

```python
from dataclasses import dataclass, field

@dataclass
class MixtureState:
    P: float                    # static pressure [Pa]
    P_total: float              # total pressure [Pa]  (= P for plenum nodes)
    T: float                    # static temperature [K]
    T_total: float              # total temperature [K]  (= T for plenum nodes)
    m_dot: float                # mass flow rate [kg/s]
    X: list[float]              # mole fractions [14 species]

    # Derived — computed on demand via CombAero
    def density(self) -> float: ...        # combaero.density(T, P, X)
    def enthalpy(self) -> float: ...       # combaero.h(T, X)
    def speed_of_sound(self) -> float: ... # combaero.speed_of_sound(T, X)
```

For a plenum node `P = P_total` and `T = T_total`. For a momentum chamber
node they differ and the isentropic relation closes the system.

**Phase 1** uses only `P` and `m_dot` (T and X are fixed, no composition
tracking). `P_total` and `T_total` are introduced in Phase 2.

---

## Static vs Stagnation Convention

`MixtureState` carries both static (`T`, `P`) and total (`T_total`, `P_total`).
The distinction matters for each part of the network:

| Context | Temperature to use | Notes |
|---|---|---|
| Element residuals (channel ΔP, orifice ṁ) | static `T`, `P` | Darcy-Weisbach, Nusselt/Re/Pr all at bulk static conditions |
| Boundary conditions | total `T_total`, `P_total` | Reservoir / compressor delivery are naturally total conditions |
| Heat flux driving temperature | `T_aw` (adiabatic wall T) | **Not** T_static or T_total; use `combaero.T_adiabatic_wall()` |
| Combustion / mixing enthalpy balance | static `h(T)` + v²/2 = h₀ | Stagnation enthalpy h₀ is conserved, not static h |
| Isentropic elements (nozzle, momentum chamber) | convert via `combaero.T0_from_static()` / `P0_from_static()` | Requires known M at the element |

**Why T_aw for heat transfer?**

```
q = h_conv · (T_aw − T_wall)          ← correct for all Mach numbers

T_aw = T_static + r · v² / (2·cp)     r = Pr^(1/3) turbulent
                                           r = Pr^(1/2) laminar

T_static < T_aw < T_total  (since r < 1 for air)
```

- Using `T_static`: underestimates heat load at M > 0.3 (2–15% error for combustor liner / turbine cooling)
- Using `T_total`: overcorrects — `T_aw < T_total` always since r < 1
- Re and Pr for the Nusselt correlation are always evaluated at static `T` (correct)

**CombAero utilities** (`stagnation.h`, available as `combaero.*`):

```python
T_aw = combaero.T_adiabatic_wall(T_static, v, T, P, X)      # from velocity
T_aw = combaero.T_adiabatic_wall_mach(T_static, M, T, P, X) # from Mach number
T0   = combaero.T0_from_static(T, M, X)
P0   = combaero.P0_from_static(P, T, M, X)
T    = combaero.T_from_stagnation(T0, M, X)
P    = combaero.P_from_stagnation(P0, T0, M, X)
```

---

## Abstract Interfaces

```python
from abc import ABC, abstractmethod

class NetworkNode(ABC):
    @abstractmethod
    def unknowns(self) -> list[str]:
        """Names of unknowns this node contributes to the solver."""
        ...

    @abstractmethod
    def residuals(self, state: MixtureState) -> list[float]:
        """Returns zero when node equations are satisfied."""
        ...

class NetworkElement(ABC):
    @abstractmethod
    def residuals(self,
                  state_in: MixtureState,
                  state_out: MixtureState) -> list[float]:
        """Returns zero when element equations are satisfied."""
        ...

    @abstractmethod
    def n_equations(self) -> int:
        """Number of residual equations contributed."""
        ...
```

---

## Network JSON Format

```json
{
  "nodes": [
    {
      "id": "inlet",
      "type": "pressure_bc",
      "P_total": 500000,
      "T_total": 700,
      "X": {"N2": 0.76, "O2": 0.21, "AR": 0.01, "CO2": 0.02}
    },
    {
      "id": "plenum_1",
      "type": "plenum"
    },
    {
      "id": "chamber_1",
      "type": "momentum_chamber",
      "area": 0.05
    },
    {
      "id": "exit",
      "type": "pressure_bc",
      "P_total": 101325,
      "T_total": 300,
      "X": {"N2": 0.79, "O2": 0.21}
    }
  ],
  "edges": [
    {
      "id": "orif_1",
      "type": "orifice",
      "from": "inlet",
      "to": "plenum_1",
      "Cd": 0.7,
      "area": 0.001
    },
    {
      "id": "burner_1",
      "type": "combustion",
      "from": "plenum_1",
      "to": "chamber_1",
      "eta": 0.99,
      "delta_P_frac": 0.04,
      "fuel": {
        "type": "mass_flow_bc",
        "m_dot": 0.05,
        "T_total": 300,
        "X": {"CH4": 1.0}
      }
    },
    {
      "id": "orif_2",
      "type": "orifice",
      "from": "chamber_1",
      "to": "exit",
      "Cd": 0.65,
      "area": 0.002
    }
  ]
}
```

---

## Phased Roadmap

### Phase 1 — Isothermal Flow Network (Completed ✅)

**Goal:** solve P and ṁ throughout a network of orifices, channels, and plenums.

- `MixtureState`: P and ṁ only (T and X fixed, no composition tracking)
- Nodes: `PlenumNode`, `JunctionNode`, `PressureBoundary`, `MassFlowBoundary`, `MomentumChamberNode`
- Elements: `OrificeElement`, `EffectiveAreaConnectionElement`, `ChannelElement`, `LosslessConnectionElement`
- Solver: `scipy.optimize.root` with finite-difference Jacobian (Pre-registry)
- Graph: Robust validation tracking unreachable graphs, isolated connections, and 0-DOF states.
- Network described and validated via JSON
- **No GUI** — JSON in, JSON out
- Validation: Flow reversals bounded strictly positive against C++ limits, orifices intelligently extracting asymmetric topology diameters.

### Phase 2 — Combustion and Composition (Completed ✅)

**Goal:** track mixture composition and temperature; add combustion element.

- `MixtureState` gains T and X[14]
- Nodes: `MomentumChamberNode` with total/static distinction
- Elements: `CombustionElement`, `MixingElement`, `RegressionElement`
- Segregated solve: flow first, then energy/composition propagation
- Validation: adiabatic flame temperature against Cantera

### Phase 3 — Heat Exchange (Completed ✅)

**Goal:** conjugate heat transfer between streams through walls.

- `HeatExchangerElement` with `T_wall` as additional unknown per segment
- Nusselt correlations via `cooling_correlations`
- Fully coupled Newton solve over [P, ṁ, T, T_wall, X]
- BC types: fixed T_wall, fixed Q, adiabatic, convective both sides

### Phase 4 — GUI (Completed ✅)

**Goal:** visual network editor.

- React + React Flow node-graph editor
- Nodes and edges map 1:1 to Python element classes
- FastAPI backend: `POST /solve` accepts network JSON, returns solution JSON
- Results overlay: colour-coded P, T, ṁ per element
- Export: network JSON, CSV results
### Phase 5 — Acoustics

**Goal:** linearise mean flow solution → acoustic transfer matrix propagation.

- Mean flow from Phase 1–3 provides the operating point
- Acoustic transfer matrices propagate on top of mean flow
- `can_annular_eigenmodes`, `annular_duct_modes` already in CombAero
- Assemble global transfer matrix from element acoustic matrices
- GUI: display mode shapes and frequency response

---

## Well-Posedness Rules

1. Every network requires ≥1 `PressureBoundary`
2. Number of pressure BCs + mass flow BCs = number of independent flow paths
3. Every node must be reachable from a boundary node
4. No isolated subgraphs

The solver validates all four at setup before attempting Newton iteration.

---

## Pending: Global Extrapolation / Validity-Flag Refactor

**Motivation:** Correlation validators currently either throw (hard error) or warn+extrapolate (for smooth power-law Re-based limits). For network solvers, throwing inside a Newton iteration is fatal — the solver cannot recover. The current partial fix (warn for Re, throw for geometry) is a step in the right direction but not yet systematic.

**Proposed design (future scope, project-wide):**
- Replace all `throw` validators with a `CorrelationResult<T>` wrapper that carries both the value and a `validity` flag (enum: `VALID`, `EXTRAPOLATED`, `INVALID`).
- Network elements check `validity` after each call and either propagate a warning or mark the solution as non-physical.
- Hard geometry errors (e_D, L_D, S_D out of range) remain throws since they indicate a modelling error, not an operating point excursion.
- This mirrors the `FlowSolution` pattern already used for flow correlations.

**Scope:** All correlations in `cooling_correlations.h`, `friction.h`, `heat_transfer.h`. Requires a coordinated refactor across C++ validators, Python bindings, and tests.
