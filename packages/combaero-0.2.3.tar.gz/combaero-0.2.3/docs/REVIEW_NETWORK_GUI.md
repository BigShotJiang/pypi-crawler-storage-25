# Network & GUI Integration Review

**Date**: 2026-04-11
**Scope**: `python/combaero/network/`, `gui/backend/`, `gui/frontend/`

### Future feature branche ideas

**Cooled Panel Element** (Part I) — Film/effusion cooling as a multi-port flow element
with pressure-driven bleed. Requires `MultiPortElement` base class and solver
generalization to N-port elements. See Part I for full design.

**Turbomachinery Stages** (Part H) — Compressor/turbine stage elements with
prescribed-PR and capacity modes, shaft coupling. Same architectural challenge as
cooled panels (new element types requiring C++ residuals + Jacobians). See Part H
for full design. Unblocked by G.2b (`calc_T_from_s_mass`).

**Cleanup** — M3 (auto_Cd Jacobian truncation), L1+L2 (legacy combustion deprecation),
L5 (legacy combustion guards), F.3 (non-smooth channel models in GUI).

---

## Part D — PyPI Publishing Readiness

Current state assessed against [PyPA packaging guide](https://packaging.python.org/)
and [scikit-build-core best practices](https://scikit-build-core.readthedocs.io/).

### D.1 — pyproject.toml metadata (HIGH — PyPI rejects without this)

The current `pyproject.toml` is **minimal**. PyPI requires or strongly recommends:

```toml
[project]
name = "combaero"
version = "0.2.0"
description = "Combustion and aerothermal tools (C++ core with Python bindings)"
readme = "README.md"
requires-python = ">=3.9"
license = "MIT"
authors = [
    { name = "...", email = "..." },
]
keywords = ["combustion", "thermodynamics", "heat-transfer", "gas-turbine", "CFD"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: C++",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Scientific/Engineering",
]
dependencies = ["numpy>=1.24", "scipy>=1.10"]

[project.urls]
Homepage = "https://github.com/.../combaero"
Documentation = "https://..."
Repository = "https://github.com/.../combaero"
Changelog = "https://github.com/.../combaero/blob/main/CHANGELOG.md"
```

**Missing today**: `license`, `authors`, `keywords`, `classifiers`, `[project.urls]`.
PyPI will accept without them, but the listing will look empty/unprofessional.

### D.2 — Cross-platform wheel builds with cibuildwheel (HIGH)

The current CI builds C++ and runs tests, but **does not build wheels**. For PyPI you
need pre-built wheels for at least:

- **Linux**: x86_64 (manylinux), aarch64
- **macOS**: x86_64, arm64 (Apple Silicon)
- **Windows**: x86_64

[cibuildwheel](https://cibuildwheel.readthedocs.io/) is the standard tool. Add to
`pyproject.toml`:

```toml
[tool.cibuildwheel]
build = "cp39-* cp310-* cp311-* cp312-* cp313-*"
skip = "*-musllinux_*"
test-requires = "pytest"
test-command = "pytest {project}/python/tests/ -x"

[tool.cibuildwheel.linux]
archs = ["x86_64", "aarch64"]
before-build = ""  # cmake is included in manylinux images

[tool.cibuildwheel.macos]
archs = ["x86_64", "arm64"]

[tool.cibuildwheel.windows]
archs = ["AMD64"]
```

Add a CI workflow (e.g. `.github/workflows/publish.yml`) triggered on tags:

```yaml
name: Publish
on:
  push:
    tags: ["v*"]
jobs:
  build-wheels:
    uses: pypa/cibuildwheel@v2
  publish:
    needs: build-wheels
    uses: pypa/gh-action-pypi-publish@release/v1
```

### D.3 — Type stubs / `py.typed` marker (MEDIUM)

The package has no `py.typed` marker file and no `.pyi` type stubs. For a
scientific library with a pybind11 C++ extension, this means:

- Users get no autocomplete or type checking for `combaero._core` functions
- `mypy` / `pyright` cannot validate calls

**Fix**:
- Add `python/combaero/py.typed` (empty marker file)
- Generate stubs with [pybind11-stubgen](https://github.com/sizmailov/pybind11-stubgen):
  `pybind11-stubgen combaero._core -o python/combaero/`
- Include the `.pyi` files in the wheel via `scikit-build` config

### D.5 — CHANGELOG.md (MEDIUM)

No changelog exists. PyPI best practice is a `CHANGELOG.md` tracking releases.
This is also linked from `[project.urls]`. Format:
[Keep a Changelog](https://keepachangelog.com/).

### D.6 — Source distribution (sdist) includes build files (LOW)

Without a `MANIFEST.in` or explicit sdist config, `scikit-build-core` includes
everything. This means the sdist may contain `build/`, `.venv/`, `gui/`,
`diagnostic_plots/`, etc.

Add to `pyproject.toml`:

```toml
[tool.scikit-build]
sdist.include = ["src/**", "include/**", "python/**", "CMakeLists.txt",
                 "README.md", "LICENSE", "pyproject.toml"]
sdist.exclude = ["build", ".venv", "gui", "diagnostic_*", "benchmarks",
                 "cantera_validation_tests", "thermo_data_generator", "dist"]
```

### D.8 — Network/GUI should not be in the PyPI package (LOW)

The `network/` subpackage and `gui/` are application-layer code, not library code.
For a PyPI release:
- `combaero` (the library) goes on PyPI
- `combaero.network` could be a separate `combaero-network` package or stay bundled
  as an optional extra
- `gui/` should **never** be in the PyPI wheel — it's a standalone application

Current `wheel.packages = ["python/combaero"]` includes `network/` since it's a
subpackage. Options:
1. Keep it bundled (simpler, what numpy/scipy do with sub-modules)
2. Split `combaero-network` as a separate distribution with `depends = ["combaero"]`

**Recommendation**: Keep bundled for now (option 1), but ensure `gui/` is excluded
from wheels.

### D.9 — Python version support floor (LOW)

`requires-python = ">=3.9"` — Python 3.9 is EOL (Oct 2025). For a new PyPI package,
`>=3.10` is reasonable. `>=3.11` if you want to drop old manylinux CI complexity.
The `ruff.toml` already targets `py312`.

### D.10 — License file in wheel (TRIVIAL)

The `LICENSE` file exists but isn't explicitly included in the wheel metadata. Add:

```toml
[project]
license = {file = "LICENSE"}
```

Or with the newer spec:
```toml
license = "MIT"
license-files = ["LICENSE"]
```

### Summary Table

| # | Item | Severity | Effort | Status |
|---|------|----------|--------|--------|
| D.1 | pyproject.toml metadata | High | Small | Missing authors, classifiers, urls |
| D.2 | cibuildwheel CI for multi-platform wheels | High | Medium | No wheel CI exists |
| D.3 | Type stubs + py.typed | Medium | Small | No stubs, no marker |
| D.5 | CHANGELOG.md | Medium | Small | Does not exist |
| D.6 | sdist include/exclude | Low | Small | May ship build artifacts |
| D.8 | network/gui packaging scope | Low | Decision | Keep bundled vs split |
| D.9 | Python version floor | Low | Trivial | 3.9 is EOL |
| D.10 | License in wheel metadata | Trivial | Trivial | Missing `license-files` |

---

## Part E — Tuning Factor Wiring Audit

**Goal**: Ensure `Nu_multiplier` and `f_multiplier` are wired end-to-end from GUI
through network components into C++ channel functions, and that they participate in
Jacobians correctly.

### E.1 — Wiring Status by Layer

| Layer | Nu_multiplier | f_multiplier | Notes |
|-------|:---:|:---:|-------|
| C++ `channel_smooth` | **YES** | **YES** | Default 1.0, applied inside correlation |
| C++ `channel_ribbed` | **YES** | **YES** | Applied on top of rib enhancement |
| C++ `channel_dimpled` | **YES** | **YES** | Applied on top of dimple enhancement |
| C++ `channel_pin_fin` | **YES** | **YES** | Applied on top of pin-fin correlation |
| C++ `channel_impingement` | **YES** | **YES** | Applied on top of impingement Nu |
| pybind `_core.cpp` | **YES** | **YES** | All 5 channel functions bound with both params |
| Python `ConvectiveSurface.htc_and_T()` | **YES** | **YES** | Passed from `self.Nu_multiplier`/`self.f_multiplier` |
| Python `heat_transfer.py` wrappers | **NO** | **NO** | `smooth()`, `ribbed()`, `dimpled()`, `pin_fin()`, `impingement()` do not accept multipliers |
| `ChannelElement.htc_and_T()` | **YES** | **YES** | Delegates to `self.surface.htc_and_T()` |
| `MomentumChamberNode.htc_and_T()` | **YES** | **YES** | Delegates to `self.surface.htc_and_T()` |
| `CombustorNode.htc_and_T()` | Implicit | Implicit | Uses `self.surface` which carries multipliers |
| Solver `_evaluate_walls_for_node` | **YES** | **YES** | Calls `obj.htc_and_T(state)` → `ConvectiveSurface` |
| GUI `schemas.py` | **NO** | **NO** | No multiplier fields on any element schema |
| GUI `graph_builder.py` | **NO** | **NO** | Hardcodes `ConvectiveSurface(area=conv_area)` with defaults |
| GUI frontend | **NO** | **NO** | No UI controls for multipliers |

### E.2 — Findings

#### E.2.1 — `heat_transfer.py` wrappers drop multipliers (MEDIUM)

The high-level Python wrappers (`smooth()`, `ribbed()`, `dimpled()`, `pin_fin()`,
`impingement()`) in `heat_transfer.py` do **not** accept or forward `Nu_multiplier`
or `f_multiplier`. These are standalone convenience functions (not on the solver path),
but any user calling e.g. `combaero.heat_transfer.smooth(...)` cannot apply tuning.

```python
# heat_transfer.py line 96-108
def smooth(...) -> ChannelResult:
    return _channel_smooth(
        T, P, list(X), u, D, L,
        T_wall=T_wall, correlation=correlation,
        heating=heating, mu_ratio=mu_ratio, roughness=roughness,
        # Nu_multiplier and f_multiplier NOT passed
    )
```

**Fix**: Add `Nu_multiplier: float = 1.0` and `f_multiplier: float = 1.0` keyword
args to all 5 wrapper functions and forward them.

#### E.2.2 — GUI does not expose multipliers (LOW — future work)

The GUI `ChannelData`/`OrificeData` schemas and `graph_builder.py` do not wire
`Nu_multiplier`/`f_multiplier`. The `ConvectiveSurface` is constructed with defaults:

```python
# graph_builder.py line 161
surface=ConvectiveSurface(area=conv_area)
# → Nu_multiplier=1.0, f_multiplier=1.0 (defaults)
```

This is acceptable for the initial GUI (no heat transfer tuning exposed yet). When
thermal coupling is fully exposed in the GUI, add:

```python
class ChannelData(BaseModel):
    Nu_multiplier: float = 1.0
    f_multiplier: float = 1.0
```

And in `graph_builder.py`:
```python
surface=ConvectiveSurface(
    area=conv_area,
    Nu_multiplier=data.Nu_multiplier,
    f_multiplier=data.f_multiplier,
)
```

#### E.2.3 — Jacobian correctness of multipliers

In C++, the multipliers are applied as `h = Nu_multiplier * h_base` and
`f = f_multiplier * f_base`. The `ChannelResult` Jacobians (`dh_dmdot`, `dh_dT`)
are computed **after** the multiplier is applied, so the chain rule is correct:

```
dh/dmdot = Nu_multiplier * dh_base/dmdot
```

This is the correct design (multiplier inside C++, not Python post-correction) per
the design doc. **No Jacobian issue.**

#### E.2.4 — Channel model selection not exposed in GUI (LOW)

The GUI hardcodes `SmoothModel()` for channels. Users cannot select ribbed, dimpled,
pin-fin, or impingement models from the GUI. This is future GUI work (Part F overlap).

### E.3 — Summary

The multiplier wiring is **correct through the solver path** (Python network →
`ConvectiveSurface` → C++ `channel_*`). The two gaps are:

1. **`heat_transfer.py` convenience wrappers** don't forward multipliers (MEDIUM fix)
2. **GUI** doesn't expose multipliers yet (LOW, future GUI feature)

---

## Part F — Missing Correlations: C++ Available but Not Wired to Network

### F.1 — Inventory: C++ Cooling Functions

The C++ library in `cooling_correlations.h` provides these standalone functions:

| C++ Function | Pybind | Network Model | GUI |
|---|:---:|:---:|:---:|
| `rib_enhancement_factor` | YES | via `channel_ribbed` | NO |
| `rib_enhancement_factor_high_re` | YES | via `channel_ribbed` | NO |
| `rib_friction_multiplier` | YES | via `channel_ribbed` | NO |
| `rib_friction_multiplier_high_re` | YES | via `channel_ribbed` | NO |
| `thermal_performance_factor` | YES | — (post-processing) | NO |
| `impingement_nusselt` | YES | via `channel_impingement` | NO |
| `film_cooling_effectiveness` | YES | **NO network model** | NO |
| `film_cooling_effectiveness_avg` | YES | **NO network model** | NO |
| `film_cooling_multirow_sellers` | YES | **NO network model** | NO |
| `effusion_effectiveness` | YES | **NO network model** | NO |
| `effusion_discharge_coefficient` | YES | **NO network model** | NO |
| `pin_fin_nusselt` | YES | via `channel_pin_fin` | NO |
| `pin_fin_friction` | YES | via `channel_pin_fin` | NO |
| `dimple_nusselt_enhancement` | YES | via `channel_dimpled` | NO |
| `dimple_friction_multiplier` | YES | via `channel_dimpled` | NO |
| `adiabatic_wall_temperature` | YES | **NO network model** | NO |
| `cooled_wall_heat_flux` | YES | **NO network model** | NO |

And `solver_interface.h` Jacobian-equipped versions:

| C++ Function | Pybind | Used in Network |
|---|:---:|:---:|
| `pin_fin_nusselt_and_jacobian` | YES | Inside `channel_pin_fin` |
| `pin_fin_friction_and_jacobian` | YES | Inside `channel_pin_fin` |
| `dimple_nusselt_enhancement_and_jacobian` | YES | Inside `channel_dimpled` |
| `dimple_friction_multiplier_and_jacobian` | YES | Inside `channel_dimpled` |
| `rib_enhancement_factor_high_re_and_jacobian` | YES | Inside `channel_ribbed` |
| `impingement_nusselt_and_jacobian` | YES | Inside `channel_impingement` |
| `film_cooling_effectiveness_and_jacobian` | YES | **NOT used in network** |
| `effusion_effectiveness_and_jacobian` | YES | **NOT used in network** |

### F.2 — Missing Network Models (Not Yet Wired)

> **Note**: Film and effusion cooling network integration is superseded by the
> `CooledPanelElement` design in **Part I**. The wall-modifier approach described
> below (F.2.1, F.2.2) was found to be insufficient — film/effusion require
> multi-port flow elements with pressure-driven bleed, not `T_aw` modifiers.

Five C++ correlation families are exposed via pybind but have **no** corresponding
`ChannelModel` subclass in the network:

#### F.2.1 — Film Cooling

- `film_cooling_effectiveness(x_D, M, DR, alpha_deg)` → local eta
- `film_cooling_effectiveness_avg(x_D, M, DR, alpha_deg, s_D)` → laterally averaged
- `film_cooling_multirow_sellers(row_positions, eval_xD, M, DR, alpha_deg)` → multi-row

These modify the *adiabatic wall temperature* (`T_aw`) seen by the hot-side wall, not
the convective HTC. They are typically used as **boundary condition modifiers** rather
than channel-flow models.

**Network model**: A `FilmCoolingModel` could modify `T_aw` on the hot side:
```
T_aw_film = T_hot - eta * (T_hot - T_coolant)
```
This would sit on `WallConnection` as a hot-side modifier, not as a `ChannelModel`.

#### F.2.2 — Effusion Cooling

- `effusion_effectiveness(x_D, M, DR, porosity, s_D, alpha_deg)` → eta for dense arrays
- `effusion_discharge_coefficient(Re_d, P_ratio, alpha_deg, L_D)` → Cd for effusion holes

Similar to film cooling — modifies `T_aw` on the hot side. Additionally, the mass
flow through effusion holes couples the coolant supply pressure to the hot-side
pressure (like an orifice array).

**Network model**: More complex — requires coupling coolant mass flow (through
effusion holes) to both thermal and flow networks. Could be modeled as:
1. Orifice array for flow coupling (using `effusion_discharge_coefficient`)
2. `T_aw` modifier for thermal coupling (using `effusion_effectiveness`)

#### F.2.3 — Standalone Helpers

- `adiabatic_wall_temperature(T_hot, T_coolant, eta)` — convenience for T_aw from eta
- `cooled_wall_heat_flux(T_hot, T_coolant, h_hot, h_coolant, eta, t_wall, k_wall)` —
  single-pass combined heat flux
- `thermal_performance_factor(Nu_ratio, f_ratio)` — post-processing diagnostic

These are building blocks, not channel models. They don't need network model classes.

### F.3 — Channel Models Wired but Not Exposed in GUI

All 5 `ChannelModel` subclasses exist in Python but the GUI only uses `SmoothModel`:

| Model | Python Class | GUI Schema | GUI Frontend |
|-------|-------------|:---:|:---:|
| Smooth | `SmoothModel` | Implicit only | NO (no controls) |
| Ribbed | `RibbedModel` | **NO** | NO |
| Dimpled | `DimpledModel` | **NO** | NO |
| Pin-fin | `PinFinModel` | **NO** | NO |
| Impingement | `ImpingementModel` | **NO** | NO |

### F.4 — Recommended Implementation for Missing Models

#### Phase F-I: Film/Effusion as T_aw modifiers (new concept)

Film and effusion cooling are not channel-flow models — they modify the adiabatic wall
temperature seen by the `WallConnection`. This requires:

1. Add a `CoolingModifier` concept to `ThermalWall` (Part C refactor):
```python
@dataclass
class FilmCoolingModifier:
    """Modifies hot-side T_aw via film cooling effectiveness."""
    x_D: float           # downstream distance / hole diameter
    M: float             # blowing ratio
    DR: float            # density ratio
    alpha_deg: float     # injection angle [deg]
    s_D: float = 3.0     # hole spacing / diameter
    multirow: bool = False
    row_positions_xD: list[float] | None = None

@dataclass
class EffusionCoolingModifier:
    """Modifies hot-side T_aw via effusion cooling effectiveness."""
    x_D: float
    M: float
    DR: float
    porosity: float
    s_D: float
    alpha_deg: float
```

2. In `ThermalWall.compute_coupling()`:
```python
if self.hot_side_modifier:
    eta = cb.film_cooling_effectiveness(...)
    T_aw_a = cb.adiabatic_wall_temperature(T_aw_a, T_coolant, eta)
```

3. The Jacobian chain extends: `dQ/dT_aw_a * dT_aw_a/deta * deta/dM`.
   The C++ `film_cooling_effectiveness_and_jacobian` already provides `deta/dM`.

#### Phase F-II: Expose channel model selection in GUI

Add `htc_model` selection to channel/element schemas:
```python
class ChannelData(BaseModel):
    htc_model: str = "smooth"  # "smooth"|"ribbed"|"dimpled"|"pin_fin"|"impingement"
    htc_params: dict = {}      # model-specific parameters
    Nu_multiplier: float = 1.0
    f_multiplier: float = 1.0
```

Map to the correct `ChannelModel` subclass in `graph_builder.py`.

### F.5 — Summary Table

| # | Item | Severity | Effort | Status |
|---|------|----------|--------|--------|
| E.2.1 | `heat_transfer.py` wrappers missing multipliers | Medium | Small | 5 functions to fix |
| E.2.2 | GUI multiplier exposure | Low | Small | Future GUI feature |
| E.2.4 | GUI channel model selection | Low | Medium | Future GUI feature |
| F.2.1 | Film cooling network model | Medium | Medium | New `CoolingModifier` concept needed |
| F.2.2 | Effusion cooling network model | Medium | Medium | Flow+thermal coupling |
| F.3 | Non-smooth models in GUI | Low | Small | Schema + builder wiring |

---

## Part G — Full C++ → Pybind → Python → GUI Wiring Audit

Systematic screen of every public C++ header for functions/types that are:
- **Not bound** in pybind (`_core.cpp`)
- **Bound** but not re-exported in `__init__.py`
- **Exported** in Python but not wired to network/GUI

Assessment criterion: *Would an engineering student or practising engineer benefit
from having this exposed in the Python API or GUI?*

### G.1 — `solver_interface.h`

All solver-interface functions are internal building blocks consumed by the Python
network solver. They are **correctly not exposed** as public API — users should not
call `orifice_residuals_and_jacobian` directly. The only user-facing items are the
Jacobian-equipped correlation functions, all of which are already bound.

| Function | Pybind | `__init__` | Network | GUI | Assessment |
|----------|:---:|:---:|:---:|:---:|------------|
| `orifice_mdot_and_jacobian` | YES | YES | Solver-internal | — | Correct: internal |
| `orifice_residuals_and_jacobian` | YES | YES | Solver-internal | — | Correct: internal |
| `channel_residuals_and_jacobian` | YES | YES | Solver-internal | — | Correct: internal |
| `lossless_pressure_and_jacobian` | YES | YES | Solver-internal | — | Correct: internal |
| `orifice_compressible_*` | YES | YES | Solver-internal | — | Correct: internal |
| `channel_compressible_*` | YES | YES | Solver-internal | — | Correct: internal |
| `nusselt_and_jacobian_*` (4 variants) | YES | YES | — | — | OK: useful for advanced users |
| `friction_and_jacobian_*` (5 variants) | YES | YES | — | — | OK: useful for advanced users |
| `pin_fin_nusselt_and_jacobian` | YES | YES | — | — | OK |
| `pin_fin_friction_and_jacobian` | YES | YES | — | — | OK |
| `dimple_*_and_jacobian` | YES | YES | — | — | OK |
| `rib_enhancement_factor_high_re_and_jacobian` | YES | YES | — | — | OK |
| `impingement_nusselt_and_jacobian` | YES | YES | — | — | OK |
| `film_cooling_effectiveness_and_jacobian` | YES | YES | — | — | OK |
| `effusion_effectiveness_and_jacobian` | YES | YES | — | — | OK |
| `density_and_jacobians` | YES | YES | — | — | OK |
| `enthalpy_and_jacobian` | YES | YES | — | — | OK |
| `viscosity_and_jacobians` | YES | YES | — | — | OK |
| `mach_number_and_jacobian_v` | YES | YES | — | — | OK |
| `T_adiabatic_wall_and_jacobian_v` | YES | YES | — | — | OK |
| `T0_from_static_and_jacobian_M` | YES | YES | — | — | OK |
| `P0_from_static_and_jacobian_M` | YES | YES | — | — | OK |
| `adiabatic_T_complete_and_jacobian_T` | YES | YES | — | — | OK |
| `adiabatic_T_equilibrium_and_jacobians` | YES | YES | — | — | OK |
| `mixer_from_streams_and_jacobians` | YES | YES | Solver-internal | — | Correct |
| `adiabatic_T_*_from_streams` | YES | YES | Solver-internal | — | Correct |
| `combustor_residuals_and_jacobians` | YES | YES | Solver-internal | — | Correct |
| `momentum_chamber_residual_and_jacobian` | YES | YES | Solver-internal | — | Correct |

**Verdict: solver_interface.h — fully wired, no gaps.**

### G.2 — `thermo.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `cp`, `h`, `s`, `cv`, `u` (molar) | YES | YES | OK |
| `cp_mass`, `h_mass`, `s_mass`, `cv_mass`, `u_mass` | YES | YES | OK |
| `density`, `molar_volume`, `specific_gas_constant` | YES | YES | OK |
| `isentropic_expansion_coefficient`, `speed_of_sound` | YES | YES | OK |
| `air_properties` | YES | YES | OK |
| `thermo_state`, `complete_state` | YES | YES | OK |
| `calc_T_from_h`, `calc_T_from_s`, `calc_T_from_cp` | YES | YES | OK |
| `calc_T_from_h_mass` | YES | YES | OK |
| `dh_dT`, `ds_dT`, `dcp_dT`, `dg_over_RT_dT` | **NO** | **NO** | **MISSING** — useful for sensitivity analysis |
| `calc_T_from_u` (molar internal energy) | **NO** | **NO** | Low value (rare use case) |
| `calc_T_from_s_mass` | **NO** | **NO** | **MISSING** — isentropic process solver |
| `calc_T_from_u_mass` | **NO** | **NO** | **MISSING** — isochoric process solver |
| `calc_T_from_sv_mass` | **NO** | **NO** | **MISSING** — (s, v) flash |
| `calc_T_from_sh_mass` | **NO** | **NO** | **MISSING** — (s, h) flash |
| `nusselt_channel` (State-based overload) | **NO** | **NO** | Low value (htc_channel covers this) |
| State-based overloads (`cp(State&)` etc.) | **NO** | **NO** | Low value (internal convenience) |

**Key gaps:**
- **`dh_dT`, `ds_dT`, `dcp_dT`** — Useful for students studying thermodynamic
  sensitivity and for engineers doing uncertainty propagation. Medium value.
- **`calc_T_from_s_mass`** — Essential for isentropic expansion/compression
  calculations (turbine/compressor modelling). **High value for students.**
- **`calc_T_from_u_mass`** — Isochoric heating (e.g., constant-volume combustion).
  Medium value.
- **`calc_T_from_sv_mass`, `calc_T_from_sh_mass`** — State-point flash calculations.
  Medium value for advanced thermodynamic analysis.

### G.3 — `transport.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `viscosity` | YES | YES | OK |
| `thermal_conductivity` | YES | YES | OK |
| `prandtl` | YES | YES | OK |
| `kinematic_viscosity` | YES | YES | OK |
| `thermal_diffusivity` | YES | YES | OK |
| `reynolds` | YES | YES | OK |
| `peclet` | YES | YES | OK |
| `transport_state` | YES | YES | OK |
| `omega22`, `linear_interp` | **NO** | **NO** | Correct: internal implementation details |

**Verdict: transport.h — fully wired, no gaps.**

### G.4 — `friction.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `friction_haaland` | YES | YES | OK |
| `friction_serghides` | YES | YES | OK |
| `friction_colebrook` | YES | YES | OK |
| `friction_petukhov` | YES | YES | OK |
| `channel_roughness` | YES | YES | OK |
| `standard_channel_roughness` | YES | YES | OK |

**Verdict: friction.h — fully wired, no gaps.**

### G.5 — `orifice.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `OrificeGeometry` struct | YES | YES | OK |
| `OrificeState` struct | YES | YES | OK |
| `CdCorrelation` enum | YES | YES | OK |
| `Cd_sharp_thin_plate` | YES | YES | OK |
| `Cd_thick_plate` | YES | YES | OK |
| `Cd_rounded_entry` | YES | YES | OK |
| `Cd` (auto-select) | YES | YES | OK |
| `orifice::Cd_ReaderHarrisGallagher` | YES | YES | OK |
| `orifice::Cd_Stolz` | YES | YES | OK |
| `orifice::Cd_Miller` | YES | YES | OK |
| `orifice::thickness_correction` | YES | YES | OK |
| `orifice::Cd_rounded` | YES | YES | OK |
| `orifice::K_from_Cd` | YES | YES | OK |
| `orifice::Cd_from_K` | YES | YES | OK |
| `orifice_mdot` | YES | YES | OK |
| `orifice_dP` | YES | YES | OK |
| `orifice_Cd_from_measurement` | YES | YES | OK |
| `solve_orifice_mdot` | YES | YES | OK |
| `OrificeFlowResult` struct | YES | YES | OK |
| `orifice_flow` | YES | YES | OK |
| `orifice_flow_state` (convenience) | YES | YES | OK |
| `orifice_velocity_from_mdot` | YES | YES | OK |
| `orifice_area_from_beta` | YES | YES | OK |
| `beta_from_diameters` | YES | YES | OK |
| `orifice_Re_d_from_mdot` | YES | YES | OK |
| `expansibility_factor` | YES | YES | OK |
| `make_correlation` (factory) | **NO** | **NO** | Low value: polymorphic OO pattern, not Pythonic |
| `make_user_correlation` | **NO** | **NO** | Low value: users can pass Cd directly |
| `make_tabulated_correlation` | **NO** | **NO** | **MISSING** — useful for test-data driven Cd. Medium. |

**Verdict: orifice.h — nearly complete. `make_tabulated_correlation` is the only
notable gap for users with empirical test data.**

### G.6 — `heat_transfer.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `nusselt_dittus_boelter` | YES | YES | OK |
| `nusselt_gnielinski` (both overloads) | YES | YES | OK |
| `nusselt_sieder_tate` | YES | YES | OK |
| `nusselt_petukhov` (both overloads) | YES | YES | OK |
| `htc_from_nusselt` | YES | YES | OK |
| `overall_htc` | YES | YES | OK |
| `overall_htc_wall` (all overloads) | YES | YES | OK |
| `thermal_resistance` | YES | YES | OK |
| `thermal_resistance_wall` | YES | YES | OK |
| `lmtd`, `lmtd_counterflow`, `lmtd_parallelflow` | YES | YES | OK |
| `heat_rate`, `heat_flux`, `heat_transfer_area`, `heat_transfer_dT` | YES | YES | OK |
| `wall_temperature_profile` | YES | YES | OK |
| `heat_flux_from_T_at_edge` | YES | YES | OK |
| `heat_flux_from_T_at_depth` | YES | YES | OK |
| `bulk_T_from_edge_T_and_q` | YES | YES | OK |
| `dT_edge_dT_hot`, `dT_edge_dT_cold`, `dT_edge_dT_bulk`, `dT_edge_dq` | YES | YES | OK |
| `ntu`, `capacity_ratio` | YES | YES | OK |
| `effectiveness_counterflow`, `effectiveness_parallelflow` | YES | YES | OK |
| `heat_rate_from_effectiveness` | YES | YES | OK |
| `ChannelResult` struct | YES | YES | OK |
| `WallCouplingResult` struct | YES | YES | OK |
| `wall_coupling_and_jacobian` | YES | YES | OK |
| `channel_smooth/ribbed/dimpled/pin_fin/impingement` | YES | YES | OK |
| `htc_channel` (composite tuple overload) | YES | YES | OK |
| `nusselt_channel` (State-based) | **NO** | **NO** | Low value — `htc_channel` covers the use case |
| `htc_channel` (State-based) | YES | YES | OK |
| Laminar constants `NU_LAMINAR_CONST_T/Q` | **NO** | **NO** | Low: trivial constants (3.66, 4.36) |

**Verdict: heat_transfer.h — fully wired. No meaningful gaps.**

### G.7 — `combustion.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `oxygen_required_per_mol_fuel/kg_fuel` | YES | YES | OK |
| `oxygen_required_per_mol_mixture/kg_mixture` | YES | YES | OK |
| `equivalence_ratio` (elemental) | YES | YES | OK |
| `equivalence_ratio_mass` (elemental) | YES | YES | OK |
| `fuel_lhv_molar`, `fuel_lhv_mass` | YES | YES | OK |
| `dryair_required_per_mol_fuel/kg_fuel` | YES | YES | OK |
| `dryair_required_per_mol_mixture/kg_mixture` | YES | YES | OK |
| `equivalence_ratio_mole` (fuel/ox streams) | YES | YES | OK |
| `set_equivalence_ratio_mole/mass` | YES | YES | OK |
| `bilger_*` functions (all) | YES | YES | OK |
| `complete_combustion_to_CO2_H2O` (both) | YES | YES | OK |
| `combustion_state` (both overloads) | YES | YES | OK |
| `combustion_state_from_streams` (both) | YES | YES | OK |
| `set_fuel_stream_for_*` (5 variants) | YES | YES | OK |
| `set_oxidizer_stream_for_*` (5 variants) | YES | YES | OK |
| `complete_combustion` (State-based) | **NO** | **NO** | **MISSING** — convenience for quick State→State combustion |
| `complete_combustion_isothermal` (State) | **NO** | **NO** | Low value: niche use case |

**Verdict: combustion.h — nearly complete. `complete_combustion(State)` is a useful
convenience but not critical since `combustion_state` covers the same physics.**

### G.8 — `materials.h`

| Function | Pybind | `__init__` | Assessment |
|----------|:---:|:---:|------------|
| `k_inconel718` | YES | YES | OK |
| `k_haynes230` | YES | YES | OK |
| `k_stainless_steel_316` | YES | YES | OK |
| `k_aluminum_6061` | YES | YES | OK |
| `k_tbc_ysz` | YES | YES | OK |
| `list_materials` | YES | YES | OK |
| `get_material` (returns `ThermalMaterial`) | **NO** | **NO** | **MISSING** — generic k(T) lookup by name. Medium value. |
| `ThermalMaterial` struct | **NO** | **NO** | Would need wrapping of `std::function<double(double)>` |

**Verdict: materials.h — mostly wired. `get_material` would be valuable for generic
wall-layer specification by material name, but requires wrapping a C++ functor.**

### G.9 — Summary of All Missing Items

| # | Header | Function(s) | Usefulness | Effort | Notes |
|---|--------|------------|-----------|--------|-------|
| G.2a | thermo.h | `dh_dT`, `ds_dT`, `dcp_dT` | Medium | Small | Sensitivity analysis, uncertainty propagation |
| G.2b | thermo.h | `calc_T_from_s_mass` | **High** | Small | Isentropic T after expansion/compression |
| G.2c | thermo.h | `calc_T_from_u_mass` | Medium | Small | Isochoric process solver |
| G.2d | thermo.h | `calc_T_from_sv_mass`, `calc_T_from_sh_mass` | Medium | Small | State-point flash calculations |
| G.5a | orifice.h | `make_tabulated_correlation` | Medium | Medium | Test-data driven Cd(beta, Re) tables |
| G.7a | combustion.h | `complete_combustion(State)` | Low | Small | Quick State→State convenience |
| G.8a | materials.h | `get_material` (generic k(T) lookup) | Medium | Medium | Needs functor wrapping |

### G.10 — Recommended Priority

1. **`calc_T_from_s_mass`** — High value for turbomachinery students. Trivial to bind
   (same pattern as `calc_T_from_h_mass`).
2. **`calc_T_from_u_mass`**, **`calc_T_from_sv_mass`**, **`calc_T_from_sh_mass`** —
   Complete the inverse-solver family. Small effort each.
3. **`dh_dT`**, **`ds_dT`**, **`dcp_dT`** — Expose thermodynamic derivatives for
   educational use. Trivial pybind wrappers.
4. **`get_material`** — Useful when Part C (multi-layer walls) lands; allows
   specifying wall materials by name instead of hardcoded k(T).
5. **`make_tabulated_correlation`** — Useful for experimental validation workflows.

---

## Part H — Turbomachinery Stage Elements (Compressor / Turbine)

The missing `calc_T_from_s_mass` (G.2b) and related inverse thermo solvers are the
key C++ building blocks for adding compressor and turbine stage elements to the
network solver. This section sketches the design.

### H.1 — Thermodynamic Model

A single compressor or turbine stage with isentropic efficiency `eta_is`:

```
Given:  T1, P1, X   (inlet stagnation state from upstream node)
        PR           (pressure ratio P2/P1 — design parameter)
        eta_is       (isentropic efficiency — design parameter)

Step 1: P2 = P1 * PR
Step 2: T2s = calc_T_from_s_mass(s_mass(T1, X, P1), P2, X)   ← isentropic outlet
Step 3: h2  = h1 + (h2s - h1) / eta_is                        (compressor)
         h2  = h1 - eta_is * (h1 - h2s)                        (turbine)
Step 4: T2  = calc_T_from_h_mass(h2, X)                        ← actual outlet
Step 5: W   = mdot * (h2 - h1)                                 [W] shaft work
```

All five C++ functions (`s_mass`, `h_mass`, `calc_T_from_s_mass`, `calc_T_from_h_mass`,
`cp_mass`) already exist with proper Newton solvers. Only `calc_T_from_s_mass` is
missing from pybind (the single blocker for this feature).

### H.2 — Operating Modes

A turbomachinery stage needs three operating modes to cover different analysis types:

| Mode | Inputs (fixed) | Solved for | Use case |
|------|----------------|-----------|----------|
| **Prescribed PR** | `pressure_ratio`, `eta_is` | — | Single design-point "what-if" |
| **Capacity** | `throat_area` (or `capacity`), `eta_is` | `PR` emerges from network | System matching, gas turbine cycles |
| **Performance map** | `CompressorMap` / `TurbineMap` | `PR`, `eta_is` both from map | Off-design analysis |

### H.2a — Capacity Model (Key for System Matching)

**Problem with fixed PR**: if PR is prescribed, the mass flow is fully determined by
the rest of the network. The stage is passive — it can't "push back" or limit flow.
This prevents modelling compressor–turbine matching, surge, or choking.

**Capacity** is the standard turbomachinery coupling parameter:

```
Capacity ≡ ṁ·√(T₀_in) / P₀_in    [kg·√K / (s·Pa)]
```

For a **choked turbine nozzle**, capacity is fixed by throat geometry:
```
capacity_choked = A_throat · √(γ/R) · (2/(γ+1))^((γ+1)/(2(γ-1)))
```

For a **compressor**, capacity at design point is a characteristic of the machine.

In capacity mode, the element's residual constrains mass flow, not pressure ratio:
```
Residual:  ṁ·√(T₀_in) / P₀_in  -  capacity  =  0
```
The pressure ratio is NOT prescribed — it emerges from the downstream node pressures
set by the rest of the network. The element observes the actual PR = P₀_out / P₀_in
and uses it to compute T_out via the isentropic model.

This is architecturally identical to how `OrificeElement` constrains ṁ from ΔP via
`ṁ = Cd·A·√(2ρΔP)` — the orifice doesn't prescribe ΔP, it relates ṁ to the
pressure difference the network provides.

### H.2b — Network Element Design

Following the existing `NetworkElement` pattern (cf. `ChannelElement`, `OrificeElement`):

```python
class CompressorStageElement(NetworkElement):
    """Single compressor stage with isentropic efficiency."""

    def __init__(self, id, from_node, to_node,
                 eta_is: float = 0.85,
                 # --- Mode selection (exactly one must be set) ---
                 pressure_ratio: float | None = None,   # Mode 1: fixed PR
                 capacity: float | None = None,          # Mode 2: ṁ√T/P capacity
                 throat_area: float | None = None,       # Mode 2 alt: compute capacity from geometry
                 # performance_map: CompressorMap | None = None,  # Mode 3: future
                 shaft_id: str | None = None):
        ...

    def unknowns(self) -> list[str]:
        return [f"{self.id}.m_dot"]

    def residuals(self, state_in, state_out):
        if self.pressure_ratio is not None:
            # Mode 1: Prescribed PR — residual enforces pressure ratio
            P2 = state_in.P_total * self.pressure_ratio
            res = [state_out.P_total - P2]
            jac = {0: {
                f"{self.from_node}.P_total": -self.pressure_ratio,
                f"{self.to_node}.P_total": 1.0,
            }}
        else:
            # Mode 2: Capacity — residual enforces mass flow capacity
            # C++ provides: capacity_residual_and_jacobian(m_dot, T1, P1, X, capacity)
            res_cpp = cb.compressor_capacity_residuals_and_jacobian(
                state_in.m_dot, state_in.T, state_in.P_total, state_in.X,
                self._capacity,
            )
            res = [res_cpp.residual]
            jac = {0: {
                f"{self.id}.m_dot": res_cpp.d_res_d_mdot,
                f"{self.from_node}.P_total": res_cpp.d_res_dP_total,
                f"{self.from_node}.T": res_cpp.d_res_dT,
            }}

        # Both modes: compute outlet T from actual PR seen by the element
        # (forward-propagated via compute_derived_state on downstream node)
        return res, jac
```

The `TurbineStageElement` is identical except the efficiency formula
flips: `h2 = h1 - eta_is * (h1 - h2s)`. In capacity mode a choked turbine nozzle
is the most common case — `throat_area` directly gives the choking capacity.

### H.2c — Corrected Quantities (Diagnostics)

For post-solve diagnostics the element reports standard corrected quantities:
```python
def diagnostics(self, state_in, state_out):
    T_ref, P_ref = 288.15, 101325.0   # ISA sea-level
    theta = state_in.T_total / T_ref
    delta = state_in.P_total / P_ref
    PR_actual = state_out.P_total / state_in.P_total

    return {
        "PR": PR_actual,
        "eta_is": self.eta_is,
        "W_specific": h2 - h1,
        "corrected_flow": state_in.m_dot * sqrt(theta) / delta,
        "capacity": state_in.m_dot * sqrt(state_in.T_total) / state_in.P_total,
    }
```

### H.3 — Temperature Propagation

**Key insight**: outlet temperature `T2` is *derived*, not a solver unknown. It follows
the same pattern as `CombustorNode.compute_derived_state()`:

The downstream `MomentumChamberNode` (or `PlenumNode`) calls
`compute_derived_state()` which receives upstream states. For a turbomachinery
element, the upstream state arriving at the downstream node already has the correct
T2 computed via the isentropic model. This means:

- The element computes `T2_calc` during residual evaluation
- The downstream node's `compute_derived_state` receives `T2_calc` as
  `state.T_total` from the element's exit
- **No additional solver unknown** for temperature — it's forward-propagated

This is architecturally identical to how `CombustorNode` propagates `T_ad` without
making it a solver unknown.

### H.4 — C++ Residuals + Jacobians (Required)

**Architecture rule**: every element wired into the Newton solver must provide its
residuals and analytical Jacobians from C++, with a matching C++ finite-difference
accuracy test (cf. `ChannelCompressibleDerivatives`, `OrificeDerivatives` patterns in
`tests/test_solver_interface.cpp`). Python-side FD Jacobians are not acceptable for
production solver elements.

Two C++ functions are needed — one per operating mode:

#### H.4a — Prescribed-PR mode

```cpp
struct StageResult {
    double T2;           // actual outlet stagnation temperature [K]
    double T2s;          // isentropic outlet temperature [K]
    double W_specific;   // specific work h2 - h1 [J/kg]

    // Residual: P_total_out - P1 * PR = 0
    double residual;
    double d_res_dP_total_in;    // = -PR
    double d_res_dP_total_out;   // = 1

    // Derived-state Jacobians (for T propagation through mixer)
    double dT2_dT1;      // ∂T2/∂T1
    double dT2_dP1;      // ∂T2/∂P1
    double dW_dT1;       // ∂W/∂T1
    double dW_dP1;       // ∂W/∂P1
};

StageResult compressor_stage_pr_and_jacobian(
    double T1, double P1, const std::vector<double>& X,
    double P_total_out, double PR, double eta_is);

StageResult turbine_stage_pr_and_jacobian(
    double T1, double P1, const std::vector<double>& X,
    double P_total_out, double PR, double eta_is);
```

#### H.4b — Capacity mode

The capacity residual constrains mass flow:

```cpp
struct StageCapacityResult {
    double T2;           // actual outlet stagnation temperature [K]
    double T2s;          // isentropic outlet temperature [K]
    double W_specific;   // specific work h2 - h1 [J/kg]
    double PR_actual;    // observed P_total_out / P_total_in

    // Residual: m_dot * sqrt(T1) / P1 - capacity = 0
    double residual;
    double d_res_d_mdot;         // = sqrt(T1) / P1
    double d_res_dT1;            // = m_dot / (2 * sqrt(T1) * P1)
    double d_res_dP_total_in;    // = -m_dot * sqrt(T1) / P1^2

    // Derived-state Jacobians (for T propagation — same chain rule as PR mode)
    double dT2_dT1;
    double dT2_dP1;
    double dT2_dP_total_out;     // via PR_actual = P_out/P_in
    double dW_dT1;
    double dW_dP1;
};

StageCapacityResult compressor_stage_capacity_and_jacobian(
    double m_dot, double T1, double P1, const std::vector<double>& X,
    double P_total_out, double capacity, double eta_is);

StageCapacityResult turbine_stage_capacity_and_jacobian(
    double m_dot, double T1, double P1, const std::vector<double>& X,
    double P_total_out, double capacity, double eta_is);
```

**Key difference**: in capacity mode the residual depends on `m_dot`, `T1`, and
`P_total_in` (3 coupled unknowns), whereas PR mode only depends on pressures.
The T2 Jacobians now also include `∂T2/∂P_total_out` because the observed PR
changes when the downstream pressure floats.

#### H.4c — Required C++ tests

```cpp
TEST(CompressorStagePR_Derivatives, FDAccuracy) {
    // Central FD test for every Jacobian entry, tolerance < 1e-6 relative
    // Points: PR=2..30, eta=0.7..0.95, T=250..500K, air + combustion products
}

TEST(CompressorStageCapacity_Derivatives, FDAccuracy) {
    // Same FD methodology, perturb m_dot, T1, P1, P_total_out independently
}

TEST(TurbineStagePR_Derivatives, FDAccuracy) { ... }
TEST(TurbineStageCapacity_Derivatives, FDAccuracy) { ... }
```

#### H.4d — Analytical Jacobian derivation

The chain rule through the isentropic solver:
```
dT2/dT1 = (dh2/dh1) · (dT2/dh2)
         where dh2/dh1 = 1 - 1/eta_is + (1/eta_is) · (dh2s/dh1)  [compressor]
         and   dh2s/dh1 = cp(T2s) · (dT2s/dT1)
         and   dT2s/dT1 = cp(T1) / cp(T2s)   (from ds = cp·dT/T - R·dP/P = 0 at const P2)
         and   dT2/dh2  = 1 / cp(T2)
```

For the capacity residual, Jacobians are simple closed-form:
```
d_res/d_mdot = √T1 / P1
d_res/dT1    = m_dot / (2·√T1·P1)
d_res/dP1    = -m_dot·√T1 / P1²
```

All analytically tractable — no FD needed for the Jacobians themselves.

### H.5 — Network Topology Patterns

**Simple turbojet** (student exercise):
```
PressureBoundary(inlet) → Channel → CompressorStage → CombustorNode → TurbineStage → Nozzle → PressureBoundary(exit)
                                      ↑                                  ↓
                                      └──────── ShaftConnection ─────────┘
                                              (W_compressor = W_turbine)
```

**Shaft coupling** adds a global constraint: `W_compressor + W_turbine = 0`.
This is a single scalar residual linking two elements — implementable as a
`ShaftConnection` similar to `WallConnection` for thermal coupling.

**Multi-spool** extends to multiple shafts, each with its own balance equation.

### H.6 — GUI Representation

| Component | GUI Schema | Parameters |
|-----------|-----------|------------|
| `CompressorStageElement` | `CompressorData` | `mode`, `pressure_ratio`\|`capacity`\|`throat_area`, `eta_is`, `shaft_id` |
| `TurbineStageElement` | `TurbineData` | `mode`, `pressure_ratio`\|`capacity`\|`throat_area`, `eta_is`, `shaft_id` |
| `ShaftConnection` | `ShaftData` | `connected_elements[]`, `mechanical_efficiency` |

In the GUI canvas, compressor and turbine would be rendered as distinct node shapes
(trapezoids per turbomachinery convention). The shaft connection would be a dashed
line between coupled stages.

### H.7 — Off-Design Performance Maps (Future)

For off-design analysis, `pressure_ratio` and `eta_is` become functions of corrected
mass flow and corrected speed (compressor map) or expansion ratio (turbine map).
This would follow the `make_tabulated_correlation` pattern from orifice.h:

```python
CompressorStageElement(
    ...,
    performance_map=cb.CompressorMap(
        corrected_flow=[...],    # corrected mass flow points
        corrected_speed=[...],   # corrected speed lines
        PR_table=[[...]],        # PR(corrected_flow, corrected_speed)
        eta_table=[[...]],       # eta_is(corrected_flow, corrected_speed)
    ),
)
```

This is a significant feature extension and should follow the basic constant-PR
element.

### H.8 — Implementation Dependencies

| Step | Description | Depends On | Effort |
|------|------------|-----------|--------|
| **H.0** | Bind `calc_T_from_s_mass` in pybind | G.2b | Small |
| **H.1a** | C++ `*_stage_pr_and_jacobian` (compressor + turbine) | H.0 | Medium |
| **H.1b** | C++ `*_stage_capacity_and_jacobian` (compressor + turbine) | H.0 | Medium |
| **H.2** | C++ FD accuracy tests for all 4 functions (8 test cases) | H.1a, H.1b | Small |
| **H.3** | Pybind bindings for `StageResult` + `StageCapacityResult` | H.2 | Small |
| **H.4** | Python `CompressorStageElement` + `TurbineStageElement` (both modes) | H.3 | Medium |
| **H.5** | C++ `shaft_balance_residual_and_jacobian` + FD test | H.4 | Medium |
| **H.6** | Python `ShaftConnection` | H.5 | Small |
| **H.7** | GUI schemas + graph builder (mode dropdown) | H.4 | Small |
| **H.8** | Performance maps (off-design, Mode 3) | H.4, G.5a | Large |

### H.9 — Summary

The existing C++ thermo backend (`s_mass`, `h_mass`, `calc_T_from_h_mass`) plus the
missing `calc_T_from_s_mass` provides everything needed for turbomachinery stages.
The network architecture already supports the pattern (forward T propagation via
`compute_derived_state`, pressure residuals from elements). The implementation
sequence is:

1. **Bind `calc_T_from_s_mass`** — trivial, unblocks everything
2. **C++ `*_stage_pr_and_jacobian`** — prescribed-PR mode (simplest, validates thermo chain)
3. **C++ `*_stage_capacity_and_jacobian`** — capacity mode (enables system matching)
4. **C++ FD accuracy tests** for all 4 functions (central FD, < 1e-6 relative)
5. **Pybind + Python `NetworkElement` subclasses** with mode dispatch
6. **C++ `shaft_balance_residual_and_jacobian`** + FD test, then Python `ShaftConnection`

Every solver-facing function must follow the established discipline:
**C++ implementation → C++ FD test → pybind binding → Python element → integration test.**

The **capacity mode** is what makes this feature genuinely useful: it enables
compressor–turbine matching, choked turbine nozzle modelling, and coupled gas turbine
cycle analysis. The prescribed-PR mode alone is only a teaching tool.

This would make the network solver capable of modelling complete gas turbine cycles,
which is high-value for both students (thermodynamic cycle analysis) and engineers
(secondary air system + engine cycle coupling).

---

## Part I — Cooled Panel Element (Film / Effusion Cooling)

Film and effusion cooling fundamentally differ from convective walls: they involve
**mass transfer** (coolant injected through holes into the hot gas) in addition to
conduction and convection. This makes them flow elements, not wall modifiers.

### I.1 — Physical Picture

A film- or effusion-cooled wall panel sits **in-line on the cold (coolant) passage**
and bleeds a fraction of coolant through the wall into the hot gas path:

```
                      hot_element (channel/chamber in hot-gas path)
                           │
                      ─────┼───── hot-gas flow direction ──►
                           │
                    ╔══════╧══════╗
                    ║  Wall layers ║  ← conduction (hot → cold)
                    ╠═════════════╣
                    ║ CooledPanel  ║  ← cold-side convective surface
       cold_in ───►║  (element)   ╠───► cold_out  (main coolant continues)
                    ║             ║
                    ╚══════╤══════╝
                           │
                           ▼ bleed (film/effusion holes)
                      hot_gas_node  (injected coolant mixes into hot path)
```

**Three flow ports:**

| Port | Role |
|------|------|
| `cold_in` (`from_node`) | Coolant enters the panel |
| `cold_out` (`to_node`) | Bulk coolant continues downstream in cold passage |
| `bleed_out` | Fraction of coolant exits through holes into hot-gas path |

The panel is a **channel section with a pressure-driven side-bleed**. Most coolant flows
through and picks up heat from the wall; a fraction exits through discrete holes
providing film/effusion protection on the hot side.

**Heat flow:**

1. **Hot gas → wall**: convection from hot element (h_hot, T_aw_hot)
2. **Wall → coolant (in-passage)**: convection from cold-side surface (h_cold, T_aw_cold)
   — panel computes this from its own internal flow, like a channel's `ConvectiveSurface`
3. **Film effect**: injected coolant modifies the effective hot-side adiabatic wall
   temperature: `T_aw_eff = T_aw_hot − η · (T_aw_hot − T_coolant_exit)`

The cooling flow absorbs most of the heat — both via in-passage convection and via
the mass exiting through holes (which carries enthalpy away from the wall).

### I.2 — Why Not a Wall Modifier

The original plan (Part F) proposed `FilmCoolingModifier` / `EffusionCoolingModifier`
as `T_aw` modifiers on `ThermalWall`. This is insufficient because:

1. **Mass transfer**: coolant mass leaves one flow path and enters another. A
   `ThermalWall` is a pure thermal edge — it cannot carry flow.
2. **Pressure coupling**: bleed flow rate is pressure-driven:
   `m_dot_bleed = Cd · A_holes · f(ΔP_across_wall)`. This couples cold-path pressure
   to hot-path pressure — a flow residual, not a thermal one.
3. **Mass conservation**: the bleed node on the hot-gas path receives mass from the
   cold path. The solver must account for this in nodal mass balance.

A wall modifier could handle the `T_aw` correction alone, but misses the flow coupling
that makes film/effusion cooling physically meaningful in a network context.

### I.3 — Multi-Port Element (Option A)

After evaluating three integration strategies, the chosen approach is a **true
multi-port element** — a new `NetworkElement` subclass with 3+ flow ports.

**Alternatives considered:**

| Option | Approach | Pro | Con |
|--------|----------|-----|-----|
| **A** (chosen) | Multi-port `NetworkElement` | Clean abstraction, generalizes | Touches solver core |
| B | Decompose into 2 elements + internal node | Works today, no solver changes | One component = 3 elements + hidden node; GUI bundling overhead; extra unknowns |
| C | 2-port element + `MassBoundary` side-effect | Minimal graph changes | New `MassBoundary` concept needed; cross-path Jacobians still required |

**Why Option A**: the decomposition (B) becomes limiting when panels need tight
intra-component coupling (in-hole convection feedback) or when many panels inflate
the Jacobian with plumbing unknowns. Option A avoids these issues and also
generalizes to future multi-port components (splitters, bleed valves, multi-stream
mixers).

### I.4 — Required Infrastructure Changes

The current `NetworkElement` assumes exactly 2 flow ports (`from_node`, `to_node`).
A multi-port element requires changes across several layers:

**Graph (`graph.py`):**
- `add_element` currently registers exactly 2 adjacency edges. Must support N ports.
- BFS reachability (`_reachable_from`) must traverse all ports.

**Solver (`solver.py`):**
- Element residuals receive `(state_in, state_out)` — must generalize to N port states.
- Jacobian assembly assumes 2-node connectivity — must handle cross-path entries
  (bleed flow couples cold-path pressure to hot-path node).
- Mass conservation at bleed node must include the bleed mass source.

**Base class (`components.py`):**
```python
class MultiPortElement(NetworkElement):
    """Element with N named flow ports (generalizes 2-port NetworkElement)."""

    def __init__(self, id: str, ports: dict[str, str]):
        # ports maps role → node_id, e.g. {"cold_in": "n1", "cold_out": "n2", "bleed": "n3"}
        self.id = id
        self.ports = ports
        # Backward compat: from_node / to_node point to primary flow path
        self.from_node = ports.get("cold_in", "")
        self.to_node = ports.get("cold_out", "")
```

### I.5 — `CooledPanelElement` Design

```python
@dataclass
class CooledPanelElement(MultiPortElement):
    """Film/effusion cooled wall panel.

    Flow: cold_in → cold_out (main coolant), bleed → hot-gas node
    Thermal: hot_ref identifies the hot-side convective element/node
    Wall: built-in layers for conduction
    Convective: built-in ConvectiveSurface for cold-side HTC
    """
    # --- thermal references ---
    hot_ref: str                           # element/node ID providing hot-side h, T_aw
    layers: list[WallLayer]                # wall conduction layers
    contact_area: float | None = None      # override area [m^2]

    # --- cold-side convection (panel IS the cold channel) ---
    surface: ConvectiveSurface             # cold-side HTC model
    diameter: float = 0.01                 # hydraulic diameter of cold channel [m]
    length: float = 0.1                    # channel length [m]

    # --- cooling model ---
    cooling: FilmModel | EffusionModel | None = None   # None = pure wall
    hole_diameter: float = 0.001           # [m]
    hole_angle: float = 30.0               # injection angle [deg]
    porosity: float = 0.0                  # hole open area fraction (effusion)
    hole_spacing_D: float = 3.0            # s/D (film)
    row_positions_xD: list[float] | None = None  # multi-row positions (film)
```

### I.6 — Residuals Contributed

1. **Momentum (cold passage)**: ΔP from friction in the cold channel — like a channel
2. **Mass split**: `m_dot_in = m_dot_out + m_dot_bleed`
3. **Bleed flow** (pressure-driven): `m_dot_bleed = Cd · A_holes · f(ΔP_cold_to_hot)`
   using `effusion_discharge_coefficient(Re_d, P_ratio, α, L/D)`
4. **Wall coupling**: Q computed from wall layers + modified hot-side T_aw_eff

**Cross-path Jacobians**: the bleed residual couples `P_cold` (cold passage) to
`P_hot` (hot-gas node), creating off-diagonal Jacobian blocks between otherwise
independent flow paths. The chain rule through blowing ratio M connects to solver
unknowns: `M = ρ_c · v_c / (ρ_hot · v_hot)`.

### I.7 — Graceful Degradation

| Condition | Behavior |
|-----------|----------|
| `bleed_out` unconnected | m_dot_bleed = 0, η = 0, no film effect |
| `cooling = None` | Pure conductive wall with cold-side convection |
| `hot_ref` unconnected | Cold-side-only convection (no wall coupling) |
| All unconnected | No thermal or flow effect (dormant element) |

This lets engineers start with a convective wall and incrementally add cooling.

### I.8 — Cooling Sub-Models

Both film and effusion share the 3-port topology but differ in physics:

| Property | Film | Effusion |
|----------|------|----------|
| Hole density | Sparse (discrete rows) | Dense (many holes) |
| Effectiveness | `film_cooling_effectiveness_and_jacobian` | `effusion_effectiveness_and_jacobian` |
| Key params | x/D, M, DR, α, row positions | x/D, M, DR, porosity, s/D, α |
| Cd model | Simple orifice Cd | `effusion_discharge_coefficient` |
| In-hole cooling | Negligible | Significant (coolant cools wall in-hole) |

All C++ functions with Jacobians already exist (see Part F inventory).

### I.9 — GUI Representation

```
         thermal-hot (top handle) ← connects to hot-gas channel/chamber
              │
    ┌─────────┴─────────┐
    │                    │
 ●──┤   Cooled Panel     ├──●   cold_in / cold_out (left/right)
    │  Film / Effusion   │
    └─────────┬─────────┘
              │
         bleed-out (bottom handle) ← connects to hot-gas node
```

- **Left/Right handles**: flow (coolant in → coolant out, main path)
- **Top handle**: thermal reference (hot-side element)
- **Bottom handle**: bleed flow (mass injection into hot-gas node)
- When bleed handle is unconnected: element is dormant for bleed, acts as convective wall

**Inspector controls:**
- Wall layers (reuse existing `WallLayersEditor`)
- Cooling model selector: None / Film / Effusion
- Hole geometry: diameter, angle, spacing, porosity (model-dependent)
- Row positions (film only): streamwise x/D of each row

### I.10 — Classical Network Model for Effusion

In established 1D effusion network models (Krewinkel 2013, Jackowski 2016), the
cooled panel is discretized into a node–branch network:

```
         hot gas path
    ═══════╤═══════╤═══════╤═══════
           │ hole  │ hole  │ hole
    ───●───┼───●───┼───●───┼───●───  cold passage
    plenum  N1      N2      N3   exit
```

- **Nodes** represent pressure and temperature at discrete stations along the cold
  passage (plenum inlet, hole midpoints, passage exit). Each node carries the
  cumulative thermal state — how much heat the coolant has absorbed upstream.

- **Branches** (holes) are the physics-carrying elements. Each hole is characterized
  by its discharge coefficient Cd(Re, P_ratio, α, L/D) and the local blowing
  ratio M = ρ_c·v_c / (ρ_hot·v_hot). The mass flow through each hole is
  pressure-driven: `m_dot_hole = Cd · A_hole · f(ΔP_cold_to_hot)`.

- **Advection** (coolant history): the model tracks how the coolant heats up as it
  flows along the cold passage. Upstream holes see colder coolant; downstream holes
  see warmer coolant that has already absorbed heat. This thermal "history" couples
  all holes — the effectiveness of downstream holes depends on upstream heat pickup.

This maps directly onto the `CooledPanelElement` design. The **baseline approach is
chaining**: each `CooledPanelElement` represents one zone (one or a few hole rows)
with a single bleed port. Multi-zone coverage is achieved by chaining panels along
the cold passage:

```
    cold_in → [Panel_1] → [Panel_2] → [Panel_3] → cold_out
                 ↓ bleed     ↓ bleed     ↓ bleed
              hot_node_1  hot_node_2  hot_node_3
```

Advection is handled naturally by the existing solver: each panel's `cold_out`
feeds the next panel's `cold_in`, so downstream panels automatically see warmer
coolant. No special treatment needed — this is the same temperature propagation
that chained `ChannelElement`s already use.

**Why chaining over internal discretization:** simpler per-element (fixed 3 ports),
composable (mix film and effusion zones), and the solver already supports chained
elements. Internal multi-row discretization could be added later as an optimization
for dense arrays, but is not required for the initial implementation.

**Fidelity ceiling:** a 1D chained network captures the dominant physics (pressure-
driven bleed, coolant history, film effectiveness decay) but cannot resolve 3D
effects (jet–crossflow interaction, lateral spreading, vortex structures). For
higher fidelity, the natural next step is coupled 1D-network ↔ CFD
(cf. Mefferd et al. 2022), which is outside the scope of this framework.

### I.11 — Implementation Scope

This feature requires `MultiPortElement` infrastructure which is a significant
extension of the solver core. It should be implemented on a **dedicated feature
branch** after the current branch (Phases 1–6) is complete.

**Dependency chain:**
1. `MultiPortElement` base class + graph registration (N-port adjacency)
2. Solver generalization (N-port residuals + Jacobian assembly)
3. `CooledPanelElement` implementation (flow + thermal + cooling model)
4. C++ `cooled_panel_residuals_and_jacobian` + FD accuracy tests
5. GUI schema + graph builder + 4-handle node component
6. Integration tests (single panel, multi-zone combustor liner)

The same `MultiPortElement` infrastructure also unblocks future components like
bleed valves, multi-stream mixers, and intercoolers.

### I.12 — References

- Aumeier, T., & Behrendt, T. (2015). Application of an aerothermal model for
  effusion cooling systems and finite rate chemistry in aero-engine combustors.
  *Proc. THMT-15*, doi:10.1615/ichmt.2015.thmt-15.1930
- Xia, H., Chen, X., & Ellis, C. D. (2024). Modelling and simulation of effusion
  cooling — A review of recent progress. *Energies*, 17(17), 4480.
  doi:10.3390/en17174480
- Yi, B., Liu, Z., Xiong, Y., Liu, Y., & Wei, X. (2023). Influence of blowing
  ratio on double-wall cooling characteristics under high-temperature flue gas.
  *Proc. GPPS*, doi:10.33737/gpps23-tc-126
- Numerical investigation of gas turbine combustor cooling performance with Bézier
  effusion holes. (2026). *J. Thermophys. Heat Transfer*.
  https://arc.aiaa.org/doi/10.2514/1.T7282
- Parametric and correlation study of effusion cooling applied to gas turbine
  blades. (2024). *Applied Sciences*, 15(17), 9778.
  https://www.mdpi.com/2076-3417/15/17/9778
- Bunker, R. S. (2005). A review of shaped hole turbine film cooling technology.
  *J. Heat Transfer*, 127(4). — Definitive reference on hole geometry effects
  (square, fan, conical) on film physics.
- Bogard, D. G., & Thole, K. A. (2006). Gas turbine film cooling.
  *J. Propulsion and Power*, 22(2). — Seminal review defining standard
  dimensionless parameters (M, DR) used throughout modern film cooling research.
- Dorrington, I., et al. (2018). The effect of trench geometry on film cooling.
  *J. Turbomachinery*. — Surface modifications for enhanced film stability.
- Ling, Y., et al. (2023). Optimization of film cooling performance via additive
  manufacturing. — Internal turbulators inside film holes enabled by 3D printing.
- Mefferd, L., et al. (2022). Coupled 1D network–CFD for turbine airfoil effusion
  cooling. — 1D plenum flow network coupled to 3D CFD for film development.
- Krewinkel, R. (2013). A design tool for effusion cooling. — Thermal resistance
  network for predicting wall temperatures in aero-engine combustor liners.
- Jackowski, T., et al. (2016). Flow network modelling of double-wall effusion
  systems. — Identifies coolant starvation zones from pressure-driven flow
  distribution.
- Scrittore, J. J., et al. (2007). Experimental validation of 1D effusion models.
  — Provides Cd calibration data for flow network models of large-scale effusion
  arrays.
