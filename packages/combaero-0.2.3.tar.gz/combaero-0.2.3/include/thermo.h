#ifndef THERMO_H
#define THERMO_H

#include "state.h"
#include "composition.h"
#include <cstddef>
#include <string>
#include <vector>

namespace combaero::thermo {

// Universal gas constant [J/(mol·K)]
constexpr double R_GAS = 8.31446261815324;

// Boltzmann constant [J/K]
constexpr double BOLTZMANN = 1.380649e-23;

// Avogadro's number [1/mol]
constexpr double AVOGADRO = 6.02214076e23;

} // namespace combaero::thermo

namespace combaero {

// Conversion factor from J/mol to J/kg
double J_per_mol_to_J_per_kg(double value, double molar_mass);

// Species metadata and lookup functions
std::string species_name(std::size_t idx);
std::size_t species_index_from_name(const std::string& name);
std::size_t num_species();

// Molar mass of a species [g/mol]
double species_molar_mass(std::size_t idx);
double species_molar_mass_from_name(const std::string& name);

// NASA polynomial evaluations (dimensionless)
double cp_R(std::size_t species_idx, double T);
double h_RT(std::size_t species_idx, double T);
double s_R(std::size_t species_idx, double T);
double g_over_RT(std::size_t species_idx, double T);

// Per-species dimensional properties
double cp_species(std::size_t species_idx, double T);  // [J/(mol·K)]
double h_species(std::size_t species_idx, double T);   // [J/mol]
double s_species(std::size_t species_idx, double T);   // [J/(mol·K)] at P_ref

// Thermodynamic properties
double cp(double T, const std::vector<double>& X);
double h(double T, const std::vector<double>& X);
double s(double T, const std::vector<double>& X, double P, double P_ref = 101325.0);
double cv(double T, const std::vector<double>& X);
double u(double T, const std::vector<double>& X);  // Internal energy [J/mol]
double density(double T, double P, const std::vector<double>& X);
double molar_volume(double T, double P);  // Ideal gas molar volume [m³/mol]
double specific_gas_constant(const std::vector<double>& X);
double isentropic_expansion_coefficient(double T, const std::vector<double>& X);
double speed_of_sound(double T, const std::vector<double>& X);

// Mass-specific thermodynamic properties
double cp_mass(double T, const std::vector<double>& X);
double cv_mass(double T, const std::vector<double>& X);
double h_mass(double T, const std::vector<double>& X);
double s_mass(double T, const std::vector<double>& X, double P, double P_ref = 101325.0);
double u_mass(double T, const std::vector<double>& X);

// Compute all air properties at once
AirProperties air_properties(double T, double P, double humidity = 0.0);

// Compute all thermodynamic properties at once
ThermoState thermo_state(double T, double P, const std::vector<double>& X, double P_ref = 101325.0);

// Compute all thermodynamic and transport properties at once
CompleteState complete_state(double T, double P, const std::vector<double>& X, double P_ref = 101325.0);

// Derivatives of thermodynamic properties with respect to temperature
double dh_dT(double T, const std::vector<double>& X);
double ds_dT(double T, const std::vector<double>& X);
double dcp_dT(double T, const std::vector<double>& X);
double dg_over_RT_dT(double T, const std::vector<double>& X);

// Inverse calculations (solving for temperature)
double calc_T_from_h(double h_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_s(double s_target, double P, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_cp(double cp_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_u(double u_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);

// Inverse calculations for mass-specific targets
double calc_T_from_h_mass(double h_mass_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_s_mass(double s_mass_target, double P, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_u_mass(double u_mass_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_sv_mass(double s_mass_target, double v_mass_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);
double calc_T_from_sh_mass(double s_mass_target, double h_mass_target, const std::vector<double>& X, double T_guess = 300.0, double tol = 1.0e-6, std::size_t max_iter = 50);

// State-based overloads
double mwmix(const State& s);
double cp(const State& s);
double h(const State& s);
double s(const State& s);
double cv(const State& s);
double u(const State& s);
double density(const State& s);
double specific_gas_constant(const State& s);
double isentropic_expansion_coefficient(const State& s);
double speed_of_sound(const State& s);

} // namespace combaero

#endif // THERMO_H
