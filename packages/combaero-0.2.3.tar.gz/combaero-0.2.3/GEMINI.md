# CombAero AI/Agent Development Guide

This document outlines the hard rules, coding styles, and project conventions for AI agents (like Gemini, Claude, or Cursor) working on the CombAero project. **These rules must be strictly followed.**

## 1. Hard Rules & Constraints

*   **No system Python installs:** Agents **must never** install packages into the system Python or use global `pip`.
*   **Virtual Environment Only:** Always use the project-local virtual environment. `uv` handles this automatically. If you must use a shell, use `uv run` or ensure `.venv` is activated.
*   **Do not bypass checks:** Never bypass Git pre-commit hooks or GitHub Actions runner checks. All code must pass these checks cleanly.
*   **Auto-generated files:** Do not manually edit auto-generated files. They will be overwritten. Use the designated scripts to regenerate them.
*   **Cross-Platform CI Strictness:** GitHub Actions runs compilation and tests across macOS, Windows, and Linux. Ensure all standard library includes (e.g. `<cmath>`, `<vector>`) are explicitly defined. Code that compiles natively on macOS may still fail on Linux/Windows due to stricter compiler requirements.
*   **API Documentation Synchronization**: If you add, remove, or modify any function signature, struct, property getter/setter, or unit, you **must autonomously** update `include/units_data.h` and the relevant API reference ([API_CPP.md](docs/API_CPP.md) or [API_PYTHON.md](docs/API_PYTHON.md)) to stay in sync. Do not wait for a specific user request to do this.
*   **Documentation Hygiene**: Follow the classification defined in [HYGIENE.md](docs/HYGIENE.md). Keep technical reports in `docs/archive/` and keep core guides focused and high-signal.
*   **Unit Sync Enforcement:** The project strictly enforces that **all** exported Python API elements (functions, class methods/properties) have a corresponding metadata entry in `include/units_data.h`. This is enforced by `python/tests/test_units_sync.py`. If you add a new Python submodule, utility function without physical units, or a structural enum, you **must** add it to the `IGNORE_LIST` in `test_units_sync.py` to prevent CI failures. Conversely, if you add a calculation, you MUST map it in `units_data.h`.
*   **Solver (f, J) Tuple Rule:** Any code calculation intended to be consumed by the global network solver must expose a dedicated fast-path PyBind11 C++ API returning `std::tuple<double, double>` representing `(value, derivative)`. Mathematical analytical derivatives should be prioritized via the chain-rule for algebraic variables; finite differences should be permanently wrapped and sandboxed inside C++ instead of exposing the noise directly to Python.
*   **Define Once (Physics Constants):** Never use "magic numbers" for physics coefficients (e.g., empirical correlation constants like 3.7 or 1.11 in the Haaland equation) directly inside `.cpp` files. They must be explicitly defined once as `constexpr` variables inside a conceptually related `namespace` block within the public header (e.g., `include/friction.h`). All subsequent C++ methods, including analytical solver Jacobians, must re-use these centralized header definitions.
## 2. Coding Style

### C++ (Modern C++17)

*   **Standard:** Use C++17 features (the project baseline).
*   **Memory Management:** Prefer smart pointers (`std::unique_ptr`, `std::shared_ptr`) over raw pointers. Never use `new` or `delete` manually. Be strictly RAII compliant.
*   **Header Hygiene:** Use `#pragma once` in all header files. Keep includes sorted and minimal (include what you use).
*   **Type Safety:** Use `auto` for complex iterator types, but keep variable types explicit where it aids readability.
*   **Comments:** Use line comments (`//`) only. Block comments (`/* ... */`) are flagged by the style checker.
*   **Math Constants:** Use `math_constants.h` instead of macros like `M_PI` to ensure MSVC (Windows) does not fail compilation due to missing definitions.
*   **Encoding:** Only ASCII characters are allowed outside of strings and comments.

### Python (Type-Safe & Clean)

*   **Type Hinting:** Mandatory type annotations for all function signatures (arguments and return types). Avoid `Any` unless absolutely necessary.
*   **Modern Typing:** Use the `|` operator for unions (e.g., `str | None`) instead of `Union` or `Optional` (project targets Python 3.12).
*   **Explicit Returns:** Always include `-> None` for functions that do not return a value.
*   **LBYL (Look Before You Leap):** Proactively check conditions rather than relying on `try/except` for control flow.
*   **Formatting/Linting:** The project uses `ruff` for both linting and formatting. Ensure code complies by running the formatters locally.
*   **Encoding:** Strictly no non-ASCII characters allowed anywhere in Python files (including docstrings and comments).

## 3. Auto-Generated Files & Scripts

Several critical files in this project are auto-generated. **Do not modify the targets directly.** Modify the source data or generation script, then run the proper updater.

### Units Documentation (`docs/UNITS.md`)
*   **Source:** `include/units_data.h`
*   **Action:** If fixing a unit description or adding a section, modify the C++ header, then run `uv run scripts/generate_units_md.py` to regenerate the markdown.

### Thermodynamic & Transport Data (`include/thermo_transport_data.h`)
*   **Source:** NASA CEA output text files and Cantera YAML mechanisms (external), combined into a local JSON cache.
*   **Generator Directory:** `thermo_data_generator/`
*   **Action:** To update the C++ thermo data header, use the scripts inside `thermo_data_generator/` (e.g., `generate_thermo_data.py`). See `thermo_data_generator/README.md` for the exact multi-step process.

## 4. Environment & Tooling Usage

### The Virtual Environment (`.venv`)
The root `.venv` is the single source of truth for all Python operations in this repository:
*   Building the C++ Python wheel binding (`scikit-build-core`)
*   Running C++/Python tests via `pytest`
*   Running the thermo data generators
*   Code style checks (`ruff`, `mypy`) via `./scripts/check-python-style.sh`

**To ensure the environment is correct:**
```bash
./scripts/bootstrap.sh
# Then use uv run for any command
uv run <command>
```

### Script Execution and Verification
Before committing code, verify it locally using the provided scripts:

*   **Check C++ Style:** `./scripts/check-source-style.sh`
*   **Check Python Style (and format):** `./scripts/check-python-style.sh --fix`
*   **Run Clang-Tidy:** `./scripts/run-clang-tidy.sh` (requires a CMake build directory with `compile_commands.json`)
*   **Run Test Suites:**
    *   C++: `cd build && ctest`
    *   Python: `uv run pytest python/tests`
    *   Cantera Validation: `CANTERA_DATA="$PWD/cantera_validation_tests" uv run --project cantera_validation_tests pytest -v`

### Version Synchronization
When updating tool versions or Python targets, ensure the following files remain synchronized:
1.  `.python-version`
2.  `ruff.toml` (`target-version`)
3.  `.github/workflows/ci.yml`
4.  `.github/workflows/validation-tests.yml`
5.  `.pre-commit-config.yaml`
6.  `Makefile` and the `.sh` scripts in `scripts/`
