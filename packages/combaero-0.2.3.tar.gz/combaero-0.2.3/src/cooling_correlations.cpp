#include "cooling_correlations.h"
#include "heat_transfer.h"
#include "math_constants.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include <string>

namespace combaero::cooling {

// -------------------------------------------------------------
// Helper Functions
// -------------------------------------------------------------

void validate_rib_params(double e_D, double pitch_to_height) {
    if (e_D < 0.02 || e_D > 0.1) {
        throw std::runtime_error(
            "Rib height ratio e_D = " + std::to_string(e_D) +
            " is outside valid range [0.02, 0.1]"
        );
    }
    if (pitch_to_height < 5.0 || pitch_to_height > 20.0) {
        throw std::runtime_error(
            "Rib pitch-to-height ratio pitch_to_height = " + std::to_string(pitch_to_height) +
            " is outside valid range [5, 20]"
        );
    }
}

void validate_rib_params(double e_D, double pitch_to_height, double alpha_deg) {
    validate_rib_params(e_D, pitch_to_height);
    if (alpha_deg < 30.0 || alpha_deg > 90.0) {
        throw std::runtime_error(
            "Rib angle alpha_deg = " + std::to_string(alpha_deg) +
            " deg is outside valid range [30, 90] deg"
        );
    }
}

void validate_impingement_params(double Re_jet, double z_D, double x_D, double y_D) {
    // Re_jet: correlation is Nu = C*Re^0.7*Pr^0.42 (power law, smooth extrapolation).
    // Warn rather than throw — the function is well-behaved outside [5000, 80000].
    if (Re_jet < 5000.0 || Re_jet > 80000.0) {
        std::cerr << "[combaero] impingement_nusselt: Re_jet = " << Re_jet
                  << " is outside validated range [5000, 80000]."
                     " Extrapolating power-law correlation; check results.\n";
    }
    if (z_D < 1.0 || z_D > 12.0) {
        throw std::runtime_error(
            "Jet-to-plate distance z_D = " + std::to_string(z_D) +
            " is outside valid range [1, 12]"
        );
    }
    if (x_D > 0.0 || y_D > 0.0) {
        if (x_D < 4.0 || x_D > 16.0) {
            throw std::runtime_error(
                "Streamwise spacing x_D = " + std::to_string(x_D) +
                " is outside valid range [4, 16]"
            );
        }
        if (y_D < 4.0 || y_D > 16.0) {
            throw std::runtime_error(
                "Spanwise spacing y_D = " + std::to_string(y_D) +
                " is outside valid range [4, 16]"
            );
        }
    }
}

void validate_film_cooling_params(double M, double DR, double alpha_deg) {
    if (M < 0.3 || M > 2.5) {
        throw std::runtime_error(
            "Blowing ratio M = " + std::to_string(M) +
            " is outside valid range [0.3, 2.5]"
        );
    }
    if (DR < 1.2 || DR > 2.0) {
        throw std::runtime_error(
            "Density ratio DR = " + std::to_string(DR) +
            " is outside valid range [1.2, 2.0]"
        );
    }
    if (alpha_deg < 20.0 || alpha_deg > 90.0) {
        throw std::runtime_error(
            "Injection angle alpha = " + std::to_string(alpha_deg) +
            " deg is outside valid range [20, 90] deg"
        );
    }
}

// -------------------------------------------------------------
// Rib-Enhanced Cooling
// -------------------------------------------------------------

double rib_enhancement_factor(double e_D, double pitch_to_height, double alpha_deg) {
    // Geometry-only overload (Re-independent).
    // Angle function: monotonically increasing with alpha_deg (90° ribs highest).
    // For Re-dependent results use rib_enhancement_factor(e_D, pitch_to_height, alpha_deg, Re).
    validate_rib_params(e_D, pitch_to_height, alpha_deg);
    double alpha_rad = alpha_deg * M_PI / 180.0;
    double f_alpha = 0.8 + 0.4 * std::sin(alpha_rad);  // monotone: 30°->1.0, 90°->1.2
    double pitch_factor = std::pow(pitch_to_height / 10.0, -0.15);
    return 3.5 * std::pow(e_D, 0.35) * pitch_factor * f_alpha;
}

double rib_enhancement_factor_high_re(double e_D, double pitch_to_height,
                                      double alpha_deg, double Re) {
    // Singh & Ekkad (2017) direct empirical fit for Re = 30k-400k.
    // Nu/Nu0 = C * Re^(-0.12) * (e/D)^0.38 * (P/e)^(-0.11) * F(alpha)
    //
    // C=54.9, n=-0.1755 fitted by least-squares to all 5 tabulated rows at
    // reference geometry (e/D=0.0625, P/e=10, 90 deg): max error < 1%.
    //   Re=30k->2.45, Re=60k->2.15, Re=100k->1.95, Re=200k->1.75, Re=400k->1.55
    // Source text states C=0.38, n=-0.12 which has a decimal-point error in C
    // and a slightly too-shallow Re exponent.
    //
    // Angle function F(alpha): 1.0 at 90 deg, ~1.13 at 60 deg (stronger secondary
    // flows from angled ribs). Form: F = 1.0 + 0.15*sin(2*alpha).
    //   90 deg -> sin(180 deg) = 0 -> F = 1.00
    //   60 deg -> sin(120 deg) = 0.866 -> F = 1.13
    //   45 deg -> sin(90 deg)  = 1.0   -> F = 1.15  (peak)
    //
    // Validated against all 5 tabulated rows within +/-1%.
    //
    // References:
    //   Singh, P. & Ekkad, S. (2017) ASME GT2016-56363
    //   Han, J.C. & Zhang, Y.M. (1992) J. Heat Transfer 114(1), 141-148
    validate_rib_params(e_D, pitch_to_height, alpha_deg);

    double alpha_rad = alpha_deg * M_PI / 180.0;
    double F_alpha = 1.0 + 0.15 * std::sin(2.0 * alpha_rad);
    double abs_Re = std::abs(Re);
    double enhancement = 54.9
        * std::pow(std::max(abs_Re, 1.0), -0.1755)
        * std::pow(e_D, 0.38)
        * std::pow(pitch_to_height, -0.11)
        * F_alpha;

    return std::clamp(enhancement, 0.8, 4.0);
}

double rib_friction_multiplier_high_re(double e_D, double pitch_to_height) {
    // Singh & Ekkad (2017) friction correlation for the fully-rough regime.
    // f/f0 = C * (e/D)^0.85 * (P/e)^(-0.25)   (Re-independent)
    //
    // C=125.0 back-calculated from tabulated data at reference geometry
    // (e/D=0.0625, P/e=10): f/f0 ~ 6.3.
    //   125 * 0.0625^0.85 * 10^(-0.25) = 125 * 0.0943 * 0.5623 = 6.63  (+5%)
    // Source text states C=12.5 which is a decimal-point error (~10x too small).
    //
    // Reference: Singh, P. & Ekkad, S. (2017) ASME GT2016-56363
    validate_rib_params(e_D, pitch_to_height);

    return 125.0
        * std::pow(e_D, 0.85)
        * std::pow(pitch_to_height, -0.25);
}

double thermal_performance_factor(double Nu_ratio, double f_ratio) {
    // Webb & Eckert (1972) thermal-hydraulic performance factor.
    // eta = (Nu/Nu0) / (f/f0)^(1/3)
    // Compares heat transfer gain against pumping power penalty at equal velocity.
    // eta > 1: net improvement over smooth; eta < 1: pressure-drop generator.
    //
    // Cross-check against Singh & Ekkad tabulated data (e/D=0.0625, P/e=10, 90 deg):
    //   Re=30k:  2.45 / 6.50^(1/3) = 2.45 / 1.866 = 1.31  (table: 1.31)
    //   Re=100k: 1.95 / 6.30^(1/3) = 1.95 / 1.849 = 1.05  (table: 1.05)
    //   Re=400k: 1.55 / 6.20^(1/3) = 1.55 / 1.838 = 0.84  (table: 0.84)
    //
    // Reference: Webb, R.L. & Eckert, E.R.G. (1972)
    //   Int. J. Heat Mass Transfer 15(8), 1647-1658
    return Nu_ratio / std::pow(f_ratio, 1.0 / 3.0);
}

double rib_friction_multiplier(double e_D, double pitch_to_height) {
    validate_rib_params(e_D, pitch_to_height);

    // Han et al. (1988) friction correlation
    // f/f_smooth = C * (e/D)^a * (P/e)^b
    double multiplier = 9.0 * std::pow(e_D, 0.45) * std::pow(pitch_to_height, -0.25);

    return multiplier;
}

// -------------------------------------------------------------
// Impingement Cooling
// -------------------------------------------------------------

double impingement_nusselt(double Re_jet, double Pr, double z_D,
                          double x_D, double y_D) {
    validate_impingement_params(Re_jet, z_D, x_D, y_D);

    // Smooth pseudo-Huber absolute value to prevent infinite Jacobian
    // gradients at Re_jet ~ 0: sqrt(Re^2 + e^2). e=10.0 provides a soft
    // differentiable landing and handles negative/reverse flow gracefully.
    double Re_safe = std::sqrt(Re_jet * Re_jet + 100.0);

    // Florschuetz et al. (1981) correlation
    // For jet array with crossflow

    bool is_array = (x_D > 0.0 && y_D > 0.0);

    if (!is_array) {
        // Single jet correlation (Martin 1977)
        double Nu = 0.42 * std::pow(Re_safe, 0.55) * std::pow(Pr, 0.4) *
                    std::pow(z_D, -0.05);
        return Nu;
    } else {
        // Jet array with crossflow (Florschuetz et al. 1981)
        // Accounts for spent air crossflow degrading downstream jets

        // Geometric factor
        double G = std::sqrt(x_D * y_D);

        // Crossflow degradation factor (stronger effect)
        double f_crossflow = 1.0 / (1.0 + 0.6 * std::pow(G / z_D, 0.7));

        // Base Nusselt number (lower than single jet)
        double Nu_base = 0.38 * std::pow(Re_safe, 0.55) * std::pow(Pr, 0.4);

        // Height correction
        double f_height = std::pow(z_D / 6.0, -0.05);

        return Nu_base * f_crossflow * f_height;
    }
}

// -------------------------------------------------------------
// Film Cooling Effectiveness
// -------------------------------------------------------------

double film_cooling_effectiveness(double x_D, double M, double DR, double alpha_deg) {
    validate_film_cooling_params(M, DR, alpha_deg);

    if (x_D < 0.0) {
        throw std::runtime_error(
            "Downstream distance x_D = " + std::to_string(x_D) +
            " must be non-negative"
        );
    }

    // Baldauf et al. (2002) correlation
    // eta = f(x/D, M, DR, alpha)

    // Convert angle to radians
    double alpha_rad = alpha_deg * M_PI / 180.0;

    // Momentum flux ratio I = (rho_c*v_c^2)/(rho_inf*v_inf^2) = M^2 / DR
    [[maybe_unused]] double I = M * M / DR;

    // Optimal blowing ratio (where effectiveness peaks)
    double M_opt = 0.6 * std::pow(DR, 0.5);

    // Blowing ratio correction (effectiveness drops if M too high or low)
    double f_M = std::exp(-0.8 * std::pow((M - M_opt) / M_opt, 2.0));

    // Angle correction (shallow angles give better coverage)
    // Lower angles (30 deg) should give higher effectiveness than steep (90 deg)
    double f_alpha = 1.2 - 0.4 * std::sin(alpha_rad);

    // Streamwise decay
    double decay = std::exp(-0.08 * x_D);

    // Peak effectiveness (at hole exit) - higher base value
    double eta_0 = 0.75 * f_M * f_alpha;

    // Effectiveness at x_D
    double eta = eta_0 * decay;

    // Clamp to [0, 1]
    return std::max(0.0, std::min(1.0, eta));
}

double film_cooling_effectiveness_avg(double x_D, double M, double DR,
                                     double alpha_deg, double s_D) {
    validate_film_cooling_params(M, DR, alpha_deg);

    if (x_D < 0.0) {
        throw std::runtime_error(
            "Downstream distance x_D = " + std::to_string(x_D) +
            " must be non-negative"
        );
    }
    if (s_D < 2.0 || s_D > 6.0) {
        throw std::runtime_error(
            "Hole spacing s_D = " + std::to_string(s_D) +
            " is outside valid range [2, 6]"
        );
    }

    // Laterally averaged effectiveness (Baldauf et al. 2002)
    // Accounts for hole spacing and jet spreading

    // Get centerline effectiveness
    double eta_centerline = film_cooling_effectiveness(x_D, M, DR, alpha_deg);

    // Lateral spreading factor (closer holes -> better coverage)
    double f_spacing = 1.0 - 0.15 * (s_D - 3.0);

    // Averaged effectiveness is lower than centerline
    double eta_avg = eta_centerline * f_spacing * 0.7;

    // Clamp to [0, 1]
    return std::max(0.0, std::min(1.0, eta_avg));
}

// Multi-row film cooling using Sellers (1963) superposition principle
// Combines effectiveness from multiple upstream rows
double film_cooling_multirow_sellers(
    const std::vector<double>& row_positions_xD,
    double eval_xD,
    double M,
    double DR,
    double alpha_deg
) {
    // Validate inputs
    if (row_positions_xD.empty()) {
        throw std::runtime_error("row_positions_xD cannot be empty");
    }

    // Sellers superposition: eta_total = 1 - product(1 - eta_i)
    // Each row contributes based on its local x/D from injection point
    double product_term = 1.0;

    for (double row_x : row_positions_xD) {
        double local_xD = eval_xD - row_x;

        // Only consider upstream rows (local_xD > 0)
        if (local_xD > 0.0) {
            // Get single-row effectiveness using Baldauf correlation
            // Parameter validation happens inside film_cooling_effectiveness
            double eta_i = film_cooling_effectiveness(local_xD, M, DR, alpha_deg);
            product_term *= (1.0 - eta_i);
        }
    }

    return 1.0 - product_term;
}

// -------------------------------------------------------------
// Effusion Cooling
// -------------------------------------------------------------

// Validate effusion cooling parameters
void validate_effusion_params(double M, double DR, double porosity, double s_D, double alpha_deg) {
    if (M < 1.0 || M > 4.0) {
        throw std::runtime_error("Effusion blowing ratio M must be in range [1.0, 4.0], got " + std::to_string(M));
    }
    if (DR < 1.2 || DR > 2.0) {
        throw std::runtime_error("Density ratio DR must be in range [1.2, 2.0], got " + std::to_string(DR));
    }
    if (porosity < 0.02 || porosity > 0.10) {
        throw std::runtime_error("Porosity must be in range [0.02, 0.10], got " + std::to_string(porosity));
    }
    if (s_D < 4.0 || s_D > 8.0) {
        throw std::runtime_error("Hole spacing s_D must be in range [4.0, 8.0], got " + std::to_string(s_D));
    }
    if (alpha_deg < 20.0 || alpha_deg > 45.0) {
        throw std::runtime_error("Injection angle alpha must be in range [20, 45] degrees, got " + std::to_string(alpha_deg));
    }
}

// Validate effusion discharge coefficient parameters
void validate_effusion_discharge_params(double Re_d, double P_ratio, double alpha_deg, double L_D) {
    if (Re_d < 3000.0) {
        throw std::runtime_error("Hole Reynolds number Re_d must be > 3000, got " + std::to_string(Re_d));
    }
    if (P_ratio < 1.02 || P_ratio > 1.15) {
        throw std::runtime_error("Pressure ratio P_ratio must be in range [1.02, 1.15], got " + std::to_string(P_ratio));
    }
    if (alpha_deg < 20.0 || alpha_deg > 45.0) {
        throw std::runtime_error("Injection angle alpha must be in range [20, 45] degrees, got " + std::to_string(alpha_deg));
    }
    if (L_D < 2.0 || L_D > 8.0) {
        throw std::runtime_error("Hole length/diameter L_D must be in range [2.0, 8.0], got " + std::to_string(L_D));
    }
}

// Effusion cooling effectiveness
// Based on Lefebvre (1984) momentum flux ratio approach with crossflow effects
double effusion_effectiveness(
    double x_D,
    double M,
    double DR,
    double porosity,
    double s_D,
    double alpha_deg
) {
    // Validate parameters
    validate_effusion_params(M, DR, porosity, s_D, alpha_deg);

    if (x_D < 0.0) {
        throw std::runtime_error("Distance x_D must be non-negative, got " + std::to_string(x_D));
    }

    // Convert angle to radians
    double alpha_rad = alpha_deg * M_PI / 180.0;

    // Momentum flux ratio (key parameter for effusion)
    // I = (rho_c * v_c^2) / (rho_inf * v_inf^2) = M^2 * DR
    double I = M * M * DR;

    // Effective blowing ratio accounting for hole density
    // Higher porosity → more coolant → higher effective coverage
    [[maybe_unused]] double M_eff = M * std::sqrt(porosity / 0.05);  // Normalized to 5% porosity

    // Crossflow accumulation factor (L'Ecuyer & Matsuura 1985)
    // Effusion builds up crossflow, reducing effectiveness decay
    double crossflow_factor = 1.0 + 0.3 * porosity * x_D / s_D;

    // Angle correction (shallow angles better for lateral spreading)
    double f_angle = 1.0 - 0.3 * std::pow(std::sin(alpha_rad), 2.0);

    // Lefebvre-style decay with momentum flux ratio
    // eta = 1 / (1 + C * (x/I^0.5)^n)
    // Modified for effusion with crossflow buildup
    double C = 0.6 / crossflow_factor;  // Decay constant reduced by crossflow
    double decay_param = (x_D / std::sqrt(I)) * std::pow(s_D / 6.0, 0.5);

    double eta = f_angle / (1.0 + C * std::pow(decay_param, 0.75));

    // Initial region (x_D < 2): blend from hole exit to fully developed
    if (x_D < 2.0) {
        double eta_exit = 0.5 * f_angle;  // Typical hole exit effectiveness
        eta = eta_exit + (eta - eta_exit) * (x_D / 2.0);
    }

    // Clamp to physical bounds
    return std::max(0.0, std::min(1.0, eta));
}

// Effusion hole discharge coefficient
// Accounts for compressibility, inclination, and L/D ratio
double effusion_discharge_coefficient(
    double Re_d,
    double P_ratio,
    double alpha_deg,
    double L_D
) {
    // Validate parameters
    validate_effusion_discharge_params(Re_d, P_ratio, alpha_deg, L_D);

    // Convert angle to radians
    double alpha_rad = alpha_deg * M_PI / 180.0;

    // Base discharge coefficient for straight cylindrical hole
    // Hay & Spencer (1992): Cd_base depends on L/D and Re
    double Cd_base = 0.72 - 0.05 * std::log(L_D);  // Decreases with L/D

    // Reynolds number correction (turbulent flow, Re > 3000)
    // Cd increases slightly with Re in turbulent regime
    double f_Re = 1.0 + 0.02 * std::log10(Re_d / 10000.0);
    f_Re = std::max(0.95, std::min(1.05, f_Re));

    // Inclination angle effect (Gritsch et al. 1998)
    // Shallow angles reduce effective area and increase losses
    double f_angle = 1.0 - 0.15 * (1.0 - std::cos(alpha_rad));

    // Compressibility correction for P_ratio
    // Use isentropic flow relations for subsonic flow
    // gamma = 1.4 for air
    const double gamma = 1.4;

    // Isentropic mass-flow function Psi(p) = sqrt((2g/(g-1))*(p^(2/g) - p^((g+1)/g)))
    // where p = P_downstream/P_upstream = 1/P_ratio (P_ratio = P_plenum/P_mainstream > 1)
    // Psi(1) = 0 (no flow at zero pressure drop), so normalise to Psi at P_ratio_ref = 1.02
    auto psi = [gamma](double p) {
        return std::sqrt((2.0 * gamma / (gamma - 1.0)) *
            (std::pow(p, 2.0 / gamma) - std::pow(p, (gamma + 1.0) / gamma)));
    };
    const double p_ref = 1.0 / 1.02;
    const double f_compress = psi(1.0 / P_ratio) / psi(p_ref);

    // Combined discharge coefficient
    double Cd = Cd_base * f_Re * f_angle * f_compress;

    // Clamp to reasonable bounds
    return std::max(0.50, std::min(0.85, Cd));
}

// -------------------------------------------------------------
// Pin Fin Arrays
// -------------------------------------------------------------

// Validate pin fin parameters
void validate_pin_fin_params(double Re_d, double L_D, double S_D, double X_D) {
    // Re_d: correlation is Nu = C*Re^m (power law, smooth extrapolation).
    // Warn rather than throw — the function is well-behaved outside [3000, 90000].
    if (Re_d < 3000.0 || Re_d > 90000.0) {
        std::cerr << "[combaero] pin_fin_nusselt: Re_d = " << Re_d
                  << " is outside validated range [3000, 90000]."
                     " Extrapolating power-law correlation; check results.\n";
    }
    if (L_D < 0.5 || L_D > 4.0) {
        throw std::runtime_error("Pin fin L_D must be in range [0.5, 4.0], got " + std::to_string(L_D));
    }
    if (S_D < 1.5 || S_D > 4.0) {
        throw std::runtime_error("Pin fin S_D must be in range [1.5, 4.0], got " + std::to_string(S_D));
    }
    if (X_D < 1.5 || X_D > 4.0) {
        throw std::runtime_error("Pin fin X_D must be in range [1.5, 4.0], got " + std::to_string(X_D));
    }
}

// Pin fin array Nusselt number (Metzger et al. 1982)
double pin_fin_nusselt(
    double Re_d,
    double Pr,
    double L_D,
    double S_D,
    double X_D,
    bool is_staggered
) {
    // Validate parameters
    validate_pin_fin_params(Re_d, L_D, S_D, X_D);

    if (Pr < 0.5 || Pr > 1.0) {
        throw std::runtime_error("Prandtl number Pr must be in range [0.5, 1.0], got " + std::to_string(Pr));
    }

    // Metzger correlation: Nu = C * Re_d^m * Pr^0.4 * f(spacing)
    // Constants depend on staggered vs inline arrangement
    double C, m;
    if (is_staggered) {
        // Staggered arrays have better heat transfer
        C = 0.135;
        m = 0.69;
    } else {
        // Inline arrays (lower performance)
        C = 0.092;
        m = 0.675;
    }

    // Base Nusselt number
    double Nu_base = C * std::pow(std::abs(Re_d), m) * std::pow(Pr, 0.4);

    // Length effect: longer pins have lower average Nu due to boundary layer growth
    double f_length = std::pow(L_D, -0.11);

    // Spacing effects (Metzger empirical fits)
    // Tighter spacing -> better heat transfer but higher pressure drop
    double f_spacing = std::pow(S_D / 2.5, -0.15) * std::pow(X_D / 2.5, -0.10);

    return Nu_base * f_length * f_spacing;
}

// Pin fin array pressure drop friction coefficient
// dP = N_rows * f_pin * (rho * v_max^2 / 2)
// Source: Metzger et al. (1982), Simoneau & VanFossen (1984)
double pin_fin_friction(double Re_d, bool is_staggered) {
    // Re_d: f = C*Re^(-0.25) is a smooth power law — warn, don't throw.
    if (Re_d < 3000.0 || Re_d > 90000.0) {
        std::cerr << "[combaero] pin_fin_friction: Re_d = " << Re_d
                  << " is outside validated range [3000, 90000]."
                     " Extrapolating power-law correlation; check results.\n";
    }

    // Metzger/Simoneau: f_pin = C_f * Re_d^(-0.25)
    // C_f = 0.317 staggered, 0.228 inline
    double C_f = is_staggered ? 0.317 : 0.228;
    return C_f * std::pow(std::max(std::abs(Re_d), 1.0), -0.25);
}

// -------------------------------------------------------------
// Dimpled Surfaces
// -------------------------------------------------------------

// Validate dimple parameters
void validate_dimple_params(double Re_Dh, double d_Dh, double h_d) {
    // Re_Dh: correlation is Nu_enh = C*Re^m (power law, smooth extrapolation).
    // Warn rather than throw — the function is well-behaved outside [10000, 80000].
    if (Re_Dh < 10000.0 || Re_Dh > 80000.0) {
        std::cerr << "[combaero] dimple_nusselt_enhancement: Re_Dh = " << Re_Dh
                  << " is outside validated range [10000, 80000]."
                     " Extrapolating power-law correlation; check results.\n";
    }
    if (d_Dh < 0.1 || d_Dh > 0.3) {
        throw std::runtime_error("Dimple d_Dh must be in range [0.1, 0.3], got " + std::to_string(d_Dh));
    }
    if (h_d < 0.1 || h_d > 0.3) {
        throw std::runtime_error("Dimple h_d must be in range [0.1, 0.3], got " + std::to_string(h_d));
    }
}

void validate_dimple_params(double Re_Dh, double d_Dh, double h_d, double S_d) {
    validate_dimple_params(Re_Dh, d_Dh, h_d);
    if (S_d < 1.5 || S_d > 3.0) {
        throw std::runtime_error("Dimple S_d must be in range [1.5, 3.0], got " + std::to_string(S_d));
    }
}

// Dimpled surface heat transfer enhancement (Chyu et al. 1997)
double dimple_nusselt_enhancement(
    double Re_Dh,
    double d_Dh,
    double h_d,
    double S_d
) {
    // Validate parameters
    validate_dimple_params(Re_Dh, d_Dh, h_d, S_d);

    // Chyu correlation: Nu/Nu_0 = f(Re, geometry)
    // Enhancement increases with Re (vortex strength)
    double Re_effect = std::pow(Re_Dh / 30000.0, 0.1);  // Weak Re dependence

    // Dimple depth effect: optimal around h/d = 0.2
    // Deeper dimples create stronger vortices
    double depth_factor = 1.0 + 2.0 * (h_d - 0.15);
    depth_factor = std::max(1.0, std::min(1.5, depth_factor));

    // Dimple density effect: closer spacing -> more vortex interaction
    double spacing_factor = std::pow(2.0 / S_d, 0.3);

    // Dimple size effect: larger dimples (higher d/Dh) -> more coverage
    double size_factor = 1.0 + 1.5 * (d_Dh - 0.15);

    // Base enhancement (typical for well-designed dimple arrays)
    double base_enhancement = 1.8;

    double enhancement = base_enhancement * Re_effect * depth_factor * spacing_factor * size_factor;

    // Clamp to realistic range (1.5 - 2.8x)
    return std::max(1.5, std::min(2.8, enhancement));
}

// Dimpled surface friction multiplier
double dimple_friction_multiplier(
    double Re_Dh,
    double d_Dh,
    double h_d
) {
    validate_dimple_params(Re_Dh, d_Dh, h_d);

    // Friction penalty for dimples (Chyu et al. 1997)
    // Much lower than ribs (1.5-2.0x vs 6-10x)

    // Base friction multiplier
    double f_base = 1.5;

    // Depth effect: deeper dimples -> higher friction
    double depth_penalty = 1.0 + 0.8 * (h_d - 0.15);

    // Size effect: larger dimples -> slightly higher friction
    double size_penalty = 1.0 + 0.4 * (d_Dh - 0.15);

    double f_ratio = f_base * depth_penalty * size_penalty;

    // Clamp to realistic range (1.3 - 2.2x)
    return std::max(1.3, std::min(2.2, f_ratio));
}

double adiabatic_wall_temperature(double T_hot, double T_coolant, double eta) {
    if (eta < 0.0 || eta > 1.0) {
        throw std::runtime_error(
            "Cooling effectiveness eta must be in range [0, 1], got " + std::to_string(eta)
        );
    }
    return T_hot - eta * (T_hot - T_coolant);
}

double cooled_wall_heat_flux(double T_hot, double T_coolant,
                             double h_hot, double h_coolant,
                             double eta,
                             double t_wall, double k_wall) {
    if (h_hot <= 0.0 || h_coolant <= 0.0) {
        throw std::runtime_error("Heat transfer coefficients must be positive");
    }
    if (t_wall < 0.0 || k_wall <= 0.0) {
        throw std::runtime_error("Wall thickness must be non-negative and conductivity positive");
    }

    const double T_aw = adiabatic_wall_temperature(T_hot, T_coolant, eta);
    const double U = overall_htc_wall(h_hot, h_coolant, t_wall, k_wall);
    return U * (T_aw - T_coolant);
}

}  // namespace combaero::cooling
