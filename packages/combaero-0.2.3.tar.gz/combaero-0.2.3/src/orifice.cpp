#include "../include/math_constants.h"
#include "../include/orifice.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

// -------------------------------------------------------------
// OrificeGeometry implementation
// -------------------------------------------------------------

double OrificeGeometry::beta() const {
    if (D <= 0.0) {
        throw std::invalid_argument("OrificeGeometry: pipe diameter D must be > 0");
    }
    return d / D;
}

double OrificeGeometry::area() const {
    return M_PI * d * d / 4.0;
}

double OrificeGeometry::t_over_d() const {
    if (d <= 0.0) return 0.0;
    return t / d;
}

double OrificeGeometry::r_over_d() const {
    if (d <= 0.0) return 0.0;
    return r / d;
}

bool OrificeGeometry::is_valid() const {
    if (d <= 0.0 || D <= 0.0) return false;
    if (d >= D) return false;
    if (t < 0.0 || r < 0.0) return false;
    return true;
}

// -------------------------------------------------------------
// OrificeState implementation
// -------------------------------------------------------------

double OrificeState::Re_d(double beta) const {
    // Orifice Reynolds number based on orifice diameter d
    // From continuity: v_orifice = v_pipe / beta^2
    // Re_d = (rho * v_orifice * d) / mu
    //      = (rho * (v_pipe / beta^2) * (D * beta)) / mu
    //      = (rho * v_pipe * D) / mu * (1/beta)
    //      = Re_D / beta
    // However, the conventional definition uses Re_d = Re_D * beta
    // (based on the diameter ratio, not the actual flow velocity)
    return Re_D * beta;
}

// -------------------------------------------------------------
// Namespace: individual correlations
// -------------------------------------------------------------

namespace orifice {

// Clamping helpers for numerical stability near d -> D
inline double clamp_beta(double b) { return std::min(b, 0.98); }
inline double clamp_Cd(double c) { return std::min(c, 1.5); }

// Reader-Harris/Gallagher (1998) correlation
// ISO 5167-2:2003, also ASME MFC-3M
// Valid for: 0.1 <= beta <= 0.75, Re_D >= 5000 (preferably >= 10000)
//            D >= 50 mm, d >= 12.5 mm
double Cd_ReaderHarrisGallagher(double beta, double Re_D, double D) {
    // Ensure minimum Reynolds number
    if (Re_D < 1.0) Re_D = 1.0;

    // Limit beta to 0.98 for correlation stability (ISO valid to 0.75)
    // d ~ D is handled separately or via smooth cap to prevent division by zero
    const double beta_corr = std::min(beta, 0.98);
    const double b2 = beta_corr * beta_corr;
    const double b4 = b2 * b2;
    const double b8 = b4 * b4;

    // Convert D to mm for the correlation
    const double D_mm = D * 1000.0;

    // Flange tap geometry
    const double L1 = reader_harris::flange_mm / D_mm;
    const double L2 = reader_harris::flange_mm / D_mm;

    // A parameter (small-bore correction)
    const double A = std::pow(reader_harris::A_coef * beta_corr / Re_D, reader_harris::A_exp);

    // M2 parameter (downstream tap correction)
    const double M2 = 2.0 * L2 / (1.0 - beta_corr);

    // Base coefficient
    double C = reader_harris::C0
             + reader_harris::C1 * b2
             - reader_harris::C2 * b8;

    // Reynolds number term
    C += reader_harris::C3 * std::pow(reader_harris::re_scale * beta_corr / Re_D, reader_harris::C3_exp);

    // Small-bore correction
    C += (reader_harris::C4a + reader_harris::C4b * A) * std::pow(beta_corr, reader_harris::C4_beta) * std::pow(reader_harris::re_scale / Re_D, reader_harris::C4_re);

    // Upstream tap term
    const double exp_term1 = std::exp(-reader_harris::C5_exp1 * L1);
    const double exp_term2 = std::exp(-reader_harris::C5_exp2 * L1);
    C += (reader_harris::C5a + reader_harris::C5b * exp_term1 - reader_harris::C5c * exp_term2)
       * (1.0 - reader_harris::C5_A_coef * A) * b4 / (1.0 - b4);

    // Downstream tap term
    C -= reader_harris::C6 * (M2 - 0.8 * std::pow(M2, reader_harris::C6_M_exp)) * std::pow(beta_corr, reader_harris::C6_beta);

    // Final smooth cap (physical orifices rarely exceed 1.0;
    // numerical stability capped at 1.5 to allow lossless bypass recovery)
    return std::min(C, 1.5);
}

// Stolz (1978) correlation - older ISO 5167
double Cd_Stolz(double beta, double Re_D) {
    if (Re_D < 1.0) Re_D = 1.0;
    const double b = clamp_beta(beta);

    // Stolz equation (corner taps)
    // C = 0.5959 + 0.0312*beta^2.1 - 0.184*beta^8 + 91.71*beta^2.5/Re_D^0.75
    double C = stolz::C0
             + stolz::C1 * std::pow(b, stolz::C1_exp)
             - stolz::C2 * std::pow(b, stolz::C2_exp)
             + stolz::C3 * std::pow(b, stolz::C3_beta) / std::pow(Re_D, stolz::C3_re);

    return clamp_Cd(C);
}

// Miller (1996) simplified correlation
double Cd_Miller(double beta, double Re_D) {
    if (Re_D < 1.0) Re_D = 1.0;
    const double b = clamp_beta(beta);

    // Simplified form: C ≈ 0.596 + 0.031*beta^2 for high Re
    const double b2 = b * b;
    double C = miller::C0 + miller::C1 * b2;

    // Reynolds number correction (approximate)
    if (Re_D < miller::re_cutoff) {
        C += miller::C2 * std::pow(b, miller::C2_beta_exp) / std::pow(Re_D, miller::C2_re_exp);
    }

    return clamp_Cd(C);
}

// Thickness correction factor for thick plates
// Idelchik model: Cd rises (reattachment) then falls (friction)
//
// Physical model:
// - For small t/d: flow reattachment increases Cd (vena contracta recovery)
// - For large t/d: friction in bore decreases Cd (pipe friction losses)
// - Peak Cd occurs at t/d ≈ 0.5-1.5 (depending on beta, Re)
//
// References:
// - Idelchik, I.E. (2008). "Handbook of Hydraulic Resistance" (4th ed.)
//   Diagram 4-15: Discharge coefficients for thick-plate orifices
// - Lichtarowicz, A., et al. (1965). "Discharge Coefficients for
//   Incompressible Non-Cavitating Flow through Long Orifices"
//   J. Mech. Eng. Sci., 7(2), 210-219.
//
// Note: Smooth in Re_d for solver stability (t/d is constant per geometry)
//
double thickness_correction(double t_over_d, double beta, double Re_d) {
    if (t_over_d <= thickness::thin_plate_limit) {
        return 1.0;  // Thin plate, no correction
    }

    // Ensure Re_d is positive for stability
    Re_d = std::max(Re_d, thickness::re_floor);

    // Component 1: Reattachment benefit (independent of Re)
    const double reattach_factor = thickness::reattach_coef * (1.0 - std::exp(-thickness::reattach_exp * t_over_d));
    const double reattachment = reattach_factor * (1.0 - beta * beta);

    // Component 2: Friction penalty (smooth Re dependence)
    // Use Blasius smooth turbulent friction: f = blasius_coef / Re^blasius_exp
    const double f = thickness::blasius_coef / std::pow(Re_d, thickness::blasius_exp);
    const double friction_loss = thickness::friction_coef * f * t_over_d;

    // Combined correction: rise (reattachment) then fall (friction)
    const double correction = 1.0 + reattachment - friction_loss;

    return std::max(thickness::correction_min, std::min(correction, thickness::correction_max));
}

// Rounded-entry Cd
// For well-rounded entries (r/d >= 0.15), Cd approaches 0.98-0.99
// Based on Idelchik contraction loss coefficients
double Cd_rounded(double r_over_d, double beta, double Re_D) {
    if (Re_D < 1.0) Re_D = 1.0;
    const double b = clamp_beta(beta);

    // For r/d = 0: sharp edge, use thin-plate correlation
    if (r_over_d <= 0.0) {
        return Cd_Stolz(b, Re_D);
    }

    // Idelchik: loss coefficient K for rounded entry
    double K;
    if (r_over_d >= rounded::radius_threshold) {
        // Well-rounded entry
        K = rounded::K_well_rounded;
    } else {
        // Partially rounded
        const double ratio = 1.0 - r_over_d / rounded::radius_threshold;
        K = rounded::K_sharp * ratio * ratio;
    }

    // Account for beta effect
    const double b4 = std::pow(b, 4.0);
    const double Cd = 1.0 / std::sqrt(1.0 + K / (1.0 - b4));

    // Reynolds number correction for low Re
    double Re_correction = 1.0;
    if (Re_D < rounded::re_correction_ref) {
        Re_correction = 1.0 - rounded::re_correction_coef * std::pow(rounded::re_correction_ref / Re_D, rounded::re_correction_exp);
    }

    return clamp_Cd(Cd * Re_correction);
}

// Convert between Cd and loss coefficient K
double K_from_Cd(double Cd, double beta) {
    if (Cd <= 0.0 || Cd > 1.5) {
        throw std::invalid_argument("Cd must be in (0, 1.5]");
    }
    const double b = clamp_beta(beta);
    const double beta4 = std::pow(b, 4.0);
    return (1.0 / (Cd * Cd) - 1.0) * (1.0 - beta4);
}

double Cd_from_K(double K, double beta) {
    if (K < 0.0) {
        throw std::invalid_argument("K must be >= 0");
    }
    const double b = clamp_beta(beta);
    const double beta4 = std::pow(b, 4.0);
    return clamp_Cd(1.0 / std::sqrt(1.0 + K / (1.0 - beta4)));
}

} // namespace orifice

// -------------------------------------------------------------
// Main Cd functions (free functions)
// -------------------------------------------------------------

double Cd_sharp_thin_plate(const OrificeGeometry& geom, const OrificeState& state) {
    if (!geom.is_valid()) {
        throw std::invalid_argument("Invalid orifice geometry");
    }
    return orifice::Cd_ReaderHarrisGallagher(geom.beta(), state.Re_D, geom.D);
}

double Cd_thick_plate(const OrificeGeometry& geom, const OrificeState& state) {
    if (!geom.is_valid()) {
        throw std::invalid_argument("Invalid orifice geometry");
    }

    // Start with thin-plate Cd
    double Cd = orifice::Cd_ReaderHarrisGallagher(geom.beta(), state.Re_D, geom.D);

    // Apply thickness correction (includes reattachment + friction effects)
    Cd *= orifice::thickness_correction(geom.t_over_d(), geom.beta(), state.Re_D);

    return Cd;
}

double Cd_rounded_entry(const OrificeGeometry& geom, const OrificeState& state) {
    if (!geom.is_valid()) {
        throw std::invalid_argument("Invalid orifice geometry");
    }
    return orifice::Cd_rounded(geom.r_over_d(), geom.beta(), state.Re_D);
}

double Cd(const OrificeGeometry& geom, const OrificeState& state) {
    if (!geom.is_valid()) {
        throw std::invalid_argument("Invalid orifice geometry");
    }

    // Auto-select based on geometry
    if (geom.r_over_d() > 0.01) {
        // Rounded entry
        return Cd_rounded_entry(geom, state);
    } else if (geom.t_over_d() > 0.02) {
        // Thick plate
        return Cd_thick_plate(geom, state);
    } else {
        // Sharp thin plate (default)
        return Cd_sharp_thin_plate(geom, state);
    }
}

// -------------------------------------------------------------
// Correlation classes
// -------------------------------------------------------------

namespace {

class ReaderHarrisGallagherCorrelation : public OrificeCorrelationBase {
public:
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return Cd_sharp_thin_plate(geom, state);
    }
    std::string name() const override { return "Reader-Harris/Gallagher (ISO 5167-2)"; }
};

class StolzCorrelation : public OrificeCorrelationBase {
public:
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return orifice::Cd_Stolz(geom.beta(), state.Re_D);
    }
    std::string name() const override { return "Stolz (ISO 5167:1980)"; }
};

class MillerCorrelation : public OrificeCorrelationBase {
public:
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return orifice::Cd_Miller(geom.beta(), state.Re_D);
    }
    std::string name() const override { return "Miller (1996)"; }
};

class ThickPlateCorrelation : public OrificeCorrelationBase {
public:
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return Cd_thick_plate(geom, state);
    }
    std::string name() const override { return "Thick Plate (Idelchik correction)"; }
};

class RoundedEntryCorrelation : public OrificeCorrelationBase {
public:
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return Cd_rounded_entry(geom, state);
    }
    std::string name() const override { return "Rounded Entry (Idelchik)"; }
};

class ConstantCdCorrelation : public OrificeCorrelationBase {
    double Cd_value_;
public:
    explicit ConstantCdCorrelation(double Cd = 0.61) : Cd_value_(Cd) {}
    double Cd(const OrificeGeometry&, const OrificeState&) const override {
        return Cd_value_;
    }
    std::string name() const override { return "Constant Cd"; }
};

class UserFunctionCorrelation : public OrificeCorrelationBase {
    CdFunction fn_;
    std::string name_;
public:
    UserFunctionCorrelation(CdFunction fn, std::string name)
        : fn_(std::move(fn)), name_(std::move(name)) {}
    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return fn_(geom, state);
    }
    std::string name() const override { return name_; }
};

class TabulatedCorrelation : public OrificeCorrelationBase {
    std::vector<double> beta_values_;
    std::vector<double> Re_values_;
    std::vector<std::vector<double>> Cd_table_;
    std::string name_;

public:
    TabulatedCorrelation(std::vector<double> beta_values,
                         std::vector<double> Re_values,
                         std::vector<std::vector<double>> Cd_table,
                         std::string name)
        : beta_values_(std::move(beta_values))
        , Re_values_(std::move(Re_values))
        , Cd_table_(std::move(Cd_table))
        , name_(std::move(name)) {}

    double Cd(const OrificeGeometry& geom, const OrificeState& state) const override {
        return interpolate(geom.beta(), state.Re_D);
    }

    std::string name() const override { return name_; }

private:
    double interpolate(double beta, double Re_D) const {
        // Bilinear interpolation in beta and log(Re_D)
        const double log_Re = std::log10(std::max(Re_D, 1.0));

        // Find beta indices
        auto it_beta = std::lower_bound(beta_values_.begin(), beta_values_.end(), beta);
        std::size_t i_beta = (it_beta == beta_values_.begin()) ? 0 :
                             (it_beta == beta_values_.end()) ? beta_values_.size() - 2 :
                             static_cast<std::size_t>(it_beta - beta_values_.begin() - 1);

        // Find Re indices (in log space)
        std::vector<double> log_Re_values;
        log_Re_values.reserve(Re_values_.size());
        for (double Re : Re_values_) {
            log_Re_values.push_back(std::log10(std::max(Re, 1.0)));
        }
        auto it_Re = std::lower_bound(log_Re_values.begin(), log_Re_values.end(), log_Re);
        std::size_t i_Re = (it_Re == log_Re_values.begin()) ? 0 :
                           (it_Re == log_Re_values.end()) ? log_Re_values.size() - 2 :
                           static_cast<std::size_t>(it_Re - log_Re_values.begin() - 1);

        // Clamp indices
        i_beta = std::min(i_beta, beta_values_.size() - 2);
        i_Re = std::min(i_Re, Re_values_.size() - 2);

        // Interpolation weights
        const double t_beta = (beta - beta_values_[i_beta]) /
                              (beta_values_[i_beta + 1] - beta_values_[i_beta]);
        const double t_Re = (log_Re - log_Re_values[i_Re]) /
                            (log_Re_values[i_Re + 1] - log_Re_values[i_Re]);

        // Clamp weights to [0, 1]
        const double tb = std::max(0.0, std::min(t_beta, 1.0));
        const double tr = std::max(0.0, std::min(t_Re, 1.0));

        // Bilinear interpolation
        const double c00 = Cd_table_[i_beta][i_Re];
        const double c10 = Cd_table_[i_beta + 1][i_Re];
        const double c01 = Cd_table_[i_beta][i_Re + 1];
        const double c11 = Cd_table_[i_beta + 1][i_Re + 1];

        return (1 - tb) * (1 - tr) * c00
             + tb * (1 - tr) * c10
             + (1 - tb) * tr * c01
             + tb * tr * c11;
    }
};

} // anonymous namespace

std::unique_ptr<OrificeCorrelationBase> make_correlation(CdCorrelation id) {
    switch (id) {
        case CdCorrelation::ReaderHarrisGallagher:
            return std::make_unique<ReaderHarrisGallagherCorrelation>();
        case CdCorrelation::Stolz:
            return std::make_unique<StolzCorrelation>();
        case CdCorrelation::Miller:
            return std::make_unique<MillerCorrelation>();
        case CdCorrelation::IdelchikThick:
        case CdCorrelation::BohlThick:
            return std::make_unique<ThickPlateCorrelation>();
        case CdCorrelation::IdelchikRounded:
        case CdCorrelation::BohlRounded:
            return std::make_unique<RoundedEntryCorrelation>();
        case CdCorrelation::Constant:
            return std::make_unique<ConstantCdCorrelation>();
        case CdCorrelation::UserFunction:
            return nullptr;  // Use make_user_correlation instead
    }
    return nullptr;
}

std::unique_ptr<OrificeCorrelationBase> make_user_correlation(
    CdFunction fn,
    const std::string& name) {
    return std::make_unique<UserFunctionCorrelation>(std::move(fn), name);
}

std::unique_ptr<OrificeCorrelationBase> make_tabulated_correlation(
    const std::vector<double>& beta_values,
    const std::vector<double>& Re_values,
    const std::vector<std::vector<double>>& Cd_table,
    const std::string& name) {
    return std::make_unique<TabulatedCorrelation>(beta_values, Re_values, Cd_table, name);
}

// -------------------------------------------------------------
// Flow calculations
// -------------------------------------------------------------

double orifice_mdot(const OrificeGeometry& geom, double Cd, double dP,
                    double rho, double epsilon) {
    if (dP < 0.0 || rho <= 0.0 || Cd <= 0.0) {
        throw std::invalid_argument("orifice_mdot: invalid parameters");
    }
    const double beta = geom.beta();
    const double E = 1.0 / std::sqrt(1.0 - std::pow(beta, 4.0));
    return Cd * E * epsilon * geom.area() * std::sqrt(2.0 * rho * dP);
}

double orifice_dP(const OrificeGeometry& geom, double Cd, double mdot,
                  double rho, double epsilon) {
    if (mdot < 0.0 || rho <= 0.0 || Cd <= 0.0) {
        throw std::invalid_argument("orifice_dP: invalid parameters");
    }
    // From mdot = Cd * E * epsilon * A * sqrt(2 * rho * dP)
    // Solve for dP: dP = (mdot / (Cd * E * epsilon * A))^2 / (2 * rho)
    const double A = geom.area();
    const double beta = geom.beta();
    const double E = 1.0 / std::sqrt(1.0 - std::pow(beta, 4.0));
    const double term = mdot / (Cd * E * epsilon * A);
    return term * term / (2.0 * rho);
}

double orifice_Cd_from_measurement(const OrificeGeometry& geom,
                                    double mdot, double dP, double rho) {
    if (dP <= 0.0 || rho <= 0.0 || mdot <= 0.0) {
        throw std::invalid_argument("orifice_Cd_from_measurement: invalid parameters");
    }
    const double beta = geom.beta();
    const double E = 1.0 / std::sqrt(1.0 - std::pow(beta, 4.0));
    double A = geom.area();
    return mdot / (E * A * std::sqrt(2.0 * rho * dP));
}

// -------------------------------------------------------------
// Iterative solver for Cd-Re coupling
// -------------------------------------------------------------

double solve_orifice_mdot(
    const OrificeGeometry& geom,
    double dP,
    double rho,
    double mu,
    double P_upstream,
    double kappa,
    CdCorrelation correlation,
    double tol,
    int max_iter)
{
    // Input validation
    if (!geom.is_valid()) {
        throw std::invalid_argument("solve_orifice_mdot: invalid geometry");
    }
    if (dP < 0.0) {
        throw std::invalid_argument("solve_orifice_mdot: dP must be non-negative");
    }
    if (rho <= 0.0) {
        throw std::invalid_argument("solve_orifice_mdot: rho must be positive");
    }
    if (mu <= 0.0) {
        throw std::invalid_argument("solve_orifice_mdot: mu must be positive");
    }
    if (P_upstream <= 0.0) {
        throw std::invalid_argument("solve_orifice_mdot: P_upstream must be positive");
    }
    if (tol <= 0.0) {
        throw std::invalid_argument("solve_orifice_mdot: tol must be positive");
    }
    if (max_iter < 1) {
        throw std::invalid_argument("solve_orifice_mdot: max_iter must be >= 1");
    }

    // Handle zero pressure drop case
    if (dP == 0.0) {
        return 0.0;
    }

    // Precompute constants
    const double area = geom.area();
    const double beta = geom.beta();
    const double D = geom.D;

    // Initial guess for Cd (typical value for sharp orifices)
    double Cd = 0.61;

    // Initial guess for mdot (use incompressible formula with initial Cd)
    double mdot = Cd * area * std::sqrt(2.0 * rho * dP);

    // Iteration loop
    for (int iter = 0; iter < max_iter; ++iter) {
        // Calculate expansibility factor if compressible (kappa > 1)
        double epsilon = 1.0;
        if (kappa > 1.0) {
            epsilon = expansibility_factor(beta, dP, P_upstream, kappa);
        }

        // Calculate velocity-of-approach factor (E)
        const double E = 1.0 / std::sqrt(1.0 - std::pow(beta, 4.0));

        // Calculate new mass flow rate using current Cd, E, and epsilon
        const double mdot_new = Cd * E * epsilon * area * std::sqrt(2.0 * rho * dP);

        // Check convergence
        const double rel_error = std::abs(mdot_new - mdot) / (mdot + 1e-30);
        if (rel_error < tol) {
            return mdot_new;
        }

        // Update Reynolds number based on new mdot
        // Re_D = (4 * mdot) / (π * D * μ)
        const double Re_D = (4.0 * mdot_new) / (M_PI * D * mu);

        // Update Cd based on new Reynolds number
        switch (correlation) {
            case CdCorrelation::ReaderHarrisGallagher:
                Cd = orifice::Cd_ReaderHarrisGallagher(beta, Re_D, D);
                break;
            case CdCorrelation::Stolz:
                Cd = orifice::Cd_Stolz(beta, Re_D);
                break;
            case CdCorrelation::Miller:
                Cd = orifice::Cd_Miller(beta, Re_D);
                break;
            default:
                throw std::invalid_argument(
                    "solve_orifice_mdot: unsupported correlation type");
        }

        // Update mdot for next iteration
        mdot = mdot_new;
    }

    // Failed to converge
    throw std::runtime_error(
        "solve_orifice_mdot: failed to converge after " +
        std::to_string(max_iter) + " iterations");
}

// -------------------------------------------------------------
// Compressible flow correction
// -------------------------------------------------------------

double expansibility_factor(double beta, double dP, double P_upstream, double kappa) {
    // Input validation
    if (beta <= 0.0 || beta >= 1.0) {
        throw std::invalid_argument("expansibility_factor: beta must be in range (0, 1)");
    }
    if (P_upstream <= 0.0) {
        throw std::invalid_argument("expansibility_factor: P_upstream must be positive");
    }
    if (dP < 0.0) {
        throw std::invalid_argument("expansibility_factor: dP must be non-negative");
    }

    // Incompressible limit: kappa <= 1 or no pressure drop
    if (kappa <= 1.0 || dP <= 0.0) {
        return 1.0;
    }

    // Pressure ratio
    const double tau = dP / P_upstream;

    // Check validity range (ISO 5167-2 recommends τ ≤ 0.25)
    if (tau > 0.25) {
        // Still compute but this is outside recommended range
        // User should be aware via documentation
    }

    // Compute beta powers
    const double beta2 = beta * beta;
    const double beta4 = beta2 * beta2;
    const double beta8 = beta4 * beta4;

    // ISO 5167-2:2003 expansibility factor formula
    // ε = 1 - (0.351 + 0.256·β⁴ + 0.93·β⁸) · [1 - (1 - τ)^(1/κ)]
    const double coeff = 0.351 + 0.256 * beta4 + 0.93 * beta8;
    const double expansion_term = 1.0 - std::pow(1.0 - tau, 1.0 / kappa);

    return 1.0 - coeff * expansion_term;
}

// -------------------------------------------------------------
// Orifice flow result bundle
// -------------------------------------------------------------

OrificeFlowResult orifice_flow(
    const OrificeGeometry& geom,
    double dP,
    double T,
    double P,
    double mu,
    double Z,
    [[maybe_unused]] const std::vector<double>& X,
    double kappa,
    CdCorrelation correlation)
{
    // Input validation
    if (!geom.is_valid()) {
        throw std::invalid_argument("orifice_flow: invalid geometry");
    }
    if (T <= 0.0) {
        throw std::invalid_argument("orifice_flow: temperature must be positive");
    }
    if (P <= 0.0) {
        throw std::invalid_argument("orifice_flow: pressure must be positive");
    }
    if (mu <= 0.0) {
        throw std::invalid_argument("orifice_flow: viscosity must be positive");
    }
    if (Z <= 0.0) {
        throw std::invalid_argument("orifice_flow: compressibility factor Z must be positive");
    }
    if (dP < 0.0) {
        throw std::invalid_argument("orifice_flow: differential pressure must be non-negative");
    }

    // Compute ideal gas density
    // For now, use simple ideal gas law with air composition
    // rho_ideal = P * MW / (R * T)
    // For air: MW ≈ 28.97 g/mol, R = 8.314 J/(mol·K)
    const double R_gas = 8.314;  // J/(mol·K)
    const double MW_air = 0.02897;  // kg/mol (air molecular weight)
    const double rho_ideal = (P * MW_air) / (R_gas * T);

    // Apply real gas correction
    const double rho_corrected = rho_ideal / Z;

    // Solve for mass flow rate with corrected density
    const double mdot = solve_orifice_mdot(
        geom, dP, rho_corrected, mu, P, kappa, correlation);

    // Calculate expansibility factor
    const double beta = geom.beta();
    const double epsilon = (kappa > 1.0) ?
        expansibility_factor(beta, dP, P, kappa) : 1.0;

    // Calculate velocity through orifice
    const double A = geom.area();
    const double v = mdot / (rho_corrected * A);

    // Calculate Reynolds numbers
    const double D = geom.D;
    const double d = geom.d;
    const double Re_D = (4.0 * mdot) / (M_PI * D * mu);
    const double Re_d = (4.0 * mdot) / (M_PI * d * mu);

    // Get discharge coefficient
    OrificeState state;
    state.Re_D = Re_D;
    state.dP = dP;
    state.rho = rho_corrected;
    state.mu = mu;

    double Cd_value = 0.61;  // Default
    switch (correlation) {
        case CdCorrelation::ReaderHarrisGallagher:
            Cd_value = Cd_sharp_thin_plate(geom, state);
            break;
        case CdCorrelation::Stolz:
            Cd_value = orifice::Cd_Stolz(beta, Re_D);
            break;
        case CdCorrelation::Miller:
            Cd_value = orifice::Cd_Miller(beta, Re_D);
            break;
        case CdCorrelation::IdelchikThick:
            Cd_value = Cd_thick_plate(geom, state);
            break;
        case CdCorrelation::IdelchikRounded:
            Cd_value = Cd_rounded_entry(geom, state);
            break;
        default:
            Cd_value = Cd(geom, state);  // Auto-select
            break;
    }

    // Populate result struct
    OrificeFlowResult result;
    result.mdot = mdot;
    result.v = v;
    result.Re_D = Re_D;
    result.Re_d = Re_d;
    result.Cd = Cd_value;
    result.epsilon = epsilon;
    result.rho_corrected = rho_corrected;

    return result;
}

// -------------------------------------------------------------
// Utility functions
// -------------------------------------------------------------

double orifice_velocity_from_mdot(double mdot, double rho, double d, double Z) {
    if (mdot < 0.0) {
        throw std::invalid_argument("orifice_velocity_from_mdot: mdot must be non-negative");
    }
    if (rho <= 0.0) {
        throw std::invalid_argument("orifice_velocity_from_mdot: rho must be positive");
    }
    if (d <= 0.0) {
        throw std::invalid_argument("orifice_velocity_from_mdot: d must be positive");
    }
    if (Z <= 0.0) {
        throw std::invalid_argument("orifice_velocity_from_mdot: Z must be positive");
    }

    // Apply real gas correction to density
    const double rho_corrected = rho / Z;

    // Calculate area
    const double A = M_PI * d * d / 4.0;

    // v = mdot / (rho_corrected * A)
    return mdot / (rho_corrected * A);
}

double orifice_area_from_beta(double D, double beta) {
    if (D <= 0.0) {
        throw std::invalid_argument("orifice_area_from_beta: D must be positive");
    }
    if (beta <= 0.0 || beta >= 1.0) {
        throw std::invalid_argument("orifice_area_from_beta: beta must be in range (0, 1)");
    }

    // A = π * (D * beta / 2)²
    const double d = D * beta;
    return M_PI * d * d / 4.0;
}

double beta_from_diameters(double d, double D) {
    if (d <= 0.0) {
        throw std::invalid_argument("beta_from_diameters: d must be positive");
    }
    if (D <= 0.0) {
        throw std::invalid_argument("beta_from_diameters: D must be positive");
    }
    if (d >= D) {
        throw std::invalid_argument("beta_from_diameters: d must be < D");
    }

    // beta = d / D
    return d / D;
}

double orifice_Re_d_from_mdot(double mdot, double d, double mu) {
    if (mdot < 0.0) {
        throw std::invalid_argument("orifice_Re_d_from_mdot: mdot must be non-negative");
    }
    if (d <= 0.0) {
        throw std::invalid_argument("orifice_Re_d_from_mdot: d must be positive");
    }
    if (mu <= 0.0) {
        throw std::invalid_argument("orifice_Re_d_from_mdot: mu must be positive");
    }

    // Re_d = 4 * mdot / (π * d * mu)
    return (4.0 * mdot) / (M_PI * d * mu);
}
