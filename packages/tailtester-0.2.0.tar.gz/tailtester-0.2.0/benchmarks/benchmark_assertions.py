"""Performance benchmarks for tailtest deterministic assertions.

Run: python benchmarks/benchmark_assertions.py

Measures execution time for each assertion type against mock responses
of varying sizes. Compares deterministic (Tier 1) vs LLM-judge (Tier 2) costs.
"""

from __future__ import annotations

import asyncio
import statistics
import sys
import time
from pathlib import Path

# Ensure the src/ package is importable when running from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from tailtest.models import AgentResponse, ToolCall, TokenUsage
from tailtest.assertions.deterministic.contains import ContainsAssertion, NotContainsAssertion
from tailtest.assertions.deterministic.cost import CostAssertion
from tailtest.assertions.deterministic.latency import LatencyAssertion
from tailtest.assertions.deterministic.tool_call import ToolCallAssertion, ToolNotCalledAssertion
from tailtest.assertions.deterministic.pii import PIIAssertion
from tailtest.assertions.deterministic.no_loop import NoLoopAssertion
from tailtest.assertions.deterministic.regex import RegexAssertion
from tailtest.assertions.deterministic.schema_check import SchemaAssertion
from tailtest.assertions.deterministic.steps import StepCountAssertion
from tailtest.assertions.deterministic.tokens import TokensUnderAssertion

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Mock response factories
# ---------------------------------------------------------------------------

def _make_response(content_size: str = "medium") -> AgentResponse:
    """Create a mock AgentResponse with realistic data at the given size tier.

    Sizes:
      - small:  ~100 chars, 0 tool calls
      - medium: ~500 chars, 2 tool calls
      - large:  ~5 000 chars, 10 tool calls
      - xlarge: ~50 000 chars, 50 tool calls
    """
    sizes = {
        "small": (100, 0),
        "medium": (500, 2),
        "large": (5_000, 10),
        "xlarge": (50_000, 50),
    }
    char_target, n_tools = sizes[content_size]

    # Build a realistic-looking content string.
    base = (
        "Thank you for contacting Acme Electronics support. "
        "Your order ORD-12345 is currently being processed. "
        "Standard shipping takes 5-7 business days. "
        "Your tracking number is 1Z999AA10123456784. "
    )
    content = (base * ((char_target // len(base)) + 1))[:char_target]

    tool_calls = [
        ToolCall(
            name="search_faq" if i % 3 == 0 else ("check_order" if i % 3 == 1 else "create_ticket"),
            arguments={"query": f"test query {i}"},
            result={"found": True, "answer": f"Answer {i}"},
            duration_ms=float(30 + i),
        )
        for i in range(n_tools)
    ]

    return AgentResponse(
        content=content,
        tool_calls=tool_calls,
        model="mock-benchmark-v1",
        latency_ms=150.0,
        cost_usd=0.003,
        tokens_used=TokenUsage(prompt_tokens=200, completion_tokens=100, total_tokens=300),
    )


def _make_json_response() -> AgentResponse:
    """Create a response whose content is valid JSON for schema checks."""
    return AgentResponse(
        content='{"order_id": "ORD-001", "status": "shipped", "total": 79.99}',
        model="mock-benchmark-v1",
        latency_ms=120.0,
        cost_usd=0.002,
        tokens_used=TokenUsage(prompt_tokens=150, completion_tokens=80, total_tokens=230),
    )


def _make_pii_response() -> AgentResponse:
    """Response that contains PII patterns (for PII assertion benchmarking)."""
    return AgentResponse(
        content=(
            "The customer's email is john.doe@example.com and their phone is "
            "(555) 123-4567. Their SSN is 123-45-6789. Card: 4111-1111-1111-1111."
        ),
        model="mock-benchmark-v1",
        latency_ms=100.0,
        cost_usd=0.001,
        tokens_used=TokenUsage(prompt_tokens=100, completion_tokens=50, total_tokens=150),
    )


# ---------------------------------------------------------------------------
# Pydantic schema for schema assertion benchmark
# ---------------------------------------------------------------------------

class OrderResponse(BaseModel):
    order_id: str
    status: str
    total: float


# ---------------------------------------------------------------------------
# Benchmark harness
# ---------------------------------------------------------------------------

ITERATIONS = 1_000


def _percentile(data: list[float], pct: float) -> float:
    """Return the *pct*-th percentile of *data* (0-100 scale)."""
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * pct / 100.0
    f = int(k)
    c = f + 1
    if c >= len(sorted_data):
        return sorted_data[f]
    return sorted_data[f] + (k - f) * (sorted_data[c] - sorted_data[f])


async def benchmark_assertion(name: str, assertion, response: AgentResponse) -> dict:
    """Run a single assertion ITERATIONS times and collect timing stats."""
    times_us: list[float] = []

    # Warm-up
    for _ in range(10):
        await assertion.evaluate(response)

    for _ in range(ITERATIONS):
        start = time.perf_counter_ns()
        await assertion.evaluate(response)
        elapsed_us = (time.perf_counter_ns() - start) / 1_000  # nanoseconds -> microseconds
        times_us.append(elapsed_us)

    return {
        "name": name,
        "iterations": ITERATIONS,
        "min_us": min(times_us),
        "max_us": max(times_us),
        "avg_us": statistics.mean(times_us),
        "median_us": statistics.median(times_us),
        "p50_us": _percentile(times_us, 50),
        "p95_us": _percentile(times_us, 95),
        "p99_us": _percentile(times_us, 99),
        "stdev_us": statistics.stdev(times_us) if len(times_us) > 1 else 0,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main() -> None:
    print("=" * 80)
    print("tailtest Assertion Performance Benchmarks")
    print(f"Iterations per assertion: {ITERATIONS:,}")
    print("=" * 80)

    response_med = _make_response("medium")
    response_large = _make_response("large")
    response_json = _make_json_response()
    response_pii = _make_pii_response()

    # Define all assertion benchmarks.
    benchmarks = [
        ("ContainsAssertion", ContainsAssertion(text="order"), response_med),
        ("ContainsAssertion (ci)", ContainsAssertion(text="ORDER", case_insensitive=True), response_med),
        ("NotContainsAssertion", NotContainsAssertion(text="ERROR"), response_med),
        ("CostAssertion", CostAssertion(max_cost=0.50), response_med),
        ("LatencyAssertion", LatencyAssertion(max_ms=5000), response_med),
        ("ToolCallAssertion", ToolCallAssertion(tool_name="search_faq"), response_med),
        ("ToolCallAssertion (args)", ToolCallAssertion(tool_name="search_faq", expected_args={"query": "test query 0"}), response_med),
        ("ToolNotCalledAssertion", ToolNotCalledAssertion(tool_name="delete_user"), response_med),
        ("PIIAssertion (clean)", PIIAssertion(), response_med),
        ("PIIAssertion (dirty)", PIIAssertion(), response_pii),
        ("NoLoopAssertion", NoLoopAssertion(max_repeats=3), response_med),
        ("RegexAssertion", RegexAssertion(pattern=r"ORD-\d+"), response_med),
        ("SchemaAssertion", SchemaAssertion(model=OrderResponse), response_json),
        ("StepCountAssertion", StepCountAssertion(max_steps=15), response_med),
        ("TokensUnderAssertion", TokensUnderAssertion(max_tokens=2000), response_med),
    ]

    results = []
    for name, assertion, resp in benchmarks:
        result = await benchmark_assertion(name, assertion, resp)
        results.append(result)

    # Print results table.
    print()
    print(f"{'Assertion':<30} {'Avg':>8} {'P50':>8} {'P95':>8} {'P99':>8} {'Min':>8} {'Max':>8}")
    print(f"{'':30} {'(us)':>8} {'(us)':>8} {'(us)':>8} {'(us)':>8} {'(us)':>8} {'(us)':>8}")
    print("-" * 86)

    total_avg = 0.0
    for r in results:
        total_avg += r["avg_us"]
        print(
            f"{r['name']:<30} "
            f"{r['avg_us']:>8.1f} "
            f"{r['p50_us']:>8.1f} "
            f"{r['p95_us']:>8.1f} "
            f"{r['p99_us']:>8.1f} "
            f"{r['min_us']:>8.1f} "
            f"{r['max_us']:>8.1f}"
        )

    print("-" * 86)
    print(f"{'TOTAL (all assertions)':<30} {total_avg:>8.1f}")
    total_avg_ms = total_avg / 1_000
    print(f"\nAll {len(results)} deterministic assertions in {total_avg_ms:.2f}ms total (avg)")

    # -----------------------------------------------------------------
    # Response size scaling test
    # -----------------------------------------------------------------
    print()
    print("=" * 80)
    print("Response Size Scaling")
    print("=" * 80)

    assertion_set = [
        ContainsAssertion(text="order"),
        CostAssertion(max_cost=0.50),
        LatencyAssertion(max_ms=5000),
        PIIAssertion(),
        RegexAssertion(pattern=r"ORD-\d+"),
        NoLoopAssertion(max_repeats=3),
        StepCountAssertion(max_steps=15),
        TokensUnderAssertion(max_tokens=2000),
    ]

    print()
    print(f"{'Size':<10} {'Chars':>8} {'Tools':>6} {'Suite Avg (us)':>15} {'Per Assertion (us)':>20}")
    print("-" * 65)

    for size in ("small", "medium", "large", "xlarge"):
        resp = _make_response(size)
        times_us: list[float] = []

        for _ in range(10):  # warm-up
            for a in assertion_set:
                await a.evaluate(resp)

        for _ in range(ITERATIONS):
            start = time.perf_counter_ns()
            for a in assertion_set:
                await a.evaluate(resp)
            elapsed = (time.perf_counter_ns() - start) / 1_000
            times_us.append(elapsed)

        avg = statistics.mean(times_us)
        per_assertion = avg / len(assertion_set)
        print(f"{size:<10} {len(resp.content):>8,} {len(resp.tool_calls):>6} {avg:>15.1f} {per_assertion:>20.1f}")

    # -----------------------------------------------------------------
    # LLM-judge cost comparison
    # -----------------------------------------------------------------
    print()
    print("=" * 80)
    print("Deterministic vs LLM-Judge Cost Comparison")
    print("=" * 80)

    # Typical LLM-judge costs (based on GPT-4o-mini pricing: ~$0.15/1M input, ~$0.60/1M output)
    # Each LLM-judge call: ~500 prompt tokens + ~200 completion tokens
    llm_prompt_tokens = 500
    llm_completion_tokens = 200
    llm_cost_per_call = (llm_prompt_tokens * 0.15 / 1_000_000) + (llm_completion_tokens * 0.60 / 1_000_000)
    llm_latency_ms = 800  # typical LLM API round-trip

    det_assertions = len(results)
    det_total_ms = total_avg_ms

    print(f"""
  {'Metric':<35} {'Deterministic':>15} {'LLM-Judge':>15}
  {'-' * 65}
  {'Assertions checked':<35} {det_assertions:>15} {det_assertions:>15}
  {'Total latency':<35} {f'{det_total_ms:.2f}ms':>15} {f'{llm_latency_ms * det_assertions}ms':>15}
  {'Cost per run':<35} {'$0.0000':>15} {f'${llm_cost_per_call * det_assertions:.4f}':>15}
  {'Cost for 1,000 runs':<35} {'$0.0000':>15} {f'${llm_cost_per_call * det_assertions * 1000:.2f}':>15}
  {'Cost for 10,000 runs':<35} {'$0.0000':>15} {f'${llm_cost_per_call * det_assertions * 10000:.2f}':>15}
  {'Requires API key':<35} {'No':>15} {'Yes':>15}
  {'Works offline':<35} {'Yes':>15} {'No':>15}
  {'Deterministic results':<35} {'Yes':>15} {'No':>15}
""")

    speedup = (llm_latency_ms * det_assertions) / det_total_ms if det_total_ms > 0 else 0
    print(f"  Deterministic assertions are ~{speedup:,.0f}x faster than LLM-judge equivalents.")
    print(f"  At 10,000 test runs, LLM-judge would cost ${llm_cost_per_call * det_assertions * 10000:.2f} vs $0.00 for deterministic.")
    print()


if __name__ == "__main__":
    asyncio.run(main())
