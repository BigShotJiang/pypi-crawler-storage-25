"""Performance benchmarks for the tailtest project scanner.

Run: python benchmarks/benchmark_scan.py

Measures scanner speed across projects of different sizes (file count and
directory depth). Reports files/second and time-to-first-context.
"""

from __future__ import annotations

import asyncio
import os
import statistics
import sys
import tempfile
import time
from pathlib import Path

# Ensure the src/ package is importable when running from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from tailtest.context.sources.scanner import scan_project, _collect_python_files


# ---------------------------------------------------------------------------
# Synthetic project generators
# ---------------------------------------------------------------------------

_AGENT_FILE = '''\
"""Synthetic agent module for benchmarking."""
import os
from openai import OpenAI

SYSTEM_PROMPT = """You are a helpful assistant that answers questions
about our products and services. Be concise and friendly."""

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

TOOLS = [
    {{
        "type": "function",
        "function": {{
            "name": "search_{idx}",
            "description": "Search function {idx}",
            "parameters": {{
                "type": "object",
                "properties": {{
                    "query": {{"type": "string"}},
                }},
                "required": ["query"],
            }},
        }},
    }},
]

def agent_{idx}(message: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {{"role": "system", "content": SYSTEM_PROMPT}},
            {{"role": "user", "content": message}},
        ],
        tools=TOOLS,
    )
    return response.choices[0].message.content
'''

_PLAIN_FILE = '''\
"""Utility module {idx}  -  no agent code."""

def helper_{idx}(x: int) -> int:
    """Simple helper function."""
    return x * 2 + {idx}

class Config_{idx}:
    """Configuration class."""
    def __init__(self):
        self.value = {idx}
        self.name = "config_{idx}"
'''

_REQUIREMENTS = """\
openai>=1.0
pydantic>=2.0
httpx>=0.25
click>=8.0
litellm>=1.0
"""


def _generate_project(
    root: Path,
    n_py_files: int,
    agent_ratio: float = 0.2,
    depth: int = 3,
) -> dict:
    """Generate a synthetic Python project.

    Parameters
    ----------
    root:
        Directory to generate into.
    n_py_files:
        Total number of .py files.
    agent_ratio:
        Fraction of files that contain agent code (0.0-1.0).
    depth:
        Maximum directory nesting depth.

    Returns
    -------
    dict with stats about the generated project.
    """
    n_agent_files = int(n_py_files * agent_ratio)
    n_plain_files = n_py_files - n_agent_files

    # Create directory structure
    dirs = [root / "src"]
    for d in range(min(depth, 5)):
        sub = root / "src" / f"pkg_{d}"
        sub.mkdir(parents=True, exist_ok=True)
        dirs.append(sub)
        for s in range(min(d + 1, 3)):
            subsub = sub / f"sub_{s}"
            subsub.mkdir(parents=True, exist_ok=True)
            dirs.append(subsub)

    # Write requirements.txt
    (root / "requirements.txt").write_text(_REQUIREMENTS)

    # Distribute files across directories
    idx = 0
    for i in range(n_agent_files):
        target_dir = dirs[i % len(dirs)]
        (target_dir / f"agent_{idx}.py").write_text(_AGENT_FILE.format(idx=idx))
        idx += 1

    for i in range(n_plain_files):
        target_dir = dirs[i % len(dirs)]
        (target_dir / f"utils_{idx}.py").write_text(_PLAIN_FILE.format(idx=idx))
        idx += 1

    # Add __init__.py files
    for d in dirs:
        init = d / "__init__.py"
        if not init.exists():
            init.write_text("")

    return {
        "total_py_files": n_py_files,
        "agent_files": n_agent_files,
        "plain_files": n_plain_files,
        "directories": len(dirs),
    }


# ---------------------------------------------------------------------------
# Project size presets
# ---------------------------------------------------------------------------

PROJECTS = {
    "small": {"n_py_files": 10, "agent_ratio": 0.3, "depth": 2},
    "medium": {"n_py_files": 50, "agent_ratio": 0.2, "depth": 3},
    "large": {"n_py_files": 200, "agent_ratio": 0.15, "depth": 4},
    "xlarge": {"n_py_files": 500, "agent_ratio": 0.10, "depth": 5},
}


# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------

def _percentile(data: list[float], pct: float) -> float:
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * pct / 100.0
    f = int(k)
    c = f + 1
    if c >= len(sorted_data):
        return sorted_data[f]
    return sorted_data[f] + (k - f) * (sorted_data[c] - sorted_data[f])


async def benchmark_file_collection(root: Path) -> dict:
    """Benchmark the file walker (no parsing)."""
    times_ms: list[float] = []

    # Warm-up
    _collect_python_files(root)

    for _ in range(50):
        start = time.perf_counter()
        files = _collect_python_files(root)
        elapsed_ms = (time.perf_counter() - start) * 1000
        times_ms.append(elapsed_ms)

    avg_ms = statistics.mean(times_ms)
    return {
        "files_found": len(files),
        "avg_ms": avg_ms,
        "p95_ms": _percentile(times_ms, 95),
        "files_per_sec": (len(files) / avg_ms) * 1000 if avg_ms > 0 else 0,
    }


async def benchmark_full_scan(root: Path) -> dict:
    """Benchmark the full scan_project pipeline."""
    times_ms: list[float] = []
    time_to_first_context_ms: list[float] = []

    # Warm-up
    await scan_project(root)

    iterations = 10
    for _ in range(iterations):
        start = time.perf_counter()
        result = await scan_project(root)
        elapsed_ms = (time.perf_counter() - start) * 1000
        times_ms.append(elapsed_ms)

        # Time to first context = time until we have at least one tool/prompt/agent
        # In practice, this is approximately the full scan time since it's synchronous
        # iteration. We'll record it as the same for now.
        ttfc = elapsed_ms  # The scanner processes files sequentially
        time_to_first_context_ms.append(ttfc)

    avg_ms = statistics.mean(times_ms)
    n_files = len(_collect_python_files(root))
    return {
        "files_scanned": n_files,
        "tools_found": len(result.tools),
        "prompts_found": len(result.prompts),
        "agents_found": len(result.agents),
        "models_found": len(result.models),
        "framework": result.framework,
        "avg_ms": avg_ms,
        "p95_ms": _percentile(times_ms, 95),
        "min_ms": min(times_ms),
        "max_ms": max(times_ms),
        "files_per_sec": (n_files / avg_ms) * 1000 if avg_ms > 0 else 0,
        "ttfc_avg_ms": statistics.mean(time_to_first_context_ms),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main() -> None:
    print("=" * 80)
    print("tailtest Scanner Performance Benchmarks")
    print("=" * 80)

    # -----------------------------------------------------------------
    # File collection benchmarks
    # -----------------------------------------------------------------
    print()
    print("--- File Collection (walker only, no AST parsing) ---")
    print()
    print(f"{'Size':<10} {'Files':>6} {'Avg (ms)':>10} {'P95 (ms)':>10} {'Files/sec':>12}")
    print("-" * 54)

    for size_name, params in PROJECTS.items():
        with tempfile.TemporaryDirectory(prefix="tailtest_scan_bench_") as tmp:
            root = Path(tmp)
            stats = _generate_project(root, **params)
            result = await benchmark_file_collection(root)
            print(
                f"{size_name:<10} "
                f"{result['files_found']:>6} "
                f"{result['avg_ms']:>10.2f} "
                f"{result['p95_ms']:>10.2f} "
                f"{result['files_per_sec']:>12,.0f}"
            )

    # -----------------------------------------------------------------
    # Full scan benchmarks
    # -----------------------------------------------------------------
    print()
    print("--- Full Scan (file walk + AST parse + detection) ---")
    print()
    print(
        f"{'Size':<10} {'Files':>6} {'Tools':>6} {'Prompts':>8} "
        f"{'Avg (ms)':>10} {'P95 (ms)':>10} {'Files/sec':>10} {'TTFC (ms)':>10}"
    )
    print("-" * 82)

    scan_results = []
    for size_name, params in PROJECTS.items():
        with tempfile.TemporaryDirectory(prefix="tailtest_scan_bench_") as tmp:
            root = Path(tmp)
            stats = _generate_project(root, **params)
            result = await benchmark_full_scan(root)
            scan_results.append((size_name, stats, result))
            print(
                f"{size_name:<10} "
                f"{result['files_scanned']:>6} "
                f"{result['tools_found']:>6} "
                f"{result['prompts_found']:>8} "
                f"{result['avg_ms']:>10.2f} "
                f"{result['p95_ms']:>10.2f} "
                f"{result['files_per_sec']:>10,.0f} "
                f"{result['ttfc_avg_ms']:>10.2f}"
            )

    # -----------------------------------------------------------------
    # Scaling analysis
    # -----------------------------------------------------------------
    print()
    print("--- Scaling Analysis ---")
    print()
    if len(scan_results) >= 2:
        base_name, base_stats, base_result = scan_results[0]
        for size_name, stats, result in scan_results[1:]:
            file_ratio = stats["total_py_files"] / base_stats["total_py_files"]
            time_ratio = result["avg_ms"] / base_result["avg_ms"] if base_result["avg_ms"] > 0 else 0
            print(
                f"  {size_name} vs {base_name}: "
                f"{file_ratio:.1f}x more files, "
                f"{time_ratio:.1f}x longer scan time "
                f"(scaling factor: {time_ratio / file_ratio:.2f}x per file)"
            )

    # -----------------------------------------------------------------
    # Real project scan (tailtest itself)
    # -----------------------------------------------------------------
    print()
    print("--- Real Project: tailtest source tree ---")
    print()

    src_path = Path(__file__).resolve().parent.parent / "src"
    if src_path.is_dir():
        result = await benchmark_full_scan(src_path)
        print(f"  Files scanned:       {result['files_scanned']}")
        print(f"  Tools found:         {result['tools_found']}")
        print(f"  Prompts found:       {result['prompts_found']}")
        print(f"  Agents found:        {result['agents_found']}")
        print(f"  Framework:           {result['framework']}")
        print(f"  Avg scan time:       {result['avg_ms']:.2f}ms")
        print(f"  P95 scan time:       {result['p95_ms']:.2f}ms")
        print(f"  Files/sec:           {result['files_per_sec']:,.0f}")
        print(f"  Time to context:     {result['ttfc_avg_ms']:.2f}ms")
    else:
        print("  (src/ directory not found, skipping)")

    print()


if __name__ == "__main__":
    asyncio.run(main())
