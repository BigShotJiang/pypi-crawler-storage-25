# tailtest Performance Benchmarks

Benchmarks measuring the speed of tailtest's core subsystems: deterministic
assertions, the test runner pipeline, and the project scanner.

## How to Run

From the repository root, using the project venv:

```bash
# Run all benchmarks
.venv/bin/python benchmarks/benchmark_assertions.py
.venv/bin/python benchmarks/benchmark_runner.py
.venv/bin/python benchmarks/benchmark_scan.py
```

Each script is self-contained and prints results to stdout. No API keys or
network access required.

## Results

All measurements taken on Apple Silicon (M-series), Python 3.11+,
single-process unless noted.

---

### Assertion Benchmarks

Measures execution time for each of the 15 deterministic assertion types,
run 1,000 times each against mock `AgentResponse` objects.

| Assertion                | Avg (us) | P50 (us) | P95 (us) | P99 (us) |
| ------------------------ | -------: | -------: | -------: | -------: |
| ContainsAssertion        |      1.4 |      1.2 |      1.4 |      1.6 |
| ContainsAssertion (ci)   |      1.6 |      1.4 |      1.7 |      2.0 |
| NotContainsAssertion     |      1.4 |      1.4 |      1.5 |      1.5 |
| CostAssertion            |      2.4 |      1.4 |      3.5 |     24.4 |
| LatencyAssertion         |      1.6 |      1.3 |      1.5 |      9.5 |
| ToolCallAssertion        |      1.2 |      1.2 |      1.4 |      1.5 |
| ToolCallAssertion (args) |      1.6 |      1.4 |      1.8 |      1.9 |
| ToolNotCalledAssertion   |      1.5 |      1.3 |      1.5 |      2.2 |
| PIIAssertion (clean)     |    156.7 |     51.7 |    350.1 |   1379.4 |
| PIIAssertion (dirty)     |    302.5 |     17.9 |    435.9 |   3635.8 |
| NoLoopAssertion          |      4.0 |      3.5 |      4.4 |     42.5 |
| RegexAssertion           |      2.7 |      1.6 |      4.8 |     27.8 |
| SchemaAssertion          |     22.8 |      7.5 |     52.4 |    237.9 |
| StepCountAssertion       |      1.6 |      1.2 |      3.0 |      3.4 |
| TokensUnderAssertion     |      1.3 |      1.2 |      1.2 |      1.4 |
| **TOTAL (all 15)**       | **504.3**|          |          |          |

**Key finding:** All 15 deterministic assertions execute in ~0.50ms total.
Most individual assertions complete in under 2 microseconds. PII and Schema
assertions are the most expensive due to regex matching and Pydantic
validation, but still run in sub-millisecond time.

#### Response Size Scaling

| Size   |  Chars | Tools | Suite Avg (us) | Per Assertion (us) |
| ------ | -----: | ----: | -------------: | -----------------: |
| small  |    100 |     0 |           28.0 |                3.5 |
| medium |    500 |     2 |          298.6 |               37.3 |
| large  |  5,000 |    10 |          796.2 |               99.5 |
| xlarge | 50,000 |    50 |        7,263.4 |              907.9 |

Scaling is sub-linear relative to content size; 500x larger content results
in roughly 260x longer execution.

---

### Deterministic vs LLM-Judge Cost Comparison

The core value proposition of tailtest's deterministic-first architecture:

| Metric                  | Deterministic | LLM-Judge   |
| ----------------------- | ------------: | ----------: |
| Assertions checked      |            15 |          15 |
| Total latency           |        0.50ms |    12,000ms |
| Cost per run            |       $0.0000 |     $0.0029 |
| Cost for 1,000 runs     |       $0.0000 |       $2.93 |
| Cost for 10,000 runs    |       $0.0000 |      $29.25 |
| Requires API key        |            No |         Yes |
| Works offline           |           Yes |          No |
| Deterministic results   |           Yes |          No |

**Deterministic assertions are ~24,000x faster and infinitely cheaper.**

At CI scale (10,000 runs/month), LLM-judge assertions cost $29.25/month
for the same checks that deterministic assertions perform for free in
sub-millisecond time. LLM-judge costs are based on GPT-4o-mini pricing
($0.15/1M input, $0.60/1M output) with ~500 prompt + ~200 completion
tokens per judge call.

---

### Runner Pipeline Benchmarks

Measures the full test execution pipeline: discovery, execution, and result
collection across varying test suite sizes.

#### Test Discovery

| Tests | Found | Avg (ms) | P95 (ms) |
| ----: | ----: | -------: | -------: |
|    10 |    10 |     0.43 |     0.50 |
|    50 |    50 |     1.81 |     2.12 |
|   100 |   100 |     3.70 |     4.10 |
|   200 |   200 |     7.54 |     9.66 |

Discovery scales linearly: ~0.04ms per test file.

#### Sequential Execution

| Tests | Avg (ms) | Tests/sec | Overhead/test |
| ----: | -------: | --------: | ------------: |
|    10 |     1.02 |     9,810 |        0.10ms |
|    50 |     2.63 |    18,995 |        0.05ms |
|   100 |     5.40 |    18,508 |        0.05ms |
|   200 |    10.64 |    18,795 |        0.05ms |

**~19,000 tests per second** at scale, with only 0.05ms overhead per test.

#### Parallel vs Sequential Comparison (4 workers)

| Tests | Seq (ms) | Par (ms) | Seq tests/s | Par tests/s |
| ----: | -------: | -------: | ----------: | ----------: |
|    10 |     1.02 |     0.84 |       9,810 |      11,865 |
|    50 |     2.63 |     3.36 |      18,995 |      14,897 |
|   100 |     5.40 |     6.07 |      18,508 |      16,485 |
|   200 |    10.64 |    13.00 |      18,795 |      15,384 |

For purely deterministic tests (no I/O), sequential execution is faster
because the async overhead of semaphores and task scheduling exceeds the
work itself. Parallel execution shines when tests make real LLM API calls
(800ms+ per call), where concurrency reduces wall-clock time linearly.

---

### Scanner Benchmarks

Measures project scanning speed: file collection and full AST-based
framework detection.

#### File Collection (walker only)

| Size   | Files | Avg (ms) | Files/sec |
| ------ | ----: | -------: | --------: |
| small  |    16 |     0.35 |    45,661 |
| medium |    60 |     0.98 |    61,115 |
| large  |   214 |     2.69 |    79,625 |
| xlarge |   518 |     6.80 |    76,172 |

File walking sustains 45,000-80,000 files/second.

#### Full Scan (walk + AST parse + detection)

| Size   | Files | Avg (ms) | Files/sec | TTFC (ms) |
| ------ | ----: | -------: | --------: | --------: |
| small  |    16 |     8.09 |     1,978 |      8.09 |
| medium |    60 |    33.50 |     1,791 |     33.50 |
| large  |   214 |   132.95 |     1,610 |    132.95 |
| xlarge |   518 |   307.00 |     1,687 |    307.00 |

Full scanning (AST parse + 6 framework detectors) processes ~1,700
files/second. A 500-file project scans in ~300ms.

#### Scaling Behavior

| Comparison      | File ratio | Time ratio | Scaling factor |
| --------------- | ---------: | ---------: | -------------: |
| medium vs small |       5.0x |       4.1x |          0.83x |
| large vs small  |      20.0x |      16.4x |          0.82x |
| xlarge vs small |      50.0x |      38.0x |          0.76x |

Scaling is sub-linear: 50x more files takes only 38x longer. Fixed
overhead (directory traversal, detector initialization) is amortized
across larger projects.

#### Real Project: tailtest Source Tree

| Metric           | Value    |
| ---------------- | -------: |
| Files scanned    |      105 |
| Avg scan time    | 669.01ms |
| P95 scan time    | 692.42ms |
| Files/sec        |      157 |

The tailtest source tree itself (105 Python files) scans in under 700ms.
This is slower per-file than synthetic projects because the real codebase
contains larger, more complex files with deeper AST trees.

---

## Interpretation

1. **Deterministic assertions are effectively free.** The entire suite of 15
   assertions runs in 0.5ms. This validates the "deterministic first"
   architecture: 80% of useful agent checks (contains, cost, latency, PII,
   tool calls, schema) need zero LLM calls.

2. **The runner adds minimal overhead.** At 0.05ms per test, the engine
   itself is not the bottleneck. Real-world test speed is dominated by
   agent call latency (typically 500-3000ms per LLM call), not framework
   overhead.

3. **Scanning is fast enough for interactive use.** Sub-second scan times
   for projects up to 500 files means `tailtest scan .` feels instant in
   typical projects.

4. **The cost argument is compelling.** For teams running thousands of tests
   in CI, deterministic assertions save real money. A pipeline running 10,000
   assertion evaluations/month saves ~$30/month vs LLM-judge, with zero
   latency penalty and deterministic reproducibility.
