"""Performance benchmarks for the tailtest test runner pipeline.

Run: python benchmarks/benchmark_runner.py

Measures full pipeline speed: discovery, execution, and reporting.
Tests with varying numbers of test cases and parallel vs sequential execution.
"""

from __future__ import annotations

import asyncio
import os
import statistics
import sys
import tempfile
import time
from pathlib import Path

# Ensure the src/ package is importable when running from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from tailtest.runner.engine import TestRunner, RunConfig
from tailtest.runner.discovery import discover_tests


# ---------------------------------------------------------------------------
# Synthetic test file generator
# ---------------------------------------------------------------------------

_TEST_TEMPLATE = '''\
"""Auto-generated benchmark test file  -  {n} test(s)."""

from tailtest.models import AgentResponse, ToolCall, TokenUsage

def _mock_response(idx: int) -> AgentResponse:
    return AgentResponse(
        content=f"Response for test {{idx}}. Order ORD-{{idx:04d}} is shipped.",
        tool_calls=[
            ToolCall(name="search_faq", arguments={{"query": f"q{{idx}}"}}, result={{"found": True}}, duration_ms=10.0),
        ],
        model="mock-v1",
        latency_ms=100.0,
        cost_usd=0.001,
        tokens_used=TokenUsage(prompt_tokens=100, completion_tokens=50, total_tokens=150),
    )

{test_functions}
'''

_SINGLE_TEST = '''\
async def test_case_{idx}():
    """Benchmark test case {idx}."""
    resp = _mock_response({idx})
    assert "Response" in resp.content
    assert resp.latency_ms < 5000
    assert resp.cost_usd < 1.0
'''


def _generate_test_files(tmp_dir: Path, n_tests: int, tests_per_file: int = 25) -> Path:
    """Generate synthetic test files in *tmp_dir* with *n_tests* total tests.

    Distributes tests across multiple files (tests_per_file each) to
    simulate a realistic project layout.
    """
    n_files = max(1, n_tests // tests_per_file)
    tests_remaining = n_tests
    idx = 0

    for file_num in range(n_files):
        count = min(tests_per_file, tests_remaining)
        tests_remaining -= count

        funcs = []
        for _ in range(count):
            funcs.append(_SINGLE_TEST.format(idx=idx))
            idx += 1

        content = _TEST_TEMPLATE.format(
            n=count,
            test_functions="\n".join(funcs),
        )
        file_path = tmp_dir / f"test_bench_{file_num:04d}.py"
        file_path.write_text(content)

    # Handle remainder
    if tests_remaining > 0:
        funcs = []
        for _ in range(tests_remaining):
            funcs.append(_SINGLE_TEST.format(idx=idx))
            idx += 1
        content = _TEST_TEMPLATE.format(
            n=tests_remaining,
            test_functions="\n".join(funcs),
        )
        file_path = tmp_dir / f"test_bench_{n_files:04d}.py"
        file_path.write_text(content)

    return tmp_dir


# ---------------------------------------------------------------------------
# Benchmark: Discovery
# ---------------------------------------------------------------------------

async def benchmark_discovery(test_dir: Path, n_tests: int) -> dict:
    """Measure how long test discovery takes."""
    times_ms: list[float] = []

    # Warm-up
    discover_tests(test_dir)

    for _ in range(20):
        start = time.perf_counter()
        tests = discover_tests(test_dir)
        elapsed_ms = (time.perf_counter() - start) * 1000
        times_ms.append(elapsed_ms)

    return {
        "tests_found": len(tests),
        "avg_ms": statistics.mean(times_ms),
        "p95_ms": _percentile(times_ms, 95),
        "min_ms": min(times_ms),
        "max_ms": max(times_ms),
    }


# ---------------------------------------------------------------------------
# Benchmark: Full run (sequential)
# ---------------------------------------------------------------------------

async def benchmark_run_sequential(test_dir: Path, n_tests: int) -> dict:
    """Run all tests sequentially and measure throughput."""
    runner = TestRunner()
    config = RunConfig(parallel=1, timeout_ms=10_000)

    # Warm-up
    await runner.run(test_dir, config=config)

    times_ms: list[float] = []
    iterations = 5

    for _ in range(iterations):
        start = time.perf_counter()
        result = await runner.run(test_dir, config=config)
        elapsed_ms = (time.perf_counter() - start) * 1000
        times_ms.append(elapsed_ms)

    avg_ms = statistics.mean(times_ms)
    return {
        "mode": "sequential",
        "n_tests": result.total,
        "passed": result.passed,
        "avg_ms": avg_ms,
        "p95_ms": _percentile(times_ms, 95),
        "tests_per_sec": (result.total / avg_ms) * 1000 if avg_ms > 0 else 0,
        "overhead_per_test_ms": avg_ms / result.total if result.total > 0 else 0,
    }


# ---------------------------------------------------------------------------
# Benchmark: Full run (parallel)
# ---------------------------------------------------------------------------

async def benchmark_run_parallel(test_dir: Path, n_tests: int, workers: int = 4) -> dict:
    """Run all tests in parallel and measure throughput."""
    runner = TestRunner()
    config = RunConfig(parallel=workers, timeout_ms=10_000)

    # Warm-up
    await runner.run(test_dir, config=config)

    times_ms: list[float] = []
    iterations = 5

    for _ in range(iterations):
        start = time.perf_counter()
        result = await runner.run(test_dir, config=config)
        elapsed_ms = (time.perf_counter() - start) * 1000
        times_ms.append(elapsed_ms)

    avg_ms = statistics.mean(times_ms)
    return {
        "mode": f"parallel({workers})",
        "n_tests": result.total,
        "passed": result.passed,
        "avg_ms": avg_ms,
        "p95_ms": _percentile(times_ms, 95),
        "tests_per_sec": (result.total / avg_ms) * 1000 if avg_ms > 0 else 0,
        "overhead_per_test_ms": avg_ms / result.total if result.total > 0 else 0,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _percentile(data: list[float], pct: float) -> float:
    """Return the *pct*-th percentile of *data* (0-100 scale)."""
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * pct / 100.0
    f = int(k)
    c = f + 1
    if c >= len(sorted_data):
        return sorted_data[f]
    return sorted_data[f] + (k - f) * (sorted_data[c] - sorted_data[f])


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main() -> None:
    print("=" * 80)
    print("tailtest Runner Pipeline Benchmarks")
    print("=" * 80)

    test_sizes = [10, 50, 100, 200]

    # -----------------------------------------------------------------
    # Discovery benchmarks
    # -----------------------------------------------------------------
    print()
    print("--- Discovery Benchmarks ---")
    print()
    print(f"{'Tests':>6} {'Found':>6} {'Avg (ms)':>10} {'P95 (ms)':>10} {'Min (ms)':>10} {'Max (ms)':>10}")
    print("-" * 60)

    for n in test_sizes:
        with tempfile.TemporaryDirectory(prefix="tailtest_bench_") as tmp:
            tmp_path = Path(tmp)
            _generate_test_files(tmp_path, n)
            result = await benchmark_discovery(tmp_path, n)
            print(
                f"{n:>6} "
                f"{result['tests_found']:>6} "
                f"{result['avg_ms']:>10.2f} "
                f"{result['p95_ms']:>10.2f} "
                f"{result['min_ms']:>10.2f} "
                f"{result['max_ms']:>10.2f}"
            )

    # -----------------------------------------------------------------
    # Sequential execution benchmarks
    # -----------------------------------------------------------------
    print()
    print("--- Sequential Execution ---")
    print()
    print(f"{'Tests':>6} {'Passed':>7} {'Avg (ms)':>10} {'Tests/sec':>10} {'Overhead/test':>14}")
    print("-" * 55)

    seq_results = []
    for n in test_sizes:
        with tempfile.TemporaryDirectory(prefix="tailtest_bench_") as tmp:
            tmp_path = Path(tmp)
            _generate_test_files(tmp_path, n)
            result = await benchmark_run_sequential(tmp_path, n)
            seq_results.append(result)
            print(
                f"{n:>6} "
                f"{result['passed']:>7} "
                f"{result['avg_ms']:>10.2f} "
                f"{result['tests_per_sec']:>10.0f} "
                f"{result['overhead_per_test_ms']:>12.2f}ms"
            )

    # -----------------------------------------------------------------
    # Parallel execution benchmarks
    # -----------------------------------------------------------------
    print()
    print("--- Parallel Execution (4 workers) ---")
    print()
    print(f"{'Tests':>6} {'Passed':>7} {'Avg (ms)':>10} {'Tests/sec':>10} {'Overhead/test':>14}")
    print("-" * 55)

    par_results = []
    for n in test_sizes:
        with tempfile.TemporaryDirectory(prefix="tailtest_bench_") as tmp:
            tmp_path = Path(tmp)
            _generate_test_files(tmp_path, n)
            result = await benchmark_run_parallel(tmp_path, n, workers=4)
            par_results.append(result)
            print(
                f"{n:>6} "
                f"{result['passed']:>7} "
                f"{result['avg_ms']:>10.2f} "
                f"{result['tests_per_sec']:>10.0f} "
                f"{result['overhead_per_test_ms']:>12.2f}ms"
            )

    # -----------------------------------------------------------------
    # Sequential vs Parallel comparison
    # -----------------------------------------------------------------
    print()
    print("--- Sequential vs Parallel Comparison ---")
    print()
    print(f"{'Tests':>6} {'Seq (ms)':>10} {'Par (ms)':>10} {'Speedup':>10} {'Seq t/s':>10} {'Par t/s':>10}")
    print("-" * 62)

    for seq, par in zip(seq_results, par_results):
        speedup = seq["avg_ms"] / par["avg_ms"] if par["avg_ms"] > 0 else 0
        print(
            f"{seq['n_tests']:>6} "
            f"{seq['avg_ms']:>10.2f} "
            f"{par['avg_ms']:>10.2f} "
            f"{speedup:>9.2f}x "
            f"{seq['tests_per_sec']:>10.0f} "
            f"{par['tests_per_sec']:>10.0f}"
        )

    print()


if __name__ == "__main__":
    asyncio.run(main())
