# Maturity Engine

The Maturity Engine is tailtest's learning system. It accumulates intelligence about your specific agent over time, making tests progressively smarter. No model retraining -- pure context accumulation and statistical analysis.

```
Day 1:    "Here are generic tests for your agent"
Week 2:   "I've learned your agent's failure patterns -- here are targeted tests"
Month 2:  "I predict this code change will break these tests. Here's why."
```

## Install

```bash
pip install tailtester
```

The Maturity Engine activates automatically after `tailtest init`. No extra setup needed.

## Three Maturity Levels

### Seedling (0-9 runs)

Your starting point. Tailtest knows basic structure from scanning your code.

**Available commands:** `tailtest scan`, `tailtest generate`, `tailtest run`, `tailtest redteam`

**Thresholds:** All defaults from config (cost: $0.05, latency: 3000ms, pass_rate: 0.95).

**Transition to Growing:** Complete 10 test runs.

### Growing (10-49 runs)

Tailtest has observed enough behavior to start learning patterns.

**Unlocked features:**

- Threshold calibration from observed data
- Flaky test detection
- Failure pattern recognition
- `tailtest suggest` for targeted test recommendations
- Trend reports with sparklines and failure categories

**Transition to Mature:** 50+ runs, at least 1 production trace ingested, and at least 1 auto-generated regression test.

### Mature (50+ runs + production data)

Full intelligence. Tailtest deeply understands your agent's behavioral profile.

**Unlocked features:**

- `tailtest predict` -- predicts which tests break from a code diff
- `tailtest optimize` -- finds redundant, missing, and inefficient tests
- Auto-regression from production traces
- Coverage gap analysis
- Drift prediction and early warnings

## Check Your Maturity Status

```bash
tailtest status
```

Example output:

```
Maturity Level: Growing (32/50 runs to Mature)
Thresholds: 2 calibrated (cost: $0.012, latency: 510ms)
Failure patterns: 3 identified (hallucination, pii_leak, scope_violation)
Flaky tests: 1 (test_greeting_reliability -- 6.4% flake rate)
Next level: Complete 18 more runs + ingest production traces
```

## Get Test Suggestions (Growing+)

```bash
tailtest suggest
```

Example output:

```
Based on 32 runs, I suggest 3 new tests:
1. test_unknown_product_hallucination -- agent hallucinated 8 times on unknown products
2. test_bulk_data_request_privacy -- agent leaked data on "list all" queries (2 incidents)
3. test_competitor_scope -- agent made competitor claims (new pattern, 3 incidents)

Run `tailtest suggest --apply` to generate these test files.
```

Apply suggestions directly:

```bash
tailtest suggest --apply
```

This generates test files based on observed failure patterns and adds them to your test suite.

## Predict Failures (Mature Only)

```bash
tailtest predict
```

Analyzes your uncommitted changes and cross-references with historical failure data:

```
Analyzing uncommitted changes...
HIGH: test_refund_flow -- prompt change in system_prompt.py affects refund handling
      (this test failed 3/4 times when this section was modified)
LOW:  test_greeting -- minor wording change, unlikely to break
      (this test has never failed across 50 runs)
```

The predictor checks for changes to prompt files, tool definitions, and model configurations, then correlates with your historical test results.

## Optimize Your Test Suite (Mature Only)

```bash
tailtest optimize
```

Example output:

```
Optimization suggestions:
- REDUNDANT: test_no_medical and test_no_legal always pass/fail together (merge?)
- UPGRADE: test_response_quality uses LLM judge ($0.015/run) but could be
  replaced with deterministic contains check (saves $0.015/run)
- MISSING: No tests for multi-turn conversations (seen in 40% of production traces)
- FLAKY: test_greeting_reliability fails 6.4% -- investigate or increase threshold
```

## Threshold Calibration

At the Growing level, tailtest replaces default thresholds with values calibrated from your agent's actual behavior.

The calibration method is **1.5x p95**: take the 95th percentile of observed values and multiply by 1.5. This gives a threshold that is tight enough to catch regressions but loose enough to avoid false alarms.

**Example:** If your agent consistently costs $0.003-$0.008 per call, with a p95 of $0.008:

- Default threshold: $0.05 (too loose to catch anything)
- Calibrated threshold: $0.012 (1.5 x $0.008)

Same logic applies to latency. If your agent responds in 180-340ms with a p95 of 340ms, the calibrated threshold becomes 510ms instead of the default 3000ms.

Calibration requires at least 10 data points per metric before activating.

## Failure Pattern Detection

Starting at the Growing level, tailtest groups recurring failures by category:

- **Hallucination** -- agent makes claims unsupported by its data
- **PII leak** -- agent exposes personal information
- **Tool error** -- expected tool calls missing or wrong
- **Scope violation** -- agent responds outside its defined scope
- **Cost overrun** -- agent exceeds cost budgets

Each pattern tracks the count, first/last occurrence, input triggers, and affected tests. These patterns feed directly into `tailtest suggest`.

## Flaky Test Detection

A test is marked flaky when it passes sometimes and fails sometimes across runs. Tailtest tracks the flake rate (percentage of runs that failed) and flags tests above a configurable threshold.

Flaky tests appear in `tailtest status` output and in `tailtest optimize` suggestions.

## Data Storage

All maturity data lives in `.tailtest/maturity.json`. Key fields:

```json
{
  "level": "growing",
  "level_transitions": {
    "seedling_to_growing": "2026-04-15T10:30:00Z",
    "growing_to_mature": null
  },
  "stats": {
    "total_runs": 47,
    "total_tests_executed": 1034,
    "first_run": "2026-04-01T09:00:00Z",
    "last_run": "2026-04-28T14:30:00Z"
  },
  "calibrated_thresholds": {
    "cost_usd": {
      "default": 0.05,
      "calibrated": 0.012,
      "observed_p50": 0.003,
      "observed_p95": 0.008,
      "calibration_method": "1.5x_p95",
      "sample_size": 47
    }
  },
  "failure_patterns": { },
  "test_profiles": { }
}
```

This file is automatically maintained. You can commit it to version control to share maturity state across your team.
