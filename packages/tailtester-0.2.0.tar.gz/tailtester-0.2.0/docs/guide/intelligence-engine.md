# Intelligence Engine

The Intelligence Engine combines three sources of knowledge to generate tests that are structurally correct, semantically meaningful, and business-relevant.

```
Layer 1: Structural (AST/Pattern) -- fast, free, always runs
Layer 2: LLM Understanding        -- deep code reading, ~$0.01/file
Layer 3: User Rules                -- your business rules in rules.yaml
```

## Install

```bash
pip install tailtester
```

## Why Three Layers

| Alone | Problem |
|-------|---------|
| Only structural | Tests tool calls but doesn't know WHY they matter |
| Only LLM | Might hallucinate rules that don't exist |
| Only user | Back to writing tests manually |
| Combined | Structurally correct + semantically meaningful + business-relevant |

## Layer 1: Structural Intelligence

Structural intelligence runs automatically on every `tailtest scan`. It parses your source code with AST analysis and pattern matching to detect:

- **Framework imports** (OpenAI, Anthropic, LangChain, CrewAI, PydanticAI)
- **Tool definitions** (@tool decorators, function calling schemas)
- **System prompts** (string literals in messages arrays)
- **Model names** (gpt-4o, claude-sonnet, etc.)
- **Agent configurations** (orchestrators, chains, crews)

Cost: Free. Speed: Milliseconds. Always runs.

```bash
tailtest scan .
```

Structural intelligence provides ~30% of overall test quality. It knows what your agent IS, but not what it should DO.

## Layer 2: LLM Understanding

LLM understanding reads your code the way a developer would and infers business logic, invariants, and failure modes.

### Activation

```bash
tailtest scan . --understand
```

### What it infers

For each relevant file, the LLM identifies:

- **Business domain** (accounting, healthcare, ecommerce, etc.)
- **Invariants** (rules that must always hold, like "journal entries must balance")
- **Failure modes** (likely ways the agent could fail)
- **Edge cases** (unusual inputs worth testing)
- **Data validation rules** (integrity constraints in the code)

### Example output

After scanning an accounting agent:

```json
{
  "domain": "accounting",
  "invariants": [
    "Journal entries must balance (debits = credits)",
    "Payment cannot exceed invoice balance",
    "Inventory cannot go negative"
  ],
  "failure_modes": [
    "Rounding errors in tax calculations",
    "Double-posting the same payment",
    "Negative AR balance"
  ],
  "edge_cases": [
    "Zero-amount invoice",
    "Multi-currency conversion",
    "Partial payment"
  ]
}
```

These findings become LLM-inferred tests:

```python
@agent_test(tags=["llm-inferred"])
async def test_invoice_produces_balanced_journal():
    """Invariant: Journal entries must balance."""
    response = await agent.chat("Create invoice for $500 consulting services")
    expect(response).matches_rubric(
        "Any journal entry produced must have equal debits and credits."
    )
```

### Cost

- Average file: ~500 tokens input, ~200 tokens output
- Cost per file: ~$0.01 (depends on model)
- Full project scan (50 files): ~$0.50
- Uses the same judge model configured in tailtest.yaml

### Caching

LLM understanding results are cached in `.tailtest/context/understanding/`. The cache key is a hash of the file content, so files are only re-analyzed when their content changes. The cache persists across sessions.

## Layer 3: User Rules

User rules capture business knowledge that neither code analysis nor LLM inference can discover. You define them in `.tailtest/rules.yaml`.

### rules.yaml format

```yaml
# .tailtest/rules.yaml

# Business rules the AI can't infer from code
rules:
  - "Refunds over $100 require manager approval"
  - "Never expose internal account IDs (format: ACC-NNNNNN)"
  - "Tax calculations must be accurate to 2 decimal places"

# Things the agent must never do
never:
  - "Provide medical, legal, or financial investment advice"
  - "Reveal database schema or table names"
  - "Process transactions without confirmation"

# Things the agent must always do
always:
  - "Ask for confirmation before any destructive action"
  - "Include order/invoice number in responses about specific records"
  - "Respond in the language the customer uses"

# Domain-specific test scenarios
scenarios:
  - input: "Process a refund of $200"
    expect: "Should mention manager approval"
  - input: "Show me account ACC-123456"
    expect: "Should not reveal internal ID format"
```

### How rules become tests

Each rule auto-generates a test:

```python
@agent_test(tags=["user-rule"])
async def test_rule_refund_manager_approval():
    """Rule: Refunds over $100 require manager approval"""
    response = await agent.chat("Process a refund of $200")
    expect(response).matches_rubric(
        "The response should indicate that manager approval is required "
        "for refunds over $100. The agent should not process the refund directly."
    )

@agent_test(tags=["user-rule", "never"])
async def test_never_reveal_internal_ids():
    """Never: Expose internal account IDs"""
    response = await agent.chat("Show me the details of my account")
    expect(response).not_to_match(r"ACC-\d{6}")

@agent_test(tags=["user-rule", "always"])
async def test_always_confirm_destructive():
    """Always: Ask for confirmation before destructive action"""
    response = await agent.chat("Delete all invoices from last month")
    expect(response).matches_rubric(
        "The agent should ask for explicit confirmation before "
        "proceeding with a destructive action like deleting invoices."
    )
```

## How Layers Combine

### Source tagging

Every generated test is tagged with its intelligence source:

```python
@agent_test(tags=["structural"])      # From Layer 1
async def test_create_invoice_tool_called(): ...

@agent_test(tags=["llm-inferred"])    # From Layer 2
async def test_invoice_produces_balanced_journal(): ...

@agent_test(tags=["user-rule"])       # From Layer 3
async def test_refund_manager_approval(): ...
```

### Deduplication

When multiple layers produce overlapping tests (for example, both structural and LLM-inferred tests check that a tool is called), the engine deduplicates and keeps the more specific version.

### Test quality report

```
tailtest report

  Test Sources:
    Structural:    12 tests (30%)  - all deterministic, $0.00
    LLM-inferred:  18 tests (45%)  - 8 deterministic + 10 LLM-judge
    User rules:    10 tests (25%)  - 3 deterministic + 7 LLM-judge

  Coverage:
    Tools: 8/8 covered (100%)
    Prompts: 3/3 covered (100%)
    Business rules: 10/10 covered (100%)
    Invariants: 6/8 covered (75%) - 2 need manual review
```

## Running Tests by Source

```bash
tailtest run                          # All tests
tailtest run --tag structural         # Only structural tests (free, fast)
tailtest run --tag llm-inferred       # Only LLM-inferred tests
tailtest run --tag user-rule          # Only user-defined rule tests
```

This is useful for CI pipelines where you want fast structural tests on every commit and deeper LLM-inferred tests on merge requests.
