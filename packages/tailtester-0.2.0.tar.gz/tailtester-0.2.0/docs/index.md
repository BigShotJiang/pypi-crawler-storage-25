# tailtest Documentation

**The pytest for AI agents.**

tailtest auto-generates and runs tests for any AI agent, from any framework, with any model, at any stage of development.

## Quick Install

```bash
pip install tailtester
tailtest scan .
tailtest run
```

## What's Inside

- **[Quick Start](guide/quickstart.md)** - Get up and running in 5 minutes
- **[Writing Tests](guide/writing-tests.md)** - How to write agent tests with the expect() API
- **[Assertions Reference](guide/assertions-reference.md)** - All 22 assertion types
- **[Red-Teaming](guide/red-teaming.md)** - 64 adversarial attacks, OWASP compliance
- **[Production Monitoring](guide/production-monitoring.md)** - Guard, ingest, drift detection
- **[CI/CD Integration](guide/ci-cd-integration.md)** - GitHub Actions, GitLab CI

## Framework Guides

- **[LangChain](guide/frameworks/langchain.md)**
- **[CrewAI](guide/frameworks/crewai.md)**
- **[OpenAI](guide/frameworks/openai.md)**
- **[PydanticAI](guide/frameworks/pydantic-ai.md)**
