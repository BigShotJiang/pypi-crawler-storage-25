"""Shared fixtures for dogfood tests  -  tailtest testing itself."""

from __future__ import annotations

import pytest

from tailtest.models import AgentResponse
from tailtest.mcp.server import TailtestMCPServer


# ---------------------------------------------------------------------------
# LLM availability check
# ---------------------------------------------------------------------------

def _llm_available() -> bool:
    """Check whether litellm is installed and importable."""
    try:
        import litellm  # noqa: F401
        return True
    except ImportError:
        return False


requires_litellm = pytest.mark.skipif(
    not _llm_available(),
    reason="litellm not installed  -  skipping live LLM test",
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mcp_server() -> TailtestMCPServer:
    """A fresh MCP server instance for tool-level testing."""
    return TailtestMCPServer()


@pytest.fixture
def safe_response() -> AgentResponse:
    """A perfectly safe agent response with no PII or issues."""
    return AgentResponse(
        content="The weather today is sunny with a high of 72F.",
        latency_ms=120.0,
        cost_usd=0.002,
        metadata={"prompt": "What is the weather?"},
    )


@pytest.fixture
def unsafe_pii_response() -> AgentResponse:
    """An agent response that leaks PII (email and SSN)."""
    return AgentResponse(
        content=(
            "Sure! The customer's email is jane.doe@example.com "
            "and their SSN is 123-45-6789."
        ),
        latency_ms=100.0,
        cost_usd=0.002,
        metadata={"prompt": "What are the customer details?"},
    )


@pytest.fixture
def hallucination_response() -> AgentResponse:
    """An agent response containing fabricated facts."""
    return AgentResponse(
        content=(
            "Python was invented in 1642 by Sir Isaac Newton "
            "as part of his work on calculus."
        ),
        latency_ms=200.0,
        cost_usd=0.003,
        metadata={"prompt": "Who created Python?"},
    )


@pytest.fixture
def code_suggestion_input() -> str:
    """Input for the MCP suggest_test tool: a description mentioning tools."""
    return (
        "An agent that looks up weather data using a tool called "
        "get_weather and returns a summary. It should not leak PII."
    )


@pytest.fixture
def failure_error_timeout() -> dict[str, str]:
    """Error context for explain_failure: a timeout scenario."""
    return {
        "test_name": "test_weather_lookup",
        "error_message": "TimeoutError: agent did not respond within 30000ms",
    }


@pytest.fixture
def failure_error_pii() -> dict[str, str]:
    """Error context for explain_failure: a PII leak scenario."""
    return {
        "test_name": "test_no_pii_leak",
        "error_message": "PII detected: email address found in response",
    }
