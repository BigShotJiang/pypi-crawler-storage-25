"""Dogfooding: tailtest scans and tests itself.

Uses tailtest's scan, generate, and run capabilities against
the tailtest codebase itself to verify the pipeline works end-to-end.
"""

from __future__ import annotations

from pathlib import Path

from tailtest.context.engine import ContextEngine
from tailtest.context.sources.scanner import scan_project
from tailtest.generator.engine import TestGenerator
from tailtest.models import ScanResult

# The tailtest source tree root (what we are scanning)
_TAILTEST_SRC = Path(__file__).resolve().parents[2] / "src" / "tailtest"
_REPO_ROOT = Path(__file__).resolve().parents[2]


# ---------------------------------------------------------------------------
# Test 1: tailtest scan detects its own framework usage (litellm)
# ---------------------------------------------------------------------------

class TestScanSelf:
    async def test_scan_detects_litellm(self):
        """Scanning the repo root should detect litellm as a dependency."""
        # Scan from the repo root so pyproject.toml / requirements are found
        result = await scan_project(_REPO_ROOT)

        assert isinstance(result, ScanResult)
        # tailtest uses litellm  -  scanner should find it in deps from pyproject
        all_deps = [d.lower() for d in result.dependencies]
        assert any("litellm" in d for d in all_deps), (
            f"Expected litellm in dependencies, got: {result.dependencies}"
        )

    async def test_scan_finds_prompts(self):
        """Scanning tailtest source should find system prompts (judge rubrics, etc.)."""
        result = await scan_project(_TAILTEST_SRC)

        assert isinstance(result, ScanResult)
        # tailtest has several prompt strings (judge system prompt, rubrics)
        # The scanner should find at least some of them
        assert isinstance(result.prompts, list)

    async def test_scan_finds_tools(self):
        """Scanning tailtest source should find tool definitions."""
        result = await scan_project(_TAILTEST_SRC)

        assert isinstance(result, ScanResult)
        assert isinstance(result.tools, list)

    async def test_scan_returns_models(self):
        """Scanning tailtest should detect model references (e.g. ollama/llama3.2)."""
        result = await scan_project(_TAILTEST_SRC)

        assert isinstance(result, ScanResult)
        assert isinstance(result.models, list)


# ---------------------------------------------------------------------------
# Test 2: tailtest generate creates tests for its own code
# ---------------------------------------------------------------------------

class TestGenerateSelf:
    async def test_generate_from_own_scan(self, tmp_path):
        """Test generator should produce test files from tailtest's own scan."""
        # Scan ourselves
        result = await scan_project(_TAILTEST_SRC)

        # Generate tests into a temp directory
        output_dir = tmp_path / "generated_tests"
        output_dir.mkdir()

        generator = TestGenerator()
        generated = await generator.generate(
            result, output_dir, regenerate=True
        )

        # Should produce at least a safety test file (always generated)
        assert isinstance(generated, list)
        if generated:
            # Verify all generated paths are real files
            for path in generated:
                assert path.exists(), f"Generated file does not exist: {path}"
                assert path.suffix == ".py"


# ---------------------------------------------------------------------------
# Test 3: tailtest run executes its own generated tests
# ---------------------------------------------------------------------------

class TestRunSelf:
    async def test_runner_discovers_own_tests(self):
        """TestRunner's discovery should find tests in the dogfood test dir."""
        test_dir = Path(__file__).resolve().parent

        # We do not run ourselves (that would cause infinite recursion).
        # Instead we verify the discovery layer can find and enumerate
        # test files in this directory without crashing.
        from tailtest.runner.discovery import _find_test_files

        files = _find_test_files(test_dir)
        assert isinstance(files, list)
        # Should find at least this file and test_judge_with_tailtest.py
        assert len(files) >= 2

        # All discovered files should be actual Python test files
        for f in files:
            assert f.exists()
            assert f.suffix == ".py"
            assert f.name.startswith("test_") or f.name.endswith("_test.py")


# ---------------------------------------------------------------------------
# Test 4: tailtest report generates a report for its own test run
# ---------------------------------------------------------------------------

class TestReportSelf:
    async def test_json_report_from_suite_result(self):
        """JSONReporter should generate valid JSON from a TestSuiteResult."""
        from datetime import datetime, timezone

        from tailtest.models import (
            AgentResponse,
            AssertionResult,
            TestCase,
            TestResult,
            TestSuiteResult,
        )
        from tailtest.reporting.json_report import JSONReporter

        # Build a minimal suite result as if we ran our own tests
        test_case = TestCase(
            name="test_dogfood_example",
            input="Is tailtest working?",
            assertions=["contains"],
        )
        assertion_result = AssertionResult(
            passed=True,
            assertion_type="contains",
            expected="working",
            actual="Yes, tailtest is working.",
            message="Contains check passed",
        )
        test_result = TestResult(
            test_case=test_case,
            passed=True,
            assertion_results=[assertion_result],
            agent_response=AgentResponse(
                content="Yes, tailtest is working.",
                latency_ms=50.0,
                cost_usd=0.001,
            ),
            duration_ms=100.0,
            cost_usd=0.001,
            timestamp=datetime.now(tz=timezone.utc),
        )
        suite = TestSuiteResult(
            total=1,
            passed=1,
            failed=0,
            skipped=0,
            duration_ms=100.0,
            total_cost_usd=0.001,
            results=[test_result],
        )

        reporter = JSONReporter()
        output = reporter.generate(suite)

        assert isinstance(output, str)
        # Should be valid JSON
        import json
        data = json.loads(output)
        assert data["total"] == 1
        assert data["passed"] == 1
        assert data["failed"] == 0

    async def test_terminal_report_does_not_crash(self):
        """TerminalReporter.report() should not crash on a valid suite."""
        from datetime import datetime, timezone

        from tailtest.models import (
            AgentResponse,
            AssertionResult,
            TestCase,
            TestResult,
            TestSuiteResult,
        )
        from tailtest.reporting.terminal import TerminalReporter

        test_case = TestCase(
            name="test_dogfood_terminal",
            input="Test input",
            assertions=["contains"],
        )
        assertion_result = AssertionResult(
            passed=True,
            assertion_type="contains",
            expected="working",
            actual="working",
            message="Contains check passed",
        )
        test_result = TestResult(
            test_case=test_case,
            passed=True,
            assertion_results=[assertion_result],
            agent_response=AgentResponse(
                content="working",
                latency_ms=50.0,
                cost_usd=0.001,
            ),
            duration_ms=100.0,
            cost_usd=0.001,
            timestamp=datetime.now(tz=timezone.utc),
        )
        suite = TestSuiteResult(
            total=1,
            passed=1,
            failed=0,
            skipped=0,
            duration_ms=100.0,
            total_cost_usd=0.001,
            results=[test_result],
        )

        # Should not raise
        reporter = TerminalReporter()
        reporter.report(suite)


# ---------------------------------------------------------------------------
# Test 5: tailtest watch detects changes in its own codebase
# ---------------------------------------------------------------------------

class TestWatchSelf:
    def test_watch_config_accepts_tailtest_paths(self):
        """The watch/file-watcher config should accept the tailtest source path."""
        from tailtest.config.schema import TestingConfig

        config = TestingConfig()
        # Ensure the config can be instantiated and has a timeout
        assert config.timeout_ms > 0

    async def test_context_engine_scan_roundtrip(self, tmp_path):
        """ContextEngine scan + save + load roundtrip on tailtest source."""
        engine = ContextEngine()
        result = await engine.scan(_TAILTEST_SRC)

        assert isinstance(result, ScanResult)
        assert result.framework is not None

        # Save and verify the output file exists
        engine.save_context(result, tmp_path)
        scan_file = tmp_path / ".tailtest" / "context" / "scan.json"
        assert scan_file.exists(), f"Expected scan file at {scan_file}"

        # Load it back
        from tailtest.context.store import load_scan

        loaded = load_scan(tmp_path)
        assert loaded is not None
        assert loaded.framework == result.framework
