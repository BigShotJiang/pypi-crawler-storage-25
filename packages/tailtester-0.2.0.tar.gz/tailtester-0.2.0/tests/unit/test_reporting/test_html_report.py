"""Tests for HTML report generation  -  self-contained, dark-themed reports with SVG charts."""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from tailtest.production.failure_detector import DriftAlert
from tailtest.reporting.aggregator import FlakyTest, TrendPoint, TrendReport
from tailtest.reporting.html_report import HTMLReportGenerator


# ── Fixtures ──────────────────────────────────────────────────────────────────


def _make_trend(
    num_points: int = 3,
    flaky: bool = True,
    new_failures: bool = True,
    fixed: bool = True,
) -> TrendReport:
    """Build a TrendReport for testing."""
    now = datetime.now(timezone.utc)
    points = [
        TrendPoint(
            timestamp=now - timedelta(days=num_points - 1 - i),
            pass_rate=80.0 + i * 5.0,
            total_tests=10,
            passed=8 + i,
            failed=2 - min(i, 2),
            cost_usd=0.04 + i * 0.01,
            duration_ms=400.0 + i * 50,
        )
        for i in range(num_points)
    ]

    flaky_tests = (
        [FlakyTest(name="test_flaky_one", total_runs=10, pass_count=7, fail_count=3, flake_rate=60.0)]
        if flaky else []
    )
    failures = ["test_newly_broken"] if new_failures else []
    fixed_tests = ["test_just_fixed"] if fixed else []

    return TrendReport(
        points=points,
        period="test",
        flaky_tests=flaky_tests,
        new_failures=failures,
        fixed_tests=fixed_tests,
        avg_pass_rate=sum(p.pass_rate for p in points) / len(points) if points else 0.0,
        avg_cost=sum(p.cost_usd for p in points) / len(points) if points else 0.0,
        total_runs=len(points),
    )


def _empty_trend() -> TrendReport:
    return TrendReport(
        points=[],
        period="empty",
        flaky_tests=[],
        new_failures=[],
        fixed_tests=[],
        avg_pass_rate=0.0,
        avg_cost=0.0,
        total_runs=0,
    )


# ── Tests ─────────────────────────────────────────────────────────────────────


class TestHTMLReportGeneration:
    def test_html_contains_doctype(self):
        """Report must start with <!DOCTYPE html>."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend())
        assert html.strip().startswith("<!DOCTYPE html>")

    def test_html_contains_summary_cards(self):
        """Report should include summary cards for Total Runs, Pass Rate, etc."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend())
        assert "Total Runs" in html
        assert "Avg Pass Rate" in html
        assert "Avg Cost" in html
        assert "Total Tests" in html
        assert 'class="cards"' in html

    def test_html_contains_svg_chart(self):
        """Report should include at least one SVG chart element."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend())
        assert "<svg" in html
        assert "viewBox" in html
        assert "polyline" in html or "rect" in html

    def test_html_handles_empty_trend(self):
        """HTML report should not crash with an empty TrendReport."""
        gen = HTMLReportGenerator()
        html = gen.generate(_empty_trend())
        assert "<!DOCTYPE html>" in html
        assert "No data" in html
        assert "Total Runs" in html

    def test_html_includes_flaky_tests(self):
        """Flaky tests section should appear when there are flaky tests."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend(flaky=True))
        assert "Flaky Tests" in html
        assert "test_flaky_one" in html

    def test_html_no_flaky_section_when_empty(self):
        """Flaky tests section should be absent when there are no flaky tests."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend(flaky=False))
        assert "Flaky Tests" not in html

    def test_html_includes_drift_alerts(self):
        """Drift alerts section renders with severity badges."""
        gen = HTMLReportGenerator()
        alerts = [
            DriftAlert(
                metric_name="latency",
                baseline_value=100.0,
                current_value=400.0,
                threshold=2.0,
                severity="critical",
                message="Latency 4x baseline",
            ),
        ]
        html = gen.generate(_make_trend(), drift_alerts=alerts)
        assert "Drift Alerts" in html
        assert "CRITICAL" in html
        assert "Latency 4x baseline" in html

    def test_html_file_write(self, tmp_path: Path):
        """write() should create a file on disk with valid HTML."""
        gen = HTMLReportGenerator()
        out = tmp_path / "report.html"
        result = gen.write(_make_trend(), out)

        assert result == out
        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content
        assert len(content) > 500  # non-trivial file

    def test_html_self_contained_no_external_urls(self):
        """HTML report must not reference external stylesheets or scripts."""
        gen = HTMLReportGenerator()
        html = gen.generate(_make_trend())
        # Should not have <link rel="stylesheet" href="http...">
        assert 'href="http' not in html
        assert 'src="http' not in html
        # CSS should be inline
        assert "<style>" in html

    def test_html_write_creates_parent_dirs(self, tmp_path: Path):
        """write() should create intermediate directories."""
        gen = HTMLReportGenerator()
        out = tmp_path / "nested" / "dir" / "report.html"
        gen.write(_make_trend(), out)
        assert out.exists()

    def test_html_includes_period_label(self):
        """Report title bar should show the period."""
        gen = HTMLReportGenerator()
        trend = _make_trend()
        html = gen.generate(trend)
        assert "Test" in html  # period is "test", capitalized to "Test"
