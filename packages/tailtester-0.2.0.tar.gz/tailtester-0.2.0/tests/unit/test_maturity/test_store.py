"""Tests for the maturity store  -  save/load round-trip and schema validation."""

import json

import pytest

from tailtest.maturity.store import (
    CalibratedThreshold,
    FailurePattern,
    LevelTransitions,
    MaturityState,
    MaturityStats,
    MaturityStore,
    TestProfile,
)


# ---------------------------------------------------------------------------
# Round-trip persistence
# ---------------------------------------------------------------------------


def test_save_load_roundtrip(tmp_path):
    path = tmp_path / ".tailtest" / "maturity.json"
    store = MaturityStore(path)

    state = MaturityState(
        level="growing",
        stats=MaturityStats(total_runs=25, total_tests_executed=100),
        test_profiles={
            "test_hello": TestProfile(runs=25, passes=24, fails=1, avg_latency_ms=100),
        },
    )
    store.save(state)
    loaded = store.load()

    assert loaded.level == "growing"
    assert loaded.stats.total_runs == 25
    assert loaded.stats.total_tests_executed == 100
    assert "test_hello" in loaded.test_profiles
    assert loaded.test_profiles["test_hello"].runs == 25


def test_save_creates_parent_dirs(tmp_path):
    path = tmp_path / "deep" / "nested" / "maturity.json"
    store = MaturityStore(path)
    store.save(MaturityState())
    assert path.exists()


def test_load_nonexistent_returns_defaults(tmp_path):
    path = tmp_path / "nonexistent" / "maturity.json"
    store = MaturityStore(path)
    state = store.load()
    assert state.level == "seedling"
    assert state.stats.total_runs == 0


def test_load_corrupt_file_returns_defaults(tmp_path):
    path = tmp_path / "maturity.json"
    path.write_text("not valid json", encoding="utf-8")
    store = MaturityStore(path)
    state = store.load()
    assert state.level == "seedling"
    assert state.stats.total_runs == 0


# ---------------------------------------------------------------------------
# State model defaults
# ---------------------------------------------------------------------------


def test_default_state():
    state = MaturityState()
    assert state.level == "seedling"
    assert state.stats.total_runs == 0
    assert state.calibrated_thresholds == {}
    assert state.failure_patterns == {}
    assert state.test_profiles == {}


def test_calibrated_threshold_model():
    ct = CalibratedThreshold(default=0.05, calibrated=0.012)
    assert ct.default == 0.05
    assert ct.calibrated == 0.012
    assert ct.observed_p50 is None


def test_failure_pattern_model():
    fp = FailurePattern(count=5, triggers=["bad query"])
    assert fp.count == 5
    assert fp.triggers == ["bad query"]
    assert fp.affected_tests == []


def test_test_profile_model():
    tp = TestProfile(runs=10, passes=8, fails=2, flaky=True, flake_rate=0.2)
    assert tp.runs == 10
    assert tp.flaky is True
    assert tp.flake_rate == 0.2


# ---------------------------------------------------------------------------
# JSON schema compatibility
# ---------------------------------------------------------------------------


def test_roundtrip_with_all_fields(tmp_path):
    path = tmp_path / "maturity.json"
    store = MaturityStore(path)

    state = MaturityState(
        level="growing",
        stats=MaturityStats(
            total_runs=47,
            total_tests_executed=1034,
            unique_test_names=22,
            unique_failures_seen=12,
        ),
        calibrated_thresholds={
            "cost_usd": CalibratedThreshold(
                default=0.05,
                calibrated=0.012,
                observed_p50=0.003,
                observed_p95=0.008,
            ),
            "latency_ms": CalibratedThreshold(
                default=3000.0,
                calibrated=510.0,
                observed_p50=180.0,
                observed_p95=340.0,
            ),
        },
        failure_patterns={
            "hallucination": FailurePattern(
                count=8,
                triggers=["unknown product query"],
                affected_tests=["test_no_price_hallucination"],
            ),
        },
        test_profiles={
            "test_greeting": TestProfile(runs=47, passes=47, fails=0),
            "test_flaky": TestProfile(runs=47, passes=44, fails=3, flaky=True, flake_rate=0.064),
        },
    )

    store.save(state)
    loaded = store.load()

    assert loaded.calibrated_thresholds["cost_usd"].calibrated == 0.012
    assert loaded.failure_patterns["hallucination"].count == 8
    assert loaded.test_profiles["test_flaky"].flaky is True
