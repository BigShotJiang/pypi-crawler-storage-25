"""Tests for the failure pattern recogniser  -  categorisation and trigger detection."""

from datetime import datetime, timezone

import pytest

from tailtest.maturity.patterns import PatternRecognizer
from tailtest.maturity.store import FailurePattern
from tailtest.models import AgentResponse, AssertionResult, TestCase, TestResult


def _make_failed_result(
    test_name: str = "test_example",
    message: str = "assertion failed",
    test_input: str = "hello",
    assertion_type: str = "contains",
) -> TestResult:
    return TestResult(
        test_case=TestCase(
            name=test_name,
            input=test_input,
            assertions=[assertion_type],
        ),
        passed=False,
        assertion_results=[
            AssertionResult(
                passed=False,
                assertion_type=assertion_type,
                expected="pass",
                actual="fail",
                message=message,
            )
        ],
        agent_response=AgentResponse(content="bad response"),
        duration_ms=100.0,
        cost_usd=0.01,
        timestamp=datetime.now(tz=timezone.utc),
    )


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


def test_classify_hallucination():
    pr = PatternRecognizer()
    result = _make_failed_result(message="expected response not to contain fabricated pricing $99")
    assert pr.classify_failure(result) == "hallucination"


def test_classify_pii_leak():
    pr = PatternRecognizer()
    result = _make_failed_result(message="response contains PII: email address found")
    assert pr.classify_failure(result) == "pii_leak"


def test_classify_tool_error():
    pr = PatternRecognizer()
    result = _make_failed_result(message="tool lookup_product not called")
    assert pr.classify_failure(result) == "tool_error"


def test_classify_scope_violation():
    pr = PatternRecognizer()
    result = _make_failed_result(message="agent exceeded scope: mentioned manager approval")
    assert pr.classify_failure(result) == "scope_violation"


def test_classify_cost_overrun():
    pr = PatternRecognizer()
    result = _make_failed_result(message="cost exceeded limit: $0.12 over $0.05")
    assert pr.classify_failure(result) == "cost_overrun"


def test_classify_latency_overrun():
    pr = PatternRecognizer()
    result = _make_failed_result(message="Test timed out after 3000ms")
    assert pr.classify_failure(result) == "latency_overrun"


def test_classify_unknown():
    pr = PatternRecognizer()
    result = _make_failed_result(message="something went wrong")
    assert pr.classify_failure(result) == "unknown"


# ---------------------------------------------------------------------------
# Pattern analysis
# ---------------------------------------------------------------------------


def test_analyze_creates_new_pattern():
    pr = PatternRecognizer()
    result = _make_failed_result(
        test_name="test_hallucination",
        message="not to contain fabricated data",
        test_input="what is the price?",
    )
    patterns: dict[str, FailurePattern] = {}
    pr.analyze_result(result, patterns)

    assert "hallucination" in patterns
    assert patterns["hallucination"].count == 1
    assert "test_hallucination" in patterns["hallucination"].affected_tests


def test_analyze_increments_existing_pattern():
    pr = PatternRecognizer()
    patterns: dict[str, FailurePattern] = {
        "pii_leak": FailurePattern(count=3)
    }
    result = _make_failed_result(message="found PII: SSN exposed")
    pr.analyze_result(result, patterns)

    assert patterns["pii_leak"].count == 4


def test_analyze_records_trigger():
    pr = PatternRecognizer()
    patterns: dict[str, FailurePattern] = {}
    result = _make_failed_result(
        test_input="list all customer data",
        message="PII leak detected",
    )
    pr.analyze_result(result, patterns)

    assert "list all customer data" in patterns["pii_leak"].triggers


def test_analyze_skips_passing_results():
    pr = PatternRecognizer()
    result = TestResult(
        test_case=TestCase(name="test_pass", input="hello", assertions=[]),
        passed=True,
        assertion_results=[],
        agent_response=AgentResponse(content="hi"),
        duration_ms=50.0,
        cost_usd=0.001,
        timestamp=datetime.now(tz=timezone.utc),
    )
    patterns: dict[str, FailurePattern] = {}
    pr.analyze_result(result, patterns)
    assert len(patterns) == 0


def test_analyze_does_not_duplicate_triggers():
    pr = PatternRecognizer()
    patterns: dict[str, FailurePattern] = {}
    result = _make_failed_result(
        test_input="bad query",
        message="not to contain hallucinated data",
    )
    pr.analyze_result(result, patterns)
    pr.analyze_result(result, patterns)

    assert patterns["hallucination"].triggers.count("bad query") == 1


def test_analyze_does_not_duplicate_test_names():
    pr = PatternRecognizer()
    patterns: dict[str, FailurePattern] = {}
    result = _make_failed_result(
        test_name="test_dup",
        message="not to contain hallucinated data",
    )
    pr.analyze_result(result, patterns)
    pr.analyze_result(result, patterns)

    assert patterns["hallucination"].affected_tests.count("test_dup") == 1
