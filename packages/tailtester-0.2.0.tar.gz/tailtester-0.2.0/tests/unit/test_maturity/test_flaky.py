"""Tests for the flaky test detector."""

import pytest

from tailtest.maturity.flaky import FlakyDetector, FlakyTestInfo, MIN_RUNS_FOR_FLAKY
from tailtest.maturity.store import TestProfile


def _make_profile(runs: int, passes: int, fails: int) -> TestProfile:
    return TestProfile(runs=runs, passes=passes, fails=fails)


# ---------------------------------------------------------------------------
# Flake rate computation
# ---------------------------------------------------------------------------


def test_flake_rate_all_pass():
    detector = FlakyDetector()
    profile = _make_profile(10, 10, 0)
    assert detector.compute_flake_rate(profile) == 0.0


def test_flake_rate_all_fail():
    detector = FlakyDetector()
    profile = _make_profile(10, 0, 10)
    assert detector.compute_flake_rate(profile) == 0.0


def test_flake_rate_fifty_fifty():
    detector = FlakyDetector()
    profile = _make_profile(10, 5, 5)
    assert detector.compute_flake_rate(profile) == 0.5


def test_flake_rate_one_failure():
    detector = FlakyDetector()
    profile = _make_profile(10, 9, 1)
    assert detector.compute_flake_rate(profile) == pytest.approx(0.1)


def test_flake_rate_zero_runs():
    detector = FlakyDetector()
    profile = _make_profile(0, 0, 0)
    assert detector.compute_flake_rate(profile) == 0.0


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------


def test_detect_identifies_flaky_test():
    detector = FlakyDetector()
    profiles = {
        "test_flaky": _make_profile(10, 8, 2),
        "test_stable": _make_profile(10, 10, 0),
    }
    flaky = detector.detect(profiles)
    assert len(flaky) == 1
    assert flaky[0].name == "test_flaky"
    assert flaky[0].flake_rate == pytest.approx(0.2)


def test_detect_skips_tests_with_few_runs():
    detector = FlakyDetector()
    profiles = {
        "test_new": _make_profile(2, 1, 1),
    }
    flaky = detector.detect(profiles)
    assert len(flaky) == 0


def test_detect_skips_all_pass():
    detector = FlakyDetector()
    profiles = {
        "test_rock_solid": _make_profile(100, 100, 0),
    }
    flaky = detector.detect(profiles)
    assert len(flaky) == 0


def test_detect_skips_all_fail():
    detector = FlakyDetector()
    profiles = {
        "test_always_broken": _make_profile(20, 0, 20),
    }
    flaky = detector.detect(profiles)
    assert len(flaky) == 0


def test_detect_sorted_by_flake_rate():
    detector = FlakyDetector()
    profiles = {
        "test_mild": _make_profile(10, 9, 1),
        "test_severe": _make_profile(10, 5, 5),
    }
    flaky = detector.detect(profiles)
    assert len(flaky) == 2
    assert flaky[0].name == "test_severe"
    assert flaky[1].name == "test_mild"


# ---------------------------------------------------------------------------
# Profile update
# ---------------------------------------------------------------------------


def test_update_profiles_sets_flaky_flag():
    detector = FlakyDetector()
    profiles = {
        "test_ok": _make_profile(10, 10, 0),
        "test_bad": _make_profile(10, 7, 3),
    }
    detector.update_profiles(profiles)

    assert profiles["test_ok"].flaky is False
    assert profiles["test_bad"].flaky is True
    assert profiles["test_bad"].flake_rate == pytest.approx(0.3)


def test_update_profiles_clears_flaky_flag_for_insufficient_runs():
    detector = FlakyDetector()
    profiles = {
        "test_new": _make_profile(2, 1, 1),
    }
    # Pre-set flaky
    profiles["test_new"].flaky = True
    profiles["test_new"].flake_rate = 0.5

    detector.update_profiles(profiles)
    assert profiles["test_new"].flaky is False
    assert profiles["test_new"].flake_rate == 0.0
