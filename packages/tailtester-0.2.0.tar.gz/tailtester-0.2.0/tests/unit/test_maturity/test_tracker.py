"""Tests for the maturity tracker  -  level transitions and run counting."""

import pytest

from tailtest.maturity.store import LevelTransitions, MaturityState, MaturityStats
from tailtest.maturity.tracker import (
    GROWING_MIN_RUNS,
    MATURE_MIN_RUNS,
    MaturityLevel,
    MaturityTracker,
)


# ---------------------------------------------------------------------------
# Level computation
# ---------------------------------------------------------------------------


def test_seedling_at_zero_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(0) == MaturityLevel.SEEDLING


def test_seedling_at_nine_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(9) == MaturityLevel.SEEDLING


def test_growing_at_ten_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(10) == MaturityLevel.GROWING


def test_growing_at_forty_nine_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(49) == MaturityLevel.GROWING


def test_mature_at_fifty_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(50) == MaturityLevel.MATURE


def test_mature_at_hundred_runs():
    tracker = MaturityTracker()
    assert tracker.compute_level(100) == MaturityLevel.MATURE


# ---------------------------------------------------------------------------
# Level transitions
# ---------------------------------------------------------------------------


def _make_state(total_runs: int, level: str = "seedling") -> MaturityState:
    return MaturityState(
        level=level,
        stats=MaturityStats(total_runs=total_runs),
    )


def test_transition_seedling_to_growing():
    tracker = MaturityTracker()
    state = _make_state(10, "seedling")
    new_level = tracker.check_transition(state)
    assert new_level == MaturityLevel.GROWING
    assert state.level == "growing"
    assert state.level_transitions.seedling_to_growing is not None


def test_transition_growing_to_mature():
    tracker = MaturityTracker()
    state = _make_state(50, "growing")
    new_level = tracker.check_transition(state)
    assert new_level == MaturityLevel.MATURE
    assert state.level == "mature"
    assert state.level_transitions.growing_to_mature is not None


def test_no_transition_when_same_level():
    tracker = MaturityTracker()
    state = _make_state(5, "seedling")
    new_level = tracker.check_transition(state)
    assert new_level == MaturityLevel.SEEDLING
    assert state.level == "seedling"
    assert state.level_transitions.seedling_to_growing is None


def test_jump_seedling_to_mature():
    tracker = MaturityTracker()
    state = _make_state(60, "seedling")
    new_level = tracker.check_transition(state)
    assert new_level == MaturityLevel.MATURE
    assert state.level_transitions.seedling_to_growing is not None
    assert state.level_transitions.growing_to_mature is not None


# ---------------------------------------------------------------------------
# Runs to next level
# ---------------------------------------------------------------------------


def test_runs_to_next_from_seedling():
    tracker = MaturityTracker()
    state = _make_state(3, "seedling")
    assert tracker.runs_to_next_level(state) == 7


def test_runs_to_next_from_growing():
    tracker = MaturityTracker()
    state = _make_state(30, "growing")
    assert tracker.runs_to_next_level(state) == 20


def test_runs_to_next_from_mature():
    tracker = MaturityTracker()
    state = _make_state(100, "mature")
    assert tracker.runs_to_next_level(state) is None


# ---------------------------------------------------------------------------
# MaturityLevel comparison operators
# ---------------------------------------------------------------------------


def test_level_ordering():
    assert MaturityLevel.SEEDLING < MaturityLevel.GROWING
    assert MaturityLevel.GROWING < MaturityLevel.MATURE
    assert MaturityLevel.MATURE > MaturityLevel.SEEDLING
    assert MaturityLevel.GROWING >= MaturityLevel.GROWING
    assert MaturityLevel.SEEDLING <= MaturityLevel.MATURE
