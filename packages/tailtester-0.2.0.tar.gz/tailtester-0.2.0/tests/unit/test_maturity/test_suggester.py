"""Tests for the test suggester  -  suggestion generation from failure patterns."""

import pytest

from tailtest.maturity.store import FailurePattern
from tailtest.maturity.suggester import TestSuggester, TestSuggestion, _slug


# ---------------------------------------------------------------------------
# Slug generation
# ---------------------------------------------------------------------------


def test_slug_simple():
    assert _slug("hello world") == "hello_world"


def test_slug_special_chars():
    assert _slug("list all orders!") == "list_all_orders"


def test_slug_hyphens():
    assert _slug("multi-turn") == "multi_turn"


# ---------------------------------------------------------------------------
# Suggestion generation
# ---------------------------------------------------------------------------


def _make_patterns() -> dict[str, FailurePattern]:
    return {
        "hallucination": FailurePattern(
            count=8,
            triggers=["unknown product query", "competitor mention"],
            affected_tests=["test_no_price_hallucination", "test_product_not_found"],
        ),
        "pii_leak": FailurePattern(
            count=2,
            triggers=["list all orders"],
            affected_tests=["test_no_data_leak_all_orders"],
        ),
    }


def test_suggest_returns_suggestions():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns())
    assert len(suggestions) > 0
    assert all(isinstance(s, TestSuggestion) for s in suggestions)


def test_suggest_prioritises_by_count():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns())
    # Hallucination has count=8, pii_leak has count=2
    assert suggestions[0].category == "hallucination"


def test_suggest_includes_name():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns())
    assert all(s.name for s in suggestions)


def test_suggest_includes_code():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns())
    assert all("def test_" in s.code for s in suggestions)


def test_suggest_includes_rationale():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns())
    for s in suggestions:
        assert "failure" in s.rationale.lower() or "observed" in s.rationale.lower()


def test_suggest_max_limit():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns(), max_suggestions=2)
    assert len(suggestions) <= 2


def test_suggest_empty_patterns():
    suggester = TestSuggester()
    suggestions = suggester.suggest({})
    assert len(suggestions) == 0


def test_suggest_pattern_with_no_triggers():
    suggester = TestSuggester()
    patterns = {
        "unknown": FailurePattern(
            count=5,
            triggers=[],
            affected_tests=["test_foo"],
        ),
    }
    suggestions = suggester.suggest(patterns)
    assert len(suggestions) == 1
    assert suggestions[0].triggers == ["general"]


# ---------------------------------------------------------------------------
# Test file generation
# ---------------------------------------------------------------------------


def test_generate_test_file():
    suggester = TestSuggester()
    suggestions = suggester.suggest(_make_patterns(), max_suggestions=2)
    content = suggester.generate_test_file(suggestions)

    assert "def test_" in content
    assert "Auto-generated" in content
    assert "from tailtest.assertions import expect" in content


def test_generate_test_file_empty():
    suggester = TestSuggester()
    content = suggester.generate_test_file([])
    assert "Auto-generated" in content
