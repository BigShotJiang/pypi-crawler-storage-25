"""Tests for the threshold calibrator  -  p95 computation and calibration."""

import pytest

from tailtest.maturity.calibrator import DEFAULTS, MIN_SAMPLES, ThresholdCalibrator
from tailtest.maturity.store import TestProfile


def _make_profiles(
    n: int = 15,
    latency_base: float = 200.0,
    cost_base: float = 0.003,
) -> dict[str, TestProfile]:
    """Create test profiles with enough data for calibration."""
    profiles: dict[str, TestProfile] = {}
    for i in range(n):
        profiles[f"test_{i}"] = TestProfile(
            runs=10,
            passes=9,
            fails=1,
            avg_latency_ms=latency_base + i * 10,
            avg_cost_usd=cost_base + i * 0.001,
            latency_history=[latency_base + i * 10],
            cost_history=[cost_base + i * 0.001],
        )
    return profiles


# ---------------------------------------------------------------------------
# Basic calibration
# ---------------------------------------------------------------------------


def test_calibrate_returns_both_metrics():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles()
    result = calibrator.calibrate(profiles)
    assert "latency_ms" in result
    assert "cost_usd" in result


def test_calibrated_latency_is_1_5x_p95():
    calibrator = ThresholdCalibrator()
    # 15 tests with latencies 200, 210, 220, ..., 340
    profiles = _make_profiles(15, latency_base=200.0)
    result = calibrator.calibrate(profiles)

    ct = result["latency_ms"]
    # p95 should be around 340
    assert ct.observed_p95 is not None
    assert ct.calibrated == pytest.approx(ct.observed_p95 * 1.5)


def test_calibrated_cost_is_1_5x_p95():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles(15, cost_base=0.003)
    result = calibrator.calibrate(profiles)

    ct = result["cost_usd"]
    assert ct.observed_p95 is not None
    assert ct.calibrated == pytest.approx(ct.observed_p95 * 1.5)


def test_calibration_preserves_defaults():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles()
    result = calibrator.calibrate(profiles)
    assert result["latency_ms"].default == DEFAULTS["latency_ms"]
    assert result["cost_usd"].default == DEFAULTS["cost_usd"]


# ---------------------------------------------------------------------------
# Insufficient data  -  returns defaults
# ---------------------------------------------------------------------------


def test_returns_defaults_with_too_few_samples():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles(3)  # Only 3 data points
    result = calibrator.calibrate(profiles)
    # With < MIN_SAMPLES, calibrated should equal default
    assert result["latency_ms"].calibrated == DEFAULTS["latency_ms"]
    assert result["cost_usd"].calibrated == DEFAULTS["cost_usd"]


def test_returns_defaults_with_empty_profiles():
    calibrator = ThresholdCalibrator()
    result = calibrator.calibrate({})
    assert result["latency_ms"].calibrated == DEFAULTS["latency_ms"]
    assert result["cost_usd"].calibrated == DEFAULTS["cost_usd"]


# ---------------------------------------------------------------------------
# p50 / p95 computation
# ---------------------------------------------------------------------------


def test_p50_is_median():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles(21, latency_base=100.0)
    result = calibrator.calibrate(profiles)
    ct = result["latency_ms"]
    # Median of 100, 110, 120, ..., 300 is 200
    assert ct.observed_p50 is not None
    assert ct.observed_p50 == 200.0


def test_sample_size_recorded():
    calibrator = ThresholdCalibrator()
    profiles = _make_profiles(20)
    result = calibrator.calibrate(profiles)
    assert result["latency_ms"].sample_size == 20
    assert result["cost_usd"].sample_size == 20


# ---------------------------------------------------------------------------
# Edge: zero values are excluded
# ---------------------------------------------------------------------------


def test_zero_values_excluded():
    calibrator = ThresholdCalibrator()
    profiles: dict[str, TestProfile] = {}
    for i in range(15):
        profiles[f"test_{i}"] = TestProfile(
            runs=10,
            passes=10,
            fails=0,
            avg_latency_ms=100.0 if i < 12 else 0.0,
            avg_cost_usd=0.0,  # all zero costs
            latency_history=[100.0] if i < 12 else [0.0],
            cost_history=[0.0],
        )
    result = calibrator.calibrate(profiles)
    # Cost should fall back to default since all values are zero
    assert result["cost_usd"].calibrated == DEFAULTS["cost_usd"]
