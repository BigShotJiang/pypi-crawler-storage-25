"""Tests for the FailurePredictor (Phase 7C)."""

from __future__ import annotations

import pytest

from tailtest.maturity.predictor import (
    ChangeCorrelation,
    FailurePredictor,
    PredictedFailure,
    _extract_changed_files,
    _extract_changed_lines,
    _is_prompt_sensitive,
    _is_tool_related,
)
from tailtest.maturity.store import FailurePattern, TestProfile


@pytest.fixture
def predictor():
    return FailurePredictor()


@pytest.fixture
def sample_profiles() -> dict[str, TestProfile]:
    """Test profiles with varied pass/fail histories."""
    return {
        "test_greeting": TestProfile(
            runs=50, passes=50, fails=0,
            avg_latency_ms=100, avg_cost_usd=0.001,
        ),
        "test_refund_flow": TestProfile(
            runs=50, passes=35, fails=15,
            avg_latency_ms=200, avg_cost_usd=0.005,
            failure_category="hallucination",
        ),
        "test_tool_call": TestProfile(
            runs=50, passes=40, fails=10,
            avg_latency_ms=150, avg_cost_usd=0.003,
            failure_category="tool_error",
        ),
        "test_always_fails": TestProfile(
            runs=50, passes=0, fails=50,
            avg_latency_ms=300, avg_cost_usd=0.01,
            failure_category="pii_leak",
        ),
        "test_response_quality": TestProfile(
            runs=50, passes=45, fails=5,
            flaky=True, flake_rate=0.1,
            avg_latency_ms=180, avg_cost_usd=0.008,
        ),
    }


@pytest.fixture
def prompt_diff() -> str:
    return """\
diff --git a/system_prompt.py b/system_prompt.py
--- a/system_prompt.py
+++ b/system_prompt.py
@@ -1,5 +1,5 @@
-SYSTEM_PROMPT = "You are a helpful assistant."
+SYSTEM_PROMPT = "You are a friendly assistant that handles refunds."
"""


@pytest.fixture
def tool_diff() -> str:
    return """\
diff --git a/tools/handler.py b/tools/handler.py
--- a/tools/handler.py
+++ b/tools/handler.py
@@ -10,3 +10,5 @@
 def lookup_order(order_id: str):
     return db.query(order_id)
+
+def cancel_order(order_id: str):
+    return db.cancel(order_id)
"""


@pytest.fixture
def model_diff() -> str:
    return """\
diff --git a/config.py b/config.py
--- a/config.py
+++ b/config.py
@@ -1,3 +1,3 @@
-MODEL = "gpt-4o"
+MODEL = "claude-sonnet-4-20250514"
"""


class TestExtractChangedFiles:
    def test_extracts_files_from_diff(self, prompt_diff: str):
        files = _extract_changed_files(prompt_diff)
        assert "system_prompt.py" in files

    def test_extracts_multiple_files(self):
        diff = """\
diff --git a/a.py b/a.py
--- a/a.py
+++ b/a.py
@@ -1 +1 @@
-x = 1
+x = 2
diff --git a/b.py b/b.py
--- a/b.py
+++ b/b.py
@@ -1 +1 @@
-y = 1
+y = 2
"""
        files = _extract_changed_files(diff)
        assert "a.py" in files
        assert "b.py" in files

    def test_empty_diff_returns_empty(self):
        assert _extract_changed_files("") == []


class TestExtractChangedLines:
    def test_extracts_added_lines(self, prompt_diff: str):
        lines = _extract_changed_lines(prompt_diff)
        assert any("friendly assistant" in line for line in lines)

    def test_extracts_removed_lines(self, prompt_diff: str):
        lines = _extract_changed_lines(prompt_diff)
        assert any("helpful assistant" in line for line in lines)


class TestIsPromptSensitive:
    def test_greeting_is_sensitive(self):
        profile = TestProfile(runs=10, passes=8, fails=2)
        assert _is_prompt_sensitive("test_greeting", profile) is True

    def test_tool_call_is_not_sensitive(self):
        profile = TestProfile(runs=10, passes=10, fails=0)
        assert _is_prompt_sensitive("test_tool_call", profile) is False

    def test_response_format_is_sensitive(self):
        profile = TestProfile(runs=10, passes=10, fails=0)
        assert _is_prompt_sensitive("test_response_format", profile) is True


class TestIsToolRelated:
    def test_tool_call_test(self):
        assert _is_tool_related("test_tool_call") is True

    def test_lookup_test(self):
        assert _is_tool_related("test_lookup_order") is True

    def test_greeting_not_tool(self):
        assert _is_tool_related("test_greeting") is False


class TestFailurePredictor:
    def test_empty_diff_returns_empty(self, predictor: FailurePredictor, sample_profiles: dict):
        result = predictor.predict("", sample_profiles)
        assert result == []

    def test_prompt_diff_predicts_prompt_sensitive(
        self, predictor: FailurePredictor, prompt_diff: str, sample_profiles: dict
    ):
        predictions = predictor.predict(prompt_diff, sample_profiles)
        names = [p.test_name for p in predictions]
        # test_refund_flow should appear (prompt-sensitive due to "refund" in diff)
        assert any("refund" in n or "greeting" in n or "response" in n for n in names)

    def test_tool_diff_predicts_tool_related(
        self, predictor: FailurePredictor, tool_diff: str, sample_profiles: dict
    ):
        predictions = predictor.predict(tool_diff, sample_profiles)
        names = [p.test_name for p in predictions]
        assert "test_tool_call" in names

    def test_model_diff_predicts_flaky(
        self, predictor: FailurePredictor, model_diff: str, sample_profiles: dict
    ):
        predictions = predictor.predict(model_diff, sample_profiles)
        names = [p.test_name for p in predictions]
        # Flaky tests and tests with failures should be predicted
        assert "test_response_quality" in names

    def test_always_failing_test_predicted_high(
        self, predictor: FailurePredictor, prompt_diff: str, sample_profiles: dict
    ):
        predictions = predictor.predict(prompt_diff, sample_profiles)
        always_fail = [p for p in predictions if p.test_name == "test_always_fails"]
        if always_fail:
            assert always_fail[0].confidence >= 0.9

    def test_sorted_by_confidence_descending(
        self, predictor: FailurePredictor, prompt_diff: str, sample_profiles: dict
    ):
        predictions = predictor.predict(prompt_diff, sample_profiles)
        if len(predictions) >= 2:
            for i in range(len(predictions) - 1):
                assert predictions[i].confidence >= predictions[i + 1].confidence

    def test_change_history_used(self, predictor: FailurePredictor, prompt_diff: str, sample_profiles: dict):
        history = [
            ChangeCorrelation(
                change_type="prompt",
                test_name="test_greeting",
                times_correlated=5,
                correlation_strength=0.95,
                caused_failures=True,
            )
        ]
        predictions = predictor.predict(prompt_diff, sample_profiles, change_history=history)
        greeting_pred = [p for p in predictions if p.test_name == "test_greeting"]
        assert len(greeting_pred) == 1
        assert greeting_pred[0].confidence == 0.95

    def test_failure_patterns_boost_confidence(
        self, predictor: FailurePredictor, sample_profiles: dict
    ):
        patterns = {
            "hallucination": FailurePattern(
                count=8,
                triggers=["refund"],
                affected_tests=["test_refund_flow"],
            )
        }
        # The diff content must contain the trigger word "refund" in a changed line
        diff = """\
diff --git a/prompt.py b/prompt.py
--- a/prompt.py
+++ b/prompt.py
@@ -1,3 +1,3 @@
-PROMPT = "Handle refund requests carefully"
+PROMPT = "Handle refund requests with extra validation"
"""
        predictions = predictor.predict(diff, sample_profiles, failure_patterns=patterns)
        refund_pred = [p for p in predictions if p.test_name == "test_refund_flow"]
        assert len(refund_pred) >= 1

    def test_touches_prompts(self, predictor: FailurePredictor, prompt_diff: str):
        assert predictor.touches_prompts(prompt_diff) is True

    def test_touches_tools(self, predictor: FailurePredictor, tool_diff: str):
        assert predictor.touches_tools(tool_diff) is True

    def test_touches_models(self, predictor: FailurePredictor, model_diff: str):
        assert predictor.touches_models(model_diff) is True
