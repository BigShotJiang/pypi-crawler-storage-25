"""Tests for the maturity engine  -  full integration tests."""

from datetime import datetime, timezone

import pytest

from tailtest.maturity.engine import MaturityEngine
from tailtest.maturity.store import MaturityState, TestProfile
from tailtest.maturity.tracker import MaturityLevel
from tailtest.models import (
    AgentResponse,
    AssertionResult,
    TestCase,
    TestResult,
    TestSuiteResult,
)


def _make_suite_result(
    test_names: list[str] | None = None,
    all_pass: bool = True,
    fail_message: str = "assertion failed",
    latency: float = 100.0,
    cost: float = 0.005,
) -> TestSuiteResult:
    """Create a TestSuiteResult with specified characteristics."""
    if test_names is None:
        test_names = ["test_hello", "test_goodbye"]

    results: list[TestResult] = []
    passed_count = 0
    failed_count = 0

    for i, name in enumerate(test_names):
        is_pass = all_pass or i % 2 == 0
        ar = AssertionResult(
            passed=is_pass,
            assertion_type="contains",
            expected="hello",
            actual="hello" if is_pass else "wrong",
            message="" if is_pass else fail_message,
        )
        results.append(
            TestResult(
                test_case=TestCase(name=name, input=name, assertions=["contains"]),
                passed=is_pass,
                assertion_results=[ar],
                agent_response=AgentResponse(content="hello"),
                duration_ms=latency + i * 10,
                cost_usd=cost,
                timestamp=datetime.now(tz=timezone.utc),
            )
        )
        if is_pass:
            passed_count += 1
        else:
            failed_count += 1

    return TestSuiteResult(
        total=len(results),
        passed=passed_count,
        failed=failed_count,
        skipped=0,
        duration_ms=sum(r.duration_ms for r in results),
        total_cost_usd=sum(r.cost_usd for r in results),
        results=results,
    )


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------


def test_engine_starts_at_seedling(tmp_path):
    engine = MaturityEngine(tmp_path)
    assert engine.level == MaturityLevel.SEEDLING


def test_engine_creates_store_file(tmp_path):
    engine = MaturityEngine(tmp_path)
    suite = _make_suite_result()
    engine.record_run(suite)
    assert (tmp_path / ".tailtest" / "maturity.json").exists()


# ---------------------------------------------------------------------------
# Run recording
# ---------------------------------------------------------------------------


def test_record_run_increments_total(tmp_path):
    engine = MaturityEngine(tmp_path)
    engine.record_run(_make_suite_result())
    assert engine.state.stats.total_runs == 1


def test_record_run_updates_test_profiles(tmp_path):
    engine = MaturityEngine(tmp_path)
    engine.record_run(_make_suite_result(["test_a", "test_b"]))
    assert "test_a" in engine.state.test_profiles
    assert "test_b" in engine.state.test_profiles


def test_record_multiple_runs_accumulates(tmp_path):
    engine = MaturityEngine(tmp_path)
    for _ in range(5):
        engine.record_run(_make_suite_result())
    assert engine.state.stats.total_runs == 5
    assert engine.state.test_profiles["test_hello"].runs == 5


# ---------------------------------------------------------------------------
# Level transitions
# ---------------------------------------------------------------------------


def test_transitions_to_growing_after_10_runs(tmp_path):
    engine = MaturityEngine(tmp_path)
    for _ in range(10):
        engine.record_run(_make_suite_result())
    assert engine.level == MaturityLevel.GROWING


def test_transitions_to_mature_after_50_runs(tmp_path):
    engine = MaturityEngine(tmp_path)
    for _ in range(50):
        engine.record_run(_make_suite_result())
    assert engine.level == MaturityLevel.MATURE


# ---------------------------------------------------------------------------
# Calibrated thresholds
# ---------------------------------------------------------------------------


def test_seedling_returns_default_thresholds(tmp_path):
    engine = MaturityEngine(tmp_path)
    thresholds = engine.get_calibrated_thresholds()
    assert thresholds["cost_usd"] == 0.05
    assert thresholds["latency_ms"] == 3000.0


def test_growing_returns_calibrated_thresholds(tmp_path):
    engine = MaturityEngine(tmp_path)
    for _ in range(12):
        engine.record_run(_make_suite_result(
            test_names=[f"test_{i}" for i in range(12)],
            latency=200.0,
            cost=0.003,
        ))
    assert engine.level == MaturityLevel.GROWING
    thresholds = engine.get_calibrated_thresholds()
    # Calibrated should differ from defaults
    assert "cost_usd" in thresholds
    assert "latency_ms" in thresholds


# ---------------------------------------------------------------------------
# Failure patterns
# ---------------------------------------------------------------------------


def test_failure_patterns_detected(tmp_path):
    engine = MaturityEngine(tmp_path)
    suite = _make_suite_result(
        test_names=["test_pii_a", "test_pii_b"],
        all_pass=False,
        fail_message="PII email address found in response",
    )
    engine.record_run(suite)
    assert "pii_leak" in engine.state.failure_patterns
    assert engine.state.failure_patterns["pii_leak"].count >= 1


def test_hallucination_pattern_detected(tmp_path):
    engine = MaturityEngine(tmp_path)
    suite = _make_suite_result(
        test_names=["test_hallucination_a", "test_hallucination_b"],
        all_pass=False,
        fail_message="expected response not to contain fabricated price $99",
    )
    engine.record_run(suite)
    assert "hallucination" in engine.state.failure_patterns


# ---------------------------------------------------------------------------
# Test suggestions
# ---------------------------------------------------------------------------


def test_suggest_empty_at_seedling(tmp_path):
    engine = MaturityEngine(tmp_path)
    assert engine.suggest_tests() == []


def test_suggest_returns_suggestions_at_growing(tmp_path):
    engine = MaturityEngine(tmp_path)
    # Build up to growing level with failures
    for _ in range(12):
        engine.record_run(_make_suite_result(
            test_names=[f"test_{i}" for i in range(12)],
            all_pass=False,
            fail_message="PII data leak detected",
        ))
    assert engine.level == MaturityLevel.GROWING
    suggestions = engine.suggest_tests()
    # May or may not have suggestions depending on patterns
    # At minimum the engine should not error
    assert isinstance(suggestions, list)


# ---------------------------------------------------------------------------
# Persistence across instances
# ---------------------------------------------------------------------------


def test_state_persists_across_instances(tmp_path):
    engine1 = MaturityEngine(tmp_path)
    for _ in range(10):
        engine1.record_run(_make_suite_result())

    engine2 = MaturityEngine(tmp_path)
    assert engine2.state.stats.total_runs == 10
    assert engine2.level == MaturityLevel.GROWING


# ---------------------------------------------------------------------------
# Stats tracking
# ---------------------------------------------------------------------------


def test_unique_test_names_counted(tmp_path):
    engine = MaturityEngine(tmp_path)
    engine.record_run(_make_suite_result(["test_a", "test_b", "test_c"]))
    assert engine.state.stats.unique_test_names == 3


def test_first_and_last_run_set(tmp_path):
    engine = MaturityEngine(tmp_path)
    engine.record_run(_make_suite_result())
    assert engine.state.stats.first_run is not None
    assert engine.state.stats.last_run is not None


def test_total_tests_executed(tmp_path):
    engine = MaturityEngine(tmp_path)
    engine.record_run(_make_suite_result(["test_a", "test_b"]))
    engine.record_run(_make_suite_result(["test_a", "test_b", "test_c"]))
    assert engine.state.stats.total_tests_executed == 5
