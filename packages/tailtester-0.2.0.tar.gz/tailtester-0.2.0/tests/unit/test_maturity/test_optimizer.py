"""Tests for the TestOptimizer (Phase 7C)."""

from __future__ import annotations

import pytest

from tailtest.maturity.optimizer import (
    OptimizationSuggestion,
    SuggestionType,
    TestOptimizer,
)
from tailtest.maturity.store import TestProfile


@pytest.fixture
def optimizer():
    return TestOptimizer()


@pytest.fixture
def redundant_profiles() -> dict[str, TestProfile]:
    """Two tests that always pass/fail together."""
    return {
        "test_no_medical": TestProfile(
            runs=20, passes=15, fails=5,
            avg_latency_ms=100, avg_cost_usd=0.001,
            failure_category="scope_violation",
        ),
        "test_no_legal": TestProfile(
            runs=20, passes=15, fails=5,
            avg_latency_ms=110, avg_cost_usd=0.001,
            failure_category="scope_violation",
        ),
        "test_greeting": TestProfile(
            runs=20, passes=20, fails=0,
            avg_latency_ms=80, avg_cost_usd=0.001,
        ),
    }


@pytest.fixture
def expensive_profiles() -> dict[str, TestProfile]:
    """Test profiles with expensive LLM-judged tests that always pass."""
    return {
        "test_response_quality": TestProfile(
            runs=30, passes=30, fails=0,
            avg_latency_ms=500, avg_cost_usd=0.02,
        ),
        "test_tone_check": TestProfile(
            runs=30, passes=30, fails=0,
            avg_latency_ms=400, avg_cost_usd=0.015,
        ),
        "test_basic": TestProfile(
            runs=30, passes=28, fails=2,
            avg_latency_ms=100, avg_cost_usd=0.001,
        ),
    }


@pytest.fixture
def flaky_profiles() -> dict[str, TestProfile]:
    """Test profiles with a flaky test."""
    return {
        "test_flaky_one": TestProfile(
            runs=20, passes=18, fails=2,
            flaky=True, flake_rate=0.1,
            avg_latency_ms=200, avg_cost_usd=0.003,
        ),
        "test_stable": TestProfile(
            runs=20, passes=20, fails=0,
            avg_latency_ms=100, avg_cost_usd=0.001,
        ),
    }


class TestFindRedundantTests:
    def test_detects_redundant_pair(self, optimizer: TestOptimizer, redundant_profiles: dict):
        suggestions = optimizer._find_redundant_tests(redundant_profiles)
        assert len(suggestions) >= 1
        redundant = [s for s in suggestions if s.type == SuggestionType.REDUNDANT]
        assert len(redundant) >= 1
        # Both test names should appear
        assert "test_no_medical" in redundant[0].tests
        assert "test_no_legal" in redundant[0].tests

    def test_no_redundancy_in_different_profiles(self, optimizer: TestOptimizer):
        profiles = {
            "test_a": TestProfile(runs=10, passes=10, fails=0),
            "test_b": TestProfile(runs=10, passes=5, fails=5),
        }
        suggestions = optimizer._find_redundant_tests(profiles)
        assert len(suggestions) == 0

    def test_skips_low_run_count(self, optimizer: TestOptimizer):
        profiles = {
            "test_a": TestProfile(runs=3, passes=3, fails=0),
            "test_b": TestProfile(runs=3, passes=3, fails=0),
        }
        suggestions = optimizer._find_redundant_tests(profiles)
        assert len(suggestions) == 0


class TestFindEfficiencyOpportunities:
    def test_detects_expensive_always_pass(self, optimizer: TestOptimizer, expensive_profiles: dict):
        suggestions = optimizer._find_efficiency_opportunities(expensive_profiles)
        assert len(suggestions) >= 1
        upgrade = [s for s in suggestions if s.type == SuggestionType.UPGRADE]
        assert len(upgrade) >= 1
        # Should suggest upgrading the expensive tests
        names_in_suggestions = [t for s in upgrade for t in s.tests]
        assert "test_response_quality" in names_in_suggestions or "test_tone_check" in names_in_suggestions

    def test_no_suggestion_for_failing_test(self, optimizer: TestOptimizer):
        profiles = {
            "test_expensive_failing": TestProfile(
                runs=20, passes=15, fails=5,
                avg_cost_usd=0.02,
            ),
        }
        suggestions = optimizer._find_efficiency_opportunities(profiles)
        assert len(suggestions) == 0


class TestFindFlakyTests:
    def test_detects_flaky(self, optimizer: TestOptimizer, flaky_profiles: dict):
        suggestions = optimizer._find_flaky_tests(flaky_profiles)
        assert len(suggestions) == 1
        assert suggestions[0].type == SuggestionType.FLAKY
        assert "test_flaky_one" in suggestions[0].tests

    def test_no_flaky_when_stable(self, optimizer: TestOptimizer):
        profiles = {
            "test_stable": TestProfile(
                runs=20, passes=20, fails=0,
            ),
        }
        suggestions = optimizer._find_flaky_tests(profiles)
        assert len(suggestions) == 0


class TestFindAlwaysPassTests:
    def test_detects_many_always_pass(self, optimizer: TestOptimizer):
        profiles = {
            f"test_{i}": TestProfile(runs=25, passes=25, fails=0)
            for i in range(5)
        }
        suggestions = optimizer._find_always_pass_tests(profiles)
        assert len(suggestions) >= 1
        assert suggestions[0].type == SuggestionType.UPGRADE

    def test_no_suggestion_for_few_always_pass(self, optimizer: TestOptimizer):
        profiles = {
            "test_a": TestProfile(runs=25, passes=25, fails=0),
            "test_b": TestProfile(runs=25, passes=24, fails=1),
        }
        suggestions = optimizer._find_always_pass_tests(profiles)
        assert len(suggestions) == 0


class TestAnalyzeIntegration:
    def test_analyze_combines_all_suggestions(self, optimizer: TestOptimizer):
        profiles = {
            # Redundant pair
            "test_dup_a": TestProfile(
                runs=10, passes=10, fails=0,
                avg_cost_usd=0.001,
            ),
            "test_dup_b": TestProfile(
                runs=10, passes=10, fails=0,
                avg_cost_usd=0.001,
            ),
            # Flaky test
            "test_flaky": TestProfile(
                runs=10, passes=8, fails=2,
                flaky=True, flake_rate=0.2,
                avg_cost_usd=0.001,
            ),
        }
        suggestions = optimizer.analyze(profiles)
        types = {s.type for s in suggestions}
        assert SuggestionType.FLAKY in types

    def test_empty_profiles_returns_empty(self, optimizer: TestOptimizer):
        assert optimizer.analyze({}) == []
