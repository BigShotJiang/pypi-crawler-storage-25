"""Tests for the CoverageAnalyzer (Phase 7C)."""

from __future__ import annotations

import pytest

from tailtest.maturity.coverage import CoverageAnalyzer, CoverageGap
from tailtest.maturity.store import (
    FailurePattern,
    MaturityState,
    MaturityStats,
    TestProfile,
)


@pytest.fixture
def analyzer():
    return CoverageAnalyzer()


@pytest.fixture
def state_with_gaps() -> MaturityState:
    """State with failure patterns but no dedicated tests for them."""
    return MaturityState(
        level="mature",
        stats=MaturityStats(total_runs=60),
        test_profiles={
            "test_greeting": TestProfile(runs=60, passes=60, fails=0),
            "test_tool_call": TestProfile(runs=60, passes=55, fails=5),
        },
        failure_patterns={
            "hallucination": FailurePattern(
                count=8,
                triggers=["unknown product query", "competitor mention"],
                affected_tests=["test_no_price_hallucination"],
            ),
            "pii_leak": FailurePattern(
                count=3,
                triggers=["list all orders"],
                affected_tests=["test_no_data_leak"],
            ),
        },
    )


@pytest.fixture
def state_no_production() -> MaturityState:
    """State with no production traces."""
    return MaturityState(
        level="mature",
        stats=MaturityStats(
            total_runs=60,
            production_traces_ingested=0,
        ),
        test_profiles={
            "test_greeting": TestProfile(runs=60, passes=60, fails=0),
        },
    )


@pytest.fixture
def state_with_production_no_regressions() -> MaturityState:
    """State with production traces but no auto-generated regressions."""
    return MaturityState(
        level="mature",
        stats=MaturityStats(
            total_runs=60,
            production_traces_ingested=50,
            auto_regressions_generated=0,
        ),
        test_profiles={
            "test_greeting": TestProfile(runs=60, passes=60, fails=0),
        },
    )


class TestGapsFromFailurePatterns:
    def test_identifies_untested_failure_categories(
        self, analyzer: CoverageAnalyzer, state_with_gaps: MaturityState
    ):
        gaps = analyzer._gaps_from_failure_patterns(
            state_with_gaps.failure_patterns,
            state_with_gaps.test_profiles,
        )
        # hallucination and pii_leak should be flagged as gaps
        behaviors = [g.behavior for g in gaps]
        assert any("hallucination" in b for b in behaviors)
        assert any("pii_leak" in b for b in behaviors)

    def test_high_severity_for_frequent_patterns(
        self, analyzer: CoverageAnalyzer, state_with_gaps: MaturityState
    ):
        gaps = analyzer._gaps_from_failure_patterns(
            state_with_gaps.failure_patterns,
            state_with_gaps.test_profiles,
        )
        halluc_gaps = [g for g in gaps if "hallucination" in g.behavior]
        # 8 count should be high severity
        assert any(g.severity == "high" for g in halluc_gaps)

    def test_no_gaps_when_patterns_empty(self, analyzer: CoverageAnalyzer):
        gaps = analyzer._gaps_from_failure_patterns({}, {})
        assert gaps == []


class TestGapsFromStandardBehaviors:
    def test_finds_missing_standard_behaviors(self, analyzer: CoverageAnalyzer):
        profiles = {
            "test_greeting": TestProfile(runs=10, passes=10, fails=0),
        }
        gaps = analyzer._gaps_from_standard_behaviors(profiles)
        behaviors = [g.behavior for g in gaps]
        # greeting is covered, but others should be missing
        assert "greeting" not in behaviors
        assert "safety" in behaviors or "data_privacy" in behaviors

    def test_safety_gaps_are_medium_severity(self, analyzer: CoverageAnalyzer):
        profiles = {
            "test_greeting": TestProfile(runs=10, passes=10, fails=0),
        }
        gaps = analyzer._gaps_from_standard_behaviors(profiles)
        safety_gaps = [g for g in gaps if g.behavior in ("safety", "data_privacy")]
        for g in safety_gaps:
            assert g.severity == "medium"


class TestGapsFromProductionTraces:
    def test_gap_when_no_production_traces(
        self, analyzer: CoverageAnalyzer, state_no_production: MaturityState
    ):
        gaps = analyzer._gaps_from_production_traces(state_no_production)
        assert len(gaps) == 1
        assert "production" in gaps[0].behavior.lower()

    def test_gap_when_traces_but_no_regressions(
        self, analyzer: CoverageAnalyzer,
        state_with_production_no_regressions: MaturityState,
    ):
        gaps = analyzer._gaps_from_production_traces(state_with_production_no_regressions)
        assert len(gaps) == 1
        assert gaps[0].severity == "high"


class TestAnalyzeIntegration:
    def test_full_analysis_returns_sorted_gaps(
        self, analyzer: CoverageAnalyzer, state_with_gaps: MaturityState
    ):
        gaps = analyzer.analyze(state_with_gaps)
        assert len(gaps) > 0
        # Should be sorted by severity (high first)
        severity_order = {"high": 0, "medium": 1, "low": 2}
        for i in range(len(gaps) - 1):
            assert severity_order.get(gaps[i].severity, 3) <= severity_order.get(
                gaps[i + 1].severity, 3
            )

    def test_empty_state_returns_gaps(self, analyzer: CoverageAnalyzer):
        state = MaturityState(level="mature", stats=MaturityStats(total_runs=60))
        gaps = analyzer.analyze(state)
        # Should at least report no production traces
        assert len(gaps) > 0
