"""Tests for GenericDetector  -  fallback detector for unknown LLM frameworks."""

import ast
from pathlib import Path

import pytest

from tailtest.context.detectors.generic_detector import GenericDetector
from tailtest.models import PromptDefinition, ToolDefinition


@pytest.fixture
def detector():
    return GenericDetector()


@pytest.fixture
def dummy_path(tmp_path):
    return tmp_path / "agent.py"


# --------------------------------------------------------------------------- #
# Detection
# --------------------------------------------------------------------------- #


def test_detects_litellm_import(detector, dummy_path):
    """detect() returns True when litellm is imported."""
    source = "import litellm\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_detects_llama_index_import(detector, dummy_path):
    """detect() returns True when llama_index is imported."""
    source = "import llama_index\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_detects_raw_messages_pattern(detector, dummy_path):
    """detect() returns True when a messages=[...] pattern is found."""
    source = '''\
import requests
result = some_function(
    messages=[{"role": "user", "content": "hello"}],
)
'''
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_returns_false_for_plain_python(detector, dummy_path):
    """detect() returns False for normal Python with no LLM patterns."""
    source = "import os\nprint('hello world')\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is False


# --------------------------------------------------------------------------- #
# Model extraction
# --------------------------------------------------------------------------- #


def test_extracts_model_strings(detector, dummy_path):
    """extract_models() finds model= kwargs that look like LLM model names."""
    source = '''\
import litellm
response = litellm.completion(
    model="gpt-4o",
    messages=[{"role": "user", "content": "hi"}],
)
'''
    tree = ast.parse(source)
    models = detector.extract_models(dummy_path, tree)
    assert "gpt-4o" in models


def test_extracts_model_with_slash_notation(detector, dummy_path):
    """extract_models() picks up 'provider/model' style strings."""
    source = '''\
import litellm
response = litellm.completion(
    model="ollama/llama3.2",
    messages=[{"role": "user", "content": "hi"}],
)
'''
    tree = ast.parse(source)
    models = detector.extract_models(dummy_path, tree)
    assert "ollama/llama3.2" in models


# --------------------------------------------------------------------------- #
# Prompt extraction
# --------------------------------------------------------------------------- #


def test_extracts_system_from_messages(detector, dummy_path):
    """extract_prompts() finds system prompts inside messages=[...] dicts."""
    source = '''\
import litellm
response = litellm.completion(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": "You are a pirate."},
        {"role": "user", "content": "Ahoy!"},
    ],
)
'''
    tree = ast.parse(source)
    prompts = detector.extract_prompts(dummy_path, tree)
    assert len(prompts) >= 1
    assert any(p.content == "You are a pirate." for p in prompts)


# --------------------------------------------------------------------------- #
# Framework name
# --------------------------------------------------------------------------- #


def test_framework_name_is_generic(detector):
    """The detector's framework_name attribute is 'generic'."""
    assert detector.framework_name == "generic"
