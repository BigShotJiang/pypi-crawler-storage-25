"""Tests for AnthropicDetector  -  detect and extract Anthropic SDK patterns from ASTs."""

import ast
from pathlib import Path

import pytest

from tailtest.context.detectors.anthropic_detector import AnthropicDetector
from tailtest.models import PromptDefinition, ToolDefinition


@pytest.fixture
def detector():
    return AnthropicDetector()


@pytest.fixture
def dummy_path(tmp_path):
    return tmp_path / "agent.py"


# --------------------------------------------------------------------------- #
# Detection
# --------------------------------------------------------------------------- #


def test_detects_import_anthropic(detector, dummy_path):
    """detect() returns True when the file imports anthropic."""
    source = "import anthropic\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_detects_from_anthropic_import(detector, dummy_path):
    """detect() returns True for `from anthropic import Anthropic`."""
    source = "from anthropic import Anthropic\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_returns_false_for_no_anthropic_import(detector, dummy_path):
    """detect() returns False when anthropic is not imported."""
    source = "import os\nimport json\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is False


# --------------------------------------------------------------------------- #
# Prompt extraction
# --------------------------------------------------------------------------- #


def test_extracts_system_param(detector, dummy_path):
    """extract_prompts() finds the system= kwarg from messages.create()."""
    source = '''\
import anthropic
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    system="You are a helpful coding assistant.",
    messages=[{"role": "user", "content": "Hello"}],
)
'''
    tree = ast.parse(source)
    prompts = detector.extract_prompts(dummy_path, tree)
    assert len(prompts) == 1
    assert prompts[0].content == "You are a helpful coding assistant."
    assert prompts[0].role == "system"


def test_no_prompts_when_no_system_param(detector, dummy_path):
    """extract_prompts() returns empty when there is no system= kwarg."""
    source = '''\
import anthropic
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello"}],
)
'''
    tree = ast.parse(source)
    prompts = detector.extract_prompts(dummy_path, tree)
    assert len(prompts) == 0


# --------------------------------------------------------------------------- #
# Model extraction
# --------------------------------------------------------------------------- #


def test_extracts_model_name(detector, dummy_path):
    """extract_models() pulls out the model= string from create() calls."""
    source = '''\
import anthropic
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "hi"}],
)
'''
    tree = ast.parse(source)
    models = detector.extract_models(dummy_path, tree)
    assert "claude-sonnet-4-20250514" in models


# --------------------------------------------------------------------------- #
# Tool extraction
# --------------------------------------------------------------------------- #


def test_extracts_tool_definitions(detector, dummy_path):
    """extract_tools() parses tools=[...] kwarg from messages.create()."""
    source = '''\
import anthropic
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "weather?"}],
    tools=[
        {"name": "get_weather", "description": "Get current weather", "input_schema": {}},
    ],
)
'''
    tree = ast.parse(source)
    tools = detector.extract_tools(dummy_path, tree)
    assert len(tools) == 1
    assert tools[0].name == "get_weather"
    assert tools[0].description == "Get current weather"


# --------------------------------------------------------------------------- #
# Framework name
# --------------------------------------------------------------------------- #


def test_framework_name_is_anthropic(detector):
    """The detector's framework_name attribute is 'anthropic'."""
    assert detector.framework_name == "anthropic"
