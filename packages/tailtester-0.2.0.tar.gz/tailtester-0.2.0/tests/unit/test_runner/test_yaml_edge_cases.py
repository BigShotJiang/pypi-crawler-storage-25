"""Tests for YAML loader edge cases.

Covers: missing agent config, relative paths, missing required fields,
malformed YAML, agent shorthand syntax, domain field, empty files,
null fields, and helpful error messages.
"""

from __future__ import annotations

import textwrap
import warnings

import pytest

from tailtest.runner.yaml_loader import YAMLLoadError, load_yaml_tests


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _write_yaml(tmp_path, content, filename="test_suite.yaml"):
    """Write a YAML file and return its path."""
    p = tmp_path / filename
    p.write_text(textwrap.dedent(content))
    return p


# --------------------------------------------------------------------------- #
# Edge Case 1: No agent config, no tailtest.yaml  -  clear warning
# --------------------------------------------------------------------------- #


class TestNoAgentConfig:
    """When no inline agent config AND no tailtest.yaml exists, give a
    clear warning instead of crashing."""

    def test_no_agent_no_tailtest_yaml_warns(self, tmp_path):
        """Should emit a UserWarning when no agent config is found anywhere."""
        f = _write_yaml(tmp_path, """\
            tests:
              - name: Orphan test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            tests = load_yaml_tests(f)

        # Tests are still returned (they just can't call the agent)
        assert len(tests) == 1
        # A warning was raised with helpful message
        warning_msgs = [str(w.message) for w in caught if issubclass(w.category, UserWarning)]
        assert any("No agent configuration found" in m for m in warning_msgs)
        assert any("tailtest.yaml" in m for m in warning_msgs)

    def test_no_agent_tests_still_loadable(self, tmp_path):
        """Tests load successfully even without agent config (for assertion-only tests)."""
        f = _write_yaml(tmp_path, """\
            tests:
              - name: Static test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            tests = load_yaml_tests(f)
        assert tests[0].__name__ == "test_static_test"


# --------------------------------------------------------------------------- #
# Edge Case 2: Relative paths  -  YAML in subdirectory
# --------------------------------------------------------------------------- #


class TestRelativePaths:
    """YAML file in a subdirectory should find tailtest.yaml in parent."""

    def test_finds_tailtest_yaml_in_parent(self, tmp_path):
        """A YAML test file in a subdirectory finds tailtest.yaml in the parent."""
        # Create tailtest.yaml in parent (use http type so no module import needed)
        (tmp_path / "tailtest.yaml").write_text(textwrap.dedent("""\
            version: "1"
            agent:
              type: http
              url: http://localhost:9999
        """))

        # Create test YAML in subdirectory
        subdir = tmp_path / "tests" / "integration"
        subdir.mkdir(parents=True)
        f = _write_yaml(subdir, """\
            tests:
              - name: Subdirectory test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """, filename="test_deep.yaml")

        # Should find the parent's tailtest.yaml without error
        tests = load_yaml_tests(f)
        assert len(tests) == 1
        assert tests[0].__name__ == "test_subdirectory_test"

    def test_deeply_nested_finds_root_config(self, tmp_path):
        """A YAML test file nested several levels deep still finds root tailtest.yaml."""
        (tmp_path / "tailtest.yaml").write_text(textwrap.dedent("""\
            version: "1"
            agent:
              type: http
              url: http://localhost:9999
        """))

        deep_dir = tmp_path / "a" / "b" / "c"
        deep_dir.mkdir(parents=True)
        f = _write_yaml(deep_dir, """\
            tests:
              - name: Deep test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)

        tests = load_yaml_tests(f)
        assert len(tests) == 1


# --------------------------------------------------------------------------- #
# Edge Case 3: Missing required fields  -  graceful errors
# --------------------------------------------------------------------------- #


class TestMissingFields:
    """Missing required fields should produce helpful, specific error messages."""

    def test_missing_tests_key_lists_present_keys(self, tmp_path):
        """Error for missing 'tests' key should list what keys are present."""
        f = _write_yaml(tmp_path, """\
            name: Bad Config
            domain: accounting
        """)
        with pytest.raises(YAMLLoadError, match="Present keys:"):
            load_yaml_tests(f)

    def test_missing_test_name_lists_present_fields(self, tmp_path):
        """Error for missing test name should list what fields are present."""
        f = _write_yaml(tmp_path, """\
            tests:
              - input: "Hello"
                assert:
                  - type: contains
                    value: "hi"
        """)
        with pytest.raises(YAMLLoadError, match="Present fields:"):
            load_yaml_tests(f)

    def test_null_tests_value_gives_clear_error(self, tmp_path):
        """A 'tests:' key with null value gives a clear error, not a crash."""
        f = _write_yaml(tmp_path, """\
            tests:
        """)
        with pytest.raises(YAMLLoadError, match="empty.*null"):
            load_yaml_tests(f)

    def test_empty_tests_list_gives_clear_error(self, tmp_path):
        """An empty tests list gives a clear error."""
        f = _write_yaml(tmp_path, """\
            tests: []
        """)
        with pytest.raises(YAMLLoadError, match="empty"):
            load_yaml_tests(f)

    def test_tests_as_string_gives_type_error(self, tmp_path):
        """'tests' value as a string gives a type mismatch error."""
        f = _write_yaml(tmp_path, """\
            tests: "not a list"
        """)
        with pytest.raises(YAMLLoadError, match="must be a list"):
            load_yaml_tests(f)


# --------------------------------------------------------------------------- #
# Edge Case 4: Malformed YAML  -  helpful messages
# --------------------------------------------------------------------------- #


class TestMalformedYAML:
    """Malformed YAML should produce helpful error messages."""

    def test_invalid_yaml_syntax(self, tmp_path):
        """Completely invalid YAML gives a helpful parse error."""
        f = tmp_path / "test_bad.yaml"
        f.write_text(":\n  - :\n    {{invalid!!")
        with pytest.raises(YAMLLoadError, match="Invalid YAML"):
            load_yaml_tests(f)

    def test_invalid_yaml_includes_hint(self, tmp_path):
        """YAML parse errors should include helpful hints."""
        f = tmp_path / "test_bad2.yaml"
        f.write_text("tests:\n  - name: foo\n    input: bar\n  bad indent")
        with pytest.raises(YAMLLoadError, match="[Hh]int"):
            load_yaml_tests(f)

    def test_empty_file_gives_clear_error(self, tmp_path):
        """An empty YAML file gives a clear 'empty' error, not a crash."""
        f = tmp_path / "test_empty.yaml"
        f.write_text("")
        with pytest.raises(YAMLLoadError, match="Empty YAML"):
            load_yaml_tests(f)

    def test_yaml_with_only_comments(self, tmp_path):
        """A YAML file with only comments is treated as empty."""
        f = tmp_path / "test_comments.yaml"
        f.write_text("# just a comment\n# nothing else\n")
        with pytest.raises(YAMLLoadError, match="Empty YAML"):
            load_yaml_tests(f)

    def test_non_mapping_top_level(self, tmp_path):
        """A YAML file whose top level is a list gives a clear error."""
        f = tmp_path / "test_list.yaml"
        f.write_text("- item1\n- item2\n")
        with pytest.raises(YAMLLoadError, match="Expected top-level mapping"):
            load_yaml_tests(f)

    def test_nonexistent_file_gives_clear_error(self, tmp_path):
        """Trying to load a file that doesn't exist gives an OSError-based message."""
        f = tmp_path / "does_not_exist.yaml"
        with pytest.raises(YAMLLoadError, match="Cannot read"):
            load_yaml_tests(f)


# --------------------------------------------------------------------------- #
# Edge Case 5: Agent shorthand  -  agent: my_module:my_fn
# --------------------------------------------------------------------------- #


class TestAgentShorthand:
    """Support shorthand agent config with just a function name string."""

    def test_python_shorthand_recognized(self, tmp_path):
        """agent: 'my_module:my_fn' is recognized as Python function shorthand."""
        from tailtest.runner.yaml_loader import _parse_agent_shorthand

        result = _parse_agent_shorthand("my_module:my_fn")
        assert result == {"type": "python", "function": "my_module:my_fn"}

    def test_http_url_shorthand_recognized(self, tmp_path):
        """agent: 'http://...' is recognized as HTTP shorthand."""
        from tailtest.runner.yaml_loader import _parse_agent_shorthand

        result = _parse_agent_shorthand("http://localhost:8000")
        assert result == {"type": "http", "url": "http://localhost:8000"}

    def test_https_url_shorthand_recognized(self, tmp_path):
        """agent: 'https://...' is recognized as HTTPS shorthand."""
        from tailtest.runner.yaml_loader import _parse_agent_shorthand

        result = _parse_agent_shorthand("https://api.example.com/agent")
        assert result == {"type": "http", "url": "https://api.example.com/agent"}

    def test_bare_module_name_raises(self, tmp_path):
        """agent: 'my_module' (no colon) gives a clear error."""
        from tailtest.runner.yaml_loader import _parse_agent_shorthand

        with pytest.raises(YAMLLoadError, match="module_name:function_name"):
            _parse_agent_shorthand("my_module")

    def test_shorthand_in_yaml_file(self, tmp_path):
        """Full integration: agent shorthand in a YAML file resolves correctly."""
        # Create a dummy agent module
        (tmp_path / "dummy_agent.py").write_text(
            "async def chat(msg):\n    return {'content': 'hello'}\n"
        )
        f = _write_yaml(tmp_path, """\
            agent: dummy_agent:chat
            tests:
              - name: Shorthand test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)
        # Should load without error (the agent interface is created from shorthand)
        tests = load_yaml_tests(f)
        assert len(tests) == 1


# --------------------------------------------------------------------------- #
# Domain field in YAML
# --------------------------------------------------------------------------- #


class TestDomainField:
    """The 'domain' field in YAML test files should load a domain pack."""

    def test_valid_domain_attaches_metadata(self, tmp_path):
        """A valid domain name attaches domain pack metadata to tests."""
        f = _write_yaml(tmp_path, """\
            domain: accounting
            tests:
              - name: Domain test
                input: "Create invoice"
                assert:
                  - type: contains
                    value: "invoice"
        """)
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            tests = load_yaml_tests(f)
        assert len(tests) == 1
        assert getattr(tests[0], "_tailtest_domain", None) == "accounting"
        assert getattr(tests[0], "_tailtest_domain_pack", None) is not None

    def test_invalid_domain_raises(self, tmp_path):
        """An unknown domain name raises YAMLLoadError."""
        f = _write_yaml(tmp_path, """\
            domain: nonexistent_domain
            tests:
              - name: Bad domain test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)
        with pytest.raises(YAMLLoadError, match="Unknown domain pack"):
            load_yaml_tests(f)

    def test_no_domain_field_no_metadata(self, tmp_path):
        """Without a domain field, no domain metadata is attached."""
        f = _write_yaml(tmp_path, """\
            tests:
              - name: No domain test
                input: "Hello"
                assert:
                  - type: contains
                    value: "hello"
        """)
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            tests = load_yaml_tests(f)
        assert not hasattr(tests[0], "_tailtest_domain")
