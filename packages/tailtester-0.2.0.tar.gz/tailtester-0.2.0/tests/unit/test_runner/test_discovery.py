"""Tests for test discovery  -  finding and loading test functions."""

import pytest

from tailtest.runner.discovery import discover_tests


# --------------------------------------------------------------------------- #
# File naming patterns
# --------------------------------------------------------------------------- #


def test_discovers_test_prefix_files(tmp_path):
    """discover_tests() finds files named test_*.py."""
    (tmp_path / "test_hello.py").write_text("def test_greet():\n    pass\n")
    tests = discover_tests(tmp_path)
    assert len(tests) >= 1
    names = [fn.__name__ for fn in tests]
    assert "test_greet" in names


def test_discovers_test_suffix_files(tmp_path):
    """discover_tests() finds files named *_test.py."""
    (tmp_path / "hello_test.py").write_text("def test_world():\n    pass\n")
    tests = discover_tests(tmp_path)
    assert len(tests) >= 1
    names = [fn.__name__ for fn in tests]
    assert "test_world" in names


def test_skips_non_test_files(tmp_path):
    """discover_tests() ignores files that are not test files."""
    (tmp_path / "utils.py").write_text("def helper():\n    pass\n")
    (tmp_path / "config.py").write_text("X = 1\n")
    tests = discover_tests(tmp_path)
    assert len(tests) == 0


# --------------------------------------------------------------------------- #
# Empty and nested directories
# --------------------------------------------------------------------------- #


def test_handles_empty_directory(tmp_path):
    """discover_tests() returns empty list for an empty directory."""
    tests = discover_tests(tmp_path)
    assert tests == []


def test_handles_nested_directories(tmp_path):
    """discover_tests() recurses into subdirectories."""
    sub = tmp_path / "sub" / "deep"
    sub.mkdir(parents=True)
    (sub / "test_nested.py").write_text("def test_deep():\n    pass\n")
    tests = discover_tests(tmp_path)
    assert len(tests) >= 1
    names = [fn.__name__ for fn in tests]
    assert "test_deep" in names


# --------------------------------------------------------------------------- #
# Decorated tests
# --------------------------------------------------------------------------- #


def test_discovers_agent_test_decorated_functions(tmp_path):
    """discover_tests() finds functions with _tailtest_test attribute."""
    source = '''\
def my_custom_check():
    """Not named test_ but has the tailtest attribute."""
    pass

my_custom_check._tailtest_test = True
'''
    (tmp_path / "test_custom.py").write_text(source)
    tests = discover_tests(tmp_path)
    names = [fn.__name__ for fn in tests]
    assert "my_custom_check" in names


# --------------------------------------------------------------------------- #
# Single file
# --------------------------------------------------------------------------- #


def test_discovers_from_single_file(tmp_path):
    """discover_tests() works when pointed at a single .py file."""
    f = tmp_path / "test_single.py"
    f.write_text("def test_one():\n    pass\n\ndef test_two():\n    pass\n")
    tests = discover_tests(f)
    assert len(tests) == 2


# --------------------------------------------------------------------------- #
# Import errors produce synthetic tests
# --------------------------------------------------------------------------- #


def test_import_error_produces_synthetic_test(tmp_path):
    """discover_tests() returns a synthetic failing test for import errors."""
    (tmp_path / "test_bad.py").write_text(
        "from some_nonexistent_package import xyz\ndef test_x(): pass\n"
    )
    tests = discover_tests(tmp_path)
    assert len(tests) >= 1
    # The synthetic test name contains 'import_error'
    names = [fn.__name__ for fn in tests]
    assert any("import_error" in n for n in names)


# --------------------------------------------------------------------------- #
# Metadata
# --------------------------------------------------------------------------- #


def test_attaches_source_file_metadata(tmp_path):
    """discover_tests() attaches _tailtest_source_file to discovered functions."""
    f = tmp_path / "test_meta.py"
    f.write_text("def test_meta():\n    pass\n")
    tests = discover_tests(f)
    assert len(tests) == 1
    assert hasattr(tests[0], "_tailtest_source_file")
    assert str(f) in tests[0]._tailtest_source_file
