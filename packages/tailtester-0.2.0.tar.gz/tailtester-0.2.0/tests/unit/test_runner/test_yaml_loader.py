"""Tests for the YAML test loader  -  parsing YAML test definitions into callables."""

import textwrap

import pytest

from tailtest.runner.yaml_loader import YAMLLoadError, load_yaml_tests


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _write_yaml(tmp_path, content, filename="test_suite.yaml"):
    """Write a YAML file and return its path."""
    p = tmp_path / filename
    p.write_text(textwrap.dedent(content))
    return p


# --------------------------------------------------------------------------- #
# Basic loading
# --------------------------------------------------------------------------- #


def test_loads_simple_yaml_test(tmp_path):
    """load_yaml_tests returns a callable for a simple single-input test."""
    f = _write_yaml(tmp_path, """\
        name: Simple Suite
        tests:
          - name: Greeting
            input: "Hello"
            assert:
              - type: contains
                value: "hello"
                case_insensitive: true
    """)
    tests = load_yaml_tests(f)
    assert len(tests) == 1
    assert tests[0].__name__ == "test_greeting"
    assert getattr(tests[0], "_tailtest_test", False) is True
    assert getattr(tests[0], "_tailtest_yaml", False) is True


def test_loads_multiple_tests(tmp_path):
    """load_yaml_tests returns one callable per test entry."""
    f = _write_yaml(tmp_path, """\
        name: Multi
        tests:
          - name: Test A
            input: "First"
            assert:
              - type: contains
                value: "a"
          - name: Test B
            input: "Second"
            assert:
              - type: contains
                value: "b"
          - name: Test C
            input: "Third"
            assert:
              - type: contains
                value: "c"
    """)
    tests = load_yaml_tests(f)
    assert len(tests) == 3
    names = [t.__name__ for t in tests]
    assert "test_a" in names
    assert "test_b" in names
    assert "test_c" in names


# --------------------------------------------------------------------------- #
# Assertion types
# --------------------------------------------------------------------------- #


def test_contains_assertion_from_yaml(tmp_path):
    """'contains' assertion type creates a ContainsAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Contains check
            input: "Hello"
            assert:
              - type: contains
                value: "hello"
                case_insensitive: true
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.contains import ContainsAssertion
    assert isinstance(assertions[0], ContainsAssertion)
    assert assertions[0].text == "hello"
    assert assertions[0].case_insensitive is True


def test_cost_under_from_yaml(tmp_path):
    """'cost_under' assertion type creates a CostAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Cost check
            input: "Hello"
            assert:
              - type: cost_under
                value: 0.05
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.cost import CostAssertion
    assert isinstance(assertions[0], CostAssertion)
    assert assertions[0].max_cost == 0.05


def test_tool_called_from_yaml(tmp_path):
    """'tool_called' assertion type creates a ToolCallAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Tool check
            input: "Lookup order"
            assert:
              - type: tool_called
                tool: lookup_order
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.tool_call import ToolCallAssertion
    assert isinstance(assertions[0], ToolCallAssertion)
    assert assertions[0].tool_name == "lookup_order"


def test_no_pii_from_yaml(tmp_path):
    """'no_pii' assertion type creates a PIIAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: PII check
            input: "Show my info"
            assert:
              - type: no_pii
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.pii import PIIAssertion
    assert isinstance(assertions[0], PIIAssertion)


def test_latency_under_from_yaml(tmp_path):
    """'latency_under' assertion type creates a LatencyAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Latency check
            input: "Quick response"
            assert:
              - type: latency_under
                value: 3000
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.latency import LatencyAssertion
    assert isinstance(assertions[0], LatencyAssertion)
    assert assertions[0].max_ms == 3000


def test_regex_assertion_from_yaml(tmp_path):
    """'regex' assertion type creates a RegexAssertion."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Regex check
            input: "Give me a number"
            assert:
              - type: regex
                pattern: "\\\\d+"
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 1
    from tailtest.assertions.deterministic.regex import RegexAssertion
    assert isinstance(assertions[0], RegexAssertion)


def test_multiple_assertion_types_in_one_test(tmp_path):
    """A single test can have multiple assertion types."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Multi assert
            input: "Hello"
            assert:
              - type: contains
                value: "hello"
              - type: latency_under
                value: 2000
              - type: cost_under
                value: 0.01
              - type: no_pii
    """)
    tests = load_yaml_tests(f)
    assertions = getattr(tests[0], "_tailtest_assertions", [])
    assert len(assertions) == 4


# --------------------------------------------------------------------------- #
# Conversation tests
# --------------------------------------------------------------------------- #


def test_conversation_test_from_yaml(tmp_path):
    """Conversation tests with multiple turns are loaded correctly."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Refund conversation
            conversation:
              - input: "I want a refund"
                assert:
                  - type: contains
                    value: "order number"
              - input: "Order #12345"
                assert:
                  - type: tool_called
                    tool: lookup_order
    """)
    tests = load_yaml_tests(f)
    assert len(tests) == 1
    assert tests[0].__name__ == "test_refund_conversation"
    assert getattr(tests[0], "_tailtest_yaml", False) is True
    turns = getattr(tests[0], "_tailtest_conversation", [])
    assert len(turns) == 2
    assert turns[0]["input"] == "I want a refund"
    assert len(turns[0]["assertions"]) == 1
    assert turns[1]["input"] == "Order #12345"
    assert len(turns[1]["assertions"]) == 1


# --------------------------------------------------------------------------- #
# Error handling
# --------------------------------------------------------------------------- #


def test_unknown_assertion_type_raises(tmp_path):
    """An unknown assertion type raises YAMLLoadError."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Bad assertion
            input: "Hello"
            assert:
              - type: totally_made_up
                value: "x"
    """)
    with pytest.raises(YAMLLoadError, match="Unknown assertion type 'totally_made_up'"):
        load_yaml_tests(f)


def test_invalid_yaml_handled(tmp_path):
    """Malformed YAML raises YAMLLoadError."""
    f = tmp_path / "test_bad.yaml"
    f.write_text(":\n  - :\n    {{invalid yaml content!!")
    with pytest.raises(YAMLLoadError, match="Invalid YAML"):
        load_yaml_tests(f)


def test_missing_required_fields(tmp_path):
    """Missing 'tests' key raises YAMLLoadError."""
    f = _write_yaml(tmp_path, """\
        name: Missing tests key
        agent:
          type: http
    """)
    with pytest.raises(YAMLLoadError, match="Missing required 'tests' key"):
        load_yaml_tests(f)


def test_missing_test_name_raises(tmp_path):
    """A test entry without a 'name' field raises YAMLLoadError."""
    f = _write_yaml(tmp_path, """\
        tests:
          - input: "Hello"
            assert:
              - type: contains
                value: "hello"
    """)
    with pytest.raises(YAMLLoadError, match="missing required 'name' field"):
        load_yaml_tests(f)


def test_missing_input_and_conversation_raises(tmp_path):
    """A test with neither 'input' nor 'conversation' raises YAMLLoadError."""
    f = _write_yaml(tmp_path, """\
        tests:
          - name: Incomplete test
            assert:
              - type: contains
                value: "hello"
    """)
    with pytest.raises(YAMLLoadError, match="must have either 'input' or 'conversation'"):
        load_yaml_tests(f)


# --------------------------------------------------------------------------- #
# Discovery integration
# --------------------------------------------------------------------------- #


def test_discovery_finds_yaml_files(tmp_path):
    """discover_tests() picks up .yaml test files alongside .py files."""
    from tailtest.runner.discovery import discover_tests

    (tmp_path / "test_py.py").write_text("def test_from_python():\n    pass\n")
    _write_yaml(tmp_path, """\
        tests:
          - name: From YAML
            input: "Hello"
            assert:
              - type: contains
                value: "hello"
    """, filename="test_yaml.yaml")

    tests = discover_tests(tmp_path)
    names = [t.__name__ for t in tests]
    assert "test_from_python" in names
    assert "test_from_yaml" in names


def test_discovery_finds_yml_files(tmp_path):
    """discover_tests() also picks up .yml test files."""
    from tailtest.runner.discovery import discover_tests

    _write_yaml(tmp_path, """\
        tests:
          - name: YML test
            input: "Hello"
            assert:
              - type: contains
                value: "hello"
    """, filename="test_yml.yml")

    tests = discover_tests(tmp_path)
    assert len(tests) >= 1
    names = [t.__name__ for t in tests]
    assert "test_yml_test" in names
