"""Tests for the HTTP agent interface."""

import json
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from tailtest.models import AgentResponse
from tailtest.runner.interfaces.http import HTTPInterface


# --------------------------------------------------------------------------- #
# Helper  -  create a mock httpx.Response
# --------------------------------------------------------------------------- #


def _mock_response(status_code=200, json_body=None, text="", headers=None):
    """Build an httpx.Response without an actual HTTP request."""
    if json_body is not None:
        text = json.dumps(json_body)
    return httpx.Response(
        status_code=status_code,
        text=text,
        headers=headers or {"content-type": "application/json"},
        request=httpx.Request("POST", "http://test"),
    )


# --------------------------------------------------------------------------- #
# Transport-level tests using monkeypatch
# --------------------------------------------------------------------------- #


async def test_sends_post_request(monkeypatch):
    """HTTPInterface sends a POST request to the configured URL."""
    mock_request = AsyncMock(
        return_value=_mock_response(json_body={"response": "Hello from agent!"})
    )
    interface = HTTPInterface(
        url="http://localhost:8000/chat",
        response_content_path="response",
    )
    monkeypatch.setattr(interface._client, "request", mock_request)

    response = await interface.chat("Hello")
    await interface.close()

    assert isinstance(response, AgentResponse)
    assert response.content == "Hello from agent!"
    assert response.latency_ms is not None
    assert response.latency_ms > 0
    mock_request.assert_awaited_once()


async def test_handles_timeout(monkeypatch):
    """HTTPInterface returns an error response on timeout."""
    mock_request = AsyncMock(side_effect=httpx.TimeoutException("timed out"))
    interface = HTTPInterface(url="http://localhost:8000/chat", timeout=0.001)
    monkeypatch.setattr(interface._client, "request", mock_request)

    response = await interface.chat("Hello")
    await interface.close()

    assert isinstance(response, AgentResponse)
    assert response.content == ""
    assert response.metadata.get("error") == "timeout"


async def test_handles_non_200_status(monkeypatch):
    """HTTPInterface returns error metadata for non-200 status codes."""
    mock_request = AsyncMock(
        return_value=_mock_response(status_code=500, text="Internal Server Error")
    )
    interface = HTTPInterface(url="http://localhost:8000/chat")
    monkeypatch.setattr(interface._client, "request", mock_request)

    response = await interface.chat("Hello")
    await interface.close()

    assert isinstance(response, AgentResponse)
    assert response.content == ""
    assert "500" in response.metadata.get("error", "")


async def test_parses_json_response(monkeypatch):
    """HTTPInterface correctly parses a JSON response body."""
    mock_request = AsyncMock(
        return_value=_mock_response(json_body={"data": {"text": "Parsed!"}})
    )
    interface = HTTPInterface(
        url="http://localhost:8000/api/chat",
        response_content_path="data.text",
    )
    monkeypatch.setattr(interface._client, "request", mock_request)

    response = await interface.chat("Parse this")
    await interface.close()

    assert response.content == "Parsed!"


async def test_handles_connection_error(monkeypatch):
    """HTTPInterface returns error metadata on connection failure."""
    mock_request = AsyncMock(side_effect=httpx.ConnectError("Connection refused"))
    interface = HTTPInterface(url="http://localhost:9999/chat")
    monkeypatch.setattr(interface._client, "request", mock_request)

    response = await interface.chat("Hello")
    await interface.close()

    assert isinstance(response, AgentResponse)
    assert response.content == ""
    assert response.metadata.get("error") == "connection_error"
