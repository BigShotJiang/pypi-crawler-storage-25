"""Tests for the test runner engine  -  discovery, execution, and result collection."""

import asyncio

import pytest

from tailtest.models import AgentResponse, TestSuiteResult
from tailtest.runner.engine import RunConfig, TestRunner


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _write_test_file(path, content):
    """Write a Python test file and return its path."""
    path.write_text(content)
    return path


# --------------------------------------------------------------------------- #
# Passing tests
# --------------------------------------------------------------------------- #


async def test_runs_passing_tests(tmp_path):
    """Engine runs a simple passing test and reports pass."""
    _write_test_file(
        tmp_path / "test_pass.py",
        "def test_simple_pass():\n    assert 1 + 1 == 2\n",
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig())
    assert isinstance(result, TestSuiteResult)
    assert result.total >= 1
    assert result.passed >= 1


# --------------------------------------------------------------------------- #
# Failing tests
# --------------------------------------------------------------------------- #


async def test_runs_failing_tests(tmp_path):
    """Engine runs a failing test and reports failure."""
    _write_test_file(
        tmp_path / "test_fail.py",
        "def test_will_fail():\n    raise AssertionError('deliberate failure')\n",
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig())
    assert result.total >= 1
    assert result.failed >= 1


# --------------------------------------------------------------------------- #
# Timeouts
# --------------------------------------------------------------------------- #


async def test_handles_timeouts(tmp_path):
    """Engine marks a test as failed when it exceeds the timeout."""
    _write_test_file(
        tmp_path / "test_slow.py",
        "import asyncio\nasync def test_too_slow():\n    await asyncio.sleep(10)\n",
    )
    runner = TestRunner()
    config = RunConfig(timeout_ms=100)  # Very short timeout
    result = await runner.run(tmp_path, config=config)
    assert result.total >= 1
    assert result.failed >= 1
    # Check that the failure reason mentions timeout
    failing = [r for r in result.results if not r.passed]
    assert any("timed out" in (r.assertion_results[0].message or "") for r in failing)


# --------------------------------------------------------------------------- #
# Cost limits
# --------------------------------------------------------------------------- #


async def test_respects_cost_limits(tmp_path):
    """Engine skips remaining tests when cost_limit is exceeded."""
    _write_test_file(
        tmp_path / "test_costs.py",
        '''\
def test_a():
    pass

def test_b():
    pass

def test_c():
    pass
''',
    )
    runner = TestRunner()
    # With cost_limit=0.0 the first test runs (at 0 cost) then the limit is hit
    config = RunConfig(cost_limit=0.0)
    result = await runner.run(tmp_path, config=config)
    assert result.total >= 3
    assert result.skipped >= 1


# --------------------------------------------------------------------------- #
# Tag filtering
# --------------------------------------------------------------------------- #


async def test_tag_filtering_works(tmp_path):
    """Engine filters tests by tag when config.tags is set."""
    _write_test_file(
        tmp_path / "test_tagged.py",
        '''\
def test_untagged():
    pass

def test_tagged():
    pass

test_tagged._tailtest_tags = ["smoke"]
''',
    )
    runner = TestRunner()
    config = RunConfig(tags=["smoke"])
    result = await runner.run(tmp_path, config=config)
    # Only the tagged test should run
    assert result.total == 1
    assert result.passed == 1


# --------------------------------------------------------------------------- #
# Reliability mode
# --------------------------------------------------------------------------- #


async def test_reliability_mode_calculates_pass_rate(tmp_path):
    """Engine runs each test N times in reliability mode and computes a score."""
    _write_test_file(
        tmp_path / "test_reliable.py",
        "def test_always_passes():\n    pass\n",
    )
    runner = TestRunner()
    config = RunConfig(reliability=3)
    result = await runner.run(tmp_path, config=config)
    # Should run the test 3 times
    assert result.total == 3
    assert result.passed == 3
    assert result.reliability_score == 1.0


# --------------------------------------------------------------------------- #
# Empty suite
# --------------------------------------------------------------------------- #


async def test_empty_test_suite_returns_zero_results(tmp_path):
    """Engine returns an empty TestSuiteResult when no tests are found."""
    # tmp_path is empty  -  no test files
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig())
    assert result.total == 0
    assert result.passed == 0
    assert result.failed == 0
    assert result.results == []


# --------------------------------------------------------------------------- #
# Import errors
# --------------------------------------------------------------------------- #


async def test_handles_import_errors_in_test_files(tmp_path):
    """Engine produces a failing result when a test file cannot be imported."""
    _write_test_file(
        tmp_path / "test_broken_import.py",
        "from nonexistent_module import something\n\ndef test_x():\n    pass\n",
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig())
    # The file produces a synthetic failing test for the import error
    assert result.total >= 1
    assert result.failed >= 1


# --------------------------------------------------------------------------- #
# RunConfig from TailtestConfig
# --------------------------------------------------------------------------- #


def test_runconfig_from_tailtest_config():
    """RunConfig.from_tailtest_config merges defaults with overrides."""
    from tailtest.config.schema import TailtestConfig

    pc = TailtestConfig()
    rc = RunConfig.from_tailtest_config(pc, tags=["fast"], reliability=5)
    assert rc.tags == ["fast"]
    assert rc.reliability == 5
    assert rc.timeout_ms == pc.testing.timeout_ms
