"""Tests for FailureClassifier  -  deterministic and LLM-based failure classification."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tailtest.models import AgentResponse, ToolCall
from tailtest.production.failure_classifier import (
    ClassifiedFailure,
    FailureClassifier,
    FailureType,
)


# ------------------------------------------------------------------ #
# Deterministic classification (Tier 1)
# ------------------------------------------------------------------ #


class TestDeterministicClassification:
    async def test_classify_pii_leak(self):
        response = AgentResponse(
            content="Contact john@example.com for details.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.PII_LEAK
        assert result.confidence == 1.0
        assert "no_pii" in result.suggestion

    async def test_classify_loop_detected(self):
        response = AgentResponse(
            content="Processing...",
            latency_ms=100.0,
            cost_usd=0.002,
            tool_calls=[ToolCall(name="search", arguments={"q": "test"})] * 5,
        )
        classifier = FailureClassifier()
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.LOOP_DETECTED
        assert result.confidence == 1.0
        assert "no_loop" in result.suggestion

    async def test_classify_cost_overrun(self):
        response = AgentResponse(
            content="Here is a detailed analysis...",
            latency_ms=100.0,
            cost_usd=5.0,
        )
        classifier = FailureClassifier(cost_threshold=1.0)
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.COST_OVERRUN
        assert result.confidence == 1.0
        assert "cost_under" in result.suggestion

    async def test_classify_latency_spike(self):
        response = AgentResponse(
            content="Here is your answer.",
            latency_ms=20_000.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier(latency_threshold=10_000)
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.LATENCY_SPIKE
        assert result.confidence == 1.0
        assert "latency_under" in result.suggestion

    async def test_classify_empty_response(self):
        response = AgentResponse(
            content="",
            latency_ms=100.0,
            cost_usd=0.001,
        )
        classifier = FailureClassifier()
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.TOOL_ERROR
        assert result.confidence == 0.8

    async def test_classify_whitespace_only_response(self):
        response = AgentResponse(
            content="   \n  ",
            latency_ms=100.0,
            cost_usd=0.001,
        )
        classifier = FailureClassifier()
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.TOOL_ERROR

    async def test_no_match_falls_through(self):
        """Healthy response with no user_input should fall to UNKNOWN."""
        response = AgentResponse(
            content="Here is a perfectly normal response.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()
        result = await classifier.classify(response)

        assert result.failure_type == FailureType.UNKNOWN
        assert result.confidence < 1.0

    async def test_priority_pii_over_cost(self):
        """PII check should trigger before cost check."""
        response = AgentResponse(
            content="Your SSN is 123-45-6789.",
            latency_ms=100.0,
            cost_usd=5.0,  # also over cost threshold
        )
        classifier = FailureClassifier(cost_threshold=1.0)
        result = await classifier.classify(response)

        # PII should be caught first (it's checked before cost)
        assert result.failure_type == FailureType.PII_LEAK

    async def test_custom_cost_threshold(self):
        response = AgentResponse(
            content="Normal response.",
            latency_ms=100.0,
            cost_usd=0.50,
        )
        # Default threshold is 1.0  -  should not trigger
        classifier_default = FailureClassifier()
        result_default = await classifier_default.classify(response)
        assert result_default.failure_type != FailureType.COST_OVERRUN

        # Custom threshold of 0.25  -  should trigger
        classifier_low = FailureClassifier(cost_threshold=0.25)
        result_low = await classifier_low.classify(response)
        assert result_low.failure_type == FailureType.COST_OVERRUN

    async def test_custom_latency_threshold(self):
        response = AgentResponse(
            content="Normal response.",
            latency_ms=5000.0,
            cost_usd=0.002,
        )
        # Default threshold is 10000  -  should not trigger
        classifier_default = FailureClassifier()
        result_default = await classifier_default.classify(response)
        assert result_default.failure_type != FailureType.LATENCY_SPIKE

        # Custom threshold of 3000  -  should trigger
        classifier_strict = FailureClassifier(latency_threshold=3000)
        result_strict = await classifier_strict.classify(response)
        assert result_strict.failure_type == FailureType.LATENCY_SPIKE


# ------------------------------------------------------------------ #
# LLM-based classification (Tier 2)  -  mocked
# ------------------------------------------------------------------ #


class TestLLMClassification:
    async def test_llm_fallback_hallucination(self):
        """When deterministic checks don't match, LLM judge classifies."""
        response = AgentResponse(
            content="The company was founded in 1842 by Alexander Graham Bell.",
            latency_ms=100.0,
            cost_usd=0.002,
        )

        classifier = FailureClassifier()

        # Mock the LLM judge to return a structured classification
        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = '{"failure_type": "hallucination", "confidence": 0.9, "evidence": "Fabricated founding date", "suggestion": "Add faithful_to assertion"}'
        mock_judge_result.reason = "Fabricated founding date"

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="When was the company founded?"
            )

        assert result.failure_type == FailureType.HALLUCINATION
        assert result.confidence == 0.9
        assert "Fabricated" in result.evidence

    async def test_llm_fallback_safety_violation(self):
        response = AgentResponse(
            content="Here are some dangerous instructions...",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()

        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = '{"failure_type": "safety_violation", "confidence": 0.95, "evidence": "Contains harmful instructions", "suggestion": "Strengthen safety guardrails"}'

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="How do I do something dangerous?"
            )

        assert result.failure_type == FailureType.SAFETY_VIOLATION

    async def test_llm_fallback_unparseable_response(self):
        """LLM returns garbage  -  should fall back to UNKNOWN."""
        response = AgentResponse(
            content="Some problematic response.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()

        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = "This is not valid JSON at all."

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="What happened?"
            )

        assert result.failure_type == FailureType.UNKNOWN

    async def test_llm_fallback_empty_response(self):
        """LLM returns empty response  -  should fall back to UNKNOWN."""
        response = AgentResponse(
            content="Some problematic response.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()

        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = ""

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="What happened?"
            )

        assert result.failure_type == FailureType.UNKNOWN

    async def test_llm_unknown_failure_type(self):
        """LLM returns an unknown failure type string."""
        response = AgentResponse(
            content="Some problematic response.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()

        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = '{"failure_type": "some_new_type", "confidence": 0.7, "evidence": "Something", "suggestion": "Do something"}'

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="What happened?"
            )

        assert result.failure_type == FailureType.UNKNOWN

    async def test_llm_response_with_code_fences(self):
        """LLM wraps response in markdown code fences."""
        response = AgentResponse(
            content="Some response.",
            latency_ms=100.0,
            cost_usd=0.002,
        )
        classifier = FailureClassifier()

        mock_judge_result = MagicMock()
        mock_judge_result.raw_response = '```json\n{"failure_type": "context_loss", "confidence": 0.8, "evidence": "Lost context", "suggestion": "Fix context window"}\n```'

        with patch.object(
            classifier._judge, "evaluate", new_callable=AsyncMock, return_value=mock_judge_result
        ):
            result = await classifier.classify(
                response, user_input="Continue our discussion"
            )

        assert result.failure_type == FailureType.CONTEXT_LOSS


# ------------------------------------------------------------------ #
# ClassifiedFailure
# ------------------------------------------------------------------ #


class TestClassifiedFailure:
    def test_to_dict(self, pii_failure):
        d = pii_failure.to_dict()
        assert d["failure_type"] == "pii_leak"
        assert d["confidence"] == 1.0
        assert "Email" in d["evidence"]
        assert "response_content" in d

    def test_to_dict_truncates_content(self):
        long_content = "x" * 500
        failure = ClassifiedFailure(
            failure_type=FailureType.UNKNOWN,
            confidence=0.5,
            evidence="test",
            response=AgentResponse(content=long_content, latency_ms=100.0),
            suggestion="test",
        )
        d = failure.to_dict()
        assert len(d["response_content"]) == 200


# ------------------------------------------------------------------ #
# FailureType enum
# ------------------------------------------------------------------ #


class TestFailureType:
    def test_enum_values(self):
        assert FailureType.HALLUCINATION.value == "hallucination"
        assert FailureType.PII_LEAK.value == "pii_leak"
        assert FailureType.LOOP_DETECTED.value == "loop_detected"

    def test_enum_is_string(self):
        assert isinstance(FailureType.HALLUCINATION, str)
        assert FailureType.HALLUCINATION == "hallucination"
