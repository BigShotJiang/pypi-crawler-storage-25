"""Tests for multi-target configuration (Phase 7D)."""

from __future__ import annotations

import pytest

from tailtest.config.schema import AgentConfig, TailtestConfig


class TestMultiTargetConfig:
    def test_default_config_has_empty_targets(self):
        config = TailtestConfig()
        assert config.targets == {}

    def test_get_agent_returns_default_when_no_target(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000/chat"),
        )
        agent = config.get_agent()
        assert agent.url == "http://default:8000/chat"

    def test_get_agent_returns_named_target(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000/chat"),
            targets={
                "staging": AgentConfig(
                    type="http", url="http://staging:8000/chat"
                ),
                "production": AgentConfig(
                    type="http", url="http://prod:8000/chat"
                ),
            },
        )
        staging = config.get_agent("staging")
        assert staging.url == "http://staging:8000/chat"

        prod = config.get_agent("production")
        assert prod.url == "http://prod:8000/chat"

    def test_get_agent_falls_back_for_unknown_target(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000/chat"),
            targets={"staging": AgentConfig(type="http", url="http://staging:8000/chat")},
        )
        agent = config.get_agent("nonexistent")
        assert agent.url == "http://default:8000/chat"

    def test_get_agent_none_returns_default(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000/chat"),
            targets={"staging": AgentConfig(type="http", url="http://staging:8000/chat")},
        )
        agent = config.get_agent(None)
        assert agent.url == "http://default:8000/chat"

    def test_targets_can_have_different_types(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000/chat"),
            targets={
                "local_fn": AgentConfig(type="python", function="agent:run"),
                "remote": AgentConfig(
                    type="http", url="https://api.example.com/chat"
                ),
                "cli_mode": AgentConfig(type="cli", command="python agent.py"),
            },
        )
        assert config.get_agent("local_fn").type == "python"
        assert config.get_agent("remote").type == "http"
        assert config.get_agent("cli_mode").type == "cli"

    def test_config_from_dict_with_targets(self):
        data = {
            "version": "1",
            "agent": {"type": "http", "url": "http://localhost:8000/chat"},
            "targets": {
                "staging": {
                    "type": "http",
                    "url": "http://staging:8000/chat",
                },
            },
        }
        config = TailtestConfig.model_validate(data)
        assert "staging" in config.targets
        assert config.targets["staging"].url == "http://staging:8000/chat"

    def test_config_serialization_roundtrip(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000"),
            targets={
                "prod": AgentConfig(type="http", url="http://prod:8000"),
            },
        )
        data = config.model_dump()
        restored = TailtestConfig.model_validate(data)
        assert restored.targets["prod"].url == "http://prod:8000"

    def test_empty_string_target_returns_default(self):
        config = TailtestConfig(
            agent=AgentConfig(type="http", url="http://default:8000"),
            targets={"staging": AgentConfig(type="http", url="http://staging:8000")},
        )
        # Empty string is falsy, so it should return default
        agent = config.get_agent("")
        assert agent.url == "http://default:8000"
