"""Tests for CLI subcommands using click.testing.CliRunner."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tailtest.cli.main import cli


@pytest.fixture
def runner():
    return CliRunner()


# ── init ──────────────────────────────────────────────────────────────────────


class TestInitCommand:
    def test_init_creates_tailtest_dir(self, runner: CliRunner, tmp_path: Path):
        """tailtest init --no-wizard should create .tailtest/ directory structure."""
        result = runner.invoke(cli, ["init", "--no-wizard"], catch_exceptions=False)
        # The command runs in cwd, which we can't easily change with
        # CliRunner for file-creating commands. Verify it at least
        # exits successfully and mentions initialization.
        assert "initialized" in result.output.lower() or result.exit_code == 0

    def test_init_help(self, runner: CliRunner):
        """tailtest init --help should show usage."""
        result = runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0
        assert "Initialize" in result.output

    def test_init_with_framework(self, runner: CliRunner):
        """tailtest init --framework langchain should accept the framework."""
        result = runner.invoke(cli, ["init", "--no-wizard", "--framework", "langchain"])
        # Should not crash
        assert result.exit_code == 0


# ── scan ──────────────────────────────────────────────────────────────────────


class TestScanCommand:
    def test_scan_runs_without_error(self, runner: CliRunner, tmp_path: Path):
        """tailtest scan on a valid directory should not crash."""
        # Create a minimal Python file
        (tmp_path / "agent.py").write_text("def agent(msg): return msg\n")
        result = runner.invoke(cli, ["scan", str(tmp_path)])
        assert result.exit_code == 0
        assert "scan" in result.output.lower()

    def test_scan_help(self, runner: CliRunner):
        """tailtest scan --help should show options."""
        result = runner.invoke(cli, ["scan", "--help"])
        assert result.exit_code == 0
        assert "PATH" in result.output or "path" in result.output.lower()


# ── run ───────────────────────────────────────────────────────────────────────


class TestRunCommand:
    def test_run_with_no_tests_found(self, runner: CliRunner, tmp_path: Path):
        """tailtest run on an empty directory should report no tests."""
        result = runner.invoke(cli, ["run", str(tmp_path)])
        # Should either report 0 tests or say no test files found
        assert result.exit_code == 0 or "No test files found" in result.output or "0 tests" in result.output.lower()

    def test_run_help(self, runner: CliRunner):
        """tailtest run --help should show options."""
        result = runner.invoke(cli, ["run", "--help"])
        assert result.exit_code == 0
        assert "PATH" in result.output or "parallel" in result.output


# ── doctor ────────────────────────────────────────────────────────────────────


class TestDoctorCommand:
    def test_doctor_shows_health(self, runner: CliRunner):
        """tailtest doctor should show health checks."""
        result = runner.invoke(cli, ["doctor"])
        assert result.exit_code == 0
        assert "Python" in result.output
        assert "pydantic" in result.output or "click" in result.output

    def test_doctor_help(self, runner: CliRunner):
        """tailtest doctor --help should describe the command."""
        result = runner.invoke(cli, ["doctor", "--help"])
        assert result.exit_code == 0
        assert "health" in result.output.lower()


# ── report ────────────────────────────────────────────────────────────────────


class TestReportCommand:
    def test_report_no_data(self, runner: CliRunner):
        """tailtest report with no data should not crash."""
        result = runner.invoke(cli, ["report"])
        # Should complete (exit 0) even without data
        assert result.exit_code == 0

    def test_report_help(self, runner: CliRunner):
        """tailtest report --help should list format options."""
        result = runner.invoke(cli, ["report", "--help"])
        assert result.exit_code == 0
        assert "html" in result.output.lower() or "format" in result.output.lower()


# ── redteam ───────────────────────────────────────────────────────────────────


class TestRedteamCommand:
    def test_redteam_help(self, runner: CliRunner):
        """tailtest redteam --help should show adversarial testing info."""
        result = runner.invoke(cli, ["redteam", "--help"])
        assert result.exit_code == 0
        assert "red-team" in result.output.lower() or "adversarial" in result.output.lower()


# ── generate ──────────────────────────────────────────────────────────────────


class TestGenerateCommand:
    def test_generate_no_context(self, runner: CliRunner, tmp_path: Path):
        """tailtest generate without prior scan should show an error message."""
        result = runner.invoke(cli, ["generate", "--project-dir", str(tmp_path)])
        # Should fail because no scan context exists
        assert result.exit_code != 0 or "no scan context" in result.output.lower() or "scan" in result.output.lower()

    def test_generate_help(self, runner: CliRunner):
        """tailtest generate --help should show options."""
        result = runner.invoke(cli, ["generate", "--help"])
        assert result.exit_code == 0
        assert "generate" in result.output.lower()


# ── guard ─────────────────────────────────────────────────────────────────────


class TestGuardCommand:
    def test_guard_help(self, runner: CliRunner):
        """tailtest guard --help should describe the validation proxy."""
        result = runner.invoke(cli, ["guard", "--help"])
        assert result.exit_code == 0
        assert "upstream" in result.output.lower() or "proxy" in result.output.lower()


# ── ingest ────────────────────────────────────────────────────────────────────


class TestIngestCommand:
    def test_ingest_help(self, runner: CliRunner):
        """tailtest ingest --help should describe trace ingestion."""
        result = runner.invoke(cli, ["ingest", "--help"])
        assert result.exit_code == 0
        assert "ingest" in result.output.lower() or "traces" in result.output.lower()


# ── drift ─────────────────────────────────────────────────────────────────────


class TestDriftCommand:
    def test_drift_help(self, runner: CliRunner):
        """tailtest drift --help should describe drift detection."""
        result = runner.invoke(cli, ["drift", "--help"])
        assert result.exit_code == 0
        assert "drift" in result.output.lower() or "baseline" in result.output.lower()
