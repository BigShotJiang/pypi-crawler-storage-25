"""Tests for the interactive init wizard (Phase 7D)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from tailtest.cli.main import cli
from tailtest.cli.init_cmd import (
    _quick_cli,
    _quick_http,
    _quick_python,
    _quick_ssh,
    _test_cli_command,
    _test_http_connection,
    _test_python_function,
    _test_ssh_connection,
)


@pytest.fixture
def runner():
    return CliRunner()


# ---------------------------------------------------------------------------
# Quick mode flags
# ---------------------------------------------------------------------------


class TestQuickModeHTTP:
    def test_init_http_creates_config(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["init", "--http", "http://localhost:9000/chat"]
            )
            assert result.exit_code == 0
            assert "initialized" in result.output.lower()
            config = Path("tailtest.yaml").read_text()
            assert "http://localhost:9000/chat" in config
            assert "type: http" in config

    def test_quick_http_generates_valid_yaml(self):
        content = _quick_http("http://localhost:8000/api")
        assert "url:" in content
        assert "http://localhost:8000/api" in content
        assert "version:" in content


class TestQuickModeSSH:
    def test_init_ssh_creates_config(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["init", "--ssh", "user@example.com", "--key", "/tmp/id_rsa"]
            )
            assert result.exit_code == 0
            config = Path("tailtest.yaml").read_text()
            assert "ssh" in config.lower() or "user" in config.lower()

    def test_quick_ssh_generates_valid_yaml(self):
        content = _quick_ssh("deploy@staging.example.com", "/home/deploy/.ssh/id_rsa", None)
        assert "ssh" in content.lower()
        assert "staging.example.com" in content


class TestQuickModePython:
    def test_init_python_creates_config(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["init", "--python", "myagent:run"]
            )
            assert result.exit_code == 0
            config = Path("tailtest.yaml").read_text()
            assert "myagent:run" in config
            assert "type: python" in config

    def test_quick_python_generates_valid_yaml(self):
        content = _quick_python("agent:handle")
        assert "agent:handle" in content
        assert "type: python" in content


class TestQuickModeCLI:
    def test_init_cli_creates_config(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["init", "--cli", "python run_agent.py"]
            )
            assert result.exit_code == 0
            config = Path("tailtest.yaml").read_text()
            assert "python run_agent.py" in config
            assert "type: cli" in config

    def test_quick_cli_generates_valid_yaml(self):
        content = _quick_cli("node agent.js")
        assert "node agent.js" in content
        assert "type: cli" in content


# ---------------------------------------------------------------------------
# No-wizard (legacy) mode
# ---------------------------------------------------------------------------


class TestNoWizardMode:
    def test_no_wizard_creates_legacy_config(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["init", "--no-wizard", "--framework", "langchain"]
            )
            assert result.exit_code == 0
            assert "initialized" in result.output.lower()
            config = Path("tailtest.yaml").read_text()
            assert "langchain" in config

    def test_no_wizard_without_framework(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init", "--no-wizard"])
            assert result.exit_code == 0
            config = Path("tailtest.yaml").read_text()
            assert "auto" in config


# ---------------------------------------------------------------------------
# Directory structure creation
# ---------------------------------------------------------------------------


class TestDirectoryCreation:
    def test_creates_tailtest_directories(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init", "--no-wizard"])
            assert result.exit_code == 0
            assert Path(".tailtest/tests/auto").is_dir()
            assert Path(".tailtest/tests/custom").is_dir()
            assert Path(".tailtest/reports").is_dir()
            assert Path(".tailtest/recordings").is_dir()

    def test_reinit_shows_warning(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            runner.invoke(cli, ["init", "--no-wizard"])
            result = runner.invoke(cli, ["init", "--no-wizard"])
            assert "already exists" in result.output.lower() or result.exit_code == 0


# ---------------------------------------------------------------------------
# Connection testing helpers
# ---------------------------------------------------------------------------


class TestConnectionHelpers:
    def test_test_cli_command_found(self):
        import sys
        exe = sys.executable  # guaranteed to exist
        ok, msg = _test_cli_command(f"{exe} --version")
        assert ok is True

    def test_test_cli_command_not_found(self):
        ok, msg = _test_cli_command("nonexistent_binary_xyz123")
        assert ok is False
        assert "not found" in msg.lower()

    def test_test_python_function_bad_module(self):
        ok, msg = _test_python_function("nonexistent_module_xyz:func")
        assert ok is False

    def test_test_http_connection_success(self):
        """Test HTTP connection helper with a mocked httpx client."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"ok"

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("httpx.Client", return_value=mock_client):
            ok, msg = _test_http_connection("http://localhost:8000/chat")
            assert ok is True
            assert "200" in msg

    def test_test_ssh_connection_no_ssh(self):
        # This will fail if ssh isn't available, which is fine
        ok, msg = _test_ssh_connection("nonexistent-host-xyz123.local")
        assert ok is False
