"""Tests for the Intelligence Engine (Layer fusion)."""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from tailtest.intelligence.cache import UnderstandingCache
from tailtest.intelligence.engine import IntelligenceEngine, IntelligenceResult
from tailtest.intelligence.rules_loader import RulesLoader, Scenario, UserRules
from tailtest.intelligence.rules_to_tests import GeneratedTest
from tailtest.intelligence.understanding import CodeUnderstanding, UnderstandingResult
from tailtest.models import (
    PromptDefinition,
    ScanResult,
    ToolDefinition,
)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_scan_result(
    tools: list[ToolDefinition] | None = None,
    prompts: list[PromptDefinition] | None = None,
) -> ScanResult:
    return ScanResult(
        framework="openai",
        tools=tools or [],
        prompts=prompts or [],
        agents=[],
        models=["gpt-4"],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


def _mock_analysis_completion(analysis: dict, cost: float = 0.001):
    content = json.dumps(analysis)
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=200, completion_tokens=100, total_tokens=300)
    return SimpleNamespace(choices=[choice], usage=usage)


SAMPLE_ANALYSIS = {
    "domain": "accounting",
    "invariants": ["debits must equal credits"],
    "failure_modes": ["rounding errors"],
    "edge_cases": ["zero-amount invoice"],
    "data_validation": ["amount > 0"],
}


SAMPLE_CODE = """
def create_invoice(customer_id, amount):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    return {"customer_id": customer_id, "amount": amount}
"""


# ── IntelligenceResult ───────────────────────────────────────────────────────


class TestIntelligenceResult:
    def test_structural_tests_filter(self):
        result = IntelligenceResult(
            generated_tests=[
                GeneratedTest(name="t1", code="", tags=["structural"]),
                GeneratedTest(name="t2", code="", tags=["llm-inferred"]),
                GeneratedTest(name="t3", code="", tags=["user-rule"]),
            ]
        )
        assert len(result.structural_tests) == 1
        assert result.structural_tests[0].name == "t1"

    def test_llm_inferred_tests_filter(self):
        result = IntelligenceResult(
            generated_tests=[
                GeneratedTest(name="t1", code="", tags=["structural"]),
                GeneratedTest(name="t2", code="", tags=["llm-inferred"]),
            ]
        )
        assert len(result.llm_inferred_tests) == 1
        assert result.llm_inferred_tests[0].name == "t2"

    def test_user_rule_tests_filter(self):
        result = IntelligenceResult(
            generated_tests=[
                GeneratedTest(name="t1", code="", tags=["user-rule"]),
                GeneratedTest(name="t2", code="", tags=["user-rule", "never"]),
            ]
        )
        assert len(result.user_rule_tests) == 2

    def test_empty_result(self):
        result = IntelligenceResult()
        assert result.structural_tests == []
        assert result.llm_inferred_tests == []
        assert result.user_rule_tests == []


# ── IntelligenceEngine ───────────────────────────────────────────────────────


class TestIntelligenceEngine:
    @pytest.fixture
    def cache(self, tmp_path):
        return UnderstandingCache(cache_dir=tmp_path / "cache")

    @pytest.fixture
    def rules_file(self, tmp_path):
        rules_dir = tmp_path / ".tailtest"
        rules_dir.mkdir(parents=True, exist_ok=True)
        rules_path = rules_dir / "rules.yaml"
        rules_path.write_text(
            'rules:\n  - "Refunds need approval"\n'
            'never:\n  - "Reveal secrets"\n'
        )
        return tmp_path

    async def test_structural_only(self, tmp_path, cache):
        scan = _make_scan_result(
            tools=[
                ToolDefinition(name="create_invoice", parameters={}),
                ToolDefinition(name="delete_invoice", parameters={}),
            ]
        )
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        result = await engine.analyse(scan_result=scan)
        assert len(result.structural_tests) == 2
        assert all("structural" in t.tags for t in result.structural_tests)

    async def test_structural_with_prompts(self, tmp_path, cache):
        scan = _make_scan_result(
            prompts=[
                PromptDefinition(content="You are a helpful assistant", file_path="main.py"),
            ]
        )
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        result = await engine.analyse(scan_result=scan)
        assert len(result.structural_tests) == 1
        assert "structural" in result.structural_tests[0].tags

    async def test_llm_understanding(self, tmp_path, cache):
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)

        engine = IntelligenceEngine(
            project_dir=tmp_path,
            understanding=CodeUnderstanding(cache=cache),
        )

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.005):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/invoice.py", SAMPLE_CODE)],
                )

        assert len(result.understanding) == 1
        assert result.understanding[0].domain == "accounting"
        assert len(result.llm_inferred_tests) > 0
        assert all("llm-inferred" in t.tags for t in result.llm_inferred_tests)

    async def test_user_rules(self, rules_file, cache):
        engine = IntelligenceEngine(
            project_dir=rules_file,
            cache=cache,
        )
        result = await engine.analyse()
        assert len(result.user_rule_tests) == 2
        assert result.user_rules is not None
        assert not result.user_rules.is_empty

    async def test_all_three_layers(self, rules_file, cache):
        scan = _make_scan_result(
            tools=[ToolDefinition(name="process_refund", parameters={})],
        )
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)

        engine = IntelligenceEngine(
            project_dir=rules_file,
            understanding=CodeUnderstanding(cache=cache),
        )

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    scan_result=scan,
                    understand=True,
                    files=[("src/refund.py", SAMPLE_CODE)],
                )

        assert len(result.structural_tests) >= 1
        assert len(result.llm_inferred_tests) >= 1
        assert len(result.user_rule_tests) >= 1
        # Total should be the sum (no duplicates expected with unique names)
        total = (
            len(result.structural_tests)
            + len(result.llm_inferred_tests)
            + len(result.user_rule_tests)
        )
        assert len(result.generated_tests) == total

    async def test_deduplication(self, tmp_path, cache):
        """Tests with the same name from different sources get deduplicated."""
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        # Manually test the dedup method
        tests = [
            GeneratedTest(name="test_foo", code="1", tags=["structural"]),
            GeneratedTest(name="test_foo", code="2", tags=["llm-inferred"]),
            GeneratedTest(name="test_bar", code="3", tags=["user-rule"]),
        ]
        deduped = engine._deduplicate(tests)
        assert len(deduped) == 2
        # First occurrence wins
        assert deduped[0].tags == ["structural"]
        assert deduped[1].name == "test_bar"

    async def test_no_llm_without_understand_flag(self, tmp_path, cache):
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        result = await engine.analyse(
            files=[("src/code.py", SAMPLE_CODE)],
        )
        assert result.understanding == []
        assert result.llm_inferred_tests == []

    async def test_empty_analyse(self, tmp_path, cache):
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        result = await engine.analyse()
        assert result.generated_tests == []
        assert result.total_cost_usd == 0.0

    async def test_cost_tracking(self, tmp_path, cache):
        analysis_1 = {**SAMPLE_ANALYSIS, "domain": "finance"}
        analysis_2 = {**SAMPLE_ANALYSIS, "domain": "ecommerce"}
        mock_resps = [
            _mock_analysis_completion(analysis_1),
            _mock_analysis_completion(analysis_2),
        ]

        engine = IntelligenceEngine(
            project_dir=tmp_path,
            understanding=CodeUnderstanding(cache=cache),
        )

        with patch("litellm.acompletion", new_callable=AsyncMock, side_effect=mock_resps):
            with patch("litellm.completion_cost", return_value=0.003):
                result = await engine.analyse(
                    understand=True,
                    files=[
                        ("src/a.py", "code_a"),
                        ("src/b.py", "code_b"),
                    ],
                )

        assert result.total_cost_usd == pytest.approx(0.006)

    async def test_progress_callback(self, tmp_path, cache):
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)
        progress_calls = []

        def on_progress(current, total, path):
            progress_calls.append((current, total, path))

        engine = IntelligenceEngine(
            project_dir=tmp_path,
            understanding=CodeUnderstanding(cache=cache),
        )

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                await engine.analyse(
                    understand=True,
                    files=[("f1.py", "c1"), ("f2.py", "c2")],
                    on_progress=on_progress,
                )

        assert len(progress_calls) == 2

    async def test_llm_tests_from_understanding(self, tmp_path, cache):
        """Verify LLM understanding generates tests for invariants, failure modes, etc."""
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=cache,
        )
        ur = UnderstandingResult(
            domain="accounting",
            invariants=["debits = credits", "no negative balances"],
            failure_modes=["double posting"],
            edge_cases=["zero amount"],
            data_validation=["amount must be numeric"],
        )
        tests = engine._generate_llm_tests([ur])
        # 2 invariants + 1 failure mode + 1 edge case + 1 data validation = 5
        assert len(tests) == 5
        assert all("llm-inferred" in t.tags for t in tests)
