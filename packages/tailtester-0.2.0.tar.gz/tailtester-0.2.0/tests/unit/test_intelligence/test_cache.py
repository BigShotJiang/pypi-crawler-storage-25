"""Tests for the understanding cache."""

from __future__ import annotations

import json

import pytest

from tailtest.intelligence.cache import UnderstandingCache, content_hash


class TestContentHash:
    def test_returns_hex_string(self):
        h = content_hash("hello world")
        assert isinstance(h, str)
        assert len(h) == 64  # SHA-256 hex digest

    def test_deterministic(self):
        assert content_hash("foo") == content_hash("foo")

    def test_different_for_different_input(self):
        assert content_hash("foo") != content_hash("bar")

    def test_empty_string(self):
        h = content_hash("")
        assert isinstance(h, str)
        assert len(h) == 64


class TestUnderstandingCache:
    @pytest.fixture
    def cache(self, tmp_path):
        return UnderstandingCache(cache_dir=tmp_path / "cache")

    @pytest.fixture
    def sample_result(self):
        return {
            "domain": "accounting",
            "invariants": ["debits = credits"],
            "failure_modes": ["rounding errors"],
            "edge_cases": ["zero amount"],
            "data_validation": ["amount > 0"],
        }

    def test_save_creates_file(self, cache, sample_result):
        path = cache.save("src/main.py", "abc123", sample_result)
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["file_path"] == "src/main.py"
        assert data["content_hash"] == "abc123"
        assert data["result"] == sample_result

    def test_load_returns_cached_result(self, cache, sample_result):
        cache.save("src/main.py", "abc123", sample_result)
        loaded = cache.load("src/main.py", "abc123")
        assert loaded == sample_result

    def test_load_returns_none_when_missing(self, cache):
        assert cache.load("nonexistent.py", "hash123") is None

    def test_load_returns_none_on_hash_mismatch(self, cache, sample_result):
        cache.save("src/main.py", "abc123", sample_result)
        assert cache.load("src/main.py", "different_hash") is None

    def test_invalidate_removes_entries(self, cache, sample_result):
        cache.save("src/main.py", "hash1", sample_result)
        cache.save("src/main.py", "hash2", sample_result)
        removed = cache.invalidate("src/main.py")
        assert removed == 2
        assert cache.load("src/main.py", "hash1") is None
        assert cache.load("src/main.py", "hash2") is None

    def test_invalidate_returns_zero_when_nothing_to_remove(self, cache):
        assert cache.invalidate("nonexistent.py") == 0

    def test_clear_removes_all(self, cache, sample_result):
        cache.save("src/a.py", "h1", sample_result)
        cache.save("src/b.py", "h2", sample_result)
        removed = cache.clear()
        assert removed == 2
        assert cache.load("src/a.py", "h1") is None
        assert cache.load("src/b.py", "h2") is None

    def test_clear_returns_zero_when_empty(self, cache):
        assert cache.clear() == 0

    def test_load_handles_corrupt_json(self, cache, tmp_path):
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        # Write a corrupt file that matches the expected pattern.
        cache.save("src/main.py", "abc123", {"domain": "test"})
        # Corrupt the cached file.
        for f in cache_dir.glob("*.json"):
            f.write_text("not valid json")
        assert cache.load("src/main.py", "abc123") is None

    def test_cache_dir_created_on_first_save(self, tmp_path, sample_result):
        cache_dir = tmp_path / "deep" / "nested" / "cache"
        cache = UnderstandingCache(cache_dir=cache_dir)
        cache.save("src/main.py", "abc123", sample_result)
        assert cache_dir.exists()
