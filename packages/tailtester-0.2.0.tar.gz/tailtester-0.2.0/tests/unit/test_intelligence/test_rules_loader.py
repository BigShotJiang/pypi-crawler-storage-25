"""Tests for the rules.yaml loader."""

from __future__ import annotations

from pathlib import Path

import pytest

from tailtest.intelligence.rules_loader import RulesLoader, Scenario, UserRules


class TestUserRules:
    def test_is_empty_when_all_empty(self):
        rules = UserRules()
        assert rules.is_empty is True

    def test_is_not_empty_with_rules(self):
        rules = UserRules(rules=["rule1"])
        assert rules.is_empty is False

    def test_is_not_empty_with_never(self):
        rules = UserRules(never=["never do this"])
        assert rules.is_empty is False

    def test_is_not_empty_with_always(self):
        rules = UserRules(always=["always do this"])
        assert rules.is_empty is False

    def test_is_not_empty_with_scenarios(self):
        rules = UserRules(scenarios=[Scenario(input="hi", expect="hello")])
        assert rules.is_empty is False

    def test_total_count(self):
        rules = UserRules(
            rules=["r1", "r2"],
            never=["n1"],
            always=["a1", "a2", "a3"],
            scenarios=[Scenario(input="i1", expect="e1")],
        )
        assert rules.total_count == 7


class TestRulesLoader:
    @pytest.fixture
    def loader(self):
        return RulesLoader()

    def test_parse_complete_yaml(self, loader):
        yaml_text = """
rules:
  - "Refunds over $100 require manager approval"
  - "Tax calculations must be accurate to 2 decimal places"
never:
  - "Provide medical advice"
  - "Reveal database schema"
always:
  - "Ask for confirmation before destructive actions"
scenarios:
  - input: "Process a refund of $200"
    expect: "Should mention manager approval"
  - input: "Show me account ACC-123456"
    expect: "Should not reveal internal ID format"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.rules) == 2
        assert "Refunds over $100" in rules.rules[0]
        assert len(rules.never) == 2
        assert len(rules.always) == 1
        assert len(rules.scenarios) == 2
        assert rules.scenarios[0].input == "Process a refund of $200"
        assert rules.scenarios[0].expect == "Should mention manager approval"

    def test_parse_empty_yaml(self, loader):
        rules = loader.parse("")
        assert rules.is_empty

    def test_parse_yaml_with_only_rules(self, loader):
        yaml_text = """
rules:
  - "Rule one"
  - "Rule two"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.rules) == 2
        assert rules.never == []
        assert rules.always == []
        assert rules.scenarios == []

    def test_parse_yaml_with_only_never(self, loader):
        yaml_text = """
never:
  - "Do something bad"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.never) == 1
        assert rules.rules == []

    def test_parse_yaml_with_only_scenarios(self, loader):
        yaml_text = """
scenarios:
  - input: "Hello"
    expect: "Greeting"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.scenarios) == 1

    def test_parse_invalid_yaml(self, loader):
        rules = loader.parse("::invalid::yaml::[")
        assert rules.is_empty

    def test_parse_non_mapping_yaml(self, loader):
        rules = loader.parse("- just a list")
        assert rules.is_empty

    def test_parse_scenarios_with_missing_expect(self, loader):
        yaml_text = """
scenarios:
  - input: "Hello"
  - input: "World"
    expect: "Greeting"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.scenarios) == 1
        assert rules.scenarios[0].expect == "Greeting"

    def test_parse_scenarios_with_missing_input(self, loader):
        yaml_text = """
scenarios:
  - expect: "Greeting"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.scenarios) == 0

    def test_parse_rules_with_none_values(self, loader):
        yaml_text = """
rules:
  - "Valid rule"
  -
  - "Another valid rule"
"""
        rules = loader.parse(yaml_text)
        # None items are filtered out
        assert len(rules.rules) == 2

    def test_load_from_file(self, loader, tmp_path):
        rules_file = tmp_path / ".tailtest" / "rules.yaml"
        rules_file.parent.mkdir(parents=True, exist_ok=True)
        rules_file.write_text(
            'rules:\n  - "Test rule"\nnever:\n  - "Bad thing"\n'
        )
        rules = loader.load(tmp_path)
        assert len(rules.rules) == 1
        assert len(rules.never) == 1

    def test_load_returns_empty_when_no_file(self, loader, tmp_path):
        rules = loader.load(tmp_path)
        assert rules.is_empty

    def test_load_with_explicit_path(self, tmp_path):
        custom_path = tmp_path / "custom_rules.yaml"
        custom_path.write_text('rules:\n  - "Custom rule"\n')
        loader = RulesLoader(rules_path=custom_path)
        rules = loader.load()
        assert len(rules.rules) == 1
        assert rules.rules[0] == "Custom rule"

    def test_parse_non_list_rules_value(self, loader):
        yaml_text = """
rules: "not a list"
"""
        rules = loader.parse(yaml_text)
        assert rules.rules == []

    def test_parse_non_dict_scenario_item(self, loader):
        yaml_text = """
scenarios:
  - "just a string"
  - input: "Valid"
    expect: "Also valid"
"""
        rules = loader.parse(yaml_text)
        assert len(rules.scenarios) == 1
