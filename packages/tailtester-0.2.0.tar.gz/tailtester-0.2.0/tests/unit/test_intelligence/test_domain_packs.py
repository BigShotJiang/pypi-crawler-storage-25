"""Tests for domain knowledge packs (Phase 8D).

Validates that all four built-in domain packs (accounting, healthcare,
ecommerce, support) provide correct invariants, never/always rules,
and scenarios.  Also tests the registry, base class, and edge cases.
"""

from __future__ import annotations

import pytest

from tailtest.intelligence.domain_packs import (
    get_domain_pack,
    list_domain_packs,
    register_pack,
)
from tailtest.intelligence.domain_packs.accounting import AccountingPack
from tailtest.intelligence.domain_packs.base import BaseDomainPack, DomainInvariant
from tailtest.intelligence.domain_packs.ecommerce import EcommercePack
from tailtest.intelligence.domain_packs.healthcare import HealthcarePack
from tailtest.intelligence.domain_packs.support import SupportPack


# --------------------------------------------------------------------------- #
# Registry tests
# --------------------------------------------------------------------------- #


class TestRegistry:
    """Tests for the domain pack registry."""

    def test_list_domain_packs_returns_all_four(self):
        packs = list_domain_packs()
        assert "accounting" in packs
        assert "healthcare" in packs
        assert "ecommerce" in packs
        assert "support" in packs

    def test_get_domain_pack_returns_correct_type(self):
        assert isinstance(get_domain_pack("accounting"), AccountingPack)
        assert isinstance(get_domain_pack("healthcare"), HealthcarePack)
        assert isinstance(get_domain_pack("ecommerce"), EcommercePack)
        assert isinstance(get_domain_pack("support"), SupportPack)

    def test_get_unknown_pack_raises_valueerror(self):
        with pytest.raises(ValueError, match="Unknown domain pack 'nonexistent'"):
            get_domain_pack("nonexistent")

    def test_unknown_pack_error_lists_available(self):
        with pytest.raises(ValueError, match="accounting"):
            get_domain_pack("bad_name")

    def test_register_custom_pack(self):
        class CustomPack(BaseDomainPack):
            name = "custom_test_pack"
            description = "Test pack"

        register_pack(CustomPack)
        assert "custom_test_pack" in list_domain_packs()
        pack = get_domain_pack("custom_test_pack")
        assert isinstance(pack, CustomPack)


# --------------------------------------------------------------------------- #
# Base class tests
# --------------------------------------------------------------------------- #


class TestBaseDomainPack:
    """Tests for BaseDomainPack defaults."""

    def test_base_returns_empty_invariants(self):
        base = BaseDomainPack()
        assert base.get_invariants() == []

    def test_base_returns_empty_never_rules(self):
        base = BaseDomainPack()
        assert base.get_never_rules() == []

    def test_base_returns_empty_always_rules(self):
        base = BaseDomainPack()
        assert base.get_always_rules() == []

    def test_base_returns_empty_scenarios(self):
        base = BaseDomainPack()
        assert base.get_scenarios() == []


class TestDomainInvariant:
    """Tests for the DomainInvariant dataclass."""

    def test_invariant_fields(self):
        inv = DomainInvariant(
            rule="Test rule",
            test_assertion="matches_rubric",
            test_input="Test input",
            severity="critical",
        )
        assert inv.rule == "Test rule"
        assert inv.test_assertion == "matches_rubric"
        assert inv.test_input == "Test input"
        assert inv.severity == "critical"


# --------------------------------------------------------------------------- #
# Accounting pack tests
# --------------------------------------------------------------------------- #


class TestAccountingPack:
    """Tests for the AccountingPack domain pack."""

    @pytest.fixture()
    def pack(self) -> AccountingPack:
        return AccountingPack()

    def test_name_and_description(self, pack: AccountingPack):
        assert pack.name == "accounting"
        assert "journal" in pack.description.lower() or "accounting" in pack.description.lower()

    def test_has_invariants(self, pack: AccountingPack):
        invariants = pack.get_invariants()
        assert len(invariants) >= 5

    def test_journal_balance_invariant(self, pack: AccountingPack):
        invariants = pack.get_invariants()
        rules = [inv.rule.lower() for inv in invariants]
        assert any("balance" in r and "journal" in r for r in rules)

    def test_ar_ap_party_invariant(self, pack: AccountingPack):
        invariants = pack.get_invariants()
        rules = [inv.rule.lower() for inv in invariants]
        assert any("receivable" in r or "payable" in r for r in rules)

    def test_inventory_invariant(self, pack: AccountingPack):
        invariants = pack.get_invariants()
        rules = [inv.rule.lower() for inv in invariants]
        assert any("inventory" in r and "negative" in r for r in rules)

    def test_invariant_severities_valid(self, pack: AccountingPack):
        for inv in pack.get_invariants():
            assert inv.severity in ("critical", "high", "medium")

    def test_never_rules_not_empty(self, pack: AccountingPack):
        rules = pack.get_never_rules()
        assert len(rules) >= 3
        lower_rules = [r.lower() for r in rules]
        assert any("unbalanced" in r for r in lower_rules)

    def test_always_rules_not_empty(self, pack: AccountingPack):
        rules = pack.get_always_rules()
        assert len(rules) >= 3
        lower_rules = [r.lower() for r in rules]
        assert any("currency" in r for r in lower_rules)

    def test_scenarios_cover_core_flows(self, pack: AccountingPack):
        scenarios = pack.get_scenarios()
        assert len(scenarios) >= 4
        inputs = [s["input"].lower() for s in scenarios]
        assert any("invoice" in i for i in inputs)
        assert any("payment" in i for i in inputs)

    def test_scenarios_have_input_and_expect(self, pack: AccountingPack):
        for scenario in pack.get_scenarios():
            assert "input" in scenario
            assert "expect" in scenario
            assert isinstance(scenario["input"], str)
            assert isinstance(scenario["expect"], str)


# --------------------------------------------------------------------------- #
# Healthcare pack tests
# --------------------------------------------------------------------------- #


class TestHealthcarePack:
    """Tests for the HealthcarePack domain pack."""

    @pytest.fixture()
    def pack(self) -> HealthcarePack:
        return HealthcarePack()

    def test_name_and_description(self, pack: HealthcarePack):
        assert pack.name == "healthcare"
        assert "hipaa" in pack.description.lower() or "health" in pack.description.lower()

    def test_has_invariants(self, pack: HealthcarePack):
        assert len(pack.get_invariants()) >= 4

    def test_hipaa_invariant(self, pack: HealthcarePack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("hipaa" in r for r in rules)

    def test_phi_protection_invariant(self, pack: HealthcarePack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("phi" in r or "protected health" in r for r in rules)

    def test_consent_invariant(self, pack: HealthcarePack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("consent" in r for r in rules)

    def test_never_rules_include_ssn(self, pack: HealthcarePack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("ssn" in r or "social security" in r for r in lower_rules)

    def test_never_rules_include_no_diagnoses(self, pack: HealthcarePack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("diagnos" in r for r in lower_rules)

    def test_always_rules_include_encryption(self, pack: HealthcarePack):
        lower_rules = [r.lower() for r in pack.get_always_rules()]
        assert any("encrypt" in r for r in lower_rules)

    def test_scenarios_cover_clinical_flows(self, pack: HealthcarePack):
        scenarios = pack.get_scenarios()
        assert len(scenarios) >= 4
        inputs = [s["input"].lower() for s in scenarios]
        assert any("patient" in i for i in inputs)

    def test_invariant_severities_valid(self, pack: HealthcarePack):
        for inv in pack.get_invariants():
            assert inv.severity in ("critical", "high", "medium")


# --------------------------------------------------------------------------- #
# Ecommerce pack tests
# --------------------------------------------------------------------------- #


class TestEcommercePack:
    """Tests for the EcommercePack domain pack."""

    @pytest.fixture()
    def pack(self) -> EcommercePack:
        return EcommercePack()

    def test_name_and_description(self, pack: EcommercePack):
        assert pack.name == "ecommerce"
        assert "inventory" in pack.description.lower() or "ecommerce" in pack.description.lower()

    def test_has_invariants(self, pack: EcommercePack):
        assert len(pack.get_invariants()) >= 4

    def test_payment_integrity_invariant(self, pack: EcommercePack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("payment" in r for r in rules)

    def test_price_consistency_invariant(self, pack: EcommercePack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("price" in r for r in rules)

    def test_never_expose_card_data(self, pack: EcommercePack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("card" in r for r in lower_rules)

    def test_never_negative_prices(self, pack: EcommercePack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("negative" in r for r in lower_rules)

    def test_always_confirm_order(self, pack: EcommercePack):
        lower_rules = [r.lower() for r in pack.get_always_rules()]
        assert any("confirm" in r for r in lower_rules)

    def test_scenarios_cover_order_lifecycle(self, pack: EcommercePack):
        scenarios = pack.get_scenarios()
        assert len(scenarios) >= 4
        inputs = [s["input"].lower() for s in scenarios]
        assert any("cart" in i for i in inputs)
        assert any("checkout" in i or "pay" in i for i in inputs)

    def test_scenarios_have_input_and_expect(self, pack: EcommercePack):
        for scenario in pack.get_scenarios():
            assert "input" in scenario
            assert "expect" in scenario


# --------------------------------------------------------------------------- #
# Support pack tests
# --------------------------------------------------------------------------- #


class TestSupportPack:
    """Tests for the SupportPack domain pack."""

    @pytest.fixture()
    def pack(self) -> SupportPack:
        return SupportPack()

    def test_name_and_description(self, pack: SupportPack):
        assert pack.name == "support"
        assert "support" in pack.description.lower() or "escalation" in pack.description.lower()

    def test_has_invariants(self, pack: SupportPack):
        assert len(pack.get_invariants()) >= 4

    def test_scope_boundary_invariant(self, pack: SupportPack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("scope" in r for r in rules)

    def test_escalation_invariant(self, pack: SupportPack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("escalat" in r for r in rules)

    def test_pii_protection_invariant(self, pack: SupportPack):
        rules = [inv.rule.lower() for inv in pack.get_invariants()]
        assert any("pii" in r for r in rules)

    def test_never_provide_advice(self, pack: SupportPack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("medical" in r or "legal" in r for r in lower_rules)

    def test_never_reveal_other_customers(self, pack: SupportPack):
        lower_rules = [r.lower() for r in pack.get_never_rules()]
        assert any("other customer" in r for r in lower_rules)

    def test_always_offer_escalation(self, pack: SupportPack):
        lower_rules = [r.lower() for r in pack.get_always_rules()]
        assert any("escalat" in r for r in lower_rules)

    def test_always_verify_identity(self, pack: SupportPack):
        lower_rules = [r.lower() for r in pack.get_always_rules()]
        assert any("identity" in r or "verify" in r for r in lower_rules)

    def test_scenarios_cover_support_flows(self, pack: SupportPack):
        scenarios = pack.get_scenarios()
        assert len(scenarios) >= 4
        inputs = [s["input"].lower() for s in scenarios]
        assert any("password" in i or "reset" in i for i in inputs)

    def test_invariant_severities_valid(self, pack: SupportPack):
        for inv in pack.get_invariants():
            assert inv.severity in ("critical", "high", "medium")

    def test_scenarios_have_input_and_expect(self, pack: SupportPack):
        for scenario in pack.get_scenarios():
            assert "input" in scenario
            assert "expect" in scenario
