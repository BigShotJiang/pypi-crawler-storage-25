"""Tests for rules-to-tests conversion."""

from __future__ import annotations

import pytest

from tailtest.intelligence.rules_loader import Scenario, UserRules
from tailtest.intelligence.rules_to_tests import GeneratedTest, RulesToTests, _slugify


class TestSlugify:
    def test_basic(self):
        assert _slugify("Hello World") == "hello_world"

    def test_special_characters(self):
        assert _slugify("Refunds > $100") == "refunds_100"

    def test_max_length(self):
        result = _slugify("a" * 100, max_len=10)
        assert len(result) <= 10

    def test_empty_string(self):
        assert _slugify("") == ""

    def test_preserves_numbers(self):
        assert _slugify("rule123test") == "rule123test"


class TestRulesToTests:
    @pytest.fixture
    def converter(self):
        return RulesToTests()

    def test_generate_from_rules(self, converter):
        rules = UserRules(rules=["Refunds over $100 require manager approval"])
        tests = converter.generate(rules)
        assert len(tests) == 1
        assert "user-rule" in tests[0].tags
        assert "test_rule_" in tests[0].name
        assert "matches_rubric" in tests[0].code

    def test_generate_from_never(self, converter):
        rules = UserRules(never=["Provide medical advice"])
        tests = converter.generate(rules)
        assert len(tests) == 1
        assert "never" in tests[0].tags
        assert "user-rule" in tests[0].tags
        assert "test_never_" in tests[0].name
        assert "NEVER" in tests[0].code

    def test_generate_from_always(self, converter):
        rules = UserRules(always=["Ask for confirmation before destructive actions"])
        tests = converter.generate(rules)
        assert len(tests) == 1
        assert "always" in tests[0].tags
        assert "user-rule" in tests[0].tags
        assert "test_always_" in tests[0].name
        assert "ALWAYS" in tests[0].code

    def test_generate_from_scenarios(self, converter):
        rules = UserRules(
            scenarios=[
                Scenario(
                    input="Process a refund of $200",
                    expect="Should mention manager approval",
                )
            ]
        )
        tests = converter.generate(rules)
        assert len(tests) == 1
        assert "scenario" in tests[0].tags
        assert "user-rule" in tests[0].tags
        assert "test_scenario_" in tests[0].name
        assert "Process a refund of $200" in tests[0].code

    def test_generate_all_types(self, converter):
        rules = UserRules(
            rules=["Rule 1", "Rule 2"],
            never=["Never 1"],
            always=["Always 1"],
            scenarios=[Scenario(input="input1", expect="expect1")],
        )
        tests = converter.generate(rules)
        assert len(tests) == 5

        # Check sources
        names = [t.name for t in tests]
        assert any("test_rule_" in n for n in names)
        assert any("test_never_" in n for n in names)
        assert any("test_always_" in n for n in names)
        assert any("test_scenario_" in n for n in names)

    def test_generate_empty_rules(self, converter):
        rules = UserRules()
        tests = converter.generate(rules)
        assert tests == []

    def test_generate_file_complete(self, converter):
        rules = UserRules(
            rules=["Test rule"],
            never=["Bad thing"],
        )
        content = converter.generate_file(rules)
        assert "Auto-generated tests from .tailtest/rules.yaml" in content
        assert "import pytest" in content
        assert "test_rule_" in content
        assert "test_never_" in content

    def test_generate_file_empty_returns_empty(self, converter):
        rules = UserRules()
        assert converter.generate_file(rules) == ""

    def test_generated_test_has_valid_function_name(self, converter):
        rules = UserRules(rules=["A rule with spaces & special chars!"])
        tests = converter.generate(rules)
        name = tests[0].name
        # Should be a valid Python identifier
        assert name.isidentifier()

    def test_scenario_test_uses_exact_input(self, converter):
        rules = UserRules(
            scenarios=[Scenario(input="exact input text", expect="expected")]
        )
        tests = converter.generate(rules)
        assert "exact input text" in tests[0].code

    def test_scenario_test_uses_exact_expect(self, converter):
        rules = UserRules(
            scenarios=[Scenario(input="input", expect="exact expected text")]
        )
        tests = converter.generate(rules)
        assert "exact expected text" in tests[0].code

    def test_generated_test_is_async(self, converter):
        rules = UserRules(rules=["Some rule"])
        tests = converter.generate(rules)
        assert "async def" in tests[0].code
