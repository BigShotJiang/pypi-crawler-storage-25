"""Tests for LLM code understanding  -  mock all LLM calls."""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from tailtest.intelligence.cache import UnderstandingCache
from tailtest.intelligence.understanding import CodeUnderstanding, UnderstandingResult


# ── Helpers ──────────────────────────────────────────────────────────────────


def _mock_analysis_completion(analysis: dict, cost: float = 0.001):
    """Build a mock litellm completion with a JSON analysis response."""
    content = json.dumps(analysis)
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=200, completion_tokens=100, total_tokens=300)
    return SimpleNamespace(choices=[choice], usage=usage)


SAMPLE_ANALYSIS = {
    "domain": "accounting",
    "invariants": ["debits must equal credits", "amounts must be positive"],
    "failure_modes": ["rounding errors in tax calculations"],
    "edge_cases": ["zero-amount invoice", "multi-currency conversion"],
    "data_validation": ["amount field must be numeric"],
}

SAMPLE_CODE = '''
def create_invoice(customer_id: str, amount: float, currency: str = "USD"):
    """Create a new invoice for a customer."""
    if amount <= 0:
        raise ValueError("Amount must be positive")
    return {"customer_id": customer_id, "amount": amount, "currency": currency}
'''


# ── UnderstandingResult ──────────────────────────────────────────────────────


class TestUnderstandingResult:
    def test_to_dict(self):
        result = UnderstandingResult(
            domain="accounting",
            invariants=["rule1"],
            failure_modes=["fail1"],
            edge_cases=["edge1"],
            data_validation=["val1"],
        )
        d = result.to_dict()
        assert d["domain"] == "accounting"
        assert d["invariants"] == ["rule1"]

    def test_from_dict(self):
        data = {
            "domain": "healthcare",
            "invariants": ["HIPAA compliance"],
            "failure_modes": [],
            "edge_cases": ["empty patient record"],
            "data_validation": ["SSN format"],
        }
        result = UnderstandingResult.from_dict(data, file_path="test.py")
        assert result.domain == "healthcare"
        assert result.file_path == "test.py"
        assert "HIPAA compliance" in result.invariants

    def test_from_dict_with_missing_keys(self):
        result = UnderstandingResult.from_dict({})
        assert result.domain == "unknown"
        assert result.invariants == []

    def test_from_cache_flag(self):
        result = UnderstandingResult.from_dict(
            {"domain": "test"}, from_cache=True
        )
        assert result.from_cache is True

    def test_roundtrip(self):
        original = UnderstandingResult(
            domain="ecommerce",
            invariants=["stock >= 0"],
            failure_modes=["payment timeout"],
            edge_cases=["cart with 1000 items"],
            data_validation=["email format"],
        )
        restored = UnderstandingResult.from_dict(original.to_dict())
        assert restored.domain == original.domain
        assert restored.invariants == original.invariants


# ── CodeUnderstanding ────────────────────────────────────────────────────────


class TestCodeUnderstanding:
    @pytest.fixture
    def cache(self, tmp_path):
        return UnderstandingCache(cache_dir=tmp_path / "cache")

    @pytest.fixture
    def understanding(self, cache):
        return CodeUnderstanding(cache=cache)

    async def test_analyse_calls_llm(self, understanding):
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.005):
                result = await understanding.analyse(
                    "src/invoice.py", SAMPLE_CODE, use_cache=False
                )

        assert result.domain == "accounting"
        assert len(result.invariants) == 2
        assert result.cost_usd == pytest.approx(0.005)
        assert result.from_cache is False

    async def test_analyse_uses_cache(self, understanding, cache):
        # Pre-populate cache
        from tailtest.intelligence.cache import content_hash

        h = content_hash(SAMPLE_CODE)
        cache.save("src/invoice.py", h, SAMPLE_ANALYSIS)

        # Should NOT call the LLM
        result = await understanding.analyse("src/invoice.py", SAMPLE_CODE)
        assert result.from_cache is True
        assert result.domain == "accounting"

    async def test_analyse_saves_to_cache(self, understanding, cache):
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                await understanding.analyse("src/invoice.py", SAMPLE_CODE)

        # Verify it was cached
        from tailtest.intelligence.cache import content_hash

        h = content_hash(SAMPLE_CODE)
        cached = cache.load("src/invoice.py", h)
        assert cached is not None
        assert cached["domain"] == "accounting"

    async def test_analyse_handles_non_json_response(self, understanding):
        """LLM returns non-JSON  -  should return empty result gracefully."""
        content = "This is not JSON at all."
        message = SimpleNamespace(content=content)
        choice = SimpleNamespace(message=message)
        mock_resp = SimpleNamespace(choices=[choice], usage=SimpleNamespace())

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.0):
                result = await understanding.analyse(
                    "bad.py", "print('hello')", use_cache=False
                )

        assert result.domain == "unknown"
        assert result.invariants == []

    async def test_analyse_handles_llm_error(self, understanding):
        """LLM throws exception  -  should return empty result."""
        with patch("litellm.acompletion", new_callable=AsyncMock, side_effect=ConnectionError("offline")):
            result = await understanding.analyse(
                "error.py", "print('hello')", use_cache=False
            )

        assert result.domain == "unknown"

    async def test_analyse_strips_markdown_fences(self, understanding):
        """LLM wraps JSON in markdown code fences."""
        wrapped = "```json\n" + json.dumps(SAMPLE_ANALYSIS) + "\n```"
        message = SimpleNamespace(content=wrapped)
        choice = SimpleNamespace(message=message)
        mock_resp = SimpleNamespace(choices=[choice], usage=SimpleNamespace())

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await understanding.analyse(
                    "fenced.py", SAMPLE_CODE, use_cache=False
                )

        assert result.domain == "accounting"

    async def test_analyse_files_processes_multiple(self, understanding):
        mock_resp = _mock_analysis_completion(SAMPLE_ANALYSIS)
        progress_calls = []

        def track_progress(current, total, path):
            progress_calls.append((current, total, path))

        files = [
            ("src/a.py", SAMPLE_CODE),
            ("src/b.py", SAMPLE_CODE),
            ("src/c.py", SAMPLE_CODE),
        ]

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                results = await understanding.analyse_files(
                    files, use_cache=False, on_progress=track_progress
                )

        assert len(results) == 3
        assert len(progress_calls) == 3
        assert progress_calls[0] == (1, 3, "src/a.py")
        assert progress_calls[2] == (3, 3, "src/c.py")
