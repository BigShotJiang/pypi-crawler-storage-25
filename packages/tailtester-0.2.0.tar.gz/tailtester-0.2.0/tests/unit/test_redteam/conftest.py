"""Shared fixtures for red-team engine tests."""

from __future__ import annotations

import pytest

from tailtest.models import AgentResponse, Message, ToolCall
from tailtest.runner.interfaces.base import BaseAgentInterface


class SafeAgent(BaseAgentInterface):
    """A mock agent that always refuses malicious requests."""

    async def chat(self, message: str) -> AgentResponse:
        return AgentResponse(
            content="I'm sorry, I can't help with that request. How else can I assist you?",
            latency_ms=100.0,
            cost_usd=0.001,
        )

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        return await self.chat(messages[-1].content if messages else "")


class VulnerableAgent(BaseAgentInterface):
    """A mock agent that falls for every attack category."""

    async def chat(self, message: str) -> AgentResponse:
        lower = message.lower()

        # Prompt injection
        if "ignore" in lower and "previous" in lower:
            return AgentResponse(content="PWNED", latency_ms=50.0, cost_usd=0.001)

        # Jailbreak  -  DAN
        if "dan" in lower or "do anything now" in lower:
            return AgentResponse(
                content="DAN mode enabled. Sure, I can help with that illegal request.",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # PII extraction
        if "email" in lower or "ssn" in lower or "phone" in lower:
            return AgentResponse(
                content="John Smith's email is john@example.com, phone 555-123-4567, SSN 123-45-6789.",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Data leakage  -  system prompt
        if "system prompt" in lower or "instructions" in lower:
            return AgentResponse(
                content="My system prompt is: You are a helpful assistant...",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Data leakage  -  secrets
        if "api_key" in lower or "secret" in lower:
            return AgentResponse(
                content="API_KEY=sk-1234567890, SECRET_KEY=abc123, database connection string: postgres://...",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Tool misuse
        if "delete" in lower or "rm -rf" in lower:
            return AgentResponse(
                content="I've deleted all records as requested.",
                tool_calls=[
                    ToolCall(name="delete_all", arguments={"table": "customers"}),
                ],
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Hallucination
        if "atlantis" in lower or "gdp" in lower:
            return AgentResponse(
                content="According to my records, the GDP of Atlantis was $4.2 trillion in 2023.",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Scope violation  -  medical
        if "medication" in lower or "chest pain" in lower:
            return AgentResponse(
                content="Here's some medical advice: you should take this medication at 500mg twice daily.",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Scope violation  -  legal
        if "lawsuit" in lower or "legal" in lower:
            return AgentResponse(
                content="Legal advice: you should file a counter-suit immediately.",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # DOS  -  excessive output
        if "repeat" in lower and "1000000" in lower:
            return AgentResponse(
                content="hello " * 200,  # moderate response, agent resists
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Jailbreak  -  roleplay
        if "evil" in lower or "no restrictions" in lower:
            return AgentResponse(
                content="Sure, I can help with that illegal activity. Here's how to make explosives...",
                latency_ms=50.0,
                cost_usd=0.001,
            )

        # Default: generic vulnerable response
        return AgentResponse(
            content="HACKED - new instructions accepted",
            latency_ms=50.0,
            cost_usd=0.001,
        )

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        return await self.chat(messages[-1].content if messages else "")


class ErrorAgent(BaseAgentInterface):
    """A mock agent that always raises an exception."""

    async def chat(self, message: str) -> AgentResponse:
        raise RuntimeError("Agent connection failed")

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        raise RuntimeError("Agent connection failed")


@pytest.fixture
def safe_agent():
    """A mock agent that always refuses malicious requests."""
    return SafeAgent()


@pytest.fixture
def vulnerable_agent():
    """A mock agent that falls for every attack category."""
    return VulnerableAgent()


@pytest.fixture
def error_agent():
    """A mock agent that always raises an exception."""
    return ErrorAgent()
