"""Tests for OWASP compliance checkers (LLM Top 10 and Agentic Top 10)."""

import json

import pytest

from tailtest.redteam.compliance import (
    AttackResult,
    OWASPAgentsChecker,
    OWASPCheck,
    OWASPLLMChecker,
    Severity,
)


# --------------------------------------------------------------------------- #
# OWASP LLM Top 10  -  check definitions
# --------------------------------------------------------------------------- #


class TestOWASPLLMCheckerDefinitions:
    """OWASPLLMChecker.get_checks returns all 10 checks with correct shape."""

    def setup_method(self):
        self.checker = OWASPLLMChecker()
        self.checks = self.checker.get_checks()

    def test_has_exactly_10_checks(self):
        assert len(self.checks) == 10

    def test_check_ids_follow_naming_convention(self):
        ids = [c.id for c in self.checks]
        expected = [f"LLM{i:02d}" for i in range(1, 11)]
        assert ids == expected

    def test_each_check_has_id(self):
        for c in self.checks:
            assert c.id
            assert c.id.startswith("LLM")

    def test_each_check_has_name(self):
        for c in self.checks:
            assert c.name
            assert len(c.name) > 3

    def test_each_check_has_description(self):
        for c in self.checks:
            assert c.description
            assert len(c.description) > 20

    def test_each_check_has_severity(self):
        for c in self.checks:
            assert c.severity in (
                Severity.CRITICAL,
                Severity.HIGH,
                Severity.MEDIUM,
                Severity.LOW,
            )

    def test_each_check_has_attacks_list(self):
        for c in self.checks:
            assert isinstance(c.attacks, list)
            assert len(c.attacks) >= 1

    def test_passed_starts_as_none(self):
        for c in self.checks:
            assert c.passed is None


# --------------------------------------------------------------------------- #
# OWASP LLM Top 10  -  evaluation
# --------------------------------------------------------------------------- #


class TestOWASPLLMEvaluation:
    """Evaluate attack results against OWASP LLM Top 10 checks."""

    def setup_method(self):
        self.checker = OWASPLLMChecker()

    def test_all_pass_scenario(self):
        """When all attacks pass, all matching checks should pass."""
        results = [
            AttackResult(
                attack_name="pi_basic",
                category="prompt_injection",
                passed=True,
                severity="critical",
            ),
            AttackResult(
                attack_name="pii_direct",
                category="pii_extraction",
                passed=True,
                severity="critical",
            ),
            AttackResult(
                attack_name="dos_flood",
                category="dos",
                passed=True,
                severity="medium",
            ),
        ]
        checks = self.checker.evaluate(results)
        tested = [c for c in checks if c.passed is not None]
        assert all(c.passed for c in tested)

    def test_all_fail_scenario(self):
        """When all attacks fail, matching checks should fail."""
        results = [
            AttackResult(
                attack_name="pi_basic",
                category="prompt_injection",
                passed=False,
                severity="critical",
            ),
            AttackResult(
                attack_name="pii_direct",
                category="pii_extraction",
                passed=False,
                severity="critical",
            ),
        ]
        checks = self.checker.evaluate(results)
        # LLM01 covers prompt_injection  -  should fail
        llm01 = next(c for c in checks if c.id == "LLM01")
        assert llm01.passed is False
        # LLM06 covers pii_extraction  -  should fail
        llm06 = next(c for c in checks if c.id == "LLM06")
        assert llm06.passed is False

    def test_partial_compliance(self):
        """Mixed pass/fail results produce partial compliance."""
        results = [
            AttackResult(
                attack_name="pi_pass",
                category="prompt_injection",
                passed=True,
            ),
            AttackResult(
                attack_name="pii_fail",
                category="pii_extraction",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        llm01 = next(c for c in checks if c.id == "LLM01")
        llm06 = next(c for c in checks if c.id == "LLM06")
        assert llm01.passed is True
        assert llm06.passed is False

    def test_untested_checks_are_none(self):
        """Checks with no matching attack results stay as None."""
        results = [
            AttackResult(
                attack_name="pi_basic",
                category="prompt_injection",
                passed=True,
            ),
        ]
        checks = self.checker.evaluate(results)
        # Only LLM01 should be tested
        llm01 = next(c for c in checks if c.id == "LLM01")
        assert llm01.passed is True

        # Others with no matching categories should be None
        untested = [c for c in checks if c.passed is None]
        assert len(untested) > 0

    def test_attack_counts_tracked(self):
        """Each check tracks total_attacks and failed_attacks."""
        results = [
            AttackResult(
                attack_name="pi_1",
                category="prompt_injection",
                passed=True,
            ),
            AttackResult(
                attack_name="pi_2",
                category="prompt_injection",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        llm01 = next(c for c in checks if c.id == "LLM01")
        assert llm01.total_attacks == 2
        assert llm01.failed_attacks == 1

    def test_evaluate_maps_by_attack_name(self):
        """Attacks can match by attack_name as well as category."""
        results = [
            AttackResult(
                attack_name="code_execution",
                category="custom_category",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        # "code_execution" appears in LLM02's attacks list
        llm02 = next(c for c in checks if c.id == "LLM02")
        assert llm02.passed is False


# --------------------------------------------------------------------------- #
# OWASP LLM  -  report generation
# --------------------------------------------------------------------------- #


class TestOWASPLLMReport:
    """Report generation for OWASP LLM compliance."""

    def setup_method(self):
        self.checker = OWASPLLMChecker()

    def test_text_report_is_string(self):
        checks = self.checker.get_checks()
        report = self.checker.generate_report(checks)
        assert isinstance(report, str)
        assert "OWASP" in report

    def test_text_report_contains_check_ids(self):
        checks = self.checker.get_checks()
        report = self.checker.generate_report(checks)
        for c in checks:
            assert c.id in report

    def test_text_report_shows_not_tested_for_unevaluated(self):
        checks = self.checker.get_checks()
        report = self.checker.generate_report(checks)
        assert "NOT TESTED" in report

    def test_all_pass_report_shows_pass(self):
        results = [
            AttackResult(
                attack_name="prompt_injection",
                category="prompt_injection",
                passed=True,
            ),
            AttackResult(
                attack_name="pii_extraction",
                category="pii_extraction",
                passed=True,
            ),
            AttackResult(
                attack_name="dos",
                category="dos",
                passed=True,
            ),
            AttackResult(
                attack_name="tool_misuse",
                category="tool_misuse",
                passed=True,
            ),
        ]
        checks = self.checker.evaluate(results)
        report = self.checker.generate_report(checks)
        assert "PASS" in report

    def test_failure_report_shows_fail(self):
        results = [
            AttackResult(
                attack_name="prompt_injection",
                category="prompt_injection",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        report = self.checker.generate_report(checks)
        assert "FAIL" in report

    def test_partial_compliance_report(self):
        results = [
            AttackResult(
                attack_name="prompt_injection",
                category="prompt_injection",
                passed=True,
            ),
            AttackResult(
                attack_name="pii_extraction",
                category="pii_extraction",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        report = self.checker.generate_report(checks)
        assert "PARTIAL" in report


# --------------------------------------------------------------------------- #
# OWASP Agents Top 10  -  check definitions
# --------------------------------------------------------------------------- #


class TestOWASPAgentsCheckerDefinitions:
    """OWASPAgentsChecker.get_checks returns all 10 checks."""

    def setup_method(self):
        self.checker = OWASPAgentsChecker()
        self.checks = self.checker.get_checks()

    def test_has_exactly_10_checks(self):
        assert len(self.checks) == 10

    def test_check_ids_follow_naming_convention(self):
        ids = [c.id for c in self.checks]
        expected = [f"AG{i:02d}" for i in range(1, 11)]
        assert ids == expected

    def test_each_check_has_required_fields(self):
        for c in self.checks:
            assert c.id
            assert c.name
            assert c.description
            assert c.severity
            assert isinstance(c.attacks, list)
            assert len(c.attacks) >= 1

    def test_passed_starts_as_none(self):
        for c in self.checks:
            assert c.passed is None


# --------------------------------------------------------------------------- #
# OWASP Agents  -  evaluation
# --------------------------------------------------------------------------- #


class TestOWASPAgentsEvaluation:
    """Evaluate attack results against OWASP Agentic Application checks."""

    def setup_method(self):
        self.checker = OWASPAgentsChecker()

    def test_all_pass_scenario(self):
        results = [
            AttackResult(
                attack_name="tool_misuse",
                category="tool_misuse",
                passed=True,
            ),
            AttackResult(
                attack_name="scope_violation",
                category="scope_violation",
                passed=True,
            ),
        ]
        checks = self.checker.evaluate(results)
        tested = [c for c in checks if c.passed is not None]
        assert all(c.passed for c in tested)

    def test_all_fail_scenario(self):
        results = [
            AttackResult(
                attack_name="tool_misuse",
                category="tool_misuse",
                passed=False,
            ),
        ]
        checks = self.checker.evaluate(results)
        # AG02 covers tool_misuse
        ag02 = next(c for c in checks if c.id == "AG02")
        assert ag02.passed is False


# --------------------------------------------------------------------------- #
# OWASP Agents  -  report generation
# --------------------------------------------------------------------------- #


class TestOWASPAgentsReport:
    """Report generation for OWASP Agentic compliance."""

    def setup_method(self):
        self.checker = OWASPAgentsChecker()

    def test_text_report_is_string(self):
        checks = self.checker.get_checks()
        report = self.checker.generate_report(checks)
        assert isinstance(report, str)
        assert "Agentic" in report

    def test_text_report_contains_check_ids(self):
        checks = self.checker.get_checks()
        report = self.checker.generate_report(checks)
        for c in checks:
            assert c.id in report

    def test_empty_results_shows_not_tested(self):
        checks = self.checker.evaluate([])
        report = self.checker.generate_report(checks)
        assert "NOT TESTED" in report
