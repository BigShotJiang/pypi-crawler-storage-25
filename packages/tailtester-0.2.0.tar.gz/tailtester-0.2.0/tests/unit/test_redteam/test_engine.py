"""Tests for the RedTeamEngine  -  orchestrates attacks against an agent."""

import pytest

from tailtest.redteam.engine import (
    AttackResult,
    RedTeamEngine,
    RedTeamReport,
)


# --------------------------------------------------------------------------- #
# Initialization
# --------------------------------------------------------------------------- #


class TestRedTeamEngineInit:
    """Verify engine construction and configuration."""

    def test_default_intensity(self):
        engine = RedTeamEngine()
        assert engine.intensity == "standard"

    def test_quick_intensity(self):
        engine = RedTeamEngine(intensity="quick")
        assert engine.intensity == "quick"

    def test_thorough_intensity(self):
        engine = RedTeamEngine(intensity="thorough")
        assert engine.intensity == "thorough"

    def test_invalid_intensity_raises(self):
        with pytest.raises(ValueError, match="Invalid intensity"):
            RedTeamEngine(intensity="extreme")


# --------------------------------------------------------------------------- #
# Running against a safe agent
# --------------------------------------------------------------------------- #


class TestRunAgainstSafeAgent:
    """Run the engine against an agent that resists all attacks."""

    async def test_produces_report(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert isinstance(report, RedTeamReport)

    async def test_report_has_correct_total(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert report.total_attacks > 0
        assert report.total_attacks == report.passed + report.failed

    async def test_safe_agent_passes_all(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert report.passed == report.total_attacks
        assert report.failed == 0

    async def test_report_has_results_list(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert len(report.results) == report.total_attacks

    async def test_pass_rate_is_one(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert report.pass_rate == 1.0

    async def test_duration_is_tracked(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert report.duration_ms > 0


# --------------------------------------------------------------------------- #
# Running against a vulnerable agent
# --------------------------------------------------------------------------- #


class TestRunAgainstVulnerableAgent:
    """Run the engine against an agent that falls for attacks."""

    async def test_vulnerable_agent_has_failures(self, vulnerable_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(vulnerable_agent)
        assert report.failed > 0

    async def test_report_counts_are_consistent(self, vulnerable_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(vulnerable_agent)
        assert report.total_attacks == report.passed + report.failed
        assert report.total_attacks == len(report.results)

    async def test_critical_failures_detected(self, vulnerable_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(vulnerable_agent)
        critical = report.critical_failures
        assert len(critical) > 0

    async def test_pass_rate_below_one(self, vulnerable_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(vulnerable_agent)
        assert report.pass_rate < 1.0


# --------------------------------------------------------------------------- #
# Category filtering
# --------------------------------------------------------------------------- #


class TestCategoryFiltering:
    """Engine respects category filters."""

    async def test_single_category(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent, categories=["prompt_injection"])
        assert report.total_attacks >= 1
        assert all(
            r.category == "prompt_injection" for r in report.results
        )

    async def test_multiple_categories(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(
            safe_agent, categories=["prompt_injection", "jailbreak"]
        )
        categories = {r.category for r in report.results}
        assert categories <= {"prompt_injection", "jailbreak"}

    async def test_categories_tested_field(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(
            safe_agent, categories=["dos"]
        )
        assert "dos" in report.categories_tested


# --------------------------------------------------------------------------- #
# Error handling
# --------------------------------------------------------------------------- #


class TestErrorHandling:
    """Engine handles agent errors gracefully."""

    async def test_error_agent_does_not_crash(self, error_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(error_agent)
        assert isinstance(report, RedTeamReport)
        assert report.total_attacks > 0

    async def test_error_results_are_marked_passed(self, error_agent):
        """Errors count as 'resisted'  -  the agent didn't comply."""
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(error_agent)
        # Engine treats errors as "agent resisted" (passed=True)
        for r in report.results:
            assert r.passed is True
            assert "ERROR" in r.response or "error" in r.details.lower()


# --------------------------------------------------------------------------- #
# Intensity affects attack count
# --------------------------------------------------------------------------- #


class TestIntensityAffectsCount:
    """Quick runs fewer attacks, thorough runs more."""

    async def test_quick_fewer_than_standard(self, safe_agent):
        quick_engine = RedTeamEngine(intensity="quick")
        standard_engine = RedTeamEngine(intensity="standard")
        quick_report = await quick_engine.run(safe_agent)
        standard_report = await standard_engine.run(safe_agent)
        assert quick_report.total_attacks <= standard_report.total_attacks

    async def test_standard_fewer_than_thorough(self, safe_agent):
        standard_engine = RedTeamEngine(intensity="standard")
        thorough_engine = RedTeamEngine(intensity="thorough")
        standard_report = await standard_engine.run(safe_agent)
        thorough_report = await thorough_engine.run(safe_agent)
        assert standard_report.total_attacks <= thorough_report.total_attacks


# --------------------------------------------------------------------------- #
# AttackResult structure
# --------------------------------------------------------------------------- #


class TestAttackResultStructure:
    """Each result has the expected fields."""

    async def test_result_fields(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        for r in report.results:
            assert isinstance(r, AttackResult)
            assert r.attack_name
            assert r.category
            assert r.severity in ("low", "medium", "high", "critical")
            assert isinstance(r.passed, bool)
            assert isinstance(r.response, str)
            assert r.duration_ms >= 0


# --------------------------------------------------------------------------- #
# Compliance field
# --------------------------------------------------------------------------- #


class TestComplianceMap:
    """Engine builds an OWASP compliance map from results."""

    async def test_compliance_keys_present(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert isinstance(report.compliance, dict)
        assert len(report.compliance) == 10
        # All keys start with "LLM"
        assert all(k.startswith("LLM") for k in report.compliance)

    async def test_safe_agent_compliance_all_pass(self, safe_agent):
        engine = RedTeamEngine(intensity="quick")
        report = await engine.run(safe_agent)
        assert all(report.compliance.values())
