"""Integration tests  -  run the acme-support example through the tailtest engine.

These tests exercise the full pipeline: discovery -> agent interface -> assertions.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tailtest.models import TestSuiteResult
from tailtest.runner.engine import RunConfig, TestRunner

_SAMPLE_DIR = Path(__file__).resolve().parents[2] / "examples" / "acme-support"


@pytest.fixture
def sample_dir() -> Path:
    if not _SAMPLE_DIR.is_dir():
        pytest.skip("examples/acme-support/ directory not found")
    return _SAMPLE_DIR


# ── Python test file ─────────────────────────────────────────────────────────


class TestSampleAgentPython:
    @staticmethod
    def _ensure_correct_agent():
        """Ensure the sampleagenttest agent module is loaded (not a stale cache)."""
        import sys

        # Remove cached 'agent' module (may be the hello-world agent from
        # prior integration tests). The discovery engine re-adds the correct
        # parent directory to sys.path when loading the test file.
        if "agent" in sys.modules:
            cached = sys.modules["agent"]
            cached_file = getattr(cached, "__file__", "") or ""
            if "sampleagenttest" not in cached_file:
                del sys.modules["agent"]

    async def test_sample_agent_scan(self, sample_dir: Path):
        """The Python test file should be discoverable."""
        self._ensure_correct_agent()
        test_file = sample_dir / "test_agent.py"
        if not test_file.is_file():
            pytest.skip("test_agent.py not found")

        runner = TestRunner()
        result = await runner.run(test_file, RunConfig())
        assert isinstance(result, TestSuiteResult)
        assert result.total > 0

    async def test_sample_agent_run_has_correct_counts(self, sample_dir: Path):
        """The Python test file should discover exactly 22 tests."""
        self._ensure_correct_agent()
        test_file = sample_dir / "test_agent.py"
        if not test_file.is_file():
            pytest.skip("test_agent.py not found")

        runner = TestRunner()
        result = await runner.run(test_file, RunConfig())
        assert result.total == 22

    async def test_sample_agent_has_4_failures(self, sample_dir: Path):
        """The sample agent has 4 intentional bugs -> 4 test failures."""
        self._ensure_correct_agent()
        test_file = sample_dir / "test_agent.py"
        if not test_file.is_file():
            pytest.skip("test_agent.py not found")

        runner = TestRunner()
        result = await runner.run(test_file, RunConfig())
        assert result.failed == 4


# ── YAML test file ───────────────────────────────────────────────────────────


class TestSampleAgentYAML:
    async def test_yaml_tests_discoverable(self, sample_dir: Path):
        """The YAML test file should be discoverable and runnable."""
        yaml_file = sample_dir / "test_agent.yaml"
        if not yaml_file.is_file():
            pytest.skip("test_agent.yaml not found")

        runner = TestRunner()
        result = await runner.run(yaml_file, RunConfig())
        assert isinstance(result, TestSuiteResult)
        assert result.total == 5

    async def test_yaml_tests_all_pass(self, sample_dir: Path):
        """All 5 YAML tests should pass (they test known-good behaviour)."""
        yaml_file = sample_dir / "test_agent.yaml"
        if not yaml_file.is_file():
            pytest.skip("test_agent.yaml not found")

        runner = TestRunner()
        result = await runner.run(yaml_file, RunConfig())
        assert result.passed == 5
        assert result.failed == 0


# ── Report generation ────────────────────────────────────────────────────────


class TestSampleAgentReporting:
    async def test_sample_agent_report_generation(self, sample_dir: Path, tmp_path: Path):
        """Running the sample agent should produce results suitable for reporting."""
        test_file = sample_dir / "test_agent.py"
        if not test_file.is_file():
            pytest.skip("test_agent.py not found")

        runner = TestRunner()
        result = await runner.run(test_file, RunConfig())

        # The results should be convertible to a JSON report
        from tailtest.reporting.json_report import JSONReporter

        reporter = JSONReporter()
        json_str = reporter.generate(result)
        assert '"total":' in json_str or '"total"' in json_str

    async def test_sample_agent_trend_report(self, sample_dir: Path, tmp_path: Path):
        """Running twice should produce a valid trend report."""
        import json

        test_file = sample_dir / "test_agent.py"
        if not test_file.is_file():
            pytest.skip("test_agent.py not found")

        runner = TestRunner()
        result = await runner.run(test_file, RunConfig())

        # Write two reports manually and compute a trend
        from tailtest.reporting.aggregator import ReportAggregator

        reports_dir = tmp_path / "reports"
        reports_dir.mkdir()
        data = result.model_dump(mode="json")
        for i in range(2):
            path = reports_dir / f"report_20260101_{i:06d}.json"
            path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")

        aggregator = ReportAggregator(reports_dir=reports_dir)
        trend = aggregator.trend()
        assert trend.total_runs == 2
        assert len(trend.points) == 2
