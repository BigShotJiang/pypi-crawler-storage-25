"""Integration tests  -  scan the examples/hello-world directory."""

from pathlib import Path

import pytest

from tailtest.context.sources.scanner import scan_project
from tailtest.models import ScanResult


_HELLO_WORLD_DIR = Path(__file__).resolve().parents[2] / "examples" / "hello-world"


@pytest.fixture
def hello_world_path():
    if not _HELLO_WORLD_DIR.is_dir():
        pytest.skip("examples/hello-world directory not found")
    return _HELLO_WORLD_DIR


async def test_scan_completes_without_error(hello_world_path):
    """Scanning hello-world should complete without raising."""
    result = await scan_project(hello_world_path)
    assert isinstance(result, ScanResult)


async def test_scan_returns_scan_result(hello_world_path):
    """Scanning hello-world returns a populated ScanResult."""
    result = await scan_project(hello_world_path)
    assert isinstance(result, ScanResult)
    # Even for a mock agent, the basic fields should be populated
    assert result.framework is not None
    assert isinstance(result.tools, list)
    assert isinstance(result.prompts, list)
    assert isinstance(result.models, list)


async def test_scan_detects_python_files(hello_world_path):
    """Scanner should find .py files in the hello-world example."""
    result = await scan_project(hello_world_path)
    # The hello-world example has agent.py and test_support.py  -  scanner
    # should at least process them without error
    assert isinstance(result, ScanResult)
