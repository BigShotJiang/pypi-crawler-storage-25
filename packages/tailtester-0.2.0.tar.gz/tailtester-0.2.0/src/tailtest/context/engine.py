"""Context engine  -  high-level orchestrator for scanning and storing project
context."""

from __future__ import annotations

import logging
from pathlib import Path

from tailtest.models import ScanResult

from . import store
from .sources.scanner import scan_project

logger = logging.getLogger(__name__)


class ContextEngine:
    """Orchestrates project scanning and context persistence.

    Usage::

        engine = ContextEngine()
        result = await engine.scan(Path("./my-agent-project"))
        engine.save_context(result, Path("./my-agent-project"))
    """

    async def scan(self, path: Path, deep: bool = False) -> ScanResult:
        """Scan a project directory and return the extracted context."""
        path = path.resolve()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")
        logger.info("Scanning %s (deep=%s)", path, deep)
        result = await scan_project(path, deep=deep)
        logger.info(
            "Scan complete: framework=%s, tools=%d, prompts=%d, agents=%d, models=%s",
            result.framework,
            len(result.tools),
            len(result.prompts),
            len(result.agents),
            result.models,
        )
        return result

    def save_context(self, result: ScanResult, output_dir: Path) -> Path:
        """Save scan results to ``.tailtest/context/`` under *output_dir*.

        Returns the path to the saved scan file.
        """
        output_dir = output_dir.resolve()
        return store.save_scan(result, output_dir)

    def load_context(self, project_dir: Path) -> ScanResult | None:
        """Load previously saved scan results, or return None."""
        return store.load_scan(project_dir.resolve())
