"""Detector for CrewAI usage."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector


class CrewAIDetector(BaseDetector):
    """Detects and extracts context from CrewAI code.

    Recognised patterns
    -------------------
    * ``from crewai import Agent, Task, Crew``
    * ``Agent(role="...", goal="...", backstory="...", tools=[...])``
    * ``Task(description="...", expected_output="...", agent=...)``
    * ``@tool`` decorated functions
    * ``Crew(agents=[...], tasks=[...], process=...)``
    * ``llm="gpt-4o"`` parameter on Agent
    """

    framework_name = "crewai"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        return self._has_import(tree, "crewai")

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if self._has_tool_decorator(node):
                    tools.append(self._tool_from_funcdef(node))
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        """CrewAI agents carry prompt-like text in role / goal / backstory."""
        prompts: list[PromptDefinition] = []
        seen: set[str] = set()

        for call in self._agent_calls(tree):
            for kw_name, role_label in (
                ("role", "system"),
                ("goal", "system"),
                ("backstory", "system"),
            ):
                kw = self._find_keyword(call, kw_name)
                if kw is None:
                    continue
                val = self._const_value(kw.value)
                if val and val not in seen:
                    seen.add(val)
                    prompts.append(PromptDefinition(
                        content=val,
                        role=role_label,
                        file_path=str(file_path),
                        line_number=getattr(kw, "lineno", None),
                    ))

        # Also capture Task descriptions as user-level prompts
        for call in self._task_calls(tree):
            for kw_name in ("description", "expected_output"):
                kw = self._find_keyword(call, kw_name)
                if kw is None:
                    continue
                val = self._const_value(kw.value)
                if val and val not in seen:
                    seen.add(val)
                    prompts.append(PromptDefinition(
                        content=val,
                        role="user",
                        file_path=str(file_path),
                        line_number=getattr(kw, "lineno", None),
                    ))

        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        agents: list[AgentDefinition] = []

        for call in self._agent_calls(tree):
            role_kw = self._find_keyword(call, "role")
            name = self._const_value(role_kw.value) if role_kw else None

            model = self._model_from_agent_call(call)

            # Collect inline prompt fragments from the Agent(...) constructor
            prompts: list[PromptDefinition] = []
            for kw_name in ("role", "goal", "backstory"):
                kw = self._find_keyword(call, kw_name)
                if kw is not None:
                    val = self._const_value(kw.value)
                    if val:
                        prompts.append(PromptDefinition(
                            content=val,
                            role="system",
                            file_path=str(file_path),
                            line_number=getattr(kw, "lineno", None),
                        ))

            agents.append(AgentDefinition(
                name=name,
                framework="crewai",
                prompts=prompts,
                model=model,
                file_path=str(file_path),
            ))

        # Crew(...)  -  top-level orchestrator
        for call in self._crew_calls(tree):
            process_kw = self._find_keyword(call, "process")
            process_name: str | None = None
            if process_kw is not None:
                # Process.sequential or Process.hierarchical
                if isinstance(process_kw.value, ast.Attribute):
                    process_name = process_kw.value.attr
            agents.append(AgentDefinition(
                name=f"crew_{process_name}" if process_name else "crew",
                framework="crewai",
                file_path=str(file_path),
            ))

        return agents

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        seen: set[str] = set()
        for call in self._agent_calls(tree):
            m = self._model_from_agent_call(call)
            if m and m not in seen:
                seen.add(m)
                models.append(m)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    # -- finding CrewAI constructor calls ------------------------------ #

    def _agent_calls(self, tree: ast.Module) -> list[ast.Call]:
        return self._named_calls(tree, "Agent")

    def _task_calls(self, tree: ast.Module) -> list[ast.Call]:
        return self._named_calls(tree, "Task")

    def _crew_calls(self, tree: ast.Module) -> list[ast.Call]:
        return self._named_calls(tree, "Crew")

    @staticmethod
    def _named_calls(tree: ast.Module, name: str) -> list[ast.Call]:
        """Find all ``<name>(...)`` calls (bare name or attribute)."""
        results: list[ast.Call] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if isinstance(func, ast.Name) and func.id == name:
                results.append(node)
            elif isinstance(func, ast.Attribute) and func.attr == name:
                results.append(node)
        return results

    # -- model extraction from Agent(...) ------------------------------ #

    def _model_from_agent_call(self, call: ast.Call) -> str | None:
        """Extract model from ``Agent(llm="gpt-4o")`` or ``Agent(llm=ChatOpenAI(model="gpt-4o"))``."""
        kw = self._find_keyword(call, "llm")
        if kw is None:
            return None
        # Direct string: llm="gpt-4o"
        val = self._const_value(kw.value)
        if val:
            return val
        # Nested constructor: llm=ChatOpenAI(model="gpt-4o")
        if isinstance(kw.value, ast.Call):
            model_kw = self._find_keyword(kw.value, "model")
            if model_kw is not None:
                return self._const_value(model_kw.value)
            model_name_kw = self._find_keyword(kw.value, "model_name")
            if model_name_kw is not None:
                return self._const_value(model_name_kw.value)
        return None

    # -- @tool decorator ----------------------------------------------- #

    @staticmethod
    def _has_tool_decorator(func: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        for dec in func.decorator_list:
            if isinstance(dec, ast.Name) and dec.id == "tool":
                return True
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Name) and dec.func.id == "tool":
                return True
        return False

    @staticmethod
    def _tool_from_funcdef(func: ast.FunctionDef | ast.AsyncFunctionDef) -> ToolDefinition:
        description = ast.get_docstring(func)
        params: dict[str, str] = {}
        for arg in func.args.args:
            if arg.arg == "self":
                continue
            annotation = ""
            if arg.annotation:
                annotation = ast.dump(arg.annotation)
            params[arg.arg] = annotation
        return ToolDefinition(
            name=func.name,
            description=description,
            parameters=params,
        )
