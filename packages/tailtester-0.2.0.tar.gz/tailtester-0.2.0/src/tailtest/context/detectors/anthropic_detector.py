"""Detector for Anthropic SDK usage."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector


class AnthropicDetector(BaseDetector):
    """Detects and extracts context from the Anthropic Python SDK.

    Recognised patterns
    -------------------
    * ``import anthropic`` / ``from anthropic import ...``
    * ``client.messages.create(...)``
    * ``system="..."`` keyword arg
    * ``tools=[...]`` keyword arg with input_schema
    * ``model="claude-..."`` keyword arg
    """

    framework_name = "anthropic"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        return self._has_import(tree, "anthropic")

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for call in self._message_calls(tree):
            tools.extend(self._tools_from_call(call))
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        prompts: list[PromptDefinition] = []
        for call in self._message_calls(tree):
            p = self._system_prompt_from_call(call, file_path)
            if p:
                prompts.append(p)
        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        agents: list[AgentDefinition] = []
        for call in self._message_calls(tree):
            model = self._model_from_call(call)
            tools = self._tools_from_call(call)
            sys_prompt = self._system_prompt_from_call(call, file_path)
            agents.append(
                AgentDefinition(
                    framework="anthropic",
                    tools=tools,
                    prompts=[sys_prompt] if sys_prompt else [],
                    model=model,
                    file_path=str(file_path),
                )
            )
        return agents

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        for call in self._message_calls(tree):
            m = self._model_from_call(call)
            if m:
                models.append(m)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    def _message_calls(self, tree: ast.Module) -> list[ast.Call]:
        """Find ``*.create(...)`` calls that look like Anthropic message calls."""
        results: list[ast.Call] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if self._is_message_call(node):
                results.append(node)
        return results

    @staticmethod
    def _is_message_call(call: ast.Call) -> bool:
        """Heuristic: ``<something>.create(...)`` with a chain containing
        'messages' and/or keyword args typical of the Anthropic SDK."""
        func = call.func
        if not isinstance(func, ast.Attribute) or func.attr != "create":
            return False
        kw_names = {kw.arg for kw in call.keywords}
        # Anthropic uses 'messages' + 'model', and often 'system' or 'max_tokens'
        if "messages" in kw_names and ("model" in kw_names or "max_tokens" in kw_names):
            return True
        # Walk the attribute chain  -  look for 'messages' (client.messages.create)
        chain: list[str] = []
        cur: ast.expr = func
        while isinstance(cur, ast.Attribute):
            chain.append(cur.attr)
            cur = cur.value
        return "messages" in chain

    def _model_from_call(self, call: ast.Call) -> str | None:
        kw = self._find_keyword(call, "model")
        if kw is not None:
            return self._const_value(kw.value)
        return None

    def _system_prompt_from_call(
        self, call: ast.Call, file_path: Path
    ) -> PromptDefinition | None:
        """Extract ``system="..."`` from the call."""
        kw = self._find_keyword(call, "system")
        if kw is None:
            return None
        content = self._const_value(kw.value)
        if content:
            return PromptDefinition(
                content=content,
                role="system",
                file_path=str(file_path),
                line_number=getattr(kw, "lineno", None),
            )
        return None

    def _tools_from_call(self, call: ast.Call) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        kw = self._find_keyword(call, "tools")
        if kw is None:
            return tools
        if isinstance(kw.value, ast.List):
            for elt in kw.value.elts:
                td = self._parse_tool_dict(elt)
                if td:
                    tools.append(td)
        return tools

    def _parse_tool_dict(self, node: ast.expr) -> ToolDefinition | None:
        """Parse an Anthropic tool dict::

            {"name": "...", "description": "...", "input_schema": {...}}
        """
        if not isinstance(node, ast.Dict):
            return None
        m = self._dict_to_map(node)
        name_node = m.get("name")
        name = self._const_value(name_node) if name_node else None
        if not name:
            return None
        desc_node = m.get("description")
        desc = self._const_value(desc_node) if desc_node else None
        return ToolDefinition(
            name=name,
            description=desc,
            parameters={},
        )

    @staticmethod
    def _dict_to_map(node: ast.Dict) -> dict[str, ast.expr]:
        out: dict[str, ast.expr] = {}
        for key, val in zip(node.keys, node.values):
            if key and isinstance(key, ast.Constant) and isinstance(key.value, str):
                out[key.value] = val
        return out
