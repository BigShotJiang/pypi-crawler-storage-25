"""Fallback detector for generic / unknown LLM frameworks."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector

# Frameworks we recognise by import name but don't have a dedicated detector for.
_KNOWN_GENERIC_IMPORTS = (
    "litellm",
    "llama_index",
    "autogen",
    "smolagents",
)


class GenericDetector(BaseDetector):
    """Best-effort detector that catches common LLM patterns regardless of
    framework.

    Looks for:
    * Imports of known generic LLM libraries (litellm, langchain, ...)
    * Any ``messages=[...]`` list containing ``{"role": "system", ...}`` dicts
    * Any ``"role": "system"`` string pair in dict literals
    * Any ``tools=[...]`` keyword arguments
    * Any ``model="..."`` keyword with a string that looks like a model name
    """

    framework_name = "generic"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        for mod in _KNOWN_GENERIC_IMPORTS:
            if self._has_import(tree, mod):
                return True
        # Also detect if there are any messages=[...] patterns with role dicts
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                kw = self._find_keyword(node, "messages")
                if kw is not None and isinstance(kw.value, ast.List):
                    return True
        return False

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            for kw_name in ("tools", "functions"):
                kw = self._find_keyword(node, kw_name)
                if kw is None or not isinstance(kw.value, ast.List):
                    continue
                for elt in kw.value.elts:
                    td = self._try_parse_tool(elt)
                    if td:
                        tools.append(td)
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        prompts: list[PromptDefinition] = []
        seen_contents: set[str] = set()

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            # 1) messages=[...] keyword  -  look for system dicts
            kw = self._find_keyword(node, "messages")
            if kw is not None and isinstance(kw.value, ast.List):
                for elt in kw.value.elts:
                    p = self._system_from_dict(elt, file_path)
                    if p and p.content not in seen_contents:
                        seen_contents.add(p.content)
                        prompts.append(p)

            # 2) system="..." keyword (Anthropic-style)
            sys_kw = self._find_keyword(node, "system")
            if sys_kw is not None:
                val = self._const_value(sys_kw.value)
                if val and val not in seen_contents:
                    seen_contents.add(val)
                    prompts.append(
                        PromptDefinition(
                            content=val,
                            role="system",
                            file_path=str(file_path),
                            line_number=getattr(sys_kw, "lineno", None),
                        )
                    )

            # 3) system_message="..." / system_prompt="..." keywords
            for alt_name in ("system_message", "system_prompt"):
                alt_kw = self._find_keyword(node, alt_name)
                if alt_kw is not None:
                    val = self._const_value(alt_kw.value)
                    if val and val not in seen_contents:
                        seen_contents.add(val)
                        prompts.append(
                            PromptDefinition(
                                content=val,
                                role="system",
                                file_path=str(file_path),
                                line_number=getattr(alt_kw, "lineno", None),
                            )
                        )

        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        # For the generic detector we don't try to assemble full agent defs  - 
        # the caller aggregates tools/prompts/models from extract_* methods.
        return []

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        seen: set[str] = set()
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            kw = self._find_keyword(node, "model")
            if kw is None:
                continue
            val = self._const_value(kw.value)
            if val and val not in seen and self._looks_like_model(val):
                seen.add(val)
                models.append(val)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    def _system_from_dict(
        self, node: ast.expr, file_path: Path
    ) -> PromptDefinition | None:
        if not isinstance(node, ast.Dict):
            return None
        role: str | None = None
        content: str | None = None
        for key, val in zip(node.keys, node.values):
            k = self._const_value(key) if key else None
            if k == "role":
                role = self._const_value(val)
            elif k == "content":
                content = self._const_value(val)
        if role == "system" and content:
            return PromptDefinition(
                content=content,
                role="system",
                file_path=str(file_path),
                line_number=getattr(node, "lineno", None),
            )
        return None

    def _try_parse_tool(self, node: ast.expr) -> ToolDefinition | None:
        if not isinstance(node, ast.Dict):
            return None
        m: dict[str, ast.expr] = {}
        for key, val in zip(node.keys, node.values):
            k = self._const_value(key) if key else None
            if k:
                m[k] = val

        # Dig into "function" sub-dict (OpenAI new format)
        func_node = m.get("function")
        if func_node and isinstance(func_node, ast.Dict):
            return self._try_parse_tool(func_node)

        name_node = m.get("name")
        name = self._const_value(name_node) if name_node else None
        if not name:
            return None
        desc_node = m.get("description")
        desc = self._const_value(desc_node) if desc_node else None
        return ToolDefinition(name=name, description=desc, parameters={})

    @staticmethod
    def _looks_like_model(value: str) -> bool:
        """Quick heuristic  -  does this string look like an LLM model name?"""
        prefixes = (
            "gpt-",
            "o1",
            "o3",
            "o4",
            "claude-",
            "gemini-",
            "mistral",
            "llama",
            "command",
            "deepseek",
        )
        lower = value.lower()
        return any(lower.startswith(p) for p in prefixes) or "/" in value
