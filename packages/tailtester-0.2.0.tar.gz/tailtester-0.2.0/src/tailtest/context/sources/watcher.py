"""File system watcher  -  monitors a project directory for changes and
triggers incremental re-scans and test generation."""

from __future__ import annotations

import logging
from pathlib import Path

from rich.console import Console
from watchfiles import Change, awatch

logger = logging.getLogger(__name__)

# Directories the watcher should always ignore.
_SKIP_DIRS: frozenset[str] = frozenset({
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".git",
    ".tailtest",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    "dist",
    "build",
})

# File extensions the watcher cares about.
_WATCH_SUFFIXES: frozenset[str] = frozenset({
    ".py", ".yaml", ".yml", ".json", ".toml", ".md", ".txt",
})


class ProjectWatcher:
    """Watches a project directory for changes and updates context.

    On start, runs an initial full scan.  Then watches for file-system
    events and re-scans on each change, optionally auto-generating tests.

    Usage::

        watcher = ProjectWatcher(Path("./my-agent-project"))
        await watcher.watch(auto_generate=True)
    """

    def __init__(self, project_path: Path, console: Console | None = None):
        self.project_path = project_path.resolve()
        self.console = console or Console()
        self._context_engine: object | None = None  # lazy import
        self._debounce_ms: int = 300  # watchfiles default is fine

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    async def watch(self, auto_generate: bool = True) -> None:
        """Watch for changes and update context continuously.

        Runs until cancelled (Ctrl+C / ``asyncio.CancelledError``).
        """
        self.console.print(
            f"[bold]Watching[/bold] [cyan]{self.project_path}[/cyan] for changes..."
        )
        self.console.print("[dim]Press Ctrl+C to stop[/dim]\n")

        # Initial scan
        await self._initial_scan(auto_generate)

        # Watch for changes
        async for changes in awatch(
            self.project_path,
            watch_filter=self._should_watch,
            debounce=self._debounce_ms,
        ):
            await self._handle_changes(changes, auto_generate)

    # ------------------------------------------------------------------ #
    # Watch filter
    # ------------------------------------------------------------------ #

    def _should_watch(self, change: Change, path: str) -> bool:
        """Filter which file changes to react to."""
        p = Path(path)

        # Skip ignored directories
        if any(part in _SKIP_DIRS for part in p.parts):
            return False

        # Only watch known file types
        return p.suffix in _WATCH_SUFFIXES

    # ------------------------------------------------------------------ #
    # Initial scan
    # ------------------------------------------------------------------ #

    async def _initial_scan(self, auto_generate: bool) -> None:
        """Run a full scan when the watcher starts."""
        engine = self._get_engine()
        result = await engine.scan(self.project_path)

        # Persist context if the project has been initialised
        tailtest_dir = self.project_path / ".tailtest"
        if tailtest_dir.exists():
            engine.save_context(result, self.project_path)

        self.console.print(
            f"  [green]Initial scan:[/green] {result.framework} framework, "
            f"{len(result.tools)} tools, {len(result.prompts)} prompts"
        )

        # Auto-generate on initial scan too
        if auto_generate and tailtest_dir.exists():
            await self._run_generate(result)

        self.console.print()

    # ------------------------------------------------------------------ #
    # Change handling
    # ------------------------------------------------------------------ #

    async def _handle_changes(
        self, changes: set[tuple[Change, str]], auto_generate: bool
    ) -> None:
        """Handle a batch of detected file changes."""
        # Log each individual change
        py_changed = False
        for change_type, path in sorted(changes, key=lambda c: c[1]):
            p = Path(path)
            try:
                rel = p.relative_to(self.project_path)
            except ValueError:
                rel = p

            label = {
                Change.added: "added",
                Change.modified: "modified",
                Change.deleted: "deleted",
            }.get(change_type, "changed")

            icon = {
                Change.added: "[green]+[/green]",
                Change.modified: "[yellow]~[/yellow]",
                Change.deleted: "[red]-[/red]",
            }.get(change_type, "[yellow]~[/yellow]")

            self.console.print(f"  {icon} {rel} {label}")

            if p.suffix == ".py":
                py_changed = True

        # Only re-scan when Python files changed (config-only changes are
        # less interesting for agent context).
        if not py_changed:
            self.console.print()
            return

        # Re-scan the project
        engine = self._get_engine()
        result = await engine.scan(self.project_path)

        tailtest_dir = self.project_path / ".tailtest"
        if tailtest_dir.exists():
            engine.save_context(result, self.project_path)

        # Report what was found
        if result.tools:
            tool_names = ", ".join(t.name for t in result.tools)
            self.console.print(f"    [dim]Tools: {tool_names}[/dim]")
        if result.prompts:
            self.console.print(f"    [dim]Prompts: {len(result.prompts)} found[/dim]")

        # Auto-generate tests if enabled
        if auto_generate and tailtest_dir.exists():
            await self._run_generate(result)

        self.console.print()

    # ------------------------------------------------------------------ #
    # Test generation helper
    # ------------------------------------------------------------------ #

    async def _run_generate(self, result: "ScanResult") -> None:  # noqa: F821
        """Run the test generator and print paths of generated files."""
        from tailtest.generator.engine import TestGenerator

        generator = TestGenerator()
        output_dir = self.project_path / ".tailtest" / "tests" / "auto"

        generated = await generator.generate(result, output_dir)
        if generated:
            for gf in generated:
                try:
                    rel = gf.relative_to(self.project_path)
                except ValueError:
                    rel = gf
                self.console.print(f"    [green]Generated:[/green] {rel}")

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    def _get_engine(self):
        """Lazily import and cache the ContextEngine."""
        if self._context_engine is None:
            from tailtest.context.engine import ContextEngine

            self._context_engine = ContextEngine()
        return self._context_engine
