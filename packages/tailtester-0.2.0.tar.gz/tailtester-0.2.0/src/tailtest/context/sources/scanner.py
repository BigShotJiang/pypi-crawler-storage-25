"""AST-based project scanner  -  walks a directory, parses Python files, and
extracts AI agent context using registered framework detectors."""

from __future__ import annotations

import ast
import asyncio
import logging
import subprocess
from pathlib import Path

from tailtest.models import (
    AgentDefinition,
    PromptDefinition,
    ScanResult,
    ToolDefinition,
)

from ..detectors.anthropic_detector import AnthropicDetector
from ..detectors.base import BaseDetector
from ..detectors.crewai_detector import CrewAIDetector
from ..detectors.generic_detector import GenericDetector
from ..detectors.langchain_detector import LangChainDetector
from ..detectors.openai_detector import OpenAIDetector
from ..detectors.pydantic_ai_detector import PydanticAIDetector

logger = logging.getLogger(__name__)

# Directories the walker should always skip.
_SKIP_DIRS: set[str] = {
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    "dist",
    "build",
    "egg-info",
}

# Well-known env-var names used by AI frameworks.
_AI_ENV_VARS: set[str] = {
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "GOOGLE_API_KEY",
    "MISTRAL_API_KEY",
    "COHERE_API_KEY",
    "HUGGINGFACE_API_KEY",
    "HF_TOKEN",
    "DEEPSEEK_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_ENDPOINT",
    "LITELLM_API_KEY",
}


async def scan_project(path: Path, deep: bool = False) -> ScanResult:
    """Scan a project directory and extract agent context.

    Parameters
    ----------
    path:
        Root of the project to scan.
    deep:
        When True, also inspect recent git history for agent-related changes.
    """
    detectors: list[BaseDetector] = [
        OpenAIDetector(),
        AnthropicDetector(),
        LangChainDetector(),
        CrewAIDetector(),
        PydanticAIDetector(),
        GenericDetector(),
    ]

    py_files = _collect_python_files(path)

    all_tools: list[ToolDefinition] = []
    all_prompts: list[PromptDefinition] = []
    all_agents: list[AgentDefinition] = []
    all_models: list[str] = []
    detected_frameworks: list[str] = []
    env_vars: set[str] = set()

    for py_file in py_files:
        try:
            source = py_file.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.debug("Skipping %s: %s", py_file, exc)
            continue

        try:
            tree = ast.parse(source, filename=str(py_file))
        except SyntaxError:
            logger.debug("Skipping %s: syntax error", py_file)
            continue

        # Collect env-var references (os.environ / os.getenv)
        env_vars.update(_extract_env_vars(tree))

        # Run specific detectors first; only fall back to generic if none matched.
        specific_matched = False
        for detector in detectors:
            if not detector.detect(py_file, tree):
                continue

            # Skip the generic detector when a specific one already matched this file.
            if detector.framework_name == "generic" and specific_matched:
                continue

            specific_matched = specific_matched or detector.framework_name != "generic"

            if detector.framework_name not in detected_frameworks:
                detected_frameworks.append(detector.framework_name)

            all_tools.extend(detector.extract_tools(py_file, tree))
            all_prompts.extend(detector.extract_prompts(py_file, tree))
            all_agents.extend(detector.extract_agents(py_file, tree))
            all_models.extend(detector.extract_models(py_file, tree))

    # Deduplicate models
    seen_models: set[str] = set()
    unique_models: list[str] = []
    for m in all_models:
        if m not in seen_models:
            seen_models.add(m)
            unique_models.append(m)

    # Detect dependencies from requirements / pyproject
    dependencies = _detect_dependencies(path)

    # Config files
    config_files = _detect_config_files(path)

    # Framework label
    if len(detected_frameworks) == 1:
        framework = detected_frameworks[0]
    elif detected_frameworks:
        framework = "+".join(detected_frameworks)
    else:
        framework = "unknown"

    # Deep scan  -  git history
    if deep:
        git_prompts = await _deep_git_scan(path)
        all_prompts.extend(git_prompts)

    return ScanResult(
        framework=framework,
        framework_version=None,
        tools=all_tools,
        prompts=all_prompts,
        agents=all_agents,
        models=unique_models,
        env_vars=sorted(env_vars),
        dependencies=dependencies,
        config_files=config_files,
    )


# ------------------------------------------------------------------ #
# File collection
# ------------------------------------------------------------------ #


def _collect_python_files(root: Path) -> list[Path]:
    """Walk *root* and return all .py files, skipping ignored directories."""
    results: list[Path] = []
    if root.is_file():
        if root.suffix == ".py":
            return [root]
        return []

    for child in sorted(root.iterdir()):
        if child.is_dir():
            if child.name in _SKIP_DIRS or child.name.endswith(".egg-info"):
                continue
            results.extend(_collect_python_files(child))
        elif child.is_file() and child.suffix == ".py":
            results.append(child)
    return results


# ------------------------------------------------------------------ #
# Environment variable extraction
# ------------------------------------------------------------------ #


def _extract_env_vars(tree: ast.Module) -> set[str]:
    """Find ``os.environ["KEY"]``, ``os.environ.get("KEY")``, and
    ``os.getenv("KEY")`` references."""
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Subscript):
            # os.environ["KEY"]
            if _is_os_environ(node.value):
                key = _const_str(node.slice)
                if key:
                    found.add(key)
        elif isinstance(node, ast.Call):
            # os.environ.get("KEY") or os.getenv("KEY")
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr == "get":
                if _is_os_environ(func.value) and node.args:
                    key = _const_str(node.args[0])
                    if key:
                        found.add(key)
            elif isinstance(func, ast.Attribute) and func.attr == "getenv":
                if isinstance(func.value, ast.Name) and func.value.id == "os":
                    if node.args:
                        key = _const_str(node.args[0])
                        if key:
                            found.add(key)

    # Only return keys that look like they're AI-related or have common
    # env-var patterns (all-caps with underscores).  We keep everything  - 
    # filtering is the caller's job.
    return found


def _is_os_environ(node: ast.expr) -> bool:
    return (
        isinstance(node, ast.Attribute)
        and node.attr == "environ"
        and isinstance(node.value, ast.Name)
        and node.value.id == "os"
    )


def _const_str(node: ast.expr) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


# ------------------------------------------------------------------ #
# Dependency detection
# ------------------------------------------------------------------ #


def _detect_dependencies(root: Path) -> list[str]:
    """Read requirements.txt / pyproject.toml and return dependency names."""
    deps: list[str] = []

    req_txt = root / "requirements.txt"
    if req_txt.is_file():
        for line in req_txt.read_text(errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and not line.startswith("-"):
                # Normalise: "openai>=1.0" -> "openai"
                name = line.split(">=")[0].split("<=")[0].split("==")[0].split("[")[0].strip()
                if name:
                    deps.append(name)

    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        try:
            text = pyproject.read_text(errors="replace")
            # Lightweight TOML parse  -  just grab dependency lines
            in_deps = False
            for line in text.splitlines():
                stripped = line.strip()
                if stripped.startswith("dependencies") and "=" in stripped:
                    in_deps = True
                    continue
                if in_deps:
                    if stripped == "]":
                        in_deps = False
                        continue
                    if stripped.startswith('"') or stripped.startswith("'"):
                        val = stripped.strip('",\' ')
                        name = (
                            val.split(">=")[0]
                            .split("<=")[0]
                            .split("==")[0]
                            .split("[")[0]
                            .split("<")[0]
                            .split(">")[0]
                            .strip()
                        )
                        if name:
                            deps.append(name)
        except OSError:
            pass

    # Deduplicate preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for d in deps:
        low = d.lower()
        if low not in seen:
            seen.add(low)
            unique.append(d)
    return unique


# ------------------------------------------------------------------ #
# Config file detection
# ------------------------------------------------------------------ #


def _detect_config_files(root: Path) -> list[str]:
    """Return paths to config files relevant to AI agents."""
    patterns = [
        "*.yaml",
        "*.yml",
        "*.json",
        "*.toml",
        ".env",
        ".env.*",
    ]
    results: list[str] = []
    for p in sorted(root.iterdir()):
        if p.is_dir():
            continue
        name = p.name
        for pat in patterns:
            if pat.startswith("*."):
                if name.endswith(pat[1:]):
                    results.append(str(p.relative_to(root)))
                    break
            elif pat.endswith(".*"):
                prefix = pat[:-2]
                if name.startswith(prefix):
                    results.append(str(p.relative_to(root)))
                    break
            elif name == pat:
                results.append(str(p.relative_to(root)))
                break
    return results


# ------------------------------------------------------------------ #
# Deep scan  -  git history
# ------------------------------------------------------------------ #


async def _deep_git_scan(
    root: Path, max_commits: int = 20
) -> list[PromptDefinition]:
    """Look at the last *max_commits* commits that touched .py files and try
    to find system-prompt strings that were added or modified."""
    prompts: list[PromptDefinition] = []
    try:
        proc = await asyncio.create_subprocess_exec(
            "git",
            "log",
            f"--max-count={max_commits}",
            "--diff-filter=AM",
            "--name-only",
            "--pretty=format:",
            "--",
            "*.py",
            cwd=str(root),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
    except FileNotFoundError:
        # git not installed
        return prompts

    if proc.returncode != 0:
        return prompts

    files_seen: set[str] = set()
    for line in stdout.decode(errors="replace").splitlines():
        line = line.strip()
        if not line or line in files_seen:
            continue
        files_seen.add(line)
        full = root / line
        if not full.is_file():
            continue
        try:
            source = full.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(source, filename=str(full))
        except (OSError, SyntaxError):
            continue

        # Quick scan for system-prompt-like strings in assignments
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            val = node.value
            if not isinstance(val, ast.Constant) or not isinstance(val.value, str):
                continue
            text: str = val.value
            lower = text.lower()
            if (
                len(text) > 40
                and ("you are" in lower or "your role" in lower or "system" in lower)
            ):
                prompts.append(
                    PromptDefinition(
                        content=text,
                        role="system",
                        file_path=str(full),
                        line_number=getattr(node, "lineno", None),
                    )
                )

    return prompts
