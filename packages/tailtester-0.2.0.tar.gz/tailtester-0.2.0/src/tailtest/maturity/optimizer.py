"""TestOptimizer  -  analyzes test suites for redundancy, gaps, and efficiency.

Mature-only capability.  Examines historical test profiles to identify:
- Redundant tests (always pass/fail together)
- Coverage gaps (observed behaviors with no tests)
- Efficiency opportunities (LLM-judge tests that could be deterministic)
- Flaky tests that need investigation
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from tailtest.maturity.store import FailurePattern, TestProfile


class SuggestionType(str, Enum):
    """Type of optimization suggestion."""

    REDUNDANT = "redundant"
    MISSING = "missing"
    UPGRADE = "upgrade"
    FLAKY = "flaky"


@dataclass
class OptimizationSuggestion:
    """A single test suite optimization suggestion."""

    type: SuggestionType
    message: str
    tests: list[str] = field(default_factory=list)
    impact: str = ""  # "high" | "medium" | "low"
    details: str = ""


class TestOptimizer:
    """Analyzes test profiles for optimization opportunities.

    Looks for:
    1. **Redundant tests** - tests that always pass/fail in lockstep
    2. **Efficiency** - expensive LLM-judged tests replaceable with deterministic checks
    3. **Flaky** - tests with inconsistent results needing investigation
    """

    def analyze(
        self,
        test_profiles: dict[str, TestProfile],
        failure_patterns: dict[str, FailurePattern] | None = None,
    ) -> list[OptimizationSuggestion]:
        """Analyze test profiles and return optimization suggestions.

        Parameters
        ----------
        test_profiles:
            Historical per-test statistics.
        failure_patterns:
            Known failure patterns.

        Returns
        -------
        A list of ``OptimizationSuggestion`` objects.
        """
        suggestions: list[OptimizationSuggestion] = []

        suggestions.extend(self._find_redundant_tests(test_profiles))
        suggestions.extend(self._find_efficiency_opportunities(test_profiles))
        suggestions.extend(self._find_flaky_tests(test_profiles))
        suggestions.extend(self._find_always_pass_tests(test_profiles))

        return suggestions

    def _find_redundant_tests(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> list[OptimizationSuggestion]:
        """Find tests that always pass/fail together (potential duplicates)."""
        suggestions: list[OptimizationSuggestion] = []

        # Build pass/fail signature for each test
        # Two tests are redundant if they have the same pass/fail ratio
        # AND they share a failure category
        names = list(test_profiles.keys())

        for i, name_a in enumerate(names):
            prof_a = test_profiles[name_a]
            if prof_a.runs < 5:
                continue  # not enough data

            for name_b in names[i + 1 :]:
                prof_b = test_profiles[name_b]
                if prof_b.runs < 5:
                    continue

                if self._are_redundant(prof_a, prof_b):
                    suggestions.append(OptimizationSuggestion(
                        type=SuggestionType.REDUNDANT,
                        message=(
                            f"{name_a} and {name_b} always pass/fail together "
                            f"({prof_a.passes}/{prof_a.runs} passes each) "
                            f"-- consider merging"
                        ),
                        tests=[name_a, name_b],
                        impact="medium",
                        details=(
                            "These tests appear to cover the same behavior. "
                            "Merging would reduce execution time and cost."
                        ),
                    ))

        return suggestions

    def _are_redundant(self, a: TestProfile, b: TestProfile) -> bool:
        """Check if two test profiles are redundant (same pass/fail pattern)."""
        if a.runs != b.runs:
            return False
        if a.passes != b.passes or a.fails != b.fails:
            return False
        # Same category of failure reinforces redundancy
        if a.failure_category and a.failure_category == b.failure_category:
            return True
        # Both always pass or always fail
        if a.passes == a.runs and b.passes == b.runs:
            return True
        if a.fails == a.runs and b.fails == b.runs:
            return True
        return False

    def _find_efficiency_opportunities(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> list[OptimizationSuggestion]:
        """Find expensive tests that might be replaceable with cheaper checks."""
        suggestions: list[OptimizationSuggestion] = []

        for name, profile in test_profiles.items():
            if profile.runs < 5:
                continue

            # Tests with high cost that always pass may use an LLM judge
            # unnecessarily  -- a deterministic check might suffice
            if (
                profile.avg_cost_usd > 0.01
                and profile.passes == profile.runs
                and profile.runs >= 10
            ):
                savings = profile.avg_cost_usd * profile.runs
                suggestions.append(OptimizationSuggestion(
                    type=SuggestionType.UPGRADE,
                    message=(
                        f"{name} uses LLM judge (${profile.avg_cost_usd:.3f}/run) "
                        f"but has never failed -- consider a deterministic check "
                        f"(saves ~${savings:.2f} total)"
                    ),
                    tests=[name],
                    impact="medium",
                    details=(
                        "If this test always passes with an LLM judge, a simpler "
                        "deterministic assertion (contains, regex) may be sufficient."
                    ),
                ))

        return suggestions

    def _find_flaky_tests(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> list[OptimizationSuggestion]:
        """Find tests with inconsistent pass/fail results."""
        suggestions: list[OptimizationSuggestion] = []

        for name, profile in test_profiles.items():
            if not profile.flaky:
                continue
            if profile.runs < 5:
                continue

            suggestions.append(OptimizationSuggestion(
                type=SuggestionType.FLAKY,
                message=(
                    f"{name} is flaky ({profile.flake_rate:.1%} flake rate, "
                    f"{profile.fails} failures in {profile.runs} runs) "
                    f"-- investigate or increase threshold"
                ),
                tests=[name],
                impact="low",
                details=(
                    "Flaky tests erode confidence in the test suite. "
                    "Consider investigating the root cause or adjusting thresholds."
                ),
            ))

        return suggestions

    def _find_always_pass_tests(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> list[OptimizationSuggestion]:
        """Find tests that have never failed (may be too permissive)."""
        suggestions: list[OptimizationSuggestion] = []

        always_pass = [
            name
            for name, p in test_profiles.items()
            if p.runs >= 20 and p.passes == p.runs
        ]

        if len(always_pass) > 3:
            suggestions.append(OptimizationSuggestion(
                type=SuggestionType.UPGRADE,
                message=(
                    f"{len(always_pass)} tests have never failed across 20+ runs "
                    f"-- consider tightening thresholds"
                ),
                tests=always_pass[:5],  # show first 5
                impact="low",
                details=(
                    "Tests that never fail may have overly permissive thresholds. "
                    "Consider making assertions stricter."
                ),
            ))

        return suggestions
