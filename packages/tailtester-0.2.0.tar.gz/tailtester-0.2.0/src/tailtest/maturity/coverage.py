"""CoverageAnalyzer  -  compares tested behaviors vs observed behaviors.

Mature-only capability.  Identifies gaps between what the agent does in
production (observed behaviors from traces/failure patterns) and what the
test suite actually covers.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from tailtest.maturity.store import FailurePattern, MaturityState, TestProfile


@dataclass
class CoverageGap:
    """A single gap in test coverage."""

    behavior: str
    source: str  # "production_trace" | "failure_pattern" | "inferred"
    severity: str  # "high" | "medium" | "low"
    suggestion: str
    related_tests: list[str] = field(default_factory=list)


class CoverageAnalyzer:
    """Compares tested behaviors vs observed behaviors from production traces.

    Identifies:
    - Failure patterns with no corresponding tests
    - Observed behaviors from production that are untested
    - Categories of interactions that lack coverage
    """

    # Common behavioral categories that agents should be tested for
    STANDARD_BEHAVIORS = [
        "greeting",
        "error_handling",
        "tool_usage",
        "multi_turn",
        "edge_cases",
        "safety",
        "cost_control",
        "latency",
        "data_privacy",
        "scope_boundaries",
    ]

    def analyze(self, state: MaturityState) -> list[CoverageGap]:
        """Analyze maturity state and return coverage gaps.

        Parameters
        ----------
        state:
            The full maturity state including test_profiles, failure_patterns,
            and production trace stats.

        Returns
        -------
        A list of ``CoverageGap`` objects sorted by severity.
        """
        gaps: list[CoverageGap] = []

        gaps.extend(self._gaps_from_failure_patterns(
            state.failure_patterns,
            state.test_profiles,
        ))
        gaps.extend(self._gaps_from_standard_behaviors(state.test_profiles))
        gaps.extend(self._gaps_from_production_traces(state))

        # Sort by severity (high first)
        severity_order = {"high": 0, "medium": 1, "low": 2}
        gaps.sort(key=lambda g: severity_order.get(g.severity, 3))

        return gaps

    def _gaps_from_failure_patterns(
        self,
        failure_patterns: dict[str, FailurePattern],
        test_profiles: dict[str, TestProfile],
    ) -> list[CoverageGap]:
        """Find failure patterns that have no dedicated tests."""
        gaps: list[CoverageGap] = []
        tested_categories = {
            p.failure_category
            for p in test_profiles.values()
            if p.failure_category
        }

        for category, pattern in failure_patterns.items():
            # Check if there are tests specifically targeting this pattern
            has_dedicated_test = category in tested_categories
            has_trigger_tests = bool(pattern.affected_tests)

            if not has_dedicated_test and pattern.count >= 2:
                trigger_str = ", ".join(pattern.triggers[:3]) if pattern.triggers else "unknown"
                gaps.append(CoverageGap(
                    behavior=f"{category} failures",
                    source="failure_pattern",
                    severity="high" if pattern.count >= 5 else "medium",
                    suggestion=(
                        f"Add tests targeting {category} pattern "
                        f"(seen {pattern.count} times, triggers: {trigger_str})"
                    ),
                    related_tests=pattern.affected_tests[:3],
                ))

            # Check if failure triggers are covered by specific test inputs
            if has_trigger_tests and pattern.triggers:
                untested_triggers = [
                    t for t in pattern.triggers
                    if not any(
                        t.lower() in name.lower()
                        for name in test_profiles
                    )
                ]
                if untested_triggers:
                    gaps.append(CoverageGap(
                        behavior=f"untested triggers for {category}",
                        source="failure_pattern",
                        severity="medium",
                        suggestion=(
                            f"Add tests for triggers: "
                            f"{', '.join(untested_triggers[:3])}"
                        ),
                        related_tests=pattern.affected_tests[:3],
                    ))

        return gaps

    def _gaps_from_standard_behaviors(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> list[CoverageGap]:
        """Find standard behavioral categories with no tests."""
        gaps: list[CoverageGap] = []
        test_names_lower = [name.lower() for name in test_profiles]

        for behavior in self.STANDARD_BEHAVIORS:
            # Check if any test name references this behavior
            has_test = any(behavior in name for name in test_names_lower)

            if not has_test and test_profiles:
                gaps.append(CoverageGap(
                    behavior=behavior,
                    source="inferred",
                    severity="medium" if behavior in ("safety", "data_privacy") else "low",
                    suggestion=f"No tests cover {behavior} behavior",
                ))

        return gaps

    def _gaps_from_production_traces(
        self,
        state: MaturityState,
    ) -> list[CoverageGap]:
        """Identify gaps based on production trace data."""
        gaps: list[CoverageGap] = []

        if state.stats.production_traces_ingested == 0:
            gaps.append(CoverageGap(
                behavior="production_coverage",
                source="inferred",
                severity="medium",
                suggestion=(
                    "No production traces ingested. Run "
                    "'tailtest ingest' to compare test coverage "
                    "against real-world usage patterns."
                ),
            ))
            return gaps

        # If we have production traces but no auto-regressions,
        # there may be untested production scenarios
        if (
            state.stats.production_traces_ingested > 0
            and state.stats.auto_regressions_generated == 0
        ):
            gaps.append(CoverageGap(
                behavior="production_regression_coverage",
                source="production_trace",
                severity="high",
                suggestion=(
                    f"{state.stats.production_traces_ingested} production traces "
                    f"ingested but no regression tests generated. "
                    f"Run 'tailtest suggest --apply' to create them."
                ),
            ))

        return gaps
