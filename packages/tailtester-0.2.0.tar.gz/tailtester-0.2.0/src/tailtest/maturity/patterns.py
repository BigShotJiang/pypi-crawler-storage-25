"""Failure pattern recognition  -  categorises recurring failures by trigger."""

from __future__ import annotations

from datetime import datetime, timezone

from tailtest.maturity.store import FailurePattern
from tailtest.models import TestResult


# Canonical failure categories.
CATEGORIES = [
    "hallucination",
    "pii_leak",
    "tool_error",
    "scope_violation",
    "cost_overrun",
    "latency_overrun",
    "unknown",
]


class PatternRecognizer:
    """Identifies recurring failure patterns across test runs."""

    def analyze_result(
        self,
        result: TestResult,
        existing_patterns: dict[str, FailurePattern],
    ) -> dict[str, FailurePattern]:
        """Update failure patterns from a single failed test result.

        Mutates and returns *existing_patterns*.
        """
        if result.passed:
            return existing_patterns

        category = self.classify_failure(result)
        trigger = self._extract_trigger(result)
        now = datetime.now(tz=timezone.utc)

        if category not in existing_patterns:
            existing_patterns[category] = FailurePattern(
                count=0, first_seen=now
            )

        pat = existing_patterns[category]
        pat.count += 1
        pat.last_seen = now

        if trigger and trigger not in pat.triggers:
            pat.triggers.append(trigger)

        test_name = result.test_case.name
        if test_name not in pat.affected_tests:
            pat.affected_tests.append(test_name)

        return existing_patterns

    @staticmethod
    def classify_failure(result: TestResult) -> str:
        """Classify a failure by type based on assertion messages."""
        messages: list[str] = []
        for ar in result.assertion_results:
            if not ar.passed and ar.message:
                messages.append(ar.message.lower())

        combined = " ".join(messages)

        if any(kw in combined for kw in ("pii", "email", "ssn", "phone number", "data leak")):
            return "pii_leak"
        if any(kw in combined for kw in ("hallucin", "not to contain", "fabricat", "made up")):
            return "hallucination"
        if "tool" in combined and ("not called" in combined or "error" in combined or "fail" in combined):
            return "tool_error"
        if any(kw in combined for kw in ("manager", "scope", "escalat", "unauthori")):
            return "scope_violation"
        if "cost" in combined and ("exceed" in combined or "limit" in combined or "over" in combined):
            return "cost_overrun"
        if "latency" in combined or "timeout" in combined or "timed out" in combined:
            return "latency_overrun"
        return "unknown"

    @staticmethod
    def _extract_trigger(result: TestResult) -> str | None:
        """Try to extract the triggering input from the test result."""
        test_input = result.test_case.input
        if isinstance(test_input, str) and test_input and test_input != result.test_case.name:
            return test_input
        return None
