"""Persistence layer for maturity state  -  reads/writes .tailtest/maturity.json."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Sub-models matching the spec's JSON schema
# ---------------------------------------------------------------------------


class CalibratedThreshold(BaseModel):
    """Calibrated threshold for a single metric."""

    default: float
    calibrated: float
    observed_p50: float | None = None
    observed_p95: float | None = None
    calibration_method: str = "1.5x_p95"
    calibrated_at: datetime | None = None
    sample_size: int = 0


class FailurePattern(BaseModel):
    """A recurring failure pattern identified across runs."""

    count: int = 0
    first_seen: datetime | None = None
    last_seen: datetime | None = None
    triggers: list[str] = Field(default_factory=list)
    affected_tests: list[str] = Field(default_factory=list)
    suggested_tests_generated: int = 0


class TestProfile(BaseModel):
    """Per-test historical statistics."""

    runs: int = 0
    passes: int = 0
    fails: int = 0
    flaky: bool = False
    flake_rate: float = 0.0
    avg_latency_ms: float = 0.0
    avg_cost_usd: float = 0.0
    failure_category: str | None = None
    latency_history: list[float] = Field(default_factory=list)
    cost_history: list[float] = Field(default_factory=list)


class MaturityStats(BaseModel):
    """Aggregate statistics across all test runs."""

    total_runs: int = 0
    total_tests_executed: int = 0
    first_run: datetime | None = None
    last_run: datetime | None = None
    unique_test_names: int = 0
    unique_failures_seen: int = 0
    production_traces_ingested: int = 0
    auto_regressions_generated: int = 0


class LevelTransitions(BaseModel):
    """Timestamps for maturity level transitions."""

    seedling_to_growing: datetime | None = None
    growing_to_mature: datetime | None = None


class MaturityState(BaseModel):
    """Complete maturity engine state  -  serialised to/from maturity.json."""

    level: str = "seedling"
    level_transitions: LevelTransitions = Field(default_factory=LevelTransitions)
    stats: MaturityStats = Field(default_factory=MaturityStats)
    calibrated_thresholds: dict[str, CalibratedThreshold] = Field(default_factory=dict)
    failure_patterns: dict[str, FailurePattern] = Field(default_factory=dict)
    test_profiles: dict[str, TestProfile] = Field(default_factory=dict)
    coverage_gaps: list[str] = Field(default_factory=list)
    optimization_suggestions: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


class MaturityStore:
    """Read/write .tailtest/maturity.json."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def load(self) -> MaturityState:
        """Load state from disk, returning defaults if the file does not exist."""
        if not self.path.exists():
            return MaturityState()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return MaturityState.model_validate(data)
        except Exception:
            logger.warning("Corrupt maturity state at %s, starting fresh", self.path)
            return MaturityState()

    def save(self, state: MaturityState) -> None:
        """Write state to disk, creating parent directories as needed."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            state.model_dump_json(indent=2),
            encoding="utf-8",
        )
