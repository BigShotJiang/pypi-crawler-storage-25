"""Flaky test detection  -  identifies tests that pass sometimes, fail sometimes."""

from __future__ import annotations

from dataclasses import dataclass

from tailtest.maturity.store import TestProfile


# Minimum number of runs before flagging a test as flaky.
MIN_RUNS_FOR_FLAKY = 5

# Minimum flake rate (0-1) to flag as flaky.
MIN_FLAKE_RATE = 0.01


@dataclass
class FlakyTestInfo:
    """Summary of a flaky test."""

    name: str
    runs: int
    passes: int
    fails: int
    flake_rate: float


class FlakyDetector:
    """Identifies tests that pass sometimes and fail sometimes.

    A test is flaky when it has both passes and failures and has been
    run at least ``min_runs`` times.
    """

    def __init__(self, min_runs: int = MIN_RUNS_FOR_FLAKY) -> None:
        self.min_runs = min_runs

    def detect(self, test_profiles: dict[str, TestProfile]) -> list[FlakyTestInfo]:
        """Return a list of flaky tests, sorted by flake rate descending."""
        flaky: list[FlakyTestInfo] = []

        for name, profile in test_profiles.items():
            if profile.runs < self.min_runs:
                continue
            if profile.passes == 0 or profile.fails == 0:
                continue

            flake_rate = self.compute_flake_rate(profile)
            if flake_rate < MIN_FLAKE_RATE:
                continue

            flaky.append(
                FlakyTestInfo(
                    name=name,
                    runs=profile.runs,
                    passes=profile.passes,
                    fails=profile.fails,
                    flake_rate=flake_rate,
                )
            )

        flaky.sort(key=lambda f: f.flake_rate, reverse=True)
        return flaky

    @staticmethod
    def compute_flake_rate(profile: TestProfile) -> float:
        """Compute flake rate for a test profile.

        The flake rate is the proportion of runs in the minority outcome.
        A test that passes 90% and fails 10% has a 10% flake rate.
        """
        if profile.runs == 0:
            return 0.0
        minority = min(profile.passes, profile.fails)
        return minority / profile.runs

    def update_profiles(self, test_profiles: dict[str, TestProfile]) -> None:
        """Update the ``flaky`` and ``flake_rate`` fields on each profile in-place."""
        for name, profile in test_profiles.items():
            if profile.runs < self.min_runs or profile.passes == 0 or profile.fails == 0:
                profile.flaky = False
                profile.flake_rate = 0.0
                continue

            rate = self.compute_flake_rate(profile)
            profile.flaky = rate >= MIN_FLAKE_RATE
            profile.flake_rate = round(rate, 4)
