"""Threshold calibrator  -  adjusts assertion thresholds from observed distributions."""

from __future__ import annotations

from datetime import datetime, timezone

from tailtest.maturity.store import CalibratedThreshold, TestProfile


# Minimum number of data points before calibration activates.
MIN_SAMPLES = 10

# Default thresholds (matching the config/spec).
DEFAULTS: dict[str, float] = {
    "cost_usd": 0.05,
    "latency_ms": 3000.0,
}


class ThresholdCalibrator:
    """Computes calibrated thresholds from observed distributions.

    Method: 1.5x observed p95.  Only activates at Growing level (10+ runs)
    when enough data points are available.
    """

    def calibrate(
        self,
        test_profiles: dict[str, TestProfile],
    ) -> dict[str, CalibratedThreshold]:
        """Compute calibrated thresholds from historical per-test data."""
        latencies = [
            v
            for p in test_profiles.values()
            for v in (p.latency_history if p.latency_history else [p.avg_latency_ms])
            if v > 0
        ]
        costs = [
            v
            for p in test_profiles.values()
            for v in (p.cost_history if p.cost_history else [p.avg_cost_usd])
            if v > 0
        ]

        return {
            "latency_ms": self._calibrate_one(
                latencies, default=DEFAULTS["latency_ms"], method="1.5x_p95"
            ),
            "cost_usd": self._calibrate_one(
                costs, default=DEFAULTS["cost_usd"], method="1.5x_p95"
            ),
        }

    @staticmethod
    def _calibrate_one(
        values: list[float],
        default: float,
        method: str,
    ) -> CalibratedThreshold:
        """Calibrate a single threshold from observed values."""
        if len(values) < MIN_SAMPLES:
            return CalibratedThreshold(default=default, calibrated=default)

        sorted_vals = sorted(values)
        p50 = sorted_vals[len(sorted_vals) // 2]
        p95_idx = int(len(sorted_vals) * 0.95)
        # Clamp index
        p95_idx = min(p95_idx, len(sorted_vals) - 1)
        p95 = sorted_vals[p95_idx]

        if method == "1.5x_p95":
            calibrated = p95 * 1.5
        elif method == "2x_p95":
            calibrated = p95 * 2.0
        else:
            calibrated = default

        return CalibratedThreshold(
            default=default,
            calibrated=calibrated,
            observed_p50=p50,
            observed_p95=p95,
            calibration_method=method,
            calibrated_at=datetime.now(tz=timezone.utc),
            sample_size=len(values),
        )
