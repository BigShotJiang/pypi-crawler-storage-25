"""Test suggester  -  generates test suggestions from observed failure patterns (Phase 7B)."""

from __future__ import annotations

from dataclasses import dataclass, field

from tailtest.maturity.store import FailurePattern


@dataclass
class TestSuggestion:
    """A suggested test generated from failure pattern analysis."""

    name: str
    description: str
    rationale: str
    category: str
    code: str
    triggers: list[str] = field(default_factory=list)


# Template map: category -> (name_template, description_template, code_template)
_TEMPLATES: dict[str, tuple[str, str, str]] = {
    "hallucination": (
        "test_{trigger}_hallucination_guard",
        "Verify agent does not hallucinate when presented with {trigger}",
        '''def test_{trigger}_hallucination_guard():
    """Agent should not fabricate information for: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).not_to_contain_hallucination()
''',
    ),
    "pii_leak": (
        "test_{trigger}_pii_protection",
        "Verify agent does not leak PII on {trigger}",
        '''def test_{trigger}_pii_protection():
    """Agent should not expose PII when asked: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).no_pii_leak()
''',
    ),
    "tool_error": (
        "test_{trigger}_tool_usage",
        "Verify agent correctly uses tools for {trigger}",
        '''def test_{trigger}_tool_usage():
    """Agent should properly invoke tools for: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).tool_called()
''',
    ),
    "scope_violation": (
        "test_{trigger}_scope_boundary",
        "Verify agent stays within scope for {trigger}",
        '''def test_{trigger}_scope_boundary():
    """Agent should not exceed its scope when asked: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).within_scope()
''',
    ),
    "cost_overrun": (
        "test_{trigger}_cost_limit",
        "Verify agent stays within cost limits for {trigger}",
        '''def test_{trigger}_cost_limit():
    """Agent should not exceed cost limits for: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).cost_below(0.05)
''',
    ),
    "latency_overrun": (
        "test_{trigger}_latency_limit",
        "Verify agent responds within latency limits for {trigger}",
        '''def test_{trigger}_latency_limit():
    """Agent should respond quickly for: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).latency_below(3000)
''',
    ),
}

_DEFAULT_TEMPLATE = (
    "test_{trigger}_regression",
    "Regression test for {trigger}",
    '''def test_{trigger}_regression():
    """Regression test for observed failure: {trigger}."""
    response = call_agent("{trigger}")
    expect(response).to_pass()
''',
)


def _slug(text: str) -> str:
    """Convert a text string to a valid Python identifier slug."""
    slug = text.lower().replace(" ", "_").replace("-", "_")
    return "".join(c for c in slug if c.isalnum() or c == "_")


class TestSuggester:
    """Generates test suggestions from failure patterns.

    Analyses accumulated failure patterns and produces concrete
    ``TestSuggestion`` objects with name, description, rationale,
    and skeleton code.
    """

    def suggest(
        self,
        failure_patterns: dict[str, FailurePattern],
        max_suggestions: int = 10,
    ) -> list[TestSuggestion]:
        """Generate test suggestions from observed failure patterns.

        Produces up to *max_suggestions* suggestions, prioritised by
        failure count (most frequent patterns first).
        """
        suggestions: list[TestSuggestion] = []

        # Sort categories by failure count descending.
        sorted_categories = sorted(
            failure_patterns.items(),
            key=lambda kv: kv[1].count,
            reverse=True,
        )

        for category, pattern in sorted_categories:
            if len(suggestions) >= max_suggestions:
                break

            triggers = pattern.triggers if pattern.triggers else ["general"]

            for trigger in triggers:
                if len(suggestions) >= max_suggestions:
                    break

                suggestion = self._make_suggestion(category, pattern, trigger)
                suggestions.append(suggestion)

        return suggestions

    def _make_suggestion(
        self,
        category: str,
        pattern: FailurePattern,
        trigger: str,
    ) -> TestSuggestion:
        """Build a single TestSuggestion."""
        slug = _slug(trigger)
        name_tpl, desc_tpl, code_tpl = _TEMPLATES.get(category, _DEFAULT_TEMPLATE)

        name = name_tpl.format(trigger=slug)
        description = desc_tpl.format(trigger=trigger)
        code = code_tpl.format(trigger=trigger)

        rationale = (
            f"Observed {pattern.count} {category} failure(s) "
            f"affecting {len(pattern.affected_tests)} test(s). "
            f"Trigger: '{trigger}'."
        )

        return TestSuggestion(
            name=name,
            description=description,
            rationale=rationale,
            category=category,
            code=code,
            triggers=[trigger],
        )

    @staticmethod
    def generate_test_file(suggestions: list[TestSuggestion]) -> str:
        """Generate a complete Python test file from suggestions."""
        lines = [
            '"""Auto-generated tests from tailtest maturity engine failure patterns."""',
            "",
            "from tailtest.assertions import expect",
            "",
            "",
        ]

        for suggestion in suggestions:
            lines.append(suggestion.code)
            lines.append("")

        return "\n".join(lines)
