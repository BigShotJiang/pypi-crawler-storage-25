"""Maturity level tracker  -  counts runs, manages level transitions."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from tailtest.maturity.store import MaturityState


class MaturityLevel(str, Enum):
    """Discrete maturity levels that unlock progressively richer capabilities."""

    SEEDLING = "seedling"
    GROWING = "growing"
    MATURE = "mature"

    def __ge__(self, other: object) -> bool:
        if not isinstance(other, MaturityLevel):
            return NotImplemented
        order = [MaturityLevel.SEEDLING, MaturityLevel.GROWING, MaturityLevel.MATURE]
        return order.index(self) >= order.index(other)

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, MaturityLevel):
            return NotImplemented
        order = [MaturityLevel.SEEDLING, MaturityLevel.GROWING, MaturityLevel.MATURE]
        return order.index(self) > order.index(other)

    def __le__(self, other: object) -> bool:
        if not isinstance(other, MaturityLevel):
            return NotImplemented
        order = [MaturityLevel.SEEDLING, MaturityLevel.GROWING, MaturityLevel.MATURE]
        return order.index(self) <= order.index(other)

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, MaturityLevel):
            return NotImplemented
        order = [MaturityLevel.SEEDLING, MaturityLevel.GROWING, MaturityLevel.MATURE]
        return order.index(self) < order.index(other)


# Thresholds for level transitions
SEEDLING_MAX_RUNS = 9
GROWING_MAX_RUNS = 49
GROWING_MIN_RUNS = 10
MATURE_MIN_RUNS = 50


class MaturityTracker:
    """Counts runs and manages level transitions.

    Seedling: 0-9 runs
    Growing:  10-49 runs
    Mature:   50+ runs
    """

    def compute_level(self, total_runs: int) -> MaturityLevel:
        """Determine maturity level from run count."""
        if total_runs >= MATURE_MIN_RUNS:
            return MaturityLevel.MATURE
        if total_runs >= GROWING_MIN_RUNS:
            return MaturityLevel.GROWING
        return MaturityLevel.SEEDLING

    def check_transition(self, state: MaturityState) -> MaturityLevel:
        """Check if a level transition is warranted and record it.

        Mutates ``state.level`` and ``state.level_transitions`` if a
        transition occurs.  Returns the (possibly new) level.
        """
        current = MaturityLevel(state.level)
        new_level = self.compute_level(state.stats.total_runs)

        if new_level == current:
            return current

        now = datetime.now(tz=timezone.utc)

        if current == MaturityLevel.SEEDLING and new_level >= MaturityLevel.GROWING:
            state.level_transitions.seedling_to_growing = now
            # If jumping straight to mature, record both transitions
            if new_level == MaturityLevel.MATURE:
                state.level_transitions.growing_to_mature = now

        if current == MaturityLevel.GROWING and new_level == MaturityLevel.MATURE:
            state.level_transitions.growing_to_mature = now

        state.level = new_level.value
        return new_level

    def runs_to_next_level(self, state: MaturityState) -> int | None:
        """Return the number of runs needed to reach the next level, or None if mature."""
        current = MaturityLevel(state.level)
        if current == MaturityLevel.MATURE:
            return None
        if current == MaturityLevel.SEEDLING:
            return max(0, GROWING_MIN_RUNS - state.stats.total_runs)
        # Growing
        return max(0, MATURE_MIN_RUNS - state.stats.total_runs)
