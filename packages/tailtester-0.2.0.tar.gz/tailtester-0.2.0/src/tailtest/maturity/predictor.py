"""FailurePredictor  -  predicts which tests will break from a code diff.

Mature-only capability (requires 50+ runs of accumulated data).  Analyzes
a git diff string, determines what kind of changes were made (prompts,
tools, model configs), then cross-references with historical test profiles
to predict which tests are most likely to fail.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from tailtest.maturity.store import FailurePattern, TestProfile


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class PredictedFailure:
    """A single predicted test failure."""

    test_name: str
    confidence: float  # 0.0 .. 1.0
    reason: str


@dataclass
class ChangeCorrelation:
    """Historical correlation between a type of code change and test failures."""

    change_type: str  # "prompt" | "tool" | "model" | "config"
    test_name: str
    times_correlated: int = 0
    correlation_strength: float = 0.0
    caused_failures: bool = False


# ---------------------------------------------------------------------------
# Diff analysis helpers
# ---------------------------------------------------------------------------

# File-path patterns that signal specific change types
_PROMPT_PATTERNS = re.compile(
    r"(?:prompt|system_prompt|instructions|template|persona)",
    re.IGNORECASE,
)
_TOOL_PATTERNS = re.compile(
    r"(?:tool|function|action|plugin|capability|handler)",
    re.IGNORECASE,
)
_MODEL_PATTERNS = re.compile(
    r"(?:model|llm|gpt|claude|anthropic|openai|litellm|ollama)",
    re.IGNORECASE,
)
_CONFIG_PATTERNS = re.compile(
    r"(?:config|settings|env|\.yaml|\.toml|\.json|\.ini)",
    re.IGNORECASE,
)


def _extract_changed_files(diff: str) -> list[str]:
    """Extract file paths from a unified diff string."""
    files: list[str] = []
    for line in diff.splitlines():
        if line.startswith("+++ b/") or line.startswith("--- a/"):
            path = line[6:]
            if path and path != "/dev/null":
                files.append(path)
    return list(set(files))


def _extract_changed_lines(diff: str) -> list[str]:
    """Extract only the added/removed content lines from a diff."""
    lines: list[str] = []
    for line in diff.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            lines.append(line[1:])
        elif line.startswith("-") and not line.startswith("---"):
            lines.append(line[1:])
    return lines


# ---------------------------------------------------------------------------
# Predictor
# ---------------------------------------------------------------------------


class FailurePredictor:
    """Predicts which tests will break from a code diff.

    Works by:
    1. Parsing the diff to determine what changed (prompt files, tool
       definitions, model configs).
    2. Cross-referencing with historical test_profiles to find tests that
       have historically failed when similar changes were made.
    3. Using failure_patterns to boost confidence for known-weak areas.
    """

    def predict(
        self,
        diff: str,
        test_profiles: dict[str, TestProfile],
        failure_patterns: dict[str, FailurePattern] | None = None,
        change_history: list[ChangeCorrelation] | None = None,
    ) -> list[PredictedFailure]:
        """Analyze a diff and predict test failures.

        Parameters
        ----------
        diff:
            A unified diff string (e.g. from ``git diff``).
        test_profiles:
            Historical per-test statistics.
        failure_patterns:
            Known failure patterns (hallucination, pii_leak, etc.).
        change_history:
            Explicit correlations between change types and test failures.

        Returns
        -------
        A list of ``PredictedFailure`` sorted by confidence descending.
        """
        if not diff.strip():
            return []

        failure_patterns = failure_patterns or {}
        change_history = change_history or []

        predictions: list[PredictedFailure] = []
        seen_tests: set[str] = set()

        change_types = self._classify_changes(diff)

        # 1. Use explicit change history correlations
        for corr in change_history:
            if corr.change_type in change_types and corr.caused_failures:
                if corr.test_name not in seen_tests:
                    predictions.append(PredictedFailure(
                        test_name=corr.test_name,
                        confidence=corr.correlation_strength,
                        reason=(
                            f"{corr.change_type.title()} changes caused "
                            f"{corr.test_name} to fail {corr.times_correlated} "
                            f"times before"
                        ),
                    ))
                    seen_tests.add(corr.test_name)

        # 2. Cross-reference change types with test profiles
        changed_content = " ".join(_extract_changed_lines(diff)).lower()

        for test_name, profile in test_profiles.items():
            if test_name in seen_tests:
                continue

            confidence = 0.0
            reasons: list[str] = []

            # Tests that always fail are likely to keep failing
            if profile.runs > 0 and profile.fails == profile.runs:
                confidence = max(confidence, 0.9)
                reasons.append(f"always fails ({profile.fails}/{profile.runs} runs)")

            # Tests with high failure rate in areas matching the change
            if profile.failure_category and profile.runs > 0:
                fail_rate = profile.fails / profile.runs
                if fail_rate >= 0.2:
                    # Check if the failure pattern relates to the change
                    cat = profile.failure_category
                    if cat in failure_patterns:
                        pattern = failure_patterns[cat]
                        # Check if any triggers appear in the changed content
                        for trigger in pattern.triggers:
                            if trigger.lower() in changed_content:
                                confidence = max(confidence, 0.7 + fail_rate * 0.2)
                                reasons.append(
                                    f"trigger '{trigger}' found in diff, "
                                    f"linked to {cat} pattern"
                                )

            # Prompt changes affect prompt-sensitive tests
            if "prompt" in change_types:
                if _is_prompt_sensitive(test_name, profile):
                    base = 0.5
                    if profile.runs > 10 and profile.fails > 0:
                        base = 0.4 + (profile.fails / profile.runs) * 0.5
                    confidence = max(confidence, base)
                    reasons.append("prompt change may affect this test")

            # Tool changes affect tool-related tests
            if "tool" in change_types:
                if _is_tool_related(test_name):
                    base = 0.5
                    if profile.runs > 10 and profile.fails > 0:
                        base = 0.4 + (profile.fails / profile.runs) * 0.5
                    confidence = max(confidence, base)
                    reasons.append("tool definition changed")

            # Model changes can affect any non-deterministic test
            if "model" in change_types:
                if profile.flaky or (profile.runs > 0 and profile.fails > 0):
                    confidence = max(confidence, 0.4)
                    reasons.append("model config changed, test has prior failures")

            if confidence > 0.0 and reasons:
                predictions.append(PredictedFailure(
                    test_name=test_name,
                    confidence=min(confidence, 1.0),
                    reason="; ".join(reasons),
                ))
                seen_tests.add(test_name)

        return sorted(predictions, key=lambda p: p.confidence, reverse=True)

    def _classify_changes(self, diff: str) -> set[str]:
        """Determine what types of changes are in the diff."""
        change_types: set[str] = set()
        files = _extract_changed_files(diff)
        content = diff

        for f in files:
            if _PROMPT_PATTERNS.search(f):
                change_types.add("prompt")
            if _TOOL_PATTERNS.search(f):
                change_types.add("tool")
            if _MODEL_PATTERNS.search(f):
                change_types.add("model")
            if _CONFIG_PATTERNS.search(f):
                change_types.add("config")

        # Also check diff content for inline changes
        if _PROMPT_PATTERNS.search(content):
            change_types.add("prompt")
        if _TOOL_PATTERNS.search(content):
            change_types.add("tool")
        if _MODEL_PATTERNS.search(content):
            change_types.add("model")

        return change_types

    def touches_prompts(self, diff: str) -> bool:
        """Check if the diff touches prompt-related files or content."""
        return "prompt" in self._classify_changes(diff)

    def touches_tools(self, diff: str) -> bool:
        """Check if the diff touches tool-related files or content."""
        return "tool" in self._classify_changes(diff)

    def touches_models(self, diff: str) -> bool:
        """Check if the diff touches model configuration."""
        return "model" in self._classify_changes(diff)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_prompt_sensitive(test_name: str, profile: TestProfile) -> bool:
    """Heuristic: is this test likely affected by prompt changes?"""
    sensitive_keywords = [
        "greeting", "response", "tone", "style", "persona",
        "instruction", "behavior", "format", "output",
        "hallucination", "scope", "refusal", "safety",
    ]
    name_lower = test_name.lower()
    return any(kw in name_lower for kw in sensitive_keywords)


def _is_tool_related(test_name: str) -> bool:
    """Heuristic: is this test related to tool usage?"""
    tool_keywords = [
        "tool", "function", "call", "action", "api",
        "lookup", "search", "query", "fetch", "handler",
    ]
    name_lower = test_name.lower()
    return any(kw in name_lower for kw in tool_keywords)
