"""MaturityEngine  -  the learning system that gets smarter over time."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from tailtest.maturity.calibrator import DEFAULTS, ThresholdCalibrator
from tailtest.maturity.coverage import CoverageAnalyzer, CoverageGap
from tailtest.maturity.flaky import FlakyDetector
from tailtest.maturity.optimizer import OptimizationSuggestion, TestOptimizer
from tailtest.maturity.patterns import PatternRecognizer
from tailtest.maturity.predictor import ChangeCorrelation, FailurePredictor, PredictedFailure
from tailtest.maturity.store import MaturityState, MaturityStore, TestProfile
from tailtest.maturity.suggester import TestSuggester, TestSuggestion
from tailtest.maturity.tracker import MaturityLevel, MaturityTracker
from tailtest.models import TestSuiteResult

logger = logging.getLogger(__name__)


class MaturityEngine:
    """The learning system that accumulates agent-specific intelligence over time.

    Sits between the reporting system and the test generator, reading
    results from test runs and feeding intelligence back into generation.
    """

    def __init__(self, project_dir: Path | None = None) -> None:
        self.project_dir = project_dir or Path(".")
        self.store = MaturityStore(self.project_dir / ".tailtest" / "maturity.json")
        self.state: MaturityState = self.store.load()
        self._tracker = MaturityTracker()
        self._calibrator = ThresholdCalibrator()
        self._pattern_recognizer = PatternRecognizer()
        self._flaky_detector = FlakyDetector()
        self._suggester = TestSuggester()
        self._predictor = FailurePredictor()
        self._optimizer = TestOptimizer()
        self._coverage = CoverageAnalyzer()

    # -- Public properties ---------------------------------------------------

    @property
    def level(self) -> MaturityLevel:
        """Current maturity level."""
        return MaturityLevel(self.state.level)

    # -- Core API ------------------------------------------------------------

    def record_run(self, result: TestSuiteResult) -> None:
        """Record a test run and update maturity state."""
        now = datetime.now(tz=timezone.utc)

        # Update aggregate stats
        self.state.stats.total_runs += 1
        self.state.stats.total_tests_executed += result.total
        if self.state.stats.first_run is None:
            self.state.stats.first_run = now
        self.state.stats.last_run = now

        # Update per-test profiles
        self._update_test_profiles(result)

        # Detect failure patterns from failed tests
        self._detect_failure_patterns(result)

        # Check level transition
        self._tracker.check_transition(self.state)

        # Growing+ features
        if self.level >= MaturityLevel.GROWING:
            self._calibrate_thresholds()
            self._detect_flaky_tests()

        # Update unique counts
        self.state.stats.unique_test_names = len(self.state.test_profiles)
        self.state.stats.unique_failures_seen = sum(
            p.count for p in self.state.failure_patterns.values()
        )

        # Persist
        self.store.save(self.state)

    def get_calibrated_thresholds(self) -> dict[str, float]:
        """Return calibrated thresholds (or defaults if seedling)."""
        if self.level == MaturityLevel.SEEDLING:
            return dict(DEFAULTS)
        return {
            k: v.calibrated
            for k, v in self.state.calibrated_thresholds.items()
        }

    def suggest_tests(self) -> list[TestSuggestion]:
        """Suggest new tests based on observed failure patterns (growing+)."""
        if self.level < MaturityLevel.GROWING:
            return []
        return self._suggester.suggest(self.state.failure_patterns)

    def predict_failures(
        self,
        diff: str,
        change_history: list[ChangeCorrelation] | None = None,
    ) -> list[PredictedFailure]:
        """Predict which tests will fail from a code diff (mature only)."""
        if self.level < MaturityLevel.MATURE:
            return []
        return self._predictor.predict(
            diff,
            self.state.test_profiles,
            failure_patterns=self.state.failure_patterns,
            change_history=change_history,
        )

    def optimize_suite(self) -> list[OptimizationSuggestion]:
        """Suggest test suite optimizations (mature only)."""
        if self.level < MaturityLevel.MATURE:
            return []
        return self._optimizer.analyze(
            self.state.test_profiles,
            failure_patterns=self.state.failure_patterns,
        )

    def coverage_gaps(self) -> list[CoverageGap]:
        """Identify untested behaviors (mature only)."""
        if self.level < MaturityLevel.MATURE:
            return []
        return self._coverage.analyze(self.state)

    # -- Private helpers -----------------------------------------------------

    def _update_test_profiles(self, result: TestSuiteResult) -> None:
        """Update per-test profiles from a suite result."""
        for tr in result.results:
            name = tr.test_case.name
            if name not in self.state.test_profiles:
                self.state.test_profiles[name] = TestProfile()

            profile = self.state.test_profiles[name]
            profile.runs += 1

            if tr.passed:
                profile.passes += 1
            else:
                profile.fails += 1

            # Update running averages for latency and cost
            if tr.duration_ms > 0:
                profile.latency_history.append(tr.duration_ms)
                profile.avg_latency_ms = (
                    sum(profile.latency_history) / len(profile.latency_history)
                )

            if tr.cost_usd > 0:
                profile.cost_history.append(tr.cost_usd)
                profile.avg_cost_usd = (
                    sum(profile.cost_history) / len(profile.cost_history)
                )

    def _detect_failure_patterns(self, result: TestSuiteResult) -> None:
        """Analyse failed tests and update failure patterns."""
        for tr in result.results:
            if not tr.passed:
                self._pattern_recognizer.analyze_result(
                    tr, self.state.failure_patterns
                )

    def _calibrate_thresholds(self) -> None:
        """Recompute calibrated thresholds from accumulated data."""
        self.state.calibrated_thresholds = self._calibrator.calibrate(
            self.state.test_profiles
        )

    def _detect_flaky_tests(self) -> None:
        """Update flaky flags on test profiles."""
        self._flaky_detector.update_profiles(self.state.test_profiles)
