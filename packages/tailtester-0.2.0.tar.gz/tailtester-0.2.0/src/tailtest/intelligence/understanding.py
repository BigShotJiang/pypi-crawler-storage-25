"""Layer 2: LLM-powered code understanding.

Sends source code to an LLM for deep analysis of business domain, invariants,
failure modes, edge cases, and data validation rules.  Results are cached by
content hash so analysis is only repeated when the file actually changes.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

from tailtest.config.schema import JudgeConfig
from tailtest.intelligence.cache import UnderstandingCache, content_hash
from tailtest.intelligence.prompts import ANALYSIS_SYSTEM_PROMPT, CODE_ANALYSIS_PROMPT

logger = logging.getLogger(__name__)


@dataclass
class UnderstandingResult:
    """Structured result from LLM code analysis."""

    domain: str = "unknown"
    invariants: list[str] = field(default_factory=list)
    failure_modes: list[str] = field(default_factory=list)
    edge_cases: list[str] = field(default_factory=list)
    data_validation: list[str] = field(default_factory=list)
    file_path: str = ""
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    from_cache: bool = False

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "invariants": self.invariants,
            "failure_modes": self.failure_modes,
            "edge_cases": self.edge_cases,
            "data_validation": self.data_validation,
        }

    @classmethod
    def from_dict(cls, data: dict, *, file_path: str = "", from_cache: bool = False) -> UnderstandingResult:
        return cls(
            domain=data.get("domain", "unknown"),
            invariants=data.get("invariants", []),
            failure_modes=data.get("failure_modes", []),
            edge_cases=data.get("edge_cases", []),
            data_validation=data.get("data_validation", []),
            file_path=file_path,
            from_cache=from_cache,
        )


class CodeUnderstanding:
    """Analyses source code using an LLM to extract domain knowledge.

    Parameters
    ----------
    config:
        LLM configuration (model, temperature).  Defaults to the same
        config used by the LLM judge (``ollama/llama3.2``).
    cache:
        Optional :class:`UnderstandingCache` for persistent caching.
    """

    def __init__(
        self,
        config: JudgeConfig | None = None,
        cache: UnderstandingCache | None = None,
    ) -> None:
        self.config = config or JudgeConfig()
        self.cache = cache or UnderstandingCache()

    async def analyse(
        self,
        file_path: str,
        content: str,
        *,
        use_cache: bool = True,
    ) -> UnderstandingResult:
        """Analyse *content* (source code at *file_path*) via LLM.

        If a cached result exists for the same content hash, it is returned
        immediately without calling the LLM.
        """
        hash_val = content_hash(content)

        # Try cache first.
        if use_cache:
            cached = self.cache.load(file_path, hash_val)
            if cached is not None:
                logger.debug("Cache hit for %s", file_path)
                return UnderstandingResult.from_dict(
                    cached, file_path=file_path, from_cache=True
                )

        # Call LLM.
        result = await self._call_llm(file_path, content)

        # Persist to cache.
        if use_cache:
            self.cache.save(file_path, hash_val, result.to_dict())

        return result

    async def analyse_files(
        self,
        files: list[tuple[str, str]],
        *,
        use_cache: bool = True,
        on_progress: object | None = None,
    ) -> list[UnderstandingResult]:
        """Analyse multiple files and return results in the same order.

        Parameters
        ----------
        files:
            List of ``(file_path, content)`` tuples.
        on_progress:
            Optional callable ``(current: int, total: int, path: str) -> None``
            invoked after each file is processed.
        """
        results: list[UnderstandingResult] = []
        total = len(files)
        total_cost = 0.0
        for idx, (fpath, fcontent) in enumerate(files, 1):
            result = await self.analyse(fpath, fcontent, use_cache=use_cache)
            total_cost += result.cost_usd
            results.append(result)
            if callable(on_progress):
                on_progress(idx, total, fpath)  # type: ignore[operator]
        logger.info(
            "Analysed %d files, total cost: $%.4f", total, total_cost
        )
        return results

    async def _call_llm(self, file_path: str, content: str) -> UnderstandingResult:
        """Send *content* to the LLM and parse the structured response."""
        try:
            import litellm  # type: ignore[import-untyped]
        except ImportError:
            logger.error("litellm is not installed  -  cannot run LLM understanding")
            return UnderstandingResult(file_path=file_path)

        user_content = CODE_ANALYSIS_PROMPT.format(code=content)
        messages = [
            {"role": "system", "content": ANALYSIS_SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ]

        start = time.perf_counter()

        try:
            completion = await litellm.acompletion(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=1024,
                timeout=60,
            )
        except Exception as exc:
            logger.error("LLM understanding failed for %s: %s", file_path, exc)
            return UnderstandingResult(file_path=file_path)

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        raw = completion.choices[0].message.content or ""
        cost = self._extract_cost(completion)

        return self._parse_response(raw, file_path=file_path, cost=cost, latency_ms=elapsed_ms)

    def _parse_response(
        self,
        raw: str,
        *,
        file_path: str,
        cost: float,
        latency_ms: float,
    ) -> UnderstandingResult:
        """Parse the LLM's JSON response into an :class:`UnderstandingResult`."""
        text = raw.strip()
        # Strip markdown fences if present.
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
        text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning(
                "LLM returned non-JSON for %s: %s", file_path, raw[:200]
            )
            return UnderstandingResult(
                file_path=file_path, cost_usd=cost, latency_ms=latency_ms
            )

        result = UnderstandingResult.from_dict(data, file_path=file_path)
        result.cost_usd = cost
        result.latency_ms = latency_ms
        return result

    def _extract_cost(self, completion: object) -> float:
        try:
            import litellm  # type: ignore[import-untyped]

            return float(litellm.completion_cost(completion_response=completion))
        except Exception:
            return 0.0
