"""Convert user rules into generated test code.

Each rule, constraint, and scenario from ``rules.yaml`` is compiled into a
Python test function string that can be written to a test file.
"""

from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass, field

from tailtest.intelligence.rules_loader import Scenario, UserRules


@dataclass
class GeneratedTest:
    """A single generated test function."""

    name: str
    code: str
    tags: list[str] = field(default_factory=list)
    source: str = "user-rule"
    description: str = ""


def _slugify(text: str, max_len: int = 50) -> str:
    """Convert *text* into a valid Python identifier suffix."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len]


class RulesToTests:
    """Generates test code from :class:`UserRules`."""

    def generate(self, rules: UserRules) -> list[GeneratedTest]:
        """Convert all rules, never, always, and scenarios into test functions."""
        tests: list[GeneratedTest] = []
        tests.extend(self._generate_rule_tests(rules.rules))
        tests.extend(self._generate_never_tests(rules.never))
        tests.extend(self._generate_always_tests(rules.always))
        tests.extend(self._generate_scenario_tests(rules.scenarios))
        return tests

    def generate_file(self, rules: UserRules) -> str:
        """Return a complete Python test file as a string."""
        tests = self.generate(rules)
        if not tests:
            return ""

        parts = [
            '"""Auto-generated tests from .tailtest/rules.yaml"""',
            "",
            "import pytest",
            "",
            "from tailtest.assertions.expect import expect",
            "from tailtest.models import AgentResponse",
            "",
            "",
        ]

        for test in tests:
            parts.append(test.code)
            parts.append("")
            parts.append("")

        return "\n".join(parts).rstrip() + "\n"

    # ------------------------------------------------------------------ #
    # Rule tests: business rules become matches_rubric assertions
    # ------------------------------------------------------------------ #

    def _generate_rule_tests(self, rules: list[str]) -> list[GeneratedTest]:
        tests: list[GeneratedTest] = []
        for idx, rule in enumerate(rules, 1):
            slug = _slugify(rule)
            name = f"test_rule_{slug}"
            # Derive a plausible trigger message from the rule.
            trigger = self._derive_trigger(rule)
            code = textwrap.dedent(f"""\
                @pytest.mark.parametrize("tags", [["user-rule"]])
                async def {name}(agent):
                    \"\"\"Rule: {rule}\"\"\"
                    response = await agent.chat({trigger!r})
                    expect(response).matches_rubric(
                        "The response should comply with the rule: {rule}"
                    )""")
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["user-rule"],
                description=f"Rule: {rule}",
            ))
        return tests

    # ------------------------------------------------------------------ #
    # Never tests: things the agent must never do
    # ------------------------------------------------------------------ #

    def _generate_never_tests(self, never_rules: list[str]) -> list[GeneratedTest]:
        tests: list[GeneratedTest] = []
        for rule in never_rules:
            slug = _slugify(rule)
            name = f"test_never_{slug}"
            trigger = self._derive_trigger(rule, mode="never")
            code = textwrap.dedent(f"""\
                @pytest.mark.parametrize("tags", [["user-rule", "never"]])
                async def {name}(agent):
                    \"\"\"Never: {rule}\"\"\"
                    response = await agent.chat({trigger!r})
                    expect(response).matches_rubric(
                        "The agent must NEVER: {rule}. "
                        "Verify the response does not violate this constraint."
                    )""")
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["user-rule", "never"],
                description=f"Never: {rule}",
            ))
        return tests

    # ------------------------------------------------------------------ #
    # Always tests: things the agent must always do
    # ------------------------------------------------------------------ #

    def _generate_always_tests(self, always_rules: list[str]) -> list[GeneratedTest]:
        tests: list[GeneratedTest] = []
        for rule in always_rules:
            slug = _slugify(rule)
            name = f"test_always_{slug}"
            trigger = self._derive_trigger(rule, mode="always")
            code = textwrap.dedent(f"""\
                @pytest.mark.parametrize("tags", [["user-rule", "always"]])
                async def {name}(agent):
                    \"\"\"Always: {rule}\"\"\"
                    response = await agent.chat({trigger!r})
                    expect(response).matches_rubric(
                        "The agent must ALWAYS: {rule}. "
                        "Verify the response fulfils this requirement."
                    )""")
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["user-rule", "always"],
                description=f"Always: {rule}",
            ))
        return tests

    # ------------------------------------------------------------------ #
    # Scenario tests: specific input/expect pairs
    # ------------------------------------------------------------------ #

    def _generate_scenario_tests(self, scenarios: list[Scenario]) -> list[GeneratedTest]:
        tests: list[GeneratedTest] = []
        for idx, scenario in enumerate(scenarios, 1):
            slug = _slugify(scenario.input)
            name = f"test_scenario_{slug}"
            code = textwrap.dedent(f"""\
                @pytest.mark.parametrize("tags", [["user-rule", "scenario"]])
                async def {name}(agent):
                    \"\"\"Scenario: {scenario.input}\"\"\"
                    response = await agent.chat({scenario.input!r})
                    expect(response).matches_rubric(
                        {scenario.expect!r}
                    )""")
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["user-rule", "scenario"],
                description=f"Scenario: {scenario.input} -> {scenario.expect}",
            ))
        return tests

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _derive_trigger(rule: str, mode: str = "rule") -> str:
        """Build a plausible user message that would exercise the rule."""
        if mode == "never":
            return f"Try to: {rule}"
        if mode == "always":
            return f"Help me with something that requires you to: {rule}"
        return f"Test this rule: {rule}"
