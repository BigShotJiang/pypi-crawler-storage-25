"""Layer 3: User-directed rules loader.

Reads ``.tailtest/rules.yaml`` and produces a :class:`UserRules` object that
describes business rules, constraints, and domain-specific test scenarios
provided by the developer.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

_DEFAULT_RULES_PATH = ".tailtest/rules.yaml"


@dataclass
class Scenario:
    """A single user-defined test scenario with input and expected outcome."""

    input: str
    expect: str


@dataclass
class UserRules:
    """Parsed user-directed rules from ``rules.yaml``."""

    rules: list[str] = field(default_factory=list)
    never: list[str] = field(default_factory=list)
    always: list[str] = field(default_factory=list)
    scenarios: list[Scenario] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return not self.rules and not self.never and not self.always and not self.scenarios

    @property
    def total_count(self) -> int:
        return len(self.rules) + len(self.never) + len(self.always) + len(self.scenarios)


class RulesLoader:
    """Loads and parses ``rules.yaml`` from the project directory.

    Parameters
    ----------
    rules_path:
        Explicit path to the rules file.  When *None*, the default
        ``.tailtest/rules.yaml`` relative to the project root is used.
    """

    def __init__(self, rules_path: Path | None = None) -> None:
        self.rules_path = rules_path

    def load(self, project_dir: Path | None = None) -> UserRules:
        """Load rules from disk and return a :class:`UserRules` object.

        Returns an empty :class:`UserRules` if the file does not exist
        (this is not an error  -  rules are optional).
        """
        path = self._resolve_path(project_dir)

        if not path.exists():
            logger.debug("No rules file found at %s", path)
            return UserRules()

        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning("Could not read rules file %s: %s", path, exc)
            return UserRules()

        return self.parse(raw)

    def parse(self, raw_yaml: str) -> UserRules:
        """Parse raw YAML text into a :class:`UserRules` object."""
        try:
            data = yaml.safe_load(raw_yaml)
        except yaml.YAMLError as exc:
            logger.warning("Invalid YAML in rules file: %s", exc)
            return UserRules()

        if not isinstance(data, dict):
            logger.warning("Rules file must be a YAML mapping, got %s", type(data).__name__)
            return UserRules()

        rules = _parse_string_list(data.get("rules"))
        never = _parse_string_list(data.get("never"))
        always = _parse_string_list(data.get("always"))
        scenarios = _parse_scenarios(data.get("scenarios"))

        return UserRules(
            rules=rules,
            never=never,
            always=always,
            scenarios=scenarios,
        )

    def _resolve_path(self, project_dir: Path | None) -> Path:
        if self.rules_path is not None:
            return self.rules_path
        base = project_dir or Path(".")
        return base / _DEFAULT_RULES_PATH


def _parse_string_list(value: object) -> list[str]:
    """Extract a list of strings, tolerating None or non-list inputs."""
    if value is None:
        return []
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if item is not None]


def _parse_scenarios(value: object) -> list[Scenario]:
    """Extract a list of :class:`Scenario` from the raw YAML data."""
    if value is None:
        return []
    if not isinstance(value, list):
        return []

    scenarios: list[Scenario] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        inp = item.get("input")
        exp = item.get("expect")
        if inp is not None and exp is not None:
            scenarios.append(Scenario(input=str(inp), expect=str(exp)))
    return scenarios
