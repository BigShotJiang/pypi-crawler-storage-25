"""Hash-based file-level cache for LLM code understanding results.

Stores analysis results in ``.tailtest/context/understanding/`` keyed by
content hash.  Results are only re-computed when the file content changes.
"""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Default cache directory relative to the project root.
_DEFAULT_CACHE_DIR = ".tailtest/context/understanding"


def content_hash(content: str) -> str:
    """Return a stable SHA-256 hex digest for *content*."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class UnderstandingCache:
    """Persistent file-level cache for LLM understanding results.

    Parameters
    ----------
    cache_dir:
        Directory where cached JSON files are stored.  Created on first
        ``save`` if it does not exist.
    """

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir or Path(_DEFAULT_CACHE_DIR)

    def _cache_path(self, file_path: str, hash_val: str) -> Path:
        """Derive a deterministic cache file path from *file_path* and *hash_val*."""
        # Use a hash of the file path to avoid filesystem issues with deep paths.
        path_hash = hashlib.sha256(file_path.encode("utf-8")).hexdigest()[:16]
        return self.cache_dir / f"{path_hash}_{hash_val[:16]}.json"

    def save(
        self,
        file_path: str,
        content_hash_val: str,
        result: dict[str, Any],
    ) -> Path:
        """Persist an understanding result to the cache.

        Returns the path to the saved cache file.
        """
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = self._cache_path(file_path, content_hash_val)
        payload = {
            "file_path": file_path,
            "content_hash": content_hash_val,
            "result": result,
        }
        cache_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        logger.debug("Cached understanding for %s -> %s", file_path, cache_file)
        return cache_file

    def load(
        self,
        file_path: str,
        content_hash_val: str,
    ) -> dict[str, Any] | None:
        """Load a cached understanding result, or return ``None`` if the cache
        is missing or the content hash no longer matches."""
        cache_file = self._cache_path(file_path, content_hash_val)
        if not cache_file.exists():
            return None

        try:
            data = json.loads(cache_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Corrupt cache file %s: %s", cache_file, exc)
            return None

        # Validate hash matches (guards against stale files).
        if data.get("content_hash") != content_hash_val:
            logger.debug("Hash mismatch for %s  -  cache invalidated", file_path)
            return None

        return data.get("result")

    def invalidate(self, file_path: str) -> int:
        """Remove all cached entries for *file_path*.

        Returns the number of cache files removed.
        """
        if not self.cache_dir.exists():
            return 0

        path_hash = hashlib.sha256(file_path.encode("utf-8")).hexdigest()[:16]
        removed = 0
        for cache_file in self.cache_dir.glob(f"{path_hash}_*.json"):
            cache_file.unlink(missing_ok=True)
            removed += 1
        if removed:
            logger.debug("Invalidated %d cache entries for %s", removed, file_path)
        return removed

    def clear(self) -> int:
        """Remove all cached entries.  Returns the number of files removed."""
        if not self.cache_dir.exists():
            return 0
        removed = 0
        for cache_file in self.cache_dir.glob("*.json"):
            cache_file.unlink(missing_ok=True)
            removed += 1
        return removed
