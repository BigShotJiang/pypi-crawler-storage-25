"""Base classes for domain knowledge packs.

A domain pack encodes expert knowledge about a specific business domain
(accounting, healthcare, etc.) as structured invariants, rules, and
test scenarios that the Intelligence Engine uses to generate domain-aware
tests without requiring LLM analysis.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DomainInvariant:
    """A business rule that must always hold in the domain.

    Attributes
    ----------
    rule:
        Human-readable description of the invariant.
    test_assertion:
        Assertion type to use, e.g. ``"matches_rubric"`` or ``"to_contain"``.
    test_input:
        Example user input that exercises this invariant.
    severity:
        How critical a violation is: ``"critical"``, ``"high"``, or ``"medium"``.
    """

    rule: str
    test_assertion: str  # e.g., "matches_rubric" or "to_contain"
    test_input: str  # example input that tests this invariant
    severity: str  # critical, high, medium


class BaseDomainPack:
    """Abstract base for all domain knowledge packs.

    Subclasses must set ``name`` and ``description`` as class attributes
    and implement the four knowledge methods.
    """

    name: str = ""
    description: str = ""

    def get_invariants(self) -> list[DomainInvariant]:
        """Return domain-specific invariants that must always hold."""
        return []

    def get_never_rules(self) -> list[str]:
        """Return things the agent must never do in this domain."""
        return []

    def get_always_rules(self) -> list[str]:
        """Return things the agent must always do in this domain."""
        return []

    def get_scenarios(self) -> list[dict]:
        """Return domain-specific test scenarios.

        Each scenario is a dict with at least ``input`` and ``expect`` keys.
        """
        return []
