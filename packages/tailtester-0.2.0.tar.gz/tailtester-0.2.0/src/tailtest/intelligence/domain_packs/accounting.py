"""Accounting domain knowledge pack.

Encodes invariants, rules, and test scenarios for accounting and
financial systems: journal entries, AR/AP, inventory, tax, fiscal periods.
"""

from __future__ import annotations

from tailtest.intelligence.domain_packs.base import BaseDomainPack, DomainInvariant


class AccountingPack(BaseDomainPack):
    """Domain pack for accounting and financial management systems."""

    name = "accounting"
    description = (
        "Accounting domain pack covering journal entries, AR/AP, inventory, "
        "tax calculations, and fiscal period management."
    )

    def get_invariants(self) -> list[DomainInvariant]:
        return [
            DomainInvariant(
                rule="Journal entries must balance (total debits = total credits)",
                test_assertion="matches_rubric",
                test_input="Create a journal entry with $1000 debit to Cash and $1000 credit to Revenue",
                severity="critical",
            ),
            DomainInvariant(
                rule="Accounts Receivable and Accounts Payable require a counterparty",
                test_assertion="matches_rubric",
                test_input="Create an AR entry without specifying a customer",
                severity="critical",
            ),
            DomainInvariant(
                rule="Inventory quantities must never go negative",
                test_assertion="matches_rubric",
                test_input="Sell 100 units of SKU-001 when only 50 are in stock",
                severity="high",
            ),
            DomainInvariant(
                rule="Tax must be calculated before posting a transaction",
                test_assertion="matches_rubric",
                test_input="Post an invoice for $500 with applicable sales tax",
                severity="high",
            ),
            DomainInvariant(
                rule="Transactions must fall within an open fiscal period",
                test_assertion="matches_rubric",
                test_input="Post a transaction dated January 15 when Q1 fiscal period is closed",
                severity="critical",
            ),
        ]

    def get_never_rules(self) -> list[str]:
        return [
            "Expose internal General Ledger account codes to end users",
            "Allow modifications to closed fiscal periods without reopening",
            "Allow unbalanced journal entries to be posted",
            "Display raw database IDs for financial records",
            "Process payments without proper authorization checks",
        ]

    def get_always_rules(self) -> list[str]:
        return [
            "Show currency symbol with all monetary amounts",
            "Require approval workflow for write-offs above threshold",
            "Maintain a complete audit trail for all financial changes",
            "Display amounts with correct decimal precision for the currency",
            "Include transaction reference numbers in all responses",
        ]

    def get_scenarios(self) -> list[dict]:
        return [
            {
                "input": "Create an invoice for $1,500 for customer Acme Corp",
                "expect": "Should create invoice with correct amount, customer, and auto-calculated tax",
            },
            {
                "input": "Record a payment of $750 against invoice INV-2024-001",
                "expect": "Should apply payment, update AR balance, and create journal entry",
            },
            {
                "input": "Reconcile bank statement for checking account ending 3/31",
                "expect": "Should match transactions and identify discrepancies",
            },
            {
                "input": "Close the fiscal period for Q4 2024",
                "expect": "Should verify all entries posted, generate closing entries, and lock the period",
            },
        ]
