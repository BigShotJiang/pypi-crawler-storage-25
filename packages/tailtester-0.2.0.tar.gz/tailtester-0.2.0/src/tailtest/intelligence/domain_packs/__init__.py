"""Domain knowledge packs for tailtest Intelligence Engine.

Each domain pack provides pre-built invariants, never/always rules,
and test scenarios specific to a business domain. These accelerate
test generation by encoding domain expertise that would otherwise
require LLM analysis or manual user input.

Usage::

    from tailtest.intelligence.domain_packs import get_domain_pack

    pack = get_domain_pack("accounting")
    invariants = pack.get_invariants()
    never_rules = pack.get_never_rules()
"""

from __future__ import annotations

from tailtest.intelligence.domain_packs.base import BaseDomainPack, DomainInvariant

_REGISTRY: dict[str, type[BaseDomainPack]] = {}


def register_pack(pack_cls: type[BaseDomainPack]) -> type[BaseDomainPack]:
    """Register a domain pack class by its ``name`` attribute."""
    _REGISTRY[pack_cls.name] = pack_cls
    return pack_cls


def get_domain_pack(name: str) -> BaseDomainPack:
    """Look up and instantiate a domain pack by name.

    Parameters
    ----------
    name:
        Domain name, e.g. ``"accounting"``, ``"healthcare"``.

    Raises
    ------
    ValueError
        If no pack is registered under *name*.
    """
    if name not in _REGISTRY:
        known = ", ".join(sorted(_REGISTRY.keys())) or "(none)"
        raise ValueError(
            f"Unknown domain pack '{name}'. Available packs: {known}"
        )
    return _REGISTRY[name]()


def list_domain_packs() -> list[str]:
    """Return sorted list of registered domain pack names."""
    return sorted(_REGISTRY.keys())


# Auto-register built-in packs on import.
def _auto_register() -> None:
    from tailtest.intelligence.domain_packs.accounting import AccountingPack
    from tailtest.intelligence.domain_packs.ecommerce import EcommercePack
    from tailtest.intelligence.domain_packs.healthcare import HealthcarePack
    from tailtest.intelligence.domain_packs.support import SupportPack

    for pack_cls in (AccountingPack, EcommercePack, HealthcarePack, SupportPack):
        register_pack(pack_cls)


_auto_register()

__all__ = [
    "BaseDomainPack",
    "DomainInvariant",
    "get_domain_pack",
    "list_domain_packs",
    "register_pack",
]
