"""Ecommerce domain knowledge pack.

Encodes invariants, rules, and test scenarios for online retail systems
covering inventory, pricing, payments, shipping, and order management.
"""

from __future__ import annotations

from tailtest.intelligence.domain_packs.base import BaseDomainPack, DomainInvariant


class EcommercePack(BaseDomainPack):
    """Domain pack for ecommerce and online retail systems."""

    name = "ecommerce"
    description = (
        "Ecommerce domain pack covering inventory management, pricing, "
        "payment processing, shipping, and order lifecycle."
    )

    def get_invariants(self) -> list[DomainInvariant]:
        return [
            DomainInvariant(
                rule="Displayed inventory quantities must match actual stock levels",
                test_assertion="matches_rubric",
                test_input="Show availability for product SKU-WIDGET-100",
                severity="high",
            ),
            DomainInvariant(
                rule="Listed prices must be consistent across product pages, cart, and checkout",
                test_assertion="matches_rubric",
                test_input="Add item to cart and verify the price matches the product page",
                severity="critical",
            ),
            DomainInvariant(
                rule="Payment must be fully authorized before order confirmation",
                test_assertion="matches_rubric",
                test_input="Complete checkout with credit card payment",
                severity="critical",
            ),
            DomainInvariant(
                rule="Shipping costs must be calculated based on destination, weight, and method",
                test_assertion="matches_rubric",
                test_input="Calculate shipping for a 5lb package to ZIP 90210 via standard delivery",
                severity="high",
            ),
        ]

    def get_never_rules(self) -> list[str]:
        return [
            "Expose full payment card numbers, CVV, or raw card data",
            "Allow negative prices or quantities on any order line",
            "Process or confirm orders without verified payment authorization",
            "Display other customers' order details or personal information",
            "Allow checkout when all items in cart are out of stock",
        ]

    def get_always_rules(self) -> list[str]:
        return [
            "Confirm order details with the customer before processing payment",
            "Provide shipment tracking information once available",
            "Calculate and display applicable taxes correctly",
            "Show itemized order summary including subtotal, tax, shipping, and total",
            "Send order confirmation with reference number after successful checkout",
        ]

    def get_scenarios(self) -> list[dict]:
        return [
            {
                "input": "Add 2 units of Blue Widget to my cart",
                "expect": "Should confirm item added, show updated cart total, and check stock availability",
            },
            {
                "input": "Proceed to checkout and pay with card ending 4242",
                "expect": "Should show order summary, calculate tax and shipping, and confirm payment",
            },
            {
                "input": "I want to return order #ORD-5678 for a refund",
                "expect": "Should verify order eligibility, initiate return, and explain refund timeline",
            },
            {
                "input": "Cancel my pending order #ORD-9012",
                "expect": "Should check order status, confirm cancellation, and initiate payment reversal",
            },
        ]
