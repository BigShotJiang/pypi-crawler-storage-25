"""Intelligence Engine  -  three-layer test intelligence for tailtest.

Combines structural scanning (Layer 1), LLM code understanding (Layer 2),
and user-directed rules (Layer 3) to produce comprehensive, domain-aware
tests for AI agents.
"""

from tailtest.intelligence.engine import IntelligenceEngine  # noqa: F401

__all__ = ["IntelligenceEngine"]
