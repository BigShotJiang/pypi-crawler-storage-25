"""tailtest doctor  -  check system health and dependencies."""

import shutil
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()


def _check_python_version() -> tuple[str, str, bool]:
    """Check Python version meets minimum requirement."""
    version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    ok = sys.version_info >= (3, 11)
    status = f"Python {version}" if ok else f"Python {version} (requires >= 3.11)"
    return "Python", status, ok


def _check_ollama() -> tuple[str, str, bool]:
    """Check if ollama is installed and accessible."""
    path = shutil.which("ollama")
    if path:
        return "Ollama", f"found at {path}", True
    return "Ollama", "not found (needed for local LLM judge)", False


def _check_tailtest_dir() -> tuple[str, str, bool]:
    """Check if .tailtest/ directory is initialized."""
    tailtest_dir = Path.cwd() / ".tailtest"
    if tailtest_dir.is_dir():
        return ".tailtest/", "initialized", True
    return ".tailtest/", "not found (run 'tailtest init')", False


def _check_config() -> tuple[str, str, bool]:
    """Check if config.yaml exists."""
    config_path = Path.cwd() / ".tailtest" / "config.yaml"
    if config_path.is_file():
        return "Config", "config.yaml found", True
    return "Config", "config.yaml missing", False


def _check_dependency(module_name: str, display_name: str) -> tuple[str, str, bool]:
    """Check if a Python dependency is importable."""
    try:
        mod = __import__(module_name)
        version = getattr(mod, "__version__", getattr(mod, "VERSION", "installed"))
        return display_name, f"{version}", True
    except ImportError:
        return display_name, "not installed", False


@click.command("doctor")
def doctor_cmd() -> None:
    """Check system health, dependencies, and configuration.

    Verifies that all required tools and libraries are installed,
    the project is initialized, and optional components (like Ollama
    for local LLM judging) are available.
    """
    console.print()
    console.print("[bold]Tailtest Doctor[/bold]")
    console.print("[dim]Checking system health...[/dim]")
    console.print()

    checks: list[tuple[str, str, bool]] = []

    # Core checks
    checks.append(_check_python_version())
    checks.append(_check_ollama())
    checks.append(_check_tailtest_dir())
    checks.append(_check_config())

    # Dependency checks
    checks.append(_check_dependency("click", "click"))
    checks.append(_check_dependency("pydantic", "pydantic"))
    checks.append(_check_dependency("httpx", "httpx"))
    checks.append(_check_dependency("litellm", "litellm"))
    checks.append(_check_dependency("rich", "rich"))
    checks.append(_check_dependency("watchfiles", "watchfiles"))
    checks.append(_check_dependency("jinja2", "jinja2"))

    # Build results table
    table = Table(title="System Health", show_header=True, header_style="bold")
    table.add_column("Check", style="cyan", min_width=14)
    table.add_column("Status", min_width=30)
    table.add_column("", width=4, justify="center")

    all_ok = True
    for name, status, ok in checks:
        icon = "[green]OK[/green]" if ok else "[red]!![/red]"
        style = "" if ok else "dim"
        table.add_row(name, status, icon)
        if not ok:
            all_ok = False

    console.print(table)
    console.print()

    if all_ok:
        console.print("[bold green]All checks passed.[/bold green]")
    else:
        console.print("[bold yellow]Some checks need attention.[/bold yellow]")

    console.print()
