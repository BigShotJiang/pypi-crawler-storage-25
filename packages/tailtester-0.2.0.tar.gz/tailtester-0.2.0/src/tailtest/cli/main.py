"""Tailtest CLI  -  the root command group and entry point."""

import click

from tailtest import __version__
from tailtest.cli.doctor import doctor_cmd
from tailtest.cli.drift import drift_cmd
from tailtest.cli.status import status_cmd
from tailtest.cli.suggest import suggest_cmd
from tailtest.cli.generate import generate_cmd
from tailtest.cli.guard import guard_cmd
from tailtest.cli.ingest import ingest_cmd
from tailtest.cli.init_cmd import init_cmd
from tailtest.cli.mcp_serve import mcp_serve_cmd
from tailtest.cli.optimize import optimize_cmd
from tailtest.cli.predict import predict_cmd
from tailtest.cli.record import record_cmd
from tailtest.cli.redteam import redteam_cmd
from tailtest.cli.replay import replay_cmd
from tailtest.cli.report import report_cmd
from tailtest.cli.run import run_cmd
from tailtest.cli.scan import scan_cmd
from tailtest.cli.watch import watch_cmd


@click.group()
@click.version_option(version=__version__, prog_name="tailtest")
def cli() -> None:
    """Tailtest -- The pytest for AI agents.

    Auto-generate and run tests for any AI agent, from any framework,
    with any model, at any stage of development.

    Quick start:

    \b
      tailtest init            Initialize a project
      tailtest scan .          Scan your agent code
      tailtest generate        Generate tests
      tailtest run             Run all tests
      tailtest doctor          Check system health
    """


# Register all subcommands
cli.add_command(init_cmd)
cli.add_command(scan_cmd)
cli.add_command(run_cmd)
cli.add_command(generate_cmd)
cli.add_command(redteam_cmd)
cli.add_command(watch_cmd)
cli.add_command(guard_cmd)
cli.add_command(ingest_cmd)
cli.add_command(record_cmd)
cli.add_command(replay_cmd)
cli.add_command(report_cmd)
cli.add_command(doctor_cmd)
cli.add_command(drift_cmd)
cli.add_command(status_cmd)
cli.add_command(suggest_cmd)
cli.add_command(predict_cmd)
cli.add_command(optimize_cmd)
cli.add_command(mcp_serve_cmd)
