"""tailtest status  -  show maturity level, calibrated thresholds, and patterns."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command("status")
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project directory (default: current directory).",
)
def status_cmd(project_dir: str) -> None:
    """Show maturity engine status.

    Displays the current maturity level, calibrated thresholds,
    identified failure patterns, and flaky tests.

    \b
    Examples:
      tailtest status
      tailtest status --project-dir /path/to/project
    """
    from tailtest.maturity import MaturityEngine
    from tailtest.maturity.flaky import FlakyDetector
    from tailtest.maturity.tracker import MaturityLevel, MaturityTracker

    project = Path(project_dir)
    engine = MaturityEngine(project)
    state = engine.state

    tracker = MaturityTracker()
    runs_left = tracker.runs_to_next_level(state)

    console.print()

    # -- Level --
    level = engine.level
    total_runs = state.stats.total_runs
    level_style = {
        MaturityLevel.SEEDLING: "yellow",
        MaturityLevel.GROWING: "green",
        MaturityLevel.MATURE: "bold cyan",
    }.get(level, "white")

    progress = ""
    if level == MaturityLevel.SEEDLING:
        progress = f"  ({total_runs}/10 runs to Growing)"
    elif level == MaturityLevel.GROWING:
        progress = f"  ({total_runs}/50 runs to Mature)"

    console.print(f"  [bold]Maturity Level:[/bold] [{level_style}]{level.value.title()}[/{level_style}]{progress}")
    console.print(f"  [bold]Total Runs:[/bold] {total_runs}")

    if state.stats.first_run:
        console.print(f"  [bold]First Run:[/bold] {state.stats.first_run:%Y-%m-%d %H:%M}")
    if state.stats.last_run:
        console.print(f"  [bold]Last Run:[/bold]  {state.stats.last_run:%Y-%m-%d %H:%M}")

    console.print(f"  [bold]Tests Executed:[/bold] {state.stats.total_tests_executed}")
    console.print(f"  [bold]Unique Tests:[/bold] {state.stats.unique_test_names}")
    console.print()

    # -- Calibrated thresholds (growing+) --
    if level >= MaturityLevel.GROWING and state.calibrated_thresholds:
        console.print("  [bold]Calibrated Thresholds:[/bold]")
        for metric, ct in state.calibrated_thresholds.items():
            if metric == "cost_usd":
                console.print(
                    f"    cost:    ${ct.calibrated:.4f}  "
                    f"(default: ${ct.default:.2f}, p50: ${ct.observed_p50 or 0:.4f}, p95: ${ct.observed_p95 or 0:.4f})"
                )
            else:
                console.print(
                    f"    latency: {ct.calibrated:.0f}ms  "
                    f"(default: {ct.default:.0f}ms, p50: {ct.observed_p50 or 0:.0f}ms, p95: {ct.observed_p95 or 0:.0f}ms)"
                )
        console.print()

    # -- Failure patterns --
    if state.failure_patterns:
        console.print(f"  [bold]Failure Patterns:[/bold] {len(state.failure_patterns)} identified")
        for category, pattern in state.failure_patterns.items():
            tests_str = ", ".join(pattern.affected_tests[:3])
            if len(pattern.affected_tests) > 3:
                tests_str += f" (+{len(pattern.affected_tests) - 3} more)"
            console.print(
                f"    [red]{category}[/red]: {pattern.count} occurrence(s), "
                f"affects [{tests_str}]"
            )
            if pattern.triggers:
                triggers_str = ", ".join(f'"{t}"' for t in pattern.triggers[:3])
                console.print(f"      triggers: {triggers_str}")
        console.print()

    # -- Flaky tests --
    detector = FlakyDetector()
    flaky_tests = detector.detect(state.test_profiles)
    if flaky_tests:
        console.print(f"  [bold]Flaky Tests:[/bold] {len(flaky_tests)}")
        for ft in flaky_tests[:5]:
            console.print(
                f"    [yellow]{ft.name}[/yellow] -- {ft.flake_rate:.1%} flake rate "
                f"({ft.passes}/{ft.runs} pass)"
            )
        console.print()

    # -- Next level --
    if runs_left is not None:
        next_name = "Growing" if level == MaturityLevel.SEEDLING else "Mature"
        console.print(f"  [dim]Next level ({next_name}): {runs_left} more run(s) needed[/dim]")
        console.print()
