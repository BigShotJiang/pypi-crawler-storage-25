"""tailtest guard  -  production validation proxy."""

from __future__ import annotations

import asyncio
import signal
from pathlib import Path

import click
from rich.console import Console
from rich.live import Live
from rich.table import Table

from tailtest.production.guard import GuardProxy

console = Console()


def _build_metrics_table(proxy: GuardProxy) -> Table:
    """Build a rich table displaying live guard proxy metrics."""
    m = proxy.metrics
    table = Table(title="Guard Proxy Metrics", show_header=True)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right", style="cyan")

    table.add_row("Total requests", str(m.total_requests))
    table.add_row("Passed", f"[green]{m.passed_requests}[/green]")
    table.add_row("Failed", f"[red]{m.failed_requests}[/red]" if m.failed_requests else "0")
    table.add_row("Blocked", f"[red]{m.blocked_requests}[/red]" if m.blocked_requests else "0")
    table.add_row("Pass rate", f"{m.pass_rate:.1%}")
    table.add_row("Avg latency", f"{m.avg_latency_ms:.1f}ms")
    table.add_row("Requests/sec", f"{m.requests_per_second:.2f}")
    table.add_row("Uptime", f"{m.uptime_seconds:.0f}s")

    return table


@click.command("guard")
@click.option(
    "--port",
    type=int,
    default=8080,
    show_default=True,
    help="Port to run the guard proxy on.",
)
@click.option(
    "--upstream",
    type=str,
    default=None,
    help="Upstream URL to proxy requests to.",
)
@click.option(
    "--block/--no-block",
    "block_on_failure",
    default=False,
    show_default=True,
    help="Block responses that fail validation (return 422 instead).",
)
@click.option(
    "--max-cost",
    type=float,
    default=1.0,
    show_default=True,
    help="Maximum cost per request (USD).",
)
@click.option(
    "--max-latency",
    type=int,
    default=30000,
    show_default=True,
    help="Maximum latency per request (ms).",
)
@click.option(
    "--audit-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory for audit logs (default: .tailtest/audit/).",
)
def guard_cmd(
    port: int,
    upstream: str | None,
    block_on_failure: bool,
    max_cost: float,
    max_latency: int,
    audit_dir: Path | None,
) -> None:
    """Start a production validation proxy.

    Intercepts agent requests and responses in real-time, running
    validation checks (no PII, no loops, cost/latency limits) before
    forwarding. Logs results to an audit trail.

    \b
    Examples:
      tailtest guard --upstream http://localhost:3000
      tailtest guard --port 9090 --upstream http://agent:8000 --block
      tailtest guard --upstream http://localhost:3000 --max-cost 0.50
    """
    if not upstream:
        console.print()
        console.print("[red]Error: --upstream URL is required.[/red]")
        console.print("[dim]  Example: tailtest guard --upstream http://localhost:3000[/dim]")
        console.print()
        return

    proxy = GuardProxy(
        upstream_url=upstream,
        port=port,
        block_on_failure=block_on_failure,
        audit_dir=audit_dir,
        max_cost=max_cost,
        max_latency_ms=max_latency,
    )

    console.print()
    console.print(f"[bold]Starting guard proxy on port[/bold] [cyan]{port}[/cyan]...")
    console.print(f"[dim]  Upstream: {upstream}[/dim]")
    console.print(f"[dim]  Block on failure: {block_on_failure}[/dim]")
    console.print(f"[dim]  Max cost: ${max_cost:.2f}[/dim]")
    console.print(f"[dim]  Max latency: {max_latency}ms[/dim]")
    console.print(f"[dim]  Health: http://0.0.0.0:{port}/_guard/health[/dim]")
    console.print(f"[dim]  Metrics: http://0.0.0.0:{port}/_guard/metrics[/dim]")
    console.print()

    rules_str = ", ".join(type(r).__name__ for r in proxy.rules)
    console.print(f"[dim]  Rules: {rules_str}[/dim]")
    console.print()
    console.print("[green]Proxying requests... Press Ctrl+C to stop.[/green]")
    console.print()

    async def _serve() -> None:
        server = await proxy.start()
        stop_event = asyncio.Event()

        def _signal_handler() -> None:
            stop_event.set()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _signal_handler)

        # Refresh metrics display periodically
        try:
            with Live(
                _build_metrics_table(proxy),
                console=console,
                refresh_per_second=1,
            ) as live:
                while not stop_event.is_set():
                    await asyncio.sleep(1)
                    live.update(_build_metrics_table(proxy))
        except asyncio.CancelledError:
            pass

        console.print()
        console.print("[yellow]Shutting down guard proxy...[/yellow]")
        await proxy.stop()

        # Final metrics
        console.print()
        console.print(_build_metrics_table(proxy))
        console.print()
        console.print(
            f"[dim]Audit logs written to {proxy.audit_dir}/[/dim]"
        )

    asyncio.run(_serve())
