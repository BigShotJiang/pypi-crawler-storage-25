"""tailtest scan  -  scan an agent project to build context."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("scan")
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option(
    "--deep",
    is_flag=True,
    default=False,
    help="Include git history analysis for deeper context.",
)
@click.option(
    "--understand",
    is_flag=True,
    default=False,
    help="Run LLM understanding on scanned files (Layer 2 intelligence).",
)
@click.option(
    "--output",
    type=click.Choice(["json", "text"], case_sensitive=False),
    default="text",
    help="Output format for scan results.",
)
@click.option(
    "--ssh",
    "ssh_target",
    type=str,
    default=None,
    help="Remote scan via SSH (user@host:/path/to/project).",
)
def scan_cmd(path: str, deep: bool, understand: bool, output: str, ssh_target: str | None) -> None:
    """Scan an agent project to build context for test generation.

    PATH is the root directory to scan (defaults to current directory).
    Discovers agent code, tool definitions, prompts, and configuration
    to feed into the test generator.

    \b
    Remote scan via SSH:
      tailtest scan --ssh user@host:/path/to/project
    """
    if ssh_target:
        resolved = _remote_scan_via_ssh(ssh_target)
        if resolved is None:
            return
    else:
        resolved = Path(path).resolve()
    console.print()
    console.print(f"[bold]Scanning[/bold] [cyan]{resolved}[/cyan] ...")

    if deep:
        console.print("[dim]  Deep mode: including git history analysis[/dim]")
    if understand:
        console.print("[dim]  Understanding mode: LLM analysis enabled[/dim]")

    from tailtest.context.engine import ContextEngine

    engine = ContextEngine()
    result = asyncio.run(engine.scan(resolved, deep=deep))

    # Save context
    tailtest_dir = resolved / ".tailtest"
    if tailtest_dir.exists():
        engine.save_context(result, tailtest_dir / "context")

    console.print()

    if output == "json":
        console.print(json.dumps(result.model_dump(), indent=2))
    else:
        console.print(f"  Framework:    [cyan]{result.framework}[/cyan]")
        if result.framework_version:
            console.print(f"  Version:      [cyan]{result.framework_version}[/cyan]")
        console.print(f"  Tools:        [cyan]{len(result.tools)}[/cyan] discovered")
        console.print(f"  Prompts:      [cyan]{len(result.prompts)}[/cyan] discovered")
        console.print(f"  Agents:       [cyan]{len(result.agents)}[/cyan] discovered")
        console.print(f"  Models:       [cyan]{', '.join(result.models) or 'none'}[/cyan]")
        console.print(f"  Dependencies: [cyan]{len(result.dependencies)}[/cyan]")
        console.print(f"  Env vars:     [cyan]{len(result.env_vars)}[/cyan]")

    # --- Layer 2: LLM Understanding ---
    if understand:
        _run_understanding(resolved, result)

    console.print()
    console.print("[bold green]Scan complete.[/bold green]")
    if tailtest_dir.exists():
        console.print("[dim]Context saved to .tailtest/context/[/dim]")
    else:
        console.print("[dim]Run 'tailtest init' first to persist context.[/dim]")
    console.print()


def _run_understanding(project_dir: Path, result: object) -> None:
    """Run LLM understanding on Python files discovered during scanning."""
    from tailtest.intelligence.cache import UnderstandingCache
    from tailtest.intelligence.understanding import CodeUnderstanding

    cache_dir = project_dir / ".tailtest" / "context" / "understanding"
    cache = UnderstandingCache(cache_dir=cache_dir)
    understanding = CodeUnderstanding(cache=cache)

    # Collect Python files to analyse (same files the scanner would have seen).
    py_files: list[tuple[str, str]] = []
    for py_path in sorted(project_dir.rglob("*.py")):
        # Skip hidden dirs and common non-source dirs.
        parts = py_path.relative_to(project_dir).parts
        skip_dirs = {".venv", "venv", "node_modules", "__pycache__", ".git", "dist", "build"}
        if any(p in skip_dirs for p in parts):
            continue
        try:
            content = py_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if len(content.strip()) < 20:
            continue
        py_files.append((str(py_path), content))

    if not py_files:
        console.print("\n  [dim]No files to analyse for understanding.[/dim]")
        return

    console.print(f"\n  [bold]Understanding[/bold] {len(py_files)} files ...")

    def on_progress(current: int, total: int, path: str) -> None:
        short = Path(path).name
        console.print(f"    [{current}/{total}] {short}")

    results = asyncio.run(
        understanding.analyse_files(py_files, on_progress=on_progress)
    )

    total_cost = sum(r.cost_usd for r in results)
    cached_count = sum(1 for r in results if r.from_cache)

    console.print()
    console.print(f"  Files analysed: [cyan]{len(results)}[/cyan]")
    console.print(f"  From cache:     [cyan]{cached_count}[/cyan]")
    console.print(f"  LLM cost:       [cyan]${total_cost:.4f}[/cyan]")


def _remote_scan_via_ssh(ssh_target: str) -> Path | None:
    """SSH to a remote host, tar Python files, transfer, and extract locally.

    Expects ssh_target in the form ``user@host:/path/to/project``.
    Returns a local temporary directory path on success, or None on failure.
    """
    import shutil
    import subprocess
    import tempfile

    # Parse target
    if ":" not in ssh_target:
        console.print("[red]SSH target must be in the form user@host:/path/to/project[/red]")
        return None

    host_part, remote_path = ssh_target.rsplit(":", 1)
    if not remote_path:
        remote_path = "."

    console.print()
    console.print(f"[bold]Remote scan[/bold] via SSH to [cyan]{host_part}[/cyan]")
    console.print(f"  Remote path: [cyan]{remote_path}[/cyan]")

    # Create temp directory for extracted files
    tmp_dir = Path(tempfile.mkdtemp(prefix="tailtest_remote_"))

    try:
        # SSH and tar Python files, pipe to local extraction
        tar_cmd = (
            f"cd {remote_path} && "
            f"find . -name '*.py' "
            f"-not -path './.venv/*' "
            f"-not -path './venv/*' "
            f"-not -path './__pycache__/*' "
            f"-not -path './.git/*' "
            f"-not -path './node_modules/*' "
            f"| tar -czf - -T -"
        )

        console.print("[dim]  Transferring Python files...[/dim]")

        ssh_proc = subprocess.run(
            ["ssh", "-o", "ConnectTimeout=10", host_part, tar_cmd],
            capture_output=True,
            timeout=60,
        )

        if ssh_proc.returncode != 0:
            console.print(f"[red]SSH failed: {ssh_proc.stderr.decode(errors='replace').strip()}[/red]")
            shutil.rmtree(tmp_dir, ignore_errors=True)
            return None

        # Write tarball to temp file and extract
        tar_path = tmp_dir / "remote.tar.gz"
        tar_path.write_bytes(ssh_proc.stdout)

        subprocess.run(
            ["tar", "-xzf", str(tar_path), "-C", str(tmp_dir)],
            check=True,
            timeout=30,
        )

        # Clean up tarball
        tar_path.unlink()

        py_count = len(list(tmp_dir.rglob("*.py")))
        console.print(f"  [green]Transferred {py_count} Python files[/green]")

        # Register cleanup for after scan completes
        import atexit
        atexit.register(lambda: shutil.rmtree(tmp_dir, ignore_errors=True))

        return tmp_dir

    except subprocess.TimeoutExpired:
        console.print("[red]SSH connection timed out[/red]")
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return None
    except Exception as exc:
        console.print(f"[red]Remote scan failed: {exc}[/red]")
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return None
