"""tailtest redteam  -  adversarial red-team testing for agents."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from tailtest.redteam.attacks import ALL_CATEGORIES, count_attacks, get_all_attacks
from tailtest.redteam.compliance import (
    AttackResult,
    OWASPAgentsChecker,
    OWASPLLMChecker,
)
from tailtest.redteam.engine import RedTeamReport
from tailtest.reporting.compliance_report import ComplianceReporter

console = Console()

# Severity -> Rich colour
_SEV_COLOURS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "dim",
}


def _severity_styled(severity: str) -> str:
    colour = _SEV_COLOURS.get(severity, "white")
    return f"[{colour}]{severity.upper()}[/{colour}]"


def _pass_fail(passed: bool) -> str:
    return "[green]PASS[/green]" if passed else "[bold red]FAIL[/bold red]"


def _display_results_table(results: list[AttackResult]) -> None:
    """Render attack results as a Rich table."""
    table = Table(
        title="Red-Team Attack Results",
        show_lines=True,
        title_style="bold",
        border_style="dim",
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Attack", min_width=30)
    table.add_column("Category", min_width=16)
    table.add_column("Severity", min_width=10, justify="center")
    table.add_column("Result", min_width=6, justify="center")

    for idx, r in enumerate(results, 1):
        table.add_row(
            str(idx),
            r.attack_name,
            r.category,
            _severity_styled(r.severity),
            _pass_fail(r.passed),
        )

    console.print()
    console.print(table)


def _display_summary(
    total: int,
    passed: int,
    failed: int,
    results: list[AttackResult],
    categories: list[str],
) -> None:
    """Render the summary section."""
    console.print()

    pct = (passed / total * 100) if total > 0 else 0
    if pct == 100:
        colour = "bold green"
    elif pct >= 80:
        colour = "yellow"
    else:
        colour = "bold red"

    console.print(
        f"[bold]Summary:[/bold]  "
        f"[{colour}]{passed}/{total} attacks resisted "
        f"({pct:.0f}%)[/{colour}]"
    )
    console.print(f"  Categories tested: {', '.join(categories)}")

    # Vulnerabilities found
    failures = [r for r in results if not r.passed]
    if failures:
        console.print()
        console.print("[bold red]Vulnerabilities found:[/bold red]")
        for r in failures:
            console.print(
                f"  [{_SEV_COLOURS.get(r.severity, 'white')}]"
                f"[{r.severity.upper()}][/{_SEV_COLOURS.get(r.severity, 'white')}] "
                f"{r.attack_name} ({r.category})"
            )
    else:
        console.print()
        console.print(
            "[bold green]No vulnerabilities found. Agent resisted all attacks.[/bold green]"
        )


def _collect_attack_results(
    intensity: str,
    categories: list[str] | None,
) -> list[AttackResult]:
    """Build AttackResult entries from the attack library.

    When a live agent interface is not available we perform a dry run:
    load every matching attack and produce a NOT-TESTED placeholder
    result for each.  This allows the OWASP compliance checkers to
    generate a meaningful (if partial) report.
    """
    attacks = get_all_attacks(categories=categories, intensity=intensity)  # type: ignore[arg-type]
    return [
        AttackResult(
            attack_name=a.name,
            category=a.category.value,
            passed=True,
            severity=a.severity.value,
            details="Dry run -- no agent was tested.",
            tags=[a.owasp_id] if a.owasp_id else [],
        )
        for a in attacks
    ]


def _run_owasp_compliance(
    report_fmt: str,
    attack_results: list[AttackResult] | None = None,
) -> None:
    """Execute OWASP compliance checks and print/write the report."""
    results = attack_results if attack_results is not None else []

    console.print("[dim]  Evaluating OWASP Top 10 for LLMs 2025...[/dim]")
    llm_checker = OWASPLLMChecker()
    llm_checks = llm_checker.evaluate(results)

    console.print("[dim]  Evaluating OWASP Top 10 for Agentic Applications 2026...[/dim]")
    agents_checker = OWASPAgentsChecker()
    agent_checks = agents_checker.evaluate(results)

    reporter = ComplianceReporter()

    # Always print text to terminal
    text_report = reporter.text(llm_checks, agent_checks)
    console.print(text_report)

    # Write report file if not text
    if report_fmt != "text":
        path = reporter.write(report_fmt, llm_checks, agent_checks)
        console.print(f"[green]Compliance report written to {path}[/green]")


@click.command("redteam")
@click.option(
    "--quick",
    is_flag=True,
    default=False,
    help="Quick scan (~5 minutes) with core attack vectors.",
)
@click.option(
    "--thorough",
    is_flag=True,
    default=False,
    help="Thorough scan (30+ minutes) with exhaustive attack coverage.",
)
@click.option(
    "--owasp",
    is_flag=True,
    default=False,
    help="Run OWASP LLM Top 10 and Agentic Top 10 compliance checks.",
)
@click.option(
    "--custom",
    type=click.Path(exists=True),
    default=None,
    help="Path to a custom attack definitions YAML file.",
)
@click.option(
    "--report",
    "report_fmt",
    type=click.Choice(["html", "json", "text"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Report output format.",
)
@click.option(
    "--category",
    "categories",
    multiple=True,
    type=click.Choice(ALL_CATEGORIES, case_sensitive=False),
    help="Only run attacks from specific categories (repeatable).",
)
@click.option(
    "--agent-url",
    default=None,
    help="HTTP endpoint of the agent to test.",
)
def redteam_cmd(
    quick: bool,
    thorough: bool,
    owasp: bool,
    custom: str | None,
    report_fmt: str,
    categories: tuple[str, ...],
    agent_url: str | None,
) -> None:
    """Run adversarial red-team tests against your agent.

    Tests for prompt injection, jailbreaks, data exfiltration, tool misuse,
    and other attack vectors from the OWASP LLM Top 10.

    By default runs a standard scan. Use --quick for a fast check or
    --thorough for exhaustive coverage.

    Use --owasp to evaluate results against both the OWASP Top 10 for
    LLMs 2025 and the OWASP Top 10 for Agentic Applications 2026.
    """
    console.print()

    # Determine intensity
    if quick and thorough:
        console.print("[red]Cannot use --quick and --thorough together.[/red]")
        raise SystemExit(1)

    if quick:
        intensity = "quick"
        console.print("[bold]Running red-team suite[/bold] [dim](quick ~5 min)[/dim]")
    elif thorough:
        intensity = "thorough"
        console.print("[bold]Running red-team suite[/bold] [dim](thorough ~30+ min)[/dim]")
    else:
        intensity = "standard"
        console.print("[bold]Running red-team suite[/bold] [dim](standard)[/dim]")

    if owasp:
        console.print("[dim]  OWASP compliance enabled (LLM Top 10 + Agentic Top 10)[/dim]")
    if custom:
        console.print(f"[dim]  Custom attacks: {custom}[/dim]")
    console.print(f"[dim]  Report format: {report_fmt}[/dim]")

    cat_list = list(categories) if categories else None

    # Show attack counts
    counts = count_attacks(intensity)
    total = sum(
        v for k, v in counts.items()
        if cat_list is None or k in cat_list
    )
    active_cats = {
        k: v for k, v in sorted(counts.items())
        if cat_list is None or k in cat_list
    }
    console.print()
    console.print(
        f"  Loaded [bold]{total}[/bold] attacks across "
        f"[bold]{len(active_cats)}[/bold] categories"
    )
    for cat, cnt in active_cats.items():
        console.print(f"    {cat}: {cnt} attacks")
    console.print()

    # Collect results (dry-run when no agent is connected)
    attack_results = _collect_attack_results(intensity, cat_list)
    tested_categories = sorted(set(r.category for r in attack_results))

    if agent_url is None:
        console.print(
            "[yellow]Note:[/yellow] No agent interface configured. "
            "Showing dry-run results."
        )
        console.print(
            "[dim]To run attacks live, pass --agent-url http://localhost:8000/chat[/dim]"
        )
        console.print()

    # Display results table
    _display_results_table(attack_results)

    # Display summary
    passed = sum(1 for r in attack_results if r.passed)
    failed = total - passed
    _display_summary(total, passed, failed, attack_results, tested_categories)

    # OWASP compliance
    if owasp:
        _run_owasp_compliance(report_fmt=report_fmt, attack_results=attack_results)

    console.print()

    if failed > 0:
        raise SystemExit(1)
