"""tailtest suggest  -  show and generate test suggestions from failure patterns."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("suggest")
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project directory (default: current directory).",
)
@click.option(
    "--apply",
    is_flag=True,
    default=False,
    help="Generate a test file from suggestions.",
)
@click.option(
    "--output",
    type=click.Path(),
    default=None,
    help="Output file path for generated tests (default: tests/test_suggested.py).",
)
@click.option(
    "--max",
    "max_suggestions",
    type=int,
    default=10,
    help="Maximum number of suggestions to show.",
)
def suggest_cmd(
    project_dir: str,
    apply: bool,
    output: str | None,
    max_suggestions: int,
) -> None:
    """Suggest new tests based on observed failure patterns.

    Analyses accumulated failure patterns from the maturity engine and
    suggests targeted tests.  Use ``--apply`` to generate a test file.

    \b
    Examples:
      tailtest suggest
      tailtest suggest --apply
      tailtest suggest --apply --output tests/test_regressions.py
    """
    from tailtest.maturity import MaturityEngine
    from tailtest.maturity.suggester import TestSuggester
    from tailtest.maturity.tracker import MaturityLevel

    project = Path(project_dir)
    engine = MaturityEngine(project)

    if engine.level < MaturityLevel.GROWING:
        runs_needed = 10 - engine.state.stats.total_runs
        console.print()
        console.print(
            f"  [yellow]Suggestions require Growing maturity level.[/yellow]  "
            f"{runs_needed} more run(s) needed."
        )
        console.print()
        return

    suggestions = engine.suggest_tests()

    if not suggestions:
        console.print()
        console.print("  [dim]No suggestions available. No failure patterns found yet.[/dim]")
        console.print()
        return

    # Limit
    suggestions = suggestions[:max_suggestions]

    console.print()
    total_runs = engine.state.stats.total_runs
    console.print(
        f"  [bold]Based on {total_runs} runs, I suggest {len(suggestions)} new test(s):[/bold]"
    )
    console.print()

    for i, s in enumerate(suggestions, 1):
        console.print(f"  {i}. [cyan]{s.name}[/cyan]")
        console.print(f"     {s.description}")
        console.print(f"     [dim]{s.rationale}[/dim]")
        console.print()

    if not apply:
        console.print("  Run [bold]tailtest suggest --apply[/bold] to generate test files.")
        console.print()
        return

    # -- Generate test file --
    suggester = TestSuggester()
    file_content = suggester.generate_test_file(suggestions)

    output_path = Path(output) if output else project / "tests" / "test_suggested.py"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(file_content, encoding="utf-8")

    console.print(f"  [green]Generated test file:[/green] {output_path}")
    console.print()
