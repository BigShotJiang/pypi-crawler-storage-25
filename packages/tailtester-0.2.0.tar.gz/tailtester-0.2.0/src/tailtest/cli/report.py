"""tailtest report  -  generate reports from test results."""

from __future__ import annotations

import json
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

import click
from rich.console import Console
from rich.text import Text

from tailtest.reporting.aggregator import ReportAggregator, TrendReport
from tailtest.reporting.html_report import HTMLReportGenerator
from tailtest.reporting.json_report import JSONReporter, REPORTS_DIR
from tailtest.reporting.sparkline import sparkline, trend_indicator

console = Console()


# ── Helpers ────────────────────────────────────────────────────────────────


def _print_trend_terminal(trend: TrendReport) -> None:
    """Render a trend report as rich terminal output."""
    console.print()
    console.print(Text("  Tailtest Quality Report", style="bold cyan"))
    console.print(
        Text(f"  Period: {trend.period}  |  Runs: {trend.total_runs}", style="dim")
    )
    console.print()

    if not trend.points:
        console.print("  [dim]No data available for this period.[/dim]")
        console.print()
        return

    # Summary line
    pass_rates = [p.pass_rate for p in trend.points]
    costs = [p.cost_usd for p in trend.points]
    durations = [p.duration_ms for p in trend.points]

    pr_spark = sparkline(pass_rates)
    pr_trend = trend_indicator(pass_rates)
    cost_spark = sparkline(costs)
    cost_trend = trend_indicator(costs)

    pct_style = "green" if trend.avg_pass_rate >= 90 else "yellow" if trend.avg_pass_rate >= 70 else "red"
    avg_cost_str = f"${trend.avg_cost:.4f}" if trend.avg_cost < 1 else f"${trend.avg_cost:.2f}"

    console.print(Text("  Pass Rate: ", style="bold") + Text(f"{trend.avg_pass_rate:.1f}%", style=pct_style))
    console.print(Text(f"    {pr_spark} {pr_trend}", style="dim"))
    console.print()

    console.print(Text("  Avg Cost:  ", style="bold") + Text(avg_cost_str))
    console.print(Text(f"    {cost_spark} {cost_trend}", style="dim"))
    console.print()

    if durations:
        dur_spark = sparkline(durations)
        dur_trend = trend_indicator(durations)
        avg_dur = sum(durations) / len(durations)
        dur_str = f"{avg_dur:.0f}ms" if avg_dur < 1000 else f"{avg_dur / 1000:.1f}s"
        console.print(Text("  Avg Time:  ", style="bold") + Text(dur_str))
        console.print(Text(f"    {dur_spark} {dur_trend}", style="dim"))
        console.print()

    # Flaky tests
    if trend.flaky_tests:
        console.print(Text("  Flaky Tests:", style="bold yellow"))
        for ft in trend.flaky_tests[:10]:
            console.print(
                Text(f"    {ft.name}", style="yellow")
                + Text(f"  ({ft.flake_rate:.0f}% flake, {ft.total_runs} runs)", style="dim")
            )
        console.print()

    # New failures
    if trend.new_failures:
        console.print(Text("  New Failures:", style="bold red"))
        for name in trend.new_failures[:10]:
            console.print(Text(f"    {name}", style="red"))
        console.print()

    # Fixed tests
    if trend.fixed_tests:
        console.print(Text("  Fixed Tests:", style="bold green"))
        for name in trend.fixed_tests[:10]:
            console.print(Text(f"    {name}", style="green"))
        console.print()


def _load_latest_report() -> TrendReport | None:
    """Load the single most recent report as a 1-point TrendReport."""
    aggregator = ReportAggregator()
    return aggregator.trend(period="latest", last_n=1)


def _load_compliance_data(framework: str) -> dict | None:
    """Attempt to load the latest compliance report from disk."""
    reports_dir = REPORTS_DIR
    if not reports_dir.exists():
        return None

    # Find the most recent compliance report JSON.
    compliance_files = sorted(reports_dir.glob("compliance_*.json"), reverse=True)
    if not compliance_files:
        return None

    try:
        data = json.loads(compliance_files[0].read_text(encoding="utf-8"))
        return data
    except Exception:
        return None


# ── CLI command ────────────────────────────────────────────────────────────


@click.command("report")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["html", "json", "text"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Report output format.",
)
@click.option(
    "--trend",
    "show_trend",
    is_flag=True,
    default=False,
    help="Show trend from last 30 runs.",
)
@click.option(
    "--daily",
    is_flag=True,
    default=False,
    help="Summary of last 24 hours.",
)
@click.option(
    "--weekly",
    is_flag=True,
    default=False,
    help="Summary of last 7 days.",
)
@click.option(
    "--open",
    "open_browser",
    is_flag=True,
    default=False,
    help="Open HTML report in browser after generating.",
)
@click.option(
    "--compliance",
    type=click.Choice(["eu-ai-act", "nist", "soc2"], case_sensitive=False),
    default=None,
    help="Include compliance report data.",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Output file path (default: auto-generated).",
)
def report_cmd(
    fmt: str,
    show_trend: bool,
    daily: bool,
    weekly: bool,
    open_browser: bool,
    compliance: str | None,
    output: str | None,
) -> None:
    """Generate a report from test results.

    Summarizes test results, pass/fail rates, reliability scores,
    cost breakdown, and optionally maps results to compliance frameworks.

    \b
    Examples:
      tailtest report                    Last run summary (terminal)
      tailtest report --trend            Trend from last 30 runs
      tailtest report --daily            Last 24 hours summary
      tailtest report --weekly           Last 7 days summary
      tailtest report --format html      Visual HTML report
      tailtest report --format html --open  Generate and open in browser
      tailtest report --format json      JSON export
      tailtest report --compliance eu-ai-act  Include compliance data
    """
    aggregator = ReportAggregator()

    # Determine which trend to compute.
    if daily:
        trend_data = aggregator.daily_summary()
    elif weekly:
        trend_data = aggregator.weekly_summary()
    elif show_trend:
        trend_data = aggregator.trend(period="trend (last 30)", last_n=30)
    else:
        trend_data = aggregator.trend(period="latest", last_n=1)

    # Load compliance data if requested.
    compliance_data = None
    if compliance:
        compliance_data = _load_compliance_data(compliance)
        if compliance_data is None:
            console.print(
                f"[yellow]  No compliance reports found for {compliance}. "
                f"Run 'tailtest redteam' first.[/yellow]"
            )

    # Generate output in the requested format.
    if fmt == "html":
        generator = HTMLReportGenerator()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = Path(output) if output else REPORTS_DIR / f"quality_report_{ts}.html"

        generator.write(
            trend_data,
            output_path,
            compliance_data=compliance_data,
        )

        console.print()
        console.print(f"[bold green]  HTML report written to:[/bold green] {output_path}")
        console.print()

        if open_browser:
            webbrowser.open(f"file://{output_path.resolve()}")

    elif fmt == "json":
        # Export trend data as JSON.
        export = {
            "period": trend_data.period,
            "total_runs": trend_data.total_runs,
            "avg_pass_rate": trend_data.avg_pass_rate,
            "avg_cost": trend_data.avg_cost,
            "flaky_tests": [
                {
                    "name": ft.name,
                    "total_runs": ft.total_runs,
                    "pass_count": ft.pass_count,
                    "fail_count": ft.fail_count,
                    "flake_rate": ft.flake_rate,
                }
                for ft in trend_data.flaky_tests
            ],
            "new_failures": trend_data.new_failures,
            "fixed_tests": trend_data.fixed_tests,
            "points": [
                {
                    "timestamp": p.timestamp.isoformat(),
                    "pass_rate": p.pass_rate,
                    "total_tests": p.total_tests,
                    "passed": p.passed,
                    "failed": p.failed,
                    "cost_usd": p.cost_usd,
                    "duration_ms": p.duration_ms,
                    "reliability_score": p.reliability_score,
                }
                for p in trend_data.points
            ],
        }

        if compliance_data:
            export["compliance"] = compliance_data

        json_str = json.dumps(export, indent=2, default=str)

        if output:
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(json_str, encoding="utf-8")
            console.print()
            console.print(f"[bold green]  JSON report written to:[/bold green] {output_path}")
            console.print()
        else:
            console.print(json_str)

    else:
        # Text / terminal output.
        _print_trend_terminal(trend_data)
