"""tailtest ingest  -  ingest traces from observability platforms."""

from __future__ import annotations

import asyncio
import signal
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from tailtest.production.ingestor import TraceIngestor

console = Console()


def _display_stats(ingestor: TraceIngestor) -> None:
    """Display ingestion statistics in a rich table."""
    stats = ingestor.stats

    table = Table(title="Ingestion Summary", show_header=True)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right", style="cyan")

    table.add_row("Traces ingested", str(stats["traces"]))
    table.add_row("Total spans", str(stats["spans"]))
    table.add_row("Responses with tool calls", str(stats["responses_with_tools"]))
    table.add_row("Responses with model info", str(stats["responses_with_model"]))

    console.print()
    console.print(table)

    # Show conversion preview
    responses = ingestor.get_agent_responses()
    if responses:
        console.print()
        console.print(f"[green]Converted {len(responses)} traces to AgentResponse objects.[/green]")
        for i, resp in enumerate(responses[:3]):
            model_str = resp.model or "unknown"
            tools_str = f"{len(resp.tool_calls)} tool(s)" if resp.tool_calls else "no tools"
            content_preview = resp.content[:80] + "..." if len(resp.content) > 80 else resp.content
            console.print(
                f"  [dim]{i + 1}. model={model_str}, {tools_str}, "
                f"latency={resp.latency_ms:.0f}ms[/dim]"
            )
            if content_preview:
                console.print(f"     [dim]{content_preview}[/dim]")
        if len(responses) > 3:
            console.print(f"  [dim]... and {len(responses) - 3} more[/dim]")


@click.command("ingest")
@click.option(
    "--otlp",
    is_flag=True,
    default=False,
    help="Start an OpenTelemetry OTLP/HTTP receiver.",
)
@click.option(
    "--otlp-port",
    type=int,
    default=4318,
    show_default=True,
    help="Port for the OTLP receiver.",
)
@click.option(
    "--langfuse-url",
    type=str,
    default=None,
    help="Langfuse instance URL to pull traces from.",
)
@click.option(
    "--langsmith",
    is_flag=True,
    default=False,
    help="Pull traces from LangSmith.",
)
@click.option(
    "--json",
    "json_file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Ingest traces from a JSON file (OTLP or simple format).",
)
@click.option(
    "--save/--no-save",
    default=True,
    show_default=True,
    help="Persist ingested traces to .tailtest/traces/.",
)
@click.option(
    "--storage-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory to store traces (default: .tailtest/traces/).",
)
def ingest_cmd(
    otlp: bool,
    otlp_port: int,
    langfuse_url: str | None,
    langsmith: bool,
    json_file: Path | None,
    save: bool,
    storage_dir: Path | None,
) -> None:
    """Ingest agent traces from observability platforms.

    Connects to OpenTelemetry, Langfuse, LangSmith, or reads from JSON
    to pull production traces and convert them into AgentResponse objects
    for assertion evaluation and regression baselines.

    \b
    Examples:
      tailtest ingest --otlp                   Start OTLP receiver on port 4318
      tailtest ingest --otlp --otlp-port 9411  Start OTLP receiver on custom port
      tailtest ingest --langfuse-url https://cloud.langfuse.com
      tailtest ingest --langsmith
      tailtest ingest --json traces.json       Ingest from a file
    """
    if not (otlp or langfuse_url or langsmith or json_file):
        console.print()
        console.print(
            "[yellow]No source specified. Use --otlp, --langfuse-url, "
            "--langsmith, or --json FILE.[/yellow]"
        )
        console.print()
        return

    ingestor = TraceIngestor(storage_dir=storage_dir)

    console.print()
    console.print("[bold]Starting trace ingestion...[/bold]")

    if otlp:
        _run_otlp(ingestor, otlp_port, save)
    elif langfuse_url:
        _run_langfuse(ingestor, langfuse_url, save)
    elif langsmith:
        _run_langsmith(ingestor, save)
    elif json_file:
        _run_json(ingestor, json_file, save)


def _run_otlp(ingestor: TraceIngestor, port: int, save: bool) -> None:
    """Start the OTLP receiver and run until Ctrl+C."""
    console.print(f"[dim]  Source: OpenTelemetry (OTLP/HTTP JSON)[/dim]")
    console.print(f"[dim]  Endpoint: http://0.0.0.0:{port}/v1/traces[/dim]")
    console.print(f"[dim]  Health: http://0.0.0.0:{port}/health[/dim]")
    console.print()
    console.print(
        "[green]Listening for traces... Press Ctrl+C to stop.[/green]"
    )

    async def _serve() -> None:
        server = await ingestor.start_otlp_receiver(port=port)
        stop_event = asyncio.Event()

        def _signal_handler() -> None:
            console.print()
            console.print("[yellow]Shutting down OTLP receiver...[/yellow]")
            stop_event.set()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _signal_handler)

        await stop_event.wait()
        await ingestor.stop_otlp_receiver()

        if save and ingestor.traces:
            out_path = ingestor.save_traces()
            console.print(f"[dim]Traces saved to {out_path}[/dim]")

        _display_stats(ingestor)

    asyncio.run(_serve())


def _run_langfuse(ingestor: TraceIngestor, url: str, save: bool) -> None:
    """Pull traces from Langfuse."""
    console.print(f"[dim]  Source: Langfuse ({url})[/dim]")
    console.print()

    async def _pull() -> None:
        try:
            count = await ingestor.ingest_from_langfuse(url=url)
            console.print(f"[green]Pulled {count} traces from Langfuse.[/green]")
        except ValueError as exc:
            console.print(f"[red]Error: {exc}[/red]")
            return
        except Exception as exc:
            console.print(f"[red]Failed to connect to Langfuse: {exc}[/red]")
            return

        if save and ingestor.traces:
            out_path = ingestor.save_traces()
            console.print(f"[dim]Traces saved to {out_path}[/dim]")

        _display_stats(ingestor)

    asyncio.run(_pull())


def _run_langsmith(ingestor: TraceIngestor, save: bool) -> None:
    """Pull traces from LangSmith."""
    console.print("[dim]  Source: LangSmith[/dim]")
    console.print()

    async def _pull() -> None:
        try:
            count = await ingestor.ingest_from_langsmith()
            console.print(f"[green]Pulled {count} traces from LangSmith.[/green]")
        except ValueError as exc:
            console.print(f"[red]Error: {exc}[/red]")
            return
        except Exception as exc:
            console.print(f"[red]Failed to connect to LangSmith: {exc}[/red]")
            return

        if save and ingestor.traces:
            out_path = ingestor.save_traces()
            console.print(f"[dim]Traces saved to {out_path}[/dim]")

        _display_stats(ingestor)

    asyncio.run(_pull())


def _run_json(ingestor: TraceIngestor, file_path: Path, save: bool) -> None:
    """Ingest traces from a JSON file."""
    console.print(f"[dim]  Source: JSON file ({file_path})[/dim]")
    console.print()

    async def _load() -> None:
        try:
            count = await ingestor.ingest_from_json(file_path)
            console.print(f"[green]Ingested {count} traces from {file_path}.[/green]")
        except Exception as exc:
            console.print(f"[red]Failed to parse {file_path}: {exc}[/red]")
            return

        if save and ingestor.traces:
            out_path = ingestor.save_traces()
            console.print(f"[dim]Traces saved to {out_path}[/dim]")

        _display_stats(ingestor)

    asyncio.run(_load())
