"""tailtest predict  -  predict which tests will break from uncommitted changes."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command("predict")
@click.option(
    "--diff-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to a diff file to analyse (instead of git diff).",
)
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project root directory.",
)
def predict_cmd(diff_file: str | None, project_dir: str) -> None:
    """Predict which tests will break from uncommitted changes.

    Analyses a git diff (or a provided diff file) against historical
    test failure data to predict which tests are most likely to fail.
    Requires Mature maturity level (50+ test runs).
    """
    project = Path(project_dir).resolve()

    # Load maturity engine
    from tailtest.maturity.engine import MaturityEngine
    from tailtest.maturity.tracker import MaturityLevel

    engine = MaturityEngine(project)

    if engine.level < MaturityLevel.MATURE:
        runs = engine.state.stats.total_runs
        console.print()
        console.print(
            f"[yellow]Prediction requires Mature level (50+ runs). "
            f"Currently at {engine.level.value} ({runs} runs).[/yellow]"
        )
        console.print("[dim]Keep running tests to unlock predictions.[/dim]")
        console.print()
        sys.exit(0)

    # Get diff
    if diff_file:
        diff = Path(diff_file).read_text(encoding="utf-8")
    else:
        diff = _get_git_diff(project)

    if not diff.strip():
        console.print()
        console.print("[dim]No uncommitted changes found.[/dim]")
        console.print()
        sys.exit(0)

    # Predict
    console.print()
    console.print("[bold]Analysing uncommitted changes...[/bold]")

    predictions = engine.predict_failures(diff)

    if not predictions:
        console.print()
        console.print("[green]No test failures predicted from these changes.[/green]")
        console.print()
        sys.exit(0)

    # Display results
    table = Table(title="Predicted Failures", show_lines=True)
    table.add_column("Risk", style="bold", width=6)
    table.add_column("Test", style="cyan")
    table.add_column("Confidence", justify="right")
    table.add_column("Reason")

    for pred in predictions:
        if pred.confidence >= 0.7:
            risk = "[red]HIGH[/red]"
        elif pred.confidence >= 0.4:
            risk = "[yellow]MED[/yellow]"
        else:
            risk = "[dim]LOW[/dim]"

        table.add_row(
            risk,
            pred.test_name,
            f"{pred.confidence:.0%}",
            pred.reason,
        )

    console.print()
    console.print(table)
    console.print()
    console.print(f"[dim]{len(predictions)} prediction(s) based on {engine.state.stats.total_runs} historical runs.[/dim]")
    console.print()


def _get_git_diff(project: Path) -> str:
    """Get the current git diff (staged + unstaged) for the project."""
    try:
        # Get both staged and unstaged changes
        result = subprocess.run(
            ["git", "diff", "HEAD"],
            capture_output=True,
            text=True,
            cwd=project,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout

        # Fallback: unstaged only
        result = subprocess.run(
            ["git", "diff"],
            capture_output=True,
            text=True,
            cwd=project,
            timeout=10,
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        console.print("[yellow]Could not run git diff. Use --diff-file instead.[/yellow]")
        return ""
