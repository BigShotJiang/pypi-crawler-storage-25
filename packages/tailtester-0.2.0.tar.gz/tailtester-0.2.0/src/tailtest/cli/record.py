"""tailtest record  -  record LLM calls for deterministic replay."""

import click
from rich.console import Console

console = Console()


@click.command("record")
def record_cmd() -> None:
    """Record LLM calls during the next test run.

    Captures all LLM requests and responses so they can be replayed
    later with 'tailtest replay', enabling fast deterministic test runs
    without live API calls.

    Recordings are saved to .tailtest/recordings/.
    """
    console.print()
    console.print("[bold]Recording mode enabled.[/bold]")
    console.print("[dim]LLM calls will be captured during the next 'tailtest run'.[/dim]")
    console.print("[dim]Recordings saved to .tailtest/recordings/[/dim]")
    console.print()

    # TODO: implement recording integration with runner
