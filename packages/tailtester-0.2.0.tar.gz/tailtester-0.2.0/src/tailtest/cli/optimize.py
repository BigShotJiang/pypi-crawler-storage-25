"""tailtest optimize  -  show test suite optimization suggestions."""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

console = Console()


@click.command("optimize")
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project root directory.",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Output suggestions as JSON.",
)
def optimize_cmd(project_dir: str, as_json: bool) -> None:
    """Show test suite optimization suggestions.

    Analyses historical test profiles to find redundant tests,
    coverage gaps, efficiency opportunities, and flaky tests.
    Requires Mature maturity level (50+ test runs).
    """
    project = Path(project_dir).resolve()

    from tailtest.maturity.engine import MaturityEngine
    from tailtest.maturity.tracker import MaturityLevel

    engine = MaturityEngine(project)

    if engine.level < MaturityLevel.MATURE:
        runs = engine.state.stats.total_runs
        console.print()
        console.print(
            f"[yellow]Optimization requires Mature level (50+ runs). "
            f"Currently at {engine.level.value} ({runs} runs).[/yellow]"
        )
        console.print("[dim]Keep running tests to unlock optimizations.[/dim]")
        console.print()
        sys.exit(0)

    # Get suggestions
    suggestions = engine.optimize_suite()

    # Also get coverage gaps
    gaps = engine.coverage_gaps()

    if as_json:
        import json as json_mod

        output = {
            "suggestions": [
                {
                    "type": s.type.value,
                    "message": s.message,
                    "tests": s.tests,
                    "impact": s.impact,
                    "details": s.details,
                }
                for s in suggestions
            ],
            "coverage_gaps": [
                {
                    "behavior": g.behavior,
                    "source": g.source,
                    "severity": g.severity,
                    "suggestion": g.suggestion,
                }
                for g in gaps
            ],
        }
        console.print(json_mod.dumps(output, indent=2))
        return

    console.print()

    if not suggestions and not gaps:
        console.print("[green]No optimization suggestions at this time.[/green]")
        console.print()
        return

    # Display optimization suggestions
    if suggestions:
        console.print("[bold]Optimization Suggestions[/bold]")
        console.print()

        type_icons = {
            "redundant": "[yellow]REDUNDANT[/yellow]",
            "upgrade": "[cyan]UPGRADE[/cyan]",
            "flaky": "[red]FLAKY[/red]",
            "missing": "[magenta]MISSING[/magenta]",
        }

        for i, s in enumerate(suggestions, 1):
            icon = type_icons.get(s.type.value, s.type.value.upper())
            console.print(f"  {i}. {icon}: {s.message}")
            if s.details:
                console.print(f"     [dim]{s.details}[/dim]")
            console.print()

    # Display coverage gaps
    if gaps:
        console.print("[bold]Coverage Gaps[/bold]")
        console.print()

        for i, g in enumerate(gaps, 1):
            severity_style = {
                "high": "[red]HIGH[/red]",
                "medium": "[yellow]MED[/yellow]",
                "low": "[dim]LOW[/dim]",
            }
            sev = severity_style.get(g.severity, g.severity.upper())
            console.print(f"  {i}. {sev}: {g.suggestion}")
            if g.related_tests:
                console.print(f"     [dim]Related tests: {', '.join(g.related_tests)}[/dim]")
            console.print()

    total = len(suggestions) + len(gaps)
    console.print(f"[dim]{total} item(s) found. Run 'tailtest suggest --apply' to generate missing tests.[/dim]")
    console.print()
