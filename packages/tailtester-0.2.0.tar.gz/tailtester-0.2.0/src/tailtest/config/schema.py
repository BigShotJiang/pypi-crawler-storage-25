"""Pydantic models for tailtest configuration."""

from __future__ import annotations

from pydantic import BaseModel, Field


class AgentConfig(BaseModel):
    """Configuration for the agent under test."""

    type: str = "http"  # http | python | cli
    url: str | None = None  # for http type
    function: str | None = None  # for python type (module:function)
    command: str | None = None  # for cli type
    request_method: str = "POST"
    request_headers: dict[str, str] = Field(default_factory=dict)
    body_template: str = '{"message": "{{input}}"}'
    response_content_path: str = "$.response"  # JSONPath
    response_tool_calls_path: str | None = None  # JSONPath for tool calls


class TestingConfig(BaseModel):
    """Configuration for test execution."""

    timeout_ms: int = 30000
    parallel: int = 1
    cost_limit: float | None = None


class JudgeConfig(BaseModel):
    """Configuration for the LLM judge."""

    model: str = "ollama/llama3.2"
    temperature: float = 0.0


class RedteamConfig(BaseModel):
    """Configuration for red-team testing."""

    intensity: str = "standard"  # quick | standard | thorough
    categories: list[str] = Field(
        default_factory=lambda: ["prompt_injection", "jailbreak", "pii_extraction"]
    )


class ProductionConfig(BaseModel):
    """Configuration for production monitoring."""

    otlp_endpoint: str | None = None
    sampling_rate: float = 0.01
    quality_threshold: float = 0.8


class ReportingConfig(BaseModel):
    """Configuration for report output."""

    formats: list[str] = Field(default_factory=lambda: ["terminal"])
    output_dir: str = ".tailtest/reports/"


class TailtestConfig(BaseModel):
    """Top-level tailtest configuration."""

    version: str = "1"
    agent: AgentConfig = Field(default_factory=AgentConfig)
    # Named targets for multi-environment testing (staging, production, etc.)
    targets: dict[str, AgentConfig] = Field(default_factory=dict)
    testing: TestingConfig = Field(default_factory=TestingConfig)
    judge: JudgeConfig = Field(default_factory=JudgeConfig)
    redteam: RedteamConfig = Field(default_factory=RedteamConfig)
    production: ProductionConfig = Field(default_factory=ProductionConfig)
    reporting: ReportingConfig = Field(default_factory=ReportingConfig)
    domain: str | None = None  # optional domain pack name (e.g. "accounting")

    def get_agent(self, target: str | None = None) -> AgentConfig:
        """Return the agent config for a specific target, or the default.

        Parameters
        ----------
        target:
            Named target from ``targets`` dict.  If *None* or the target
            does not exist, falls back to the default ``agent`` config.
        """
        if target and target in self.targets:
            return self.targets[target]
        return self.agent
