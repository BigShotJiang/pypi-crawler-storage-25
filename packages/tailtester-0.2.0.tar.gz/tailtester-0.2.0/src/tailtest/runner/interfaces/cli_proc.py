"""Agent interface that communicates via a CLI subprocess."""

from __future__ import annotations

import asyncio
import shlex
import time

from tailtest.models import AgentResponse, Message
from tailtest.runner.interfaces.base import BaseAgentInterface


class CLIInterface(BaseAgentInterface):
    """Run an agent as a subprocess, piping input through stdin.

    Parameters
    ----------
    command:
        Shell command (string) or argument list to spawn.  When given as
        a string it is parsed with :func:`shlex.split`.
    timeout:
        Maximum seconds to wait for the process to produce output and
        exit.  Defaults to 30.
    """

    def __init__(
        self,
        command: str | list[str],
        timeout: float = 30.0,
    ) -> None:
        if isinstance(command, str):
            self._args: list[str] = shlex.split(command)
        else:
            self._args = list(command)
        self.timeout = timeout
        self._process: asyncio.subprocess.Process | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(self, message: str) -> AgentResponse:
        """Spawn the command, write *message* to stdin, collect stdout."""
        start = time.perf_counter()

        try:
            process = await asyncio.create_subprocess_exec(
                *self._args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            self._process = process

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                process.communicate(input=message.encode()),
                timeout=self.timeout,
            )
            elapsed_ms = (time.perf_counter() - start) * 1000

            stdout_text = stdout_bytes.decode(errors="replace").strip()
            stderr_text = stderr_bytes.decode(errors="replace").strip()

            # Use stderr as fallback when stdout is empty (some agents
            # print responses to stderr instead of stdout)
            content = stdout_text or stderr_text

            metadata: dict[str, object] = {
                "exit_code": process.returncode,
                "stdout_length": len(stdout_text),
                "stderr_length": len(stderr_text),
            }
            if stderr_text and stdout_text:
                metadata["stderr"] = stderr_text
            if not stdout_text and stderr_text:
                metadata["source"] = "stderr"

            if process.returncode != 0:
                metadata["error"] = f"process exited with code {process.returncode}"

            return AgentResponse(
                content=content,
                latency_ms=elapsed_ms,
                metadata=metadata,
            )

        except asyncio.TimeoutError:
            elapsed_ms = (time.perf_counter() - start) * 1000
            await self._kill_process()
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "timeout",
                    "outcome": "TIMEOUT",
                    "timeout_seconds": self.timeout,
                    "detail": (
                        f"Agent did not respond within {self.timeout}s. "
                        "This may indicate an infinite tool-call loop or "
                        "LLM processing delay."
                    ),
                },
            )
        except FileNotFoundError:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "command_not_found",
                    "command": self._args,
                },
            )
        except OSError as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "os_error",
                    "detail": str(exc),
                },
            )

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        """Replay a multi-turn conversation.

        Since a subprocess is spawned fresh for each invocation, only the
        last user message is sent.
        """
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.role == "user":
                last_user_msg = msg.content
                break

        if not last_user_msg:
            return AgentResponse(content="", metadata={"error": "no user message found"})

        return await self.chat(last_user_msg)

    async def close(self) -> None:
        """Terminate any lingering subprocess."""
        await self._kill_process()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _kill_process(self) -> None:
        """Best-effort termination of the current subprocess."""
        if self._process is None:
            return
        try:
            self._process.kill()
            await self._process.wait()
        except ProcessLookupError:
            pass
        finally:
            self._process = None

    def __repr__(self) -> str:
        cmd_display = " ".join(self._args)
        return f"CLIInterface(command={cmd_display!r})"
