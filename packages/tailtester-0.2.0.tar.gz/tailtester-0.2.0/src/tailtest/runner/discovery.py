"""Test discovery  -  find and load tailtest test functions from files and directories.

Given a path (file or directory), this module locates all Python files that
look like test modules, imports them, and extracts callable test functions.
It also discovers YAML/YML test files and loads them via the YAML loader.

A function is considered a test if:
- Its name starts with ``test_``, **or**
- It has been decorated with ``@agent_test`` (identified by the
  ``_tailtest_test`` attribute).

Usage::

    from tailtest.runner.discovery import discover_tests

    tests = discover_tests("tests/")
    for test_fn in tests:
        ...
"""

from __future__ import annotations

import importlib.util
import inspect
import sys
import types
from pathlib import Path
from typing import Any, Callable


def discover_tests(path: str | Path) -> list[Callable[..., Any]]:
    """Discover all test functions under *path*.

    Parameters
    ----------
    path:
        A Python file, a YAML file, or a directory.  When a directory is
        given, it is walked recursively for files matching ``test_*.py``,
        ``*_test.py``, ``test_*.yaml``, ``test_*.yml``, ``*_test.yaml``,
        or ``*_test.yml``.

    Returns
    -------
    list[Callable]
        A list of discovered test callables, sorted by (file, line number).
    """
    target = Path(path).resolve()

    if target.is_file():
        if target.suffix in (".yaml", ".yml"):
            return _load_yaml_tests(target)
        return _extract_tests_from_file(target)

    if target.is_dir():
        test_files = _find_test_files(target)
        tests: list[Callable[..., Any]] = []
        for tf in sorted(test_files):
            if tf.suffix in (".yaml", ".yml"):
                tests.extend(_load_yaml_tests(tf))
            else:
                tests.extend(_extract_tests_from_file(tf))
        return tests

    return []


def _load_yaml_tests(file_path: Path) -> list[Callable[..., Any]]:
    """Load YAML test definitions from a file.

    Returns test callables on success, or a synthetic failing test if
    the YAML file cannot be parsed.
    """
    try:
        from tailtest.runner.yaml_loader import YAMLLoadError, load_yaml_tests

        return load_yaml_tests(file_path)
    except (YAMLLoadError, Exception) as exc:
        # Produce a synthetic failing test so the error is visible in output
        async def _yaml_load_error() -> None:
            raise ImportError(
                f"Failed to load YAML test file {file_path}: {exc}"
            ) from exc

        _yaml_load_error.__name__ = f"test_yaml_load_error_{file_path.stem}"
        _yaml_load_error.__qualname__ = _yaml_load_error.__name__
        _yaml_load_error._tailtest_source_file = str(file_path)  # type: ignore[attr-defined]
        _yaml_load_error._tailtest_line_number = 0  # type: ignore[attr-defined]
        return [_yaml_load_error]


def _find_test_files(directory: Path) -> list[Path]:
    """Recursively find Python and YAML test files in *directory*.

    A file is a test file if its name starts with ``test_`` or ends with
    ``_test.py`` / ``_test.yaml`` / ``_test.yml``.  Files and directories
    starting with ``.`` or ``_`` (except ``__``) are skipped.
    """
    test_files: list[Path] = []
    for child in sorted(directory.iterdir()):
        if child.name.startswith("."):
            continue
        if child.is_dir():
            # Skip common non-test directories.
            if child.name in {"__pycache__", "node_modules", ".git", ".venv", "venv"}:
                continue
            test_files.extend(_find_test_files(child))
        elif child.is_file():
            if child.suffix == ".py":
                if child.name.startswith("test_") or child.name.endswith("_test.py"):
                    test_files.append(child)
            elif child.suffix in (".yaml", ".yml"):
                stem = child.stem  # e.g. "test_support" from "test_support.yaml"
                if child.name.startswith("test_") or stem.endswith("_test"):
                    test_files.append(child)
    return test_files


def _load_module_from_file(file_path: Path) -> types.ModuleType:
    """Import a Python file as a module without adding it permanently to ``sys.modules``.

    This uses ``importlib.util`` so arbitrary file paths work even if
    they are not on ``sys.path``.
    """
    module_name = f"tailtest_test_{file_path.stem}_{id(file_path)}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec for {file_path}")

    module = importlib.util.module_from_spec(spec)

    # Temporarily add the file's parent to sys.path so relative imports
    # within the test file can resolve.
    parent_str = str(file_path.parent)
    added_to_path = False
    if parent_str not in sys.path:
        sys.path.insert(0, parent_str)
        added_to_path = True

    try:
        # Register the module so nested imports work.
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    finally:
        if added_to_path:
            try:
                sys.path.remove(parent_str)
            except ValueError:
                pass

    return module


def _is_test_function(name: str, obj: Any) -> bool:
    """Return ``True`` if *obj* looks like a tailtest test function."""
    if not (inspect.isfunction(obj) or inspect.iscoroutinefunction(obj)):
        return False

    # Decorated with @agent_test
    if getattr(obj, "_tailtest_test", False):
        return True

    # Naming convention: test_*
    if name.startswith("test_"):
        return True

    return False


def _extract_tests_from_file(file_path: Path) -> list[Callable[..., Any]]:
    """Load a Python file and extract all test functions.

    Returns functions sorted by their line number in the source file.
    """
    try:
        module = _load_module_from_file(file_path)
    except Exception as exc:  # noqa: BLE001
        # If a test file fails to import, produce a synthetic failing test
        # so the user sees the error in the test output rather than
        # silently skipping the file.
        async def _import_error() -> None:
            raise ImportError(
                f"Failed to import test file {file_path}: {exc}"
            ) from exc

        _import_error.__name__ = f"test_import_error_{file_path.stem}"
        _import_error.__qualname__ = _import_error.__name__
        _import_error._tailtest_source_file = str(file_path)  # type: ignore[attr-defined]
        _import_error._tailtest_line_number = 0  # type: ignore[attr-defined]
        return [_import_error]

    tests: list[Callable[..., Any]] = []
    for name, obj in inspect.getmembers(module, predicate=inspect.isfunction):
        if _is_test_function(name, obj):
            # Attach source location metadata.
            obj._tailtest_source_file = str(file_path)  # type: ignore[attr-defined]
            try:
                obj._tailtest_line_number = inspect.getsourcelines(obj)[1]  # type: ignore[attr-defined]
            except (OSError, TypeError):
                obj._tailtest_line_number = 0  # type: ignore[attr-defined]
            tests.append(obj)

    # Sort by line number for deterministic ordering.
    tests.sort(key=lambda fn: getattr(fn, "_tailtest_line_number", 0))
    return tests
