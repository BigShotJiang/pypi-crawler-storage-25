"""YAML test loader  -  parse YAML test definitions into runnable test callables.

Loads ``.yaml`` / ``.yml`` test files that define agent tests declaratively,
including assertions, multi-turn conversations, and agent connection info.

The loader automatically resolves the agent under test:
1. If the YAML file has an ``agent`` section inline, use that.
2. Otherwise, search for ``tailtest.yaml`` in the YAML file's directory and
   parent directories and load the agent config from there.

Usage::

    from tailtest.runner.yaml_loader import load_yaml_tests

    tests = load_yaml_tests(Path("tests/test_support.yaml"))
    for test_fn in tests:
        result = await test_fn()  # or hand off to the engine

See ``docs/guide/writing-tests.md`` for the YAML format spec.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

import yaml

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.deterministic import (
    ContainsAssertion,
    CostAssertion,
    LatencyAssertion,
    NoLoopAssertion,
    NotContainsAssertion,
    PIIAssertion,
    RegexAssertion,
    SchemaAssertion,
    StepCountAssertion,
    TokensUnderAssertion,
    ToolCallAssertion,
    ToolNotCalledAssertion,
)
from tailtest.config.schema import AgentConfig
from tailtest.models import AgentResponse, AssertionResult
from tailtest.runner.interfaces import create_interface
from tailtest.runner.interfaces.base import BaseAgentInterface

# ---------------------------------------------------------------------------
# Assertion type registry  -  maps YAML ``type`` strings to factory functions
# ---------------------------------------------------------------------------

_ASSERTION_FACTORIES: dict[str, Callable[..., BaseAssertion]] = {
    "contains": lambda cfg: ContainsAssertion(
        text=cfg["value"],
        case_insensitive=cfg.get("case_insensitive", False),
    ),
    "not_contains": lambda cfg: NotContainsAssertion(
        text=cfg["value"],
    ),
    "regex": lambda cfg: RegexAssertion(
        pattern=cfg["pattern"],
    ),
    "cost_under": lambda cfg: CostAssertion(
        max_cost=float(cfg["value"]),
    ),
    "latency_under": lambda cfg: LatencyAssertion(
        max_ms=int(cfg["value"]),
    ),
    "tool_called": lambda cfg: ToolCallAssertion(
        tool_name=cfg["tool"],
        expected_args=cfg.get("args"),
    ),
    "tool_not_called": lambda cfg: ToolNotCalledAssertion(
        tool_name=cfg["tool"],
    ),
    "schema": lambda cfg: _build_schema_assertion(cfg),
    "steps_under": lambda cfg: StepCountAssertion(
        max_steps=int(cfg["value"]),
    ),
    "no_loop": lambda cfg: NoLoopAssertion(
        max_repeats=int(cfg.get("max_repeats", 3)),
    ),
    "no_pii": lambda cfg: PIIAssertion(),
    "tokens_under": lambda cfg: TokensUnderAssertion(
        max_tokens=int(cfg["value"]),
    ),
}


def _build_schema_assertion(cfg: dict[str, Any]) -> SchemaAssertion:
    """Build a SchemaAssertion from a JSON schema dict in YAML.

    The YAML ``model`` field should contain a JSON-schema-style dict.
    We create a dynamic Pydantic model from it.
    """
    from pydantic import create_model

    schema = cfg.get("model", {})
    if isinstance(schema, str):
        # If someone passed a string, treat it as a JSON string
        schema = json.loads(schema)

    # Build a simple Pydantic model from the JSON schema properties
    properties = schema.get("properties", {})
    field_definitions: dict[str, Any] = {}
    required_fields = set(schema.get("required", []))

    _type_map = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
    }

    for field_name, field_spec in properties.items():
        py_type = _type_map.get(field_spec.get("type", "string"), Any)
        if field_name in required_fields:
            field_definitions[field_name] = (py_type, ...)
        else:
            field_definitions[field_name] = (py_type | None, None)

    DynamicModel = create_model("YAMLSchemaModel", **field_definitions)
    return SchemaAssertion(model=DynamicModel)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class YAMLLoadError(Exception):
    """Raised when a YAML test file cannot be loaded or is invalid."""


# ---------------------------------------------------------------------------
# Agent resolution
# ---------------------------------------------------------------------------


def _find_tailtest_yaml(start: Path) -> Path | None:
    """Walk *start* and its parents looking for ``tailtest.yaml``.

    Returns the first match, or ``None`` if none is found (stops at
    filesystem root).
    """
    current = start if start.is_dir() else start.parent
    for _ in range(50):  # safety limit
        candidate = current / "tailtest.yaml"
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _parse_agent_shorthand(agent_value: str) -> dict[str, Any]:
    """Convert shorthand agent string to a full agent config dict.

    Supports::

        agent: my_module:my_fn        ->  {"type": "python", "function": "my_module:my_fn"}
        agent: http://localhost:8000   ->  {"type": "http", "url": "http://localhost:8000"}

    Parameters
    ----------
    agent_value:
        A string that is either a ``module:function`` path or an HTTP URL.

    Returns
    -------
    dict
        Agent configuration dict suitable for ``AgentConfig.model_validate()``.
    """
    if agent_value.startswith(("http://", "https://")):
        return {"type": "http", "url": agent_value}
    # Treat as python function shorthand (module:function)
    if ":" in agent_value:
        return {"type": "python", "function": agent_value}
    # Bare module name without colon -- assume module has a default callable
    # but still needs colon format; give a clear error
    raise YAMLLoadError(
        f"Agent shorthand '{agent_value}' is not valid. "
        f"Use 'module_name:function_name' format for Python agents "
        f"or 'http://...' for HTTP agents."
    )


def _resolve_agent_interface(
    data: dict[str, Any], file_path: Path
) -> BaseAgentInterface | None:
    """Create an agent interface from either inline YAML config or tailtest.yaml.

    Resolution order:
    1. Inline ``agent:`` section in the YAML test file (dict or shorthand string).
    2. ``tailtest.yaml`` found in the same directory or parent directories.

    For Python-type agents, the module is resolved relative to the
    tailtest.yaml / YAML test file directory so that ``agent:support_agent``
    correctly finds ``agent.py`` next to the config file.

    Returns ``None`` if no agent config is found anywhere (callers should
    handle this gracefully rather than crashing).
    """
    import sys

    # 1. Inline agent config in the YAML test file
    agent_section = data.get("agent")

    # Support shorthand: agent: "my_module:my_fn"
    if isinstance(agent_section, str):
        agent_section = _parse_agent_shorthand(agent_section)

    if isinstance(agent_section, dict):
        try:
            agent_cfg = AgentConfig.model_validate(agent_section)
        except Exception as exc:
            raise YAMLLoadError(
                f"Invalid agent config in {file_path}: {exc}"
            ) from exc

        resolve_dir = str(file_path.parent)
        added = resolve_dir not in sys.path
        if added:
            sys.path.insert(0, resolve_dir)
        # Clear cached module if it exists (may be stale from another dir)
        if agent_cfg.type == "python" and agent_cfg.function:
            _invalidate_cached_module(agent_cfg.function)
        try:
            return create_interface(agent_cfg)
        finally:
            if added:
                try:
                    sys.path.remove(resolve_dir)
                except ValueError:
                    pass

    # 2. Search for tailtest.yaml
    tailtest_yaml = _find_tailtest_yaml(file_path)
    if tailtest_yaml is not None:
        from tailtest.config.loader import load_config

        config = load_config(tailtest_yaml)

        # Resolve relative paths: the agent module is relative to
        # the tailtest.yaml location, not the test file location.
        resolve_dir = str(tailtest_yaml.parent)
        added = resolve_dir not in sys.path
        if added:
            sys.path.insert(0, resolve_dir)
        # Clear cached module if it exists (may be stale from another dir)
        if config.agent.type == "python" and config.agent.function:
            _invalidate_cached_module(config.agent.function)
        try:
            return create_interface(config.agent)
        finally:
            if added:
                try:
                    sys.path.remove(resolve_dir)
                except ValueError:
                    pass

    return None


def _invalidate_cached_module(function_path: str) -> None:
    """Remove a cached module from sys.modules so it can be re-imported.

    This is necessary when the same module name (e.g. ``agent``) exists
    in multiple directories and we need to load the correct one relative
    to the current config file.
    """
    import sys

    if ":" not in function_path:
        return
    module_path = function_path.rsplit(":", 1)[0]
    if module_path in sys.modules:
        del sys.modules[module_path]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_yaml_tests(file_path: Path) -> list[Callable[..., Any]]:
    """Load a YAML test file and return a list of async test callables.

    Each callable is an ``async def`` that:

    1. Sends the test input to the agent (via the resolved agent interface).
    2. Evaluates all assertions against the agent response.
    3. Records results in the engine context so that ``TestRunner`` can
       report them.

    The agent interface is resolved from:
    - An ``agent:`` section in the YAML file, **or**
    - The ``agent:`` section in ``tailtest.yaml`` (searched from the YAML
      file's directory upward).

    Parameters
    ----------
    file_path:
        Path to a ``.yaml`` or ``.yml`` file.

    Returns
    -------
    list[Callable]
        Async test callables compatible with ``TestRunner``.

    Raises
    ------
    YAMLLoadError
        If the file is not valid YAML, is missing required fields, or
        references unknown assertion types.
    """
    file_path = Path(file_path).resolve()

    # --- Parse YAML ---
    try:
        raw_text = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise YAMLLoadError(f"Cannot read {file_path}: {exc}") from exc

    try:
        data = yaml.safe_load(raw_text)
    except yaml.YAMLError as exc:
        # Provide helpful context about the YAML parse error
        raise YAMLLoadError(
            f"Invalid YAML in {file_path}: {exc}\n"
            f"Hint: check for incorrect indentation, missing colons, "
            f"or unquoted special characters."
        ) from exc

    # Handle empty files gracefully
    if data is None:
        raise YAMLLoadError(
            f"Empty YAML file: {file_path}. "
            f"A tailtest YAML file must contain at least a 'tests' key "
            f"with a list of test definitions."
        )

    if not isinstance(data, dict):
        raise YAMLLoadError(
            f"Expected top-level mapping in {file_path}, "
            f"got {type(data).__name__}. "
            f"The file must be a YAML mapping with at least a 'tests' key."
        )

    # --- Validate required top-level fields ---
    if "tests" not in data:
        # Provide actionable guidance about what's missing
        present_keys = ", ".join(sorted(data.keys())) if data else "(none)"
        raise YAMLLoadError(
            f"Missing required 'tests' key in {file_path}. "
            f"Present keys: {present_keys}. "
            f"Add a 'tests:' list with at least one test definition."
        )

    tests_list = data["tests"]
    if tests_list is None:
        raise YAMLLoadError(
            f"'tests' key in {file_path} is empty (null). "
            f"It must be a list of test definitions."
        )

    if not isinstance(tests_list, list):
        raise YAMLLoadError(
            f"'tests' must be a list in {file_path}, got {type(tests_list).__name__}"
        )

    if len(tests_list) == 0:
        raise YAMLLoadError(
            f"'tests' list in {file_path} is empty. "
            f"Add at least one test definition."
        )

    suite_name = data.get("name", file_path.stem)

    # --- Resolve agent interface ---
    interface = _resolve_agent_interface(data, file_path)

    # If no agent found anywhere, give a clear error instead of silently
    # returning tests that cannot call the agent.
    if interface is None:
        import warnings

        warnings.warn(
            f"No agent configuration found for {file_path}. "
            f"Tests will run but cannot call the agent. "
            f"Either add an 'agent:' section to the YAML file or create "
            f"a tailtest.yaml in the project directory. "
            f"Searched parent directories up to filesystem root.",
            UserWarning,
            stacklevel=2,
        )

    # --- Load domain pack if specified ---
    domain_name = data.get("domain")
    domain_pack = None
    if domain_name is not None:
        try:
            from tailtest.intelligence.domain_packs import get_domain_pack

            domain_pack = get_domain_pack(domain_name)
        except ValueError as exc:
            raise YAMLLoadError(str(exc)) from exc

    # --- Build test callables ---
    callables: list[Callable[..., Any]] = []

    for idx, test_def in enumerate(tests_list):
        if not isinstance(test_def, dict):
            raise YAMLLoadError(
                f"Test entry {idx} in {file_path} must be a mapping, "
                f"got {type(test_def).__name__}"
            )

        test_name = test_def.get("name")
        if not test_name:
            # Show which fields ARE present to help debugging
            present = ", ".join(sorted(test_def.keys())) if test_def else "(none)"
            raise YAMLLoadError(
                f"Test entry {idx} in {file_path} is missing required 'name' field. "
                f"Present fields: {present}"
            )

        # Determine if this is a single-message or conversation test
        if "conversation" in test_def:
            fn = _build_conversation_test(
                test_def, suite_name, file_path, idx, interface
            )
        elif "input" in test_def:
            fn = _build_single_test(
                test_def, suite_name, file_path, idx, interface
            )
        else:
            raise YAMLLoadError(
                f"Test '{test_name}' in {file_path} must have either 'input' "
                f"or 'conversation' field"
            )

        callables.append(fn)

    # Attach domain pack metadata to each callable if a domain was specified
    if domain_pack is not None:
        for fn in callables:
            fn._tailtest_domain = domain_name  # type: ignore[attr-defined]
            fn._tailtest_domain_pack = domain_pack  # type: ignore[attr-defined]

    return callables


# ---------------------------------------------------------------------------
# Test callable builders
# ---------------------------------------------------------------------------


def _build_single_test(
    test_def: dict[str, Any],
    suite_name: str,
    file_path: Path,
    index: int,
    interface: BaseAgentInterface | None = None,
) -> Callable[..., Any]:
    """Build an async test callable for a single-input test."""
    test_name = test_def["name"]
    input_text = test_def["input"]
    assert_defs = test_def.get("assert", [])

    assertions = _build_assertions(assert_defs, test_name, file_path)

    async def _yaml_test() -> None:
        # Import here to avoid circular imports at module level
        from tailtest.runner.engine import _current_context

        ctx = _current_context
        if ctx is None:
            return

        # Call the agent if an interface is available
        if interface is not None:
            response = await interface.chat(input_text)
            ctx.response = response
        else:
            response = ctx.response or AgentResponse(content="")

        for assertion in assertions:
            result = await assertion.evaluate(response)
            ctx.assertion_results.append(result)

    # Attach metadata for the engine
    safe_name = _sanitize_name(test_name)
    _yaml_test.__name__ = safe_name
    _yaml_test.__qualname__ = f"{suite_name}.{safe_name}"
    _yaml_test.__doc__ = f"YAML test: {test_name}"
    _yaml_test._tailtest_test = True  # type: ignore[attr-defined]
    _yaml_test._tailtest_source_file = str(file_path)  # type: ignore[attr-defined]
    _yaml_test._tailtest_line_number = index  # type: ignore[attr-defined]
    _yaml_test._tailtest_yaml = True  # type: ignore[attr-defined]
    _yaml_test._tailtest_input = input_text  # type: ignore[attr-defined]
    _yaml_test._tailtest_assertions = assertions  # type: ignore[attr-defined]

    return _yaml_test


def _build_conversation_test(
    test_def: dict[str, Any],
    suite_name: str,
    file_path: Path,
    index: int,
    interface: BaseAgentInterface | None = None,
) -> Callable[..., Any]:
    """Build an async test callable for a multi-turn conversation test."""
    test_name = test_def["name"]
    conversation = test_def["conversation"]

    if not isinstance(conversation, list):
        raise YAMLLoadError(
            f"'conversation' in test '{test_name}' must be a list of turns"
        )

    # Pre-build assertions for each turn
    turns: list[dict[str, Any]] = []
    for turn_idx, turn in enumerate(conversation):
        if not isinstance(turn, dict):
            raise YAMLLoadError(
                f"Conversation turn {turn_idx} in test '{test_name}' "
                f"must be a mapping"
            )
        if "input" not in turn:
            raise YAMLLoadError(
                f"Conversation turn {turn_idx} in test '{test_name}' "
                f"is missing 'input'"
            )
        turn_assertions = _build_assertions(
            turn.get("assert", []), f"{test_name}[turn {turn_idx}]", file_path
        )
        turns.append({
            "input": turn["input"],
            "assertions": turn_assertions,
        })

    async def _yaml_conversation_test() -> None:
        from tailtest.runner.engine import _current_context

        ctx = _current_context
        if ctx is None:
            return

        # For each turn, call the agent (if available) and evaluate
        # assertions against the response for that turn.
        for turn in turns:
            if interface is not None:
                response = await interface.chat(turn["input"])
                ctx.response = response
            else:
                response = ctx.response or AgentResponse(content="")

            for assertion in turn["assertions"]:
                result = await assertion.evaluate(response)
                ctx.assertion_results.append(result)

    safe_name = _sanitize_name(test_name)
    _yaml_conversation_test.__name__ = safe_name
    _yaml_conversation_test.__qualname__ = f"{suite_name}.{safe_name}"
    _yaml_conversation_test.__doc__ = f"YAML conversation test: {test_name}"
    _yaml_conversation_test._tailtest_test = True  # type: ignore[attr-defined]
    _yaml_conversation_test._tailtest_source_file = str(file_path)  # type: ignore[attr-defined]
    _yaml_conversation_test._tailtest_line_number = index  # type: ignore[attr-defined]
    _yaml_conversation_test._tailtest_yaml = True  # type: ignore[attr-defined]
    _yaml_conversation_test._tailtest_conversation = turns  # type: ignore[attr-defined]

    return _yaml_conversation_test


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_assertions(
    assert_defs: list[dict[str, Any]],
    test_name: str,
    file_path: Path,
) -> list[BaseAssertion]:
    """Convert a list of YAML assertion dicts into assertion instances."""
    assertions: list[BaseAssertion] = []

    for assert_def in assert_defs:
        if not isinstance(assert_def, dict):
            raise YAMLLoadError(
                f"Assertion in test '{test_name}' must be a mapping, "
                f"got {type(assert_def).__name__}"
            )

        assert_type = assert_def.get("type")
        if not assert_type:
            raise YAMLLoadError(
                f"Assertion in test '{test_name}' is missing 'type' field"
            )

        factory = _ASSERTION_FACTORIES.get(assert_type)
        if factory is None:
            known = ", ".join(sorted(_ASSERTION_FACTORIES.keys()))
            raise YAMLLoadError(
                f"Unknown assertion type '{assert_type}' in test '{test_name}' "
                f"({file_path}). Known types: {known}"
            )

        try:
            assertion = factory(assert_def)
        except (KeyError, TypeError, ValueError) as exc:
            raise YAMLLoadError(
                f"Invalid config for assertion '{assert_type}' in test "
                f"'{test_name}' ({file_path}): {exc}"
            ) from exc

        assertions.append(assertion)

    return assertions


def _sanitize_name(name: str) -> str:
    """Convert a human-readable test name to a valid Python identifier.

    Example: ``"Order lookup"`` -> ``"test_order_lookup"``
    """
    sanitized = name.lower().replace(" ", "_").replace("-", "_")
    # Remove characters that are not alphanumeric or underscore
    sanitized = "".join(c for c in sanitized if c.isalnum() or c == "_")
    # Ensure it starts with test_
    if not sanitized.startswith("test_"):
        sanitized = f"test_{sanitized}"
    return sanitized
