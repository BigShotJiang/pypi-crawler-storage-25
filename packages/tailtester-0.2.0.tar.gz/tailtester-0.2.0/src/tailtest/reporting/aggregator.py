"""Report aggregation engine  -  loads historical JSON reports and computes trends."""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from tailtest.models import TestSuiteResult

logger = logging.getLogger(__name__)

REPORTS_DIR = Path(".tailtest/reports")


# ── Data containers ────────────────────────────────────────────────────────


@dataclass
class TrendPoint:
    """A single data point in a quality trend timeline."""

    timestamp: datetime
    pass_rate: float
    total_tests: int
    passed: int
    failed: int
    cost_usd: float
    duration_ms: float
    reliability_score: float | None = None


@dataclass
class FlakyTest:
    """A test with inconsistent pass/fail behaviour across runs."""

    name: str
    total_runs: int
    pass_count: int
    fail_count: int
    flake_rate: float  # percentage (0-100) of inconsistent results


@dataclass
class TrendReport:
    """Aggregated trend data across multiple test runs."""

    points: list[TrendPoint]
    period: str  # "daily", "weekly", "all"
    flaky_tests: list[FlakyTest]
    new_failures: list[str]  # test names that started failing
    fixed_tests: list[str]  # test names that started passing
    avg_pass_rate: float
    avg_cost: float
    total_runs: int


# ── Aggregator ─────────────────────────────────────────────────────────────


class ReportAggregator:
    """Aggregates historical test results into trend reports.

    Reads JSON reports produced by :class:`~tailtest.reporting.json_report.JSONReporter`
    from the reports directory and computes quality trends, flaky tests,
    new failures, and fixed tests.
    """

    def __init__(self, reports_dir: Path | None = None) -> None:
        self.reports_dir = reports_dir or REPORTS_DIR

    # ── Loading ────────────────────────────────────────────────────────────

    def load_all_reports(self) -> list[TestSuiteResult]:
        """Load all JSON reports from the reports directory.

        Files are sorted by filename (which encodes a timestamp) so results
        are returned in chronological order.  Malformed files are logged and
        skipped.
        """
        if not self.reports_dir.exists():
            logger.debug("Reports directory does not exist: %s", self.reports_dir)
            return []

        reports: list[TestSuiteResult] = []
        json_files = sorted(self.reports_dir.glob("report_*.json"))

        for path in json_files:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                suite = TestSuiteResult.model_validate(data)
                reports.append(suite)
            except Exception:
                logger.warning("Skipping malformed report: %s", path, exc_info=True)

        return reports

    # ── Trend computation ──────────────────────────────────────────────────

    def trend(
        self,
        period: str = "all",
        last_n: int | None = None,
        since: datetime | None = None,
    ) -> TrendReport:
        """Compute a trend report from historical data.

        Parameters
        ----------
        period:
            Label for the trend period (``"daily"``, ``"weekly"``, ``"all"``).
        last_n:
            If set, only use the most recent *last_n* reports.
        since:
            If set, only include reports whose earliest test timestamp is
            on or after *since*.
        """
        all_reports = self.load_all_reports()

        if since is not None:
            all_reports = [
                r for r in all_reports if self._suite_timestamp(r) >= since
            ]

        if last_n is not None and last_n > 0:
            all_reports = all_reports[-last_n:]

        if not all_reports:
            return TrendReport(
                points=[],
                period=period,
                flaky_tests=[],
                new_failures=[],
                fixed_tests=[],
                avg_pass_rate=0.0,
                avg_cost=0.0,
                total_runs=0,
            )

        points = self._build_trend_points(all_reports)
        flaky = self._detect_flaky(all_reports)
        new_failures = self._detect_new_failures(all_reports)
        fixed = self._detect_fixed(all_reports)

        pass_rates = [p.pass_rate for p in points]
        costs = [p.cost_usd for p in points]
        avg_pass_rate = sum(pass_rates) / len(pass_rates) if pass_rates else 0.0
        avg_cost = sum(costs) / len(costs) if costs else 0.0

        return TrendReport(
            points=points,
            period=period,
            flaky_tests=flaky,
            new_failures=new_failures,
            fixed_tests=fixed,
            avg_pass_rate=avg_pass_rate,
            avg_cost=avg_cost,
            total_runs=len(all_reports),
        )

    def daily_summary(self) -> TrendReport:
        """Summary of the last 24 hours."""
        since = datetime.now(timezone.utc) - timedelta(hours=24)
        return self.trend(period="daily", since=since)

    def weekly_summary(self) -> TrendReport:
        """Summary of the last 7 days."""
        since = datetime.now(timezone.utc) - timedelta(days=7)
        return self.trend(period="weekly", since=since)

    # ── Flaky test detection ───────────────────────────────────────────────

    def detect_flaky_tests(self, min_runs: int = 3) -> list[FlakyTest]:
        """Find tests that pass sometimes and fail sometimes.

        Only considers tests that have appeared in at least *min_runs*
        reports.  Flake rate is the percentage of runs where the test
        gave inconsistent results (i.e. it passed in some runs and failed
        in others, so ``min(pass%, fail%) * 2`` capped at 100).
        """
        all_reports = self.load_all_reports()
        return self._detect_flaky(all_reports, min_runs=min_runs)

    # ── New failure detection ──────────────────────────────────────────────

    def detect_new_failures(self, since: datetime | None = None) -> list[str]:
        """Find tests that started failing recently.

        Compares the last report (or last reports since *since*) against
        earlier history to find tests that were previously passing but are
        now failing.
        """
        all_reports = self.load_all_reports()
        if since is not None:
            recent = [
                r for r in all_reports if self._suite_timestamp(r) >= since
            ]
            earlier = [
                r for r in all_reports if self._suite_timestamp(r) < since
            ]
        elif len(all_reports) >= 2:
            recent = all_reports[-1:]
            earlier = all_reports[:-1]
        else:
            return []
        return self._compare_for_new_failures(earlier, recent)

    # ── Private helpers ────────────────────────────────────────────────────

    @staticmethod
    def _suite_timestamp(suite: TestSuiteResult) -> datetime:
        """Extract the earliest test timestamp from a suite.

        Falls back to ``datetime.min`` (UTC) if no results.
        """
        if not suite.results:
            return datetime.min.replace(tzinfo=timezone.utc)
        ts = min(r.timestamp for r in suite.results)
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return ts

    @staticmethod
    def _build_trend_points(reports: list[TestSuiteResult]) -> list[TrendPoint]:
        """Convert a list of suite results into chronological trend points."""
        points: list[TrendPoint] = []
        for suite in reports:
            ts = ReportAggregator._suite_timestamp(suite)
            pass_rate = (suite.passed / suite.total * 100.0) if suite.total > 0 else 0.0
            points.append(
                TrendPoint(
                    timestamp=ts,
                    pass_rate=pass_rate,
                    total_tests=suite.total,
                    passed=suite.passed,
                    failed=suite.failed,
                    cost_usd=suite.total_cost_usd,
                    duration_ms=suite.duration_ms,
                    reliability_score=suite.reliability_score,
                )
            )
        return points

    @staticmethod
    def _detect_flaky(
        reports: list[TestSuiteResult], min_runs: int = 3
    ) -> list[FlakyTest]:
        """Detect flaky tests across reports."""
        # test_name -> list of pass/fail booleans
        test_history: dict[str, list[bool]] = defaultdict(list)

        for suite in reports:
            for result in suite.results:
                test_history[result.test_case.name].append(result.passed)

        flaky: list[FlakyTest] = []
        for name, outcomes in test_history.items():
            if len(outcomes) < min_runs:
                continue
            pass_count = sum(outcomes)
            fail_count = len(outcomes) - pass_count

            # A test is flaky if it has both passes and failures.
            if pass_count > 0 and fail_count > 0:
                # Flake rate: how inconsistent. If always passes or always
                # fails it is 0%.  Maximum flakiness is 100% when
                # exactly half pass.
                minority = min(pass_count, fail_count)
                flake_rate = (minority / len(outcomes)) * 100.0 * 2
                flake_rate = min(flake_rate, 100.0)

                flaky.append(
                    FlakyTest(
                        name=name,
                        total_runs=len(outcomes),
                        pass_count=pass_count,
                        fail_count=fail_count,
                        flake_rate=round(flake_rate, 1),
                    )
                )

        # Sort by flake rate descending.
        flaky.sort(key=lambda f: f.flake_rate, reverse=True)
        return flaky

    @staticmethod
    def _detect_new_failures(reports: list[TestSuiteResult]) -> list[str]:
        """Find tests that started failing between the first and last reports."""
        if len(reports) < 2:
            return []
        earlier = reports[:-1]
        recent = reports[-1:]
        return ReportAggregator._compare_for_new_failures(earlier, recent)

    @staticmethod
    def _detect_fixed(reports: list[TestSuiteResult]) -> list[str]:
        """Find tests that started passing between the first and last reports."""
        if len(reports) < 2:
            return []

        # Tests that failed in earlier runs but pass in the latest.
        earlier_failed: set[str] = set()
        for suite in reports[:-1]:
            for result in suite.results:
                if not result.passed:
                    earlier_failed.add(result.test_case.name)

        latest_passed: set[str] = set()
        for result in reports[-1].results:
            if result.passed:
                latest_passed.add(result.test_case.name)

        fixed = sorted(earlier_failed & latest_passed)
        return fixed

    @staticmethod
    def _compare_for_new_failures(
        earlier: list[TestSuiteResult], recent: list[TestSuiteResult]
    ) -> list[str]:
        """Compare earlier and recent reports to find new failures."""
        # Tests that passed at any point in earlier runs.
        earlier_passed: set[str] = set()
        for suite in earlier:
            for result in suite.results:
                if result.passed:
                    earlier_passed.add(result.test_case.name)

        # Tests that fail in recent runs.
        recent_failed: set[str] = set()
        for suite in recent:
            for result in suite.results:
                if not result.passed:
                    recent_failed.add(result.test_case.name)

        new_failures = sorted(recent_failed & earlier_passed)
        return new_failures
