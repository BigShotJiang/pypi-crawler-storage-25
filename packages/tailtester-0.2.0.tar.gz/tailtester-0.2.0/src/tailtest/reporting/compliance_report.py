"""Compliance report generator  -  text, JSON, and HTML formats.

Consumes evaluated ``OWASPCheck`` lists from both the LLM and Agentic
checkers and renders them in the requested format.
"""

from __future__ import annotations

import html as html_mod
import json
from datetime import datetime, timezone
from pathlib import Path

from tailtest.redteam.compliance.owasp_llm import OWASPCheck, Severity

REPORTS_DIR = Path(".tailtest/reports")

# ── Symbols ─────────────────────────────────────────────────────────────────
SYM_PASS = "\u2713"  # tick
SYM_FAIL = "\u2717"  # cross
RULE_CHAR = "\u2501"  # ━


# ═══════════════════════════════════════════════════════════════════════════
#  Compliance Report Generator
# ═══════════════════════════════════════════════════════════════════════════


class ComplianceReporter:
    """Generate OWASP compliance reports in text, JSON, and HTML formats."""

    # ── Text report ─────────────────────────────────────────────────────────

    def text(
        self,
        llm_checks: list[OWASPCheck] | None = None,
        agent_checks: list[OWASPCheck] | None = None,
    ) -> str:
        """Produce a terminal-friendly plain-text compliance report."""
        parts: list[str] = []

        if llm_checks:
            parts.append(
                self._text_section(
                    "OWASP Top 10 for LLMs 2025", llm_checks
                )
            )

        if agent_checks:
            parts.append(
                self._text_section(
                    "OWASP Top 10 for Agentic Applications 2026", agent_checks
                )
            )

        if not parts:
            return "No compliance checks to report.\n"

        return "\n".join(parts)

    def _text_section(
        self, title: str, checks: list[OWASPCheck]
    ) -> str:
        """Render a single compliance section as text."""
        lines: list[str] = []
        rule_width = max(len(title) + 22, 52)

        lines.append("")
        lines.append(f"{title} -- Compliance Report")
        lines.append(RULE_CHAR * rule_width)
        lines.append("")

        total_tested = 0
        total_passed = 0
        critical_high_issues: list[OWASPCheck] = []

        for check in checks:
            status = self._status_label(check)
            sev = check.severity.upper().ljust(10)

            lines.append(
                f"  {check.id}  {check.name:<40s} {sev} {status}"
            )
            if check.details:
                lines.append(f"         {check.details}")

            if check.passed is not None:
                total_tested += 1
                if check.passed:
                    total_passed += 1
                elif check.severity in (Severity.CRITICAL, Severity.HIGH):
                    critical_high_issues.append(check)

        lines.append("")
        lines.append(f"  Overall: {total_passed}/{total_tested} checks passed")
        lines.append(f"  Compliance: {self._overall_verdict(total_tested, total_passed, critical_high_issues)}")
        lines.append("")
        return "\n".join(lines)

    # ── JSON report ─────────────────────────────────────────────────────────

    def json(
        self,
        llm_checks: list[OWASPCheck] | None = None,
        agent_checks: list[OWASPCheck] | None = None,
    ) -> str:
        """Produce a machine-readable JSON compliance report."""
        report: dict = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "frameworks": [],
        }

        if llm_checks:
            report["frameworks"].append(
                self._json_section(
                    "OWASP Top 10 for LLMs 2025", llm_checks
                )
            )

        if agent_checks:
            report["frameworks"].append(
                self._json_section(
                    "OWASP Top 10 for Agentic Applications 2026",
                    agent_checks,
                )
            )

        return json.dumps(report, indent=2)

    def _json_section(
        self, framework: str, checks: list[OWASPCheck]
    ) -> dict:
        """Build a JSON dict for a single compliance framework."""
        tested = [c for c in checks if c.passed is not None]
        passed = [c for c in tested if c.passed]
        critical_high = [
            c
            for c in tested
            if not c.passed
            and c.severity in (Severity.CRITICAL, Severity.HIGH)
        ]

        return {
            "framework": framework,
            "total_checks": len(checks),
            "tested": len(tested),
            "passed": len(passed),
            "failed": len(tested) - len(passed),
            "critical_high_failures": len(critical_high),
            "verdict": self._overall_verdict(
                len(tested), len(passed), critical_high
            ),
            "checks": [self._check_to_dict(c) for c in checks],
        }

    @staticmethod
    def _check_to_dict(check: OWASPCheck) -> dict:
        return {
            "id": check.id,
            "name": check.name,
            "description": check.description,
            "severity": check.severity,
            "passed": check.passed,
            "details": check.details,
            "total_attacks": check.total_attacks,
            "failed_attacks": check.failed_attacks,
            "mapped_attacks": check.attacks,
        }

    # ── HTML report ─────────────────────────────────────────────────────────

    def html(
        self,
        llm_checks: list[OWASPCheck] | None = None,
        agent_checks: list[OWASPCheck] | None = None,
    ) -> str:
        """Produce a styled HTML compliance report."""
        sections: list[str] = []

        if llm_checks:
            sections.append(
                self._html_section(
                    "OWASP Top 10 for LLMs 2025", llm_checks
                )
            )

        if agent_checks:
            sections.append(
                self._html_section(
                    "OWASP Top 10 for Agentic Applications 2026",
                    agent_checks,
                )
            )

        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        body = "\n".join(sections) if sections else "<p>No compliance checks to report.</p>"

        return f"""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OWASP Compliance Report  -  Tailtest</title>
<style>
  :root {{
    --pass: #16a34a;
    --fail: #dc2626;
    --warn: #ca8a04;
    --muted: #6b7280;
    --bg: #111827;
    --surface: #1f2937;
    --border: #374151;
    --text: #f9fafb;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: "Inter", "SF Pro", system-ui, -apple-system, sans-serif;
    background: var(--bg);
    color: var(--text);
    padding: 2rem;
    max-width: 960px;
    margin: 0 auto;
  }}
  h1 {{
    font-size: 1.5rem;
    margin-bottom: .25rem;
  }}
  .subtitle {{
    color: var(--muted);
    font-size: .85rem;
    margin-bottom: 2rem;
  }}
  .section {{ margin-bottom: 2.5rem; }}
  .section h2 {{
    font-size: 1.15rem;
    margin-bottom: 1rem;
    padding-bottom: .5rem;
    border-bottom: 1px solid var(--border);
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    font-size: .9rem;
  }}
  th {{
    text-align: left;
    padding: .6rem .8rem;
    background: var(--surface);
    border-bottom: 2px solid var(--border);
    font-weight: 600;
  }}
  td {{
    padding: .6rem .8rem;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }}
  tr:hover td {{ background: rgba(255,255,255,.03); }}
  .pass {{ color: var(--pass); font-weight: 700; }}
  .fail {{ color: var(--fail); font-weight: 700; }}
  .not-tested {{ color: var(--muted); font-style: italic; }}
  .severity-critical {{ color: var(--fail); font-weight: 700; }}
  .severity-high {{ color: #f97316; font-weight: 600; }}
  .severity-medium {{ color: var(--warn); }}
  .severity-low {{ color: var(--muted); }}
  .details {{ color: var(--muted); font-size: .82rem; }}
  .summary {{
    margin-top: 1rem;
    padding: 1rem;
    background: var(--surface);
    border-radius: .5rem;
    border: 1px solid var(--border);
  }}
  .summary strong {{ font-size: 1rem; }}
  footer {{
    margin-top: 3rem;
    color: var(--muted);
    font-size: .75rem;
    text-align: center;
  }}
</style>
</head>
<body>
<h1>OWASP Compliance Report</h1>
<p class="subtitle">Generated by Tailtest on {html_mod.escape(ts)}</p>

{body}

<footer>
  Tailtest  -  The pytest for AI agents
</footer>
</body>
</html>"""

    def _html_section(
        self, title: str, checks: list[OWASPCheck]
    ) -> str:
        """Render one compliance framework as an HTML section."""
        rows: list[str] = []
        tested = 0
        passed = 0
        critical_high: list[OWASPCheck] = []

        for check in checks:
            sev_cls = f"severity-{check.severity}"
            if check.passed is None:
                status_cls = "not-tested"
                status_text = "NOT TESTED"
            elif check.passed:
                status_cls = "pass"
                status_text = f"{SYM_PASS} PASS"
            else:
                status_cls = "fail"
                status_text = f"{SYM_FAIL} FAIL"

            detail_html = (
                f'<div class="details">{html_mod.escape(check.details)}</div>'
                if check.details
                else ""
            )

            rows.append(f"""\
      <tr>
        <td><strong>{html_mod.escape(check.id)}</strong></td>
        <td>{html_mod.escape(check.name)}{detail_html}</td>
        <td class="{sev_cls}">{html_mod.escape(check.severity.upper())}</td>
        <td class="{status_cls}">{status_text}</td>
      </tr>""")

            if check.passed is not None:
                tested += 1
                if check.passed:
                    passed += 1
                elif check.severity in (Severity.CRITICAL, Severity.HIGH):
                    critical_high.append(check)

        verdict = self._overall_verdict(tested, passed, critical_high)
        verdict_cls = "pass" if verdict.startswith("PASS") else "fail"

        return f"""\
<div class="section">
  <h2>{html_mod.escape(title)}</h2>
  <table>
    <thead>
      <tr><th>ID</th><th>Check</th><th>Severity</th><th>Status</th></tr>
    </thead>
    <tbody>
{"".join(rows)}
    </tbody>
  </table>
  <div class="summary">
    <strong>{passed}/{tested} checks passed</strong>  - 
    <span class="{verdict_cls}">{html_mod.escape(verdict)}</span>
  </div>
</div>"""

    # ── Persistence ─────────────────────────────────────────────────────────

    def write(
        self,
        fmt: str,
        llm_checks: list[OWASPCheck] | None = None,
        agent_checks: list[OWASPCheck] | None = None,
        output_path: Path | None = None,
    ) -> Path:
        """Write a compliance report to disk.

        *fmt* is one of ``"text"``, ``"json"``, or ``"html"``.
        If *output_path* is ``None``, a timestamped path under
        ``.tailtest/reports/`` is used.
        """
        ext_map = {"text": "txt", "json": "json", "html": "html"}
        ext = ext_map.get(fmt, "txt")

        if output_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = REPORTS_DIR / f"compliance_{ts}.{ext}"

        content: str
        if fmt == "json":
            content = self.json(llm_checks, agent_checks)
        elif fmt == "html":
            content = self.html(llm_checks, agent_checks)
        else:
            content = self.text(llm_checks, agent_checks)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")
        return output_path

    # ── Helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _status_label(check: OWASPCheck) -> str:
        if check.passed is None:
            return "- NOT TESTED"
        return f"{SYM_PASS} PASS" if check.passed else f"{SYM_FAIL} FAIL"

    @staticmethod
    def _overall_verdict(
        total_tested: int,
        total_passed: int,
        critical_high_issues: list[OWASPCheck],
    ) -> str:
        if total_tested == 0:
            return "NOT TESTED -- no attack results provided"
        if total_passed == total_tested:
            return "PASS -- all tested checks passed"
        if critical_high_issues:
            count = len(critical_high_issues)
            return f"PARTIAL -- {count} critical/high issues found"
        return "PARTIAL -- issues found (no critical/high severity)"
