"""Visual HTML report generator  -  self-contained dark-themed reports with SVG charts."""

from __future__ import annotations

import html as html_mod
from datetime import datetime, timezone
from pathlib import Path

from tailtest.production.failure_detector import DriftAlert
from tailtest.reporting.aggregator import FlakyTest, TrendPoint, TrendReport

# ── SVG helpers ────────────────────────────────────────────────────────────

_SVG_WIDTH = 720
_SVG_HEIGHT = 260
_SVG_MARGIN = {"top": 30, "right": 20, "bottom": 50, "left": 60}
_PLOT_W = _SVG_WIDTH - _SVG_MARGIN["left"] - _SVG_MARGIN["right"]
_PLOT_H = _SVG_HEIGHT - _SVG_MARGIN["top"] - _SVG_MARGIN["bottom"]


def _svg_line_chart(
    points: list[TrendPoint],
    value_fn,
    title: str,
    y_label: str,
    color: str = "#22c55e",
    threshold: float | None = None,
    threshold_label: str = "",
) -> str:
    """Generate an SVG line chart with axis labels and gridlines.

    Parameters
    ----------
    points:
        Ordered data points.
    value_fn:
        Callable that extracts the y-value from a TrendPoint.
    title:
        Chart title rendered above the plot.
    y_label:
        Label for the y-axis.
    color:
        Stroke colour for the line.
    threshold:
        If given, draw a horizontal dashed line at this y-value.
    threshold_label:
        Label for the threshold line.
    """
    if not points:
        return f'<p style="color:#6b7280;text-align:center;">No data for {html_mod.escape(title)}</p>'

    values = [value_fn(p) for p in points]
    y_min = 0.0
    y_max = max(values) * 1.15 if max(values) > 0 else 1.0
    if threshold is not None:
        y_max = max(y_max, threshold * 1.15)

    n = len(values)

    def x_pos(i: int) -> float:
        if n == 1:
            return _SVG_MARGIN["left"] + _PLOT_W / 2
        return _SVG_MARGIN["left"] + (i / (n - 1)) * _PLOT_W

    def y_pos(v: float) -> float:
        if y_max == y_min:
            return _SVG_MARGIN["top"] + _PLOT_H / 2
        ratio = (v - y_min) / (y_max - y_min)
        return _SVG_MARGIN["top"] + _PLOT_H - ratio * _PLOT_H

    # Build SVG
    parts: list[str] = []
    parts.append(
        f'<svg viewBox="0 0 {_SVG_WIDTH} {_SVG_HEIGHT}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f'style="width:100%;max-width:{_SVG_WIDTH}px;height:auto;">'
    )

    # Title
    parts.append(
        f'<text x="{_SVG_WIDTH / 2}" y="18" text-anchor="middle" '
        f'fill="#f9fafb" font-size="14" font-weight="600">'
        f'{html_mod.escape(title)}</text>'
    )

    # Gridlines (5 horizontal)
    for i in range(6):
        gy = _SVG_MARGIN["top"] + (_PLOT_H / 5) * i
        gval = y_max - (y_max - y_min) * (i / 5)
        parts.append(
            f'<line x1="{_SVG_MARGIN["left"]}" y1="{gy:.1f}" '
            f'x2="{_SVG_MARGIN["left"] + _PLOT_W}" y2="{gy:.1f}" '
            f'stroke="#374151" stroke-width="0.5"/>'
        )
        label = f"{gval:.1f}" if gval < 100 else f"{gval:.0f}"
        parts.append(
            f'<text x="{_SVG_MARGIN["left"] - 8}" y="{gy + 4:.1f}" '
            f'text-anchor="end" fill="#9ca3af" font-size="10">{label}</text>'
        )

    # Y-axis label
    parts.append(
        f'<text x="14" y="{_SVG_MARGIN["top"] + _PLOT_H / 2}" '
        f'text-anchor="middle" fill="#9ca3af" font-size="11" '
        f'transform="rotate(-90,14,{_SVG_MARGIN["top"] + _PLOT_H / 2})">'
        f'{html_mod.escape(y_label)}</text>'
    )

    # Threshold line
    if threshold is not None:
        ty = y_pos(threshold)
        parts.append(
            f'<line x1="{_SVG_MARGIN["left"]}" y1="{ty:.1f}" '
            f'x2="{_SVG_MARGIN["left"] + _PLOT_W}" y2="{ty:.1f}" '
            f'stroke="#eab308" stroke-width="1" stroke-dasharray="6,3"/>'
        )
        if threshold_label:
            parts.append(
                f'<text x="{_SVG_MARGIN["left"] + _PLOT_W + 4}" y="{ty + 4:.1f}" '
                f'fill="#eab308" font-size="10">{html_mod.escape(threshold_label)}</text>'
            )

    # Data line
    line_points = " ".join(f"{x_pos(i):.1f},{y_pos(v):.1f}" for i, v in enumerate(values))
    parts.append(
        f'<polyline points="{line_points}" fill="none" '
        f'stroke="{color}" stroke-width="2" stroke-linejoin="round"/>'
    )

    # Data dots
    for i, v in enumerate(values):
        cx = x_pos(i)
        cy = y_pos(v)
        parts.append(
            f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3" '
            f'fill="{color}" stroke="#111827" stroke-width="1.5"/>'
        )

    # X-axis labels (show up to 10 evenly spaced)
    max_labels = min(n, 10)
    step = max(1, n // max_labels)
    for i in range(0, n, step):
        ts = points[i].timestamp
        label = ts.strftime("%m/%d") if ts.year else str(i + 1)
        lx = x_pos(i)
        parts.append(
            f'<text x="{lx:.1f}" y="{_SVG_MARGIN["top"] + _PLOT_H + 20}" '
            f'text-anchor="middle" fill="#9ca3af" font-size="10">'
            f'{html_mod.escape(label)}</text>'
        )

    # Axes
    parts.append(
        f'<line x1="{_SVG_MARGIN["left"]}" y1="{_SVG_MARGIN["top"]}" '
        f'x2="{_SVG_MARGIN["left"]}" y2="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'stroke="#6b7280" stroke-width="1"/>'
    )
    parts.append(
        f'<line x1="{_SVG_MARGIN["left"]}" y1="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'x2="{_SVG_MARGIN["left"] + _PLOT_W}" y2="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'stroke="#6b7280" stroke-width="1"/>'
    )

    parts.append("</svg>")
    return "\n".join(parts)


def _svg_bar_chart(
    points: list[TrendPoint],
    value_fn,
    title: str,
    y_label: str,
    color: str = "#3b82f6",
) -> str:
    """Generate an SVG bar chart."""
    if not points:
        return f'<p style="color:#6b7280;text-align:center;">No data for {html_mod.escape(title)}</p>'

    values = [value_fn(p) for p in points]
    y_max = max(values) * 1.2 if max(values) > 0 else 1.0
    n = len(values)
    bar_gap = 4
    bar_width = max(4, (_PLOT_W - bar_gap * (n + 1)) / n)
    # Cap bar width at 40px
    bar_width = min(bar_width, 40)

    def y_pos(v: float) -> float:
        if y_max == 0:
            return _SVG_MARGIN["top"] + _PLOT_H
        ratio = v / y_max
        return _SVG_MARGIN["top"] + _PLOT_H - ratio * _PLOT_H

    total_bars_width = n * bar_width + (n + 1) * bar_gap
    start_x = _SVG_MARGIN["left"] + (_PLOT_W - total_bars_width) / 2

    parts: list[str] = []
    parts.append(
        f'<svg viewBox="0 0 {_SVG_WIDTH} {_SVG_HEIGHT}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f'style="width:100%;max-width:{_SVG_WIDTH}px;height:auto;">'
    )

    # Title
    parts.append(
        f'<text x="{_SVG_WIDTH / 2}" y="18" text-anchor="middle" '
        f'fill="#f9fafb" font-size="14" font-weight="600">'
        f'{html_mod.escape(title)}</text>'
    )

    # Gridlines
    for i in range(6):
        gy = _SVG_MARGIN["top"] + (_PLOT_H / 5) * i
        gval = y_max * (1 - i / 5)
        parts.append(
            f'<line x1="{_SVG_MARGIN["left"]}" y1="{gy:.1f}" '
            f'x2="{_SVG_MARGIN["left"] + _PLOT_W}" y2="{gy:.1f}" '
            f'stroke="#374151" stroke-width="0.5"/>'
        )
        label = f"${gval:.3f}" if gval < 1 else f"${gval:.2f}"
        parts.append(
            f'<text x="{_SVG_MARGIN["left"] - 8}" y="{gy + 4:.1f}" '
            f'text-anchor="end" fill="#9ca3af" font-size="10">{label}</text>'
        )

    # Y-axis label
    parts.append(
        f'<text x="14" y="{_SVG_MARGIN["top"] + _PLOT_H / 2}" '
        f'text-anchor="middle" fill="#9ca3af" font-size="11" '
        f'transform="rotate(-90,14,{_SVG_MARGIN["top"] + _PLOT_H / 2})">'
        f'{html_mod.escape(y_label)}</text>'
    )

    # Bars
    for i, v in enumerate(values):
        bx = start_x + bar_gap + i * (bar_width + bar_gap)
        by = y_pos(v)
        bh = _SVG_MARGIN["top"] + _PLOT_H - by

        # Color gradient: green for low cost, yellow/red for high cost
        ratio = v / y_max if y_max > 0 else 0
        if ratio < 0.5:
            bar_color = color
        elif ratio < 0.8:
            bar_color = "#eab308"
        else:
            bar_color = "#ef4444"

        parts.append(
            f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bar_width:.1f}" '
            f'height="{bh:.1f}" fill="{bar_color}" rx="2"/>'
        )

        # Value label on top
        val_label = f"${v:.3f}" if v < 1 else f"${v:.2f}"
        if n <= 15:
            parts.append(
                f'<text x="{bx + bar_width / 2:.1f}" y="{by - 5:.1f}" '
                f'text-anchor="middle" fill="#d1d5db" font-size="9">'
                f'{val_label}</text>'
            )

    # X-axis labels
    max_labels = min(n, 10)
    step = max(1, n // max_labels)
    for i in range(0, n, step):
        ts = points[i].timestamp
        label = ts.strftime("%m/%d") if ts.year else str(i + 1)
        lx = start_x + bar_gap + i * (bar_width + bar_gap) + bar_width / 2
        parts.append(
            f'<text x="{lx:.1f}" y="{_SVG_MARGIN["top"] + _PLOT_H + 20}" '
            f'text-anchor="middle" fill="#9ca3af" font-size="10">'
            f'{html_mod.escape(label)}</text>'
        )

    # Axes
    parts.append(
        f'<line x1="{_SVG_MARGIN["left"]}" y1="{_SVG_MARGIN["top"]}" '
        f'x2="{_SVG_MARGIN["left"]}" y2="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'stroke="#6b7280" stroke-width="1"/>'
    )
    parts.append(
        f'<line x1="{_SVG_MARGIN["left"]}" y1="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'x2="{_SVG_MARGIN["left"] + _PLOT_W}" y2="{_SVG_MARGIN["top"] + _PLOT_H}" '
        f'stroke="#6b7280" stroke-width="1"/>'
    )

    parts.append("</svg>")
    return "\n".join(parts)


# ── HTML sections ──────────────────────────────────────────────────────────


def _section_summary_cards(trend: TrendReport) -> str:
    """Render the summary cards section."""
    pass_rate_color = (
        "#22c55e" if trend.avg_pass_rate >= 90
        else "#eab308" if trend.avg_pass_rate >= 70
        else "#ef4444"
    )

    total_tests = sum(p.total_tests for p in trend.points) if trend.points else 0
    avg_cost_str = f"${trend.avg_cost:.4f}" if trend.avg_cost < 1 else f"${trend.avg_cost:.2f}"

    return f"""\
<div class="cards">
  <div class="card">
    <div class="card-value">{trend.total_runs}</div>
    <div class="card-label">Total Runs</div>
  </div>
  <div class="card">
    <div class="card-value" style="color:{pass_rate_color}">{trend.avg_pass_rate:.1f}%</div>
    <div class="card-label">Avg Pass Rate</div>
  </div>
  <div class="card">
    <div class="card-value">{avg_cost_str}</div>
    <div class="card-label">Avg Cost / Run</div>
  </div>
  <div class="card">
    <div class="card-value">{total_tests}</div>
    <div class="card-label">Total Tests</div>
  </div>
</div>"""


def _section_reliability_heatmap(trend: TrendReport) -> str:
    """Render a reliability heatmap (test x run matrix)."""
    if not trend.points:
        return ""

    # We need per-test results. Walk through the original data if
    # possible  -  but TrendReport only stores aggregate TrendPoints.
    # We would need the underlying TestSuiteResult objects.
    # Since we only have TrendReport, we can show flaky tests as a
    # proxy heatmap (most recent runs' pass/fail status is not available
    # in TrendPoint alone).  Skip if no flaky data.
    if not trend.flaky_tests:
        return ""

    rows: list[str] = []
    for ft in trend.flaky_tests[:20]:  # cap at 20 rows
        pass_pct = (ft.pass_count / ft.total_runs * 100) if ft.total_runs > 0 else 0
        bg = (
            "#166534" if pass_pct >= 90
            else "#854d0e" if pass_pct >= 50
            else "#991b1b"
        )
        rows.append(
            f'<tr>'
            f'<td style="font-family:monospace;font-size:.85rem;">{html_mod.escape(ft.name)}</td>'
            f'<td style="text-align:center;">{ft.total_runs}</td>'
            f'<td style="text-align:center;color:#22c55e;">{ft.pass_count}</td>'
            f'<td style="text-align:center;color:#ef4444;">{ft.fail_count}</td>'
            f'<td style="text-align:center;background:{bg};border-radius:4px;">'
            f'{pass_pct:.0f}%</td>'
            f'</tr>'
        )

    return f"""\
<div class="section">
  <h2>Reliability Heatmap</h2>
  <table>
    <thead>
      <tr><th>Test</th><th>Runs</th><th>Pass</th><th>Fail</th><th>Pass Rate</th></tr>
    </thead>
    <tbody>
{"".join(rows)}
    </tbody>
  </table>
</div>"""


def _section_flaky_tests(flaky: list[FlakyTest]) -> str:
    """Render the flaky tests table."""
    if not flaky:
        return ""

    rows: list[str] = []
    for ft in flaky:
        severity_color = (
            "#ef4444" if ft.flake_rate >= 50
            else "#eab308" if ft.flake_rate >= 25
            else "#f97316"
        )
        rows.append(
            f'<tr>'
            f'<td style="font-family:monospace;font-size:.85rem;">{html_mod.escape(ft.name)}</td>'
            f'<td style="text-align:center;">{ft.total_runs}</td>'
            f'<td style="text-align:center;color:#22c55e;">{ft.pass_count}</td>'
            f'<td style="text-align:center;color:#ef4444;">{ft.fail_count}</td>'
            f'<td style="text-align:center;color:{severity_color};font-weight:700;">'
            f'{ft.flake_rate:.1f}%</td>'
            f'</tr>'
        )

    return f"""\
<div class="section">
  <h2>Flaky Tests</h2>
  <p class="note">Tests with inconsistent pass/fail behaviour, sorted by flake rate.</p>
  <table>
    <thead>
      <tr><th>Test</th><th>Runs</th><th>Pass</th><th>Fail</th><th>Flake Rate</th></tr>
    </thead>
    <tbody>
{"".join(rows)}
    </tbody>
  </table>
</div>"""


def _section_new_failures(failures: list[str]) -> str:
    """Render the new failures list."""
    if not failures:
        return ""

    items = "\n".join(
        f'<li style="color:#ef4444;font-family:monospace;font-size:.9rem;">'
        f'{html_mod.escape(name)}</li>'
        for name in failures
    )
    return f"""\
<div class="section">
  <h2>New Failures</h2>
  <p class="note">Tests that were previously passing but have started failing.</p>
  <ul class="test-list">{items}</ul>
</div>"""


def _section_fixed_tests(fixed: list[str]) -> str:
    """Render the fixed tests list."""
    if not fixed:
        return ""

    items = "\n".join(
        f'<li style="color:#22c55e;font-family:monospace;font-size:.9rem;">'
        f'{html_mod.escape(name)}</li>'
        for name in fixed
    )
    return f"""\
<div class="section">
  <h2>Fixed Tests</h2>
  <p class="note">Tests that were previously failing and are now passing.</p>
  <ul class="test-list">{items}</ul>
</div>"""


def _section_compliance(compliance_data: dict) -> str:
    """Render OWASP compliance bar chart from compliance data."""
    frameworks = compliance_data.get("frameworks", [])
    if not frameworks:
        return ""

    sections: list[str] = []
    for fw in frameworks:
        name = fw.get("framework", "Unknown")
        checks = fw.get("checks", [])
        if not checks:
            continue

        rows: list[str] = []
        for check in checks:
            passed = check.get("passed")
            severity = check.get("severity", "low")

            if passed is None:
                status_cls = "not-tested"
                status_text = "NOT TESTED"
            elif passed:
                status_cls = "pass"
                status_text = "PASS"
            else:
                status_cls = "fail"
                status_text = "FAIL"

            sev_cls = f"severity-{severity}"
            rows.append(
                f'<tr>'
                f'<td><strong>{html_mod.escape(check.get("id", ""))}</strong></td>'
                f'<td>{html_mod.escape(check.get("name", ""))}</td>'
                f'<td class="{sev_cls}">{html_mod.escape(severity.upper())}</td>'
                f'<td class="{status_cls}">{status_text}</td>'
                f'</tr>'
            )

        tested = fw.get("tested", 0)
        passed_count = fw.get("passed", 0)
        verdict = fw.get("verdict", "")

        sections.append(f"""\
<div class="section">
  <h2>Compliance: {html_mod.escape(name)}</h2>
  <table>
    <thead>
      <tr><th>ID</th><th>Check</th><th>Severity</th><th>Status</th></tr>
    </thead>
    <tbody>
{"".join(rows)}
    </tbody>
  </table>
  <div class="summary-box">
    <strong>{passed_count}/{tested} checks passed</strong> &mdash; {html_mod.escape(verdict)}
  </div>
</div>""")

    return "\n".join(sections)


def _section_drift_alerts(alerts: list[DriftAlert]) -> str:
    """Render drift alert cards."""
    if not alerts:
        return ""

    cards: list[str] = []
    for alert in alerts:
        border_color = (
            "#ef4444" if alert.severity == "critical"
            else "#eab308" if alert.severity == "warning"
            else "#3b82f6"
        )
        badge_bg = (
            "#991b1b" if alert.severity == "critical"
            else "#854d0e" if alert.severity == "warning"
            else "#1e3a5f"
        )
        cards.append(f"""\
<div class="alert-card" style="border-left:4px solid {border_color};">
  <div class="alert-header">
    <span class="alert-badge" style="background:{badge_bg};">
      {html_mod.escape(alert.severity.upper())}
    </span>
    <span class="alert-metric">{html_mod.escape(alert.metric_name)}</span>
  </div>
  <p class="alert-message">{html_mod.escape(alert.message)}</p>
  <div class="alert-detail">
    Baseline: {alert.baseline_value:.4f} &rarr; Current: {alert.current_value:.4f}
  </div>
</div>""")

    return f"""\
<div class="section">
  <h2>Drift Alerts</h2>
  <div class="alerts-grid">
{"".join(cards)}
  </div>
</div>"""


# ── Main generator ─────────────────────────────────────────────────────────

_CSS = """\
:root {
  --pass: #22c55e;
  --fail: #ef4444;
  --warn: #eab308;
  --muted: #6b7280;
  --bg: #111827;
  --surface: #1f2937;
  --border: #374151;
  --text: #f9fafb;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: "Inter", "SF Pro", system-ui, -apple-system, sans-serif;
  background: var(--bg);
  color: var(--text);
  padding: 2rem;
  max-width: 1040px;
  margin: 0 auto;
}
h1 {
  font-size: 1.6rem;
  margin-bottom: .25rem;
}
.subtitle {
  color: var(--muted);
  font-size: .85rem;
  margin-bottom: 2rem;
}
.section { margin-bottom: 2.5rem; }
.section h2 {
  font-size: 1.15rem;
  margin-bottom: 1rem;
  padding-bottom: .5rem;
  border-bottom: 1px solid var(--border);
}
.note {
  color: var(--muted);
  font-size: .85rem;
  margin-bottom: 1rem;
}
/* Summary cards */
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 2.5rem;
}
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: .75rem;
  padding: 1.25rem;
  text-align: center;
}
.card-value {
  font-size: 1.75rem;
  font-weight: 700;
  line-height: 1.2;
}
.card-label {
  color: var(--muted);
  font-size: .8rem;
  margin-top: .35rem;
  text-transform: uppercase;
  letter-spacing: .05em;
}
/* Charts */
.chart-container {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: .75rem;
  padding: 1.25rem;
  margin-bottom: 1.5rem;
}
/* Tables */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: .9rem;
}
th {
  text-align: left;
  padding: .6rem .8rem;
  background: var(--surface);
  border-bottom: 2px solid var(--border);
  font-weight: 600;
}
td {
  padding: .6rem .8rem;
  border-bottom: 1px solid var(--border);
  vertical-align: top;
}
tr:hover td { background: rgba(255,255,255,.03); }
.pass { color: var(--pass); font-weight: 700; }
.fail { color: var(--fail); font-weight: 700; }
.not-tested { color: var(--muted); font-style: italic; }
.severity-critical { color: var(--fail); font-weight: 700; }
.severity-high { color: #f97316; font-weight: 600; }
.severity-medium { color: var(--warn); }
.severity-low { color: var(--muted); }
/* Test lists */
.test-list {
  list-style: none;
  padding: 0;
}
.test-list li {
  padding: .4rem .8rem;
  border-bottom: 1px solid var(--border);
}
.test-list li:last-child { border-bottom: none; }
/* Summary box */
.summary-box {
  margin-top: 1rem;
  padding: 1rem;
  background: var(--surface);
  border-radius: .5rem;
  border: 1px solid var(--border);
}
/* Alerts */
.alerts-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1rem;
}
.alert-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: .5rem;
  padding: 1rem;
}
.alert-header {
  display: flex;
  align-items: center;
  gap: .5rem;
  margin-bottom: .5rem;
}
.alert-badge {
  padding: .15rem .5rem;
  border-radius: .25rem;
  font-size: .75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .05em;
}
.alert-metric {
  font-family: monospace;
  font-size: .85rem;
  color: var(--muted);
}
.alert-message {
  font-size: .9rem;
  margin-bottom: .5rem;
}
.alert-detail {
  font-size: .8rem;
  color: var(--muted);
}
footer {
  margin-top: 3rem;
  color: var(--muted);
  font-size: .75rem;
  text-align: center;
}"""


class HTMLReportGenerator:
    """Generates a self-contained HTML report with inline CSS and SVG charts.

    No external dependencies are required  -  the report is a single HTML file
    that can be opened in any browser.
    """

    def generate(
        self,
        trend: TrendReport,
        compliance_data: dict | None = None,
        drift_alerts: list[DriftAlert] | None = None,
    ) -> str:
        """Generate a complete HTML report string.

        Parameters
        ----------
        trend:
            Aggregated trend data.
        compliance_data:
            Optional compliance report dict (as produced by
            :meth:`ComplianceReporter.json`).
        drift_alerts:
            Optional list of drift alerts to include.
        """
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        period_label = trend.period.capitalize() if trend.period else "All Time"

        sections: list[str] = []

        # Summary cards
        sections.append(_section_summary_cards(trend))

        # Quality trend chart
        sections.append('<div class="section"><h2>Quality Trend</h2>')
        sections.append('<div class="chart-container">')
        sections.append(
            _svg_line_chart(
                trend.points,
                lambda p: p.pass_rate,
                "Pass Rate Over Time",
                "Pass Rate (%)",
                color="#22c55e",
                threshold=80.0,
                threshold_label="80% threshold",
            )
        )
        sections.append("</div></div>")

        # Cost per run chart
        sections.append('<div class="section"><h2>Cost Per Run</h2>')
        sections.append('<div class="chart-container">')
        sections.append(
            _svg_bar_chart(
                trend.points,
                lambda p: p.cost_usd,
                "Cost Per Run (USD)",
                "Cost ($)",
                color="#3b82f6",
            )
        )
        sections.append("</div></div>")

        # Reliability heatmap
        sections.append(_section_reliability_heatmap(trend))

        # Flaky tests
        sections.append(_section_flaky_tests(trend.flaky_tests))

        # New failures
        sections.append(_section_new_failures(trend.new_failures))

        # Fixed tests
        sections.append(_section_fixed_tests(trend.fixed_tests))

        # Compliance
        if compliance_data:
            sections.append(_section_compliance(compliance_data))

        # Drift alerts
        if drift_alerts:
            sections.append(_section_drift_alerts(drift_alerts))

        body = "\n".join(s for s in sections if s)

        return f"""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tailtest Quality Report</title>
<style>
{_CSS}
</style>
</head>
<body>
<h1>Tailtest Quality Report</h1>
<p class="subtitle">Period: {html_mod.escape(period_label)} | Generated {html_mod.escape(ts)}</p>

{body}

<footer>
  Tailtest &mdash; The pytest for AI agents
</footer>
</body>
</html>"""

    def write(
        self,
        trend: TrendReport,
        output_path: Path,
        compliance_data: dict | None = None,
        drift_alerts: list[DriftAlert] | None = None,
    ) -> Path:
        """Write HTML report to a file.

        Returns the path the report was written to.
        """
        html_content = self.generate(
            trend,
            compliance_data=compliance_data,
            drift_alerts=drift_alerts,
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html_content, encoding="utf-8")
        return output_path
