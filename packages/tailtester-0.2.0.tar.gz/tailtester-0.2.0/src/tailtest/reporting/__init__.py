"""Tailtest reporting  -  terminal, JUnit XML, JSON, HTML, compliance, and aggregation reporters."""

from tailtest.reporting.aggregator import (
    FlakyTest,
    ReportAggregator,
    TrendPoint,
    TrendReport,
)
from tailtest.reporting.compliance_report import ComplianceReporter
from tailtest.reporting.html_report import HTMLReportGenerator
from tailtest.reporting.json_report import JSONReporter
from tailtest.reporting.junit_xml import JUnitReporter
from tailtest.reporting.sparkline import sparkline, trend_indicator
from tailtest.reporting.terminal import TerminalReporter

__all__ = [
    "ComplianceReporter",
    "FlakyTest",
    "HTMLReportGenerator",
    "JSONReporter",
    "JUnitReporter",
    "ReportAggregator",
    "TerminalReporter",
    "TrendPoint",
    "TrendReport",
    "sparkline",
    "trend_indicator",
]
