"""Unicode sparklines and trend indicators for terminal output."""

from __future__ import annotations

# Unicode block elements ordered by height (1/8 increments).
_BLOCKS = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"


def sparkline(values: list[float]) -> str:
    """Generate a Unicode sparkline string from a list of numeric values.

    Each value is mapped to one of eight block characters (plus space for
    the minimum).  An empty list returns an empty string.

    Example::

        >>> sparkline([1, 3, 5, 7, 5, 3, 1])
        '▁▃▅▇▅▃▁'
    """
    if not values:
        return ""

    lo = min(values)
    hi = max(values)
    span = hi - lo

    if span == 0:
        # All values identical  -  use mid-height block.
        return _BLOCKS[4] * len(values)

    chars: list[str] = []
    for v in values:
        # Normalize to 0..1, then map to block index 0..8.
        idx = int(((v - lo) / span) * (len(_BLOCKS) - 1))
        idx = max(0, min(len(_BLOCKS) - 1, idx))
        chars.append(_BLOCKS[idx])

    return "".join(chars)


def trend_indicator(values: list[float]) -> str:
    """Return a trend arrow based on overall direction.

    Compares the average of the last third of values against the average
    of the first third.  Returns ``"\\u2191"`` (up arrow) when increasing,
    ``"\\u2193"`` (down arrow) when decreasing, or ``"\\u2192"`` (right arrow)
    when roughly flat (< 5% relative change).

    An empty list or a list with fewer than two values returns
    ``"\\u2192"`` (flat).
    """
    if len(values) < 2:
        return "\u2192"  # →

    third = max(1, len(values) // 3)
    first_avg = sum(values[:third]) / third
    last_avg = sum(values[-third:]) / third

    if first_avg == 0:
        # Avoid division by zero  -  compare absolutes.
        if last_avg > 0:
            return "\u2191"
        if last_avg < 0:
            return "\u2193"
        return "\u2192"

    change = (last_avg - first_avg) / abs(first_avg)

    if change > 0.05:
        return "\u2191"  # ↑
    if change < -0.05:
        return "\u2193"  # ↓
    return "\u2192"  # →
