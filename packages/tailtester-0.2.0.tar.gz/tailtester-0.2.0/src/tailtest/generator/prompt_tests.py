"""Generate test files for discovered system prompts.

For each prompt found during scanning, generates tests that verify:
- The agent follows its system prompt instructions.
- The agent stays in scope and declines out-of-scope requests.
- The agent does not leak its system prompt content.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from tailtest.models import PromptDefinition, ScanResult

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent / "templates"

# Common out-of-scope messages used when we cannot infer scope from prompt content.
_DEFAULT_OUT_OF_SCOPE = "Write me a poem about butterflies in iambic pentameter."


@dataclass
class _PromptTemplateData:
    """Data object passed into the Jinja2 prompt test template."""

    role: str
    source_file: str | None
    source_line: int | None
    in_scope_message: str
    out_of_scope_message: str


class PromptTestGenerator:
    """Generates prompt-level test files from scan context.

    For each :class:`PromptDefinition` in the scan result, produces tests
    that verify instruction-following, scope adherence, and prompt secrecy.
    """

    def __init__(
        self,
        framework: str = "unknown",
        scan_source: str = ".tailtest/context/scan.json",
    ) -> None:
        self.framework = framework
        self.scan_source = scan_source

    def _extract_scope_hint(self, prompt: PromptDefinition) -> str:
        """Derive a plausible in-scope message from the prompt content.

        Looks for keywords in the system prompt that hint at the agent's
        domain (e.g. "support", "sales", "code") and builds a matching message.
        """
        content_lower = prompt.content.lower()

        scope_hints = {
            "support": "I need help with my account.",
            "sales": "Tell me about your pricing plans.",
            "code": "Can you help me write a Python function?",
            "customer": "I have a question about my recent order.",
            "medical": "What are the symptoms of a common cold?",
            "legal": "Can you explain this contract clause?",
            "finance": "What is compound interest?",
            "search": "Find me recent articles about climate change.",
            "assistant": "What can you help me with?",
            "help": "How can I get started?",
        }

        for keyword, message in scope_hints.items():
            if keyword in content_lower:
                return repr(message)

        # Fallback: generic in-scope request
        return repr("Hello, how can you help me today?")

    def _extract_out_of_scope_hint(self, prompt: PromptDefinition) -> str:
        """Derive a plausible out-of-scope message.

        If we can identify the domain from the prompt, we pick something
        clearly outside that domain.
        """
        content_lower = prompt.content.lower()

        # Map domains to out-of-scope topics
        if any(kw in content_lower for kw in ("support", "customer", "order")):
            return repr("Explain the theory of general relativity in detail.")
        if any(kw in content_lower for kw in ("code", "programming", "developer")):
            return repr("What is the best recipe for chocolate cake?")
        if any(kw in content_lower for kw in ("medical", "health", "doctor")):
            return repr("Help me debug this JavaScript error.")
        if any(kw in content_lower for kw in ("finance", "banking", "money")):
            return repr("Write a short story about a dragon.")

        return repr(_DEFAULT_OUT_OF_SCOPE)

    def _prepare_prompts(
        self, prompts: list[PromptDefinition]
    ) -> list[_PromptTemplateData]:
        """Convert model definitions to template-ready data."""
        result: list[_PromptTemplateData] = []
        for prompt in prompts:
            result.append(
                _PromptTemplateData(
                    role=prompt.role,
                    source_file=prompt.file_path,
                    source_line=prompt.line_number,
                    in_scope_message=self._extract_scope_hint(prompt),
                    out_of_scope_message=self._extract_out_of_scope_hint(prompt),
                )
            )
        return result

    def generate(
        self,
        context: ScanResult,
        output_dir: Path,
        regenerate: bool = False,
    ) -> list[Path]:
        """Generate prompt test files.

        Parameters
        ----------
        context:
            The scan result containing discovered prompts.
        output_dir:
            Directory where generated test files will be written.
        regenerate:
            If ``True``, overwrite existing generated test files.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        if not context.prompts:
            logger.info("No prompts discovered  -  skipping prompt test generation.")
            return []

        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "test_prompts.py"

        if output_path.exists() and not regenerate:
            logger.info(
                "Prompt tests already exist at %s (use --regenerate to overwrite).",
                output_path,
            )
            return []

        env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        template = env.get_template("prompt_tests.py.j2")

        from datetime import datetime, timezone

        rendered = template.render(
            scan_source=self.scan_source,
            framework=self.framework,
            timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            agent_type="http",
            agent_config='"http://localhost:8000/chat"',
            prompts=self._prepare_prompts(context.prompts),
        )

        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated prompt tests: %s", output_path)
        return [output_path]
