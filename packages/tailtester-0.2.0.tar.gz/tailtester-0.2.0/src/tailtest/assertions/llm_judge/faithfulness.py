"""Faithfulness assertion  -  checks that a response is grounded in provided context."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.llm_judge.judge import LLMJudge
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse, AssertionResult


FAITHFULNESS_RUBRIC = """\
Evaluate whether the AI assistant's response is **faithfully grounded** in the
provided context.

## Context
{context}

## Criteria
1. Every factual claim in the response MUST be directly supported by the context.
2. The response must NOT introduce information, statistics, or claims that are
   absent from the context.
3. If the response paraphrases the context, the meaning must be preserved
   accurately.
4. Minor stylistic differences (e.g., rewording for clarity) are acceptable as
   long as the meaning is not altered.

## Scoring Guide
- 1.0: Every statement is fully supported by the context.
- 0.7-0.9: Mostly grounded with minor unsupported details that do not change
  the overall meaning.
- 0.4-0.6: Some claims are supported but the response introduces notable
  unsupported information.
- 0.1-0.3: Largely ungrounded  -  most claims cannot be traced to the context.
- 0.0: Completely fabricated or contradicts the context.

Set passed=true if the score is >= 0.7, otherwise passed=false.
"""


class FaithfulnessAssertion(BaseAssertion):
    """Assert that the agent response is grounded in the given *context*.

    Example::

        assertion = FaithfulnessAssertion(context="The capital of France is Paris.")
        result = await assertion.evaluate(response)
    """

    def __init__(
        self,
        context: str,
        config: JudgeConfig | None = None,
    ) -> None:
        self.context = context
        self._judge = LLMJudge(config)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        rubric = FAITHFULNESS_RUBRIC.format(context=self.context)

        # Use the original user input if available from metadata, else empty.
        prompt = response.metadata.get("prompt", "")

        judge_result = await self._judge.evaluate(
            prompt=prompt,
            response_text=response.content,
            rubric=rubric,
            threshold=0.7,
        )

        return AssertionResult(
            passed=judge_result.passed,
            assertion_type="faithfulness",
            expected="Response grounded in provided context",
            actual=judge_result.reason,
            message=(
                f"Faithfulness check {'passed' if judge_result.passed else 'FAILED'} "
                f"(score: {judge_result.score:.2f}): {judge_result.reason}"
            ),
            score=judge_result.score,
            cost_usd=judge_result.cost_usd,
        )
