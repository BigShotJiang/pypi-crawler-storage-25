"""No-loop assertion  -  detects repeated consecutive tool calls (likely loops)."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class NoLoopAssertion(BaseAssertion):
    """Assert that no tool was called more than *max_repeats* times consecutively.

    A common failure mode for agents is getting stuck in a loop, calling the
    same tool over and over. This assertion catches that pattern.

    Example::

        # Default: no tool called 3+ times in a row
        assertion = NoLoopAssertion()

        # Custom threshold
        assertion = NoLoopAssertion(max_repeats=5)
    """

    def __init__(self, max_repeats: int = 3) -> None:
        self.max_repeats = max_repeats

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        if not response.tool_calls:
            return AssertionResult(
                passed=True,
                assertion_type="no_loop",
                expected=f"no tool called {self.max_repeats}+ times consecutively",
                actual="no tool calls",
                message="No tool calls made  -  no loop possible",
            )

        # Find the longest consecutive run of the same tool
        longest_run = 1
        longest_tool = response.tool_calls[0].name
        current_run = 1
        current_tool = response.tool_calls[0].name

        for tc in response.tool_calls[1:]:
            if tc.name == current_tool:
                current_run += 1
                if current_run > longest_run:
                    longest_run = current_run
                    longest_tool = current_tool
            else:
                current_tool = tc.name
                current_run = 1

        passed = longest_run < self.max_repeats

        return AssertionResult(
            passed=passed,
            assertion_type="no_loop",
            expected=f"no tool called {self.max_repeats}+ times consecutively",
            actual=f"'{longest_tool}' called {longest_run} time(s) consecutively",
            message=(
                f"No loop detected (longest consecutive run: "
                f"'{longest_tool}' x{longest_run})"
                if passed
                else (
                    f"Loop detected: tool '{longest_tool}' was called "
                    f"{longest_run} times consecutively "
                    f"(max allowed: {self.max_repeats - 1})"
                )
            ),
        )
