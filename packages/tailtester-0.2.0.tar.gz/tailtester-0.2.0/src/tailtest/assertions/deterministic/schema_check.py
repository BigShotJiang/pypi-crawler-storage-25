"""Schema assertion  -  checks that response content parses as JSON matching a Pydantic model."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, ValidationError

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class SchemaAssertion(BaseAssertion):
    """Assert that ``response.content`` can be parsed as JSON matching a Pydantic model.

    The assertion first attempts to parse the content as JSON, then validates
    it against the provided Pydantic model. If the content contains a JSON
    code block (```json ... ```), the assertion will extract and parse that.

    Example::

        class OrderResponse(BaseModel):
            order_id: str
            status: str
            total: float

        assertion = SchemaAssertion(model=OrderResponse)
        result = await assertion.evaluate(response)
    """

    def __init__(self, model: type[BaseModel]) -> None:
        self.model = model

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        content = response.content.strip()

        # Try to extract JSON from a code block if present
        json_str = _extract_json(content)

        # Step 1: Parse as JSON
        try:
            parsed: Any = json.loads(json_str)
        except json.JSONDecodeError as exc:
            return AssertionResult(
                passed=False,
                assertion_type="schema",
                expected=self.model.__name__,
                actual="invalid JSON",
                message=(
                    f"Expected response to be valid JSON matching {self.model.__name__}, "
                    f"but JSON parsing failed: {exc.msg} "
                    f"(at position {exc.pos})"
                ),
            )

        # Step 2: Validate against the Pydantic model
        try:
            self.model.model_validate(parsed)
        except ValidationError as exc:
            error_count = exc.error_count()
            first_errors = exc.errors()[:3]
            error_summary = "; ".join(
                f"{'.'.join(str(loc) for loc in e['loc'])}: {e['msg']}"
                for e in first_errors
            )
            return AssertionResult(
                passed=False,
                assertion_type="schema",
                expected=self.model.__name__,
                actual=parsed,
                message=(
                    f"Response is valid JSON but does not match {self.model.__name__} "
                    f"({error_count} validation error(s): {error_summary})"
                ),
            )

        return AssertionResult(
            passed=True,
            assertion_type="schema",
            expected=self.model.__name__,
            actual=parsed,
            message=f"Response matches schema {self.model.__name__}",
        )


def _extract_json(text: str) -> str:
    """Extract JSON from markdown code blocks if present, otherwise return as-is."""
    # Try ```json ... ``` block
    if "```json" in text:
        start = text.index("```json") + len("```json")
        end = text.index("```", start)
        return text[start:end].strip()

    # Try generic ``` ... ``` block
    if text.startswith("```") and text.endswith("```"):
        inner = text[3:]
        # Skip optional language identifier on first line
        first_newline = inner.find("\n")
        if first_newline != -1:
            inner = inner[first_newline + 1 :]
        if inner.endswith("```"):
            inner = inner[:-3]
        return inner.strip()

    return text
