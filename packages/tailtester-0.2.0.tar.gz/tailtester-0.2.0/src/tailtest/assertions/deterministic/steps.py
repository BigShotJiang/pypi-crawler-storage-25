"""Step-count assertion  -  checks that the agent didn't take too many steps."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class StepCountAssertion(BaseAssertion):
    """Assert that ``len(response.tool_calls)`` is below a maximum.

    This is a proxy for reasoning complexity  -  agents that take too many
    tool-call steps may be looping, confused, or inefficient.

    Example::

        assertion = StepCountAssertion(max_steps=15)
        result = await assertion.evaluate(response)
    """

    def __init__(self, max_steps: int) -> None:
        self.max_steps = max_steps

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        actual_steps = len(response.tool_calls)
        passed = actual_steps < self.max_steps

        return AssertionResult(
            passed=passed,
            assertion_type="steps_under",
            expected=self.max_steps,
            actual=actual_steps,
            message=(
                f"Agent used {actual_steps} tool call(s), under the {self.max_steps} limit"
                if passed
                else (
                    f"Agent used {actual_steps} tool call(s), "
                    f"exceeding the {self.max_steps} step limit "
                    f"(over by {actual_steps - self.max_steps})"
                )
            ),
        )
