"""Token usage assertion  -  checks that total tokens stay under a threshold."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class TokensUnderAssertion(BaseAssertion):
    """Assert that ``response.tokens_used.total_tokens`` is below a threshold.

    Example::

        assertion = TokensUnderAssertion(max_tokens=2000)
        result = await assertion.evaluate(response)
    """

    def __init__(self, max_tokens: int) -> None:
        self.max_tokens = max_tokens

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        if response.tokens_used is None:
            return AssertionResult(
                passed=False,
                assertion_type="tokens_under",
                expected=self.max_tokens,
                actual=None,
                message=(
                    f"Token usage data unavailable on response "
                    f"(expected < {self.max_tokens} tokens). "
                    "Ensure the agent adapter populates tokens_used."
                ),
            )

        actual_tokens = response.tokens_used.total_tokens
        passed = actual_tokens < self.max_tokens

        return AssertionResult(
            passed=passed,
            assertion_type="tokens_under",
            expected=self.max_tokens,
            actual=actual_tokens,
            message=(
                f"Used {actual_tokens} tokens, under the {self.max_tokens} limit"
                if passed
                else (
                    f"Used {actual_tokens} tokens, "
                    f"exceeding the {self.max_tokens} token limit "
                    f"(over by {actual_tokens - self.max_tokens})"
                )
            ),
        )
