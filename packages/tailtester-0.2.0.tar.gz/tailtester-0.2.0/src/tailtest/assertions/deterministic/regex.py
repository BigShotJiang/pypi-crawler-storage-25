"""Regex assertion  -  checks that response content matches a regex pattern."""

from __future__ import annotations

import re

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class RegexAssertion(BaseAssertion):
    r"""Assert that ``response.content`` matches a regular expression pattern.

    Uses ``re.search``  -  the pattern can match anywhere in the content.

    Example::

        assertion = RegexAssertion(pattern=r"\d{5}")
        result = await assertion.evaluate(response)
    """

    def __init__(self, pattern: str) -> None:
        self.pattern = pattern
        self._compiled = re.compile(pattern)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        match = self._compiled.search(response.content)
        passed = match is not None
        snippet = _truncate(response.content, max_len=200)

        return AssertionResult(
            passed=passed,
            assertion_type="regex_match",
            expected=self.pattern,
            actual=match.group(0) if match else snippet,
            message=(
                f"Response matches pattern /{self.pattern}/ "
                f"(matched: {match.group(0)!r})"
                if passed
                else (
                    f"Expected response to match pattern /{self.pattern}/, "
                    f"but no match found in: {snippet!r}"
                )
            ),
        )


def _truncate(text: str, max_len: int = 200) -> str:
    """Truncate text for display in assertion messages."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + "..."
