"""Tool-call assertions  -  check which tools the agent called (or didn't)."""

from __future__ import annotations

from typing import Any

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class ToolCallAssertion(BaseAssertion):
    """Assert that a specific tool was called, optionally with expected arguments.

    Example::

        # Just check that the tool was called
        assertion = ToolCallAssertion(tool_name="search")

        # Check tool was called with specific arguments
        assertion = ToolCallAssertion(tool_name="search", expected_args={"q": "test"})
    """

    def __init__(
        self, tool_name: str, expected_args: dict[str, Any] | None = None
    ) -> None:
        self.tool_name = tool_name
        self.expected_args = expected_args

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        matching_calls = [
            tc for tc in response.tool_calls if tc.name == self.tool_name
        ]

        if not matching_calls:
            called_tools = [tc.name for tc in response.tool_calls]
            return AssertionResult(
                passed=False,
                assertion_type="tool_called",
                expected=self.tool_name,
                actual=called_tools,
                message=(
                    f"Expected tool '{self.tool_name}' to be called, "
                    f"but it was not. Tools called: {called_tools or '(none)'}"
                ),
            )

        # Tool was called  -  if no argument check, we pass
        if self.expected_args is None:
            return AssertionResult(
                passed=True,
                assertion_type="tool_called",
                expected=self.tool_name,
                actual=self.tool_name,
                message=f"Tool '{self.tool_name}' was called as expected",
            )

        # Check arguments on each matching call  -  pass if ANY call matches
        for call in matching_calls:
            if _args_match(call.arguments, self.expected_args):
                return AssertionResult(
                    passed=True,
                    assertion_type="tool_called_with",
                    expected={"tool": self.tool_name, "args": self.expected_args},
                    actual={"tool": self.tool_name, "args": call.arguments},
                    message=(
                        f"Tool '{self.tool_name}' was called with expected arguments"
                    ),
                )

        # No call matched the expected arguments
        actual_args = [call.arguments for call in matching_calls]
        return AssertionResult(
            passed=False,
            assertion_type="tool_called_with",
            expected={"tool": self.tool_name, "args": self.expected_args},
            actual={"tool": self.tool_name, "args": actual_args},
            message=(
                f"Tool '{self.tool_name}' was called but not with expected arguments. "
                f"Expected args to include {self.expected_args}, "
                f"got: {actual_args}"
            ),
        )


class ToolNotCalledAssertion(BaseAssertion):
    """Assert that a specific tool was NOT called.

    Example::

        assertion = ToolNotCalledAssertion(tool_name="delete_user")
        result = await assertion.evaluate(response)
    """

    def __init__(self, tool_name: str) -> None:
        self.tool_name = tool_name

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        matching_calls = [
            tc for tc in response.tool_calls if tc.name == self.tool_name
        ]

        if matching_calls:
            call_count = len(matching_calls)
            return AssertionResult(
                passed=False,
                assertion_type="tool_not_called",
                expected=f"'{self.tool_name}' not called",
                actual=f"'{self.tool_name}' called {call_count} time(s)",
                message=(
                    f"Expected tool '{self.tool_name}' NOT to be called, "
                    f"but it was called {call_count} time(s)"
                ),
            )

        return AssertionResult(
            passed=True,
            assertion_type="tool_not_called",
            expected=f"'{self.tool_name}' not called",
            actual=f"'{self.tool_name}' not called",
            message=f"Tool '{self.tool_name}' was not called, as expected",
        )


def _args_match(
    actual: dict[str, Any], expected: dict[str, Any]
) -> bool:
    """Check that all expected key-value pairs exist in actual arguments.

    This is a *subset* match: the actual arguments may contain extra keys
    beyond what is specified in ``expected``.
    """
    for key, value in expected.items():
        if key not in actual:
            return False
        if actual[key] != value:
            return False
    return True
