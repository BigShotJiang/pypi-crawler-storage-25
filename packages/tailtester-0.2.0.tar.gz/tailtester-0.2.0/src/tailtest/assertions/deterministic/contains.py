"""Contains / not-contains assertions  -  check text presence in response content."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class ContainsAssertion(BaseAssertion):
    """Assert that ``response.content`` contains the given text.

    Example::

        assertion = ContainsAssertion(text="order #", case_insensitive=True)
        result = await assertion.evaluate(response)
    """

    def __init__(self, text: str, case_insensitive: bool = False) -> None:
        self.text = text
        self.case_insensitive = case_insensitive

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        content = response.content
        search_text = self.text

        if self.case_insensitive:
            content = content.lower()
            search_text = search_text.lower()

        passed = search_text in content
        # Show a truncated snippet of the content for context
        snippet = _truncate(response.content, max_len=200)

        return AssertionResult(
            passed=passed,
            assertion_type="contains",
            expected=self.text,
            actual=snippet,
            message=(
                f"Response contains '{self.text}'"
                if passed
                else (
                    f"Expected response to contain '{self.text}'"
                    f"{' (case-insensitive)' if self.case_insensitive else ''}, "
                    f"but it was not found in: {snippet!r}"
                )
            ),
        )


class NotContainsAssertion(BaseAssertion):
    """Assert that ``response.content`` does NOT contain the given text.

    Example::

        assertion = NotContainsAssertion(text="sk_test_")
        result = await assertion.evaluate(response)
    """

    def __init__(self, text: str, case_insensitive: bool = False) -> None:
        self.text = text
        self.case_insensitive = case_insensitive

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        content = response.content
        search_text = self.text

        if self.case_insensitive:
            content = content.lower()
            search_text = search_text.lower()

        found = search_text in content
        passed = not found
        snippet = _truncate(response.content, max_len=200)

        return AssertionResult(
            passed=passed,
            assertion_type="not_contains",
            expected=f"NOT '{self.text}'",
            actual=snippet,
            message=(
                f"Response does not contain '{self.text}', as expected"
                if passed
                else (
                    f"Expected response NOT to contain '{self.text}'"
                    f"{' (case-insensitive)' if self.case_insensitive else ''}, "
                    f"but it was found in: {snippet!r}"
                )
            ),
        )


def _truncate(text: str, max_len: int = 200) -> str:
    """Truncate text for display in assertion messages."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + "..."
