"""Latency assertion  -  checks that response time stays under a threshold."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class LatencyAssertion(BaseAssertion):
    """Assert that ``response.latency_ms`` is below a maximum threshold.

    Example::

        assertion = LatencyAssertion(max_ms=3000)
        result = await assertion.evaluate(response)
    """

    def __init__(self, max_ms: int) -> None:
        self.max_ms = max_ms

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        actual_ms = response.latency_ms

        if actual_ms is None:
            return AssertionResult(
                passed=False,
                assertion_type="latency_under",
                expected=self.max_ms,
                actual=None,
                message=(
                    f"Latency data unavailable on response (expected < {self.max_ms}ms). "
                    "Ensure the agent adapter populates latency_ms."
                ),
            )

        passed = actual_ms < self.max_ms
        return AssertionResult(
            passed=passed,
            assertion_type="latency_under",
            expected=self.max_ms,
            actual=actual_ms,
            message=(
                f"Latency {actual_ms:.0f}ms is under {self.max_ms}ms threshold"
                if passed
                else (
                    f"Latency {actual_ms:.0f}ms exceeds {self.max_ms}ms threshold "
                    f"(over by {actual_ms - self.max_ms:.0f}ms)"
                )
            ),
        )
