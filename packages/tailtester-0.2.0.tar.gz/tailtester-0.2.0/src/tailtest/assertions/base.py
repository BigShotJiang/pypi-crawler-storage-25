"""Base assertion interface  -  all assertions inherit from this."""

from __future__ import annotations

from abc import ABC, abstractmethod

from tailtest.models import AgentResponse, AssertionResult


class BaseAssertion(ABC):
    """Abstract base class for all tailtest assertions.

    Subclasses implement ``evaluate`` to inspect an ``AgentResponse`` and
    return a deterministic ``AssertionResult`` (pass/fail with message).
    """

    @abstractmethod
    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Evaluate this assertion against the agent response."""
        ...
