"""Tailtest  -  The pytest for AI agents."""

__version__ = "0.2.0"

from tailtest.assertions.expect import Expectation, expect  # noqa: F401
from tailtest.decorators import Agent, agent_test  # noqa: F401

__all__ = [
    "Agent",
    "Expectation",
    "agent_test",
    "expect",
]
