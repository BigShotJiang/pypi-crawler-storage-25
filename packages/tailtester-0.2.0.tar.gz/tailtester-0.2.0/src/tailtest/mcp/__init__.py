"""MCP server  -  Model Context Protocol integration for tailtest.

Exposes tailtest capabilities (scan, generate, run, safety check) to
MCP-compatible IDEs such as Cursor, Claude Code, and others.

Start the server::

    tailtest mcp-serve
"""

from tailtest.mcp.server import TailtestMCPServer, main

__all__ = ["TailtestMCPServer", "main"]
