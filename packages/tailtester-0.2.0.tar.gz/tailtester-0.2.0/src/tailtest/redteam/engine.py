"""Red-team orchestrator  -  runs adversarial attacks against an AI agent."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from tailtest.models import AgentResponse, Message
from tailtest.redteam.attacks import Attack, AttackCategory, Severity, get_all_attacks
from tailtest.redteam.compliance.owasp_llm import AttackResult
from tailtest.runner.interfaces.base import BaseAgentInterface


@dataclass
class RedTeamReport:
    """Aggregate report from a full red-team run."""

    total_attacks: int
    passed: int  # Agent resisted
    failed: int  # Agent was vulnerable
    results: list[AttackResult]
    compliance: dict[str, bool]  # OWASP LLM Top 10 checks
    duration_ms: float = 0.0
    categories_tested: list[str] = field(default_factory=list)

    @property
    def pass_rate(self) -> float:
        return self.passed / self.total_attacks if self.total_attacks > 0 else 0.0

    @property
    def critical_failures(self) -> list[AttackResult]:
        return [r for r in self.results if not r.passed and r.severity == "critical"]

    @property
    def high_failures(self) -> list[AttackResult]:
        return [r for r in self.results if not r.passed and r.severity == "high"]


# OWASP LLM Top 10 (2025) mapping
OWASP_LLM_TOP_10 = {
    "LLM01": "Prompt Injection",
    "LLM02": "Insecure Output Handling",
    "LLM03": "Training Data Poisoning",
    "LLM04": "Model Denial of Service",
    "LLM05": "Supply Chain Vulnerabilities",
    "LLM06": "Sensitive Information Disclosure",
    "LLM07": "Insecure Plugin Design",
    "LLM08": "Excessive Agency",
    "LLM09": "Overreliance",
    "LLM10": "Model Theft",
}

# Map attack categories to OWASP IDs
CATEGORY_OWASP_MAP: dict[str, str] = {
    AttackCategory.PROMPT_INJECTION.value: "LLM01",
    AttackCategory.JAILBREAK.value: "LLM01",
    AttackCategory.PII_EXTRACTION.value: "LLM06",
    AttackCategory.DATA_LEAKAGE.value: "LLM06",
    AttackCategory.TOOL_MISUSE.value: "LLM08",
    AttackCategory.HALLUCINATION.value: "LLM09",
    AttackCategory.SCOPE_VIOLATION.value: "LLM09",
    AttackCategory.DOS.value: "LLM04",
}


class RedTeamEngine:
    """Orchestrates adversarial red-team testing against AI agents.

    Usage::

        engine = RedTeamEngine(intensity="standard")
        async with my_agent_interface as agent:
            report = await engine.run(agent)
    """

    def __init__(self, intensity: str = "standard"):
        if intensity not in ("quick", "standard", "thorough"):
            raise ValueError(
                f"Invalid intensity: {intensity!r}. Use quick, standard, or thorough."
            )
        self.intensity = intensity
        self.attacks: list[Attack] = []

    def load_attacks(
        self, categories: list[str] | None = None
    ) -> list[Attack]:
        """Load attacks from the built-in attack library."""
        return get_all_attacks(
            categories=categories, intensity=self.intensity
        )

    async def _execute_single_turn(
        self, agent: BaseAgentInterface, attack: Attack
    ) -> AttackResult:
        """Execute a single-turn attack and check the result."""
        prompt = attack.prompt
        start = time.perf_counter()
        try:
            response = await agent.chat(prompt)
            duration_ms = (time.perf_counter() - start) * 1000
            passed = attack.check_fn(response)
            return AttackResult(
                attack_name=attack.name,
                category=attack.category.value,
                passed=passed,
                severity=attack.severity.value,
                details=(
                    "Agent resisted the attack."
                    if passed
                    else "Agent may be vulnerable."
                ),
                tags=[attack.owasp_id] if attack.owasp_id else [],
            )
        except Exception as exc:
            return AttackResult(
                attack_name=attack.name,
                category=attack.category.value,
                passed=True,  # Errors count as resisted
                severity=attack.severity.value,
                details=f"Agent raised an error: {exc}",
                tags=[attack.owasp_id] if attack.owasp_id else [],
            )

    async def _execute_multi_turn(
        self, agent: BaseAgentInterface, attack: Attack
    ) -> AttackResult:
        """Execute a multi-turn attack sequence."""
        prompts = attack.multi_turn_prompts
        start = time.perf_counter()
        try:
            messages = [Message(role="user", content=p) for p in prompts]
            response = await agent.conversation(messages)
            duration_ms = (time.perf_counter() - start) * 1000
            passed = attack.check_fn(response)
            return AttackResult(
                attack_name=attack.name,
                category=attack.category.value,
                passed=passed,
                severity=attack.severity.value,
                details=(
                    "Agent resisted the multi-turn attack."
                    if passed
                    else "Agent may be vulnerable to multi-turn escalation."
                ),
                tags=[attack.owasp_id] if attack.owasp_id else [],
            )
        except Exception as exc:
            return AttackResult(
                attack_name=attack.name,
                category=attack.category.value,
                passed=True,
                severity=attack.severity.value,
                details=f"Agent raised an error during multi-turn attack: {exc}",
                tags=[attack.owasp_id] if attack.owasp_id else [],
            )

    async def _execute_attack(
        self, agent: BaseAgentInterface, attack: Attack
    ) -> AttackResult:
        """Execute a single attack (dispatches to single or multi-turn)."""
        if attack.multi_turn_prompts:
            return await self._execute_multi_turn(agent, attack)
        return await self._execute_single_turn(agent, attack)

    def _build_compliance(
        self, results: list[AttackResult]
    ) -> dict[str, bool]:
        """Build OWASP LLM Top 10 compliance map from results."""
        compliance: dict[str, bool] = {}
        for owasp_id, name in OWASP_LLM_TOP_10.items():
            # Match by tag or by category->OWASP mapping
            relevant = [
                r
                for r in results
                if owasp_id in r.tags
                or CATEGORY_OWASP_MAP.get(r.category) == owasp_id
            ]
            if relevant:
                compliance[f"{owasp_id}: {name}"] = all(
                    r.passed for r in relevant
                )
            else:
                compliance[f"{owasp_id}: {name}"] = True  # Not tested
        return compliance

    async def run(
        self,
        agent: BaseAgentInterface,
        categories: list[str] | None = None,
        on_progress: Callable[[AttackResult, int, int], None] | None = None,
    ) -> RedTeamReport:
        """Execute the full red-team suite against an agent.

        Args:
            agent: The agent interface to attack.
            categories: Optional filter for attack categories.
            on_progress: Optional callback(result, current, total).

        Returns:
            A RedTeamReport with all results and OWASP compliance.
        """
        self.attacks = self.load_attacks(categories)
        total = len(self.attacks)
        results: list[AttackResult] = []
        start = time.perf_counter()

        for idx, attack in enumerate(self.attacks):
            result = await self._execute_attack(agent, attack)
            results.append(result)
            if on_progress is not None:
                on_progress(result, idx + 1, total)

        duration_ms = (time.perf_counter() - start) * 1000
        passed = sum(1 for r in results if r.passed)
        failed = total - passed
        tested_categories = sorted(set(r.category for r in results))

        return RedTeamReport(
            total_attacks=total,
            passed=passed,
            failed=failed,
            results=results,
            compliance=self._build_compliance(results),
            duration_ms=duration_ms,
            categories_tested=tested_categories,
        )
