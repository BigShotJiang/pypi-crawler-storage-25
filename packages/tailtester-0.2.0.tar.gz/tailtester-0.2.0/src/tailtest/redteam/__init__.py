"""tailtest.redteam  -  Red-team engine for adversarial AI agent testing.

Provides 50+ attack patterns across 8 categories:
- prompt_injection: direct/indirect instruction override
- jailbreak: safety guardrail bypass via social engineering
- pii_extraction: personal data exfiltration attempts
- data_leakage: system prompt, config, and API key extraction
- tool_misuse: unauthorized actions, injection, privilege escalation
- hallucination: fabrication, false confidence, source invention
- scope_violation: out-of-domain questions, opinions, predictions
- dos: token exhaustion, infinite loops, recursive expansion
"""

from tailtest.redteam.engine import RedTeamEngine, RedTeamReport

__all__ = [
    "RedTeamEngine",
    "RedTeamReport",
]
