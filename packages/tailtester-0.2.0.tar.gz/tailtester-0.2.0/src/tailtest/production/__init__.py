"""Production loop  -  trace ingestion, guard proxy, drift detection, and failure analysis."""

from tailtest.production.drift_detector import DriftDetector
from tailtest.production.failure_classifier import (
    ClassifiedFailure,
    FailureClassifier,
    FailureType,
)
from tailtest.production.failure_detector import (
    DriftAlert,
    FailureDetector,
    QualityMetrics,
)
from tailtest.production.guard import GuardMetrics, GuardProxy
from tailtest.production.ingestor import AgentTrace, TraceIngestor, TraceSpan
from tailtest.production.regression_builder import RegressionBuilder

__all__ = [
    "AgentTrace",
    "ClassifiedFailure",
    "DriftAlert",
    "DriftDetector",
    "FailureClassifier",
    "FailureDetector",
    "FailureType",
    "GuardMetrics",
    "GuardProxy",
    "QualityMetrics",
    "RegressionBuilder",
    "TraceIngestor",
    "TraceSpan",
]
