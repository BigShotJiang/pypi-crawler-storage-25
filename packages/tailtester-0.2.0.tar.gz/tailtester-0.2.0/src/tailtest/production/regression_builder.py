"""Regression builder  -  auto-generates regression test cases from classified failures.

Converts :class:`ClassifiedFailure` instances into YAML test case files that
can be picked up by the tailtest runner on the next CI run, closing the
production-to-test feedback loop.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml

from tailtest.production.failure_classifier import ClassifiedFailure, FailureType

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Assertion templates per failure type
# ---------------------------------------------------------------------------

_ASSERTION_MAP: dict[FailureType, list[str]] = {
    FailureType.HALLUCINATION: [
        "faithful_to()",
    ],
    FailureType.TOOL_ERROR: [
        "not_empty()",
    ],
    FailureType.TOOL_WRONG_ARGS: [],
    FailureType.SAFETY_VIOLATION: [
        "safe()",
    ],
    FailureType.SCOPE_VIOLATION: [
        "safe()",
    ],
    FailureType.PII_LEAK: [
        "no_pii()",
    ],
    FailureType.COST_OVERRUN: [],  # filled dynamically
    FailureType.LATENCY_SPIKE: [],  # filled dynamically
    FailureType.CONTEXT_LOSS: [
        "faithful_to()",
    ],
    FailureType.LOOP_DETECTED: [
        "no_loop()",
    ],
    FailureType.UNKNOWN: [
        "not_empty()",
    ],
}


def _slugify(text: str, max_len: int = 50) -> str:
    """Convert text to a filename-safe slug."""
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len]


class RegressionBuilder:
    """Converts classified failures into regression test cases.

    Generated test files are written to ``output_dir`` (default:
    ``.tailtest/tests/auto/regression/``) as YAML files compatible with
    ``tailtest run``.

    Usage::

        builder = RegressionBuilder()
        path = await builder.build_from_failure(failure, user_input="Book a flight")
    """

    def __init__(self, output_dir: Path | None = None) -> None:
        self.output_dir = output_dir or Path(".tailtest/tests/auto/regression")

    # ------------------------------------------------------------------ #
    # Single failure
    # ------------------------------------------------------------------ #

    async def build_from_failure(
        self,
        failure: ClassifiedFailure,
        user_input: str,
    ) -> Path:
        """Generate a regression test from a classified failure.

        Parameters
        ----------
        failure:
            The classified failure to convert into a test case.
        user_input:
            The original user input that triggered the failure.

        Returns
        -------
        Path
            Path to the generated YAML test file.
        """
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Build assertion list
        assertions = list(_ASSERTION_MAP.get(failure.failure_type, []))

        # Dynamic assertions for thresholds
        if failure.failure_type == FailureType.COST_OVERRUN:
            cost = failure.response.cost_usd
            if cost is not None:
                # Set threshold at 80% of the offending cost to catch regressions
                threshold = round(cost * 0.8, 4)
                assertions.append(f"cost_under({threshold})")
            else:
                assertions.append("cost_under(1.0)")

        if failure.failure_type == FailureType.LATENCY_SPIKE:
            latency = failure.response.latency_ms
            if latency is not None:
                threshold = int(latency * 0.8)
                assertions.append(f"latency_under({threshold})")
            else:
                assertions.append("latency_under(10000)")

        # If we have tool calls that failed, add tool-specific assertions
        if failure.failure_type == FailureType.TOOL_ERROR and failure.response.tool_calls:
            tool_name = failure.response.tool_calls[0].name
            assertions.append(f"to_call_tool({tool_name})")

        if failure.failure_type == FailureType.TOOL_WRONG_ARGS and failure.response.tool_calls:
            tool_name = failure.response.tool_calls[0].name
            assertions.append(f"to_call_tool({tool_name})")

        # Ensure at least one assertion
        if not assertions:
            assertions.append("not_empty()")

        # Build test case name
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        name = f"regression_{failure.failure_type.value}_{ts}"

        test_case = {
            "name": name,
            "description": (
                f"Auto-generated regression test for {failure.failure_type.value} failure. "
                f"Evidence: {failure.evidence[:200]}"
            ),
            "input": user_input,
            "assertions": assertions,
            "tags": ["regression", "auto-generated", failure.failure_type.value],
        }

        # Write YAML file
        filename = f"{_slugify(name)}.yaml"
        path = self.output_dir / filename
        path.write_text(
            yaml.dump(
                {"tests": [test_case]},
                default_flow_style=False,
                sort_keys=False,
                allow_unicode=True,
            )
        )

        logger.info(
            "Generated regression test: %s (type=%s)",
            path,
            failure.failure_type.value,
        )
        return path

    # ------------------------------------------------------------------ #
    # Batch
    # ------------------------------------------------------------------ #

    async def build_from_batch(
        self,
        failures: list[tuple[ClassifiedFailure, str]],
    ) -> list[Path]:
        """Generate regression tests from a batch of failures.

        Parameters
        ----------
        failures:
            List of ``(ClassifiedFailure, user_input)`` tuples.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        paths: list[Path] = []
        for failure, user_input in failures:
            path = await self.build_from_failure(failure, user_input)
            paths.append(path)

        if paths:
            logger.info(
                "Generated %d regression test(s) in %s", len(paths), self.output_dir
            )
        return paths
