"""Failure detector  -  detects quality degradation in agent responses.

Computes quality metrics from batches of ``AgentResponse`` objects and
compares them against a stored baseline to surface drift alerts.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from tailtest.assertions.deterministic.no_loop import NoLoopAssertion
from tailtest.assertions.deterministic.pii import PIIAssertion
from tailtest.models import AgentResponse

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------


@dataclass
class QualityMetrics:
    """Quality metrics for a batch of agent responses."""

    total_responses: int = 0
    avg_latency_ms: float = 0.0
    avg_cost_usd: float = 0.0
    error_rate: float = 0.0  # percentage (0-100) of responses with errors
    pii_leak_rate: float = 0.0  # percentage (0-100) with PII detected
    avg_tool_calls: float = 0.0
    total_cost_usd: float = 0.0

    def to_dict(self) -> dict:
        """Serialise to a plain dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> QualityMetrics:
        """Deserialise from a plain dictionary."""
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class DriftAlert:
    """Alert when quality degrades below threshold."""

    metric_name: str
    baseline_value: float
    current_value: float
    threshold: float
    severity: str  # critical, warning, info
    message: str
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        """Serialise to a plain dictionary."""
        return asdict(self)


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


class FailureDetector:
    """Detects quality degradation in agent responses.

    Usage::

        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)
        detector.set_baseline(metrics)
        # ... later ...
        current = await detector.compute_metrics(new_responses)
        alerts = detector.detect_drift(current)
    """

    # Default thresholds (multipliers relative to baseline)
    LATENCY_THRESHOLD = 2.0  # alert if >2x baseline latency
    COST_THRESHOLD = 2.0  # alert if >2x baseline cost
    ERROR_RATE_THRESHOLD = 1.5  # alert if >1.5x baseline error rate
    # Any PII increase is critical
    PII_INCREASE_THRESHOLD = 0.0

    def __init__(self, baseline: QualityMetrics | None = None) -> None:
        self.baseline = baseline
        self.history: list[QualityMetrics] = []
        self._pii_assertion = PIIAssertion()
        self._loop_assertion = NoLoopAssertion()

    # ------------------------------------------------------------------ #
    # Metric computation
    # ------------------------------------------------------------------ #

    async def compute_metrics(
        self, responses: list[AgentResponse]
    ) -> QualityMetrics:
        """Compute quality metrics from a batch of responses."""
        if not responses:
            return QualityMetrics()

        total = len(responses)

        # Latency
        latencies = [r.latency_ms for r in responses if r.latency_ms is not None]
        avg_latency = sum(latencies) / len(latencies) if latencies else 0.0

        # Cost
        costs = [r.cost_usd for r in responses if r.cost_usd is not None]
        total_cost = sum(costs)
        avg_cost = total_cost / len(costs) if costs else 0.0

        # Error rate  -  responses that are empty or have no content
        error_count = sum(
            1 for r in responses if not r.content or not r.content.strip()
        )
        error_rate = (error_count / total) * 100.0

        # PII leak rate  -  use the existing PII assertion
        pii_count = 0
        for r in responses:
            result = await self._pii_assertion.evaluate(r)
            if not result.passed:
                pii_count += 1
        pii_leak_rate = (pii_count / total) * 100.0

        # Average tool calls
        total_tool_calls = sum(len(r.tool_calls) for r in responses)
        avg_tool_calls = total_tool_calls / total

        metrics = QualityMetrics(
            total_responses=total,
            avg_latency_ms=avg_latency,
            avg_cost_usd=avg_cost,
            error_rate=error_rate,
            pii_leak_rate=pii_leak_rate,
            avg_tool_calls=avg_tool_calls,
            total_cost_usd=total_cost,
        )

        self.history.append(metrics)
        return metrics

    # ------------------------------------------------------------------ #
    # Baseline management
    # ------------------------------------------------------------------ #

    def set_baseline(self, metrics: QualityMetrics) -> None:
        """Set the quality baseline for drift detection."""
        self.baseline = metrics

    def save_baseline(self, path: Path) -> None:
        """Save baseline to JSON."""
        if self.baseline is None:
            raise ValueError("No baseline set  -  call set_baseline() first.")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.baseline.to_dict(), indent=2))
        logger.info("Baseline saved to %s", path)

    def load_baseline(self, path: Path) -> QualityMetrics:
        """Load baseline from JSON and set it as the active baseline."""
        data = json.loads(path.read_text())
        metrics = QualityMetrics.from_dict(data)
        self.baseline = metrics
        logger.info("Baseline loaded from %s", path)
        return metrics

    # ------------------------------------------------------------------ #
    # Drift detection
    # ------------------------------------------------------------------ #

    def detect_drift(self, current: QualityMetrics) -> list[DriftAlert]:
        """Compare current metrics to baseline and return alerts.

        Checks:
        - Latency spike (>2x baseline)
        - Cost spike (>2x baseline)
        - Error rate increase (>1.5x baseline)
        - PII leak rate increase (any increase is critical)
        """
        if self.baseline is None:
            raise ValueError(
                "No baseline set  -  call set_baseline() or load_baseline() first."
            )

        alerts: list[DriftAlert] = []
        now = datetime.now(timezone.utc).isoformat()

        # --- Latency spike ---
        if self.baseline.avg_latency_ms > 0:
            ratio = current.avg_latency_ms / self.baseline.avg_latency_ms
            if ratio > self.LATENCY_THRESHOLD:
                alerts.append(
                    DriftAlert(
                        metric_name="avg_latency_ms",
                        baseline_value=self.baseline.avg_latency_ms,
                        current_value=current.avg_latency_ms,
                        threshold=self.LATENCY_THRESHOLD,
                        severity="warning",
                        message=(
                            f"Latency spike: {current.avg_latency_ms:.0f}ms "
                            f"vs baseline {self.baseline.avg_latency_ms:.0f}ms "
                            f"({ratio:.1f}x increase)"
                        ),
                        timestamp=now,
                    )
                )

        # --- Cost spike ---
        if self.baseline.avg_cost_usd > 0:
            ratio = current.avg_cost_usd / self.baseline.avg_cost_usd
            if ratio > self.COST_THRESHOLD:
                alerts.append(
                    DriftAlert(
                        metric_name="avg_cost_usd",
                        baseline_value=self.baseline.avg_cost_usd,
                        current_value=current.avg_cost_usd,
                        threshold=self.COST_THRESHOLD,
                        severity="warning",
                        message=(
                            f"Cost spike: ${current.avg_cost_usd:.4f} "
                            f"vs baseline ${self.baseline.avg_cost_usd:.4f} "
                            f"({ratio:.1f}x increase)"
                        ),
                        timestamp=now,
                    )
                )

        # --- Error rate increase ---
        if self.baseline.error_rate > 0:
            ratio = current.error_rate / self.baseline.error_rate
            if ratio > self.ERROR_RATE_THRESHOLD:
                alerts.append(
                    DriftAlert(
                        metric_name="error_rate",
                        baseline_value=self.baseline.error_rate,
                        current_value=current.error_rate,
                        threshold=self.ERROR_RATE_THRESHOLD,
                        severity="critical",
                        message=(
                            f"Error rate increase: {current.error_rate:.1f}% "
                            f"vs baseline {self.baseline.error_rate:.1f}% "
                            f"({ratio:.1f}x increase)"
                        ),
                        timestamp=now,
                    )
                )
        elif current.error_rate > 0:
            # Baseline was 0 errors but now we have errors
            alerts.append(
                DriftAlert(
                    metric_name="error_rate",
                    baseline_value=0.0,
                    current_value=current.error_rate,
                    threshold=self.ERROR_RATE_THRESHOLD,
                    severity="critical",
                    message=(
                        f"Error rate increase: {current.error_rate:.1f}% "
                        f"vs baseline 0.0% (new errors detected)"
                    ),
                    timestamp=now,
                )
            )

        # --- PII leak rate increase (any increase is critical) ---
        if current.pii_leak_rate > self.baseline.pii_leak_rate:
            alerts.append(
                DriftAlert(
                    metric_name="pii_leak_rate",
                    baseline_value=self.baseline.pii_leak_rate,
                    current_value=current.pii_leak_rate,
                    threshold=self.PII_INCREASE_THRESHOLD,
                    severity="critical",
                    message=(
                        f"PII leak rate increase: {current.pii_leak_rate:.1f}% "
                        f"vs baseline {self.baseline.pii_leak_rate:.1f}% "
                        f" -  any PII increase is critical"
                    ),
                    timestamp=now,
                )
            )

        return alerts
