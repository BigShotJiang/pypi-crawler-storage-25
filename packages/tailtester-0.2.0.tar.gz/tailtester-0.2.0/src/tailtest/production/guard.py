"""Production guard proxy  -  validates agent responses before forwarding."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import httpx

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.deterministic.cost import CostAssertion
from tailtest.assertions.deterministic.latency import LatencyAssertion
from tailtest.assertions.deterministic.no_loop import NoLoopAssertion
from tailtest.assertions.deterministic.pii import PIIAssertion
from tailtest.models import AgentResponse, AssertionResult, TokenUsage, ToolCall

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Metrics tracking
# ---------------------------------------------------------------------------


@dataclass
class GuardMetrics:
    """Accumulated metrics for the guard proxy."""

    total_requests: int = 0
    passed_requests: int = 0
    failed_requests: int = 0
    blocked_requests: int = 0
    total_latency_ms: float = 0.0
    _start_time: float = field(default_factory=time.monotonic)

    @property
    def pass_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.passed_requests / self.total_requests

    @property
    def avg_latency_ms(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.total_latency_ms / self.total_requests

    @property
    def uptime_seconds(self) -> float:
        return time.monotonic() - self._start_time

    @property
    def requests_per_second(self) -> float:
        elapsed = self.uptime_seconds
        if elapsed == 0:
            return 0.0
        return self.total_requests / elapsed


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


@dataclass
class AuditEntry:
    """A single audit log entry for a proxied request."""

    timestamp: str
    request_path: str
    request_method: str
    upstream_status: int
    assertion_results: list[dict]
    all_passed: bool
    blocked: bool
    latency_ms: float


# ---------------------------------------------------------------------------
# Guard proxy HTTP handler
# ---------------------------------------------------------------------------


class _GuardProtocol(asyncio.Protocol):
    """HTTP/1.1 protocol handler for the guard proxy."""

    def __init__(self, proxy: GuardProxy) -> None:
        self._proxy = proxy
        self._buffer = b""
        self._transport: asyncio.Transport | None = None

    def connection_made(self, transport: asyncio.Transport) -> None:  # type: ignore[override]
        self._transport = transport

    def data_received(self, data: bytes) -> None:
        self._buffer += data

        if b"\r\n\r\n" not in self._buffer:
            return

        header_end = self._buffer.index(b"\r\n\r\n")
        header_bytes = self._buffer[:header_end]
        body_start = header_end + 4

        # Parse Content-Length
        content_length = 0
        headers_dict: dict[str, str] = {}
        lines = header_bytes.split(b"\r\n")
        for line in lines[1:]:  # skip request line
            if b":" in line:
                key, _, val = line.partition(b":")
                headers_dict[key.strip().lower().decode()] = val.strip().decode()
        content_length = int(headers_dict.get("content-length", "0"))

        body = self._buffer[body_start:]
        if len(body) < content_length:
            return

        body = body[:content_length]

        # Parse request line
        request_line = lines[0].decode("utf-8", errors="replace")
        parts = request_line.split(" ")
        method = parts[0] if parts else "GET"
        path = parts[1] if len(parts) > 1 else "/"

        # Handle guard-specific endpoints
        if path == "/_guard/health":
            self._send_json(200, {
                "status": "ok",
                "metrics": {
                    "total_requests": self._proxy.metrics.total_requests,
                    "pass_rate": round(self._proxy.metrics.pass_rate, 4),
                    "avg_latency_ms": round(self._proxy.metrics.avg_latency_ms, 1),
                    "requests_per_second": round(
                        self._proxy.metrics.requests_per_second, 2
                    ),
                },
            })
            self._buffer = self._buffer[body_start + content_length:]
            return

        if path == "/_guard/metrics":
            self._send_json(200, {
                "total_requests": self._proxy.metrics.total_requests,
                "passed": self._proxy.metrics.passed_requests,
                "failed": self._proxy.metrics.failed_requests,
                "blocked": self._proxy.metrics.blocked_requests,
                "pass_rate": round(self._proxy.metrics.pass_rate, 4),
                "avg_latency_ms": round(self._proxy.metrics.avg_latency_ms, 1),
                "uptime_seconds": round(self._proxy.metrics.uptime_seconds, 1),
                "rps": round(self._proxy.metrics.requests_per_second, 2),
            })
            self._buffer = self._buffer[body_start + content_length:]
            return

        # Forward to upstream and validate
        asyncio.ensure_future(
            self._handle_proxy(method, path, headers_dict, body)
        )
        self._buffer = self._buffer[body_start + content_length:]

    async def _handle_proxy(
        self,
        method: str,
        path: str,
        headers: dict[str, str],
        body: bytes,
    ) -> None:
        """Forward request to upstream, validate response, return result."""
        start_time = time.monotonic()

        # Forward to upstream
        upstream_url = f"{self._proxy.upstream_url.rstrip('/')}{path}"
        forward_headers = {
            k: v for k, v in headers.items()
            if k not in ("host", "connection", "content-length")
        }

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                upstream_resp = await client.request(
                    method=method,
                    url=upstream_url,
                    headers=forward_headers,
                    content=body if body else None,
                )
        except httpx.HTTPError as exc:
            elapsed_ms = (time.monotonic() - start_time) * 1000
            logger.error("Upstream request failed: %s", exc)
            self._proxy.metrics.total_requests += 1
            self._proxy.metrics.failed_requests += 1
            self._proxy.metrics.total_latency_ms += elapsed_ms
            self._send_json(502, {"error": f"Upstream error: {exc}"})
            return

        elapsed_ms = (time.monotonic() - start_time) * 1000

        # Parse upstream response into AgentResponse for validation
        upstream_body = upstream_resp.content
        agent_response = self._proxy._parse_response_body(upstream_body, elapsed_ms)

        # Run assertions
        results = await self._proxy._run_assertions(agent_response)
        all_passed = all(r.passed for r in results)

        # Update metrics
        self._proxy.metrics.total_requests += 1
        self._proxy.metrics.total_latency_ms += elapsed_ms
        if all_passed:
            self._proxy.metrics.passed_requests += 1
        else:
            self._proxy.metrics.failed_requests += 1

        # Audit log
        self._proxy._log_audit(
            AuditEntry(
                timestamp=datetime.now(tz=timezone.utc).isoformat(),
                request_path=path,
                request_method=method,
                upstream_status=upstream_resp.status_code,
                assertion_results=[
                    {
                        "type": r.assertion_type,
                        "passed": r.passed,
                        "message": r.message,
                    }
                    for r in results
                ],
                all_passed=all_passed,
                blocked=not all_passed and self._proxy.block_on_failure,
                latency_ms=elapsed_ms,
            )
        )

        if not all_passed and self._proxy.block_on_failure:
            self._proxy.metrics.blocked_requests += 1
            failure_messages = [r.message for r in results if not r.passed]
            self._send_json(
                422,
                {
                    "error": "Response blocked by guard proxy",
                    "failures": failure_messages,
                    "guard": True,
                },
            )
            return

        # Forward the original upstream response
        # Add guard headers
        response_headers = dict(upstream_resp.headers)
        response_headers["X-Tailtest-Guard"] = "pass" if all_passed else "fail"
        response_headers["X-Tailtest-Guard-Checks"] = str(len(results))
        response_headers["X-Tailtest-Guard-Failures"] = str(
            sum(1 for r in results if not r.passed)
        )

        header_lines = f"HTTP/1.1 {upstream_resp.status_code} OK\r\n"
        for k, v in response_headers.items():
            if k.lower() not in ("transfer-encoding",):
                header_lines += f"{k}: {v}\r\n"
        header_lines += f"Content-Length: {len(upstream_body)}\r\n"
        header_lines += "\r\n"

        if self._transport:
            self._transport.write(header_lines.encode("utf-8") + upstream_body)

    def _send_json(self, status: int, data: dict) -> None:
        body = json.dumps(data).encode("utf-8")
        reason = {
            200: "OK",
            400: "Bad Request",
            422: "Unprocessable Entity",
            502: "Bad Gateway",
        }.get(status, "OK")
        header = (
            f"HTTP/1.1 {status} {reason}\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Connection: keep-alive\r\n"
            f"\r\n"
        )
        if self._transport:
            self._transport.write(header.encode("utf-8") + body)


# ---------------------------------------------------------------------------
# GuardProxy  -  the main proxy orchestrator
# ---------------------------------------------------------------------------


class GuardProxy:
    """HTTP proxy that validates agent responses before forwarding.

    Sits between the client and the upstream agent, running assertions
    on every response. Logs results to an audit trail under
    ``.tailtest/audit/`` and tracks request metrics.

    Usage::

        proxy = GuardProxy(upstream_url="http://localhost:3000", port=8080)
        await proxy.start()
    """

    def __init__(
        self,
        upstream_url: str,
        port: int = 8080,
        rules: list[BaseAssertion] | None = None,
        block_on_failure: bool = False,
        audit_dir: Path | None = None,
        max_cost: float = 1.0,
        max_latency_ms: int = 30000,
    ) -> None:
        self.upstream_url = upstream_url
        self.port = port
        self.rules = rules or self._default_rules(max_cost, max_latency_ms)
        self.block_on_failure = block_on_failure
        self.audit_dir = audit_dir or Path(".tailtest/audit")
        self.metrics = GuardMetrics()
        self._server: asyncio.Server | None = None
        self._audit_buffer: list[AuditEntry] = []

    @staticmethod
    def _default_rules(
        max_cost: float = 1.0,
        max_latency_ms: int = 30000,
    ) -> list[BaseAssertion]:
        """Default validation rules: no PII, no loops, cost under limit."""
        return [
            PIIAssertion(),
            NoLoopAssertion(max_repeats=5),
            CostAssertion(max_cost=max_cost),
            LatencyAssertion(max_ms=max_latency_ms),
        ]

    async def start(self) -> asyncio.Server:
        """Start the guard proxy server.

        Returns:
            The ``asyncio.Server`` instance so the caller can manage
            its lifecycle.
        """
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        loop = asyncio.get_running_loop()
        server = await loop.create_server(
            lambda: _GuardProtocol(self),
            "0.0.0.0",
            self.port,
            reuse_address=True,
        )
        self._server = server
        logger.info(
            "Guard proxy listening on port %d, upstream: %s",
            self.port,
            self.upstream_url,
        )
        return server

    async def stop(self) -> None:
        """Stop the guard proxy and flush audit logs."""
        self._flush_audit()
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
            logger.info("Guard proxy stopped")

    async def _run_assertions(
        self, response: AgentResponse
    ) -> list[AssertionResult]:
        """Run all configured assertion rules against the response."""
        results: list[AssertionResult] = []
        for rule in self.rules:
            try:
                result = await rule.evaluate(response)
                results.append(result)
            except Exception as exc:
                results.append(
                    AssertionResult(
                        passed=False,
                        assertion_type=type(rule).__name__,
                        expected="no error",
                        actual=str(exc),
                        message=f"Assertion raised an error: {exc}",
                    )
                )
        return results

    @staticmethod
    def _parse_response_body(body: bytes, latency_ms: float) -> AgentResponse:
        """Parse an upstream HTTP response body into an AgentResponse.

        Attempts to extract structured content from common agent response
        formats (OpenAI chat completions, raw JSON, plain text).
        """
        content = ""
        model: str | None = None
        tool_calls: list[ToolCall] = []
        tokens_used: TokenUsage | None = None
        cost_usd: float | None = None

        try:
            data = json.loads(body)
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Plain text response
            return AgentResponse(
                content=body.decode("utf-8", errors="replace"),
                latency_ms=latency_ms,
            )

        # OpenAI chat completion format
        if isinstance(data, dict) and "choices" in data:
            model = data.get("model")
            choices = data.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                for tc in message.get("tool_calls", []):
                    fn = tc.get("function", {})
                    try:
                        args = json.loads(fn.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        args = {}
                    tool_calls.append(
                        ToolCall(name=fn.get("name", ""), arguments=args)
                    )
            usage = data.get("usage", {})
            if usage:
                tokens_used = TokenUsage(
                    prompt_tokens=usage.get("prompt_tokens", 0),
                    completion_tokens=usage.get("completion_tokens", 0),
                    total_tokens=usage.get("total_tokens", 0),
                )

        # Anthropic format
        elif isinstance(data, dict) and data.get("type") == "message":
            model = data.get("model")
            for block in data.get("content", []):
                if block.get("type") == "text":
                    content += block.get("text", "")
                elif block.get("type") == "tool_use":
                    tool_calls.append(
                        ToolCall(
                            name=block.get("name", ""),
                            arguments=block.get("input", {}),
                        )
                    )
            usage = data.get("usage", {})
            if usage:
                tokens_used = TokenUsage(
                    prompt_tokens=usage.get("input_tokens", 0),
                    completion_tokens=usage.get("output_tokens", 0),
                    total_tokens=usage.get("input_tokens", 0)
                    + usage.get("output_tokens", 0),
                )

        # Generic JSON  -  just stringify it
        else:
            content = json.dumps(data)

        return AgentResponse(
            content=content,
            tool_calls=tool_calls,
            model=model,
            tokens_used=tokens_used,
            cost_usd=cost_usd,
            latency_ms=latency_ms,
        )

    def _log_audit(self, entry: AuditEntry) -> None:
        """Buffer an audit entry and flush periodically."""
        self._audit_buffer.append(entry)
        if len(self._audit_buffer) >= 50:
            self._flush_audit()

    def _flush_audit(self) -> None:
        """Write buffered audit entries to disk."""
        if not self._audit_buffer:
            return

        self.audit_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.audit_dir / f"audit-{int(time.time())}.jsonl"

        with out_path.open("a", encoding="utf-8") as f:
            for entry in self._audit_buffer:
                f.write(
                    json.dumps(
                        {
                            "timestamp": entry.timestamp,
                            "method": entry.request_method,
                            "path": entry.request_path,
                            "upstream_status": entry.upstream_status,
                            "assertions": entry.assertion_results,
                            "all_passed": entry.all_passed,
                            "blocked": entry.blocked,
                            "latency_ms": round(entry.latency_ms, 1),
                        },
                        default=str,
                    )
                    + "\n"
                )

        self._audit_buffer.clear()
        logger.debug("Flushed audit log to %s", out_path)
