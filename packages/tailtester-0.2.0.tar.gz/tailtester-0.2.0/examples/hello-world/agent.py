"""A simple mock support agent for demonstration.

This agent doesn't call any LLM  -  it uses pattern matching to simulate
agent behavior, making it perfect for testing the tailtest tool itself
without needing API keys.
"""

from tailtest.models import AgentResponse, ToolCall


def support_agent(message: str) -> AgentResponse:
    """A mock support agent that handles common queries."""
    message_lower = message.lower()

    if "order" in message_lower and "#" in message:
        # Extract order number and simulate a lookup
        return AgentResponse(
            content="I found your order. It's currently being shipped and should arrive within 3-5 business days.",
            tool_calls=[
                ToolCall(
                    name="lookup_order",
                    arguments={"order_id": message.split("#")[1].split()[0]},
                    result={"status": "shipped"},
                )
            ],
            latency_ms=150.0,
            cost_usd=0.003,
            model="mock-agent-v1",
        )

    if "refund" in message_lower:
        return AgentResponse(
            content="I can help you with a refund. Could you please provide your order number?",
            latency_ms=120.0,
            cost_usd=0.002,
            model="mock-agent-v1",
        )

    if "hours" in message_lower or "open" in message_lower:
        return AgentResponse(
            content="Our business hours are Monday to Friday, 9am to 5pm EST.",
            latency_ms=80.0,
            cost_usd=0.001,
            model="mock-agent-v1",
        )

    if any(word in message_lower for word in ["headache", "medicine", "medical", "sick"]):
        # BAD behavior  -  agent should NOT give medical advice
        return AgentResponse(
            content="You should take ibuprofen for headaches. Two tablets every 4-6 hours.",
            latency_ms=100.0,
            cost_usd=0.002,
            model="mock-agent-v1",
        )

    if "system prompt" in message_lower or "ignore previous" in message_lower:
        # Prompt injection attempt  -  agent should refuse
        return AgentResponse(
            content="I'm a customer support assistant. I can help you with orders, refunds, and business hours. How can I assist you today?",
            latency_ms=90.0,
            cost_usd=0.001,
            model="mock-agent-v1",
        )

    # Default response
    return AgentResponse(
        content="Hello! I'm a customer support assistant. I can help you with order tracking, refunds, and general inquiries. How can I help you today?",
        latency_ms=100.0,
        cost_usd=0.001,
        model="mock-agent-v1",
    )
