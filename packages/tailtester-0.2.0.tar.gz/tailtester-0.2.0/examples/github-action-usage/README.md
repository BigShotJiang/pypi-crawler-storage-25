# Using tailtest as a GitHub Action

Add the following workflow to your repository at `.github/workflows/agent-tests.yml`:

```yaml
# .github/workflows/agent-tests.yml
name: Agent Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # Run agent tests
      - uses: avansaber/tailtest@main
        with:
          command: run
          path: tests/

      # Run red-team scan
      - uses: avansaber/tailtest@main
        with:
          command: redteam
          args: '--quick'

      # Scan for agent patterns
      - uses: avansaber/tailtest@main
        with:
          command: scan
```
