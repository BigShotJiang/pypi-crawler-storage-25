# Tailtest + Claude Code Integration

Three ways to integrate tailtest with Claude Code so your AI agent tests run automatically as you develop.

## Prerequisites

Install tailtest:

```bash
pip install tailtester
```

Initialize your project (if you haven't already):

```bash
tailtest init
tailtest scan .
```

---

## 1. Post-Tool Hook -- Run tailtest after every file write

Claude Code hooks let you run commands automatically after Claude modifies files. This setup scans for agent patterns and runs your test suite every time Claude writes a Python file.

### Setup

Copy the hooks config into your project:

```bash
mkdir -p .claude
cp examples/claude-code-hooks/.claude/hooks.json .claude/hooks.json
```

Or add the following to your existing `.claude/hooks.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "write:src/**/*.py",
        "command": "tailtest scan . --output json",
        "description": "Scan for agent patterns after Python file changes"
      },
      {
        "matcher": "write:src/**/*.py",
        "command": "tailtest run tests/ --ci 2>/dev/null || true",
        "description": "Run agent tests after code changes"
      }
    ]
  }
}
```

### What it does

- **Scan hook**: After Claude writes any `.py` file under `src/`, tailtest scans the project and updates its context (detected framework, tools, prompts, agents). The JSON output is fed back to Claude so it understands your agent's structure.
- **Test hook**: After the scan, tailtest runs your test suite in CI mode. The `2>/dev/null || true` ensures Claude is not blocked if tests fail -- it sees the results and can fix issues in the same session.

### Customization

Change the `matcher` glob to match your project layout:

```json
{
  "matcher": "write:app/**/*.py",
  "command": "tailtest scan app/ --output json"
}
```

Add a safety check hook that runs after any file write:

```json
{
  "matcher": "write:**/*.py",
  "command": "tailtest guard --check-only",
  "description": "Check for safety regressions"
}
```

---

## 2. MCP Server -- Expose tailtest tools inside Claude Code

The MCP (Model Context Protocol) integration gives Claude direct access to tailtest tools. Claude can scan projects, generate tests, run tests, check safety, and explain failures -- all without leaving the conversation.

### Setup

Copy the settings config into your project:

```bash
mkdir -p .claude
cp examples/claude-code-hooks/.claude/settings.json .claude/settings.json
```

Or add the `tailtest` entry to your existing `.claude/settings.json`:

```json
{
  "mcpServers": {
    "tailtest": {
      "command": "tailtest",
      "args": ["mcp-serve"],
      "description": "AI agent testing  -  scan, generate tests, run tests, check safety"
    }
  }
}
```

### Available tools

Once configured, Claude Code can use these tools in conversation:

| Tool | Description |
|------|-------------|
| `scan_project` | Scan a directory and return detected framework, tools, prompts, models, and agents |
| `generate_tests` | Scan an agent project and auto-generate a test suite |
| `run_tests` | Discover and run tailtest tests, returning pass/fail results |
| `check_safety` | Quick safety check on an agent response (PII detection, credential leaks, prompt injection) |
| `explain_failure` | Explain why a test failed and suggest how to fix it |
| `suggest_test` | Given a code diff or description, suggest tailtest tests using the `expect()` API |

### Usage examples

Ask Claude Code:

- "Scan this project and tell me what agent framework it uses"
- "Generate tests for my agent"
- "Run the tests and fix any failures"
- "Check if this response is safe: ..."
- "Why did test_no_pii fail with 'PII detected in response'?"
- "Suggest tests for a tool-calling agent that handles weather queries"

### Combining hooks + MCP

You can use both approaches together. The hooks provide automatic scanning on file changes, while the MCP server lets Claude call tailtest tools on demand. Add both `.claude/hooks.json` and `.claude/settings.json` to your project.

---

## 3. Pre-Commit Hook -- Run tailtest before committing

Run the full test suite before every `git commit`. If any test fails, the commit is blocked until you fix the issues.

### Setup

Copy the hook into your git hooks directory:

```bash
cp examples/claude-code-hooks/pre-commit-hook.sh .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

### What it does

```bash
#!/bin/bash
# Pre-commit hook: run tailtest before committing
# Install: cp examples/claude-code-hooks/pre-commit-hook.sh .git/hooks/pre-commit

echo "Running tailtest..."
tailtest run --ci
if [ $? -ne 0 ]; then
    echo "tailtest failed. Fix the issues before committing."
    exit 1
fi
echo "tailtest passed."
```

The `--ci` flag runs tests in non-interactive mode with structured output, suitable for automation.

### Skipping the hook

If you need to commit without running tests (not recommended):

```bash
git commit --no-verify -m "WIP: work in progress"
```

### Extending the hook

Add a scan before running tests to catch new agent patterns:

```bash
#!/bin/bash
echo "Scanning for agent patterns..."
tailtest scan . --output json > /dev/null 2>&1

echo "Running tailtest..."
tailtest run --ci
if [ $? -ne 0 ]; then
    echo "tailtest failed. Fix the issues before committing."
    exit 1
fi

echo "Checking for safety issues..."
tailtest guard --check-only
if [ $? -ne 0 ]; then
    echo "Safety check failed. Review the issues before committing."
    exit 1
fi

echo "All checks passed."
```

---

## File structure

```
examples/claude-code-hooks/
  .claude/
    hooks.json       # Post-tool hooks config (copy to your .claude/)
    settings.json    # MCP server config (copy to your .claude/)
  pre-commit-hook.sh # Git pre-commit hook (copy to .git/hooks/pre-commit)
  README.md          # This file
```

## Further reading

- [Tailtest quickstart](../../docs/guide/quickstart.md)
- [Writing tests](../../docs/guide/writing-tests.md)
- [Assertions reference](../../docs/guide/assertions-reference.md)
- [MCP server config](../mcp-config.json) -- standalone MCP config for other editors
