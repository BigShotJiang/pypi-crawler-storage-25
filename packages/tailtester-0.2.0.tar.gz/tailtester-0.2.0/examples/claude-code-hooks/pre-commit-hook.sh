#!/bin/bash
# Pre-commit hook: run tailtest before committing
# Install: cp examples/claude-code-hooks/pre-commit-hook.sh .git/hooks/pre-commit

echo "Running tailtest..."
tailtest run --ci
if [ $? -ne 0 ]; then
    echo "tailtest failed. Fix the issues before committing."
    exit 1
fi
echo "tailtest passed."
