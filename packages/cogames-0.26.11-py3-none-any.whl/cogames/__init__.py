"""CoGames package."""
