"""CLI smoke tests.

We don't spin up a real backend — respx intercepts httpx calls and returns
canned responses. The goal is to assert the CLI parses output correctly
and shapes the right HTTP requests, not to re-test the backend.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import respx
from httpx import Response
from typer.testing import CliRunner

from sirb_cli.config import CliConfig
from sirb_cli.main import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def tmp_config(tmp_path: Path, monkeypatch):
    """Point the CLI's config at a tmp file so tests don't touch the real one."""
    monkeypatch.setenv("SIRB_CLI_CONFIG", str(tmp_path / "config.json"))
    # Pre-seed with a base_url + api_key so commands work without `login`.
    CliConfig(base_url="http://sirb.test", api_key="sirb_test", default_model="mock-7b").save()
    yield


def test_login_writes_config(tmp_path):
    cfg_path = Path(os.environ["SIRB_CLI_CONFIG"])
    r = runner.invoke(app, ["login", "--api-key", "sirb_new", "--base-url", "https://example.com"])
    assert r.exit_code == 0, r.output
    saved = json.loads(cfg_path.read_text())
    assert saved["api_key"] == "sirb_new"
    assert saved["base_url"] == "https://example.com"


@respx.mock
def test_models_calls_endpoint_and_renders():
    respx.get("http://sirb.test/v1/models").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "mock-7b", "owned_by": "decentralized-community"},
        ]})
    )
    r = runner.invoke(app, ["models"])
    assert r.exit_code == 0, r.output
    assert "mock-7b" in r.output


@respx.mock
def test_chat_non_stream_prints_completion():
    respx.post("http://sirb.test/v1/chat/completions").mock(
        return_value=Response(200, json={
            "id": "x", "object": "chat.completion", "created": 0, "model": "mock-7b",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "pong"},
                         "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        })
    )
    r = runner.invoke(app, ["chat", "ping"])
    assert r.exit_code == 0, r.output
    assert "pong" in r.output


@respx.mock
def test_balance_unconfigured_renders_warning():
    respx.get("http://sirb.test/v1/balance").mock(
        return_value=Response(200, json={
            "object": "sirb.balance", "wallet": "0xtest",
            "balance": 0.0, "balance_wei": "0", "currency": "SIRB",
            "source": "unconfigured",
        })
    )
    r = runner.invoke(app, ["balance"])
    assert r.exit_code == 0, r.output
    assert "unavailable" in r.output.lower() or "no chain" in r.output.lower()


@respx.mock
def test_keys_create_renders_plaintext_warning():
    respx.post("http://sirb.test/admin/api-keys").mock(
        return_value=Response(201, json={
            "object": "sirb.api_key.created", "id": "key_abc",
            "key": "sirb_supersecret", "name": "demo",
            "wallet_address": "0xtest", "created_at": "2026-05-14T00:00:00Z",
            "rate_limit_per_minute": 60,
        })
    )
    r = runner.invoke(app, ["keys", "create", "--name", "demo"])
    assert r.exit_code == 0, r.output
    assert "sirb_supersecret" in r.output
    assert "only time" in r.output.lower()


@respx.mock
def test_keys_revoke_calls_delete():
    route = respx.delete("http://sirb.test/admin/api-keys/key_abc").mock(
        return_value=Response(204)
    )
    r = runner.invoke(app, ["keys", "revoke", "key_abc"])
    assert r.exit_code == 0, r.output
    assert route.called


def test_opencode_env_prints_export_lines():
    r = runner.invoke(app, ["opencode", "env"])
    assert r.exit_code == 0, r.output
    assert 'export OPENAI_API_KEY="sirb_test"' in r.output
    assert 'export OPENAI_BASE_URL="http://sirb.test/v1"' in r.output


def test_opencode_config_prints_json():
    r = runner.invoke(app, ["opencode", "config"])
    assert r.exit_code == 0, r.output
    parsed = json.loads(r.output)
    assert parsed["provider"] == "openai-compatible"
    assert parsed["baseURL"] == "http://sirb.test/v1"
    assert parsed["apiKey"] == "sirb_test"


@respx.mock
def test_status_all_green_exits_zero():
    """Status command should hit healthz/readyz/balance/models/nodes and
    render a green row for each. Exit code 0 when nothing failed."""
    respx.get("http://sirb.test/healthz").mock(return_value=Response(200, json={"status": "ok"}))
    respx.get("http://sirb.test/readyz").mock(return_value=Response(200, json={"db": {"ok": True}, "chain": {"skipped": True}}))
    respx.get("http://sirb.test/v1/balance").mock(return_value=Response(200, json={
        "wallet": "0xtest", "balance": 1.5, "balance_wei": "1500000000000000000",
        "currency": "SIRB", "source": "chain",
    }))
    respx.get("http://sirb.test/v1/models").mock(return_value=Response(200, json={
        "object": "list", "data": [{"id": "mock-7b", "owned_by": "x"}],
    }))
    respx.get("http://sirb.test/nodes").mock(return_value=Response(200, json=[
        {"node_id": "n1", "status": "online"},
        {"node_id": "n2", "status": "offline"},
    ]))
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 0, r.output
    # Spot-check the table contains each check's output
    assert "Gateway" in r.output
    assert "Readiness" in r.output
    assert "Auth" in r.output
    assert "1 online / 2 registered" in r.output
    assert "mock-7b" in r.output


@respx.mock
def test_status_gateway_unreachable_exits_nonzero():
    """If /healthz can't be reached, exit code should be 1 so shell
    scripts (`sirb status && deploy`) short-circuit cleanly. respx
    raises AllMockedAssertionError for unmocked URLs, so we have to
    mock every endpoint the command probes (the later probes still get
    rendered but don't change the fail outcome)."""
    import httpx
    respx.get("http://sirb.test/healthz").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/readyz").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/v1/balance").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/v1/models").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/nodes").mock(side_effect=httpx.ConnectError("nope"))
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 1, r.output
    assert "fail" in r.output.lower() or "ConnectError" in r.output


@respx.mock
def test_observations_bare_runs_list():
    """Bare `sirb observations` (no subcommand) should default to the
    list view, not show help. Without this default, the unfriendly
    no-args-is-help behavior left users dead-ended on `sirb observations`."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "obs_1", "kind": "monitoring", "outcome": "ok",
             "provider": "sirb", "summary": "all green", "findings": []},
        ]})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 0, r.output
    # The table doesn't render the id column (id is part of `show`),
    # but kind + outcome + summary are visible enough to confirm the
    # list defaulted as intended.
    assert "monitoring" in r.output
    assert "all green" in r.output


@respx.mock
def test_observations_show_fetches_single():
    """`sirb observations show <id>` hits the singular endpoint and
    renders the findings section."""
    respx.get("http://sirb.test/admin/observations/obs_42").mock(
        return_value=Response(200, json={
            "id": "obs_42", "kind": "fraud_detection", "outcome": "ok",
            "provider": "sirb", "summary": "two suspect nodes",
            "findings": [
                {"severity": "warning", "category": "low_pass_rate",
                 "target": "0xnode_a", "detail": "0.41 over window=200"},
            ],
        })
    )
    r = runner.invoke(app, ["observations", "show", "obs_42"])
    assert r.exit_code == 0, r.output
    assert "obs_42" in r.output
    assert "two suspect nodes" in r.output
    assert "warning" in r.output


@respx.mock
def test_observations_all_dry_run_shows_hint():
    """When every recent observation is dry_run, the user should see the
    'how to enable real runs' footer — otherwise they think the agents
    are broken."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "o1", "kind": "monitoring", "outcome": "dry_run", "provider": "none", "summary": None, "findings": []},
            {"id": "o2", "kind": "monitoring", "outcome": "dry_run", "provider": "none", "summary": None, "findings": []},
        ]})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 0, r.output
    assert "dry_run" in r.output.lower()
    assert "SIRB_MONITORING_ENABLED" in r.output


@respx.mock
def test_observations_403_renders_admin_scope_message():
    """Non-admin key → backend returns 403 admin_scope_required.
    The CLI catches that and prints a clean one-line message instead
    of leaking an HTTPStatusError traceback. Exit code 1 so shell
    scripts can branch."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "type": "permission_error",
            "message": "this endpoint requires an admin-scoped API key",
        }}})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()
    # Operator-only guidance must NOT appear for non-admin users —
    # they can't act on it and it leaks gateway-tuning intent.
    assert "SIRB_MONITORING_ENABLED" not in r.output
    assert "fly secrets set" not in r.output


@respx.mock
def test_observations_show_admin_only():
    """Same gating on `show` subcommand."""
    respx.get("http://sirb.test/admin/observations/obs_x").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "message": "needs admin",
        }}})
    )
    r = runner.invoke(app, ["observations", "show", "obs_x"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()


@respx.mock
def test_observations_run_admin_only():
    """Same gating on `run` subcommand."""
    respx.post("http://sirb.test/admin/observations/run").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "message": "needs admin",
        }}})
    )
    r = runner.invoke(app, ["observations", "run", "--kind", "monitoring"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()


def test_deploy_help_lists_node_and_gateway():
    """Just confirm both deploy subcommands are wired up."""
    r = runner.invoke(app, ["deploy", "--help"])
    assert r.exit_code == 0, r.output
    assert "node" in r.output
    assert "gateway" in r.output


def test_wallet_new_no_save_prints_address():
    """`sirb wallet new --no-save` should print a 0x + 40-hex address
    and NOT write to disk."""
    r = runner.invoke(app, ["wallet", "new", "--no-save"])
    assert r.exit_code == 0, r.output
    # Look for 0x followed by 40 hex chars somewhere in the output
    import re
    m = re.search(r"0x[a-fA-F0-9]{40}", r.output)
    assert m, f"no wallet address in output: {r.output}"


def test_signing_secret_new_show_prints_hex_only():
    """`sirb signing-secret new --show` should print only the hex value,
    pipe-friendly. 32 bytes default = 64 hex chars."""
    r = runner.invoke(app, ["signing-secret", "new", "--show"])
    assert r.exit_code == 0, r.output
    line = r.output.strip()
    # Exactly 64 lowercase hex chars
    import re
    assert re.fullmatch(r"[a-f0-9]{64}", line), f"unexpected output: {line!r}"


def test_signing_secret_new_default_includes_hints():
    """Without --show, the command should print the secret PLUS the
    operator-facing setup hints (fly secrets set / sirb deploy node)."""
    r = runner.invoke(app, ["signing-secret", "new"])
    assert r.exit_code == 0, r.output
    assert "fly secrets set" in r.output
    assert "sirb deploy node" in r.output


def test_deploy_node_help_shows_no_sharding_default():
    """The --no-sharding flag must show as the DEFAULT in --help so
    contributors see at a glance that they're opted-out by default."""
    r = runner.invoke(app, ["deploy", "node", "--help"])
    assert r.exit_code == 0, r.output
    assert "--no-sharding" in r.output
    assert "--allow-sharding" in r.output


def test_deploy_gateway_print_mode():
    """`--print` should emit the deploy script without trying to run it,
    so users can review what gets executed before saying yes. We point
    at a fake backend dir to satisfy the fly.toml existence check."""
    import os
    from pathlib import Path
    repo = Path(os.environ.get("TMPDIR", "/tmp")) / "sirb-deploy-test"
    (repo / "backend").mkdir(parents=True, exist_ok=True)
    (repo / "backend" / "fly.toml").write_text("# fake\n")
    cwd = os.getcwd()
    os.chdir(repo)
    try:
        r = runner.invoke(app, ["deploy", "gateway", "--app-name", "sirb-test",
                                 "--region", "iad", "--print"])
        assert r.exit_code == 0, r.output
        assert "fly apps create" in r.output
        assert "sirb-test" in r.output
        assert "openssl rand -hex 32" in r.output
        assert "alembic upgrade head" in r.output
        # Confirm we didn't accidentally invoke flyctl
        assert "Connecting to" not in r.output
    finally:
        os.chdir(cwd)


def test_status_warns_when_no_api_key(monkeypatch):
    """No key configured → Config + Auth show warn, but exit 0 (the
    user might just be browsing models, which doesn't need auth)."""
    # Wipe the api_key out of the seeded config
    CliConfig(base_url="http://sirb.test", api_key=None, default_model="mock-7b").save()
    # Mock the unauthed endpoints so we don't time out
    with respx.mock() as mock:
        mock.get("http://sirb.test/healthz").mock(return_value=Response(200, json={"status": "ok"}))
        mock.get("http://sirb.test/readyz").mock(return_value=Response(200, json={"db": {"ok": True}}))
        mock.get("http://sirb.test/v1/models").mock(return_value=Response(200, json={"object": "list", "data": []}))
        mock.get("http://sirb.test/nodes").mock(return_value=Response(200, json=[]))
        r = runner.invoke(app, ["status"])
    assert r.exit_code == 0, r.output
    assert "no api key" in r.output.lower()
