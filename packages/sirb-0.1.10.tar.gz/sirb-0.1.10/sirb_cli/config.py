"""CLI config persistence with multi-profile support.

State lives at ``~/.sirb/config.json`` by default (overridable with
``SIRB_CLI_CONFIG``). We do NOT keep a separate credential store — the
config file's permissions are the boundary (0600 on Unix). On Windows
the file inherits user-level perms.

File layout (current, v2):

    {
      "active": "default",
      "profiles": {
        "default": {
          "base_url": "https://api.sirb.run",
          "api_key": "sirb_...",
          "default_model": "gemma4:e4b"
        },
        "local-dev": {
          "base_url": "http://localhost:8000",
          "api_key": "sirb_dev_key",
          "default_model": "mock-7b"
        }
      }
    }

Legacy (v1) layout — automatically migrated on first read:

    { "base_url": "...", "api_key": "...", "default_model": "..." }

…becomes a single profile named "default".
"""

from __future__ import annotations

import json
import os
import stat
from dataclasses import asdict, dataclass, field
from pathlib import Path


DEFAULT_PROFILE_NAME = "default"


def _config_path() -> Path:
    env = os.environ.get("SIRB_CLI_CONFIG")
    if env:
        return Path(env)
    return Path.home() / ".sirb" / "config.json"


@dataclass
class CliConfig:
    """One profile's worth of state. Kept as a flat dataclass so existing
    call sites — `cfg.base_url`, `cfg.api_key`, `cfg.default_model` — keep
    working unchanged after the multi-profile refactor."""

    base_url: str = "https://api.sirb.run"
    api_key: str | None = None
    default_model: str = "gemma4:e4b"

    @classmethod
    def load(cls) -> "CliConfig":
        """Load the active profile, or empty config if no file exists."""
        store = ProfileStore.load()
        return store.active_profile()

    def save(self) -> Path:
        """Save this config as the active profile, preserving siblings."""
        store = ProfileStore.load()
        store.profiles[store.active] = self
        return store.save()


@dataclass
class ProfileStore:
    """All saved profiles + which one is currently active."""

    active: str = DEFAULT_PROFILE_NAME
    profiles: dict[str, CliConfig] = field(default_factory=dict)

    @classmethod
    def load(cls) -> "ProfileStore":
        p = _config_path()
        if not p.exists():
            return cls()
        try:
            data = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            return cls()

        # Legacy v1 detection: flat object with base_url/api_key at the root.
        # Migrate inline by wrapping it as the "default" profile.
        if "profiles" not in data and any(k in data for k in ("api_key", "base_url", "default_model")):
            return cls(
                active=DEFAULT_PROFILE_NAME,
                profiles={DEFAULT_PROFILE_NAME: _profile_from_dict(data)},
            )

        profiles = {
            name: _profile_from_dict(body)
            for name, body in (data.get("profiles") or {}).items()
        }
        active = data.get("active") or DEFAULT_PROFILE_NAME
        # Defensive: if the file claims an active profile that doesn't exist,
        # fall back to one that does (or empty).
        if active not in profiles and profiles:
            active = next(iter(profiles))
        return cls(active=active, profiles=profiles)

    def save(self) -> Path:
        p = _config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "active": self.active,
            "profiles": {name: asdict(cfg) for name, cfg in self.profiles.items()},
        }
        p.write_text(json.dumps(payload, indent=2))
        try:
            os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
        except (OSError, NotImplementedError):
            pass
        return p

    def active_profile(self) -> CliConfig:
        """Return the active profile, or an empty default when nothing is
        configured. Never raises — callers downstream check `api_key` is set."""
        if self.active in self.profiles:
            return self.profiles[self.active]
        return CliConfig()

    def names(self) -> list[str]:
        return sorted(self.profiles.keys())


def _profile_from_dict(d: dict) -> CliConfig:
    return CliConfig(
        base_url=d.get("base_url", CliConfig.base_url),
        api_key=d.get("api_key"),
        default_model=d.get("default_model", CliConfig.default_model),
    )


def env_override_or_config() -> CliConfig:
    """Env vars trump the saved active profile. Lets users do one-off calls
    without rewriting their config and without flipping profiles."""
    cfg = CliConfig.load()
    if (env_url := os.environ.get("SIRB_BASE_URL")):
        cfg.base_url = env_url
    if (env_key := os.environ.get("SIRB_API_KEY")):
        cfg.api_key = env_key
    if (env_model := os.environ.get("SIRB_MODEL")):
        cfg.default_model = env_model
    return cfg
