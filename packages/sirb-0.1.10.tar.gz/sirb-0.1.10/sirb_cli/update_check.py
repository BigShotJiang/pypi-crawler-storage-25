"""Best-effort update advisories.

Two checks live here:

  1. CLI version (PyPI) — query the public JSON API for the latest
     `sirb` release and compare against `importlib.metadata.version`.
     Used after every `sirb deploy …` and inside `sirb status`.
  2. Local node-agent image age (docker inspect) — a rough heuristic;
     if the image powering the running container is older than N days,
     advise running `sirb deploy node` to refresh. Used by `sirb status`
     only; post-deploy the image was just pulled so the check is moot.

Both checks are fail-soft. Any network/Docker/parsing error returns
None silently — a flaky PyPI mirror or missing Docker socket must not
make `sirb deploy` look broken.

`SIRB_DISABLE_UPDATE_CHECK=1` short-circuits both checks. Useful for
CI loops and air-gapped installs.
"""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from importlib import metadata

import httpx
from rich import print as rprint


PYPI_URL = "https://pypi.org/pypi/sirb/json"
NODE_IMAGE_AGE_THRESHOLD_DAYS = 7


# ─── version parsing ────────────────────────────────────────────────────

def _installed_version() -> str | None:
    try:
        return metadata.version("sirb")
    except metadata.PackageNotFoundError:
        return None


def _parse(v: str) -> tuple[int, ...]:
    """Minimal semver-ish parse. Splits on '.', takes the LEADING run of
    digits from each part (so '7a1' parses as 7, not 71), falls back to
    0 on garbage. Good enough for the 'is 0.1.7 < 0.1.8' question; we
    don't try to rank alpha vs release."""
    parts = []
    for p in v.split("."):
        digits = ""
        for c in p:
            if c.isdigit():
                digits += c
            else:
                break
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def _is_outdated(installed: str, latest: str) -> bool:
    if installed == latest:
        return False
    try:
        return _parse(installed) < _parse(latest)
    except Exception:
        return False


# ─── PyPI check ─────────────────────────────────────────────────────────

def latest_pypi_version(timeout: float = 3.0) -> str | None:
    try:
        r = httpx.get(PYPI_URL, timeout=timeout)
        r.raise_for_status()
        return r.json()["info"]["version"]
    except Exception:
        return None


def check_cli_update() -> tuple[str, str] | None:
    """Return (installed, latest) when an update is available, else None.
    Skips the network call when SIRB_DISABLE_UPDATE_CHECK is truthy."""
    if os.environ.get("SIRB_DISABLE_UPDATE_CHECK"):
        return None
    installed = _installed_version()
    if not installed:
        return None
    latest = latest_pypi_version()
    if latest and _is_outdated(installed, latest):
        return installed, latest
    return None


def print_cli_update_advisory_if_outdated() -> bool:
    """Print a loud coral banner if the installed sirb is older than
    PyPI's latest. Returns True iff a banner was shown (handy for
    callers that want to gate exit codes or follow-up nudges)."""
    update = check_cli_update()
    if not update:
        return False
    installed, latest = update
    bar = "━" * 64
    rprint()
    rprint(f"[bold #FF6B47]{bar}[/bold #FF6B47]")
    rprint("[bold #FF6B47]  ⚠  A newer sirb CLI is available — update now[/bold #FF6B47]")
    rprint(f"     installed: [yellow]{installed}[/yellow]    latest: [green]{latest}[/green]")
    rprint()
    rprint("     [bold cyan]pip install --upgrade sirb[/bold cyan]")
    rprint()
    rprint("     Recent releases fix CLI bugs and bump the default image pins.")
    rprint("     Set [dim]SIRB_DISABLE_UPDATE_CHECK=1[/dim] to silence this check.")
    rprint(f"[bold #FF6B47]{bar}[/bold #FF6B47]")
    rprint()
    return True


# ─── node-agent image freshness ─────────────────────────────────────────

def _container_image_created_at(container: str) -> datetime | None:
    """Return the build timestamp of the image powering a running container.

    Goes through two `docker inspect` calls — first to map container →
    image id, then image id → Created. The container's own `Created`
    field is the *container* creation time, not the image build time."""
    try:
        out = subprocess.run(
            ["docker", "inspect", "--format", "{{.Image}}", container],
            capture_output=True, text=True, timeout=5,
        )
        if out.returncode != 0 or not out.stdout.strip():
            return None
        image_id = out.stdout.strip()

        out2 = subprocess.run(
            ["docker", "image", "inspect", "--format", "{{.Created}}", image_id],
            capture_output=True, text=True, timeout=5,
        )
        if out2.returncode != 0 or not out2.stdout.strip():
            return None
        created_str = out2.stdout.strip()
        # Docker emits RFC3339 with nanoseconds; trim to microseconds for fromisoformat.
        # E.g. "2026-05-15T14:23:11.123456789Z" → "2026-05-15T14:23:11.123456+00:00"
        if "." in created_str:
            head, _, tail = created_str.partition(".")
            tail = tail.rstrip("Z")
            tail = tail[:6]
            created_str = f"{head}.{tail}+00:00"
        else:
            created_str = created_str.replace("Z", "+00:00")
        return datetime.fromisoformat(created_str)
    except (subprocess.SubprocessError, OSError, ValueError):
        return None


def check_node_image_age(container: str = "sirb-node",
                        days: int = NODE_IMAGE_AGE_THRESHOLD_DAYS) -> int | None:
    """Return the image age in days when it's older than `days`,
    otherwise None. None also when no container is running or any step
    in the lookup failed — the check is a hint, never a blocker."""
    if os.environ.get("SIRB_DISABLE_UPDATE_CHECK"):
        return None
    created = _container_image_created_at(container)
    if not created:
        return None
    age_days = (datetime.now(timezone.utc) - created).days
    return age_days if age_days >= days else None
