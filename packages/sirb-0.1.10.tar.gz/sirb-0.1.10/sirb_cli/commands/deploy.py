"""``sirb deploy`` — bring up either a node or a whole gateway.

Two subcommands, two very different lifecycles:

    sirb deploy node        # run a node-agent on this machine (wraps install.sh)
    sirb deploy gateway     # bootstrap a brand-new Sirb gateway on Fly.io

`node` is what most people want — turn a laptop or workstation into a
contributor in one command. It's a thin wrapper around the canonical
landing/install.sh: same flags, same end state, but invoked through the
CLI you already have configured.

`gateway` is for someone standing up their *own* Sirb network (a
fork, a private deployment, a stage env). It generates the Fly secrets,
creates the app + Postgres, deploys, runs migrations, and mints a
bootstrap admin key — all the runbook §2 steps in one command. Requires
flyctl on PATH and an authenticated session.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import httpx
import typer
from rich import print as rprint
from rich.console import Console
from rich.prompt import Confirm

from sirb_cli.config import env_override_or_config
from sirb_cli.update_check import print_cli_update_advisory_if_outdated

app = typer.Typer(
    invoke_without_command=False,
    no_args_is_help=True,
    help="Deploy a node on this machine, or a brand-new gateway on Fly.io.",
)

console = Console()

INSTALLER_URL = "https://sirb.run/install.sh"

# Default image references for `sirb deploy node` and `sirb deploy gateway`.
#
# We track `:latest` rather than a pinned version. The publish workflows
# (.github/workflows/publish-{node,gateway}-image.yml) rebuild `:latest` on
# every push to main, so users always pull the current state of the network's
# canonical build. Operators who want reproducible deploys can pin to a
# specific tag via `--image ghcr.io/ammarwa/sirb-<service>:vX.Y.Z`.
DEFAULT_NODE_IMAGE = "ghcr.io/ammarwa/sirb-node:latest"
DEFAULT_GATEWAY_IMAGE = "ghcr.io/ammarwa/sirb-gateway:latest"


# ─────────────────────────── node ──────────────────────────────────


@app.command("node")
def node(
    backend: str | None = typer.Option(
        None, "--backend", "-b",
        help="Gateway URL. Defaults to your `sirb login` base_url, which itself defaults to https://api.sirb.run.",
    ),
    signing_secret: str | None = typer.Option(
        None, "--signing-secret", "-s",
        envvar="SIRB_SIGNING_SECRET",
        help=(
            "HMAC secret matching the gateway. Optional: when omitted, the script does "
            "key-only setup (mints your API key, skips node registration). Get this from "
            "the gateway operator, or run `sirb signing-secret new` if you're standing up "
            "your own network."
        ),
    ),
    api_key: str | None = typer.Option(
        None, "--api-key", "-k",
        help="Reuse an existing API key instead of minting one. Defaults to your `sirb login` key.",
    ),
    wallet: str | None = typer.Option(
        None, "--wallet", "-w",
        help=(
            "0x-prefixed wallet for on-chain rewards. Optional: when omitted, the installer "
            "generates an off-chain identifier (works for testnet, can't claim chain rewards). "
            "To use a real Ethereum wallet, pass its address here. To mint an off-chain "
            "wallet without running the installer, see `sirb wallet new`."
        ),
    ),
    models: str | None = typer.Option(
        None, "--models", "-m",
        help="Comma-separated model ids this node will advertise.",
    ),
    no_sharding: bool = typer.Option(
        True, "--no-sharding/--allow-sharding",
        help=(
            "Opt your node out of sharded-model fan-out (MoE / pipeline / tensor parallel). "
            "Default is opted-OUT — by joining you only serve single-node-topology models "
            "unless you explicitly enable sharding. Some operators run nodes specifically "
            "for sharded participation; turn it on with --allow-sharding."
        ),
    ),
    name: str = typer.Option(
        "sirb-node", "--name", "-n",
        help="Docker container name (default: sirb-node).",
    ),
    image: str = typer.Option(
        DEFAULT_NODE_IMAGE, "--image", "-i",
        envvar="SIRB_NODE_IMAGE",
        help=(
            f"Node-agent image to run. Default: {DEFAULT_NODE_IMAGE} — "
            "tracks the latest build from main. Override with a specific "
            "tag (e.g. ghcr.io/ammarwa/sirb-node:v0.2.0) for a reproducible deploy."
        ),
    ),
    # Resource budget — left as `None` means "let install.sh auto-detect
    # from this host". Set any of them to declare a cap explicitly.
    cpu_cores: int | None = typer.Option(
        None, "--cpu-cores",
        help="CPU cores to dedicate to the node (Docker --cpus). Auto-detected if omitted.",
    ),
    ram_gb: int | None = typer.Option(
        None, "--ram-gb",
        help="RAM cap in GB (Docker --memory). Auto-detected if omitted.",
    ),
    gpu_count: int | None = typer.Option(
        None, "--gpu-count",
        help="How many GPUs to expose (Docker --gpus 'count=N'). 0 = CPU-only.",
    ),
    gpu_percent: int | None = typer.Option(
        None, "--gpu-percent",
        help="1-100, fraction of GPU compute Sirb may use (advisory unless NVIDIA MPS is set up).",
    ),
    vram_gb: float | None = typer.Option(
        None, "--vram-gb",
        help="VRAM advertised in the registration claim. Auto-detected from nvidia-smi.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Run a node-agent on this machine. Wraps landing/install.sh.

    The two interesting flags are optional:

      --signing-secret   omit for key-only setup (no node registered)
      --wallet           omit for a fresh off-chain identifier

    Defaults to the public Sirb gateway at https://api.sirb.run unless
    you've configured a different backend via `sirb login` or `--backend`.
    """
    cfg = env_override_or_config()
    backend_url = (backend or cfg.base_url).rstrip("/")
    used_api_key = api_key or cfg.api_key

    if not used_api_key:
        rprint("[red]No API key available.[/red] Run `sirb login` first, or pass `--api-key`.")
        raise typer.Exit(code=1)

    # Pre-flight: friendlier error than letting install.sh fail mid-flight.
    if not shutil.which("docker"):
        rprint("[red]docker not found.[/red] Install Docker Desktop (macOS) or docker-engine (Linux) and retry.")
        raise typer.Exit(code=1)

    rprint("[bold]This will:[/bold]")
    rprint(f"  • run [cyan]{INSTALLER_URL}[/cyan] against [cyan]{backend_url}[/cyan]")
    if signing_secret:
        rprint("  • register a node with the provided signing secret")
    else:
        rprint("  • [yellow]not[/yellow] register a node — key-only setup "
               "(pass --signing-secret to register)")
    if no_sharding:
        rprint("  • opt the node [yellow]out[/yellow] of sharded-model fan-out (MoE etc.)")
    else:
        rprint("  • [cyan]allow[/cyan] this node to participate in sharded-model fan-out")
    rprint(f"  • pull [cyan]{image}[/cyan]")
    # Resource budget: only flagged when at least one value was set
    # explicitly. Auto-detect path stays silent here — install.sh prints
    # what it picked once running.
    budget = []
    if cpu_cores is not None:   budget.append(f"{cpu_cores} CPU cores")
    if ram_gb is not None:      budget.append(f"{ram_gb} GB RAM")
    if gpu_count is not None:   budget.append(f"{gpu_count} GPU(s)")
    if vram_gb is not None:     budget.append(f"{vram_gb} GB VRAM")
    if gpu_percent is not None: budget.append(f"{gpu_percent}% GPU compute")
    if budget:
        rprint(f"  • dedicate [cyan]{' · '.join(budget)}[/cyan] to Sirb")
    else:
        rprint("  • [dim]auto-detect resource budget from this host[/dim]")
    rprint("  • start a Cloudflare Tunnel")
    rprint("  • write state to [cyan]~/.sirb/[/cyan]")
    rprint()

    if not yes and not Confirm.ask("Proceed?", default=True):
        rprint("[dim]aborted[/dim]")
        raise typer.Exit(code=1)

    # Build the command. We pipe the live installer through bash so we
    # always get the latest version — same UX as the homepage's
    # `curl … | bash` recipe, just invoked through the CLI.
    args = ["--backend", backend_url, "--api-key", used_api_key, "--name", name]
    if signing_secret:
        args += ["--signing-secret", signing_secret]
    if wallet:
        args += ["--wallet", wallet]
    if models:
        args += ["--models", models]
    # Sharding flag is passed through to install.sh, which sets the
    # corresponding env on the node-agent container. The node-agent
    # advertises a node-level allow_sharding=false when this is set, so
    # the gateway's MoE executor never selects it as a shard candidate.
    if no_sharding:
        args += ["--no-sharding"]
    if image != DEFAULT_NODE_IMAGE:
        # Only forward --image when the user explicitly overrode it.
        # install.sh has the same default baked in, so passing the same
        # value twice is harmless but noisy in the printed command.
        args += ["--image", image]
    # Resource caps: forward only when explicitly set. install.sh will
    # auto-detect anything not passed through.
    if cpu_cores is not None:   args += ["--cpu-cores",   str(cpu_cores)]
    if ram_gb is not None:      args += ["--ram-gb",      str(ram_gb)]
    if gpu_count is not None:   args += ["--gpu-count",   str(gpu_count)]
    if gpu_percent is not None: args += ["--gpu-percent", str(gpu_percent)]
    if vram_gb is not None:     args += ["--vram-gb",     str(vram_gb)]

    # `curl ... | bash -s -- <args>` — `-s` reads from stdin (the curl
    # body), `--` passes everything after as positional args to the script.
    bash_cmd = f"curl -sSL {INSTALLER_URL} | bash -s -- " + " ".join(_shell_quote(a) for a in args)
    rprint(f"\n[dim]$ {bash_cmd}[/dim]\n")

    proc = subprocess.run(bash_cmd, shell=True)
    # Only nag about CLI updates on a successful deploy — otherwise the
    # user is mid-incident and a sidebar advisory just adds noise.
    if proc.returncode == 0:
        print_cli_update_advisory_if_outdated()
    raise typer.Exit(code=proc.returncode)


# ─────────────────────────── gateway ───────────────────────────────


@app.command("gateway")
def gateway(
    app_name: str = typer.Option(..., "--app-name", "-a",
                                 help="Fly app name (must be globally unique). e.g. sirb-acme."),
    region: str = typer.Option("iad", "--region", "-r",
                               help="Fly region (default: iad / Ashburn). See `fly platform regions`."),
    domain: str | None = typer.Option(None, "--domain", "-d",
                                      help="Custom domain to attach (optional, e.g. api.example.com)."),
    cors_origin: str | None = typer.Option(None, "--cors-origin",
                                           help="Origin to allow in CORS (e.g. https://your-frontend.com)."),
    image: str = typer.Option(
        DEFAULT_GATEWAY_IMAGE, "--image",
        envvar="SIRB_GATEWAY_IMAGE",
        help=(
            f"Gateway image to deploy. Default: {DEFAULT_GATEWAY_IMAGE} — "
            "tracks the latest build from main. Override with a specific "
            "tag (e.g. :v0.2.0) for a reproducible deploy, or pass --build "
            "to build from a local checkout."
        ),
    ),
    build_from_source: bool = typer.Option(
        False, "--build",
        help=(
            "Build the gateway from the local backend/ Dockerfile instead of "
            "pulling a pre-built image from GHCR. Requires the Sirb repo "
            "cloned alongside, and a slower deploy. Use this for forks you've "
            "modified that aren't yet published as an image."
        ),
    ),
    print_only: bool = typer.Option(False, "--print", help="Print the script without running it."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Bootstrap a brand-new Sirb gateway on Fly.io.

    Generates a deterministic deploy script that:
      1. creates the Fly app + Postgres add-on
      2. sets a freshly-generated signing secret + CORS + signup flags
      3. deploys the backend image
      4. runs Alembic migrations
      5. mints the first admin key and prints it (save it!)

    Requires `flyctl` on PATH and an authenticated session
    (`fly auth login`). Operates on the repo at the current working
    directory (must contain `backend/`).
    """
    # Default path: pull the pinned image from GHCR — no checkout required.
    # `--build` flips to local source build, which DOES need the repo.
    backend_dir: str | None = None
    pin_image: str | None = None
    if build_from_source:
        repo_root = _find_repo_root()
        backend_path = repo_root / "backend"
        if not (backend_path / "fly.toml").exists():
            rprint(f"[red]No backend/fly.toml found under {repo_root}.[/red]")
            rprint("--build requires the Sirb repo cloned (git clone https://github.com/ammarwa/SIRB).")
            rprint("Drop --build to deploy the pinned GHCR image instead — no checkout needed.")
            raise typer.Exit(code=1)
        backend_dir = str(backend_path)
    else:
        pin_image = image

    if not print_only:
        if not shutil.which("fly") and not shutil.which("flyctl"):
            rprint("[red]flyctl not found.[/red] Install from https://fly.io/docs/flyctl/install/ then retry.")
            raise typer.Exit(code=1)

    script = _build_gateway_script(
        app_name=app_name,
        region=region,
        domain=domain,
        cors_origin=cors_origin or (f"https://{domain}" if domain else "https://sirb.run"),
        backend_dir=backend_dir,
        image=pin_image,
    )

    rprint("[bold]Gateway deploy script[/bold]")
    rprint("[dim]" + ("─" * 60) + "[/dim]")
    console.print(script, highlight=False)
    rprint("[dim]" + ("─" * 60) + "[/dim]")

    if print_only:
        rprint("[dim]--print: script printed only, not executed[/dim]")
        return

    rprint(f"\n[bold]This will create:[/bold]")
    rprint(f"  • Fly app:      [cyan]{app_name}[/cyan] in [cyan]{region}[/cyan]")
    rprint(f"  • Fly Postgres: [cyan]{app_name}-pg[/cyan] (small tier)")
    rprint(f"  • Secrets:      SIRB_SIGNING_SECRET, SIRB_CORS_ALLOW_ORIGINS, SIRB_PUBLIC_SIGNUP_ENABLED")
    if pin_image:
        rprint(f"  • Gateway:      [cyan]{pin_image}[/cyan] (pinned image from GHCR)")
    else:
        rprint(f"  • Gateway:      built from local [cyan]backend/[/cyan] (--build)")
    if domain:
        rprint(f"  • Cert:         {domain}")
    rprint(f"  • Admin key:    minted at the end (printed once, save it)")
    rprint()
    if not yes and not Confirm.ask("Run this script now?", default=False):
        rprint("[dim]aborted — re-run with --print to copy the script, or --yes to skip the prompt[/dim]")
        raise typer.Exit(code=1)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as fh:
        fh.write(script)
        script_path = fh.name
    os.chmod(script_path, 0o700)

    proc = subprocess.run(["bash", script_path])
    if proc.returncode == 0:
        print_cli_update_advisory_if_outdated()
    raise typer.Exit(code=proc.returncode)


def _build_gateway_script(*, app_name: str, region: str, domain: str | None,
                          cors_origin: str, backend_dir: str | None,
                          image: str | None) -> str:
    """The deploy script body. Generated rather than templated to keep
    everything one file and self-contained — operators can read what
    runs against their Fly account before saying yes.

    `backend_dir` is the local repo's backend/ folder for source-build
    deploys; `image` is a GHCR reference for image-pin deploys. Exactly
    one is set."""
    domain_step = ""
    if domain:
        domain_step = f"""
# 7. (optional) attach the custom hostname; you'll need to add the
#    DNS records the cert request prints.
fly certs add -a "$APP" {_shell_quote(domain)}
fly secrets set -a "$APP" SIRB_PUBLIC_BASE_URL={_shell_quote("https://" + domain)}
"""

    if image:
        # Image-pin path. No local backend/ needed. We still call `fly deploy`
        # so that machines pull the pinned tag — `--image` overrides any
        # build:dockerfile= in fly.toml for this run.
        deploy_step = f"""# 4. Deploy the pinned gateway image from GHCR
fly deploy -a "$APP" --image {_shell_quote(image)}"""
    else:
        deploy_step = f"""# 4. Deploy from the backend directory of the Sirb repo
cd {_shell_quote(backend_dir or "backend")}
fly deploy -a "$APP\""""

    return f"""#!/usr/bin/env bash
set -euo pipefail
APP={_shell_quote(app_name)}
REGION={_shell_quote(region)}
SIGNING_SECRET="$(openssl rand -hex 32)"
echo "Generated signing secret (save it!): $SIGNING_SECRET"
echo

# 1. Create the Fly app
fly apps create "$APP" --org personal || true

# 2. Provision Postgres + attach (sets DATABASE_URL automatically)
fly postgres create --name "${{APP}}-pg" --region "$REGION" --vm-size shared-cpu-1x --initial-cluster-size 1 || true
fly postgres attach "${{APP}}-pg" --app "$APP" || true

# 3. Required secrets
fly secrets set -a "$APP" \\
  SIRB_SIGNING_SECRET="$SIGNING_SECRET" \\
  SIRB_CORS_ALLOW_ORIGINS={_shell_quote('["' + cors_origin + '"]')} \\
  SIRB_PUBLIC_SIGNUP_ENABLED=true \\
  SIRB_RATE_LIMIT_ENABLED=true

{deploy_step}

# 5. Run Alembic migrations against the freshly-attached Postgres
fly ssh console -a "$APP" -C "alembic upgrade head"

# 6. Bootstrap the first admin key — printed once, save it
echo
echo "Bootstrapping the first admin key:"
fly ssh console -a "$APP" -C "python -m app.scripts.admin_key create --admin --name ops"
{domain_step}
echo
echo "Done. Gateway live at https://${{APP}}.fly.dev/"
echo "Save the SIGNING_SECRET and the admin key printed above — they're not stored anywhere else."
"""


# ─────────────────────────── helpers ───────────────────────────────


def _find_repo_root() -> Path:
    """Walk up from cwd looking for backend/fly.toml. Falls back to cwd."""
    cur = Path.cwd().resolve()
    for parent in (cur, *cur.parents):
        if (parent / "backend" / "fly.toml").exists():
            return parent
    return cur


def _shell_quote(s: str) -> str:
    """Cheap shell-quote so the generated script handles spaces / special
    chars in the cors origin / app name without subtle bash injection.
    Stdlib's shlex.quote would do this but we avoid the import."""
    if not s or any(c in s for c in " \"'`$&|;<>()[]{}*?"):
        return "'" + s.replace("'", "'\"'\"'") + "'"
    return s
