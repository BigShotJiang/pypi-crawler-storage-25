"""``sirb wallet`` — generate / inspect off-chain wallet identifiers.

The node-agent's identity is a 0x-prefixed 20-byte address. For the
testnet phase, this is just a random identifier — no private key is
generated or stored, and the gateway doesn't validate ownership against
chain state. That's exactly enough to participate as a contributor and
build reputation across restarts.

For **on-chain rewards** you need a real Ethereum keypair (a private
key you control). Use a real wallet provider — MetaMask, hardware
wallet, `eth-account` if you script it — and pass the resulting
address to ``sirb deploy node --wallet 0x…``. We deliberately do NOT
manage private keys: the CLI should never become a custodial wallet.
"""

from __future__ import annotations

import json
import secrets
import stat
import os
from datetime import datetime, timezone
from pathlib import Path

import typer
from rich import print as rprint

app = typer.Typer(
    invoke_without_command=False,
    no_args_is_help=True,
    help="Generate or inspect off-chain node-agent wallet identifiers.",
)


def _wallet_path() -> Path:
    """Match install.sh: ~/.sirb/wallet.json, mode 0600."""
    return Path.home() / ".sirb" / "wallet.json"


@app.command("new")
def new(
    save: bool = typer.Option(
        True, "--save/--no-save",
        help="Persist to ~/.sirb/wallet.json (default). --no-save prints to stdout only.",
    ),
    force: bool = typer.Option(
        False, "--force", "-f",
        help="Overwrite an existing ~/.sirb/wallet.json without prompting.",
    ),
) -> None:
    """Generate a new off-chain wallet identifier (0x + 40 hex chars).

    For testnet/off-chain participation only — no private key is stored,
    so this address cannot claim on-chain rewards. For real rewards,
    bring your own Ethereum wallet and pass it to
    `sirb deploy node --wallet 0x…`.
    """
    addr = "0x" + secrets.token_hex(20)
    payload = {
        "address": addr,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "note": (
            "Auto-generated off-chain identifier. No private key stored. "
            "For on-chain rewards, replace with an Ethereum address you control."
        ),
    }

    if save:
        path = _wallet_path()
        if path.exists() and not force:
            rprint(f"[yellow]wallet file already exists at {path}[/yellow]")
            rprint("Pass [bold]--force[/bold] to overwrite, or use [bold]--no-save[/bold] to print without writing.")
            raise typer.Exit(code=1)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2) + "\n")
        # 0600 so other users on this machine can't read the file
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        except (OSError, NotImplementedError):
            pass
        rprint(f"[green]wallet:[/green] [bold]{addr}[/bold]")
        rprint(f"[dim]saved to {path} (mode 0600)[/dim]")
    else:
        rprint(f"[green]wallet:[/green] [bold]{addr}[/bold]")
        rprint("[dim]not saved (--no-save)[/dim]")

    rprint(
        "\n[dim]Off-chain only. For on-chain rewards bring an Ethereum wallet you control "
        "(MetaMask / hardware wallet / eth-account) and pass that address to "
        "`sirb deploy node --wallet 0x…`.[/dim]"
    )


@app.command("show")
def show() -> None:
    """Print the wallet currently saved at ~/.sirb/wallet.json."""
    path = _wallet_path()
    if not path.exists():
        rprint(f"[yellow]no wallet at {path}[/yellow] — run `sirb wallet new` to create one")
        raise typer.Exit(code=1)
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        rprint(f"[red]could not read wallet file:[/red] {e}")
        raise typer.Exit(code=1)
    rprint(f"[green]address:[/green]  [bold]{data.get('address', '?')}[/bold]")
    if data.get("created_at"):
        rprint(f"[dim]created:  {data['created_at']}[/dim]")
    if data.get("note"):
        rprint(f"[dim]note:     {data['note']}[/dim]")
