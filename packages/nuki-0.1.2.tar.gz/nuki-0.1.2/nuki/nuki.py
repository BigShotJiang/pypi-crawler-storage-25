import hashlib
import random
import re
import time
import unicodedata as ud
from collections.abc import Iterator
from contextlib import contextmanager
from loguru import logger
from pathlib import Path
from typing import Callable
from urllib.parse import urljoin

import pandas as pd
from camoufox.sync_api import Camoufox
from patchright.sync_api import sync_playwright, Page as PatchrightPage, ElementHandle
from playwright.sync_api import Page as PlaywrightPage
from selectolax.lexbor import LexborHTMLParser, LexborNode


Page = PatchrightPage | PlaywrightPage

class _NPlayBase:
    def first(self, elems: list[ElementHandle]) -> ElementHandle | None:
        return elems[0] if elems else None

    def re_filter(self, pattern: str, elems: list[ElementHandle]) -> list[ElementHandle]:
        prog = re.compile(pattern)
        return [e for e in elems if (t := e.text_content()) and prog.search(ud.normalize('NFKC', t.strip()))]

class _NSelectBase:
    def first(self, nodes: list[LexborNode]) -> LexborNode | None:
        return nodes[0] if nodes else None

    def re_filter(self, pattern: str, nodes: list[LexborNode]) -> list[LexborNode]:
        prog = re.compile(pattern)
        return [n for n in nodes if (t := n.text(strip=True)) and prog.search(ud.normalize('NFKC', t))]

def npage(page: Page) -> NPage:
    return NPage(page)

def nelement(elem: ElementHandle | None) -> NElement:
    return NElement(elem)

class NPage(_NPlayBase):
    def __init__(self, page: Page) -> None:
        self._page = page

    def ss(self, selector: str) -> list[NElement]:
        elems = self._page.query_selector_all(selector)
        return [nelement(e) for e in elems]

    def s(self, selector: str) -> NElement:
        elem = self._page.query_selector(selector)
        return nelement(elem)

    def ss_re(self, selector: str, pattern: str) -> list[NElement]:
        elems = self.re_filter(pattern, self._page.query_selector_all(selector))
        return [nelement(e) for e in elems]

    def s_re(self, selector: str, pattern: str) -> NElement:
        elem = self.first(self.re_filter(pattern, self._page.query_selector_all(selector)))
        return nelement(elem)

    def goto(self, url: str | None, try_cnt: int = 3, wait_range: tuple[float, float] = (3, 5)) -> bool:
        if not url:
            return False
        for i in range(try_cnt):
            try:
                if self._page.goto(url) is not None:
                    return True
                else:
                    reason = "response is None"
            except Exception as e:
                reason = f"{type(e).__name__}: {e}"
            logger.warning(f"[goto] {url} ({i+1}/{try_cnt}) {reason}")
            if i + 1 < try_cnt:
                time.sleep(random.uniform(*wait_range))
        logger.error(f"[goto] giving up: {url}")
        return False

    def wait(self, selector: str, timeout: int = 15000) -> NElement:
        try:
            elem = self._page.wait_for_selector(selector, timeout=timeout)
            return nelement(elem)
        except Exception as e:
            logger.warning(f"[wait] {type(e).__name__}: {e} | selector={selector!r} | url={self._page.url}")
            return nelement(None)

    def abs_url(self, href: str | None) -> str | None:
        if not href:
            return None
        return urljoin(self._page.url, href)

class NElement(_NPlayBase):
    def __init__(self, elem: ElementHandle | None) -> None:
        self._elem = elem

    def unwrap(self) -> ElementHandle | None:
        return self._elem

    def ss(self, selector: str) -> list[NElement]:
        elems = self._elem.query_selector_all(selector) if self._elem else []
        return [nelement(e) for e in elems]

    def s(self, selector: str) -> NElement:
        elem = self._elem.query_selector(selector) if self._elem else None
        return nelement(elem)

    def ss_re(self, selector: str, pattern: str) -> list[NElement]:
        elems = self.re_filter(pattern, self._elem.query_selector_all(selector)) if self._elem else []
        return [nelement(e) for e in elems]

    def s_re(self, selector: str, pattern: str) -> NElement:
        elem = self.first(self.re_filter(pattern, self._elem.query_selector_all(selector))) if self._elem else None
        return nelement(elem)

    def next(self) -> NElement:
        if self._elem is None:
            return nelement(None)
        try:
            elem = self._elem.evaluate_handle('el => el.nextElementSibling').as_element()
            return nelement(elem)
        except Exception as e:
            logger.error(f"[next] {self._elem} {type(e).__name__}: {e}")
            return nelement(None)

    def text_content(self) -> str | None:
        if self._elem is None:
            return None
        return t.strip() if (t := self._elem.text_content()) else None

    def inner_text(self) -> str | None:
        if self._elem is None:
            return None
        return t.strip() if (t := self._elem.inner_text()) else None

    def attr(self, attr_name: str) -> str | None:
        if self._elem is None:
            return None
        return a.strip() if (a := self._elem.get_attribute(attr_name)) else None

    def url(self) -> str | None:
        if not (href := self.attr('href')):
            return None
        if re.search(r'(?i)^(?:#|javascript:|mailto:|tel:|data:)', href):
            return None
        return href

def parse_html(path: Path | str) -> LexborHTMLParser | None:
    try:
        return LexborHTMLParser(Path(path).read_text(encoding='utf-8'))
    except Exception as e:
        logger.error(f"[parse_html] {path} {type(e).__name__}: {e}")
        return None

def nparser(parser: LexborHTMLParser) -> NParser:
    return NParser(parser)

def nnode(node: LexborNode | None) -> NNode:
    return NNode(node)

class NParser(_NSelectBase):
    def __init__(self, parser: LexborHTMLParser) -> None:
        self._parser = parser

    def ss(self, selector: str) -> list[NNode]:
        nodes = self._parser.css(selector)
        return [nnode(n) for n in nodes]

    def s(self, selector: str) -> NNode:
        node = self._parser.css_first(selector)
        return nnode(node)

    def ss_re(self, selector: str, pattern: str) -> list[NNode]:
        nodes = self.re_filter(pattern, self._parser.css(selector))
        return [nnode(n) for n in nodes]

    def s_re(self, selector: str, pattern: str) -> NNode:
        node = self.first(self.re_filter(pattern, self._parser.css(selector)))
        return nnode(node)

class NNode(_NSelectBase):
    def __init__(self, node: LexborNode | None) -> None:
        self._node = node

    def unwrap(self) -> LexborNode | None:
        return self._node

    def ss(self, selector: str) -> list[NNode]:
        nodes = self._node.css(selector) if self._node else []
        return [nnode(n) for n in nodes]

    def s(self, selector: str) -> NNode:
        node = self._node.css_first(selector) if self._node else None
        return nnode(node)

    def ss_re(self, selector: str, pattern: str) -> list[NNode]:
        nodes = self.re_filter(pattern, self._node.css(selector)) if self._node else []
        return [nnode(n) for n in nodes]

    def s_re(self, selector: str, pattern: str) -> NNode:
        node = self.first(self.re_filter(pattern, self._node.css(selector))) if self._node else None
        return nnode(node)

    def next(self, selector: str) -> NNode:
        if self._node is None:
            return nnode(None)
        cur = self._node.next
        while cur is not None:
            if cur.is_element_node and cur.css_matches(selector):
                return nnode(cur)
            cur = cur.next
        return nnode(None)

    def text(self) -> str | None:
        if self._node is None:
            return None
        return t if (t := self._node.text(strip=True)) else None

    def attr(self, attr_name: str) -> str | None:
        if self._node is None:
            return None
        return a.strip() if (a := self._node.attributes.get(attr_name)) else None

def from_here(file: str) -> Callable[[str], Path]:
    base = Path(file).resolve().parent
    return lambda path: base / path

def random_sleep(a: float, b: float) -> None:
    time.sleep(random.uniform(a, b))

def append_csv(path: Path | str, row: dict) -> None:
    p = Path(path)
    try:
        pd.DataFrame([row]).to_csv(
            p,
            mode='a',
            index=False,
            header=True if not p.exists() else p.stat().st_size == 0,
            encoding='utf-8-sig',
        )
    except Exception as e:
        logger.error(f"[append_csv] {path} {row} {type(e).__name__}: {e}")

def write_parquet(path: Path | str, rows: list[dict]) -> None:
    try:
        pd.DataFrame(rows).to_parquet(
            Path(path),
            index=False,
        )
    except Exception as e:
        logger.error(f"[write_parquet] {path} {type(e).__name__}: {e}")

def hash_name(key: str) -> str:
    return hashlib.md5(key.encode()).hexdigest()

def save_html(filepath: Path, html: str) -> bool:
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(html, encoding="utf-8", errors="replace")
        return True
    except Exception as e:
        logger.error(f"[save_html] {filepath} {type(e).__name__}: {e}")
        return False

def add_log_file(path: Path | str) -> None:
    logger.add(Path(path), level="WARNING", encoding="utf-8")

@contextmanager
def patchright_page(user_data_dir: str | Path) -> Iterator[Page]:
    with sync_playwright() as pw:
        with pw.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),
            channel='chrome',
            headless=False,
            no_viewport=True,
        ) as context:
            page = context.new_page()
            yield page

@contextmanager
def camoufox_page(locale: str | list[str] = 'ja-JP,ja') -> Iterator[Page]:
    with Camoufox(
        headless=False,
        humanize=True,
        locale=locale,
    ) as browser:
        page = browser.new_page()
        yield page
