# nuki

## Overview - 概要

nuki is a scraping utility library built on Patchright and selectolax.
nuki(抜き)はPatchrightとselectolaxをベースにしたスクレイピングユーティリティライブラリです。


## Requirements - 必要条件

- Python 3.12 or higher
- Libraries: patchright, selectolax, pandas, camoufox（自動インストール）
- `write_parquet` を使う場合は pandas の Parquet エンジンとして `pyarrow`（または `fastparquet`）が必要です。
- Browser binaries（別途インストールが必要）

## Installation - インストール

### pip

```
pip install nuki
```

### uv (推奨)

```
uv add nuki
```

ブラウザバイナリを別途インストールしてください。

### Patchright（Chromium）

#### pip

```
python -m patchright install chromium
```

#### uv (推奨)

```
uv run patchright install chromium
```

### Camoufox（Firefox）

#### pip

```
camoufox fetch
```

#### uv (推奨)

```
uv run camoufox fetch
```

## メソッド

- **`patchright_page(user_data_dir)`** … コンテキストマネージャ。Patchright（Chrome チャネル・永続コンテキスト）で `Page` を開き、`with` ブロック内に渡す。  
  `user_data_dir` は `'C:\Users\あなた\...\User Data'` のような文字列（`chrome://version/` で確認可）。

- **`camoufox_page(locale=...)`** … 同様に Camoufox（Firefox）で `Page` を開く。bot 検知が厳しいサイト向け。  
  _例:_ `with camoufox_page(locale='en-US,en') as page:`  
  ロケールのデフォルトは `'ja-JP,ja'`。

## Basic Usage - 基本的な使い方

```python
from nuki import *

fh = from_here(__file__)
add_log_file(fh('log/scraping.log'))

user_data_dir = r'C:\Users\あなたのユーザ名\AppData\Local\Google\Chrome\User Data'
with patchright_page(user_data_dir) as page:
    p = npage(page)
    p.goto('https://www.foobarbaz1.jp')

    pref_urls = [p.abs_url(e.url()) for e in p.ss('li.item > ul > li > a')]

    classroom_urls = []
    for i, url in enumerate(pref_urls, 1):
        print(f'{i}/{len(pref_urls)} pref_urls')
        if not p.goto(url):
            continue
        random_sleep(1, 2)
        links = [p.abs_url(e.url()) for e in p.ss('.school-area h4 a')]
        classroom_urls.extend(links)

    for i, url in enumerate(classroom_urls, 1):
        print(f'{i}/{len(classroom_urls)} classroom_urls')
        if not p.goto(url):
            continue
        random_sleep(1, 2)
        append_csv(fh('csv/out.csv'), {
            'URL': page.url,
            '教室名': p.s('h1 .text01').text_content(),
            '住所': p.s('.item .mapText').text_content(),
            '電話番号': p.s('.item .phoneNumber').text_content(),
            'HP': p.s_re('th', 'ホームページ').next().s('a').url(),
        })
```

## Save HTML while scraping - スクレイピングしながらHTMLを保存する

```python
from nuki import *

fh = from_here(__file__)
add_log_file(fh('log/scraping.log'))

with camoufox_page() as page:
    ctx = {}
    p = npage(page)
    p.goto('https://www.foobarbaz1.jp')

    ctx['アイテムURLs'] = [p.abs_url(e.url()) for e in p.ss('ul.items > li > a')]

    for i, url in enumerate(ctx['アイテムURLs'], 1):
        print(f"{i}/{len(ctx['アイテムURLs'])} アイテムURLs")
        if not p.goto(url):
            continue
        random_sleep(1, 2)
        if p.wait('#logo', timeout=10000).unwrap() is None:
            continue
        file_name = f'{hash_name(url)}.html'
        if not save_html(fh('html') / file_name, page.content()):
            continue
        append_csv(fh('outurlhtml.csv'), {
            'URL': url,
            'HTML': file_name,
        })
```

## Scrape from local HTML files - 保存済みHTMLからスクレイピングしてParquetに出力する

```python
import pandas as pd

from nuki import *

fh = from_here(__file__)
add_log_file(fh('log/scraping.log'))

df = pd.read_csv(fh('outurlhtml.csv'))
results = []
for i, (url, path) in enumerate(zip(df['URL'], df['HTML']), 1):
    print(i)
    if not (parser := parse_html(fh('html') / path)):
        continue
    p = nparser(parser)
    results.append({
        'URL': url,
        '教室名': p.s('h1 .text02').text(),
        '住所': p.s('.item .mapText').text(),
        '所在地': p.s_re('dt', r'所在地').next('dd').text(),
    })
write_parquet(fh('outhtml.parquet'), results)
```

## License - ライセンス

[MIT](./LICENSE)
