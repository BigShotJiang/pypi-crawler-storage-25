import os
import tempfile
import unittest
import uuid as pyuuid
from unittest.mock import patch

import ddt

from plexus.pulse.common.utils.flowutils import FlowContext


@ddt.ddt
class FlowUtilsTest(unittest.TestCase):

    def test_flow_context(self):
        with tempfile.TemporaryDirectory(delete=True) as temp_dir:
            with patch.dict(os.environ,
                            {
                                "PULSE_FLOW_WORKSPACE_ROOT_DIR": temp_dir,
                                "PULSE_FLOW_RUN_ID": "01234567-89ab-cdef-0123-456789abcdef",
                            },
                            clear=True):
                context = (
                    FlowContext()
                    .add_dataset_ref(pyuuid.UUID("01234567-89ab-cdef-0123-456789abcdef"), "one_dataset")
                    .add_dataset_ref(pyuuid.UUID("89abcdef-0123-4567-89ab-cdef01234567"), "another_dataset")
                    .add_dataset_ref(pyuuid.UUID("00000000-0000-0000-0000-000000000000"), "zero_dataset")
                )

                self.assertEqual(context.count_dataset_ref(), 3)

                one_dataset, another_dataset, zero_dataset = context.list_dataset_refs()

                self.assertEqual(one_dataset.dataset_uuid, pyuuid.UUID("01234567-89ab-cdef-0123-456789abcdef"))
                self.assertEqual(another_dataset.dataset_uuid, pyuuid.UUID("89abcdef-0123-4567-89ab-cdef01234567"))
                self.assertEqual(zero_dataset.dataset_uuid, pyuuid.UUID("00000000-0000-0000-0000-000000000000"))

            # This is the same flow context file as above, but we are creating a new `FlowContext` instance
            # via explicit file path which is deducted from the mocked environment variables
            context = FlowContext(file_path=f"{temp_dir}/01234567-89ab-cdef-0123-456789abcdef/flow_context.db")

            self.assertEqual(context.count_dataset_ref(), 3)

            one_dataset, another_dataset, zero_dataset = context.list_dataset_refs()

            self.assertEqual(one_dataset.dataset_uuid, pyuuid.UUID("01234567-89ab-cdef-0123-456789abcdef"))
            self.assertEqual(another_dataset.dataset_uuid, pyuuid.UUID("89abcdef-0123-4567-89ab-cdef01234567"))
            self.assertEqual(zero_dataset.dataset_uuid, pyuuid.UUID("00000000-0000-0000-0000-000000000000"))
