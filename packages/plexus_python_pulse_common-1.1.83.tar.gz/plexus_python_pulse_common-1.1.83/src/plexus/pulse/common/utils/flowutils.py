import contextlib
import enum
import os
import pathlib
import threading
import typing
import uuid as py_uuid
from collections.abc import Generator
from typing import Self

import pydantic as pdt
import requests
import sqlalchemy as sa
import sqlalchemy.dialects.sqlite as sa_sqlite
import sqlalchemy.orm as sa_orm
from plexus.common.utils.dbutils import ConnectionMaker
from plexus.common.utils.funcutils import Chainable
from plexus.common.utils.funcutils import chainable, singleton
from plexus.common.utils.jsonutils import JsonObject
from plexus.common.utils.retry import retry
from sqlmodel import Field

from plexus.pulse.common.utils.ormutils import SQLiteUUID, SequenceModelMixinProtocol
from plexus.pulse.common.utils.ormutils import clone_sequence_model_instance, make_base_model, make_sequence_model_mixin

__all__ = [
    "flow_workspace_root_path",
    "current_flow_run_id",
    "current_flow_workspace_root_path",
    "FlowStageEnum",
    "current_flow_stage",
    "stage_can_resolve_dataset_ref",
    "make_dataset_ref_model_mixin",
    "DatasetRef",
    "DatasetRefTable",
    "current_flow_context_file_path",
    "FlowContext",
    "flow_context",
    "flow_api_url",
    "resolve_dataset_ref",
    "resolve_dataset_storage_location",
    "resolve",
]

flow_stage_env = "PULSE_FLOW_STAGE"
flow_run_id_env = "PULSE_FLOW_RUN_ID"
flow_workspace_root_dir_env = "PULSE_FLOW_WORKSPACE_ROOT_DIR"
flow_api_url_env = "PULSE_FLOW_API_URL"


def flow_workspace_root_path() -> pathlib.Path:
    value = os.environ.get(flow_workspace_root_dir_env)
    if value is None:
        raise ValueError(f"Missing required environment variable '{flow_workspace_root_dir_env}'")
    return pathlib.Path(value).absolute()


def current_flow_run_id() -> str:
    value = os.environ.get(flow_run_id_env)
    if value is None:
        raise ValueError(f"Missing required environment variable '{flow_run_id_env}'")
    return value


def current_flow_workspace_root_path() -> pathlib.Path:
    return flow_workspace_root_path() / current_flow_run_id()


class FlowStageEnum(enum.Enum):
    Preprocessing = "preprocessing"
    Annotation = "annotation"
    Curation = "curation"
    Training = "training"


def current_flow_stage() -> FlowStageEnum:
    value = os.environ.get(flow_stage_env)
    if value is None:
        raise ValueError(f"Missing required environment variable '{flow_stage_env}'")
    for stage in list(FlowStageEnum):
        if value == stage.value:
            return stage
    raise ValueError(f"Illegal '{flow_stage_env}' value '{value}'")


def stage_can_resolve_dataset_ref(stage: FlowStageEnum | None = None) -> bool:
    if stage is None:
        stage = current_flow_stage()
    return stage in {FlowStageEnum.Curation}


def make_dataset_ref_model_mixin() -> type[pdt.BaseModel]:
    class ModelMixin(pdt.BaseModel):
        dataset_uuid: py_uuid.UUID = Field(
            sa_column=sa.Column(SQLiteUUID(), nullable=False),
            description="UUID of the dataset",
        )
        dataset_name: str = Field(
            sa_column=sa.Column(sa_sqlite.VARCHAR(128), nullable=False),
            description="Name of the dataset",
        )
        dataset_props: JsonObject | None = Field(
            sa_column=sa.Column(sa_sqlite.JSON),
            default=None,
            description="Additional properties stored as JSON",
            schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
        )

    return ModelMixin


BaseModel = make_base_model()


class DatasetRef(BaseModel, make_dataset_ref_model_mixin()):
    pass


class DatasetRefTable(DatasetRef, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "dataset_ref"


if typing.TYPE_CHECKING:
    class DatasetRef(BaseModel):
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        dataset_name: sa_orm.Mapped[str] = ...
        dataset_props: sa_orm.Mapped[JsonObject | None] = ...


    class DatasetRefTable(DatasetRef, SequenceModelMixinProtocol):
        pass


def current_flow_context_file_path() -> pathlib.Path:
    return current_flow_workspace_root_path() / "flow_context.db"


class FlowContext(object):
    def __init__(
        self,
        *,
        file_path: str | os.PathLike[str] | None = None,
        fail_if_exists: bool = False,
    ):
        self.file_path = pathlib.Path(file_path or current_flow_context_file_path())
        if fail_if_exists and self.file_path.exists():
            raise FileExistsError(f"flow context file '{self.file_path}' already exists")
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        self.conn_maker = ConnectionMaker.from_url(f"sqlite:///{self.file_path.absolute()}",
                                                   engine_opts=dict(connect_args={"check_same_thread": False}))

        self.thread_lock = threading.Lock()

        BaseModel.metadata.create_all(self.conn_maker.engine)

    @contextlib.contextmanager
    def make_session(self) -> Generator[sa_orm.Session, None, None]:
        with self.thread_lock:
            with self.conn_maker.make_session(expire_on_commit=False) as session:
                try:
                    yield session
                    session.commit()
                except Exception:
                    session.rollback()
                    raise

    def count_dataset_ref(self) -> int:
        with self.make_session() as session:
            return session.query(DatasetRefTable).count()

    def list_dataset_refs(self) -> list[DatasetRefTable]:
        with self.make_session() as session:
            return session.query(DatasetRefTable).all()

    def query_dataset_ref(
        self,
        dataset_uuid: py_uuid.UUID | None = None,
        dataset_name: str | None = None,
    ) -> Chainable[Self, DatasetRefTable | None]:
        if dataset_uuid is None and dataset_name is None:
            raise ValueError("either 'dataset_uuid' or 'dataset_name' is required")

        with self.make_session() as session:
            query_stmt = session.query(DatasetRefTable)
            if dataset_uuid is not None:
                query_stmt = query_stmt.filter(DatasetRefTable.dataset_uuid == dataset_uuid)
            if dataset_name is not None:
                query_stmt = query_stmt.filter(DatasetRefTable.dataset_name == dataset_name)
            db_dataset_ref = query_stmt.one_or_none()

            return chainable(self, db_dataset_ref)

    def add_dataset_ref(
        self,
        dataset_uuid: py_uuid.UUID,
        dataset_name: str,
        dataset_props: JsonObject | None = None,
    ) -> Chainable[Self, DatasetRefTable]:
        with self.make_session() as session:
            dataset_ref = DatasetRef(dataset_uuid=dataset_uuid, dataset_name=dataset_name, dataset_props=dataset_props)
            db_dataset_ref = clone_sequence_model_instance(DatasetRefTable, dataset_ref)
            session.add(db_dataset_ref)
            session.commit()

            return chainable(self, db_dataset_ref)


@singleton
def flow_context() -> FlowContext:
    return FlowContext()


def flow_api_url() -> str:
    value = os.environ.get(flow_api_url_env)
    if value is None:
        raise ValueError(f"Missing required environment variable '{flow_api_url_env}'")
    return value


@retry(wait=10, retrials=3)
def fetch_dataset_ref(
    dataset_uuid: py_uuid.UUID | None = None,
    dataset_name: str | None = None,
) -> DatasetRef | None:
    response = requests.get(f"{flow_api_url()}/pulse_demeter/dataset_public/query_dataset",
                            headers={"accept": "application/json"},
                            params={
                                "dataset_uuid": str(dataset_uuid),
                                "dataset_name": dataset_name,
                            })
    response.raise_for_status()

    response_data = response.json()

    try:
        uuid = py_uuid.UUID(response_data["dataset"]["uuid"])
        name = response_data["dataset"]["name"]
        props = response_data["dataset"].get("props", None)
        return DatasetRef(dataset_uuid=uuid, dataset_name=name, dataset_props=props)
    except KeyError:
        return None


def resolve_dataset_ref(
    dataset_uuid: py_uuid.UUID | None = None,
    dataset_name: str | None = None,
    *,
    context: FlowContext | None = None,
) -> DatasetRefTable:
    if context is None:
        context = flow_context()

    if dataset_uuid is None and dataset_name is None:
        raise ValueError("either 'dataset_uuid' or 'dataset_name' is required")

    _, db_dataset_ref = context.query_dataset_ref(dataset_uuid=dataset_uuid, dataset_name=dataset_name)
    if db_dataset_ref is None:
        if not stage_can_resolve_dataset_ref():
            # In some stages, the dataset ref should have been resolved and stored in the flow context.
            # If not found, it's an error.
            raise ValueError(f"cannot resolve dataset ref at flow stage '{current_flow_stage()}'")

        dataset_ref = fetch_dataset_ref(dataset_uuid=dataset_uuid, dataset_name=dataset_name)
        if dataset_ref is None:
            raise ValueError(f"cannot found dataset with uuid '{str(dataset_uuid)}' or name '{dataset_name}'")

        _, db_dataset_ref = context.add_dataset_ref(dataset_ref.dataset_uuid,
                                                    dataset_ref.dataset_name,
                                                    dataset_ref.dataset_props)

    return db_dataset_ref


def resolve_dataset_storage_location(
    dataset_uuid: str | py_uuid.UUID | None = None,
    dataset_name: str | None = None,
    *,
    context: FlowContext | None = None,
) -> pathlib.Path:
    if isinstance(dataset_uuid, str):
        return resolve_dataset_storage_location(py_uuid.UUID(dataset_uuid), dataset_name, context=context)

    db_dataset_ref = resolve_dataset_ref(dataset_uuid, dataset_name, context=context)
    if "storage_location" in (db_dataset_ref.dataset_props or {}):
        return pathlib.Path(db_dataset_ref.dataset_props["storage_location"]).absolute()

    return current_flow_workspace_root_path() / "datasets" / str(db_dataset_ref.dataset_uuid)


resolve = resolve_dataset_storage_location
