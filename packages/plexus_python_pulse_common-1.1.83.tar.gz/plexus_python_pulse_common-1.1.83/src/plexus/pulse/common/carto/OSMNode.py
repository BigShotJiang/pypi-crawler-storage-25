from plexus.common.utils.strutils import repr_data

from plexus.pulse.common.carto.OSMTags import OSMTags
from plexus.pulse.common.utils.gisutils import Coord


class OSMNode(object):
    """
    Represents node in OSM
    """

    def __init__(self, node_id: int, coord: Coord, tags: OSMTags):
        """
        Creates an OSM node from the given ID, coordinate, and tags.

        :param node_id: Node ID.
        :param coord: Node coordinate.
        :param tags: Node tags.
        """
        self.node_id = node_id
        self.coord = coord
        self.tags = tags

    def __str__(self):
        return repr_data(self)
