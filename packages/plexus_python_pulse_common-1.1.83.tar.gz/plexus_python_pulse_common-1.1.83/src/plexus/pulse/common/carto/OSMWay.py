from plexus.common.utils.strutils import repr_data

from plexus.pulse.common.carto.OSMTags import OSMTags


class OSMWay(object):
    """
    Represents way in OSM
    """

    def __init__(self, way_id: int, node_ids: list[int], tags: OSMTags):
        """
        Creates an OSM way from the given ID, node IDs, and tags.

        :param way_id: Way ID.
        :param node_ids: Node IDs that make up the way.
        :param tags: Way tags.
        """
        self.way_id = way_id
        self.node_ids = node_ids
        self.tags = tags

    def __str__(self):
        return repr_data(self)
