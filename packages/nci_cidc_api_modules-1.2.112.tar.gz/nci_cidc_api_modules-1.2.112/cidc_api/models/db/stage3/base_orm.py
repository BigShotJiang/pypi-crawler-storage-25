from sqlalchemy_mixins import SerializeMixin, ReprMixin
from cidc_api.config.db import Stage3BaseModel, ModelMixin
from sqlalchemy.orm import Mapped


class BaseORM(Stage3BaseModel, ModelMixin, ReprMixin, SerializeMixin):
    __abstract__ = True
    __repr__ = ReprMixin.__repr__

    trial_id: Mapped[str]
    version: Mapped[str]
