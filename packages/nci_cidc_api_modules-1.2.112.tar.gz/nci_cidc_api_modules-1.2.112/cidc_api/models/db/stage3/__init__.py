from .program_orm import ProgramORM

__all__ = [
    "ProgramORM",
]

all_models = [globals()[cls_name] for cls_name in __all__]
