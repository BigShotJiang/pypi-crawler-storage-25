from __future__ import annotations
from typing import List
from datetime import datetime

from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import JSON

from cidc_api.models.db.stage3.base_orm import BaseORM


class ProgramORM(BaseORM):
    __tablename__ = "program"
    __repr_attrs__ = ["program_name", "program_short_name"]
    __data_category__ = "program"

    program_name: Mapped[str]
    program_short_name: Mapped[str] = mapped_column(primary_key=True)
