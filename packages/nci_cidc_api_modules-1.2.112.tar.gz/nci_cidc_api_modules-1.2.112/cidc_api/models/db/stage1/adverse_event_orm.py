from __future__ import annotations
from pydantic import NonNegativeInt
from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.ctcae import SeverityGrade, SeverityGradeSystem, SeverityGradeSystemVersion
from cidc_api.code_systems.other import SystemOrganClass
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.models.types import (
    YN,
    YNU,
    AttributionCause,
    AttributionLikelihood,
)


class AdverseEventORM(BaseORM):
    __tablename__ = "adverse_event"
    __repr_attrs__ = ["adverse_event_id", "participant_id", "event_term"]
    __data_category__ = "adverse_event"
    __exclude_during_promotion__ = ["adverse_event_id", "participant_id", "treatment_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    adverse_event_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))
    treatment_id: Mapped[int | None] = mapped_column(ForeignKey("stage1.treatment.treatment_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    event_term: Mapped[str | None]
    event_code: Mapped[str | None]
    severity_grade_system: Mapped[SeverityGradeSystem]
    severity_grade_system_version: Mapped[SeverityGradeSystemVersion]
    severity_grade: Mapped[SeverityGrade]
    event_other_specify: Mapped[str | None]
    system_organ_class: Mapped[SystemOrganClass | None]
    discontinuation_due_to_event: Mapped[YN]
    days_to_onset_of_event: Mapped[NonNegativeInt]
    days_to_resolution_of_event: Mapped[NonNegativeInt | None]
    serious_adverse_event: Mapped[YNU]
    dose_limiting_toxicity: Mapped[YNU | None]
    attribution_cause: Mapped[AttributionCause]
    attribution_likelihood: Mapped[AttributionLikelihood]
    treatment_description: Mapped[str | None]
    individual_therapy: Mapped[str | None]

    trial: Mapped[TrialORM] = relationship(back_populates="adverse_events", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="adverse_events", cascade="all, delete")
    treatment: Mapped[TreatmentORM] = relationship(back_populates="adverse_events", cascade="all, delete")
