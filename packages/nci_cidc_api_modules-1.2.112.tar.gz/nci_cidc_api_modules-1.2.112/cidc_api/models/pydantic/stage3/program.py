from datetime import datetime
from pydantic import BeforeValidator, PlainSerializer
from typing import List, Annotated

from cidc_api.models.pydantic.base import Base


class Program(Base):
    __data_category__ = "program"
    __cardinality__ = None

    program_name: str
    program_short_name: str
