from __future__ import annotations

import shutil
import os, tarfile, io, json

from os import makedirs, remove
from functools import lru_cache
from datetime import datetime as dt
from os.path import exists, expanduser, join, isdir, dirname, isfile
from ymvas.utils.errors import YException
from ymvas.utils.files import get_yaml
from ymvas.utils.system import (
    get_pkg_localtion,
    get_global_config
)

class GitServer:
    # BASE CONFIG
    CONFIG:dict = get_global_config()

    # SERVER BASE DATA
    HOME            : str = str(CONFIG.get(
        "ymvas-server-home",
        expanduser("~/")
    ))

    AUTHORIZED_KEYS : str = join(
        HOME,
        '.ssh/authorized_keys'
    )
    REPOSITORIES    : str = str(CONFIG.get(
        "ymvas-server-repos-base",
        join(HOME,"repositories")
    ))




    def __init__(self) -> None:

        pass


    def exists(self,user:str,name:str) -> bool:
        return exists(
            join( self.REPOSITORIES , user, f"{name}.git" )
        )

    def setup(self, user:str, sshkey:str ):
        # this will create ssh record in the authorized_keys
        auth_keys = expanduser(self.AUTHORIZED_KEYS)
        sshkey    = expanduser(sshkey)

        if not exists(sshkey):
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        if not exists(sshkey):
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        content = None
        with open(sshkey) as f:
            content = f.read().strip()

        # in case of some strange file
        if content is None or content == '':
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        src = get_pkg_localtion()
        srv = join(src,'server.py')

        srv_exec = f"{srv} user='{user}'"

        full_command = (
            f"command=\"{srv_exec}\","
            f"no-port-forwarding,"
            f"no-X11-forwarding,"
            "no-agent-forwarding,"
            f"no-pty {content}"
        )

        if exists(auth_keys):
            with open(auth_keys) as f:
                for l in f:
                    if l.strip() == full_command:
                        print('access was already added!')
                        return

            with open(auth_keys,"a") as f:
                f.write(full_command + "\n")
        else:
            with open(auth_keys,"w") as f:
                f.write(full_command + "\n")

        print('succefully added access!')

    @lru_cache(maxsize=2)
    def _get_rep_access(self,repo:str) -> dict:
        fpath = join( self.REPOSITORIES , repo + '.git' )
        yconf = join( fpath , 'ymconf.yaml' )

        if not exists(yconf):
            return {}

        data = get_yaml(yconf)

        if not isinstance(data,dict):
            return {}

        return data

    def __has_access(self,repo:str,user:str,priv:str) -> bool:
        access = self._get_rep_access(repo)

        if 'users' not in access:
            return False

        users = access['users']
        if user not in users:
            return False

        privleg = users[user]
        if 'access' not in privleg:
            return False

        uacces = privleg['access']
        if not isinstance(uacces,str):
            return False

        return priv.lower() in uacces.lower()

    def has_read_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'r')

    def has_write_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'w')

    def backup(self , target:str ) -> str:
        src = join(
            target,
            dt.now().strftime("%Y%m%d%H%M%S") + ".tar.gz"
        )

        conf = GitServer.CONFIG
        extras = conf.get("ymvas-server-backup-extras",{})

        folders = {
            "repositories" : self.REPOSITORIES,
            "auth_keys"    : expanduser(self.AUTHORIZED_KEYS)
        }

        if isinstance(extras,dict):
            for k,v in extras.items():
                if not isinstance(v, str):
                    continue
                folders[k] = v

        for path in folders.values():
            if not exists(path):
                raise YException('missing-backup-path', amsg={
                    "src" : path
                })

        makedirs(target,exist_ok=True)

        with tarfile.open(src, "w:gz") as tar:
            for path in folders.values():
                tar.add(path, arcname = path )

            data = json.dumps(folders, indent=2).encode("utf-8")
            info = tarfile.TarInfo(name="meta.json")
            info.size = len(data)

            tar.addfile(info, io.BytesIO(data))

        return src

    def restore(self, archive: str) -> bool:
        if not exists(archive):
            raise YException("backup-not-found", amsg={"src": archive})

        conf = GitServer.CONFIG
        extras = conf.get("ymvas-server-backup-extras",{})

        folders = {
            "repositories" : self.REPOSITORIES,
            "auth_keys"    : expanduser(self.AUTHORIZED_KEYS)
        }

        restore = {}

        if isinstance(extras,dict):
            for k,v in extras.items():
                if not isinstance(v, str):
                    continue
                folders[k] = v

        with tarfile.open(archive, "r:gz") as tar:
            try:
                meta_file = tar.extractfile("meta.json")
                meta = json.load(meta_file)

                for k,f in meta.items():
                    if k not in folders:
                        continue

                    xpath = folders[k]
                    restore[f[1:] if f.startswith('/') else f] = xpath
                    if isfile(xpath) and not isdir(xpath):
                        remove(xpath)
                    else:
                        shutil.rmtree(xpath,ignore_errors=True)

            except Exception:
                raise YException("invalid-backup", amsg={"reason": "missing meta.json"})
            
            for member in tar.getmembers():
                if member.name == "meta.json":
                    continue
                
                dest = member.name
                for original, changed in restore.items():
                    if dest.startswith(original):
                        dest = dest.replace(original,changed)
                        break

                destdir = dirname(dest)
                makedirs(destdir, exist_ok=True)

                if member.isfile():
                    with tar.extractfile(member) as src, open(dest, "wb") as dst:
                        dst.write(src.read())
                else:
                    tar.extract(member, path=dest)

        return True
