from . import (
    global_config_file,
    global_config_dir
)


server_errors = {
    'server-help' : {
        "msg": (
            "[server] needs more arguments to be used: {choices}\n"
            "try with:\n"
            ">> ym server setup   --user=ymvas --ssh-key=\"~./ssh/ssh-key.pub\"  \n"
            ">> ym server backup  --target=\"/save/it/here\" \n"
            ">> ym server restore --target=\"/path/to/restore.tar.gz\" \n"
        ), 
        "color" : "yellow"
    },
    'server-setup' : {
        "msg": (
            "[setup] needs proper flags \n"
            "try with:\n"
            ">> ym server setup --user=ymvas --ssh-key=\"~./ssh/ssh-key.pub\"  \n"
        ), 
        "color" : "yellow"
    },

    "missing-ssh-key" : {
        "msg" : (
            "The ssh-key path you provided is invalid! [{src}]"
        ),
        "color" : "red"
    },

    "missing-backup-path" : {
        "msg" : (
            "The path for backup does not exists! [{src}]"
        ),
        "color" : "red"
    },

    "backup-not-found" : {
        "msg" : (
            "The file you provided for backup does not exists! [{src}]"
        ),
        "color" : "red"
    },

    "invalid-backup" : {
        "msg" : (
            "The file you provided to restore backup is not valid: {reason}"
        ),
        "color" : "red"
    }

}

errors = {
    # system errors
    "global-dir-not-created" : {
        "msg"  : (
            "Unable to create global directory, please check permisions for this directory "
            f"[{global_config_dir()}] !"
        ),
    },
    "global-config-not-created" : {
        "msg" : (
            "Unable to create global config file please check permisions!"
            f"[{global_config_file()}]"
        ),
    },
    "global-config-misconfigured": {
        "msg" : (
            f"Unable to parse config file [{global_config_file()}]"
            ", please remove it or fix the contents"
        ),
    },









    
    'complex-secret' : {
        'msg' : (
            "[{src}] contains references and can't be updated!"
        ),
    },
    'invalid-directory' : {
        'msg' : (
            "[{src}] is not a valid repositoy!"
        ),
        "color" : "yellow"
    },
    'reference-not-compiled' : {
        'msg' : (
            "[{src}] was not complied correctly, please use Referer properly!"
        ),
    },



    # operator errors
    'init-help' : {
        "msg": (
            "init was not setup correctly, valid arguments: {choices} \n" 
            "try this: \n"
            ">> ym init local \n"
            ">> ym init default \n"
            ">> ym init account "
        ), 
        "color" : "yellow"
    },
    'config-help' : {
        "msg": (
            "[config] needs more arguments to be used: {choices}\n"
            "try with:\n"
            "  ym config designate   make this directory as your global config storage \n\n"
            "  ym config set --global-src=\"/path/for/your/global/repo\" \n"
            "  ym config get --global-src\n"
            "  ym config rm  --global-src\n"
            "  ym config show \n"
            "\n"
            "avaliable flags:\n{flags}\n"
        ), 
        "color" : "yellow"
    },
    'task-help' : {
        "msg": (
            "[task] needs more arguments to be used: {choices}\n"
            "try with:\n"
            ">> ym task get \n"
            ">> ym task list \n"
            # "\n"
            # "avaliable flags:\n{flags}\n"
        ), 
        "color" : "yellow"
    },

    **server_errors
}




