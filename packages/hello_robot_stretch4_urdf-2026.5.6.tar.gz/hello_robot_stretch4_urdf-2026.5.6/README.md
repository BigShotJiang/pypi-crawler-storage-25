# Overview

This package provides URDF and mesh files for Stretch 4, as well as code for manipulating the kinematic description (e.g. adding virtual joints) and exporting for use in other programs (e.g. ROS2, pinocchio). The assets for Stretch 3 and below can be found in the [stretch_urdf](https://github.com/hello-robot/stretch_urdf) repo. This package can be installed by:

```
python3 -m pip install -U hello-robot-stretch4-urdf
```

The URDF and meshes are installed to your Python site directory. You can load them dynamically using:

```
from stretch4_urdf import get_urdf

print(get_urdf())
```

## Primers

The following primers provide deeper documentation on various parts of the system:

| Primer | Description |
| :--- | :--- |
| [Batches](stretch4_urdf/primer_batches.md) | Explains URDF batch organization, compiling the URDF dynamically, and how to add new batch models. |
| [End Effectors](stretch4_urdf/SE4_tools/primer_end_effectors.md) | Outlines the available end effector tools and provides instructions on how to add new tools to the robot. |
