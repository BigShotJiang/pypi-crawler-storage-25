"""Tests for the g8_voice_* MCP suite (read + lifecycle dialer tools).

Covers the 5 read-only tools plus the 5 dialer lifecycle tools added on
2026-04-27: list_agents, create_dialer_session, pause_session,
resume_session, stop_session.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
import g8_mcp_server.server as server_module
from g8_mcp_server.server import create_server


def _server_with_mode(monkeypatch, mode: str):
    """Build a fresh FastMCP server in the given mode.

    `MCP_MODE` is captured at module import time, so setting the env var
    after the fact is a no-op. Patch the module-level constant directly
    so each fixture gets a server registered for the intended mode."""
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setenv("G8_MCP_MODE", mode)
    monkeypatch.setattr(server_module, "MCP_MODE", mode)
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


@pytest.fixture
def mcp_server(monkeypatch):
    return _server_with_mode(monkeypatch, "all")


@pytest.fixture
def gtm_only_server(monkeypatch):
    """Server registered in GTM-only mode - voice tools must NOT be present.

    Locks the "voice lives in `all` mode only" decision so a future
    refactor that drops the gating regresses loudly here."""
    return _server_with_mode(monkeypatch, "gtm")


@pytest.fixture
def dev_only_server(monkeypatch):
    return _server_with_mode(monkeypatch, "dev")


def _tool(server, name):
    return server._tool_manager._tools[name]


def _read_only(tool) -> bool:
    ann = tool.annotations
    flag = getattr(ann, "readOnlyHint", None)
    if flag is None and isinstance(ann, dict):
        flag = ann.get("readOnlyHint")
    return bool(flag)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestRegistration:
    READ_ONLY_NAMES = [
        "g8_voice_list_dialer_sessions",
        "g8_voice_get_dialer_stats",
        "g8_voice_list_numbers",
        "g8_voice_list_missed_callbacks",
        "g8_voice_get_call_grading",
        "g8_voice_get_call_transcript",
        "g8_voice_list_calls_for_contact",
        "g8_voice_list_calls_for_sdr",
        "g8_voice_list_agents",
    ]
    # Lifecycle tools that mutate session state. Kept separate from the
    # read-only list so the read-only invariant test stays meaningful.
    WRITE_NAMES = [
        "g8_voice_create_dialer_session",
        "g8_voice_pause_session",
        "g8_voice_resume_session",
        "g8_voice_stop_session",
    ]
    EXPECTED_NAMES = READ_ONLY_NAMES + WRITE_NAMES

    def test_all_tools_registered_in_all_mode(self, mcp_server):
        for name in self.EXPECTED_NAMES:
            assert name in mcp_server._tool_manager._tools, f"Missing: {name}"

    def test_read_only_tools_are_read_only(self, mcp_server):
        # The read-only set never charges credits and never mutates. If
        # this flips, we've accidentally promoted a destructive tool to
        # the read group.
        for name in self.READ_ONLY_NAMES:
            assert _read_only(_tool(mcp_server, name)), f"{name} should be read-only"

    def test_write_tools_are_not_read_only(self, mcp_server):
        # Lifecycle tools must NOT carry the read-only hint - MCP-aware
        # clients use that bit to decide whether to surface a confirm
        # prompt before invoking. Regression guard against
        # "accidentally pasted the read-only annotation onto a write".
        for name in self.WRITE_NAMES:
            assert not _read_only(_tool(mcp_server, name)), (
                f"{name} must not be marked read-only - it mutates session state"
            )

    def test_destructive_tools_carry_destructive_hint(self, mcp_server):
        # create + stop + resume are real-world side effects: create spins
        # up a session row, stop transitions to COMPLETED with no public
        # un-stop, and resume actually places phone calls. All three must
        # surface destructiveHint=True so MCP clients prompt for confirm.
        for name in (
            "g8_voice_create_dialer_session",
            "g8_voice_stop_session",
            "g8_voice_resume_session",
        ):
            ann = _tool(mcp_server, name).annotations
            destructive = getattr(ann, "destructiveHint", None)
            if destructive is None and isinstance(ann, dict):
                destructive = ann.get("destructiveHint")
            assert destructive is True, f"{name} should be destructive"

    def test_reversible_tools_are_idempotent(self, mcp_server):
        # pause is the only reversible+idempotent lifecycle tool now -
        # resume was promoted to destructive on 2026-04-28 because it
        # places real outbound calls, not just a status flip. Calling
        # pause twice is still safe (no-op the second time).
        for name in ("g8_voice_pause_session",):
            ann = _tool(mcp_server, name).annotations
            idem = getattr(ann, "idempotentHint", None)
            if idem is None and isinstance(ann, dict):
                idem = ann.get("idempotentHint")
            assert idem is True, f"{name} should be idempotent"

    def test_voice_tools_absent_in_gtm_mode(self, gtm_only_server):
        for name in self.EXPECTED_NAMES:
            assert name not in gtm_only_server._tool_manager._tools, (
                f"{name} leaked into gtm mode - voice is supposed to live in `all` only"
            )

    def test_voice_tools_absent_in_dev_mode(self, dev_only_server):
        for name in self.EXPECTED_NAMES:
            assert name not in dev_only_server._tool_manager._tools


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------


class TestListDialerSessions:
    async def test_path_and_default_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "sessions": [{"session_id": "s-1"}],
                    "pagination": {"total_items": 1, "current_page": 1, "page_size": 50},
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_dialer_sessions").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/voice/dialer/sessions"
        assert params["page"] == 1
        assert params["page_size"] == 50
        assert params["sort_order"] == "desc"
        # None-valued filters must not be forwarded - keeps the URL clean
        # and avoids "?status=None" weirdness on the server side.
        for absent in ("status", "user_email", "name", "campaign_id"):
            assert absent not in params
        assert isinstance(r, dict) and r["sessions"][0]["session_id"] == "s-1"

    async def test_page_size_clamp(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"sessions": [], "pagination": {}}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_dialer_sessions").fn(page_size=9999, page=0)
        params = fake.await_args.args[1]
        assert params["page_size"] == 200
        assert params["page"] == 1

    async def test_filter_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"sessions": [], "pagination": {}}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_dialer_sessions").fn(
            status="ACTIVE,PAUSED",
            user_email="sdr@example.com",
            list_id="list-99",
            sort_by="created_at",
            sort_order="asc",
        )
        params = fake.await_args.args[1]
        assert params["status"] == "ACTIVE,PAUSED"
        assert params["user_email"] == "sdr@example.com"
        assert params["list_id"] == "list-99"
        assert params["sort_by"] == "created_at"
        assert params["sort_order"] == "asc"

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("voice down"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_dialer_sessions").fn()
        assert isinstance(r, str) and "voice down" in r


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


class TestGetDialerStats:
    async def test_path_and_aggregation_default(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"filters": {}, "metrics": [], "summary": None}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_get_dialer_stats").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/voice/dialer/stats"
        assert params["aggregation"] == "DAILY"

    async def test_filter_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"filters": {}, "metrics": [], "summary": None}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_get_dialer_stats").fn(
            session_id="s-1",
            user_email="sdr@example.com",
            date_from="2026-04-01",
            date_to="2026-04-26",
            aggregation="TOTAL",
        )
        params = fake.await_args.args[1]
        assert params["session_id"] == "s-1"
        assert params["user_email"] == "sdr@example.com"
        assert params["date_from"] == "2026-04-01"
        assert params["date_to"] == "2026-04-26"
        assert params["aggregation"] == "TOTAL"


# ---------------------------------------------------------------------------
# Numbers
# ---------------------------------------------------------------------------


class TestListDialerNumbers:
    async def test_path_no_filter(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"numbers": []}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_numbers").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/voice/dialer/numbers"
        assert "user_email" not in params

    async def test_user_email_filter(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"numbers": []}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_numbers").fn(user_email="sdr@example.com")
        params = fake.await_args.args[1]
        assert params["user_email"] == "sdr@example.com"


# ---------------------------------------------------------------------------
# Missed callbacks
# ---------------------------------------------------------------------------


class TestListMissedCallbacks:
    async def test_path_and_limit_default(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"missed_callbacks": [], "count": 0}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_missed_callbacks").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/voice/dialer/missed-callbacks"
        assert params["limit"] == 50

    async def test_limit_clamps(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"missed_callbacks": [], "count": 0}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_missed_callbacks").fn(limit=9999)
        assert fake.await_args.args[1]["limit"] == 200

        await _tool(mcp_server, "g8_voice_list_missed_callbacks").fn(limit=0)
        assert fake.await_args.args[1]["limit"] == 1


# ---------------------------------------------------------------------------
# Call grading
# ---------------------------------------------------------------------------


class TestGetCallGrading:
    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "room_name": "room-abc",
                    "status": "ready",
                    "grading": {"score": 8},
                    "reviewed": False,
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_get_call_grading").fn(room_name="room-abc")
        path = fake.await_args.args[0]
        assert path == "/voice/dialer/calls/room-abc/grading"
        assert r["status"] == "ready"
        assert r["grading"]["score"] == 8

    async def test_pending_passthrough(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"room_name": "room-abc", "status": "pending"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_get_call_grading").fn(room_name="room-abc")
        assert r["status"] == "pending"


# ---------------------------------------------------------------------------
# Per-call transcript + per-contact call listing (read-only)
# ---------------------------------------------------------------------------


class TestGetCallTranscript:
    async def test_path_passes_room_name(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "room_name": "room-abc",
                    "status": "ready",
                    "transcript": [
                        {"speaker": "SDR", "content": "Hi"},
                        {"speaker": "HUMAN", "content": "Hello"},
                    ],
                    "summary": "Quick chat",
                    "disposition": "booked",
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_get_call_transcript").fn(room_name="room-abc")
        path = fake.await_args.args[0]
        assert path == "/voice/dialer/calls/room-abc/transcript"
        assert r["status"] == "ready"
        assert len(r["transcript"]) == 2
        assert r["summary"] == "Quick chat"

    async def test_empty_status_passthrough(self, mcp_server, monkeypatch):
        """An empty/in-flight transcript must NOT be treated as an error."""
        fake = AsyncMock(
            return_value={"data": {"room_name": "room-abc", "status": "empty", "transcript": []}}
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_get_call_transcript").fn(room_name="room-abc")
        assert r["status"] == "empty"
        assert r["transcript"] == []

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("transcript svc down"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_get_call_transcript").fn(room_name="room-abc")
        assert isinstance(r, str) and "transcript svc down" in r


class TestListCallsForContact:
    async def test_path_and_default_limit(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "contact_id": "12345",
                    "count": 1,
                    "calls": [{"room_name": "room-1", "has_transcript": True}],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_calls_for_contact").fn(contact_id="12345")
        path, params = fake.await_args.args
        assert path == "/voice/dialer/calls"
        assert params["contact_id"] == "12345"
        assert params["limit"] == 20  # default
        assert r["count"] == 1
        # No transcript blob should leak into the listing
        for row in r["calls"]:
            assert "transcript" not in row

    async def test_limit_clamps(self, mcp_server, monkeypatch):
        """Caller-supplied limit is clamped to [1, 100] to match the dev API surface."""
        fake = AsyncMock(return_value={"data": {"contact_id": "x", "count": 0, "calls": []}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        # Over upper bound
        await _tool(mcp_server, "g8_voice_list_calls_for_contact").fn(contact_id="x", limit=500)
        params = fake.await_args.args[1]
        assert params["limit"] == 100

        # Under lower bound
        await _tool(mcp_server, "g8_voice_list_calls_for_contact").fn(contact_id="x", limit=0)
        params = fake.await_args.args[1]
        assert params["limit"] == 1

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("calls svc down"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_calls_for_contact").fn(contact_id="x")
        assert isinstance(r, str) and "calls svc down" in r


class TestListCallsForSdr:
    async def test_path_and_required_user_email(self, mcp_server, monkeypatch):
        """user_email is forwarded; optional params omitted when not supplied."""
        fake = AsyncMock(
            return_value={
                "data": {
                    "contact_id": None,
                    "user_email": "bleron.gashi@cience.com",
                    "parallel_session_id": None,
                    "count": 1,
                    "calls": [
                        {
                            "room_name": "sdr-room-1",
                            "contact_id": "12345",
                            "to": "+15551234567",
                            "has_transcript": True,
                        }
                    ],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_calls_for_sdr").fn(
            user_email="bleron.gashi@cience.com"
        )
        path, params = fake.await_args.args
        assert path == "/voice/dialer/calls"
        assert params["user_email"] == "bleron.gashi@cience.com"
        assert params["limit"] == 20  # default
        # Optional params must NOT be forwarded when omitted (keeps URL clean)
        assert "created_after" not in params
        assert "parallel_session_id" not in params
        # contact_id MUST NOT be set - this tool is for the SDR pivot
        assert "contact_id" not in params
        assert r["count"] == 1
        # Each row must include to/contact_id so the consumer can client-filter
        assert r["calls"][0]["to"] == "+15551234567"
        assert r["calls"][0]["contact_id"] == "12345"

    async def test_optional_filters_forwarded(self, mcp_server, monkeypatch):
        """created_after and parallel_session_id are forwarded when provided."""
        fake = AsyncMock(
            return_value={
                "data": {
                    "user_email": "bleron.gashi@cience.com",
                    "parallel_session_id": "sess-x",
                    "count": 0,
                    "calls": [],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_calls_for_sdr").fn(
            user_email="bleron.gashi@cience.com",
            created_after="2026-05-12T00:00:00Z",
            parallel_session_id="sess-x",
            limit=50,
        )
        params = fake.await_args.args[1]
        assert params["created_after"] == "2026-05-12T00:00:00Z"
        assert params["parallel_session_id"] == "sess-x"
        assert params["limit"] == 50

    async def test_limit_clamps(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={"data": {"user_email": "x@y.com", "count": 0, "calls": []}}
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        # Over upper bound
        await _tool(mcp_server, "g8_voice_list_calls_for_sdr").fn(
            user_email="x@y.com", limit=500
        )
        params = fake.await_args.args[1]
        assert params["limit"] == 100

        # Under lower bound
        await _tool(mcp_server, "g8_voice_list_calls_for_sdr").fn(
            user_email="x@y.com", limit=0
        )
        params = fake.await_args.args[1]
        assert params["limit"] == 1

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("sdr svc down"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_calls_for_sdr").fn(
            user_email="x@y.com"
        )
        assert isinstance(r, str) and "sdr svc down" in r


# ---------------------------------------------------------------------------
# Agents (read-only, but new - backs the create-session picker)
# ---------------------------------------------------------------------------


class TestListAgents:
    async def test_path_no_filters(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"agents": [{"agent_id": "a-1", "name": "Aria"}]}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_agents").fn()
        path = fake.await_args.args[0]
        assert path == "/voice/dialer/agents"
        # G8Client.get strips None at the HTTP layer, so the tool itself
        # forwards a dict whose values are all None - we only assert the
        # response unwrap worked.
        assert r["agents"][0]["agent_id"] == "a-1"

    async def test_filter_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"agents": []}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        await _tool(mcp_server, "g8_voice_list_agents").fn(
            role="SDR",
            agent_status="active",
            entity_type="agent",
            search="aria",
        )
        params = fake.await_args.args[1]
        assert params["role"] == "SDR"
        assert params["agent_status"] == "active"
        assert params["entity_type"] == "agent"
        assert params["search"] == "aria"

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("agents svc down"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.get", fake)

        r = await _tool(mcp_server, "g8_voice_list_agents").fn()
        assert isinstance(r, str) and "agents svc down" in r


# ---------------------------------------------------------------------------
# Create dialer session (write)
# ---------------------------------------------------------------------------


class TestCreateDialerSession:
    async def test_minimal_body_strips_none(self, mcp_server, monkeypatch):
        # Only `name` and `from_phone` are actually required by the public
        # router. Everything else MUST be omitted from the body when None
        # so we don't pollute Pydantic validation upstream with explicit
        # nulls (the DTO is exclude_none friendly but the test locks in
        # the wire shape regardless).
        fake = AsyncMock(return_value={"data": {"session_id": "s-new", "status": "PAUSED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        r = await _tool(mcp_server, "g8_voice_create_dialer_session").fn(
            name="Tuesday cold dial",
            from_phone="+15551234567",
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/voice/dialer/sessions"
        assert body == {"name": "Tuesday cold dial", "from_phone": "+15551234567"}
        assert r["session_id"] == "s-new"
        assert r["status"] == "PAUSED"

    async def test_full_body_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"session_id": "s-new", "status": "PAUSED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        await _tool(mcp_server, "g8_voice_create_dialer_session").fn(
            name="Q4 ICP push",
            from_phone="+15551234567",
            list_id="list-99",
            list_title="Q4 ICP",
            agent_id="agent-uuid-1",
            agent_name="Aria",
            entity_type="agent",
            studio_campaign_id="camp-uuid-7",
            user_timezone="America/New_York",
            skip_voicemails=True,
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        # studio_campaign_id is the *public* name - mapping to
        # campaign_builder_campaign_id happens at the developer-API
        # router boundary, NOT in the MCP tool. The MCP tool sends the
        # public name and trusts the router.
        assert body["studio_campaign_id"] == "camp-uuid-7"
        assert body["agent_id"] == "agent-uuid-1"
        assert body["agent_name"] == "Aria"
        assert body["entity_type"] == "agent"
        assert body["list_id"] == "list-99"
        assert body["list_title"] == "Q4 ICP"
        assert body["user_timezone"] == "America/New_York"
        assert body["skip_voicemails"] is True

    async def test_skip_voicemails_false_is_kept(self, mcp_server, monkeypatch):
        # `False` is meaningful - it means "explicitly include voicemails
        # for this session". The None-strip filter must not drop it.
        fake = AsyncMock(return_value={"data": {"session_id": "s-new", "status": "PAUSED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        await _tool(mcp_server, "g8_voice_create_dialer_session").fn(
            name="VM-on session",
            from_phone="+15551234567",
            skip_voicemails=False,
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["skip_voicemails"] is False

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("voice 502"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        r = await _tool(mcp_server, "g8_voice_create_dialer_session").fn(
            name="x", from_phone="+15550000000"
        )
        assert isinstance(r, str) and "voice 502" in r


# ---------------------------------------------------------------------------
# Session lifecycle PATCH (pause / resume / stop)
# ---------------------------------------------------------------------------


class TestSessionLifecycle:
    async def test_pause_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"session_id": "s-1", "status": "PAUSED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.patch", fake)

        r = await _tool(mcp_server, "g8_voice_pause_session").fn(session_id="s-1")
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/voice/dialer/sessions/s-1/status"
        assert body == {"status": "PAUSED"}
        assert r["status"] == "PAUSED"

    async def test_resume_path_and_body(self, mcp_server, monkeypatch):
        # Resume now POSTs to a dedicated endpoint that auto-fetches the
        # next batch of contacts and forwards them to voice's
        # start-session API. The PATCH-status path is no longer used here
        # because voice's PATCH only accepts PAUSED/COMPLETED.
        fake = AsyncMock(
            return_value={
                "data": {
                    "session_id": "s-1",
                    "status": "ACTIVE",
                    "dialed_count": 3,
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        r = await _tool(mcp_server, "g8_voice_resume_session").fn(session_id="s-1")
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/voice/dialer/sessions/s-1/resume"
        assert body == {"max_contacts": 4}  # default
        assert r["status"] == "ACTIVE"
        assert r["dialed_count"] == 3

    async def test_resume_max_contacts_forwarded_and_clamped(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={"data": {"session_id": "s-1", "status": "ACTIVE", "dialed_count": 1}}
        )
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        # Custom value below the cap is forwarded as-is
        await _tool(mcp_server, "g8_voice_resume_session").fn(session_id="s-1", max_contacts=2)
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body == {"max_contacts": 2}

        # Over-large value is clamped client-side at 4 (voice cap)
        await _tool(mcp_server, "g8_voice_resume_session").fn(session_id="s-1", max_contacts=99)
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body == {"max_contacts": 4}

        # Zero is treated as "no value" -> falls back to the default (4)
        # because `0 or 4` short-circuits to 4 in Python. This is fine for
        # an LLM caller that may pass 0 to mean "let me skip this arg".
        await _tool(mcp_server, "g8_voice_resume_session").fn(session_id="s-1", max_contacts=0)
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body == {"max_contacts": 4}

    async def test_resume_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("session not found"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.post", fake)

        r = await _tool(mcp_server, "g8_voice_resume_session").fn(session_id="missing")
        assert isinstance(r, str) and "session not found" in r

    async def test_stop_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"session_id": "s-1", "status": "COMPLETED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.patch", fake)

        r = await _tool(mcp_server, "g8_voice_stop_session").fn(session_id="s-1")
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/voice/dialer/sessions/s-1/status"
        assert body == {"status": "COMPLETED"}
        assert r["status"] == "COMPLETED"

    async def test_session_id_url_segment_passthrough(self, mcp_server, monkeypatch):
        # UUID-shaped session ids are the realistic case. Lock the path
        # template so a future refactor that breaks it (e.g. adding an
        # extra segment) regresses here.
        fake = AsyncMock(return_value={"data": {"session_id": "abc-123-uuid", "status": "PAUSED"}})
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.patch", fake)

        await _tool(mcp_server, "g8_voice_pause_session").fn(session_id="abc-123-uuid")
        assert fake.await_args.args[0] == "/voice/dialer/sessions/abc-123-uuid/status"

    async def test_pause_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("session not found"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.patch", fake)

        r = await _tool(mcp_server, "g8_voice_pause_session").fn(session_id="missing")
        assert isinstance(r, str) and "session not found" in r

    async def test_stop_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("voice 502"))
        monkeypatch.setattr("g8_mcp_server.tools.voice.G8Client.patch", fake)

        r = await _tool(mcp_server, "g8_voice_stop_session").fn(session_id="s-1")
        assert isinstance(r, str) and "voice 502" in r
