"""Unit tests for MCP tools — verifies correct endpoint URLs and params."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.auth import set_api_key
from g8_mcp_server.client import G8Client, G8ClientError, _handle_response
from g8_mcp_server.server import create_remote_app, create_server


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_123")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))


@pytest.fixture
def client(mock_env):
    return G8Client()


def _tool_names(server):
    return list(server._tool_manager._tools.keys())


class TestG8Client:
    def test_missing_api_key_required(self, monkeypatch):
        monkeypatch.delenv("G8_API_KEY", raising=False)
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        with pytest.raises(G8ClientError, match="G8_API_KEY"):
            G8Client(require_key=True)

    def test_missing_api_key_not_required(self, monkeypatch):
        monkeypatch.delenv("G8_API_KEY", raising=False)
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        client = G8Client(require_key=False)
        assert client._env_api_key == ""

    def test_contextvars_key_takes_priority(self, client):
        set_api_key("context_key_456")
        assert client._headers["Authorization"] == "Bearer context_key_456"
        # Clean up
        from g8_mcp_server.auth import _api_key
        _api_key.set("")

    def test_env_key_fallback(self, client):
        assert client._headers["Authorization"] == "Bearer test_key_123"
        assert client._headers["Content-Type"] == "application/json"

    def test_base_url(self, client):
        assert client.base_url == "https://test.graph8.com"


class TestDevTools:
    """Dev-mode tool registration (repo/install/campaigns/kb).

    Replaces the original `TestRepoTools` / `TestInstallTools` / `TestCampaignTools`
    classes that exercised legacy `tools/repos.py` / `install.py` / `campaigns.py`
    / `kb.py` modules. Those modules were pre-Upgrade-2 precursors to the
    consolidated `dev.py` registrar — they were never wired into `server.py`'s
    `_register_tools()` and returned plain `str` (no Pydantic envelopes). They
    were deleted as dead code on 2026-04-21 when the tool-count audit found
    they didn't contribute to the 86-tool `all`-mode inventory.

    The equivalent tools now live in `dev.py` with proper Pydantic return
    types and are what actually gets registered.
    """

    def test_repo_tools_registered_via_dev(self, client):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import dev
        server = FastMCP("test")
        dev.register(server, client)
        names = _tool_names(server)
        assert "g8_connect_repo" in names
        assert "g8_scan_repo" in names
        assert "g8_get_scan_results" in names
        assert "g8_status" in names
        assert "g8_doctor" in names

    def test_install_tools_registered_via_dev(self, client):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import dev
        server = FastMCP("test")
        dev.register(server, client)
        names = _tool_names(server)
        assert "g8_install_spine" in names
        assert "g8_apply_install" in names

    def test_campaign_tools_registered_via_dev(self, client):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import dev
        server = FastMCP("test")
        dev.register(server, client)
        names = _tool_names(server)
        assert "g8_list_campaigns" in names
        assert "g8_get_campaign" in names
        # Note: the legacy `campaigns.py` registered `g8_launch_campaign`,
        # but the current `all`-mode surface uses `g8_gtm_launch_campaign`
        # (via gtm.py's `name_prefix="gtm"`). The unprefixed variant is
        # intentionally dropped.


class TestPlatformTools:
    def test_tools_registered(self, client):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import platform
        server = FastMCP("test")
        platform.register(server, client)
        names = _tool_names(server)
        assert "g8_search_contacts" in names
        assert "g8_search_companies" in names
        assert "g8_lookup_person" in names
        assert "g8_lookup_company" in names
        assert "g8_add_to_sequence" in names
        assert "g8_get_deals" in names
        assert "g8_get_tasks" in names
        assert "g8_get_lists" in names
        assert "g8_get_activities" in names


class TestServerBootstrap:
    def test_all_mode_registers_dev_and_gtm_tools(self, mock_env):
        server = create_server()
        expected_tools = [
            "g8_connect_repo", "g8_scan_repo", "g8_get_scan_results", "g8_status", "g8_doctor",
            "g8_install_spine", "g8_apply_install",
            "g8_get_tracking_snippet", "g8_get_form_template",
            "g8_list_campaigns", "g8_get_campaign", "g8_search_kb", "g8_list_kb_documents",
            "g8_gtm_list_campaigns", "g8_gtm_get_campaign", "g8_gtm_launch_campaign",
            "g8_gtm_list_campaign_documents", "g8_gtm_get_campaign_document",
            "g8_gtm_create_campaign", "g8_gtm_update_campaign",
            "g8_gtm_create_campaign_document", "g8_gtm_update_campaign_document", "g8_gtm_delete_campaign_document",
            "g8_gtm_get_campaign_sequence", "g8_gtm_update_campaign_sequence",
            "g8_gtm_create_campaign_step", "g8_gtm_update_campaign_step", "g8_gtm_delete_campaign_step",
            "g8_gtm_get_global_context", "g8_gtm_get_personas", "g8_gtm_get_icps", "g8_gtm_get_campaign_ideas",
            "g8_gtm_search_kb", "g8_gtm_list_kb_documents",
            "g8_search_contacts", "g8_search_companies", "g8_lookup_person", "g8_lookup_company", "g8_add_to_sequence",
            "g8_find_contacts", "g8_find_companies",
            "g8_create_contact", "g8_create_list", "g8_add_to_list", "g8_enrich_contacts", "g8_list_sequences",
            "g8_get_deals", "g8_get_deal", "g8_get_tasks", "g8_create_task",
            "g8_get_lists", "g8_get_pipeline", "g8_create_note", "g8_get_activities",
        ]
        names = _tool_names(server)
        for tool_name in expected_tools:
            assert tool_name in names, f"Missing tool: {tool_name}"
        # `all` mode registers the union of every domain + the progressive-discovery
        # meta tool (`g8_tool_search`, Upgrade 1). The count grows as new tools
        # land; just assert the union is at least as large as the curated list here.
        assert len(names) >= len(expected_tools)
        assert "g8_tool_search" in names

    def test_profile_catalog_is_truthful(self):
        """The profile UI shows tool counts per group — just verify shape & order.

        Exact counts drift every time a new tool lands, and this test used to
        lock them in 4 places (here + the test_integration.test_tool_count +
        two copies of the full name list). Post-Upgrade-1/2/4 we assert the
        structure and keep the count check loose.
        """
        from g8_mcp_server.capabilities import profile_tool_catalog

        catalog = profile_tool_catalog()
        counts = {group["value"]: group["toolCount"] for group in catalog["groups"]}
        assert set(counts.keys()) == {"crm", "campaigns", "intent", "dev", "all"}
        for value, label in counts.items():
            # "NN tools" shape
            n_str, _, suffix = label.partition(" ")
            assert suffix == "tools", f"group {value} label bad: {label!r}"
            assert int(n_str) > 0
        campaign_labels = {tool["name"] for tool in catalog["tools"]["campaigns"]}
        assert "generate_ideas" not in campaign_labels
        assert any(
            tool["name"] == "get_campaign_ideas" and tool["actual_tool"] == "g8_gtm_get_campaign_ideas"
            for tool in catalog["tools"]["campaigns"]
        )

    def test_remote_tool_group_filters_new_tools(self):
        from g8_mcp_server.server import _filter_tools_list

        tools = [
            {"name": "g8_gtm_list_campaigns"},
            {"name": "g8_scan_repo"},
            {"name": "g8_get_deals"},
            {"name": "g8_get_lists"},
            {"name": "g8_list_sequences"},
        ]
        assert [tool["name"] for tool in _filter_tools_list(tools, "dev")] == [
            "g8_scan_repo",
            "g8_get_lists",
            "g8_list_sequences",
        ]
        assert [tool["name"] for tool in _filter_tools_list(tools, "crm")] == [
            "g8_gtm_list_campaigns",
            "g8_get_deals",
            "g8_get_lists",
            "g8_list_sequences",
        ]


class TestRemoteApp:
    def test_creates_without_env_key(self, monkeypatch):
        monkeypatch.delenv("G8_API_KEY", raising=False)
        app = create_remote_app()
        assert app is not None

    def test_creates_with_env_key(self, mock_env):
        app = create_remote_app()
        assert app is not None


class TestClientErrorHandling:
    def test_401_error(self):
        resp = MagicMock()
        resp.status_code = 401
        with pytest.raises(G8ClientError, match="Invalid API key"):
            _handle_response(resp)

    def test_429_error(self):
        resp = MagicMock()
        resp.status_code = 429
        with pytest.raises(G8ClientError, match="Rate limit"):
            _handle_response(resp)

    def test_404_error(self):
        resp = MagicMock()
        resp.status_code = 404
        with pytest.raises(G8ClientError, match="not found"):
            _handle_response(resp)

    def test_generic_error(self):
        resp = MagicMock()
        resp.status_code = 500
        resp.json.return_value = {"message": "Internal server error"}
        resp.text = "Internal server error"
        with pytest.raises(G8ClientError, match="Internal server error"):
            _handle_response(resp)

    def test_success_json(self):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"data": {"id": "test"}}
        result = _handle_response(resp)
        assert result == {"data": {"id": "test"}}


# ---------------------------------------------------------------------------
# g8_enrich_contacts — waterfall pipeline flow
#
# Historical: the tool used to POST /enrichment/enrich (legacy BYOK path).
# That silently failed for orgs without provider credentials. The rewrite
# routes through /enrichment/waterfall/* so it respects saved pipelines
# (including graph8-managed providers) and auto-creates a default pipeline
# when one doesn't exist.
#
# These tests exercise the three shapes the tool must handle:
#   1. happy path: an active pipeline already exists -> GET + POST enrich
#   2. auto-create path: no pipeline exists -> GET + POST create + POST enrich
#   3. signature preservation: (contact_ids: list[int], list_id: int) unchanged
# ---------------------------------------------------------------------------


def _register_platform_tools(client):
    """Register platform tools on a fresh FastMCP server and return the map."""
    from mcp.server import FastMCP
    from g8_mcp_server.tools import platform

    server = FastMCP("test")
    platform.register(server, client)
    return server, server._tool_manager._tools


class TestEnrichContactsWaterfallFlow:
    @pytest.mark.asyncio
    async def test_uses_existing_pipeline_when_one_is_active(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_enrich_contacts"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "configs": [
                        {
                            "column_id": "waterfall_abc123",
                            "name": "Custom",
                            "is_active": True,
                            "is_global": False,
                            "list_id": 142,
                            "step_count": 2,
                            "providers": ["graph8", "prospeo"],
                        }
                    ],
                    "list_id": 142,
                    "count": 1,
                }
            }
        )
        client.post = AsyncMock(
            return_value={"data": {"job_id": "job_xyz", "status": "queued"}}
        )

        result = await fn(contact_ids=[25090], list_id=142)

        # GET configs called with the list_id
        client.get.assert_called_once_with(
            "/enrichment/waterfall/configs", {"list_id": 142}
        )
        # POST enrich called with the existing column_id — NO auto-create
        assert client.post.call_count == 1
        post_call = client.post.call_args_list[0]
        assert post_call.args[0] == "/enrichment/waterfall/enrich"
        assert post_call.args[1] == {
            "column_id": "waterfall_abc123",
            "list_id": 142,
            "record_ids": [25090],
        }
        # ActionResult propagates the job_id via extra=allow
        assert hasattr(result, "model_dump")
        extras = result.model_dump()
        assert extras.get("job_id") == "job_xyz"
        assert extras.get("status") == "queued"

    @pytest.mark.asyncio
    async def test_auto_creates_pipeline_when_list_has_none(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_enrich_contacts"].fn

        client.get = AsyncMock(
            return_value={"data": {"configs": [], "list_id": 999, "count": 0}}
        )
        # Two POSTs: first creates the default pipeline, second runs it.
        client.post = AsyncMock(
            side_effect=[
                {
                    "data": {
                        "column_id": "waterfall_new456",
                        "config_id": "uuid-1",
                        "name": "API Auto-Created Pipeline",
                        "list_id": 999,
                        "created": True,
                    }
                },
                {"data": {"job_id": "job_new", "status": "queued"}},
            ]
        )

        result = await fn(contact_ids=[1, 2, 3], list_id=999)

        # Order: GET configs -> POST create -> POST enrich
        assert client.get.call_count == 1
        assert client.post.call_count == 2

        create_call, enrich_call = client.post.call_args_list
        assert create_call.args[0] == "/enrichment/waterfall/configs"
        assert create_call.args[1] == {"list_id": 999}

        assert enrich_call.args[0] == "/enrichment/waterfall/enrich"
        assert enrich_call.args[1] == {
            "column_id": "waterfall_new456",
            "list_id": 999,
            "record_ids": [1, 2, 3],
        }

        extras = result.model_dump()
        assert extras.get("job_id") == "job_new"

    @pytest.mark.asyncio
    async def test_skips_inactive_configs_when_picking_pipeline(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_enrich_contacts"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "configs": [
                        {"column_id": "waterfall_old", "is_active": False},
                        {"column_id": "waterfall_live", "is_active": True},
                    ]
                }
            }
        )
        client.post = AsyncMock(
            return_value={"data": {"job_id": "job_pick", "status": "queued"}}
        )

        await fn(contact_ids=[1], list_id=5)

        # The active config is the one used, not the first one.
        enrich_call = client.post.call_args_list[0]
        assert enrich_call.args[1]["column_id"] == "waterfall_live"

    def test_signature_preserved(self, client):
        """MCP clients that already know g8_enrich_contacts(contact_ids, list_id)
        keep working without any prompt or integration update.

        New optional parameters with defaults (e.g. ``dry_run`` for the
        wave-3 confirmation widget) are additive and DO NOT break existing
        callers, so we whitelist them as long as the original two params
        retain their position and types AND every new param has a default.
        """
        _, tools = _register_platform_tools(client)
        assert "g8_enrich_contacts" in tools
        import inspect

        sig = inspect.signature(tools["g8_enrich_contacts"].fn)
        params = list(sig.parameters.values())
        # Original two params must be first, in order, with the same types.
        assert params[0].name == "contact_ids"
        assert params[1].name == "list_id"
        # platform.py uses `from __future__ import annotations`, so the
        # annotation values are stringified - compare as strings rather than
        # typing objects.
        assert str(params[0].annotation) == "list[int]"
        assert str(params[1].annotation) == "int"
        # Original two params have no default (required positional/kwargs).
        assert params[0].default is inspect.Parameter.empty
        assert params[1].default is inspect.Parameter.empty
        # Every additional param introduced over time MUST be optional
        # (have a default) so unaware clients keep working.
        for extra in params[2:]:
            assert extra.default is not inspect.Parameter.empty, (
                f"new param {extra.name!r} has no default - breaks existing callers"
            )


class TestGetEnrichmentJob:
    def test_tool_registered(self, client):
        _, tools = _register_platform_tools(client)
        assert "g8_get_enrichment_job" in tools

    @pytest.mark.asyncio
    async def test_calls_job_status_endpoint(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_get_enrichment_job"].fn

        client.get = AsyncMock(
            return_value={"data": {"job_id": "abc", "status": "completed"}}
        )
        result = await fn(job_id="abc")

        client.get.assert_called_once_with("/enrichment/jobs/abc")
        extras = result.model_dump()
        assert extras.get("status") == "completed"


class TestExtractWaterfallConfigs:
    """Envelope parsing for the list-configs response. Robust to minor drift."""

    def test_extracts_from_api_response_envelope(self):
        from g8_mcp_server.tools.platform import _extract_waterfall_configs

        envelope = {"data": {"configs": [{"column_id": "a"}, {"column_id": "b"}]}}
        assert _extract_waterfall_configs(envelope) == [
            {"column_id": "a"},
            {"column_id": "b"},
        ]

    def test_extracts_from_bare_shape(self):
        from g8_mcp_server.tools.platform import _extract_waterfall_configs

        assert _extract_waterfall_configs(
            {"configs": [{"column_id": "x"}]}
        ) == [{"column_id": "x"}]

    def test_empty_configs_returns_empty_list(self):
        from g8_mcp_server.tools.platform import _extract_waterfall_configs

        assert _extract_waterfall_configs({"data": {"configs": []}}) == []
        assert _extract_waterfall_configs({}) == []
        assert _extract_waterfall_configs(None) == []

    def test_filters_non_dict_entries(self):
        from g8_mcp_server.tools.platform import _extract_waterfall_configs

        envelope = {"data": {"configs": [{"column_id": "a"}, "junk", 42]}}
        assert _extract_waterfall_configs(envelope) == [{"column_id": "a"}]


# ---------------------------------------------------------------------------
# Bug 3: seniority synonym expansion
#
# The open-data contact index stores seniority as full strings
# ("Vice President", "Senior Vice President", ...), not abbreviations. LLMs
# and legacy callers pass abbreviations (VP, SVP, EVP, ...) because that's
# how the older skill examples phrased them. We expand the abbreviation
# additively (keep the original AND append the canonical form) so any-of
# match semantics still find the rows. Backward compatible because:
#   - filters that already use the canonical form pass through unchanged
#   - non-seniority filters never get touched
#   - malformed input (non-list value, non-dict clause) passes through verbatim
# ---------------------------------------------------------------------------


class TestExpandSenioritySynonyms:
    def test_expands_vp_additively(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        out = _expand_seniority_synonyms(
            [{"field": "seniority_level", "operator": "any_of", "value": ["VP"]}]
        )
        assert out == [
            {
                "field": "seniority_level",
                "operator": "any_of",
                "value": ["VP", "Vice President"],
            }
        ]

    def test_expands_svp_evp_avp(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        out = _expand_seniority_synonyms(
            [
                {
                    "field": "seniority_level",
                    "operator": "any_of",
                    "value": ["SVP", "EVP", "AVP"],
                }
            ]
        )
        value = out[0]["value"]
        assert "SVP" in value and "Senior Vice President" in value
        assert "EVP" in value and "Executive Vice President" in value
        assert "AVP" in value and "Associate Vice President" in value

    def test_canonical_value_passes_through_unchanged(self):
        """Backward compat: filters that already use the canonical strings
        are not duplicated. This is the new-code recommended form."""
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        filters = [
            {
                "field": "seniority_level",
                "operator": "any_of",
                "value": ["Vice President", "Director"],
            }
        ]
        out = _expand_seniority_synonyms(filters)
        # Same shape - no duplication of "Vice President"
        assert out == filters

    def test_does_not_touch_other_fields(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        filters = [
            {"field": "job_title", "operator": "any_of", "value": ["VP", "Director"]},
            {"field": "country", "operator": "any_of", "value": ["United States"]},
        ]
        # job_title is NOT seniority_level - "VP" must NOT be expanded here.
        assert _expand_seniority_synonyms(filters) == filters

    def test_returns_none_for_none_input(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        assert _expand_seniority_synonyms(None) is None

    def test_returns_empty_for_empty_input(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        assert _expand_seniority_synonyms([]) == []

    def test_handles_mixed_canonical_and_abbrev(self):
        """Combining ["VP", "Director"] expands to canonical + originals,
        without duplicating Director."""
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        out = _expand_seniority_synonyms(
            [{"field": "seniority_level", "operator": "any_of", "value": ["VP", "Director"]}]
        )
        value = out[0]["value"]
        assert value.count("VP") == 1
        assert value.count("Director") == 1
        assert value.count("Vice President") == 1

    def test_case_insensitive_lookup_for_uppercased_form(self):
        """Lowercase ``vp`` still expands to "Vice President" via .upper()."""
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        out = _expand_seniority_synonyms(
            [{"field": "seniority_level", "operator": "any_of", "value": ["vp"]}]
        )
        assert "Vice President" in out[0]["value"]

    def test_passes_non_dict_clauses_verbatim(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        filters = ["not a dict", 42, None]
        # Bad shape doesn't crash; non-dict entries pass through.
        assert _expand_seniority_synonyms(filters) == ["not a dict", 42, None]

    def test_passes_non_list_value_verbatim(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        # A scalar value (e.g. ``operator: contains, value: "VP"``) is not
        # a list - we leave it alone because the backend handles operator
        # semantics, not us.
        filters = [{"field": "seniority_level", "operator": "contains", "value": "VP"}]
        assert _expand_seniority_synonyms(filters) == filters

    def test_does_not_mutate_input(self):
        from g8_mcp_server.tools.platform import _expand_seniority_synonyms

        original = [{"field": "seniority_level", "operator": "any_of", "value": ["VP"]}]
        snapshot = [dict(original[0])]
        snapshot[0]["value"] = list(original[0]["value"])
        _expand_seniority_synonyms(original)
        # The caller's filter list still holds only "VP", not the expanded set.
        assert original[0]["value"] == ["VP"]
        assert original == snapshot


class TestFindContactsExpandsSeniority:
    """g8_find_contacts must transparently expand abbreviations before
    calling the backend. The dry-run preview and read-back of the filter
    arg are intentionally OUT OF SCOPE - the expansion happens inside the
    HTTP body construction, not on the in-memory filters."""

    @pytest.mark.asyncio
    async def test_vp_filter_expands_to_canonical(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_find_contacts"].fn

        client.post = AsyncMock(
            return_value={"data": {"contacts": [], "page": 1, "limit": 25, "total": 0}}
        )
        await fn(
            filters=[{"field": "seniority_level", "operator": "any_of", "value": ["VP"]}]
        )
        call = client.post.call_args_list[0]
        # Endpoint unchanged, body's filter has the canonical form appended.
        assert call.args[0] == "/search/contacts"
        outbound = call.args[1]["filters"][0]["value"]
        assert "VP" in outbound  # original preserved (backward compat)
        assert "Vice President" in outbound  # canonical appended


class TestCreateListExpandsSeniorityInFiltersMode:
    """Same expansion contract for filters-mode g8_create_list. The dry-run
    branch keeps the user's original filters in the preview (verifiable via
    confirm_args), but the execution branch must call /search/contacts/save
    with the expanded filters."""

    @pytest.mark.asyncio
    async def test_filters_mode_save_uses_expanded(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_list"].fn

        client.post = AsyncMock(
            return_value={
                "data": {
                    "status": "processing",
                    "list_id": 351,
                    "estimated_total": 5,
                }
            }
        )
        await fn(
            title="VP test",
            filters=[
                {"field": "seniority_level", "operator": "any_of", "value": ["VP"]}
            ],
            max_results=5,
        )
        call = client.post.call_args_list[0]
        assert call.args[0] == "/search/contacts/save"
        outbound = call.args[1]["filters"][0]["value"]
        assert "Vice President" in outbound

    @pytest.mark.asyncio
    async def test_filters_mode_dry_run_keeps_original_filters_in_preview(self, client):
        """The confirmation widget must show what the user typed, not the
        expanded form, so they understand exactly what they asked for."""
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_list"].fn

        preview = await fn(
            title="VP test",
            filters=[
                {"field": "seniority_level", "operator": "any_of", "value": ["VP"]}
            ],
            max_results=5,
            dry_run=True,
        )
        assert hasattr(preview, "confirm_args")
        # The original "VP" filter is what's echoed back into confirm_args,
        # so when the widget fires the second call the SERVER expansion
        # runs on the original input (not double-expanded).
        echoed = preview.confirm_args["filters"][0]["value"]
        assert echoed == ["VP"]


# ---------------------------------------------------------------------------
# Bug 2: empty-mode g8_create_list return shape normalization
#
# Previously, calling g8_create_list with no source mode (just title) passed
# the raw backend response through, which had:
#   {status: "completed", id: N}
# but the contact_ids / rows / filters branches returned:
#   {status: "ok" | "processing", id: N, list_id: N, ...}
# That inconsistency confused callers and the UI. The empty mode is now
# wrapped in the same envelope: {status, id, list_id, total: 0, message}.
# ---------------------------------------------------------------------------


class TestCreateListEmptyModeReturnShape:
    @pytest.mark.asyncio
    async def test_empty_mode_returns_canonical_envelope(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_list"].fn

        # Backend returns the typical create-list ack.
        client.post = AsyncMock(
            return_value={"data": {"status": "completed", "id": 42}}
        )
        result = await fn(title="empty list test")
        dumped = result.model_dump()
        # Canonical envelope fields.
        assert dumped["status"] == "ok"
        assert dumped["id"] == 42
        assert dumped["list_id"] == 42
        assert dumped["total"] == 0
        assert "Created empty list 42" in dumped["message"]
        # Backward compat: the ``id`` field is still present so callers
        # that previously read result.id keep working.
        assert result.id == 42

    @pytest.mark.asyncio
    async def test_empty_mode_dry_run_renders_confirmation(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_list"].fn

        preview = await fn(title="empty list test", dry_run=True)
        # Dry-run branch still returns a ConfirmationPreview - widget gate
        # depends on confirm_tool being set.
        assert preview.confirm_tool == "g8_create_list"
        assert preview.confirm_args["dry_run"] is False
        assert preview.confirm_args["title"] == "empty list test"


# ---------------------------------------------------------------------------
# Bug 1: ConfirmationPreview must appear in the wave-3 tools' return type
# annotations so FastMCP includes the preview fields (preview, confirm_tool,
# confirm_args, summary, ...) in the union outputSchema rather than
# narrowing them away to ActionResult only.
# ---------------------------------------------------------------------------


class TestWave3ConfirmationReturnAnnotations:
    """Every wave-3 confirmation tool must declare ConfirmationPreview in
    its return union, so the FastMCP outputSchema preserves the preview
    field set. Without this, structuredContent.confirm_tool can be
    stripped and the widget renders the dry-run UI with no Confirm action."""

    def _annotation_string(self, fn):
        import inspect

        sig = inspect.signature(fn)
        return str(sig.return_annotation)

    def test_g8_create_list_includes_confirmation_preview(self, client):
        _, tools = _register_platform_tools(client)
        ann = self._annotation_string(tools["g8_create_list"].fn)
        assert "ConfirmationPreview" in ann

    def test_g8_add_to_list_includes_confirmation_preview(self, client):
        _, tools = _register_platform_tools(client)
        ann = self._annotation_string(tools["g8_add_to_list"].fn)
        assert "ConfirmationPreview" in ann

    def test_g8_enrich_contacts_includes_confirmation_preview(self, client):
        _, tools = _register_platform_tools(client)
        ann = self._annotation_string(tools["g8_enrich_contacts"].fn)
        assert "ConfirmationPreview" in ann

    def test_g8_add_to_sequence_includes_confirmation_preview(self, client):
        _, tools = _register_platform_tools(client)
        ann = self._annotation_string(tools["g8_add_to_sequence"].fn)
        assert "ConfirmationPreview" in ann

    def test_g8_gtm_launch_campaign_includes_confirmation_preview(self, client):
        """launch_campaign in gtm.py registers as g8_gtm_launch_campaign in
        ``all`` mode. We import via the dev/gtm registrar to keep the test
        self-contained."""
        from mcp.server import FastMCP
        from g8_mcp_server.tools import gtm

        server = FastMCP("test")
        gtm.register(server, client)
        # In gtm-only mode the tool name is g8_launch_campaign (no prefix).
        # In all mode it's g8_gtm_launch_campaign. Either way the annotation
        # must include ConfirmationPreview.
        all_tools = server._tool_manager._tools
        candidates = [
            n for n in all_tools if n.endswith("launch_campaign")
        ]
        assert candidates, "launch_campaign tool not registered"
        fn = all_tools[candidates[0]].fn
        ann = self._annotation_string(fn)
        assert "ConfirmationPreview" in ann


# ---------------------------------------------------------------------------
# g8_list_fields / g8_create_field / g8_delete_field
#
# Routes through /api/v1/fields (contacts) and /api/v1/fields/companies
# (companies). Backed by `developer_api/interfaces/v1/fields_router.py` with
# ColumnType enum that currently allows only "text". The MCP tools must:
#   1. pick the right path by entity (contacts vs companies)
#   2. forward optional list_id consistently as query OR body
#   3. propagate `data_type` to the backend so backend-side enum validation
#      surfaces (rather than us pre-validating and drifting from the enum)
# ---------------------------------------------------------------------------


class TestListFields:
    def test_tool_registered(self, client):
        _, tools = _register_platform_tools(client)
        assert "g8_list_fields" in tools

    @pytest.mark.asyncio
    async def test_default_lists_contact_fields(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_list_fields"].fn

        client.get = AsyncMock(
            return_value={
                "data": [
                    {"id": None, "title": "Email", "name": "email", "data_type": "text", "is_global": True},
                    {"id": 42, "title": "Job Level", "name": "job_level", "data_type": "text", "is_global": True},
                ]
            }
        )

        result = await fn()

        client.get.assert_called_once_with("/fields", None)
        assert hasattr(result, "fields")
        assert [f.title for f in result.fields] == ["Email", "Job Level"]
        assert result.entity == "contacts"
        assert result.list_id is None

    @pytest.mark.asyncio
    async def test_companies_uses_companies_path(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_list_fields"].fn

        client.get = AsyncMock(return_value={"data": []})
        result = await fn(entity="companies")

        client.get.assert_called_once_with("/fields/companies", None)
        assert result.entity == "companies"

    @pytest.mark.asyncio
    async def test_list_id_forwarded_as_query_param(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_list_fields"].fn

        client.get = AsyncMock(return_value={"data": []})
        result = await fn(entity="contacts", list_id=142)

        client.get.assert_called_once_with("/fields", {"list_id": 142})
        assert result.list_id == 142


class TestCreateField:
    def test_tool_registered(self, client):
        _, tools = _register_platform_tools(client)
        assert "g8_create_field" in tools

    @pytest.mark.asyncio
    async def test_minimal_body_for_global_contact_column(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_field"].fn

        client.post = AsyncMock(
            return_value={
                "data": {
                    "id": 7,
                    "title": "Job Level",
                    "data_type": "text",
                    "name": "job_level",
                    "list_id": None,
                    "is_global": True,
                }
            }
        )

        result = await fn(title="Job Level")

        client.post.assert_called_once_with(
            "/fields",
            {"title": "Job Level", "data_type": "text", "entity": "contacts"},
        )
        # ActionResult exposes id via the model
        assert result.id == 7

    @pytest.mark.asyncio
    async def test_list_scoped_company_column(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_field"].fn

        client.post = AsyncMock(
            return_value={
                "data": {
                    "id": 11,
                    "title": "Pricing Tier",
                    "data_type": "text",
                    "name": "pricing_tier",
                    "list_id": 99,
                    "is_global": False,
                }
            }
        )

        await fn(
            title="Pricing Tier",
            entity="companies",
            list_id=99,
            data_type="text",
        )

        client.post.assert_called_once_with(
            "/fields",
            {
                "title": "Pricing Tier",
                "data_type": "text",
                "entity": "companies",
                "list_id": 99,
            },
        )

    @pytest.mark.asyncio
    async def test_list_id_omitted_from_body_when_none(self, client):
        """list_id must NOT appear in the body when global, otherwise the
        backend would treat it as a list-scoped column (None vs missing matters
        for some validators)."""
        _, tools = _register_platform_tools(client)
        fn = tools["g8_create_field"].fn

        client.post = AsyncMock(return_value={"data": {"id": 1}})
        await fn(title="X")

        body = client.post.call_args_list[0].args[1]
        assert "list_id" not in body


class TestDeleteField:
    def test_tool_registered(self, client):
        _, tools = _register_platform_tools(client)
        assert "g8_delete_field" in tools

    @pytest.mark.asyncio
    async def test_default_delete_passes_entity_query(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_delete_field"].fn

        client.delete = AsyncMock(
            return_value={"data": {"column_id": 42, "deleted": True}}
        )

        await fn(column_id=42)

        client.delete.assert_called_once_with(
            "/fields/42", {"entity": "contacts"}
        )

    @pytest.mark.asyncio
    async def test_company_delete_with_list_scope_guard(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_delete_field"].fn

        client.delete = AsyncMock(
            return_value={"data": {"column_id": 11, "deleted": True}}
        )

        await fn(column_id=11, entity="companies", list_id=99)

        client.delete.assert_called_once_with(
            "/fields/11",
            {"entity": "companies", "list_id": 99},
        )

    @pytest.mark.asyncio
    async def test_returns_action_result_with_status(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_delete_field"].fn

        client.delete = AsyncMock(
            return_value={"data": {"column_id": 5, "deleted": True}}
        )
        result = await fn(column_id=5)

        # ActionResult uses extra=allow, so deleted/column_id pass through.
        extras = result.model_dump()
        assert extras.get("deleted") is True
        assert extras.get("column_id") == 5


class TestSetFieldValue:
    def test_tool_registered(self, client):
        _, tools = _register_platform_tools(client)
        assert "g8_set_field_value" in tools

    @pytest.mark.asyncio
    async def test_happy_path_contacts(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_set_field_value"].fn

        client.patch = AsyncMock(
            return_value={
                "data": {
                    "column_id": 42,
                    "record_id": 123,
                    "updated": True,
                }
            }
        )

        result = await fn(column_id=42, record_id=123, value="Director")

        client.patch.assert_called_once_with(
            "/fields/42/values",
            {"record_id": 123, "entity": "contacts", "value": "Director"},
        )
        # ActionResult exposes column_id / updated via extras (extra="allow")
        extras = result.model_dump()
        assert extras.get("updated") is True
        assert extras.get("column_id") == 42

    @pytest.mark.asyncio
    async def test_value_omitted_from_body_when_none(self, client):
        """value=None must NOT appear in the body so the backend treats the
        request as a clear (writes NULL into the column)."""
        _, tools = _register_platform_tools(client)
        fn = tools["g8_set_field_value"].fn

        client.patch = AsyncMock(return_value={"data": {"updated": True}})
        await fn(column_id=7, record_id=99)

        body = client.patch.call_args_list[0].args[1]
        assert "value" not in body
        assert body == {"record_id": 99, "entity": "contacts"}

    @pytest.mark.asyncio
    async def test_companies_entity_forwarded(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_set_field_value"].fn

        client.patch = AsyncMock(return_value={"data": {"updated": True}})
        await fn(column_id=11, record_id=55, value="A", entity="companies")

        client.patch.assert_called_once_with(
            "/fields/11/values",
            {"record_id": 55, "entity": "companies", "value": "A"},
        )

    @pytest.mark.asyncio
    async def test_returns_action_result_with_extras(self, client):
        _, tools = _register_platform_tools(client)
        fn = tools["g8_set_field_value"].fn

        client.patch = AsyncMock(
            return_value={
                "data": {
                    "column_id": 5,
                    "record_id": 222,
                    "updated": True,
                }
            }
        )
        result = await fn(column_id=5, record_id=222, value="x")

        extras = result.model_dump()
        assert extras.get("record_id") == 222
        assert extras.get("updated") is True


class TestFieldToolsCrmFiltering:
    """The new field tools should be filtered out in dev mode but kept in
    crm/campaigns/all modes - they manage CRM custom columns."""

    def test_dev_mode_drops_field_tools(self):
        from g8_mcp_server.server import _filter_tools_list

        tools = [
            {"name": "g8_list_fields"},
            {"name": "g8_create_field"},
            {"name": "g8_delete_field"},
            {"name": "g8_set_field_value"},
            {"name": "g8_scan_repo"},
        ]
        names = [t["name"] for t in _filter_tools_list(tools, "dev")]
        assert "g8_scan_repo" in names
        assert "g8_list_fields" not in names
        assert "g8_create_field" not in names
        assert "g8_delete_field" not in names
        assert "g8_set_field_value" not in names

    def test_crm_mode_keeps_field_tools(self):
        from g8_mcp_server.server import _filter_tools_list

        tools = [
            {"name": "g8_list_fields"},
            {"name": "g8_create_field"},
            {"name": "g8_delete_field"},
            {"name": "g8_set_field_value"},
        ]
        names = [t["name"] for t in _filter_tools_list(tools, "crm")]
        assert names == [
            "g8_list_fields",
            "g8_create_field",
            "g8_delete_field",
            "g8_set_field_value",
        ]
