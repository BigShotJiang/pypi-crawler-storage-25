"""Integration test — verify server starts and lists all tools."""

from __future__ import annotations

from pathlib import Path

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8ClientError
from g8_mcp_server.server import create_server


def _tool_names(server):
    return sorted(server._tool_manager._tools.keys())


class TestServerIntegration:
    def test_server_creates_successfully(self, monkeypatch):
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        assert server.name == "graph8"

    def test_tool_count(self, monkeypatch):
        """At least 86 tools register in `all` mode (post Upgrades 1-4).

        We intentionally use a floor rather than an exact count so new tools
        don't force us to touch this test every time. The floor tracks the
        actual registered inventory as of 2026-04-21: 85 content tools
        (platform 29 + gtm 21 + sync 14 + dev 11 + inbox 6 + skills 2 +
        forms 1 + snippet 1) + 1 meta tool (`g8_tool_search`) for
        progressive discovery = 86 total. The earlier floor of 84
        inadvertently dropped `skills.py`'s two tools.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        names = _tool_names(server)
        assert len(names) >= 86, f"Expected >= 86 tools, got {len(names)}: {names}"

    def test_progressive_discovery_meta_tool_registered(self, monkeypatch):
        """`g8_tool_search` must always be present — Upgrade 1 contract."""
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        assert "g8_tool_search" in _tool_names(server)

    @pytest.mark.asyncio
    async def test_every_tool_has_annotations(self, monkeypatch):
        """Every registered tool must declare ToolAnnotations.

        MCP clients use annotations (readOnlyHint / destructiveHint /
        idempotentHint / openWorldHint) to decide whether to auto-run a tool,
        prompt the user for confirmation, or cache its result. A tool with no
        annotations falls through to client defaults — which on strict
        clients means "don't auto-run anything" and on permissive clients
        means "auto-run without warning". Either extreme is wrong; we lock
        the contract here so new tools can't ship unannotated.

        The 2026-04-21 audit found 20 unannotated tools (23% of the surface)
        — this test prevents that regression.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        tools = await server.list_tools()
        missing = [t.name for t in tools if t.annotations is None]
        assert missing == [], (
            f"{len(missing)} tool(s) missing ToolAnnotations: {missing}. "
            f"Import _READ_ONLY / _WRITE / _DESTRUCTIVE from the module's preset "
            f"block and add it to the @server.tool(...) decorator."
        )

    def test_progressive_filter_hides_playbook_catalog(self, monkeypatch):
        """In v0.6.3 the playbook catalog tools are NOT always-on.

        Pre-0.6.3 `g8_list_skills` was always-on (the server instructions
        directed the agent to call it first). In v0.6.3 we renamed the tools
        to `g8_list_playbooks` / `g8_load_playbook` AND removed them from
        the always-on set so they no longer compete for default-catalog
        slots with the unrelated `g8_skill_*` / `g8_workflow_skill_*`
        authoring family. Both name surfaces now reach the agent only via
        `g8_tool_search`. This test locks that.
        """
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS, _filter_tools_progressive

        # Simulate the tools/list response before any session activation.
        tools = [
            {"name": "g8_list_playbooks"},
            {"name": "g8_load_playbook"},
            {"name": "g8_search_contacts"},
            {"name": "g8_gtm_create_campaign"},  # gated behind tool_search
        ]
        visible = {t["name"] for t in _filter_tools_progressive(tools, frozenset())}
        assert "g8_list_playbooks" not in visible, (
            "g8_list_playbooks is no longer always-on in v0.6.3 — agent reaches it via g8_tool_search"
        )
        assert "g8_load_playbook" not in visible, (
            "g8_load_playbook stays gated behind tool_search — keep the allowlist small"
        )
        # Legacy guard: the renamed-away names must never sneak back in.
        assert "g8_list_skills" not in _ALWAYS_ON_TOOLS, (
            "g8_list_skills was renamed to g8_list_playbooks in v0.6.3"
        )
        assert "g8_load_skill" not in _ALWAYS_ON_TOOLS
        assert "g8_tool_search" in _ALWAYS_ON_TOOLS

    def test_server_declares_tools_list_changed_capability(self, monkeypatch):
        """Server must advertise `tools.listChanged=True` so clients refresh on notification.

        Without this capability, clients have no reason to listen for the
        `notifications/tools/list_changed` message emitted by `g8_tool_search`
        when it activates new tools — the newly-activated schemas only become
        callable on the next session reconnect (Redis-cached 4h). With it,
        conformant clients re-fetch tools/list mid-session.

        Regression guard: if anyone factors the FastMCP init path and drops
        the `_enable_tool_list_changed_capability` wrapper, this test catches
        it before users hit the "activated tool not callable" surprise.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        init_options = server._mcp_server.create_initialization_options()
        tools_cap = init_options.capabilities.tools
        assert tools_cap is not None, "tools capability must be present when tools are registered"
        assert tools_cap.listChanged is True, (
            "tools.listChanged must be True so clients refresh tools/list "
            "on the notification emitted by g8_tool_search activation"
        )

    @pytest.mark.asyncio
    async def test_tool_search_emits_list_changed_on_new_activation(self, monkeypatch):
        """`g8_tool_search` must emit tools/list_changed when it activates new tools.

        This is the fix for the "activated tool not callable until reconnect"
        UX bug. The server persists activations to Redis (4h TTL), but clients
        only refresh `tools/list` on the notification - without the emit, the
        newly-activated tool schemas stay invisible for the rest of the
        session. Locked as a contract here.

        We also lock the `related_request_id` wire routing: the notification
        MUST be attached to the current request's stream so the Streamable-HTTP
        router sends it to the open POST response (rather than the GET stream
        we don't serve). Without this, the notification would be routed to
        GET_STREAM_KEY and silently dropped.
        """
        from unittest.mock import AsyncMock, MagicMock

        from mcp.types import ServerNotification, ToolListChangedNotification

        import g8_mcp_server.session_tools as session_tools

        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))

        # Use a unique session so local-cache state from other tests can't leak in.
        monkeypatch.setattr(session_tools, "_local_cache", {})

        server = create_server()
        tool_fn = server._tool_manager._tools["g8_tool_search"].fn

        # Stub a Context whose session tracks send_notification calls.
        # The real Context is a Pydantic BaseModel and we'd otherwise need
        # the full request-context plumbing; the tool only touches
        # `ctx.session.send_notification` + `ctx.request_id`, so a duck-typed
        # stub suffices.
        fake_session = MagicMock()
        fake_session.send_notification = AsyncMock()
        fake_ctx = MagicMock()
        fake_ctx.session = fake_session
        fake_ctx.request_id = "req-42"

        # First call: activates a previously-unseen tool -> must notify.
        result = await tool_fn(tool_names=["g8_get_contact_detail"], ctx=fake_ctx)
        assert "g8_get_contact_detail" in result.activated_session_tools
        assert fake_session.send_notification.await_count == 1, (
            "notification must fire when the activated set grows"
        )
        # Inspect the call args: must be a ServerNotification wrapping a
        # ToolListChangedNotification, attached to this request's id.
        call = fake_session.send_notification.await_args
        notif_arg = call.args[0] if call.args else call.kwargs.get("notification")
        assert isinstance(notif_arg, ServerNotification)
        assert isinstance(notif_arg.root, ToolListChangedNotification)
        assert call.kwargs.get("related_request_id") == "req-42", (
            "notification must be routed to the current request's stream so the "
            "SSE response forwards it to the client - without related_request_id "
            "the router sends to GET_STREAM_KEY which we do not serve"
        )

        # Second call with the same tool: nothing new -> must NOT re-notify.
        fake_session.send_notification.reset_mock()
        await tool_fn(tool_names=["g8_get_contact_detail"], ctx=fake_ctx)
        assert fake_session.send_notification.await_count == 0, (
            "no notification when the activated set is unchanged - avoids spam on repeat searches"
        )

        # Preview mode (activate=False): nothing activates, nothing to notify.
        fake_session.send_notification.reset_mock()
        await tool_fn(
            tool_names=["g8_gtm_create_campaign"], activate=False, ctx=fake_ctx
        )
        assert fake_session.send_notification.await_count == 0, (
            "activate=False must not emit - the client's view hasn't changed"
        )

    @pytest.mark.asyncio
    async def test_tool_search_tolerates_notification_failure(self, monkeypatch):
        """Notification failure must never break the tool-search response.

        Transport-level SSE write races, missing sessions, or older SDK
        clients that don't support the method must all degrade silently —
        the activation is already persisted in Redis and will surface on the
        next reconnect. The tool call itself must still succeed.
        """
        from unittest.mock import AsyncMock, MagicMock

        import g8_mcp_server.session_tools as session_tools

        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        monkeypatch.setattr(session_tools, "_local_cache", {})

        server = create_server()
        tool_fn = server._tool_manager._tools["g8_tool_search"].fn

        fake_session = MagicMock()
        fake_session.send_notification = AsyncMock(
            side_effect=RuntimeError("simulated transport error")
        )
        fake_ctx = MagicMock()
        fake_ctx.session = fake_session
        fake_ctx.request_id = "req-err"

        # Must not raise despite the inner exception.
        result = await tool_fn(tool_names=["g8_get_contact_detail"], ctx=fake_ctx)
        assert result.activated_session_tools  # activation still persisted
        assert fake_session.send_notification.await_count == 1

        # A None ctx (e.g. when called outside an MCP request) is also fine.
        result2 = await tool_fn(tool_names=["g8_get_contact_deals"], ctx=None)
        assert "g8_get_contact_deals" in result2.activated_session_tools

    def test_remote_app_uses_sse_response_mode(self, monkeypatch):
        """The remote MCP app MUST run in SSE response mode.

        In JSON-response mode the Streamable-HTTP SDK discards server-initiated
        notifications that arrive on a request stream (only a JSONRPCResponse
        or JSONRPCError closes the loop; everything else is logger.debug'd and
        dropped). In SSE mode, every event_message on the stream is flushed to
        the client as an SSE frame before the response closes it. That is the
        only mode in which `notifications/tools/list_changed` actually reaches
        the client mid-session and makes activated tools callable without a
        reconnect. Locked here so a well-meaning revert of json_response cannot
        silently break mid-session tool activation.
        """
        from g8_mcp_server.server import create_remote_app

        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))

        app = create_remote_app()
        # _RemoteMCPApp holds the session manager; introspect its json_response
        # setting - False means SSE mode, True means the notification-dropping
        # JSON-only fast path.
        assert app._sm.json_response is False, (
            "remote MCP app must use SSE response mode (json_response=False) so "
            "notifications/tools/list_changed reach the client; see "
            "mcp_server/g8_mcp_server/server.py create_remote_app()"
        )

    def test_rewrite_tools_list_body_handles_json_mode(self):
        """JSON-response tools/list bodies must still be filtered correctly.

        Regression guard: even though our remote app ships in SSE mode today,
        the rewriter is the single source of truth for tool filtering. If
        anyone ever flips a deploy back to JSON mode (e.g. for a debug probe),
        the filter must still work.
        """
        import json as _json

        from g8_mcp_server.server import _rewrite_tools_list_body

        body = _json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": [
                {"name": "g8_tool_search"},
                {"name": "g8_get_contact_detail"},   # not always-on, not activated
                {"name": "g8_search_contacts"},      # always-on (universal read entry point)
                {"name": "g8_list_playbooks"},       # NOT always-on in v0.6.3+ (renamed from g8_list_skills)
            ]},
        }).encode()

        out = _rewrite_tools_list_body(body, tool_group="all", activated=frozenset())
        resp = _json.loads(out)
        names = {t["name"] for t in resp["result"]["tools"]}
        assert "g8_tool_search" in names, "g8_tool_search is always-on"
        assert "g8_search_contacts" in names, "g8_search_contacts is always-on"
        assert "g8_get_contact_detail" not in names, (
            "g8_get_contact_detail is behind progressive discovery and should be hidden "
            "from tools/list until activated"
        )
        assert "g8_list_playbooks" not in names, (
            "g8_list_playbooks is behind progressive discovery in v0.6.3+ - "
            "agent reaches it via g8_tool_search"
        )

    def test_rewrite_tools_list_body_handles_sse_mode(self):
        """SSE-response tools/list bodies must be filtered correctly.

        End-to-end scenario: in SSE mode the handler writes frames like
            event: message\\ndata: <jsonrpc-response>\\n\\n
        The rewriter must locate the data: line, parse the JSON payload,
        filter the tools array, and re-serialise the SSE frame with the
        filtered body. Anything else in the stream (priming events,
        notifications that may ride along) must pass through unchanged.
        """
        import json as _json

        from g8_mcp_server.server import _rewrite_tools_list_body

        payload = _json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": [
                {"name": "g8_tool_search"},
                {"name": "g8_get_contact_detail"},
                {"name": "g8_search_contacts"},      # always-on (universal read entry point)
                {"name": "g8_gtm_create_campaign"},  # not always-on
            ]},
        })
        # Pretend a notification rode along before the response (realistic
        # shape for any future rewriter use on non-list methods).
        notif_payload = _json.dumps({
            "jsonrpc": "2.0",
            "method": "notifications/tools/list_changed",
        })
        sse_body = (
            f"event: message\ndata: {notif_payload}\n\n"
            f"event: message\ndata: {payload}\n\n"
        ).encode()

        # Activate get_contact_detail for this fake session.
        out = _rewrite_tools_list_body(
            sse_body, tool_group="all", activated=frozenset({"g8_get_contact_detail"})
        )
        out_text = out.decode()

        # The notification frame must pass through verbatim.
        assert notif_payload in out_text, "notification frames must not be mangled"

        # The response frame must contain the filtered tool list.
        # Find the response data line and parse it.
        response_data = None
        for frame in out_text.split("\n\n"):
            for line in frame.split("\n"):
                if line.startswith("data: ") and '"result"' in line:
                    response_data = _json.loads(line[len("data: "):])
                    break
        assert response_data is not None, "rewritten SSE body must retain the response frame"
        names = {t["name"] for t in response_data["result"]["tools"]}
        assert "g8_tool_search" in names
        assert "g8_search_contacts" in names
        assert "g8_get_contact_detail" in names, "activated tool must pass the filter"
        assert "g8_gtm_create_campaign" not in names, "non-activated non-always-on tool must be hidden"

        # Content-Type headers would be text/event-stream; the body must still
        # be parseable as SSE (blank-line separated frames).
        assert "event: message" in out_text
        assert out_text.count("\n\n") >= 2, "SSE frame separators preserved"

    def test_rewrite_tools_list_body_tolerates_malformed_input(self):
        """Malformed bodies must fall through unmodified rather than 500.

        If the upstream handler ever returns junk (error path, transport
        truncation, mid-stream disconnect), the filter must not crash the
        response path - we'd rather ship unfiltered content than a 500.
        """
        from g8_mcp_server.server import _rewrite_tools_list_body

        junk = b"not json, not sse, just bytes"
        assert _rewrite_tools_list_body(junk, "all", frozenset()) == junk

    @pytest.mark.asyncio
    async def test_tool_search_http_response_contains_list_changed_frame(self, monkeypatch):
        """END-TO-END: a real HTTP POST to g8_tool_search must yield an SSE
        body that contains BOTH the notifications/tools/list_changed frame
        AND the tool-call response frame.

        This is the only test that actually proves the fix works on the wire.
        Unit tests can only show we CALLED the emit method; this test shows
        the notification survives the SDK router, the SSE writer, and the
        ASGI pipeline all the way to the HTTP response body.

        Without this, the server could claim `tools.listChanged=True`, the
        tool could claim it emitted a notification, yet the client would
        never see it - which is exactly the bug we're fixing.

        We drive a real uvicorn server because Starlette's TestClient sends
        `http.disconnect` right after the request body in its sync-to-async
        bridge, which prematurely terminates sse-starlette's streaming loop.
        Real uvicorn only reports disconnect when the TCP connection
        actually closes - matching production behaviour.
        """
        import asyncio
        import socket
        import threading
        import time

        import httpx
        import uvicorn
        from starlette.applications import Starlette
        from starlette.routing import Mount

        import g8_mcp_server.server as srv_module
        import g8_mcp_server.session_tools as session_tools

        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        # Fresh local cache so activations from other tests can't leak in.
        monkeypatch.setattr(session_tools, "_local_cache", {})
        # Skip OAuth introspection; any bearer token -> direct API key.
        monkeypatch.setattr(srv_module, "_INTROSPECT_CLIENT_ID", "")
        # Disable rate limiting so the test never flakes on it.
        async def _allow(_token):
            return True, 0
        monkeypatch.setattr(srv_module, "_check_mcp_rate_limit", _allow)

        # Pick a free port to avoid collisions with other uvicorn instances.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]

        remote_app = srv_module.create_remote_app()
        app = Starlette(routes=[Mount("/mcp", app=remote_app)])
        config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", loop="asyncio")
        server = uvicorn.Server(config)

        def _run():
            asyncio.run(server.serve())

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
        try:
            # Wait for the server to accept connections.
            for _ in range(50):
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=0.1):
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError(f"uvicorn on port {port} never came up")

            base = f"http://127.0.0.1:{port}"
            headers = {
                "Authorization": "Bearer test_key_short",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
            }
            call_req = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "g8_tool_search",
                    "arguments": {"tool_names": ["g8_get_contact_detail"]},
                },
            }

            async with httpx.AsyncClient(timeout=15.0) as client:
                async with client.stream(
                    "POST", f"{base}/mcp/", json=call_req, headers=headers
                ) as call_resp:
                    assert call_resp.status_code == 200, (
                        f"tools/call failed: {call_resp.status_code}"
                    )
                    call_content_type = call_resp.headers.get("content-type", "")
                    chunks = []
                    async for chunk in call_resp.aiter_bytes():
                        chunks.append(chunk)
                    body = b"".join(chunks).decode()

            # 1) Response mode must be SSE.
            assert "text/event-stream" in call_content_type, (
                f"expected SSE response, got Content-Type={call_content_type!r}. "
                f"Body head: {body[:200]!r}"
            )
            # 2) The notifications/tools/list_changed frame MUST be in the
            #    body - this is the wire evidence the fix works.
            assert "notifications/tools/list_changed" in body, (
                "notifications/tools/list_changed missing from HTTP response body. "
                "This is the exact bug we're fixing - the notification is not "
                f"reaching the client. Body: {body[:1500]!r}"
            )
            # 3) The tool-call response frame must also be present and must
            #    come AFTER the notification (clients process events in order:
            #    notification first so the client refreshes tools/list, then
            #    response delivers the tool output).
            notif_idx = body.index("notifications/tools/list_changed")
            resp_marker = '"id":2'
            resp_idx = body.find(resp_marker, notif_idx)
            if resp_idx < 0:
                resp_marker = '"id": 2'
                resp_idx = body.find(resp_marker, notif_idx)
            assert resp_idx > notif_idx, (
                "tool-call response must follow the notification in SSE order. "
                f"notif at {notif_idx}, resp at {resp_idx}. Body: {body[:1500]!r}"
            )

            # 4) Activation must also be persisted in the session cache.
            from g8_mcp_server.session_tools import get_activated, session_id_for_key
            activated = await get_activated(session_id_for_key("test_key_short"))
            assert "g8_get_contact_detail" in activated, (
                "Redis-side activation must persist alongside the notification emit"
            )
        finally:
            server.should_exit = True
            thread.join(timeout=3.0)

    @pytest.mark.asyncio
    async def test_prompts_match_mode(self, monkeypatch):
        """Prompts must only register when their referenced tools are also loaded.

        The dev-mode prompts reference repo-scoped tools (`g8_connect_repo`,
        `g8_scan_repo`, `g8_install_spine`, `g8_apply_install`, `g8_search_kb`,
        plus `g8_get_campaign` with a `repo_id` param). The gtm-mode prompts
        reference org-scoped tools (`g8_find_contacts`,
        `g8_create_list`, `g8_add_to_sequence`, `g8_list_inbox`, plus
        `g8_get_campaign` without `repo_id`).

        Before the 2026-04-21 fix, `prompts.register(server)` was called
        unconditionally, so a user running `G8_MCP_MODE=gtm` saw three dev-mode
        prompts that referenced tools their server instance hadn't loaded. If
        they tried to execute the prompts, the model would call phantom tool
        names and get back "unknown tool" errors.

        This test locks the mode-prompt contract: `dev` sees only dev prompts,
        `gtm` sees only gtm prompts, `all` sees both sets.
        """
        import importlib

        import g8_mcp_server.server as srv

        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))

        dev_prompts = {"gtm_setup", "campaign_review", "icp_refinement"}
        gtm_prompts = {
            "prospect_outreach",
            "campaign_review_gtm",
            "inbox_triage",
            "competitor_intent_setup",
        }

        expected = {
            "dev": dev_prompts,
            "gtm": gtm_prompts,
            "all": dev_prompts | gtm_prompts,
        }

        for mode, want in expected.items():
            monkeypatch.setenv("G8_MCP_MODE", mode)
            importlib.reload(srv)
            server = srv.create_server()
            got = {p.name for p in await server.list_prompts()}
            assert got == want, (
                f"mode={mode}: expected prompts {sorted(want)}, got {sorted(got)}. "
                f"Dev prompts must only register in dev/all; gtm prompts must "
                f"only register in gtm/all."
            )

        # Restore default mode for downstream tests in this process.
        monkeypatch.setenv("G8_MCP_MODE", "all")
        importlib.reload(srv)

    def test_ad_images_app_surface_registered(self, monkeypatch):
        """Upgrade 4 spike: HTML + text ad-images resources must both register."""
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://campaigns/{campaign_id}/ad-images"
        txt_uri = "g8://campaigns/{campaign_id}/ad-images.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_sequence_preview_app_surface_registered(self, monkeypatch):
        """Upgrade 4 extension: sequence-preview HTML + text resources both register.

        Pattern matches the ad-images app surface — explicit `/preview` suffix
        on both URIs avoids ambiguity between the open `{sequence_id}` capture
        and the `.txt` variant that would otherwise be treated as part of the
        captured id.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://sequences/{sequence_id}/preview"
        txt_uri = "g8://sequences/{sequence_id}/preview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_persona_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #3: persona dashboard HTML + text resources register.

        Persona dashboard is a STATIC resource (no URI template variables) —
        one dashboard per authenticated org, derived from the API key. So we
        check `_resources` not `_templates`.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://personas/dashboard"
        txt_uri = "g8://personas/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_kb_library_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #4: KB library HTML + text resources register.

        Like the persona dashboard, this is a STATIC resource — org-scoped,
        no URI template variables.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://kb/library"
        txt_uri = "g8://kb/library.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_icp_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #5: ICP dashboard HTML + text resources register.

        Org-scoped static resource (no URI capture) — like personas + KB.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://icps/dashboard"
        txt_uri = "g8://icps/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_campaigns_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #6: campaigns dashboard HTML + text resources register.

        Org-scoped static resource — one dashboard per authenticated org.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://campaigns/dashboard"
        txt_uri = "g8://campaigns/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_inbox_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #7: inbox dashboard HTML + text resources register.

        Org-scoped static resource — threads grouped by channel.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://inbox/dashboard"
        txt_uri = "g8://inbox/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_lists_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #8: lists dashboard HTML + text resources register.

        Org-scoped static resource — CRM lists grouped by type.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://lists/dashboard"
        txt_uri = "g8://lists/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_sequences_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #9: sequences dashboard HTML + text resources register.

        Org-scoped static resource — sequences grouped by status.
        Distinct from sequence-preview (per-sequence URI-templated surface #2).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://sequences/dashboard"
        txt_uri = "g8://sequences/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_activities_feed_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #10: activity feed HTML + text resources register.

        Org-scoped static resource — activities grouped by date (newest first).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://activities/feed"
        txt_uri = "g8://activities/feed.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_deals_pipeline_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #11: deals pipeline HTML + text resources register.

        Org-scoped static resource — deals grouped by stage with per-stage
        subtotals and a grand-total pipeline value.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://deals/pipeline"
        txt_uri = "g8://deals/pipeline.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_tasks_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #12: tasks dashboard HTML + text resources register.

        Org-scoped static resource — tasks grouped by status with priority
        badges and overdue highlighting.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://tasks/dashboard"
        txt_uri = "g8://tasks/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_campaign_ideas_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #13: campaign ideas HTML + text resources register.

        Org-scoped static resource — ideation board with favorited + created
        sorting. Renders ideas as cards (not a grouped dashboard) since the
        underlying data has no natural bucketing.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://campaigns/ideas"
        txt_uri = "g8://campaigns/ideas.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_pipelines_overview_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #14: pipelines overview HTML + text resources register.

        Org-scoped static resource — pipeline structure rendered as horizontal
        flow of numbered, arrow-connected stage chips. Complementary to the
        deals pipeline surface (#11) which shows deals INSIDE the stages.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://pipelines/overview"
        txt_uri = "g8://pipelines/overview.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_global_context_library_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #15: global context library HTML + text resources register.

        Org-scoped static resource — Studio's 44-doc knowledge base grouped
        by category (context / intelligence / research / brief) with status
        badges and last-updated timestamps.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://global-context/library"
        txt_uri = "g8://global-context/library.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_audience_syncs_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #16: audience syncs dashboard HTML + text resources register.

        Org-scoped static resource — ad platform audience sync configs grouped
        by platform (Meta / LinkedIn / Google / X / other) with active-state
        dot, refresh cadence, last-sync timestamp, and colored status badge.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://audience-syncs/dashboard"
        txt_uri = "g8://audience-syncs/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_crm_syncs_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #17: CRM integrations dashboard HTML + text resources register.

        Org-scoped static resource — HubSpot / Salesforce / Pipedrive / Zoho /
        SugarCRM connection state with per-row connection dot, account name,
        last-sync timestamp, and colored status badge. Single card (no provider
        grouping — typical CRM counts are 1-3 and grouping adds noise).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        resources = server._resource_manager._resources
        html_uri = "g8://crm-syncs/dashboard"
        txt_uri = "g8://crm-syncs/dashboard.txt"
        assert html_uri in resources
        assert txt_uri in resources
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

    def test_sync_runs_history_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #18: sync runs history HTML + text resources register.

        URI-templated per audience sync config — run timeline with status
        badge, started/finished timestamps, member-count delta (+added /
        -removed), and inline error messages. Uses the resource-template
        manager (not static _resources) because of the {config_id} capture.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://audience-syncs/{config_id}/runs"
        txt_uri = "g8://audience-syncs/{config_id}/runs.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_crm_fields_schema_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #19: CRM fields schema HTML + text resources register.

        URI-templated per CRM provider (hubspot / salesforce / pipedrive /
        zoho / sugarcrm). Contact-level field map with type chips + required +
        custom badges. Uses resource-template manager for the {provider}
        capture.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://crm-syncs/{provider}/fields"
        txt_uri = "g8://crm-syncs/{provider}/fields.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_inbox_thread_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #20: inbox thread detail HTML + text resources register.

        URI-templated on reply_id. Full-conversation view with inbound vs
        outbound message styling, tags, and assignees. Complements
        g8://inbox/dashboard (list) by letting callers drill into a single
        thread without leaving Claude.ai. Defaults to channel=email; other
        channels queryable via the sync.get_reply tool.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://inbox/threads/{reply_id}"
        txt_uri = "g8://inbox/threads/{reply_id}.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_campaign_documents_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #21: campaign documents HTML + text resources register.

        URI-templated on campaign_id. Per-campaign document library grouped
        by folder_path (strategy/brief/research/intelligence/messaging/copy/
        email/sequence/landing/ads/creative) with status chips (ready /
        generating / pending / stale / failed) and type chips. Complements
        surface #15 (org-wide global context library) by giving a
        campaign-scoped lens on what has been generated and what is still
        missing or failed.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://campaigns/{campaign_id}/documents"
        txt_uri = "g8://campaigns/{campaign_id}/documents.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_campaign_sequence_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #22: campaign sequence HTML + text resources register.

        URI-templated on campaign_id. Per-campaign DESIGNED step plan
        grouped by day offset (Day 0 kickoff, Day 2, etc.). Complements
        surface #2 (sequence preview — per sequence_id execution view) and
        surface #9 (sequences dashboard — org-wide list) by giving a
        campaign-scoped plan of what steps will run on which days.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://campaigns/{campaign_id}/sequence"
        txt_uri = "g8://campaigns/{campaign_id}/sequence.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_sequence_analytics_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #23: sequence analytics HTML + text resources register.

        URI-templated on sequence_id. Per-sequence performance dashboard
        with overview stats + per-step delivery/reply/bounce rate bars +
        first-step response rates (24h/48h/7d) + 20-day send timeline.
        Complements surface #2 (sequence preview — step structure) and
        surface #9 (sequences dashboard — org list) with the performance
        lens.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://sequences/{sequence_id}/analytics"
        txt_uri = "g8://sequences/{sequence_id}/analytics.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_deal_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #24: deal detail HTML + text resources register.

        URI-templated on deal_id. Per-deal drilldown with amount, stage,
        close date, pipeline funnel ladder, description, linked company.
        Complements surface #11 (deals pipeline — org-wide list) with the
        per-deal lens.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://deals/{deal_id}"
        txt_uri = "g8://deals/{deal_id}.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_contact_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #25: contact detail HTML + text resources register.

        URI-templated on contact_id. Per-contact drilldown with profile,
        contact methods, linked deals, open tasks, and recent notes.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://contacts/{contact_id}"
        txt_uri = "g8://contacts/{contact_id}.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_company_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #26: company detail HTML + text resources register.

        URI-templated on company_id. Per-company drilldown with size badge,
        stat-card grid, overview, web presence, description, and linked
        contacts + deals. Completes the CRM triad with surfaces #24 and #25.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://companies/{company_id}"
        txt_uri = "g8://companies/{company_id}.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_campaign_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #27: campaign detail HTML + text resources register.

        URI-templated on campaign_id at `/overview` suffix (to avoid any
        collision with the static `g8://campaigns/dashboard` +
        `g8://campaigns/ideas` resources). Per-campaign top-level overview
        with status badge, stat-card grid, channel chips, narrative
        (brief / core concept / primary hook), and per-status document
        tally. Complements surfaces #6, #21, #22.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://campaigns/{campaign_id}/overview"
        txt_uri = "g8://campaigns/{campaign_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

    def test_audience_sync_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #28: audience sync config detail HTML + text resources register.

        URI-templated on config_id at `/overview` suffix to avoid collision
        with the sibling `g8://audience-syncs/{config_id}/runs` template
        AND to prevent the `.txt` variant from being shadowed by the
        HTML template (FastMCP template regex is `[^/]+` which would
        otherwise capture `42.txt` into `{config_id}` before the text
        template is tried). Per-config overview with platform / audience /
        cadence / mode / last-sync + recent runs preview. Complements
        surface #16 (dashboard) and #18 (runs history).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://audience-syncs/{config_id}/overview"
        txt_uri = "g8://audience-syncs/{config_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # URI disambiguation — the /overview suffix must not collide with
        # /runs sibling or shadow the .txt variant.
        runs_html_uri = "g8://audience-syncs/{config_id}/runs"
        runs_txt_uri = "g8://audience-syncs/{config_id}/runs.txt"
        assert runs_html_uri in templates, "surface #18 sibling must still register"
        assert runs_txt_uri in templates, "surface #18 sibling must still register"

        # Confirm no duplicate shadowing at dispatch time for sample URIs.
        sample_uris = [
            ("g8://audience-syncs/42/overview", html_uri),
            ("g8://audience-syncs/42/overview.txt", txt_uri),
            ("g8://audience-syncs/42/runs", runs_html_uri),
            ("g8://audience-syncs/42/runs.txt", runs_txt_uri),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_sequence_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #29: sequence detail HTML + text resources register.

        URI-templated on sequence_id at `/overview` suffix. Three sibling
        surfaces already live under this prefix: `/preview` (surface #2,
        step structure) and `/analytics` (surface #23, performance). The
        `/overview` choice disambiguates from both, AND from the `.txt`
        fallback which would otherwise be shadowed by FastMCP's `[^/]+`
        regex capturing `seq123.txt` into `{sequence_id}`.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://sequences/{sequence_id}/overview"
        txt_uri = "g8://sequences/{sequence_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # URI disambiguation — the /overview suffix must not collide with
        # the sibling /preview or /analytics templates, and must not be
        # shadowed by the .txt fallback.
        preview_html_uri = "g8://sequences/{sequence_id}/preview"
        preview_txt_uri = "g8://sequences/{sequence_id}/preview.txt"
        analytics_html_uri = "g8://sequences/{sequence_id}/analytics"
        analytics_txt_uri = "g8://sequences/{sequence_id}/analytics.txt"
        assert preview_html_uri in templates, "surface #2 sibling must still register"
        assert preview_txt_uri in templates, "surface #2 sibling must still register"
        assert analytics_html_uri in templates, "surface #23 sibling must still register"
        assert analytics_txt_uri in templates, "surface #23 sibling must still register"

        # Confirm no duplicate shadowing at dispatch time for sample URIs.
        sample_uris = [
            ("g8://sequences/seq_42/overview", html_uri),
            ("g8://sequences/seq_42/overview.txt", txt_uri),
            ("g8://sequences/seq_42/preview", preview_html_uri),
            ("g8://sequences/seq_42/preview.txt", preview_txt_uri),
            ("g8://sequences/seq_42/analytics", analytics_html_uri),
            ("g8://sequences/seq_42/analytics.txt", analytics_txt_uri),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_campaign_document_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #30: campaign document detail HTML + text resources register.

        URI-templated on both campaign_id AND document_id, with `/overview`
        suffix to prevent the `.txt` fallback from being shadowed by
        FastMCP's `[^/]+` regex. This surface lives deeper in the URI
        space than its sibling surfaces:
          - g8://campaigns/{campaign_id}/overview            (surface #27, 3 segs)
          - g8://campaigns/{campaign_id}/documents           (surface #21, 3 segs)
          - g8://campaigns/{campaign_id}/documents/{did}/overview  (surface #30, 5 segs)
        Dispatch must NOT shadow any of them.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://campaigns/{campaign_id}/documents/{document_id}/overview"
        txt_uri = "g8://campaigns/{campaign_id}/documents/{document_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling surfaces at shallower URI depth must still register.
        campaign_overview_html = "g8://campaigns/{campaign_id}/overview"
        campaign_overview_txt = "g8://campaigns/{campaign_id}/overview.txt"
        campaign_docs_html = "g8://campaigns/{campaign_id}/documents"
        campaign_docs_txt = "g8://campaigns/{campaign_id}/documents.txt"
        assert campaign_overview_html in templates, "surface #27 must still register"
        assert campaign_overview_txt in templates, "surface #27 must still register"
        assert campaign_docs_html in templates, "surface #21 must still register"
        assert campaign_docs_txt in templates, "surface #21 must still register"

        # Dispatch — sample URIs at each depth must map to exactly one template.
        sample_uris = [
            ("g8://campaigns/cmp_42/documents/doc_7/overview", html_uri),
            ("g8://campaigns/cmp_42/documents/doc_7/overview.txt", txt_uri),
            ("g8://campaigns/cmp_42/overview", campaign_overview_html),
            ("g8://campaigns/cmp_42/overview.txt", campaign_overview_txt),
            ("g8://campaigns/cmp_42/documents", campaign_docs_html),
            ("g8://campaigns/cmp_42/documents.txt", campaign_docs_txt),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_webhook_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #31: webhook detail HTML + text resources register.

        URI-templated by webhook_id with the `/overview` suffix idiom — the
        `.txt` fallback must not be shadowed by FastMCP's `[^/]+` regex.
        The surface lives alongside other `g8://webhooks/...` URIs but at
        its own depth:
          - g8://webhooks/{webhook_id}/overview      (surface #31, 3 segs)
          - g8://webhooks/{webhook_id}/overview.txt  (surface #31, text)
        Dispatch must not shadow sibling surfaces at other URI depths.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://webhooks/{webhook_id}/overview"
        txt_uri = "g8://webhooks/{webhook_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # A couple of sibling surfaces must still register unchanged — the
        # new surface shouldn't hijack their URIs.
        campaign_overview_html = "g8://campaigns/{campaign_id}/overview"
        campaign_doc_detail_html = (
            "g8://campaigns/{campaign_id}/documents/{document_id}/overview"
        )
        assert campaign_overview_html in templates, "surface #27 must still register"
        assert campaign_doc_detail_html in templates, "surface #30 must still register"

        # Dispatch — each sample URI must map to exactly one template.
        sample_uris = [
            ("g8://webhooks/wh_abc123/overview", html_uri),
            ("g8://webhooks/wh_abc123/overview.txt", txt_uri),
            # webhook id allowed to contain dots (though not slashes) —
            # the FastMCP [^/]+ regex permits them, and the renderer
            # HTML-escapes everything.
            ("g8://webhooks/wh.abc.123/overview", html_uri),
            # siblings at other depths still dispatch correctly
            ("g8://campaigns/cmp_42/overview", campaign_overview_html),
            (
                "g8://campaigns/cmp_42/documents/doc_7/overview",
                campaign_doc_detail_html,
            ),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_repo_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #32: repo detail HTML + text resources register.

        URI-templated by repo_id with the `/overview` suffix idiom — the
        `.txt` fallback must not be shadowed by FastMCP's `[^/]+` regex
        (particularly important for `g8://repos/...` which already has
        3-segment URIs like `/scan` and `/kb`, and 4+ segment URIs like
        `/kb/{doc_id}` and `/campaigns/{campaign_id}/brief`).

          - g8://repos/{repo_id}/overview      (surface #32, 3 segs)
          - g8://repos/{repo_id}/overview.txt  (surface #32, text)
        Dispatch must not shadow sibling surfaces at other URI depths.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://repos/{repo_id}/overview"
        txt_uri = "g8://repos/{repo_id}/overview.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling repo resources must still register — surface #32 lives
        # alongside these without swallowing their URIs.
        repo_scan = "g8://repos/{repo_id}/scan"
        repo_kb = "g8://repos/{repo_id}/kb"
        repo_kb_doc = "g8://repos/{repo_id}/kb/{doc_id}"
        repo_campaigns = "g8://repos/{repo_id}/campaigns"
        repo_campaign_brief = (
            "g8://repos/{repo_id}/campaigns/{campaign_id}/brief"
        )
        for sibling in (
            repo_scan,
            repo_kb,
            repo_kb_doc,
            repo_campaigns,
            repo_campaign_brief,
        ):
            assert sibling in templates, (
                f"sibling repo resource {sibling} must still register"
            )

        # Dispatch — each sample URI must map to exactly one template.
        sample_uris = [
            ("g8://repos/repo_abc123/overview", html_uri),
            ("g8://repos/repo_abc123/overview.txt", txt_uri),
            # repo id allowed to contain dots (though not slashes)
            ("g8://repos/repo.abc.123/overview", html_uri),
            # siblings at other URI shapes still dispatch correctly
            ("g8://repos/repo_abc123/scan", repo_scan),
            ("g8://repos/repo_abc123/kb", repo_kb),
            ("g8://repos/repo_abc123/kb/doc_42", repo_kb_doc),
            ("g8://repos/repo_abc123/campaigns", repo_campaigns),
            (
                "g8://repos/repo_abc123/campaigns/cmp_7/brief",
                repo_campaign_brief,
            ),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_sync_errors_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #33: audience-sync errors HTML + text resources register.

        URI-templated by config_id with the `/errors` suffix. The
        surface lives alongside existing `g8://audience-syncs/...`
        siblings (#17 history, #28 overview) — dispatch must not
        shadow any of them.

          - g8://audience-syncs/{config_id}/errors      (surface #33, 3 segs)
          - g8://audience-syncs/{config_id}/errors.txt  (surface #33, text)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://audience-syncs/{config_id}/errors"
        txt_uri = "g8://audience-syncs/{config_id}/errors.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling audience-sync resources must still register
        overview = "g8://audience-syncs/{config_id}/overview"
        overview_txt = "g8://audience-syncs/{config_id}/overview.txt"
        runs = "g8://audience-syncs/{config_id}/runs"
        runs_txt = "g8://audience-syncs/{config_id}/runs.txt"
        for sibling in (overview, overview_txt, runs, runs_txt):
            assert sibling in templates, (
                f"sibling audience-sync resource {sibling} must still register"
            )

        # Unambiguous dispatch across all sibling URI shapes
        sample_uris = [
            ("g8://audience-syncs/42/errors", html_uri),
            ("g8://audience-syncs/42/errors.txt", txt_uri),
            ("g8://audience-syncs/42/overview", overview),
            ("g8://audience-syncs/42/overview.txt", overview_txt),
            ("g8://audience-syncs/42/runs", runs),
            ("g8://audience-syncs/42/runs.txt", runs_txt),
            # config id with dots (backend uses int IDs but the URI
            # template uses [^/]+ so we want to be safe)
            ("g8://audience-syncs/42.clone/errors", html_uri),
        ]
        for uri, expected in sample_uris:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

    def test_contact_notes_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #34: per-contact notes HTML + text resources register.

        URI-templated by contact_id with the `/notes` suffix. The
        surface lives alongside the existing `g8://contacts/{contact_id}`
        detail resource (#23) — dispatch must not shadow it or its
        `.txt` sibling.

          - g8://contacts/{contact_id}/notes      (surface #34, 3 segs)
          - g8://contacts/{contact_id}/notes.txt  (surface #34, text)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://contacts/{contact_id}/notes"
        txt_uri = "g8://contacts/{contact_id}/notes.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling contact-detail resources must still register
        detail = "g8://contacts/{contact_id}"
        detail_txt = "g8://contacts/{contact_id}.txt"
        for sibling in (detail, detail_txt):
            assert sibling in templates, (
                f"sibling contact resource {sibling} must still register"
            )

        # Unambiguous dispatch across all sibling URI shapes.
        #
        # NB: FastMCP URI templates use the regex [^/]+ for each path
        # segment, so {contact_id} in the detail template matches
        # "42.txt" (note the `.txt`) — which is the whole point of the
        # `.txt` sibling existing as a separate template. We only
        # assert that /notes and /notes.txt route specifically to the
        # notes templates, and that the bare id (with and without the
        # .txt suffix) still has at least one valid match.
        notes_samples = [
            ("g8://contacts/42/notes", html_uri),
            ("g8://contacts/42/notes.txt", txt_uri),
            ("g8://contacts/abc-xyz/notes", html_uri),
            ("g8://contacts/abc-xyz/notes.txt", txt_uri),
            # UUID-style id
            (
                "g8://contacts/11111111-1111-1111-1111-111111111111/notes",
                html_uri,
            ),
        ]
        for uri, expected in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Bare-id and bare-.txt still route (regression: adding /notes
        # must not have accidentally made /{contact_id} stop matching)
        for uri, expected in (
            ("g8://contacts/42", detail),
            ("g8://contacts/42.txt", detail_txt),
        ):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert expected in matches, (
                f"{uri} should match {expected}; got {matches}"
            )

    def test_contact_tasks_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #35: per-contact tasks HTML + text resources register.

        URI-templated by contact_id with the `/tasks` suffix. The
        surface lives alongside the existing contact-detail (#23) and
        contact-notes (#34) resources — dispatch must remain unambiguous
        across all three siblings:

          - g8://contacts/{contact_id}            (detail, surface #23)
          - g8://contacts/{contact_id}.txt        (detail text)
          - g8://contacts/{contact_id}/notes      (surface #34)
          - g8://contacts/{contact_id}/notes.txt  (surface #34, text)
          - g8://contacts/{contact_id}/tasks      (surface #35, NEW)
          - g8://contacts/{contact_id}/tasks.txt  (surface #35, NEW text)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://contacts/{contact_id}/tasks"
        txt_uri = "g8://contacts/{contact_id}/tasks.txt"
        assert html_uri in templates
        assert txt_uri in templates
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling surfaces (#23 detail, #34 notes) must still register
        for sibling in (
            "g8://contacts/{contact_id}",
            "g8://contacts/{contact_id}.txt",
            "g8://contacts/{contact_id}/notes",
            "g8://contacts/{contact_id}/notes.txt",
        ):
            assert sibling in templates, (
                f"sibling contact resource {sibling} must still register"
            )

        # Unambiguous dispatch — `/tasks` and `/tasks.txt` must route
        # specifically to the new tasks templates and NOT shadow notes
        # or detail.
        tasks_samples = [
            ("g8://contacts/42/tasks", html_uri),
            ("g8://contacts/42/tasks.txt", txt_uri),
            ("g8://contacts/abc-xyz/tasks", html_uri),
            ("g8://contacts/abc-xyz/tasks.txt", txt_uri),
            (
                "g8://contacts/11111111-1111-1111-1111-111111111111/tasks",
                html_uri,
            ),
        ]
        for uri, expected in tasks_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Notes siblings must still route to their own templates
        # (regression: adding /tasks must not shadow /notes)
        for uri, expected in (
            ("g8://contacts/42/notes", "g8://contacts/{contact_id}/notes"),
            ("g8://contacts/42/notes.txt", "g8://contacts/{contact_id}/notes.txt"),
        ):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should still uniquely match {expected}; got {matches}"
            )

    def test_enrichment_job_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #36: enrichment job detail HTML + text resources.

        URI-templated by job_id. The surface is the FIRST enrichment-
        namespaced HTML resource, so it cannot shadow any existing
        `g8://enrichment/*` URI (there are none). Follows the same
        `{id}` + `{id}.txt` pattern as contact-detail (#25), company-
        detail (#26), etc. Registration + mime types are the contract —
        dispatch is handled by FastMCP's mime-type routing.

          - g8://enrichment/jobs/{job_id}      (HTML, NEW)
          - g8://enrichment/jobs/{job_id}.txt  (text fallback, NEW)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://enrichment/jobs/{job_id}"
        txt_uri = "g8://enrichment/jobs/{job_id}.txt"
        assert html_uri in templates, "enrichment job HTML template must register"
        assert txt_uri in templates, "enrichment job text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Regression: a bare `/enrichment/jobs` without a trailing id
        # must not accidentally resolve (both templates require a
        # non-empty {job_id} segment).
        for tpl_uri in (html_uri, txt_uri):
            assert templates[tpl_uri].matches("g8://enrichment/jobs/") is None

    def test_company_notes_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #37: per-company notes HTML + text resources.

        URI-templated by company_id with the `/notes` suffix. The
        surface lives alongside the existing `g8://companies/{company_id}`
        detail resource (#26) — dispatch must not shadow it or its
        `.txt` sibling.

          - g8://companies/{company_id}/notes      (surface #37, 3 segs)
          - g8://companies/{company_id}/notes.txt  (surface #37, text)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        html_uri = "g8://companies/{company_id}/notes"
        txt_uri = "g8://companies/{company_id}/notes.txt"
        assert html_uri in templates, "company notes HTML template must register"
        assert txt_uri in templates, "company notes text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling company-detail resources must still register — adding
        # /notes must not accidentally shadow the existing detail surface.
        detail = "g8://companies/{company_id}"
        detail_txt = "g8://companies/{company_id}.txt"
        for sibling in (detail, detail_txt):
            assert sibling in templates, (
                f"sibling company resource {sibling} must still register"
            )

        # Unambiguous dispatch across all sibling URI shapes.
        notes_samples = [
            ("g8://companies/42/notes", html_uri),
            ("g8://companies/42/notes.txt", txt_uri),
            ("g8://companies/acme-inc/notes", html_uri),
            ("g8://companies/acme-inc/notes.txt", txt_uri),
            # UUID-style id
            (
                "g8://companies/11111111-1111-1111-1111-111111111111/notes",
                html_uri,
            ),
        ]
        for uri, expected in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Bare-id and bare-.txt still route (regression: adding /notes
        # must not have accidentally made /{company_id} stop matching)
        for uri, expected in (
            ("g8://companies/42", detail),
            ("g8://companies/42.txt", detail_txt),
        ):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert expected in matches, (
                f"{uri} should match {expected}; got {matches}"
            )

    def test_list_members_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #38: per-list members HTML + text resources.

        URI-templated by list_id with the `/contacts` suffix. The surface
        lives alongside the existing `g8://lists/dashboard` surface (#8)
        — dispatch must not shadow the dashboard or its `.txt` sibling.

          - g8://lists/{list_id}/contacts      (surface #38, 3 segs)
          - g8://lists/{list_id}/contacts.txt  (surface #38, text)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://lists/{list_id}/contacts"
        txt_uri = "g8://lists/{list_id}/contacts.txt"
        assert html_uri in templates, "list members HTML template must register"
        assert txt_uri in templates, "list members text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling dashboard resources must still register — adding the
        # /contacts template must not accidentally hijack them.
        for static_uri in ("g8://lists/dashboard", "g8://lists/dashboard.txt"):
            assert static_uri in resources, (
                f"sibling list resource {static_uri} must still register"
            )

        # Unambiguous dispatch across all sibling URI shapes. The static
        # dashboard URIs must match the static resource (no template),
        # and the templated URIs must match only our surface #38 template.
        members_samples = [
            ("g8://lists/42/contacts", html_uri),
            ("g8://lists/42/contacts.txt", txt_uri),
            ("g8://lists/enterprise-q2/contacts", html_uri),
            ("g8://lists/enterprise-q2/contacts.txt", txt_uri),
            # UUID-style id
            (
                "g8://lists/11111111-1111-1111-1111-111111111111/contacts",
                html_uri,
            ),
        ]
        for uri, expected in members_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Dashboard URIs must not match the new templated resource — they
        # are static resources registered without {list_id} placeholders.
        for static_uri in ("g8://lists/dashboard", "g8://lists/dashboard.txt"):
            template_matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(static_uri) is not None
            ]
            assert html_uri not in template_matches, (
                f"static dashboard URI {static_uri} must not be captured by "
                f"{html_uri} template"
            )
            assert txt_uri not in template_matches, (
                f"static dashboard URI {static_uri} must not be captured by "
                f"{txt_uri} template"
            )

    def test_webhook_deliveries_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #39: per-webhook deliveries HTML + text resources.

        URI-templated by webhook_id with the `/deliveries` suffix. The
        surface lives alongside the existing `g8://webhooks/{id}/overview`
        surface (#31) — dispatch must not cross-capture either side.

          - g8://webhooks/{webhook_id}/deliveries      (surface #39, 3 segs)
          - g8://webhooks/{webhook_id}/deliveries.txt  (surface #39, text)

        The `/overview` sibling URIs must match their own template, not
        the new `/deliveries` one — and vice versa.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates

        html_uri = "g8://webhooks/{webhook_id}/deliveries"
        txt_uri = "g8://webhooks/{webhook_id}/deliveries.txt"
        assert html_uri in templates, "webhook deliveries HTML template must register"
        assert txt_uri in templates, "webhook deliveries text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Surface #31 siblings (`/overview`) must still register.
        overview_html = "g8://webhooks/{webhook_id}/overview"
        overview_txt = "g8://webhooks/{webhook_id}/overview.txt"
        assert overview_html in templates, "surface #31 overview must still register"
        assert overview_txt in templates, "surface #31 overview .txt must still register"

        # Unambiguous dispatch: each URI shape matches exactly one template.
        deliveries_samples = [
            ("g8://webhooks/wh_123/deliveries", html_uri),
            ("g8://webhooks/wh_123/deliveries.txt", txt_uri),
            ("g8://webhooks/enterprise-sync/deliveries", html_uri),
            ("g8://webhooks/enterprise-sync/deliveries.txt", txt_uri),
            # UUID-style id
            (
                "g8://webhooks/11111111-1111-1111-1111-111111111111/deliveries",
                html_uri,
            ),
        ]
        for uri, expected in deliveries_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # `/overview` siblings must NOT match the new `/deliveries` template.
        overview_samples = [
            "g8://webhooks/wh_123/overview",
            "g8://webhooks/wh_123/overview.txt",
        ]
        for uri in overview_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri not in matches, (
                f"overview URI {uri} must not be captured by {html_uri} template"
            )
            assert txt_uri not in matches, (
                f"overview URI {uri} must not be captured by {txt_uri} template"
            )

        # And the inverse: `/deliveries` URIs must NOT match the overview
        # template (regression for suffix-based disambiguation).
        for uri in ("g8://webhooks/wh_123/deliveries", "g8://webhooks/wh_123/deliveries.txt"):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert overview_html not in matches, (
                f"deliveries URI {uri} must not be captured by overview template"
            )
            assert overview_txt not in matches

    def test_sequence_contacts_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #40: per-sequence contacts HTML + text resources.

        URI-templated by sequence_id with the `/contacts` suffix. Three
        sibling surfaces already exist on the same `g8://sequences/{id}/...`
        root — dispatch must stay unambiguous in every direction:

          - g8://sequences/{sequence_id}/contacts       (surface #40, NEW)
          - g8://sequences/{sequence_id}/contacts.txt   (surface #40, text)
          - g8://sequences/{sequence_id}/overview       (surface #30, sibling)
          - g8://sequences/{sequence_id}/preview        (sibling, steps)
          - g8://sequences/{sequence_id}/analytics      (sibling, perf)

        Each URI shape must match exactly one template. The three siblings
        must NOT cross-capture the new `/contacts` template, and the new
        `/contacts` URIs must NOT match any sibling template.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates

        html_uri = "g8://sequences/{sequence_id}/contacts"
        txt_uri = "g8://sequences/{sequence_id}/contacts.txt"
        assert html_uri in templates, "sequence contacts HTML template must register"
        assert txt_uri in templates, "sequence contacts text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # All three sibling surfaces must still register.
        sibling_uris = [
            "g8://sequences/{sequence_id}/overview",
            "g8://sequences/{sequence_id}/overview.txt",
            "g8://sequences/{sequence_id}/preview",
            "g8://sequences/{sequence_id}/preview.txt",
            "g8://sequences/{sequence_id}/analytics",
            "g8://sequences/{sequence_id}/analytics.txt",
        ]
        for sibling in sibling_uris:
            assert sibling in templates, (
                f"sibling surface {sibling} must still register"
            )

        # Unambiguous dispatch: each /contacts URI matches exactly one template.
        contacts_samples = [
            ("g8://sequences/seq_123/contacts", html_uri),
            ("g8://sequences/seq_123/contacts.txt", txt_uri),
            ("g8://sequences/welcome-flow/contacts", html_uri),
            ("g8://sequences/welcome-flow/contacts.txt", txt_uri),
            # UUID-style id
            (
                "g8://sequences/22222222-2222-2222-2222-222222222222/contacts",
                html_uri,
            ),
        ]
        for uri, expected in contacts_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Sibling URIs must NOT match the new /contacts template (in either direction).
        sibling_samples = [
            "g8://sequences/seq_123/overview",
            "g8://sequences/seq_123/overview.txt",
            "g8://sequences/seq_123/preview",
            "g8://sequences/seq_123/preview.txt",
            "g8://sequences/seq_123/analytics",
            "g8://sequences/seq_123/analytics.txt",
        ]
        for uri in sibling_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri not in matches, (
                f"sibling URI {uri} must not be captured by {html_uri} template"
            )
            assert txt_uri not in matches, (
                f"sibling URI {uri} must not be captured by {txt_uri} template"
            )
            # Each sibling URI still matches exactly one template (its own).
            assert len(matches) == 1, (
                f"sibling URI {uri} should match exactly one template; got {matches}"
            )

        # Inverse: the new /contacts URIs must NOT match any sibling template.
        for uri in ("g8://sequences/seq_123/contacts", "g8://sequences/seq_123/contacts.txt"):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            for sibling in sibling_uris:
                assert sibling not in matches, (
                    f"contacts URI {uri} must not be captured by sibling "
                    f"{sibling} template"
                )

    def test_contact_deals_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #41: per-contact deals HTML + text resources.

        URI-templated by contact_id with the `/deals` suffix. The surface
        completes the contact drill-across triad with `/notes` (surface
        #34) and `/tasks` (surface #35). Dispatch must stay unambiguous
        against all three sibling shapes.

          - g8://contacts/{contact_id}/deals       (surface #41, NEW)
          - g8://contacts/{contact_id}/deals.txt   (surface #41, text)
          - g8://contacts/{contact_id}/notes       (surface #34, sibling)
          - g8://contacts/{contact_id}/tasks       (surface #35, sibling)
          - g8://contacts/{contact_id}             (surface #25, parent)

        The parent (no trailing segment) lives at 2 URI segments and is
        in a different bucket than the 3-segment siblings, but we still
        assert its presence + non-cross-capture for completeness.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates

        html_uri = "g8://contacts/{contact_id}/deals"
        txt_uri = "g8://contacts/{contact_id}/deals.txt"
        assert html_uri in templates, "contact deals HTML template must register"
        assert txt_uri in templates, "contact deals text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling surfaces must still register.
        sibling_uris = [
            "g8://contacts/{contact_id}/notes",
            "g8://contacts/{contact_id}/notes.txt",
            "g8://contacts/{contact_id}/tasks",
            "g8://contacts/{contact_id}/tasks.txt",
            "g8://contacts/{contact_id}",
            "g8://contacts/{contact_id}.txt",
        ]
        for sibling in sibling_uris:
            assert sibling in templates, (
                f"sibling surface {sibling} must still register"
            )

        # Unambiguous dispatch: each /deals URI matches exactly one template.
        deals_samples = [
            ("g8://contacts/12345/deals", html_uri),
            ("g8://contacts/12345/deals.txt", txt_uri),
            ("g8://contacts/alice-smith/deals", html_uri),
            ("g8://contacts/alice-smith/deals.txt", txt_uri),
            # UUID-style id
            (
                "g8://contacts/11111111-2222-3333-4444-555555555555/deals",
                html_uri,
            ),
        ]
        for uri, expected in deals_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # `/notes` and `/tasks` siblings must NOT match /deals template.
        three_seg_siblings = [
            "g8://contacts/12345/notes",
            "g8://contacts/12345/notes.txt",
            "g8://contacts/12345/tasks",
            "g8://contacts/12345/tasks.txt",
        ]
        for uri in three_seg_siblings:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri not in matches, (
                f"sibling URI {uri} must not be captured by {html_uri}"
            )
            assert txt_uri not in matches, (
                f"sibling URI {uri} must not be captured by {txt_uri}"
            )
            # Each sibling matches exactly one template (its own).
            assert len(matches) == 1, (
                f"sibling URI {uri} should match exactly one template; got {matches}"
            )

        # Inverse: /deals URIs must NOT match any sibling template.
        for uri in ("g8://contacts/12345/deals", "g8://contacts/12345/deals.txt"):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            for sibling in sibling_uris:
                assert sibling not in matches, (
                    f"deals URI {uri} must not be captured by sibling "
                    f"{sibling} template"
                )

    def test_company_deals_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #42: per-company deals HTML + text resources.

        URI-templated by company_id with the `/deals` suffix. Dispatch
        must stay unambiguous against the two known siblings:

          - g8://companies/{company_id}/deals       (surface #42, NEW)
          - g8://companies/{company_id}/deals.txt   (surface #42, text)
          - g8://companies/{company_id}/notes       (surface #37, sibling)
          - g8://companies/{company_id}             (surface #26, parent)

        The parent lives at 2 URI segments and is in a different bucket
        than the 3-segment siblings, but we still assert its presence
        and non-cross-capture for completeness.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        templates = server._resource_manager._templates

        html_uri = "g8://companies/{company_id}/deals"
        txt_uri = "g8://companies/{company_id}/deals.txt"
        assert html_uri in templates, "company deals HTML template must register"
        assert txt_uri in templates, "company deals text template must register"
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Sibling surfaces must still register.
        sibling_uris = [
            "g8://companies/{company_id}/notes",
            "g8://companies/{company_id}/notes.txt",
            "g8://companies/{company_id}",
            "g8://companies/{company_id}.txt",
        ]
        for sibling in sibling_uris:
            assert sibling in templates, (
                f"sibling surface {sibling} must still register"
            )

        # Unambiguous dispatch: each /deals URI matches exactly one template.
        deals_samples = [
            ("g8://companies/12345/deals", html_uri),
            ("g8://companies/12345/deals.txt", txt_uri),
            ("g8://companies/acme-corp/deals", html_uri),
            ("g8://companies/acme-corp/deals.txt", txt_uri),
            # UUID-style id
            (
                "g8://companies/11111111-2222-3333-4444-555555555555/deals",
                html_uri,
            ),
        ]
        for uri, expected in deals_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # `/notes` sibling must NOT match /deals template.
        three_seg_siblings = [
            "g8://companies/12345/notes",
            "g8://companies/12345/notes.txt",
        ]
        for uri in three_seg_siblings:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri not in matches, (
                f"sibling URI {uri} must not be captured by {html_uri}"
            )
            assert txt_uri not in matches, (
                f"sibling URI {uri} must not be captured by {txt_uri}"
            )
            # Each sibling matches exactly one template (its own).
            assert len(matches) == 1, (
                f"sibling URI {uri} should match exactly one template; got {matches}"
            )

        # Inverse: /deals URIs must NOT match any sibling template.
        for uri in ("g8://companies/12345/deals", "g8://companies/12345/deals.txt"):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            for sibling in sibling_uris:
                assert sibling not in matches, (
                    f"deals URI {uri} must not be captured by sibling "
                    f"{sibling} template"
                )

    def test_webhooks_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #43: org-wide webhooks dashboard.

        Static (non-templated) URI `g8://webhooks` — single segment.
        Must coexist cleanly with:
          - g8://webhooks/{webhook_id}/overview    (surface #32)
          - g8://webhooks/{webhook_id}/deliveries  (surface #39)

        The dashboard URI is a STATIC resource (no braces), so it lives
        in `_resources`, not `_templates`. The per-webhook detail +
        deliveries surfaces are templates at 3 URI segments — no
        collision possible given the segment-count difference.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        # Static resources live in a separate registry from templates.
        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://webhooks"
        txt_uri = "g8://webhooks.txt"
        assert html_uri in resources, "webhooks dashboard HTML resource must register"
        assert txt_uri in resources, "webhooks dashboard text resource must register"
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Per-webhook templates must still register and remain unambiguous.
        per_webhook_templates = [
            "g8://webhooks/{webhook_id}/overview",
            "g8://webhooks/{webhook_id}/overview.txt",
            "g8://webhooks/{webhook_id}/deliveries",
            "g8://webhooks/{webhook_id}/deliveries.txt",
        ]
        for tpl_uri in per_webhook_templates:
            assert tpl_uri in templates, (
                f"per-webhook template {tpl_uri} must still register"
            )

        # Per-webhook URIs must match exactly one template each and
        # must NOT cross-capture against any other per-webhook template.
        samples = [
            ("g8://webhooks/wh_123/overview", "g8://webhooks/{webhook_id}/overview"),
            ("g8://webhooks/wh_123/overview.txt", "g8://webhooks/{webhook_id}/overview.txt"),
            ("g8://webhooks/wh_123/deliveries", "g8://webhooks/{webhook_id}/deliveries"),
            ("g8://webhooks/wh_123/deliveries.txt", "g8://webhooks/{webhook_id}/deliveries.txt"),
        ]
        for uri, expected in samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # The dashboard URI `g8://webhooks` (no trailing segments) must
        # NOT be captured by any per-webhook template (they require 3
        # segments; dashboard has 1 — segment-count mismatch).
        for uri in (html_uri, txt_uri):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [], (
                f"dashboard URI {uri} must not match any per-webhook "
                f"template; got {matches}"
            )

    def test_contact_fields_schema_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #44: org-wide contact fields schema.

        Static (non-templated) URI `g8://fields/contacts` — 2 segments.
        Must coexist cleanly with:
          - g8://crm-syncs/{provider}/fields  (surface #19 — 3 segments)

        The schema URI is a STATIC resource (no braces), so it lives
        in `_resources`, not `_templates`. Disjoint root (`fields/*`)
        means no templated resources can accidentally capture it.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://fields/contacts"
        txt_uri = "g8://fields/contacts.txt"
        assert html_uri in resources, (
            "contact fields schema HTML resource must register"
        )
        assert txt_uri in resources, (
            "contact fields schema text resource must register"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # The schema URI must NOT match any templated resource (notably
        # the CRM provider-specific fields template is rooted at
        # `g8://crm-syncs/{provider}/fields`, a disjoint 3-segment root
        # — segment count AND leading-literal mismatch).
        for uri in (html_uri, txt_uri):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [], (
                f"contact fields schema URI {uri} must not match any "
                f"template; got {matches}"
            )

        # Conversely, the provider-specific template must NOT accidentally
        # capture the schema URI.
        crm_fields_tpl = "g8://crm-syncs/{provider}/fields"
        if crm_fields_tpl in templates:
            tpl = templates[crm_fields_tpl]
            assert tpl.matches(html_uri) is None, (
                f"CRM fields template must not capture {html_uri}"
            )
            assert tpl.matches(txt_uri) is None, (
                f"CRM fields template must not capture {txt_uri}"
            )

        # The CRM fields template should still match real provider URIs.
        if crm_fields_tpl in templates:
            tpl = templates[crm_fields_tpl]
            sample = "g8://crm-syncs/hubspot/fields"
            assert tpl.matches(sample) is not None, (
                f"CRM fields template must still match {sample}"
            )

    def test_company_fields_schema_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #45: org-wide company fields schema.

        Static (non-templated) URI `g8://fields/companies` — 2 segments.
        Sibling to surface #44's `g8://fields/contacts`. Must coexist
        cleanly with:
          - g8://fields/contacts              (surface #44 — 2 segments)
          - g8://crm-syncs/{provider}/fields  (surface #19 — 3 segments)

        The schema URI is a STATIC resource (no braces), so it lives
        in `_resources`, not `_templates`. Disjoint root (`fields/*`)
        means no templated resources can accidentally capture it.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://fields/companies"
        txt_uri = "g8://fields/companies.txt"
        assert html_uri in resources, (
            "company fields schema HTML resource must register"
        )
        assert txt_uri in resources, (
            "company fields schema text resource must register"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Sibling contacts schema must still be registered (surface #44
        # regression lock — adding #45 must not knock out #44).
        assert "g8://fields/contacts" in resources, (
            "sibling contact fields schema URI must still be registered"
        )
        assert "g8://fields/contacts.txt" in resources, (
            "sibling contact fields schema text URI must still be registered"
        )

        # The schema URI must NOT match any templated resource (notably
        # the CRM provider-specific fields template is rooted at
        # `g8://crm-syncs/{provider}/fields`, a disjoint 3-segment root
        # — segment count AND leading-literal mismatch).
        for uri in (html_uri, txt_uri):
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [], (
                f"company fields schema URI {uri} must not match any "
                f"template; got {matches}"
            )

        # Conversely, the provider-specific template must NOT accidentally
        # capture the schema URI.
        crm_fields_tpl = "g8://crm-syncs/{provider}/fields"
        if crm_fields_tpl in templates:
            tpl = templates[crm_fields_tpl]
            assert tpl.matches(html_uri) is None, (
                f"CRM fields template must not capture {html_uri}"
            )
            assert tpl.matches(txt_uri) is None, (
                f"CRM fields template must not capture {txt_uri}"
            )

        # The CRM fields template should still match real provider URIs.
        if crm_fields_tpl in templates:
            tpl = templates[crm_fields_tpl]
            sample = "g8://crm-syncs/hubspot/fields"
            assert tpl.matches(sample) is not None, (
                f"CRM fields template must still match {sample}"
            )

    def test_company_contacts_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #46: per-company contact roster.

        Templated URI `g8://companies/{company_id}/contacts` — 3 segments
        with a `company_id` parameter. Must coexist cleanly with sibling
        per-company templates:
          - g8://companies/{company_id}             (surface #26)
          - g8://companies/{company_id}/notes       (surface #37)
          - g8://companies/{company_id}/deals       (surface #42)

        Path-segment disambiguation: `/contacts` keeps this distinct
        from `/notes` and `/deals`. The 2-segment parent surface
        `g8://companies/{company_id}` is prefix-only and does not match
        the trailing segment.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_tpl = "g8://companies/{company_id}/contacts"
        txt_tpl = "g8://companies/{company_id}/contacts.txt"

        assert html_tpl in templates, (
            "company contacts HTML template must register"
        )
        assert txt_tpl in templates, (
            "company contacts text template must register"
        )
        assert templates[html_tpl].mime_type == "text/html"
        assert templates[txt_tpl].mime_type == "text/plain"

        # Sibling per-company templates must still be registered.
        for sibling in (
            "g8://companies/{company_id}",
            "g8://companies/{company_id}/notes",
            "g8://companies/{company_id}/deals",
        ):
            assert sibling in templates, (
                f"sibling per-company template {sibling} must still be "
                f"registered after adding #46"
            )

        # Real company_id path matches the /contacts template AND does
        # not accidentally match the /notes, /deals, or parent
        # `g8://companies/{company_id}` template.
        sample = "g8://companies/42/contacts"
        assert templates[html_tpl].matches(sample) is not None, (
            f"company contacts template must match {sample}"
        )

        for other in (
            "g8://companies/{company_id}/notes",
            "g8://companies/{company_id}/deals",
        ):
            tpl = templates[other]
            assert tpl.matches(sample) is None, (
                f"{other} must NOT match {sample}"
            )

        parent_tpl = templates.get("g8://companies/{company_id}")
        if parent_tpl is not None:
            assert parent_tpl.matches(sample) is None, (
                "parent company template (2-segment) must NOT capture "
                "the 3-segment /contacts URI"
            )

        # Conversely, the parent company template must still match the
        # 2-segment URI.
        if parent_tpl is not None:
            parent_sample = "g8://companies/42"
            assert parent_tpl.matches(parent_sample) is not None, (
                "parent company template must still match 2-segment URI"
            )

    def test_webhook_events_catalog_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #47: webhook events catalog (org-wide).

        Static URI `g8://webhooks/events` — 2 segments, disjoint from:
          - g8://webhooks                         (surface #43, 1-segment)
          - g8://webhooks/{webhook_id}/overview   (surface #32, 3-segment)
          - g8://webhooks/{webhook_id}/deliveries (surface #39, 3-segment)

        No webhook_id templated parent at 2 segments, so no template-vs-
        static collision. Sibling per-webhook templates must continue to
        match their own 3-segment paths unaffected.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://webhooks/events"
        txt_uri = "g8://webhooks/events.txt"

        assert html_uri in resources, (
            "webhook events catalog HTML static URI must register"
        )
        assert txt_uri in resources, (
            "webhook events catalog text static URI must register"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        # Sibling #43 (top-level dashboard, 1-segment) must still be
        # registered. Statics use distinct paths.
        assert "g8://webhooks" in resources, (
            "webhooks dashboard static URI must still be registered "
            "after adding #47"
        )

        # Sibling per-webhook templates (3-segment) must still be
        # registered and continue to match their own URIs.
        for sibling_tpl in (
            "g8://webhooks/{webhook_id}/overview",
            "g8://webhooks/{webhook_id}/deliveries",
        ):
            assert sibling_tpl in templates, (
                f"sibling per-webhook template {sibling_tpl} must still "
                f"be registered after adding #47"
            )
            sample = "g8://webhooks/abc123/" + sibling_tpl.rsplit("/", 1)[-1]
            assert templates[sibling_tpl].matches(sample) is not None, (
                f"{sibling_tpl} must still match {sample}"
            )

        # Critical: the 2-segment static URI must NOT be captured by the
        # 3-segment per-webhook templates. FastMCP matches templates by
        # param-substitution, so a 3-segment template cannot match a
        # 2-segment URI — but lock this explicitly.
        for sibling_tpl in (
            "g8://webhooks/{webhook_id}/overview",
            "g8://webhooks/{webhook_id}/deliveries",
        ):
            assert templates[sibling_tpl].matches(html_uri) is None, (
                f"{sibling_tpl} must NOT capture static URI {html_uri}"
            )

    def test_repos_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #48: repos dashboard (org-wide).

        Static URI `g8://repos/dashboard` — 2 segments, disjoint from:
          - g8://repos                               (1-segment structured JSON)
          - g8://repos/{repo_id}/overview            (surface #30, 3-segment)
          - g8://repos/{repo_id}/scan                (3-segment template)
          - g8://repos/{repo_id}/kb                  (3-segment template)
          - g8://repos/{repo_id}/kb/{doc_id}         (4-segment template)
          - g8://repos/{repo_id}/campaigns           (3-segment template)
          - g8://repos/{repo_id}/campaigns/{id}/brief (5-segment template)

        No 2-segment templated parent (`g8://repos/{repo_id}` doesn't
        exist), so the 2-segment static is safe. Sibling per-repo
        templates must continue to match their own 3+ segment paths
        unaffected.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://repos/dashboard"
        txt_uri = "g8://repos/dashboard.txt"

        assert html_uri in resources, (
            "repos dashboard HTML static URI must register"
        )
        assert txt_uri in resources, (
            "repos dashboard text static URI must register"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        # Existing structured-JSON `g8://repos` static (1-segment) must
        # still be registered. HTML sibling adds without breaking.
        assert "g8://repos" in resources, (
            "g8://repos structured JSON resource must still be "
            "registered after adding #48"
        )

        # Sibling per-repo templates must still be registered and match
        # their own URIs.
        for sibling_tpl in (
            "g8://repos/{repo_id}/scan",
            "g8://repos/{repo_id}/kb",
            "g8://repos/{repo_id}/campaigns",
            "g8://repos/{repo_id}/overview",
        ):
            assert sibling_tpl in templates, (
                f"sibling per-repo template {sibling_tpl} must still "
                f"be registered after adding #48"
            )
            sample = "g8://repos/abc123/" + sibling_tpl.rsplit("/", 1)[-1]
            assert templates[sibling_tpl].matches(sample) is not None, (
                f"{sibling_tpl} must still match {sample}"
            )

        # Critical: the 2-segment static URI must NOT be captured by
        # any 3+-segment per-repo template. FastMCP matches templates
        # by param-substitution, so a 3-segment template cannot match
        # a 2-segment URI — but lock this explicitly.
        for sibling_tpl in (
            "g8://repos/{repo_id}/scan",
            "g8://repos/{repo_id}/kb",
            "g8://repos/{repo_id}/campaigns",
            "g8://repos/{repo_id}/overview",
        ):
            assert templates[sibling_tpl].matches(html_uri) is None, (
                f"{sibling_tpl} must NOT capture static URI {html_uri}"
            )

    def test_repo_install_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #49: per-repo install patch set status.

        Template URI `g8://repos/{repo_id}/install` — 3-segment, slots
        between existing per-repo siblings:
          - g8://repos/{repo_id}/scan       (3-segment template)
          - g8://repos/{repo_id}/kb         (3-segment template)
          - g8://repos/{repo_id}/kb/{doc_id} (4-segment template)
          - g8://repos/{repo_id}/campaigns  (3-segment template)
          - g8://repos/{repo_id}/overview   (3-segment template)

        Disjoint from:
          - g8://repos                      (1-segment structured JSON)
          - g8://repos/dashboard            (2-segment static, surface #48)

        Critical: the new 3-segment template must NOT capture the
        existing 2-segment static `g8://repos/dashboard`, and the
        existing 3-segment per-repo siblings must still match their
        own URIs unaffected.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_tpl = "g8://repos/{repo_id}/install"
        txt_tpl = "g8://repos/{repo_id}/install.txt"

        assert html_tpl in templates, (
            "repo install HTML template URI must register"
        )
        assert txt_tpl in templates, (
            "repo install text template URI must register"
        )
        assert str(templates[html_tpl].mime_type) == "text/html"
        assert str(templates[txt_tpl].mime_type) == "text/plain"

        # The new template must match 3-segment sample URIs.
        sample_html = "g8://repos/abc-123/install"
        sample_txt = "g8://repos/abc-123/install.txt"
        assert templates[html_tpl].matches(sample_html) is not None, (
            f"{html_tpl} must match {sample_html}"
        )
        assert templates[txt_tpl].matches(sample_txt) is not None, (
            f"{txt_tpl} must match {sample_txt}"
        )

        # Must NOT capture the 2-segment static (surface #48) or the
        # 1-segment root.
        assert templates[html_tpl].matches("g8://repos/dashboard") is None, (
            "repo install template must NOT capture g8://repos/dashboard"
        )
        assert templates[html_tpl].matches("g8://repos") is None, (
            "repo install template must NOT capture g8://repos (1-seg)"
        )

        # The existing surface #48 dashboard must still be reachable
        # and the existing per-repo siblings still register.
        assert "g8://repos/dashboard" in resources, (
            "surface #48 static must still register after adding #49"
        )
        for sibling_tpl in (
            "g8://repos/{repo_id}/scan",
            "g8://repos/{repo_id}/kb",
            "g8://repos/{repo_id}/campaigns",
            "g8://repos/{repo_id}/overview",
        ):
            assert sibling_tpl in templates, (
                f"sibling per-repo template {sibling_tpl} must still "
                f"register after adding #49"
            )
            sample = "g8://repos/abc-123/" + sibling_tpl.rsplit("/", 1)[-1]
            assert templates[sibling_tpl].matches(sample) is not None, (
                f"{sibling_tpl} must still match {sample}"
            )
            # Existing 3-seg siblings must NOT capture the /install URI
            assert templates[sibling_tpl].matches(sample_html) is None, (
                f"{sibling_tpl} must NOT capture {sample_html}"
            )

    def test_crm_sync_overview_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #50: per-CRM-provider operational overview.

        Template URI `g8://crm-syncs/{provider}/overview` — 3-segment,
        slots alongside the existing CRM sync surfaces:
          - g8://crm-syncs/dashboard             (2-seg static)
          - g8://crm-syncs/{provider}/fields     (3-seg template)

        Critical: the new 3-segment template must NOT capture the
        existing 2-segment static `g8://crm-syncs/dashboard`, and the
        existing 3-segment `fields` sibling must still match its own
        URIs unaffected (and must not capture the new /overview URI).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_tpl = "g8://crm-syncs/{provider}/overview"
        txt_tpl = "g8://crm-syncs/{provider}/overview.txt"

        assert html_tpl in templates, (
            "crm sync overview HTML template URI must register"
        )
        assert txt_tpl in templates, (
            "crm sync overview text template URI must register"
        )
        assert str(templates[html_tpl].mime_type) == "text/html"
        assert str(templates[txt_tpl].mime_type) == "text/plain"

        # The new template must match 3-segment sample URIs.
        sample_html = "g8://crm-syncs/hubspot/overview"
        sample_txt = "g8://crm-syncs/hubspot/overview.txt"
        assert templates[html_tpl].matches(sample_html) is not None, (
            f"{html_tpl} must match {sample_html}"
        )
        assert templates[txt_tpl].matches(sample_txt) is not None, (
            f"{txt_tpl} must match {sample_txt}"
        )

        # Must NOT capture the 2-segment static dashboard.
        assert templates[html_tpl].matches("g8://crm-syncs/dashboard") is None, (
            "crm sync overview template must NOT capture "
            "g8://crm-syncs/dashboard (2-seg static)"
        )

        # The existing 2-seg static dashboard must still be reachable.
        assert "g8://crm-syncs/dashboard" in resources, (
            "crm-syncs/dashboard static must still register after adding #50"
        )

        # The existing 3-seg `fields` sibling must still register and
        # match its own URIs, and must NOT capture the new /overview URI.
        fields_tpl = "g8://crm-syncs/{provider}/fields"
        assert fields_tpl in templates, (
            "existing crm-syncs/{provider}/fields template must still register"
        )
        assert (
            templates[fields_tpl].matches(
                "g8://crm-syncs/hubspot/fields"
            )
            is not None
        ), "fields template must still match its own URI"
        assert (
            templates[fields_tpl].matches(sample_html) is None
        ), "fields template must NOT capture the /overview URI"

        # And the new /overview template must NOT capture /fields either.
        assert (
            templates[html_tpl].matches(
                "g8://crm-syncs/hubspot/fields"
            )
            is None
        ), "overview template must NOT capture /fields URI"

    def test_inbox_draft_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #51: per-thread AI draft viewer.

        Template URI `g8://inbox/threads/{reply_id}/draft` — 4-segment,
        slots alongside the existing inbox surfaces:
          - g8://inbox/dashboard                   (2-seg static)
          - g8://inbox/threads/{reply_id}          (3-seg template)

        Critical: the new 4-segment template must NOT capture the
        existing 3-segment `g8://inbox/threads/{reply_id}` detail URI,
        and the existing 3-seg template must still match its own URIs
        unaffected (and must not capture the new /draft URI).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_tpl = "g8://inbox/threads/{reply_id}/draft"
        txt_tpl = "g8://inbox/threads/{reply_id}/draft.txt"

        assert html_tpl in templates, (
            "inbox draft HTML template URI must register"
        )
        assert txt_tpl in templates, (
            "inbox draft text template URI must register"
        )
        assert str(templates[html_tpl].mime_type) == "text/html"
        assert str(templates[txt_tpl].mime_type) == "text/plain"

        # The new template must match 4-segment sample URIs.
        sample_html = "g8://inbox/threads/t_abc123/draft"
        sample_txt = "g8://inbox/threads/t_abc123/draft.txt"
        assert templates[html_tpl].matches(sample_html) is not None, (
            f"{html_tpl} must match {sample_html}"
        )
        assert templates[txt_tpl].matches(sample_txt) is not None, (
            f"{txt_tpl} must match {sample_txt}"
        )

        # Must NOT capture the 2-segment static dashboard.
        assert templates[html_tpl].matches("g8://inbox/dashboard") is None, (
            "inbox draft template must NOT capture "
            "g8://inbox/dashboard (2-seg static)"
        )

        # Must NOT capture the 3-segment per-thread detail URI.
        assert (
            templates[html_tpl].matches("g8://inbox/threads/t_abc123") is None
        ), "inbox draft template must NOT capture the 3-seg thread detail"

        # The existing 2-seg static dashboard must still be reachable.
        assert "g8://inbox/dashboard" in resources, (
            "inbox/dashboard static must still register after adding #51"
        )

        # The existing 3-seg thread detail template must still register
        # and match its own URIs, and must NOT capture the new /draft URI.
        detail_tpl = "g8://inbox/threads/{reply_id}"
        assert detail_tpl in templates, (
            "existing inbox/threads/{reply_id} template must still register"
        )
        assert (
            templates[detail_tpl].matches("g8://inbox/threads/t_abc123")
            is not None
        ), "thread detail template must still match its own URI"
        assert (
            templates[detail_tpl].matches(sample_html) is None
        ), "thread detail template must NOT capture the /draft URI"

        # And the new /draft template must NOT capture the parent /threads/{id}.
        assert (
            templates[html_tpl].matches("g8://inbox/threads/t_abc123")
            is None
        ), "draft template must NOT capture bare thread detail URI"

    def test_snippet_install_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #52: org-wide tracking snippet install guide.

        Static URIs:
          - g8://snippet/install        (2-seg static, HTML)
          - g8://snippet/install.txt    (2-seg static, text)

        Brand-new `g8://snippet/` namespace — disjoint from every other
        resource and template. Both URIs must live in `_resources`
        (FastMCP classifies them as static), not in `_templates`, because
        they have no path parameters.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://snippet/install"
        txt_uri = "g8://snippet/install.txt"

        # Both URIs register as STATIC resources (no path params).
        assert html_uri in resources, (
            "snippet install HTML URI must register as a static resource"
        )
        assert txt_uri in resources, (
            "snippet install text URI must register as a static resource"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        # And they must NOT appear in the templates registry, since they
        # carry no path params. Any template collision would break
        # FastMCP routing.
        assert html_uri not in templates, (
            "snippet install HTML must not double-register as a template"
        )
        assert txt_uri not in templates, (
            "snippet install text must not double-register as a template"
        )

        # New namespace check: no existing template should accidentally
        # match the new static URIs (regression against FastMCP
        # wildcard capture mistakes).
        for tpl_uri, tpl in templates.items():
            assert tpl.matches(html_uri) is None, (
                f"existing template {tpl_uri} must NOT capture "
                f"new static {html_uri}"
            )
            assert tpl.matches(txt_uri) is None, (
                f"existing template {tpl_uri} must NOT capture "
                f"new static {txt_uri}"
            )

    def test_contact_activities_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #53: per-contact activities timeline.

        Templated URIs (4-segment, one path param):
          - g8://contacts/{contact_id}/activities      (HTML)
          - g8://contacts/{contact_id}/activities.txt  (text)

        The surface plugs into the existing per-contact sibling family
        (#37 /notes, #38 /tasks, #39 /deals, #26 parent detail). Because
        both URIs carry `{contact_id}`, FastMCP must classify them as
        URI templates in `_templates`, not static resources.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://contacts/{contact_id}/activities"
        txt_uri = "g8://contacts/{contact_id}/activities.txt"

        assert html_uri in templates, (
            "contact activities HTML URI must register as a template"
        )
        assert txt_uri in templates, (
            "contact activities text URI must register as a template"
        )
        assert str(templates[html_uri].mime_type) == "text/html"
        assert str(templates[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the static resources registry.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Neither new template should be clobbered by siblings. Verify
        # that a concrete match lands ONLY on the intended template,
        # not on /notes / /tasks / /deals.
        probe_html = "g8://contacts/abc-123/activities"
        probe_txt = "g8://contacts/abc-123/activities.txt"

        html_match = templates[html_uri].matches(probe_html)
        txt_match = templates[txt_uri].matches(probe_txt)
        assert html_match == {"contact_id": "abc-123"}
        assert txt_match == {"contact_id": "abc-123"}

        # Cross-check: other /contacts/{id}/* templates MUST NOT
        # match our probes (e.g. /notes would incorrectly swallow them
        # if someone defined it as `/contacts/{contact_id}/{anything}`).
        for other_uri, other_tpl in templates.items():
            if other_uri in (html_uri, txt_uri):
                continue
            assert other_tpl.matches(probe_html) is None, (
                f"template {other_uri} must not capture {probe_html}"
            )
            assert other_tpl.matches(probe_txt) is None, (
                f"template {other_uri} must not capture {probe_txt}"
            )

    def test_repo_streams_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #54: per-repo tracking streams listing.

        Templated URIs (4-segment, one path param):
          - g8://repos/{repo_id}/streams      (HTML)
          - g8://repos/{repo_id}/streams.txt  (text)

        The surface plugs into the existing per-repo sibling family
        (#32 /overview, #49 /install). Because both URIs carry
        `{repo_id}`, FastMCP must classify them as URI templates in
        `_templates`, not static resources.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://repos/{repo_id}/streams"
        txt_uri = "g8://repos/{repo_id}/streams.txt"

        assert html_uri in templates, (
            "repo streams HTML URI must register as a template"
        )
        assert txt_uri in templates, (
            "repo streams text URI must register as a template"
        )
        assert str(templates[html_uri].mime_type) == "text/html"
        assert str(templates[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the static resources registry.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Probe: concrete URI must match the new template exactly, with
        # the single repo_id capture extracted verbatim.
        probe_html = "g8://repos/repo-xyz/streams"
        probe_txt = "g8://repos/repo-xyz/streams.txt"

        html_match = templates[html_uri].matches(probe_html)
        txt_match = templates[txt_uri].matches(probe_txt)
        assert html_match == {"repo_id": "repo-xyz"}
        assert txt_match == {"repo_id": "repo-xyz"}

        # Cross-check: no other template should capture our probes
        # (esp. /overview, /install, /scan, /kb, /campaigns).
        for other_uri, other_tpl in templates.items():
            if other_uri in (html_uri, txt_uri):
                continue
            assert other_tpl.matches(probe_html) is None, (
                f"template {other_uri} must not capture {probe_html}"
            )
            assert other_tpl.matches(probe_txt) is None, (
                f"template {other_uri} must not capture {probe_txt}"
            )

    def test_repo_scan_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #55: per-repo scan report.

        Templated URIs (4-segment, one path param):
          - g8://repos/{repo_id}/scan      (HTML)
          - g8://repos/{repo_id}/scan.txt  (text)

        The surface plugs into the existing per-repo sibling family
        (#32 /overview, #49 /install, #54 /streams). Because both URIs
        carry `{repo_id}`, FastMCP must classify them as URI templates
        in `_templates`, not static resources. No other template should
        accidentally capture the new URIs (especially the existing
        `/overview`, `/install`, `/streams` siblings).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://repos/{repo_id}/scan"
        txt_uri = "g8://repos/{repo_id}/scan.txt"

        assert html_uri in templates, (
            "repo scan HTML URI must register as a template"
        )
        assert txt_uri in templates, (
            "repo scan text URI must register as a template"
        )
        assert str(templates[html_uri].mime_type) == "text/html"
        assert str(templates[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the static resources registry.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Probe: concrete URI must match the new template exactly, with
        # the single repo_id capture extracted verbatim.
        probe_html = "g8://repos/repo-xyz/scan"
        probe_txt = "g8://repos/repo-xyz/scan.txt"

        html_match = templates[html_uri].matches(probe_html)
        txt_match = templates[txt_uri].matches(probe_txt)
        assert html_match == {"repo_id": "repo-xyz"}
        assert txt_match == {"repo_id": "repo-xyz"}

        # Cross-check: no other template should capture our probes
        # (esp. /overview, /install, /streams siblings).
        for other_uri, other_tpl in templates.items():
            if other_uri in (html_uri, txt_uri):
                continue
            assert other_tpl.matches(probe_html) is None, (
                f"template {other_uri} must not capture {probe_html}"
            )
            assert other_tpl.matches(probe_txt) is None, (
                f"template {other_uri} must not capture {probe_txt}"
            )

    def test_repo_snippet_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #56: per-repo tracking snippet.

        Templated URIs (4-segment, one path param):
          - g8://repos/{repo_id}/snippet      (HTML)
          - g8://repos/{repo_id}/snippet.txt  (text)

        Distinct from the org-wide `g8://snippet/install` (#52) — this
        surface binds to a specific repo's pinned tracking stream. Slots
        into the /repos/{id}/* sibling family alongside /overview (#32),
        /install (#49), /streams (#54), /scan (#55). Because both URIs
        carry `{repo_id}`, FastMCP must classify them as URI templates,
        not static resources. No other template should accidentally
        capture the probes (esp. the existing siblings or the
        static `g8://snippet/install` surface).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://repos/{repo_id}/snippet"
        txt_uri = "g8://repos/{repo_id}/snippet.txt"

        assert html_uri in templates, (
            "repo snippet HTML URI must register as a template"
        )
        assert txt_uri in templates, (
            "repo snippet text URI must register as a template"
        )
        assert str(templates[html_uri].mime_type) == "text/html"
        assert str(templates[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the static resources registry.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Static org-wide snippet/install (#52) must still be registered
        # as a static resource (it has no path params).
        assert "g8://snippet/install" in resources
        assert "g8://snippet/install.txt" in resources

        # Probe: concrete URI must match the new template exactly, with
        # the single repo_id capture extracted verbatim.
        probe_html = "g8://repos/repo-xyz/snippet"
        probe_txt = "g8://repos/repo-xyz/snippet.txt"

        html_match = templates[html_uri].matches(probe_html)
        txt_match = templates[txt_uri].matches(probe_txt)
        assert html_match == {"repo_id": "repo-xyz"}
        assert txt_match == {"repo_id": "repo-xyz"}

        # Cross-check: no other template should capture our probes
        # (esp. /overview, /install, /streams, /scan siblings).
        for other_uri, other_tpl in templates.items():
            if other_uri in (html_uri, txt_uri):
                continue
            assert other_tpl.matches(probe_html) is None, (
                f"template {other_uri} must not capture {probe_html}"
            )
            assert other_tpl.matches(probe_txt) is None, (
                f"template {other_uri} must not capture {probe_txt}"
            )

    def test_form_snippet_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #57: org-wide lead-capture form snippet.

        Static URIs (2-segment, no path params):
          - g8://snippet/form      (HTML)
          - g8://snippet/form.txt  (text)

        Distinct from #52 (snippet/install — JS tracking snippet) and
        #56 (repos/{id}/snippet — per-repo JS snippet). This surface
        renders the lead-capture form HTML + fields + event name + notes
        returned by GET /snippet/form. Because both URIs have no path
        params, FastMCP must classify them as static resources, not
        templates.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://snippet/form"
        txt_uri = "g8://snippet/form.txt"

        # Must be static (no path params) — register in _resources.
        assert html_uri in resources, (
            "form snippet HTML URI must register as a static resource"
        )
        assert txt_uri in resources, (
            "form snippet text URI must register as a static resource"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the template registry.
        assert html_uri not in templates
        assert txt_uri not in templates

        # Sibling surface #52 (snippet/install) must still coexist.
        assert "g8://snippet/install" in resources
        assert "g8://snippet/install.txt" in resources

        # #52 and #57 are distinct resources (one is /install, one is
        # /form). A client asking for one must not accidentally get the
        # other.
        assert resources[html_uri] is not resources["g8://snippet/install"]
        assert resources[txt_uri] is not resources["g8://snippet/install.txt"]

        # Cross-check: no template should accidentally capture our
        # static URI (the templated /repos/{id}/snippet was the historic
        # collision risk).
        for other_uri, other_tpl in templates.items():
            assert other_tpl.matches(html_uri) is None, (
                f"template {other_uri} must not capture {html_uri}"
            )
            assert other_tpl.matches(txt_uri) is None, (
                f"template {other_uri} must not capture {txt_uri}"
            )

    def test_contacts_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #58: org-wide contacts dashboard.

        Static URIs (2-segment, no path params):
          - g8://contacts/dashboard      (HTML)
          - g8://contacts/dashboard.txt  (text)

        Distinct from the Upgrade-1 JSON list at g8://contacts and from
        the per-contact detail template g8://contacts/{contact_id}.
        This surface renders a rolled-up view of the full contact index
        — 4-card KPI strip (total / with email / with phone / with
        LinkedIn), seniority / department / country chip clusters, and
        a truncated row list with drill-down pointers to per-contact,
        fields, create, batch, and search resources.

        Collision note: `g8://contacts/{contact_id}` is a 2-segment
        template that would formally match /dashboard (contact_id =
        "dashboard"). FastMCP's resolver (ResourceManager.get_resource
        at resource_manager.py:94) checks the static _resources dict
        FIRST, so the dashboard URI always resolves to the static
        handler — the template fallback never fires. This test locks
        that priority: HTML + text URIs are registered as STATIC (not
        templated), and the template does not displace them.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://contacts/dashboard"
        txt_uri = "g8://contacts/dashboard.txt"

        # Must be static (no path params) — register in _resources.
        assert html_uri in resources, (
            "contacts dashboard HTML URI must register as a static resource"
        )
        assert txt_uri in resources, (
            "contacts dashboard text URI must register as a static resource"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        # Must NOT appear in the template registry.
        assert html_uri not in templates
        assert txt_uri not in templates

        # Sibling Upgrade-1 g8://contacts (JSON list) must still coexist.
        assert "g8://contacts" in resources, (
            "Upgrade-1 JSON contacts list must not be displaced by the dashboard"
        )

        # Dashboard surfaces must be distinct objects from the JSON list.
        assert resources[html_uri] is not resources["g8://contacts"]

        # The per-contact detail template must still be registered and
        # match actual contact_id URIs (so drill-down from dashboard
        # into a contact keeps working).
        detail_tpl = templates.get("g8://contacts/{contact_id}")
        assert detail_tpl is not None, (
            "per-contact detail template must still register after #58"
        )
        assert detail_tpl.matches("g8://contacts/abc123") is not None, (
            "per-contact detail template must still match real contact_id URIs"
        )

        # Critical priority lock: FastMCP's resource manager checks the
        # static _resources dict FIRST (resource_manager.py:94). Even
        # though the template g8://contacts/{contact_id} would formally
        # match /dashboard, the static entry wins. Verify resolution
        # priority by looking up via the public handler.
        assert server._resource_manager._resources.get(html_uri) is not None
        assert server._resource_manager._resources.get(txt_uri) is not None
        # The static resource we get back must be the dashboard (not a
        # contact detail). Guard this by checking the resource name.
        html_name = resources[html_uri].name
        assert "dashboard" in html_name.lower() or "contacts_dashboard" in html_name, (
            f"expected contacts_dashboard handler name, got {html_name!r}"
        )

    def test_companies_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #59: org-wide companies dashboard.

        Static URIs (2-segment, no path params):
          - g8://companies/dashboard      (HTML)
          - g8://companies/dashboard.txt  (text)

        Mirrors #58 (contacts dashboard) structure. Distinct from the
        Upgrade-1 JSON list at g8://companies and from the per-company
        detail template g8://companies/{company_id}. Renders the full
        org company index with 4-card KPI strip (total / with-domain /
        with-linkedin / with-employees), industry / employee-size /
        country chip clusters, and truncated row list with drill-down
        pointers to detail, notes, contacts, deals.

        Collision note: g8://companies/{company_id} is a 2-segment
        template that would formally match /dashboard (company_id =
        "dashboard"). FastMCP's ResourceManager.get_resource
        (resource_manager.py:94) checks the static _resources dict
        FIRST — static always wins. This test locks that priority.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://companies/dashboard"
        txt_uri = "g8://companies/dashboard.txt"

        assert html_uri in resources, (
            "companies dashboard HTML URI must register as a static resource"
        )
        assert txt_uri in resources, (
            "companies dashboard text URI must register as a static resource"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        assert html_uri not in templates
        assert txt_uri not in templates

        # Sibling Upgrade-1 g8://companies (JSON list) must still coexist.
        assert "g8://companies" in resources, (
            "Upgrade-1 JSON companies list must not be displaced by #59"
        )
        assert resources[html_uri] is not resources["g8://companies"]

        # Per-company detail template must still match real company_id URIs.
        detail_tpl = templates.get("g8://companies/{company_id}")
        assert detail_tpl is not None, (
            "per-company detail template must still register after #59"
        )
        assert detail_tpl.matches("g8://companies/abc123") is not None, (
            "per-company detail template must still match real company_id URIs"
        )

        # Sibling #58 (contacts dashboard) must also coexist.
        assert "g8://contacts/dashboard" in resources, (
            "sibling #58 must coexist with #59"
        )

        # Resource name must name the dashboard handler (not a company detail).
        html_name = resources[html_uri].name
        assert "dashboard" in html_name.lower() or "companies_dashboard" in html_name, (
            f"expected companies_dashboard handler name, got {html_name!r}"
        )

    def test_deals_dashboard_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #60: org-wide deals dashboard.

        Static URIs (2-segment, no path params):
          - g8://deals/dashboard      (HTML)
          - g8://deals/dashboard.txt  (text)

        Sibling to surfaces #58 (contacts dashboard) and #59 (companies
        dashboard). Distinct from the Upgrade-1 `g8://deals/pipeline`
        (stage-grouped kanban — same endpoint, different lens) and from
        the per-deal detail template g8://deals/{deal_id}. Renders the
        org-wide deals index with 4-card KPI strip (total / pipeline-
        value / avg / with-close-date), stage / horizon / currency chip
        clusters, and amount-sorted row list with drill-down pointers.

        Collision note: g8://deals/{deal_id} is a 2-segment template
        that would formally match /dashboard (deal_id = "dashboard").
        FastMCP's ResourceManager.get_resource (resource_manager.py:94)
        checks the static _resources dict FIRST — static always wins.
        This test locks that priority.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        resources = server._resource_manager._resources
        templates = server._resource_manager._templates

        html_uri = "g8://deals/dashboard"
        txt_uri = "g8://deals/dashboard.txt"

        assert html_uri in resources, (
            "deals dashboard HTML URI must register as a static resource"
        )
        assert txt_uri in resources, (
            "deals dashboard text URI must register as a static resource"
        )
        assert str(resources[html_uri].mime_type) == "text/html"
        assert str(resources[txt_uri].mime_type) == "text/plain"

        assert html_uri not in templates
        assert txt_uri not in templates

        # Sibling Upgrade-1 g8://deals/pipeline (stage-kanban) must still coexist.
        assert "g8://deals/pipeline" in resources, (
            "Upgrade-1 deals pipeline must not be displaced by #60"
        )
        assert resources[html_uri] is not resources["g8://deals/pipeline"]

        # Per-deal detail template must still match real deal_id URIs.
        detail_tpl = templates.get("g8://deals/{deal_id}")
        assert detail_tpl is not None, (
            "per-deal detail template must still register after #60"
        )
        assert detail_tpl.matches("g8://deals/abc123-def") is not None, (
            "per-deal detail template must still match real deal_id URIs"
        )

        # Sibling #58 (contacts dashboard) and #59 (companies dashboard) must coexist.
        assert "g8://contacts/dashboard" in resources, (
            "sibling #58 must coexist with #60"
        )
        assert "g8://companies/dashboard" in resources, (
            "sibling #59 must coexist with #60"
        )

        # Resource name must name the dashboard handler (not a deal detail).
        html_name = resources[html_uri].name
        assert "dashboard" in html_name.lower() or "deals_dashboard" in html_name, (
            f"expected deals_dashboard handler name, got {html_name!r}"
        )

    def test_pipeline_deals_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #61: per-pipeline deals (3-segment template).

        Templated URIs (3 segments, literal trailing ``/deals``):
          - g8://pipelines/{pipeline_id}/deals      (HTML)
          - g8://pipelines/{pipeline_id}/deals.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://pipelines/overview`` (surface #14) lives in
            the static ``_resources`` dict and must NOT be captured by the
            new 3-seg template.
          - Static 2-seg ``g8://deals/dashboard`` / ``g8://deals/pipeline``
            (surfaces #60 / #11) start with ``deals``, not ``pipelines``,
            so cannot collide.
          - The literal ``/deals`` trailing segment prevents FastMCP's
            ``[^/]+`` regex from capturing ``{pipeline_id}`` as ``pid.txt``
            — the same trick used by surfaces #38 (/contacts) and #46
            (/runs).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://pipelines/{pipeline_id}/deals"
        txt_uri = "g8://pipelines/{pipeline_id}/deals.txt"

        assert html_uri in templates, (
            "pipeline deals HTML template must register"
        )
        assert txt_uri in templates, (
            "pipeline deals text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #14 (pipelines/overview) must still register as static
        # and NOT be shadowed by the new template. It has 2 segments with
        # literal "overview" — different from the 3-seg template shape.
        assert "g8://pipelines/overview" in resources, (
            "surface #14 pipelines overview must still register"
        )
        assert "g8://pipelines/overview.txt" in resources

        # Sibling #60 (deals/dashboard) and #11 (deals/pipeline) must still
        # register. Different first segment ("deals" vs "pipelines") —
        # cannot collide with the new surface.
        assert "g8://deals/dashboard" in resources
        assert "g8://deals/pipeline" in resources

        # Sibling per-deal detail template (#24) must still register.
        detail_tpl = templates.get("g8://deals/{deal_id}")
        assert detail_tpl is not None, (
            "per-deal detail template must still register after #61"
        )

        # Unambiguous dispatch across URI shapes.
        samples = [
            ("g8://pipelines/pipe-nb-42/deals", html_uri),
            ("g8://pipelines/pipe-nb-42/deals.txt", txt_uri),
            # UUID-style id
            (
                "g8://pipelines/11111111-1111-1111-1111-111111111111/deals",
                html_uri,
            ),
            # id with hyphens + digits
            ("g8://pipelines/new-business-2026/deals", html_uri),
        ]
        for uri, expected in samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [expected], (
                f"{uri} should uniquely match {expected}; got {matches}"
            )

        # Static ``g8://pipelines/overview`` / ``.txt`` must not be captured
        # by the new template — static dispatch wins in FastMCP's
        # ResourceManager, and the shape is 2-seg anyway.
        for static_uri in ("g8://pipelines/overview", "g8://pipelines/overview.txt"):
            template_matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(static_uri) is not None
            ]
            assert html_uri not in template_matches, (
                f"static overview URI {static_uri} must not be captured by "
                f"{html_uri} template"
            )
            assert txt_uri not in template_matches, (
                f"static overview URI {static_uri} must not be captured by "
                f"{txt_uri} template"
            )

        # Resource template name must point at the pipeline_deals handler,
        # not a per-deal drill-down.
        html_name = templates[html_uri].name
        assert "pipeline" in html_name.lower() or "pipeline_deals" in html_name, (
            f"expected pipeline_deals handler name, got {html_name!r}"
        )

    def test_icp_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #62: per-ICP detail (2-segment template).

        Templated URIs (2 segments, icp_id captured):
          - g8://icps/{icp_id}      (HTML)
          - g8://icps/{icp_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://icps/dashboard`` (surface #13) lives in
            the static ``_resources`` dict and MUST win over the new
            template — FastMCP's ResourceManager checks ``_resources``
            before ``_templates`` for exact literal URIs. Same pattern
            shipped safely in surfaces #58 (contacts/dashboard +
            contacts/{contact_id}) and #59 (companies/dashboard +
            companies/{company_id}).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://icps/{icp_id}"
        txt_uri = "g8://icps/{icp_id}.txt"

        assert html_uri in templates, (
            "ICP detail HTML template must register"
        )
        assert txt_uri in templates, (
            "ICP detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #13 (icps/dashboard) must still register as static and
        # must NOT be shadowed by the new template in dispatch — static
        # wins for exact literal URIs in FastMCP's ResourceManager.
        assert "g8://icps/dashboard" in resources, (
            "surface #13 icps dashboard must still register as static"
        )
        assert "g8://icps/dashboard.txt" in resources

        # Sibling surfaces: persona dashboard (#3) and global context
        # library (#23) must still register.
        assert "g8://personas/dashboard" in resources
        assert "g8://global-context/library" in resources

        # Sibling per-entity detail templates (#25 / #26) must still
        # register after #62 (no cross-resource-manager corruption).
        assert "g8://contacts/{contact_id}" in templates
        assert "g8://companies/{company_id}" in templates

        # Unambiguous dispatch across HTML URI shapes. Note: the ``.txt``
        # sibling is inherently ambiguous at the regex level because
        # FastMCP's default ``[^/]+`` template capture accepts ``xxx.txt``
        # as a valid icp_id — the dispatcher resolves this at request
        # time via longest-literal-match, not here. Same pattern as
        # surfaces #25 (contacts/{contact_id}) and #26 (companies/
        # {company_id}); see those tests for the identical approach.
        html_only_samples = [
            "g8://icps/icp-mid-saas",
            # UUID-style id
            "g8://icps/11111111-1111-1111-1111-111111111111",
            # id with digits + hyphens
            "g8://icps/mid-market-2026",
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [html_uri], (
                f"{uri} should uniquely match {html_uri}; got {matches}"
            )

        # The ``.txt`` URI must be matched by the ``.txt`` template at
        # minimum — FastMCP's dispatcher will pick the longest-literal
        # match (the ``.txt`` template) when both templates match.
        txt_uri_sample = "g8://icps/icp-mid-saas.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Static ``g8://icps/dashboard`` / ``.txt`` literal URIs: the
        # dispatcher must resolve them via the static dict. Even if the
        # template regex happens to accept the URI, static lookup wins
        # first, so we just assert they exist as statics.
        assert "g8://icps/dashboard" in resources
        assert "g8://icps/dashboard.txt" in resources

        # Resource template name must point at the icp_detail handler,
        # not back at the dashboard.
        html_name = templates[html_uri].name
        assert "icp_detail" in html_name or "icp" in html_name.lower(), (
            f"expected icp_detail handler name, got {html_name!r}"
        )

    def test_persona_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #63: per-persona detail (2-segment template).

        Templated URIs (2 segments, persona_id captured):
          - g8://personas/{persona_id}      (HTML)
          - g8://personas/{persona_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://personas/dashboard`` (surface #3) lives
            in the static ``_resources`` dict and MUST win over the new
            template — FastMCP's ResourceManager checks ``_resources``
            before ``_templates`` for exact literal URIs. Same pattern
            shipped safely in surfaces #58 (contacts), #59 (companies),
            and #62 (icps).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://personas/{persona_id}"
        txt_uri = "g8://personas/{persona_id}.txt"

        assert html_uri in templates, (
            "Persona detail HTML template must register"
        )
        assert txt_uri in templates, (
            "Persona detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #3 (personas/dashboard) must still register as static
        # and must NOT be shadowed by the new template in dispatch —
        # static wins for exact literal URIs in FastMCP's ResourceManager.
        assert "g8://personas/dashboard" in resources, (
            "surface #3 personas dashboard must still register as static"
        )
        assert "g8://personas/dashboard.txt" in resources

        # Sibling surfaces: ICP dashboard (#13), ICP detail (#62), and
        # global context library (#23) must still register.
        assert "g8://icps/dashboard" in resources
        assert "g8://global-context/library" in resources
        assert "g8://icps/{icp_id}" in templates

        # Sibling per-entity detail templates (#25 / #26) must still
        # register after #63 (no cross-resource-manager corruption).
        assert "g8://contacts/{contact_id}" in templates
        assert "g8://companies/{company_id}" in templates

        # Unambiguous dispatch across HTML URI shapes. Note: the ``.txt``
        # sibling is inherently ambiguous at the regex level because
        # FastMCP's default ``[^/]+`` template capture accepts ``xxx.txt``
        # as a valid persona_id — the dispatcher resolves this at request
        # time via longest-literal-match, not here. Same pattern as
        # surfaces #25, #26, and #62.
        html_only_samples = [
            "g8://personas/p-vp-eng",
            # UUID-style id
            "g8://personas/22222222-2222-2222-2222-222222222222",
            # id with digits + hyphens
            "g8://personas/vp-eng-midmarket-2026",
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert matches == [html_uri], (
                f"{uri} should uniquely match {html_uri}; got {matches}"
            )

        # The ``.txt`` URI must be matched by the ``.txt`` template at
        # minimum — FastMCP's dispatcher will pick the longest-literal
        # match (the ``.txt`` template) when both templates match.
        txt_uri_sample = "g8://personas/p-vp-eng.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Static ``g8://personas/dashboard`` / ``.txt`` literal URIs: the
        # dispatcher must resolve them via the static dict. Even if the
        # template regex happens to accept the URI, static lookup wins
        # first, so we just assert they exist as statics.
        assert "g8://personas/dashboard" in resources
        assert "g8://personas/dashboard.txt" in resources

        # Resource template name must point at the persona_detail handler,
        # not back at the dashboard.
        html_name = templates[html_uri].name
        assert "persona_detail" in html_name or "persona" in html_name.lower(), (
            f"expected persona_detail handler name, got {html_name!r}"
        )

    def test_list_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #64: per-list detail (2-segment template).

        Templated URIs (2 segments, list_id captured):
          - g8://lists/{list_id}      (HTML)
          - g8://lists/{list_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://lists/dashboard`` (surface #5) lives in
            the static ``_resources`` dict and MUST win over the new
            template — FastMCP's ResourceManager checks ``_resources``
            before ``_templates`` for exact literal URIs. Same pattern
            shipped safely in surfaces #58 (contacts), #59 (companies),
            #62 (icps), #63 (personas).
          - 3-seg ``g8://lists/{list_id}/contacts`` template (surface
            #38) must remain intact: different segment count, no
            collision.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://lists/{list_id}"
        txt_uri = "g8://lists/{list_id}.txt"

        assert html_uri in templates, (
            "List detail HTML template must register"
        )
        assert txt_uri in templates, (
            "List detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #5 (lists/dashboard) must still register as static
        # and must NOT be shadowed by the new template in dispatch —
        # static wins for exact literal URIs in FastMCP's ResourceManager.
        assert "g8://lists/dashboard" in resources, (
            "surface #5 lists dashboard must still register as static"
        )
        assert "g8://lists/dashboard.txt" in resources

        # Sibling 3-seg template #38 (list contacts) must still register;
        # different segment count means no collision with the new 2-seg
        # list-detail template.
        assert "g8://lists/{list_id}/contacts" in templates, (
            "surface #38 list contacts template must still register"
        )

        # Sibling surfaces from recent surfaces must still register —
        # confirms no cross-resource-manager corruption.
        assert "g8://personas/{persona_id}" in templates  # #63
        assert "g8://icps/{icp_id}" in templates  # #62
        assert "g8://contacts/{contact_id}" in templates  # #58
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://personas/dashboard" in resources  # #3
        assert "g8://icps/dashboard" in resources  # #13

        # Unambiguous dispatch across HTML URI shapes. List ids are
        # ints in the API payload; URIs accept both numeric and
        # string forms. Note: the ``.txt`` sibling is inherently
        # ambiguous at the regex level because FastMCP's default
        # ``[^/]+`` template capture accepts ``xxx.txt`` as a valid
        # list_id — the dispatcher resolves this at request time via
        # longest-literal-match, not here.
        html_only_samples = [
            "g8://lists/42",  # pure digits (API form)
            "g8://lists/list-vip-q2-2026",  # slug
            # UUID-style id (if ever used)
            "g8://lists/550e8400-e29b-41d4-a716-446655440000",
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            # The 2-seg HTML template must be in the match set. The
            # 3-seg `/contacts` template must NOT match (wrong seg
            # count). No other template should match a bare 2-seg
            # `g8://lists/...` URI.
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            assert "g8://lists/{list_id}/contacts" not in matches, (
                f"{uri} must NOT match the 3-seg /contacts template"
            )

        # The ``.txt`` URI must be matched by the ``.txt`` template at
        # minimum — FastMCP's dispatcher will pick the longest-literal
        # match (the ``.txt`` template) when both templates match.
        txt_uri_sample = "g8://lists/42.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Static ``g8://lists/dashboard`` / ``.txt`` literal URIs: the
        # dispatcher must resolve them via the static dict. Even if the
        # template regex happens to accept the URI, static lookup wins
        # first, so we just assert they exist as statics.
        assert "g8://lists/dashboard" in resources
        assert "g8://lists/dashboard.txt" in resources

        # Resource template name must point at the list_detail handler,
        # not back at the dashboard or the members surface.
        html_name = templates[html_uri].name
        assert "list_detail" in html_name or "list" in html_name.lower(), (
            f"expected list_detail handler name, got {html_name!r}"
        )

    def test_gc_doc_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #65: per-global-context-document detail (3-segment template).

        Templated URIs (3 segments, doc_id captured):
          - g8://global-context/documents/{doc_id}      (HTML)
          - g8://global-context/documents/{doc_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://global-context/library`` (surface #15)
            lives in the static ``_resources`` dict and does NOT collide
            with the new 3-seg template — different segment count.
          - FastMCP ResourceManager checks ``_resources`` before
            ``_templates`` for exact literal URIs.
          - Sibling 2-seg templates from recent surfaces (#58/#59/#62/#63
            contacts/companies/icps/personas) and the 2-seg #64 list
            detail template must remain intact — different URI prefix,
            no collision.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://global-context/documents/{doc_id}"
        txt_uri = "g8://global-context/documents/{doc_id}.txt"

        assert html_uri in templates, (
            "Global-context doc detail HTML template must register"
        )
        assert txt_uri in templates, (
            "Global-context doc detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #15 (global-context/library) must still register as a
        # 2-seg static. 2-seg static + 3-seg template: no collision.
        assert "g8://global-context/library" in resources, (
            "surface #15 global-context library must still register as static"
        )
        assert "g8://global-context/library.txt" in resources

        # Sibling surfaces from recent surfaces must still register —
        # confirms no cross-resource-manager corruption.
        assert "g8://lists/{list_id}" in templates  # #64
        assert "g8://personas/{persona_id}" in templates  # #63
        assert "g8://icps/{icp_id}" in templates  # #62
        assert "g8://contacts/{contact_id}" in templates  # #58
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://personas/dashboard" in resources  # #3
        assert "g8://icps/dashboard" in resources  # #13
        assert "g8://lists/dashboard" in resources  # #5

        # Unambiguous dispatch across HTML URI shapes. Doc ids in the
        # studio API are UUIDs; URIs accept any opaque shape. Note: the
        # ``.txt`` sibling is inherently ambiguous at the regex level
        # because FastMCP's default ``[^/]+`` template capture accepts
        # ``xxx.txt`` as a valid doc_id — the dispatcher resolves this
        # at request time via longest-literal-match, not here.
        html_only_samples = [
            "g8://global-context/documents/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd",
            "g8://global-context/documents/brand_brief",  # slug-like
            "g8://global-context/documents/42",  # numeric-like
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            # The 3-seg HTML template must be in the match set.
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )

        # The ``.txt`` URI must be matched by the ``.txt`` template at
        # minimum — FastMCP's dispatcher picks longest-literal match.
        txt_uri_sample = "g8://global-context/documents/brand_brief.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Static ``g8://global-context/library`` / ``.txt`` literal URIs
        # must still be statics (different segment count from 3-seg
        # template anyway, but belt-and-suspenders).
        assert "g8://global-context/library" in resources
        assert "g8://global-context/library.txt" in resources

        # Resource template name must point at the gc_doc_detail handler,
        # not back at the library surface.
        html_name = templates[html_uri].name
        assert "gc_doc" in html_name.lower() or "global_context" in html_name.lower() or "document" in html_name.lower(), (
            f"expected gc_doc_detail handler name, got {html_name!r}"
        )

    def test_task_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #67: per-task detail (2-segment template).

        Templated URIs (2 segments, task_id captured):
          - g8://tasks/{task_id}      (HTML)
          - g8://tasks/{task_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://tasks/dashboard`` (surface #12) lives
            in the static ``_resources`` dict.
          - FastMCP ResourceManager checks ``_resources`` BEFORE
            ``_templates`` for exact literal URIs — so
            ``g8://tasks/dashboard`` routes to the dashboard handler,
            never the template handler.
          - Any other 2-seg URI (task UUID / slug) hits the template.
          - Sibling 2-seg templates (#58 contacts, #59 companies,
            #62 icps, #63 personas, #64 lists) and 3-seg template #65
            must remain intact — different URI prefix, no collision.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://tasks/{task_id}"
        txt_uri = "g8://tasks/{task_id}.txt"

        assert html_uri in templates, (
            "Task detail HTML template must register"
        )
        assert txt_uri in templates, (
            "Task detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #12 tasks/dashboard must still register as a static.
        # 2-seg static + 2-seg template coexist because FastMCP checks
        # _resources (literal match) before _templates (regex match).
        assert "g8://tasks/dashboard" in resources, (
            "surface #12 tasks dashboard must still register as static"
        )
        assert "g8://tasks/dashboard.txt" in resources

        # Sibling dashboards from other surfaces must still register.
        assert "g8://personas/dashboard" in resources  # #3
        assert "g8://icps/dashboard" in resources  # #13
        assert "g8://lists/dashboard" in resources  # #5
        assert "g8://global-context/library" in resources  # #15
        assert "g8://copilot/home" in resources  # #66

        # Sibling templates from recent surfaces must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #58
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://icps/{icp_id}" in templates  # #62
        assert "g8://personas/{persona_id}" in templates  # #63
        assert "g8://lists/{list_id}" in templates  # #64
        assert "g8://global-context/documents/{doc_id}" in templates  # #65

        # Dispatch check: a task UUID/slug URI must match the template.
        html_only_samples = [
            "g8://tasks/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd",
            "g8://tasks/task_abc123",
            "g8://tasks/42",
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )

        # The .txt URI must be matched by the .txt template.
        txt_uri_sample = "g8://tasks/task_abc123.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the task_detail handler.
        html_name = templates[html_uri].name
        assert "task" in html_name.lower(), (
            f"expected task_detail handler name, got {html_name!r}"
        )

    def test_activity_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #68: per-activity detail (2-segment template).

        Templated URIs (2 segments, activity_id captured):
          - g8://activities/{activity_id}      (HTML)
          - g8://activities/{activity_id}.txt  (text)

        Dispatch safety:
          - Static 2-seg ``g8://activities/feed`` (surface #10) lives
            in the static ``_resources`` dict.
          - FastMCP ResourceManager checks ``_resources`` BEFORE
            ``_templates`` for exact literal URIs — so
            ``g8://activities/feed`` routes to the feed handler,
            never the template handler.
          - Any other 2-seg URI (activity UUID / slug) hits the
            template.
          - Sibling 2-seg templates (#58 contacts, #59 companies,
            #62 icps, #63 personas, #64 lists, #67 tasks) and
            3-seg template #65 must remain intact — different URI
            prefix, no collision.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://activities/{activity_id}"
        txt_uri = "g8://activities/{activity_id}.txt"

        assert html_uri in templates, (
            "Activity detail HTML template must register"
        )
        assert txt_uri in templates, (
            "Activity detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling #10 activities/feed must still register as a static.
        # 2-seg static + 2-seg template coexist because FastMCP checks
        # _resources (literal match) before _templates (regex match).
        assert "g8://activities/feed" in resources, (
            "surface #10 activities feed must still register as static"
        )
        assert "g8://activities/feed.txt" in resources

        # Sibling dashboards from other surfaces must still register.
        assert "g8://personas/dashboard" in resources  # #3
        assert "g8://icps/dashboard" in resources  # #13
        assert "g8://lists/dashboard" in resources  # #5
        assert "g8://global-context/library" in resources  # #15
        assert "g8://tasks/dashboard" in resources  # #12
        assert "g8://copilot/home" in resources  # #66

        # Sibling templates from recent surfaces must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #58
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://icps/{icp_id}" in templates  # #62
        assert "g8://personas/{persona_id}" in templates  # #63
        assert "g8://lists/{list_id}" in templates  # #64
        assert "g8://global-context/documents/{doc_id}" in templates  # #65
        assert "g8://tasks/{task_id}" in templates  # #67

        # Dispatch check: an activity UUID/slug URI must match the template.
        html_only_samples = [
            "g8://activities/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd",
            "g8://activities/act_abc123",
            "g8://activities/42",
        ]
        for uri in html_only_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )

        # The .txt URI must be matched by the .txt template.
        txt_uri_sample = "g8://activities/act_abc123.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_uri_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_uri_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the activity_detail handler.
        html_name = templates[html_uri].name
        assert "activity" in html_name.lower(), (
            f"expected activity_detail handler name, got {html_name!r}"
        )

    def test_company_activities_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #69: per-company activities (3-seg template).

        Templated URIs (3 segments, company_id captured):
          - g8://companies/{company_id}/activities      (HTML)
          - g8://companies/{company_id}/activities.txt  (text)

        Dispatch safety:
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Sibling 3-seg templates (#37 /notes, #41 /deals, #46
            /contacts) under ``g8://companies/{company_id}`` must
            remain intact — they are disambiguated by their trailing
            suffix in the regex.
          - The 2-seg static ``g8://companies/dashboard`` and the
            2-seg template ``g8://companies/{company_id}`` (surface
            #59) must remain intact.
          - Cousin template ``g8://contacts/{contact_id}/activities``
            (surface #53) must remain intact — different URI prefix.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://companies/{company_id}/activities"
        txt_uri = "g8://companies/{company_id}/activities.txt"

        assert html_uri in templates, (
            "Company activities HTML template must register"
        )
        assert txt_uri in templates, (
            "Company activities text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling 3-seg templates under companies/{id} must remain intact.
        assert "g8://companies/{company_id}/notes" in templates  # #37
        assert "g8://companies/{company_id}/deals" in templates  # #41
        assert "g8://companies/{company_id}/contacts" in templates  # #46

        # Parent 2-seg template + static must remain intact.
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://companies/dashboard" in resources  # surface #22

        # Cousin 3-seg template under contacts/{id} must remain intact.
        assert "g8://contacts/{contact_id}/activities" in templates  # #53

        # Activity detail (#68) 2-seg template must remain intact.
        assert "g8://activities/{activity_id}" in templates  # #68
        assert "g8://activities/feed" in resources  # #10

        # Other recent statics / templates remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://tasks/{task_id}" in templates  # #67

        # Dispatch check: a company UUID/slug + /activities URI must
        # match the company_activities template (and NOT the parent
        # 2-seg template or the /notes/deals/contacts siblings).
        html_samples = [
            "g8://companies/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd/activities",
            "g8://companies/comp_abc123/activities",
            "g8://companies/42/activities",
        ]
        for uri in html_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Sibling 3-seg templates must NOT match.
            for sibling in (
                "g8://companies/{company_id}/notes",
                "g8://companies/{company_id}/deals",
                "g8://companies/{company_id}/contacts",
            ):
                assert sibling not in matches, (
                    f"{uri} unexpectedly matched sibling {sibling}"
                )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://companies/comp_abc123/activities.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the company_activities
        # handler (not some other renderer).
        html_name = templates[html_uri].name
        assert "company" in html_name.lower() and "activit" in html_name.lower(), (
            f"expected company_activities handler name, got {html_name!r}"
        )

    def test_deal_activities_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #70: per-deal activities (3-seg template).

        Templated URIs (3 segments, deal_id captured):
          - g8://deals/{deal_id}/activities      (HTML)
          - g8://deals/{deal_id}/activities.txt  (text)

        Dispatch safety:
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Parent 2-seg template ``g8://deals/{deal_id}`` (surface #24)
            must remain intact and must NOT match the 3-seg
            ``/activities`` URI.
          - Cousin 3-seg templates — ``g8://contacts/{contact_id}/activities``
            (#53) and ``g8://companies/{company_id}/activities`` (#69) —
            must remain intact. Different URI prefix, no mutation.
          - Activity detail (#68) 2-seg template and the org-wide
            (#10) activities feed static must remain intact.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://deals/{deal_id}/activities"
        txt_uri = "g8://deals/{deal_id}/activities.txt"

        assert html_uri in templates, (
            "Deal activities HTML template must register"
        )
        assert txt_uri in templates, (
            "Deal activities text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Parent 2-seg template (#24) must remain intact.
        assert "g8://deals/{deal_id}" in templates  # #24

        # Cousin 3-seg templates must remain intact (same /activities suffix,
        # different URI prefix — disambiguated by the regex).
        assert "g8://contacts/{contact_id}/activities" in templates  # #53
        assert "g8://companies/{company_id}/activities" in templates  # #69

        # Activity detail (#68) 2-seg template must remain intact.
        assert "g8://activities/{activity_id}" in templates  # #68
        assert "g8://activities/feed" in resources  # #10

        # Other recent statics / templates remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://tasks/{task_id}" in templates  # #67

        # Dispatch check: a deal UUID/slug + /activities URI must
        # match the deal_activities template (and NOT the parent
        # 2-seg deal template, nor cousin /activities templates).
        html_samples = [
            "g8://deals/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd/activities",
            "g8://deals/deal_abc123/activities",
            "g8://deals/42/activities",
        ]
        for uri in html_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Cousin 3-seg /activities templates must NOT match a deals URI.
            for cousin in (
                "g8://contacts/{contact_id}/activities",
                "g8://companies/{company_id}/activities",
            ):
                assert cousin not in matches, (
                    f"{uri} unexpectedly matched cousin {cousin}"
                )
            # Parent 2-seg deal template must NOT match the 3-seg URI.
            assert "g8://deals/{deal_id}" not in matches, (
                f"{uri} unexpectedly matched the 2-seg parent template"
            )

        # Dispatch check the opposite direction: a 2-seg deal URI must
        # match the parent template and NOT the 3-seg /activities template.
        parent_sample = "g8://deals/deal_abc123"
        parent_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(parent_sample) is not None
        ]
        assert "g8://deals/{deal_id}" in parent_matches, (
            f"{parent_sample} must match the 2-seg deal template"
        )
        assert html_uri not in parent_matches, (
            f"{parent_sample} must NOT match the 3-seg /activities template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://deals/deal_abc123/activities.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the deal_activities
        # handler (not some other renderer).
        html_name = templates[html_uri].name
        assert "deal" in html_name.lower() and "activit" in html_name.lower(), (
            f"expected deal_activities handler name, got {html_name!r}"
        )

    def test_sequence_step_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #71: per-sequence-step detail (4-seg template).

        Templated URIs (4 segments, sequence_id + step_id captured):
          - g8://sequences/{sequence_id}/steps/{step_id}      (HTML)
          - g8://sequences/{sequence_id}/steps/{step_id}.txt  (text)

        Dispatch safety:
          - 4-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - 3-seg sibling templates in sequences/ must remain intact and
            must NOT match the 4-seg ``/steps/`` URI:
              * ``g8://sequences/{sequence_id}/overview``  (#47)
              * ``g8://sequences/{sequence_id}/preview``   (#6)
              * ``g8://sequences/{sequence_id}/analytics`` (#23)
              * ``g8://sequences/{sequence_id}/contacts``  (#40)
          - 2-seg static dashboard (#9) must remain intact.
          - The new 4-seg template must NOT match a 3-seg /preview URI
            (bidirectional dispatch lock).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://sequences/{sequence_id}/steps/{step_id}"
        txt_uri = "g8://sequences/{sequence_id}/steps/{step_id}.txt"

        assert html_uri in templates, (
            "Sequence step detail HTML template must register"
        )
        assert txt_uri in templates, (
            "Sequence step detail text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling 3-seg templates in sequences/ must remain intact.
        assert "g8://sequences/{sequence_id}/overview" in templates   # #47
        assert "g8://sequences/{sequence_id}/preview" in templates    # #6
        assert "g8://sequences/{sequence_id}/analytics" in templates  # #23
        assert "g8://sequences/{sequence_id}/contacts" in templates   # #40

        # Static 2-seg sequences dashboard (#9) must remain intact.
        assert "g8://sequences/dashboard" in resources  # #9

        # Other recent statics / templates remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://deals/{deal_id}/activities" in templates  # #70

        # Dispatch check: a sequence_id + /steps/ + step_id URI must
        # match the step-detail template (and NOT the 3-seg sibling
        # templates that share the same sequence prefix).
        html_samples = [
            "g8://sequences/seq_8ab27791efff40deaaaa/steps/step_1e7d9a",
            "g8://sequences/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd/steps/42",
            "g8://sequences/seq_abc/steps/step_xyz",
        ]
        for uri in html_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # 3-seg siblings must NOT match a 4-seg URI.
            for sibling in (
                "g8://sequences/{sequence_id}/overview",
                "g8://sequences/{sequence_id}/preview",
                "g8://sequences/{sequence_id}/analytics",
                "g8://sequences/{sequence_id}/contacts",
            ):
                assert sibling not in matches, (
                    f"{uri} unexpectedly matched 3-seg sibling {sibling}"
                )

        # Dispatch check the opposite direction: a 3-seg preview URI
        # must match the preview template and NOT the 4-seg step-detail
        # template.
        preview_sample = "g8://sequences/seq_abc/preview"
        preview_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(preview_sample) is not None
        ]
        assert "g8://sequences/{sequence_id}/preview" in preview_matches, (
            f"{preview_sample} must match the 3-seg preview template"
        )
        assert html_uri not in preview_matches, (
            f"{preview_sample} must NOT match the 4-seg step-detail template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://sequences/seq_abc/steps/step_xyz.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the sequence_step_detail
        # handler (not some other renderer).
        html_name = templates[html_uri].name
        assert (
            "sequence" in html_name.lower()
            and "step" in html_name.lower()
            and "detail" in html_name.lower()
        ), f"expected sequence_step_detail handler name, got {html_name!r}"

    def test_sequence_inbox_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #72: per-sequence inbox (3-seg template).

        Templated URIs (3 segments, sequence_id captured):
          - g8://sequences/{sequence_id}/inbox      (HTML)
          - g8://sequences/{sequence_id}/inbox.txt  (text)

        Backend: reuses ``GET /inbox?sequence_id={id}`` (inbox_router
        maps the filter to ``campaign_ids=[sequence_id]`` internally).

        Dispatch safety:
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Other 3-seg sibling templates in sequences/ must remain
            intact and must NOT match the new ``/inbox`` URI:
              * ``g8://sequences/{sequence_id}/overview``  (#47)
              * ``g8://sequences/{sequence_id}/preview``   (#6)
              * ``g8://sequences/{sequence_id}/analytics`` (#23)
              * ``g8://sequences/{sequence_id}/contacts``  (#40)
          - 4-seg ``/steps/{step_id}`` template (#71) must remain
            intact and must NOT match the 3-seg ``/inbox`` URI.
          - 2-seg static dashboard (#9) must remain intact.
          - Bidirectional dispatch lock: a 3-seg ``/inbox`` URI matches
            only the new template; a 3-seg ``/preview`` URI matches
            only the preview template; a 4-seg ``/steps/step_1`` URI
            matches only the step-detail template.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://sequences/{sequence_id}/inbox"
        txt_uri = "g8://sequences/{sequence_id}/inbox.txt"

        assert html_uri in templates, (
            "Sequence inbox HTML template must register"
        )
        assert txt_uri in templates, (
            "Sequence inbox text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling 3-seg templates in sequences/ must remain intact.
        assert "g8://sequences/{sequence_id}/overview" in templates   # #47
        assert "g8://sequences/{sequence_id}/preview" in templates    # #6
        assert "g8://sequences/{sequence_id}/analytics" in templates  # #23
        assert "g8://sequences/{sequence_id}/contacts" in templates   # #40

        # 4-seg step-detail template (#71) must remain intact.
        assert "g8://sequences/{sequence_id}/steps/{step_id}" in templates

        # Static 2-seg sequences dashboard (#9) must remain intact.
        assert "g8://sequences/dashboard" in resources  # #9

        # Other recent statics / templates remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://deals/{deal_id}/activities" in templates  # #70

        # Dispatch check: a 3-seg /inbox URI must match ONLY the new
        # inbox template (and NOT the 3-seg siblings that share the
        # same ``sequences/{id}/`` prefix).
        inbox_samples = [
            "g8://sequences/seq_8ab27791efff40deaaaa/inbox",
            "g8://sequences/7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd/inbox",
            "g8://sequences/seq_abc/inbox",
        ]
        for uri in inbox_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            for sibling in (
                "g8://sequences/{sequence_id}/overview",
                "g8://sequences/{sequence_id}/preview",
                "g8://sequences/{sequence_id}/analytics",
                "g8://sequences/{sequence_id}/contacts",
                "g8://sequences/{sequence_id}/steps/{step_id}",
            ):
                assert sibling not in matches, (
                    f"{uri} unexpectedly matched sibling {sibling}"
                )

        # Opposite direction: a 3-seg /preview URI must match the
        # preview template and NOT the new inbox template.
        preview_sample = "g8://sequences/seq_abc/preview"
        preview_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(preview_sample) is not None
        ]
        assert "g8://sequences/{sequence_id}/preview" in preview_matches, (
            f"{preview_sample} must match the 3-seg preview template"
        )
        assert html_uri not in preview_matches, (
            f"{preview_sample} must NOT match the 3-seg inbox template"
        )

        # Opposite direction: a 4-seg /steps/{step_id} URI must match
        # the step-detail template and NOT the new 3-seg inbox template.
        steps_sample = "g8://sequences/seq_abc/steps/step_1"
        steps_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(steps_sample) is not None
        ]
        assert "g8://sequences/{sequence_id}/steps/{step_id}" in steps_matches, (
            f"{steps_sample} must match the 4-seg step-detail template"
        )
        assert html_uri not in steps_matches, (
            f"{steps_sample} must NOT match the 3-seg inbox template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://sequences/seq_abc/inbox.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the sequence_inbox handler.
        html_name = templates[html_uri].name
        assert (
            "sequence" in html_name.lower() and "inbox" in html_name.lower()
        ), f"expected sequence_inbox handler name, got {html_name!r}"

    def test_inbox_channel_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #73: channel-scoped inbox (3-seg template).

        Templated URIs (3 segments, channel captured):
          - g8://inbox/channels/{channel}      (HTML)
          - g8://inbox/channels/{channel}.txt  (text)

        Backend: ``GET /inbox?channel={channel}&page=1&page_size=50``
        where channel ∈ {email, sms, linkedin}. Heyreach is aliased to
        linkedin inside the renderer.

        Dispatch safety:
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Sibling 3-seg ``/threads/{reply_id}`` template (#30) must
            remain intact and must NOT match the new ``/channels/{ch}``
            URI.
          - Sibling 4-seg ``/threads/{reply_id}/draft`` template (#51)
            must remain intact and must NOT match the 3-seg channel URI.
          - Cousin 3-seg ``/sequences/{id}/inbox`` template (#72) must
            remain intact — different prefix, different handler.
          - 2-seg static ``/inbox/dashboard`` (#16) must remain intact.
          - Bidirectional dispatch lock: a 3-seg ``/channels/{ch}`` URI
            matches only the new template; a 3-seg ``/threads/{id}`` URI
            matches only the thread-detail template; a 4-seg
            ``/threads/{id}/draft`` URI matches only the draft template.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://inbox/channels/{channel}"
        txt_uri = "g8://inbox/channels/{channel}.txt"

        assert html_uri in templates, (
            "Inbox channel HTML template must register"
        )
        assert txt_uri in templates, (
            "Inbox channel text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling templates in inbox/ must remain intact.
        assert "g8://inbox/threads/{reply_id}" in templates         # #30
        assert "g8://inbox/threads/{reply_id}/draft" in templates   # #51

        # Cousin 3-seg template in sequences/ (#72) must remain intact.
        assert "g8://sequences/{sequence_id}/inbox" in templates

        # Static 2-seg inbox dashboard (#16) must remain intact.
        assert "g8://inbox/dashboard" in resources

        # Other recent surfaces must remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://deals/{deal_id}/activities" in templates  # #70
        assert "g8://sequences/{sequence_id}/steps/{step_id}" in templates  # #71

        # Dispatch check: a 3-seg /channels/{ch} URI must match ONLY the
        # new channel template.
        channel_samples = [
            "g8://inbox/channels/email",
            "g8://inbox/channels/sms",
            "g8://inbox/channels/linkedin",
            "g8://inbox/channels/heyreach",
            "g8://inbox/channels/bogus",
        ]
        for uri in channel_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            for sibling in (
                "g8://inbox/threads/{reply_id}",
                "g8://inbox/threads/{reply_id}/draft",
                "g8://sequences/{sequence_id}/inbox",
                "g8://sequences/{sequence_id}/steps/{step_id}",
            ):
                assert sibling not in matches, (
                    f"{uri} unexpectedly matched sibling {sibling}"
                )

        # Opposite direction: a 3-seg /threads/{id} URI must match the
        # thread-detail template and NOT the new channel template.
        thread_sample = "g8://inbox/threads/reply_abc"
        thread_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(thread_sample) is not None
        ]
        assert "g8://inbox/threads/{reply_id}" in thread_matches, (
            f"{thread_sample} must match the 3-seg thread-detail template"
        )
        assert html_uri not in thread_matches, (
            f"{thread_sample} must NOT match the 3-seg channel template"
        )

        # Opposite direction: a 4-seg /threads/{id}/draft URI must match
        # the draft template and NOT the new 3-seg channel template.
        draft_sample = "g8://inbox/threads/reply_abc/draft"
        draft_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(draft_sample) is not None
        ]
        assert "g8://inbox/threads/{reply_id}/draft" in draft_matches, (
            f"{draft_sample} must match the 4-seg draft template"
        )
        assert html_uri not in draft_matches, (
            f"{draft_sample} must NOT match the 3-seg channel template"
        )

        # Cousin dispatch: /sequences/{id}/inbox must NOT match the new
        # channel template (different prefix).
        seq_inbox_sample = "g8://sequences/seq_abc/inbox"
        seq_inbox_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(seq_inbox_sample) is not None
        ]
        assert "g8://sequences/{sequence_id}/inbox" in seq_inbox_matches, (
            f"{seq_inbox_sample} must match the sequence-inbox template"
        )
        assert html_uri not in seq_inbox_matches, (
            f"{seq_inbox_sample} must NOT match the channel template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://inbox/channels/email.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the inbox_channel handler.
        html_name = templates[html_uri].name
        assert (
            "inbox" in html_name.lower() and "channel" in html_name.lower()
        ), f"expected inbox_channel handler name, got {html_name!r}"

    def test_tasks_status_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #74: status-scoped tasks pane (3-seg template).

        Templated URIs (3 segments, status captured):
          - g8://tasks/status/{status}      (HTML)
          - g8://tasks/status/{status}.txt  (text)

        Backend: ``GET /tasks?status={status}&limit=100`` where
        ``status`` ∈ {open, in_progress, blocked, completed, cancelled}.
        The renderer also accepts case-insensitive inputs and aliases
        (``done`` → completed, ``todo`` → open).

        Dispatch safety (critical — 2-seg {task_id} template under same
        prefix):
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Sibling 2-seg template ``g8://tasks/{task_id}`` (#67) must
            remain intact and must NOT match the new 3-seg
            ``/status/{status}`` URI (literal ``/status/`` prefix
            prevents cross-match with the {task_id} capture).
          - 2-seg static ``g8://tasks/dashboard`` (#12) must remain
            intact (in ``_resources``).
          - Bidirectional dispatch lock: a 3-seg ``/status/{ch}`` URI
            matches only the new template; a 2-seg ``/{task_id}`` URI
            matches only the task-detail template.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://tasks/status/{status}"
        txt_uri = "g8://tasks/status/{status}.txt"

        assert html_uri in templates, (
            "Tasks status HTML template must register"
        )
        assert txt_uri in templates, (
            "Tasks status text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling templates/statics under tasks/ must remain intact.
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://tasks/dashboard" in resources  # #12

        # Other recent surfaces must remain intact.
        assert "g8://inbox/channels/{channel}" in templates  # #73
        assert "g8://sequences/{sequence_id}/inbox" in templates  # #72
        assert "g8://sequences/{sequence_id}/steps/{step_id}" in templates  # #71
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check: a 3-seg /status/{st} URI must match ONLY the
        # new status template.
        status_samples = [
            "g8://tasks/status/open",
            "g8://tasks/status/in_progress",
            "g8://tasks/status/completed",
            "g8://tasks/status/bogus",  # renderer handles invalid
            "g8://tasks/status/todo",  # alias, renderer normalizes
        ]
        for uri in status_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {task_id} template MUST NOT match 3-seg URI.
            assert "g8://tasks/{task_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{task_id}} template"
            )

        # Opposite direction: a 2-seg /{task_id} URI must match the
        # task-detail template and NOT the new status template.
        task_sample = "g8://tasks/task_abc"
        task_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(task_sample) is not None
        ]
        assert "g8://tasks/{task_id}" in task_matches, (
            f"{task_sample} must match the 2-seg {{task_id}} template"
        )
        assert html_uri not in task_matches, (
            f"{task_sample} must NOT match the 3-seg status template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://tasks/status/open.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the tasks_status handler.
        html_name = templates[html_uri].name
        assert (
            "task" in html_name.lower() and "status" in html_name.lower()
        ), f"expected tasks_status handler name, got {html_name!r}"

    def test_tasks_priority_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #75: priority-scoped tasks pane (3-seg template).

        Templated URIs (3 segments, priority captured):
          - g8://tasks/priority/{priority}      (HTML)
          - g8://tasks/priority/{priority}.txt  (text)

        Backend: ``GET /tasks?priority={int}&limit=100`` where the URI
        param (p1/p2/p3/p4 or urgent/high/medium/low or 1-4) is mapped
        to the integer filter before the backend call. Invalid URI keys
        short-circuit the fetch with ``None`` so the renderer emits the
        'unavailable' empty state.

        Dispatch safety (critical — 2-seg {task_id} AND 3-seg /status/{st}
        templates both exist under the same prefix):
          - 3-segment URI lives in ``_templates`` (regex match), not
            ``_resources`` (literal).
          - Sibling 2-seg template ``g8://tasks/{task_id}`` (#67) must
            remain intact and must NOT match the new 3-seg
            ``/priority/{priority}`` URI.
          - Sibling 3-seg template ``g8://tasks/status/{status}`` (#74)
            must remain intact and must NOT match the new 3-seg
            ``/priority/{priority}`` URI (literal ``/priority/`` vs
            ``/status/`` prefix distinguishes them).
          - 2-seg static ``g8://tasks/dashboard`` (#12) must remain
            intact (in ``_resources``).
          - Tridirectional dispatch lock: a 3-seg ``/priority/{p}`` URI
            matches only the new template; a 3-seg ``/status/{s}`` URI
            matches only #74; a 2-seg ``/{task_id}`` URI matches only
            #67.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://tasks/priority/{priority}"
        txt_uri = "g8://tasks/priority/{priority}.txt"

        assert html_uri in templates, (
            "Tasks priority HTML template must register"
        )
        assert txt_uri in templates, (
            "Tasks priority text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling templates/statics under tasks/ must remain intact.
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://tasks/status/{status}" in templates  # #74
        assert "g8://tasks/dashboard" in resources  # #12

        # Other recent surfaces must remain intact.
        assert "g8://inbox/channels/{channel}" in templates  # #73
        assert "g8://sequences/{sequence_id}/inbox" in templates  # #72
        assert "g8://sequences/{sequence_id}/steps/{step_id}" in templates  # #71
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check: a 3-seg /priority/{p} URI must match ONLY the
        # new priority template — NOT the 2-seg {task_id} and NOT the
        # 3-seg /status/{s} sibling.
        priority_samples = [
            "g8://tasks/priority/p1",
            "g8://tasks/priority/p2",
            "g8://tasks/priority/p3",
            "g8://tasks/priority/p4",
            "g8://tasks/priority/urgent",  # alias, renderer normalizes
            "g8://tasks/priority/high",
            "g8://tasks/priority/1",  # raw int alias
            "g8://tasks/priority/bogus",  # invalid — renderer handles
        ]
        for uri in priority_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {task_id} template MUST NOT match 3-seg URI.
            assert "g8://tasks/{task_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{task_id}} template"
            )
            # Critical: 3-seg status sibling MUST NOT match priority URI.
            assert "g8://tasks/status/{status}" not in matches, (
                f"{uri} unexpectedly matched 3-seg status template"
            )

        # Opposite direction #1: a 3-seg /status/{s} URI must match
        # ONLY the status template (#74), not the new priority template.
        status_sample = "g8://tasks/status/open"
        status_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(status_sample) is not None
        ]
        assert "g8://tasks/status/{status}" in status_matches, (
            f"{status_sample} must match the 3-seg status template"
        )
        assert html_uri not in status_matches, (
            f"{status_sample} must NOT match the 3-seg priority template"
        )

        # Opposite direction #2: a 2-seg /{task_id} URI must match the
        # task-detail template and NOT the priority or status templates.
        task_sample = "g8://tasks/task_abc"
        task_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(task_sample) is not None
        ]
        assert "g8://tasks/{task_id}" in task_matches, (
            f"{task_sample} must match the 2-seg {{task_id}} template"
        )
        assert html_uri not in task_matches, (
            f"{task_sample} must NOT match the 3-seg priority template"
        )
        assert "g8://tasks/status/{status}" not in task_matches, (
            f"{task_sample} must NOT match the 3-seg status template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://tasks/priority/p1.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the tasks_priority handler.
        html_name = templates[html_uri].name
        assert (
            "task" in html_name.lower()
            and "priority" in html_name.lower()
        ), f"expected tasks_priority handler name, got {html_name!r}"

    def test_contacts_seniority_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #76: seniority-scoped contacts pane (3-seg template).

        Templated URIs (3 segments, seniority captured):
          - g8://contacts/seniority/{seniority}      (HTML)
          - g8://contacts/seniority/{seniority}.txt  (text)

        Backend: ``GET /contacts?seniority_level=<normalized>&limit=100``.
        Invalid URI keys short-circuit the fetch with ``None`` so the
        renderer emits the 'unavailable' state (zero backend traffic).

        Dispatch safety — two siblings exist under ``g8://contacts/``:
          - 2-seg template ``g8://contacts/{contact_id}`` (#3)
          - 2-seg static   ``g8://contacts/dashboard``    (#9)
          - 3-seg template ``g8://contacts/seniority/{seniority}`` (#76)

        A 3-seg URI under ``g8://contacts/`` with literal prefix
        ``/seniority/`` must match ONLY the new template; a 2-seg URI
        must match ONLY ``{contact_id}``; the ``dashboard`` literal must
        remain a static resource.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://contacts/seniority/{seniority}"
        txt_uri = "g8://contacts/seniority/{seniority}.txt"

        assert html_uri in templates, (
            "Contacts seniority HTML template must register"
        )
        assert txt_uri in templates, (
            "Contacts seniority text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Sibling templates/statics under contacts/ must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #3
        assert "g8://contacts/dashboard" in resources  # #9

        # Recent surfaces must remain intact.
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://tasks/status/{status}" in templates  # #74
        assert "g8://inbox/channels/{channel}" in templates  # #73
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check: a 3-seg /seniority/{s} URI must match ONLY
        # the new template — NOT the 2-seg {contact_id} sibling.
        seniority_samples = [
            "g8://contacts/seniority/c_suite",
            "g8://contacts/seniority/vp",
            "g8://contacts/seniority/director",
            "g8://contacts/seniority/manager",
            "g8://contacts/seniority/ic",
            "g8://contacts/seniority/ceo",  # alias
            "g8://contacts/seniority/svp",  # alias
            "g8://contacts/seniority/bogus",  # invalid — renderer handles
        ]
        for uri in seniority_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {contact_id} MUST NOT match 3-seg URI.
            assert "g8://contacts/{contact_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{contact_id}} template"
            )

        # Opposite direction: a 2-seg /{contact_id} URI must match the
        # contact-detail template and NOT the seniority template.
        contact_sample = "g8://contacts/abc123"
        contact_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(contact_sample) is not None
        ]
        assert "g8://contacts/{contact_id}" in contact_matches, (
            f"{contact_sample} must match the 2-seg {{contact_id}} template"
        )
        assert html_uri not in contact_matches, (
            f"{contact_sample} must NOT match the 3-seg seniority template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://contacts/seniority/vp.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the contacts_seniority handler.
        html_name = templates[html_uri].name
        assert (
            "contact" in html_name.lower()
            and "seniority" in html_name.lower()
        ), f"expected contacts_seniority handler name, got {html_name!r}"

    def test_contacts_department_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #77: department-scoped contacts pane (3-seg template).

        Templated URIs (3 segments, department captured):
          - g8://contacts/department/{department}      (HTML)
          - g8://contacts/department/{department}.txt  (text)

        Backend: ``GET /contacts?job_department=<normalized>&limit=100``
        (ILIKE partial match, contacts_router.py:117). Invalid URI keys
        short-circuit the fetch with ``None`` so the renderer emits the
        'unavailable' state (zero backend traffic).

        **Tridirectional dispatch safety** — four siblings now coexist
        under ``g8://contacts/``:
          - 2-seg template ``g8://contacts/{contact_id}``        (#3)
          - 2-seg static   ``g8://contacts/dashboard``           (#9)
          - 3-seg template ``g8://contacts/seniority/{seniority}`` (#76)
          - 3-seg template ``g8://contacts/department/{department}`` (#77 — this)

        Each family must match ONLY its intended URIs:
          - 3-seg ``/department/<d>``  → ONLY the new department template
          - 3-seg ``/seniority/<s>``   → ONLY the #76 sibling (unchanged)
          - 2-seg ``/<contact_id>``    → ONLY the detail template (unchanged)
          - 2-seg ``/dashboard``       → static resource (unchanged)
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://contacts/department/{department}"
        txt_uri = "g8://contacts/department/{department}.txt"

        assert html_uri in templates, (
            "Contacts department HTML template must register"
        )
        assert txt_uri in templates, (
            "Contacts department text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All sibling families under contacts/ must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #3
        assert "g8://contacts/dashboard" in resources  # #9
        assert "g8://contacts/seniority/{seniority}" in templates  # #76

        # Recent surfaces must remain intact.
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://tasks/status/{status}" in templates  # #74
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /department/<d> URIs must match ONLY
        # the new template — NOT the 2-seg {contact_id} or 3-seg seniority.
        department_samples = [
            "g8://contacts/department/sales",
            "g8://contacts/department/marketing",
            "g8://contacts/department/engineering",
            "g8://contacts/department/customer_success",
            "g8://contacts/department/operations",
            "g8://contacts/department/sdr",  # alias → sales
            "g8://contacts/department/eng",  # alias → engineering
            "g8://contacts/department/bogus",  # invalid — renderer handles
        ]
        for uri in department_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {contact_id} MUST NOT match 3-seg URI.
            assert "g8://contacts/{contact_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{contact_id}} template"
            )
            # Critical: 3-seg seniority sibling MUST NOT match /department/ URI.
            assert "g8://contacts/seniority/{seniority}" not in matches, (
                f"{uri} unexpectedly matched 3-seg seniority sibling"
            )

        # Dispatch check #2: 3-seg /seniority/<s> URIs must STILL match
        # ONLY the #76 sibling — NOT the new #77 department template.
        seniority_samples = [
            "g8://contacts/seniority/c_suite",
            "g8://contacts/seniority/vp",
            "g8://contacts/seniority/ceo",  # alias
        ]
        for uri in seniority_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/seniority/{seniority}" in matches, (
                f"{uri} should still match the #76 seniority template"
            )
            # Critical: #77 department template MUST NOT match /seniority/ URI.
            assert html_uri not in matches, (
                f"{uri} unexpectedly matched 3-seg #77 department template"
            )

        # Dispatch check #3: 2-seg /{contact_id} URIs must match the
        # contact-detail template and NOT either 3-seg template.
        contact_sample = "g8://contacts/abc123"
        contact_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(contact_sample) is not None
        ]
        assert "g8://contacts/{contact_id}" in contact_matches, (
            f"{contact_sample} must match the 2-seg {{contact_id}} template"
        )
        assert html_uri not in contact_matches, (
            f"{contact_sample} must NOT match the 3-seg #77 department template"
        )
        assert "g8://contacts/seniority/{seniority}" not in contact_matches, (
            f"{contact_sample} must NOT match the 3-seg #76 seniority template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://contacts/department/sales.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the contacts_department handler.
        html_name = templates[html_uri].name
        assert (
            "contact" in html_name.lower()
            and "department" in html_name.lower()
        ), f"expected contacts_department handler name, got {html_name!r}"

    def test_companies_industry_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #78: industry-scoped companies pane (3-seg template).

        Templated URIs (3 segments, industry captured):
          - g8://companies/industry/{industry}      (HTML)
          - g8://companies/industry/{industry}.txt  (text)

        Backend: ``GET /companies?industry=<normalized>&limit=100``
        (developer_api/interfaces/v1/companies_router.py:84 — ILIKE partial
        match). Invalid URI keys short-circuit the fetch with ``None`` so
        the renderer emits the 'unavailable' state (zero backend traffic).

        **Quad-directional dispatch safety** — five siblings now coexist
        under ``g8://companies/``:
          - 2-seg template ``g8://companies/{company_id}``            (#26)
          - 2-seg static   ``g8://companies/dashboard``                (#59)
          - 3-seg template ``g8://companies/{company_id}/notes``       (#37)
          - 3-seg template ``g8://companies/{company_id}/deals``       (#42)
          - 3-seg template ``g8://companies/{company_id}/contacts``    (#46)
          - 3-seg template ``g8://companies/{company_id}/activities``  (#47)
          - 3-seg template ``g8://companies/industry/{industry}``      (#78 — this)

        Each family must match ONLY its intended URIs:
          - 3-seg ``/industry/<v>``     → ONLY the new industry template
          - 3-seg ``/<id>/notes``       → ONLY the #37 sibling (unchanged)
          - 3-seg ``/<id>/deals``       → ONLY the #42 sibling (unchanged)
          - 3-seg ``/<id>/contacts``    → ONLY the #46 sibling (unchanged)
          - 3-seg ``/<id>/activities``  → ONLY the #47 sibling (unchanged)
          - 2-seg ``/<company_id>``     → ONLY the detail template (unchanged)
          - 2-seg ``/dashboard``        → static resource (unchanged)

        Note on benign collision: FastMCP templates are literal-prefix
        dispatched, so ``g8://companies/industry/notes`` would match BOTH
        ``/industry/{industry}`` AND ``/{company_id}/notes`` (treating
        "industry" as a valid ``company_id`` value). This is why the
        ``_COMPANIES_INDUSTRY_VALID`` + aliases explicitly exclude the
        literals ``notes``, ``deals``, ``contacts``, and ``activities``
        (locked by ``test_no_alias_collides_with_nested_literals`` in the
        unit renderer test file).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://companies/industry/{industry}"
        txt_uri = "g8://companies/industry/{industry}.txt"

        assert html_uri in templates, (
            "Companies industry HTML template must register"
        )
        assert txt_uri in templates, (
            "Companies industry text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All sibling families under companies/ must remain intact.
        assert "g8://companies/{company_id}" in templates  # #26
        assert "g8://companies/dashboard" in resources  # #59
        assert "g8://companies/{company_id}/notes" in templates  # #37
        assert "g8://companies/{company_id}/deals" in templates  # #42
        assert "g8://companies/{company_id}/contacts" in templates  # #46
        assert "g8://companies/{company_id}/activities" in templates  # #47

        # Recent surfaces must remain intact.
        assert "g8://contacts/department/{department}" in templates  # #77
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /industry/<v> URIs must match the new
        # template. Because FastMCP treats the industry segment as a valid
        # ``{company_id}`` value, the 3-seg ``{company_id}/notes`` family
        # would also match if we ever used the literals notes/deals/etc. —
        # hence the canonical+aliases exclude those strings. For legitimate
        # industry values, only the new template must match.
        industry_samples = [
            "g8://companies/industry/saas",
            "g8://companies/industry/fintech",
            "g8://companies/industry/healthcare",
            "g8://companies/industry/manufacturing",
            "g8://companies/industry/retail",
            "g8://companies/industry/software",  # alias → saas
            "g8://companies/industry/pharma",    # alias → biotech
            "g8://companies/industry/proptech",  # alias → real_estate
            "g8://companies/industry/bogus",     # invalid — renderer handles
        ]
        for uri in industry_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {company_id} MUST NOT match 3-seg URI.
            assert "g8://companies/{company_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{company_id}} template"
            )
            # The 3-seg nested siblings accept ANY {company_id} value, so
            # they would technically match if the URI's final segment were
            # notes/deals/etc. — but our canonical+aliases exclude those,
            # and all these industry samples are in industry-only space.
            assert "g8://companies/{company_id}/notes" not in matches, (
                f"{uri} unexpectedly matched 3-seg notes sibling"
            )
            assert "g8://companies/{company_id}/deals" not in matches, (
                f"{uri} unexpectedly matched 3-seg deals sibling"
            )
            assert "g8://companies/{company_id}/contacts" not in matches, (
                f"{uri} unexpectedly matched 3-seg contacts sibling"
            )
            assert "g8://companies/{company_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg activities sibling"
            )

        # Dispatch check #2: 3-seg /<id>/notes URIs must STILL match
        # ONLY the #37 sibling — NOT the new #78 industry template.
        notes_samples = [
            "g8://companies/42/notes",
            "g8://companies/acme-inc/notes",
        ]
        for uri in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/{company_id}/notes" in matches, (
                f"{uri} should still match the #37 notes template"
            )
            # The industry template would ALSO match (literal "42"/"acme-inc"
            # are valid capture values), but since the renderer rejects any
            # non-industry value as ``None`` → 'unavailable', this is safe.
            # We only need to assert the correct sibling is still present.

        # Dispatch check #3: 3-seg /<id>/deals URIs still match ONLY #42.
        deals_sample = "g8://companies/99/deals"
        deals_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deals_sample) is not None
        ]
        assert "g8://companies/{company_id}/deals" in deals_matches, (
            f"{deals_sample} must still match the #42 deals template"
        )

        # Dispatch check #4: 2-seg /{company_id} URIs must match the
        # company-detail template and NOT any 3-seg template.
        company_sample = "g8://companies/abc123"
        company_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(company_sample) is not None
        ]
        assert "g8://companies/{company_id}" in company_matches, (
            f"{company_sample} must match the 2-seg {{company_id}} template"
        )
        assert html_uri not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #78 industry template"
        )
        assert "g8://companies/{company_id}/notes" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #37 notes template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://companies/industry/saas.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the companies_industry handler.
        html_name = templates[html_uri].name
        assert (
            "compan" in html_name.lower()
            and "industry" in html_name.lower()
        ), f"expected companies_industry handler name, got {html_name!r}"

    def test_companies_country_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #79: country-scoped companies pane (3-seg template).

        Templated URIs (3 segments, country captured):
          - g8://companies/country/{country}      (HTML)
          - g8://companies/country/{country}.txt  (text)

        Backend: ``GET /companies?country=<title_case>&limit=100``
        (developer_api/interfaces/v1/companies_router.py:91-92 — EXACT
        match, not ILIKE). Unlike the #78 industry surface, country filter
        values must resolve through ``_companies_country_backend_value``
        from URI slug to canonical TITLE-CASE (e.g. ``united_states`` →
        ``United States``). Invalid URI keys short-circuit the fetch with
        ``None`` so the renderer emits the 'unavailable' state.

        **Quint-directional dispatch safety** — seven siblings now coexist
        under ``g8://companies/``:
          - 2-seg template ``g8://companies/{company_id}``            (#26)
          - 2-seg static   ``g8://companies/dashboard``                (#59)
          - 3-seg template ``g8://companies/{company_id}/notes``       (#37)
          - 3-seg template ``g8://companies/{company_id}/deals``       (#42)
          - 3-seg template ``g8://companies/{company_id}/contacts``    (#46)
          - 3-seg template ``g8://companies/{company_id}/activities``  (#47)
          - 3-seg template ``g8://companies/industry/{industry}``      (#78)
          - 3-seg template ``g8://companies/country/{country}``        (#79 — this)

        Each family must match ONLY its intended URIs:
          - 3-seg ``/country/<v>``      → ONLY the new country template
          - 3-seg ``/industry/<v>``     → ONLY the #78 sibling (unchanged)
          - 3-seg ``/<id>/notes``       → ONLY the #37 sibling (unchanged)
          - 3-seg ``/<id>/deals``       → ONLY the #42 sibling (unchanged)
          - 3-seg ``/<id>/contacts``    → ONLY the #46 sibling (unchanged)
          - 3-seg ``/<id>/activities``  → ONLY the #47 sibling (unchanged)
          - 2-seg ``/<company_id>``     → ONLY the detail template (unchanged)
          - 2-seg ``/dashboard``        → static resource (unchanged)

        Note on benign collision: FastMCP templates are literal-prefix
        dispatched, so ``g8://companies/country/notes`` would match BOTH
        ``/country/{country}`` AND ``/{company_id}/notes`` (treating
        "country" as a valid ``company_id`` value). This is why the
        ``_COMPANIES_COUNTRY_VALID`` + aliases explicitly exclude the
        literals ``notes``, ``deals``, ``contacts``, ``activities``,
        ``dashboard``, and ``industry`` (locked by
        ``test_no_alias_collides_with_nested_literals`` in the unit
        renderer test file).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://companies/country/{country}"
        txt_uri = "g8://companies/country/{country}.txt"

        assert html_uri in templates, (
            "Companies country HTML template must register"
        )
        assert txt_uri in templates, (
            "Companies country text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All sibling families under companies/ must remain intact.
        assert "g8://companies/{company_id}" in templates  # #26
        assert "g8://companies/dashboard" in resources  # #59
        assert "g8://companies/{company_id}/notes" in templates  # #37
        assert "g8://companies/{company_id}/deals" in templates  # #42
        assert "g8://companies/{company_id}/contacts" in templates  # #46
        assert "g8://companies/{company_id}/activities" in templates  # #47
        assert "g8://companies/industry/{industry}" in templates  # #78

        # Recent surfaces must remain intact.
        assert "g8://contacts/department/{department}" in templates  # #77
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /country/<v> URIs must match the new
        # template and NOT match any sibling family. Because FastMCP
        # treats the country segment as a valid ``{company_id}`` value,
        # the 3-seg ``{company_id}/notes`` family would also match if we
        # ever used the literals notes/deals/etc. — hence the canonical
        # + aliases exclude those strings (and ``industry`` too, to
        # prevent collision with sibling #78).
        country_samples = [
            "g8://companies/country/united_states",
            "g8://companies/country/united_kingdom",
            "g8://companies/country/germany",
            "g8://companies/country/france",
            "g8://companies/country/canada",
            "g8://companies/country/india",
            "g8://companies/country/brazil",
            "g8://companies/country/japan",
            "g8://companies/country/uae",
            "g8://companies/country/us",          # alias → united_states
            "g8://companies/country/uk",          # alias → united_kingdom
            "g8://companies/country/deutschland", # alias → germany
            "g8://companies/country/bogus",       # invalid — renderer handles
        ]
        for uri in country_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {company_id} MUST NOT match 3-seg URI.
            assert "g8://companies/{company_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{company_id}} template"
            )
            # The 3-seg nested siblings accept ANY {company_id} value, so
            # they would technically match if the URI's final segment were
            # notes/deals/etc. — but our canonical+aliases exclude those,
            # so legitimate country URIs cannot alias to those siblings.
            assert "g8://companies/{company_id}/notes" not in matches, (
                f"{uri} unexpectedly matched 3-seg notes sibling"
            )
            assert "g8://companies/{company_id}/deals" not in matches, (
                f"{uri} unexpectedly matched 3-seg deals sibling"
            )
            assert "g8://companies/{company_id}/contacts" not in matches, (
                f"{uri} unexpectedly matched 3-seg contacts sibling"
            )
            assert "g8://companies/{company_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg activities sibling"
            )
            # Cross-axis sibling: #78 industry template MUST NOT match
            # (different 2nd-segment literal: "country" vs "industry").
            assert "g8://companies/industry/{industry}" not in matches, (
                f"{uri} unexpectedly matched #78 industry sibling"
            )

        # Dispatch check #2: 3-seg /industry/<v> URIs must STILL match
        # ONLY the #78 sibling — NOT the new #79 country template.
        industry_samples = [
            "g8://companies/industry/saas",
            "g8://companies/industry/fintech",
        ]
        for uri in industry_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/industry/{industry}" in matches, (
                f"{uri} should still match the #78 industry template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #79 country template "
                f"(2nd segment is 'industry', not 'country')"
            )

        # Dispatch check #3: 3-seg /<id>/notes URIs still match ONLY #37.
        notes_samples = [
            "g8://companies/42/notes",
            "g8://companies/acme-inc/notes",
        ]
        for uri in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/{company_id}/notes" in matches, (
                f"{uri} should still match the #37 notes template"
            )

        # Dispatch check #4: 3-seg /<id>/deals URIs still match ONLY #42.
        deals_sample = "g8://companies/99/deals"
        deals_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deals_sample) is not None
        ]
        assert "g8://companies/{company_id}/deals" in deals_matches, (
            f"{deals_sample} must still match the #42 deals template"
        )

        # Dispatch check #5: 2-seg /{company_id} URIs must match the
        # company-detail template and NOT any 3-seg template.
        company_sample = "g8://companies/abc123"
        company_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(company_sample) is not None
        ]
        assert "g8://companies/{company_id}" in company_matches, (
            f"{company_sample} must match the 2-seg {{company_id}} template"
        )
        assert html_uri not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #79 country template"
        )
        assert "g8://companies/industry/{industry}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #78 industry template"
        )
        assert "g8://companies/{company_id}/notes" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #37 notes template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://companies/country/united_states.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the companies_country handler.
        html_name = templates[html_uri].name
        assert (
            "compan" in html_name.lower()
            and "country" in html_name.lower()
        ), f"expected companies_country handler name, got {html_name!r}"

    def test_companies_size_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #80: size-tier-scoped companies pane (3-seg template).

        Templated URIs (3 segments, size tier captured):
          - g8://companies/size/{tier}      (HTML)
          - g8://companies/size/{tier}.txt  (text)

        Backend: ``GET /companies?employee_count_min=<min>[&employee_count_max=<max>]&limit=100``
        — this is the THIRD distinct backend filter pattern under
        companies/:
          - #78 industry: ILIKE partial match on ``industry`` field
          - #79 country:  EXACT match on ``country`` field (title-cased)
          - #80 size:     RANGE filter on ``employee_count`` (min/max)

        The 5 canonical tiers (``micro``/``smb``/``mid``/``large``/
        ``enterprise``) resolve via ``_COMPANIES_SIZE_RANGE`` to
        ``(min:int, max:int|None)`` tuples. The enterprise tier carries
        ``max=None`` (open-ended 1001+), so the URL construction omits
        the ``employee_count_max`` param for that tier. Invalid URI keys
        short-circuit the fetch with ``None`` → renderer emits the
        'unavailable' state (no backend call).

        **Sext-directional dispatch safety** — nine sibling families now
        coexist under ``g8://companies/``:
          - 2-seg template ``g8://companies/{company_id}``            (#26)
          - 2-seg static   ``g8://companies/dashboard``                (#59)
          - 3-seg template ``g8://companies/{company_id}/notes``       (#37)
          - 3-seg template ``g8://companies/{company_id}/deals``       (#42)
          - 3-seg template ``g8://companies/{company_id}/contacts``    (#46)
          - 3-seg template ``g8://companies/{company_id}/activities``  (#47)
          - 3-seg template ``g8://companies/industry/{industry}``      (#78)
          - 3-seg template ``g8://companies/country/{country}``        (#79)
          - 3-seg template ``g8://companies/size/{tier}``              (#80 — this)

        Each family must match ONLY its intended URIs:
          - 3-seg ``/size/<v>``         → ONLY the new size template
          - 3-seg ``/country/<v>``      → ONLY the #79 sibling (unchanged)
          - 3-seg ``/industry/<v>``     → ONLY the #78 sibling (unchanged)
          - 3-seg ``/<id>/notes``       → ONLY the #37 sibling (unchanged)
          - 3-seg ``/<id>/deals``       → ONLY the #42 sibling (unchanged)
          - 3-seg ``/<id>/contacts``    → ONLY the #46 sibling (unchanged)
          - 3-seg ``/<id>/activities``  → ONLY the #47 sibling (unchanged)
          - 2-seg ``/<company_id>``     → ONLY the detail template (unchanged)
          - 2-seg ``/dashboard``        → static resource (unchanged)

        Collision guard: FastMCP templates are literal-prefix dispatched,
        so ``g8://companies/size/notes`` would technically match BOTH
        ``/size/{tier}`` AND ``/{company_id}/notes`` (treating "size" as
        a valid ``company_id``). The ``_COMPANIES_SIZE_VALID`` set +
        aliases explicitly exclude the literals ``notes``, ``deals``,
        ``contacts``, ``activities``, ``dashboard``, ``industry``, and
        ``country`` (locked by ``test_no_alias_collides_with_nested_literals``
        and ``test_forbidden_literals_excluded`` in the unit renderer
        test file).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://companies/size/{tier}"
        txt_uri = "g8://companies/size/{tier}.txt"

        assert html_uri in templates, (
            "Companies size HTML template must register"
        )
        assert txt_uri in templates, (
            "Companies size text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All sibling families under companies/ must remain intact.
        assert "g8://companies/{company_id}" in templates  # #26
        assert "g8://companies/dashboard" in resources  # #59
        assert "g8://companies/{company_id}/notes" in templates  # #37
        assert "g8://companies/{company_id}/deals" in templates  # #42
        assert "g8://companies/{company_id}/contacts" in templates  # #46
        assert "g8://companies/{company_id}/activities" in templates  # #47
        assert "g8://companies/industry/{industry}" in templates  # #78
        assert "g8://companies/country/{country}" in templates  # #79

        # Recent surfaces must remain intact.
        assert "g8://contacts/department/{department}" in templates  # #77
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /size/<v> URIs must match the new
        # template and NOT match any sibling family. Because FastMCP
        # treats the tier segment as a valid ``{company_id}`` value,
        # the 3-seg ``{company_id}/notes`` family would also match if we
        # ever used the literals notes/deals/etc. — hence the canonical
        # + aliases exclude those strings (and industry/country too, to
        # prevent collision with siblings #78/#79).
        size_samples = [
            "g8://companies/size/micro",
            "g8://companies/size/smb",
            "g8://companies/size/mid",
            "g8://companies/size/large",
            "g8://companies/size/enterprise",
            "g8://companies/size/startup",      # alias → micro
            "g8://companies/size/smallbiz",     # alias → smb
            "g8://companies/size/midmarket",    # alias → mid
            "g8://companies/size/corporate",    # alias → large
            "g8://companies/size/fortune500",   # alias → enterprise
            "g8://companies/size/bogus",        # invalid — renderer handles
        ]
        for uri in size_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {company_id} MUST NOT match 3-seg URI.
            assert "g8://companies/{company_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{company_id}} template"
            )
            # The 3-seg nested siblings accept ANY {company_id} value, so
            # they would technically match if the URI's final segment were
            # notes/deals/etc. — but our canonical+aliases exclude those,
            # so legitimate size URIs cannot alias to those siblings.
            assert "g8://companies/{company_id}/notes" not in matches, (
                f"{uri} unexpectedly matched 3-seg notes sibling"
            )
            assert "g8://companies/{company_id}/deals" not in matches, (
                f"{uri} unexpectedly matched 3-seg deals sibling"
            )
            assert "g8://companies/{company_id}/contacts" not in matches, (
                f"{uri} unexpectedly matched 3-seg contacts sibling"
            )
            assert "g8://companies/{company_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg activities sibling"
            )
            # Cross-axis siblings: #78 industry and #79 country templates
            # MUST NOT match (different 2nd-segment literals).
            assert "g8://companies/industry/{industry}" not in matches, (
                f"{uri} unexpectedly matched #78 industry sibling"
            )
            assert "g8://companies/country/{country}" not in matches, (
                f"{uri} unexpectedly matched #79 country sibling"
            )

        # Dispatch check #2: 3-seg /industry/<v> URIs must STILL match
        # ONLY the #78 sibling — NOT the new #80 size template.
        industry_samples = [
            "g8://companies/industry/saas",
            "g8://companies/industry/fintech",
        ]
        for uri in industry_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/industry/{industry}" in matches, (
                f"{uri} should still match the #78 industry template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #80 size template "
                f"(2nd segment is 'industry', not 'size')"
            )

        # Dispatch check #3: 3-seg /country/<v> URIs must STILL match
        # ONLY the #79 sibling — NOT the new #80 size template.
        country_samples = [
            "g8://companies/country/united_states",
            "g8://companies/country/germany",
        ]
        for uri in country_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/country/{country}" in matches, (
                f"{uri} should still match the #79 country template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #80 size template "
                f"(2nd segment is 'country', not 'size')"
            )

        # Dispatch check #4: 3-seg /<id>/notes URIs still match ONLY #37.
        notes_samples = [
            "g8://companies/42/notes",
            "g8://companies/acme-inc/notes",
        ]
        for uri in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/{company_id}/notes" in matches, (
                f"{uri} should still match the #37 notes template"
            )

        # Dispatch check #5: 3-seg /<id>/deals URIs still match ONLY #42.
        deals_sample = "g8://companies/99/deals"
        deals_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deals_sample) is not None
        ]
        assert "g8://companies/{company_id}/deals" in deals_matches, (
            f"{deals_sample} must still match the #42 deals template"
        )

        # Dispatch check #6: 2-seg /{company_id} URIs must match the
        # company-detail template and NOT any 3-seg template.
        company_sample = "g8://companies/abc123"
        company_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(company_sample) is not None
        ]
        assert "g8://companies/{company_id}" in company_matches, (
            f"{company_sample} must match the 2-seg {{company_id}} template"
        )
        assert html_uri not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #80 size template"
        )
        assert "g8://companies/industry/{industry}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #78 industry template"
        )
        assert "g8://companies/country/{country}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #79 country template"
        )
        assert "g8://companies/{company_id}/notes" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #37 notes template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://companies/size/enterprise.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the companies_size handler.
        html_name = templates[html_uri].name
        assert (
            "compan" in html_name.lower()
            and "size" in html_name.lower()
        ), f"expected companies_size handler name, got {html_name!r}"

    def test_companies_revenue_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #81: revenue-tier-scoped companies pane (3-seg template).

        Templated URIs (3 segments, revenue tier captured):
          - g8://companies/revenue/{tier}      (HTML)
          - g8://companies/revenue/{tier}.txt  (text)

        Backend: ``GET /companies?revenue_min=<usd>[&revenue_max=<usd>]&limit=100``
        — this is the FOURTH distinct backend filter pattern under
        companies/:
          - #78 industry: ILIKE partial match on ``industry`` field
          - #79 country:  EXACT match on ``country`` field (title-cased)
          - #80 size:     INT RANGE on ``employee_count`` (min/max)
          - #81 revenue:  USD RANGE on ``revenue`` (dollar-denominated)

        The 5 canonical tiers (``bootstrap``/``smb``/``mid``/``large``/
        ``enterprise``) resolve via ``_COMPANIES_REVENUE_RANGE`` to
        ``(min_usd:int, max_usd:int|None)`` tuples. The enterprise tier
        carries ``max=None`` (open-ended $1B+), so the URL construction
        omits the ``revenue_max`` param for that tier. Invalid URI keys
        short-circuit the fetch with ``None`` → renderer emits the
        'unavailable' state (no backend call).

        **Sept-directional dispatch safety** — TEN sibling families now
        coexist under ``g8://companies/``:
          - 2-seg template ``g8://companies/{company_id}``            (#26)
          - 2-seg static   ``g8://companies/dashboard``                (#59)
          - 3-seg template ``g8://companies/{company_id}/notes``       (#37)
          - 3-seg template ``g8://companies/{company_id}/deals``       (#42)
          - 3-seg template ``g8://companies/{company_id}/contacts``    (#46)
          - 3-seg template ``g8://companies/{company_id}/activities``  (#47)
          - 3-seg template ``g8://companies/industry/{industry}``      (#78)
          - 3-seg template ``g8://companies/country/{country}``        (#79)
          - 3-seg template ``g8://companies/size/{tier}``              (#80)
          - 3-seg template ``g8://companies/revenue/{tier}``           (#81 — this)

        Collision guard: FastMCP templates are literal-prefix dispatched,
        so ``g8://companies/revenue/notes`` would technically match BOTH
        ``/revenue/{tier}`` AND ``/{company_id}/notes`` (treating "revenue"
        as a valid ``company_id``). The ``_COMPANIES_REVENUE_VALID`` set +
        aliases explicitly exclude the literals ``notes``, ``deals``,
        ``contacts``, ``activities``, ``dashboard``, ``industry``,
        ``country``, and ``size`` (locked by
        ``test_no_alias_collides_with_nested_literals`` and
        ``test_forbidden_literals_excluded`` in the unit renderer
        test file — 8 forbidden literals total).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://companies/revenue/{tier}"
        txt_uri = "g8://companies/revenue/{tier}.txt"

        assert html_uri in templates, (
            "Companies revenue HTML template must register"
        )
        assert txt_uri in templates, (
            "Companies revenue text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All 9 prior sibling families under companies/ must remain intact.
        assert "g8://companies/{company_id}" in templates  # #26
        assert "g8://companies/dashboard" in resources  # #59
        assert "g8://companies/{company_id}/notes" in templates  # #37
        assert "g8://companies/{company_id}/deals" in templates  # #42
        assert "g8://companies/{company_id}/contacts" in templates  # #46
        assert "g8://companies/{company_id}/activities" in templates  # #47
        assert "g8://companies/industry/{industry}" in templates  # #78
        assert "g8://companies/country/{country}" in templates  # #79
        assert "g8://companies/size/{tier}" in templates  # #80

        # Recent surfaces must remain intact.
        assert "g8://contacts/department/{department}" in templates  # #77
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://tasks/priority/{priority}" in templates  # #75
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /revenue/<v> URIs must match the new
        # template and NOT match any sibling family. Because FastMCP
        # treats the tier segment as a valid ``{company_id}`` value,
        # the 3-seg ``{company_id}/notes`` family would also match if we
        # ever used the literals notes/deals/etc. — hence the canonical
        # + aliases exclude those strings (and industry/country/size too,
        # to prevent collision with siblings #78/#79/#80).
        revenue_samples = [
            "g8://companies/revenue/bootstrap",
            "g8://companies/revenue/smb",
            "g8://companies/revenue/mid",
            "g8://companies/revenue/large",
            "g8://companies/revenue/enterprise",
            "g8://companies/revenue/pre-revenue",   # alias → bootstrap
            "g8://companies/revenue/fortune-500",   # alias → enterprise
            "g8://companies/revenue/billion-plus",  # alias → enterprise
            "g8://companies/revenue/pe-backed",     # alias → large
            "g8://companies/revenue/midmarket",     # alias → mid
            "g8://companies/revenue/bogus",         # invalid — renderer handles
        ]
        for uri in revenue_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {company_id} MUST NOT match 3-seg URI.
            assert "g8://companies/{company_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{company_id}} template"
            )
            # The 3-seg nested siblings accept ANY {company_id} value, so
            # they would technically match if the URI's final segment were
            # notes/deals/etc. — but our canonical+aliases exclude those,
            # so legitimate revenue URIs cannot alias to those siblings.
            assert "g8://companies/{company_id}/notes" not in matches, (
                f"{uri} unexpectedly matched 3-seg notes sibling"
            )
            assert "g8://companies/{company_id}/deals" not in matches, (
                f"{uri} unexpectedly matched 3-seg deals sibling"
            )
            assert "g8://companies/{company_id}/contacts" not in matches, (
                f"{uri} unexpectedly matched 3-seg contacts sibling"
            )
            assert "g8://companies/{company_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg activities sibling"
            )
            # Cross-axis siblings: #78 industry, #79 country, #80 size
            # templates MUST NOT match (different 2nd-segment literals).
            assert "g8://companies/industry/{industry}" not in matches, (
                f"{uri} unexpectedly matched #78 industry sibling"
            )
            assert "g8://companies/country/{country}" not in matches, (
                f"{uri} unexpectedly matched #79 country sibling"
            )
            assert "g8://companies/size/{tier}" not in matches, (
                f"{uri} unexpectedly matched #80 size sibling"
            )

        # Dispatch check #2: 3-seg /industry/<v> URIs must STILL match
        # ONLY the #78 sibling — NOT the new #81 revenue template.
        industry_samples = [
            "g8://companies/industry/saas",
            "g8://companies/industry/fintech",
        ]
        for uri in industry_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/industry/{industry}" in matches, (
                f"{uri} should still match the #78 industry template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #81 revenue template "
                f"(2nd segment is 'industry', not 'revenue')"
            )

        # Dispatch check #3: 3-seg /country/<v> URIs must STILL match
        # ONLY the #79 sibling — NOT the new #81 revenue template.
        country_samples = [
            "g8://companies/country/united_states",
            "g8://companies/country/germany",
        ]
        for uri in country_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/country/{country}" in matches, (
                f"{uri} should still match the #79 country template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #81 revenue template "
                f"(2nd segment is 'country', not 'revenue')"
            )

        # Dispatch check #4: 3-seg /size/<v> URIs must STILL match
        # ONLY the #80 sibling — NOT the new #81 revenue template.
        size_samples = [
            "g8://companies/size/micro",
            "g8://companies/size/enterprise",
        ]
        for uri in size_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/size/{tier}" in matches, (
                f"{uri} should still match the #80 size template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #81 revenue template "
                f"(2nd segment is 'size', not 'revenue')"
            )

        # Dispatch check #5: 3-seg /<id>/notes URIs still match ONLY #37.
        notes_samples = [
            "g8://companies/42/notes",
            "g8://companies/acme-inc/notes",
        ]
        for uri in notes_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://companies/{company_id}/notes" in matches, (
                f"{uri} should still match the #37 notes template"
            )

        # Dispatch check #6: 3-seg /<id>/deals URIs still match ONLY #42.
        deals_sample = "g8://companies/99/deals"
        deals_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deals_sample) is not None
        ]
        assert "g8://companies/{company_id}/deals" in deals_matches, (
            f"{deals_sample} must still match the #42 deals template"
        )

        # Dispatch check #7: 2-seg /{company_id} URIs must match the
        # company-detail template and NOT any 3-seg template.
        company_sample = "g8://companies/abc123"
        company_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(company_sample) is not None
        ]
        assert "g8://companies/{company_id}" in company_matches, (
            f"{company_sample} must match the 2-seg {{company_id}} template"
        )
        assert html_uri not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #81 revenue template"
        )
        assert "g8://companies/industry/{industry}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #78 industry template"
        )
        assert "g8://companies/country/{country}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #79 country template"
        )
        assert "g8://companies/size/{tier}" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #80 size template"
        )
        assert "g8://companies/{company_id}/notes" not in company_matches, (
            f"{company_sample} must NOT match the 3-seg #37 notes template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://companies/revenue/enterprise.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the companies_revenue handler.
        html_name = templates[html_uri].name
        assert (
            "compan" in html_name.lower()
            and "revenue" in html_name.lower()
        ), f"expected companies_revenue handler name, got {html_name!r}"

    def test_deals_stage_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #82: stage-bucketed deals pane (3-seg template).

        Templated URIs (3 segments, stage bucket captured):
          - g8://deals/stage/{stage}      (HTML)
          - g8://deals/stage/{stage}.txt  (text)

        This is the FIRST axis-filter surface on the ``deals/`` entity and
        introduces the FIFTH distinct backend-filter pattern across all
        axis-filter surfaces:
          - #78 industry: ILIKE partial match on ``industry``
          - #79 country:  EXACT title-case match on ``country``
          - #80 size:     INT RANGE on ``employee_count``
          - #81 revenue:  USD RANGE on ``revenue``
          - #82 stage:    POST-FETCH CLIENT-SIDE BUCKETING (this)

        Unlike the other four, deal stage names are per-org custom strings
        with no canonical enum or backend filter param. Backend call is a
        plain ``GET /deals?limit=200`` and the renderer bucketizes deals
        into 6 canonical stages via ``_deals_stage_bucket_of()`` heuristic:
        won/lost short-circuit on ``stage_type``, otherwise keyword matching
        on ``stage_name`` (negotiation/proposal/qualification/prospecting).
        Invalid URI keys short-circuit the fetch → renderer emits the
        'unavailable' state (no backend call).

        **Five-directional dispatch safety** — FIVE sibling families now
        coexist under ``g8://deals/``:
          - 2-seg static   ``g8://deals/pipeline``                   (#11)
          - 2-seg template ``g8://deals/{deal_id}``                  (#24)
          - 2-seg static   ``g8://deals/dashboard``                  (#60)
          - 3-seg template ``g8://deals/{deal_id}/activities``       (#70)
          - 3-seg template ``g8://deals/stage/{stage}``              (#82 — this)

        Collision guard: FastMCP templates are literal-prefix dispatched,
        so ``g8://deals/stage/activities`` would technically match BOTH
        ``/stage/{stage}`` AND ``/{deal_id}/activities`` (treating "stage"
        as a valid ``deal_id``). The canonical set + aliases explicitly
        exclude the literals ``activities``, ``pipeline``, ``dashboard``,
        and ``stage`` itself (locked by ``test_forbidden_literals_excluded``
        in the unit renderer test file).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://deals/stage/{stage}"
        txt_uri = "g8://deals/stage/{stage}.txt"

        assert html_uri in templates, (
            "Deals stage HTML template must register"
        )
        assert txt_uri in templates, (
            "Deals stage text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All 4 prior sibling families under deals/ must remain intact.
        assert "g8://deals/pipeline" in resources  # #11
        assert "g8://deals/{deal_id}" in templates  # #24
        assert "g8://deals/dashboard" in resources  # #60
        assert "g8://deals/{deal_id}/activities" in templates  # #70

        # Prior axis-filter surfaces under companies/ must remain intact.
        assert "g8://companies/industry/{industry}" in templates  # #78
        assert "g8://companies/country/{country}" in templates  # #79
        assert "g8://companies/size/{tier}" in templates  # #80
        assert "g8://companies/revenue/{tier}" in templates  # #81
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /stage/<v> URIs must match the new
        # template and NOT match any sibling family. Because FastMCP
        # treats the stage segment as a valid ``{deal_id}`` value, the
        # 3-seg ``{deal_id}/activities`` family would also match if we
        # ever used the literal "activities" — hence the canonical set
        # + aliases exclude that string (and pipeline/dashboard/stage
        # too, to prevent collision with siblings #11/#60).
        stage_samples = [
            "g8://deals/stage/prospecting",
            "g8://deals/stage/qualification",
            "g8://deals/stage/proposal",
            "g8://deals/stage/negotiation",
            "g8://deals/stage/won",
            "g8://deals/stage/lost",
            "g8://deals/stage/discovery",      # alias → qualification
            "g8://deals/stage/demo",            # alias → qualification
            "g8://deals/stage/contract",        # alias → negotiation
            "g8://deals/stage/closed-won",      # alias → won
            "g8://deals/stage/closed-lost",     # alias → lost
            "g8://deals/stage/bogus",           # invalid — renderer handles
        ]
        for uri in stage_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {deal_id} MUST NOT match 3-seg URI.
            assert "g8://deals/{deal_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{deal_id}} template"
            )
            # The 3-seg nested sibling accepts ANY {deal_id} value, so
            # it would technically match if the URI's final segment were
            # "activities" — but our canonical+aliases exclude that,
            # so legitimate stage URIs cannot alias to that sibling.
            assert "g8://deals/{deal_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg /activities sibling"
            )

        # Dispatch check #2: 3-seg /<id>/activities URIs still match
        # ONLY the #70 sibling — NOT the new #82 stage template.
        activities_samples = [
            "g8://deals/42/activities",
            "g8://deals/acme-deal/activities",
        ]
        for uri in activities_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://deals/{deal_id}/activities" in matches, (
                f"{uri} should still match the #70 activities template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #82 stage template "
                f"(2nd segment is a deal_id, not 'stage')"
            )

        # Dispatch check #3: 2-seg /pipeline URI (#11) stays static —
        # not matched by any template.
        pipeline_uri = "g8://deals/pipeline"
        pipeline_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(pipeline_uri) is not None
        ]
        # The 2-seg {deal_id} template will match "pipeline" as a value
        # only if templates don't filter literal statics — that's fine,
        # because resources dict has higher dispatch priority. Assert
        # the static resource is present and the new template is NOT.
        assert html_uri not in pipeline_matches, (
            f"{pipeline_uri} must NOT match the #82 stage template"
        )

        # Dispatch check #4: 2-seg /dashboard URI (#60) — same as above.
        dashboard_uri = "g8://deals/dashboard"
        dashboard_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(dashboard_uri) is not None
        ]
        assert html_uri not in dashboard_matches, (
            f"{dashboard_uri} must NOT match the #82 stage template"
        )

        # Dispatch check #5: 2-seg /{deal_id} URIs must match the
        # deal-detail template and NOT any 3-seg template.
        deal_sample = "g8://deals/abc123"
        deal_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deal_sample) is not None
        ]
        assert "g8://deals/{deal_id}" in deal_matches, (
            f"{deal_sample} must match the 2-seg {{deal_id}} template"
        )
        assert html_uri not in deal_matches, (
            f"{deal_sample} must NOT match the 3-seg #82 stage template"
        )
        assert "g8://deals/{deal_id}/activities" not in deal_matches, (
            f"{deal_sample} must NOT match the 3-seg #70 activities template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://deals/stage/won.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the deals_stage handler.
        html_name = templates[html_uri].name
        assert (
            "deal" in html_name.lower()
            and "stage" in html_name.lower()
        ), f"expected deals_stage handler name, got {html_name!r}"

    def test_deals_owner_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #83: owner-scoped deals pane (3-seg template).

        Templated URIs (3 segments, owner user_id captured):
          - g8://deals/owner/{user_id}      (HTML)
          - g8://deals/owner/{user_id}.txt  (text)

        This is the **SECOND axis-filter** on the ``deals/`` entity (first
        was #82 stage) and introduces the **SIXTH distinct backend-filter
        pattern** across all MCP HTML app surfaces:
          - #78 industry: ILIKE partial match (canonical set)
          - #79 country:  EXACT title-case match (canonical set)
          - #80 size:     INT RANGE on employee_count (canonical tiers)
          - #81 revenue:  USD RANGE on revenue (canonical tiers)
          - #82 stage:    POST-FETCH CLIENT-SIDE BUCKETING (canonical + aliases)
          - #83 owner:    EXACT backend match on OPAQUE user_id (this)

        Normalization divergence from all prior axis-filters: user_ids are
        per-org opaque strings (UUIDs, emails, auth subs). There is NO
        canonical set, NO alias table, NO bucket heuristic. The renderer
        accepts any non-empty non-forbidden string and passes it through
        to ``GET /deals?owner_id=<user_id>&limit=200`` verbatim.

        **Six-directional dispatch safety** — SIX sibling families now
        coexist under ``g8://deals/``:
          - 2-seg static   ``g8://deals/pipeline``                   (#11)
          - 2-seg template ``g8://deals/{deal_id}``                  (#24)
          - 2-seg static   ``g8://deals/dashboard``                  (#60)
          - 3-seg template ``g8://deals/{deal_id}/activities``       (#70)
          - 3-seg template ``g8://deals/stage/{stage}``              (#82)
          - 3-seg template ``g8://deals/owner/{user_id}``            (#83 — this)

        Collision guard: FastMCP templates are literal-prefix dispatched,
        so URIs like ``g8://deals/owner/stage``, ``g8://deals/owner/pipeline``,
        ``g8://deals/owner/dashboard``, and ``g8://deals/owner/activities``
        would technically match BOTH ``/owner/{user_id}`` AND the sibling
        static/template families if we accepted those literals as valid
        user_ids. The ``_DEALS_OWNER_FORBIDDEN`` tuple explicitly rejects
        these 4 literals (locked by ``test_forbidden_literals_excluded``
        in the unit renderer test file).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://deals/owner/{user_id}"
        txt_uri = "g8://deals/owner/{user_id}.txt"

        assert html_uri in templates, (
            "Deals owner HTML template must register"
        )
        assert txt_uri in templates, (
            "Deals owner text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All 5 prior sibling families under deals/ must remain intact.
        assert "g8://deals/pipeline" in resources  # #11
        assert "g8://deals/{deal_id}" in templates  # #24
        assert "g8://deals/dashboard" in resources  # #60
        assert "g8://deals/{deal_id}/activities" in templates  # #70
        assert "g8://deals/stage/{stage}" in templates  # #82

        # Prior companies axis-filters remain intact.
        assert "g8://companies/industry/{industry}" in templates  # #78
        assert "g8://companies/country/{country}" in templates  # #79
        assert "g8://companies/size/{tier}" in templates  # #80
        assert "g8://companies/revenue/{tier}" in templates  # #81
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /owner/<v> URIs must match the new
        # template. Various opaque ID shapes (UUID, email, auth0, plain).
        owner_samples = [
            "g8://deals/owner/abc123",
            "g8://deals/owner/user_42",
            "g8://deals/owner/550e8400-e29b-41d4-a716-446655440000",  # UUID
            # NOTE: FastMCP template capture applies before normalization,
            # so emails with @/. are OK; email is tested via server match.
            "g8://deals/owner/alice%40example.com",  # URL-encoded email
            "g8://deals/owner/USR-42",
        ]
        for uri in owner_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {deal_id} MUST NOT match 3-seg URI.
            assert "g8://deals/{deal_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{deal_id}} template"
            )
            # The 3-seg nested sibling accepts ANY {deal_id}, so it
            # would technically match if the final segment were
            # "activities" — but the canonical normalization rejects
            # that literal up front, so a legitimate owner URI cannot
            # alias to it.
            assert "g8://deals/{deal_id}/activities" not in matches, (
                f"{uri} unexpectedly matched 3-seg /activities sibling"
            )
            # The #82 stage sibling must NOT match /owner/<v> URIs
            # (different 2nd-segment literals).
            assert "g8://deals/stage/{stage}" not in matches, (
                f"{uri} unexpectedly matched #82 stage sibling"
            )

        # Dispatch check #2: 3-seg /stage/<v> URIs still match ONLY #82 —
        # NOT the new #83 owner template.
        stage_samples = [
            "g8://deals/stage/prospecting",
            "g8://deals/stage/negotiation",
            "g8://deals/stage/won",
        ]
        for uri in stage_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://deals/stage/{stage}" in matches, (
                f"{uri} should still match the #82 stage template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #83 owner template "
                f"(2nd segment is 'stage', not 'owner')"
            )

        # Dispatch check #3: 3-seg /<id>/activities URIs still match
        # ONLY the #70 sibling — NOT the new #83 owner template.
        activities_samples = [
            "g8://deals/42/activities",
            "g8://deals/acme-deal/activities",
        ]
        for uri in activities_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://deals/{deal_id}/activities" in matches, (
                f"{uri} should still match the #70 activities template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #83 owner template "
                f"(2nd segment is a deal_id, not 'owner')"
            )

        # Dispatch check #4: 2-seg /pipeline URI (#11) — new template
        # must not match it.
        pipeline_uri = "g8://deals/pipeline"
        pipeline_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(pipeline_uri) is not None
        ]
        assert html_uri not in pipeline_matches, (
            f"{pipeline_uri} must NOT match the #83 owner template"
        )

        # Dispatch check #5: 2-seg /dashboard URI (#60) — same guard.
        dashboard_uri = "g8://deals/dashboard"
        dashboard_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(dashboard_uri) is not None
        ]
        assert html_uri not in dashboard_matches, (
            f"{dashboard_uri} must NOT match the #83 owner template"
        )

        # Dispatch check #6: 2-seg /{deal_id} URIs still match ONLY
        # the #24 deal-detail template.
        deal_sample = "g8://deals/abc123"
        deal_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(deal_sample) is not None
        ]
        assert "g8://deals/{deal_id}" in deal_matches, (
            f"{deal_sample} must match the 2-seg {{deal_id}} template"
        )
        assert html_uri not in deal_matches, (
            f"{deal_sample} must NOT match the 3-seg #83 owner template"
        )
        assert "g8://deals/stage/{stage}" not in deal_matches, (
            f"{deal_sample} must NOT match the 3-seg #82 stage template"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://deals/owner/u_abc.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the deals_owner handler.
        html_name = templates[html_uri].name
        assert (
            "deal" in html_name.lower()
            and "owner" in html_name.lower()
        ), f"expected deals_owner handler name, got {html_name!r}"

    def test_contacts_engagement_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #84: engagement-scoped contacts pane (3-seg template).

        Templated URIs (3 segments, engagement level captured):
          - g8://contacts/engagement/{level}      (HTML)
          - g8://contacts/engagement/{level}.txt  (text)

        **Third axis-filter** on the ``contacts/`` entity (prior: #76
        seniority, #77 department). Reuses the **POST-FETCH CLIENT-SIDE
        BUCKETING pattern** from #82 stage, but with a recency/score
        heuristic rather than stage-name keyword matching.

        Level normalization:
          - 5 canonical levels: hot / warm / cool / cold / dormant
          - ~50 aliases including tier ranking (a/b/c/d/e/f-tier) and
            intent words (active, engaged, high, low, inactive, etc.)
          - Score-tier preferred: ≥80/60/40/20 boundaries
          - Days-since-touch fallback: ≤7/30/90/180 bands

        **Nine-directional dispatch safety** — NINE sibling families now
        coexist under ``g8://contacts/``:
          - 2-seg template ``g8://contacts/{contact_id}``                (#27)
          - 2-seg static   ``g8://contacts/dashboard``                   (#57)
          - 3-seg template ``g8://contacts/{contact_id}/notes``          (#33)
          - 3-seg template ``g8://contacts/{contact_id}/tasks``          (#34)
          - 3-seg template ``g8://contacts/{contact_id}/deals``          (#43)
          - 3-seg template ``g8://contacts/{contact_id}/activities``     (#52)
          - 3-seg template ``g8://contacts/seniority/{seniority}``       (#76)
          - 3-seg template ``g8://contacts/department/{department}``     (#77)
          - 3-seg template ``g8://contacts/engagement/{level}``          (#84 — this)

        Collision guard: FastMCP templates are literal-prefix dispatched,
        so URIs like ``g8://contacts/engagement/notes`` would technically
        match BOTH ``/engagement/{level}`` AND the sibling
        ``/{contact_id}/notes`` family (if we accepted "notes" as a
        valid level). The ``_CONTACTS_ENGAGEMENT_FORBIDDEN`` tuple
        explicitly rejects 8 literals: ``dashboard``, ``notes``,
        ``tasks``, ``deals``, ``activities``, ``seniority``,
        ``department``, ``engagement`` (self) — highest forbidden-count
        of any axis-filter shipped so far, due to 6 nested siblings +
        2 axis siblings.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://contacts/engagement/{level}"
        txt_uri = "g8://contacts/engagement/{level}.txt"

        assert html_uri in templates, (
            "Contacts engagement HTML template must register"
        )
        assert txt_uri in templates, (
            "Contacts engagement text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All 8 prior sibling families under contacts/ must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #27
        assert "g8://contacts/dashboard" in resources  # #57
        assert "g8://contacts/{contact_id}/notes" in templates  # #33
        assert "g8://contacts/{contact_id}/tasks" in templates  # #34
        assert "g8://contacts/{contact_id}/deals" in templates  # #43
        assert "g8://contacts/{contact_id}/activities" in templates  # #52
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://contacts/department/{department}" in templates  # #77

        # Prior deals axis-filters remain intact.
        assert "g8://deals/stage/{stage}" in templates  # #82
        assert "g8://deals/owner/{user_id}" in templates  # #83
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /engagement/<v> URIs must match the
        # new template (canonical + alias shapes).
        engagement_samples = [
            "g8://contacts/engagement/hot",
            "g8://contacts/engagement/warm",
            "g8://contacts/engagement/cool",
            "g8://contacts/engagement/cold",
            "g8://contacts/engagement/dormant",
            "g8://contacts/engagement/active",   # alias → hot
            "g8://contacts/engagement/a-tier",   # alias → hot
            "g8://contacts/engagement/inactive", # alias → dormant
        ]
        for uri in engagement_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {contact_id} MUST NOT match 3-seg URI.
            assert "g8://contacts/{contact_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{contact_id}} template"
            )
            # Nested 3-seg siblings accept any contact_id for their 2nd
            # segment, so they could match /engagement/<v> if the final
            # segment were "notes"/"tasks"/"deals"/"activities" — the
            # forbidden-literals guard rejects those up front.
            for nested in (
                "g8://contacts/{contact_id}/notes",
                "g8://contacts/{contact_id}/tasks",
                "g8://contacts/{contact_id}/deals",
                "g8://contacts/{contact_id}/activities",
            ):
                # These WILL match because FastMCP pattern-matches on
                # structure. They resolve to a different handler only
                # when the 2nd seg equals "engagement" (literal) rather
                # than a captured {contact_id}. That's why we also
                # assert html_uri is in matches — FastMCP returns the
                # first template match, and registration order puts
                # the axis-filter first for literal /engagement/.
                pass
            # The #76 seniority sibling must NOT match /engagement/<v>
            # (different 2nd-segment literals).
            assert "g8://contacts/seniority/{seniority}" not in matches, (
                f"{uri} unexpectedly matched #76 seniority sibling"
            )
            assert "g8://contacts/department/{department}" not in matches, (
                f"{uri} unexpectedly matched #77 department sibling"
            )

        # Dispatch check #2: 3-seg /seniority/<v> URIs still match ONLY
        # #76 — NOT the new #84 engagement template.
        seniority_samples = [
            "g8://contacts/seniority/c-level",
            "g8://contacts/seniority/vp",
        ]
        for uri in seniority_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/seniority/{seniority}" in matches, (
                f"{uri} should still match the #76 seniority template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #84 engagement template "
                f"(2nd segment is 'seniority', not 'engagement')"
            )

        # Dispatch check #3: 3-seg /department/<v> URIs still match ONLY
        # #77 — NOT the new #84 engagement template.
        dept_samples = [
            "g8://contacts/department/engineering",
            "g8://contacts/department/sales",
        ]
        for uri in dept_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/department/{department}" in matches, (
                f"{uri} should still match the #77 department template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #84 engagement template "
                f"(2nd segment is 'department', not 'engagement')"
            )

        # Dispatch check #4: 2-seg /dashboard URI (#57) — new template
        # must not match it.
        dashboard_uri = "g8://contacts/dashboard"
        dashboard_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(dashboard_uri) is not None
        ]
        assert html_uri not in dashboard_matches, (
            f"{dashboard_uri} must NOT match the #84 engagement template"
        )

        # Dispatch check #5: 2-seg /{contact_id} URIs still match ONLY
        # the #27 contact-detail template.
        contact_sample = "g8://contacts/abc123"
        contact_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(contact_sample) is not None
        ]
        assert "g8://contacts/{contact_id}" in contact_matches, (
            f"{contact_sample} must match the 2-seg {{contact_id}} template"
        )
        assert html_uri not in contact_matches, (
            f"{contact_sample} must NOT match the 3-seg #84 engagement template"
        )

        # Dispatch check #6: 3-seg /<id>/notes URIs still match the #33
        # nested sibling — NOT the new #84 engagement template.
        notes_sample = "g8://contacts/xyz/notes"
        notes_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(notes_sample) is not None
        ]
        assert "g8://contacts/{contact_id}/notes" in notes_matches, (
            f"{notes_sample} must match the #33 notes sibling"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://contacts/engagement/hot.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the contacts_engagement handler.
        html_name = templates[html_uri].name
        assert (
            "contact" in html_name.lower()
            and "engagement" in html_name.lower()
        ), f"expected contacts_engagement handler name, got {html_name!r}"

    def test_activities_today_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #86: today's activities (2-seg static, temporal).

        Static URIs (2 segments, NO template capture — "today" is a fixed
        server-side scope, not a user-supplied value):
          - g8://activities/today      (HTML)
          - g8://activities/today.txt  (text)

        **First purely-TEMPORAL axis-filter** in Upgrade 4. Introduces
        the **EIGHTH distinct backend-filter pattern**: TEMPORAL
        DATE-RANGE FILTER via ``?since={today_00_utc_iso}``. Client-side
        safety filter on top of backend ``?since=`` prevents stale /
        unfiltered responses from leaking into the today-only pane.

        Sibling family coexistence under ``g8://activities/``:
          - 2-seg static ``g8://activities/feed``   (#11, recent)
          - 2-seg static ``g8://activities/today``  (#86 — this)

        Dispatch safety: both are STATIC resources (literal URIs, no
        template). FastMCP routes them via the ``_resources`` dict
        rather than ``_templates``, so there is no capture conflict.
        The integration test locks that both static URIs remain
        registered and that the new one resolves to the
        ``activities_today_*`` handler name.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://activities/today"
        txt_uri = "g8://activities/today.txt"

        # Both live in the STATIC _resources dict, not _templates.
        assert html_uri in resources, (
            "Activities today HTML resource must register as static"
        )
        assert txt_uri in resources, (
            "Activities today text resource must register as static"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Must NOT accidentally land in templates.
        assert html_uri not in templates
        assert txt_uri not in templates

        # Prior sibling under activities/ must remain intact.
        assert "g8://activities/feed" in resources, (
            "#11 activities/feed sibling must stay registered"
        )
        assert "g8://activities/feed.txt" in resources

        # Cross-entity drill-up destinations must remain intact.
        assert "g8://tasks/dashboard" in resources  # #15 (or equivalent static)
        assert "g8://copilot/home" in resources  # #66

        # And key axis-filter siblings from recent surfaces still exist.
        assert "g8://contacts/source/{channel}" in templates  # #85
        assert "g8://contacts/engagement/{level}" in templates  # #84
        assert "g8://deals/owner/{user_id}" in templates  # #83
        assert "g8://deals/stage/{stage}" in templates  # #82

        # Resource name must point at the activities_today handler.
        html_name = resources[html_uri].name
        assert (
            "activit" in html_name.lower()
            and "today" in html_name.lower()
        ), f"expected activities_today handler name, got {html_name!r}"

        # The .txt URI must have its own handler name.
        txt_name = resources[txt_uri].name
        assert (
            "activit" in txt_name.lower()
            and "today" in txt_name.lower()
            and "text" in txt_name.lower()
        ), f"expected activities_today text handler, got {txt_name!r}"

    def test_tasks_due_today_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #87: due-today scoped tasks (2-seg static, temporal).

        Static URIs (2 segments, NO template capture — "due-today" is a
        fixed server-side scope, not a user-supplied value):
          - g8://tasks/due-today      (HTML)
          - g8://tasks/due-today.txt  (text)

        **Second purely-TEMPORAL axis-filter** in Upgrade 4 (first was
        #86 activities/today). Extends the **EIGHTH backend-filter
        pattern** (TEMPORAL DATE-RANGE FILTER) with a semantic twist:
        backend filter is ``?due_before={tomorrow_00_utc}`` rather than
        ``?since={today_00_utc}`` — this catches OVERDUE tasks (due
        before today) together with tasks due today, then the renderer
        also admits tasks completed today via ``completed_at`` scan.

        Client-side three-band partition:
          - overdue          (due_date < today, not done)
          - due_today        (due_date == today, not done)
          - completed_today  (done AND completed_at date == today)
        All other tasks are filtered out.

        **Five-family coexistence** under ``g8://tasks/`` — distinct
        sibling families now share this prefix:
          - 2-seg static   ``g8://tasks/dashboard``          (#12)
          - 2-seg template ``g8://tasks/{task_id}``          (#67)
          - 3-seg template ``g8://tasks/status/{status}``    (#74)
          - 3-seg template ``g8://tasks/priority/{priority}`` (#75)
          - 2-seg static   ``g8://tasks/due-today``          (#87 — this)

        Dispatch safety: #87 is a STATIC resource (literal URI, no
        template). FastMCP routes it via the ``_resources`` dict rather
        than ``_templates``, so the literal ``due-today`` path segment
        cannot collide with the ``{task_id}`` template capture (static
        resources take precedence on exact match).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://tasks/due-today"
        txt_uri = "g8://tasks/due-today.txt"

        # Both live in the STATIC _resources dict, not _templates.
        assert html_uri in resources, (
            "Tasks due-today HTML resource must register as static"
        )
        assert txt_uri in resources, (
            "Tasks due-today text resource must register as static"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Must NOT accidentally land in templates.
        assert html_uri not in templates
        assert txt_uri not in templates

        # All 4 prior sibling families under tasks/ must remain intact.
        assert "g8://tasks/dashboard" in resources  # #12
        assert "g8://tasks/{task_id}" in templates  # #67
        assert "g8://tasks/status/{status}" in templates  # #74
        assert "g8://tasks/priority/{priority}" in templates  # #75

        # Cross-entity drill-up destinations must remain intact.
        assert "g8://activities/today" in resources  # #86
        assert "g8://copilot/home" in resources  # #66

        # And key axis-filter siblings from recent surfaces still exist.
        assert "g8://contacts/source/{channel}" in templates  # #85
        assert "g8://contacts/engagement/{level}" in templates  # #84
        assert "g8://deals/owner/{user_id}" in templates  # #83
        assert "g8://deals/stage/{stage}" in templates  # #82

        # Dispatch check: 2-seg /tasks/due-today URI must resolve to the
        # STATIC resource, NOT to the {task_id} template. FastMCP
        # prefers exact-match static resources over templates; this
        # assertion locks that invariant.
        assert resources[html_uri].name.lower().startswith("tasks_due_today"), (
            f"expected tasks_due_today handler name, got "
            f"{resources[html_uri].name!r}"
        )

        # The .txt URI must have its own handler name.
        txt_name = resources[txt_uri].name
        assert (
            "tasks" in txt_name.lower()
            and "due" in txt_name.lower()
            and "today" in txt_name.lower()
            and "text" in txt_name.lower()
        ), f"expected tasks_due_today text handler, got {txt_name!r}"

        # Lock: the {task_id} template still matches normal id values
        # (not hijacked by adding the static "due-today" sibling).
        taskid_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches("g8://tasks/abc123") is not None
        ]
        assert "g8://tasks/{task_id}" in taskid_matches, (
            "{task_id} template must still match regular id values"
        )

    def test_deals_this_week_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #88: this-week scoped deals (2-seg static, temporal range).

        Static URIs (2 segments, NO template capture — "this-week" is a
        fixed server-side scope, not a user-supplied value):
          - g8://deals/this-week      (HTML)
          - g8://deals/this-week.txt  (text)

        **Third purely-TEMPORAL axis-filter** in Upgrade 4 (after #86
        activities/today and #87 tasks/due-today). Introduces the
        **NINTH distinct backend-filter pattern**: DUAL-BOUND TEMPORAL
        RANGE — backend is called with BOTH ``?close_after=...`` AND
        ``?close_before=...`` to scope to the current ISO week (Monday
        00:00 UTC inclusive through next Monday 00:00 UTC exclusive).
        This differs from #86/#87 which use a SINGLE temporal bound.

        Client-side three-band partition on close_date + stage:
          - closing_this_week    (close_date in week, stage OPEN)
          - closed_won_this_week (stage keyword match "won")
          - closed_lost_this_week (stage keyword match "lost")
        Deals not in the week window are filtered out.

        **Seven-family coexistence** under ``g8://deals/`` — distinct
        sibling families now share this prefix:
          - 2-seg static   ``g8://deals/pipeline``            (#13)
          - 2-seg static   ``g8://deals/dashboard``           (#12)
          - 2-seg template ``g8://deals/{deal_id}``           (#66)
          - 3-seg template ``g8://deals/{deal_id}/activities`` (#69)
          - 3-seg template ``g8://deals/stage/{stage}``       (#82)
          - 3-seg template ``g8://deals/owner/{user_id}``     (#83)
          - 2-seg static   ``g8://deals/this-week``           (#88 — this)

        Dispatch safety: #88 is a STATIC resource (literal URI, no
        template). FastMCP routes it via ``_resources`` rather than
        ``_templates``, so the literal ``this-week`` path segment
        cannot collide with the ``{deal_id}`` template capture.

        Also first-use of ``_G8_DESTRUCTIVE_BG`` / ``_G8_DESTRUCTIVE_FG``
        design tokens for the closed-lost band palette — a new visual
        signature distinct from all prior Upgrade 4 surfaces.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://deals/this-week"
        txt_uri = "g8://deals/this-week.txt"

        # Both live in the STATIC _resources dict, not _templates.
        assert html_uri in resources, (
            "Deals this-week HTML resource must register as static"
        )
        assert txt_uri in resources, (
            "Deals this-week text resource must register as static"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Must NOT accidentally land in templates.
        assert html_uri not in templates
        assert txt_uri not in templates

        # All 6 prior sibling families under deals/ must remain intact.
        assert "g8://deals/pipeline" in resources  # #13
        assert "g8://deals/dashboard" in resources  # #12
        assert "g8://deals/{deal_id}" in templates  # #66
        assert "g8://deals/{deal_id}/activities" in templates  # #69
        assert "g8://deals/stage/{stage}" in templates  # #82
        assert "g8://deals/owner/{user_id}" in templates  # #83

        # Cross-entity drill-up destinations must remain intact.
        assert "g8://activities/today" in resources  # #86
        assert "g8://tasks/due-today" in resources  # #87
        assert "g8://copilot/home" in resources  # #66

        # And key axis-filter siblings from recent surfaces still exist.
        assert "g8://contacts/source/{channel}" in templates  # #85
        assert "g8://contacts/engagement/{level}" in templates  # #84

        # Dispatch check: 2-seg /deals/this-week URI must resolve to the
        # STATIC resource, NOT to the {deal_id} template. FastMCP prefers
        # exact-match static resources over templates; this assertion
        # locks that invariant.
        assert resources[html_uri].name.lower().startswith("deals_this_week"), (
            f"expected deals_this_week handler name, got "
            f"{resources[html_uri].name!r}"
        )

        # The .txt URI must have its own handler name.
        txt_name = resources[txt_uri].name
        assert (
            "deals" in txt_name.lower()
            and "this" in txt_name.lower()
            and "week" in txt_name.lower()
            and "text" in txt_name.lower()
        ), f"expected deals_this_week text handler, got {txt_name!r}"

        # Lock: the {deal_id} template still matches normal id values
        # (not hijacked by adding the static "this-week" sibling).
        dealid_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches("g8://deals/deal_abc123") is not None
        ]
        assert "g8://deals/{deal_id}" in dealid_matches, (
            "{deal_id} template must still match regular id values"
        )

    def test_account_detail_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #89: account detail (2-seg templated, revenue lens).

        Templated URIs (2 segments, account_id captured):
          - g8://accounts/{account_id}      (HTML)
          - g8://accounts/{account_id}.txt  (text)

        **First MCP app surface for the `accounts` entity prefix** —
        no prior sibling families exist under `g8://accounts/`. This
        establishes the accounts prefix independently of the long-
        established `companies` prefix (#38 / #75 / #76 / #77 / #78 /
        #79 / #80 / #81), giving operators a CRM-vs-revenue dual lens
        on the same underlying MashupCompany record.

        Re-frames the company record as a REVENUE ACCOUNT:
          - Stats emphasize $ (Total account value / Won $ / Open
            pipeline / Health score 0-100)
          - Deals partitioned into won / open / lost (client-side)
          - Contacts rendered as a compact rollup (count + top-5)
          - Health score blends deals + contacts into a capped
            0-100 aggregate with band palette (high=green /
            medium=amber / low=purple)

        Backend access pattern (distinct from all prior surfaces):
        **THREE parallel GETs** against `/companies/{id}`,
        `/companies/{id}/deals`, `/companies/{id}/contacts`. #89 does
        not introduce a new backend ENDPOINT family — it introduces a
        new backend ACCESS pattern (parallel multi-source aggregation)
        layered into a new entity prefix.

        Dispatch check: #89 is a TEMPLATED resource. FastMCP routes it
        via `_templates`. No sibling static or template under
        `g8://accounts/` existed before, so no dispatch collision
        possible. The {account_id} capture must match arbitrary id
        values (including numeric ids).
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://accounts/{account_id}"
        txt_uri = "g8://accounts/{account_id}.txt"

        # Both must register as TEMPLATES (not static resources).
        assert html_uri in templates, (
            "Account detail HTML must register as a URI template"
        )
        assert txt_uri in templates, (
            "Account detail text must register as a URI template"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT accidentally land in statics.
        assert html_uri not in resources
        assert txt_uri not in resources

        # Handler names distinct + recognizable.
        assert templates[html_uri].name.lower().startswith("account_detail"), (
            f"expected account_detail handler, got {templates[html_uri].name!r}"
        )
        txt_name = templates[txt_uri].name
        assert "account" in txt_name.lower() and "text" in txt_name.lower(), (
            f"expected account_detail text handler, got {txt_name!r}"
        )

        # Cross-entity drill-up destinations must remain intact.
        assert "g8://companies/{company_id}" in templates  # #38 — CRM lens
        assert "g8://deals/this-week" in resources  # #88
        assert "g8://deals/pipeline" in resources  # #13
        assert "g8://activities/today" in resources  # #86
        assert "g8://tasks/due-today" in resources  # #87
        assert "g8://copilot/home" in resources  # #66

        # {account_id} template must match arbitrary id values.
        account_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches("g8://accounts/acc_xyz123") is not None
        ]
        assert "g8://accounts/{account_id}" in account_matches, (
            "{account_id} template must match regular id values"
        )

        # And numeric ids should also match (CRM systems often use ints).
        numeric_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches("g8://accounts/42") is not None
        ]
        assert "g8://accounts/{account_id}" in numeric_matches, (
            "{account_id} template must match numeric ids"
        )

    def test_system_credit_usage_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #90 (CAPSTONE): system/credit-usage.

        Static URIs (2 segments, NO template capture):
          - g8://system/credit-usage      (HTML)
          - g8://system/credit-usage.txt  (text)

        **First MCP app surface under the `system/` entity prefix** —
        establishes a SIXTH top-level entity prefix alongside
        companies / contacts / deals / tasks / activities / accounts.

        **CAPSTONE surface for Upgrade 4** (hard cap at #90 per
        Thomas). Introduces the **ELEVENTH distinct backend access
        pattern**: STATIC-KNOWLEDGE SURFACE — renderer serves
        documented reference content from Python constants with NO
        backend fetch. Distinct from the 10 prior backend-fetching
        patterns in Upgrade 4:
          1.  ILIKE partial match (#78 industry)
          2.  EXACT title-case match (#79 country)
          3.  INT RANGE (#80 size)
          4.  USD RANGE (#81 revenue)
          5.  POST-FETCH client-side bucketing (#82 stage, #84 engagement)
          6.  EXACT opaque-id backend match (#83 owner)
          7.  EXACT + fallback-to-other hybrid (#85 source)
          8.  SINGLE-BOUND TEMPORAL past (#86 activities/today)
          9.  SINGLE-BOUND TEMPORAL future (#87 tasks/due-today)
          10. DUAL-BOUND TEMPORAL RANGE (#88 deals/this-week)
          11. PARALLEL MULTI-SOURCE AGGREGATION (#89 accounts)
          12. STATIC-KNOWLEDGE (this surface — #90)

        The surface is deliberately HONEST about a data gap: live
        balance + per-service usage history are NOT yet exposed via
        the public developer API. Operators check live balance via
        Studio billing. The status card uses warning-amber to flag
        this gap rather than hiding it.

        Dispatch safety: #90 is a STATIC resource (literal URI, no
        template). FastMCP routes statics via `_resources` before
        `_templates`. No prior sibling under `g8://system/` exists,
        so there is no dispatch collision possible.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://system/credit-usage"
        txt_uri = "g8://system/credit-usage.txt"

        # Both live in the STATIC _resources dict, not _templates.
        assert html_uri in resources, (
            "System credit-usage HTML must register as static"
        )
        assert txt_uri in resources, (
            "System credit-usage text must register as static"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Must NOT accidentally land in templates.
        assert html_uri not in templates
        assert txt_uri not in templates

        # Handler names recognizable.
        assert resources[html_uri].name.lower().startswith("system_credit"), (
            f"expected system_credit handler, got {resources[html_uri].name!r}"
        )
        txt_name = resources[txt_uri].name
        assert "credit" in txt_name.lower() and "text" in txt_name.lower(), (
            f"expected system_credit text handler, got {txt_name!r}"
        )

        # Cross-entity drill-up destinations must remain intact.
        assert "g8://copilot/home" in resources  # #66
        assert "g8://deals/this-week" in resources  # #88
        assert "g8://deals/pipeline" in resources  # #13
        assert "g8://activities/today" in resources  # #86
        assert "g8://tasks/due-today" in resources  # #87

        # All prior Upgrade 4 surfaces in the current branch line must
        # remain intact (sanity regression for the capstone merge).
        assert "g8://accounts/{account_id}" in templates  # #89
        assert "g8://contacts/source/{channel}" in templates  # #85
        assert "g8://contacts/engagement/{level}" in templates  # #84
        assert "g8://deals/owner/{user_id}" in templates  # #83
        assert "g8://deals/stage/{stage}" in templates  # #82
        assert "g8://companies/size/{tier}" in templates  # #80
        assert "g8://companies/revenue/{tier}" in templates  # #81

    def test_contacts_source_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #85: source-scoped contacts pane (3-seg template).

        Templated URIs (3 segments, source channel captured):
          - g8://contacts/source/{channel}      (HTML)
          - g8://contacts/source/{channel}.txt  (text)

        **Fourth axis-filter** on the ``contacts/`` entity (prior: #76
        seniority, #77 department, #84 engagement). Introduces the
        **SEVENTH distinct backend-filter pattern**: EXACT backend match
        on canonical channel, HYBRID of #78 industry (canonical set +
        ILIKE) and #82 stage (keyword-driven bucketing). Source is sent
        to backend as ``?source={normalized}`` — but unknown values are
        re-bucketed to "other" rather than dropped, so the renderer is
        forgiving of non-canonical source strings in the response.

        Channel normalization:
          - 12 canonical channels: referral / partner / inbound / webinar
            / content / outbound / paid / cold / event / social / other
            / unknown
          - ~80 aliases (including vendors: linkedin, google, facebook;
            semantic: word-of-mouth → referral, sdr → outbound)
          - Pass-through for canonical + case/underscore/hyphen fuzzy

        **Ten-directional dispatch safety** — TEN sibling families now
        coexist under ``g8://contacts/``:
          - 2-seg template ``g8://contacts/{contact_id}``                (#27)
          - 2-seg static   ``g8://contacts/dashboard``                   (#57)
          - 3-seg template ``g8://contacts/{contact_id}/notes``          (#33)
          - 3-seg template ``g8://contacts/{contact_id}/tasks``          (#34)
          - 3-seg template ``g8://contacts/{contact_id}/deals``          (#43)
          - 3-seg template ``g8://contacts/{contact_id}/activities``     (#52)
          - 3-seg template ``g8://contacts/seniority/{seniority}``       (#76)
          - 3-seg template ``g8://contacts/department/{department}``     (#77)
          - 3-seg template ``g8://contacts/engagement/{level}``          (#84)
          - 3-seg template ``g8://contacts/source/{channel}``            (#85 — this)

        Collision guard: ``_CONTACTS_SOURCE_FORBIDDEN`` rejects 9 literals
        (``dashboard``, ``notes``, ``tasks``, ``deals``, ``activities``,
        ``seniority``, ``department``, ``engagement``, ``source`` self) —
        highest forbidden-count of any axis-filter shipped so far.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://contacts/source/{channel}"
        txt_uri = "g8://contacts/source/{channel}.txt"

        assert html_uri in templates, (
            "Contacts source HTML template must register"
        )
        assert txt_uri in templates, (
            "Contacts source text template must register"
        )
        assert templates[html_uri].mime_type == "text/html"
        assert templates[txt_uri].mime_type == "text/plain"

        # Must NOT land in the static _resources dict — they are templates.
        assert html_uri not in resources
        assert txt_uri not in resources

        # All 9 prior sibling families under contacts/ must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #27
        assert "g8://contacts/dashboard" in resources  # #57
        assert "g8://contacts/{contact_id}/notes" in templates  # #33
        assert "g8://contacts/{contact_id}/tasks" in templates  # #34
        assert "g8://contacts/{contact_id}/deals" in templates  # #43
        assert "g8://contacts/{contact_id}/activities" in templates  # #52
        assert "g8://contacts/seniority/{seniority}" in templates  # #76
        assert "g8://contacts/department/{department}" in templates  # #77
        assert "g8://contacts/engagement/{level}" in templates  # #84

        # Prior deals axis-filters remain intact.
        assert "g8://deals/stage/{stage}" in templates  # #82
        assert "g8://deals/owner/{user_id}" in templates  # #83
        assert "g8://copilot/home" in resources  # #66

        # Dispatch check #1: 3-seg /source/<v> URIs must match the new
        # template (canonical + alias shapes).
        source_samples = [
            "g8://contacts/source/referral",
            "g8://contacts/source/partner",
            "g8://contacts/source/inbound",
            "g8://contacts/source/webinar",
            "g8://contacts/source/content",
            "g8://contacts/source/outbound",
            "g8://contacts/source/paid",
            "g8://contacts/source/cold",
            "g8://contacts/source/event",
            "g8://contacts/source/social",
            "g8://contacts/source/other",
            "g8://contacts/source/unknown",
            "g8://contacts/source/linkedin",      # alias → social
            "g8://contacts/source/word-of-mouth", # alias → referral
            "g8://contacts/source/sdr",           # alias → outbound
        ]
        for uri in source_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert html_uri in matches, (
                f"{uri} should match {html_uri}; got {matches}"
            )
            # Critical: 2-seg {contact_id} MUST NOT match 3-seg URI.
            assert "g8://contacts/{contact_id}" not in matches, (
                f"{uri} unexpectedly matched 2-seg {{contact_id}} template"
            )
            # Other axis-filter siblings MUST NOT match /source/<v>.
            assert "g8://contacts/seniority/{seniority}" not in matches, (
                f"{uri} unexpectedly matched #76 seniority sibling"
            )
            assert "g8://contacts/department/{department}" not in matches, (
                f"{uri} unexpectedly matched #77 department sibling"
            )
            assert "g8://contacts/engagement/{level}" not in matches, (
                f"{uri} unexpectedly matched #84 engagement sibling"
            )

        # Dispatch check #2: 3-seg /seniority/<v> URIs still match ONLY
        # #76 — NOT the new #85 source template.
        seniority_samples = [
            "g8://contacts/seniority/c-level",
            "g8://contacts/seniority/vp",
        ]
        for uri in seniority_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/seniority/{seniority}" in matches, (
                f"{uri} should still match the #76 seniority template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #85 source template "
                f"(2nd segment is 'seniority', not 'source')"
            )

        # Dispatch check #3: 3-seg /department/<v> URIs still match ONLY
        # #77 — NOT the new #85 source template.
        dept_samples = [
            "g8://contacts/department/engineering",
            "g8://contacts/department/sales",
        ]
        for uri in dept_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/department/{department}" in matches, (
                f"{uri} should still match the #77 department template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #85 source template "
                f"(2nd segment is 'department', not 'source')"
            )

        # Dispatch check #4: 3-seg /engagement/<v> URIs still match ONLY
        # #84 — NOT the new #85 source template.
        engagement_samples = [
            "g8://contacts/engagement/hot",
            "g8://contacts/engagement/warm",
        ]
        for uri in engagement_samples:
            matches = [
                tpl_uri for tpl_uri, tpl in templates.items()
                if tpl.matches(uri) is not None
            ]
            assert "g8://contacts/engagement/{level}" in matches, (
                f"{uri} should still match the #84 engagement template"
            )
            assert html_uri not in matches, (
                f"{uri} must NOT match the #85 source template "
                f"(2nd segment is 'engagement', not 'source')"
            )

        # Dispatch check #5: 2-seg /dashboard URI (#57) — new template
        # must not match it.
        dashboard_uri = "g8://contacts/dashboard"
        dashboard_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(dashboard_uri) is not None
        ]
        assert html_uri not in dashboard_matches, (
            f"{dashboard_uri} must NOT match the #85 source template"
        )

        # Dispatch check #6: 2-seg /{contact_id} URIs still match ONLY
        # the #27 contact-detail template.
        contact_sample = "g8://contacts/abc123"
        contact_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(contact_sample) is not None
        ]
        assert "g8://contacts/{contact_id}" in contact_matches, (
            f"{contact_sample} must match the 2-seg {{contact_id}} template"
        )
        assert html_uri not in contact_matches, (
            f"{contact_sample} must NOT match the 3-seg #85 source template"
        )

        # Dispatch check #7: 3-seg /<id>/notes URIs still match the #33
        # nested sibling — NOT the new #85 source template.
        notes_sample = "g8://contacts/xyz/notes"
        notes_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(notes_sample) is not None
        ]
        assert "g8://contacts/{contact_id}/notes" in notes_matches, (
            f"{notes_sample} must match the #33 notes sibling"
        )

        # The .txt URI must be matched by the .txt template.
        txt_sample = "g8://contacts/source/referral.txt"
        txt_matches = [
            tpl_uri for tpl_uri, tpl in templates.items()
            if tpl.matches(txt_sample) is not None
        ]
        assert txt_uri in txt_matches, (
            f"{txt_sample} must be matched by {txt_uri} template"
        )

        # Resource template name must point at the contacts_source handler.
        html_name = templates[html_uri].name
        assert (
            "contact" in html_name.lower()
            and "source" in html_name.lower()
        ), f"expected contacts_source handler name, got {html_name!r}"

    def test_copilot_home_app_surface_registered(self, monkeypatch):
        """Upgrade 4 surface #66: copilot home hub (2-seg static).

        Static URIs (2 segments, no template capture):
          - g8://copilot/home      (HTML)
          - g8://copilot/home.txt  (text)

        Dispatch safety:
          - Both URIs live in the static ``_resources`` dict (exact
            literal match), not ``_templates``.
          - FastMCP ResourceManager checks ``_resources`` before
            ``_templates`` for exact literal URIs — no collision risk
            with any sibling 2- or 3-seg template.
          - Sibling 2-seg statics (#3/#13/#5/#15 dashboards + library)
            and sibling templates (#58/#59/#62/#63/#64/#65) must remain
            intact — different URI prefix, no mutation.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()

        templates = server._resource_manager._templates
        resources = server._resource_manager._resources

        html_uri = "g8://copilot/home"
        txt_uri = "g8://copilot/home.txt"

        assert html_uri in resources, (
            "Copilot home HTML surface must register as a static"
        )
        assert txt_uri in resources, (
            "Copilot home text surface must register as a static"
        )
        assert resources[html_uri].mime_type == "text/html"
        assert resources[txt_uri].mime_type == "text/plain"

        # Must NOT land in _templates — they are statics, not templates.
        assert html_uri not in templates
        assert txt_uri not in templates

        # Sibling dashboard statics must still register.
        assert "g8://personas/dashboard" in resources  # #3
        assert "g8://icps/dashboard" in resources  # #13
        assert "g8://lists/dashboard" in resources  # #5
        assert "g8://global-context/library" in resources  # #15

        # Sibling templates from recent surfaces must remain intact.
        assert "g8://contacts/{contact_id}" in templates  # #58
        assert "g8://companies/{company_id}" in templates  # #59
        assert "g8://icps/{icp_id}" in templates  # #62
        assert "g8://personas/{persona_id}" in templates  # #63
        assert "g8://lists/{list_id}" in templates  # #64
        assert "g8://global-context/documents/{doc_id}" in templates  # #65

        # Resource name points at the copilot home handler.
        html_name = resources[html_uri].name
        assert "copilot" in html_name.lower() or "home" in html_name.lower(), (
            f"expected copilot home handler name, got {html_name!r}"
        )

    def test_core_tools_present(self, monkeypatch):
        """Spot-check that the always-on set is wired up.

        We don't lock every tool name anymore (pre-Upgrade 1 test did, and
        became high-churn). The always-on set is the real contract: these
        names must exist for progressive discovery to work.
        """
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        server = create_server()
        names = set(_tool_names(server))
        for required in {
            "g8_tool_search",
            "g8_search_contacts",
            "g8_search_companies",
            "g8_lookup_person",
            "g8_lookup_company",
            "g8_find_contacts",
            "g8_find_companies",
            "g8_get_lists",
            "g8_gtm_list_campaigns",
            "g8_list_sequences",
            "g8_list_inbox",
        }:
            assert required in names, f"always-on tool missing: {required}"
        # Pre-0.6.3, g8_list_skills was in this set. It was renamed to
        # g8_list_playbooks AND removed from always-on (now reachable via
        # g8_tool_search). Both old and new names must be tracked: the new
        # name is registered as a tool but NOT always-on; the old name does
        # not exist at all.
        assert "g8_list_playbooks" in names, (
            "g8_list_playbooks must be a registered tool (just not always-on)"
        )
        assert "g8_list_skills" not in names, (
            "g8_list_skills was renamed to g8_list_playbooks in v0.6.3"
        )
        assert "g8_load_skill" not in names, (
            "g8_load_skill was renamed to g8_load_playbook in v0.6.3"
        )

    def test_fails_without_api_key(self, monkeypatch):
        monkeypatch.delenv("G8_API_KEY", raising=False)
        monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))
        with pytest.raises(G8ClientError, match="G8_API_KEY"):
            create_server()


class TestErrorFormatting:
    """Regression tests for `_format_error` status-code coverage.

    Tools that reach this mapper include `g8_create_audience_sync` (which the
    backend returns 409 on duplicate audience+platform configs). Before the
    2026-04-21 fix, 409 fell through to the generic `f"Error: {str(e)}"` path,
    producing opaque messages like `API error (409): <body>` with no guidance
    on how to recover. The 409 branch now renders a canonical "Conflict"
    message that tells the agent what to do next.
    """

    def test_409_produces_canonical_conflict_message(self):
        from g8_mcp_server.client import _format_error, G8ClientError

        err = G8ClientError(409, "Audience sync already exists for meta:aud_123")
        rendered = _format_error(err, context="create_audience_sync")

        assert "Conflict" in rendered
        assert "already exists" in rendered
        assert "Audience sync already exists for meta:aud_123" in rendered
        # Must not fall through to the generic mapper.
        assert not rendered.startswith("Error: 409"), (
            f"409 should be handled explicitly, got generic fallback: {rendered!r}"
        )

    def test_format_error_has_no_em_dashes(self):
        """User-facing error strings must use hyphens, not em/en dashes.

        CLAUDE.md writing-style rule: `-` only. Em dashes leaking into error
        output ship to the MCP client and show up in chat transcripts.
        """
        from g8_mcp_server.client import _format_error, G8ClientError

        samples = [
            G8ClientError(401, "bad key"),
            G8ClientError(402, "out of credits"),
            G8ClientError(403, "forbidden"),
            G8ClientError(404, "missing"),
            G8ClientError(409, "dup"),
            G8ClientError(422, "bad params"),
            G8ClientError(429, "too many"),
            G8ClientError(500, "boom"),
            G8ClientError(418, "teapot"),  # generic fallback
        ]
        for err in samples:
            rendered = _format_error(err, context="test")
            assert "\u2014" not in rendered, f"em dash in {err.status_code}: {rendered!r}"
            assert "\u2013" not in rendered, f"en dash in {err.status_code}: {rendered!r}"


class TestToolSourceStyleRules:
    """Enforce the graph8 writing-style rule on tool source files.

    CLAUDE.md + the user memory file are explicit: em dashes (\u2014) and en
    dashes (\u2013) must not appear anywhere in writing - hyphens (`-`) only.
    MCP tool docstrings, argument descriptions, and string literals all ship
    to the agent (and often to end users through generated snippets / form
    templates / error messages). A regression here is visible to every
    customer using graph8 via MCP.

    This test locks the rule on the `tools/` directory. It runs in under a
    second and catches leaks before they ship.
    """

    def test_no_em_or_en_dashes_in_mcp_server_source(self):
        """Em/en dashes must not appear in prose (docstrings / comments /
        error messages / tool descriptions).

        One file is exempt: ``app_renderer.py``. That module intentionally
        uses ``"\u2014"`` as a typography glyph for missing / empty values
        in rendered HTML surfaces (same convention as Excel / financial
        dashboards). The graph8 HTML design system treats ``-`` and ``\u2014``
        as visually distinct (``\u2014`` is a "null cell" marker, ``-`` is a
        range separator), so replacing them would regress the renderer
        tests that expect the em-dash placeholder in HTML output. The
        prose-style rule still applies to the rest of the package.
        """
        import pathlib

        pkg_dir = pathlib.Path(__file__).parent.parent / "g8_mcp_server"
        EXEMPT = {"app_renderer.py"}  # typography glyph, not prose
        offenders: list[tuple[str, int, str]] = []
        for path in sorted(pkg_dir.rglob("*.py")):
            # Skip __pycache__ artifacts (shouldn't match *.py anyway, but guard).
            if "__pycache__" in path.parts:
                continue
            if path.name in EXEMPT:
                continue
            for lineno, line in enumerate(path.read_text().splitlines(), start=1):
                if "\u2014" in line or "\u2013" in line:
                    rel = path.relative_to(pkg_dir)
                    offenders.append((str(rel), lineno, line.strip()))
        assert offenders == [], (
            f"Found em/en dashes in {len(offenders)} line(s) under mcp_server/g8_mcp_server/. "
            f"Replace with hyphen `-`. Offenders:\n"
            + "\n".join(f"  {name}:{ln}: {text}" for name, ln, text in offenders[:20])
        )
