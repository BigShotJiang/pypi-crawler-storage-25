"""Unit tests for the MCP Apps (ui://) protocol helpers.

These tests exercise the thin registration layer against FastMCP  -  they
don't boot an MCP server over HTTP. For end-to-end testing see the
integration tests under `tests/` and the manual ladder documented in
`docs/plans/2026-04-22-mcp-apps-poc-campaigns-plan.md` (Phase 4).
"""

from __future__ import annotations

import pytest

from mcp.server import FastMCP

from g8_mcp_server.ui_apps import (
    UI_MIME_TYPE,
    UI_SCHEME,
    VENDOR_BUNDLE_PLACEHOLDER,
    claude_mcp_domain,
    load_bundle,
    register_ui_app_resource,
    ui_resource_meta,
    ui_tool_meta,
)


# ---------------------------------------------------------------------------
# Protocol constants  -  fail loudly if someone changes them
# ---------------------------------------------------------------------------


def test_ui_mime_type_matches_spec():
    """The literal MIME type is fixed by the MCP Apps spec.

    See https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/draft/apps.mdx
     -  "SHOULD be text/html;profile=mcp-app for HTML-based UIs in the initial MVP."
    """
    assert UI_MIME_TYPE == "text/html;profile=mcp-app"


def test_ui_scheme_is_ui_colon_slash_slash():
    """URI scheme for MCP App resources is spec-mandated `ui://`."""
    assert UI_SCHEME == "ui://"


# ---------------------------------------------------------------------------
# claude_mcp_domain  -  claude.ai's sandbox-origin format
# ---------------------------------------------------------------------------


class TestClaudeMcpDomain:
    """claude.ai rejects ui.domain unless it matches
    ``{sha256(mcp_url)[:32]}.claudemcpcontent.com``. Regression-test the
    exact values for prod / qa so a drift in the URL or hash length blows
    up here instead of silently breaking the widget in production.
    """

    def test_prod_url_hash_matches_claude_ai_expectation(self):
        """Value must equal what the node snippet from claude.ai's error
        banner produces for ``https://be.graph8.com/mcp``.
        """
        # This is the value claude.ai's "Invalid ui.domain format" error
        # suggested on 2026-04-24 when the server sent the literal string
        # "graph8". If this assertion fails, either the prod URL changed
        # or claude.ai changed the hash algorithm  -  investigate before
        # shipping.
        assert (
            claude_mcp_domain("https://be.graph8.com/mcp")
            == "9325f3a5a4b55958f0d08574bcfd5c64.claudemcpcontent.com"
        )

    def test_default_uses_prod_url(self, monkeypatch):
        """With no env var set the helper defaults to prod URL."""
        monkeypatch.delenv("G8_MCP_PUBLIC_URL", raising=False)
        assert claude_mcp_domain() == claude_mcp_domain("https://be.graph8.com/mcp")

    def test_env_var_overrides_default(self, monkeypatch):
        """``G8_MCP_PUBLIC_URL`` lets QA / dev deployments emit their
        own host's hash without a code change.
        """
        monkeypatch.setenv("G8_MCP_PUBLIC_URL", "https://be.qa.graph8.com/mcp")
        assert claude_mcp_domain() == claude_mcp_domain("https://be.qa.graph8.com/mcp")
        # And it's a different value than prod  -  proves the override took.
        assert claude_mcp_domain() != claude_mcp_domain("https://be.graph8.com/mcp")

    def test_explicit_arg_overrides_env(self, monkeypatch):
        """Explicit argument beats env var."""
        monkeypatch.setenv("G8_MCP_PUBLIC_URL", "https://lies.example.com/mcp")
        assert (
            claude_mcp_domain("https://be.graph8.com/mcp")
            == "9325f3a5a4b55958f0d08574bcfd5c64.claudemcpcontent.com"
        )

    def test_format_shape(self):
        """Shape must be ``{32-hex-chars}.claudemcpcontent.com``."""
        value = claude_mcp_domain("https://example.com/mcp")
        prefix, suffix = value.split(".", 1)
        assert len(prefix) == 32
        assert all(c in "0123456789abcdef" for c in prefix)
        assert suffix == "claudemcpcontent.com"


# ---------------------------------------------------------------------------
# ui_resource_meta
# ---------------------------------------------------------------------------


class TestUiResourceMeta:
    def test_empty_when_nothing_passed(self):
        assert ui_resource_meta() == {}

    def test_csp_only(self):
        csp = {"resourceDomains": ["cdn.jsdelivr.net"]}
        assert ui_resource_meta(csp=csp) == {"ui": {"csp": csp}}

    def test_permissions_only(self):
        perms = {"microphone": {}}
        assert ui_resource_meta(permissions=perms) == {"ui": {"permissions": perms}}

    def test_all_fields(self):
        meta = ui_resource_meta(
            csp={"connectDomains": ["api.graph8.com"]},
            permissions={"camera": {}},
            prefers_border=True,
            domain="graph8",
        )
        assert meta == {
            "ui": {
                "csp": {"connectDomains": ["api.graph8.com"]},
                "permissions": {"camera": {}},
                "prefersBorder": True,
                "domain": "graph8",
            }
        }


# ---------------------------------------------------------------------------
# ui_tool_meta
# ---------------------------------------------------------------------------


class TestUiToolMeta:
    def test_happy_path(self):
        assert ui_tool_meta("ui://campaigns/ad-images") == {
            "ui": {"resourceUri": "ui://campaigns/ad-images"}
        }

    def test_with_visibility(self):
        m = ui_tool_meta(
            "ui://campaigns/ad-images",
            visibility=["model", "app"],
        )
        assert m == {
            "ui": {
                "resourceUri": "ui://campaigns/ad-images",
                "visibility": ["model", "app"],
            }
        }

    def test_rejects_non_ui_scheme(self):
        """Tools must target ui:// resources specifically  -  g8:// is a user
        error that would silently fail at render time."""
        with pytest.raises(ValueError, match="must start with 'ui://'"):
            ui_tool_meta("g8://campaigns/dashboard")

    def test_rejects_empty_uri(self):
        with pytest.raises(ValueError):
            ui_tool_meta("")


# ---------------------------------------------------------------------------
# Bundle loading
# ---------------------------------------------------------------------------


class TestLoadBundle:
    def test_loads_existing_bundle(self):
        """The repo ships a `_smoke.html` bundle specifically for this test."""
        html = load_bundle("_smoke")
        assert "<!doctype html>" in html.lower()

    def test_missing_bundle_raises(self):
        with pytest.raises(FileNotFoundError, match="not found"):
            load_bundle("definitely_not_a_real_bundle_name_9999")

    def test_smoke_bundle_has_no_placeholder_and_passes_through(self):
        """The `_smoke.html` bundle has no vendor placeholder - it must
        round-trip byte-for-byte so that bundles that don't need the SDK
        aren't accidentally mutated by the injection path.
        """
        html = load_bundle("_smoke")
        assert VENDOR_BUNDLE_PLACEHOLDER not in html

    def test_placeholder_is_substituted(self, tmp_path, monkeypatch):
        """``load_bundle`` replaces the literal placeholder with
        ``<script>{vendor-iife}</script>``, and leaves everything else
        alone.
        """
        from g8_mcp_server import ui_apps

        # Point the bundle dir at a tmp location so we can drop a fake
        # bundle + fake vendor file without touching the real ones.
        fake_bundle = tmp_path / "fake.html"
        fake_bundle.write_text(
            f"<html><body>BEFORE\n{VENDOR_BUNDLE_PLACEHOLDER}\nAFTER</body></html>",
            encoding="utf-8",
        )
        fake_vendor_dir = tmp_path / "_vendor"
        fake_vendor_dir.mkdir()
        fake_vendor = fake_vendor_dir / "ext-apps.iife.min.js"
        fake_vendor.write_text("var __mcpApps={App:class{}};", encoding="utf-8")

        monkeypatch.setattr(ui_apps, "_BUNDLE_DIR", tmp_path)
        monkeypatch.setattr(ui_apps, "_VENDOR_BUNDLE_PATH", fake_vendor)

        html = ui_apps.load_bundle("fake")
        assert VENDOR_BUNDLE_PLACEHOLDER not in html
        assert "<script>var __mcpApps={App:class{}};</script>" in html
        assert "BEFORE" in html and "AFTER" in html

    def test_placeholder_missing_when_vendor_file_missing(
        self, tmp_path, monkeypatch
    ):
        """If the vendor file is gone but a bundle still references the
        placeholder, we raise FileNotFoundError instead of serving a
        widget that will throw "SDK missing" at runtime.
        """
        from g8_mcp_server import ui_apps

        fake_bundle = tmp_path / "fake.html"
        fake_bundle.write_text(VENDOR_BUNDLE_PLACEHOLDER, encoding="utf-8")

        monkeypatch.setattr(ui_apps, "_BUNDLE_DIR", tmp_path)
        monkeypatch.setattr(
            ui_apps, "_VENDOR_BUNDLE_PATH", tmp_path / "does-not-exist.js"
        )
        with pytest.raises(FileNotFoundError, match="SDK bundle not found"):
            ui_apps.load_bundle("fake")

    def test_vendor_bundle_file_exists_and_defines_global(self):
        """The real vendor file must ship with the package; a broken /
        missing bundle is a deployment bug that this test catches at
        CI time instead of at first widget render.
        """
        from g8_mcp_server import ui_apps

        assert ui_apps._VENDOR_BUNDLE_PATH.is_file(), (
            f"vendor bundle missing at {ui_apps._VENDOR_BUNDLE_PATH}. "
            "Rebuild per ui_bundles/_vendor/README.md."
        )
        vendor = ui_apps._VENDOR_BUNDLE_PATH.read_text(encoding="utf-8")
        # esbuild --format=iife --global-name=__mcpApps produces this marker.
        assert "var __mcpApps=" in vendor
        # And the surface we actually use.
        assert "App" in vendor


# ---------------------------------------------------------------------------
# register_ui_app_resource  -  exercises the full wire path
# ---------------------------------------------------------------------------


class TestRegisterUiAppResource:
    @pytest.fixture
    def server(self) -> FastMCP:
        return FastMCP("test-ui-apps")

    @pytest.mark.asyncio
    async def test_registers_with_correct_mime_and_meta(self, server: FastMCP):
        register_ui_app_resource(
            server,
            uri="ui://smoke/test",
            bundle_name="_smoke",
            description="Smoke test",
            csp={"resourceDomains": ["cdn.jsdelivr.net"]},
            domain="graph8",
        )

        resources = await server.list_resources()
        matching = [r for r in resources if str(r.uri) == "ui://smoke/test"]
        assert len(matching) == 1, (
            f"Expected exactly one resource at ui://smoke/test, got: "
            f"{[str(r.uri) for r in resources]}"
        )
        resource = matching[0]

        # Mime type is the spec literal.
        assert resource.mimeType == "text/html;profile=mcp-app"

        # _meta.ui.csp + _meta.ui.domain show up on the listing.
        assert resource.meta is not None
        ui = resource.meta.get("ui") or {}
        assert ui.get("csp") == {"resourceDomains": ["cdn.jsdelivr.net"]}
        assert ui.get("domain") == "graph8"

    @pytest.mark.asyncio
    async def test_read_returns_bundle_html_with_meta(self, server: FastMCP):
        register_ui_app_resource(
            server,
            uri="ui://smoke/test",
            bundle_name="_smoke",
            description="Smoke test",
            csp={"resourceDomains": ["cdn.jsdelivr.net"]},
        )

        # FastMCP returns ReadResourceContents (a dataclass); the lowlevel
        # wire conversion turns this into TextResourceContents with _meta
        # preserved. In 1.26+ the meta kwarg on ReadResourceContents is
        # propagated. We assert both the mime type and the meta survive.
        contents = list(await server.read_resource("ui://smoke/test"))
        assert len(contents) == 1
        rc = contents[0]
        assert rc.mime_type == "text/html;profile=mcp-app"
        assert "<!doctype html>" in rc.content.lower()  # type: ignore[union-attr]
        assert rc.meta is not None
        assert rc.meta.get("ui", {}).get("csp") == {"resourceDomains": ["cdn.jsdelivr.net"]}

    def test_rejects_non_ui_uri(self, server: FastMCP):
        with pytest.raises(ValueError, match="must start with 'ui://'"):
            register_ui_app_resource(
                server,
                uri="g8://wrong/scheme",
                bundle_name="_smoke",
                description="",
            )

    def test_rejects_missing_bundle(self, server: FastMCP):
        """A typo in bundle_name must fail at registration time, not later
        at read time  -  we don't want the server to boot fine and then throw
        when a user opens the widget."""
        with pytest.raises(FileNotFoundError):
            register_ui_app_resource(
                server,
                uri="ui://smoke/bad",
                bundle_name="this_bundle_does_not_exist",
                description="",
            )


# ---------------------------------------------------------------------------
# Integration: the real app resources + tool meta wiring
#
# These tests don't boot HTTP; they exercise the registration paths against
# a FastMCP instance populated by our real `resources.register()` /
# `tools.gtm.register()` calls, proving that:
#   - ui://campaigns/ad-images and ui://campaigns/dashboard both exist with
#     the spec mime type.
#   - g8_gtm_list_campaigns, g8_get_ad_images, g8_hide_ad_image all carry
#     _meta.ui.resourceUri pointing at the correct ui:// URI.
#   - Legacy g8:// resources are NOT clobbered by the ui:// additions.
# ---------------------------------------------------------------------------


class TestRealAppsRegistration:
    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import gtm as gtm_mod

        server = FastMCP("test-integration")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        gtm_mod.register(server, client, name_prefix="gtm")
        return server

    @pytest.mark.asyncio
    async def test_both_ui_resources_registered(self, server: FastMCP):
        resources = await server.list_resources()
        uris = {str(r.uri) for r in resources}
        assert "ui://campaigns/ad-images" in uris
        assert "ui://campaigns/dashboard" in uris

    @pytest.mark.asyncio
    async def test_ui_resources_use_spec_mime_type(self, server: FastMCP):
        resources = await server.list_resources()
        for uri in ("ui://campaigns/ad-images", "ui://campaigns/dashboard"):
            matching = [r for r in resources if str(r.uri) == uri]
            assert matching, f"missing ui resource: {uri}"
            assert matching[0].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}: {matching[0].mimeType!r}"
            )

    @pytest.mark.asyncio
    async def test_legacy_g8_resources_still_present(self, server: FastMCP):
        """Adding ui:// variants must not have removed any legacy g8://
        resources  -  existing Claude reasoning workflows depend on them."""
        resources = await server.list_resources()
        uris = {str(r.uri) for r in resources}
        # Spot-check one known legacy surface to make sure we didn't regress.
        assert "g8://campaigns/dashboard" in uris, (
            "legacy g8://campaigns/dashboard resource disappeared  -  the ui://"
            " sibling should be additive, not a replacement"
        )

    @pytest.mark.asyncio
    async def test_list_campaigns_tool_links_dashboard(self, server: FastMCP):
        tools = await server.list_tools()
        tool = next((t for t in tools if t.name == "g8_gtm_list_campaigns"), None)
        assert tool is not None, "g8_gtm_list_campaigns tool missing"
        assert tool.meta is not None, "tool has no _meta"
        assert tool.meta.get("ui", {}).get("resourceUri") == "ui://campaigns/dashboard"

    @pytest.mark.asyncio
    async def test_get_ad_images_tool_links_grid(self, server: FastMCP):
        tools = await server.list_tools()
        tool = next((t for t in tools if t.name == "g8_gtm_get_ad_images"), None)
        assert tool is not None, "g8_gtm_get_ad_images tool missing"
        assert tool.meta is not None
        assert tool.meta.get("ui", {}).get("resourceUri") == "ui://campaigns/ad-images"

    @pytest.mark.asyncio
    async def test_hide_ad_image_tool_links_grid(self, server: FastMCP):
        tools = await server.list_tools()
        tool = next((t for t in tools if t.name == "g8_gtm_hide_ad_image"), None)
        assert tool is not None, "g8_gtm_hide_ad_image tool missing"
        assert tool.meta is not None
        assert tool.meta.get("ui", {}).get("resourceUri") == "ui://campaigns/ad-images"

    @pytest.mark.asyncio
    async def test_ui_resource_read_contains_bundle_html(self, server: FastMCP):
        """Sanity-check that the real bundles load and contain an app.connect
        call  -  a missing file or broken path would surface here."""
        for uri, expected_title in (
            ("ui://campaigns/ad-images", "graph8 ad creatives"),
            ("ui://campaigns/dashboard", "graph8 campaigns"),
        ):
            contents = list(await server.read_resource(uri))
            assert len(contents) == 1
            rc = contents[0]
            html = rc.content
            assert isinstance(html, str)
            assert expected_title in html, f"{uri} bundle missing expected title"
            assert "app.connect()" in html, (
                f"{uri} bundle missing app.connect()  -  MCP Apps handshake would never fire"
            )
            assert rc.mime_type == "text/html;profile=mcp-app"

    @pytest.mark.asyncio
    async def test_ad_images_csp_has_image_origins_not_cdn(self, server: FastMCP):
        """ad-images declares its image CDN origins and, since the SDK is
        now inlined, no longer lists cdn.jsdelivr.net. Hosts that honor
        CSP (Claude Desktop etc.) rely on this list being accurate.
        """
        contents = list(await server.read_resource("ui://campaigns/ad-images"))
        rc = contents[0]
        assert rc.meta is not None
        csp = (rc.meta.get("ui") or {}).get("csp") or {}
        domains = csp.get("resourceDomains", [])
        assert "cdn.jsdelivr.net" not in domains, (
            "cdn.jsdelivr.net left in CSP - the SDK is inlined now, this is stale"
        )
        # Image origins still required.
        assert "*.s3.amazonaws.com" in domains
        assert "*.cloudfront.net" in domains
        assert "*.r2.cloudflarestorage.com" in domains

    @pytest.mark.asyncio
    async def test_dashboard_csp_has_image_origins_for_drill_in(self, server: FastMCP):
        """Dashboard now drills into ad-images via the shared shell
        (one widget, multiple views), so it must declare the same image
        CDN origins as the ad-images widget. A bare CSP or one missing
        these origins would break the drill-in flow on hosts that honor
        ``ui.csp.resourceDomains`` (Claude Desktop etc.).

        ``cdn.jsdelivr.net`` must NOT be present - the SDK is inlined.
        """
        contents = list(await server.read_resource("ui://campaigns/dashboard"))
        rc = contents[0]
        assert rc.meta is not None
        csp = (rc.meta.get("ui") or {}).get("csp") or {}
        domains = csp.get("resourceDomains", [])
        assert "cdn.jsdelivr.net" not in domains, (
            "cdn.jsdelivr.net left in CSP - the SDK is inlined now, this is stale"
        )
        # Image origins required because the dashboard drills into ad-images.
        assert "*.s3.amazonaws.com" in domains
        assert "*.cloudfront.net" in domains
        assert "*.r2.cloudflarestorage.com" in domains

    @pytest.mark.asyncio
    async def test_real_widgets_have_no_cdn_script_imports(self, server: FastMCP):
        """claude.ai's widget-iframe CSP ignores our resourceDomains list
        and blocks all cross-origin script loads. Widgets MUST inline the
        SDK - not import from jsdelivr, esm.sh, unpkg, or any other CDN.
        This test locks that invariant on the rendered HTML.
        """
        forbidden = ("cdn.jsdelivr.net", "esm.sh", "unpkg.com", "cdn.skypack.dev")
        for uri in ("ui://campaigns/ad-images", "ui://campaigns/dashboard"):
            rc = list(await server.read_resource(uri))[0]
            html = rc.content
            assert isinstance(html, str)
            for host in forbidden:
                assert host not in html, (
                    f"{uri} still references {host!r} - would be blocked by "
                    "claude.ai's widget CSP. Inline the SDK instead."
                )

    @pytest.mark.asyncio
    async def test_real_widgets_contain_inlined_vendor_sdk(self, server: FastMCP):
        """The vendor IIFE defines a global ``__mcpApps`` and we inject it
        as ``<script>var __mcpApps=...</script>``. A widget that loses the
        injection (placeholder missing, or file removed) would fail to
        render silently. Assert a marker string that only the inlined
        bundle can produce.
        """
        for uri in ("ui://campaigns/ad-images", "ui://campaigns/dashboard"):
            rc = list(await server.read_resource(uri))[0]
            html = rc.content
            assert isinstance(html, str)
            # Marker produced by esbuild's IIFE wrapper for --global-name=__mcpApps.
            assert "var __mcpApps=" in html, (
                f"{uri} missing inlined MCP Apps SDK - did the "
                "<!--@MCP_APPS_VENDOR_BUNDLE@--> placeholder get removed?"
            )
            # And the widget must pull the class off that global.
            assert "window.__mcpApps" in html


# ---------------------------------------------------------------------------
# Wave 1: 5 generic list widgets (contacts, companies, inbox, lists,
# sequences) all driven by the shared shell.html bundle. These tests use
# their own fixture that registers the platform + inbox tool modules so we
# can assert _meta.ui.resourceUri on the relevant tools.
# ---------------------------------------------------------------------------


class TestWave1Apps:
    """All 5 Wave 1 widgets share one shell + per-widget view_config. The
    invariants we check here:
      - each ui:// resource is registered with the spec mime type
      - each linked tool carries _meta.ui.resourceUri pointing at it
      - the rendered HTML embeds the per-widget view_config JSON (the
        shell otherwise renders an error)
      - bundles use the inlined SDK (no CDN imports)
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import inbox as inbox_mod
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-wave1")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        platform_mod.register(server, client)
        inbox_mod.register(server, client)
        return server

    # --- Resources -------------------------------------------------------

    @pytest.mark.asyncio
    async def test_all_wave1_resources_registered(self, server: FastMCP):
        """All 5 widget URIs must be present with the spec mime type."""
        resources = await server.list_resources()
        by_uri = {str(r.uri): r for r in resources}
        for uri in (
            "ui://contacts/list",
            "ui://companies/list",
            "ui://inbox/list",
            "ui://lists/list",
            "ui://sequences/list",
        ):
            assert uri in by_uri, f"missing Wave 1 resource: {uri}"
            assert by_uri[uri].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}"
            )

    # --- Tool wiring -----------------------------------------------------

    @pytest.mark.asyncio
    async def test_tools_link_to_correct_widgets(self, server: FastMCP):
        """Every Wave 1 tool must declare _meta.ui.resourceUri pointing
        at its widget. Both find_* (open-data) and search_* (CRM)
        contact/company tools share a widget URI - the same shell renders
        both result shapes since they use the same Pydantic model.
        """
        expected = {
            "g8_find_contacts": "ui://contacts/list",
            "g8_search_contacts": "ui://contacts/list",
            "g8_find_companies": "ui://companies/list",
            "g8_search_companies": "ui://companies/list",
            "g8_list_inbox": "ui://inbox/list",
            "g8_get_lists": "ui://lists/list",
            "g8_list_sequences": "ui://sequences/list",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} not registered"
            tool = tools[name]
            assert tool.meta is not None, f"tool {name!r} has no _meta"
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta.ui.resourceUri = {actual!r}, "
                f"expected {expected_uri!r}"
            )

    # --- Rendered HTML ---------------------------------------------------

    @pytest.mark.asyncio
    async def test_wave1_widgets_embed_view_config(self, server: FastMCP):
        """The shell reads its view config from a
        <script type="application/json" id="mcp-app-view-config">
        block. The Python serializer substitutes {{VIEW_CONFIG_JSON}}
        with the dict for each widget. We assert the substitution
        happened (no leftover placeholder) and that a widget-specific
        marker is present in the JSON.
        """
        markers = {
            "ui://contacts/list": '"page_title": "graph8 contacts"',
            "ui://companies/list": '"page_title": "graph8 companies"',
            "ui://inbox/list": '"page_title": "graph8 inbox"',
            "ui://lists/list": '"page_title": "graph8 lists"',
            "ui://sequences/list": '"page_title": "graph8 sequences"',
        }
        for uri, marker in markers.items():
            contents = list(await server.read_resource(uri))
            assert len(contents) == 1
            html = contents[0].content
            assert isinstance(html, str)
            assert "{{VIEW_CONFIG_JSON}}" not in html, (
                f"{uri}: view-config placeholder left unsubstituted"
            )
            # Pydantic dumps with double-quoted keys, no spaces. JSON.dumps
            # adds a space after colons by default. Match the actual format
            # the json module produces.
            normalized = html.replace(": ", ":").replace('", "', '","')
            normalized_marker = marker.replace(": ", ":").replace('", "', '","')
            assert normalized_marker in normalized, (
                f"{uri}: expected JSON marker {marker!r} in rendered HTML"
            )
            # All Wave 1 bundles also inline the SDK and call app.connect.
            assert "var __mcpApps=" in html
            assert "app.connect()" in html
            assert "<!--@MCP_APPS_VENDOR_BUNDLE@-->" not in html

    @pytest.mark.asyncio
    async def test_wave1_widgets_have_no_cdn_script_imports(self, server: FastMCP):
        """Same invariant as the campaigns widgets: claude.ai blocks CDN
        scripts in the iframe CSP, so the SDK must be inlined.
        """
        forbidden = ("cdn.jsdelivr.net", "esm.sh", "unpkg.com", "cdn.skypack.dev")
        for uri in (
            "ui://contacts/list",
            "ui://companies/list",
            "ui://inbox/list",
            "ui://lists/list",
            "ui://sequences/list",
        ):
            html = list(await server.read_resource(uri))[0].content
            assert isinstance(html, str)
            for host in forbidden:
                assert host not in html, (
                    f"{uri} references forbidden CDN host {host!r}"
                )

    @pytest.mark.asyncio
    async def test_wave1_widgets_have_no_csp_image_origins(self, server: FastMCP):
        """List-only widgets render no images, so they should not declare
        image CDN origins. (Adding origins later is fine; this test
        documents the current minimal-CSP shape.)
        """
        for uri in (
            "ui://contacts/list",
            "ui://companies/list",
            "ui://inbox/list",
            "ui://lists/list",
            "ui://sequences/list",
        ):
            rc = list(await server.read_resource(uri))[0]
            assert rc.meta is not None
            csp = (rc.meta.get("ui") or {}).get("csp")
            # csp may be None (no declaration) or {} - either is fine.
            if csp:
                domains = csp.get("resourceDomains", [])
                # Must NOT carry image origins for list-only widgets.
                assert "*.s3.amazonaws.com" not in domains, (
                    f"{uri} declares image CDN origins it does not need"
                )


# ---------------------------------------------------------------------------
# Drill-in row_action wiring on list widgets, plus standalone detail widgets,
# plus the second batch of net-new list widgets. Every check below is a
# registration-level invariant (no HTTP, no real backend calls).
# ---------------------------------------------------------------------------


class TestDrillInsAndDetailWidgets:
    """This block covers three additive concerns on top of the first list batch:

      1. Every list widget gets a ``row_action`` declaration so a row click
         drills into a sibling detail/sub-list view.
      2. Six standalone ``ui://*/detail`` widgets so a tool can be
         invoked directly (without a list ancestor) and still render.
      3. Seven net-new Wave 2 list widgets covering deals, tasks,
         activities, audience-syncs, crm-syncs, personas, and icps.

    All three layers ride the same shell.html bundle - we only assert the
    config dict shape and that linked tools carry _meta.ui.resourceUri.
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import gtm as gtm_mod
        from g8_mcp_server.tools import inbox as inbox_mod
        from g8_mcp_server.tools import platform as platform_mod
        from g8_mcp_server.tools import sync as sync_mod

        server = FastMCP("test-pr-b")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        platform_mod.register(server, client)
        inbox_mod.register(server, client)
        sync_mod.register(server, client)
        gtm_mod.register(server, client, name_prefix="gtm")
        return server

    # --- Wave 1 row_action drill-ins ------------------------------------

    @pytest.mark.asyncio
    async def test_wave1_widgets_declare_row_action(self, server: FastMCP):
        """Every Wave 1 list widget must declare ``row_action`` so clicks
        drill into a detail or sub-list. Specifically:

          - contacts/list -> "detail"  (g8_get_contact_detail)
          - companies/list -> "company-contacts"  (g8_get_company_contacts)
          - inbox/list -> "thread"  (g8_get_reply)
          - lists/list -> "contacts"  (g8_search_contacts)
          - sequences/list -> "detail"  (g8_get_sequence_preview)

        We grep the rendered view-config JSON for the tool name and the
        target view id to lock the wiring in. A regression here would
        manifest as silent click-does-nothing in production.
        """
        cases = {
            "ui://contacts/list": ("g8_get_contact_detail", '"view": "detail"'),
            "ui://companies/list": (
                "g8_get_company_contacts",
                '"view": "company-contacts"',
            ),
            "ui://inbox/list": ("g8_get_reply", '"view": "thread"'),
            "ui://lists/list": ("g8_search_contacts", '"view": "contacts"'),
            "ui://sequences/list": (
                "g8_get_sequence_preview",
                '"view": "detail"',
            ),
        }
        for uri, (tool_name, view_marker) in cases.items():
            html = list(await server.read_resource(uri))[0].content
            assert isinstance(html, str)
            # Drop spaces inside JSON so we don't depend on json.dumps
            # indentation. We just want to know both markers are there.
            normalized = html.replace(" ", "")
            assert f'"tool":"{tool_name}"' in normalized, (
                f"{uri}: row_action must call {tool_name!r}"
            )
            assert view_marker.replace(" ", "") in normalized, (
                f"{uri}: row_action must target {view_marker}"
            )

    # --- Standalone detail widgets --------------------------------------

    @pytest.mark.asyncio
    async def test_standalone_detail_widgets_registered(self, server: FastMCP):
        """All five standalone detail widgets must be registered with the
        spec mime type and a ``"type": "detail"`` root view.
        """
        detail_uris = (
            "ui://contacts/detail",
            "ui://companies/detail",
            "ui://sequences/detail",
            "ui://inbox/thread",
            "ui://deals/detail",
        )
        resources = await server.list_resources()
        by_uri = {str(r.uri): r for r in resources}
        for uri in detail_uris:
            assert uri in by_uri, f"missing standalone detail widget: {uri}"
            assert by_uri[uri].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}"
            )
            html = list(await server.read_resource(uri))[0].content
            assert isinstance(html, str)
            normalized = html.replace(" ", "")
            assert '"type":"detail"' in normalized, (
                f"{uri}: root view must be type=detail"
            )
            assert '"data_path":"__self__"' in normalized, (
                f"{uri}: detail view must use the __self__ dispatch sentinel"
            )

    @pytest.mark.asyncio
    async def test_detail_tools_link_to_detail_widgets(self, server: FastMCP):
        """The four read-only detail tools must declare _meta.ui.resourceUri
        pointing at their standalone widget.
        """
        expected = {
            "g8_get_contact_detail": "ui://contacts/detail",
            "g8_lookup_company": "ui://companies/detail",
            "g8_get_sequence_preview": "ui://sequences/detail",
            "g8_get_reply": "ui://inbox/thread",
            "g8_get_deal": "ui://deals/detail",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} not registered"
            tool = tools[name]
            assert tool.meta is not None, f"tool {name!r} has no _meta"
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta.ui.resourceUri = {actual!r}, "
                f"expected {expected_uri!r}"
            )

    # --- Wave 2 list widgets --------------------------------------------

    @pytest.mark.asyncio
    async def test_wave2_widgets_registered(self, server: FastMCP):
        """All seven Wave 2 widgets must be registered."""
        wave2_uris = (
            "ui://deals/list",
            "ui://tasks/list",
            "ui://activities/list",
            "ui://audience-syncs/list",
            "ui://crm-syncs/list",
            "ui://personas/list",
            "ui://icps/list",
        )
        resources = await server.list_resources()
        by_uri = {str(r.uri): r for r in resources}
        for uri in wave2_uris:
            assert uri in by_uri, f"missing Wave 2 widget: {uri}"
            assert by_uri[uri].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}"
            )

    @pytest.mark.asyncio
    async def test_wave2_tools_link_to_widgets(self, server: FastMCP):
        """Wave 2 list tools must declare _meta.ui.resourceUri pointing at
        their widget. Drill-in detail tools (g8_get_deal,
        g8_get_audience_sync_runs) also point at the parent list widget
        because their detail view is rendered as a sibling inside the
        same widget bundle.
        """
        expected = {
            "g8_get_deals": "ui://deals/list",
            "g8_get_deal": "ui://deals/detail",
            "g8_get_tasks": "ui://tasks/list",
            "g8_get_activities": "ui://activities/list",
            "g8_list_audience_syncs": "ui://audience-syncs/list",
            "g8_get_audience_sync_runs": "ui://audience-syncs/list",
            "g8_list_crm_syncs": "ui://crm-syncs/list",
            "g8_gtm_get_personas": "ui://personas/list",
            "g8_gtm_get_icps": "ui://icps/list",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} not registered"
            tool = tools[name]
            assert tool.meta is not None, f"tool {name!r} has no _meta"
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta.ui.resourceUri = {actual!r}, "
                f"expected {expected_uri!r}"
            )

    @pytest.mark.asyncio
    async def test_deals_list_drills_into_deals_detail(self, server: FastMCP):
        """deals/list declares a row_action for g8_get_deal and registers
        a sibling "detail" view in the same widget bundle.
        """
        html = list(await server.read_resource("ui://deals/list"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"tool":"g8_get_deal"' in normalized
        assert '"view":"detail"' in normalized
        # Sibling detail view must be present in the bundle.
        assert '"data_path":"__self__"' in normalized

    @pytest.mark.asyncio
    async def test_audience_syncs_list_drills_into_runs(self, server: FastMCP):
        """audience-syncs/list declares a row_action for
        g8_get_audience_sync_runs and registers a sibling "runs" view.
        """
        html = list(await server.read_resource("ui://audience-syncs/list"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"tool":"g8_get_audience_sync_runs"' in normalized
        assert '"view":"runs"' in normalized

    # --- Back-compat ----------------------------------------------------

    @pytest.mark.asyncio
    async def test_existing_resources_still_present(self, server: FastMCP):
        """All previously-registered resources (campaigns/dashboard,
        ad-images, the five original list widgets, legacy g8:// URIs)
        must still be present; this batch is additive only.
        """
        resources = await server.list_resources()
        uris = {str(r.uri) for r in resources}
        for uri in (
            "ui://campaigns/dashboard",
            "ui://campaigns/ad-images",
            "ui://contacts/list",
            "ui://companies/list",
            "ui://inbox/list",
            "ui://lists/list",
            "ui://sequences/list",
            "g8://campaigns/dashboard",  # legacy g8:// resource still alive
        ):
            assert uri in uris, f"back-compat regression: missing {uri}"


class TestPostMergeRegressionFixes:
    """Real-world regression fixes after the first round of MCP-Apps
    drill-ins shipped to production:

      1. Inbox thread messages rendered as just ``:`` because the MCP
         server's ``InboxMessage`` model invented field names that don't
         match the developer_api ``InboxMessageItem`` DTO. Pydantic's
         ``extra='ignore'`` swallowed the real fields, leaving everything
         null.
      2. Sequence detail stat cards (Steps / Channels) rendered ``-``
         because ``statCardHtml`` ignored the ``cfg.key`` fallback when a
         ``cfg.template`` was present and the template had unresolved
         placeholders.
      3. Sequence detail rendered a wall of ``-`` rows for sequences
         whose backend payload came back with all-null fields (drafts /
         no-preview), because the empty check only fired for literally
         empty objects, not for objects whose every key is null.

    These tests lock in the fixes so the symptoms can't silently come
    back. They're scoped tightly: they assert the fix surface is wired,
    not the entire render path.
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client

        server = FastMCP("test-post-merge-fixes")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        return server

    # --- Fix 1: InboxMessage model + thread template -------------------

    def test_inbox_message_accepts_backend_canonical_fields(self):
        """``InboxMessage`` must populate the canonical backend fields
        (``message_id``, ``from_address``, ``content``, ``date``,
        ``responder``, ``is_draft``, ``to_addresses``) instead of
        silently dropping them. Regression: pre-fix, all fields rendered
        as null because the model named them ``id``/``sender``/``body``.
        """
        from g8_mcp_server.models import InboxMessage

        msg = InboxMessage.model_validate(
            {
                "message_id": "m_123",
                "from_address": "alice@example.com",
                "to_addresses": ["bob@example.com"],
                "content": "Hello there",
                "responder": "USER",
                "date": "2026-04-26T10:00:00Z",
                "is_draft": False,
            }
        )
        assert msg.message_id == "m_123"
        assert msg.from_address == "alice@example.com"
        assert msg.to_addresses == ["bob@example.com"]
        assert msg.content == "Hello there"
        assert msg.responder == "USER"
        assert msg.date == "2026-04-26T10:00:00Z"
        assert msg.is_draft is False

    def test_inbox_message_keeps_legacy_fields_for_backwards_compat(self):
        """The pre-fix legacy field names (``id``, ``sender``, ``body``,
        etc.) must remain on the model with ``None`` defaults so any
        downstream caller that referenced them by attribute keeps
        working. Removing them would be a breaking change.
        """
        from g8_mcp_server.models import InboxMessage

        msg = InboxMessage()
        # Each legacy field still resolves to None - no AttributeError.
        for legacy in (
            "id",
            "channel",
            "direction",
            "sender",
            "recipient",
            "subject",
            "body",
            "sent_at",
            "received_at",
        ):
            assert getattr(msg, legacy) is None, (
                f"legacy field {legacy!r} must remain on InboxMessage"
            )

    @pytest.mark.asyncio
    async def test_inbox_thread_template_uses_backend_field_names(
        self, server: FastMCP
    ):
        """The inbox thread message section template must reference the
        backend canonical field names (``from_address``, ``date``,
        ``content``) - not the pre-fix invented names (``sender``,
        ``sent_at``, ``body``) - or messages render as just ``:``.
        """
        html = list(await server.read_resource("ui://inbox/thread"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        # The new templates must be present.
        assert '"primary_template":"{responder}:{from_address}"' in normalized, (
            "inbox thread primary_template must use {responder}: {from_address}"
        )
        assert '"meta_template":"{date}"' in normalized, (
            "inbox thread meta_template must use {date}"
        )
        assert '"body_key":"content"' in normalized, (
            "inbox thread body_key must use 'content'"
        )
        # And the broken ones must be gone (regression guard).
        assert '"primary_template":"{direction}:{sender}"' not in normalized
        assert '"meta_template":"{sent_at}"' not in normalized
        assert '"body_key":"body"' not in normalized

    # --- Fix 2: statCardHtml cfg.key fallback --------------------------

    def test_shell_stat_card_falls_back_to_key_when_template_incomplete(self):
        """``statCardHtml`` must fall back to ``getPath(item, cfg.key)``
        when ``cfg.template`` is set but the interpolation didn't fully
        resolve (e.g. ``{steps.length}`` against a payload with no
        ``steps`` array). Without this fallback, sequence detail stat
        cards render ``-`` even when the backend supplies ``step_count``.
        """
        from g8_mcp_server.ui_apps import load_bundle

        html = load_bundle("shell")
        # The fallback block must reference both cfg.template and cfg.key
        # and call getPath with cfg.key. We grep for the key sentinels
        # so brace/whitespace style doesn't matter.
        assert "cfg.template && cfg.key" in html, (
            "statCardHtml must fall back to cfg.key when cfg.template "
            "doesn't fully resolve"
        )

    @pytest.mark.asyncio
    async def test_sequence_detail_stat_cards_have_key_fallback_configured(
        self, server: FastMCP
    ):
        """The sequence detail Steps/Channels stat cards must keep the
        ``key`` fallback (``step_count`` / ``channel_count``) so the
        shell-side fallback in statCardHtml has somewhere to land. If a
        future edit drops these keys, the fix becomes a no-op.
        """
        html = list(await server.read_resource("ui://sequences/detail"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        # Both stat cards still declare both template and key.
        assert '"template":"{steps.length}"' in normalized
        assert '"key":"step_count"' in normalized
        assert '"template":"{channels.length}"' in normalized
        assert '"key":"channel_count"' in normalized

    # --- Fix 3: empty_when_key gate on detail views --------------------

    def test_shell_detail_view_honors_empty_when_key(self):
        """The shell's ``renderCurrent`` block for ``view.type ===
        'detail'`` must consult ``view.empty_when_key`` and treat a null
        sentinel as empty. Without this, Pydantic-typed payloads that
        come back all-null still render the wall of dashes.
        """
        from g8_mcp_server.ui_apps import load_bundle

        html = load_bundle("shell")
        assert "view.empty_when_key" in html, (
            "shell.html renderCurrent must consult view.empty_when_key"
        )

    @pytest.mark.asyncio
    async def test_sequence_detail_view_declares_empty_when_key(
        self, server: FastMCP
    ):
        """``ui://sequences/detail`` must opt into the empty_when_key
        gate so all-null sequence previews (drafts, no preview yet)
        render the empty-text fallback instead of a wall of dashes.
        """
        html = list(await server.read_resource("ui://sequences/detail"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"empty_when_key":"id"' in normalized, (
            "sequences/detail must declare empty_when_key='id'"
        )
        # And the empty_text must be informative enough that a user can
        # tell it apart from "Not found" (which is the shell default).
        assert "Sequence preview unavailable" in html

    @pytest.mark.asyncio
    async def test_other_detail_views_unchanged_by_empty_when_key(
        self, server: FastMCP
    ):
        """Backwards compat: detail views that haven't opted in must NOT
        carry an empty_when_key in their view-config JSON. The legacy
        zero-keys empty check is the right behavior for them.

        We pull the actual JSON config block out of the rendered HTML so
        we don't false-match on the shell.html comment that explains the
        feature.
        """
        import re

        # contacts/detail and companies/detail both come back populated
        # from real lookup tools - they shouldn't gate on a sentinel.
        for uri in ("ui://contacts/detail", "ui://companies/detail"):
            html = list(await server.read_resource(uri))[0].content
            assert isinstance(html, str)
            m = re.search(
                r'<script[^>]*id="mcp-app-view-config"[^>]*>(.*?)</script>',
                html,
                re.DOTALL,
            )
            assert m, f"{uri}: missing mcp-app-view-config JSON block"
            cfg_json = m.group(1)
            assert '"empty_when_key"' not in cfg_json, (
                f"{uri}: did not opt in to empty_when_key, must stay unchanged"
            )

    # --- Fix 4: SequenceChannel.channel_id type drift ------------------
    #
    # Backend (developer_api/interfaces/dtos/sequences.py:108) declares
    # PreviewChannelItem.channel_id as Optional[int] because the underlying
    # SeqSequenceChannel.channel_id column is Integer. The MCP-side model
    # previously declared it as ``str | None`` which caused Pydantic to
    # raise ValidationError on every live sequence preview that had at
    # least one mailbox channel attached. ``safe_call_typed`` swallowed
    # the error and returned a JSON-formatted string, FastMCP wrapped that
    # under ``{result: "<string>"}``, and the widget's
    # ``empty_when_key: "id"`` sentinel saw no top-level ``id`` and
    # rendered the "Sequence preview unavailable" fallback for every
    # drill-in. This locks in the int-aware type so the failure mode
    # cannot silently come back.

    def test_sequence_channel_accepts_int_channel_id_from_backend(self):
        """``SequenceChannel.channel_id`` must accept the integer the
        backend actually returns. Regression: pre-fix, an int would raise
        ``ValidationError`` and cascade into the empty-text fallback for
        every drill-in.
        """
        from g8_mcp_server.models import SequenceChannel

        ch = SequenceChannel.model_validate(
            {
                "id": "ch_1",
                "channel_id": 221,  # int — production reality
                "channel_value": "alice@example.com",
                "channel_type": "mailbox",
            }
        )
        assert ch.id == "ch_1"
        assert ch.channel_id == 221
        assert ch.channel_value == "alice@example.com"
        assert ch.channel_type == "mailbox"

    def test_sequence_channel_still_accepts_str_channel_id(self):
        """Backwards compat: a string ``channel_id`` must continue to
        validate so any existing fixtures, callers, or alternate upstream
        sources that pre-coerce to string keep working.
        """
        from g8_mcp_server.models import SequenceChannel

        ch = SequenceChannel.model_validate(
            {
                "id": "ch_1",
                "channel_id": "cid_legacy",
                "channel_value": "x@y.com",
                "channel_type": "mailbox",
            }
        )
        assert ch.channel_id == "cid_legacy"

    def test_sequence_preview_from_envelope_with_int_channel_ids(self):
        """End-to-end: a backend-shaped envelope with integer
        ``channel_id`` values must produce a populated ``SequencePreview``
        — not a ``ValidationError`` that ``safe_call_typed`` would
        downgrade to a fallback string.

        This is the exact regression observed in pod g8-7c8c76d8cd-8cz2d:
        20 channels per sequence, all with int channel_ids, every
        validation failing on the same ``channel_id`` field.
        """
        from g8_mcp_server.models import SequencePreview

        envelope = {
            "data": {
                "id": "bafe30a4-47c1-4365-803d-5bbb98789855",
                "name": "C7_API-First_Infrastructure_Tech_and_RevOps_Leaders",
                "status": "paused",
                "description": "3-touch outbound sequence.",
                "steps": [
                    {
                        "id": "step_1",
                        "step_order": 1,
                        "step_type": "email",
                        "input_type": "manual",
                        "time_interval": 0,
                    },
                ],
                "channels": [
                    {
                        "id": "ch_1",
                        "channel_id": 221,
                        "channel_value": "sender@graph8.com",
                        "channel_type": "mailbox",
                    },
                    {
                        "id": "ch_2",
                        "channel_id": 222,
                        "channel_value": "sender2@graph8.com",
                        "channel_type": "mailbox",
                    },
                ],
            }
        }

        preview = SequencePreview.from_envelope(envelope)

        # The id must survive — this is what the empty_when_key sentinel
        # in _sequence_detail_view (resources.py:329) reads to decide
        # whether to render the fallback text.
        assert preview.id == "bafe30a4-47c1-4365-803d-5bbb98789855"
        assert preview.name == "C7_API-First_Infrastructure_Tech_and_RevOps_Leaders"
        assert preview.status == "paused"
        assert len(preview.channels) == 2
        assert preview.channels[0].channel_id == 221
        assert preview.channels[1].channel_id == 222
        assert len(preview.steps) == 1
        assert preview.steps[0].step_order == 1


# ---------------------------------------------------------------------------
# Wave 3 confirmation widgets + voice/dialer surface widgets.
#
# These tests cover the additive widgets:
#   - Six ui://confirmations/* widgets driven by tools/dry_run=True previews
#   - Three ui://dialer/* + ui://voice/* widgets for the voice tool surface
#
# All checks are additive: the existing widgets and tool wiring must remain
# untouched. ConfirmationPreview must subclass ActionResult so existing
# return-type annotations remain valid.
# ---------------------------------------------------------------------------


class TestConfirmationPreviewModel:
    """ConfirmationPreview is a thin payload returned by every wave-3 tool
    when called with dry_run=True. It must subclass ActionResult so existing
    `ActionResult | str` return type hints continue to validate.
    """

    def test_subclasses_action_result(self):
        from g8_mcp_server.models import ActionResult, ConfirmationPreview

        assert issubclass(ConfirmationPreview, ActionResult)

    def test_round_trips_with_required_fields(self):
        from g8_mcp_server.models import ConfirmationDetail, ConfirmationPreview

        preview = ConfirmationPreview(
            action_label="Save list",
            summary="Save up to 100 contacts.",
            details=[ConfirmationDetail(label="Max", value="100")],
            warning="Charges credits.",
            cost_label="Up to 100 credits",
            confirm_tool="g8_create_list",
            confirm_args={"max_results": 100, "dry_run": False},
            confirm_label="Save",
            cancel_label="Cancel",
        )
        dumped = preview.model_dump()
        assert dumped["preview"] is True
        assert dumped["confirm_tool"] == "g8_create_list"
        assert dumped["confirm_args"]["dry_run"] is False
        assert dumped["details"][0]["label"] == "Max"

    def test_default_preview_flag_is_true(self):
        """The widget reads `preview: True` to dispatch a ConfirmationPreview
        through the __self__ branch in shell.html. If this default flips, the
        widget would silently render the wrong view.
        """
        from g8_mcp_server.models import ConfirmationPreview

        preview = ConfirmationPreview()
        assert preview.preview is True

    def test_extra_fields_ignored_for_back_compat(self):
        """ActionResult is `extra=allow`. ConfirmationPreview extends it; if
        a future tool adds fields, model_validate must not reject them."""
        from g8_mcp_server.models import ConfirmationPreview

        preview = ConfirmationPreview.model_validate(
            {
                "preview": True,
                "summary": "Test",
                "future_field": "still works",
            }
        )
        # The base allow=extras applies, so the new field round-trips.
        assert preview.summary == "Test"


class TestWave3ConfirmationWidgets:
    """Confirmation widgets (Wave 3) are credit/send guardrails. Each one
    is a `ui://confirmations/<topic>` resource with a single root view of
    type `confirmation` and `data_path: "__self__"`. All must be
    registered, mime-typed correctly, and linked from their source tool via
    `_meta.ui.resourceUri`.
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import gtm as gtm_mod
        from g8_mcp_server.tools import platform as platform_mod
        from g8_mcp_server.tools import voice as voice_mod

        server = FastMCP("test-wave3-confirmations")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        platform_mod.register(server, client)
        gtm_mod.register(server, client, name_prefix="gtm")
        voice_mod.register(server, client)
        return server

    @pytest.mark.asyncio
    async def test_all_confirmation_widgets_registered(self, server: FastMCP):
        confirmation_uris = (
            "ui://confirmations/create-list",
            "ui://confirmations/add-to-list",
            "ui://confirmations/enrich-contacts",
            "ui://confirmations/add-to-sequence",
            "ui://confirmations/launch-campaign",
            "ui://confirmations/create-dialer-session",
            "ui://confirmations/stop-dialer-session",
        )
        resources = await server.list_resources()
        by_uri = {str(r.uri): r for r in resources}
        for uri in confirmation_uris:
            assert uri in by_uri, f"missing confirmation widget: {uri}"
            assert by_uri[uri].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}"
            )

    @pytest.mark.asyncio
    async def test_confirmation_widget_uses_confirmation_view_type(
        self, server: FastMCP
    ):
        """Every confirmation widget must use type=confirmation with the
        __self__ data path so the structuredContent payload (the dry-run
        preview) flows through shell.html's confirmation dispatcher.
        """
        for uri in (
            "ui://confirmations/create-list",
            "ui://confirmations/add-to-list",
            "ui://confirmations/enrich-contacts",
            "ui://confirmations/add-to-sequence",
            "ui://confirmations/launch-campaign",
            "ui://confirmations/create-dialer-session",
            "ui://confirmations/stop-dialer-session",
        ):
            html = list(await server.read_resource(uri))[0].content
            assert isinstance(html, str)
            normalized = html.replace(" ", "")
            assert '"type":"confirmation"' in normalized, (
                f"{uri}: root view must be type=confirmation"
            )
            assert '"data_path":"__self__"' in normalized, (
                f"{uri}: confirmation view must use the __self__ dispatch sentinel"
            )

    @pytest.mark.asyncio
    async def test_wave3_tools_link_to_confirmation_widgets(self, server: FastMCP):
        """The wave-3 tools must declare _meta.ui.resourceUri pointing
        at their confirmation widget so the model knows which UI surface to
        render when calling with dry_run=True.
        """
        expected = {
            "g8_create_list": "ui://confirmations/create-list",
            "g8_add_to_list": "ui://confirmations/add-to-list",
            "g8_enrich_contacts": "ui://confirmations/enrich-contacts",
            "g8_add_to_sequence": "ui://confirmations/add-to-sequence",
            "g8_gtm_launch_campaign": "ui://confirmations/launch-campaign",
            "g8_voice_create_dialer_session": "ui://confirmations/create-dialer-session",
            "g8_voice_stop_session": "ui://confirmations/stop-dialer-session",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} not registered"
            tool = tools[name]
            assert tool.meta is not None, f"tool {name!r} has no _meta"
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta.ui.resourceUri = {actual!r}, "
                f"expected {expected_uri!r}"
            )

    @pytest.mark.asyncio
    async def test_wave3_tools_accept_dry_run_argument(self, server: FastMCP):
        """All wave-3 tools must accept the dry_run boolean parameter.
        Backwards-compat: dry_run defaults to False so existing call sites
        keep their original semantics.
        """
        expected_tools = (
            "g8_create_list",
            "g8_add_to_list",
            "g8_enrich_contacts",
            "g8_add_to_sequence",
            "g8_gtm_launch_campaign",
            "g8_voice_create_dialer_session",
            "g8_voice_stop_session",
        )
        tools = {t.name: t for t in await server.list_tools()}
        for name in expected_tools:
            assert name in tools, f"tool {name!r} missing"
            schema = tools[name].inputSchema or {}
            props = schema.get("properties") or {}
            assert "dry_run" in props, f"tool {name!r} missing dry_run param"
            # Defaults must be False (back-compat: existing callers keep
            # the original execute-now behaviour).
            assert props["dry_run"].get("default") is False, (
                f"tool {name!r} dry_run default is not False"
            )

    def test_create_list_dry_run_returns_preview_for_filters(self):
        """Smoke test: g8_create_list(filters=..., dry_run=True) returns a
        ConfirmationPreview without ever touching the network. This is the
        credit-spending path so the dry-run preview is mandatory.
        """
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.models import ConfirmationPreview
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-dry-run")
        client = G8Client(require_key=False)
        platform_mod.register(server, client)

        async def _call() -> object:
            tools = await server.list_tools()
            assert any(t.name == "g8_create_list" for t in tools)
            tm = server._tool_manager
            tool = tm._tools["g8_create_list"]
            fn = tool.fn
            return await fn(
                title="X",
                filters=[{"field": "seniority_level", "operator": "any_of", "value": ["VP"]}],
                max_results=5,
                dry_run=True,
            )

        result = asyncio.run(_call())
        assert isinstance(result, ConfirmationPreview)
        assert result.preview is True
        assert result.confirm_tool == "g8_create_list"
        # confirm_args carries dry_run=False so the second call actually executes.
        assert result.confirm_args.get("dry_run") is False
        assert result.confirm_args.get("max_results") == 5
        assert result.confirm_args.get("filters")

    def test_create_list_dry_run_returns_preview_for_rows(self):
        """g8_create_list(rows=..., dry_run=True) returns a free-cost preview.
        Rows mode is free (no enrichment credits) but still warrants a preview
        so the user sees what's about to be imported.
        """
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.models import ConfirmationPreview
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-dry-run-rows")
        client = G8Client(require_key=False)
        platform_mod.register(server, client)

        async def _call() -> object:
            tm = server._tool_manager
            tool = tm._tools["g8_create_list"]
            fn = tool.fn
            return await fn(
                title="Curated",
                rows=[
                    {"work_email": "a@example.com", "first_name": "A"},
                    {"work_email": "b@example.com", "first_name": "B"},
                ],
                dry_run=True,
            )

        result = asyncio.run(_call())
        assert isinstance(result, ConfirmationPreview)
        assert result.confirm_tool == "g8_create_list"
        assert result.cost_label == "No enrichment credits"
        assert result.confirm_args.get("dry_run") is False
        assert len(result.confirm_args.get("rows") or []) == 2

    def test_create_list_rejects_multiple_source_modes(self):
        """At-most-one source enforcement: passing both filters and rows
        should return a clear error string rather than silently picking one.
        """
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-multi-source")
        client = G8Client(require_key=False)
        platform_mod.register(server, client)

        async def _call() -> object:
            tm = server._tool_manager
            tool = tm._tools["g8_create_list"]
            fn = tool.fn
            return await fn(
                title="X",
                filters=[{"field": "seniority_level", "operator": "any_of", "value": ["VP"]}],
                rows=[{"work_email": "a@example.com"}],
                dry_run=True,
            )

        result = asyncio.run(_call())
        assert isinstance(result, str)
        assert "at most one" in result.lower()

    def test_add_to_list_requires_a_source(self):
        """g8_add_to_list with no source must fail loudly. An empty add is
        meaningless and the tool should return an error rather than silently
        no-oping."""
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-add-empty")
        client = G8Client(require_key=False)
        platform_mod.register(server, client)

        async def _call() -> object:
            tm = server._tool_manager
            tool = tm._tools["g8_add_to_list"]
            fn = tool.fn
            return await fn(list_id=42, dry_run=True)

        result = asyncio.run(_call())
        assert isinstance(result, str)
        assert "requires" in result.lower()

    def test_add_to_list_dry_run_returns_preview_for_rows(self):
        """g8_add_to_list(rows=..., dry_run=True) returns a preview so the
        user sees how many records will be imported into the target list."""
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.models import ConfirmationPreview
        from g8_mcp_server.tools import platform as platform_mod

        server = FastMCP("test-add-rows")
        client = G8Client(require_key=False)
        platform_mod.register(server, client)

        async def _call() -> object:
            tm = server._tool_manager
            tool = tm._tools["g8_add_to_list"]
            fn = tool.fn
            return await fn(
                list_id=42,
                rows=[{"work_email": "a@example.com"}],
                dry_run=True,
            )

        result = asyncio.run(_call())
        assert isinstance(result, ConfirmationPreview)
        assert result.confirm_tool == "g8_add_to_list"
        assert result.confirm_args.get("list_id") == 42
        assert result.confirm_args.get("dry_run") is False


class TestVoiceDialerWidgets:
    """Three voice/dialer widgets surface dialer state in chat:
      - ui://dialer/sessions   -> g8_voice_list_dialer_sessions
      - ui://dialer/stats      -> g8_voice_get_dialer_stats
      - ui://voice/agents      -> g8_voice_list_agents

    The sessions widget also bakes pause/resume/stop card actions in.
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import voice as voice_mod

        server = FastMCP("test-voice-widgets")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        voice_mod.register(server, client)
        return server

    @pytest.mark.asyncio
    async def test_voice_widgets_registered(self, server: FastMCP):
        voice_uris = (
            "ui://dialer/sessions",
            "ui://dialer/stats",
            "ui://voice/agents",
        )
        resources = await server.list_resources()
        by_uri = {str(r.uri): r for r in resources}
        for uri in voice_uris:
            assert uri in by_uri, f"missing voice widget: {uri}"
            assert by_uri[uri].mimeType == "text/html;profile=mcp-app", (
                f"wrong mime type for {uri}"
            )

    @pytest.mark.asyncio
    async def test_voice_read_tools_link_to_widgets(self, server: FastMCP):
        expected = {
            "g8_voice_list_dialer_sessions": "ui://dialer/sessions",
            "g8_voice_get_dialer_stats": "ui://dialer/stats",
            "g8_voice_list_agents": "ui://voice/agents",
            # Pause/resume refresh the same sessions widget.
            "g8_voice_pause_session": "ui://dialer/sessions",
            "g8_voice_resume_session": "ui://dialer/sessions",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} not registered"
            tool = tools[name]
            assert tool.meta is not None, f"tool {name!r} has no _meta"
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta.ui.resourceUri = {actual!r}, "
                f"expected {expected_uri!r}"
            )

    @pytest.mark.asyncio
    async def test_dialer_sessions_widget_has_lifecycle_actions(
        self, server: FastMCP
    ):
        """The sessions card grid declares pause / resume / stop card
        actions. Their tool names must match the registered voice tools so a
        click actually fires the right MCP call.
        """
        html = list(await server.read_resource("ui://dialer/sessions"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"type":"card_grid"' in normalized
        assert '"data_path":"sessions"' in normalized
        # The three card actions must be wired by tool name.
        assert '"tool":"g8_voice_pause_session"' in normalized
        assert '"tool":"g8_voice_resume_session"' in normalized
        assert '"tool":"g8_voice_stop_session"' in normalized
        # Resume + stop are destructive -> must declare a confirm modal.
        assert '"confirm":' in normalized

    @pytest.mark.asyncio
    async def test_dialer_stats_widget_uses_detail_view(self, server: FastMCP):
        html = list(await server.read_resource("ui://dialer/stats"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"type":"detail"' in normalized
        assert '"data_path":"__self__"' in normalized

    @pytest.mark.asyncio
    async def test_voice_agents_widget_uses_card_grid(self, server: FastMCP):
        html = list(await server.read_resource("ui://voice/agents"))[0].content
        assert isinstance(html, str)
        normalized = html.replace(" ", "")
        assert '"type":"card_grid"' in normalized
        assert '"data_path":"agents"' in normalized

    def test_voice_dry_run_returns_dict_preview(self):
        """create_dialer_session and stop_session return dicts (not pydantic
        objects) when dry_run=True so the existing `dict[str, Any] | str`
        return type stays valid. The dict must carry the canonical
        ConfirmationPreview keys so the widget's __self__ dispatch fires.
        """
        import asyncio

        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import voice as voice_mod

        server = FastMCP("test-voice-dry-run")
        client = G8Client(require_key=False)
        voice_mod.register(server, client)

        async def _call_create() -> object:
            tm = server._tool_manager
            fn = tm._tools["g8_voice_create_dialer_session"].fn
            return await fn(
                name="Tuesday cold dial",
                from_phone="+15551234567",
                list_id="L1",
                agent_id="A1",
                dry_run=True,
            )

        async def _call_stop() -> object:
            tm = server._tool_manager
            fn = tm._tools["g8_voice_stop_session"].fn
            return await fn(session_id="S1", dry_run=True)

        create_result = asyncio.run(_call_create())
        assert isinstance(create_result, dict)
        assert create_result.get("preview") is True
        assert create_result.get("confirm_tool") == "g8_voice_create_dialer_session"
        assert create_result.get("confirm_args", {}).get("dry_run") is False

        stop_result = asyncio.run(_call_stop())
        assert isinstance(stop_result, dict)
        assert stop_result.get("preview") is True
        assert stop_result.get("confirm_tool") == "g8_voice_stop_session"
        assert stop_result.get("confirm_args", {}).get("dry_run") is False
        assert stop_result.get("confirm_args", {}).get("session_id") == "S1"


class TestWave3BackCompat:
    """Hard back-compat sentinel: wave-3 + voice changes are additive only.
    Existing widgets, tools, and legacy g8:// resources MUST stay registered
    and unchanged. This test runs every prior assertion in one place so a
    single regression line surfaces here loudly.
    """

    @pytest.fixture
    def server(self) -> FastMCP:
        from g8_mcp_server import resources as resources_mod
        from g8_mcp_server.client import G8Client
        from g8_mcp_server.tools import gtm as gtm_mod
        from g8_mcp_server.tools import inbox as inbox_mod
        from g8_mcp_server.tools import platform as platform_mod
        from g8_mcp_server.tools import sync as sync_mod
        from g8_mcp_server.tools import voice as voice_mod

        server = FastMCP("test-wave3-back-compat")
        client = G8Client(require_key=False)
        resources_mod.register(server, client)
        platform_mod.register(server, client)
        inbox_mod.register(server, client)
        sync_mod.register(server, client)
        gtm_mod.register(server, client, name_prefix="gtm")
        voice_mod.register(server, client)
        return server

    @pytest.mark.asyncio
    async def test_existing_resources_still_present(self, server: FastMCP):
        """Every previously-registered resource must still exist."""
        resources = await server.list_resources()
        uris = {str(r.uri) for r in resources}
        for uri in (
            "ui://campaigns/dashboard",
            "ui://campaigns/ad-images",
            "ui://contacts/list",
            "ui://contacts/detail",
            "ui://companies/list",
            "ui://companies/detail",
            "ui://inbox/list",
            "ui://inbox/thread",
            "ui://lists/list",
            "ui://sequences/list",
            "ui://sequences/detail",
            "ui://deals/list",
            "ui://deals/detail",
            "ui://tasks/list",
            "ui://activities/list",
            "ui://audience-syncs/list",
            "ui://crm-syncs/list",
            "ui://personas/list",
            "ui://icps/list",
            "g8://campaigns/dashboard",  # legacy g8:// resource still alive
        ):
            assert uri in uris, f"back-compat regression: missing {uri}"

    @pytest.mark.asyncio
    async def test_existing_tool_meta_unchanged(self, server: FastMCP):
        """Pre-existing tool->resourceUri mappings must NOT have been
        rewired by the wave-3 additions. We spot-check the ones most
        likely to drift (shared widgets across multiple tools).
        """
        expected = {
            "g8_gtm_list_campaigns": "ui://campaigns/dashboard",
            "g8_gtm_get_ad_images": "ui://campaigns/ad-images",
            "g8_gtm_hide_ad_image": "ui://campaigns/ad-images",
            "g8_search_contacts": "ui://contacts/list",
            "g8_get_contact_detail": "ui://contacts/detail",
            "g8_lookup_company": "ui://companies/detail",
            "g8_get_sequence_preview": "ui://sequences/detail",
        }
        tools = {t.name: t for t in await server.list_tools()}
        for name, expected_uri in expected.items():
            assert name in tools, f"tool {name!r} disappeared"
            tool = tools[name]
            assert tool.meta is not None
            actual = tool.meta.get("ui", {}).get("resourceUri")
            assert actual == expected_uri, (
                f"tool {name!r} meta drifted: now {actual!r}, "
                f"expected {expected_uri!r}"
            )

    @pytest.mark.asyncio
    async def test_voice_lifecycle_tools_still_callable_without_dry_run(
        self, server: FastMCP
    ):
        """create_dialer_session and stop_session keep their original
        signature - dry_run is optional (default False), so the original
        callers continue to work unchanged.
        """
        tools = {t.name: t for t in await server.list_tools()}
        for name in ("g8_voice_create_dialer_session", "g8_voice_stop_session"):
            schema = tools[name].inputSchema or {}
            required = set(schema.get("required") or [])
            # dry_run must NOT be required - it has a default.
            assert "dry_run" not in required, (
                f"tool {name!r} now requires dry_run - back-compat broken"
            )
