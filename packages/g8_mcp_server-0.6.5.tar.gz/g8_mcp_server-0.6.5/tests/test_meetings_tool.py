"""Unit tests for the meetings MCP tools (g8_list_meetings, g8_get_meeting).

Covers:
  - Tool registration on the meetings registrar
  - URL + params construction for list endpoint
  - participant_email repeated query param formation (the wire shape
    FastAPI's ``Query(list[str])`` parser expects)
  - email + contact_id resolution into participant_emails
  - case-insensitive de-dup of resolved emails
  - Detail tool hits the correct path
  - MeetingListResult / MeetingDetail envelope parsing

These exercises stub ``G8Client.get`` so we don't need an actual HTTP
server. The function objects are introspected from the FastMCP
``_tool_manager._tools`` map exactly like ``test_tools.py`` does so the
pattern matches the rest of the suite.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import MeetingDetail, MeetingListResult


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_meetings")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(
        client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json")
    )


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_meetings_tools(client):
    """Register meetings tools on a fresh FastMCP server and return tool map."""
    from mcp.server import FastMCP

    from g8_mcp_server.tools import meetings

    server = FastMCP("test")
    meetings.register(server, client)
    return server, server._tool_manager._tools


# ---------------------------------------------------------------------------
# Registration / surface contract
# ---------------------------------------------------------------------------


class TestMeetingsRegistration:
    def test_list_meetings_registered(self, client):
        _, tools = _register_meetings_tools(client)
        assert "g8_list_meetings" in tools

    def test_get_meeting_registered(self, client):
        _, tools = _register_meetings_tools(client)
        assert "g8_get_meeting" in tools

    def test_list_meetings_in_always_on_set(self):
        """The list tool must be discoverable without a tool_search activation
        because "show me meetings" is a foundational question. Detail is gated
        behind tool_search so we keep the catalog compact."""
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS

        assert "g8_list_meetings" in _ALWAYS_ON_TOOLS
        # g8_get_meeting is intentionally NOT always-on; agents reach it
        # after g8_list_meetings narrows the surface.

    def test_both_tools_have_read_only_annotations(self, client):
        """Meetings tools are read-only / idempotent — locks the contract
        so a future refactor cannot accidentally drop the annotation."""
        server, tools = _register_meetings_tools(client)
        for name in ("g8_list_meetings", "g8_get_meeting"):
            ann = tools[name].annotations
            assert ann is not None, f"{name} missing ToolAnnotations"
            assert ann.readOnlyHint is True
            assert ann.idempotentHint is True


# ---------------------------------------------------------------------------
# g8_list_meetings — endpoint + parameter wiring
# ---------------------------------------------------------------------------


class TestListMeetingsCall:
    @pytest.mark.asyncio
    async def test_no_filters_hits_meetings_endpoint(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [],
                "pagination": {"page": 1, "limit": 50, "total": 0, "has_next": False},
            }
        )

        result = await fn()

        # Endpoint must be /inbox/meetings (relative to the developer_api base).
        client.get.assert_called_once()
        args = client.get.call_args.args
        assert args[0] == "/inbox/meetings"
        # No participant_email key when nothing was passed in.
        params = args[1]
        assert "participant_email" not in params
        # Pagination defaults flow through.
        assert params["page"] == 1
        assert params["page_size"] == 50

        # Typed result, no fallback string.
        assert isinstance(result, MeetingListResult)
        assert result.meetings == []
        assert result.total == 0

    @pytest.mark.asyncio
    async def test_email_arg_forwards_as_participant_email_list(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(email="alice@example.com")

        params = client.get.call_args.args[1]
        # httpx serializes list values as repeated keys — match FastAPI Query(list[str]).
        assert params["participant_email"] == ["alice@example.com"]

    @pytest.mark.asyncio
    async def test_explicit_participant_emails_used_verbatim(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(participant_emails=["bob@x.com", "carol@x.com"])

        params = client.get.call_args.args[1]
        assert params["participant_email"] == ["bob@x.com", "carol@x.com"]

    @pytest.mark.asyncio
    async def test_email_plus_participant_emails_combined(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            email="alice@example.com",
            participant_emails=["bob@x.com"],
        )

        params = client.get.call_args.args[1]
        # Order is preserved: explicit list first, single email appended.
        assert params["participant_email"] == ["bob@x.com", "alice@example.com"]

    @pytest.mark.asyncio
    async def test_dedupes_emails_case_insensitively(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            email="ALICE@example.com",
            participant_emails=["alice@example.com", "Bob@X.com", "BOB@x.com"],
        )

        params = client.get.call_args.args[1]
        # First-seen casing wins, duplicates dropped.
        assert params["participant_email"] == ["alice@example.com", "Bob@X.com"]

    @pytest.mark.asyncio
    async def test_contact_id_resolves_to_work_email(self, client):
        """contact_id -> GET /contacts/{id} -> extract work_email -> add to
        participant filter. The lookup is a single extra round-trip."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        async def fake_get(path, params=None):
            if path == "/contacts/42":
                return {"data": {"id": 42, "work_email": "found@example.com"}}
            if path == "/inbox/meetings":
                return {"data": [], "pagination": {}}
            raise AssertionError(f"unexpected GET {path}")

        client.get = AsyncMock(side_effect=fake_get)
        await fn(contact_id=42)

        # Two GETs: contact lookup + meetings list.
        assert client.get.call_count == 2
        meetings_call = client.get.call_args_list[1]
        assert meetings_call.args[0] == "/inbox/meetings"
        assert meetings_call.args[1]["participant_email"] == ["found@example.com"]

    @pytest.mark.asyncio
    async def test_contact_id_lookup_failure_falls_back_to_other_filters(self, client):
        """If the contact lookup raises (404, network error, etc.) we don't
        bubble the failure — we just skip the contact-derived email and
        continue with whatever else the caller provided."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        async def fake_get(path, params=None):
            if path == "/contacts/9999":
                raise Exception("404 not found")
            if path == "/inbox/meetings":
                return {"data": [], "pagination": {}}
            raise AssertionError(f"unexpected GET {path}")

        client.get = AsyncMock(side_effect=fake_get)
        result = await fn(contact_id=9999, email="fallback@example.com")

        # Still calls the meetings endpoint with the fallback email only.
        meetings_call = client.get.call_args_list[-1]
        assert meetings_call.args[0] == "/inbox/meetings"
        assert meetings_call.args[1]["participant_email"] == ["fallback@example.com"]
        assert isinstance(result, MeetingListResult)

    @pytest.mark.asyncio
    async def test_filter_params_flow_through(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            scope="all",
            timeframe="upcoming",
            has_transcript=True,
            search="Q4 review",
            page=2,
            page_size=25,
        )

        params = client.get.call_args.args[1]
        assert params["scope"] == "all"
        assert params["timeframe"] == "upcoming"
        assert params["has_transcript"] is True
        assert params["search"] == "Q4 review"
        assert params["page"] == 2
        assert params["page_size"] == 25


# ---------------------------------------------------------------------------
# g8_list_meetings — envelope parsing
# ---------------------------------------------------------------------------


class TestListMeetingsResultShape:
    @pytest.mark.asyncio
    async def test_parses_summary_envelope(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "m1",
                        "subject": "Kickoff",
                        "organizer_email": "alice@example.com",
                        "user_email": "alice@example.com",
                        "transcript_status": "linked",
                        "transcript_summary": "Short preview text.",
                        "attendees": [
                            {"email": "bob@external.com", "name": "Bob"},
                        ],
                    },
                    {
                        "id": "m2",
                        "subject": "Followup",
                        "transcript_status": "none",
                    },
                ],
                "pagination": {"page": 1, "limit": 50, "total": 2, "has_next": False},
            }
        )

        result = await fn()

        assert isinstance(result, MeetingListResult)
        assert len(result.meetings) == 2
        assert result.meetings[0].subject == "Kickoff"
        assert result.meetings[0].transcript_summary == "Short preview text."
        assert result.meetings[0].attendees[0].email == "bob@external.com"
        assert result.total == 2
        assert result.has_next is False

    @pytest.mark.asyncio
    async def test_summary_drops_transcript_text(self, client):
        """List endpoint must not leak full transcript body even if the
        backend mistakenly returns it — MeetingSummary ignores the field."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "m1",
                        "subject": "Big meeting",
                        "transcript_text": "FULL BODY THAT SHOULD NOT APPEAR",
                    }
                ],
                "pagination": {},
            }
        )

        result = await fn()
        summary = result.meetings[0]
        # MeetingSummary has no transcript_text attribute; model_dump
        # confirms it's been stripped from the structured output.
        dumped = summary.model_dump()
        assert "transcript_text" not in dumped


# ---------------------------------------------------------------------------
# g8_get_meeting — detail endpoint
# ---------------------------------------------------------------------------


class TestGetMeetingCall:
    @pytest.mark.asyncio
    async def test_hits_detail_path(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={"data": {"id": "42", "subject": "Test", "channel": "meetings"}}
        )

        result = await fn(meeting_id="42")

        client.get.assert_called_once_with("/inbox/meetings/42")
        assert isinstance(result, MeetingDetail)
        assert result.id == "42"

    @pytest.mark.asyncio
    async def test_returns_full_transcript_bundled(self, client):
        """Detail tool is the ONE place full transcript_text is exposed —
        bundled approach (Option A) means callers don't have to make a
        second round-trip."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "id": "42",
                    "subject": "Q4 review",
                    "transcript_status": "linked",
                    "transcript_text": "Full transcript body. Many words.",
                    "transcript_summary": "Short.",
                    "transcript_redacted": False,
                    "attendees": [
                        {"email": "bob@external.com", "name": "Bob"},
                        {
                            "email": "alice@example.com",
                            "name": "Alice",
                            "organizer": True,
                        },
                    ],
                    "key_topics": ["pricing", "renewal"],
                    "action_items": [{"text": "Follow up Thursday"}],
                }
            }
        )

        result = await fn(meeting_id="42")

        assert isinstance(result, MeetingDetail)
        assert result.transcript_text == "Full transcript body. Many words."
        assert result.transcript_summary == "Short."
        assert result.transcript_redacted is False
        assert result.key_topics == ["pricing", "renewal"]
        assert any(a.organizer for a in result.attendees)

    @pytest.mark.asyncio
    async def test_respects_redaction(self, client):
        """When transcript_redacted=true the body is None — the wrapper
        passes the flag through so the agent knows why content is missing."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "id": "42",
                    "subject": "Internal sync",
                    "transcript_status": "linked",
                    "transcript_text": None,
                    "transcript_summary": None,
                    "transcript_redacted": True,
                    "transcript_id": "t-123",
                }
            }
        )

        result = await fn(meeting_id="42")
        assert result.transcript_redacted is True
        assert result.transcript_text is None
        # Status / IDs remain visible so the agent can explain why.
        assert result.transcript_status == "linked"
        assert result.transcript_id == "t-123"


# ---------------------------------------------------------------------------
# Helper: _extract_contact_email — keeps the contact-lookup tolerant of
# envelope shapes the contacts endpoint may emit.
# ---------------------------------------------------------------------------


class TestExtractContactEmail:
    def test_prefers_work_email(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        envelope = {
            "data": {
                "id": 1,
                "work_email": "work@example.com",
                "email": "other@example.com",
            }
        }
        assert _extract_contact_email(envelope) == "work@example.com"

    def test_falls_back_to_email(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert (
            _extract_contact_email({"data": {"email": "x@example.com"}})
            == "x@example.com"
        )

    def test_bare_dict_no_envelope(self):
        """Some endpoints return a bare contact dict instead of an
        ApiResponse envelope — accept both."""
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert (
            _extract_contact_email({"work_email": "bare@example.com"})
            == "bare@example.com"
        )

    def test_returns_none_for_garbage(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert _extract_contact_email(None) is None
        assert _extract_contact_email("not a dict") is None
        assert _extract_contact_email({"data": "not a dict"}) is None
        assert _extract_contact_email({}) is None

    def test_skips_blank_values(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        # Blank work_email shouldn't beat a populated `email`.
        envelope = {"data": {"work_email": "   ", "email": "real@example.com"}}
        assert _extract_contact_email(envelope) == "real@example.com"
