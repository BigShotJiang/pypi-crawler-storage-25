"""Tests for the playbooks tool family (renamed from "skills" in v0.6.3).

Prior state (pre-0.6.3): tools were `g8_list_skills` / `g8_load_skill` with
`Skill*Result` Pydantic models. Renamed to `g8_list_playbooks` /
`g8_load_playbook` (and `Playbook*Result` models) to disambiguate from the
unrelated `g8_skill_*` / `g8_workflow_skill_*` tool family that authors
graph8 skill records used by workflow Action nodes.

Both tools return Pydantic `Model | str` unions so the agent sees typed
fields without re-parsing, matching the rest of the MCP surface.

These tests lock:
- The tool signatures resolve to the expected Pydantic models.
- Happy-path returns are valid model instances (not strings).
- Error-path returns are plain strings (the `str` branch of the union).
- Model field shapes match `PLAYBOOKS_CATALOG` and `get_playbook_content`.
- The pre-0.6.3 names (`g8_list_skills`, `g8_load_skill`, `Skill*Result`)
  do NOT exist anywhere — guarded explicitly to catch accidental
  re-introduction.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.models import (
    PlaybookContentResult,
    PlaybookMetadata,
    PlaybooksCatalogResult,
)
from g8_mcp_server.playbooks import PLAYBOOKS_CATALOG


class TestPlaybooksCatalogResultModel:
    def test_from_entries_builds_typed_catalog(self):
        result = PlaybooksCatalogResult.from_entries(list(PLAYBOOKS_CATALOG))
        assert isinstance(result, PlaybooksCatalogResult)
        assert result.total == len(PLAYBOOKS_CATALOG)
        assert len(result.playbooks) == len(PLAYBOOKS_CATALOG)
        for playbook in result.playbooks:
            assert isinstance(playbook, PlaybookMetadata)
            assert playbook.slug
            assert playbook.title
            assert playbook.summary
            assert playbook.when_to_use

    def test_from_entries_ignores_path_field(self):
        """`path` is an internal field on PLAYBOOKS_CATALOG entries — should be
        stripped by `_StrictIgnore` so it never leaks to the agent."""
        result = PlaybooksCatalogResult.from_entries(list(PLAYBOOKS_CATALOG))
        dump = result.model_dump()
        for entry in dump["playbooks"]:
            assert "path" not in entry
            assert set(entry.keys()) == {"slug", "title", "summary", "when_to_use"}

    def test_from_entries_skips_non_dict_entries(self):
        """Defensive: a corrupted catalog entry (None, list, etc.) must not blow up."""
        result = PlaybooksCatalogResult.from_entries([
            {"slug": "ok", "title": "OK", "summary": "s", "when_to_use": "w"},
            None,  # type: ignore[list-item]
            "string-not-dict",  # type: ignore[list-item]
            ["not", "a", "dict"],  # type: ignore[list-item]
        ])
        assert result.total == 1
        assert result.playbooks[0].slug == "ok"

    def test_empty_catalog_yields_zero_total(self):
        result = PlaybooksCatalogResult.from_entries([])
        assert result.total == 0
        assert result.playbooks == []

    def test_model_emits_output_schema(self):
        """FastMCP auto-generates an outputSchema from the model — spot-check
        that the model is JSON-schema-able (no forward refs, weird types)."""
        schema = PlaybooksCatalogResult.model_json_schema()
        assert schema["type"] == "object"
        assert "playbooks" in schema["properties"]
        assert "total" in schema["properties"]


class TestPlaybookContentResultModel:
    def test_from_entry_with_full_content(self):
        entry = {"slug": "prospecting-and-lists", "title": "Prospecting", "path": "x.md"}
        result = PlaybookContentResult.from_entry(entry, "# Heading\n\nBody text.")
        assert isinstance(result, PlaybookContentResult)
        assert result.slug == "prospecting-and-lists"
        assert result.title == "Prospecting"
        assert result.content == "# Heading\n\nBody text."

    def test_from_entry_missing_title_falls_back_to_slug(self):
        entry = {"slug": "ai-inbox-replies"}
        result = PlaybookContentResult.from_entry(entry, "content")
        assert result.slug == "ai-inbox-replies"
        assert result.title == "ai-inbox-replies"  # fallback

    def test_from_entry_missing_slug_renders_empty_strings(self):
        """Defensive: if caller passes a totally empty dict we don't crash —
        we surface empty fields so the union falls back sensibly."""
        result = PlaybookContentResult.from_entry({}, "content")
        assert result.slug == ""
        assert result.title == ""
        assert result.content == "content"

    def test_from_entry_with_non_dict_entry(self):
        """If `entry` is not a dict, fall back to empty metadata."""
        result = PlaybookContentResult.from_entry("not-a-dict", "content")  # type: ignore[arg-type]
        assert result.slug == ""
        assert result.title == ""
        assert result.content == "content"

    def test_none_content_becomes_empty_string(self):
        """Consistency: content field is always a str, never None."""
        entry = {"slug": "s", "title": "T"}
        result = PlaybookContentResult.from_entry(entry, None)  # type: ignore[arg-type]
        assert result.content == ""

    def test_model_emits_output_schema(self):
        schema = PlaybookContentResult.model_json_schema()
        assert schema["type"] == "object"
        assert set(schema["properties"].keys()) >= {"slug", "title", "content"}


class TestPlaybooksToolsRegistration:
    """Integration-style: register playbook tools on a fresh FastMCP server and
    verify the signatures + outputSchema presence."""

    def _fresh_server(self):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import playbooks as playbooks_tools

        server = FastMCP("test-playbooks")
        playbooks_tools.register(server)
        return server

    def test_both_tools_registered(self):
        server = self._fresh_server()
        names = list(server._tool_manager._tools.keys())
        assert "g8_list_playbooks" in names
        assert "g8_load_playbook" in names

    def test_legacy_skill_names_not_registered(self):
        """Regression guard: pre-0.6.3 names must NOT be re-introduced. The
        whole point of the rename was to remove the overload with the
        g8_skill_* / g8_workflow_skill_* authoring family."""
        server = self._fresh_server()
        names = set(server._tool_manager._tools.keys())
        assert "g8_list_skills" not in names, (
            "g8_list_skills was renamed to g8_list_playbooks in v0.6.3. "
            "Don't re-introduce it - it collides with the g8_skill_* family."
        )
        assert "g8_load_skill" not in names, (
            "g8_load_skill was renamed to g8_load_playbook in v0.6.3. "
            "Don't re-introduce it - it collides with the g8_skill_* family."
        )

    def test_both_tools_have_output_schema(self):
        """Structured output contract: every tool emits an `outputSchema`."""
        server = self._fresh_server()
        for tool_name in ("g8_list_playbooks", "g8_load_playbook"):
            tool = server._tool_manager._tools[tool_name]
            # FastMCP stores the schema on the `Tool` object — it's derived
            # from the return annotation, which is `Model | str` for both.
            fn_metadata = getattr(tool, "fn_metadata", None) or getattr(tool, "_metadata", None)
            assert fn_metadata is not None, f"{tool_name} lost its fn_metadata"

    @pytest.mark.asyncio
    async def test_list_playbooks_returns_model_instance(self):
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_list_playbooks"]
        result = await tool.fn()
        assert isinstance(result, PlaybooksCatalogResult)
        assert result.total == len(PLAYBOOKS_CATALOG)

    @pytest.mark.asyncio
    async def test_load_playbook_happy_path_returns_model(self):
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_load_playbook"]
        # Pick the first catalog entry — guaranteed to exist because the test
        # runs inside the repo where the markdown files ship.
        first_slug = PLAYBOOKS_CATALOG[0]["slug"]
        result = await tool.fn(slug=first_slug)
        assert isinstance(result, PlaybookContentResult)
        assert result.slug == first_slug
        assert result.content  # markdown body should be non-empty

    @pytest.mark.asyncio
    async def test_load_playbook_unknown_slug_returns_str(self):
        """Error branch of the `Model | str` union: unknown slug → plain string.
        Must NOT be JSON — that was the old bug."""
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_load_playbook"]
        result = await tool.fn(slug="definitely-not-a-real-playbook-xyz")
        assert isinstance(result, str)
        # Should not be JSON-ish (no leading `{`)
        assert not result.lstrip().startswith("{")
        # Should guide the agent to recover
        assert "g8_list_playbooks" in result
        assert "Available slugs" in result


class TestLegacyModelNamesAreGone:
    """Belt-and-suspenders guard: the pre-0.6.3 Pydantic class names must
    not exist on the models module. Anyone re-importing them will get an
    explicit ImportError instead of a silent fallthrough."""

    def test_skill_metadata_class_removed(self):
        from g8_mcp_server import models
        assert not hasattr(models, "SkillMetadata"), (
            "SkillMetadata was renamed to PlaybookMetadata in v0.6.3."
        )

    def test_skills_catalog_result_class_removed(self):
        from g8_mcp_server import models
        assert not hasattr(models, "SkillsCatalogResult"), (
            "SkillsCatalogResult was renamed to PlaybooksCatalogResult in v0.6.3."
        )

    def test_skill_content_result_class_removed(self):
        from g8_mcp_server import models
        assert not hasattr(models, "SkillContentResult"), (
            "SkillContentResult was renamed to PlaybookContentResult in v0.6.3."
        )
