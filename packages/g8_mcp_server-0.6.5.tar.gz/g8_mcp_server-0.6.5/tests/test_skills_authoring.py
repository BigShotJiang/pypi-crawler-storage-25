"""Tests for the g8_skill_* MCP suite (skill authoring).

Covers the 14 skill-authoring tools added in the MCP skills port PRD
(docs/prds/mcp-skills-port.md):
  - 5 read/discover (list, get, extract_variables, list_models,
    list_templates)
  - 5 build/edit (create_llm, create_api, update_llm, update_api,
    delete)
  - 3 validate/lift (validate_template, create_from_template,
    create_from_node)
  - 1 execute

Verifies:
  * All 14 tools register in `all` mode and are absent in `dev` / `gtm`.
  * Read tools carry readOnlyHint=True.
  * Destructive tools (create_*, delete, execute, from-template,
    from-node) carry destructiveHint=True so MCP-aware clients prompt
    for confirm.
  * Reversible tools (update_llm, update_api) carry destructiveHint=False
    and NOT destructiveHint=True.
  * URL paths and bodies forwarded to the developer_api proxy match
    the wire contract: ``/skills``, ``/skills/{id}``,
    ``/skills/{id}/variables``, ``/skills/models``, ``/skills/templates``,
    ``/skills/validate``, ``/skills/from-template``, ``/skills/from-node``,
    ``/skills/{id}/execute``.
  * dry_run on destructive tools returns a ConfirmationPreview-shaped
    dict and does NOT call the backend.
  * delete: when workflows reference the skill, the tool refuses
    without forwarding the DELETE.
  * Lift (create_from_node) routes through the same /skills/from-node
    body shape the proxy expects (byte-identical-to-authored invariant
    is asserted as a router-side concern in test_skill_lift_diff.py).
  * Update tools pre-fetch and merge so partial updates preserve the
    fields the caller didn't pass.
  * None of these tools are in _ALWAYS_ON_TOOLS (progressive discovery).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
import g8_mcp_server.server as server_module
from g8_mcp_server.server import create_server


def _server_with_mode(monkeypatch, mode: str):
    """Build a fresh FastMCP server in the given mode."""
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setenv("G8_MCP_MODE", mode)
    monkeypatch.setattr(server_module, "MCP_MODE", mode)
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


@pytest.fixture
def mcp_server(monkeypatch):
    return _server_with_mode(monkeypatch, "all")


@pytest.fixture
def gtm_only_server(monkeypatch):
    return _server_with_mode(monkeypatch, "gtm")


@pytest.fixture
def dev_only_server(monkeypatch):
    return _server_with_mode(monkeypatch, "dev")


def _tool(server, name):
    return server._tool_manager._tools[name]


def _ann_flag(tool, key: str):
    ann = tool.annotations
    flag = getattr(ann, key, None)
    if flag is None and isinstance(ann, dict):
        flag = ann.get(key)
    return flag


# ---------------------------------------------------------------------------
# Registration & annotations
# ---------------------------------------------------------------------------

READ_ONLY_NAMES = [
    "g8_skill_list",
    "g8_skill_get",
    "g8_skill_extract_variables",
    "g8_skill_list_models",
    "g8_skill_list_templates",
    "g8_skill_validate_template",
]

DESTRUCTIVE_NAMES = [
    "g8_skill_create_llm",
    "g8_skill_create_api",
    "g8_skill_delete",
    "g8_skill_create_from_template",
    "g8_skill_create_from_node",
    "g8_skill_execute",
]

REVERSIBLE_NAMES = [
    "g8_skill_update_llm",
    "g8_skill_update_api",
]

ALL_NAMES = READ_ONLY_NAMES + DESTRUCTIVE_NAMES + REVERSIBLE_NAMES


class TestRegistration:
    def test_all_tools_registered_in_all_mode(self, mcp_server):
        for name in ALL_NAMES:
            assert name in mcp_server._tool_manager._tools, f"Missing: {name}"

    def test_total_count(self, mcp_server):
        # Lock the surface count so adding/removing a tool is intentional.
        # Aliases live under `g8_workflow_skill_*` (different prefix) so this
        # filter still matches only the 14 canonical names.
        registered = [n for n in mcp_server._tool_manager._tools if n.startswith("g8_skill_")]
        assert len(registered) == 14, (
            f"Expected 14 skill tools, got {len(registered)}: {sorted(registered)}"
        )

    def test_workflow_skill_aliases_registered(self, mcp_server):
        """Every g8_skill_* tool also exists under g8_workflow_skill_*.

        The alias namespace puts skill authoring inside the workflow toolbelt
        so the agent picks the Action+LLM-skill pattern over an Agent node
        when building workflows. Both names must remain callable; backwards
        compatibility for the canonical g8_skill_* surface is non-negotiable.
        """
        canonical = [
            n for n in mcp_server._tool_manager._tools if n.startswith("g8_skill_")
        ]
        assert len(canonical) == 14, "canonical surface drifted"
        for name in canonical:
            base = name[len("g8_skill_"):]
            alias = f"g8_workflow_skill_{base}"
            assert alias in mcp_server._tool_manager._tools, (
                f"missing alias {alias} for canonical {name}"
            )

    def test_alias_handler_is_same_function_as_canonical(self, mcp_server):
        """Alias and canonical Tool entries must share the same callable
        (and identical schema/description/annotations) so calling either
        routes to the same coroutine without behavioural drift.
        """
        for base in (
            "list", "get", "create_llm", "create_api", "update_llm",
            "update_api", "delete", "execute", "extract_variables",
            "list_models", "list_templates", "validate_template",
            "create_from_template", "create_from_node",
        ):
            canonical = mcp_server._tool_manager._tools[f"g8_skill_{base}"]
            alias = mcp_server._tool_manager._tools[f"g8_workflow_skill_{base}"]
            assert canonical.fn is alias.fn, f"{base}: fn must be shared"
            assert canonical.description == alias.description, f"{base}: description drift"
            assert canonical.parameters == alias.parameters, f"{base}: parameters drift"
            assert canonical.annotations == alias.annotations, f"{base}: annotations drift"
            assert alias.name == f"g8_workflow_skill_{base}"
            assert canonical.name == f"g8_skill_{base}"

    def test_read_only_tools_are_read_only(self, mcp_server):
        for name in READ_ONLY_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "readOnlyHint") is True, (
                f"{name} should be read-only"
            )

    def test_destructive_tools_carry_destructive_hint(self, mcp_server):
        for name in DESTRUCTIVE_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "destructiveHint") is True, (
                f"{name} should be destructive (MCP clients prompt to confirm)"
            )
            assert _ann_flag(_tool(mcp_server, name), "readOnlyHint") is not True, (
                f"{name} must not be marked read-only - it mutates state"
            )

    def test_reversible_tools_are_idempotent_not_destructive(self, mcp_server):
        for name in REVERSIBLE_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "idempotentHint") is True, (
                f"{name} should be idempotent (reversible state flip)"
            )
            assert _ann_flag(_tool(mcp_server, name), "destructiveHint") is not True, (
                f"{name} must not be destructive - update can be reversed"
            )

    def test_skill_tools_absent_in_gtm_mode(self, gtm_only_server):
        # PRD lock: skill authoring lives in `all` mode only — same
        # boundary as workflow tools. Lock it here.
        for name in ALL_NAMES:
            assert name not in gtm_only_server._tool_manager._tools, (
                f"{name} leaked into gtm mode - skill authoring lives in `all` only"
            )

    def test_skill_tools_absent_in_dev_mode(self, dev_only_server):
        for name in ALL_NAMES:
            assert name not in dev_only_server._tool_manager._tools, (
                f"{name} leaked into dev mode - skill authoring lives in `all` only"
            )

    def test_not_in_always_on_set(self):
        # Progressive discovery promise: skill authoring is a niche surface.
        # Steady-state context cost must stay zero.
        for name in ALL_NAMES:
            assert name not in server_module._ALWAYS_ON_TOOLS, (
                f"{name} is in _ALWAYS_ON_TOOLS — skill authoring tools must stay "
                "behind progressive discovery."
            )


# ---------------------------------------------------------------------------
# Read / discover
# ---------------------------------------------------------------------------


class TestListSkills:
    async def test_default_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"actions": [], "total": 0})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        await _tool(mcp_server, "g8_skill_list").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/skills"
        # include_system defaults to True; others omitted unless passed.
        assert params == {"include_system": True}

    async def test_filter_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"actions": []})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        await _tool(mcp_server, "g8_skill_list").fn(
            runtime_type="llm",
            enabled=True,
            category="Sales",
            object_type="Contact",
            include_system=False,
        )
        params = fake.await_args.args[1]
        assert params == {
            "include_system": False,
            "runtime_type": "llm",
            "enabled": True,
            "category": "Sales",
            "object_type": "Contact",
        }


class TestGetSkill:
    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "skill-1", "runtime_type": "llm"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        await _tool(mcp_server, "g8_skill_get").fn(action_id="skill-1")
        assert fake.await_args.args[0] == "/skills/skill-1"

    async def test_missing_action_id_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        r = await _tool(mcp_server, "g8_skill_get").fn(action_id="")
        assert isinstance(r, str)
        fake.assert_not_called()


class TestExtractVariables:
    async def test_path_and_envelope(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "action_id": "skill-1",
                "runtime_type": "llm",
                "variables": ["company", "name"],
                "total": 2,
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        result = await _tool(mcp_server, "g8_skill_extract_variables").fn(action_id="skill-1")
        assert fake.await_args.args[0] == "/skills/skill-1/variables"
        # Returns the Pydantic envelope, not a raw dict.
        assert result.variables == ["company", "name"]
        assert result.total == 2
        assert result.runtime_type == "llm"


class TestListModels:
    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"models": [{"id": "gpt-4o"}], "total": 1})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        result = await _tool(mcp_server, "g8_skill_list_models").fn()
        assert fake.await_args.args[0] == "/skills/models"
        assert result["total"] == 1


class TestListTemplates:
    async def test_default_no_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"templates": []})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        await _tool(mcp_server, "g8_skill_list_templates").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/skills/templates"
        assert params == {}

    async def test_category_filter(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"templates": []})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", fake)
        await _tool(mcp_server, "g8_skill_list_templates").fn(category="Research")
        params = fake.await_args.args[1]
        assert params == {"category": "Research"}


# ---------------------------------------------------------------------------
# Build / edit — create
# ---------------------------------------------------------------------------


class TestCreateLLMSkill:
    async def test_dry_run_returns_preview_without_calling_backend(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_llm").fn(
            name="Email Drafter",
            model="gpt-4o",
            prompt_template="Write a follow-up to {prospect_name}",
            dry_run=True,
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_create_llm"
        assert r["confirm_args"]["dry_run"] is False
        fake.assert_not_called()

    async def test_minimal_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "skill-new", "runtime_type": "llm"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_llm").fn(
            name="Drafter",
            model="gpt-4o",
            prompt_template="Hi {name}",
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/skills"
        assert body["name"] == "Drafter"
        assert body["runtime_type"] == "llm"
        assert body["llm_config"] == {
            "model": "gpt-4o",
            "prompt_template": "Hi {name}",
            "temperature": 0.7,
            "max_tokens": 1000,
        }
        # Defaults — optional fields should NOT appear unless caller passed.
        assert "description" not in body
        assert "category" not in body
        assert "object_type" not in body

    async def test_full_body_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "skill-new"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_llm").fn(
            name="Researcher",
            model="claude-3-5-sonnet",
            prompt_template="Research {company}",
            description="Researches companies",
            category="Research",
            object_type="Company",
            temperature=0.3,
            max_tokens=4000,
            requires_approval=True,
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["description"] == "Researches companies"
        assert body["category"] == "Research"
        assert body["object_type"] == "Company"
        assert body["llm_config"]["temperature"] == 0.3
        assert body["llm_config"]["max_tokens"] == 4000
        assert body["requires_approval"] is True

    async def test_missing_required_fields(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_llm").fn(
            name="", model="gpt-4o", prompt_template="x"
        )
        assert isinstance(r, str)
        fake.assert_not_called()


class TestCreateAPISkill:
    async def test_dry_run_returns_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_api").fn(
            name="Slack Notify",
            endpoint="https://hooks.slack.com/services/{key}",
            method="POST",
            dry_run=True,
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_create_api"
        fake.assert_not_called()

    async def test_method_normalization(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "api-skill"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_api").fn(
            name="X", endpoint="https://x.com/api", method="get"
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["api_config"]["method"] == "GET"

    async def test_invalid_method_rejected(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_api").fn(
            name="X", endpoint="https://x.com", method="BREW"
        )
        assert isinstance(r, str) and "method" in r.lower()
        fake.assert_not_called()

    async def test_full_api_config_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "api-skill"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_api").fn(
            name="Slack",
            endpoint="https://hooks.slack.com/{token}",
            method="POST",
            headers={"Content-Type": "application/json"},
            body_template='{"text": "{message}"}',
            query_params={"v": "1"},
            body_type="json",
            content_type="application/json",
            category="Integrations",
            object_type="Contact",
            requires_approval=False,
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        api_cfg = body["api_config"]
        assert api_cfg["endpoint"] == "https://hooks.slack.com/{token}"
        assert api_cfg["headers"] == {"Content-Type": "application/json"}
        assert api_cfg["body_template"] == '{"text": "{message}"}'
        assert api_cfg["query_params"] == {"v": "1"}
        assert api_cfg["body_type"] == "json"


# ---------------------------------------------------------------------------
# Build / edit — update (pre-fetch + merge)
# ---------------------------------------------------------------------------


class TestUpdateLLMSkill:
    async def test_metadata_only_no_prefetch(self, mcp_server, monkeypatch):
        # Updating just metadata fields should NOT pre-fetch the skill —
        # only the llm_config replacement triggers the merge.
        get_fake = AsyncMock()
        put_fake = AsyncMock(return_value={"action_id": "skill-1"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.put", put_fake)
        await _tool(mcp_server, "g8_skill_update_llm").fn(
            action_id="skill-1", name="Renamed", enabled=False
        )
        get_fake.assert_not_called()
        path = put_fake.await_args.args[0]
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        assert path == "/skills/skill-1"
        assert body == {"name": "Renamed", "enabled": False}
        assert "llm_config" not in body

    async def test_partial_llm_config_change_merges_with_current(self, mcp_server, monkeypatch):
        # Update only temperature; the helper must pre-fetch and preserve
        # model + prompt_template + max_tokens on the resulting llm_config.
        get_fake = AsyncMock(
            return_value={
                "action_id": "skill-1",
                "runtime_type": "llm",
                "llm_config": {
                    "model": "gpt-4o",
                    "prompt_template": "Hi {name}",
                    "temperature": 0.7,
                    "max_tokens": 1000,
                },
            }
        )
        put_fake = AsyncMock(return_value={"action_id": "skill-1"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.put", put_fake)
        await _tool(mcp_server, "g8_skill_update_llm").fn(
            action_id="skill-1", temperature=0.2
        )
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        assert body["llm_config"] == {
            "model": "gpt-4o",
            "prompt_template": "Hi {name}",
            "temperature": 0.2,
            "max_tokens": 1000,
        }


class TestUpdateAPISkill:
    async def test_partial_api_config_change_merges_with_current(self, mcp_server, monkeypatch):
        # Update only endpoint; the helper must pre-fetch and preserve
        # method + headers + body_template.
        get_fake = AsyncMock(
            return_value={
                "action_id": "api-1",
                "runtime_type": "api",
                "api_config": {
                    "endpoint": "https://old.com/v1",
                    "method": "POST",
                    "headers": {"X-Key": "abc"},
                    "body_template": '{"x": 1}',
                },
            }
        )
        put_fake = AsyncMock(return_value={"action_id": "api-1"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.put", put_fake)
        await _tool(mcp_server, "g8_skill_update_api").fn(
            action_id="api-1", endpoint="https://new.com/v1"
        )
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        merged = body["api_config"]
        assert merged["endpoint"] == "https://new.com/v1"
        assert merged["method"] == "POST"
        assert merged["headers"] == {"X-Key": "abc"}
        assert merged["body_template"] == '{"x": 1}'

    async def test_no_fields_returns_error(self, mcp_server, monkeypatch):
        get_fake = AsyncMock()
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.put", put_fake)
        r = await _tool(mcp_server, "g8_skill_update_api").fn(action_id="api-1")
        assert isinstance(r, str) and "at least one field" in r.lower()
        put_fake.assert_not_called()


# ---------------------------------------------------------------------------
# Delete (reference scan)
# ---------------------------------------------------------------------------


class TestDeleteSkill:
    async def test_unreferenced_dry_run_returns_preview(self, mcp_server, monkeypatch):
        # No workflows reference this skill -> dry_run returns a normal
        # confirmation preview (not the blocked variant).
        get_fake = AsyncMock(return_value={"actions": []})  # no workflows in org
        del_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.delete", del_fake)
        r = await _tool(mcp_server, "g8_skill_delete").fn(action_id="skill-1", dry_run=True)
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_delete"
        assert r["action_label"] == "Delete skill"
        del_fake.assert_not_called()

    async def test_unreferenced_live_call_forwards_delete(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(return_value={"actions": []})
        del_fake = AsyncMock(return_value={"success": True})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.delete", del_fake)
        await _tool(mcp_server, "g8_skill_delete").fn(action_id="skill-1", dry_run=False)
        assert del_fake.await_args.args[0] == "/skills/skill-1"

    async def test_referenced_dry_run_returns_blocked_preview(self, mcp_server, monkeypatch):
        # One workflow's node references skill-1 -> dry_run must return
        # the blocked preview with confirm_tool=None.
        get_fake = AsyncMock(
            side_effect=[
                {"actions": [{"action_id": "wf-1", "name": "My WF"}]},  # /workflows
                {  # /workflows/wf-1
                    "action_id": "wf-1",
                    "config": {
                        "nodes": [
                            {
                                "node_id": "act-node-1",
                                "node_type": "action",
                                "config": {"action_id": "skill-1"},
                            },
                        ],
                    },
                },
            ]
        )
        del_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.delete", del_fake)
        r = await _tool(mcp_server, "g8_skill_delete").fn(action_id="skill-1", dry_run=True)
        assert isinstance(r, dict)
        assert r["action_label"] == "Delete skill - BLOCKED"
        assert r["confirm_tool"] is None
        del_fake.assert_not_called()

    async def test_referenced_live_call_refuses_without_calling_delete(
        self, mcp_server, monkeypatch
    ):
        get_fake = AsyncMock(
            side_effect=[
                {"actions": [{"action_id": "wf-1", "name": "My WF"}]},
                {
                    "action_id": "wf-1",
                    "config": {
                        "nodes": [
                            {
                                "node_id": "act-node-1",
                                "node_type": "action",
                                "config": {"actionId": "skill-1"},  # camelCase variant
                            },
                        ],
                    },
                },
            ]
        )
        del_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.delete", del_fake)
        r = await _tool(mcp_server, "g8_skill_delete").fn(action_id="skill-1", dry_run=False)
        assert isinstance(r, str)
        assert "refused" in r.lower()
        del_fake.assert_not_called()


# ---------------------------------------------------------------------------
# Validate / lift
# ---------------------------------------------------------------------------


class TestValidateTemplate:
    async def test_template_string_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={"valid": True, "variables": ["x"], "variable_count": 1, "warnings": []}
        )
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_validate_template").fn(template="Hello {x}")
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/skills/validate"
        assert body == {"template": "Hello {x}"}
        # Returns envelope, not raw dict.
        assert r.valid is True
        assert r.variables == ["x"]

    async def test_full_skill_shape(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={"valid": True, "variables": ["company"], "variable_count": 1, "warnings": []}
        )
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_validate_template").fn(
            runtime_type="llm",
            llm_config={"prompt_template": "Research {company}"},
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["runtime_type"] == "llm"
        assert body["llm_config"] == {"prompt_template": "Research {company}"}

    async def test_no_args_returns_error(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_validate_template").fn()
        assert isinstance(r, str)
        fake.assert_not_called()


class TestCreateFromTemplate:
    async def test_dry_run_returns_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_from_template").fn(
            template_id="tmpl-1", name="My Skill", dry_run=True
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_create_from_template"
        fake.assert_not_called()

    async def test_body_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "new-skill"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_from_template").fn(
            template_id="tmpl-1",
            name="My Skill",
            overrides={"temperature": 0.2},
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/skills/from-template"
        assert body == {"template_id": "tmpl-1", "name": "My Skill", "overrides": {"temperature": 0.2}}


class TestCreateFromNode:
    async def test_dry_run_returns_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_create_from_node").fn(
            workflow_id="wf-1", node_id="act-1", name="Lifted", dry_run=True
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_create_from_node"
        assert r["confirm_args"]["workflow_id"] == "wf-1"
        assert r["confirm_args"]["node_id"] == "act-1"
        fake.assert_not_called()

    async def test_body_forwarding_with_name(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "lifted-skill"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_from_node").fn(
            workflow_id="wf-1", node_id="act-1", name="My Lift"
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/skills/from-node"
        assert body == {"workflow_id": "wf-1", "node_id": "act-1", "name": "My Lift"}

    async def test_body_forwarding_without_name(self, mcp_server, monkeypatch):
        # When name is omitted, the helper must NOT send "name": None —
        # voice's endpoint defaults to "<source> (Copy)" only when the
        # field is absent.
        fake = AsyncMock(return_value={"action_id": "lifted-skill"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_create_from_node").fn(
            workflow_id="wf-1", node_id="act-1"
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert "name" not in body
        assert body == {"workflow_id": "wf-1", "node_id": "act-1"}


# ---------------------------------------------------------------------------
# Execute
# ---------------------------------------------------------------------------


class TestExecuteSkill:
    async def test_dry_run_returns_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_skill_execute").fn(
            action_id="skill-1", input_data={"name": "Acme"}, dry_run=True
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_skill_execute"
        assert "credits" in r["warning"].lower() or "external" in r["warning"].lower()
        fake.assert_not_called()

    async def test_body_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"result": "ok", "output": "..."})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_execute").fn(
            action_id="skill-1", input_data={"company": "Acme"}
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/skills/skill-1/execute"
        assert body == {
            "action_id": "skill-1",
            "input_data": {"company": "Acme"},
            "trigger_type": "manual",
        }

    async def test_no_inputs_sends_empty_dict(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"result": "ok"})
        monkeypatch.setattr("g8_mcp_server.tools.skills_authoring.G8Client.post", fake)
        await _tool(mcp_server, "g8_skill_execute").fn(action_id="skill-1")
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["input_data"] == {}
