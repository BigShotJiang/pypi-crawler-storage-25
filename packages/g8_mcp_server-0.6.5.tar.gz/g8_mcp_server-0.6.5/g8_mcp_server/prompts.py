"""Pre-built prompt templates for common graph8 workflows.

Prompts are mode-aware so the server never exposes a workflow that references
tools the current instance hasn't registered.

- **dev prompts** reference repo-scoped dev tools (`g8_connect_repo`,
  `g8_scan_repo`, `g8_install_spine`, `g8_apply_install`, `g8_get_campaign`
  with `repo_id`, `g8_search_kb`) - only valid when dev tools are registered.
- **gtm prompts** reference org-scoped gtm tools (`g8_list_campaigns`,
  `g8_get_campaign` without `repo_id`, `g8_find_contacts`,
  `g8_create_list`, `g8_add_to_sequence`, `g8_list_inbox`) - valid when
  gtm tools are registered.
- In ``all`` mode both sets register; gtm tool names are prefixed with
  ``g8_gtm_`` to avoid collisions, so the gtm prompt strings use the
  ``g8_gtm_*`` form.
"""

from mcp.server import FastMCP
from mcp.types import PromptMessage, TextContent


def register(server: FastMCP, mode: str = "all") -> None:
    """Register prompt templates on the MCP server.

    Args:
        server: the FastMCP instance to attach prompts to.
        mode: one of ``"dev"``, ``"gtm"``, ``"all"``. Matches
            ``G8_MCP_MODE`` / the ``mode`` arg on ``_register_tools``.
    """
    mode = (mode or "all").lower()

    if mode in ("dev", "all"):
        _register_dev_prompts(server)

    if mode in ("gtm", "all"):
        _register_gtm_prompts(server, all_mode=(mode == "all"))


def _register_dev_prompts(server: FastMCP) -> None:
    """Dev-mode prompts - reference repo-scoped dev tools."""

    @server.prompt()
    async def gtm_setup(repo_url: str) -> list[PromptMessage]:
        """Full GTM setup workflow - connect a repo, scan, install, and launch campaigns.

        Args:
            repo_url: GitHub/GitLab repository URL to set up
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Set up graph8 GTM automation for this repository: {repo_url}

Follow these steps in order:
1. Connect the repository using g8_connect_repo
2. Scan it with g8_scan_repo to detect the tech stack
3. Review scan results with g8_get_scan_results
4. Generate install patches with g8_install_spine
5. Review the patches and ask me to confirm before applying with g8_apply_install
6. List generated campaigns with g8_list_campaigns
7. Show me campaign details and ask which to launch

Always ask for my confirmation before destructive operations (applying patches, launching campaigns).""",
                ),
            )
        ]

    @server.prompt()
    async def campaign_review(campaign_id: str, repo_id: str) -> list[PromptMessage]:
        """Review and improve a generated dev-mode (repo-scoped) campaign.

        Args:
            campaign_id: Campaign ID to review
            repo_id: Repository ID the campaign belongs to
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Review the campaign with ID {campaign_id} on repo {repo_id}.

Use g8_get_campaign(repo_id, campaign_id) to load the full campaign details, then:
1. Evaluate the target persona fit - does it match a real buyer?
2. Review the core concept and primary hook - are they compelling?
3. Check the channel strategy - are the channels appropriate for the audience?
4. Look at the sequence copy - is it specific enough, or too generic?
5. Suggest 3 concrete improvements with rationale.

Use g8_search_kb(repo_id, query) to pull relevant ICP profiles and buyer personas for context.""",
                ),
            )
        ]

    @server.prompt()
    async def icp_refinement(feedback: str, repo_id: str) -> list[PromptMessage]:
        """Refine ICP profiles in the dev-mode knowledge base based on user feedback.

        Args:
            feedback: What to change about the current ICP profiles
            repo_id: Repository ID whose KB should be refined
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Refine the ICP profiles for repo {repo_id} based on this feedback: {feedback}

1. Use g8_search_kb(repo_id, query) with queries like "ICP" and "buyer persona" to load current profiles
2. Analyze what's working and what needs to change based on the feedback
3. Suggest specific updates to:
   - Target company characteristics (size, industry, tech stack)
   - Buyer titles and seniority levels
   - Pain points and use cases
   - Qualification criteria
4. Explain how these changes would affect campaign targeting""",
                ),
            )
        ]


def _register_gtm_prompts(server: FastMCP, *, all_mode: bool) -> None:
    """GTM-mode prompts - reference org-scoped gtm tools.

    In ``all`` mode the gtm tools register with a ``g8_gtm_`` prefix to avoid
    colliding with dev-mode names, so the prompt strings switch their tool
    references accordingly.
    """
    prefix = "g8_gtm_" if all_mode else "g8_"

    @server.prompt()
    async def prospect_outreach(
        icp_description: str, list_name: str, sequence_id: str
    ) -> list[PromptMessage]:
        """Build a prospect list from an ICP description and enroll them in a sequence.

        Args:
            icp_description: Plain-English description of the target buyer (e.g. "VPs
                of Engineering at 50-500 person B2B SaaS companies using Kubernetes").
            list_name: Name for the CRM list that will hold the matched contacts.
            sequence_id: ID of the outreach sequence to enroll contacts into.
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Run a full prospect-to-outreach workflow for this ICP: {icp_description}

Target list name: {list_name}
Sequence to enroll into: {sequence_id}

Follow these steps and ALWAYS stop for my confirmation before the credit-consuming or outreach-sending ones:

1. Call g8_find_contacts with filters derived from the ICP description to PREVIEW matches (this is free - no credits).
2. Show me the match count and the first 5-10 results. Ask if I want to refine filters.
3. Once I confirm, call g8_create_list(filters=..., title="{list_name}", dry_run=True) to render the cost preview. After I confirm, re-call with dry_run=False to save matches (COSTS credits - one per contact).
4. Call g8_enrich_contacts on the saved list to fill missing emails / phones (COSTS credits - confirm count first).
5. Once enrichment completes, call g8_add_to_sequence with sequence_id={sequence_id} to start automated outreach (SENDS REAL MESSAGES - confirm the total enrollment count).

At each credit-consuming or outreach step: show me a count + estimated credit cost + ask yes/no.""",
                ),
            )
        ]

    @server.prompt()
    async def campaign_review_gtm(campaign_id: str) -> list[PromptMessage]:
        """Review and improve an org-scoped (gtm-mode) campaign before launch.

        Args:
            campaign_id: Campaign ID from g8_gtm_list_campaigns / g8_list_campaigns
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Review campaign {campaign_id} before it launches.

1. Call {prefix}get_campaign({campaign_id}) to load core content (brief, hook, persona, goal).
2. Call {prefix}list_campaign_documents({campaign_id}) to see the generated doc set, then {prefix}get_campaign_document() on the key ones (strategy, ICP, email copy, ad copy).
3. Call {prefix}get_campaign_sequence({campaign_id}) to inspect the planned step sequence (days, channels, personalization).
4. Evaluate:
   - Does the target persona match a real buyer?
   - Are the core concept and primary hook compelling (not generic)?
   - Is the channel mix appropriate for the audience (email vs LinkedIn vs SMS)?
   - Is the sequence copy specific, or does it sound AI-generated?
5. Suggest 3 concrete improvements with rationale. Never call {prefix}launch_campaign without my explicit confirmation - launch sends real outreach.""",
                ),
            )
        ]

    @server.prompt()
    async def inbox_triage() -> list[PromptMessage]:
        """Work through the inbox reply queue, tagging and assigning as you go."""
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text="""Triage unread / unassigned inbox replies.

1. Call g8_list_inbox with status="unread" (or the equivalent) to get pending replies.
2. For each reply, summarize the contact's intent in one sentence (positive / objection / unsubscribe / meeting-request / out-of-office).
3. Use g8_tag_reply to tag with the intent classification (e.g. "positive", "objection:price", "meeting:booked").
4. If the reply needs a human (meeting-request, strong objection, enterprise interest), call g8_assign_reply to route it to an owner and tell me which owner you chose.
5. For auto-replies (out-of-office, unsubscribe), tag and leave unassigned.
6. Report a summary at the end: N triaged, M assigned, and a breakdown by tag.

Never draft or send a reply without my confirmation.""",
                ),
            )
        ]

    @server.prompt()
    async def competitor_intent_setup(competitor_domains: str) -> list[PromptMessage]:
        """Set up compete-tracking for a list of competitor domains.

        Saves each domain as an intent keyword, reads the seeded contacts and
        companies, and explains the daily-resolver delay so the agent does not
        retry create-from-domain on initial low counts.

        Args:
            competitor_domains: Comma- or newline-separated list of competitor
                domains (bare, no scheme). Example:
                "belkins.io, martal.ca, operatix.net".
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Set up compete-tracking on graph8 for these competitor domains: {competitor_domains}

This is the canonical competitor-intent workflow. Do NOT substitute CRM
search, open-index search, or any external scrape - the only correct
substrate is graph8's intent keyword search over actual site-visitor /
web-research signals.

Step 1. Confirm coverage.
   Call g8_intent_stats and check that the intent index has meaningful
   document counts. If it is empty, stop and tell me - the rest of the
   workflow has no data to read.

Step 2. Save each competitor domain as an intent keyword.
   For each domain in the list, call:
     g8_intent_create_from_domain(domain="<domain>")
   This is a server-side composite: it pulls indexed pages on the domain,
   resolves contacts seen on those pages, and saves a keyword row with both
   URLs and pre-seeded contacts in a single call. Returns keyword_id plus
   counts (pages_seeded, contacts_seeded, companies_seeded,
   off_domain_rejected). If a keyword for the same domain already exists,
   the call is idempotent - re-use the returned id.

Step 3. Inventory what landed.
   Call g8_intent_list_keywords and show me the saved rows with
   total_resolved_contacts and total_resolved_companies per row. Highest
   counts first.

Step 4. Read the resolved signal per keyword.
   For each keyword_id, call:
     - g8_intent_keyword_companies(keyword_id) - companies aggregated by
       domain (the ABM-style account roll-up).
     - g8_intent_keyword_contacts(keyword_id) - individual contacts with
       full identity (name, job title, LinkedIn, work email, company link).
   For URL-level drill-down (a specific page from g8_intent_search_pages
   or g8_intent_keyword_urls), use g8_intent_search_url_companies(url=...).

Step 5. Set expectations on data growth.
   The save-from-domain seed is immediate, but the daily data4seo resolver
   runs once per cycle and expands both the URL set and the contact /
   company set after that. If counts look thin on day 1, tell me
   "results expand after the next resolver cycle (within 24h)" - do NOT
   re-create the keyword and do NOT fall back to a different substrate.

Step 6. Ownership and suppression check before any outreach.
   For high-signal contacts, run g8_search_contacts and g8_lookup_company
   to confirm we don't already own them in the CRM and that they pass
   suppression. Only after that should you propose outreach.

Never call g8_intent_delete_keyword without my explicit confirmation - the
resolved signal accumulates over time and re-saving a keyword does not
recover the historical resolved rows.""",
                ),
            )
        ]
