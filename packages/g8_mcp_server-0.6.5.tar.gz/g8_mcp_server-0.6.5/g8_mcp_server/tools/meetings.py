"""Meetings tools - list calendar meetings and fetch transcripts.

Exposes two read-only tools:
  - g8_list_meetings: card-level meeting list with transcript preview.
    Supports filtering by participant (organizer + owner + attendees),
    timeframe, visibility scope, and transcript presence.
  - g8_get_meeting: single meeting with FULL transcript bundled inline,
    plus extracted topics, action items, and CRM tasks.

Both tools proxy /api/v1/inbox/meetings on the developer API, which
itself wraps ai_inbox.services.channels.ChannelsService meetings logic.
RBAC is enforced at the backend (meetings:see_all, meetings:see_transcripts)
based on the API key's bound user.
"""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import MeetingDetail, MeetingListResult

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register meetings tools on the MCP server."""

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_meetings(
        email: str | None = None,
        contact_id: int | None = None,
        participant_emails: list[str] | None = None,
        scope: str | None = None,
        timeframe: str | None = None,
        has_transcript: bool | None = None,
        search: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> MeetingListResult | str:
        """List calendar meetings as compact summary cards.

        Use this for "show me meetings", "what meetings did X attend",
        or browsing the meeting inbox. Each card includes title, time,
        attendees, transcript status, and a short transcript summary
        preview. Call g8_get_meeting(meeting_id) to read the full
        transcript body.

        Filter to a specific person's meetings by passing `email`,
        `contact_id`, or `participant_emails`. The match is across
        organizer + owner + attendees (case-insensitive, OR-matched).

        Args:
            email: Single email - filter to meetings where this person
                appears as organizer, owner, or attendee.
            contact_id: CRM contact ID - resolved to the contact's work
                email and used as the participant filter. Combine with
                `email` to broaden (OR-matched).
            participant_emails: Explicit list of emails to match (OR).
                Use when the caller already knows multiple emails.
            scope: 'my' (your meetings, default) or 'all' (org-wide,
                requires meetings:see_all permission).
            timeframe: 'all', 'upcoming', or 'past' (default 'past').
            has_transcript: True = only meetings with a linked
                transcript. False = only meetings without. Omit for all.
            search: Match against meeting title or transcript text.
            page: Page number (default 1).
            page_size: Items per page (default 50, max 100).
        """
        # Build the participant filter list from any combination of
        # contact_id / email / participant_emails. Contact resolution is
        # a single extra GET, kept lazy so callers who pass email alone
        # avoid the round-trip.
        emails_filter: list[str] = []
        if participant_emails:
            emails_filter.extend(
                e.strip() for e in participant_emails if isinstance(e, str) and e.strip()
            )
        if email and isinstance(email, str) and email.strip():
            emails_filter.append(email.strip())
        if contact_id is not None:
            try:
                contact_envelope = await client.get(f"/contacts/{contact_id}")
            except Exception:
                contact_envelope = None
            resolved_email = _extract_contact_email(contact_envelope)
            if resolved_email:
                emails_filter.append(resolved_email)

        # De-dupe (case-insensitive) while preserving order.
        seen: set[str] = set()
        deduped: list[str] = []
        for e in emails_filter:
            key = e.lower()
            if key in seen:
                continue
            seen.add(key)
            deduped.append(e)

        params: dict = {
            "scope": scope,
            "timeframe": timeframe,
            "has_transcript": has_transcript,
            "search": search,
            "page": page,
            "page_size": page_size,
        }
        if deduped:
            # httpx encodes list values as repeated query params, matching
            # FastAPI's Query(list[str]) parsing on the backend.
            params["participant_email"] = deduped

        return await safe_call_typed(
            client.get("/inbox/meetings", params),
            MeetingListResult.from_envelope,
            context="Meetings list",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_meeting(meeting_id: str) -> MeetingDetail | str:
        """Get a single meeting with FULL transcript bundled inline.

        Returns the meeting record plus the complete transcript body,
        summary, key topics, action items, CRM tasks, and custom-field
        extractions. When the caller is not a participant and lacks the
        meetings:see_transcripts permission, transcript content is
        redacted (the response sets transcript_redacted=true).

        Use this after g8_list_meetings has narrowed down a meeting id,
        or when the user asks for "this meeting" / "that meeting".

        Args:
            meeting_id: Meeting ID (CalendarEvent.id, string or integer
                form - the backend accepts both).
        """
        return await safe_call_typed(
            client.get(f"/inbox/meetings/{meeting_id}"),
            MeetingDetail.from_envelope,
            context="Meeting detail",
        )


def _extract_contact_email(envelope) -> str | None:
    """Pull the most useful email off a contact envelope.

    Tolerates both ApiResponse-wrapped ({"data": {...}}) and bare-dict
    contact records. Prefers work_email, falls back to other email
    fields the backend may surface.
    """
    if not isinstance(envelope, dict):
        return None
    data = envelope.get("data") if "data" in envelope else envelope
    if not isinstance(data, dict):
        return None
    for key in ("work_email", "email", "CONTACT_WORK_EMAIL", "primary_email"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None
