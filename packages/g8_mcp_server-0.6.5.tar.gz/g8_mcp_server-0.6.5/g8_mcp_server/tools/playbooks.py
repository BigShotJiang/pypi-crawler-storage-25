"""Playbook tools - workflow-level domain knowledge served as markdown.

Registers two tools:
- g8_list_playbooks: catalog of available playbooks (slug, title, when_to_use)
- g8_load_playbook: full markdown content for a single playbook by slug

Playbooks are prescriptive guides for multi-step graph8 workflows. They
complement tool docstrings (which describe individual tools) by covering
the sequencing, confirmations, and gotchas that only show up across
multiple tool calls.

Renamed from "skills" in v0.6.3 to disambiguate from the `g8_skill_*` /
`g8_workflow_skill_*` tool family (which authors first-class graph8 skill
records consumed by workflow Action nodes). The two surfaces are
unrelated - "skill" was an overloaded term that confused MCP clients.

Both tools return Pydantic `Model | str` unions (Upgrade 2 - structured
output). The success branch gives the agent typed fields (slug / title /
content / ...); the `str` branch is reserved for error messages on the
unhappy path (unknown slug, missing file). This mirrors the envelope
pattern used by every other tool in the MCP surface.
"""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.models import (
    PlaybookContentResult,
    PlaybooksCatalogResult,
)
from g8_mcp_server.playbooks import PLAYBOOKS_CATALOG, get_playbook_content

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)


def register(server: FastMCP) -> None:
    """Register playbook discovery tools on the MCP server."""

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_playbooks() -> PlaybooksCatalogResult | str:
        """List available graph8 playbooks - prescriptive workflow guides.

        Each playbook is a markdown document covering a specific user
        journey (prospecting, running a campaign, installing tracking,
        handling inbox replies). Call g8_load_playbook(slug) to fetch the
        full content.

        Returns a structured catalog with slug, title, summary, and
        when_to_use for every playbook. Use when_to_use to decide which
        playbook to load next.

        NOTE: distinct from the `g8_skill_*` / `g8_workflow_skill_*` tool
        family, which authors graph8 skill records used by workflow
        Action nodes. Playbooks are docs for the agent to read; skills
        are records for workflows to execute.
        """
        return PlaybooksCatalogResult.from_entries(list(PLAYBOOKS_CATALOG))

    @server.tool(annotations=_READ_ONLY)
    async def g8_load_playbook(slug: str) -> PlaybookContentResult | str:
        """Load the full markdown content of a graph8 playbook by slug.

        Use this after g8_list_playbooks when the user's task matches a
        playbook's when_to_use. The returned content is prescriptive -
        follow the tool sequencing and confirmations it describes.

        Args:
            slug: Playbook slug from g8_list_playbooks (e.g. "prospecting-and-lists")
        """
        # Find catalog entry BEFORE loading content so we can surface a
        # well-formed error even when the slug is valid but the markdown
        # file went missing (rare - would indicate a broken package build).
        entry = next((s for s in PLAYBOOKS_CATALOG if s["slug"] == slug), None)
        if entry is None:
            available = ", ".join(s["slug"] for s in PLAYBOOKS_CATALOG)
            return (
                f"Unknown playbook slug: {slug!r}. "
                f"Available slugs: {available}. "
                f"Call g8_list_playbooks to see the full catalog with descriptions."
            )

        content = get_playbook_content(slug)
        if content is None:
            return (
                f"Playbook {slug!r} is registered in the catalog but its markdown "
                f"file is missing on disk. This is a packaging bug - please "
                f"report it. Other playbooks should still load normally."
            )

        return PlaybookContentResult.from_entry(dict(entry), content)
