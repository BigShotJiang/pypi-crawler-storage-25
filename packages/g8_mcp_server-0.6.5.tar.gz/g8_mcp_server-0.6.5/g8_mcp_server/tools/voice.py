"""Voice / dialer MCP tools.

Wrappers around the public Developer API voice endpoints exposed by
``developer_api/interfaces/v1/voice_router.py``. These let an MCP agent
answer "what did the dialer do today?" / "how is SDR X pacing?" /
"create a session for tomorrow morning" without ever touching the voice
microservice directly.

Tool surface:
- Read (free, no credits): list_dialer_sessions, get_dialer_stats,
  list_numbers, list_missed_callbacks, get_call_grading,
  get_call_transcript, list_calls_for_contact, list_calls_for_sdr,
  list_agents.
- Write (no credits but mutates state): create_dialer_session,
  pause_session, stop_session.
- Destructive (places real calls): resume_session - dials the next
  batch of contacts from the session's source list.

Per-call SDR-frontend operations (manual_dial, redial, hangup, drop
voicemail, update disposition) intentionally stay out of this tool
surface. They require a Twilio browser conference and belong in the
dialer UI, not in chat.
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client
from g8_mcp_server.models import ConfirmationDetail, ConfirmationPreview
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Used for create / stop - actions that change real session state and
# warrant a confirmation prompt from MCP-aware clients.
_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    openWorldHint=True,
)
# Used for pause / resume - reversible state flips that do not destroy
# anything. We mark them idempotent so a double-call is a no-op.
_REVERSIBLE_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)


def _unwrap(resp: Any) -> Any:
    """Strip the ``ApiResponse`` envelope (``{"data": ...}``).

    Voice tools forward the inner payload to the agent so the model sees
    the same shape it would get from the OpenAPI docs of the underlying
    REST endpoint - no extra envelope nesting to confuse it.
    """
    if isinstance(resp, dict) and "data" in resp:
        return resp["data"]
    return resp


def register(server: FastMCP, client: G8Client, *, name_prefix: str = "voice") -> None:
    """Register the read-only voice / dialer tools.

    ``name_prefix`` mirrors the GTM convention (``g8_gtm_*`` etc.) so
    the tool names are unambiguous in mixed-mode servers. Pass an empty
    string to expose the bare ``g8_*_dialer_*`` names if a future mode
    wants to drop the namespace.
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    @server.tool(
        name=tool_name("list_dialer_sessions"),
        annotations=_READ_ONLY,
        # Renders ui://dialer/sessions card grid with pause/resume/stop actions.
        meta=ui_tool_meta("ui://dialer/sessions"),
    )
    async def list_dialer_sessions(
        page: int = 1,
        page_size: int = 50,
        status: str | None = None,
        user_email: str | None = None,
        name: str | None = None,
        campaign_id: str | None = None,
        list_id: str | None = None,
        list_name: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        sort_by: str | None = None,
        sort_order: str = "desc",
    ) -> dict[str, Any] | str:
        """List parallel dialer sessions for the caller's organization.

        Each row carries ``session_id``, ``status``, ``user_email``,
        campaign + list metadata, total_calls, and the aggregated
        ``contact_ids`` array. Combined with ``g8_voice_get_dialer_stats``
        this is enough to answer most "how did dialing go?" questions
        without the agent making a follow-up call.

        Args:
            page: 1-indexed page number.
            page_size: Rows per page (1-200).
            status: Comma-separated session statuses ("ACTIVE,PAUSED").
            user_email: Filter by SDR email (substring match).
            name: Filter by session name (substring match).
            campaign_id: Filter by campaign id (substring match).
            list_id: Exact list id stored inside session_metadata.
            list_name: Filter by list title (substring match).
            date_from: ISO timestamp - sessions created on/after.
            date_to: ISO timestamp - sessions created on/before.
            sort_by: Column name (created_at, updated_at, total_calls...).
            sort_order: "asc" or "desc". Defaults to "desc".
        """
        params: dict[str, Any] = {
            "page": max(1, page),
            "page_size": max(1, min(page_size, 200)),
            "sort_order": sort_order or "desc",
        }
        for key, value in (
            ("status", status),
            ("user_email", user_email),
            ("name", name),
            ("campaign_id", campaign_id),
            ("list_id", list_id),
            ("list_name", list_name),
            ("date_from", date_from),
            ("date_to", date_to),
            ("sort_by", sort_by),
        ):
            if value:
                params[key] = value
        try:
            return _unwrap(await client.get("/voice/dialer/sessions", params))
        except Exception as e:
            return f"List dialer sessions failed: {e}"

    # ------------------------------------------------------------------
    # Aggregated analytics
    # ------------------------------------------------------------------

    @server.tool(
        name=tool_name("get_dialer_stats"),
        annotations=_READ_ONLY,
        # Renders ui://dialer/stats detail view with metrics + summary.
        meta=ui_tool_meta("ui://dialer/stats"),
    )
    async def get_dialer_stats(
        session_id: str | None = None,
        user_email: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        aggregation: str = "DAILY",
    ) -> dict[str, Any] | str:
        """Get aggregated dialer analytics for the caller's org.

        Returns a report with:
          - ``filters``: echo of the filter set the server resolved
          - ``metrics``: list of per-day rows (when aggregation=DAILY)
            or one summary row (when aggregation=TOTAL)
          - ``summary``: optional overall summary regardless of grouping

        Each row includes total_dials, connection_rate, talk time,
        disposition breakdown, success_rate, redial stats, peak hour,
        and inbound callback counts.

        Args:
            session_id: Restrict to a single dialer session.
            user_email: Restrict to a single SDR's calls.
            date_from: Start date "YYYY-MM-DD".
            date_to: End date "YYYY-MM-DD".
            aggregation: "DAILY" (default) or "TOTAL".
        """
        params: dict[str, Any] = {"aggregation": aggregation or "DAILY"}
        for key, value in (
            ("session_id", session_id),
            ("user_email", user_email),
            ("date_from", date_from),
            ("date_to", date_to),
        ):
            if value:
                params[key] = value
        try:
            return _unwrap(await client.get("/voice/dialer/stats", params))
        except Exception as e:
            return f"Get dialer stats failed: {e}"

    # ------------------------------------------------------------------
    # Phone numbers
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("list_numbers"), annotations=_READ_ONLY)
    async def list_dialer_numbers(
        user_email: str | None = None,
    ) -> dict[str, Any] | str:
        """List the org's dialer-eligible phone numbers with usage stats.

        Use this before starting a session to pick a healthy number, or
        when triaging "why is this SDR not connecting" - low
        ``connect_rate_7d`` rows usually need provider-side attention.

        Args:
            user_email: Optional - restrict to numbers assigned to one SDR.
        """
        params: dict[str, Any] = {}
        if user_email:
            params["user_email"] = user_email
        try:
            return _unwrap(await client.get("/voice/dialer/numbers", params))
        except Exception as e:
            return f"List dialer numbers failed: {e}"

    # ------------------------------------------------------------------
    # Missed callbacks
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("list_missed_callbacks"), annotations=_READ_ONLY)
    async def list_missed_callbacks(
        limit: int = 50,
    ) -> dict[str, Any] | str:
        """Inbound calls the org missed (no SDR pickup), with caller info.

        Each row links back to the original outbound session via
        ``parallel_session_id`` so the agent can answer "did this lead
        try to call us back after our outreach?".

        Args:
            limit: Max rows to return (1-200, default 50).
        """
        params = {"limit": max(1, min(limit, 200))}
        try:
            return _unwrap(await client.get("/voice/dialer/missed-callbacks", params))
        except Exception as e:
            return f"List missed callbacks failed: {e}"

    # ------------------------------------------------------------------
    # Per-call AI grading
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("get_call_grading"), annotations=_READ_ONLY)
    async def get_call_grading(
        room_name: str,
    ) -> dict[str, Any] | str:
        """Fetch the AI-generated grading for a single dialer call.

        Returns ``{status: "pending"}`` if grading is still being
        computed (the call just ended). Returns the grading payload plus
        ``reviewed`` / ``reviewed_at`` once it is ready. Polling at
        ~10s intervals is safe.

        Args:
            room_name: The ``livekit_room_name`` identifier returned by
                ``g8_voice_list_dialer_sessions`` (or the row id from any
                CallResult-shaped surface).
        """
        try:
            return _unwrap(await client.get(f"/voice/dialer/calls/{room_name}/grading"))
        except Exception as e:
            return f"Get call grading failed: {e}"

    # ------------------------------------------------------------------
    # Per-call transcript + per-contact call listing
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("get_call_transcript"), annotations=_READ_ONLY)
    async def get_call_transcript(
        room_name: str,
    ) -> dict[str, Any] | str:
        """Fetch the full transcript for a single dialer call.

        Returns ``status: "ready"`` with a ``transcript`` array of
        ``{speaker, content, timestamp}`` segments, plus call metadata
        (summary, disposition, recording_url, contact_id, duration).
        Returns ``status: "empty"`` with ``transcript: []`` if the call
        ended but the transcript was never flushed (rare - usually an
        AMD-detected voicemail or instant hangup). The call row's
        ``summary`` field is still populated in the empty case.

        Org isolation is enforced upstream: a 404 means either the call
        does not exist OR it belongs to another org.

        Args:
            room_name: The ``livekit_room_name`` identifier returned by
                ``g8_voice_list_calls_for_contact`` or any CallResult row.
        """
        try:
            return _unwrap(await client.get(f"/voice/dialer/calls/{room_name}/transcript"))
        except Exception as e:
            return f"Get call transcript failed: {e}"

    @server.tool(name=tool_name("list_calls_for_contact"), annotations=_READ_ONLY)
    async def list_calls_for_contact(
        contact_id: str,
        limit: int = 20,
    ) -> dict[str, Any] | str:
        """List dialer calls for a specific contact, newest first.

        Returns summary rows ONLY - no transcript blob - so listings
        stay cheap. Each row carries ``room_name`` (the canonical call
        id), ``has_transcript`` (bool), ``disposition``, ``summary``,
        ``call_duration``, ``recording_url``, ``parallel_session_id``,
        ``from_``, ``to``, ``contact_id``, and ``created_at``. To pull
        the full transcript for any row, pass its ``room_name`` to
        ``g8_voice_get_call_transcript``.

        Args:
            contact_id: The graph8 contact id (``mashup_contacts.id``
                or the ``contact_id`` you used when creating the
                session). Treated as a string - pass numeric ids as
                their string form.
            limit: Max rows to return (1-100, default 20).
        """
        try:
            return _unwrap(
                await client.get(
                    "/voice/dialer/calls",
                    {"contact_id": contact_id, "limit": max(1, min(limit, 100))},
                )
            )
        except Exception as e:
            return f"List calls for contact failed: {e}"

    @server.tool(name=tool_name("list_calls_for_sdr"), annotations=_READ_ONLY)
    async def list_calls_for_sdr(
        user_email: str,
        created_after: str | None = None,
        parallel_session_id: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any] | str:
        """List dialer calls placed by a specific SDR, newest first.

        Returns summary rows ONLY - no transcript blob. Each row carries
        ``room_name`` (canonical call id), ``has_transcript`` (bool),
        ``disposition``, ``summary``, ``call_duration``, ``recording_url``,
        ``parallel_session_id``, ``contact_id``, ``from_``, ``to``
        (the number dialed), and ``created_at``. Use ``room_name`` with
        ``g8_voice_get_call_transcript`` to pull the full transcript for
        any single row.

        Built for external ingestion pipelines that poll an SDR's call
        history. Pass ``created_after`` to do incremental polling: use
        the max ``created_at`` from the previous page as the next
        ``created_after`` value.

        Args:
            user_email: SDR email (matches ``ParallelDialSession.user_email``).
                Returns only dialer rows (rows with a ``parallel_session_id``).
            created_after: Optional ISO-8601 timestamp. Only rows with
                ``created_at >= created_after`` are returned. Use for
                incremental polling.
            parallel_session_id: Optional - narrow to one session id.
                Combines with ``user_email`` via AND.
            limit: Max rows to return (1-100, default 20).
        """
        params: dict[str, Any] = {
            "user_email": user_email,
            "limit": max(1, min(limit, 100)),
        }
        if created_after:
            params["created_after"] = created_after
        if parallel_session_id:
            params["parallel_session_id"] = parallel_session_id
        try:
            return _unwrap(await client.get("/voice/dialer/calls", params))
        except Exception as e:
            return f"List calls for SDR failed: {e}"

    # ------------------------------------------------------------------
    # Agents lookup (read-only, but lives here because it backs the
    # create-session picker)
    # ------------------------------------------------------------------

    @server.tool(
        name=tool_name("list_agents"),
        annotations=_READ_ONLY,
        # Renders ui://voice/agents card grid.
        meta=ui_tool_meta("ui://voice/agents"),
    )
    async def list_agents(
        role: str | None = None,
        agent_status: str | None = None,
        entity_type: str | None = None,
        search: str | None = None,
    ) -> dict[str, Any] | str:
        """List voice agents (personas) available for a dialer session.

        Use this BEFORE calling ``g8_voice_create_dialer_session`` so you
        can present the user a real list of agents to pick from instead
        of guessing. Returns ``agent_id`` (UUID) plus name, role, status.

        Args:
            role: Filter by agent role (SDR, AE, Receptionist, CSM, etc.).
            agent_status: Filter by status (e.g. "active").
            entity_type: "agent" or "twin". Defaults to all.
            search: Substring match on agent name.
        """
        params = {
            "role": role,
            "agent_status": agent_status,
            "entity_type": entity_type,
            "search": search,
        }
        try:
            return _unwrap(await client.get("/voice/dialer/agents", params))
        except Exception as e:
            return f"List agents failed: {e}"

    # ------------------------------------------------------------------
    # Session lifecycle (write)
    # ------------------------------------------------------------------

    @server.tool(
        name=tool_name("create_dialer_session"),
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/create-dialer-session when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/create-dialer-session"),
    )
    async def create_dialer_session(
        name: str,
        from_phone: str,
        list_id: str | None = None,
        list_title: str | None = None,
        agent_id: str | None = None,
        agent_name: str | None = None,
        entity_type: str | None = None,
        studio_campaign_id: str | None = None,
        user_timezone: str | None = None,
        skip_voicemails: bool | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Create a new parallel-dialer session in PAUSED state.

        IMPORTANT: This creates a real session bound to the caller's org
        and SDR. ALWAYS confirm with the user FIRST, after gathering:
          - The list to dial (use ``g8_get_lists`` to look up ``list_id``).
          - The Studio campaign, if any (use ``g8_gtm_list_campaigns`` for
            ``studio_campaign_id``).
          - A session name they want.
          - The phone number to dial from (use ``g8_voice_list_numbers``).
          - The voice agent to use (use ``g8_voice_list_agents``).

        The session is created PAUSED. To actually start dialing, the SDR
        must open the dialer UI and join the Twilio conference - this
        tool only sets up the session row.

        Args:
            name: Session display name (e.g. "Tuesday cold dial - Q4 ICP").
            from_phone: Caller-ID number; must be one of the org's dialer
                numbers from ``g8_voice_list_numbers``.
            list_id: ID of the contact list to dial. Optional but
                strongly recommended - without it the SDR can only
                manual-dial.
            list_title: Display title for the list (e.g. "Q4 ICP").
            agent_id: Voice agent UUID from ``g8_voice_list_agents``.
            agent_name: Legacy V1 agent name fallback. Skip if you have
                ``agent_id``.
            entity_type: "agent" or "twin". Skip unless you know.
            studio_campaign_id: Optional Campaign Builder UUID linkage.
            user_timezone: IANA timezone for analytics grouping (e.g.
                "America/New_York"). Defaults to the SDR's setting.
            skip_voicemails: Per-session voicemail-skip override. None =
                use the SDR's default.
            dry_run: When True, return a confirmation preview instead of
                creating the session. Recommended pattern: call once with
                dry_run=True, render the confirmation widget, then call
                again with dry_run=False after the user confirms.
        """
        if dry_run:
            details = [
                ConfirmationDetail(label="Session name", value=name),
                ConfirmationDetail(label="From phone", value=from_phone),
            ]
            if list_id:
                details.append(ConfirmationDetail(label="List ID", value=list_id))
            if list_title:
                details.append(ConfirmationDetail(label="List title", value=list_title))
            if agent_id:
                details.append(ConfirmationDetail(label="Agent ID", value=agent_id))
            if agent_name:
                details.append(ConfirmationDetail(label="Agent name", value=agent_name))
            if studio_campaign_id:
                details.append(ConfirmationDetail(label="Studio campaign", value=studio_campaign_id))
            if entity_type:
                details.append(ConfirmationDetail(label="Entity type", value=entity_type))
            if user_timezone:
                details.append(ConfirmationDetail(label="Timezone", value=user_timezone))
            if skip_voicemails is not None:
                details.append(
                    ConfirmationDetail(label="Skip voicemails", value=str(skip_voicemails).lower())
                )
            confirm_args: dict[str, Any] = {
                "name": name,
                "from_phone": from_phone,
                "list_id": list_id,
                "list_title": list_title,
                "agent_id": agent_id,
                "agent_name": agent_name,
                "entity_type": entity_type,
                "studio_campaign_id": studio_campaign_id,
                "user_timezone": user_timezone,
                "skip_voicemails": skip_voicemails,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Create dialer session",
                summary=f"Create paused dialer session \"{name}\" calling from {from_phone}.",
                details=details,
                warning="Session is created in PAUSED state. The SDR must open the dialer UI to begin actual calls.",
                cost_label=None,
                confirm_tool=tool_name("create_dialer_session"),
                confirm_args=confirm_args,
                confirm_label="Create session",
                cancel_label="Cancel",
            ).model_dump()
        body = {
            "name": name,
            "from_phone": from_phone,
            "list_id": list_id,
            "list_title": list_title,
            "agent_id": agent_id,
            "agent_name": agent_name,
            "entity_type": entity_type,
            "studio_campaign_id": studio_campaign_id,
            "user_timezone": user_timezone,
            "skip_voicemails": skip_voicemails,
        }
        body = {k: v for k, v in body.items() if v is not None}
        try:
            return _unwrap(await client.post("/voice/dialer/sessions", body=body))
        except Exception as e:
            return f"Create dialer session failed: {e}"

    async def _patch_status(session_id: str, target_status: str) -> dict[str, Any] | str:
        """Shared helper for the three lifecycle PATCH tools."""
        try:
            return _unwrap(
                await client.patch(
                    f"/voice/dialer/sessions/{session_id}/status",
                    body={"status": target_status},
                )
            )
        except Exception as e:
            return f"Update session status failed: {e}"

    @server.tool(
        name=tool_name("pause_session"),
        annotations=_REVERSIBLE_WRITE,
        # Refresh the same dialer sessions widget after the state flip.
        meta=ui_tool_meta("ui://dialer/sessions"),
    )
    async def pause_session(session_id: str) -> dict[str, Any] | str:
        """Pause an active parallel-dialer session.

        Reversible - call ``g8_voice_resume_session`` to flip it back to
        ACTIVE. Idempotent: pausing a session that is already PAUSED is
        a no-op.

        Args:
            session_id: Session UUID from
                ``g8_voice_list_dialer_sessions`` or
                ``g8_voice_create_dialer_session``.
        """
        return await _patch_status(session_id, "PAUSED")

    @server.tool(
        name=tool_name("resume_session"),
        annotations=_DESTRUCTIVE,
        # Refresh the same dialer sessions widget after dialing the next batch.
        meta=ui_tool_meta("ui://dialer/sessions"),
    )
    async def resume_session(
        session_id: str,
        max_contacts: int = 4,
    ) -> dict[str, Any] | str:
        """Resume a paused parallel-dialer session by dialing the next batch.

        Mirrors the dialer UI's "Start Dialing" button on a paused
        session: the backend reads the source list and ``list_offset``
        cursor stored in ``session_metadata``, skips any contacts already
        called in this session, and forwards the next batch (up to 4) to
        voice's start-session endpoint. The session row flips to ACTIVE
        and real outbound calls are placed.

        IMPORTANT: This actually dials phone numbers and consumes telephony
        capacity. ALWAYS confirm with the user before calling. Not
        idempotent - each call advances the list cursor and starts a new
        batch of calls.

        Returns the voice service's response plus ``dialed_count`` (the
        number of calls actually placed in this batch). It can be lower
        than ``max_contacts`` when the list is near exhausted, the
        remaining rows have no usable phone, or every candidate was
        already called earlier in the session.

        Args:
            session_id: Session UUID from
                ``g8_voice_list_dialer_sessions`` or
                ``g8_voice_create_dialer_session``.
            max_contacts: Number of contacts to dial in this batch
                (1-4). Voice caps parallel dialing at 4. Defaults to 4.
        """
        # Clamp client-side too so an over-large value doesn't roundtrip
        # for a 422 - the route also enforces this.
        clamped = max(1, min(int(max_contacts or 4), 4))
        try:
            return _unwrap(
                await client.post(
                    f"/voice/dialer/sessions/{session_id}/resume",
                    body={"max_contacts": clamped},
                )
            )
        except Exception as e:
            return f"Resume session failed: {e}"

    @server.tool(
        name=tool_name("stop_session"),
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/stop-dialer-session when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/stop-dialer-session"),
    )
    async def stop_session(session_id: str, dry_run: bool = False) -> dict[str, Any] | str:
        """Stop a parallel-dialer session permanently.

        IMPORTANT: This marks the session COMPLETED. It is one-way -
        re-opening a stopped session is only possible from the dialer UI
        via manual-dial. ALWAYS confirm with the user before calling.
        Recommended flow: call once with `dry_run=True` to render a
        confirmation widget, then again with `dry_run=False` after the
        user confirms.

        Args:
            session_id: Session UUID.
            dry_run: When True, return a confirmation preview instead of stopping.
        """
        if dry_run:
            return ConfirmationPreview(
                action_label="Stop dialer session",
                summary=f"Permanently stop dialer session {session_id}.",
                details=[
                    ConfirmationDetail(label="Session ID", value=session_id),
                    ConfirmationDetail(label="Target status", value="COMPLETED"),
                ],
                warning="This is one-way. Re-opening requires the dialer UI manual-dial flow.",
                cost_label=None,
                confirm_tool=tool_name("stop_session"),
                confirm_args={
                    "session_id": session_id,
                    "dry_run": False,
                },
                confirm_label="Stop session",
                cancel_label="Cancel",
            ).model_dump()
        return await _patch_status(session_id, "COMPLETED")
