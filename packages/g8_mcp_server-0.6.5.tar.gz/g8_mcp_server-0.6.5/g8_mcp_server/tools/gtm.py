"""GTM mode tools - org-scoped operations for campaign managers."""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import (
    ActionResult,
    AdImageHideResult,
    AdImagesResult,
    CampaignDocumentsResult,
    CampaignIdeasResult,
    CampaignSequenceResult,
    CampaignsResult,
    ConfirmationDetail,
    ConfirmationPreview,
    GlobalContextsResult,
    IcpsResult,
    KBDocumentsResult,
    KBResult,
    PersonasResult,
    ResourceDetail,
)
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Campaign-builder creates/updates mutate draft state but don't launch
# outreach - _WRITE. `launch_campaign` and the `delete_*` siblings stay
# _DESTRUCTIVE because they either send real messages or remove records.
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client, *, name_prefix: str = "") -> None:
    """Register GTM-mode tools.

    When ``name_prefix`` is provided, GTM tool names are namespaced to avoid
    collisions with dev-mode tools in combined `all` mode.
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    @server.tool(
        name=tool_name("list_campaigns"),
        annotations=_READ_ONLY,
        # Link to the interactive dashboard App: MCP Apps-aware hosts will
        # fetch `ui://campaigns/dashboard` and render it inline whenever this
        # tool fires. Non-App clients still get the same structured result
        # as before  -  the `meta` is purely additive.
        meta=ui_tool_meta("ui://campaigns/dashboard"),
    )
    async def list_campaigns(page: int = 1, limit: int = 50) -> CampaignsResult | str:
        """List campaigns in your organization."""
        return await safe_call_typed(
            client.get("/campaigns", {"page": page, "limit": limit}),
            CampaignsResult.from_envelope,
            context="Campaign list",
        )

    @server.tool(
        name=tool_name("get_ad_images"),
        annotations=_READ_ONLY,
        # Drives the `ui://campaigns/ad-images` App: users see a grid of
        # creatives with a Hide action per card.
        meta=ui_tool_meta("ui://campaigns/ad-images"),
    )
    async def get_ad_images(campaign_id: str) -> AdImagesResult | str:
        """List ad image creatives for one campaign.

        Returns every ad image that hasn't been marked hidden. The
        result drives an interactive grid in MCP Apps-aware hosts and
        reads as a structured list elsewhere.
        """
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/ad-images"),
            AdImagesResult.from_envelope,
            context="Campaign ad images",
        )

    @server.tool(
        name=tool_name("hide_ad_image"),
        # Idempotent "mark as hidden"  -  not destructive in the GDPR sense
        # (data is retained, just filtered out of listings). Not strictly
        # read-only either; classify as _WRITE.
        annotations=_WRITE,
        meta=ui_tool_meta("ui://campaigns/ad-images"),
    )
    async def hide_ad_image(campaign_id: str, image_id: str) -> AdImageHideResult | str:
        """Hide one ad creative from the campaign's grid.

        Sets `feedback='down'` on the underlying `cb_website_images` row so
        it drops out of future listings. Idempotent  -  hiding an
        already-hidden image is a no-op that still succeeds.
        """
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/ad-images/{image_id}/hide", body={}),
            AdImageHideResult.from_envelope,
            context="Hide ad image",
        )

    @server.tool(name=tool_name("get_campaign"), annotations=_READ_ONLY)
    async def get_campaign(campaign_id: str) -> ResourceDetail | str:
        """Get full campaign details including content and documents."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}"),
            ResourceDetail.from_envelope,
            context="Campaign",
        )

    @server.tool(name=tool_name("list_campaign_documents"), annotations=_READ_ONLY)
    async def list_campaign_documents(campaign_id: str) -> CampaignDocumentsResult | str:
        """List document metadata for a campaign."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/documents"),
            CampaignDocumentsResult.from_envelope,
            context="Campaign documents",
        )

    @server.tool(name=tool_name("get_campaign_document"), annotations=_READ_ONLY)
    async def get_campaign_document(campaign_id: str, document_id: str) -> ResourceDetail | str:
        """Get the full content of a campaign document."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/documents/{document_id}"),
            ResourceDetail.from_envelope,
            context="Campaign document",
        )

    @server.tool(name=tool_name("create_campaign"), annotations=_WRITE)
    async def create_campaign(
        name: str,
        category: str = "Outbound",
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        goal: str | None = None,
    ) -> ActionResult | str:
        """Create a new campaign draft."""
        body = {
            key: value
            for key, value in {
                "name": name,
                "category": category,
                "brief": brief,
                "core_concept": core_concept,
                "primary_hook": primary_hook,
                "target_persona": target_persona,
                "goal": goal,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.post("/campaigns", body),
            ActionResult.from_envelope,
            context="Campaign creation",
        )

    @server.tool(name=tool_name("update_campaign"), annotations=_WRITE)
    async def update_campaign(
        campaign_id: str,
        name: str | None = None,
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        category: str | None = None,
        goal: str | None = None,
    ) -> ActionResult | str:
        """Update campaign strategy fields or metadata."""
        body = {
            key: value
            for key, value in {
                "name": name,
                "brief": brief,
                "core_concept": core_concept,
                "primary_hook": primary_hook,
                "target_persona": target_persona,
                "category": category,
                "goal": goal,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.patch(f"/campaigns/{campaign_id}", body),
            ActionResult.from_envelope,
            context="Campaign update",
        )

    @server.tool(name=tool_name("create_campaign_document"), annotations=_WRITE)
    async def create_campaign_document(
        campaign_id: str,
        file_type: str,
        display_name: str,
        content: str = "",
        folder_path: str | None = None,
        status: str = "draft",
    ) -> ActionResult | str:
        """Create a new campaign document."""
        body = {
            "file_type": file_type,
            "display_name": display_name,
            "content": content,
            "folder_path": folder_path,
            "status": status,
        }
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/documents", body=body),
            ActionResult.from_envelope,
            context="Document creation",
        )

    @server.tool(name=tool_name("update_campaign_document"), annotations=_WRITE)
    async def update_campaign_document(
        campaign_id: str,
        document_id: str,
        content: str,
        status: str | None = None,
        structured_data: dict | None = None,
    ) -> ActionResult | str:
        """Save edits back to a campaign document."""
        body = {
            key: value
            for key, value in {
                "content": content,
                "status": status,
                "structured_data": structured_data,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/documents/{document_id}", body),
            ActionResult.from_envelope,
            context="Document update",
        )

    @server.tool(name=tool_name("delete_campaign_document"), annotations=_DESTRUCTIVE)
    async def delete_campaign_document(campaign_id: str, document_id: str) -> ActionResult | str:
        """Delete a campaign document."""
        return await safe_call_typed(
            client.delete(f"/campaigns/{campaign_id}/documents/{document_id}"),
            ActionResult.from_envelope,
            context="Document",
        )

    @server.tool(name=tool_name("get_campaign_sequence"), annotations=_READ_ONLY)
    async def get_campaign_sequence(campaign_id: str) -> CampaignSequenceResult | str:
        """Get the campaign sequence and step catalog."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/sequence"),
            CampaignSequenceResult.from_envelope,
            context="Campaign sequence",
        )

    @server.tool(name=tool_name("update_campaign_sequence"), annotations=_WRITE)
    async def update_campaign_sequence(campaign_id: str, steps: list[dict]) -> ActionResult | str:
        """Replace the campaign sequence ordering with a new step list."""
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/sequence", {"steps": steps}),
            ActionResult.from_envelope,
            context="Sequence update",
        )

    @server.tool(name=tool_name("create_campaign_step"), annotations=_WRITE)
    async def create_campaign_step(
        campaign_id: str,
        name: str,
        channel: str,
        mode: str,
        day: int,
        platform: str | None = None,
        angle_id: str = "angle_1",
        cta_type: str = "soft_ask",
        personalization_level: str = "medium",
        constraints: dict | None = None,
        condition: str | None = None,
        stop_on_reply: bool = True,
    ) -> ActionResult | str:
        """Add a step to a campaign sequence."""
        body = {
            "name": name,
            "channel": channel,
            "mode": mode,
            "day": day,
            "platform": platform,
            "angle_id": angle_id,
            "cta_type": cta_type,
            "personalization_level": personalization_level,
            "constraints": constraints or {},
            "condition": condition,
            "stop_on_reply": stop_on_reply,
        }
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/sequence/steps", body),
            ActionResult.from_envelope,
            context="Step creation",
        )

    @server.tool(name=tool_name("update_campaign_step"), annotations=_WRITE)
    async def update_campaign_step(
        campaign_id: str,
        step_id: str,
        name: str | None = None,
        channel: str | None = None,
        mode: str | None = None,
        platform: str | None = None,
        angle_id: str | None = None,
        cta_type: str | None = None,
        personalization_level: str | None = None,
        constraints: dict | None = None,
        do_not_send_rules: list[str] | None = None,
        day: int | None = None,
        condition: str | None = None,
        stop_on_reply: bool | None = None,
    ) -> ActionResult | str:
        """Update a campaign sequence step definition or placement."""
        body = {
            key: value
            for key, value in {
                "name": name,
                "channel": channel,
                "mode": mode,
                "platform": platform,
                "angle_id": angle_id,
                "cta_type": cta_type,
                "personalization_level": personalization_level,
                "constraints": constraints,
                "do_not_send_rules": do_not_send_rules,
                "day": day,
                "condition": condition,
                "stop_on_reply": stop_on_reply,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/sequence/steps/{step_id}", body),
            ActionResult.from_envelope,
            context="Step update",
        )

    @server.tool(name=tool_name("delete_campaign_step"), annotations=_DESTRUCTIVE)
    async def delete_campaign_step(campaign_id: str, step_id: str) -> ActionResult | str:
        """Remove a step from the campaign sequence."""
        return await safe_call_typed(
            client.delete(f"/campaigns/{campaign_id}/sequence/steps/{step_id}"),
            ActionResult.from_envelope,
            context="Step",
        )

    @server.tool(
        name=tool_name("launch_campaign"),
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/launch-campaign when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/launch-campaign"),
    )
    async def launch_campaign(
        campaign_id: str, dry_run: bool = False
    ) -> ConfirmationPreview | ActionResult | str:
        """Launch a campaign to begin outbound execution.

        IMPORTANT: This sends real outreach. Recommended flow: call with
        `dry_run=True` first to render a confirmation widget, then again with
        `dry_run=False` after the user confirms.

        Args:
            campaign_id: Campaign to launch (from g8_gtm_list_campaigns).
            dry_run: When True, return a confirmation preview instead of launching.
        """
        if dry_run:
            return ConfirmationPreview(
                action_label="Launch campaign",
                summary=f"Launch campaign {campaign_id} - this begins outbound execution.",
                details=[
                    ConfirmationDetail(label="Campaign ID", value=campaign_id),
                ],
                warning="Real outbound messages will start sending to enrolled contacts.",
                cost_label=None,
                confirm_tool=tool_name("launch_campaign"),
                confirm_args={
                    "campaign_id": campaign_id,
                    "dry_run": False,
                },
                confirm_label="Launch campaign",
                cancel_label="Cancel",
            )
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/launch"),
            ActionResult.from_envelope,
            context="Campaign launch",
        )

    @server.tool(name=tool_name("get_global_context"), annotations=_READ_ONLY)
    async def get_global_context(category: str | None = None, limit: int = 50) -> GlobalContextsResult | str:
        """List global context documents available for campaign work."""
        return await safe_call_typed(
            client.get("/global-context/documents", {"category": category, "limit": limit}),
            GlobalContextsResult.from_envelope,
            context="Global context",
        )

    @server.tool(
        name=tool_name("get_personas"),
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://personas/list"),
    )
    async def get_personas(status: str | None = None, limit: int = 50) -> PersonasResult | str:
        """List personas available for campaign targeting."""
        return await safe_call_typed(
            client.get("/personas", {"status": status, "limit": limit}),
            PersonasResult.from_envelope,
            context="Personas",
        )

    @server.tool(
        name=tool_name("get_icps"),
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://icps/list"),
    )
    async def get_icps(status: str | None = None, limit: int = 50) -> IcpsResult | str:
        """List ICPs available for campaign targeting."""
        return await safe_call_typed(
            client.get("/icps", {"status": status, "limit": limit}),
            IcpsResult.from_envelope,
            context="ICPs",
        )

    @server.tool(name=tool_name("get_campaign_ideas"), annotations=_READ_ONLY)
    async def get_campaign_ideas(favorited: bool | None = None, limit: int = 50) -> CampaignIdeasResult | str:
        """List saved campaign ideas."""
        return await safe_call_typed(
            client.get("/campaigns/ideas", {"favorited": favorited, "limit": limit}),
            CampaignIdeasResult.from_envelope,
            context="Campaign ideas",
        )

    @server.tool(name=tool_name("search_kb"), annotations=_READ_ONLY)
    async def search_kb(query: str) -> KBResult | str:
        """Search the GTM knowledge base."""
        return await safe_call_typed(
            client.post("/kb/search", {"query": query}),
            KBResult.from_envelope,
            context="KB search",
        )

    @server.tool(name=tool_name("list_kb_documents"), annotations=_READ_ONLY)
    async def list_kb_documents() -> KBDocumentsResult | str:
        """List all documents in the GTM knowledge base."""
        return await safe_call_typed(
            client.get("/kb"),
            KBDocumentsResult.from_envelope,
            context="KB documents",
        )
