"""Skill authoring MCP tools (``g8_skill_*`` + ``g8_workflow_skill_*`` aliases).

Wrappers around the public Developer API skills endpoints exposed by
``developer_api/interfaces/v1/skills_router.py``. These let an MCP
agent author, list, validate, execute, and lift skills - the LLM and
API runtimes of voice's ``/api/v1/actions/*`` surface.

Naming convention (every tool registered under TWO names):
  - ``g8_skill_*``           - original / canonical (existing callers).
  - ``g8_workflow_skill_*``  - alias under the workflow namespace, so
    the agent sees skill authoring as part of the workflow toolbelt
    when it enumerates ``g8_workflow_*`` tools. Skill authoring is
    almost always used WITH workflow building (create skill -> wire
    via Action node), and the namespaced alias makes that obvious.
  - Both names point at the same handler; pick whichever fits the
    surrounding agent context. Removing the legacy ``g8_skill_*``
    surface is intentionally NOT done now to preserve back-compat.
  - ``tools/playbooks.py`` (``g8_list_playbooks`` / ``g8_load_playbook``)
    is a different surface entirely - it serves prescriptive workflow
    markdown for the agent to read, not skill authoring. It was named
    ``g8_list_skills`` / ``g8_load_skill`` prior to v0.6.3 - that
    overload was the original reason MCP clients sometimes picked the
    wrong family. Renamed to "playbook" for unambiguous separation.

Tool surface (14 base tools, each registered under both prefixes):
  Read / discover (5)
    - {prefix}_list                  list LLM + API skills
    - {prefix}_get                   full skill detail
    - {prefix}_extract_variables     {var} placeholders from a skill
    - {prefix}_list_models           supported LLM model ids
    - {prefix}_list_templates        template catalog

  Build / edit (5)
    - {prefix}_create_llm            create LLM-runtime skill (DESTRUCTIVE)
    - {prefix}_create_api            create API-runtime skill (DESTRUCTIVE)
    - {prefix}_update_llm            patch LLM-runtime skill
    - {prefix}_update_api            patch API-runtime skill
    - {prefix}_delete                delete (refuses if referenced by a
                                     workflow node) (DESTRUCTIVE)

  Validate / lift (3)
    - {prefix}_validate_template     dry-run template validate (warn-only)
    - {prefix}_create_from_template  clone a template (DESTRUCTIVE)
    - {prefix}_create_from_node      lift a workflow action node into a
                                     standalone skill (DESTRUCTIVE)

  Execute (1)
    - {prefix}_execute               run once (DESTRUCTIVE)

When to author an LLM skill (READ BEFORE PICKING A WORKFLOW NODE):
  ANY natural-language sub-step of a workflow - "summarize this thread",
  "generate a follow-up email", "extract the time delay from a reply",
  "classify the objection", "draft a Slack message" - belongs in an
  ``llm_completion`` Action node bound to an LLM skill you create
  here, NOT in an ``agent`` node.

  Pattern (use this every time):
    1. ``g8_workflow_skill_create_llm`` (or ``g8_skill_create_llm``)
       with a prompt template containing ``{variable}`` placeholders
       for every input the step needs from upstream (thread body,
       contact name, objection text, etc.). For deterministic
       downstream wiring - e.g. a Delay node that must consume a
       number of days - say so explicitly in the prompt ("Reply with
       ONLY an integer number of days, nothing else.").
    2. Add an ``llm_completion`` (Action) node to the workflow whose
       ``action_id`` is the new skill. ``g8_workflow_add_node`` will
       auto-stub ``input_mappings`` for every variable; fill each one
       with a ``{{trigger.*}}`` / ``{{node_id.*}}`` reference.
    3. Reference the skill's output downstream as
       ``{{<node_id>.result}}`` (or ``${<node_id>.result}`` in some
       node types - see ``g8_workflow_describe_node_type``).

  Use an ``agent`` node ONLY when the step needs autonomous multi-turn
  tool use (browse, search, decide, call MCP tools). A single-turn LLM
  call is ALWAYS cheaper, more deterministic, and more re-usable as an
  Action+skill. Summarize / generate / extract / classify = Action+skill.

Per the PRD lock (5.3): delete does an MCP-only soft-delete by
querying workflows for references. If any workflow node references the
skill, the tool refuses and lists the offending workflows. If no
references exist, the tool forwards the DELETE to voice (hard-delete).
No restore - once nothing references it, deletion is final.

Per the PRD lock (5.2): create_from_node is implemented end-to-end on
the developer_api side at POST /skills/from-node which routes through
the same POST /api/v1/actions/create that create_llm / create_api use.
Lift skills are byte-identical to authored skills.

Progressive discovery: NONE of these tools belong in the always-on
catalog. Skill authoring is a deep niche - surface widening via
``g8_tool_search`` is the right entry point. The agent typically
arrives here from a workflow-building task (after ``g8_workflow_*``
shows up via discovery), which is why the alias prefix exists.

Backwards compatibility: this module is purely additive. All shapes
pass through the developer_api proxy as ``Dict[str, Any]`` so schema
additions on the voice side never break MCP clients. Both name
prefixes are guaranteed to remain callable.
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client
from g8_mcp_server.models import (
    ConfirmationDetail,
    ConfirmationPreview,
    SkillValidateResult,
    SkillVariableExtractResult,
)

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# create / delete / execute - flips real persisted state.
_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    openWorldHint=True,
)
# update - reversible (you can update back to the prior value).
_REVERSIBLE_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)


def _unwrap(resp: Any) -> Any:
    """Strip the developer_api ``ApiResponse`` envelope when present.

    The /skills/* routes mostly pass through voice's payload directly
    (no envelope), but tolerate both shapes so future router-side
    wrapping doesn't break clients.
    """
    if isinstance(resp, dict) and "data" in resp and len(resp) <= 3:
        keys = set(resp.keys())
        if keys.issubset({"data", "pagination", "meta", "success"}):
            return resp["data"]
    return resp


def _action_from_resp(resp: Any) -> dict[str, Any] | None:
    """Pull the action dict out of a voice response. Voice's GET wraps
    as ``{"success": true, "action": {...}}``; create/update return the
    flat dict. Match either shape."""
    if not isinstance(resp, dict):
        return None
    if isinstance(resp.get("action"), dict):
        return resp["action"]
    if "action_id" in resp or "runtime_type" in resp:
        return resp
    return None


# ---------------------------------------------------------------------------
# Workflow-reference scanner (used by g8_skill_delete)
#
# A "reference" is any workflow node whose config.action_id matches the
# skill being deleted. The skills surface intentionally returns 404 for
# workflow rows, so we have to read from /workflows directly.
# ---------------------------------------------------------------------------


async def _workflows_referencing_skill(
    client: G8Client,
    skill_id: str,
) -> list[dict[str, str]]:
    """Return ``[{"workflow_id", "workflow_name", "node_id"}, ...]`` for
    every workflow node in the caller's org whose config points at
    ``skill_id``. Empty list when nothing references it.

    Reads /workflows for the org, then GETs each one (we need the full
    graph - list doesn't include nodes). Cost is one list + N gets where
    N is the number of workflows. Acceptable for the delete confirmation
    path; for catalogs much larger than ~50 workflows we'd want a
    dedicated ``/skills/{id}/references`` route - punt until that scale.
    """
    refs: list[dict[str, str]] = []
    try:
        wf_list = _unwrap(await client.get("/workflows"))
    except Exception:
        return refs
    if not isinstance(wf_list, dict):
        return refs
    actions = wf_list.get("actions") or []
    if not isinstance(actions, list):
        return refs

    for wf_summary in actions:
        if not isinstance(wf_summary, dict):
            continue
        wf_id = wf_summary.get("action_id")
        if not isinstance(wf_id, str):
            continue
        try:
            wf_full = _unwrap(await client.get(f"/workflows/{wf_id}"))
        except Exception:
            continue
        if not isinstance(wf_full, dict):
            continue
        action = _action_from_resp(wf_full) or wf_full
        config = action.get("config") or action.get("skill_config")
        if not isinstance(config, dict):
            continue
        nodes = config.get("nodes")
        if not isinstance(nodes, list):
            continue
        for n in nodes:
            if not isinstance(n, dict):
                continue
            ncfg = n.get("config")
            if not isinstance(ncfg, dict):
                data = n.get("data")
                if isinstance(data, dict) and isinstance(data.get("config"), dict):
                    ncfg = data["config"]
            if not isinstance(ncfg, dict):
                continue
            ref = ncfg.get("action_id") or ncfg.get("actionId")
            if ref == skill_id:
                refs.append(
                    {
                        "workflow_id": wf_id,
                        "workflow_name": str(wf_summary.get("name") or ""),
                        "node_id": str(n.get("node_id") or n.get("nodeId") or n.get("id") or ""),
                    }
                )
    return refs


def register(
    server: FastMCP,
    client: G8Client,
    *,
    name_prefix: str = "skill",
    alias_prefixes: tuple[str, ...] = ("workflow_skill",),
) -> None:
    """Register the skill authoring MCP tools.

    Each tool is registered under ``name_prefix`` (canonical) AND under
    every entry in ``alias_prefixes`` (additional callable names). The
    aliases share the same handler function - calling either name routes
    to the same underlying coroutine. This keeps existing callers using
    the legacy ``g8_skill_*`` names working while also exposing the
    ``g8_workflow_skill_*`` namespace so the agent treats skill
    authoring as part of the workflow toolbelt.

    Pass ``name_prefix=""`` to expose bare ``g8_*`` names (no callers
    do today). Pass ``alias_prefixes=()`` to disable aliasing entirely.
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    # ------------------------------------------------------------------
    # Read / discover
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("list"), annotations=_READ_ONLY)
    async def list_skills(
        runtime_type: str | None = None,
        enabled: bool | None = None,
        category: str | None = None,
        object_type: str | None = None,
        include_system: bool = True,
    ) -> dict[str, Any] | str:
        """List skills (LLM + API runtimes) owned by the caller's org.

        Workflows live behind ``g8_workflow_list`` and are not shown
        here. Script-runtime actions are hidden.

        Args:
            runtime_type: Filter to ``"llm"`` or ``"api"``. Omit to see both.
            enabled: Filter by enabled flag.
            category: Filter by free-text category (e.g. ``"Sales"``).
            object_type: Filter by entity target -
                ``"Company"|"Contact"|"Deal"|"Campaign"``. Omit for global.
            include_system: When True (default), shared system-default
                skills are merged in alongside org-owned ones.
        """
        params: dict[str, Any] = {"include_system": include_system}
        if runtime_type:
            params["runtime_type"] = runtime_type
        if enabled is not None:
            params["enabled"] = enabled
        if category:
            params["category"] = category
        if object_type:
            params["object_type"] = object_type
        try:
            return _unwrap(await client.get("/skills", params))
        except Exception as e:
            return f"List skills failed: {e}"

    @server.tool(name=tool_name("get"), annotations=_READ_ONLY)
    async def get_skill(action_id: str) -> dict[str, Any] | str:
        """Get a skill's full configuration (metadata + llm_config or api_config).

        Returns 404 if the action_id is a workflow or script - the skill
        surface is sealed. Use ``g8_workflow_get`` for workflow rows.

        Args:
            action_id: Skill UUID.
        """
        if not action_id:
            return "Error: action_id is required."
        try:
            return _unwrap(await client.get(f"/skills/{action_id}"))
        except Exception as e:
            return f"Get skill failed: {e}"

    @server.tool(name=tool_name("extract_variables"), annotations=_READ_ONLY)
    async def extract_variables(action_id: str) -> SkillVariableExtractResult | str:
        """Extract ``{variable}`` placeholders from a skill's templates.

        Single-brace regex: ``\\{(\\w+)\\}``. Variables are deduplicated
        and returned in first-seen order so prompt UIs are deterministic.
        Double-brace patterns (``{{var}}``) are intentionally ignored.

        For LLM skills: scans ``llm_config.prompt_template``.
        For API skills: scans ``api_config.endpoint``, ``body_template``,
        every header value, and every query param value.

        Use this BEFORE wiring the skill into a workflow Action node so
        you know which input mappings to declare on the upstream trigger.

        Args:
            action_id: Skill UUID.
        """
        if not action_id:
            return "Error: action_id is required."
        try:
            resp = _unwrap(await client.get(f"/skills/{action_id}/variables"))
        except Exception as e:
            return f"Extract variables failed: {e}"
        if not isinstance(resp, dict):
            return "Extract variables returned an unexpected shape."
        return SkillVariableExtractResult.model_validate(resp)

    @server.tool(name=tool_name("list_models"), annotations=_READ_ONLY)
    async def list_models() -> dict[str, Any] | str:
        """List supported LLM model identifiers for the ``model`` field of
        ``g8_skill_create_llm`` / ``g8_skill_update_llm``.

        Returns ``{models: [{id, provider, label}], total: N}``. Curated
        list - voice ultimately decides which models route to which
        provider, and the create/update endpoints accept any string.
        """
        try:
            return _unwrap(await client.get("/skills/models"))
        except Exception as e:
            return f"List models failed: {e}"

    @server.tool(name=tool_name("list_templates"), annotations=_READ_ONLY)
    async def list_templates(category: str | None = None) -> dict[str, Any] | str:
        """List skill templates available in the caller's org (plus shared
        system templates).

        Workflow templates are filtered out - use ``g8_workflow_list`` for
        those. Use the returned ``action_id`` with
        ``g8_skill_create_from_template`` to instantiate a copy into the org.

        Args:
            category: Optional category filter.
        """
        params: dict[str, Any] = {}
        if category:
            params["category"] = category
        try:
            return _unwrap(await client.get("/skills/templates", params))
        except Exception as e:
            return f"List templates failed: {e}"

    # ------------------------------------------------------------------
    # Build / edit
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("create_llm"), annotations=_DESTRUCTIVE)
    async def create_llm_skill(
        name: str,
        model: str,
        prompt_template: str,
        description: str | None = None,
        category: str | None = None,
        object_type: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        requires_approval: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Create an LLM-runtime skill.

        IMPORTANT: this persists a new skill in the org. Confirm with the
        user before calling with ``dry_run=False``. Recommended pattern:
        first call with ``dry_run=True`` to render a confirmation widget,
        then again after the user confirms.

        ``g8_skill_create_from_node`` (lift) routes through the SAME
        underlying endpoint, so an LLM skill created this way is
        byte-identical to one lifted from a workflow action node.

        Args:
            name: Display name.
            model: Model id from ``g8_skill_list_models`` (e.g. ``"gpt-4o"``).
            prompt_template: Prompt template. Use ``{variable}`` for
                inputs - they're extracted by
                ``g8_skill_extract_variables`` and become the skill's
                input surface.
            description: Optional human-readable summary.
            category: Optional grouping (e.g. ``"Research"``, ``"Sales"``).
            object_type: Optional entity target -
                ``"Company"|"Contact"|"Deal"|"Campaign"``. ``None`` (default)
                means the skill applies globally.
            temperature: LLM temperature (default 0.7).
            max_tokens: Max output tokens (default 1000).
            requires_approval: Force manual approval before execution
                (default False).
            dry_run: When True, return a confirmation preview instead of
                persisting.
        """
        if not name or not model or not prompt_template:
            return "Error: name, model, and prompt_template are required."

        if dry_run:
            details = [
                ConfirmationDetail(label="Name", value=name),
                ConfirmationDetail(label="Runtime", value="llm"),
                ConfirmationDetail(label="Model", value=model),
                ConfirmationDetail(label="Temperature", value=str(temperature)),
                ConfirmationDetail(label="Max tokens", value=str(max_tokens)),
            ]
            if category:
                details.append(ConfirmationDetail(label="Category", value=category))
            if object_type:
                details.append(ConfirmationDetail(label="Object type", value=object_type))
            confirm_args: dict[str, Any] = {
                "name": name,
                "model": model,
                "prompt_template": prompt_template,
                "description": description,
                "category": category,
                "object_type": object_type,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "requires_approval": requires_approval,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Create LLM skill",
                summary=f'Create LLM skill "{name}" using model {model}.',
                details=details,
                confirm_tool=tool_name("create_llm"),
                confirm_args=confirm_args,
                confirm_label="Create skill",
                cancel_label="Cancel",
            ).model_dump()

        body: dict[str, Any] = {
            "name": name,
            "runtime_type": "llm",
            "llm_config": {
                "model": model,
                "prompt_template": prompt_template,
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
            "requires_approval": requires_approval,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if object_type is not None:
            body["object_type"] = object_type
        try:
            return _unwrap(await client.post("/skills", body=body))
        except Exception as e:
            return f"Create LLM skill failed: {e}"

    @server.tool(name=tool_name("create_api"), annotations=_DESTRUCTIVE)
    async def create_api_skill(
        name: str,
        endpoint: str,
        method: str = "POST",
        description: str | None = None,
        category: str | None = None,
        object_type: str | None = None,
        headers: dict[str, str] | None = None,
        body_template: str | None = None,
        query_params: dict[str, str] | None = None,
        body_type: str | None = None,
        content_type: str | None = None,
        requires_approval: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Create an API-runtime skill.

        IMPORTANT: this persists a new skill in the org. Confirm with the
        user before calling with ``dry_run=False``.

        ``g8_skill_create_from_node`` (lift) routes through the SAME
        underlying endpoint, so an API skill created this way is
        byte-identical to one lifted from a workflow action node.

        Args:
            name: Display name.
            endpoint: Full URL. May contain ``{variable}`` placeholders
                for path params (e.g. ``https://api.x.com/v1/{id}``).
            method: HTTP method (default ``"POST"``). One of
                ``GET|POST|PUT|PATCH|DELETE``.
            description: Optional human-readable summary.
            category: Optional grouping.
            object_type: Optional entity target -
                ``"Company"|"Contact"|"Deal"|"Campaign"``.
            headers: Static request headers. Values may use ``{var}``.
            body_template: Request body template. ``{var}`` placeholders
                are substituted at runtime.
            query_params: Static query params dict. Values may use ``{var}``.
            body_type: ``json``, ``form-urlencoded``, ``form-data``,
                ``raw``, or ``graphql``. Defaults to ``json``.
            content_type: Custom Content-Type header. Auto-detected from
                ``body_type`` if omitted.
            requires_approval: Force manual approval before execution.
            dry_run: When True, return a confirmation preview.
        """
        if not name or not endpoint:
            return "Error: name and endpoint are required."
        method_norm = (method or "POST").upper()
        if method_norm not in {"GET", "POST", "PUT", "PATCH", "DELETE"}:
            return f"Error: method must be one of GET|POST|PUT|PATCH|DELETE, got '{method}'."

        if dry_run:
            details = [
                ConfirmationDetail(label="Name", value=name),
                ConfirmationDetail(label="Runtime", value="api"),
                ConfirmationDetail(label="Method", value=method_norm),
                ConfirmationDetail(label="Endpoint", value=endpoint),
            ]
            if body_type:
                details.append(ConfirmationDetail(label="Body type", value=body_type))
            if category:
                details.append(ConfirmationDetail(label="Category", value=category))
            confirm_args: dict[str, Any] = {
                "name": name,
                "endpoint": endpoint,
                "method": method_norm,
                "description": description,
                "category": category,
                "object_type": object_type,
                "headers": headers,
                "body_template": body_template,
                "query_params": query_params,
                "body_type": body_type,
                "content_type": content_type,
                "requires_approval": requires_approval,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Create API skill",
                summary=f'Create API skill "{name}" -> {method_norm} {endpoint}.',
                details=details,
                confirm_tool=tool_name("create_api"),
                confirm_args=confirm_args,
                confirm_label="Create skill",
                cancel_label="Cancel",
            ).model_dump()

        api_config: dict[str, Any] = {
            "endpoint": endpoint,
            "method": method_norm,
        }
        if headers is not None:
            api_config["headers"] = headers
        if body_template is not None:
            api_config["body_template"] = body_template
        if query_params is not None:
            api_config["query_params"] = query_params
        if body_type is not None:
            api_config["body_type"] = body_type
        if content_type is not None:
            api_config["content_type"] = content_type

        body: dict[str, Any] = {
            "name": name,
            "runtime_type": "api",
            "api_config": api_config,
            "requires_approval": requires_approval,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if object_type is not None:
            body["object_type"] = object_type
        try:
            return _unwrap(await client.post("/skills", body=body))
        except Exception as e:
            return f"Create API skill failed: {e}"

    @server.tool(name=tool_name("update_llm"), annotations=_REVERSIBLE_WRITE)
    async def update_llm_skill(
        action_id: str,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        object_type: str | None = None,
        enabled: bool | None = None,
        model: str | None = None,
        prompt_template: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        requires_approval: bool | None = None,
    ) -> dict[str, Any] | str:
        """Update an LLM-runtime skill. Pass only the fields you want to change.

        404 is returned if the action is not an LLM skill - switching
        runtime is not supported.

        Args:
            action_id: Skill UUID.
            name, description, category, object_type, enabled: Top-level
                metadata. Pass to change.
            model, prompt_template, temperature, max_tokens: LLM config.
                If ANY one is passed, all four are sent (voice's update
                replaces the full llm_config block). Read the current
                value first via ``g8_skill_get`` if you only want a
                partial change.
            requires_approval: Approval gate toggle.
        """
        if not action_id:
            return "Error: action_id is required."

        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if object_type is not None:
            body["object_type"] = object_type
        if enabled is not None:
            body["enabled"] = enabled
        if requires_approval is not None:
            body["requires_approval"] = requires_approval

        any_llm_field = any(v is not None for v in (model, prompt_template, temperature, max_tokens))
        if any_llm_field:
            # Voice's update replaces the full llm_config block - fetch
            # current values to preserve any field the caller didn't pass.
            try:
                current = _unwrap(await client.get(f"/skills/{action_id}"))
            except Exception as e:
                return f"Update LLM skill failed (pre-fetch): {e}"
            current_action = _action_from_resp(current)
            current_llm = (current_action or {}).get("llm_config") or {}
            if not isinstance(current_llm, dict):
                current_llm = {}
            body["llm_config"] = {
                "model": model if model is not None else current_llm.get("model"),
                "prompt_template": prompt_template if prompt_template is not None else current_llm.get("prompt_template"),
                "temperature": temperature if temperature is not None else current_llm.get("temperature", 0.7),
                "max_tokens": max_tokens if max_tokens is not None else current_llm.get("max_tokens", 1000),
            }

        if not body:
            return "Error: at least one field must be provided."

        try:
            return _unwrap(await client.put(f"/skills/{action_id}", body=body))
        except Exception as e:
            return f"Update LLM skill failed: {e}"

    @server.tool(name=tool_name("update_api"), annotations=_REVERSIBLE_WRITE)
    async def update_api_skill(
        action_id: str,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        object_type: str | None = None,
        enabled: bool | None = None,
        endpoint: str | None = None,
        method: str | None = None,
        headers: dict[str, str] | None = None,
        body_template: str | None = None,
        query_params: dict[str, str] | None = None,
        body_type: str | None = None,
        content_type: str | None = None,
        requires_approval: bool | None = None,
    ) -> dict[str, Any] | str:
        """Update an API-runtime skill. Pass only the fields you want to change.

        404 is returned if the action is not an API skill - switching
        runtime is not supported.

        Args:
            action_id: Skill UUID.
            name, description, category, object_type, enabled: Top-level
                metadata.
            endpoint, method, headers, body_template, query_params,
                body_type, content_type: API config. If ANY one is passed,
                all are sent (voice's update replaces the full api_config
                block). Fetch current values first via ``g8_skill_get``
                if you only want a partial change.
            requires_approval: Approval gate toggle.
        """
        if not action_id:
            return "Error: action_id is required."

        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if object_type is not None:
            body["object_type"] = object_type
        if enabled is not None:
            body["enabled"] = enabled
        if requires_approval is not None:
            body["requires_approval"] = requires_approval

        api_fields = (endpoint, method, headers, body_template, query_params, body_type, content_type)
        any_api_field = any(v is not None for v in api_fields)
        if any_api_field:
            try:
                current = _unwrap(await client.get(f"/skills/{action_id}"))
            except Exception as e:
                return f"Update API skill failed (pre-fetch): {e}"
            current_action = _action_from_resp(current)
            current_api = (current_action or {}).get("api_config") or {}
            if not isinstance(current_api, dict):
                current_api = {}
            method_val = method if method is not None else current_api.get("method", "POST")
            if isinstance(method_val, str):
                method_val = method_val.upper()
            merged: dict[str, Any] = {
                "endpoint": endpoint if endpoint is not None else current_api.get("endpoint"),
                "method": method_val,
            }
            if headers is not None or current_api.get("headers") is not None:
                merged["headers"] = headers if headers is not None else current_api.get("headers")
            if body_template is not None or current_api.get("body_template") is not None:
                merged["body_template"] = body_template if body_template is not None else current_api.get("body_template")
            if query_params is not None or current_api.get("query_params") is not None:
                merged["query_params"] = query_params if query_params is not None else current_api.get("query_params")
            if body_type is not None or current_api.get("body_type") is not None:
                merged["body_type"] = body_type if body_type is not None else current_api.get("body_type")
            if content_type is not None or current_api.get("content_type") is not None:
                merged["content_type"] = content_type if content_type is not None else current_api.get("content_type")
            body["api_config"] = merged

        if not body:
            return "Error: at least one field must be provided."

        try:
            return _unwrap(await client.put(f"/skills/{action_id}", body=body))
        except Exception as e:
            return f"Update API skill failed: {e}"

    @server.tool(name=tool_name("delete"), annotations=_DESTRUCTIVE)
    async def delete_skill(
        action_id: str,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Delete a skill (with MCP-side reference check).

        Per the PRD lock (5.3): this tool scans every workflow in the org
        for nodes that reference the skill. If ANY workflow references
        it, the delete is refused and the offending workflows are listed
        so the user can decide. If no references exist, the DELETE is
        forwarded to voice (hard-delete).

        IMPORTANT: hard-delete is final. There is no g8_skill_restore.

        Recommended pattern: call with ``dry_run=True`` to see the
        reference report + confirmation, then again with ``dry_run=False``
        once the user confirms.

        Args:
            action_id: Skill UUID.
            dry_run: When True, return a confirmation preview (including
                any reference list) instead of deleting.
        """
        if not action_id:
            return "Error: action_id is required."

        # Always run the reference scan, even in dry_run, so the preview
        # carries the same information the live call would refuse on.
        refs = await _workflows_referencing_skill(client, action_id)

        if refs:
            if dry_run:
                details = [
                    ConfirmationDetail(
                        label=f"Referenced by workflow {r['workflow_name'] or r['workflow_id']}",
                        value=f"node {r['node_id']} ({r['workflow_id']})",
                    )
                    for r in refs[:10]
                ]
                if len(refs) > 10:
                    details.append(
                        ConfirmationDetail(
                            label="…",
                            value=f"and {len(refs) - 10} more",
                        )
                    )
                return ConfirmationPreview(
                    action_label="Delete skill - BLOCKED",
                    summary=(
                        f"This skill is referenced by {len(refs)} workflow node(s). "
                        "Remove or repoint the references before deleting."
                    ),
                    details=details,
                    warning=(
                        "Delete refused. Update the listed workflows first "
                        "(g8_workflow_update_node) so they point at a different "
                        "skill, then retry delete."
                    ),
                    confirm_tool=None,
                    confirm_args={},
                    confirm_label="OK",
                    cancel_label="Cancel",
                ).model_dump()
            return (
                f"Delete refused: skill '{action_id}' is referenced by {len(refs)} workflow "
                "node(s). Update the workflows first then retry.\n"
                + "\n".join(
                    f"  - workflow {r['workflow_name'] or r['workflow_id']} ({r['workflow_id']}), node {r['node_id']}"
                    for r in refs
                )
            )

        if dry_run:
            return ConfirmationPreview(
                action_label="Delete skill",
                summary=f"Permanently delete skill {action_id}. No workflows reference it.",
                details=[ConfirmationDetail(label="Skill id", value=action_id)],
                warning="Hard delete - there is no restore tool.",
                confirm_tool=tool_name("delete"),
                confirm_args={"action_id": action_id, "dry_run": False},
                confirm_label="Delete skill",
                cancel_label="Cancel",
            ).model_dump()

        try:
            return _unwrap(await client.delete(f"/skills/{action_id}"))
        except Exception as e:
            return f"Delete skill failed: {e}"

    # ------------------------------------------------------------------
    # Validate / lift
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("validate_template"), annotations=_READ_ONLY)
    async def validate_template(
        template: str | None = None,
        runtime_type: str | None = None,
        llm_config: dict[str, Any] | None = None,
        api_config: dict[str, Any] | None = None,
    ) -> SkillValidateResult | str:
        """Dry-run a skill template through the variable extractor and
        warn-only validator.

        Two call shapes:
          - ``validate_template(template="Hello {name}")`` - one string
            in, vars out.
          - ``validate_template(runtime_type="llm", llm_config={...})``
            (or ``api_config=...``) - full skill shape, scans every
            template field the runtime would use.

        Per the PRD lock (Q3): warn-only - ``valid`` is always True for
        parseable templates; warnings list soft issues like double-brace
        usage or unmatched braces so you can repair before saving.

        Args:
            template: Single template string.
            runtime_type: ``"llm"`` or ``"api"`` (when passing a full
                skill shape).
            llm_config: Full LLM config dict.
            api_config: Full API config dict.
        """
        body: dict[str, Any] = {}
        if template is not None:
            body["template"] = template
        if runtime_type is not None:
            body["runtime_type"] = runtime_type
        if llm_config is not None:
            body["llm_config"] = llm_config
        if api_config is not None:
            body["api_config"] = api_config
        if not body:
            return "Error: pass either `template` or a `runtime_type` + matching config."
        try:
            resp = _unwrap(await client.post("/skills/validate", body=body))
        except Exception as e:
            return f"Validate template failed: {e}"
        if not isinstance(resp, dict):
            return "Validate template returned an unexpected shape."
        return SkillValidateResult.model_validate(resp)

    @server.tool(name=tool_name("create_from_template"), annotations=_DESTRUCTIVE)
    async def create_from_template(
        template_id: str,
        name: str,
        overrides: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Clone a skill template into the org.

        IMPORTANT: persists a new skill. Confirm with the user before
        calling with ``dry_run=False``.

        Pre-flight on the proxy refuses to clone templates of workflow
        or script runtime - only llm/api templates can land here.

        Args:
            template_id: Template UUID from ``g8_skill_list_templates``.
            name: Display name for the new skill.
            overrides: Optional dict of fields to override on the clone
                (forwarded as-is to voice's from-template endpoint).
            dry_run: When True, return a confirmation preview.
        """
        if not template_id or not name:
            return "Error: template_id and name are required."

        if dry_run:
            details = [
                ConfirmationDetail(label="Template id", value=template_id),
                ConfirmationDetail(label="New name", value=name),
            ]
            if overrides:
                details.append(
                    ConfirmationDetail(
                        label="Overrides",
                        value=", ".join(sorted(overrides.keys())),
                    )
                )
            return ConfirmationPreview(
                action_label="Clone template",
                summary=f'Create a new skill named "{name}" from template {template_id}.',
                details=details,
                confirm_tool=tool_name("create_from_template"),
                confirm_args={
                    "template_id": template_id,
                    "name": name,
                    "overrides": overrides or {},
                    "dry_run": False,
                },
                confirm_label="Create skill",
                cancel_label="Cancel",
            ).model_dump()

        body: dict[str, Any] = {
            "template_id": template_id,
            "name": name,
            "overrides": overrides or {},
        }
        try:
            return _unwrap(await client.post("/skills/from-template", body=body))
        except Exception as e:
            return f"Create from template failed: {e}"

    @server.tool(name=tool_name("create_from_node"), annotations=_DESTRUCTIVE)
    async def create_from_node(
        workflow_id: str,
        node_id: str,
        name: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Lift a workflow action node into a standalone skill.

        Per the PRD lock (5.2): this routes through POST /skills/from-node,
        which itself calls POST /api/v1/actions/create - the SAME endpoint
        ``g8_skill_create_llm`` / ``g8_skill_create_api`` use. Lift skills
        are byte-identical to authored skills.

        Does NOT modify the workflow - the lift is a copy. If the user
        wants the workflow node to reference the new skill, update the
        workflow afterward with ``g8_workflow_update_node`` to set the
        node's ``config.action_id`` to the new skill's id.

        IMPORTANT: persists a new skill. Confirm with the user before
        calling with ``dry_run=False``.

        Args:
            workflow_id: Workflow UUID.
            node_id: Node id inside the workflow's graph.
            name: Optional new name; defaults to ``"<source name> (Copy)"``.
            dry_run: When True, return a confirmation preview.
        """
        if not workflow_id or not node_id:
            return "Error: workflow_id and node_id are required."

        if dry_run:
            details = [
                ConfirmationDetail(label="Workflow id", value=workflow_id),
                ConfirmationDetail(label="Node id", value=node_id),
            ]
            if name:
                details.append(ConfirmationDetail(label="New name", value=name))
            return ConfirmationPreview(
                action_label="Lift skill from workflow node",
                summary=(
                    f"Create a standalone skill from node {node_id} in "
                    f"workflow {workflow_id}. The workflow is not modified."
                ),
                details=details,
                confirm_tool=tool_name("create_from_node"),
                confirm_args={
                    "workflow_id": workflow_id,
                    "node_id": node_id,
                    "name": name,
                    "dry_run": False,
                },
                confirm_label="Lift skill",
                cancel_label="Cancel",
            ).model_dump()

        body: dict[str, Any] = {
            "workflow_id": workflow_id,
            "node_id": node_id,
        }
        if name is not None:
            body["name"] = name
        try:
            return _unwrap(await client.post("/skills/from-node", body=body))
        except Exception as e:
            return f"Lift skill failed: {e}"

    # ------------------------------------------------------------------
    # Execute
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("execute"), annotations=_DESTRUCTIVE)
    async def execute_skill(
        action_id: str,
        input_data: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Run a skill once and return the execution result.

        IMPORTANT: this triggers a real execution (LLM call or HTTP
        request) and may consume credits. Confirm with the user before
        calling with ``dry_run=False``.

        ``input_data`` keys should match the ``{variable}`` placeholders
        returned by ``g8_skill_extract_variables`` - anything else is
        passed through but won't substitute.

        Args:
            action_id: Skill UUID.
            input_data: Dict of input field values for placeholder
                substitution (e.g. ``{"company_name": "Acme"}``).
            dry_run: When True, return a confirmation preview.
        """
        if not action_id:
            return "Error: action_id is required."
        payload_inputs = dict(input_data or {})

        if dry_run:
            details = [
                ConfirmationDetail(label="Skill id", value=action_id),
                ConfirmationDetail(label="Inputs", value=str(len(payload_inputs))),
            ]
            for k, v in list(payload_inputs.items())[:5]:
                details.append(ConfirmationDetail(label=k, value=str(v)[:80]))
            return ConfirmationPreview(
                action_label="Execute skill",
                summary=f"Run skill {action_id} with {len(payload_inputs)} input(s).",
                details=details,
                warning="Execution may consume credits or make external requests.",
                confirm_tool=tool_name("execute"),
                confirm_args={
                    "action_id": action_id,
                    "input_data": payload_inputs,
                    "dry_run": False,
                },
                confirm_label="Execute",
                cancel_label="Cancel",
            ).model_dump()

        body: dict[str, Any] = {
            "action_id": action_id,
            "input_data": payload_inputs,
            "trigger_type": "manual",
        }
        try:
            return _unwrap(await client.post(f"/skills/{action_id}/execute", body=body))
        except Exception as e:
            return f"Execute skill failed: {e}"

    # ------------------------------------------------------------------
    # Aliases - register every canonical g8_{name_prefix}_* tool under
    # each entry in alias_prefixes (e.g. g8_workflow_skill_*) pointing
    # at the SAME handler function. Uses Pydantic model_copy so the
    # alias inherits the parameters schema, annotations, description,
    # is_async flag, etc. without re-deriving from the function. This
    # is the lowest-risk path: existing g8_skill_* callers (tests,
    # cached client schemas, the test_skills_authoring suite) keep
    # working unchanged; new callers can also use the alias.
    # ------------------------------------------------------------------
    canonical_prefix = f"g8_{name_prefix}_" if name_prefix else "g8_"
    tool_manager = server._tool_manager
    canonical_names = [
        n for n in list(tool_manager._tools.keys()) if n.startswith(canonical_prefix)
    ]
    for alias_prefix in alias_prefixes:
        if not alias_prefix or alias_prefix == name_prefix:
            continue
        alias_namespace = f"g8_{alias_prefix}_"
        for canonical in canonical_names:
            base = canonical[len(canonical_prefix):]
            alias_name = f"{alias_namespace}{base}"
            if alias_name in tool_manager._tools:
                # Idempotent: another caller already registered this alias.
                continue
            original = tool_manager._tools[canonical]
            tool_manager._tools[alias_name] = original.model_copy(
                update={"name": alias_name}
            )
