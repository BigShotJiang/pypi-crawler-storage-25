# Skill: Prospecting and Lists

**When to use this skill:** the user wants to find new leads, build a contact list, or enrich contacts they already have.

## Core concept you must get right

graph8 has two very different data sources. Confusing them produces wrong answers.

| Source | Tools | What it is |
|---|---|---|
| **Your CRM** (PostgreSQL) | `g8_search_contacts`, `g8_search_companies` | Only contacts your org has already imported or created. |
| **Open data index** (300M+ records) | `g8_find_contacts`, `g8_find_companies`, `g8_lookup_person`, `g8_lookup_company` | The global prospecting database. |

Rule: if the user says "find me" or "give me new leads," always use the open-data tools. If they say "check whether we have" or "who in our list is...," use the CRM tools.

## The list-building workflow (prescriptive)

`g8_create_list` is the one tool for building lists. It accepts one of three optional source modes (or none, for an empty list):
- `contact_ids=[..]` — attach existing CRM contacts to a new list (free).
- `rows=[{..}]` — import explicit records (e.g. the curated subset of a `g8_find_contacts` result) (free; no enrichment credits).
- `filters=[{..}]` — search-and-save against the 300M open data index (CHARGES CREDITS — `max_results` caps the spend).

`g8_add_to_list(list_id, ...)` follows the same shape but takes `contact_ids` or `rows`. Use `g8_create_list(filters=...)` to make a brand-new list from a search.

### A) Search-and-save flow (filters)

Follow this sequence for any "build me a list of X" request when the user describes their ideal customer profile rather than naming records:

1. **Sample with a small limit.** Call `g8_find_contacts(filters, limit=25)` first. Show the user the top 3-5 rows and ask them to confirm the filters before committing to a larger save.

2. **Dry-run preview.** `g8_create_list(filters=..., title=..., max_results=N, dry_run=True)` returns a ConfirmationPreview. Render it and wait for the user.

3. **Save the list.** On confirm, re-call with `dry_run=False`. Use a descriptive title like "VP Sales at SaaS 50-500" rather than "My List."

### B) Curate-then-commit flow (rows)

Use when the user wants to hand-pick from a `g8_find_contacts` result:

1. `g8_find_contacts(filters, limit=80)` — show the results.
2. The user picks the subset they want (e.g. 40 of 80).
3. `g8_create_list(title="...", rows=[the chosen rows], dry_run=True)` → preview → re-call with `dry_run=False`. Each row becomes a CRM contact and is attached to the new list. No enrichment credits because the rows already carry their data.

### C) Append to existing list

- Existing CRM contacts: `g8_add_to_list(list_id, contact_ids=[..])` (free).
- Explicit rows: `g8_add_to_list(list_id, rows=[..], dry_run=True)` → preview → re-call.

### D) Optional follow-ups

- **Enrich.** If saved contacts are missing emails or phones, call `g8_enrich_contacts(contact_ids, list_id)`. Ask first.
- **Enroll.** To push the list into outreach, use the running-a-campaign skill or `g8_list_sequences` + `g8_add_to_sequence`. Never enroll without explicit user confirmation — it sends real messages.

## Filter format

Filters for `g8_find_contacts`, `g8_find_companies`, and `g8_create_list(filters=...)` are a list of dicts. Each dict has:

```json
{"field": "seniority_level", "operator": "any_of", "value": ["VP", "Director"]}
```

**Common contact fields:** `first_name`, `last_name`, `work_email`, `job_title`, `seniority_level`, `job_department`, `role`, `company_name`, `company_domain`, `company_industry`, `company_employee_count`, `company_revenue`, `country`, `state`, `city`.

**Common company fields:** `name`, `domain`, `industry`, `employee_count`, `revenue`, `founded_year`, `country`.

**Operators:** `any_of`, `contains`, `all_of`, `none_of`, `is_empty`, `is_not_empty`, `between`, `exists`.

**Real example** (VPs of Sales at US SaaS companies with 50-500 headcount):

```json
[
  {"field": "seniority_level", "operator": "any_of", "value": ["Vice President"]},
  {"field": "job_department", "operator": "any_of", "value": ["Sales"]},
  {"field": "company_industry", "operator": "contains", "value": ["SaaS", "Software"]},
  {"field": "company_employee_count", "operator": "between", "value": [50, 500]},
  {"field": "country", "operator": "any_of", "value": ["United States"]}
]
```

> The open-data index stores seniority as full strings ("Vice President",
> "Senior Vice President", "Director", ...), NOT abbreviations. The server
> auto-expands the common abbreviations (`VP`, `SVP`, `EVP`, `AVP`,
> `C-Level`, `C-Suite`) to their canonical forms before searching, so
> existing filters that use abbreviations keep working — but prefer the
> canonical form in new code.

## Single-person and single-company lookup

If the user asks about one specific person or company (by email, LinkedIn URL, or domain), use the faster single-record tools:

- `g8_lookup_person(email=..., linkedin_url=..., first_name=..., last_name=..., company_domain=...)` — returns enriched profile.
- `g8_lookup_company(domain=..., name=...)` — returns enriched firmographics.

These do not save to CRM. To save, follow up with `g8_create_contact(work_email=..., ...)` which returns a `contact_id` you can then `g8_add_to_list` or `g8_add_to_sequence`.

## Common mistakes to avoid

- **Do not call `g8_create_list(filters=...)` before sampling with `g8_find_contacts`.** You will commit to saving up to `max_results` contacts on filters the user did not validate. A 25-record sample first lets you confirm before committing.
- **Do not pass raw prospecting results to `g8_add_to_sequence` or `g8_add_to_list(contact_ids=...)`.** Those need CRM `contact_id` integers. Open-data results are not yet in the CRM. Either save them first with `g8_create_list(filters=...)` / `g8_create_list(rows=...)` / `g8_create_contact`, or pass them as `rows=` to the unified list tools.
- **Do not skip the dry_run preview for cost-bearing source modes (`filters`, `rows`).** Both `g8_create_list` and `g8_add_to_list` honor `dry_run=True` and return a ConfirmationPreview the user can confirm.
- **Do not skip the enrichment confirmation.** "Enrich these 500 contacts" sounds harmless but can produce results the user did not want. Always confirm before calling.

## Chaining into outreach

Once contacts are saved to a list (`list_id`), the typical next step is:

1. `g8_list_sequences(limit=50)` — find an existing sequence to use.
2. Show the user the sequence name and ask which one to enroll into.
3. `g8_add_to_sequence(sequence_id, contact_ids, list_id)` — confirm with user first. This starts real outreach.

If no suitable sequence exists, create one with `g8_create_sequence` — but campaign-level planning is better handled via the running-a-campaign skill.
