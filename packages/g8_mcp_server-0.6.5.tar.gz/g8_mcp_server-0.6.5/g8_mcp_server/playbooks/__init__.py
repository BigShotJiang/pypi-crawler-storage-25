"""graph8 MCP playbooks - markdown workflow guides loaded on demand.

Playbooks are prescriptive domain-knowledge documents that teach an agent
how to use graph8 tools in the right order, with the right confirmations,
for a specific user journey. They are distinct from tool docstrings (which
describe individual tools) and prompts (which are pre-canned user messages).

Renamed from "skills" in v0.6.3 to disambiguate from the `g8_skill_*` /
`g8_workflow_skill_*` tool family, which authors first-class graph8 skill
records (LLM/HTTP/code) consumed by workflow Action nodes. "Skill" was an
overloaded term across two unrelated surfaces - "playbook" is the
unambiguous name for these prescriptive how-to guides for the agent itself.

Exposed through two surfaces:
- Tools: g8_list_playbooks, g8_load_playbook (see g8_mcp_server/tools/playbooks.py)
- Resources: g8://playbooks, g8://playbooks/{slug} (see g8_mcp_server/resources.py)
"""

from __future__ import annotations

from pathlib import Path
from typing import TypedDict

_PLAYBOOKS_DIR = Path(__file__).parent


class PlaybookEntry(TypedDict):
    """Catalog metadata for one playbook. Content lives in the sibling .md file."""

    slug: str
    title: str
    summary: str
    path: str  # filename within the playbooks/ directory
    when_to_use: str


# Ordered catalog. Keep the list short and curated - this is the first
# thing the model sees when it calls g8_list_playbooks. Each summary should
# answer "when would I reach for this playbook?"
PLAYBOOKS_CATALOG: list[PlaybookEntry] = [
    {
        "slug": "prospecting-and-lists",
        "title": "Prospecting and Lists",
        "summary": "Find new leads in graph8's 300M+ open data index, preview filters safely, save to CRM lists, and enrich contacts.",
        "path": "prospecting-and-lists.md",
        "when_to_use": "User wants to find new leads, build a contact list, or enrich contacts.",
    },
    {
        "slug": "running-a-campaign",
        "title": "Running a Campaign End-to-End",
        "summary": "Ideate, draft, document, sequence, review, and launch a graph8 campaign. Covers loading brand context, building steps, and launch confirmations.",
        "path": "running-a-campaign.md",
        "when_to_use": "User wants to create, review, or launch a graph8 campaign.",
    },
    {
        "slug": "installing-tracking",
        "title": "Installing graph8 Tracking",
        "summary": "Install the p.js snippet on a website or wire up full Spine integration in a codebase. Picks between standalone snippet and repo-based install paths.",
        "path": "installing-tracking.md",
        "when_to_use": "User wants to install graph8 tracking, identity, forms, or attribution.",
    },
    {
        "slug": "ai-inbox-replies",
        "title": "AI Inbox Replies",
        "summary": "Triage the multi-channel inbox (email, SMS, LinkedIn), generate AI drafts, review, and send replies with confirmations.",
        "path": "ai-inbox-replies.md",
        "when_to_use": "User wants to read, triage, or reply to inbound messages in their inbox.",
    },
]


def get_playbook_content(slug: str) -> str | None:
    """Return the markdown content for a playbook by slug, or None if unknown."""
    entry = next((s for s in PLAYBOOKS_CATALOG if s["slug"] == slug), None)
    if entry is None:
        return None
    playbook_path = _PLAYBOOKS_DIR / entry["path"]
    if not playbook_path.exists():
        return None
    return playbook_path.read_text(encoding="utf-8")


def list_playbook_slugs() -> list[str]:
    """Return the list of available playbook slugs."""
    return [s["slug"] for s in PLAYBOOKS_CATALOG]
