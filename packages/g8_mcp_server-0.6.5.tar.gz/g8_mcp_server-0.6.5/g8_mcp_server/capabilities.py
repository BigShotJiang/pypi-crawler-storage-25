"""Canonical MCP capability catalog used by Profile and documentation."""

from __future__ import annotations

from typing import Any

MCP_TOOL_GROUPS: list[dict[str, str]] = [
    {
        "value": "crm",
        "label": "Sales & CRM",
        "description": "Contacts, companies, prospecting, lists, sequences, enrichment, deals, tasks, inbox, CRM sync",
    },
    {
        "value": "campaigns",
        "label": "Marketing & Campaigns",
        "description": "Campaigns, campaign documents, context, personas, ICPs, ideas, KB, sequences, audience sync",
    },
    {
        "value": "intent",
        "label": "Compete Tracking",
        "description": "Intent keywords + page / visitor / company resolution for competitor research",
    },
    {
        "value": "dev",
        "label": "Developer",
        "description": "Repos, scans, installs, snippets, forms, campaigns, KB",
    },
    {
        "value": "all",
        "label": "Everything",
        "description": "All registered MCP tools",
    },
]


def _tool(label: str, actual: str, endpoint: str, description: str, status: str = "available") -> dict[str, str]:
    return {
        "name": label,
        "actual_tool": actual,
        "backing_endpoint": endpoint,
        "description": description,
        "status": status,
    }


MCP_TOOL_CATALOG: dict[str, list[dict[str, str]]] = {
    "crm": [
        _tool("search_contacts", "g8_search_contacts", "GET /api/v1/contacts", "Search contacts already in your CRM"),
        _tool("search_companies", "g8_search_companies", "GET /api/v1/companies", "Search companies already in your CRM"),
        _tool("find_contacts", "g8_find_contacts", "POST /api/v1/search/contacts", "Prospect: search contacts for new leads"),
        _tool("find_companies", "g8_find_companies", "POST /api/v1/search/companies", "Prospect: search company database for targets"),
        _tool("lookup_person", "g8_lookup_person", "POST /api/v1/enrichment/lookup/person", "Look up a single person by email or LinkedIn"),
        _tool("lookup_company", "g8_lookup_company", "POST /api/v1/enrichment/lookup/company", "Look up a single company by domain or name"),
        _tool("create_contact", "g8_create_contact", "POST /api/v1/contacts", "Save a prospect to your CRM"),
        _tool("create_list", "g8_create_list", "POST /api/v1/lists (+ optional /contacts or /search/contacts/save)", "Create a list - empty, or pre-populated via contact_ids / rows / filters"),
        _tool("add_to_list", "g8_add_to_list", "POST /api/v1/lists/{list_id}/contacts (or /contacts loop)", "Add to a list by contact_ids or by explicit rows"),
        _tool("enrich_contacts", "g8_enrich_contacts", "POST /api/v1/enrichment/enrich", "Bulk enrich CRM contacts with external data"),
        _tool("add_to_sequence", "g8_add_to_sequence", "POST /api/v1/sequences/{sequence_id}/contacts", "Enroll contacts in an outbound sequence"),
        _tool("get_sequences", "g8_list_sequences", "GET /api/v1/sequences", "List active sequences", "name mismatch"),
        _tool("get_deals", "g8_get_deals", "GET /api/v1/deals", "List deals with stage filtering"),
        _tool("get_deal", "g8_get_deal", "GET /api/v1/deals/{deal_id}", "Get single deal details"),
        _tool("create_deal", "g8_create_deal", "POST /api/v1/deals", "Create a CRM deal"),
        _tool("update_deal", "g8_update_deal", "PATCH /api/v1/deals/{deal_id}", "Update a deal (incl. stage change)"),
        _tool("delete_deal", "g8_delete_deal", "DELETE /api/v1/deals/{deal_id}", "Delete a deal"),
        _tool("get_company_deals", "g8_get_company_deals", "GET /api/v1/companies/{company_id}/deals", "List deals on a company (account view)"),
        _tool("create_note", "g8_create_note", "POST /api/v1/contacts/{contact_id}/notes", "Add a note to a contact"),
        _tool("list_notes", "g8_list_notes", "GET /api/v1/contacts/{contact_id}/notes", "List notes on a contact"),
        _tool("update_note", "g8_update_note", "PATCH /api/v1/notes/{note_id}", "Update a note's content"),
        _tool("delete_note", "g8_delete_note", "DELETE /api/v1/notes/{note_id}", "Delete a note"),
        _tool("get_tasks", "g8_get_tasks", "GET /api/v1/tasks", "List tasks for current user"),
        _tool("create_task", "g8_create_task", "POST /api/v1/contacts/{contact_id}/tasks", "Create a task linked to a contact"),
        _tool("update_task", "g8_update_task", "PATCH /api/v1/tasks/{task_id}", "Update a task (status, assignee, due date, etc.)"),
        _tool("delete_task", "g8_delete_task", "DELETE /api/v1/tasks/{task_id}", "Delete a task"),
        _tool("get_activities", "g8_get_activities", "GET /api/v1/activities", "Get recent activities timeline"),
        _tool("get_lists", "g8_get_lists", "GET /api/v1/lists", "List contact lists"),
        _tool("get_pipeline", "g8_get_pipeline", "GET /api/v1/deals/pipelines", "View pipeline stages and deal counts"),
        # Custom fields / columns
        _tool("list_fields", "g8_list_fields", "GET /api/v1/fields", "List contact or company fields (base + custom)"),
        _tool("create_field", "g8_create_field", "POST /api/v1/fields", "Create a custom column on contacts or companies"),
        _tool("delete_field", "g8_delete_field", "DELETE /api/v1/fields/{column_id}", "Soft-delete a custom column"),
        _tool("set_field_value", "g8_set_field_value", "PATCH /api/v1/fields/{column_id}/values", "Set a custom column value on a single contact or company row"),
        # Sequence lifecycle
        _tool("create_sequence", "g8_create_sequence", "POST /api/v1/sequences", "Create a new outreach sequence"),
        _tool("sequence_preview", "g8_get_sequence_preview", "GET /api/v1/sequences/{id}/preview", "Preview sequence steps before launching"),
        _tool("update_sequence", "g8_update_sequence", "PATCH /api/v1/sequences/{id}", "Update sequence metadata"),
        _tool("update_sequence_step", "g8_update_sequence_step", "PATCH /api/v1/sequences/{id}/steps/{step_id}", "Update a single step in a sequence"),
        _tool("pause_sequence", "g8_pause_sequence", "POST /api/v1/sequences/{id}/pause", "Pause a live sequence"),
        _tool("resume_sequence", "g8_resume_sequence", "POST /api/v1/sequences/{id}/resume", "Resume a paused sequence"),
        _tool("sequence_analytics", "g8_get_sequence_analytics", "GET /api/v1/sequences/{id}/analytics", "Get sequence performance metrics"),
        _tool("delete_sequence", "g8_delete_sequence", "DELETE /api/v1/sequences/{id}", "Archive a sequence (soft delete)"),
        # Inbox
        _tool("list_inbox", "g8_list_inbox", "GET /api/v1/inbox", "List reply threads across email, SMS, LinkedIn"),
        _tool("get_reply", "g8_get_reply", "GET /api/v1/inbox/{reply_id}", "Get a single reply thread with messages"),
        _tool("assign_reply", "g8_assign_reply", "POST /api/v1/inbox/{reply_id}/assign", "Assign a reply to a team member"),
        _tool("tag_reply", "g8_tag_reply", "POST /api/v1/inbox/{reply_id}/tag", "Tag a reply thread"),
        _tool("get_reply_draft", "g8_get_reply_draft", "GET /api/v1/inbox/{reply_id}/draft", "Generate an AI reply draft (charges credits)"),
        _tool("send_reply", "g8_send_reply", "POST /api/v1/inbox/{reply_id}/send", "Send a reply via email, SMS, or LinkedIn"),
        # CRM sync
        _tool("list_crm_syncs", "g8_list_crm_syncs", "GET /api/v1/crm-syncs", "List connected CRM integrations"),
        _tool("push_to_crm_contact", "g8_push_to_crm_contact", "POST /api/v1/crm-syncs/{provider}/contacts/push", "Push contacts to a CRM"),
        _tool("push_to_crm_company", "g8_push_to_crm_company", "POST /api/v1/crm-syncs/{provider}/companies/push", "Push companies to a CRM"),
        _tool("push_to_crm_list", "g8_push_to_crm_list", "POST /api/v1/crm-syncs/{provider}/lists/push", "Push list memberships to a CRM"),
        _tool("get_crm_fields", "g8_get_crm_fields", "GET /api/v1/crm-syncs/{provider}/fields", "Discover CRM field mappings"),
        _tool("get_crm_status", "g8_get_crm_status", "GET /api/v1/crm-syncs/{provider}/status", "Check CRM connection health"),
    ],
    "campaigns": [
        _tool("get_campaigns", "g8_gtm_list_campaigns", "GET /api/v1/campaigns", "List campaigns with status filtering", "name mismatch"),
        _tool("get_campaign", "g8_gtm_get_campaign", "GET /api/v1/campaigns/{campaign_id}", "Get single campaign details", "name mismatch"),
        _tool("create_campaign", "g8_gtm_create_campaign", "POST /api/v1/campaigns", "Create a new campaign", "name mismatch"),
        _tool("launch_campaign", "g8_gtm_launch_campaign", "POST /api/v1/campaigns/{campaign_id}/launch", "Launch a draft campaign", "name mismatch"),
        _tool("get_campaign_docs", "g8_gtm_list_campaign_documents", "GET /api/v1/campaigns/{campaign_id}/documents", "List campaign documents", "name mismatch"),
        _tool("generate_campaign_doc", "g8_gtm_create_campaign_document", "POST /api/v1/campaigns/{campaign_id}/documents", "Create a campaign document", "name mismatch"),
        _tool("find_contacts", "g8_find_contacts", "POST /api/v1/search/contacts", "Prospect: search contacts for new leads"),
        _tool("find_companies", "g8_find_companies", "POST /api/v1/search/companies", "Prospect: search company database for targets"),
        _tool("create_contact", "g8_create_contact", "POST /api/v1/contacts", "Save a prospect to your CRM"),
        _tool("create_list", "g8_create_list", "POST /api/v1/lists (+ optional /contacts or /search/contacts/save)", "Create a list - empty, or pre-populated via contact_ids / rows / filters"),
        _tool("add_to_list", "g8_add_to_list", "POST /api/v1/lists/{list_id}/contacts (or /contacts loop)", "Add to a list by contact_ids or by explicit rows"),
        _tool("enrich_contacts", "g8_enrich_contacts", "POST /api/v1/enrichment/enrich", "Bulk enrich CRM contacts with external data"),
        _tool("get_global_context", "g8_gtm_get_global_context", "GET /api/v1/global-context/documents", "Get global context documents", "name mismatch"),
        _tool("search_kb", "g8_gtm_search_kb", "POST /api/v1/kb/search", "Search knowledge base", "name mismatch"),
        _tool("get_lists", "g8_get_lists", "GET /api/v1/lists", "List contact lists for targeting", "name mismatch"),
        _tool("get_sequences", "g8_list_sequences", "GET /api/v1/sequences", "List sequences for campaign delivery", "name mismatch"),
        _tool("lookup_person", "g8_lookup_person", "POST /api/v1/enrichment/lookup/person", "Look up a person by email or LinkedIn"),
        _tool("lookup_company", "g8_lookup_company", "POST /api/v1/enrichment/lookup/company", "Look up a company by domain"),
        _tool("add_to_sequence", "g8_add_to_sequence", "POST /api/v1/sequences/{sequence_id}/contacts", "Enroll contacts in an outbound sequence"),
        _tool("get_personas", "g8_gtm_get_personas", "GET /api/v1/personas", "List personas for campaign targeting", "name mismatch"),
        _tool("get_icps", "g8_gtm_get_icps", "GET /api/v1/icps", "List ICPs for campaign targeting", "name mismatch"),
        _tool("get_campaign_ideas", "g8_gtm_get_campaign_ideas", "GET /api/v1/campaigns/ideas", "List generated campaign ideas", "name mismatch"),
        # Sequence lifecycle (campaign context)
        _tool("create_sequence", "g8_create_sequence", "POST /api/v1/sequences", "Create a sequence for campaign delivery"),
        _tool("sequence_preview", "g8_get_sequence_preview", "GET /api/v1/sequences/{id}/preview", "Preview sequence steps before launching"),
        _tool("pause_sequence", "g8_pause_sequence", "POST /api/v1/sequences/{id}/pause", "Pause a live sequence"),
        _tool("resume_sequence", "g8_resume_sequence", "POST /api/v1/sequences/{id}/resume", "Resume a paused sequence"),
        _tool("sequence_analytics", "g8_get_sequence_analytics", "GET /api/v1/sequences/{id}/analytics", "Get sequence performance metrics"),
        # Inbox (reply management)
        _tool("list_inbox", "g8_list_inbox", "GET /api/v1/inbox", "List reply threads across email, SMS, LinkedIn"),
        _tool("get_reply", "g8_get_reply", "GET /api/v1/inbox/{reply_id}", "Get a reply thread with messages"),
        _tool("assign_reply", "g8_assign_reply", "POST /api/v1/inbox/{reply_id}/assign", "Assign a reply to a team member"),
        _tool("tag_reply", "g8_tag_reply", "POST /api/v1/inbox/{reply_id}/tag", "Tag a reply thread"),
        _tool("send_reply", "g8_send_reply", "POST /api/v1/inbox/{reply_id}/send", "Send a reply via email, SMS, or LinkedIn"),
        # Audience sync
        _tool("list_audience_syncs", "g8_list_audience_syncs", "GET /api/v1/audience-syncs", "List audience sync configs"),
        _tool("create_audience_sync", "g8_create_audience_sync", "POST /api/v1/audience-syncs", "Create audience sync to ad platform"),
        _tool("trigger_audience_sync", "g8_trigger_audience_sync", "POST /api/v1/audience-syncs/{id}/trigger", "Manually trigger a sync run"),
        _tool("get_audience_sync_runs", "g8_get_audience_sync_runs", "GET /api/v1/audience-syncs/{id}/runs", "View sync run history"),
        _tool("get_audience_sync_errors", "g8_get_audience_sync_errors", "GET /api/v1/audience-syncs/{id}/errors", "View sync error logs"),
        # Workflow builder (proxies voice's /api/v1/actions/* with runtime_type='workflow')
        _tool("workflow_list_node_types", "g8_workflow_list_node_types", "GET /api/v1/workflows/node-types/schema", "Catalog of every workflow node type with config schema"),
        _tool("workflow_describe_node_type", "g8_workflow_describe_node_type", "GET /api/v1/workflows/node-types/schema?node_type=X", "Full Pydantic config schema for one node type"),
        _tool("workflow_list", "g8_workflow_list", "GET /api/v1/workflows", "List workflows for the org"),
        _tool("workflow_get", "g8_workflow_get", "GET /api/v1/workflows/{action_id}", "Get full workflow graph (nodes + edges + trigger)"),
        _tool("workflow_get_trigger_status", "g8_workflow_get_trigger_status", "GET /api/v1/workflows/{action_id}/trigger-status", "Trigger config + last cursor for a workflow"),
        _tool("workflow_create", "g8_workflow_create", "POST /api/v1/workflows", "Create a new workflow (DESTRUCTIVE - supports dry_run)"),
        _tool("workflow_update", "g8_workflow_update", "PUT /api/v1/workflows/{action_id}", "Partially update a workflow's metadata or graph"),
        _tool("workflow_delete", "g8_workflow_delete", "DELETE /api/v1/workflows/{action_id}", "Delete a workflow (DESTRUCTIVE - supports dry_run)"),
        _tool("workflow_validate", "g8_workflow_validate", "POST /api/v1/workflows/validate", "Validate a workflow graph without saving"),
        _tool("workflow_add_node", "g8_workflow_add_node", "GET+PUT /api/v1/workflows/{action_id}", "Granular: append a node (and optional edge)"),
        _tool("workflow_update_node", "g8_workflow_update_node", "GET+PUT /api/v1/workflows/{action_id}", "Granular: patch one node's config / label / position"),
        _tool("workflow_remove_node", "g8_workflow_remove_node", "GET+PUT /api/v1/workflows/{action_id}", "Granular: remove a node + its dangling edges"),
        _tool("workflow_connect_nodes", "g8_workflow_connect_nodes", "GET+PUT /api/v1/workflows/{action_id}", "Granular: append an edge (idempotent on source/target)"),
        _tool("workflow_execute", "g8_workflow_execute", "POST /api/v1/workflows/{action_id}/execute", "Trigger a workflow run (DESTRUCTIVE - supports dry_run)"),
        _tool("workflow_get_execution", "g8_workflow_get_execution", "GET /api/v1/workflows/executions/{execution_id}", "Poll execution status / output / token cost"),
        _tool("workflow_pause_execution", "g8_workflow_pause_execution", "POST /api/v1/workflows/executions/{execution_id}/pause", "Pause a running execution (reversible, tenant-checked)"),
        _tool("workflow_resume_execution", "g8_workflow_resume_execution", "POST /api/v1/workflows/executions/{execution_id}/resume", "Resume a paused execution (reversible, tenant-checked)"),
        _tool("workflow_stop_execution", "g8_workflow_stop_execution", "POST /api/v1/workflows/executions/{execution_id}/stop", "Permanently stop an execution (DESTRUCTIVE - supports dry_run)"),
        _tool("workflow_reset_trigger_cursor", "g8_workflow_reset_trigger_cursor", "POST /api/v1/workflows/{action_id}/trigger-reset", "Reset trigger cursor to now() so backlog isn't replayed"),
    ],
    "intent": [
        # Pages layer - free-form competitor research over the intent-enriched index.
        _tool("intent_domain_search", "g8_intent_domain_search", "POST /api/v1/intent/pages-by-domain", "Find every indexed page on a competitor domain plus subdomains"),
        _tool("intent_search_pages", "g8_intent_search_pages", "POST /api/v1/intent/pages/search", "Text / semantic / hybrid search across intent-enriched pages"),
        _tool("intent_page_visitors", "g8_intent_page_visitors", "POST /api/v1/intent/pages/visitors", "Resolve people who visited a single page URL"),
        _tool("intent_pages_contacts", "g8_intent_pages_contacts", "POST /api/v1/intent/pages/contacts", "Aggregated, deduplicated resolved contacts across multiple URLs"),
        _tool("intent_pages_visitor_counts", "g8_intent_pages_visitor_counts", "POST /api/v1/intent/pages/visitor-counts", "Batched unique-visitor count per page URL"),
        _tool("intent_stats", "g8_intent_stats", "GET /api/v1/intent/stats", "Intent index coverage (doc count + size)"),
        # Keywords layer - per-org saved compete-tracking rows.
        _tool("intent_list_keywords", "g8_intent_list_keywords", "POST /api/v1/intent/keywords/list", "List all compete-tracking keyword rows for the org"),
        _tool("intent_create_from_domain", "g8_intent_create_from_domain", "POST /api/v1/intent/keywords/create-from-domain", "One-shot: domain to URLs to contacts to saved keyword row"),
        _tool("intent_delete_keyword", "g8_intent_delete_keyword", "DELETE /api/v1/intent/keywords/{keyword_id}", "Soft-delete a compete-tracking keyword row"),
        _tool("intent_keyword_urls", "g8_intent_keyword_urls", "POST /api/v1/intent/keywords/{keyword_id}/urls", "URLs linked to a compete-tracking keyword"),
        _tool("intent_keyword_contacts", "g8_intent_keyword_contacts", "POST /api/v1/intent/keywords/{keyword_id}/contacts", "Resolved people for a saved keyword"),
        _tool("intent_keyword_companies", "g8_intent_keyword_companies", "POST /api/v1/intent/keywords/{keyword_id}/companies", "Resolved companies for a saved keyword (ABM-style roll-up)"),
        _tool("intent_update_keyword_filters", "g8_intent_update_keyword_filters", "POST /api/v1/intent/keywords/{keyword_id}/filters", "Replace a keyword's search_filters JSON"),
        # URL drill-down (intent_search module).
        _tool("intent_search_url_companies", "g8_intent_search_url_companies", "POST /api/v1/intent-search/url-companies", "Companies that visited a single URL with B2B/B2C split + enrichment"),
    ],
    "dev": [
        _tool("scan_repo", "g8_scan_repo", "POST /api/v1/repos/{repo_id}/scan", "Record pre-computed scan results (CLI runs the actual scan)"),
        _tool("get_scan_results", "g8_get_scan_results", "GET /api/v1/repos/{repo_id}/scan", "Get latest scan results for a repo"),
        _tool("generate_snippet", "g8_get_tracking_snippet", "GET /api/v1/snippet", "Generate tracking snippet (React + vanilla JS)", "name mismatch"),
        _tool("generate_form", "g8_get_form_template", "GET /api/v1/snippet/form", "Generate a lead-capture HTML form wired to tracking", "name mismatch"),
        _tool("get_install_plan", "g8_install_spine", "POST /api/v1/repos/{repo_id}/install", "Generate GTM install patch set (CLI applies it)", "name mismatch"),
        _tool("install_spine", "g8_install_spine", "POST /api/v1/repos/{repo_id}/install", "Generate GTM install patch set (CLI applies it)"),
        _tool("get_campaigns", "g8_list_campaigns", "GET /api/v1/repos/{repo_id}/campaigns", "List campaigns", "name mismatch"),
        _tool("get_campaign", "g8_get_campaign", "GET /api/v1/repos/{repo_id}/campaigns/{campaign_id}", "Get campaign details", "name mismatch"),
        _tool("get_sequences", "g8_list_sequences", "GET /api/v1/sequences", "List sequences", "name mismatch"),
        _tool("get_lists", "g8_get_lists", "GET /api/v1/lists", "List contact lists"),
        _tool("search_contacts", "g8_search_contacts", "GET /api/v1/contacts", "Search contacts in your CRM"),
        _tool("search_companies", "g8_search_companies", "GET /api/v1/companies", "Search companies in your CRM"),
        _tool("lookup_person", "g8_lookup_person", "POST /api/v1/enrichment/lookup/person", "Look up a person"),
        _tool("lookup_company", "g8_lookup_company", "POST /api/v1/enrichment/lookup/company", "Look up a company"),
        _tool("search_kb", "g8_search_kb", "POST /api/v1/repos/{repo_id}/kb/search", "Search knowledge base"),
    ],
}


def profile_tool_catalog() -> dict[str, Any]:
    """Return the Profile-ready catalog with dynamic group counts."""
    groups = []
    total = 0
    for group in MCP_TOOL_GROUPS:
        value = group["value"]
        if value == "all":
            continue
        count = len(MCP_TOOL_CATALOG.get(value, []))
        total += count
        groups.append({**group, "toolCount": f"{count} tools"})
    groups.append({**MCP_TOOL_GROUPS[-1], "toolCount": f"{total} tools"})
    return {"groups": groups, "tools": MCP_TOOL_CATALOG}
