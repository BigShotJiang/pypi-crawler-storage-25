"""Tests for VibePR utilities."""

import pytest
from vibe_pr.utils import (
    detect_language,
    should_ignore_file,
    extract_github_pr_info,
    truncate_text,
    format_duration,
    get_file_icon,
)


class TestDetectLanguage:
    def test_python(self):
        assert detect_language("app.py") == "python"

    def test_javascript(self):
        assert detect_language("index.js") == "javascript"

    def test_typescript(self):
        assert detect_language("app.ts") == "typescript"

    def test_tsx(self):
        assert detect_language("Component.tsx") == "typescript"

    def test_go(self):
        assert detect_language("main.go") == "go"

    def test_rust(self):
        assert detect_language("lib.rs") == "rust"

    def test_dockerfile(self):
        assert detect_language("Dockerfile") == "dockerfile"

    def test_unknown(self):
        assert detect_language("file.xyz") is None


class TestShouldIgnoreFile:
    def test_ignore_min_js(self):
        assert should_ignore_file("dist/app.min.js", ["*.min.js"])

    def test_ignore_lock_file(self):
        assert should_ignore_file("package-lock.json", ["package-lock.json"])

    def test_not_ignored(self):
        assert not should_ignore_file("app.py", ["*.min.js"])


class TestExtractGithubPrInfo:
    def test_full_url(self):
        result = extract_github_pr_info("https://github.com/owner/repo/pull/123")
        assert result == ("owner", "repo", 123)

    def test_url_with_path(self):
        result = extract_github_pr_info("https://github.com/my-org/my-repo/pull/42")
        assert result == ("my-org", "my-repo", 42)

    def test_invalid_url(self):
        result = extract_github_pr_info("https://example.com")
        assert result is None


class TestTruncateText:
    def test_short_text(self):
        assert truncate_text("hello", 10) == "hello"

    def test_long_text(self):
        result = truncate_text("a" * 300, 100)
        assert len(result) == 100
        assert result.endswith("...")


class TestFormatDuration:
    def test_milliseconds(self):
        assert format_duration(0.5) == "500ms"

    def test_seconds(self):
        assert format_duration(5.3) == "5.3s"

    def test_minutes(self):
        assert "m" in format_duration(90)


class TestGetFileIcon:
    def test_python_icon(self):
        assert get_file_icon("python") == "🐍"

    def test_javascript_icon(self):
        assert get_file_icon("javascript") == "🟨"

    def test_unknown_icon(self):
        assert get_file_icon(None) == "📄"
