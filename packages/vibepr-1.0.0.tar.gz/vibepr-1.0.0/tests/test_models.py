"""Tests for VibePR models."""

import pytest
from vibe_pr.models import (
    Finding,
    FindingLevel,
    ReviewResult,
    PRInfo,
    FileChange,
    Verdict,
)


class TestFindingLevel:
    def test_severity_ordering(self):
        assert FindingLevel.BLOCKER < FindingLevel.WARNING
        assert FindingLevel.WARNING < FindingLevel.SUGGESTION
        assert FindingLevel.SUGGESTION < FindingLevel.PRAISE

    def test_severity_rank(self):
        assert FindingLevel.BLOCKER.severity_rank == 0
        assert FindingLevel.PRAISE.severity_rank == 3


class TestFinding:
    def test_creation(self):
        f = Finding(
            file="test.py",
            line=42,
            level=FindingLevel.WARNING,
            issue="Test issue",
            detail="Test detail",
        )
        assert f.file == "test.py"
        assert f.line == 42
        assert f.level == FindingLevel.WARNING

    def test_default_confidence(self):
        f = Finding(
            file="test.py",
            level=FindingLevel.SUGGESTION,
            issue="Test",
            detail="Test",
        )
        assert f.confidence == 1.0


class TestReviewResult:
    def test_stats_computation(self):
        result = ReviewResult(
            pr_info=PRInfo(files=[FileChange(path="a.py"), FileChange(path="b.py")]),
            findings=[
                Finding(file="a.py", level=FindingLevel.BLOCKER, issue="b1", detail="d1"),
                Finding(file="a.py", level=FindingLevel.BLOCKER, issue="b2", detail="d2"),
                Finding(file="b.py", level=FindingLevel.WARNING, issue="w1", detail="d3"),
                Finding(file="b.py", level=FindingLevel.SUGGESTION, issue="s1", detail="d4"),
                Finding(file="a.py", level=FindingLevel.PRAISE, issue="p1", detail="d5"),
            ],
        )
        stats = result.stats
        assert stats["blockers"] == 2
        assert stats["warnings"] == 1
        assert stats["suggestions"] == 1
        assert stats["praises"] == 1
        assert stats["total_files"] == 2
        assert stats["total_findings"] == 5

    def test_property_filters(self):
        result = ReviewResult(
            pr_info=PRInfo(),
            findings=[
                Finding(file="a.py", level=FindingLevel.BLOCKER, issue="b", detail="d"),
                Finding(file="a.py", level=FindingLevel.PRAISE, issue="p", detail="d"),
            ],
        )
        assert len(result.blockers) == 1
        assert len(result.praises) == 1
        assert len(result.warnings) == 0


class TestFileChange:
    def test_defaults(self):
        fc = FileChange(path="test.py")
        assert fc.status == "modified"
        assert fc.additions == 0
        assert fc.deletions == 0
        assert fc.added_lines == []
        assert fc.removed_lines == []
