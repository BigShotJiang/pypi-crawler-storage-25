"""Tests for VibePR analyzers."""

import pytest
from vibe_pr.models import FileChange, FindingLevel, PRInfo
from vibe_pr.analyzers.security import SecurityAnalyzer
from vibe_pr.analyzers.logic import LogicAnalyzer
from vibe_pr.analyzers.performance import PerformanceAnalyzer
from vibe_pr.analyzers.maintainability import MaintainabilityAnalyzer


@pytest.fixture
def pr_context():
    """Minimal PR context for testing."""
    return PRInfo(title="Test PR", description="Test", author="tester")


class TestSecurityAnalyzer:
    """Tests for the security analyzer."""

    def setup_method(self):
        self.analyzer = SecurityAnalyzer()

    def _make_file(self, lines: list[tuple[int, str]], lang="python", path="test.py"):
        return FileChange(
            path=path,
            language=lang,
            added_lines=lines,
        )

    def test_detects_hardcoded_aws_key(self, pr_context):
        fc = self._make_file([(1, 'aws_key = "AKIAIOSFODNN7EXAMPLE1"')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any(f.level == FindingLevel.BLOCKER for f in findings)
        assert any("AWS" in f.issue for f in findings)

    def test_detects_eval(self, pr_context):
        fc = self._make_file([(1, 'result = eval(user_input)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("eval" in f.issue.lower() for f in findings)

    def test_detects_exec(self, pr_context):
        fc = self._make_file([(1, 'exec(code_string)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("exec" in f.issue.lower() for f in findings)

    def test_detects_sql_injection_fstring(self, pr_context):
        fc = self._make_file([(1, 'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("SQL" in f.issue.upper() or "injection" in f.issue.lower() for f in findings)

    def test_detects_subprocess_shell_true(self, pr_context):
        fc = self._make_file([(1, 'subprocess.run(cmd, shell=True)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("shell" in f.issue.lower() for f in findings)

    def test_detects_pickle_loads(self, pr_context):
        fc = self._make_file([(1, 'data = pickle.loads(payload)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("pickle" in f.issue.lower() for f in findings)

    def test_ignores_comments(self, pr_context):
        fc = self._make_file([(1, '# eval(user_input)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert len(findings) == 0

    def test_detects_hardcoded_password(self, pr_context):
        fc = self._make_file([(1, 'password = "super_secret_123"')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("password" in f.issue.lower() or "Password" in f.issue for f in findings)

    def test_detects_github_token(self, pr_context):
        fc = self._make_file([(1, 'token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh"')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("GitHub" in f.issue for f in findings)

    def test_detects_js_eval(self, pr_context):
        fc = self._make_file([(1, 'var x = eval(userInput)')], lang="javascript", path="test.js")
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("eval" in f.issue.lower() for f in findings)

    def test_detects_innerhtml(self, pr_context):
        fc = self._make_file([(1, 'element.innerHTML = userInput')], lang="javascript", path="test.js")
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("innerHTML" in f.issue for f in findings)

    def test_no_findings_for_clean_code(self, pr_context):
        fc = self._make_file([
            (1, 'def hello(name: str) -> str:'),
            (2, '    return f"Hello, {name}!"'),
        ])
        findings = self.analyzer.analyze(fc, pr_context)
        assert len(findings) == 0


class TestLogicAnalyzer:
    """Tests for the logic analyzer."""

    def setup_method(self):
        self.analyzer = LogicAnalyzer()

    def _make_file(self, lines, lang="python", path="test.py"):
        return FileChange(path=path, language=lang, added_lines=lines)

    def test_detects_bare_except(self, pr_context):
        fc = self._make_file([(1, 'except:')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("except" in f.issue.lower() or "Bare" in f.issue for f in findings)

    def test_detects_none_comparison_equals(self, pr_context):
        fc = self._make_file([(1, 'if x == None:')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("is None" in f.issue for f in findings)

    def test_detects_js_equality(self, pr_context):
        fc = self._make_file([(1, 'if (x == y)')], lang="javascript", path="test.js")
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("===" in f.issue or "==" in f.issue for f in findings)

    def test_detects_swallowed_exception(self, pr_context):
        fc = self._make_file([
            (1, 'except Exception as e:'),
            (2, '    pass'),
        ])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("pass" in f.issue.lower() or "ignored" in f.issue.lower() for f in findings)


class TestPerformanceAnalyzer:
    """Tests for the performance analyzer."""

    def setup_method(self):
        self.analyzer = PerformanceAnalyzer()

    def _make_file(self, lines, lang="python", path="test.py"):
        return FileChange(path=path, language=lang, added_lines=lines)

    def test_detects_file_without_with(self, pr_context):
        fc = self._make_file([(1, 'f = open("data.txt", "r")')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("open" in f.issue.lower() or "with" in f.issue.lower() for f in findings)

    def test_detects_sync_fs_in_js(self, pr_context):
        fc = self._make_file(
            [(1, 'const data = fs.readFileSync("file.txt")')],
            lang="javascript", path="app.js",
        )
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("Sync" in f.issue or "readFileSync" in f.issue for f in findings)

    def test_detects_time_sleep(self, pr_context):
        fc = self._make_file([(1, 'time.sleep(5)')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("sleep" in f.issue.lower() for f in findings)


class TestMaintainabilityAnalyzer:
    """Tests for the maintainability analyzer."""

    def setup_method(self):
        self.analyzer = MaintainabilityAnalyzer()

    def _make_file(self, lines, lang="python", path="test.py"):
        return FileChange(path=path, language=lang, added_lines=lines)

    def test_detects_todo_in_new_code(self, pr_context):
        fc = self._make_file([(1, '# TODO: fix this later')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("TODO" in f.issue for f in findings)

    def test_detects_fixme(self, pr_context):
        fc = self._make_file([(1, '# FIXME: broken edge case')])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("FIXME" in f.issue for f in findings)

    def test_detects_deep_nesting(self, pr_context):
        fc = self._make_file([(1, '                        x = 1')])  # 24 spaces = depth 6
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("nested" in f.issue.lower() or "depth" in f.issue.lower() for f in findings)

    def test_praises_good_type_hints(self, pr_context):
        fc = self._make_file([
            (1, 'def foo(x: int) -> str:'),
            (2, 'def bar(y: float) -> bool:'),
            (3, 'def baz(z: str) -> list:'),
        ])
        findings = self.analyzer.analyze(fc, pr_context)
        praises = [f for f in findings if f.level == FindingLevel.PRAISE]
        assert any("type hint" in f.issue.lower() for f in praises)

    def test_detects_missing_docstring(self, pr_context):
        fc = self._make_file([
            (1, 'def public_function(x):'),
            (2, '    return x + 1'),
        ])
        findings = self.analyzer.analyze(fc, pr_context)
        assert any("docstring" in f.issue.lower() for f in findings)
