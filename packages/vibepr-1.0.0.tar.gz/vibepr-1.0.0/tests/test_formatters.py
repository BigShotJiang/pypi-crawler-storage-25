"""Tests for VibePR formatters."""

import json
import pytest
from vibe_pr.models import (
    Finding,
    FindingLevel,
    PRInfo,
    FileChange,
    ReviewResult,
    Verdict,
)
from vibe_pr.formatters.json_formatter import format_json
from vibe_pr.formatters.markdown import format_markdown


@pytest.fixture
def sample_result():
    """Create a sample ReviewResult for testing."""
    return ReviewResult(
        pr_info=PRInfo(
            title="Fix authentication bug",
            description="Fixes the login flow for expired tokens",
            author="testuser",
            url="https://github.com/owner/repo/pull/42",
            number=42,
            repo_full_name="owner/repo",
            base_branch="main",
            head_branch="fix/auth-bug",
            files=[
                FileChange(path="auth.py", status="modified", additions=10, deletions=5),
                FileChange(path="tests/test_auth.py", status="modified", additions=20, deletions=0),
            ],
        ),
        summary="This PR fixes the authentication flow for expired tokens.",
        findings=[
            Finding(
                file="auth.py",
                line=42,
                level=FindingLevel.BLOCKER,
                issue="Hardcoded secret key",
                detail="A secret key is hardcoded in the source.",
                fix="Move to environment variable.",
            ),
            Finding(
                file="auth.py",
                line=55,
                level=FindingLevel.WARNING,
                issue="Missing error handling",
                detail="No try/except around API call.",
                fix="Wrap in try/except.",
            ),
            Finding(
                file="tests/test_auth.py",
                line=10,
                level=FindingLevel.PRAISE,
                issue="Good test coverage",
                detail="Comprehensive tests for edge cases.",
            ),
        ],
        verdict=Verdict.REQUEST_CHANGES,
        verdict_reason="1 blocker must be fixed.",
        must_fix=["auth.py:42 — Hardcoded secret key"],
        review_duration_seconds=2.5,
        analyzers_used=["security", "logic"],
    )


class TestJsonFormatter:
    def test_valid_json_output(self, sample_result):
        output = format_json(sample_result)
        data = json.loads(output)  # Should not raise
        assert data["vibepr_version"] == "1.0.0"

    def test_correct_structure(self, sample_result):
        data = json.loads(format_json(sample_result))
        assert "pr" in data
        assert "findings" in data
        assert "verdict" in data
        assert "stats" in data
        assert len(data["findings"]) == 3

    def test_verdict_value(self, sample_result):
        data = json.loads(format_json(sample_result))
        assert data["verdict"] == "REQUEST_CHANGES"

    def test_stats_correct(self, sample_result):
        data = json.loads(format_json(sample_result))
        assert data["stats"]["blockers"] == 1
        assert data["stats"]["warnings"] == 1
        assert data["stats"]["praises"] == 1


class TestMarkdownFormatter:
    def test_contains_header(self, sample_result):
        md = format_markdown(sample_result)
        assert "# ⚡ VibePR Review" in md

    def test_contains_verdict(self, sample_result):
        md = format_markdown(sample_result)
        assert "CHANGES REQUESTED" in md

    def test_contains_findings(self, sample_result):
        md = format_markdown(sample_result)
        assert "Hardcoded secret key" in md
        assert "Missing error handling" in md

    def test_hide_praise(self, sample_result):
        md = format_markdown(sample_result, show_praise=False)
        assert "Good test coverage" not in md

    def test_contains_stats_table(self, sample_result):
        md = format_markdown(sample_result)
        assert "| 🔴 Blockers" in md

    def test_contains_powered_by(self, sample_result):
        md = format_markdown(sample_result)
        assert "Powered by VibePR" in md
