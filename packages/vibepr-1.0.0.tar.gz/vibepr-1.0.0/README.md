<div align="center">

# ⚡ VibePR

### AI-Powered PR Review Agent

**Reviews pull requests with the depth, care, and directness of a senior engineer.**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)

</div>

---

## 🚀 What is VibePR?

VibePR is an intelligent, opinionated PR review tool that combines **built-in static analysis** with **LLM-powered semantic review** to catch bugs, security vulnerabilities, and code quality issues that other tools miss.

Unlike linters, VibePR thinks at the level of **logic, architecture, security, and intent**.

### Key Features

- 🔍 **Multi-dimensional analysis** — Security, logic, performance, and maintainability checks
- 🤖 **AI-powered deep review** — Optional LLM integration (OpenAI / Anthropic) for semantic analysis
- 🎯 **Smart verdicts** — Automatically determines APPROVE, REQUEST_CHANGES, or COMMENT
- 📊 **Beautiful output** — Rich terminal UI, JSON for CI/CD, and Markdown for GitHub comments
- 🌐 **Web dashboard** — Browse and search past reviews with a premium dark-mode UI
- 📦 **GitHub integration** — Fetch PRs directly, post reviews as comments
- 💾 **Review history** — SQLite-backed storage for all past reviews
- 🔧 **Configurable** — YAML configuration with per-project overrides

---

## 📦 Installation

```bash
pip install vibepr
```

Or install from source:

```bash
git clone https://github.com/chandanhastantram/vibepr.git
cd vibepr
pip install -e .
```

---

## ⚡ Quick Start

### Review a GitHub PR

```bash
# Review a public PR (no token needed)
vibepr review https://github.com/owner/repo/pull/123

# Review with GitHub token for private repos
export GITHUB_TOKEN=ghp_your_token
vibepr review https://github.com/owner/repo/pull/123

# Shorthand format
vibepr review owner/repo#123
```

### Review Local Changes

```bash
# Review all uncommitted changes
vibepr review --local

# Review against a specific branch
vibepr review --local --base main

# Review only staged changes
vibepr review --local --staged
```

### Deep AI Review

```bash
# Enable LLM-powered analysis (requires API key)
export OPENAI_API_KEY=sk-your-key
vibepr review https://github.com/owner/repo/pull/123 --deep

# Or use Anthropic
export ANTHROPIC_API_KEY=sk-ant-your-key
vibepr review --local --deep
```

### Output Formats

```bash
# Beautiful terminal output (default)
vibepr review --local

# JSON for CI/CD pipelines
vibepr review --local --format json

# Markdown for GitHub comments
vibepr review --local --format markdown

# Post review directly to GitHub
vibepr review <PR_URL> --post
```

---

## 🔍 What VibePR Checks

### 🔴 Security
| Check | Languages | Severity |
|-------|-----------|----------|
| Hardcoded secrets (AWS, Stripe, GitHub, OpenAI, etc.) | All | BLOCKER |
| SQL injection via string interpolation | Python, JS | BLOCKER |
| Command injection (os.system, subprocess shell=True) | Python | BLOCKER |
| Unsafe functions (eval, exec, pickle.loads) | Python, JS | BLOCKER |
| XSS via innerHTML | JavaScript | BLOCKER |
| Path traversal vulnerabilities | Python | WARNING |
| Database connection strings in code | All | BLOCKER |

### 🟡 Logic & Correctness
| Check | Languages | Severity |
|-------|-----------|----------|
| Bare except clauses | Python | WARNING |
| Swallowed exceptions (except + pass) | Python | WARNING |
| == None instead of is None | Python | SUGGESTION |
| == instead of === | JavaScript | WARNING |
| Floating promises (missing await) | JavaScript | WARNING |
| Empty catch blocks | JavaScript | WARNING |

### 🔵 Performance
| Check | Languages | Severity |
|-------|-----------|----------|
| N+1 query patterns in loops | Python, JS | WARNING |
| File opened without context manager | Python | WARNING |
| Sync fs operations blocking event loop | JavaScript | WARNING |
| HTTP requests inside loops | Python, JS | WARNING |
| useEffect without dependency array | React | WARNING |
| Event listeners without cleanup | JavaScript | SUGGESTION |

### 🟢 Maintainability
| Check | Languages | Severity |
|-------|-----------|----------|
| Magic numbers in logic | All | SUGGESTION |
| Deep nesting (>4 levels) | All | WARNING |
| Long functions (>50 lines) | Python | SUGGESTION |
| Missing docstrings on public APIs | Python | SUGGESTION |
| TODO/FIXME/HACK in new code | All | SUGGESTION/WARNING |
| Good type hints (praise) | Python | PRAISE |
| Good test coverage (praise) | All | PRAISE |

---

## ⚙️ Configuration

Create a `.vibepr.yml` in your project root or home directory:

```yaml
github:
  token: ""  # Or set GITHUB_TOKEN env var

llm:
  provider: "none"     # "openai", "anthropic", or "none"
  api_key: ""          # Or set OPENAI_API_KEY / ANTHROPIC_API_KEY
  model: "gpt-4o"

review:
  security: true
  logic: true
  performance: true
  maintainability: true
  min_level: "suggestion"  # "blocker", "warning", "suggestion", "praise"
  ignore_patterns:
    - "*.min.js"
    - "package-lock.json"
    - "*.lock"

output:
  format: "terminal"    # "terminal", "json", "markdown"
  show_praise: true
  color: true

dashboard:
  host: "127.0.0.1"
  port: 8777
  db_path: "~/.vibepr/reviews.db"
```

---

## 📊 Web Dashboard

Launch the built-in web dashboard to browse and search past reviews:

```bash
vibepr dashboard
```

Opens at `http://127.0.0.1:8777` with:
- 📊 Aggregate statistics across all reviews
- 📜 Review history with filtering
- 🔍 Detailed finding view per review
- 🎨 Premium dark-mode UI

---

## 📜 Review History

```bash
# View recent reviews
vibepr history

# Filter by repo
vibepr history --repo owner/repo

# Filter by verdict
vibepr history --verdict REQUEST_CHANGES

# Limit results
vibepr history --limit 5
```

---

## 🏗️ Architecture

```
vibe_pr/
├── cli.py              # Click CLI — entry point
├── config.py           # YAML config + env vars
├── models.py           # Pydantic data models
├── reviewer.py         # Core orchestrator
├── github_client.py    # GitHub API (PyGithub)
├── diff_parser.py      # Unified diff parsing
├── storage.py          # SQLite review history
├── utils.py            # Shared utilities
├── analyzers/          # Static analysis engines
│   ├── security.py     # Secret, injection, unsafe function detection
│   ├── logic.py        # Error handling, edge cases, comparisons
│   ├── performance.py  # N+1, memory leaks, blocking ops
│   └── maintainability.py # Complexity, naming, documentation
├── llm/                # LLM providers
│   ├── openai_provider.py
│   ├── anthropic_provider.py
│   └── prompts.py      # Review prompt templates
├── formatters/         # Output renderers
│   ├── terminal.py     # Rich terminal UI
│   ├── json_formatter.py
│   └── markdown.py
└── dashboard/          # Web dashboard (Flask)
    ├── app.py
    ├── templates/
    └── static/
```

---

## 🧪 Testing

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ -v --cov=vibe_pr --cov-report=term-missing
```

---

## 📋 Finding Levels

| Level | Icon | Meaning |
|-------|------|---------|
| **BLOCKER** | 🔴 | Must fix before merge. Logic errors, security vulnerabilities, data loss risks. |
| **WARNING** | 🟡 | Should fix. Performance issues, missing error handling, unclear naming. |
| **SUGGESTION** | 🔵 | Consider changing. Better patterns, simpler approaches, future-proofing. |
| **PRAISE** | 🟢 | What is done well. Good abstractions, smart optimizations, clean coverage. |

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

<div align="center">

**Built with ❤️ by the VibePR team**

⚡ *Review code like a senior engineer, every time.*

</div>
