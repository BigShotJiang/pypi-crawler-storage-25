"""
Diff parser for VibePR.
Parses unified diffs from local git repos and remote sources.
"""

from __future__ import annotations

import io
import subprocess
from pathlib import Path
from typing import Optional

from vibe_pr.models import FileChange, PRInfo
from vibe_pr.utils import detect_language


class DiffParserError(Exception):
    """Raised when diff parsing fails."""
    pass


def parse_diff_string(diff_text: str) -> list[FileChange]:
    """
    Parse a unified diff string into FileChange objects.
    Uses the unidiff library for robust parsing.
    """
    try:
        from unidiff import PatchSet
    except ImportError:
        raise DiffParserError("unidiff is required. Install with: pip install unidiff")

    try:
        patch_set = PatchSet(io.StringIO(diff_text))
    except Exception as e:
        raise DiffParserError(f"Failed to parse diff: {e}")

    files = []
    for patched_file in patch_set:
        added_lines = []
        removed_lines = []

        for hunk in patched_file:
            for line in hunk:
                if line.is_added:
                    added_lines.append((line.target_line_no, line.value.rstrip("\n")))
                elif line.is_removed:
                    removed_lines.append((line.source_line_no, line.value.rstrip("\n")))

        # Determine file status
        if patched_file.is_added_file:
            status = "added"
        elif patched_file.is_removed_file:
            status = "removed"
        elif patched_file.is_rename:
            status = "renamed"
        else:
            status = "modified"

        file_path = patched_file.path or ""
        language = detect_language(file_path)

        # Reconstruct the raw patch text for this file
        patch_text = str(patched_file)

        files.append(
            FileChange(
                path=file_path,
                status=status,
                additions=patched_file.added,
                deletions=patched_file.removed,
                patch=patch_text,
                added_lines=added_lines,
                removed_lines=removed_lines,
                language=language,
            )
        )

    return files


def parse_local_diff(
    repo_path: str = ".",
    base_ref: Optional[str] = None,
    staged_only: bool = False,
) -> tuple[PRInfo, list[FileChange]]:
    """
    Parse local git diff into FileChange objects.

    Args:
        repo_path: Path to the git repository
        base_ref: Base reference to diff against (e.g., "main", "HEAD~1")
        staged_only: If True, only show staged changes

    Returns:
        Tuple of (PRInfo, list of FileChange)
    """
    repo = Path(repo_path).resolve()

    if not (repo / ".git").exists():
        raise DiffParserError(f"Not a git repository: {repo}")

    # Build the git diff command
    cmd = ["git", "-C", str(repo), "diff"]

    if staged_only:
        cmd.append("--cached")
    elif base_ref:
        cmd.append(base_ref)
    else:
        # Default: diff of uncommitted changes (staged + unstaged)
        cmd.append("HEAD")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        raise DiffParserError("Git diff command timed out")
    except FileNotFoundError:
        raise DiffParserError("git command not found. Is git installed?")

    if result.returncode != 0:
        # If HEAD doesn't exist yet (new repo), try without ref
        if "HEAD" in (result.stderr or ""):
            cmd = ["git", "-C", str(repo), "diff", "--cached"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                raise DiffParserError(f"Git diff failed: {result.stderr}")
        else:
            raise DiffParserError(f"Git diff failed: {result.stderr}")

    diff_text = result.stdout
    if not diff_text.strip():
        return _build_local_pr_info(repo, base_ref), []

    files = parse_diff_string(diff_text)

    # Try to get full file content for added lines context
    for file_change in files:
        full_path = repo / file_change.path
        if full_path.exists() and full_path.is_file():
            try:
                file_change.content = full_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                pass

    pr_info = _build_local_pr_info(repo, base_ref)
    pr_info.files = files

    return pr_info, files


def _build_local_pr_info(repo: Path, base_ref: Optional[str]) -> PRInfo:
    """Build PRInfo from local git metadata."""
    # Get current branch
    try:
        branch_result = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        head_branch = branch_result.stdout.strip() if branch_result.returncode == 0 else "unknown"
    except Exception:
        head_branch = "unknown"

    # Get repo name from directory
    repo_name = repo.name

    # Get last commit message as description
    try:
        log_result = subprocess.run(
            ["git", "-C", str(repo), "log", "-1", "--pretty=%B"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        description = log_result.stdout.strip() if log_result.returncode == 0 else ""
    except Exception:
        description = ""

    # Get git user as author
    try:
        user_result = subprocess.run(
            ["git", "-C", str(repo), "config", "user.name"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        author = user_result.stdout.strip() if user_result.returncode == 0 else ""
    except Exception:
        author = ""

    return PRInfo(
        title=f"Local changes on {head_branch}",
        description=description,
        author=author,
        base_branch=base_ref or "HEAD",
        head_branch=head_branch,
        url=f"local://{repo}",
        number=0,
        repo_full_name=repo_name,
    )
