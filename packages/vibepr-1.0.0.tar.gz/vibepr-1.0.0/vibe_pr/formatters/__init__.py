"""
Output formatters package for VibePR.
"""
