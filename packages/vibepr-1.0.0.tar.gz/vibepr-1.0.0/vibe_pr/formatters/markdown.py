"""
Markdown formatter for VibePR.
Produces markdown reports suitable for GitHub comments or file export.
"""

from __future__ import annotations

from collections import defaultdict

from vibe_pr.models import FindingLevel, ReviewResult
from vibe_pr.utils import format_duration


LEVEL_ICONS = {
    FindingLevel.BLOCKER:    "🔴",
    FindingLevel.WARNING:    "🟡",
    FindingLevel.SUGGESTION: "🔵",
    FindingLevel.PRAISE:     "🟢",
}

VERDICT_LABELS = {
    "APPROVE":         "✅ **APPROVED** — Ready to merge",
    "REQUEST_CHANGES": "❌ **CHANGES REQUESTED** — Must fix before merge",
    "COMMENT":         "💬 **COMMENT** — Review findings attached",
}


def format_markdown(result: ReviewResult, show_praise: bool = True) -> str:
    """Render review results as Markdown."""
    lines: list[str] = []

    # ── Header ────────────────────────────────────────────────────────
    lines.append("# ⚡ VibePR Review")
    lines.append("")

    pr = result.pr_info
    if pr.title:
        lines.append(f"**{pr.title}**")
    if pr.url and not pr.url.startswith("local://"):
        lines.append(f"🔗 [{pr.url}]({pr.url})")
    if pr.author:
        lines.append(f"👤 {pr.author} · `{pr.head_branch}` → `{pr.base_branch}`")
    lines.append("")

    # ── Summary ───────────────────────────────────────────────────────
    if result.summary:
        lines.append("## 📋 Summary")
        lines.append("")
        lines.append(result.summary)
        lines.append("")

    # ── Stats ─────────────────────────────────────────────────────────
    stats = result.stats
    lines.append("## 📊 Statistics")
    lines.append("")
    lines.append("| 🔴 Blockers | 🟡 Warnings | 🔵 Suggestions | 🟢 Praises | 📁 Files |")
    lines.append("|:-----------:|:-----------:|:--------------:|:----------:|:--------:|")
    lines.append(f"| {stats['blockers']} | {stats['warnings']} | {stats['suggestions']} | {stats['praises']} | {stats['total_files']} |")
    lines.append("")

    # ── Findings ──────────────────────────────────────────────────────
    findings_by_file = defaultdict(list)
    for finding in result.findings:
        if not show_praise and finding.level == FindingLevel.PRAISE:
            continue
        findings_by_file[finding.file].append(finding)

    if findings_by_file:
        lines.append("## 🔍 Findings")
        lines.append("")

        for file_path in sorted(findings_by_file.keys()):
            findings = sorted(
                findings_by_file[file_path],
                key=lambda f: f.level.severity_rank,
            )

            lines.append(f"### `{file_path}`")
            lines.append("")

            for finding in findings:
                icon = LEVEL_ICONS[finding.level]
                line_ref = f"L{finding.line}" if finding.line else "—"

                lines.append(f"**{icon} {finding.level.value}** ({line_ref})")
                lines.append(f"> **{finding.issue}**")

                if finding.detail:
                    lines.append(f"> {finding.detail}")

                if finding.fix:
                    lines.append(f"> 💡 **Fix:** {finding.fix}")

                lines.append("")

    # ── Verdict ───────────────────────────────────────────────────────
    lines.append("---")
    lines.append("")
    lines.append("## ⚖️ Verdict")
    lines.append("")

    verdict_label = VERDICT_LABELS.get(result.verdict.value, "💬 COMMENT")
    lines.append(verdict_label)
    lines.append("")

    if result.verdict_reason:
        lines.append(result.verdict_reason)
        lines.append("")

    if result.must_fix:
        lines.append("**Must fix before merge:**")
        for item in result.must_fix:
            lines.append(f"- {item}")
        lines.append("")

    # ── Footer ────────────────────────────────────────────────────────
    lines.append("---")
    duration = format_duration(result.review_duration_seconds)
    analyzers = ", ".join(result.analyzers_used) if result.analyzers_used else "none"
    lines.append(f"*⏱ Reviewed in {duration} | Analyzers: {analyzers} | Powered by VibePR*")

    return "\n".join(lines)
