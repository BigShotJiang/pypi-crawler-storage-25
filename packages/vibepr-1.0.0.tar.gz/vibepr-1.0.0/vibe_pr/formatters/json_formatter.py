"""
JSON formatter for VibePR.
Machine-readable output for CI/CD integration.
"""

from __future__ import annotations

import json
from datetime import datetime

from vibe_pr.models import ReviewResult


def format_json(result: ReviewResult, indent: int = 2) -> str:
    """Render review results as JSON."""
    output = {
        "vibepr_version": "1.0.0",
        "reviewed_at": result.reviewed_at.isoformat() if result.reviewed_at else None,
        "review_duration_seconds": result.review_duration_seconds,
        "pr": {
            "title": result.pr_info.title,
            "description": result.pr_info.description,
            "author": result.pr_info.author,
            "url": result.pr_info.url,
            "number": result.pr_info.number,
            "repo": result.pr_info.repo_full_name,
            "base_branch": result.pr_info.base_branch,
            "head_branch": result.pr_info.head_branch,
            "is_draft": result.pr_info.is_draft,
            "files_changed": len(result.pr_info.files),
        },
        "summary": result.summary,
        "verdict": result.verdict.value,
        "verdict_reason": result.verdict_reason,
        "must_fix_before_merge": result.must_fix,
        "stats": result.stats,
        "findings": [
            {
                "file": f.file,
                "line": f.line,
                "line_end": f.line_end,
                "level": f.level.value,
                "issue": f.issue,
                "detail": f.detail,
                "fix": f.fix,
                "analyzer": f.analyzer,
                "confidence": f.confidence,
            }
            for f in result.findings
        ],
        "analyzers_used": result.analyzers_used,
    }

    return json.dumps(output, indent=indent, ensure_ascii=False)
