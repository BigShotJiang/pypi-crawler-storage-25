"""
Rich-powered terminal formatter for VibePR.
Beautiful, color-coded output with panels, tables, and grouped findings.
"""

from __future__ import annotations

from collections import defaultdict

from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from vibe_pr.models import FindingLevel, ReviewResult
from vibe_pr.utils import format_duration, get_file_icon


LEVEL_STYLES = {
    FindingLevel.BLOCKER:    ("🔴", "bold red",       "red"),
    FindingLevel.WARNING:    ("🟡", "bold yellow",    "yellow"),
    FindingLevel.SUGGESTION: ("🔵", "bold blue",      "blue"),
    FindingLevel.PRAISE:     ("🟢", "bold green",     "green"),
}

VERDICT_STYLES = {
    "APPROVE":         ("✅", "bold green",  "APPROVED — Ready to merge"),
    "REQUEST_CHANGES": ("❌", "bold red",    "CHANGES REQUESTED — Must fix before merge"),
    "COMMENT":         ("💬", "bold yellow", "COMMENT — Review findings attached"),
}


def format_terminal(result: ReviewResult, show_praise: bool = True) -> None:
    """Render review results to the terminal using Rich."""
    console = Console()

    # ── Header ────────────────────────────────────────────────────────
    _render_header(console, result)

    # ── Summary ───────────────────────────────────────────────────────
    if result.summary:
        console.print()
        console.print(Panel(
            escape(result.summary),
            title="[bold white]📋 Summary[/bold white]",
            border_style="dim cyan",
            padding=(1, 2),
        ))

    # ── Stats Table ───────────────────────────────────────────────────
    console.print()
    _render_stats(console, result)

    # ── Findings by File ──────────────────────────────────────────────
    findings_by_file = defaultdict(list)
    for finding in result.findings:
        if not show_praise and finding.level == FindingLevel.PRAISE:
            continue
        findings_by_file[finding.file].append(finding)

    if findings_by_file:
        console.print()
        console.print("[bold white]━━━ Findings ━━━[/bold white]")

        for file_path, findings in sorted(findings_by_file.items()):
            console.print()
            # Sort findings by severity
            findings.sort(key=lambda f: f.level.severity_rank)
            _render_file_findings(console, file_path, findings)

    # ── Verdict ───────────────────────────────────────────────────────
    console.print()
    _render_verdict(console, result)

    # ── Footer ────────────────────────────────────────────────────────
    console.print()
    duration = format_duration(result.review_duration_seconds)
    analyzers = ", ".join(result.analyzers_used) if result.analyzers_used else "none"
    console.print(
        f"[dim]⏱  Reviewed in {duration} | Analyzers: {analyzers}[/dim]"
    )
    console.print()


def _render_header(console: Console, result: ReviewResult) -> None:
    """Render the review header with PR info."""
    pr = result.pr_info

    header_lines = []
    if pr.title:
        header_lines.append(f"[bold white]{escape(pr.title)}[/bold white]")
    if pr.url and not pr.url.startswith("local://"):
        header_lines.append(f"[dim cyan]{pr.url}[/dim cyan]")
    if pr.author:
        header_lines.append(f"[dim]by {pr.author}[/dim]  [dim]•[/dim]  [dim]{pr.head_branch} → {pr.base_branch}[/dim]")

    header_text = "\n".join(header_lines)

    console.print()
    console.print(Panel(
        header_text,
        title="[bold magenta]⚡ VibePR Review[/bold magenta]",
        subtitle=f"[dim]{len(result.pr_info.files)} files changed[/dim]",
        border_style="magenta",
        padding=(1, 2),
    ))


def _render_stats(console: Console, result: ReviewResult) -> None:
    """Render the findings statistics table."""
    stats = result.stats
    table = Table(
        box=box.ROUNDED,
        border_style="dim",
        show_header=True,
        header_style="bold",
        padding=(0, 2),
    )

    table.add_column("🔴 Blockers", justify="center", style="red bold")
    table.add_column("🟡 Warnings", justify="center", style="yellow bold")
    table.add_column("🔵 Suggestions", justify="center", style="blue bold")
    table.add_column("🟢 Praises", justify="center", style="green bold")
    table.add_column("📁 Files", justify="center", style="white")

    table.add_row(
        str(stats["blockers"]),
        str(stats["warnings"]),
        str(stats["suggestions"]),
        str(stats["praises"]),
        str(stats["total_files"]),
    )

    console.print(table)


def _render_file_findings(
    console: Console, file_path: str, findings: list
) -> None:
    """Render findings for a single file."""
    from vibe_pr.utils import detect_language

    lang = detect_language(file_path)
    icon = get_file_icon(lang)

    console.print(f"  {icon} [bold white]{file_path}[/bold white]")
    console.print(f"  [dim]{'─' * (len(file_path) + 4)}[/dim]")

    for finding in findings:
        emoji, style, color = LEVEL_STYLES[finding.level]
        line_text = f"L{finding.line}" if finding.line else "—"

        console.print(f"    {emoji} [{style}]{finding.level.value}[/{style}] [dim]({line_text})[/dim]")
        console.print(f"      [bold]{escape(finding.issue)}[/bold]")

        if finding.detail:
            console.print(f"      [dim]{escape(finding.detail)}[/dim]")

        if finding.fix:
            console.print(f"      [green]↳ Fix: {escape(finding.fix)}[/green]")

        if finding.confidence < 0.7:
            console.print(f"      [dim italic]Confidence: {finding.confidence:.0%}[/dim italic]")

        console.print()


def _render_verdict(console: Console, result: ReviewResult) -> None:
    """Render the final verdict panel."""
    emoji, style, label = VERDICT_STYLES.get(
        result.verdict.value,
        ("💬", "bold yellow", "COMMENT"),
    )

    verdict_lines = [f"[{style}]{emoji} {label}[/{style}]"]

    if result.verdict_reason:
        verdict_lines.append(f"\n{escape(result.verdict_reason)}")

    if result.must_fix:
        verdict_lines.append("\n[bold red]Must fix before merge:[/bold red]")
        for item in result.must_fix:
            verdict_lines.append(f"  [red]• {escape(item)}[/red]")

    console.print(Panel(
        "\n".join(verdict_lines),
        title="[bold white]⚖️  Verdict[/bold white]",
        border_style=style.replace("bold ", ""),
        padding=(1, 2),
    ))
