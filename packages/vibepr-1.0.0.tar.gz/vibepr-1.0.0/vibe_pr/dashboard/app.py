"""
Flask web dashboard for VibePR.
"""

from __future__ import annotations

import json
from typing import Any

from flask import Flask, render_template, jsonify, request

from vibe_pr.storage import ReviewStorage


def create_app(config: dict[str, Any] | None = None) -> Flask:
    """Create and configure the Flask dashboard app."""
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    db_path = "~/.vibepr/reviews.db"
    if config:
        db_path = config.get("dashboard", {}).get("db_path", db_path)

    storage = ReviewStorage(db_path=db_path)

    @app.route("/")
    def index():
        """Dashboard home — list of reviews."""
        reviews = storage.get_reviews(limit=50)
        stats = storage.get_stats()
        return render_template("index.html", reviews=reviews, stats=stats)

    @app.route("/review/<int:review_id>")
    def review_detail(review_id: int):
        """Single review detail page."""
        review = storage.get_review(review_id)
        if not review:
            return "Review not found", 404
        return render_template("review.html", review=review)

    @app.route("/api/reviews")
    def api_reviews():
        """API endpoint for reviews."""
        limit = request.args.get("limit", 50, type=int)
        repo = request.args.get("repo")
        verdict = request.args.get("verdict")
        reviews = storage.get_reviews(limit=limit, repo=repo, verdict=verdict)
        return jsonify(reviews)

    @app.route("/api/stats")
    def api_stats():
        """API endpoint for aggregate stats."""
        return jsonify(storage.get_stats())

    @app.route("/api/review/<int:review_id>")
    def api_review(review_id: int):
        """API endpoint for a single review."""
        review = storage.get_review(review_id)
        if not review:
            return jsonify({"error": "Not found"}), 404
        return jsonify(review)

    return app
