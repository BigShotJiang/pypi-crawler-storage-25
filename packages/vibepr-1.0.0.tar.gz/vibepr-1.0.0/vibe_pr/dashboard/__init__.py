"""
VibePR Dashboard package.
"""
