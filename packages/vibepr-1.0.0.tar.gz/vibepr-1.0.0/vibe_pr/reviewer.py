"""
Core review orchestrator for VibePR.
Coordinates analyzers, LLM providers, and output formatting.
"""

from __future__ import annotations

import re
import time
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from vibe_pr.config import get_review_config, get_llm_config, get_github_token
from vibe_pr.models import (
    FileChange,
    Finding,
    FindingLevel,
    PRInfo,
    ReviewResult,
    Verdict,
)
from vibe_pr.utils import should_ignore_file

console = Console()


class Reviewer:
    """
    Central review orchestrator.
    Runs all enabled analyzers against PR files and produces a ReviewResult.
    """

    def __init__(self, config: dict):
        self.config = config
        self.review_config = get_review_config(config)
        self.llm_config = get_llm_config(config)
        self._analyzers = self._build_analyzers()
        self._llm_provider = self._build_llm_provider()

    def _build_analyzers(self) -> list:
        """Initialize enabled analyzers."""
        analyzers = []

        if self.review_config.get("security", True):
            from vibe_pr.analyzers.security import SecurityAnalyzer
            analyzers.append(SecurityAnalyzer())

        if self.review_config.get("logic", True):
            from vibe_pr.analyzers.logic import LogicAnalyzer
            analyzers.append(LogicAnalyzer())

        if self.review_config.get("performance", True):
            from vibe_pr.analyzers.performance import PerformanceAnalyzer
            analyzers.append(PerformanceAnalyzer())

        if self.review_config.get("maintainability", True):
            from vibe_pr.analyzers.maintainability import MaintainabilityAnalyzer
            analyzers.append(MaintainabilityAnalyzer())

        return analyzers

    def _build_llm_provider(self):
        """Initialize LLM provider if configured."""
        provider_name = self.llm_config.get("provider", "none")

        if provider_name == "none":
            return None

        api_key = self.llm_config.get("api_key", "")
        model = self.llm_config.get("model", "")

        if provider_name == "openai":
            from vibe_pr.llm.openai_provider import OpenAIProvider
            return OpenAIProvider(api_key=api_key, model=model or "gpt-4o")

        elif provider_name == "anthropic":
            from vibe_pr.llm.anthropic_provider import AnthropicProvider
            return AnthropicProvider(api_key=api_key, model=model or "claude-sonnet-4-20250514")

        return None

    def review(self, pr_info: PRInfo, deep: bool = False) -> ReviewResult:
        """
        Run a full review on a PR.

        Args:
            pr_info: PR metadata and file changes
            deep: If True, also run LLM-powered analysis

        Returns:
            Complete ReviewResult
        """
        start_time = time.time()
        all_findings: list[Finding] = []
        ignore_patterns = self.review_config.get("ignore_patterns", [])

        # Filter files
        files_to_review = [
            f for f in pr_info.files
            if not should_ignore_file(f.path, ignore_patterns)
        ]

        console.print(f"\n[bold cyan]⚡ VibePR[/bold cyan] reviewing {len(files_to_review)} files...")

        # ── Static Analysis ──────────────────────────────────────────
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console,
        ) as progress:
            task = progress.add_task(
                "[cyan]Running static analysis...",
                total=len(files_to_review) * len(self._analyzers),
            )

            for file_change in files_to_review:
                for analyzer in self._analyzers:
                    if analyzer.supports_language(file_change.language):
                        try:
                            findings = analyzer.analyze(file_change, pr_info)
                            all_findings.extend(findings)
                        except Exception as e:
                            console.print(
                                f"  [dim yellow]⚠ {analyzer.name} failed on {file_change.path}: {e}[/dim yellow]"
                            )
                    progress.advance(task)

        # ── LLM Deep Analysis ────────────────────────────────────────
        if deep and self._llm_provider:
            if self._llm_provider.is_available():
                console.print("[cyan]Running AI-powered deep analysis...[/cyan]")
                llm_findings = self._run_llm_analysis(pr_info, files_to_review)
                all_findings.extend(llm_findings)
            else:
                console.print(
                    "[yellow]⚠ LLM provider configured but API key not set. "
                    "Skipping deep analysis.[/yellow]"
                )

        # ── Filter by min level ──────────────────────────────────────
        min_level = self.review_config.get("min_level", "suggestion")
        all_findings = self._filter_by_level(all_findings, min_level)

        # ── Apply per-file limits ────────────────────────────────────
        max_per_file = self.review_config.get("max_findings_per_file", 0)
        if max_per_file > 0:
            all_findings = self._limit_per_file(all_findings, max_per_file)

        # ── Determine Verdict ────────────────────────────────────────
        verdict, verdict_reason, must_fix = self._determine_verdict(all_findings)

        # ── Generate Summary ─────────────────────────────────────────
        summary = self._generate_summary(pr_info, all_findings, deep)

        # ── Build Result ─────────────────────────────────────────────
        elapsed = time.time() - start_time
        analyzers_used = [a.name for a in self._analyzers]
        if deep and self._llm_provider:
            analyzers_used.append(f"llm:{self._llm_provider.name}")

        return ReviewResult(
            pr_info=pr_info,
            summary=summary,
            findings=all_findings,
            verdict=verdict,
            verdict_reason=verdict_reason,
            must_fix=must_fix,
            review_duration_seconds=elapsed,
            analyzers_used=analyzers_used,
        )

    def _run_llm_analysis(
        self, pr_info: PRInfo, files: list[FileChange]
    ) -> list[Finding]:
        """Run LLM-powered analysis on each file."""
        findings = []

        for file_change in files:
            if not file_change.patch:
                continue

            try:
                response = self._llm_provider.review_diff(
                    diff=file_change.patch,
                    file_path=file_change.path,
                    pr_description=pr_info.description,
                    language=file_change.language,
                )
                parsed = self._parse_llm_response(response, file_change.path)
                findings.extend(parsed)
            except Exception as e:
                console.print(f"  [dim yellow]⚠ LLM analysis failed for {file_change.path}: {e}[/dim yellow]")

        return findings

    @staticmethod
    def _parse_llm_response(response: str, file_path: str) -> list[Finding]:
        """Parse LLM response into Finding objects."""
        findings = []

        # Parse the structured output format
        blocks = re.split(r'\n(?=FILE:\s)', response)

        for block in blocks:
            if not block.strip():
                continue

            file_match = re.search(r'FILE:\s*(.+)', block)
            line_match = re.search(r'LINE:\s*(\d+)', block)
            level_match = re.search(r'LEVEL:\s*(BLOCKER|WARNING|SUGGESTION|PRAISE)', block)
            issue_match = re.search(r'ISSUE:\s*(.+)', block)
            detail_match = re.search(r'DETAIL:\s*(.+)', block)
            fix_match = re.search(r'FIX:\s*(.+)', block)

            if level_match and issue_match:
                findings.append(Finding(
                    file=file_match.group(1).strip() if file_match else file_path,
                    line=int(line_match.group(1)) if line_match else None,
                    level=FindingLevel(level_match.group(1)),
                    issue=issue_match.group(1).strip(),
                    detail=detail_match.group(1).strip() if detail_match else "",
                    fix=fix_match.group(1).strip() if fix_match else None,
                    analyzer="llm",
                    confidence=0.75,
                ))

        return findings

    @staticmethod
    def _filter_by_level(findings: list[Finding], min_level: str) -> list[Finding]:
        """Filter findings by minimum severity level."""
        level_order = {"blocker": 0, "warning": 1, "suggestion": 2, "praise": 3}
        min_rank = level_order.get(min_level.lower(), 2)

        return [f for f in findings if f.level.severity_rank <= min_rank]

    @staticmethod
    def _limit_per_file(findings: list[Finding], max_per_file: int) -> list[Finding]:
        """Limit findings per file, keeping highest severity."""
        from collections import defaultdict

        by_file: dict[str, list[Finding]] = defaultdict(list)
        for f in findings:
            by_file[f.file].append(f)

        result = []
        for file_path, file_findings in by_file.items():
            # Sort by severity (blockers first)
            file_findings.sort(key=lambda f: f.level.severity_rank)
            result.extend(file_findings[:max_per_file])

        return result

    def _determine_verdict(
        self, findings: list[Finding]
    ) -> tuple[Verdict, str, list[str]]:
        """Determine the overall review verdict."""
        blockers = [f for f in findings if f.level == FindingLevel.BLOCKER]
        warnings = [f for f in findings if f.level == FindingLevel.WARNING]

        must_fix = [f"{f.file}:{f.line or '?'} — {f.issue}" for f in blockers]

        if blockers:
            return (
                Verdict.REQUEST_CHANGES,
                f"{len(blockers)} blocking issue(s) found that must be resolved before merge.",
                must_fix,
            )

        if len(warnings) >= 3:
            return (
                Verdict.REQUEST_CHANGES,
                f"{len(warnings)} warnings found. While none are individually blocking, "
                "the accumulation suggests the code needs more attention.",
                [],
            )

        if warnings:
            return (
                Verdict.COMMENT,
                f"{len(warnings)} warning(s) found. Consider addressing these before merge.",
                [],
            )

        return (
            Verdict.APPROVE,
            "No blocking issues found. Code looks good.",
            [],
        )

    def _generate_summary(
        self, pr_info: PRInfo, findings: list[Finding], deep: bool
    ) -> str:
        """Generate a review summary."""
        # Try LLM summary if available
        if deep and self._llm_provider and self._llm_provider.is_available():
            try:
                file_summaries = [
                    f"{f.path} ({f.status}, +{f.additions}/-{f.deletions})"
                    for f in pr_info.files
                ]
                stats = {
                    "blockers": len([f for f in findings if f.level == FindingLevel.BLOCKER]),
                    "warnings": len([f for f in findings if f.level == FindingLevel.WARNING]),
                    "suggestions": len([f for f in findings if f.level == FindingLevel.SUGGESTION]),
                    "praises": len([f for f in findings if f.level == FindingLevel.PRAISE]),
                }
                return self._llm_provider.generate_summary(
                    pr_info.description, file_summaries, stats
                )
            except Exception:
                pass

        # Fallback: generate a basic summary
        return self._generate_basic_summary(pr_info, findings)

    @staticmethod
    def _generate_basic_summary(pr_info: PRInfo, findings: list[Finding]) -> str:
        """Generate a basic summary without LLM."""
        parts = []

        # PR description
        if pr_info.description:
            desc = pr_info.description.strip()
            if len(desc) > 200:
                desc = desc[:200] + "..."
            parts.append(f"This PR {desc.lower()}" if not desc[0].isupper() else desc.split("\n")[0])
        else:
            parts.append(f"This PR modifies {len(pr_info.files)} file(s).")

        # Stats
        total_additions = sum(f.additions for f in pr_info.files)
        total_deletions = sum(f.deletions for f in pr_info.files)
        parts.append(f"Changes span {len(pr_info.files)} files (+{total_additions}/-{total_deletions} lines).")

        # Findings summary
        blockers = len([f for f in findings if f.level == FindingLevel.BLOCKER])
        warnings = len([f for f in findings if f.level == FindingLevel.WARNING])

        if blockers:
            parts.append(f"⚠️ {blockers} blocking issue(s) must be resolved before merge.")
        elif warnings:
            parts.append(f"{warnings} warning(s) found — recommend addressing before merge.")
        else:
            parts.append("No significant issues found.")

        return " ".join(parts)
