"""
Core data models for VibePR.
All structured data flows through these Pydantic models.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class FindingLevel(str, enum.Enum):
    """Severity level of a review finding."""
    BLOCKER = "BLOCKER"
    WARNING = "WARNING"
    SUGGESTION = "SUGGESTION"
    PRAISE = "PRAISE"

    @property
    def severity_rank(self) -> int:
        return {
            FindingLevel.BLOCKER: 0,
            FindingLevel.WARNING: 1,
            FindingLevel.SUGGESTION: 2,
            FindingLevel.PRAISE: 3,
        }[self]

    def __lt__(self, other):
        if not isinstance(other, FindingLevel):
            return NotImplemented
        return self.severity_rank < other.severity_rank


class Verdict(str, enum.Enum):
    """Overall review verdict."""
    APPROVE = "APPROVE"
    REQUEST_CHANGES = "REQUEST_CHANGES"
    COMMENT = "COMMENT"


class Finding(BaseModel):
    """A single review finding."""
    file: str = Field(description="File path where the finding was identified")
    line: Optional[int] = Field(default=None, description="Line number (1-indexed)")
    line_end: Optional[int] = Field(default=None, description="End line for multi-line findings")
    level: FindingLevel = Field(description="Severity level")
    issue: str = Field(description="Short one-line issue description")
    detail: str = Field(description="Detailed explanation of why this matters")
    fix: Optional[str] = Field(default=None, description="Suggested fix or alternative")
    analyzer: str = Field(default="manual", description="Which analyzer produced this finding")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Confidence score 0-1")


class FileChange(BaseModel):
    """Represents a changed file in a PR or diff."""
    path: str = Field(description="File path relative to repo root")
    status: str = Field(default="modified", description="added, modified, removed, renamed")
    additions: int = Field(default=0)
    deletions: int = Field(default=0)
    patch: Optional[str] = Field(default=None, description="Unified diff patch text")
    content: Optional[str] = Field(default=None, description="Full file content (if available)")
    added_lines: list[tuple[int, str]] = Field(
        default_factory=list, description="List of (line_number, content) added"
    )
    removed_lines: list[tuple[int, str]] = Field(
        default_factory=list, description="List of (line_number, content) removed"
    )
    language: Optional[str] = Field(default=None, description="Detected programming language")


class PRInfo(BaseModel):
    """Pull request metadata."""
    title: str = Field(default="")
    description: str = Field(default="")
    author: str = Field(default="")
    base_branch: str = Field(default="main")
    head_branch: str = Field(default="")
    url: str = Field(default="")
    number: int = Field(default=0)
    repo_full_name: str = Field(default="")
    files: list[FileChange] = Field(default_factory=list)
    labels: list[str] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    is_draft: bool = False


class ReviewResult(BaseModel):
    """Complete review result."""
    pr_info: PRInfo = Field(description="PR metadata")
    summary: str = Field(default="", description="One-paragraph summary of the PR")
    findings: list[Finding] = Field(default_factory=list)
    verdict: Verdict = Field(default=Verdict.COMMENT)
    verdict_reason: str = Field(default="")
    must_fix: list[str] = Field(default_factory=list, description="Items that must be fixed")
    reviewed_at: datetime = Field(default_factory=datetime.now)
    review_duration_seconds: float = Field(default=0.0)
    analyzers_used: list[str] = Field(default_factory=list)

    @property
    def blockers(self) -> list[Finding]:
        return [f for f in self.findings if f.level == FindingLevel.BLOCKER]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.level == FindingLevel.WARNING]

    @property
    def suggestions(self) -> list[Finding]:
        return [f for f in self.findings if f.level == FindingLevel.SUGGESTION]

    @property
    def praises(self) -> list[Finding]:
        return [f for f in self.findings if f.level == FindingLevel.PRAISE]

    @property
    def stats(self) -> dict[str, int]:
        return {
            "blockers": len(self.blockers),
            "warnings": len(self.warnings),
            "suggestions": len(self.suggestions),
            "praises": len(self.praises),
            "total_files": len(self.pr_info.files),
            "total_findings": len(self.findings),
        }
