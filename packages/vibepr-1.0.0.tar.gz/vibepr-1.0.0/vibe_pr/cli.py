"""
CLI interface for VibePR.
The main entry point for the vibepr command.
"""

from __future__ import annotations

import sys
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from vibe_pr import __version__, __app_name__
from vibe_pr.config import load_config, get_github_token

console = Console()

BANNER = r"""
[bold magenta]
 ╦  ╦┬┌┐ ┌─┐╔═╗╦═╗
 ╚╗╔╝│├┴┐├┤ ╠═╝╠╦╝
  ╚╝ ┴└─┘└─┘╩  ╩╚═
[/bold magenta]
[dim]AI-Powered PR Review Agent  v{version}[/dim]
"""


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name=__app_name__)
@click.option("--config", "-c", type=click.Path(), default=None, help="Path to config file")
@click.pass_context
def main(ctx, config):
    """⚡ VibePR — AI-powered PR review agent.

    Reviews pull requests with the depth and care of a senior engineer.
    """
    ctx.ensure_object(dict)
    ctx.obj["config"] = load_config(config)

    if ctx.invoked_subcommand is None:
        console.print(BANNER.format(version=__version__))
        console.print("Run [bold cyan]vibepr --help[/bold cyan] for available commands.\n")


@main.command()
@click.argument("target", required=False)
@click.option("--local", "-l", is_flag=True, help="Review local git changes")
@click.option("--base", "-b", default=None, help="Base branch/ref for local diff (default: HEAD)")
@click.option("--staged", "-s", is_flag=True, help="Review only staged changes")
@click.option("--format", "-f", "output_format", type=click.Choice(["terminal", "json", "markdown"]), default=None, help="Output format")
@click.option("--deep", "-d", is_flag=True, help="Enable LLM-powered deep analysis")
@click.option("--post", "-p", is_flag=True, help="Post review as GitHub comment")
@click.option("--save/--no-save", default=True, help="Save review to history")
@click.pass_context
def review(ctx, target, local, base, staged, output_format, deep, post, save):
    """Review a PR or local changes.

    \b
    Examples:
      vibepr review https://github.com/owner/repo/pull/123
      vibepr review owner/repo#123
      vibepr review --local
      vibepr review --local --base main
      vibepr review --local --staged
      vibepr review <URL> --deep --format json
    """
    config = ctx.obj["config"]
    output_format = output_format or config.get("output", {}).get("format", "terminal")

    if not target and not local:
        console.print("[red]Error: Provide a PR URL/reference or use --local flag.[/red]")
        console.print("  vibepr review https://github.com/owner/repo/pull/123")
        console.print("  vibepr review --local")
        raise SystemExit(1)

    try:
        if local:
            _review_local(config, base, staged, output_format, deep, save)
        else:
            _review_remote(config, target, output_format, deep, post, save)
    except KeyboardInterrupt:
        console.print("\n[yellow]Review cancelled.[/yellow]")
        raise SystemExit(130)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        raise SystemExit(1)


def _review_local(config, base, staged, output_format, deep, save):
    """Review local git changes."""
    from vibe_pr.diff_parser import parse_local_diff
    from vibe_pr.reviewer import Reviewer

    console.print(BANNER.format(version=__version__))

    pr_info, files = parse_local_diff(
        repo_path=".",
        base_ref=base,
        staged_only=staged,
    )

    if not files:
        console.print("[yellow]No changes detected. Nothing to review.[/yellow]")
        return

    pr_info.files = files
    reviewer = Reviewer(config)
    result = reviewer.review(pr_info, deep=deep)

    _output_result(result, output_format, config)

    if save:
        _save_review(result, config)


def _review_remote(config, target, output_format, deep, post, save):
    """Review a GitHub PR."""
    from vibe_pr.github_client import GitHubClient
    from vibe_pr.reviewer import Reviewer

    console.print(BANNER.format(version=__version__))

    token = get_github_token(config)
    client = GitHubClient(token=token)

    try:
        console.print(f"[cyan]Fetching PR from GitHub...[/cyan]")
        pr_info = client.fetch_pr(target)

        if not pr_info.files:
            console.print("[yellow]PR has no file changes. Nothing to review.[/yellow]")
            return

        reviewer = Reviewer(config)
        result = reviewer.review(pr_info, deep=deep)

        _output_result(result, output_format, config)

        if save:
            _save_review(result, config)

        # Optionally post review to GitHub
        if post and token:
            _post_to_github(client, result, config)

    finally:
        client.close()


def _output_result(result, output_format, config):
    """Output the review result in the specified format."""
    show_praise = config.get("output", {}).get("show_praise", True)

    if output_format == "json":
        from vibe_pr.formatters.json_formatter import format_json
        click.echo(format_json(result))

    elif output_format == "markdown":
        from vibe_pr.formatters.markdown import format_markdown
        click.echo(format_markdown(result, show_praise=show_praise))

    else:
        from vibe_pr.formatters.terminal import format_terminal
        format_terminal(result, show_praise=show_praise)


def _save_review(result, config):
    """Save review to history database."""
    try:
        from vibe_pr.storage import ReviewStorage
        db_path = config.get("dashboard", {}).get("db_path", "~/.vibepr/reviews.db")
        storage = ReviewStorage(db_path=db_path)
        review_id = storage.save_review(result)
        console.print(f"[dim]💾 Review saved (ID: {review_id})[/dim]")
    except Exception as e:
        console.print(f"[dim yellow]⚠ Failed to save review: {e}[/dim yellow]")


def _post_to_github(client, result, config):
    """Post review as a GitHub comment."""
    from vibe_pr.formatters.markdown import format_markdown

    try:
        show_praise = config.get("output", {}).get("show_praise", True)
        body = format_markdown(result, show_praise=show_praise)
        event = "REQUEST_CHANGES" if result.verdict.value == "REQUEST_CHANGES" else "COMMENT"

        client.post_review_comment(
            repo_full_name=result.pr_info.repo_full_name,
            pr_number=result.pr_info.number,
            body=body,
            event=event,
        )
        console.print("[green]✅ Review posted to GitHub.[/green]")
    except Exception as e:
        console.print(f"[red]Failed to post review: {e}[/red]")


@main.command()
@click.option("--limit", "-n", default=20, help="Number of reviews to show")
@click.option("--repo", "-r", default=None, help="Filter by repo")
@click.option("--verdict", "-v", type=click.Choice(["APPROVE", "REQUEST_CHANGES", "COMMENT"]), default=None)
@click.pass_context
def history(ctx, limit, repo, verdict):
    """View review history."""
    config = ctx.obj["config"]

    from vibe_pr.storage import ReviewStorage

    db_path = config.get("dashboard", {}).get("db_path", "~/.vibepr/reviews.db")
    storage = ReviewStorage(db_path=db_path)
    reviews = storage.get_reviews(limit=limit, repo=repo, verdict=verdict)

    if not reviews:
        console.print("[yellow]No reviews found.[/yellow]")
        return

    table = Table(
        title="📜 Review History",
        box=box.ROUNDED,
        border_style="dim cyan",
        show_header=True,
        header_style="bold",
    )

    table.add_column("ID", style="dim", width=4)
    table.add_column("PR", style="cyan", max_width=40)
    table.add_column("Repo", style="magenta", max_width=25)
    table.add_column("Verdict", justify="center", width=10)
    table.add_column("🔴", justify="center", width=3)
    table.add_column("🟡", justify="center", width=3)
    table.add_column("🔵", justify="center", width=3)
    table.add_column("Date", style="dim", width=12)

    verdict_icons = {
        "APPROVE": "[green]✅[/green]",
        "REQUEST_CHANGES": "[red]❌[/red]",
        "COMMENT": "[yellow]💬[/yellow]",
    }

    for r in reviews:
        table.add_row(
            str(r["id"]),
            r.get("pr_title", "")[:40],
            r.get("repo", ""),
            verdict_icons.get(r.get("verdict", ""), ""),
            str(r.get("blockers", 0)),
            str(r.get("warnings", 0)),
            str(r.get("suggestions", 0)),
            r.get("reviewed_at", "")[:10],
        )

    console.print(table)

    # Show aggregate stats
    stats = storage.get_stats()
    if stats.get("total_reviews", 0) > 0:
        console.print()
        console.print(Panel(
            f"[bold]{stats['total_reviews']}[/bold] reviews across "
            f"[bold]{stats['repos_reviewed']}[/bold] repos | "
            f"[red]{stats['total_blockers']}[/red] blockers caught | "
            f"[yellow]{stats['total_warnings']}[/yellow] warnings | "
            f"Avg review: [cyan]{stats['avg_duration']:.1f}s[/cyan]",
            title="[bold white]📊 Aggregate Stats[/bold white]",
            border_style="dim",
        ))


@main.command()
@click.pass_context
def dashboard(ctx):
    """Launch the web dashboard."""
    config = ctx.obj["config"]

    host = config.get("dashboard", {}).get("host", "127.0.0.1")
    port = config.get("dashboard", {}).get("port", 8777)

    console.print(BANNER.format(version=__version__))
    console.print(f"[bold green]🌐 Starting VibePR Dashboard[/bold green]")
    console.print(f"[cyan]   http://{host}:{port}[/cyan]\n")

    try:
        from vibe_pr.dashboard.app import create_app

        app = create_app(config)
        app.run(host=host, port=port, debug=True)
    except ImportError:
        console.print("[red]Flask is required for the dashboard. Install with: pip install flask[/red]")
    except Exception as e:
        console.print(f"[red]Dashboard error: {e}[/red]")


@main.command(name="config")
@click.option("--show", is_flag=True, help="Show current configuration")
@click.pass_context
def config_cmd(ctx, show):
    """View or manage configuration."""
    config = ctx.obj["config"]

    if show or True:  # Default to show
        import yaml
        console.print(Panel(
            yaml.dump(config, default_flow_style=False, sort_keys=False),
            title="[bold white]⚙️  VibePR Configuration[/bold white]",
            border_style="dim cyan",
        ))

        # Check status
        token = get_github_token(config)
        llm = config.get("llm", {}).get("provider", "none")

        console.print()
        console.print(f"  GitHub Token:  {'[green]✅ Set[/green]' if token else '[red]❌ Not set[/red]'}")
        console.print(f"  LLM Provider:  {'[green]✅ ' + llm + '[/green]' if llm != 'none' else '[yellow]⚠ None (static analysis only)[/yellow]'}")
        console.print()


if __name__ == "__main__":
    main()
