"""
VibePR — AI-powered PR review agent.
Reviews pull requests with the depth, care, and directness of a senior engineer.
"""

__version__ = "1.0.0"
__app_name__ = "VibePR"
