"""
GitHub API client for VibePR.
Fetches PR metadata, files, and diffs using PyGithub.
"""

from __future__ import annotations

import re
import time
from typing import Optional

from rich.console import Console

from vibe_pr.models import FileChange, PRInfo
from vibe_pr.utils import detect_language, extract_github_pr_info

console = Console()


class GitHubClientError(Exception):
    """Raised when GitHub API interaction fails."""
    pass


class GitHubClient:
    """Client for interacting with the GitHub API."""

    def __init__(self, token: Optional[str] = None):
        self._token = token
        self._github = None

    @property
    def github(self):
        """Lazy-init the GitHub connection."""
        if self._github is None:
            try:
                from github import Github, Auth

                if self._token:
                    auth = Auth.Token(self._token)
                    self._github = Github(auth=auth)
                else:
                    self._github = Github()
            except ImportError:
                raise GitHubClientError(
                    "PyGithub is required. Install with: pip install PyGithub"
                )
        return self._github

    def fetch_pr(self, url_or_ref: str) -> PRInfo:
        """
        Fetch PR information from a GitHub URL.

        Args:
            url_or_ref: GitHub PR URL (e.g., https://github.com/owner/repo/pull/123)
                        or shorthand (e.g., owner/repo#123)

        Returns:
            PRInfo with metadata and file changes
        """
        owner, repo_name, pr_number = self._parse_pr_reference(url_or_ref)
        repo_full_name = f"{owner}/{repo_name}"

        try:
            repo = self.github.get_repo(repo_full_name)
            pr = repo.get_pull(pr_number)
        except Exception as e:
            raise GitHubClientError(f"Failed to fetch PR #{pr_number} from {repo_full_name}: {e}")

        # Fetch files with retry logic
        files = self._fetch_pr_files(pr)

        return PRInfo(
            title=pr.title or "",
            description=pr.body or "",
            author=pr.user.login if pr.user else "",
            base_branch=pr.base.ref if pr.base else "main",
            head_branch=pr.head.ref if pr.head else "",
            url=pr.html_url or url_or_ref,
            number=pr_number,
            repo_full_name=repo_full_name,
            files=files,
            labels=[label.name for label in pr.labels] if pr.labels else [],
            created_at=pr.created_at,
            is_draft=pr.draft if hasattr(pr, "draft") else False,
        )

    def _parse_pr_reference(self, ref: str) -> tuple[str, str, int]:
        """Parse a PR reference into (owner, repo, number)."""
        # Try URL format
        result = extract_github_pr_info(ref)
        if result:
            return result

        # Try shorthand: owner/repo#123
        match = re.match(r"([^/]+)/([^#]+)#(\d+)", ref)
        if match:
            return match.group(1), match.group(2), int(match.group(3))

        raise GitHubClientError(
            f"Invalid PR reference: {ref}\n"
            "Expected format: https://github.com/owner/repo/pull/123 or owner/repo#123"
        )

    def _fetch_pr_files(self, pr, max_retries: int = 3) -> list[FileChange]:
        """Fetch all files changed in a PR with retry logic."""
        files = []

        for attempt in range(max_retries):
            try:
                pr_files = pr.get_files()
                for f in pr_files:
                    language = detect_language(f.filename)
                    file_change = FileChange(
                        path=f.filename,
                        status=f.status or "modified",
                        additions=f.additions or 0,
                        deletions=f.deletions or 0,
                        patch=f.patch,
                        language=language,
                    )

                    # Parse patch into added/removed lines
                    if f.patch:
                        file_change.added_lines, file_change.removed_lines = (
                            self._parse_patch_lines(f.patch)
                        )

                    files.append(file_change)
                break
            except Exception as e:
                if attempt < max_retries - 1:
                    wait = 2 ** attempt
                    console.print(
                        f"[yellow]GitHub API rate limit/error, retrying in {wait}s...[/yellow]"
                    )
                    time.sleep(wait)
                else:
                    raise GitHubClientError(f"Failed to fetch PR files after {max_retries} attempts: {e}")

        return files

    @staticmethod
    def _parse_patch_lines(patch: str) -> tuple[list[tuple[int, str]], list[tuple[int, str]]]:
        """Parse unified diff patch into added and removed line lists."""
        added = []
        removed = []
        current_add_line = 0
        current_del_line = 0

        for line in patch.split("\n"):
            # Parse hunk header: @@ -start,count +start,count @@
            hunk_match = re.match(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
            if hunk_match:
                current_del_line = int(hunk_match.group(1))
                current_add_line = int(hunk_match.group(2))
                continue

            if line.startswith("+") and not line.startswith("+++"):
                added.append((current_add_line, line[1:]))
                current_add_line += 1
            elif line.startswith("-") and not line.startswith("---"):
                removed.append((current_del_line, line[1:]))
                current_del_line += 1
            else:
                current_add_line += 1
                current_del_line += 1

        return added, removed

    def post_review_comment(
        self,
        repo_full_name: str,
        pr_number: int,
        body: str,
        event: str = "COMMENT",
    ) -> None:
        """Post a review comment to a GitHub PR."""
        try:
            repo = self.github.get_repo(repo_full_name)
            pr = repo.get_pull(pr_number)
            pr.create_review(body=body, event=event)
        except Exception as e:
            raise GitHubClientError(f"Failed to post review comment: {e}")

    def close(self):
        """Close the GitHub connection."""
        if self._github:
            self._github.close()
            self._github = None
