"""
SQLite storage for VibePR review history.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

from vibe_pr.models import ReviewResult


class ReviewStorage:
    """SQLite-backed storage for review history."""

    def __init__(self, db_path: str = "~/.vibepr/reviews.db"):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        """Initialize the database schema."""
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pr_url TEXT,
                    pr_title TEXT,
                    pr_author TEXT,
                    repo TEXT,
                    pr_number INTEGER,
                    verdict TEXT,
                    summary TEXT,
                    blockers INTEGER DEFAULT 0,
                    warnings INTEGER DEFAULT 0,
                    suggestions INTEGER DEFAULT 0,
                    praises INTEGER DEFAULT 0,
                    total_files INTEGER DEFAULT 0,
                    review_data TEXT,
                    reviewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    duration_seconds REAL DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_reviews_repo ON reviews(repo)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_reviews_date ON reviews(reviewed_at)
            """)

    def save_review(self, result: ReviewResult) -> int:
        """Save a review result and return its ID."""
        stats = result.stats

        # Serialize the full result to JSON for retrieval
        review_json = json.dumps({
            "summary": result.summary,
            "verdict": result.verdict.value,
            "verdict_reason": result.verdict_reason,
            "must_fix": result.must_fix,
            "analyzers_used": result.analyzers_used,
            "findings": [
                {
                    "file": f.file,
                    "line": f.line,
                    "level": f.level.value,
                    "issue": f.issue,
                    "detail": f.detail,
                    "fix": f.fix,
                    "analyzer": f.analyzer,
                    "confidence": f.confidence,
                }
                for f in result.findings
            ],
        })

        with sqlite3.connect(str(self.db_path)) as conn:
            cursor = conn.execute(
                """
                INSERT INTO reviews (
                    pr_url, pr_title, pr_author, repo, pr_number,
                    verdict, summary, blockers, warnings, suggestions,
                    praises, total_files, review_data, reviewed_at, duration_seconds
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result.pr_info.url,
                    result.pr_info.title,
                    result.pr_info.author,
                    result.pr_info.repo_full_name,
                    result.pr_info.number,
                    result.verdict.value,
                    result.summary,
                    stats["blockers"],
                    stats["warnings"],
                    stats["suggestions"],
                    stats["praises"],
                    stats["total_files"],
                    review_json,
                    result.reviewed_at.isoformat() if result.reviewed_at else datetime.now().isoformat(),
                    result.review_duration_seconds,
                ),
            )
            return cursor.lastrowid

    def get_reviews(
        self,
        limit: int = 20,
        repo: Optional[str] = None,
        verdict: Optional[str] = None,
    ) -> list[dict]:
        """Get recent reviews with optional filters."""
        query = "SELECT id, pr_url, pr_title, pr_author, repo, pr_number, verdict, summary, blockers, warnings, suggestions, praises, total_files, reviewed_at, duration_seconds FROM reviews"
        conditions = []
        params = []

        if repo:
            conditions.append("repo = ?")
            params.append(repo)
        if verdict:
            conditions.append("verdict = ?")
            params.append(verdict)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY reviewed_at DESC LIMIT ?"
        params.append(limit)

        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, params).fetchall()

        return [dict(row) for row in rows]

    def get_review(self, review_id: int) -> Optional[dict]:
        """Get a single review by ID, including full data."""
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM reviews WHERE id = ?", (review_id,)
            ).fetchone()

        if row:
            result = dict(row)
            if result.get("review_data"):
                result["review_data"] = json.loads(result["review_data"])
            return result
        return None

    def get_stats(self) -> dict:
        """Get aggregate statistics across all reviews."""
        with sqlite3.connect(str(self.db_path)) as conn:
            row = conn.execute("""
                SELECT
                    COUNT(*) as total_reviews,
                    SUM(blockers) as total_blockers,
                    SUM(warnings) as total_warnings,
                    SUM(suggestions) as total_suggestions,
                    SUM(praises) as total_praises,
                    SUM(total_files) as total_files_reviewed,
                    AVG(duration_seconds) as avg_duration,
                    COUNT(DISTINCT repo) as repos_reviewed
                FROM reviews
            """).fetchone()

        if row:
            return {
                "total_reviews": row[0] or 0,
                "total_blockers": row[1] or 0,
                "total_warnings": row[2] or 0,
                "total_suggestions": row[3] or 0,
                "total_praises": row[4] or 0,
                "total_files_reviewed": row[5] or 0,
                "avg_duration": round(row[6] or 0, 2),
                "repos_reviewed": row[7] or 0,
            }
        return {}
