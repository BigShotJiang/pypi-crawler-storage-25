"""
Configuration management for VibePR.
Loads config from .vibepr.yml files and environment variables.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml


DEFAULT_CONFIG = {
    "github": {
        "token": "",
    },
    "llm": {
        "provider": "none",
        "api_key": "",
        "model": "gpt-4o",
        "max_tokens": 4096,
    },
    "review": {
        "security": True,
        "logic": True,
        "performance": True,
        "maintainability": True,
        "min_level": "suggestion",
        "max_findings_per_file": 0,
        "ignore_patterns": [
            "*.min.js",
            "*.min.css",
            "package-lock.json",
            "yarn.lock",
            "*.lock",
            "*.generated.*",
        ],
    },
    "output": {
        "format": "terminal",
        "show_praise": True,
        "color": True,
    },
    "dashboard": {
        "host": "127.0.0.1",
        "port": 8777,
        "db_path": "~/.vibepr/reviews.db",
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep merge override dict into base dict."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _find_config_file() -> Optional[Path]:
    """Search for .vibepr.yml in current dir, then parents, then home."""
    # Check current directory and parents
    current = Path.cwd()
    for parent in [current, *current.parents]:
        candidate = parent / ".vibepr.yml"
        if candidate.exists():
            return candidate

    # Check home directory
    home_config = Path.home() / ".vibepr.yml"
    if home_config.exists():
        return home_config

    return None


def load_config(config_path: Optional[str] = None) -> dict[str, Any]:
    """
    Load configuration with precedence:
    1. Default config
    2. Config file (.vibepr.yml)
    3. Environment variables
    """
    config = DEFAULT_CONFIG.copy()

    # Load from file
    if config_path:
        file_path = Path(config_path)
    else:
        file_path = _find_config_file()

    if file_path and file_path.exists():
        with open(file_path, "r") as f:
            file_config = yaml.safe_load(f) or {}
        config = _deep_merge(config, file_config)

    # Override with environment variables
    env_mappings = {
        "GITHUB_TOKEN": ("github", "token"),
        "VIBEPR_GITHUB_TOKEN": ("github", "token"),
        "OPENAI_API_KEY": ("llm", "api_key"),
        "ANTHROPIC_API_KEY": ("llm", "api_key"),
        "VIBEPR_LLM_PROVIDER": ("llm", "provider"),
        "VIBEPR_LLM_MODEL": ("llm", "model"),
        "VIBEPR_OUTPUT_FORMAT": ("output", "format"),
    }

    for env_var, (section, key) in env_mappings.items():
        value = os.environ.get(env_var)
        if value:
            if section not in config:
                config[section] = {}
            config[section][key] = value

    # Auto-detect LLM provider from API key if provider is "none" but key is set
    if config["llm"]["provider"] == "none" and config["llm"]["api_key"]:
        if os.environ.get("ANTHROPIC_API_KEY"):
            config["llm"]["provider"] = "anthropic"
        elif os.environ.get("OPENAI_API_KEY"):
            config["llm"]["provider"] = "openai"

    # Expand ~ in paths
    db_path = config["dashboard"]["db_path"]
    if isinstance(db_path, str) and "~" in db_path:
        config["dashboard"]["db_path"] = str(Path(db_path).expanduser())

    return config


def get_github_token(config: dict) -> Optional[str]:
    """Get GitHub token from config, falling back to env vars."""
    token = config.get("github", {}).get("token", "")
    if token:
        return token

    for env_var in ["GITHUB_TOKEN", "VIBEPR_GITHUB_TOKEN", "GH_TOKEN"]:
        token = os.environ.get(env_var, "")
        if token:
            return token

    return None


def get_llm_config(config: dict) -> dict:
    """Get LLM configuration section."""
    return config.get("llm", DEFAULT_CONFIG["llm"])


def get_review_config(config: dict) -> dict:
    """Get review configuration section."""
    return config.get("review", DEFAULT_CONFIG["review"])
