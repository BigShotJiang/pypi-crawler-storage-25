"""
Shared utilities for VibePR.
"""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Optional

# Language detection by file extension
LANGUAGE_MAP = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".java": "java",
    ".kt": "kotlin",
    ".go": "go",
    ".rs": "rust",
    ".rb": "ruby",
    ".php": "php",
    ".cs": "csharp",
    ".cpp": "cpp",
    ".c": "c",
    ".h": "c",
    ".hpp": "cpp",
    ".swift": "swift",
    ".scala": "scala",
    ".r": "r",
    ".R": "r",
    ".sql": "sql",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "zsh",
    ".ps1": "powershell",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".json": "json",
    ".xml": "xml",
    ".html": "html",
    ".css": "css",
    ".scss": "scss",
    ".md": "markdown",
    ".tf": "terraform",
    ".hcl": "hcl",
    ".dockerfile": "dockerfile",
    ".toml": "toml",
}


def detect_language(file_path: str) -> Optional[str]:
    """Detect programming language from file extension."""
    path = Path(file_path)

    # Check for Dockerfile (no extension)
    if path.name.lower() in ("dockerfile", "containerfile"):
        return "dockerfile"

    # Check for Makefile
    if path.name.lower() in ("makefile", "gnumakefile"):
        return "makefile"

    ext = path.suffix.lower()
    return LANGUAGE_MAP.get(ext)


def should_ignore_file(file_path: str, ignore_patterns: list[str]) -> bool:
    """Check if a file should be ignored based on glob patterns."""
    for pattern in ignore_patterns:
        if fnmatch.fnmatch(file_path, pattern):
            return True
        if fnmatch.fnmatch(Path(file_path).name, pattern):
            return True
    return False


def extract_github_pr_info(url: str) -> Optional[tuple[str, str, int]]:
    """
    Extract owner, repo, and PR number from a GitHub PR URL.
    Returns (owner, repo, pr_number) or None.
    """
    patterns = [
        r"github\.com/([^/]+)/([^/]+)/pull/(\d+)",
        r"github\.com/([^/]+)/([^/]+)/pulls/(\d+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1), match.group(2), int(match.group(3))
    return None


def truncate_text(text: str, max_length: int = 200, suffix: str = "...") -> str:
    """Truncate text to max length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


def count_lines(text: str) -> int:
    """Count lines in a text string."""
    if not text:
        return 0
    return len(text.splitlines())


def format_duration(seconds: float) -> str:
    """Format duration in seconds to human-readable string."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    else:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.0f}s"


def get_file_icon(language: Optional[str]) -> str:
    """Get an emoji icon for a programming language."""
    icons = {
        "python": "🐍",
        "javascript": "🟨",
        "typescript": "🔷",
        "java": "☕",
        "go": "🐹",
        "rust": "🦀",
        "ruby": "💎",
        "php": "🐘",
        "csharp": "🟪",
        "cpp": "⚡",
        "c": "⚡",
        "swift": "🍎",
        "kotlin": "🟣",
        "html": "🌐",
        "css": "🎨",
        "sql": "🗄️",
        "bash": "🐚",
        "yaml": "📄",
        "json": "📋",
        "markdown": "📝",
        "terraform": "🏗️",
        "dockerfile": "🐳",
    }
    return icons.get(language or "", "📄")
