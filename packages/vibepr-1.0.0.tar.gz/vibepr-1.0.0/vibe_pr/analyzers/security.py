"""
Security analyzer for VibePR.
Detects injection vulnerabilities, exposed secrets, unsafe functions, and auth gaps.
"""

from __future__ import annotations

import re

from vibe_pr.analyzers import BaseAnalyzer
from vibe_pr.models import FileChange, Finding, FindingLevel, PRInfo


class SecurityAnalyzer(BaseAnalyzer):
    """Detects security vulnerabilities in code changes."""

    name = "security"
    description = "Security vulnerability detection"

    # ── Hardcoded secret patterns ──────────────────────────────────────
    SECRET_PATTERNS = [
        (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID", 0.95),
        (r'(?:aws).{0,20}(?:secret|key).{0,10}[\"\'][0-9a-zA-Z/+]{40}[\"\']', "AWS Secret Key", 0.90),
        (r'sk_live_[0-9a-zA-Z]{24,}', "Stripe Secret Key", 0.95),
        (r'sk-[a-zA-Z0-9]{20,}', "OpenAI API Key", 0.85),
        (r'ghp_[a-zA-Z0-9]{36}', "GitHub Personal Access Token", 0.95),
        (r'gho_[a-zA-Z0-9]{36}', "GitHub OAuth Token", 0.95),
        (r'github_pat_[a-zA-Z0-9_]{22,}', "GitHub Fine-Grained PAT", 0.95),
        (r'xox[baprs]-[0-9a-zA-Z\-]{10,}', "Slack Token", 0.90),
        (r'(?:password|passwd|pwd)\s*[=:]\s*["\'][^"\']{4,}["\']', "Hardcoded Password", 0.80),
        (r'(?:api_key|apikey|api_secret)\s*[=:]\s*["\'][^"\']{8,}["\']', "Hardcoded API Key", 0.75),
        (r'(?:private_key|privatekey)\s*[=:]\s*["\'][^"\']{10,}["\']', "Hardcoded Private Key", 0.85),
        (r'-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----', "Embedded Private Key", 0.95),
        (r'(?:mongodb|postgres|mysql|redis)://[^"\'\s]{10,}', "Database Connection String", 0.85),
    ]

    # ── Unsafe function patterns ───────────────────────────────────────
    UNSAFE_FUNCTION_PATTERNS = {
        "python": [
            (r'\beval\s*\(', "eval()", "eval() executes arbitrary code. Use ast.literal_eval() for safe parsing, or find an alternative approach."),
            (r'\bexec\s*\(', "exec()", "exec() executes arbitrary code strings. This is almost always avoidable."),
            (r'\bos\.system\s*\(', "os.system()", "os.system() is vulnerable to command injection. Use subprocess.run() with a list of args instead."),
            (r'subprocess\.\w+\(.*shell\s*=\s*True', "subprocess with shell=True", "shell=True enables shell injection. Use a list of args instead."),
            (r'\bpickle\.loads?\s*\(', "pickle.load()", "pickle can execute arbitrary code during deserialization. Never unpickle untrusted data."),
            (r'yaml\.load\s*\([^)]*\)(?!.*Loader)', "yaml.load() without SafeLoader", "yaml.load() without SafeLoader can execute arbitrary Python. Use yaml.safe_load() instead."),
            (r'\b__import__\s*\(', "__import__()", "Dynamic imports can load arbitrary modules. Use importlib with validation."),
            (r'marshal\.loads?\s*\(', "marshal.load()", "marshal can execute arbitrary code. Never unmarshal untrusted data."),
        ],
        "javascript": [
            (r'\beval\s*\(', "eval()", "eval() executes arbitrary JavaScript. Use JSON.parse() for data, or find an alternative."),
            (r'new\s+Function\s*\(', "new Function()", "Function constructor executes arbitrary code, similar to eval()."),
            (r'innerHTML\s*=', "innerHTML assignment", "innerHTML can execute scripts via XSS. Use textContent or a sanitization library like DOMPurify."),
            (r'document\.write\s*\(', "document.write()", "document.write() can inject arbitrary HTML. Use DOM APIs instead."),
            (r'\.html\s*\(', "jQuery .html()", "jQuery .html() can execute scripts. Use .text() for user content."),
        ],
        "typescript": [],  # Will inherit javascript patterns
    }

    # ── SQL injection patterns ─────────────────────────────────────────
    SQL_INJECTION_PATTERNS = [
        (r'(?:execute|query|raw)\s*\(\s*[f"\'].*(?:\{|\%s|\%d|\+\s*\w)', "SQL string interpolation/concatenation detected"),
        (r'f["\'](?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER)\s+.*\{', "f-string SQL query — vulnerable to injection"),
        (r'["\'](?:SELECT|INSERT|UPDATE|DELETE).*["\']\s*\+\s*\w+', "SQL query built with string concatenation"),
        (r'\.format\(.*\).*(?:SELECT|INSERT|UPDATE|DELETE)', "SQL query using .format() — vulnerable to injection"),
        (r'%\s*\(.*\).*(?:SELECT|INSERT|UPDATE|DELETE)', "SQL query using % formatting — vulnerable to injection"),
    ]

    # ── Path traversal patterns ────────────────────────────────────────
    PATH_TRAVERSAL_PATTERNS = [
        (r'open\s*\(.*(?:request|input|param|arg|user)', "File open with user-controlled path"),
        (r'os\.path\.join\s*\(.*(?:request|input|param|arg|user)', "Path join with user-controlled input"),
        (r'send_file\s*\(.*(?:request|input|param)', "send_file with user-controlled path"),
        (r'\.\./', "Path traversal sequence in code"),
    ]

    def analyze(self, file_change: FileChange, context: PRInfo) -> list[Finding]:
        findings: list[Finding] = []

        if not file_change.added_lines:
            return findings

        lang = file_change.language or ""

        for line_no, line_content in file_change.added_lines:
            stripped = line_content.strip()

            # Skip comments
            if self._is_comment(stripped, lang):
                continue

            # Check secrets
            findings.extend(self._check_secrets(file_change.path, line_no, stripped))

            # Check unsafe functions
            findings.extend(self._check_unsafe_functions(file_change.path, line_no, stripped, lang))

            # Check SQL injection
            findings.extend(self._check_sql_injection(file_change.path, line_no, stripped))

            # Check path traversal
            findings.extend(self._check_path_traversal(file_change.path, line_no, stripped))

        return findings

    def _check_secrets(self, file_path: str, line_no: int, line: str) -> list[Finding]:
        findings = []
        for pattern, name, confidence in self.SECRET_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.BLOCKER,
                    issue=f"Potential {name} detected",
                    detail=(
                        f"A pattern matching {name} was found in the code. "
                        "Hardcoded credentials in source code can be extracted by anyone with repo access "
                        "and are extremely difficult to rotate once committed."
                    ),
                    fix=(
                        "Move secrets to environment variables or a secrets manager. "
                        "Use .env files (excluded via .gitignore) for local development. "
                        "If this secret was already pushed, rotate it immediately."
                    ),
                    confidence=confidence,
                ))
        return findings

    def _check_unsafe_functions(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        findings = []

        # Get patterns for the language
        patterns = self.UNSAFE_FUNCTION_PATTERNS.get(lang, [])
        if lang == "typescript":
            patterns = patterns + self.UNSAFE_FUNCTION_PATTERNS.get("javascript", [])

        for pattern, func_name, detail in patterns:
            if re.search(pattern, line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.BLOCKER,
                    issue=f"Unsafe function: {func_name}",
                    detail=detail,
                    fix=f"Replace {func_name} with a safer alternative. See detail for suggestions.",
                    confidence=0.85,
                ))
        return findings

    def _check_sql_injection(self, file_path: str, line_no: int, line: str) -> list[Finding]:
        findings = []
        for pattern, description in self.SQL_INJECTION_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.BLOCKER,
                    issue="Potential SQL injection vulnerability",
                    detail=(
                        f"{description}. SQL injection allows attackers to read, modify, or delete "
                        "database contents and potentially execute system commands."
                    ),
                    fix=(
                        "Use parameterized queries (prepared statements) instead of string "
                        "interpolation. Example: cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))"
                    ),
                    confidence=0.80,
                ))
        return findings

    def _check_path_traversal(self, file_path: str, line_no: int, line: str) -> list[Finding]:
        findings = []
        for pattern, description in self.PATH_TRAVERSAL_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                # Skip test files for path traversal (common in test fixtures)
                if "test" in file_path.lower():
                    continue
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="Potential path traversal vulnerability",
                    detail=(
                        f"{description}. Path traversal can allow attackers to read or write "
                        "arbitrary files on the server."
                    ),
                    fix=(
                        "Validate and sanitize file paths. Use os.path.realpath() and verify "
                        "the resolved path is within the expected directory."
                    ),
                    confidence=0.65,
                ))
        return findings

    @staticmethod
    def _is_comment(line: str, lang: str) -> bool:
        """Check if a line is a comment."""
        if lang in ("python", "ruby", "bash", "yaml"):
            return line.startswith("#")
        elif lang in ("javascript", "typescript", "java", "go", "rust", "csharp", "cpp", "c"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False
