"""
Logic analyzer for VibePR.
Detects logic errors, edge case gaps, error handling issues, and async bugs.
"""

from __future__ import annotations

import re

from vibe_pr.analyzers import BaseAnalyzer
from vibe_pr.models import FileChange, Finding, FindingLevel, PRInfo


class LogicAnalyzer(BaseAnalyzer):
    """Detects logic and correctness issues in code changes."""

    name = "logic"
    description = "Logic and correctness analysis"

    def analyze(self, file_change: FileChange, context: PRInfo) -> list[Finding]:
        findings: list[Finding] = []

        if not file_change.added_lines:
            return findings

        lang = file_change.language or ""
        all_added = [(ln, c) for ln, c in file_change.added_lines]
        all_added_text = "\n".join(c for _, c in all_added)

        for line_no, line_content in file_change.added_lines:
            stripped = line_content.strip()

            # Skip empty lines and comments
            if not stripped or self._is_comment(stripped, lang):
                continue

            findings.extend(self._check_error_handling(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_edge_cases(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_comparisons(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_async_issues(file_change.path, line_no, stripped, lang))

        # Multi-line analysis
        findings.extend(self._check_broad_exception_patterns(file_change.path, all_added, lang))

        return findings

    def _check_error_handling(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        findings = []

        # Python: bare except
        if lang == "python":
            if re.match(r'^except\s*:', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="Bare except clause catches all exceptions including SystemExit and KeyboardInterrupt",
                    detail=(
                        "A bare 'except:' will catch every exception, including ones that should "
                        "propagate (SystemExit, KeyboardInterrupt, GeneratorExit). This makes "
                        "debugging extremely difficult because errors are silently swallowed."
                    ),
                    fix="Use 'except Exception:' to catch all application errors, or better yet, catch specific exception types.",
                    confidence=0.95,
                ))

            # Python: except pass
            if re.match(r'^except.*:\s*$', line):
                # Peek-ahead would be ideal but we check the pattern
                pass

            # Python: catching too broad
            if re.match(r'^except\s+Exception\s+as\s+\w+\s*:\s*$', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="Broad exception handler — consider catching specific exceptions",
                    detail=(
                        "Catching 'Exception' is better than bare except, but catching specific "
                        "exception types makes error handling more precise and self-documenting."
                    ),
                    fix="Identify the specific exceptions that can be raised and catch those instead.",
                    confidence=0.50,
                ))

        # JavaScript/TypeScript: empty catch
        if lang in ("javascript", "typescript"):
            if re.search(r'catch\s*\(\s*\w*\s*\)\s*\{\s*\}', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="Empty catch block silently swallows errors",
                    detail=(
                        "An empty catch block will hide any errors, making bugs nearly impossible "
                        "to diagnose in production. At minimum, log the error."
                    ),
                    fix="Add error logging: catch(err) { console.error('Context:', err); }",
                    confidence=0.90,
                ))

        return findings

    def _check_edge_cases(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        findings = []

        # Division without zero-check
        if re.search(r'/\s*(?!/)(?!\*)(\w+)', line) and not re.search(r'(?:https?://|//|/\*)', line):
            divisor_match = re.search(r'/\s*(\w+)(?:\s*[;\)\],])', line)
            if divisor_match:
                var = divisor_match.group(1)
                if var not in ("2", "10", "100", "1000", "60", "24", "3600", "1024", "255"):
                    # Only flag if denominator is a variable
                    if not var.isdigit() and var not in ("True", "False", "true", "false", "None", "null"):
                        findings.append(self._make_finding(
                            file=file_path,
                            line=line_no,
                            level=FindingLevel.SUGGESTION,
                            issue=f"Division by variable '{var}' — is zero possible?",
                            detail=f"If '{var}' can be zero, this will raise a ZeroDivisionError (Python) or yield Infinity/NaN (JS).",
                            fix=f"Add a zero-check: 'if {var} != 0' or provide a default value.",
                            confidence=0.40,
                        ))

        # Array/list index without bounds check
        if lang == "python":
            if re.search(r'\w+\[\s*-1\s*\]', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="Index [-1] on potentially empty sequence",
                    detail="If the list/string is empty, index [-1] will raise an IndexError.",
                    fix="Check 'if my_list:' before accessing my_list[-1], or use a try/except.",
                    confidence=0.40,
                ))

        return findings

    def _check_comparisons(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        findings = []

        # Python: == None instead of is None
        if lang == "python":
            if re.search(r'==\s*None\b', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="Use 'is None' instead of '== None'",
                    detail="PEP 8 recommends 'is None' / 'is not None' for singleton comparisons. '==' can be overridden by __eq__.",
                    fix="Replace '== None' with 'is None' and '!= None' with 'is not None'.",
                    confidence=0.90,
                ))

            if re.search(r'!=\s*None\b', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="Use 'is not None' instead of '!= None'",
                    detail="PEP 8 recommends 'is not None' for singleton comparisons.",
                    fix="Replace '!= None' with 'is not None'.",
                    confidence=0.90,
                ))

        # JavaScript: == instead of ===
        if lang in ("javascript", "typescript"):
            if re.search(r'[^!=]==[^=]', line) and not re.search(r'===', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="Use === instead of == to avoid type coercion",
                    detail="== performs type coercion which leads to surprising results (e.g., '' == false is true).",
                    fix="Replace == with === and != with !==.",
                    confidence=0.80,
                ))

        return findings

    def _check_async_issues(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        findings = []

        # Python: missing await
        if lang == "python":
            if re.search(r'(?<!await\s)\b\w+\.(?:fetch|send|read|write|execute|commit|close|connect)\s*\(', line):
                if "async" in line or "await" in line:
                    pass  # Already has await context
                # Low confidence — context-dependent
                # We only flag obvious patterns

        # JavaScript: floating promise
        if lang in ("javascript", "typescript"):
            if re.search(r'^\s*\w+\.\w+\(.*\)\s*;?\s*$', line):
                if re.search(r'(?:fetch|axios|request|query|save|delete|update|create)\s*\(', line):
                    if "await" not in line and ".then" not in line and ".catch" not in line:
                        findings.append(self._make_finding(
                            file=file_path,
                            line=line_no,
                            level=FindingLevel.WARNING,
                            issue="Potential floating Promise — async operation without await or .then()",
                            detail=(
                                "Calling an async function without 'await', '.then()', or '.catch()' means "
                                "errors will be silently lost and execution order may be non-deterministic."
                            ),
                            fix="Add 'await' before the call, or chain .then()/.catch() to handle the promise.",
                            confidence=0.55,
                        ))

        return findings

    def _check_broad_exception_patterns(
        self, file_path: str, lines: list[tuple[int, str]], lang: str
    ) -> list[Finding]:
        """Multi-line analysis for exception patterns."""
        findings = []

        if lang != "python":
            return findings

        # Detect except + pass (swallowed exceptions)
        for i, (line_no, line) in enumerate(lines):
            stripped = line.strip()
            if re.match(r'^except\b', stripped):
                # Check if next non-blank added line is just 'pass'
                for j in range(i + 1, min(i + 3, len(lines))):
                    next_line = lines[j][1].strip()
                    if not next_line:
                        continue
                    if next_line == "pass":
                        findings.append(self._make_finding(
                            file=file_path,
                            line=line_no,
                            level=FindingLevel.WARNING,
                            issue="Exception caught and silently ignored with 'pass'",
                            detail=(
                                "Catching an exception and doing nothing hides bugs. If this truly "
                                "should be ignored, add a comment explaining why."
                            ),
                            fix="At minimum, log the exception: logging.exception('Explanation of why this is acceptable')",
                            confidence=0.85,
                        ))
                    break

        return findings

    @staticmethod
    def _is_comment(line: str, lang: str) -> bool:
        if lang in ("python", "ruby", "bash", "yaml"):
            return line.startswith("#")
        elif lang in ("javascript", "typescript", "java", "go", "rust", "csharp", "cpp", "c"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False
