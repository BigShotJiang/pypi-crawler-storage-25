"""
Base analyzer interface for VibePR.
All analyzers inherit from this abstract class.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from vibe_pr.models import FileChange, Finding, PRInfo


class BaseAnalyzer(ABC):
    """Abstract base class for all code analyzers."""

    name: str = "base"
    description: str = "Base analyzer"

    @abstractmethod
    def analyze(self, file_change: FileChange, context: PRInfo) -> list[Finding]:
        """
        Analyze a single file change and return findings.

        Args:
            file_change: The file change to analyze
            context: PR context information

        Returns:
            List of findings discovered during analysis
        """
        ...

    def supports_language(self, language: str | None) -> bool:
        """Check if this analyzer supports the given language. Override to restrict."""
        return True

    def _make_finding(self, **kwargs) -> Finding:
        """Helper to create a Finding with this analyzer's name."""
        kwargs.setdefault("analyzer", self.name)
        return Finding(**kwargs)
