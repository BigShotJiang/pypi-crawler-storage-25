"""
Maintainability analyzer for VibePR.
Detects code quality issues: complexity, magic values, naming, documentation gaps.
"""

from __future__ import annotations

import re

from vibe_pr.analyzers import BaseAnalyzer
from vibe_pr.models import FileChange, Finding, FindingLevel, PRInfo


class MaintainabilityAnalyzer(BaseAnalyzer):
    """Detects maintainability and code quality issues."""

    name = "maintainability"
    description = "Code quality and maintainability analysis"

    # Common magic numbers that are acceptable
    ACCEPTABLE_NUMBERS = {
        "0", "1", "2", "-1", "0.0", "1.0", "0.5",
        "100", "1000", "60", "24", "3600", "1024",
        "200", "201", "204", "301", "302", "400", "401", "403", "404", "500",  # HTTP status
        "255", "256", "512", "8", "16", "32", "64", "128",  # Powers of 2
        "True", "False", "true", "false", "None", "null", "undefined",
    }

    def analyze(self, file_change: FileChange, context: PRInfo) -> list[Finding]:
        findings: list[Finding] = []

        if not file_change.added_lines:
            return findings

        lang = file_change.language or ""
        all_added = [(ln, c) for ln, c in file_change.added_lines]

        for line_no, line_content in file_change.added_lines:
            stripped = line_content.strip()
            if not stripped or self._is_comment(stripped, lang):
                continue

            findings.extend(self._check_magic_values(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_nesting(file_change.path, line_no, line_content, lang))
            findings.extend(self._check_todo_fixme(file_change.path, line_no, stripped))

        # Multi-line analysis
        findings.extend(self._check_function_length(file_change.path, all_added, lang))
        findings.extend(self._check_missing_docstrings(file_change.path, all_added, lang))
        findings.extend(self._check_praise_patterns(file_change.path, all_added, lang))

        return findings

    def _check_magic_values(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        """Detect magic numbers and strings."""
        findings = []

        # Skip certain file types where literals are expected
        if file_path.endswith((".json", ".yml", ".yaml", ".toml", ".env", ".cfg", ".ini")):
            return findings

        # Magic numbers (not in assignments to constants)
        number_pattern = r'(?<![A-Z_a-z\d.])(\d{3,})(?![A-Z_a-z\d.])'
        for match in re.finditer(number_pattern, line):
            number = match.group(1)
            if number not in self.ACCEPTABLE_NUMBERS:
                # Skip if it looks like a constant definition
                if re.match(r'^[A-Z_]+\s*=', line):
                    continue
                # Skip if in a comment
                if self._is_comment(line, lang):
                    continue
                # Skip index access like [0]
                if f'[{number}]' in line:
                    continue
                # Skip range/enumerate
                if re.search(r'(?:range|enumerate)\s*\(', line):
                    continue

                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue=f"Magic number {number} — consider using a named constant",
                    detail=(
                        "Unnamed numeric literals make code harder to understand and maintain. "
                        "A named constant documents the intent and makes future changes safer."
                    ),
                    fix=f"Define a named constant: MY_CONSTANT = {number}",
                    confidence=0.45,
                ))

        return findings

    def _check_nesting(
        self, file_path: str, line_no: int, raw_line: str, lang: str
    ) -> list[Finding]:
        """Detect deeply nested code."""
        findings = []

        # Count indentation level
        if lang == "python":
            indent = len(raw_line) - len(raw_line.lstrip())
            spaces_per_level = 4
            depth = indent // spaces_per_level

            if depth >= 5:
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue=f"Deeply nested code (depth {depth}) — hard to read and maintain",
                    detail=(
                        "Code nested more than 3-4 levels deep is difficult to follow. "
                        "Each level of nesting multiplies the mental load required to understand the code."
                    ),
                    fix=(
                        "Flatten using early returns (guard clauses), extract helper functions, "
                        "or restructure the logic. The 'Extract Method' refactoring is usually the best first step."
                    ),
                    confidence=0.75,
                ))
        elif lang in ("javascript", "typescript", "java", "csharp"):
            # Count curly brace depth (rough heuristic)
            indent = len(raw_line) - len(raw_line.lstrip())
            if indent >= 20:  # ~5 levels with 4-space indent
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="Deeply nested code — consider flattening",
                    detail="Excessive nesting hurts readability. Use early returns or extract to helper functions.",
                    fix="Apply guard clause pattern or extract inner blocks to separate functions.",
                    confidence=0.60,
                ))

        return findings

    def _check_todo_fixme(self, file_path: str, line_no: int, line: str) -> list[Finding]:
        """Flag TODO/FIXME/HACK in new code."""
        findings = []

        match = re.search(r'\b(TODO|FIXME|HACK|XXX|WORKAROUND)\b', line, re.IGNORECASE)
        if match:
            tag = match.group(1).upper()
            level = FindingLevel.WARNING if tag in ("FIXME", "HACK", "XXX") else FindingLevel.SUGGESTION

            findings.append(self._make_finding(
                file=file_path,
                line=line_no,
                level=level,
                issue=f"{tag} comment in new code — should this be resolved before merge?",
                detail=(
                    f"A {tag} comment was added in new code. If this represents known technical debt, "
                    "consider creating a ticket to track it rather than leaving it as a comment."
                ),
                fix=f"Resolve the {tag} item now, or create a tracking ticket and reference it in the comment.",
                confidence=0.60,
            ))

        return findings

    def _check_function_length(
        self, file_path: str, lines: list[tuple[int, str]], lang: str
    ) -> list[Finding]:
        """Detect overly long functions."""
        findings = []

        if lang == "python":
            func_start = None
            func_name = ""
            func_lines = 0

            for line_no, line in lines:
                stripped = line.strip()

                # Detect function definitions
                match = re.match(r'^(?:async\s+)?def\s+(\w+)\s*\(', stripped)
                if match:
                    # Check previous function
                    if func_start and func_lines > 50:
                        findings.append(self._make_finding(
                            file=file_path,
                            line=func_start,
                            level=FindingLevel.SUGGESTION,
                            issue=f"Function '{func_name}' is {func_lines} lines long — consider splitting",
                            detail=(
                                "Functions longer than ~50 lines are harder to understand, test, and maintain. "
                                "Long functions often do more than one thing."
                            ),
                            fix="Extract logical sections into smaller, well-named helper functions.",
                            confidence=0.55,
                        ))

                    func_start = line_no
                    func_name = match.group(1)
                    func_lines = 0

                if func_start:
                    func_lines += 1

            # Check the last function
            if func_start and func_lines > 50:
                findings.append(self._make_finding(
                    file=file_path,
                    line=func_start,
                    level=FindingLevel.SUGGESTION,
                    issue=f"Function '{func_name}' is {func_lines} lines long — consider splitting",
                    detail="Functions longer than ~50 lines are harder to understand, test, and maintain.",
                    fix="Extract logical sections into smaller, well-named helper functions.",
                    confidence=0.55,
                ))

        return findings

    def _check_missing_docstrings(
        self, file_path: str, lines: list[tuple[int, str]], lang: str
    ) -> list[Finding]:
        """Check for missing docstrings on public functions."""
        findings = []

        if lang != "python":
            return findings

        for i, (line_no, line) in enumerate(lines):
            stripped = line.strip()

            # Public function/class definition
            match = re.match(r'^(?:async\s+)?(?:def|class)\s+([a-zA-Z]\w*)\s*[\(:]', stripped)
            if match and not match.group(1).startswith("_"):
                # Check if next non-empty line is a docstring
                has_docstring = False
                for j in range(i + 1, min(i + 4, len(lines))):
                    next_line = lines[j][1].strip()
                    if not next_line:
                        continue
                    if next_line.startswith(('"""', "'''", '"', "'")):
                        has_docstring = True
                    break

                if not has_docstring:
                    findings.append(self._make_finding(
                        file=file_path,
                        line=line_no,
                        level=FindingLevel.SUGGESTION,
                        issue=f"Public {'class' if 'class' in stripped else 'function'} '{match.group(1)}' missing docstring",
                        detail="Public APIs should have docstrings documenting purpose, parameters, and return values.",
                        fix=f'Add a docstring: def {match.group(1)}(...):\n    """Brief description."""',
                        confidence=0.60,
                    ))

        return findings

    def _check_praise_patterns(
        self, file_path: str, lines: list[tuple[int, str]], lang: str
    ) -> list[Finding]:
        """Identify praiseworthy patterns in the code."""
        findings = []
        all_text = "\n".join(c for _, c in lines)

        # Praise: good use of type hints
        if lang == "python":
            type_hint_count = sum(1 for _, l in lines if re.search(r'->\s*\w+|:\s*\w+\s*=', l.strip()))
            if type_hint_count >= 3:
                findings.append(self._make_finding(
                    file=file_path,
                    line=lines[0][0] if lines else 0,
                    level=FindingLevel.PRAISE,
                    issue="Good use of type hints throughout",
                    detail="Type annotations improve code clarity, enable better IDE support, and catch bugs early with mypy/pyright.",
                    confidence=0.70,
                ))

        # Praise: comprehensive error handling
        error_handling_count = sum(
            1 for _, l in lines
            if re.search(r'(?:try:|except |raise |\.catch\(|\.then\()', l.strip())
        )
        if error_handling_count >= 3:
            findings.append(self._make_finding(
                file=file_path,
                line=lines[0][0] if lines else 0,
                level=FindingLevel.PRAISE,
                issue="Thorough error handling with multiple error paths covered",
                detail="Comprehensive error handling makes the code more robust and easier to debug in production.",
                confidence=0.60,
            ))

        # Praise: good test coverage patterns
        if "test" in file_path.lower():
            test_count = sum(1 for _, l in lines if re.match(r'\s*(?:def test_|it\(|describe\(|test\()', l.strip()))
            if test_count >= 5:
                findings.append(self._make_finding(
                    file=file_path,
                    line=lines[0][0] if lines else 0,
                    level=FindingLevel.PRAISE,
                    issue=f"Solid test coverage with {test_count} test cases",
                    detail="Good test coverage reduces regression risk and documents expected behavior.",
                    confidence=0.80,
                ))

        return findings

    @staticmethod
    def _is_comment(line: str, lang: str) -> bool:
        if lang in ("python", "ruby", "bash", "yaml"):
            return line.startswith("#")
        elif lang in ("javascript", "typescript", "java", "go", "rust", "csharp", "cpp", "c"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False
