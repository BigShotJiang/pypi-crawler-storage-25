"""
Performance analyzer for VibePR.
Detects N+1 queries, memory leaks, blocking operations, and re-computation.
"""

from __future__ import annotations

import re

from vibe_pr.analyzers import BaseAnalyzer
from vibe_pr.models import FileChange, Finding, FindingLevel, PRInfo


class PerformanceAnalyzer(BaseAnalyzer):
    """Detects performance anti-patterns in code changes."""

    name = "performance"
    description = "Performance anti-pattern detection"

    def analyze(self, file_change: FileChange, context: PRInfo) -> list[Finding]:
        findings: list[Finding] = []

        if not file_change.added_lines:
            return findings

        lang = file_change.language or ""
        all_added = [(ln, c) for ln, c in file_change.added_lines]

        for line_no, line_content in file_change.added_lines:
            stripped = line_content.strip()
            if not stripped or self._is_comment(stripped, lang):
                continue

            findings.extend(self._check_n_plus_one(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_memory_issues(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_blocking_ops(file_change.path, line_no, stripped, lang))
            findings.extend(self._check_recomputation(file_change.path, line_no, stripped, lang))

        # Multi-line analysis
        findings.extend(self._check_loop_patterns(file_change.path, all_added, lang))

        return findings

    def _check_n_plus_one(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        """Detect potential N+1 query patterns."""
        findings = []

        # ORM queries in loops
        orm_patterns = [
            r'\.objects\.(?:get|filter|all|first|last)\s*\(',
            r'\.query\s*\.\s*(?:filter|get|all)\s*\(',
            r'session\.query\s*\(',
            r'\.find(?:One|Many|ById)?\s*\(',
            r'\.select\s*\(',
            r'await\s+\w+\.findUnique\s*\(',
            r'await\s+\w+\.findMany\s*\(',
        ]

        for pattern in orm_patterns:
            if re.search(pattern, line):
                # Check indentation to heuristically guess if inside a loop
                indent = len(line_content) - len(line_content.lstrip()) if 'line_content' in dir() else 0
                if indent >= 8:  # Likely inside a loop
                    findings.append(self._make_finding(
                        file=file_path,
                        line=line_no,
                        level=FindingLevel.WARNING,
                        issue="Potential N+1 query — database call may be inside a loop",
                        detail=(
                            "Executing a database query inside a loop causes N+1 queries: "
                            "1 query for the collection, then N queries for each item. "
                            "This scales linearly with data size and can crush performance."
                        ),
                        fix=(
                            "Use eager loading (select_related/prefetch_related in Django, "
                            "joinedload in SQLAlchemy, include in Prisma) to fetch related "
                            "data in a single query."
                        ),
                        confidence=0.55,
                    ))
                break

        return findings

    def _check_memory_issues(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        """Detect potential memory leak patterns."""
        findings = []

        # Unbounded list/dict growth
        if re.search(r'\.append\s*\(|\.extend\s*\(|\.add\s*\(', line):
            # Only flag if it looks like it's in a while/infinite context
            pass  # Requires multi-line context

        # Missing resource cleanup (Python)
        if lang == "python":
            if re.search(r'(?<!with\s)\bopen\s*\(', line) and "with" not in line:
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.WARNING,
                    issue="File opened without 'with' context manager",
                    detail=(
                        "Opening a file without a 'with' statement means the file handle "
                        "may not be properly closed, leading to resource leaks. This is "
                        "especially problematic in long-running processes."
                    ),
                    fix="Use 'with open(path) as f:' to ensure the file is automatically closed.",
                    confidence=0.75,
                ))

        # Event listener without cleanup (JavaScript)
        if lang in ("javascript", "typescript"):
            if re.search(r'addEventListener\s*\(', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="Event listener added — ensure cleanup on unmount",
                    detail=(
                        "Event listeners that are not removed when a component unmounts or "
                        "an object is destroyed cause memory leaks. Each re-mount adds another listener."
                    ),
                    fix=(
                        "Add a corresponding removeEventListener in a cleanup function "
                        "(componentWillUnmount, useEffect return, or ngOnDestroy)."
                    ),
                    confidence=0.50,
                ))

        return findings

    def _check_blocking_ops(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        """Detect blocking operations in async contexts."""
        findings = []

        if lang == "python":
            # time.sleep in async context
            if re.search(r'time\.sleep\s*\(', line):
                findings.append(self._make_finding(
                    file=file_path,
                    line=line_no,
                    level=FindingLevel.SUGGESTION,
                    issue="time.sleep() blocks the thread",
                    detail=(
                        "time.sleep() blocks the entire thread. In async code, use "
                        "'await asyncio.sleep()' instead. In threaded code, this may be acceptable."
                    ),
                    fix="If in async context: use 'await asyncio.sleep(n)'. If in a sync context, this may be fine.",
                    confidence=0.45,
                ))

        if lang in ("javascript", "typescript"):
            # Sync filesystem operations
            sync_ops = ["readFileSync", "writeFileSync", "existsSync", "mkdirSync", "readdirSync"]
            for op in sync_ops:
                if op in line:
                    findings.append(self._make_finding(
                        file=file_path,
                        line=line_no,
                        level=FindingLevel.WARNING,
                        issue=f"Synchronous {op}() blocks the event loop",
                        detail=(
                            f"{op}() blocks the Node.js event loop while waiting for I/O. "
                            "This prevents the server from handling other requests."
                        ),
                        fix=f"Use the async equivalent from 'fs/promises' or 'fs.{op.replace('Sync', '')}()' with a callback.",
                        confidence=0.70,
                    ))

        return findings

    def _check_recomputation(
        self, file_path: str, line_no: int, line: str, lang: str
    ) -> list[Finding]:
        """Detect potential unnecessary re-computation."""
        findings = []

        # React: missing dependency arrays or inline objects
        if lang in ("javascript", "typescript"):
            if re.search(r'useMemo\s*\(\s*\(\)\s*=>', line):
                if re.search(r',\s*\[\s*\]\s*\)', line):
                    findings.append(self._make_finding(
                        file=file_path,
                        line=line_no,
                        level=FindingLevel.SUGGESTION,
                        issue="useMemo with empty dependency array — computed value never updates",
                        detail="A useMemo with [] as deps will compute the value once and never recompute, even if inputs change.",
                        fix="Add the relevant dependencies to the array, or use useRef for truly constant values.",
                        confidence=0.50,
                    ))

            if re.search(r'useEffect\s*\(\s*(?:async\s*)?\(\)\s*=>', line):
                if re.search(r',\s*\)\s*;?\s*$', line) or not re.search(r',\s*\[', line):
                    findings.append(self._make_finding(
                        file=file_path,
                        line=line_no,
                        level=FindingLevel.WARNING,
                        issue="useEffect without dependency array — runs on every render",
                        detail="Without a dependency array, this effect runs after every render, which usually causes performance issues or infinite loops.",
                        fix="Add a dependency array: useEffect(() => { ... }, [dep1, dep2])",
                        confidence=0.65,
                    ))

        return findings

    def _check_loop_patterns(
        self, file_path: str, lines: list[tuple[int, str]], lang: str
    ) -> list[Finding]:
        """Multi-line analysis for performance issues in loops."""
        findings = []

        # Detect queries/API calls inside loops
        in_loop = False
        loop_start_line = 0

        for line_no, line in lines:
            stripped = line.strip()

            # Detect loop starts
            if re.match(r'^(?:for|while)\b', stripped):
                in_loop = True
                loop_start_line = line_no
            elif in_loop and not stripped:
                # Heuristic: blank line might end the loop body
                # (very rough — proper AST analysis would be better)
                pass

            if in_loop:
                # HTTP requests in loops
                http_patterns = [
                    r'requests\.(?:get|post|put|patch|delete)\s*\(',
                    r'fetch\s*\(',
                    r'axios\.(?:get|post|put|patch|delete)\s*\(',
                    r'http\.(?:get|post|put|patch|delete)\s*\(',
                    r'urllib\.request\.urlopen\s*\(',
                ]
                for pattern in http_patterns:
                    if re.search(pattern, stripped):
                        findings.append(self._make_finding(
                            file=file_path,
                            line=line_no,
                            level=FindingLevel.WARNING,
                            issue="HTTP request inside a loop — consider batching",
                            detail=(
                                "Making HTTP requests inside a loop is slow due to network latency. "
                                "If the API supports batching, use a single request for all items."
                            ),
                            fix="Batch the requests into a single API call, or use asyncio.gather() / Promise.all() for concurrent execution.",
                            confidence=0.60,
                        ))
                        break

        return findings

    @staticmethod
    def _is_comment(line: str, lang: str) -> bool:
        if lang in ("python", "ruby", "bash", "yaml"):
            return line.startswith("#")
        elif lang in ("javascript", "typescript", "java", "go", "rust", "csharp", "cpp", "c"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False
