"""
Review prompt templates for VibePR.
Carefully crafted prompts that encode the review philosophy.
"""

SYSTEM_PROMPT = """You are VibePR, an expert AI code reviewer. You review code with the same depth, care, and directness as a senior engineer who deeply understands software craftsmanship.

You are NOT a linter. You do not flag style issues. You think at the level of logic, architecture, security, and intent.

REVIEW RULES:
1. Classify every finding into one of four levels:
   - BLOCKER: Must fix before merge. Logic errors, security vulnerabilities, data loss risks.
   - WARNING: Should fix. Performance issues, missing error handling, unclear naming.
   - SUGGESTION: Consider changing. Better patterns, simpler approaches, future-proofing.
   - PRAISE: What is done well. Good abstractions, smart optimizations, clean test coverage.

2. For every BLOCKER and WARNING, explain WHY it matters and WHAT could go wrong.

3. For every issue, provide a concrete fix or alternative.

4. Be direct. No filler phrases. Start with the finding itself.

OUTPUT FORMAT (one per finding):
FILE: <path>
LINE: <number>
LEVEL: <BLOCKER|WARNING|SUGGESTION|PRAISE>
ISSUE: <one-line summary>
DETAIL: <why this matters>
FIX: <concrete fix>

If there are no issues, say "No issues found." and optionally add PRAISE findings."""


def build_review_prompt(
    diff: str,
    file_path: str,
    pr_description: str = "",
    language: str | None = None,
) -> str:
    """Build a review prompt for a single file diff."""
    parts = [
        f"Review this code change in `{file_path}`",
    ]

    if language:
        parts[0] += f" ({language})"

    if pr_description:
        parts.append(f"\nPR DESCRIPTION:\n{pr_description}")

    parts.append(f"\nDIFF:\n```\n{diff}\n```")

    parts.append(
        "\nFocus on: security vulnerabilities, logic errors, edge cases, "
        "performance issues, and maintainability. Do not flag formatting or style."
    )

    return "\n".join(parts)


def build_summary_prompt(
    pr_description: str,
    file_summaries: list[str],
    finding_counts: dict[str, int],
) -> str:
    """Build a prompt to generate an overall PR summary."""
    parts = [
        "Generate a one-paragraph summary of this pull request and whether it is ready to merge.",
        "",
    ]

    if pr_description:
        parts.append(f"PR DESCRIPTION:\n{pr_description}\n")

    if file_summaries:
        parts.append("FILES CHANGED:")
        for summary in file_summaries:
            parts.append(f"  - {summary}")
        parts.append("")

    parts.append(f"FINDINGS: {finding_counts.get('blockers', 0)} blockers, "
                 f"{finding_counts.get('warnings', 0)} warnings, "
                 f"{finding_counts.get('suggestions', 0)} suggestions, "
                 f"{finding_counts.get('praises', 0)} praises")

    parts.append("\nWrite a clear, direct summary. State whether the PR should be approved, "
                 "needs changes, or needs discussion. Be specific about any blocking issues.")

    return "\n".join(parts)
