"""
LLM integration package for VibePR.
"""

from vibe_pr.llm.base import BaseLLMProvider

__all__ = ["BaseLLMProvider"]
