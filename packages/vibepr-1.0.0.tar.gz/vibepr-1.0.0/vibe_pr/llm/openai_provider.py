"""
OpenAI LLM provider for VibePR.
"""

from __future__ import annotations

import os
import re
from typing import Optional

from vibe_pr.llm.base import BaseLLMProvider
from vibe_pr.llm.prompts import SYSTEM_PROMPT, build_review_prompt, build_summary_prompt


class OpenAIProvider(BaseLLMProvider):
    """OpenAI GPT provider for deep code review."""

    name = "openai"

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o"):
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self._model = model
        self._client = None

    @property
    def client(self):
        if self._client is None:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self._api_key)
            except ImportError:
                raise RuntimeError("openai package required. Install with: pip install openai")
        return self._client

    def is_available(self) -> bool:
        return bool(self._api_key)

    def review_diff(
        self,
        diff: str,
        file_path: str,
        pr_description: str = "",
        language: Optional[str] = None,
    ) -> str:
        prompt = build_review_prompt(diff, file_path, pr_description, language)

        response = self.client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=4096,
        )

        return response.choices[0].message.content or ""

    def generate_summary(
        self,
        pr_description: str,
        file_summaries: list[str],
        finding_counts: dict[str, int],
    ) -> str:
        prompt = build_summary_prompt(pr_description, file_summaries, finding_counts)

        response = self.client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=1024,
        )

        return response.choices[0].message.content or ""
