"""
Anthropic Claude LLM provider for VibePR.
"""

from __future__ import annotations

import os
from typing import Optional

from vibe_pr.llm.base import BaseLLMProvider
from vibe_pr.llm.prompts import SYSTEM_PROMPT, build_review_prompt, build_summary_prompt


class AnthropicProvider(BaseLLMProvider):
    """Anthropic Claude provider for deep code review."""

    name = "anthropic"

    def __init__(self, api_key: Optional[str] = None, model: str = "claude-sonnet-4-20250514"):
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self._model = model
        self._client = None

    @property
    def client(self):
        if self._client is None:
            try:
                from anthropic import Anthropic
                self._client = Anthropic(api_key=self._api_key)
            except ImportError:
                raise RuntimeError("anthropic package required. Install with: pip install anthropic")
        return self._client

    def is_available(self) -> bool:
        return bool(self._api_key)

    def review_diff(
        self,
        diff: str,
        file_path: str,
        pr_description: str = "",
        language: Optional[str] = None,
    ) -> str:
        prompt = build_review_prompt(diff, file_path, pr_description, language)

        response = self.client.messages.create(
            model=self._model,
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
        )

        return response.content[0].text if response.content else ""

    def generate_summary(
        self,
        pr_description: str,
        file_summaries: list[str],
        finding_counts: dict[str, int],
    ) -> str:
        prompt = build_summary_prompt(pr_description, file_summaries, finding_counts)

        response = self.client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
        )

        return response.content[0].text if response.content else ""
