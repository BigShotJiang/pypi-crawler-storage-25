"""
Abstract LLM provider interface for VibePR.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class BaseLLMProvider(ABC):
    """Abstract base class for LLM providers."""

    name: str = "base"

    @abstractmethod
    def review_diff(
        self,
        diff: str,
        file_path: str,
        pr_description: str = "",
        language: Optional[str] = None,
    ) -> str:
        """
        Send a diff to the LLM for semantic review.

        Args:
            diff: The unified diff text to review
            file_path: Path of the file being reviewed
            pr_description: PR description for context
            language: Programming language of the file

        Returns:
            Structured review text from the LLM
        """
        ...

    @abstractmethod
    def generate_summary(
        self,
        pr_description: str,
        file_summaries: list[str],
        finding_counts: dict[str, int],
    ) -> str:
        """
        Generate a high-level PR summary.

        Args:
            pr_description: PR description text
            file_summaries: Per-file summary notes
            finding_counts: Count of findings by level

        Returns:
            Summary paragraph text
        """
        ...

    def is_available(self) -> bool:
        """Check if this provider's API key is configured."""
        return False
