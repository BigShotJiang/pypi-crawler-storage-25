"""llmner – Schema-driven Named Entity Recognition powered by local LLMs.

The public API surface is intentionally small:

* :class:`~llmner.base_model.NERBaseModel` – base class for extraction schemas.
* :class:`~llmner.factories.SchemaRegistry` – factory for typed, self-documenting
  Pydantic field annotations.
* :class:`~llmner.factories.EvidenceField` – container pairing an extracted
  value with its supporting textual evidence.
* :class:`~llmner.extractor.NERExtractor` – orchestrates prompt building,
  LLM calls, parsing, and optional retries.
* :class:`~llmner.llm_client.OllamaClient` – default HTTP client for Ollama.
* :func:`~llmner.factories.is_null_value` – utility to test for null-like values.

Typical usage::

    from llmner import NERBaseModel, NERExtractor, SchemaRegistry

    registry = SchemaRegistry()

    class PersonSchema(NERBaseModel):
        name: registry.generic("name", "Full name of the person.") = None
        age:  registry.int_range("age", "Age in years or range.") = None

    extractor = NERExtractor(
        schema_class=PersonSchema,
        system_role="You are an expert information extractor.",
        system_task="Extract the requested fields. Return null if absent.",
        rules_registry=registry.rules,
    )

    result = extractor.extract_one("John Smith, aged 34, was interviewed.")
    print(result.name.value)   # "John Smith"
    print(result.age.value)    # "34"
    print(result.name.evidence)  # "John Smith"
"""

from importlib.metadata import version

from llmner.base_model import NERBaseModel
from llmner.extractor import NERExtractor
from llmner.factories import EvidenceField, SchemaRegistry, is_null_value
from llmner.llm_client import OllamaClient
from llmner.prompt import DEFAULT_PROMPT_TEMPLATE, PromptBuilder

__version__ = version("llm-ner")

__all__ = [
    "__version__",
    "NERBaseModel",
    "NERExtractor",
    "EvidenceField",
    "SchemaRegistry",
    "is_null_value",
    "OllamaClient",
    "PromptBuilder",
    "DEFAULT_PROMPT_TEMPLATE",
]
