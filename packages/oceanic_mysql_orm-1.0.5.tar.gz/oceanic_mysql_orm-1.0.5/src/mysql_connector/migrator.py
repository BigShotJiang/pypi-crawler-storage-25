"""
ORM Migrations Engine — handles schema discovery and synchronization.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional, Type, Dict, TYPE_CHECKING

from .types import ColumnInfo, FieldDefinition
from .registry import registry

if TYPE_CHECKING:
    from .pool import ConnectionPool
    from .model import MySQLModel

logger = logging.getLogger(__name__)


# Map Python type -> MySQL type string
TYPE_MAP = {
    int:      "INT",
    str:      "VARCHAR(255)",
    bool:     "TINYINT(1)",
    float:    "DOUBLE",
    dict:     "JSON",
    list:     "JSON",
}


class Migrator:
    """
    Orchestrates schema inspection and synchronization.
    """

    def __init__(self, pool: ConnectionPool):
        self._pool = pool

    async def migrate(self) -> None:
        """
        Synchronize all registered models with the database.
        1. Creates missing tables.
        2. Adds missing columns to existing tables.
        """
        db_name = self._pool._config.get("db")
        if not db_name:
            logger.warning("No database name in config; skipping migrations.")
            return

        # 1. Get current schema state
        current_schema = await self._get_db_schema(db_name)

        # 2. Iterate over all registered models
        for model in registry.all().values():
            table_name = model.__table__
            
            if table_name not in current_schema:
                await self._create_table(model)
            else:
                await self._sync_columns(model, current_schema[table_name])

    async def _get_db_schema(self, db_name: str) -> Dict[str, Dict[str, ColumnInfo]]:
        """
        Fetch all columns for all tables in the current database.
        Returns: { 'table_name': { 'column_name': ColumnInfo } }
        """
        sql = """
            SELECT 
                TABLE_NAME, 
                COLUMN_NAME, 
                DATA_TYPE, 
                IS_NULLABLE, 
                COLUMN_DEFAULT, 
                CHARACTER_MAXIMUM_LENGTH, 
                COLUMN_KEY, 
                EXTRA
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = %s
        """
        async with self._pool.cursor() as cur:
            await cur.execute(sql, [db_name])
            rows = await cur.fetchall()

        schema: Dict[str, Dict[str, ColumnInfo]] = {}
        for row in rows:
            table = row["TABLE_NAME"]
            col   = row["COLUMN_NAME"]
            
            if table not in schema:
                schema[table] = {}
            
            schema[table][col] = ColumnInfo(
                name           = col,
                data_type      = row["DATA_TYPE"].upper(),
                is_nullable    = row["IS_NULLABLE"].upper() == "YES",
                column_default = row["COLUMN_DEFAULT"],
                character_maximum_length = row["CHARACTER_MAXIMUM_LENGTH"],
                column_key     = row["COLUMN_KEY"],
                extra          = row["EXTRA"],
            )
        return schema

    async def _create_table(self, model: Type[MySQLModel]) -> None:
        """Generate and execute a CREATE TABLE statement."""
        table_name = model.__table__
        logger.info("Migrator: Creating table '%s'", table_name)

        column_defs = []
        for name, field in model._fields.items():
            column_defs.append(self._build_column_sql(field))

        sql = f"CREATE TABLE `{table_name}` ({', '.join(column_defs)}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        
        self._pool.log_query(sql)
        async with self._pool.cursor() as cur:
            await cur.execute(sql)

    async def _sync_columns(self, model: Type[MySQLModel], db_cols: Dict[str, ColumnInfo]) -> None:
        """Find columns in the model that are missing in the DB and ADD them."""
        table_name = model.__table__
        
        for col_name, field in model._fields.items():
            if col_name not in db_cols:
                logger.info("Migrator: Adding column '%s' to table '%s'", col_name, table_name)
                col_sql = self._build_column_sql(field)
                sql = f"ALTER TABLE `{table_name}` ADD COLUMN {col_sql}"
                self._pool.log_query(sql)
                async with self._pool.cursor() as cur:
                    await cur.execute(sql)

    def _build_column_sql(self, field: FieldDefinition) -> str:
        """Convert a FieldDefinition to a partial SQL column definition string."""
        mysql_type = TYPE_MAP.get(field.python_type, "VARCHAR(255)")
        
        if field.is_json:
            mysql_type = "JSON"
        elif field.python_type == str and field.max_length:
            mysql_type = f"VARCHAR({field.max_length})"
        elif field.auto_now or field.auto_now_add:
            mysql_type = "DATETIME"

        parts = [f"`{field.name}`", mysql_type]

        if not field.nullable:
            parts.append("NOT NULL")
        
        if field.auto_increment:
            parts.append("AUTO_INCREMENT")
        
        if field.primary_key:
            parts.append("PRIMARY KEY")
        
        if field.unique and not field.primary_key:
            parts.append("UNIQUE")

        # Handle defaults (Skip for JSON fields)
        if field.is_json:
            pass
        elif field.auto_now_add:
            parts.append("DEFAULT CURRENT_TIMESTAMP")
        elif field.auto_now:
            parts.append("DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
        elif field.has_default and field.default is not None:
            if isinstance(field.default, str):
                parts.append(f"DEFAULT '{field.default}'")
            elif isinstance(field.default, bool):
                parts.append(f"DEFAULT {1 if field.default else 0}")
            else:
                parts.append(f"DEFAULT {field.default}")

        return " ".join(parts)
