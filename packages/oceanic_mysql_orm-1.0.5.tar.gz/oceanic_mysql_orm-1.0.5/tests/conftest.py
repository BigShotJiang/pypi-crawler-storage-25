import pytest
import asyncio
from mysql_connector import MySQLConnector

@pytest.fixture(scope="function")
async def connector():
    """Session-wide connector fixture."""
    import os
    import pymysql
    
    # Environment-aware connection settings
    db_host = os.getenv("DB_HOST", "127.0.0.1")
    db_port = int(os.getenv("DB_PORT", "3307"))
    db_user = os.getenv("DB_USER", "root")
    db_pass = os.getenv("DB_PASSWORD", "secret")
    db_name = os.getenv("DB_NAME", "test_db")

    conn = MySQLConnector(
        host=db_host,
        port=db_port,
        user=db_user,
        password=db_pass,
        database=db_name
    )
    
    # Create test database if it doesn't exist
    bootstrap = pymysql.connect(
        host=db_host, 
        port=db_port, 
        user=db_user, 
        password=db_pass
    )
    with bootstrap.cursor() as cursor:
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
    bootstrap.commit()
    bootstrap.close()

    await conn.connect()
    yield conn
    await conn.disconnect()

@pytest.fixture(autouse=True)
async def cleanup_db(connector):
    """Clean up the database before each test."""
    # We can't easily truncate all without knowing models, 
    # but tests should probably handle their own tables or we can drop all here.
    # For now, let's just provide the connector.
    yield
