"""
CLI subcommands: create, attach, agents, mappings, onboard, agent (inspect).

Mirrors UI onboarding (bind → name → register) vs mapping (explicit registry ops).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from puvinoise.agent_state import find_all_agent_states, load_agent_state, save_agent_state
from puvinoise.tenant_api import (
    TenantApiError,
    api_auto_register,
    api_create_agent,
    api_get_agent,
    api_list_agents,
    api_patch_agent,
    load_binding,
    resolve_bearer,
)


def parse_tags_csv(s: Optional[str]) -> Dict[str, str]:
    """Parse --tags 'team=payments,stage=prod' into a dict (keys lowercased for CLI convenience)."""
    if not s or not str(s).strip():
        return {}
    out: Dict[str, str] = {}
    for part in str(s).split(","):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip()
        if k and v:
            out[k.lower()] = v
    return out


def parse_filter_args(filters: Optional[List[str]]) -> List[Tuple[str, str]]:
    """Parse repeated --filter team=payments → [(team, payments), ...]."""
    out: List[Tuple[str, str]] = []
    if not filters:
        return out
    for raw in filters:
        s = str(raw or "").strip()
        if not s or "=" not in s:
            print(f"puvinoise agents: ignoring invalid --filter {raw!r} (expected key=value)", file=sys.stderr)
            continue
        k, _, v = s.partition("=")
        k, v = k.strip(), v.strip()
        if k and v:
            out.append((k, v))
    return out


def agent_name_convention_warnings(name: str) -> List[str]:
    """Non-blocking hints; server still enforces uniqueness."""
    w: List[str] = []
    if name != name.strip():
        w.append("Name has leading/trailing spaces.")
    if re.search(r"\s{2,}", name):
        w.append("Multiple consecutive spaces — consider a single hyphen (e.g. my-service-agent).")
    if len(name) > 1 and name.upper() == name and re.search(r"[A-Z]", name):
        w.append("All-caps names are noisy in lists; prefer lowercase-with-hyphens.")
    if not re.match(r"^[a-zA-Z0-9][a-zA-Z0-9 _.\-]*$", name):
        w.append("Use letters, numbers, spaces, hyphens, underscores, dots for broad tooling compatibility.")
    return w


def _tags_cell(tags: object) -> str:
    if not tags or not isinstance(tags, dict):
        return "—"
    items = sorted((str(k), str(v)) for k, v in tags.items() if k)
    if not items:
        return "—"
    return ",".join(f"{k}={v}" for k, v in items)


def _print_agents_table(agents: List[dict], *, show_tags: bool = True) -> None:
    rows = []
    for a in agents:
        aid = a.get("agent_id") or "—"
        name = a.get("name") or "—"
        eid = a.get("environmentId") or "—"
        ename = a.get("environmentName") or "—"
        tcell = _tags_cell(a.get("tags") or {}) if show_tags else ""
        rows.append((str(aid), str(name), str(eid), str(ename), tcell))
    if not rows:
        print("No agents returned.")
        return
    w0 = max(len(r[0]) for r in rows)
    w1 = max(len(r[1]) for r in rows)
    w2 = max(len(r[2]) for r in rows)
    w3 = max(len(r[3]) for r in rows)
    if show_tags:
        w4 = max(len(r[4]) for r in rows)
        print(
            f"{'agent_id'.ljust(w0)}  {'name'.ljust(w1)}  "
            f"{'env_id'.ljust(w2)}  {'env_name'.ljust(w3)}  {'tags'.ljust(w4)}"
        )
        for aid, name, eid, ename, tcell in rows:
            print(
                f"{aid.ljust(w0)}  {name.ljust(w1)}  "
                f"{eid.ljust(w2)}  {ename.ljust(w3)}  {tcell.ljust(w4)}"
            )
    else:
        print(f"{'agent_id'.ljust(w0)}  {'name'.ljust(w1)}  {'env_id'.ljust(w2)}  {'env_name'.ljust(w3)}")
        for aid, name, eid, ename, _ in rows:
            print(f"{aid.ljust(w0)}  {name.ljust(w1)}  {eid.ljust(w2)}  {ename.ljust(w3)}")


def _persist_from_auto_register(workdir: Path, ar: dict, env_id: str, base_url: str) -> None:
    save_agent_state(
        str(ar.get("agent_id", "")).strip(),
        env_id=str(ar.get("env_id", env_id)).strip(),
        base_url=base_url,
        workdir=workdir,
        api_key=str(ar.get("api_key", "")).strip(),
        tenant_id=str(ar.get("tenant_id", "")).strip(),
        agent_name=str(ar.get("agent_name", "")).strip(),
    )


def cmd_agents(args: argparse.Namespace) -> int:
    try:
        base_url, _eid, _en, _tid = load_binding(Path.cwd())
        bearer = resolve_bearer(getattr(args, "bearer", None))
        tag_filters = parse_filter_args(getattr(args, "filter", None))
        search = (getattr(args, "search", None) or "").strip() or None
        agents = api_list_agents(base_url, bearer, tag_filters=tag_filters or None, search=search)
        _print_agents_table(agents)
        return 0
    except ValueError as e:
        print(f"puvinoise agents: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:
        print(f"puvinoise agents: {e}", file=sys.stderr)
        return 1


def cmd_mappings(args: argparse.Namespace) -> int:
    try:
        base_url, env_id, env_name, tenant_id = load_binding(Path.cwd())
        bearer = resolve_bearer(getattr(args, "bearer", None))
        agents = api_list_agents(base_url, bearer)
        mapped = [
            a
            for a in agents
            if a.get("environmentId") and str(a.get("environmentId")) == str(env_id)
        ]
        print("Mapping — active bound environment")
        print(f"  environment_id:   {env_id}")
        print(f"  environment_name: {env_name or '—'}")
        print(f"  tenant_id:        {tenant_id or '—'}")
        print()
        print(f"Agents mapped to this environment ({len(mapped)}):")
        if not mapped:
            print("  (none — use `puvinoise create` or `puvinoise attach --agent-id ...`)")
            return 0
        _print_agents_table(mapped)
        return 0
    except ValueError as e:
        print(f"puvinoise mappings: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:
        print(f"puvinoise mappings: {e}", file=sys.stderr)
        return 1


def cmd_agent_inspect(args: argparse.Namespace) -> int:
    aid = (getattr(args, "agent_id", None) or "").strip()
    if not aid:
        print("puvinoise agent: agent id or name is required", file=sys.stderr)
        return 2
    try:
        base_url, _eid, _en, _tid = load_binding(Path.cwd())
        bearer = resolve_bearer(getattr(args, "bearer", None))
        agent = api_get_agent(base_url, bearer, aid)
        print(json.dumps({"agent": agent}, indent=2))
        return 0
    except ValueError as e:
        print(f"puvinoise agent: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:
        print(f"puvinoise agent: {e}", file=sys.stderr)
        return 1


def cmd_create(args: argparse.Namespace) -> int:
    workdir = Path.cwd().resolve()
    name = (getattr(args, "name", None) or "").strip()
    if not name:
        print("puvinoise create: --name is required", file=sys.stderr)
        return 2
    tags = parse_tags_csv(getattr(args, "tags", None))
    for hint in agent_name_convention_warnings(name):
        print(f"puvinoise create: warning: {hint}", file=sys.stderr)
    try:
        base_url, env_id, _en, _tid = load_binding(workdir)
        bearer = resolve_bearer(getattr(args, "bearer", None))
        existing_files = find_all_agent_states(workdir)
        if existing_files:
            print(
                "puvinoise create: this folder already has .puvinoise/agent_*.json.\n"
                "  Remove agent state first or use a different directory — "
                "the CLI does not auto-replace local identity.",
                file=sys.stderr,
            )
            return 3
        try:
            all_agents = api_list_agents(base_url, bearer)
        except Exception:
            all_agents = []
        name_lower = name.lower()
        for row in all_agents:
            if str(row.get("name") or "").strip().lower() == name_lower:
                rid = str(row.get("agent_id") or "").strip()
                print(
                    f"puvinoise create: warning: an agent named {name!r} already exists "
                    f"({rid}). Creating will fail — reuse with:\n"
                    f"  puvinoise attach --agent-id {rid}",
                    file=sys.stderr,
                )
                break
        agent = api_create_agent(base_url, bearer, name, tags=tags or None)
        agent_id = str(agent.get("agent_id", "")).strip()
        api_patch_agent(base_url, bearer, agent_id, environment_id=env_id)
        ar = api_auto_register(base_url, env_id, name)
        _persist_from_auto_register(workdir, ar, env_id, base_url)
        tag_note = f" tags={tags!r}" if tags else ""
        print(f"✔ Created and attached agent {name} ({agent_id}); local credentials saved.{tag_note}")
        return 0
    except ValueError as e:
        print(f"puvinoise create: {e}", file=sys.stderr)
        return 2
    except TenantApiError as e:
        if e.status == 409 and e.payload:
            hint = e.payload.get("hint") or ""
            eid = e.payload.get("existing_agent_id") or ""
            print(f"puvinoise create: {e}", file=sys.stderr)
            if hint:
                print(f"  {hint}", file=sys.stderr)
            elif eid:
                print(f"  puvinoise attach --agent-id {eid}", file=sys.stderr)
        else:
            print(f"puvinoise create: {e}", file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(f"puvinoise create: {e}", file=sys.stderr)
        return 1


def cmd_attach(args: argparse.Namespace) -> int:
    workdir = Path.cwd().resolve()
    agent_id = (getattr(args, "agent_id", None) or "").strip()
    if not agent_id:
        print("puvinoise attach: --agent-id is required", file=sys.stderr)
        return 2
    try:
        base_url, env_id, _en, _tid = load_binding(workdir)
        bearer = resolve_bearer(getattr(args, "bearer", None))
        existing_files = find_all_agent_states(workdir)
        if existing_files:
            print(
                "puvinoise attach: this folder already has .puvinoise/agent_*.json.\n"
                "  Remove agent state first if you intend to switch the local agent identity.",
                file=sys.stderr,
            )
            return 3
        before = api_get_agent(base_url, bearer, agent_id)
        name = str(before.get("name", "")).strip()
        if not name:
            print("puvinoise attach: could not read agent name from server", file=sys.stderr)
            return 1
        api_patch_agent(base_url, bearer, agent_id, environment_id=env_id)
        ar = api_auto_register(base_url, env_id, name)
        _persist_from_auto_register(workdir, ar, env_id, base_url)
        print(f"✔ Attached {name} ({agent_id}) to this environment; local credentials saved.")
        return 0
    except ValueError as e:
        print(f"puvinoise attach: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:
        print(f"puvinoise attach: {e}", file=sys.stderr)
        return 1


def cmd_onboard(args: argparse.Namespace) -> int:
    """
    Onboarding without tenant JWT: bindcar must be done; then auto-register + local state.
    Does not create registry rows via POST /api/agents (server auto-register path handles that).
    """
    workdir = Path.cwd().resolve()
    try:
        base_url, env_id, _en, _tid = load_binding(workdir)
    except ValueError as e:
        print(f"puvinoise onboard: {e}", file=sys.stderr)
        print(
            "\nOnboarding step 1 — bind this folder to the platform:\n"
            "  puvinoise bindcar --token <prt_...>\n",
            file=sys.stderr,
        )
        return 2

    st, _p = load_agent_state(workdir)
    if st:
        print(
            "puvinoise onboard: an agent is already registered in this folder.\n"
            "  Use `puvinoise run ...` or mapping commands (`puvinoise attach`, etc.).",
            file=sys.stderr,
        )
        return 3

    name = (getattr(args, "name", None) or "").strip()
    if not name:
        if sys.stdin.isatty():
            try:
                name = input("Enter agent name: ").strip()
            except EOFError:
                name = ""
        else:
            print(
                "puvinoise onboard: --name is required in non-interactive environments",
                file=sys.stderr,
            )
            return 2
    if not name:
        print("puvinoise onboard: agent name must be non-empty", file=sys.stderr)
        return 2

    for hint in agent_name_convention_warnings(name):
        print(f"puvinoise onboard: warning: {hint}", file=sys.stderr)

    try:
        ar = api_auto_register(base_url, env_id, name)
        _persist_from_auto_register(workdir, ar, env_id, base_url)
        print(f"✔ Registered agent {name} locally. Run your code with:\n  puvinoise run python main.py")
        return 0
    except RuntimeError as e:
        print(f"puvinoise onboard: {e}", file=sys.stderr)
        return 1


def register_tenant_subparsers(sub: object) -> None:
    common_bearer = argparse.ArgumentParser(add_help=False)
    common_bearer.add_argument(
        "--bearer",
        default=None,
        help="Tenant JWT (overrides PUVINOISE_BEARER_TOKEN)",
    )

    p_agents = sub.add_parser(
        "agents",
        parents=[common_bearer],
        help="List tenant agents (requires JWT + bound environment folder)",
    )
    p_agents.add_argument(
        "--filter",
        action="append",
        dest="filter",
        metavar="KEY=VALUE",
        help="Filter by tag (repeatable), e.g. --filter team=payments",
    )
    p_agents.add_argument(
        "--search",
        default=None,
        help="Substring match on agent name or agent_id",
    )
    p_agents.set_defaults(func=cmd_agents)

    p_map = sub.add_parser(
        "mappings",
        parents=[common_bearer],
        help="Show bound environment and agents mapped to it",
    )
    p_map.set_defaults(func=cmd_mappings)

    p_inspect = sub.add_parser(
        "agent",
        parents=[common_bearer],
        help="Inspect one agent by agt_ id or name (JSON)",
    )
    p_inspect.add_argument("agent_id", help="Agent id (agt_...) or name")
    p_inspect.set_defaults(func=cmd_agent_inspect)

    p_create = sub.add_parser(
        "create",
        parents=[common_bearer],
        help="Create a registry agent, attach to bound env, save local credentials (JWT required)",
    )
    p_create.add_argument("--name", required=True, help="Agent display name (unique per tenant)")
    p_create.add_argument(
        "--tags",
        default=None,
        help='Key-value tags, e.g. "team=payments,stage=prod"',
    )
    p_create.set_defaults(func=cmd_create)

    p_attach = sub.add_parser(
        "attach",
        parents=[common_bearer],
        help="Attach an existing agent to the bound environment and save local credentials",
    )
    p_attach.add_argument("--agent-id", required=True, help="Canonical agent id (agt_...)")
    p_attach.set_defaults(func=cmd_attach)

    p_onboard = sub.add_parser(
        "onboard",
        help="After bindcar: enter agent name and register locally (no JWT; bootstrapped env required)",
    )
    p_onboard.add_argument("--name", default=None, help="Agent name (required if stdin is not a TTY)")
    p_onboard.set_defaults(func=cmd_onboard)
