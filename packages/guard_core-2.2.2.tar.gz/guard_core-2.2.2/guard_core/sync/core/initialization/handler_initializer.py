import logging
import threading
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from guard_core.models import SecurityConfig
    from guard_core.sync.core.events.metrics import MetricsCollector
    from guard_core.sync.core.events.middleware_events import SecurityEventBus


class HandlerInitializer:
    def __init__(
        self,
        config: "SecurityConfig",
        redis_handler: Any = None,
        agent_handler: Any = None,
        geo_ip_handler: Any = None,
        rate_limit_handler: Any = None,
        guard_decorator: Any = None,
    ):
        self.config = config
        self.redis_handler = redis_handler
        self.agent_handler = agent_handler
        self.geo_ip_handler = geo_ip_handler
        self.rate_limit_handler = rate_limit_handler
        self.guard_decorator = guard_decorator
        self.composite_handler: Any = None
        self.event_filter: Any = None
        self.enricher: Any = None
        self.behavior_tracker: Any = None
        self._lazy_init_task: threading.Thread | None = None
        self.logger = logging.getLogger("guard_core.sync.core.initialization")

    def build_enricher(self) -> Any | None:
        if not self.config.enable_enrichment:
            return None
        from guard_core.sync.core.events.enricher import (
            EnrichmentContext,
            EventEnricher,
        )

        dynamic_rule_handler: Any = None
        if self.config.enable_dynamic_rules:
            from guard_core.sync.handlers.dynamic_rule_handler import DynamicRuleManager

            dynamic_rule_handler = DynamicRuleManager(self.config)

        behavior_tracker: Any = None
        if self.guard_decorator is not None:
            behavior_tracker = getattr(self.guard_decorator, "behavior_tracker", None)
        if behavior_tracker is None:
            from guard_core.sync.handlers.behavior_handler import BehaviorTracker

            behavior_tracker = BehaviorTracker(self.config)

        self.behavior_tracker = behavior_tracker

        context = EnrichmentContext(
            config=self.config,
            agent_handler=self.agent_handler,
            dynamic_rule_handler=dynamic_rule_handler,
            behavior_tracker=behavior_tracker,
        )
        return EventEnricher(context)

    def build_composite_handler(self) -> Any:
        from guard_core.sync.core.events.composite_handler import CompositeAgentHandler

        handlers = []
        if self.agent_handler:
            handlers.append(self.agent_handler)
        if self.config.enable_otel:
            from guard_core.sync.core.events.otel_handler import OtelHandler

            handlers.append(OtelHandler(self.config))
        if self.config.enable_logfire:
            from guard_core.sync.core.events.logfire_handler import LogfireHandler

            handlers.append(LogfireHandler(self.config))
        event_filter = self.build_event_filter()
        self.enricher = self.build_enricher()
        return CompositeAgentHandler(
            handlers, event_filter=event_filter, enricher=self.enricher
        )

    def build_event_filter(self) -> Any:
        from guard_core.sync.core.events.event_types import EventFilter

        return EventFilter(
            muted_event_types=frozenset(self.config.muted_event_types),
            muted_metric_types=frozenset(self.config.muted_metric_types),
        )

    def build_event_bus(self, geo_ip_handler: Any = None) -> "SecurityEventBus":
        from guard_core.sync.core.events.middleware_events import SecurityEventBus

        if self.composite_handler is None or self.event_filter is None:
            raise RuntimeError(
                "Call initialize_agent_integrations() before build_event_bus()."
            )
        return SecurityEventBus(
            agent_handler=self.composite_handler,
            config=self.config,
            geo_ip_handler=geo_ip_handler or self.geo_ip_handler,
            event_filter=self.event_filter,
        )

    def build_metrics_collector(self) -> "MetricsCollector":
        from guard_core.sync.core.events.metrics import MetricsCollector

        if self.composite_handler is None or self.event_filter is None:
            raise RuntimeError(
                "Call initialize_agent_integrations() before build_metrics_collector()."
            )
        return MetricsCollector(
            agent_handler=self.composite_handler,
            config=self.config,
            event_filter=self.event_filter,
        )

    def _run_lazy_init(self) -> None:
        try:
            from guard_core.sync.handlers.cloud_handler import cloud_handler

            if self.config.block_cloud_providers:
                cloud_handler.initialize_redis(
                    self.redis_handler,
                    self.config.block_cloud_providers,
                    ttl=self.config.cloud_ip_refresh_interval,
                )
            if self.geo_ip_handler is not None:
                self.geo_ip_handler.initialize_redis(self.redis_handler)
        except Exception as e:
            self.logger.warning(
                "Lazy background initialization failed: %s", e, exc_info=True
            )

    def initialize_redis_handlers(self) -> None:
        if not (self.config.enable_redis and self.redis_handler):
            return

        self.redis_handler.initialize()

        from guard_core.sync.handlers.cloud_handler import cloud_handler
        from guard_core.sync.handlers.ipban_handler import ip_ban_manager
        from guard_core.sync.handlers.suspatterns_handler import sus_patterns_handler

        if self.config.cloud_ip_store is not None:
            cloud_handler.set_store(self.config.cloud_ip_store)

        if self.config.lazy_init:
            self._lazy_init_task = threading.Thread(
                target=self._run_lazy_init, daemon=True
            )
            self._lazy_init_task.start()
        else:
            if self.config.block_cloud_providers:
                cloud_handler.initialize_redis(
                    self.redis_handler,
                    self.config.block_cloud_providers,
                    ttl=self.config.cloud_ip_refresh_interval,
                )
            if self.geo_ip_handler is not None:
                self.geo_ip_handler.initialize_redis(self.redis_handler)

        ip_ban_manager.initialize_redis(self.redis_handler)

        if self.rate_limit_handler is not None:
            self.rate_limit_handler.initialize_redis(self.redis_handler)
        sus_patterns_handler.initialize_redis(self.redis_handler)

    def initialize_agent_for_handlers(self) -> None:
        telemetry = self.composite_handler or self.agent_handler
        if telemetry is None:
            return

        from guard_core.sync.handlers.cloud_handler import cloud_handler
        from guard_core.sync.handlers.ipban_handler import ip_ban_manager
        from guard_core.sync.handlers.suspatterns_handler import sus_patterns_handler

        ip_ban_manager.initialize_agent(telemetry)
        if self.rate_limit_handler is not None:
            self.rate_limit_handler.initialize_agent(telemetry)
        sus_patterns_handler.initialize_agent(telemetry)

        if self.config.block_cloud_providers:
            cloud_handler.initialize_agent(telemetry)

        if self.geo_ip_handler and hasattr(self.geo_ip_handler, "initialize_agent"):
            self.geo_ip_handler.initialize_agent(telemetry)

    def initialize_dynamic_rule_manager(self) -> None:
        if not self.config.enable_dynamic_rules:
            return
        if not self.agent_handler:
            self.logger.warning(
                "Dynamic rules enabled but agent unavailable; falling back to "
                "static config. Dashboard rule updates will not propagate until "
                "agent connectivity is restored."
            )
            return

        from guard_core.sync.handlers.dynamic_rule_handler import DynamicRuleManager

        dynamic_rule_manager = DynamicRuleManager(self.config)
        telemetry = self.composite_handler or self.agent_handler
        dynamic_rule_manager.initialize_agent(telemetry)

        if self.redis_handler:
            dynamic_rule_manager.initialize_redis(self.redis_handler)

    def initialize_agent_integrations(self) -> None:
        if (
            not self.agent_handler
            and not self.config.enable_otel
            and not self.config.enable_logfire
            and not self.config.enable_enrichment
        ):
            return

        self.composite_handler = self.build_composite_handler()
        self.event_filter = self.build_event_filter()

        self.composite_handler.start()

        if self.agent_handler and self.redis_handler:
            self.agent_handler.initialize_redis(self.redis_handler)
            self.redis_handler.initialize_agent(self.agent_handler)

        self.initialize_agent_for_handlers()

        if self.guard_decorator and hasattr(self.guard_decorator, "initialize_agent"):
            telemetry = self.composite_handler or self.agent_handler
            self.guard_decorator.initialize_agent(telemetry)

        self.initialize_dynamic_rule_manager()

    def shutdown_agent_integrations(self) -> None:
        if self.composite_handler is None:
            return
        self.composite_handler.stop()
        self.composite_handler = None
        self.event_filter = None
        self.enricher = None
