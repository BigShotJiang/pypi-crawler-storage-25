import fnmatch
import os
import posixpath
import tomllib
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Literal

import tomlkit

from git_workspace import git
from git_workspace.assets import Copier
from git_workspace.env import BASE_VAR_KEYS, FINGERPRINT_VAR_PREFIX
from git_workspace.errors import WorktreeListingError
from git_workspace.fingerprint import SUPPORTED_ALGORITHMS
from git_workspace.manifest import KNOWN_CONDITION_KEYS, HookGroup, Manifest
from git_workspace.utils import normalize_variable_name

if TYPE_CHECKING:
    from git_workspace.workspace import Workspace


@dataclass
class Fix:
    """
    A remediation attached to a diagnostic finding.

    :param label: One-line description of what the fix does.
    :param kind: ``"auto"`` fixes are applied without prompting; ``"interactive"``
        fixes require user confirmation.
    :param apply: Callable that performs the fix when invoked.
    """

    label: str
    kind: Literal["auto", "interactive"]
    apply: Callable[[], None]


@dataclass
class Finding:
    """
    A diagnostic finding produced by a workspace health check.

    :param level: Severity of the finding; either ``"error"`` or ``"warning"``.
    :param message: Human-readable description of the issue.
    :param fix: Optional remediation; ``None`` if the issue cannot be fixed automatically.
    """

    level: Literal["error", "warning"]
    message: str
    fix: Fix | None = field(default=None, compare=False)


def _manifest_remove_hook_empty_entries(manifest_path: Path, event: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    for group in doc.get("hooks", {}).get(event, []):
        group["commands"] = [c for c in group.get("commands", []) if c.strip()]
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_deduplicate_hook_commands(manifest_path: Path, event: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    seen: set[str] = set()
    for group in doc.get("hooks", {}).get(event, []):
        new_cmds: list[str] = []
        for c in group.get("commands", []):
            if c not in seen:
                seen.add(c)
                new_cmds.append(c)
        group["commands"] = new_cmds
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_remove_hook_empty_groups(manifest_path: Path, event: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    hooks = doc.get("hooks", {})
    if event in hooks:
        groups = hooks[event]
        for i in range(len(groups) - 1, -1, -1):
            if not groups[i].get("commands", []):
                del groups[i]
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_remove_hook_command(manifest_path: Path, event: str, cmd: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    for group in doc.get("hooks", {}).get(event, []):
        group["commands"] = [c for c in group.get("commands", []) if c != cmd]
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_deduplicate_fingerprint_files(manifest_path: Path, fp_name: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    for fp in doc.get("fingerprint", []):
        if fp.get("name") == fp_name:
            seen: set[str] = set()
            deduped: list[str] = []
            for f in fp.get("files", []):
                if f not in seen:
                    seen.add(f)
                    deduped.append(f)
            fp["files"] = deduped
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_remove_link(manifest_path: Path, source: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    links = doc.get("link", [])
    for i in range(len(links) - 1, -1, -1):
        if links[i].get("source") == source:
            del links[i]
    manifest_path.write_text(tomlkit.dumps(doc))


def _manifest_remove_copy(manifest_path: Path, source: str) -> None:
    doc = tomlkit.loads(manifest_path.read_text())
    copies = doc.get("copy", [])
    for i in range(len(copies) - 1, -1, -1):
        if copies[i].get("source") == source:
            del copies[i]
    manifest_path.write_text(tomlkit.dumps(doc))


def _iter_hooks(workspace: Workspace) -> Iterator[tuple[str, list[HookGroup]]]:
    hooks = workspace.manifest.hooks
    yield from [
        ("on_setup", hooks.on_setup),
        ("on_attach", hooks.on_attach),
        ("on_detach", hooks.on_detach),
        ("on_teardown", hooks.on_teardown),
    ]


def _iter_hook_entries(workspace: Workspace) -> Iterator[tuple[str, str]]:
    for event, groups in _iter_hooks(workspace):
        for group in groups:
            for cmd in group.commands:
                yield event, cmd


def _check_manifest_parseable(workspace: Workspace, findings: list[Finding]) -> None:
    try:
        tomllib.loads(workspace.paths.manifest.read_text())
    except OSError as e:
        findings.append(Finding("error", f"Cannot read manifest: {e}"))
    except tomllib.TOMLDecodeError as e:
        findings.append(Finding("error", f"Manifest is not valid TOML: {e}"))


def _check_manifest_version(manifest: Manifest, findings: list[Finding]) -> None:
    if manifest.version > Manifest.DEFAULT_VERSION:
        findings.append(
            Finding(
                "error",
                f"Manifest version {manifest.version} is not supported"
                f" (max: {Manifest.DEFAULT_VERSION})",
            )
        )


def _check_asset_sources_exist(workspace: Workspace, findings: list[Finding]) -> None:
    assets_dir = workspace.paths.assets
    for link in workspace.manifest.links:
        if not (assets_dir / link.source).exists():
            findings.append(
                Finding(
                    "error",
                    f"Link source '{link.source}' does not exist in assets/",
                    fix=Fix(
                        label=f"Remove [[link]] entry for '{link.source}'",
                        kind="interactive",
                        apply=lambda p=workspace.paths.manifest, s=link.source: (
                            _manifest_remove_link(p, s)
                        ),
                    ),
                )
            )

    for copy in workspace.manifest.copies:
        if not (assets_dir / copy.source).exists():
            findings.append(
                Finding(
                    "error",
                    f"Copy source '{copy.source}' does not exist in assets/",
                    fix=Fix(
                        label=f"Remove [[copy]] entry for '{copy.source}'",
                        kind="interactive",
                        apply=lambda p=workspace.paths.manifest, s=copy.source: (
                            _manifest_remove_copy(p, s)
                        ),
                    ),
                )
            )


def _check_asset_target_clashes(workspace: Workspace, findings: list[Finding]) -> None:
    seen: dict[str, str] = {}
    for link in workspace.manifest.links:
        if link.target in seen:
            findings.append(
                Finding(
                    "error",
                    f"Asset target '{link.target}' is declared more than once"
                    f" (link clashes with {seen[link.target]})",
                )
            )
        else:
            seen[link.target] = "link"

    for copy in workspace.manifest.copies:
        if copy.target in seen:
            findings.append(
                Finding(
                    "error",
                    f"Asset target '{copy.target}' is declared more than once"
                    f" (copy clashes with {seen[copy.target]})",
                )
            )
        else:
            seen[copy.target] = "copy"


def _check_asset_target_escapes(workspace: Workspace, findings: list[Finding]) -> None:
    for asset in [*workspace.manifest.links, *workspace.manifest.copies]:
        normalized = posixpath.normpath(asset.target)
        if normalized.startswith("../") or normalized == ".." or posixpath.isabs(normalized):
            findings.append(
                Finding("error", f"Asset target '{asset.target}' escapes the worktree root")
            )


def _check_var_normalization_clashes(workspace: Workspace, findings: list[Finding]) -> None:
    seen: dict[str, str] = {}
    for key in workspace.manifest.vars:
        normalized = normalize_variable_name(key)
        if normalized in seen:
            findings.append(
                Finding(
                    "error",
                    f"Variables '{seen[normalized]}' and '{key}' both normalize"
                    f" to GIT_WORKSPACE_VAR_{normalized}",
                )
            )
        else:
            seen[normalized] = key


def _check_fingerprint_name_clashes(workspace: Workspace, findings: list[Finding]) -> None:
    seen: dict[str, str] = {}
    for fp in workspace.manifest.fingerprints:
        normalized = normalize_variable_name(fp.name)
        if normalized in seen:
            findings.append(
                Finding(
                    "error",
                    f"Fingerprints '{seen[normalized]}' and '{fp.name}' both normalize"
                    f" to {FINGERPRINT_VAR_PREFIX}{normalized}",
                )
            )
        else:
            seen[normalized] = fp.name


def _check_fingerprint_name_var_clashes(workspace: Workspace, findings: list[Finding]) -> None:
    var_normalized = {normalize_variable_name(k) for k in (workspace.manifest.vars or {})}
    for fp in workspace.manifest.fingerprints:
        normalized = normalize_variable_name(fp.name)
        if normalized in var_normalized:
            findings.append(
                Finding(
                    "warning",
                    f"Fingerprint '{fp.name}' and a var both normalize to '{normalized}';"
                    " they occupy different env namespaces (FINGERPRINT vs VAR)"
                    " but this may cause confusion in copy templates",
                )
            )


def _check_fingerprint_empty_name(workspace: Workspace, findings: list[Finding]) -> None:
    for fp in workspace.manifest.fingerprints:
        if not fp.name.strip():
            findings.append(Finding("error", "Fingerprint has an empty or whitespace-only name"))


def _check_fingerprint_files(workspace: Workspace, findings: list[Finding]) -> None:
    for fp in workspace.manifest.fingerprints:
        if not fp.files:
            findings.append(Finding("warning", f"Fingerprint '{fp.name}' has an empty files list"))
            continue

        seen: set[str] = set()
        for f in fp.files:
            if f in seen:
                findings.append(
                    Finding(
                        "warning",
                        f"File '{f}' is listed more than once in fingerprint '{fp.name}'",
                        fix=Fix(
                            label=f"Deduplicate files in fingerprint '{fp.name}'",
                            kind="auto",
                            apply=lambda p=workspace.paths.manifest, n=fp.name: (
                                _manifest_deduplicate_fingerprint_files(p, n)
                            ),
                        ),
                    )
                )
            seen.add(f)

            normalized = posixpath.normpath(f)
            if normalized.startswith("../") or normalized == ".." or posixpath.isabs(normalized):
                findings.append(
                    Finding(
                        "error",
                        f"File '{f}' in fingerprint '{fp.name}' escapes the worktree root",
                    )
                )


def _check_fingerprint_algorithm(workspace: Workspace, findings: list[Finding]) -> None:
    for fp in workspace.manifest.fingerprints:
        if fp.algorithm not in SUPPORTED_ALGORITHMS:
            findings.append(
                Finding(
                    "error",
                    f"Fingerprint '{fp.name}' uses unsupported algorithm '{fp.algorithm}'"
                    f" (supported: {', '.join(sorted(SUPPORTED_ALGORITHMS))})",
                )
            )


def _check_fingerprint_length(workspace: Workspace, findings: list[Finding]) -> None:
    _DIGEST_SIZES = {"sha256": 64, "md5": 32}

    for fp in workspace.manifest.fingerprints:
        if fp.length <= 0:
            findings.append(
                Finding(
                    "error",
                    f"Fingerprint '{fp.name}' has an invalid length {fp.length} (must be > 0)",
                )
            )
            continue

        max_len = _DIGEST_SIZES.get(fp.algorithm)
        if max_len is not None and fp.length > max_len:
            findings.append(
                Finding(
                    "warning",
                    f"Fingerprint '{fp.name}' length {fp.length} exceeds the"
                    f" {fp.algorithm} digest size of {max_len};"
                    f" the full {max_len}-character digest will be used",
                )
            )


def _check_hook_bin_references(workspace: Workspace, findings: list[Finding]) -> None:
    bin_dir = workspace.paths.bin
    for event, entry in _iter_hook_entries(workspace):
        if not entry.strip() or " " in entry or "\t" in entry:
            continue

        bin_path = bin_dir / entry
        if not bin_path.exists():
            findings.append(
                Finding(
                    "warning",
                    f"Hook entry '{entry}' looks like a bin script"
                    f" but 'bin/{entry}' does not exist",
                    fix=Fix(
                        label=f"Remove '{entry}' from {event} hook commands",
                        kind="interactive",
                        apply=lambda p=workspace.paths.manifest, e=event, cmd=entry: (
                            _manifest_remove_hook_command(p, e, cmd)
                        ),
                    ),
                )
            )
        elif not os.access(bin_path, os.X_OK):
            findings.append(
                Finding(
                    "warning",
                    f"Hook script 'bin/{entry}' exists but is not executable",
                    fix=Fix(
                        label=f"Make bin/{entry} executable",
                        kind="auto",
                        apply=lambda p=bin_path: p.chmod(p.stat().st_mode | 0o111),
                    ),
                )
            )


def _check_hook_empty_entries(workspace: Workspace, findings: list[Finding]) -> None:
    for event, entry in _iter_hook_entries(workspace):
        if not entry.strip():
            findings.append(
                Finding(
                    "warning",
                    f"Hook '{event}' contains an empty entry",
                    fix=Fix(
                        label=f"Remove empty entries from {event} hook",
                        kind="auto",
                        apply=lambda p=workspace.paths.manifest, e=event: (
                            _manifest_remove_hook_empty_entries(p, e)
                        ),
                    ),
                )
            )


def _check_hook_duplicates(workspace: Workspace, findings: list[Finding]) -> None:
    for event, groups in _iter_hooks(workspace):
        seen: set[str] = set()
        for group in groups:
            for entry in group.commands:
                if entry in seen:
                    findings.append(
                        Finding(
                            "warning",
                            f"Hook '{event}' has duplicate entry: '{entry}'",
                            fix=Fix(
                                label=f"Deduplicate {event} hook commands",
                                kind="auto",
                                apply=lambda p=workspace.paths.manifest, e=event: (
                                    _manifest_deduplicate_hook_commands(p, e)
                                ),
                            ),
                        )
                    )
                seen.add(entry)


def _check_orphaned_bin_scripts(workspace: Workspace, findings: list[Finding]) -> None:
    bin_dir = workspace.paths.bin
    if not bin_dir.is_dir():
        return

    referenced = {entry for _, entry in _iter_hook_entries(workspace)}
    for script in sorted(bin_dir.iterdir()):
        if script.is_file() and script.name not in referenced:
            findings.append(
                Finding(
                    "warning",
                    f"Script 'bin/{script.name}' is not referenced by any hook",
                    fix=Fix(
                        label=f"Delete unreferenced script bin/{script.name}",
                        kind="interactive",
                        apply=lambda p=script: p.unlink(),
                    ),
                )
            )


def _check_orphaned_assets(workspace: Workspace, findings: list[Finding]) -> None:
    assets_dir = workspace.paths.assets
    if not assets_dir.is_dir():
        return

    referenced = {a.source for a in [*workspace.manifest.links, *workspace.manifest.copies]}
    for asset in sorted(assets_dir.iterdir()):
        if asset.is_file() and asset.name not in referenced:
            findings.append(
                Finding(
                    "warning",
                    f"Asset '{asset.name}' is not referenced by any link or copy",
                    fix=Fix(
                        label=f"Delete unreferenced asset {asset.name}",
                        kind="interactive",
                        apply=lambda p=asset: p.unlink(),
                    ),
                )
            )


def _check_base_branch(workspace: Workspace, findings: list[Finding]) -> None:
    base = workspace.manifest.base_branch
    if not (
        git.local_branch_exists(base, workspace.dir)
        or git.remote_branch_exists(base, workspace.dir)
    ):
        findings.append(
            Finding(
                "warning",
                f"base_branch '{base}' does not resolve to any local or remote ref",
            )
        )


def _check_copy_placeholders(workspace: Workspace, findings: list[Finding]) -> None:
    known = (
        BASE_VAR_KEYS
        | {
            f"GIT_WORKSPACE_VAR_{normalize_variable_name(k)}"
            for k in (workspace.manifest.vars or {})
        }
        | {
            f"{FINGERPRINT_VAR_PREFIX}{normalize_variable_name(fp.name)}"
            for fp in workspace.manifest.fingerprints
        }
    )
    assets_dir = workspace.paths.assets

    for copy in workspace.manifest.copies:
        source = assets_dir / copy.source
        if not source.exists():
            continue

        files = sorted(source.rglob("*")) if source.is_dir() else [source]
        for file in files:
            if not file.is_file():
                continue
            try:
                content = file.read_text(encoding="utf-8")
            except UnicodeDecodeError, OSError:
                continue
            seen: set[str] = set()
            for match in Copier.PLACEHOLDER_RE.finditer(content):
                key = match.group(1)
                if key not in known and key not in seen:
                    seen.add(key)
                    rel = file.relative_to(assets_dir)
                    findings.append(
                        Finding(
                            "warning",
                            f"Copy asset '{rel}' references unknown placeholder '{{{{{key}}}}}'"
                            " (not a base variable or manifest var;"
                            " pass it as a runtime var or add it to [vars])",
                        )
                    )


def _check_stale_worktrees(workspace: Workspace, findings: list[Finding]) -> None:
    try:
        raw_worktrees = git.list_worktrees(workspace.dir)
    except WorktreeListingError:
        return

    for wt in raw_worktrees:
        wt_dir = Path(wt["directory"])
        if not wt_dir.exists():
            findings.append(
                Finding(
                    "warning",
                    f"Worktree for branch '{wt['branch']}' is registered"
                    f" but its directory '{wt_dir}' no longer exists",
                    fix=Fix(
                        label=f"Prune stale worktree registration for '{wt['branch']}'",
                        kind="auto",
                        apply=lambda: git.prune_worktrees(workspace.dir),
                    ),
                )
            )


def _check_hook_unknown_condition_keys(workspace: Workspace, findings: list[Finding]) -> None:
    known_str = ", ".join(sorted(KNOWN_CONDITION_KEYS))
    for event, groups in _iter_hooks(workspace):
        for group in groups:
            if group.conditions is None:
                continue
            for key in group.conditions.unknown_keys:
                findings.append(
                    Finding(
                        "warning",
                        f"Hook '{event}' has unknown condition key '{key}' (known: {known_str})",
                    )
                )


def _check_hook_invalid_glob(workspace: Workspace, findings: list[Finding]) -> None:
    for event, groups in _iter_hooks(workspace):
        for group in groups:
            if group.conditions is None:
                continue
            for attr in ("if_branch_matches", "if_branch_not_matches"):
                pattern = getattr(group.conditions, attr)
                if pattern is None:
                    continue
                try:
                    fnmatch.translate(pattern)
                except Exception:
                    findings.append(
                        Finding(
                            "warning",
                            f"Hook '{event}' condition '{attr}' has invalid glob pattern: {pattern!r}",
                        )
                    )


def _check_hook_empty_groups(workspace: Workspace, findings: list[Finding]) -> None:
    for event, groups in _iter_hooks(workspace):
        for group in groups:
            if not group.commands:
                findings.append(
                    Finding(
                        "warning",
                        f"Hook '{event}' has a group with no commands",
                        fix=Fix(
                            label=f"Remove empty group from {event} hook",
                            kind="auto",
                            apply=lambda p=workspace.paths.manifest, e=event: (
                                _manifest_remove_hook_empty_groups(p, e)
                            ),
                        ),
                    )
                )


def run_checks(workspace: Workspace) -> list[Finding]:
    """
    Run all workspace health checks and return the collected findings.

    :param workspace: The workspace to inspect.
    :returns: List of findings; empty if the workspace is healthy.
    """
    findings: list[Finding] = []

    _check_manifest_parseable(workspace, findings)
    if findings:
        return findings

    _check_manifest_version(workspace.manifest, findings)
    _check_asset_sources_exist(workspace, findings)
    _check_asset_target_clashes(workspace, findings)
    _check_asset_target_escapes(workspace, findings)
    _check_var_normalization_clashes(workspace, findings)
    _check_fingerprint_name_clashes(workspace, findings)
    _check_fingerprint_name_var_clashes(workspace, findings)
    _check_fingerprint_empty_name(workspace, findings)
    _check_fingerprint_files(workspace, findings)
    _check_fingerprint_algorithm(workspace, findings)
    _check_fingerprint_length(workspace, findings)
    _check_hook_bin_references(workspace, findings)
    _check_hook_empty_entries(workspace, findings)
    _check_hook_duplicates(workspace, findings)
    _check_hook_unknown_condition_keys(workspace, findings)
    _check_hook_invalid_glob(workspace, findings)
    _check_hook_empty_groups(workspace, findings)
    _check_orphaned_bin_scripts(workspace, findings)
    _check_orphaned_assets(workspace, findings)
    _check_copy_placeholders(workspace, findings)
    _check_base_branch(workspace, findings)
    _check_stale_worktrees(workspace, findings)

    return findings
