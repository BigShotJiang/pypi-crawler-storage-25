from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Command:
    name: str
    url: str = "remote"
    api_version: str = "v1"
    fallback: Command | None = None

    def __repr__(self):
        return self.name


COMMAND_ENGINE_ON = Command(name="REON")
COMMAND_ENGINE_OFF = Command(name="REOFF")
COMMAND_COMFORT_ON = Command(name="ROCOMFORTON", api_version="v2")
COMMAND_COMFORT_OFF = Command(name="ROCOMFORTOFF", api_version="v2")
COMMAND_HVAC_ON = Command(name="ROHVACON", api_version="v2")
COMMAND_HVAC_OFF = Command(name="ROHVACOFF", api_version="v2")
COMMAND_PRECOND_ON = Command(name="ROPRECOND")
COMMAND_PRECOND_OFF = Command(name="ROPRECOND_OFF")
COMMAND_LIGHTS_HORN = Command(name="HBLF")
COMMAND_LIGHTS = Command(name="ROLIGHTS")
COMMAND_DOORS_UNLOCK = Command(name="RDU")
COMMAND_DOORS_LOCK = Command(name="RDL")
COMMAND_TRUNK_UNLOCK = Command(name="ROTRUNKUNLOCK", api_version="v2")
COMMAND_TRUNK_LOCK = Command(name="ROTRUNKLOCK", api_version="v2")
COMMAND_LIFTGATE_UNLOCK = Command(name="ROLIFTGATEUNLOCK", api_version="v2")
COMMAND_LIFTGATE_LOCK = Command(name="ROLIFTGATELOCK", api_version="v2")
COMMAND_CABIN_VENTILATION = Command(name="ACV", api_version="v2")
COMMAND_HVAC_TARGET_TEMP = Command(name="ROHVACTMP", api_version="v2")

COMMAND_DEEP_REFRESH_V2 = Command(name="DEEPREFRESH2", url="ev", api_version="v2")
COMMAND_DEEP_REFRESH = Command(
    name="DEEPREFRESH",
    url="ev",
    fallback=COMMAND_DEEP_REFRESH_V2,
)

COMMAND_CHARGE_V4 = Command(
    name="START_CHARGE",
    url="ev/chargenow",
    api_version="v4",
)
COMMAND_CHARGE = Command(
    name="CNOW",
    url="ev/chargenow",
    fallback=COMMAND_CHARGE_V4,
)

COMMAND_REFRESH_LOCATION = Command(name="VF", url="location")

COMMANDS = [
    COMMAND_ENGINE_ON,
    COMMAND_ENGINE_OFF,
    COMMAND_COMFORT_ON,
    COMMAND_COMFORT_OFF,
    COMMAND_HVAC_ON,
    COMMAND_HVAC_OFF,
    COMMAND_PRECOND_ON,
    COMMAND_PRECOND_OFF,
    COMMAND_LIGHTS_HORN,
    COMMAND_LIGHTS,
    COMMAND_DOORS_UNLOCK,
    COMMAND_DOORS_LOCK,
    COMMAND_TRUNK_UNLOCK,
    COMMAND_TRUNK_LOCK,
    COMMAND_LIFTGATE_UNLOCK,
    COMMAND_LIFTGATE_LOCK,
    COMMAND_CABIN_VENTILATION,
    COMMAND_HVAC_TARGET_TEMP,
    COMMAND_CHARGE,
    COMMAND_CHARGE_V4,
    COMMAND_DEEP_REFRESH,
    COMMAND_DEEP_REFRESH_V2,
    COMMAND_REFRESH_LOCATION,
]

COMMANDS_BY_NAME = {x.name: x for x in COMMANDS}
