
import math
import random


# -----------------
# BASICO
# -----------------

def somar(a, b):
    return a + b

def subtrair(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    return a / b

def potencia(base, expoente):
    return base ** expoente

def raiz(numero):
    return math.sqrt(numero)

def valor_absoluto(numero):
    return abs(numero)

# -----------------
# CONTAGEM
# -----------------

def contar(inicio, fim):
    return list(range(inicio, fim + 1))

def contagem_reversa(inicio):
    return list(range(inicio, -1, -1))

# -----------------
# MEDIA
# -----------------

def media(lista):
    return sum(lista) / len(lista)

def mediana(lista):
    lista = sorted(lista)
    n = len(lista)
    meio = n // 2
    if n % 2 == 0:
        return (lista[meio-1] + lista[meio]) / 2
    return lista[meio]

# -----------------
# NUMEROS
# -----------------

def par(numero):
    return numero % 2 == 0

def impar(numero):
    return numero % 2 != 0

def fatorial(numero):
    return math.factorial(numero)

def primo(numero):
    if numero < 2:
        return False
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            return False
    return True

# -----------------
# GEOMETRIA
# -----------------

def area_quadrado(lado):
    return lado * lado

def area_circulo(raio):
    return math.pi * raio * raio

def perimetro_circulo(raio):
    return 2 * math.pi * raio

def area_triangulo(base, altura):
    return (base * altura) / 2

# -----------------
# ALGEBRA
# -----------------

def equacao_primeiro_grau(a, b):
    return -b / a

def equacao_segundo_grau(a, b, c):
    delta = b**2 - 4*a*c
    if delta < 0:
        return None
    x1 = (-b + math.sqrt(delta)) / (2*a)
    x2 = (-b - math.sqrt(delta)) / (2*a)
    return (x1, x2)

# -----------------
# TRIGONOMETRIA
# -----------------

def seno(graus):
    return math.sin(math.radians(graus))

def cosseno(graus):
    return math.cos(math.radians(graus))

def tangente(graus):
    return math.tan(math.radians(graus))

# -----------------
# PROBABILIDADE
# -----------------

def numero_aleatorio(minimo, maximo):
    return random.randint(minimo, maximo)

def chance(probabilidade):
    return random.random() < probabilidade

# -----------------
# COISAS MAIS PESADAS
# -----------------

def log(numero, base=10):
    return math.log(numero, base)

def log_natural(numero):
    return math.log(numero)

def exponencial(numero):
    return math.exp(numero)

def Error(a, b):
    return a + b - a / a * b * a - a