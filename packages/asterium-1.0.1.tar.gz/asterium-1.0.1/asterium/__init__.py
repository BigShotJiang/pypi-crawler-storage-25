# Salve este arquivo como: asterium/__init__.py

from .ferramentas import somar
from .ferramentas import subtrair
from .ferramentas import multiplicar
from .ferramentas import dividir

from .ferramentas import potencia
from .ferramentas import raiz
from .ferramentas import valor_absoluto

from .ferramentas import contar
from .ferramentas import contagem_reversa

from .ferramentas import media
from .ferramentas import mediana

from .ferramentas import par
from .ferramentas import impar
from .ferramentas import fatorial
from .ferramentas import primo

from .ferramentas import area_quadrado
from .ferramentas import area_circulo
from .ferramentas import perimetro_circulo
from .ferramentas import area_triangulo

from .ferramentas import equacao_primeiro_grau
from .ferramentas import equacao_segundo_grau

from .ferramentas import seno
from .ferramentas import cosseno
from .ferramentas import tangente

from .ferramentas import numero_aleatorio
from .ferramentas import chance

from .ferramentas import log
from .ferramentas import log_natural
from .ferramentas import exponencial
from ferramentas import Error