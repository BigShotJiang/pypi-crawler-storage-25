import tkinter as tk
from tkinter import filedialog
import os
import webbrowser
import asterium

# Cria janela
root = tk.Tk()
root.title("MiniTube Desktop")
root.geometry("900x500")
root.configure(bg="#0f0f0f")

# Lista de vídeos
video_list = [f for f in os.listdir() if f.endswith(".mp4")]

# Layout
frame_left = tk.Frame(root, bg="#0f0f0f")
frame_left.pack(side="left", fill="both", expand=True)

frame_right = tk.Frame(root, bg="#181818", width=250)
frame_right.pack(side="right", fill="y")

label = tk.Label(frame_left, text="Selecione um vídeo", fg="white", bg="#0f0f0f", font=("Arial", 18))
label.pack(pady=20)

# Função para abrir vídeo
def play(video):
    label.config(text=video)
    webbrowser.open(video)

# Lista lateral
for video in video_list:
    btn = tk.Button(frame_right, text=video,
                    bg="#242424", fg="white",
                    relief="flat",
                    command=lambda v=video: play(v))
    btn.pack(fill="x", pady=2)

root.mainloop()