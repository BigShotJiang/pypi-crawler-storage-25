# Salve como: setup.py
from setuptools import setup

setup(
    name="asterium",
    version="1.0.1",
    description="Biblioteca completa de ferramentas matemáticas.",
    author="Max",
    # AQUI ESTÁ A CORREÇÃO: Forçamos o instalador a pegar APENAS a pasta asterium
    packages=["asterium"], 
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)