"""Tests for browser fetch tool."""

from __future__ import annotations

import pytest

from www_search_mcp.browser import ensure_browser
from www_search_mcp.tools.web_fetch_browser import web_fetch_browser


@pytest.mark.asyncio
class TestWebFetchBrowser:
    async def test_browser_fetch_example(self):
        result = await web_fetch_browser("https://example.com")
        assert result["status"] == "ok"
        assert result["http_status"] == 200
        assert result.get("title") == "Example Domain" or result.get("title") is None

    async def test_browser_cache(self):
        await web_fetch_browser("https://example.com")
        result = await web_fetch_browser("https://example.com")
        assert result["status"] == "ok"

    async def test_browser_created(self):
        browser = await ensure_browser(headless=True)
        assert browser.is_connected()

    async def test_browser_fetch_includes_content_type(self):
        result = await web_fetch_browser("https://example.com")
        assert result["status"] == "ok"
        assert "content_type" in result
        assert "text/html" in result["content_type"]


@pytest.mark.asyncio
class TestBrowserLifecycle:
    async def test_browser_created(self):
        browser = await ensure_browser(headless=True)
        assert browser.is_connected()

    async def test_browser_reused_when_same_headless(self):
        b1 = await ensure_browser(headless=True)
        b2 = await ensure_browser(headless=True)
        assert b1 is b2


@pytest.mark.asyncio
class TestBrowserContextInvalidation:
    async def test_context_not_returned_when_browser_disconnected(self, monkeypatch):
        from www_search_mcp import browser as b
        from www_search_mcp.browser import ensure_browser_context

        await ensure_browser(headless=True)
        assert b._browser is not None
        ctx1 = await b._browser.new_context()
        b._browser_context = ctx1
        assert b._browser_context is ctx1
        monkeypatch.setattr(b._browser, "is_connected", lambda: False)
        ctx = await ensure_browser_context(headless=True)
        assert ctx is not None
        assert ctx is not ctx1
