"""Tests for server info resource."""

from __future__ import annotations

import asyncio
import json


def test_server_info_resource_is_readable():
    from www_search_mcp.server import create_mcp

    mcp = create_mcp()
    contents = asyncio.run(mcp.read_resource("www-search-mcp://server/info"))
    assert isinstance(contents, list)
    assert contents, "resource must return at least one content part"
    part = contents[0]
    assert hasattr(part, "mime_type")
    assert part.mime_type == "application/json"
    assert hasattr(part, "content")
    assert isinstance(part.content, str)
    payload = json.loads(part.content)
    assert payload["server_name"] == "www-search-mcp"
    assert "server_version" in payload
    assert payload["details_tool"] == "web_mcp_info"
