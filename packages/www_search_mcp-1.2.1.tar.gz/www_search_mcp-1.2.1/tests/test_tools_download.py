"""Tests for download tool."""

from __future__ import annotations

from pathlib import Path

import pytest

from www_search_mcp.tools.web_download import web_download


@pytest.mark.asyncio
class TestWebDownload:
    async def test_download_example(self, tmp_path: Path):
        target = tmp_path / "test.html"
        result = await web_download("https://example.com", str(target))
        assert result["status"] == "downloaded"
        assert result["bytes"] > 0
        assert target.exists()

    async def test_download_too_large(self, monkeypatch):
        monkeypatch.setattr(
            "www_search_mcp.utils.fetch_processing.MAX_DOWNLOAD_BYTES", 10
        )
        result = await web_download("https://example.com", "/tmp/too_large.html")
        assert result["status"] == "error"
        assert "File too large" in result.get("error", "")

    async def test_download_oserror(self, monkeypatch, tmp_path: Path):
        target = tmp_path / "readonly" / "test.html"
        monkeypatch.setattr(
            Path,
            "write_bytes",
            lambda *args, **kwargs: (_ for _ in ()).throw(PermissionError("read-only")),
        )
        result = await web_download("https://example.com", str(target))
        assert result["status"] == "error"
        assert "read-only" in result.get("error", "")
