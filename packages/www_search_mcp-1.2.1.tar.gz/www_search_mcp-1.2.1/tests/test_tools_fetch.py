"""Tests for fetch tool."""

from __future__ import annotations

import time

import pytest

from www_search_mcp.errors import InvalidURLError
from www_search_mcp.tools.web_fetch import web_fetch


@pytest.mark.asyncio
class TestWebFetch:
    async def test_fetch_example_com(self):
        result = await web_fetch("https://example.com")
        assert result["status"] == "ok"
        assert result["http_status"] == 200
        assert "Example Domain" in result["body"]

    async def test_fetch_with_div(self):
        result = await web_fetch("https://example.com", fetch_div="body")
        assert result["status"] == "ok"
        assert "Example Domain" in result["body"]

    async def test_fetch_invalid_url(self):
        with pytest.raises(InvalidURLError):
            await web_fetch("not-a-url")

    async def test_fetch_404(self):
        result = await web_fetch("https://example.com/404-not-found")
        assert result["status"] == "http_error"

    async def test_fetch_extracts_title(self):
        result = await web_fetch("https://example.com")
        assert result["status"] == "ok"
        assert result.get("title") == "Example Domain"

    async def test_fetch_cache(self):
        await web_fetch("https://example.com")
        t0 = time.monotonic()
        result = await web_fetch("https://example.com")
        t1 = time.monotonic()
        assert t1 - t0 < 0.05
        assert result["status"] == "ok"

    async def test_save_file_not_truncated(self, monkeypatch, tmp_path):
        """Regression: save_file must receive the FULL body, not truncated."""
        monkeypatch.setattr("www_search_mcp.utils.fetch_processing.MAX_FETCH_CHARS", 5)
        target = tmp_path / "page.md"
        result = await web_fetch("https://example.com", save_file=str(target))
        assert result["status"] == "ok"
        assert target.exists()
        assert target.stat().st_size > 50
