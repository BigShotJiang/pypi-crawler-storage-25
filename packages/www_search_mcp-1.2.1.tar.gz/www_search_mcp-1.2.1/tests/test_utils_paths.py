"""Tests for path and URL utilities."""

from __future__ import annotations

from pathlib import Path

import pytest

from www_search_mcp.errors import InvalidPathError, InvalidURLError
from www_search_mcp.utils.paths import resolve_path, validate_url


class TestValidateUrl:
    def test_valid_https(self):
        assert validate_url("https://example.com") == "https://example.com"

    def test_valid_http(self):
        assert validate_url("http://example.com") == "http://example.com"

    def test_strips_whitespace(self):
        assert validate_url("  https://example.com  ") == "https://example.com"

    def test_rejects_ftp(self):
        with pytest.raises(InvalidURLError, match="http:// or https://"):
            validate_url("ftp://example.com")

    def test_rejects_empty(self):
        with pytest.raises(InvalidURLError, match="http:// or https://"):
            validate_url("")


class TestResolvePath:
    def test_relative_resolves_to_home(self):
        p = resolve_path("test.txt")
        assert p.is_absolute()
        assert p.name == "test.txt"

    def test_absolute_preserved(self):
        p = resolve_path("/tmp/test.txt")
        assert p == Path("/tmp/test.txt").resolve()

    def test_rejects_no_extension(self):
        with pytest.raises(InvalidPathError, match="file extension"):
            resolve_path("/tmp/noextension")

    def test_rejects_path_traversal(self):
        with pytest.raises(InvalidPathError, match="path traversal"):
            resolve_path(str(Path.home() / ".." / "etc" / "passwd.txt"))
