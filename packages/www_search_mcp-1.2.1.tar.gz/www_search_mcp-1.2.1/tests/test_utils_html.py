"""Tests for HTML processing utilities."""

from __future__ import annotations

from www_search_mcp.utils.html import clip_text, html_to_markdown


class TestHtmlToMarkdown:
    def test_basic_conversion(self):
        md, title = html_to_markdown("<h1>Title</h1><p>Paragraph</p>")
        assert "# Title" in md
        assert "Paragraph" in md
        assert title == ""

    def test_noise_tags_removed(self):
        md, _ = html_to_markdown("<script>alert(1)</script><p>Keep me</p>")
        assert "alert" not in md
        assert "Keep me" in md

    def test_layout_tags_removed(self):
        md, _ = html_to_markdown("<nav>Nav</nav><p>Content</p>")
        assert "Nav" not in md
        assert "Content" in md

    def test_selector_extraction(self):
        html = "<div class='content'><p>Inside</p></div><footer>Out</footer>"
        md, _ = html_to_markdown(html, selector=".content")
        assert "Inside" in md
        assert "Out" not in md

    def test_invalid_selector_fallback(self):
        md, _ = html_to_markdown("<p>Body</p>", selector="[[bad")
        assert "Body" in md

    def test_broken_html_fallback(self):
        result, _ = html_to_markdown("<<<>>>not valid<<<")
        assert isinstance(result, str)

    def test_title_extracted(self):
        _, title = html_to_markdown(
            "<html><head><title>My Page</title></head><body><p>Hi</p></body></html>"
        )
        assert title == "My Page"


class TestClipText:
    def test_no_clip(self):
        clipped, truncated = clip_text("short", 100)
        assert clipped == "short"
        assert truncated is False

    def test_clip(self):
        clipped, truncated = clip_text("1234567890", 5)
        assert len(clipped) == 5
        assert truncated is True
