"""Tests for config/proxy handling."""

from __future__ import annotations


class TestProxyConfig:
    def test_proxy_env_read(self, monkeypatch):
        monkeypatch.setattr(
            "www_search_mcp.config.PROXY", "http://proxy.example.com:8080"
        )
        from www_search_mcp import config

        assert config.PROXY == "http://proxy.example.com:8080"

    def test_proxy_env_empty(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.PROXY", None)
        from www_search_mcp import config

        assert config.PROXY is None
