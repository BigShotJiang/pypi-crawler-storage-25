"""Shared pytest fixtures for www_search_mcp."""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from www_search_mcp.browser import close_all
from www_search_mcp.utils.cache import fetch_cache, search_cache
from www_search_mcp.utils.session_state import aclose_all_sessions
from www_search_mcp.utils.throttle import request_throttle


@pytest.fixture(autouse=True)
def reset_global_state(monkeypatch):
    """Reset shared mutable state before each test."""
    fetch_cache.clear()
    search_cache.clear()
    request_throttle.reset()
    yield
    fetch_cache.clear()
    search_cache.clear()


@pytest.fixture(autouse=True)
async def cleanup_http_async():
    """Close per-session HTTP clients after each test."""
    yield
    await aclose_all_sessions()


@pytest.fixture(autouse=True)
async def cleanup_browser():
    """Close Playwright browser after each async test."""
    yield
    from www_search_mcp import browser as b

    b._browser_context = None
    await close_all()


@pytest.fixture()
def local_api_server(monkeypatch):
    """Local HTTP server for deterministic API/tool tests.

    Avoids reliance on external network in CI.
    """

    # Ensure localhost does not go through a corporate proxy.
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    monkeypatch.setenv("no_proxy", "127.0.0.1,localhost")
    for key in (
        "HTTP_PROXY",
        "http_proxy",
        "HTTPS_PROXY",
        "https_proxy",
        "ALL_PROXY",
        "all_proxy",
    ):
        monkeypatch.delenv(key, raising=False)

    class Handler(BaseHTTPRequestHandler):
        server_version = "TestHTTP/1.0"

        def _send_json(self, payload: dict) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:  # noqa: N802
            if self.path.startswith("/headers"):
                # Normalize header casing for assertions.
                headers = {k: v for k, v in self.headers.items()}
                return self._send_json({"headers": headers})
            return self._send_json({"ok": True, "path": self.path})

        def do_POST(self) -> None:  # noqa: N802
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            try:
                data = json.loads(raw.decode("utf-8") or "{}")
            except Exception:
                data = {"raw": raw.decode("utf-8", errors="replace")}

            if self.path.startswith("/rest"):
                return self._send_json({"json": data})

            if self.path.startswith("/graphql"):
                # Minimal GraphQL-like response.
                op = data.get("operationName")
                if op:
                    return self._send_json({"data": {"operationName": op}})
                return self._send_json({"data": {"__typename": "Query"}})

            return self._send_json({"json": data})

        def log_message(self, format: str, *args) -> None:  # noqa: A002
            # Silence server logs in tests.
            return

    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    host, port = httpd.server_address  # type: ignore
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()

    try:
        yield f"http://{host}:{port}"
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=2)
