"""Tests for shared vs ephemeral HTTP session behavior."""

from __future__ import annotations

import niquests
import pytest
from pathlib import Path

from www_search_mcp.tools.web_download import web_download
from www_search_mcp.tools.web_fetch import web_fetch


def _track_client_inits(monkeypatch):
    created: list[int] = []
    original_init = niquests.AsyncSession.__init__

    def tracking_init(self, *args, **kwargs):
        created.append(1)
        return original_init(self, *args, **kwargs)

    monkeypatch.setattr(niquests.AsyncSession, "__init__", tracking_init)
    return created


@pytest.mark.asyncio
class TestHttpSession:
    async def test_fetch_without_session_creates_new_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.SESSION_ENABLED", False)
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=False)
        assert result["status"] == "ok"
        assert len(created) >= 1

    async def test_fetch_with_session_uses_shared_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.SESSION_ENABLED", True)
        created = _track_client_inits(monkeypatch)
        result = await web_fetch("https://example.com", use_session=True)
        assert result["status"] == "ok"
        first_count = len(created)
        result2 = await web_fetch("https://example.com", use_session=True)
        assert result2["status"] == "ok"
        assert len(created) == first_count


@pytest.mark.asyncio
class TestWebDownloadSession:
    async def test_download_without_session_creates_new_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.SESSION_ENABLED", False)
        created = _track_client_inits(monkeypatch)
        tmp = Path("/tmp/test_download_session.html")
        result = await web_download("https://example.com", str(tmp), use_session=False)
        assert result["status"] == "downloaded"
        assert len(created) >= 1

    async def test_download_with_session_uses_shared_client(self, monkeypatch):
        monkeypatch.setattr("www_search_mcp.config.SESSION_ENABLED", True)
        from www_search_mcp.utils.session_state import get_http_session

        tmp = Path("/tmp/test_download_shared.html")
        result = await web_download("https://example.com", str(tmp), use_session=True)
        assert result["status"] == "downloaded"
        client1 = await get_http_session(None)

        result2 = await web_download("https://example.com", str(tmp), use_session=True)
        assert result2["status"] == "downloaded"
        client2 = await get_http_session(None)
        assert client1 is client2
