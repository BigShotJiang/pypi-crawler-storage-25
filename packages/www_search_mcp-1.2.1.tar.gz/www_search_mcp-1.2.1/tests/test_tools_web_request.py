"""Tests for the web_request tool."""

from __future__ import annotations

import pytest

from www_search_mcp.errors import ValidationError
from www_search_mcp.tools.web_request import web_request


@pytest.mark.asyncio
class TestWebRequest:
    async def test_rest_post_json_body(self, local_api_server):
        r = await web_request(
            {
                "type": "rest",
                "method": "POST",
                "url": f"{local_api_server}/rest",
                "headers": {},
                "body": {"hello": "world"},
                "requests": 1,
                "concurrency": 1,
                "time": 0,
            }
        )
        assert r["status"] == "ok"
        assert r["http_status_counts"].get(200) == 1
        assert "response_samples" in r
        import json

        payload = json.loads(r["response_samples"][0])
        assert payload["json"]["hello"] == "world"

    async def test_graphql_query_field(self, local_api_server):
        r = await web_request(
            {
                "type": "graphql",
                "method": "POST",
                "url": f"{local_api_server}/graphql",
                "query": "{ __typename }",
                "requests": 1,
                "concurrency": 1,
                "time": 0,
            }
        )
        assert r["status"] == "ok"
        assert r["http_status_counts"].get(200) == 1
        assert "response_samples" in r
        assert "__typename" in r["response_samples"][0]

    async def test_graphql_operation_name(self, local_api_server):
        r = await web_request(
            {
                "type": "graphql",
                "method": "POST",
                "url": f"{local_api_server}/graphql",
                "query": "query A{__typename} query B{__typename}",
                "operationName": "B",
                "requests": 1,
                "concurrency": 1,
                "time": 0,
            }
        )
        assert r["status"] == "ok"
        assert r["http_status_counts"].get(200) == 1

    async def test_response_samples_only_for_small_runs(self, local_api_server):
        r = await web_request(
            {
                "type": "rest",
                "method": "GET",
                "url": f"{local_api_server}/rest",
                "requests": 2,
                "concurrency": 2,
                "time": 0,
            }
        )
        assert r["total_requests"] == 4
        assert "response_samples" not in r

    async def test_threads_rejected(self, local_api_server):
        with pytest.raises(ValidationError, match="use concurrency"):
            await web_request(
                {
                    "type": "rest",
                    "method": "GET",
                    "url": f"{local_api_server}/rest",
                    "threads": 1,
                }
            )

    async def test_graphql_fields_rejected_for_rest(self):
        with pytest.raises(ValidationError, match="only valid when type=graphql"):
            await web_request(
                {
                    "type": "rest",
                    "method": "GET",
                    "url": "https://example.com",
                    "query": "{ __typename }",
                }
            )

    async def test_request_token_injected_as_authorization(
        self, monkeypatch, local_api_server
    ):
        # web_request imports REQUEST_TOKEN at module import-time.
        import importlib

        wr = importlib.import_module("www_search_mcp.tools.web_request")
        monkeypatch.setattr(wr, "REQUEST_TOKEN", "testtoken")
        r = await web_request(
            {
                "type": "rest",
                "method": "GET",
                "url": f"{local_api_server}/headers",
                "headers": {},
                "requests": 1,
                "concurrency": 1,
                "time": 0,
            }
        )
        assert r["http_status_counts"].get(200) == 1
        import json

        sample = json.loads(r["response_samples"][0])
        assert sample["headers"].get("Authorization") == "Bearer testtoken"
