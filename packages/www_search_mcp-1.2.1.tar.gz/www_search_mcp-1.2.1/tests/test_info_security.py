"""Tests for info reporting (no secret leakage)."""

from __future__ import annotations


def test_web_request_token_not_leaked(monkeypatch):
    monkeypatch.setenv("WEB_REQUEST_TOKEN", "super-secret")
    # Reloading config is intentionally avoided; info.py reads env directly for current values.
    from www_search_mcp.info import get_server_info

    info = get_server_info()
    env = info["environment_variables"]
    assert "WEB_REQUEST_TOKEN" in env
    assert env["WEB_REQUEST_TOKEN"]["current"] == "set"
    # Ensure the actual secret value does not appear anywhere in the report.
    assert "super-secret" not in str(info)
