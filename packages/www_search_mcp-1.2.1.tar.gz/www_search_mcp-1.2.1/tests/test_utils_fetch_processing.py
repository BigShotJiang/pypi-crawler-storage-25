"""Tests for fetch processing helpers."""

from __future__ import annotations

from www_search_mcp.utils.fetch_processing import build_fetch_result


class TestBuildFetchResult:
    def test_ok_status(self):
        r = build_fetch_result("body", 200, "https://example.com")
        assert r["status"] == "ok"
        assert r["http_status"] == 200

    def test_error_status(self):
        r = build_fetch_result("err", 500, "https://example.com")
        assert r["status"] == "http_error"

    def test_optional_fields(self):
        r = build_fetch_result("b", 200, "url", content_type="text/html", title="T")
        assert r["title"] == "T"
        assert r["content_type"] == "text/html"
