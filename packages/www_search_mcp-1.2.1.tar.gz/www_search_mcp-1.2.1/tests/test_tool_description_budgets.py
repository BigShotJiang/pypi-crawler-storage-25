"""Guardrails: keep tool descriptions reasonably small.

Large descriptions bloat the tool list (context) and can cause truncation.
We enforce per-tool limits here, instead of a single global budget.
"""

from __future__ import annotations


def test_tool_description_budgets():
    from www_search_mcp.info import TOOL_INSTRUCTIONS

    # Per-tool character budgets for TOOL_INSTRUCTIONS[tool]["description"].
    # These are intentionally conservative. If a tool needs more detail, move it
    # into web_mcp_info's structured output rather than the tool description.
    budgets: dict[str, int] = {
        "web_search": 450,
        "web_search_images": 420,
        "web_search_github": 420,
        "web_search_pypi": 480,
        "web_fetch": 560,
        "web_fetch_browser": 420,
        "web_download": 360,
        "web_request": 520,
        "web_mcp_info": 220,
    }

    failures: list[str] = []
    for name, meta in TOOL_INSTRUCTIONS.items():
        desc = str(meta.get("description") or "")
        limit = budgets.get(name, 450)
        if len(desc) > limit:
            failures.append(
                f"{name}: {len(desc)} chars > {limit} (trim by {len(desc) - limit})"
            )

    assert not failures, "Tool description budgets exceeded:\n" + "\n".join(failures)
