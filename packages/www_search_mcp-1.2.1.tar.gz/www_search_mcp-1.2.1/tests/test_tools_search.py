"""Tests for search tools."""

from __future__ import annotations

import uuid

import pytest

from www_search_mcp.errors import ValidationError
from www_search_mcp.tools.web_search import web_search
from www_search_mcp.tools.web_search_images import web_search_images
from www_search_mcp.tools.web_search_pypi import web_search_pypi


class TestWebSearchPyPI:
    @pytest.mark.asyncio
    async def test_pypi_search_returns_results(self):
        result = await web_search_pypi("httpx", max_results=3)
        assert result["status"] in ("ok", "no_results")
        assert result["result_count"] <= 3
        if result["result_count"] > 0:
            first = result["results"][0]
            assert "name" in first
            assert "version" in first
            assert "summary" in first
            assert "url" in first

    @pytest.mark.asyncio
    async def test_pypi_search_cache(self):
        query = f"cache-test-pypi-{uuid.uuid4().hex[:8]}"
        result1 = await web_search_pypi(query, max_results=2)
        result2 = await web_search_pypi(query, max_results=2)
        assert result1 == result2

    def test_empty_query_raises(self):
        with pytest.raises(ValidationError):
            import asyncio

            asyncio.run(web_search_pypi("   "))


class TestWebSearch:
    @pytest.mark.asyncio
    async def test_search_returns_results(self):
        result = await web_search("python programming", max_results=3)
        assert result["status"] == "ok"
        assert result["result_count"] <= 3
        assert result["result_count"] > 0
        first = result["results"][0]
        assert "title" in first
        assert "url" in first

    @pytest.mark.asyncio
    async def test_empty_query_raises(self):
        with pytest.raises(ValidationError):
            await web_search("   ")

    @pytest.mark.asyncio
    async def test_no_results_structure(self):
        query = f"no-results-{uuid.uuid4().hex}"
        result = await web_search(query, max_results=5)
        assert result["status"] in ("ok", "no_results")
        assert isinstance(result["result_count"], int)


class TestWebSearchImages:
    @pytest.mark.asyncio
    async def test_image_search_returns_results(self):
        result = await web_search_images("cat", max_results=3)
        assert result["status"] in ("ok", "no_results")
        assert result["result_count"] <= 3
        if result["result_count"] > 0:
            first = result["results"][0]
            assert "title" in first
            assert "image" in first
            assert "url" in first
            assert "thumbnail" in first

    @pytest.mark.asyncio
    async def test_empty_query_raises(self):
        with pytest.raises(ValidationError):
            await web_search_images("   ")

    @pytest.mark.asyncio
    async def test_image_search_cache(self):
        query = f"cache-test-{uuid.uuid4().hex}"
        result1 = await web_search_images(query, max_results=2)
        result2 = await web_search_images(query, max_results=2)
        assert result1 == result2
