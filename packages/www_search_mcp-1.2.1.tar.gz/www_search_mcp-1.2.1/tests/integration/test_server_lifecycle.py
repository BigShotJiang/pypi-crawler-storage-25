"""Integration tests: server lifecycle (shutdown)."""

from __future__ import annotations

import asyncio
import json
import os
import shutil

import pytest

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio,
    pytest.mark.xdist_group("integration"),
]

WWW_SEARCH_MCP_CMD = shutil.which("www-search-mcp")


class TestServerLifecycle:
    async def test_session_reuse_with_enabled(self) -> None:
        from tests.integration.conftest import mcp_client

        async with mcp_client() as client:
            # First fetch with use_session=true
            r1 = await client.call_tool(
                "web_fetch",
                arguments={"urls": "https://example.com", "use_session": True},
            )
            assert not r1.isError
            # Second fetch should reuse the same underlying session
            r2 = await client.call_tool(
                "web_fetch",
                arguments={"urls": "https://example.com", "use_session": True},
            )
            assert not r2.isError
            payload1 = json.loads(r1.content[0].text)
            payload2 = json.loads(r2.content[0].text)
            assert payload1["status"] == "ok"
            assert payload2["status"] == "ok"

    async def test_cache_hit_on_second_call(self) -> None:
        from tests.integration.conftest import mcp_client

        async with mcp_client() as client:
            r1 = await client.call_tool(
                "web_search",
                arguments={"queries": "python", "max_results": 2},
            )
            assert not r1.isError
            payload1 = json.loads(r1.content[0].text)
            # Second identical call should also succeed (may be cached)
            r2 = await client.call_tool(
                "web_search",
                arguments={"queries": "python", "max_results": 2},
            )
            assert not r2.isError
            payload2 = json.loads(r2.content[0].text)
            assert payload1["status"] == payload2["status"] == "ok"

    async def test_cleanup_closes_sessions(self) -> None:
        if not WWW_SEARCH_MCP_CMD:
            pytest.skip("www-search-mcp not installed")

        import socket

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            port = int(s.getsockname()[1])

        proc = await asyncio.create_subprocess_exec(
            WWW_SEARCH_MCP_CMD,
            env={
                **os.environ,
                "WEB_DEBUG": "1",
                "WEB_DNS_RESOLVER": "google",
                "WEB_TRANSPORT": "streamable-http",
                "WEB_HTTP_HOST": "127.0.0.1",
                "WEB_HTTP_PORT": str(port),
            },
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await asyncio.sleep(1.5)
        proc.terminate()
        try:
            returncode = await asyncio.wait_for(proc.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            proc.kill()
            returncode = await proc.wait()

        assert returncode in (0, -15)
        assert proc.stderr is not None
        stderr = (await proc.stderr.read()).decode("utf-8", errors="replace")
        # Should mention shutdown and ideally session cleanup.
        assert "Shutting down" in stderr or returncode == 0

    async def test_graceful_shutdown_on_sigterm(self) -> None:
        if not WWW_SEARCH_MCP_CMD:
            pytest.skip("www-search-mcp not installed")

        import socket

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            port = int(s.getsockname()[1])

        proc = await asyncio.create_subprocess_exec(
            WWW_SEARCH_MCP_CMD,
            env={
                **os.environ,
                "WEB_DEBUG": "1",
                "WEB_DNS_RESOLVER": "google",
                "WEB_TRANSPORT": "streamable-http",
                "WEB_HTTP_HOST": "127.0.0.1",
                "WEB_HTTP_PORT": str(port),
            },
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Let it start up
        await asyncio.sleep(1.5)

        proc.terminate()
        try:
            returncode = await asyncio.wait_for(proc.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            proc.kill()
            returncode = await proc.wait()

        assert returncode in (0, -15)  # 0 = clean, -15 = SIGTERM

        # Verify shutdown message in stderr
        assert proc.stderr is not None
        stderr = (await proc.stderr.read()).decode("utf-8", errors="replace")
        assert "Shutting down" in stderr or returncode == 0
