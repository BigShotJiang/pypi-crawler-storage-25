"""Integration tests: stdio transport initialization and tool discovery."""

from __future__ import annotations

import json

import pytest

from tests.integration.conftest import mcp_client

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio,
    pytest.mark.xdist_group("integration"),
]

EXPECTED_TOOL_NAMES = {
    "web_search",
    "web_search_images",
    "web_search_github",
    "web_search_pypi",
    "web_fetch",
    "web_fetch_browser",
    "web_download",
    "web_request",
    "web_mcp_info",
    "web_mcp_status",
}


class TestStdioTransport:
    async def test_initialize_ok(self) -> None:
        """Initialization happens in the fixture; reaching here means success."""
        async with mcp_client() as client:
            assert client is not None

    async def test_list_tools_returns_ten(self) -> None:
        async with mcp_client() as client:
            result = await client.list_tools()
            assert len(result.tools) == 10

    async def test_tool_names_match_expected(self) -> None:
        async with mcp_client() as client:
            result = await client.list_tools()
            names = {t.name for t in result.tools}
            assert names == EXPECTED_TOOL_NAMES

    async def test_tool_descriptions_not_empty(self) -> None:
        async with mcp_client() as client:
            result = await client.list_tools()
            for tool in result.tools:
                assert tool.description, f"Tool {tool.name!r} has empty description"

    async def test_tool_annotations_present(self) -> None:
        async with mcp_client() as client:
            result = await client.list_tools()
            for tool in result.tools:
                assert hasattr(tool, "annotations")
                assert tool.annotations is not None
                assert hasattr(tool.annotations, "readOnlyHint")
                assert hasattr(tool.annotations, "openWorldHint")

    async def test_read_server_info_resource(self) -> None:
        async with mcp_client() as client:
            resource = await client.read_resource("www-search-mcp://server/info")
            assert resource.contents
            part = resource.contents[0]
            assert part.mimeType == "application/json"
            payload = json.loads(part.text)
            assert payload["server_name"] == "www-search-mcp"
            assert payload["tool_count"] == 10
            assert payload["details_tool"] == "web_mcp_info"
