"""Integration tests: custom HTTP routes via niquests."""

from __future__ import annotations

import pytest

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio,
    pytest.mark.xdist_group("integration"),
]


class TestCustomRoutes:
    async def test_healthz_returns_ok(self, http_server: str, http_session) -> None:
        resp = await http_session.get(f"{http_server}/healthz")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"

    async def test_readyz_returns_status(self, http_server: str, http_session) -> None:
        resp = await http_session.get(f"{http_server}/readyz")
        assert resp.status_code in (200, 503)
        data = resp.json()
        assert data["status"] == "ok"
        assert "readyz" in data
        assert data["readyz"]["status"] in ("ready", "degraded")
        assert "checks" in data["readyz"]
        for check in ("dns", "ddgs", "playwright"):
            assert check in data["readyz"]["checks"]

    async def test_error_types_returns_hierarchy(
        self, http_server: str, http_session
    ) -> None:
        resp = await http_session.get(f"{http_server}/error-types")
        assert resp.status_code == 200
        data = resp.json()
        # Spot-check a few known error types
        assert any("TimeoutError" in k or "NetworkTimeoutError" in k for k in data)
        for name, info in data.items():
            assert "parent" in info
            assert "retryable" in info
            assert "suggested_action" in info

    async def test_custom_routes_not_in_schema(
        self, http_server: str, http_session
    ) -> None:
        # FastMCP/Starlette does not expose OpenAPI by default, so we verify
        # the custom routes are not mixed into the MCP message endpoint.
        resp = await http_session.get(f"{http_server}/healthz")
        assert resp.status_code == 200
        # The MCP endpoint should be separate and respond differently.
        resp_mcp = await http_session.get(f"{http_server}/mcp", allow_redirects=False)
        # MCP endpoint typically requires POST; GET may 405 or 406.
        assert resp_mcp.status_code in (200, 301, 302, 404, 405, 406)
