"""Shared helpers for MCP integration tests.

We do **not** use async-generator fixtures for the stdio client because
pytest-asyncio runs the finaliser in a fresh ``asyncio.run()`` call, which
breaks anyio cancel-scopes that were entered in the original loop.
Instead each test opens the client explicitly with ``async with mcp_client()``.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import socket
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import pytest
import pytest_asyncio

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

WWW_SEARCH_MCP_CMD = shutil.which("www-search-mcp")


def _get_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


@asynccontextmanager
async def mcp_client() -> AsyncGenerator:
    """Yield an initialized MCP ClientSession over stdio transport."""
    if not WWW_SEARCH_MCP_CMD:
        pytest.skip("www-search-mcp not installed (run 'uv tool install dist/*.whl')")

    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    params = StdioServerParameters(
        command=WWW_SEARCH_MCP_CMD,
        env={
            **os.environ,
            "WEB_DEBUG": "1",
            "WEB_DNS_RESOLVER": "google",
            "WEB_SESSION_ENABLED": "1",
        },
    )

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            yield session


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def http_server() -> AsyncGenerator[str, None]:
    """Spawn www-search-mcp in streamable-http mode on a free port."""
    if not WWW_SEARCH_MCP_CMD:
        pytest.skip("www-search-mcp not installed")

    port = await asyncio.get_running_loop().run_in_executor(None, _get_free_port)
    env = {
        **os.environ,
        "WEB_TRANSPORT": "streamable-http",
        "WEB_HTTP_HOST": "127.0.0.1",
        "WEB_HTTP_PORT": str(port),
    }

    proc = await asyncio.create_subprocess_exec(
        WWW_SEARCH_MCP_CMD,
        env=env,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )

    # Wait for the HTTP server to come up.
    await asyncio.sleep(1.5)

    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        proc.terminate()
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()


@pytest_asyncio.fixture
async def http_session() -> AsyncGenerator:
    """Yield an ephemeral niquests AsyncSession for route tests."""
    import niquests

    session = niquests.AsyncSession(multiplexed=True, timeout=10)
    try:
        yield session
    finally:
        await session.close()
