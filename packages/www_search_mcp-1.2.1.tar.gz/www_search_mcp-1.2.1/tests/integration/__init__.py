"""Integration tests for www-search-mcp via MCP protocol."""
