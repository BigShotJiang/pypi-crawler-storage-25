"""Integration tests: call every tool through the MCP protocol."""

from __future__ import annotations

import json

import pytest

from tests.integration.conftest import mcp_client

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio,
    pytest.mark.xdist_group("integration"),
]


class TestToolsViaMcp:
    # ------------------------------------------------------------------
    # Search tools
    # ------------------------------------------------------------------

    async def test_web_search_returns_results(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_search",
                arguments={"queries": "python programming", "max_results": 2},
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] == "ok"
            assert payload["result_count"] > 0
            first = payload["results"][0]
            assert "title" in first
            assert "url" in first

    async def test_web_search_images_returns_results(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_search_images",
                arguments={"queries": "python logo", "max_results": 2},
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] in ("ok", "no_results")
            if payload["result_count"] > 0:
                first = payload["results"][0]
                assert "image" in first
                assert "thumbnail" in first

    async def test_web_search_github_returns_results(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_search_github",
                arguments={"queries": "fastapi", "max_results": 2},
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] in ("ok", "no_results")
            if payload["result_count"] > 0:
                first = payload["results"][0]
                assert "stars" in first
                assert "language" in first

    async def test_web_search_pypi_returns_results(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_search_pypi",
                arguments={"queries": "httpx", "max_results": 2},
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] == "ok"
            assert payload["result_count"] > 0
            first = payload["results"][0]
            assert "name" in first
            assert "version" in first
            assert "summary" in first

    # ------------------------------------------------------------------
    # Fetch / request tools
    # ------------------------------------------------------------------

    async def test_web_fetch_returns_markdown(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_fetch",
                arguments={"urls": "https://example.com"},
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] == "ok"
            assert payload["http_status"] == 200
            assert "Example Domain" in payload["body"]

    async def test_web_request_rest_get(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_request",
                arguments={
                    "queries": {
                        "type": "rest",
                        "method": "GET",
                        "url": "https://httpbin.org/get",
                        "requests": 1,
                        "concurrency": 1,
                    }
                },
            )
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] == "ok"
            assert payload["http_status_counts"].get("200") == 1

    # ------------------------------------------------------------------
    # Meta
    # ------------------------------------------------------------------

    async def test_web_mcp_info_returns_server_data(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool("web_mcp_info", arguments={})
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["server_name"] == "www-search-mcp"
            assert isinstance(payload.get("tools"), list)
            assert len(payload["tools"]) == 10

    async def test_web_mcp_status_returns_diagnostics(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool("web_mcp_status", arguments={})
            assert not result.isError
            payload = json.loads(result.content[0].text)
            assert payload["status"] == "ok"
            assert payload["server_name"] == "www-search-mcp"
            assert "uptime_seconds" in payload
            assert "throttle" in payload
            assert "sessions" in payload
            assert "health" in payload

    # ------------------------------------------------------------------
    # Error paths
    # ------------------------------------------------------------------

    async def test_empty_query_returns_error(self) -> None:
        async with mcp_client() as client:
            result = await client.call_tool(
                "web_search",
                arguments={"queries": "   ", "max_results": 2},
            )
            assert result.isError
            assert "queries must not be empty" in result.content[0].text
