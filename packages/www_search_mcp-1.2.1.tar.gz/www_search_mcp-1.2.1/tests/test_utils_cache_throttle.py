"""Tests for cache and throttle utilities."""

from __future__ import annotations

import asyncio
import time

from www_search_mcp.utils.cache import TTLCache
from www_search_mcp.utils.throttle import request_throttle


class TestCache:
    async def test_cache_hit_async(self):
        c = TTLCache(ttl=10, maxsize=10)
        await c.aset("k", {"body": "test"})
        assert await c.aget("k") == {"body": "test"}

    async def test_cache_ttl_expiry(self):
        c = TTLCache(ttl=0.01, maxsize=10)
        await c.aset("k", {"body": "x"})
        await asyncio.sleep(0.02)
        assert await c.aget("k") is None

    async def test_cache_lru_eviction(self):
        c = TTLCache(ttl=10, maxsize=2)
        await c.aset("k1", {"v": 1})
        await c.aset("k2", {"v": 2})
        await c.aset("k3", {"v": 3})
        assert await c.aget("k1") is None
        assert await c.aget("k2") is not None
        assert await c.aget("k3") is not None

    def test_make_key(self):
        k1 = TTLCache.make_key("https://example.com", "", True, 0)
        k2 = TTLCache.make_key("https://example.com", "", False, 0)
        assert k1 != k2

    def test_sync_cache(self):
        c = TTLCache(ttl=10, maxsize=10)
        c.set("k", {"v": 1})
        assert c.get("k") == {"v": 1}


class TestThrottle:
    def test_sync_throttle_delays(self, monkeypatch):
        monkeypatch.setattr(request_throttle, "interval", 0.2)
        request_throttle.reset()
        request_throttle.wait()
        t0 = time.monotonic()
        request_throttle.wait()
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.15

    async def test_async_throttle_delays(self, monkeypatch):
        monkeypatch.setattr(request_throttle, "interval", 0.2)
        request_throttle.reset()
        await request_throttle.await_gap()
        t0 = time.monotonic()
        await request_throttle.await_gap()
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.15
