"""MCP server entry point.

This module should stay small:
- configure logging
- create FastMCP instance
- register tools
- handle shutdown hooks
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import os
import signal
import sys
from typing import Any, Literal, cast

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from .browser import close_all as close_browser
from .errors import WebSearchMCError
from .info import get_mcp_instructions, register_web_mcp_info_tool
from .tools import (
    register_web_download_tool,
    register_web_fetch_browser_tool,
    register_web_fetch_tool,
    register_web_mcp_status_tool,
    register_web_request_tool,
    register_web_search_github_tool,
    register_web_search_images_tool,
    register_web_search_pypi_tool,
    register_web_search_tool,
)
from .utils import aclose_all_sessions


def _env_transport() -> Literal["stdio", "streamable-http"]:
    raw = (os.getenv("WEB_TRANSPORT", "stdio") or "stdio").strip().lower()
    if raw not in {"stdio", "streamable-http"}:
        logger.warning("Invalid WEB_TRANSPORT=%r, using stdio", raw)
        return "stdio"
    return cast(Literal["stdio", "streamable-http"], raw)


def _env_http_host() -> str:
    return (os.getenv("WEB_HTTP_HOST", "127.0.0.1") or "127.0.0.1").strip()


def _env_http_port() -> int:
    raw = (os.getenv("WEB_HTTP_PORT", "8000") or "8000").strip()
    try:
        port = int(raw)
    except ValueError:
        logger.warning("Invalid WEB_HTTP_PORT=%r, using 8000", raw)
        return 8000
    if port < 1 or port > 65535:
        logger.warning("Invalid WEB_HTTP_PORT=%r, using 8000", raw)
        return 8000
    return port


logger = logging.getLogger("www-search-mcp")


def _setup_logging() -> None:
    """Configure logging. Called once from main() to avoid side effects on import.

    Supports structured JSON logging via WEB_LOG_FORMAT=json.
    """
    import json

    level = logging.DEBUG if os.getenv("WEB_DEBUG") else logging.INFO
    if os.getenv("WEB_LOG_FORMAT", "").strip().lower() == "json":

        class JSONFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                payload = {
                    "timestamp": self.formatTime(record),
                    "level": record.levelname,
                    "logger": record.name,
                    "message": record.getMessage(),
                }
                if record.exc_info:
                    payload["exception"] = self.formatException(record.exc_info)
                return json.dumps(payload, ensure_ascii=False)

        handler = logging.StreamHandler()
        handler.setFormatter(JSONFormatter())
        logging.getLogger().handlers = []
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(level)
    else:
        logging.basicConfig(
            level=level,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )


def create_mcp() -> FastMCP:
    mcp = FastMCP(
        name="www-search-mcp",
        instructions=get_mcp_instructions(),
        host=_env_http_host(),
        port=_env_http_port(),
    )

    @mcp.resource(
        "www-search-mcp://server/info",
        description="Server summary info (name, version, tool count, safe env).",
        mime_type="application/json",
    )
    def server_info() -> dict[str, Any]:
        # Keep the resource lightweight; use the web_mcp_info tool for full details.
        from .info import get_server_info

        info = get_server_info()
        tools = info.get("tools") or []
        env = info.get("environment_variables") or {}
        return {
            "server_name": info.get("server_name"),
            "server_version": info.get("server_version"),
            "tool_count": len(tools) if isinstance(tools, list) else None,
            "environment_variables": env,
            "details_tool": "web_mcp_info",
        }

    # Operational endpoints (HTTP transports only). Note: custom routes are not
    # protected by FastMCP auth middleware by design.
    @mcp.custom_route("/status", methods=["GET"], include_in_schema=False)
    async def _status(_: Request) -> Response:
        from .tools.web_mcp_status import get_status_json

        return JSONResponse(get_status_json())

    @mcp.custom_route("/healthz", methods=["GET"], include_in_schema=False)
    async def _healthz(_: Request) -> Response:
        return JSONResponse({"status": "ok"})

    @mcp.custom_route("/error-types", methods=["GET"], include_in_schema=False)
    async def _error_types(_: Request) -> Response:
        """Return the exception hierarchy for client introspection."""
        hierarchy: dict[str, dict[str, Any]] = {}
        for cls in WebSearchMCError.__subclasses__():
            for sub in cls.__subclasses__():
                hierarchy[sub.__name__] = {
                    "parent": cls.__name__,
                    "retryable": sub.retryable,
                    "suggested_action": sub.suggested_action,
                }
            hierarchy[cls.__name__] = {
                "parent": "WebSearchMCError",
                "retryable": cls.retryable,
                "suggested_action": cls.suggested_action,
            }
        return JSONResponse(hierarchy)

    @mcp.custom_route("/readyz", methods=["GET"], include_in_schema=False)
    async def _readyz(_: Request) -> Response:
        from .tools.web_mcp_status import get_status_json

        data = get_status_json()
        health = data.get("health", {})
        checks = {
            "dns": "ok" if data.get("dns_resolver_count", 0) > 0 else "fail",
            "ddgs": "ok" if health.get("ddgs_available") else "fail",
            "playwright": "ok" if health.get("playwright_available") else "fail",
        }
        healthy = all(v == "ok" for v in checks.values())
        data["readyz"] = {
            "status": "ready" if healthy else "degraded",
            "checks": checks,
        }
        return JSONResponse(data, status_code=200 if healthy else 503)

    # Tools
    register_web_search_tool(mcp)
    register_web_search_images_tool(mcp)
    register_web_search_github_tool(mcp)
    register_web_search_pypi_tool(mcp)
    register_web_fetch_tool(mcp)
    register_web_fetch_browser_tool(mcp)
    register_web_download_tool(mcp)
    register_web_request_tool(mcp)
    register_web_mcp_info_tool(mcp)
    register_web_mcp_status_tool(mcp)

    return mcp


def _cleanup() -> None:
    logger.info("Shutting down www-search-mcp")

    async def _do_cleanup() -> None:
        try:
            await aclose_all_sessions()
        except Exception:
            logger.warning("Per-session HTTP cleanup failed", exc_info=True)
        try:
            await close_browser()
        except Exception:
            logger.warning("Browser cleanup failed", exc_info=True)

    # FastMCP stdio transport might stop the loop before atexit, and in
    # HTTP/SSE mode the loop is already running. Handle both cases safely.
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # HTTP/SSE mode: schedule tasks on the running loop.
            # Fire-and-forget is the best we can do from atexit.
            asyncio.ensure_future(_do_cleanup())
        else:
            loop.run_until_complete(_do_cleanup())
    except RuntimeError:
        # No loop exists at all (e.g. stdio after loop cleanup).
        try:
            asyncio.run(_do_cleanup())
        except Exception:
            logger.warning("Async cleanup failed", exc_info=True)


def _signal_handler(signum: int, frame: Any) -> None:
    logger.info("Received signal %d, shutting down", signum)
    try:
        _cleanup()
    except Exception:
        logger.warning("Cleanup raised during signal handling", exc_info=True)
    sys.exit(0)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    _setup_logging()
    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    atexit.register(_cleanup)

    mcp = create_mcp()

    # Start idle timer for stdio so the process self-terminates after inactivity.
    from .utils.activity import bump_activity

    bump_activity()

    # FastMCP defaults:
    # - streamable-http path: /mcp
    # - message path: /messages/
    mcp.run(transport=_env_transport())
