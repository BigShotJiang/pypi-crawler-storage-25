"""Playwright browser lifecycle management."""

from __future__ import annotations

import asyncio
import logging
import subprocess  # nosec B404
import sys
from typing import Any

from playwright.async_api import Browser, BrowserContext, Playwright, async_playwright

from .config import PROXY

logger = logging.getLogger("www-search-mcp")

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_pw: Playwright | None = None
_browser: Browser | None = None
_browser_headless: bool | None = None
_browser_context: BrowserContext | None = None

_BROWSER_LOCK = asyncio.Lock()
_BROWSER_CONTEXT_LOCK = asyncio.Lock()
_chromium_installed = False


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


async def _ensure_chromium() -> None:
    """Install Playwright Chromium if not already present."""
    global _chromium_installed
    if _chromium_installed:
        return
    _chromium_installed = True
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True,
            capture_output=True,
        )  # nosec B603 (args are constant, no shell)
        logger.info("Playwright Chromium browser installed successfully")
    except subprocess.CalledProcessError as exc:
        logger.warning(
            "Failed to auto-install Playwright Chromium: %s",
            exc.stderr.decode() if exc.stderr else exc,
        )
    except Exception as exc:
        logger.warning("Failed to auto-install Playwright Chromium: %s", exc)


async def ensure_browser(headless: bool = True) -> Browser:
    """Return a connected browser, creating one if necessary.

    If *headless* mode changes the old browser is closed first.
    """
    global _pw, _browser, _browser_headless, _browser_context

    async with _BROWSER_LOCK:
        if (
            _browser is not None
            and _browser.is_connected()
            and _browser_headless == headless
        ):
            return _browser

        await _close_context()
        await _close_browser_instance()
        await _stop_playwright()

        try:
            _pw = await async_playwright().start()
            launch_options: dict[str, Any] = {"headless": headless}
            if PROXY:
                launch_options["proxy"] = {"server": PROXY}
            if _pw is None:
                raise RuntimeError("Playwright failed to start")
            _browser = await _pw.chromium.launch(**launch_options)
        except Exception as exc:
            # If browser executable not found — try auto-installing Chromium
            if "Executable doesn't exist" in str(exc):
                logger.info("Playwright browser not found, auto-installing Chromium...")
                await _ensure_chromium()
                try:
                    if _pw is None:
                        raise RuntimeError("Playwright failed to start")
                    _browser = await _pw.chromium.launch(**launch_options)
                except Exception as retry_exc:
                    await _stop_playwright()
                    raise RuntimeError(
                        f"Browser launch failed after auto-install: {retry_exc}"
                    ) from retry_exc
            else:
                await _stop_playwright()
                raise RuntimeError(f"Browser launch failed: {exc}") from exc

        _browser_headless = headless
        logger.debug("Playwright browser launched (headless=%s)", headless)
        return _browser


async def ensure_browser_context(headless: bool = True) -> BrowserContext:
    """Return a shared ``BrowserContext`` (used for session persistence)."""
    global _browser_context

    if (
        _browser_context is not None
        and _browser is not None
        and _browser.is_connected()
    ):
        return _browser_context

    async with _BROWSER_CONTEXT_LOCK:
        if (
            _browser_context is not None
            and _browser is not None
            and _browser.is_connected()
        ):
            return _browser_context
        browser = await ensure_browser(headless=headless)
        _browser_context = await browser.new_context()
        logger.debug("Playwright browser context created")
        return _browser_context


async def close_all() -> None:
    """Shut down context, browser and playwright in order."""
    global _pw, _browser, _browser_headless, _browser_context

    await _close_context()
    await _close_browser_instance()
    await _stop_playwright()

    _browser = None
    _pw = None
    _browser_headless = None


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


async def _close_context() -> None:
    global _browser_context
    if _browser_context is not None:
        try:
            await _browser_context.close()
        except Exception:
            logger.warning("Browser context close failed", exc_info=True)
        _browser_context = None
        logger.debug("Playwright browser context closed")


async def _close_browser_instance() -> None:
    global _browser
    if _browser is not None:
        try:
            if _browser.is_connected():
                await _browser.close()
        except Exception:
            logger.warning("Browser close failed", exc_info=True)
        _browser = None
        logger.debug("Playwright browser closed")


async def _stop_playwright() -> None:
    global _pw
    if _pw is not None:
        try:
            await _pw.stop()
        except Exception:
            logger.warning("Playwright stop failed", exc_info=True)
        _pw = None
        logger.debug("Playwright stopped")
