"""Search backends: DuckDuckGo, GitHub, PyPI."""

from __future__ import annotations

from .ddg import ddg_context, ddg_search
from .github import github_search_repos
from .pypi import pypi_search, pypi_search_async

__all__ = [
    "ddg_context",
    "ddg_search",
    "github_search_repos",
    "pypi_search",
    "pypi_search_async",
]
