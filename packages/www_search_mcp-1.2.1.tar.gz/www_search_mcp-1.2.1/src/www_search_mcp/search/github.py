"""GitHub repository search via the public API."""

from __future__ import annotations

import logging
import time
from typing import Any

import niquests

from ..config import MAX_RESULTS, RETRIES, TIMEOUT
from ..errors import HTTPError, SearchEmptyError
from ..utils.cache import api_cache
from ..utils.search_exec import clamp_results
from ..utils.throttle import request_throttle
from .session import api_session, safe_json

logger = logging.getLogger("www-search-mcp")


def github_search_repos(
    query: str, max_results: int = MAX_RESULTS
) -> list[dict[str, Any]]:
    """Search GitHub repositories via the public API.

    If ``WEB_GITHUB_TOKEN`` is set, it is used to increase rate limits.
    Results are cached for 5 minutes to reduce API load.
    """
    max_results = clamp_results(max_results)

    # Check cache first
    cache_key = api_cache.make_key("github", query, max_results)
    cached = api_cache.get(cache_key)
    if cached is not None:
        logger.debug("github_search_repos: cache hit for %r", query)
        return cached.get("items", [])

    url = "https://api.github.com/search/repositories"
    params: dict[str, Any] = {
        "q": query,
        "per_page": max_results,
        "sort": "stars",
        "order": "desc",
    }

    for attempt in range(RETRIES + 1):
        try:
            request_throttle.wait()
            resp = api_session().get(
                url,
                params=params,
                timeout=TIMEOUT,
                headers={
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
            )

            retry_after = (
                (resp.headers or {}).get("retry-after")
                if hasattr(resp, "headers")
                else None
            )
            if retry_after and attempt < RETRIES:
                try:
                    delay = min(10.0, float(retry_after))
                except (TypeError, ValueError):
                    delay = 1.0
                logger.warning(
                    "GitHub Retry-After=%s, sleeping %.1fs", retry_after, delay
                )
                time.sleep(delay)
                continue

            if resp.status_code == 429 and attempt < RETRIES:
                time.sleep(1.0)
                continue

            if resp.status_code == 403:
                payload = safe_json(resp)
                msg = ""
                if isinstance(payload, dict):
                    msg = str(payload.get("message") or "")

                if attempt < RETRIES and "secondary rate limit" in msg.lower():
                    time.sleep(1.5)
                    continue

                raise HTTPError(
                    f"GitHub API returned 403 (likely rate limit). {msg}".strip(),
                    status=403,
                    retryable=True,
                    suggested_action="Set WEB_GITHUB_TOKEN to increase rate limits, or retry later.",
                )

            status_code = int(resp.status_code or 0)
            if status_code >= 400:
                payload = safe_json(resp)
                msg = ""
                if isinstance(payload, dict):
                    msg = str(payload.get("message") or "")
                raise HTTPError(
                    f"GitHub search failed: HTTP {status_code} {msg}".strip(),
                    status=status_code,
                )

            payload = safe_json(resp)
            if isinstance(payload, dict):
                items = payload.get("items")
                result = items if isinstance(items, list) else []
                api_cache.set(cache_key, {"items": result})
                return result

            api_cache.set(cache_key, {"items": []})
            return []
        except (niquests.exceptions.RequestException, HTTPError):
            raise
        except Exception as exc:
            if attempt >= RETRIES:
                raise SearchEmptyError(f"GitHub search failed: {exc}") from exc
            _log_retry(attempt, exc)

    raise SearchEmptyError("GitHub search failed: exhausted retries")


def _log_retry(attempt: int, exc: Exception) -> None:
    backoff = 0.7 * (2**attempt)
    logger.warning(
        "Search attempt %d failed (%s), retrying in %.1fs",
        attempt + 1,
        type(exc).__name__,
        backoff,
    )
    time.sleep(backoff)
