"""DuckDuckGo search with retry logic."""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from ddgs import DDGS
from ddgs.exceptions import DDGSException, RatelimitException, TimeoutException

from ..config import PROXY, RETRIES, TIMEOUT
from ..errors import (
    SearchEmptyError,
    SearchRateLimitError,
    SearchTimeoutError,
    WebSearchMCError,
)
from ..utils.throttle import request_throttle

logger = logging.getLogger("www-search-mcp")


def ddg_search(
    query: str,
    search_method: Callable[..., list],
) -> list[dict[str, Any]]:
    """Execute a DDG search call with throttling + retries.

    *search_method* is a callable like ``ddgs.text`` that returns a list.
    """
    for attempt in range(RETRIES + 1):
        try:
            request_throttle.wait()
            return search_method()
        except (TimeoutException, RatelimitException, DDGSException) as exc:
            if "No results found" in str(exc):
                return []
            if attempt >= RETRIES:
                raise _wrap_search_error(exc) from exc
            _log_retry(attempt, exc)
        except Exception as exc:
            if attempt >= RETRIES:
                raise RuntimeError(f"Search failed: {exc}") from exc
            _log_retry(attempt, exc)

    raise RuntimeError("Search failed: exhausted retries")


def ddg_context() -> Any:
    """Return a configured DDGS context manager."""
    return DDGS(timeout=TIMEOUT, proxy=PROXY)


def _wrap_search_error(
    exc: DDGSException | TimeoutException | RatelimitException,
) -> WebSearchMCError:
    if isinstance(exc, TimeoutException):
        return SearchTimeoutError("Search timed out.")
    if isinstance(exc, RatelimitException):
        return SearchRateLimitError("Rate-limited. Try later.")
    return SearchEmptyError(f"Search failed: {exc}")


def _log_retry(attempt: int, exc: Exception) -> None:
    backoff = 0.7 * (2**attempt)
    logger.warning(
        "Search attempt %d failed (%s), retrying in %.1fs",
        attempt + 1,
        type(exc).__name__,
        backoff,
    )
    time.sleep(backoff)
