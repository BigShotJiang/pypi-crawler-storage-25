"""PyPI package search (DDG discovery + JSON API enrichment)."""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

import niquests

from ..config import MAX_RESULTS, PROXY, TIMEOUT, get_ip_version_settings
from ..errors import NetworkError
from ..utils.cache import api_cache
from ..utils.dns import get_dns_resolvers
from ..utils.search_exec import clamp_results
from ..utils.throttle import request_throttle
from ..utils.ua import pick_ua
from .ddg import ddg_context, ddg_search

logger = logging.getLogger("www-search-mcp")

_PYPI_PKG_RE = re.compile(r"pypi\.org/project/([^/]+)")


def _extract_author(info: dict[str, Any]) -> str:
    """Extract a clean author name from PyPI metadata."""
    email = info.get("author_email") or ""
    if "<" in email:
        return email.split("<")[0].strip()
    if email:
        return email.strip()
    return (info.get("author") or "").strip()


def _build_result(info: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    """Build a formatted result dict from PyPI JSON API response."""
    project_urls = info.get("project_urls") or {}
    return {
        "name": (info.get("name") or "").strip(),
        "version": (info.get("version") or "").strip(),
        "summary": (info.get("summary") or "").strip(),
        "author": _extract_author(info),
        "license": (info.get("license_expression") or "").strip(),
        "requires_python": (info.get("requires_python") or "").strip(),
        "url": (info.get("project_url") or "").strip(),
        "repository": (
            project_urls.get("Source") or project_urls.get("Homepage") or ""
        ).strip(),
        "py_versions": [
            c.split("::")[-1].strip()
            for c in info.get("classifiers", [])
            if "Programming Language :: Python :: 3." in c
        ],
        "dependencies": [
            d.split(";")[0].strip()
            for d in (info.get("requires_dist") or [])
            if ";" not in d or "extra" not in d
        ][:10],
    }


def _build_fallback(item: dict[str, Any], pkg_name: str) -> dict[str, Any]:
    """Build a fallback result from DDG-only data."""
    return {
        "name": pkg_name,
        "version": "",
        "summary": (item.get("body") or "").strip(),
        "url": (item.get("href") or "").strip(),
    }


async def _fetch_pypi_metadata(
    session: niquests.AsyncSession, pkg_name: str
) -> dict[str, Any] | None:
    """Fetch and return PyPI JSON metadata for a single package."""
    try:
        request_throttle.wait()
        resp = await session.get(
            f"https://pypi.org/pypi/{pkg_name}/json",
            timeout=TIMEOUT,
            stream=False,
        )
        await session.gather(resp)
        if resp.status_code == 200:
            payload = resp.json()
            return payload["info"] if isinstance(payload, dict) else {}
    except Exception as exc:
        logger.warning("PyPI metadata fetch failed for %s: %s", pkg_name, exc)
    return None


async def pypi_search_async(
    query: str, max_results: int = MAX_RESULTS
) -> list[dict[str, Any]]:
    """Search PyPI packages via DuckDuckGo + enrich with JSON API metadata (async)."""
    max_results = clamp_results(max_results)

    # Check cache first
    cache_key = api_cache.make_key("pypi", query, max_results)
    cached = api_cache.get(cache_key)
    if cached is not None:
        logger.debug("pypi_search_async: cache hit for %r", query)
        return cached.get("items", [])

    # Step 1: Discover packages via DuckDuckGo (sync)
    with ddg_context() as ddgs:
        ddg_items = ddg_search(
            query,
            lambda: ddgs.text(
                f"site:pypi.org {query}", max_results=max_results, safesearch="off"
            ),
        )

    # Collect package names and their DDG items
    packages: list[tuple[str, dict[str, Any]]] = []
    for item in ddg_items:
        if not isinstance(item, dict):
            continue
        match = _PYPI_PKG_RE.search(item.get("href", ""))
        if match:
            packages.append((match.group(1), item))

    if not packages:
        return []

    # Step 2: Enrich with PyPI JSON API in parallel using async niquests
    session = niquests.AsyncSession(
        multiplexed=True,
        timeout=TIMEOUT,
        headers={"User-Agent": pick_ua()},
        resolver=get_dns_resolvers(),
        **get_ip_version_settings(),
    )
    if PROXY:
        session.proxies.update({"http": PROXY, "https": PROXY})

    try:
        # Launch all requests concurrently
        infos = await asyncio.gather(
            *(_fetch_pypi_metadata(session, name) for name, _ in packages),
            return_exceptions=True,
        )
    finally:
        await session.close()

    results: list[dict[str, Any]] = []
    for (pkg_name, item), info in zip(packages, infos):
        if isinstance(info, Exception):
            logger.warning("PyPI metadata fetch failed for %s: %s", pkg_name, info)
            results.append(_build_fallback(item, pkg_name))
            continue
        if info is not None and isinstance(info, dict):
            results.append(_build_result(info, item))
        else:
            results.append(_build_fallback(item, pkg_name))

    api_cache.set(cache_key, {"items": results})
    return results


def pypi_search(query: str, max_results: int = MAX_RESULTS) -> list[dict[str, Any]]:
    """Search PyPI packages via DuckDuckGo + enrich with JSON API metadata (sync wrapper)."""
    try:
        loop = asyncio.get_running_loop()
        if loop.is_running():
            # Called from async context without await - this is a usage error
            raise NetworkError(
                "pypi_search() is synchronous. Use pypi_search_async() from async code."
            )
    except RuntimeError:
        pass  # No loop running - safe to use asyncio.run
    return asyncio.run(pypi_search_async(query, max_results))


def _extract_author(info: dict[str, Any]) -> str:
    """Extract a clean author name from PyPI metadata."""
    email = info.get("author_email") or ""
    if "<" in email:
        return email.split("<")[0].strip()
    if email:
        return email.strip()
    return (info.get("author") or "").strip()
