"""Shared sync API session for GitHub and PyPI calls."""

from __future__ import annotations

import atexit
import logging
import os
from typing import Any

import niquests

from ..config import PROXY, get_ip_version_settings, get_ssl_context
from ..utils.dns import get_dns_resolvers
from ..utils.ua import pick_ua

logger = logging.getLogger("www-search-mcp")

_API_SESSION: niquests.Session | None = None


def _close_api_session() -> None:
    global _API_SESSION
    if _API_SESSION is None:
        return
    try:
        _API_SESSION.close()
    except Exception:
        logger.debug("Failed to close API session", exc_info=True)
    finally:
        _API_SESSION = None


atexit.register(_close_api_session)


def api_session() -> niquests.Session:
    """Lazy singleton for outbound API calls (connection pooling)."""
    global _API_SESSION
    if _API_SESSION is None:
        s = niquests.Session(
            multiplexed=True,
            resolver=get_dns_resolvers(),
            **get_ip_version_settings(),
        )
        s.headers.update({"User-Agent": pick_ua()})
        if PROXY:
            s.proxies.update({"http": PROXY, "https": PROXY})
        # niquests typing expects a path/bool here; runtime also accepts SSLContext.
        s.verify = get_ssl_context()  # type: ignore

        token = os.getenv("WEB_GITHUB_TOKEN", "").strip()
        if token:
            s.headers.update({"Authorization": f"Bearer {token}"})
        _API_SESSION = s

    return _API_SESSION


def safe_json(resp: Any) -> Any:
    try:
        return resp.json()
    except Exception:
        return None
