"""Structured exception hierarchy for www-search-mcp.

Every tool-level error is a ``WebSearchMCError`` subclass carrying:

* ``retryable`` – whether the caller should retry the operation.
* ``suggested_action`` – human-readable hint for the LLM / user.
* ``http_status`` – optional HTTP status code (for HTTPError subclasses).

This lets upstream code decide between retry, fallback, or surfacing a
user-facing message without parsing exception strings.
"""

from __future__ import annotations


class WebSearchMCError(Exception):
    """Base for all domain-specific errors in this package."""

    retryable: bool = False
    suggested_action: str = ""
    http_status: int | None = None

    def __init__(
        self,
        message: str,
        *,
        retryable: bool | None = None,
        suggested_action: str = "",
        http_status: int | None = None,
    ) -> None:
        super().__init__(message)
        if retryable is not None:
            self.retryable = retryable
        if suggested_action:
            self.suggested_action = suggested_action
        if http_status is not None:
            self.http_status = http_status


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class ConfigError(WebSearchMCError):
    """Invalid configuration (environment variables, SSL paths, etc.)."""

    retryable = False
    suggested_action = "Check environment variables and configuration values."


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


class ValidationError(WebSearchMCError):
    """Invalid user input (URL, selector, file path)."""

    retryable = False
    suggested_action = "Verify the input parameters and try again."


class InvalidURLError(ValidationError):
    """URL does not start with http:// or https://."""

    suggested_action = "Ensure the URL starts with http:// or https://."


class InvalidPathError(ValidationError):
    """save_file path is invalid or unsafe."""

    suggested_action = "Use a safe file path with an extension and no '..' traversal."


class InvalidSelectorError(ValidationError):
    """CSS selector is malformed or unsupported."""

    suggested_action = "Check the CSS selector syntax."


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------


class NetworkError(WebSearchMCError):
    """Low-level network failure (DNS, TCP, TLS)."""

    retryable = True
    suggested_action = "Check network connectivity and retry."


class NetworkTimeoutError(NetworkError):
    """Request timed out."""

    suggested_action = "The server is slow or unreachable. Retry with a longer timeout."


class RateLimitError(NetworkError):
    """Rate-limited by the remote server."""

    retryable = True
    suggested_action = "Wait a moment and retry, or reduce request frequency."


class ProxyError(NetworkError):
    """Proxy configuration or connection failure."""

    retryable = True
    suggested_action = "Check WEB_PROXY setting and proxy availability."


# ---------------------------------------------------------------------------
# Fetch / Download
# ---------------------------------------------------------------------------


class FetchError(WebSearchMCError):
    """Error during HTTP fetch or download."""

    retryable = True
    suggested_action = "Retry the request. If it persists, check the URL."


class HTTPError(FetchError):
    """HTTP response with status >= 400."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        retryable: bool | None = None,
        suggested_action: str = "",
    ) -> None:
        # Auto-compute retryability for known status codes
        if retryable is None:
            retryable = status in (429, 502, 503, 504)
        super().__init__(
            message,
            retryable=retryable,
            suggested_action=suggested_action,
            http_status=status,
        )


class BinaryContentError(FetchError):
    """URL returned binary content when text/HTML was expected."""

    retryable = False
    suggested_action = "Use web_download for binary files (PDFs, images, archives)."


class ContentTooLargeError(FetchError):
    """Content exceeds the configured size limit."""

    retryable = False
    suggested_action = "Increase WEB_MAX_DOWNLOAD_MB or fetch a smaller resource."


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class SearchError(WebSearchMCError):
    """Error during search operations (DDG, GitHub, PyPI)."""

    retryable = True
    suggested_action = "Retry the search. If rate-limited, wait before retrying."


class SearchTimeoutError(SearchError):
    """Search provider timed out."""

    retryable = True
    suggested_action = "Retry the search. Consider reducing max_results."


class SearchRateLimitError(SearchError):
    """Search provider rate-limited the request."""

    retryable = True
    suggested_action = "Wait a moment and retry, or reduce request frequency."


class SearchEmptyError(SearchError):
    """Search returned no results (not an error per se, but surfaced as one)."""

    retryable = False
    suggested_action = "Try a different query or broader search terms."


# ---------------------------------------------------------------------------
# Browser / Playwright
# ---------------------------------------------------------------------------


class BrowserError(WebSearchMCError):
    """Playwright or browser automation failure."""

    retryable = True
    suggested_action = "Ensure Chromium is installed (playwright install chromium)."


class BrowserLaunchError(BrowserError):
    """Failed to launch the browser process."""

    retryable = False
    suggested_action = (
        "Run 'playwright install chromium' and verify system dependencies."
    )


class BrowserNavigationError(BrowserError):
    """Page navigation failed (timeout, DNS, SSL error)."""

    retryable = True
    suggested_action = "Check the URL and network connectivity, then retry."


class BrowserTimeoutError(BrowserError):
    """Browser operation timed out."""

    retryable = True
    suggested_action = "Increase wait_seconds or retry."
