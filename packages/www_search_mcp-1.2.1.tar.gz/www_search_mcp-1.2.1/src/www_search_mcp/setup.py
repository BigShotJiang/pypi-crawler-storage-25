"""Post-install setup for www-search-mcp: installs Playwright browsers."""

import subprocess  # nosec B404
import sys


def post_install() -> None:
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])  # nosec B603 (args are constant, no shell)


if __name__ == "__main__":
    post_install()
