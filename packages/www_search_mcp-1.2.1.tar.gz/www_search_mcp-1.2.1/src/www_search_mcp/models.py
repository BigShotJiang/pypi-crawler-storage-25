"""Pydantic models for tool parameter validation."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator

from .config import MAX_RESULTS


class WebSearchParams(BaseModel):
    """Parameters for web_search and web_search_images tools."""

    queries: str | list[str] = Field(..., description="Search query or list of queries")
    max_results: int = Field(
        default=MAX_RESULTS, ge=1, le=25, description="Max results per query"
    )

    @field_validator("queries")
    @classmethod
    def validate_queries(cls, v: str | list[str]) -> str | list[str]:
        if isinstance(v, str):
            if not v.strip():
                raise ValueError("queries must not be empty")
        else:
            if not any(q.strip() for q in v):
                raise ValueError("queries must not be empty")
        return v


class WebFetchParams(BaseModel):
    """Parameters for web_fetch tool."""

    urls: str | list[str] = Field(..., description="URL or list of URLs to fetch")
    fetch_div: str = Field(
        default="", description="CSS selector to extract specific content"
    )
    save_file: str = Field(default="", description="Path to save fetched content")
    use_session: bool = Field(
        default=False, description="Use persistent session for cookies"
    )

    @field_validator("urls")
    @classmethod
    def validate_urls(cls, v: str | list[str]) -> str | list[str]:
        if isinstance(v, str):
            if not v.strip():
                raise ValueError("urls must not be empty")
        else:
            if not v:
                raise ValueError("urls must not be empty")
        return v


class WebDownloadParams(BaseModel):
    """Parameters for web_download tool."""

    urls: str | list[str] = Field(..., description="URL or list of URLs to download")
    save_files: str | list[str] = Field(
        ..., description="Path or list of paths to save files"
    )
    use_session: bool = Field(
        default=False, description="Use persistent session for cookies"
    )


class WebFetchBrowserParams(BaseModel):
    """Parameters for web_fetch_browser tool."""

    urls: str | list[str] = Field(..., description="URL or list of URLs to fetch")
    headless: bool = Field(default=True, description="Run browser in headless mode")
    fetch_div: str = Field(
        default="", description="CSS selector to extract specific content"
    )
    save_file: str = Field(default="", description="Path to save fetched content")
    wait_seconds: int = Field(
        default=0, ge=0, le=60, description="Seconds to wait for dynamic content"
    )
    use_session: bool = Field(
        default=False, description="Use persistent session for cookies"
    )


class WebRequestParams(BaseModel):
    """Parameters for web_request tool."""

    queries: dict[str, Any] | list[dict[str, Any]] = Field(
        ..., description="Request specification(s)"
    )


class WebSearchGithubParams(BaseModel):
    """Parameters for web_search_github tool."""

    queries: str | list[str] = Field(..., description="GitHub search query or list")
    max_results: int = Field(
        default=MAX_RESULTS, ge=1, le=25, description="Max results per query"
    )

    @field_validator("queries")
    @classmethod
    def validate_queries(cls, v: str | list[str]) -> str | list[str]:
        if isinstance(v, str):
            if not v.strip():
                raise ValueError("queries must not be empty")
        else:
            if not any(q.strip() for q in v):
                raise ValueError("queries must not be empty")
        return v


class WebSearchPyPIParams(BaseModel):
    """Parameters for web_search_pypi tool."""

    queries: str | list[str] = Field(..., description="PyPI search query or list")
    max_results: int = Field(
        default=MAX_RESULTS, ge=1, le=25, description="Max results per query"
    )

    @field_validator("queries")
    @classmethod
    def validate_queries(cls, v: str | list[str]) -> str | list[str]:
        if isinstance(v, str):
            if not v.strip():
                raise ValueError("queries must not be empty")
        else:
            if not any(q.strip() for q in v):
                raise ValueError("queries must not be empty")
        return v
