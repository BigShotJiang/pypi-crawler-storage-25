"""Server and tool instructions.

This module is the single source of truth for:
- MCP server instructions string
- per-tool title/description/usage docs
- web_mcp_info tool
"""

import os
from importlib.metadata import version as _pkg_version
from pathlib import Path
from typing import Any, Callable, TypedDict

import yaml
from mcp.server.fastmcp import FastMCP
from mcp.types import Icon, ToolAnnotations

from .config import (
    DNS_RESOLVER,
    DNS_STRATEGY,
    MAX_FETCH_CHARS,
    MAX_RESULTS,
    REQUEST_LIMIT,
    SESSION_ENABLED,
    TIMEOUT,
    TIMEOUT_CONNECT,
    TIMEOUT_READ,
    TIMEOUT_TOTAL,
)


def _load_tool_instructions() -> dict[str, dict[str, Any]]:
    """Load tool instructions from YAML file."""
    yaml_path = Path(__file__).parent / "data" / "tools.yaml"
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data


TOOL_INSTRUCTIONS: dict[str, dict[str, Any]] = _load_tool_instructions()


# Optional tool metadata for host UIs.
# FastMCP's public tool decorator supports icons, annotations (hints), and meta.


class _IconSpec(TypedDict, total=False):
    src: str
    mimeType: str
    sizes: list[str]


class _ToolMetaSpec(TypedDict, total=False):
    tags: list[str]
    icons: list[_IconSpec]
    # ToolAnnotations fields, using readable snake_case keys.
    read_only: bool
    destructive: bool
    idempotent: bool
    open_world: bool


_TOOL_META: dict[str, _ToolMetaSpec] = {
    "web_search": {
        "tags": ["search", "ddg"],
        "read_only": True,
        "open_world": True,
        "icons": [
            {"src": "https://duckduckgo.com/favicon.ico", "mimeType": "image/x-icon"}
        ],
    },
    "web_search_images": {
        "tags": ["search", "images", "ddg"],
        "read_only": True,
        "open_world": True,
        "icons": [
            {"src": "https://duckduckgo.com/favicon.ico", "mimeType": "image/x-icon"}
        ],
    },
    "web_search_github": {
        "tags": ["search", "github"],
        "read_only": True,
        "open_world": True,
        "icons": [
            {
                "src": "https://github.githubassets.com/favicons/favicon.svg",
                "mimeType": "image/svg+xml",
            }
        ],
    },
    "web_search_pypi": {
        "tags": ["search", "pypi"],
        "read_only": True,
        "open_world": True,
        "icons": [
            {
                "src": "https://pypi.org/static/images/favicon.35549fe8.ico",
                "mimeType": "image/x-icon",
            }
        ],
    },
    "web_fetch": {
        "tags": ["fetch", "html", "markdown"],
        "read_only": True,
        "open_world": True,
    },
    "web_fetch_browser": {
        "tags": ["fetch", "browser", "playwright"],
        "read_only": True,
        "open_world": True,
    },
    "web_download": {
        "tags": ["download", "files"],
        "destructive": True,
        "open_world": True,
    },
    "web_request": {
        "tags": ["api", "request"],
        "open_world": True,
    },
    "web_mcp_info": {
        "tags": ["info"],
        "read_only": True,
    },
    "web_mcp_status": {
        "tags": ["status", "diagnostics"],
        "read_only": True,
    },
}


def tool_meta(
    tool_name: str,
) -> tuple[list[Icon] | None, ToolAnnotations | None, dict[str, Any] | None]:
    """Return (icons, annotations, meta) for the given tool.

    meta currently includes ``tags`` for host UIs.
    """

    m = _TOOL_META.get(tool_name)
    if not m:
        return None, None, None

    icons_raw = m.get("icons")
    if isinstance(icons_raw, list):
        icons = [
            Icon(
                src=spec["src"],
                mimeType=spec.get("mimeType"),
                sizes=spec.get("sizes"),
            )
            for spec in icons_raw
            if spec.get("src")
        ]
        if not icons:
            icons = None
    else:
        icons = None

    hint_kwargs: dict[str, Any] = {}
    if "read_only" in m:
        hint_kwargs["readOnlyHint"] = bool(m["read_only"])
    if "destructive" in m:
        hint_kwargs["destructiveHint"] = bool(m["destructive"])
    if "idempotent" in m:
        hint_kwargs["idempotentHint"] = bool(m["idempotent"])
    if "open_world" in m:
        hint_kwargs["openWorldHint"] = bool(m["open_world"])

    annotations = ToolAnnotations(**hint_kwargs) if hint_kwargs else None

    meta: dict[str, Any] = {}
    tags = m.get("tags")
    if isinstance(tags, list) and tags:
        meta["tags"] = list(tags)

    return icons, annotations, meta or None


def tool_title(tool_name: str) -> str:
    return str(TOOL_INSTRUCTIONS[tool_name]["title"])


def tool_description(tool_name: str) -> str:
    return str(TOOL_INSTRUCTIONS[tool_name]["description"])


def get_mcp_instructions() -> str:
    lines: list[str] = [
        "Web search, fetch, and download tools.",
        "",
        "Batching guidance:",
        "- Prefer multi-query and multi-URL calls (pass lists) to reduce round-trips.",
        "- Tune max_results based on task scope (typical 5-25).",
        "",
        "Session guidance:",
        "- If use_session=true (or WEB_SESSION_ENABLED=true), cookies persist per MCP session (not globally).",
        "",
        "Timeout guidance:",
        "- Tools are bounded by WEB_TIMEOUT_TOTAL (tool execution deadline).",
        "- HTTP connect/read timeouts are controlled by WEB_TIMEOUT_CONNECT/WEB_TIMEOUT_READ.",
        "",
        "Available tools:",
    ]

    for name, meta in TOOL_INSTRUCTIONS.items():
        if name == "web_mcp_info":
            continue
        # Keep this short; tool_description contains full guidance.
        lines.append(f"- {name}: {meta['title']}")

    lines.append("")
    lines.append(
        "Use web_mcp_info to get full per-tool details, parameters and examples."
    )
    return "\n".join(lines)


def get_server_info() -> dict[str, Any]:
    """Get comprehensive server information including available tools and environment variables."""
    tools = []

    # Add tools with detailed instruction information
    for tool_name, instructions in TOOL_INSTRUCTIONS.items():
        tools.append(
            {
                "name": tool_name,
                "title": instructions["title"],
                "description": instructions["description"],
                "parameters": instructions["parameters"],
                "examples": instructions.get("examples", []),
                "use_cases": instructions.get("use_cases", []),
            }
        )

    env_vars = {
        "WEB_DEBUG": "Enable debug logging (default: disabled)",
        "WEB_MAX_DOWNLOAD_MB": "Maximum file size for downloads in MB (default: 50)",
        "WEB_MAX_RESULTS": "Maximum results per search (default: 5, max: 25)",
        "WEB_MAX_FETCH_CHARS": "Maximum characters returned in fetch body (default: 200000)",
        "WEB_PROXY": "HTTP proxy URL (optional)",
        "WEB_REQUEST_LIMIT": "Max concurrent outbound requests (default: 50)",
        "WEB_DNS_RESOLVER": "DNS resolver preset: google|cloudflare|yandex|quad9|system (default: google)",
        "WEB_DNS_STRATEGY": "IPv4/IPv6 strategy: only_ipv4|only_ipv6 (default: both enabled)",
        "WEB_SESSION_ENABLED": "Enable session cookies persistence (default: disabled)",
        "WEB_TIMEOUT": "Legacy total request timeout in seconds (default: 30)",
        "WEB_TIMEOUT_TOTAL": "Total request timeout in seconds (default: WEB_TIMEOUT)",
        "WEB_TIMEOUT_CONNECT": "Connect timeout in seconds (default: 5)",
        "WEB_TIMEOUT_READ": "Read timeout in seconds (default: 25)",
        "WEB_SSL_VERIFY": "SSL certificate verification (default: enabled)",
        "WEB_SSL_PATH": "Extra CA bundle path (optional)",
        "WEB_USER_AGENT": "Override default User-Agent (optional)",
        "WEB_UA_ROTATION": "Enable User-Agent rotation (default: disabled)",
        "WEB_UA_LIST": "Custom User-Agent list separated by ||| (optional)",
        "WEB_GITHUB_TOKEN": "GitHub API token to increase rate limits (optional)",  # nosec B105
        "WEB_REQUEST_TOKEN": "Default Authorization token for web_request (optional)",  # nosec B105
        "WEB_TRANSPORT": "Server transport: stdio|sse|streamable-http (default: stdio)",
        "WEB_HTTP_HOST": "Host for HTTP-based transports (default: 127.0.0.1)",
        "WEB_HTTP_PORT": "Port for HTTP-based transports (default: 8000)",
    }

    # Get current values for environment variables using a small registry so
    # each variable declares how its current value is resolved.
    from .config import MAX_DOWNLOAD_MB

    _env_getters: dict[str, Callable[[], str]] = {
        "WEB_DEBUG": lambda: "enabled" if os.getenv("WEB_DEBUG") else "disabled",
        "WEB_MAX_DOWNLOAD_MB": lambda: str(MAX_DOWNLOAD_MB),
        "WEB_MAX_RESULTS": lambda: str(MAX_RESULTS),
        "WEB_PROXY": lambda: os.getenv("WEB_PROXY", ""),
        "WEB_REQUEST_LIMIT": lambda: str(REQUEST_LIMIT),
        "WEB_DNS_RESOLVER": lambda: DNS_RESOLVER,
        "WEB_DNS_STRATEGY": lambda: DNS_STRATEGY,
        "WEB_SESSION_ENABLED": lambda: "enabled" if SESSION_ENABLED else "disabled",
        "WEB_TIMEOUT": lambda: str(TIMEOUT),
        "WEB_TIMEOUT_TOTAL": lambda: str(TIMEOUT_TOTAL),
        "WEB_TIMEOUT_CONNECT": lambda: str(TIMEOUT_CONNECT),
        "WEB_TIMEOUT_READ": lambda: str(TIMEOUT_READ),
        "WEB_MAX_FETCH_CHARS": lambda: str(MAX_FETCH_CHARS),
        "WEB_SSL_VERIFY": lambda: (
            "enabled" if os.getenv("WEB_SSL_VERIFY") != "0" else "disabled"
        ),
        "WEB_SSL_PATH": lambda: os.getenv("WEB_SSL_PATH", ""),
        "WEB_USER_AGENT": lambda: os.getenv("WEB_USER_AGENT", ""),
        "WEB_UA_ROTATION": lambda: (
            "enabled"
            if os.getenv("WEB_UA_ROTATION", "").lower() in {"1", "true", "yes", "on"}
            else "disabled"
        ),
        "WEB_UA_LIST": lambda: "set" if os.getenv("WEB_UA_LIST", "") else "not set",
        "WEB_GITHUB_TOKEN": lambda: (
            "set" if os.getenv("WEB_GITHUB_TOKEN") else "not set"
        ),
        "WEB_REQUEST_TOKEN": lambda: (
            "set" if os.getenv("WEB_REQUEST_TOKEN") else "not set"
        ),
        "WEB_TRANSPORT": lambda: os.getenv("WEB_TRANSPORT", "stdio"),
        "WEB_HTTP_HOST": lambda: os.getenv("WEB_HTTP_HOST", ""),
        "WEB_HTTP_PORT": lambda: os.getenv("WEB_HTTP_PORT", ""),
    }

    env_values = {}
    for var, desc in env_vars.items():
        getter = _env_getters.get(var, lambda v=var: os.getenv(v, ""))
        env_values[var] = {"description": desc, "current": getter()}

    try:
        pkg_ver = _pkg_version("www-search-mcp")
    except Exception:
        pkg_ver = "0.0.0"

    return {
        "server_name": "www-search-mcp",
        "server_version": pkg_ver,
        "http_client": "niquests",
        "connection_multiplexing": True,
        "parallel_execution": {
            "web_search": "batch: list of queries; tune max_results (typical 5-25)",
            "web_search_images": "batch: list of queries; tune max_results (typical 5-25)",
            "web_search_github": "batch: list of queries; tune max_results (typical 5-25)",
            "web_search_pypi": "batch: list of queries; tune max_results (typical 5-25)",
            "web_fetch": "up to 10 parallel URLs",
            "web_fetch_browser": "optional for multiple URLs",
            "web_download": "up to 20 parallel downloads",
            "web_request": "batch: list of request specs; concurrency is async workers",
        },
        "tools": tools,
        "environment_variables": env_values,
    }


def register_web_mcp_info_tool(mcp: FastMCP) -> None:
    meta = TOOL_INSTRUCTIONS["web_mcp_info"]
    icons, annotations, tool_meta_dict = tool_meta("web_mcp_info")

    @mcp.tool(
        name="web_mcp_info",
        title=str(meta["title"]),
        description=str(meta["description"]),
        icons=icons,
        annotations=annotations,
        meta=tool_meta_dict,
    )
    def web_mcp_info() -> dict[str, Any]:
        from .utils.activity import bump_activity

        bump_activity()
        return get_server_info()
