"""Environment-driven configuration and shared constants."""

from __future__ import annotations

import logging
import os
import ssl
import threading
from pathlib import Path
from typing import Any

import niquests
import truststore

from .errors import ConfigError

logger = logging.getLogger("www-search-mcp")

# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------


def _env_int(
    name: str, default: int, lo: int | None = None, hi: int | None = None
) -> int:
    try:
        val = int(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %d", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


def _env_float(
    name: str, default: float, lo: float | None = None, hi: float | None = None
) -> float:
    try:
        val = float(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %.1f", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


_TRUE_SET = {"1", "true", "yes", "on", "y", "t"}
_FALSE_SET = {"0", "false", "no", "off", "n", "f"}


def _parse_bool(raw: str) -> bool | None:
    """Parse a string into a bool. Returns None if not recognized."""
    v = raw.strip().lower()
    if v in _TRUE_SET:
        return True
    if v in _FALSE_SET:
        return False
    return None


def _env_bool(name: str, default: bool = True) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    parsed = _parse_bool(raw)
    if parsed is None:
        logger.warning(
            "Environment variable %s=%r not a valid bool, using default %s",
            name,
            raw,
            default,
        )
        return default
    return parsed


# ---------------------------------------------------------------------------
# Resolved settings (read once at import time)
# ---------------------------------------------------------------------------

# Timeouts: keep requests bounded. If it doesn't load fast, it's likely not usable.
# Legacy: WEB_TIMEOUT controls total timeout.
TIMEOUT_TOTAL: int = _env_int(
    "WEB_TIMEOUT_TOTAL", _env_int("WEB_TIMEOUT", 30, lo=1), lo=1
)
TIMEOUT_CONNECT: int = _env_int("WEB_TIMEOUT_CONNECT", 5, lo=1, hi=30)
TIMEOUT_READ: int = _env_int("WEB_TIMEOUT_READ", 25, lo=1, hi=120)

# Backwards-compatible alias used across the codebase.
TIMEOUT: int = TIMEOUT_TOTAL

TIMEOUT_CONFIG = niquests.TimeoutConfiguration(
    total=TIMEOUT_TOTAL,
    connect=TIMEOUT_CONNECT,
    read=TIMEOUT_READ,
)

MAX_RESULTS: int = _env_int("WEB_MAX_RESULTS", 5, lo=1, hi=25)
MAX_FETCH_CHARS: int = _env_int("WEB_MAX_FETCH_CHARS", 200_000, lo=1_000, hi=1_000_000)
RETRIES: int = _env_int("WEB_RETRIES", 2, lo=0, hi=5)
MIN_INTERVAL: float = _env_float("WEB_MIN_INTERVAL", 1.0, lo=0.0)
MAX_DOWNLOAD_MB: int = _env_int("WEB_MAX_DOWNLOAD_MB", 50, lo=1)
MAX_DOWNLOAD_BYTES: int = MAX_DOWNLOAD_MB * 1024 * 1024
SESSION_ENABLED: bool = _env_bool("WEB_SESSION_ENABLED", default=False)
PROXY: str | None = os.getenv("WEB_PROXY", "").strip() or None

# Optional default Authorization token for the web_request tool.
# Do not print this value anywhere; web_mcp_info should only report set/not set.
REQUEST_TOKEN: str | None = os.getenv("WEB_REQUEST_TOKEN", "").strip() or None

# Global upper bound for concurrent outbound requests (fetch/download).
REQUEST_LIMIT: int = _env_int("WEB_REQUEST_LIMIT", 50, lo=1, hi=500)

# DNS resolver preset for niquests.
DNS_RESOLVER: str = (
    (os.getenv("WEB_DNS_RESOLVER", "google") or "google").strip().lower()
)
if DNS_RESOLVER not in {"google", "cloudflare", "yandex", "quad9", "system"}:
    logger.warning("Invalid WEB_DNS_RESOLVER=%r, using 'google'", DNS_RESOLVER)
    DNS_RESOLVER = "google"

# IPv4/IPv6 strategy for niquests.
# Note: niquests doesn't support explicit 'prefer' — only enable/disable.
# Default behavior (empty / unknown value) = both IPv4+IPv6 enabled.
DNS_STRATEGY: str = (os.getenv("WEB_DNS_STRATEGY", "") or "").strip().lower()
VALID_STRATEGIES = {"only_ipv4", "only_ipv6"}
if DNS_STRATEGY and DNS_STRATEGY not in VALID_STRATEGIES:
    logger.warning(
        "Invalid WEB_DNS_STRATEGY=%r, using default (both IPv4+IPv6 enabled)",
        DNS_STRATEGY,
    )
    DNS_STRATEGY = ""


def get_ip_version_settings(strategy: str = DNS_STRATEGY) -> dict[str, Any]:
    """Return IPv4/IPv6 disable flags based on DNS_STRATEGY.

    Note: niquests doesn't support 'prefer' — only explicit disable.
    Empty or unknown value = both IPv4 and IPv6 enabled (default).
    """
    if strategy == "only_ipv4":
        return {"disable_ipv6": True}
    if strategy == "only_ipv6":
        return {"disable_ipv4": True}
    # Default: both enabled
    return {}


SSL_VERIFY: bool = _env_bool("WEB_SSL_VERIFY", default=True)
# Optional path to extra trusted CA certificates (PEM file or directory with
# OpenSSL-hashed certs). Loaded *in addition to* the system trust store, not
# as a replacement. Ignored when SSL_VERIFY is False.
SSL_PATH: str | None = os.getenv("WEB_SSL_PATH", "").strip() or None

# ---------------------------------------------------------------------------
# User-Agent rotation
# ---------------------------------------------------------------------------

UA_ROTATION: bool = _env_bool("WEB_UA_ROTATION", default=False)

# Default pool of realistic desktop browser UAs.
_DEFAULT_UAS: tuple[str, ...] = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/18.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
)

# User-provided single UA (legacy) or custom list via WEB_UA_LIST.
_WEB_USER_AGENT: str = os.getenv(
    "WEB_USER_AGENT",
    "",
)

# Parse WEB_UA_LIST: "UA1|||UA2|||UA3"
_UA_LIST_RAW: str = os.getenv("WEB_UA_LIST", "").strip()
if _UA_LIST_RAW:
    UA_LIST: tuple[str, ...] = tuple(
        ua.strip() for ua in _UA_LIST_RAW.split("|||") if ua.strip()
    )
elif _WEB_USER_AGENT:
    UA_LIST = (_WEB_USER_AGENT,)
else:
    UA_LIST = _DEFAULT_UAS

CHROME_UA: str = UA_LIST[0]


# ---------------------------------------------------------------------------
# SSL context builder (lazy, cached)
# ---------------------------------------------------------------------------

_SSL_CONTEXT: ssl.SSLContext | None = None
_SSL_LOCK = threading.Lock()


def get_ssl_context() -> ssl.SSLContext:
    """Return the shared SSL context used by all HTTP clients.

    Thread-safe singleton.

    Policy:
      * ``SSL_VERIFY=False`` -> permissive context (CERT_NONE, no hostname check).
      * ``SSL_VERIFY=True`` (default) -> ``truststore.SSLContext`` backed by the
        operating system trust store (macOS Keychain, Windows Cert Store,
        OpenSSL paths on Linux).
      * If ``SSL_PATH`` is set, it is loaded *in addition to* the system
        trust store as an extra CA source (PEM file or OpenSSL-hashed dir).
    """
    global _SSL_CONTEXT
    if _SSL_CONTEXT is not None:
        return _SSL_CONTEXT

    with _SSL_LOCK:
        if _SSL_CONTEXT is not None:
            return _SSL_CONTEXT

        if SSL_VERIFY is False:
            logger.warning(
                "WEB_SSL_VERIFY=false: TLS certificate verification is DISABLED (insecure)"
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            _SSL_CONTEXT = ctx
            return ctx

        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

        if SSL_PATH:
            logger.info("WEB_SSL_PATH: adding extra CA trust from %r", SSL_PATH)
            p = Path(SSL_PATH).expanduser()
            if not p.exists():
                raise ConfigError(f"WEB_SSL_PATH points to a non-existent path: {p}")
            try:
                if p.is_dir():
                    ctx.load_verify_locations(capath=os.fspath(p))
                else:
                    ctx.load_verify_locations(cafile=os.fspath(p))
            except ssl.SSLError as exc:
                raise ConfigError(
                    f"Failed to load CA bundle from {p}: {exc}",
                    suggested_action="Verify WEB_SSL_PATH points to a valid PEM file or directory.",
                ) from exc

        _SSL_CONTEXT = ctx
        return ctx
