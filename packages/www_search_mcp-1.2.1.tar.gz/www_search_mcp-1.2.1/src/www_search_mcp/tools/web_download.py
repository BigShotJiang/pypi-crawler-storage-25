"""Web download tool implementation."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import niquests

from mcp.server.fastmcp.server import Context

from ..config import SESSION_ENABLED, TIMEOUT_TOTAL
from ..errors import FetchError, ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..utils.throttle import request_throttle
from ..utils.tool_runtime import tool_timeout
from ..utils import (
    get_http_session,
    limited_request,
    new_ephemeral_async_session,
    read_streamed_response,
    resolve_path,
    validate_url,
)

logger = logging.getLogger("www-search-mcp")


async def web_download(
    urls: str | list[str],
    save_files: str | list[str],
    use_session: bool = False,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Execute the download."""
    with tool_timeout(TIMEOUT_TOTAL):
        return await _web_download_inner(urls, save_files, use_session, ctx)


async def _web_download_inner(
    urls: str | list[str],
    save_files: str | list[str],
    use_session: bool,
    ctx: Context | None,
) -> dict[str, Any]:
    # Handle single URL string or list of URLs
    url_list: list[str]
    save_paths: list[Path]

    if isinstance(urls, str):
        url_list = [validate_url(urls)]
        # For single URL, save_files should be a string
        if isinstance(save_files, str):
            save_paths = [resolve_path(save_files)]
        else:
            raise ValidationError(
                "save_files must be a string when urls is a single string"
            )
    else:
        url_list = [validate_url(url.strip()) for url in urls if url.strip()]
        # For multiple URLs, save_files should be a list
        if isinstance(save_files, str):
            raise ValidationError(
                "save_files must be a list of paths when urls is a list"
            )
        save_paths = [resolve_path(path.strip()) for path in save_files if path.strip()]

    if not url_list:
        raise ValidationError("urls must not be empty")

    if len(url_list) != len(save_paths):
        raise ValidationError("Number of URLs must match number of save_file paths")

    session_active = use_session or SESSION_ENABLED
    logger.info(
        "web_download: downloading %d files session=%s", len(url_list), session_active
    )

    # Perform parallel downloads
    results = []

    await request_throttle.await_gap()

    try:
        if session_active:
            client = await get_http_session(ctx)
            # Create tasks for all URLs
            tasks = []
            for url, target in zip(url_list, save_paths):
                task = asyncio.create_task(_download_single(url, target, client))
                tasks.append((url, target, task))

            # Execute all downloads in parallel
            task_results = await asyncio.gather(*[task for _, _, task in tasks])

            for (url, target, _), result in zip(tasks, task_results):
                results.append(result)
        else:
            # Use a new session for non-session downloads
            async with new_ephemeral_async_session() as session:
                # Create tasks for all URLs
                tasks = []
                for url, target in zip(url_list, save_paths):
                    task = asyncio.create_task(_download_single(url, target, session))
                    tasks.append((url, target, task))

                # Execute all downloads in parallel
                task_results = await asyncio.gather(*[task for _, _, task in tasks])

                for (url, target, _), result in zip(tasks, task_results):
                    results.append(result)
    except Exception as exc:
        logger.error("web_download failed: %s", exc)
        raise FetchError(f"Download failed: {exc}") from exc

    # Return single result for single URL, or multi-URL format for multiple URLs
    if len(results) == 1:
        return results[0]

    return {
        "status": "downloaded",
        "file_count": len(results),
        "results": results,
        "total_bytes": sum(r.get("bytes", 0) for r in results),
        "success_count": sum(1 for r in results if r["status"] == "downloaded"),
    }


async def _download_single(url: str, target: Path, client) -> dict[str, Any]:
    """Download a single file using the provided HTTP client or session."""
    try:
        try:
            resp = await limited_request(client.get(url, stream=True))
            await client.gather(resp)
            data, content_type = await read_streamed_response(resp)
        except (niquests.exceptions.RequestException, OSError) as exc:
            logger.warning("web_download retry: url=%s err=%s", url, exc)
            resp = await limited_request(client.get(url, stream=True))
            await client.gather(resp)
            data, content_type = await read_streamed_response(resp)

        # Save file
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

        logger.info("web_download: saved %d bytes to %s", len(data), target)
        return {
            "status": "downloaded",
            "url": url,
            "saved_to": str(target),
            "bytes": len(data),
            "content_type": content_type,
        }
    except Exception as exc:
        logger.error("Failed to download %s: %s", url, exc)
        return {
            "status": "error",
            "url": url,
            "error": str(exc),
            "saved_to": "",
            "bytes": 0,
        }


def register_tool(mcp):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_download")
    mcp.tool(
        name="web_download",
        title=tool_title("web_download"),
        description=tool_description("web_download"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_download)
