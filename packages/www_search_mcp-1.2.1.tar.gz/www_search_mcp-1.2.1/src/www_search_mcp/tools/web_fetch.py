"""Web fetch tool implementation."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import niquests

from mcp.server.fastmcp.server import Context

from ..utils.cache import TTLCache, fetch_cache
from ..config import SESSION_ENABLED, TIMEOUT_TOTAL
from ..errors import FetchError, ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..utils.throttle import request_throttle
from ..utils.tool_runtime import tool_timeout
from ..utils import (
    get_http_session,
    limited_request,
    normalize_fetch_div,
    new_ephemeral_async_session,
    process_fetch_response,
    validate_url,
)

logger = logging.getLogger("www-search-mcp")


async def web_fetch(
    urls: str | list[str],
    fetch_div: str = "",
    save_file: str = "",
    use_session: bool = False,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Fetch URLs in parallel."""
    with tool_timeout(TIMEOUT_TOTAL):
        return await _web_fetch_inner(urls, fetch_div, save_file, use_session, ctx)


async def _web_fetch_inner(
    urls: str | list[str],
    fetch_div: str,
    save_file: str,
    use_session: bool,
    ctx: Context | None,
) -> dict[str, Any]:
    # Handle single URL string or list of URLs
    if isinstance(urls, str):
        urls = [validate_url(urls)]
    else:
        urls = [validate_url(url.strip()) for url in urls if url.strip()]

    if not urls:
        raise ValidationError("urls must not be empty")

    # Disable save_file for multiple URLs (would be ambiguous)
    if len(urls) > 1 and save_file:
        raise ValidationError("save_file cannot be used with multiple URLs")

    # Apply narrow, site-specific selector normalization.
    if len(urls) == 1:
        fetch_div = normalize_fetch_div(urls[0], fetch_div)

    session_active = use_session or SESSION_ENABLED
    logger.info(
        "web_fetch: urls=%r fetch_div=%r session=%s", urls, fetch_div, session_active
    )

    # Perform parallel fetches
    results = []

    # Check cache first
    uncached_urls = []
    url_to_cache_key = {}

    for url in urls:
        cache_key = TTLCache.make_key(url, fetch_div, use_session)
        url_to_cache_key[url] = cache_key
        cached = await fetch_cache.aget(cache_key)
        if cached is not None and not save_file:
            results.append(cached)
        else:
            uncached_urls.append(url)

    # Execute fetches for uncached URLs in parallel
    if uncached_urls:
        await request_throttle.await_gap()

        try:
            if session_active:
                client = await get_http_session(ctx)
                fetched = await _fetch_urls_with_client(
                    client, uncached_urls, fetch_div, save_file, url_to_cache_key
                )
                results.extend(fetched)
            else:
                async with new_ephemeral_async_session() as session:
                    fetched = await _fetch_urls_with_client(
                        session, uncached_urls, fetch_div, save_file, url_to_cache_key
                    )
                    results.extend(fetched)
        except Exception as exc:
            logger.error("web_fetch failed: %s", exc)
            raise FetchError(f"Fetch failed: {exc}") from exc

    # Return single result for single URL, or multi-URL format for multiple URLs
    if len(results) == 1:
        return results[0]

    return {
        "status": "ok",
        "url_count": len(results),
        "results": results,
        "total_success": sum(1 for r in results if r["http_status"] < 400),
    }


async def _fetch_urls_with_client(
    client,
    uncached_urls: list[str],
    fetch_div: str,
    save_file: str,
    url_to_cache_key: dict[str, str],
) -> list[dict[str, Any]]:
    """Fetch a list of URLs using the provided HTTP client and return results."""
    tasks = []
    for url in uncached_urls:
        task = asyncio.create_task(limited_request(client.get(url, stream=False)))
        tasks.append((url, task))

    task_results = await asyncio.gather(*[task for _, task in tasks])

    results: list[dict[str, Any]] = []
    for (url, _), resp in zip(tasks, task_results):
        try:
            await client.gather(resp)
            result = await process_fetch_response(
                resp, fetch_div=fetch_div, save_file=save_file
            )
        except (niquests.exceptions.RequestException, OSError) as exc:
            logger.warning("web_fetch retry: url=%s err=%s", url, exc)
            retry_resp = await limited_request(client.get(url, stream=False))
            await client.gather(retry_resp)
            result = await process_fetch_response(
                retry_resp, fetch_div=fetch_div, save_file=save_file
            )
        cache_key = url_to_cache_key[url]
        if not save_file:
            await fetch_cache.aset(cache_key, result)
        results.append(result)

    return results


def register_tool(mcp):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_fetch")
    mcp.tool(
        name="web_fetch",
        title=tool_title("web_fetch"),
        description=tool_description("web_fetch"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_fetch)
