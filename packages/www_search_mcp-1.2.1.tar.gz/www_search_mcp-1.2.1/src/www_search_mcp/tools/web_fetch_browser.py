"""Web browser fetch tool implementation."""

from __future__ import annotations

import asyncio
import logging
from typing import Any


from mcp.server.fastmcp.server import Context

from ..browser import ensure_browser, ensure_browser_context
from ..utils.cache import TTLCache, fetch_cache
from ..config import (
    SESSION_ENABLED,
    TIMEOUT,
    TIMEOUT_TOTAL,
)
from ..errors import BrowserError, ValidationError
from ..utils.html import html_to_markdown
from ..info import tool_description, tool_meta, tool_title
from ..utils.throttle import request_throttle
from ..utils.tool_runtime import tool_timeout
from ..utils import (
    build_fetch_result,
    get_browser_context,
    save_or_return,
    set_browser_context,
    validate_url,
)
from ..utils.ua import pick_ua

logger = logging.getLogger("www-search-mcp")


async def web_fetch_browser(
    urls: str | list[str],
    fetch_div: str = "",
    save_file: str = "",
    headless: bool = True,
    wait_seconds: int = 0,
    use_session: bool = False,
    parallel: bool = False,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Execute the browser fetch."""
    with tool_timeout(TIMEOUT_TOTAL):
        return await _web_fetch_browser_inner(
            urls,
            fetch_div,
            save_file,
            headless,
            wait_seconds,
            use_session,
            parallel,
            ctx,
        )


async def _web_fetch_browser_inner(
    urls: str | list[str],
    fetch_div: str,
    save_file: str,
    headless: bool,
    wait_seconds: int,
    use_session: bool,
    parallel: bool,
    ctx: Context | None,
) -> dict[str, Any]:
    # Handle single URL string or list of URLs
    if isinstance(urls, str):
        urls = [validate_url(urls)]
    else:
        urls = [validate_url(url.strip()) for url in urls if url.strip()]

    if not urls:
        raise ValidationError("urls must not be empty")

    # Disable save_file for multiple URLs (would be ambiguous)
    if len(urls) > 1 and save_file:
        raise ValidationError("save_file cannot be used with multiple URLs")

    # Force serial execution for more than 1 URL unless explicit parallel is requested
    # (Browser resources are limited, parallel may be unstable)
    if len(urls) > 1 and not parallel:
        # Execute URLs one by one
        results = []
        for url in urls:
            result = await _fetch_single_url_browser(
                url, fetch_div, save_file, headless, wait_seconds, use_session, ctx
            )
            results.append(result)

        return {
            "status": "ok",
            "url_count": len(results),
            "results": results,
            "total_success": sum(1 for r in results if r["http_status"] < 400),
        }

    # Single URL or explicit parallel mode
    if parallel:
        # Execute URLs in parallel (use with caution!)
        tasks = []
        for url in urls:
            task = asyncio.create_task(
                _fetch_single_url_browser(
                    url, fetch_div, save_file, headless, wait_seconds, use_session, ctx
                )
            )
            tasks.append(task)

        results = await asyncio.gather(*tasks)

        return {
            "status": "ok",
            "url_count": len(results),
            "results": results,
            "total_success": sum(1 for r in results if r["http_status"] < 400),
        }

    # Single URL case
    return await _fetch_single_url_browser(
        urls[0], fetch_div, save_file, headless, wait_seconds, use_session, ctx
    )


async def _fetch_single_url_browser(
    url: str,
    fetch_div: str,
    save_file: str,
    headless: bool,
    wait_seconds: int,
    use_session: bool,
    ctx: Context | None,
) -> dict[str, Any]:
    """Fetch a single URL using browser."""
    clean_url = url
    session_active = use_session or SESSION_ENABLED
    logger.info(
        "web_fetch_browser: url=%r fetch_div=%r headless=%s wait=%d session=%s",
        clean_url,
        fetch_div,
        headless,
        wait_seconds,
        session_active,
    )

    cache_key = TTLCache.make_key(
        clean_url, fetch_div, headless, wait_seconds, use_session
    )
    cached = await fetch_cache.aget(cache_key)
    if cached is not None and not save_file:
        return cached

    await request_throttle.await_gap()

    html = ""
    page_url = clean_url
    page_title = ""
    http_status = 200
    content_type = ""
    page = None

    try:
        if session_active:
            cached_ctx, cached_headless = await get_browser_context(ctx)
            if cached_ctx is not None and cached_headless == headless:
                context = cached_ctx
            else:
                context = await ensure_browser_context(headless=headless)
                await set_browser_context(
                    ctx, browser_context=context, headless=headless
                )
            page = await context.new_page()
            logger.debug("Using per-session browser context")
        else:
            browser = await ensure_browser(headless=headless)
            page = await browser.new_page()

        ua = pick_ua()
        await page.set_extra_http_headers({"User-Agent": ua})
        page.set_default_timeout(TIMEOUT * 1000)
        resp = await page.goto(clean_url, wait_until="load")

        if wait_seconds > 0:
            await asyncio.sleep(wait_seconds)

        html = await page.content()
        page_url = page.url
        page_title = await page.title()
        http_status = resp.status if resp else 200
        content_type = resp.headers.get("content-type", "") if resp else ""
    except Exception as exc:
        logger.error("web_fetch_browser failed: %s", exc)
        raise BrowserError(
            f"Browser fetch failed: {exc}",
            suggested_action="Ensure Chromium is installed (playwright install chromium) and retry.",
        ) from exc
    finally:
        if page is not None:
            try:
                await page.close()
            except Exception:
                pass

    body, _title = html_to_markdown(html, fetch_div)
    # Prefer Playwright's page.title() over HTML-parsed title (more reliable after JS)
    title = page_title or _title

    # BUG FIX: save_file gets the full body BEFORE truncation
    from ..config import MAX_FETCH_CHARS
    from ..utils.html import clip_text

    saved = save_or_return(
        body, save_file, http_status, page_url or clean_url, content_type, title
    )
    if saved is not None:
        return saved

    body, truncated = clip_text(body, MAX_FETCH_CHARS)

    result = build_fetch_result(
        body=body,
        http_status=http_status,
        url=page_url or clean_url,
        content_type=content_type,
        title=title,
        truncated=truncated,
    )

    await fetch_cache.aset(cache_key, result)
    return result


def register_tool(mcp):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_fetch_browser")
    mcp.tool(
        name="web_fetch_browser",
        title=tool_title("web_fetch_browser"),
        description=tool_description("web_fetch_browser"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_fetch_browser)
