"""GitHub search tool implementation."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..errors import ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..models import WebSearchGithubParams
from ..search import github_search_repos
from ..utils import execute_search

logger = logging.getLogger("www-search-mcp")


async def web_search_github(
    queries: str | list[str],
    max_results: int = WebSearchGithubParams.model_fields["max_results"].default,
) -> dict[str, Any]:
    """Search GitHub repositories for one or more queries in parallel via the GitHub API."""

    # Validate via Pydantic model
    try:
        params = WebSearchGithubParams(queries=queries, max_results=max_results)
    except Exception as exc:
        raise ValidationError(str(exc)) from exc
    queries = params.queries
    max_results = params.max_results

    async def search_func(query: str, max_results: int) -> list[dict[str, Any]]:
        """Execute GitHub search for a single query."""
        logger.info("web_search_github: query=%r max_results=%d", query, max_results)

        items = github_search_repos(query, max_results)

        logger.info("web_search_github: found %d results", len(items))
        return items

    def transform_results(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Transform GitHub API results to our format."""
        return [
            {
                "title": (item.get("name") or "").strip(),
                "url": (item.get("html_url") or "").strip(),
                "description": (item.get("description") or "").strip(),
                "stars": item.get("stargazers_count") or 0,
                "forks": item.get("forks_count") or 0,
                "language": (item.get("language") or "").strip(),
            }
            for item in items
            if isinstance(item, dict)
        ]

    # For GitHub, we'll handle the field transformation manually
    if isinstance(queries, str):
        queries = [queries]

    # Execute search
    result = await execute_search(
        queries=queries,
        max_results=max_results,
        cache_type="github",
        search_func=search_func,
        field_map=None,  # We'll transform manually
    )

    # Transform each query's raw GitHub API items into our stable schema.
    if isinstance(result.get("results"), list) and "query_count" in result:
        for qr in result["results"]:
            if isinstance(qr, dict) and isinstance(qr.get("results"), list):
                qr["results"] = transform_results(qr["results"])  # type: ignore[assignment]
    elif isinstance(result.get("results"), list):
        result["results"] = transform_results(result["results"])  # type: ignore[assignment]

    return result


def register_tool(mcp: FastMCP):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_search_github")
    mcp.tool(
        name="web_search_github",
        title=tool_title("web_search_github"),
        description=tool_description("web_search_github"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_search_github)
