"""Generic HTTP API request tool (REST/GraphQL) with optional load mode."""

from __future__ import annotations

import asyncio
import logging
import time
from collections import Counter
from typing import Any, Literal, cast

import niquests
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.server import Context

from ..config import REQUEST_TOKEN, TIMEOUT_TOTAL
from ..errors import ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..utils import get_http_session, limited_request, validate_url
from ..utils.tool_runtime import tool_timeout
from .web_request_metrics import aggregate_results
from .web_request_payload import build_data_payload, build_json_payload

logger = logging.getLogger("www-search-mcp")

ApiType = Literal["rest", "graphql"]

_ALLOWED_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


def _apply_default_auth(headers: dict[str, str]) -> None:
    """Apply WEB_REQUEST_TOKEN as a default Authorization header.

    If the caller already set Authorization explicitly, it is preserved.
    """
    if any(k.lower() == "authorization" for k in headers):
        return
    if not REQUEST_TOKEN:
        return
    token = REQUEST_TOKEN.strip()
    if not token:
        return
    if " " in token:
        headers["Authorization"] = token
    else:
        headers["Authorization"] = f"Bearer {token}"


async def web_request(
    queries: dict[str, Any] | list[dict[str, Any]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Send REST or GraphQL requests to a known API endpoint.

    You can use it for a single API call or as a lightweight load generator.
    The tool supports batching: pass a list of request specs.

    Request spec fields:
    - type: "rest" | "graphql"
    - method: HTTP method (GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS)
    - url: full http(s) URL
    - headers: object/dict (e.g. Authorization)
    - body:
      - rest: dict/list -> JSON body; string -> raw request body
      - graphql: string -> treated as {"query": <string>}; dict -> sent as-is
    - graphql convenience fields (optional):
      - query: string
      - variables: object/dict
      - operationName: string
    - requests (default 1): controls load test shape
    - concurrency (default 1): number of concurrent async workers (not OS threads)
    - time (seconds, default 0):
      - 0: send exactly requests*concurrency requests as fast as possible
      - >0: run for ~time seconds with best-effort pacing at ~requests*concurrency RPS

    Returned data is aggregated (status counts, HTTP codes, latency percentiles).
    """
    with tool_timeout(TIMEOUT_TOTAL):
        return await _web_request_inner(queries, ctx)


async def _web_request_inner(
    queries: dict[str, Any] | list[dict[str, Any]],
    ctx: Context | None,
) -> dict[str, Any]:
    if isinstance(queries, dict):
        query_list = [queries]
        single = True
    else:
        query_list = list(queries)
        single = False

    if not query_list:
        raise ValidationError("queries must not be empty")

    client = await get_http_session(ctx)
    results: list[dict[str, Any]] = []
    for spec in query_list:
        out = await _run_one_spec(client, spec)
        results.append(out)

    if single:
        return results[0]
    return {
        "status": "ok",
        "query_count": len(results),
        "results": results,
    }


async def _run_one_spec(
    client: niquests.AsyncSession, spec: dict[str, Any]
) -> dict[str, Any]:
    if "threads" in spec:
        raise ValidationError("threads is not supported; use concurrency")

    api_type_raw = str(spec.get("type", "rest")).strip().lower()
    if api_type_raw not in {"rest", "graphql"}:
        raise ValidationError("type must be one of: rest, graphql")
    api_type = cast(ApiType, api_type_raw)

    method = str(spec.get("method", "GET")).strip().upper()
    if method not in _ALLOWED_METHODS:
        raise ValidationError(
            f"method must be one of: {', '.join(sorted(_ALLOWED_METHODS))}"
        )

    url = validate_url(str(spec.get("url", "")))

    requests = int(spec.get("requests", 1) or 1)
    concurrency = int(spec.get("concurrency", 1) or 1)
    if requests < 1:
        raise ValidationError("requests must be >= 1")
    if concurrency < 1:
        raise ValidationError("concurrency must be >= 1")

    duration_seconds = float(spec.get("time", 0) or 0)
    if duration_seconds < 0:
        raise ValidationError("time must be >= 0")

    headers_in = spec.get("headers") or {}
    if not isinstance(headers_in, dict):
        raise ValidationError("headers must be an object (dict)")
    headers = {str(k): str(v) for k, v in headers_in.items()}
    _apply_default_auth(headers)

    body = spec.get("body")
    gql_query = spec.get("query")
    gql_variables = spec.get("variables")
    gql_operation_name = spec.get("operationName")

    if api_type != "graphql" and any(
        v is not None for v in (gql_query, gql_variables, gql_operation_name)
    ):
        raise ValidationError(
            "query/variables/operationName are only valid when type=graphql"
        )

    target_rps: float | None = None
    total_requests: int
    if duration_seconds > 0:
        target_rps = float(requests * concurrency)
        total_requests = int(target_rps * duration_seconds)
        total_requests = max(total_requests, 1)
    else:
        total_requests = requests * concurrency

    status_counts: Counter[str] = Counter()
    http_code_counts: Counter[int] = Counter()
    errors: Counter[str] = Counter()
    latencies_ms: list[float] = []
    max_latency_samples = 20_000

    start = time.perf_counter()
    idx = 0
    idx_lock = asyncio.Lock()

    async def next_index() -> int | None:
        nonlocal idx
        async with idx_lock:
            if idx >= total_requests:
                return None
            v = idx
            idx += 1
            return v

    async def worker() -> None:
        while True:
            i = await next_index()
            if i is None:
                return

            if target_rps is not None and target_rps > 0:
                due = start + (i / target_rps)
                now = time.perf_counter()
                if due > now:
                    await asyncio.sleep(due - now)

            t0 = time.perf_counter()
            try:
                resp = await limited_request(
                    client.request(
                        method,
                        url,
                        headers=headers or None,
                        json=build_json_payload(
                            api_type,
                            body,
                            query=gql_query,
                            variables=gql_variables,
                            operation_name=gql_operation_name,
                        ),
                        data=build_data_payload(api_type, body),
                        stream=False,
                    )
                )
                await client.gather(resp)
                code = int(getattr(resp, "status_code", 0) or 0)
                http_code_counts[code] += 1
                status_counts["ok" if code and code < 400 else "http_error"] += 1

                if total_requests <= 3:
                    text = getattr(resp, "text", "")
                    if callable(text):
                        text = text()
                    if asyncio.iscoroutine(text):
                        text = await text
                    if isinstance(text, str) and text:
                        sample = text[:2000]
                        if sample:
                            out_samples.append(sample)
            except Exception as exc:
                status_counts["error"] += 1
                errors[type(exc).__name__] += 1
            finally:
                dt_ms = (time.perf_counter() - t0) * 1000.0
                if len(latencies_ms) < max_latency_samples:
                    latencies_ms.append(dt_ms)

    out_samples: list[str] = []
    workers = [asyncio.create_task(worker()) for _ in range(concurrency)]
    await asyncio.gather(*workers)
    elapsed_s = time.perf_counter() - start

    return aggregate_results(
        status_counts=status_counts,
        http_code_counts=http_code_counts,
        errors=errors,
        latencies_ms=latencies_ms,
        out_samples=out_samples,
        total_requests=total_requests,
        elapsed_s=elapsed_s,
        api_type=api_type,
        method=method,
        url=url,
        requests=requests,
        concurrency=concurrency,
        duration_seconds=duration_seconds,
    )


def register_tool(mcp: FastMCP) -> None:
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_request")
    mcp.tool(
        name="web_request",
        title=tool_title("web_request"),
        description=tool_description("web_request"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_request)
