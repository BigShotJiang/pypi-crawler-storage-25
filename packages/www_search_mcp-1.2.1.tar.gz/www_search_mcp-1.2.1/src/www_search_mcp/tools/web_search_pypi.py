"""PyPI search tool implementation."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..errors import ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..models import WebSearchPyPIParams
from ..search import pypi_search_async
from ..utils import execute_search

logger = logging.getLogger("www-search-mcp")


async def web_search_pypi(
    queries: str | list[str],
    max_results: int = WebSearchPyPIParams.model_fields["max_results"].default,
) -> dict[str, Any]:
    """Search Python packages on PyPI for one or more queries in parallel."""

    # Validate via Pydantic model
    try:
        params = WebSearchPyPIParams(queries=queries, max_results=max_results)
    except Exception as exc:
        raise ValidationError(str(exc)) from exc
    queries = params.queries
    max_results = params.max_results

    async def search_func(query: str, max_results: int) -> list[dict[str, Any]]:
        """Execute PyPI search for a single query."""
        logger.info("web_search_pypi: query=%r max_results=%d", query, max_results)

        items = await pypi_search_async(query, max_results)

        logger.info("web_search_pypi: found %d results", len(items))
        return items

    # PyPI search already returns formatted results, so we don't need field mapping
    return await execute_search(
        queries=queries,
        max_results=max_results,
        cache_type="pypi",
        search_func=search_func,
        field_map=None,
    )


def register_tool(mcp: FastMCP):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_search_pypi")
    mcp.tool(
        name="web_search_pypi",
        title=tool_title("web_search_pypi"),
        description=tool_description("web_search_pypi"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_search_pypi)
