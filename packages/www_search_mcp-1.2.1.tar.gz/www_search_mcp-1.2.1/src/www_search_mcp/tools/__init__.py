"""Tools module for www-search-mcp package."""

from .web_search import register_tool as register_web_search_tool, web_search
from .web_search_images import (
    register_tool as register_web_search_images_tool,
    web_search_images,
)
from .web_search_github import (
    register_tool as register_web_search_github_tool,
    web_search_github,
)
from .web_search_pypi import (
    register_tool as register_web_search_pypi_tool,
    web_search_pypi,
)
from .web_fetch import register_tool as register_web_fetch_tool, web_fetch
from .web_fetch_browser import (
    register_tool as register_web_fetch_browser_tool,
    web_fetch_browser,
)
from .web_download import register_tool as register_web_download_tool, web_download
from .web_request import register_tool as register_web_request_tool, web_request
from .web_mcp_status import (
    register_tool as register_web_mcp_status_tool,
    web_mcp_status,
)

__all__ = [
    "web_search",
    "web_search_images",
    "web_search_github",
    "web_search_pypi",
    "web_fetch",
    "web_fetch_browser",
    "web_download",
    "web_request",
    "register_web_search_tool",
    "register_web_search_images_tool",
    "register_web_search_github_tool",
    "register_web_search_pypi_tool",
    "register_web_fetch_tool",
    "register_web_fetch_browser_tool",
    "register_web_download_tool",
    "register_web_request_tool",
    "register_web_mcp_status_tool",
    "web_mcp_status",
]
