"""Payload builders for web_request (REST/GraphQL)."""

from __future__ import annotations

from typing import Any, Literal

from ..errors import ValidationError

ApiType = Literal["rest", "graphql"]


def build_json_payload(
    api_type: ApiType,
    body: Any,
    *,
    query: Any,
    variables: Any,
    operation_name: Any,
) -> Any | None:
    """Build the JSON payload for REST or GraphQL requests."""
    if api_type == "graphql":
        if query is not None or variables is not None or operation_name is not None:
            payload: dict[str, Any] = {}
            if query is not None:
                if not isinstance(query, str):
                    raise ValidationError("graphql query must be a string")
                payload["query"] = query
            if variables is not None:
                if not isinstance(variables, dict):
                    raise ValidationError("graphql variables must be an object (dict)")
                payload["variables"] = variables
            if operation_name is not None:
                if not isinstance(operation_name, str):
                    raise ValidationError("graphql operationName must be a string")
                payload["operationName"] = operation_name
            if not payload.get("query"):
                payload["query"] = ""
            return payload

        if body is None:
            return {"query": ""}
        if isinstance(body, str):
            return {"query": body}
        if isinstance(body, dict):
            return body
        raise ValidationError("graphql body must be an object (dict) or a query string")

    if isinstance(body, (dict, list)):
        return body
    return None


def build_data_payload(api_type: ApiType, body: Any) -> Any | None:
    """Build the raw data payload for REST requests (non-JSON bodies)."""
    if api_type == "graphql":
        return None
    if body is None:
        return None
    if isinstance(body, (dict, list)):
        return None
    if isinstance(body, str):
        return body
    return str(body)
