"""Web search tool implementation."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from ..errors import ValidationError
from ..info import tool_description, tool_meta, tool_title
from ..models import WebSearchParams
from ..search import ddg_context, ddg_search
from ..utils import FIELD_MAPS, execute_search

logger = logging.getLogger("www-search-mcp")


async def web_search(
    queries: str | list[str],
    max_results: int = WebSearchParams.model_fields["max_results"].default,
) -> dict[str, Any]:
    """Perform web search for one or more queries in parallel."""

    # Validate via Pydantic model
    try:
        params = WebSearchParams(queries=queries, max_results=max_results)
    except Exception as exc:
        raise ValidationError(str(exc)) from exc
    queries = params.queries
    max_results = params.max_results

    async def search_func(query: str, max_results: int) -> list[dict[str, Any]]:
        """Execute search for a single query."""
        logger.info("web_search: query=%r max_results=%d", query, max_results)

        with ddg_context() as ddgs:
            items = ddg_search(
                query,
                lambda: ddgs.text(query, max_results=max_results, safesearch="off"),
            )

        logger.info("web_search: found %d results", len(items))
        return items

    return await execute_search(
        queries=queries,
        max_results=max_results,
        cache_type="ddg_text",
        search_func=search_func,
        field_map=FIELD_MAPS["text"],
    )


def register_tool(mcp: FastMCP):
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_search")
    mcp.tool(
        name="web_search",
        title=tool_title("web_search"),
        description=tool_description("web_search"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_search)
