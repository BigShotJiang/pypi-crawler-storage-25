"""Metrics aggregation helpers for web_request."""

from __future__ import annotations

from collections import Counter
from typing import Any


def percentile(sorted_values: list[float], p: float) -> float | None:
    """Return the *p*-th percentile of a sorted list."""
    if not sorted_values:
        return None
    if p <= 0:
        return sorted_values[0]
    if p >= 100:
        return sorted_values[-1]
    k = (len(sorted_values) - 1) * (p / 100.0)
    lo = int(k)
    hi = min(lo + 1, len(sorted_values) - 1)
    if lo == hi:
        return sorted_values[lo]
    frac = k - lo
    return sorted_values[lo] * (1.0 - frac) + sorted_values[hi] * frac


def aggregate_results(
    *,
    status_counts: Counter[str],
    http_code_counts: Counter[int],
    errors: Counter[str],
    latencies_ms: list[float],
    out_samples: list[str],
    total_requests: int,
    elapsed_s: float,
    api_type: str,
    method: str,
    url: str,
    requests: int,
    concurrency: int,
    duration_seconds: float,
) -> dict[str, Any]:
    """Build the final aggregated response dict."""
    lat_sorted = sorted(latencies_ms)
    p50 = percentile(lat_sorted, 50)
    p95 = percentile(lat_sorted, 95)
    p99 = percentile(lat_sorted, 99)

    out: dict[str, Any] = {
        "status": "ok",
        "type": api_type,
        "method": method,
        "url": url,
        "requests": requests,
        "concurrency": concurrency,
        "time": duration_seconds,
        "total_requests": total_requests,
        "elapsed_seconds": round(elapsed_s, 6),
        "achieved_rps": round(
            (total_requests / elapsed_s) if elapsed_s > 0 else float(total_requests), 3
        ),
        "status_counts": dict(status_counts),
        "http_status_counts": dict(http_code_counts),
    }
    if errors:
        out["errors"] = dict(errors)
    if latencies_ms:
        out["latency_ms"] = {
            "count": len(latencies_ms),
            "min": round(lat_sorted[0], 3),
            "avg": round(sum(latencies_ms) / len(latencies_ms), 3),
            "p50": round(p50, 3) if p50 is not None else None,
            "p95": round(p95, 3) if p95 is not None else None,
            "p99": round(p99, 3) if p99 is not None else None,
            "max": round(lat_sorted[-1], 3),
            "samples_capped": len(latencies_ms) >= 20000,
        }
    if out_samples:
        out["response_samples"] = out_samples[:3]

    return out
