"""Web MCP status tool — system diagnostics."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
from typing import Any

from importlib.metadata import version as _pkg_version

from ..config import MIN_INTERVAL, REQUEST_LIMIT, SESSION_ENABLED, TIMEOUT_CONFIG
from ..info import tool_description, tool_meta, tool_title
from ..utils.dns import get_dns_resolvers
from ..utils.session_state import get_session_stats
from ..utils.throttle import request_throttle

logger = logging.getLogger("www-search-mcp")

_started_at = time.monotonic()

# Simple request counters (best-effort, no lock for speed).
_total_requests = 0
_total_errors = 0
_total_timeouts = 0


def _bump_request() -> None:
    global _total_requests
    _total_requests += 1


def _bump_error() -> None:
    global _total_errors
    _total_errors += 1


def _bump_timeout() -> None:
    global _total_timeouts
    _total_timeouts += 1


def _get_counters() -> dict[str, int]:
    return {
        "total_requests": _total_requests,
        "total_errors": _total_errors,
        "total_timeouts": _total_timeouts,
    }


def _get_open_fds() -> int:
    try:
        import resource

        soft, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
        return soft
    except Exception:
        return 0


def _get_memory_mb() -> float:
    try:
        import resource

        usage = resource.getrusage(resource.RUSAGE_SELF)
        return round(usage.ru_maxrss / 1024.0, 2)
    except Exception:
        return 0.0


def _get_loop_tasks() -> int:
    try:
        loop = asyncio.get_running_loop()
        return len(asyncio.all_tasks(loop))
    except Exception:
        return 0


def _get_niquests_version() -> str:
    try:
        return _pkg_version("niquests")
    except Exception:
        return "unknown"


def _check_ddgs() -> bool:
    try:
        import ddgs  # noqa: F401

        return True
    except Exception:
        return False


def _check_playwright() -> bool:
    try:
        from playwright.async_api import async_playwright  # noqa: F401

        return True
    except Exception:
        return False


def _build_status_payload() -> dict[str, Any]:
    uptime = time.monotonic() - _started_at

    return {
        "status": "ok",
        "server_name": "www-search-mcp",
        "server_version": _pkg_version_safe(),
        "pid": os.getpid(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "uptime_seconds": round(uptime, 1),
        "throttle": request_throttle.get_stats(),
        "sessions": get_session_stats(),
        "connections": {
            "niquests_version": _get_niquests_version(),
            "pool_connections": REQUEST_LIMIT,
            "pool_maxsize": REQUEST_LIMIT,
        },
        "resources": {
            "open_fd_limit": _get_open_fds(),
            "memory_rss_mb": _get_memory_mb(),
            "event_loop_tasks": _get_loop_tasks(),
        },
        "counters": _get_counters(),
        "dns_resolver_count": len(get_dns_resolvers() or []),
        "config": {
            "transport": os.getenv("WEB_TRANSPORT", "stdio"),
            "session_enabled": SESSION_ENABLED,
            "request_limit": REQUEST_LIMIT,
            "min_interval": MIN_INTERVAL,
            "timeout": {
                "total": TIMEOUT_CONFIG.total,
                "connect": TIMEOUT_CONFIG.connect_timeout,
                "read": TIMEOUT_CONFIG.read_timeout,
            },
        },
        "health": {
            "ddgs_available": _check_ddgs(),
            "playwright_available": _check_playwright(),
        },
    }


def _pkg_version_safe() -> str:
    try:
        return _pkg_version("www-search-mcp")
    except Exception:
        return "unknown"


async def web_mcp_status() -> dict[str, Any]:
    """Return system status and diagnostics."""
    from ..utils.activity import bump_activity

    bump_activity()
    return _build_status_payload()


def register_tool(mcp) -> None:
    """Register the tool with the MCP server."""
    icons, annotations, meta = tool_meta("web_mcp_status")
    mcp.tool(
        name="web_mcp_status",
        title=tool_title("web_mcp_status"),
        description=tool_description("web_mcp_status"),
        icons=icons,
        annotations=annotations,
        meta=meta,
    )(web_mcp_status)


# Convenience for external callers (HTTP routes, etc).
get_status_json = _build_status_payload
