"""Per-session state helpers.

FastMCP provides a request-scoped Context object which includes the underlying
session (transport instance). In stateful HTTP transports (e.g. Streamable HTTP),
that session persists across requests and is the correct boundary for keeping
cookies and browser contexts.

We key state by ``id(ctx.session)`` which is stable for the lifetime of the
server-side session object.
"""

from __future__ import annotations

import asyncio
import logging
from collections import OrderedDict
from dataclasses import dataclass
from time import monotonic
from typing import Any

import niquests

from mcp.server.fastmcp.server import Context

from ..config import REQUEST_LIMIT
from .http_async import _new_async_session


def session_key(ctx: Context | None) -> str:
    """Return a stable per-session key for the current request."""

    if ctx is None:
        return "global"

    sess = ctx.session
    try:
        # Prefer the object's own hash when possible (avoids id() reuse after GC).
        return f"sess:{hash(sess)}"
    except TypeError:
        # Fallback for unhashable session objects.
        return f"sess:{id(sess)}"


@dataclass
class _Entry:
    created_at: float
    last_used_at: float
    http: niquests.AsyncSession
    # Playwright BrowserContext is typed as Any to avoid a hard dependency in utils.
    browser_context: Any | None = None
    browser_headless: bool | None = None


_LOCK = asyncio.Lock()

# Keep a bounded number of sessions. This is a safety valve; the primary lifetime
# is driven by the underlying transport session manager.
_MAX_SESSIONS = max(8, min(REQUEST_LIMIT, 128))
_TTL_SECONDS = 30 * 60.0

_SESSIONS: OrderedDict[str, _Entry] = OrderedDict()

logger = logging.getLogger("www-search-mcp")


def _evict_if_needed(now: float) -> list[_Entry]:
    """Evict stale or excess entries and return them so the caller can close them."""
    dead: list[str] = []
    for k, v in _SESSIONS.items():
        if (now - v.last_used_at) > _TTL_SECONDS:
            dead.append(k)
    evicted: list[_Entry] = []
    for k in dead:
        entry = _SESSIONS.pop(k, None)
        if entry is not None:
            evicted.append(entry)

    while len(_SESSIONS) > _MAX_SESSIONS:
        _, entry = _SESSIONS.popitem(last=False)
        evicted.append(entry)

    return evicted


async def _close_entry(entry: _Entry) -> None:
    """Best-effort close of an evicted entry's HTTP session and browser context."""
    try:
        close = getattr(entry.http, "aclose", None) or getattr(
            entry.http, "close", None
        )
        if close is not None:
            out = close()
            if asyncio.iscoroutine(out):
                await out
    except Exception:
        logger.warning("HTTP session close failed", exc_info=True)

    if entry.browser_context is not None:
        try:
            await entry.browser_context.close()
        except Exception:
            logger.warning("Browser context close failed", exc_info=True)


async def get_http_session(ctx: Context | None) -> niquests.AsyncSession:
    """Get or create a per-session niquests AsyncSession.

    This session is used only when tools request session persistence
    ("use_session" or WEB_SESSION_ENABLED). Non-session mode continues to use
    ephemeral sessions.
    """

    key = session_key(ctx)
    now = monotonic()

    async with _LOCK:
        evicted = _evict_if_needed(now)
        entry = _SESSIONS.get(key)
        if entry is None:
            entry = _Entry(created_at=now, last_used_at=now, http=_new_async_session())
            _SESSIONS[key] = entry
        else:
            entry.last_used_at = now
            _SESSIONS.move_to_end(key)
        http = entry.http

    for e in evicted:
        await _close_entry(e)
    return http


async def set_browser_context(
    ctx: Context | None, *, browser_context: Any, headless: bool
) -> None:
    key = session_key(ctx)
    now = monotonic()
    async with _LOCK:
        evicted = _evict_if_needed(now)
        entry = _SESSIONS.get(key)
        if entry is None:
            entry = _Entry(created_at=now, last_used_at=now, http=_new_async_session())
            _SESSIONS[key] = entry
        entry.last_used_at = now
        entry.browser_context = browser_context
        entry.browser_headless = headless
        _SESSIONS.move_to_end(key)

    for e in evicted:
        await _close_entry(e)


async def get_browser_context(ctx: Context | None) -> tuple[Any | None, bool | None]:
    key = session_key(ctx)
    now = monotonic()
    async with _LOCK:
        evicted = _evict_if_needed(now)
        entry = _SESSIONS.get(key)
        if entry is None:
            result = None, None
        else:
            entry.last_used_at = now
            _SESSIONS.move_to_end(key)
            result = entry.browser_context, entry.browser_headless

    for e in evicted:
        await _close_entry(e)
    return result


async def aclose_all_sessions() -> None:
    """Best-effort close of all per-session HTTP clients and browser contexts."""

    async with _LOCK:
        items = list(_SESSIONS.items())
        _SESSIONS.clear()

    for _, entry in items:
        await _close_entry(entry)


def get_session_stats() -> dict[str, Any]:
    """Return diagnostic stats about active sessions (sync, no lock)."""
    now = monotonic()
    total = len(_SESSIONS)
    with_browser = sum(1 for e in _SESSIONS.values() if e.browser_context is not None)
    stale = sum(1 for e in _SESSIONS.values() if (now - e.last_used_at) > _TTL_SECONDS)
    oldest = min((now - e.last_used_at for e in _SESSIONS.values()), default=0.0)
    return {
        "total_sessions": total,
        "max_sessions": _MAX_SESSIONS,
        "with_browser_context": with_browser,
        "stale_sessions": stale,
        "oldest_idle_seconds": round(oldest, 1),
        "ttl_seconds": _TTL_SECONDS,
    }
