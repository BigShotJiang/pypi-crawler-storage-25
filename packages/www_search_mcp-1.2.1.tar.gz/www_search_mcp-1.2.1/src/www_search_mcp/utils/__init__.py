"""Shared utilities reused across tools.

This package intentionally contains small, focused modules.

Public API:
- Tools may import from ``www_search_mcp.utils`` for convenience.
- Internals should prefer direct imports from the underlying modules.
"""

from __future__ import annotations

# Facade re-exports (keeps call sites stable)
from .fetch_processing import (
    build_fetch_result,
    is_binary_content,
    process_fetch_response,
    read_streamed_response,
    save_full_body,
    save_or_return,
)
from .http_async import (
    get_dns_resolvers,
    limited_request,
    new_ephemeral_async_session,
)
from .session_state import (
    aclose_all_sessions,
    get_browser_context,
    get_http_session,
    set_browser_context,
)
from .paths import normalize_fetch_div, resolve_path, validate_url
from .search_exec import FIELD_MAPS, execute_search

__all__ = [
    # http
    "get_dns_resolvers",
    "limited_request",
    "new_ephemeral_async_session",
    # per-session state
    "aclose_all_sessions",
    "get_http_session",
    "get_browser_context",
    "set_browser_context",
    # fetch/download processing
    "build_fetch_result",
    "is_binary_content",
    "process_fetch_response",
    "read_streamed_response",
    "save_full_body",
    "save_or_return",
    # validation/paths
    "normalize_fetch_div",
    "resolve_path",
    "validate_url",
    # search
    "FIELD_MAPS",
    "execute_search",
]
