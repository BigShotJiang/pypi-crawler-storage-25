"""Search execution helpers shared by search tools."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..errors import ValidationError
from .activity import bump_activity
from .cache import TTLCache, search_cache

logger = logging.getLogger("www-search-mcp")


RESULTS_CAP = 25


def clamp_results(max_results: int) -> int:
    """Clamp max_results to a safe, documented upper bound."""
    return max(1, min(int(max_results), RESULTS_CAP))


FIELD_MAPS: dict[str, dict[str, str]] = {
    "text": {
        "title": "title",
        "url": "href",
        "snippet": "body",
    },
    "images": {
        "title": "title",
        "image": "image",
        "url": "url",
        "thumbnail": "thumbnail",
        "height": "height",
        "width": "width",
        "source": "source",
    },
}


async def execute_search(
    queries: str | list[str],
    max_results: int,
    cache_type: str,
    search_func: Any,
    field_map: dict[str, str] | None = None,
    **search_kwargs,
) -> dict[str, Any]:
    """Execute a search with caching and processing for multiple queries."""
    bump_activity()

    if isinstance(queries, str):
        queries = [queries.strip()]
    else:
        queries = [q.strip() for q in queries if q.strip()]

    if not queries:
        raise ValidationError("queries must not be empty")

    max_results = clamp_results(max_results)
    results: list[dict[str, Any]] = []

    for query in queries:
        cache_key = TTLCache.make_key(cache_type, query, max_results)
        cached = search_cache.get(cache_key)
        if cached is not None:
            results.append(cached)
            continue

        logger.debug("Executing search for query=%r", query)
        try:
            out = search_func(query, max_results=max_results, **search_kwargs)
            items = await out if asyncio.iscoroutine(out) else out
        except Exception as exc:
            logger.error("Search failed for query=%r: %s", query, exc)
            items = []

        if field_map:
            mapped_results = []
            for item in items:
                if not isinstance(item, dict):
                    continue

                mapped_item: dict[str, Any] = {}
                for field, source in field_map.items():
                    value = item.get(source)
                    if isinstance(value, (str, int)):
                        if isinstance(value, str):
                            value = value.strip()
                        mapped_item[field] = value

                cache_type_key = (
                    cache_type.split("_")[-1] if "_" in cache_type else cache_type
                )
                if (
                    cache_type_key == "text"
                    and mapped_item.get("title")
                    and mapped_item.get("url")
                ):
                    mapped_results.append(mapped_item)
                elif cache_type_key == "images" and mapped_item.get("image"):
                    mapped_results.append(mapped_item)
                elif cache_type_key not in ["text", "images"]:
                    mapped_results.append(mapped_item)

            items = mapped_results

        result = {
            "status": "ok",
            "query": query,
            "result_count": len(items),
            "results": items,
        }
        search_cache.set(cache_key, result)
        results.append(result)

    if len(results) == 1:
        return results[0]

    return {
        "status": "ok",
        "query_count": len(results),
        "results": results,
        "total_results": sum(r["result_count"] for r in results),
    }
