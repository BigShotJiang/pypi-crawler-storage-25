"""Helpers for turning HTTP responses into tool payloads."""

from __future__ import annotations

import asyncio
from typing import Any

import niquests

from ..config import MAX_DOWNLOAD_BYTES, MAX_DOWNLOAD_MB, MAX_FETCH_CHARS
from ..errors import BinaryContentError, ContentTooLargeError, HTTPError
from .html import clip_text, html_to_markdown, is_html_response
from .paths import resolve_path


_BINARY_TYPES = frozenset(
    {
        "application/pdf",
        "application/zip",
        "application/gzip",
        "application/octet-stream",
        "application/x-tar",
        "application/x-7z-compressed",
        "application/x-rar-compressed",
    }
)
_BINARY_PREFIXES = ("image/", "video/", "audio/")


def is_binary_content(content_type: str) -> bool:
    """Return True if the content type looks like non-text binary data."""
    ct = content_type.lower().split(";")[0].strip()
    if ct in _BINARY_TYPES:
        return True
    if ct == "image/svg+xml":
        return False
    return any(ct.startswith(p) for p in _BINARY_PREFIXES)


def build_fetch_result(
    body: str,
    http_status: int,
    url: str,
    content_type: str = "",
    title: str = "",
    truncated: bool = False,
) -> dict[str, Any]:
    """Build a standardized fetch result."""
    result: dict[str, Any] = {
        "status": "ok" if http_status < 400 else "http_error",
        "http_status": http_status,
        "url": url,
        "truncated": truncated,
    }
    if title:
        result["title"] = title
    if content_type:
        result["content_type"] = content_type
    result["body"] = body
    return result


def save_full_body(
    body: str, save_file: str, base_result: dict[str, Any]
) -> dict[str, Any]:
    """Save the *full* (pre-truncation) body to disk, return metadata."""
    target = resolve_path(save_file)
    target.parent.mkdir(parents=True, exist_ok=True)
    data = body.encode("utf-8", errors="replace")
    target.write_bytes(data)
    result = {k: v for k, v in base_result.items() if k != "body"}
    result["saved_to"] = str(target)
    result["bytes_written"] = len(data)
    return result


def save_or_return(
    body: str,
    save_file: str,
    http_status: int,
    url: str,
    content_type: str,
    title: str,
) -> dict[str, Any] | None:
    """If *save_file* is set, save full body to disk and return metadata."""
    if not save_file:
        return None
    full_result = build_fetch_result(
        body=body,
        http_status=http_status,
        url=url,
        content_type=content_type,
        title=title,
    )
    return save_full_body(body, save_file, full_result)


async def _response_text(resp: niquests.Response) -> str:
    """Best-effort text extraction for niquests responses."""
    val = getattr(resp, "text", None)
    if isinstance(val, str):
        return val
    if callable(val):
        out = val()
        return await out if asyncio.iscoroutine(out) else str(out)

    content = getattr(resp, "content", None)
    if isinstance(content, (bytes, bytearray)):
        return bytes(content).decode("utf-8", errors="replace")
    if callable(content):
        out = content()
        out = await out if asyncio.iscoroutine(out) else out
        if isinstance(out, (bytes, bytearray)):
            return bytes(out).decode("utf-8", errors="replace")
        return str(out)

    return ""


async def process_fetch_response(
    resp: niquests.Response, fetch_div: str, save_file: str
) -> dict[str, Any]:
    """Convert an HTTP response to a standardized fetch payload."""
    http_status = int(getattr(resp, "status_code", 0) or 0)
    headers = getattr(resp, "headers", {}) or {}
    url = str(getattr(resp, "url", ""))
    content_type = headers.get("content-type", "")

    body = await _response_text(resp)

    if is_binary_content(content_type):
        raise BinaryContentError(
            f"URL returned binary content ({content_type}).",
            suggested_action="Use web_download for binary files (PDFs, images, archives).",
        )

    title = ""
    if is_html_response(content_type, body):
        body, title = html_to_markdown(body, fetch_div)

    saved = save_or_return(body, save_file, http_status, url, content_type, title)
    if saved is not None:
        return saved

    body, truncated = clip_text(body, MAX_FETCH_CHARS)
    return build_fetch_result(
        body=body,
        http_status=http_status,
        url=url,
        content_type=content_type,
        title=title,
        truncated=truncated,
    )


async def read_streamed_response(resp: niquests.Response) -> tuple[bytearray, str]:
    """Read a streamed response with size limits.

    Returns ``(data, content_type)``.
    """
    status_code = int(getattr(resp, "status_code", 0) or 0)
    if status_code >= 400:
        raise HTTPError(
            f"Download failed: HTTP {status_code}",
            status=status_code,
        )

    headers = getattr(resp, "headers", {}) or {}
    content_type = headers.get("content-type", "")

    data = bytearray()
    iterator = resp.iter_content(chunk_size=65536)
    if asyncio.iscoroutine(iterator):
        iterator = await iterator

    async for chunk in iterator:  # type: ignore
        data.extend(chunk)
        if len(data) > MAX_DOWNLOAD_BYTES:
            raise ContentTooLargeError(
                f"File too large: {len(data) / (1024 * 1024):.1f} MB "
                f"(limit {MAX_DOWNLOAD_MB} MB).",
                suggested_action="Increase WEB_MAX_DOWNLOAD_MB or fetch a smaller resource.",
            )

    return data, content_type
