"""Path and URL validation helpers."""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from ..errors import InvalidPathError, InvalidURLError


def validate_url(url: str) -> str:
    """Validate and clean URL."""
    url = url.strip()
    if not url or not (url.startswith("http://") or url.startswith("https://")):
        raise InvalidURLError("url must start with http:// or https://")
    return url


def normalize_fetch_div(url: str, fetch_div: str) -> str:
    """Normalize site-specific selectors.

    Only apply narrowly-scoped fixes to avoid surprising behavior.
    """

    fetch_div = (fetch_div or "").strip()
    if not fetch_div:
        return ""

    host = urlparse(url).netloc.lower()
    if host.endswith("habr.com") and fetch_div == "article-body":
        return ".article-body"

    return fetch_div


def resolve_path(file_path: str) -> Path:
    """Resolve save_file: must have a file extension.

    Relative paths are resolved from the user's home directory.
    """

    p = Path(file_path.strip())
    if not p.suffix:
        raise InvalidPathError(f"save_file must have a file extension: {file_path}")
    if ".." in p.parts:
        raise InvalidPathError(
            f"save_file contains invalid path traversal: {file_path}"
        )
    if not p.is_absolute():
        p = Path.home() / p
    return p.resolve()
