"""Runtime helpers for tool execution.

FastMCP's tool decorator does not currently expose a per-tool timeout parameter.
We use ``anyio.fail_after`` to ensure a tool never hangs longer than
``TIMEOUT_TOTAL`` seconds (plus a small margin).  This is a safety net on
*top* of the niquests connect/read timeouts, because niquests may retry or
follow redirects internally, extending wall-clock time beyond the nominal
config.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import anyio

from ..config import TIMEOUT_TOTAL
from .activity import bump_activity

_MARGIN = 5.0


@contextmanager
def tool_timeout(seconds: float = TIMEOUT_TOTAL + _MARGIN) -> Iterator[None]:
    """Hard deadline for a single tool invocation.

    Keeps the coroutine alive for ``seconds`` wall-clock time.
    If the deadline is exceeded the coroutine is cancelled.
    """
    bump_activity()
    with anyio.fail_after(seconds):
        yield
