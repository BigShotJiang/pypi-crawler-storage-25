"""Activity tracking for idle-timeout detection."""

from __future__ import annotations

import logging
import os
import sys
import threading
import time

logger = logging.getLogger("www-search-mcp")

_LOCK = threading.Lock()
_last_activity = time.monotonic()

_IDLE_TIMER: threading.Timer | None = None


def _env_idle_lifetime() -> float:
    raw = os.getenv("WEB_MCP_IDLE_LIFETIME", "300")
    try:
        val = float(raw)
    except ValueError:
        val = 300.0
    return max(0.0, val)


def _start_idle_timer(lifetime: float) -> None:
    global _IDLE_TIMER
    if _IDLE_TIMER is not None:
        _IDLE_TIMER.cancel()
    if lifetime > 0:
        _IDLE_TIMER = threading.Timer(lifetime, _idle_timeout)
        _IDLE_TIMER.daemon = True
        _IDLE_TIMER.start()


def _idle_timeout() -> None:
    lifetime = _env_idle_lifetime()
    logger.info("Idle timeout after %.0fs, shutting down", lifetime)
    sys.exit(0)


def bump_activity() -> None:
    """Mark the current moment as the last observed activity.

    Thread-safe — safe to call from sync or async code.
    Resets the stdio idle timer when running in stdio mode.
    """
    global _last_activity
    with _LOCK:
        _last_activity = time.monotonic()

    # Reset idle timer for stdio transport
    if os.getenv("WEB_TRANSPORT", "stdio") == "stdio":
        lifetime = _env_idle_lifetime()
        if lifetime > 0:
            _start_idle_timer(lifetime)


def idle_seconds() -> float:
    """Return seconds since the last call to ``bump_activity``."""
    with _LOCK:
        return time.monotonic() - _last_activity
