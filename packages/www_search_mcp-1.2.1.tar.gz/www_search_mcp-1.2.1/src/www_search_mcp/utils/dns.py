"""DNS resolver presets for niquests.

Centralised here so both sync and async stacks share the same resolver
configuration without duplication.
"""

from __future__ import annotations

from ..config import DNS_RESOLVER


def get_dns_resolvers() -> list[str] | None:
    """Return resolver list for niquests.

    Policy:
    - If DNS_RESOLVER == "system": return None -> let niquests use OS resolver.
    - Try DoH first.
    - If DoH is blocked/unavailable, fall back to DoT.
    - Include two IPs (primary + backup) as explicit DNS endpoints.

    Supported formats:
    - DoH: doh://host, doh+cloudflare://, doh+google://
    - DoT: dot://IP, dot://hostname
    - DoQ: doq://hostname (DNS-over-QUIC)
    - Simple DNS: IP address (e.g. "8.8.8.8")
    """

    if DNS_RESOLVER == "system":
        return None

    if DNS_RESOLVER == "cloudflare":
        return [
            "doh+cloudflare://",
            "dot://1.1.1.1",
            "dot://1.0.0.1",
        ]
    if DNS_RESOLVER == "quad9":
        return [
            "doh://dns.quad9.net",
            "doq://dns.quad9.net",
            "dot://9.9.9.9",
            "dot://149.112.112.112",
        ]
    if DNS_RESOLVER == "yandex":
        return [
            "doh://common.dot.dns.yandex.net",
            "dot://common.dot.dns.yandex.net",
            "dot://77.88.8.8",
            "dot://77.88.8.1",
        ]

    # Default: google
    return [
        "doh://dns.google",
        "dot://8.8.8.8",
        "dot://8.8.4.4",
    ]
