"""Request throttling — unified sync/async with a single lock."""

import asyncio
import threading
import time

from ..config import MIN_INTERVAL


class Throttle:
    """Rate-limiter that works for both sync and async callers.

    Uses a single ``threading.Lock`` to protect ``_last_at``.
    The async ``await_gap`` delegates the quick check to the executor
    but sleeps via ``asyncio.sleep`` so the thread pool is never blocked.
    """

    def __init__(self, interval: float = MIN_INTERVAL) -> None:
        self.interval = interval
        self._last_at: float = 0.0
        self._lock = threading.Lock()

    def reset(self) -> None:
        with self._lock:
            self._last_at = 0.0

    def _check_and_update(self) -> float:
        """Return seconds to sleep (0.0 if no wait needed) and update _last_at."""
        with self._lock:
            remaining = self.interval - (time.monotonic() - self._last_at)
            if remaining <= 0:
                self._last_at = time.monotonic()
                return 0.0
            return remaining

    def wait(self) -> None:
        """Synchronous wait — blocks the calling thread."""
        while True:
            remaining = self._check_and_update()
            if remaining <= 0:
                return
            time.sleep(remaining)

    async def await_gap(self) -> None:
        """Asynchronous wait — never blocks the thread pool."""
        loop = asyncio.get_running_loop()
        while True:
            remaining = await loop.run_in_executor(None, self._check_and_update)
            if remaining <= 0:
                return
            await asyncio.sleep(remaining)

    def get_stats(self) -> dict[str, float]:
        """Return diagnostic stats (thread-safe)."""
        with self._lock:
            last_at = self._last_at
        now = time.monotonic()
        return {
            "interval": self.interval,
            "last_request_ago_seconds": round(now - last_at, 3),
            "last_request_at": round(last_at, 3),
        }


request_throttle = Throttle()
