"""Async HTTP primitives (niquests).

This module centralizes:
- standard AsyncSession construction
- the global outbound request semaphore

DNS resolver presets and UA rotation live in ``utils.dns`` and ``utils.ua``
to avoid duplication with the sync stack.

Per-session persistence is implemented in ``utils.session_state``.
"""

from __future__ import annotations

import asyncio
from typing import Any

import niquests

from ..config import (
    PROXY,
    REQUEST_LIMIT,
    TIMEOUT_CONFIG,
    get_ip_version_settings,
    get_ssl_context,
)
from .dns import get_dns_resolvers
from .ua import pick_ua

_REQUEST_SEM = asyncio.Semaphore(REQUEST_LIMIT)


async def limited_request(coro: Any):
    """Run an awaitable under the global request semaphore."""
    async with _REQUEST_SEM:
        return await coro


def _new_async_session() -> niquests.AsyncSession:
    session = niquests.AsyncSession(
        multiplexed=True,
        timeout=TIMEOUT_CONFIG,
        headers={"User-Agent": pick_ua()},
        happy_eyeballs=True,
        resolver=get_dns_resolvers(),
        pool_connections=REQUEST_LIMIT,
        pool_maxsize=REQUEST_LIMIT,
        **get_ip_version_settings(),
    )
    if PROXY:
        session.proxies.update({"http": PROXY, "https": PROXY})
    # niquests typing expects a path/bool here; runtime also accepts SSLContext.
    session.verify = get_ssl_context()  # type: ignore
    return session


def new_ephemeral_async_session() -> niquests.AsyncSession:
    """Create a one-off async session with standard settings."""
    return _new_async_session()
