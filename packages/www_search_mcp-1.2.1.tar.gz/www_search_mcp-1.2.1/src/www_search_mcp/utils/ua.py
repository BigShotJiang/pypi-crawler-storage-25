"""User-Agent rotation helpers.

Provides a single ``pick_ua()`` function used by both sync and async HTTP
stacks so the rotation logic lives in one place.
"""

from __future__ import annotations

import random

from ..config import CHROME_UA, UA_LIST, UA_ROTATION


def pick_ua() -> str:
    """Return a User-Agent string.

    When ``UA_ROTATION`` is enabled and the pool has more than one entry,
    a random UA from ``UA_LIST`` is chosen.  Otherwise the first (default)
    UA is returned.
    """
    if UA_ROTATION and len(UA_LIST) > 1:
        return random.choice(UA_LIST)  # nosec B311: UA rotation, not crypto
    return CHROME_UA
