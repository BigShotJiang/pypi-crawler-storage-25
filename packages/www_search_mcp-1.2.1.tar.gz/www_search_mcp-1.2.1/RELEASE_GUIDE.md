# Release Guide for www-search-mcp

## Semantic Versioning (SemVer)

This project follows [Semantic Versioning](https://semver.org/) with the format `MAJOR.MINOR.PATCH`:

- **MAJOR** version when you make incompatible API changes
- **MINOR** version when you add functionality in a backwards-compatible manner
- **PATCH** version when you make backwards-compatible bug fixes

### Version Examples

- `0.1.0` - Initial development release
- `0.2.0` - New features added, backwards-compatible
- `0.2.1` - Bug fix for 0.2.0
- `1.0.0` - First stable release
- `1.1.0` - Minor feature addition
- `2.0.0` - Breaking changes

### Pre-release Versions

For alpha, beta, and release candidate versions:

- `0.3.0-alpha.1` - First alpha release
- `0.3.0-beta.1` - First beta release
- `0.3.0-rc.1` - First release candidate

## How to Release a New Version

Version is derived automatically from the **git tag** via `hatch-vcs`. No need to edit any files.

### Step 1: Create and Push Tag

```bash
git tag v1.1.0
git push origin v1.1.0
```

### Step 2: CI/CD Pipeline

Once you push the tag, the GitHub Actions CI/CD pipeline will automatically:

1. **Lint** - Run ruff code checks
2. **Test** - Run pytest on multiple Python versions (3.10-3.14)
3. **Build** - Create `.tar.gz` and `.whl` packages with version from the tag
4. **Publish to PyPI** - Upload packages to PyPI
5. **Create GitHub Release** - Create a release with artifacts attached

## Release Notes

GitHub release notes can be formed in two ways:

1. **Auto-generated notes (recommended default)**
GitHub can generate release notes automatically from the commit/PR history between tags.

The generated notes typically include a **Full Changelog** link (compare view between tags).

In this repository, the CI workflow also generates release notes automatically on tag pushes.
It uses GitHub's `releases/generate-notes` API and falls back to `git log` when needed.

2. **Curated notes (manual)**
You write the release notes yourself.

### Auto-generated Notes (UI)

If you create a release manually in the GitHub UI:

1. Go to the new tag (or Releases page)
2. Create/Edit release
3. Click **Generate release notes**

### Auto-generated Notes (CLI)

You can generate notes from the terminal:

```bash
# Create a release from a tag with auto-generated notes
gh release create v1.1.0 --title "v1.1.0" --generate-notes

# If you need to generate notes starting from a specific previous tag:
gh release create v1.1.0 --title "v1.1.0" --generate-notes --notes-start-tag v1.0.3
```

### Why Notes Might Be Missing/Empty

- The release was created without auto-notes (UI button not clicked, or CLI without `--generate-notes`).
- The workflow created the release but the notes are minimal because most work is in a single squash commit.
- The release already existed (e.g. created manually) and the CI job only uploaded artifacts.

### CI-generated Notes (Tag Push)

When you push a tag like `v1.2.3`, the CI/CD workflow will:

1. Determine the previous `v*` tag (best effort)
2. Generate release notes via GitHub API (`POST /repos/{owner}/{repo}/releases/generate-notes`)
3. Ensure the notes contain a `**Full Changelog**: <compare-url>` link
4. Create a GitHub release with `release_notes.md` as the release body

If GitHub's generator output is empty or contains only a `Full Changelog` link, the workflow falls back to `git log`.

### Curated Notes Template

Use this structure when you want human-readable notes:

1. Summary (1-3 bullets)
2. New Tools / Features
3. Behavior Changes (especially anything session/timeouts related)
4. Configuration (new/changed env vars)
5. Testing / Verification

### Manual Verification (Optional)

```bash
# Build the package
rm -rf dist/
uv build

# Check the version
uv run python -c "import www_search_mcp; print(www_search_mcp.__version__)"

# List the output
ls -la dist/
```

> **Note:** Local builds without a git tag will produce a dev version like `0.0.1.dev5`.

## PyPI Publishing

The package is automatically published to PyPI when you push a version tag. 

### Requirements

- You must have publishing permissions for the `www-search-mcp` package on PyPI
- The GitHub repository must be configured with trusted publishing (OIDC) to PyPI

### Manual Publish (if needed)

If automatic publishing fails, you can publish manually:

```bash
# Install twine
uv pip install twine

# Build the package
uv build

# Upload to PyPI
uv run twine upload dist/*
```

You'll need PyPI credentials or an API token.

## GitHub Release Artifacts

Each GitHub release will include:

- **Source code** (automatic from GitHub)
- **`.whl` file** - Wheel package for easy installation
- **`.tar.gz` file** - Source distribution

Users can download and install directly:

```bash
uv pip install www-search-mcp==1.1.0
# or
uv pip install https://github.com/naifs/www-search-mcp/releases/download/v1.1.0/www_search_mcp-1.1.0-py3-none-any.whl
```

## Troubleshooting

### Build Fails

Ensure all dependencies are available and `pyproject.toml` is valid:

```bash
uv sync --all-groups
uv build
```

### PyPI Publish Fails

Check:
- Version number is unique (not already on PyPI)
- You have proper permissions
- Trusted publishing is configured in GitHub repository settings

### Tests Fail

Run tests locally:

```bash
uv sync --all-groups
uv run playwright install chromium
uv run python -m pytest tests/ -v
```

### Lint / Types Fail

The CI pipeline runs formatting checks, linting, and type checking. To reproduce locally:

```bash
uv sync --all-groups
uv run ruff format --check src/ tests/
uv run ruff check src/ tests/
uv run ty check src/
```
