# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
import time

from Tea.exceptions import TeaException, UnretryableException
from Tea.request import TeaRequest
from Tea.core import TeaCore
from antchain_alipay_util.antchain_utils import AntchainUtils
from typing import Dict

from antchain_sdk_sds import models as sds_models
from alibabacloud_tea_util.client import Client as UtilClient
from alibabacloud_tea_util import models as util_models
from alibabacloud_rpc_util.client import Client as RPCUtilClient


class Client:
    _endpoint: str = None
    _region_id: str = None
    _access_key_id: str = None
    _access_key_secret: str = None
    _protocol: str = None
    _user_agent: str = None
    _read_timeout: int = None
    _connect_timeout: int = None
    _http_proxy: str = None
    _https_proxy: str = None
    _socks_5proxy: str = None
    _socks_5net_work: str = None
    _no_proxy: str = None
    _max_idle_conns: int = None
    _security_token: str = None
    _max_idle_time_millis: int = None
    _keep_alive_duration_millis: int = None
    _max_requests: int = None
    _max_requests_per_host: int = None

    def __init__(
        self, 
        config: sds_models.Config,
    ):
        """
        Init client with Config
        @param config: config contains the necessary information to create a client
        """
        if UtilClient.is_unset(config):
            raise TeaException({
                'code': 'ParameterMissing',
                'message': "'config' can not be unset"
            })
        self._access_key_id = config.access_key_id
        self._access_key_secret = config.access_key_secret
        self._security_token = config.security_token
        self._endpoint = config.endpoint
        self._protocol = config.protocol
        self._user_agent = config.user_agent
        self._read_timeout = UtilClient.default_number(config.read_timeout, 20000)
        self._connect_timeout = UtilClient.default_number(config.connect_timeout, 20000)
        self._http_proxy = config.http_proxy
        self._https_proxy = config.https_proxy
        self._no_proxy = config.no_proxy
        self._socks_5proxy = config.socks_5proxy
        self._socks_5net_work = config.socks_5net_work
        self._max_idle_conns = UtilClient.default_number(config.max_idle_conns, 60000)
        self._max_idle_time_millis = UtilClient.default_number(config.max_idle_time_millis, 5)
        self._keep_alive_duration_millis = UtilClient.default_number(config.keep_alive_duration_millis, 5000)
        self._max_requests = UtilClient.default_number(config.max_requests, 100)
        self._max_requests_per_host = UtilClient.default_number(config.max_requests_per_host, 100)

    def do_request(
        self,
        version: str,
        action: str,
        protocol: str,
        method: str,
        pathname: str,
        request: dict,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> dict:
        """
        Encapsulate the request and invoke the network
        @param action: api name
        @param protocol: http or https
        @param method: e.g. GET
        @param pathname: pathname of every api
        @param request: which contains request params
        @param runtime: which controls some details of call api, such as retry times
        @return: the response
        """
        runtime.validate()
        _runtime = {
            'timeouted': 'retry',
            'readTimeout': UtilClient.default_number(runtime.read_timeout, self._read_timeout),
            'connectTimeout': UtilClient.default_number(runtime.connect_timeout, self._connect_timeout),
            'httpProxy': UtilClient.default_string(runtime.http_proxy, self._http_proxy),
            'httpsProxy': UtilClient.default_string(runtime.https_proxy, self._https_proxy),
            'noProxy': UtilClient.default_string(runtime.no_proxy, self._no_proxy),
            'maxIdleConns': UtilClient.default_number(runtime.max_idle_conns, self._max_idle_conns),
            'maxIdleTimeMillis': self._max_idle_time_millis,
            'keepAliveDuration': self._keep_alive_duration_millis,
            'maxRequests': self._max_requests,
            'maxRequestsPerHost': self._max_requests_per_host,
            'retry': {
                'retryable': runtime.autoretry,
                'maxAttempts': UtilClient.default_number(runtime.max_attempts, 3)
            },
            'backoff': {
                'policy': UtilClient.default_string(runtime.backoff_policy, 'no'),
                'period': UtilClient.default_number(runtime.backoff_period, 1)
            },
            'ignoreSSL': runtime.ignore_ssl,
            # 【固定折扣特定信息】
        }
        _last_request = None
        _last_exception = None
        _now = time.time()
        _retry_times = 0
        while TeaCore.allow_retry(_runtime.get('retry'), _retry_times, _now):
            if _retry_times > 0:
                _backoff_time = TeaCore.get_backoff_time(_runtime.get('backoff'), _retry_times)
                if _backoff_time > 0:
                    TeaCore.sleep(_backoff_time)
            _retry_times = _retry_times + 1
            try:
                _request = TeaRequest()
                _request.protocol = UtilClient.default_string(self._protocol, protocol)
                _request.method = method
                _request.pathname = pathname
                _request.query = {
                    'method': action,
                    'version': version,
                    'sign_type': 'HmacSHA1',
                    'req_time': AntchainUtils.get_timestamp(),
                    'req_msg_id': AntchainUtils.get_nonce(),
                    'access_key': self._access_key_id,
                    'base_sdk_version': 'TeaSDK-2.0',
                    'sdk_version': '1.6.0',
                    '_prod_code': 'SDS',
                    '_prod_channel': 'default'
                }
                if not UtilClient.empty(self._security_token):
                    _request.query['security_token'] = self._security_token
                _request.headers = TeaCore.merge({
                    'host': UtilClient.default_string(self._endpoint, 'openapi.antchain.antgroup.com'),
                    'user-agent': UtilClient.get_user_agent(self._user_agent)
                }, headers)
                tmp = UtilClient.anyify_map_value(RPCUtilClient.query(request))
                _request.body = UtilClient.to_form_string(tmp)
                _request.headers['content-type'] = 'application/x-www-form-urlencoded'
                signed_param = TeaCore.merge(_request.query,
                    RPCUtilClient.query(request))
                _request.query['sign'] = AntchainUtils.get_signature(signed_param, self._access_key_secret)
                _last_request = _request
                _response = TeaCore.do_action(_request, _runtime)
                raw = UtilClient.read_as_string(_response.body)
                obj = UtilClient.parse_json(raw)
                res = UtilClient.assert_as_map(obj)
                resp = UtilClient.assert_as_map(res.get('response'))
                if AntchainUtils.has_error(raw, self._access_key_secret):
                    raise TeaException({
                        'message': resp.get('result_msg'),
                        'data': resp,
                        'code': resp.get('result_code')
                    })
                return resp
            except Exception as e:
                if TeaCore.is_retryable(e):
                    _last_exception = e
                    continue
                raise e
        raise UnretryableException(_last_request, _last_exception)

    async def do_request_async(
        self,
        version: str,
        action: str,
        protocol: str,
        method: str,
        pathname: str,
        request: dict,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> dict:
        """
        Encapsulate the request and invoke the network
        @param action: api name
        @param protocol: http or https
        @param method: e.g. GET
        @param pathname: pathname of every api
        @param request: which contains request params
        @param runtime: which controls some details of call api, such as retry times
        @return: the response
        """
        runtime.validate()
        _runtime = {
            'timeouted': 'retry',
            'readTimeout': UtilClient.default_number(runtime.read_timeout, self._read_timeout),
            'connectTimeout': UtilClient.default_number(runtime.connect_timeout, self._connect_timeout),
            'httpProxy': UtilClient.default_string(runtime.http_proxy, self._http_proxy),
            'httpsProxy': UtilClient.default_string(runtime.https_proxy, self._https_proxy),
            'noProxy': UtilClient.default_string(runtime.no_proxy, self._no_proxy),
            'maxIdleConns': UtilClient.default_number(runtime.max_idle_conns, self._max_idle_conns),
            'maxIdleTimeMillis': self._max_idle_time_millis,
            'keepAliveDuration': self._keep_alive_duration_millis,
            'maxRequests': self._max_requests,
            'maxRequestsPerHost': self._max_requests_per_host,
            'retry': {
                'retryable': runtime.autoretry,
                'maxAttempts': UtilClient.default_number(runtime.max_attempts, 3)
            },
            'backoff': {
                'policy': UtilClient.default_string(runtime.backoff_policy, 'no'),
                'period': UtilClient.default_number(runtime.backoff_period, 1)
            },
            'ignoreSSL': runtime.ignore_ssl,
            # 【固定折扣特定信息】
        }
        _last_request = None
        _last_exception = None
        _now = time.time()
        _retry_times = 0
        while TeaCore.allow_retry(_runtime.get('retry'), _retry_times, _now):
            if _retry_times > 0:
                _backoff_time = TeaCore.get_backoff_time(_runtime.get('backoff'), _retry_times)
                if _backoff_time > 0:
                    TeaCore.sleep(_backoff_time)
            _retry_times = _retry_times + 1
            try:
                _request = TeaRequest()
                _request.protocol = UtilClient.default_string(self._protocol, protocol)
                _request.method = method
                _request.pathname = pathname
                _request.query = {
                    'method': action,
                    'version': version,
                    'sign_type': 'HmacSHA1',
                    'req_time': AntchainUtils.get_timestamp(),
                    'req_msg_id': AntchainUtils.get_nonce(),
                    'access_key': self._access_key_id,
                    'base_sdk_version': 'TeaSDK-2.0',
                    'sdk_version': '1.6.0',
                    '_prod_code': 'SDS',
                    '_prod_channel': 'default'
                }
                if not UtilClient.empty(self._security_token):
                    _request.query['security_token'] = self._security_token
                _request.headers = TeaCore.merge({
                    'host': UtilClient.default_string(self._endpoint, 'openapi.antchain.antgroup.com'),
                    'user-agent': UtilClient.get_user_agent(self._user_agent)
                }, headers)
                tmp = UtilClient.anyify_map_value(RPCUtilClient.query(request))
                _request.body = UtilClient.to_form_string(tmp)
                _request.headers['content-type'] = 'application/x-www-form-urlencoded'
                signed_param = TeaCore.merge(_request.query,
                    RPCUtilClient.query(request))
                _request.query['sign'] = AntchainUtils.get_signature(signed_param, self._access_key_secret)
                _last_request = _request
                _response = await TeaCore.async_do_action(_request, _runtime)
                raw = await UtilClient.read_as_string_async(_response.body)
                obj = UtilClient.parse_json(raw)
                res = UtilClient.assert_as_map(obj)
                resp = UtilClient.assert_as_map(res.get('response'))
                if AntchainUtils.has_error(raw, self._access_key_secret):
                    raise TeaException({
                        'message': resp.get('result_msg'),
                        'data': resp,
                        'code': resp.get('result_code')
                    })
                return resp
            except Exception as e:
                if TeaCore.is_retryable(e):
                    _last_exception = e
                    continue
                raise e
        raise UnretryableException(_last_request, _last_exception)

    def judge_crowd_preferment(
        self,
        request: sds_models.JudgeCrowdPrefermentRequest,
    ) -> sds_models.JudgeCrowdPrefermentResponse:
        """
        Description: 根据人维度的业务号和城市，决定是否优待人群，业务号可以是不同类型的，可以是手机号，也可以是证件号，如果业务号是敏感数据，可以选择算法类型加密传输。
        Summary: 优待人群判断
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.judge_crowd_preferment_ex(request, headers, runtime)

    async def judge_crowd_preferment_async(
        self,
        request: sds_models.JudgeCrowdPrefermentRequest,
    ) -> sds_models.JudgeCrowdPrefermentResponse:
        """
        Description: 根据人维度的业务号和城市，决定是否优待人群，业务号可以是不同类型的，可以是手机号，也可以是证件号，如果业务号是敏感数据，可以选择算法类型加密传输。
        Summary: 优待人群判断
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.judge_crowd_preferment_ex_async(request, headers, runtime)

    def judge_crowd_preferment_ex(
        self,
        request: sds_models.JudgeCrowdPrefermentRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.JudgeCrowdPrefermentResponse:
        """
        Description: 根据人维度的业务号和城市，决定是否优待人群，业务号可以是不同类型的，可以是手机号，也可以是证件号，如果业务号是敏感数据，可以选择算法类型加密传输。
        Summary: 优待人群判断
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.JudgeCrowdPrefermentResponse(),
            self.do_request('1.0', 'antchain.sds.crowd.preferment.judge', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def judge_crowd_preferment_ex_async(
        self,
        request: sds_models.JudgeCrowdPrefermentRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.JudgeCrowdPrefermentResponse:
        """
        Description: 根据人维度的业务号和城市，决定是否优待人群，业务号可以是不同类型的，可以是手机号，也可以是证件号，如果业务号是敏感数据，可以选择算法类型加密传输。
        Summary: 优待人群判断
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.JudgeCrowdPrefermentResponse(),
            await self.do_request_async('1.0', 'antchain.sds.crowd.preferment.judge', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def submit_scenedata_task(
        self,
        request: sds_models.SubmitScenedataTaskRequest,
    ) -> sds_models.SubmitScenedataTaskResponse:
        """
        Description: 客户上传文件以及参数，创建任务，获取批次号异步查询处理结果。
        Summary: 场景数据批处理任务提交
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.submit_scenedata_task_ex(request, headers, runtime)

    async def submit_scenedata_task_async(
        self,
        request: sds_models.SubmitScenedataTaskRequest,
    ) -> sds_models.SubmitScenedataTaskResponse:
        """
        Description: 客户上传文件以及参数，创建任务，获取批次号异步查询处理结果。
        Summary: 场景数据批处理任务提交
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.submit_scenedata_task_ex_async(request, headers, runtime)

    def submit_scenedata_task_ex(
        self,
        request: sds_models.SubmitScenedataTaskRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.SubmitScenedataTaskResponse:
        """
        Description: 客户上传文件以及参数，创建任务，获取批次号异步查询处理结果。
        Summary: 场景数据批处理任务提交
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.SubmitScenedataTaskResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.task.submit', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def submit_scenedata_task_ex_async(
        self,
        request: sds_models.SubmitScenedataTaskRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.SubmitScenedataTaskResponse:
        """
        Description: 客户上传文件以及参数，创建任务，获取批次号异步查询处理结果。
        Summary: 场景数据批处理任务提交
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.SubmitScenedataTaskResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.task.submit', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def upload_scenedata_file(
        self,
        request: sds_models.UploadScenedataFileRequest,
    ) -> sds_models.UploadScenedataFileResponse:
        """
        Description: 批次数据文件上传
        Summary: 批次数据文件上传
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.upload_scenedata_file_ex(request, headers, runtime)

    async def upload_scenedata_file_async(
        self,
        request: sds_models.UploadScenedataFileRequest,
    ) -> sds_models.UploadScenedataFileResponse:
        """
        Description: 批次数据文件上传
        Summary: 批次数据文件上传
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.upload_scenedata_file_ex_async(request, headers, runtime)

    def upload_scenedata_file_ex(
        self,
        request: sds_models.UploadScenedataFileRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.UploadScenedataFileResponse:
        """
        Description: 批次数据文件上传
        Summary: 批次数据文件上传
        """
        if not UtilClient.is_unset(request.file_object):
            upload_req = sds_models.CreateAntcloudGatewayxFileUploadRequest(
                auth_token=request.auth_token,
                api_code='antchain.sds.scenedata.file.upload',
                file_name=request.file_object_name
            )
            upload_resp = self.create_antcloud_gatewayx_file_upload_ex(upload_req, headers, runtime)
            if not AntchainUtils.is_success(upload_resp.result_code, 'ok'):
                upload_scenedata_file_response = sds_models.UploadScenedataFileResponse(
                    req_msg_id=upload_resp.req_msg_id,
                    result_code=upload_resp.result_code,
                    result_msg=upload_resp.result_msg
                )
                return upload_scenedata_file_response
            upload_headers = AntchainUtils.parse_upload_headers(upload_resp.upload_headers)
            AntchainUtils.put_object(request.file_object, upload_headers, upload_resp.upload_url)
            request.file_id = upload_resp.file_id
            request.file_object = None
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.UploadScenedataFileResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.file.upload', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def upload_scenedata_file_ex_async(
        self,
        request: sds_models.UploadScenedataFileRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.UploadScenedataFileResponse:
        """
        Description: 批次数据文件上传
        Summary: 批次数据文件上传
        """
        if not UtilClient.is_unset(request.file_object):
            upload_req = sds_models.CreateAntcloudGatewayxFileUploadRequest(
                auth_token=request.auth_token,
                api_code='antchain.sds.scenedata.file.upload',
                file_name=request.file_object_name
            )
            upload_resp = await self.create_antcloud_gatewayx_file_upload_ex_async(upload_req, headers, runtime)
            if not AntchainUtils.is_success(upload_resp.result_code, 'ok'):
                upload_scenedata_file_response = sds_models.UploadScenedataFileResponse(
                    req_msg_id=upload_resp.req_msg_id,
                    result_code=upload_resp.result_code,
                    result_msg=upload_resp.result_msg
                )
                return upload_scenedata_file_response
            upload_headers = AntchainUtils.parse_upload_headers(upload_resp.upload_headers)
            await AntchainUtils.put_object_async(request.file_object, upload_headers, upload_resp.upload_url)
            request.file_id = upload_resp.file_id
            request.file_object = None
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.UploadScenedataFileResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.file.upload', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def batchquery_scenedata_taskresult(
        self,
        request: sds_models.BatchqueryScenedataTaskresultRequest,
    ) -> sds_models.BatchqueryScenedataTaskresultResponse:
        """
        Description: 场景数据SaaS第一天预处理客户提交的文件处理任务，第二天客户调该接口批量查询任务结果
        Summary: 场景数据任务结果批量查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.batchquery_scenedata_taskresult_ex(request, headers, runtime)

    async def batchquery_scenedata_taskresult_async(
        self,
        request: sds_models.BatchqueryScenedataTaskresultRequest,
    ) -> sds_models.BatchqueryScenedataTaskresultResponse:
        """
        Description: 场景数据SaaS第一天预处理客户提交的文件处理任务，第二天客户调该接口批量查询任务结果
        Summary: 场景数据任务结果批量查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.batchquery_scenedata_taskresult_ex_async(request, headers, runtime)

    def batchquery_scenedata_taskresult_ex(
        self,
        request: sds_models.BatchqueryScenedataTaskresultRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.BatchqueryScenedataTaskresultResponse:
        """
        Description: 场景数据SaaS第一天预处理客户提交的文件处理任务，第二天客户调该接口批量查询任务结果
        Summary: 场景数据任务结果批量查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.BatchqueryScenedataTaskresultResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.taskresult.batchquery', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def batchquery_scenedata_taskresult_ex_async(
        self,
        request: sds_models.BatchqueryScenedataTaskresultRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.BatchqueryScenedataTaskresultResponse:
        """
        Description: 场景数据SaaS第一天预处理客户提交的文件处理任务，第二天客户调该接口批量查询任务结果
        Summary: 场景数据任务结果批量查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.BatchqueryScenedataTaskresultResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.taskresult.batchquery', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def query_scenedata_online(
        self,
        request: sds_models.QueryScenedataOnlineRequest,
    ) -> sds_models.QueryScenedataOnlineResponse:
        """
        Description: 场景数据在线查询，仅支持单条匹配
        Summary: 场景数据在线查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.query_scenedata_online_ex(request, headers, runtime)

    async def query_scenedata_online_async(
        self,
        request: sds_models.QueryScenedataOnlineRequest,
    ) -> sds_models.QueryScenedataOnlineResponse:
        """
        Description: 场景数据在线查询，仅支持单条匹配
        Summary: 场景数据在线查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.query_scenedata_online_ex_async(request, headers, runtime)

    def query_scenedata_online_ex(
        self,
        request: sds_models.QueryScenedataOnlineRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataOnlineResponse:
        """
        Description: 场景数据在线查询，仅支持单条匹配
        Summary: 场景数据在线查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataOnlineResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.online.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def query_scenedata_online_ex_async(
        self,
        request: sds_models.QueryScenedataOnlineRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataOnlineResponse:
        """
        Description: 场景数据在线查询，仅支持单条匹配
        Summary: 场景数据在线查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataOnlineResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.online.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def query_scenedata_taskinfo(
        self,
        request: sds_models.QueryScenedataTaskinfoRequest,
    ) -> sds_models.QueryScenedataTaskinfoResponse:
        """
        Description: 通过批次号查询任务详细信息
        Summary: 批次任务信息查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.query_scenedata_taskinfo_ex(request, headers, runtime)

    async def query_scenedata_taskinfo_async(
        self,
        request: sds_models.QueryScenedataTaskinfoRequest,
    ) -> sds_models.QueryScenedataTaskinfoResponse:
        """
        Description: 通过批次号查询任务详细信息
        Summary: 批次任务信息查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.query_scenedata_taskinfo_ex_async(request, headers, runtime)

    def query_scenedata_taskinfo_ex(
        self,
        request: sds_models.QueryScenedataTaskinfoRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataTaskinfoResponse:
        """
        Description: 通过批次号查询任务详细信息
        Summary: 批次任务信息查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataTaskinfoResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.taskinfo.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def query_scenedata_taskinfo_ex_async(
        self,
        request: sds_models.QueryScenedataTaskinfoRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataTaskinfoResponse:
        """
        Description: 通过批次号查询任务详细信息
        Summary: 批次任务信息查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataTaskinfoResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.taskinfo.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def query_scenedata_dws(
        self,
        request: sds_models.QueryScenedataDwsRequest,
    ) -> sds_models.QueryScenedataDwsResponse:
        """
        Description: 批次计算结果聚合，任务为ready状态时，返回分页列表数据
        Summary: 批次结果聚合查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.query_scenedata_dws_ex(request, headers, runtime)

    async def query_scenedata_dws_async(
        self,
        request: sds_models.QueryScenedataDwsRequest,
    ) -> sds_models.QueryScenedataDwsResponse:
        """
        Description: 批次计算结果聚合，任务为ready状态时，返回分页列表数据
        Summary: 批次结果聚合查询
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.query_scenedata_dws_ex_async(request, headers, runtime)

    def query_scenedata_dws_ex(
        self,
        request: sds_models.QueryScenedataDwsRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataDwsResponse:
        """
        Description: 批次计算结果聚合，任务为ready状态时，返回分页列表数据
        Summary: 批次结果聚合查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataDwsResponse(),
            self.do_request('1.0', 'antchain.sds.scenedata.dws.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def query_scenedata_dws_ex_async(
        self,
        request: sds_models.QueryScenedataDwsRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryScenedataDwsResponse:
        """
        Description: 批次计算结果聚合，任务为ready状态时，返回分页列表数据
        Summary: 批次结果聚合查询
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryScenedataDwsResponse(),
            await self.do_request_async('1.0', 'antchain.sds.scenedata.dws.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def query_favor_stocks(
        self,
        request: sds_models.QueryFavorStocksRequest,
    ) -> sds_models.QueryFavorStocksResponse:
        """
        Description: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        Summary: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.query_favor_stocks_ex(request, headers, runtime)

    async def query_favor_stocks_async(
        self,
        request: sds_models.QueryFavorStocksRequest,
    ) -> sds_models.QueryFavorStocksResponse:
        """
        Description: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        Summary: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.query_favor_stocks_ex_async(request, headers, runtime)

    def query_favor_stocks_ex(
        self,
        request: sds_models.QueryFavorStocksRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryFavorStocksResponse:
        """
        Description: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        Summary: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryFavorStocksResponse(),
            self.do_request('1.0', 'antchain.sds.favor.stocks.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def query_favor_stocks_ex_async(
        self,
        request: sds_models.QueryFavorStocksRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.QueryFavorStocksResponse:
        """
        Description: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        Summary: 微信批次分页条件查询。通过此接口可查询商家多个批次的信息，包括批次的配置信息以及批次概况数据。
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.QueryFavorStocksResponse(),
            await self.do_request_async('1.0', 'antchain.sds.favor.stocks.query', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def download_stock_useflow(
        self,
        request: sds_models.DownloadStockUseflowRequest,
    ) -> sds_models.DownloadStockUseflowResponse:
        """
        Description: 微信核销账单接口
        Summary: 微信核销账单接口
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.download_stock_useflow_ex(request, headers, runtime)

    async def download_stock_useflow_async(
        self,
        request: sds_models.DownloadStockUseflowRequest,
    ) -> sds_models.DownloadStockUseflowResponse:
        """
        Description: 微信核销账单接口
        Summary: 微信核销账单接口
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.download_stock_useflow_ex_async(request, headers, runtime)

    def download_stock_useflow_ex(
        self,
        request: sds_models.DownloadStockUseflowRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.DownloadStockUseflowResponse:
        """
        Description: 微信核销账单接口
        Summary: 微信核销账单接口
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.DownloadStockUseflowResponse(),
            self.do_request('1.0', 'antchain.sds.stock.useflow.download', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def download_stock_useflow_ex_async(
        self,
        request: sds_models.DownloadStockUseflowRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.DownloadStockUseflowResponse:
        """
        Description: 微信核销账单接口
        Summary: 微信核销账单接口
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.DownloadStockUseflowResponse(),
            await self.do_request_async('1.0', 'antchain.sds.stock.useflow.download', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def download_stock_refundflow(
        self,
        request: sds_models.DownloadStockRefundflowRequest,
    ) -> sds_models.DownloadStockRefundflowResponse:
        """
        Description: 微信退款账单接口
        Summary: 微信退款账单接口
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.download_stock_refundflow_ex(request, headers, runtime)

    async def download_stock_refundflow_async(
        self,
        request: sds_models.DownloadStockRefundflowRequest,
    ) -> sds_models.DownloadStockRefundflowResponse:
        """
        Description: 微信退款账单接口
        Summary: 微信退款账单接口
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.download_stock_refundflow_ex_async(request, headers, runtime)

    def download_stock_refundflow_ex(
        self,
        request: sds_models.DownloadStockRefundflowRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.DownloadStockRefundflowResponse:
        """
        Description: 微信退款账单接口
        Summary: 微信退款账单接口
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.DownloadStockRefundflowResponse(),
            self.do_request('1.0', 'antchain.sds.stock.refundflow.download', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def download_stock_refundflow_ex_async(
        self,
        request: sds_models.DownloadStockRefundflowRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.DownloadStockRefundflowResponse:
        """
        Description: 微信退款账单接口
        Summary: 微信退款账单接口
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.DownloadStockRefundflowResponse(),
            await self.do_request_async('1.0', 'antchain.sds.stock.refundflow.download', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    def create_antcloud_gatewayx_file_upload(
        self,
        request: sds_models.CreateAntcloudGatewayxFileUploadRequest,
    ) -> sds_models.CreateAntcloudGatewayxFileUploadResponse:
        """
        Description: 创建HTTP PUT提交的文件上传
        Summary: 文件上传创建
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return self.create_antcloud_gatewayx_file_upload_ex(request, headers, runtime)

    async def create_antcloud_gatewayx_file_upload_async(
        self,
        request: sds_models.CreateAntcloudGatewayxFileUploadRequest,
    ) -> sds_models.CreateAntcloudGatewayxFileUploadResponse:
        """
        Description: 创建HTTP PUT提交的文件上传
        Summary: 文件上传创建
        """
        runtime = util_models.RuntimeOptions()
        headers = {}
        return await self.create_antcloud_gatewayx_file_upload_ex_async(request, headers, runtime)

    def create_antcloud_gatewayx_file_upload_ex(
        self,
        request: sds_models.CreateAntcloudGatewayxFileUploadRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.CreateAntcloudGatewayxFileUploadResponse:
        """
        Description: 创建HTTP PUT提交的文件上传
        Summary: 文件上传创建
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.CreateAntcloudGatewayxFileUploadResponse(),
            self.do_request('1.0', 'antcloud.gatewayx.file.upload.create', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )

    async def create_antcloud_gatewayx_file_upload_ex_async(
        self,
        request: sds_models.CreateAntcloudGatewayxFileUploadRequest,
        headers: Dict[str, str],
        runtime: util_models.RuntimeOptions,
    ) -> sds_models.CreateAntcloudGatewayxFileUploadResponse:
        """
        Description: 创建HTTP PUT提交的文件上传
        Summary: 文件上传创建
        """
        UtilClient.validate_model(request)
        return TeaCore.from_map(
            sds_models.CreateAntcloudGatewayxFileUploadResponse(),
            await self.do_request_async('1.0', 'antcloud.gatewayx.file.upload.create', 'HTTPS', 'POST', f'/gateway.do', TeaCore.to_map(request), headers, runtime)
        )
