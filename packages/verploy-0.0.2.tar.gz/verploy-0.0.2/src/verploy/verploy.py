import os
import subprocess
from pathlib import Path
from textwrap import dedent
from typing import Annotated

import typer
from pl_mocks_and_fakes import MockInUnitTests, MockReason
from pl_run_program import (
    SimpleProgramError,
    run_simple_program,
)
from pl_tiny_clients.git_push import git_push
from pl_user_io.display import display

from verploy._constants import GIT_PROGRAM

MAIN_BRANCH = "main"
GIT_CREDENTIALS = Path.home() / ".git-credentials"

app = typer.Typer()


@MockInUnitTests(MockReason.UNMITIGATED_SIDE_EFFECT)
def git_credentials_present() -> bool:
    return GIT_CREDENTIALS.exists()  # pragma: no cover


def _detect_worktree(cwd: Path) -> tuple[Path | None, Path]:  # pragma: no cover
    git_dir = (cwd / _git(cwd, "rev-parse", "--git-dir").strip()).resolve()
    git_common_dir = (
        cwd / _git(cwd, "rev-parse", "--git-common-dir").strip()
    ).resolve()
    if git_dir != git_common_dir:
        worktree = Path(_git(cwd, "rev-parse", "--show-toplevel").strip())
        repo_dir = git_common_dir.parent
        return worktree, repo_dir
    return None, cwd


@app.callback()
def verploy(  # pragma: no cover
    ctx: typer.Context,
    worktree: Annotated[Path | None, typer.Option("--worktree", "-w")] = None,
    repo_dir: Annotated[Path | None, typer.Option()] = None,
) -> None:
    if worktree is None and repo_dir is None:
        worktree, repo_dir = _detect_worktree(Path.cwd())
    elif repo_dir is None:
        repo_dir = Path.cwd()
    ctx.obj = (worktree, repo_dir)


def _validate_verploy_dir(
    repo_dir: Path,
) -> tuple[Path | None, Path | None, Path | None]:
    verify_script = repo_dir / ".verploy" / "verify"
    deploy_script = repo_dir / ".verploy" / "deploy"
    manual_file = repo_dir / ".verploy" / "manual"
    if not verify_script.exists():
        display("No verify script found, skipping verification.")
        verify_script = None
    if not deploy_script.exists():
        display("No deploy script found, skipping deploy.")
        deploy_script = None
    if not manual_file.exists():
        display("No manual script found, skipping manual checks.")
        manual_file = None
    return verify_script, deploy_script, manual_file


@app.command("verify")
def verify_cmd(ctx: typer.Context) -> None:  # pragma: no cover
    worktree, repo_dir = ctx.obj
    verify(repo_dir, worktree)


@app.command("deploy")
def deploy_cmd(ctx: typer.Context) -> None:  # pragma: no cover
    worktree, repo_dir = ctx.obj
    deploy(repo_dir, worktree)


def _resolve_worktree(worktree: Path | str | None, repo_dir: Path) -> Path | None:
    if worktree is None:
        return None
    name = str(worktree)
    output = _git(repo_dir, "worktree", "list", "--porcelain")
    for line in output.splitlines():
        if line.startswith("worktree "):
            path = Path(line.removeprefix("worktree "))
            if path.name == name:
                return path
    worktree_path = Path(worktree)
    if worktree_path.exists():
        return worktree_path
    msg = f"No worktree found matching '{name}'"
    raise RuntimeError(msg)


def verify(
    repo_dir: Path,
    worktree: Path | str | None = None,
) -> None:
    worktree = _resolve_worktree(worktree, repo_dir)
    verify_script, _deploy_script, _manual_file = _validate_verploy_dir(repo_dir)

    if worktree is not None:
        _verploy_worktree(worktree, repo_dir, verify_script, None, verify=True)
    else:
        _verploy_main(repo_dir, verify_script, None, verify=True)

    display(
        "Verified. Tell the user to run `verploy deploy` to finish deployment. "
        "If they reject, make edits and continue using `verploy verify`."
    )


def deploy(
    repo_dir: Path,
    worktree: Path | str | None = None,
) -> None:
    worktree = _resolve_worktree(worktree, repo_dir)
    if not git_credentials_present():
        msg = f"Missing {GIT_CREDENTIALS}"
        raise RuntimeError(msg)
    if worktree is not None and _is_mid_rebase(worktree):
        msg = "Rebase conflict. Resolve conflicts and run `verploy verify` first."
        raise RuntimeError(msg)
    verify_script, deploy_script, manual_script = _validate_verploy_dir(repo_dir)

    if worktree is not None:
        _verploy_worktree(
            worktree, repo_dir, verify_script, manual_script, verify=False
        )
    else:
        _verploy_main(repo_dir, verify_script, manual_script, verify=False)

    display("Pushing...")
    git_push()

    if deploy_script is not None:
        display(f"Deploying ({deploy_script})...")
        _run_deploy(deploy_script, repo_dir)
        display("Deployed.")


def _require_changes(repo_dir: Path) -> None:
    if not _git(repo_dir, "status", "--porcelain").strip():
        msg = f"Repository at {repo_dir} has no changes to verploy."
        raise RuntimeError(msg)


def _verploy_main(
    repo_dir: Path,
    verify_script: Path | None,
    manual_script: Path | None,
    verify: bool,
) -> None:
    _require_changes(repo_dir)

    if verify_script is not None:
        display(f"Running verification ({verify_script})...")
        _run_verify(verify_script, repo_dir)

    if manual_script is not None:
        _run_manual_checks(manual_script, repo_dir)

    if verify:
        return

    display("Committing changes...")
    _git(repo_dir, "add", "-A")
    _git(repo_dir, "commit", "-m", "Commit")


def _is_mid_rebase(worktree: Path) -> bool:
    git_dir = Path(_git(worktree, "rev-parse", "--git-dir").strip())
    return (git_dir / "rebase-merge").is_dir() or (git_dir / "rebase-apply").is_dir()


def _resume_rebase(worktree: Path) -> None:
    display("Resuming rebase...")
    try:
        _git(worktree, "diff", "--check")
    except SimpleProgramError:
        _git(worktree, "rebase", "--abort")
        msg = "Conflict markers remain; rebase aborted."
        raise RuntimeError(msg) from None
    _git(worktree, "add", "-A")
    _git(worktree, "-c", "core.editor=/bin/true", "rebase", "--continue")


def _commit_and_rebase(worktree: Path, repo_dir: Path) -> None:
    if _git(repo_dir, "status", "--porcelain").strip():
        msg = f"Repository at {repo_dir} is dirty. Commit or stash changes first."
        raise RuntimeError(msg)

    if _is_mid_rebase(worktree):
        _resume_rebase(worktree)
    else:
        display("Committing worktree changes...")
        _git(worktree, "add", "-A")
        _git(worktree, "commit", "-m", "Commit")

        display(f"Rebasing onto {MAIN_BRANCH}...")
        try:
            _git(worktree, "rebase", MAIN_BRANCH)
        except SimpleProgramError:
            msg = (
                f"Rebase conflict in {worktree}. "
                "Resolve the conflict markers by editing the affected files. "
                "Do NOT run any git commands — verploy will handle staging "
                "and completing the rebase. When done, re-run `verploy verify` to resume."
            )
            raise RuntimeError(msg) from None


def _verploy_worktree(
    worktree: Path,
    repo_dir: Path,
    verify_script: Path | None,
    manual_script: Path | None,
    verify: bool,
) -> None:
    _commit_and_rebase(worktree, repo_dir)

    if verify_script is not None:
        display(f"Running verification ({verify_script})...")
        try:
            _run_verify(verify_script, worktree)
        except RuntimeError:
            _undo_auto_commit(worktree)
            raise

    if manual_script is not None:
        try:
            _run_manual_checks(manual_script, worktree)
        except RuntimeError:
            _undo_auto_commit(worktree)
            raise

    if verify:
        _undo_auto_commit(worktree)
        return

    _amend_auto_fixes(worktree)

    branch = _git(worktree, "branch", "--show-current").strip()
    display(f"Fast-forward merging {branch} into {MAIN_BRANCH}...")
    _git(repo_dir, "merge", "--ff-only", branch)


def _run_manual_checks(manual_script: Path, cwd: Path) -> None:
    display(
        dedent(f"""\

        All automated verification passed.
        Running manual checks ({manual_script})...
    """)
    )
    result = subprocess.run(
        [str(manual_script)], cwd=cwd, env=dict(os.environ), check=False
    )
    if result.returncode != 0:
        msg = "Manual checks failed."
        raise RuntimeError(msg)


def _run_verify(verify_script: Path, cwd: Path) -> None:
    result = subprocess.run(
        [str(verify_script)], cwd=cwd, env=dict(os.environ), check=False
    )
    if result.returncode != 0:
        msg = f"Verification failed with return code {result.returncode}."
        raise RuntimeError(msg)


def _run_deploy(deploy_script: Path, cwd: Path) -> None:
    result = subprocess.run(
        [str(deploy_script)], cwd=cwd, env=dict(os.environ), check=False
    )
    if result.returncode != 0:
        msg = f"Deploy failed with return code {result.returncode}."
        raise RuntimeError(msg)


def _amend_auto_fixes(worktree: Path) -> None:
    if _git(worktree, "status", "--porcelain").strip():
        _git(worktree, "add", "-A")
        _git(worktree, "commit", "--amend", "--no-edit")


def _undo_auto_commit(worktree: Path) -> None:
    """Revert verploy's own commit so the agent's edits remain in the worktree as unstaged changes."""
    _git(worktree, "reset", "--mixed", "HEAD~1")


def _git(cwd: Path, *args: str) -> str:
    return run_simple_program(GIT_PROGRAM, list(args), cwd=cwd, env=dict(os.environ))


def main() -> None:
    app()  # pragma: no cover
