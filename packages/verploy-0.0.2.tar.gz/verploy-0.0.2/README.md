# verploy

Continuous integration and continuous deployment of python projects.

## Installation

Install ruff, pyright, pytest, and pytest-cov in your uv project.

(Optional) Install verploy as a CLI tool:

```bash
uv tool install verploy
```

## Usage

Run with uvx:

```bash
uvx --from verploy check
```

Run as a CLI tool:

```bash
check
```

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE).
