# -*- coding: utf-8 -*-

from .wraps import *
from .quote_base import *
from .quote_data import *
from .quote_archive import *
from .quote_factor import *
# from .technical_analysis import *
import multiprocessing

try:
    if multiprocessing.get_start_method() != 'spawn':
        multiprocessing.set_start_method('spawn')
except:
    pass

__version__ = '0.7.2'

__all__ = [
    'JQWraps',
    'QuoteData',
    'QuoteArchive',
    'QuoteFactor',
    '__version__'
]