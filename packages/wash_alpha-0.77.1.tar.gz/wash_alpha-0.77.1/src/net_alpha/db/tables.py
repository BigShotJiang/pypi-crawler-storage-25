# src/net_alpha/db/tables.py
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import field_validator
from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel


class AccountRow(SQLModel, table=True):
    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("broker", "label", name="uq_account_broker_label"),)

    id: int | None = Field(default=None, primary_key=True)
    broker: str = Field(index=True)
    label: str = Field(index=True)
    type: str = Field(default="taxable", sa_column_kwargs={"server_default": "taxable"})
    created_at: str | None = None
    # The broker-exported account string (e.g. "Short Term ...180" from a
    # Schwab positions CSV header). Lets the verify reconciler key its
    # (account_label, symbol) join against the user's nicknamed account
    # instead of the raw broker text. NULL until the user maps it via the
    # /imports/positions/map picker. Not unique-enforced: an unmapped row
    # is NULL and SQLite UNIQUE counts every NULL distinct, but we also
    # don't want two accounts claiming the same broker string — see
    # repo.set_account_broker_alias for the runtime "one owner" guard.
    broker_label: str | None = None


class ImportRecordRow(SQLModel, table=True):
    __tablename__ = "imports"

    id: int | None = Field(default=None, primary_key=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    csv_filename: str
    csv_sha256: str = Field(index=True)
    imported_at: datetime
    trade_count: int

    # v4 additions — populated on import or backfilled at startup.
    min_trade_date: str | None = None
    max_trade_date: str | None = None
    equity_count: int | None = None
    option_count: int | None = None
    option_expiry_count: int | None = None
    parse_warnings_json: str | None = None  # JSON-encoded list[str]; "[]" = no warnings
    # v5 — count of trades dropped as natural-key duplicates of prior imports.
    # Nullable (defaults to 0 in Python) so legacy raw-SQL inserts in old tests
    # that omit the column don't fail; the migration also stamps a DB DEFAULT 0
    # so existing v4 rows read back as 0 not NULL.
    duplicate_trades: int | None = Field(default=0)
    cash_event_count: int | None = Field(default=0)


class TradeRow(SQLModel, table=True):
    __tablename__ = "trades"
    __table_args__ = (UniqueConstraint("account_id", "natural_key", name="uq_trade_account_natkey"),)

    id: int | None = Field(default=None, primary_key=True)
    import_id: int | None = Field(default=None, foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    natural_key: str = Field(index=True)

    ticker: str = Field(index=True)
    trade_date: str = Field(index=True)  # YYYY-MM-DD as-is from broker
    action: str
    quantity: float
    proceeds: float | None = None
    cost_basis: float | None = None
    basis_unknown: bool = False

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None
    basis_source: str = Field(default="unknown")
    # values: "broker_csv" | "g_l" | "fifo" | "unknown" | "user"
    is_manual: bool = Field(default=False)
    transfer_basis_user_set: bool = Field(default=False)
    is_section_1256: bool = Field(default=False, sa_column_kwargs={"server_default": "0"})
    gross_cash_impact: float | None = Field(default=None)
    # The original broker-statement date the transfer landed in the account.
    # ``trade_date`` (above) is the *acquisition* date — set initially to the
    # broker date but rewritten by the user once they look up the lot's
    # acquisition history. Storing both lets the timeline show "Acq …
    # · Xferred …" so the user can audit when the shares actually moved
    # vs when the cost basis began. Only meaningful when basis_source is in
    # {'transfer_in','transfer_out'}; null otherwise.
    transfer_date: str | None = Field(default=None)
    # Groups sibling rows that came from a single multi-segment transfer split
    # (one transfer with N acquisition lots). All siblings share the same
    # transfer_group_id and the same transfer_date. Null for un-split rows.
    transfer_group_id: str | None = Field(default=None, index=True)


class LotRow(SQLModel, table=True):
    __tablename__ = "lots"

    id: int | None = Field(default=None, primary_key=True)
    trade_id: int = Field(foreign_key="trades.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)

    ticker: str = Field(index=True)
    trade_date: str
    quantity: float
    cost_basis: float
    adjusted_basis: float

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None
    # IRC §1223(4): wash-sale-tacked holding-period start. NULL means use
    # ``trade_date`` directly (no tacking).
    tacked_acquired_date: str | None = None


class WashSaleViolationRow(SQLModel, table=True):
    __tablename__ = "wash_sale_violations"

    id: int | None = Field(default=None, primary_key=True)
    loss_trade_id: int = Field(foreign_key="trades.id", index=True)
    replacement_trade_id: int = Field(foreign_key="trades.id", index=True)
    loss_account_id: int = Field(foreign_key="accounts.id", index=True)
    buy_account_id: int = Field(foreign_key="accounts.id", index=True)
    loss_sale_date: str = Field(index=True)
    triggering_buy_date: str = Field(index=True)
    ticker: str = Field(index=True, default="")
    confidence: str
    disallowed_loss: float
    matched_quantity: float
    source: str = Field(default="engine")
    # values: "schwab_g_l" | "engine"
    # IRC §1091 disposition kind. "deferred" = §1091(d) basis rollover (default;
    # pre-2026-05-11 behavior). "permanent_ira" = Rev. Rul. 2008-5: replacement
    # leg is in a tax-advantaged account, so the disallowed loss can't roll into
    # basis and is permanently lost.
    kind: str = Field(default="deferred")


class ExemptMatchRow(SQLModel, table=True):
    """Persistent form of `models.domain.ExemptMatch`."""

    __tablename__ = "exempt_matches"

    id: int | None = Field(default=None, primary_key=True)
    loss_trade_id: int = Field(index=True, foreign_key="trades.id")
    triggering_buy_id: int = Field(index=True, foreign_key="trades.id")
    exempt_reason: str = Field(index=True)
    rule_citation: str
    notional_disallowed: Decimal
    confidence: str
    matched_quantity: float
    loss_account: str = Field(index=True)
    buy_account: str = Field(index=True)
    loss_sale_date: str = Field(index=True)  # YYYY-MM-DD per project convention
    triggering_buy_date: str
    ticker: str = Field(index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Section1256ClassificationRow(SQLModel, table=True):
    """Persistent form of `models.domain.Section1256Classification`. Pure derived data."""

    __tablename__ = "section_1256_classifications"

    id: int | None = Field(default=None, primary_key=True)
    trade_id: int = Field(index=True, foreign_key="trades.id", unique=True)
    realized_pnl: Decimal
    long_term_portion: Decimal
    short_term_portion: Decimal
    underlying: str = Field(index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Section1256MTMRow(SQLModel, table=True):
    """Persistent form of `models.domain.Section1256MTM`. Pure derived data."""

    __tablename__ = "section_1256_mtm"

    id: int | None = Field(default=None, primary_key=True)
    position_key: str = Field(index=True)
    tax_year: int = Field(index=True)
    last_business_day: str  # YYYY-MM-DD per project convention
    fmv: Decimal
    basis_before: Decimal
    unrealized_pnl: Decimal
    long_term_portion: Decimal
    short_term_portion: Decimal
    fmv_source: str
    ticker: str = Field(index=True)
    account: str = Field(default="", index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MetaRow(SQLModel, table=True):
    __tablename__ = "meta"

    key: str = Field(primary_key=True)
    value: str


class PlanViewSnapshotRow(SQLModel, table=True):
    """One row per ticker present on the user's last-seen Plan view.

    Used by the diff that drives `● new` / `▲ changed` badges. Rewritten in
    full on every "Mark as seen" click; never updated incrementally.
    """

    __tablename__ = "plan_view_snapshot"

    ticker: str = Field(primary_key=True)
    target_kind: str  # "shares" | "usd"
    target_value: float
    risk_pill: str  # "green" | "yellow" | "red"
    pl_bucket: int  # signed bin; see portfolio/plan_diff.py
    snapshot_taken_at: str  # ISO 8601


class RealizedGLLotRow(SQLModel, table=True):
    __tablename__ = "realized_gl_lots"

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)

    symbol_raw: str = Field(index=True)
    ticker: str = Field(index=True)
    closed_date: str = Field(index=True)
    opened_date: str
    quantity: float
    proceeds: float
    cost_basis: float
    unadjusted_cost_basis: float
    wash_sale: bool
    disallowed_loss: float
    term: str

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None

    natural_key: str = Field(unique=True, index=True)


class PriceCacheRow(SQLModel, table=True):
    __tablename__ = "price_cache"

    symbol: str = Field(primary_key=True)
    price: float
    as_of: str  # ISO 8601 timestamp from provider
    fetched_at: str  # ISO 8601 UTC timestamp; TTL check performed by cache.py
    source: str  # e.g. "yahoo"


class HistoricalPriceCacheRow(SQLModel, table=True):
    __tablename__ = "historical_price_cache"

    symbol: str = Field(primary_key=True)
    on_date: str = Field(primary_key=True)  # YYYY-MM-DD
    close_price: float | None = None  # NULL = negative cache
    fetched_at: str  # ISO 8601 UTC timestamp


class SplitRow(SQLModel, table=True):
    __tablename__ = "splits"
    __table_args__ = (UniqueConstraint("symbol", "split_date", name="uq_splits_symbol_date"),)

    id: int | None = Field(default=None, primary_key=True)
    symbol: str = Field(index=True)
    split_date: str  # YYYY-MM-DD ex-date
    ratio: float  # new shares ÷ old shares; 2.0 = 2-for-1; 0.1 = 1-for-10 reverse
    source: str  # 'yahoo' | 'manual'
    fetched_at: str  # ISO 8601 UTC timestamp


class LotOverrideRow(SQLModel, table=True):
    __tablename__ = "lot_overrides"

    id: int | None = Field(default=None, primary_key=True)
    trade_id: int = Field(foreign_key="trades.id", index=True)
    field: str  # 'quantity' | 'adjusted_basis'
    old_value: float
    new_value: float
    reason: str  # 'split' | 'manual' | 'transfer_basis_fix'
    edited_at: str  # ISO 8601 UTC timestamp
    split_id: int | None = Field(default=None, foreign_key="splits.id", index=True)
    # split_id is set when reason='split'; lets apply_split check idempotency.


class CashEventRow(SQLModel, table=True):
    __tablename__ = "cash_events"
    __table_args__ = (UniqueConstraint("account_id", "natural_key", name="uq_cash_event_account_natkey"),)

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    natural_key: str = Field(index=True)

    event_date: str = Field(index=True)  # YYYY-MM-DD as-is from broker
    kind: str  # transfer_in | transfer_out | dividend | interest | fee | sweep_in | sweep_out
    amount: float  # always positive; sign comes from `kind`
    ticker: str | None = Field(default=None, index=True)
    description: str = ""


class UserPreferenceRow(SQLModel, table=True):
    __tablename__ = "user_preferences"

    account_id: int = Field(primary_key=True, foreign_key="accounts.id")
    profile: str = Field(default="active")  # 'conservative' | 'active' | 'options'
    density: str = Field(default="comfortable")  # 'compact' | 'comfortable' | 'tax'
    theme: str = Field(default="system", sa_column_kwargs={"server_default": "system"})  # 'system' | 'light' | 'dark'
    updated_at: datetime


class PositionTargetRow(SQLModel, table=True):
    __tablename__ = "position_targets"
    id: int | None = Field(default=None, primary_key=True)
    symbol: str = Field(index=True, unique=True)
    target_amount: Decimal
    target_unit: str  # 'usd' | 'shares'
    created_at: str  # ISO datetime
    updated_at: str  # ISO datetime
    sort_order: int = Field(default=0, sa_column_kwargs={"server_default": "0"})


class PositionTargetTagRow(SQLModel, table=True):
    __tablename__ = "position_target_tag"
    target_symbol: str = Field(primary_key=True, index=True)
    tag: str = Field(primary_key=True, index=True)


class DismissedInboxItemRow(SQLModel, table=True):
    __tablename__ = "dismissed_inbox_items"

    dismiss_key: str = Field(primary_key=True)
    dismissed_at: str  # ISO 8601 UTC timestamp


class LossCarryforwardRow(SQLModel, table=True):
    """Per-year ST/LT capital-loss carryforward override.

    Only user overrides are persisted. Derived values are computed on read by
    `portfolio.carryforward.derive_carryforward` and never stored. Aggregated
    federal-level — not per-account.

    Sign convention: stored as positive magnitudes (loss = positive number);
    sign is flipped at apply-time inside the planner / after-tax math.
    """

    __tablename__ = "loss_carryforward"
    # SQLModel `table=True` models skip pydantic validation by default; opt in
    # so the field validators below enforce sign / source on construction.
    model_config = {"validate_assignment": True}  # type: ignore[assignment]

    year: int = Field(primary_key=True)
    st_amount: Decimal = Field(default=Decimal("0"))
    lt_amount: Decimal = Field(default=Decimal("0"))
    # Stored as str (SQLModel can't map typing.Literal to a column); the
    # validator below pins it to the allowed values.
    source: str = Field(default="user")
    note: str | None = None
    updated_at: datetime

    @field_validator("st_amount", "lt_amount")
    @classmethod
    def _non_negative(cls, v: Decimal) -> Decimal:
        if v < 0:
            raise ValueError("carryforward amounts are positive magnitudes")
        return v

    @field_validator("source")
    @classmethod
    def _allowed_source(cls, v: str) -> str:
        allowed: tuple[Literal["user"], ...] = ("user",)
        if v not in allowed:
            raise ValueError(f"source must be one of {allowed}, got {v!r}")
        return v


class ServiceRunRow(SQLModel, table=True):
    __tablename__ = "service_run"

    id: int | None = Field(default=None, primary_key=True)
    job_name: str
    started_at: str
    finished_at: str | None = None
    status: str
    duration_ms: int | None = None
    error_msg: str | None = None
    payload: str | None = None  # JSON-encoded


class WashSaleWatchResultRow(SQLModel, table=True):
    __tablename__ = "washsale_watch_result"

    target_id: int = Field(primary_key=True)
    status: str
    severity: str
    reason: str | None = None
    triggering: str | None = None  # JSON-encoded
    computed_at: str
