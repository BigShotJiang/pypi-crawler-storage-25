/**
 * net-alpha shared ApexCharts theme + helpers.
 *
 * Loaded by base.html (as a non-module script). Sets a global namespace.
 *
 * Colors and the Apex `tooltip.theme` mode are read live from the active
 * CSS custom properties (so [data-theme="light"] / [data-theme="dark"]
 * just works), and a registry of inline render() functions re-renders
 * every chart on the `theme:change` window event dispatched by theme.js.
 */
(function () {
  function readVar(name) {
    var v = getComputedStyle(document.documentElement).getPropertyValue(name);
    return v ? v.trim() : "";
  }

  function readColors() {
    return {
      pos:       readVar("--color-pos")       || "#30D158",
      neg:       readVar("--color-neg")       || "#FF453A",
      indigo:    readVar("--color-indigo")    || "#5E5CE6",
      violet:    readVar("--color-violet")    || "#BF5AF2",
      signature: readVar("--color-signature") || "#0A84FF",
      info:      readVar("--color-info")      || "#64D2FF",
      warn:      readVar("--color-warn")      || "#FF9F0A",
      label1:    readVar("--color-label-1")   || "rgba(235,235,245,0.92)",
      label2:    readVar("--color-label-2")   || "rgba(235,235,245,0.6)",
      label3:    readVar("--color-label-3")   || "rgba(235,235,245,0.35)",
      hairline:  readVar("--color-hairline")  || "rgba(255,255,255,0.10)",
      surface:   readVar("--color-surface")   || "#26262A",
      bg:        readVar("--color-bg")        || "#1A1A1C",
    };
  }

  function activeTheme() {
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  }

  // Live `colors` view — reading any property re-resolves against the
  // current CSS variables, so existing call sites that say
  // `window.netAlphaChartTheme.colors.pos` always get the active-theme value.
  var colors = new Proxy({}, {
    get: function (_target, key) {
      var snapshot = readColors();
      return snapshot[key];
    },
  });

  function prefersReducedMotion() {
    try {
      return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch (e) {
      return false;
    }
  }

  function buildDefaults() {
    var c = readColors();
    var isLight = activeTheme() === "light";
    // In dark mode label3 (35% white) reads fine on near-black; in light
    // mode label2 (60% black) on white only hits ~3.3:1, below WCAG AA
    // (4.5:1), so axis ticks + date labels use slate-600 (#475569 ≈ 8:1).
    // Legend uses label1 in light (~9:1) / label2 in dark.
    var axisColor = isLight ? "#475569" : c.label3;
    var legendColor = isLight ? c.label1 : c.label2;
    // CSS handles transitions/animations elsewhere with prefers-reduced-motion;
    // Apex configures its own engine, so suppress entrance + dynamic animations
    // when the user has opted out of motion at the OS level.
    var animationsEnabled = !prefersReducedMotion();
    return {
      chart: {
        background: "transparent",
        foreColor: legendColor,
        fontFamily: "Inter, -apple-system, system-ui, sans-serif",
        toolbar: { show: false },
        zoom: { enabled: false },
        animations: {
          enabled: animationsEnabled,
          easing: "easeout",
          speed: 480,                                // was 800 — matches --duration-slow
          animateGradually: { enabled: animationsEnabled, delay: 80 },
          dynamicAnimation: { enabled: animationsEnabled, speed: 240 },
        },
      },
      theme: { mode: activeTheme() },
      grid: {
        borderColor: c.hairline,
        strokeDashArray: 3,                        // was 2 — slightly more open
        xaxis: { lines: { show: false } },
        yaxis: { lines: { show: true } },
        padding: { top: 8, right: 8, bottom: 4, left: 8 },
      },
      xaxis: {
        labels: {
          style: { colors: axisColor, fontSize: "10px", fontFamily: "JetBrains Mono, ui-monospace, monospace" },
        },
        axisBorder: { show: false },
        axisTicks:  { show: false },
      },
      yaxis: {
        labels: {
          style: { colors: axisColor, fontSize: "10px", fontFamily: "JetBrains Mono, ui-monospace, monospace" },
        },
      },
      tooltip: {
        theme: activeTheme(),
        style: { fontSize: "12px", fontFamily: "Inter, sans-serif" },
      },
      dataLabels: { enabled: false },
      legend: {
        labels: { colors: legendColor },
        fontSize: "12px",
        fontFamily: "Inter, sans-serif",
      },
      colors: [
        c.signature, c.info, c.pos, c.warn, c.neg,
        c.indigo, c.violet,
      ],
      stroke: { curve: "smooth", width: 1.5, lineCap: "round" },  // was width: 2
    };
  }

  // `defaults` is a getter so per-chart templates that read it during render
  // always pick up live theme values instead of a snapshot from page load.
  var defaultsHandle = {
    get value() { return buildDefaults(); },
  };

  function merge(a, b) {
    var out = Object.assign({}, a);
    for (var k in b) {
      if (b[k] && typeof b[k] === "object" && !Array.isArray(b[k])) {
        out[k] = merge(a[k] || {}, b[k]);
      } else {
        out[k] = b[k];
      }
    }
    return out;
  }

  // Keyed registry of render functions: one entry per chart target id. Each
  // HTMX swap of a chart fragment re-runs its inline IIFE which calls
  // `register(key, render)` to OVERWRITE the prior closure for that key — so
  // theme:change re-renders the latest closure (with fresh data) instead of
  // a stack of stale ones accumulated across every prior swap.
  var registry = new Map();

  function register(key, fn) {
    // Legacy single-arg form (no callers in tree but defensive) — synthesize
    // a unique key so old behavior of append-and-grow is preserved rather
    // than collapsing every legacy registration onto the same slot.
    if (typeof key === "function" && fn === undefined) {
      fn = key;
      key = "__anon_" + (registry.size + 1);
    }
    if (typeof fn !== "function") return;
    registry.set(key, fn);
    // Run it now so the chart appears on initial load / post-swap.
    try { fn(); } catch (e) { console.warn("chart initial render failed:", e); }
  }

  function refresh() {
    // Walk a snapshot of values so render functions that re-register (via the
    // post-swap re-mount path) don't mutate the iterator. Each render is
    // expected to early-return when its target node is no longer in the DOM.
    var snapshot = Array.from(registry.values());
    for (var i = 0; i < snapshot.length; i++) {
      try {
        snapshot[i]();
      } catch (e) {
        // A single chart failure shouldn't kill the others, but the error must
        // not be invisible — silent catch made chart leaks impossible to spot.
        console.warn("chart refresh failed:", e);
      }
    }
  }

  // Mount or remount an ApexCharts instance on `el`. Destroys any prior chart
  // stored on the node so theme-change re-renders don't leak event listeners
  // or animation timers (Apex keeps internal refs even after `innerHTML = ''`).
  // Returns the new chart instance (or null on failure).
  function mountChart(el, opts) {
    if (!el || typeof window.ApexCharts !== "function") return null;
    if (el._apexChart && typeof el._apexChart.destroy === "function") {
      try { el._apexChart.destroy(); } catch (e) { console.warn("chart destroy failed:", e); }
    }
    el.innerHTML = "";
    var c = new window.ApexCharts(el, opts);
    try {
      c.render();
    } catch (e) {
      console.warn("chart render failed:", e);
      return null;
    }
    el._apexChart = c;
    return c;
  }

  window.addEventListener("theme:change", refresh);

  // Expose. `defaults` keeps property semantics for back-compat with
  // existing per-chart code that calls `merge(defaults, {...})`.
  window.netAlphaChartTheme = {
    colors: colors,
    get defaults() { return defaultsHandle.value; },
    merge: merge,
    register: register,
    refresh: refresh,
    mountChart: mountChart,
  };
})();
