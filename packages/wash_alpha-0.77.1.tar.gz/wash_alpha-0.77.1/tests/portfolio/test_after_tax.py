"""compute_after_tax math correctness, all paths."""

from datetime import datetime
from decimal import Decimal

from sqlmodel import Session, SQLModel, create_engine

import net_alpha.db.tables  # noqa: F401 — register SQLModel metadata
from net_alpha.db.migrations import migrate
from net_alpha.db.repository import Repository
from net_alpha.db.tables import AccountRow, ImportRecordRow, RealizedGLLotRow
from net_alpha.portfolio.after_tax import Period, compute_after_tax
from net_alpha.portfolio.carryforward import Carryforward
from net_alpha.portfolio.tax_planner import TaxBrackets


def _brackets(*, niit=True, state=Decimal("0")) -> TaxBrackets:
    return TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Decimal("0.37"),
        state_marginal_rate=state,
        ltcg_rate=Decimal("0.20"),
        qualified_div_rate=Decimal("0.20"),
        niit_enabled=niit,
    )


class _StubRepo:
    def __init__(
        self,
        *,
        st=Decimal("0"),
        lt=Decimal("0"),
        s1256=Decimal("0"),
        s1256_mtm=Decimal("0"),
        disallowed=Decimal("0"),
    ):
        self._st = st
        self._lt = lt
        self._s1256 = s1256
        self._s1256_mtm = s1256_mtm
        self._disallowed = disallowed

    def realized_pnl_split(self, period, accounts=None):
        return {"short_term": self._st, "long_term": self._lt}

    def section_1256_pnl(self, period, accounts=None):
        return self._s1256

    def section_1256_mtm_pnl(self, period, accounts=None):
        return self._s1256_mtm

    def wash_sale_disallowed_total(self, period, accounts=None):
        return self._disallowed


def _ytd():
    return Period.ytd(2026)


def test_all_short_term_gain():
    repo = _StubRepo(st=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.estimated_tax_bill == Decimal("4080")  # 10000*0.37 + 10000*0.038
    assert r.after_tax_realized_pnl == Decimal("5920")
    assert r.tax_drag_dollar == Decimal("4080")


def test_all_long_term_gain():
    repo = _StubRepo(lt=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.estimated_tax_bill == Decimal("2380")  # 10000*0.20 + 10000*0.038


def test_all_loss_no_negative_tax():
    repo = _StubRepo(st=Decimal("-5000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.estimated_tax_bill == Decimal("0")
    # §1211(b) benefit added: $3,000 cap × 0.37 fed rate = $1,110 offset.
    # After-tax = -5000 + 1110 = -3890.
    assert r.after_tax_realized_pnl == Decimal("-3890.000")
    # Drag is negative because losses gained a marginal-rate benefit.
    assert r.tax_drag_dollar == Decimal("-1110.000")


def test_section_1256_60_40_split_absorbed_into_st_lt():
    repo = _StubRepo(s1256=Decimal("1000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    # st_tax = 400 * 0.37 = 148; lt_tax = 600 * 0.20 = 120; niit = 1000 * 0.038 = 38
    assert r.estimated_tax_bill == Decimal("306")
    assert r.section_1256_lt_portion == Decimal("600")
    assert r.section_1256_st_portion == Decimal("400")


def test_niit_toggle_off_zeroes_niit():
    repo = _StubRepo(st=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets(niit=False))
    assert r.estimated_tax_bill == Decimal("3700")


def test_state_tax_layer():
    repo = _StubRepo(st=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets(state=Decimal("0.05")))
    assert r.estimated_tax_bill == Decimal("4580")  # 3700+500+380


def test_wash_sale_marginal_cost():
    repo = _StubRepo(st=Decimal("0"), disallowed=Decimal("1000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.wash_sale_disallowed_total == Decimal("1000")
    assert r.wash_sale_marginal_cost == Decimal("370")


def test_effective_tax_rate():
    repo = _StubRepo(st=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.effective_tax_rate == Decimal("0.408")


def test_effective_tax_rate_zero_when_no_gains():
    repo = _StubRepo(st=Decimal("-5000"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert r.effective_tax_rate == Decimal("0")


def test_period_label_set():
    repo = _StubRepo(st=Decimal("100"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert "2026" in r.period_label or "YTD" in r.period_label


def test_caveats_includes_lifetime_warning_when_lifetime():
    repo = _StubRepo(st=Decimal("100"))
    r = compute_after_tax(repo, Period.lifetime(), _brackets())
    assert any("Lifetime" in c or "current rates" in c for c in r.caveats)


def test_pre_tax_realized_exposes_pre_and_post_carryforward(_=None):
    """Audit #39: ``pre_tax_realized_pnl`` was rebound to the *post-CF*
    sum (the rebind at ``st_pnl = st_after_cf``), so the Tax Performance
    tile silently disagreed with the Home page's ``period_realized``
    (which doesn't apply CF). Expose both:

      ``pre_tax_realized_before_cf`` — true pre-CF realized P&L (matches
          home-page ``period_realized``)
      ``pre_tax_realized_pnl`` — post-CF pre-tax realized P&L (what the
          downstream tax bill is computed against). Kept for back-compat.
      ``carryforward_absorbed`` — the difference; how much CF the year
          consumed (≥ 0; magnitude). Lets the UI surface the netting.

    Setup: $5,000 ST gain with $3,000 ST CF → before CF $5K, after CF
    $2K, absorbed $3K.
    """
    repo = _StubRepo(st=Decimal("5000"))
    cf = Carryforward(st=Decimal("3000"), lt=Decimal("0"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(niit=False), carryforward=cf)
    assert r.pre_tax_realized_before_cf == Decimal("5000")
    assert r.pre_tax_realized_pnl == Decimal("2000")
    assert r.carryforward_absorbed == Decimal("3000")


def test_pre_tax_realized_before_cf_when_no_carryforward(_=None):
    """When no CF is supplied, the two pre-tax fields are equal and
    ``carryforward_absorbed`` is zero — back-compat for the common case.
    """
    repo = _StubRepo(st=Decimal("1000"), lt=Decimal("2000"))
    r = compute_after_tax(repo, _ytd(), _brackets(niit=False))
    assert r.pre_tax_realized_before_cf == Decimal("3000")
    assert r.pre_tax_realized_pnl == Decimal("3000")
    assert r.carryforward_absorbed == Decimal("0")


def test_pre_tax_realized_before_cf_includes_section_1256(_=None):
    """§1256 realized + MTM contribute to the pre-CF pre-tax figure
    identically to ST/LT — they aren't reshaped by carryforward in this
    module (CF applies only to ST/LT) but they ARE part of the pre-tax
    headline number.
    """
    repo = _StubRepo(st=Decimal("1000"), s1256=Decimal("500"), s1256_mtm=Decimal("200"))
    r = compute_after_tax(repo, _ytd(), _brackets(niit=False))
    assert r.pre_tax_realized_before_cf == Decimal("1700")


def test_pre_tax_realized_cf_absorbed_caps_at_pnl_when_cf_exceeds_gain(_=None):
    """If CF exceeds the gain, the gain is reduced to zero and the
    surplus rolls forward; ``carryforward_absorbed`` reports only the
    amount actually consumed (not the full CF).

    $1,000 ST gain with $3,000 ST CF + $0 LT gain → ST absorbed = $1,000
    (the gain), surplus $2,000 has nowhere to go this year (no LT gain
    to cross-net into), so post-CF state is ST=$0, LT=$0.
    """
    repo = _StubRepo(st=Decimal("1000"))
    cf = Carryforward(st=Decimal("3000"), lt=Decimal("0"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(niit=False), carryforward=cf)
    assert r.pre_tax_realized_before_cf == Decimal("1000")
    # After CF: 1000 - 3000 = -2000; no LT gain to cross-net → ST stays -2000.
    # pre_tax_realized_pnl (post-CF) reflects ST=-2000 + LT=0 + §1256=0.
    assert r.pre_tax_realized_pnl == Decimal("-2000")
    # carryforward_absorbed = pre - post = 1000 - (-2000) = 3000
    assert r.carryforward_absorbed == Decimal("3000")


def test_niit_caveat_says_unconditional_when_enabled_no_magi_gate():
    """The NIIT math applies the 3.8% surtax to all positive net capital
    gains whenever ``niit_enabled=True`` — it does NOT check MAGI. The
    caveat must say so honestly and point the user at the manual toggle,
    not imply we gate on the $200K / $250K threshold.
    """
    repo = _StubRepo(st=Decimal("100"))
    r_on = compute_after_tax(repo, _ytd(), _brackets(niit=True))
    niit_caveats = [c for c in r_on.caveats if "NIIT" in c]
    assert niit_caveats, "expected an NIIT caveat to be present"
    blob = " ".join(niit_caveats)
    # Truthful framing: surtax applies whenever the flag is on (no MAGI gate).
    assert "all net positive capital gains" in blob
    assert "whenever enabled" in blob
    # Pointer to the manual toggle, with the threshold given as context for
    # when the user should turn it off — not as a gate the math implements.
    assert "Toggle NIIT off in tax config" in blob
    assert "$200K" in blob
    assert "$250K" in blob
    # Currently-on / currently-off status still appears so the user can
    # confirm at a glance which side of the toggle they're on.
    assert "on" in blob

    r_off = compute_after_tax(repo, _ytd(), _brackets(niit=False))
    niit_caveats_off = [c for c in r_off.caveats if "NIIT" in c]
    assert any("off" in c for c in niit_caveats_off)


def test_niit_math_unchanged_when_enabled():
    """Behavioral check: the caveat rewrite must NOT change the actual tax
    arithmetic. With $10K ST gain and NIIT on, expect federal + NIIT =
    10000*0.37 + 10000*0.038 = $4080.
    """
    repo = _StubRepo(st=Decimal("10000"))
    r = compute_after_tax(repo, _ytd(), _brackets(niit=True))
    assert r.estimated_tax_bill == Decimal("4080")
    r_off = compute_after_tax(repo, _ytd(), _brackets(niit=False))
    assert r_off.estimated_tax_bill == Decimal("3700")  # no NIIT


def test_caveats_drop_capital_loss_limitation_note():
    """Task 9: the old "$3K capital-loss limitation / multi-year carryforward
    not modeled" caveat is gone — those are now modeled via the carryforward
    pipeline."""
    repo = _StubRepo(st=Decimal("-100"))
    r = compute_after_tax(repo, _ytd(), _brackets())
    assert all("not modeled" not in c for c in r.caveats)
    assert all("Capital-loss limitation" not in c for c in r.caveats)


def test_compute_after_tax_consumes_st_carryforward_reducing_tax_bill():
    """A $5,000 ST carryforward applied against $10,000 ST gain reduces ST
    taxable to $5,000 → federal_marginal_rate * 5000 + niit."""
    repo = _StubRepo(st=Decimal("10000"))
    cf = Carryforward(st=Decimal("5000"), lt=Decimal("0"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf)
    # ST taxable: 10000 - 5000 = 5000
    # st_tax = 5000 * 0.37 = 1850; niit = 5000 * 0.038 = 190 → 2040
    assert r.short_term_pnl == Decimal("5000")
    assert r.estimated_tax_bill == Decimal("2040")


def test_compute_after_tax_consumes_lt_carryforward_reducing_tax_bill():
    """LT carryforward absorbs same-bucket LT gain first."""
    repo = _StubRepo(lt=Decimal("10000"))
    cf = Carryforward(st=Decimal("0"), lt=Decimal("4000"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf)
    # LT taxable: 10000 - 4000 = 6000
    # lt_tax = 6000 * 0.20 = 1200; niit = 6000 * 0.038 = 228 → 1428
    assert r.long_term_pnl == Decimal("6000")
    assert r.estimated_tax_bill == Decimal("1428")


def test_compute_after_tax_carryforward_crosses_categories_st_into_lt():
    """ST carry surplus crosses into LT gain when ST has no gains to absorb
    (§1212(b)(1)(B))."""
    # ST gain $0, LT gain $10,000, ST carry $4,000.
    # Same-bucket: ST carry vs ST gain (0) → unchanged.
    # Cross: ST carry $4,000 vs LT gain $10,000 → LT gain becomes $6,000.
    repo = _StubRepo(st=Decimal("0"), lt=Decimal("10000"))
    cf = Carryforward(st=Decimal("4000"), lt=Decimal("0"), source="derived")
    r = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf)
    assert r.short_term_pnl == Decimal("0")
    assert r.long_term_pnl == Decimal("6000")
    # lt_tax = 6000*0.20=1200; niit = 6000*0.038=228 → 1428
    assert r.estimated_tax_bill == Decimal("1428")


def test_compute_after_tax_carryforward_crosses_categories_lt_into_st():
    """LT carry surplus crosses into ST gain."""
    repo = _StubRepo(st=Decimal("10000"), lt=Decimal("0"))
    cf = Carryforward(st=Decimal("0"), lt=Decimal("3000"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf)
    # ST gain reduced by 3000 cross-bucket LT carry → ST taxable 7000.
    assert r.short_term_pnl == Decimal("7000")
    assert r.long_term_pnl == Decimal("0")
    # st_tax = 7000*0.37=2590; niit = 7000*0.038=266 → 2856
    assert r.estimated_tax_bill == Decimal("2856")


def test_compute_after_tax_caveat_emitted_when_carryforward_applied():
    repo = _StubRepo(st=Decimal("10000"))
    cf = Carryforward(st=Decimal("2000"), lt=Decimal("500"), source="user")
    r = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf)
    assert any("Carryforward applied" in c and "user" in c for c in r.caveats)


def test_compute_after_tax_no_carryforward_caveat_when_zero():
    """When carryforward is None or all-zero, no carryforward caveat is added."""
    repo = _StubRepo(st=Decimal("10000"))
    r_none = compute_after_tax(repo, _ytd(), _brackets())
    assert all("Carryforward applied" not in c for c in r_none.caveats)

    cf_zero = Carryforward(st=Decimal("0"), lt=Decimal("0"), source="none")
    r_zero = compute_after_tax(repo, _ytd(), _brackets(), carryforward=cf_zero)
    assert all("Carryforward applied" not in c for c in r_zero.caveats)


def test_compute_after_tax_carryforward_default_is_zero():
    """Omitting `carryforward` is equivalent to passing zero — preserves
    legacy behavior for existing callers."""
    repo = _StubRepo(st=Decimal("10000"))
    r_default = compute_after_tax(repo, _ytd(), _brackets())
    r_zero = compute_after_tax(
        repo,
        _ytd(),
        _brackets(),
        carryforward=Carryforward(st=Decimal("0"), lt=Decimal("0"), source="none"),
    )
    assert r_default.estimated_tax_bill == r_zero.estimated_tax_bill
    assert r_default.short_term_pnl == r_zero.short_term_pnl


def test_realized_pnl_split_excludes_1256_at_repo_level(tmp_path):
    """Regression: §1256 contracts must be excluded from realized_pnl_split
    so they're not double-counted alongside section_1256_pnl."""
    engine = create_engine(f"sqlite:///{tmp_path}/repo.db")
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        migrate(session)
        # Plant a single §1256 row (SPX option) and a single regular row (TSLA stock).
        # Need an account + import record first.
        acct = AccountRow(broker="schwab", label="personal")
        session.add(acct)
        session.commit()
        session.refresh(acct)
        imp = ImportRecordRow(
            account_id=acct.id,
            csv_filename="x.csv",
            csv_sha256="abc123",
            imported_at=datetime(2026, 1, 1, 0, 0, 0),
            trade_count=2,
        )
        session.add(imp)
        session.commit()
        session.refresh(imp)
        # SPX option (§1256 contract) — should be excluded
        session.add(
            RealizedGLLotRow(
                import_id=imp.id,
                account_id=acct.id,
                symbol_raw="SPX 4500C",
                ticker="SPX",
                closed_date="2024-09-15",
                opened_date="2024-08-15",
                quantity=1.0,
                proceeds=100.0,
                cost_basis=200.0,
                unadjusted_cost_basis=200.0,
                wash_sale=False,
                disallowed_loss=0.0,
                term="Short Term",
                option_strike=4500.0,
                option_expiry="2025-12-19",
                natural_key="spx_4500c_20240915",
            )
        )
        # TSLA stock (regular equity) — should be included
        session.add(
            RealizedGLLotRow(
                import_id=imp.id,
                account_id=acct.id,
                symbol_raw="TSLA",
                ticker="TSLA",
                closed_date="2024-09-15",
                opened_date="2024-08-15",
                quantity=10.0,
                proceeds=1000.0,
                cost_basis=2000.0,
                unadjusted_cost_basis=2000.0,
                wash_sale=False,
                disallowed_loss=0.0,
                term="Short Term",
                natural_key="tsla_20240915",
            )
        )
        session.commit()

    repo = Repository(engine)
    pnl = repo.realized_pnl_split(Period.ytd(2024), None)
    # Only TSLA should be counted (-1000); SPX excluded.
    assert pnl["short_term"] == Decimal("-1000")
    assert pnl["long_term"] == Decimal("0")


def test_compute_after_tax_accounts_list_threads_through_to_repo():
    """accounts=['A','B'] should pass `accounts=['A','B']` keyword to every repo method."""
    received: dict[str, object] = {}

    class TrackingRepo:
        def realized_pnl_split(self, period, accounts=None):
            received["realized_pnl_split"] = list(accounts) if accounts else None
            return {"short_term": Decimal("0"), "long_term": Decimal("0")}

        def section_1256_pnl(self, period, accounts=None):
            received["section_1256_pnl"] = list(accounts) if accounts else None
            return Decimal("0")

        def section_1256_mtm_pnl(self, period, accounts=None):
            received["section_1256_mtm_pnl"] = list(accounts) if accounts else None
            return Decimal("0")

        def wash_sale_disallowed_by_kind(self, period, accounts=None):
            received["wash_sale_disallowed_by_kind"] = list(accounts) if accounts else None
            return {"deferred": Decimal("0"), "permanent_ira": Decimal("0")}

    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Decimal("0.32"),
        ltcg_rate=Decimal("0.15"),
        qualified_div_rate=Decimal("0.15"),
        state_marginal_rate=Decimal("0.09"),
        niit_enabled=False,
    )
    result = compute_after_tax(
        TrackingRepo(),
        Period.for_year(2025),
        brackets=brackets,
        accounts=["Schwab/A", "Schwab/B"],
    )
    for key in ("realized_pnl_split", "section_1256_pnl", "section_1256_mtm_pnl", "wash_sale_disallowed_by_kind"):
        assert received[key] == ["Schwab/A", "Schwab/B"], (
            f"{key} received {received[key]} instead of ['Schwab/A', 'Schwab/B']"
        )
    # When a multi-account filter is active, account_filter is a comma-joined string.
    assert result.account_filter == "Schwab/A, Schwab/B"


def test_compute_after_tax_single_account_filter_via_accounts():
    """accounts=['Schwab/A'] routes correctly — single-entry list matches old account= behavior."""
    received: dict[str, object] = {}

    class TrackingRepo:
        def realized_pnl_split(self, period, accounts=None):
            received["accounts_kw"] = list(accounts) if accounts else None
            return {"short_term": Decimal("0"), "long_term": Decimal("0")}

        def section_1256_pnl(self, period, accounts=None):
            return Decimal("0")

        def section_1256_mtm_pnl(self, period, accounts=None):
            return Decimal("0")

        def wash_sale_disallowed_by_kind(self, period, accounts=None):
            return {"deferred": Decimal("0"), "permanent_ira": Decimal("0")}

    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Decimal("0.32"),
        ltcg_rate=Decimal("0.15"),
        qualified_div_rate=Decimal("0.15"),
        state_marginal_rate=Decimal("0.09"),
        niit_enabled=False,
    )
    result = compute_after_tax(
        TrackingRepo(),
        Period.for_year(2025),
        brackets=brackets,
        accounts=["Schwab/A"],
    )
    assert received["accounts_kw"] == ["Schwab/A"]
    assert result.account_filter == "Schwab/A"


def test_compute_after_tax_accounts_empty_means_no_filter():
    """accounts=[] should NOT thread anything to repo (None passed)."""
    received: dict[str, object] = {}

    class TrackingRepo:
        def realized_pnl_split(self, period, accounts=None):
            received["accounts_kw"] = list(accounts) if accounts else None
            return {"short_term": Decimal("0"), "long_term": Decimal("0")}

        def section_1256_pnl(self, period, accounts=None):
            return Decimal("0")

        def section_1256_mtm_pnl(self, period, accounts=None):
            return Decimal("0")

        def wash_sale_disallowed_by_kind(self, period, accounts=None):
            return {"deferred": Decimal("0"), "permanent_ira": Decimal("0")}

    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Decimal("0.32"),
        ltcg_rate=Decimal("0.15"),
        qualified_div_rate=Decimal("0.15"),
        state_marginal_rate=Decimal("0.09"),
        niit_enabled=False,
    )
    result = compute_after_tax(
        TrackingRepo(),
        Period.for_year(2025),
        brackets=brackets,
        accounts=[],
    )
    assert received["accounts_kw"] is None
    assert result.account_filter is None
