from decimal import Decimal
from decimal import Decimal as D

from sqlalchemy import create_engine
from sqlmodel import Session, SQLModel

from net_alpha.db.migrations import migrate
from net_alpha.db.repository import Repository
from net_alpha.portfolio.carryforward import (
    Carryforward,
    derive_carryforward,
    get_effective_carryforward,
)


class _StubRepo:
    """Pure-function stub. Returns the (st, lt) realized P&L for each year."""

    def __init__(self, by_year: dict[int, tuple[Decimal, Decimal]]):
        self._by = by_year

    def realized_pnl_split_by_year(self, year: int) -> tuple[Decimal, Decimal]:
        return self._by.get(year, (Decimal("0"), Decimal("0")))

    def earliest_trade_year(self) -> int | None:
        return min(self._by) if self._by else None


def test_no_prior_history_returns_none_source():
    repo = _StubRepo({})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="none")


def test_single_prior_year_st_loss_below_cap():
    # 2024 had a $1,500 ST loss. Below the $3,000 cap, all absorbed against
    # ordinary, nothing rolls forward.
    repo = _StubRepo({2024: (Decimal("-1500"), Decimal("0"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_single_prior_year_st_loss_above_cap_rolls_forward():
    # 2024 had a $5,000 ST loss. $3,000 absorbed against ordinary; $2,000 rolls.
    repo = _StubRepo({2024: (Decimal("-5000"), Decimal("0"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("2000"), lt=Decimal("0"), source="derived")


def test_single_prior_year_lt_loss_above_cap_rolls_forward():
    repo = _StubRepo({2024: (Decimal("0"), Decimal("-5000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("2000"), source="derived")


def test_single_prior_year_pure_gain_no_carryforward():
    repo = _StubRepo({2024: (Decimal("1000"), Decimal("2000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_excess_st_loss_offsets_lt_gain_same_year():
    # 2024: ST loss $5,000, LT gain $2,000.
    # ST loss first absorbs $2,000 of LT gain → ST net $3,000 loss, LT net 0.
    # $3,000 absorbed against ordinary; nothing rolls.
    repo = _StubRepo({2024: (Decimal("-5000"), Decimal("2000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_excess_st_loss_partially_absorbed_by_lt_gain_then_rolls():
    # 2024: ST loss $10,000, LT gain $3,000.
    # ST loss absorbs $3,000 LT gain → ST net $7,000 loss.
    # $3,000 against ordinary, $4,000 rolls forward as ST.
    repo = _StubRepo({2024: (Decimal("-10000"), Decimal("3000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("4000"), lt=Decimal("0"), source="derived")


def test_excess_lt_loss_offsets_st_gain():
    # 2024: ST gain $1,000, LT loss $6,000.
    # LT loss absorbs $1,000 ST gain → LT net $5,000 loss.
    # $3,000 against ordinary, $2,000 rolls forward as LT.
    repo = _StubRepo({2024: (Decimal("1000"), Decimal("-6000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("2000"), source="derived")


def test_both_categories_negative_each_rolls_in_bucket():
    # 2024: ST loss $4,000, LT loss $2,000. Total $6,000 loss.
    # Schedule D Capital Loss Carryover Worksheet absorbs the $3K cap
    # against ST loss FIRST (line 7 = line 4 + line 6), then any cap
    # remaining against LT loss. ST CF = $4K − $3K = $1K; LT CF = $2K.
    repo = _StubRepo({2024: (Decimal("-4000"), Decimal("-2000"))})
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("1000"), lt=Decimal("2000"), source="derived")


def test_two_year_chain_carryforward_consumes_next_year_gain():
    # 2023: ST loss $5,000 → $2,000 ST carry into 2024.
    # 2024: ST gain $1,500 + $2,000 ST carry → net $500 ST loss.
    # $500 absorbed against 2024 ordinary income under §1211(b); $0 to 2025.
    repo = _StubRepo(
        {
            2023: (Decimal("-5000"), Decimal("0")),
            2024: (Decimal("1500"), Decimal("0")),
        }
    )
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_carryforward_drains_in_idle_year_against_ordinary_income():
    # §1211(b) caps deductions against ordinary at $3,000 PER YEAR.
    # A $2,000 ST carry into an idle year is fully consumed that year — it
    # does NOT roll forward indefinitely until offset by a gain.
    #
    # 2023: $5,000 ST loss → $2,000 ST carry into 2024.
    # 2024: no activity → $2,000 absorbed against ordinary → $0 to 2025.
    repo = _StubRepo(
        {
            2023: (Decimal("-5000"), Decimal("0")),
            # 2024 deliberately omitted: stub returns (0, 0).
        }
    )
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_carryforward_drain_with_new_losses_combined_for_cap():
    # The $3K cap applies ONCE per year to the COMBINED total of carry + new
    # losses, not to each separately.
    #
    # 2023: $8,000 ST loss → $5,000 ST carry into 2024.
    # 2024: $1,000 LT new loss + $5,000 ST carry. Combined net = $6,000 loss.
    # $3,000 cap absorbed against ordinary. $3,000 rolls forward — ST first
    # per Schedule D worksheet (ST cap consumed before LT), leaving $2,000 ST
    # and $1,000 LT carry into 2025.
    repo = _StubRepo(
        {
            2023: (Decimal("-8000"), Decimal("0")),
            2024: (Decimal("0"), Decimal("-1000")),
        }
    )
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("2000"), lt=Decimal("1000"), source="derived")


def test_carryforward_large_residue_partially_drained_by_gain_then_capped():
    # 2023: $10,000 ST loss → $7,000 ST carry into 2024.
    # 2024: $500 ST gain. Carry first absorbs gain ($7,000 - $500 = $6,500
    # ST loss remains). $3,000 cap absorbed against ordinary in 2024.
    # $3,500 ST rolls forward into 2025.
    repo = _StubRepo(
        {
            2023: (Decimal("-10000"), Decimal("0")),
            2024: (Decimal("500"), Decimal("0")),
        }
    )
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("3500"), lt=Decimal("0"), source="derived")


def test_three_year_chain_with_cross_category():
    # 2022: ST loss $10,000 → $7,000 carry into 2023 (after $3K cap).
    # 2023: ST gain $2,000, LT gain $5,000. Carry first absorbs ST gain ($2,000 → 0),
    #       remaining $5,000 ST carry crosses to absorb LT gain ($5,000 → 0).
    #       Net for 2023: 0/0. Nothing new rolls. Carry into 2024: 0/0.
    # 2024: ST loss $1,000. $1,000 against ordinary. Nothing rolls.
    # Carry into 2025: 0/0.
    repo = _StubRepo(
        {
            2022: (Decimal("-10000"), Decimal("0")),
            2023: (Decimal("2000"), Decimal("5000")),
            2024: (Decimal("-1000"), Decimal("0")),
        }
    )
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def _real_repo() -> Repository:
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        migrate(session)
    return Repository(engine)


def test_user_override_beats_derived():
    repo = _real_repo()
    repo.upsert_carryforward_override(year=2025, st=D("999"), lt=D("0"))
    cf = get_effective_carryforward(repo, year=2025)
    assert cf.source == "user"
    assert cf.st == D("999")


def test_user_override_zero_still_beats_derived():
    """Explicit zero override means 'I have no carryforward' — beats derive."""
    repo = _real_repo()
    repo.upsert_carryforward_override(year=2025, st=D("0"), lt=D("0"))
    cf = get_effective_carryforward(repo, year=2025)
    assert cf.source == "user"
    assert cf == Carryforward(st=D("0"), lt=D("0"), source="user")


def test_falls_back_to_derived_when_no_override():
    repo = _real_repo()
    cf = get_effective_carryforward(repo, year=2025)
    # No trades in repo → "none"
    assert cf.source == "none"


class _StubRepoWithOverrides(_StubRepo):
    """Stub that also records year-keyed carryforward overrides."""

    def __init__(self, by_year, overrides=None):
        super().__init__(by_year)
        self._overrides = overrides or {}

    def get_carryforward_override(self, year: int):
        return self._overrides.get(year)


class _Override:
    """Minimal LossCarryforwardRow-shaped struct for the stub."""

    def __init__(self, st: Decimal, lt: Decimal):
        self.st_amount = st
        self.lt_amount = lt


def test_intermediate_override_freezes_replay_state(_=None):
    """Audit #38: ``derive_carryforward`` must honor user-recorded
    overrides for intermediate years, not just the target year. Semantic:
    an override at year N IS the post-year-N CF state — year N+1 derives
    from that override directly (no year-N PnL re-applied on top).

    Setup:
        2022 ST loss -$10,000 → would derive ST CF $7,000 into 2023
        2023 ST loss -$2,000 → would derive ST CF $4,000 into 2024
        2024 user override at end of 2023 says ST=$1,500 (their tax
            software is authoritative); we expect 2024's replay to
            START from $1,500 and apply 2024's PnL.

    Year-2024 PnL is +$500 ST. With override-frozen 2023 state
    (ST=$1,500): net ST = +500 - 1500 = -$1,000 loss; below $3K cap →
    fully absorbed; no carry into 2025. Without the override-respect
    fix the replay would compute ST CF into 2025 from raw P&L only.
    """
    repo = _StubRepoWithOverrides(
        by_year={
            2022: (Decimal("-10000"), Decimal("0")),
            2023: (Decimal("-2000"), Decimal("0")),
            2024: (Decimal("500"), Decimal("0")),
        },
        overrides={
            # Override AT year 2023 = post-2023 CF state going into 2024.
            2023: _Override(st=Decimal("1500"), lt=Decimal("0")),
        },
    )
    cf = derive_carryforward(repo, year=2025)
    # Year 2024 starts from override (ST=1500), net ST = 500 - 1500 = -1000,
    # below $3K cap → fully absorbed; no CF rolls into 2025.
    assert cf == Carryforward(st=Decimal("0"), lt=Decimal("0"), source="derived")


def test_intermediate_override_replaces_not_adds():
    """If a year-N override exists, the post-year-N CF state is the
    override values — year-N PnL is NOT re-applied on top.

    Without the override, year 2023 raw replay would give ST=$5K (from
    -$8K loss minus $3K cap). With an override saying ST=$10K at end of
    2023, that $10K is the authoritative starting state for 2024.
    """
    repo = _StubRepoWithOverrides(
        by_year={
            2023: (Decimal("-8000"), Decimal("0")),  # raw replay → CF $5K
        },
        overrides={
            2023: _Override(st=Decimal("10000"), lt=Decimal("0")),
        },
    )
    # 2024 starts from override $10K. No 2024 P&L → minus $3K cap = $7K rolls.
    cf = derive_carryforward(repo, year=2025)
    assert cf == Carryforward(st=Decimal("7000"), lt=Decimal("0"), source="derived")


def test_no_intermediate_override_uses_raw_replay_unchanged():
    """Control: no overrides recorded for intermediate years → behavior
    is identical to pre-fix (raw multi-year replay).
    """
    repo = _StubRepoWithOverrides(
        by_year={
            2022: (Decimal("-10000"), Decimal("0")),
            2023: (Decimal("-2000"), Decimal("0")),
        },
        overrides={},
    )
    cf = derive_carryforward(repo, year=2024)
    # Year 2022: -10K → CF $7K. Year 2023: -$2K loss + CF $7K = -$9K total ST
    # loss → -$3K cap → $6K rolls into 2024.
    assert cf == Carryforward(st=Decimal("6000"), lt=Decimal("0"), source="derived")


def test_override_target_year_is_consumed_by_get_effective_not_derive():
    """An override at the TARGET year is the get_effective_carryforward
    contract — derive_carryforward must NOT also apply it (would double
    up). Only intermediate-year overrides reshape the replay state.
    """
    repo = _StubRepoWithOverrides(
        by_year={2023: (Decimal("-5000"), Decimal("0"))},
        overrides={
            2024: _Override(st=Decimal("999"), lt=Decimal("0")),  # at target year
        },
    )
    # derive_carryforward(year=2024) replays 2023 only — the 2024 override is
    # for the target year and is consumed by get_effective_carryforward, not
    # by derive_carryforward.
    cf = derive_carryforward(repo, year=2024)
    # 2023: -$5K - $3K cap → $2K rolls into 2024.
    assert cf == Carryforward(st=Decimal("2000"), lt=Decimal("0"), source="derived")
