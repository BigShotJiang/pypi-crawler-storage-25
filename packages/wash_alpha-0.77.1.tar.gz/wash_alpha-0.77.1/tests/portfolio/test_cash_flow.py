import datetime as dt
from decimal import Decimal

from net_alpha.models.domain import CashEvent, Trade
from net_alpha.portfolio.cash_flow import (
    build_cash_balance_series,
    cash_allocation_slice,
    compute_cash_kpis,
)


def _ev(d, kind, amount, account="Schwab/x", description="x"):
    return CashEvent(account=account, event_date=d, kind=kind, amount=amount, ticker=None, description=description)


def _trade(d, action, gross, account="Schwab/x", ticker="SPIR"):
    return Trade(
        id="t",
        account=account,
        date=d,
        ticker=ticker,
        action=action,
        quantity=10.0,
        proceeds=gross if action == "Sell" else None,
        cost_basis=abs(gross) if action == "Buy" else None,
        gross_cash_impact=gross,
        option_details=None,
    )


def test_empty_inputs_yield_empty_series():
    pts = build_cash_balance_series(events=[], trades=[], period=None)
    assert pts == []


def test_single_deposit_jumps_balance_and_contributions():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 300.0, description="DEPOSIT")]
    pts = build_cash_balance_series(events=events, trades=[], period=None)
    assert len(pts) == 1
    assert pts[0].cash_balance == Decimal("300")
    assert pts[0].cumulative_contributions == Decimal("300")


def test_buy_decreases_balance_but_not_contributions():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 300.0)]
    trades = [_trade(dt.date(2026, 3, 5), "Buy", -158.80)]
    pts = build_cash_balance_series(events=events, trades=trades, period=None)
    assert pts[-1].cash_balance == Decimal("141.20")
    assert pts[-1].cumulative_contributions == Decimal("300")


def test_sweep_in_and_sweep_out_are_cash_neutral():
    """Sweep events move cash between Schwab1 brokerage and the Schwab Futures
    sub-account — both are part of the same total account value, so they must
    not move our combined cash balance. Otherwise the headline drifts from
    Schwab's combined account total as cash sloshes between sub-accounts."""
    events = [
        _ev(dt.date(2026, 4, 22), "sweep_out", 4460.97, description="Sweep to Futures"),
        _ev(dt.date(2026, 4, 24), "sweep_in", 307.00, description="Sweep from Futures"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], period=None)
    assert pts[0].cash_balance == Decimal("0")
    assert pts[1].cash_balance == Decimal("0")


def test_dividend_does_not_change_contributions():
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0),
        _ev(dt.date(2026, 3, 31), "dividend", 4.47, description="SQQQ"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], period=None)
    assert pts[-1].cash_balance == Decimal("104.47")
    assert pts[-1].cumulative_contributions == Decimal("100")


def test_account_filter_excludes_other_accounts():
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 4), "transfer_in", 999.0, account="Schwab/B"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], accounts=["Schwab/A"], period=None)
    assert pts[-1].cash_balance == Decimal("100")


def test_period_clip_excludes_events_after_window():
    events = [
        _ev(dt.date(2025, 12, 31), "transfer_in", 1000.0),
        _ev(dt.date(2026, 6, 1), "transfer_in", 200.0),
    ]
    # period = (2026, 2027) means YTD 2026
    pts = build_cash_balance_series(events=events, trades=[], period=(2026, 2027))
    # The 2025 event sets the opening balance carried into 2026.
    # The 2026 event makes the balance jump.
    assert pts[-1].cash_balance == Decimal("1200")
    assert pts[-1].cumulative_contributions == Decimal("1200")


def test_put_assignment_uses_gross_not_cost_basis():
    """A buy with cost_basis adjusted-down for put_assignment must still
    debit cash by the gross strike × qty amount."""
    trades = [_trade(dt.date(2026, 4, 17), "Buy", -300.0)]
    # Override cost_basis to 213 (basis-adjusted for premium); gross stays -300.
    trades[0].cost_basis = 213.0
    pts = build_cash_balance_series(events=[], trades=trades, period=None)
    assert pts[-1].cash_balance == Decimal("-300")


def test_legacy_trade_without_gross_falls_back_to_proceeds_or_cost_basis():
    trades = [_trade(dt.date(2026, 1, 5), "Sell", 824.96)]
    trades[0].gross_cash_impact = None  # simulate pre-migration row
    pts = build_cash_balance_series(events=[], trades=trades, period=None)
    assert pts[-1].cash_balance == Decimal("824.96")


# Tests for compute_cash_kpis


def test_kpis_zero_inputs():
    kpi = compute_cash_kpis(
        events=[],
        trades=[],
        holdings_value=Decimal("0"),
        period=None,
    )
    assert kpi.cash_balance == Decimal("0")
    assert kpi.account_value == Decimal("0")
    assert kpi.growth == Decimal("0")
    assert kpi.growth_pct is None
    assert kpi.cash_share_pct == Decimal("0")


def test_kpis_simple_deposit_and_holdings():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 1000.0)]
    kpi = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("250"),
        period=None,
    )
    # cash 1000 + holdings 250 = 1250 account_value, contrib 1000 → growth 250
    assert kpi.cash_balance == Decimal("1000")
    assert kpi.holdings_value == Decimal("250")
    assert kpi.account_value == Decimal("1250")
    assert kpi.net_contributions == Decimal("1000")
    assert kpi.growth == Decimal("250")
    assert kpi.growth_pct == Decimal("0.25")
    assert kpi.cash_share_pct == Decimal("0.8")  # 1000/1250


def test_kpis_period_net_contributions_excludes_pre_period_transfers():
    """Regression: the YTD KPI card was leaking lifetime contributions because
    `compute_cash_kpis` returned `series[-1].cumulative_contributions`, which
    folds pre-period events into the running total. The card displayed next to
    the provenance modal must match the modal (in-period transfers only)."""
    events = [
        _ev(dt.date(2025, 6, 1), "transfer_in", 31000.0),  # pre-period
        _ev(dt.date(2026, 2, 3), "transfer_in", 750.0),
        _ev(dt.date(2026, 3, 24), "transfer_in", 500.0),
    ]
    kpi = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("0"),
        period=(2026, 2027),  # YTD 2026
    )
    # Lifetime cumulative — used by growth math, unchanged.
    assert kpi.net_contributions == Decimal("32250")
    # Period-bounded — what the card and the provenance modal both show.
    assert kpi.period_net_contributions == Decimal("1250")


def test_kpis_period_net_contributions_equals_lifetime_when_no_period():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 1000.0)]
    kpi = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("0"),
        period=None,
    )
    assert kpi.period_net_contributions == kpi.net_contributions == Decimal("1000")


def test_kpis_growth_pct_none_when_no_contributions():
    events = [_ev(dt.date(2026, 3, 4), "dividend", 4.47)]
    kpi = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("0"),
        period=None,
    )
    assert kpi.net_contributions == Decimal("0")
    assert kpi.growth_pct is None


# Tests for cash_allocation_slice


def test_cash_allocation_slice_returns_current_balance():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 100.0)]
    trades = [_trade(dt.date(2026, 3, 5), "Buy", -25.0)]
    sl = cash_allocation_slice(events=events, trades=trades)
    assert sl == Decimal("75")


# Regression: share-quantity transfers move shares, not cash. They must
# contribute zero to the cash balance, NOT a phantom debit/credit derived from
# cost_basis/proceeds.
def test_security_transfer_in_contributes_zero_cash_delta():
    transfer_trade = Trade(
        id="t",
        account="Schwab/x",
        date=dt.date(2026, 1, 5),
        ticker="ABC",
        action="Buy",
        quantity=100.0,
        proceeds=None,
        cost_basis=5000.0,  # would otherwise become a -5000 cash debit
        gross_cash_impact=None,
        basis_source="transfer_in",
        option_details=None,
    )
    pts = build_cash_balance_series(events=[], trades=[transfer_trade], period=None)
    # No cash events and only a share-quantity transfer → empty/zero series.
    assert pts == [] or pts[-1].cash_balance == Decimal("0")


def test_security_transfer_out_contributes_zero_cash_delta():
    transfer_trade = Trade(
        id="t",
        account="Schwab/x",
        date=dt.date(2026, 1, 5),
        ticker="ABC",
        action="Sell",
        quantity=100.0,
        proceeds=5000.0,  # would otherwise become a +5000 cash credit
        cost_basis=None,
        gross_cash_impact=None,
        basis_source="transfer_out",
        option_details=None,
    )
    pts = build_cash_balance_series(events=[], trades=[transfer_trade], period=None)
    assert pts == [] or pts[-1].cash_balance == Decimal("0")


def test_total_return_uses_period_starting_value():
    """YTD Total Return must subtract the account value at period start.

    Sketch: $50K deposited 2025-01-15 (before YTD window), $5K deposited
    2026-03-01 (inside window). Holdings worth $51,020.18 today; cash is
    just the $55K of cumulative contributions (no trades). Period start
    value = $50,000.

    ending_value      = cash 55,000 + holdings 51,020.18 = 106,020.18
    starting_value    = 50,000
    period contribs   = 5,000
    Total Return YTD  = 106,020.18 − 50,000 − 5,000 = 51,020.18
    """
    import datetime as dt
    from decimal import Decimal

    from net_alpha.models.domain import CashEvent
    from net_alpha.portfolio.cash_flow import compute_cash_kpis

    events = [
        CashEvent(
            account="Schwab/Tax",
            event_date=dt.date(2025, 1, 15),
            kind="transfer_in",
            amount=50000,
        ),
        CashEvent(
            account="Schwab/Tax",
            event_date=dt.date(2026, 3, 1),
            kind="transfer_in",
            amount=5000,
        ),
    ]
    kpis = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("51020.18"),
        period=(2026, 2027),
        period_starting_value=Decimal("50000"),
    )
    assert kpis.growth == Decimal("51020.18")
    assert kpis.period_starting_value == Decimal("50000")


def test_total_return_lifetime_unchanged_when_starting_value_zero():
    """Lifetime mode (starting_value = 0) yields the legacy formula."""
    import datetime as dt
    from decimal import Decimal

    from net_alpha.models.domain import CashEvent
    from net_alpha.portfolio.cash_flow import compute_cash_kpis

    events = [
        CashEvent(
            account="Schwab/Tax",
            event_date=dt.date(2025, 1, 15),
            kind="transfer_in",
            amount=50000,
        ),
    ]
    kpis = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("60000"),
        period=None,
        period_starting_value=Decimal("0"),
    )
    # ending = 50000 + 60000 = 110000; starting = 0; contributions = 50000
    # Total Return = 110000 − 0 − 50000 = 60000
    assert kpis.growth == Decimal("60000")


# ---------------------------------------------------------------------------
# Tests for accounts= list filter (multi-account widening)
# ---------------------------------------------------------------------------


def test_build_cash_balance_series_accounts_list_filters_single():
    """accounts=['Schwab/A'] filters to only Schwab/A events."""
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 4), "transfer_in", 999.0, account="Schwab/B"),
    ]
    result = build_cash_balance_series(events=events, trades=[], accounts=["Schwab/A"], period=None)
    assert result[-1].cash_balance == Decimal("100")


def test_build_cash_balance_series_two_accounts_equals_all():
    """accounts=['Schwab/A', 'Schwab/B'] with account=None equals account=None."""
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 5), "transfer_in", 200.0, account="Schwab/B"),
    ]
    all_ = build_cash_balance_series(events=events, trades=[], period=None)
    both = build_cash_balance_series(events=events, trades=[], accounts=["Schwab/A", "Schwab/B"], period=None)
    assert all_ == both


def test_build_cash_balance_series_empty_accounts_means_all():
    """accounts=[] is treated as 'no filter' — same as account=None."""
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A")]
    all_ = build_cash_balance_series(events=events, trades=[], period=None)
    empty = build_cash_balance_series(events=events, trades=[], accounts=[], period=None)
    assert all_ == empty


def test_compute_cash_kpis_accounts_list_filters_single():
    """accounts=['Schwab/A'] filters to only Schwab/A events."""
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 4), "transfer_in", 999.0, account="Schwab/B"),
    ]
    result = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("0"),
        accounts=["Schwab/A"],
        period=None,
    )
    assert result.cash_balance == Decimal("100")


def test_compute_cash_kpis_two_accounts_equals_all():
    """accounts=['Schwab/A', 'Schwab/B'] with account=None equals no filter."""
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 5), "transfer_in", 200.0, account="Schwab/B"),
    ]
    all_ = compute_cash_kpis(events=events, trades=[], holdings_value=Decimal("0"), period=None)
    both = compute_cash_kpis(
        events=events,
        trades=[],
        holdings_value=Decimal("0"),
        accounts=["Schwab/A", "Schwab/B"],
        period=None,
    )
    assert all_ == both


def test_cash_allocation_slice_accounts_list_filters_single():
    """accounts=['Schwab/A'] filters to only Schwab/A events."""
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 4), "transfer_in", 999.0, account="Schwab/B"),
    ]
    result = cash_allocation_slice(events=events, trades=[], accounts=["Schwab/A"])
    assert result == Decimal("100")


# Tests for cash_balance_extremes


def test_cash_balance_extremes_empty():
    from net_alpha.portfolio.cash_flow import cash_balance_extremes

    assert cash_balance_extremes([]) is None


def test_cash_balance_extremes_single_point():
    from net_alpha.portfolio.cash_flow import cash_balance_extremes
    from net_alpha.portfolio.models import CashBalancePoint

    pts = [
        CashBalancePoint(on=dt.date(2024, 1, 1), cash_balance=Decimal("500"), cumulative_contributions=Decimal("500"))
    ]
    assert cash_balance_extremes(pts) == (Decimal("500"), dt.date(2024, 1, 1), Decimal("500"), dt.date(2024, 1, 1))


def test_cash_balance_extremes_multi_point():
    from net_alpha.portfolio.cash_flow import cash_balance_extremes
    from net_alpha.portfolio.models import CashBalancePoint

    pts = [
        CashBalancePoint(on=dt.date(2024, 1, 1), cash_balance=Decimal("1000"), cumulative_contributions=Decimal("0")),
        CashBalancePoint(on=dt.date(2024, 6, 1), cash_balance=Decimal("250"), cumulative_contributions=Decimal("0")),
        CashBalancePoint(on=dt.date(2025, 3, 1), cash_balance=Decimal("4200"), cumulative_contributions=Decimal("0")),
        CashBalancePoint(on=dt.date(2025, 9, 1), cash_balance=Decimal("3000"), cumulative_contributions=Decimal("0")),
    ]
    assert cash_balance_extremes(pts) == (
        Decimal("250"),
        dt.date(2024, 6, 1),
        Decimal("4200"),
        dt.date(2025, 3, 1),
    )


def test_cash_balance_extremes_tie_earliest_wins():
    from net_alpha.portfolio.cash_flow import cash_balance_extremes
    from net_alpha.portfolio.models import CashBalancePoint

    pts = [
        CashBalancePoint(on=dt.date(2024, 1, 1), cash_balance=Decimal("100"), cumulative_contributions=Decimal("0")),
        CashBalancePoint(on=dt.date(2024, 2, 1), cash_balance=Decimal("100"), cumulative_contributions=Decimal("0")),
        CashBalancePoint(on=dt.date(2024, 3, 1), cash_balance=Decimal("100"), cumulative_contributions=Decimal("0")),
    ]
    mn, mn_date, mx, mx_date = cash_balance_extremes(pts)
    assert mn == Decimal("100") and mn_date == dt.date(2024, 1, 1)
    assert mx == Decimal("100") and mx_date == dt.date(2024, 1, 1)


# --- pledged_cash_at -------------------------------------------------------

from net_alpha.models.domain import OptionDetails  # noqa: E402
from net_alpha.portfolio.cash_flow import pledged_cash_at  # noqa: E402


def _short_put(d, strike, expiry, qty=1, account="Schwab/x", ticker="SPY"):
    return Trade(
        id=f"sto-{d.isoformat()}",
        account=account,
        date=d,
        ticker=f"{ticker} {expiry.strftime('%Y-%m-%d')} P{strike}",
        action="Sell",
        quantity=float(qty),
        proceeds=100.0,
        cost_basis=None,
        gross_cash_impact=100.0,
        option_details=OptionDetails(
            strike=float(strike),
            expiry=expiry,
            call_put="P",
        ),
    )


def _btc(d, strike, expiry, qty=1, account="Schwab/x", ticker="SPY"):
    return Trade(
        id=f"btc-{d.isoformat()}",
        account=account,
        date=d,
        ticker=f"{ticker} {expiry.strftime('%Y-%m-%d')} P{strike}",
        action="Buy",
        quantity=float(qty),
        proceeds=None,
        cost_basis=50.0,
        gross_cash_impact=-50.0,
        option_details=OptionDetails(
            strike=float(strike),
            expiry=expiry,
            call_put="P",
        ),
    )


def test_pledged_zero_when_no_short_puts():
    assert pledged_cash_at(on=dt.date(2026, 5, 1), trades=[]) == Decimal("0")


def test_pledged_sums_open_short_put_collateral():
    trades = [_short_put(dt.date(2026, 4, 1), 400, dt.date(2026, 6, 20))]
    assert pledged_cash_at(on=dt.date(2026, 5, 1), trades=trades) == Decimal("40000")


def test_pledged_drops_after_btc_closes_position():
    trades = [
        _short_put(dt.date(2026, 4, 1), 400, dt.date(2026, 6, 20)),
        _btc(dt.date(2026, 4, 15), 400, dt.date(2026, 6, 20)),
    ]
    assert pledged_cash_at(on=dt.date(2026, 4, 14), trades=trades) == Decimal("40000")
    assert pledged_cash_at(on=dt.date(2026, 4, 16), trades=trades) == Decimal("0")


def test_pledged_ignores_short_calls():
    trades = [
        Trade(
            id="sc",
            account="Schwab/x",
            date=dt.date(2026, 4, 1),
            ticker="SPY 2026-06-20 C500",
            action="Sell",
            quantity=1.0,
            proceeds=200.0,
            cost_basis=None,
            gross_cash_impact=200.0,
            option_details=OptionDetails(strike=500.0, expiry=dt.date(2026, 6, 20), call_put="C"),
        ),
    ]
    assert pledged_cash_at(on=dt.date(2026, 5, 1), trades=trades) == Decimal("0")


def test_pledged_scales_with_quantity():
    trades = [_short_put(dt.date(2026, 4, 1), 400, dt.date(2026, 6, 20), qty=3)]
    assert pledged_cash_at(on=dt.date(2026, 5, 1), trades=trades) == Decimal("120000")


def test_pledged_excludes_trades_after_on():
    trades = [_short_put(dt.date(2026, 5, 5), 400, dt.date(2026, 6, 20))]
    assert pledged_cash_at(on=dt.date(2026, 5, 1), trades=trades) == Decimal("0")
