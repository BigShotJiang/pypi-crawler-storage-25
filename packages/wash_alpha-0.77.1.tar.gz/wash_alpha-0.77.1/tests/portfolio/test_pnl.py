import datetime as dt
from decimal import Decimal

from net_alpha.models.domain import Lot, OptionDetails, Trade, WashSaleViolation
from net_alpha.models.realized_gl import RealizedGLLot
from net_alpha.portfolio.pnl import compute_kpis, compute_wash_impact, realized_pl_from_trades
from net_alpha.pricing.provider import Quote


def _trade(**kw):
    defaults = dict(
        id="t1",
        account="Tax",
        date=dt.date(2025, 1, 15),
        ticker="SPY",
        action="Buy",
        quantity=100.0,
        proceeds=None,
        cost_basis=40_000.0,
        basis_unknown=False,
        option_details=None,
    )
    defaults.update(kw)
    return Trade(**defaults)


def _lot(**kw):
    defaults = dict(
        id="l1",
        trade_id="t1",
        account="Tax",
        date=dt.date(2025, 1, 15),
        ticker="SPY",
        quantity=100.0,
        cost_basis=40_000.0,
        adjusted_basis=40_000.0,
        option_details=None,
    )
    defaults.update(kw)
    return Lot(**defaults)


def _quote(symbol, price):
    return Quote(symbol=symbol, price=Decimal(str(price)), as_of=dt.datetime.now(dt.UTC), source="yahoo")


def test_kpis_zero_when_no_trades():
    k = compute_kpis(trades=[], lots=[], prices={}, period_label="YTD", period=(2026, 2027))
    assert k.period_realized == Decimal("0")
    assert k.lifetime_realized == Decimal("0")
    assert k.open_position_value == Decimal("0")
    assert k.lifetime_net_pl == Decimal("0")  # 0 realized + 0 unrealized (no missing prices since no lots)


def test_kpis_realized_split_by_period():
    trades = [
        _trade(id="t1", action="Sell", date=dt.date(2025, 6, 10), quantity=10, proceeds=5_000, cost_basis=4_000),
        _trade(id="t2", action="Sell", date=dt.date(2026, 3, 1), quantity=10, proceeds=6_000, cost_basis=4_500),
    ]
    k = compute_kpis(trades=trades, lots=[], prices={}, period_label="YTD", period=(2026, 2027))
    assert k.period_realized == Decimal("1500")
    assert k.lifetime_realized == Decimal("2500")


def test_kpis_unrealized_uses_prices_when_available():
    lots = [_lot()]
    k = compute_kpis(
        trades=[_trade()],
        lots=lots,
        prices={"SPY": _quote("SPY", 460)},
        period_label="YTD",
        period=(2026, 2027),
    )
    assert k.open_position_value == Decimal("46000")
    assert k.period_unrealized == Decimal("6000")
    assert k.lifetime_unrealized == Decimal("6000")
    assert k.lifetime_net_pl == Decimal("6000")  # 0 realized (Buy only) + 6000 unrealized
    assert k.missing_symbols == ()


def test_kpis_unrealized_none_when_all_lots_unpriced():
    lots = [_lot()]
    k = compute_kpis(trades=[_trade()], lots=lots, prices={}, period_label="YTD", period=(2026, 2027))
    assert k.open_position_value is None
    assert k.period_unrealized is None
    assert k.lifetime_unrealized is None
    assert k.lifetime_net_pl is None
    assert k.missing_symbols == ("SPY",)


def test_kpis_partial_when_some_lots_unpriced():
    """When some symbols can be priced and others can't, KPIs should reflect
    a partial sum scoped to the priced subset rather than collapsing to None."""
    lots = [
        _lot(id="l1", ticker="SPY", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0),
        _lot(id="l2", ticker="BITF", quantity=10.0, cost_basis=500.0, adjusted_basis=500.0),
    ]
    trades = [
        _trade(id="t1", ticker="SPY", quantity=100, cost_basis=40_000),
        _trade(id="t2", ticker="BITF", quantity=10, cost_basis=500),
    ]
    k = compute_kpis(
        trades=trades,
        lots=lots,
        prices={"SPY": _quote("SPY", 460)},  # BITF has no quote
        period_label="YTD",
        period=(2026, 2027),
    )
    # Open value reflects only SPY (the priced lot).
    assert k.open_position_value == Decimal("46000")
    # Unrealized = priced_market - priced_basis = 46000 - 40000 = 6000 (BITF excluded).
    assert k.period_unrealized == Decimal("6000")
    assert k.lifetime_unrealized == Decimal("6000")
    assert k.lifetime_net_pl == Decimal("6000")
    assert k.missing_symbols == ("BITF",)


def test_kpis_open_value_excludes_already_sold_lots():
    """Regression: lot.quantity is the original buy size and never decremented
    when the user sells. compute_kpis must FIFO-consume lots against sell
    trades, otherwise open_position_value double-counts shares the user has
    already disposed of."""
    lots = [
        _lot(id="l1", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0),
        _lot(id="l2", date=dt.date(2025, 3, 1), quantity=50.0, cost_basis=22_000.0, adjusted_basis=22_000.0),
    ]
    trades = [
        _trade(id="tb1", action="Buy", quantity=100, cost_basis=40_000),
        _trade(id="tb2", action="Buy", date=dt.date(2025, 3, 1), quantity=50, cost_basis=22_000),
        # Sell 100: should fully consume the first lot via FIFO.
        _trade(id="ts1", action="Sell", date=dt.date(2025, 6, 1), quantity=100, proceeds=46_000, cost_basis=40_000),
    ]
    k = compute_kpis(
        trades=trades,
        lots=lots,
        prices={"SPY": _quote("SPY", 460)},
        period_label="YTD",
        period=(2026, 2027),
    )
    # Only the second lot (50 shares) remains open after the FIFO sell.
    assert k.open_position_value == Decimal("23000")  # 50 * 460
    # Unrealized = market - prorated_basis = 23000 - 22000 = 1000.
    assert k.period_unrealized == Decimal("1000")
    assert k.lifetime_unrealized == Decimal("1000")


def test_kpis_open_value_carries_unexpired_options_at_basis():
    """No live option-quote provider exists, so unexpired option lots are
    carried at basis: contribute equally to market AND basis (so unrealized
    stays $0). Expired option lots contribute nothing — Schwab logs the
    expiration only in Realized G/L."""
    from net_alpha.models.domain import OptionDetails

    opt_open = OptionDetails(strike=200, expiry=dt.date(2027, 1, 15), call_put="C")
    opt_expired = OptionDetails(strike=180, expiry=dt.date(2025, 1, 17), call_put="P")
    lots = [
        _lot(id="leq", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0),
        _lot(
            id="lopt-open",
            date=dt.date(2025, 6, 1),
            ticker="NVDA",
            quantity=2.0,
            cost_basis=400.0,
            adjusted_basis=400.0,
            option_details=opt_open,
        ),
        _lot(
            id="lopt-exp",
            date=dt.date(2024, 11, 1),
            ticker="SPY",
            quantity=1.0,
            cost_basis=300.0,
            adjusted_basis=300.0,
            option_details=opt_expired,
        ),
    ]
    trades = [
        _trade(id="tb-eq", action="Buy", quantity=100, cost_basis=40_000),
        _trade(
            id="tb-opt-open",
            action="Buy",
            date=dt.date(2025, 6, 1),
            ticker="NVDA",
            quantity=2,
            cost_basis=400,
            option_details=opt_open,
        ),
        _trade(
            id="tb-opt-exp",
            action="Buy",
            date=dt.date(2024, 11, 1),
            ticker="SPY",
            quantity=1,
            cost_basis=300,
            option_details=opt_expired,
        ),
    ]
    k = compute_kpis(
        trades=trades,
        lots=lots,
        prices={"SPY": _quote("SPY", 460)},
        period_label="YTD",
        period=(2026, 2027),
        as_of=dt.date(2026, 5, 3),
    )
    # Equity 100 × 460 = 46000, plus unexpired option basis-carry 400 = 46400.
    # Expired option lot contributes nothing.
    assert k.open_position_value == Decimal("46400")
    # Unrealized is equity-only (6000) — the option's basis-carry exactly
    # cancels in the market/basis subtraction.
    assert k.period_unrealized == Decimal("6000")
    assert k.lifetime_unrealized == Decimal("6000")


def test_kpis_open_value_honors_gl_closures():
    """When a Realized G/L CSV reports a closure that has no matching trade
    row (Schwab logs option expirations / corporate actions only in GL),
    compute_kpis must still treat the lot as closed."""
    lots = [_lot(id="l1", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0)]
    trades = [_trade(id="tb1", action="Buy", quantity=100, cost_basis=40_000)]
    gl_lots = [
        RealizedGLLot(
            id="g1",
            account_display="Tax",
            symbol_raw="SPY",
            ticker="SPY",
            opened_date=dt.date(2025, 1, 15),
            closed_date=dt.date(2025, 6, 1),
            quantity=100.0,
            proceeds=46_000.0,
            cost_basis=40_000.0,
            unadjusted_cost_basis=40_000.0,
            wash_sale=False,
            disallowed_loss=0.0,
            term="Short",
        ),
    ]
    k = compute_kpis(
        trades=trades,
        lots=lots,
        prices={"SPY": _quote("SPY", 460)},
        period_label="YTD",
        period=(2026, 2027),
        gl_lots=gl_lots,
    )
    assert k.open_position_value == Decimal("0")
    # No open lots are priced, so unrealized collapses too — unrealized for an
    # empty open subset is just 0 (the all_unpriced guard only fires when there
    # are equity lots that we couldn't price).
    assert k.period_unrealized == Decimal("0")


def _violation(loss_date, *, disallowed=100.0, confidence="Confirmed", loss_account="Tax", buy_account="Tax"):
    return WashSaleViolation(
        id="v",
        loss_trade_id="t1",
        replacement_trade_id="t2",
        loss_account=loss_account,
        buy_account=buy_account,
        loss_sale_date=loss_date,
        triggering_buy_date=loss_date,
        ticker="SPY",
        confidence=confidence,
        disallowed_loss=disallowed,
        matched_quantity=10.0,
        source="engine",
    )


def test_wash_impact_period_filters_by_loss_date():
    violations = [
        _violation(dt.date(2026, 3, 1), disallowed=200, confidence="Confirmed"),
        _violation(dt.date(2025, 3, 1), disallowed=300, confidence="Probable"),
    ]
    out = compute_wash_impact(violations=violations, period_label="YTD", period=(2026, 2027))
    assert out.violation_count == 1
    assert out.disallowed_total == Decimal("200")
    assert out.confirmed_count == 1
    assert out.probable_count == 0


def test_wash_impact_account_filter_matches_either_side():
    v1 = _violation(dt.date(2026, 3, 1), loss_account="IRA", buy_account="IRA")
    v2 = _violation(dt.date(2026, 3, 2), loss_account="Tax", buy_account="Tax")
    v3 = _violation(dt.date(2026, 3, 3), loss_account="IRA", buy_account="Tax")  # cross-account
    out = compute_wash_impact(violations=[v1, v2, v3], period_label="YTD", period=(2026, 2027), accounts=["Tax"])
    # v2 (both Tax) and v3 (Tax on buy side) match; v1 (both IRA) does not
    assert out.violation_count == 2


def test_realized_pl_distributes_sto_premium_across_partial_btcs():
    # STO 2 contracts for $1698.67 premium, then close as two separate
    # 1-contract BTCs ($236.66 + $101.66). The premium must be split per
    # contract (not credited in full to each BTC), otherwise lifetime P&L
    # is inflated by the entire STO premium — exactly the TSLA divergence
    # users hit when net-alpha showed $3841.11 vs Schwab's $2142.44.
    opt = OptionDetails(strike=455.0, expiry=dt.date(2025, 10, 24), call_put="C")
    trades = [
        _trade(
            id="t_sto",
            ticker="TSLA",
            action="Sell",
            quantity=2.0,
            proceeds=1698.67,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2025, 10, 22),
        ),
        _trade(
            id="t_btc1",
            ticker="TSLA",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=236.66,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2025, 10, 23),
        ),
        _trade(
            id="t_btc2",
            ticker="TSLA",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=101.66,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2025, 10, 23),
        ),
    ]
    realized = realized_pl_from_trades(trades, period=None)
    # Correct: 1698.67 - 236.66 - 101.66 = 1360.35
    assert abs(realized - Decimal("1360.35")) < Decimal("0.01")


def test_realized_pl_unequal_btc_quantities_split_premium_proportionally():
    # STO 4 contracts for $400 total premium. Close 3 + 1.
    opt = OptionDetails(strike=100.0, expiry=dt.date(2025, 12, 19), call_put="P")
    trades = [
        _trade(
            id="t_sto",
            action="Sell",
            quantity=4.0,
            proceeds=400.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2025, 6, 1),
        ),
        _trade(
            id="t_btc1",
            action="Buy",
            quantity=3.0,
            proceeds=None,
            cost_basis=120.0,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2025, 7, 1),
        ),
        _trade(
            id="t_btc2",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=30.0,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2025, 7, 15),
        ),
    ]
    realized = realized_pl_from_trades(trades, period=None)
    # 400 (premium) - 120 - 30 = 250
    assert abs(realized - Decimal("250")) < Decimal("0.01")


def _gl_lot(**kw):
    defaults = dict(
        account_display="Tax",
        symbol_raw="OSCR 01/16/2026 25.00 C",
        ticker="OSCR",
        closed_date=dt.date(2026, 1, 16),
        opened_date=dt.date(2025, 10, 10),
        quantity=1.0,
        proceeds=0.0,
        cost_basis=258.66,
        unadjusted_cost_basis=258.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
        option_strike=25.0,
        option_expiry="2026-01-16",
        option_call_put="C",
    )
    defaults.update(kw)
    return RealizedGLLot(**defaults)


def test_realized_pl_synthesizes_long_option_expiry_from_gl():
    # Schwab "Transactions" CSV records "Expired" rows that the parser drops,
    # leaving the trades table without a Sell-to-Close counterpart for long
    # options that expired worthless. Without GL data, those losses are
    # silently missed by realized_pl_from_trades. The Realized G/L CSV
    # records the closure (proceeds=0, cost=N), so we reconcile from there.
    #
    # Real-world OSCR repro: 25C 01/16/2026 (qty 1, basis 258.66) and 30C
    # 01/16/2026 (qty 2, basis 160.66 each) all expired on 2026-01-16.
    # Trade table has only the BTOs. Schwab GL has the closures. Net-alpha
    # must include them in YTD/lifetime realized P&L.
    opt_25c = OptionDetails(strike=25.0, expiry=dt.date(2026, 1, 16), call_put="C")
    opt_30c = OptionDetails(strike=30.0, expiry=dt.date(2026, 1, 16), call_put="C")
    trades = [
        # BTO of long 25C on 2025-10-10 (cost 258.66) — no STC counterpart
        _trade(
            id="bto_25c",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=258.66,
            basis_source="unknown",
            option_details=opt_25c,
            date=dt.date(2025, 10, 10),
        ),
        # BTO of long 30C #1 on 2025-10-10
        _trade(
            id="bto_30c_a",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=160.66,
            basis_source="unknown",
            option_details=opt_30c,
            date=dt.date(2025, 10, 10),
        ),
        # BTO of long 30C #2 on 2025-10-20
        _trade(
            id="bto_30c_b",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=160.66,
            basis_source="unknown",
            option_details=opt_30c,
            date=dt.date(2025, 10, 20),
        ),
    ]
    gl_lots = [
        _gl_lot(option_strike=25.0, cost_basis=258.66, opened_date=dt.date(2025, 10, 10)),
        _gl_lot(
            option_strike=30.0,
            symbol_raw="OSCR 01/16/2026 30.00 C",
            cost_basis=160.66,
            opened_date=dt.date(2025, 10, 10),
        ),
        _gl_lot(
            option_strike=30.0,
            symbol_raw="OSCR 01/16/2026 30.00 C",
            cost_basis=160.66,
            opened_date=dt.date(2025, 10, 20),
        ),
    ]
    # YTD 2026 realized: -258.66 -160.66 -160.66 = -579.98
    realized_ytd = realized_pl_from_trades(trades, period=(2026, 2027), gl_lots=gl_lots)
    assert abs(realized_ytd - Decimal("-579.98")) < Decimal("0.01")
    # Lifetime same: no other realizations
    realized_life = realized_pl_from_trades(trades, period=None, gl_lots=gl_lots)
    assert abs(realized_life - Decimal("-579.98")) < Decimal("0.01")


def test_realized_pl_does_not_double_count_when_gl_pairs_with_trade_close():
    # The Schwab GL CSV records the same close events as the trade-side STCs
    # and BTCs already in the trades table. We must NOT double-count: when a
    # GL lot has a matching close trade (STC or BTC) on the same / adjacent
    # date for the same option key, the trade-side already accounted for it.
    opt = OptionDetails(strike=25.0, expiry=dt.date(2026, 1, 16), call_put="C")
    trades = [
        _trade(
            id="bto",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=185.66,
            basis_source="unknown",
            option_details=opt,
            date=dt.date(2025, 10, 1),
        ),
        # STC on 2025-10-03 with cost_basis from g_l → realized P&L = +98.68
        _trade(
            id="stc",
            ticker="OSCR",
            action="Sell",
            quantity=1.0,
            proceeds=284.34,
            cost_basis=185.66,
            basis_source="g_l",
            option_details=opt,
            date=dt.date(2025, 10, 3),
        ),
    ]
    # Schwab GL row for the same close (closed_date matches trade date)
    gl_lots = [
        _gl_lot(
            closed_date=dt.date(2025, 10, 3),
            opened_date=dt.date(2025, 10, 1),
            proceeds=284.34,
            cost_basis=185.66,
        ),
    ]
    realized = realized_pl_from_trades(trades, period=None, gl_lots=gl_lots)
    # Only count it once: 284.34 - 185.66 = 98.68 (NOT 197.36)
    assert abs(realized - Decimal("98.68")) < Decimal("0.01")


def test_realized_pl_pairs_btc_with_gl_at_settlement_offset():
    # Schwab GL `closed_date` is settle date (T+1) while the BTC trade row
    # carries the actual trade date. Pairing must tolerate a ±1 day gap so
    # the BTC's premium-share P&L isn't doubled by a "synthetic" GL close.
    opt = OptionDetails(strike=17.0, expiry=dt.date(2025, 8, 15), call_put="P")
    trades = [
        # STO premium received
        _trade(
            id="sto",
            ticker="OSCR",
            action="Sell",
            quantity=1.0,
            proceeds=269.34,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2025, 7, 2),
        ),
        # BTC on 2025-08-07 closes the short (paired premium realized)
        _trade(
            id="btc",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=212.66,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2025, 8, 7),
        ),
    ]
    # Schwab GL records closed_date as T+1 settlement
    gl_lots = [
        _gl_lot(
            symbol_raw="OSCR 08/15/2025 17.00 P",
            ticker="OSCR",
            closed_date=dt.date(2025, 8, 8),
            opened_date=dt.date(2025, 7, 2),
            proceeds=269.34,
            cost_basis=212.66,
            option_strike=17.0,
            option_expiry="2025-08-15",
            option_call_put="P",
        ),
    ]
    realized = realized_pl_from_trades(trades, period=None, gl_lots=gl_lots)
    # Pair-counted once: 269.34 - 212.66 = 56.68. Without ±1-day pairing
    # the GL would synthesize a duplicate +56.68.
    assert abs(realized - Decimal("56.68")) < Decimal("0.01")


def test_compute_kpis_emits_economic_realized_alongside_recognized():
    # KpiSet exposes both views: tax-recognized (the main number, matches
    # Schwab UI) and economic (the actual cash netted, recognized minus the
    # wash-sale add-back). The Realized P/L tile renders both.
    gl_lots = [
        _gl_lot(
            symbol_raw="PANW",
            ticker="PANW",
            closed_date=dt.date(2025, 8, 12),
            opened_date=dt.date(2025, 8, 5),
            proceeds=199.34,
            cost_basis=255.66,
            unadjusted_cost_basis=255.66,
            wash_sale=True,
            disallowed_loss=56.32,
            option_strike=None,
            option_expiry=None,
            option_call_put=None,
        ),
    ]
    k = compute_kpis(
        trades=[],
        lots=[],
        prices={},
        period_label="2025",
        period=(2025, 2026),
        gl_lots=gl_lots,
    )
    # Recognized = (proc - cb) + disallowed = -56.32 + 56.32 = 0
    assert abs(k.period_realized - Decimal("0")) < Decimal("0.01")
    # Economic = (proc - cb) = -56.32 (actual cash loss before wash adjustment)
    assert abs(k.period_realized_economic - Decimal("-56.32")) < Decimal("0.01")


def test_realized_pl_adds_back_wash_sale_disallowed_loss():
    # Real-world PANW repro: 2 closes — one with a $56.32 loss fully disallowed
    # by §1091, one with a $102.36 gain. Schwab's UI and Form 8949 add the
    # disallowed loss back to the lot's realized P&L (the loss shifts to the
    # replacement lot's basis), so the recognized period total is +$102.36, not
    # the economic +$46.04.
    gl_lots = [
        _gl_lot(
            symbol_raw="PANW",
            ticker="PANW",
            closed_date=dt.date(2025, 8, 12),
            opened_date=dt.date(2025, 8, 5),
            proceeds=199.34,
            cost_basis=255.66,
            unadjusted_cost_basis=255.66,
            wash_sale=True,
            disallowed_loss=56.32,
            option_strike=None,
            option_expiry=None,
            option_call_put=None,
        ),
        _gl_lot(
            symbol_raw="PANW",
            ticker="PANW",
            closed_date=dt.date(2025, 8, 13),
            opened_date=dt.date(2025, 8, 6),
            proceeds=299.34,
            cost_basis=196.98,
            unadjusted_cost_basis=196.98,
            wash_sale=False,
            disallowed_loss=0.0,
            option_strike=None,
            option_expiry=None,
            option_call_put=None,
        ),
    ]
    realized = realized_pl_from_trades([], period=(2025, 2026), gl_lots=gl_lots)
    # 102.36 (gain) + 0 (loss recognized as zero, $56.32 shifted to replacement)
    assert abs(realized - Decimal("102.36")) < Decimal("0.01")


def test_realized_pl_pairs_btc_across_weekend_settlement():
    # Real-world UUUU repro: a BTC traded on a Friday settles Monday — a
    # 3-calendar-day gap. With a 2-day tolerance the GL synth path counted
    # the closure a second time, inflating YTD realized by the full premium
    # delta. Tolerance must cover Fri→Mon (3 days) and Fri→Tue across a
    # Monday holiday (4 days).
    opt = OptionDetails(strike=20.0, expiry=dt.date(2026, 1, 16), call_put="P")
    trades = [
        _trade(
            id="sto",
            ticker="UUUU",
            action="Sell",
            quantity=1.0,
            proceeds=486.34,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2025, 12, 11),
        ),
        # BTC on Fri 2026-01-09; Schwab settles it Mon 2026-01-12 (3-day gap).
        _trade(
            id="btc",
            ticker="UUUU",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=140.66,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2026, 1, 9),
        ),
    ]
    gl_lots = [
        _gl_lot(
            symbol_raw="UUUU 01/16/2026 20.00 P",
            ticker="UUUU",
            closed_date=dt.date(2026, 1, 12),  # Monday settlement after Friday trade
            opened_date=dt.date(2025, 12, 12),
            proceeds=486.34,
            cost_basis=140.66,
            option_strike=20.0,
            option_expiry="2026-01-16",
            option_call_put="P",
        ),
    ]
    realized = realized_pl_from_trades(trades, period=(2026, 2027), gl_lots=gl_lots)
    # Counted once: 486.34 - 140.66 = 345.68. With the old 2-day tolerance
    # the GL would have added a duplicate 345.68 → 691.36.
    assert abs(realized - Decimal("345.68")) < Decimal("0.01")


def test_realized_pl_period_filter_uses_gl_closed_date():
    # GL-synthesized closures must respect the period filter using the GL's
    # closed_date, not the trade's BTO date. An OSCR call bought in 2025 that
    # expired in 2026 belongs to YTD 2026, not YTD 2025.
    opt = OptionDetails(strike=25.0, expiry=dt.date(2026, 1, 16), call_put="C")
    trades = [
        _trade(
            id="bto",
            ticker="OSCR",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=258.66,
            basis_source="unknown",
            option_details=opt,
            date=dt.date(2025, 10, 10),
        ),
    ]
    gl_lots = [_gl_lot(opened_date=dt.date(2025, 10, 10))]
    # YTD 2025 should NOT include the 2026 expiry
    assert realized_pl_from_trades(trades, period=(2025, 2026), gl_lots=gl_lots) == Decimal("0")
    # YTD 2026 should
    realized = realized_pl_from_trades(trades, period=(2026, 2027), gl_lots=gl_lots)
    assert abs(realized - Decimal("-258.66")) < Decimal("0.01")


def test_wash_impact_lifetime_when_period_is_none():
    violations = [
        _violation(dt.date(2024, 6, 1), confidence="Unclear"),
        _violation(dt.date(2025, 6, 1), confidence="Probable"),
    ]
    out = compute_wash_impact(violations=violations, period_label="Lifetime", period=None)
    assert out.violation_count == 2
    assert out.unclear_count == 1
    assert out.probable_count == 1


def test_short_put_otm_uses_time_decay():
    """Sold OTM put: intrinsic = 0, decay shrinks the liability over time.

    Setup: sold 1 SPY 500P at $5.00 premium ($500 total) on 2026-04-03,
    expires 2026-07-02 (90 days total). Today 2026-05-03 (60 days left).
    Spot $520 → put intrinsic = 0.

    time_value_per_share = 5.00 * (60/90) = 3.333…
    est_value_to_close   = max(0, 3.333) = 3.333 → liability $333.33
    unrealized           = $500 - $333.33 = +$166.67
    """
    today = dt.date(2026, 5, 3)
    expiry = dt.date(2026, 7, 2)
    open_date = dt.date(2026, 4, 3)

    trade = Trade(
        account="X",
        date=open_date,
        ticker="SPY",
        action="Sell",
        quantity=1.0,
        cost_basis=None,
        proceeds=500.0,
        gross_cash_impact=500.0,
        basis_source="option_short_open",
        option_details=OptionDetails(strike=500.0, expiry=expiry, call_put="P"),
    )
    prices = {
        "SPY": Quote(
            symbol="SPY",
            price=Decimal("520.00"),
            previous_close=Decimal("519"),
            as_of=dt.datetime(2026, 5, 3, 16, 0, tzinfo=dt.UTC),
            source="yahoo",
        )
    }

    kpis = compute_kpis(
        trades=[trade],
        lots=[],
        prices=prices,
        period_label="YTD 2026",
        period=(2026, 2027),
        as_of=today,
    )
    assert kpis.period_unrealized is not None
    assert abs(kpis.period_unrealized - Decimal("166.67")) < Decimal("0.50")


def test_short_put_itm_uses_intrinsic_floor():
    """Sold ITM put: spot $480 < strike $500 → intrinsic $20/sh × 100 = $2000 liability.

    time_value = $500 * (60/90) = $333.33
    est_value_to_close = max(2000, 333.33) = $2000
    unrealized = $500 - $2000 = -$1500
    """
    today = dt.date(2026, 5, 3)
    expiry = dt.date(2026, 7, 2)
    open_date = dt.date(2026, 4, 3)

    trade = Trade(
        account="X",
        date=open_date,
        ticker="SPY",
        action="Sell",
        quantity=1.0,
        cost_basis=None,
        proceeds=500.0,
        gross_cash_impact=500.0,
        basis_source="option_short_open",
        option_details=OptionDetails(strike=500.0, expiry=expiry, call_put="P"),
    )
    prices = {
        "SPY": Quote(
            symbol="SPY",
            price=Decimal("480.00"),
            previous_close=Decimal("481"),
            as_of=dt.datetime(2026, 5, 3, 16, 0, tzinfo=dt.UTC),
            source="yahoo",
        )
    }

    kpis = compute_kpis(
        trades=[trade],
        lots=[],
        prices=prices,
        period_label="YTD 2026",
        period=(2026, 2027),
        as_of=today,
    )
    assert kpis.period_unrealized is not None
    assert abs(kpis.period_unrealized - Decimal("-1500.00")) < Decimal("1.00")


def test_short_covered_call_itm_uses_call_intrinsic():
    """Sold 2 NVDA 850C for $1200 premium total on 2026-03-31 (60 days
    total). Today 2026-05-03 (27 days left to 2026-05-30 expiry). Spot $872.

    intrinsic_per_share = max(0, 872 - 850) = 22
    intrinsic_total     = 22 * 2 contracts * 100 = $4400 liability
    premium_per_share   = 1200 / 2 / 100 = 6.00
    time_value_per_share= 6.00 * 27/60 = 2.70
    est_value_per_share = max(22, 2.70) = 22
    est_liability       = 22 * 2 * 100 = 4400
    unrealized          = 1200 - 4400 = -3200
    """
    today = dt.date(2026, 5, 3)
    expiry = dt.date(2026, 5, 30)
    open_date = dt.date(2026, 3, 31)

    trade = Trade(
        account="X",
        date=open_date,
        ticker="NVDA",
        action="Sell",
        quantity=2.0,
        cost_basis=None,
        proceeds=1200.0,
        gross_cash_impact=1200.0,
        basis_source="option_short_open",
        option_details=OptionDetails(strike=850.0, expiry=expiry, call_put="C"),
    )
    prices = {
        "NVDA": Quote(
            symbol="NVDA",
            price=Decimal("872.00"),
            previous_close=Decimal("870"),
            as_of=dt.datetime(2026, 5, 3, 16, 0, tzinfo=dt.UTC),
            source="yahoo",
        )
    }

    kpis = compute_kpis(
        trades=[trade],
        lots=[],
        prices=prices,
        period_label="YTD 2026",
        period=(2026, 2027),
        as_of=today,
    )
    assert kpis.period_unrealized is not None
    assert abs(kpis.period_unrealized - Decimal("-3200.00")) < Decimal("1.00")


def test_short_option_no_underlying_quote_falls_back_to_zero():
    """If we don't have an underlying quote, the short option contributes
    0 unrealized (rather than crashing or making something up)."""
    today = dt.date(2026, 5, 3)
    expiry = dt.date(2026, 7, 2)
    open_date = dt.date(2026, 4, 3)

    trade = Trade(
        account="X",
        date=open_date,
        ticker="WXYZ",
        action="Sell",
        quantity=1.0,
        cost_basis=None,
        proceeds=500.0,
        gross_cash_impact=500.0,
        basis_source="option_short_open",
        option_details=OptionDetails(strike=500.0, expiry=expiry, call_put="P"),
    )

    # No quote for WXYZ. Also no equity lots, so no other unrealized to worry about.
    kpis = compute_kpis(
        trades=[trade],
        lots=[],
        prices={},
        period_label="YTD 2026",
        period=(2026, 2027),
        as_of=today,
    )
    # The short option contributes 0 because we can't price the underlying.
    # period_unrealized will be 0 (or possibly None if "all_unpriced" logic kicks
    # in — but there are no equity lots, so all_unpriced stays False, and
    # period_unrealized is the sum, which is 0).
    assert kpis.period_unrealized == Decimal("0")


def test_short_option_closed_via_gl_does_not_contribute_to_unrealized():
    """A short option closed by a Realized G/L import (no BTC trade row)
    must drop out of unrealized — otherwise it phantom-contributes after
    the user imports their GL CSV.
    """
    today = dt.date(2026, 5, 3)
    expiry = dt.date(2026, 7, 2)
    open_date = dt.date(2026, 4, 3)

    trade = Trade(
        account="X",
        date=open_date,
        ticker="SPY",
        action="Sell",
        quantity=1.0,
        cost_basis=None,
        proceeds=500.0,
        gross_cash_impact=500.0,
        basis_source="option_short_open",
        option_details=OptionDetails(strike=500.0, expiry=expiry, call_put="P"),
    )

    # Mark the short put as closed via a GL import: 1 contract on this chain
    # was closed (e.g., expired worthless on a date Schwab only logged in GL).
    gl_lot = RealizedGLLot(
        account_display="X",
        symbol_raw="SPY 07/02/2026 500.00 P",
        ticker="SPY",
        quantity=1.0,
        cost_basis=0.0,
        unadjusted_cost_basis=0.0,
        proceeds=500.0,
        opened_date=open_date,
        closed_date=dt.date(2026, 6, 30),
        term="Short Term",
        wash_sale=False,
        disallowed_loss=0.0,
        option_strike=500.0,
        option_expiry=expiry.isoformat(),
        option_call_put="P",
    )

    prices = {
        "SPY": Quote(
            symbol="SPY",
            price=Decimal("520.00"),
            previous_close=Decimal("519"),
            as_of=dt.datetime(2026, 5, 3, 16, 0, tzinfo=dt.UTC),
            source="yahoo",
        ),
    }

    kpis = compute_kpis(
        trades=[trade],
        lots=[],
        prices=prices,
        period_label="YTD 2026",
        period=(2026, 2027),
        as_of=today,
        gl_lots=[gl_lot],
    )
    # Without the fix, the OTM short put would contribute +$166.67.
    # With the fix, the GL closure flushes the short → contribution = 0.
    assert kpis.period_unrealized == Decimal("0")


def test_compute_kpis_accounts_list_matches_single_account():
    """accounts=['Tax'] must equal today's account='Tax'."""
    trades = [
        _trade(id="t1", account="Tax", ticker="SPY", action="Buy", quantity=10.0, cost_basis=1000.0),
        _trade(id="t2", account="IRA", ticker="SPY", action="Buy", quantity=5.0, cost_basis=500.0),
    ]
    lots = [
        _lot(
            id="l1", trade_id="t1", account="Tax", ticker="SPY", quantity=10.0, cost_basis=1000.0, adjusted_basis=1000.0
        ),
        _lot(id="l2", trade_id="t2", account="IRA", ticker="SPY", quantity=5.0, cost_basis=500.0, adjusted_basis=500.0),
    ]
    prices = {"SPY": _quote("SPY", 120)}
    kpis_single = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label="Lifetime",
        period=None,
        accounts=["Tax"],
    )
    kpis_list = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label="Lifetime",
        period=None,
        accounts=["Tax"],
    )
    assert kpis_single == kpis_list


def test_compute_kpis_accounts_list_two_equals_union():
    """accounts=['Tax', 'IRA'] equals account=None (no filter) when those are the only accounts."""
    trades = [
        _trade(id="t1", account="Tax", ticker="SPY", action="Buy", quantity=10.0, cost_basis=1000.0),
        _trade(id="t2", account="IRA", ticker="SPY", action="Buy", quantity=5.0, cost_basis=500.0),
    ]
    lots = [
        _lot(
            id="l1", trade_id="t1", account="Tax", ticker="SPY", quantity=10.0, cost_basis=1000.0, adjusted_basis=1000.0
        ),
        _lot(id="l2", trade_id="t2", account="IRA", ticker="SPY", quantity=5.0, cost_basis=500.0, adjusted_basis=500.0),
    ]
    prices = {"SPY": _quote("SPY", 120)}
    kpis_all = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label="Lifetime",
        period=None,
    )
    kpis_both = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label="Lifetime",
        period=None,
        accounts=["Tax", "IRA"],
    )
    assert kpis_all == kpis_both


def test_compute_kpis_empty_accounts_means_all():
    trades = [_trade(id="t1", account="Tax", ticker="SPY")]
    lots = [_lot(id="l1", trade_id="t1", account="Tax", ticker="SPY")]
    prices = {"SPY": _quote("SPY", 410)}
    kpis_none = compute_kpis(trades=trades, lots=lots, prices=prices, period_label="Lifetime", period=None)
    kpis_empty = compute_kpis(
        trades=trades, lots=lots, prices=prices, period_label="Lifetime", period=None, accounts=[]
    )
    assert kpis_none == kpis_empty


def test_compute_wash_impact_accounts_list_or_semantic():
    """A cross-account violation (loss=Tax, buy=IRA) must appear under filter ['Tax'] AND ['IRA']."""
    v_cross = _violation(dt.date(2026, 3, 1), loss_account="Tax", buy_account="IRA")
    v_other = _violation(dt.date(2026, 3, 2), loss_account="Other", buy_account="Other")

    only_tax = compute_wash_impact(
        violations=[v_cross, v_other],
        period_label="YTD",
        period=(2026, 2027),
        accounts=["Tax"],
    )
    only_ira = compute_wash_impact(
        violations=[v_cross, v_other],
        period_label="YTD",
        period=(2026, 2027),
        accounts=["IRA"],
    )
    assert only_tax.violation_count == 1
    assert only_ira.violation_count == 1


def test_compute_wash_impact_accounts_list_single_matches_legacy():
    v_cross = _violation(dt.date(2026, 3, 1), loss_account="Tax", buy_account="IRA")
    result_a = compute_wash_impact(violations=[v_cross], period_label="YTD", period=(2026, 2027), accounts=["Tax"])
    result_b = compute_wash_impact(violations=[v_cross], period_label="YTD", period=(2026, 2027), accounts=["Tax"])
    assert result_a == result_b


def test_partial_btc_does_not_double_count_in_lifetime_net_pl():
    """STO 2c @ $100/contract (total premium $200), BTC 1c @ $50, leaving 1c open.

    Realized (paired premium - btc cost):    (200 × 1/2) − 50 = +$50
    Today: spot $100.80, strike $100 call, expiry 60d out, opened 30d ago →
        intrinsic_per_share  = max(0, 100.80 − 100) = 0.80
        premium_per_share (TRUE)    = 200/2/100 = 1.00
        days_remaining/days_total = 30/60 = 0.5
        time_value_per_share = 1.00 × 0.5 = 0.50
        est_value_per_share  = max(0.80, 0.50) = 0.80
        est_liability        = 0.80 × 1 × 100 = $80

    Correct unrealized for the remaining contract:
        sto_premium_for_remaining (200 × 1/2 = 100) − est_liability(80) = +$20
    Correct lifetime_net_pl: realized($50) + unrealized($20) = +$70

    Pre-fix: row.premium_received is NET of BTC ($150), so unrealized
    miscalculates as 150 − 80 = +$70 → lifetime_net_pl = 50 + 70 = $120,
    overstating by exactly the BTC cost ($50) which was already booked as
    realized.
    """
    today = dt.date(2026, 5, 3)
    opened = dt.date(2026, 4, 3)
    btc_date = dt.date(2026, 4, 17)
    expiry = dt.date(2026, 6, 2)  # 60 days from opened
    opt = OptionDetails(strike=100.0, expiry=expiry, call_put="C")
    trades = [
        Trade(
            id="sto",
            account="Tax",
            date=opened,
            ticker="ACME",
            action="Sell",
            quantity=2.0,
            cost_basis=None,
            proceeds=200.0,
            gross_cash_impact=200.0,
            basis_source="option_short_open",
            option_details=opt,
        ),
        Trade(
            id="btc",
            account="Tax",
            date=btc_date,
            ticker="ACME",
            action="Buy",
            quantity=1.0,
            cost_basis=50.0,
            proceeds=None,
            gross_cash_impact=-50.0,
            basis_source="option_short_close",
            option_details=opt,
        ),
    ]
    prices = {
        "ACME": Quote(
            symbol="ACME",
            price=Decimal("100.80"),
            previous_close=Decimal("100.80"),
            as_of=dt.datetime(2026, 5, 3, 16, 0, tzinfo=dt.UTC),
            source="yahoo",
        )
    }
    kpis = compute_kpis(
        trades=trades,
        lots=[],
        prices=prices,
        period_label="Lifetime",
        period=None,
        as_of=today,
    )
    # Realized: +$50
    assert abs(kpis.lifetime_realized - Decimal("50")) < Decimal("0.01")
    # Unrealized for the remaining 1c: +$20 (NOT +$70)
    assert kpis.lifetime_unrealized is not None
    assert abs(kpis.lifetime_unrealized - Decimal("20")) < Decimal("0.01")
    # Lifetime net: +$70 (NOT +$120)
    assert kpis.lifetime_net_pl is not None
    assert abs(kpis.lifetime_net_pl - Decimal("70")) < Decimal("0.01")


def test_compute_open_short_option_exposes_sto_premium_for_remaining_contracts():
    """`compute_open_short_option_positions` must expose enough info for the
    unrealized estimator to compute the STO-only per-share premium for the
    *still-open* contracts (not the chain-wide net-of-BTC figure divided by
    remaining qty).

    For STO 2c @ $200 total premium then BTC 1c @ $50:
      - premium_received (net) = $150 — what cash actually stayed in the chain
      - sto_premium_total      = $200 — gross STO proceeds across the chain
      - sto_qty_total          = 2 contracts
      - qty_short              = 1 (still open)
      → STO premium attributable to remaining = 200 × 1/2 = $100
      → premium_per_share (STO, remaining) = 100 / 1 / 100 = $1.00

    Pre-fix the only way to derive per-share was net/remaining = 150/1/100 = $1.50,
    which double-counts the BTC cost.
    """
    from net_alpha.portfolio.positions import compute_open_short_option_positions

    opt = OptionDetails(strike=100.0, expiry=dt.date(2026, 6, 2), call_put="C")
    trades = [
        Trade(
            id="sto",
            account="Tax",
            date=dt.date(2026, 4, 3),
            ticker="ACME",
            action="Sell",
            quantity=2.0,
            cost_basis=None,
            proceeds=200.0,
            gross_cash_impact=200.0,
            basis_source="option_short_open",
            option_details=opt,
        ),
        Trade(
            id="btc",
            account="Tax",
            date=dt.date(2026, 4, 17),
            ticker="ACME",
            action="Buy",
            quantity=1.0,
            cost_basis=50.0,
            proceeds=None,
            gross_cash_impact=-50.0,
            basis_source="option_short_close",
            option_details=opt,
        ),
    ]
    rows = compute_open_short_option_positions(trades)
    assert len(rows) == 1
    row = rows[0]
    assert row.qty_short == Decimal("1")
    assert row.premium_received == Decimal("150.00")  # net of BTC, unchanged contract
    assert row.sto_premium_total == Decimal("200.00")  # gross STO proceeds
    assert row.sto_qty_total == Decimal("2")


def test_open_short_option_opened_at_uses_earliest_unmatched_sto():
    """Audit #36 / #9: ``opened_at`` must reflect the date the still-open
    contracts were *actually* opened — FIFO match BTC closures against STO
    legs and report the earliest STO whose qty hasn't been fully consumed.

    Chain: STO 1c Jan, STO 1c Mar, BTC 1c Apr → one contract still open.
    Per FIFO, BTC consumes the January STO first, leaving the March STO
    open. Pre-fix the helper just tracked "latest STO date" regardless of
    whether it had been closed, returning March — but if FIFO matters
    (and it does for §1223 holding-period tacking + the unrealized
    estimator's time-decay base) the correct answer is March here.

    Conversely: STO 1c Jan, STO 1c Mar, BTC 1c Feb (BTC dated *between*
    the two STOs) — FIFO still consumes the January STO first, leaving
    March open. Pre-fix returned March (latest STO) which happens to be
    correct here. The discriminating case below: STO 1c Mar then STO 1c
    Jan (out-of-order import) + BTC 1c Apr — FIFO matches the earliest
    STO (Jan) leaving Mar open. Pre-fix returns Mar (latest), which is
    the correct answer; but the more important property is that
    ``opened_at`` is derived from the FIFO-consumption walk, not the
    raw max-date.

    Most direct counter-example: STO 1c Jan + STO 1c Feb + BTC 1c Mar
    leaving 1c open. FIFO consumes the Jan STO; ``opened_at`` = Feb.
    Pre-fix returns Feb (latest), which is correct. To produce a real
    divergence we need a chain where FIFO opening date < latest STO
    date AND the latest STO is fully closed. E.g. STO 1c Jan + STO 1c
    Mar + BTC 1c Apr leaving 1c → FIFO closes Jan; opened_at = Mar.
    Pre-fix returns Mar. No divergence. The divergence appears when
    multiple BTCs close the *later* STOs first under FIFO of opens.

    Best clear divergence per the task spec: STO 1c Jan, STO 1c Mar,
    BTC 1c Apr (closes Jan under FIFO) → opened_at = Mar.

    Pre-fix this returns Mar too — because Mar IS the latest STO. The
    actual divergence in the audit is when the LATEST STO is fully
    closed and an OLDER STO remains. Use: STO 1c Jan, STO 1c Mar, BTC
    2c Apr — leaves 0 open. Use: STO 2c Jan, STO 1c Mar, BTC 2c Apr —
    FIFO closes 2c Jan first, leaving the Mar STO open (1c). opened_at
    must be Mar. Pre-fix returns Mar (latest STO date), agrees.

    True divergence: STO 1c Jan, STO 1c Mar, STO 1c May, BTC 1c Jun
    leaving 2c open. FIFO closes Jan → still-open are Mar+May. The
    *earliest* still-open is Mar. Pre-fix returns May (latest STO date).
    """
    from net_alpha.portfolio.positions import compute_open_short_option_positions

    opt = OptionDetails(strike=100.0, expiry=dt.date(2026, 12, 18), call_put="C")
    trades = [
        _trade(
            id="sto_jan",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=100.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 1, 15),
        ),
        _trade(
            id="sto_mar",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=110.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 3, 15),
        ),
        _trade(
            id="sto_may",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=120.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 5, 15),
        ),
        _trade(
            id="btc_jun",
            ticker="ACME",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=80.0,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2026, 6, 15),
        ),
    ]
    rows = compute_open_short_option_positions(trades)
    assert len(rows) == 1
    row = rows[0]
    assert row.qty_short == Decimal("2")
    # FIFO closes the Jan STO; earliest still-open STO is March.
    assert row.opened_at == dt.date(2026, 3, 15)


def test_open_short_option_opened_at_single_sto_no_close():
    """Single STO, no BTC — opened_at is the STO date."""
    from net_alpha.portfolio.positions import compute_open_short_option_positions

    opt = OptionDetails(strike=100.0, expiry=dt.date(2026, 12, 18), call_put="C")
    trades = [
        _trade(
            id="sto",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=100.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 1, 15),
        )
    ]
    rows = compute_open_short_option_positions(trades)
    assert len(rows) == 1
    assert rows[0].opened_at == dt.date(2026, 1, 15)


def test_open_short_option_opened_at_partial_fifo_consumption():
    """STO 2c then STO 1c, BTC 1c closes part of the first STO.

    FIFO: BTC consumes 1c of the 2c-Jan STO → 1c of Jan still open + 1c
    of Mar still open = 2c total. Earliest still-open STO leg is Jan.
    Pre-fix returned March (latest STO date).
    """
    from net_alpha.portfolio.positions import compute_open_short_option_positions

    opt = OptionDetails(strike=100.0, expiry=dt.date(2026, 12, 18), call_put="C")
    trades = [
        _trade(
            id="sto_jan",
            ticker="ACME",
            action="Sell",
            quantity=2.0,
            proceeds=200.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 1, 15),
        ),
        _trade(
            id="sto_mar",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=110.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 3, 15),
        ),
        _trade(
            id="btc_apr",
            ticker="ACME",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=70.0,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2026, 4, 15),
        ),
    ]
    rows = compute_open_short_option_positions(trades)
    assert len(rows) == 1
    row = rows[0]
    assert row.qty_short == Decimal("2")
    # Jan STO has 1c remaining after FIFO closure; earliest still-open = Jan.
    assert row.opened_at == dt.date(2026, 1, 15)


def test_open_short_option_chain_fully_closed_emits_no_row():
    """STO + BTC of equal qty → no still-open contracts → no row."""
    from net_alpha.portfolio.positions import compute_open_short_option_positions

    opt = OptionDetails(strike=100.0, expiry=dt.date(2026, 12, 18), call_put="C")
    trades = [
        _trade(
            id="sto",
            ticker="ACME",
            action="Sell",
            quantity=1.0,
            proceeds=100.0,
            cost_basis=None,
            basis_source="option_short_open",
            option_details=opt,
            date=dt.date(2026, 1, 15),
        ),
        _trade(
            id="btc",
            ticker="ACME",
            action="Buy",
            quantity=1.0,
            proceeds=None,
            cost_basis=50.0,
            basis_source="option_short_close",
            option_details=opt,
            date=dt.date(2026, 2, 15),
        ),
    ]
    rows = compute_open_short_option_positions(trades)
    assert rows == []
