from datetime import date
from decimal import Decimal

import pytest

from net_alpha.engine.lot_selector import (
    InsufficientLotsError,
    LotPick,  # noqa: F401 — re-export sanity check
    LotPickResult,
    select_lots,
)


def _lot(id: int, qty: float, basis: float, acquired: date):
    """Build a minimal Lot domain object for tests."""
    from net_alpha.models.domain import Lot

    return Lot(
        id=str(id),
        trade_id=f"t{id}",
        ticker="SPY",
        date=acquired,
        quantity=qty,
        cost_basis=basis,
        adjusted_basis=basis,
        account="default",
    )


def test_insufficient_lots_raises():
    lots = [_lot(1, 10, 1000, date(2024, 1, 1))]
    with pytest.raises(InsufficientLotsError):
        select_lots(
            lots=lots,
            qty=Decimal("100"),
            sell_price=Decimal("110"),
            sell_date=date(2026, 5, 5),
            strategy="FIFO",
            repo=None,
            etf_pairs={},
            brackets=None,
            carryforward=None,
        )


def test_lot_pick_result_has_required_fields():
    # 100-share lot with $50/share total basis ($5000 total), partial-fill 50 shares.
    # LotPick.adjusted_basis is per-share, so 5000 / 100 = $50/sh and the
    # 50-share partial fill realizes 50 * (100 - 50) = $2500.
    lots = [_lot(1, 100, 5000.0, date(2024, 1, 1))]
    result = select_lots(
        lots=lots,
        qty=Decimal("50"),
        sell_price=Decimal("100"),
        sell_date=date(2026, 5, 5),
        strategy="FIFO",
        repo=None,
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert isinstance(result, LotPickResult)
    assert result.strategy == "FIFO"
    assert len(result.picks) == 1
    assert result.picks[0].qty_consumed == Decimal("50")
    assert result.picks[0].adjusted_basis == Decimal("50")  # per-share
    assert result.pre_tax_pnl == Decimal("2500")  # 50 * (100 - 50)
    assert result.has_wash_sale_risk is False
    assert result.wash_sale_disallowed == Decimal("0")


def _make_lots():
    """3 same-size lots with distinct dates and basis-per-share."""
    return [
        _lot(1, 100, 8000.0, date(2023, 1, 15)),  # oldest, low basis ($80/sh)
        _lot(2, 100, 12000.0, date(2024, 6, 1)),  # mid, high basis ($120/sh)
        _lot(3, 100, 10000.0, date(2025, 3, 1)),  # newest, mid basis ($100/sh)
    ]


def _strategy_pick_ids(strategy: str) -> list[str]:
    lots = _make_lots()
    result = select_lots(
        lots=lots,
        qty=Decimal("150"),
        sell_price=Decimal("110"),
        sell_date=date(2026, 5, 5),
        strategy=strategy,
        repo=None,
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    return [p.lot_id for p in result.picks]


def test_fifo_consumes_oldest_first():
    assert _strategy_pick_ids("FIFO") == ["1", "2"]


def test_lifo_consumes_newest_first():
    assert _strategy_pick_ids("LIFO") == ["3", "2"]


def test_hifo_consumes_highest_basis_first():
    assert _strategy_pick_ids("HIFO") == ["2", "3"]


def test_hifo_sorts_on_basis_per_share_not_total_basis():
    """A small lot with high $/share should win over a large lot with low $/share,
    even though the large lot has higher TOTAL basis. This is the correctness fix
    from Task 11 review."""
    lots = [
        _lot(1, 1000, 50000.0, date(2024, 1, 1)),  # 1000 sh @ $50/sh, total $50K
        _lot(2, 10, 2000.0, date(2024, 1, 2)),  # 10 sh @ $200/sh, total $2K
    ]
    result = select_lots(
        lots=lots,
        qty=Decimal("10"),
        sell_price=Decimal("110"),
        sell_date=date(2026, 5, 5),
        strategy="HIFO",
        repo=None,
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    # HIFO should pick lot 2 first (higher per-share basis).
    assert [p.lot_id for p in result.picks] == ["2"]


def test_hifo_tiebreak_deterministic():
    """Two lots with identical basis-per-share → tiebreak by lot_id ascending."""
    lots = [
        _lot(2, 100, 10000.0, date(2024, 1, 1)),  # $100/sh
        _lot(1, 100, 10000.0, date(2025, 1, 1)),  # $100/sh — same per-share
    ]
    result = select_lots(
        lots=lots,
        qty=Decimal("100"),
        sell_price=Decimal("110"),
        sell_date=date(2026, 5, 5),
        strategy="HIFO",
        repo=None,
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    # Tiebreak by lot_id ascending: "1" wins.
    assert result.picks[0].lot_id == "1"


def test_fifo_tiebreak_by_lot_id_when_same_date():
    lots = [
        _lot(2, 50, 5000.0, date(2024, 1, 1)),
        _lot(1, 50, 5000.0, date(2024, 1, 1)),
    ]
    result = select_lots(
        lots=lots,
        qty=Decimal("50"),
        sell_price=Decimal("110"),
        sell_date=date(2026, 5, 5),
        strategy="FIFO",
        repo=None,
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.picks[0].lot_id == "1"


def test_wash_sale_flagged_when_existing_buy_within_30_days():
    """A loss lot with a recent buy in the ±30d window should be flagged.

    Per IRC §1091's partial-replacement rule (audit #7): with sell qty=100
    and replacement buy qty=10, only 10% of the loss is disallowed —
    not the full $5,000.
    """
    from datetime import date as D

    from net_alpha.models.domain import Trade

    lots = [_lot(1, 100, 15000.0, D(2024, 6, 1))]  # basis $15K total, $150/sh

    # Stub repo with a buy 10 days before the proposed sell.
    class _R:
        def trades_for_ticker_in_window(self, ticker, sell_date, days):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=10,
                    proceeds=None,
                    cost_basis=1100.0,
                )
            ]

    result = select_lots(
        lots=lots,
        qty=Decimal("100"),
        sell_price=Decimal("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.has_wash_sale_risk is True
    # Loss = (100 - 150) * 100 = -5000. Replacement qty 10 / sell qty 100 = 10%.
    # Disallowed = 5000 * 10/100 = 500.
    assert result.wash_sale_disallowed == Decimal("500")


def test_no_wash_sale_when_loss_lot_has_no_replacement_buy():
    from datetime import date as D

    lots = [_lot(1, 100, 15000.0, D(2024, 6, 1))]

    class _R:
        def trades_for_ticker_in_window(self, ticker, sell_date, days):
            return []

    result = select_lots(
        lots=lots,
        qty=Decimal("100"),
        sell_price=Decimal("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.has_wash_sale_risk is False
    assert result.wash_sale_disallowed == Decimal("0")


def test_no_wash_sale_when_lot_is_a_gain():
    """Gains can't trigger wash sales."""
    from datetime import date as D

    from net_alpha.models.domain import Trade

    lots = [_lot(1, 100, 5000.0, D(2024, 6, 1))]  # basis $50/sh, sell at $100 = gain

    class _R:
        def trades_for_ticker_in_window(self, ticker, sell_date, days):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=10,
                    proceeds=None,
                    cost_basis=1100.0,
                )
            ]

    result = select_lots(
        lots=lots,
        qty=Decimal("100"),
        sell_price=Decimal("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.has_wash_sale_risk is False


def test_after_tax_applies_brackets_and_carryforward():
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.carryforward import Carryforward
    from net_alpha.portfolio.tax_planner import TaxBrackets

    # Lot held > 365 days at $50/sh, sell at $100 → LT gain $5000.
    # 100 shares × $50/share basis = $5000 total. _lot expects total basis.
    lots = [_lot(1, 100, 5000.0, D(2023, 1, 1))]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )
    cf = Carryforward(st=Dc("0"), lt=Dc("2000"), source="user")

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=cf,
    )
    # Pre-tax LT gain: 100 * (100 - 50) = 5000
    # After $2000 LT carryforward: taxable LT = 3000
    # Tax: 3000 * 0.15 = 450
    # After-tax: 5000 - 450 = 4550
    assert result.pre_tax_pnl == Dc("5000")
    assert result.after_tax_pnl == Dc("4550")


def test_after_tax_disallowed_loss_treated_as_zero_benefit():
    """A wash-sale-disallowed loss provides $0 current-year tax benefit.

    Setup: replacement buy fully covers the sell qty (100 sh sell, 100 sh
    buy) so 100% of the $5K loss is disallowed under §1091 → $0 current-
    year benefit.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.models.domain import Trade
    from net_alpha.portfolio.tax_planner import TaxBrackets

    # 100 shares, $150/sh basis ($15K total), sell at $100 → -$5000 loss.
    lots = [_lot(1, 100, 15000.0, D(2024, 6, 1))]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=100,  # full replacement → 100% disallowed
                    proceeds=None,
                    cost_basis=11000.0,
                )
            ]

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    # Pre-tax: -5000. Full replacement → wash sale disallows the entire loss
    # → 0 current-year benefit.
    # After-tax: pre_tax - tax_bill (0) - loss_benefit (0) = -5000
    assert result.pre_tax_pnl == Dc("-5000")
    assert result.wash_sale_disallowed == Dc("5000")
    assert result.after_tax_pnl == Dc("-5000")


def test_partial_replacement_disallows_proportional_loss_only():
    """Audit #7 / IRC §1091 partial-replacement rule: when the replacement
    buy quantity is *less than* the sell quantity, only the proportional
    loss is disallowed — not the entire loss.

        disallowed = loss × min(replacement_qty, sell_qty) / sell_qty

    Sell 1,000 sh at $100 with $150/sh basis → -$50,000 loss. Replacement
    buy of 100 sh in the ±30d window → disallowed = 50,000 × 100/1000 =
    $5,000 (10%). Pre-fix the whole $50K was disallowed.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.models.domain import Trade

    # 1000 shares, $150/sh basis ($150K total), sell at $100 → -$50,000 loss.
    lots = [_lot(1, 1000, 150000.0, D(2024, 6, 1))]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=100,
                    proceeds=None,
                    cost_basis=11000.0,
                )
            ]

    result = select_lots(
        lots=lots,
        qty=Dc("1000"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.has_wash_sale_risk is True
    # -50,000 × min(100, 1000)/1000 = 5,000
    assert result.wash_sale_disallowed == Dc("5000")


def test_full_replacement_disallows_entire_loss():
    """Replacement buy ≥ sell quantity → 100% of the loss is disallowed."""
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.models.domain import Trade

    # 100 shares, $150/sh basis ($15K total), sell at $100 → -$5,000 loss.
    lots = [_lot(1, 100, 15000.0, D(2024, 6, 1))]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=150,  # 150% replacement → clamps at 100% of loss
                    proceeds=None,
                    cost_basis=15000.0,
                )
            ]

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    # min(150, 100)/100 = 1.0 → entire $5K loss disallowed.
    assert result.wash_sale_disallowed == Dc("5000")


def test_zero_replacement_qty_no_disallowance():
    """Edge case: no qualifying buy → no disallowance (control)."""
    from datetime import date as D
    from decimal import Decimal as Dc

    lots = [_lot(1, 100, 15000.0, D(2024, 6, 1))]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []  # zero qualifying buys

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.wash_sale_disallowed == Dc("0")
    assert result.has_wash_sale_risk is False


def test_replacement_qty_summed_across_window():
    """Multiple qualifying buys in the window are summed before being
    compared to the sell qty. Sell 1,000 sh, two buys of 200 sh each → 400
    sh replacement → 40% of loss disallowed.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.models.domain import Trade

    lots = [_lot(1, 1000, 150000.0, D(2024, 6, 1))]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return [
                Trade(
                    id="b1",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 25),
                    action="Buy",
                    quantity=200,
                    proceeds=None,
                    cost_basis=22000.0,
                ),
                Trade(
                    id="b2",
                    account="default",
                    ticker="SPY",
                    date=D(2026, 4, 28),
                    action="Buy",
                    quantity=200,
                    proceeds=None,
                    cost_basis=22000.0,
                ),
            ]

    result = select_lots(
        lots=lots,
        qty=Dc("1000"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    # -50,000 × min(400, 1000)/1000 = 20,000
    assert result.wash_sale_disallowed == Dc("20000")


def test_after_tax_applies_niit_when_enabled_to_match_tax_performance_tile():
    """Sim's Lot Strategy Comparison must agree with the Tax Performance
    tile (`compute_after_tax`). Pre-fix, sim's `_compute_after_tax` ignored
    NIIT entirely — flagged in audit #3 because the same input gave
    different tax bills on the two surfaces.

    Setup: pure LT gain $5,000, no carryforward, NIIT on.
        lt_tax  = 5000 * 0.15 = $750
        niit    = 5000 * 0.038 = $190
        bill    = $940
        after   = 5000 - 940 = $4060
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.tax_planner import TaxBrackets

    lots = [_lot(1, 100, 5000.0, D(2023, 1, 1))]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=True,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    assert result.pre_tax_pnl == Dc("5000")
    # 5000 - 750 (LT tax) - 190 (NIIT) = 4060
    assert result.after_tax_pnl == Dc("4060")


def test_after_tax_niit_disabled_matches_legacy_behavior():
    """With ``niit_enabled=False`` the after-tax math must be unchanged from
    pre-fix: no NIIT layer, just federal + state + LTCG + $3K cap.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.tax_planner import TaxBrackets

    lots = [_lot(1, 100, 5000.0, D(2023, 1, 1))]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="FIFO",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    # 5000 - 750 (LT tax only) = 4250
    assert result.after_tax_pnl == Dc("4250")


def test_after_tax_no_brackets_falls_back_to_pretax_with_note():
    from datetime import date as D
    from decimal import Decimal as Dc

    lots = [_lot(1, 100, 5000.0, D(2023, 1, 1))]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="MIN_TAX",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.after_tax_pnl == result.pre_tax_pnl
    assert any("brackets" in n.lower() for n in result.notes)


def test_min_tax_picks_combo_minimizing_tax_bill():
    """Two lots: one big LT loss, one small ST gain. Min Tax should prefer
    the LT loss to maximize the deduction."""
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.tax_planner import TaxBrackets

    # Lot 1: 50 shares × $200/sh basis = $10,000 total. Held > 365d → LT.
    #   At sell=$100: -$5000 LT loss
    # Lot 2: 50 shares × $80/sh basis = $4,000 total. Held < 365d → ST.
    #   At sell=$100: +$1000 ST gain
    lots = [
        _lot(1, 50, 10000.0, D(2023, 1, 1)),  # LT loss at sell
        _lot(2, 50, 4000.0, D(2025, 12, 1)),  # ST gain at sell
    ]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("50"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="MIN_TAX",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    # MIN_TAX picks lot 1 (the LT loss) → max tax benefit.
    assert [p.lot_id for p in result.picks] == ["1"]


def test_min_tax_brute_reaches_optimal_partial_fill_ordering():
    """Audit #8: ``_select_brute`` only tried one ordering of each combo
    (lex by lot.id), which makes the "which lot gets the partial fill"
    decision NON-optimal whenever per-share basis differs between lots in
    the combo.

    Counter-example: sell 150 sh @ $5 with three same-size lots holding
    100 sh each:
        Lot 1: 100 sh @ $10/sh basis ($1,000 total)
        Lot 2: 100 sh @ $20/sh basis ($2,000 total)
        Lot 3: 100 sh @ $30/sh basis ($3,000 total)

    Proceeds: 150 × $5 = $750.

    True MIN_TAX optimum: consume lot 3 fully (100 sh × $30 = $3,000
    basis) + lot 2 partially (50 sh × $20 = $1,000 basis) → realized P&L
    = $750 − $4,000 = -$3,250.

    Pre-fix the brute used lex ordering (lot 1 → lot 2 → lot 3) so the
    last lot in each combo took the partial role. For combo
    {lot2, lot3} that meant 100 sh from lot 2 (the full slot) + 50 sh
    from lot 3 (the partial slot) → $750 − ($2,000 + $1,500) = -$2,750.
    The optimal swap (lot 3 full + lot 2 partial) was unreachable.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.tax_planner import TaxBrackets

    lots = [
        _lot(1, 100, 1000.0, D(2023, 1, 1)),
        _lot(2, 100, 2000.0, D(2023, 1, 1)),
        _lot(3, 100, 3000.0, D(2023, 1, 1)),
    ]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("150"),
        sell_price=Dc("5"),
        sell_date=D(2026, 5, 5),
        strategy="MIN_TAX",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    # Optimum: lot 3 fully consumed + lot 2 partially (50 sh) → -$3,250 P&L.
    assert result.pre_tax_pnl == Dc("-3250")
    pick_summary = sorted((p.lot_id, p.qty_consumed) for p in result.picks)
    assert pick_summary == [("2", Dc("50")), ("3", Dc("100"))]


def test_max_loss_brute_reaches_optimal_partial_fill_ordering():
    """Asymmetric MAX_LOSS counterpart to the MIN_TAX test above. With the
    same three lots and a 150-share sell, MAX_LOSS minimizes pre-tax
    (most-negative) P&L; the optimal partial-fill placement again puts
    the partial slot on the *lower-basis* lot of the two consumed,
    leaving the highest-basis lot fully consumed.
    """
    from datetime import date as D
    from decimal import Decimal as Dc

    lots = [
        _lot(1, 100, 1000.0, D(2023, 1, 1)),
        _lot(2, 100, 2000.0, D(2023, 1, 1)),
        _lot(3, 100, 3000.0, D(2023, 1, 1)),
    ]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("150"),
        sell_price=Dc("5"),
        sell_date=D(2026, 5, 5),
        strategy="MAX_LOSS",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert result.pre_tax_pnl == Dc("-3250")
    pick_summary = sorted((p.lot_id, p.qty_consumed) for p in result.picks)
    assert pick_summary == [("2", Dc("50")), ("3", Dc("100"))]


def test_min_tax_greedy_fallback_for_many_lots():
    """With >12 lots, MIN_TAX uses greedy fallback and emits an 'approximate' note."""
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.portfolio.tax_planner import TaxBrackets

    # 15 lots of 10 shares each, basis varying $100-$115.
    lots = [_lot(i, 10, 1000.0 + i * 10, D(2023, 1, 1)) for i in range(1, 16)]
    brackets = TaxBrackets(
        filing_status="single",
        state="",
        federal_marginal_rate=Dc("0.35"),
        state_marginal_rate=Dc("0"),
        ltcg_rate=Dc("0.15"),
        qualified_div_rate=Dc("0.15"),
        niit_enabled=False,
    )

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("90"),
        sell_date=D(2026, 5, 5),
        strategy="MIN_TAX",
        repo=_R(),
        etf_pairs={},
        brackets=brackets,
        carryforward=None,
    )
    # 100 shares from 15 lots of 10 each → 10 lots picked.
    assert sum(p.qty_consumed for p in result.picks) == Dc("100")
    # Greedy fallback emits a note.
    assert any("greedy" in n.lower() or "approximate" in n.lower() for n in result.notes)


def test_max_loss_picks_most_negative_combo():
    from datetime import date as D
    from decimal import Decimal as Dc

    # Lot 1: 100 shares × $200/sh ($20K total). At sell=$100 → -$10K loss.
    # Lot 2: 100 shares × $50/sh ($5K total). At sell=$100 → +$5K gain.
    lots = [
        _lot(1, 100, 20000.0, D(2024, 1, 1)),
        _lot(2, 100, 5000.0, D(2024, 1, 1)),
    ]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="MAX_LOSS",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert [p.lot_id for p in result.picks] == ["1"]
    assert result.pre_tax_pnl == Dc("-10000")


def test_max_loss_prefers_no_wash_sale_on_tie():
    """Two combos tied on pre-tax loss; the picker should be deterministic.

    With both lots clean (no wash sales) and identical pre-tax P&L, the picker
    falls back to lot_id ascending tiebreak (deterministic ordering)."""
    from datetime import date as D
    from decimal import Decimal as Dc

    # Two identical-loss lots ($200/sh basis, sell at $100 → -$10K each on 100 shares).
    lots = [
        _lot(1, 100, 20000.0, D(2024, 1, 1)),
        _lot(2, 100, 20000.0, D(2024, 1, 2)),
    ]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("100"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="MAX_LOSS",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    # Pre-tax tied at -10000 → both have no wash sale → first-found wins, which
    # is lot 1 (smallest combo, sorted by lot_id ascending).
    assert [p.lot_id for p in result.picks] == ["1"]


def test_max_loss_picker_actually_avoids_wash_sale():
    """Two combos tied on pre-tax pnl — but only one triggers a wash sale.
    The picker should prefer the no-wash-sale combo per `_is_better` rule."""
    from datetime import date as D
    from decimal import Decimal as Dc

    from net_alpha.models.domain import Trade  # noqa: F401 — kept for parity with sibling tests

    # Two lots with identical loss magnitude. We engineer the stub repo to
    # flag ONE of them as wash-sale (via fake date arithmetic) — but in this
    # framework, the wash check uses ticker + sell_date, not lot_id. Both lots
    # would be flagged or both would not.
    #
    # Instead: use one loss lot + one gain lot of equal magnitude for total qty.
    # MAX_LOSS picks the LOSS lot (negative pre-tax wins). This is a partial
    # test of the wash-sale-tiebreak rule — full tiebreak coverage requires
    # an etf_pair construction that flags one combo and not another, which
    # is hard in a unit test.
    #
    # We just verify MAX_LOSS prefers losses over gains for the same qty.
    lots = [
        _lot(1, 50, 10000.0, D(2024, 1, 1)),  # 50 sh × $200/sh = $10K → -$5K loss
        _lot(2, 50, 2500.0, D(2024, 1, 1)),  # 50 sh × $50/sh = $2.5K → +$2.5K gain
    ]

    class _R:
        def trades_for_ticker_in_window(self, *a, **kw):
            return []

    result = select_lots(
        lots=lots,
        qty=Dc("50"),
        sell_price=Dc("100"),
        sell_date=D(2026, 5, 5),
        strategy="MAX_LOSS",
        repo=_R(),
        etf_pairs={},
        brackets=None,
        carryforward=None,
    )
    assert [p.lot_id for p in result.picks] == ["1"]
    assert result.pre_tax_pnl == Dc("-5000")
