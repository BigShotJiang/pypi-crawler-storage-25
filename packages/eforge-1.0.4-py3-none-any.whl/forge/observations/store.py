"""
Project-local observation graph store.

CONCURRENCY: This store is single-process only.
Concurrent writes from multiple forge processes to the
same .forge/observations/ directory are not safe.
Last write wins with no locking or conflict detection.
This is a known limitation. For team use, commit
.forge/observations/nodes/ to version control and
resolve conflicts via git.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

import yaml

from forge.observations.cache import SQLiteCache
from forge.observations.config import ObservationConfig
from forge.observations.errors import (
    ObservationError,
    dangling_link,
    emit_observation_warning,
    node_already_exists,
    node_delete_failed,
    node_not_found,
    node_write_failed,
    node_yaml_malformed,
    set_active_observations_dir,
    store_dir_missing,
    store_init_failed,
)
from forge.observations.models import DevLink, DevNode, _now_iso
from forge.schemas.registry import SchemaRegistry
from forge.schemas.store import SchemaStore

logger = logging.getLogger(__name__)

_BUILTIN_SCHEMAS = (
    Path(__file__).resolve().parent.parent / "_defaults" / "schemas" / "domain"
)


class ObservationStore:
    """Project-local observation graph; YAML nodes are source of truth."""

    def __init__(self, project_path: Path) -> None:
        self.project_path = Path(project_path).resolve()
        self.observations_dir = self.project_path / ".forge" / "observations"
        try:
            self._init_layout()
        except OSError as exc:
            raise store_init_failed(
                path=self.observations_dir,
                os_error=str(exc),
            ) from exc
        self.config = ObservationConfig.load(self.observations_dir)
        set_active_observations_dir(self.observations_dir)
        SchemaStore.init_project(self.project_path)
        cache_path = self.observations_dir / self.config.cache_file
        self._cache = SQLiteCache(cache_path)
        self._registry = SchemaRegistry.for_project(self.project_path)

    def _init_layout(self) -> None:
        self.observations_dir.mkdir(parents=True, exist_ok=True)
        nodes_dir = self.observations_dir / "nodes"
        schemas_dir = self.observations_dir / "schemas"
        cache_dir = self.observations_dir / ".cache"
        for d in (nodes_dir, schemas_dir, cache_dir):
            d.mkdir(parents=True, exist_ok=True)

        config_path = self.observations_dir / "config.yaml"
        if not config_path.exists():
            ObservationConfig().save(self.observations_dir)

        self._seed_builtin_schemas(schemas_dir)

    def _seed_builtin_schemas(self, target: Path) -> None:
        if not _BUILTIN_SCHEMAS.is_dir():
            return
        for src in _BUILTIN_SCHEMAS.rglob("*.yaml"):
            rel = src.relative_to(_BUILTIN_SCHEMAS)
            dest = target / rel
            if not dest.exists():
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)

    def _ensure_nodes_dir(self) -> Path:
        nodes = self.observations_dir / self.config.nodes_dir
        if not nodes.is_dir():
            raise store_dir_missing(path=self.observations_dir, dir_name=self.config.nodes_dir)
        return nodes

    @property
    def nodes_dir(self) -> Path:
        return self.observations_dir / self.config.nodes_dir

    def _node_path(self, node_id: str) -> Path:
        return self.nodes_dir / f"{node_id}.yaml"

    def save_node(self, node: DevNode, *, strict: bool = False) -> None:
        if strict:
            existing = self.find_by_name(node.name)
            if existing is not None and existing.id != node.id:
                raise node_already_exists(
                    name=node.name,
                    existing_id=existing.id,
                    new_id=node.id,
                )
        node.updated_at = _now_iso()
        path = self._node_path(node.id)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                yaml.dump(
                    node.to_dict(),
                    default_flow_style=False,
                    sort_keys=False,
                ),
                encoding="utf-8",
            )
        except OSError as exc:
            raise node_write_failed(
                node_id=node.id,
                file_path=path,
                os_error=str(exc),
            ) from exc
        self._cache.upsert_node(node)

    def save_nodes_batch(self, nodes: list[DevNode]) -> None:
        """
        Write multiple DevNodes and rebuild cache once.
        Much faster than repeated save_node calls.
        """
        if not nodes:
            return
        now = _now_iso()
        for node in nodes:
            node.updated_at = now
            path = self._node_path(node.id)
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(
                    yaml.dump(
                        node.to_dict(),
                        default_flow_style=False,
                        sort_keys=False,
                    ),
                    encoding="utf-8",
                )
            except OSError as exc:
                raise node_write_failed(
                    node_id=node.id,
                    file_path=path,
                    os_error=str(exc),
                ) from exc
        self.rebuild_cache()

    def load_node(self, node_id: str) -> DevNode:
        """Load node by id. Raises OBS-001 if missing, OBS-003 if yaml invalid."""
        path = self._node_path(node_id)
        if not path.is_file():
            raise node_not_found(
                node_id=node_id,
                store_path=self.nodes_dir,
            )
        try:
            raw = path.read_text(encoding="utf-8")
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            raise node_yaml_malformed(
                node_id=node_id,
                file_path=path,
                parse_error=str(exc),
            ) from exc
        except OSError as exc:
            raise node_yaml_malformed(
                node_id=node_id,
                file_path=path,
                parse_error=str(exc),
            ) from exc
        if not isinstance(data, dict):
            raise node_yaml_malformed(
                node_id=node_id,
                file_path=path,
                parse_error="root must be a mapping",
            )
        return DevNode.from_dict(data)

    def find_by_name(self, name: str) -> DevNode | None:
        self.ensure_cache_fresh()
        node_id = self._cache.find_by_name(name)
        if node_id:
            try:
                return self.load_node(node_id)
            except ObservationError:
                pass

        nodes_dir = self._ensure_nodes_dir()
        for path in nodes_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError:
                continue
            if isinstance(data, dict) and data.get("name") == name:
                logger.info(
                    "Cache miss for %r, rebuilt from disk",
                    name,
                )
                self.rebuild_cache()
                return DevNode.from_dict(data)
        return None

    def find_by_manifest_ref(self, manifest_ref: str) -> DevNode | None:
        """
        Find DevNode where manifest_ref == node_id.
        Returns None if not found. Never raises.
        """
        try:
            nodes = self.list_nodes()
            return next(
                (n for n in nodes if n.manifest_ref == manifest_ref),
                None,
            )
        except Exception:
            return None

    def delete_node(self, node_id: str) -> None:
        path = self._node_path(node_id)
        if path.is_file():
            try:
                path.unlink()
            except OSError as exc:
                raise node_delete_failed(
                    node_id=node_id,
                    file_path=path,
                    os_error=str(exc),
                ) from exc
        self._cache.delete_node(node_id)

    def list_nodes(
        self,
        domain: str | None = None,
        type: str | None = None,
        tags: list[str] | None = None,
        marked: bool | None = None,
        status: str | None = None,
    ) -> list[DevNode]:
        self.ensure_cache_fresh()
        clauses: list[str] = []
        params: list[object] = []
        if domain is not None:
            clauses.append("domain = ?")
            params.append(domain)
        if type is not None:
            clauses.append("type = ?")
            params.append(type)
        if marked is not None:
            clauses.append("marked = ?")
            params.append(1 if marked else 0)
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        sql = "SELECT * FROM dev_nodes"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        rows = self._cache.query(sql, tuple(params))
        nodes = [self._cache.node_from_row(r) for r in rows]
        if tags:
            tag_set = set(tags)
            nodes = [n for n in nodes if tag_set.intersection(n.tags)]
        return nodes

    def add_link(
        self, from_id: str, to: str, rel: str, note: str | None = None
    ) -> None:
        try:
            node = self.load_node(from_id)
        except ObservationError as exc:
            if exc.code.value == "OBS-001":
                raise node_not_found(node_id=from_id, store_path=self.nodes_dir) from exc
            raise
        if self.find_by_name(to) is None and self._resolve_link_target_id(to) is None:
            emit_observation_warning(
                dangling_link(to=to, from_id=from_id)
            )
        node.add_link(to=to, rel=rel, note=note)
        self.save_node(node)

    def _resolve_link_target_id(self, to: str) -> str | None:
        path = self.nodes_dir / f"{to}.yaml"
        if path.is_file():
            return to
        return None

    def get_links_from(self, node_id: str) -> list[DevLink]:
        try:
            node = self.load_node(node_id)
        except ObservationError:
            return []
        return list(node.links)

    def get_links_to(self, name: str) -> list[tuple[DevNode, DevLink]]:
        self.ensure_cache_fresh()
        rows = self._cache.get_links_to(name)
        result: list[tuple[DevNode, DevLink]] = []
        for row in rows:
            try:
                from_node = self.load_node(row["from_id"])
            except ObservationError:
                continue
            link = DevLink(to=row["to_id"], rel=row["rel"], note=row.get("note"))
            result.append((from_node, link))
        return result

    def _load_all_nodes(self) -> list[DevNode]:
        nodes: list[DevNode] = []
        nodes_dir = self._ensure_nodes_dir()
        for path in sorted(nodes_dir.glob("*.yaml")):
            node_id = path.stem
            nodes.append(self.load_node(node_id))
        return nodes

    def ensure_cache_fresh(self) -> None:
        if self._cache.is_stale(self.nodes_dir):
            self.rebuild_cache()

    def rebuild_cache(self) -> None:
        self._cache.rebuild(self._load_all_nodes())

    def search_nodes(
        self,
        query: str,
        *,
        domain: str | None = None,
        type: str | None = None,
        tag: str | None = None,
        source_file: str | None = None,
        marked: bool | None = None,
    ) -> list[tuple[DevNode, int]]:
        self.ensure_cache_fresh()
        rows = self._cache.search(
            query,
            domain=domain,
            type_=type,
            tags=tag,
            source_file=source_file,
            marked=marked,
        )
        result: list[tuple[DevNode, int]] = []
        for row in rows:
            score = int(row.pop("score", 0))
            result.append((self._cache.node_from_row(row), score))
        return result

    @property
    def registry(self) -> SchemaRegistry:
        return self._registry
