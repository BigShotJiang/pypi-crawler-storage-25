from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from typing import Any


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _filter_known(data: dict[str, Any], cls: type) -> dict[str, Any]:
    known = {f.name for f in fields(cls)}
    return {k: v for k, v in data.items() if k in known}


@dataclass
class DevLink:
    to: str
    rel: str
    note: str | None = None
    created_at: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DevLink:
        return cls(**_filter_known(data, cls))


@dataclass
class DevNote:
    body: str
    tags: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DevNote:
        return cls(**_filter_known(data, cls))


@dataclass
class DevNode:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    domain: str | None = None
    type: str | None = None
    status: str = "observed"
    source_file: str | None = None
    source_line: int | None = None
    properties: dict[str, Any] = field(default_factory=dict)
    notes: list[DevNote] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    links: list[DevLink] = field(default_factory=list)
    marked: bool = False
    manifest_ref: str | None = None
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["notes"] = [n.to_dict() for n in self.notes]
        data["links"] = [lnk.to_dict() for lnk in self.links]
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DevNode:
        filtered = _filter_known(data, cls)
        raw_notes = data.get("notes") or []
        raw_links = data.get("links") or []
        filtered["notes"] = [
            DevNote.from_dict(n) if isinstance(n, dict) else n for n in raw_notes
        ]
        filtered["links"] = [
            DevLink.from_dict(lnk) if isinstance(lnk, dict) else lnk for lnk in raw_links
        ]
        if not filtered.get("id"):
            filtered["id"] = str(uuid.uuid4())
        return cls(**filtered)

    def add_link(self, to: str, rel: str, note: str | None = None) -> None:
        self.links.append(DevLink(to=to, rel=rel, note=note))
        self.updated_at = _now_iso()

    def add_note(self, body: str, tags: list[str] | None = None) -> None:
        self.notes.append(DevNote(body=body, tags=list(tags or [])))
        self.updated_at = _now_iso()

    def set_property(self, key: str, value: Any) -> None:
        self.properties[key] = value
        self.updated_at = _now_iso()
