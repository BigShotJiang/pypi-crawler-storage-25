"""Backward-compatible shim — SchemaRegistry lives in forge.schemas.registry."""

from forge.schemas.registry import SchemaRegistry

__all__ = ["SchemaRegistry"]
