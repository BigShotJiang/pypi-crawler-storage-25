from __future__ import annotations

from typing import Any

from forge.errors import ErrorRegistry
from forge.observations.errors import ObservationError, ObservationErrorCode
from forge.schemas.models import PropertyDef, TypeSchema
from forge.schemas.registry import SchemaRegistry
from forge.ui.errors import UI_001, UI_002, UI_003, UI_004
from forge.ui.prompt import FieldDef, FieldOption, PromptEngine, PromptMode, PromptResult

_UI_TO_OBS: dict[str, ObservationErrorCode] = {
    UI_001: ObservationErrorCode.REQUIRED_FIELD_MISSING,
    UI_002: ObservationErrorCode.INVALID_ENUM_VALUE,
    UI_003: ObservationErrorCode.VALIDATION_FAILED,
    UI_004: ObservationErrorCode.PROMPT_ABORTED,
}


def _map_ui_to_obs(ui_code: str) -> str:
    return {
        UI_001: "OBS-030",
        UI_002: "OBS-031",
        UI_003: "OBS-032",
        UI_004: "OBS-033",
    }.get(ui_code, ui_code)


def observations_error_factory(
    code: str, message: str, context: dict[str, Any]
) -> ObservationError:
    obs_code_str = _map_ui_to_obs(code)
    obs_enum = _UI_TO_OBS.get(code) or ObservationErrorCode(obs_code_str)
    entry = ErrorRegistry.lookup(obs_code_str)
    hint = entry.hint if entry and entry.hint else ""
    return ObservationError(
        code=obs_enum,
        message=message,
        hint=hint,
        context=context,
    )


class SchemaPrompt:
    """Adapter: TypeSchema properties → FieldDef prompts via PromptEngine."""

    def __init__(
        self,
        registry: SchemaRegistry,
        mode: PromptMode = PromptMode.INTERACTIVE,
        prefilled: dict[str, Any] | None = None,
        input_fn=None,
    ) -> None:
        self._registry = registry
        self._mode = mode
        self._prefilled = dict(prefilled or {})
        self._input_fn = input_fn

    def _make_engine(self, prefilled: dict[str, Any]) -> PromptEngine:
        return PromptEngine(
            mode=self._mode,
            prefilled=prefilled,
            input_fn=self._input_fn,
            error_factory=observations_error_factory,
        )

    def collect(
        self,
        schema: TypeSchema | None,
        prefilled: dict[str, Any] | None = None,
    ) -> PromptResult:
        merged_prefilled = {**self._prefilled, **(prefilled or {})}
        if schema is None:
            return PromptResult(values=merged_prefilled)
        fields = self._schema_to_fields(schema)
        result = self._make_engine(merged_prefilled).run(fields)
        self._raise_on_errors(result)
        return result

    def _raise_on_errors(self, result: PromptResult) -> None:
        if not result.errors:
            return
        for err in result.errors:
            if isinstance(err, ObservationError) and err.code in (
                ObservationErrorCode.REQUIRED_FIELD_MISSING,
                ObservationErrorCode.INVALID_ENUM_VALUE,
                ObservationErrorCode.VALIDATION_FAILED,
                ObservationErrorCode.PROMPT_ABORTED,
            ):
                raise err
        raise result.errors[0]

    def _schema_to_fields(self, schema: TypeSchema) -> list[FieldDef]:
        merged = schema.merged_properties(self._registry)
        ordered_keys: list[str] = []
        for key in schema.prompts_order:
            if key in merged:
                ordered_keys.append(key)
        for key in merged:
            if key not in ordered_keys:
                ordered_keys.append(key)
        return [self._property_to_field(k, merged[k]) for k in ordered_keys]

    def _property_to_field(self, key: str, prop: PropertyDef) -> FieldDef:
        field_type = prop.type
        multi = field_type == "multi_enum"
        if multi:
            field_type = "multi_enum"

        options: list[FieldOption] = []
        for opt in prop.options:
            exposed_fields = [
                self._property_to_field(nk, nv)
                for nk, nv in opt.exposes.items()
            ]
            options.append(
                FieldOption(
                    value=opt.value,
                    label=opt.label,
                    exposes=exposed_fields,
                )
            )

        return FieldDef(
            key=key,
            type=field_type,
            prompt=prop.prompt or key,
            options=options,
            required=prop.required,
            default=prop.default,
            multi=multi,
        )

    def collect_domain_and_type(self) -> tuple[str, str]:
        domains = self._registry.list_domains()
        domain_field = FieldDef(
            key="domain",
            type="enum",
            prompt="Observation domain",
            options=[FieldOption(value=d) for d in domains],
            required=True,
        )
        engine = self._make_engine(self._prefilled)
        domain_result = engine.run([domain_field])
        self._raise_on_errors(domain_result)
        domain = str(domain_result.values["domain"])

        types = self._registry.list_types(domain)
        type_field = FieldDef(
            key="type",
            type="enum",
            prompt="Observation type",
            options=[FieldOption(value=t) for t in types],
            required=True,
        )
        type_result = engine.run([type_field])
        self._raise_on_errors(type_result)
        return domain, str(type_result.values["type"])
