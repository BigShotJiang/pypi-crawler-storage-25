"""Project path resolution for devtools CLI (no forge.core dependency).

Not duplicated in store.py or config.py: those modules assume an already-
resolved observations_dir. CLI commands need cwd/parent walk to find
.forge/observations or manifest before opening the store.
"""

from __future__ import annotations

import os
from pathlib import Path


def resolve_project_path(explicit: str | None = None) -> Path | None:
    """Resolve project root for observation CLI commands."""
    if explicit:
        return Path(explicit).expanduser().resolve()

    cwd = Path(os.getcwd()).resolve()
    check = cwd
    for _ in range(6):
        if (check / ".forge" / "observations").is_dir():
            return check
        if (check / ".forge" / "manifest.yaml").is_file():
            return check
        if check.parent == check:
            break
        check = check.parent
    return None
