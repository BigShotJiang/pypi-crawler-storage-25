"""Append-only error event log for observation projects."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _subsystem_from_code(code: str) -> str:
    prefix = code.split("-")[0].lower()
    return {
        "obs": "observations",
        "ui": "ui",
    }.get(prefix, "forge")


def _error_code_str(error: Any) -> str:
    code = getattr(error, "code", "")
    if hasattr(code, "value"):
        return str(code.value)
    return str(code)


def _error_message(error: Any) -> str:
    message = getattr(error, "message", None)
    if message is not None:
        return str(message)
    return str(error)


@dataclass
class ErrorEvent:
    code: str
    message: str
    context: dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""
    subsystem: str = "forge"
    hint: str | None = None
    resolved: bool = False
    node_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ErrorEvent:
        known = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


class EventLog:
    """Append-only JSONL log at .forge/observations/.cache/events.jsonl."""

    def __init__(self, observations_dir: Path) -> None:
        self.observations_dir = Path(observations_dir)
        self.log_path = self.observations_dir / ".cache" / "events.jsonl"

    @classmethod
    def capture(cls, observations_dir: Path, error: Any) -> None:
        try:
            obs_dir = Path(observations_dir)
            if not obs_dir.is_dir():
                return
            code = _error_code_str(error)
            entry = ErrorEvent(
                code=code,
                message=_error_message(error),
                context=dict(getattr(error, "context", {}) or {}),
                timestamp=datetime.now(timezone.utc).isoformat(),
                subsystem=_subsystem_from_code(code),
                hint=getattr(error, "hint", None) or None,
            )
            log_path = obs_dir / ".cache" / "events.jsonl"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(entry.to_dict()) + "\n")
        except Exception:
            pass

    def read_all(self) -> list[ErrorEvent]:
        if not self.log_path.is_file():
            return []
        events: list[ErrorEvent] = []
        for line in self.log_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if isinstance(data, dict):
                    events.append(ErrorEvent.from_dict(data))
            except json.JSONDecodeError:
                continue
        return events

    def read_recent(self, n: int = 20) -> list[ErrorEvent]:
        events = self.read_all()
        if n <= 0:
            return []
        return events[-n:]

    def read_by_code(self, code: str) -> list[ErrorEvent]:
        return [event for event in self.read_all() if event.code == code]

    def stats(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for event in self.read_all():
            counts[event.code] = counts.get(event.code, 0) + 1
        return counts
