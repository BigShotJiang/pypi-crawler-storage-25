"""Backward-compatible shim — schema models live in forge.schemas.models."""

from forge.schemas.models import (
    ConstraintDef,
    EnumOption,
    PropertyDef,
    TypeSchema,
    WhenClause,
)

__all__ = [
    "ConstraintDef",
    "EnumOption",
    "PropertyDef",
    "TypeSchema",
    "WhenClause",
]
