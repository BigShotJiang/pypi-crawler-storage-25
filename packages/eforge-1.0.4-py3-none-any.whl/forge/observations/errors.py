"""
Typed errors for forge.observations and related prompt flows.

Mirrors forge.core.errors.ForgeError structure (code, layer, message, hint, context).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from forge.errors import ErrorEntry, ErrorRegistry

logger = logging.getLogger(__name__)

_active_observations_dir: Path | None = None


def set_active_observations_dir(path: Path) -> None:
    global _active_observations_dir
    _active_observations_dir = path


class ObservationErrorCode(str, Enum):
    NODE_NOT_FOUND = "OBS-001"
    NODE_ALREADY_EXISTS = "OBS-002"
    NODE_YAML_MALFORMED = "OBS-003"
    NODE_WRITE_FAILED = "OBS-004"
    NODE_DELETE_FAILED = "OBS-005"
    DANGLING_LINK = "OBS-006"

    SCHEMA_NOT_FOUND = "OBS-010"
    SCHEMA_MALFORMED = "OBS-011"
    SCHEMA_INHERITANCE_CYCLE = "OBS-012"
    SCHEMA_EMPTY_ENUM = "OBS-013"
    SCHEMA_OVERRIDE_REQUIRED = "OBS-014"

    STORE_INIT_FAILED = "OBS-020"
    CACHE_REBUILD_FAILED = "OBS-021"
    CACHE_QUERY_FAILED = "OBS-022"
    STORE_DIR_MISSING = "OBS-023"

    REQUIRED_FIELD_MISSING = "OBS-030"
    INVALID_ENUM_VALUE = "OBS-031"
    VALIDATION_FAILED = "OBS-032"
    PROMPT_ABORTED = "OBS-033"

    CONFIG_MALFORMED = "OBS-040"
    CONFIG_UNKNOWN_KEYS = "OBS-041"


@dataclass
class ObservationError(Exception):
    """Structured observation-layer error (same fields as ForgeError)."""

    code: ObservationErrorCode
    message: str
    hint: str = ""
    layer: str = "execution"
    recoverable: bool = True
    context: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if _active_observations_dir is not None:
            from forge.observations.event_log import EventLog

            EventLog.capture(_active_observations_dir, self)

    def __str__(self) -> str:
        return f"{self.code.value}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code.value,
            "layer": self.layer,
            "message": self.message,
            "hint": self.hint,
            "recoverable": self.recoverable,
            "context": self.context,
        }

    def model_dump_json(self, indent: int | None = None) -> str:
        return json.dumps(self.to_dict(), indent=indent)


def emit_observation_warning(err: ObservationError) -> None:
    """Log a non-fatal observation warning (OBS-006, OBS-041, etc.)."""
    logger.warning("%s: %s", err.code.value, err.message)
    if err.hint:
        logger.warning("  hint: %s", err.hint)


def node_not_found(
    *,
    node_id: str | None = None,
    name: str | None = None,
    store_path: str | Path | None = None,
) -> ObservationError:
    label = name or node_id or "unknown"
    return ObservationError(
        code=ObservationErrorCode.NODE_NOT_FOUND,
        message=f"Node {label!r} not found in store",
        hint=(
            "Run 'eforge node list' to see available nodes, "
            "or 'eforge node add' to create it"
        ),
        context={
            "node_id": node_id,
            "name": name,
            "store_path": str(store_path) if store_path else None,
        },
    )


def node_already_exists(
    *,
    name: str,
    existing_id: str,
    new_id: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.NODE_ALREADY_EXISTS,
        message=f"Node name {name!r} already exists (id={existing_id})",
        hint=(
            "Use store.update_node() to modify the existing node, "
            "or pass strict=False to overwrite"
        ),
        context={"name": name, "existing_id": existing_id, "new_id": new_id},
    )


def node_yaml_malformed(
    *,
    node_id: str,
    file_path: str | Path,
    parse_error: str,
) -> ObservationError:
    path = str(file_path)
    return ObservationError(
        code=ObservationErrorCode.NODE_YAML_MALFORMED,
        message=f"Node yaml malformed for {node_id!r}",
        hint=f"Node yaml may be corrupted. Raw file at {path}",
        context={
            "node_id": node_id,
            "file_path": path,
            "parse_error": parse_error,
        },
    )


def node_write_failed(
    *,
    node_id: str,
    file_path: str | Path,
    os_error: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.NODE_WRITE_FAILED,
        message=f"Failed to write node {node_id!r} to disk",
        hint="Check directory permissions for .forge/observations/nodes/",
        recoverable=False,
        context={
            "node_id": node_id,
            "file_path": str(file_path),
            "os_error": os_error,
        },
    )


def node_delete_failed(
    *,
    node_id: str,
    file_path: str | Path,
    os_error: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.NODE_DELETE_FAILED,
        message=f"Failed to delete node {node_id!r}",
        hint="Check file permissions and whether the node file exists",
        context={
            "node_id": node_id,
            "file_path": str(file_path),
            "os_error": os_error,
        },
    )


def dangling_link(*, to: str, from_id: str) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.DANGLING_LINK,
        message=f"Link target {to!r} not registered",
        hint="Link saved; add target node later to resolve",
        recoverable=True,
        context={"to": to, "from_id": from_id},
    )


def schema_malformed(
    *,
    file_path: str | Path,
    parse_error: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.SCHEMA_MALFORMED,
        message=f"Schema yaml malformed at {file_path}",
        hint="Check yaml syntax in schema file",
        context={"file_path": str(file_path), "parse_error": parse_error},
    )


def schema_inheritance_cycle(
    *,
    cycle: list[str],
    type_name: str,
) -> ObservationError:
    chain = " → ".join(cycle)
    return ObservationError(
        code=ObservationErrorCode.SCHEMA_INHERITANCE_CYCLE,
        message=f"Schema inheritance cycle detected: {chain}",
        hint="Remove or fix inherits references in schema yaml files",
        context={"cycle": cycle, "type_name": type_name},
    )


def schema_empty_enum(
    *,
    type_name: str,
    property_key: str,
    domain: str | None = None,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.SCHEMA_EMPTY_ENUM,
        message=f"Enum property {property_key!r} has no options in {type_name!r}",
        hint="Add at least one option to the enum PropertyDef",
        context={
            "type_name": type_name,
            "property_key": property_key,
            "domain": domain,
        },
    )


def schema_override_required(
    *,
    type_name: str,
    property_key: str,
    parent_type: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.SCHEMA_OVERRIDE_REQUIRED,
        message=(
            f"Property {property_key!r} on {type_name!r} redefines parent "
            f"{parent_type!r} without override: true"
        ),
        hint="Set override: true on the child property to replace the parent definition",
        context={
            "type_name": type_name,
            "property_key": property_key,
            "parent_type": parent_type,
        },
    )


def store_init_failed(*, path: str | Path, os_error: str) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.STORE_INIT_FAILED,
        message=f"Cannot create observation store at {path}",
        hint="Check directory permissions for .forge/observations/",
        recoverable=False,
        context={"path": str(path), "os_error": os_error},
    )


def cache_rebuild_failed(
    *, db_path: str | Path, sqlite_error: str
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.CACHE_REBUILD_FAILED,
        message="SQLite cache rebuild failed",
        hint="Cache may be corrupt. Run 'eforge node cache rebuild'",
        context={"db_path": str(db_path), "sqlite_error": sqlite_error},
    )


def cache_query_failed(
    *,
    sql: str,
    params: tuple,
    db_path: str | Path,
    sqlite_error: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.CACHE_QUERY_FAILED,
        message="SQLite cache query failed",
        hint="Cache may be corrupt. Run 'eforge node cache rebuild'",
        context={
            "sql": sql,
            "params": params,
            "db_path": str(db_path),
            "sqlite_error": sqlite_error,
        },
    )


def store_dir_missing(*, path: str | Path, dir_name: str) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.STORE_DIR_MISSING,
        message=f"Expected store directory missing: {dir_name}",
        hint="Re-initialize the observation store or restore from version control",
        context={"path": str(path), "dir_name": dir_name},
    )


def required_field_missing(*, field_key: str, mode: str) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.REQUIRED_FIELD_MISSING,
        message=f"Required field {field_key!r} not provided in {mode} mode",
        hint="Provide the field via prefilled values or switch to interactive mode",
        context={"field_key": field_key, "mode": mode},
    )


def invalid_enum_value(
    *,
    field_key: str,
    value: Any,
    allowed: list[str],
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.INVALID_ENUM_VALUE,
        message=f"Value {value!r} not in options for {field_key!r}",
        hint=f"Allowed values: {', '.join(allowed)}",
        context={"field_key": field_key, "value": value, "allowed": allowed},
    )


def validation_failed(*, field_key: str, detail: str) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.VALIDATION_FAILED,
        message=f"Validation failed for {field_key!r}: {detail}",
        hint="Correct the value and try again",
        context={"field_key": field_key, "detail": detail},
    )


def prompt_aborted() -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.PROMPT_ABORTED,
        message="Prompt aborted by user",
        hint="Re-run the command to continue",
        recoverable=True,
        context={},
    )


def config_malformed(
    *,
    file_path: str | Path,
    parse_error: str,
) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.CONFIG_MALFORMED,
        message=f"config.yaml malformed at {file_path}",
        hint="Check yaml syntax in .forge/observations/config.yaml",
        context={"file_path": str(file_path), "parse_error": parse_error},
    )


def config_unknown_keys(*, keys: list[str]) -> ObservationError:
    return ObservationError(
        code=ObservationErrorCode.CONFIG_UNKNOWN_KEYS,
        message=f"Unknown config keys preserved: {', '.join(keys)}",
        hint="Keys are kept for forward compatibility across forge versions",
        recoverable=True,
        context={"unknown_keys": keys},
    )


def _obs(
    code: str,
    name: str,
    description: str,
    hint: str,
    context_fields: list[str],
) -> ErrorEntry:
    return ErrorEntry(
        code=code,
        name=name,
        description=description,
        hint=hint,
        subsystem="observations",
        context_fields=context_fields,
    )


# OBS-001..OBS-041 — full catalog (node 001-009, schema 010-019, store 020-029,
# prompt 030-039, config 040-041). Each code registered below.
_OBS_CATALOG: list[ErrorEntry] = [
    _obs(
        "OBS-001",
        "NodeNotFound",
        "Node id or name not found in observation store",
        "Run 'eforge node list' to see ids; add with 'eforge node add'; "
        "files live in .forge/observations/nodes/{id}.yaml",
        ["node_id", "name", "store_path"],
    ),
    _obs(
        "OBS-002",
        "NodeAlreadyExists",
        "Node name collision on strict save",
        "Use a different name or save with strict=False to overwrite the existing yaml",
        ["name", "existing_id", "new_id"],
    ),
    _obs(
        "OBS-003",
        "NodeYamlMalformed",
        "Node yaml parse failure on load",
        "Fix yaml syntax in the node file under .forge/observations/nodes/",
        ["node_id", "file_path", "parse_error"],
    ),
    _obs(
        "OBS-004",
        "NodeWriteFailed",
        "Disk write failure saving node yaml",
        "Check disk space and write permissions on .forge/observations/nodes/",
        ["node_id", "file_path", "os_error"],
    ),
    _obs(
        "OBS-005",
        "NodeDeleteFailed",
        "Disk delete failure removing node yaml",
        "Check permissions on .forge/observations/nodes/{id}.yaml",
        ["node_id", "file_path", "os_error"],
    ),
    _obs(
        "OBS-006",
        "DanglingLink",
        "Link target name not registered (warning)",
        "Create the target with 'eforge node add' under .forge/observations/nodes/",
        ["to", "from_id"],
    ),
    _obs(
        "OBS-007",
        "NodeIdMalformed",
        "Node id format is invalid for the store",
        "Use a valid uuid or existing id from 'eforge node list'",
        ["node_id", "store_path"],
    ),
    _obs(
        "OBS-008",
        "BookmarkUnresolved",
        "@bookmark name did not resolve to a node",
        "Run 'eforge node list' and use an existing name after @",
        ["bookmark", "store_path"],
    ),
    _obs(
        "OBS-009",
        "NodeKindInvalid",
        "Node kind is not registered in the schema registry",
        "Pick a kind from .forge/observations/schemas/ or project schemas",
        ["kind", "domain", "type_name"],
    ),
    _obs(
        "OBS-010",
        "SchemaNotFound",
        "Schema file missing (returns None, not raised)",
        "Add {type_name}.yaml under .forge/observations/schemas/{domain}/",
        ["domain", "type_name"],
    ),
    _obs(
        "OBS-011",
        "SchemaMalformed",
        "Schema yaml parse failure",
        "Repair yaml at the file_path in context under .forge/observations/schemas/",
        ["file_path", "parse_error"],
    ),
    _obs(
        "OBS-012",
        "SchemaInheritanceCycle",
        "Schema inherits chain forms a cycle",
        "Break the inherits: cycle in the schema yaml files",
        ["cycle", "type_name"],
    ),
    _obs(
        "OBS-013",
        "SchemaEmptyEnum",
        "Enum PropertyDef has no options",
        "Add options: to the enum property in the schema yaml",
        ["type_name", "property_key", "domain"],
    ),
    _obs(
        "OBS-014",
        "SchemaOverrideRequired",
        "Child property redefines parent without override: true",
        "Set override: true on the child property in schema yaml",
        ["type_name", "property_key", "parent_type"],
    ),
    _obs(
        "OBS-015",
        "SchemaDuplicateType",
        "Two schema files define the same type name in one domain",
        "Remove or rename the duplicate under .forge/observations/schemas/",
        ["domain", "type_name", "file_path"],
    ),
    _obs(
        "OBS-016",
        "SchemaPropertyUnknown",
        "Property key is not defined on the resolved schema",
        "Add the property to the type schema yaml or fix the node field name",
        ["type_name", "property_key", "domain"],
    ),
    _obs(
        "OBS-017",
        "SchemaRequiredPropertyMissing",
        "Required schema property missing on node or prompt",
        "Fill the required property per schema in the node yaml or CLI flags",
        ["type_name", "property_key", "domain"],
    ),
    _obs(
        "OBS-018",
        "SchemaDomainUnknown",
        "Schema domain directory not found",
        "Create .forge/observations/schemas/{domain}/ or fix the domain path",
        ["domain", "store_path"],
    ),
    _obs(
        "OBS-019",
        "SchemaBuiltinSeedFailed",
        "Failed to copy built-in schema defaults into the project",
        "Check permissions on .forge/observations/schemas/ and disk space",
        ["file_path", "os_error"],
    ),
    _obs(
        "OBS-020",
        "StoreInitFailed",
        "Cannot create .forge/observations/ layout",
        "Ensure the project can create .forge/observations/ (permissions, path)",
        ["path", "os_error"],
    ),
    _obs(
        "OBS-021",
        "CacheRebuildFailed",
        "SQLite error during cache rebuild",
        "Delete .forge/observations/.cache/graph.db and run a store operation to rebuild",
        ["db_path", "sqlite_error"],
    ),
    _obs(
        "OBS-022",
        "CacheQueryFailed",
        "SQLite error during cache query",
        "Rebuild cache by touching nodes or deleting .forge/observations/.cache/graph.db",
        ["sql", "params", "db_path", "sqlite_error"],
    ),
    _obs(
        "OBS-023",
        "StoreDirMissing",
        "Expected nodes/ or schemas/ directory missing",
        "Restore nodes/ and schemas/ under .forge/observations/ from git",
        ["path", "dir_name"],
    ),
    _obs(
        "OBS-024",
        "CacheStale",
        "SQLite cache is out of date with node yaml (warning)",
        "Run any store read/write to trigger ensure_cache_fresh() rebuild",
        ["yaml_mtime", "db_mtime", "node_count"],
    ),
    _obs(
        "OBS-025",
        "CacheNotInitialized",
        "Cache database missing before first query",
        "Open the store once to create .forge/observations/.cache/graph.db",
        ["db_path"],
    ),
    _obs(
        "OBS-026",
        "CacheNodeUpsertFailed",
        "Failed to upsert a node row into SQLite cache",
        "Check .forge/observations/.cache/graph.db permissions and disk space",
        ["node_id", "db_path", "sqlite_error"],
    ),
    _obs(
        "OBS-027",
        "LinkWriteFailed",
        "Failed to persist a dev link on the node yaml",
        "Edit links in .forge/observations/nodes/{id}.yaml or use 'eforge node link'",
        ["from_id", "to", "file_path", "os_error"],
    ),
    _obs(
        "OBS-028",
        "NoteAppendFailed",
        "Failed to append a note on the node yaml",
        "Use 'eforge node note' or edit notes in .forge/observations/nodes/{id}.yaml",
        ["node_id", "file_path", "os_error"],
    ),
    _obs(
        "OBS-029",
        "NodeSearchFailed",
        "Full-text or filter search against cache failed",
        "Rebuild cache; verify .forge/observations/.cache/graph.db is readable",
        ["query", "db_path", "sqlite_error"],
    ),
    _obs(
        "OBS-030",
        "RequiredFieldMissing",
        "Required prompt field missing in batch/silent mode",
        "Pass the field via CLI flags, prefilled dict, or drop -y/--yes for interactive",
        ["field_key", "mode"],
    ),
    _obs(
        "OBS-031",
        "InvalidEnumValue",
        "Prefilled or silent enum value not in options",
        "Use a value from the schema options list in .forge/observations/schemas/",
        ["field_key", "value", "allowed"],
    ),
    _obs(
        "OBS-032",
        "ValidationFailed",
        "Field custom validation failed",
        "Correct the value to satisfy the schema property validate rule",
        ["field_key", "detail"],
    ),
    _obs(
        "OBS-033",
        "PromptAborted",
        "Interactive prompt cancelled",
        "Re-run the command without Ctrl+C to finish prompts",
        [],
    ),
    _obs(
        "OBS-034",
        "PromptFieldUnknown",
        "Prompt field key not defined in the schema adapter",
        "Align field keys with properties in the type schema yaml",
        ["field_key", "type_name"],
    ),
    _obs(
        "OBS-035",
        "PromptPrefillInvalid",
        "Prefilled value type does not match the field definition",
        "Fix the prefilled dict passed to SchemaPrompt.collect()",
        ["field_key", "value", "expected_type"],
    ),
    _obs(
        "OBS-036",
        "PromptNonInteractiveRequired",
        "Interactive input required but stdin is not a TTY",
        "Remove -y/--yes or run in a terminal for interactive prompts",
        ["field_key", "mode"],
    ),
    _obs(
        "OBS-037",
        "PromptOptionNotFound",
        "Selected option id not in the field options list",
        "Pick a valid option id from the schema enum options",
        ["field_key", "option_id", "allowed"],
    ),
    _obs(
        "OBS-038",
        "PromptBatchIncomplete",
        "Batch mode ended with one or more unresolved fields",
        "Supply all required fields via flags or prefilled before using -y",
        ["field_keys", "mode"],
    ),
    _obs(
        "OBS-039",
        "PromptSilentConflict",
        "Silent mode cannot resolve a required or invalid field",
        "Provide defaults in schema or switch to interactive mode",
        ["field_key", "mode"],
    ),
    _obs(
        "OBS-040",
        "ConfigMalformed",
        "config.yaml parse failure",
        "Fix yaml syntax in .forge/observations/config.yaml",
        ["file_path", "parse_error"],
    ),
    _obs(
        "OBS-041",
        "ConfigUnknownKeys",
        "Unknown config keys preserved (warning)",
        "Remove unused keys or document them; stored in config unknown_keys",
        ["unknown_keys"],
    ),
]

assert len(_OBS_CATALOG) == 41, f"expected 41 OBS codes, got {len(_OBS_CATALOG)}"

ErrorRegistry.register(_OBS_CATALOG[0])   # OBS-001
ErrorRegistry.register(_OBS_CATALOG[1])   # OBS-002
ErrorRegistry.register(_OBS_CATALOG[2])   # OBS-003
ErrorRegistry.register(_OBS_CATALOG[3])   # OBS-004
ErrorRegistry.register(_OBS_CATALOG[4])   # OBS-005
ErrorRegistry.register(_OBS_CATALOG[5])   # OBS-006
ErrorRegistry.register(_OBS_CATALOG[6])   # OBS-007
ErrorRegistry.register(_OBS_CATALOG[7])   # OBS-008
ErrorRegistry.register(_OBS_CATALOG[8])   # OBS-009
ErrorRegistry.register(_OBS_CATALOG[9])   # OBS-010
ErrorRegistry.register(_OBS_CATALOG[10])  # OBS-011
ErrorRegistry.register(_OBS_CATALOG[11])  # OBS-012
ErrorRegistry.register(_OBS_CATALOG[12])  # OBS-013
ErrorRegistry.register(_OBS_CATALOG[13])  # OBS-014
ErrorRegistry.register(_OBS_CATALOG[14])  # OBS-015
ErrorRegistry.register(_OBS_CATALOG[15])  # OBS-016
ErrorRegistry.register(_OBS_CATALOG[16])  # OBS-017
ErrorRegistry.register(_OBS_CATALOG[17])  # OBS-018
ErrorRegistry.register(_OBS_CATALOG[18])  # OBS-019
ErrorRegistry.register(_OBS_CATALOG[19])  # OBS-020
ErrorRegistry.register(_OBS_CATALOG[20])  # OBS-021
ErrorRegistry.register(_OBS_CATALOG[21])  # OBS-022
ErrorRegistry.register(_OBS_CATALOG[22])  # OBS-023
ErrorRegistry.register(_OBS_CATALOG[23])  # OBS-024
ErrorRegistry.register(_OBS_CATALOG[24])  # OBS-025
ErrorRegistry.register(_OBS_CATALOG[25])  # OBS-026
ErrorRegistry.register(_OBS_CATALOG[26])  # OBS-027
ErrorRegistry.register(_OBS_CATALOG[27])  # OBS-028
ErrorRegistry.register(_OBS_CATALOG[28])  # OBS-029
ErrorRegistry.register(_OBS_CATALOG[29])  # OBS-030
ErrorRegistry.register(_OBS_CATALOG[30])  # OBS-031
ErrorRegistry.register(_OBS_CATALOG[31])  # OBS-032
ErrorRegistry.register(_OBS_CATALOG[32])  # OBS-033
ErrorRegistry.register(_OBS_CATALOG[33])  # OBS-034
ErrorRegistry.register(_OBS_CATALOG[34])  # OBS-035
ErrorRegistry.register(_OBS_CATALOG[35])  # OBS-036
ErrorRegistry.register(_OBS_CATALOG[36])  # OBS-037
ErrorRegistry.register(_OBS_CATALOG[37])  # OBS-038
ErrorRegistry.register(_OBS_CATALOG[38])  # OBS-039
ErrorRegistry.register(_OBS_CATALOG[39])  # OBS-040
ErrorRegistry.register(_OBS_CATALOG[40])  # OBS-041
