from forge.observations import errors as _obs_errors  # noqa: F401
from forge.observations.config import ObservationConfig
from forge.observations.errors import ObservationError, ObservationErrorCode
from forge.observations.models import DevLink, DevNode, DevNote

__all__ = [
    "DevLink",
    "DevNode",
    "DevNote",
    "ObservationConfig",
    "ObservationError",
    "ObservationErrorCode",
    "ObservationStore",
    "SchemaRegistry",
    "TypeSchema",
]


def __getattr__(name: str):
    if name == "ObservationStore":
        from forge.observations.store import ObservationStore

        return ObservationStore
    if name == "SchemaRegistry":
        from forge.schemas.registry import SchemaRegistry

        return SchemaRegistry
    if name == "TypeSchema":
        from forge.schemas.models import TypeSchema

        return TypeSchema
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
