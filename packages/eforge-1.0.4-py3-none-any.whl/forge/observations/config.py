from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

import yaml

from forge.observations.errors import (
    config_malformed,
    config_unknown_keys,
    emit_observation_warning,
)


@dataclass
class ObservationConfig:
    version: int = 1
    storage_format: str = "yaml"
    nodes_dir: str = "nodes"
    links_embedded: bool = True
    cache_file: str = ".cache/graph.db"
    schemas_dirs: list[str] = field(default_factory=lambda: ["schemas/"])
    display_bookmark_prefix: str = "@"
    display_interactive: bool = True
    graduation_target: str = "../manifest.yaml"
    graduation_require_kind_mapping: bool = True
    unknown_keys: dict = field(default_factory=dict)

    @classmethod
    def load(cls, observations_dir: Path) -> ObservationConfig:
        config_path = observations_dir / "config.yaml"
        if not config_path.exists():
            return cls()
        try:
            data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as exc:
            raise config_malformed(
                file_path=config_path,
                parse_error=str(exc),
            ) from exc
        if not isinstance(data, dict):
            raise config_malformed(
                file_path=config_path,
                parse_error="root must be a mapping",
            )
        known = {f.name for f in fields(cls) if f.name != "unknown_keys"}
        unknown = {k: v for k, v in data.items() if k not in known}
        if unknown:
            emit_observation_warning(
                config_unknown_keys(keys=sorted(unknown.keys()))
            )
        filtered = {k: v for k, v in data.items() if k in known}
        cfg = cls(**filtered)
        cfg.unknown_keys = unknown
        return cfg

    def save(self, observations_dir: Path) -> None:
        config_path = observations_dir / "config.yaml"
        observations_dir.mkdir(parents=True, exist_ok=True)
        payload = asdict(self)
        unknown = payload.pop("unknown_keys", {}) or {}
        payload.update(unknown)
        config_path.write_text(
            yaml.dump(payload, default_flow_style=False),
            encoding="utf-8",
        )
