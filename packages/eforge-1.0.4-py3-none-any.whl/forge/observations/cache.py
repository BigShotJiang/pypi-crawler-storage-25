from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from forge.observations.errors import cache_query_failed, cache_rebuild_failed
from forge.observations.models import DevLink, DevNode, DevNote


class SQLiteCache:
    """Derived SQLite index; YAML nodes are authoritative."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._ensure_schema()
        except sqlite3.Error as exc:
            raise cache_rebuild_failed(
                db_path=self.db_path,
                sqlite_error=str(exc),
            ) from exc

    def _ensure_schema(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS dev_nodes (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              domain TEXT,
              type TEXT,
              status TEXT,
              source_file TEXT,
              source_line INTEGER,
              properties TEXT,
              tags TEXT,
              marked INTEGER,
              manifest_ref TEXT,
              created_at TEXT,
              updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS dev_links (
              from_id TEXT,
              to_id TEXT,
              rel TEXT,
              note TEXT,
              FOREIGN KEY(from_id) REFERENCES dev_nodes(id),
              FOREIGN KEY(to_id) REFERENCES dev_nodes(id)
            );
            CREATE TABLE IF NOT EXISTS dev_notes (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              node_id TEXT,
              body TEXT,
              tags TEXT,
              created_at TEXT,
              FOREIGN KEY(node_id) REFERENCES dev_nodes(id)
            );
            CREATE INDEX IF NOT EXISTS idx_domain_type ON dev_nodes(domain, type);
            CREATE INDEX IF NOT EXISTS idx_name ON dev_nodes(name);
            CREATE INDEX IF NOT EXISTS idx_marked ON dev_nodes(marked);
            """
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def rebuild(self, nodes: list[DevNode]) -> None:
        try:
            self._conn.execute("DELETE FROM dev_links")
            self._conn.execute("DELETE FROM dev_notes")
            self._conn.execute("DELETE FROM dev_nodes")
            for node in nodes:
                self._upsert_node_no_commit(node)
            self._conn.commit()
        except sqlite3.Error as exc:
            raise cache_rebuild_failed(
                db_path=self.db_path,
                sqlite_error=str(exc),
            ) from exc

    def upsert_node(self, node: DevNode) -> None:
        try:
            self._upsert_node_no_commit(node)
            self._conn.commit()
        except sqlite3.Error as exc:
            raise cache_rebuild_failed(
                db_path=self.db_path,
                sqlite_error=str(exc),
            ) from exc

    def _upsert_node_no_commit(self, node: DevNode) -> None:
        self._conn.execute(
            """
            INSERT OR REPLACE INTO dev_nodes (
              id, name, domain, type, status, source_file, source_line,
              properties, tags, marked, manifest_ref, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                node.id,
                node.name,
                node.domain,
                node.type,
                node.status,
                node.source_file,
                node.source_line,
                json.dumps(node.properties),
                json.dumps(node.tags),
                1 if node.marked else 0,
                node.manifest_ref,
                node.created_at,
                node.updated_at,
            ),
        )
        self._conn.execute("DELETE FROM dev_links WHERE from_id = ?", (node.id,))
        for link in node.links:
            self._conn.execute(
                """
                INSERT INTO dev_links (from_id, to_id, rel, note)
                VALUES (?, ?, ?, ?)
                """,
                (node.id, link.to, link.rel, link.note),
            )
        self._conn.execute("DELETE FROM dev_notes WHERE node_id = ?", (node.id,))
        for note in node.notes:
            self._conn.execute(
                """
                INSERT INTO dev_notes (node_id, body, tags, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (node.id, note.body, json.dumps(note.tags), note.created_at),
            )

    def delete_node(self, node_id: str) -> None:
        try:
            self._conn.execute("DELETE FROM dev_links WHERE from_id = ?", (node_id,))
            self._conn.execute("DELETE FROM dev_links WHERE to_id = ?", (node_id,))
            self._conn.execute("DELETE FROM dev_notes WHERE node_id = ?", (node_id,))
            self._conn.execute("DELETE FROM dev_nodes WHERE id = ?", (node_id,))
            self._conn.commit()
        except sqlite3.Error as exc:
            raise cache_query_failed(
                sql="DELETE dev_nodes",
                params=(node_id,),
                db_path=self.db_path,
                sqlite_error=str(exc),
            ) from exc

    def query(self, sql: str, params: tuple = ()) -> list[dict]:
        try:
            cur = self._conn.execute(sql, params)
            return [dict(row) for row in cur.fetchall()]
        except sqlite3.Error as exc:
            raise cache_query_failed(
                sql=sql,
                params=params,
                db_path=self.db_path,
                sqlite_error=str(exc),
            ) from exc

    def find_by_name(self, name: str) -> str | None:
        rows = self.query(
            "SELECT id FROM dev_nodes WHERE name = ? LIMIT 1", (name,)
        )
        if rows:
            return str(rows[0]["id"])
        return None

    def get_links_to(self, name: str) -> list[dict]:
        return self.query(
            """
            SELECT dl.from_id, dl.to_id, dl.rel, dl.note, dn.name AS from_name
            FROM dev_links dl
            JOIN dev_nodes dn ON dn.id = dl.from_id
            WHERE dl.to_id = ?
            """,
            (name,),
        )

    def node_count(self) -> int:
        rows = self.query("SELECT COUNT(*) AS c FROM dev_nodes")
        return int(rows[0]["c"]) if rows else 0

    def search(
        self,
        query: str,
        *,
        domain: str | None = None,
        type_: str | None = None,
        tags: str | None = None,
        source_file: str | None = None,
        marked: bool | None = None,
    ) -> list[dict]:
        like = f"%{query}%"
        exact = query
        clauses = [
            "(n.name LIKE ? OR n.tags LIKE ? OR n.properties LIKE ? "
            "OR n.source_file LIKE ? OR dn.body LIKE ?)"
        ]
        params: list[Any] = [like, like, like, like, like]
        if domain is not None:
            clauses.append("n.domain = ?")
            params.append(domain)
        if type_ is not None:
            clauses.append("n.type = ?")
            params.append(type_)
        if tags is not None:
            clauses.append("n.tags LIKE ?")
            params.append(f"%{tags}%")
        if source_file is not None:
            clauses.append("n.source_file LIKE ?")
            params.append(f"%{source_file}%")
        if marked is not None:
            clauses.append("n.marked = ?")
            params.append(1 if marked else 0)

        sql = f"""
            SELECT n.*,
              CASE
                WHEN n.name = ? THEN 100
                WHEN n.name LIKE ? THEN 80
                WHEN n.tags LIKE ? THEN 60
                WHEN n.properties LIKE ? THEN 40
                WHEN dn.body LIKE ? THEN 30
                ELSE 20
              END AS score
            FROM dev_nodes n
            LEFT JOIN dev_notes dn ON dn.node_id = n.id
            WHERE {" AND ".join(clauses)}
            GROUP BY n.id
            ORDER BY score DESC, n.name ASC
        """
        score_params = [exact, like, like, like, like]
        return self.query(sql, tuple(score_params + params))

    def is_stale(self, nodes_dir: Path) -> bool:
        if not self.db_path.exists():
            return True
        yaml_files = (
            list(nodes_dir.glob("*.yaml")) if nodes_dir.is_dir() else []
        )
        try:
            db_count = self.node_count()
        except Exception:
            return True
        if len(yaml_files) != db_count:
            return True
        if not yaml_files:
            return db_count > 0
        db_mtime = self.db_path.stat().st_mtime
        for path in yaml_files:
            if path.stat().st_mtime > db_mtime:
                return True
        return False

    def node_from_row(self, row: dict) -> DevNode:
        props = row.get("properties")
        if isinstance(props, str):
            props = json.loads(props) if props else {}
        tags = row.get("tags")
        if isinstance(tags, str):
            tags = json.loads(tags) if tags else []
        node_id = row["id"]
        link_rows = self.query(
            "SELECT to_id, rel, note FROM dev_links WHERE from_id = ?",
            (node_id,),
        )
        links = [
            DevLink(to=r["to_id"], rel=r["rel"], note=r.get("note"))
            for r in link_rows
        ]
        note_rows = self.query(
            "SELECT body, tags, created_at FROM dev_notes WHERE node_id = ?",
            (node_id,),
        )
        notes: list[DevNote] = []
        for nr in note_rows:
            note_tags = nr.get("tags")
            if isinstance(note_tags, str):
                note_tags = json.loads(note_tags) if note_tags else []
            notes.append(
                DevNote(
                    body=nr["body"],
                    tags=note_tags or [],
                    created_at=nr.get("created_at") or "",
                )
            )
        return DevNode(
            id=node_id,
            name=row["name"],
            domain=row.get("domain"),
            type=row.get("type"),
            status=row.get("status") or "observed",
            source_file=row.get("source_file"),
            source_line=row.get("source_line"),
            properties=props or {},
            tags=tags or [],
            links=links,
            notes=notes,
            marked=bool(row.get("marked")),
            manifest_ref=row.get("manifest_ref"),
            created_at=row.get("created_at") or "",
            updated_at=row.get("updated_at") or "",
        )
