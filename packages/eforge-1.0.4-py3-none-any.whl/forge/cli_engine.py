"""Shared CLI adapter registry for forge command packages."""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from typing import Any

import click


class CLIEngine:
    """Class-level registry; no instance state."""

    _registry: dict[str, dict[str, click.Group]] = {}

    @classmethod
    def register(cls, adapter: str, group: click.Group, name: str) -> None:
        if adapter not in cls._registry:
            cls._registry[adapter] = {}
        groups = cls._registry[adapter]
        if not any(existing is group for existing in groups.values()):
            groups[name] = group

    @classmethod
    def discover(cls, package_path: str, package_name: str) -> None:
        path = Path(package_path)
        if not path.is_dir():
            return
        for module_info in pkgutil.iter_modules([str(path)]):
            if module_info.name.startswith("_"):
                continue
            importlib.import_module(f"{package_name}.{module_info.name}")

    @classmethod
    def build(
        cls,
        adapter: str,
        name: str,
        version: str,
        description: str,
    ) -> click.Group:
        groups = dict(cls._registry.get(adapter, {}))

        @click.group(name=name, help=description)
        @click.version_option(version=version, prog_name=name)
        def cli() -> None:
            """Root CLI group."""

        for cmd_name, group in sorted(groups.items()):
            cli.add_command(group, name=cmd_name)
        return cli

    @classmethod
    def adapters(cls) -> list[str]:
        return sorted(cls._registry.keys())

    @classmethod
    def commands(cls, adapter: str) -> list[str]:
        return sorted(cls._registry.get(adapter, {}).keys())


import functools
import json
from enum import Enum
from typing import Any, Callable


class OutputFormat(str, Enum):
    SIMPLE = "simple"
    JSON = "json"
    QUIET = "quiet"


def yes_option():
    """Reusable -y/--yes decorator for any command."""
    return click.option(
        "--yes",
        "-y",
        "yes_flag",
        is_flag=True,
        default=False,
        help="Skip interactive prompts.",
    )


def project_path_option(required: bool = False):
    return click.option(
        "--project-path",
        required=required,
        default=".",
        show_default=True,
        help="Project root.",
    )


def dry_run_option():
    return click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Preview without writing.",
    )


def response_tier_option(default: str = "L1"):
    return click.option(
        "--response-tier",
        type=click.Choice(["L0", "L1", "L2"]),
        default=default,
        show_default=True,
        help="Output tier (L0=minimal, L1=standard, L2=full).",
    )


def output_format_options(f):
    """
    Decorator adding --json and --quiet to any command.
    Injects output_format: OutputFormat into the function.
    """

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        json_flag = kwargs.pop("json_output", False)
        quiet_flag = kwargs.pop("quiet_output", False)
        if json_flag and quiet_flag:
            raise click.UsageError("Cannot use --json and --quiet together.")
        if json_flag:
            kwargs["output_format"] = OutputFormat.JSON
        elif quiet_flag:
            kwargs["output_format"] = OutputFormat.QUIET
        else:
            kwargs["output_format"] = OutputFormat.SIMPLE
        return f(*args, **kwargs)

    wrapper = click.option(
        "--json",
        "json_output",
        is_flag=True,
        default=False,
        help="Output raw JSON.",
    )(wrapper)
    wrapper = click.option(
        "--quiet",
        "-q",
        "quiet_output",
        is_flag=True,
        default=False,
        help="Minimal one-line output.",
    )(wrapper)
    return wrapper


def coerce_output_format(fmt: Any) -> OutputFormat:
    if isinstance(fmt, OutputFormat):
        return fmt
    if fmt is False or fmt is None:
        return OutputFormat.SIMPLE
    if isinstance(fmt, str):
        if fmt in ("human", "OutputFormat.HUMAN"):
            return OutputFormat.SIMPLE
        if fmt.startswith("OutputFormat."):
            name = fmt.split(".", 1)[1]
            if name == "HUMAN":
                return OutputFormat.SIMPLE
            if name in OutputFormat.__members__:
                return OutputFormat[name]
        for member in OutputFormat:
            if fmt in (member.value, member.name, f"OutputFormat.{member.name}"):
                return member
    return OutputFormat.SIMPLE


def print_result(
    result: dict[str, Any],
    fmt: OutputFormat | str,
    simple_fn: Callable[[dict[str, Any]], None],
    quiet_fn: Callable[[dict[str, Any]], None] | None = None,
) -> None:
    """Print result in the requested format (SIMPLE / JSON / QUIET)."""
    fmt_val = coerce_output_format(fmt)
    if fmt_val == OutputFormat.JSON:
        click.echo(json.dumps(result, indent=2, default=str))
        return
    if fmt_val == OutputFormat.QUIET:
        if quiet_fn is not None:
            quiet_fn(result)
        else:
            parts = [
                f"{k}={v}"
                for k, v in result.items()
                if v not in (None, [], {})
            ]
            click.echo(" ".join(parts[:4]))
        return
    simple_fn(result)
