# Package marker for bundled default schemas.
