"""
Cross-subsystem error catalog and lookup.

ForgeError (typed runtime errors) lives in forge.core.errors.
This module holds ErrorRegistry for discoverable code metadata.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ErrorEntry:
    code: str
    name: str
    description: str
    hint: str | None = None
    subsystem: str = "forge"
    context_fields: list[str] = field(default_factory=list)


class ErrorRegistry:
    _entries: dict[str, ErrorEntry] = {}

    @classmethod
    def register(cls, entry: ErrorEntry) -> None:
        cls._entries[entry.code] = entry

    @classmethod
    def lookup(cls, code: str) -> ErrorEntry | None:
        return cls._entries.get(code)

    @classmethod
    def search(cls, query: str) -> list[ErrorEntry]:
        q = query.lower()
        return [
            e
            for e in cls._entries.values()
            if q in e.code.lower()
            or q in e.description.lower()
            or q in e.name.lower()
        ]

    @classmethod
    def all_codes(cls, subsystem: str | None = None) -> list[str]:
        entries = cls._entries.values()
        if subsystem:
            entries = [e for e in entries if e.subsystem == subsystem]
        return sorted(e.code for e in entries)

    @classmethod
    def all_entries(cls, subsystem: str | None = None) -> list[ErrorEntry]:
        entries = list(cls._entries.values())
        if subsystem:
            entries = [e for e in entries if e.subsystem == subsystem]
        return sorted(entries, key=lambda e: e.code)
