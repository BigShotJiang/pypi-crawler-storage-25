"""ManifestObservationBridge — unified declaration + observation node context."""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from forge.observations.models import DevNode


@dataclass
class NodeContext:
    node_id: str
    declared: bool = False
    implemented: bool = False
    kind: str | None = None
    domain: str | None = None
    tier: int | None = None
    dev_node: DevNode | None = None
    schema_properties: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    marked: bool = False
    observation_links: int = 0
    error_stats: dict = field(default_factory=dict)
    related_tasks: list[str] = field(default_factory=list)

    @property
    def has_observation(self) -> bool:
        return self.dev_node is not None

    @property
    def is_graduated(self) -> bool:
        return (
            self.dev_node is not None
            and self.dev_node.status == "graduated"
        )

    def to_dict(self) -> dict:
        d = asdict(self)
        d["has_observation"] = self.has_observation
        d["is_graduated"] = self.is_graduated
        d.pop("dev_node", None)
        return d


class ManifestObservationBridge:
    """Unified view across manifest declaration and observation DevNodes."""

    def __init__(
        self,
        project_path: Path,
        store: Any | None,
    ) -> None:
        self.project_path = Path(project_path).resolve()
        self._store = store
        self._manifest_nodes: dict[str, Any] | None = None

    @classmethod
    def for_project(cls, project_path: Path | str) -> ManifestObservationBridge:
        """Never raises — bridge with None store if observations unavailable."""
        root = Path(project_path).expanduser().resolve()
        store = None
        try:
            if (root / ".forge").is_dir():
                from forge.observations.store import ObservationStore

                store = ObservationStore(root)
        except Exception:
            store = None
        return cls(root, store)

    def context_for_node(self, node_id: str) -> NodeContext:
        """Build NodeContext for a manifest node id. Never raises."""
        try:
            ctx = NodeContext(node_id=node_id)
            mnode = self._find_manifest_node(node_id)
            if mnode is not None:
                ctx.declared = True
                ctx.kind = getattr(mnode, "kind", None) or None
                ctx.domain = getattr(mnode, "domain", None) or None
                status = (getattr(mnode, "status", None) or "").lower()
                ctx.implemented = status in (
                    "implemented",
                    "present",
                    "active",
                )
                meta = getattr(mnode, "meta", None) or {}
                if isinstance(meta, dict):
                    raw_tier = meta.get("tier")
                    if raw_tier is not None:
                        try:
                            ctx.tier = int(raw_tier)
                        except (TypeError, ValueError):
                            pass

            if self._store is not None:
                dev = self._store.find_by_manifest_ref(node_id)
                if dev is not None:
                    ctx.dev_node = dev
                    ctx.schema_properties = self._schema_props(dev)
                    ctx.notes = [n.body for n in dev.notes]
                    ctx.tags = list(dev.tags)
                    ctx.marked = dev.marked
                    ctx.observation_links = len(dev.links)

            ctx.error_stats = self._error_stats()
            ctx.related_tasks = self._related_tasks(node_id)
            return ctx
        except Exception:
            return NodeContext(node_id=node_id)

    def find_or_create_devnode(
        self,
        node_id: str,
        kind: str,
        path: str,
        *,
        schema_properties: dict[str, Any] | None = None,
        schema_ref: tuple[str, str] | None = None,
    ) -> DevNode | None:
        """Find or create DevNode linked to manifest node_id."""
        if self._store is None:
            return None
        try:
            props = dict(schema_properties or {})
            existing = self._store.find_by_manifest_ref(node_id)
            if existing is None:
                by_name = self._store.find_by_name(node_id)
                if by_name is not None and by_name.manifest_ref == node_id:
                    existing = by_name

            if existing is not None:
                if props:
                    existing.properties.update(props)
                    self._store.save_node(existing)
                return existing

            domain_name = type_name = None
            if schema_ref is not None:
                domain_name, type_name = schema_ref

            dev_node = DevNode(
                id=str(uuid.uuid4())[:8],
                name=node_id,
                domain=domain_name,
                type=type_name if schema_ref else kind,
                status="graduated",
                source_file=path,
                properties=props,
                manifest_ref=node_id,
            )
            self._store.save_node(dev_node)
            return dev_node
        except Exception:
            return None

    def has_store(self) -> bool:
        return self._store is not None

    def save_devnodes_batch(self, nodes: list[DevNode]) -> None:
        """Write DevNodes in one batch; no-op if store missing or list empty."""
        if self._store is not None and nodes:
            self._store.save_nodes_batch(nodes)

    def all_devnodes_by_manifest_ref(self) -> dict[str, DevNode]:
        """
        Return all DevNodes keyed by manifest_ref.
        Empty dict if no observation store.
        Used by import-manifest for bulk operations.
        """
        if self._store is None:
            return {}
        try:
            return {
                n.manifest_ref: n
                for n in self._store.list_nodes()
                if n.manifest_ref
            }
        except Exception:
            return {}

    def graduate(self, dev_node: DevNode, manifest_kind: str) -> None:
        """Stub — full graduation flow not implemented yet."""
        _ = (dev_node, manifest_kind)
        raise NotImplementedError(
            "graduation sprint not yet done — use forge node graduate when available"
        )

    def _find_manifest_node(self, node_id: str) -> Any | None:
        try:
            if self._manifest_nodes is None:
                from forge.tools.manifest.graph import build_manifest_graph

                graph = build_manifest_graph(self.project_path)
                self._manifest_nodes = {
                    n.id: n for n in graph.nodes if getattr(n, "id", None)
                }
            return self._manifest_nodes.get(node_id)
        except Exception:
            return None

    def _schema_props(self, dev_node: DevNode) -> dict:
        """
        Return typed schema properties for this DevNode.
        Uses SchemaRegistry to know which properties
        are schema-defined vs freeform.
        Falls back to raw properties if schema unavailable.
        """
        try:
            if not dev_node.domain or not dev_node.type:
                return dict(dev_node.properties or {})
            from forge.schemas.registry import SchemaRegistry

            registry = SchemaRegistry.for_project(self.project_path)
            schema = registry.get_domain(dev_node.domain, dev_node.type)
            if not schema:
                return dict(dev_node.properties or {})
            return {
                k: dev_node.properties[k]
                for k in schema.properties
                if dev_node.properties.get(k) is not None
            }
        except Exception:
            return dict(dev_node.properties or {})

    def _error_stats(self) -> dict:
        if self._store is None:
            return {}
        try:
            from forge.observations.event_log import EventLog

            log = EventLog(self._store.observations_dir)
            return dict(log.stats())
        except Exception:
            return {}

    def _related_tasks(self, node_id: str) -> list[str]:
        try:
            import yaml

            from forge.devtools.models.tasks import ForgeTask

            tasks_dir = self.project_path / ".forge" / "tasks"
            if not tasks_dir.is_dir():
                return []
            related: list[str] = []
            needle = node_id.lower()
            for f in sorted(tasks_dir.glob("TASK-*.yaml")):
                try:
                    data = yaml.safe_load(f.read_text(encoding="utf-8"))
                    task = ForgeTask.from_dict(data)
                except Exception:
                    continue
                hay = " ".join(
                    [
                        task.id or "",
                        task.title or "",
                        task.note or "",
                        " ".join(task.tags or []),
                    ]
                ).lower()
                if needle in hay:
                    related.append(task.id)
            return related[:10]
        except Exception:
            return []
