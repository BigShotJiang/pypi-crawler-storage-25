from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from forge.schemas.registry import SchemaRegistry

from forge.observations.errors import (
    schema_empty_enum,
    schema_inheritance_cycle,
    schema_override_required,
)

MERGED_PROPERTIES_MAX_DEPTH = 10


def _filter_known(data: dict[str, Any], cls: type) -> dict[str, Any]:
    known = {f.name for f in fields(cls)}
    return {k: v for k, v in data.items() if k in known}


@dataclass
class WhenClause:
    property: str
    equals: Any = None
    in_values: list[Any] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WhenClause:
        return cls(**_filter_known(data, cls))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def matches(self, props: dict[str, Any]) -> bool:
        if self.property not in props:
            return False
        val = props[self.property]
        if self.in_values:
            return val in self.in_values
        return val == self.equals


@dataclass
class EnumOption:
    value: str
    label: str | None = None
    exposes: dict[str, PropertyDef] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EnumOption:
        filtered = _filter_known(data, cls)
        raw_exposes = data.get("exposes") or {}
        if isinstance(raw_exposes, dict):
            filtered["exposes"] = {
                k: PropertyDef.from_dict(k, v) if isinstance(v, dict) else v
                for k, v in raw_exposes.items()
            }
        return cls(**filtered)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["exposes"] = {k: v.to_dict() for k, v in self.exposes.items()}
        return data


@dataclass
class ConstraintDef:
    rule: str
    condition: dict[str, Any] = field(default_factory=dict)
    requires: list[str] = field(default_factory=list)
    requires_status: list[str] = field(default_factory=list)
    forbids: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConstraintDef:
        return cls(**_filter_known(data, cls))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def condition_matches(self, props: dict[str, Any]) -> bool:
        if not self.condition:
            return True
        for key, expected in self.condition.items():
            if props.get(key) != expected:
                return False
        return True


@dataclass
class PropertyDef:
    key: str
    type: str
    options: list[EnumOption] = field(default_factory=list)
    required: bool = False
    default: Any = None
    prompt: str | None = None
    inherits: str | None = None
    override: bool = False
    constraints: list[ConstraintDef] = field(default_factory=list)
    _option_index: dict[str, EnumOption] = field(
        default_factory=dict, repr=False, compare=False
    )

    @classmethod
    def from_dict(cls, key: str, data: dict[str, Any]) -> PropertyDef:
        filtered = _filter_known(data, cls)
        filtered["key"] = data.get("key") or key
        raw_options = data.get("options") or []
        filtered["options"] = [
            EnumOption.from_dict(o) if isinstance(o, dict) else o for o in raw_options
        ]
        raw_constraints = data.get("constraints") or []
        filtered["constraints"] = [
            ConstraintDef.from_dict(c) if isinstance(c, dict) else c
            for c in raw_constraints
        ]
        return cls(**filtered)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("_option_index", None)
        data["options"] = [o.to_dict() for o in self.options]
        data["constraints"] = [c.to_dict() for c in self.constraints]
        return data

    def _ensure_option_index(self) -> None:
        if not self._option_index:
            self._option_index = {o.value: o for o in self.options}

    def get_option(self, value: str) -> EnumOption | None:
        self._ensure_option_index()
        return self._option_index.get(value)

    def exposes_for(self, value: str) -> dict[str, PropertyDef]:
        opt = self.get_option(value)
        return opt.exposes if opt else {}


@dataclass
class TypeSchema:
    domain: str
    type_name: str
    category: str = "domain"
    description: str | None = None
    inherits: str | None = None
    properties: dict[str, PropertyDef] = field(default_factory=dict)
    prompts_order: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TypeSchema:
        filtered = _filter_known(data, cls)
        filtered["type_name"] = data.get("type_name") or data.get("type") or ""
        filtered["domain"] = data.get("domain") or ""
        if "category" not in filtered:
            filtered["category"] = data.get("category") or "domain"
        raw_props = data.get("properties") or {}
        if isinstance(raw_props, dict):
            filtered["properties"] = {
                k: PropertyDef.from_dict(k, v) if isinstance(v, dict) else v
                for k, v in raw_props.items()
            }
        return cls(**filtered)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["type"] = self.type_name
        data["properties"] = {k: v.to_dict() for k, v in self.properties.items()}
        return data

    def _parse_inherits(self) -> tuple[str, str] | None:
        if not self.inherits:
            return None
        parts = self.inherits.split("/", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
        return self.domain, parts[0]

    def validate_structure(self) -> None:
        for prop_key, prop_def in self.properties.items():
            if prop_def.type in ("enum", "multi_enum") and not prop_def.options:
                raise schema_empty_enum(
                    type_name=self.type_name,
                    property_key=prop_key,
                    domain=self.domain,
                )

    def merged_properties(
        self,
        registry: SchemaRegistry,
        *,
        max_depth: int = MERGED_PROPERTIES_MAX_DEPTH,
    ) -> dict[str, PropertyDef]:
        merged: dict[str, PropertyDef] = {}
        chain: list[TypeSchema] = []
        seen_keys: list[str] = []
        seen: set[tuple[str, str, str]] = set()
        current: TypeSchema | None = self
        depth = 0
        while current is not None and depth < max_depth:
            key = (current.category, current.domain, current.type_name)
            label = f"{current.category}/{current.domain}/{current.type_name}"
            if key in seen:
                raise schema_inheritance_cycle(
                    cycle=seen_keys + [label],
                    type_name=self.type_name,
                )
            seen.add(key)
            seen_keys.append(label)
            chain.append(current)
            parsed = current._parse_inherits()
            if parsed is None:
                break
            parent_domain, parent_type = parsed
            current = registry.lookup(
                current.category,
                parent_domain,
                parent_type,
            )
            depth += 1

        if depth >= max_depth:
            raise schema_inheritance_cycle(
                cycle=seen_keys,
                type_name=self.type_name,
            )

        for schema in reversed(chain):
            for prop_key, prop_def in schema.properties.items():
                if prop_key in merged and not prop_def.override:
                    raise schema_override_required(
                        type_name=schema.type_name,
                        property_key=prop_key,
                        parent_type=f"{schema.domain}/{schema.type_name}",
                    )
                merged[prop_key] = prop_def
        return merged

    def validate_properties(
        self,
        props: dict,
        *,
        registry: SchemaRegistry | None = None,
    ) -> list[str]:
        violations: list[str] = []
        if registry is not None:
            merged = self.merged_properties(registry)
        else:
            merged = self.properties

        for prop_key, prop_def in merged.items():
            value = props.get(prop_key)
            if prop_def.required and (value is None or value == ""):
                violations.append(f"required property missing: {prop_key}")
                continue

            if value is None or value == "":
                if prop_def.default is not None and prop_key not in props:
                    continue
                continue

            if prop_def.type == "enum":
                if prop_def.get_option(str(value)) is None:
                    allowed = [o.value for o in prop_def.options]
                    violations.append(
                        f"{prop_key}: value {value!r} not in {allowed}"
                    )
                else:
                    nested = prop_def.exposes_for(str(value))
                    for nested_key, nested_def in nested.items():
                        nested_val = props.get(nested_key)
                        if nested_def.required and (
                            nested_val is None or nested_val == ""
                        ):
                            violations.append(
                                f"required nested property missing: {nested_key}"
                            )
                        elif nested_val is not None and nested_def.type == "enum":
                            if nested_def.get_option(str(nested_val)) is None:
                                allowed = [o.value for o in nested_def.options]
                                violations.append(
                                    f"{nested_key}: value {nested_val!r} not in {allowed}"
                                )

            elif prop_def.type == "multi_enum":
                if not isinstance(value, list):
                    violations.append(f"{prop_key}: expected list for multi_enum")
                else:
                    for item in value:
                        if prop_def.get_option(str(item)) is None:
                            violations.append(
                                f"{prop_key}: value {item!r} not in enum options"
                            )

            for constraint in prop_def.constraints:
                if not constraint.condition_matches(props):
                    continue
                for req in constraint.requires:
                    if props.get(req) in (None, "", []):
                        violations.append(
                            f"constraint {constraint.rule!r}: requires {req}"
                        )
                for forbidden in constraint.forbids:
                    if props.get(forbidden) not in (None, "", []):
                        violations.append(
                            f"constraint {constraint.rule!r}: forbids {forbidden}"
                        )

        return violations
