from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

import yaml

from forge.schemas.models import TypeSchema

_PACKAGE_DEFAULTS = (
    Path(__file__).resolve().parent.parent / "_defaults" / "schemas"
)


@dataclass
class SchemaEntry:
    category: str
    domain: str
    type_name: str
    scope: str
    path: Path
    data: dict[str, Any]


def _schema_is_internal(entry: SchemaEntry) -> bool:
    """Forge-internal entity schemas (manifest_node, DevNode status)."""
    if entry.category != "entity":
        return False
    return entry.domain in ("manifest_node", "internal")


def _entry_source_key(entry: SchemaEntry) -> str:
    """Display source label for schema list."""
    if entry.scope == "builtin":
        return "built-in"
    if entry.scope == "defaults":
        return "defaults"
    if entry.scope in ("project", "legacy"):
        return "project"
    return entry.scope


class SchemaStore:
    """Read/write project schema files under .eforge/schemas/."""

    def __init__(self, project_path: Path) -> None:
        self.project_path = Path(project_path).resolve()
        self._project = self.project_path / ".eforge" / "schemas"
        self._project_legacy = (
            self.project_path / ".forge" / "observations" / "schemas"
        )
        self._defaults = self._project / "_defaults"
        self._package = _PACKAGE_DEFAULTS

    def _schema_path(
        self,
        category: str,
        domain: str,
        type_name: str,
        *,
        scope: str = "project",
    ) -> Path:
        filename = f"{type_name}.yaml"
        if scope == "defaults":
            return self._defaults / category / domain / filename
        if scope == "package":
            return self._package / category / domain / filename
        return self._project / category / domain / filename

    def _legacy_path(self, domain: str, type_name: str) -> Path:
        return self._project_legacy / domain / f"{type_name}.yaml"

    @classmethod
    def init_project(cls, project_path: Path) -> None:
        store = cls(project_path)
        if store._defaults.is_dir() and any(store._defaults.rglob("*.yaml")):
            return
        store._defaults.mkdir(parents=True, exist_ok=True)
        if not store._package.is_dir():
            return
        for src in store._package.rglob("*.yaml"):
            rel = src.relative_to(store._package)
            dest = store._defaults / rel
            if dest.exists():
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)

    def restore_default(self, category: str, domain: str, type_name: str) -> Path:
        src = self._schema_path(category, domain, type_name, scope="package")
        dest = self._schema_path(category, domain, type_name, scope="defaults")
        if not src.is_file():
            raise FileNotFoundError(src)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        return dest

    def restore_all_defaults(self) -> int:
        count = 0
        if not self._package.is_dir():
            return count
        for src in self._package.rglob("*.yaml"):
            rel = src.relative_to(self._package)
            dest = self._defaults / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            count += 1
        return count

    def exists(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> bool:
        if self._schema_path(category, domain, type_name).is_file():
            return True
        if category == "domain" and self._legacy_path(domain, type_name).is_file():
            return True
        return self._schema_path(
            category, domain, type_name, scope="defaults"
        ).is_file()

    def read(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> TypeSchema | None:
        for scope in ("project", "defaults"):
            path = self._schema_path(category, domain, type_name, scope=scope)
            if path.is_file():
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                return TypeSchema.from_dict(data)
        if category == "domain":
            legacy = self._legacy_path(domain, type_name)
            if legacy.is_file():
                data = yaml.safe_load(legacy.read_text(encoding="utf-8")) or {}
                return TypeSchema.from_dict(data)
        return None

    def write(
        self,
        schema: TypeSchema,
        *,
        scope: str = "project",
    ) -> Path:
        path = self._schema_path(
            schema.category,
            schema.domain,
            schema.type_name,
            scope=scope,
        )
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            yaml.safe_dump(schema.to_dict(), sort_keys=False),
            encoding="utf-8",
        )
        return path

    def delete(
        self,
        category: str,
        domain: str,
        type_name: str,
        *,
        scope: str = "project",
    ) -> bool:
        path = self._schema_path(category, domain, type_name, scope=scope)
        if path.is_file():
            path.unlink()
            return True
        return False

    def list_schemas(
        self,
        category: str,
        domain: str | None = None,
        *,
        scope: str = "project",
    ) -> list[tuple[str, str]]:
        base = self._defaults if scope == "defaults" else self._project
        root = base / category
        if not root.is_dir():
            return []
        out: list[tuple[str, str]] = []
        domains = [domain] if domain else [d.name for d in root.iterdir() if d.is_dir()]
        for dom in domains:
            dom_dir = root / dom
            if not dom_dir.is_dir():
                continue
            for path in dom_dir.glob("*.yaml"):
                out.append((dom, path.stem))
        return sorted(out)

    def copy_to(
        self,
        category: str,
        domain: str,
        type_name: str,
        *,
        from_scope: str = "defaults",
        to_scope: str = "project",
    ) -> Path:
        src = self._schema_path(category, domain, type_name, scope=from_scope)
        dest = self._schema_path(category, domain, type_name, scope=to_scope)
        if not src.is_file():
            raise FileNotFoundError(src)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        return dest

    def read_dict(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> dict[str, Any] | None:
        entry = self.find(category, domain, type_name)
        if entry is None:
            return None
        return dict(entry.data)

    def write_dict(
        self,
        schema_dict: dict[str, Any],
        *,
        scope: str = "project",
    ) -> Path:
        category = schema_dict.get("category") or "domain"
        domain = str(schema_dict.get("domain") or "")
        type_name = str(schema_dict.get("type_name") or schema_dict.get("type") or "")
        path = self._schema_path(category, domain, type_name, scope=scope)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            yaml.safe_dump(schema_dict, sort_keys=False),
            encoding="utf-8",
        )
        return path

    def find(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> SchemaEntry | None:
        for scope in ("project", "defaults", "package"):
            path = self._schema_path(category, domain, type_name, scope=scope)
            if path.is_file():
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                if isinstance(data, dict):
                    data.setdefault("domain", domain)
                    data.setdefault("type_name", type_name)
                    data.setdefault("category", category)
                    display_scope = "builtin" if scope == "package" else scope
                    return SchemaEntry(
                        category=category,
                        domain=domain,
                        type_name=type_name,
                        scope=display_scope,
                        path=path,
                        data=data,
                    )
        if category == "domain":
            legacy = self._legacy_path(domain, type_name)
            if legacy.is_file():
                data = yaml.safe_load(legacy.read_text(encoding="utf-8")) or {}
                if isinstance(data, dict):
                    return SchemaEntry(
                        category="domain",
                        domain=domain,
                        type_name=type_name,
                        scope="legacy",
                        path=legacy,
                        data=data,
                    )
        return None

    def list_all(
        self,
        *,
        category: str | None = None,
        domain: str | None = None,
        scope: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Flat list of schemas with display metadata.

        Each item: category, domain, type, source, path, entry (SchemaEntry).
        """
        rows: list[dict[str, Any]] = []
        for entry in self.iter_all(
            category=category, domain=domain, scope=scope
        ):
            rows.append(
                {
                    "category": entry.category,
                    "domain": entry.domain,
                    "type": entry.type_name,
                    "source": _entry_source_key(entry),
                    "path": entry.path,
                    "entry": entry,
                    "internal": _schema_is_internal(entry),
                }
            )
        return rows

    def iter_all(
        self,
        *,
        category: str | None = None,
        domain: str | None = None,
        scope: str | None = None,
    ) -> Iterator[SchemaEntry]:
        categories = (
            [category]
            if category and category != "all"
            else ["domain", "entity", "config"]
        )
        scopes = (
            [scope]
            if scope and scope not in ("all", None)
            else ["project", "defaults", "package"]
        )
        if scope == "builtin":
            scopes = ["package"]
        seen: set[tuple[str, str, str, str]] = set()

        for cat in categories:
            for sc in scopes:
                if sc == "legacy":
                    continue
                base = self._scope_root(sc)
                if base is None or not base.is_dir():
                    continue
                root = base / cat if sc != "legacy" else base
                if not root.is_dir():
                    continue
                for dom_dir in sorted(root.iterdir()):
                    if not dom_dir.is_dir():
                        continue
                    if domain and dom_dir.name != domain:
                        continue
                    for path in sorted(dom_dir.glob("*.yaml")):
                        key = (cat, dom_dir.name, path.stem, sc)
                        if key in seen:
                            continue
                        seen.add(key)
                        try:
                            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                        except yaml.YAMLError:
                            continue
                        if not isinstance(data, dict):
                            continue
                        data.setdefault("domain", dom_dir.name)
                        data.setdefault("type_name", path.stem)
                        data.setdefault("category", cat)
                        yield SchemaEntry(
                            category=cat,
                            domain=dom_dir.name,
                            type_name=path.stem,
                            scope=sc if sc != "package" else "builtin",
                            path=path,
                            data=data,
                        )

        if (scope in (None, "all", "legacy")) and (not category or category == "domain"):
            if self._project_legacy.is_dir():
                for dom_dir in sorted(self._project_legacy.iterdir()):
                    if not dom_dir.is_dir():
                        continue
                    if domain and dom_dir.name != domain:
                        continue
                    for path in sorted(dom_dir.glob("*.yaml")):
                        key = ("domain", dom_dir.name, path.stem, "legacy")
                        if key in seen:
                            continue
                        seen.add(key)
                        try:
                            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                        except yaml.YAMLError:
                            continue
                        if isinstance(data, dict):
                            yield SchemaEntry(
                                category="domain",
                                domain=dom_dir.name,
                                type_name=path.stem,
                                scope="legacy",
                                path=path,
                                data=data,
                            )

    def _scope_root(self, scope: str) -> Path | None:
        if scope == "project":
            return self._project
        if scope == "defaults":
            return self._defaults
        if scope in ("package", "builtin"):
            return self._package
        return None

    def has_defaults_copy(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> bool:
        return self._schema_path(
            category, domain, type_name, scope="defaults"
        ).is_file()

    def has_package_copy(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> bool:
        return self._schema_path(
            category, domain, type_name, scope="package"
        ).is_file()
