from __future__ import annotations

from pathlib import Path

import yaml

from forge.observations.errors import schema_malformed
from forge.schemas.models import TypeSchema

_PACKAGE_DEFAULTS = (
    Path(__file__).resolve().parent.parent / "_defaults" / "schemas"
)
_LEGACY_PACKAGE_DEFAULTS = (
    Path(__file__).resolve().parent.parent
    / "observations"
    / "_defaults"
    / "schemas"
)


class SchemaRegistry:
    """Forge-wide schema lookup: project, defaults, then package canonical."""

    _instances: dict[str, SchemaRegistry] = {}

    def __init__(self, project_path: Path | None = None) -> None:
        self._project_path = Path(project_path).resolve() if project_path else None
        self._cache: dict[tuple[str, str, str], TypeSchema | None] = {}

    @classmethod
    def for_project(cls, project_path: Path | None) -> SchemaRegistry:
        key = str(project_path.resolve()) if project_path else ""
        if key not in cls._instances:
            cls._instances[key] = cls(project_path)
        return cls._instances[key]

    @property
    def project_schemas_dir(self) -> Path | None:
        if self._project_path is None:
            return None
        return self._project_path / ".eforge" / "schemas"

    @property
    def observations_schemas_dir(self) -> Path | None:
        if self._project_path is None:
            return None
        return self._project_path / ".forge" / "observations" / "schemas"

    def _path_candidates(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> list[Path]:
        filename = f"{type_name}.yaml"
        candidates: list[Path] = []
        if self._project_path is not None:
            eforge = self._project_path / ".eforge" / "schemas"
            candidates.append(eforge / category / domain / filename)
            candidates.append(eforge / "_defaults" / category / domain / filename)
            if category == "domain":
                legacy = self.observations_schemas_dir
                if legacy is not None:
                    candidates.append(legacy / domain / filename)
        candidates.append(_PACKAGE_DEFAULTS / category / domain / filename)
        if category == "domain" and _LEGACY_PACKAGE_DEFAULTS.is_dir():
            candidates.append(_LEGACY_PACKAGE_DEFAULTS / domain / filename)
        return candidates

    def _load_from_path(self, path: Path) -> TypeSchema:
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise schema_malformed(
                file_path=path,
                parse_error=str(exc),
            ) from exc
        try:
            data = yaml.safe_load(raw) or {}
        except yaml.YAMLError as exc:
            raise schema_malformed(
                file_path=path,
                parse_error=str(exc),
            ) from exc
        if not isinstance(data, dict):
            raise schema_malformed(
                file_path=path,
                parse_error="root must be a mapping",
            )
        data.setdefault("domain", path.parent.name)
        data.setdefault("type_name", path.stem)
        if "category" not in data:
            parts = path.parts
            inferred = "domain"
            for idx, part in enumerate(parts):
                if part == "schemas" and idx + 1 < len(parts):
                    nxt = parts[idx + 1]
                    if nxt in ("entity", "domain", "config"):
                        inferred = nxt
                        break
                    if nxt == "_defaults" and idx + 2 < len(parts):
                        inferred = parts[idx + 2]
                        break
            data["category"] = inferred
        schema = TypeSchema.from_dict(data)
        schema.validate_structure()
        return schema

    def lookup(
        self,
        category: str,
        domain: str,
        type_name: str,
    ) -> TypeSchema | None:
        key = (category, domain, type_name)
        if key in self._cache:
            return self._cache[key]

        schema: TypeSchema | None = None
        found_file = False
        for path in self._path_candidates(category, domain, type_name):
            if not path.is_file():
                continue
            found_file = True
            schema = self._load_from_path(path)
            break

        if not found_file:
            self._cache[key] = None
            return None

        self._cache[key] = schema
        return schema

    def get(self, domain: str, type_name: str) -> TypeSchema | None:
        """Backward-compatible domain schema lookup (OBS-010/OBS-011)."""
        return self.get_domain(domain, type_name)

    def get_domain(self, domain: str, type_name: str) -> TypeSchema | None:
        return self.lookup("domain", domain, type_name)

    def get_entity(self, entity_type: str, subtype: str) -> TypeSchema | None:
        return self.lookup("entity", entity_type, subtype)

    def list_domains(self) -> list[str]:
        domains: set[str] = set()
        for root in self._discover_category_roots("domain"):
            if root.is_dir():
                for child in root.iterdir():
                    if child.is_dir() and any(child.glob("*.yaml")):
                        domains.add(child.name)
        return sorted(domains)

    def list_types(self, domain: str) -> list[str]:
        types: set[str] = set()
        for root in self._discover_category_roots("domain"):
            domain_dir = root / domain
            if domain_dir.is_dir():
                for path in domain_dir.glob("*.yaml"):
                    types.add(path.stem)
        return sorted(types)

    def list_entity_types(self) -> list[str]:
        types: set[str] = set()
        for root in self._discover_category_roots("entity"):
            if root.is_dir():
                for child in root.iterdir():
                    if child.is_dir() and any(child.glob("*.yaml")):
                        types.add(child.name)
        return sorted(types)

    def list_entity_subtypes(self, entity_type: str) -> list[str]:
        subtypes: set[str] = set()
        for root in self._discover_category_roots("entity"):
            entity_dir = root / entity_type
            if entity_dir.is_dir():
                for path in entity_dir.glob("*.yaml"):
                    subtypes.add(path.stem)
        return sorted(subtypes)

    def _discover_category_roots(self, category: str) -> list[Path]:
        roots: list[Path] = []
        if self._project_path is not None:
            eforge = self._project_path / ".eforge" / "schemas"
            for sub in (eforge / category, eforge / "_defaults" / category):
                if sub.is_dir():
                    roots.append(sub)
            if category == "domain":
                legacy = self.observations_schemas_dir
                if legacy is not None and legacy.is_dir():
                    roots.append(legacy)
        if (_PACKAGE_DEFAULTS / category).is_dir():
            roots.append(_PACKAGE_DEFAULTS / category)
        if category == "domain" and _LEGACY_PACKAGE_DEFAULTS.is_dir():
            roots.append(_LEGACY_PACKAGE_DEFAULTS)
        return roots

    def get_for_kind(
        self,
        kind: str,
        project_path: Path | None = None,
    ) -> TypeSchema | None:
        """
        Get TypeSchema for a manifest node kind.
        Uses KindSchemaMap to resolve category/domain/type.
        Returns None if kind has no mapped schema.

        Usage:
          registry.get_for_kind("module")
          → TypeSchema for code/module

          registry.get_for_kind("glove")
          → TypeSchema for tooling/glove (when mapped)
        """
        from forge.schemas.kind_map import KindSchemaMap

        path = project_path if project_path is not None else self._project_path
        kind_map = KindSchemaMap.load(path)
        ref = kind_map.resolve_schema_ref(kind)
        if ref is None:
            return None
        category, domain, type_name = ref
        return self.lookup(category, domain, type_name)

    def reload(self) -> None:
        self._cache.clear()
