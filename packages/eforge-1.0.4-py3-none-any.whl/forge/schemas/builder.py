from __future__ import annotations

import copy
from typing import Any

import click

from forge.schemas.models import PropertyDef, TypeSchema
from forge.ui.prompt import FieldDef, FieldOption, PromptEngine, PromptMode

_PROPERTY_TYPES = ["enum", "multi_enum", "string", "int", "bool", "list"]
_CATEGORIES = ["domain", "entity", "config"]


class SchemaBuilder:
    """Interactive schema construction via PromptEngine."""

    def __init__(self, engine: PromptEngine) -> None:
        self._engine = engine

    @staticmethod
    def from_dict(data: dict[str, Any]) -> TypeSchema:
        return TypeSchema.from_dict(data)

    @staticmethod
    def property(key: str, data: dict[str, Any]) -> PropertyDef:
        return PropertyDef.from_dict(key, data)

    @staticmethod
    def assemble(
        *,
        domain: str,
        type_name: str,
        category: str = "domain",
        description: str | None = None,
        inherits: str | None = None,
        properties: dict[str, dict[str, Any]] | None = None,
        prompts_order: list[str] | None = None,
    ) -> TypeSchema:
        props: dict[str, PropertyDef] = {}
        for key, raw in (properties or {}).items():
            props[key] = PropertyDef.from_dict(key, raw)
        return TypeSchema(
            domain=domain,
            type_name=type_name,
            category=category,
            description=description,
            inherits=inherits,
            properties=props,
            prompts_order=list(prompts_order or []),
        )

    def collect_meta(self, prefilled: dict[str, Any] | None = None) -> dict[str, Any]:
        base = dict(prefilled or {})
        fields = [
            FieldDef(
                key="domain",
                type="string",
                prompt="Schema domain (e.g. code, task)",
                required=True,
                default=base.get("domain"),
            ),
            FieldDef(
                key="type_name",
                type="string",
                prompt="Type name (e.g. function, framework)",
                required=True,
                default=base.get("type_name"),
            ),
            FieldDef(
                key="description",
                type="string",
                prompt="Description",
                required=False,
                default=base.get("description"),
            ),
            FieldDef(
                key="category",
                type="enum",
                prompt="Category",
                options=[FieldOption(value=c) for c in _CATEGORIES],
                required=True,
                default=base.get("category") or "domain",
            ),
            FieldDef(
                key="inherits",
                type="string",
                prompt="Inherits (domain/type or type, optional)",
                required=False,
                default=base.get("inherits"),
            ),
            FieldDef(
                key="prompts_order",
                type="list",
                prompt="Prompts order (comma-separated keys, optional)",
                required=False,
                default=base.get("prompts_order"),
            ),
        ]
        result = self._engine.run(fields)
        if not result.is_valid:
            raise result.errors[0]
        meta = dict(result.values)
        order = meta.get("prompts_order")
        if isinstance(order, str):
            meta["prompts_order"] = [
                p.strip() for p in order.split(",") if p.strip()
            ]
        elif order is None:
            meta["prompts_order"] = base.get("prompts_order") or []
        return meta

    def collect_option(
        self,
        prop_key: str,
        prefilled: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        base = dict(prefilled or {})
        fields = [
            FieldDef(
                key="value",
                type="string",
                prompt=f"Option value for {prop_key}",
                required=True,
                default=base.get("value"),
            ),
            FieldDef(
                key="label",
                type="string",
                prompt="Label (optional)",
                required=False,
                default=base.get("label"),
            ),
        ]
        result = self._engine.run(fields)
        if not result.is_valid:
            raise result.errors[0]
        option: dict[str, Any] = {
            "value": result.values["value"],
        }
        if result.values.get("label"):
            option["label"] = result.values["label"]

        exposes_more = click.confirm(
            "  Exposes more fields for this option? [y/n]",
            default=bool(base.get("exposes")),
        )
        if exposes_more:
            exposes: dict[str, Any] = dict(base.get("exposes") or {})
            while True:
                click.echo("  Exposed field (leave key empty to finish):")
                exposed = self.collect_property()
                key = exposed.get("key")
                if not key:
                    break
                exposes[key] = {
                    k: v for k, v in exposed.items() if k != "key"
                }
                exposes[key]["key"] = key
                if not click.confirm("  Add another exposed field? [y/n]", default=False):
                    break
            if exposes:
                option["exposes"] = exposes
        return option

    def collect_property(
        self,
        prefilled: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        base = dict(prefilled or {})
        fields = [
            FieldDef(
                key="key",
                type="string",
                prompt="Property key",
                required=not bool(base.get("key")),
                default=base.get("key"),
            ),
            FieldDef(
                key="type",
                type="enum",
                prompt="Property type",
                options=[FieldOption(value=t) for t in _PROPERTY_TYPES],
                required=True,
                default=base.get("type") or "string",
            ),
            FieldDef(
                key="required",
                type="bool",
                prompt="Required?",
                required=False,
                default=base.get("required", False),
            ),
            FieldDef(
                key="default",
                type="string",
                prompt="Default value (optional)",
                required=False,
                default=base.get("default"),
            ),
            FieldDef(
                key="prompt",
                type="string",
                prompt="Prompt text (optional)",
                required=False,
                default=base.get("prompt"),
            ),
            FieldDef(
                key="override",
                type="bool",
                prompt="Override parent property?",
                required=False,
                default=base.get("override", False),
            ),
        ]
        result = self._engine.run(fields)
        if not result.is_valid:
            raise result.errors[0]
        prop: dict[str, Any] = {
            "key": result.values.get("key") or base.get("key"),
            "type": result.values["type"],
        }
        if result.values.get("required"):
            prop["required"] = True
        if result.values.get("override"):
            prop["override"] = True
        if result.values.get("default") not in (None, ""):
            prop["default"] = result.values["default"]
        if result.values.get("prompt"):
            prop["prompt"] = result.values["prompt"]

        if prop["type"] in ("enum", "multi_enum"):
            options: list[dict[str, Any]] = list(base.get("options") or [])
            while True:
                if options:
                    vals = ", ".join(str(o.get("value")) for o in options)
                    click.echo(f"  Current options: {vals}")
                opt = self.collect_option(prop["key"])
                if opt.get("value"):
                    options.append(opt)
                if not click.confirm("  Add another option? [y/n]", default=False):
                    break
            prop["options"] = options
        return prop

    def collect_all_properties(
        self,
        existing: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        props = copy.deepcopy(existing or {})
        if props:
            click.echo("\n  Current properties:")
            for key in sorted(props):
                ptype = props[key].get("type", "?")
                click.echo(f"    {key} [{ptype}]")
        while click.confirm("\n  Add or replace a property? [y/n]", default=not props):
            prop = self.collect_property()
            key = prop.get("key")
            if not key:
                continue
            entry = {k: v for k, v in prop.items() if k != "key"}
            props[key] = entry
            if not click.confirm("  Add another property? [y/n]", default=False):
                break
        return props

    def build(self, prefilled: dict[str, Any] | None = None) -> dict[str, Any]:
        base = copy.deepcopy(prefilled or {})
        meta = self.collect_meta(
            prefilled={
                "domain": base.get("domain"),
                "type_name": base.get("type_name"),
                "description": base.get("description"),
                "category": base.get("category", "domain"),
                "inherits": base.get("inherits"),
                "prompts_order": base.get("prompts_order"),
            }
        )
        properties = self.collect_all_properties(existing=base.get("properties"))
        schema = {
            **meta,
            "properties": properties,
        }
        if schema.get("prompts_order"):
            order = schema["prompts_order"]
            if isinstance(order, list):
                schema["prompts_order"] = order
        else:
            schema["prompts_order"] = []
        return schema

    def diff(self, original: dict[str, Any], updated: dict[str, Any]) -> list[str]:
        lines: list[str] = []
        orig_props = original.get("properties") or {}
        new_props = updated.get("properties") or {}

        for key in ("domain", "type_name", "description", "category", "inherits"):
            if original.get(key) != updated.get(key):
                lines.append(
                    f"~ meta {key}: {original.get(key)!r} → {updated.get(key)!r}"
                )

        orig_order = original.get("prompts_order") or []
        new_order = updated.get("prompts_order") or []
        if orig_order != new_order:
            lines.append(f"~ prompts_order: {orig_order} → {new_order}")

        for key in sorted(set(orig_props) | set(new_props)):
            if key not in orig_props:
                ptype = new_props[key].get("type", "?")
                lines.append(f"+ property: {key} ({ptype})")
                continue
            if key not in new_props:
                lines.append(f"- property: {key}")
                continue
            opt_lines = _diff_property(orig_props[key], new_props[key], key)
            lines.extend(opt_lines)
        return lines


def _diff_property(old: dict, new: dict, key: str) -> list[str]:
    lines: list[str] = []
    if old.get("type") != new.get("type"):
        lines.append(f"~ {key}: type {old.get('type')!r} → {new.get('type')!r}")
    old_opts = {o.get("value"): o for o in old.get("options") or []}
    new_opts = {o.get("value"): o for o in new.get("options") or []}
    for val in sorted(set(old_opts) | set(new_opts)):
        if val not in old_opts:
            lines.append(f"~ {key}: added option {val!r}")
        elif val not in new_opts:
            lines.append(f"~ {key}: removed option {val!r}")
    for field in ("required", "default", "prompt", "override"):
        if old.get(field) != new.get(field):
            lines.append(f"~ {key}: {field} {old.get(field)!r} → {new.get(field)!r}")
    return lines
