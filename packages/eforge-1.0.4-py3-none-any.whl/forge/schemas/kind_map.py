from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

_DEFAULT_MAP_PATH = (
    Path(__file__).resolve().parent.parent / "_defaults" / "kind_schema_map.yaml"
)


class KindSchemaMap:
    """
    Maps manifest node kinds to TypeSchema category/domain/type.

    Used by:
      - graduation (validate DevNode against kind)
      - import-manifest (populate DevNode properties)
      - scaffold (drive template + prompt)
      - ObservationComponent (what schema is this entity?)
      - SchemaPrompt on manifest append

    Project-local override:
      .forge/kind_schema_map.yaml shadows _defaults.
    """

    def __init__(self, mappings: dict[str, str | None]) -> None:
        self._mappings = mappings

    @classmethod
    def load(cls, project_path: Path | None = None) -> KindSchemaMap:
        """
        Load map. Project-local .forge/kind_schema_map.yaml
        shadows _defaults if present.
        """
        data = yaml.safe_load(_DEFAULT_MAP_PATH.read_text(encoding="utf-8")) or {}
        mappings: dict[str, str | None] = {}
        for key, val in (data.get("mappings") or {}).items():
            mappings[str(key)] = _normalize_mapping_value(val)

        if project_path is not None:
            local = Path(project_path).expanduser().resolve() / ".forge" / "kind_schema_map.yaml"
            if local.is_file():
                local_data = yaml.safe_load(local.read_text(encoding="utf-8")) or {}
                for key, val in (local_data.get("mappings") or {}).items():
                    mappings[str(key)] = _normalize_mapping_value(val)

        return cls(mappings)

    def resolve_schema_ref(
        self, kind: str
    ) -> tuple[str, str, str] | None:
        """
        Returns (category, domain, type_name) for kind.
        Returns None if kind unknown or explicitly null.
        """
        val = self._mappings.get(kind)
        if val is None:
            return None
        parts = val.split("/")
        if len(parts) == 2:
            return ("domain", parts[0], parts[1])
        if len(parts) == 3:
            return (parts[0], parts[1], parts[2])
        return None

    def schema_for_kind(self, kind: str) -> tuple[str, str] | None:
        """
        Returns (domain, type_name) for domain-category mappings only.

        Entity-category mappings return None here; use resolve_schema_ref()
        or SchemaRegistry.get_for_kind().
        """
        ref = self.resolve_schema_ref(kind)
        if ref is None:
            return None
        category, domain, type_name = ref
        if category == "domain":
            return (domain, type_name)
        return None

    def kind_for_schema(
        self, domain: str, type_name: str, *, category: str = "domain"
    ) -> str | None:
        """
        Reverse lookup — find kind for a schema.
        Returns first match (some schemas map to multiple kinds).
        """
        target = f"{category}/{domain}/{type_name}"
        target_domain = f"{domain}/{type_name}"
        for kind, val in self._mappings.items():
            if val is None:
                continue
            if val == target or val == target_domain:
                return kind
        return None

    def all_kinds(self) -> list[str]:
        return list(self._mappings.keys())

    def unmapped_kinds(self) -> list[str]:
        """Kinds with null schema — documented gaps."""
        return [k for k, v in self._mappings.items() if v is None]

    def mapped_kinds(self) -> list[str]:
        """Kinds with a TypeSchema."""
        return [k for k, v in self._mappings.items() if v is not None]


def _normalize_mapping_value(val: Any) -> str | None:
    if val is None:
        return None
    if isinstance(val, str):
        stripped = val.strip()
        if not stripped or stripped.lower() == "null":
            return None
        return stripped
    return None
