from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from forge.observations.errors import ObservationError
from forge.schemas.models import TypeSchema
from forge.schemas.registry import SchemaRegistry


class SchemaValidator:
    """Validate schema dicts and yaml files."""

    def __init__(self, registry: SchemaRegistry | None = None) -> None:
        self._registry = registry

    def validate(
        self,
        schema_dict: dict[str, Any],
        registry: SchemaRegistry | None = None,
    ) -> list[str]:
        errors: list[str] = []
        reg = registry or self._registry

        if not isinstance(schema_dict, dict):
            return ["schema root must be a mapping"]

        domain = schema_dict.get("domain")
        if not domain or not str(domain).strip():
            errors.append("domain is required and must be non-empty")
        type_name = schema_dict.get("type_name") or schema_dict.get("type")
        if not type_name or not str(type_name).strip():
            errors.append("type_name is required and must be non-empty")
        elif " " in str(type_name):
            errors.append("type_name must not contain spaces")

        category = schema_dict.get("category") or "domain"
        if category not in ("domain", "entity", "config"):
            errors.append("category must be domain, entity, or config")

        properties = schema_dict.get("properties")
        if properties is not None and not isinstance(properties, dict):
            errors.append("properties must be a mapping if present")

        if properties:
            for key, prop in properties.items():
                if not isinstance(prop, dict):
                    errors.append(f"property {key!r} must be a mapping")
                    continue
                if "type" not in prop:
                    errors.append(f"property {key!r} missing 'type'")

        prompts_order = schema_dict.get("prompts_order") or []
        if prompts_order and isinstance(properties, dict):
            for key in prompts_order:
                if key not in properties:
                    errors.append(
                        f"prompts_order key {key!r} not found in properties"
                    )

        if errors:
            return errors

        try:
            schema = TypeSchema.from_dict(schema_dict)
            schema.validate_structure()
        except ObservationError as exc:
            code = exc.code.value if hasattr(exc.code, "value") else str(exc.code)
            errors.append(f"{code}: {exc.message}")
        except Exception as exc:
            errors.append(str(exc))

        if reg is not None and not errors:
            try:
                schema = TypeSchema.from_dict(schema_dict)
                schema.merged_properties(reg)
            except ObservationError as exc:
                code = exc.code.value if hasattr(exc.code, "value") else str(exc.code)
                errors.append(f"{code}: {exc.message}")
                if exc.context.get("cycle"):
                    errors.append(f"  cycle: {exc.context.get('cycle')}")
            except Exception as exc:
                errors.append(str(exc))

        return errors

    def validate_file(self, path: Path) -> list[str]:
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            return [f"OBS-011: cannot read file: {exc}"]
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            return [f"OBS-011: yaml parse failure: {exc}"]
        if not isinstance(data, dict):
            return ["OBS-011: root must be a mapping"]
        msgs = self.validate(data, registry=self._registry)
        return [f"OBS-011: {path}: {m}" if not m.startswith("OBS-") else m for m in msgs]

    def validate_properties(
        self,
        schema: TypeSchema,
        props: dict,
        *,
        use_merged: bool = True,
    ) -> list[str]:
        registry = self._registry if use_merged else None
        return schema.validate_properties(props, registry=registry)

    def validate_structure(self, schema: TypeSchema) -> None:
        schema.validate_structure()
