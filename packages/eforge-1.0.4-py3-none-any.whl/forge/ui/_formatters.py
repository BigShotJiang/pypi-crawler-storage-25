from __future__ import annotations

from typing import Any

OPTION_THRESHOLD = 4


def _pad(indent: int) -> str:
    return " " * indent


def numbered_list(
    options: list[Any],
    selected: str | None = None,
    indent: int = 0,
    default_value: str | None = None,
) -> str:
    lines: list[str] = []
    prefix = _pad(indent)
    for i, opt in enumerate(options, start=1):
        label = opt.label or opt.value
        marker = ""
        if selected and opt.value == selected:
            marker = " *"
        default_note = ""
        if default_value and opt.value == default_value:
            default_note = " (default)"
        lines.append(f"{prefix}{i}. {label}{default_note}{marker}")
    return "\n".join(lines)


def inline_options(options: list[Any]) -> str:
    labels = [o.label or o.value for o in options]
    return "[" + " / ".join(labels) + "]"


def field_prompt_line(field: Any, indent: int = 0) -> str:
    pad = _pad(indent)
    if field.type in ("enum", "multi_enum") and field.options:
        if len(field.options) <= OPTION_THRESHOLD:
            opts = inline_options(field.options)
            default_note = ""
            if field.default is not None:
                default_note = f" [default: {field.default}]"
            return f"{pad}? {field.prompt} {opts}{default_note}: "
        return f"{pad}? {field.prompt}:"
    default_note = ""
    if field.default is not None:
        default_note = f" [default: {field.default}]"
    return f"{pad}? {field.prompt}{default_note}: "
