"""Rich-free display helpers for forge node CLI (strings only, no observations imports)."""

from __future__ import annotations

import json
from typing import Any


def _line(content: str = "") -> str:
    return f"│ {content}"


def _top(title: str) -> str:
    inner = f"─ {title} "
    return f"┌{inner}"


def _bottom() -> str:
    return "└"


def node_card(node: dict[str, Any]) -> str:
    name = node.get("name") or node.get("id") or "?"
    lines = [
        _top(name),
        _line(f"domain: {node.get('domain') or '-':<14} type: {node.get('type') or '-'}"),
        _line(
            f"status: {node.get('status') or '-':<14} marked: {node.get('marked', False)}"
        ),
    ]
    src = node.get("source_file")
    if src:
        line_no = node.get("source_line")
        loc = f"{src}:{line_no}" if line_no is not None else str(src)
        lines.append(_line(f"file: {loc}"))
    tags = node.get("tags") or []
    if tags:
        for tag in tags:
            lines.append(_line(f"tag: {tag}"))
    props = node.get("properties") or {}
    if props:
        lines.append(_line("properties:"))
        for key, val in props.items():
            lines.append(_line(f"  {key}: {val}"))
    notes = node.get("notes") or []
    links = node.get("links") or []
    lines.append(_line(f"links: {len(links)}    notes: {len(notes)}"))
    lines.append(_bottom())
    return "\n".join(lines)


def node_inline(node: dict[str, Any]) -> str:
    parts = [
        f"name: {node.get('name')}",
        f"domain: {node.get('domain')}",
        f"type: {node.get('type')}",
        f"status: {node.get('status')}",
        f"marked: {node.get('marked')}",
    ]
    if node.get("source_file"):
        parts.append(f"source_file: {node.get('source_file')}")
    if node.get("source_line") is not None:
        parts.append(f"source_line: {node.get('source_line')}")
    tags = node.get("tags") or []
    if tags:
        parts.append(f"tags: {', '.join(tags)}")
    return "\n".join(parts)


def node_table(
    nodes: list[dict[str, Any]],
    columns: list[str] | None = None,
) -> str:
    cols = columns or ["name", "domain", "type", "status", "marked", "tags"]
    if not nodes:
        return "  (no nodes)"
    widths: dict[str, int] = {c: len(c) for c in cols}
    rows: list[list[str]] = []
    for node in nodes:
        row = []
        for col in cols:
            val = node.get(col)
            if col == "tags" and isinstance(val, list):
                text = ", ".join(val)
            elif col == "marked":
                text = str(bool(val))
            else:
                text = str(val) if val is not None else ""
            widths[col] = max(widths[col], len(text))
            row.append(text)
        rows.append(row)
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    sep = "  ".join("-" * widths[c] for c in cols)
    body = ["  ".join(row[i].ljust(widths[cols[i]]) for i in range(len(cols))) for row in rows]
    return "\n".join([header, sep, *body])


def link_tree(
    node: dict[str, Any],
    links: list[dict[str, Any]],
    direction: str = "from",
) -> str:
    root = node.get("name") or node.get("id") or "?"
    lines = [root]
    for link in links:
        rel = link.get("rel") or "rel"
        target = link.get("to") or link.get("to_id") or "?"
        note = link.get("note")
        branch = f"├── {rel} → {target}"
        if note:
            branch = f"{branch}  ({note})"
        if direction == "to":
            from_name = link.get("from_name") or link.get("from_id") or "?"
            branch = f"├── {from_name} [{rel}]"
        lines.append(branch)
    if len(lines) == 1:
        lines.append("  (no links)")
    return "\n".join(lines)


def properties_table(properties: dict[str, Any]) -> str:
    if not properties:
        return "  (no properties)"
    lines = ["properties:"]
    for key, val in properties.items():
        lines.append(f"  {key}: {val}")
    return "\n".join(lines)


def _hint_lines(hint: str) -> list[str]:
    parts = hint.splitlines()
    if not parts:
        return []
    lines = [f"  → hint: {parts[0]}"]
    indent = "          "
    for part in parts[1:]:
        lines.append(f"{indent}{part}")
    return lines


def error_card(entry: dict[str, Any]) -> str:
    code = entry.get("code") or "?"
    name = entry.get("name") or ""
    lines = [
        _top(f"{code} {name}".strip()),
        _line(f"subsystem: {entry.get('subsystem') or '-'}"),
        _line(f"description: {entry.get('description') or ''}"),
    ]
    context_fields = entry.get("context_fields") or []
    if context_fields:
        if isinstance(context_fields, list):
            fields_text = ", ".join(str(f) for f in context_fields)
        else:
            fields_text = str(context_fields)
        lines.append(_line(f"context fields: {fields_text}"))
    lines.append(_bottom())
    hint = entry.get("hint")
    if hint:
        lines.extend(_hint_lines(str(hint)))
    return "\n".join(lines)


def graph_ascii(root: str, edges: list[tuple[str, str, str]], depth: int = 2) -> str:
    """Render a small ASCII subgraph: (parent, rel, child) tuples."""
    children: dict[str, list[tuple[str, str]]] = {}
    for parent, rel, child in edges:
        children.setdefault(parent, []).append((rel, child))

    lines: list[str] = [root]

    def walk(name: str, level: int, prefix: str) -> None:
        if level >= depth:
            return
        items = children.get(name, [])
        for i, (rel, child) in enumerate(items):
            connector = "└──" if i == len(items) - 1 else "├──"
            lines.append(f"{prefix}{connector} [{rel}] → {child}")
            ext = "    " if connector == "└──" else "│   "
            walk(child, level + 1, prefix + ext)

    walk(root, 0, "")
    return "\n".join(lines)


def node_context_section(ctx: Any) -> str:
    """
    Render observation context for any command.
    Accepts NodeContext or dict. Plain text only.
    """
    try:
        if ctx is None:
            return _node_context_empty()

        if isinstance(ctx, dict):
            has_obs = bool(ctx.get("has_observation") or ctx.get("dev_node"))
            if not has_obs:
                return _node_context_empty()
            name = (
                (ctx.get("dev_node") or {}).get("name")
                if isinstance(ctx.get("dev_node"), dict)
                else None
            ) or ctx.get("node_id") or "?"
            status = ctx.get("status") or (
                (ctx.get("dev_node") or {}).get("status")
                if isinstance(ctx.get("dev_node"), dict)
                else "observed"
            )
            lines = [
                "",
                "Observation:",
                f"  status: {status}",
            ]
            props = ctx.get("schema_properties") or {}
            if props:
                lines.append("  properties:")
                for key, val in props.items():
                    lines.append(f"    {key}: {val}")
            notes = ctx.get("notes") or []
            if notes:
                lines.append("  notes:")
                for note in notes[:5]:
                    lines.append(f"    · {note}")
            tags = ctx.get("tags") or []
            if tags:
                lines.append(f"  tags: {', '.join(str(t) for t in tags)}")
            err = ctx.get("error_stats") or {}
            if err:
                lines.append("  recent errors:")
                for code, count in sorted(
                    err.items(), key=lambda x: x[1], reverse=True
                )[:3]:
                    lines.append(f"    {code}: {count}x")
            tasks = ctx.get("related_tasks") or []
            if tasks:
                lines.append("  related tasks:")
                for tid in tasks[:3]:
                    lines.append(f"    · {tid}")
            lines.append(f"  → eforge node show '{name}'")
            return "\n".join(lines)

        has_obs = getattr(ctx, "has_observation", False)
        if not has_obs:
            return _node_context_empty()

        dev = ctx.dev_node
        name = dev.name if dev is not None else ctx.node_id
        status = dev.status if dev is not None else "observed"
        lines = [
            "",
            "Observation:",
            f"  status: {status}",
        ]
        if getattr(ctx, "is_graduated", False):
            lines.append("  graduated: yes")
        if ctx.schema_properties:
            lines.append("  properties:")
            for key, val in ctx.schema_properties.items():
                lines.append(f"    {key}: {val}")
        if ctx.notes:
            lines.append("  notes:")
            for note in ctx.notes[:5]:
                lines.append(f"    · {note}")
        if ctx.tags:
            lines.append(f"  tags: {', '.join(ctx.tags)}")
        if ctx.observation_links:
            lines.append(f"  links: {ctx.observation_links}")
        if ctx.error_stats:
            lines.append("  recent errors:")
            for code, count in sorted(
                ctx.error_stats.items(), key=lambda x: x[1], reverse=True
            )[:3]:
                lines.append(f"    {code}: {count}x")
        if ctx.related_tasks:
            lines.append("  related tasks:")
            for tid in ctx.related_tasks[:3]:
                lines.append(f"    · {tid}")
        lines.append(f"  → eforge node show '{name}'")
        return "\n".join(lines)
    except Exception:
        return _node_context_empty()


def _node_context_empty() -> str:
    return "\n".join(
        [
            "",
            "Observation:",
            "  No observation node linked",
            "  → eforge node add <name> --kind <domain/type>",
            "  → forge manifest add <node_id> (creates DevNode)",
        ]
    )


def format_tags_json(tags: Any) -> str:
    if isinstance(tags, str):
        try:
            tags = json.loads(tags)
        except json.JSONDecodeError:
            return tags
    if isinstance(tags, list):
        return ", ".join(str(t) for t in tags)
    return str(tags)
