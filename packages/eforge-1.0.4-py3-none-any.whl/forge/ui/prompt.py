from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from forge.ui._formatters import OPTION_THRESHOLD, field_prompt_line, numbered_list
from forge.ui.errors import UI_001, UI_002, UI_004, default_prompt_error_factory


class PromptMode(str, Enum):
    INTERACTIVE = "interactive"
    BATCH = "batch"
    SILENT = "silent"


@dataclass
class FieldOption:
    value: str
    label: str | None = None
    exposes: list[FieldDef] = field(default_factory=list)


@dataclass
class FieldDef:
    key: str
    type: str
    prompt: str
    options: list[FieldOption] = field(default_factory=list)
    required: bool = False
    default: Any = None
    multi: bool = False
    validate: Callable[[Any], str | None] | None = None

    def get_option(self, value: str) -> FieldOption | None:
        if not hasattr(self, "_option_map"):
            object.__setattr__(self, "_option_map", {o.value: o for o in self.options})
        return self._option_map.get(value)

    def exposes_for(self, value: str) -> list[FieldDef]:
        opt = self.get_option(value)
        return opt.exposes if opt else []


@dataclass
class PromptResult:
    values: dict[str, Any] = field(default_factory=dict)
    skipped: list[str] = field(default_factory=list)
    errors: list[Exception] = field(default_factory=list)

    def get(self, key: str, default: Any = None) -> Any:
        return self.values.get(key, default)

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0


def _default_input_fn(prompt: str) -> str:
    return input(prompt)


class PromptEngine:
    def __init__(
        self,
        mode: PromptMode = PromptMode.INTERACTIVE,
        prefilled: dict[str, Any] | None = None,
        indent: int = 0,
        input_fn: Callable[[str], str] | None = None,
        output_fn: Callable[[str], None] | None = None,
        error_factory: Callable[[str, str, dict[str, Any]], Exception] | None = None,
    ) -> None:
        self.mode = mode
        self._prefilled = dict(prefilled or {})
        self.indent = indent
        self._input_fn = input_fn or _default_input_fn
        self._output_fn = output_fn or print
        self.error_factory = error_factory or default_prompt_error_factory

    def _make_error(
        self, code: str, message: str, context: dict[str, Any]
    ) -> Exception:
        return self.error_factory(code, message, context)

    def run(self, fields: list[FieldDef]) -> PromptResult:
        values: dict[str, Any] = dict(self._prefilled)
        skipped: list[str] = []
        errors: list[Exception] = []
        try:
            for field_def in fields:
                self._collect_field(field_def, values, skipped, errors)
        except KeyboardInterrupt as exc:
            raise self._make_error(
                UI_004, "Prompt aborted by user", {}
            ) from exc
        return PromptResult(values=values, skipped=skipped, errors=errors)

    def _collect_field(
        self,
        field_def: FieldDef,
        values: dict[str, Any],
        skipped: list[str],
        errors: list[Exception],
    ) -> None:
        if field_def.key in self._prefilled:
            value = self._prefilled[field_def.key]
            enum_err = self._validate_prefilled_enum(field_def, value)
            if enum_err is not None:
                errors.append(enum_err)
                return
            values[field_def.key] = value
            skipped.append(field_def.key)
            self._collect_exposes(field_def, value, values, skipped, errors)
            return

        value, field_errors, was_skipped = self._resolve_value(field_def)
        if field_errors:
            errors.extend(field_errors)
            return
        if was_skipped:
            skipped.append(field_def.key)
        values[field_def.key] = value
        self._collect_exposes(field_def, value, values, skipped, errors)

    def _validate_prefilled_enum(
        self, field_def: FieldDef, value: Any
    ) -> Exception | None:
        if field_def.type not in ("enum", "multi_enum") or not field_def.options:
            return None
        allowed = [o.value for o in field_def.options]
        if field_def.multi or field_def.type == "multi_enum":
            items = value if isinstance(value, list) else [value]
            for item in items:
                if field_def.get_option(str(item)) is None:
                    return self._make_error(
                        UI_002,
                        f"Value {item!r} not in options for {field_def.key!r}",
                        {
                            "field_key": field_def.key,
                            "value": item,
                            "valid_options": allowed,
                        },
                    )
            return None
        if field_def.get_option(str(value)) is None:
            return self._make_error(
                UI_002,
                f"Value {value!r} not in options for {field_def.key!r}",
                {
                    "field_key": field_def.key,
                    "value": value,
                    "valid_options": allowed,
                },
            )
        return None

    def _collect_exposes(
        self,
        field_def: FieldDef,
        value: Any,
        values: dict[str, Any],
        skipped: list[str],
        errors: list[Exception],
    ) -> None:
        if field_def.type not in ("enum", "multi_enum"):
            return
        if field_def.type == "multi_enum" or field_def.multi:
            if isinstance(value, list):
                exposed: list[FieldDef] = []
                for item in value:
                    exposed.extend(field_def.exposes_for(str(item)))
                if exposed:
                    nested = PromptEngine(
                        mode=self.mode,
                        prefilled={**self._prefilled, **values},
                        indent=self.indent + 2,
                        input_fn=self._input_fn,
                        output_fn=self._output_fn,
                        error_factory=self.error_factory,
                    )
                    nested_result = nested.run(exposed)
                    values.update(nested_result.values)
                    skipped.extend(nested_result.skipped)
                    errors.extend(nested_result.errors)
            return

        exposed_fields = field_def.exposes_for(str(value))
        if not exposed_fields:
            return
        nested = PromptEngine(
            mode=self.mode,
            prefilled={**self._prefilled, **values},
            indent=self.indent + 2,
            input_fn=self._input_fn,
            output_fn=self._output_fn,
            error_factory=self.error_factory,
        )
        nested_result = nested.run(exposed_fields)
        values.update(nested_result.values)
        skipped.extend(nested_result.skipped)
        errors.extend(nested_result.errors)

    def _resolve_value(
        self, field_def: FieldDef
    ) -> tuple[Any, list[Exception], bool]:
        if self.mode == PromptMode.BATCH:
            return self._resolve_batch(field_def)
        if self.mode == PromptMode.SILENT:
            return self._resolve_silent(field_def)
        return self._resolve_interactive(field_def)

    def _resolve_batch(self, field_def: FieldDef) -> tuple[Any, list[Exception], bool]:
        if field_def.default is not None:
            return field_def.default, [], True
        if field_def.required:
            return None, [
                self._make_error(
                    UI_001,
                    f"Required field {field_def.key!r} not provided in batch mode",
                    {"field_key": field_def.key, "mode": PromptMode.BATCH.value},
                )
            ], False
        return None, [], True

    def _resolve_silent(self, field_def: FieldDef) -> tuple[Any, list[Exception], bool]:
        if field_def.key in self._prefilled:
            value = self._prefilled[field_def.key]
            enum_err = self._validate_prefilled_enum(field_def, value)
            if enum_err is not None:
                return None, [enum_err], False
            return value, [], True
        if field_def.default is not None:
            return field_def.default, [], True
        if field_def.required:
            return None, [
                self._make_error(
                    UI_001,
                    f"Required field {field_def.key!r} not provided in silent mode",
                    {"field_key": field_def.key, "mode": PromptMode.SILENT.value},
                )
            ], False
        return None, [], True

    def _resolve_interactive(
        self, field_def: FieldDef
    ) -> tuple[Any, list[Exception], bool]:
        while True:
            self._display_field_header(field_def)
            try:
                value = self._read_field_value(field_def)
            except KeyboardInterrupt as exc:
                raise self._make_error(
                    UI_004, "Prompt aborted by user", {}
                ) from exc
            if value is _SENTINEL_SKIP:
                if field_def.default is not None:
                    value = field_def.default
                elif field_def.required:
                    self._output_fn("  Required. Please enter a value.")
                    continue
                else:
                    return None, [], True

            if field_def.validate is not None:
                err_msg = field_def.validate(value)
                if err_msg:
                    self._output_fn(f"  {err_msg}")
                    continue
            return value, [], False

    def _read_field_value(self, field_def: FieldDef) -> Any:
        if field_def.type == "enum" and not field_def.multi:
            return self._prompt_enum(field_def)
        if field_def.type == "multi_enum" or (field_def.type == "enum" and field_def.multi):
            return self._prompt_multi_enum(field_def)
        if field_def.type == "string":
            return self._prompt_string(field_def)
        if field_def.type == "bool":
            return self._prompt_bool(field_def)
        if field_def.type == "int":
            return self._prompt_int(field_def)
        if field_def.type == "list":
            return self._prompt_list(field_def)
        return self._prompt_string(field_def)

    def _display_field_header(self, field_def: FieldDef) -> None:
        if field_def.type in ("enum", "multi_enum") and field_def.options:
            if len(field_def.options) > OPTION_THRESHOLD:
                self._output_fn(field_prompt_line(field_def, self.indent).rstrip())
                default_str = str(field_def.default) if field_def.default is not None else None
                self._output_fn(
                    numbered_list(
                        field_def.options,
                        indent=self.indent + 2,
                        default_value=default_str,
                    )
                )
                return
        self._output_fn(field_prompt_line(field_def, self.indent).rstrip())

    def _prompt_enum(self, field_def: FieldDef) -> Any:
        default_str = (
            str(field_def.default) if field_def.default is not None else None
        )
        prompt = field_prompt_line(field_def, self.indent)
        if field_def.options and len(field_def.options) > OPTION_THRESHOLD:
            prompt = f"{_pad(self.indent)}? {field_def.prompt} "
        while True:
            if field_def.options and len(field_def.options) > OPTION_THRESHOLD:
                self._display_field_header(field_def)
                raw = self._input_fn(
                    f"{_pad(self.indent)}Choice"
                    + (f" [default: {default_str}]" if default_str else "")
                    + ": "
                ).strip()
            else:
                raw = self._input_fn(prompt).strip()

            if not raw:
                if default_str is not None:
                    return default_str
                if not field_def.required:
                    return _SENTINEL_SKIP
                continue

            resolved = self._resolve_enum_token(raw, field_def)
            if resolved is not None:
                return resolved
            self._output_fn("  Invalid choice. Enter a number or option value.")

    def _resolve_enum_token(self, raw: str, field_def: FieldDef) -> str | None:
        if not field_def.options:
            return raw
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(field_def.options):
                return field_def.options[idx].value
        lower = raw.lower()
        for opt in field_def.options:
            if opt.value.lower() == lower:
                return opt.value
            label = (opt.label or "").lower()
            if label and label == lower:
                return opt.value
        return None

    def _prompt_multi_enum(self, field_def: FieldDef) -> list[str]:
        default_list = field_def.default if isinstance(field_def.default, list) else []
        while True:
            self._display_field_header(field_def)
            raw = self._input_fn(
                f"{_pad(self.indent)}Choices (comma-separated numbers or values): "
            ).strip()
            if not raw:
                if default_list:
                    return list(default_list)
                if not field_def.required:
                    return []
                continue
            parts = [p.strip() for p in raw.split(",") if p.strip()]
            resolved: list[str] = []
            invalid = False
            for part in parts:
                token = self._resolve_enum_token(part, field_def)
                if token is None:
                    invalid = True
                    break
                resolved.append(token)
            if invalid:
                self._output_fn("  Invalid choice. Use comma-separated numbers or values.")
                continue
            return resolved

    def _prompt_string(self, field_def: FieldDef) -> Any:
        raw = self._input_fn(field_prompt_line(field_def, self.indent)).strip()
        if not raw:
            if field_def.default is not None:
                return field_def.default
            if field_def.required:
                return _SENTINEL_SKIP
            return ""
        return raw

    def _prompt_bool(self, field_def: FieldDef) -> Any:
        default_note = ""
        if field_def.default is not None:
            default_note = f" [default: {'y' if field_def.default else 'n'}]"
        while True:
            raw = self._input_fn(
                f"{_pad(self.indent)}? {field_def.prompt} [y/n]{default_note}: "
            ).strip()
            if not raw:
                if field_def.default is not None:
                    return bool(field_def.default)
                if not field_def.required:
                    return _SENTINEL_SKIP
                continue
            lower = raw.lower()
            if lower in ("y", "yes"):
                return True
            if lower in ("n", "no"):
                return False
            self._output_fn("  Enter y or n.")

    def _prompt_int(self, field_def: FieldDef) -> Any:
        while True:
            raw = self._input_fn(field_prompt_line(field_def, self.indent)).strip()
            if not raw:
                if field_def.default is not None:
                    return int(field_def.default)
                if not field_def.required:
                    return _SENTINEL_SKIP
                continue
            try:
                return int(raw)
            except ValueError:
                self._output_fn("  Enter a valid integer.")

    def _prompt_list(self, field_def: FieldDef) -> list[str]:
        raw = self._input_fn(
            f"{_pad(self.indent)}? {field_def.prompt} (comma-separated, empty to finish): "
        ).strip()
        if not raw:
            if isinstance(field_def.default, list):
                return list(field_def.default)
            if field_def.default is not None:
                return [str(field_def.default)]
            return []
        return [p.strip() for p in raw.split(",") if p.strip()]


_SENTINEL_SKIP = object()


def _pad(indent: int) -> str:
    return " " * indent
