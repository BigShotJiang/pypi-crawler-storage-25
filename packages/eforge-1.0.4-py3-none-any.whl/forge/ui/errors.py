"""
UI prompt errors and registry entries (UI-001..UI-004).

Aligned with forge.core.errors.ForgeError fields; uses string subsystem codes.
No imports from the observations package.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from forge.errors import ErrorEntry, ErrorRegistry

UI_001 = "UI-001"
UI_002 = "UI-002"
UI_003 = "UI-003"
UI_004 = "UI-004"


@dataclass
class PromptError(Exception):
    """Prompt-layer error (ForgeError-aligned; string code per subsystem taxonomy)."""

    code: str
    message: str
    hint: str = ""
    layer: str = "input"
    recoverable: bool = True
    context: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "layer": self.layer,
            "message": self.message,
            "hint": self.hint,
            "recoverable": self.recoverable,
            "context": self.context,
        }

    def model_dump_json(self, indent: int | None = None) -> str:
        return json.dumps(self.to_dict(), indent=indent)


UI_CODES = [
    ErrorEntry(
        code=UI_001,
        name="RequiredFieldMissing",
        description="Required field not provided in batch or silent mode",
        hint=(
            "Provide the value as a CLI argument, or run "
            "interactively without --yes to be prompted"
        ),
        subsystem="ui",
        context_fields=["field_key", "mode"],
    ),
    ErrorEntry(
        code=UI_002,
        name="InvalidEnumValue",
        description="Value not in allowed options for enum field",
        hint=(
            "Run interactively to see available options, "
            "or check the schema for valid values"
        ),
        subsystem="ui",
        context_fields=["field_key", "value", "valid_options"],
    ),
    ErrorEntry(
        code=UI_003,
        name="ValidationFailed",
        description="Field value failed custom validation",
        hint="Check the validation rule for this field",
        subsystem="ui",
        context_fields=["field_key", "value", "validation_message"],
    ),
    ErrorEntry(
        code=UI_004,
        name="PromptAborted",
        description="Interactive prompt was cancelled by user",
        hint="Re-run the command to try again",
        subsystem="ui",
        context_fields=[],
    ),
]

for _entry in UI_CODES:
    ErrorRegistry.register(_entry)


def default_prompt_error_factory(
    code: str, message: str, context: dict[str, Any]
) -> PromptError:
    entry = ErrorRegistry.lookup(code)
    return PromptError(
        code=code,
        message=message,
        hint=entry.hint if entry and entry.hint else "",
        context=context,
    )
