"""eforge CLI entry point — devtools-only observation graph."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from forge.cli_engine import CLIEngine
from forge.devtools import __version__


def main() -> None:
    commands_dir = Path(__file__).resolve().parent / "commands"
    CLIEngine.discover(str(commands_dir), "forge.devtools.commands")
    cli = CLIEngine.build(
        "devtools",
        "eforge",
        __version__,
        "Codebase observation graph and mapping tools",
    )
    try:
        cli(prog_name="eforge")
    except click.exceptions.Exit as exc:
        raise SystemExit(exc.code) from exc
    except SystemExit:
        raise
    except Exception as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
