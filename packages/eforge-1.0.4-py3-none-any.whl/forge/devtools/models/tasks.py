from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml


class TaskKind(str, Enum):
    FRAMEWORK = "framework"
    PERSONAL = "personal"
    NEW_USER = "new-user"


class TaskPriority(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class TaskStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in-progress"
    DONE = "done"
    ARCHIVED = "archived"


@dataclass
class ForgeTask:
    id: str
    title: str
    kind: TaskKind
    priority: TaskPriority
    status: TaskStatus
    created: str
    note: str = ""
    project: str = ""
    tags: list[str] = field(default_factory=list)
    recurrence: str | None = None
    affects_nodes: list[str] = field(default_factory=list)
    properties: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {
            "id": self.id,
            "title": self.title,
            "kind": self.kind.value,
            "priority": self.priority.value,
            "status": self.status.value,
            "created": self.created,
            "note": self.note,
            "project": self.project,
            "tags": list(self.tags),
            "recurrence": self.recurrence,
            "affects_nodes": list(self.affects_nodes),
        }
        if self.properties:
            data["properties"] = dict(self.properties)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ForgeTask":
        return cls(
            id=data["id"],
            title=data["title"],
            kind=TaskKind(data.get("kind", "framework")),
            priority=TaskPriority(data.get("priority", "medium")),
            status=TaskStatus(data.get("status", "open")),
            created=data.get("created", ""),
            note=data.get("note", ""),
            project=data.get("project", ""),
            tags=list(data.get("tags") or []),
            recurrence=data.get("recurrence"),
            affects_nodes=list(data.get("affects_nodes") or []),
            properties=dict(data.get("properties") or {}),
        )

    @classmethod
    def from_file(cls, path: Path) -> "ForgeTask":
        raw = yaml.safe_load(path.read_text()) or {}
        return cls.from_dict(raw)

    def save(self, tasks_dir: Path) -> None:
        tasks_dir.mkdir(parents=True, exist_ok=True)
        path = tasks_dir / f"{self.id}.yaml"
        with open(path, "w") as f:
            yaml.dump(
                self.to_dict(),
                f,
                default_flow_style=False,
                sort_keys=False,
            )

    def update(self, tasks_dir: Path, **kwargs: Any) -> None:
        for key, val in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, val)
        self.save(tasks_dir)


def load_tasks(
    tasks_dir: Path,
    kind: TaskKind | None = None,
    status: TaskStatus | None = None,
    priority: TaskPriority | None = None,
) -> list[ForgeTask]:
    if not tasks_dir.exists():
        return []
    tasks = []
    for f in sorted(tasks_dir.glob("*.yaml")):
        try:
            t = ForgeTask.from_file(f)
            if kind and t.kind != kind:
                continue
            if status and t.status != status:
                continue
            if priority and t.priority != priority:
                continue
            tasks.append(t)
        except Exception:
            continue
    return tasks


def next_task_id(tasks_dir: Path) -> str:
    existing = list(tasks_dir.glob("TASK-*.yaml"))
    if not existing:
        return "TASK-001"
    nums = []
    for f in existing:
        try:
            n = int(f.stem.split("-")[1])
            nums.append(n)
        except (IndexError, ValueError):
            continue
    next_n = max(nums) + 1 if nums else 1
    return f"TASK-{next_n:03d}"
