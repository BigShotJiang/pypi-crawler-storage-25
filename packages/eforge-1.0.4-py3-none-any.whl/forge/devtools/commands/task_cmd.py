"""eforge task — manage project tasks in .forge/tasks/."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import click
from click.core import ParameterSource

from forge.cli_engine import (
    OutputFormat,
    coerce_output_format,
    output_format_options,
    print_result,
    project_path_option,
    yes_option,
)
from forge.observations.path_utils import resolve_project_path
from forge.devtools.models.tasks import (
    ForgeTask,
    TaskKind,
    TaskPriority,
    TaskStatus,
    load_tasks,
    next_task_id,
)
from forge.observations.prompt import SchemaPrompt
from forge.schemas.registry import SchemaRegistry
from forge.ui.display import properties_table
from forge.ui.prompt import PromptMode

_TASK_CLICK_FIELDS = frozenset({"title", "priority", "note", "status"})


def _project_root(project_path: str) -> Path:
    root = resolve_project_path(project_path)
    if root is None:
        root = Path(project_path).expanduser().resolve()
    return root


def _tasks_dir(project_path: str) -> Path:
    return _project_root(project_path) / ".forge" / "tasks"


def _filters_explicit(ctx: click.Context) -> bool:
    for name in ("kind", "status", "priority"):
        if ctx.get_parameter_source(name) != ParameterSource.DEFAULT:
            return True
    return False


def _render_task_list(tasks: list[ForgeTask]) -> None:
    if not tasks:
        click.echo("\n  No tasks found.\n")
        return

    priority_order = {
        TaskPriority.HIGH: 0,
        TaskPriority.MEDIUM: 1,
        TaskPriority.LOW: 2,
    }
    tasks = sorted(tasks, key=lambda t: priority_order.get(t.priority, 9))

    click.echo(f"\n  Tasks ({len(tasks)})\n")

    icons = {
        TaskPriority.HIGH: "!",
        TaskPriority.MEDIUM: "-",
        TaskPriority.LOW: " ",
    }

    for t in tasks:
        icon = icons.get(t.priority, " ")
        click.echo(f"  [{icon}] {t.id}  {t.title[:55]}")
        click.echo(
            f"      {t.kind.value}  {t.priority.value}  {t.status.value}"
        )
        if t.note:
            click.echo(f"      {t.note[:70]}")
        click.echo("")


def _interactive_list_filters() -> tuple[TaskKind | None, TaskStatus | None, TaskPriority | None] | None:
    click.echo("\n  eforge task list\n")
    click.echo("  Filter by? (press Enter to show all)\n")
    click.echo("    [1] kind     (framework/personal/new-user)")
    click.echo("    [2] status   (open/in-progress/done)")
    click.echo("    [3] priority (high/medium/low)")
    click.echo("    [4] show all")
    click.echo("    [5] quit\n")

    choice = click.prompt("  Enter number", default="4").strip()

    if choice == "5":
        click.echo("  Quit.\n")
        return None
    if choice in ("4", ""):
        return None, None, None

    if choice == "1":
        click.echo("\n  Kind:")
        kinds = list(TaskKind)
        for i, k in enumerate(kinds, 1):
            click.echo(f"    [{i}] {k.value}")
        c = click.prompt("  Enter number", default="1")
        try:
            return kinds[int(c) - 1], None, None
        except (ValueError, IndexError):
            return TaskKind.FRAMEWORK, None, None

    if choice == "2":
        click.echo("\n  Status:")
        statuses = list(TaskStatus)
        for i, s in enumerate(statuses, 1):
            click.echo(f"    [{i}] {s.value}")
        c = click.prompt("  Enter number", default="1")
        try:
            return None, statuses[int(c) - 1], None
        except (ValueError, IndexError):
            return None, TaskStatus.OPEN, None

    if choice == "3":
        click.echo("\n  Priority:")
        priorities = list(TaskPriority)
        for i, p in enumerate(priorities, 1):
            click.echo(f"    [{i}] {p.value}")
        c = click.prompt("  Enter number", default="1")
        try:
            return None, None, priorities[int(c) - 1]
        except (ValueError, IndexError):
            return None, None, TaskPriority.MEDIUM

    click.echo("  Invalid choice — showing all open tasks.\n")
    return None, TaskStatus.OPEN, None


@click.group("task")
def task_cmd() -> None:
    """Manage project tasks in .forge/tasks/."""


@task_cmd.command("list")
@click.option("--project-path", default=".", help="Project root.")
@click.option(
    "--kind",
    type=click.Choice([k.value for k in TaskKind]),
    default=None,
)
@click.option(
    "--status",
    type=click.Choice([s.value for s in TaskStatus]),
    default=None,
)
@click.option(
    "--priority",
    type=click.Choice([p.value for p in TaskPriority]),
    default=None,
)
@output_format_options
@click.pass_context
def task_list(
    ctx: click.Context,
    project_path: str,
    kind: str | None,
    status: str | None,
    priority: str | None,
    output_format: str,
) -> None:
    """List tasks. Default: open tasks, or interactive filter menu."""
    tasks_dir = _tasks_dir(project_path)

    kind_filter = TaskKind(kind) if kind else None
    status_filter = TaskStatus(status) if status else None
    priority_filter = TaskPriority(priority) if priority else None

    fmt = coerce_output_format(output_format)
    if fmt == OutputFormat.SIMPLE and not _filters_explicit(ctx):
        picked = _interactive_list_filters()
        if picked is None:
            return
        kind_filter, status_filter, priority_filter = picked
        if kind_filter is None and status_filter is None and priority_filter is None:
            status_filter = TaskStatus.OPEN
    elif not status and not kind and not priority:
        status_filter = TaskStatus.OPEN

    tasks = load_tasks(tasks_dir, kind_filter, status_filter, priority_filter)

    result = {
        "count": len(tasks),
        "tasks": [t.to_dict() for t in tasks],
    }

    def _simple(_: dict) -> None:
        _render_task_list(tasks)

    def _quiet(r: dict) -> None:
        click.echo(f"count={r['count']}")

    print_result(result, fmt, _simple, _quiet)


@task_cmd.command("add")
@project_path_option(required=False)
@yes_option()
@click.option("--title", default=None)
@click.option(
    "--kind",
    type=click.Choice([k.value for k in TaskKind]),
    default=None,
)
@click.option(
    "--priority",
    type=click.Choice([p.value for p in TaskPriority]),
    default=None,
)
@click.option("--note", default=None)
def task_add(
    project_path: str,
    yes_flag: bool,
    title: str | None,
    kind: str | None,
    priority: str | None,
    note: str | None,
) -> None:
    """Add a new task."""
    root = _project_root(project_path)
    tasks_dir = _tasks_dir(project_path)

    click.echo("\n  eforge task add\n")

    if yes_flag and not title:
        click.echo("  --yes requires --title.", err=True)
        raise SystemExit(1)

    if not title:
        title = click.prompt("  Title")
    if not kind:
        click.echo("\n  Kind:")
        for i, k in enumerate(TaskKind, 1):
            click.echo(f"    [{i}] {k.value}")
        choice = click.prompt("  Enter number", default="1")
        kinds = list(TaskKind)
        try:
            kind = kinds[int(choice) - 1].value
        except (ValueError, IndexError):
            kind = TaskKind.FRAMEWORK.value
    if not priority:
        click.echo("\n  Priority:")
        for i, p in enumerate(TaskPriority, 1):
            click.echo(f"    [{i}] {p.value}")
        choice = click.prompt("  Enter number", default="1")
        priorities = list(TaskPriority)
        try:
            priority = priorities[int(choice) - 1].value
        except (ValueError, IndexError):
            priority = TaskPriority.MEDIUM.value
    if not note and not yes_flag:
        note = click.prompt("  Note (optional)", default="")

    task_kind = TaskKind(kind)
    prefilled = {
        "title": title,
        "priority": priority,
        "note": note or "",
        "status": TaskStatus.OPEN.value,
    }
    registry = SchemaRegistry.for_project(root)
    schema = registry.get_entity("task", task_kind.value)
    extra_properties: dict = {}
    if schema:
        mode = PromptMode.BATCH if yes_flag else PromptMode.INTERACTIVE
        prompt = SchemaPrompt(registry, mode=mode, prefilled=prefilled)
        result = prompt.collect(schema)
        extra_properties = {
            k: v
            for k, v in result.values.items()
            if k not in _TASK_CLICK_FIELDS
        }

    task_id = next_task_id(tasks_dir)
    task = ForgeTask(
        id=task_id,
        title=title,
        kind=task_kind,
        priority=TaskPriority(priority),
        status=TaskStatus.OPEN,
        created=str(date.today()),
        note=note or "",
        project=root.name,
        properties=extra_properties,
    )
    task.save(tasks_dir)
    click.echo(f"\n  Created {task_id}: {title}\n")


@task_cmd.command("done")
@click.argument("task_id")
@click.option("--project-path", default=".", help="Project root.")
@click.option("--archive", is_flag=True, help="Archive instead of delete.")
def task_done(task_id: str, project_path: str, archive: bool) -> None:
    """Mark a task as done."""
    tasks_dir = _tasks_dir(project_path)
    path = tasks_dir / f"{task_id}.yaml"

    if not path.exists():
        click.echo(f"  Task {task_id} not found.", err=True)
        raise SystemExit(1)

    task = ForgeTask.from_file(path)

    click.echo(f"\n  {task.id}: {task.title}")
    click.echo(f"  {task.kind.value}  {task.priority.value}\n")

    if task.note:
        click.echo(f"  Note: {task.note}\n")

    confirmed = click.confirm("  Mark as done?", default=True)
    if not confirmed:
        click.echo("  Cancelled.\n")
        return

    if archive:
        archive_dir = tasks_dir / "archive"
        archive_dir.mkdir(parents=True, exist_ok=True)
        task.status = TaskStatus.ARCHIVED
        task.save(archive_dir)
        path.unlink()
        click.echo(f"  Archived {task_id}.\n")
    else:
        should_delete = click.confirm("  Delete file?", default=False)
        if should_delete:
            path.unlink()
            click.echo(f"  Deleted {task_id}.\n")
        else:
            task.status = TaskStatus.DONE
            task.save(tasks_dir)
            click.echo(f"  Marked {task_id} done.\n")


@task_cmd.command("show")
@click.argument("task_id")
@click.option("--project-path", default=".", help="Project root.")
def task_show(task_id: str, project_path: str) -> None:
    """Show full detail for one task."""
    tasks_dir = _tasks_dir(project_path)
    path = tasks_dir / f"{task_id}.yaml"

    if not path.exists():
        click.echo(f"  Task {task_id} not found.", err=True)
        raise SystemExit(1)

    task = ForgeTask.from_file(path)
    click.echo(f"\n  {task.id}")
    click.echo(f"  {task.title}\n")
    click.echo(f"  kind     : {task.kind.value}")
    click.echo(f"  priority : {task.priority.value}")
    click.echo(f"  status   : {task.status.value}")
    click.echo(f"  created  : {task.created}")
    click.echo(f"  project  : {task.project}")
    if task.recurrence:
        click.echo(f"  recurrence: {task.recurrence}")
    if task.tags:
        click.echo(f"  tags     : {', '.join(task.tags)}")
    if task.affects_nodes:
        click.echo(f"  affects  : {', '.join(task.affects_nodes)}")
    if task.note:
        click.echo(f"\n  {task.note}")
    if task.properties:
        click.echo()
        click.echo(properties_table(task.properties))
    click.echo("")


@task_cmd.command("update")
@click.argument("task_id")
@click.option("--project-path", default=".", help="Project root.")
def task_update(task_id: str, project_path: str) -> None:
    """Update a task's properties."""
    tasks_dir = _tasks_dir(project_path)
    path = tasks_dir / f"{task_id}.yaml"

    if not path.exists():
        click.echo(f"  Task {task_id} not found.", err=True)
        raise SystemExit(1)

    task = ForgeTask.from_file(path)

    click.echo(f"\n  Updating {task.id}: {task.title}\n")
    click.echo("  What to update?\n")
    click.echo("    [1] title")
    click.echo("    [2] kind")
    click.echo("    [3] priority")
    click.echo("    [4] status")
    click.echo("    [5] note")
    click.echo("    [6] cancel\n")

    choice = click.prompt("  Enter number", default="6")

    if choice == "1":
        task.title = click.prompt("  New title", default=task.title)
    elif choice == "2":
        click.echo("\n  Kind:")
        kinds = list(TaskKind)
        for i, k in enumerate(kinds, 1):
            marker = " <" if k == task.kind else ""
            click.echo(f"    [{i}] {k.value}{marker}")
        c = click.prompt("  Enter number", default="1")
        try:
            task.kind = kinds[int(c) - 1]
        except (ValueError, IndexError):
            pass
    elif choice == "3":
        click.echo("\n  Priority:")
        priorities = list(TaskPriority)
        for i, p in enumerate(priorities, 1):
            marker = " <" if p == task.priority else ""
            click.echo(f"    [{i}] {p.value}{marker}")
        c = click.prompt("  Enter number", default="1")
        try:
            task.priority = priorities[int(c) - 1]
        except (ValueError, IndexError):
            pass
    elif choice == "4":
        click.echo("\n  Status:")
        statuses = list(TaskStatus)
        for i, s in enumerate(statuses, 1):
            marker = " <" if s == task.status else ""
            click.echo(f"    [{i}] {s.value}{marker}")
        c = click.prompt("  Enter number", default="1")
        try:
            task.status = statuses[int(c) - 1]
        except (ValueError, IndexError):
            pass
    elif choice == "5":
        task.note = click.prompt("  Note", default=task.note or "")
    else:
        click.echo("  Cancelled.\n")
        return

    task.save(tasks_dir)
    click.echo(f"\n  Updated {task.id}.\n")


from forge.cli_engine import CLIEngine

task_group = task_cmd
CLIEngine.register("devtools", task_group, "task")
