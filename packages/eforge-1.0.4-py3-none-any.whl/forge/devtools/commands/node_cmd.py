"""eforge node — developer-facing observation graph CLI."""

from __future__ import annotations

import json
import sys
import uuid
from functools import wraps
from pathlib import Path
from typing import Any, Callable

import click

from forge.observations.path_utils import resolve_project_path
from forge.errors import ErrorRegistry
from forge.observations.errors import (
    ObservationError,
    ObservationErrorCode,
    node_not_found,
    required_field_missing,
)
from forge.observations.models import DevNode
from forge.observations.prompt import SchemaPrompt
from forge.observations.store import ObservationStore
from forge.schemas.models import TypeSchema
from forge.schemas.registry import SchemaRegistry
from forge.ui.display import (
    error_card,
    graph_ascii,
    link_tree,
    node_card,
    node_inline,
    node_table,
    properties_table,
)
from forge.ui.prompt import FieldDef, FieldOption, PromptEngine, PromptMode

COMMON_RELATIONS = [
    "housed-in",
    "relates-to",
    "variant-of",
    "active-in",
    "slot-for",
    "depends-on",
    "consumes",
    "produces",
    "member-of",
    "persists-to",
    "implements",
    "extends",
    "raises",
    "tests",
    "other",
]

INSPECT_ASPECTS = [
    "deps",
    "consumers",
    "relations",
    "notes",
    "properties",
    "graph",
    "errors",
]


def _project_path_option(func: Callable) -> Callable:
    return click.option(
        "--project-path",
        default=".",
        show_default=True,
        help="Project root containing .forge/observations/",
    )(func)


def _json_option(func: Callable) -> Callable:
    return click.option(
        "--json",
        "json_output",
        is_flag=True,
        help="Machine-readable JSON output.",
    )(func)


def _yes_option(func: Callable) -> Callable:
    return click.option("-y", "--yes", is_flag=True, help="Batch mode; skip prompts.")(func)


def handle_observation_error(e: ObservationError) -> None:
    code_str = e.code.value if hasattr(e.code, "value") else str(e.code)
    click.echo(click.style(f"\n✗ {code_str}: {e.message}", fg="red"))
    if e.context:
        for key, val in e.context.items():
            click.echo(f"  {key}: {val}")
    if e.hint:
        click.echo(click.style(f"\n  → {e.hint}", fg="yellow"))
    entry = ErrorRegistry.lookup(code_str)
    if entry and entry.description != e.message:
        click.echo(click.style(f"  ({entry.description})", fg="bright_black"))


def observation_command(fn: Callable) -> Callable:
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except ObservationError as exc:
            handle_observation_error(exc)
            raise SystemExit(1) from exc
        except KeyboardInterrupt:
            click.echo("\nAborted.")
            raise SystemExit(0) from None

    return wrapper


def _project_root(project_path: str) -> Path:
    root = resolve_project_path(project_path)
    if root is None:
        root = Path(project_path).expanduser().resolve()
    return root


def _store(project_path: str) -> ObservationStore:
    return ObservationStore(_project_root(project_path))


def _registry(project_path: str) -> SchemaRegistry:
    return SchemaRegistry.for_project(_project_root(project_path))


def node_to_dict(node: DevNode) -> dict[str, Any]:
    return node.to_dict()


def resolve_name(name: str, store: ObservationStore) -> str:
    if not name.startswith("@"):
        return name
    actual = name[1:]
    node = store.find_by_name(actual)
    if node and node.marked:
        return actual
    raise ObservationError(
        code=ObservationErrorCode.NODE_NOT_FOUND,
        message=f"No marked node '{actual}' for @{actual}",
        hint=f"Mark a node first: eforge node mark '{actual}'",
        context={"name": actual},
    )


def get_node(store: ObservationStore, name_or_id: str) -> DevNode:
    resolved = resolve_name(name_or_id, store)
    node = store.find_by_name(resolved)
    if node:
        return node
    path = store.nodes_dir / f"{resolved}.yaml"
    if path.is_file():
        return store.load_node(resolved)
    raise node_not_found(
        name=resolved,
        node_id=resolved,
        store_path=str(store.nodes_dir),
    )


def _prompt_mode(yes: bool) -> PromptMode:
    return PromptMode.BATCH if yes else PromptMode.INTERACTIVE


def _read_multiline_note() -> str:
    click.echo("Enter note (empty line to finish):")
    lines: list[str] = []
    while True:
        line = input()
        if not line:
            break
        lines.append(line)
    return "\n".join(lines)


def _warn_unknown_kind(kind: str | None, project_path: str) -> None:
    """Warn when --kind looks like a manifest kind not in KindSchemaMap."""
    if not kind or "/" in kind:
        return
    try:
        from forge.schemas.kind_map import KindSchemaMap

        root = resolve_project_path(project_path) or Path(project_path).resolve()
        kind_map = KindSchemaMap.load(root)
        if kind in kind_map.all_kinds():
            return
        mapped = kind_map.mapped_kinds()[:8]
        preview = ", ".join(mapped) if mapped else "(none)"
        click.echo(
            click.style("⚠ ", fg="yellow") + f"Unknown kind '{kind}'."
        )
        click.echo(f"  Known kinds: {preview}...")
        click.echo(f"  Create your own: eforge schema create {kind}/type")
        click.echo("  Or browse: eforge schema list")
        click.echo("")
    except Exception:
        return


def _parse_kind(kind: str | None) -> tuple[str | None, str | None]:
    if not kind:
        return None, None
    if "/" in kind:
        domain, type_name = kind.split("/", 1)
        return domain.strip(), type_name.strip()
    return kind.strip(), None


def _prompt_domain_type(
    registry: SchemaRegistry,
    mode: PromptMode,
    domain: str | None,
    type_name: str | None,
) -> tuple[str, str]:
    if domain and type_name:
        return domain, type_name
    if not domain:
        domains = registry.list_domains()
        if not domains:
            raise click.ClickException("No schema domains available")
        if mode == PromptMode.BATCH and domains:
            first = domains[0]
            types = registry.list_types(first)
            return first, type_name or (types[0] if types else "")
        engine = PromptEngine(mode=mode)
        domain_result = engine.run(
            [
                FieldDef(
                    key="domain",
                    type="enum",
                    prompt="Observation domain",
                    options=[FieldOption(value=d) for d in domains],
                    required=True,
                )
            ]
        )
        if not domain_result.is_valid:
            raise domain_result.errors[0]
        domain = str(domain_result.values["domain"])
    types = registry.list_types(domain)
    if not types:
        raise click.ClickException(f"No types for domain {domain!r}")
    if type_name:
        return domain, type_name
    if mode == PromptMode.BATCH:
        return domain, types[0]
    engine = PromptEngine(mode=mode)
    type_result = engine.run(
        [
            FieldDef(
                key="type",
                type="enum",
                prompt="Observation type",
                options=[FieldOption(value=t) for t in types],
                required=True,
            )
        ]
    )
    if not type_result.is_valid:
        raise type_result.errors[0]
    return domain, str(type_result.values["type"])


def _merge_domain_entity_properties(
    domain_props: dict[str, Any],
    entity_props: dict[str, Any],
) -> dict[str, Any]:
    merged = dict(domain_props)
    for key, val in entity_props.items():
        if key in merged:
            merged[f"_entity_{key}"] = val
        else:
            merged[key] = val
    return merged


_NODE_STATUS_SCHEMA_SUBTYPES = {
    "observed": "node-observed",
    "graduated": "node-graduated",
    "verified": "node-verified",
}


def _entity_schema_for_node_status(
    registry: SchemaRegistry,
    status: str,
) -> TypeSchema | None:
    subtype = _NODE_STATUS_SCHEMA_SUBTYPES.get(status)
    if not subtype:
        return None
    return registry.get_entity("internal", subtype)


def _collect_properties_for_node(
    registry: SchemaRegistry,
    mode: PromptMode,
    domain: str,
    type_name: str,
    node_status: str,
    prefilled: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Collect domain + entity schema properties (interactive only, matches prior add)."""
    base_prefilled = dict(prefilled or {})
    domain_props: dict[str, Any] = {}
    entity_props: dict[str, Any] = {}

    if mode == PromptMode.BATCH:
        return {}

    domain_schema = registry.get_domain(domain, type_name)
    if domain_schema:
        domain_result = SchemaPrompt(
            registry, mode=mode, prefilled=base_prefilled
        ).collect(domain_schema)
        domain_props = dict(domain_result.values)

    prefilled_after = {**base_prefilled, **domain_props}
    entity_schema = _entity_schema_for_node_status(registry, node_status)
    if entity_schema:
        entity_result = SchemaPrompt(
            registry, mode=mode, prefilled=prefilled_after
        ).collect(entity_schema)
        entity_props = dict(entity_result.values)

    return _merge_domain_entity_properties(domain_props, entity_props)


def _enum_valid_hint(prop_def: Any) -> str:
    if prop_def.type == "enum" and prop_def.options:
        return "|".join(o.value for o in prop_def.options)
    if prop_def.type == "multi_enum" and prop_def.options:
        return "|".join(o.value for o in prop_def.options)
    return ""


def _split_node_properties(
    node: DevNode,
    registry: SchemaRegistry,
) -> tuple[dict[str, Any], dict[str, Any]]:
    props = dict(node.properties or {})
    domain_props: dict[str, Any] = {}
    entity_props: dict[str, Any] = {}

    domain_keys: set[str] = set()
    if node.domain and node.type:
        domain_schema = registry.get_domain(node.domain, node.type)
        if domain_schema:
            domain_keys = set(domain_schema.merged_properties(registry).keys())

    for key, val in props.items():
        if key.startswith("_entity_"):
            entity_props[key[8:]] = val
        elif key in domain_keys:
            domain_props[key] = val
        else:
            entity_props[key] = val
    return domain_props, entity_props


def _format_property_lines(
    props: dict[str, Any],
    schema: TypeSchema | None,
    registry: SchemaRegistry,
) -> list[str]:
    if not props:
        return ["  (none)"]
    if schema is None:
        return [f"  {key}: {val}" for key, val in props.items()]
    merged = schema.merged_properties(registry)
    lines: list[str] = []
    for key, val in props.items():
        prop = merged.get(key)
        hint = _enum_valid_hint(prop) if prop else ""
        if hint:
            lines.append(f"  {key}: {val}  (valid: {hint})")
        else:
            lines.append(f"  {key}: {val}")
    return lines


def _inspect_properties_text(node: DevNode, registry: SchemaRegistry) -> str:
    domain_props, entity_props = _split_node_properties(node, registry)
    domain_schema = (
        registry.get_domain(node.domain, node.type)
        if node.domain and node.type
        else None
    )
    entity_schema = _entity_schema_for_node_status(registry, node.status)

    if domain_schema is None and entity_schema is None:
        return properties_table(node.properties)

    lines: list[str] = []
    if domain_props or domain_schema:
        lines.append("properties:")
        lines.extend(_format_property_lines(domain_props, domain_schema, registry))
    elif node.properties and not entity_props:
        return properties_table(node.properties)

    if entity_props or entity_schema:
        if lines:
            lines.append("")
        lines.append("entity properties:")
        lines.extend(_format_property_lines(entity_props, entity_schema, registry))
    return "\n".join(lines) if lines else properties_table(node.properties)


def _list_rows_with_properties(nodes: list[DevNode]) -> tuple[list[dict[str, Any]], list[str]]:
    rows = [node_to_dict(n) for n in nodes]
    prop_keys: set[str] = set()
    for node in nodes:
        prop_keys.update((node.properties or {}).keys())
    extra_cols = sorted(prop_keys)
    base_cols = ["name", "domain", "type", "status", "marked", "tags"]
    for row, node in zip(rows, nodes):
        for key in extra_cols:
            val = (node.properties or {}).get(key)
            row[key] = "—" if val is None or val == "" else val
    return rows, base_cols + extra_cols


def _emit_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, default=str))


@click.group(name="node")
def node_group() -> None:
    """Manage developer observation nodes (.forge/observations/)."""


@node_group.command("add")
@click.argument("name", required=False)
@click.option("--kind", default=None, help="DOMAIN/TYPE for layer 3 and 2.")
@click.option("--file", "source_file", default=None, help="Source file path.")
@click.option("--line", "source_line", type=int, default=None, help="Source line number.")
@click.option("--tag", "tags", multiple=True, help="Tags to add.")
@click.option("--note", default=None, help="Initial note text.")
@_project_path_option
@_yes_option
@_json_option
@observation_command
def node_add(
    name: str | None,
    kind: str | None,
    source_file: str | None,
    source_line: int | None,
    tags: tuple[str, ...],
    note: str | None,
    project_path: str,
    yes: bool,
    json_output: bool,
) -> None:
    """Add a new observation node."""
    store = _store(project_path)
    registry = _registry(project_path)
    mode = _prompt_mode(yes)

    if not name:
        if yes:
            raise required_field_missing(field_key="name", mode="batch")
        name = click.prompt("Node name").strip()
    if not name:
        raise required_field_missing(field_key="name", mode="interactive")

    _warn_unknown_kind(kind, project_path)

    existing = store.find_by_name(name)
    if existing and not yes:
        if click.confirm(f"Node {name!r} exists. Edit it?", default=False):
            ctx = click.get_current_context()
            ctx.invoke(
                node_edit,
                name=name,
                project_path=project_path,
                yes=yes,
            )
            return
        click.echo("Aborted.")
        return

    domain_hint, type_hint = _parse_kind(kind)
    domain: str
    type_name: str
    if kind and "/" not in kind:
        try:
            from forge.schemas.kind_map import KindSchemaMap

            root = (
                resolve_project_path(project_path)
                or Path(project_path).resolve()
            )
            km = KindSchemaMap.load(root)
            if kind not in km.all_kinds():
                domain = kind
                type_name = kind
            else:
                domain, type_name = _prompt_domain_type(
                    registry, mode, domain_hint, type_hint
                )
        except Exception:
            domain, type_name = _prompt_domain_type(
                registry, mode, domain_hint, type_hint
            )
    else:
        domain, type_name = _prompt_domain_type(
            registry, mode, domain_hint, type_hint
        )

    node_status = "observed"
    properties = _collect_properties_for_node(
        registry,
        mode,
        domain,
        type_name,
        node_status,
    )

    node = DevNode(
        id=str(uuid.uuid4())[:8],
        name=name,
        domain=domain,
        type=type_name,
        status=node_status,
        properties=properties,
        tags=list(tags),
        source_file=source_file,
        source_line=source_line,
    )
    if note:
        node.add_note(note)
    store.save_node(node)

    data = node_to_dict(node)
    if json_output:
        _emit_json(data)
    else:
        click.echo(node_card(data))
        click.echo(
            click.style(
                f"\n  → Add links with: eforge node link '{name}' <target>",
                fg="yellow",
            )
        )


@node_group.command("show")
@click.argument("name_or_id")
@_project_path_option
@_json_option
@observation_command
def node_show(name_or_id: str, project_path: str, json_output: bool) -> None:
    """Show full details for a node."""
    store = _store(project_path)
    node = get_node(store, name_or_id)
    data = node_to_dict(node)

    if json_output:
        consumers = [
            {"from": n.name, "rel": lnk.rel, "note": lnk.note}
            for n, lnk in store.get_links_to(node.name)
        ]
        data["consumers"] = consumers
        _emit_json(data)
        return

    click.echo(node_card(data))
    if node.properties:
        click.echo()
        click.echo(properties_table(node.properties))
    if node.links:
        click.echo()
        click.echo("Outgoing links:")
        click.echo(
            link_tree(
                data,
                [{"to": l.to, "rel": l.rel, "note": l.note} for l in node.links],
            )
        )
    consumers = store.get_links_to(node.name)
    if consumers:
        click.echo()
        click.echo("Consumers:")
        click.echo(
            link_tree(
                data,
                [
                    {
                        "to": node.name,
                        "rel": lnk.rel,
                        "from_name": n.name,
                        "note": lnk.note,
                    }
                    for n, lnk in consumers
                ],
                direction="to",
            )
        )
    if node.notes:
        click.echo()
        click.echo("Notes:")
        for nt in sorted(node.notes, key=lambda n: n.created_at, reverse=True):
            click.echo(f"  - [{nt.created_at}] {nt.body}")
            if nt.tags:
                click.echo(f"    tags: {', '.join(nt.tags)}")
    click.echo()
    click.echo(click.style(f"  → Edit: eforge node edit '{node.name}'", fg="yellow"))
    click.echo(click.style(f"  → Link: eforge node link '{node.name}' <target>", fg="yellow"))
    click.echo(click.style(f"  → Note: eforge node note '{node.name}' '<text>'", fg="yellow"))
    if node.source_file:
        loc = f"{node.source_file}:{node.source_line}" if node.source_line else node.source_file
        click.echo(click.style(f"  → File: {loc}", fg="yellow"))


@node_group.command("list")
@click.option("--domain", default=None)
@click.option("--type", "type_name", default=None)
@click.option("--tag", default=None)
@click.option("--marked", is_flag=True)
@click.option("--status", default=None)
@click.option(
    "--sort",
    type=click.Choice(["name", "created", "updated"]),
    default="name",
)
@click.option(
    "--properties",
    "show_properties",
    is_flag=True,
    help="Include node.properties keys as extra table columns.",
)
@_project_path_option
@_json_option
@observation_command
def node_list(
    domain: str | None,
    type_name: str | None,
    tag: str | None,
    marked: bool,
    status: str | None,
    sort: str,
    show_properties: bool,
    project_path: str,
    json_output: bool,
) -> None:
    """List observation nodes with optional filters."""
    store = _store(project_path)
    tag_list = [tag] if tag else None
    nodes = store.list_nodes(
        domain=domain,
        type=type_name,
        tags=tag_list,
        marked=True if marked else None,
        status=status,
    )
    if sort == "created":
        nodes.sort(key=lambda n: n.created_at)
    elif sort == "updated":
        nodes.sort(key=lambda n: n.updated_at)
    else:
        nodes.sort(key=lambda n: n.name.lower())

    all_count = len(store.list_nodes())
    filtered = len(nodes)
    if json_output:
        _emit_json([node_to_dict(n) for n in nodes])
        return

    if not nodes:
        click.echo("No nodes match.")
        click.echo(click.style("  → Try: eforge node list", fg="yellow"))
        click.echo(click.style("  → Create one: eforge node add", fg="yellow"))
        return

    if show_properties:
        rows, columns = _list_rows_with_properties(nodes)
        click.echo(node_table(rows, columns=columns))
    else:
        click.echo(node_table([node_to_dict(n) for n in nodes]))
    suffix = f" (filtered: {filtered})" if filtered != all_count else ""
    click.echo(f"\n{filtered} nodes{suffix}")


@node_group.command("find")
@click.argument("query")
@click.option("--domain", default=None)
@click.option("--type", "type_name", default=None)
@click.option("--tag", default=None)
@click.option("--file", "source_file", default=None)
@click.option("--marked", is_flag=True)
@_project_path_option
@_json_option
@observation_command
def node_find(
    query: str,
    domain: str | None,
    type_name: str | None,
    tag: str | None,
    source_file: str | None,
    marked: bool,
    project_path: str,
    json_output: bool,
) -> None:
    """Fuzzy search nodes by name, tags, properties, notes, or file."""
    store = _store(project_path)
    hits = store.search_nodes(
        query,
        domain=domain,
        type=type_name,
        tag=tag,
        source_file=source_file,
        marked=True if marked else None,
    )
    if json_output:
        _emit_json(
            [{"score": score, **node_to_dict(node)} for node, score in hits]
        )
        return

    if not hits:
        click.echo(f"No nodes match {query!r}")
        click.echo(click.style("  → Try a broader query or: eforge node list", fg="yellow"))
        return

    rows = [node_to_dict(node) for node, _score in hits]
    click.echo(node_table(rows))
    click.echo(f"\nFound {len(hits)} nodes matching {query!r}")


@node_group.command("link")
@click.argument("from_name")
@click.argument("to_name")
@click.option("--rel", default=None, help="Relationship type.")
@click.option("--note", default=None, help="Link note.")
@_project_path_option
@_yes_option
@_json_option
@observation_command
def node_link(
    from_name: str,
    to_name: str,
    rel: str | None,
    note: str | None,
    project_path: str,
    yes: bool,
    json_output: bool,
) -> None:
    """Link two nodes (FROM --rel--> TO)."""
    store = _store(project_path)
    from_node = get_node(store, from_name)
    to_resolved = resolve_name(to_name, store)
    target_exists = store.find_by_name(to_resolved) is not None

    mode = _prompt_mode(yes)
    if not rel:
        if yes:
            rel = "depends-on"
        else:
            engine = PromptEngine(mode=mode)
            result = engine.run(
                [
                    FieldDef(
                        key="rel",
                        type="enum",
                        prompt="Relationship",
                        options=[FieldOption(value=r) for r in COMMON_RELATIONS],
                        required=True,
                    )
                ]
            )
            if not result.is_valid:
                raise result.errors[0]
            rel = str(result.values["rel"])
            if rel == "other":
                rel = click.prompt("Custom relationship").strip()

    if note is None and not yes:
        note_input = click.prompt("Link note (optional, Enter to skip)", default="")
        note = note_input.strip() or None

    store.add_link(from_node.id, to_resolved, rel, note=note)
    payload = {
        "from": from_node.name,
        "to": to_resolved,
        "rel": rel,
        "note": note,
        "dangling": not target_exists,
    }
    if json_output:
        _emit_json(payload)
        return

    click.echo(click.style(f"✓ Linked: {from_node.name} --[{rel}]--> {to_resolved}", fg="green"))
    if not target_exists:
        click.echo(
            click.style(
                f"  → Target {to_resolved!r} not registered. "
                f"Resolve: eforge node add '{to_resolved}'",
                fg="yellow",
            )
        )


@node_group.command("note")
@click.argument("name")
@click.argument("text", required=False)
@click.option("--tag", "tags", multiple=True)
@_project_path_option
@observation_command
def node_note(
    name: str,
    text: str | None,
    tags: tuple[str, ...],
    project_path: str,
) -> None:
    """Add a note to a node."""
    store = _store(project_path)
    node = get_node(store, name)
    body = text if text is not None else _read_multiline_note()
    if not body.strip():
        click.echo("No note text provided.")
        return
    node.add_note(body.strip(), tags=list(tags))
    store.save_node(node)
    click.echo(click.style(f"✓ Note added to {node.name!r}", fg="green"))
    click.echo(f"  notes: {len(node.notes)}")


@node_group.command("tag")
@click.argument("name")
@click.argument("tags", nargs=-1)
@click.option("--remove", is_flag=True, help="Remove tags instead of adding.")
@_project_path_option
@observation_command
def node_tag(
    name: str,
    tags: tuple[str, ...],
    remove: bool,
    project_path: str,
) -> None:
    """Add or remove tags on a node."""
    store = _store(project_path)
    node = get_node(store, name)
    if remove:
        for tag in tags:
            if tag in node.tags:
                node.tags.remove(tag)
    else:
        for tag in tags:
            if tag not in node.tags:
                node.tags.append(tag)
    store.save_node(node)
    click.echo(f"tags: {', '.join(node.tags) if node.tags else '(none)'}")


@node_group.command("mark")
@click.argument("name")
@click.option("--unmark", is_flag=True)
@_project_path_option
@observation_command
def node_mark(name: str, unmark: bool, project_path: str) -> None:
    """Bookmark a node for @name shorthand."""
    store = _store(project_path)
    node = get_node(store, name)
    node.marked = not unmark
    store.save_node(node)
    if unmark:
        click.echo(click.style(f"✓ Unmarked: {node.name}", fg="green"))
    else:
        click.echo(click.style(f"✓ Marked: {node.name} (@{node.name} shorthand active)", fg="green"))
    marked_nodes = store.list_nodes(marked=True)
    if marked_nodes:
        names = ", ".join(f"@{n.name}" for n in marked_nodes)
        click.echo(f"Marked nodes: {names}")


@node_group.command("edit")
@click.argument("name")
@_project_path_option
@_yes_option
@observation_command
def node_edit(name: str, project_path: str, yes: bool) -> None:
    """Edit an existing node interactively."""
    store = _store(project_path)
    registry = _registry(project_path)
    node = get_node(store, name)
    mode = _prompt_mode(yes)
    original = node_to_dict(node)

    if node.domain and node.type and mode != PromptMode.BATCH:
        node.properties = _collect_properties_for_node(
            registry,
            mode,
            node.domain,
            node.type,
            node.status,
            prefilled=node.properties,
        )

    changes: list[str] = []
    old_props = original.get("properties") or {}
    for key, val in node.properties.items():
        if old_props.get(key) != val:
            changes.append(f"  {key}: {old_props.get(key)!r} → {val!r}")

    if not changes:
        click.echo("No changes made.")
        return

    click.echo("Changes:")
    for line in changes:
        click.echo(line)
    if not yes and not click.confirm("Save changes?", default=True):
        click.echo("Aborted.")
        return

    store.save_node(node)
    click.echo(node_card(node_to_dict(node)))


@node_group.command("inspect")
@click.argument("name")
@click.argument("aspect", required=False)
@_project_path_option
@_json_option
@observation_command
def node_inspect(
    name: str,
    aspect: str | None,
    project_path: str,
    json_output: bool,
) -> None:
    """Inspect a node aspect: deps, consumers, relations, notes, properties, graph, errors."""
    store = _store(project_path)
    node = get_node(store, name)

    if not aspect:
        click.echo("Aspects:")
        for i, a in enumerate(INSPECT_ASPECTS, 1):
            click.echo(f"  {i}. {a}")
        choice = click.prompt("Select aspect number", default="1").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(INSPECT_ASPECTS):
            aspect = INSPECT_ASPECTS[int(choice) - 1]
        else:
            aspect = choice

    data = node_to_dict(node)

    if aspect == "deps":
        links = [{"to": l.to, "rel": l.rel, "note": l.note} for l in node.links]
        if json_output:
            _emit_json({"aspect": "deps", "links": links})
            return
        click.echo(f"{node.name} depends on:")
        click.echo(link_tree(data, links))

    elif aspect == "consumers":
        consumers = store.get_links_to(node.name)
        if json_output:
            _emit_json(
                {
                    "aspect": "consumers",
                    "links": [
                        {"from": n.name, "rel": l.rel, "note": l.note}
                        for n, l in consumers
                    ],
                }
            )
            return
        click.echo(f"{node.name} is consumed by:")
        click.echo(
            link_tree(
                data,
                [
                    {
                        "to": node.name,
                        "rel": lnk.rel,
                        "from_name": n.name,
                        "note": lnk.note,
                    }
                    for n, lnk in consumers
                ],
                direction="to",
            )
        )

    elif aspect == "relations":
        outgoing = [{"dir": "→", "rel": l.rel, "target": l.to} for l in node.links]
        incoming = [
            {"dir": "←", "rel": lnk.rel, "target": n.name}
            for n, lnk in store.get_links_to(node.name)
        ]
        if json_output:
            _emit_json({"aspect": "relations", "outgoing": outgoing, "incoming": incoming})
            return
        click.echo(f"Relations for {node.name}:")
        for item in outgoing:
            click.echo(f"  → [{item['rel']}] {item['target']}")
        for item in incoming:
            click.echo(f"  ← [{item['rel']}] {item['target']}")

    elif aspect == "notes":
        notes = sorted(node.notes, key=lambda n: n.created_at, reverse=True)
        if json_output:
            _emit_json({"aspect": "notes", "notes": [n.to_dict() for n in notes]})
            return
        if not notes:
            click.echo("  (no notes)")
        for nt in notes:
            click.echo(f"  [{nt.created_at}] {nt.body}")
            if nt.tags:
                click.echo(f"    tags: {', '.join(nt.tags)}")

    elif aspect == "properties":
        if json_output:
            _emit_json({"aspect": "properties", "properties": node.properties})
            return
        registry = _registry(project_path)
        click.echo(_inspect_properties_text(node, registry))

    elif aspect == "graph":
        edges: list[tuple[str, str, str]] = []
        for link in node.links:
            edges.append((node.name, link.rel, link.to))
            child = store.find_by_name(link.to)
            if child:
                for sub in child.links:
                    edges.append((child.name, sub.rel, sub.to))
        if json_output:
            _emit_json({"aspect": "graph", "edges": edges})
            return
        click.echo(graph_ascii(node.name, edges))

    elif aspect == "errors":
        error_links = [l for l in node.links if l.rel in ("raises", "can-raise")]
        if json_output:
            _emit_json(
                {
                    "aspect": "errors",
                    "links": [l.to_dict() for l in error_links],
                }
            )
            return
        click.echo(f"{node.name} can raise:")
        for link in error_links:
            entry = ErrorRegistry.lookup(link.to)
            if entry:
                click.echo(
                    error_card(
                        {
                            "code": entry.code,
                            "name": entry.name,
                            "description": entry.description,
                            "hint": entry.hint,
                            "subsystem": entry.subsystem,
                        }
                    )
                )
            else:
                click.echo(node_card({"name": link.to, "domain": "?", "type": "?"}))

    else:
        raise click.ClickException(f"Unknown aspect: {aspect}")


@node_group.command("import-manifest")
@_project_path_option
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview import without writing DevNodes.",
)
@_yes_option
@_json_option
@observation_command
def node_import_manifest(
    project_path: str,
    dry_run: bool,
    yes: bool,
    json_output: bool,
) -> None:
    """Bootstrap DevNodes from .forge/manifest.yaml graph nodes."""
    _ = yes
    root = resolve_project_path(project_path) or Path(project_path).resolve()
    from forge.graphs.bridge import ManifestObservationBridge
    from forge.schemas.kind_map import KindSchemaMap
    from forge.tools.manifest.graph import build_manifest_graph

    graph = build_manifest_graph(root)
    bridge = ManifestObservationBridge.for_project(root)

    kind_map = KindSchemaMap.load(root)
    created = 0
    updated = 0
    skipped = 0
    rows: list[dict[str, Any]] = []
    all_existing = bridge.all_devnodes_by_manifest_ref()
    to_create: list[DevNode] = []
    to_update: list[DevNode] = []

    for mnode in graph.nodes:
        node_id = str(getattr(mnode, "id", "") or "").strip()
        if not node_id:
            skipped += 1
            continue
        kind = str(getattr(mnode, "kind", None) or "module").strip()
        path = str(getattr(mnode, "path", None) or "").strip()
        schema_ref = kind_map.schema_for_kind(kind)
        domain_name = type_name = None
        if schema_ref is not None:
            domain_name, type_name = schema_ref
        props: dict[str, Any] = {}
        if getattr(mnode, "domain", None):
            props["manifest_domain"] = mnode.domain

        existing = all_existing.get(node_id)

        if dry_run:
            action = "update" if existing else "create"
            rows.append(
                {
                    "node_id": node_id,
                    "kind": kind,
                    "action": action,
                }
            )
            if existing:
                updated += 1
            else:
                created += 1
            continue

        if existing:
            if props:
                existing.properties.update(props)
            to_update.append(existing)
            updated += 1
        else:
            dev_node = DevNode(
                id=str(uuid.uuid4())[:8],
                name=node_id,
                domain=domain_name,
                type=type_name if schema_ref else kind,
                status="graduated",
                source_file=path,
                properties=props,
                manifest_ref=node_id,
            )
            to_create.append(dev_node)
            created += 1

    if not dry_run:
        bridge.save_devnodes_batch(to_create + to_update)

    total = len(graph.nodes)
    summary = {
        "total_manifest_nodes": total,
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "dry_run": dry_run,
    }
    if json_output:
        payload = {**summary, "preview": rows} if dry_run else summary
        _emit_json(payload)
        return

    label = "Would import" if dry_run else "Imported"
    click.echo(
        click.style(f"\n✓ {label} manifest → observations", fg="green")
    )
    click.echo(f"  manifest nodes: {total}")
    click.echo(f"  created:        {created}")
    click.echo(f"  updated:        {updated}")
    if skipped:
        click.echo(f"  skipped:        {skipped}")
    if dry_run:
        click.echo("\n  Re-run without --dry-run to write DevNodes.")


from forge.cli_engine import CLIEngine

CLIEngine.register("devtools", node_group, "node")
