"""eforge error — error catalog lookup, search, and event history."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import click

from forge.observations.path_utils import resolve_project_path
from forge.errors import ErrorEntry, ErrorRegistry
from forge.observations.event_log import EventLog
from forge.ui.display import error_card


def _observations_dir(project_path: str) -> Path:
    root = resolve_project_path(project_path)
    return root / ".forge" / "observations"


def _entry_dict(entry: ErrorEntry) -> dict:
    return {
        "code": entry.code,
        "name": entry.name,
        "description": entry.description,
        "hint": entry.hint,
        "subsystem": entry.subsystem,
        "context_fields": entry.context_fields,
    }


def _format_timestamp(iso_ts: str) -> str:
    try:
        normalized = iso_ts.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return iso_ts[:19] if len(iso_ts) >= 19 else iso_ts


def _format_context(ctx: dict) -> str:
    if not ctx:
        return ""
    parts = [f"{k}={v}" for k, v in ctx.items() if v is not None]
    return ", ".join(parts)


def _cmd_lookup(code: str, history: bool, project_path: str) -> None:
    entry = ErrorRegistry.lookup(code.upper())
    if entry is None:
        click.echo(f"Unknown error code: {code}")
        click.echo("Try: eforge error --search <query>")
        raise SystemExit(1)

    click.echo(error_card(_entry_dict(entry)))

    if not history:
        return

    obs_dir = _observations_dir(project_path)
    log = EventLog(obs_dir)
    if not log.log_path.is_file():
        click.echo("\nNo event history found for this project.")
        return

    events = log.read_by_code(entry.code)
    if not events:
        click.echo("\nNo event history found for this project.")
        return

    recent = events[-5:]
    click.echo("\nRecent occurrences (last 5):")
    for event in recent:
        ctx_text = _format_context(event.context)
        ts = _format_timestamp(event.timestamp)
        if ctx_text:
            click.echo(f"  {ts}  context: {ctx_text}")
        else:
            click.echo(f"  {ts}")
    click.echo(f"\nTotal occurrences: {len(events)}")


def _cmd_search(query: str, subsystem: str | None) -> None:
    hits = ErrorRegistry.search(query)
    if subsystem:
        hits = [e for e in hits if e.subsystem == subsystem]
    hits = sorted(hits, key=lambda e: e.code)

    if not hits:
        click.echo(f"No error codes match '{query}'")
        click.echo("Try: eforge error --list to see all codes")
        return

    click.echo(f"\nMatching error codes for '{query}':\n")
    click.echo(f"  {'CODE':<10}{'NAME':<22}{'SUBSYSTEM':<16}")
    for entry in hits:
        click.echo(
            f"  {entry.code:<10}{entry.name:<22}{entry.subsystem:<16}"
        )
    click.echo(f"\n{len(hits)} result{'s' if len(hits) != 1 else ''}. "
               f"Use 'eforge error <CODE>' for details.")


def _cmd_list(subsystem: str | None) -> None:
    entries = ErrorRegistry.all_entries(subsystem)
    if not entries:
        if subsystem:
            click.echo(f"No error codes registered for subsystem '{subsystem}'.")
        else:
            click.echo("No error codes registered.")
        return

    by_sub: dict[str, list[ErrorEntry]] = {}
    for entry in entries:
        by_sub.setdefault(entry.subsystem, []).append(entry)

    for sub_name in sorted(by_sub):
        group = by_sub[sub_name]
        click.echo(f"\n{sub_name} ({len(group)} code{'s' if len(group) != 1 else ''}):")
        for entry in group:
            click.echo(f"  {entry.code}  {entry.name}")

    total = len(entries)
    click.echo(f"\nTotal: {total} registered error code{'s' if total != 1 else ''}.")
    click.echo("Use 'eforge error <CODE>' for details.")


def _cmd_stats(project_path: str) -> None:
    obs_dir = _observations_dir(project_path)
    log = EventLog(obs_dir)
    if not log.log_path.is_file():
        click.echo("No error history for this project.")
        return

    stats = log.stats()
    if not stats:
        click.echo("No error history for this project.")
        return

    all_events = log.read_all()
    last_seen: dict[str, str] = {}
    for event in all_events:
        prev = last_seen.get(event.code)
        if prev is None or event.timestamp > prev:
            last_seen[event.code] = event.timestamp

    click.echo("\nError frequency (this project):\n")
    click.echo(f"  {'CODE':<10}{'NAME':<20}{'COUNT':<8}{'LAST SEEN'}")
    rows: list[tuple[str, str, int, str]] = []
    for code, count in sorted(stats.items(), key=lambda x: (-x[1], x[0])):
        entry = ErrorRegistry.lookup(code)
        name = entry.name if entry else "?"
        ts = _format_timestamp(last_seen.get(code, ""))[:16]
        rows.append((code, name, count, ts))
        click.echo(f"  {code:<10}{name:<20}{count:<8}{ts}")

    total = sum(stats.values())
    top_code = max(stats, key=stats.get)
    click.echo(f"\nTotal events: {total}")
    click.echo(
        f"→ Most common: {top_code} (run 'eforge error {top_code}' for details)"
    )


# Flat @click.command (not a Group): options like --history must follow
# `eforge error CODE`; a Group would treat trailing flags as subcommand names.
@click.command(name="error")
@click.argument("code", required=False)
@click.option("--search", "search_query", default=None, help="Search error catalog.")
@click.option("--list", "list_codes", is_flag=True, help="List all registered error codes.")
@click.option("--stats", "show_stats", is_flag=True, help="Show event frequency for project.")
@click.option("--history", is_flag=True, help="Include recent occurrences (with CODE).")
@click.option("--subsystem", default=None, help="Filter --search or --list by subsystem.")
@click.option("--project-path", default=".", show_default=True)
def error_group(
    code: str | None,
    search_query: str | None,
    list_codes: bool,
    show_stats: bool,
    history: bool,
    subsystem: str | None,
    project_path: str,
) -> None:
    """Error code lookup and management."""
    if list_codes:
        _cmd_list(subsystem)
    elif search_query is not None:
        _cmd_search(search_query, subsystem)
    elif show_stats:
        _cmd_stats(project_path)
    elif code:
        _cmd_lookup(code, history, project_path)
    else:
        ctx = click.get_current_context()
        click.echo(ctx.get_help() if ctx else "")


from forge.cli_engine import CLIEngine

CLIEngine.register("devtools", error_group, "error")
