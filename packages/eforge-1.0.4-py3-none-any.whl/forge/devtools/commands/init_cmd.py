"""eforge init — initialize .forge/observations for a project."""

from __future__ import annotations

from pathlib import Path

import click

from forge.observations.path_utils import resolve_project_path
from forge.observations.store import ObservationStore
from forge.schemas.store import SchemaStore


def _project_root(project_path: str) -> Path:
    root = resolve_project_path(project_path)
    if root is None:
        root = Path(project_path).expanduser().resolve()
    return root


def _do_init(project_path: str) -> None:
    root = _project_root(project_path)
    store = ObservationStore(root)
    SchemaStore.init_project(root)
    obs_dir = store.observations_dir
    click.echo(click.style("✓ ", fg="green") + str(obs_dir))
    click.echo("")
    click.echo("  Structure:")
    click.echo(
        "  .forge/observations/nodes/     "
        "← your observation nodes"
    )
    click.echo(
        "  .forge/observations/schemas/   "
        "← your project schemas"
    )
    click.echo(
        "  .forge/observations/.cache/    "
        "← SQLite index (auto-rebuilt)"
    )
    click.echo("")
    click.echo("  Quick start:")
    click.echo(
        '  eforge node add "MyFeature" '
        "--kind concept/feature -y"
    )
    click.echo(
        '  eforge node add "myfile.py" '
        "--kind core/file "
        "--file path/to/myfile.py -y"
    )
    click.echo(
        '  eforge node link "MyFeature" "myfile.py"'
        " --rel housed-in -y"
    )
    click.echo("")
    click.echo("  Your own schemas:")
    click.echo(
        "  eforge schema create game/canvas  "
        "← project-local, never touches forge"
    )
    click.echo(
        "  eforge schema list               "
        "← see all available schemas"
    )
    click.echo("")
    click.echo("  eforge --help for all commands")


@click.group(name="init", invoke_without_command=True)
@click.option("--project-path", default=".", show_default=True)
@click.pass_context
def init_group(ctx: click.Context, project_path: str) -> None:
    """Initialize .forge/observations for this project."""
    if ctx.invoked_subcommand is None:
        _do_init(project_path)


from forge.cli_engine import CLIEngine

CLIEngine.register("devtools", init_group, "init")
