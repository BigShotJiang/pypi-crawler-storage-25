"""eforge schema — manage eforge schemas under .eforge/schemas/."""

from __future__ import annotations

import copy
from functools import wraps
from pathlib import Path
from typing import Any, Callable

import click
import yaml

from forge.observations.path_utils import resolve_project_path
from forge.errors import ErrorRegistry
from forge.observations.errors import ObservationError
from forge.schemas.builder import SchemaBuilder
from forge.schemas.registry import SchemaRegistry
from forge.schemas.store import SchemaEntry, SchemaStore
from forge.schemas.validator import SchemaValidator
from forge.ui.display import error_card
from forge.ui.prompt import PromptEngine, PromptMode


def _project_root(project_path: str) -> Path:
    root = resolve_project_path(project_path)
    if root is None:
        root = Path(project_path).expanduser().resolve()
    return root


def _store(project_path: str) -> SchemaStore:
    SchemaStore.init_project(_project_root(project_path))
    return SchemaStore(_project_root(project_path))


def _registry(project_path: str) -> SchemaRegistry:
    return SchemaRegistry.for_project(_project_root(project_path))


def _reload(project_path: str) -> None:
    _registry(project_path).reload()


def parse_schema_ref(ref: str) -> tuple[str, str]:
    if "/" not in ref:
        raise click.ClickException(
            f"Invalid schema ref {ref!r}. Use DOMAIN/TYPE (e.g. code/function)."
        )
    domain, type_name = ref.split("/", 1)
    return domain.strip(), type_name.strip()


def resolve_category(
    registry: SchemaRegistry,
    domain: str,
    type_name: str,
    category: str | None,
) -> str:
    if category and category != "all":
        return category
    for cat in ("domain", "entity", "config"):
        if registry.lookup(cat, domain, type_name):
            return cat
    return "domain"


def handle_schema_error(exc: Exception) -> None:
    if isinstance(exc, ObservationError):
        code_str = exc.code.value if hasattr(exc.code, "value") else str(exc.code)
        click.echo(click.style(f"\n✗ {code_str}: {exc.message}", fg="red"))
        if exc.context:
            for key, val in exc.context.items():
                click.echo(f"  {key}: {val}")
        if exc.hint:
            click.echo(click.style(f"\n  → {exc.hint}", fg="yellow"))
        entry = ErrorRegistry.lookup(code_str)
        if entry and entry.description != exc.message:
            click.echo(click.style(f"  ({entry.description})", fg="bright_black"))
        if code_str.startswith("OBS-01"):
            ctx_domain = exc.context.get("domain") or exc.context.get("file_path")
            if ctx_domain:
                click.echo(
                    click.style(
                        f"  → Fix yaml at {ctx_domain} or run: eforge schema edit",
                        fg="yellow",
                    )
                )
        return
    click.echo(click.style(f"\n✗ {exc}", fg="red"))


def schema_command(fn: Callable) -> Callable:
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except ObservationError as exc:
            handle_schema_error(exc)
            raise SystemExit(1) from exc
        except click.ClickException:
            raise
        except Exception as exc:
            handle_schema_error(exc)
            raise SystemExit(1) from exc

    return wrapper


def _list_marker(store: SchemaStore, entry: SchemaEntry) -> str:
    if entry.scope != "project":
        return ""
    if store.has_defaults_copy(entry.category, entry.domain, entry.type_name):
        return " ✓"
    if not store.has_package_copy(entry.category, entry.domain, entry.type_name):
        return " ★"
    return ""


def _source_display(store: SchemaStore, entry: SchemaEntry) -> str:
    """SOURCE column: built-in, project, defaults; ★ for project-only schemas."""
    from forge.schemas.store import _entry_source_key

    label = _entry_source_key(entry)
    if entry.scope == "project" and _list_marker(store, entry).strip() == "★":
        return "project ★"
    if entry.scope == "legacy":
        return "project ★"
    return label


def _format_show(entry: SchemaEntry, registry: SchemaRegistry) -> str:
    data = entry.data
    category = data.get("category") or entry.category
    domain = data.get("domain") or entry.domain
    type_name = data.get("type_name") or entry.type_name
    lines = [
        f"┌─ {category}/{domain}/{type_name}",
        f"│ category: {category}",
        f"│ source: {entry.scope}",
        f"│ description: {data.get('description') or '—'}",
        f"│ inherits: {data.get('inherits') or '—'}",
    ]
    order = data.get("prompts_order") or []
    lines.append(f"│ prompts_order: {', '.join(order) if order else '—'}")
    lines.append("└")
    lines.append("")
    props = data.get("properties") or {}
    lines.append(f"  Properties ({len(props)}):")
    lines.append("")

    try:
        schema = SchemaBuilder.from_dict(data)
        merged = schema.merged_properties(registry)
    except ObservationError:
        merged = {}

    for key in sorted(props.keys()):
        raw = props[key]
        if not isinstance(raw, dict):
            lines.append(f"  {key}: {raw}")
            continue
        ptype = raw.get("type", "?")
        req = "required" if raw.get("required") else "optional"
        default = raw.get("default")
        default_txt = f"  default: {default}" if default is not None else ""
        lines.append(f"  {key}  [{ptype}]  {req}{default_txt}")
        if ptype in ("enum", "multi_enum"):
            for opt in raw.get("options") or []:
                if not isinstance(opt, dict):
                    continue
                val = opt.get("value", "?")
                exposes = opt.get("exposes") or {}
                if exposes:
                    reveal = ", ".join(sorted(exposes.keys()))
                    lines.append(f"    options: {val} → reveals: {reveal}")
                else:
                    lines.append(f"    options: {val}")
        constraints = raw.get("constraints") or []
        for constraint in constraints:
            if isinstance(constraint, dict):
                rule = constraint.get("rule") or "constraint"
                lines.append(f"    ⚠ {rule}")
        prop_def = merged.get(key)
        if prop_def and prop_def.constraints:
            for c in prop_def.constraints:
                lines.append(f"    ⚠ {c.rule}")
        lines.append("")

    lines.append(f"  → Edit:   eforge schema edit {domain}/{type_name}")
    lines.append(f"  → Copy:   eforge schema copy {domain}/{type_name}")
    lines.append(
        f"  → Nodes using this: eforge node list --domain {domain} --type {type_name}"
    )
    return "\n".join(lines)


def _validate_and_retry(
    validator: SchemaValidator,
    schema_dict: dict[str, Any],
    registry: SchemaRegistry,
    *,
    label: str,
) -> bool:
    while True:
        errors = validator.validate(schema_dict, registry=registry)
        if not errors:
            return True
        click.echo(click.style(f"\n✗ {label} validation failed:", fg="red"))
        for err in errors:
            click.echo(f"  {err}")
        if not click.confirm("Fix and retry? [y/n]", default=True):
            return False


@click.group(name="schema")
def schema_group() -> None:
    """Manage eforge schemas — list, show, create, edit, validate, copy, restore."""


@schema_group.command("list")
@click.option(
    "--scope",
    type=click.Choice(["project", "defaults", "builtin", "all"]),
    default="all",
)
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config", "all"]),
    default="all",
)
@click.option("--domain", default=None)
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Include Forge-internal schemas (manifest_node, internal).",
)
@click.option("--project-path", default=".", show_default=True)
@schema_command
def schema_list(
    scope: str,
    category: str,
    domain: str | None,
    show_all: bool,
    project_path: str,
) -> None:
    """List schemas across project, defaults, and builtin scopes."""
    store = _store(project_path)
    cat_filter = None if category == "all" else category
    scope_filter = None if scope == "all" else scope
    rows = store.list_all(
        category=cat_filter, domain=domain, scope=scope_filter
    )
    hidden_internal = 0
    if not show_all:
        hidden_internal = sum(1 for row in rows if row.get("internal"))
        rows = [row for row in rows if not row.get("internal")]

    click.echo(f"\n  Schemas ({len(rows)} total):\n")
    click.echo(
        f"  {'CATEGORY':<10}{'DOMAIN':<16}{'TYPE':<22}{'SOURCE'}"
    )
    for row in rows:
        entry = row["entry"]
        source = _source_display(store, entry)
        type_label = row["type"]
        if show_all and row.get("internal"):
            type_label = f"{type_label} [internal]"
        click.echo(
            f"  {row['category']:<10}{row['domain']:<16}"
            f"{type_label:<22}{source}"
        )
    click.echo("")
    click.echo("  ★ = your project schema")
    click.echo("")
    click.echo("  Add your own: eforge schema create <domain>/<type>")
    click.echo(
        "  Project schemas live in .forge/observations/schemas/"
    )
    click.echo(f"\n  Total: {len(rows)} schemas")
    if hidden_internal and not show_all:
        click.echo(
            click.style(
                "\n  Forge-internal schemas hidden. Use --all to show.",
                fg="bright_black",
            )
        )


@schema_group.command("show")
@click.argument("schema_ref")
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config"]),
    default=None,
)
@click.option("--project-path", default=".", show_default=True)
@click.option("--raw", is_flag=True, help="Dump raw yaml.")
@schema_command
def schema_show(
    schema_ref: str,
    category: str | None,
    project_path: str,
    raw: bool,
) -> None:
    """Show schema details for DOMAIN/TYPE."""
    dom, typ = parse_schema_ref(schema_ref)
    store = _store(project_path)
    reg = _registry(project_path)
    cat = resolve_category(reg, dom, typ, category)
    entry = store.find(cat, dom, typ)
    if entry is None:
        click.echo(f"Schema not found: {cat}/{dom}/{typ}")
        click.echo("Try: eforge schema list")
        raise SystemExit(1)
    if raw:
        click.echo(yaml.safe_dump(entry.data, sort_keys=False))
        return
    click.echo()
    click.echo(_format_show(entry, reg))


@schema_group.command("create")
@click.argument("schema_ref", required=False)
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config"]),
    default=None,
)
@click.option("--project-path", default=".", show_default=True)
@click.option("-y", "--yes", is_flag=True, help="Batch mode (defaults only).")
@schema_command
def schema_create(
    schema_ref: str | None,
    category: str | None,
    project_path: str,
    yes: bool,
) -> None:
    """Create a new project schema interactively."""
    store = _store(project_path)
    reg = _registry(project_path)
    mode = PromptMode.BATCH if yes else PromptMode.INTERACTIVE
    engine = PromptEngine(mode=mode)
    builder = SchemaBuilder(engine)

    prefilled: dict[str, Any] = {}
    if schema_ref:
        dom, typ = parse_schema_ref(schema_ref)
        prefilled["domain"] = dom
        prefilled["type_name"] = typ
        if category:
            prefilled["category"] = category

    dom = prefilled.get("domain")
    typ = prefilled.get("type_name")
    cat = prefilled.get("category") or "domain"
    if dom and typ:
        existing = store.find(cat, dom, typ) or store.find(
            resolve_category(reg, dom, typ, cat), dom, typ
        )
        if existing and existing.scope in ("project", "defaults"):
            if not click.confirm(
                f"Schema {dom}/{typ} exists. Edit it? [y/n]", default=True
            ):
                raise SystemExit(0)
            ctx = click.get_current_context()
            ctx.invoke(
                schema_edit,
                schema_ref=f"{dom}/{typ}",
                category=cat,
                project_path=project_path,
            )
            return

    schema_dict = builder.build(prefilled=prefilled or None)
    cat = schema_dict.get("category") or "domain"
    dom = str(schema_dict.get("domain"))
    typ = str(schema_dict.get("type_name"))
    validator = SchemaValidator(reg)
    if not _validate_and_retry(validator, schema_dict, reg, label="Schema"):
        raise SystemExit(1)

    path = store.write_dict(schema_dict, scope="project")
    _reload(project_path)
    click.echo(
        click.style(f"\n✓ Schema created: {cat}/{dom}/{typ}", fg="green")
    )
    click.echo(f"  path: {path}")
    click.echo(f"  Use: eforge node add <name> --kind {dom}/{typ}")
    click.echo(f"  Or:  eforge schema show {dom}/{typ}")


@schema_group.command("edit")
@click.argument("schema_ref")
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config"]),
    default=None,
)
@click.option("--project-path", default=".", show_default=True)
@schema_command
def schema_edit(
    schema_ref: str,
    category: str | None,
    project_path: str,
) -> None:
    """Edit a schema (project or defaults; package copies to project first)."""
    dom, typ = parse_schema_ref(schema_ref)
    store = _store(project_path)
    reg = _registry(project_path)
    cat = resolve_category(reg, dom, typ, category)
    entry = store.find(cat, dom, typ)
    if entry is None:
        click.echo(f"Schema not found: {cat}/{dom}/{typ}")
        raise SystemExit(1)

    if entry.scope in ("builtin", "package"):
        click.echo("This is a read-only built-in schema.")
        if not click.confirm("Copy to project first? [y/n]", default=True):
            raise SystemExit(0)
        ctx = click.get_current_context()
        ctx.invoke(
            schema_copy,
            schema_ref=f"{dom}/{typ}",
            category=cat,
            project_path=project_path,
        )
        entry = store.find(cat, dom, typ)
        if entry is None or entry.scope != "project":
            raise SystemExit(1)

    original = copy.deepcopy(entry.data)
    write_scope = "project" if entry.scope == "project" else "defaults"
    if entry.scope == "legacy":
        write_scope = "project"
        click.echo("Legacy schema will be copied to project scope on save.")

    engine = PromptEngine(mode=PromptMode.INTERACTIVE)
    builder = SchemaBuilder(engine)
    updated = builder.build(prefilled=original)
    diff_lines = builder.diff(original, updated)
    if not diff_lines:
        click.echo("No changes made.")
        return
    click.echo("\nChanges:")
    for line in diff_lines:
        click.echo(f"  {line}")
    if not click.confirm("Save changes?", default=True):
        click.echo("Aborted.")
        return

    validator = SchemaValidator(reg)
    if not _validate_and_retry(validator, updated, reg, label="Schema"):
        raise SystemExit(1)

    if write_scope == "project":
        path = store.write_dict(updated, scope="project")
    else:
        path = store.write_dict(updated, scope="defaults")
    _reload(project_path)
    click.echo(click.style(f"\n✓ Schema updated: {dom}/{typ}", fg="green"))
    click.echo(_format_show(store.find(cat, dom, typ) or entry, reg))


@schema_group.command("validate")
@click.argument("schema_ref", required=False)
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config"]),
    default=None,
)
@click.option("--all", "validate_all", is_flag=True, help="Validate all project+defaults.")
@click.option("--project-path", default=".", show_default=True)
@schema_command
def schema_validate(
    schema_ref: str | None,
    category: str | None,
    project_path: str,
    validate_all: bool,
) -> None:
    """Validate one schema or all project/defaults schemas."""
    store = _store(project_path)
    reg = _registry(project_path)
    validator = SchemaValidator(reg)

    if validate_all:
        entries = list(
            store.iter_all(
                category=None if not category or category == "all" else category,
                scope=None,
            )
        )
        targets = [e for e in entries if e.scope in ("project", "defaults", "legacy")]
        click.echo(f"\n  Validating {len(targets)} schemas...")
        valid = 0
        invalid = 0
        for entry in targets:
            label = f"{entry.category}/{entry.domain}/{entry.type_name}"
            errors = validator.validate(entry.data, registry=reg)
            if errors:
                invalid += 1
                click.echo(click.style(f"  ✗ {label}", fg="red"))
                for err in errors:
                    click.echo(f"    {err}")
                click.echo(
                    click.style(
                        f"    → Fix: eforge schema edit {entry.domain}/{entry.type_name}",
                        fg="yellow",
                    )
                )
            else:
                valid += 1
                click.echo(click.style(f"  ✓ {label}", fg="green"))
        click.echo(f"\n  {valid} valid, {invalid} invalid.")
        if invalid:
            raise SystemExit(1)
        return

    if not schema_ref:
        click.echo("Provide DOMAIN/TYPE or use --all")
        raise SystemExit(1)

    dom, typ = parse_schema_ref(schema_ref)
    cat = resolve_category(reg, dom, typ, category)
    entry = store.find(cat, dom, typ)
    if entry is None:
        click.echo(f"Schema not found: {dom}/{typ}")
        raise SystemExit(1)
    errors = validator.validate(entry.data, registry=reg)
    label = f"{entry.category}/{entry.domain}/{entry.type_name}"
    if errors:
        click.echo(click.style(f"\n✗ {label}", fg="red"))
        for err in errors:
            click.echo(f"  {err}")
        click.echo(
            click.style(
                f"  → Fix: eforge schema edit {dom}/{typ}",
                fg="yellow",
            )
        )
        raise SystemExit(1)
    click.echo(click.style(f"\n✓ Valid: {label}", fg="green"))


@schema_group.command("copy")
@click.argument("schema_ref")
@click.option(
    "--category",
    type=click.Choice(["domain", "entity", "config"]),
    default=None,
)
@click.option("--project-path", default=".", show_default=True)
@schema_command
def schema_copy(
    schema_ref: str,
    category: str | None,
    project_path: str,
) -> None:
    """Copy a schema into project scope."""
    dom, typ = parse_schema_ref(schema_ref)
    store = _store(project_path)
    reg = _registry(project_path)
    cat = resolve_category(reg, dom, typ, category)
    entry = store.find(cat, dom, typ)
    if entry is None:
        click.echo(f"Schema not found: {dom}/{typ}")
        raise SystemExit(1)

    dest = store._schema_path(cat, dom, typ, scope="project")
    if dest.is_file() and not click.confirm("Overwrite project copy? [y/n]", default=False):
        click.echo("Aborted.")
        return

    if entry.scope == "project":
        shutil_copy = copy.deepcopy(entry.data)
        path = store.write_dict(shutil_copy, scope="project")
    else:
        from_scope = "defaults" if entry.scope == "defaults" else "package"
        try:
            path = store.copy_to(cat, dom, typ, from_scope=from_scope, to_scope="project")
        except FileNotFoundError:
            path = store.write_dict(copy.deepcopy(entry.data), scope="project")

    _reload(project_path)
    click.echo(click.style(f"\n✓ Copied {cat}/{dom}/{typ}", fg="green"))
    click.echo(f"  → {path}")
    click.echo(f"  Now edit: eforge schema edit {dom}/{typ}")


@schema_group.command("restore")
@click.argument("schema_ref", required=False)
@click.option("--all", "restore_all", is_flag=True)
@click.option("--project-path", default=".", show_default=True)
@schema_command
def schema_restore(
    schema_ref: str | None,
    restore_all: bool,
    project_path: str,
) -> None:
    """Restore package defaults into .eforge/schemas/_defaults/."""
    store = _store(project_path)
    if restore_all:
        count = store.restore_all_defaults()
        _reload(project_path)
        click.echo(click.style(f"\n✓ Restored {count} schemas to defaults", fg="green"))
        return

    if not schema_ref:
        click.echo("Provide DOMAIN/TYPE or use --all")
        raise SystemExit(1)

    dom, typ = parse_schema_ref(schema_ref)
    reg = _registry(project_path)
    entry = store.find(resolve_category(reg, dom, typ, None), dom, typ)
    cat = entry.category if entry else resolve_category(reg, dom, typ, None)
    try:
        path = store.restore_default(cat, dom, typ)
    except FileNotFoundError:
        click.echo(f"No package default for {cat}/{dom}/{typ}")
        raise SystemExit(1)
    _reload(project_path)
    pkg = store._schema_path(cat, dom, typ, scope="package")
    click.echo(click.style(f"\n✓ Restored {dom}/{typ} to defaults", fg="green"))
    click.echo(f"  Source: {pkg}")
    click.echo(f"  Restored to: {path}")


from forge.cli_engine import CLIEngine

CLIEngine.register("devtools", schema_group, "schema")
