"""eforge cli — list registered commands and adapter status."""

from __future__ import annotations

import click

from forge.cli_engine import CLIEngine


@click.group(name="cli")
def cli_group() -> None:
    """Introspect the eforge CLI surface."""


@cli_group.command("list")
def cli_list() -> None:
    """List adapters and registered command groups."""
    adapters = CLIEngine.adapters()
    if not adapters:
        click.echo("No CLI adapters registered.")
        return
    for adapter in adapters:
        click.echo(f"\n{adapter}:")
        for name in CLIEngine.commands(adapter):
            click.echo(f"  {name}")


@cli_group.command("status")
def cli_status() -> None:
    """Show adapter registration counts."""
    adapters = CLIEngine.adapters()
    if not adapters:
        click.echo("eforge CLI: no adapters registered")
        return
    click.echo("eforge CLI status:")
    for adapter in adapters:
        names = CLIEngine.commands(adapter)
        click.echo(f"  {adapter}: {len(names)} command(s) — {', '.join(names)}")


from forge.cli_engine import CLIEngine

CLIEngine.register("devtools", cli_group, "cli")
