"""Shoreguard — Open source control plane for NVIDIA OpenShell."""

__version__ = "0.19.0"
