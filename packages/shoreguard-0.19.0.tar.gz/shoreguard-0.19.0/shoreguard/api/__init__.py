"""Shoreguard FastAPI application."""
