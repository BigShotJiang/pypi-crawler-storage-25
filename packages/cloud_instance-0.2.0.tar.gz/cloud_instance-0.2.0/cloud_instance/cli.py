import json
import logging
import platform
import sys
import time

import typer

from . import __version__
from .commands.create import create
from .commands.delete import delete
from .commands.gather import gather
from .commands.modify import modify
from .commands.resize import resize
from .commands.slated import slated
from .models import CloudInstance, Deployment, GroupFilter, InstanceDefaults

EPILOG = "Docs: <https://github.com/fabiog1901/cloud_instance>"

# setup global logger
logger = logging.getLogger("cloud_instance")
logger.setLevel(logging.INFO)


class ShorthandFormatter(logging.Formatter):
    LEVEL_MAP = {
        "DEBUG": "D",
        "INFO": "I",
        "WARNING": "W",
        "ERROR": "E",
        "CRITICAL": "C",
    }

    def format(self, record):
        original_levelname = record.levelname
        record.levelname = self.LEVEL_MAP.get(original_levelname, original_levelname)
        result = super().format(record)
        record.levelname = original_levelname
        return result


# create console handler and set level to debug
ch = logging.FileHandler(filename="/tmp/cloud_instance.log")
ch.setLevel(logging.INFO)

# create formatter
formatter = ShorthandFormatter(
    "%(asctime)s [%(levelname)s] (%(threadName)s) %(filename)s:%(lineno)d %(message)s"
)
formatter.converter = time.gmtime
formatter.default_msec_format = "%s.%03d"

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)
logger.removeHandler(logger.handlers[0])  # Remove the console output

app = typer.Typer(
    epilog=EPILOG,
    no_args_is_help=True,
    help=f"cloud_instance v{__version__}: utility to manage VMs in the cloud.",
)

version: bool = typer.Option(True)


def instances_to_json(instances: list[CloudInstance]) -> str:
    return json.dumps([x.to_dict() for x in instances])


def exit_with_error(error: Exception) -> None:
    print(f"Error: {error}", file=sys.stderr)
    sys.exit(1)


@app.command(
    name="create",
    help="Create the deployment",
    no_args_is_help=True,
)
def cli_create(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
    deployment: str = typer.Option(
        ...,
        help="deployment",
    ),
    defaults: str = typer.Option(
        ...,
        help="defaults",
    ),
    preserve: bool = typer.Option(
        False,
        "--preserve",
        show_default=False,
        help="Whether to preserve existing VMs.",
    ),
):

    logger.info(f"START: create {deployment_id=}")

    try:
        result = create(
            deployment_id,
            Deployment.from_list(json.loads(deployment)),
            InstanceDefaults.from_dict(json.loads(defaults)),
            preserve,
        )
    except Exception as e:
        exit_with_error(e)

    print(instances_to_json(result))

    logger.info(f"COMPLETED: create {deployment_id=}")


@app.command(
    name="gather",
    help="Gather a list of all existing VMs in the specified deployment_id",
    no_args_is_help=True,
)
def cli_gather(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
):

    logger.info(f"START: gather {deployment_id=}")

    try:
        result = gather(deployment_id)
    except Exception as e:
        exit_with_error(e)

    print(instances_to_json(result))

    logger.info(f"COMPLETED: gather {deployment_id=}")


@app.command(
    name="slated",
    help="Return VMs slated to be deleted",
    no_args_is_help=True,
)
def cli_slated(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
    deployment: str = typer.Option(
        ...,
        help="The deployment_id",
    ),
):

    logger.info(f"START: slated {deployment_id=}")

    try:
        result = slated(
            deployment_id,
            Deployment.from_list(json.loads(deployment)),
        )
    except Exception as e:
        exit_with_error(e)

    print(instances_to_json(result))

    logger.info(f"COMPLETED: slated {deployment_id=}")


@app.command(
    name="modify",
    help="Modify instance type",
    no_args_is_help=True,
)
def cli_modify(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
    new_cpus_count: int = typer.Option(
        ...,
        "-c",
        "--cpu-count",
        help="New CPU count.",
    ),
    filter_by_groups: str = typer.Option(
        None,
        "-f",
        "--filter-by-groups",
        help="comma separated list of groups the instance must belong to",
    ),
    sequential: bool = typer.Option(
        True,
        "--no-sequential",
        show_default=False,
        help="Whether to modify instances sequentially.",
    ),
    pause_between: int = typer.Option(
        30,
        "-p",
        "--pause-between",
        help="If sequential, seconds to pause between modifications.",
    ),
    defaults: str = typer.Option(
        ...,
        help="defaults",
    ),
):

    logger.info(f"START: modify {deployment_id=}")

    try:
        modify(
            deployment_id,
            new_cpus_count,
            GroupFilter.from_csv(filter_by_groups),
            sequential,
            pause_between,
            InstanceDefaults.from_dict(json.loads(defaults)),
        )
    except Exception as e:
        exit_with_error(e)

    logger.info(f"COMPLETED: modify {deployment_id=}")


@app.command(
    name="resize",
    help="Resize disk",
    no_args_is_help=True,
)
def cli_resize(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
    new_disk_size: int = typer.Option(
        ...,
        "-s",
        "--disk-size",
        help="New CPU count.",
    ),
    filter_by_groups: str = typer.Option(
        None,
        "-f",
        "--filter-by-groups",
        help="comma separated list of groups the instance must belong to",
    ),
    sequential: bool = typer.Option(
        True,
        "--no-sequential",
        show_default=False,
        help="Whether to modify instances sequentially.",
    ),
    pause_between: int = typer.Option(
        30,
        "-p",
        "--pause-between",
        help="If sequential, seconds to pause between modifications.",
    ),
):

    logger.info(f"START: resize {deployment_id=}")

    try:
        resize(
            deployment_id,
            new_disk_size,
            GroupFilter.from_csv(filter_by_groups),
            sequential,
            pause_between,
        )
    except Exception as e:
        exit_with_error(e)

    logger.info(f"COMPLETED: resize {deployment_id=}")


@app.command(
    name="delete",
    help="Destroy the deployment",
    no_args_is_help=True,
)
def cli_delete(
    deployment_id: str = typer.Option(
        ...,
        "-d",
        "--deployment-id",
        help="The deployment_id",
    ),
):

    logger.info(f"START: delete {deployment_id=}")

    try:
        delete(deployment_id)
    except Exception as e:
        exit_with_error(e)

    logger.info(f"COMPLETED: delete {deployment_id=}")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"cloud_instance : {__version__}")
        typer.echo(f"Python         : {platform.python_version()}")
        raise typer.Exit()


@app.callback()
def version_option(
    _: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=_version_callback,
        help="Print the version and exit",
    ),
) -> None:
    pass


# this is only needed for mkdocs-click
click_app = typer.main.get_command(app)
