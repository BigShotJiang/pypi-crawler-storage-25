# -*- coding: utf-8 -*-

import os
import importlib
import configuration
from bravaweb.utils.log import Debug, Error

class Router:
    _controller_cache = {}

    @classmethod
    def load_routes(cls):
        """
        Percorre o diretório 'controllers' da aplicação no boot e faz o pré-carregamento
        de todos os módulos e suas classes Controller, armazenando em cache.
        Erros críticos são registrados em log e ignorados para não travar a aplicação.
        """
        try:
            if not hasattr(configuration, 'api') or not hasattr(configuration.api, 'directory'):
                return

            controllers_path = os.path.join(configuration.api.directory, "controllers")

            if not os.path.exists(controllers_path):
                Debug("O diretório 'controllers' não foi encontrado. Roteamento dinâmico sem pré-cache.")
                return

            Debug("Iniciando pré-carregamento (Boot) das rotas e controladores...")

            for root, dirs, files in os.walk(controllers_path):
                if '__pycache__' in root:
                    continue

                for file in files:
                    if file.endswith(".py") and file != "__init__.py":
                        rel_dir = os.path.relpath(root, configuration.api.directory)
                        module_name = file[:-3]

                        if rel_dir == ".":
                            module_path = module_name
                        else:
                            module_path = f"{rel_dir.replace(os.sep, '.')}.{module_name}"

                        try:
                            _module = importlib.import_module(module_path)
                            klass = f"{module_name.capitalize()}Controller"

                            if hasattr(_module, klass):
                                _class_ref = getattr(_module, klass)
                                cache_key = f"{module_path}:{klass}"
                                cls._controller_cache[cache_key] = _class_ref
                                Debug(f"Rota em cache pronta: {cache_key}")
                        except Exception as e:
                            Error(f"Erro ao pré-carregar módulo '{module_path}'", e)

            Debug(f"Total de classes controller carregadas: {len(cls._controller_cache)}")

        except Exception as e:
            Error("[CRÍTICO] Falha em Router.load_routes() — aplicação continuará sem pré-cache de rotas", e)

    @classmethod
    def get_controller_class(cls, route_list, klass_name):
        """
        Retorna a referência da classe Controller.
        Busca do cache, ou tenta importar dinamicamente caso não esteja no cache.
        """
        module_path = ".".join(route_list)
        cache_key = f"{module_path}:{klass_name}"

        if cache_key in cls._controller_cache:
            return cls._controller_cache[cache_key]

        # Fallback (Lazy Load)
        try:
            _module = importlib.import_module(module_path)
            if hasattr(_module, klass_name):
                _class_ref = getattr(_module, klass_name)
                cls._controller_cache[cache_key] = _class_ref
                return _class_ref
        except Exception as e:
            if getattr(configuration.api, "debug", False):
                raise e
            # Emite log do erro caso o arquivo exista mas contenha erros de sintaxe ou imports inválidos
            Error(f"Erro ao carregar Controller via rota '{module_path}'", e)

        return None
