import datetime
import configuration

from bravaweb.utils import ResponseCode

from bravaweb.utils.log import *


def _merge_headers(base, extra):
    """Substitui headers existentes em base pelos de extra; adiciona os novos."""
    extra_keys = {k for k, _ in extra}
    merged = [(k, v) for k, v in base if k not in extra_keys]
    merged.extend(extra)
    return merged


async def View(environment, data, headers=None, **args):

    Debug(f"View: Start Response Type {environment.response_type.__name__}")

    if not "token" in args and environment.auth_token:
        args["token"] = environment.auth_token

    response = environment.response_type()

    content = response.Response(data=data, route=environment.route, action=environment.action, **args)

    _headers = [
        response.header,
        (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
        (b"Accept-Ranges", b"bytes"),
        (b"X-Frame-Options", b"Deny")
    ]

    _extra_headers = headers if headers is not None else getattr(configuration.api, "response_headers", None)
    if _extra_headers:
        _headers = _merge_headers(_headers, _extra_headers)

    if environment.origin:
        _headers.append((b"Access-Control-Allow-Origin", environment.origin.encode(configuration.api.encoding)))

    await environment.send({
        'type': 'http.response.start',
        'status': ResponseCode.OK.code,
        'headers': _headers
    })

    await environment.send({
        'type': 'http.response.body',
        'body': content
    })
    
    Debug(f"View: Finalized Response")
