"""Tests for sgn.compose module - composable elements."""

from dataclasses import dataclass

import pytest

from sgn.apps import Pipeline
from sgn.base import TransformElement, SourceElement, SinkElement
from sgn.compose import (
    Compose,
    ComposedSourceElement,
    ComposedTransformElement,
    ComposedSinkElement,
)
from sgn.sinks import CollectSink, NullSink
from sgn.sources import IterSource
from sgn.transforms import CallableTransform


class TestComposedSourceElement:
    """Tests for ComposedSourceElement."""

    def test_source_only(self):
        """A single source can be wrapped as a composed source."""
        source = IterSource(
            name="src",
            source_pad_names=["out"],
            iters={"out": iter([1, 2, 3])},
        )

        composed = Compose(source).as_source(name="composed_src")

        assert isinstance(composed, ComposedSourceElement)
        assert isinstance(composed, SourceElement)
        assert "out" in composed.srcs
        assert len(composed.source_pads) == 1

    def test_source_plus_transform(self):
        """Source + Transform composes into a source."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3, 4, 5])},
            eos_on_empty={"data": True},
        )

        transform = CallableTransform.from_callable(
            name="double",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        composed = Compose().connect(source, transform).as_source(name="doubled_source")

        assert isinstance(composed, ComposedSourceElement)
        assert "data" in composed.srcs

        # Test in pipeline
        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["data"]) == [2, 4, 6, 8, 10]

    def test_source_plus_multiple_transforms(self):
        """Source + multiple transforms compose correctly."""
        source = IterSource(
            name="src",
            source_pad_names=["x"],
            iters={"x": iter([1, 2, 3])},
            eos_on_empty={"x": True},
        )

        add_one = CallableTransform.from_callable(
            name="add_one",
            callable=lambda frame: frame.data + 1 if frame.data is not None else None,
            output_pad_name="x",
            sink_pad_names=["x"],
        )

        square = CallableTransform.from_callable(
            name="square",
            callable=lambda frame: (
                frame.data * frame.data if frame.data is not None else None
            ),
            output_pad_name="x",
            sink_pad_names=["x"],
        )

        # (1+1)^2=4, (2+1)^2=9, (3+1)^2=16
        composed = (
            Compose()
            .connect(source, add_one)
            .connect(add_one, square)
            .as_source(name="processed")
        )

        sink = CollectSink(name="sink", sink_pad_names=["x"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["x"]) == [4, 9, 16]

    def test_source_composition_with_multi_pad(self):
        """Composed source with multiple pads works correctly."""
        source = IterSource(
            name="src",
            source_pad_names=["H1", "L1"],
            iters={
                "H1": iter([1, 2]),
                "L1": iter([10, 20]),
            },
            eos_on_empty={"H1": True, "L1": True},
        )

        # Transform that doubles each channel
        transform = CallableTransform.from_combinations(
            name="double",
            combos=[
                (
                    ("H1",),
                    lambda frame: frame.data * 2 if frame.data is not None else None,
                    "H1",
                ),
                (
                    ("L1",),
                    lambda frame: frame.data * 2 if frame.data is not None else None,
                    "L1",
                ),
            ],
        )

        composed = Compose().connect(source, transform).as_source(name="doubled")

        assert set(composed.srcs.keys()) == {"H1", "L1"}

        sink = CollectSink(name="sink", sink_pad_names=["H1", "L1"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["H1"]) == [2, 4]
        assert list(sink.collects["L1"]) == [20, 40]

    def test_invalid_source_composition_with_sink(self):
        """Source composition cannot contain a SinkElement."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
        )

        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        sink = NullSink(name="sink", sink_pad_names=["data"])

        with pytest.raises(TypeError, match="cannot contain SinkElement"):
            (Compose().connect(source, transform).connect(transform, sink).as_source())

    def test_invalid_source_composition_first_not_source(self):
        """Source composition must contain at least one SourceElement."""
        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        with pytest.raises(TypeError, match="requires at least one SourceElement"):
            Compose(transform).as_source()

    def test_also_expose_source_pads(self):
        """Source pads can be exposed even when internally linked."""
        # Create a source with a data output
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        # Create an internal transform that consumes the source pad
        internal_transform = CallableTransform.from_callable(
            name="internal",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="processed",
            sink_pad_names=["data"],
        )

        # Without also_expose_source_pads, the "data" pad would be filtered out
        # because it's internally linked to the transform
        composed = (
            Compose()
            .connect(source, internal_transform)
            .as_source(
                name="composed",
                also_expose_source_pads=["src:src:data"],
            )
        )

        # Both pads should be available:
        # - "data" from the source (exposed via also_expose_source_pads)
        # - "processed" from the transform (normal boundary pad)
        assert "data" in composed.srcs
        assert "processed" in composed.srcs

        # Test that it works in a pipeline - need to connect both pads
        sink = CollectSink(name="sink", sink_pad_names=["data", "processed"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        # Both outputs should be collected
        assert list(sink.collects["data"]) == [1, 2, 3]
        assert list(sink.collects["processed"]) == [2, 4, 6]


class TestComposedTransformElement:
    """Tests for ComposedTransformElement."""

    def test_single_transform(self):
        """A single transform can be wrapped."""
        transform = CallableTransform.from_callable(
            name="double",
            callable=lambda frame: frame.data * 2,
            output_pad_name="out",
            sink_pad_names=["in"],
        )

        composed = Compose(transform).as_transform(name="composed_transform")

        assert isinstance(composed, ComposedTransformElement)
        assert isinstance(composed, TransformElement)
        assert "in" in composed.snks
        assert "out" in composed.srcs

    def test_transform_chain(self):
        """Multiple transforms compose into a single transform."""
        t1 = CallableTransform.from_callable(
            name="add_one",
            callable=lambda frame: frame.data + 1 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        t2 = CallableTransform.from_callable(
            name="double",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        composed = Compose().connect(t1, t2).as_transform(name="add_then_double")

        assert "data" in composed.snks
        assert "data" in composed.srcs

        # Test in pipeline
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )
        sink = CollectSink(name="sink", sink_pad_names=["data"])

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.connect(composed, sink)
        pipeline.run()

        # (1+1)*2=4, (2+1)*2=6, (3+1)*2=8
        assert list(sink.collects["data"]) == [4, 6, 8]

    def test_invalid_transform_with_source(self):
        """Transform composition cannot contain SourceElement."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1])},
        )

        with pytest.raises(TypeError, match="cannot contain SourceElements"):
            Compose(source).as_transform()

    def test_transform_with_internal_sink(self):
        """Transform composition can contain internal sinks (e.g., NullSink).

        This is useful for discarding unused outputs in complex pipelines.
        The transform must still have at least one exposed source pad.
        """
        # Create a transform with two outputs using callmap
        transform = CallableTransform(
            name="dual_output",
            sink_pad_names=["input"],
            callmap={
                "main": lambda frame: (
                    frame.data * 2 if frame.data is not None else None
                ),
                "debug": lambda frame: frame.data if frame.data is not None else None,
            },
            depmap={
                "main": ("input",),
                "debug": ("input",),
            },
        )

        # Discard the debug output via NullSink
        null_sink = NullSink(name="null", sink_pad_names=["debug"])

        # This should work - main output is still exposed
        composed = (
            Compose()
            .connect(transform, null_sink, link_map={"debug": "debug"})
            .as_transform(name="transform_with_discard")
        )

        assert isinstance(composed, ComposedTransformElement)
        assert "input" in composed.snks
        assert "main" in composed.srcs
        assert "debug" not in composed.srcs  # Consumed by NullSink

        # Test in pipeline
        source = IterSource(
            name="src",
            source_pad_names=["input"],
            iters={"input": iter([1, 2, 3])},
            eos_on_empty={"input": True},
        )
        sink = CollectSink(name="sink", sink_pad_names=["main"])

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["main"]) == [2, 4, 6]

    def test_invalid_transform_all_outputs_consumed(self):
        """Transform fails if all source pads are consumed by internal sinks."""
        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )
        sink = NullSink(name="sink", sink_pad_names=["data"])

        # This should fail - sink consumes all outputs, no source pads left
        with pytest.raises(ValueError, match="must have both sink and source pads"):
            Compose().connect(transform, sink).as_transform()

    def test_transform_with_also_expose_source_pads(self):
        """Transform can expose internal source pads via also_expose_source_pads.

        This enables multilink patterns where an internal source pad feeds
        both an internal sink and is exposed externally.
        """
        # Create transforms for a processing chain
        t1 = CallableTransform.from_callable(
            name="t1",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        t2 = CallableTransform.from_callable(
            name="t2",
            callable=lambda frame: frame.data + 10 if frame.data is not None else None,
            output_pad_name="processed",
            sink_pad_names=["data"],
        )

        # Compose with also_expose_source_pads to expose t1's output
        composed = (
            Compose()
            .connect(t1, t2)
            .as_transform(
                name="chain_with_tap",
                also_expose_source_pads=["t1:src:data"],
            )
        )

        # Both t1's output (exposed via also_expose_source_pads) and t2's output
        assert "data" in composed.srcs  # From t1 via also_expose_source_pads
        assert "processed" in composed.srcs  # From t2 (boundary)
        assert "data" in composed.snks  # Input

        # Test in pipeline - need to connect both outputs
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )
        sink = CollectSink(name="sink", sink_pad_names=["data", "processed"])

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.connect(composed, sink)
        pipeline.run()

        # "data" output is t1's output (input * 2): [2, 4, 6]
        # "processed" output is t2's output (t1_output + 10): [12, 14, 16]
        assert list(sink.collects["data"]) == [2, 4, 6]
        assert list(sink.collects["processed"]) == [12, 14, 16]


class TestComposedSinkElement:
    """Tests for ComposedSinkElement."""

    def test_sink_only(self):
        """A single sink can be wrapped."""
        sink = NullSink(name="sink", sink_pad_names=["data"])

        composed = Compose(sink).as_sink(name="composed_sink")

        assert isinstance(composed, ComposedSinkElement)
        assert isinstance(composed, SinkElement)
        assert "data" in composed.snks

    def test_transform_plus_sink(self):
        """Transform + Sink composes into a sink."""
        transform = CallableTransform.from_callable(
            name="double",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        collect = CollectSink(name="collect", sink_pad_names=["data"])

        composed = Compose().connect(transform, collect).as_sink(name="doubling_sink")

        assert isinstance(composed, ComposedSinkElement)
        assert "data" in composed.snks

        # Test in pipeline
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()

        # Access internal sink's data
        assert list(collect.collects["data"]) == [2, 4, 6]

    def test_invalid_sink_with_source_first(self):
        """Sink composition cannot contain SourceElement."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1])},
        )

        sink = NullSink(name="sink", sink_pad_names=["data"])

        with pytest.raises(TypeError, match="cannot contain SourceElement"):
            Compose().connect(source, sink).as_sink()

    def test_invalid_sink_not_ending_with_sink(self):
        """Sink composition must contain at least one SinkElement."""
        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        with pytest.raises(TypeError, match="requires at least one SinkElement"):
            Compose(transform).as_sink()


class TestComposeBuilder:
    """Tests for the Compose builder class."""

    def test_explicit_link_map(self):
        """Explicit link_map can override implicit linking."""
        source = IterSource(
            name="src",
            source_pad_names=["out"],
            iters={"out": iter([1, 2, 3])},
            eos_on_empty={"out": True},
        )

        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="result",
            sink_pad_names=["in"],
        )

        # Explicit mapping: connect "out" -> "in"
        composed = (
            Compose()
            .connect(source, transform, link_map={"in": "out"})
            .as_source(name="explicit")
        )

        assert "result" in composed.srcs

        sink = CollectSink(name="sink", sink_pad_names=["result"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["result"]) == [2, 4, 6]

    def test_compose_preserves_element_identity(self):
        """Internal elements are stored by reference."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1])},
        )

        composed = Compose(source).as_source()

        assert composed.internal_elements[0] is source

    def test_connect_auto_inserts_elements(self):
        """connect() automatically inserts elements not yet in composition."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        # Don't call insert() - connect() should handle it
        composed = Compose().connect(source, transform).as_source()

        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["data"]) == [2, 4, 6]


class TestImplicitLinking:
    """Tests for implicit linking strategies in composition."""

    def test_exact_match_linking(self):
        """Pads with identical names are linked automatically."""
        source = IterSource(
            name="src",
            source_pad_names=["alpha", "beta"],
            iters={"alpha": iter([1]), "beta": iter([2])},
            eos_on_empty={"alpha": True, "beta": True},
        )

        transform = CallableTransform.from_combinations(
            name="t",
            combos=[
                (
                    ("alpha",),
                    lambda frame: frame.data * 10 if frame.data is not None else None,
                    "alpha",
                ),
                (
                    ("beta",),
                    lambda frame: frame.data * 100 if frame.data is not None else None,
                    "beta",
                ),
            ],
        )

        composed = Compose().connect(source, transform).as_source()

        sink = CollectSink(name="sink", sink_pad_names=["alpha", "beta"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["alpha"]) == [10]
        assert list(sink.collects["beta"]) == [200]

    def test_n_to_one_linking(self):
        """Multiple source pads can link to single sink pad."""
        source = IterSource(
            name="src",
            source_pad_names=["a", "b"],
            iters={"a": iter([1, 2]), "b": iter([10, 20])},
        )

        # Transform with single sink that receives from multiple sources
        transform = CallableTransform.from_callable(
            name="passthrough",
            callable=lambda frame: frame.data,
            output_pad_name="out",
            sink_pad_names=["in"],
        )

        # With N-to-1, both a and b would try to connect to "in"
        composed = Compose().connect(source, transform).as_source()

        assert "out" in composed.srcs


class TestEOSPropagation:
    """Tests for End-of-Stream propagation in composed elements."""

    def test_composed_source_eos(self):
        """EOS propagates correctly through composed source."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2])},
            eos_on_empty={"data": True},
        )

        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        composed = Compose().connect(source, transform).as_source()

        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        # Should complete normally with EOS
        assert list(sink.collects["data"]) == [1, 2]

    def test_composed_sink_eos(self):
        """EOS is tracked correctly in composed sink."""
        transform = CallableTransform.from_callable(
            name="t",
            callable=lambda frame: frame.data,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        inner_sink = NullSink(name="inner", sink_pad_names=["data"])

        composed = Compose().connect(transform, inner_sink).as_sink()

        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2])},
            eos_on_empty={"data": True},
        )

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()

        # Pipeline should complete - check internal sink is at EOS
        assert inner_sink.at_eos


class TestIntegration:
    """Integration tests for composed elements with full pipelines."""

    def test_composed_elements_in_complex_pipeline(self):
        """Composed elements work in complex pipeline configurations."""
        # Create a composed source
        raw_source = IterSource(
            name="raw",
            source_pad_names=["signal"],
            iters={"signal": iter([1, 2, 3, 4, 5])},
            eos_on_empty={"signal": True},
        )

        preprocess = CallableTransform.from_callable(
            name="preprocess",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="signal",
            sink_pad_names=["signal"],
        )

        composed_source = (
            Compose()
            .connect(raw_source, preprocess)
            .as_source(name="preprocessed_source")
        )

        # Create a composed transform
        t1 = CallableTransform.from_callable(
            name="t1",
            callable=lambda frame: frame.data + 100 if frame.data is not None else None,
            output_pad_name="signal",
            sink_pad_names=["signal"],
        )

        t2 = CallableTransform.from_callable(
            name="t2",
            callable=lambda frame: frame.data // 2 if frame.data is not None else None,
            output_pad_name="signal",
            sink_pad_names=["signal"],
        )

        composed_transform = (
            Compose().connect(t1, t2).as_transform(name="processing_chain")
        )

        # Create a composed sink
        final_transform = CallableTransform.from_callable(
            name="final",
            callable=lambda frame: frame.data * -1 if frame.data is not None else None,
            output_pad_name="signal",
            sink_pad_names=["signal"],
        )

        collector = CollectSink(name="collector", sink_pad_names=["signal"])

        composed_sink = (
            Compose().connect(final_transform, collector).as_sink(name="output_sink")
        )

        # Build pipeline: composed_source -> composed_transform -> composed_sink
        pipeline = Pipeline()
        pipeline.connect(composed_source, composed_transform)
        pipeline.connect(composed_transform, composed_sink)
        pipeline.run()

        # Calculation: raw -> *2 -> +100 -> //2 -> *-1
        # 1 -> 2 -> 102 -> 51 -> -51
        # 2 -> 4 -> 104 -> 52 -> -52
        # 3 -> 6 -> 106 -> 53 -> -53
        # 4 -> 8 -> 108 -> 54 -> -54
        # 5 -> 10 -> 110 -> 55 -> -55
        expected = [-51, -52, -53, -54, -55]
        assert list(collector.collects["signal"]) == expected

    def test_mixed_composed_and_regular_elements(self):
        """Composed elements work alongside regular elements."""
        # Regular source
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([10, 20, 30])},
            eos_on_empty={"data": True},
        )

        # Composed transform
        t1 = CallableTransform.from_callable(
            name="half",
            callable=lambda frame: frame.data // 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        t2 = CallableTransform.from_callable(
            name="stringify",
            callable=lambda frame: (
                f"value={frame.data}" if frame.data is not None else None
            ),
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        composed_transform = Compose().connect(t1, t2).as_transform()

        # Regular sink
        sink = CollectSink(name="sink", sink_pad_names=["data"])

        pipeline = Pipeline()
        pipeline.connect(source, composed_transform)
        pipeline.connect(composed_transform, sink)
        pipeline.run()

        assert list(sink.collects["data"]) == ["value=5", "value=10", "value=15"]


class TestEdgeCases:
    """Tests for edge cases and validation errors."""

    def test_composed_source_empty_elements(self):
        """ComposedSourceElement with empty elements raises ValueError."""
        with pytest.raises(ValueError, match="requires at least one element"):
            ComposedSourceElement(
                name="empty",
                internal_elements=[],
                internal_links={},
            )

    def test_composed_transform_empty_elements(self):
        """ComposedTransformElement with empty elements raises ValueError."""
        with pytest.raises(ValueError, match="requires at least one element"):
            ComposedTransformElement(
                name="empty",
                internal_elements=[],
                internal_links={},
            )

    def test_composed_sink_empty_elements(self):
        """ComposedSinkElement with empty elements raises ValueError."""
        with pytest.raises(ValueError, match="requires at least one element"):
            ComposedSinkElement(
                name="empty",
                internal_elements=[],
                internal_links={},
            )


class TestNonLinearGraphs:
    """Tests for non-linear graph composition using insert() and connect() API."""

    def test_insert_and_connect_api(self):
        """Test explicit insert() and connect() API for non-linear graphs."""
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        transform = CallableTransform.from_callable(
            name="double",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="data",
            sink_pad_names=["data"],
        )

        # Use explicit insert() and connect()
        composed = (
            Compose()
            .insert(source, transform)
            .connect(source, transform)
            .as_source(name="explicit_compose")
        )

        assert isinstance(composed, ComposedSourceElement)
        assert "data" in composed.srcs

        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        assert list(sink.collects["data"]) == [2, 4, 6]

    def test_multiple_sources_merging(self):
        """Multiple sources can merge into a multi-pad transform."""
        # Two sources with different pads
        source_a = IterSource(
            name="src_a",
            source_pad_names=["a"],
            iters={"a": iter([1, 2])},
            eos_on_empty={"a": True},
        )

        source_b = IterSource(
            name="src_b",
            source_pad_names=["b"],
            iters={"b": iter([10, 20])},
            eos_on_empty={"b": True},
        )

        # Transform with two inputs and two outputs
        transform = CallableTransform.from_combinations(
            name="proc",
            combos=[
                (
                    ("a",),
                    lambda frame: frame.data * 100 if frame.data is not None else None,
                    "a",
                ),
                (
                    ("b",),
                    lambda frame: frame.data + 1 if frame.data is not None else None,
                    "b",
                ),
            ],
        )

        # Compose using connect() - non-linear structure
        composed = (
            Compose()
            .connect(source_a, transform)
            .connect(source_b, transform)
            .as_source(name="merged_source")
        )

        assert isinstance(composed, ComposedSourceElement)
        assert "a" in composed.srcs
        assert "b" in composed.srcs

        sink = CollectSink(name="sink", sink_pad_names=["a", "b"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        # a: 1*100=100, 2*100=200
        # b: 10+1=11, 20+1=21
        assert list(sink.collects["a"]) == [100, 200]
        assert list(sink.collects["b"]) == [11, 21]

    def test_multiple_sinks_composed(self):
        """Multiple sinks can be composed (fan-out pattern)."""
        transform = CallableTransform.from_combinations(
            name="split",
            combos=[
                (
                    ("data",),
                    lambda frame: frame.data * 2 if frame.data is not None else None,
                    "doubled",
                ),
                (
                    ("data",),
                    lambda frame: frame.data * 3 if frame.data is not None else None,
                    "tripled",
                ),
            ],
        )

        sink1 = CollectSink(name="sink_double", sink_pad_names=["doubled"])
        sink2 = CollectSink(name="sink_triple", sink_pad_names=["tripled"])

        # Compose transform with two sinks using connect()
        composed = (
            Compose()
            .connect(transform, sink1)
            .connect(transform, sink2)
            .as_sink(name="multi_sink")
        )

        assert isinstance(composed, ComposedSinkElement)
        assert "data" in composed.snks

        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()

        # sink1 gets doubled: 2, 4, 6
        # sink2 gets tripled: 3, 6, 9
        assert list(sink1.collects["doubled"]) == [2, 4, 6]
        assert list(sink2.collects["tripled"]) == [3, 6, 9]

    def test_composed_sink_multiple_internal_sinks_eos(self):
        """ComposedSinkElement with multiple sinks reports EOS correctly."""
        sink1 = CollectSink(name="sink1", sink_pad_names=["a"])
        sink2 = CollectSink(name="sink2", sink_pad_names=["b"])

        # Split transform - one input, two outputs
        transform = CallableTransform.from_combinations(
            name="split",
            combos=[
                (
                    ("data",),
                    lambda frame: frame.data if frame.data is not None else None,
                    "a",
                ),
                (
                    ("data",),
                    lambda frame: frame.data if frame.data is not None else None,
                    "b",
                ),
            ],
        )

        composed = (
            Compose()
            .connect(transform, sink1)
            .connect(transform, sink2)
            .as_sink(name="multi_out")
        )

        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1])},
            eos_on_empty={"data": True},
        )

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()

        # Both internal sinks should be at EOS after pipeline completes
        assert sink1.at_eos
        assert sink2.at_eos
        assert composed.at_eos

    def test_source_composition_with_same_pad_name(self):
        """Source composition handles elements with same pad names correctly."""
        # Adapted from test_multiple_sources_merging
        source_a = IterSource(
            name="src_a",
            source_pad_names=["a"],
            iters={"a": iter([1, 2])},
            eos_on_empty={"a": True},
        )

        source_b = IterSource(
            name="src_b",
            source_pad_names=["b"],
            iters={"b": iter([10, 20])},
            eos_on_empty={"b": True},
        )

        t_1 = CallableTransform.from_callable(
            name="t_1",
            callable=lambda frame: frame.data * 100 if frame.data is not None else None,
            output_pad_name="a",
            sink_pad_names=["a"],
        )

        t_2 = CallableTransform.from_callable(
            name="t_2",
            callable=lambda frame: frame.data + 1 if frame.data is not None else None,
            output_pad_name="a",
            sink_pad_names=["b"],
        )

        composed = (
            Compose()
            .connect(source_a, t_1)
            .connect(source_b, t_2)
            .as_source(
                name="merged_source",
                update_pad_names={"a": dict(a="t_1:src:a", b="t_2:src:a")},
            )
        )

        assert isinstance(composed, ComposedSourceElement)
        assert composed.source_pad_names == ["a", "b"]

        sink = CollectSink(name="sink", sink_pad_names=["a", "b"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()

        # a: 1*100=100, 2*100=200
        # b: 10+1=11, 20+1=21
        assert list(sink.collects["a"]) == [100, 200]
        assert list(sink.collects["b"]) == [11, 21]

    def test_transform_composition_with_same_pad_name(self):
        """Transform composition handles elements with same pad names correctly."""
        t_1 = CallableTransform.from_callable(
            name="double_1",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="out",
            sink_pad_names=["in"],
        )

        t_2 = CallableTransform.from_callable(
            name="double_2",
            callable=lambda frame: frame.data * 2 if frame.data is not None else None,
            output_pad_name="out",
            sink_pad_names=["in"],
        )

        t_3 = CallableTransform.from_callable(
            name="triple_1",
            callable=lambda frame: frame.data * 3 if frame.data is not None else None,
            output_pad_name="out_v2",
            sink_pad_names=["in_v2"],
        )

        t_4 = CallableTransform.from_callable(
            name="triple_2",
            callable=lambda frame: frame.data * 3 if frame.data is not None else None,
            output_pad_name="out_v2",
            sink_pad_names=["in_v2"],
        )

        composed = (
            Compose()
            .insert(t_1, t_2)
            .connect(t_1, t_3, link_map={"in_v2": "out"})
            .connect(t_2, t_4, link_map={"in_v2": "out"})
            .as_transform(
                name="multi_same_pad",
                update_pad_names={
                    "in": dict(in_1="double_1:snk:in", in_2="double_2:snk:in"),
                    "out_v2": dict(
                        out_v2_1="triple_1:src:out_v2", out_v2_2="triple_2:src:out_v2"
                    ),
                },
            )
        )

        assert composed.sink_pad_names == ["in_1", "in_2"]
        assert composed.source_pad_names == ["out_v2_1", "out_v2_2"]

        source_1 = IterSource(
            name="src_1",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        source_2 = IterSource(
            name="src_2",
            source_pad_names=["data"],
            iters={"data": iter([4, 5, 6])},
            eos_on_empty={"data": True},
        )

        sink_1 = CollectSink(name="sink_1", sink_pad_names=["data"])
        sink_2 = CollectSink(name="sink_2", sink_pad_names=["data"])

        pipeline = Pipeline()
        pipeline.connect(source_1, composed, link_map={"in_1": "data"})
        pipeline.connect(source_2, composed, link_map={"in_2": "data"})
        pipeline.connect(composed, sink_1, link_map={"data": "out_v2_1"})
        pipeline.connect(composed, sink_2, link_map={"data": "out_v2_2"})
        pipeline.run()

        # source1 gets sextupled: 6, 12, 18
        # source2 gets sextupled: 24, 30, 36
        assert list(sink_1.collects["data"]) == [6, 12, 18]
        assert list(sink_2.collects["data"]) == [24, 30, 36]

        with pytest.raises(KeyError, match="not found in boundary pads"):
            composed = (
                Compose()
                .insert(t_1, t_2)
                .connect(t_1, t_3, link_map={"in_v2": "out"})
                .connect(t_2, t_4, link_map={"in_v2": "out"})
                .as_transform(
                    name="multi_same_pad", update_pad_names={"not_a_key": dict()}
                )
            )

    def test_sink_composition_with_same_pad_name(self):
        """Sink composition handles elements with same pad names correctly."""
        # Adapted from test_multiple_sinks_composed
        transform = CallableTransform.from_combinations(
            name="split",
            combos=[
                (
                    ("data",),
                    lambda frame: frame.data * 2 if frame.data is not None else None,
                    "doubled",
                ),
                (
                    ("data",),
                    lambda frame: frame.data * 3 if frame.data is not None else None,
                    "tripled",
                ),
            ],
        )

        sink1 = CollectSink(name="sink_double", sink_pad_names=["doubled"])
        sink2 = CollectSink(name="sink_triple", sink_pad_names=["tripled"])

        # Compose transform with two sinks using connect()
        composed = (
            Compose()
            .connect(transform, sink1)
            .connect(transform, sink2)
            .as_sink(
                name="multi_sink",
                update_pad_names={
                    "data": dict(
                        to_be_doubled="split:snk:data", to_be_tripled="split:snk:data"
                    ),
                },
            )
        )

        assert isinstance(composed, ComposedSinkElement)
        assert composed.sink_pad_names == ["to_be_doubled", "to_be_tripled"]

        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )

        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()

        # sink1 gets doubled: 2, 4, 6
        # sink2 gets tripled: 3, 6, 9
        assert list(sink1.collects["doubled"]) == [2, 4, 6]
        assert list(sink2.collects["tripled"]) == [3, 6, 9]


class TestComposedElementSubclassing:
    """Tests for the subclass pattern using _build(), self.insert(), self.connect()."""

    def test_subclassed_source(self):
        """A subclass of ComposedSourceElement using _build() constructs correctly."""

        @dataclass(repr=False, kw_only=True)
        class DoubledSource(ComposedSourceElement):
            factor: int = 2

            def _build(self):
                source = IterSource(
                    name=f"{self.name}_raw",
                    source_pad_names=["data"],
                    iters={"data": iter([1, 2, 3])},
                    eos_on_empty={"data": True},
                )
                transform = CallableTransform.from_callable(
                    name=f"{self.name}_scale",
                    callable=lambda frame, f=self.factor: (
                        frame.data * f if frame.data is not None else None
                    ),
                    output_pad_name="data",
                    sink_pad_names=["data"],
                )
                self.connect(source, transform)

        composed = DoubledSource(name="ds", factor=3)
        assert isinstance(composed, ComposedSourceElement)
        assert isinstance(composed, SourceElement)
        assert "data" in composed.srcs

        # Run in pipeline
        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(composed, sink)
        pipeline.run()
        assert list(sink.collects["data"]) == [3, 6, 9]

    def test_subclassed_transform(self):
        """ComposedTransformElement subclass with _build() works."""

        @dataclass(repr=False, kw_only=True)
        class ScaleAndOffset(ComposedTransformElement):
            factor: int = 2
            offset: int = 10

            def _build(self):
                scale = CallableTransform.from_callable(
                    name=f"{self.name}_scale",
                    callable=lambda frame, f=self.factor: (
                        frame.data * f if frame.data is not None else None
                    ),
                    output_pad_name="data",
                    sink_pad_names=["data"],
                )
                add = CallableTransform.from_callable(
                    name=f"{self.name}_offset",
                    callable=lambda frame, o=self.offset: (
                        frame.data + o if frame.data is not None else None
                    ),
                    output_pad_name="data",
                    sink_pad_names=["data"],
                )
                self.connect(scale, add)

        composed = ScaleAndOffset(name="so", factor=3, offset=100)
        assert isinstance(composed, ComposedTransformElement)
        assert isinstance(composed, TransformElement)
        assert "data" in composed.srcs
        assert "data" in composed.snks

        # Run in pipeline
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )
        sink = CollectSink(name="sink", sink_pad_names=["data"])
        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.connect(composed, sink)
        pipeline.run()
        assert list(sink.collects["data"]) == [103, 106, 109]

    def test_subclassed_sink(self):
        """A subclass of ComposedSinkElement using _build() constructs correctly."""

        @dataclass(kw_only=True)
        class ScaleAndCollect(ComposedSinkElement):
            factor: int = 2

            def _build(self):
                scale = CallableTransform.from_callable(
                    name=f"{self.name}_scale",
                    callable=lambda frame, f=self.factor: (
                        frame.data * f if frame.data is not None else None
                    ),
                    output_pad_name="data",
                    sink_pad_names=["data"],
                )
                self._collector = CollectSink(
                    name=f"{self.name}_collect",
                    sink_pad_names=["data"],
                )
                self.connect(scale, self._collector)

        composed = ScaleAndCollect(name="sc", factor=5)
        assert isinstance(composed, ComposedSinkElement)
        assert isinstance(composed, SinkElement)
        assert "data" in composed.snks

        # Run in pipeline
        source = IterSource(
            name="src",
            source_pad_names=["data"],
            iters={"data": iter([1, 2, 3])},
            eos_on_empty={"data": True},
        )
        pipeline = Pipeline()
        pipeline.connect(source, composed)
        pipeline.run()
        assert list(composed._collector.collects["data"]) == [5, 10, 15]

    def test_validate_is_called(self):
        """_validate() is called and can raise ValueError."""

        @dataclass(repr=False, kw_only=True)
        class ValidatedTransform(ComposedTransformElement):
            factor: int = 1

            def _validate(self):
                if self.factor <= 0:
                    raise ValueError("factor must be positive")

            def _build(self):
                t = CallableTransform.from_callable(
                    name=f"{self.name}_t",
                    callable=lambda frame: frame.data,
                    output_pad_name="out",
                    sink_pad_names=["in"],
                )
                self.insert(t)

        # Valid construction works
        vt = ValidatedTransform(name="vt", factor=5)
        assert "out" in vt.srcs

        # Invalid construction raises
        with pytest.raises(ValueError, match="factor must be positive"):
            ValidatedTransform(name="vt_bad", factor=-1)

    def test_expose_source_pad(self):
        """expose_source_pad() makes internally-linked pads available externally."""

        @dataclass(repr=False, kw_only=True)
        class TransformWithExposedPad(ComposedTransformElement):
            def _build(self):
                # First transform outputs on "data" and "extra"
                main = CallableTransform.from_combinations(
                    name=f"{self.name}_main",
                    combos=[
                        (
                            ("in",),
                            lambda frame: (
                                frame.data * 2 if frame.data is not None else None
                            ),
                            "data",
                        ),
                        (
                            ("in",),
                            lambda frame: (
                                frame.data * 10 if frame.data is not None else None
                            ),
                            "extra",
                        ),
                    ],
                )

                # Consumer of "data" — this internally links main:src:data
                consumer = CallableTransform.from_callable(
                    name=f"{self.name}_consumer",
                    callable=lambda frame: (
                        frame.data + 1 if frame.data is not None else None
                    ),
                    output_pad_name="out",
                    sink_pad_names=["data"],
                )
                self.connect(main, consumer, link_map={"data": "data"})

                # Expose "data" even though it's internally linked
                self.expose_source_pad(f"{self.name}_main:src:data")

        composed = TransformWithExposedPad(name="ep")
        # Should have: "data" (exposed), "extra" (boundary), "out" (boundary)
        assert "data" in composed.srcs
        assert "extra" in composed.srcs
        assert "out" in composed.srcs
        assert "in" in composed.snks

    def test_insert_only(self):
        """Elements can be added with insert() without connect()."""

        @dataclass(repr=False, kw_only=True)
        class MultiSource(ComposedSourceElement):
            def _build(self):
                s1 = IterSource(
                    name=f"{self.name}_s1",
                    source_pad_names=["a"],
                    iters={"a": iter([1, 2])},
                    eos_on_empty={"a": True},
                )
                s2 = IterSource(
                    name=f"{self.name}_s2",
                    source_pad_names=["b"],
                    iters={"b": iter([10, 20])},
                    eos_on_empty={"b": True},
                )
                self.insert(s1)
                self.insert(s2)

        composed = MultiSource(name="ms")
        assert "a" in composed.srcs
        assert "b" in composed.srcs

    def test_empty_build_raises(self):
        """A subclass with empty _build() raises ValueError."""

        @dataclass(repr=False, kw_only=True)
        class EmptyBuild(ComposedTransformElement):
            def _build(self):
                pass  # doesn't insert anything

        with pytest.raises(ValueError, match="requires at least one element"):
            EmptyBuild(name="empty")
