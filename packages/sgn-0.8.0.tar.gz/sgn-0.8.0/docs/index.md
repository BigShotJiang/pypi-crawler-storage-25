# SGN Documentation

SGN is a lightweight Python library for building streaming data pipelines.
Connect sources, transforms, and sinks into clear workflows while SGN handles
asynchronous execution under the hood. Zero external dependencies.

## Installation

```bash
pip install sgn
```

??? info "Developer Installation"
    ```bash
    git clone https://git.ligo.org/greg/sgn.git
    cd sgn
    pip install -e ".[dev]"
    ```

    The `dev` extras include tools for docs, linting, testing, and monitoring.
    Run `make` to verify your development environment.

## Where to Start

- **[Tutorial](tutorials/first-pipeline.md)** — New to SGN? Build your first pipeline step by step.
- **[User Guide](user/connect-elements.md)** — Solve specific problems: connecting elements, grouping, parallelism, and more.
- **[Background](background/architecture.md)** — Understand how SGN works: execution model, core concepts, and design decisions.
- **[Reference](reference/elements.md)** — Elements and auto-generated API documentation.

## Related Libraries

- [`sgn-ts`](https://git.ligo.org/greg/sgn-ts): TimeSeries utilities for SGN
- [`sgn-ligo`](https://git.ligo.org/greg/sgn-ligo): LSC specific utilities for SGN
