# Element Composition

SGN lets you combine multiple elements into a single reusable unit. The
resulting composed element behaves like any other element.

There are two approaches:

- **Subclassing** (recommended for reusable elements): define a dataclass that
  inherits from `ComposedSourceElement`, `ComposedTransformElement`, or
  `ComposedSinkElement` and override `_build()`.
- **Compose builder** (for one-off compositions): use the `Compose` fluent API.

## Composition Types

| Compose with | Element type | Builder method |
|---|---|---|
| Source + Transform(s) | `ComposedSourceElement` | `.as_source()` |
| Transform(s) | `ComposedTransformElement` | `.as_transform()` |
| Transform(s) + Sink | `ComposedSinkElement` | `.as_sink()` |

## Subclassing

The recommended way to create reusable composed elements. Define your
parameters as dataclass fields, override `_build()` to wire internal elements
using `self.insert()` and `self.connect()`. The resulting object IS an element
— pass it directly to `pipeline.connect()`.

### Composed Transform

```python
from dataclasses import dataclass

from sgn import Pipeline, IterSource, CollectSink
from sgn.compose import ComposedTransformElement
from sgn.transforms import CallableTransform


@dataclass(repr=False, kw_only=True)
class ScaleAndOffset(ComposedTransformElement):
    """Multiplies input by a factor then adds an offset."""

    factor: float = 1.0
    offset: float = 0.0

    def _validate(self):
        if self.factor == 0:
            raise ValueError("factor must be non-zero")

    def _build(self):
        scale = CallableTransform.from_callable(
            name=f"{self.name}_scale",
            callable=lambda frame, f=self.factor: (
                frame.data * f if frame.data is not None else None
            ),
            output_pad_name="data",
            sink_pad_names=["data"],
        )
        add = CallableTransform.from_callable(
            name=f"{self.name}_add",
            callable=lambda frame, o=self.offset: (
                frame.data + o if frame.data is not None else None
            ),
            output_pad_name="data",
            sink_pad_names=["data"],
        )
        self.connect(scale, add)


# Use like any element — no .element needed
to_fahrenheit = ScaleAndOffset(
    name="to_f", factor=9 / 5, offset=32
)

source = IterSource(
    name="celsius",
    source_pad_names=["data"],
    iters={"data": iter([0, 20, 100])},
    eos_on_empty={"data": True},
)
sink = CollectSink(name="sink", sink_pad_names=["data"])

pipeline = Pipeline()
pipeline.connect(source, to_fahrenheit)
pipeline.connect(to_fahrenheit, sink)
pipeline.run()

assert list(sink.collects["data"]) == [32.0, 68.0, 212.0]
```

### Composed Source

```python
from dataclasses import dataclass

from sgn import Pipeline, IterSource, CollectSink
from sgn.compose import ComposedSourceElement
from sgn.transforms import CallableTransform


@dataclass(repr=False, kw_only=True)
class ScaledSource(ComposedSourceElement):
    """A source that produces values scaled by a factor."""

    values: tuple = (1, 2, 3)
    factor: float = 1.0

    def _build(self):
        raw = IterSource(
            name=f"{self.name}_raw",
            source_pad_names=["data"],
            iters={"data": iter(self.values)},
            eos_on_empty={"data": True},
        )
        scale = CallableTransform.from_callable(
            name=f"{self.name}_scale",
            callable=lambda frame, f=self.factor: (
                frame.data * f if frame.data is not None else None
            ),
            output_pad_name="data",
            sink_pad_names=["data"],
        )
        self.connect(raw, scale)


source = ScaledSource(name="src", values=(10, 20, 30), factor=0.5)
sink = CollectSink(name="sink", sink_pad_names=["data"])

pipeline = Pipeline()
pipeline.connect(source, sink)
pipeline.run()

assert list(sink.collects["data"]) == [5.0, 10.0, 15.0]
```

### Composed Sink

```python
from dataclasses import dataclass

from sgn import Pipeline, IterSource, CollectSink
from sgn.compose import ComposedSinkElement
from sgn.transforms import CallableTransform


@dataclass(kw_only=True)
class FormattedCollector(ComposedSinkElement):
    """Formats data as strings before collecting."""

    prefix: str = "value"

    def _build(self):
        fmt = CallableTransform.from_callable(
            name=f"{self.name}_fmt",
            callable=lambda frame, p=self.prefix: (
                f"{p}={frame.data}" if frame.data is not None else None
            ),
            output_pad_name="data",
            sink_pad_names=["data"],
        )
        self._collector = CollectSink(
            name=f"{self.name}_collect", sink_pad_names=["data"]
        )
        self.connect(fmt, self._collector)


source = IterSource(
    name="src",
    source_pad_names=["data"],
    iters={"data": iter([1, 2, 3])},
    eos_on_empty={"data": True},
)
sink = FormattedCollector(name="sink", prefix="result")

pipeline = Pipeline()
pipeline.connect(source, sink)
pipeline.run()

assert list(sink._collector.collects["data"]) == [
    "result=1",
    "result=2",
    "result=3",
]
```

## Compose Builder

For one-off compositions where you don't need a reusable class, use the
`Compose` fluent API.

### Basic Composition

```python
from sgn import Pipeline, Compose, IterSource, CollectSink
from sgn.transforms import CallableTransform

source = IterSource(
    name="src",
    source_pad_names=["data"],
    iters={"data": iter([1, 2, 3, 4, 5])},
    eos_on_empty={"data": True},
)

double = CallableTransform.from_callable(
    name="double",
    callable=lambda frame: frame.data * 2 if frame.data is not None else None,
    output_pad_name="data",
    sink_pad_names=["data"],
)

add_ten = CallableTransform.from_callable(
    name="add_ten",
    callable=lambda frame: frame.data + 10 if frame.data is not None else None,
    output_pad_name="data",
    sink_pad_names=["data"],
)

# Compose: source -> double -> add_ten as a single source element
composed_source = (
    Compose()
    .connect(source, double)
    .connect(double, add_ten)
    .as_source(name="processed_source")
)

sink = CollectSink(name="sink", sink_pad_names=["data"])
pipeline = Pipeline()
pipeline.connect(composed_source, sink)
pipeline.run()

assert list(sink.collects["data"]) == [12, 14, 16, 18, 20]
```

## All Three Types Together

```python
from sgn import Pipeline, Compose, IterSource, CollectSink
from sgn.transforms import CallableTransform

# ComposedSourceElement: source that doubles values
raw_source = IterSource(
    name="raw", source_pad_names=["data"],
    iters={"data": iter([1, 2, 3, 4, 5])},
)
double_t = CallableTransform.from_callable(
    name="double", callable=lambda f: f.data * 2 if f.data is not None else None,
    output_pad_name="data", sink_pad_names=["data"],
)
composed_source = Compose().connect(raw_source, double_t).as_source("doubled_source")

# ComposedTransformElement: adds 100 then negates
add_100 = CallableTransform.from_callable(
    name="add_100", callable=lambda f: f.data + 100 if f.data is not None else None,
    output_pad_name="data", sink_pad_names=["data"],
)
negate = CallableTransform.from_callable(
    name="negate", callable=lambda f: -f.data if f.data is not None else None,
    output_pad_name="data", sink_pad_names=["data"],
)
composed_transform = Compose().connect(add_100, negate).as_transform("add_and_negate")

# ComposedSinkElement: formats before collecting
formatter = CallableTransform.from_callable(
    name="format",
    callable=lambda f: f"result={f.data}" if f.data is not None else None,
    output_pad_name="data", sink_pad_names=["data"],
)
collector = CollectSink(name="collector", sink_pad_names=["data"])
composed_sink = Compose().connect(formatter, collector).as_sink("formatting_sink")

# Wire it all up
pipeline = Pipeline()
pipeline.connect(composed_source, composed_transform)
pipeline.connect(composed_transform, composed_sink)
pipeline.run()

assert list(collector.collects["data"]) == [
    "result=-102", "result=-104", "result=-106", "result=-108", "result=-110"
]
```

## Merging Multiple Sources

```python
from sgn import Pipeline, Compose, IterSource, CollectSink
from sgn.transforms import CallableTransform

temps = IterSource(name="temps", source_pad_names=["temp"],
                   iters={"temp": iter([20, 25, 30])}, eos_on_empty={"temp": True})
humids = IterSource(name="humid", source_pad_names=["humid"],
                    iters={"humid": iter([50, 60, 70])}, eos_on_empty={"humid": True})

converter = CallableTransform.from_combinations(
    name="convert",
    combos=[
        (("temp",), lambda f: f.data * 9/5 + 32 if f.data is not None else None, "temp"),
        (("humid",), lambda f: f"{f.data}%" if f.data is not None else None, "humid"),
    ],
)

weather_source = (
    Compose()
    .connect(temps, converter)
    .connect(humids, converter)
    .as_source("weather_data")
)

sink = CollectSink(name="sink", sink_pad_names=["temp", "humid"])
pipeline = Pipeline()
pipeline.connect(weather_source, sink)
pipeline.run()

assert list(sink.collects["temp"]) == [68.0, 77.0, 86.0]
assert list(sink.collects["humid"]) == ["50%", "60%", "70%"]
```

## Subclassing vs Compose Builder

Use **subclassing** when you want a reusable, parameterized element (like the
`ScaleAndOffset` example above). Use the **Compose builder** for one-off
compositions or quick prototyping.

## Tips

- Always handle `None` data in callables (appears in EOS and gap frames).
- `connect()` auto-inserts elements — no need to call `insert()` separately.
- Use meaningful names for composed elements to help with
  [visualization](visualize-pipelines.md).
- Override `_validate()` in subclasses to check parameters before the
  internal graph is built.
- Use `self.expose_source_pad("element:src:pad")` in `_build()` for
  multilink patterns where a source pad feeds both an internal sink and
  external consumers.
