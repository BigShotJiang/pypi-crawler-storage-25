import sys
import pytest
from unittest.mock import patch, MagicMock
from psinfo import ProcessInfo


def test_parser_accepts_name_positional():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql"])
    assert args.name == "mysql"


def test_parser_accepts_user_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["--user", "root"])
    assert args.user == "root"


def test_parser_top_defaults_to_none():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql"])
    assert args.top is None


def test_parser_top_accepts_value():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--top", "5"])
    assert args.top == 5


def test_parser_top_short_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "-T", "10"])
    assert args.top == 10


def test_parser_expand_defaults_to_false():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql"])
    assert args.expand is False


def test_parser_expand_accepts_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--expand"])
    assert args.expand is True


def test_parser_tree_defaults_to_false():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql"])
    assert args.tree is False


def test_parser_tree_accepts_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--tree"])
    assert args.tree is True


def test_parser_accepts_port_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["--port", "3306"])
    assert args.port == 3306


def test_parser_accepts_pid_flag():
    from psinfo import build_parser
    args = build_parser().parse_args(["--pid", "1234"])
    assert args.pid == 1234


def test_parser_watch_defaults_to_2():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--watch"])
    assert args.watch == 2.0


def test_parser_watch_accepts_custom_interval():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--watch", "5"])
    assert args.watch == 5.0


def test_parser_sort_defaults_to_cpu():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql"])
    assert args.sort == "cpu"


def test_parser_sort_accepts_mem():
    from psinfo import build_parser
    args = build_parser().parse_args(["mysql", "--sort", "mem"])
    assert args.sort == "mem"


def test_main_calls_find_by_name(mocker):
    from psinfo import main
    mock_find = mocker.patch("psinfo.find_by_name", return_value=[])
    mocker.patch("psutil.net_connections", return_value=[])
    with patch("sys.argv", ["psinfo", "mysql"]):
        main()
    mock_find.assert_called_once_with("mysql")


def test_main_calls_find_by_user(mocker):
    from psinfo import main
    mock_find = mocker.patch("psinfo.find_by_user", return_value=[])
    with patch("sys.argv", ["psinfo", "--user", "root"]):
        main()
    mock_find.assert_called_once_with("root")


def test_main_calls_find_by_pid(mocker):
    from psinfo import main
    proc = ProcessInfo(
        pid=1234, name="test", cmdline=[], username="user",
        cpu_percent=0.0, mem_percent=0.0, rss_mb=0.0,
        num_threads=1, create_time=0.0, num_fds=0
    )
    mock_find = mocker.patch("psinfo.find_by_pid", return_value=proc)
    with patch("sys.argv", ["psinfo", "--pid", "1234"]):
        main()
    mock_find.assert_called_once_with(1234)


def test_main_calls_find_by_port(mocker):
    from psinfo import main
    mock_find = mocker.patch("psinfo.find_by_port", return_value=None)
    with patch("sys.argv", ["psinfo", "--port", "3306"]):
        main()
    mock_find.assert_called_once_with(3306)


def test_main_exits_1_when_pid_not_found(mocker):
    from psinfo import main
    mocker.patch("psinfo.find_by_pid", return_value=None)
    with patch("sys.argv", ["psinfo", "--pid", "9999"]):
        with pytest.raises(SystemExit) as exc:
            main()
    assert exc.value.code == 1
