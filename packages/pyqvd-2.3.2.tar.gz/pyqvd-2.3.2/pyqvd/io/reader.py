"""
Module for reading QVD files into memory. Contains the required logic to parse the binary data of a QVD file.
"""

import math
import struct
from collections.abc import Iterator
from pathlib import Path
from typing import Union, List, BinaryIO
import xml.etree.ElementTree as ET
from pyqvd.qvd import (QvdTable, QvdValue, IntegerValue, DoubleValue, StringValue,
                       DualIntegerValue, DualDoubleValue, QvdTableHeader, QvdFieldHeader,
                       NumberFormat, LineageInfo, TimeValue, DateValue, TimestampValue,
                       IntervalValue, MoneyValue)

class QvdFileReaderIterator(Iterator):
    """
    Iterator class for reading QVD files into memory. Parses the binary data of a QVD file and
    converts it into a :class:`.QvdTable` object.
    """
    def __init__(self, reader: "QvdFileReader", chunk_size: int):
        """
        Constructs a new QVD file parser iterator.

        :param reader: The QVD file reader.
        :param chunk_size: The size of the chunks to read as number of records.
        """
        self._reader = reader
        self._chunk_size = chunk_size
        self._current_chunk = 0

    def __next__(self):
        # pylint: disable-next=protected-access
        if self._current_chunk * self._chunk_size >= self._reader._header.no_of_records:
            # pylint: disable-next=protected-access
            self._reader._stream.close()
            raise StopIteration

        # pylint: disable-next=protected-access
        chunk = self._reader._parse_index_table_next_chunk(self._chunk_size)
        self._current_chunk += 1

        # pylint: disable-next=protected-access
        data = [self._reader._decode_record(record) for record in chunk]
        # pylint: disable-next=protected-access
        columns = [field.field_name for field in self._reader._header.fields]

        return QvdTable(data, columns)

    def __len__(self):
        return math.ceil(self._reader._header.no_of_records / self._chunk_size)

class QvdFileReader:
    """
    Class for reading QVD files into memory. Parses the binary data of a QVD file and converts it into a
    :class:`.QvdTable` object.

    :param source: The source to the QVD file. Either a file path (str or Path) or a BinaryIO object.
    :param chunk_size: Optional chunk size if the data should be read in chunks. The chunk size is
        given as number of records.
    """
    def __init__(self, source: Union[str, Path, BinaryIO], chunk_size: int = None):
        """
        Constructs a new QVD file parser. The source can be either a file path (str or Path) or a BinaryIO object.

        :param source: The source to the QVD file.
        """
        # Convert Path objects to strings for compatibility with existing code
        if isinstance(source, Path):
            source = str(source)

        self._source: Union[str, BinaryIO] = source
        self._stream: BinaryIO = None
        self._chunk_size: int = chunk_size
        self._stream_buffer: bytes = b""
        self._symbol_table_offset: int = None
        self._index_table_offset: int = None
        self._field_masks: List[int] = None

        self._header_buffer: bytes = None
        self._header: QvdTableHeader = None
        self._symbol_table_buffer: bytes = None
        self._symbol_table: List[List[QvdValue]] = None
        self._index_table_buffer: bytes = None
        self._index_table: List[List[int]] = None

    def _read_header_data(self):
        """
        Reads the header data of the QVD file into memory.
        """
        # pylint: disable-next=invalid-name
        HEADER_DELIMITER = "\r\n\0"
        delimiter_bytes = str.encode(HEADER_DELIMITER)

        blocks = []

        while True:
            block = self._stream.read(512)

            if not block:
                break

            blocks.append(block)

            # Check if we've found the delimiter
            buffer = b"".join(blocks)
            pos = buffer.find(delimiter_bytes)

            if pos != -1:
                end = pos + len(delimiter_bytes)
                self._header_buffer = buffer[:end]
                self._symbol_table_offset = end
                # Preserve bytes read past the delimiter for sequential consumption
                self._stream_buffer = buffer[end:]
                return

        if not blocks:
            raise ValueError("The XML header section does not exist or is not properly delimited from the binary data.")

        # If we get here, delimiter not found
        raise ValueError("The XML header section does not exist or is not properly delimited from the binary data.")

    def _parse_header(self):
        """
        Parses the header of the QVD file.
        """
        self._read_header_data()

        header_xml: str = ET.fromstring(self._header_buffer.decode()[:-1])

        self._header = QvdTableHeader()
        self._header.qv_build_no = int(header_xml.find("QvBuildNo").text, 10)
        self._header.creator_doc = header_xml.find("CreatorDoc").text
        self._header.create_utc_time = header_xml.find("CreateUtcTime").text
        self._header.source_create_utc_time = header_xml.find("SourceCreateUtcTime").text
        self._header.source_file_utc_time = header_xml.find("SourceFileUtcTime").text
        self._header.stale_utc_time = header_xml.find("StaleUtcTime").text
        self._header.table_name = header_xml.find("TableName").text
        self._header.source_file_size = int(header_xml.find("SourceFileSize").text, 10)

        self._header.fields = []
        self._field_masks = []

        for field_xml in header_xml.find("Fields"):
            field = QvdFieldHeader()
            field.field_name = field_xml.find("FieldName").text
            field.bit_offset = int(field_xml.find("BitOffset").text, 10)
            field.bit_width = int(field_xml.find("BitWidth").text, 10)
            field.bias = int(field_xml.find("Bias").text, 10)

            number_format_xml = field_xml.find("NumberFormat")
            field.number_format = NumberFormat()
            field.number_format.type = number_format_xml.find("Type").text
            field.number_format.n_dec = int(number_format_xml.find("nDec").text, 10)
            field.number_format.use_thou = int(number_format_xml.find("UseThou").text, 10)
            field.number_format.fmt = number_format_xml.find("Fmt").text
            field.number_format.dec = number_format_xml.find("Dec").text
            field.number_format.thou = number_format_xml.find("Thou").text

            field.no_of_symbols = int(field_xml.find("NoOfSymbols").text, 10)
            field.offset = int(field_xml.find("Offset").text, 10)
            field.length = int(field_xml.find("Length").text, 10)
            field.comment = field_xml.find("Comment").text
            field.tags = [tag.text for tag in field_xml.find("Tags")]

            # Precompute field masks for efficient bit extraction later
            mask = (1 << field.bit_width) - 1 if field.bit_width else 0
            self._field_masks.append(mask)

            self._header.fields.append(field)

        self._header.compression = header_xml.find("Compression").text
        self._header.record_byte_size = int(header_xml.find("RecordByteSize").text, 10)
        self._header.no_of_records = int(header_xml.find("NoOfRecords").text, 10)
        self._header.no_of_fields = len(self._header.fields)
        self._header.offset = int(header_xml.find("Offset").text, 10)
        self._header.length = int(header_xml.find("Length").text, 10)
        self._header.comment = header_xml.find("Comment").text

        self._header.lineage = []

        for lineage_xml in header_xml.find("Lineage"):
            lineage = LineageInfo()
            lineage.discriminator = lineage_xml.find("Discriminator").text
            lineage.statement = lineage_xml.find("Statement").text

            self._header.lineage.append(lineage)

        self._index_table_offset = self._symbol_table_offset + self._header.offset

    def _read_stream(self, n: int) -> bytes:
        """
        Reads exactly n bytes from the stream, consuming the internal buffer first.

        :param n: Number of bytes to read.
        :return: The bytes read.
        """
        result = bytearray()

        if self._stream_buffer:
            if len(self._stream_buffer) >= n:
                result.extend(self._stream_buffer[:n])
                self._stream_buffer = self._stream_buffer[n:]
                return bytes(result)

            result.extend(self._stream_buffer)
            n -= len(self._stream_buffer)
            self._stream_buffer = b""

        while n > 0:
            chunk = self._stream.read(n)

            if not chunk:
                break

            result.extend(chunk)
            n -= len(chunk)

        return bytes(result)

    def _read_symbol_table_data(self):
        """
        Reads the symbol table data of the QVD file into memory.
        """
        self._symbol_table_buffer = self._read_stream(self._header.offset)

    def _parse_symbol_table(self):
        """
        Parses the symbol table of the QVD file.
        """
        self._read_symbol_table_data()

        self._symbol_table = [None] * self._header.no_of_fields

        for field_index, field in enumerate(self._header.fields):
            symbols: List[QvdValue] = []
            pointer = field.offset

            while pointer < field.offset + field.length:
                symbol_type = self._symbol_table_buffer[pointer]
                pointer += 1

                if symbol_type == 1:
                    byte_data = self._symbol_table_buffer[pointer:pointer + 4]
                    value = int.from_bytes(byte_data, byteorder="little", signed=True)
                    pointer += 4
                    symbols.append(IntegerValue(value))
                elif symbol_type == 2:
                    byte_data = self._symbol_table_buffer[pointer:pointer + 8]
                    value = struct.unpack("<d", byte_data)[0]
                    pointer += 8
                    symbols.append(DoubleValue(value))
                elif symbol_type == 4:
                    byte_data = bytearray()

                    while self._symbol_table_buffer[pointer] != 0:
                        byte_data.append(self._symbol_table_buffer[pointer])
                        pointer += 1

                    value = byte_data.decode(encoding="utf-8")
                    pointer += 1
                    symbols.append(StringValue(value))
                elif symbol_type == 5:
                    int_byte_data = self._symbol_table_buffer[pointer:pointer + 4]
                    int_value = int.from_bytes(int_byte_data, byteorder="little", signed=True)
                    pointer += 4

                    string_byte_data = bytearray()
                    while self._symbol_table_buffer[pointer] != 0:
                        string_byte_data.append(self._symbol_table_buffer[pointer])
                        pointer += 1

                    string_value = string_byte_data.decode(encoding="utf-8")
                    pointer += 1

                    if field.number_format.type == "DATE":
                        symbols.append(DateValue(int_value, string_value))
                    elif field.number_format.type == "MONEY":
                        symbols.append(MoneyValue(int_value, string_value))
                    else:
                        symbols.append(DualIntegerValue(int_value, string_value))
                elif symbol_type == 6:
                    double_byte_data = self._symbol_table_buffer[pointer:pointer + 8]
                    double_value = struct.unpack("<d", double_byte_data)[0]
                    pointer += 8

                    string_byte_data = bytearray()
                    while self._symbol_table_buffer[pointer] != 0:
                        string_byte_data.append(self._symbol_table_buffer[pointer])
                        pointer += 1

                    string_value = string_byte_data.decode(encoding="utf-8")
                    pointer += 1

                    if field.number_format.type == "TIMESTAMP":
                        symbols.append(TimestampValue(double_value, string_value))
                    elif field.number_format.type == "TIME":
                        symbols.append(TimeValue(double_value, string_value))
                    elif field.number_format.type == "INTERVAL":
                        symbols.append(IntervalValue(double_value, string_value))
                    elif field.number_format.type == "MONEY":
                        symbols.append(MoneyValue(double_value, string_value))
                    else:
                        symbols.append(DualDoubleValue(double_value, string_value))
                else:
                    raise ValueError("The symbol type byte is not recognized. Unknown data type: " + hex(symbol_type))

            self._symbol_table[field_index] = symbols

    def _read_index_table_data(self):
        """
        Reads the index table data of the QVD file into memory.
        """
        self._index_table_buffer = self._read_stream(self._header.length + 1)

    def _parse_index_table(self):
        """
        Parses the index table of the QVD file.
        """
        self._read_index_table_data()

        # For performance reasons, we gonna bind instance variables to local variables
        # to avoid attribute lookups in the hot loop
        buffer = memoryview(self._index_table_buffer)
        record_size = self._header.record_byte_size
        fields = self._header.fields
        masks = self._field_masks
        n_fields = len(fields)

        # Pre-extract field data to avoid attribute lookups in hot loop
        bit_offsets = [f.bit_offset for f in fields]
        bit_widths = [f.bit_width for f in fields]
        biases = [f.bias for f in fields]

        no_of_records = self._header.no_of_records
        table = [None] * no_of_records
        pointer = 0
        row_index = 0
        buffer_len = len(buffer)

        while pointer < buffer_len:
            record_buffer = buffer[pointer:pointer + record_size]

            # Convert bytes to integer
            record_content = int.from_bytes(record_buffer, byteorder="little")

            # Preallocate instead of append
            record_indices = [0] * n_fields

            for i in range(n_fields):
                if bit_widths[i] == 0:
                    symbol_index = 0
                else:
                    # Extract the symbol index for the field using bit manipulation and the precomputed field masks
                    symbol_index = (record_content >> bit_offsets[i]) & masks[i]

                record_indices[i] = symbol_index + biases[i]

            table[row_index] = record_indices
            pointer += record_size
            row_index += 1

        self._index_table = table

    def _read_index_table_next_chunk_data(self, chunk_size: int) -> bytes:
        """
        Reads the next chunk of the index table data sequentially from the stream.

        :param chunk_size: The size of the chunk as number of records.
        :return: The chunk of the index table.
        """
        return self._read_stream(chunk_size * self._header.record_byte_size)

    def _parse_index_table_next_chunk(self, chunk_size: int) -> List[List[int]]:
        """
        Parses the next chunk of the index table sequentially from the stream.

        :param chunk_size: The size of the chunk as number of records.
        :return: The chunk of the index table.
        """
        chunk_buffer = self._read_index_table_next_chunk_data(chunk_size)

        # For performance reasons, we gonna bind instance variables to local variables
        # to avoid attribute lookups in the hot loop
        record_size = self._header.record_byte_size
        fields = self._header.fields
        masks = self._field_masks

        n_fields = len(fields)

        # Pre-extract field data to avoid attribute lookups in hot loop
        bit_offsets = [f.bit_offset for f in fields]
        bit_widths = [f.bit_width for f in fields]
        biases = [f.bias for f in fields]

        buffer_len = len(chunk_buffer)
        number_of_records = buffer_len // record_size
        chunk: List[List[int]] = [None] * number_of_records
        pointer = 0
        row_index = 0

        while pointer < buffer_len:
            record_buffer = chunk_buffer[pointer:pointer + record_size]

            # Convert bytes to integer
            record_content = int.from_bytes(record_buffer, byteorder="little")

            record_indices = [0] * n_fields

            for i in range(n_fields):
                if bit_widths[i] == 0:
                    symbol_index = 0
                else:
                    # Extract the symbol index for the field using bit manipulation and the precomputed field masks
                    symbol_index = (record_content >> bit_offsets[i]) & masks[i]

                record_indices[i] = symbol_index + biases[i]

            chunk[row_index] = record_indices
            pointer += record_size
            row_index += 1

        return chunk

    def _decode_record(self, record: List[int]) -> List[QvdValue]:
        """
        Decodes a record from the index table.
        """
        symbol_table = self._symbol_table

        return [
            None if symbol_index < 0 else symbol_table[field_index][symbol_index]
            for field_index, symbol_index in enumerate(record)
        ]

    def read(self) -> Union[QvdTable, Iterator[QvdTable]]:
        """
        Reads the QVD file and returns its data as a :class:`.QvdTable` object.

        :return: The data table of the QVD file or an iterator for reading the data in chunks.
        """
        if isinstance(self._source, str):
            self._stream = open(self._source, "rb")
        else:
            self._stream = self._source

        self._parse_header()
        self._parse_symbol_table()

        if self._chunk_size is None:
            self._parse_index_table()

            self._stream.close()

            data = [self._decode_record(record) for record in self._index_table]
            columns = [field.field_name for field in self._header.fields]

            return QvdTable(data, columns)
        else:
            return QvdFileReaderIterator(self, self._chunk_size)
