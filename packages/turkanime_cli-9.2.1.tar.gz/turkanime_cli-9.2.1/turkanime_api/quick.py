import debugpy;debugpy.listen(("localhost", 5678))
import turkanime_api as ta; b = ta.Bolum("yakusoku-no-neverland-1-bolum")
import turkanime_api as ta; b = ta.Bolum("niwatori-fighter-1-bolum")

{'Csrf-Token': 'EqdGHqwZJvydjfbmuYsZeGvBxDxnQXeARRqUNbhRYnPEWqdDnYFEKVBaUPCAGTZA', 'cf_clearance': 'dull'}
/sources/{MASK}/false


hdvid
/sources/bHRxNkRscm5raHZ0VFNGL0VWV1lNalhxSzE4U1dIMDVVSU50OUxVckg2MnFIczR6TXd2ci9ON3J0Wm5NeDQwajo6Si1Bb2N4RzlwUTFtVkZkeg/false


https://www.turkanime.tv/player/MWh5ODVJS3pBWHJ5QmJNS1VNS1NLeW1OT2xOQi92RUU1R2pnWmVtMlBxQT06OlozTlRwT0d0cVdlcG9YQ1o

λ curl 'https://www.turkanime.tv/sources/Q2FQQ3czdDgxbk9iUXFmUGFadjVZVGZ1bG9DdUxiZE91TWxSMUZob2dLND06OlNJd1k2M1FiUkdRQ1pyT1Y/true' /
-H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0' /
-H 'X-Requested-With: XMLHttpRequest'  / 
-H 'Csrf-Token: EqdGHqwZJvydjfbmuYsZeGvBxDxnQXeARRqUNbhRYnPEWqdDnYFEKVBaUPCAGTZA'  / 
-H 'Cookie: PHPSESSID=i3ogbkgqjk7lufocumvo97qetg'



#alucard
res = '{"response":{"status":true,"referrer":"turkanime.tv","preload":"metadata","resumeId":"751b664c170a0c527cb425c60f64bd221287dc89cbe80f341dea37551e01246b","snapshot":true,"name":"\\u0130yi seyirler dileriz...","sources":[{"file":"https:\\/\\/alucard.click\\/video\\/13277278243402\\/1080.mp4","label":"1080p","type":"video\\/mp4"},{"file":"https:\\/\\/alucard.click\\/video\\/13277278243402\\/720.mp4","label":"720p","type":"video\\/mp4","default":true},{"file":"https:\\/\\/alucard.click\\/video\\/13277278243402\\/480.mp4","label":"480p","type":"video\\/mp4"},{"file":"https:\\/\\/alucard.click\\/video\\/13277278243402\\/360.mp4","label":"360p","type":"video\\/mp4"},{"file":"https:\\/\\/alucard.click\\/video\\/13277278243402\\/alucard.mp4","label":"Alucard","type":"video\\/mp4"}]}}'
{
  "response": {
    "status": true,
    "referrer": "turkanime.tv",
    "preload": "metadata",
    "resumeId": "751b664c170a0c527cb425c60f64bd221287dc89cbe80f341dea37551e01246b",
    "snapshot": true,
    "name": "\\u0130yi seyirler dileriz...",
    "sources": [
      {
        "file": "https:\\/\\/alucard.click\\/video\\/13277278243402\\/1080.mp4",
        "label": "1080p",
        "type": "video\\/mp4"
      },
      {
        "file": "https:\\/\\/alucard.click\\/video\\/13277278243402\\/720.mp4",
        "label": "720p",
        "type": "video\\/mp4",
        "default": true
      },
      {
        "file": "https:\\/\\/alucard.click\\/video\\/13277278243402\\/480.mp4",
        "label": "480p",
        "type": "video\\/mp4"
      },
      {
        "file": "https:\\/\\/alucard.click\\/video\\/13277278243402\\/360.mp4",
        "label": "360p",
        "type": "video\\/mp4"
      },
      {
        "file": "https:\\/\\/alucard.click\\/video\\/13277278243402\\/alucard.mp4",
        "label": "Alucard",
        "type": "video\\/mp4"
      }
    ]
  }
}


#bankai
res = '{"response":{"status":true,"referrer":"turkanime.co","preload":"auto","snapshot":true,"resumeId":"","name":"\\u0130yi seyirler dileriz...",
"image":"https:\\/\\/lh3.googleusercontent.com\\/drive-storage\\/AJQWtBMswAkYoXE_E4J-RBpzPc7mruHMiY639gqM40igPvN3Yh6F8h1uXIdF03dzpH66p2LwB9_lIwFZNczuJ75nYZUOnv9xO5tdakQBApBK=s512","track":[{"file":"","kind":"thumbnails"}],
"sources":[{"file":"https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=18&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&dur=1415.813&lmt=1774718909380163&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0006224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Cdur%2Clmt&sig=AHEqNM4wRQIgc7UNKIPMcicQA0PeO81dv7ACEuC-zpfr298nmVmZPnECIQCDWck98s1rqVLlDoVTPgc4r4mXVwJx32jjcKbpRIsUHQ==&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIgYfL27XuLUDY8jX-Y_S58BRikMKakRVDnHu-La4_1HDcCIQDYHIcseub1FnBoLJAXbBwOHoDnp2ER0ib2ERKt4eCuFA==","label":"360p","type":"video\\/mp4"},
{"file":"https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=22&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&cnr=14&dur=1415.836&lmt=1774719333177604&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0016224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Ccnr%2Cdur%2Clmt&sig=AHEqNM4wRAIgJoy4B44UzO1cRnr3_qfKMjayHq6eOt3vEvcqMJQFHSQCIG_Igbs1J9QHl_xlb704SIGSP4nS1iu7RUnyQlbLX1KR&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIhAJRJ7G_LSXGvprrA0Vvp9ZpWwmnK0hg-Nj5drv2dKWkJAiArQQhrRvEMVcOXq441G7re22O9MDB8typmLVxMhz3w-w==","label":"720p","type":"video\\/mp4"},
{"file":"https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=37&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&cnr=14&dur=1415.836&lmt=1774719357668138&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0016224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Ccnr%2Cdur%2Clmt&sig=AHEqNM4wRQIgWKHNt5NuwaPj7KBrBELBAvBgmTJWLTvGu3s4EQM1bPgCIQC2wGxTA9s4yjvj3-vRUca1vMwwGnKOBNiSUqyCx1_fEg==&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIgPnPN-Ibj3g1RZNEecQx2Tlk9cw4Z9pKh7sJCsAVyRHcCIQCieL3LYbr8e31JWuEifG5yJLgFHgV32D3YQTNvM-nmYA==","label":"1080p","type":"video\\/mp4"}]}}'

{
  "response": {
    "status": true,
    "referrer": "turkanime.co",
    "preload": "auto",
    "snapshot": true,
    "resumeId": "",
    "name": "\\u0130yi seyirler dileriz...",
    "image": "https:\\/\\/lh3.googleusercontent.com\\/drive-storage\\/AJQWtBMswAkYoXE_E4J-RBpzPc7mruHMiY639gqM40igPvN3Yh6F8h1uXIdF03dzpH66p2LwB9_lIwFZNczuJ75nYZUOnv9xO5tdakQBApBK=s512",
    "track": [
      {
        "file": "",
        "kind": "thumbnails"
      }
    ],
    "sources": [
      {
        "file": "https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=18&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&dur=1415.813&lmt=1774718909380163&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0006224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Cdur%2Clmt&sig=AHEqNM4wRQIgc7UNKIPMcicQA0PeO81dv7ACEuC-zpfr298nmVmZPnECIQCDWck98s1rqVLlDoVTPgc4r4mXVwJx32jjcKbpRIsUHQ==&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIgYfL27XuLUDY8jX-Y_S58BRikMKakRVDnHu-La4_1HDcCIQDYHIcseub1FnBoLJAXbBwOHoDnp2ER0ib2ERKt4eCuFA==",
        "label": "360p",
        "type": "video\\/mp4"
      },
      {
        "file": "https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=22&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&cnr=14&dur=1415.836&lmt=1774719333177604&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0016224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Ccnr%2Cdur%2Clmt&sig=AHEqNM4wRAIgJoy4B44UzO1cRnr3_qfKMjayHq6eOt3vEvcqMJQFHSQCIG_Igbs1J9QHl_xlb704SIGSP4nS1iu7RUnyQlbLX1KR&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIhAJRJ7G_LSXGvprrA0Vvp9ZpWwmnK0hg-Nj5drv2dKWkJAiArQQhrRvEMVcOXq441G7re22O9MDB8typmLVxMhz3w-w==",
        "label": "720p",
        "type": "video\\/mp4"
      },
      {
        "file": "https:\\/\\/rr2---sn-woc7kn7y.c.docs.google.com\\/videoplayback?expire=1776113526&ei=Ri3daaGxMLHh0u8PzYTR6Q4&ip=104.28.163.91&id=1fd125fefe3cc628&itag=37&source=webdrive&requiressl=yes&xpc=EghonaK1InoBAQ==&met=1776102726%2C&mh=Re&mm=32%2C26&mn=sn-woc7kn7y%2Csn-5ualdnll&ms=su%2Conr&mv=m&mvi=2&pl=24&rms=su%2Csu&ttl=transient&susc=dr&driveid=1xcE9etL3mvSQz3JCqR5y5bGLPTNt3jae&app=explorer&eaua=7LLTIMdC1kU&mime=video\\/mp4&vprv=1&prv=1&rqh=1&cnr=14&dur=1415.836&lmt=1774719357668138&mt=1776102311&fvip=3&subapp=UNKNOWN&txp=0016224&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cttl%2Csusc%2Cdriveid%2Capp%2Ceaua%2Cmime%2Cvprv%2Cprv%2Crqh%2Ccnr%2Cdur%2Clmt&sig=AHEqNM4wRQIgWKHNt5NuwaPj7KBrBELBAvBgmTJWLTvGu3s4EQM1bPgCIQC2wGxTA9s4yjvj3-vRUca1vMwwGnKOBNiSUqyCx1_fEg==&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms&lsig=APaTxxMwRQIgPnPN-Ibj3g1RZNEecQx2Tlk9cw4Z9pKh7sJCsAVyRHcCIQCieL3LYbr8e31JWuEifG5yJLgFHgV32D3YQTNvM-nmYA==",
        "label": "1080p",
        "type": "video\\/mp4"
      }
    ]
  }
}