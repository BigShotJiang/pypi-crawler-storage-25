# zOS/core/L1_Foundation/c_zLoader/loader_modules/cache_base.py

"""
Base class for cache implementations with common patterns.

This module provides a shared foundation for all cache implementations in the
zLoader subsystem, extracting common patterns to reduce duplication and ensure
consistency across cache tiers.

Purpose
-------
The CacheBase class serves as Tier 2.5 (Cache Base Class) in the zLoader architecture,
providing shared infrastructure for SystemCache, PinnedCache, and SchemaCache. It
extracts ~50 lines of duplicated code per cache implementation into a reusable base.

Architecture
------------
**Tier 2.5 - Cache Base Class**
    - Position: Base class for Tier 2 cache implementations
    - Dependencies: zConfig constants
    - Used By: SystemCache, PinnedCache, SchemaCache (all Tier 2)
    - Purpose: DRY for stats, session management, pattern matching, logging

Key Responsibilities
--------------------
1. **Stats Tracking Infrastructure**: Common _hits, _misses, _evictions tracking
2. **Session Namespace Helpers**: Consistent session storage initialization
3. **Pattern Matching**: Shared wildcard pattern matching logic
4. **Hit Rate Calculation**: Standardized hit rate formatting
5. **Logging Helpers**: Consistent debug/info/error logging patterns

Shared Patterns Extracted
--------------------------
**Stats Collection**:
    - _hits: Cache hit counter
    - _misses: Cache miss counter
    - _evictions: Entry eviction counter
    - get_stats(): Standardized stats dictionary format

**Session Management**:
    - _ensure_namespace(): Initialize cache namespace in session
    - _get_cache_dict(): Safe access to cache dictionary
    - _get_stats_dict(): Safe access to stats dictionary

**Pattern Matching**:
    - _pattern_matches(): Wildcard pattern matching (prefix/suffix/contains)
    - Supports: "ui_*", "*_plugin", "*test*"

**Hit Rate Calculation**:
    - _calculate_hit_rate(): Returns formatted percentage string
    - Formula: hits / (hits + misses) * 100

Design Decisions
----------------
1. **Composition Over Strict Inheritance**: Subclasses can override or ignore
   base methods as needed. No forced method signatures.

2. **Protected Members**: All base class members use _ prefix to indicate
   they're internal infrastructure, not public API.

3. **No Abstract Methods**: No forced interface since cache types have different
   semantics (get vs get_alias vs get_connection).

4. **Graceful Defaults**: All methods return safe defaults on error, never
   raising exceptions that could break cache operations.

5. **Session-Based Storage**: All caches use session dict for persistence and
   isolation, not class attributes.

External Usage
--------------
**Used By**:
    - loader_cache_system.py: Inherits for stats + pattern matching
    - loader_cache_pinned.py: Inherits for stats + session helpers
    - loader_cache_schema.py: Inherits for stats + logging helpers

Integration Points
------------------
**SystemCache**:
    - Uses: _ensure_namespace, _pattern_matches, _calculate_hit_rate
    - Extends: Adds LRU eviction, mtime checking

**PinnedCache**:
    - Uses: _ensure_namespace, _pattern_matches, _calculate_hit_rate
    - Extends: Adds no-eviction semantics, alias management

**SchemaCache**:
    - Uses: _ensure_namespace, _calculate_hit_rate
    - Extends: Adds dual storage, transaction management

Version History
---------------
- v1.6.0: Created cache base class (Phase 2 refactoring - consolidation)
"""

from zOS import Any, Dict
from ..loader_constants import (
    STAT_KEY_HITS,
    STAT_KEY_MISSES,
    STAT_KEY_HIT_RATE,
)


class CacheBase:
    """
    Base class for cache implementations with shared patterns.
    
    Provides common infrastructure for stats tracking, session management,
    pattern matching, and logging helpers. Subclasses inherit these patterns
    to reduce duplication and ensure consistency.
    
    Attributes
    ----------
    session : Dict[str, Any]
        Session dictionary for cache storage and stats
    logger : Any
        Logger instance for debug/info/error messages
    namespace : str
        Cache namespace key in session dict (e.g., "system_cache")
    _hits : int
        Cache hit counter (incremented on successful get)
    _misses : int
        Cache miss counter (incremented on failed get)
    _evictions : int
        Entry eviction counter (incremented on LRU eviction)
    
    Notes
    -----
    **Usage Pattern**:
        ```python
        class SystemCache(CacheBase):
            def __init__(self, session, logger, max_size=100):
                super().__init__(session, logger, "system_cache")
                self.max_size = max_size
                self._ensure_namespace()
        ```
    
    **Not Abstract**:
        This is NOT an abstract base class. Subclasses can override or
        ignore base methods as needed. No forced method signatures.
    """

    def __init__(self, session: Dict[str, Any], logger: Any, namespace: str) -> None:
        """
        Initialize cache base with session, logger, and namespace.
        
        Parameters
        ----------
        session : Dict[str, Any]
            Session dictionary for cache storage
        logger : Any
            Logger instance for debug/info/error messages
        namespace : str
            Cache namespace key (e.g., "system_cache", "pinned_cache")
        
        Notes
        -----
        Subclasses should call super().__init__() and then call
        _ensure_namespace() to initialize their storage.
        """
        self.session = session
        self.logger = logger
        self.namespace = namespace

        # Stats tracking
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    # ========================================================================
    # Session Management Helpers
    # ========================================================================

    def _ensure_namespace(self, parent_key: str = "zCache") -> None:
        """
        Ensure cache namespace exists in session dict.
        
        Creates parent_key and namespace if they don't exist, using
        nested dict structure for organization.
        
        Parameters
        ----------
        parent_key : str, optional
            Parent key in session dict (default: "zCache")
        
        Examples
        --------
        >>> self._ensure_namespace()  # Creates session["zCache"][self.namespace]
        >>> self._ensure_namespace("myCache")  # Creates session["myCache"][self.namespace]
        
        Notes
        -----
        **Thread Safety**: NOT thread-safe. Assumes single-threaded access.
        **Idempotent**: Safe to call multiple times, won't overwrite existing data.
        """
        if parent_key not in self.session:
            self.session[parent_key] = {}
        if self.namespace not in self.session[parent_key]:
            self.session[parent_key][self.namespace] = {}

    def _get_cache_dict(self, parent_key: str = "zCache") -> Dict[str, Any]:
        """
        Get cache dictionary from session with safe access.
        
        Parameters
        ----------
        parent_key : str, optional
            Parent key in session dict (default: "zCache")
        
        Returns
        -------
        Dict[str, Any]
            Cache dictionary, or empty dict if not found
        
        Notes
        -----
        **Graceful Degradation**: Returns {} if namespace doesn't exist.
        **Reference**: Returns reference to actual dict, not a copy.
        """
        try:
            return self.session.get(parent_key, {}).get(self.namespace, {})
        except (KeyError, AttributeError):
            return {}

    def _get_stats_dict(self) -> Dict[str, Any]:
        """
        Get stats dictionary with current counters.
        
        Returns
        -------
        Dict[str, Any]
            Stats dictionary with hits, misses, hit_rate
        
        Examples
        --------
        >>> stats = self._get_stats_dict()
        >>> print(stats)
        {'hits': 10, 'misses': 2, 'hit_rate': '83.3%'}
        
        Notes
        -----
        **Standard Format**: Consistent across all cache types.
        **Calculated Hit Rate**: Uses _calculate_hit_rate() for formatting.
        """
        return {
            STAT_KEY_HITS: self._hits,
            STAT_KEY_MISSES: self._misses,
            STAT_KEY_HIT_RATE: self._calculate_hit_rate(),
        }

    # ========================================================================
    # Pattern Matching Helpers
    # ========================================================================

    def _pattern_matches(self, key: str, pattern: str) -> bool:
        """
        Check if key matches wildcard pattern.
        
        Supports three wildcard patterns:
        - Prefix: "ui_*" matches keys starting with "ui_"
        - Suffix: "*_plugin" matches keys ending with "_plugin"
        - Contains: "*test*" matches keys containing "test"
        
        Parameters
        ----------
        key : str
            Cache key to test
        pattern : str
            Wildcard pattern (e.g., "ui_*", "*_plugin", "*test*")
        
        Returns
        -------
        bool
            True if key matches pattern, False otherwise
        
        Examples
        --------
        >>> self._pattern_matches("ui_main", "ui_*")
        True
        >>> self._pattern_matches("test_plugin", "*_plugin")
        True
        >>> self._pattern_matches("my_test_file", "*test*")
        True
        >>> self._pattern_matches("other_file", "ui_*")
        False
        
        Notes
        -----
        **Simple Wildcards**: Only supports * wildcard, not regex.
        **Case Sensitive**: Matching is case-sensitive.
        **Exact Match**: If pattern has no *, does exact string comparison.
        """
        if "*" not in pattern:
            return key == pattern

        if pattern.startswith("*") and pattern.endswith("*"):
            # Contains: "*test*"
            return pattern[1:-1] in key
        elif pattern.startswith("*"):
            # Suffix: "*_plugin"
            return key.endswith(pattern[1:])
        elif pattern.endswith("*"):
            # Prefix: "ui_*"
            return key.startswith(pattern[:-1])
        else:
            # Exact match (no wildcard at ends)
            return key == pattern

    # ========================================================================
    # Stats Calculation Helpers
    # ========================================================================

    def _calculate_hit_rate(self) -> str:
        """
        Calculate cache hit rate as formatted percentage string.
        
        Returns
        -------
        str
            Hit rate percentage (e.g., "83.3%", "0.0%", "100.0%")
        
        Examples
        --------
        >>> self._hits = 10
        >>> self._misses = 2
        >>> self._calculate_hit_rate()
        '83.3%'
        
        >>> self._hits = 0
        >>> self._misses = 0
        >>> self._calculate_hit_rate()
        '0.0%'
        
        Notes
        -----
        **Formula**: hits / (hits + misses) * 100
        **Zero Division**: Returns "0.0%" if no requests yet
        **Precision**: Returns 1 decimal place (e.g., "83.3%")
        """
        total = self._hits + self._misses
        if total == 0:
            return "0.0%"
        return f"{(self._hits / total) * 100:.1f}%"

    # ========================================================================
    # Increment Helpers (for subclass convenience)
    # ========================================================================

    def _increment_hit(self) -> None:
        """Increment cache hit counter. Call on successful get()."""
        self._hits += 1

    def _increment_miss(self) -> None:
        """Increment cache miss counter. Call on failed get()."""
        self._misses += 1

    def _increment_eviction(self) -> None:
        """Increment eviction counter. Call on LRU eviction."""
        self._evictions += 1


# ============================================================================
# MODULE METADATA
# ============================================================================

__all__ = ["CacheBase"]
