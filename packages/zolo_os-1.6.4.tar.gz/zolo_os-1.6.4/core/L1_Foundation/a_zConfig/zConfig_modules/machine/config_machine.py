# zOS/core/L1_Foundation/a_zConfig/zConfig_modules/config_machine.py
"""Machine-level configuration management for system identity and preferences."""

from zOS import Any, Dict
from zSys.Utils import print_ready_message
from ..helpers import load_config_with_override
from .detectors import auto_detect_machine, create_user_machine_config
from ..paths.config_paths import zConfigPaths
from zlsp.parser.basic.serializer import dumps as zolo_dumps

# Module constants
LOG_PREFIX = "[MachineConfig]"
READY_MESSAGE = "zMachine Ready"
YAML_KEY = "zMachine"
SUBSYSTEM_NAME = "MachineConfig"

class MachineConfig:
    """Machine-level configuration for system identity and user preferences.
    
    Auto-detects capabilities (browser, IDE, shell, memory, CPU) and loads user 
    overrides from zConfig.machine.zolo. Persisted via config_persistence.py.
    """

    # Type hints for instance attributes
    paths: zConfigPaths
    machine: Dict[str, Any]
    _verbose: bool

    def __init__(self, paths: zConfigPaths, verbose: bool = False) -> None:
        """Initialize with auto-detection and load user preferences from zConfig.machine.zolo.
        
        Args:
            paths: zConfigPaths instance for file resolution
            verbose: If True, show initialization output (default: False)
        """
        self.paths = paths
        self._verbose = verbose

        # Auto-detect machine information (verbose controls preboot output)
        self.machine = auto_detect_machine(log_level=paths._log_level, is_production=not verbose)

        # Add user_data_dir from paths (needed for zPath display formatting)
        self.machine["user_data_dir"] = str(paths.user_data_dir)

        # Load and override from config file (check exists, create if missing)
        load_config_with_override(
            self.paths,
            YAML_KEY,
            create_user_machine_config,
            self.machine,
            self.paths.ZMACHINE_USER_ZOLO_FILENAME,
            SUBSYSTEM_NAME,
            verbose=self._verbose
        )

        # Write current state to .zolo config file
        self._write_zolo_config()

        # Print ready message (shown in Development mode only, not Testing or Production)
        if verbose or not (paths._is_production or paths._is_testing):
            print_ready_message(READY_MESSAGE, color="CONFIG")

    def get(self, key: str, default: Any = None) -> Any:
        """Get machine config value by key, returning default if not found."""
        return self.machine.get(key, default)

    def get_all(self) -> Dict[str, Any]:
        """Get complete machine configuration."""
        return self.machine.copy()

    def update(self, key: str, value: Any) -> None:
        """Update machine config value (runtime only)."""
        self.machine[key] = value

    def _write_zolo_config(self) -> None:
        """Write current machine state to zConfig.machine.zolo."""
        try:
            zolo_path = self.paths.user_zconfigs_dir / self.paths.ZMACHINE_USER_ZOLO_FILENAME
            zolo_path.parent.mkdir(parents=True, exist_ok=True)
            with open(zolo_path, 'w', encoding='utf-8') as f:
                f.write(zolo_dumps({YAML_KEY: self.machine}))
                f.write('\n')
        except Exception as e:
            print(f"{LOG_PREFIX} Failed to write .zolo config: {e}")

    def save_user_config(self) -> bool:
        """Save current machine config to zConfig.machine.zolo."""
        try:
            base_dir = self.paths.user_zconfigs_dir
            base_dir.mkdir(parents=True, exist_ok=True)

            zolo_path = base_dir / self.paths.ZMACHINE_USER_ZOLO_FILENAME
            with open(zolo_path, 'w', encoding='utf-8') as f:
                f.write(zolo_dumps({YAML_KEY: self.machine}))
                f.write('\n')

            print(f"{LOG_PREFIX} Saved machine config to: {zolo_path}")
            return True

        except Exception as e:
            print(f"{LOG_PREFIX} Failed to save machine config: {e}")
            return False
