# zOS/core/L2_Core/f_zNavigation/navigation_modules/navigation_breadcrumbs.py

"""
Breadcrumb Trail Management for zNavigation - Session State Component.

This module provides the Breadcrumbs class, which manages hierarchical navigation
trails stored in the zSession. It supports adding breadcrumbs, navigating backward
through the trail, and formatting breadcrumbs for display.

Architecture
------------
The Breadcrumbs class is a Tier 1 (Foundation) component that directly manages
zSession state for navigation history. It implements a scope-based breadcrumb model
where each scope (file + block path) maintains its own trail of navigation keys.

Breadcrumb Data Model (Session-based):

    session[SESSION_KEY_ZCRUMBS] = {
        "@.zUI.main.MainMenu": ["Dashboard", "Settings", "Profile"],
        "@.zUI.settings.Network": ["Wi-Fi", "DNS", "Proxy"]
    }

**Structure:**
- **Key (Scope)**: Full path to a zUI block (e.g., "@.zUI.main.MainMenu")
- **Value (Trail)**: Ordered list of navigation keys within that block

**Scope Format**: `{path}.{filename}.{BlockName}`
- `path`: Base path or "@" for default
- `filename`: e.g., "zUI.main"
- `BlockName`: Top-level block name

This model supports:
- **Hierarchical Navigation**: Parent/child scope relationships
- **Multi-level Back**: Navigate up through nested scopes
- **State Persistence**: Trails preserved in zSession
- **File Reloading**: Automatic reload of correct file after zBack

Core Methods
------------
1. handle_zCrumbs(zBlock, zKey, walker=None)
   - Adds a navigation key to the current block's trail
   - Prevents duplicate consecutive keys
   - Creates new scopes as needed

2. handle_zBack(show_banner=True, walker=None) -> Tuple[Dict, List, Optional[str]]
   - Navigates backward through the breadcrumb trail
   - Manages parent/child scope transitions
   - Reloads the appropriate file after navigation
   - Returns: (block_dict, block_keys, start_key)

3. zCrumbs_banner() -> Dict[str, str]
   - Formats breadcrumbs for display
   - Returns dict of {scope: formatted_trail}

zBack Algorithm (Complex - 113 lines)
--------------------------------------
The zBack algorithm handles multi-level navigation with sophisticated scope management:

**Step 1: Identify Active Scope**
- Get the last (most recent) scope from session[SESSION_KEY_ZCRUMBS]
- Get the trail (list of keys) for this scope

**Step 2: Pop from Current Trail**
- If trail has items → pop the last key
- This moves back one step within the current block

**Step 3: Handle Empty Trail (Scope Transition)**
- If trail is empty and we're not at root:
  a. Remove the empty child scope from session
  b. Move to parent scope (now the last scope)
  c. Pop parent's last key (the link that opened the child)

**Step 4: Cascade Empty Scope Removal**
- If after popping, the current scope is now empty and not root:
  - Repeat the scope transition (step 3)
  - This handles cases where navigating back empties multiple levels

**Step 5: Parse Active Crumb for File Context**
- Split the active crumb by "." to extract:
  - Base path (everything before last 3 parts)
  - Filename (2nd and 3rd parts from end)
  - Block name (last part)
- Update session keys: zVaFolder, zVaFile, zBlock

**Step 6: Reload File**
- Construct zPath from session values
- Load file using zLoader
- Extract the active block dict and its keys

**Step 7: Return Context**
- Return (block_dict, block_keys, start_key)
- start_key is the current position in the trail (or None if trail is empty)

Session Integration (Critical)
-------------------------------
This module is a **CORE session management component** that directly reads and writes
multiple session keys:

**Primary Session Keys (from zConfig):**
- SESSION_KEY_ZCRUMBS: The breadcrumb trail dict
- SESSION_KEY_ZVAFOLDER: Folder containing current file
- SESSION_KEY_ZVAFILE: Current file name
- SESSION_KEY_ZBLOCK: Current block name

**Session Dependencies:**
- zWalker: Relies on breadcrumbs for navigation state
- zLoader: Used to reload files after navigation
- zDisplay: Uses zCrumbs_banner() for UI display

**CRITICAL**: All session keys MUST use centralized SESSION_KEY_* constants from
zConfig.zConfig_modules.config_session to ensure system-wide consistency.

Layer Position
--------------
Layer 1, Position 4 (zNavigation) - Tier 1 (Foundation)

Integration
-----------
- Called by: MenuSystem, zWalker
- Uses: zSession (state management), zLoader (file reloading), zDisplay (output)
- Thread Safety: Not thread-safe (relies on session state)

Usage Examples
--------------
Add breadcrumb to trail::

    breadcrumbs = Breadcrumbs(navigation_system)
    breadcrumbs.handle_zCrumbs(
        zBlock="@.zUI.main.MainMenu",
        zKey="Settings",
        walker=current_walker
    )

Navigate backward::

    block_dict, block_keys, start_key = breadcrumbs.handle_zBack(
        show_banner=True,
        walker=current_walker
    )
    
    if start_key:
        # Resume from start_key in block_keys
        index = block_keys.index(start_key)
    else:
        # Start from beginning
        index = 0

Format breadcrumbs for display::

    breadcrumbs_dict = breadcrumbs.zCrumbs_banner()
    # {"@.zUI.main.MainMenu": "Dashboard > Settings > Profile"}

Module Constants
----------------
COLOR_* : str
    Display colors for breadcrumb operations
STYLE_* : str
    Display styles (full, single, etc.)
INDENT_* : int
    Indentation levels for display
SEPARATOR_* : str
    String separators for formatting
PREFIX_* : str
    Path prefixes for default locations
MSG_* : str
    Display messages for operations
LOG_* : str
    Logging message templates
ERR_* : str
    Error messages for validation failures
CRUMB_* : int
    Magic numbers for crumb parsing (minimum parts, indices)
"""

from zOS import Any, Dict, List, Optional, Tuple
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import SESSION_KEY_ZCRUMBS

from .navigation_helpers import get_display as get_display_helper
from .handlers.handler_panels import PanelManager
from .handlers.handler_zback import ZBackHandler
from .handlers.handler_breadcrumbs_ops import BreadcrumbsOpsHandler
from .navigation_constants import (
    COLOR_ZCRUMB,
    _STYLE_FULL,
    _INDENT_ZBACK,
    _SEPARATOR_CRUMB,
    _SEPARATOR_EMPTY,
    _MSG_HANDLE_ZBACK,
    _KEY_TRAILS,
    _KEY_CONTEXT,
    _KEY_DEPTH_MAP,
)


# ============================================================================
# Breadcrumbs Class
# ============================================================================

class Breadcrumbs:
    """
    Breadcrumb trail manager for zNavigation.
    
    Manages hierarchical navigation trails stored in zSession, supporting adding
    breadcrumbs, navigating backward through history, and formatting trails for display.
    
    Attributes
    ----------
    navigation : Any
        Reference to parent navigation system
    zos : Any
        Reference to zOS instance
    logger : Any
        Logger instance for breadcrumb operations
    
    Methods
    -------
    handle_zCrumbs(zBlock, zKey, walker=None)
        Add navigation key to breadcrumb trail
    handle_zBack(show_banner=True, walker=None)
        Navigate backward through trail, reload file
    zCrumbs_banner()
        Format breadcrumbs for display
    
    Private Methods
    ---------------
    _get_display(walker)
        Get display adapter (DRY helper)
    _get_active_crumb(session)
        Get active (most recent) crumb from session (DRY helper)
    _get_crumbs_dict(session)
        Get crumbs dict with validation (DRY helper)
    _pop_scope(session, scope)
        Pop (remove) a scope from crumbs dict (DRY helper)
    
    Examples
    --------
    Initialize and add breadcrumb::
    
        breadcrumbs = Breadcrumbs(navigation_system)
        breadcrumbs.handle_zCrumbs("@.zUI.main.Menu", "Settings", walker)
    
    Navigate backward::
    
        block_dict, keys, start_key = breadcrumbs.handle_zBack(True, walker)
    
    Format for display::
    
        trails = breadcrumbs.zCrumbs_banner()
    
    Integration
    -----------
    - Parent: zNavigation system
    - Session: Reads/writes SESSION_KEY_ZCRUMBS, SESSION_KEY_ZVAFOLDER, etc.
    - Display: Uses zDisplay for output (mode-agnostic)
    - Loader: Uses zLoader for file reloading
    """

    # Class-level type declarations
    navigation: Any  # Navigation system reference
    zos: Any  # zOS instance
    logger: Any  # Logger instance
    panel_manager: PanelManager  # Panel management component
    zback_handler: ZBackHandler  # zBack navigation handler
    ops_handler: BreadcrumbsOpsHandler  # Operations handler

    def __init__(self, navigation: Any) -> None:
        """
        Initialize breadcrumbs manager.
        
        Args
        ----
        navigation : Any
            Parent navigation system instance that provides access to zos and logger
        
        Notes
        -----
        Stores references to the parent navigation system, zos instance, and logger
        for use during breadcrumb operations. No state is maintained beyond these
        references - all navigation state is stored in zSession.
        
        Session Dependencies
        --------------------
        This module relies on zSession having the following keys initialized:
        - SESSION_KEY_ZCRUMBS: Dict of scopes and trails (or enhanced format)
        - SESSION_KEY_ZVAFOLDER: Current file folder
        - SESSION_KEY_ZVAFILE: Current file name
        - SESSION_KEY_ZBLOCK: Current block name
        
        Enhanced Format (Phase 0.5)
        ---------------------------
        SESSION_KEY_ZCRUMBS now supports enhanced format:
        {
            'trails': {scope: [keys...]},
            '_context': {last_operation, last_nav_type, current_file, timestamp},
            '_depth_map': {file: {block: {depth, type}}}
        }
        Old format (flat dict) is auto-migrated for backward compatibility.
        """
        self.navigation = navigation
        self.zos = navigation.zos
        self.logger = navigation.logger

        # Initialize handlers (extracted)
        self.panel_manager = PanelManager(self.logger)
        self.zback_handler = ZBackHandler(self.logger)
        self.ops_handler = BreadcrumbsOpsHandler(self.logger)

    def _create_panel_key(self, panel_name: str, session: Dict) -> str:
        """Delegates to PanelManager."""
        return self.panel_manager.create_panel_key(panel_name, session)

    def _clear_other_panel_keys(self, current_panel: str, session: Dict) -> None:
        """Delegates to PanelManager."""
        return self.panel_manager.clear_other_panel_keys(current_panel, session)

    def handle_zCrumbs(
        self,
        zKey: str,
        _walker: Optional[Any] = None,
        operation: str = "APPEND"
    ) -> None:
        """
        Add or replace navigation key in breadcrumb trail.
        
        Delegates to BreadcrumbsOpsHandler for implementation.
        See handler_breadcrumbs_ops.py for full details.
        """
        # Get active block path from session
        session = self.zos.session
        z_block = self._get_active_crumb(session)  # Use helper

        # Get or create trail
        trails = self._get_crumbs_dict(session)
        if z_block not in trails:
            trails[z_block] = []
        trail = trails[z_block]

        # Delegate operation to handler
        if operation == "RESET":
            self.ops_handler.handle_reset_operation(session, trail, zKey)
        elif operation == "REPLACE":
            self.ops_handler.handle_replace_operation(session, trail, zKey)
        elif operation == "POP_TO":
            self.ops_handler.handle_pop_to_operation(session, trail, zKey)
        else:  # APPEND (default)
            self.ops_handler.handle_append_operation(session, trail, zKey)

        # Update context and depth
        self.ops_handler.update_context_and_depth(
            session, operation, "SEQUENTIAL", "SEQUENTIAL",
            z_block, zKey, trail
        )

    def handle_zBack(
        self,
        show_banner: bool = True,
        walker: Optional[Any] = None
    ) -> Tuple[Dict[str, Any], List[str], Optional[str]]:
        """
        Navigate backward through breadcrumb trail.
        
        Delegates to ZBackHandler for all backward navigation operations.
        
        Args
        ----
        show_banner : bool, default=True
            Whether to display "zBack" banner
        walker : Optional[Any], default=None
            Optional walker instance for context
        
        Returns
        -------
        Tuple[Dict[str, Any], List[str], Optional[str]]
            Tuple of (block_dict, block_keys, start_key)
        
        Notes
        -----
        - Delegates to self.zback_handler methods
        - See ZBackHandler for full implementation details
        """
        # Display banner if requested
        if show_banner:
            display = self._get_display(walker)
            display.zDeclare(
                _MSG_HANDLE_ZBACK,
                color=COLOR_ZCRUMB,
                indent=_INDENT_ZBACK,
                style=_STYLE_FULL
            )

        # Get initial state
        active_crumb = self._get_active_crumb(self.zos.session)
        root_crumb = self._get_active_crumb(self.zos.session)  # Simplified for now
        trail = self._get_crumbs_dict(self.zos.session).get(active_crumb, [])

        # Guard: no active crumb means top-level block with no parent — signal exit to caller
        if not active_crumb:
            self.logger.debug("[ZBackHandler] No active crumb - at top-level, no parent to navigate to")
            return {}, [], None

        # Step 1-4: Handle trail popping and scope transitions (delegate to handler)
        active_crumb, trail = self.zback_handler.handle_trail_pop_and_scope_transition(
            self.zos.session,
            active_crumb,
            root_crumb,
            trail
        )

        # Step 5: Parse crumb and update session (delegate to handler)
        resolved_key = self.zback_handler.parse_crumb_and_update_session(
            self.zos.session,
            active_crumb,
            trail
        )

        # Step 6-8: Reload file and prepare context (delegate to handler)
        return self.zback_handler.reload_file_after_back(
            self.zos.session,
            resolved_key,
            walker
        )

    def zCrumbs_banner(self) -> Dict[str, str]:
        """
        Format breadcrumbs for display.
        
        Converts the session breadcrumb dict into a display-friendly format
        where each scope's trail is joined into a readable string.
        
        Returns
        -------
        Dict[str, str]
            Dictionary mapping scope names to formatted trail strings.
            Empty trails are represented as empty strings.
        
        Examples
        --------
        Format all breadcrumbs::
        
            trails = breadcrumbs.zCrumbs_banner()
            # {
            #     "@.zUI.main.MainMenu": "Dashboard > Settings > Profile",
            #     "@.zUI.settings.Network": "Wi-Fi > DNS"
            # }
        
        Handle empty trails::
        
            trails = breadcrumbs.zCrumbs_banner()
            # {
            #     "@.zUI.main.MainMenu": "",
            #     "@.zUI.settings.Network": "Wi-Fi"
            # }
        
        Notes
        -----
        - **Separator**: Trails are joined with " > " (_SEPARATOR_CRUMB)
        - **Empty Trails**: Represented as empty strings (not None)
        - **Read-Only**: Does not modify session state
        - **Display Integration**: Typically called by zDisplay.zCrumbs() for UI output
        
        Format
        ------
        - Input: {"scope1": ["key1", "key2"], "scope2": []}
        - Output: {"scope1": "key1 > key2", "scope2": ""}
        """
        zCrumbs_zPrint: Dict[str, str] = {}

        # Phase 0.5: Ensure enhanced format
        self._ensure_enhanced_format(self.zos.session)

        # Get trails from enhanced format
        trails = self._get_crumbs_dict(self.zos.session)

        # Iterate through all scopes and their trails
        for zScope, zTrail in trails.items():
            # Skip metadata keys (defensive programming)
            if zScope.startswith('_'):
                continue

            # Skip non-list values (defensive programming - should not happen after migration fix)
            if not isinstance(zTrail, list):
                self.logger.warning(f"[zCrumbs_banner] Skipping non-list trail: {zScope} = {type(zTrail)}")
                continue

            # Join trail with separator, or use empty string if trail is empty
            path = _SEPARATOR_CRUMB.join(zTrail) if zTrail else _SEPARATOR_EMPTY
            zCrumbs_zPrint[zScope] = path

        return zCrumbs_zPrint

    # ========================================================================
    # Private Helper Methods (DRY)
    # ========================================================================

    def _get_active_crumb(self, session: Dict[str, Any]) -> str:
        """
        Get active (most recent) crumb from session.

        Args
        ----
        session : Dict[str, Any]
            zSession dict

        Returns
        -------
        str
            Active crumb (last key in trails dict)
        """
        trails = self._get_crumbs_dict(session)
        if trails:
            # Return the last key from trails (most recent)
            return list(trails.keys())[-1]
        return ""

    def _get_crumbs_dict(self, session: Dict[str, Any]) -> Dict[str, List[str]]:
        """
        Get crumbs dict (trails) from session with validation.

        Args
        ----
        session : Dict[str, Any]
            zSession dict

        Returns
        -------
        Dict[str, List[str]]
            Trails dictionary
        """
        self._ensure_enhanced_format(session)
        crumbs_dict = session.get(SESSION_KEY_ZCRUMBS, {})
        return crumbs_dict.get(_KEY_TRAILS, {})

    def _pop_scope(self, session: Dict[str, Any], scope: str) -> None:
        """
        Pop (remove) a scope from crumbs dict.

        Args
        ----
        session : Dict[str, Any]
            zSession dict
        scope : str
            Scope key to remove
        """
        trails = self._get_crumbs_dict(session)
        if scope in trails:
            del trails[scope]

    def _create_trail_key(self, scope: str, session: Dict[str, Any]) -> None:
        """
        Create a new trail key if it doesn't exist.

        Args
        ----
        scope : str
            Scope key to create (e.g., "@.zUI.main.MainMenu")
        session : Dict[str, Any]
            zSession dict

        Returns
        -------
        None

        Notes
        -----
        DRY Helper: Centralizes trail key creation for zWalker orchestration.
        Ensures enhanced format and only creates if key doesn't already exist.
        Used by zWalker for session initialization and multi-block execution.

        Phase 0.5: Creates empty trail in enhanced format 'trails' dict.
        """
        self._ensure_enhanced_format(session)
        trails = self._get_crumbs_dict(session)
        if scope not in trails:
            trails[scope] = []

    def _ensure_enhanced_format(self, session: Dict[str, Any]) -> None:
        """
        Ensure breadcrumbs are in enhanced format.

        Args
        ----
        session : Dict[str, Any]
            zSession dict
        """
        crumbs_dict = session.get(SESSION_KEY_ZCRUMBS, {})

        # Check if already in enhanced format
        if _KEY_TRAILS in crumbs_dict:
            return

        # Migrate to enhanced format
        session[SESSION_KEY_ZCRUMBS] = {
            _KEY_TRAILS: crumbs_dict if isinstance(crumbs_dict, dict) else {},
            _KEY_CONTEXT: {},
            _KEY_DEPTH_MAP: {}
        }

    def _get_display(self, walker: Optional[Any] = None) -> Any:
        """
        Get display instance for banner rendering.

        Args
        ----
        walker : Optional[Any], default=None
            Optional walker instance for context

        Returns
        -------
        Any
            Display instance
        """
        return get_display_helper(self.zos, walker)
