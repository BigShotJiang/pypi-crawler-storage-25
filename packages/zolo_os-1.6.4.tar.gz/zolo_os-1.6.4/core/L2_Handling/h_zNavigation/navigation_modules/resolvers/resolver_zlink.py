# zOS/core/L2_Handling/f_zNavigation/navigation_modules/resolvers/resolver_zlink.py

"""
zLink Expression Resolver for zNavigation Subsystem.

This module provides the ZLinkResolver class, which parses zLink expressions
and validates RBAC permissions. Extracted from navigation_linking.py to follow
the approved resolver pattern from e_zDispatch.

Architecture
------------
The ZLinkResolver encapsulates parsing and validation logic:

1. **Expression Parsing** (parse_expression)
   - Extracts file path from zLink expression
   - Parses optional permission requirements
   - Supports imperative (zLink(...)) and declarative (raw path) formats

2. **RBAC Validation** (check_permissions)
   - Validates user permissions against requirements
   - Exact matching strategy (all keys must match)
   - Session-based user authentication

zLink Syntax
------------
Basic link (no permissions):
    zLink(@.zUI.settings.NetworkSettings)

Link with permissions:
    zLink(@.zUI.admin.UserManagement, {"role": "admin"})
    zLink(@.zUI.finance.Reports, {"role": "finance", "level": "manager"})

Path Format:
- @ = Base path (workspace root)
- zUI = UI directory
- filename = YAML file name (without extension)
- BlockName = Target block within file

Layer Position
--------------
Layer 1, Position 4 (zNavigation) - Resolver (Tier 1)

Integration
-----------
- Called by: Linking handler (navigation_linking.py)
- Uses: zParser.zExpr_eval() for permission dict parsing
- Session: Read-only for SESSION_KEY_ZAUTH
"""

from zOS import Any, Dict, Tuple
from zOS.L2_Handling.d_zParser.parser_modules.parser_utils import zExpr_eval
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import SESSION_KEY_ZAUTH

# Parsing constants
_PARSE_PREFIX_ZLINK = "zLink("
_PARSE_SUFFIX_RPAREN = ")"
_PARSE_PERMS_SEPARATOR = ", {"
_PARSE_BRACE_OPEN = "{"
_PARSE_BRACE_CLOSE = "}"

# href classification constants (shared with display_event_links via classify_href)
LINK_TYPE_INTERNAL_DELTA = 'internal_delta'
LINK_TYPE_INTERNAL_ZPATH = 'internal_zpath'
LINK_TYPE_EXTERNAL = 'external'
LINK_TYPE_ANCHOR = 'anchor'
LINK_TYPE_PLACEHOLDER = 'placeholder'

# Log messages
_LOG_RAW_EXPRESSION = "[ZLinkResolver] Raw zLink expression: %s"
_LOG_STRIPPED_INNER = "[ZLinkResolver] Stripped inner: %s"
_LOG_PATH_PART = "[ZLinkResolver] Path: %s"
_LOG_PERMS_PART_RAW = "[ZLinkResolver] Raw permissions: %s"
_LOG_PARSED_PERMS = "[ZLinkResolver] Parsed permissions: %s"
_LOG_WARN_NON_DICT = "[ZLinkResolver] Parsed permissions is not a dict, using {}"
_LOG_NO_PERMS_BLOCK = "[ZLinkResolver] No permissions block specified for: %s"
_LOG_ZAUTH_USER = "[ZLinkResolver] User auth data: %s"
_LOG_REQUIRED_PERMS_CHECK = "[ZLinkResolver] Required permissions: %s"
_LOG_NO_PERMS_REQUIRED = "[ZLinkResolver] No permissions required (public link)"
_LOG_CHECK_PERM_KEY = "[ZLinkResolver] Checking: '%s' (expected: %s, actual: %s)"
_LOG_WARN_PERM_DENIED = "[ZLinkResolver] Permission denied: '%s' (expected: %s, actual: %s)"
_LOG_ALL_PERMS_MATCHED = "[ZLinkResolver] All permissions matched - access granted"


class ZLinkResolver:
    """
    zLink expression parser and RBAC validator.
    
    Provides parsing and validation services for zLink expressions without
    side effects. Pure resolver pattern - no session mutation, only reads.
    
    Attributes
    ----------
    logger : Any
        Logger instance for resolver operations
    
    Methods
    -------
    classify_href(href)
        Classify a raw href string into a link type constant (static)
    parse_expression(expr)
        Parse zLink expression to extract path and permissions
    check_permissions(session, required)
        Check if user has required permissions
    """

    # Class-level type declarations
    logger: Any  # Logger instance

    def __init__(self, logger: Any) -> None:
        """
        Initialize zLink resolver.
        
        Args
        ----
        logger : Any
            Logger instance for resolver operations
        """
        self.logger = logger

    @staticmethod
    def classify_href(href: str) -> str:
        """
        Classify a raw href string into a link type constant.

        This is the Python SSOT for href classification, used by both
        zNavigation (zLink) and zDisplay (zURL) to ensure consistent
        type detection across all link-rendering subsystems.

        Args
        ----
        href : str
            Raw href value (e.g. "$zAbout", "@.UI.foo.Bar",
            "https://example.com", "#section", "#")

        Returns
        -------
        str
            One of: 'internal_delta', 'internal_zpath', 'external',
            'anchor', 'placeholder'

        Examples
        --------
        ::

            ZLinkResolver.classify_href("$zAbout")          # 'internal_delta'
            ZLinkResolver.classify_href("@.UI.app.Main")    # 'internal_zpath'
            ZLinkResolver.classify_href("https://zolo.io")  # 'external'
            ZLinkResolver.classify_href("#features")        # 'anchor'
            ZLinkResolver.classify_href("#")                # 'placeholder'
        """
        if not href or href == '#':
            return LINK_TYPE_PLACEHOLDER
        if href.startswith('$'):
            return LINK_TYPE_INTERNAL_DELTA
        if href.startswith('@'):
            return LINK_TYPE_INTERNAL_ZPATH
        if href.startswith(('http://', 'https://')):
            return LINK_TYPE_EXTERNAL
        if href.startswith('#'):
            return LINK_TYPE_ANCHOR
        # Default: treat unknown hrefs as internal delta navigation
        return LINK_TYPE_INTERNAL_DELTA

    def parse_expression(self, expr: str) -> Tuple[str, Dict[str, Any]]:
        """
        Parse zLink expression to extract path and permissions.
        
        Parses zLink syntax to extract the file path and optional permission
        requirements. Uses zParser.zExpr_eval() to parse permission dict strings.
        
        Args
        ----
        expr : str
            zLink expression string to parse
        
        Returns
        -------
        Tuple[str, Dict[str, Any]]
            Tuple of (path, permissions):
            - path (str): File path (e.g., "@.zUI.settings.Network")
            - permissions (Dict[str, Any]): Required permissions dict (empty if none)
        
        Examples
        --------
        Parse basic zLink::
        
            path, perms = resolver.parse_expression("zLink(@.zUI.settings.Main)")
            # path = "@.zUI.settings.Main"
            # perms = {}
        
        Parse zLink with permissions::
        
            path, perms = resolver.parse_expression(
                'zLink(@.zUI.admin.Users, {"role": "admin"})'
            )
            # path = "@.zUI.admin.Users"
            # perms = {"role": "admin"}
        
        Notes
        -----
        - Syntax: zLink(path) or zLink(path, {"key": "value"})
        - Permission Parsing: Uses zParser.zExpr_eval() to convert string to dict
        - Error Handling: Defaults to empty dict if parsing fails or returns non-dict
        - Supports both imperative (zLink(...)) and declarative (raw path) formats
        
        Algorithm
        ---------
        1. Log raw expression
        2. Strip "zLink(" prefix and ")" suffix (if present)
        3. Log stripped inner contents
        4. Check if ", {" exists (indicates permissions)
        5. If permissions:
           a. Split on ", {" to separate path and permissions
           b. Reconstruct permission dict string with braces
           c. Parse permissions with zExpr_eval()
           d. Validate result is dict (default to {} if not)
        6. If no permissions:
           a. Use inner contents as path
           b. Set permissions to empty dict
        7. Return (path, permissions) tuple
        """
        # Log raw expression
        self.logger.info(_LOG_RAW_EXPRESSION, expr)

        # Check if expression has "zLink(" wrapper (imperative) or is raw path (declarative YAML)
        if expr.startswith(_PARSE_PREFIX_ZLINK) and expr.endswith(_PARSE_SUFFIX_RPAREN):
            # Imperative format: zLink(@.path) → strip wrapper
            inner = expr[len(_PARSE_PREFIX_ZLINK):-1].strip()
        else:
            # Declarative YAML format: already a raw path → use as-is
            inner = expr.strip()

        self.logger.info(_LOG_STRIPPED_INNER, inner)

        # Check if permissions are specified
        if _PARSE_PERMS_SEPARATOR in inner:
            # Split path and permissions
            path_str, perms_str = inner.rsplit(_PARSE_PERMS_SEPARATOR, 1)
            zLink_path = path_str.strip()

            # Reconstruct permission dict string
            perms_str = (
                _PARSE_BRACE_OPEN +
                perms_str.strip().rstrip(_PARSE_BRACE_CLOSE) +
                _PARSE_BRACE_CLOSE
            )

            # Log parts
            self.logger.info(_LOG_PATH_PART, zLink_path)
            self.logger.info(_LOG_PERMS_PART_RAW, perms_str)

            # Parse permissions with zExpr_eval
            required = zExpr_eval(perms_str, self.logger)

            # Validate result is dict
            if not isinstance(required, dict):
                self.logger.warning(_LOG_WARN_NON_DICT)
                required = {}
            else:
                self.logger.info(_LOG_PARSED_PERMS, required)
        else:
            # No permissions specified
            zLink_path = inner
            required = {}
            self.logger.debug(_LOG_NO_PERMS_BLOCK, zLink_path)

        return zLink_path, required

    def check_permissions(
        self,
        session: Dict[str, Any],
        required: Dict[str, Any]
    ) -> bool:
        """
        Check if user has required permissions.
        
        Validates user permissions from session against required permissions dict.
        Uses exact matching: each required permission key must exist in user dict
        with the exact same value.
        
        Args
        ----
        session : Dict[str, Any]
            Session dictionary containing user auth data
        required : Dict[str, Any]
            Required permissions dict (e.g., {"role": "admin"})
        
        Returns
        -------
        bool
            True if user has all required permissions (or no permissions required),
            False if any permission check fails
        
        Examples
        --------
        Check admin role::
        
            # Session: {SESSION_KEY_ZAUTH: {"role": "admin"}}
            has_access = resolver.check_permissions(session, {"role": "admin"})
            # Returns: True
        
        Check multiple permissions::
        
            # Session: {SESSION_KEY_ZAUTH: {"role": "finance", "level": "manager"}}
            has_access = resolver.check_permissions(
                session,
                {"role": "finance", "level": "manager"}
            )
            # Returns: True
        
        Permission mismatch::
        
            # Session: {SESSION_KEY_ZAUTH: {"role": "user"}}
            has_access = resolver.check_permissions(session, {"role": "admin"})
            # Returns: False
        
        No permissions required::
        
            has_access = resolver.check_permissions(session, {})
            # Returns: True (public link)
        
        Notes
        -----
        - User Data: Reads from session[SESSION_KEY_ZAUTH]
        - Exact Matching: user[key] must == required[key] for all keys
        - No Permissions: Returns True if required dict is empty
        - Missing Keys: Returns False if user dict doesn't have required key
        
        Algorithm
        ---------
        1. Get user dict from session[SESSION_KEY_ZAUTH]
        2. Log user dict and required permissions
        3. If no permissions required, allow access (return True)
        4. For each required permission key:
           a. Get actual value from user dict
           b. Log comparison (key, expected, actual)
           c. If value doesn't match, deny access (return False)
        5. If all permissions match, allow access (return True)
        """
        # Get user auth data from session
        user = session.get(SESSION_KEY_ZAUTH, {})

        # Log auth check
        self.logger.debug(_LOG_ZAUTH_USER, user)
        self.logger.debug(_LOG_REQUIRED_PERMS_CHECK, required)

        # No permissions required (public link)
        if not required:
            self.logger.debug(_LOG_NO_PERMS_REQUIRED)
            return True

        # Check each required permission
        for perm_key, expected_value in required.items():
            actual_value = user.get(perm_key)

            self.logger.debug(_LOG_CHECK_PERM_KEY, perm_key, expected_value, actual_value)

            if actual_value != expected_value:
                self.logger.warning(
                    _LOG_WARN_PERM_DENIED,
                    perm_key,
                    expected_value,
                    actual_value
                )
                return False

        # All permissions matched
        self.logger.debug(_LOG_ALL_PERMS_MATCHED)
        return True

    def extract_block_from_path(self, zLink_path: str) -> Tuple[str, str]:
        """
        Extract block name and file path from zLink path.
        
        Args
        ----
        zLink_path : str
            Full zLink path (e.g., "@.zUI.settings.NetworkSettings")
        
        Returns
        -------
        Tuple[str, str]
            Tuple of (selected_zBlock, zFile_path):
            - selected_zBlock: Block name (last part)
            - zFile_path: File path (all parts except last)
        
        Examples
        --------
        Extract components::
        
            block, file = resolver.extract_block_from_path("@.zUI.settings.Network")
            # block = "Network"
            # file = "@.zUI.settings"
        """
        path_parts = zLink_path.split(".")
        selected_zBlock = path_parts[-1]
        zFile_path = ".".join(path_parts[:-1])
        return selected_zBlock, zFile_path
