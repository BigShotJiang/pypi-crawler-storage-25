# zOS/core/L2_Handling/f_zNavigation/navigation_modules/handlers/handler_navbar.py

"""
Navigation Bar Handler for zNavigation Subsystem.

This module provides the NavbarHandler class, which manages navigation bar
resolution, RBAC filtering, and multi-format parsing. Extracted from zNavigation
facade to follow the approved handler pattern from e_zDispatch.

Architecture
------------
The NavbarHandler encapsulates all navbar-related logic that was previously
in the zNavigation facade (lines 288-697). It provides:

1. **Global Navbar Loading** (load_global)
   - Reads from os.environ["ZNAVBAR"] (zEnv YAML files)
   - Legacy .zEnv file fallback
   - Multiple format support (JSON dict, JSON array, comma-separated)

2. **Dict Format Parsing** (parse_dict)
   - Converts navbar dict to internal list format
   - Preserves zRBAC and zSub metadata

3. **RBAC Filtering** (filter_by_rbac)
   - Terminal-first implementation (backend filtering)
   - Supports zGuest, authenticated, require_role rules
   - Preserves zSub metadata for hierarchical menus

4. **Navbar Resolution** (resolve)
   - Priority chain: local override > zVaFile opt-in > route fallback
   - Session-aware (checks authentication state)

Layer Position
--------------
Layer 1, Position 4 (zNavigation) - Handler (Tier 2)

Integration
-----------
- Called by: zNavigation facade (delegation)
- Uses: zAuth (authentication checks), zConfig (environment vars)
- Session: Read-only for auth state
"""

from zOS import Any, Dict, List, Optional, Union


class NavbarHandler:
    """
    Navigation bar handler for zNavigation subsystem.
    
    Manages navbar loading, parsing, RBAC filtering, and resolution following
    the approved handler pattern. Extracted from zNavigation facade for better
    separation of concerns.
    
    Attributes
    ----------
    navigation : Any
        Reference to parent zNavigation system
    zos : Any
        Reference to zOS instance
    logger : Any
        Logger instance for navbar operations
    _global_navbar : Optional[List[Any]]
        Cached global navbar from environment
    
    Methods
    -------
    load_global()
        Load global navbar from environment configuration
    parse_dict(navbar_raw)
        Parse navbar dict format into internal list format
    filter_by_rbac(navbar_items)
        Filter navbar items based on RBAC rules
    resolve(raw_zFile, route_meta)
        Resolve navbar for a given zVaFile with route fallback
    """

    # Class-level type declarations
    navigation: Any  # Navigation system reference
    zos: Any  # zOS instance
    logger: Any  # Logger instance
    _global_navbar: Optional[List[Any]]  # Cached global navbar

    def __init__(self, navigation: Any) -> None:
        """
        Initialize navbar handler.
        
        Args
        ----
        navigation : Any
            Parent zNavigation system instance
        
        Notes
        -----
        Loads global navbar from environment during initialization and caches it.
        The cached navbar is unfiltered - RBAC filtering happens dynamically.
        """
        self.navigation = navigation
        self.zos = navigation.zos
        self.logger = navigation.logger

        # Load global navbar from environment (.zEnv)
        self._global_navbar = self.load_global()

    def load_global(self) -> Optional[List[Any]]:
        """
        Load global navigation bar from environment configuration.
        
        Delegates to zConfig for loading zEnv YAML files - this method only reads from os.environ.
        zConfig.load_dotenv() loads zEnv.base.yaml + zEnv.{environment}.yaml and injects into os.environ.
        
        Supports multiple formats (priority order):
        1. os.environ["ZNAVBAR"] (from zConfig's zEnv YAML loading) - THE zOS WAY
        2. Legacy .zEnv file parsing (backward compatibility only)
        3. Legacy comma-separated: ZNAVBAR=zVaF,zAbout,zLogin
        
        Returns
        -------
        Optional[List[Any]]
            List of navbar items (strings or dicts with RBAC) or None
        
        Examples
        --------
        YAML dict format (recommended, loaded by zConfig)::
        
            Input (zEnv.base.yaml):
                ZNAVBAR:
                  zVaF:
                  zAccount:
                    zRBAC:
                      require_role: [zAdmin]
            Output: ["zVaF", {"zAccount": {"zRBAC": {"require_role": ["zAdmin"]}}}]
        
        Legacy format::
        
            ZNAVBAR=zVaF,zAbout,zRegister,zLogin
            Returns: ["zVaF", "zAbout", "zRegister", "zLogin"]
        
        Notes
        -----
        - Loaded once during initialization
        - Cached in self._global_navbar (unfiltered)
        - RBAC filtering applied later in resolve()
        - zEnv YAML files are loaded by zConfig (config_paths.load_dotenv) and injected into os.environ
        - This method does NOT parse YAML files directly - that's zConfig's responsibility
        """
        import os
        import json
        from pathlib import Path

        # Priority 1: Check os.environ (from zConfig's zEnv YAML loading - THE zOS WAY)
        navbar_env = os.getenv("ZNAVBAR", "").strip()

        # Priority 2: Fallback to legacy .zEnv file (backward compatibility only)
        # Note: This is only for legacy setups. Modern setups use zEnv.*.yaml loaded by zConfig.
        if not navbar_env:
            legacy_env_path = Path(self.zos.config.paths.workspace_dir) / ".zEnv"
            if legacy_env_path.exists():
                try:
                    env_data = self.zos.zparser.parse_file_by_path(str(legacy_env_path))
                    if env_data and "ZNAVBAR" in env_data:
                        navbar_raw = env_data["ZNAVBAR"]
                        if isinstance(navbar_raw, dict):
                            navbar_items = self.parse_dict(navbar_raw)
                            if navbar_items:
                                self.logger.framework.info(
                                    f"[NavbarHandler] Loaded navbar from legacy .zEnv "
                                    f"({len(navbar_items)} items)"
                                )
                                return navbar_items
                        elif isinstance(navbar_raw, str):
                            navbar_env = navbar_raw
                except Exception as e:
                    self.logger.framework.debug(f"[NavbarHandler] Failed to parse legacy .zEnv: {e}")

            if not navbar_env:
                self.logger.framework.debug(
                    "[NavbarHandler] No global navbar defined in ZNAVBAR env var "
                    "(zConfig should load from zEnv.*.yaml)"
                )
                return None

        # Parse navbar_env (from os.environ or legacy .zEnv)
        # Check if it's JSON dict format (starts with '{') - FROM zEnv YAML flattening
        if navbar_env.startswith("{"):
            # zEnv flattened dict: Parse as JSON dict
            try:
                navbar_raw = json.loads(navbar_env)

                if not isinstance(navbar_raw, dict):
                    self.logger.framework.warning(f"[NavbarHandler] ZNAVBAR JSON is not a dict: {type(navbar_raw)}")
                    return None

                # Parse dict format using helper method
                navbar_items = self.parse_dict(navbar_raw)

                if navbar_items:
                    self.logger.framework.info(
                        f"[NavbarHandler] Loaded navbar from os.environ (zEnv YAML) "
                        f"({len(navbar_items)} items)"
                    )
                    return navbar_items

            except json.JSONDecodeError as e:
                self.logger.framework.error(f"[NavbarHandler] Failed to parse ZNAVBAR JSON dict: {e}")
                return None
            except Exception as e:
                self.logger.framework.error(f"[NavbarHandler] Error processing ZNAVBAR dict: {e}")
                return None

        # Check if it's JSON array format (starts with '[') - LEGACY
        elif navbar_env.startswith("["):
            # Enhanced JSON format: Parse as JSON
            try:
                navbar_raw = json.loads(navbar_env)

                if not isinstance(navbar_raw, list):
                    self.logger.framework.warning(f"[NavbarHandler] ZNAVBAR JSON is not an array: {type(navbar_raw)}")
                    return None

                # Transform JSON format to internal format
                # Input: [{"item": "zVaF"}, {"item": "^logout", "zRBAC": {...}}]
                # Output: ["zVaF", {"^logout": {"zRBAC": {...}}}]
                navbar_items = []
                for entry in navbar_raw:
                    if not isinstance(entry, dict):
                        self.logger.framework.warning(f"[NavbarHandler] Invalid navbar entry (not a dict): {entry}")
                        continue

                    item_name = entry.get("item")
                    if not item_name:
                        self.logger.framework.warning(f"[NavbarHandler] Navbar entry missing 'item' key: {entry}")
                        continue

                    # If entry has zRBAC, convert to dict format: {item_name: {zRBAC: ...}}
                    if "zRBAC" in entry:
                        navbar_items.append({item_name: {"zRBAC": entry["zRBAC"]}})
                    else:
                        # Simple string item (public)
                        navbar_items.append(item_name)

                if navbar_items:
                    self.logger.framework.info(
                        f"[NavbarHandler] Loaded enhanced navbar (JSON) "
                        f"with {len(navbar_items)} items"
                    )
                    return navbar_items

            except json.JSONDecodeError as e:
                self.logger.framework.error(f"[NavbarHandler] Failed to parse ZNAVBAR JSON: {e}")
                return None
            except Exception as e:
                self.logger.framework.error(f"[NavbarHandler] Error processing ZNAVBAR: {e}")
                return None

        else:
            # Legacy format: Split by comma
            navbar_items = [item.strip() for item in navbar_env.split(",") if item.strip()]

            if navbar_items:
                self.logger.framework.info(f"[NavbarHandler] Loaded legacy navbar (comma-separated): {navbar_items}")
                return navbar_items

        return None

    def parse_dict(self, navbar_raw: Dict[str, Any]) -> List[Any]:
        """
        Parse navbar dict format into internal format.
        
        Args
        ----
        navbar_raw : Dict[str, Any]
            Dict with item names as keys and optional metadata as values
        
        Returns
        -------
        List[Any]
            List of navbar items (strings or dicts with RBAC and/or sub-items)
        
        Examples
        --------
        Simple items::
        
            Input: {"zVaF": None, "zAbout": None}
            Output: ["zVaF", "zAbout"]
        
        Items with RBAC::
        
            Input: {"zAccount": {"zRBAC": {"require_role": ["zAdmin"]}}}
            Output: [{"zAccount": {"zRBAC": {"require_role": ["zAdmin"]}}}]
        
        Items with sub-items::
        
            Input: {"zProducts": {"zSub": ["zCLI", "zBifrost"]}}
            Output: [{"zProducts": {"zSub": ["zCLI", "zBifrost"]}}]
        """
        navbar_items = []

        for item_name, item_config in navbar_raw.items():
            # If item has metadata (zRBAC or zSub), include it
            if item_config and isinstance(item_config, dict):
                metadata = {}
                if "zRBAC" in item_config:
                    metadata["zRBAC"] = item_config["zRBAC"]
                if "zSub" in item_config:
                    metadata["zSub"] = item_config["zSub"]

                if metadata:
                    navbar_items.append({item_name: metadata})
                else:
                    # Config dict but no recognized metadata
                    navbar_items.append(item_name)
            else:
                # Simple string item (public, no RBAC, no sub-items)
                navbar_items.append(item_name)

        return navbar_items

    def filter_by_rbac(self, navbar_items: List[Any]) -> List[Union[str, Dict[str, Any]]]:
        """
        Filter navbar items based on RBAC rules and current user authentication state.
        
        This is the "Terminal First" implementation - filtering happens in the backend
        (zLoader/zNavigation layer) ensuring consistent behavior across Terminal and Bifrost.
        
        Filtering Rules
        ---------------
        1. String items (no zRBAC) → Always visible (public)
        2. Dict items with zRBAC:
            - zGuest: true → Only visible if NOT authenticated
            - authenticated: true → Only visible if authenticated
            - authenticated: false → Only visible if NOT authenticated (same as zGuest)
            - require_role: "role" → Only visible if user has that role
        3. Dict items with zSub → Preserved in output for hierarchical navigation
        4. Invalid items → Filtered out (logged as warnings)
        
        Args
        ----
        navbar_items : List[Any]
            Raw navbar items (strings or dicts with RBAC metadata and/or sub-items)
        
        Returns
        -------
        List[Union[str, Dict[str, Any]]]
            Filtered list of navbar items (strings or dicts with zSub)
        
        Examples
        --------
        Not authenticated::
        
            Input: ["zVaF", {"^logout": {"zRBAC": {"authenticated": true}}}, 
                    {"^zLogin": {"zRBAC": {"authenticated": false}}}]
            Output: ["zVaF", "^zLogin"]
        
        With sub-items::
        
            Input: ["zVaF", {"zProducts": {"zSub": ["zCLI", "zBifrost"]}}]
            Output: ["zVaF", {"zProducts": {"zSub": ["zCLI", "zBifrost"]}}]
        
        Authenticated as zAdmin::
        
            Input: ["zVaF", {"zAccount": {"zRBAC": {"require_role": "zAdmin"}}}, 
                    {"^zLogin": {"zRBAC": {"authenticated": false}}}]
            Output: ["zVaF", "zAccount"]
        
        Notes
        -----
        - Uses zos.auth.is_authenticated() for auth checks
        - Preserves zSub metadata for hierarchical menus
        - Uses zos.auth.has_role() for role checks
        - Returns clean item names (without zRBAC metadata)
        - Logs filtered items at DEBUG level
        """
        if not navbar_items:
            return []

        filtered = []
        is_authenticated = self.zos.auth.is_authenticated() if hasattr(self.zos, 'auth') else False

        for item in navbar_items:
            # Case 1: Simple string item (no RBAC) - always visible
            if isinstance(item, str):
                filtered.append(item)
                continue

            # Case 2: Dict item with potential RBAC metadata and/or sub-items
            if isinstance(item, dict):
                # Extract the item name (key) and metadata (value)
                if len(item) != 1:
                    self.logger.framework.warning(
                        f"[NavbarHandler] Invalid navbar item dict "
                        f"(must have exactly 1 key): {item}"
                    )
                    continue

                item_name = list(item.keys())[0]
                item_metadata = item[item_name]

                # Extract sub-items if present
                sub_items = (
                    item_metadata.get("zSub") if isinstance(item_metadata, dict) else None
                )

                # If no metadata or no zRBAC, treat as public
                if not isinstance(item_metadata, dict) or "zRBAC" not in item_metadata:
                    # If has sub-items, include them in output (preserve metadata wrapper)
                    if sub_items:
                        filtered.append({item_name: {"zSub": sub_items}})
                    else:
                        filtered.append(item_name)
                    continue

                # Extract RBAC rules
                rbac_rules = item_metadata.get("zRBAC", {})

                # Check zGuest (guest-only - must NOT be authenticated)
                if rbac_rules.get("zGuest"):
                    if not is_authenticated:
                        filtered.append(
                            {item_name: {"zSub": sub_items}} if sub_items else item_name
                        )
                        self.logger.framework.debug(
                            f"[NavbarHandler] Navbar item '{item_name}' visible "
                            f"(zGuest: user not authenticated)"
                        )
                    else:
                        self.logger.framework.debug(
                            f"[NavbarHandler] Navbar item '{item_name}' hidden "
                            f"(zGuest: user is authenticated)"
                        )
                    continue

                # Check authenticated (must be authenticated OR must NOT be authenticated)
                if "authenticated" in rbac_rules:
                    auth_required = rbac_rules.get("authenticated")
                    if auth_required is True:
                        # authenticated: true - must be authenticated
                        if is_authenticated:
                            filtered.append(
                                {item_name: {"zSub": sub_items}} if sub_items else item_name
                            )
                            self.logger.framework.debug(
                                f"[NavbarHandler] Navbar item '{item_name}' visible "
                                f"(authenticated: true)"
                            )
                        else:
                            self.logger.framework.debug(
                                f"[NavbarHandler] Navbar item '{item_name}' hidden "
                                f"(not authenticated)"
                            )
                    elif auth_required is False:
                        # authenticated: false - must NOT be authenticated (guest-only)
                        if not is_authenticated:
                            filtered.append(
                                {item_name: {"zSub": sub_items}} if sub_items else item_name
                            )
                            self.logger.framework.debug(
                                f"[NavbarHandler] Navbar item '{item_name}' visible "
                                f"(authenticated: false, user is guest)"
                            )
                        else:
                            self.logger.framework.debug(
                                f"[NavbarHandler] Navbar item '{item_name}' hidden "
                                f"(authenticated: false, user is authenticated)"
                            )
                    continue

                # Check require_role (must have specific role)
                required_role = rbac_rules.get("require_role")
                if required_role:
                    if (is_authenticated and hasattr(self.zos, 'auth')
                            and self.zos.auth.has_role(required_role)):
                        filtered.append(
                            {item_name: {"zSub": sub_items}} if sub_items else item_name
                        )
                        self.logger.framework.debug(
                            f"[NavbarHandler] Navbar item '{item_name}' visible "
                            f"(has role: {required_role})"
                        )
                    else:
                        self.logger.framework.debug(
                            f"[NavbarHandler] Navbar item '{item_name}' hidden "
                            f"(missing role: {required_role})"
                        )
                    continue

                # No RBAC rules matched - treat as public
                filtered.append({item_name: {"zSub": sub_items}} if sub_items else item_name)
                continue

            # Case 3: Invalid item type
            self.logger.framework.warning(f"[NavbarHandler] Invalid navbar item type: {type(item)} ({item})")

        self.logger.framework.debug(f"[NavbarHandler] Filtered navbar: {len(navbar_items)} → {len(filtered)} items")
        return filtered

    def resolve(
        self,
        raw_zFile: Dict[str, Any],
        route_meta: Optional[Dict[str, Any]] = None
    ) -> Optional[List[str]]:
        """
        Resolve navigation bar for a given zVaFile based on meta.zNavBar with route fallback.
        
        Resolution Logic (Priority Chain)
        ----------------------------------
        1. If zVaFile meta.zNavBar is a list → return it (highest priority: local override)
        2. If zVaFile meta.zNavBar: true → return global navbar from .zEnv
        3. If zVaFile meta.zNavBar is false/missing AND route meta.zNavBar: true →
           return global navbar (lowest priority: route fallback)
        4. Otherwise → return None (no navbar)
        
        Args
        ----
        raw_zFile : Dict[str, Any]
            Parsed YAML dictionary from zVaFile
        route_meta : Optional[Dict[str, Any]], default=None
            Optional route metadata from zServer.routes.yaml (for fallback)
        
        Returns
        -------
        Optional[List[str]]
            Resolved navbar items or None
        
        Examples
        --------
        Priority 1: Local override (custom navbar)::
        
            zVaFile meta.zNavBar: ["Custom", "Items"]
            Returns: ["Custom", "Items"]
        
        Priority 2: zVaFile opt-in to global navbar::
        
            zVaFile meta.zNavBar: true
            Returns: ["zVaF", "zAbout", "zRegister", "zLogin"] (from .zEnv)
        
        Priority 3: Route fallback (if zVaFile has no navbar)::
        
            zVaFile meta.zNavBar: missing/false
            Route meta.zNavBar: true
            Returns: ["zVaF", "zAbout", "zRegister", "zLogin"] (from .zEnv)
        
        No navbar::
        
            All meta.zNavBar: false/missing
            Returns: None
        
        Notes
        -----
        - Local navbar always wins (DRY principle with override)
        - Route meta provides fallback for files without navbar
        - zServer routes can enforce navbar for all pages via meta.zNavBar: true
        """
        if not raw_zFile or not isinstance(raw_zFile, dict):
            return None

        # Get zVaFile zMeta section
        meta_section = raw_zFile.get("zMeta", {})
        if not isinstance(meta_section, dict):
            meta_section = {}

        # Get zNavBar value from zVaFile
        navbar_value = meta_section.get("zNavBar")

        # Normalize string 'true'/'false' to boolean (for .zolo file compatibility)
        if isinstance(navbar_value, str):
            navbar_value = navbar_value.lower() == 'true'

        # Priority 1: Local override (list of items)
        if isinstance(navbar_value, list):
            if len(navbar_value) > 0:
                self.logger.framework.debug(f"[NavbarHandler] Using local navbar (priority 1): {navbar_value}")
                # Return raw (unfiltered) navbar - filtering happens dynamically in zDispatch
                return navbar_value
            else:
                self.logger.framework.debug("[NavbarHandler] Empty local navbar, skipping")
                return None

        # Priority 2: zVaFile opt-in to global navbar (true)
        if navbar_value is True:
            if self._global_navbar:
                self.logger.framework.debug(
                    f"[NavbarHandler] Injecting global navbar from zVaFile (priority 2): "
                    f"{self._global_navbar}"
                )
                # Return raw (unfiltered) navbar - filtering happens dynamically in zDispatch
                return self._global_navbar
            else:
                self.logger.framework.warning(
                    "[NavbarHandler] meta.zNavBar: true but no global navbar defined in .zEnv"
                )
                return None

        # Priority 3: Route fallback (if zVaFile has no navbar setting)
        # Check if route metadata has zNavBar: true
        if route_meta and isinstance(route_meta, dict):
            route_navbar_value = route_meta.get("zNavBar")

            # Normalize string 'true'/'false' to boolean (for .zolo file compatibility)
            if isinstance(route_navbar_value, str):
                route_navbar_value = route_navbar_value.lower() == 'true'

            if route_navbar_value is True:
                if self._global_navbar:
                    self.logger.framework.debug(
                        f"[NavbarHandler] Injecting global navbar from route fallback "
                        f"(priority 3): {self._global_navbar}"
                    )
                    # Return raw (unfiltered) navbar - filtering happens dynamically in zDispatch
                    return self._global_navbar
                else:
                    self.logger.framework.warning(
                        "[NavbarHandler] Route meta.zNavBar: true but no global navbar "
                        "defined in .zEnv"
                    )
                    return None
            elif isinstance(route_navbar_value, list) and len(route_navbar_value) > 0:
                self.logger.framework.debug(
                    f"[NavbarHandler] Using route navbar fallback (priority 3): "
                    f"{route_navbar_value}"
                )
                # Return raw (unfiltered) navbar - filtering happens dynamically in zDispatch
                return route_navbar_value

        # Case 4: No navbar (false, None, or missing everywhere)
        self.logger.framework.debug("[NavbarHandler] No navbar configured (zVaFile or route)")
        return None
