# zOS/core/L2_Handling/g_zParser/parser_modules/plugin/plugin_syntax.py

"""
Plugin invocation syntax parsing for plugin package.

Provides parsing and validation of plugin invocation syntax using regex,
and zPath resolution for plugin file paths.

Public API:
    - parse_plugin_invocation: Parse &Plugin.function(args) syntax
    - resolve_plugin_path: Convert zPath to file path

Dependencies:
    - re: Regex for syntax validation

Created: Phase 2.1 - Extract Syntax from parser_plugin.py
"""

from zOS import re, Any, Tuple

# Regex Patterns
REGEX_PLUGIN_INVOCATION: str = r'^&([a-zA-Z_][a-zA-Z0-9_]*)\.([a-zA-Z_][a-zA-Z0-9_]*)\((.*?)\)$'  # pylint: disable=line-too-long

# Characters
CHAR_DOT: str = '.'

# Error Messages
ERROR_MSG_INVALID_SYNTAX: str = "Invalid plugin invocation syntax: {}"
ERROR_MSG_EXPECTED_FORMAT: str = "Expected format: &PluginName.function_name(args)"
ERROR_MSG_SYNTAX_EXAMPLES: str = (
    "Examples:\n"
    "  &test_plugin.hello_world('Alice')\n"
    "  &IDGenerator.generate_uuid()\n"
    "  &DateUtils.get_timestamp()"
)


def parse_plugin_invocation(value: str) -> Tuple[str, str, str]:
    """
    Parse &PluginName.function_name(args) into components using regex.
    
    Uses a regex pattern to extract the three components of a plugin invocation:
    plugin name, function name, and arguments string. Validates syntax and
    provides helpful error messages with examples.
    
    Regex Pattern:
        ^&([a-zA-Z_][a-zA-Z0-9_]*)\\.([a-zA-Z_][a-zA-Z0-9_]*)\\((.*?)\\)$
        
        Breakdown:
        - ^& : Must start with ampersand
        - ([a-zA-Z_][a-zA-Z0-9_]*) : Plugin name (valid Python identifier)
        - \\. : Literal dot separator
        - ([a-zA-Z_][a-zA-Z0-9_]*) : Function name (valid Python identifier)
        - \\( : Literal opening parenthesis
        - (.*?) : Arguments (any characters, non-greedy)
        - \\) : Literal closing parenthesis
        - $ : Must end here
    
    Args:
        value: Plugin invocation string to parse
    
    Returns:
        Tuple[str, str, str]: (plugin_name, function_name, args_str)
            - plugin_name: Name of plugin file (without .py)
            - function_name: Name of function to call
            - args_str: Arguments string (may be empty)
    
    Raises:
        ValueError: If syntax doesn't match expected pattern
    
    Examples:
        >>> parse_plugin_invocation("&test_plugin.hello('Alice')")
        ('test_plugin', 'hello', "'Alice'")
        
        >>> parse_plugin_invocation("&IDGenerator.generate_uuid()")
        ('IDGenerator', 'generate_uuid', '')
        
        >>> parse_plugin_invocation("&math.add(10, 20)")
        ('math', 'add', '10, 20')
        
        >>> parse_plugin_invocation("&bad syntax")
        ValueError: Invalid plugin invocation syntax: &bad syntax
        ...
    
    Notes:
        - Plugin and function names must be valid Python identifiers
        - Arguments string is returned as-is (parsed separately)
        - Provides comprehensive error messages with examples
        - Regex is stored in REGEX_PLUGIN_INVOCATION constant
    
    See Also:
        - plugin_resolver.resolve_plugin_invocation: Uses this for parsing
        - plugin_args.parse_plugin_arguments: Parses the args_str component
    """
    # Pattern: &PluginName.function_name(args)
    match = re.match(REGEX_PLUGIN_INVOCATION, value)

    if not match:
        raise ValueError(
            f"{ERROR_MSG_INVALID_SYNTAX.format(value)}\n"
            f"{ERROR_MSG_EXPECTED_FORMAT}\n"
            f"{ERROR_MSG_SYNTAX_EXAMPLES}"
        )

    plugin_name, function_name, args_str = match.groups()
    return plugin_name, function_name, args_str


def resolve_plugin_path(zpath: str, zos: Any) -> str:
    """
    Resolve zPath to absolute file path using zParser.
    
    Delegates to zParser's resolve_symbol_path() to convert a zPath string
    (e.g., "@.utils.test_plugin") into an absolute filesystem path.
    
    zPath Format:
        symbol.part1.part2.partN
        
        Where:
        - symbol: @ (workspace root), ~ (home), etc.
        - parts: Directory/file path components
    
    Args:
        zpath: zPath string (e.g., "@.utils.test_plugin")
        zos: zOS instance with zparser subsystem
    
    Returns:
        str: Absolute file path (without .py extension)
    
    Examples:
        >>> resolve_plugin_path("@.utils.test_plugin", zos)
        "/Users/user/workspace/utils/test_plugin"
        
        >>> resolve_plugin_path("@.plugins.data_processor", zos)
        "/Users/user/workspace/plugins/data_processor"
        
        >>> resolve_plugin_path("@.zTestSuite.demos.demo_plugin", zos)
        "/Users/user/workspace/zTestSuite/demos/demo_plugin"
    
    Notes:
        - Uses zParser's resolve_symbol_path() for resolution
        - Splits zPath by dot to extract symbol and parts
        - Returns path without .py extension (added by caller)
        - Symbol resolution follows zParser rules
    
    See Also:
        - plugin_resolver.resolve_plugin_invocation: Uses this to resolve plugin paths
        - zParser.resolve_symbol_path: Underlying resolution logic
    """
    # Parse zPath
    parts = zpath.split(CHAR_DOT)
    symbol = parts[0]
    path_parts = parts[1:]

    # Resolve using zParser
    return zos.zparser.resolve_symbol_path(symbol, [symbol] + path_parts)
