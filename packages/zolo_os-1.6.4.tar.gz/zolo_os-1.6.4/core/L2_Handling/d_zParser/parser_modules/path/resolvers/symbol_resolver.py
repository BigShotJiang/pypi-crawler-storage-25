# zOS/core/L2_Handling/g_zParser/parser_modules/path/resolvers/symbol_resolver.py

"""
Symbol-based path resolution for path package.

Resolves paths based on symbol prefixes (@, ~, or none) for workspace-relative,
absolute, or relative path modes.

Public API:
    - resolve_symbol_path: Resolve @ or ~ symbol paths

Dependencies:
    - os: Path operations

Created: Phase 3.1 - Extract Resolvers from parser_path.py
"""

from zOS import os, Any, Dict, List, Optional

# Import constants from shared
from ...shared.file_constants import (
    SYMBOL_AT,
    SYMBOL_TILDE,
    SESSION_KEY_ZSPACE,
    LOG_MSG_SYMBOL_AT,
    LOG_MSG_SYMBOL_TILDE,
    LOG_MSG_SYMBOL_NONE,
    LOG_MSG_NO_WORKSPACE,
    LOG_MSG_NO_WORKSPACE_HELP,
    LOG_MSG_NO_WORKSPACE_FALLBACK,
    LOG_MSG_ZVAFOLDER_PATH
)


def resolve_symbol_path(
    symbol: Optional[str],
    zRelPath_parts: List[str],
    zSpace: str,
    zSession: Dict[str, Any],
    logger: Any
) -> str:
    """
    Resolve path based on symbol (@, ~, or no symbol).
    
    Internal helper that handles the three path resolution modes:
        - @ (at): Workspace-relative path
        - ~ (tilde): Absolute path from root
        - (none): Relative path from workspace
    
    Args:
        symbol: Path symbol prefix (SYMBOL_AT, SYMBOL_TILDE, or None)
        zRelPath_parts: List of path components (including symbol if present)
        zSpace: Workspace directory path
        zSession: Session dictionary (for workspace validation)
        logger: Logger instance for diagnostic output
    
    Returns:
        str: Resolved base path
    
    Examples:
        >>> resolve_symbol_path('@', ['@', 'config', 'data'], '/app', {}, logger)
        '/app/config/data'
        
        >>> resolve_symbol_path('~', ['~', 'etc', 'config'], '/app', {}, logger)
        '/etc/config'
        
        >>> resolve_symbol_path(None, ['config', 'data'], '/app', {}, logger)
        '/app/config/data'
    
    Notes:
        - @ symbol: Relative to zSpace in zSession (or cwd)
        - ~ symbol: Absolute path from root
        - No symbol: Relative to zSpace (same as @)
        - Logs warnings if @ used without configured workspace
        - Skips first part (symbol) when building path
    
    See Also:
        - zPath_decoder: Main function using this helper
    """
    if symbol == SYMBOL_AT:
        logger.framework.debug(LOG_MSG_SYMBOL_AT)

        # Warn if workspace not configured
        if not zSession.get(SESSION_KEY_ZSPACE):
            logger.warning(LOG_MSG_NO_WORKSPACE)
            logger.warning(LOG_MSG_NO_WORKSPACE_HELP)
            logger.warning(LOG_MSG_NO_WORKSPACE_FALLBACK, zSpace)

        # Build path: skip first part (symbol), join rest
        rel_base_parts = zRelPath_parts[1:]
        zVaFolder_basepath = os.path.join(zSpace, *rel_base_parts)
        logger.framework.debug(LOG_MSG_ZVAFOLDER_PATH, zVaFolder_basepath)

    elif symbol == SYMBOL_TILDE:
        logger.framework.debug(LOG_MSG_SYMBOL_TILDE)
        # Build path: skip first part (symbol), join rest from root
        rel_base_parts = zRelPath_parts[1:]
        zVaFolder_basepath = os.path.join(*rel_base_parts)

    else:
        logger.framework.debug(LOG_MSG_SYMBOL_NONE)
        # Build path: join all parts relative to workspace
        zVaFolder_basepath = os.path.join(zSpace, *(zRelPath_parts or []))

    return zVaFolder_basepath
