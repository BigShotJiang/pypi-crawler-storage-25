# zOS/core/L2_Core/i_zFunc/__init__.py
"""
zFunc subsystem.
"""

from .zFunc import zFunc  # noqa: F401

__all__ = ['zFunc']
