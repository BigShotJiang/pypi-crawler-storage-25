# zOS/core/L2_Core/c_zDisplay/zDisplay_modules/sandbox/terminal_executor.py

"""
Terminal Code Execution Sandbox
================================

Provides secure code execution for zTerminal events with restricted builtins.
Extracted from zDisplay.py to improve maintainability and reduce file size.

Supported Languages:
- Python: Restricted sandbox with safe builtins only
- Bash: Disabled for security (not safely sandboxable)
- Zolo: Full zOS execution through temporary swap file

Security Model:
- No file/network/system access
- No dangerous builtins (open, exec, eval, compile, __import__)
- Pre-configured zOS instance available as 'z' variable
- Custom input() wrapper using zDisplay.read_string()
"""

from zOS import Optional, Any, re, os


class TerminalExecutor:
    """Code execution sandbox for zTerminal events.
    
    Provides secure execution environment for Python, Bash (disabled), and Zolo code.
    """
    
    def __init__(self, display_instance: Any) -> None:
        """Initialize terminal executor with display instance.
        
        Args:
            display_instance: Parent zDisplay instance
        """
        self.display = display_instance
        self.zos = display_instance.zos
        self.zEvents = display_instance.zEvents
        self.mode = display_instance.mode
    
    def execute(
        self,
        content: str,
        language: str = "python",
        title: Optional[str] = None
    ) -> Optional[str]:
        """Execute code in sandbox and return output.
        
        Args:
            content: Code to execute
            language: Language (python, bash, zui)
            title: Optional title for display
        
        Returns:
            Captured output or None
        """
        # Bifrost mode: Skip execution (frontend handles rendering)
        if self.mode == 'zBifrost':
            return None
        
        # Parse code fences (```python ... ```)
        code_content, detected_lang = self._parse_code_fence(content)
        if detected_lang:
            language = detected_lang
        
        # Display header
        if title:
            self.zEvents.header(f"[{title}]", color="CYAN", indent=0, style="single")
        
        # Display code being executed
        self.zEvents.code(content=code_content, language=language, indent=0)
        
        # Execute based on language
        if language.lower() == "python":
            return self._execute_python(code_content)
        elif language.lower() == "bash":
            return self._execute_bash()
        elif language.lower() == "zui":
            return self._execute_zui(code_content, title)
        else:
            self.zEvents.warning(f"Language '{language}' not yet supported", indent=0)
            return None
    
    def _parse_code_fence(self, content: str) -> tuple[str, Optional[str]]:
        """Parse code fence and extract content and language.
        
        Args:
            content: Raw content (may include ```python ... ```)
        
        Returns:
            Tuple of (code_content, detected_language)
        """
        fence_match = re.match(r'^```(\w+)?\s*\n?(.*?)(`{3,})\s*$', content, re.DOTALL)
        if fence_match:
            detected_lang = (fence_match.group(1) or 'text').lower()
            inner_content = fence_match.group(2)
            closing_backticks = fence_match.group(3)
            
            # Handle nested fences (6+ backticks)
            if len(closing_backticks) > 3:
                remaining_backticks = '`' * (len(closing_backticks) - 3)
                inner_content = inner_content.rstrip() + remaining_backticks
            
            return inner_content.strip(), detected_lang
        return content.strip(), None
    
    def _execute_python(self, code_content: str) -> Optional[str]:
        """Execute Python code in restricted sandbox.
        
        Args:
            code_content: Python code to execute
        
        Returns:
            None (output displayed directly)
        """
        # Wrap Python's input() to use zDisplay.read_string()
        def sandbox_input(prompt=""):
            return self.display.read_string(prompt)
        
        SAFE_BUILTINS = {
            'print': print,
            'input': sandbox_input,
            'int': int, 'float': float, 'str': str, 'bool': bool,
            'list': list, 'dict': dict, 'tuple': tuple, 'set': set,
            'bytes': bytes, 'bytearray': bytearray,
            'range': range, 'enumerate': enumerate, 'zip': zip,
            'map': map, 'filter': filter, 'reversed': reversed, 'sorted': sorted,
            'len': len, 'min': min, 'max': max, 'sum': sum,
            'all': all, 'any': any,
            'abs': abs, 'round': round, 'pow': pow, 'divmod': divmod,
            'chr': chr, 'ord': ord, 'repr': repr, 'format': format,
            'type': type, 'isinstance': isinstance, 'issubclass': issubclass,
            'hasattr': hasattr, 'getattr': getattr,
            'callable': callable, 'id': id, 'hash': hash,
            'Exception': Exception, 'TypeError': TypeError, 'ValueError': ValueError,
            'KeyError': KeyError, 'IndexError': IndexError, 'AttributeError': AttributeError,
            'RuntimeError': RuntimeError, 'StopIteration': StopIteration,
            'ZeroDivisionError': ZeroDivisionError,
            'True': True, 'False': False, 'None': None,
        }
        
        exec_globals = {"__builtins__": SAFE_BUILTINS}
        exec_globals['z'] = self.zos
        
        try:
            exec(code_content, exec_globals, {})  # pylint: disable=exec-used
            return None
        except NameError as e:
            self.zEvents.error(f"Sandbox Error: {e} (blocked for security)", indent=0)
            return None
        except Exception as e:
            self.zEvents.error(f"Error: {type(e).__name__}: {e}", indent=0)
            return None
    
    def _execute_bash(self) -> Optional[str]:
        """Bash execution disabled for security.
        
        Returns:
            None (error message displayed)
        """
        self.zEvents.error("Bash execution disabled in sandbox mode", indent=0)
        self.zEvents.info("Use 'python' or 'zui' instead", indent=0)
        return None
    
    def _execute_zui(self, code_content: str, title: Optional[str]) -> Optional[str]:
        """Execute zUI code through full zWalker pipeline.
        
        Args:
            code_content: zUI code to execute
            title: Optional title for swap file
        
        Returns:
            None (output displayed directly)
        """
        try:
            # Sanitize title for filename
            sanitized_title = re.sub(r'[^a-zA-Z0-9]', '_', title or 'zTerminal_Swap')
            sanitized_title = re.sub(r'_+', '_', sanitized_title).strip('_') or 'zTerminal_Swap'
            
            # Swap file in zSpace
            zspace = self.zos.session.get('zSpace', os.getcwd())
            swap_filename = f"zUI.{sanitized_title}.zolo"
            swap_path = os.path.join(zspace, swap_filename)
            
            # Write content to swap file
            with open(swap_path, 'w', encoding='utf-8') as swap_file:
                swap_file.write(code_content)
            
            try:
                from zOS import zOS as zOS_Class
                
                zSpark = {
                    "zState": "Production",
                    "title": f"zTerminal: {title or 'Swap'}",
                    "zScrap": "PROD",
                    "zMode": "zCLI",
                    "zSpace": zspace,
                    "zVaFolder": "@",
                    "zVaFile": f"zUI.{sanitized_title}",
                    "zBlock": "zVaF",
                }
                
                # Run new zOS instance
                z_temp = zOS_Class(zSpark)
                z_temp.run()
            finally:
                # Clean up swap file
                if os.path.exists(swap_path):
                    os.unlink(swap_path)
            
            return None
        except Exception as e:
            self.zEvents.error(f"Zolo Error: {e}", indent=0)
            return None
