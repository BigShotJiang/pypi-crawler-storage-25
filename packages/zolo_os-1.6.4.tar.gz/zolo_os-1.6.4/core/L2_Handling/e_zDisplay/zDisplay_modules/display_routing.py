# zOS/core/L2_Core/c_zDisplay/zDisplay_modules/display_routing.py

"""
Event Routing Map - Single Source of Truth
===========================================

Centralizes event routing logic for zDisplay subsystem.
This module provides a single function to build the event routing map,
eliminating duplication between zDisplay.py and other modules.

Usage:
    from .display_routing import build_event_map
    
    self._event_map = build_event_map(self.zEvents, self.zPrimitives, self._terminal_executor)
"""

from zOS import Dict, Callable, Any
from .display_constants import (
    _EVENT_TEXT,
    _EVENT_RICH_TEXT,
    _EVENT_HEADER,
    _EVENT_CODE,
    _EVENT_LINE,
    _EVENT_ERROR,
    _EVENT_WARNING,
    _EVENT_SUCCESS,
    _EVENT_INFO,
    _EVENT_ZMARKER,
    _EVENT_LIST,
    _EVENT_DL,
    _EVENT_JSON,
    _EVENT_JSON_DATA,
    _EVENT_ZTABLE,
    _EVENT_IMAGE,
    _EVENT_VIDEO,
    _EVENT_AUDIO,
    _EVENT_PICTURE,
    _EVENT_ICON,
    _EVENT_ZDECLARE,
    _EVENT_ZSESSION,
    _EVENT_ZCONFIG,
    _EVENT_ZCRUMBS,
    _EVENT_ZMENU,
    _EVENT_ZDASH,
    _EVENT_ZDIALOG,
    _EVENT_ZTERMINAL,
    _EVENT_PROGRESS_BAR,
    _EVENT_SPINNER,
    _EVENT_PROGRESS_ITERATOR,
    _EVENT_INDETERMINATE_PROGRESS,
    _EVENT_SELECTION,
    _EVENT_READ_STRING,
    _EVENT_READ_PASSWORD,
    _EVENT_READ_BOOL,
    _EVENT_READ_RANGE,
    _EVENT_BUTTON,
    _EVENT_LINK,
    _EVENT_WRITE_RAW,
    _EVENT_WRITE_LINE,
    _EVENT_WRITE_BLOCK,
)


def build_event_map(
    events: Any,
    primitives: Any,
    terminal_executor: Any
) -> Dict[str, Callable]:
    """Build unified event routing map (SSOT).
    
    Single source of truth for event routing. Maps event names to handler functions.
    
    Args:
        events: zEvents instance with all event packages
        primitives: zPrimitives instance for I/O operations
        terminal_executor: TerminalExecutor instance for code execution
    
    Returns:
        Dict mapping event names to handler callables
    
    Example:
        self._event_map = build_event_map(self.zEvents, self.zPrimitives, self._terminal_executor)
        handler = self._event_map.get('text')
        handler(content="Hello")
    """
    # zText paragraph spacing: only the dispatched zText event gets a trailing \n.
    # Internal text() calls (error, warning, zCrumbs, selection, etc.) go directly
    # to BasicOutputs.text() and never hit this wrapper.
    def _ztext_event(**kw):
        events.text(**kw)
        if events.BasicOutputs.display.mode in ("zCLI", "Walker", ""):
            primitives.raw('\n')

    return {
        # Output events
        _EVENT_TEXT: _ztext_event,
        _EVENT_RICH_TEXT: events.rich_text,
        _EVENT_HEADER: events.header,
        _EVENT_CODE: events.code,
        _EVENT_LINE: events.text,

        # Signal events
        _EVENT_ERROR: events.error,
        _EVENT_WARNING: events.warning,
        _EVENT_SUCCESS: events.success,
        _EVENT_INFO: events.info,
        _EVENT_ZMARKER: events.zMarker,

        # Data events
        _EVENT_LIST: events.list,
        _EVENT_DL: lambda **kwargs: events.list(style='details', **kwargs),
        _EVENT_JSON: events.json_data,
        _EVENT_JSON_DATA: events.json_data,
        _EVENT_ZTABLE: events.zTable,

        # Media events
        _EVENT_IMAGE: events.image,
        _EVENT_VIDEO: events.video,
        _EVENT_AUDIO: events.audio,
        _EVENT_PICTURE: events.picture,
        _EVENT_ICON: events.icon,

        # System events
        _EVENT_ZDECLARE: events.zDeclare,
        _EVENT_ZSESSION: events.zSession,
        _EVENT_ZCONFIG: events.zConfig,
        _EVENT_ZCRUMBS: events.zCrumbs,
        _EVENT_ZMENU: events.zMenu,
        _EVENT_ZDASH: events.zDash,
        _EVENT_ZDIALOG: events.zDialog,
        _EVENT_ZTERMINAL: lambda **kwargs: terminal_executor.execute(**kwargs),

        # Widget events (progress, spinners)
        _EVENT_PROGRESS_BAR: events.progress_bar,
        _EVENT_SPINNER: events.spinner,
        _EVENT_PROGRESS_ITERATOR: events.progress_iterator,
        _EVENT_INDETERMINATE_PROGRESS: events.indeterminate_progress,

        # Input events
        _EVENT_SELECTION: events.selection,
        _EVENT_READ_STRING: primitives.read_string,
        _EVENT_READ_PASSWORD: primitives.read_password,
        _EVENT_READ_BOOL: events.BasicInputs.read_bool,
        _EVENT_READ_RANGE: events.InteractiveInputs.read_range,
        _EVENT_BUTTON: events.button,
        _EVENT_LINK: events.link,

        # Primitive events
        _EVENT_WRITE_RAW: primitives.raw,
        _EVENT_WRITE_LINE: primitives.line,
        _EVENT_WRITE_BLOCK: primitives.block,
    }
