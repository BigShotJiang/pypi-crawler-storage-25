# zOS/core/L2_Core/c_zDisplay/zDisplay_modules/d_compounds/inputs/selection_collector.py

"""
Selection Collector - Helper module for BasicInputs
====================================================

Provides input collection logic:
- Single-select collection with validation
- Multi-select collection with toggle behavior
- Button confirmation collection
"""

from zOS import Any, List, Set, Optional

from ...display_constants import (  # pylint: disable=relative-beyond-top-level
    _PROMPT_INPUT,
    _PROMPT_SINGLE_SELECT_TEMPLATE,
    _PROMPT_BUTTON_TEMPLATE,
    _CMD_DONE,
    _CMD_DONE_SHORT,
    _CMD_EMPTY,
    _OPTION_INDEX_OFFSET,
    _MSG_MULTI_SELECT_INSTRUCTIONS,
    _MSG_BUTTON_CLICKED,
    _MSG_BUTTON_CANCELLED,
)
from ...basic.outputs.semantic_colors import get_semantic_color


class SelectionCollector:
    """Input collection logic for BasicInputs."""

    def __init__(self, display_instance: Any) -> None:
        """Initialize SelectionCollector with display reference.
        
        Args:
            display_instance: Parent zDisplay instance
        """
        self.display = display_instance
        self.zPrimitives = display_instance.zPrimitives
        self.zColors = display_instance.zColors

    def collect_single_selection(
        self,
        options: List[str],
        default: Optional[str],
        validator: Any,
        renderer: Any,
        basic_outputs: Optional[Any] = None
    ) -> Optional[str]:
        """Collect single selection from user with validation.
        
        Args:
            options: List of option strings
            default: Default option (or None)
            validator: InputValidators instance
            renderer: SelectionRenderer instance
            basic_outputs: BasicOutputs instance (optional)
            
        Returns:
            Optional[str]: Selected option or None if cancelled
        """
        # Build default hint — show value name, not index
        default_hint = _CMD_EMPTY
        if default is not None and default in options:
            default_hint = f" [{default}]"

        # Get selection with validation loop
        while True:
            try:
                prompt = _PROMPT_SINGLE_SELECT_TEMPLATE.format(
                    max_num=len(options),
                    default_hint=default_hint
                )
                selection = self.zPrimitives.read_string(prompt).strip()

                # Validate
                is_valid, result = validator.validate_single_selection(
                    selection, options, default
                )

                if is_valid:
                    renderer.display_feedback(f"  > {result} [selected]", basic_outputs=basic_outputs)
                    return result
                else:
                    # Display error message
                    renderer.display_feedback(result, basic_outputs=basic_outputs)

            except KeyboardInterrupt:
                return None

    def collect_multi_selection(
        self,
        options: List[str],
        default_set: Set[str],
        validator: Any,
        renderer: Any,
        basic_outputs: Optional[Any] = None
    ) -> List[str]:
        """Collect multiple selections from user with toggle behavior.
        
        Args:
            options: List of option strings
            default_set: Set of default selections
            validator: InputValidators instance
            renderer: SelectionRenderer instance
            basic_outputs: BasicOutputs instance (optional)
            
        Returns:
            List[str]: List of selected options
        """
        renderer.output_text(
            _MSG_MULTI_SELECT_INSTRUCTIONS,
            break_after=False,
            basic_outputs=basic_outputs
        )

        selected = set(default_set) if default_set else set()

        while True:
            try:
                default_hint = f" [{', '.join(sorted(selected))}]" if selected else ""
                user_input = self.zPrimitives.read_string(f"Input{default_hint}: ").strip().lower()

                if user_input in (_CMD_DONE, _CMD_DONE_SHORT, _CMD_EMPTY):
                    if selected:
                        renderer.display_feedback(
                            f"  > {', '.join(sorted(selected))} [selected]",
                            basic_outputs=basic_outputs
                        )
                    break

                # Parse numbers
                numbers = user_input.split()
                for num_str in numbers:
                    _, feedback = validator.process_multi_selection_number(
                        num_str, options, selected
                    )
                    # Display feedback
                    renderer.display_feedback(feedback, basic_outputs=basic_outputs)

            except KeyboardInterrupt:
                break

        return list(selected)

    def collect_button_confirmation(
        self,
        label: str,
        color: str,
        action: Optional[str],
        renderer: Any,
        basic_outputs: Optional[Any] = None,
        zIcon: Optional[str] = None
    ) -> bool:
        """Collect button click confirmation in terminal mode.
        
        Args:
            label: Button label text
            color: Button semantic color
            action: Optional action identifier
            renderer: SelectionRenderer instance
            basic_outputs: BasicOutputs instance (optional)
            zIcon: Optional icon name (renders emoji in terminal instead of label)
            
        Returns:
            bool: True if confirmed (y/yes only), False otherwise
        """
        try:
            # Use centralized color mapping
            terminal_color = get_semantic_color(color)
            
            # Render icon in terminal mode if provided — always keep label
            if zIcon:
                icon_text = self._render_icon_for_terminal(zIcon)
                display_text = f"{label} [{icon_text}]" if icon_text != zIcon else label
            else:
                display_text = label
            
            prompt_text = _PROMPT_BUTTON_TEMPLATE.format(label=display_text)

            # Apply semantic color if available
            if terminal_color:
                colored_prompt = f"{terminal_color}{prompt_text}{self.zColors.RESET}"
            else:
                colored_prompt = prompt_text

            # Collect and validate response — only y/yes/n/no/empty accepted
            _VALID_BTN = ('y', 'yes', 'n', 'no', '')
            while True:
                response = self.zPrimitives.read_string(colored_prompt).strip().lower()
                if response in _VALID_BTN:
                    break
                if hasattr(self.display, 'error'):
                    self.display.error("Invalid input — please enter 'y' or 'n'.")
                else:
                    print("  Invalid input — please enter 'y' or 'n'.")

            # Log response
            if hasattr(self.display, 'zos') and hasattr(self.display.zos, 'logger'):
                self.display.zos.logger.info(f"🔘 Button response: '{response}' (color: {color})")

            # MUST type 'y' or 'yes' - empty/n/no all cancel
            if response in ('y', 'yes'):
                renderer.display_feedback(
                    _MSG_BUTTON_CLICKED.format(label=label),
                    basic_outputs=basic_outputs
                )

                # Execute action if provided
                if action and isinstance(action, str):
                    if action.startswith('&'):
                        self._execute_button_action(action)
                    elif action != '#':
                        # Return action as navigation/jump target for wizard step-jumps
                        return action

                return True
            else:
                renderer.display_feedback(
                    _MSG_BUTTON_CANCELLED.format(label=label),
                    basic_outputs=basic_outputs
                )
                return False

        except KeyboardInterrupt:
            renderer.display_feedback(
                _MSG_BUTTON_CANCELLED.format(label=label),
                basic_outputs=basic_outputs
            )
            return False

    def _execute_button_action(self, action: str) -> None:
        """Execute button action (plugin invocation).
        
        Args:
            action: Action string starting with '&'
        """
        try:
            if hasattr(self.display, 'zos') and hasattr(self.display.zos, 'zparser'):
                self.display.zos.logger.debug(f"🎯 Executing button action: {action}")
                result = self.display.zos.zparser.resolve_plugin_invocation(action, self.display.zos)
                self.display.zos.logger.debug(f"✅ Button action executed, result: {result}")
            else:
                if hasattr(self.display, 'zos') and hasattr(self.display.zos, 'logger'):
                    self.display.zos.logger.warning(
                        f"⚠️  Cannot execute button action - zparser not available: {action}"
                    )
        except Exception as e:
            if hasattr(self.display, 'zos') and hasattr(self.display.zos, 'logger'):
                self.display.zos.logger.error(f"❌ Button action execution failed: {e}", exc_info=True)

    def _render_icon_for_terminal(self, icon_name: str) -> str:
        """Render icon as ANSI-safe text for terminal mode."""
        try:
            from ......zSys.accessibility import get_icon_mapper, get_emoji_descriptions
            emoji = get_icon_mapper().render_for_mode(icon_name, mode="zCLI")
            safe = get_emoji_descriptions().format_for_terminal(emoji)
            # Strip outer brackets — the prompt template adds its own []
            if safe.startswith('[') and safe.endswith(']'):
                safe = safe[1:-1]
            return safe
        except Exception:
            return icon_name
