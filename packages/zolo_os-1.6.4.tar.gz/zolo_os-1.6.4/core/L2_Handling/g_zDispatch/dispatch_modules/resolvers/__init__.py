# zOS/core/L2_Handling/e_zDispatch/dispatch_modules/resolvers/__init__.py

"""
Data Resolvers for zDispatch Subsystem.

This package provides resolution logic for different data sources
(zUI files, zData queries, session variables).

Components:
    - DataResolver: %data.* variable resolution and data query execution
    - UIResolver: zUI key resolution for Bifrost mode

These resolvers transform references and queries into concrete data values.
"""

from .resolver_data import DataResolver
from .resolver_ui import UIResolver

__all__ = ['DataResolver', 'UIResolver']
