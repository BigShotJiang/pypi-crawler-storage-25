# zOS/core/L2_Core/e_zDispatch/dispatch_modules/dispatch_modifiers.py

"""
Modifier Processor Orchestrator for zDispatch Subsystem.

This module provides the ModifierProcessor class, which orchestrates prefix and suffix
modifiers by delegating to domain-specific modifier implementations.

Architecture:
    The ModifierProcessor follows an orchestrator pattern:
    
    1. Detection Phase:
       - check_prefix(): Detects prefix modifiers (^ ~)
       - check_suffix(): Detects suffix modifiers (* !)
    
    2. Processing Phase:
       - process(): Routes to domain-specific modifier implementations
       - Delegates to MenuModifier, BounceModifier, RequiredModifier
       - Handles mode-specific return values (zCLI vs. Bifrost)

Modifier Semantics:
    PREFIX MODIFIERS:
    - ^ (caret): "Bounce Back" - Execute action, then return to previous menu
    - ~ (tilde): "Anchor" - Disable back navigation (used with *)
    
    SUFFIX MODIFIERS:
    - * (asterisk): "Menu" - Create menu from horizontal data
    - ! (exclamation): "Required" - Retry until success

Refactoring:
    This file was refactored from 713 lines → ~200 lines by extracting:
    - MenuModifier → modifiers/modifier_menu.py
    - BounceModifier → modifiers/modifier_bounce.py
    - RequiredModifier → modifiers/modifier_required.py
"""

from zOS import Any, Optional, Dict, List, Union

# Import all dispatch constants from centralized location
from .dispatch_constants import (
    # Modifiers
    MOD_CARET,
    MOD_ASTERISK,
    MOD_EXCLAMATION,
    PREFIX_MODIFIERS,
    SUFFIX_MODIFIERS,
    # Log Messages (INTERNAL)
    _LOG_MSG_PARSING_PREFIX,
    _LOG_MSG_PARSING_SUFFIX,
    _LOG_MSG_PRE_MODIFIERS,
    _LOG_MSG_SUF_MODIFIERS,
    _LOG_MSG_RESOLVED,
    # Display Labels (INTERNAL)
    _LABEL_PROCESS_MODIFIERS,
    _DEFAULT_INDENT_PROCESS,
)

# Import domain-specific modifier implementations
from .modifiers.modifier_menu import MenuModifier
from .modifiers.modifier_bounce import BounceModifier
from .modifiers.modifier_required import RequiredModifier


class ModifierProcessor:
    """
    Modifier processor orchestrator for zDispatch subsystem.
    
    Delegates modifier processing to domain-specific implementations:
    - MenuModifier: Handles * (asterisk) modifier
    - BounceModifier: Handles ^ (caret) modifier
    - RequiredModifier: Handles ! (exclamation) modifier
    
    Attributes:
        dispatch: Parent zDispatch instance
        zos: zOS framework instance (provides subsystems, logger)
        logger: Logger instance for debug output
        menu_modifier: MenuModifier instance for * processing
        bounce_modifier: BounceModifier instance for ^ processing
        required_modifier: RequiredModifier instance for ! processing
    
    Methods:
        check_prefix(zKey): Detect prefix modifiers (^ ~)
        check_suffix(zKey): Detect suffix modifiers (* !)
        process(modifiers, zKey, zHorizontal, context, walker): Execute modifiers
    
    Integration:
        - CommandLauncher: Delegates unmodified commands to launcher
        - Domain Modifiers: Routes to MenuModifier, BounceModifier, RequiredModifier
    """

    # Class-level type declarations
    dispatch: Any  # zDispatch instance
    zos: Any  # zOS framework instance
    logger: Any  # Logger instance
    menu_modifier: MenuModifier
    bounce_modifier: BounceModifier
    required_modifier: RequiredModifier

    def __init__(self, dispatch: Any) -> None:
        """
        Initialize modifier processor with parent dispatch instance.
        
        Args:
            dispatch: Parent zDispatch instance providing access to zOS and logger
        
        Example:
            processor = ModifierProcessor(dispatch)
        """
        self.dispatch = dispatch
        self.zos = dispatch.zos
        self.logger = dispatch.logger

        # Initialize domain-specific modifier implementations
        self.menu_modifier = MenuModifier(dispatch, self.zos, self.logger)
        self.bounce_modifier = BounceModifier(dispatch, self.zos, self.logger)
        self.required_modifier = RequiredModifier(dispatch, self.zos, self.logger)

    # ========================================================================
    # PUBLIC METHODS - Modifier Detection
    # ========================================================================

    def check_prefix(self, zKey: str) -> List[str]:
        """
        Check for prefix modifiers at the start of a key.
        
        Detects the following prefix modifiers:
        - ^ (caret): Bounce back modifier
        - ~ (tilde): Anchor modifier
        
        Args:
            zKey: Key string to check for prefix modifiers
        
        Returns:
            List of detected prefix modifier symbols (may be empty)
        
        Examples:
            check_prefix("^action")  # Returns ["^"]
            check_prefix("~menu*")   # Returns ["~"]
            check_prefix("action")   # Returns []
        """
        self.logger.framework.debug(_LOG_MSG_PARSING_PREFIX, zKey)
        pre_modifiers = [sym for sym in PREFIX_MODIFIERS if zKey.startswith(sym)]
        self.logger.framework.debug(_LOG_MSG_PRE_MODIFIERS, pre_modifiers)
        return pre_modifiers

    def check_suffix(self, zKey: str) -> List[str]:
        """
        Check for suffix modifiers at the end of a key.
        
        Detects the following suffix modifiers:
        - ! (exclamation): Required modifier
        - * (asterisk): Menu modifier
        
        Args:
            zKey: Key string to check for suffix modifiers
        
        Returns:
            List of detected suffix modifier symbols (may be empty)
        
        Examples:
            check_suffix("validate!")  # Returns ["!"]
            check_suffix("menu*")      # Returns ["*"]
            check_suffix("action")     # Returns []
        """
        self.logger.framework.debug(_LOG_MSG_PARSING_SUFFIX, zKey)
        suf_modifiers = [sym for sym in SUFFIX_MODIFIERS if zKey.endswith(sym)]
        self.logger.framework.debug(_LOG_MSG_SUF_MODIFIERS, suf_modifiers)
        return suf_modifiers

    # ========================================================================
    # PUBLIC METHODS - Modifier Processing
    # ========================================================================

    def process(
        self,
        modifiers: List[str],
        zKey: str,
        zHorizontal: Any,
        context: Optional[Dict[str, Any]] = None,
        walker: Optional[Any] = None
    ) -> Optional[Union[str, Any]]:
        """
        Process modifiers by delegating to domain-specific implementations (ORCHESTRATOR).
        
        Routes modifier processing to focused handlers. Refactored from 713 lines
        to ~200 lines by extracting domain-specific logic.
        
        Modifier priority:
        1. * (menu): Create menu via zNavigation → MenuModifier
        2. ^ (bounce): Execute action → return based on mode → BounceModifier
        3. ! (required): Retry loop until success → RequiredModifier
        4. No modifiers: Pass through to launcher
        
        Args:
            modifiers: List of detected modifier symbols
            zKey: Original key with modifiers
            zHorizontal: Command/data to execute
            context: Optional context dict
            walker: Optional walker instance
        
        Returns:
            Modifier-specific result (varies by modifier type)
        
        Examples:
            result = process(["*"], "menu*", menu_dict, context, walker)
            result = process(["^"], "^save", {"zFunc": "save"}, context, walker)
            result = process(["!"], "validate!", {"zFunc": "validate"}, context, walker)
        
        Notes:
            - Delegates to MenuModifier, BounceModifier, RequiredModifier
            - Mode-specific behavior handled in domain modifiers
            - Maintains backward compatibility with all modifier types
        """
        # Use walker's display if available, otherwise use zOS display
        display = walker.display if walker else self.zos.display

        self._display_modifier(display, _LABEL_PROCESS_MODIFIERS, _DEFAULT_INDENT_PROCESS)
        self.logger.framework.debug(_LOG_MSG_RESOLVED, modifiers, zKey)

        # Priority 1: Menu modifier (*) → Delegate to MenuModifier
        if MOD_ASTERISK in modifiers:
            return self.menu_modifier.process(modifiers, zKey, zHorizontal, walker)

        # Priority 2: Bounce modifier (^) → Delegate to BounceModifier
        if MOD_CARET in modifiers:
            return self.bounce_modifier.process(zHorizontal, context, walker, display)

        # Priority 3: Required modifier (!) → Delegate to RequiredModifier
        if MOD_EXCLAMATION in modifiers:
            return self.required_modifier.process(zKey, zHorizontal, context, walker, display)

        # No modifiers: Pass through to launcher
        return self.dispatch.launcher.launch(zHorizontal, context=context, walker=walker)

    # ========================================================================
    # DISPLAY HELPERS
    # ========================================================================

    def _display_modifier(
        self,
        display: Any,
        label: str,
        indent: int,
        style: str = "wavy"
    ) -> None:
        """
        Display modifier processing label (optional UI styling).
        
        Args:
            display: zDisplay instance
            label: Label text to display
            indent: Indentation level
            style: Border style (default: "wavy")
        
        Notes:
            - Only displays if display instance is available
            - Uses zDisplay.zDeclare() for UI output
        """
        if display and hasattr(display, 'zDeclare'):
            display.zDeclare(
                label=label,
                indent=indent,
                style=style
            )
