# zOS/core/L2_Core/e_zDispatch/dispatch_modules/dispatch_launcher.py

"""
Command Launcher for zDispatch Subsystem
=========================================

Central dispatcher routing commands to subsystems (zFunc, zNavigation, zWizard, zData, etc.).

Architecture:
    Two command pathways:
    1. String: "zFunc(...)", "zLink(...)", "zOpen(...)", "zWizard(...)", "zRead(...)"
    2. Dict: {"zFunc": ...}, {"zLink": ...}, {"zData": ...}, {"zDialog": ...}
    
    Flow: launch() → _launch_string() or _launch_dict() → subsystem handler

Mode Behavior:
    - zCLI: Plain strings return None, zWizard returns "zBack"
    - Bifrost: Plain strings resolve from zUI, zWizard returns actual result

Plugin Support: "&" prefix in zFunc commands (e.g., "zFunc(&my_plugin)")
CRUD Detection: Auto-routes generic CRUD dicts (action, model, table keys) to zData

Usage:
    launcher.launch("zFunc(calculate)")
    launcher.launch({"zRead": {"model": "users", "where": {"id": 1}}})
    launcher.launch({"action": "read", "model": "users"})  # Auto-detected CRUD
"""

from zOS import Any, Optional, Dict, Union, List

# Import ACTION_PLACEHOLDER from zConfig
from zOS.L1_Foundation.a_zConfig.zConfig_modules import ACTION_PLACEHOLDER

# Import all dispatch constants from centralized location
from .dispatch_constants import (
    # Dict Keys - Subsystem Commands
    KEY_ZFUNC,
    KEY_ZLINK,
    KEY_ZDELTA,
    KEY_ZWIZARD,
    KEY_ZREAD,
    KEY_ZDATA,
    KEY_ZDIALOG,
    KEY_ZDASH,
    KEY_ZDISPLAY,
    KEY_ZLOGIN,
    KEY_ZLOGOUT,
    # Dict Keys - Context & Session
    KEY_ZVAFILE,
    KEY_ZBLOCK,
    KEY_MESSAGE,
    KEY_ACTION,
    # Mode Values
    MODE_BIFROST,
    # Display Labels (INTERNAL)
    _LABEL_LAUNCHER,
    # Default Values (INTERNAL)
    _DEFAULT_ZBLOCK,
    _DEFAULT_INDENT_LAUNCHER,
    _DEFAULT_STYLE_SINGLE,
)

# Import new domain-based architecture modules
from .resolvers.resolver_data import DataResolver
from .handlers.handler_auth import AuthHandler
from .handlers.handler_crud import CRUDHandler
from .handlers.handler_navigation import NavigationHandler
from .handlers.handler_subsystems import SubsystemRouter
from .shorthand_expander import ShorthandExpander
from .commands.command_wizard_detector import WizardDetector
from .expansion.expander_organizational import OrganizationalHandler
from .commands.command_list import ListCommandHandler
from .commands.command_string_parser import StringCommandHandler
from .handlers.handler_routing import RoutingHandlers
from .handlers.handler_wizard_data import WizardDataHandlers


class CommandLauncher(RoutingHandlers, WizardDataHandlers):
    """
    Central command launcher for zDispatch subsystem.
    
    Routes string and dict commands to appropriate subsystem handlers, with mode-aware
    behavior for zCLI vs. Bifrost execution environments.
    
    Attributes:
        dispatch: Parent zDispatch instance
        zos: zOS framework instance
        logger: Logger instance from zOS
        display: zDisplay instance for UI output
    
    Methods:
        launch(): Main entry point for command routing (type detection)
        _launch_string(): Route string-based commands (zFunc(), zLink(), etc.)
        _launch_dict(): Route dict-based commands ({zFunc:, zLink:, etc.})
        _handle_wizard_string(): Parse and execute wizard from string
        _handle_wizard_dict(): Execute wizard from dict
        _handle_read_string(): Handle zRead string -> zData
        _handle_read_dict(): Handle zRead dict -> zData
        _handle_data_dict(): Handle zData dict -> zData
        _handle_crud_dict(): Handle generic CRUD dict -> zData
        
        Helper methods (DRY):
        _display_handler(): Display handler label with consistent styling
        _log_detected(): Log detected command with consistent format
    
    Integration:
        - zConfig: Uses ACTION_PLACEHOLDER constant
        - zDisplay: UI output via zDeclare() and text()
        - zSession: Mode detection via context dict
        - Forward dependencies: 8 subsystems (see module docstring)
    """

    # Class-level type declarations
    dispatch: Any  # zDispatch instance
    zos: Any  # zOS framework instance
    logger: Any  # Logger instance
    display: Any  # zDisplay instance

    def __init__(self, dispatch: Any) -> None:
        """
        Initialize command launcher with parent dispatch instance.
        
        Args:
            dispatch: Parent zDispatch instance providing access to zCLI, logger, and display
        
        Raises:
            AttributeError: If dispatch is missing required attributes (zos, logger)
        
        Example:
            launcher = CommandLauncher(dispatch)
        """
        self.dispatch = dispatch
        self.zos = dispatch.zos
        self.logger = dispatch.logger
        self.display = dispatch.zos.display

        # ========================================================================
        # Phase 5 Micro-Step 5.1: Initialize Extracted Modules
        # ========================================================================
        # These modules are initialized but not yet used. They will be integrated
        # incrementally in subsequent micro-steps.

        # Phase 1 modules (Leaf)
        self.data_resolver = DataResolver(self.zos)
        self.auth_handler = AuthHandler(self.zos, self.display, self.logger)
        self.crud_handler = CRUDHandler(self.zos, self.display, self.logger)

        # Phase 2 modules (Core Logic)
        self.navigation_handler = NavigationHandler(self.zos, self.display, self.logger)
        self.subsystem_router = SubsystemRouter(
            self.zos,
            self.display,
            self.logger,
            self.auth_handler,
            self.navigation_handler
        )

        # Phase 3 modules (Shorthand & Detection)
        self.shorthand_expander = ShorthandExpander(self.logger)
        self.wizard_detector = WizardDetector()
        self.organizational_handler = OrganizationalHandler(
            self.shorthand_expander,  # Needs expander, not zos
            self.logger
        )

        # Phase 4 modules (Command Handlers)
        self.list_handler = ListCommandHandler(self.zos, self.logger)
        self.string_handler = StringCommandHandler(
            self.zos,
            self.logger,
            self.subsystem_router,
            self.launch  # Pass launch function for recursion
        )
        # Note: dict_handler will be added in later micro-step (has circular deps)

    # ========================================================================
    # PUBLIC METHODS - Main Entry Points
    # ========================================================================

    def launch(
        self,
        zHorizontal: Union[str, Dict[str, Any]],
        context: Optional[Dict[str, Any]] = None,
        walker: Optional[Any] = None
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Main entry point: routes string/dict commands to appropriate handlers."""
        self._display_handler(_LABEL_LAUNCHER, _DEFAULT_INDENT_LAUNCHER)

        # Early return for placeholder actions (development/testing)
        if zHorizontal == ACTION_PLACEHOLDER:
            self.logger.debug(f"[CommandLauncher] Placeholder action detected: '{ACTION_PLACEHOLDER}' - no-op")
            return None

        if isinstance(zHorizontal, str):
            return self._launch_string(zHorizontal, context, walker)
        elif isinstance(zHorizontal, dict):
            return self._launch_dict(zHorizontal, context, walker)
        elif isinstance(zHorizontal, list):
            return self._launch_list(zHorizontal, context, walker)

        # Unknown type - return None
        return None

    # ========================================================================
    # PRIVATE METHODS - List Command Routing (Sequential Execution)
    # ========================================================================

    def _launch_list(
        self,
        zHorizontal: list,
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Delegate list command handling to ListCommandHandler."""
        return self.list_handler.handle(zHorizontal, context, walker, self.launch)

    # ========================================================================
    # PRIVATE METHODS - String Command Routing
    # ========================================================================

    def _launch_string(
        self,
        zHorizontal: str,
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Delegate string command handling to StringCommandHandler."""
        return self.string_handler.handle(zHorizontal, context, walker)

    # ========================================================================
    # STRING ROUTING HELPERS - Decomposed from _launch_string()
    # ========================================================================

    def _resolve_plain_string_in_bifrost(
        self,
        zHorizontal: str,
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Union[Dict[str, Any], Any]:
        """Resolve plain string in Bifrost mode from zUI block or return as message."""
        zVaFile = self.zos.zspark_obj.get(KEY_ZVAFILE)
        zBlock = self.zos.zspark_obj.get(KEY_ZBLOCK, _DEFAULT_ZBLOCK)

        if zVaFile and zBlock:
            try:
                raw_zFile = self.zos.loader.handle(zVaFile)
                if raw_zFile and zBlock in raw_zFile:
                    block_dict = raw_zFile[zBlock]

                    # Look up the key in the block
                    if zHorizontal in block_dict:
                        resolved_value = block_dict[zHorizontal]
                        self.logger.framework.debug(
                            f"[{MODE_BIFROST}] Resolved key '{zHorizontal}' from zUI to: {resolved_value}"
                        )
                        # Recursively launch with the resolved value
                        return self.launch(resolved_value, context=context, walker=walker)
                    else:
                        self.logger.framework.debug(
                            f"[{MODE_BIFROST}] Key '{zHorizontal}' not found in zUI block '{zBlock}'"
                        )
            except Exception as e:
                self.logger.warning(f"[{MODE_BIFROST}] Error resolving key from zUI: {e}")

        # If we couldn't resolve it, return as display message
        self.logger.framework.debug(f"Plain string in {MODE_BIFROST} mode - returning as message")
        return {KEY_MESSAGE: zHorizontal}

    # ========================================================================
    # PRIVATE METHODS - Dict Command Routing
    # ========================================================================

    def _launch_dict(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Route dict commands: wrapper unwrap → data resolution → organizational/wizard/subsystem → CRUD."""
        # ========================================================================
        # PRELIMINARY CHECKS
        # ========================================================================
        subsystem_keys = {KEY_ZDISPLAY, KEY_ZFUNC, KEY_ZDIALOG, KEY_ZDASH, KEY_ZLINK, KEY_ZWIZARD, KEY_ZREAD, KEY_ZDATA}
        # Get ALL content keys, excluding only metadata (_zClass, _zStyle, etc.)
        # This matches the organizational_handler logic to include organizational containers like _Visual_Progression
        metadata_keys = {'_zClass', '_zStyle', '_zId', '_zScripts', 'zId'}
        content_keys = [k for k in zHorizontal.keys() if k not in metadata_keys]
        is_subsystem_call = any(k in zHorizontal for k in subsystem_keys)
        crud_keys = {'action', 'model', 'table', 'collection'}
        is_crud_call = any(k in zHorizontal for k in crud_keys)

        # ========================================================================
        # CONTENT WRAPPER UNWRAPPING
        # ========================================================================
        result = self._unwrap_content_wrapper(zHorizontal, content_keys, context, walker)
        if result is not None or (len(content_keys) == 1 and content_keys[0] == 'Content'):
            return result

        # ========================================================================
        # BLOCK-LEVEL DATA RESOLUTION
        # ========================================================================
        if context is not None:  # Only resolve if context exists
            self._resolve_data_block_if_present(zHorizontal, is_subsystem_call, context)

        # ========================================================================
        # SHORTHAND SYNTAX EXPANSION
        # ========================================================================
        zHorizontal, is_subsystem_call = self._expand_plural_shorthands(zHorizontal, is_subsystem_call)

        # Phase 5 Micro-Step 5.3: MODE-AGNOSTIC Shorthand Expansion (FIXES zCrumbs BUG!)
        # OLD: Only expanded in zCLI mode → zCrumbs never rendered in Bifrost
        # NEW: Expands for BOTH modes → zCrumbs work everywhere!
        zHorizontal, is_subsystem_call = self.shorthand_expander.expand(
            zHorizontal,
            self.zos.session,  # Pass session dict (not .data)
            is_subsystem_call
        )

        # Recalculate content_keys and subsystem check after shorthand expansion
        # Use same metadata filtering as initial check to include organizational containers
        content_keys = [k for k in zHorizontal.keys() if k not in metadata_keys]

        # Check for explicit subsystem keys at top level (zDisplay, zFunc, etc.)
        has_explicit_subsystem_keys = any(k in zHorizontal for k in subsystem_keys)
        if has_explicit_subsystem_keys:
            is_subsystem_call = True

        # ========================================================================
        # ORGANIZATIONAL STRUCTURE DETECTION (mutually exclusive with wizard)
        # ========================================================================
        # After shorthand expansion, we may have: {'zH1': {'zDisplay': {...}}, 'zText': {'zDisplay': {...}}}
        # These are organizational structures that need recursive launching, even if is_subsystem_call=True

        # SPECIAL CASE: When zWizard is mixed with other content keys, process non-wizard keys first
        # Example: {'zText': {...}, 'zWizard': {...}} should render zText then execute wizard
        has_zwizard_key = KEY_ZWIZARD in zHorizontal
        non_wizard_content_keys = [k for k in content_keys if k != KEY_ZWIZARD]

        should_check_organizational = (
            not is_crud_call and len(content_keys) > 0 and
            (not has_explicit_subsystem_keys or (has_zwizard_key and len(non_wizard_content_keys) > 0))
        )
        if should_check_organizational:
            # If zWizard is present with other keys, only process the non-wizard keys here
            keys_to_process = non_wizard_content_keys if has_zwizard_key else content_keys

            if len(keys_to_process) > 0:
                result = self._handle_organizational_structure(zHorizontal, context, walker)
                # If organizational structure was detected and processed, return immediately
                # (even if result is None) to prevent fallthrough to implicit wizard
                # UNLESS we have a zWizard to process after
                if result is not None and not has_zwizard_key:
                    return result

                # Check if organizational structure was detected (all keys are nested)
                all_nested = all(
                    isinstance(zHorizontal[k], (dict, list))
                    for k in keys_to_process
                )
                if all_nested and not has_zwizard_key:
                    # Organizational structure was processed, don't fall through to wizard
                    return result

        # ========================================================================
        # IMPLICIT WIZARD DETECTION
        # ========================================================================
        # Run after shorthand expansion so zImage/zText/etc are already converted
        if not is_subsystem_call and not is_crud_call and len(content_keys) > 1:
            return self._handle_implicit_wizard(zHorizontal, walker)

        # ========================================================================
        # EXPLICIT SUBSYSTEM ROUTING
        # ========================================================================
        if KEY_ZDISPLAY in zHorizontal:
            return self._route_zdisplay(zHorizontal, context)
        if KEY_ZFUNC in zHorizontal:
            return self._route_zfunc(zHorizontal, context)
        if KEY_ZDIALOG in zHorizontal:
            return self._route_zdialog(zHorizontal, context, walker)
        if KEY_ZDASH in zHorizontal:
            return self._route_zdash(zHorizontal, context)
        # Phase 5 Micro-Step 5.4: Delegate Auth routing to AuthHandler (Phase 1)
        if KEY_ZLOGIN in zHorizontal:
            return self.auth_handler.handle_zlogin(zHorizontal, context)
        if KEY_ZLOGOUT in zHorizontal:
            return self.auth_handler.handle_zlogout(zHorizontal)
        # Phase 5 Micro-Step 5.5: Delegate Navigation routing to NavigationHandler (Phase 2)
        if KEY_ZLINK in zHorizontal:
            return self.navigation_handler.handle_zlink(zHorizontal, walker)
        if KEY_ZDELTA in zHorizontal:
            return self.navigation_handler.handle_zdelta(zHorizontal, walker)
        if KEY_ZWIZARD in zHorizontal:
            return self._handle_wizard_dict(zHorizontal, walker, context)
        if KEY_ZREAD in zHorizontal:
            return self._handle_read_dict(zHorizontal, context)
        if KEY_ZDATA in zHorizontal:
            return self._handle_data_dict(zHorizontal, context)

        # ========================================================================
        # CRUD FALLBACK
        # ========================================================================
        # Phase 5 Micro-Step 5.6: Delegate CRUD detection to CRUDHandler (Phase 1)
        if self.crud_handler.is_crud_pattern(zHorizontal):
            return self.crud_handler.handle(zHorizontal, context)

        # No recognized keys found
        self.logger.framework.debug("[zCLI Launcher] No recognized keys found, returning None")
        return None

    # ========================================================================
    # PRIVATE METHODS - Specialized Command Handlers
    # ========================================================================


    # ========================================================================
    # DICT ROUTING HELPERS - Decomposed from _launch_dict()
    # ========================================================================

    def _unwrap_content_wrapper(
        self,
        zHorizontal: Dict[str, Any],
        content_keys: List[str],
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Unwrap 'Content' wrapper and dispatch recursively."""
        if len(content_keys) == 1 and content_keys[0] == 'Content':
            self._log_detected("Content wrapper (unwrapping)")
            content_value = zHorizontal['Content']
            return self.launch(content_value, context=context, walker=walker)
        return None

    def _resolve_data_block_if_present(
        self,
        zHorizontal: Dict[str, Any],
        is_subsystem_call: bool,
        context: Optional[Dict[str, Any]]
    ) -> None:
        """Resolve _data block queries, store results in context["_resolved_data"]."""
        if "_data" in zHorizontal and not is_subsystem_call:
            self.logger.framework.info("[zCLI Data] Detected _data block, resolving queries...")
            resolved_data = self.data_resolver.resolve_block_data(zHorizontal["_data"], context)
            if resolved_data:
                if "_resolved_data" not in context:
                    context["_resolved_data"] = {}
                context["_resolved_data"].update(resolved_data)
                self.logger.framework.info(f"[zCLI Data] Resolved {len(resolved_data)} data queries for block")
            else:
                self.logger.framework.warning("[zCLI Data] _data block present but no data resolved")


    def _handle_organizational_structure(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Union[str, Dict[str, Any]]]:
        """Delegate organizational structure handling to OrganizationalHandler."""
        return self.organizational_handler.handle(zHorizontal, context, walker, self)



    # ========================================================================
    # HELPER METHODS - DRY Refactoring
    # ========================================================================

    def _display_handler(self, label: str, indent: int) -> None:
        """Display handler label with consistent styling."""
        self.display.zDeclare(label, color=self.dispatch.mycolor, indent=indent, style=_DEFAULT_STYLE_SINGLE)

    def _log_detected(self, message: str) -> None:
        """Log detected command."""
        self.logger.framework.debug(f"Detected {message}")

    def _set_default_action(self, req: Dict[str, Any], default_action: str) -> None:
        """Set default action if not present in request."""
        if KEY_ACTION not in req:
            req[KEY_ACTION] = default_action

    def _expand_plural_shorthands(
        self,
        zHorizontal: Dict[str, Any],
        is_subsystem_call: bool
    ) -> tuple:
        """Expand plural shorthands (zURLs, zTexts, etc.) to wizard format."""
        plural_shorthands = ['zURLs', 'zTexts', 'zH1s', 'zH2s', 'zH3s', 'zH4s', 'zH5s', 'zH6s', 'zImages', 'zMDs']
        found_plural = None
        for plural_key in plural_shorthands:
            if plural_key in zHorizontal and isinstance(zHorizontal[plural_key], dict):
                found_plural = plural_key
                break

        if found_plural:
            self.logger.debug(f"[Shorthand] Found plural: {found_plural}")
            plural_items = zHorizontal[found_plural]
            expanded = {}
            event_map = {
                'zURLs': 'zURL',
                'zTexts': 'text',
                'zImages': 'image',
                'zMDs': 'rich_text'
            }
            singular = event_map.get(found_plural)

            if not singular and found_plural.startswith('zH') and found_plural.endswith('s'):
                indent = int(found_plural[2])
                if 1 <= indent <= 6:
                    singular = ('header', indent)

            if singular:
                for key, params in plural_items.items():
                    if isinstance(params, dict):
                        if isinstance(singular, tuple):
                            event_type, indent = singular
                            expanded[key] = {KEY_ZDISPLAY: {'event': event_type, 'indent': indent, **params}}
                        else:
                            expanded[key] = {KEY_ZDISPLAY: {'event': singular, **params}}

                if expanded and '_zClass' in zHorizontal:
                    for key, value in expanded.items():
                        if KEY_ZDISPLAY in value:
                            value[KEY_ZDISPLAY]['_zClass'] = zHorizontal['_zClass']

                if expanded:
                    self.logger.debug(f"[Shorthand] Expanded to {len(expanded)} steps")
                    return expanded, False

        return zHorizontal, is_subsystem_call

    # ========================================================================
    # DATA RESOLUTION HELPERS - Decomposed from _resolve_block_data()
    # ========================================================================
