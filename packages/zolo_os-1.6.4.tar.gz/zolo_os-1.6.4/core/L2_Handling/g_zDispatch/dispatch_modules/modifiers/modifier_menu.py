# zOS/core/L2_Handling/e_zDispatch/dispatch_modules/modifiers/modifier_menu.py

"""
Menu Modifier Implementation for zDispatch Subsystem.

This module provides the MenuModifier class, which implements the asterisk (*)
modifier behavior for creating navigation menus from data.

Extracted from dispatch_modifiers.py as part of Phase 4 refactoring.

Modifier Behavior:
    * (asterisk) - "Menu" modifier
    - Creates navigation menu via zNavigation.create()
    - Respects ~ (tilde) anchor modifier to disable back button
    - Applies RBAC filtering for navbar menus (~zNavBar*)
    - Tracks menu appearance in breadcrumbs (POP semantics)
    - Re-dispatches dict results (e.g., zLink navigation)

Usage Example:
    modifier = MenuModifier(dispatch, zos, logger)
    
    # Simple menu
    result = modifier.process(["*"], "menu*", menu_dict, walker)
    
    # Anchored menu (no back button)
    result = modifier.process(["~", "*"], "~menu*", menu_dict, walker)
    
    # Navbar menu (RBAC filtered)
    result = modifier.process(["~", "*"], "~zNavBar*", navbar_items, walker)

Integration:
    - zNavigation: Menu creation via zos.navigation.create()
    - zAuth: RBAC filtering for navbar menus
    - zCrumbs: Breadcrumb tracking via handle_zCrumbs()
    - CommandLauncher: Re-dispatch dict results

Thread Safety:
    - Stateless operations (no instance state mutation)
    - Safe for concurrent execution
"""

from zOS import Any, List, Optional, Union

# Import dispatch constants
from ..dispatch_constants import (
    MOD_TILDE,
    _LOG_MSG_MENU_DETECTED,
)

# Import session constants for RBAC
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import SESSION_KEY_ZCRUMBS


class MenuModifier:
    """
    Implements menu creation modifier (*) for navigation.
    
    This class handles the asterisk modifier, which creates navigation
    menus from horizontal data structures (lists or dicts).
    
    Attributes:
        dispatch: Parent zDispatch instance
        zos: zOS framework instance (provides navigation subsystem)
        logger: Logger instance for debug output
    
    Methods:
        process(): Main entry point for menu modifier processing
    
    Example:
        modifier = MenuModifier(dispatch, zos, logger)
        result = modifier.process(["*"], "menu*", menu_dict, walker)
    """

    def __init__(self, dispatch: Any, zos: Any, logger: Any) -> None:
        """
        Initialize menu modifier.
        
        Args:
            dispatch: Parent zDispatch instance
            zos: zOS framework instance (provides navigation subsystem)
            logger: Logger instance for debug output
        
        Example:
            modifier = MenuModifier(dispatch, zos, logger)
        """
        self.dispatch = dispatch
        self.zos = zos
        self.logger = logger

    # ========================================================================
    # PUBLIC API
    # ========================================================================

    def process(
        self,
        modifiers: List[str],
        zKey: str,
        zHorizontal: Any,
        walker: Optional[Any]
    ) -> Optional[Union[str, Any]]:
        """
        Process menu modifier (*) - creates menu via zNavigation.
        
        Args:
            modifiers: List of detected modifier symbols
            zKey: Original key with modifiers
            zHorizontal: Menu items (list or dict)
            walker: Optional walker instance
        
        Returns:
            Menu navigation result
        
        Notes:
            - Checks for anchor (~) modifier to disable back button
            - Tracks menu appearance in breadcrumbs (POP semantics)
            - Applies RBAC filtering for navbar menus
            - Re-dispatches dict results (e.g., zLink navigation)
        """
        is_anchor = MOD_TILDE in modifiers
        self.logger.debug(_LOG_MSG_MENU_DETECTED, zKey, is_anchor)

        # Track menu appearance in breadcrumbs
        if self.zos and hasattr(self.zos, 'navigation') and not zKey.startswith("~zNavBar"):
            self.zos.navigation.handle_zCrumbs(
                zKey,
                walker=None,
                operation='APPEND'
            )
            self.logger.debug(f"[Menu] Tracked menu appearance: {zKey}")

        # Apply RBAC filtering for navbar menus
        if zKey.startswith("~zNavBar"):
            zHorizontal = self._apply_navbarzRBAC_filtering(zKey, zHorizontal)

        # Menu loop: re-show if child navigation returns zBack
        while True:
            result = self.zos.navigation.create(
                zHorizontal,
                allow_back=not is_anchor,
                walker=walker
            )

            # User directly chose zBack from THIS menu → propagate up to parent
            if result == 'zBack':
                return result

            # Re-dispatch dict results (e.g., zLink, zDelta navigation)
            if isinstance(result, dict):
                self.logger.framework.debug(f"[Menu] Returned dict, re-dispatching: {result}")
                result = self.dispatch.launcher.launch(result, None, walker)

                # Child navigation returned zBack → pop trail entry and re-show THIS menu
                if result == 'zBack':
                    self._pop_last_crumb()
                    continue

            return result

    # ========================================================================
    # PRIVATE HELPERS
    # ========================================================================

    def _pop_last_crumb(self) -> None:
        """Pop the last entry from the active crumb trail when zBack unwinds a child menu."""
        try:
            session = self.zos.session
            crumbs = session.get('zCrumbs', {})
            trails = crumbs.get('trails') if isinstance(crumbs, dict) else None
            if trails and isinstance(trails, dict):
                active_key = crumbs.get('active_scope') or (next(reversed(trails)) if trails else None)
                trail = trails.get(active_key) if active_key else None
                if trail:
                    removed = trail.pop()
                    self.logger.framework.debug(f"[Menu] Popped crumb on zBack: '{removed}'")
        except Exception as e:
            self.logger.framework.debug(f"[Menu] _pop_last_crumb failed: {e}")

    def _apply_navbarzRBAC_filtering(
        self,
        zKey: str,
        zHorizontal: List[Any]
    ) -> List[str]:
        """
        Apply RBAC filtering to navbar menu items.
        
        Filters navbar items based on current authentication state,
        re-evaluated dynamically on every render.
        
        Args:
            zKey: Navbar key (starts with ~zNavBar)
            zHorizontal: Raw navbar items (may have $ prefixes)
        
        Returns:
            Filtered navbar items with $ prefixes restored
        
        Notes:
            - Strips $ prefixes before RBAC filtering
            - Re-adds $ prefixes after filtering (for delta navigation)
            - Sets navbar navigation flag in session for OP_RESET
        """
        self.logger.framework.debug(
            f"[Dispatch] Applying dynamic RBAC filtering for navbar: {zKey}"
        )

        # Strip existing $ prefixes from zHorizontal before filtering
        clean_items = []
        for item in zHorizontal:
            if isinstance(item, str):
                clean_items.append(item.lstrip('$'))
            else:
                clean_items.append(item)

        # Filter the navbar items based on current authentication state
        filtered_items = self.zos.navigation._filter_navbar_byzRBAC(clean_items)  # pylint: disable=protected-access
        self.logger.framework.info(
            f"[Dispatch] Navbar filtered: {len(zHorizontal)} → {len(filtered_items)} items"
        )

        # Add delta prefix ($) to filtered items for intra-file navigation
        filtered_with_prefix = []
        for item in filtered_items:
            if isinstance(item, str):
                filtered_with_prefix.append(f"${item}")
            elif isinstance(item, dict):
                item_name = list(item.keys())[0]
                item_data = item[item_name]
                filtered_with_prefix.append({f"${item_name}": item_data})
            else:
                filtered_with_prefix.append(item)

        # SET NAVBAR FLAG: Mark that next navigation is from navbar
        if SESSION_KEY_ZCRUMBS not in self.zos.session:
            self.zos.session[SESSION_KEY_ZCRUMBS] = {}
        self.zos.session[SESSION_KEY_ZCRUMBS]["_navbar_navigation"] = True
        self.logger.framework.debug(
            "[Dispatch] Navbar flag set: next navigation will trigger OP_RESET"
        )

        return filtered_with_prefix
