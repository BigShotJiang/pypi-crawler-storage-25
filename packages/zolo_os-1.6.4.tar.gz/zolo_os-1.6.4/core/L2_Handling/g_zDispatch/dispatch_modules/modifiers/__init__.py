# zOS/core/L2_Handling/e_zDispatch/dispatch_modules/modifiers/__init__.py

"""
Modifier Implementations for zDispatch Subsystem.

This package provides individual modifier logic for command behavior modification.

Modifiers:
    - MenuModifier: * (asterisk) - Create menu from data
    - BounceModifier: ^ (caret) - Execute action then return
    - AnchorModifier: ~ (tilde) - Disable back navigation
    - RequiredModifier: ! (exclamation) - Retry until success

Each modifier encapsulates specific behavior patterns for command routing.
"""

from .modifier_menu import MenuModifier
from .modifier_bounce import BounceModifier
from .modifier_required import RequiredModifier

__all__ = ['MenuModifier', 'BounceModifier', 'RequiredModifier']
