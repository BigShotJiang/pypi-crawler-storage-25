# zOS/core/L2_Handling/e_zDispatch/dispatch_modules/modifiers/modifier_bounce.py

"""
Bounce Modifier Implementation for zDispatch Subsystem.

This module provides the BounceModifier class, which implements the caret (^)
modifier behavior for "bounce-back" navigation.

Extracted from dispatch_modifiers.py as part of Phase 4 refactoring.

Modifier Behavior:
    ^ (caret) - "Bounce Back" modifier
    - Executes action and returns to previous context
    - zCLI/Walker mode: Returns "zBack" for navigation
    - Bifrost mode: Returns actual result for API consumption
    - Supports ^key resolution from zUI files

Usage Example:
    modifier = BounceModifier(dispatch, zos, logger)
    
    # Simple bounce-back
    result = modifier.process("^save", {"zFunc": "save"}, context, walker, display)
    # Terminal: Returns "zBack"
    # Bifrost: Returns save result
    
    # UI key resolution
    result = modifier.process("^submit_form", "^submit_form", context, walker, display)
    # Resolves ^submit_form from zUI file, executes, returns zBack

Integration:
    - zLoader: UI key resolution via zos.loader.handle()
    - CommandLauncher: Action execution via dispatch.launcher.launch()
    - Mode detection: is_bifrost_mode() for return behavior

Thread Safety:
    - Stateless operations (no instance state mutation)
    - Safe for concurrent execution
"""

from zOS import Any, Dict, Optional, Union

# Import dispatch constants
from ..dispatch_constants import (
    MOD_CARET,
    KEY_ZVAFILE,
    KEY_ZBLOCK,
    NAV_ZBACK,
    NAV_ZBOUNCE,
    _LABEL_ZBOUNCE,
    _LOG_MSG_ZBOUNCE_RESULT,
    _LOG_MSG_ZBOUNCE_CONTEXT,
    _LOG_MSG_ZBOUNCE_MODE_CHECK,
    _LOG_MSG_BIFROST_DETECTED,
    _LOG_MSG_LOOKING_UP_KEY,
    _LOG_MSG_RESOLVED_KEY,
    _LOG_MSG_COULD_NOT_LOAD,
    _LOG_MSG_NO_ZVAFILE,
    _LOG_MSG_CANNOT_RESOLVE,
    _DEFAULT_ZBLOCK,
    _DEFAULT_INDENT_MODIFIER,
)

# Import session constants
from zOS.L1_Foundation.a_zConfig.zConfig_modules import SESSION_KEY_ZMODE

# Import dispatch helpers
from ..dispatch_helpers import is_bifrost_mode


class BounceModifier:
    """
    Implements bounce-back modifier (^) for navigation.
    
    This class handles the caret modifier, which executes actions
    and returns to the previous context automatically.
    
    Attributes:
        dispatch: Parent zDispatch instance
        zos: zOS framework instance (provides loader, session)
        logger: Logger instance for debug output
    
    Methods:
        process(): Main entry point for bounce modifier processing
    
    Example:
        modifier = BounceModifier(dispatch, zos, logger)
        result = modifier.process("^save", {"zFunc": "save"}, context, walker, display)
    """

    def __init__(self, dispatch: Any, zos: Any, logger: Any) -> None:
        """
        Initialize bounce modifier.
        
        Args:
            dispatch: Parent zDispatch instance
            zos: zOS framework instance (provides loader, session)
            logger: Logger instance for debug output
        
        Example:
            modifier = BounceModifier(dispatch, zos, logger)
        """
        self.dispatch = dispatch
        self.zos = zos
        self.logger = logger

    # ========================================================================
    # PUBLIC API
    # ========================================================================

    def process(
        self,
        zHorizontal: Any,
        context: Optional[Dict[str, Any]],
        walker: Optional[Any],
        display: Any
    ) -> Union[str, Any]:
        """
        Process bounce modifier (^) - executes action then returns.
        
        Args:
            zHorizontal: Command to execute
            context: Optional context dict
            walker: Optional walker instance
            display: Display instance for output
        
        Returns:
            - zCLI mode: "zBack" (for navigation)
            - Bifrost mode: Action result (for API consumption)
        
        Notes:
            - Resolves ^key from UI file if needed
            - Mode-specific return behavior
            - Logs mode detection for debugging
        """
        self._display_modifier(display, _LABEL_ZBOUNCE, _DEFAULT_INDENT_MODIFIER)

        # Resolve ^key from UI file if needed
        if isinstance(zHorizontal, str) and zHorizontal.startswith(MOD_CARET):
            zHorizontal = self._resolve_ui_key(zHorizontal)

        # Execute the action
        result = self.dispatch.launcher.launch(zHorizontal, context=context, walker=walker)
        self.logger.framework.debug(_LOG_MSG_ZBOUNCE_RESULT, result)

        # Debug logging for mode detection
        self.logger.framework.debug(_LOG_MSG_ZBOUNCE_CONTEXT, context)
        self.logger.framework.debug(
            _LOG_MSG_ZBOUNCE_MODE_CHECK,
            True,
            self.zos.session.get(SESSION_KEY_ZMODE)
        )

        # Mode-specific return behavior
        if is_bifrost_mode(self.zos.session):
            self.logger.framework.debug(_LOG_MSG_BIFROST_DETECTED)
            return result

        # zBounce keeps execution inside the SequentialExecutor loop.
        # The executor detects zBounce and jumps back to the nearest preceding menu key.
        # NAV_ZBACK would exit the executor and escalate to the walker's on_back() callback.
        return NAV_ZBOUNCE

    # ========================================================================
    # PRIVATE HELPERS
    # ========================================================================

    def _display_modifier(self, display: Any, label: str, indent: int, style: str = "single") -> None:
        """Display modifier label if display system is available."""
        if display:
            display.zDeclare(label, color="DISPATCH", indent=indent, style=style)

    def _resolve_ui_key(self, zKey: str) -> Any:
        """
        Resolve ^key from zUI file.
        
        Args:
            zKey: Key starting with ^ to resolve
        
        Returns:
            Resolved value from zUI file, or original key if resolution fails
        """
        self.logger.framework.debug(_LOG_MSG_LOOKING_UP_KEY, zKey)

        zVaFile = self.zos.zspark_obj.get(KEY_ZVAFILE)
        zBlock = self.zos.zspark_obj.get(KEY_ZBLOCK, _DEFAULT_ZBLOCK)

        if not zVaFile:
            self.logger.warning(_LOG_MSG_NO_ZVAFILE, zKey)
            return zKey

        try:
            raw_zFile = self.zos.loader.handle(zVaFile)
            if raw_zFile and zBlock in raw_zFile:
                block_dict = raw_zFile[zBlock]
                clean_key = zKey.lstrip(MOD_CARET)
                if clean_key in block_dict:
                    resolved_value = block_dict[clean_key]
                    self.logger.framework.debug(_LOG_MSG_RESOLVED_KEY, zKey, resolved_value)
                    return resolved_value
        except Exception as e:
            self.logger.warning(_LOG_MSG_COULD_NOT_LOAD, zVaFile, e)

        self.logger.framework.debug(_LOG_MSG_CANNOT_RESOLVE, zKey)
        return zKey
