# zOS/core/L2_Handling/e_zDispatch/dispatch_modules/modifiers/modifier_required.py

"""
Required Modifier Implementation for zDispatch Subsystem.

This module provides the RequiredModifier class, which implements the exclamation (!)
modifier behavior for mandatory action execution with retry logic.

Extracted from dispatch_modifiers.py as part of Phase 4 refactoring.

Modifier Behavior:
    ! (exclamation) - "Required" modifier
    - Enters retry loop until action returns truthy result
    - User can abort with "stop", "n", or "no" input
    - Bifrost mode: Frontend handles retry UI
    - zCLI mode: Backend retry loop with prompts
    - Handles Ctrl+C and shutdown signals gracefully

Usage Example:
    modifier = RequiredModifier(dispatch, zos, logger)
    
    # Required action (validates until success)
    result = modifier.process("validate!", {"zFunc": "validate"}, context, walker, display)
    # Retries until validate() returns True
    
    # User can abort
    # Terminal: Prompt "Try again? (y/n)" - user types "n"
    # Returns: None

Integration:
    - CommandLauncher: Action execution via dispatch.launcher.launch()
    - zDisplay: User prompts via display.read_string()
    - Mode detection: is_bifrost_mode() for retry handling

Thread Safety:
    - Stateless operations (no instance state mutation)
    - Safe for concurrent execution
"""

from zOS import Any, Dict, Optional

# Import dispatch constants
from ..dispatch_constants import (
    MOD_EXCLAMATION,
    _LABEL_ZREQUIRED,
    _LABEL_ZREQUIRED_RETURN,
    _LOG_MSG_REQUIRED_STEP,
    _LOG_MSG_REQUIRED_RESULTS,
    _LOG_MSG_REQUIREMENT_NOT_SATISFIED,
    _LOG_MSG_REQUIREMENT_SATISFIED,
    _PROMPT_REQUIRED_CONTINUE,
    _INPUT_STOP,
    _DEFAULT_INDENT_MODIFIER,
    _STYLE_WAVY,
)

# Import dispatch helpers
from ..dispatch_helpers import is_bifrost_mode


class RequiredModifier:
    """
    Implements required action modifier (!) with retry logic.
    
    This class handles the exclamation modifier, which enforces
    successful action execution through a retry loop.
    
    Attributes:
        dispatch: Parent zDispatch instance
        zos: zOS framework instance (provides session)
        logger: Logger instance for debug output
    
    Methods:
        process(): Main entry point for required modifier processing
    
    Example:
        modifier = RequiredModifier(dispatch, zos, logger)
        result = modifier.process("validate!", {"zFunc": "validate"}, context, walker, display)
    """

    def __init__(self, dispatch: Any, zos: Any, logger: Any) -> None:
        """
        Initialize required modifier.
        
        Args:
            dispatch: Parent zDispatch instance
            zos: zOS framework instance (provides session)
            logger: Logger instance for debug output
        
        Example:
            modifier = RequiredModifier(dispatch, zos, logger)
        """
        self.dispatch = dispatch
        self.zos = zos
        self.logger = logger

    # ========================================================================
    # PUBLIC API
    # ========================================================================

    def process(
        self,
        zKey: str,
        zHorizontal: Any,
        context: Optional[Dict[str, Any]],
        walker: Optional[Any],
        display: Any
    ) -> Optional[Any]:
        """
        Process required modifier (!) - retry loop until success.
        
        Args:
            zKey: Original key with modifiers
            zHorizontal: Command to execute
            context: Optional context dict
            walker: Optional walker instance
            display: Display instance for prompts
        
        Returns:
            Action result after successful execution, or None if aborted
        
        Notes:
            - Bifrost mode: Frontend handles retry UI
            - zCLI mode: Backend retry loop with prompts
            - User can abort with "stop", "n", or "no"
            - Handles Ctrl+C and shutdown signals gracefully
        """
        self._display_modifier(display, _LABEL_ZREQUIRED, _DEFAULT_INDENT_MODIFIER)
        self.logger.framework.debug(_LOG_MSG_REQUIRED_STEP, zKey)

        # Execute action
        result = self.dispatch.launcher.launch(zHorizontal, context=context, walker=walker)
        self.logger.framework.debug(_LOG_MSG_REQUIRED_RESULTS, result)

        # Mode-aware retry handling
        is_bifrost = is_bifrost_mode(self.zos.session)

        if is_bifrost:
            if not result:
                self.logger.info(
                    f"[{MOD_EXCLAMATION}] Bifrost mode - gate failed, frontend will handle retry"
                )
            else:
                self.logger.info(f"[{MOD_EXCLAMATION}] Bifrost mode - gate passed")
            return result

        # zCLI mode: Backend retry loop
        while not result:
            if getattr(self.zos, '_shutdown_requested', False):
                self.logger.info(
                    f"[{MOD_EXCLAMATION}] Shutdown requested, aborting retry loop for: {zKey}"
                )
                return None

            self.logger.warning(_LOG_MSG_REQUIREMENT_NOT_SATISFIED, zKey)
            if walker:
                try:
                    choice = display.read_string(_PROMPT_REQUIRED_CONTINUE).strip().lower()
                except (KeyboardInterrupt, EOFError):
                    self.logger.info(
                        f"[{MOD_EXCLAMATION}] Interrupted during retry prompt for: {zKey}"
                    )
                    return None

                if choice in [_INPUT_STOP, 'n', 'no']:
                    self.logger.framework.debug(
                        f"[{MOD_EXCLAMATION}] User declined retry for: {zKey}"
                    )
                    return None
            result = self.dispatch.launcher.launch(zHorizontal, context=context, walker=walker)

        self.logger.framework.debug(_LOG_MSG_REQUIREMENT_SATISFIED, zKey)
        self._display_modifier(
            display,
            _LABEL_ZREQUIRED_RETURN,
            _DEFAULT_INDENT_MODIFIER,
            style=_STYLE_WAVY
        )
        return result

    # ========================================================================
    # PRIVATE HELPERS
    # ========================================================================

    def _display_modifier(self, display: Any, label: str, indent: int, style: str = "single") -> None:
        """Display modifier label if display system is available."""
        if display:
            display.zDeclare(label, color="DISPATCH", indent=indent, style=style)
