# zOS/core/L2_Core/e_zDispatch/dispatch_modules/handlers/handler_routing.py

"""
Command Routing Handlers
=========================

Extracted from dispatch_launcher.py to reduce file size.
Provides routing logic for zDisplay, zFunc, and zDialog commands.
"""

from zOS import Any, Optional, Dict


class RoutingHandlers:
    """Mixin providing routing methods for CommandLauncher.
    
    Required Attributes (provided by CommandLauncher):
        - zos: zOS instance
        - display: Display instance
        - logger: Logger instance
        - dispatch: Dispatch instance
    """

    zos: Any
    display: Any
    logger: Any
    dispatch: Any

    def _log_detected(self, _message: str) -> None:
        """Log detected command (provided by parent)."""
        pass

    def _display_handler(self, _label: str, _indent: int) -> None:
        """Display handler label (provided by parent)."""
        pass

    def _route_zdisplay(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Any:
        """Route zDisplay command (legacy format).
        
        Args:
            zHorizontal: Dict containing zDisplay key
            context: Optional context dict
        
        Returns:
            Result from display event
        """
        from ..dispatch_constants import KEY_ZDISPLAY

        self._log_detected("zDisplay (wrapped)")
        display_data = zHorizontal[KEY_ZDISPLAY]

        keys_repr = list(display_data.keys()) if isinstance(display_data, dict) else 'not a dict'
        self.logger.framework.debug(f"[_route_zdisplay] display_data keys: {keys_repr}")
        self.logger.framework.debug(f"[_route_zdisplay] display_data: {display_data}")

        if isinstance(display_data, dict):
            if context and "_resolved_data" in context:
                display_data["_context"] = context

            result = self.display.handle(display_data)
            return result
        else:
            self.logger.framework.warning(f"[_route_zdisplay] display_data is not a dict! Type: {type(display_data)}")

        return None

    def _route_zfunc(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Route zFunc command (function execution or plugin invocation).
        
        Args:
            zHorizontal: Dict containing zFunc key
            context: Optional context dict
        
        Returns:
            Function/plugin execution result
        """
        from ..dispatch_constants import (
            KEY_ZFUNC, _LABEL_HANDLE_ZFUNC_DICT, _DEFAULT_INDENT_HANDLER, PLUGIN_PREFIX
        )

        self._log_detected("zFunc (dict)")
        self._display_handler(_LABEL_HANDLE_ZFUNC_DICT, _DEFAULT_INDENT_HANDLER)
        func_spec = zHorizontal[KEY_ZFUNC]

        context_keys = context.keys() if context else 'None'
        self.logger.debug(f"[_route_zfunc] context type: {type(context)}, keys: {context_keys}")
        if context and "zHat" in context:
            self.logger.debug(f"[_route_zfunc] zHat found in context: {context['zHat']}")

        if isinstance(func_spec, str) and func_spec.startswith(PLUGIN_PREFIX):
            self._log_detected(f"plugin invocation in zFunc: {func_spec}")
            return self.zos.zparser.resolve_plugin_invocation(func_spec, context=context)

        return self.zos.zfunc.handle(func_spec, zContext=context)

    def _route_zdialog(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]],
        walker: Optional[Any]
    ) -> Optional[Any]:
        """Route zDialog command (interactive form).
        
        Args:
            zHorizontal: Dict containing zDialog key
            context: Optional context dict
            walker: Optional walker instance
        
        Returns:
            Dialog execution result
        """
        from ....j_zDialog import handle_zDialog

        self._log_detected("zDialog")
        return handle_zDialog(zHorizontal, zcli=self.zos, walker=walker, context=context)

    def _route_zdash(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Route zDash command (interactive dashboard with sidebar navigation).
        
        Args:
            zHorizontal: Dict containing zDash key with folder, sidebar, default params
            context: Optional context dict
        
        Returns:
            Dashboard execution result
        """
        from ..dispatch_constants import KEY_ZDASH

        self._log_detected("zDash")
        dash_params = zHorizontal[KEY_ZDASH]

        if not isinstance(dash_params, dict):
            self.logger.framework.warning(f"[_route_zdash] zDash value must be a dict, got: {type(dash_params)}")
            return None

        display_data = {"event": "zDash", **dash_params}

        if context and "_resolved_data" in context:
            display_data["_context"] = context

        return self.display.handle(display_data)
