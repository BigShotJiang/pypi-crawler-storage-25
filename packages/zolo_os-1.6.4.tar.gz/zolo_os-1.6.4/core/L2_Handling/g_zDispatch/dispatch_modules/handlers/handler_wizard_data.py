# zOS/core/L2_Core/e_zDispatch/dispatch_modules/handlers/handler_wizard_data.py

"""
Wizard & Data Command Handlers
===============================

Extracted from dispatch_launcher.py to reduce file size.
Provides handlers for zWizard, zRead, and zData commands.
"""

from zOS import Any, Optional, Dict, Union, ast


class WizardDataHandlers:
    """Mixin providing wizard and data command handlers for CommandLauncher.
    
    Required Attributes (provided by CommandLauncher):
        - zos: zOS instance
        - logger: Logger instance
        - dispatch: Dispatch instance
    """

    zos: Any
    logger: Any
    dispatch: Any

    def _log_detected(self, _message: str) -> None:
        """Log detected command (provided by parent)."""
        pass

    def _display_handler(self, _label: str, _indent: int) -> None:
        """Display handler label (provided by parent)."""
        pass

    def _set_default_action(self, _req: Dict[str, Any], _default_action: str) -> None:
        """Set default action for data requests (provided by parent)."""
        pass

    def _handle_wizard_string(
        self,
        zHorizontal: str,
        walker: Optional[Any]
    ) -> Optional[Union[str, Any]]:
        """Handle zWizard string command.
        
        Args:
            zHorizontal: String in format "zWizard(...)"
            walker: Optional walker instance
        
        Returns:
            - Bifrost: Wizard result (zHat)
            - zCLI: "zBack" for navigation (or zHat if no walker)
        """
        from ..dispatch_constants import (
            CMD_PREFIX_ZWIZARD, _LABEL_HANDLE_ZWIZARD, _DEFAULT_INDENT_LAUNCHER,
            NAV_ZBACK
        )
        from ..dispatch_helpers import is_bifrost_mode

        self._log_detected("zWizard request")
        self._display_handler(_LABEL_HANDLE_ZWIZARD, _DEFAULT_INDENT_LAUNCHER)

        inner = zHorizontal[len(CMD_PREFIX_ZWIZARD):-1].strip()
        try:
            wizard_obj = ast.literal_eval(inner)

            if walker:
                zHat = walker.handle(wizard_obj)
            else:
                zHat = self.zos.wizard.handle(wizard_obj)

            if is_bifrost_mode(self.zos.session):
                return zHat

            return NAV_ZBACK if walker else zHat
        except Exception as e:
            self.logger.error(f"Failed to parse zWizard payload: {e}")
            return None

    def _handle_wizard_dict(
        self,
        zHorizontal: Dict[str, Any],
        walker: Optional[Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[Union[str, Any]]:
        """Handle zWizard dict command.
        
        Args:
            zHorizontal: Dict with "zWizard" key
            walker: Optional walker instance
            context: Optional context dict
        
        Returns:
            - Bifrost: Wizard result (zHat)
            - zCLI: "zBack" for navigation (or zHat if no walker)
        """
        from ..dispatch_constants import KEY_ZWIZARD, NAV_ZBACK
        from ..dispatch_helpers import is_bifrost_mode

        self._log_detected("zWizard (dict)")

        self.logger.debug("=" * 80)
        self.logger.debug("[_handle_wizard_dict] ENTRY POINT")
        self.logger.debug(f"  Walker: {walker is not None}")
        self.logger.debug(f"  zWizard keys: {list(zHorizontal[KEY_ZWIZARD].keys())}")
        self.logger.debug("=" * 80)

        if walker:
            self.logger.debug("[_handle_wizard_dict] Calling walker.handle()")
            zHat = walker.handle(zHorizontal[KEY_ZWIZARD])
            self.logger.debug(f"[_handle_wizard_dict] walker.handle() returned: {type(zHat)}")
        else:
            self.logger.debug("[_handle_wizard_dict] Calling zos.wizard.handle()")
            zHat = self.zos.wizard.handle(zHorizontal[KEY_ZWIZARD])
            self.logger.debug(f"[_handle_wizard_dict] zos.wizard.handle() returned: {type(zHat)}")

        if is_bifrost_mode(self.zos.session):
            return zHat

        is_nested = context and context.get('_is_nested_in_org_container', False)

        if is_nested:
            return zHat
        else:
            return NAV_ZBACK if walker else zHat

    def _handle_read_string(
        self,
        zHorizontal: str,
        context: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Handle zRead string command.
        
        Args:
            zHorizontal: String in format "zRead(...)"
            context: Optional context dict
        
        Returns:
            Data result from zData.handle_request()
        """
        from ..dispatch_constants import (
            CMD_PREFIX_ZREAD, _LABEL_HANDLE_ZREAD_STRING, _DEFAULT_INDENT_LAUNCHER,
            KEY_ACTION, _DEFAULT_ACTION_READ, KEY_MODEL
        )

        self._log_detected("zRead request (string)")
        self._display_handler(_LABEL_HANDLE_ZREAD_STRING, _DEFAULT_INDENT_LAUNCHER)

        inner = zHorizontal[len(CMD_PREFIX_ZREAD):-1].strip()
        req = {KEY_ACTION: _DEFAULT_ACTION_READ}
        if inner:
            req[KEY_MODEL] = inner

        self.logger.framework.debug(f"Dispatching zRead (string) with request: {req}")
        return self.zos.data.handle_request(req, context=context)

    def _handle_read_dict(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Handle zRead dict command.
        
        Args:
            zHorizontal: Dict with "zRead" key
            context: Optional context dict
        
        Returns:
            Data result from zData.handle_request()
        """
        from ..dispatch_constants import (
            KEY_ZREAD, _LABEL_HANDLE_ZREAD_DICT, _DEFAULT_INDENT_LAUNCHER,
            KEY_MODEL, _DEFAULT_ACTION_READ
        )

        self._log_detected("zRead (dict)")
        self._display_handler(_LABEL_HANDLE_ZREAD_DICT, _DEFAULT_INDENT_LAUNCHER)

        req = zHorizontal.get(KEY_ZREAD) or {}
        if isinstance(req, str):
            req = {KEY_MODEL: req}

        self._set_default_action(req, _DEFAULT_ACTION_READ)

        self.logger.framework.debug(f"Dispatching zRead (dict) with request: {req}")
        return self.zos.data.handle_request(req, context=context)

    def _handle_data_dict(
        self,
        zHorizontal: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Handle zData dict command.
        
        Args:
            zHorizontal: Dict with "zData" key
            context: Optional context dict
        
        Returns:
            Data result from zData.handle_request()
        """
        from ..dispatch_constants import (
            KEY_ZDATA, _LABEL_HANDLE_ZDATA_DICT, _DEFAULT_INDENT_LAUNCHER,
            KEY_MODEL, _DEFAULT_ACTION_READ
        )

        self._log_detected("zData (dict)")
        self._display_handler(_LABEL_HANDLE_ZDATA_DICT, _DEFAULT_INDENT_LAUNCHER)

        req = zHorizontal.get(KEY_ZDATA) or {}
        if isinstance(req, str):
            req = {KEY_MODEL: req}

        self._set_default_action(req, _DEFAULT_ACTION_READ)

        self.logger.framework.debug(f"Dispatching zData (dict) with request: {req}")
        return self.zos.data.handle_request(req, context=context)

    def _handle_implicit_wizard(
        self,
        zHorizontal: Dict[str, Any],
        walker: Optional[Any]
    ) -> Dict[str, Any]:
        """Handle implicit wizard (dict with multiple content keys).
        
        Args:
            zHorizontal: Dict command
            walker: Optional walker instance
        
        Returns:
            Wizard execution result (zHat)
        """
        self._log_detected("Implicit zWizard (multi-step)")

        if walker:
            zHat = walker.handle(zHorizontal)
        else:
            zHat = self.zos.wizard.handle(zHorizontal)

        return zHat
