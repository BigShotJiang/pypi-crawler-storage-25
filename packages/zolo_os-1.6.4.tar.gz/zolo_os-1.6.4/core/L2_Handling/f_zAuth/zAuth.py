# zOS/core/L2_Core/d_zAuth/zAuth.py
"""
zAuth - Three-Tier Authentication Facade (v1.5.4+)

Facade Pattern orchestrating 4 modules: PasswordSecurity, SessionPersistence,
Authentication, RBAC. Provides unified API for bcrypt passwords, SQLite sessions,
three-tier auth (zSession/Application/Dual), and context-aware RBAC.

THREE-TIER MODEL
  Tier 1 (zSession): Internal zOS/Zolo users -> login/logout/is_authenticated/
                     get_credentials/status
  Tier 2 (Application): External app users -> authenticate_app_user/switch_app/
                        get_app_user (multi-app simultaneous auth supported)
  Tier 3 (Dual): Both contexts active -> set_active_context/get_active_user
                 (RBAC uses OR logic)

DELEGATION (16 methods via zAuthDelegates mixins)
  Password: hash_password, verify_password -> password_security
  Session: login, logout, status, is_authenticated, get_credentials -> authentication
  App: authenticate_app_user, switch_app, get_app_user -> authentication
  Context: set_active_context, get_active_user -> authentication
  RBAC: has_role, has_permission, grant_permission, revoke_permission -> rbac

MODULE RESPONSIBILITIES
  PasswordSecurity: bcrypt (12 rounds), timing-safe verification, 72-byte truncation
  SessionPersistence: SQLite sessions.db, 7-day expiry, declarative zData ops
  Authentication: Three-tier logic, multi-app, remote auth (zComm), zDisplay UI
  RBAC: Context-aware roles/permissions, dual-mode OR logic, SQLite persistence

INTEGRATION: zConfig (constants), zDisplay (UI), zComm (remote), zData (storage),
             zWizard (RBAC)

EXAMPLES
  # Basic: zos.auth.login("user@zolo.com", "pass"); zos.auth.has_role("admin")
  # Multi-app: zos.auth.authenticate_app_user("store", token, config)
  # Dual: zos.auth.set_active_context("dual")  # RBAC checks both contexts

THREAD SAFETY: NOT thread-safe. Each thread needs own zOS instance.
               Multi-app auth within single session is fully supported.
"""

from zOS import Any, Optional, Dict
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import SESSION_KEY_ZAUTH

from .zAuth_modules import PasswordSecurity, SessionPersistence, Authentication, RBAC
from .zAuth_modules.auth_delegates import zAuthDelegates
from .zAuth_modules.auth_constants import (
    KEY_ROLE,
    DEFAULT_ROLE, DEFAULT_SESSION_DURATION_DAYS as SESSION_DURATION_DAYS,
)

# Module-specific constants
COLOR_ZAUTH: str = "ZAUTH"
MSG_READY: str = "zAuth Ready"


class zAuth(zAuthDelegates):
    """
    Authentication Facade - Three-Tier Auth System (v1.5.4+)
    
    Orchestrates 4 modules (PasswordSecurity, SessionPersistence, Authentication, RBAC)
    via Facade Pattern. Inherits 16 public methods from zAuthDelegates mixins.
    
    Modules: password_security, session_persistence, authentication, rbac
    Methods: See zAuthDelegates (api/delegate_*.py) - Password(2), Session(5), 
             Application(3), Context(2), RBAC(4)
    Integration: zConfig (constants), zDisplay (UI), zComm (remote), zData (storage)
    Thread Safety: NOT thread-safe (use separate zOS per thread)
    
    BREAKING (v1.5.4): bcrypt only, no plaintext passwords
    """

    # Class-level type declarations
    zos: Any
    session: Dict[str, Any]
    logger: Any
    mycolor: str
    password_security: PasswordSecurity
    session_persistence: SessionPersistence
    authentication: Authentication
    rbac: RBAC

    def __init__(self, zos: Any) -> None:
        """Initialize auth modules (password_security, session_persistence, 
        authentication, rbac). DB init deferred (lazy load)."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger
        self.mycolor = COLOR_ZAUTH  # Orange-brown bg (Authentication)

        # Initialize modular components (all require zos instance)
        self.password_security = PasswordSecurity(logger=self.logger)
        self.session_persistence = SessionPersistence(zos, session_duration_days=SESSION_DURATION_DAYS)
        self.authentication = Authentication(zos)
        self.rbac = RBAC(zos)

        # Display ready message via zDisplay facade
        self.zos.display.zDeclare(MSG_READY, color=self.mycolor, indent=0, style="full")

        # Note: Database initialization is deferred until after zParser/zLoader are ready
        # Will be called automatically on first use (lazy initialization)


    # ════════════════════════════════════════════════════════════════════════════
    # PUBLIC API METHODS (Delegated to zAuthDelegates mixins)
    # ════════════════════════════════════════════════════════════════════════════

    # All public API methods (16 total) are now provided by zAuthDelegates
    # mixins via multiple inheritance. See zAuth_modules/auth_delegates.py for
    # the complete implementation and individual delegate modules in zAuth_modules/api/.
    #
    # From DelegatePassword (2 methods):
    #   - hash_password(plain_password) -> str
    #   - verify_password(plain_password, hashed_password) -> bool
    #
    # From DelegateSession (5 methods):
    #   - login(username, password, server_url, persist) -> Dict
    #   - logout(context, app_name, delete_persistent) -> Dict
    #   - status() -> Dict
    #   - is_authenticated() -> bool
    #   - get_credentials() -> Optional[Dict]
    #
    # From DelegateApplication (3 methods):
    #   - authenticate_app_user(app_name, token, config) -> Dict
    #   - switch_app(app_name) -> bool
    #   - get_app_user(app_name) -> Optional[Dict]
    #
    # From DelegateContext (2 methods):
    #   - set_active_context(context) -> bool
    #   - get_active_user() -> Optional[Dict]
    #
    # From DelegateRBAC (4 methods):
    #   - has_role(required_role) -> bool
    #   - has_permission(required_permission) -> bool
    #   - grant_permission(user_id, permission, granted_by) -> bool
    #   - revoke_permission(user_id, permission) -> bool

    # ════════════════════════════════════════════════════════════════════════════
    # DEPRECATED METHODS (Backwards Compatibility)
    # ════════════════════════════════════════════════════════════════════════════

    def _ensure_sessions_db(self) -> None:
        """DEPRECATED v1.5.4 - v1.6.0: Use session_persistence.ensure_sessions_db()"""
        return self.session_persistence.ensure_sessions_db()

    def _load_session(self) -> Optional[Dict[str, Any]]:
        """DEPRECATED v1.5.4 - v1.6.0: Use session_persistence.load_session(identifier, type)"""
        return self.session_persistence.load_session()

    def _save_session(self, username: str, password_hash: str, user_id: Optional[str] = None) -> bool:
        """DEPRECATED v1.5.4 - v1.6.0: Use session_persistence.save_session(username, hash, id, role)"""
        role = self.session.get(SESSION_KEY_ZAUTH, {}).get(KEY_ROLE, DEFAULT_ROLE)
        return self.session_persistence.save_session(username, password_hash, user_id, role)

    def _cleanup_expired(self) -> int:
        """DEPRECATED v1.5.4 - v1.6.0: Use session_persistence.cleanup_expired()"""
        return self.session_persistence.cleanup_expired()

    def _authenticate_remote(self, username: str, password: str, server_url: Optional[str] = None) -> Dict[str, Any]:
        """DEPRECATED v1.5.4 - v1.6.0: Use authentication.authenticate_remote(username, password, server_url)"""
        return self.authentication.authenticate_remote(username, password, server_url)

    def _ensure_permissions_db(self) -> None:
        """DEPRECATED v1.5.4 - v1.6.0: Use rbac.ensure_permissions_db()"""
        return self.rbac.ensure_permissions_db()
