# zOS/core/L2_Handling/d_zAuth/zAuth_modules/api/delegate_session.py

"""
Session Authentication Delegate for zAuth Facade.

This module provides zSession (Layer 1) authentication delegate methods,
following zDisplay's delegate pattern for clean facade composition.

Methods:
    - login: Authenticate zOS/Zolo user
    - logout: Clear session authentication
    - status: Show authentication status
    - is_authenticated: Check if authenticated
    - get_credentials: Get current user credentials

Pattern:
    All methods delegate to self.authentication module instance.
"""

from zOS import Any, Optional, Dict

# Import constants for method implementation
from ..auth_constants import (
    CONTEXT_ZSESSION,
    KEY_STATUS,
    KEY_PERSIST,
    KEY_CREDENTIALS,
    KEY_PASSWORD,
    KEY_USERNAME,
    FIELD_USER_ID,
    KEY_ROLE,
    KEY_DELETE_PERSISTENT,
    STATUS_SUCCESS,
    DEFAULT_ROLE,
    TABLE_SESSIONS,
    DB_LABEL_AUTH as DATA_LABEL_AUTH,
)


class DelegateSession:  # pylint: disable=no-member
    """Mixin providing zSession authentication delegate methods.
    
    These methods provide the primary Layer 1 (zSession) authentication API,
    delegating to the Authentication module for core logic and SessionPersistence
    for persistent storage.
    
    Note:
        This is a mixin class. The authentication, session_persistence, logger,
        and zos attributes are provided by the subclass (zAuth). Pylint warnings
        about missing members are expected and suppressed.
    """

    # Layer 1: zSession Authentication Delegates

    def login(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        server_url: Optional[str] = None,
        persist: bool = True
    ) -> Dict[str, Any]:
        """
        Authenticate user (zSession) and optionally persist session.
        
        Delegates to: authentication.login() + session_persistence.save_session()
        
        This method handles Layer 1 (zSession) authentication for internal zOS/Zolo
        users. Supports both local (prompt) and remote (server_url) authentication.
        
        Args:
            username: Username for authentication (prompts if None)
            password: Password for authentication (prompts if None)
            server_url: Optional remote Zolo server URL for authentication
            persist: If True, save session to sessions.db (default: True)
        
        Returns:
            Dict: {"status": "success"|"fail"|"pending", "user": {...}}
                - status="success": Authentication successful
                - status="fail": Invalid credentials
                - status="pending": Remote auth initiated (async)
        
        Integration:
            - Uses zDisplay generic events for prompts and feedback
            - Uses zComm for remote authentication (comm_http.py)
            - Uses session_persistence.save_session() if persist=True
            - Updates session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ZSESSION]
        
        Context Awareness:
            After successful login, active_context is set to:
            - "zSession" if no app authenticated
            - "dual" if app already authenticated
        
        Example:
            # Basic login (prompts for credentials)
            result = zos.auth.login()
            
            # Login with credentials
            result = zos.auth.login("user@zolo.com", "password", persist=True)
            
            # Remote authentication
            result = zos.auth.login("user", "pass", server_url="https://zolo.com")
        """
        result = self.authentication.login(username, password, server_url, persist)

        # Handle session persistence if login was successful
        if result.get(KEY_STATUS) == STATUS_SUCCESS and result.get(KEY_PERSIST):
            credentials = result.get(KEY_CREDENTIALS)
            password_for_hash = result.get(KEY_PASSWORD)

            if credentials and password_for_hash:
                password_hash = self.hash_password(password_for_hash)
                self.session_persistence.save_session(
                    username=credentials.get(KEY_USERNAME),
                    password_hash=password_hash,
                    user_id=credentials.get(FIELD_USER_ID),
                    role=credentials.get(KEY_ROLE, DEFAULT_ROLE)
                )

        # Clean up sensitive data before returning
        if KEY_PASSWORD in result:
            del result[KEY_PASSWORD]
        if KEY_PERSIST in result:
            del result[KEY_PERSIST]

        return result

    def logout(
        self,
        context: str = CONTEXT_ZSESSION,
        app_name: Optional[str] = None,
        delete_persistent: bool = True
    ) -> Dict[str, str]:
        """
        Clear session authentication and optionally delete persistent session.
        
        Delegates to: authentication.logout() + session_persistence cleanup
        
        Supports context-aware logout for all three authentication tiers:
        - "zSession": Logout from zSession only
        - "application": Logout from specific app (requires app_name)
        - "all_apps": Logout from all authenticated apps
        - "all": Logout from everything (zSession + all apps)
        
        Args:
            context: Authentication context to logout from (default: "zSession")
                    - "zSession": Logout zOS/Zolo user
                    - "application": Logout specific app user (requires app_name)
                    - "all_apps": Logout from all apps
                    - "all": Logout from zSession and all apps
            app_name: App name for "application" context logout (optional)
            delete_persistent: If True, delete SQLite session entry (default: True)
        
        Returns:
            Dict: {"status": "success", "cleared": ["zSession", "app1", ...]}
        
        Integration:
            - Uses zDisplay generic events for logout feedback
            - Uses zData to delete persistent session (if delete_persistent=True)
            - Clears session[SESSION_KEY_ZAUTH] based on context
        
        Context Behavior:
            After logout, active_context is updated:
            - "zSession" logout: context → "application" (if app exists) or None
            - "application" logout: context → "zSession" (if exists) or None
            - "all" logout: context → None
        
        Examples:
            # Logout from zSession only
            zos.auth.logout()
            
            # Logout from specific app
            zos.auth.logout(context="application", app_name="my_store")
            
            # Logout from all apps but keep zSession
            zos.auth.logout(context="all_apps")
            
            # Logout from everything
            zos.auth.logout(context="all", delete_persistent=True)
        """
        result = self.authentication.logout(
            context=context,
            app_name=app_name,
            delete_persistent=delete_persistent
        )

        # Delete persistent session from SQLite if requested
        if result.get(KEY_DELETE_PERSISTENT) and result.get(KEY_USERNAME):
            try:
                if self.zos.data.handler and self.zos.data.schema.get("zMeta", {}).get("Data_Label") == DATA_LABEL_AUTH:
                    self.zos.data.delete(
                        table=TABLE_SESSIONS,
                        where=f"{KEY_USERNAME} = '{result.get(KEY_USERNAME)}'"
                    )
                    self.logger.info(f"[zAuth] Persistent session deleted for user: {result.get(KEY_USERNAME)}")
            except Exception as e:
                self.logger.error(f"[zAuth] Error deleting persistent session: {e}")

        return {KEY_STATUS: STATUS_SUCCESS}

    def status(self) -> Dict[str, Any]:
        """
        Show current authentication status for all tiers.
        
        Delegates to: authentication.status()
        
        Returns comprehensive authentication status including:
        - zSession authentication (username, role)
        - Application authentications (all apps)
        - Active context (zSession, application, dual)
        - Dual mode status
        
        Returns:
            Dict: {
                "status": "authenticated"|"not_authenticated",
                "user": {...},  # Current user based on active_context
                "zsession": {...},  # zSession auth data
                "applications": {...},  # All app auth data
                "active_context": "zSession"|"application"|"dual",
                "dual_mode": bool
            }
        
        Integration:
            - Uses zDisplay generic events for status display
            - Reads from session[SESSION_KEY_ZAUTH]
        
        Example:
            status = zos.auth.status()
            print(f"Authenticated: {status['status']}")
            print(f"Current user: {status['user']}")
            print(f"Active context: {status['active_context']}")
        """
        return self.authentication.status()

    def is_authenticated(self) -> bool:
        """
        Check if user is currently authenticated in ANY context.
        
        Delegates to: authentication.is_authenticated()
        
        Returns True if:
        - zSession is authenticated, OR
        - At least one application is authenticated
        
        Returns:
            bool: True if authenticated in any context, False otherwise
        
        Context Awareness:
            This checks for ANY authentication. For context-specific checks,
            use get_credentials() or get_app_user(app_name).
        
        Example:
            if zos.auth.is_authenticated():
                print("User is logged in")
            else:
                print("No authentication")
        """
        return self.authentication.is_authenticated()

    def get_credentials(self) -> Optional[Dict[str, Any]]:
        """
        Get zSession credentials for the currently authenticated user.
        
        Delegates to: authentication.get_credentials()
        
        Returns zSession (Layer 1) credentials only. For application credentials,
        use get_app_user(app_name).
        
        Returns:
            Optional[Dict]: {
                "username": str,
                "user_id": str,
                "role": str
            } if authenticated, None otherwise
        
        Integration:
            - Reads from session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ZSESSION]
            - Returns None if not authenticated
        
        Example:
            creds = zos.auth.get_credentials()
            if creds:
                print(f"Logged in as: {creds['username']}")
                print(f"Role: {creds['role']}")
        """
        return self.authentication.get_credentials()
