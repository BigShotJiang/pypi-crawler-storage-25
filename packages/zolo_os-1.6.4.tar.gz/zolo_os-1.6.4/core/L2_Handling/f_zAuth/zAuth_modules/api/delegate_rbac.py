# zOS/core/L2_Handling/d_zAuth/zAuth_modules/api/delegate_rbac.py

"""
RBAC Delegate for zAuth Facade.

This module provides Role-Based Access Control delegate methods,
following zDisplay's delegate pattern for clean facade composition.

Methods:
    - has_role: Check if user has required role
    - has_permission: Check if user has required permission
    - grant_permission: Grant permission to user
    - revoke_permission: Revoke permission from user

Pattern:
    All methods delegate to self.rbac module instance.
"""

from zOS import Optional, Union, List


class DelegateRBAC:  # pylint: disable=no-member
    """Mixin providing RBAC delegate methods.
    
    These methods provide context-aware role and permission checks,
    delegating to the RBAC module for access control logic.
    
    Note:
        This is a mixin class. The rbac attribute is provided by
        the subclass (zAuth). Pylint warnings about missing members are expected
        and suppressed.
    """

    # RBAC Delegates

    def has_role(self, required_role: Union[str, List[str], None]) -> bool:
        """
        Check if the current user has the required role (context-aware).
        
        Delegates to: rbac.has_role()
        
        Checks roles based on active_context:
        - "zSession": Checks zSession user's role
        - "application": Checks active app user's role
        - "dual": Checks BOTH with OR logic (either context can grant)
        
        Args:
            required_role: Role name (str), list of roles (list), or None
                         - str: User must have this exact role
                         - list: User must have ANY of these roles (OR logic)
                         - None: Public access (always returns True)
        
        Returns:
            bool: True if user has the required role(s), False otherwise
        
        Integration:
            - Used by zWizard for zVaF menu access control
            - Reads role from session[SESSION_KEY_ZAUTH] based on active_context
        
        Dual-Mode Behavior:
            In dual mode, returns True if user has role in EITHER context:
            - zSession user has "admin" OR
            - Active app user has "admin"
        
        Examples:
            # Single role check
            if zos.auth.has_role("admin"):
                print("User is admin")
            
            # Multiple roles (OR logic)
            if zos.auth.has_role(["admin", "moderator"]):
                print("User is admin OR moderator")
            
            # Public access
            if zos.auth.has_role(None):
                print("Always True - public access")
        """
        return self.rbac.has_role(required_role)

    def has_permission(self, required_permission: Union[str, List[str]]) -> bool:
        """
        Check if the current user has the required permission (context-aware).
        
        Delegates to: rbac.has_permission()
        
        Checks permissions based on active_context:
        - "zSession": Checks zSession user's permissions
        - "application": Checks active app user's permissions
        - "dual": Checks BOTH with OR logic (either context can grant)
        
        Permissions are stored in SQLite (permissions table) and checked via
        declarative zData operations.
        
        Args:
            required_permission: Permission name (str) or list of permissions (list)
                               - str: User must have this exact permission
                               - list: User must have ANY of these permissions (OR logic)
        
        Returns:
            bool: True if user has the required permission(s), False otherwise
        
        Integration:
            - Permissions stored in SQLite via zData
            - Used by zWizard for granular access control
        
        Dual-Mode Behavior:
            In dual mode, returns True if user has permission in EITHER context:
            - zSession user has "data.delete" OR
            - Active app user has "data.delete"
        
        Examples:
            # Single permission
            if zos.auth.has_permission("users.delete"):
                # Delete user operation
            
            # Multiple permissions (OR logic)
            if zos.auth.has_permission(["data.read", "data.write"]):
                # User can read OR write
        """
        return self.rbac.has_permission(required_permission)

    def grant_permission(
        self,
        user_id: str,
        permission: str,
        granted_by: Optional[str] = None
    ) -> bool:
        """
        Grant a permission to a user (admin-only operation).
        
        Delegates to: rbac.grant_permission()
        
        Stores permission in SQLite (permissions table) via declarative zData
        operations. Permissions are persistent across sessions.
        
        Args:
            user_id: User ID to grant permission to
            permission: Permission name (e.g., "users.delete", "system.shutdown")
            granted_by: Optional admin username who granted this permission
        
        Returns:
            bool: True if permission was granted successfully, False otherwise
        
        Integration:
            - Uses zData.insert() for persistence
            - Requires auth.db SQLite database (permissions table)
        
        Example:
            # Grant permission
            success = zos.auth.grant_permission(
                user_id="user123",
                permission="users.delete",
                granted_by="admin@zolo.com"
            )
            
            if success:
                print("Permission granted")
        """
        return self.rbac.grant_permission(user_id, permission, granted_by)

    def revoke_permission(self, user_id: str, permission: str) -> bool:
        """
        Revoke a permission from a user (admin-only operation).
        
        Delegates to: rbac.revoke_permission()
        
        Removes permission from SQLite (permissions table) via declarative zData
        operations.
        
        Args:
            user_id: User ID to revoke permission from
            permission: Permission name to revoke
        
        Returns:
            bool: True if permission was revoked successfully, False otherwise
        
        Integration:
            - Uses zData.delete() for persistence
            - Requires auth.db SQLite database (permissions table)
        
        Example:
            # Revoke permission
            success = zos.auth.revoke_permission(
                user_id="user123",
                permission="users.delete"
            )
            
            if success:
                print("Permission revoked")
        """
        return self.rbac.revoke_permission(user_id, permission)
