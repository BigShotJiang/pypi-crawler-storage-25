"""
Credential Manager - Handles credential queries

Extracted from monolithic Authentication class for better separation of concerns.
"""

from zOS import Dict, Optional, Any
from zOS.L1_Foundation.a_zConfig.zConfig_modules import (
    SESSION_KEY_ZAUTH,
    ZAUTH_KEY_APPLICATIONS,
    ZAUTH_KEY_AUTHENTICATED,
    ZAUTH_KEY_ID,
    ZAUTH_KEY_USERNAME,
    ZAUTH_KEY_ROLE,
    ZAUTH_KEY_API_KEY,
)

from ...auth_constants import (
    KEY_STATUS,
    _MSG_NOT_AUTHENTICATED,
)

from ...auth_helpers import get_zsession_data, get_applications_data

class CredentialManager:
    """Manages credential queries and authentication status."""

    def __init__(self, zos: Any) -> None:
        """Initialize with zOS instance."""
        self.zos = zos
        self.session = zos.session

    def _check_session(self) -> bool:
        """Validate that session exists."""
        return self.session is not None

    def _create_status_response(self, status: str, **kwargs: Any) -> Dict[str, Any]:
        """Create standardized status response dictionary."""
        response = {KEY_STATUS: status}
        response.update(kwargs)
        return response

    def is_authenticated(self) -> bool:
        """Check if user is currently authenticated in ANY context."""
        if not self._check_session():
            return False

        zsession = get_zsession_data(self.session)
        if zsession.get(ZAUTH_KEY_AUTHENTICATED, False) and zsession.get(ZAUTH_KEY_USERNAME) is not None:
            return True

        applications = get_applications_data(self.session)
        for _app_name, app_session in applications.items():
            if app_session.get(ZAUTH_KEY_AUTHENTICATED, False) and app_session.get(ZAUTH_KEY_ID) is not None:
                return True

        return False

    def get_credentials(self) -> Optional[Dict[str, Any]]:
        """Get current zSession authentication data."""
        if self.is_authenticated():
            return get_zsession_data(self.session)
        return None

    def get_app_user(self, app_name: str) -> Optional[Dict[str, Any]]:
        """Get authentication info for a specific application."""
        if not self._check_session():
            return None

        apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})
        return apps.get(app_name)

    def status(self) -> Dict[str, Any]:
        """Show current zSession authentication status."""
        if self.is_authenticated():
            auth_data = get_zsession_data(self.session)
            self.zos.display.header("[*] Authentication Status")
            self.zos.display.text(f"Username:   {auth_data.get(ZAUTH_KEY_USERNAME)}", indent=1, pause=False)
            self.zos.display.text(f"Role:       {auth_data.get(ZAUTH_KEY_ROLE)}", indent=1, pause=False)
            self.zos.display.text(f"User ID:    {auth_data.get(ZAUTH_KEY_ID)}", indent=1, pause=False)
            if api_key := auth_data.get(ZAUTH_KEY_API_KEY):
                truncated_key = api_key[:20] + "..." if len(api_key) > 20 else api_key
                self.zos.display.text(f"API Key:    {truncated_key}", indent=1, pause=False)
            return self._create_status_response("authenticated", user=auth_data)
        else:
            self.zos.display.warning("[WARN] Not authenticated. Run 'auth login' to authenticate.")
            return self._create_status_response(_MSG_NOT_AUTHENTICATED)
