"""
Database Manager - Handles permissions database initialization

Extracted from monolithic RBAC class for better separation of concerns.
"""

from zOS import Path, Any
from ...auth_constants import (
    DB_LABEL_AUTH,
    TABLE_PERMISSIONS,
    TABLE_SESSIONS,
    SCHEMAS_DIR,
    SCHEMA_META_KEY,
    SCHEMA_LABEL_KEY,
    SCHEMA_FILE_NAME,
    _LOG_PREFIX_RBAC,
    _LOG_DB_INIT,
    _LOG_TABLE_CREATED,
    _LOG_SESSIONS_TABLE_CREATED,
    _LOG_SCHEMA_NOT_FOUND,
    _LOG_SCHEMA_PARSE_FAILED,
    _LOG_HANDLER_FAILED,
    _LOG_WRONG_SCHEMA,
    _LOG_DB_ERROR,
)

LOG_PREFIX = _LOG_PREFIX_RBAC


class DatabaseManager:
    """Manages permissions database initialization."""

    def __init__(self, zos: Any, context_helpers: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.logger = zos.logger
        self.context_helpers = context_helpers
        self._permissions_db_initialized = False

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        full_message = f"{LOG_PREFIX} {message}"

        if level == "info":
            self.logger.info(full_message)
        elif level == "warning":
            self.logger.warning(full_message)
        elif level == "error":
            self.logger.error(full_message)

    def ensure_permissions_db(self) -> None:
        """Ensure the permissions database is initialized."""
        if self._permissions_db_initialized:
            return

        try:
            if self.context_helpers._is_db_ready():  # pylint: disable=protected-access
                if not self.zos.data.table_exists(TABLE_PERMISSIONS):
                    self.zos.data.create_table(TABLE_PERMISSIONS)
                    self._log("info", _LOG_TABLE_CREATED)
                self._permissions_db_initialized = True
                return

            zos_root = Path(__file__).parent.parent.parent.parent.parent
            schema_path = zos_root / SCHEMAS_DIR / SCHEMA_FILE_NAME

            if not schema_path.exists():
                self._log("warning", f"{_LOG_SCHEMA_NOT_FOUND}: {schema_path}")
                return

            schema_content = schema_path.read_text(encoding="utf-8")
            parsed_schema = self.zos.zparser.parse_file_content(schema_content, ".yaml")

            if not parsed_schema:
                self._log("warning", _LOG_SCHEMA_PARSE_FAILED)
                return

            self.zos.data.load_schema(parsed_schema)

            if not self.zos.data.handler:
                self._log("error", _LOG_HANDLER_FAILED)
                return

            loaded_label = self.zos.data.schema.get(SCHEMA_META_KEY, {}).get(SCHEMA_LABEL_KEY)
            if loaded_label != DB_LABEL_AUTH:
                self._log("error", f"{_LOG_WRONG_SCHEMA}: {loaded_label} (expected: {DB_LABEL_AUTH})")
                return

            if not self.zos.data.table_exists(TABLE_SESSIONS):
                self.zos.data.create_table(TABLE_SESSIONS)
                self._log("info", _LOG_SESSIONS_TABLE_CREATED)

            if not self.zos.data.table_exists(TABLE_PERMISSIONS):
                self.zos.data.create_table(TABLE_PERMISSIONS)
                self._log("info", _LOG_TABLE_CREATED)

            self._log("info", _LOG_DB_INIT)
            self._permissions_db_initialized = True

        except Exception as e:
            self._log("error", f"{_LOG_DB_ERROR}: {e}")
            import traceback
            self.logger.debug(traceback.format_exc())
