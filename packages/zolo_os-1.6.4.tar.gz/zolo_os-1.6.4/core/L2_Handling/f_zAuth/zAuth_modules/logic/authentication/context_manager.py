"""
Context Manager - Handles authentication context switching

Extracted from monolithic Authentication class for better separation of concerns.
"""

from zOS import Dict, Optional, Any
from zOS.L1_Foundation.a_zConfig.zConfig_modules import (
    SESSION_KEY_ZAUTH,
    ZAUTH_KEY_APPLICATIONS,
    ZAUTH_KEY_ACTIVE_APP,
    ZAUTH_KEY_ACTIVE_CONTEXT,
    ZAUTH_KEY_DUAL_MODE,
    ZAUTH_KEY_AUTHENTICATED,
    CONTEXT_ZSESSION,
    CONTEXT_APPLICATION,
    CONTEXT_DUAL,
)

from ...auth_constants import (
    _LOG_PREFIX_AUTH,
    _LOG_LEVEL_INFO,
    _LOG_LEVEL_WARNING,
    _LOG_APP_SWITCH,
    _LOG_APP_SWITCH_FAIL,
    _LOG_CONTEXT_SET,
    _LOG_CONTEXT_INVALID,
    _LOG_CONTEXT_NO_ZSESSION,
    _LOG_CONTEXT_NO_APP,
    _LOG_CONTEXT_NO_DUAL,
    _LOG_DUAL_MODE_ACTIVATED,
)

from ...auth_helpers import (
    get_zsession_data,
    get_applications_data,
)

LOG_PREFIX = _LOG_PREFIX_AUTH


class ContextManager:
    """Manages authentication context switching and state."""

    def __init__(self, zos: Any) -> None:
        """Initialize with zOS instance."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        if level == _LOG_LEVEL_INFO:
            self.logger.info(message)
        elif level == _LOG_LEVEL_WARNING:
            self.logger.warning(message)

    def _check_session(self) -> bool:
        """Validate that session exists."""
        return self.session is not None

    def _update_active_context(self) -> None:
        """Update active_context based on current authentication state."""
        if not self._check_session():
            return

        zsession_auth = get_zsession_data(self.session).get(ZAUTH_KEY_AUTHENTICATED, False)
        active_app = self.session.get(SESSION_KEY_ZAUTH, {}).get(ZAUTH_KEY_ACTIVE_APP)
        apps = get_applications_data(self.session)
        app_auth = active_app and active_app in apps

        if zsession_auth and app_auth:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_DUAL
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = True
            self._log(_LOG_LEVEL_INFO, _LOG_DUAL_MODE_ACTIVATED)
        elif zsession_auth:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_ZSESSION
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False
        elif app_auth:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_APPLICATION
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False
        else:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = None
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False

    def set_active_context(self, context: str) -> bool:
        """Set the active authentication context."""
        if not self._check_session():
            return False

        valid_contexts = [CONTEXT_ZSESSION, CONTEXT_APPLICATION, CONTEXT_DUAL]
        if context not in valid_contexts:
            self._log(_LOG_LEVEL_WARNING, f"{_LOG_CONTEXT_INVALID}: {context}")
            return False

        if context == CONTEXT_ZSESSION:
            if not get_zsession_data(self.session).get(ZAUTH_KEY_AUTHENTICATED):
                self._log(_LOG_LEVEL_WARNING, _LOG_CONTEXT_NO_ZSESSION)
                return False

        elif context == CONTEXT_APPLICATION:
            active_app = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_APP)
            if not active_app:
                self._log(_LOG_LEVEL_WARNING, _LOG_CONTEXT_NO_APP)
                return False
            apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})
            if active_app not in apps:
                self._log(_LOG_LEVEL_WARNING, f"{_LOG_CONTEXT_NO_APP}: {active_app} not authenticated")
                return False

        elif context == CONTEXT_DUAL:
            zsession_auth = get_zsession_data(self.session).get(ZAUTH_KEY_AUTHENTICATED)
            active_app = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_APP)
            apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})

            if not zsession_auth or not active_app or active_app not in apps:
                self._log(_LOG_LEVEL_WARNING, _LOG_CONTEXT_NO_DUAL)
                return False

        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = context
        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = context == CONTEXT_DUAL

        self._log(_LOG_LEVEL_INFO, f"{_LOG_CONTEXT_SET}: {context}")
        return True

    def get_active_user(self) -> Optional[Dict[str, Any]]:
        """Get user data for the current active authentication context."""
        if not self._check_session():
            return None

        active_context = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_CONTEXT)

        if not active_context:
            return None

        if active_context == CONTEXT_ZSESSION:
            return get_zsession_data(self.session)

        elif active_context == CONTEXT_APPLICATION:
            active_app = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_APP)
            if active_app:
                return get_applications_data(self.session).get(active_app)
            return None

        elif active_context == CONTEXT_DUAL:
            active_app = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_APP)
            return {
                "zSession": get_zsession_data(self.session),
                "application": get_applications_data(self.session).get(active_app) if active_app else None
            }

        return None

    def switch_app(self, app_name: str) -> bool:
        """Switch focus to a different authenticated application."""
        if not self._check_session():
            return False

        apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})
        if app_name not in apps:
            self._log(_LOG_LEVEL_WARNING, f"{_LOG_APP_SWITCH_FAIL}: {app_name}")
            return False

        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_APP] = app_name

        self._log(_LOG_LEVEL_INFO, f"{_LOG_APP_SWITCH}: {app_name}")
        return True
