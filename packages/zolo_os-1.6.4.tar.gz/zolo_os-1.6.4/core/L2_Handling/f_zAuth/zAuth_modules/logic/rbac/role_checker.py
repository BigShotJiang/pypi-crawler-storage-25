"""
Role Checker - Handles role checking with hierarchy support

Extracted from monolithic RBAC class for better separation of concerns.
"""

from zOS import Optional, Any, Union, Tuple, List
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import (
    CONTEXT_ZSESSION,
    CONTEXT_APPLICATION,
    CONTEXT_DUAL,
)

from ...auth_constants import (
    _LOG_PREFIX_RBAC,
    _LOG_NOT_AUTHENTICATED,
    _LOG_NO_ROLE,
    _LOG_INVALID_ROLE_TYPE,
    _LOG_CONTEXT_ZSESSION,
    _LOG_CONTEXT_APPLICATION,
    _LOG_CONTEXT_DUAL,
    _LOG_DUAL_ROLE_MATCH,
)

LOG_PREFIX = _LOG_PREFIX_RBAC


class RoleChecker:
    """Handles role checking with optional hierarchy support."""

    def __init__(self, zos: Any, context_helpers: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.logger = zos.logger
        self.context_helpers = context_helpers
        self._role_level_cache = {}

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        full_message = f"{LOG_PREFIX} {message}"

        if level == "debug":
            self.logger.debug(full_message)
        elif level == "warning":
            self.logger.warning(full_message)

    def has_role(self, required_role: Optional[Union[str, List[str]]]) -> bool:
        """Check if the current user has the required role (context-aware)."""
        if required_role is None:
            return True

        if not self.context_helpers._is_authenticated():  # pylint: disable=protected-access
            self._log("debug", _LOG_NOT_AUTHENTICATED)
            return False

        user_role = self.context_helpers._get_current_role()  # pylint: disable=protected-access

        if not user_role:
            self._log("debug", _LOG_NO_ROLE)
            return False

        active_context = self.context_helpers._get_active_context()  # pylint: disable=protected-access
        if active_context == CONTEXT_ZSESSION:
            self._log("debug", _LOG_CONTEXT_ZSESSION)
        elif active_context == CONTEXT_APPLICATION:
            self._log("debug", _LOG_CONTEXT_APPLICATION)
        elif active_context == CONTEXT_DUAL:
            self._log("debug", _LOG_CONTEXT_DUAL)

        if self._check_role_match(user_role, required_role):
            return True

        if not isinstance(required_role, (str, list)):
            self._log("warning", f"{_LOG_INVALID_ROLE_TYPE}: {type(required_role)}")

        return False

    def _check_role_match(
        self,
        user_role: Optional[Union[str, Tuple[Optional[str], Optional[str]]]],
        required_role: Union[str, List[str]]
    ) -> bool:
        """Check if user's role(s) match the required role(s), with dual-mode OR logic."""
        if not user_role:
            return False

        if isinstance(user_role, tuple):
            zsession_role, app_role = user_role

            if isinstance(required_role, list):
                zsession_match = any(
                    self._check_role_hierarchy(zsession_role, req) for req in required_role
                ) if zsession_role else False
                app_match = any(
                    self._check_role_hierarchy(app_role, req) for req in required_role
                ) if app_role else False
                return zsession_match or app_match

            if isinstance(required_role, str):
                zsession_match = self._check_role_hierarchy(zsession_role, required_role) if zsession_role else False
                app_match = self._check_role_hierarchy(app_role, required_role) if app_role else False
                if zsession_match or app_match:
                    self._log("debug", f"{_LOG_DUAL_ROLE_MATCH}: {required_role}")
                return zsession_match or app_match

            return False

        if isinstance(required_role, str):
            return self._check_role_hierarchy(user_role, required_role)

        if isinstance(required_role, list):
            return any(self._check_role_hierarchy(user_role, req) for req in required_role)

        return False

    def _check_role_hierarchy(self, user_role_name: str, required_role_name: str) -> bool:
        """Check if user's role matches required role with optional hierarchical checking."""
        try:
            user_level = self._get_role_level(user_role_name)
            required_level = self._get_role_level(required_role_name)

            if user_level is not None and required_level is not None:
                result = user_level >= required_level
                if result:
                    self._log(
                        "debug",
                        f"[RBAC Hierarchy] User '{user_role_name}' (level {user_level}) "
                        f"qualifies for '{required_role_name}' (level {required_level})"
                    )
                return result

            self._log(
                "debug",
                f"[RBAC] No hierarchy for '{user_role_name}' or '{required_role_name}', "
                f"using exact match"
            )

        except Exception as e:
            self._log(
                "warning",
                f"[RBAC] Role hierarchy check failed: {e}, falling back to exact match"
            )

        return user_role_name == required_role_name

    def _get_role_level(self, role_name: str) -> Optional[int]:
        """Get the hierarchical level of a role from the roles table."""
        if role_name in self._role_level_cache:
            return self._role_level_cache[role_name]

        try:
            roles_schema = self.zos.loader.handle('@.models.zSchema.roles')
            self.zos.data.load_schema(roles_schema)

            role_data = self.zos.data.adapter.select(
                "roles",
                where={"name": role_name}
            )

            if role_data and len(role_data) > 0:
                level = role_data[0].get('level')
                self._role_level_cache[role_name] = level

                if level is not None:
                    self._log(
                        "debug",
                        f"[RBAC] Cached level for role '{role_name}': {level}"
                    )

                return level

        except Exception as e:
            self._log(
                "debug",
                f"[RBAC] Could not query level for role '{role_name}': {e}"
            )

        self._role_level_cache[role_name] = None
        return None
