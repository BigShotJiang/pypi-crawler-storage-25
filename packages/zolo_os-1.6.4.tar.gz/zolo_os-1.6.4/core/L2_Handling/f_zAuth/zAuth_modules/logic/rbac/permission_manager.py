"""
Permission Manager - Handles permission grant/revoke operations

Extracted from monolithic RBAC class for better separation of concerns.
"""

from zOS import datetime, Optional, Any
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import (
    ZAUTH_KEY_ZSESSION,
    ZAUTH_KEY_APPLICATIONS,
    ZAUTH_KEY_ACTIVE_APP,
    ZAUTH_KEY_USERNAME,
    CONTEXT_DUAL,
    CONTEXT_ZSESSION,
    CONTEXT_APPLICATION,
)

from ...auth_constants import (
    TABLE_PERMISSIONS,
    FIELD_USER_ID,
    FIELD_PERMISSION,
    FIELD_GRANTED_BY,
    FIELD_GRANTED_AT,
    QUERY_LIMIT_ONE,
    DEFAULT_GRANTED_BY,
    _LOG_PREFIX_RBAC,
    _LOG_PERMISSION_GRANTED,
    _LOG_PERMISSION_ALREADY_GRANTED,
    _LOG_PERMISSION_REVOKED,
    _LOG_GRANT_ERROR,
    _LOG_REVOKE_ERROR,
    _QUERY_LEN_ZERO,
)

from ...auth_helpers import get_auth_data

LOG_PREFIX = _LOG_PREFIX_RBAC


class PermissionManager:
    """Manages permission grant and revoke operations."""

    def __init__(self, zos: Any, context_helpers: Any, database_manager: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger
        self.context_helpers = context_helpers
        self.database_manager = database_manager

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        full_message = f"{LOG_PREFIX} {message}"

        if level == "info":
            self.logger.info(full_message)
        elif level == "error":
            self.logger.error(full_message)

    def grant_permission(
        self,
        user_id: str,
        permission: str,
        granted_by: Optional[str] = None
    ) -> bool:
        """Grant a permission to a user (admin-only operation)."""
        try:
            self.database_manager.ensure_permissions_db()

            existing = self.zos.data.select(
                table=TABLE_PERMISSIONS,
                where=f"{FIELD_USER_ID} = '{user_id}' AND {FIELD_PERMISSION} = '{permission}'",
                limit=QUERY_LIMIT_ONE
            )

            if existing and len(existing) > _QUERY_LEN_ZERO:
                self._log("info", f"{_LOG_PERMISSION_ALREADY_GRANTED} '{user_id}': {permission}")
                return True

            if not granted_by:
                granted_by = self._get_current_admin_username()

            self.zos.data.insert(
                table=TABLE_PERMISSIONS,
                fields=[FIELD_USER_ID, FIELD_PERMISSION, FIELD_GRANTED_BY, FIELD_GRANTED_AT],
                values=[user_id, permission, granted_by, datetime.now().isoformat()]
            )

            self._log("info", f"{_LOG_PERMISSION_GRANTED} '{permission}' to user '{user_id}' by '{granted_by}'")
            return True

        except Exception as e:
            self._log("error", f"{_LOG_GRANT_ERROR}: {e}")
            return False

    def _get_current_admin_username(self) -> str:
        """Get current admin's username from active context."""
        auth_data = get_auth_data(self.session)
        active_context = self.context_helpers._get_active_context()  # pylint: disable=protected-access

        if active_context == CONTEXT_DUAL:
            return auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_USERNAME, DEFAULT_GRANTED_BY)
        elif active_context == CONTEXT_ZSESSION:
            return auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_USERNAME, DEFAULT_GRANTED_BY)
        elif active_context == CONTEXT_APPLICATION:
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            if active_app:
                app_session = auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {})
                return app_session.get(ZAUTH_KEY_USERNAME, DEFAULT_GRANTED_BY)
            else:
                return DEFAULT_GRANTED_BY
        else:
            return DEFAULT_GRANTED_BY

    def revoke_permission(self, user_id: str, permission: str) -> bool:
        """Revoke a permission from a user (admin-only operation)."""
        try:
            self.database_manager.ensure_permissions_db()

            self.zos.data.delete(
                table=TABLE_PERMISSIONS,
                where=f"{FIELD_USER_ID} = '{user_id}' AND {FIELD_PERMISSION} = '{permission}'"
            )

            self._log("info", f"{_LOG_PERMISSION_REVOKED} '{permission}' from user '{user_id}'")
            return True

        except Exception as e:
            self._log("error", f"{_LOG_REVOKE_ERROR}: {e}")
            return False
