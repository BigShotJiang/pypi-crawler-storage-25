"""
Permission Checker - Handles permission checking

Extracted from monolithic RBAC class for better separation of concerns.
"""

from zOS import Union, List, Optional, Any, Tuple
from ...auth_constants import (
    TABLE_PERMISSIONS,
    FIELD_USER_ID,
    FIELD_PERMISSION,
    QUERY_LIMIT_ONE,
    _LOG_PREFIX_RBAC,
    _LOG_NO_USER_ID,
    _LOG_PERMISSION_CHECK_FAILED,
    _LOG_INVALID_PERMISSION_TYPE,
    _LOG_PERMISSION_ERROR,
    _QUERY_LEN_ZERO,
)

LOG_PREFIX = _LOG_PREFIX_RBAC


class PermissionChecker:
    """Handles permission checking across authentication contexts."""

    def __init__(self, zos: Any, context_helpers: Any, database_manager: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.logger = zos.logger
        self.context_helpers = context_helpers
        self.database_manager = database_manager

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        full_message = f"{LOG_PREFIX} {message}"

        if level == "debug":
            self.logger.debug(full_message)
        elif level == "warning":
            self.logger.warning(full_message)
        elif level == "error":
            self.logger.error(full_message)

    def has_permission(self, required_permission: Union[str, List[str]]) -> bool:
        """Check if the current user has the required permission (context-aware)."""
        if not self._validate_permission_check():
            return False

        user_id = self.context_helpers._get_current_user_id()  # pylint: disable=protected-access
        if not user_id:
            self._log("debug", _LOG_NO_USER_ID)
            return False

        try:
            self.database_manager.ensure_permissions_db()

            if isinstance(user_id, tuple):
                return self._check_permission_dual_context(user_id, required_permission)

            return self._check_permission_single_context(user_id, required_permission)

        except Exception as e:
            self._log("error", f"{_LOG_PERMISSION_ERROR}: {e}")
            return False

    def _validate_permission_check(self) -> bool:
        """Validate user is authenticated before permission check."""
        if not self.context_helpers._is_authenticated():  # pylint: disable=protected-access
            self._log("debug", _LOG_PERMISSION_CHECK_FAILED)
            return False
        return True

    def _check_permission_dual_context(
        self,
        user_ids: Tuple[Optional[str], Optional[str]],
        required_permission: Union[str, List[str]]
    ) -> bool:
        """Check permissions for dual context (OR logic across two user IDs)."""
        zsession_id, app_id = user_ids

        if isinstance(required_permission, str):
            return self._check_single_permission_dual(zsession_id, app_id, required_permission)

        if isinstance(required_permission, list):
            return self._check_multiple_permissions_dual(zsession_id, app_id, required_permission)

        self._log("warning", f"{_LOG_INVALID_PERMISSION_TYPE}: {type(required_permission)}")
        return False

    def _check_single_permission_dual(
        self,
        zsession_id: Optional[str],
        app_id: Optional[str],
        permission: str
    ) -> bool:
        """Check single permission across both user IDs in dual context."""
        if zsession_id and self._user_has_permission(zsession_id, permission):
            return True

        if app_id and self._user_has_permission(app_id, permission):
            return True

        return False

    def _check_multiple_permissions_dual(
        self,
        zsession_id: Optional[str],
        app_id: Optional[str],
        permissions: List[str]
    ) -> bool:
        """Check multiple permissions across both user IDs in dual context (OR logic)."""
        for perm in permissions:
            if zsession_id and self._user_has_permission(zsession_id, perm):
                return True

            if app_id and self._user_has_permission(app_id, perm):
                return True

        return False

    def _check_permission_single_context(
        self,
        user_id: str,
        required_permission: Union[str, List[str]]
    ) -> bool:
        """Check permissions for single context."""
        if isinstance(required_permission, str):
            return self._user_has_permission(user_id, required_permission)

        if isinstance(required_permission, list):
            for perm in required_permission:
                if self._user_has_permission(user_id, perm):
                    return True
            return False

        self._log("warning", f"{_LOG_INVALID_PERMISSION_TYPE}: {type(required_permission)}")
        return False

    def _user_has_permission(self, user_id: str, permission: str) -> bool:
        """Query database to check if user has specific permission."""
        results = self.zos.data.select(
            table=TABLE_PERMISSIONS,
            where=f"{FIELD_USER_ID} = '{user_id}' AND {FIELD_PERMISSION} = '{permission}'",
            limit=QUERY_LIMIT_ONE
        )
        return results and len(results) > _QUERY_LEN_ZERO
