"""
App Authentication Manager - Handles application user authentication

Extracted from monolithic Authentication class for better separation of concerns.
"""

from zOS import Dict, Optional, Any
from zOS.L1_Foundation.a_zConfig.zConfig_modules import (
    SESSION_KEY_ZAUTH,
    ZAUTH_KEY_ACTIVE_APP,
    ZAUTH_KEY_AUTHENTICATED,
    ZAUTH_KEY_ID,
    ZAUTH_KEY_USERNAME,
    ZAUTH_KEY_ROLE,
    ZAUTH_KEY_API_KEY,
)

from ...auth_constants import (
    STATUS_SUCCESS,
    STATUS_ERROR,
    KEY_STATUS,
    DEFAULT_USER_MODEL,
    DEFAULT_ID_FIELD,
    DEFAULT_USERNAME_FIELD,
    DEFAULT_ROLE_FIELD,
    DEFAULT_API_KEY_FIELD,
    PLACEHOLDER_USER_ID,
    PLACEHOLDER_ROLE,
    _LOG_PREFIX_AUTH,
    _LOG_LEVEL_INFO,
    _LOG_LEVEL_ERROR,
    _LOG_APP_AUTH_SUCCESS,
    _LOG_APP_AUTH_ERROR,
    _ERR_NO_SESSION,
)

from ...auth_helpers import get_applications_data, get_active_context

LOG_PREFIX = _LOG_PREFIX_AUTH


class AppAuthenticationManager:
    """Manages application user authentication."""

    def __init__(self, zos: Any, context_manager: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger
        self.context_manager = context_manager

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        if level == _LOG_LEVEL_INFO:
            self.logger.info(message)
        elif level == _LOG_LEVEL_ERROR:
            self.logger.error(message)

    def _check_session(self) -> bool:
        """Validate that session exists."""
        return self.session is not None

    def _create_status_response(self, status: str, **kwargs: Any) -> Dict[str, Any]:
        """Create standardized status response dictionary."""
        response = {KEY_STATUS: status}
        response.update(kwargs)
        return response

    def authenticate_app_user(
        self,
        app_name: str,
        token: str,
        config: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Authenticate user to a specific application (Layer 2 auth)."""
        if not self._check_session():
            return self._create_status_response(STATUS_ERROR, reason=_ERR_NO_SESSION)

        auth_config = self._configure_app_auth(config)

        try:
            user_data = self._authenticate_app_user_data(app_name, token, auth_config)
            self._store_app_authentication(app_name, user_data)
            self._log_app_auth_success(app_name, user_data)

            return self._create_status_response(
                STATUS_SUCCESS,
                app_name=app_name,
                user=user_data,
                context=get_active_context(self.session)
            )

        except Exception as e:
            self._log(_LOG_LEVEL_ERROR, f"{_LOG_APP_AUTH_ERROR} for {app_name}: {e}")
            return self._create_status_response(
                STATUS_ERROR,
                app_name=app_name,
                reason=str(e)
            )

    def _configure_app_auth(self, config: Optional[Dict[str, str]]) -> Dict[str, str]:
        """Configure authentication settings with defaults."""
        default_config = {
            "user_model": DEFAULT_USER_MODEL,
            DEFAULT_ID_FIELD: DEFAULT_ID_FIELD,
            DEFAULT_USERNAME_FIELD: DEFAULT_USERNAME_FIELD,
            DEFAULT_ROLE_FIELD: DEFAULT_ROLE_FIELD,
            DEFAULT_API_KEY_FIELD: DEFAULT_API_KEY_FIELD
        }
        return {**default_config, **(config or {})}

    def _authenticate_app_user_data(
        self,
        app_name: str,
        token: str,
        _auth_config: Dict[str, str]
    ) -> Dict[str, Any]:
        """Authenticate app user and return user data (currently placeholder)."""
        return {
            ZAUTH_KEY_AUTHENTICATED: True,
            ZAUTH_KEY_ID: PLACEHOLDER_USER_ID,
            ZAUTH_KEY_USERNAME: f"user_from_{app_name}",
            ZAUTH_KEY_ROLE: PLACEHOLDER_ROLE,
            ZAUTH_KEY_API_KEY: token
        }

    def _store_app_authentication(self, app_name: str, user_data: Dict[str, Any]) -> None:
        """Store app authentication in session and update context."""
        get_applications_data(self.session)[app_name] = user_data
        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_APP] = app_name
        self.context_manager._update_active_context()  # pylint: disable=protected-access

    def _log_app_auth_success(self, app_name: str, user_data: Dict[str, Any]) -> None:
        """Log successful application authentication."""
        self._log(
            _LOG_LEVEL_INFO,
            f"{_LOG_APP_AUTH_SUCCESS}: {app_name} "
            f"(username={user_data[ZAUTH_KEY_USERNAME]}, "
            f"context={get_active_context(self.session)})"
        )
