"""
Remote Authentication Manager - Handles authentication via Flask API

Extracted from monolithic Authentication class for better separation of concerns.
"""

from zOS import os, Dict, Optional, Any

from ...auth_constants import (
    STATUS_SUCCESS,
    STATUS_FAIL,
    STATUS_ERROR,
    KEY_STATUS,
    KEY_USER,
    KEY_USERNAME,
    KEY_PASSWORD,
    KEY_SERVER_URL,
    FIELD_ROLE,
    FIELD_API_KEY,
    DEFAULT_SERVER_URL,
    ENV_API_URL,
    HTTP_MODE_KEY,
    HTTP_MODE_ZCLI,
    _LOG_PREFIX_AUTH,
    _LOG_LEVEL_INFO,
    _LOG_LEVEL_WARNING,
    _LOG_LEVEL_ERROR,
    _LOG_REMOTE_AUTH,
    _LOG_REMOTE_SUCCESS,
    _LOG_REMOTE_FAIL,
    _ERR_CONNECTION_FAILED,
    _ERR_INVALID_CREDS,
    _LOG_APP_AUTH_ERROR,
)

LOG_PREFIX = _LOG_PREFIX_AUTH


class RemoteAuthenticationManager:
    """Manages remote API authentication operations."""

    def __init__(self, zos: Any) -> None:
        """Initialize with zOS instance."""
        self.zos = zos
        self.logger = zos.logger

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        if level == _LOG_LEVEL_INFO:
            self.logger.info(message)
        elif level == _LOG_LEVEL_WARNING:
            self.logger.warning(message)
        elif level == _LOG_LEVEL_ERROR:
            self.logger.error(message)

    def _create_status_response(self, status: str, **kwargs: Any) -> Dict[str, Any]:
        """Create standardized status response dictionary."""
        response = {KEY_STATUS: status}
        response.update(kwargs)
        return response

    def authenticate_remote(
        self,
        username: str,
        password: str,
        server_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """Authenticate via Flask API (remote server)."""
        server_url = self._get_server_url(server_url)
        self._log(_LOG_LEVEL_INFO, f"{_LOG_REMOTE_AUTH}: {server_url}")

        try:
            response = self._send_auth_request(username, password, server_url)
            if not response:
                return self._create_status_response(STATUS_FAIL, reason=_ERR_CONNECTION_FAILED)

            result = response.json()

            if result and result.get(KEY_STATUS) == STATUS_SUCCESS:
                return self._handle_remote_auth_success(result, server_url)

            return self._handle_remote_auth_failure()

        except Exception as e:
            return self._handle_remote_auth_error(e)

    def _get_server_url(self, server_url: Optional[str]) -> str:
        """Get server URL from parameter, environment, or default."""
        if server_url:
            return server_url
        return os.getenv(ENV_API_URL, DEFAULT_SERVER_URL)

    def _send_auth_request(self, username: str, password: str, server_url: str):
        """Send HTTP POST request to authentication server."""
        return self.zos.comm.http_post(
            f"{server_url}/zAuth",
            data={KEY_USERNAME: username, KEY_PASSWORD: password, HTTP_MODE_KEY: HTTP_MODE_ZCLI}
        )

    def _handle_remote_auth_success(self, result: Dict[str, Any], server_url: str) -> Dict[str, Any]:
        """Handle successful remote authentication."""
        user = result.get(KEY_USER, {})
        credentials = self._prepare_credentials(user, server_url)

        self._log(
            _LOG_LEVEL_INFO,
            f"{_LOG_REMOTE_SUCCESS}: {credentials[KEY_USERNAME]} (role={credentials[FIELD_ROLE]})"
        )

        self._display_remote_auth_success(credentials, server_url)

        return self._create_status_response(STATUS_SUCCESS, credentials=credentials)

    def _prepare_credentials(self, user: Dict[str, Any], server_url: str) -> Dict[str, Any]:
        """Prepare credentials dict from user data."""
        return {
            KEY_USERNAME: user.get(KEY_USERNAME),
            FIELD_API_KEY: user.get(FIELD_API_KEY),
            FIELD_ROLE: user.get(FIELD_ROLE),
            "user_id": user.get("id"),
            KEY_SERVER_URL: server_url
        }

    def _display_remote_auth_success(self, credentials: Dict[str, Any], server_url: str) -> None:
        """Display remote authentication success message."""
        self.zos.display.zEvents.BasicOutputs.text("")
        self.zos.display.zEvents.Signals.success(
            f"Logged in as: {credentials[KEY_USERNAME]} ({credentials[FIELD_ROLE]})"
        )
        self.zos.display.zEvents.BasicOutputs.text(
            f"API Key: {credentials[FIELD_API_KEY][:20]}...",
            indent=1
        )
        self.zos.display.zEvents.BasicOutputs.text(
            f"Server: {server_url}",
            indent=1
        )

    def _handle_remote_auth_failure(self) -> Dict[str, Any]:
        """Handle remote authentication failure."""
        self._log(_LOG_LEVEL_WARNING, _LOG_REMOTE_FAIL)
        self.zos.display.zEvents.BasicOutputs.text("")
        self.zos.display.zEvents.Signals.error(f"Authentication failed: {_ERR_INVALID_CREDS}")
        self.zos.display.zEvents.BasicOutputs.text("")
        return self._create_status_response(STATUS_FAIL, reason=_ERR_INVALID_CREDS)

    def _handle_remote_auth_error(self, error: Exception) -> Dict[str, Any]:
        """Handle remote authentication error."""
        self._log(_LOG_LEVEL_ERROR, f"{_LOG_APP_AUTH_ERROR}: {error}")
        self.zos.display.zEvents.BasicOutputs.text("")
        self.zos.display.zEvents.Signals.error(f"Error connecting to remote server: {error}")
        self.zos.display.zEvents.BasicOutputs.text("")
        return self._create_status_response(STATUS_ERROR, reason=str(error))
