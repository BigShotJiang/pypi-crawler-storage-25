"""
Context Helpers - Resolves authentication context for RBAC

Extracted from monolithic RBAC class for better separation of concerns.
"""

from zOS import Optional, Any, Union, Tuple
from zOS.L1_Foundation.a_zConfig.zConfig_modules.config_constants import (
    SESSION_KEY_ZAUTH,
    ZAUTH_KEY_ZSESSION,
    ZAUTH_KEY_APPLICATIONS,
    ZAUTH_KEY_ACTIVE_CONTEXT,
    ZAUTH_KEY_ACTIVE_APP,
    ZAUTH_KEY_ROLE,
    ZAUTH_KEY_ID,
    ZAUTH_KEY_AUTHENTICATED,
    CONTEXT_ZSESSION,
    CONTEXT_APPLICATION,
    CONTEXT_DUAL,
)

from ...auth_constants import (
    DB_LABEL_AUTH,
    SCHEMA_META_KEY,
    SCHEMA_LABEL_KEY,
    _LOG_PREFIX_RBAC,
    _LOG_NO_ACTIVE_APP,
    _LOG_UNKNOWN_CONTEXT,
)

from ...auth_helpers import get_auth_data

LOG_PREFIX = _LOG_PREFIX_RBAC


class ContextHelpers:
    """Resolves authentication context for RBAC operations."""

    def __init__(self, zos: Any) -> None:
        """Initialize with zOS instance."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        full_message = f"{LOG_PREFIX} {message}"

        if level == "debug":
            self.logger.debug(full_message)
        elif level == "warning":
            self.logger.warning(full_message)

    def _get_active_context(self) -> str:
        """Get the current active authentication context."""
        if not self.session:
            return CONTEXT_ZSESSION

        return self.session.get(SESSION_KEY_ZAUTH, {}).get(
            ZAUTH_KEY_ACTIVE_CONTEXT,
            CONTEXT_ZSESSION
        )

    def _get_current_role(self) -> Optional[Union[str, Tuple[str, str]]]:
        """Get the current user's role(s) from the active authentication context."""
        if not self.session:
            return None

        active_context = self._get_active_context()
        auth_data = get_auth_data(self.session)

        if active_context == CONTEXT_ZSESSION:
            return auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_ROLE)

        elif active_context == CONTEXT_APPLICATION:
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            if not active_app:
                self._log("debug", _LOG_NO_ACTIVE_APP)
                return None

            return auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {}).get(ZAUTH_KEY_ROLE)

        elif active_context == CONTEXT_DUAL:
            zsession_role = auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_ROLE)
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            app_role = None
            if active_app:
                app_role = auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {}).get(ZAUTH_KEY_ROLE)

            return (zsession_role, app_role)

        else:
            self._log("warning", f"{_LOG_UNKNOWN_CONTEXT}: {active_context}")
            return None

    def _get_current_user_id(self) -> Optional[Union[str, Tuple[Optional[str], Optional[str]]]]:
        """Get the current user's ID(s) from the active authentication context."""
        if not self.session:
            return None

        active_context = self._get_active_context()
        auth_data = get_auth_data(self.session)

        if active_context == CONTEXT_ZSESSION:
            return auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_ID)

        elif active_context == CONTEXT_APPLICATION:
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            if not active_app:
                return None

            return auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {}).get(ZAUTH_KEY_ID)

        elif active_context == CONTEXT_DUAL:
            zsession_id = auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_ID)
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            app_id = None
            if active_app:
                app_id = auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {}).get(ZAUTH_KEY_ID)

            return (zsession_id, app_id)

        else:
            return None

    def _is_authenticated(self) -> bool:
        """Check if user is authenticated in the active context."""
        if not self.session:
            return False

        active_context = self._get_active_context()
        auth_data = get_auth_data(self.session)

        if active_context == CONTEXT_ZSESSION:
            return auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_AUTHENTICATED, False)

        elif active_context == CONTEXT_APPLICATION:
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            if not active_app:
                return False

            return auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {}).get(ZAUTH_KEY_AUTHENTICATED, False)

        elif active_context == CONTEXT_DUAL:
            zsession_auth = auth_data.get(ZAUTH_KEY_ZSESSION, {}).get(ZAUTH_KEY_AUTHENTICATED, False)
            active_app = auth_data.get(ZAUTH_KEY_ACTIVE_APP)
            app_auth = False
            if active_app:
                app_session = auth_data.get(ZAUTH_KEY_APPLICATIONS, {}).get(active_app, {})
                app_auth = app_session.get(ZAUTH_KEY_AUTHENTICATED, False)

            return zsession_auth and app_auth

        else:
            return False

    def _is_db_ready(self) -> bool:
        """Check if zData handler is ready and auth schema is loaded."""
        return (
            self.zos.data.handler is not None and
            self.zos.data.schema.get(SCHEMA_META_KEY, {}).get(SCHEMA_LABEL_KEY) == DB_LABEL_AUTH
        )
