"""
Logout Manager - Handles logout operations across contexts

Extracted from monolithic Authentication class for better separation of concerns.
"""

from zOS import Dict, Optional, Any
from zOS.L1_Foundation.a_zConfig.zConfig_modules import (
    SESSION_KEY_ZAUTH,
    ZAUTH_KEY_ZSESSION,
    ZAUTH_KEY_APPLICATIONS,
    ZAUTH_KEY_ACTIVE_APP,
    ZAUTH_KEY_ACTIVE_CONTEXT,
    ZAUTH_KEY_DUAL_MODE,
    ZAUTH_KEY_AUTHENTICATED,
    ZAUTH_KEY_ID,
    ZAUTH_KEY_USERNAME,
    ZAUTH_KEY_ROLE,
    ZAUTH_KEY_API_KEY,
    CONTEXT_ZSESSION,
    CONTEXT_APPLICATION,
)
from zOS.L1_Foundation.a_zConfig.zConfig_modules.session.config_session import SessionConfig

from ...auth_constants import (
    STATUS_SUCCESS,
    STATUS_ERROR,
    KEY_STATUS,
    TABLE_SESSIONS,
    FIELD_USERNAME,
    DEFAULT_DELETE_PERSISTENT,
    HTTP_DATA_KEY,
    _LOG_PREFIX_AUTH,
    _LOG_LEVEL_INFO,
    _LOG_LEVEL_DEBUG,
    _LOG_LOGOUT_APP,
    _LOG_LOGOUT_ALL_APPS,
    _LOG_SESSION_DELETE,
    _LOG_SESSION_DELETE_FAIL,
    _ERR_NO_SESSION,
    _ERR_APP_NAME_REQUIRED,
    _ERR_APP_NOT_AUTH,
)

from ...auth_helpers import get_zsession_data, get_applications_data

LOG_PREFIX = _LOG_PREFIX_AUTH


class LogoutManager:
    """Manages logout operations across all authentication contexts."""

    def __init__(self, zos: Any, credential_manager: Any) -> None:
        """Initialize with zOS instance and dependencies."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger
        self.credential_manager = credential_manager

    def _log(self, level: str, message: str) -> None:
        """Centralized logging with LOG_PREFIX."""
        if level == _LOG_LEVEL_INFO:
            self.logger.info(message)
        elif level == _LOG_LEVEL_DEBUG:
            self.logger.debug(message)

    def _create_status_response(self, status: str, **kwargs: Any) -> Dict[str, Any]:
        """Create standardized status response dictionary."""
        response = {KEY_STATUS: status}
        response.update(kwargs)
        return response

    def _check_session(self) -> bool:
        """Validate that session exists."""
        return self.session is not None

    def logout(
        self,
        context: str = CONTEXT_ZSESSION,
        app_name: Optional[str] = None,
        delete_persistent: bool = DEFAULT_DELETE_PERSISTENT
    ) -> Dict[str, Any]:
        """Clear session authentication (context-aware, multi-app support)."""
        if not self._check_session():
            return self._create_status_response(STATUS_ERROR, reason=_ERR_NO_SESSION)

        cleared = []
        is_logged_in = self.credential_manager.is_authenticated()

        if context in [CONTEXT_ZSESSION, "all"]:
            _username = self._logout_zsession(cleared, delete_persistent)
        else:
            _username = None

        self._display_logout_feedback(is_logged_in)

        if context == CONTEXT_APPLICATION:
            error_response = self._logout_application(app_name, cleared)
            if error_response:
                return error_response

        if context in ["all_apps", "all"]:
            self._logout_all_applications(cleared)

        new_hash = SessionConfig.regenerate_session_hash(self.session)
        self._log(_LOG_LEVEL_DEBUG, f"Session hash regenerated on logout: {new_hash}")

        return self._create_status_response(
            STATUS_SUCCESS,
            context=context,
            cleared=cleared,
            delete_persistent=delete_persistent if context in [CONTEXT_ZSESSION, "all"] else False
        )

    def _logout_zsession(self, cleared: list, delete_persistent: bool) -> Optional[str]:
        """Logout from zSession and update context."""
        username = get_zsession_data(self.session).get(ZAUTH_KEY_USERNAME)

        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ZSESSION] = {
            ZAUTH_KEY_AUTHENTICATED: False,
            ZAUTH_KEY_ID: None,
            ZAUTH_KEY_USERNAME: None,
            ZAUTH_KEY_ROLE: None,
            ZAUTH_KEY_API_KEY: None
        }

        self._update_context_after_zsession_logout()
        cleared.append(f"{CONTEXT_ZSESSION} ({username})")

        if delete_persistent and username:
            self._delete_persistent_session(username)

        return username

    def _update_context_after_zsession_logout(self) -> None:
        """Update active context after zSession logout."""
        if self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_CONTEXT) == CONTEXT_ZSESSION:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = None

        if self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_DUAL_MODE):
            apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})
            if apps:
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_APPLICATION
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False
            else:
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = None
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False

    def _delete_persistent_session(self, username: str) -> None:
        """Delete persistent session from SQLite database."""
        try:
            if hasattr(self.zos, HTTP_DATA_KEY) and self.zos.data.handler:
                self.zos.data.delete(
                    table=TABLE_SESSIONS,
                    where=f"{FIELD_USERNAME} = '{username}'"
                )
                self._log(_LOG_LEVEL_DEBUG, f"{_LOG_SESSION_DELETE}: {username}")
        except Exception as e:
            self._log(_LOG_LEVEL_DEBUG, f"{_LOG_SESSION_DELETE_FAIL}: {e}")

    def _display_logout_feedback(self, is_logged_in: bool) -> None:
        """Display logout feedback to user."""
        if is_logged_in:
            self.zos.display.success("[OK] Logged out successfully")
        else:
            self.zos.display.warning("[WARN] Not currently logged in")

    def _logout_application(self, app_name: Optional[str], cleared: list) -> Optional[Dict[str, Any]]:
        """Logout from specific application."""
        if not app_name:
            return self._create_status_response(STATUS_ERROR, reason=_ERR_APP_NAME_REQUIRED)

        apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})
        if app_name not in apps:
            return self._create_status_response(STATUS_ERROR, reason=f"{_ERR_APP_NOT_AUTH} {app_name}")

        app_username = apps[app_name].get(ZAUTH_KEY_USERNAME)
        del get_applications_data(self.session)[app_name]
        cleared.append(f"{CONTEXT_APPLICATION}/{app_name} ({app_username})")

        self._update_context_after_app_logout(app_name)
        self._log(_LOG_LEVEL_INFO, f"{_LOG_LOGOUT_APP}: {app_name}")
        return None

    def _update_context_after_app_logout(self, app_name: str) -> None:
        """Update active app and context after logging out of an application."""
        if self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_APP) == app_name:
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_APP] = None

            if not get_applications_data(self.session):
                if self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_CONTEXT) == CONTEXT_APPLICATION:
                    self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = None
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False

    def _logout_all_applications(self, cleared: list) -> None:
        """Logout from all applications."""
        apps = self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_APPLICATIONS, {})

        for app_name_iter, app_data in apps.items():
            app_username = app_data.get(ZAUTH_KEY_USERNAME)
            cleared.append(f"{CONTEXT_APPLICATION}/{app_name_iter} ({app_username})")

        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_APPLICATIONS] = {}
        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_APP] = None

        self._update_context_after_all_apps_logout()
        self._log(_LOG_LEVEL_INFO, f"{_LOG_LOGOUT_ALL_APPS} ({len(apps)} apps)")

    def _update_context_after_all_apps_logout(self) -> None:
        """Update context after logging out of all applications."""
        if self.session[SESSION_KEY_ZAUTH].get(ZAUTH_KEY_ACTIVE_CONTEXT) in [CONTEXT_APPLICATION, "dual"]:
            if get_zsession_data(self.session).get(ZAUTH_KEY_AUTHENTICATED):
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_ZSESSION
            else:
                self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = None

        self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_DUAL_MODE] = False
