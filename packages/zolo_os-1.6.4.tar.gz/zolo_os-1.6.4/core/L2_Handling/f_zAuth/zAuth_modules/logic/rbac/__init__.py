"""
RBAC Facade - Maintains backward compatibility

This facade delegates to specialized manager classes while preserving the
original RBAC class interface.
"""

from zOS import Any, Dict, Optional, Union, List

from .context_helpers import ContextHelpers
from .database_manager import DatabaseManager
from .role_checker import RoleChecker
from .permission_checker import PermissionChecker
from .permission_manager import PermissionManager


class RBAC:
    """
    Context-Aware Role-Based Access Control with three-tier authentication support.
    
    This is a facade class that delegates to specialized managers:
    - ContextHelpers: Resolves authentication context
    - DatabaseManager: Handles database initialization
    - RoleChecker: Performs role checks with hierarchy support
    - PermissionChecker: Performs permission checks
    - PermissionManager: Handles permission grant/revoke
    
    Maintains full backward compatibility with the original monolithic class.
    """
    
    zos: Any
    session: Dict[str, Any]
    logger: Any
    _permissions_db_initialized: bool
    
    def __init__(self, zos: Any) -> None:
        """Initialize RBAC module with manager delegation."""
        self.zos = zos
        self.session = zos.session
        self.logger = zos.logger
        self._permissions_db_initialized = False
        
        # Initialize managers (order matters for dependencies)
        self._context_helpers = ContextHelpers(zos)
        self._database_manager = DatabaseManager(zos, self._context_helpers)
        self._role_checker = RoleChecker(zos, self._context_helpers)
        self._permission_checker = PermissionChecker(zos, self._context_helpers, self._database_manager)
        self._permission_manager = PermissionManager(zos, self._context_helpers, self._database_manager)
    
    # =========================================================================
    # PUBLIC API - Delegated to managers
    # =========================================================================
    
    # Role Checking
    def has_role(self, required_role: Optional[Union[str, List[str]]]) -> bool:
        """Check if the current user has the required role (context-aware)."""
        return self._role_checker.has_role(required_role)
    
    # Permission Checking
    def has_permission(self, required_permission: Union[str, List[str]]) -> bool:
        """Check if the current user has the required permission (context-aware)."""
        return self._permission_checker.has_permission(required_permission)
    
    # Permission Management
    def grant_permission(
        self, 
        user_id: str, 
        permission: str, 
        granted_by: Optional[str] = None
    ) -> bool:
        """Grant a permission to a user (admin-only operation)."""
        return self._permission_manager.grant_permission(user_id, permission, granted_by)
    
    def revoke_permission(self, user_id: str, permission: str) -> bool:
        """Revoke a permission from a user (admin-only operation)."""
        return self._permission_manager.revoke_permission(user_id, permission)
    
    # Database Initialization
    def ensure_permissions_db(self) -> None:
        """Ensure the permissions database is initialized."""
        self._database_manager.ensure_permissions_db()
        # Update facade's flag for backward compatibility
        self._permissions_db_initialized = self._database_manager._permissions_db_initialized


__all__ = ['RBAC']
