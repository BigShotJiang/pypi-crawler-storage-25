"""
Token Generation Utility for Session Persistence.

Provides cryptographically secure token generation using Python's
secrets module, consolidated from session_persistence.py.

Security:
    - Uses secrets.token_urlsafe() for cryptographic security
    - Configurable token length (default 32 bytes)
    - URL-safe base64 encoding (suitable for APIs)
"""

from zOS import secrets
from ..auth_constants import _TOKEN_LENGTH


def generate_session_tokens() -> tuple[str, str]:
    """Generate cryptographically secure session ID and API token.
    
    Returns:
        tuple: (session_id, token) - Both are URL-safe base64 strings
    
    Security:
        - Uses secrets.token_urlsafe for cryptographic strength
        - Default length: 32 bytes (produces ~43 character strings)
        - Suitable for session IDs and API tokens
    
    Example:
        >>> session_id, token = generate_session_tokens()
        >>> len(session_id)  # ~43 characters
        43
        >>> len(token)  # ~43 characters
        43
    """
    session_id = secrets.token_urlsafe(_TOKEN_LENGTH)
    token = secrets.token_urlsafe(_TOKEN_LENGTH)
    return session_id, token
