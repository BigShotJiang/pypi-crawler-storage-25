"""
Persistence Module - Layer 2: Data Persistence

Provides SQLite-based persistent session storage using composition pattern.

Architecture:
    - SessionPersistence: Facade coordinating database and store operations
    - SessionDatabase: Schema loading and table management
    - SessionStore: CRUD operations for session data
    - generate_session_tokens: Cryptographically secure token generation
    - decorators: Error handling utilities

Depends on: security (for password hashing)
"""

from .session_persistence import SessionPersistence
from .session_database import SessionDatabase
from .session_store import SessionStore
from .token_generator import generate_session_tokens
from .decorators import database_operation, requires_database

__all__ = [
    'SessionPersistence',
    'SessionDatabase',
    'SessionStore',
    'generate_session_tokens',
    'database_operation',
    'requires_database',
]
