"""
Database Operation Decorators for Error Handling.

Provides decorators to standardize error handling patterns across
session persistence operations, reducing boilerplate code.
"""

from functools import wraps
from zOS import Callable, Any
from ..auth_constants import _LOG_PREFIX_PERSISTENCE, _LOG_DB_NOT_LOADED_SKIP


def database_operation(
    skip_if_not_ready: bool = True,
    default_return: Any = None,
    operation_name: str = "database operation"
):
    """Decorator for database operations with standardized error handling.
    
    Features:
        - Checks database readiness before execution
        - Logs errors with context
        - Graceful degradation (returns default_return on failure)
        - Reduces try/except boilerplate
    
    Args:
        skip_if_not_ready: If True, skip operation if DB not ready
        default_return: Value to return on error or skip
        operation_name: Operation name for logging (e.g., "load", "save")
    
    Example:
        >>> @database_operation(skip_if_not_ready=True, default_return=None)
        >>> def load_session(self):
        ...     return self.zos.data.select(...)
    
    Usage Pattern:
        Before:
            def load_session(self):
                try:
                    if not self._is_db_ready():
                        self._log("debug", f"{LOG_DB_NOT_LOADED_SKIP} restore")
                        return
                    # ... operation logic ...
                except Exception as e:
                    self._log("error", f"Error loading session: {e}")
        
        After:
            @database_operation(operation_name="restore")
            def load_session(self):
                # ... operation logic ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            # Check database readiness if required
            if skip_if_not_ready:
                # Assumes instance has _is_db_ready() and _log() methods
                # pylint: disable=protected-access
                if hasattr(self, '_is_db_ready') and not self._is_db_ready():
                    if hasattr(self, '_log'):
                        self._log("debug", f"{_LOG_DB_NOT_LOADED_SKIP} {operation_name}")
                    return default_return

            # Execute operation with error handling
            try:
                return func(self, *args, **kwargs)
            except Exception as e:
                # Log error if logger available
                # pylint: disable=protected-access
                if hasattr(self, '_log'):
                    self._log("error", f"Error during {operation_name}: {e}")
                elif hasattr(self, 'logger'):
                    log_method = getattr(self.logger, 'error', None)
                    if log_method:
                        log_method(f"{_LOG_PREFIX_PERSISTENCE} Error during {operation_name}: {e}")

                return default_return

        return wrapper
    return decorator


def requires_database(default_return: Any = None):
    """Simplified decorator that requires database to be ready.
    
    This is a convenience wrapper around database_operation with
    common defaults for operations that absolutely need the database.
    
    Args:
        default_return: Value to return if database not ready
    
    Example:
        >>> @requires_database(default_return=0)
        >>> def cleanup_expired(self):
        ...     return self.zos.data.delete(...)
    """
    return database_operation(
        skip_if_not_ready=True,
        default_return=default_return,
        operation_name="database operation"
    )
