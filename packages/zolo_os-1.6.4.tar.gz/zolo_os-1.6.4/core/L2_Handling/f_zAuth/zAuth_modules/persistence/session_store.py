"""
Session Store - CRUD Operations for Session Persistence.

Handles all session data operations including:
- Loading sessions from database
- Saving sessions to database
- Deleting sessions
- Cleaning up expired sessions

Separated from session_persistence.py for single responsibility principle.
"""

from zOS import datetime, timedelta, Any, Dict, Optional
from zOS.L1_Foundation.a_zConfig.zConfig_modules import (
    ZAUTH_KEY_AUTHENTICATED,
    ZAUTH_KEY_ID,
    ZAUTH_KEY_USERNAME,
    ZAUTH_KEY_ROLE,
    ZAUTH_KEY_API_KEY,
    ZAUTH_KEY_ACTIVE_CONTEXT,
    SESSION_KEY_ZAUTH,
    CONTEXT_ZSESSION
)

from ..auth_constants import (
    DEFAULT_SESSION_DURATION_DAYS,
    TABLE_SESSIONS,
    FIELD_SESSION_ID,
    FIELD_USER_ID,
    FIELD_USERNAME,
    FIELD_ROLE,
    FIELD_PASSWORD_HASH,
    FIELD_TOKEN,
    FIELD_CREATED_AT,
    FIELD_EXPIRES_AT,
    FIELD_LAST_ACCESSED,
    QUERY_LIMIT_ONE,
    ORDER_BY_LAST_ACCESSED,
    _SESSION_KEY_SESSION_ID,
    _LOG_PREFIX_PERSISTENCE,
    _LOG_SESSION_RESTORED,
    _LOG_SESSION_SAVED,
    _LOG_SESSIONS_CLEANED,
    _LOG_NO_SESSION,
    _LOG_NO_EXPIRED_SESSIONS,
    _LOG_NO_EXISTING_SESSIONS,
    _LOG_ERROR_LOAD_SESSION,
    _LOG_ERROR_SAVE_SESSION,
    _LOG_ERROR_CLEANUP,
)

from ..auth_helpers import get_zsession_data
from .token_generator import generate_session_tokens


class SessionStore:
    """
    CRUD operations for session persistence.
    
    This class handles all database operations for sessions:
    - Loading (restore session from database)
    - Saving (persist session to database)
    - Deleting (remove existing sessions)
    - Cleanup (remove expired sessions)
    
    Responsibilities:
        - Session data queries (SELECT, INSERT, UPDATE, DELETE)
        - Token generation
        - Timestamp management
        - In-memory session updates
    
    Integration:
        - Uses zOS.data for database operations
        - Updates zOS.session for in-memory state
        - Coordinates with auth_helpers for session access
    
    Example:
        >>> store = SessionStore(zos, session, logger, session_duration_days=7)
        >>> store.load()  # Restore from database
        >>> session_id = store.save("username", "hash", role="admin")
        >>> deleted = store.cleanup_expired()
    """

    def __init__(
        self,
        zos: Any,
        session: Dict[str, Any],
        logger: Any,
        session_duration_days: int = DEFAULT_SESSION_DURATION_DAYS
    ):
        """Initialize session store.
        
        Args:
            zos: zOS instance providing data subsystem
            session: In-memory session dictionary
            logger: Logger instance for diagnostic output
            session_duration_days: Session expiration period in days
        """
        self.zos = zos
        self.session = session
        self.logger = logger
        self.session_duration_days = session_duration_days

    def load(self) -> None:
        """Load and restore persistent session on startup (if exists and valid).
        
        Session Restoration:
            1. Query for most recent valid session (not expired)
            2. Restore session data to session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ZSESSION]
            3. Set active_context to CONTEXT_ZSESSION
            4. Update last_accessed timestamp in database
        
        Query Logic:
            - WHERE: expires_at > current_time (not expired)
            - ORDER BY: last_accessed DESC (most recent first)
            - LIMIT: 1 (single most recent session)
        
        Error Handling:
            - No valid session: Log debug message, return gracefully
            - Query failure: Log error, return gracefully
        """
        try:
            # Query for most recent valid session (not expired)
            now = self._get_current_timestamp()

            results = self.zos.data.select(
                table=TABLE_SESSIONS,
                where=f"{FIELD_EXPIRES_AT} > '{now}'",
                order=ORDER_BY_LAST_ACCESSED,
                limit=QUERY_LIMIT_ONE
            )

            if not results or len(results) == 0:
                self._log("debug", _LOG_NO_SESSION)
                return

            # Restore session to in-memory state (zSession context)
            session_data = results[0]

            get_zsession_data(self.session).update({
                ZAUTH_KEY_AUTHENTICATED: True,
                ZAUTH_KEY_ID: session_data.get(FIELD_USER_ID),
                ZAUTH_KEY_USERNAME: session_data.get(FIELD_USERNAME),
                ZAUTH_KEY_ROLE: session_data.get(FIELD_ROLE, "user"),
                ZAUTH_KEY_API_KEY: session_data.get(FIELD_TOKEN),
                _SESSION_KEY_SESSION_ID: session_data.get(FIELD_SESSION_ID)
            })

            # Set active context to zSession
            self.session[SESSION_KEY_ZAUTH][ZAUTH_KEY_ACTIVE_CONTEXT] = CONTEXT_ZSESSION

            # Update last_accessed timestamp
            self.zos.data.update(
                table=TABLE_SESSIONS,
                fields=[FIELD_LAST_ACCESSED],
                values=[self._get_current_timestamp()],
                where=f"{FIELD_SESSION_ID} = '{session_data.get(FIELD_SESSION_ID)}'"
            )

            self._log("info", f"{_LOG_SESSION_RESTORED}: {session_data.get(FIELD_USERNAME)}")

        except Exception as e:
            self._log("error", f"{_LOG_ERROR_LOAD_SESSION}: {e}")

    def save(
        self,
        username: str,
        password_hash: str,
        user_id: Optional[str] = None,
        role: str = "user"
    ) -> Optional[str]:
        """Save session to persistent storage.
        
        Args:
            username: Username for the session
            password_hash: bcrypt password hash
            user_id: Optional user ID (defaults to username)
            role: User role (default: "user")
        
        Returns:
            str: Generated session_id if successful, None if failed
        
        Process:
            1. Generate session data (tokens, timestamps)
            2. Delete existing sessions for user
            3. Insert new session record
            4. Update in-memory session with session_id
        """
        try:
            # Generate session data
            session_data = self._generate_session_data(username, user_id)

            # Delete existing sessions for user
            self._delete_existing_sessions(username)

            # Insert new session record
            self._insert_session_record(
                session_data['session_id'],
                session_data['user_id'],
                username,
                role,
                password_hash,
                session_data['token'],
                session_data['created_at'],
                session_data['expires_at'],
                session_data['last_accessed']
            )

            # Update in-memory session
            self._update_session_id(session_data['session_id'])

            # Log success
            self._log("info", f"{_LOG_SESSION_SAVED}: {username} (expires: {session_data['expires_at']})")

            return session_data['session_id']

        except Exception as e:
            self._log("error", f"{_LOG_ERROR_SAVE_SESSION}: {e}")
            return None

    def cleanup_expired(self) -> int:
        """Remove expired sessions from database.
        
        Returns:
            int: Number of sessions deleted (0 if none expired)
        
        Query Logic:
            - WHERE: expires_at <= current_time
            - DELETE: All matching records
        """
        try:
            now = self._get_current_timestamp()

            deleted = self.zos.data.delete(
                table=TABLE_SESSIONS,
                where=f"{FIELD_EXPIRES_AT} <= '{now}'"
            )

            if deleted and deleted > 0:
                self._log("info", f"{_LOG_SESSIONS_CLEANED}: {deleted}")
                return deleted
            else:
                self._log("debug", _LOG_NO_EXPIRED_SESSIONS)
                return 0

        except Exception as e:
            self._log("error", f"{_LOG_ERROR_CLEANUP}: {e}")
            return 0

    def _generate_session_data(self, username: str, user_id: Optional[str]) -> Dict[str, str]:
        """Generate session data with secure tokens and timestamps."""
        # Generate unique session ID and API token
        session_id, token = generate_session_tokens()

        # Calculate expiration and timestamps
        expires_at = (datetime.now() + timedelta(days=self.session_duration_days)).isoformat()
        created_at = self._get_current_timestamp()
        last_accessed = created_at

        # Use user_id or fall back to username
        effective_user_id = user_id if user_id else username

        return {
            'session_id': session_id,
            'token': token,
            'user_id': effective_user_id,
            'created_at': created_at,
            'expires_at': expires_at,
            'last_accessed': last_accessed
        }

    def _delete_existing_sessions(self, username: str) -> None:
        """Delete any existing sessions for user (single session policy)."""
        try:
            self.zos.data.delete(
                table=TABLE_SESSIONS,
                where=f"{FIELD_USERNAME} = '{username}'"
            )
        except Exception as e:
            self._log("debug", f"{_LOG_NO_EXISTING_SESSIONS}: {e}")

    def _insert_session_record(
        self,
        session_id: str,
        user_id: str,
        username: str,
        role: str,
        password_hash: str,
        token: str,
        created_at: str,
        expires_at: str,
        last_accessed: str
    ) -> None:
        """Insert new session record into database."""
        self.zos.data.insert(
            table=TABLE_SESSIONS,
            fields=[
                FIELD_SESSION_ID,
                FIELD_USER_ID,
                FIELD_USERNAME,
                FIELD_ROLE,
                FIELD_PASSWORD_HASH,
                FIELD_TOKEN,
                FIELD_CREATED_AT,
                FIELD_EXPIRES_AT,
                FIELD_LAST_ACCESSED
            ],
            values=[
                session_id,
                user_id,
                username,
                role,
                password_hash,
                token,
                created_at,
                expires_at,
                last_accessed
            ]
        )

    def _update_session_id(self, session_id: str) -> None:
        """Update in-memory session with session_id."""
        self.session[SESSION_KEY_ZAUTH][_SESSION_KEY_SESSION_ID] = session_id

    def _get_current_timestamp(self) -> str:
        """Get current timestamp in ISO format."""
        return datetime.now().isoformat()

    def _log(self, level: str, message: str):
        """Centralized logging with persistence prefix."""
        if self.logger:
            log_method = getattr(self.logger, level, self.logger.info)
            log_method(f"{_LOG_PREFIX_PERSISTENCE} {message}")
