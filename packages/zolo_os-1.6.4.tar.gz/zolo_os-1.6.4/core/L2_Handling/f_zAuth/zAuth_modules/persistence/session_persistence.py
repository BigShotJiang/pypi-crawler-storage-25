"""
Session Persistence Module - SQLite-based session management (v1.5.4+)

This module provides persistent session storage using SQLite, enabling
"Remember me" functionality across application restarts. It integrates
deeply with zOS's declarative zData subsystem and three-tier authentication
architecture.

ARCHITECTURE - Session Persistence Layer

Design Pattern:
    - SQLite-backed persistent storage (unified auth database)
    - Declarative zData operations (no raw SQL)
    - Lazy initialization (database loaded on demand)
    - Automatic expiration and cleanup
    - Integration with three-tier authentication

Session Lifecycle:
    1. LOAD:    Restore valid session from database on startup
    2. SAVE:    Persist authenticated session to database
    3. EXPIRE:  Sessions expire after 7 days (configurable)
    4. CLEANUP: Automatic removal of expired sessions

Storage Location:
    - Platform-specific data directory (via platformdirs)
    - Unified auth database: sessions + permissions tables
    - Schema: zSchema.auth.yaml (declarative YAML)

DATABASE STRUCTURE - Unified Auth Database

Database Label: "auth"
    - Shared between SessionPersistence and RBAC modules
    - Defined in zSchema.auth.yaml (zAuth subsystem)

Table: sessions
    Fields:
        - session_id:    Unique session identifier (32-byte URL-safe token)
        - user_id:       User identifier (from authentication)
        - username:      Username for the session
        - role:          User role (user, admin, etc.)
        - password_hash: bcrypt password hash (for verification)
        - token:         API token (32-byte URL-safe token)
        - created_at:    Timestamp when session was created
        - expires_at:    Timestamp when session expires (7 days)
        - last_accessed: Timestamp of last access (updated on restore)

Table: user_permissions
    - Managed by RBAC module (authzRBAC.py)
    - Shared database for unified auth operations

SECURITY MODEL

Token Generation:
    - Uses secrets.token_urlsafe(32) for cryptographically secure tokens
    - Session ID: 32-byte URL-safe token (unique identifier)
    - API Token: 32-byte URL-safe token (authentication credential)

Session Expiration:
    - Default: 7 days from creation (configurable)
    - Automatic cleanup on startup
    - Manual cleanup available via cleanup_expired()

Password Storage:
    - Stores bcrypt password hash (from auth_password_security.py)
    - Never stores plaintext passwords
    - Hash used for session verification if needed

Single Session Per User:
    - Deletes existing sessions for user before creating new one
    - Prevents session accumulation
    - Last login wins (invalidates previous sessions)

THREE-TIER AUTHENTICATION INTEGRATION

Session Persistence Scope:
    - PERSISTS:     zSession context only (Layer 1)
    - NOT PERSISTED: Application contexts (Layer 2)
    - NOT PERSISTED: Dual-auth state (Layer 3)

Rationale:
    - zSession represents the zOS/Zolo user (persistent identity)
    - Application contexts are transient (per-application session)
    - Dual-auth is a runtime state (not persisted across restarts)

Session Restoration:
    - Loads zSession credentials from database
    - Sets active_context to "zSession"
    - Applications must re-authenticate on startup
    - Dual-auth must be re-established if needed

Integration with zAuth:
    - Used by auth_authentication.py for login/logout
    - Integrates with session["zAuth"] structure (via SESSION_KEY_ZAUTH)
    - Respects three-tier authentication model
    - Coordinates with RBAC via shared database

ZCLI INTEGRATION - Declarative zData Operations

zData Integration:
    - NO raw SQL queries (fully declarative)
    - Uses zData.select(), zData.insert(), zData.update(), zData.delete()
    - Schema loaded from zSchema.auth.yaml via zParser
    - Database handler managed by zData subsystem

zParser Integration:
    - Loads YAML schema from package directory
    - Parses schema into zData-compatible format
    - Handles package-internal file paths

zConfig Integration:
    - Imports ZAUTH_KEY_* constants (field names)
    - Imports SESSION_KEY_ZAUTH (session structure key)
    - Imports CONTEXT_ZSESSION (authentication context)
    - Ensures consistency with zConfig session structure

Lazy Initialization:
    - Database not loaded until first use
    - ensure_sessions_db() loads schema on demand
    - Graceful degradation if database unavailable

═══════════════════════════════════════════════════════════════════════════════
SESSION LIFECYCLE EXAMPLES
═══════════════════════════════════════════════════════════════════════════════

Initialization:
    >>> from zOS.L2_Handling.f_zAuth.zAuth_modules.persistence import SessionPersistence
    >>> session_mgr = SessionPersistence(zos, session_duration_days=7)
    >>> session_mgr.ensure_sessions_db()

Load Session on Startup:
    >>> # Called automatically by zAuth on initialization
    >>> session_mgr.load_session()
    # If valid session exists:
    # - Restores username, role, API key to session["zAuth"]["zSession"]
    # - Sets active_context to "zSession"
    # - Updates last_accessed timestamp

Save Session After Login:
    >>> # Called by auth_authentication.py after successful login
    >>> session_id = session_mgr.save_session(
    ...     username="john_doe",
    ...     password_hash="$2b$12$...",
    ...     user_id="zU_12345",
    ...     role="admin"
    ... )
    # Creates new session with 7-day expiration

Cleanup Expired Sessions:
    >>> # Called automatically on startup
    >>> deleted = session_mgr.cleanup_expired()
    >>> print(f"Cleaned up {deleted} expired sessions")

ERROR HANDLING & LOGGING

Graceful Degradation:
    - Database unavailable: Continue without persistence
    - Schema load failure: Log warning, continue
    - Session restore failure: Start with clean session

Logging Levels:
    - INFO:  Successful operations (DB init, session saved/restored, cleanup)
    - DEBUG: Operational details (no session found, DB checks)
    - WARN:  Non-fatal issues (schema not found, DB not loaded)
    - ERROR: Operation failures (save failed, restore failed)

Error Recovery:
    - All methods return gracefully on error
    - Try/except blocks with comprehensive logging
    - Never exposes sensitive data in logs (passwords, tokens)
    - Provides context for debugging (operation, reason)
"""

from zOS import Optional, Any, Dict

# Import only constants used in facade layer
from ..auth_constants import (
    DEFAULT_SESSION_DURATION_DAYS,
    _LOG_PREFIX_PERSISTENCE,
    _LOG_DB_NOT_LOADED_SKIP,
    _LOG_DB_NOT_LOADED_ATTEMPT,
    _LOG_DB_NOT_LOADED_WARNING,
)

# Composition Components
from .session_database import SessionDatabase
from .session_store import SessionStore

# Module uses _LOG_PREFIX_PERSISTENCE as LOG_PREFIX for compatibility
LOG_PREFIX = _LOG_PREFIX_PERSISTENCE


# Session Persistence Class

class SessionPersistence:
    """
    SQLite-based persistent session management with declarative zData integration.
    
    This class provides session persistence across application restarts using
    SQLite storage. It integrates with zOS's declarative zData subsystem and
    supports the three-tier authentication architecture.
    
    Architecture:
        - SQLite backend (unified auth database)
        - Declarative operations (no raw SQL)
        - Lazy initialization (load on demand)
        - Automatic expiration (7-day default)
        - Three-tier awareness (persists zSession only)
    
    Session Lifecycle:
        1. LOAD:    Restore valid session from database on startup
        2. SAVE:    Persist authenticated session to database
        3. EXPIRE:  Sessions expire after DEFAULT_SESSION_DURATION_DAYS
        4. CLEANUP: Automatic removal of expired sessions
    
    Security Features:
        - Cryptographically secure tokens (secrets.token_urlsafe)
        - bcrypt password hashes (never plaintext)
        - Automatic expiration and cleanup
        - Single session per user (last login wins)
    
    zData Integration:
        - No raw SQL queries (fully declarative)
        - Uses zData.select(), insert(), update(), delete()
        - Schema loaded from zSchema.auth.yaml via zParser
        - Graceful degradation if database unavailable
    
    Three-Tier Authentication:
        - PERSISTS:     zSession context (Layer 1)
        - NOT PERSISTED: Application contexts (Layer 2)
        - NOT PERSISTED: Dual-auth state (Layer 3)
        - Rationale: zSession is persistent identity, apps are transient
    
    Methods:
        ensure_sessions_db():     Initialize database and tables
        load_session():           Restore session from database on startup
        save_session(user, ...):  Persist authenticated session
        cleanup_expired():        Remove expired sessions (housekeeping)
        _is_db_ready():          Check if database is loaded (helper)
        _get_current_timestamp(): Get ISO timestamp (helper)
        _log(level, message):    Centralized logging (helper)
        _ensure_db_loaded():     Try to load database (helper)
    
    Usage:
        >>> session_mgr = SessionPersistence(zos, session_duration_days=7)
        >>> session_mgr.ensure_sessions_db()
        >>> session_mgr.load_session()  # On startup
        >>> session_id = session_mgr.save_session("john", hash, role="admin")
        >>> deleted = session_mgr.cleanup_expired()  # Housekeeping
    
    Integration:
        - Used by auth_authentication.py for login/logout
        - Shares database with authzRBAC.py (permissions)
        - Respects SESSION_KEY_ZAUTH from zConfig
        - Coordinates with three-tier authentication model
    
    Attributes:
        zos: Any                      - zOS instance
        logger: Any                    - Logger instance
        session: Dict[str, Any]        - In-memory session dictionary
        session_duration_days: int     - Session expiration period
        auth_db_label: str             - Database label ("auth")
    """

    # Class-level type declarations
    zos: Any
    logger: Any
    session: Dict[str, Any]
    session_duration_days: int

    # Composed components
    _database: SessionDatabase
    _store: SessionStore

    def __init__(self, zos: Any, session_duration_days: int = DEFAULT_SESSION_DURATION_DAYS):
        """Initialize session persistence module with configurable expiration.
        
        This class uses composition pattern to delegate operations to:
            - SessionDatabase: Schema loading and table management
            - SessionStore: CRUD operations for session data
        
        Args:
            zos: zOS instance providing access to:
                - data: zData subsystem for database operations
                - loader: zLoader for schema loading
                - logger: Logging instance
                - session: In-memory session dictionary
                - zparser: YAML parser for schema files
            session_duration_days: Session expiration period in days.
                Default is DEFAULT_SESSION_DURATION_DAYS (7 days).
                After this period, sessions expire and are removed.
        
        Notes:
            - Database is NOT initialized here (lazy initialization)
            - Call ensure_sessions_db() to initialize database
            - Gracefully handles missing zOS subsystems
        
        Example:
            >>> # Default 7-day expiration
            >>> session_mgr = SessionPersistence(zos)
            >>> 
            >>> # Custom 30-day expiration (long-lived sessions)
            >>> session_mgr = SessionPersistence(zos, session_duration_days=30)
            >>> 
            >>> # Initialize database
            >>> session_mgr.ensure_sessions_db()
        """
        self.zos = zos
        self.logger = zos.logger
        self.session = zos.session
        self.session_duration_days = session_duration_days

        # Initialize composed components
        self._database = SessionDatabase(zos, zos.logger)
        self._store = SessionStore(zos, zos.session, zos.logger, session_duration_days)

    # ═══════════════════════════════════════════════════════════════════════════
    # Private Helper Methods (Delegation to Composed Components)
    # ═══════════════════════════════════════════════════════════════════════════

    def _is_db_ready(self) -> bool:
        """Check if zData handler is ready with auth schema loaded.
        
        Delegates to SessionDatabase.is_ready()
        
        Returns:
            bool: True if database handler exists and auth schema is loaded
        """
        return self._database.is_ready()

    def _log(self, level: str, message: str):
        """Centralized logging with LOG_PREFIX.
        
        Args:
            level: Log level (info, debug, warning, error)
            message: Log message (without prefix)
        """
        if self.logger:
            log_method = getattr(self.logger, level, self.logger.info)
            log_method(f"{LOG_PREFIX} {message}")

    def _ensure_db_loaded(self) -> bool:
        """Attempt to load database if not ready.
        
        Returns:
            bool: True if database is ready, False otherwise
        """
        if self._is_db_ready():
            return True

        self._log("debug", _LOG_DB_NOT_LOADED_ATTEMPT)
        self.ensure_sessions_db()

        return self._is_db_ready()

    # ═══════════════════════════════════════════════════════════════════════════
    # Database Initialization (Facade - delegates to SessionDatabase)
    # ═══════════════════════════════════════════════════════════════════════════

    def ensure_sessions_db(self):
        """Ensure the sessions database is initialized (declarative zOS way).
        
        Delegates initialization to SessionDatabase component, then performs
        automatic cleanup of expired sessions.
        
        Process:
            1. SessionDatabase.initialize() - loads schema, creates tables
            2. cleanup_expired() - removes expired sessions
        
        Example:
            >>> session_mgr = SessionPersistence(zos)
            >>> session_mgr.ensure_sessions_db()
        
        Notes:
            - Safe to call multiple times (idempotent)
            - Automatic cleanup on initialization
            - Shares database with RBAC module
        """
        # Delegate database initialization to SessionDatabase
        if self._database.initialize():
            # Clean up expired sessions on successful initialization
            self.cleanup_expired()

    # ═══════════════════════════════════════════════════════════════════════════
    # Session Lifecycle Methods (Facade - delegates to SessionStore)
    # ═══════════════════════════════════════════════════════════════════════════

    def load_session(self):
        """Load and restore persistent session on startup (if exists and valid).
        
        Delegates to SessionStore.load() which handles:
            - Database readiness check
            - Query for valid session
            - Restore to in-memory state
            - Update last_accessed timestamp
        
        Example:
            >>> session_mgr = SessionPersistence(zos)
            >>> session_mgr.ensure_sessions_db()
            >>> session_mgr.load_session()
        """
        if not self._is_db_ready():
            self._log("debug", f"{_LOG_DB_NOT_LOADED_SKIP} restore")
            return

        # Delegate to SessionStore
        self._store.load()

    def save_session(
        self, username: str, password_hash: str,
        user_id: Optional[str] = None, role: str = "user"
    ) -> Optional[str]:
        """Save current session to persistent storage (sessions database).
        
        Delegates to SessionStore.save() which handles:
            - Database readiness check and lazy initialization
            - Token generation (session_id, API token)
            - Timestamp calculation (created_at, expires_at)
            - Deletion of existing sessions (single session policy)
            - Insert new session record
            - Update in-memory session
        
        Args:
            username: Username for the session
            password_hash: bcrypt password hash
            user_id: Optional user ID (defaults to username)
            role: User role (default: "user")
        
        Returns:
            str: Generated session_id if successful, None if failed
        
        Example:
            >>> session_id = session_mgr.save_session(
            ...     username="john_doe",
            ...     password_hash=hash,
            ...     user_id="zU_12345",
            ...     role="admin"
            ... )
        """
        # Check database readiness with lazy initialization
        if not self._ensure_db_loaded():
            self._log("warning", _LOG_DB_NOT_LOADED_WARNING)
            return None

        # Delegate to SessionStore
        return self._store.save(username, password_hash, user_id, role)

    def cleanup_expired(self) -> int:
        """Remove expired sessions from database (housekeeping).
        
        Delegates to SessionStore.cleanup_expired() which handles:
            - Database readiness check
            - Query for expired sessions (expires_at <= now)
            - Delete expired records
            - Return count of deleted sessions
        
        Returns: 
            int: Number of sessions deleted (0 if none expired)
        
        Example:
            >>> deleted = session_mgr.cleanup_expired()
            >>> if deleted > 0:
            >>>     print(f"Cleaned up {deleted} expired sessions")
        """
        if not self._is_db_ready():
            self._log("debug", f"{_LOG_DB_NOT_LOADED_SKIP} cleanup")
            return 0

        # Delegate to SessionStore
        return self._store.cleanup_expired()
