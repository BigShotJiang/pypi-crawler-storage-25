"""
Session Database Management - Schema Loading and Table Initialization.

Handles all database initialization concerns including:
- Schema file location and loading
- Schema parsing via zParser
- Database handler verification
- Table creation (sessions + permissions)

Separated from session_persistence.py for single responsibility principle.
"""

from zOS import Path, Any
from ..auth_constants import (
    DB_LABEL_AUTH,
    TABLE_SESSIONS,
    TABLE_PERMISSIONS,
    SCHEMAS_DIR,
    SCHEMA_FILE_NAME,
    SCHEMA_META_KEY,
    SCHEMA_LABEL_KEY,
    _LOG_PREFIX_PERSISTENCE,
    _LOG_SCHEMA_NOT_FOUND,
    _LOG_SCHEMA_PARSE_FAILED,
    _LOG_HANDLER_FAILED,
    _LOG_WRONG_SCHEMA,
    _LOG_TABLE_CREATED_SESSIONS,
    _LOG_TABLE_CREATED_PERMISSIONS,
    _LOG_DB_INIT,
    _LOG_ERROR_INIT_DB,
)


class SessionDatabase:
    """
    Database initialization and schema management for session persistence.
    
    This class handles all concerns related to setting up the SQLite database:
    - Locating and loading zSchema.auth.yaml
    - Parsing schema via zParser
    - Initializing zData handler
    - Creating required tables
    - Verifying database readiness
    
    Responsibilities:
        - Schema file I/O
        - Schema parsing and validation
        - Table creation (sessions, permissions)
        - Handler verification
    
    Integration:
        - Uses zOS.zparser for YAML parsing
        - Uses zOS.data for table operations
        - Coordinates with zData subsystem
        - Shares database with RBAC module
    
    Example:
        >>> db = SessionDatabase(zos, logger)
        >>> db.initialize()  # Load schema, create tables
        >>> if db.is_ready():
        ...     # Database ready for operations
    """

    def __init__(self, zos: Any, logger: Any):
        """Initialize database manager.
        
        Args:
            zos: zOS instance providing data, zparser subsystems
            logger: Logger instance for diagnostic output
        """
        self.zos = zos
        self.logger = logger
        self.auth_db_label = DB_LABEL_AUTH

    def is_ready(self) -> bool:
        """Check if database handler is ready with auth schema loaded.
        
        Returns:
            bool: True if handler exists and auth schema loaded, False otherwise
        
        Checks:
            1. zData handler exists (self.zos.data.handler)
            2. Schema is loaded (self.zos.data.schema)
            3. Schema label matches DB_LABEL_AUTH
        """
        return (
            self.zos.data.handler is not None and
            self.zos.data.schema.get(SCHEMA_META_KEY, {}).get(SCHEMA_LABEL_KEY) == self.auth_db_label
        )

    def initialize(self) -> bool:
        """Initialize database with schema and tables.
        
        Returns:
            bool: True if initialization successful, False otherwise
        
        Process:
            1. Load and parse auth schema
            2. Verify database handler
            3. Create required tables
        
        Error Handling:
            - All errors logged with context
            - Returns False on any failure
            - Safe to retry after fixing issues
        """
        try:
            # Load and verify schema
            if not self._load_auth_schema():
                return False

            # Verify database handler
            if not self._verify_db_handler():
                return False

            # Create required tables
            self._create_required_tables()

            self._log("info", _LOG_DB_INIT)
            return True

        except Exception as e:
            self._log("error", f"{_LOG_ERROR_INIT_DB}: {e}")
            import traceback
            self.logger.debug(traceback.format_exc())
            return False

    def _load_auth_schema(self) -> bool:
        """Load and parse auth schema from zSchema.auth.yaml.
        
        Returns:
            bool: True if schema loaded successfully, False otherwise
        """
        # Get absolute path to zSchema.auth.yaml (centralized location)
        zos_root = Path(__file__).parent.parent.parent.parent
        schema_path = zos_root / SCHEMAS_DIR / SCHEMA_FILE_NAME

        if not schema_path.exists():
            self._log("warning", f"{_LOG_SCHEMA_NOT_FOUND}: {schema_path}")
            return False

        # Load schema using zParser
        schema_content = Path(schema_path).read_text()
        parsed_schema = self.zos.zparser.parse_file_content(schema_content, ".yaml")

        if not parsed_schema:
            self._log("warning", _LOG_SCHEMA_PARSE_FAILED)
            return False

        # Load schema into zData
        self.zos.data.load_schema(parsed_schema)
        return True

    def _verify_db_handler(self) -> bool:
        """Verify database handler was created and correct schema loaded.
        
        Returns:
            bool: True if handler valid and schema correct, False otherwise
        """
        # Verify handler was created
        if not self.zos.data.handler:
            self._log("error", _LOG_HANDLER_FAILED)
            return False

        # Verify correct schema is loaded
        loaded_label = self.zos.data.schema.get(SCHEMA_META_KEY, {}).get(SCHEMA_LABEL_KEY)
        if loaded_label != self.auth_db_label:
            self._log("error", f"{_LOG_WRONG_SCHEMA}: {loaded_label} (expected: {self.auth_db_label})")
            return False

        return True

    def _create_required_tables(self) -> None:
        """Create sessions and permissions tables if they don't exist."""
        # Create sessions table
        if not self.zos.data.table_exists(TABLE_SESSIONS):
            self.zos.data.create_table(TABLE_SESSIONS)
            self._log("info", _LOG_TABLE_CREATED_SESSIONS)

        # Create permissions table (shared with RBAC)
        if not self.zos.data.table_exists(TABLE_PERMISSIONS):
            self.zos.data.create_table(TABLE_PERMISSIONS)
            self._log("info", _LOG_TABLE_CREATED_PERMISSIONS)

    def _log(self, level: str, message: str):
        """Centralized logging with persistence prefix.
        
        Args:
            level: Log level (info, debug, warning, error)
            message: Log message (without prefix)
        """
        if self.logger:
            log_method = getattr(self.logger, level, self.logger.info)
            log_method(f"{_LOG_PREFIX_PERSISTENCE} {message}")
