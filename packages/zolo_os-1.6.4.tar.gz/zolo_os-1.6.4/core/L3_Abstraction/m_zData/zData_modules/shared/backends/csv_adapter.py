# zOS/core/L3_Abstraction/n_zData/zData_modules/shared/backends/csv_adapter.py
"""
CSV database backend adapter with pandas-powered DataFrames and in-memory caching.

See csv_helpers/README.md for full documentation.
"""

from zOS import Dict, List, Optional, Any
from .base_adapter import BaseDataAdapter

try:
    import pandas  # pylint: disable=unused-import
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

# Import helper modules
from .csv_helpers import constants as csv_const
from .csv_helpers import file_operations as file_ops
from .csv_helpers import schema_operations as schema_ops
from .csv_helpers import ddl_operations as ddl_ops
from .csv_helpers import dml_operations as dml_ops

__all__ = ["CSVAdapter"]


class CSVAdapter(BaseDataAdapter):
    """
    CSV backend adapter with pandas DataFrames, in-memory caching, and multi-table JOINs.
    
    This is a thin orchestration layer that delegates to helper modules in csv_helpers/.
    See csv_helpers/README.md for complete documentation.
    
    Key Features:
    - Pandas-powered DataFrames for efficient data manipulation
    - In-memory table caching for performance
    - Multi-table JOIN support (manual and auto-detected)
    - Comprehensive WHERE clause filtering
    - Schema-based type coercion
    - UPSERT support with conflict resolution
    
    Methods:
    - DDL: create_table, alter_table, drop_table, table_exists, list_tables, introspect_schema
    - DML: insert, select, update, delete, upsert, aggregate
    - Connection: connect, disconnect, get_cursor
    - Transaction: begin_transaction, commit, rollback (no-ops for CSV)
    - Type mapping: map_type
    """

    def __init__(self, config: Dict[str, Any], logger=None) -> None:
        """Initialize CSV adapter with pandas check and in-memory caching."""
        if not PANDAS_AVAILABLE:
            raise ImportError(csv_const.ERR_PANDAS_MISSING)

        super().__init__(config, logger)
        self.tables: Dict[str, Any] = {}  # Cache: {table_name: DataFrame}
        self.schemas: Dict[str, Dict] = {}  # Schema: {table_name: schema_dict}

    # ============================================================
    # Connection Management
    # ============================================================

    def connect(self) -> bool:
        """Establish CSV backend connection by ensuring base directory exists."""
        try:
            file_ops.ensure_directory(self.base_path)
            self.connection = True
            return True
        except Exception as e:
            self._log('error', csv_const.ERR_DIR_CREATE_FAILED, e)
            raise

    def disconnect(self) -> None:
        """Disconnect from CSV backend by flushing all cached tables to disk."""
        if self.tables:
            for table_name, df in self.tables.items():
                self._save_table(table_name, df)
            self.tables.clear()
            self._log('info', csv_const.LOG_DISCONNECTED, self.base_path)
        self.connection = None

    def get_cursor(self):
        """Return self as cursor (CSV has no cursor concept)."""
        return self

    # ============================================================
    # DDL Operations (Schema Management)
    # ============================================================

    def create_table(self, table_name: str, schema: Dict[str, Any]) -> None:
        """Create CSV table file with headers based on schema definition."""
        ddl_ops.create_table(
            self.base_path, table_name, schema,
            self.tables, self.schemas, self.logger
        )

    def alter_table(self, table_name: str, changes: Dict[str, Any]) -> None:
        """Alter CSV table structure by adding or dropping columns."""
        ddl_ops.alter_table(
            self.base_path, table_name, changes,
            self.tables, self.schemas, self._load_table, self.logger
        )

    def drop_table(self, table_name: str) -> None:
        """Drop CSV table by deleting the file and clearing cache."""
        ddl_ops.drop_table(
            self.base_path, table_name,
            self.tables, self.schemas, self.logger
        )

    def table_exists(self, table_name: str) -> bool:
        """Check if CSV table exists by verifying file existence."""
        return ddl_ops.table_exists(self.base_path, table_name)

    def list_tables(self) -> List[str]:
        """List all CSV tables in base_path directory."""
        return ddl_ops.list_tables(self.base_path, self.logger)

    def introspect_schema(self, table_name: str) -> Dict[str, Any]:
        """Introspect CSV file to get actual columns and infer types."""
        return ddl_ops.introspect_schema(self.base_path, table_name, self.logger)

    # ============================================================
    # DML Operations (Data Manipulation)
    # ============================================================

    def insert(self, table: str, fields: List[str], values: List[Any]) -> int:
        """Insert a row into CSV table and save to disk."""
        return dml_ops.insert(
            table, fields, values, self.schemas,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def insert_many(self, table: str, rows_data: List[Dict[str, Any]]) -> List[int]:
        """Insert multiple pre-processed rows in a single write pass."""
        return dml_ops.insert_many(
            table, rows_data, self.schemas,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def select(self, table, fields: Optional[List[str]] = None, **kwargs) -> List[Dict[str, Any]]:
        """Select rows from CSV table(s) with WHERE, JOINs, ORDER BY, LIMIT."""
        where = kwargs.get('where')
        joins = kwargs.get('joins')
        order = kwargs.get('order')
        limit = kwargs.get('limit')
        offset = kwargs.get('offset', 0)
        auto_join = kwargs.get('auto_join', False)
        schema = kwargs.get('schema')
        distinct = kwargs.get('distinct', False)

        return dml_ops.select(
            table, fields, where, joins, order, limit, offset,
            auto_join, schema, self._load_table, self.logger, distinct
        )

    def update(self, table: str, fields: List[str], values: List[Any], where: Dict[str, Any]) -> int:
        """Update rows in CSV table matching WHERE condition."""
        return dml_ops.update(
            table, fields, values, where,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def delete(self, table: str, where: Dict[str, Any]) -> int:
        """Delete rows from CSV table matching WHERE condition."""
        return dml_ops.delete(
            table, where,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def truncate(self, table: str) -> int:
        """Truncate CSV table: remove all rows and reset PK auto-increment sequence."""
        return dml_ops.truncate(
            table,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def upsert(self, table: str, fields: List[str], values: List[Any], conflict_fields: List[str]) -> int:
        """Insert or update row with conflict resolution."""
        return dml_ops.upsert(
            table, fields, values, conflict_fields,
            self._load_table, self._save_table, self.tables, self.logger
        )

    def aggregate(
        self,
        table: str,
        function: str,
        field: Optional[str] = None,
        where: Optional[Dict[str, Any]] = None,
        group_by=None,   # Optional[Union[str, List[str]]]
        alias: Optional[str] = None
    ) -> Any:
        """Perform aggregation function on table data using pandas."""
        return dml_ops.aggregate(
            table, function, field, where, group_by,
            self._load_table, self.logger, alias
        )

    # ============================================================
    # Type Mapping
    # ============================================================

    def map_type(self, abstract_type: str) -> str:
        """Map abstract schema type to pandas dtype."""
        return schema_ops.map_abstract_type_to_pandas(abstract_type)

    # ============================================================
    # Transaction Control (No-ops for CSV)
    # ============================================================

    def begin_transaction(self) -> None:
        """Begin transaction (no-op for CSV - no transaction support)."""
        self._log('debug', "CSV adapter: begin_transaction (no-op)")

    def commit(self) -> None:
        """Commit transaction by saving all cached tables to CSV files."""
        for table_name, df in self.tables.items():
            self._save_table(table_name, df)
        self._log('debug', "CSV adapter: commit (saved all tables)")

    def rollback(self) -> None:
        """Rollback transaction by reloading tables from disk (best-effort)."""
        self._log('warning', "CSV adapter: rollback (reloading from disk)")
        self.tables.clear()

    # ============================================================
    # Internal Helpers
    # ============================================================

    def _load_table(self, table_name):
        """Load table from CSV file (with caching)."""
        # Check cache first
        if table_name in self.tables:
            return self.tables[table_name]

        csv_file = file_ops.get_csv_path(self.base_path, table_name)
        df = file_ops.load_table_from_csv(csv_file, logger=self.logger)

        # Apply schema types if available
        if table_name in self.schemas:
            df = schema_ops.apply_schema_types(df, self.schemas[table_name], self.logger)

        # Cache for reuse
        self.tables[table_name] = df

        return df

    def _save_table(self, table_name, df):
        """Save DataFrame to CSV file."""
        csv_file = file_ops.get_csv_path(self.base_path, table_name)
        file_ops.save_table_to_csv(csv_file, df, self.logger)

    def get_connection_info(self):
        """Get connection information for CSV adapter."""
        return {
            "adapter": "CSVAdapter",
            "connected": self.is_connected(),
            "path": str(self.base_path),
            "tables_cached": len(self.tables),
            "tables_available": len(self.list_tables()) if self.base_path.exists() else 0,
        }
