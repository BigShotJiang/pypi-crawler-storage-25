# zOS/core/L3_Abstraction/n_zData/zData_modules/shared/backends/csv_helpers/ddl_operations.py
"""
DDL (Data Definition Language) operations for CSV adapter.

This module handles table creation, alteration, dropping, and schema introspection.
"""

from zOS import Dict, Any, List, Path
import pandas as pd

from . import constants as csv_const
from . import file_operations as file_ops
from . import schema_operations as schema_ops


def create_table(
    base_path: Path,
    table_name: str,
    schema: Dict[str, Any],
    tables_cache: Dict[str, pd.DataFrame],
    schemas_cache: Dict[str, Dict],
    logger: Any = None
) -> None:
    """
    Create CSV table file with headers based on schema definition.
    
    Args:
        base_path: Base directory for CSV files
        table_name: Name of the table
        schema: Schema dict with field definitions
        tables_cache: Cache dict to store DataFrame
        schemas_cache: Cache dict to store schema
        logger: Optional logger
    """
    if logger:
        logger.info("Creating CSV table: %s", table_name)

    columns, normalized_schema = schema_ops.parse_schema_columns(schema)
    schemas_cache[table_name] = normalized_schema

    df = pd.DataFrame(columns=columns)
    csv_file = file_ops.get_csv_path(base_path, table_name)
    file_ops.save_table_to_csv(csv_file, df, logger)
    tables_cache[table_name] = df

    if logger:
        logger.info(csv_const.LOG_TABLE_CREATED, csv_file)


def alter_table(
    base_path: Path,
    table_name: str,
    changes: Dict[str, Any],
    tables_cache: Dict[str, pd.DataFrame],
    _schemas_cache: Dict[str, Dict],
    load_table_func,
    logger: Any = None
) -> None:
    """
    Alter CSV table structure by adding or dropping columns.
    
    Args:
        base_path: Base directory for CSV files
        table_name: Name of the table to alter
        changes: Dict with operations (add_columns, drop_columns)
        tables_cache: Cache dict to update
        _schemas_cache: Schema cache dict (reserved for future use)
        load_table_func: Function to load table if not cached
        logger: Optional logger
    """
    df = load_table_func(table_name)

    if "add_columns" in changes:
        for column_name, column_def in changes["add_columns"].items():
            default = column_def.get(csv_const.COL_DEFAULT, None)
            df[column_name] = default
            if logger:
                logger.info(csv_const.LOG_COLUMN_ADDED, column_name, table_name)

    if "drop_columns" in changes:
        for column_name in changes["drop_columns"]:
            if column_name in df.columns:
                df = df.drop(columns=[column_name])
                if logger:
                    logger.info(csv_const.LOG_COLUMN_DROPPED, column_name, table_name)

    csv_file = file_ops.get_csv_path(base_path, table_name)
    file_ops.save_table_to_csv(csv_file, df, logger)
    tables_cache[table_name] = df

    if logger:
        logger.info(csv_const.LOG_TABLE_ALTERED, table_name)


def drop_table(
    base_path: Path,
    table_name: str,
    tables_cache: Dict[str, pd.DataFrame],
    schemas_cache: Dict[str, Dict],
    logger: Any = None
) -> None:
    """
    Drop CSV table by deleting the file and clearing cache.
    
    Args:
        base_path: Base directory for CSV files
        table_name: Name of the table to drop
        tables_cache: Cache dict to clear
        schemas_cache: Schema cache dict to clear
        logger: Optional logger
    """
    csv_file = file_ops.get_csv_path(base_path, table_name)
    if csv_file.exists():
        csv_file.unlink()
        if logger:
            logger.info(csv_const.LOG_TABLE_DROPPED, table_name)

    if table_name in tables_cache:
        del tables_cache[table_name]
    if table_name in schemas_cache:
        del schemas_cache[table_name]


def table_exists(base_path: Path, table_name: str) -> bool:
    """
    Check if CSV table exists by verifying file existence.
    
    Args:
        base_path: Base directory for CSV files
        table_name: Name of the table to check
    
    Returns:
        bool: True if CSV file exists
    """
    csv_file = file_ops.get_csv_path(base_path, table_name)
    return csv_file.exists()


def list_tables(base_path: Path, logger: Any = None) -> List[str]:
    """
    List all CSV tables in base_path directory.
    
    Args:
        base_path: Base directory for CSV files
        logger: Optional logger
    
    Returns:
        List[str]: List of table names (without .csv extension)
    """
    csv_files = list(base_path.glob(csv_const.CSV_GLOB_PATTERN))
    tables = [f.stem for f in csv_files]
    if logger:
        logger.debug(csv_const.LOG_FOUND_TABLES, len(tables), tables)
    return tables


def introspect_schema(base_path: Path, table_name: str, logger: Any = None) -> Dict[str, Any]:
    """
    Introspect CSV file to get actual columns and infer types.
    
    Args:
        base_path: Base directory for CSV files
        table_name: Name of the table to introspect
        logger: Optional logger
    
    Returns:
        Dict[str, Any]: Schema dict in zCLI format
    """
    csv_file = file_ops.get_csv_path(base_path, table_name)

    if not csv_file.exists():
        if logger:
            logger.warning(f"Cannot introspect non-existent table: {table_name}")
        return {}

    try:
        # Read just header + 10 rows for type inference
        df = pd.read_csv(csv_file, nrows=10)
        schema = schema_ops.introspect_dataframe_schema(df)

        if logger:
            logger.debug(f"Introspected schema for {table_name}: {len(schema)} columns")

        return schema

    except Exception as e:
        if logger:
            logger.error(f"Failed to introspect table {table_name}: {e}")
        return {}
