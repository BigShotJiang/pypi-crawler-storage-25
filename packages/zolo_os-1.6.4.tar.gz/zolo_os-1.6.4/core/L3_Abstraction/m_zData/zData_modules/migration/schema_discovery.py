# zOS/core/L3_Abstraction/n_zData/zData_modules/migration/schema_discovery.py
"""
SchemaDiscovery - Automatic schema discovery from environment.

Handles schema discovery operations including:
- Scanning ZDATA_*_URL environment variables
- Loading schemas via zLoader
- Filtering by zMigration flag
- Providing schema metadata

Architecture:
    - Scans zConfig.environment.env for ZDATA_* vars
    - Constructs schema paths following convention
    - Loads schemas via zLoader
    - Returns metadata for migration operations
"""

from zOS import Any, Dict, List, Optional, os

# Module Constants
_LOG_PREFIX = "[SchemaDiscovery]"
_META_KEY = "zMeta"
_META_KEY_DATA_TYPE = "Data_Type"
_META_KEY_ZMIGRATION = "zMigration"
_META_KEY_ZMIGRATION_VERSION = "zMigrationVersion"


class SchemaDiscovery:
    """
    Discovers schemas from environment variables.
    
    Responsibilities:
        - Scan ZDATA_*_URL environment variables
        - Load schemas via zLoader
        - Extract metadata for migration
        - Filter by zMigration flag
    
    Attributes:
        zos: zOS framework instance
        logger: Logger instance
    """

    def __init__(self, zos: Any, logger: Any) -> None:
        """
        Initialize SchemaDiscovery.
        
        Args:
            zos: zOS framework instance
            logger: Logger instance
        """
        self.zos = zos
        self.logger = logger

    def discover_schemas(self) -> List[Dict[str, Any]]:
        """
        Discover all schemas with zMigration enabled.
        
        Returns:
            List of discovered schemas with metadata
        """
        schemas = []

        # Get environment from zOS (includes .zEnv)
        env = self.zos.config.environment.env

        # Fallback to os.environ if no ZDATA vars
        if not any(k.startswith('ZDATA_') for k in env.keys()):
            env = os.environ
            self.logger.debug(f"{_LOG_PREFIX} Using os.environ as fallback for ZDATA_* vars")

        # Scan for ZDATA_*_URL variables
        for key, _ in env.items():
            if key.startswith('ZDATA_') and key.endswith('_URL'):
                # Extract schema name (e.g., ZDATA_USERS_URL → users)
                schema_name_upper = key[6:-4]  # Remove ZDATA_ prefix and _URL suffix
                schema_name = schema_name_upper.lower()

                try:
                    # Construct schema path following convention
                    schema_path = f"@.models.zSchema.{schema_name}"

                    # Load schema via zLoader
                    schema = self.zos.loader.handle(schema_path)

                    if not schema:
                        self.logger.warning(f"{_LOG_PREFIX} Failed to load schema: {schema_path}")
                        continue

                    # Extract metadata
                    meta = schema.get(_META_KEY, {})
                    data_type = meta.get(_META_KEY_DATA_TYPE, 'unknown')
                    migration_enabled = meta.get(_META_KEY_ZMIGRATION, True)  # Default True
                    version = meta.get(_META_KEY_ZMIGRATION_VERSION, 'none')

                    schemas.append({
                        'name': f"zSchema.{schema_name}",
                        'env_var': key,
                        'data_type': data_type,
                        'version': version,
                        'migration_enabled': migration_enabled,
                        'schema': schema
                    })

                    self.logger.debug(
                        f"{_LOG_PREFIX} Discovered: {schema_name} "
                        f"(v{version}, {data_type}, migration={migration_enabled})"
                    )

                except Exception as e:
                    self.logger.warning(
                        f"{_LOG_PREFIX} Error loading schema for {key}: {e}"
                    )
                    continue

        self.logger.info(
            f"{_LOG_PREFIX} Found {len(schemas)} schema(s), "
            f"{sum(1 for s in schemas if s['migration_enabled'])} migration-enabled"
        )

        return schemas

    def migrate_app(
        self,
        orchestrator: Any,
        _app_file: Optional[str] = None,
        auto_approve: bool = False,
        dry_run: bool = False,
        specific_schema: Optional[str] = None,
        force_version: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute migrations for all schemas in an application.
        
        Args:
            orchestrator: DataOrchestrator instance
            _app_file: Optional app file path (for display only, unused)
            auto_approve: If True, skip confirmation prompts
            dry_run: If True, preview changes without executing
            specific_schema: If provided, migrate only this schema
            force_version: If provided, force this version for all migrations
            
        Returns:
            Dict with success, failed, skipped, up_to_date, total, schemas
        """
        results = {
            'success': 0,
            'failed': 0,
            'skipped': 0,
            'up_to_date': 0,
            'total': 0,
            'schemas': []
        }

        # Discover all schemas
        discovered_schemas = self.discover_schemas()

        if not discovered_schemas:
            self.logger.warning(f"{_LOG_PREFIX} No schemas found with ZDATA_*_URL environment variables")
            return results

        # Filter by zMigration: true
        migration_enabled_schemas = [s for s in discovered_schemas if s['migration_enabled']]

        if not migration_enabled_schemas:
            results['skipped'] = len(discovered_schemas)
            results['total'] = len(discovered_schemas)
            self.logger.info(f"{_LOG_PREFIX} No schemas enabled for migration (zMigration: false)")
            return results

        # Filter by specific_schema if provided
        if specific_schema:
            migration_enabled_schemas = [
                s for s in migration_enabled_schemas
                if s['name'].split('.')[-1].lower() == specific_schema.lower()
            ]
            if not migration_enabled_schemas:
                self.logger.warning(f"{_LOG_PREFIX} Schema '{specific_schema}' not found or not migration-enabled")
                return results

        results['total'] = len(migration_enabled_schemas)
        results['skipped'] = len(discovered_schemas) - len(migration_enabled_schemas)

        self.logger.info(f"{_LOG_PREFIX} Migrating {len(migration_enabled_schemas)} schema(s)")

        # Migrate each schema
        from .migration_engine import MigrationEngine
        migration_engine = MigrationEngine(self.zos, self.logger)

        for schema_info in migration_enabled_schemas:
            schema_name = schema_info['name']
            schema_path = f"@.models.{schema_name}"
            current_version = schema_info['version']

            # Use force_version if provided
            target_version = (
                force_version if force_version
                else (current_version if current_version != 'none' else None)
            )

            self.logger.info(f"{_LOG_PREFIX} Migrating {schema_name} (v{current_version})")

            try:
                migration_result = migration_engine.migrate(
                    orchestrator=orchestrator,
                    new_schema_path=schema_path,
                    auto_approve=auto_approve,
                    dry_run=dry_run,
                    schema_version=target_version
                )

                # Track results
                schema_result = {
                    'name': schema_name,
                    'version': current_version,
                    'result': migration_result
                }

                if migration_result.get('success'):
                    ops_executed = migration_result.get('operations_executed', 0)
                    if ops_executed == 0:
                        results['up_to_date'] += 1
                        schema_result['status'] = 'up_to_date'
                        self.logger.info(f"{_LOG_PREFIX} {schema_name}: Up to date (no changes)")
                    else:
                        results['success'] += 1
                        schema_result['status'] = 'success'
                        self.logger.info(f"{_LOG_PREFIX} {schema_name}: Success ({ops_executed} operation(s))")
                else:
                    results['failed'] += 1
                    schema_result['status'] = 'failed'
                    error = migration_result.get('error', 'Unknown error')
                    self.logger.error(f"{_LOG_PREFIX} {schema_name}: Failed - {error}")

                results['schemas'].append(schema_result)

            except Exception as e:
                results['failed'] += 1
                schema_result = {
                    'name': schema_name,
                    'version': current_version,
                    'status': 'failed',
                    'result': {'success': False, 'error': str(e)}
                }
                results['schemas'].append(schema_result)
                self.logger.error(f"{_LOG_PREFIX} {schema_name}: Exception - {e}", exc_info=True)

        # Log summary
        self.logger.info(
            f"{_LOG_PREFIX} Complete: {results['success']} success, "
            f"{results['failed']} failed, {results['up_to_date']} up-to-date, "
            f"{results['skipped']} skipped"
        )

        return results
