# zOS/core/L3_Abstraction/l_zWizard/__init__.py
"""
zWizard shim — public zOS repo.

Source lives in the private zguard.wizard package (binary wheel via zGuard).
This file re-exports the public API so all existing zOS imports remain unchanged.

Public users (no zGuard): a clear ZGuardRequired error is raised on first use.
"""

try:
    from zguard.wizard import zWizard  # noqa: F401
    from zguard.wizard.zWizard_modules import (  # noqa: F401
        SUBSYSTEM_NAME,
        SUBSYSTEM_COLOR,
        NAVIGATION_SIGNALS,
    )
    _ZGUARD_AVAILABLE = True
except ImportError:
    _ZGUARD_AVAILABLE = False

    class zWizard:  # noqa: N801
        """Placeholder raised when zGuard is not installed."""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "zWizard runtime unavailable (Python ABI mismatch or missing zguard).\n"
                "Fix: z patch\n"
                "Docs: https://zolo.media"
            )

    SUBSYSTEM_NAME = "zWizard"
    SUBSYSTEM_COLOR = "white"
    NAVIGATION_SIGNALS: list = []

__all__ = ["zWizard", "SUBSYSTEM_NAME", "SUBSYSTEM_COLOR", "NAVIGATION_SIGNALS"]
