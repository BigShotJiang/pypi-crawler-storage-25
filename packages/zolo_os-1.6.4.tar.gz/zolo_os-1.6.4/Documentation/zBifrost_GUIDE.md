**[← Back to zData Guide](zData_GUIDE.md) | [Home](../README.md) | [Next: zShell Guide →](zShell_GUIDE.md)**

---

# zBifrost

**zBifrost** is a **Layer 2 subsystem** initialized by **zOS** (Orchestration Layer).
> See [**zArchitecture**](../README.md#the-zarchitecture) for full context.

It orchestrates Terminal↔Web communication by coordinating zOS subsystems - transforming terminal applications into real-time web GUIs through declarative WebSocket infrastructure.

You get:

- **Zero WebSocket boilerplate**  
- **No manual event routing**
- **No authentication wiring**  
- **Three-tier authentication** (zSession, Application, Dual)
- **Real-time display sync** (Terminal↔Web)
- **CRUD operation bridge** (Web UI→zData)  
- **Cache management** (Client-side state)
- **Connection lifecycle** (Auto-reconnect, monitoring)

> **Note:** zBifrost is a **Layer 2 orchestrator** that uses Layer 0 primitives (zComm WebSocket) to coordinate Layer 1 subsystems (zDisplay, zAuth, zData). For raw WebSocket primitives, see [zComm Guide](zComm_GUIDE.md).

## Architecture Overview

**zBifrost** orchestrates Terminal↔Web communication by composing specialized modules:

| Module | Purpose | Guide |
|--------|---------|-------|
| **orchestrator** | WebSocket bridge lifecycle and coordination | [connection_GUIDE.md](zBifrost_Guides/connection_GUIDE.md) |
| **ws_server** | WebSocket server wrapper (uses zComm primitives) | [connection_GUIDE.md](zBifrost_Guides/connection_GUIDE.md) |
| **bridge_connection** | Client connection tracking and management | [connection_GUIDE.md](zBifrost_Guides/connection_GUIDE.md) |
| **auth** | Three-tier authentication manager | [authentication_GUIDE.md](zBifrost_Guides/authentication_GUIDE.md) |
| **cache** | Client-side state caching (session, users, data) | [caching_GUIDE.md](zBifrost_Guides/caching_GUIDE.md) |
| **message_handler** | Incoming message routing and dispatch | [events_GUIDE.md](zBifrost_Guides/events_GUIDE.md) |
| **message_walker** | Walker-specific message coordination | [events_GUIDE.md](zBifrost_Guides/events_GUIDE.md) |
| **events/** | Event dispatching (display, client, cache, discovery, menu) | [events_GUIDE.md](zBifrost_Guides/events_GUIDE.md) |
| **server/** | Server lifecycle, client handling, message routing, broadcasting | [connection_GUIDE.md](zBifrost_Guides/connection_GUIDE.md) |
| **monitoring** | Health checks and connection monitoring | [monitoring_GUIDE.md](zBifrost_Guides/monitoring_GUIDE.md) |
| **bifrost_constants** | Shared constants and configuration | [connection_GUIDE.md](zBifrost_Guides/connection_GUIDE.md) |

This guide provides a **facade overview** of zBifrost. For deep dives into specific modules, see the guides in `zBifrost_Guides/`.

---

## What's in This Guide

This guide covers the **main zBifrost facade** - the unified orchestrator interface for Terminal↔Web communication. Following the zConfig/zComm patterns:

1. **Architecture Overview** - Module structure and orchestration patterns
2. **Initialization** - How zBifrost auto-initializes in Layer 2
3. **Tutorials** - Hands-on demos (Level 0-4) for learning by doing
4. **API Reference** - Complete method signatures and usage patterns
5. **Advanced Features** - Three-tier auth, caching, event routing, monitoring

**What's NOT in this guide:**
- Deep dives into individual modules (see `zBifrost_Guides/` folder)
- Raw WebSocket primitives (see [zComm Guide](zComm_GUIDE.md))
- HTTP server setup (see [zServer Guide](zServer_GUIDE.md))
- Terminal rendering (see [zDisplay Guide](zDisplay_GUIDE.md))

**Current Implementation Status:**
- ✅ WebSocket Bridge Orchestration (start, broadcast, lifecycle)
- ✅ Three-Tier Authentication (zSession, Application, Dual)
- ✅ Cache Management (session, users, applications, data)
- ✅ Event Routing (display, client, cache, discovery, menu)
- ✅ Message Handling (incoming message dispatch)
- ✅ Connection Monitoring (health checks, client tracking)
- ✅ Server Lifecycle (start, shutdown, auto-start)

---

## Initialization Order

When you call `zOS()`, zBifrost initializes automatically in Layer 2 after zData:

1. **Layer 0 Ready** - zConfig, zComm initialized
2. **Layer 1 Ready** - zDisplay, zAuth, zDispatch initialized
3. **Layer 2 - zData Ready** - Data management initialized
4. **zBifrost Initialization** - Bridge orchestrator starts:
   - Validate zOS instance (requires comm, display, auth, data, logger, session)
   - Create BridgeOrchestrator
   - Auto-start if `zMode: "zBifrost"` in zSpark
   - Print ready message (Layer 2)
   - Log ready state
5. **zBifrost Ready** - Terminal↔Web bridge available

This order ensures zBifrost has access to all required subsystems before orchestrating communication.

**Auto-Initialization:**
```python
from zOS import zOS

# Default mode (zCLI) - bridge dormant until manually started
z = zOS()
z.bifrost.start()  # Explicit start required

# zBifrost mode - bridge auto-starts
z = zOS({"zMode": "zBifrost"})  # Auto-starts on initialization

# zBifrost is now ready:
z.bifrost.broadcast({...})          # Broadcast to all clients
z.bifrost.health_check()            # Check bridge status
z.bifrost.get_connected_clients()   # List connected clients
```

---

## Tutorials

**Learn by doing!** 

The tutorials below are organized in a bottom-up fashion. Every tutorial has a working demo you can run and modify.

**A Note on Learning zOS:**  
Each tutorial (lvl0, lvl1, lvl2...) progressively introduces more complex features of **this subsystem**. By now, you've completed Layers 0-1, so you understand the imperative-to-declarative shift. In zBifrost, you'll see **full orchestration** - coordinating multiple subsystems declaratively for real-time Terminal↔Web communication.

Get the demos:

```bash
# Clone only the Demos folder
git clone --depth 1 --filter=blob:none --sparse https://github.com/ZoloAi/zolo-zcli.git
cd zolo-zcli
git sparse-checkout set Demos
```

> All zBifrost demos are in: `Demos/Layer_2/zBifrost_Demo/`

---

# **zBifrost - Level 0** (Hello zBifrost)

### **i. Manual Bridge Start (zCLI Mode)**

In previous guides (zComm, zDisplay), you used `zOS()` with default settings. By default, zOS runs in **zCLI mode** - the bridge stays dormant until you explicitly start it.

```python
from zOS import zOS

# Default initialization (zCLI mode)
zSpark = {
    "deployment": "Development",  # Show subsystem banners
    "title": "hello-bifrost",
    "logger": "INFO",
    "logger_path": "./logs",
}

# Watch the initialization order in output:
# [zConfig Ready] → [zComm Ready] → [zDisplay Ready] → [zAuth Ready] → [zData Ready] → [zBifrost Ready]

z = zOS(zSpark)

# Bridge is ready but dormant - start explicitly
z.bifrost.start()  # Starts WebSocket bridge with zDisplay sync
```

**Key Discovery**: In zCLI mode, zBifrost initializes but doesn't auto-start. You control when the WebSocket bridge activates.

**🎯 Try it yourself:**

Run the demo to see manual bridge start:

```bash
python3 Demos/Layer_2/zBifrost_Demo/lvl0_hello/1_manual_start.py
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl0_hello/1_manual_start.py)

**What you'll discover:**
- Watch initialization order: Layer 0 → Layer 1 → Layer 2
- zBifrost initializes but stays dormant
- Explicit `start()` activates WebSocket bridge
- Ctrl+C gracefully shuts down (like zComm)

---

### **ii. Auto-Start Bridge (zBifrost Mode)**

In the previous demo, you manually started the bridge with `z.bifrost.start()`. But what if you want the bridge to start automatically during initialization?

**Enter zBifrost mode** - set `zMode: "zBifrost"` in zSpark:

```python
from zOS import zOS

# zBifrost mode - auto-start bridge
zSpark = {
    "deployment": "Development",
    "title": "auto-bifrost",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",  # Auto-start WebSocket bridge
}

z = zOS(zSpark)

# Bridge is already running!
# No z.bifrost.start() needed

# Check bridge status
status = z.bifrost.health_check()
print(f"Bridge running: {status.get('running')}")
```

**What's the difference?**

| zMode | Behavior | Use Case |
|-------|----------|----------|
| **zCLI** (default) | Bridge dormant until `z.bifrost.start()` | Terminal-only apps, manual control |
| **zBifrost** | Bridge auto-starts on initialization | Web-first apps, declarative setup |

**🎯 Try it yourself:**

Run the demo to see auto-start:

```bash
python3 Demos/Layer_2/zBifrost_Demo/lvl0_hello/2_auto_start.py
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl0_hello/2_auto_start.py)

**What you'll discover:**
- Set `zMode: "zBifrost"` for auto-start
- Bridge starts during initialization (no manual `start()` call)
- Check bridge status with `health_check()`
- WebSocket server ready immediately

---

**🎯 Level 0 Complete!**

You've learned the two initialization modes:
- ✅ **zCLI mode**: Bridge dormant, manual start with `z.bifrost.start()`
- ✅ **zBifrost mode**: Bridge auto-starts with `zMode: "zBifrost"`

---

# **zBifrost - Level 1** (Display Synchronization)

### **i. Terminal→Web Display Sync**

Now that you know how to start the bridge, let's see the **magic** - terminal rendering automatically synchronized to web clients!

Remember from zDisplay guide? When you render in the terminal:

```python
z.display.header("Welcome to zBifrost")
z.display.text("This text appears in terminal...")
```

**With zBifrost running**, that same rendering **automatically broadcasts to all connected web clients** - no extra code needed!

**Server (Python):**

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "display-sync",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",  # Auto-start bridge
}

z = zOS(zSpark)

# Render in terminal
z.display.header("Terminal↔Web Sync Demo")
z.display.text("This text appears in BOTH terminal AND web browser!")
z.display.success("✅ Display events synchronized automatically")

# Keep server running
input("Press Enter to stop...")
```

**Client (JavaScript):**

```javascript
// Connect to WebSocket bridge
const ws = new WebSocket('ws://127.0.0.1:56891');

// Receive display events
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('Display event received:', data);
    
    // Render in browser (zDisplay web component handles this)
    renderDisplayEvent(data);
};
```

**What happens:**
1. Python renders with `z.display.*` methods
2. zBifrost intercepts display events (via zComm.websocket_events)
3. Events broadcast to all connected web clients automatically
4. Web clients render the same UI in browser

**🎯 Try it yourself:**

```bash
# Step 1: Start the Python server
python3 Demos/Layer_2/zBifrost_Demo/lvl1_display/1_display_sync.py

# Step 2: Open the HTML client
open Demos/Layer_2/zBifrost_Demo/lvl1_display/1_client.html
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl1_display/1_display_sync.py) | [View client →](../Demos/Layer_2/zBifrost_Demo/lvl1_display/1_client.html)

**What you'll discover:**
- Terminal rendering automatically syncs to web
- No manual WebSocket event sending
- zBifrost orchestrates zDisplay + zComm
- Same display code works in both terminal and web

---

### **ii. Bidirectional Sync (Web→Terminal)**

In Level 1.i, you saw Terminal→Web sync (Python `z.display.*` → Browser). Now let's go the other direction: **Web→Terminal**.

When users interact with the web UI (click buttons, submit forms, etc.), those actions send messages back to Python through zBifrost.

**Server (Python):**

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "bidirectional-sync",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Define handler for incoming messages from web
async def handle_client_message(websocket, message):
    """Process messages from web client."""
    import json
    data = json.loads(message)
    
    action = data.get('action')
    if action == 'button_click':
        button_id = data.get('button_id')
        z.display.success(f"Button clicked in web: {button_id}")
        
        # Send response back to web
        await websocket.send(json.dumps({
            'event': 'action_response',
            'message': f'Processed {button_id}'
        }))

# Register handler (zBifrost routes messages to your handler)
z.bifrost.websocket.handler = handle_client_message

# Keep server running
input("Press Enter to stop...")
```

**Client (JavaScript):**

```javascript
const ws = new WebSocket('ws://127.0.0.1:56891');

// Send button click to Python
function onButtonClick(buttonId) {
    ws.send(JSON.stringify({
        action: 'button_click',
        button_id: buttonId
    }));
}

// Receive response from Python
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'action_response') {
        console.log('Python response:', data.message);
    }
};
```

**🎯 Try it yourself:**

```bash
# Step 1: Start the Python server
python3 Demos/Layer_2/zBifrost_Demo/lvl1_display/2_bidirectional.py

# Step 2: Open the HTML client
open Demos/Layer_2/zBifrost_Demo/lvl1_display/2_client.html
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl1_display/2_bidirectional.py) | [View client →](../Demos/Layer_2/zBifrost_Demo/lvl1_display/2_client.html)

**What you'll discover:**
- Handle incoming messages from web clients
- Bidirectional communication (Terminal↔Web both directions)
- Custom message handlers for UI actions
- Response loop: Web→Python→Web

---

**🎯 Level 1 Complete!**

You've mastered display synchronization:
- ✅ **Terminal→Web**: Display events auto-broadcast to browsers
- ✅ **Web→Terminal**: Handle client actions in Python

---

# **zBifrost - Level 2** (Authentication)

> **Note:** This level covers **three-tier authentication** - zBifrost's advanced authentication system that coordinates with zAuth subsystem. For raw token authentication, see [zComm WebSocket Guide](zComm_GUIDE.md).

### **i. zSession Authentication (Internal)**

In Level 1, any client could connect - no authentication required. Now let's add **Layer 1 auth: zSession** (internal zCLI users).

**zSession Auth** is for internal connections - when your Python terminal app connects to its own WebSocket bridge. No token required, authenticated via session ID.

**Server (Python):**

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "zsession-auth",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,  # Enable authentication
        "auth_tier": "zsession",  # Layer 1: zSession auth
    }
}

z = zOS(zSpark)

# Bridge starts with zSession auth enabled
# Only clients with valid session token can connect

input("Press Enter to stop...")
```

**Client (JavaScript):**

```javascript
// Get session token from server (auto-generated by zOS)
const sessionToken = 'your_session_token';  // From z.session.get('zS_id')

// Connect with session token
const ws = new WebSocket(`ws://127.0.0.1:56891?token=${sessionToken}`);

ws.onopen = () => {
    console.log('✅ Connected with zSession auth');
};

ws.onclose = (event) => {
    if (event.code === 1008) {
        console.log('❌ Authentication failed');
    }
};
```

**🎯 Try it yourself:**

```bash
# Step 1: Start the Python server (note the session token in output)
python3 Demos/Layer_2/zBifrost_Demo/lvl2_auth/1_zsession.py

# Step 2: Open the HTML client (paste session token from server output)
open Demos/Layer_2/zBifrost_Demo/lvl2_auth/1_client.html
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl2_auth/1_zsession.py) | [View client →](../Demos/Layer_2/zBifrost_Demo/lvl2_auth/1_client.html)

**What you'll discover:**
- Enable authentication with `require_auth: True`
- zSession auth for internal connections
- Session token from `z.session.get('zS_id')`
- Unauthorized clients rejected automatically

---

### **ii. Application Authentication (External)**

In Level 2.i, you authenticated **internal** users (zSession). Now let's authenticate **external** users - people using your web app who aren't running Python terminals.

**Application Auth (Layer 2)** validates external users via zAuth integration:

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "app-auth",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",  # Layer 2: Application auth
    }
}

z = zOS(zSpark)

# Register a test user (in production, users come from database)
z.auth.register_user(
    username="alice",
    password="password123",
    role="user"
)

# Generate API key for Alice
api_key = z.auth.generate_api_key("alice")
print(f"Alice's API key: {api_key}")

input("Press Enter to stop...")
```

**Client (JavaScript):**

```javascript
// User logs in (gets API key from server)
const apiKey = 'alice_api_key_from_server';

// Connect with API key
const ws = new WebSocket(`ws://127.0.0.1:56891?api_key=${apiKey}`);

ws.onopen = () => {
    console.log('✅ Connected as application user');
};
```

**🎯 Try it yourself:**

```bash
# Step 1: Start the Python server (note Alice's API key)
python3 Demos/Layer_2/zBifrost_Demo/lvl2_auth/2_application.py

# Step 2: Open the HTML client (paste API key from server output)
open Demos/Layer_2/zBifrost_Demo/lvl2_auth/2_client.html
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl2_auth/2_application.py) | [View client →](../Demos/Layer_2/zBifrost_Demo/lvl2_auth/2_client.html)

**What you'll discover:**
- Application auth with zAuth integration
- User registration and API key generation
- External user authentication (not zSession)
- API key passed as query parameter

---

### **iii. Dual Authentication (Both Layers)**

In Levels 2.i-ii, you used either zSession OR Application auth. But what if you want **both simultaneously**?

**Dual Auth (Layer 3)** combines both authentication layers:
- Internal users connect with zSession token
- External users connect with API key
- Both authenticated simultaneously on the same bridge

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "dual-auth",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,
        "auth_tier": "dual",  # Layer 3: Both zSession + Application
    }
}

z = zOS(zSpark)

# Register application users
alice_key = z.auth.generate_api_key("alice")

# Now both work:
# - Internal: ws://...?token=<session_token>
# - External: ws://...?api_key=<alice_key>

input("Press Enter to stop...")
```

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_2/zBifrost_Demo/lvl2_auth/3_dual.py
```

[View demo source →](../Demos/Layer_2/zBifrost_Demo/lvl2_auth/3_dual.py)

**What you'll discover:**
- Dual authentication supports both auth types
- Internal and external users on same bridge
- Query params: `?token=` or `?api_key=`
- Three-tier architecture complete

---

**🎯 Level 2 Complete!**

You've mastered three-tier authentication:
- ✅ **Layer 1 (zSession)**: Internal users via session token
- ✅ **Layer 2 (Application)**: External users via API key  
- ✅ **Layer 3 (Dual)**: Both authentication types simultaneously

---

# **zBifrost - Level 3** (Caching & State)

### **i. Session Cache**

zBifrost maintains client-side caches automatically. The **session cache** stores your zOS session info (session ID, mode, logger, etc.) and broadcasts it to all connected clients.

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "session-cache",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Session cache populated automatically
cache_status = z.bifrost.get_cache_status()
print(f"Session cached: {cache_status['session']['cached']}")

# Clients receive session data on connect
input("Press Enter to stop...")
```

**Client receives:**
```javascript
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'cache_update' && data.cache_type === 'session') {
        console.log('Session data:', data.payload);
        // { zS_id: "...", zMode: "zBifrost", zLogger: "INFO", ... }
    }
};
```

**What you'll discover:**
- Session cache auto-populated on bridge start
- Clients receive session data on connection
- Cache updates broadcast automatically
- Access cache status with `get_cache_status()`

---

### **ii. Users Cache**

When using Application or Dual auth, zBifrost caches authenticated user info from zAuth:

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "users-cache",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",
    }
}

z = zOS(zSpark)

# Register users (automatically cached)
z.auth.register_user("alice", "pass123", role="admin")
z.auth.register_user("bob", "pass456", role="user")

# Users cache populated from zAuth
cache_status = z.bifrost.get_cache_status()
print(f"Users cached: {cache_status['users']['count']}")

input("Press Enter to stop...")
```

**Client receives:**
```javascript
// After authentication
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'cache_update' && data.cache_type === 'users') {
        console.log('Users:', data.payload);
        // [{ username: "alice", role: "admin" }, { username: "bob", role: "user" }]
    }
};
```

**What you'll discover:**
- Users cache syncs with zAuth automatically
- New registrations broadcast to clients
- Role-based access control data available
- Multi-user support out of the box

---

### **iii. Data Cache (CRUD Bridge)**

The data cache bridges zData CRUD operations to web clients:

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "data-cache",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# CRUD operations automatically cached and broadcast
z.data.create("tasks", {"id": 1, "title": "Learn zBifrost", "done": False})
z.data.create("tasks", {"id": 2, "title": "Build app", "done": False})

# Clients receive data updates
cache_status = z.bifrost.get_cache_status()
print(f"Data models cached: {cache_status['data']['models']}")

input("Press Enter to stop...")
```

**Client receives:**
```javascript
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'cache_update' && data.cache_type === 'data') {
        console.log('Data:', data.payload);
        // { tasks: [{ id: 1, title: "...", done: false }, ...] }
    }
};
```

**Web→Python CRUD:**
```javascript
// Client sends CRUD operation
ws.send(JSON.stringify({
    action: 'data_create',
    model: 'tasks',
    payload: { id: 3, title: 'New task', done: false }
}));

// Server processes via zData automatically
// Result broadcasts to all clients
```

**What you'll discover:**
- CRUD operations automatically synchronized
- Web clients can create/read/update/delete data
- Changes broadcast to all connected clients
- zData integration seamless

---

**🎯 Level 3 Complete!**

You've mastered client-side caching:
- ✅ **Session cache**: Session info synchronized
- ✅ **Users cache**: Authenticated users from zAuth
- ✅ **Data cache**: CRUD operations from zData

---

# **zBifrost - Level 4** (Advanced Orchestration)

### **i. Health Monitoring**

Monitor bridge health and connection status:

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "health-monitoring",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Check bridge health
status = z.bifrost.health_check()
print(f"Running: {status['running']}")
print(f"Clients: {status['clients_connected']}")
print(f"Port: {status['port']}")

# Get connected clients
clients = z.bifrost.get_connected_clients()
for client in clients:
    print(f"Client: {client['address']}, Auth: {client['authenticated']}")

input("Press Enter to stop...")
```

**What you'll discover:**
- Check bridge running state
- Count connected clients
- Get client connection details
- Monitor authentication status per client

---

### **ii. Custom Event Routing**

Create custom event types and route them through zBifrost:

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "custom-events",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Broadcast custom event
z.bifrost.broadcast({
    'event': 'custom_notification',
    'type': 'info',
    'message': 'System maintenance in 5 minutes',
    'timestamp': 1234567890
})

input("Press Enter to stop...")
```

**Client receives:**
```javascript
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'custom_notification') {
        showNotification(data.message, data.type);
    }
};
```

**What you'll discover:**
- Broadcast custom events beyond display/data
- Define your own event schema
- Route custom messages to clients
- Extend zBifrost for app-specific needs

---

**🎯 Level 4 Complete!**

You've completed the entire zBifrost tutorial journey:
- ✅ **Level 0**: Initialization (manual/auto-start)
- ✅ **Level 1**: Display synchronization (Terminal↔Web)
- ✅ **Level 2**: Three-tier authentication (zSession, Application, Dual)
- ✅ **Level 3**: Caching & state (session, users, data)
- ✅ **Level 4**: Advanced orchestration (monitoring, custom events)

**You now understand the complete zBifrost subsystem for Terminal↔Web orchestration!**

---

## Module Structure

zBifrost follows a modular orchestration architecture:

**Core Modules:**
- `zBifrost.py` - Main facade class providing unified interface
- `__init__.py` - Package exports and public API

**Orchestration:**
- `orchestrator.py` - BridgeOrchestrator for lifecycle management
- `ws_server.py` - WebSocket server wrapper (delegates to zComm)
- `bridge_connection.py` - Client connection tracking

**Authentication:**
- `auth.py` - AuthenticationManager for three-tier auth

**State Management:**
- `cache.py` - CacheManager for session/users/data caching

**Message Handling:**
- `message_handler.py` - Incoming message router
- `message_walker.py` - Walker-specific coordination
- `message_utils.py` - Message utilities
- `message_walker_support.py` - Walker support utilities

**Event System:**
- `events/base_event_handler.py` - Base event handler
- `events/bridge_event_dispatch.py` - Display event routing
- `events/bridge_event_client.py` - Client event handling
- `events/bridge_event_cache.py` - Cache event broadcasting
- `events/bridge_event_discovery.py` - Discovery/handshake events
- `events/bridge_event_menu.py` - Menu interaction events

**Server Infrastructure:**
- `server/lifecycle.py` - Server lifecycle management
- `server/client_handler.py` - Per-client connection handling
- `server/message_router.py` - Message routing logic
- `server/broadcaster.py` - Event broadcasting to clients

**Monitoring:**
- `monitoring.py` - Health checks and connection monitoring

**Constants:**
- `bifrost_constants.py` - Shared constants and configuration

**Architecture Pattern:**
zBifrost uses the **Orchestrator pattern** - coordinates multiple subsystems declaratively:
- `z.bifrost.start()` → Orchestrates zComm.websocket + zDisplay + zAuth + zData
- `z.bifrost.broadcast()` → Routes to appropriate clients via connection manager
- `z.bifrost.get_cache_status()` → Queries cache manager state
- `z.bifrost.health_check()` → Monitors bridge and connection health

---

## Layer 2 Design Philosophy

As a **Layer 2 subsystem**, zBifrost orchestrates multiple Layer 0-1 subsystems:

**Orchestration Dependencies:**
- **Layer 0**: Uses zComm for WebSocket infrastructure
- **Layer 1**: Coordinates zDisplay (rendering), zAuth (authentication), zData (CRUD)
- **Layer 2**: Provides complete Terminal↔Web bridge

**Declarative Configuration:**
- Set `zMode: "zBifrost"` for auto-start
- Configure auth tier: `zsession`, `application`, `dual`
- Enable caching: session, users, data
- All via zSpark (no manual wiring)

**Integration Points:**
- **Depends on:** zConfig, zComm, zDisplay, zAuth, zData, zLogger, zSession
- **Used by:** User applications transforming terminal apps to web
- **Provides:** Terminal↔Web orchestration, three-tier auth, CRUD bridge, cache sync

---

## Advanced Features

### Three-Tier Authentication

zBifrost's authentication system has three layers:

**Layer 1: zSession Auth (Internal)**
```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "zsession",
    }
}
```
- For internal zCLI connections
- No token required (session-based)
- Auto-authenticated via `z.session.get('zS_id')`

**Layer 2: Application Auth (External)**
```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",
    }
}
```
- For external web users
- Token-based (API keys from zAuth)
- Integrates with user database

**Layer 3: Dual Auth (Both)**
```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "dual",
    }
}
```
- Supports both internal and external
- Multiple authentication contexts
- Multi-app support

For detailed authentication documentation, see [authentication_GUIDE.md](zBifrost_Guides/authentication_GUIDE.md).

---

### Cache Management

Three cache types synchronized automatically:

**Session Cache:**
- Stores zOS session info
- Broadcasts to clients on connection
- Updates on session changes

**Users Cache:**
- Syncs with zAuth user database
- Role-based access control data
- Real-time user updates

**Data Cache:**
- Bridges zData CRUD operations
- Bidirectional sync (Terminal↔Web)
- Multi-model support

For detailed caching documentation, see [caching_GUIDE.md](zBifrost_Guides/caching_GUIDE.md).

---

### Event System

Five event types routed by zBifrost:

**Display Events:**
- Terminal rendering synchronized to web
- All `z.display.*` methods broadcast
- Uses zComm.websocket_events

**Client Events:**
- Connection/disconnection notifications
- Authentication status changes
- Client metadata updates

**Cache Events:**
- Session/users/data cache updates
- Broadcast to all connected clients
- Incremental sync support

**Discovery Events:**
- Client handshake coordination
- Capability negotiation
- Version compatibility

**Menu Events:**
- Interactive menu coordination
- Walker menu synchronization
- User input routing

For detailed event documentation, see [events_GUIDE.md](zBifrost_Guides/events_GUIDE.md).

---

### Facade API Reference

The `zBifrost` class provides these convenience methods:

**Lifecycle Management:**
```python
# Start bridge (manual mode)
z.bifrost.start(host="127.0.0.1", port=56891)

# Shutdown bridge
z.bifrost.shutdown()

# Check if running
is_running = z.bifrost.is_running()
```

**Broadcasting:**
```python
# Broadcast to all clients
z.bifrost.broadcast({"event": "update", "data": {...}})

# Broadcast to specific clients
z.bifrost.broadcast_to_authenticated({"event": "...", ...})
```

**Connection Management:**
```python
# Get connected clients
clients = z.bifrost.get_connected_clients()
# [{"address": "127.0.0.1:12345", "authenticated": True, ...}, ...]

# Get client count
count = z.bifrost.get_client_count()
```

**Health & Monitoring:**
```python
# Health check
status = z.bifrost.health_check()
# {"running": True, "clients_connected": 2, "port": 56891, ...}

# Get cache status
cache_status = z.bifrost.get_cache_status()
# {"session": {"cached": True}, "users": {"count": 5}, "data": {"models": 3}}
```

**Direct Module Access:**
```python
# Access modules directly
z.bifrost.orchestrator    # BridgeOrchestrator instance
z.bifrost.websocket       # WebSocket server wrapper
z.bifrost.auth            # AuthenticationManager instance
z.bifrost.cache           # CacheManager instance
z.bifrost.monitoring      # Monitoring instance
```

---

## What's Next?

You've mastered **zBifrost** (Layer 2 Terminal↔Web orchestration). Continue to **Layer 3** subsystems:

**→ Continue to [zShell Guide](zShell_GUIDE.md)**

Layer 3 builds on zBifrost's orchestration with:
- **zShell** - Command-line interface and shell integration
- **zWalker** - Interactive menu navigation
- **zServer** - HTTP server for serving web clients
- **zDialog**, **zOpen**, **zWizard** - Advanced UI orchestration

> **Note:** For modular deep dives into zBifrost components, see the guides in `zBifrost_Guides/`:
> - [Authentication Guide](zBifrost_Guides/authentication_GUIDE.md) - Three-tier auth system
> - [Connection Guide](zBifrost_Guides/connection_GUIDE.md) - WebSocket lifecycle & client tracking
> - [Caching Guide](zBifrost_Guides/caching_GUIDE.md) - Session/users/data cache management
> - [Events Guide](zBifrost_Guides/events_GUIDE.md) - Event routing and message handling
> - [Monitoring Guide](zBifrost_Guides/monitoring_GUIDE.md) - Health checks and diagnostics

---

**[← Back to zData Guide](zData_GUIDE.md) | [Home](../README.md) | [Next: zShell Guide →](zShell_GUIDE.md)**
