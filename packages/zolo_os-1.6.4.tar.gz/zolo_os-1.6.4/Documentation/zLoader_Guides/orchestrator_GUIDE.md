# zLoader Cache Orchestrator Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/cache_orchestrator.py`  
> **Purpose:** Unified cache routing to all cache tiers (System, Pinned, Schema, Plugin).

---

## Overview

The `cache_orchestrator` module provides the central orchestration layer for zLoader's caching system. It is composed of one public class exposed via `__init__.py`:

| Class | File | Purpose |
|---|---|---|
| `CacheOrchestrator` | `cache_orchestrator.py` | Unified cache router (routes to Tier 2 caches) |

---

## Architecture: Tier 3 Orchestrator

`CacheOrchestrator` serves as Tier 3 in the zLoader architecture, routing cache requests to appropriate Tier 2 implementations:

```
CacheOrchestrator (Tier 3)
├── SystemCache (Tier 2)        — UI/config files with LRU eviction
├── PinnedCache (Tier 2)        — User aliases with no eviction
├── SchemaCache (Tier 2)        — DB connections + transactions
└── PluginCache (Tier 2)        — Module instances + session injection
```

**Design rationale:** Orchestrator pattern provides single point of control, simplifies facade logic, enables batch operations across all tiers.

---

## `CacheOrchestrator`

### Initialization

```python
from zLoader.loader_modules import CacheOrchestrator

orchestrator = CacheOrchestrator(session, logger, zos=None)
```

| Parameter | Type | Description |
|---|---|---|
| `session` | `Dict[str, Any]` | zOS session dictionary (for state management) |
| `logger` | `Any` | zOS logger instance (for debug/info logging) |
| `zos` | `Any \| None` | zOS framework instance (optional, required for plugin cache) |

**On init, automatically:**
- Creates SystemCache (UI/config with LRU eviction)
- Creates PinnedCache (user aliases, no eviction)
- Creates SchemaCache (DB connections + transactions)
- Creates PluginCache (if zos provided - module instances + session injection)
- Logs initialization details

---

## Cache Type Routing

The orchestrator routes requests based on `cache_type` parameter:

### System Cache (`cache_type="system"`)

**Purpose:** UI files, config files, YAML schemas  
**Features:** LRU eviction (max_size=100), pattern matching, mtime invalidation  
**Methods:** `get()`, `set()`, `has()`, `clear()`, `get_stats()`

```python
# Get from system cache
data = orchestrator.get("parsed:/path/to/file.yaml", cache_type="system", filepath="/path/to/file.yaml")

# Set in system cache
orchestrator.set("parsed:/path/to/file.yaml", data, cache_type="system", filepath="/path/to/file.yaml")
```

**Cache Key Format:** `"parsed:{absolute_filepath}"`

---

### Pinned Cache (`cache_type="pinned"`)

**Purpose:** User-loaded aliases (zLoad command)  
**Features:** No eviction, highest priority, user control  
**Methods:** `get_alias()`, `load_alias()`, `has_alias()`, `clear()`, `get_stats()`

```python
# Get from pinned cache
data = orchestrator.get("users", cache_type="pinned", zpath="@.zUI.users.yaml")

# Set in pinned cache
orchestrator.set("users", data, cache_type="pinned", zpath="@.zUI.users.yaml")
```

**Cache Key Format:** User-defined alias (string)

---

### Schema Cache (`cache_type="schema"`)

**Purpose:** Database connections, transaction management  
**Features:** Dual storage (in-memory connections + session metadata)  
**Methods:** `get_connection()`, `set_connection()`, `has_connection()`, `clear()`, `get_stats()`

```python
# Get from schema cache
connection = orchestrator.get("users", cache_type="schema")

# Set in schema cache
orchestrator.set("users", connection, cache_type="schema")
```

**Cache Key Format:** Schema name (string)

---

### Plugin Cache (`cache_type="plugin"`)

**Purpose:** Dynamically loaded plugin modules  
**Features:** Collision detection, session injection, mtime invalidation, LRU  
**Methods:** `get()`, `set()`, `has()`, `clear()`, `get_stats()`

```python
# Get from plugin cache
plugin = orchestrator.get("my_plugin", cache_type="plugin", file_path="/path/to/plugin.py")

# Set in plugin cache
orchestrator.set("my_plugin", plugin, cache_type="plugin", file_path="/path/to/plugin.py")
```

**Cache Key Format:** Plugin name (string)

---

### Batch Operations (`cache_type="all"`)

**Purpose:** Operations across all cache tiers  
**Features:** Aggregates results from all 4 caches  
**Methods:** `clear()`, `get_stats()`

```python
# Clear all cache tiers
orchestrator.clear("all")

# Get stats from all tiers
stats = orchestrator.get_stats("all")
# Returns: {"total_hits": int, "total_misses": int, "hit_rate": float, ...}
```

---

## Method Reference

### `get(cache_key, cache_type, **kwargs)`

Get value from cache tier.

**Parameters:**
- `cache_key` (str): Cache key (format varies by tier)
- `cache_type` (str): Cache tier ("system", "pinned", "schema", "plugin")
- `**kwargs`: Tier-specific parameters (e.g., `filepath`, `zpath`)

**Returns:** Cached value or `None` if miss

**Example:**
```python
# System cache
data = orchestrator.get("parsed:/path/to/file.yaml", "system", filepath="/path/to/file.yaml")

# Pinned cache
data = orchestrator.get("users", "pinned", zpath="@.zUI.users.yaml")
```

---

### `set(cache_key, value, cache_type, **kwargs)`

Set value in cache tier.

**Parameters:**
- `cache_key` (str): Cache key (format varies by tier)
- `value` (Any): Value to cache
- `cache_type` (str): Cache tier ("system", "pinned", "schema", "plugin")
- `**kwargs`: Tier-specific parameters (e.g., `filepath`, `zpath`)

**Returns:** Cached value (for chaining)

**Example:**
```python
# System cache
orchestrator.set("parsed:/path/to/file.yaml", data, "system", filepath="/path/to/file.yaml")

# Plugin cache
orchestrator.set("my_plugin", plugin, "plugin", file_path="/path/to/plugin.py")
```

---

### `has(cache_key, cache_type)`

Check if cache tier has key.

**Parameters:**
- `cache_key` (str): Cache key (format varies by tier)
- `cache_type` (str): Cache tier ("system", "pinned", "schema", "plugin")

**Returns:** `True` if key exists, `False` otherwise

**Example:**
```python
# Check system cache
exists = orchestrator.has("parsed:/path/to/file.yaml", "system")

# Check pinned cache
exists = orchestrator.has("users", "pinned")
```

---

### `clear(cache_type)`

Clear cache tier(s).

**Parameters:**
- `cache_type` (str): Cache tier to clear ("system", "pinned", "schema", "plugin", "all")

**Returns:** `None`

**Example:**
```python
# Clear all tiers
orchestrator.clear("all")

# Clear specific tier
orchestrator.clear("system")
```

---

### `get_stats(cache_type)`

Get cache statistics.

**Parameters:**
- `cache_type` (str): Cache tier ("system", "pinned", "schema", "plugin", "all")

**Returns:** Dict with stats (`hits`, `misses`, `hit_rate`, `size`, etc.)

**Example:**
```python
# Get stats from all tiers
stats = orchestrator.get_stats("all")
print(f"Total hits: {stats['total_hits']}")
print(f"Hit rate: {stats['hit_rate']:.2%}")

# Get stats from specific tier
system_stats = orchestrator.get_stats("system")
print(f"Cache size: {system_stats['size']}/{system_stats['max_size']}")
```

---

## Integration Points

**Used By:**
- zLoader facade (`zLoader.py`) - Main consumer

**Delegates To:**
- SystemCache (`loader_cache_system.py`)
- PinnedCache (`loader_cache_pinned.py`)
- SchemaCache (`loader_cache_schema.py`)
- PluginCache (`loader_cache_python_module.py`)

**Architecture Position:**
- Tier 3 (Orchestrator) - Routes requests to Tier 2 implementations

---

## Best Practices

### When to Use Each Tier

**System Cache:**
- UI files that change infrequently
- Config files shared across commands
- Static YAML schemas

**Pinned Cache:**
- User-defined aliases (via zLoad command)
- Frequently accessed UIs needing persistent cache
- Navigation shortcuts

**Schema Cache:**
- Database connections (expensive to recreate)
- Transaction management
- Session-based connection pooling

**Plugin Cache:**
- Dynamically loaded modules
- Custom functions/classes
- Plugin instances with session injection

### Cache Key Best Practices

**System Cache Keys:**
- Use absolute paths for consistency
- Format: `"parsed:{absolute_filepath}"`
- Example: `"parsed:/Users/name/workspace/zUI.users.yaml"`

**Pinned Cache Keys:**
- Use meaningful aliases
- Format: User-defined string
- Example: `"users"`, `"settings"`, `"admin_panel"`

**Schema Cache Keys:**
- Use schema names
- Format: Schema identifier string
- Example: `"users"`, `"products"`, `"orders"`

**Plugin Cache Keys:**
- Use plugin names
- Format: Plugin identifier string
- Example: `"my_plugin"`, `"data_processor"`

---

## See Also

- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache implementation
- [cache_pinned_GUIDE.md](cache_pinned_GUIDE.md) - Pinned cache implementation
- [cache_schema_GUIDE.md](cache_schema_GUIDE.md) - Schema cache implementation
- [cache_plugin_GUIDE.md](cache_plugin_GUIDE.md) - Plugin cache implementation
- [utils_GUIDE.md](utils_GUIDE.md) - Cache statistics and utilities
