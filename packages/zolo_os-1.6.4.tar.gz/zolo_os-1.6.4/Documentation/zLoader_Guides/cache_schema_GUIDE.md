# zLoader Schema Cache Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_cache_schema.py`  
> **Purpose:** Database connection caching with transaction management.

---

## Overview

The `loader_cache_schema` module provides the Schema Cache implementation (Tier 2) for zLoader's caching system. It is optimized for database connections with transaction support.

| Class | File | Purpose |
|---|---|---|
| `SchemaCache` | `loader_cache_schema.py` | DB connection cache with transactions |

---

## Key Features

**Database Connections:**
- Cache expensive database connections
- Connection pooling support
- Session-based lifetime

**Transaction Management:**
- Begin/commit/rollback support
- Nested transaction handling
- Transaction isolation

**Use Cases:**
- Database schema loading
- Connection pooling
- Transaction coordination

---

## Architecture: Tier 2 Cache Implementation

`SchemaCache` serves as Tier 2 in the zLoader architecture, implementing DB connection caching:

```
SchemaCache (Tier 2)
├── Connection Caching   — Reuse DB connections
├── Transaction Support  — Begin/commit/rollback
├── Session-based        — Per-session lifetime
└── Statistics           — Track connections, transactions
```

---

## Method Reference

### `get_connection(schema_name)`

Get database connection by schema name.

**Returns:** Connection object or `None` if miss

---

### `set_connection(schema_name, connection)`

Cache database connection.

**Returns:** Connection object (for chaining)

---

### `has_connection(schema_name)`

Check if cache has connection.

**Returns:** `True` if connection exists, `False` otherwise

---

### `clear()`

Clear entire schema cache (closes all connections).

---

### `get_stats()`

Get cache statistics.

**Returns:** Dict with stats (`connections`, `transactions`, `commits`, `rollbacks`)

---

## Integration Points

**Used By:**
- CacheOrchestrator (`cache_orchestrator.py`) - Routes schema cache requests
- zData subsystem - Database operations

**Architecture Position:**
- Tier 2 (Cache Implementation) - Provides DB connection caching

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator (Tier 3)
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache (UI/config)
- [cache_pinned_GUIDE.md](cache_pinned_GUIDE.md) - Pinned cache (aliases)
- [cache_plugin_GUIDE.md](cache_plugin_GUIDE.md) - Plugin cache (modules)
