# zLoader Constants Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_constants.py`  
> **Purpose:** Shared constants and configuration for zLoader subsystem.

---

## Overview

The `loader_constants` module provides centralized constants for the zLoader subsystem, ensuring consistency across all modules and preventing hardcoded values.

---

## Constant Categories

### Display Constants

**Purpose:** Visual feedback configuration for zDisplay integration

```python
# Color key for zLoader messages
COLOR_LOADER = "loader"  # Maps to zDisplay color scheme

# Message templates
MSG_READY = "zLoader Ready"
MSG_START = "zLoader Start"
MSG_CACHED = "Cache Hit"
MSG_RETURN = "Returning Data"
```

**Usage:**
```python
display.zDeclare(MSG_READY, color=COLOR_LOADER, style=STYLE_FULL)
display.zDeclare(MSG_START, color=COLOR_LOADER, style=STYLE_TILDE)
```

---

### Display Styles

**Purpose:** Control message formatting and visual hierarchy

```python
# Style modifiers
STYLE_FULL = "="   # Full banner (e.g., "====== zLoader Ready ======")
STYLE_TILDE = "~"  # Subtle message (e.g., "~ zLoader Start ~")

# Indentation levels
INDENT_ROOT = 0        # Root level (no indent)
INDENT_PRIMARY = 1     # Primary level (2 spaces)
INDENT_SECONDARY = 2   # Secondary level (4 spaces)
```

**Usage:**
```python
# Root level (full banner)
display.zDeclare(MSG_READY, indent=INDENT_ROOT, style=STYLE_FULL)

# Primary level (subtle)
display.zDeclare(MSG_START, indent=INDENT_PRIMARY, style=STYLE_TILDE)
```

---

### File Type Constants

**Purpose:** Identify different zVaFile types for routing

```python
# File types
FILE_TYPE_UI = "zUI"           # UI definition files
FILE_TYPE_SCHEMA = "zSchema"   # Database schema files
FILE_TYPE_CONFIG = "zConfig"   # Configuration files
FILE_TYPE_PLUGIN = "zPlugin"   # Plugin module files
```

**Usage:**
```python
# Detect file type
if FILE_TYPE_SCHEMA in filename:
    # Skip caching for schemas
    return load_fresh(filename)
elif FILE_TYPE_UI in filename:
    # Cache UI files
    return load_cached(filename)
```

---

### Cache Constants

**Purpose:** Cache configuration and behavior

```python
# Cache types
CACHE_TYPE_SYSTEM = "system"   # System cache (UI/config with LRU)
CACHE_TYPE_PINNED = "pinned"   # Pinned cache (user aliases, no eviction)
CACHE_TYPE_SCHEMA = "schema"   # Schema cache (DB connections)
CACHE_TYPE_PLUGIN = "plugin"   # Plugin cache (module instances)
CACHE_TYPE_ALL = "all"         # All cache tiers (batch operations)

# Cache key prefix
CACHE_KEY_PREFIX = "parsed:"   # Prefix for system cache keys
                               # Format: "parsed:{absolute_filepath}"

# Cache sizes
CACHE_MAX_SIZE_SYSTEM = 100    # System cache max size (LRU eviction)
CACHE_MAX_SIZE_PLUGIN = 50     # Plugin cache max size (LRU eviction)
```

**Usage:**
```python
# Build cache key
cache_key = f"{CACHE_KEY_PREFIX}{absolute_filepath}"
# Result: "parsed:/Users/name/workspace/zUI.users.yaml"

# Route to cache tier
orchestrator.get(cache_key, cache_type=CACHE_TYPE_SYSTEM)
```

---

### File Extension Constants

**Purpose:** Format detection and validation

```python
# Supported extensions (in priority order)
EXTENSION_ZOLO = ".zolo"     # Native zOS format (tried first)
EXTENSION_JSON = ".json"     # JSON format (tried second)
EXTENSION_YAML = ".yaml"     # YAML format (tried third)
EXTENSION_YML = ".yml"       # YAML format (tried last)

# Special extensions
SCHEMA_EXTENSION = ".yaml|zSchema"  # Schema file indicator
```

**Usage:**
```python
# Try extensions in order
for ext in [EXTENSION_ZOLO, EXTENSION_JSON, EXTENSION_YAML, EXTENSION_YML]:
    file_path = base_path + ext
    if os.path.exists(file_path):
        return file_path
```

---

### Session Constants

**Purpose:** Session dictionary keys for state management

```python
# Session keys
SESSION_KEY_VAFILE = "zVaFile"       # Current UI filename
SESSION_KEY_VAFOLDER = "zVaFolder"   # Current folder path
SESSION_KEY_SPACE = "zSpace"         # Workspace path
SESSION_KEY_MODE = "zMode"           # Execution mode
```

**Usage:**
```python
# Get current UI from session
vafile = session.get(SESSION_KEY_VAFILE)
vafolder = session.get(SESSION_KEY_VAFOLDER)

# Build path
zpath = f"{vafolder}.{vafile}"
```

---

### Error Message Constants

**Purpose:** Consistent error messages

```python
# Error messages
ERR_FILE_NOT_FOUND = "File not found"
ERR_INVALID_FORMAT = "Invalid file format"
ERR_PARSE_ERROR = "Cannot parse file"
ERR_CACHE_ERROR = "Cache operation failed"
```

**Usage:**
```python
if not os.path.exists(file_path):
    raise FileNotFoundError(f"{ERR_FILE_NOT_FOUND}: {file_path}")
```

---

## Constant Groups

### Display Configuration

**Group:** All display-related constants

```python
# Import display constants
from zLoader.loader_modules import (
    COLOR_LOADER,
    MSG_READY,
    MSG_START,
    MSG_CACHED,
    MSG_RETURN,
    STYLE_FULL,
    STYLE_TILDE,
    INDENT_ROOT,
    INDENT_PRIMARY,
    INDENT_SECONDARY,
)
```

---

### Cache Configuration

**Group:** All cache-related constants

```python
# Import cache constants
from zLoader.loader_modules import (
    CACHE_TYPE_SYSTEM,
    CACHE_TYPE_PINNED,
    CACHE_TYPE_SCHEMA,
    CACHE_TYPE_PLUGIN,
    CACHE_TYPE_ALL,
    CACHE_KEY_PREFIX,
    CACHE_MAX_SIZE_SYSTEM,
    CACHE_MAX_SIZE_PLUGIN,
)
```

---

### File Type Configuration

**Group:** All file-related constants

```python
# Import file constants
from zLoader.loader_modules import (
    FILE_TYPE_UI,
    FILE_TYPE_SCHEMA,
    FILE_TYPE_CONFIG,
    FILE_TYPE_PLUGIN,
    EXTENSION_ZOLO,
    EXTENSION_JSON,
    EXTENSION_YAML,
    EXTENSION_YML,
    SCHEMA_EXTENSION,
)
```

---

## Integration Points

**Used By:**
- All zLoader modules (facade, cache tiers, utilities)
- Ensures consistency across subsystem

**Exported By:**
- `loader_modules/__init__.py` (public API)

**Architecture Position:**
- Support module (shared across all tiers)

---

## Best Practices

### Import from Constants Module

**Do this:**
```python
from zLoader.loader_modules import (
    COLOR_LOADER,
    CACHE_TYPE_SYSTEM,
    FILE_TYPE_UI,
)
```

**Don't do this:**
```python
# Bad: Hardcoded values
color = "loader"
cache_type = "system"
file_type = "zUI"
```

### Use Constants for Configuration

**Do this:**
```python
if file_type == FILE_TYPE_SCHEMA:
    skip_cache = True
```

**Don't do this:**
```python
# Bad: Hardcoded string comparison
if file_type == "zSchema":
    skip_cache = True
```

### Group Related Constants

**Do this:**
```python
# Group cache constants
CACHE_CONFIG = {
    "system_max_size": CACHE_MAX_SIZE_SYSTEM,
    "plugin_max_size": CACHE_MAX_SIZE_PLUGIN,
}
```

**Don't do this:**
```python
# Bad: Scattered configuration
system_max = 100
plugin_max = 50
```

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache
- [io_GUIDE.md](io_GUIDE.md) - File I/O operations
- [validator_GUIDE.md](validator_GUIDE.md) - File validation
