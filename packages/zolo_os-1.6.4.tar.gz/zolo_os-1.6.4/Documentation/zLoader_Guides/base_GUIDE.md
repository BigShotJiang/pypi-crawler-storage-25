# zLoader Base Cache Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/cache_base.py`  
> **Purpose:** Abstract base class (ABC) for all cache tier implementations.

---

## Overview

The `cache_base` module provides the abstract base class for all cache tier implementations in zLoader's caching system, ensuring consistent interface across all tiers.

| Class | File | Purpose |
|---|---|---|
| `CacheBase` | `cache_base.py` | Abstract base class for cache tiers |

---

## Key Features

**Interface Definition:**
- Defines required methods for all cache tiers
- Enforces consistent API across tiers
- Type hints for IDE support

**Abstract Methods:**
- `get()` - Get value from cache
- `set()` - Set value in cache
- `has()` - Check if cache has key
- `clear()` - Clear cache
- `get_stats()` - Get cache statistics

**Benefits:**
- Polymorphism (any cache tier can be used interchangeably)
- Contract enforcement (all tiers implement same interface)
- Documentation (clear expectations for implementations)

---

## Architecture: Abstract Base Class

`CacheBase` serves as the foundation for all Tier 2 cache implementations:

```
CacheBase (ABC)
├── SystemCache        — Implements CacheBase
├── PinnedCache        — Implements CacheBase
├── SchemaCache        — Implements CacheBase
└── PluginCache        — Implements CacheBase
```

**Design rationale:** ABC pattern ensures all cache tiers implement required methods, enabling polymorphic usage via CacheOrchestrator.

---

## Abstract Method Signatures

### `get(cache_key, **kwargs)`

Get value from cache.

**Parameters:**
- `cache_key` (str): Cache key
- `**kwargs`: Tier-specific parameters

**Returns:** Cached value or `None` if miss

**Must be implemented by:** All cache tiers

---

### `set(cache_key, value, **kwargs)`

Set value in cache.

**Parameters:**
- `cache_key` (str): Cache key
- `value` (Any): Value to cache
- `**kwargs`: Tier-specific parameters

**Returns:** Cached value (for chaining)

**Must be implemented by:** All cache tiers

---

### `has(cache_key)`

Check if cache has key.

**Parameters:**
- `cache_key` (str): Cache key

**Returns:** `True` if key exists, `False` otherwise

**Must be implemented by:** All cache tiers

---

### `clear()`

Clear entire cache.

**Returns:** `None`

**Must be implemented by:** All cache tiers

---

### `get_stats()`

Get cache statistics.

**Returns:** Dict with stats (`hits`, `misses`, `hit_rate`, `size`, etc.)

**Must be implemented by:** All cache tiers

---

## Implementation Example

```python
from cache_base import CacheBase

class MyCache(CacheBase):
    """Custom cache tier implementation."""
    
    def __init__(self, session, logger):
        self.session = session
        self.logger = logger
        self._storage = {}
        self._hits = 0
        self._misses = 0
    
    def get(self, cache_key, **kwargs):
        if cache_key in self._storage:
            self._hits += 1
            return self._storage[cache_key]
        self._misses += 1
        return None
    
    def set(self, cache_key, value, **kwargs):
        self._storage[cache_key] = value
        return value
    
    def has(self, cache_key):
        return cache_key in self._storage
    
    def clear(self):
        self._storage.clear()
    
    def get_stats(self):
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0.0
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "size": len(self._storage),
        }
```

---

## Integration Points

**Used By:**
- All Tier 2 cache implementations (SystemCache, PinnedCache, SchemaCache, PluginCache)

**Enforces:**
- Consistent interface across all cache tiers
- Contract for cache implementations

**Architecture Position:**
- Support module (base class for Tier 2)

---

## Best Practices

### Implementing Cache Tiers

**Do this:**
```python
class MyCache(CacheBase):
    """Implement all abstract methods."""
    
    def get(self, cache_key, **kwargs):
        # Implementation
        pass
    
    def set(self, cache_key, value, **kwargs):
        # Implementation
        pass
    
    # ... other required methods
```

**Don't do this:**
```python
class MyCache:
    """Don't skip CacheBase - breaks polymorphism."""
    
    def get(self, key):  # Wrong signature
        pass
```

---

## See Also

- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache implementation
- [cache_pinned_GUIDE.md](cache_pinned_GUIDE.md) - Pinned cache implementation
- [cache_schema_GUIDE.md](cache_schema_GUIDE.md) - Schema cache implementation
- [cache_plugin_GUIDE.md](cache_plugin_GUIDE.md) - Plugin cache implementation
- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator
