# zLoader I/O Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_io.py`  
> **Purpose:** Raw file I/O operations for zLoader (Tier 1 Foundation).

---

## Overview

The `loader_io` module provides the foundational file I/O operations for zLoader's caching system. It is the lowest tier (Tier 1) in the zLoader architecture, handling raw file reading with proper encoding and error handling.

| Function | File | Purpose |
|---|---|---|
| `load_file_raw()` | `loader_io.py` | Raw file reading with UTF-8 encoding |

---

## Architecture: Tier 1 Foundation

`loader_io` serves as Tier 1 (Foundation) in the zLoader architecture, providing raw file I/O:

```
load_file_raw() (Tier 1)
├── File Reading         — Raw file content (UTF-8 encoded)
├── Error Handling       — FileNotFoundError, IOError
├── Encoding Support     — UTF-8 with fallback
└── Display Integration  — Visual feedback via zDisplay
```

**Design rationale:** Centralizing file I/O in one place ensures consistent error handling, encoding, and logging across all cache tiers.

---

## `load_file_raw()`

### Function Signature

```python
def load_file_raw(file_path: str, logger: Any, display: Any) -> str:
    """
    Load raw file content from disk.
    
    Parameters
    ----------
    file_path : str
        Absolute path to file
    logger : Any
        zOS logger instance (for debug/info logging)
    display : Any
        zDisplay instance (for visual feedback)
    
    Returns
    -------
    str
        Raw file content as string (UTF-8 decoded)
    
    Raises
    ------
    FileNotFoundError
        If file does not exist
    IOError
        If file cannot be read
    UnicodeDecodeError
        If file is not valid UTF-8
    """
```

### Usage Example

```python
from zLoader.loader_modules import load_file_raw

# Load raw file content
try:
    content = load_file_raw("/path/to/file.yaml", logger, display)
    print(f"Loaded {len(content)} bytes")
except FileNotFoundError:
    print("File not found")
except IOError as e:
    print(f"I/O error: {e}")
```

---

## Encoding Handling

**Default encoding: UTF-8**
- All files read as UTF-8 by default
- Handles most text formats (.yaml, .json, .zolo)
- Compatible with international characters

**Error handling:**
```python
# UTF-8 decoding
try:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
except UnicodeDecodeError:
    # File is not valid UTF-8
    raise UnicodeDecodeError(...)
```

**Why UTF-8?**
- **Universal**: Supports all languages and symbols
- **Standard**: Python 3 default encoding
- **Compatible**: Works with YAML, JSON, and zOS formats
- **Safe**: Handles edge cases (emojis, special characters)

---

## Error Handling

`load_file_raw()` handles three types of errors:

### FileNotFoundError

**When:** File does not exist at specified path

**Handling:**
```python
if not os.path.exists(file_path):
    raise FileNotFoundError(f"File not found: {file_path}")
```

**User experience:**
- Clear error message with full path
- Logged to framework logger
- Display shows error via zDeclare

---

### IOError

**When:** File exists but cannot be read (permissions, corruption, etc.)

**Handling:**
```python
try:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
except IOError as e:
    raise IOError(f"Cannot read file: {e}")
```

**User experience:**
- Clear error message with reason
- Logged to framework logger
- Display shows error via zDeclare

---

### UnicodeDecodeError

**When:** File contains invalid UTF-8 sequences

**Handling:**
```python
try:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
except UnicodeDecodeError as e:
    raise UnicodeDecodeError(f"Invalid UTF-8 encoding: {e}")
```

**User experience:**
- Clear error message with encoding issue
- Logged to framework logger
- Display shows error via zDeclare

---

## Display Integration

`load_file_raw()` integrates with zDisplay for visual feedback:

**Progress messages:**
```python
# Before reading
display.zDeclare("Loading file...", color="loader", style="~")

# After reading
display.zDeclare("File loaded", color="loader", style="~")
```

**Error messages:**
```python
# File not found
display.zDeclare("File not found!", color="error", style="!")

# I/O error
display.zDeclare("Cannot read file!", color="error", style="!")
```

---

## Integration Points

**Used By:**
- zLoader facade (`zLoader.py`) - Main file loading
- CacheOrchestrator (`cache_orchestrator.py`) - Cache miss handling
- All cache tiers (indirect via facade/orchestrator)

**Depends On:**
- Python stdlib: `os`, `open()`
- zDisplay: Visual feedback
- zLogger: Debug logging

**Architecture Position:**
- Tier 1 (Foundation) - Raw file I/O operations

---

## Best Practices

### File Path Requirements

**Use absolute paths:**
```python
# Good: Absolute path
content = load_file_raw("/Users/name/workspace/file.yaml", logger, display)

# Bad: Relative path (may fail depending on cwd)
content = load_file_raw("file.yaml", logger, display)
```

**Resolve paths before calling:**
```python
import os

# Resolve to absolute path first
file_path = os.path.abspath("relative/path/file.yaml")

# Then load
content = load_file_raw(file_path, logger, display)
```

### Error Handling

**Always wrap in try/except:**
```python
try:
    content = load_file_raw(file_path, logger, display)
except FileNotFoundError:
    # Handle missing file
    print("File not found")
except IOError as e:
    # Handle I/O error
    print(f"Cannot read file: {e}")
except UnicodeDecodeError as e:
    # Handle encoding error
    print(f"Invalid encoding: {e}")
```

**Don't catch all exceptions:**
```python
# Bad: Catches too much
try:
    content = load_file_raw(file_path, logger, display)
except Exception as e:
    print(f"Error: {e}")

# Good: Catch specific exceptions
try:
    content = load_file_raw(file_path, logger, display)
except (FileNotFoundError, IOError, UnicodeDecodeError) as e:
    print(f"Error: {e}")
```

### Performance Tips

**Cache file content:**
- Don't call `load_file_raw()` repeatedly for same file
- Use cache tiers (System, Pinned, Plugin) instead
- Only call when cache miss or invalidation

**Minimize disk I/O:**
- Load once, cache result
- Check cache before loading
- Use mtime invalidation (don't reload unchanged files)

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator (Tier 3)
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache (Tier 2)
- [validator_GUIDE.md](validator_GUIDE.md) - File validation and format detection
- [constants_GUIDE.md](constants_GUIDE.md) - Shared constants
