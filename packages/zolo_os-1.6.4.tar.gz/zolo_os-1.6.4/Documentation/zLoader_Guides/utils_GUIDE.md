# zLoader Utilities Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/cache_utils.py`  
> **Purpose:** Cache statistics and utility functions for zLoader.

---

## Overview

The `cache_utils` module provides utility functions for cache management, statistics aggregation, and debugging support across all cache tiers.

---

## Statistics Functions

### `aggregate_stats()`

Aggregate statistics from multiple cache tiers.

**Function Signature:**
```python
def aggregate_stats(stats_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aggregate statistics from multiple cache tiers.
    
    Parameters
    ----------
    stats_list : List[Dict[str, Any]]
        List of statistics dicts from cache tiers
    
    Returns
    -------
    Dict[str, Any]
        Aggregated statistics with totals and averages
    """
```

**Usage:**
```python
from zLoader.loader_modules import aggregate_stats

# Get stats from all tiers
system_stats = system_cache.get_stats()
pinned_stats = pinned_cache.get_stats()
schema_stats = schema_cache.get_stats()
plugin_stats = plugin_cache.get_stats()

# Aggregate
total_stats = aggregate_stats([
    system_stats,
    pinned_stats,
    schema_stats,
    plugin_stats,
])

print(f"Total hits: {total_stats['total_hits']}")
print(f"Total misses: {total_stats['total_misses']}")
print(f"Hit rate: {total_stats['hit_rate']:.2%}")
```

**Output Format:**
```python
{
    "total_hits": int,        # Sum of hits across all tiers
    "total_misses": int,      # Sum of misses across all tiers
    "hit_rate": float,        # Overall hit rate (hits / total)
    "total_size": int,        # Sum of cache sizes
    "total_evictions": int,   # Sum of evictions (LRU tiers only)
    "tiers": {
        "system": {...},      # Individual tier stats
        "pinned": {...},
        "schema": {...},
        "plugin": {...},
    }
}
```

---

### `format_stats()`

Format statistics for display.

**Function Signature:**
```python
def format_stats(stats: Dict[str, Any], include_tiers: bool = True) -> str:
    """
    Format statistics for human-readable display.
    
    Parameters
    ----------
    stats : Dict[str, Any]
        Statistics dict (from get_stats() or aggregate_stats())
    include_tiers : bool
        Include per-tier breakdown (default: True)
    
    Returns
    -------
    str
        Formatted statistics string
    """
```

**Usage:**
```python
from zLoader.loader_modules import format_stats

# Get stats
stats = cache.get_stats("all")

# Format for display
output = format_stats(stats)
print(output)
```

**Output Example:**
```
Cache Statistics
================
Total Hits:    1,234
Total Misses:    567
Hit Rate:      68.5%
Total Size:      89/150

Tier Breakdown
--------------
System Cache:  45 hits, 12 misses (78.9%), 45/100 entries
Pinned Cache:  23 hits, 5 misses (82.1%), 23 entries
Schema Cache:  15 hits, 8 misses (65.2%), 15 entries
Plugin Cache:  11 hits, 2 misses (84.6%), 6/50 entries
```

---

## Cache Key Utilities

### `build_cache_key()`

Build consistent cache key from filepath.

**Function Signature:**
```python
def build_cache_key(filepath: str, prefix: str = "parsed") -> str:
    """
    Build cache key from filepath.
    
    Parameters
    ----------
    filepath : str
        Absolute filepath
    prefix : str
        Cache key prefix (default: "parsed")
    
    Returns
    -------
    str
        Cache key in format "prefix:filepath"
    """
```

**Usage:**
```python
from zLoader.loader_modules import build_cache_key

# Build cache key
key = build_cache_key("/Users/name/workspace/zUI.users.yaml")
# Result: "parsed:/Users/name/workspace/zUI.users.yaml"

# Custom prefix
key = build_cache_key("/path/to/plugin.py", prefix="plugin")
# Result: "plugin:/path/to/plugin.py"
```

---

### `parse_cache_key()`

Parse cache key to extract filepath.

**Function Signature:**
```python
def parse_cache_key(cache_key: str) -> Tuple[str, str]:
    """
    Parse cache key to extract prefix and filepath.
    
    Parameters
    ----------
    cache_key : str
        Cache key in format "prefix:filepath"
    
    Returns
    -------
    Tuple[str, str]
        (prefix, filepath)
    """
```

**Usage:**
```python
from zLoader.loader_modules import parse_cache_key

# Parse cache key
prefix, filepath = parse_cache_key("parsed:/Users/name/workspace/zUI.users.yaml")
# prefix: "parsed"
# filepath: "/Users/name/workspace/zUI.users.yaml"
```

---

## Debugging Utilities

### `dump_cache()`

Dump cache contents for debugging.

**Function Signature:**
```python
def dump_cache(cache: Any, include_values: bool = False) -> str:
    """
    Dump cache contents for debugging.
    
    Parameters
    ----------
    cache : Any
        Cache instance (any tier)
    include_values : bool
        Include cached values (default: False)
    
    Returns
    -------
    str
        Formatted cache dump
    """
```

**Usage:**
```python
from zLoader.loader_modules import dump_cache

# Dump cache (keys only)
dump = dump_cache(system_cache)
print(dump)

# Dump cache (keys + values)
dump = dump_cache(system_cache, include_values=True)
print(dump)
```

**Output Example (keys only):**
```
System Cache Dump
=================
Size: 45/100

Keys:
- parsed:/Users/name/workspace/zUI.users.yaml (mtime: 1234567890)
- parsed:/Users/name/workspace/zUI.settings.yaml (mtime: 1234567891)
- parsed:/Users/name/workspace/zConfig.app.yaml (mtime: 1234567892)
...
```

**Output Example (keys + values):**
```
System Cache Dump
=================
Size: 45/100

Entries:
- parsed:/Users/name/workspace/zUI.users.yaml
  mtime: 1234567890
  value: {'zName': 'users', 'zBlock': [...], ...}

- parsed:/Users/name/workspace/zUI.settings.yaml
  mtime: 1234567891
  value: {'zName': 'settings', 'zBlock': [...], ...}
...
```

---

### `validate_cache_state()`

Validate cache state for consistency.

**Function Signature:**
```python
def validate_cache_state(cache: Any) -> List[str]:
    """
    Validate cache state for consistency issues.
    
    Parameters
    ----------
    cache : Any
        Cache instance (any tier)
    
    Returns
    -------
    List[str]
        List of validation warnings (empty if valid)
    """
```

**Usage:**
```python
from zLoader.loader_modules import validate_cache_state

# Validate cache
warnings = validate_cache_state(system_cache)

if warnings:
    print("Cache validation warnings:")
    for warning in warnings:
        print(f"  - {warning}")
else:
    print("Cache is valid")
```

**Validation Checks:**
- Size consistency (size matches actual entry count)
- Mtime freshness (cached mtimes match file mtimes)
- Key format (cache keys follow expected format)
- Memory leaks (no orphaned entries)

---

## Integration Points

**Used By:**
- CacheOrchestrator (`cache_orchestrator.py`) - Statistics aggregation
- All cache tiers - Individual statistics
- zLoader facade (`zLoader.py`) - Debugging support

**Architecture Position:**
- Support module (shared across all tiers)

---

## Best Practices

### Statistics Monitoring

**Do this:**
```python
# Monitor hit rate
stats = cache.get_stats("all")
if stats['hit_rate'] < 0.5:
    print("Warning: Low cache hit rate")
```

**Don't do this:**
```python
# Bad: Manual calculation
hits = cache._hits  # Don't access private attributes
misses = cache._misses
hit_rate = hits / (hits + misses)
```

### Cache Debugging

**Do this:**
```python
# Use dump_cache for debugging
dump = dump_cache(cache)
logger.debug(dump)
```

**Don't do this:**
```python
# Bad: Manual inspection
for key, value in cache._storage.items():  # Don't access private attributes
    print(f"{key}: {value}")
```

### Statistics Display

**Do this:**
```python
# Use format_stats for display
stats = cache.get_stats("all")
print(format_stats(stats))
```

**Don't do this:**
```python
# Bad: Manual formatting
print(f"Hits: {stats['total_hits']}")
print(f"Misses: {stats['total_misses']}")
```

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache
- [constants_GUIDE.md](constants_GUIDE.md) - Shared constants
