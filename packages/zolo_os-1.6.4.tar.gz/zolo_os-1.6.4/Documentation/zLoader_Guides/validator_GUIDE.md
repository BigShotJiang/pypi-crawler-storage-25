# zLoader Validator Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_validator.py`  
> **Purpose:** File validation and format detection for zLoader.

---

## Overview

The `loader_validator` module provides file validation and format detection utilities for the zLoader subsystem, ensuring consistent file handling across all cache tiers.

---

## Key Features

**Format Detection:**
- Auto-detect file formats (.zolo, .yaml, .json)
- Try extensions in priority order
- First match wins

**File Validation:**
- Check file existence
- Validate file permissions
- Detect file type (UI, config, schema, plugin)

**Error Handling:**
- Clear error messages
- File-specific validation rules
- Integration with zDisplay/zLogger

---

## Function Reference

### `detect_format(file_path)`

Auto-detect file format by trying extensions.

**Parameters:**
- `file_path` (str): Base filepath (without extension)

**Returns:** Tuple of (full_path, extension) or (None, None) if not found

**Extension Priority:**
1. `.zolo` - Native zOS format (tried first)
2. `.json` - JSON format (tried second)
3. `.yaml` - YAML format (tried third)
4. `.yml` - YAML format (tried last)

---

### `validate_file(file_path)`

Validate file existence and permissions.

**Parameters:**
- `file_path` (str): Filepath to validate

**Returns:** `True` if valid, raises exception if invalid

**Checks:**
- File exists
- File is readable
- File is not empty (optional)

---

### `detect_file_type(filename)`

Detect zVaFile type from filename.

**Parameters:**
- `filename` (str): Filename to check

**Returns:** File type string ("zUI", "zSchema", "zConfig", "zPlugin") or `None`

**Detection Logic:**
- "zUI" in filename → UI file
- "zSchema" in filename → Schema file
- "zConfig" in filename → Config file
- "zPlugin" in filename → Plugin file

---

## Integration Points

**Used By:**
- zLoader facade (`zLoader.py`) - File loading validation
- CacheOrchestrator (`cache_orchestrator.py`) - Format detection
- All cache tiers - File validation

**Delegates To:**
- zParser - File type identification
- Python stdlib - File I/O and path operations

**Architecture Position:**
- Support module (shared across all tiers)

---

## See Also

- [io_GUIDE.md](io_GUIDE.md) - Raw file I/O operations
- [constants_GUIDE.md](constants_GUIDE.md) - File type constants
- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator
