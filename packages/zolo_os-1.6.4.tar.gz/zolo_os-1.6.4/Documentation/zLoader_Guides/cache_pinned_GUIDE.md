# zLoader Pinned Cache Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_cache_pinned.py`  
> **Purpose:** No-eviction cache for user-defined aliases (via zLoad command).

---

## Overview

The `loader_cache_pinned` module provides the Pinned Cache implementation (Tier 2) for zLoader's caching system. It is optimized for user-defined aliases with no automatic eviction.

| Class | File | Purpose |
|---|---|---|
| `PinnedCache` | `loader_cache_pinned.py` | No-eviction cache for user aliases |

---

## Key Features

**No Eviction:**
- User-loaded aliases persist until manually cleared
- Highest priority cache (user intent)
- Unlimited size (bounded only by memory)

**User Control:**
- Loaded via `zLoad` command
- Cleared via `zClear` command
- Listed via `zAlias` command

**Use Cases:**
- Frequently accessed UIs
- Navigation shortcuts
- Development workflows

---

## Architecture: Tier 2 Cache Implementation

`PinnedCache` serves as Tier 2 in the zLoader architecture, implementing no-eviction caching:

```
PinnedCache (Tier 2)
├── No Eviction          — User controls lifetime
├── Alias Management     — Named shortcuts
├── User Control         — Via zDispatch commands
└── Statistics           — Track hits, misses
```

---

## Method Reference

### `get_alias(alias, zpath)`

Get value from pinned cache by alias.

**Returns:** Cached value or `None` if miss

---

### `load_alias(alias, data, zpath)`

Load value into pinned cache with alias.

**Returns:** Cached value (for chaining)

---

### `has_alias(alias)`

Check if pinned cache has alias.

**Returns:** `True` if alias exists, `False` otherwise

---

### `clear()`

Clear entire pinned cache.

---

### `get_stats()`

Get cache statistics.

**Returns:** Dict with stats (`hits`, `misses`, `hit_rate`, `size`)

---

## Integration Points

**Used By:**
- CacheOrchestrator (`cache_orchestrator.py`) - Routes pinned cache requests
- zDispatch - zLoad/zClear/zAlias commands

**Architecture Position:**
- Tier 2 (Cache Implementation) - Provides no-eviction caching

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator (Tier 3)
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache (LRU eviction)
- [cache_schema_GUIDE.md](cache_schema_GUIDE.md) - Schema cache (DB connections)
- [cache_plugin_GUIDE.md](cache_plugin_GUIDE.md) - Plugin cache (modules)
