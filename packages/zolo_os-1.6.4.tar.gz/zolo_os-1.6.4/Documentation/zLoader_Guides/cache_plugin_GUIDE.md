# zLoader Plugin Cache Module Guide

> **Module:** `zOS/core/L1_Foundation/c_zLoader/loader_modules/loader_cache_python_module.py`  
> **Purpose:** LRU cache for dynamically loaded plugin modules with session injection.

---

## Overview

The `loader_cache_python_module` module provides the Plugin Cache implementation (Tier 2) for zLoader's caching system. It is optimized for dynamically loaded Python modules with session injection.

| Class | File | Purpose |
|---|---|---|
| `PluginCache` | `loader_cache_python_module.py` | Plugin module cache with session injection |

---

## Key Features

**Module Loading:**
- Cache dynamically loaded Python modules
- Session injection (zos instance available to plugins)
- Mtime invalidation (auto-reload on changes)

**Collision Detection:**
- Detect plugin name collisions
- Warn on duplicate plugin names
- Namespace isolation

**Use Cases:**
- Custom plugin loading
- Function/class extensions
- Dynamic module imports

---

## Architecture: Tier 2 Cache Implementation

`PluginCache` serves as Tier 2 in the zLoader architecture, implementing plugin module caching:

```
PluginCache (Tier 2)
├── Module Loading       — Dynamic Python imports
├── Session Injection    — zos instance available
├── Mtime Invalidation   — Auto-reload on changes
├── LRU Eviction         — Max 50 entries
└── Collision Detection  — Warn on duplicates
```

---

## Method Reference

### `get(plugin_name, file_path)`

Get plugin module by name.

**Returns:** Module instance or `None` if miss

---

### `set(plugin_name, module, file_path)`

Cache plugin module.

**Returns:** Module instance (for chaining)

---

### `has(plugin_name)`

Check if cache has plugin.

**Returns:** `True` if plugin exists, `False` otherwise

---

### `clear()`

Clear entire plugin cache.

---

### `get_stats()`

Get cache statistics.

**Returns:** Dict with stats (`hits`, `misses`, `hit_rate`, `size`, `max_size`, `evictions`)

---

## Integration Points

**Used By:**
- CacheOrchestrator (`cache_orchestrator.py`) - Routes plugin cache requests
- zFunc subsystem - Plugin loading and execution

**Architecture Position:**
- Tier 2 (Cache Implementation) - Provides plugin module caching

---

## See Also

- [orchestrator_GUIDE.md](orchestrator_GUIDE.md) - Cache orchestrator (Tier 3)
- [cache_system_GUIDE.md](cache_system_GUIDE.md) - System cache (UI/config)
- [cache_pinned_GUIDE.md](cache_pinned_GUIDE.md) - Pinned cache (aliases)
- [cache_schema_GUIDE.md](cache_schema_GUIDE.md) - Schema cache (connections)
