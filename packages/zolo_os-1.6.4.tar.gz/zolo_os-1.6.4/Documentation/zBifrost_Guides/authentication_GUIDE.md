# zBifrost Authentication Module Guide

> **Module:** `auth.py`  
> **Purpose:** Three-tier WebSocket authentication manager with zAuth integration

---

## Overview

The Authentication module provides three-tier WebSocket client authentication by orchestrating zComm primitives (origin/token validation) and zAuth integration. Supports zSession (internal users), Application (external users with tokens), and Dual (both simultaneously) authentication tiers.

**Key Features:**
- Three authentication tiers (zSession, Application, Dual)
- Origin validation (CORS/CSRF protection)
- Token-based authentication
- API key validation via zAuth
- Multi-app authentication support
- Connection lifecycle tracking
- Graceful authentication failure handling

---

## Architecture

### Three-Tier Design

```
Layer 1: zSession Authentication
├── For internal zCLI connections
├── No token required (session-based)
├── Auto-authenticated via session ID
└── Use case: Terminal→Web bridge for developer

Layer 2: Application Authentication
├── For external web users
├── Token-based (API keys from zAuth)
├── Integrates with user database
└── Use case: Public-facing web apps

Layer 3: Dual Authentication
├── Supports both zSession + Application
├── Multiple authentication contexts
├── Multi-app support (multiple apps per user)
└── Use case: Hybrid internal/external deployments
```

---

## Authentication Tiers

### zSession Auth (Layer 1)

**Internal authentication for zCLI connections:**

```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "zsession",
    }
}

z = zOS(zSpark)

# Session token auto-generated
session_token = z.session.get('zS_id')
print(f"Connect with: ws://127.0.0.1:56891?token={session_token}")
```

**Client connection:**
```javascript
const sessionToken = 'session_token_from_server';
const ws = new WebSocket(`ws://127.0.0.1:56891?token=${sessionToken}`);
```

**Behavior:**
- No user database required
- Session ID validates connection
- Origin validation still applies
- Use for internal tooling

---

### Application Auth (Layer 2)

**External authentication via zAuth:**

```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",
    }
}

z = zOS(zSpark)

# Register users via zAuth
z.auth.register_user("alice", "password123", role="admin")
z.auth.register_user("bob", "password456", role="user")

# Generate API keys
alice_key = z.auth.generate_api_key("alice")
bob_key = z.auth.generate_api_key("bob")

print(f"Alice: ws://...?api_key={alice_key}")
print(f"Bob: ws://...?api_key={bob_key}")
```

**Client connection:**
```javascript
const apiKey = 'user_api_key_from_login';
const ws = new WebSocket(`ws://127.0.0.1:56891?api_key=${apiKey}`);
```

**Behavior:**
- Requires zAuth user database
- API key validation
- Role-based access control
- Use for public web apps

---

### Dual Auth (Layer 3)

**Both authentication types simultaneously:**

```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "dual",
    }
}

z = zOS(zSpark)

# Both authentication methods work:
# Internal: ?token=<session_token>
# External: ?api_key=<user_api_key>
```

**Client connection (either works):**
```javascript
// Internal user
const ws1 = new WebSocket(`ws://...?token=${sessionToken}`);

// External user
const ws2 = new WebSocket(`ws://...?api_key=${apiKey}`);
```

**Behavior:**
- Supports both auth types
- Multiple authentication contexts
- Multi-app support
- Use for hybrid deployments

---

## Authentication Flow

### Handshake Process

```
1. Client initiates WebSocket connection
   ↓
2. Server validates Origin header (if configured)
   ↓
3. Server extracts authentication credentials from URL:
   - ?token=<session_token> (zSession)
   - ?api_key=<api_key> (Application)
   ↓
4. AuthenticationManager validates credentials:
   - zSession: Check session ID validity
   - Application: Query zAuth for API key
   - Dual: Try zSession first, fall back to Application
   ↓
5. Success: Connection established, client tracked
   Failure: Connection closed with code 1008 (Policy Violation)
```

### Authentication States

**Authenticated:**
- Client info stored in `authenticated_clients` dict
- User metadata cached (username, role, etc.)
- Full access to bridge features

**Rejected:**
- Connection closed immediately
- Close code 1008 (Policy Violation)
- Reason message explains failure
- No retry without valid credentials

---

## AuthenticationManager Class

### Initialization

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import AuthenticationManager

auth_mgr = AuthenticationManager(
    zos=z,
    logger=z.logger,
    config=z.config.websocket
)
```

**Attributes:**
- `zos`: zOS framework instance (access to zAuth)
- `logger`: Logger instance
- `config`: WebSocket config (auth settings)
- `authenticated_clients`: Dict tracking authenticated connections
- `auth_tier`: Current authentication tier (zsession/application/dual)

---

### Methods

#### `authenticate_client(websocket, path) -> bool`

**Purpose:** Validate client authentication during WebSocket handshake

```python
async def authenticate_client(websocket, path):
    """
    Authenticate client based on configured auth tier.
    
    Args:
        websocket: WebSocket connection
        path: Connection URL path (with query params)
        
    Returns:
        bool: True if authenticated, False if rejected
    """
```

**Returns:**
- `True`: Client authenticated, connection allowed
- `False`: Authentication failed, connection will be closed

**Side effects:**
- Adds client to `authenticated_clients` on success
- Closes connection with code 1008 on failure
- Logs authentication attempts

---

#### `get_client_info(websocket) -> Optional[Dict]`

**Purpose:** Get authentication info for connected client

```python
client_info = auth_mgr.get_client_info(websocket)
# {
#     'authenticated': True,
#     'auth_context': 'application',
#     'username': 'alice',
#     'role': 'admin',
#     'api_key': 'alice_key_...',
#     'connected_at': 1234567890.123
# }
```

**Returns:**
- `Dict`: Client authentication details
- `None`: Client not authenticated or not found

---

#### `remove_client(websocket) -> None`

**Purpose:** Remove client from authenticated clients (on disconnect)

```python
auth_mgr.remove_client(websocket)
```

**Called automatically** when client disconnects (cleanup).

---

#### `get_authenticated_count() -> int`

**Purpose:** Count currently authenticated clients

```python
count = auth_mgr.get_authenticated_count()
print(f"{count} clients authenticated")
```

---

## Multi-App Authentication

### Scenario: Multiple Apps per User

Application auth supports **multi-app authentication** - users can authenticate to different apps:

```python
# Configure auth with app_name support
zSpark = {
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",
    }
}

z = zOS(zSpark)

# Register user Alice
z.auth.register_user("alice", "password123", role="admin")

# Alice can authenticate to different apps
# Connection 1: Alice to "inventory-app"
# ws://...?api_key=alice_key&app_name=inventory-app

# Connection 2: Alice to "reports-app"
# ws://...?api_key=alice_key&app_name=reports-app
```

**Query parameters:**
- `api_key`: User's API key (from zAuth)
- `app_name`: Which app to authenticate to (optional)

**Use case:**
- SaaS platforms with multiple apps
- User accesses different apps simultaneously
- Per-app permissions/roles

---

## Origin Validation

Origin validation (CORS/CSRF protection) is handled by zComm primitives, but configured via zBifrost:

```python
zSpark = {
    "websocket": {
        "require_auth": True,
        "allowed_origins": [
            "https://myapp.com",
            "https://app.myapp.com",
            "http://localhost:3000",  # Development
        ]
    }
}
```

**Behavior:**
- Origin header checked before authentication
- Rejects connections from unauthorized domains
- Close code 1008 with "Invalid origin" reason
- Development: Allow `file://` for local HTML testing

---

## Error Handling

### Authentication Failure Codes

| Code | Reason | Description |
|------|--------|-------------|
| 1008 | Invalid origin | Origin header not in allowed_origins |
| 1008 | Authentication required | No credentials provided |
| 1008 | Invalid token | zSession token not found |
| 1008 | Invalid API key | Application API key not found in zAuth |
| 1011 | Authentication error | Internal error during auth process |

### Client-Side Handling

```javascript
ws.onclose = (event) => {
    if (event.code === 1008) {
        console.log('Authentication failed:', event.reason);
        // Show login UI or error message
    } else if (event.code === 1011) {
        console.log('Server error during auth');
        // Retry or contact support
    }
};
```

---

## Configuration Reference

### zSpark Configuration

```python
zSpark = {
    "websocket": {
        # Enable authentication (opt-in)
        "require_auth": True,
        
        # Authentication tier
        "auth_tier": "dual",  # zsession | application | dual
        
        # Origin validation (CORS/CSRF)
        "allowed_origins": [
            "https://myapp.com",
            "http://localhost:3000",
        ],
        
        # Connection limits
        "max_connections": 100,
        
        # Timeouts
        "auth_timeout": 10,  # Seconds to complete auth
        "ping_interval": 20,
        "ping_timeout": 10,
    }
}
```

### Environment Variables (.zEnv)

```bash
# Authentication
WEBSOCKET_REQUIRE_AUTH=true
WEBSOCKET_AUTH_TIER=application

# Origin validation
WEBSOCKET_ALLOWED_ORIGINS=https://myapp.com,https://app.myapp.com

# Connection limits
WEBSOCKET_MAX_CONNECTIONS=100
WEBSOCKET_AUTH_TIMEOUT=10
```

---

## Best Practices

### Security

1. **Always enable auth for production:**
   ```python
   # Development: OK to disable
   "require_auth": False
   
   # Production: Always enable
   "require_auth": True
   ```

2. **Use appropriate auth tier:**
   - Internal tools → `zsession`
   - Public web apps → `application`
   - Hybrid deployments → `dual`

3. **Validate origins in production:**
   ```python
   "allowed_origins": [
       "https://myapp.com",  # Specific domains only
       # Never: "*" or empty list in production!
   ]
   ```

4. **Store tokens securely:**
   - Never commit tokens to version control
   - Use `.zEnv` files (add to `.gitignore`)
   - Environment variables in production
   - Secrets managers (AWS Secrets Manager, etc.)

### Performance

1. **Connection limits:**
   ```python
   "max_connections": 100  # Prevent resource exhaustion
   ```

2. **Authentication timeouts:**
   ```python
   "auth_timeout": 10  # Seconds to complete auth
   ```

3. **Cleanup on disconnect:**
   - AuthenticationManager automatically removes clients
   - No manual cleanup required

### Development

1. **Local testing:**
   ```python
   "allowed_origins": [
       "file://",  # Allow local HTML files
       "http://localhost:3000",
   ]
   ```

2. **Debug logging:**
   ```python
   "logger": "DEBUG"  # See auth attempts in logs
   ```

---

## Integration with zAuth

zBifrost's Application auth integrates seamlessly with zAuth subsystem:

**User Registration:**
```python
# Register users via zAuth
z.auth.register_user("alice", "password123", role="admin")
z.auth.register_user("bob", "password456", role="user")
```

**API Key Generation:**
```python
# Generate API keys for WebSocket auth
alice_key = z.auth.generate_api_key("alice")
```

**Authentication Validation:**
```python
# zBifrost queries zAuth during WebSocket handshake
# - API key lookup
# - User existence check
# - Role/permission retrieval
```

**User Metadata:**
```python
# Get user info after authentication
client_info = z.bifrost.auth.get_client_info(websocket)
username = client_info['username']
role = client_info['role']
```

---

## Examples

### Complete Authentication Setup

```python
from zOS import zOS

# Configure three-tier authentication
zSpark = {
    "deployment": "Production",
    "title": "secure-bridge",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,
        "auth_tier": "dual",
        "allowed_origins": [
            "https://myapp.com",
            "http://localhost:3000",
        ],
        "max_connections": 100,
    }
}

z = zOS(zSpark)

# Register application users
z.auth.register_user("alice", "pass123", role="admin")
z.auth.register_user("bob", "pass456", role="user")

# Generate API keys
alice_key = z.auth.generate_api_key("alice")
bob_key = z.auth.generate_api_key("bob")

# Bridge auto-started with dual authentication
# Internal users: ?token=<session_token>
# External users: ?api_key=<alice_key|bob_key>

print(f"Session token: {z.session.get('zS_id')}")
print(f"Alice API key: {alice_key}")
print(f"Bob API key: {bob_key}")

input("Press Enter to stop...")
```

---

## Troubleshooting

### Connection Rejected (Code 1008)

**Check:**
1. Origin header allowed?
2. Credentials provided in URL?
3. Token/API key valid?
4. User exists in zAuth?

**Debug:**
```python
# Enable debug logging
"logger": "DEBUG"

# Check auth tier configuration
print(f"Auth tier: {z.config.websocket.auth_tier}")
print(f"Require auth: {z.config.websocket.require_auth}")
```

### Authentication Timeout

**Symptoms:** Connection closes before auth completes

**Solutions:**
```python
# Increase timeout
"auth_timeout": 30  # Seconds
```

### Origin Validation Fails

**Symptoms:** "Invalid origin" rejection

**Solutions:**
```python
# Add origin to allowed list
"allowed_origins": [
    "https://myapp.com",
    "http://localhost:3000",  # Development
]

# For local HTML files
"allowed_origins": ["file://"]
```

---

## Related Modules

- **zAuth** - User management and API key generation
- **zComm WebSocket** - Low-level origin/token validation primitives
- **Connection Module** - Client connection tracking
- **Cache Module** - Stores authenticated user metadata

---

**See also:**
- [zBifrost Main Guide](../zBifrost_GUIDE.md) - Complete facade overview
- [Connection Guide](connection_GUIDE.md) - WebSocket lifecycle
- [Caching Guide](caching_GUIDE.md) - User cache synchronization
- [zAuth Guide](../zAuth_GUIDE.md) - User management subsystem
