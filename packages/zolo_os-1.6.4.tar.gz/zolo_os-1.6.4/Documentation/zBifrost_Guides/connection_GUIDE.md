# zBifrost Connection Module Guide

> **Modules:** `orchestrator.py`, `ws_server.py`, `bridge_connection.py`, `server/lifecycle.py`, `server/client_handler.py`, `server/message_router.py`, `server/broadcaster.py`  
> **Purpose:** WebSocket bridge lifecycle, client connection management, and server infrastructure

---

## Overview

The Connection modules manage the WebSocket bridge lifecycle - from initialization to shutdown. Orchestrates client connections, message routing, and event broadcasting by coordinating zComm primitives with Layer 1 subsystems (zDisplay, zAuth, zData).

**Key Features:**
- Auto-start in zBifrost mode
- Manual start in zCLI mode
- Client connection tracking
- Message routing and dispatch
- Event broadcasting to clients
- Graceful shutdown (Ctrl+C safe)
- Health monitoring
- Connection lifecycle hooks

---

## Architecture

### Module Hierarchy

```
BridgeOrchestrator (orchestrator.py)
├── Manages bridge lifecycle (start, shutdown, auto-start)
├── Coordinates with zComm WebSocket primitives
└── Provides health check and status APIs

WebSocketServer (ws_server.py)
├── Wraps zComm WebSocket infrastructure
├── Delegates to lifecycle/client_handler/message_router
└── Coordinates authentication via auth.py

ConnectionManager (bridge_connection.py)
├── Tracks connected clients
├── Manages client metadata
└── Provides connection queries

Server Infrastructure (server/)
├── lifecycle.py: Server start/stop coordination
├── client_handler.py: Per-client connection handling
├── message_router.py: Incoming message routing
└── broadcaster.py: Event broadcasting to clients
```

---

## Initialization Modes

### zCLI Mode (Default)

**Bridge dormant until manually started:**

```python
from zOS import zOS

# Default mode (zCLI)
z = zOS()

# Bridge initialized but not started
print(f"Bridge running: {z.bifrost.is_running()}")  # False

# Start manually when needed
z.bifrost.start()

# Now running
print(f"Bridge running: {z.bifrost.is_running()}")  # True
```

**Use cases:**
- Terminal-only applications
- Manual control over bridge lifecycle
- Delayed WebSocket activation

---

### zBifrost Mode (Auto-Start)

**Bridge auto-starts on initialization:**

```python
from zOS import zOS

# zBifrost mode
zSpark = {
    "zMode": "zBifrost",  # Auto-start bridge
}

z = zOS(zSpark)

# Bridge already running
print(f"Bridge running: {z.bifrost.is_running()}")  # True
```

**Use cases:**
- Web-first applications
- Declarative setup (no manual start)
- Production deployments

---

## BridgeOrchestrator Class

### Initialization

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import BridgeOrchestrator

orchestrator = BridgeOrchestrator(
    zos=z,
    logger=z.logger,
    session=z.session
)
```

**Attributes:**
- `zos`: zOS framework instance
- `logger`: Logger instance
- `session`: Session dict from zOS
- `websocket`: WebSocket bridge instance (None until started)

---

### Methods

#### `start(host=None, port=None) -> None`

**Purpose:** Start WebSocket bridge manually

```python
# Use defaults from zConfig
z.bifrost.start()

# Override host/port
z.bifrost.start(host="0.0.0.0", port=8765)
```

**Parameters:**
- `host` (optional): Bind address (default from zConfig)
- `port` (optional): Port number (default from zConfig)

**Behavior:**
- Creates WebSocket server instance
- Starts server in background thread
- Registers socket_ready callback
- Blocks until Ctrl+C or shutdown()

---

#### `shutdown() -> None`

**Purpose:** Gracefully shutdown WebSocket bridge

```python
z.bifrost.shutdown()
```

**Behavior:**
- Closes all client connections
- Releases port binding
- Cleans up resources
- Thread-safe

---

#### `is_running() -> bool`

**Purpose:** Check if bridge is currently running

```python
if z.bifrost.is_running():
    print("Bridge active")
else:
    print("Bridge dormant")
```

---

#### `health_check() -> Dict`

**Purpose:** Get comprehensive bridge health status

```python
status = z.bifrost.health_check()
# {
#     'running': True,
#     'clients_connected': 5,
#     'port': 56891,
#     'host': '127.0.0.1',
#     'uptime_seconds': 123.45,
#     'authenticated_clients': 3,
#     'cache_status': {...},
# }
```

**Returns:**
- `running`: Bridge running state
- `clients_connected`: Current client count
- `port`: WebSocket port
- `host`: Bind address
- `uptime_seconds`: Time since start
- `authenticated_clients`: Authenticated client count
- `cache_status`: Cache module status

---

#### `broadcast(data: Dict) -> None`

**Purpose:** Broadcast event to all connected clients

```python
z.bifrost.broadcast({
    'event': 'notification',
    'type': 'info',
    'message': 'System update available'
})
```

**Parameters:**
- `data`: Event dictionary (must be JSON-serializable)

**Behavior:**
- Serializes data to JSON
- Broadcasts to all connected WebSocket clients
- Logs broadcast operation
- Non-blocking

---

#### `get_connected_clients() -> List[Dict]`

**Purpose:** Get list of connected client metadata

```python
clients = z.bifrost.get_connected_clients()
for client in clients:
    print(f"Address: {client['address']}")
    print(f"Authenticated: {client['authenticated']}")
    print(f"Connected at: {client['connected_at']}")
```

**Returns:**
```python
[
    {
        'address': '127.0.0.1:12345',
        'authenticated': True,
        'auth_context': 'application',
        'username': 'alice',
        'connected_at': 1234567890.123
    },
    ...
]
```

---

## WebSocket Server Lifecycle

### Startup Sequence

```
1. BridgeOrchestrator.start() called
   ↓
2. Create WebSocketServer instance (ws_server.py)
   ↓
3. Load configuration from zConfig.websocket
   ↓
4. Initialize authentication manager (auth.py)
   ↓
5. Initialize connection manager (bridge_connection.py)
   ↓
6. Initialize cache manager (cache.py)
   ↓
7. Register message handler (message_handler.py)
   ↓
8. Start zComm WebSocket server (delegates to comm_websocket.py)
   ↓
9. Register socket_ready callback
   ↓
10. Bridge running - clients can connect
```

### Shutdown Sequence

```
1. Ctrl+C or z.bifrost.shutdown() called
   ↓
2. Signal all clients to disconnect gracefully
   ↓
3. Wait for client disconnections (timeout: 5s)
   ↓
4. Force close remaining connections
   ↓
5. Stop zComm WebSocket server
   ↓
6. Release port binding
   ↓
7. Clean up resources (auth, cache, connections)
   ↓
8. Log shutdown completion
   ↓
9. Bridge dormant
```

---

## Connection Manager

### Client Tracking

**ConnectionManager** tracks all connected WebSocket clients:

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import ConnectionManager

conn_mgr = ConnectionManager(logger)
```

**Attributes:**
- `clients`: Dict mapping WebSocket to client metadata
- `logger`: Logger instance

---

### Methods

#### `add_client(websocket, metadata) -> None`

**Purpose:** Register new client connection

```python
conn_mgr.add_client(websocket, {
    'address': websocket.remote_address,
    'authenticated': False,
    'connected_at': time.time()
})
```

**Called automatically** during WebSocket handshake.

---

#### `remove_client(websocket) -> None`

**Purpose:** Remove client on disconnection

```python
conn_mgr.remove_client(websocket)
```

**Called automatically** when client disconnects.

---

#### `get_client(websocket) -> Optional[Dict]`

**Purpose:** Get client metadata by WebSocket connection

```python
client = conn_mgr.get_client(websocket)
if client:
    print(f"Client: {client['address']}")
```

---

#### `get_all_clients() -> List[Dict]`

**Purpose:** Get list of all connected clients

```python
clients = conn_mgr.get_all_clients()
print(f"{len(clients)} clients connected")
```

---

#### `get_client_count() -> int`

**Purpose:** Get count of connected clients

```python
count = conn_mgr.get_client_count()
```

---

## Message Router

### Routing Logic

**MessageRouter** dispatches incoming messages to appropriate handlers:

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.server import MessageRouter

router = MessageRouter(zos, logger)
```

**Routing table:**

| Message Type | Handler | Module |
|-------------|---------|--------|
| `display_*` | Display event handler | events/bridge_event_dispatch.py |
| `client_*` | Client event handler | events/bridge_event_client.py |
| `cache_*` | Cache event handler | events/bridge_event_cache.py |
| `data_*` | Data CRUD handler | zData integration |
| `walker_*` | Walker menu handler | message_walker.py |
| `discovery_*` | Discovery handler | events/bridge_event_discovery.py |

---

### Custom Handlers

**Register custom message handlers:**

```python
def custom_handler(websocket, message):
    """Handle custom message type."""
    data = json.loads(message)
    action = data.get('action')
    
    if action == 'custom_action':
        # Process custom action
        result = process_custom_action(data)
        
        # Send response
        await websocket.send(json.dumps({
            'event': 'custom_response',
            'result': result
        }))

# Register handler
router.register_handler('custom_', custom_handler)
```

---

## Event Broadcasting

### Broadcaster Class

**Broadcaster** sends events to connected clients:

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.server import Broadcaster

broadcaster = Broadcaster(conn_mgr, logger)
```

---

### Methods

#### `broadcast_to_all(event: Dict) -> int`

**Purpose:** Send event to all connected clients

```python
count = broadcaster.broadcast_to_all({
    'event': 'system_notification',
    'message': 'Server restarting in 5 minutes'
})

print(f"Sent to {count} clients")
```

**Returns:** Number of clients that received the event

---

#### `broadcast_to_authenticated(event: Dict) -> int`

**Purpose:** Send event only to authenticated clients

```python
count = broadcaster.broadcast_to_authenticated({
    'event': 'user_notification',
    'message': 'New message received'
})
```

**Returns:** Number of authenticated clients that received the event

---

#### `send_to_client(websocket, event: Dict) -> bool`

**Purpose:** Send event to specific client

```python
success = broadcaster.send_to_client(websocket, {
    'event': 'direct_message',
    'message': 'Hello Alice!'
})
```

**Returns:** `True` if sent successfully, `False` if failed

---

## Configuration

### WebSocket Configuration (zConfig)

```python
zSpark = {
    "websocket": {
        # Server binding
        "host": "127.0.0.1",  # Bind address
        "port": 56891,        # Port number (auto-assigned if 0)
        
        # Connection limits
        "max_connections": 100,
        
        # Timeouts
        "ping_interval": 20,  # Ping clients every 20s
        "ping_timeout": 10,   # Disconnect if no pong in 10s
        
        # Authentication (see authentication_GUIDE.md)
        "require_auth": True,
        "auth_tier": "dual",
        "allowed_origins": [
            "https://myapp.com",
        ],
    }
}
```

### Bridge Configuration (zBifrost-specific)

```python
zSpark = {
    # Bridge mode
    "zMode": "zBifrost",  # Auto-start bridge
    
    # Or manual control
    "zMode": "zCLI",  # Dormant until z.bifrost.start()
}
```

---

## Server Infrastructure Modules

### lifecycle.py - Server Start/Stop

**Manages server lifecycle:**
- Start WebSocket server
- Register shutdown handlers
- Coordinate graceful shutdown
- Handle Ctrl+C signals

### client_handler.py - Per-Client Handling

**Manages individual client connections:**
- Accept new connections
- Authentication handshake
- Message receive loop
- Disconnect cleanup

### message_router.py - Message Routing

**Routes incoming messages:**
- Parse message type
- Dispatch to appropriate handler
- Error handling
- Response coordination

### broadcaster.py - Event Broadcasting

**Sends events to clients:**
- Broadcast to all clients
- Broadcast to authenticated clients
- Send to specific clients
- Connection-safe sending

---

## Best Practices

### Lifecycle Management

1. **Use appropriate mode:**
   ```python
   # Terminal-only app
   "zMode": "zCLI"
   z.bifrost.start()  # Manual control
   
   # Web-first app
   "zMode": "zBifrost"  # Auto-start
   ```

2. **Graceful shutdown:**
   ```python
   try:
       z.bifrost.start()
   except KeyboardInterrupt:
       z.bifrost.shutdown()  # Cleanup
   ```

3. **Health monitoring:**
   ```python
   import time
   while z.bifrost.is_running():
       status = z.bifrost.health_check()
       if status['clients_connected'] > 100:
           print("Warning: High client count")
       time.sleep(60)
   ```

### Connection Management

1. **Track client metadata:**
   ```python
   clients = z.bifrost.get_connected_clients()
   for client in clients:
       if time.time() - client['connected_at'] > 3600:
           print(f"Client {client['address']} idle for 1 hour")
   ```

2. **Monitor connection count:**
   ```python
   count = z.bifrost.get_client_count()
   if count > 50:
       print("Warning: Many clients connected")
   ```

3. **Broadcast strategically:**
   ```python
   # Only to authenticated users
   z.bifrost.broadcast_to_authenticated(event)
   
   # Not to all clients (may include unauthenticated)
   # z.bifrost.broadcast(event)
   ```

### Performance

1. **Connection limits:**
   ```python
   "max_connections": 100  # Prevent overload
   ```

2. **Timeout configuration:**
   ```python
   "ping_interval": 20,
   "ping_timeout": 10,
   ```

3. **Message size limits:**
   - Keep messages small (< 1MB)
   - Use chunking for large data
   - Compress if needed

---

## Examples

### Complete Bridge Setup

```python
from zOS import zOS

zSpark = {
    "deployment": "Production",
    "title": "bridge-demo",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",  # Auto-start
    "websocket": {
        "host": "0.0.0.0",  # All interfaces
        "port": 56891,
        "max_connections": 100,
        "ping_interval": 20,
        "ping_timeout": 10,
        "require_auth": True,
        "auth_tier": "dual",
    }
}

z = zOS(zSpark)

# Bridge auto-started
print(f"Bridge running on port {z.bifrost.health_check()['port']}")

# Broadcast welcome message
z.bifrost.broadcast({
    'event': 'welcome',
    'message': 'Bridge is online!'
})

# Monitor connections
while True:
    clients = z.bifrost.get_connected_clients()
    print(f"{len(clients)} clients connected")
    time.sleep(10)
```

---

### Manual Lifecycle Control

```python
from zOS import zOS

# zCLI mode (manual control)
z = zOS()

# Start when ready
print("Starting bridge...")
z.bifrost.start(host="127.0.0.1", port=8765)

# Check status
if z.bifrost.is_running():
    print("Bridge started successfully")
    
    # Get health info
    status = z.bifrost.health_check()
    print(f"Port: {status['port']}")
    print(f"Clients: {status['clients_connected']}")
    
# Shutdown gracefully
try:
    input("Press Enter to shutdown...")
finally:
    z.bifrost.shutdown()
    print("Bridge stopped")
```

---

## Troubleshooting

### Bridge Won't Start

**Check:**
1. Port already in use?
2. Required subsystems initialized? (zComm, zDisplay, zAuth, zData)
3. Configuration valid?

**Debug:**
```python
# Check configuration
print(f"Host: {z.config.websocket.host}")
print(f"Port: {z.config.websocket.port}")

# Check port availability
is_available = z.comm.check_port(56891)
print(f"Port available: {is_available}")
```

### Clients Can't Connect

**Check:**
1. Bridge running?
2. Firewall blocking port?
3. Origin validation configured?
4. Authentication required?

**Debug:**
```python
# Check bridge status
status = z.bifrost.health_check()
print(f"Running: {status['running']}")
print(f"Port: {status['port']}")

# Check authentication
print(f"Auth required: {z.config.websocket.require_auth}")
print(f"Auth tier: {z.config.websocket.auth_tier}")
```

### Broadcast Not Received

**Check:**
1. Clients authenticated?
2. WebSocket connection active?
3. Message format valid JSON?

**Debug:**
```python
# Check connected clients
clients = z.bifrost.get_connected_clients()
print(f"{len(clients)} clients connected")

# Check authentication
auth_count = z.bifrost.orchestrator.auth.get_authenticated_count()
print(f"{auth_count} clients authenticated")
```

---

## Related Modules

- **Authentication Module** - Client authentication (see [authentication_GUIDE.md](authentication_GUIDE.md))
- **Cache Module** - State synchronization (see [caching_GUIDE.md](caching_GUIDE.md))
- **Events Module** - Message routing (see [events_GUIDE.md](events_GUIDE.md))
- **Monitoring Module** - Health checks (see [monitoring_GUIDE.md](monitoring_GUIDE.md))
- **zComm WebSocket** - Low-level primitives (see [../zComm_GUIDE.md](../zComm_GUIDE.md))

---

**See also:**
- [zBifrost Main Guide](../zBifrost_GUIDE.md) - Complete facade overview
- [Authentication Guide](authentication_GUIDE.md) - Three-tier auth
- [Caching Guide](caching_GUIDE.md) - State management
- [Events Guide](events_GUIDE.md) - Message handling
