# zBifrost Monitoring Module Guide

> **Module:** `monitoring.py`  
> **Purpose:** Health checks, connection monitoring, and bridge diagnostics

---

## Overview

The Monitoring module provides comprehensive health checks and diagnostics for the WebSocket bridge. Tracks connection status, client health, cache status, authentication metrics, and overall bridge performance.

**Key Features:**
- Bridge health checks
- Connection monitoring
- Client health tracking
- Authentication metrics
- Cache status reporting
- Performance diagnostics
- Uptime tracking
- Error rate monitoring

---

## Architecture

### Monitoring Hierarchy

```
BridgeMonitor (monitoring.py)
├── Health Check Engine
│   ├── Bridge running status
│   ├── Port availability
│   └── Subsystem integration checks
│
├── Connection Monitor
│   ├── Client count tracking
│   ├── Connection duration
│   ├── Disconnect rate
│   └── Client metadata
│
├── Authentication Monitor
│   ├── Auth success/failure rates
│   ├── Authenticated client count
│   └── Authentication duration
│
├── Cache Monitor
│   ├── Cache population status
│   ├── Cache size metrics
│   └── Update frequency
│
└── Performance Monitor
    ├── Message throughput
    ├── Event latency
    └── Resource usage
```

---

## BridgeMonitor Class

### Initialization

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import BridgeMonitor

monitor = BridgeMonitor(
    zos=z,
    logger=z.logger,
    orchestrator=z.bifrost.orchestrator
)
```

**Attributes:**
- `zos`: zOS framework instance
- `logger`: Logger instance
- `orchestrator`: BridgeOrchestrator instance
- `metrics`: Dict storing performance metrics
- `start_time`: Bridge start timestamp

---

## Health Check Methods

### `health_check() -> Dict`

**Purpose:** Comprehensive bridge health status

```python
status = monitor.health_check()
# {
#     'running': True,
#     'uptime_seconds': 123.45,
#     'port': 56891,
#     'host': '127.0.0.1',
#     'clients_connected': 5,
#     'authenticated_clients': 3,
#     'cache_status': {
#         'session': {'cached': True},
#         'users': {'count': 10},
#         'data': {'models': 3}
#     },
#     'subsystems': {
#         'zComm': True,
#         'zDisplay': True,
#         'zAuth': True,
#         'zData': True
#     },
#     'metrics': {
#         'messages_received': 1000,
#         'events_broadcast': 500,
#         'errors': 2
#     }
# }
```

**Returns:**
- `running`: Bridge running state
- `uptime_seconds`: Time since bridge start
- `port`: WebSocket port
- `host`: Bind address
- `clients_connected`: Current client count
- `authenticated_clients`: Authenticated client count
- `cache_status`: Cache module status
- `subsystems`: Subsystem availability
- `metrics`: Performance metrics

---

### `is_healthy() -> bool`

**Purpose:** Quick health check (boolean)

```python
if monitor.is_healthy():
    print("Bridge healthy")
else:
    print("Bridge unhealthy - check logs")
```

**Health criteria:**
- Bridge running
- No critical errors in last 60s
- All required subsystems available
- Port listening
- Cache populated

---

### `get_status_summary() -> str`

**Purpose:** Human-readable status summary

```python
summary = monitor.get_status_summary()
print(summary)
# """
# zBifrost Bridge Status
# =====================
# Running: Yes
# Uptime: 2m 34s
# Port: 56891
# Clients: 5 (3 authenticated)
# Cache: Session ✓ | Users ✓ (10) | Data ✓ (3 models)
# Health: Healthy ✓
# """
```

---

## Connection Monitoring

### `get_connection_metrics() -> Dict`

**Purpose:** Connection-specific metrics

```python
metrics = monitor.get_connection_metrics()
# {
#     'total_connections': 100,
#     'current_connections': 5,
#     'authenticated_connections': 3,
#     'avg_connection_duration': 300.5,
#     'disconnect_rate': 0.02,
#     'connection_errors': 3
# }
```

**Metrics:**
- `total_connections`: Lifetime connection count
- `current_connections`: Active connections
- `authenticated_connections`: Authenticated client count
- `avg_connection_duration`: Average session length (seconds)
- `disconnect_rate`: Disconnects per second
- `connection_errors`: Failed connection attempts

---

### `get_client_details() -> List[Dict]`

**Purpose:** Detailed information for each connected client

```python
clients = monitor.get_client_details()
for client in clients:
    print(f"Address: {client['address']}")
    print(f"Connected: {client['duration_seconds']}s ago")
    print(f"Authenticated: {client['authenticated']}")
    print(f"Username: {client.get('username', 'N/A')}")
    print(f"Messages sent: {client['messages_sent']}")
    print(f"Messages received: {client['messages_received']}")
```

**Returns:**
```python
[
    {
        'address': '127.0.0.1:12345',
        'connected_at': 1234567890.123,
        'duration_seconds': 300.5,
        'authenticated': True,
        'auth_context': 'application',
        'username': 'alice',
        'role': 'admin',
        'messages_sent': 50,
        'messages_received': 100,
        'last_activity': 1234567900.123
    },
    ...
]
```

---

### `get_connection_history() -> List[Dict]`

**Purpose:** Historical connection data

```python
history = monitor.get_connection_history(limit=10)
for conn in history:
    print(f"{conn['timestamp']}: {conn['event']} - {conn['address']}")
```

**Returns:**
```python
[
    {
        'timestamp': 1234567890.123,
        'event': 'connected',
        'address': '127.0.0.1:12345',
        'duration': None
    },
    {
        'timestamp': 1234567900.456,
        'event': 'authenticated',
        'address': '127.0.0.1:12345',
        'username': 'alice'
    },
    {
        'timestamp': 1234568000.789,
        'event': 'disconnected',
        'address': '127.0.0.1:12345',
        'duration': 110.666
    },
    ...
]
```

---

## Authentication Monitoring

### `get_auth_metrics() -> Dict`

**Purpose:** Authentication-specific metrics

```python
auth_metrics = monitor.get_auth_metrics()
# {
#     'total_attempts': 50,
#     'successful_auths': 45,
#     'failed_auths': 5,
#     'success_rate': 0.9,
#     'avg_auth_duration': 0.05,
#     'auth_methods': {
#         'zsession': 10,
#         'application': 35
#     },
#     'rejected_origins': 2
# }
```

**Metrics:**
- `total_attempts`: Total authentication attempts
- `successful_auths`: Successful authentications
- `failed_auths`: Failed authentication attempts
- `success_rate`: Success percentage (0.0-1.0)
- `avg_auth_duration`: Average auth time (seconds)
- `auth_methods`: Breakdown by auth tier
- `rejected_origins`: Invalid origin rejections

---

### `get_auth_failures() -> List[Dict]`

**Purpose:** Recent authentication failures

```python
failures = monitor.get_auth_failures(limit=10)
for failure in failures:
    print(f"{failure['timestamp']}: {failure['reason']} - {failure['address']}")
```

**Returns:**
```python
[
    {
        'timestamp': 1234567890.123,
        'address': '192.168.1.100:54321',
        'reason': 'Invalid token',
        'auth_tier': 'zsession',
        'origin': 'https://unknown.com'
    },
    ...
]
```

---

## Cache Monitoring

### `get_cache_metrics() -> Dict`

**Purpose:** Cache-specific metrics

```python
cache_metrics = monitor.get_cache_metrics()
# {
#     'session_cache': {
#         'populated': True,
#         'size_bytes': 512,
#         'last_update': 1234567890.123
#     },
#     'users_cache': {
#         'populated': True,
#         'count': 10,
#         'size_bytes': 2048,
#         'last_update': 1234567895.456
#     },
#     'data_cache': {
#         'populated': True,
#         'models': ['tasks', 'users_data'],
#         'total_records': 50,
#         'size_bytes': 10240,
#         'last_update': 1234567900.789
#     },
#     'cache_hit_rate': 0.95,
#     'cache_updates': 100
# }
```

**Metrics:**
- Cache population status
- Cache sizes (bytes)
- Last update timestamps
- Record counts
- Cache hit rate
- Update frequency

---

## Performance Monitoring

### `get_performance_metrics() -> Dict`

**Purpose:** Performance and throughput metrics

```python
perf = monitor.get_performance_metrics()
# {
#     'messages_received': 10000,
#     'messages_sent': 5000,
#     'events_broadcast': 2000,
#     'throughput': {
#         'messages_per_second': 50.5,
#         'events_per_second': 10.2
#     },
#     'latency': {
#         'avg_message_latency': 0.001,
#         'avg_event_latency': 0.005,
#         'p95_latency': 0.010,
#         'p99_latency': 0.050
#     },
#     'errors': {
#         'total': 10,
#         'rate': 0.001
#     }
# }
```

**Metrics:**
- Message counts (received/sent)
- Event broadcast count
- Throughput (messages/events per second)
- Latency statistics (avg, p95, p99)
- Error counts and rates

---

### `get_resource_usage() -> Dict`

**Purpose:** Resource consumption metrics

```python
resources = monitor.get_resource_usage()
# {
#     'memory_mb': 50.5,
#     'cpu_percent': 2.5,
#     'threads': 10,
#     'file_descriptors': 15
# }
```

**Note:** Resource metrics require `psutil` library.

---

## Alerting and Thresholds

### `set_alert_threshold(metric: str, threshold: float) -> None`

**Purpose:** Configure alerting thresholds

```python
# Alert if disconnect rate exceeds 5 per second
monitor.set_alert_threshold('disconnect_rate', 5.0)

# Alert if error rate exceeds 1%
monitor.set_alert_threshold('error_rate', 0.01)

# Alert if client count exceeds 100
monitor.set_alert_threshold('client_count', 100)
```

---

### `get_alerts() -> List[Dict]`

**Purpose:** Get active alerts

```python
alerts = monitor.get_alerts()
for alert in alerts:
    print(f"[{alert['severity']}] {alert['message']}")
    print(f"  Metric: {alert['metric']} = {alert['value']}")
    print(f"  Threshold: {alert['threshold']}")
```

**Returns:**
```python
[
    {
        'severity': 'warning',
        'metric': 'disconnect_rate',
        'value': 6.5,
        'threshold': 5.0,
        'message': 'High disconnect rate detected',
        'timestamp': 1234567890.123
    },
    ...
]
```

**Severity levels:**
- `info`: Informational
- `warning`: Needs attention
- `error`: Critical issue

---

## Diagnostic Methods

### `diagnose() -> Dict`

**Purpose:** Comprehensive diagnostic report

```python
diag = monitor.diagnose()
# {
#     'health_status': 'healthy',
#     'issues': [],
#     'recommendations': [
#         'Consider increasing connection limit'
#     ],
#     'detailed_checks': {
#         'bridge_running': {'status': 'pass', 'message': 'Bridge is running'},
#         'port_available': {'status': 'pass', 'message': 'Port 56891 listening'},
#         'clients_connected': {'status': 'pass', 'message': '5 clients connected'},
#         'cache_populated': {'status': 'pass', 'message': 'All caches populated'},
#         'auth_working': {'status': 'pass', 'message': '90% auth success rate'},
#         'error_rate_low': {'status': 'pass', 'message': 'Error rate: 0.1%'}
#     }
# }
```

**Checks performed:**
- Bridge running state
- Port availability
- Client connections
- Cache population
- Authentication health
- Error rates
- Resource usage
- Subsystem availability

---

### `get_uptime_stats() -> Dict`

**Purpose:** Uptime and availability statistics

```python
uptime = monitor.get_uptime_stats()
# {
#     'start_time': 1234567890.123,
#     'uptime_seconds': 3600.5,
#     'uptime_formatted': '1h 0m 0s',
#     'restarts': 0,
#     'total_downtime': 0.0,
#     'availability_percent': 99.9
# }
```

---

## Logging and Reporting

### `export_metrics(format: str = 'json') -> str`

**Purpose:** Export metrics for external monitoring

```python
# JSON format
json_metrics = monitor.export_metrics(format='json')

# Prometheus format
prom_metrics = monitor.export_metrics(format='prometheus')
# # HELP bifrost_clients_connected Number of connected clients
# # TYPE bifrost_clients_connected gauge
# bifrost_clients_connected 5
# ...

# CSV format
csv_metrics = monitor.export_metrics(format='csv')
```

**Formats:**
- `json`: JSON structure
- `prometheus`: Prometheus exposition format
- `csv`: CSV for spreadsheets
- `influxdb`: InfluxDB line protocol

---

### `generate_report() -> str`

**Purpose:** Human-readable monitoring report

```python
report = monitor.generate_report()
print(report)
# """
# zBifrost Monitoring Report
# ==========================
# Generated: 2026-03-12 10:30:00
# 
# Bridge Status
# -------------
# Running: Yes
# Uptime: 1h 5m 30s
# Port: 56891
# Health: Healthy ✓
# 
# Connections
# -----------
# Current: 5 clients
# Authenticated: 3 clients
# Total (lifetime): 100 connections
# Avg duration: 5m 15s
# Disconnect rate: 0.02/s
# 
# Authentication
# --------------
# Success rate: 90%
# Failed attempts: 5
# Methods: zSession (10), Application (35)
# 
# Cache
# -----
# Session: ✓ (512 bytes)
# Users: ✓ (10 users, 2KB)
# Data: ✓ (3 models, 50 records, 10KB)
# 
# Performance
# -----------
# Messages/sec: 50.5
# Events/sec: 10.2
# Avg latency: 1ms
# Error rate: 0.1%
# 
# Resource Usage
# --------------
# Memory: 50.5 MB
# CPU: 2.5%
# Threads: 10
# 
# Alerts
# ------
# No active alerts
# 
# Recommendations
# ---------------
# 1. Consider increasing connection limit
# """
```

---

## Examples

### Basic Health Monitoring

```python
from zOS import zOS
import time

zSpark = {
    "deployment": "Production",
    "title": "monitor-demo",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Monitor loop
while True:
    status = z.bifrost.health_check()
    
    print(f"Clients: {status['clients_connected']}")
    print(f"Authenticated: {status['authenticated_clients']}")
    
    if not z.bifrost.is_healthy():
        print("⚠️ Bridge unhealthy!")
        print(z.bifrost.diagnose())
    
    time.sleep(10)
```

---

### Alert Configuration

```python
# Configure thresholds
monitor = z.bifrost.monitoring

monitor.set_alert_threshold('client_count', 100)
monitor.set_alert_threshold('disconnect_rate', 5.0)
monitor.set_alert_threshold('error_rate', 0.01)

# Check alerts
while True:
    alerts = monitor.get_alerts()
    for alert in alerts:
        if alert['severity'] == 'error':
            print(f"🚨 CRITICAL: {alert['message']}")
            # Send notification, page ops, etc.
        elif alert['severity'] == 'warning':
            print(f"⚠️ WARNING: {alert['message']}")
    
    time.sleep(30)
```

---

### Performance Dashboard

```python
# Real-time performance monitoring
def print_dashboard():
    perf = monitor.get_performance_metrics()
    conn = monitor.get_connection_metrics()
    auth = monitor.get_auth_metrics()
    
    print("\033[2J\033[H")  # Clear screen
    print("=" * 50)
    print("zBifrost Performance Dashboard")
    print("=" * 50)
    print(f"Throughput: {perf['throughput']['messages_per_second']:.1f} msg/s")
    print(f"Latency: {perf['latency']['avg_message_latency'] * 1000:.2f}ms")
    print(f"Clients: {conn['current_connections']}")
    print(f"Auth rate: {auth['success_rate'] * 100:.1f}%")
    print(f"Errors: {perf['errors']['total']}")

while True:
    print_dashboard()
    time.sleep(1)
```

---

## Best Practices

### Monitoring Frequency

1. **Health checks:**
   ```python
   # Quick checks: Every 10s
   if time.time() % 10 == 0:
       if not monitor.is_healthy():
           alert_ops()
   
   # Detailed checks: Every 60s
   if time.time() % 60 == 0:
       diag = monitor.diagnose()
       log_diagnostics(diag)
   ```

2. **Metric collection:**
   ```python
   # Performance metrics: Every 5s
   # Connection metrics: Every 30s
   # Cache metrics: Every 60s
   ```

### Alert Configuration

1. **Set reasonable thresholds:**
   ```python
   # Based on capacity and SLAs
   monitor.set_alert_threshold('client_count', max_capacity * 0.8)
   monitor.set_alert_threshold('error_rate', 0.01)  # 1%
   ```

2. **Escalation levels:**
   ```python
   alerts = monitor.get_alerts()
   for alert in alerts:
       if alert['severity'] == 'error':
           page_ops()
       elif alert['severity'] == 'warning':
           log_warning()
   ```

### Resource Management

1. **Monitor resource usage:**
   ```python
   resources = monitor.get_resource_usage()
   if resources['memory_mb'] > 500:
       print("High memory usage!")
   ```

2. **Clean up metrics periodically:**
   ```python
   # Archive old metrics
   if time.time() % 86400 == 0:  # Daily
       monitor.archive_old_metrics()
   ```

---

## Troubleshooting

### High Disconnect Rate

**Symptoms:** Many clients disconnecting

**Debug:**
```python
conn_metrics = monitor.get_connection_metrics()
print(f"Disconnect rate: {conn_metrics['disconnect_rate']}")

history = monitor.get_connection_history(limit=20)
for event in history:
    if event['event'] == 'disconnected':
        print(f"Disconnect: {event['address']}, duration: {event['duration']}")
```

**Solutions:**
- Check network stability
- Increase ping timeout
- Investigate client errors

---

### High Error Rate

**Symptoms:** Errors in metrics

**Debug:**
```python
perf = monitor.get_performance_metrics()
print(f"Error rate: {perf['errors']['rate']}")

# Check error logs
z.logger.error_history()
```

**Solutions:**
- Check logs for error patterns
- Validate message formats
- Fix handler bugs

---

### Authentication Failures

**Symptoms:** Low auth success rate

**Debug:**
```python
auth_metrics = monitor.get_auth_metrics()
print(f"Success rate: {auth_metrics['success_rate']}")

failures = monitor.get_auth_failures()
for failure in failures:
    print(f"Failed: {failure['reason']}")
```

**Solutions:**
- Check token validity
- Verify zAuth integration
- Review origin configuration

---

## Related Modules

- **Connection Module** - Client tracking (see [connection_GUIDE.md](connection_GUIDE.md))
- **Authentication Module** - Auth metrics (see [authentication_GUIDE.md](authentication_GUIDE.md))
- **Caching Module** - Cache status (see [caching_GUIDE.md](caching_GUIDE.md))
- **Events Module** - Message metrics (see [events_GUIDE.md](events_GUIDE.md))

---

**See also:**
- [zBifrost Main Guide](../zBifrost_GUIDE.md) - Complete facade overview
- [Connection Guide](connection_GUIDE.md) - WebSocket lifecycle
- [Authentication Guide](authentication_GUIDE.md) - User management
- [Caching Guide](caching_GUIDE.md) - State synchronization
