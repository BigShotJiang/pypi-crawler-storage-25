# zBifrost Caching Module Guide

> **Module:** `cache.py`  
> **Purpose:** Client-side state caching for session, users, and data synchronization

---

## Overview

The Caching module manages three distinct cache types - session, users, and data - automatically synchronized between Python server and web clients. Enables real-time state sharing across Terminal↔Web environments without manual synchronization code.

**Key Features:**
- **Session cache**: zOS session info (session ID, mode, logger, etc.)
- **Users cache**: Authenticated users from zAuth (roles, permissions)
- **Data cache**: CRUD operations from zData (models, records)
- Automatic cache population
- Real-time synchronization
- Incremental updates
- Cache invalidation
- Query APIs for cache status

---

## Architecture

### Cache Types

```
Session Cache (cache.py)
├── Stores: zOS session configuration
├── Source: z.session dict
├── Sync: On bridge start, session changes
└── Use: Client needs session context

Users Cache (cache.py)
├── Stores: Authenticated user metadata
├── Source: z.auth user database
├── Sync: On registration, role changes
└── Use: Client needs user info, RBAC

Data Cache (cache.py)
├── Stores: CRUD operation results
├── Source: z.data models/records
├── Sync: On create/update/delete operations
└── Use: Client needs app data, real-time sync
```

### Cache Flow

```
Python Server                    WebSocket Bridge                    Web Client
    │                                  │                                  │
    ├─ z.data.create("tasks", {...})   │                                  │
    │                                  │                                  │
    │─────────────────────────────────>│                                  │
    │         CRUD operation           │                                  │
    │                                  │                                  │
    │                                  ├─ Update data cache               │
    │                                  │                                  │
    │                                  ├─ Broadcast cache event           │
    │                                  │─────────────────────────────────>│
    │                                  │  { event: "cache_update",        │
    │                                  │    cache_type: "data",          │
    │                                  │    payload: {...} }              │
    │                                  │                                  │
    │                                  │                                  ├─ Update local cache
    │                                  │                                  ├─ Re-render UI
```

---

## CacheManager Class

### Initialization

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import CacheManager

cache_mgr = CacheManager(
    zos=z,
    logger=z.logger,
    session=z.session
)
```

**Attributes:**
- `zos`: zOS framework instance
- `logger`: Logger instance
- `session`: Session dict from zOS
- `session_cache`: Session configuration cache
- `users_cache`: User metadata cache
- `data_cache`: CRUD operation cache

---

### Session Cache Methods

#### `populate_session_cache() -> None`

**Purpose:** Populate session cache from zOS session

```python
cache_mgr.populate_session_cache()
```

**Cached data:**
```python
{
    'zS_id': 'session_id_123',
    'title': 'my-app',
    'zMode': 'zBifrost',
    'zLogger': 'INFO',
    'logger_path': './logs',
    'zSpace': '/path/to/workspace',
    'virtual_env': None,
    'zTraceback': True,
}
```

**Behavior:**
- Reads from `z.session` dict
- Filters sensitive data (not exposed to clients)
- Broadcasts cache update to all clients
- Called automatically on bridge start

---

#### `get_session_cache() -> Dict`

**Purpose:** Get current session cache

```python
session = cache_mgr.get_session_cache()
print(f"Session ID: {session['zS_id']}")
print(f"Mode: {session['zMode']}")
```

**Returns:**
- `Dict`: Session configuration
- `{}`: Empty if not populated

---

#### `update_session_cache(key: str, value: Any) -> None`

**Purpose:** Update specific session cache key

```python
# Update logger level
cache_mgr.update_session_cache('zLogger', 'DEBUG')

# Broadcasts to all clients automatically
```

**Parameters:**
- `key`: Session key to update
- `value`: New value

**Behavior:**
- Updates internal cache
- Broadcasts incremental update
- Logs cache update

---

### Users Cache Methods

#### `populate_users_cache() -> None`

**Purpose:** Populate users cache from zAuth

```python
cache_mgr.populate_users_cache()
```

**Cached data:**
```python
[
    {
        'id': 1,
        'username': 'alice',
        'role': 'admin',
        'created_at': 1234567890.123,
        # Note: password hash NOT included
    },
    {
        'id': 2,
        'username': 'bob',
        'role': 'user',
        'created_at': 1234567890.456,
    }
]
```

**Behavior:**
- Queries z.auth for all users
- Filters sensitive data (passwords, tokens)
- Broadcasts cache update to all clients
- Called automatically on bridge start (if auth enabled)

---

#### `get_users_cache() -> List[Dict]`

**Purpose:** Get current users cache

```python
users = cache_mgr.get_users_cache()
for user in users:
    print(f"User: {user['username']}, Role: {user['role']}")
```

**Returns:**
- `List[Dict]`: User metadata list
- `[]`: Empty if not populated

---

#### `add_user_to_cache(user: Dict) -> None`

**Purpose:** Add new user to cache (on registration)

```python
# When user registers via zAuth
new_user = {
    'id': 3,
    'username': 'charlie',
    'role': 'user',
    'created_at': time.time()
}
cache_mgr.add_user_to_cache(new_user)

# Broadcasts to all clients automatically
```

**Parameters:**
- `user`: User metadata dict

**Behavior:**
- Adds to internal cache
- Broadcasts incremental update
- Used by authentication module

---

#### `update_user_in_cache(user_id: int, updates: Dict) -> None`

**Purpose:** Update existing user in cache

```python
# Change user role
cache_mgr.update_user_in_cache(user_id=2, updates={'role': 'admin'})

# Broadcasts to all clients automatically
```

**Parameters:**
- `user_id`: User ID to update
- `updates`: Dict of fields to update

**Behavior:**
- Updates internal cache
- Broadcasts incremental update
- Used by authentication module

---

#### `remove_user_from_cache(user_id: int) -> None`

**Purpose:** Remove user from cache (on deletion)

```python
cache_mgr.remove_user_from_cache(user_id=3)

# Broadcasts to all clients automatically
```

---

### Data Cache Methods

#### `populate_data_cache() -> None`

**Purpose:** Populate data cache from zData

```python
cache_mgr.populate_data_cache()
```

**Cached data:**
```python
{
    'tasks': [
        {'id': 1, 'title': 'Learn zBifrost', 'done': False},
        {'id': 2, 'title': 'Build app', 'done': False},
    ],
    'users_data': [
        {'id': 1, 'name': 'Alice', 'email': 'alice@example.com'},
    ],
    # One key per zData model
}
```

**Behavior:**
- Queries z.data for all models
- Reads all records per model
- Broadcasts cache update to all clients
- Called automatically on bridge start

---

#### `get_data_cache(model: str = None) -> Union[Dict, List]`

**Purpose:** Get data cache (all models or specific model)

```python
# Get all models
all_data = cache_mgr.get_data_cache()
print(f"Models: {list(all_data.keys())}")

# Get specific model
tasks = cache_mgr.get_data_cache(model='tasks')
print(f"{len(tasks)} tasks cached")
```

**Parameters:**
- `model` (optional): Specific model name

**Returns:**
- `Dict`: All models (if model=None)
- `List`: Records for specific model
- `{}` or `[]`: Empty if not found

---

#### `add_data_to_cache(model: str, record: Dict) -> None`

**Purpose:** Add new record to data cache (on create)

```python
# When z.data.create() is called
new_task = {'id': 3, 'title': 'New task', 'done': False}
cache_mgr.add_data_to_cache(model='tasks', record=new_task)

# Broadcasts to all clients automatically
```

**Parameters:**
- `model`: Model name
- `record`: Record dict

**Behavior:**
- Adds to internal cache for that model
- Broadcasts incremental update
- Used by data CRUD bridge

---

#### `update_data_in_cache(model: str, record_id: int, updates: Dict) -> None`

**Purpose:** Update existing record in cache

```python
# When z.data.update() is called
cache_mgr.update_data_in_cache(
    model='tasks',
    record_id=1,
    updates={'done': True}
)

# Broadcasts to all clients automatically
```

**Parameters:**
- `model`: Model name
- `record_id`: Record ID to update
- `updates`: Dict of fields to update

**Behavior:**
- Updates internal cache
- Broadcasts incremental update
- Used by data CRUD bridge

---

#### `remove_data_from_cache(model: str, record_id: int) -> None`

**Purpose:** Remove record from cache (on delete)

```python
# When z.data.delete() is called
cache_mgr.remove_data_from_cache(model='tasks', record_id=2)

# Broadcasts to all clients automatically
```

---

### Cache Status Methods

#### `get_cache_status() -> Dict`

**Purpose:** Get comprehensive cache status

```python
status = cache_mgr.get_cache_status()
# {
#     'session': {
#         'cached': True,
#         'keys': ['zS_id', 'zMode', 'zLogger', ...]
#     },
#     'users': {
#         'cached': True,
#         'count': 5
#     },
#     'data': {
#         'cached': True,
#         'models': ['tasks', 'users_data'],
#         'record_counts': {
#             'tasks': 10,
#             'users_data': 5
#         }
#     }
# }
```

**Returns:**
- Session cache status
- Users cache status
- Data cache status
- Record counts per model

---

#### `invalidate_cache(cache_type: str) -> None`

**Purpose:** Clear and repopulate specific cache

```python
# Invalidate users cache
cache_mgr.invalidate_cache('users')

# Invalidate all caches
cache_mgr.invalidate_cache('all')
```

**Parameters:**
- `cache_type`: "session", "users", "data", or "all"

**Behavior:**
- Clears internal cache
- Repopulates from source
- Broadcasts full cache update

---

## Cache Events

### Event Schema

**Cache events broadcast to clients:**

```javascript
{
    event: 'cache_update',
    cache_type: 'data',  // session | users | data
    update_type: 'incremental',  // full | incremental
    payload: {
        // Cache-specific payload
    },
    timestamp: 1234567890.123
}
```

---

### Session Cache Events

**Full update (on populate):**
```javascript
{
    event: 'cache_update',
    cache_type: 'session',
    update_type: 'full',
    payload: {
        zS_id: 'session_id_123',
        title: 'my-app',
        zMode: 'zBifrost',
        // ... full session dict
    }
}
```

**Incremental update (on change):**
```javascript
{
    event: 'cache_update',
    cache_type: 'session',
    update_type: 'incremental',
    payload: {
        zLogger: 'DEBUG'  // Only changed field
    }
}
```

---

### Users Cache Events

**Full update (on populate):**
```javascript
{
    event: 'cache_update',
    cache_type: 'users',
    update_type: 'full',
    payload: [
        { id: 1, username: 'alice', role: 'admin' },
        { id: 2, username: 'bob', role: 'user' }
    ]
}
```

**Add user:**
```javascript
{
    event: 'cache_update',
    cache_type: 'users',
    update_type: 'add',
    payload: {
        id: 3,
        username: 'charlie',
        role: 'user'
    }
}
```

**Update user:**
```javascript
{
    event: 'cache_update',
    cache_type: 'users',
    update_type: 'update',
    payload: {
        id: 2,
        updates: { role: 'admin' }
    }
}
```

**Remove user:**
```javascript
{
    event: 'cache_update',
    cache_type: 'users',
    update_type: 'remove',
    payload: {
        id: 3
    }
}
```

---

### Data Cache Events

**Full update (on populate):**
```javascript
{
    event: 'cache_update',
    cache_type: 'data',
    update_type: 'full',
    payload: {
        tasks: [
            { id: 1, title: 'Task 1', done: false },
            { id: 2, title: 'Task 2', done: true }
        ],
        users_data: [...]
    }
}
```

**Add record:**
```javascript
{
    event: 'cache_update',
    cache_type: 'data',
    update_type: 'add',
    model: 'tasks',
    payload: {
        id: 3,
        title: 'New task',
        done: false
    }
}
```

**Update record:**
```javascript
{
    event: 'cache_update',
    cache_type: 'data',
    update_type: 'update',
    model: 'tasks',
    payload: {
        id: 1,
        updates: { done: true }
    }
}
```

**Remove record:**
```javascript
{
    event: 'cache_update',
    cache_type: 'data',
    update_type: 'remove',
    model: 'tasks',
    payload: {
        id: 2
    }
}
```

---

## Client-Side Integration

### JavaScript Cache Handler

```javascript
class BifrostCache {
    constructor() {
        this.session = {};
        this.users = [];
        this.data = {};
    }
    
    handleCacheUpdate(event) {
        switch(event.cache_type) {
            case 'session':
                this.updateSession(event);
                break;
            case 'users':
                this.updateUsers(event);
                break;
            case 'data':
                this.updateData(event);
                break;
        }
    }
    
    updateSession(event) {
        if (event.update_type === 'full') {
            this.session = event.payload;
        } else if (event.update_type === 'incremental') {
            Object.assign(this.session, event.payload);
        }
        this.onSessionUpdate(this.session);
    }
    
    updateUsers(event) {
        if (event.update_type === 'full') {
            this.users = event.payload;
        } else if (event.update_type === 'add') {
            this.users.push(event.payload);
        } else if (event.update_type === 'update') {
            const user = this.users.find(u => u.id === event.payload.id);
            if (user) Object.assign(user, event.payload.updates);
        } else if (event.update_type === 'remove') {
            this.users = this.users.filter(u => u.id !== event.payload.id);
        }
        this.onUsersUpdate(this.users);
    }
    
    updateData(event) {
        if (event.update_type === 'full') {
            this.data = event.payload;
        } else if (event.update_type === 'add') {
            if (!this.data[event.model]) this.data[event.model] = [];
            this.data[event.model].push(event.payload);
        } else if (event.update_type === 'update') {
            const records = this.data[event.model];
            const record = records.find(r => r.id === event.payload.id);
            if (record) Object.assign(record, event.payload.updates);
        } else if (event.update_type === 'remove') {
            this.data[event.model] = this.data[event.model].filter(
                r => r.id !== event.payload.id
            );
        }
        this.onDataUpdate(event.model, this.data[event.model]);
    }
    
    // Override these in your app
    onSessionUpdate(session) {}
    onUsersUpdate(users) {}
    onDataUpdate(model, records) {}
}

// Usage
const cache = new BifrostCache();

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.event === 'cache_update') {
        cache.handleCacheUpdate(data);
    }
};

// React to cache updates
cache.onDataUpdate = (model, records) => {
    if (model === 'tasks') {
        renderTasks(records);
    }
};
```

---

## Examples

### Complete Cache Setup

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "cache-demo",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
    "websocket": {
        "require_auth": True,
        "auth_tier": "application",
    }
}

z = zOS(zSpark)

# Register users (auto-cached)
z.auth.register_user("alice", "pass123", role="admin")
z.auth.register_user("bob", "pass456", role="user")

# Create data (auto-cached)
z.data.create("tasks", {"id": 1, "title": "Task 1", "done": False})
z.data.create("tasks", {"id": 2, "title": "Task 2", "done": False})

# Check cache status
status = z.bifrost.get_cache_status()
print(f"Session cached: {status['session']['cached']}")
print(f"Users cached: {status['users']['count']}")
print(f"Data models: {status['data']['models']}")

# Update data (broadcasts automatically)
z.data.update("tasks", record_id=1, updates={"done": True})

# Update user role (broadcasts automatically)
z.auth.update_user_role("bob", "admin")

input("Press Enter to stop...")
```

---

### Manual Cache Invalidation

```python
# Invalidate specific cache
z.bifrost.cache.invalidate_cache('data')

# Invalidate all caches
z.bifrost.cache.invalidate_cache('all')

# Check cache status after invalidation
status = z.bifrost.get_cache_status()
```

---

## Best Practices

### Cache Population

1. **Auto-population on bridge start:**
   - Session cache always populated
   - Users cache populated if auth enabled
   - Data cache populated if zData initialized

2. **Manual repopulation:**
   ```python
   # Force repopulate
   z.bifrost.cache.populate_data_cache()
   ```

### Cache Updates

1. **Use subsystem methods:**
   ```python
   # Good: Uses zData (auto-cached)
   z.data.create("tasks", {...})
   
   # Bad: Manual cache update (not synced with zData)
   z.bifrost.cache.add_data_to_cache("tasks", {...})
   ```

2. **Incremental updates preferred:**
   - Faster than full cache reloads
   - Less bandwidth usage
   - Better client performance

### Client-Side Caching

1. **Handle all update types:**
   ```javascript
   if (event.update_type === 'full') {
       // Replace entire cache
   } else if (event.update_type === 'add') {
       // Add to cache
   } else if (event.update_type === 'update') {
       // Update existing
   } else if (event.update_type === 'remove') {
       // Remove from cache
   }
   ```

2. **Debounce UI updates:**
   ```javascript
   // Avoid re-rendering on every cache update
   const debouncedRender = debounce(renderUI, 100);
   cache.onDataUpdate = debouncedRender;
   ```

---

## Troubleshooting

### Cache Not Populating

**Check:**
1. Bridge running?
2. Required subsystems initialized?
3. Data exists in source?

**Debug:**
```python
# Check cache status
status = z.bifrost.get_cache_status()
print(f"Session cached: {status['session']['cached']}")
print(f"Users count: {status['users']['count']}")

# Manually populate
z.bifrost.cache.populate_session_cache()
z.bifrost.cache.populate_users_cache()
z.bifrost.cache.populate_data_cache()
```

### Cache Updates Not Broadcasting

**Check:**
1. Clients connected?
2. Clients authenticated?
3. WebSocket connection active?

**Debug:**
```python
# Check connected clients
clients = z.bifrost.get_connected_clients()
print(f"{len(clients)} clients connected")

# Check cache broadcasting
z.bifrost.cache.add_data_to_cache('tasks', {'id': 999, 'test': True})
```

### Cache Out of Sync

**Solution:** Invalidate and repopulate

```python
# Force full refresh
z.bifrost.cache.invalidate_cache('all')
```

---

## Related Modules

- **Authentication Module** - User cache source (see [authentication_GUIDE.md](authentication_GUIDE.md))
- **Events Module** - Cache event broadcasting (see [events_GUIDE.md](events_GUIDE.md))
- **Connection Module** - Client tracking (see [connection_GUIDE.md](connection_GUIDE.md))
- **zData Subsystem** - Data cache source (see [../zData_GUIDE.md](../zData_GUIDE.md))
- **zAuth Subsystem** - User cache source (see [../zAuth_GUIDE.md](../zAuth_GUIDE.md))

---

**See also:**
- [zBifrost Main Guide](../zBifrost_GUIDE.md) - Complete facade overview
- [Authentication Guide](authentication_GUIDE.md) - User management
- [Connection Guide](connection_GUIDE.md) - WebSocket lifecycle
- [Events Guide](events_GUIDE.md) - Event routing
