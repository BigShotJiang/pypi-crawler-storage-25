# zBifrost Events Module Guide

> **Modules:** `message_handler.py`, `message_walker.py`, `message_utils.py`, `message_walker_support.py`, `events/base_event_handler.py`, `events/bridge_event_dispatch.py`, `events/bridge_event_client.py`, `events/bridge_event_cache.py`, `events/bridge_event_discovery.py`, `events/bridge_event_menu.py`  
> **Purpose:** Event routing, message handling, and dispatch coordination

---

## Overview

The Events modules handle incoming message routing and outgoing event broadcasting. Coordinates Terminal↔Web communication by dispatching display events, client events, cache events, discovery handshakes, and menu interactions.

**Key Features:**
- Message routing by type (display, client, cache, data, walker, discovery)
- Event dispatching to appropriate handlers
- Display event synchronization (Terminal→Web)
- Client event management (connection, authentication)
- Cache event broadcasting (session, users, data)
- Discovery handshake coordination
- Walker menu event routing
- Message utilities and support functions

---

## Architecture

### Event Flow

```
Web Client                    WebSocket Bridge                    Python Server
    │                                  │                                  │
    │─── Send message ───────────────>│                                  │
    │         (JSON)                   │                                  │
    │                                  ├─ Parse message type              │
    │                                  │                                  │
    │                                  ├─ Route to handler:               │
    │                                  │   - display_* → Display handler  │
    │                                  │   - client_* → Client handler    │
    │                                  │   - cache_* → Cache handler      │
    │                                  │   - data_* → zData integration   │
    │                                  │   - walker_* → Walker handler    │
    │                                  │   - discovery_* → Discovery      │
    │                                  │                                  │
    │                                  │─────────────────────────────────>│
    │                                  │         Process in subsystem      │
    │                                  │                                  │
    │                                  │<─────────────────────────────────│
    │                                  │         Result/Response           │
    │                                  │                                  │
    │                                  ├─ Broadcast event                 │
    │<───── Receive event ─────────────│                                  │
    │         (JSON)                   │                                  │
```

---

## Message Handler

### MessageHandler Class

**Purpose:** Route incoming WebSocket messages to appropriate handlers

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import MessageHandler

msg_handler = MessageHandler(
    zos=z,
    logger=z.logger,
    cache=cache_mgr,
    auth=auth_mgr
)
```

**Attributes:**
- `zos`: zOS framework instance
- `logger`: Logger instance
- `cache`: CacheManager instance
- `auth`: AuthenticationManager instance
- `handlers`: Dict mapping message types to handlers

---

### Routing Logic

**Message routing table:**

| Message Prefix | Handler | Module |
|---------------|---------|--------|
| `display_` | Display event handler | bridge_event_dispatch.py |
| `client_` | Client event handler | bridge_event_client.py |
| `cache_` | Cache event handler | bridge_event_cache.py |
| `data_` | Data CRUD handler | zData integration |
| `walker_` | Walker menu handler | message_walker.py |
| `discovery_` | Discovery handler | bridge_event_discovery.py |
| `menu_` | Menu event handler | bridge_event_menu.py |

---

### Method: handle_message()

```python
async def handle_message(websocket, message: str) -> None:
    """
    Route incoming message to appropriate handler.
    
    Args:
        websocket: Client WebSocket connection
        message: JSON string message
    """
```

**Process:**
1. Parse JSON message
2. Extract message type/action
3. Route to registered handler
4. Handle errors gracefully
5. Log message handling

---

## Event Handlers

### Base Event Handler

**BaseEventHandler** provides common functionality:

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import BaseEventHandler

class CustomHandler(BaseEventHandler):
    def __init__(self, zos, logger):
        super().__init__(zos, logger)
    
    async def handle_event(self, websocket, data):
        # Custom event handling
        pass
```

**Attributes:**
- `zos`: zOS framework instance
- `logger`: Logger instance

**Methods:**
- `broadcast_event(event)`: Send event to all clients
- `send_to_client(websocket, event)`: Send to specific client
- `validate_event(data)`: Validate event schema
- `log_event(event_type, details)`: Log event handling

---

### Display Event Handler

**Purpose:** Synchronize terminal display events to web clients

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import DisplayEventHandler

display_handler = DisplayEventHandler(zos=z, logger=z.logger)
```

**Handled events:**
- `display_header`: Header rendering
- `display_text`: Text output
- `display_table`: Table rendering
- `display_list`: List rendering
- `display_input`: Input prompt
- `display_clear`: Clear screen
- `display_progress`: Progress bar
- All other `z.display.*` methods

**Event schema:**
```javascript
{
    event: 'display_header',
    payload: {
        text: 'Welcome to zBifrost',
        level: 1,
        style: 'default'
    },
    timestamp: 1234567890.123
}
```

**Process:**
1. Intercept `z.display.*` calls
2. Extract display parameters
3. Format as event dict
4. Broadcast to all connected clients
5. Render in terminal (original behavior preserved)

---

### Client Event Handler

**Purpose:** Manage client connection events

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import ClientEventHandler

client_handler = ClientEventHandler(zos=z, logger=z.logger)
```

**Handled events:**
- `client_connected`: New client connection
- `client_disconnected`: Client disconnection
- `client_authenticated`: Authentication success
- `client_auth_failed`: Authentication failure
- `client_metadata_update`: Client info changed

**Event schema:**
```javascript
{
    event: 'client_connected',
    payload: {
        address: '127.0.0.1:12345',
        timestamp: 1234567890.123
    }
}
```

**Use cases:**
- Show connected users list
- Display connection status
- Track active sessions
- Audit logging

---

### Cache Event Handler

**Purpose:** Broadcast cache updates to clients

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import CacheEventHandler

cache_handler = CacheEventHandler(zos=z, logger=z.logger, cache=cache_mgr)
```

**Handled events:**
- `cache_session_update`: Session cache changed
- `cache_users_update`: Users cache changed
- `cache_data_update`: Data cache changed
- `cache_invalidate`: Cache cleared

**Event schema:**
```javascript
{
    event: 'cache_update',
    cache_type: 'data',
    update_type: 'add',
    model: 'tasks',
    payload: {
        id: 3,
        title: 'New task',
        done: false
    }
}
```

**Integration:** See [caching_GUIDE.md](caching_GUIDE.md) for detailed cache event handling.

---

### Discovery Event Handler

**Purpose:** Client handshake and capability negotiation

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import DiscoveryEventHandler

discovery_handler = DiscoveryEventHandler(zos=z, logger=z.logger)
```

**Handled events:**
- `discovery_hello`: Client announces presence
- `discovery_capabilities`: Client capabilities query
- `discovery_version`: Version compatibility check
- `discovery_config`: Configuration request

**Event schema:**
```javascript
// Client → Server
{
    event: 'discovery_hello',
    client_version: '1.0.0',
    capabilities: ['display', 'cache', 'walker']
}

// Server → Client
{
    event: 'discovery_welcome',
    server_version: '2.0.0',
    session_id: 'session_id_123',
    capabilities: ['display', 'cache', 'walker', 'data']
}
```

**Process:**
1. Client sends discovery_hello on connection
2. Server validates version compatibility
3. Server responds with discovery_welcome
4. Client receives session info and capabilities
5. Handshake complete - client ready

---

### Menu Event Handler

**Purpose:** Interactive menu coordination with zWalker

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import MenuEventHandler

menu_handler = MenuEventHandler(zos=z, logger=z.logger)
```

**Handled events:**
- `menu_show`: Display menu options
- `menu_select`: User selected option
- `menu_navigate`: Navigate menu hierarchy
- `menu_input`: Menu input prompt
- `menu_close`: Close menu

**Event schema:**
```javascript
// Server → Client (show menu)
{
    event: 'menu_show',
    menu_id: 'main-menu',
    title: 'Main Menu',
    options: [
        { id: 1, label: 'Option 1', action: 'action1' },
        { id: 2, label: 'Option 2', action: 'action2' }
    ]
}

// Client → Server (user selection)
{
    event: 'menu_select',
    menu_id: 'main-menu',
    option_id: 1
}
```

**Integration:** Coordinates with zWalker subsystem for menu navigation.

---

## Walker Message Coordination

### MessageWalker Module

**Purpose:** Coordinate walker-specific messages (zWalker integration)

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import MessageWalker

walker = MessageWalker(zos=z, logger=z.logger)
```

**Handled messages:**
- Walker menu navigation
- User input coordination
- Walker state synchronization
- Menu option selection

**Integration points:**
- **zWalker subsystem**: Menu navigation logic
- **zDisplay subsystem**: Menu rendering
- **WebSocket clients**: User interaction

---

### Walker Support Utilities

**MessageWalkerSupport** provides helper functions:

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import MessageWalkerSupport

# Format walker menu for web client
menu_data = MessageWalkerSupport.format_menu(walker_menu)

# Parse walker selection
selection = MessageWalkerSupport.parse_selection(message)

# Validate walker state
is_valid = MessageWalkerSupport.validate_walker_state(state)
```

---

## Message Utilities

### MessageUtils Module

**Purpose:** Common message processing utilities

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import MessageUtils

# Parse JSON message safely
data = MessageUtils.parse_message(message)

# Extract message type
msg_type = MessageUtils.get_message_type(data)

# Validate message schema
is_valid = MessageUtils.validate_schema(data, schema)

# Format error response
error_event = MessageUtils.format_error('Invalid action', code=400)
```

**Utilities:**
- JSON parsing with error handling
- Message type extraction
- Schema validation
- Error formatting
- Timestamp utilities
- Message truncation (for logging)

---

## Custom Event Handling

### Registering Custom Handlers

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules import MessageHandler

# Create custom handler
async def handle_custom(websocket, data):
    action = data.get('action')
    if action == 'custom_action':
        result = process_custom_action(data)
        await websocket.send(json.dumps({
            'event': 'custom_response',
            'result': result
        }))

# Register with message handler
msg_handler.register_handler('custom_', handle_custom)
```

---

### Creating Event Classes

```python
from zOS.core.L3_Abstraction.n_zBifrost.zBifrost_modules.events import BaseEventHandler

class CustomEventHandler(BaseEventHandler):
    def __init__(self, zos, logger):
        super().__init__(zos, logger)
        self.event_type = 'custom'
    
    async def handle_event(self, websocket, data):
        """Process custom event."""
        action = data.get('action')
        
        # Process action
        result = self.process_action(action, data)
        
        # Broadcast response
        await self.broadcast_event({
            'event': 'custom_result',
            'result': result
        })
    
    def process_action(self, action, data):
        # Custom logic
        return {'status': 'success'}
```

---

## Event Broadcasting

### Broadcast Methods

**Broadcast to all clients:**
```python
await msg_handler.broadcast({
    'event': 'system_notification',
    'message': 'Server maintenance in 5 minutes'
})
```

**Broadcast to authenticated clients:**
```python
await msg_handler.broadcast_to_authenticated({
    'event': 'user_notification',
    'message': 'New message received'
})
```

**Send to specific client:**
```python
await msg_handler.send_to_client(websocket, {
    'event': 'direct_message',
    'message': 'Hello Alice!'
})
```

---

## Error Handling

### Error Event Schema

```javascript
{
    event: 'error',
    error_type: 'validation_error',
    message: 'Invalid action',
    code: 400,
    details: {
        field: 'action',
        expected: 'string',
        received: 'null'
    },
    timestamp: 1234567890.123
}
```

### Error Types

| Error Type | Description | Code |
|-----------|-------------|------|
| `validation_error` | Invalid message schema | 400 |
| `authentication_error` | Auth failure | 401 |
| `permission_error` | Insufficient permissions | 403 |
| `not_found_error` | Resource not found | 404 |
| `internal_error` | Server error | 500 |

---

## Examples

### Complete Event Handling Setup

```python
from zOS import zOS

zSpark = {
    "deployment": "Development",
    "title": "events-demo",
    "logger": "INFO",
    "logger_path": "./logs",
    "zMode": "zBifrost",
}

z = zOS(zSpark)

# Display events auto-synchronized
z.display.header("Terminal→Web Sync")
z.display.text("This appears in both terminal and browser!")

# Custom event handler
async def handle_custom_message(websocket, message):
    import json
    data = json.loads(message)
    
    if data.get('action') == 'ping':
        await websocket.send(json.dumps({
            'event': 'pong',
            'timestamp': time.time()
        }))

# Register custom handler
z.bifrost.websocket.handler = handle_custom_message

input("Press Enter to stop...")
```

---

### Client-Side Event Handling

```javascript
class BifrostClient {
    constructor(wsUrl) {
        this.ws = new WebSocket(wsUrl);
        this.handlers = {};
        
        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleEvent(data);
        };
    }
    
    registerHandler(eventType, handler) {
        this.handlers[eventType] = handler;
    }
    
    handleEvent(data) {
        const eventType = data.event;
        const handler = this.handlers[eventType];
        
        if (handler) {
            handler(data);
        } else {
            console.warn('No handler for event:', eventType);
        }
    }
    
    send(event) {
        this.ws.send(JSON.stringify(event));
    }
}

// Usage
const client = new BifrostClient('ws://127.0.0.1:56891');

// Register display handler
client.registerHandler('display_header', (data) => {
    const header = document.createElement('h1');
    header.textContent = data.payload.text;
    document.body.appendChild(header);
});

// Register cache handler
client.registerHandler('cache_update', (data) => {
    if (data.cache_type === 'data') {
        updateLocalCache(data.payload);
        renderUI();
    }
});

// Send custom event
client.send({
    action: 'ping'
});
```

---

## Best Practices

### Message Design

1. **Use consistent schema:**
   ```javascript
   {
       event: 'event_type',
       payload: { /* event data */ },
       timestamp: Date.now()
   }
   ```

2. **Include error handling:**
   ```python
   try:
       data = json.loads(message)
       await process_message(data)
   except Exception as e:
       await send_error(websocket, str(e))
   ```

3. **Validate inputs:**
   ```python
   if not data.get('action'):
       await send_error(websocket, 'Missing action field')
       return
   ```

### Event Routing

1. **Use prefixes for clarity:**
   - `display_*` for display events
   - `client_*` for client events
   - `cache_*` for cache events
   - `custom_*` for custom events

2. **Register handlers early:**
   ```python
   # Register before bridge start
   msg_handler.register_handler('custom_', handler)
   z.bifrost.start()
   ```

### Performance

1. **Avoid heavy processing in handlers:**
   ```python
   # Good: Offload to background
   async def handler(websocket, data):
       asyncio.create_task(process_heavy_task(data))
       await websocket.send('Processing...')
   
   # Bad: Block event loop
   async def handler(websocket, data):
       result = process_heavy_task(data)  # Blocks!
       await websocket.send(result)
   ```

2. **Batch events when possible:**
   ```python
   # Good: Batch multiple updates
   await broadcast({
       'event': 'batch_update',
       'updates': [update1, update2, update3]
   })
   
   # Bad: Send individual events
   await broadcast(update1)
   await broadcast(update2)
   await broadcast(update3)
   ```

---

## Troubleshooting

### Events Not Received

**Check:**
1. WebSocket connection active?
2. Client event listener registered?
3. Event format valid JSON?

**Debug:**
```python
# Enable message logging
z.logger.setLevel('DEBUG')

# Log all broadcasts
await z.bifrost.broadcast({
    'event': 'test',
    'message': 'Testing...'
})
```

### Handler Not Called

**Check:**
1. Handler registered correctly?
2. Message prefix matches?
3. Handler function signature correct?

**Debug:**
```python
# Check registered handlers
print(msg_handler.handlers.keys())

# Test handler directly
await test_handler(websocket, message)
```

### Invalid Message Format

**Check:**
1. Valid JSON?
2. Required fields present?
3. Data types correct?

**Debug:**
```python
# Validate message
try:
    data = json.loads(message)
    print(f"Parsed: {data}")
except json.JSONDecodeError as e:
    print(f"Invalid JSON: {e}")
```

---

## Related Modules

- **Connection Module** - Client tracking (see [connection_GUIDE.md](connection_GUIDE.md))
- **Caching Module** - Cache events (see [caching_GUIDE.md](caching_GUIDE.md))
- **Authentication Module** - Client auth events (see [authentication_GUIDE.md](authentication_GUIDE.md))
- **zDisplay Subsystem** - Display event source (see [../zDisplay_GUIDE.md](../zDisplay_GUIDE.md))
- **zWalker Subsystem** - Walker menu events (see [../zWalker_GUIDE.md](../zWalker_GUIDE.md))

---

**See also:**
- [zBifrost Main Guide](../zBifrost_GUIDE.md) - Complete facade overview
- [Connection Guide](connection_GUIDE.md) - WebSocket lifecycle
- [Caching Guide](caching_GUIDE.md) - Cache synchronization
- [Authentication Guide](authentication_GUIDE.md) - User management
