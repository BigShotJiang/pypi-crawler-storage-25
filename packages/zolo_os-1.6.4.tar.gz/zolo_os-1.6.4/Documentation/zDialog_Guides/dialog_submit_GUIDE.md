# zDialog Submit Module Guide

> **Module:** `zOS/core/L2_Handling/j_zDialog/dialog_modules/dialog_submit.py`  
> **Purpose:** Submission handling for zDialog forms via zDispatch.

---

## Overview

The `dialog_submit` module provides **Tier 2** submission handling for the zDialog subsystem:

1. **Dict-based submission** - Pure declarative paradigm via zDispatch
2. **Placeholder injection** - Automatic zConv.* and %session.* resolution
3. **Model injection** - Smart model reference injection for zData/zCRUD
4. **Session interpolation** - Access session variables in onSubmit

| Function | Purpose |
|---|---|
| `handle_submit()` | Main entry point for onSubmit processing |
| `_handle_dict_submit()` | Process dict-based submissions via zDispatch |
| `_inject_model_if_needed()` | Smart model injection logic |
| `_interpolate_session_values()` | Session placeholder resolution |

---

## Architecture: Tier 2 Submit Handler

```
Tier 5: Package Root (__init__.py)
Tier 4: Facade (zDialog.py)
Tier 3: Package Aggregator (dialog_modules/__init__.py)
Tier 2: Submit Handler (dialog_submit.py) ← This module
Tier 1: Foundation (dialog_context.py)
```

**Design rationale:**
- **Depends on Tier 1** - Uses `inject_placeholders()` from dialog_context
- **Used by Tier 4** - Called by zDialog.handle() for submission
- **Pure declarative** - Dict-based only (string-based removed in v1.5.4)

---

## Public Functions

### `handle_submit()`

Main entry point for onSubmit expression processing.

**Signature:**
```python
def handle_submit(
    submit_expr: Any,
    zContext: Dict[str, Any],
    logger: Any,
    walker: Optional[Any]
) -> Any
```

**Parameters:**
| Parameter | Type | Description |
|---|---|---|
| `submit_expr` | `Any` | onSubmit expression (must be dict) |
| `zContext` | `Dict[str, Any]` | Dialog context with model, zConv, session |
| `logger` | `Any` | Logger instance for debug output |
| `walker` | `Optional[Any]` | Walker instance (for zDispatch access) |

**Returns:**
- **Success**: Result from zDispatch execution
- **Invalid type**: `False` (logs error)
- **No walker**: `False` (logs error)

**Example 1 - Basic dict submission:**
```python
submit_expr = {
    "zData": {
        "query": "INSERT INTO users (name) VALUES (zConv.username)"
    }
}

zContext = {
    "model": "@.zSchema.users",
    "zConv": {"username": "alice"}
}

result = handle_submit(submit_expr, zContext, logger, walker)

# 1. Injects placeholders: "INSERT INTO users (name) VALUES ('alice')"
# 2. Executes via zDispatch: handle_zDispatch({"zData": {...}}, ...)
# 3. Returns: Result from zData execution
```

**Example 2 - Invalid type:**
```python
submit_expr = "some_string"  # Invalid (string-based removed)
result = handle_submit(submit_expr, zContext, logger, walker)

# Logs error: "Invalid onSubmit type: str"
# Returns: False
```

---

## Submission Flow

### Dict-Based Submission (Pure Declarative)

**Flow:**
1. Session interpolation: `%session.*` → actual values
2. Placeholder injection: `zConv.*` → form data
3. Model injection: Add model reference if needed
4. zDispatch execution: `handle_zDispatch()`
5. Return result

**Example:**
```python
# Original onSubmit
submit_expr = {
    "zData": {
        "query": "INSERT INTO posts (author_id, title) VALUES (%session.user_id, zConv.title)"
    }
}

# Step 1: Session interpolation
# %session.user_id → 123
{
    "zData": {
        "query": "INSERT INTO posts (author_id, title) VALUES (123, zConv.title)"
    }
}

# Step 2: Placeholder injection
# zConv.title → 'My Post'
{
    "zData": {
        "query": "INSERT INTO posts (author_id, title) VALUES (123, 'My Post')"
    }
}

# Step 3: Model injection (if needed)
# Dialog has model="@.zSchema.posts", onSubmit missing model
{
    "zData": {
        "model": "@.zSchema.posts",  # Auto-injected
        "query": "INSERT INTO posts (author_id, title) VALUES (123, 'My Post')"
    }
}

# Step 4: Execute via zDispatch
result = handle_zDispatch(payload, walker, zContext, logger)
```

---

## Placeholder Types

### zConv Placeholders

Access form data using zConv placeholders (see [dialog_context_GUIDE.md](dialog_context_GUIDE.md)):

**Supported syntax:**
- Full: `"zConv"` → entire form data
- Dot notation: `"zConv.username"` → specific field
- Bracket: `"zConv['email']"` → specific field
- Embedded: `"WHERE id = zConv.user_id"` → inline replacement

**Example:**
```python
submit_expr = {
    "zData": {
        "query": "INSERT INTO users (username, email) VALUES (zConv.username, zConv.email)"
    }
}

zContext = {"zConv": {"username": "alice", "email": "alice@example.com"}}

# After injection:
# "INSERT INTO users (username, email) VALUES ('alice', 'alice@example.com')"
```

### Session Placeholders

Access session variables using %session.* syntax:

**Syntax:** `"%session.variable_name"`

**Example:**
```python
submit_expr = {
    "zData": {
        "query": "INSERT INTO posts (author_id, title) VALUES (%session.user_id, zConv.title)"
    }
}

zContext = {
    "zConv": {"title": "My Post"},
    "session": {"user_id": 123}
}

# After session interpolation:
# "INSERT INTO posts (author_id, title) VALUES (123, zConv.title)"
#
# After placeholder injection:
# "INSERT INTO posts (author_id, title) VALUES (123, 'My Post')"
```

**Common session variables:**
- `%session.user_id` - Current user ID
- `%session.zS_id` - Session ID
- `%session.zMode` - Execution mode (zCLI, zBifrost)
- `%session.title` - Session title

---

## Model Injection

### When Model Injection Happens

Model injection occurs when **all** conditions met:

1. Dialog has `model` reference (e.g., `"model": "@.zSchema.users"`)
2. onSubmit contains `zData` or `zCRUD` key
3. onSubmit does **NOT** already have `model` key

**Example - Injection needed:**
```python
# Dialog definition
form_spec = {
    "zDialog": {
        "model": "@.zSchema.users",  # Model defined here
        "fields": [...],
        "onSubmit": {
            "zData": {
                "action": "create",
                "data": "zConv"
                # No model here - injection needed
            }
        }
    }
}

# After injection:
{
    "zData": {
        "model": "@.zSchema.users",  # Auto-injected
        "action": "create",
        "data": "zConv"
    }
}
```

**Example - Injection NOT needed:**
```python
form_spec = {
    "zDialog": {
        "model": "@.zSchema.users",
        "fields": [...],
        "onSubmit": {
            "zData": {
                "model": "@.zSchema.posts",  # Already has model - no injection
                "action": "create",
                "data": "zConv"
            }
        }
    }
}

# No injection - respects explicit model override
```

### Model Injection Logic

The `_inject_model_if_needed()` function handles complex nesting:

**Case 1 - Top-level zData/zCRUD:**
```python
# Before
{"zData": {"action": "create", "data": "zConv"}}

# After
{"zData": {"model": "@.zSchema.users", "action": "create", "data": "zConv"}}
```

**Case 2 - Nested zData/zCRUD:**
```python
# Before
{
    "outer": {
        "zData": {"action": "create", "data": "zConv"}
    }
}

# After
{
    "outer": {
        "zData": {"model": "@.zSchema.users", "action": "create", "data": "zConv"}
    }
}
```

**Case 3 - Multiple zData/zCRUD (injects in all):**
```python
# Before
{
    "zData": {"action": "create", "data": "zConv"},
    "nested": {
        "zCRUD": {"operation": "read"}
    }
}

# After
{
    "zData": {"model": "@.zSchema.users", "action": "create", "data": "zConv"},
    "nested": {
        "zCRUD": {"model": "@.zSchema.users", "operation": "read"}
    }
}
```

**Case 4 - Already has model (no injection):**
```python
# Before
{"zData": {"model": "@.zSchema.posts", "action": "create"}}

# After (unchanged)
{"zData": {"model": "@.zSchema.posts", "action": "create"}}
```

---

## Session Interpolation

### How Session Interpolation Works

The `_interpolate_session_values()` function recursively replaces `%session.*` placeholders:

**Supported types:**
- Strings with `%session.*` syntax
- Dicts (recursive)
- Lists (recursive)
- Other types (unchanged)

**Example 1 - String interpolation:**
```python
obj = "INSERT INTO posts (author_id) VALUES (%session.user_id)"
session = {"user_id": 123}

result = _interpolate_session_values(obj, session, logger)
# Returns: "INSERT INTO posts (author_id) VALUES (123)"
```

**Example 2 - Dict interpolation:**
```python
obj = {
    "query": "WHERE user_id = %session.user_id",
    "params": {
        "role": "%session.role"
    }
}
session = {"user_id": 123, "role": "admin"}

result = _interpolate_session_values(obj, session, logger)
# Returns:
# {
#     "query": "WHERE user_id = 123",
#     "params": {"role": "admin"}
# }
```

**Example 3 - List interpolation:**
```python
obj = [
    "%session.user_id",
    "WHERE role = %session.role"
]
session = {"user_id": 123, "role": "admin"}

result = _interpolate_session_values(obj, session, logger)
# Returns: [123, "WHERE role = admin"]
```

### Regex Pattern

Session interpolation uses this regex pattern:

```python
import re
pattern = r'%session\.(\w+)'

# Matches:
# %session.user_id → Captures "user_id"
# %session.role → Captures "role"
# %session.zS_id → Captures "zS_id"
```

### Error Handling

**Missing session key:**
```python
obj = "WHERE user_id = %session.missing_key"
session = {"user_id": 123}

result = _interpolate_session_values(obj, session, logger)
# Logs warning: "Session key 'missing_key' not found"
# Returns: "WHERE user_id = %session.missing_key" (unchanged)
```

**No session dict:**
```python
obj = "WHERE user_id = %session.user_id"
session = {}

result = _interpolate_session_values(obj, session, logger)
# Returns: "WHERE user_id = %session.user_id" (unchanged, no error)
```

---

## Integration Points

**Used by:**
- `zDialog.py` (line 143) - Submission in `handle()` method

**Dependencies:**
- `dialog_context.py` - `inject_placeholders()`, constants
- `zDispatch.py` - `handle_zDispatch()` for command execution
- `zDisplay.py` - `walker.display.zDeclare()` for visual feedback

**External dependencies:**
- zDispatch subsystem (Layer 2)
- zDisplay subsystem (Layer 1)

---

## Error Handling

### Invalid Submission Type

```python
submit_expr = 123  # Not a dict
result = handle_submit(submit_expr, zContext, logger, walker)

# Logs: "Invalid onSubmit type: int - must be dict"
# Returns: False
```

### No Walker Instance

```python
result = handle_submit(submit_expr, zContext, logger, walker=None)

# Logs: "No walker instance - cannot execute zDispatch"
# Returns: False
```

### zDispatch Execution Failure

```python
# zDispatch raises exception
result = handle_submit(submit_expr, zContext, logger, walker)

# Exception caught and logged
# Visual feedback displayed via zDisplay
# Returns: False
```

---

## Constants

All constants imported from `dialog_constants.py`:

```python
from .dialog_constants import (
    KEY_ZCRUD,                    # "zCRUD"
    KEY_ZDATA,                    # "zData"
    KEY_MODEL,                    # "model"
    KEY_ZCONV,                    # "zConv"
    COLOR_ZDIALOG,                # Display color
    _DISPATCH_CMD_SUBMIT,         # "zDialog onSubmit"
    _STYLE_SINGLE,                # Display style
    _STYLE_TILDE,                 # Display style
    _INDENT_DIALOG,               # Indent level
    _INDENT_SUBMIT,               # Indent level
    _DEBUG_SUBMIT_EXPR,           # Debug message
    _DEBUG_CONTEXT_KEYS,          # Debug message
    _DEBUG_DICT_PAYLOAD,          # Debug message
    _INFO_DISPATCH_DICT,          # Info message
    _ERROR_INVALID_TYPE_SUBMIT,   # Error message
    _ERROR_NO_WALKER,             # Error message
    _ERROR_DISPATCH_FAILED,       # Error message
)
```

---

## Best Practices

### DO:
✅ Use dict-based onSubmit expressions (pure declarative)  
✅ Let model injection handle schema references automatically  
✅ Use session placeholders for user context (%session.user_id)  
✅ Use zConv placeholders for form data (zConv.username)  
✅ Check return value for False (indicates failure)  
✅ Log submission expressions for debugging  

### DON'T:
❌ Use string-based submissions (removed in v1.5.4)  
❌ Manually inject model when not needed (auto-handled)  
❌ Hardcode user IDs (use %session.user_id)  
❌ Assume submission always succeeds (check return value)  
❌ Mix placeholder types incorrectly (use correct syntax)  

---

## Performance Considerations

**Recursive operations:**
- Session interpolation: O(n) where n = object size
- Placeholder injection: O(n) where n = object size
- Model injection: O(n) where n = nesting depth

**Optimization tips:**
- Keep onSubmit expressions shallow (< 5 levels deep)
- Pre-format queries when possible
- Minimize nested zData/zCRUD blocks

---

## Testing

**Unit test coverage:**
- ✅ Dict-based submission (valid and invalid)
- ✅ Session interpolation (strings, dicts, lists)
- ✅ Placeholder injection integration
- ✅ Model injection (all cases)
- ✅ Error handling (invalid types, no walker, dispatch failure)
- ✅ Visual feedback display

**Test files:**
- `tests/test_dialog_submit.py` - Unit tests
- `tests/test_session_interpolation.py` - Session-specific tests

---

## Version History

- **v1.5.4**: Industry-grade refactor + String-based removal
  - **REMOVED**: String-based submissions (architectural purity)
  - Added: Type hints (100% coverage)
  - Added: Constants from dialog_constants
  - Added: Comprehensive docstrings (500+ lines)
  - Enhanced: Error handling and logging
- **v1.5.3**: Dict-based submission support
  - Added: Dict-based submission via zDispatch
  - Added: Session interpolation
  - Added: Model injection logic
- **v1.5.2**: Initial implementation
  - String-based submissions only (removed)

---

**[← Back to zDialog Guide](../zDialog_GUIDE.md)**
