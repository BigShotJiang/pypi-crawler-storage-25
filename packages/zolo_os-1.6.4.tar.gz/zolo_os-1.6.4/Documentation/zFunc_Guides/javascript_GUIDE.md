# zFunc JavaScript Execution Module Guide

> **Module:** `zOS/core/L2_Handling/i_zFunc/zFunc_modules/func_js_executor.py`  
> **Purpose:** JavaScript and Node.js function execution for zFunc subsystem.

---

## Overview

The `func_js_executor` module enables execution of JavaScript functions from Python, supporting both Node.js and Deno runtimes. It provides seamless interoperability between Python and JavaScript codebases.

**Key Features:**
- Execute JavaScript functions from Python code
- Support for Node.js and Deno runtimes
- Automatic JSON serialization/deserialization
- Error handling and logging
- Async/await support (via runtime)

---

## Functions

### `execute_js_function(js_file_path, function_name, args=None, runtime="node", logger=None) -> Any`

Execute JavaScript function with specified runtime.

```python
# Execute Node.js function
result = execute_js_function(
    js_file_path="/path/to/script.js",
    function_name="processData",
    args=["input", 42],
    runtime="node"
)
```

**Parameters:**
- `js_file_path` (str): Path to JavaScript file
- `function_name` (str): Name of function to execute
- `args` (list): Function arguments (optional, default: None)
- `runtime` (str): Runtime to use - "node" or "deno" (default: "node")
- `logger` (Any): Logger instance for debug messages (optional)

**Returns:** Function result (deserialized from JSON)

**Raises:**
- `FileNotFoundError`: If JavaScript file doesn't exist
- `RuntimeError`: If JavaScript runtime not installed or execution fails
- `ValueError`: If invalid runtime specified

**Supported Runtimes:**
- **node**: Node.js (most common, default)
- **deno**: Deno (secure runtime)

---

## Runtime Requirements

### Node.js

**Installation:**
```bash
# macOS
brew install node

# Linux (Debian/Ubuntu)
sudo apt-get install nodejs npm

# Linux (Fedora)
sudo dnf install nodejs npm

# Windows
# Download from https://nodejs.org/
```

**Check installation:**
```bash
node --version
# v18.0.0 or higher
```

---

### Deno

**Installation:**
```bash
# macOS/Linux
curl -fsSL https://deno.land/install.sh | sh

# Windows
irm https://deno.land/install.ps1 | iex
```

**Check installation:**
```bash
deno --version
# deno 1.30.0 or higher
```

---

## JavaScript Function Format

JavaScript functions must be exported and follow this structure:

### Node.js Format

```javascript
// script.js
function processData(input, number) {
    return {
        result: `Processed ${input} with ${number}`,
        timestamp: Date.now()
    };
}

// Export function
module.exports = { processData };
```

---

### Deno Format

```javascript
// script.js
export function processData(input, number) {
    return {
        result: `Processed ${input} with ${number}`,
        timestamp: Date.now()
    };
}
```

---

## Practical Examples

### Example 1: Basic JavaScript Execution

```python
from zFunc_modules.func_js_executor import execute_js_function

# JavaScript file: utils.js
# function add(a, b) { return a + b; }
# module.exports = { add };

result = execute_js_function(
    js_file_path="/path/to/utils.js",
    function_name="add",
    args=[5, 3],
    runtime="node"
)
# Returns: 8
```

---

### Example 2: Complex Data Structures

```python
# JavaScript file: data_processor.js
# function processUser(user) {
#     return {
#         fullName: `${user.firstName} ${user.lastName}`,
#         email: user.email.toLowerCase(),
#         created: Date.now()
#     };
# }
# module.exports = { processUser };

user_data = {
    "firstName": "Alice",
    "lastName": "Smith",
    "email": "Alice@EXAMPLE.COM"
}

result = execute_js_function(
    js_file_path="/path/to/data_processor.js",
    function_name="processUser",
    args=[user_data],
    runtime="node"
)
# Returns: {"fullName": "Alice Smith", "email": "alice@example.com", "created": 1703001234567}
```

---

### Example 3: Array Processing

```python
# JavaScript file: array_utils.js
# function filterEven(numbers) {
#     return numbers.filter(n => n % 2 === 0);
# }
# module.exports = { filterEven };

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

result = execute_js_function(
    js_file_path="/path/to/array_utils.js",
    function_name="filterEven",
    args=[numbers],
    runtime="node"
)
# Returns: [2, 4, 6, 8, 10]
```

---

### Example 4: Async JavaScript Functions

```javascript
// async_api.js
async function fetchData(url) {
    const response = await fetch(url);
    return await response.json();
}

module.exports = { fetchData };
```

```python
# Execute async JavaScript (awaited by Node.js runtime)
result = execute_js_function(
    js_file_path="/path/to/async_api.js",
    function_name="fetchData",
    args=["https://api.example.com/users"],
    runtime="node"
)
# Returns: JSON response from API
```

---

### Example 5: Using Deno Runtime

```javascript
// deno_script.js
export function processText(text) {
    return text.toUpperCase();
}
```

```python
# Execute with Deno runtime
result = execute_js_function(
    js_file_path="/path/to/deno_script.js",
    function_name="processText",
    args=["hello world"],
    runtime="deno"
)
# Returns: "HELLO WORLD"
```

---

### Example 6: Error Handling

```python
# JavaScript file: error_demo.js
# function mayFail(value) {
#     if (value < 0) {
#         throw new Error("Value must be positive");
#     }
#     return value * 2;
# }
# module.exports = { mayFail };

try:
    result = execute_js_function(
        js_file_path="/path/to/error_demo.js",
        function_name="mayFail",
        args=[-5],
        runtime="node"
    )
except RuntimeError as e:
    print(f"JavaScript error: {e}")
    # Output: JavaScript error: Error: Value must be positive
```

---

### Example 7: Integration with zFunc

```python
from zOS import zOS

z = zOS()

# Note: JavaScript execution via zFunc is currently internal
# Public API for JS execution coming in future release

# Current usage (internal):
from zFunc_modules.func_js_executor import execute_js_function

result = execute_js_function(
    js_file_path="/path/to/script.js",
    function_name="myFunction",
    args=["arg1", 42],
    runtime="node",
    logger=z.logger
)
```

---

### Example 8: NPM Package Usage (Node.js)

```javascript
// npm_example.js
const _ = require('lodash');

function sortNumbers(numbers) {
    return _.sortBy(numbers);
}

module.exports = { sortNumbers };
```

```bash
# Install dependencies first
cd /path/to/scripts
npm install lodash
```

```python
# Execute function using npm package
result = execute_js_function(
    js_file_path="/path/to/scripts/npm_example.js",
    function_name="sortNumbers",
    args=[[3, 1, 4, 1, 5, 9, 2, 6]],
    runtime="node"
)
# Returns: [1, 1, 2, 3, 4, 5, 6, 9]
```

---

## Implementation Details

### Execution Flow

1. **Validate File**: Check if JavaScript file exists
2. **Validate Runtime**: Check if runtime (node/deno) is installed
3. **Prepare Wrapper**: Create temporary wrapper script
4. **Serialize Args**: Convert Python args to JSON
5. **Execute**: Run JavaScript via subprocess
6. **Capture Output**: Read stdout from JavaScript
7. **Deserialize Result**: Parse JSON output to Python
8. **Clean Up**: Remove temporary wrapper
9. **Return**: Return deserialized result

---

### Wrapper Script Generation

The executor creates a temporary wrapper script that:
- Imports the target module
- Calls the specified function with args
- Serializes result to JSON
- Writes JSON to stdout

**Node.js Wrapper:**
```javascript
const module = require('/path/to/script.js');
const args = JSON.parse(process.argv[2]);
const result = module.functionName(...args);
console.log(JSON.stringify(result));
```

**Deno Wrapper:**
```javascript
import * as module from '/path/to/script.js';
const args = JSON.parse(Deno.args[0]);
const result = module.functionName(...args);
console.log(JSON.stringify(result));
```

---

### Data Serialization

**Python → JavaScript:**
- `dict` → JavaScript object
- `list` → JavaScript array
- `str` → JavaScript string
- `int/float` → JavaScript number
- `bool` → JavaScript boolean
- `None` → JavaScript null

**JavaScript → Python:**
- JavaScript object → `dict`
- JavaScript array → `list`
- JavaScript string → `str`
- JavaScript number → `int/float`
- JavaScript boolean → `bool`
- JavaScript null → `None`

---

## Use Cases

### 1. Frontend Code Reuse

```python
# Reuse frontend validation logic in backend
result = execute_js_function(
    js_file_path="/frontend/validators.js",
    function_name="validateEmail",
    args=["user@example.com"],
    runtime="node"
)
# Returns: True
```

---

### 2. Node.js Library Integration

```python
# Use Node.js libraries from Python
result = execute_js_function(
    js_file_path="/scripts/markdown_parser.js",
    function_name="parseMarkdown",
    args=["# Heading\n\nParagraph"],
    runtime="node"
)
# Returns: "<h1>Heading</h1><p>Paragraph</p>"
```

---

### 3. JavaScript-based Data Processing

```python
# Leverage JavaScript's JSON/string manipulation
result = execute_js_function(
    js_file_path="/scripts/data_transform.js",
    function_name="transformData",
    args=[complex_data_structure],
    runtime="node"
)
```

---

### 4. Web Scraping (with Deno)

```javascript
// scraper.js (Deno)
export async function scrapeWebsite(url) {
    const response = await fetch(url);
    const html = await response.text();
    // Parse HTML and extract data
    return extractedData;
}
```

```python
# Execute web scraper
result = execute_js_function(
    js_file_path="/scripts/scraper.js",
    function_name="scrapeWebsite",
    args=["https://example.com"],
    runtime="deno"
)
```

---

## Performance Considerations

### Overhead

JavaScript execution via subprocess has overhead:

- **Process spawn**: ~50-100ms
- **Module loading**: ~10-50ms (cached after first run)
- **JSON serialization**: ~1-10ms (depends on data size)

**Total overhead**: ~60-160ms per call

**Optimization strategies:**
1. **Batch operations**: Process multiple items in one call
2. **Minimize calls**: Cache results when possible
3. **Use native Python**: For simple operations, Python is faster
4. **Consider persistent process**: For high-frequency calls (future feature)

---

### When to Use JavaScript Execution

**Good use cases:**
- Reusing existing JavaScript code
- Leveraging JavaScript libraries (npm packages)
- Complex string/JSON manipulation (JavaScript's strength)
- Frontend/backend code sharing

**Poor use cases:**
- Simple calculations (use Python)
- High-frequency operations (overhead too high)
- CPU-intensive tasks (subprocess overhead)
- When Python library exists (use Python)

---

## Best Practices

1. **Function Design:**
   - Keep functions pure (no side effects)
   - Return serializable data (JSON-compatible)
   - Handle errors in JavaScript
   - Document expected arguments

2. **Error Handling:**
   - Validate inputs in JavaScript
   - Catch exceptions in Python
   - Log errors for debugging
   - Provide meaningful error messages

3. **Performance:**
   - Batch operations when possible
   - Cache results if reused
   - Minimize subprocess calls
   - Use native Python for simple tasks

4. **Dependencies:**
   - Document npm package requirements
   - Use package.json for Node.js projects
   - Consider bundle size for Deno

5. **Testing:**
   - Test JavaScript functions independently
   - Test Python-JavaScript integration
   - Test error conditions
   - Test with different runtimes

---

## Limitations

Current limitations:

1. **Subprocess Overhead**: Each call spawns new process (~50-100ms)
2. **No Shared State**: Functions can't maintain state between calls
3. **JSON Only**: Arguments/returns must be JSON-serializable
4. **No Callbacks**: Python can't pass callbacks to JavaScript
5. **No Streaming**: All data transferred at once (not streaming)

---

## Future Enhancements

Planned features for future versions:

- **Persistent Process**: Keep Node.js process alive for multiple calls
- **Bidirectional Communication**: Python ↔ JavaScript callbacks
- **Streaming Support**: Stream large datasets
- **Direct Integration**: Python ↔ JavaScript without subprocess
- **Type Validation**: Validate argument types before execution
- **zFunc Facade**: Public API via `z.zfunc.execute_js()`

---

## Version History

- **v1.6.0**: Initial implementation
  - Node.js runtime support
  - Deno runtime support
  - JSON serialization/deserialization
  - Error handling and logging
  - Subprocess-based execution
