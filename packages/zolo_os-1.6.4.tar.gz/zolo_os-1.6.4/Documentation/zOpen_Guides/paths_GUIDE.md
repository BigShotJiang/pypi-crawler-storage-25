# zOpen Paths Module Guide

> **Module:** `zOS/core/L2_Handling/k_zOpen/open_modules/open_paths.py`  
> **Purpose:** zPath notation resolution for workspace-relative and absolute file references.

---

## Overview

The `paths` module provides declarative path notation (**zPath**) using symbols to reference files relative to workspace or filesystem root. It eliminates hardcoded paths and makes file references portable across machines.

---

## zPath Notation

### Symbols

| Symbol | Meaning | Example | Resolves To |
|--------|---------|---------|-------------|
| `@` | Workspace-relative | `@.README.md` | `/workspace/README.md` |
| `~` | Absolute from root | `~.Users.alice.notes.txt` | `/Users/alice/notes.txt` |
| `.` | Path separator | `@.docs.setup.md` | `/workspace/docs/setup.md` |

**Why zPath?**
- **Portable:** Works across machines regardless of actual workspace path
- **Declarative:** References intent (workspace file) not implementation (hardcoded path)
- **Type-safe:** Validated before resolution
- **Clear intent:** @ means workspace, ~ means absolute

---

## API Reference

### `resolve_zpath(zpath, session, logger)`

Resolves a zPath string to an actual filesystem path.

**Parameters:**
- `zpath` (str): zPath string starting with @ or ~
- `session` (dict): zOS session containing workspace directory
- `logger` (Logger): Logger for debug output

**Returns:**
- `Path | None`: Resolved filesystem path, or None if validation fails

**Examples:**
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import resolve_zpath

# Workspace-relative
path = resolve_zpath("@.README.md", session, logger)
# Returns: Path("/workspace/README.md")

# Nested workspace path
path = resolve_zpath("@.docs.setup.md", session, logger)
# Returns: Path("/workspace/docs/setup.md")

# Absolute path
path = resolve_zpath("~.Users.alice.notes.txt", session, logger)
# Returns: Path("/Users/alice/notes.txt")
```

**Validation:**
- Must start with @ or ~
- Must have at least 2 parts (symbol + name)
- Logs error and returns None for invalid paths

**Resolution Process:**
1. Validates zPath format
2. Splits by . separator
3. Removes symbol prefix
4. For @: Joins with workspace directory
5. For ~: Joins with filesystem root
6. Returns Path object

---

### `validate_zpath(zpath)`

Validates zPath format before resolution.

**Parameters:**
- `zpath` (str): zPath string to validate

**Returns:**
- `bool`: True if valid, False otherwise

**Validation Rules:**
- Must start with @ or ~
- Must contain at least one . separator
- Must have symbol + at least one path component

**Examples:**
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import validate_zpath

# Valid zPaths
validate_zpath("@.README.md")        # True
validate_zpath("~.Users.alice.file") # True
validate_zpath("@.docs.api.md")      # True

# Invalid zPaths
validate_zpath("README.md")          # False (no symbol)
validate_zpath("@")                  # False (no path)
validate_zpath("@.")                 # False (no filename)
```

---

## Workspace Context

zPath resolution requires workspace context from zOS session:

**Workspace Sources:**
1. **zSpark override:** `{"zSpace": "/path/to/workspace"}`
2. **Current directory:** `Path.cwd()`
3. **Fallback:** `Path.home()`

**Access workspace:**
```python
# From session
workspace = session.get("zSpace")  # Path object

# Example: /Users/alice/projects/myapp
```

**No workspace:**
- If workspace is None, @ paths cannot resolve
- Returns None with error log
- ~ paths still work (absolute)

---

## Path Resolution Examples

### Workspace-Relative (@)

Assuming workspace is `/Users/alice/projects/myapp`:

```python
# Simple file
"@.README.md"
→ /Users/alice/projects/myapp/README.md

# Nested directory
"@.docs.setup.md"
→ /Users/alice/projects/myapp/docs/setup.md

# Deep nesting
"@.src.components.button.tsx"
→ /Users/alice/projects/myapp/src/components/button.tsx

# Hidden file
"@..gitignore"
→ /Users/alice/projects/myapp/.gitignore
```

### Absolute Paths (~)

```python
# User directory
"~.Users.alice.notes.txt"
→ /Users/alice/notes.txt

# System directory
"~.etc.config.yaml"
→ /etc/config.yaml

# Temp directory
"~.tmp.test.log"
→ /tmp/test.log

# Deep nesting
"~.Users.alice.Documents.notes.personal.diary.txt"
→ /Users/alice/Documents/notes/personal/diary.txt
```

---

## Error Handling

### Invalid Format

```python
# Missing symbol
resolve_zpath("README.md", session, logger)
→ None + error log

# Missing path component
resolve_zpath("@", session, logger)
→ None + error log

# Empty path
resolve_zpath("@.", session, logger)
→ None + error log
```

### Missing Workspace

```python
# Workspace not set in session
session = {}  # No zSpace

resolve_zpath("@.README.md", session, logger)
→ None + error log: "No workspace set for relative path"

# Absolute paths still work
resolve_zpath("~.tmp.test.log", session, logger)
→ Path("/tmp/test.log")
```

---

## Integration with zOpen

zPath resolution is called automatically by zOpen:

```python
# From zOpen.handle()
result = z.open.handle("zOpen(@.README.md)")

# Internal flow:
# 1. Detect @ symbol
# 2. Call resolve_zpath("@.README.md", session, logger)
# 3. Get Path("/workspace/README.md")
# 4. Call open_file(path, ...)
# 5. Open in appropriate application
```

**No manual resolution needed** - zOpen detects zPath notation and resolves automatically.

---

## Best Practices

### When to Use @

Use workspace-relative (@) for:
- Project documentation (README, GUIDE)
- Source code files within project
- Configuration files in project
- Test files in project
- Any file that moves with the workspace

**Benefits:**
- Portable across machines
- Works in different workspace locations
- No hardcoded paths
- Clear intent (project file)

### When to Use ~

Use absolute paths (~) for:
- System configuration files (/etc/*)
- User home directory files
- System logs (/var/log/*)
- Temp files (/tmp/*)
- Files outside workspace

**Benefits:**
- Explicit filesystem location
- No workspace dependency
- System-level references
- Clear intent (absolute)

### When NOT to Use zPath

Don't use zPath for:
- User input (let them type normal paths)
- URLs (use http:// or https://)
- Already resolved paths (from Path objects)
- Dynamic paths (use Path operations)

**Use normal paths when:**
- Accepting user input
- Building paths dynamically
- Working with Path objects directly
- Interacting with APIs

---

## Constants Reference

From `open_constants.py`:

```python
# zPath symbols
ZPATH_SYMBOL_WORKSPACE = "@"
ZPATH_SYMBOL_ABSOLUTE = "~"
ZPATH_SEPARATOR = "."

# Validation
_ZPATH_MIN_PARTS = 2  # Symbol + at least one component
```

---

## Logging

The module logs at different levels:

**DEBUG:**
- `"Resolving zPath: @.README.md"`
- `"Resolved zPath '@.README.md' to: /workspace/README.md"`

**ERROR:**
- `"Invalid zPath format: README.md"`
- `"Workspace context missing for path: @.README.md"`
- `"Failed to resolve zPath"`

**Usage:**
```python
# Enable debug logging
z = zOS({
    "logger": "DEBUG",
    "logger_path": "./logs",
})

# See zPath resolution in logs
result = z.open.handle("zOpen(@.README.md)")
```

---

## Testing zPath Resolution

Test zPath validation:
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import validate_zpath

# Valid
assert validate_zpath("@.README.md") == True
assert validate_zpath("~.Users.file.txt") == True

# Invalid
assert validate_zpath("README.md") == False
assert validate_zpath("@") == False
```

Test zPath resolution:
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import resolve_zpath
from pathlib import Path

# Mock session with workspace
session = {"zSpace": Path("/workspace")}

# Test workspace-relative
path = resolve_zpath("@.README.md", session, logger)
assert path == Path("/workspace/README.md")

# Test absolute
path = resolve_zpath("~.tmp.test.log", session, logger)
assert path == Path("/tmp/test.log")
```

---

## Common Patterns

### Project Documentation

```python
# Open project README
z.open.handle("zOpen(@.README.md)")

# Open API docs
z.open.handle("zOpen(@.docs.api.md)")

# Open setup guide
z.open.handle("zOpen(@.docs.setup.md)")
```

### Source Code

```python
# Open main app file
z.open.handle("zOpen(@.src.app.py)")

# Open component
z.open.handle("zOpen(@.src.components.button.tsx)")

# Open test file
z.open.handle("zOpen(@.tests.test_app.py)")
```

### Configuration Files

```python
# Project config
z.open.handle("zOpen(@.config.settings.yaml)")

# Environment variables
z.open.handle("zOpen(@..env)")

# Package config
z.open.handle("zOpen(@.package.json)")
```

### System Files

```python
# System config
z.open.handle("zOpen(~.etc.hosts)")

# User config
z.open.handle("zOpen(~.Users.alice.bashrc)")

# System log
z.open.handle("zOpen(~.var.log.system.log)")
```

---

**[← Back to zOpen Guide](../zOpen_GUIDE.md)**
