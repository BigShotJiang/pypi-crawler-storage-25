# zOpen Files Module Guide

> **Module:** `zOS/core/L2_Handling/k_zOpen/open_modules/open_files.py`  
> **Purpose:** Local file opening based on extension with IDE/browser routing and interactive fallbacks.

---

## Overview

The `files` module handles opening local files by detecting their extension and routing to the appropriate application. It provides interactive prompts for missing files and IDE selection, with content display fallbacks.

---

## Supported File Types

### HTML Files

**Extensions:** `.html`, `.htm`

**Opens in:** Browser (preferred or default)

**Examples:**
```python
# Open HTML documentation
z.open.handle("zOpen(/path/to/docs.html)")

# Open local web page
z.open.handle("zOpen(./index.htm)")

# Open workspace HTML
z.open.handle("zOpen(@.build.index.html)")
```

**Opening Process:**
1. Detects .html or .htm extension
2. Creates file:// URL
3. Opens in browser (preferred or default)
4. Falls back to URL info display if browser fails

### Text Files

**Extensions:** `.txt`, `.md`, `.py`, `.js`, `.json`, `.yaml`, `.yml`

**Opens in:** IDE (configured or selected)

**Examples:**
```python
# Open Python file
z.open.handle("zOpen(/path/to/script.py)")

# Open Markdown documentation
z.open.handle("zOpen(./README.md)")

# Open JSON config
z.open.handle("zOpen(./config.json)")

# Open YAML file
z.open.handle("zOpen(@.settings.yaml)")
```

**Opening Process:**
1. Detects text extension
2. Gets IDE from zMachine or prompts user
3. Opens file in IDE
4. Falls back to content display if IDE fails

---

## API Reference

### `open_file(path, session, display, dialog, logger)`

Opens a local file based on its extension.

**Parameters:**
- `path` (str | Path): File path to open
- `session` (dict): zOS session containing IDE preferences
- `display` (zDisplay): Display instance for output
- `dialog` (zDialog): Dialog instance for prompts
- `logger` (Logger): Logger for debug output

**Returns:**
- `str`: "zBack" on success, "stop" on failure/cancellation

**Examples:**
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import open_file
from pathlib import Path

# Open text file
result = open_file("/path/to/notes.txt", session, display, dialog, logger)
# Returns: "zBack" (opened in IDE)

# Open HTML file
result = open_file(Path("./index.html"), session, display, dialog, logger)
# Returns: "zBack" (opened in browser)

# Open non-existent file (prompts for creation)
result = open_file("./new.txt", session, display, dialog, logger)
# Returns: "zBack" if created and opened, "stop" if cancelled
```

**Opening Flow:**
1. Resolve path to absolute Path object
2. Check if file exists:
   - If not: Prompt for creation via zDialog
   - If cancelled: Return "stop"
   - If created: Continue
3. Detect file extension:
   - HTML → Route to browser
   - Text → Route to IDE
   - Other → Display unsupported message
4. Open in appropriate application
5. Return "zBack" on success, "stop" on failure

---

## File Type Detection

### HTML Files

```python
# Extensions
EXTENSIONS_HTML = ('.html', '.htm')

# Detection
if path.suffix.lower() in EXTENSIONS_HTML:
    return _open_html_file(path, ...)
```

**HTML Opening Process:**
1. Convert path to file:// URL
2. Get browser preference from session
3. Try preferred browser
4. Try default browser
5. Display URL info if both fail

### Text Files

```python
# Extensions
EXTENSIONS_TEXT = ('.txt', '.md', '.py', '.js', '.json', '.yaml', '.yml')

# Detection
if path.suffix.lower() in EXTENSIONS_TEXT:
    return _open_text_file(path, ...)
```

**Text Opening Process:**
1. Get IDE from session or prompt user
2. Build command for IDE
3. Execute command (subprocess)
4. Display content if IDE fails

### Unsupported Files

```python
# Extension not in EXTENSIONS_HTML or EXTENSIONS_TEXT
else:
    display.print_message(f"Unsupported file type: {ext}", color="ERROR")
    return "stop"
```

---

## Interactive Features

### File Creation Prompt

When file doesn't exist, prompts user:

```python
# File not found
→ zDialog prompt:
   "File not found: /path/to/file.txt"
   Options:
     - Create file
     - Cancel

# User selects "Create file"
→ Create empty file
→ Open in IDE
→ Return "zBack"

# User selects "Cancel"
→ Return "stop"
```

**zDialog Integration:**
```python
fields = [
    {
        "type": "select",
        "label": f"File not found: {path}",
        "options": ["Create file", "Cancel"],
        "zField": "action"
    }
]

result = dialog.submit(fields)
action = result.get("action")

if action == "Create file":
    path.touch()  # Create empty file
    # Continue opening
elif action == "Cancel":
    return "stop"
```

### IDE Selection Prompt

When IDE not configured, prompts user:

```python
# No IDE in session
→ zDialog prompt:
   "Select your preferred IDE:"
   Options:
     - cursor
     - code (VS Code)
     - sublime
     - nano
     - vim

# User selects IDE
→ Save to zMachine config (persists)
→ Open file in selected IDE
→ Return "zBack"

# Future opens use saved preference
```

**zDialog Integration:**
```python
fields = [
    {
        "type": "select",
        "label": "Select your preferred IDE:",
        "options": ["cursor", "code", "nano", "vim"],
        "zField": "ide"
    }
]

result = dialog.submit(fields)
ide = result.get("ide")

# Save preference
z.config.persistence.persist_machine("ide", ide)

# Continue opening with selected IDE
```

---

## IDE Support

### Supported IDEs

| IDE | Command | Notes |
|-----|---------|-------|
| cursor | `cursor <path>` | Cursor IDE |
| code | `code <path>` | VS Code |
| sublime | `subl <path>` | Sublime Text |
| nano | `nano <path>` | Terminal editor |
| vim | `vim <path>` | Terminal editor |
| fleet | `fleet <path>` | Fleet IDE |
| zed | `zed <path>` | Zed IDE |
| pycharm | `pycharm <path>` | PyCharm |
| webstorm | `webstorm <path>` | WebStorm |

### IDE Command Execution

```python
# Build command
if ide == "cursor":
    cmd = ["cursor", str(path)]
elif ide == "code":
    cmd = ["code", str(path)]
elif ide == "nano":
    cmd = ["nano", str(path)]
# ... etc

# Execute
subprocess.run(cmd, check=True)
```

**Error Handling:**
- IDE not installed → Falls back to content display
- Permission denied → Falls back to content display
- Command fails → Falls back to content display

### Default IDE

If IDE selection fails, defaults to `nano`:

```python
# IDE selection failed
ide = "nano"  # Safe fallback (always available)
```

---

## Content Display Fallback

If IDE opening fails, displays file content in terminal:

```python
# IDE failed
→ Read file content
→ Display via zDisplay
→ Truncate if > 1000 characters
→ Show truncation notice
→ Return "zBack" (success with fallback)
```

**Display Format:**
```
════════════════════════════════════
File Content: notes.txt
════════════════════════════════════
[file content here]

[Content truncated - showing first 1000 of 5000 characters]
════════════════════════════════════
```

**Truncation:**
- Limit: 1000 characters
- Shows truncation notice if exceeded
- Displays total character count

**zDisplay Integration:**
```python
# Show section header
display.print_section_start(
    f"File Content: {path.name}",
    style="full"
)

# Show content (truncated)
content = path.read_text(encoding='utf-8')
if len(content) > 1000:
    content = content[:1000]
    display.print_message(content)
    display.print_message(
        f"[Content truncated - showing first 1000 of {len(content)} characters]"
    )
else:
    display.print_message(content)

# Show section end
display.print_section_end(style="full")
```

---

## HTML File Opening

### file:// URL Creation

```python
# Convert path to file:// URL
file_url = path.as_uri()
# /path/to/page.html → file:///path/to/page.html
```

### Browser Opening

Same as URL opening (see urls_GUIDE.md):
1. Try preferred browser
2. Try default browser
3. Display URL info if both fail

**Success Messages:**
```python
# Opened in browser
display.print_message(
    f"Opened {path.name} in browser",
    color="SUCCESS"
)
```

---

## Error Handling

### File Not Found

```python
if not path.exists():
    # Prompt for creation via zDialog
    # If cancelled: return "stop"
    # If created: continue opening
```

### Unsupported Extension

```python
if ext not in (EXTENSIONS_HTML + EXTENSIONS_TEXT):
    display.print_message(
        f"Unsupported file type: {ext}",
        color="ERROR"
    )
    return "stop"
```

### IDE Opening Failed

```python
try:
    subprocess.run(cmd, check=True)
except Exception as e:
    logger.error(f"Failed to open with {ide}: {e}")
    # Fall back to content display
    _display_text_content(path, display, logger)
    return "zBack"
```

### File Read Failed

```python
try:
    content = path.read_text(encoding='utf-8')
except Exception as e:
    logger.error(f"Failed to read file: {e}")
    display.print_message(
        f"Failed to read file: {e}",
        color="ERROR"
    )
    return "stop"
```

---

## Integration with zOpen

File opening is called automatically by zOpen:

```python
# From zOpen.handle()
result = z.open.handle("zOpen(/path/to/file.txt)")

# Internal flow:
# 1. Detect local path (not URL, not zPath)
# 2. Call open_file(path, session, display, dialog, logger)
# 3. Detect extension
# 4. Route to appropriate handler
# 5. Open or display content
# 6. Return result
```

**No manual calls needed** - zOpen detects file paths and routes automatically.

---

## Constants Reference

From `open_constants.py`:

```python
# File extensions
EXTENSIONS_HTML = ('.html', '.htm')
EXTENSIONS_TEXT = ('.txt', '.md', '.py', '.js', '.json', '.yaml', '.yml')

# IDE configuration
_DEFAULT_IDE = "nano"
_IDE_UNKNOWN = "unknown"
_AVAILABLE_IDES = ["cursor", "code", "nano", "vim"]

# File actions
_FILE_ACTION_CREATE = "Create file"
_FILE_ACTION_CANCEL = "Cancel"
_FILE_ACTIONS = [_FILE_ACTION_CREATE, _FILE_ACTION_CANCEL]

# Content truncation
_CONTENT_TRUNCATE_LIMIT = 1000  # Characters
_FILE_ENCODING = 'utf-8'

# Messages
_MSG_CREATED_FILE = "Created {path}"
_MSG_OPENED_BROWSER = "Opened {filename} in browser"
_MSG_OPENED_IDE = "Opened {filename} in {ide}"
_MSG_FILE_CONTENT_TITLE = "File Content: {filename}"
_MSG_CONTENT_TRUNCATED = "[Content truncated - showing first {limit} of {total} characters]"
_MSG_UNSUPPORTED_TYPE = "Unsupported file type: {ext}"

# Errors
_ERR_FILE_NOT_FOUND = "File not found: %s"
_ERR_IDE_FAILED = "Failed to open with IDE %s: %s"
_ERR_READ_FAILED = "Failed to read file: %s"
```

---

## Logging

The module logs at different levels:

**DEBUG:**
- `"Resolved path: /path/to/file.txt"`
- `"Opening text file: /path/to/file.txt"`
- `"Using IDE: cursor"`

**INFO:**
- `"Successfully opened file with cursor"`
- `"Created file: /path/to/new.txt"`

**ERROR:**
- `"File not found: /path/to/file.txt"`
- `"Failed to open with cursor: <error>"`
- `"Failed to read file: <error>"`

**Usage:**
```python
# Enable debug logging
z = zOS({
    "logger": "DEBUG",
    "logger_path": "./logs",
})

# See file opening in logs
result = z.open.handle("zOpen(/path/to/file.txt)")
```

---

## Common Patterns

### Opening Source Code

```python
# Python files
z.open.handle("zOpen(@.src.app.py)")
z.open.handle("zOpen(@.tests.test_app.py)")

# JavaScript files
z.open.handle("zOpen(@.src.components.button.js)")

# TypeScript files (need to add .ts to EXTENSIONS_TEXT)
z.open.handle("zOpen(@.src.app.ts)")
```

### Opening Documentation

```python
# Markdown files
z.open.handle("zOpen(@.README.md)")
z.open.handle("zOpen(@.docs.api.md)")

# HTML documentation
z.open.handle("zOpen(@.build.docs.html)")
```

### Opening Configuration

```python
# JSON config
z.open.handle("zOpen(@.package.json)")
z.open.handle("zOpen(@.tsconfig.json)")

# YAML config
z.open.handle("zOpen(@.config.yaml)")
z.open.handle("zOpen(@..github.workflows.ci.yml)")
```

### Creating New Files

```python
# Try to open non-existent file
z.open.handle("zOpen(@.new_feature.py)")

# Prompts:
# "File not found: /workspace/new_feature.py"
# Options: Create file | Cancel

# Select "Create file"
# → Creates empty file
# → Opens in IDE
# → Ready to start coding
```

---

## Best Practices

### When to Use File Opening

Use for:
- Source code files (.py, .js, .ts)
- Documentation files (.md, .txt)
- Configuration files (.json, .yaml)
- HTML documentation (.html)
- Any text-based files

### When NOT to Use

Don't use for:
- Binary files (images, videos, PDFs)
- Large files (> 100MB)
- Remote URLs (use URL opening)
- Directories (not supported)

### IDE Configuration

**Set preferred IDE:**
```python
# Via zMachine config
z.config.persistence.persist_machine("ide", "cursor")

# Via zSpark
z = zOS({"ide": "code"})

# Via environment
# ZOLO_IDE=nano
```

**IDE priority:**
1. zSpark override (highest)
2. zMachine configuration
3. Interactive selection prompt
4. Default (nano)

### File Creation

Always handle file creation prompts:
```python
# User might cancel
result = z.open.handle("zOpen(@.new_file.txt)")

if result == "stop":
    print("User cancelled file creation")
else:
    print("File created and opened")
```

---

## Future Extensions

The modular architecture supports easy addition of new file types:

**Documents:**
- PDF: Open in default PDF viewer
- Word/Excel: Open in appropriate app
- PowerPoint: Open in presentation app

**Images:**
- PNG, JPG: Open in image viewer
- SVG: Open in browser or editor
- With Bifrost: Display inline

**Archives:**
- ZIP, TAR: Extract or open in file manager
- GZ: Decompress and open contents

**Media:**
- Audio: Open in media player
- Video: Open in media player

**To add support:**
1. Update EXTENSIONS_* tuples in open_constants.py
2. Add handler function in open_files.py
3. Update routing logic in open_file()
4. Document in this guide

---

**[← Back to zOpen Guide](../zOpen_GUIDE.md)**
