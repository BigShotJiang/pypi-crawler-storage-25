# zOpen URLs Module Guide

> **Module:** `zOS/core/L2_Handling/k_zOpen/open_modules/open_urls.py`  
> **Purpose:** URL opening in user's preferred or system default browser.

---

## Overview

The `urls` module handles opening HTTP/HTTPS URLs in browsers. It automatically detects URL patterns, adds missing protocols, and uses browser preferences from zMachine configuration.

---

## Supported URL Patterns

### HTTP URLs

```python
# Plain HTTP
z.open.handle("zOpen(http://example.com)")

# HTTP with path
z.open.handle("zOpen(http://example.com/page)")

# HTTP with query params
z.open.handle("zOpen(http://example.com/search?q=test)")
```

### HTTPS URLs

```python
# Plain HTTPS
z.open.handle("zOpen(https://example.com)")

# HTTPS with subdomain
z.open.handle("zOpen(https://api.example.com)")

# HTTPS with path and params
z.open.handle("zOpen(https://github.com/user/repo?tab=readme)")
```

### WWW Prefix

```python
# Auto-adds https://
z.open.handle("zOpen(www.google.com)")
→ Opens: https://www.google.com

# With path
z.open.handle("zOpen(www.github.com/explore)")
→ Opens: https://www.github.com/explore
```

---

## API Reference

### `open_url(url, session, display, logger)`

Opens a URL in the user's browser.

**Parameters:**
- `url` (str): URL to open (http://, https://, or www.)
- `session` (dict): zOS session containing browser preferences
- `display` (zDisplay): Display instance for output messages
- `logger` (Logger): Logger for debug output

**Returns:**
- `str`: "zBack" on success, "stop" on failure

**Examples:**
```python
from zOS.core.L2_Handling.k_zOpen.open_modules import open_url

# Open HTTPS URL
result = open_url("https://github.com", session, display, logger)
# Returns: "zBack"

# Open HTTP URL
result = open_url("http://example.com", session, display, logger)
# Returns: "zBack"

# Open www URL (auto-adds https://)
result = open_url("www.google.com", session, display, logger)
# Returns: "zBack"
```

**Opening Process:**
1. Add https:// if URL starts with www.
2. Get preferred browser from session
3. Try to open in preferred browser
4. If fails, try system default browser
5. If both fail, display URL info (fallback)
6. Log result and return status

---

## Browser Selection

### Preferred Browser

Browser preference comes from zMachine configuration:

```python
# From session
browser = session.get("browser")  # "chrome", "firefox", "safari", etc.

# Example flow:
# 1. Check session["browser"]
# 2. Try to open in that browser
# 3. If fails, try default browser
# 4. If both fail, show URL info
```

**Supported Browsers:**
- chrome (Google Chrome)
- firefox (Mozilla Firefox)
- safari (Safari)
- arc (Arc Browser)
- brave (Brave Browser)
- edge (Microsoft Edge)
- opera (Opera Browser)

### Default Browser

If preferred browser fails, falls back to system default:

```python
# Browser preference: "chrome"
# Chrome not installed or fails
→ Try system default browser
→ If that works: "zBack"
→ If that fails: Display URL info
```

**Default browser detection:**
- macOS: Uses open command
- Linux: Uses xdg-open
- Windows: Uses start command

### Unknown Browser

If browser is "unknown" or not recognized:

```python
# Session browser: "unknown"
→ Skip preferred browser
→ Try system default directly
→ If that fails: Display URL info
```

---

## URL Processing

### WWW Prefix Handling

URLs starting with www. automatically get https:// prepended:

```python
# Input: www.google.com
# Processed: https://www.google.com

# Input: www.github.com/explore
# Processed: https://www.github.com/explore
```

**Why https://?**
- Modern web standard
- Most sites require HTTPS
- Secure by default
- Browser automatically redirects if needed

### URL Validation

URLs are validated before opening:

```python
# Valid URLs
"http://example.com"          # ✓
"https://example.com"         # ✓
"www.example.com"             # ✓
"https://api.example.com/v1"  # ✓

# Invalid URLs (not handled by this module)
"example.com"                 # ✗ (no protocol or www)
"/path/to/file"               # ✗ (local path)
"@.README.md"                 # ✗ (zPath)
```

---

## Browser Opening Methods

### Preferred Browser

Uses `webbrowser.get(browser).open(url)`:

```python
import webbrowser

# Example: Open in Chrome
browser = webbrowser.get("chrome")
browser.open("https://example.com")
```

**Advantages:**
- Respects user preference
- Consistent with zMachine config
- Predictable behavior

**Error Handling:**
- Catches browser not found
- Catches browser launch errors
- Falls back to default browser

### Default Browser

Uses `webbrowser.open(url)`:

```python
import webbrowser

# Opens in system default browser
webbrowser.open("https://example.com")
```

**Advantages:**
- Always available (fallback)
- Uses system preference
- No configuration needed

**Error Handling:**
- Catches all webbrowser errors
- Falls back to URL info display

---

## Fallback Display

If both browser methods fail, displays URL information:

```python
# Browser failed
→ Display URL info via zDisplay

# Output:
# ════════════════════════════════════
# URL Information
# ════════════════════════════════════
# Unable to open in browser. Please copy and paste into your browser:
# 
# https://example.com
# ════════════════════════════════════
```

**What's displayed:**
- Section header
- Helpful message
- Full URL (for copy/paste)
- Clean formatting via zDisplay

**User action:**
- Copy URL from terminal
- Paste into browser manually
- Graceful degradation (no crash)

---

## Success Messages

### Preferred Browser

```python
# Opened in configured browser
z.display.print_message(
    f"Opened URL in {browser}",
    color="SUCCESS"
)
```

### Default Browser

```python
# Opened in system default
z.display.print_message(
    "Opened URL in default browser",
    color="SUCCESS"
)
```

---

## Error Handling

### Browser Launch Errors

```python
try:
    browser.open(url)
except webbrowser.Error as e:
    # Log error
    logger.error(f"Browser error: {e}")
    
    # Try fallback
    # → Default browser
    # → URL info display
```

### Browser Not Found

```python
try:
    browser = webbrowser.get("chrome")
except Exception:
    # Browser not installed
    # → Try default browser
    # → URL info display
```

### All Methods Failed

```python
# Preferred browser failed
# Default browser failed
→ Display URL info (always succeeds)
→ Return "stop" (opening failed)
```

---

## Integration with zOpen

URL opening is called automatically by zOpen:

```python
# From zOpen.handle()
result = z.open.handle("zOpen(https://example.com)")

# Internal flow:
# 1. Detect URL pattern (http/https/www)
# 2. Call open_url(url, session, display, logger)
# 3. Try preferred browser
# 4. Try default browser
# 5. Display URL info if both fail
# 6. Return result
```

**No manual calls needed** - zOpen detects URLs and routes automatically.

---

## Constants Reference

From `open_constants.py`:

```python
# URL schemes
URL_SCHEME_HTTP = "http"
URL_SCHEME_HTTPS = "https"
URL_SCHEMES_SUPPORTED = ("http", "https")
URL_PREFIX_WWW = "www."
URL_SCHEME_HTTPS_DEFAULT = "https://"

# Machine keys
ZMACHINE_KEY_BROWSER = "browser"

# Browser configuration
_BROWSERS_SKIP = ("unknown",)

# Messages
_MSG_OPENED_BROWSER_URL = "Opened URL in {browser}"
_MSG_OPENED_DEFAULT = "Opened URL in default browser"
_MSG_URL_INFO_TITLE = "URL Information"
_MSG_URL_MANUAL = "Unable to open in browser. Please copy and paste into your browser."

# Errors
_ERR_BROWSER_FAILED_URL = "Browser failed to open URL"
_ERR_BROWSER_ERROR = "Browser error: %s"
_ERR_URL_OPEN_FAILED = "Unable to open URL. Displaying information instead."
```

---

## Logging

The module logs at different levels:

**DEBUG:**
- `"Opening URL: https://example.com"`
- `"Using browser: chrome"`

**INFO:**
- `"Successfully opened URL in chrome"`
- `"Successfully opened URL in system default browser"`

**ERROR:**
- `"Browser failed to open URL"`
- `"Browser error: <error details>"`

**Usage:**
```python
# Enable debug logging
z = zOS({
    "logger": "DEBUG",
    "logger_path": "./logs",
})

# See URL opening in logs
result = z.open.handle("zOpen(https://github.com)")
```

---

## Common Patterns

### Opening Documentation

```python
# GitHub repository
z.open.handle("zOpen(https://github.com/user/repo)")

# API documentation
z.open.handle("zOpen(https://api.example.com/docs)")

# Package documentation
z.open.handle("zOpen(https://docs.python.org/3/)")
```

### Opening Web Apps

```python
# Gmail
z.open.handle("zOpen(https://mail.google.com)")

# GitHub Issues
z.open.handle("zOpen(https://github.com/user/repo/issues)")

# Slack workspace
z.open.handle("zOpen(https://workspace.slack.com)")
```

### Opening Search Results

```python
# Google search
z.open.handle("zOpen(https://google.com/search?q=python)")

# Stack Overflow
z.open.handle("zOpen(https://stackoverflow.com/questions)")

# GitHub search
z.open.handle("zOpen(https://github.com/search?q=zos)")
```

### Opening with WWW

```python
# Will auto-add https://
z.open.handle("zOpen(www.google.com)")
z.open.handle("zOpen(www.github.com)")
z.open.handle("zOpen(www.python.org)")
```

---

## Platform-Specific Behavior

### macOS

```python
# Uses 'open' command for default browser
# Supports all major browsers
# Clean integration with system preferences
```

### Linux

```python
# Uses 'xdg-open' command for default browser
# Supports all major browsers
# Respects BROWSER environment variable
```

### Windows

```python
# Uses 'start' command for default browser
# Supports all major browsers
# Integrated with Windows default apps
```

---

## Best Practices

### When to Use URL Opening

Use for:
- External documentation links
- Web applications
- API documentation
- Online resources
- GitHub repositories
- Stack Overflow questions

### When NOT to Use

Don't use for:
- Local files (use file opening)
- File:// URLs (use HTML file opening)
- zPath references (use path resolution)
- API calls (use zComm)

### Browser Configuration

**Set preferred browser:**
```python
# Via zMachine config
z.config.persistence.persist_machine("browser", "chrome")

# Via zSpark
z = zOS({"browser": "firefox"})

# Via environment
# ZOLO_BROWSER=safari
```

**Browser priority:**
1. zSpark override (highest)
2. zMachine configuration
3. System default browser (fallback)

---

**[← Back to zOpen Guide](../zOpen_GUIDE.md)**
