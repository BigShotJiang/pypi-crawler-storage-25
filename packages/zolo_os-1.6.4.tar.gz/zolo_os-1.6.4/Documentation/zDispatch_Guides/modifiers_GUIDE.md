**[← Back to zDispatch Guide](../zDispatch_GUIDE.md)**

---

# Modifiers System

The **ModifierProcessor** orchestrates prefix and suffix modifiers, enabling declarative flow control through simple symbols.

## Overview

Modifiers change command behavior through symbolic annotations:

- **Prefix Modifiers**: `^` (bounce), `~` (anchor)
- **Suffix Modifiers**: `*` (menu), `!` (required)

## Architecture

```
ModifierProcessor
├── check_prefix()      # Detect ^ ~
├── check_suffix()      # Detect * !
├── process()           # Route to domain handlers
└── Domain Modifiers
    ├── BounceModifier     # ^ (execute and return)
    ├── MenuModifier       # * (create menu)
    └── RequiredModifier   # ! (retry until success)
```

## Bounce Modifier (^)

**Execute action, then return based on mode.**

### Syntax

```python
# Prefix the key with ^
result = z.dispatch.handle("^save", {"zFunc": "save_data"})
```

### Behavior

**zCLI Mode (Terminal):**
```python
result = z.dispatch.handle("^save", {"zFunc": "save_data"})
# Executes save_data()
# Returns: "zBack" → triggers menu navigation
```

**zBifrost Mode (Web):**
```python
result = z.dispatch.handle("^save", {"zFunc": "save_data"})
# Executes save_data()
# Returns: <actual function result> → client handles navigation
```

### Use Cases

- **Menu actions**: Execute action, return to menu
- **Form submissions**: Process form, show menu again
- **One-shot operations**: Complete task, navigate back
- **Wizard steps**: Execute step, return to wizard flow

### Examples

```python
# Simple bounce
result = z.dispatch.handle("^delete", {"zFunc": "delete_user", "args": [user_id]})
# Deletes user, returns to menu

# Bounce with validation
result = z.dispatch.handle("^submit", {"zFunc": "submit_form", "args": [form_data]})
# Submits form, returns to menu

# Bounce in wizard
result = z.dispatch.handle("^confirm", {"zFunc": "confirm_step"}, walker=walker)
# Confirms step, returns to wizard
```

### Implementation

**Detection:**
```python
prefix_mods = modifiers.check_prefix("^save")
# Returns: ["^"]
```

**Processing:**
```python
# BounceModifier.process()
1. Strip ^ from key
2. Execute command via launcher.launch()
3. Check mode (zCLI vs. zBifrost)
4. Return "zBack" (zCLI) or actual result (zBifrost)
```

---

## Menu Modifier (*)

**Create interactive menu from data structure.**

### Syntax

```python
# Suffix the key with *
menu_data = {
    "title": "Main Menu",
    "items": {
        "opt1": {"zFunc": "action1", "label": "Action 1"},
        "opt2": {"zFunc": "action2", "label": "Action 2"}
    }
}
result = z.dispatch.handle("menu*", menu_data)
```

### Behavior

```python
# Creates menu via zNavigation.create()
# User sees:
# ┌─ Main Menu ─┐
# │ 1. Action 1 │
# │ 2. Action 2 │
# │ 0. Back     │
# └─────────────┘
# Select: _
```

### Menu Features

- **Automatic numbering**: Items numbered 1, 2, 3...
- **Back button**: Built-in "0: Back" option
- **Interactive selection**: User chooses via number input
- **Recursive dispatch**: Selected action dispatched automatically
- **Nested menus**: Menu items can trigger other menus

### Use Cases

- **Navigation menus**: Top-level app navigation
- **Action menus**: Choose operation to perform
- **Admin panels**: Administrative actions
- **Settings**: Configuration options

### Examples

```python
# Simple menu
admin_menu = {
    "title": "Admin Panel",
    "items": {
        "users": {"zFunc": "manage_users", "label": "Manage Users"},
        "settings": {"zFunc": "edit_settings", "label": "Settings"},
        "logout": {"zLogout": True, "label": "Logout"}
    }
}
z.dispatch.handle("admin*", admin_menu)

# Nested menu
main_menu = {
    "title": "Main Menu",
    "items": {
        "admin": {"menu*": admin_menu, "label": "Admin Panel"},
        "reports": {"menu*": reports_menu, "label": "Reports"}
    }
}
z.dispatch.handle("main*", main_menu)

# Data-driven menu
users = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
user_menu = {
    "title": "Select User",
    "items": {
        f"user_{u['id']}": {"zFunc": "select_user", "args": [u['id']], "label": u['name']}
        for u in users
    }
}
z.dispatch.handle("users*", user_menu)
```

### Implementation

**Detection:**
```python
suffix_mods = modifiers.check_suffix("menu*")
# Returns: ["*"]
```

**Processing:**
```python
# MenuModifier.process()
1. Strip * from key
2. Check for ~ (anchor) modifier
3. Route to zNavigation.create(menu_data, anchor=<bool>)
4. Display menu and handle selection
5. Dispatch selected action
6. Return result
```

---

## Anchor Modifier (~)

**Disable back navigation in menus.**

### Syntax

```python
# Prefix the key with ~, suffix with *
menu_data = {
    "title": "Welcome (No Back)",
    "items": {
        "start": {"zFunc": "start_app", "label": "Start"},
        "exit": {"zFunc": "exit_app", "label": "Exit"}
    }
}
result = z.dispatch.handle("~menu*", menu_data)
```

### Behavior

```python
# Creates menu WITHOUT back button
# User sees:
# ┌─ Welcome (No Back) ─┐
# │ 1. Start            │
# │ 2. Exit             │
# └─────────────────────┘
# Select: _
```

### Use Cases

- **Welcome screens**: Entry point with no back
- **Login menus**: Must authenticate or exit
- **Confirmation dialogs**: Must choose yes/no
- **Terminal states**: No going back (e.g., game over)

### Examples

```python
# Welcome screen
welcome = {
    "title": "Welcome to MyApp",
    "items": {
        "login": {"zLogin": True, "label": "Login"},
        "register": {"zFunc": "register", "label": "Register"},
        "demo": {"zFunc": "demo_mode", "label": "Try Demo"}
    }
}
z.dispatch.handle("~welcome*", welcome)

# Confirmation
confirm = {
    "title": "Delete User?",
    "items": {
        "yes": {"zFunc": "delete_user", "args": [user_id], "label": "Yes, Delete"},
        "no": {"zFunc": "cancel", "label": "No, Cancel"}
    }
}
z.dispatch.handle("~confirm*", confirm)
```

### Implementation

**Detection:**
```python
prefix_mods = modifiers.check_prefix("~menu*")
suffix_mods = modifiers.check_suffix("~menu*")
# prefix_mods: ["~"]
# suffix_mods: ["*"]
```

**Processing:**
```python
# MenuModifier.process()
1. Detect ~ in prefix_mods
2. Set anchor=True
3. Route to zNavigation.create(menu_data, anchor=True)
4. Menu displayed without back button
```

---

## Required Modifier (!)

**Retry command until it returns success (True).**

### Syntax

```python
# Suffix the key with !
result = z.dispatch.handle("validate!", {"zFunc": "validate_email"})
```

### Behavior

```python
# Executes command
# If returns False/None → prompt "Try again?"
# If user confirms → retry
# Repeat until function returns True or user cancels
```

### Validation Loop

```
┌─────────────────────────────┐
│ Execute command             │
├─────────────────────────────┤
│ ❌ Result: False            │
│ Try again? (Enter/n/stop):  │
├─────────────────────────────┤
│ User presses Enter          │
│ → Retry command             │
├─────────────────────────────┤
│ ❌ Result: False            │
│ Try again? (Enter/n/stop):  │
├─────────────────────────────┤
│ User enters 'n'             │
│ → Return None (cancelled)   │
└─────────────────────────────┘
```

### Use Cases

- **Form validation**: Email, password, phone
- **Required fields**: Must be filled before proceeding
- **Input validation**: Retry until valid input
- **Confirmation**: Must acknowledge before continuing

### Examples

```python
# Email validation
def validate_email(email):
    if "@" not in email:
        print("❌ Invalid email - missing @")
        return False
    print("✅ Valid email!")
    return True

result = z.dispatch.handle("email!", {"zFunc": "validate_email", "args": ["user@"]})
# Retries until valid email or cancelled

# Password strength
def check_password(password):
    if len(password) < 8:
        print("❌ Password too short (min 8 chars)")
        return False
    if not any(c.isupper() for c in password):
        print("❌ Password needs uppercase letter")
        return False
    print("✅ Strong password!")
    return True

result = z.dispatch.handle("password!", {"zFunc": "check_password"})

# Confirmation
def confirm_delete():
    response = input("Type 'DELETE' to confirm: ")
    if response != "DELETE":
        print("❌ Confirmation failed")
        return False
    print("✅ Confirmed")
    return True

result = z.dispatch.handle("confirm!", {"zFunc": "confirm_delete"})
```

### Implementation

**Detection:**
```python
suffix_mods = modifiers.check_suffix("validate!")
# Returns: ["!"]
```

**Processing:**
```python
# RequiredModifier.process()
1. Strip ! from key
2. Execute command via launcher.launch()
3. Check result:
   - True → return result
   - False/None → prompt "Try again?"
4. If user confirms → goto step 2
5. If user cancels → return None
```

---

## Combined Modifiers

Modifiers can be combined for powerful declarative patterns:

### Bounce + Required (^!)

**Retry until success, then return to menu.**

```python
# Validate password, then return to menu
result = z.dispatch.handle("^password!", {"zFunc": "check_password"})
# Retries until valid password
# Then returns "zBack" (zCLI) or result (zBifrost)
```

**Use cases:**
- Required form submissions with menu navigation
- Validation before proceeding
- Confirmation dialogs with back navigation

### Anchor + Menu (~*)

**Menu without back navigation.**

```python
# Welcome screen with no back button
result = z.dispatch.handle("~welcome*", welcome_menu)
```

**Use cases:**
- Entry points
- Authentication screens
- Terminal states

### All Together (^~*!)

While technically possible, not all combinations make semantic sense:

```python
# This doesn't make sense:
# "^~menu*!" - Bounce + Anchor + Menu + Required
# Anchor (~) is only meaningful with Menu (*)
# Required (!) on a menu doesn't make sense
```

**Valid combinations:**
- `^action` - Bounce
- `menu*` - Menu
- `~menu*` - Anchored menu
- `action!` - Required
- `^action!` - Bounce + Required

**Invalid combinations:**
- `^menu*` - Bounce on menu (menu already handles navigation)
- `~action` - Anchor without menu (meaningless)
- `^~action` - Bounce + Anchor without menu (meaningless)

---

## Modifier Priority

When multiple modifiers detected, processing order:

1. **Menu (*)** - Highest priority (creates menu structure)
2. **Bounce (^)** - Execute and return
3. **Required (!)** - Retry until success
4. **Anchor (~)** - Modifies menu behavior (no standalone processing)

**Example:**
```python
# "^validate!"
1. Detect: ["^", "!"]
2. Process: Required first (retry loop)
3. Then: Bounce (return based on mode)
```

---

## Mode Behavior

Modifiers adjust behavior based on execution mode:

### zCLI Mode (Terminal)

```python
# Bounce returns "zBack"
result = z.dispatch.handle("^save", cmd)
# Returns: "zBack" → triggers menu navigation

# Menu creates interactive selection
result = z.dispatch.handle("menu*", data)
# Displays menu → waits for input → dispatches selection

# Required prompts in terminal
result = z.dispatch.handle("validate!", cmd)
# Shows validation errors → prompts "Try again?"
```

### zBifrost Mode (Web)

```python
# Bounce returns actual result
result = z.dispatch.handle("^save", cmd)
# Returns: <actual result> → client handles navigation

# Menu creates structured response
result = z.dispatch.handle("menu*", data)
# Returns: menu structure → client renders UI

# Required handled client-side
result = z.dispatch.handle("validate!", cmd)
# Returns: validation result → client shows retry UI
```

---

## Error Handling

Modifiers handle errors gracefully:

```python
# Invalid modifier combination
result = z.dispatch.handle("^~action", cmd)
# Logs warning, processes as regular command

# Missing command after modifier
result = z.dispatch.handle("^", None)
# Returns: None (logs error)

# Modifier on invalid command
result = z.dispatch.handle("menu*", "not a dict")
# Returns: None (logs error)
```

---

## Best Practices

### Use Bounce for Actions

```python
# ✅ Good: Bounce on actions that should return
z.dispatch.handle("^delete", {"zFunc": "delete_user"})

# ❌ Bad: No bounce when you want to stay
z.dispatch.handle("delete", {"zFunc": "delete_user"})
# User stuck after deletion
```

### Use Anchor for Entry Points

```python
# ✅ Good: Anchor welcome screens
z.dispatch.handle("~welcome*", welcome_menu)

# ❌ Bad: Back button on welcome screen
z.dispatch.handle("welcome*", welcome_menu)
# User can "go back" to nothing
```

### Use Required for Validation

```python
# ✅ Good: Required for critical validation
z.dispatch.handle("password!", {"zFunc": "check_password"})

# ❌ Bad: No retry on validation failure
z.dispatch.handle("password", {"zFunc": "check_password"})
# User can proceed with invalid password
```

### Combine Thoughtfully

```python
# ✅ Good: Meaningful combinations
z.dispatch.handle("^password!", cmd)  # Validate then return
z.dispatch.handle("~menu*", data)     # Entry point menu

# ❌ Bad: Meaningless combinations
z.dispatch.handle("^~action", cmd)    # Anchor without menu?
z.dispatch.handle("menu*!", data)     # Required menu?
```

---

**[← Back to zDispatch Guide](../zDispatch_GUIDE.md)**
