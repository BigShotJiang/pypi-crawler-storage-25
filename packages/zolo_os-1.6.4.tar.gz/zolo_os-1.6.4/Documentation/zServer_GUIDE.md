# zServer Guide

> **Full-Featured HTTP Server with Declarative Routing**  
> Production-ready web server with static files, dynamic routes, caching, RBAC, and auto-discovery.

---

## What It Does

**zServer** is a comprehensive HTTP server subsystem built into zOS:

- ✅ **Static file serving** - HTML, CSS, JavaScript, images with smart caching
- ✅ **Declarative routing** - Define routes in zVaFiles (.zolo, .yaml, .json)
- ✅ **Auto-discovery** - Automatic route detection from directory structure
- ✅ **HTTP caching** - ETag, Last-Modified, Cache-Control with statistics
- ✅ **RBAC integration** - Role-based access control via zAuth
- ✅ **Mount management** - Static, templates, UI, plugins, custom mounts
- ✅ **Schema auto-init** - Database tables from models/ folder
- ✅ **Dual deployment** - Development (http.server) + Production (Gunicorn)
- ✅ **zWalker integration** - Server-side rendering of zUI blocks
- ✅ **Template rendering** - Jinja2 support for dynamic pages

**Status:** ✅ Production-ready (Manager-based architecture, comprehensive features)

---

## Quick Start

### 1. Simple Static Server (30 seconds)

```python
from zOS import zOS

z = zOS({"http_server": {"enabled": True, "port": 8080, "serve_path": "./public"}})
z.server.start()
print(f"Server: {z.server.get_url()}")
z.server.wait()
```

### 2. With Declarative Routing (2 minutes)

Create `zServer.routes.zolo`:
```yaml
type: server
routes:
  /:
    type: static
    file: index.html
  /about:
    type: static
    file: about.html
```

Run:
```python
from zOS import zOS

z = zOS({"http_server": {"enabled": True, "port": 8080, "serve_path": "."}})
z.server.start()
z.server.wait()
```

### 3. With Auto-Discovery (5 minutes)

Directory structure:
```
UI/
├── zUI.Dashboard.zolo
├── zUI.About.zolo
└── zProducts/
    └── zUI.zCLI.zolo
```

Route file:
```yaml
type: server
routes:
  /:
    type: zWalker
    zVaFolder: @.UI
    zVaFile: zUI.Dashboard
    zBlock: zDashboard
    auto_discover_blocks: true  # Auto-discovers /Dashboard, /About, /zProducts/zCLI
```

---

## Why It Matters

### For Developers
- **Manager-based architecture** - 9 specialized managers (Config, Route, Mount, Cache, Schema, Lifecycle, Dev, Gunicorn, WSGI)
- **Declarative routing** - Define routes in data files, not code
- **Auto-discovery** - Routes auto-detected from directory structure
- **Smart caching** - HTTP cache validation with ETag, Last-Modified, statistics
- **RBAC built-in** - Role-based access control via zAuth integration
- **Dual deployment** - Development (http.server) + Production (Gunicorn)
- **Template support** - Jinja2 rendering for dynamic pages
- **zWalker integration** - Server-side rendering of zUI blocks

### For Executives
- **Production-grade** - Gunicorn support with multi-worker deployment
- **Security first** - RBAC, mount isolation, cache policies
- **Performance** - HTTP caching reduces bandwidth and server load
- **Flexible deployment** - Development mode for rapid iteration, Production for scale
- **Database integration** - Auto-initializes schemas from models/ folder
- **Works standalone or with WebSocket** - Flexible full-stack architecture

---

## Architecture (Manager-Based)

```
zServer (HTTP Server Facade)
│
├── Core Managers (Configuration & Resources)
│   ├── ConfigManager - Server config, SSL, deployment mode
│   ├── MountManager - Static mounts (/static/, /templates/, /UI/, /plugins/)
│   ├── RouteManager - Route detection, loading, HTTPRouter initialization
│   ├── SchemaManager - Database schema auto-initialization
│   └── CacheManager - HTTP cache policies, ETag, statistics
│
├── Lifecycle Managers (Deployment)
│   ├── LifecycleManager - Orchestrates dev vs production
│   ├── DevServerManager - http.server (Development/Testing)
│   └── GunicornManager - Gunicorn subprocess (Production)
│
├── Routing System
│   ├── HTTPRouter - Declarative routing with auto-discovery
│   ├── RouteDispatcher - Request handling and dispatch
│   ├── SecurityChecks - RBAC enforcement via zAuth
│   └── Handler - HTTP request handler with CORS
│
├── Rendering System
│   ├── PageRenderer - zWalker integration (zUI → HTML)
│   ├── StaticFileHandler - Static file serving with cache
│   ├── ErrorPages - 403, 404 error handling
│   └── FormUtils - Declarative web forms
│
└── Utilities
    ├── HTTPCacheUtils - ETag, Last-Modified, 304 responses
    ├── JSONUtils - JSON response formatting
    └── Constants - Server configuration constants

Integration Points:
├── zOS initialization → zServer(logger, zos, config)
├── zAuth → RBAC enforcement in routes
├── zLoader → Route file loading
├── zParser → zVaFile parsing
├── zData → Schema auto-initialization
└── zWalker → Server-side rendering
```

**Architecture:** Manager-based delegation pattern for maintainability

---

## Feature Overview

| Feature | Status | Description |
|---------|--------|-------------|
| **Static File Serving** | ✅ | HTML, CSS, JS, images with MIME type detection |
| **Declarative Routing** | ✅ | Routes defined in zVaFiles (.zolo, .yaml, .json) |
| **Auto-Discovery** | ✅ | Routes from directory structure, schemas from models/ |
| **HTTP Caching** | ✅ | ETag, Last-Modified, Cache-Control, 304 responses |
| **RBAC Integration** | ✅ | Role-based access via zAuth (require_auth, require_role) |
| **Mount Management** | ✅ | /static/, /templates/, /UI/, /plugins/, custom mounts |
| **Schema Auto-Init** | ✅ | Database tables from models/zSchema.*.zolo files |
| **Development Mode** | ✅ | http.server in background thread |
| **Production Mode** | ✅ | Gunicorn with multi-worker support |
| **SSL/TLS Support** | ✅ | HTTPS with certificate validation |
| **zWalker Integration** | ✅ | Server-side rendering of zUI blocks |
| **Template Rendering** | ✅ | Jinja2 support for dynamic pages |
| **Parametrized Routes** | ✅ | /users/:user_id/avatar patterns |
| **Blueprint Pattern** | ✅ | Multiple route files merged automatically |
| **Cache Statistics** | ✅ | Hits, misses, bandwidth saved tracking |
| **CORS Support** | ✅ | Configurable cross-origin headers |
| **Error Pages** | ✅ | Custom 403, 404 pages |
| **Form Handling** | ✅ | Declarative web forms (zDialog for web) |
| **JSON Responses** | ✅ | Declarative JSON API endpoints |
| **Redirects** | ✅ | HTTP 301/302 redirects |

---

## Table of Contents

1. [What It Does](#what-it-does)
2. [Why It Matters](#why-it-matters)
3. [Architecture (Manager-Based)](#architecture-manager-based)
4. [How It Works](#how-it-works)
5. [API Reference](#api-reference)
6. [Configuration](#configuration)
7. [Common Patterns](#common-patterns)
8. [Relationship with zBifrost](#relationship-with-zbifrost)
9. [Manager Architecture Details](#manager-architecture-details)
10. [Best Practices](#best-practices)
11. [Security Considerations](#security-considerations)
12. [Troubleshooting](#troubleshooting)
13. [Performance Tips](#performance-tips)
14. [Route Types Reference](#route-types-reference)
15. [Summary](#summary)

---

## How It Works

### 1. Initialize zServer

```python
from zOS import zOS

z = zOS({
    "zWorkspace": ".",
    "http_server": {
        "enabled": True,
        "host": "127.0.0.1",
        "port": 8080,
        "serve_path": "./public"
    }
})

# zServer automatically initialized via zOS
# Managers handle: config, mounts, routes, schemas, cache
```

### 2. Start Server

```python
# Start server (deployment-aware)
z.server.start()

print(f"Server running at: {z.server.get_url()}")
# Output: Server running at: http://127.0.0.1:8080

# Development: http.server in background thread
# Production: Gunicorn with multiple workers
```

### 3. Declarative Routing

Create route file: `zServer.routes.zolo`

```yaml
type: server
meta:
  base_path: ./public
  default_route: index.html

routes:
  /:
    type: static
    file: index.html
  
  /about:
    type: static
    file: about.html
  
  /admin:
    type: static
    file: admin.html
    zRBAC:
      require_auth: true
      require_role: admin
  
  /dashboard:
    type: zWalker
    zVaFolder: @.UI
    zVaFile: zUI.Dashboard
    zBlock: zDashboard
    auto_discover_blocks: true
```

### 4. Auto-Discovery

Directory structure mirrors URL structure:

```
public/
├── UI/
│   ├── zUI.Dashboard.zolo → /Dashboard (auto-discovered)
│   ├── zProducts/
│   │   └── zUI.zCLI.zolo → /zProducts/zCLI (auto-discovered)
│   └── zUI.About.zolo → /About (auto-discovered)
├── static/
│   ├── style.css → /static/style.css
│   └── script.js → /static/script.js
└── models/
    └── zSchema.Users.zolo (auto-initialized on startup)
```

### 5. Stop Server

```python
# Graceful shutdown (works in all modes)
z.server.stop()

# Or use wait() to block until interrupted
z.server.wait()  # Ctrl+C handled automatically
```

---

## API Reference

### zServer Methods

#### `start()`
Start HTTP server (deployment-aware).

```python
z.server.start()
# Development/Testing → http.server (background thread)
# Production → Gunicorn (subprocess)
# Raises OSError if port already in use
```

#### `stop()`
Stop HTTP server gracefully (works in all modes).

```python
z.server.stop()
# Shuts down server, cleans up resources
```

#### `wait()`
Block until server is interrupted (signal-aware).

```python
z.server.wait()
# Keeps process alive, handles Ctrl+C gracefully
# Signal handlers registered by zOS call shutdown automatically
```

#### `is_running()`
Check if server is running.

```python
if z.server.is_running():
    print("Server is active")
# Returns: bool (works in all deployment modes)
```

#### `get_url()`
Get server URL.

```python
url = z.server.get_url()
# Returns: "http://127.0.0.1:8080" or "https://..." if SSL enabled
```

#### `health_check()`
Get comprehensive server status.

```python
status = z.server.health_check()
# Returns: {
#   "running": True,
#   "host": "127.0.0.1",
#   "port": 8080,
#   "url": "http://127.0.0.1:8080",
#   "serve_path": "/path/to/files"
# }
```

### Manager Access (Advanced)

```python
# ConfigManager
z.server.config_manager.get_deployment_mode()  # "Development" | "Production"

# MountManager
z.server.mount_manager.get_all_mounts()  # {"/static/": "/path/to/static", ...}

# RouteManager
z.server.route_manager.get_router()  # HTTPRouter instance

# CacheManager
z.server.cache_manager.get_statistics()  # {"hits": 42, "misses": 8, ...}
z.server.cache_manager.get_cache_policy("static")  # {"max_age": 3600, "public": True}

# SchemaManager (no public API - auto-initializes on startup)
```

---

## Configuration

### Via zSpark (zOS init)

```python
z = zOS({
    "http_server": {
        "enabled": True,
        "host": "127.0.0.1",
        "port": 8080,
        "serve_path": "./public",
        "routes_file": "zServer.routes.zolo",  # Optional: explicit route file
        "static_mounts": {                      # Optional: custom mounts
            "/assets/": "/path/to/assets",
            "/uploads/": "/var/uploads"
        },
        "ssl_enabled": False,                   # Optional: HTTPS
        "ssl_cert": "/path/to/cert.pem",       # Required if ssl_enabled
        "ssl_key": "/path/to/key.pem"          # Required if ssl_enabled
    },
    "deployment": "Development"  # or "Production" for Gunicorn
})
```

### Default Mounts (Auto-Configured)

```python
# MountManager automatically creates these mounts:
# /static/     → {serve_path}/static/
# /templates/  → {serve_path}/templates/
# /UI/         → {serve_path}/UI/
# /plugins/    → {serve_path}/plugins/ (auto-detected)
```

### Route File Auto-Detection

```python
# RouteManager automatically detects route files:
# 1. Root folder: zServer.*.zolo, zServer.*.yaml, zServer.*.json
# 2. routes/ subfolder: zServer.*.zolo, zServer.*.yaml, zServer.*.json
# Multiple files merged (blueprint pattern, last wins)
```

### Cache Policies (Configurable)

```python
# CacheManager default policies (extensible):
{
    "static": {"max_age": 3600, "public": True},      # 1 hour
    "api": {"max_age": 300, "public": False},         # 5 minutes
    "ui": {"max_age": 0, "public": False},            # Always revalidate
    "template": {"max_age": 0, "public": False},      # Always revalidate
    "favicon": {"max_age": 86400, "public": True}     # 1 day
}

# Development mode: All cache policies become "no-cache"
```

---

## Common Patterns

### Pattern 1: Simple Static Server

```python
#!/usr/bin/env python3
from zOS import zOS

z = zOS({
    "http_server": {
        "enabled": True,
        "port": 8080,
        "serve_path": "./public"
    }
})

# Start server and wait
z.server.start()
print(f"Server: {z.server.get_url()}")
z.server.wait()  # Blocks until Ctrl+C
```

### Pattern 2: Declarative Routing with Auto-Discovery

```python
#!/usr/bin/env python3
from zOS import zOS

z = zOS({
    "http_server": {
        "enabled": True,
        "port": 8080,
        "serve_path": "./public"
        # routes_file auto-detected from root and routes/ folder
        # schemas auto-initialized from models/ folder
    }
})

z.server.start()
print(f"Server: {z.server.get_url()}")
print(f"Routes: {len(z.server.router.route_map)} explicit + {len(z.server.router.auto_discovered_routes)} auto-discovered")
z.server.wait()
```

### Pattern 3: Full-Stack (HTTP + WebSocket)

```python
#!/usr/bin/env python3
from zOS import zOS

z = zOS({
    "zMode": "zBifrost",
    "websocket": {"port": 8765, "require_auth": False},
    "http_server": {"port": 8080, "serve_path": ".", "enabled": True}
})

# Start HTTP server
z.server.start()

print(f"HTTP:      {z.server.get_url()}")
print(f"WebSocket: ws://127.0.0.1:8765")

# Start WebSocket server (blocking)
z.walker.run()
```

### Pattern 4: Production Deployment

```python
#!/usr/bin/env python3
from zOS import zOS

z = zOS({
    "deployment": "Production",  # Triggers Gunicorn
    "http_server": {
        "enabled": True,
        "host": "0.0.0.0",
        "port": 8080,
        "serve_path": "/var/www/app",
        "ssl_enabled": True,
        "ssl_cert": "/etc/ssl/cert.pem",
        "ssl_key": "/etc/ssl/key.pem"
    }
})

# Start Gunicorn with 4 workers
z.server.start()
print(f"Production server: {z.server.get_url()}")
z.server.wait()
```

### Pattern 5: Cache Statistics Monitoring

```python
import time

z.server.start()

while z.server.is_running():
    stats = z.server.cache_manager.get_statistics()
    print(f"Cache: {stats['hits']} hits, {stats['misses']} misses, {stats['bytes_saved']} bytes saved")
    time.sleep(60)
```

---

## Relationship with zBifrost

**zServer** (HTTP) and **zBifrost** (WebSocket) are **independent systems**:

| Aspect | zServer | zBifrost |
|--------|---------|----------|
| Protocol | HTTP/HTTPS | WebSocket |
| Direction | One-way (request → response) | Bidirectional |
| Purpose | Web pages, APIs, static files | Real-time messaging |
| Library | `http.server` / `gunicorn` | `websockets` |
| Port | 8080 (default) | 8765 (default) |
| Auth | ✅ Yes (RBAC via zAuth) | ✅ Yes (session-based) |
| Routing | ✅ Declarative (zVaFiles) | ✅ Command-based (zDispatch) |
| Caching | ✅ HTTP cache (ETag, Last-Modified) | ❌ No |
| Deployment | Dev (http.server) + Prod (Gunicorn) | Single mode (asyncio) |

**Can Run:**
- ✅ **Standalone**: zServer only (no WebSocket)
- ✅ **Standalone**: zBifrost only (no HTTP)
- ✅ **Together**: Both systems (full-stack)

**Why Separate?**
- Different protocols (HTTP vs WebSocket)
- Different use cases (web pages vs real-time)
- Different deployment models (Gunicorn vs asyncio)
- Easier to maintain and update independently

---

## Manager Architecture Details

### ConfigManager
**Purpose:** Server configuration and path resolution  
**Responsibilities:**
- Extract config from HttpServerConfig object
- Resolve serve_path to absolute path
- Detect deployment mode (Development/Testing/Production)
- Manage SSL configuration

### MountManager
**Purpose:** Unified mount management (SSOT for URL → filesystem mapping)  
**Responsibilities:**
- Default mounts: /static/, /templates/, /UI/
- Custom mounts from config
- Auto-mount plugins folder
- Query interface for handlers

### RouteManager
**Purpose:** Route detection and loading  
**Responsibilities:**
- Auto-detect route files (root + routes/ folder)
- Load and merge routes (blueprint pattern)
- Initialize HTTPRouter
- Support .zolo, .yaml, .json formats

### CacheManager
**Purpose:** HTTP cache policy and validation  
**Responsibilities:**
- Cache policy configuration per file type
- ETag generation and validation
- 304 Not Modified responses
- Cache statistics tracking (hits, misses, bandwidth saved)

### SchemaManager
**Purpose:** Database schema auto-initialization  
**Responsibilities:**
- Auto-detect schemas in models/ folder
- Load schemas via zLoader
- Initialize database adapters
- Create tables (idempotent)

### LifecycleManager
**Purpose:** Deployment-aware server orchestration  
**Responsibilities:**
- Route to DevServerManager or GunicornManager
- WSGI module generation for Production
- Unified start/stop/wait interface
- Cleanup on shutdown

### DevServerManager
**Purpose:** Development server lifecycle  
**Responsibilities:**
- http.server setup and configuration
- SSL context creation
- Background thread management
- Development mode lifecycle

### GunicornManager
**Purpose:** Production server lifecycle  
**Responsibilities:**
- Gunicorn subprocess management
- Multi-worker configuration
- Health monitoring
- Graceful shutdown

### HTTPRouter
**Purpose:** Declarative routing with RBAC  
**Responsibilities:**
- Match paths to route definitions
- Auto-discover zBlock routes from directory structure
- Enforce RBAC via zAuth
- Support exact, parametrized, wildcard, default routes

---

## Best Practices

### ✅ DO: Use Declarative Routing
```python
# Define routes in zServer.routes.zolo, not code
# Easier to maintain, test, and version control
```

### ❌ DON'T: Hardcode Routes
```python
# Avoid Flask-style @app.route decorators
# Use zVaFiles for consistency with zOS patterns
```

---

### ✅ DO: Leverage Auto-Discovery
```python
# Directory structure mirrors URL structure
# UI/zProducts/zUI.zCLI.zolo → /zProducts/zCLI (automatic)
```

### ❌ DON'T: Create Explicit Routes for Every Page
```python
# Let auto_discover_blocks handle common patterns
# Only create explicit routes for special cases
```

---

### ✅ DO: Use RBAC for Protected Routes
```python
routes:
  /admin:
    type: static
    file: admin.html
    zRBAC:
      require_auth: true
      require_role: admin
```

### ❌ DON'T: Implement Auth in Code
```python
# Use declarative RBAC in route definitions
# Centralized, testable, auditable
```

---

### ✅ DO: Use wait() for Signal Handling
```python
z.server.start()
z.server.wait()  # Handles Ctrl+C automatically
```

### ❌ DON'T: Write Manual Signal Handlers
```python
try:
    z.server.start()
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    z.server.stop()  # Unnecessary boilerplate
```

---

### ✅ DO: Monitor Cache Statistics
```python
stats = z.server.cache_manager.get_statistics()
# Track hits, misses, bandwidth saved
```

### ❌ DON'T: Ignore Cache Performance
```python
# HTTP caching reduces server load significantly
# Monitor and optimize cache policies
```

---

### ✅ DO: Use Production Mode for Deployment
```python
z = zOS({"deployment": "Production"})
# Triggers Gunicorn with multi-worker support
```

### ❌ DON'T: Use Development Mode in Production
```python
# http.server is single-threaded
# Use Gunicorn for production workloads
```

---

## Security Considerations

### RBAC Integration

```python
# Route-level access control via zAuth
routes:
  /admin:
    type: static
    file: admin.html
    zRBAC:
      require_auth: true        # Must be logged in
      require_role: admin       # Must have admin role
      require_permission: edit  # Must have edit permission
```

### Mount Isolation

```python
# Mounts are isolated - no directory traversal
# /static/ only serves from {serve_path}/static/
# Path normalization prevents ../../../etc/passwd attacks
```

### Cache Security

```python
# Cache policies respect deployment mode
# Development: no-cache (always fresh)
# Production: policy-based (public/private per file type)
```

### SSL/TLS Support

```python
z = zOS({
    "http_server": {
        "ssl_enabled": True,
        "ssl_cert": "/path/to/cert.pem",
        "ssl_key": "/path/to/key.pem"
    }
})
# HTTPS with proper certificate validation
```

### Built-in Security Features

- ✅ **RBAC enforcement** - Role-based access control via zAuth
- ✅ **Mount isolation** - Prevents directory traversal
- ✅ **Path normalization** - Secure file path resolution
- ✅ **Cache policies** - Public/private per file type
- ✅ **SSL/TLS support** - HTTPS with certificate validation
- ✅ **Localhost default** - Secure by default (127.0.0.1)
- ✅ **CORS configurable** - Enable only for trusted origins

### Production Deployment

```python
# Use reverse proxy (nginx/Apache) for:
# - SSL termination
# - Rate limiting
# - DDoS protection
# - Load balancing
# - Static asset caching

# zServer handles:
# - Application logic
# - RBAC enforcement
# - Dynamic content
# - Database integration
```

---

## Troubleshooting

### Issue: Port already in use

```
OSError: [zServer] Port 8080 already in use
```

**Solution**: Change port or stop conflicting process
```python
z = zOS({
    "http_server": {"port": 9090}  # Use different port
})
```

### Issue: Routes not auto-detected

```
[zServer] No zServer route files found - static serving only
```

**Solution**: Check file naming and location
```bash
# Route files must match pattern:
# - zServer.*.zolo, zServer.*.yaml, zServer.*.json
# - In root folder OR routes/ subfolder

# Examples:
# ✅ zServer.routes.zolo
# ✅ routes/zServer.api.yaml
# ❌ routes.zolo (missing zServer. prefix)
```

### Issue: Auto-discovered routes not working

```
[Router] Auto-discovery complete: 0 virtual routes
```

**Solution**: Enable auto_discover_blocks in route definition
```yaml
routes:
  /:
    type: zWalker
    zVaFolder: @.UI
    zVaFile: zUI.Main
    zBlock: zMain
    auto_discover_blocks: true  # Required for auto-discovery
```

### Issue: Schema not auto-initialized

```
[zServer] No zSchema files found in models/
```

**Solution**: Check schema file naming and location
```bash
# Schema files must:
# - Be in models/ folder
# - Match pattern: zSchema.*.zolo, zSchema.*.yaml, zSchema.*.json

# Examples:
# ✅ models/zSchema.Users.zolo
# ✅ models/zSchema.Products.yaml
# ❌ models/schema.zolo (missing zSchema. prefix)
```

### Issue: RBAC not enforcing

```
[HTTPRouter] Access granted: public route
```

**Solution**: Add zRBAC to route definition
```yaml
routes:
  /admin:
    type: static
    file: admin.html
    zRBAC:
      require_auth: true
      require_role: admin
```

### Issue: Cache not working

```
Cache: 0 hits, 100 misses
```

**Solution**: Check deployment mode and cache policies
```python
# Development mode forces no-cache
# Use Production mode for cache testing
z = zOS({"deployment": "Production"})

# Or check cache policies
policies = z.server.cache_manager.policies
print(policies)  # Should show max_age > 0 for static files
```

### Issue: Gunicorn not starting

```
OSError: Gunicorn is not installed
```

**Solution**: Install Gunicorn for Production mode
```bash
pip install gunicorn

# Or use Development mode
z = zOS({"deployment": "Development"})
```

---

## Performance Tips

### 1. HTTP Caching
```python
# Monitor cache effectiveness
stats = z.server.cache_manager.get_statistics()
hit_rate = stats['hits'] / (stats['hits'] + stats['misses'])
print(f"Cache hit rate: {hit_rate:.1%}")

# Optimize cache policies for your workload
# Static assets: long max_age (3600s+)
# API responses: short max_age (300s)
# UI pages: no-cache (always fresh)
```

### 2. Production Deployment
```python
# Use Gunicorn with multiple workers
z = zOS({
    "deployment": "Production",
    "http_server": {"enabled": True}
})
# Gunicorn defaults to 4 workers (configurable in GunicornManager)
```

### 3. Static File Optimization
```python
# Serve static assets from CDN in production
# Use zServer for application logic only
# Let nginx/Apache handle static files at scale
```

### 4. Route Organization
```python
# Use blueprint pattern for modular routes
# routes/zServer.api.yaml - API endpoints
# routes/zServer.admin.yaml - Admin pages
# routes/zServer.public.yaml - Public pages
# All merged automatically, last wins for conflicts
```

### 5. Database Schema Management
```python
# Auto-initialization on startup
# models/zSchema.Users.zolo
# models/zSchema.Products.zolo
# Tables created only if missing (idempotent)
```

### 6. Monitor Server Health
```python
import time

while z.server.is_running():
    health = z.server.health_check()
    cache = z.server.cache_manager.get_statistics()
    print(f"Server: {health['url']}, Cache: {cache['hits']} hits")
    time.sleep(60)
```

---

## Route Types Reference

### static
Serve static files from filesystem.
```yaml
/:
  type: static
  file: index.html
```

### zWalker
Execute zUI blocks via zWalker (server-side rendering).
```yaml
/dashboard:
  type: zWalker
  zVaFolder: @.UI
  zVaFile: zUI.Dashboard
  zBlock: zDashboard
  auto_discover_blocks: true  # Enable auto-discovery
```

### template
Render Jinja2 templates with context.
```yaml
/profile:
  type: template
  file: profile.html
  context:
    user: "{{ session.user }}"
```

### form
Declarative web forms (zDialog pattern for web).
```yaml
/contact:
  type: form
  schema: zForm.Contact
```

### json
Declarative JSON responses.
```yaml
/api/status:
  type: json
  data:
    status: ok
    version: 1.0
```

### redirect
HTTP redirects.
```yaml
/old-page:
  type: redirect
  target: /new-page
  code: 301
```

---

## Summary

**zServer** is a full-featured HTTP server built into zOS:

- **Manager-based** - 9 specialized managers for clean architecture
- **Declarative** - Routes, schemas, mounts defined in data files
- **Auto-discovery** - Routes from directory structure, schemas from models/
- **HTTP caching** - ETag, Last-Modified, Cache-Control with statistics
- **RBAC** - Role-based access control via zAuth integration
- **Dual deployment** - Development (http.server) + Production (Gunicorn)
- **zWalker integration** - Server-side rendering of zUI blocks
- **Template support** - Jinja2 rendering for dynamic pages

**Use Cases:**
- Web applications with declarative routing
- Full-stack apps (with zBifrost WebSocket)
- RESTful APIs with RBAC
- Server-side rendered UIs (zWalker)
- Static asset hosting with caching

**Architecture:** Manager-based delegation pattern  
**Status:** ✅ Production Ready  
**Version:** 1.5.4+
