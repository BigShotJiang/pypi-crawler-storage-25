**[← Back to zAuth Guide](../zAuth_GUIDE.md)**

---

# Persistence Module Guide

**Module**: `zAuth_modules/persistence/session_persistence.py`  
**Class**: `SessionPersistence`  
**Purpose**: SQLite-based persistent session management with 7-day expiration

---

## Overview

The **SessionPersistence** module provides persistent session storage using SQLite, enabling "Remember me" functionality across application restarts. It integrates deeply with zOS's declarative zData subsystem and three-tier authentication architecture.

### Key Features

- **SQLite Storage**: Unified auth database (sessions + permissions)
- **Declarative zData**: No raw SQL queries
- **Lazy Initialization**: Database loaded on demand
- **Automatic Expiration**: 7-day default (configurable)
- **Three-Tier Awareness**: Persists zSession context only
- **Secure Tokens**: Cryptographically secure session and API tokens

---

## Architecture

### Design Pattern

```
SessionPersistence (Facade)
├── SessionDatabase      # Schema loading and table management
│   ├── initialize()
│   ├── is_ready()
│   └── _load_schema()
│
└── SessionStore         # CRUD operations for session data
    ├── load()
    ├── save()
    ├── cleanup_expired()
    └── _generate_token()
```

### Composition Pattern

The module uses **composition** to delegate operations:

- **SessionDatabase**: Handles schema loading and database initialization
- **SessionStore**: Handles session CRUD operations and token generation

This separation ensures clean responsibilities and maintainability.

---

## Session Lifecycle

### 1. LOAD - Restore Session on Startup

```python
zos = zOS()
# Automatically calls session_persistence.load_session()

if zos.auth.is_authenticated():
    print("Session restored from disk!")
```

**Process**:
1. Query database for valid session (not expired)
2. Restore to `session["zAuth"]["zSession"]`
3. Set `active_context` to "zSession"
4. Update `last_accessed` timestamp

---

### 2. SAVE - Persist Session After Login

```python
result = zos.auth.login("user@zolo.com", "password", persist=True)
# Calls session_persistence.save_session()
```

**Process**:
1. Generate session_id and API token (cryptographically secure)
2. Calculate expiration timestamp (now + 7 days)
3. Delete existing sessions for user (single session policy)
4. Insert new session record
5. Update in-memory session

---

### 3. EXPIRE - Automatic Expiration

Sessions expire after **7 days** (configurable):

```python
# Configure custom expiration
zos.auth.session_persistence.session_duration_days = 30
```

**Expiration Logic**:
- `expires_at` timestamp calculated on save
- Sessions with `expires_at <= now` are considered expired
- Expired sessions excluded from load queries
- Manual cleanup via `cleanup_expired()`

---

### 4. CLEANUP - Remove Expired Sessions

```python
deleted = zos.auth.session_persistence.cleanup_expired()
print(f"Cleaned up {deleted} expired sessions")
```

**When**:
- Automatically on database initialization
- Manually via `cleanup_expired()` method
- Recommended: Periodic cleanup (e.g., daily cron job)

---

## Database Structure

### Unified Auth Database

**Database Label**: `"auth"`  
**Shared By**: SessionPersistence + RBAC modules  
**Schema File**: `zSchema.auth.yaml` (declarative YAML)

### Table: sessions

| Field | Type | Description |
|-------|------|-------------|
| `session_id` | TEXT PRIMARY KEY | Unique session identifier (32-byte token) |
| `user_id` | TEXT | User identifier (from authentication) |
| `username` | TEXT | Username for the session |
| `role` | TEXT | User role (user, admin, etc.) |
| `password_hash` | TEXT | bcrypt password hash |
| `token` | TEXT | API token (32-byte token) |
| `created_at` | TEXT | ISO timestamp when session was created |
| `expires_at` | TEXT | ISO timestamp when session expires |
| `last_accessed` | TEXT | ISO timestamp of last access |

### Table: user_permissions

Managed by RBAC module (shared database).

---

## Storage Location

Sessions are stored in platform-specific application data directories:

| Platform | Location |
|----------|----------|
| **macOS** | `~/Library/Application Support/zOS/zAuth/auth.db` |
| **Linux** | `~/.local/share/zOS/zAuth/auth.db` |
| **Windows** | `%APPDATA%\zOS\zAuth\auth.db` |

Uses `platformdirs` library for cross-platform path resolution.

---

## Security Model

### Token Generation

```python
import secrets

# Cryptographically secure tokens
session_id = secrets.token_urlsafe(32)  # 43 characters
api_token = secrets.token_urlsafe(32)   # 43 characters
```

**Properties**:
- URL-safe base64 encoding
- 256 bits of entropy (32 bytes)
- Unpredictable and unique
- Suitable for session identifiers and API keys

---

### Password Storage

- **Never stores plaintext passwords**
- Stores bcrypt password hash (from PasswordSecurity)
- Hash used for session verification if needed
- 60-character bcrypt hash format: `$2b$12$...`

---

### Single Session Per User

```python
# Before saving new session
# Delete existing sessions for user
zos.data.delete(
    db_label="auth",
    table="sessions",
    where={"username": username}
)

# Insert new session
# Last login wins (invalidates previous sessions)
```

**Rationale**:
- Prevents session accumulation
- Security: Logout invalidates old sessions
- Simplicity: One active session per user

---

## Three-Tier Integration

### Session Persistence Scope

| Tier | Persisted? | Rationale |
|------|-----------|-----------|
| **Tier 1** (zSession) | ✓ Yes | Persistent identity (zOS/Zolo user) |
| **Tier 2** (Application) | ✗ No | Transient per-application sessions |
| **Tier 3** (Dual-Mode) | ✗ No | Runtime state (not stored) |

### Session Restoration Behavior

```python
zos = zOS()
# On initialization:

# 1. Load session from database
session_data = load_session()

# 2. Restore ONLY zSession context
if session_data:
    session["zAuth"]["zSession"] = session_data
    session["zAuth"]["active_context"] = "zSession"

# 3. Applications must re-authenticate
# session["zAuth"]["applications"] = {}  # Empty

# 4. Dual-auth must be re-established
# session["zAuth"]["dual_mode"] = False
```

**Why Only zSession?**
- zSession represents persistent platform identity
- Application contexts are app-specific and transient
- Dual-auth is a runtime relationship, not stored state

---

## zData Integration

### Declarative Operations

**NO raw SQL queries**. All database operations use zData:

```python
# SELECT
results = zos.data.select(
    db_label="auth",
    table="sessions",
    where={"username": username}
)

# INSERT
zos.data.insert(
    db_label="auth",
    table="sessions",
    data={
        "session_id": session_id,
        "username": username,
        # ... other fields
    }
)

# UPDATE
zos.data.update(
    db_label="auth",
    table="sessions",
    where={"session_id": session_id},
    data={"last_accessed": timestamp}
)

# DELETE
zos.data.delete(
    db_label="auth",
    table="sessions",
    where={"username": username}
)
```

---

### Schema Loading via zParser

```python
# Load YAML schema from package directory
schema_path = os.path.join(
    os.path.dirname(__file__),
    "../../zSchemas/auth.yaml"
)

# Parse schema
zos.zparser.parse_file(schema_path)

# Register with zData
zos.data.register_schema("auth", parsed_schema)
```

---

## API Reference

### Constructor

```python
SessionPersistence(
    zos: Any,
    session_duration_days: int = 7
)
```

**Args**:
- `zos`: zOS instance providing access to data, loader, logger, session, zparser
- `session_duration_days`: Session expiration period in days (default: 7)

**Example**:

```python
# Default 7-day expiration
session_mgr = SessionPersistence(zos)

# Custom 30-day expiration (long-lived sessions)
session_mgr = SessionPersistence(zos, session_duration_days=30)

# Initialize database
session_mgr.ensure_sessions_db()
```

---

### ensure_sessions_db()

```python
def ensure_sessions_db() -> None
```

Initialize the sessions database (declarative zOS way).

**Process**:
1. Load schema from `zSchema.auth.yaml` via zParser
2. Create tables if not exist (via zData)
3. Perform automatic cleanup of expired sessions

**Example**:

```python
session_mgr = SessionPersistence(zos)
session_mgr.ensure_sessions_db()

# Safe to call multiple times (idempotent)
session_mgr.ensure_sessions_db()
```

**Notes**:
- Safe to call multiple times (idempotent)
- Automatic cleanup on initialization
- Shares database with RBAC module

---

### load_session()

```python
def load_session() -> Optional[Dict[str, Any]]
```

Load and restore persistent session on startup (if exists and valid).

**Returns**: `Optional[Dict]` - Session data if found and valid, None otherwise

**Example**:

```python
session_mgr = SessionPersistence(zos)
session_mgr.ensure_sessions_db()

# Load session (automatically called by zAuth on init)
session_mgr.load_session()

# Check if restored
if zos.auth.is_authenticated():
    print("Session restored successfully!")
    creds = zos.auth.get_credentials()
    print(f"Username: {creds['username']}")
```

**Process**:
1. Check database readiness
2. Query for valid session (not expired)
3. Restore to `session["zAuth"]["zSession"]`
4. Set `active_context` to "zSession"
5. Update `last_accessed` timestamp

**Failure Cases**:
- Database not loaded: Skip restore
- No session found: Clean start
- Session expired: Skip restore
- Database error: Log error, continue

---

### save_session()

```python
def save_session(
    username: str,
    password_hash: str,
    user_id: Optional[str] = None,
    role: str = "user"
) -> Optional[str]
```

Save current session to persistent storage (sessions database).

**Args**:
- `username`: Username for the session
- `password_hash`: bcrypt password hash
- `user_id`: Optional user ID (defaults to username)
- `role`: User role (default: "user")

**Returns**: `str` - Generated session_id if successful, None if failed

**Example**:

```python
session_mgr = SessionPersistence(zos)
session_mgr.ensure_sessions_db()

# Save session after login
hashed = pwd_security.hash_password("password")
session_id = session_mgr.save_session(
    username="john_doe",
    password_hash=hashed,
    user_id="zU_12345",
    role="admin"
)

if session_id:
    print(f"Session saved: {session_id}")
```

**Process**:
1. Check database readiness (lazy initialization)
2. Generate session_id and API token (cryptographically secure)
3. Calculate timestamps (created_at, expires_at)
4. Delete existing sessions for user (single session policy)
5. Insert new session record
6. Update in-memory `session["zAuth"]["zSession"]`

**Token Generation**:
- `session_id`: `secrets.token_urlsafe(32)` (43 chars)
- `token`: `secrets.token_urlsafe(32)` (43 chars)

**Expiration**:
- `expires_at = now + session_duration_days`
- Default: 7 days from creation

---

### cleanup_expired()

```python
def cleanup_expired() -> int
```

Remove expired sessions from database (housekeeping).

**Returns**: `int` - Number of sessions deleted (0 if none expired)

**Example**:

```python
session_mgr = SessionPersistence(zos)
session_mgr.ensure_sessions_db()

# Manual cleanup
deleted = session_mgr.cleanup_expired()
if deleted > 0:
    print(f"Cleaned up {deleted} expired sessions")

# Periodic cleanup (recommended)
import schedule

schedule.every().day.at("03:00").do(
    lambda: session_mgr.cleanup_expired()
)
```

**Process**:
1. Check database readiness
2. Query for expired sessions (`expires_at <= now`)
3. Delete expired records
4. Return count of deleted sessions

**When to Call**:
- Automatic: On database initialization
- Manual: Periodically (daily recommended)
- On-demand: As needed for housekeeping

---

## Usage Examples

### Basic Session Lifecycle

```python
from zOS import zOS

# Initialize zOS
zos = zOS()

# ═══════════════════════════════════════════════════════════
# First Run: Login and Save Session
# ═══════════════════════════════════════════════════════════

result = zos.auth.login(
    username="user@zolo.com",
    password="secure_password",
    persist=True  # Saves to SQLite
)

if result["success"]:
    print("Logged in and session saved!")
    print(f"Username: {result['username']}")
    print(f"API Key: {result['api_key']}")

# ═══════════════════════════════════════════════════════════
# Later Run: Session Automatically Restored
# ═══════════════════════════════════════════════════════════

zos2 = zOS()
# Session loaded from SQLite on initialization

if zos2.auth.is_authenticated():
    print("Session restored from disk!")
    creds = zos2.auth.get_credentials()
    print(f"Username: {creds['username']}")
    print(f"API Key: {creds['api_key']}")
else:
    print("No valid session found")
```

---

### Manual Session Management

```python
from zOS import zOS

zos = zOS()

# Access persistence module directly
session_mgr = zos.auth.session_persistence

# Ensure database initialized
session_mgr.ensure_sessions_db()

# Load session manually
session_mgr.load_session()

# Save session manually
hashed = zos.auth.hash_password("password")
session_id = session_mgr.save_session(
    username="john_doe",
    password_hash=hashed,
    user_id="zU_12345",
    role="admin"
)

print(f"Session ID: {session_id}")

# Cleanup expired sessions
deleted = session_mgr.cleanup_expired()
print(f"Cleaned up {deleted} sessions")
```

---

### Custom Expiration Duration

```python
from zOS import zOS

zos = zOS()

# Change expiration (before saving)
zos.auth.session_persistence.session_duration_days = 30

# Login with 30-day expiration
result = zos.auth.login("user", "pass", persist=True)

# Session will expire in 30 days instead of default 7
```

---

### Database Inspection

```python
from zOS import zOS

zos = zOS()

# Ensure database loaded
zos.auth.session_persistence.ensure_sessions_db()

# Query sessions directly via zData
results = zos.data.select(
    db_label="auth",
    table="sessions",
    where={}  # Get all sessions
)

for session in results:
    print(f"User: {session['username']}")
    print(f"Created: {session['created_at']}")
    print(f"Expires: {session['expires_at']}")
    print(f"Session ID: {session['session_id']}")
    print("---")
```

---

### Periodic Cleanup Script

```python
import schedule
import time
from zOS import zOS

def cleanup_sessions():
    zos = zOS()
    deleted = zos.auth.session_persistence.cleanup_expired()
    if deleted > 0:
        print(f"[{time.ctime()}] Cleaned up {deleted} expired sessions")

# Schedule daily cleanup at 3 AM
schedule.every().day.at("03:00").do(cleanup_sessions)

# Run forever
while True:
    schedule.run_pending()
    time.sleep(60)
```

---

## Best Practices

### Session Management

1. **Always use persist=True for "Remember me"**:
   ```python
   # Good: Persistent session
   zos.auth.login(username, password, persist=True)
   
   # Temporary: In-memory only
   zos.auth.login(username, password, persist=False)
   ```

2. **Logout with cleanup**:
   ```python
   # Full cleanup
   zos.auth.logout(delete_persistent=True)
   
   # Keep session on disk
   zos.auth.logout(delete_persistent=False)
   ```

3. **Periodic cleanup**:
   ```python
   # Recommended: Daily cleanup
   schedule.every().day.at("03:00").do(cleanup_expired)
   ```

### Security

1. **Never expose session_id or token**:
   ```python
   # Good: Log username only
   logger.info(f"Session restored for: {username}")
   
   # Bad: Exposes session token
   # logger.info(f"Session: {session_id}")  # DON'T
   ```

2. **Validate session on critical operations**:
   ```python
   # Check authentication before sensitive operations
   if not zos.auth.is_authenticated():
       raise PermissionError("Authentication required")
   
   # Perform operation
   delete_user_data()
   ```

3. **Use appropriate expiration**:
   ```python
   # Short-lived for high-security
   session_duration_days = 1  # 1 day
   
   # Long-lived for convenience
   session_duration_days = 30  # 30 days
   
   # Balance security and UX
   session_duration_days = 7  # 7 days (default)
   ```

### Performance

1. **Initialize database once**:
   ```python
   # Good: Once on startup
   zos.auth.session_persistence.ensure_sessions_db()
   
   # Bad: Repeated initialization
   # for _ in range(100):
   #     ensure_sessions_db()  # DON'T
   ```

2. **Batch cleanup operations**:
   ```python
   # Good: Periodic cleanup (daily)
   schedule.every().day.do(cleanup_expired)
   
   # Bad: After every operation
   # after_login():
   #     cleanup_expired()  # Too frequent
   ```

---

## Troubleshooting

### Common Issues

**1. Session not persisting across restarts**

```python
# Check persist flag
result = zos.auth.login(username, password, persist=True)  # Must be True

# Check database initialization
zos.auth.session_persistence.ensure_sessions_db()

# Check database location
import os
db_path = zos.config.paths.get_auth_db_path()
print(f"Database: {db_path}")
print(f"Exists: {os.path.exists(db_path)}")
```

**2. "Database not loaded" warnings**

```python
# Ensure database initialized before use
zos.auth.session_persistence.ensure_sessions_db()

# Check zData handler
if hasattr(zos, 'data') and zos.data:
    print("zData ready")
else:
    print("zData not initialized")
```

**3. Session expires too quickly**

```python
# Check expiration setting
duration = zos.auth.session_persistence.session_duration_days
print(f"Session duration: {duration} days")

# Change if needed (before login)
zos.auth.session_persistence.session_duration_days = 30
```

**4. Database file permission errors**

```python
# Check database directory permissions
db_path = zos.config.paths.get_auth_db_path()
db_dir = os.path.dirname(db_path)

# Ensure directory exists and is writable
os.makedirs(db_dir, exist_ok=True)
os.access(db_dir, os.W_OK)  # Check write access
```

---

## Performance Characteristics

| Operation | Time | Notes |
|-----------|------|-------|
| **ensure_sessions_db()** | 50-100ms | First call only (loads schema) |
| **load_session()** | <50ms | Single SELECT query |
| **save_session()** | <100ms | DELETE + INSERT queries |
| **cleanup_expired()** | <100ms | Single DELETE query |

**Optimization Tips**:
- Database operations are fast (<100ms)
- No need for aggressive caching
- Periodic cleanup is sufficient (daily)
- SQLite handles concurrent reads well

---

**[← Back to zAuth Guide](../zAuth_GUIDE.md)**
