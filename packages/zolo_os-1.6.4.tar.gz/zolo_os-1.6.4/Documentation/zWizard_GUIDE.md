**[← Back to zOpen Guide](zOpen_GUIDE.md) | [Home](../README.md) | [Next: zData Guide →](zData_GUIDE.md)**

---

# zWizard

**zWizard** is the **core loop engine** in **zOS** (Layer 3).
> See [**zArchitecture**](../README.md#the-zarchitecture) for full context.

It provides stepped execution for wizards and walkers - orchestrating multi-step workflows with automatic result accumulation, template interpolation, transaction management, and navigation control.

You get:

- **Zero boilerplate**  
- **No manual result tracking**
- **No template engine imports**  
- **Triple-access results** (numeric, key, attribute)
- **Template interpolation** ({{ zHat.key }})
- **Transaction management** (commit/rollback)
- **RBAC integration** (role-based access control)
- **Navigation signals** (zBack, exit, stop, error)
- **Mode-aware execution** (sequential vs chunked)

## Architecture Overview

**zWizard** is composed of specialized modules, each handling a specific aspect of workflow execution:

| Module | Purpose | Guide |
|--------|---------|-------|
| **wizard_hat** | Triple-access result container (numeric, key, attribute) | [wizard_hat_GUIDE.md](zWizard_Guides/wizard_hat_GUIDE.md) |
| **wizard_interpolation** | zHat template variable interpolation ({{ zHat.key }}) | [wizard_interpolation_GUIDE.md](zWizard_Guides/wizard_interpolation_GUIDE.md) |
| **wizard_transactions** | Database transaction management (commit/rollback) | [wizard_transactions_GUIDE.md](zWizard_Guides/wizard_transactions_GUIDE.md) |
| **wizard_rbac** | Role-based access control enforcement | [wizard_rbac_GUIDE.md](zWizard_Guides/wizard_rbac_GUIDE.md) |
| **wizard_exceptions** | Custom exception hierarchy | [wizard_exceptions_GUIDE.md](zWizard_Guides/wizard_exceptions_GUIDE.md) |
| **navigation** | Navigation signals, breadcrumbs, menu looping | [navigation_GUIDE.md](zWizard_Guides/navigation_GUIDE.md) |
| **dispatch** | Dispatch function creation and routing | [dispatch_GUIDE.md](zWizard_Guides/dispatch_GUIDE.md) |
| **data** | Block-level data resolution (Flask pattern) | [data_GUIDE.md](zWizard_Guides/data_GUIDE.md) |
| **filters** | Key filtering and shorthand expansion | [filters_GUIDE.md](zWizard_Guides/filters_GUIDE.md) |
| **conditions** | Conditional evaluation (if statements) | [conditions_GUIDE.md](zWizard_Guides/conditions_GUIDE.md) |
| **execution** | Mode-aware execution strategies (sequential/chunked) | [execution_GUIDE.md](zWizard_Guides/execution_GUIDE.md) |

This guide provides a **facade overview** of zWizard. For deep dives into specific modules, see the guides in `zWizard_Guides/`.

---

## Initialization Order

When you call `zOS()`, zWizard initializes automatically as part of Layer 3 orchestration:

1. **Layer 0**: zConfig → zComm (foundation)
2. **Layer 1**: zDisplay → zAuth → zDispatch (display and dispatch)
3. **Layer 2**: zParser → zLoader → zFunc (parsing and utilities)
4. **Layer 3**: zDialog → zOpen → **zWizard** → zData → zShell → zWalker → zServer (orchestration)

**zWizard initialization sequence:**
1. Validate zOS or zWalker instance (requires session + logger)
2. Initialize specialized managers (navigation, dispatch, data, filters, conditions)
3. Initialize execution strategies (sequential, chunked)
4. Display ready message (if zDisplay available)
5. Log ready state

---

## What's in This Guide

This guide covers the **main zWizard facade** - the unified interface to all workflow execution features. Following the zConfig/zComm pattern:

1. **Architecture Overview** - Module structure and design patterns
2. **Initialization** - How zWizard auto-initializes in Layer 3
3. **Tutorials** - Hands-on patterns (Level 1-4) for learning by doing
4. **API Reference** - Complete method signatures and usage patterns
5. **Advanced Features** - Transactions, RBAC, interpolation, navigation

**What's NOT in this guide:**
- Deep dives into individual modules (see `zWizard_Guides/` folder)
- Walker implementation details (see [zWalker Guide](zWalker_GUIDE.md))
- Shell command execution (see [zShell Guide](zShell_GUIDE.md))

**Current Implementation Status:**
- ✅ Triple-access results (WizardHat)
- ✅ Template interpolation (zHat variables)
- ✅ Transaction management (commit/rollback)
- ✅ RBAC integration (role-based access control)
- ✅ Navigation signals (zBack, exit, stop, error)
- ✅ Mode-aware execution (sequential vs chunked)
- ✅ Block-level data resolution (Flask pattern)
- ✅ Conditional execution (if statements)

---

## Tutorials

**Learn by doing!** 

The tutorials below are organized in a bottom-up fashion. Every tutorial below has a working demo you can run and modify.

**A Note on Learning zOS:**  
Each tutorial (lvl1, lvl2, lvl3...) progressively introduces more complex features of **this subsystem**. The early tutorials start with familiar imperative patterns (think Django-style conventions) to meet you where you are as a developer.

As you progress through zOS's subsystems, you'll notice a gradual shift from imperative to declarative patterns. This intentional journey helps reshape your mental model from imperative to declarative thinking. Only when you reach **Layer 3 (Orchestration)** will you see subsystems used **fully declaratively** as intended in production. By then, the true magic of declarative coding will reveal itself, and you'll understand why we started this way.

Get the demos:

```bash
# Clone only the Demos folder
git clone --depth 1 --filter=blob:none --sparse https://github.com/ZoloAi/zolo-zcli.git
cd zolo-zcli
git sparse-checkout set Demos
```

> All zWizard demos are in: `Demos/Layer_3/zWizard_Demo/`

---

# **zWizard - Level 1** (Basic Workflows)

### **i. Execute Loop Basics**

The simplest zWizard operation - execute a sequence of steps and collect results.

```python
from zOS import zOS

z = zOS({
    "deployment": "Production",
    "title": "wizard-basic",
    "logger": "INFO",
    "logger_path": "./logs",
})

# Define workflow steps
workflow_items = {
    "welcome": {
        "type": "zDisplay",
        "event": "text",
        "content": "Welcome to User Creation Wizard",
        "color": "MAIN"
    },
    "get_username": {
        "type": "zDialog",
        "prompt": "Enter username:",
        "validate": "required"
    },
    "get_email": {
        "type": "zDialog",
        "prompt": "Enter email:",
        "validate": "email"
    },
}

# Execute workflow
result = z.wizard.execute_loop(workflow_items)

# Result is a WizardHat object with triple-access
print(f"Username: {result['get_username']}")  # Key access
print(f"Email: {result.get_email}")  # Attribute access
print(f"First result: {result[0]}")  # Numeric access
```

**What you discover:**
- Execute multi-step workflows with one method call
- Results auto-collected in WizardHat (triple-access container)
- Access results by key, attribute, or numeric index
- No manual result tracking needed

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl1_basics/1_execute_loop.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl1_basics/1_execute_loop.py)

---

### **ii. WizardHat - Triple-Access Results**

Learn the three ways to access wizard results using WizardHat.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow_items = {
    "step1": {"type": "zDisplay", "event": "text", "content": "Step 1"},
    "step2": {"type": "zDisplay", "event": "text", "content": "Step 2"},
    "step3": {"type": "zDisplay", "event": "text", "content": "Step 3"},
}

zHat = z.wizard.execute_loop(workflow_items)

# Method 1: Numeric access (backward compatible)
print(f"First step: {zHat[0]}")
print(f"Second step: {zHat[1]}")
print(f"Third step: {zHat[2]}")

# Method 2: Key-based access (semantic)
print(f"Step1: {zHat['step1']}")
print(f"Step2: {zHat['step2']}")
print(f"Step3: {zHat['step3']}")

# Method 3: Attribute access (convenient!)
print(f"Step1: {zHat.step1}")
print(f"Step2: {zHat.step2}")
print(f"Step3: {zHat.step3}")

# Check existence
print("step1" in zHat)  # True
print(0 in zHat)  # True
print(10 in zHat)  # False
```

**What you discover:**
- Three access patterns: numeric, key, attribute
- Backward compatibility (numeric indexing)
- Semantic access (key-based, readable)
- Convenient access (attribute style)
- Existence checking (in operator)

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl1_basics/2_wizard_hat.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl1_basics/2_wizard_hat.py)

---

### **iii. YAML-Based Workflows**

Most powerful pattern - define workflows in YAML and execute declaratively.

```yaml
# workflow.yaml
welcome:
  type: zDisplay
  event: text
  content: "Welcome to Setup Wizard"
  color: MAIN

get_name:
  type: zDialog
  prompt: "Enter your name:"
  validate: required

get_email:
  type: zDialog
  prompt: "Enter email:"
  validate: email

confirm:
  type: zDisplay
  event: text
  content: "Setup complete!"
  color: SUCCESS
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

# Load workflow from YAML
workflow = z.loader.load_yaml("workflow.yaml")

# Execute workflow
zHat = z.wizard.handle(workflow)

# Access results
print(f"Name: {zHat.get_name}")
print(f"Email: {zHat.get_email}")
```

**What you discover:**
- Define workflows in YAML (declarative)
- Load with zLoader (automatic)
- Execute with wizard.handle() (one line)
- Results auto-collected in WizardHat

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl1_basics/3_yaml_workflow.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl1_basics/3_yaml_workflow.py)

---

**🎯 Level 1 Complete!**

You've learned the workflow execution fundamentals:
- ✅ **Execute Loop** - Multi-step workflow execution
- ✅ **WizardHat** - Triple-access result container
- ✅ **YAML Workflows** - Declarative workflow definitions

**These are the essentials. Most applications only need these.**

---

# **zWizard - Level 2** (Template Interpolation)

### **i. zHat Variable Interpolation**

Reference previous step results in subsequent steps using `{{ zHat.key }}` syntax.

```yaml
# interpolation_workflow.yaml
get_name:
  type: zDialog
  prompt: "Enter your name:"
  validate: required

greet_user:
  type: zDisplay
  event: text
  content: "Hello, {{ zHat.get_name }}!"  # Reference previous result
  color: MAIN

get_age:
  type: zDialog
  prompt: "{{ zHat.get_name }}, how old are you?"  # Use in prompt
  validate: integer

summary:
  type: zDisplay
  event: text
  content: "{{ zHat.get_name }} is {{ zHat.get_age }} years old"
  color: SUCCESS
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("interpolation_workflow.yaml")
zHat = z.wizard.handle(workflow)
```

**What you discover:**
- Reference previous results with `{{ zHat.key }}`
- Works in any string field (content, prompt, etc.)
- Automatic interpolation (no manual string formatting)
- Results flow through workflow automatically

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl2_interpolation/1_zhat_variables.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl2_interpolation/1_zhat_variables.py)

---

### **ii. Nested Result Access**

Access nested dictionary and list values from previous results.

```yaml
# nested_access.yaml
fetch_user:
  type: zData
  action: query
  sql: "SELECT name, email, role FROM users WHERE id = 1"

display_info:
  type: zDisplay
  event: text
  content: |
    User: {{ zHat.fetch_user.name }}
    Email: {{ zHat.fetch_user.email }}
    Role: {{ zHat.fetch_user.role }}
  color: MAIN

fetch_files:
  type: zData
  action: query
  sql: "SELECT filename FROM files LIMIT 3"

display_files:
  type: zDisplay
  event: text
  content: |
    File 1: {{ zHat.fetch_files[0].filename }}
    File 2: {{ zHat.fetch_files[1].filename }}
    File 3: {{ zHat.fetch_files[2].filename }}
  color: INFO
```

**What you discover:**
- Access nested dict fields: `{{ zHat.step.field }}`
- Access list indices: `{{ zHat.step[0] }}`
- Combine both: `{{ zHat.step[0].field }}`
- Works with complex data structures

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl2_interpolation/2_nested_access.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl2_interpolation/2_nested_access.py)

---

### **iii. Multiple Variable Interpolation**

Use multiple zHat variables in a single field.

```yaml
# multiple_variables.yaml
get_first_name:
  type: zDialog
  prompt: "Enter first name:"

get_last_name:
  type: zDialog
  prompt: "Enter last name:"

get_city:
  type: zDialog
  prompt: "Enter city:"

get_state:
  type: zDialog
  prompt: "Enter state:"

summary:
  type: zDisplay
  event: text
  content: |
    Full Name: {{ zHat.get_first_name }} {{ zHat.get_last_name }}
    Location: {{ zHat.get_city }}, {{ zHat.get_state }}
  color: SUCCESS
```

**What you discover:**
- Multiple variables in one string
- Works with multiline content (|)
- Automatic whitespace handling
- Clean, readable templates

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl2_interpolation/3_multiple_variables.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl2_interpolation/3_multiple_variables.py)

---

**🎯 Level 2 Complete!**

You've mastered template interpolation:
- ✅ **zHat Variables** - Reference previous results
- ✅ **Nested Access** - Dictionary and list navigation
- ✅ **Multiple Variables** - Combine multiple references

**Template interpolation makes workflows dynamic and maintainable.**

---

# **zWizard - Level 3** (Transactions & RBAC)

### **i. Transaction Management**

Execute multi-step workflows with automatic commit/rollback on success/failure.

```yaml
# transaction_workflow.yaml
_transaction: true  # Enable transaction mode

create_team:
  type: zData
  action: execute
  sql: |
    INSERT INTO teams (name, description)
    VALUES ('Engineering', 'Software development team')
    RETURNING id

add_member_1:
  type: zData
  action: execute
  sql: |
    INSERT INTO team_members (team_id, user_id, role)
    VALUES ({{ zHat.create_team.id }}, 101, 'lead')

add_member_2:
  type: zData
  action: execute
  sql: |
    INSERT INTO team_members (team_id, user_id, role)
    VALUES ({{ zHat.create_team.id }}, 102, 'developer')

# All three operations commit together
# If any fails, all rollback automatically
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("transaction_workflow.yaml")

try:
    zHat = z.wizard.handle(workflow)
    print("Team created successfully!")
except Exception as e:
    print(f"Transaction rolled back: {e}")
```

**What you discover:**
- Enable transactions with `_transaction: true`
- All steps execute in one transaction
- Automatic commit on success
- Automatic rollback on any error
- Multi-step atomicity guaranteed

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl3_advanced/1_transactions.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl3_advanced/1_transactions.py)

---

### **ii. RBAC Integration**

Protect wizard steps with role-based access control.

```yaml
# rbac_workflow.yaml
public_step:
  type: zDisplay
  event: text
  content: "Everyone can see this"

authenticated_step:
  type: zDisplay
  event: text
  content: "Only logged-in users see this"
  zRBAC:
    require_auth: true

admin_step:
  type: zDisplay
  event: text
  content: "Only admins see this"
  zRBAC:
    require_role: admin

permission_step:
  type: zDisplay
  event: text
  content: "Only users with write permission see this"
  zRBAC:
    require_permission: content.write
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

# User context (from authentication)
user_context = {
    "user_id": 42,
    "roles": ["user"],  # Not admin
    "permissions": ["content.read"],  # No write permission
}

workflow = z.loader.load_yaml("rbac_workflow.yaml")

# Steps with failing RBAC checks are skipped automatically
zHat = z.wizard.handle(workflow)
```

**What you discover:**
- Protect steps with `zRBAC` key
- Three access levels: auth, role, permission
- Automatic access denial messages
- Steps skipped if access denied
- Integrates with zAuth subsystem

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl3_advanced/2_rbac.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl3_advanced/2_rbac.py)

---

### **iii. Conditional Execution**

Execute steps conditionally based on previous results.

```yaml
# conditional_workflow.yaml
get_user_type:
  type: zDialog
  prompt: "Are you a new user? (yes/no)"
  validate: required

welcome_new:
  type: zDisplay
  event: text
  content: "Welcome! Let's set up your account."
  color: SUCCESS
  _if: "{{ zHat.get_user_type == 'yes' }}"

welcome_returning:
  type: zDisplay
  event: text
  content: "Welcome back!"
  color: MAIN
  _if: "{{ zHat.get_user_type == 'no' }}"

setup_account:
  type: zDialog
  prompt: "Choose a username:"
  _if: "{{ zHat.get_user_type == 'yes' }}"
```

**What you discover:**
- Conditional execution with `_if` key
- Reference previous results in condition
- Boolean expressions supported
- Steps skipped if condition fails
- Clean workflow branching

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl3_advanced/3_conditionals.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl3_advanced/3_conditionals.py)

---

**🎯 Level 3 Complete!**

You've mastered advanced workflow features:
- ✅ **Transactions** - Atomic multi-step operations
- ✅ **RBAC** - Role-based access control
- ✅ **Conditionals** - Dynamic workflow branching

**These features enable production-grade workflows with data integrity and security.**

---

# **zWizard - Level 4** (Navigation & Data Resolution)

### **i. Navigation Signals**

Control workflow execution with navigation signals (zBack, exit, stop, error).

```yaml
# navigation_workflow.yaml
main_menu:
  type: zDisplay
  event: menu
  items:
    - label: "Continue"
      value: "continue"
    - label: "Go Back"
      value: "zBack"
    - label: "Exit"
      value: "exit"

process_step:
  type: zDisplay
  event: text
  content: "Processing..."
  _if: "{{ zHat.main_menu != 'zBack' and zHat.main_menu != 'exit' }}"

# Navigation callbacks handle signals
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("navigation_workflow.yaml")

# Define navigation callbacks
callbacks = {
    "on_back": lambda: print("User went back"),
    "on_exit": lambda: print("User exited"),
    "on_stop": lambda: print("Workflow stopped"),
    "on_error": lambda: print("Error occurred"),
}

result = z.wizard.execute_loop(workflow, navigation_callbacks=callbacks)
```

**What you discover:**
- Four navigation signals: zBack, exit, stop, error
- Navigation callbacks for custom handling
- Workflow control flow management
- Integration with zWalker menus

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl4_advanced/1_navigation.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl4_advanced/1_navigation.py)

---

### **ii. Block-Level Data Resolution**

Pre-fetch data for entire workflow using `_data` block (Flask pattern).

```yaml
# data_resolution_workflow.yaml
_data:
  users:
    type: zData
    action: query
    sql: "SELECT id, name, email FROM users"
  
  settings:
    type: zData
    action: query
    sql: "SELECT key, value FROM settings"

# Data is now available in all steps
display_users:
  type: zDisplay
  event: text
  content: |
    Total users: {{ len(users) }}
    First user: {{ users[0].name }}

display_settings:
  type: zDisplay
  event: text
  content: |
    Setting 1: {{ settings[0].key }} = {{ settings[0].value }}
```

**What you discover:**
- Pre-fetch data with `_data` block
- Data available to all subsequent steps
- Reduces redundant queries
- Flask-style data resolution pattern
- Clean separation of data and presentation

**🎯 Try it yourself:**

```bash
python3 Demos/Layer_3/zWizard_Demo/lvl4_advanced/2_data_resolution.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl4_advanced/2_data_resolution.py)

---

### **iii. Mode-Aware Execution**

Different execution modes (sequential vs chunked) for different contexts.

```python
from zOS import zOS

# zCLI mode (sequential execution)
z_cli = zOS({"deployment": "Production"})

workflow = {
    "step1": {"type": "zDisplay", "event": "text", "content": "Step 1"},
    "step2": {"type": "zDisplay", "event": "text", "content": "Step 2"},
    "step3": {"type": "zDisplay", "event": "text", "content": "Step 3"},
}

# Sequential execution (all steps run in sequence)
result = z_cli.wizard.execute_loop(workflow)

# Bifrost mode (chunked execution for web)
z_bifrost = zOS({
    "deployment": "Production",
    "zMode": "zBifrost",  # Enable Bifrost mode
})

# Chunked execution (steps sent incrementally to web client)
result = z_bifrost.wizard.execute_loop(
    workflow,
    ws_callback=lambda chunk: send_to_web(chunk)  # Stream to web
)
```

**What you discover:**
- Two execution modes: sequential (zCLI) and chunked (Bifrost)
- Automatic mode detection from zMode
- Sequential mode: all steps execute, return at end
- Chunked mode: stream steps to web client incrementally
- Same workflow, different execution strategies

**🎯 Try it yourself:**

```bash
# Sequential mode
python3 Demos/Layer_3/zWizard_Demo/lvl4_advanced/3_sequential_mode.py

# Chunked mode (requires Bifrost setup)
python3 Demos/Layer_3/zWizard_Demo/lvl4_advanced/3_chunked_mode.py
```

[View demo source →](../Demos/Layer_3/zWizard_Demo/lvl4_advanced/3_mode_aware.py)

---

**🎯 Level 4 Complete!**

You've completed the entire zWizard tutorial journey:
- ✅ **Level 1**: Basic workflows (execute loop, WizardHat, YAML)
- ✅ **Level 2**: Template interpolation (zHat variables, nested access)
- ✅ **Level 3**: Transactions & RBAC (atomicity, security)
- ✅ **Level 4**: Navigation & data resolution (signals, pre-fetching, modes)

**You now understand the complete zWizard subsystem for workflow orchestration!**

---

## Module Structure

zWizard follows a modular architecture with specialized components:

**Core Modules:**
- `zWizard.py` - Main facade class providing unified interface
- `__init__.py` - Package exports and public API

**Core Components:**
- `wizard_hat.py` - WizardHat triple-access container
- `wizard_interpolation.py` - zHat template variable interpolation
- `wizard_transactions.py` - Database transaction management
- `wizard_rbac.py` - Role-based access control enforcement
- `wizard_exceptions.py` - Custom exception hierarchy
- `wizard_examples.py` - Comprehensive usage patterns
- `wizard_constants.py` - Shared constants and configuration

**Domain Managers:**
- `managers/wizard_navigation.py` - Navigation signal handling
- `managers/wizard_dispatch.py` - Dispatch function creation
- `managers/wizard_data.py` - Block-level data resolution
- `managers/wizard_filters.py` - Key filtering and shorthand expansion
- `managers/wizard_conditions.py` - Conditional evaluation

**Execution Strategies:**
- `execution/wizard_execution_base.py` - Base executor class
- `execution/wizard_execution_sequential.py` - zCLI sequential mode
- `execution/wizard_execution_chunked.py` - Bifrost chunked mode

**Architecture Pattern:**
zWizard uses the **Facade + Strategy pattern** - a unified interface delegates to specialized managers and execution strategies:
- `z.wizard.execute_loop()` → `SequentialExecutor.execute()` or `ChunkedExecutor.execute()`
- `z.wizard.handle()` → High-level YAML workflow execution
- Managers handle: navigation, dispatch, data, filters, conditions

This separation allows each component to be tested and evolved independently while maintaining a stable public API.

---

## Layer 3 Design Philosophy

As a **Layer 3 subsystem**, zWizard has special design considerations:

**Orchestration Role:**
- Coordinates multiple Layer 0-2 subsystems (zDisplay, zDialog, zData, etc.)
- Provides workflow execution infrastructure
- Handles result accumulation and interpolation
- Manages navigation and transaction flow

**Automatic Initialization:**
- Validates zOS or zWalker instance (session + logger required)
- Creates all managers automatically
- Initializes execution strategies
- Prints ready message (if zDisplay available)
- Logs ready state to framework logger

**Integration Points:**
- **Depends on:** zConfig, zDisplay, zDialog, zData, zAuth, zLoader
- **Used by:** zWalker (inherits from zWizard), zShell, user applications
- **Provides for:** Workflow orchestration, result accumulation, template interpolation

---

## Advanced Features

### WizardHat - Triple-Access Container

The core result container supporting three access patterns:

```python
# Numeric access (backward compatible)
first_result = zHat[0]
second_result = zHat[1]

# Key-based access (semantic)
user_data = zHat["fetch_user"]
email = zHat["get_email"]

# Attribute access (convenient!)
user_data = zHat.fetch_user
email = zHat.get_email

# Existence checking
if "fetch_user" in zHat:
    print(zHat.fetch_user)

if 0 in zHat:
    print(zHat[0])

# Length checking
num_steps = len(zHat)
```

For detailed documentation, see [wizard_hat_GUIDE.md](zWizard_Guides/wizard_hat_GUIDE.md).

---

### Template Interpolation

Reference previous step results using `{{ zHat.key }}` syntax:

```yaml
get_name:
  type: zDialog
  prompt: "Enter your name:"

greet:
  type: zDisplay
  event: text
  content: "Hello, {{ zHat.get_name }}!"
```

**Supported features:**
- Simple variable access: `{{ zHat.step_key }}`
- Nested dictionary access: `{{ zHat.step.field.subfield }}`
- List index access: `{{ zHat.step[0] }}`
- Multiple variables in one string
- Works in any string field

For detailed documentation, see [wizard_interpolation_GUIDE.md](zWizard_Guides/wizard_interpolation_GUIDE.md).

---

### Transaction Management

Execute multi-step workflows with automatic commit/rollback:

```yaml
_transaction: true

step1:
  type: zData
  action: execute
  sql: "INSERT INTO users (name) VALUES ('Alice')"

step2:
  type: zData
  action: execute
  sql: "INSERT INTO teams (name) VALUES ('Engineering')"

# Both operations commit together
# If either fails, both rollback
```

**Features:**
- Enable with `_transaction: true` at workflow root
- All steps execute in one database transaction
- Automatic commit on success
- Automatic rollback on any error
- Connection reuse via schema cache

For detailed documentation, see [wizard_transactions_GUIDE.md](zWizard_Guides/wizard_transactions_GUIDE.md).

---

### RBAC Integration

Protect steps with role-based access control:

```yaml
admin_only_step:
  type: zDisplay
  event: text
  content: "Admin content"
  zRBAC:
    require_role: admin

permission_step:
  type: zDisplay
  event: text
  content: "Protected content"
  zRBAC:
    require_permission: content.write
```

**Access levels:**
- `require_auth: true` - Any authenticated user
- `require_role: <role>` - Specific role required
- `require_permission: <permission>` - Specific permission required

**Behavior:**
- Steps with failing RBAC checks are skipped automatically
- Access denied messages displayed (optional)
- Integrates with zAuth subsystem

For detailed documentation, see [wizard_rbac_GUIDE.md](zWizard_Guides/wizard_rbac_GUIDE.md).

---

### Navigation Signals

Control workflow execution with navigation signals:

**Supported signals:**
- `zBack` - Return to previous menu/step
- `exit` - Exit application
- `stop` - Stop workflow execution
- `error` - Error occurred

**Usage:**
```python
callbacks = {
    "on_back": lambda: print("Going back"),
    "on_exit": lambda: print("Exiting"),
    "on_stop": lambda: print("Stopping"),
    "on_error": lambda: print("Error"),
}

result = z.wizard.execute_loop(items, navigation_callbacks=callbacks)
```

For detailed documentation, see [navigation_GUIDE.md](zWizard_Guides/navigation_GUIDE.md).

---

### Block-Level Data Resolution

Pre-fetch data for entire workflow using `_data` block:

```yaml
_data:
  users:
    type: zData
    action: query
    sql: "SELECT * FROM users"
  
  settings:
    type: zData
    action: query
    sql: "SELECT * FROM settings"

# Data now available in all steps
step1:
  type: zDisplay
  event: text
  content: "Total users: {{ len(users) }}"
```

**Features:**
- Flask-style data resolution pattern
- Data fetched once, available to all steps
- Reduces redundant queries
- Clean separation of data and presentation

For detailed documentation, see [data_GUIDE.md](zWizard_Guides/data_GUIDE.md).

---

### Conditional Execution

Execute steps conditionally based on previous results:

```yaml
get_user_type:
  type: zDialog
  prompt: "Are you a new user? (yes/no)"

welcome_new:
  type: zDisplay
  event: text
  content: "Welcome! Let's set up your account."
  _if: "{{ zHat.get_user_type == 'yes' }}"

welcome_returning:
  type: zDisplay
  event: text
  content: "Welcome back!"
  _if: "{{ zHat.get_user_type == 'no' }}"
```

**Features:**
- Conditional execution with `_if` key
- Reference previous results in condition
- Boolean expressions supported
- Steps skipped if condition fails

For detailed documentation, see [conditions_GUIDE.md](zWizard_Guides/conditions_GUIDE.md).

---

## Facade API Reference

The `zWizard` class provides these convenience methods:

**Workflow Execution:**
```python
# Execute workflow with items dict (imperative)
result = z.wizard.execute_loop(
    items_dict,
    dispatch_fn=None,
    navigation_callbacks=None,
    context=None,
    start_key=None,
    ws_callback=None,
    block_name=None
)

# Execute YAML workflow (declarative)
zHat = z.wizard.handle(workflow_dict)
```

**WizardHat Access:**
```python
# Numeric access
first = zHat[0]

# Key-based access
user = zHat["fetch_user"]

# Attribute access
user = zHat.fetch_user

# Existence checking
"step_key" in zHat  # True/False
0 in zHat  # True/False

# Length
num_steps = len(zHat)
```

**Template Interpolation:**
```python
# In YAML workflows (automatic)
content: "Hello, {{ zHat.get_name }}!"

# Programmatic interpolation
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import interpolate_zhat

interpolated = interpolate_zhat(value, zHat, logger)
```

**Transaction Management:**
```python
# In YAML workflows
_transaction: true

# Programmatic transaction control
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import (
    check_transaction_start,
    commit_transaction,
    rollback_transaction,
)
```

**RBAC Enforcement:**
```python
# In YAML workflows
zRBAC:
  require_role: admin

# Programmatic RBAC check
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import checkzRBAC_access

granted = checkzRBAC_access(step_value, user_context, logger)
```

**Direct Module Access:**
```python
# Access managers directly (advanced usage)
z.wizard._navigation      # NavigationManager instance
z.wizard._dispatch_mgr    # DispatchManager instance
z.wizard._data_resolver   # DataResolver instance
z.wizard._filter_mgr      # FilterManager instance
z.wizard._conditions      # ConditionManager instance

# Access execution strategies (advanced usage)
z.wizard._sequential_executor  # SequentialExecutor instance
z.wizard._chunked_executor     # ChunkedExecutor instance
```

---

## What's Next?

You've mastered **zWizard** (Layer 3 workflow orchestration). Now continue to other Layer 3 subsystems:

**→ Continue to [zData Guide](zData_GUIDE.md)**

Layer 3 orchestration subsystems:
- **zDialog** - User input and prompts (see [zDialog Guide](zDialog_GUIDE.md))
- **zOpen** - File opening and external applications (see [zOpen Guide](zOpen_GUIDE.md))
- **zWizard** ← You are here (workflow execution)
- **zData** - Database operations and CRUD (see [zData Guide](zData_GUIDE.md))
- **zShell** - Command execution and shell integration (see [zShell Guide](zShell_GUIDE.md))
- **zWalker** - Menu navigation (inherits from zWizard, see [zWalker Guide](zWalker_GUIDE.md))
- **zServer** - HTTP server and routing (see [zServer Guide](zServer_GUIDE.md))

---

**[← Back to zOpen Guide](zOpen_GUIDE.md) | [Home](../README.md) | [Next: zData Guide →](zData_GUIDE.md)**
