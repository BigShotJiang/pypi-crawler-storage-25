# Key Filtering and Shorthand Expansion

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/managers/wizard_filters.py`  
> **Purpose:** Filter meta keys and expand shorthand notation in workflow definitions

---

## Overview

**Key filtering and shorthand expansion** provides workflow authoring convenience by filtering internal meta keys (starting with `_`) and supporting shorthand notation for common patterns.

**Key Features:**
- **Meta key filtering**: Exclude keys starting with `_` from step execution
- **Shorthand expansion**: Expand common patterns (planned feature)
- **Clean workflow definitions**: Internal keys don't clutter step processing
- **Reserved prefixes**: `_` prefix for framework use, `~` prefix for menu anchors

---

## Meta Key Filtering

### Reserved Meta Keys

Keys starting with `_` are reserved for framework configuration and are automatically filtered from step execution.

**Common meta keys:**

| Key | Purpose | Example |
|-----|---------|---------|
| `_transaction` | Enable transaction mode | `_transaction: true` |
| `_data` | Pre-fetch data block | `_data: {users: {...}}` |
| `_if` | Conditional execution | `_if: "{{ condition }}"` |
| `_rbac_display_denials` | Show RBAC denials | `_rbac_display_denials: true` |

### Example: Meta Keys Filtered

```yaml
# workflow.yaml
_transaction: true  # Meta key (not a step)
_data:              # Meta key (not a step)
  users:
    type: zData
    sql: "SELECT * FROM users"

step1:              # Regular step (executes)
  type: zDisplay
  content: "Hello"

step2:              # Regular step (executes)
  type: zData
  sql: "..."

# Only step1 and step2 execute
# _transaction and _data are configuration, not steps
```

---

## Basic Usage

### Workflow with Meta Keys

```yaml
# advanced_workflow.yaml
# Configuration meta keys (filtered from execution)
_transaction: true
_rbac_display_denials: false

# Data pre-fetching (filtered from execution)
_data:
  users:
    type: zData
    sql: "SELECT * FROM users"

# Regular steps (execute in order)
welcome:
  type: zDisplay
  event: text
  content: "Welcome"

show_users:
  type: zDisplay
  event: table
  data: "{{ users }}"  # Uses pre-fetched data
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("advanced_workflow.yaml")

# Meta keys processed for configuration
# Only 'welcome' and 'show_users' steps execute
zHat = z.wizard.handle(workflow)
```

---

## Reserved Key Patterns

### Underscore Prefix (`_`)

Reserved for framework configuration and meta information.

**Usage:**
- Workflow-level settings: `_transaction`, `_rbac_display_denials`
- Data blocks: `_data`
- Step-level directives: `_if`, `_loop`, `_retry`

**Example:**
```yaml
_transaction: true          # Framework setting
_custom_setting: "value"    # Custom meta key

step1:
  type: zDisplay
  _if: "{{ condition }}"    # Step directive
  content: "Hello"
```

### Tilde Prefix (`~`)

Reserved for navigation anchors.

**Usage:**
- Menu anchors: `~*menu_name`
- Bookmark points: `~checkpoint1`

**Example:**
```yaml
~*main_menu:  # Navigation anchor
  type: zDisplay
  event: menu
  items: [...]

sub_menu:
  type: zDisplay
  event: menu
  items:
    - label: "Back"
      value: "zBack"  # Returns to ~*main_menu
```

---

## Advanced Usage

### Nested Meta Keys

Meta keys work at any level of nesting.

```yaml
workflow:
  _transaction: true  # Root-level meta
  
  step1:
    type: zData
    _cache: true      # Step-level meta (custom)
    sql: "SELECT * FROM users"
  
  step2:
    type: zDisplay
    _if: "{{ condition }}"  # Step-level directive
    content: "Hello"
```

### Custom Meta Keys

Create your own meta keys for custom workflows.

```yaml
# Custom meta keys for documentation
_workflow_name: "User Registration"
_workflow_version: "2.0"
_workflow_author: "Team Alpha"

# Custom step meta
step1:
  type: zDisplay
  _description: "Welcome message"
  _category: "onboarding"
  content: "Welcome!"
```

```python
# Access custom meta keys
workflow = z.loader.load_yaml("workflow.yaml")

# Extract meta information
workflow_name = workflow.get("_workflow_name")
workflow_version = workflow.get("_workflow_version")

# Filter meta keys before execution
regular_steps = {k: v for k, v in workflow.items() if not k.startswith("_")}
```

---

## Shorthand Expansion (Planned)

Future feature to expand common patterns.

**Proposed shorthands:**

```yaml
# Future shorthand (not yet implemented)
quick_display: "Hello, world!"
# Expands to:
# quick_display:
#   type: zDisplay
#   event: text
#   content: "Hello, world!"

quick_query: "SELECT * FROM users"
# Expands to:
# quick_query:
#   type: zData
#   action: query
#   sql: "SELECT * FROM users"
```

---

## API Reference

### FilterManager

```python
class FilterManager:
    """Filters meta keys and expands shorthand notation."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
```

---

### filter_meta_keys()

```python
filter_meta_keys(items_dict: Dict[str, Any]) -> Dict[str, Any]
```

Filter keys starting with `_` from items dictionary.

**Parameters:**
- `items_dict` (dict): Workflow items dictionary

**Returns:** Filtered dictionary with only regular step keys

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.managers import FilterManager

items = {
    "_transaction": True,
    "_data": {...},
    "step1": {...},
    "step2": {...},
}

filtered = z.wizard._filter_mgr.filter_meta_keys(items)
# Returns: {"step1": {...}, "step2": {...}}
```

---

### expand_shorthand()

```python
expand_shorthand(value: Any) -> Any
```

Expand shorthand notation (planned feature).

**Parameters:**
- `value` (Any): Step value (may be shorthand)

**Returns:** Expanded step value

**Status:** Planned for future release

---

## Best Practices

### 1. Use `_` Prefix for Meta Keys

```yaml
# Good: clear meta key prefix
_transaction: true
_workflow_version: "1.0"

# Bad: ambiguous naming
transaction: true  # Is this a step or config?
workflow_version: "1.0"
```

### 2. Document Custom Meta Keys

```yaml
# Document custom meta keys at top of workflow
# Custom meta keys:
# - _workflow_name: Workflow identifier
# - _workflow_owner: Team responsible for maintenance
# - _cache_ttl: Cache duration in seconds

_workflow_name: "User Onboarding"
_workflow_owner: "Platform Team"
_cache_ttl: 3600
```

### 3. Group Meta Keys Together

```yaml
# Good: all meta keys at top
_transaction: true
_rbac_display_denials: false
_data: {...}

step1: {...}
step2: {...}

# Bad: mixed meta and steps
_transaction: true
step1: {...}
_rbac_display_denials: false
step2: {...}
```

### 4. Avoid Accidental Meta Keys

```yaml
# Good: no underscore prefix for regular steps
display_message: {...}
fetch_data: {...}

# Bad: underscore in step name (filtered!)
_display_message: {...}  # This won't execute!
```

---

## Common Patterns

### Pattern 1: Workflow Configuration Block

```yaml
# All workflow-level configuration
_workflow:
  name: "User Registration"
  version: "2.0"
  transaction: true
  rbac_display_denials: false

# Data pre-fetching
_data:
  roles: {...}
  settings: {...}

# Steps
step1: {...}
step2: {...}
```

### Pattern 2: Step-Level Directives

```yaml
protected_step:
  type: zData
  sql: "DELETE FROM users WHERE id = 123"
  _if: "{{ zHat.confirm == 'yes' }}"
  _rbac: {require_role: admin}
  _retry: 3
  _timeout: 30
```

### Pattern 3: Documentation Meta Keys

```yaml
# Workflow documentation
_description: "Complete user registration flow"
_prerequisites: ["database", "email_service"]
_outputs: ["user_id", "confirmation_email_sent"]

# Steps with documentation
create_user:
  _step_description: "Create new user record"
  _step_owner: "Backend Team"
  type: zData
  sql: "..."
```

---

## Integration with Other Features

### With Conditional Execution

`_if` is a meta key that controls step execution.

```yaml
step1:
  type: zDisplay
  content: "Hello"
  _if: "{{ condition }}"  # Meta key (not part of step data)
```

### With RBAC

`_rbac` could be used for step-level access control.

```yaml
admin_action:
  type: zData
  sql: "..."
  _rbac:  # Meta key for RBAC config
    require_role: admin
```

### With Transactions

`_transaction` is a workflow-level meta key.

```yaml
_transaction: true  # Meta key enables transactions

step1: {...}
step2: {...}
```

---

## Performance Considerations

**Filtering overhead:** Minimal - single pass through dictionary keys.

**Memory usage:** Filtered dictionary is separate object, but workflow dictionaries are typically small.

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **Conditionals**: [conditions_GUIDE.md](conditions_GUIDE.md) - `_if` directive
- **Data**: [data_GUIDE.md](data_GUIDE.md) - `_data` block
- **Transactions**: [wizard_transactions_GUIDE.md](wizard_transactions_GUIDE.md) - `_transaction` key

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
