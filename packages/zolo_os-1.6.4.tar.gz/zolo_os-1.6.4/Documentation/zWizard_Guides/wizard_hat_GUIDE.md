# WizardHat - Triple-Access Results Container

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_hat.py`  
> **Purpose:** Triple-access container for wizard step results (numeric, key, attribute access)

---

## Overview

**WizardHat** is the core result container for zWizard workflows. It provides three distinct ways to access step results, making workflows flexible and maintainable.

**Key Features:**
- **Numeric indexing**: `zHat[0]`, `zHat[1]`, ... (backward compatible)
- **Key-based access**: `zHat["step1"]`, `zHat["fetch_user"]`, ... (semantic)
- **Attribute access**: `zHat.step1`, `zHat.fetch_user`, ... (convenient!)
- **Length checking**: `len(zHat)`
- **Containment checks**: `"step1" in zHat` or `0 in zHat`
- **Debug representation**: `WizardHat(steps=2, keys=['step1', 'step2'])`

---

## Architecture

WizardHat uses a dual-storage architecture:

```python
class WizardHat:
    def __init__(self):
        self._list: list = []   # For numeric access (backward compat)
        self._dict: dict = {}   # For key-based access (semantic)
```

**Design rationale:** Maintains backward compatibility with numeric indexing while enabling semantic key-based and convenient attribute access.

---

## Basic Usage

### Creating and Adding Results

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import WizardHat

# Create container
zHat = WizardHat()

# Add results (automatically supports triple-access)
zHat.add("fetch_data", {"files": ["file1.txt", "file2.txt"]})
zHat.add("process", {"status": "done", "count": 42})
```

### Access Pattern 1: Numeric Indexing

Backward-compatible with legacy code that uses numeric indices.

```python
# Access by position (0-indexed)
first_result = zHat[0]
# Returns: {"files": ["file1.txt", "file2.txt"]}

second_result = zHat[1]
# Returns: {"status": "done", "count": 42}

# Negative indexing works too
last_result = zHat[-1]
# Returns: {"status": "done", "count": 42}
```

### Access Pattern 2: Key-Based Access

Semantic, readable access using step names.

```python
# Access by step name
data = zHat["fetch_data"]
# Returns: {"files": ["file1.txt", "file2.txt"]}

process_result = zHat["process"]
# Returns: {"status": "done", "count": 42}

# More readable than numeric indices!
```

### Access Pattern 3: Attribute Access

Most convenient - clean dot notation like JavaScript objects.

```python
# Access by attribute (cleanest!)
data = zHat.fetch_data
# Returns: {"files": ["file1.txt", "file2.txt"]}

status = zHat.process
# Returns: {"status": "done", "count": 42}

# Chaining works with nested dicts
count = zHat.process["count"]  # 42
```

---

## Advanced Usage

### Existence Checking

Check if a step or index exists before accessing.

```python
# Check by key name
if "fetch_data" in zHat:
    print(zHat.fetch_data)

# Check by numeric index
if 0 in zHat:
    print(zHat[0])

if 10 in zHat:  # False if only 2 steps
    print("This won't execute")
```

### Length Checking

Get the number of steps completed.

```python
num_steps = len(zHat)
print(f"Completed {num_steps} steps")

# Useful for conditional logic
if len(zHat) > 5:
    print("Long workflow!")
```

### Iteration

Iterate over all results.

```python
# Iterate over values
for result in zHat:
    print(result)

# With enumerate for indices
for idx, result in enumerate(zHat):
    print(f"Step {idx}: {result}")
```

### Debug Representation

Clean debug output shows structure at a glance.

```python
print(zHat)
# Output: WizardHat(steps=2, keys=['fetch_data', 'process'])

print(repr(zHat))
# Output: WizardHat(steps=2, keys=['fetch_data', 'process'])
```

---

## Workflow Examples

### Example 1: User Registration Workflow

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow_items = {
    "get_username": {
        "type": "zDialog",
        "prompt": "Enter username:",
        "validate": "required"
    },
    "get_email": {
        "type": "zDialog",
        "prompt": "Enter email:",
        "validate": "email"
    },
    "get_password": {
        "type": "zDialog",
        "prompt": "Enter password:",
        "validate": "required",
        "secret": True
    },
}

# Execute workflow
zHat = z.wizard.execute_loop(workflow_items)

# Triple-access to results
username = zHat.get_username      # Attribute access
email = zHat["get_email"]         # Key access
password = zHat[2]                # Numeric access

print(f"User: {username}, Email: {email}")
```

### Example 2: Database Query Workflow

```python
workflow = {
    "fetch_users": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM users LIMIT 10"
    },
    "fetch_teams": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM teams"
    },
}

zHat = z.wizard.execute_loop(workflow)

# Access results (all three ways work)
users = zHat.fetch_users          # Attribute
teams = zHat["fetch_teams"]       # Key
first = zHat[0]                   # Numeric

print(f"Found {len(users)} users")
print(f"Found {len(teams)} teams")
```

### Example 3: Multi-Step Data Pipeline

```python
workflow = {
    "extract": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM raw_data"
    },
    "transform": {
        "type": "zFunc",
        "action": "process_data",
        "input": "{{ zHat.extract }}"
    },
    "load": {
        "type": "zData",
        "action": "insert",
        "table": "processed_data",
        "data": "{{ zHat.transform }}"
    },
}

zHat = z.wizard.handle(workflow)

# Verify pipeline results
if "extract" in zHat and "transform" in zHat and "load" in zHat:
    print("Pipeline completed successfully!")
    print(f"Extracted: {len(zHat.extract)} records")
    print(f"Transformed: {len(zHat.transform)} records")
    print(f"Loaded: {zHat.load['inserted']} records")
```

---

## API Reference

### Constructor

```python
WizardHat()
```

Creates empty container ready for result accumulation.

**Parameters:** None

**Returns:** WizardHat instance

---

### add()

```python
add(key: str, value: Any) -> None
```

Add a step result with both numeric and key-based access.

**Parameters:**
- `key` (str): Step name (e.g., "step1", "fetch_user")
- `value` (Any): Step result (any Python object)

**Returns:** None

**Example:**
```python
zHat.add("fetch_data", {"files": [...]})
```

---

### \_\_getitem\_\_()

```python
__getitem__(key: Union[int, str]) -> Any
```

Support both `zHat[0]` and `zHat["step1"]`.

**Parameters:**
- `key` (int or str): Numeric index or string key

**Returns:** Step result

**Raises:**
- `KeyError`: If key not found
- `IndexError`: If index out of range
- `TypeError`: If key is neither int nor str

**Examples:**
```python
result = zHat[0]              # Numeric
result = zHat["step_name"]    # Key
```

---

### \_\_getattr\_\_()

```python
__getattr__(key: str) -> Any
```

Support attribute-style access: `zHat.step1`.

**Parameters:**
- `key` (str): Step name as attribute

**Returns:** Step result

**Raises:**
- `AttributeError`: If key not found

**Example:**
```python
result = zHat.step_name
```

---

### \_\_contains\_\_()

```python
__contains__(key: Union[int, str]) -> bool
```

Check if key or index exists: `"step" in zHat` or `0 in zHat`.

**Parameters:**
- `key` (int or str): Numeric index or string key

**Returns:** True if exists, False otherwise

**Examples:**
```python
if "step1" in zHat:
    print(zHat.step1)

if 0 in zHat:
    print(zHat[0])
```

---

### \_\_len\_\_()

```python
__len__() -> int
```

Get number of steps: `len(zHat)`.

**Parameters:** None

**Returns:** Number of steps completed

**Example:**
```python
num_steps = len(zHat)
```

---

### \_\_iter\_\_()

```python
__iter__() -> Iterator
```

Iterate over results: `for result in zHat`.

**Parameters:** None

**Returns:** Iterator over step results

**Example:**
```python
for result in zHat:
    print(result)
```

---

### \_\_repr\_\_()

```python
__repr__() -> str
```

Debug representation showing step count and keys.

**Parameters:** None

**Returns:** Debug string

**Example:**
```python
print(zHat)
# Output: WizardHat(steps=2, keys=['step1', 'step2'])
```

---

## Error Handling

### KeyError (Key-Based Access)

```python
try:
    result = zHat["nonexistent"]
except KeyError:
    print("Step key not found")
```

### IndexError (Numeric Access)

```python
try:
    result = zHat[999]
except IndexError:
    print("Index out of range")
```

### AttributeError (Attribute Access)

```python
try:
    result = zHat.nonexistent
except AttributeError:
    print("Attribute not found")
```

### TypeError (Invalid Key Type)

```python
try:
    result = zHat[{"invalid": "key"}]
except TypeError:
    print("Key must be int or str")
```

---

## Best Practices

### 1. Choose the Right Access Pattern

```python
# Use numeric indexing for backward compatibility
legacy_result = zHat[0]

# Use key-based access for semantic clarity
user_data = zHat["fetch_user"]

# Use attribute access for convenience
email = zHat.get_email  # Cleanest!
```

### 2. Check Existence Before Access

```python
# Avoid KeyError/IndexError
if "fetch_user" in zHat:
    user = zHat.fetch_user
else:
    print("User fetch step not executed")
```

### 3. Use Meaningful Step Names

```python
# Good: semantic, readable
workflow = {
    "fetch_user_profile": {...},
    "update_preferences": {...},
    "send_confirmation_email": {...},
}

# Bad: generic, unclear
workflow = {
    "step1": {...},
    "step2": {...},
    "step3": {...},
}
```

### 4. Leverage in Conditional Logic

```python
# Check if critical steps completed
if "fetch_data" in zHat and "validate_data" in zHat:
    if len(zHat.fetch_data) > 0:
        process_data(zHat.validate_data)
```

### 5. Combine with Template Interpolation

```python
# In YAML workflows
workflow = """
fetch_user:
  type: zData
  action: query
  sql: "SELECT * FROM users WHERE id = 1"

greet_user:
  type: zDisplay
  event: text
  content: "Hello, {{ zHat.fetch_user.name }}!"
"""
```

---

## Integration with Other Subsystems

### With zDisplay

```python
# Display results from previous steps
workflow = {
    "fetch_stats": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT COUNT(*) as count FROM users"
    },
    "show_stats": {
        "type": "zDisplay",
        "event": "text",
        "content": "Total users: {{ zHat.fetch_stats.count }}"
    },
}
```

### With zData

```python
# Chain database operations
workflow = {
    "create_user": {
        "type": "zData",
        "action": "execute",
        "sql": "INSERT INTO users (name) VALUES ('Alice') RETURNING id"
    },
    "create_profile": {
        "type": "zData",
        "action": "execute",
        "sql": "INSERT INTO profiles (user_id) VALUES ({{ zHat.create_user.id }})"
    },
}
```

### With zDialog

```python
# Use user input in subsequent steps
workflow = {
    "get_query": {
        "type": "zDialog",
        "prompt": "Enter search term:"
    },
    "search_database": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM items WHERE name LIKE '%{{ zHat.get_query }}%'"
    },
}
```

---

## Performance Considerations

**Memory usage:** WizardHat stores results twice (list + dict). For very large workflows (1000+ steps), consider:
- Streaming results instead of accumulating
- Clearing intermediate results after use
- Using generators for large data

**Access speed:**
- Numeric access: O(1) - direct list indexing
- Key-based access: O(1) - dict lookup
- Attribute access: O(1) - dict lookup via `__getattr__`

---

## Constants Reference

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.wizard_constants import (
    _ERR_KEY_NOT_FOUND,
    _ERR_INVALID_KEY_TYPE,
)
```

| Constant | Value | Description |
|----------|-------|-------------|
| `_ERR_KEY_NOT_FOUND` | "Key '{key}' not found in WizardHat" | KeyError message template |
| `_ERR_INVALID_KEY_TYPE` | "Key must be int or str, got {type}" | TypeError message template |

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **Interpolation**: [wizard_interpolation_GUIDE.md](wizard_interpolation_GUIDE.md) - zHat variable interpolation
- **Examples**: [wizard_examples.py](../../core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_examples.py) - Usage patterns

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
