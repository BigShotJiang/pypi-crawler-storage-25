# Dispatch Management for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/managers/wizard_dispatch.py`  
> **Purpose:** Create and route dispatch functions for step execution

---

## Overview

**Dispatch management** handles step execution routing, creating appropriate dispatch functions based on context (zOS vs zWalker) and managing step-level execution.

**Key Features:**
- **Context-aware dispatch**: Automatic selection of zos or walker dispatch
- **Custom dispatch functions**: Support for user-defined dispatch logic
- **Default fallback**: Automatic dispatch creation when none provided
- **Error handling**: Graceful error reporting for dispatch failures
- **Step context injection**: Pass context to all dispatch calls

---

## Basic Usage

### Automatic Dispatch

zWizard automatically creates appropriate dispatch function based on context.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow_items = {
    "step1": {"type": "zDisplay", "event": "text", "content": "Hello"},
    "step2": {"type": "zData", "action": "query", "sql": "SELECT * FROM users"},
    "step3": {"type": "zDialog", "prompt": "Enter name:"},
}

# Automatic dispatch - no dispatch_fn needed
result = z.wizard.execute_loop(workflow_items)
```

### Custom Dispatch Function

Provide custom dispatch logic for specialized workflows.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

def custom_dispatch(key, value, context=None):
    """Custom dispatch with logging and validation."""
    z.logger.info(f"Executing step: {key}")
    
    # Validation
    if "type" not in value:
        raise ValueError(f"Step '{key}' missing 'type' field")
    
    # Custom handling for specific types
    if value["type"] == "custom_action":
        return execute_custom_action(value)
    
    # Fallback to default dispatch
    return z.shell.executor.execute_wizard_step(key, value, context)

workflow_items = {
    "step1": {"type": "custom_action", "action": "special"},
    "step2": {"type": "zDisplay", "event": "text", "content": "Done"},
}

# Use custom dispatch
result = z.wizard.execute_loop(workflow_items, dispatch_fn=custom_dispatch)
```

---

## Advanced Usage

### Dispatch with Context

Pass context to all dispatch calls.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

# Create context with shared data
context = {
    "user_id": 42,
    "session_id": "abc123",
    "permissions": ["read", "write"],
}

workflow_items = {
    "fetch_user": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM users WHERE id = {{ context.user_id }}"
    },
    "display_info": {
        "type": "zDisplay",
        "event": "text",
        "content": "Session: {{ context.session_id }}"
    },
}

# Pass context to all steps
result = z.wizard.execute_loop(workflow_items, context=context)
```

### Walker Mode Dispatch

In Walker mode, dispatch routes to walker's dispatch system.

```python
from zOS.L3_Abstraction.l_zWalker import zWalker

walker = zWalker(zos=z)

menu_items = {
    "option1": {"label": "Option 1", "action": "action1"},
    "option2": {"label": "Option 2", "action": "action2"},
    "exit": {"label": "Exit", "action": "zBack"},
}

# Walker dispatch handles menu navigation
result = walker.execute_loop(menu_items)
```

---

## Dispatch Function Signature

### Standard Dispatch Function

```python
def dispatch_function(
    key: str,
    value: Dict[str, Any],
    context: Optional[Dict[str, Any]] = None
) -> Any:
    """
    Execute a single workflow step.
    
    Args:
        key: Step identifier
        value: Step configuration
        context: Optional context data
    
    Returns:
        Step execution result
    """
    # Step execution logic here
    pass
```

### Example Implementations

**Logging Dispatch:**
```python
def logging_dispatch(key, value, context=None):
    """Dispatch with detailed logging."""
    logger.info(f"[Step: {key}] Type: {value.get('type')}")
    
    result = default_dispatch(key, value, context)
    
    logger.info(f"[Step: {key}] Result: {result}")
    return result
```

**Timed Dispatch:**
```python
import time

def timed_dispatch(key, value, context=None):
    """Dispatch with execution timing."""
    start = time.time()
    
    result = default_dispatch(key, value, context)
    
    elapsed = time.time() - start
    print(f"Step '{key}' completed in {elapsed:.2f}s")
    
    return result
```

**Error Recovery Dispatch:**
```python
def error_recovery_dispatch(key, value, context=None):
    """Dispatch with automatic retry on failure."""
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            return default_dispatch(key, value, context)
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            logger.warning(f"Step '{key}' failed (attempt {attempt+1}), retrying...")
            time.sleep(1)
```

---

## API Reference

### DispatchManager

```python
class DispatchManager:
    """Creates and manages dispatch functions for step execution."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
```

---

### get_default_dispatch()

```python
get_default_dispatch() -> Any
```

Get default dispatch function based on context (zOS or zWalker).

**Parameters:** None

**Returns:** Default dispatch function

**Example:**
```python
dispatch_fn = z.wizard._dispatch_mgr.get_default_dispatch()

# Returns appropriate dispatch based on context:
# - z.shell.executor.execute_wizard_step (zOS mode)
# - walker.dispatch.handle (Walker mode)
```

---

### create_dispatch_function()

```python
create_dispatch_function(
    custom_fn: Optional[Any] = None
) -> Any
```

Create dispatch function (use custom or default).

**Parameters:**
- `custom_fn` (Optional[callable]): Custom dispatch function

**Returns:** Dispatch function to use

**Example:**
```python
def my_dispatch(key, value, context=None):
    return custom_logic(key, value)

dispatch_fn = z.wizard._dispatch_mgr.create_dispatch_function(my_dispatch)
```

---

## Best Practices

### 1. Keep Dispatch Functions Simple

```python
# Good: focused dispatch logic
def simple_dispatch(key, value, context=None):
    return z.shell.executor.execute_wizard_step(key, value, context)

# Bad: complex logic in dispatch
def complex_dispatch(key, value, context=None):
    # Lots of validation
    # Lots of transformation
    # Lots of logging
    # Hard to maintain
    pass
```

### 2. Use Default Dispatch When Possible

```python
# Good: use default dispatch
result = z.wizard.execute_loop(workflow_items)

# Only create custom dispatch when needed
def custom_dispatch(key, value, context=None):
    if value["type"] == "special":
        return handle_special(value)
    return z.shell.executor.execute_wizard_step(key, value, context)

result = z.wizard.execute_loop(workflow_items, dispatch_fn=custom_dispatch)
```

### 3. Handle Errors Gracefully

```python
def safe_dispatch(key, value, context=None):
    try:
        return default_dispatch(key, value, context)
    except Exception as e:
        logger.error(f"Step '{key}' failed: {e}")
        # Return error indicator, don't crash workflow
        return {"error": str(e)}
```

### 4. Document Custom Dispatch

```python
def custom_dispatch(key, value, context=None):
    """
    Custom dispatch with retry logic and timing.
    
    Features:
    - Automatic retry (3 attempts)
    - Execution timing
    - Detailed logging
    
    Args:
        key: Step identifier
        value: Step configuration
        context: Execution context
    
    Returns:
        Step result or error dict
    """
    # Implementation...
```

---

## Integration with Other Features

### With Navigation Signals

Dispatch functions should handle navigation signals.

```python
def navigation_aware_dispatch(key, value, context=None):
    result = default_dispatch(key, value, context)
    
    # Check for navigation signals
    if result in ["zBack", "exit", "stop"]:
        logger.info(f"Navigation signal: {result}")
    
    return result
```

### With RBAC

Dispatch can enforce RBAC before step execution.

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import checkzRBAC_access

def rbac_dispatch(key, value, context=None):
    # Check RBAC before dispatch
    if not checkzRBAC_access(value, context.get("user"), logger, display):
        return None  # Skip step
    
    return default_dispatch(key, value, context)
```

### With Context Injection

Dispatch can enhance context with additional data.

```python
def context_enhanced_dispatch(key, value, context=None):
    # Enhance context with timestamp
    enhanced_context = {
        **(context or {}),
        "step_key": key,
        "timestamp": datetime.now(),
    }
    
    return default_dispatch(key, value, enhanced_context)
```

---

## Performance Considerations

**Dispatch overhead:** Minimal - dispatch is simple function call per step.

**Custom dispatch complexity:** Keep dispatch logic simple. Heavy computation should be in step implementations, not dispatch layer.

**Error handling:** Graceful error handling in dispatch prevents workflow interruption but adds slight overhead.

---

## Common Patterns

### Pattern 1: Logging Wrapper

```python
def logging_dispatch(key, value, context=None):
    logger.debug(f"[{key}] Start")
    result = default_dispatch(key, value, context)
    logger.debug(f"[{key}] Complete")
    return result
```

### Pattern 2: Validation Wrapper

```python
def validating_dispatch(key, value, context=None):
    # Pre-execution validation
    required_fields = ["type"]
    for field in required_fields:
        if field not in value:
            raise ValueError(f"Step '{key}' missing required field: {field}")
    
    return default_dispatch(key, value, context)
```

### Pattern 3: Transformation Wrapper

```python
def transforming_dispatch(key, value, context=None):
    # Transform step value before execution
    if "shorthand" in value:
        value = expand_shorthand(value)
    
    return default_dispatch(key, value, context)
```

### Pattern 4: Caching Wrapper

```python
cache = {}

def caching_dispatch(key, value, context=None):
    # Cache results for idempotent steps
    cache_key = (key, str(value))
    
    if cache_key in cache:
        logger.debug(f"[{key}] Cache hit")
        return cache[cache_key]
    
    result = default_dispatch(key, value, context)
    cache[cache_key] = result
    
    return result
```

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **Execution**: [execution_GUIDE.md](execution_GUIDE.md) - Execution strategies
- **Navigation**: [navigation_GUIDE.md](navigation_GUIDE.md) - Navigation signal handling

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
