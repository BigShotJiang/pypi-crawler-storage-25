# Role-Based Access Control (RBAC) for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_rbac.py`  
> **Purpose:** Enforce role-based access control on wizard steps before execution

---

## Overview

**RBAC integration** enables fine-grained access control for wizard steps based on user roles, permissions, and authentication status. Steps with failing RBAC checks are automatically skipped with optional access denial messages.

**Key Features:**
- **Authentication check**: Require logged-in users
- **Role-based access**: Require specific roles (admin, editor, etc.)
- **Permission-based access**: Require specific permissions (content.write, etc.)
- **Automatic denial**: Steps skipped if access denied
- **Optional messages**: Display access denial messages
- **Integration with zAuth**: Seamless authentication/authorization integration

---

## Access Levels

### 1. Authentication Only

Require any authenticated user (logged in).

```yaml
authenticated_step:
  type: zDisplay
  event: text
  content: "Only logged-in users see this"
  zRBAC:
    require_auth: true
```

### 2. Role-Based Access

Require specific role (admin, editor, user, etc.).

```yaml
admin_step:
  type: zDisplay
  event: text
  content: "Only admins see this"
  zRBAC:
    require_role: admin
```

### 3. Permission-Based Access

Require specific permission (content.write, user.delete, etc.).

```yaml
write_step:
  type: zDisplay
  event: text
  content: "Only users with write permission see this"
  zRBAC:
    require_permission: content.write
```

---

## Basic Usage

### Protect Single Step

```yaml
# workflow.yaml
public_step:
  type: zDisplay
  event: text
  content: "Everyone can see this"

protected_step:
  type: zDisplay
  event: text
  content: "Only authenticated users see this"
  zRBAC:
    require_auth: true
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

# User context from authentication
user_context = {
    "user_id": 42,
    "authenticated": True,
    "roles": ["user"],
    "permissions": ["content.read"],
}

workflow = z.loader.load_yaml("workflow.yaml")

# Protected step only executes if user is authenticated
zHat = z.wizard.handle(workflow)
```

### Protect Multiple Steps

```yaml
# admin_workflow.yaml
public_info:
  type: zDisplay
  event: text
  content: "Public information"

admin_panel:
  type: zDisplay
  event: text
  content: "Admin Panel"
  zRBAC:
    require_role: admin

delete_users:
  type: zData
  action: execute
  sql: "DELETE FROM users WHERE inactive = true"
  zRBAC:
    require_role: admin
    require_permission: user.delete

audit_log:
  type: zData
  action: query
  sql: "SELECT * FROM audit_logs"
  zRBAC:
    require_role: admin
```

---

## Advanced Usage

### Multiple Role Requirements

Require one of multiple roles (OR logic).

```yaml
editor_or_admin:
  type: zDisplay
  event: text
  content: "Editors or Admins can see this"
  zRBAC:
    require_role: [editor, admin]  # User needs editor OR admin
```

### Multiple Permission Requirements

Require all permissions (AND logic).

```yaml
advanced_action:
  type: zData
  action: execute
  sql: "..."
  zRBAC:
    require_permission: [content.write, content.publish]  # User needs both
```

### Combined Requirements

Combine authentication, role, and permission checks.

```yaml
publish_content:
  type: zFunc
  action: publish
  zRBAC:
    require_auth: true              # Must be logged in
    require_role: [editor, admin]   # Must be editor OR admin
    require_permission: content.publish  # Must have publish permission
```

### Role Hierarchy

Check for admin role which inherits all permissions.

```yaml
sensitive_action:
  type: zData
  action: execute
  sql: "TRUNCATE TABLE logs"
  zRBAC:
    require_role: admin  # Only admins
```

---

## Access Denial Behavior

### Automatic Step Skipping

Steps with failing RBAC checks are automatically skipped (not executed).

```yaml
_rbac_display_denials: false  # Don't show access denial messages

step1:
  type: zDisplay
  event: text
  content: "Public"

step2:
  type: zDisplay
  event: text
  content: "Admins only"
  zRBAC:
    require_role: admin

step3:
  type: zDisplay
  event: text
  content: "Public"

# If user is not admin:
# - step1 executes
# - step2 skipped (no error, no message)
# - step3 executes
```

### Access Denial Messages

Display custom messages when access is denied.

```yaml
_rbac_display_denials: true  # Show access denial messages

admin_action:
  type: zData
  action: execute
  sql: "..."
  zRBAC:
    require_role: admin
    denial_message: "Admin access required to perform this action"
```

### Guest User Handling

Special handling for guest (unauthenticated) users.

```yaml
login_required:
  type: zDisplay
  event: text
  content: "Members-only content"
  zRBAC:
    require_auth: true
    denial_message: "Please log in to access this content"
```

---

## API Reference

### checkzRBAC_access()

```python
checkzRBAC_access(
    step_value: Dict[str, Any],
    user_context: Optional[Dict[str, Any]],
    logger: Any,
    display: Optional[Any] = None
) -> bool
```

Check if user has required access for a step.

**Parameters:**
- `step_value` (dict): Step configuration (may contain `zRBAC` key)
- `user_context` (dict): User info (user_id, roles, permissions, authenticated)
- `logger` (Logger): Logger instance
- `display` (Optional[Display]): Display instance for denial messages

**Returns:** True if access granted, False if denied

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import checkzRBAC_access

step_value = {
    "type": "zDisplay",
    "content": "Admin content",
    "zRBAC": {"require_role": "admin"}
}

user_context = {
    "user_id": 42,
    "authenticated": True,
    "roles": ["user"],  # Not admin
    "permissions": []
}

granted = checkzRBAC_access(step_value, user_context, z.logger, z.display)
# Returns: False (user is not admin)
```

---

### display_access_denied()

```python
display_access_denied(
    step_key: str,
    rbac_config: Dict[str, Any],
    user_context: Optional[Dict[str, Any]],
    display: Any,
    logger: Any
) -> None
```

Display access denial message for a step.

**Parameters:**
- `step_key` (str): Step name
- `rbac_config` (dict): RBAC configuration from step
- `user_context` (dict): User info
- `display` (Display): Display instance
- `logger` (Logger): Logger instance

**Returns:** None

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import display_access_denied

rbac_config = {
    "require_role": "admin",
    "denial_message": "Admin access required"
}

display_access_denied(
    step_key="admin_panel",
    rbac_config=rbac_config,
    user_context=user_context,
    display=z.display,
    logger=z.logger
)
```

---

## Best Practices

### 1. Least Privilege Principle

Grant minimum permissions needed for each action.

```yaml
# Good: specific permission
view_content:
  type: zData
  sql: "SELECT * FROM articles"
  zRBAC:
    require_permission: content.read

# Bad: overly broad
view_content:
  type: zData
  sql: "SELECT * FROM articles"
  zRBAC:
    require_role: admin  # Too much privilege for simple view
```

### 2. Combine Checks Appropriately

Use role OR permission checks for flexibility.

```yaml
# Good: flexible
edit_content:
  type: zData
  sql: "UPDATE articles SET ..."
  zRBAC:
    require_role: [admin, editor]  # Either role works
    require_permission: content.write
```

### 3. Provide Clear Denial Messages

```yaml
# Good: clear message
premium_content:
  type: zDisplay
  content: "Premium content"
  zRBAC:
    require_auth: true
    denial_message: "Please upgrade to premium to access this content"

# Bad: vague message
premium_content:
  type: zDisplay
  content: "Premium content"
  zRBAC:
    require_auth: true
    denial_message: "Access denied"  # Why? What to do?
```

### 4. Document Permission Requirements

```yaml
# Document complex permission requirements
publish_article:
  # Requires: content.write AND content.publish permissions
  # Role: editor or admin
  type: zFunc
  action: publish_to_production
  zRBAC:
    require_role: [editor, admin]
    require_permission: [content.write, content.publish]
```

---

## Integration with Other Features

### With Conditional Execution

```yaml
get_action:
  type: zDialog
  prompt: "Choose action:"
  options: [view, edit, delete]

delete_action:
  type: zData
  sql: "DELETE FROM items WHERE id = 123"
  _if: "{{ zHat.get_action == 'delete' }}"
  zRBAC:
    require_role: admin
    require_permission: content.delete
```

### With Transactions

```yaml
_transaction: true

create_team:
  type: zData
  sql: "INSERT INTO teams (...)"
  zRBAC:
    require_role: admin

add_members:
  type: zData
  sql: "INSERT INTO team_members (...)"
  zRBAC:
    require_role: admin

# Transaction only starts if user has admin role
# If RBAC fails, transaction never begins
```

### With Template Interpolation

```yaml
get_user_id:
  type: zDialog
  prompt: "Enter user ID to delete:"

delete_user:
  type: zData
  sql: "DELETE FROM users WHERE id = {{ zHat.get_user_id }}"
  zRBAC:
    require_role: admin
    require_permission: user.delete
    denial_message: "Only admins can delete users"
```

---

## User Context Structure

The `user_context` dict should contain:

```python
user_context = {
    "user_id": 42,                      # Unique user ID
    "authenticated": True,              # Is user logged in?
    "roles": ["user", "editor"],        # List of role names
    "permissions": [                    # List of permission names
        "content.read",
        "content.write",
        "content.publish"
    ],
}
```

### Guest User Context

For unauthenticated (guest) users:

```python
guest_context = {
    "user_id": None,
    "authenticated": False,
    "roles": [],
    "permissions": [],
}
```

### Admin User Context

Example admin with all permissions:

```python
admin_context = {
    "user_id": 1,
    "authenticated": True,
    "roles": ["admin"],
    "permissions": [
        "content.read",
        "content.write",
        "content.publish",
        "content.delete",
        "user.create",
        "user.delete",
        "system.configure"
    ],
}
```

---

## Constants Reference

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.wizard_constants import (
    RBAC_ACCESS_GRANTED,
    RBAC_ACCESS_DENIED,
    RBAC_ACCESS_DENIED_ZGUEST,
)
```

| Constant | Value | Description |
|----------|-------|-------------|
| `RBAC_ACCESS_GRANTED` | `"[RBAC] Access granted"` | Log message for granted access |
| `RBAC_ACCESS_DENIED` | `"[RBAC] Access denied"` | Log message for denied access |
| `RBAC_ACCESS_DENIED_ZGUEST` | `"[RBAC] Access denied for zGuest"` | Special message for guest users |

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **zAuth Guide**: [zAuth_GUIDE.md](../zAuth_GUIDE.md) - Authentication/authorization subsystem
- **Conditionals**: [conditions_GUIDE.md](conditions_GUIDE.md) - Conditional execution

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
