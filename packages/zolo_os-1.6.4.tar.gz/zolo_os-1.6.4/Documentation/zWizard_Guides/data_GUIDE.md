# Block-Level Data Resolution for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/managers/wizard_data.py`  
> **Purpose:** Pre-fetch data for entire workflow using `_data` block (Flask pattern)

---

## Overview

**Block-level data resolution** enables pre-fetching data before workflow execution, making it available to all subsequent steps. This Flask-inspired pattern reduces redundant queries and improves workflow clarity.

**Key Features:**
- **`_data` block**: Pre-fetch data at workflow start
- **Automatic resolution**: Data loaded before any steps execute
- **Context injection**: Data available in step context
- **Multiple queries**: Fetch multiple datasets in parallel
- **Clean separation**: Data fetching separated from presentation
- **Reduced redundancy**: Fetch once, use many times

---

## Basic Usage

### Single Data Source

Pre-fetch one dataset for use in all steps.

```yaml
# workflow.yaml
_data:
  users:
    type: zData
    action: query
    sql: "SELECT id, name, email FROM users"

# Data now available in all steps
display_users:
  type: zDisplay
  event: text
  content: |
    Total users: {{ len(users) }}
    First user: {{ users[0].name }}

show_user_list:
  type: zDisplay
  event: table
  data: "{{ users }}"
```

### Multiple Data Sources

Pre-fetch multiple datasets.

```yaml
# multi_data_workflow.yaml
_data:
  users:
    type: zData
    action: query
    sql: "SELECT * FROM users"
  
  teams:
    type: zData
    action: query
    sql: "SELECT * FROM teams"
  
  settings:
    type: zData
    action: query
    sql: "SELECT key, value FROM settings"

# All three datasets available in all steps
summary:
  type: zDisplay
  event: text
  content: |
    Users: {{ len(users) }}
    Teams: {{ len(teams) }}
    Settings: {{ len(settings) }}
```

---

## Advanced Usage

### Data with Parameters

Use zSpark or environment variables for dynamic queries.

```yaml
# parameterized_data.yaml
_data:
  active_users:
    type: zData
    action: query
    sql: "SELECT * FROM users WHERE created_at > '{{ cutoff_date }}'"

# cutoff_date injected from zSpark or context
```

```python
from zOS import zOS

z = zOS({
    "deployment": "Production",
    "cutoff_date": "2024-01-01",
})

workflow = z.loader.load_yaml("parameterized_data.yaml")
zHat = z.wizard.handle(workflow)
```

### Nested Data Access

Access nested fields from pre-fetched data.

```yaml
_data:
  user_profile:
    type: zData
    action: query
    sql: "SELECT * FROM users WHERE id = 1"

display_profile:
  type: zDisplay
  event: text
  content: |
    Name: {{ user_profile.name }}
    Email: {{ user_profile.email }}
    Role: {{ user_profile.role }}
    Created: {{ user_profile.created_at }}
```

### Conditional Data Usage

Use pre-fetched data in conditional steps.

```yaml
_data:
  user_permissions:
    type: zData
    action: query
    sql: "SELECT permission FROM permissions WHERE user_id = 1"

admin_panel:
  type: zDisplay
  event: text
  content: "Admin Panel"
  _if: "{{ 'admin' in user_permissions }}"

editor_panel:
  type: zDisplay
  event: text
  content: "Editor Panel"
  _if: "{{ 'editor' in user_permissions }}"
```

---

## Data Block Patterns

### Pattern 1: Dashboard Data

Pre-fetch all dashboard data in one block.

```yaml
_data:
  stats:
    type: zData
    action: query
    sql: |
      SELECT 
        COUNT(*) as total_users,
        COUNT(CASE WHEN active = true THEN 1 END) as active_users,
        COUNT(CASE WHEN created_at > NOW() - INTERVAL '30 days' THEN 1 END) as new_users
      FROM users
  
  recent_activity:
    type: zData
    action: query
    sql: "SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 10"

dashboard:
  type: zDisplay
  event: dashboard
  data:
    stats: "{{ stats }}"
    activity: "{{ recent_activity }}"
```

### Pattern 2: Form Population

Pre-fetch data to populate form defaults.

```yaml
_data:
  user_settings:
    type: zData
    action: query
    sql: "SELECT * FROM user_settings WHERE user_id = 1"

edit_settings:
  type: zDialog
  fields:
    theme:
      prompt: "Theme"
      default: "{{ user_settings.theme }}"
    language:
      prompt: "Language"
      default: "{{ user_settings.language }}"
    notifications:
      prompt: "Enable notifications"
      default: "{{ user_settings.notifications }}"
```

### Pattern 3: Validation Data

Pre-fetch validation rules or reference data.

```yaml
_data:
  valid_roles:
    type: zData
    action: query
    sql: "SELECT name FROM roles"
  
  valid_categories:
    type: zData
    action: query
    sql: "SELECT id, name FROM categories"

get_role:
  type: zDialog
  prompt: "Enter role:"
  validate: "{{ zHat.get_role in valid_roles }}"

get_category:
  type: zDialog
  prompt: "Select category:"
  options: "{{ valid_categories }}"
```

---

## API Reference

### DataResolver

```python
class DataResolver:
    """Resolves block-level data queries (Flask pattern)."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
```

---

### has_data_block()

```python
has_data_block(workflow_dict: Dict[str, Any]) -> bool
```

Check if workflow has `_data` block.

**Parameters:**
- `workflow_dict` (dict): Workflow configuration

**Returns:** True if `_data` block exists, False otherwise

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.managers import DataResolver

workflow = {
    "_data": {
        "users": {"type": "zData", "sql": "..."}
    },
    "step1": {...}
}

has_data = z.wizard._data_resolver.has_data_block(workflow)
# Returns: True
```

---

### resolve_block_data()

```python
resolve_block_data(
    workflow_dict: Dict[str, Any],
    context: Dict[str, Any]
) -> Dict[str, Any]
```

Execute `_data` queries and inject results into context.

**Parameters:**
- `workflow_dict` (dict): Workflow configuration with `_data` block
- `context` (dict): Execution context

**Returns:** Updated context with data results

**Example:**
```python
workflow = {
    "_data": {
        "users": {
            "type": "zData",
            "action": "query",
            "sql": "SELECT * FROM users"
        }
    }
}

context = {}
updated_context = z.wizard._data_resolver.resolve_block_data(workflow, context)

# updated_context now contains:
# {"users": [{"id": 1, "name": "Alice"}, ...]}
```

---

## Best Practices

### 1. Fetch Only What's Needed

```yaml
# Good: specific fields
_data:
  user_names:
    type: zData
    sql: "SELECT id, name FROM users"

# Bad: fetch everything
_data:
  users:
    type: zData
    sql: "SELECT * FROM users"  # Might include sensitive fields
```

### 2. Use Descriptive Key Names

```yaml
# Good: clear, descriptive names
_data:
  active_users:
    type: zData
    sql: "SELECT * FROM users WHERE active = true"
  
  pending_orders:
    type: zData
    sql: "SELECT * FROM orders WHERE status = 'pending'"

# Bad: generic names
_data:
  data1:
    type: zData
    sql: "SELECT * FROM users WHERE active = true"
  
  data2:
    type: zData
    sql: "SELECT * FROM orders WHERE status = 'pending'"
```

### 3. Limit Result Sets

```yaml
# Good: limit results to reasonable size
_data:
  recent_activity:
    type: zData
    sql: "SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 50"

# Bad: fetch everything (performance issue)
_data:
  all_activity:
    type: zData
    sql: "SELECT * FROM activity_log"  # Could be millions of rows
```

### 4. Document Data Dependencies

```yaml
# Document which steps use which data
# Used by: display_stats, show_chart, export_report
_data:
  user_stats:
    type: zData
    sql: "SELECT COUNT(*), AVG(age) FROM users"

display_stats:
  type: zDisplay
  content: "{{ user_stats }}"
```

---

## Integration with Other Features

### With Conditional Execution

Use pre-fetched data in conditions.

```yaml
_data:
  user_role:
    type: zData
    action: query
    sql: "SELECT role FROM users WHERE id = 1"

admin_section:
  type: zDisplay
  content: "Admin content"
  _if: "{{ user_role.role == 'admin' }}"
```

### With RBAC

Pre-fetch user permissions for RBAC checks.

```yaml
_data:
  user_permissions:
    type: zData
    action: query
    sql: "SELECT permission FROM permissions WHERE user_id = 1"

protected_action:
  type: zData
  sql: "DELETE FROM items WHERE id = 123"
  zRBAC:
    require_permission: "{{ 'delete' in user_permissions }}"
```

### With Template Interpolation

Reference pre-fetched data in all steps.

```yaml
_data:
  site_config:
    type: zData
    action: query
    sql: "SELECT * FROM site_config"

welcome:
  type: zDisplay
  content: "Welcome to {{ site_config.site_name }}!"

footer:
  type: zDisplay
  content: "© {{ site_config.copyright_year }} {{ site_config.company_name }}"
```

---

## Performance Considerations

**Parallel execution:** Multiple queries in `_data` block execute in parallel when possible.

**Caching:** Data is fetched once at workflow start, not per step.

**Memory usage:** Pre-fetched data stays in memory for entire workflow. For large datasets:
- Limit result sets (LIMIT clause)
- Fetch only needed fields (SELECT specific columns)
- Consider pagination for very large datasets

**Query optimization:** Use database indices on frequently queried fields.

---

## Flask Pattern Comparison

This pattern mirrors Flask's `@app.before_request` decorator:

**Flask:**
```python
@app.before_request
def load_data():
    g.users = User.query.all()
    g.settings = Setting.query.all()

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', 
                         users=g.users, 
                         settings=g.settings)
```

**zWizard:**
```yaml
_data:
  users:
    type: zData
    sql: "SELECT * FROM users"
  settings:
    type: zData
    sql: "SELECT * FROM settings"

dashboard:
  type: zDisplay
  template: dashboard
  data:
    users: "{{ users }}"
    settings: "{{ settings }}"
```

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **zData Guide**: [zData_GUIDE.md](../zData_GUIDE.md) - Database operations
- **Interpolation**: [wizard_interpolation_GUIDE.md](wizard_interpolation_GUIDE.md) - Using pre-fetched data

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
