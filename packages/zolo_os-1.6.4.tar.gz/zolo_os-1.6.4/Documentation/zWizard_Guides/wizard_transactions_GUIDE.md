# Transaction Management for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_transactions.py`  
> **Purpose:** Database transaction management with automatic commit/rollback for multi-step workflows

---

## Overview

**Transaction management** enables atomic multi-step workflows where all database operations either succeed together or rollback together. Perfect for maintaining data integrity across complex workflows.

**Key Features:**
- **Automatic transaction detection**: Enable with `_transaction: true`
- **Connection reuse**: Single connection across all steps (via schema cache)
- **Automatic commit**: All steps succeed → commit
- **Automatic rollback**: Any step fails → rollback all
- **zData integration**: Works seamlessly with zData subsystem
- **Safe error handling**: Always closes connections, even on errors

---

## Basic Usage

### Enable Transaction Mode

Add `_transaction: true` at the workflow root to enable transaction management.

```yaml
# transaction_workflow.yaml
_transaction: true  # Enable transaction mode

create_user:
  type: zData
  action: execute
  sql: "INSERT INTO users (name) VALUES ('Alice') RETURNING id"

create_profile:
  type: zData
  action: execute
  sql: "INSERT INTO profiles (user_id) VALUES ({{ zHat.create_user.id }})"

# Both operations commit together
# If either fails, both rollback
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("transaction_workflow.yaml")

try:
    zHat = z.wizard.handle(workflow)
    print("Transaction committed successfully!")
except Exception as e:
    print(f"Transaction rolled back: {e}")
```

### Without Transaction Mode

Default behavior (no `_transaction` key) - each step auto-commits independently.

```yaml
# no_transaction.yaml
# No _transaction key = each step auto-commits

create_user:
  type: zData
  action: execute
  sql: "INSERT INTO users (name) VALUES ('Alice') RETURNING id"

create_profile:
  type: zData
  action: execute
  sql: "INSERT INTO profiles (user_id) VALUES (123)"

# If create_profile fails, create_user is already committed!
```

---

## Transaction Lifecycle

### 1. Transaction Start

Transaction starts with the first `zData` step that uses an alias.

```yaml
_transaction: true

step1:
  type: zDisplay  # No transaction started yet (not zData)
  event: text
  content: "Starting workflow..."

step2:
  type: zData  # Transaction starts HERE
  action: execute
  alias: default  # Connection alias
  sql: "INSERT INTO users (name) VALUES ('Alice')"
```

### 2. Connection Reuse

All subsequent `zData` steps with the same alias reuse the connection.

```yaml
_transaction: true

insert_user:
  type: zData
  alias: default  # Connection opened
  sql: "INSERT INTO users (name) VALUES ('Alice') RETURNING id"

insert_team:
  type: zData
  alias: default  # Reuses same connection
  sql: "INSERT INTO teams (name) VALUES ('Engineering')"

insert_membership:
  type: zData
  alias: default  # Still reusing connection
  sql: "INSERT INTO memberships (user_id, team_id) VALUES ({{ zHat.insert_user.id }}, {{ zHat.insert_team.id }})"
```

### 3. Automatic Commit

If all steps succeed, transaction commits automatically at workflow end.

```yaml
_transaction: true

step1:
  type: zData
  alias: default
  sql: "INSERT INTO users (name) VALUES ('Alice')"

step2:
  type: zData
  alias: default
  sql: "INSERT INTO teams (name) VALUES ('Engineering')"

# All steps succeeded → COMMIT
```

### 4. Automatic Rollback

If any step fails, transaction rolls back automatically.

```yaml
_transaction: true

step1:
  type: zData
  alias: default
  sql: "INSERT INTO users (name) VALUES ('Alice')"

step2:
  type: zData
  alias: default
  sql: "INSERT INTO teams (name) VALUES ('Engineering')"

step3:
  type: zData
  alias: default
  sql: "INVALID SQL SYNTAX"  # FAILS HERE

# Step3 failed → ROLLBACK (step1 and step2 undone)
```

---

## Advanced Usage

### Multi-Step Data Pipeline

Create complex data workflows with guaranteed atomicity.

```yaml
_transaction: true

# Step 1: Create user
create_user:
  type: zData
  action: execute
  alias: default
  sql: |
    INSERT INTO users (name, email)
    VALUES ('Alice', 'alice@example.com')
    RETURNING id

# Step 2: Create user profile
create_profile:
  type: zData
  action: execute
  alias: default
  sql: |
    INSERT INTO profiles (user_id, bio)
    VALUES ({{ zHat.create_user.id }}, 'Software Engineer')

# Step 3: Create user preferences
create_preferences:
  type: zData
  action: execute
  alias: default
  sql: |
    INSERT INTO preferences (user_id, theme, language)
    VALUES ({{ zHat.create_user.id }}, 'dark', 'en')

# All three succeed together or rollback together
```

### Multiple Database Connections

Use different aliases for independent transactions.

```yaml
_transaction: true

# Transaction 1: users database
insert_user:
  type: zData
  alias: users_db  # First transaction
  sql: "INSERT INTO users (name) VALUES ('Alice')"

# Transaction 2: logs database
insert_log:
  type: zData
  alias: logs_db  # Second transaction (independent)
  sql: "INSERT INTO logs (message) VALUES ('User created')"

# Each alias has its own transaction
# users_db commit/rollback is independent of logs_db
```

### Conditional Transactions

Transaction behavior respects conditional execution.

```yaml
_transaction: true

get_action:
  type: zDialog
  prompt: "Create user? (yes/no)"

create_user:
  type: zData
  alias: default
  sql: "INSERT INTO users (name) VALUES ('Alice')"
  _if: "{{ zHat.get_action == 'yes' }}"

# Transaction only starts if condition is true
# If condition is false, no transaction needed
```

---

## API Reference

### check_transaction_start()

```python
check_transaction_start(
    use_transaction: bool,
    transaction_alias: Optional[str],
    step_value: Dict[str, Any],
    schema_cache: Any,
    logger: Any
) -> Optional[str]
```

Detect first `zData` step and mark transaction alias for tracking.

**Parameters:**
- `use_transaction` (bool): True if `_transaction: true` in workflow
- `transaction_alias` (Optional[str]): Current transaction alias (None if not started)
- `step_value` (dict): Current step configuration
- `schema_cache` (SchemaCache): Schema cache for connection management
- `logger` (Logger): Logger instance

**Returns:** Transaction alias if started, None otherwise

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import check_transaction_start

transaction_alias = check_transaction_start(
    use_transaction=True,
    transaction_alias=None,
    step_value={"type": "zData", "alias": "default"},
    schema_cache=z.loader.cache.schema_cache,
    logger=z.logger
)
# Returns: "default"
```

---

### commit_transaction()

```python
commit_transaction(
    use_transaction: bool,
    transaction_alias: Optional[str],
    schema_cache: Any,
    logger: Any
) -> None
```

Commit active transaction if all steps succeeded.

**Parameters:**
- `use_transaction` (bool): True if `_transaction: true` in workflow
- `transaction_alias` (Optional[str]): Transaction alias to commit
- `schema_cache` (SchemaCache): Schema cache for connection management
- `logger` (Logger): Logger instance

**Returns:** None

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import commit_transaction

# After all steps succeed
commit_transaction(
    use_transaction=True,
    transaction_alias="default",
    schema_cache=z.loader.cache.schema_cache,
    logger=z.logger
)
```

---

### rollback_transaction()

```python
rollback_transaction(
    use_transaction: bool,
    transaction_alias: Optional[str],
    schema_cache: Any,
    logger: Any,
    error: Exception
) -> None
```

Rollback active transaction if any step failed.

**Parameters:**
- `use_transaction` (bool): True if `_transaction: true` in workflow
- `transaction_alias` (Optional[str]): Transaction alias to rollback
- `schema_cache` (SchemaCache): Schema cache for connection management
- `logger` (Logger): Logger instance
- `error` (Exception): Exception that triggered rollback

**Returns:** None

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import rollback_transaction

try:
    # Execute workflow steps
    pass
except Exception as e:
    rollback_transaction(
        use_transaction=True,
        transaction_alias="default",
        schema_cache=z.loader.cache.schema_cache,
        logger=z.logger,
        error=e
    )
    raise
```

---

## Error Handling

### Automatic Rollback on Error

Any exception during workflow execution triggers automatic rollback.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = {
    "_transaction": True,
    "step1": {
        "type": "zData",
        "alias": "default",
        "sql": "INSERT INTO users (name) VALUES ('Alice')"
    },
    "step2": {
        "type": "zData",
        "alias": "default",
        "sql": "INVALID SQL"  # Will fail
    },
}

try:
    zHat = z.wizard.handle(workflow)
except Exception as e:
    # Automatic rollback happened here
    print(f"Transaction rolled back: {e}")
```

### Manual Rollback

Raise exception to trigger rollback from custom code.

```python
workflow = {
    "_transaction": True,
    "fetch_data": {
        "type": "zData",
        "alias": "default",
        "sql": "SELECT * FROM users"
    },
    "validate": {
        "type": "zFunc",
        "action": "validate_data",
        "data": "{{ zHat.fetch_data }}"
    },
}

# In validate_data function:
def validate_data(data):
    if len(data) == 0:
        raise ValueError("No data to validate")  # Triggers rollback
    return {"valid": True}
```

---

## Best Practices

### 1. Use Transactions for Multi-Step Operations

```yaml
# Good: transaction for related operations
_transaction: true

create_order:
  type: zData
  sql: "INSERT INTO orders (...) VALUES (...) RETURNING id"

create_line_items:
  type: zData
  sql: "INSERT INTO line_items (...) VALUES (...)"

update_inventory:
  type: zData
  sql: "UPDATE inventory SET quantity = quantity - 1"
```

### 2. Keep Transactions Short

```yaml
# Good: focused transaction
_transaction: true

insert_user:
  type: zData
  sql: "INSERT INTO users (...)"

insert_profile:
  type: zData
  sql: "INSERT INTO profiles (...)"

# Bad: long-running transaction with non-DB steps
_transaction: true

insert_user:
  type: zData
  sql: "INSERT INTO users (...)"

send_email:  # Slow external API call
  type: zFunc
  action: send_welcome_email

query_stats:  # Long-running query
  type: zData
  sql: "SELECT COUNT(*) FROM huge_table"
```

### 3. Use Same Alias for Related Operations

```yaml
_transaction: true

# All use same alias = one transaction
step1:
  type: zData
  alias: default  # Same alias
  sql: "INSERT INTO table1 (...)"

step2:
  type: zData
  alias: default  # Same alias
  sql: "INSERT INTO table2 (...)"

step3:
  type: zData
  alias: default  # Same alias
  sql: "UPDATE table1 SET (...)"
```

### 4. Document Transaction Boundaries

```yaml
# Transaction scope: user creation + profile setup
_transaction: true

# Start transaction
create_user:
  type: zData
  alias: default
  sql: "INSERT INTO users (...) RETURNING id"

# Continue transaction
create_profile:
  type: zData
  alias: default
  sql: "INSERT INTO profiles (user_id) VALUES ({{ zHat.create_user.id }})"

# End transaction (commit if all succeed)
```

---

## Integration with Other Features

### With Template Interpolation

```yaml
_transaction: true

create_user:
  type: zData
  alias: default
  sql: "INSERT INTO users (name) VALUES ('{{ zHat.get_name }}') RETURNING id"

create_profile:
  type: zData
  alias: default
  sql: "INSERT INTO profiles (user_id) VALUES ({{ zHat.create_user.id }})"
```

### With RBAC

```yaml
_transaction: true

create_team:
  type: zData
  alias: default
  sql: "INSERT INTO teams (name) VALUES ('Engineering')"
  zRBAC:
    require_role: admin  # Only admins can create teams

add_member:
  type: zData
  alias: default
  sql: "INSERT INTO team_members (...)"
```

### With Conditional Execution

```yaml
_transaction: true

get_action:
  type: zDialog
  prompt: "Confirm deletion? (yes/no)"

delete_user:
  type: zData
  alias: default
  sql: "DELETE FROM users WHERE id = 123"
  _if: "{{ zHat.get_action == 'yes' }}"
```

---

## Performance Considerations

**Connection reuse:** Transaction mode reuses database connections across steps, reducing overhead.

**Lock contention:** Long transactions can hold locks. Keep transactions focused and short.

**Deadlock avoidance:** Access tables in consistent order across workflows to prevent deadlocks.

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **zData Guide**: [zData_GUIDE.md](../zData_GUIDE.md) - Database operations
- **Interpolation**: [wizard_interpolation_GUIDE.md](wizard_interpolation_GUIDE.md) - zHat variables

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
