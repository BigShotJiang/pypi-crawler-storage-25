# Conditional Execution for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/managers/wizard_conditions.py`  
> **Purpose:** Evaluate conditional expressions to control step execution based on previous results

---

## Overview

**Conditional execution** enables dynamic workflow branching by allowing steps to execute only when specified conditions are met. Use the `_if` key to reference previous step results.

**Key Features:**
- **Boolean conditions**: `_if: "{{ zHat.step == 'value' }}"`
- **Result-based branching**: Execute steps based on previous results
- **Automatic evaluation**: Conditions evaluated before step execution
- **Silent skipping**: Steps with failed conditions are skipped (no error)
- **Integration with interpolation**: Reference zHat variables in conditions

---

## Basic Usage

### Simple Equality Check

Execute step only if previous result matches value.

```yaml
# conditional_workflow.yaml
get_user_type:
  type: zDialog
  prompt: "Are you a new user? (yes/no)"

welcome_new:
  type: zDisplay
  event: text
  content: "Welcome! Let's set up your account."
  _if: "{{ zHat.get_user_type == 'yes' }}"

welcome_returning:
  type: zDisplay
  event: text
  content: "Welcome back!"
  _if: "{{ zHat.get_user_type == 'no' }}"
```

### Existence Check

Execute step only if previous step completed successfully.

```yaml
fetch_data:
  type: zData
  action: query
  sql: "SELECT * FROM users"

process_data:
  type: zFunc
  action: process
  input: "{{ zHat.fetch_data }}"
  _if: "{{ 'fetch_data' in zHat }}"
```

### Numeric Comparisons

Execute step based on numeric threshold.

```yaml
get_age:
  type: zDialog
  prompt: "Enter your age:"
  validate: integer

adult_content:
  type: zDisplay
  event: text
  content: "You have access to adult content."
  _if: "{{ zHat.get_age >= 18 }}"

minor_content:
  type: zDisplay
  event: text
  content: "Age-appropriate content for you."
  _if: "{{ zHat.get_age < 18 }}"
```

---

## Advanced Usage

### Complex Boolean Expressions

Combine multiple conditions with AND/OR logic.

```yaml
get_role:
  type: zDialog
  prompt: "Enter role (admin/user):"

get_subscription:
  type: zDialog
  prompt: "Enter subscription (free/premium):"

premium_admin_feature:
  type: zDisplay
  event: text
  content: "Premium admin feature"
  _if: "{{ zHat.get_role == 'admin' and zHat.get_subscription == 'premium' }}"

any_premium_feature:
  type: zDisplay
  event: text
  content: "Premium feature"
  _if: "{{ zHat.get_subscription == 'premium' or zHat.get_role == 'admin' }}"
```

### Nested Field Checks

Check nested dictionary fields.

```yaml
fetch_user:
  type: zData
  action: query
  sql: "SELECT * FROM users WHERE id = 1"

admin_panel:
  type: zDisplay
  event: text
  content: "Admin Panel"
  _if: "{{ zHat.fetch_user.role == 'admin' }}"

verified_badge:
  type: zDisplay
  event: text
  content: "✓ Verified"
  _if: "{{ zHat.fetch_user.is_verified == true }}"
```

### List/Array Checks

Check list length or element existence.

```yaml
fetch_items:
  type: zData
  action: query
  sql: "SELECT * FROM items"

show_items:
  type: zDisplay
  event: text
  content: "Items found: {{ len(zHat.fetch_items) }}"
  _if: "{{ len(zHat.fetch_items) > 0 }}"

no_items:
  type: zDisplay
  event: text
  content: "No items found."
  _if: "{{ len(zHat.fetch_items) == 0 }}"
```

### NOT Logic

Negate conditions.

```yaml
get_consent:
  type: zDialog
  prompt: "Do you agree? (yes/no)"

rejected:
  type: zDisplay
  event: text
  content: "You must agree to continue."
  _if: "{{ zHat.get_consent != 'yes' }}"
```

---

## Condition Syntax

### Boolean Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `==` | Equality | `{{ zHat.value == 'yes' }}` |
| `!=` | Inequality | `{{ zHat.value != 'no' }}` |
| `>` | Greater than | `{{ zHat.age > 18 }}` |
| `>=` | Greater or equal | `{{ zHat.age >= 18 }}` |
| `<` | Less than | `{{ zHat.count < 10 }}` |
| `<=` | Less or equal | `{{ zHat.count <= 10 }}` |
| `and` | Logical AND | `{{ zHat.a == 1 and zHat.b == 2 }}` |
| `or` | Logical OR | `{{ zHat.a == 1 or zHat.b == 2 }}` |
| `not` | Logical NOT | `{{ not (zHat.value == 'no') }}` |

### Functions

| Function | Description | Example |
|----------|-------------|---------|
| `len()` | Get length | `{{ len(zHat.items) > 0 }}` |
| `in` | Membership | `{{ 'key' in zHat }}` |

---

## Best Practices

### 1. Use Meaningful Conditions

```yaml
# Good: clear, readable condition
welcome_admin:
  type: zDisplay
  content: "Admin Dashboard"
  _if: "{{ zHat.user_role == 'admin' }}"

# Bad: unclear condition
welcome_admin:
  type: zDisplay
  content: "Admin Dashboard"
  _if: "{{ zHat.x == 1 }}"  # What is x?
```

### 2. Check Existence Before Access

```yaml
# Good: check existence first
display_user:
  type: zDisplay
  content: "User: {{ zHat.fetch_user.name }}"
  _if: "{{ 'fetch_user' in zHat and zHat.fetch_user }}"

# Bad: might fail if fetch_user doesn't exist
display_user:
  type: zDisplay
  content: "User: {{ zHat.fetch_user.name }}"
  _if: "{{ zHat.fetch_user.name != '' }}"
```

### 3. Provide Alternative Branches

```yaml
# Good: handle both cases
success_message:
  type: zDisplay
  content: "Operation succeeded!"
  _if: "{{ zHat.operation_result == 'success' }}"

failure_message:
  type: zDisplay
  content: "Operation failed."
  _if: "{{ zHat.operation_result != 'success' }}"

# Bad: only handle one case
success_message:
  type: zDisplay
  content: "Operation succeeded!"
  _if: "{{ zHat.operation_result == 'success' }}"
# What happens if operation failed?
```

### 4. Document Complex Conditions

```yaml
# Document complex logic
premium_feature:
  # Show if: (admin OR premium subscriber) AND feature_enabled
  type: zDisplay
  content: "Premium Feature"
  _if: "{{ (zHat.role == 'admin' or zHat.subscription == 'premium') and zHat.feature_enabled }}"
```

---

## API Reference

### ConditionManager

```python
class ConditionManager:
    """Evaluates conditional expressions for step execution."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
```

---

### should_execute_step()

```python
should_execute_step(
    step_value: Any,
    zHat: WizardHat
) -> Tuple[bool, Any]
```

Check if step should execute based on `_if` condition.

**Parameters:**
- `step_value` (Any): Step configuration (may contain `_if` key)
- `zHat` (WizardHat): Container with previous step results

**Returns:** Tuple of (should_execute: bool, cleaned_value: Any)

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.managers import ConditionManager

step_value = {
    "type": "zDisplay",
    "content": "Admin content",
    "_if": "{{ zHat.role == 'admin' }}"
}

should_execute, cleaned = z.wizard._conditions.should_execute_step(
    step_value, zHat
)

if should_execute:
    # Execute step
    pass
else:
    # Skip step
    pass
```

---

## Integration with Other Features

### With RBAC

Combine conditions with access control.

```yaml
get_action:
  type: zDialog
  prompt: "Choose action (view/delete):"

delete_action:
  type: zData
  sql: "DELETE FROM items WHERE id = 123"
  _if: "{{ zHat.get_action == 'delete' }}"
  zRBAC:
    require_role: admin
    require_permission: content.delete

# Both condition AND RBAC must pass for step to execute
```

### With Transactions

Conditional steps within transactions.

```yaml
_transaction: true

create_user:
  type: zData
  alias: default
  sql: "INSERT INTO users (...) RETURNING id"

create_profile:
  type: zData
  alias: default
  sql: "INSERT INTO profiles (user_id) VALUES ({{ zHat.create_user.id }})"
  _if: "{{ zHat.create_user.id is not None }}"

# Transaction only proceeds if user creation succeeded
```

### With Template Interpolation

Reference conditional results in interpolation.

```yaml
get_tier:
  type: zDialog
  prompt: "Enter tier (free/premium):"

premium_welcome:
  type: zDisplay
  content: "Welcome, {{ zHat.get_name }}! You have premium access."
  _if: "{{ zHat.get_tier == 'premium' }}"

free_welcome:
  type: zDisplay
  content: "Welcome, {{ zHat.get_name }}! Upgrade for more features."
  _if: "{{ zHat.get_tier == 'free' }}"
```

---

## Error Handling

### Safe Evaluation

Conditions are evaluated safely. If evaluation fails, step is skipped.

```yaml
# If zHat.fetch_user doesn't exist, condition fails safely
admin_panel:
  type: zDisplay
  content: "Admin Panel"
  _if: "{{ zHat.fetch_user.role == 'admin' }}"

# Step is skipped if condition evaluation fails
# No exception raised, workflow continues
```

### Fallback Behavior

Failed conditions default to False (skip step).

```yaml
risky_step:
  type: zDisplay
  content: "This might fail"
  _if: "{{ zHat.nonexistent.field }}"

# Step skipped if condition can't be evaluated
# Workflow continues with next step
```

---

## Performance Considerations

**Condition evaluation overhead:** Minimal - conditions evaluated once per step before execution.

**Complex conditions:** Keep conditions simple for readability. If very complex logic needed, consider:
- Breaking into multiple steps with simpler conditions
- Using custom function in zFunc step
- Pre-computing boolean flags in earlier steps

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **Interpolation**: [wizard_interpolation_GUIDE.md](wizard_interpolation_GUIDE.md) - zHat variable access
- **RBAC**: [wizard_rbac_GUIDE.md](wizard_rbac_GUIDE.md) - Access control integration

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
