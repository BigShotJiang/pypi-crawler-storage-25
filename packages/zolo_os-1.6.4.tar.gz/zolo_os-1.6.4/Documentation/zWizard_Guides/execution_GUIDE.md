# Execution Strategies for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/execution/`  
> **Purpose:** Mode-aware execution strategies (sequential vs chunked) for different runtime contexts

---

## Overview

**Execution strategies** enable zWizard to adapt workflow execution based on runtime mode (zCLI vs Bifrost). Sequential execution for terminal applications, chunked execution for web clients.

**Key Features:**
- **Mode detection**: Automatic based on `zMode` in zSession
- **Sequential execution**: zCLI mode - execute all steps, return at end
- **Chunked execution**: Bifrost mode - stream steps to web client incrementally
- **Strategy pattern**: Clean separation of execution logic
- **Unified API**: Same workflow code works in both modes

---

## Execution Modes

### Sequential Execution (zCLI Mode)

**When:** Terminal/CLI applications  
**Behavior:** Execute all steps in sequence, return final result

```python
from zOS import zOS

# zCLI mode (default)
z = zOS({"deployment": "Production"})

workflow_items = {
    "step1": {...},
    "step2": {...},
    "step3": {...},
}

# All steps execute sequentially
# Returns: final WizardHat with all results
zHat = z.wizard.execute_loop(workflow_items)
```

**Characteristics:**
- **Synchronous**: Steps execute one after another
- **Blocking**: Workflow blocks until all steps complete
- **Result accumulation**: All results collected in WizardHat
- **Full context**: Each step has access to all previous results

---

### Chunked Execution (Bifrost Mode)

**When:** Web applications, real-time UIs  
**Behavior:** Stream steps to web client as they execute

```python
from zOS import zOS

# Bifrost mode (web streaming)
z = zOS({
    "deployment": "Production",
    "zMode": "zBifrost",
})

workflow_items = {
    "step1": {...},
    "step2": {...},
    "step3": {...},
}

# Steps stream to web client as they execute
# ws_callback receives each step result
zHat = z.wizard.execute_loop(
    workflow_items,
    ws_callback=lambda chunk: send_to_web_client(chunk)
)
```

**Characteristics:**
- **Progressive**: Steps sent to client as they complete
- **Non-blocking UI**: Client can render incrementally
- **Real-time updates**: User sees progress as it happens
- **Improved UX**: Faster perceived performance

---

## Basic Usage

### Sequential Mode (zCLI)

Default mode for terminal applications.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = {
    "welcome": {
        "type": "zDisplay",
        "event": "text",
        "content": "Starting workflow..."
    },
    "fetch_data": {
        "type": "zData",
        "action": "query",
        "sql": "SELECT * FROM users"
    },
    "display_results": {
        "type": "zDisplay",
        "event": "table",
        "data": "{{ zHat.fetch_data }}"
    },
}

# Sequential execution - all steps run to completion
zHat = z.wizard.execute_loop(workflow)

# All results available
print(f"Fetched {len(zHat.fetch_data)} users")
```

### Chunked Mode (Bifrost)

Streaming mode for web applications.

```python
from zOS import zOS

z = zOS({
    "deployment": "Production",
    "zMode": "zBifrost",
})

def send_to_web(chunk):
    """Send step result to web client via WebSocket."""
    websocket.send(json.dumps(chunk))

workflow = {
    "step1": {"type": "zDisplay", "content": "Loading..."},
    "step2": {"type": "zData", "sql": "SELECT * FROM users"},
    "step3": {"type": "zDisplay", "content": "Complete!"},
}

# Chunked execution - steps stream to client
zHat = z.wizard.execute_loop(workflow, ws_callback=send_to_web)

# Each step result sent to send_to_web as it completes:
# 1. {"step": "step1", "result": {...}}
# 2. {"step": "step2", "result": {...}}
# 3. {"step": "step3", "result": {...}}
```

---

## Advanced Usage

### Mode-Aware Workflows

Same workflow code works in both modes.

```yaml
# workflow.yaml - works in both zCLI and Bifrost
welcome:
  type: zDisplay
  event: text
  content: "Welcome to the wizard"

fetch_users:
  type: zData
  action: query
  sql: "SELECT * FROM users"

show_users:
  type: zDisplay
  event: table
  data: "{{ zHat.fetch_users }}"
```

```python
# zCLI mode
z_cli = zOS({"deployment": "Production"})
zHat_cli = z_cli.wizard.handle(workflow)

# Bifrost mode
z_bifrost = zOS({"deployment": "Production", "zMode": "zBifrost"})
zHat_bifrost = z_bifrost.wizard.handle(workflow)

# Same workflow, different execution strategies
```

### Custom Chunk Processing

Process chunks before sending to client.

```python
def process_chunk(chunk):
    """Enhance chunk before sending to client."""
    # Add timestamp
    chunk["timestamp"] = datetime.now().isoformat()
    
    # Add metadata
    chunk["session_id"] = session.id
    
    # Transform result if needed
    if "result" in chunk and isinstance(chunk["result"], dict):
        chunk["result"] = transform_for_web(chunk["result"])
    
    # Send to client
    websocket.send(json.dumps(chunk))

zHat = z.wizard.execute_loop(workflow, ws_callback=process_chunk)
```

### Block-Level Chunking

Extract and execute specific workflow blocks.

```python
workflow = {
    "onboarding": {
        "step1": {...},
        "step2": {...},
        "step3": {...},
    },
    "settings": {
        "step4": {...},
        "step5": {...},
    },
}

# Execute only 'onboarding' block
zHat = z.wizard.execute_loop(
    workflow,
    block_name="onboarding",
    ws_callback=send_to_web
)
```

---

## Execution Strategy Classes

### SequentialExecutor

Executes steps synchronously in order.

**Features:**
- Linear execution flow
- Full result accumulation
- Navigation signal handling
- Breadcrumb tracking for menus
- Menu loop detection

**Use cases:**
- Terminal applications
- CLI tools
- Batch processing
- Admin scripts

---

### ChunkedExecutor

Executes steps with progressive result streaming.

**Features:**
- Progressive step execution
- WebSocket chunk streaming
- Real-time UI updates
- Block extraction support
- Same navigation signal handling as sequential

**Use cases:**
- Web applications
- Real-time dashboards
- Long-running workflows
- User-facing wizards

---

## API Reference

### SequentialExecutor

```python
class SequentialExecutor:
    """Sequential execution strategy for zCLI mode."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
    
    def execute(
        self,
        items_dict: Dict[str, Any],
        dispatch_fn: Optional[Any] = None,
        navigation_callbacks: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        start_key: Optional[str] = None,
        ws_callback: Optional[Any] = None,
        block_name: Optional[str] = None
    ) -> Any:
        """Execute steps sequentially."""
```

**Example:**
```python
executor = z.wizard._sequential_executor

result = executor.execute(
    items_dict=workflow_items,
    context={"user_id": 42}
)
```

---

### ChunkedExecutor

```python
class ChunkedExecutor:
    """Chunked execution strategy for Bifrost mode."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
    
    def execute(
        self,
        items_dict: Dict[str, Any],
        dispatch_fn: Optional[Any] = None,
        navigation_callbacks: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        start_key: Optional[str] = None,
        ws_callback: Optional[Any] = None,
        block_name: Optional[str] = None
    ) -> Any:
        """Execute steps with chunked streaming."""
```

**Example:**
```python
executor = z.wizard._chunked_executor

result = executor.execute(
    items_dict=workflow_items,
    ws_callback=send_to_web,
    context={"user_id": 42}
)
```

---

## Chunk Format (Bifrost Mode)

### Standard Chunk

```python
{
    "step": "step_key",           # Step identifier
    "result": {...},              # Step execution result
    "index": 0,                   # Step index in workflow
    "total": 5,                   # Total steps in workflow
    "navigation_signal": None,    # Navigation signal if any
}
```

### Chunk with Navigation Signal

```python
{
    "step": "menu_choice",
    "result": "zBack",
    "index": 2,
    "total": 5,
    "navigation_signal": "zBack",  # Navigation signal detected
}
```

### Error Chunk

```python
{
    "step": "failing_step",
    "error": "SQL syntax error",
    "index": 3,
    "total": 5,
    "navigation_signal": "error",
}
```

---

## Best Practices

### 1. Mode-Agnostic Workflows

```yaml
# Good: works in both modes
workflow:
  step1: {...}
  step2: {...}
  step3: {...}

# No mode-specific logic in workflow
# Execution strategy handles differences
```

### 2. Chunk Size Considerations

```python
# Good: reasonable chunk size
workflow = {
    "step1": {...},  # Quick operation
    "step2": {...},  # Quick operation
    "step3": {...},  # Quick operation
}

# Bad: one giant step (poor chunking)
workflow = {
    "process_everything": {
        "type": "zFunc",
        "action": "process_all_data"  # Takes minutes
    }
}

# Better: break into smaller steps
workflow = {
    "step1": {"action": "process_batch_1"},
    "step2": {"action": "process_batch_2"},
    "step3": {"action": "process_batch_3"},
}
```

### 3. WebSocket Callback Error Handling

```python
def safe_ws_callback(chunk):
    try:
        websocket.send(json.dumps(chunk))
    except Exception as e:
        logger.error(f"Failed to send chunk: {e}")
        # Don't crash workflow if WebSocket fails
```

### 4. Progress Indication

```python
def progress_callback(chunk):
    """Display progress to user."""
    index = chunk.get("index", 0)
    total = chunk.get("total", 0)
    step = chunk.get("step", "unknown")
    
    print(f"Progress: {index+1}/{total} - {step}")
    
    # Also send to web client
    websocket.send(json.dumps(chunk))
```

---

## Performance Considerations

**Sequential mode:**
- Blocks until all steps complete
- Lower overhead (no chunking)
- Better for fast workflows
- Simpler error handling

**Chunked mode:**
- Perceived performance improvement (progressive rendering)
- Slight overhead (serialization per chunk)
- Better for long workflows
- More complex error handling (mid-workflow failures)

---

## Mode Detection Logic

```python
from zOS.L1_Foundation.a_zConfig.zConfig_modules import ZMODE_ZBIFROST

# Mode detection in execute_loop
mode = z.session.get("zMode", "zCLI")

if mode == ZMODE_ZBIFROST:
    # Use chunked executor
    return z.wizard._chunked_executor.execute(...)
else:
    # Use sequential executor
    return z.wizard._sequential_executor.execute(...)
```

---

## Integration with Other Features

### With Navigation Signals

Both executors handle navigation signals identically.

```yaml
menu:
  type: zDisplay
  event: menu
  items:
    - label: "Continue"
      value: "continue"
    - label: "Exit"
      value: "exit"

# Both sequential and chunked handle exit signal
```

### With Transactions

Transactions work in both modes.

```yaml
_transaction: true

step1: {...}
step2: {...}

# Transaction commits after all steps (both modes)
```

### With RBAC

Access control enforced in both modes.

```yaml
admin_step:
  type: zData
  sql: "..."
  zRBAC:
    require_role: admin

# RBAC checked before step execution (both modes)
```

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **Navigation**: [navigation_GUIDE.md](navigation_GUIDE.md) - Signal handling
- **zBifrost Guide**: [zBifrost_GUIDE.md](../zBifrost_GUIDE.md) - Web integration

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
