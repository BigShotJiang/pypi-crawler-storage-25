# Navigation Management for Wizards

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/managers/wizard_navigation.py`  
> **Purpose:** Handle navigation signals, breadcrumb tracking, and menu looping for workflow control

---

## Overview

**Navigation management** enables workflow control through signals like zBack, exit, stop, and error. Essential for menu navigation, workflow interruption, and user-driven navigation.

**Key Features:**
- **Navigation signals**: zBack, exit, stop, error
- **Signal normalization**: Convert dict results to string signals
- **Callback handling**: Execute callbacks for navigation events
- **Breadcrumb tracking**: Track navigation path for menu systems
- **Menu pattern detection**: Identify menu anchors (~*)
- **zLink support**: Navigate to external workflows/menus

---

## Navigation Signals

### Four Core Signals

| Signal | Purpose | Use Case |
|--------|---------|----------|
| `zBack` | Return to previous menu/step | Menu navigation, cancel actions |
| `exit` | Exit application | Quit program, logout |
| `stop` | Stop workflow execution | Cancel long operations |
| `error` | Error occurred | Error handling, exception flows |

---

## Basic Usage

### Define Navigation Callbacks

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

# Define callbacks for navigation events
callbacks = {
    "on_back": lambda: print("User went back"),
    "on_exit": lambda: print("User exited"),
    "on_stop": lambda: print("Workflow stopped"),
    "on_error": lambda: print("Error occurred"),
}

workflow_items = {
    "main_menu": {
        "type": "zDisplay",
        "event": "menu",
        "items": [
            {"label": "Continue", "value": "continue"},
            {"label": "Go Back", "value": "zBack"},
            {"label": "Exit", "value": "exit"},
        ]
    },
}

# Execute with callbacks
result = z.wizard.execute_loop(workflow_items, navigation_callbacks=callbacks)

if result == "zBack":
    print("Returned to previous menu")
elif result == "exit":
    print("Exited application")
```

### YAML-Based Navigation

```yaml
# navigation_workflow.yaml
welcome:
  type: zDisplay
  event: text
  content: "Welcome! Press any key to continue or type 'exit' to quit."

get_action:
  type: zDialog
  prompt: "Enter action (continue/exit):"

process:
  type: zDisplay
  event: text
  content: "Processing..."
  _if: "{{ zHat.get_action != 'exit' }}"

# Return exit signal if user typed 'exit'
```

---

## Advanced Usage

### Menu Navigation with zBack

```yaml
# menu_system.yaml
main_menu:
  type: zDisplay
  event: menu
  items:
    - label: "Settings"
      value: "settings"
    - label: "Help"
      value: "help"
    - label: "Exit"
      value: "exit"

settings_menu:
  type: zDisplay
  event: menu
  items:
    - label: "Change Theme"
      value: "theme"
    - label: "Change Language"
      value: "language"
    - label: "Back"
      value: "zBack"  # Returns to main_menu
  _if: "{{ zHat.main_menu == 'settings' }}"

help_menu:
  type: zDisplay
  event: menu
  items:
    - label: "User Guide"
      value: "guide"
    - label: "Back"
      value: "zBack"  # Returns to main_menu
  _if: "{{ zHat.main_menu == 'help' }}"
```

### Breadcrumb Tracking

Track navigation path through menus.

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

breadcrumbs = []

def on_back():
    if breadcrumbs:
        previous = breadcrumbs.pop()
        print(f"Navigating back to: {previous}")

def on_forward(menu_name):
    breadcrumbs.append(menu_name)
    print(f"Navigating to: {menu_name}")

callbacks = {
    "on_back": on_back,
}

# Execute menu system with breadcrumb tracking
result = z.wizard.execute_loop(menu_items, navigation_callbacks=callbacks)
```

### Error Handling with Navigation

```yaml
# error_workflow.yaml
risky_operation:
  type: zData
  action: execute
  sql: "..."

error_handler:
  type: zDisplay
  event: text
  content: "Operation failed. Press any key to return."
  color: ERROR
  _if: "{{ 'error' in zHat }}"

# Navigation callback handles 'error' signal
```

---

## Signal Normalization

### Dict to String Conversion

The navigation manager automatically normalizes dict-based signals to strings.

```python
# These are equivalent:
result = {"zBack": True}  # Dict format
result = "zBack"          # String format (normalized to this)

# Both become "zBack" signal after normalization
```

**Why?** Different subsystems may return signals in different formats. Normalization ensures consistent handling.

---

## Menu Pattern Detection

### Menu Anchors (~*)

Menu anchors enable looping behavior for menu systems.

```yaml
# menu_with_anchor.yaml
~*main_menu:  # Anchor: loop back here after sub-menus
  type: zDisplay
  event: menu
  items:
    - label: "Option 1"
      value: "opt1"
    - label: "Option 2"
      value: "opt2"
    - label: "Exit"
      value: "exit"

sub_menu:
  type: zDisplay
  event: menu
  items:
    - label: "Action"
      value: "action"
    - label: "Back"
      value: "zBack"  # Returns to ~*main_menu anchor
```

**How it works:**
1. `~*` prefix marks menu as anchor point
2. `zBack` signal navigates to most recent `~*` anchor
3. Enables multi-level menu navigation

---

## zLink Navigation

Navigate to external workflows or menus.

```yaml
# main_workflow.yaml
welcome:
  type: zDisplay
  event: text
  content: "Welcome to main workflow"

navigate_to_admin:
  type: zLink
  target: "admin_workflow.yaml"
  _if: "{{ zHat.user_role == 'admin' }}"

navigate_to_user:
  type: zLink
  target: "user_workflow.yaml"
  _if: "{{ zHat.user_role == 'user' }}"
```

**zLink behavior:**
- Loads target workflow/menu
- Executes in new context
- Returns to original workflow after completion

---

## API Reference

### NavigationManager

```python
class NavigationManager:
    """Manages navigation signals, breadcrumbs, and menu looping."""
    
    def __init__(self, wizard: Any) -> None:
        """Initialize with wizard reference."""
```

---

### handle_navigation_result()

```python
handle_navigation_result(
    result: Any,
    key: str,
    navigation_callbacks: Optional[Dict[str, Any]]
) -> Any
```

Handle navigation results (zBack, exit, stop, error, zLink).

**Parameters:**
- `result` (Any): Result from dispatch
- `key` (str): Current step key
- `navigation_callbacks` (Optional[dict]): Callbacks for navigation events

**Returns:** Navigation signal or None

**Example:**
```python
result = z.wizard._navigation.handle_navigation_result(
    result="zBack",
    key="current_step",
    navigation_callbacks={"on_back": lambda: print("Going back")}
)
# Returns: "zBack"
# Executes: on_back callback
```

---

### detect_menu_pattern()

```python
detect_menu_pattern(items_dict: Dict[str, Any]) -> bool
```

Check if items dict contains menu pattern markers (~*).

**Parameters:**
- `items_dict` (dict): Items dictionary

**Returns:** True if menu pattern detected, False otherwise

**Example:**
```python
items = {
    "~*main_menu": {...},
    "sub_menu": {...},
}

is_menu = z.wizard._navigation.detect_menu_pattern(items)
# Returns: True (contains ~* prefix)
```

---

### find_menu_index()

```python
find_menu_index(items_dict: Dict[str, Any], start_key: str) -> Optional[int]
```

Find index of menu anchor for looping.

**Parameters:**
- `items_dict` (dict): Items dictionary
- `start_key` (str): Key to start from

**Returns:** Index of menu anchor or None

**Example:**
```python
items = {
    "step1": {...},
    "~*menu": {...},
    "step2": {...},
}

idx = z.wizard._navigation.find_menu_index(items, "~*menu")
# Returns: 1 (index of ~*menu)
```

---

## Best Practices

### 1. Use Callbacks for Side Effects

```python
# Good: callbacks for logging, state updates
callbacks = {
    "on_back": lambda: update_navigation_state("back"),
    "on_exit": lambda: save_session_and_cleanup(),
}

# Bad: inline side effects in workflow
# (hard to test, not reusable)
```

### 2. Provide Exit Options in Menus

```yaml
# Good: always provide exit
menu:
  type: zDisplay
  event: menu
  items:
    - label: "Option 1"
      value: "opt1"
    - label: "Back"
      value: "zBack"
    - label: "Exit"
      value: "exit"

# Bad: no way to exit
menu:
  type: zDisplay
  event: menu
  items:
    - label: "Option 1"
      value: "opt1"
```

### 3. Use Anchors for Menu Systems

```yaml
# Good: anchor for looping
~*main_menu:
  type: zDisplay
  event: menu
  items: [...]

# Bad: no anchor, can't loop back
main_menu:
  type: zDisplay
  event: menu
  items: [...]
```

### 4. Document Navigation Flow

```yaml
# Document expected navigation paths
# Flow: welcome → main_menu → (settings | help) → zBack to main_menu → exit

welcome:
  type: zDisplay
  content: "Welcome"

~*main_menu:
  type: zDisplay
  event: menu
  items: [...]
```

---

## Constants Reference

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.wizard_constants import (
    NAVIGATION_SIGNALS,
    _SIGNAL_ZBACK,
    _SIGNAL_EXIT,
    _SIGNAL_STOP,
    _SIGNAL_ERROR,
)
```

| Constant | Value | Description |
|----------|-------|-------------|
| `NAVIGATION_SIGNALS` | `["zBack", "exit", "stop", "error"]` | All navigation signals |
| `_SIGNAL_ZBACK` | `"zBack"` | Back signal |
| `_SIGNAL_EXIT` | `"exit"` | Exit signal |
| `_SIGNAL_STOP` | `"stop"` | Stop signal |
| `_SIGNAL_ERROR` | `"error"` | Error signal |

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **zWalker Guide**: [zWalker_GUIDE.md](../zWalker_GUIDE.md) - Menu navigation implementation
- **Execution**: [execution_GUIDE.md](execution_GUIDE.md) - Execution strategies

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
