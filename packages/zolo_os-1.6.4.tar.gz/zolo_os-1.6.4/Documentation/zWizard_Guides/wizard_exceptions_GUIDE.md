# zWizard Exception Hierarchy

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_exceptions.py`  
> **Purpose:** Custom exception hierarchy for wizard-specific errors

---

## Overview

**zWizard exceptions** provide clear, specific error handling for wizard workflow execution, initialization, and access control issues.

**Key Features:**
- **Base exception**: `zWizardError` (catch all wizard errors)
- **Initialization errors**: `WizardInitializationError` (setup failures)
- **Execution errors**: `WizardExecutionError` (runtime failures)
- **RBAC errors**: `WizardRBACError` (access control violations)
- **Clear error messages**: Descriptive messages for debugging
- **Inheritance hierarchy**: Standard Python exception patterns

---

## Exception Hierarchy

```
Exception
└── zWizardError (base)
    ├── WizardInitializationError
    ├── WizardExecutionError
    └── WizardRBACError
```

---

## Base Exception

### zWizardError

Base exception for all zWizard-related errors.

**Usage:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import zWizardError

try:
    # Wizard operations
    zHat = z.wizard.handle(workflow)
except zWizardError as e:
    # Catches all wizard-specific errors
    print(f"Wizard error: {e}")
```

**When to catch:**
- When you want to handle all wizard errors uniformly
- When wrapping wizard execution in error boundaries
- When logging wizard-specific failures

---

## Initialization Errors

### WizardInitializationError

Raised when zWizard initialization fails.

**Common causes:**
- Missing zOS or zWalker instance
- Missing required session
- Missing required logger
- Invalid configuration

**Example:**
```python
from zOS.L3_Abstraction.l_zWizard import zWizard
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import WizardInitializationError

try:
    # Invalid: no zos or walker provided
    wizard = zWizard()
except WizardInitializationError as e:
    print(f"Initialization failed: {e}")
    # Output: "zWizard requires either zos or walker instance"
```

**Error messages:**
- `"zWizard requires either zos or walker instance"`
- `"zWizard requires a walker with a session"`
- `"zWizard requires a walker with a logger"`

---

## Execution Errors

### WizardExecutionError

Raised when workflow execution fails.

**Common causes:**
- Invalid step configuration
- Step dispatch failures
- Navigation callback errors
- Data resolution failures

**Example:**
```python
from zOS import zOS
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import WizardExecutionError

z = zOS({"deployment": "Production"})

workflow = {
    "invalid_step": {
        "type": "NonExistentType",  # Invalid type
        "action": "something"
    }
}

try:
    zHat = z.wizard.handle(workflow)
except WizardExecutionError as e:
    print(f"Execution failed: {e}")
```

**Error scenarios:**
- Invalid step type
- Missing required step fields
- Dispatch function failures
- Navigation callback exceptions

---

## RBAC Errors

### WizardRBACError

Raised when role-based access control violations occur.

**Common causes:**
- Missing user context
- Invalid role configuration
- Permission check failures (when strict mode enabled)

**Example:**
```python
from zOS import zOS
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import WizardRBACError

z = zOS({"deployment": "Production"})

workflow = {
    "admin_step": {
        "type": "zData",
        "sql": "DELETE FROM users",
        "zRBAC": {
            "require_role": "admin",
            "strict": True  # Raise exception instead of skip
        }
    }
}

user_context = {
    "user_id": 42,
    "roles": ["user"],  # Not admin
}

try:
    zHat = z.wizard.handle(workflow)
except WizardRBACError as e:
    print(f"Access denied: {e}")
```

**Note:** By default, RBAC failures skip steps silently. `WizardRBACError` is only raised when `strict: true` in RBAC config.

---

## Error Handling Patterns

### Pattern 1: Catch All Wizard Errors

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import zWizardError

try:
    zHat = z.wizard.handle(workflow)
except zWizardError as e:
    logger.error(f"Wizard error: {e}")
    # Handle all wizard-specific errors
```

### Pattern 2: Specific Error Handling

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import (
    WizardInitializationError,
    WizardExecutionError,
    WizardRBACError,
)

try:
    zHat = z.wizard.handle(workflow)
except WizardInitializationError as e:
    print(f"Setup failed: {e}")
except WizardExecutionError as e:
    print(f"Execution failed: {e}")
except WizardRBACError as e:
    print(f"Access denied: {e}")
```

### Pattern 3: Graceful Degradation

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import zWizardError

try:
    zHat = z.wizard.handle(workflow)
except zWizardError as e:
    # Log error but continue with fallback
    logger.error(f"Wizard failed: {e}")
    zHat = execute_fallback_workflow()
```

### Pattern 4: Error Context Preservation

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import WizardExecutionError

try:
    zHat = z.wizard.handle(workflow)
except WizardExecutionError as e:
    # Re-raise with additional context
    raise WizardExecutionError(
        f"Failed to execute user registration workflow: {e}"
    ) from e
```

---

## API Reference

### zWizardError

```python
class zWizardError(Exception):
    """Base exception for all zWizard errors."""
```

**Usage:**
```python
raise zWizardError("Custom wizard error message")
```

---

### WizardInitializationError

```python
class WizardInitializationError(zWizardError):
    """Raised when zWizard initialization fails."""
```

**Usage:**
```python
raise WizardInitializationError("Missing required configuration")
```

---

### WizardExecutionError

```python
class WizardExecutionError(zWizardError):
    """Raised when wizard execution fails."""
```

**Usage:**
```python
raise WizardExecutionError(f"Step '{step_key}' failed: {reason}")
```

---

### WizardRBACError

```python
class WizardRBACError(zWizardError):
    """Raised when RBAC access control fails (strict mode)."""
```

**Usage:**
```python
raise WizardRBACError(f"User lacks required role: {required_role}")
```

---

## Best Practices

### 1. Catch Specific Exceptions

```python
# Good: specific handling
try:
    zHat = z.wizard.handle(workflow)
except WizardExecutionError as e:
    handle_execution_error(e)
except WizardRBACError as e:
    handle_access_denied(e)

# Bad: generic catching
try:
    zHat = z.wizard.handle(workflow)
except Exception as e:  # Too broad
    pass
```

### 2. Preserve Error Context

```python
# Good: preserve original error
try:
    zHat = z.wizard.handle(workflow)
except WizardExecutionError as e:
    logger.error(f"Workflow failed: {e}", exc_info=True)
    raise

# Bad: lose context
try:
    zHat = z.wizard.handle(workflow)
except WizardExecutionError:
    raise Exception("Something failed")  # Lost context
```

### 3. Provide Helpful Messages

```python
# Good: descriptive message
raise WizardExecutionError(
    f"Failed to execute step '{step_key}' in workflow '{workflow_name}': {error}"
)

# Bad: vague message
raise WizardExecutionError("Error")
```

### 4. Use Appropriate Exception Type

```python
# Good: correct exception type
if not zos and not walker:
    raise WizardInitializationError("Missing zos or walker instance")

if step_type not in VALID_TYPES:
    raise WizardExecutionError(f"Invalid step type: {step_type}")

# Bad: wrong exception type
if not zos and not walker:
    raise WizardExecutionError("Missing instance")  # Should be Initialization
```

---

## Constants Reference

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.wizard_constants import (
    ERR_MISSING_INSTANCE,
)
```

| Constant | Value | Description |
|----------|-------|-------------|
| `ERR_MISSING_INSTANCE` | `"zWizard requires either zos or walker instance"` | Initialization error message |

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **RBAC**: [wizard_rbac_GUIDE.md](wizard_rbac_GUIDE.md) - Access control
- **Transactions**: [wizard_transactions_GUIDE.md](wizard_transactions_GUIDE.md) - Transaction rollback on errors

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
