# zHat Template Variable Interpolation

> **Module:** `zOS/core/L3_Abstraction/l_zWizard/zWizard_modules/wizard_interpolation.py`  
> **Purpose:** Reference previous wizard step results using `{{ zHat.key }}` template syntax

---

## Overview

**Template interpolation** enables dynamic workflows by allowing subsequent steps to reference previous step results using a clean template syntax: `{{ zHat.key }}`.

**Key Features:**
- **Simple variable access**: `{{ zHat.step_name }}`
- **Nested dictionary access**: `{{ zHat.step.field.subfield }}`
- **List index access**: `{{ zHat.step[0] }}`
- **Multiple variables**: Combine multiple references in one string
- **Automatic interpolation**: Works in any string field (no manual string formatting)
- **Safe error handling**: Missing keys return placeholder, workflow continues

---

## Basic Usage

### Simple Variable Interpolation

Reference a previous step result by name.

```yaml
# workflow.yaml
get_name:
  type: zDialog
  prompt: "Enter your name:"

greet_user:
  type: zDisplay
  event: text
  content: "Hello, {{ zHat.get_name }}!"  # Reference previous result
```

```python
from zOS import zOS

z = zOS({"deployment": "Production"})

workflow = z.loader.load_yaml("workflow.yaml")
zHat = z.wizard.handle(workflow)

# If user entered "Alice", greet_user displays: "Hello, Alice!"
```

### Nested Dictionary Access

Access nested fields within step results.

```yaml
fetch_user:
  type: zData
  action: query
  sql: "SELECT name, email, role FROM users WHERE id = 1"

display_info:
  type: zDisplay
  event: text
  content: |
    User: {{ zHat.fetch_user.name }}
    Email: {{ zHat.fetch_user.email }}
    Role: {{ zHat.fetch_user.role }}
```

### List Index Access

Access elements within list results.

```yaml
fetch_files:
  type: zData
  action: query
  sql: "SELECT filename FROM files LIMIT 3"

display_files:
  type: zDisplay
  event: text
  content: |
    File 1: {{ zHat.fetch_files[0].filename }}
    File 2: {{ zHat.fetch_files[1].filename }}
    File 3: {{ zHat.fetch_files[2].filename }}
```

### Multiple Variable Interpolation

Combine multiple variables in a single string.

```yaml
get_first_name:
  type: zDialog
  prompt: "Enter first name:"

get_last_name:
  type: zDialog
  prompt: "Enter last name:"

get_city:
  type: zDialog
  prompt: "Enter city:"

get_state:
  type: zDialog
  prompt: "Enter state:"

summary:
  type: zDisplay
  event: text
  content: |
    Full Name: {{ zHat.get_first_name }} {{ zHat.get_last_name }}
    Location: {{ zHat.get_city }}, {{ zHat.get_state }}
```

---

## Advanced Usage

### Conditional Interpolation

Use interpolated values in conditional expressions.

```yaml
get_user_role:
  type: zDialog
  prompt: "Enter role (admin/user):"

admin_message:
  type: zDisplay
  event: text
  content: "Welcome, {{ zHat.get_user_role }}! You have admin access."
  _if: "{{ zHat.get_user_role == 'admin' }}"

user_message:
  type: zDisplay
  event: text
  content: "Welcome, {{ zHat.get_user_role }}! You have user access."
  _if: "{{ zHat.get_user_role == 'user' }}"
```

### Database Query Parameters

Use interpolated values as SQL parameters.

```yaml
get_user_id:
  type: zDialog
  prompt: "Enter user ID:"
  validate: integer

fetch_user:
  type: zData
  action: query
  sql: "SELECT * FROM users WHERE id = {{ zHat.get_user_id }}"

display_user:
  type: zDisplay
  event: text
  content: "User: {{ zHat.fetch_user.name }}, Email: {{ zHat.fetch_user.email }}"
```

### Multi-Step Data Pipeline

Chain interpolated values through multiple steps.

```yaml
extract:
  type: zData
  action: query
  sql: "SELECT * FROM raw_data"

transform:
  type: zFunc
  action: process_data
  input: "{{ zHat.extract }}"

load:
  type: zData
  action: insert
  table: processed_data
  data: "{{ zHat.transform }}"

report:
  type: zDisplay
  event: text
  content: |
    ETL Pipeline Complete:
    - Extracted: {{ len(zHat.extract) }} records
    - Transformed: {{ len(zHat.transform) }} records
    - Loaded: {{ zHat.load.inserted }} records
```

---

## Interpolation Syntax

### Basic Syntax

```
{{ zHat.step_name }}
```

### Nested Access

```
{{ zHat.step_name.field }}
{{ zHat.step_name.field.subfield }}
```

### List Indexing

```
{{ zHat.step_name[0] }}
{{ zHat.step_name[1].field }}
```

### Complex Expressions

```
{{ zHat.step1.field1 + zHat.step2.field2 }}
{{ zHat.step[0].items[2].name }}
```

---

## Error Handling

### Missing Keys

When a referenced key doesn't exist, interpolation returns a placeholder.

```yaml
# If "nonexistent" step doesn't exist
content: "Value: {{ zHat.nonexistent }}"

# Result: "Value: {{ zHat.nonexistent }}" (unchanged)
# Workflow continues without error
```

### Missing Nested Fields

```yaml
# If "fetch_user" has no "middle_name" field
content: "Name: {{ zHat.fetch_user.middle_name }}"

# Result: "Name: {{ zHat.fetch_user.middle_name }}" (unchanged)
# Workflow continues without error
```

### Invalid List Indices

```yaml
# If list has only 2 items
content: "Item: {{ zHat.fetch_items[10] }}"

# Result: "Item: {{ zHat.fetch_items[10] }}" (unchanged)
# Workflow continues without error
```

---

## API Reference

### interpolate_zhat()

```python
interpolate_zhat(value: Any, zHat: WizardHat, logger: Any) -> Any
```

Recursively interpolate zHat variables in strings, dicts, and lists.

**Parameters:**
- `value` (Any): Value to interpolate (string, dict, list, or primitive)
- `zHat` (WizardHat): Container with previous step results
- `logger` (Logger): Logger instance for debug output

**Returns:** Value with interpolated variables

**Examples:**
```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules import interpolate_zhat

# String interpolation
result = interpolate_zhat("Hello, {{ zHat.name }}!", zHat, logger)

# Dict interpolation
config = {
    "title": "{{ zHat.get_title }}",
    "count": "{{ zHat.fetch_data.count }}"
}
result = interpolate_zhat(config, zHat, logger)

# List interpolation
items = [
    "{{ zHat.item1 }}",
    "{{ zHat.item2 }}",
    "{{ zHat.item3 }}"
]
result = interpolate_zhat(items, zHat, logger)
```

---

## Best Practices

### 1. Use Semantic Step Names

```yaml
# Good: clear, descriptive names
get_user_email:
  type: zDialog
  prompt: "Enter email:"

send_confirmation:
  type: zFunc
  action: send_email
  to: "{{ zHat.get_user_email }}"

# Bad: generic names
step1:
  type: zDialog
  prompt: "Enter email:"

step2:
  type: zFunc
  action: send_email
  to: "{{ zHat.step1 }}"
```

### 2. Check for Existence in Conditionals

```yaml
# Safe: check if step exists before using
display_result:
  type: zDisplay
  event: text
  content: "Result: {{ zHat.fetch_data.value }}"
  _if: "{{ 'fetch_data' in zHat }}"
```

### 3. Use Nested Access for Clarity

```yaml
# Good: clear field access
content: "User {{ zHat.fetch_user.name }} has {{ zHat.fetch_user.count }} items"

# Bad: unclear reference
content: "User {{ zHat.user }} has {{ zHat.count }} items"
```

### 4. Document Complex Interpolations

```yaml
# Document complex nested access
fetch_order:
  type: zData
  action: query
  sql: "SELECT * FROM orders WHERE id = 1"

# Access: order → customer → address → city
display_city:
  type: zDisplay
  event: text
  content: "City: {{ zHat.fetch_order.customer.address.city }}"
```

### 5. Avoid Deep Nesting

```yaml
# Good: shallow, readable
fetch_user:
  type: zData
  action: query
  sql: "SELECT name, city FROM users WHERE id = 1"

content: "{{ zHat.fetch_user.name }} lives in {{ zHat.fetch_user.city }}"

# Bad: deeply nested, hard to read
content: "{{ zHat.step1.result.data.user.profile.address.city }}"
```

---

## Integration with Other Features

### With Conditional Execution

```yaml
get_role:
  type: zDialog
  prompt: "Enter role:"

admin_dashboard:
  type: zDisplay
  event: text
  content: "Admin Dashboard for {{ zHat.get_role }}"
  _if: "{{ zHat.get_role == 'admin' }}"
```

### With Transactions

```yaml
_transaction: true

create_user:
  type: zData
  action: execute
  sql: "INSERT INTO users (name) VALUES ('{{ zHat.get_name }}') RETURNING id"

create_profile:
  type: zData
  action: execute
  sql: "INSERT INTO profiles (user_id, bio) VALUES ({{ zHat.create_user.id }}, '{{ zHat.get_bio }}')"
```

### With RBAC

```yaml
get_username:
  type: zDialog
  prompt: "Enter username:"

admin_action:
  type: zDisplay
  event: text
  content: "Performing admin action for {{ zHat.get_username }}"
  zRBAC:
    require_role: admin
```

---

## Performance Considerations

**Interpolation overhead:** Interpolation is performed once per step during workflow execution. For most workflows, overhead is negligible.

**Large data structures:** Avoid interpolating very large objects (>1MB). Instead:
- Pass references or IDs
- Use database queries to fetch subsets
- Store large data externally

**Recursive interpolation:** Handles nested dicts/lists automatically. Max depth: 100 levels (more than sufficient for real workflows).

---

## Constants Reference

```python
from zOS.L3_Abstraction.l_zWizard.zWizard_modules.wizard_constants import (
    _ZHAT_PREFIX,
    _ZHAT_PATTERN,
)
```

| Constant | Value | Description |
|----------|-------|-------------|
| `_ZHAT_PREFIX` | `"zHat."` | Prefix for zHat variable references |
| `_ZHAT_PATTERN` | Regex pattern | Pattern to match `{{ zHat.* }}` syntax |

---

## Related Documentation

- **Main Guide**: [zWizard_GUIDE.md](../zWizard_GUIDE.md) - Facade overview
- **WizardHat**: [wizard_hat_GUIDE.md](wizard_hat_GUIDE.md) - Triple-access container
- **Conditionals**: [conditions_GUIDE.md](conditions_GUIDE.md) - Conditional execution

---

**Version:** v1.5.4+  
**Layer:** 3 (Orchestration)  
**Position:** 2 (zWizard subsystem)
