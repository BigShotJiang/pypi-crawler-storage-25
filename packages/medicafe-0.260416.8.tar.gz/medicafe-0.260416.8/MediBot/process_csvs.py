#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
MediBot CSV Processor

This script processes CSV files from the download folder, moves them to the target folder
with timestamp renaming, updates the config file, and builds the deductible cache.

Operations:
- Moves CSV files from local_storage_path to source_folder
- Finds most recent CSV file in source_folder
- Validates/compares with config file's current CSV path
- Moves CSV to target folder with timestamp rename (SX_CSV_<timestamp>.csv)
- Updates config JSON with new CSV path
- Updates downloaded_emails.txt with original filename
- Builds deductible cache

Use --silent flag to suppress non-error output.
"""

import os
import re
import sys
import json
import argparse
import shutil
import glob
import time
from datetime import datetime

# Setup Python path to find MediCafe
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_root = os.path.dirname(current_dir)
if workspace_root not in sys.path:
    sys.path.insert(0, workspace_root)

from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config

# Import required functions directly (no subprocess calls needed)
try:
    from MediBot.update_json import get_current_csv_path, update_csv_path
    HAS_UPDATE_JSON = True
except ImportError:
    HAS_UPDATE_JSON = False

try:
    from MediLink.MediLink_Gmail import add_downloaded_email
    HAS_ADD_DOWNLOADED_EMAIL = True
except ImportError:
    HAS_ADD_DOWNLOADED_EMAIL = False

try:
    from MediBot.build_deductible_cache import build_deductible_cache
    HAS_BUILD_CACHE = True
except ImportError:
    HAS_BUILD_CACHE = False

try:
    from MediCafe.MediLink_ConfigLoader import clear_config_cache, load_configuration
    HAS_CONFIG_LOADER = True
except ImportError:
    HAS_CONFIG_LOADER = False

# Setup logging
try:
    LOGGER = get_config_loader_with_fallback()
except Exception:
    LOGGER = None

def _log(message, level="INFO"):
    """Log message using shared config loader if available."""
    try:
        if LOGGER and hasattr(LOGGER, "log"):
            LOGGER.log(message, level=level)
    except Exception:
        pass


def _log_step(message):
    """Routine CSV processing milestone that should be visible in normal logs."""
    _log(message, level="INFO")


CSV_PROCESSING_STAGE = 'not_started'
CSV_PROCESSING_CONTEXT = {}


def _json_default(value):
    try:
        return str(value)
    except Exception:
        return '<unprintable>'


def _set_csv_context(stage=None, **fields):
    global CSV_PROCESSING_STAGE, CSV_PROCESSING_CONTEXT
    if stage is not None:
        CSV_PROCESSING_STAGE = str(stage or '')
    try:
        for key, value in fields.items():
            CSV_PROCESSING_CONTEXT[key] = value
    except Exception:
        pass


def _csv_event(event, level="INFO", **fields):
    payload = {
        'event': event,
        'stage': CSV_PROCESSING_STAGE,
    }
    try:
        payload.update(CSV_PROCESSING_CONTEXT)
        payload.update(fields)
        message = "CSV_PROCESSING_EVENT {}".format(json.dumps(payload, sort_keys=True, default=_json_default))
    except Exception:
        message = "CSV_PROCESSING_EVENT event={} stage={} fields_unserializable=True".format(event, CSV_PROCESSING_STAGE)
    _log(message, level=level)


# ---------------------------------------------------------------------------
# CSV intake index (persisted mapping: downloaded_emails.txt <-> source/target CSVs)
# Pattern mirrors MediBot_docx_index: index JSON + last-run status JSON, temp+replace writes.
# ---------------------------------------------------------------------------

CSV_INTAKE_INDEX_FILENAME = 'csv_intake_index.json'
CSV_INTAKE_STATUS_FILENAME = 'csv_intake_index_status.json'
CSV_INTAKE_INDEX_VERSION = 1


def _safe_replace(src, dst):
    try:
        os.replace(src, dst)
    except Exception:
        try:
            if os.path.exists(dst):
                os.remove(dst)
            os.rename(src, dst)
        except Exception:
            pass


def _get_index_local_storage_abs(config, local_storage_path_arg):
    """
    Resolve absolute local storage directory (same basis as downloaded_emails.txt).
    When config uses '.', prefer the launcher's local_storage_path argument if provided.
    """
    if isinstance(config, dict):
        medi = extract_medilink_config(config)
        base = medi.get('local_storage_path', '.') or '.'
        if base == '.' and local_storage_path_arg:
            base = local_storage_path_arg
        return os.path.abspath(os.path.expanduser(base))
    if local_storage_path_arg:
        return os.path.abspath(os.path.expanduser(local_storage_path_arg))
    return os.path.abspath('.')


def _get_intake_index_path(local_storage_abs):
    return os.path.join(local_storage_abs, CSV_INTAKE_INDEX_FILENAME)


def _get_intake_status_path(local_storage_abs):
    return os.path.join(local_storage_abs, CSV_INTAKE_STATUS_FILENAME)


def _default_intake_index():
    return {
        'version': CSV_INTAKE_INDEX_VERSION,
        'updated_at_utc': None,
        'entries': {},
    }


def _load_csv_intake_index(local_storage_abs):
    path = _get_intake_index_path(local_storage_abs)
    if not os.path.exists(path):
        return _default_intake_index()
    try:
        with open(path, 'r') as jf:
            data = json.load(jf)
        if not isinstance(data, dict):
            return _default_intake_index()
        if 'entries' not in data or not isinstance(data.get('entries'), dict):
            return _default_intake_index()
        if data.get('version') != CSV_INTAKE_INDEX_VERSION:
            data.setdefault('entries', {})
            data['version'] = CSV_INTAKE_INDEX_VERSION
        return data
    except Exception:
        return _default_intake_index()


def _save_csv_intake_index(local_storage_abs, index_data):
    try:
        if local_storage_abs and not os.path.isdir(local_storage_abs):
            try:
                os.makedirs(local_storage_abs)
            except Exception:
                pass
        index_data['updated_at_utc'] = int(time.time())
        path = _get_intake_index_path(local_storage_abs)
        try:
            from MediCafe.json_io import write_json_atomic
        except ImportError:
            write_json_atomic = None
        if write_json_atomic is not None:
            if write_json_atomic(
                    path,
                    index_data,
                    'csv_intake_index',
                    'process_csvs',
                    indent=2,
                    sort_keys=True,
                    lock=True,
                    ensure_ascii=False,
            ):
                return True
            return False
        tmp_path = path + '.tmp'
        with open(tmp_path, 'w') as jf:
            json.dump(index_data, jf, sort_keys=True)
        _safe_replace(tmp_path, path)
        return True
    except Exception as e:
        _log("Failed to write CSV intake index: {}".format(e), level="WARNING")
        _csv_event(
            'index_write_failed',
            level='WARNING',
            artifact='csv_intake_index',
            exception_type=e.__class__.__name__,
            exception_message=str(e),
        )
        return False


def _save_csv_intake_status(local_storage_abs, status_data):
    try:
        if local_storage_abs and not os.path.isdir(local_storage_abs):
            try:
                os.makedirs(local_storage_abs)
            except Exception:
                pass
        path = _get_intake_status_path(local_storage_abs)
        try:
            from MediCafe.json_io import write_json_atomic
        except ImportError:
            write_json_atomic = None
        if write_json_atomic is not None:
            if write_json_atomic(
                    path,
                    status_data,
                    'csv_intake_index_status',
                    'process_csvs',
                    indent=2,
                    sort_keys=True,
                    lock=True,
                    ensure_ascii=False,
            ):
                return True
            return False
        tmp_path = path + '.tmp'
        with open(tmp_path, 'w') as jf:
            json.dump(status_data, jf, sort_keys=True)
        _safe_replace(tmp_path, path)
        return True
    except Exception as e:
        _log("Failed to write CSV intake index status: {}".format(e), level="WARNING")
        _csv_event(
            'index_write_failed',
            level='WARNING',
            artifact='csv_intake_index_status',
            exception_type=e.__class__.__name__,
            exception_message=str(e),
        )
        return False


def _normalize_csv_intake_key(filename):
    if not filename:
        return ''
    return os.path.basename(str(filename)).strip().lower()


def _load_downloaded_emails_names(local_storage_abs):
    path = os.path.join(local_storage_abs, 'downloaded_emails.txt')
    names = []
    if not os.path.exists(path):
        return names
    try:
        with open(path, 'r') as handle:
            for line in handle:
                s = (line or '').strip()
                if s:
                    names.append(s)
    except Exception:
        pass
    return names


def _csv_basenames_in_folder(folder):
    if not folder or not os.path.isdir(folder):
        return set()
    out = set()
    try:
        pattern = os.path.join(folder, '*.csv')
        for p in glob.glob(pattern):
            out.add(os.path.basename(p))
    except Exception:
        pass
    return out


def _merge_downloaded_tracker_into_index(index_data, downloaded_names, now_ts):
    entries = index_data.setdefault('entries', {})
    for name in downloaded_names:
        key = _normalize_csv_intake_key(name)
        if not key:
            continue
        if key not in entries:
            entries[key] = {
                'downloaded_name': name,
                'first_seen_at_utc': now_ts,
                'last_seen_at_utc': now_ts,
                'current': None,
                'history': [],
            }
        else:
            ent = entries[key]
            ent['last_seen_at_utc'] = now_ts
            if 'history' not in ent or not isinstance(ent.get('history'), list):
                ent['history'] = []
            if 'downloaded_name' not in ent:
                ent['downloaded_name'] = name


def _reconcile_intake_index_entries(index_data, source_folder, target_folder):
    source_basenames = _csv_basenames_in_folder(source_folder)
    target_basenames = _csv_basenames_in_folder(target_folder)
    entries = index_data.get('entries', {})
    if not isinstance(entries, dict):
        return
    for _key, entry in list(entries.items()):
        if not isinstance(entry, dict):
            continue
        cur = entry.get('current')
        if isinstance(cur, dict):
            src_bn = cur.get('source_basename') or entry.get('downloaded_name') or ''
            tgt_bn = cur.get('target_basename') or ''
            cur['present_in_source'] = bool(src_bn) and (src_bn in source_basenames)
            cur['present_in_target'] = bool(tgt_bn) and (tgt_bn in target_basenames)
            if cur.get('present_in_target'):
                cur['status'] = 'mapped'
            elif cur.get('present_in_source'):
                cur['status'] = 'source_only'
            elif tgt_bn:
                cur['status'] = 'target_only'
            else:
                cur['status'] = 'unmapped'
        else:
            dn = entry.get('downloaded_name') or ''
            entry['tracker_present_in_source'] = bool(dn) and (dn in source_basenames)


def _compute_intake_index_stats(index_data, downloaded_names):
    entries = index_data.get('entries', {})
    hist_total = 0
    mapped = 0
    no_current = 0
    in_src = 0
    in_tgt = 0
    if not isinstance(entries, dict):
        entries = {}
    for _k, ent in entries.items():
        if not isinstance(ent, dict):
            continue
        h = ent.get('history')
        if isinstance(h, list):
            hist_total += len(h)
        cur = ent.get('current')
        if isinstance(cur, dict):
            if cur.get('status') == 'mapped':
                mapped += 1
            if cur.get('present_in_source'):
                in_src += 1
            if cur.get('present_in_target'):
                in_tgt += 1
        else:
            no_current += 1
    return {
        'downloaded_tracker_count': len(downloaded_names),
        'entries_count': len(entries),
        'mapped_current': mapped,
        'no_current_mapping': no_current,
        'current_present_in_source': in_src,
        'current_present_in_target': in_tgt,
        'history_records_total': hist_total,
    }


def _record_csv_intake_mapping(
    index_data,
    local_storage_abs,
    original_csv_filename,
    source_path_before_move,
    target_path_after_move,
    iteration,
):
    """Update index entry; append history when current mapping changes materially."""
    key = _normalize_csv_intake_key(original_csv_filename)
    if not key:
        return False
    entries = index_data.setdefault('entries', {})
    now_ts = int(time.time())
    if key not in entries:
        entries[key] = {
            'downloaded_name': original_csv_filename,
            'first_seen_at_utc': now_ts,
            'last_seen_at_utc': now_ts,
            'current': None,
            'history': [],
        }
    entry = entries[key]
    if not isinstance(entry.get('history'), list):
        entry['history'] = []
    old = entry.get('current')
    new_target = os.path.abspath(target_path_after_move) if target_path_after_move else ''
    new_source = os.path.abspath(source_path_before_move) if source_path_before_move else ''
    new_tgt_bn = os.path.basename(new_target) if new_target else ''

    if isinstance(old, dict) and old:
        old_target = old.get('target_path') or ''
        old_source = old.get('source_path') or ''
        material = (old_target != new_target) or (old_source != new_source)
        if material:
            history = entry['history']
            history.append({
                'source_path': old_source,
                'target_path': old_target,
                'target_basename': old.get('target_basename') or '',
                'source_basename': old.get('source_basename') or '',
                'recorded_at_utc': old.get('updated_at_utc'),
                'superseded_at_utc': now_ts,
                'reason': 'retargeted',
            })
            entry['history'] = history
            _csv_event(
                'index_history_appended',
                level='INFO',
                intake_key=key,
                history_len=len(history),
            )

    src_bn = os.path.basename(source_path_before_move) if source_path_before_move else original_csv_filename
    entry['current'] = {
        'source_path': new_source,
        'target_path': new_target,
        'source_basename': src_bn,
        'target_basename': new_tgt_bn,
        'present_in_source': True,
        'present_in_target': True,
        'last_process_iteration': iteration,
        'status': 'mapped',
        'updated_at_utc': now_ts,
    }
    entry['last_seen_at_utc'] = now_ts
    entry['downloaded_name'] = original_csv_filename
    ok = _save_csv_intake_index(local_storage_abs, index_data)
    if ok:
        _csv_event(
            'index_updated',
            level='INFO',
            intake_key=key,
            target_basename=new_tgt_bn,
        )
    return ok


def _finalize_csv_intake_index(
    index_data,
    local_storage_abs,
    source_folder,
    target_folder,
    downloaded_names,
    started_at,
    silent,
):
    _reconcile_intake_index_entries(index_data, source_folder, target_folder)
    stats = _compute_intake_index_stats(index_data, downloaded_names)
    _save_csv_intake_index(local_storage_abs, index_data)
    _save_csv_intake_status(local_storage_abs, {
        'source': 'process_csvs',
        'started_at': started_at,
        'completed_at': int(time.time()),
        'requested_downloaded_count': len(downloaded_names),
        'stats': stats,
    })
    _csv_event('index_reconciled', level='INFO', **stats)
    summary = (
        "CSV intake index: tracker_lines={tracker} entries={entries} mapped={mapped} "
        "present_in_source={pinsrc} present_in_target={pintgt} no_current={nocur} history_records={hist}".format(
            tracker=stats['downloaded_tracker_count'],
            entries=stats['entries_count'],
            mapped=stats['mapped_current'],
            pinsrc=stats['current_present_in_source'],
            pintgt=stats['current_present_in_target'],
            nocur=stats['no_current_mapping'],
            hist=stats['history_records_total'],
        )
    )
    _log_step(summary)
    if not silent:
        print(summary)
    return stats


def resolve_csv_intake_local_storage(config_path, local_storage_path_arg=None):
    """
    Resolve absolute local storage for CSV intake index / downloaded_emails.txt.
    For launcher wizards: does not exit on failure; returns None if config unreadable.
    """
    try:
        if not config_path:
            return None
        path = os.path.abspath(os.path.expanduser(config_path))
        if not os.path.exists(path):
            return None
        with open(path, 'r') as handle:
            cfg = json.load(handle)
        if not isinstance(cfg, dict):
            return None
        return _get_index_local_storage_abs(cfg, local_storage_path_arg)
    except Exception:
        return None


def read_csv_intake_index(local_storage_abs):
    """Load persisted intake index; safe default if missing or invalid."""
    if not local_storage_abs:
        return _default_intake_index()
    return _load_csv_intake_index(local_storage_abs)


def read_csv_intake_status(local_storage_abs):
    """Load last-run status dict; empty if missing."""
    if not local_storage_abs:
        return {}
    path = _get_intake_status_path(local_storage_abs)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r') as jf:
            data = json.load(jf)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def csv_intake_artifact_paths(local_storage_abs):
    """Paths to index, status, and downloaded_emails tracker (basenames only in UI)."""
    if not local_storage_abs:
        return {
            'index': '',
            'status': '',
            'downloaded_emails': '',
        }
    root = local_storage_abs
    return {
        'index': _get_intake_index_path(root),
        'status': _get_intake_status_path(root),
        'downloaded_emails': os.path.join(root, 'downloaded_emails.txt'),
    }


def format_csv_intake_wizard_report(index_data, status_data, max_rows=12):
    """
    Human-readable lines for console wizard (basenames and counts only; no row-level PHI).
    """
    lines = []
    if not isinstance(status_data, dict):
        status_data = {}
    stats = status_data.get('stats') if isinstance(status_data.get('stats'), dict) else {}
    if status_data:
        phase = status_data.get('phase') or ''
        completed = status_data.get('completed_at')
        started = status_data.get('started_at')
        lines.append(
            'Last status: phase={phase} started_at={started} completed_at={completed}'.format(
                phase=phase or '(finished)',
                started=started,
                completed=completed,
            )
        )
        if stats:
            lines.append(
                '  stats: mapped={mapped} no_current={nocur} in_src={pinsrc} in_tgt={pintgt} history={hist} tracker_lines={trk}'.format(
                    mapped=stats.get('mapped_current', 0),
                    nocur=stats.get('no_current_mapping', 0),
                    pinsrc=stats.get('current_present_in_source', 0),
                    pintgt=stats.get('current_present_in_target', 0),
                    hist=stats.get('history_records_total', 0),
                    trk=stats.get('downloaded_tracker_count', 0),
                )
            )
    else:
        lines.append('No status file yet (intake may not have completed before).')

    entries = index_data.get('entries') if isinstance(index_data, dict) else None
    if not isinstance(entries, dict) or not entries:
        lines.append('Index entries: (none)')
        return lines

    rows = []
    for _key, ent in entries.items():
        if not isinstance(ent, dict):
            continue
        name = ent.get('downloaded_name') or _key
        cur = ent.get('current')
        tgt = ''
        st = ''
        hist_n = 0
        if isinstance(ent.get('history'), list):
            hist_n = len(ent['history'])
        if isinstance(cur, dict):
            tgt = cur.get('target_basename') or ''
            st = cur.get('status') or ''
            if cur.get('inferred_mapping'):
                st = '{0} (inferred)'.format(st) if st else 'inferred'
        rows.append((str(name).lower(), name, tgt or '-', st or '-', hist_n))

    rows.sort(key=lambda r: r[0])
    lines.append('Tracker / index rows (basename -> target SX, status, history depth):')
    shown = rows[: max(0, int(max_rows))]
    for _sortkey, name, tgt, st, hist_n in shown:
        lines.append('  {name} | {tgt} | {st} | hist={hist}'.format(name=name, tgt=tgt, st=st, hist=hist_n))
    if len(rows) > len(shown):
        lines.append('  ... and {n} more (open csv_intake_index.json for full detail)'.format(n=len(rows) - len(shown)))
    return lines


# Heuristic: embedded YYYYMMDD_HHMMSS_###### in downloaded basename -> next later SX_CSV_* in target.
_TRACKER_EMBEDDED_TS_RE = re.compile(r'(\d{8})_(\d{6})_(\d{6})')
_SX_CSV_TS_RE = re.compile(r'^SX_CSV_(\d{8})_(\d{6})(?:_(\d+))?\.csv$', re.IGNORECASE)


def _parse_tracker_embedded_datetime(basename):
    """Parse rightmost YYYYMMDD_HHMMSS_###### from tracker/downloaded basename; None if absent."""
    if not basename:
        return None
    name = os.path.basename(str(basename))
    matches = _TRACKER_EMBEDDED_TS_RE.findall(name)
    if not matches:
        return None
    ymd, hms, frac6 = matches[-1]
    try:
        base_dt = datetime.strptime('{0}_{1}'.format(ymd, hms), '%Y%m%d_%H%M%S')
        micro = int(frac6)
        if micro > 999999:
            micro = 999999
        return base_dt.replace(microsecond=micro)
    except Exception:
        return None


def _parse_sx_csv_datetime(basename):
    """Parse SX_CSV_YYYYMMDD_HHMMSS[_fraction].csv basename to datetime; None if not matched."""
    if not basename:
        return None
    name = os.path.basename(str(basename))
    m = _SX_CSV_TS_RE.match(name)
    if not m:
        return None
    ymd, hms, frac_raw = m.group(1), m.group(2), m.group(3)
    try:
        base_dt = datetime.strptime('{0}_{1}'.format(ymd, hms), '%Y%m%d_%H%M%S')
        if frac_raw:
            raw = int(frac_raw)
            frag = m.group(3)
            if len(frag) <= 6:
                micro = raw
            else:
                micro = int(frag[:6])
            if micro > 999999:
                micro = 999999
            return base_dt.replace(microsecond=micro)
        return base_dt
    except Exception:
        return None


def apply_sx_heuristic_backfill(
    index_data,
    source_folder,
    target_folder,
    local_storage_abs,
    persist=True,
    quiet=True,
    cold_start=False,
):
    """
    For index entries with no current mapping, infer target SX_CSV_* by timestamp ordering
    (earliest unused SX strictly after embedded tracker time).

    Incremental by design: only fills entries with current=None; never overwrites observed intake.

    persist: when False, only mutates index_data (caller saves, e.g. process_csv finalize).
    quiet: when False, prints a one-line summary to stdout.
    cold_start: True if no csv_intake_index.json existed before this run (telemetry only).
    Returns stats dict: inferred, skipped_unparsed, skipped_no_sx, saved, backfill_mode.
    """
    result = {
        'inferred': 0,
        'skipped_unparsed': 0,
        'skipped_no_sx': 0,
        'saved': False,
        'backfill_mode': 'full_seed' if cold_start else 'incremental',
    }
    if not isinstance(index_data, dict):
        return result
    entries = index_data.get('entries')
    if not isinstance(entries, dict):
        return result

    claimed = set()
    for _k, ent in entries.items():
        if not isinstance(ent, dict):
            continue
        cur = ent.get('current')
        if isinstance(cur, dict):
            tb = cur.get('target_basename') or ''
            if tb:
                claimed.add(tb)

    sx_candidates = []
    if target_folder and os.path.isdir(target_folder):
        pattern = os.path.join(target_folder, 'SX_CSV_*.csv')
        for p in glob.glob(pattern):
            bn = os.path.basename(p)
            dt_sx = _parse_sx_csv_datetime(bn)
            if dt_sx is not None and bn not in claimed:
                sx_candidates.append((bn, dt_sx))
    sx_candidates.sort(key=lambda x: x[1])

    skipped_unparsed = 0
    candidates_with_dt = []
    for key, ent in entries.items():
        if not isinstance(ent, dict):
            continue
        if ent.get('current') is not None:
            continue
        name = ent.get('downloaded_name') or key
        dt_track = _parse_tracker_embedded_datetime(name)
        if dt_track is None:
            skipped_unparsed += 1
        else:
            candidates_with_dt.append((key, ent, dt_track))

    candidates_with_dt.sort(key=lambda x: x[2])

    used_sx = set()
    inferred = 0
    skipped_no_sx = 0
    now_ts = int(time.time())
    target_abs = os.path.abspath(target_folder) if target_folder else ''

    for _key, ent, t_track in candidates_with_dt:
        chosen = None
        for bn, t_sx in sx_candidates:
            if bn in used_sx:
                continue
            if t_sx > t_track:
                chosen = bn
                break
        if not chosen:
            skipped_no_sx += 1
            continue
        used_sx.add(chosen)
        tgt_path = os.path.join(target_abs, chosen) if target_abs else chosen
        src_bn = os.path.basename(str(ent.get('downloaded_name') or _key))
        exists = os.path.isfile(tgt_path)
        ent['current'] = {
            'source_path': '',
            'target_path': os.path.abspath(tgt_path) if tgt_path else '',
            'source_basename': src_bn,
            'target_basename': chosen,
            'present_in_source': False,
            'present_in_target': exists,
            'last_process_iteration': 0,
            'status': 'mapped' if exists else 'target_only',
            'updated_at_utc': now_ts,
            'inferred_mapping': True,
            'inference_rule': 'next_sx_after_tracker_timestamp',
        }
        inferred += 1

    result['skipped_unparsed'] = skipped_unparsed
    result['skipped_no_sx'] = skipped_no_sx
    result['inferred'] = inferred

    _set_csv_context('index_heuristic_backfill')
    _reconcile_intake_index_entries(
        index_data,
        source_folder or '',
        target_folder or '',
    )
    saved = False
    if persist and local_storage_abs:
        saved = _save_csv_intake_index(local_storage_abs, index_data)
    result['saved'] = bool(saved)

    _csv_event(
        'index_heuristic_backfill',
        level='INFO',
        inferred=inferred,
        skipped_unparsed=skipped_unparsed,
        skipped_no_sx=skipped_no_sx,
        sx_pool=len(sx_candidates),
        saved=bool(saved),
        persist=bool(persist),
        backfill_mode=result['backfill_mode'],
    )
    if not quiet:
        print(
            'CSV intake heuristic backfill ({0}): inferred={1} skipped_unparsed={2} skipped_no_sx={3} sx_pool={4} persisted={5}'.format(
                result['backfill_mode'],
                inferred,
                skipped_unparsed,
                skipped_no_sx,
                len(sx_candidates),
                bool(saved),
            )
        )
    return result


def load_config(config_path):
    """Load configuration from JSON file"""
    try:
        if not os.path.isabs(config_path):
            config_path = os.path.abspath(config_path)
        with open(config_path, 'r') as f:
            config = json.load(f)
        return config
    except Exception as e:
        print("ERROR|Failed to load config: {}".format(str(e)), file=sys.stderr)
        _log("Failed to load config: {}".format(str(e)), level="ERROR")
        sys.exit(1)

def validate_paths(source_folder, target_folder, config_file, local_storage_path=None):
    """Validate all required paths exist."""
    errors = []
    
    if not os.path.exists(source_folder):
        errors.append("Source folder does not exist: {}".format(source_folder))
    
    if not os.path.exists(target_folder):
        errors.append("Target folder does not exist: {}".format(target_folder))
    
    if not os.path.exists(config_file):
        errors.append("Config file does not exist: {}".format(config_file))
    
    if local_storage_path and not os.path.exists(local_storage_path):
        # Local storage path is optional - just warn
        print("[WARNING] Local storage path does not exist: {}".format(local_storage_path), file=sys.stderr)
        _log("Local storage path does not exist: {}".format(local_storage_path), level="WARNING")
    
    if errors:
        _set_csv_context(
            'validating_paths',
            source_folder=source_folder,
            target_folder=target_folder,
            config_file=config_file,
            local_storage_path=local_storage_path or ''
        )
        _csv_event('path_validation_failed', level='ERROR', errors=errors)
        for error in errors:
            print("ERROR|{}".format(error), file=sys.stderr)
            _log(error, level="ERROR")
        sys.exit(1)

def move_csvs_from_storage(local_storage_path, source_folder, silent=False):
    """Move CSV files from local_storage_path to source_folder."""
    if not local_storage_path or not os.path.exists(local_storage_path):
        _log_step("Local storage path {} does not exist - skipping initial scan".format(local_storage_path))
        return 0
    
    # Scan for both CSV and DOCX files to provide better visibility in logs
    csv_pattern = os.path.join(local_storage_path, "*.csv")
    docx_pattern = os.path.join(local_storage_path, "*.docx")
    
    csv_files = glob.glob(csv_pattern)
    docx_files = glob.glob(docx_pattern)
    
    total_detected = len(csv_files) + len(docx_files)
    
    if not silent:
        print("Scanning local storage: {}".format(local_storage_path))
    
    _log_step("Local storage scan: Found {} file(s) ({} CSV, {} DOCX) in {}".format(
        total_detected, len(csv_files), len(docx_files), local_storage_path))
    
    if not csv_files:
        _log_step("No CSV files found in local storage to move")
        return 0
    
    if not silent:
        print("Moving {} new CSV file(s) to source folder...".format(len(csv_files)))
    
    moved_count = 0
    for csv_file in csv_files:
        try:
            if not os.path.exists(csv_file):
                print("[WARNING] Source CSV does not exist: {}".format(os.path.abspath(csv_file)), file=sys.stderr)
                _log("Source CSV does not exist: {}".format(os.path.abspath(csv_file)), level="WARNING")
                continue
            filename = os.path.basename(csv_file)
            dest_path = os.path.join(source_folder, filename)
            
            if not silent:
                print("  -> Moving {} ...".format(filename))
            
            shutil.move(csv_file, dest_path)
            moved_count += 1
            _log_step("Moved CSV from local storage to source: {}".format(filename))
        except Exception as e:
            print("[WARNING] Failed to move CSV file {}: {}".format(csv_file, str(e)), file=sys.stderr)
            _log("Failed to move CSV file {}: {}".format(csv_file, str(e)), level="WARNING")
    
    _log_step("Successfully moved {} CSV file(s) from local storage to {}".format(moved_count, source_folder))
    return moved_count

def find_latest_csv(source_folder):
    """Find most recent CSV file by modification time. Returns (filename, filepath) or (None, None).
    Searches source_folder top-level (browser downloads to MediCare root)."""
    csv_pattern = os.path.join(source_folder, "*.csv")
    csv_files = glob.glob(csv_pattern)
    
    if not csv_files:
        return (None, None)
    
    # Find most recent by modification time
    latest_file = max(csv_files, key=os.path.getmtime)
    filename = os.path.basename(latest_file)
    
    return (filename, latest_file)

def compare_csv_with_config(latest_csv_path, config_file, target_folder, silent=False):
    """Compare latest CSV with config. Prompt to update if different (non-silent)."""
    if not HAS_UPDATE_JSON:
        return False
    
    try:
        current_csv_path = get_current_csv_path(config_file)
        if not current_csv_path:
            # No CSV path in config yet
            return False
        
        # Compare filenames only (not full paths)
        current_csv_name = os.path.basename(current_csv_path)
        latest_csv_name = os.path.basename(latest_csv_path)
        
        if current_csv_name == latest_csv_name:
            return False  # Same file, no update needed
        
        # Different CSV - prompt user (non-silent mode only)
        if not silent:
            print("Current CSV: {}".format(current_csv_name))
            print("Latest CSV: {}".format(latest_csv_name))
            
            while True:
                update_choice = input("Update config to latest CSV? (Y/N): ").strip().upper()
                if update_choice in ('Y', 'N'):
                    break
                print("Please enter Y or N")
            
            if update_choice == 'Y':
                # Update config with path to latest CSV in target folder (before rename)
                latest_csv_in_target = os.path.join(target_folder, latest_csv_name)
                update_csv_path(config_file, latest_csv_in_target)
                _log_step("Updated config to latest CSV: {}".format(latest_csv_name))
                return True
        
        return False
    except Exception as e:
        print("[WARNING] Failed to compare CSV with config: {}".format(str(e)), file=sys.stderr)
        _log("Failed to compare CSV with config: {}".format(str(e)), level="WARNING")
        return False

def move_and_rename_csv(source_path, target_folder, timestamp=None):
    """Move CSV to target folder with timestamp rename. Returns (new_path, original_filename)."""
    if not os.path.exists(source_path):
        abs_path = os.path.abspath(source_path)
        _log("move_and_rename_csv: source file not found: {}".format(abs_path), level="WARNING")
        raise FileNotFoundError("Source CSV not found: {}".format(abs_path))
    if timestamp is None:
        # Include microseconds so back-to-back intakes in the same clock second get unique names.
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    
    original_filename = os.path.basename(source_path)
    new_filename = "SX_CSV_{}.csv".format(timestamp)
    new_path = os.path.join(target_folder, new_filename)
    
    shutil.move(source_path, new_path)
    
    return (new_path, original_filename)

def _load_fresh_config_for_cache(config_file):
    """Load fresh config via MediCafe centralized loader for build_cache.
    Clears cache and reloads from disk to avoid stale CSV_FILE_PATH."""
    if not HAS_CONFIG_LOADER:
        return load_config(config_file)
    try:
        clear_config_cache()
        crosswalk_path = os.path.join(os.path.dirname(config_file), 'crosswalk.json')
        config, _ = load_configuration(config_path=config_file, crosswalk_path=crosswalk_path)
        return config
    except Exception as e:
        _log("Failed to load fresh config for cache build ({}); falling back to direct load".format(e), level="WARNING")
        return load_config(config_file)


def build_cache(config, silent=False):
    """Build deductible cache from config."""
    if not HAS_BUILD_CACHE:
        if not silent:
            print("[WARNING] Deductible cache builder not available")
        _log("Deductible cache builder not available", level="WARNING")
        return 0
    
    if not silent:
        print("Building deductible cache (silent)...")
    _log_step("Building deductible cache")
    _log_step("build_cache invoked (caller: CSV processor or launcher)")
    
    try:
        # Call build_deductible_cache directly
        # verbose=False to suppress output (silent mode)
        result = build_deductible_cache(config=config, verbose=False, skip_internet_check=False, submit_error_report=True)
        if result == 0:
            _log("Deductible cache build completed successfully", level="INFO")
        else:
            _log("Deductible cache builder reported an error (see logs for details)", level="WARNING")
        return result
    except Exception as e:
        print("[WARNING] Deductible cache builder error: {}".format(str(e)), file=sys.stderr)
        _log("Deductible cache builder error: {}".format(str(e)), level="WARNING")
        return 1

def process_csv(source_folder, target_folder, config_file, local_storage_path=None, python_script=None, silent=False):
    """Main processing function - orchestrates all CSV operations."""
    _set_csv_context(
        'starting',
        source_folder=source_folder,
        target_folder=target_folder,
        config_file=config_file,
        local_storage_path=local_storage_path or '',
        silent=bool(silent),
        iteration=0,
        latest_csv_name='',
        latest_csv_path='',
        new_csv_path='',
        moved_from_storage=0,
        cache_result=None
    )
    _log_step("Starting CSV processing workflow")
    _log_step("Configuration: Source={}, Target={}, Config={}".format(source_folder, target_folder, config_file))
    _csv_event('start', level='INFO')
    
    # Validate paths
    _set_csv_context('validating_paths')
    validate_paths(source_folder, target_folder, config_file, local_storage_path)
    _csv_event('paths_validated', level='INFO')
    
    # Move CSVs from local storage to source folder
    if local_storage_path:
        _set_csv_context('moving_csvs_from_local_storage')
        _log_step("Checking for new files in local storage: {}".format(local_storage_path))
        moved_count = move_csvs_from_storage(local_storage_path, source_folder, silent=silent)
        _set_csv_context(moved_from_storage=moved_count)
        if moved_count > 0:
            _log_step("Discovered and moved {} new CSV file(s) for processing".format(moved_count))
        _csv_event('local_storage_scan_complete', level='INFO')
    
    # Load config for later use
    _set_csv_context('loading_config')
    config = load_config(config_file)
    _csv_event(
        'config_loaded',
        level='INFO',
        csv_file_path=config.get('CSV_FILE_PATH', '') if isinstance(config, dict) else ''
    )

    intake_started_at = int(time.time())
    local_index_root = _get_index_local_storage_abs(config, local_storage_path)
    index_path_for_cold = _get_intake_index_path(local_index_root)
    cold_start_index = not os.path.exists(index_path_for_cold)
    index_data = _load_csv_intake_index(local_index_root)
    downloaded_names = _load_downloaded_emails_names(local_index_root)
    _merge_downloaded_tracker_into_index(index_data, downloaded_names, intake_started_at)
    _reconcile_intake_index_entries(index_data, source_folder, target_folder)
    _csv_event(
        'index_loaded',
        level='INFO',
        intake_index_path=_get_intake_index_path(local_index_root),
        intake_status_path=_get_intake_status_path(local_index_root),
        downloaded_tracker_count=len(downloaded_names),
        entries_count=len(index_data.get('entries', {})),
    )
    _save_csv_intake_status(local_index_root, {
        'source': 'process_csvs',
        'started_at': intake_started_at,
        'completed_at': None,
        'phase': 'started',
        'requested_downloaded_count': len(downloaded_names),
        'stats': _compute_intake_index_stats(index_data, downloaded_names),
    })

    # Process all CSVs in source folder (loop until none remain)
    MAX_CSV_ITERATIONS = 20  # Guard against runaway if something leaves files in place
    iteration = 0
    
    while iteration < MAX_CSV_ITERATIONS:
        iteration += 1
        _set_csv_context('finding_latest_csv', iteration=iteration)
        latest_csv_name, latest_csv_path = find_latest_csv(source_folder)
        _set_csv_context(latest_csv_name=latest_csv_name or '', latest_csv_path=latest_csv_path or '')
        
        if not latest_csv_name:
            if iteration == 1:
                # No CSV files found - skip processing but build cache
                if not silent:
                    print("No CSV files found in {}. This is normal when only DOCX files were received from the email download.".format(source_folder))
                    print("Skipping CSV processing, but will build deductible cache using latest known CSV from config.")
                _log("No CSV files found in source folder {} - skipping CSV specific redistribution".format(source_folder), level="INFO")
                _csv_event('no_csv_found_building_cache_from_config', level='INFO')
                
                # Build cache anyway (using latest known CSV from config) - reload config for fresh CSV_FILE_PATH
                _set_csv_context('loading_config_for_existing_cache_build')
                _log_step("Triggering deductible cache build using existing config CSV path")
                fresh_config = _load_fresh_config_for_cache(config_file)
                _set_csv_context('building_cache_from_existing_config')
                cache_result = build_cache(fresh_config, silent=silent)
                _set_csv_context(cache_result=cache_result)
                _csv_event(
                    'cache_build_complete',
                    level='INFO' if cache_result == 0 else 'WARNING',
                    cache_result=cache_result,
                    csv_file_path=fresh_config.get('CSV_FILE_PATH', '') if isinstance(fresh_config, dict) else ''
                )
            break
        
        _log_step("Identified latest CSV for processing: {}".format(latest_csv_name))
        _csv_event('latest_csv_selected', level='INFO')
        
        if not silent:
            print("Validating latest CSV with config file...")
        
        # Compare with config and prompt if different (non-silent mode)
        _set_csv_context('comparing_csv_with_config')
        compare_csv_with_config(latest_csv_path, config_file, target_folder, silent=silent)
        
        # Store original filename before timestamp rename
        original_csv_filename = latest_csv_name
        
        # Move and rename CSV with timestamp (seconds to avoid collisions in straggler loop)
        _set_csv_context('moving_and_renaming_csv')
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        new_csv_path, _ = move_and_rename_csv(latest_csv_path, target_folder, timestamp=timestamp)
        new_filename = os.path.basename(new_csv_path)
        _set_csv_context(new_csv_path=new_csv_path)
        
        if not silent:
            print("Processing CSV...")
        
        _log_step("Moved and renamed CSV: {} -> {} (in target folder)".format(original_csv_filename, new_filename))
        _csv_event(
            'csv_moved_to_target',
            level='INFO',
            original_csv_filename=original_csv_filename,
            new_csv_filename=new_filename
        )

        _record_csv_intake_mapping(
            index_data,
            local_index_root,
            original_csv_filename,
            latest_csv_path,
            new_csv_path,
            iteration,
        )

        # Update config with new CSV path
        if HAS_UPDATE_JSON:
            try:
                _set_csv_context('updating_config_csv_path')
                update_csv_path(config_file, new_csv_path)
                _log_step("Successfully updated config.json with new CSV path: {}".format(new_csv_path))
                _csv_event('config_csv_path_updated', level='INFO')
            except Exception as e:
                print("[WARNING] Failed to update config with new CSV path: {}".format(str(e)), file=sys.stderr)
                _log("Failed to update config with new CSV path: {}".format(str(e)), level="WARNING")
                _csv_event(
                    'config_csv_path_update_failed',
                    level='WARNING',
                    exception_type=e.__class__.__name__,
                    exception_message=str(e)
                )
        
        # Update downloaded_emails.txt with original filename (before timestamp rename)
        if HAS_ADD_DOWNLOADED_EMAIL:
            # Verify file exists at destination before updating
            if os.path.exists(new_csv_path):
                try:
                    _set_csv_context('updating_processed_tracker')
                    _log_step("Adding original filename to processed tracker: {}".format(original_csv_filename))
                    success = add_downloaded_email(original_csv_filename, config=config, log_fn=None)
                    if success:
                        _log_step("Updated downloaded_emails.txt successfully for: {}".format(original_csv_filename))
                        _csv_event('processed_tracker_updated', level='INFO', original_csv_filename=original_csv_filename)
                    else:
                        if not silent:
                            print("[WARNING] Failed to update downloaded_emails.txt for {}".format(original_csv_filename), file=sys.stderr)
                        _log("Failed to update downloaded_emails.txt for {}".format(original_csv_filename), level="WARNING")
                        _csv_event('processed_tracker_update_failed', level='WARNING', original_csv_filename=original_csv_filename)
                except Exception as e:
                    if not silent:
                        print("[WARNING] Error updating downloaded_emails.txt for {}: {}".format(original_csv_filename, str(e)), file=sys.stderr)
                    _log("Error updating downloaded_emails.txt for {}: {}".format(original_csv_filename, str(e)), level="WARNING")
                    _csv_event(
                        'processed_tracker_update_exception',
                        level='WARNING',
                        original_csv_filename=original_csv_filename,
                        exception_type=e.__class__.__name__,
                        exception_message=str(e)
                    )
        
        # Build deductible cache - reload config for fresh CSV_FILE_PATH after update_csv_path
        _set_csv_context('loading_config_for_cache_build')
        _log_step("Initiating deductible cache build step")
        fresh_config = _load_fresh_config_for_cache(config_file)
        _set_csv_context('building_cache_after_csv_move')
        cache_result = build_cache(fresh_config, silent=silent)
        _set_csv_context(cache_result=cache_result)
        _csv_event(
            'cache_build_complete',
            level='INFO' if cache_result == 0 else 'WARNING',
            cache_result=cache_result,
            csv_file_path=fresh_config.get('CSV_FILE_PATH', '') if isinstance(fresh_config, dict) else ''
        )
    
    if iteration >= MAX_CSV_ITERATIONS:
        _log("Reached max CSV iterations ({}); stopping to avoid runaway".format(MAX_CSV_ITERATIONS), level="WARNING")
        _csv_event('max_iterations_reached', level='WARNING')
    
    # Check for straggler files in source folder (CSV stragglers should be empty after loop)
    _set_csv_context('checking_stragglers')
    _log_stragglers(source_folder)

    _set_csv_context('pre_finalize_heuristic')
    apply_sx_heuristic_backfill(
        index_data,
        source_folder,
        target_folder,
        local_index_root,
        persist=False,
        quiet=silent,
        cold_start=cold_start_index,
    )

    downloaded_names = _load_downloaded_emails_names(local_index_root)

    _finalize_csv_intake_index(
        index_data,
        local_index_root,
        source_folder,
        target_folder,
        downloaded_names,
        intake_started_at,
        silent,
    )

    if not silent:
        print("CSV Processor Complete.")
    
    _set_csv_context('complete')
    _csv_event('complete', level='INFO')
    _log("CSV processing workflow completed successfully", level="INFO")
    return 0

def _log_stragglers(source_folder):
    """Scan source folder for any remaining CSV or DOCX files and log a WARNING."""
    csv_stragglers = glob.glob(os.path.join(source_folder, "*.csv"))
    docx_stragglers = glob.glob(os.path.join(source_folder, "*.docx"))
    
    total = len(csv_stragglers) + len(docx_stragglers)
    if total > 0:
        msg = "STRAGGLERS DETECTED in working folder {}: Found {} file(s) ({} CSV, {} DOCX) that were not processed or moved.".format(
            source_folder, total, len(csv_stragglers), len(docx_stragglers))
        _log(msg, level="WARNING")
        _log("Run Force CSV intake again to process remaining files, or move them manually.", level="INFO")
        
        # Log individual stragglers for easier cleanup
        for f in csv_stragglers + docx_stragglers:
            _log_step("Straggler file: {}".format(os.path.basename(f)))

def main():
    parser = argparse.ArgumentParser(description='MediBot CSV Processor')
    parser.add_argument('--config', required=True, help='Path to config.json')
    parser.add_argument('--source-folder', required=True, help='Source folder to scan for CSV files')
    parser.add_argument('--target-folder', required=True, help='Target folder for processed CSV files')
    parser.add_argument('--local-storage-path', help='Local storage path for CSV files (optional)')
    parser.add_argument('--python-script', help='Path to update_json.py (optional, for backward compat - not used)')
    parser.add_argument('--silent', action='store_true', help='Suppress non-error output')
    
    args = parser.parse_args()
    
    # Resolve paths to absolute
    config_file = os.path.abspath(os.path.expanduser(args.config))
    source_folder = os.path.abspath(os.path.expanduser(args.source_folder))
    target_folder = os.path.abspath(os.path.expanduser(args.target_folder))
    local_storage_path = None
    if args.local_storage_path:
        local_storage_path = os.path.abspath(os.path.expanduser(args.local_storage_path))
    
    # Run processing
    try:
        return process_csv(
            source_folder=source_folder,
            target_folder=target_folder,
            config_file=config_file,
            local_storage_path=local_storage_path,
            python_script=args.python_script,  # Not used in Python version, but kept for compat
            silent=args.silent
        )
    except KeyboardInterrupt:
        print("\n[INFO] CSV processing interrupted by user", file=sys.stderr)
        _log("CSV processing interrupted by user", level="INFO")
        _csv_event('interrupted', level='WARNING')
        return 1
    except Exception as e:
        print("ERROR|CSV processing failed: {}".format(str(e)), file=sys.stderr)
        _csv_event(
            'failed',
            level='ERROR',
            exception_type=e.__class__.__name__,
            exception_message=str(e)
        )
        _log("CSV processing failed: {}".format(str(e)), level="ERROR")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == '__main__':
    sys.exit(main())