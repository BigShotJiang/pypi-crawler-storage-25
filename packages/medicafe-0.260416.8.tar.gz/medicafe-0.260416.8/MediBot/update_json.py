# update_json.py
import json
import sys
import os
from collections import OrderedDict

try:
    from MediCafe.json_io import load_json_file, write_json_atomic
except ImportError:
    load_json_file = None
    write_json_atomic = None

def _debug_config_write_enabled():
    v = str(os.environ.get('MEDICAFE_DEBUG_CONFIG_WRITE', '') or '').strip().lower()
    return v in ('1', 'true', 'yes', 'y', 'on')


def _debug_config_write(phase, path):
    """stderr line for correlating overlapping config writers (set MEDICAFE_DEBUG_CONFIG_WRITE=1)."""
    if not _debug_config_write_enabled():
        return
    try:
        print(
            "[CONFIG_WRITE] pid={0} script=update_json phase={1} path={2}".format(
                os.getpid(), phase, path
            ),
            file=sys.stderr,
        )
    except Exception:
        pass


def _notify_write_failure(json_file, phase, exc=None):
    try:
        from MediCafe.config_write_telemetry import record_json_write_failure

        record_json_write_failure('update_json', json_file, phase, exc=exc)
    except Exception:
        pass


def get_current_csv_path(json_file):
    try:
        if load_json_file is not None:
            try:
                data = load_json_file(json_file, object_pairs=True)
            except ValueError as decode_err:
                print("Error decoding JSON file '{}': {}".format(json_file, decode_err))
                _notify_write_failure(json_file, 'json_decode_read', decode_err)
                sys.exit(1)
            if not isinstance(data, dict):
                print("Error: '{}' does not contain a JSON object".format(json_file))
                _notify_write_failure(json_file, 'json_decode_read', None)
                sys.exit(1)
            return data.get('CSV_FILE_PATH', None)
        with open(json_file, 'r', encoding='utf-8') as file:
            try:
                data = json.load(file, object_pairs_hook=OrderedDict)
                return data.get('CSV_FILE_PATH', None)
            except ValueError as decode_err:
                print("Error decoding JSON file '{}': {}".format(json_file, decode_err))
                _notify_write_failure(json_file, 'json_decode_read', decode_err)
                sys.exit(1)
    except IOError as io_err:
        print("Error accessing file '{}': {}".format(json_file, io_err))
        _notify_write_failure(json_file, 'io_read', io_err)
        sys.exit(1)
    except Exception as e:
        print("An unexpected error occurred: {}".format(e))
        _notify_write_failure(json_file, 'unexpected_read', e)
        sys.exit(1)
    return None

def normalize_path_for_json(path):
    """
    Normalize a file path for JSON storage, ensuring proper backslash escaping.
    This function prevents double-processing and ensures consistent formatting.
    """
    if not path:
        return path
    
    # First, normalize the path using os.path to handle any existing issues
    normalized_path = os.path.normpath(path)
    
    # Check if the path is already properly formatted for JSON (contains \\\\)
    # We look for the pattern where backslashes are already escaped
    if "\\\\" in normalized_path:
        # Path is already JSON-formatted, return as-is
        return normalized_path
    
    # Check if the path contains single backslashes that need escaping
    if "\\" in normalized_path:
        # Escape single backslashes for JSON
        formatted_path = normalized_path.replace("\\", "\\\\")
        return formatted_path
    
    # No backslashes found, return as-is
    return normalized_path

def update_csv_path(json_file, new_path):
    _debug_config_write('update_csv_path_begin', json_file)
    try:
        _debug_config_write('open_read', json_file)
        if load_json_file is not None:
            try:
                data = load_json_file(json_file, object_pairs=True)
            except ValueError as decode_err:
                print("Error decoding JSON file '{}': {}".format(json_file, decode_err))
                _notify_write_failure(json_file, 'json_decode_before_write', decode_err)
                sys.exit(1)
        else:
            with open(json_file, 'r', encoding='utf-8') as file:
                try:
                    data = json.load(file, object_pairs_hook=OrderedDict)
                except ValueError as decode_err:
                    print("Error decoding JSON file '{}': {}".format(json_file, decode_err))
                    _notify_write_failure(json_file, 'json_decode_before_write', decode_err)
                    sys.exit(1)
        if not isinstance(data, dict):
            print("Error decoding JSON file '{}': not an object".format(json_file))
            _notify_write_failure(json_file, 'json_decode_before_write', None)
            sys.exit(1)

        # Use the improved path normalization function
        formatted_path = normalize_path_for_json(new_path)
        
        # Validate that the path doesn't have excessive slashes
        if formatted_path.count("\\\\") > formatted_path.count("\\") * 2:
            print("Warning: Path may have excessive backslashes. Original: {}, Formatted: {}".format(
                new_path, formatted_path))
        
        data['CSV_FILE_PATH'] = formatted_path

        _debug_config_write('atomic_write_begin', json_file)
        if write_json_atomic is not None:
            try:
                json.dumps(data, ensure_ascii=False)
            except (ValueError, TypeError) as encode_err:
                print("Error encoding JSON data to file '{}': {}".format(json_file, encode_err))
                _notify_write_failure(json_file, 'json_encode_write', encode_err)
                sys.exit(1)
            if not write_json_atomic(
                    json_file,
                    data,
                    'config',
                    'update_json',
                    indent=4,
                    sort_keys=False,
                    lock=True,
                    ensure_ascii=False,
            ):
                print(
                    "Error writing file '{}': atomic config write failed "
                    "(see JSON_IO_EVENT / CONFIG_WRITE_FAILURE diagnostics).".format(json_file)
                )
                sys.exit(1)
        else:
            _debug_config_write('open_write', json_file)
            with open(json_file, 'w', encoding='utf-8') as file:
                try:
                    json.dump(data, file, ensure_ascii=False, indent=4)
                except ValueError as encode_err:
                    print("Error encoding JSON data to file '{}': {}".format(json_file, encode_err))
                    _notify_write_failure(json_file, 'json_encode_write', encode_err)
                    sys.exit(1)
        _debug_config_write('update_csv_path_done', json_file)

    except IOError as io_err:
        print("Error accessing file '{}': {}".format(json_file, io_err))
        phase = 'io_read' if 'read' in str(io_err).lower() else 'io_write'
        _notify_write_failure(json_file, phase, io_err)
        sys.exit(1)
    except Exception as e:
        print("An unexpected error occurred: {}".format(e))
        _notify_write_failure(json_file, 'unexpected_update_csv_path', e)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) == 3:
        json_path = sys.argv[1]
        new_csv_path = sys.argv[2]
        update_csv_path(json_path, new_csv_path)
    elif len(sys.argv) == 2:
        json_path = sys.argv[1]
        current_csv_path = get_current_csv_path(json_path)
        if current_csv_path:
            print(current_csv_path)
        else:
            print("No CSV path found in config.")
    else:
        print("Usage: update_json.py <path_to_json_file> [<new_csv_path>]")
        sys.exit(1)