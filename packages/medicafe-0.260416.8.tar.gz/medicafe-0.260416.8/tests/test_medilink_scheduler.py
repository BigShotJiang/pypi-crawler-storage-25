#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
import tempfile
import unittest
try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
if MEDILINK_ROOT not in sys.path:
    sys.path.insert(0, MEDILINK_ROOT)

import MediLink_Scheduler as sched  # noqa: E402


class TestNormalizeDos(unittest.TestCase):
    def test_mm_dd_yyyy(self):
        self.assertEqual(sched.normalize_dos_yyyymmdd("06-15-2025"), "20250615")

    def test_yyyymmdd_passthrough(self):
        self.assertEqual(sched.normalize_dos_yyyymmdd("20250615"), "20250615")


class TestBillingCache(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.mkdtemp()
        self.cfg = {"CSV_FILE_PATH": os.path.join(self._td, "batch.csv")}

    def tearDown(self):
        try:
            for name in os.listdir(self._td):
                os.remove(os.path.join(self._td, name))
            os.rmdir(self._td)
        except Exception:
            pass

    def test_record_and_query_claim_submitted(self):
        root = sched.load_billing_status(self.cfg)
        self.assertEqual(root.get("by_patient"), {})
        sched.merge_dos_update(self.cfg, "12345", "20250601", charges_entered=True)
        sched.record_claim_submitted_for_patients(
            self.cfg,
            [
                {
                    "patid": "12345",
                    "surgery_date_iso": "2025-06-01",
                }
            ],
        )
        root = sched.load_billing_status(self.cfg)
        rec = sched.get_dos_record(root, "12345", "20250601")
        self.assertTrue(rec.get("charges_entered"))
        self.assertTrue(rec.get("claim_submitted"))

    def test_existing_row_needs_work_until_claim(self):
        row = {
            "_all_surgery_dates": ["06-01-2025"],
        }
        rev = {"Patient ID #2": "Patient ID #2"}
        row["Patient ID #2"] = "99999"
        root = sched.load_billing_status(self.cfg)
        self.assertTrue(sched.existing_row_needs_charge_or_claim_work(root, row, rev))
        sched.record_claim_submitted_for_patients(
            self.cfg,
            [{"patid": "99999", "surgery_date_iso": "2025-06-01"}],
        )
        root = sched.load_billing_status(self.cfg)
        self.assertFalse(sched.existing_row_needs_charge_or_claim_work(root, row, rev))


class TestClaimStatusNormalize(unittest.TestCase):
    def test_no_data(self):
        MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
        if MEDILINK_ROOT not in sys.path:
            sys.path.insert(0, MEDILINK_ROOT)
        from MediLink_ClaimStatus import normalize_claim_status_display

        c, m = normalize_claim_status_display("No data found with given request parameters")
        self.assertEqual(c, "no_data")


class TestClaimStatusIndexHealthNotice(unittest.TestCase):
    def test_claim_status_health_notice_uses_shared_builder_once(self):
        MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
        if MEDILINK_ROOT not in sys.path:
            sys.path.insert(0, MEDILINK_ROOT)
        import MediLink_ClaimStatus as claim_status

        notice_state = {'shown': False}
        health = {'invalid_lines': 2, 'total_lines': 10}
        with patch('builtins.print') as print_mock:
            with patch.object(claim_status.MediLink_ConfigLoader, 'log') as log_mock:
                first = claim_status._maybe_notify_submission_index_health(health, notice_state)
                second = claim_status._maybe_notify_submission_index_health(health, notice_state)
        self.assertTrue(first)
        self.assertFalse(second)
        self.assertEqual(print_mock.call_count, 1)
        self.assertEqual(log_mock.call_count, 1)


if __name__ == "__main__":
    unittest.main()
