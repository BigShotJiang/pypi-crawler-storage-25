from __future__ import print_function

import json
import os
import sys
import unittest

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediCafe import deductible_utils
from MediLink import MediLink_Deductible_v1_5 as deductible_v15


def _parse_prefixed_json(message, prefix):
    idx = message.find(prefix)
    if idx < 0:
        return None
    return json.loads(message[idx + len(prefix):])


class _CaptureLogger(object):
    def __init__(self):
        self.records = []

    def log(self, message, config=None, level='INFO', error_type=None, claim=None, verbose=False, console_output=False):
        self.records.append((level, message))


class DeductibleCsvDiagnosticsTests(unittest.TestCase):
    def test_payer_resolution_reports_lowercase_phase_d_shape(self):
        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
            {
                'category': 'denial',
                'patient_id': 'PAT-2',
                'Surgery Date': '04/10/2026',
                'payer_id': '87726',
                'claim_key': 'ck2',
                'claim_number': 'cn2',
                'detail': 'y',
                'next_action': 'review',
            },
        ]
        capture = _CaptureLogger()
        original_logger = deductible_utils.MediLink_ConfigLoader
        try:
            deductible_utils.MediLink_ConfigLoader = capture
            result = deductible_utils.resolve_payer_ids_from_csv(rows, {}, {}, None)
        finally:
            deductible_utils.MediLink_ConfigLoader = original_logger

        self.assertEqual(result, {})
        payloads = [
            _parse_prefixed_json(message, 'CSV_PAYER_RESOLUTION_TELEMETRY ')
            for level, message in capture.records
            if message.startswith('CSV_PAYER_RESOLUTION_TELEMETRY ')
        ]
        self.assertEqual(len(payloads), 1)
        payload = payloads[0]
        self.assertEqual(payload.get('row_count'), 2)
        self.assertEqual(payload.get('resolved_count'), 0)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_payer_id'), 2)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_dob'), 2)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_member_id'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('payer', {}).get('payer_id'), 2)
        self.assertTrue(any(item.get('value') == 'denial' and item.get('count') == 2 for item in payload.get('category_values', [])))
        self.assertTrue(any(level == 'WARNING' and 'produced 0 mappings' in message for level, message in capture.records))

    def test_patient_tuple_diagnostics_reports_required_field_drop_reasons(self):
        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
            {
                'category': 'appeal',
                'patient_id': 'PAT-2',
                'Surgery Date': '04/10/2026',
                'payer_id': '62308',
                'claim_key': 'ck2',
                'claim_number': 'cn2',
                'detail': 'y',
                'next_action': 'hold',
            },
        ]
        records = []
        original_log = deductible_v15._log
        try:
            deductible_v15._log = lambda message, level='INFO': records.append((level, message))
            deductible_v15._emit_patient_tuple_build_diagnostics(
                rows,
                0,
                {
                    'missing_patient_id': 2,
                    'missing_dob': 2,
                    'missing_member_id': 2,
                    'invalid_dob': 0,
                    'row_exception': 0,
                },
            )
        finally:
            deductible_v15._log = original_log

        payloads = [
            _parse_prefixed_json(message, 'DEDUCTIBLE_CACHE_CSV_TELEMETRY ')
            for level, message in records
            if message.startswith('DEDUCTIBLE_CACHE_CSV_TELEMETRY ')
        ]
        self.assertEqual(len(payloads), 1)
        payload = payloads[0]
        self.assertEqual(payload.get('row_count'), 2)
        self.assertEqual(payload.get('patient_tuple_count'), 0)
        self.assertEqual(payload.get('drop_counts', {}).get('missing_dob'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('patient_id', {}).get('patient_id'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('payer', {}).get('payer_id'), 2)
        self.assertEqual(payload.get('column_nonempty_counts', {}).get('Surgery Date'), 2)
        self.assertTrue(any(level == 'WARNING' and 'produced 0 patient tuples' in message for level, message in records))


if __name__ == '__main__':
    unittest.main()