import os

from MediCafe import error_reporter



def _raise_loader():
    raise RuntimeError('broken loader')



def _degraded_diagnostics():
    return {
        'overall_status': 'degraded',
        'summary_lines': ['config missing'],
        'defaults_in_use': {'config': True, 'crosswalk': True},
    }



def test_list_queued_bundles_uses_degraded_storage_root_when_loader_raises(monkeypatch, tmp_path):
    queue_dir = tmp_path / 'reports_queue'
    queue_dir.mkdir()
    bundle = queue_dir / 'bundle.zip'
    bundle.write_bytes(b'zip')

    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)

    queued = error_reporter.list_queued_bundles()

    assert str(bundle) in queued



def test_capture_unhandled_traceback_writes_to_degraded_storage_root(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)

    try:
        raise ValueError('boom')
    except ValueError:
        error_reporter.capture_unhandled_traceback(*__import__('sys').exc_info())

    trace_path = tmp_path / 'traceback.txt'
    assert trace_path.exists()
    content = trace_path.read_text(encoding='utf-8')
    assert 'ValueError' in content
    assert 'boom' in content



def test_delivery_readiness_surfaces_config_loader_degraded_state(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_BOOTSTRAP_LOG_DIR', str(tmp_path))
    monkeypatch.setattr(error_reporter, 'load_configuration', _raise_loader)
    monkeypatch.setattr(error_reporter, '_loader_get_last_load_diagnostics', _degraded_diagnostics)
    monkeypatch.setattr(error_reporter, 'list_queued_bundles', lambda: [])

    readiness = error_reporter.get_error_reporting_delivery_readiness(
        quiet_token=True,
        include_queue_paths=True,
        defer_token_probe_until_queue=True,
    )

    assert readiness['config_loader_status'] == 'degraded'
    assert 'config missing' in readiness['config_loader_summary']
    assert readiness['queued_bundle_count'] == 0
    assert readiness['recipient_count'] == 0
    assert readiness['token_probe_skipped_reason'] == 'queue_empty'
