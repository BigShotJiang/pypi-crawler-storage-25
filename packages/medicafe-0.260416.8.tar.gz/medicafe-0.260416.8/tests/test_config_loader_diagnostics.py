import json
import os

from MediCafe import MediLink_ConfigLoader as cfg_loader


def setup_function(_function):
    cfg_loader.clear_config_cache()
    os.environ.pop('MEDICAFE_CONFIG_FILE', None)
    os.environ.pop('MEDICAFE_CROSSWALK_FILE', None)


def teardown_function(_function):
    cfg_loader.clear_config_cache()
    os.environ.pop('MEDICAFE_CONFIG_FILE', None)
    os.environ.pop('MEDICAFE_CROSSWALK_FILE', None)


def _write_json(path, payload):
    with open(str(path), 'w', encoding='utf-8') as handle:
        json.dump(payload, handle)


def test_load_configuration_reports_missing_files_and_uses_defaults(tmp_path):
    config_path = tmp_path / 'missing_config.json'
    crosswalk_path = tmp_path / 'missing_crosswalk.json'

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['overall_status'] == 'degraded'
    assert diagnostics['config']['status'] == 'missing'
    assert diagnostics['crosswalk']['status'] == 'missing'
    assert diagnostics['defaults_in_use']['config'] is True
    assert diagnostics['defaults_in_use']['crosswalk'] is True
    assert 'MediLink_Config' in config
    assert 'payer_id' in crosswalk


def test_invalid_config_keeps_valid_crosswalk_and_records_syntax_issue(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        handle.write('{ invalid json')
    _write_json(crosswalk_path, {'payer_id': {'1': '87726'}})

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['overall_status'] == 'degraded'
    assert diagnostics['config']['status'] == 'invalid_syntax'
    assert diagnostics['defaults_in_use']['config'] is True
    assert diagnostics['defaults_in_use']['crosswalk'] is False
    assert crosswalk['payer_id']['1'] == '87726'
    assert 'MediLink_Config' in config


def test_invalid_utf8_config_reports_decode_error(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    with open(str(config_path), 'wb') as handle:
        handle.write(b'{"MediLink_Config": {"local_storage_path": "\x80"}}')
    _write_json(crosswalk_path, {'payer_id': {}})

    cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['config']['status'] == 'decode_error'
    assert diagnostics['defaults_in_use']['config'] is True


def test_missing_medilink_config_section_preserves_root_keys_and_injects_defaults(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'demo.csv'})
    _write_json(crosswalk_path, {'payer_id': {'2': '03432'}})

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['config']['status'] == 'missing_required_key'
    assert diagnostics['config']['fallback_scope'] == 'MediLink_Config_section'
    assert config['CSV_FILE_PATH'] == 'demo.csv'
    assert 'MediLink_Config' in config
    assert crosswalk['payer_id']['2'] == '03432'
