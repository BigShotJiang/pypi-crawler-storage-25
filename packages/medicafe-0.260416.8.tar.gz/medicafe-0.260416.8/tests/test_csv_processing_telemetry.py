from __future__ import print_function

import json
import os
import sys
import unittest

try:
    from unittest.mock import MagicMock, patch
except ImportError:
    from mock import MagicMock, patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class _FakeLogger(object):
    def __init__(self):
        self.records = []

    def log(self, message, level="INFO"):
        self.records.append((level, message))


class CsvProcessingTelemetryTests(unittest.TestCase):
    def test_csv_event_logs_stage_context_and_exception_fields(self):
        from MediBot import process_csvs

        old_logger = process_csvs.LOGGER
        old_stage = process_csvs.CSV_PROCESSING_STAGE
        old_context = dict(process_csvs.CSV_PROCESSING_CONTEXT)
        fake = _FakeLogger()
        try:
            process_csvs.LOGGER = fake
            process_csvs.CSV_PROCESSING_CONTEXT = {}
            process_csvs._set_csv_context(
                'moving_and_renaming_csv',
                source_folder='source',
                target_folder='target',
                latest_csv_name='daily.csv'
            )
            process_csvs._csv_event(
                'failed',
                level='ERROR',
                exception_type='ValueError',
                exception_message='boom'
            )
        finally:
            process_csvs.LOGGER = old_logger
            process_csvs.CSV_PROCESSING_STAGE = old_stage
            process_csvs.CSV_PROCESSING_CONTEXT = old_context

        self.assertEqual(len(fake.records), 1)
        level, message = fake.records[0]
        self.assertEqual(level, 'ERROR')
        self.assertTrue(message.startswith('CSV_PROCESSING_EVENT '))
        payload = json.loads(message.split(' ', 1)[1])
        self.assertEqual(payload.get('stage'), 'moving_and_renaming_csv')
        self.assertEqual(payload.get('event'), 'failed')
        self.assertEqual(payload.get('latest_csv_name'), 'daily.csv')
        self.assertEqual(payload.get('exception_type'), 'ValueError')

    def test_launcher_records_unfiltered_subprocess_output_tail(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig

        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        orch = MediCafeOrchestrator(session)
        recorded = []

        with patch.object(orch, '_record_notice', side_effect=lambda level, msg: recorded.append((level, msg))):
            orch._record_subprocess_output_tail(
                'CSV processing',
                'stderr',
                b'line1\nline2\nTraceback (most recent call last):\nValueError: boom\n',
                level='WARNING',
                max_lines=2
            )

        messages = [msg for _level, msg in recorded]
        self.assertTrue(any('earlier line(s) omitted' in msg for msg in messages))
        self.assertTrue(any('Traceback (most recent call last)' in msg for msg in messages))
        self.assertTrue(any('ValueError: boom' in msg for msg in messages))
        self.assertTrue(all(level == 'WARNING' for level, _msg in recorded))


if __name__ == '__main__':
    unittest.main()