# -*- coding: utf-8 -*-
"""Tests for support bundle build telemetry (meta.json + log line)."""
from __future__ import print_function

import json
import os
import shutil
import tempfile
import unittest
import zipfile

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

import MediCafe.MediLink_ConfigLoader as cfg_loader
import MediCafe.error_reporter as er
from MediCafe import bundle_build_telemetry as bbt


class TestBundleBuildTelemetryModule(unittest.TestCase):
    def tearDown(self):
        bbt.telemetry_session_reset()

    def test_finalize_includes_milestones_and_counts(self):
        bbt.telemetry_session_begin({'send_source': 'unit_test', 'system_health_pack': True})
        bbt.telemetry_record_milestone('stage_a')
        bbt.telemetry_record_milestone('stage_b')
        bbt.telemetry_merge_collect_counts(5, 500)
        bbt.telemetry_record_snapshot_build(1.25, 3, False)
        out = bbt.telemetry_finalize_for_meta('system_health_pack')
        self.assertEqual(out.get('schema_version'), 1)
        self.assertEqual(out.get('flow'), 'system_health_pack')
        self.assertEqual(out.get('send_source'), 'unit_test')
        self.assertTrue(out.get('total_build_sec', 0) >= 0)
        self.assertEqual(len(out.get('milestones') or []), 2)
        self.assertEqual((out.get('counts') or {}).get('extra_files'), 5)
        self.assertEqual((out.get('counts') or {}).get('max_log_lines'), 500)
        self.assertEqual(len(out.get('snapshot_events') or []), 1)
        line = bbt.format_bundle_telemetry_log_line(out)
        self.assertIn('BUNDLE_TELEMETRY', line)
        self.assertIn('schema=1', line)


class TestResolveBundleTelemetryLogLevel(unittest.TestCase):
    def tearDown(self):
        os.environ.pop('MEDICAFE_BUNDLE_TELEMETRY_INFO', None)

    def test_default_debug_fast_build(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 10.0}), 'DEBUG')

    def test_info_when_slow(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 50.0}), 'INFO')

    def test_info_when_env_set(self):
        os.environ['MEDICAFE_BUNDLE_TELEMETRY_INFO'] = '1'
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 0}), 'INFO')


class TestCollectSupportBundleTelemetry(unittest.TestCase):
    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None
        bbt.telemetry_session_reset()

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath
        bbt.telemetry_session_reset()

    def test_collect_support_bundle_meta_includes_bundle_build_telemetry(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_tel_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('TEL_MARKER\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            bbt.telemetry_session_begin({
                'send_source': 'test_collect',
                'system_health_pack': True,
            })
            bbt.telemetry_record_milestone('pre_zip_stage')
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={'system_health_pack': True, 'send_source': 'test_collect'},
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            tel = meta.get('bundle_build_telemetry')
            self.assertIsInstance(tel, dict)
            self.assertEqual(tel.get('schema_version'), 1)
            self.assertIn('milestones', tel)
            names = [m.get('name') for m in (tel.get('milestones') or []) if isinstance(m, dict)]
            self.assertIn('pre_zip_stage', names)
            self.assertIn('creating zip bundle', names)
            counts = tel.get('counts') or {}
            self.assertEqual(counts.get('extra_files'), 0)
            self.assertEqual(counts.get('max_log_lines'), 20)
        finally:
            shutil.rmtree(store, ignore_errors=True)
