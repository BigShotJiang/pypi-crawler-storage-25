#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
from unittest.mock import MagicMock, patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def test_telemetry_skipped_without_env_on_non_legacy_profile(monkeypatch, tmp_path):
    monkeypatch.delenv('MEDICAFE_CONFIG_WRITE_TELEMETRY', raising=False)
    with patch('MediCafe.config_write_telemetry.should_auto_enable_profile', return_value=False):
        from MediCafe.config_write_telemetry import record_json_write_failure, jsonl_path

        cfg = tmp_path / 'cfg.json'
        cfg.write_text('{}', encoding='utf-8')
        record_json_write_failure('test_writer', str(cfg), 'phase', errno=13, strerror='denied')
        assert not os.path.isfile(jsonl_path(str(cfg)))


def test_record_appends_jsonl_when_forced(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_CONFIG_WRITE_TELEMETRY', '1')
    from MediCafe import config_write_telemetry as cwt

    tel = tmp_path / 'tel'
    tel.mkdir()
    with patch.object(cwt, 'resolve_telemetry_dir', return_value=str(tel)):
        cfg = tmp_path / 'cfg.json'
        cfg.write_text('{}', encoding='utf-8')
        cwt.record_json_write_failure('unit', str(cfg), 'p', errno=13, strerror='eacces')

    jpath = os.path.join(str(tel), 'config_write_events.jsonl')
    assert os.path.isfile(jpath)
    lines = open(jpath, 'r', encoding='utf-8').read().strip().splitlines()
    assert len(lines) == 1
    row = json.loads(lines[0])
    assert row.get('errno') == 13
    assert row.get('writer') == 'unit'


def test_autosubmit_dedupes_within_cooldown(monkeypatch, tmp_path):
    monkeypatch.setenv('MEDICAFE_CONFIG_WRITE_TELEMETRY', '1')
    monkeypatch.setenv('MEDICAFE_CONFIG_WRITE_AUTOSUBMIT', '1')
    from MediCafe import config_write_telemetry as cwt

    tel = tmp_path / 'tel'
    tel.mkdir()
    zp = tmp_path / 'bundle.zip'
    zp.write_bytes(b'zip')

    event = {
        'path': str(tmp_path / 'cfg.json'),
        'errno': 13,
        'writer': 't',
        'phase': 'p',
        'utc_ts': '2000-01-01T00:00:00Z',
    }

    with patch.object(cwt, 'resolve_telemetry_dir', return_value=str(tel)):
        with patch('MediCafe.error_reporter.collect_support_bundle', return_value=str(zp)) as col:
            with patch('MediCafe.error_reporter.submit_support_bundle_email', return_value=True) as sub:
                with patch(
                    'MediCafe.error_reporter.maybe_resolve_queued_bundles_opportunistically'
                ) as mrq:
                    cwt.maybe_auto_submit_config_write_bundle(event)
                    cwt.maybe_auto_submit_config_write_bundle(dict(event))

    assert col.call_count == 1
    assert sub.call_count == 1
    assert mrq.call_count == 0
