# -*- coding: utf-8 -*-
"""Tests for support bundle_kind labeling (ZIP meta, email subject/body helpers)."""
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest
import zipfile

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from MediCafe import error_reporter as er
from MediCafe import MediLink_ConfigLoader as cfg_loader


class TestBundleKindResolution(unittest.TestCase):
    def test_resolve_explicit_override(self):
        self.assertEqual(
            er.resolve_bundle_kind({'bundle_kind': 'system_health_pack'}),
            'system_health_pack',
        )

    def test_resolve_run_evidence_flag(self):
        self.assertEqual(
            er.resolve_bundle_kind({'run_evidence_bundle': True}),
            'run_evidence_bundle',
        )

    def test_resolve_phase_d_evidence(self):
        self.assertEqual(
            er.resolve_bundle_kind({'phase_d_evidence': True}),
            'phase_d_evidence',
        )

    def test_resolve_phase_f_report_maps_to_phase_f_evidence(self):
        self.assertEqual(
            er.resolve_bundle_kind({'phase_f_report': True}),
            'phase_f_evidence',
        )

    def test_resolve_phase_e_failure_before_pipeline(self):
        meta = {'phase_e_failure': True, 'pipeline_failure': True}
        self.assertEqual(er.resolve_bundle_kind(meta), 'phase_e_pipeline_report')

    def test_resolve_claim_only(self):
        self.assertEqual(er.resolve_bundle_kind(None, claim_failure_summary=True), 'claim_submission_report')

    def test_default_error_report(self):
        self.assertEqual(er.resolve_bundle_kind(None), 'error_report')
        self.assertEqual(er.resolve_bundle_kind({}), 'error_report')

    def test_compose_subject_error_uses_prefix(self):
        s = er._compose_email_subject('error_report', 'MediCafe Error Report', '20250101_120000')
        self.assertIn('MediCafe Error Report', s)
        self.assertIn('20250101_120000', s)

    def test_compose_subject_health_strips_error_report_suffix(self):
        s = er._compose_email_subject('system_health_pack', 'MediCafe Error Report', '20250101_120000')
        self.assertIn('System Health Pack', s)
        self.assertNotIn('Error Report', s)
        self.assertIn('20250101_120000', s)

    def test_compose_subject_includes_run_id_and_send_source(self):
        s = er._compose_email_subject(
            'phase_f_evidence',
            'MediCafe Error Report',
            '20250101_120000',
            run_id='20260329-171213-1ccb1c51',
            send_source='manual_phase_f_evidence',
        )
        self.assertIn('run_id=20260329-171213-1ccb1c51', s)
        self.assertIn('source=manual_phase_f_evidence', s)

    def test_subject_context_from_meta_uses_extra_context_aliases(self):
        ctx = er._subject_context_from_meta_dict({
            'extra_context': {
                'artifact_run_id': '20260329-171213-1ccb1c51',
                'send_source': 'Manual Phase F Evidence',
            }
        })
        self.assertEqual(ctx.get('run_id'), '20260329-171213-1ccb1c51')
        self.assertEqual(ctx.get('send_source'), 'manual_phase_f_evidence')

    def test_read_subject_context_from_zip(self):
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            zpath = tmp.name
        try:
            with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({
                    'bundle_kind': 'phase_f_evidence',
                    'extra_context': {
                        'run_id': '20260329-171213-1ccb1c51',
                        'send_source': 'auto_phase_f_evidence',
                    },
                }))
            ctx = er._read_subject_context_from_zip(zpath)
            self.assertEqual(ctx.get('run_id'), '20260329-171213-1ccb1c51')
            self.assertEqual(ctx.get('send_source'), 'auto_phase_f_evidence')
        finally:
            try:
                os.remove(zpath)
            except OSError:
                pass

    def test_read_kind_from_zip(self):
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            zpath = tmp.name
        try:
            with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({'bundle_kind': 'phase_b_evidence'}))
            self.assertEqual(er._read_bundle_kind_from_zip(zpath), 'phase_b_evidence')
        finally:
            try:
                os.remove(zpath)
            except OSError:
                pass

    def test_repack_lite_from_zip_preserves_kind_and_drops_heavy_members(self):
        store = tempfile.mkdtemp()
        try:
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                rq = os.path.join(store, 'reports_queue')
                os.makedirs(rq)
                src = os.path.join(store, 'src.zip')
                big = 'x' * 5000
                with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as zf:
                    zf.writestr('meta.json', json.dumps({
                        'bundle_kind': 'system_health_pack',
                        'selected_log_archive_name': 'Log_04162026_run023.log',
                    }))
                    zf.writestr('evidence.txt', 'ok')
                    zf.writestr('Log_04162026_run023.log', big)
                    zf.writestr('traceback.txt', 'tb')
                out = er.repack_support_bundle_lite_from_zip(src)
                self.assertTrue(out and os.path.isfile(out))
                self.assertIn('system_health_pack', os.path.basename(out))
                with zipfile.ZipFile(out, 'r') as zf:
                    names = zf.namelist()
                    self.assertNotIn('Log_04162026_run023.log', names)
                    self.assertNotIn('traceback.txt', names)
                    self.assertIn('evidence.txt', names)
                    meta = json.loads(zf.read('meta.json').decode('utf-8'))
                    self.assertEqual(meta.get('bundle_kind'), 'system_health_pack')
                    self.assertTrue(meta.get('bundle_lite'))
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_merge_extra_meta_bundle_kind_from_zip(self):
        store = tempfile.mkdtemp()
        try:
            src = os.path.join(store, 'x.zip')
            with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({'bundle_kind': 'run_evidence_bundle'}))
            merged = er._merge_extra_meta_with_bundle_kind_from_zip(src, {})
            self.assertEqual(merged.get('bundle_kind'), 'run_evidence_bundle')
            merged2 = er._merge_extra_meta_with_bundle_kind_from_zip(src, {'bundle_kind': 'error_report'})
            self.assertEqual(merged2.get('bundle_kind'), 'error_report')
        finally:
            shutil.rmtree(store, ignore_errors=True)


class TestSupportBundleRunLogSelection(unittest.TestCase):
    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath

    def _write_log(self, path, marker):
        with open(path, 'w') as f:
            f.write(marker + '\n')

    def test_collect_support_bundle_prefers_current_run_log_and_records_meta(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            newer_other = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            self._write_log(current_log, 'CURRENT_RUN_MARKER')
            self._write_log(newer_other, 'NEWER_LOG_MARKER')
            os.utime(current_log, (100, 100))
            os.utime(newer_other, (200, 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                tail = zf.read(os.path.basename(current_log)).decode('utf-8')
            self.assertIn('CURRENT_RUN_MARKER', tail)
            self.assertNotIn('NEWER_LOG_MARKER', tail)
            self.assertEqual(meta.get('selected_log_selection_strategy'), 'current_process_run_log')
            self.assertEqual(meta.get('selected_log_name'), os.path.basename(current_log))
            self.assertEqual(meta.get('selected_log_archive_name'), os.path.basename(current_log))
            self.assertEqual(meta.get('app_log_run_id'), '2')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_includes_two_prior_run_log_tails(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_history_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            run001 = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            run002 = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            current_log = os.path.join(store, 'Log_{0}_run003.log'.format(date_token))
            newer_other = os.path.join(store, 'Log_{0}_run004.log'.format(date_token))
            self._write_log(run001, 'PRE_UPDATE_SESSION_MARKER')
            self._write_log(run002, 'KILLED_POST_UPDATE_SESSION_MARKER')
            self._write_log(current_log, 'CURRENT_RECOVERY_SESSION_MARKER')
            self._write_log(newer_other, 'SHOULD_NOT_BE_SELECTED_MARKER')
            os.utime(run001, (100, 100))
            os.utime(run002, (200, 200))
            os.utime(current_log, (300, 300))
            os.utime(newer_other, (400, 400))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '3'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                names = zf.namelist()
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                selected_tail = zf.read(os.path.basename(current_log)).decode('utf-8')
                previous_1 = zf.read(os.path.basename(run002)).decode('utf-8')
                previous_2 = zf.read(os.path.basename(run001)).decode('utf-8')
            self.assertIn('CURRENT_RECOVERY_SESSION_MARKER', selected_tail)
            self.assertIn('KILLED_POST_UPDATE_SESSION_MARKER', previous_1)
            self.assertIn('PRE_UPDATE_SESSION_MARKER', previous_2)
            self.assertNotIn('SHOULD_NOT_BE_SELECTED_MARKER', selected_tail + previous_1 + previous_2)
            self.assertIn(os.path.basename(run002), names)
            self.assertIn(os.path.basename(run001), names)
            history = meta.get('historical_log_tails') or []
            self.assertEqual([row.get('selected_log_name') for row in history], [
                os.path.basename(run002),
                os.path.basename(run001),
            ])
            self.assertEqual([row.get('archive_name') for row in history], [
                os.path.basename(run002),
                os.path.basename(run001),
            ])
        finally:
            shutil.rmtree(store, ignore_errors=True)
    def test_collect_support_bundle_falls_back_to_latest_when_current_missing(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            older = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            newer = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            self._write_log(older, 'OLDER_LOG_MARKER')
            self._write_log(newer, 'LATEST_LOG_MARKER')
            os.utime(older, (100, 100))
            os.utime(newer, (200, 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '9'  # expected current-run log path is absent
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                tail = zf.read(os.path.basename(newer)).decode('utf-8')
            self.assertIn('LATEST_LOG_MARKER', tail)
            self.assertNotIn('OLDER_LOG_MARKER', tail)
            self.assertEqual(meta.get('selected_log_selection_strategy'), 'latest_modified_fallback')
            self.assertEqual(meta.get('selected_log_name'), os.path.basename(newer))
            self.assertEqual(meta.get('selected_log_archive_name'), os.path.basename(newer))
            self.assertEqual(meta.get('app_log_run_id'), '9')
        finally:
            shutil.rmtree(store, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
