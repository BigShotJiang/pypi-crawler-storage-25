#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock  # pyright: ignore[reportMissingModuleSource]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir


class TestLabRootResolution(unittest.TestCase):
    """resolve_lab_root and invalid-root diagnostics."""

    def test_resolve_lab_root_strips_wrapping_quotes(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"./lab"'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.abspath('./lab'))

    def test_resolve_lab_root_quoted_empty_falls_back_to_repo_lab(self):
        """Quoted empty MEDICAFE_LAB_DIR (e.g. "") must fall back to repo_root/lab, not cwd."""
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': "''"}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))

    def test_resolve_lab_root_quoted_empty_never_uses_cwd(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        orig = os.getcwd()
        temp = tempfile.mkdtemp()
        try:
            os.chdir(temp)
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
                got = resolve_lab_root('/repo')
            self.assertEqual(got, os.path.join('/repo', 'lab'))
            self.assertNotEqual(got, os.path.abspath(''))
        finally:
            os.chdir(orig)
            import shutil
            shutil.rmtree(temp, ignore_errors=True)

    def test_resolve_lab_root_auto_heals_malformed_windows_prefix(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        bad = 'C: C:\\Python34\\Lib\\site-packages\\lab'
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': bad}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:\\Python34\\Lib\\site-packages\\lab'))

    def test_resolve_lab_root_keeps_windows_absolute_path(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/lab'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_windows_backslash_medicafe_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': r'C:\Python34\Lib\site-packages\MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath(r'C:\Python34\Lib\site-packages\MediCafe/lab'))

    def test_resolve_lab_root_medicafe_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/MediCafe/lab'))

    def test_invalid_lab_root_message_includes_env_details(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"C:/missing/lab"'}, clear=False):
            diagnostics = _collect_health_diagnostics('C:/missing/lab', auto_resolve=True)
        issue = diagnostics['issues'][0]
        self.assertEqual(issue['code'], 'LAB_ROOT_NOT_FOUND')
        self.assertIn('MEDICAFE_LAB_DIR(raw)', issue['message'])



class TestCollectHealthDiagnostics(unittest.TestCase):
    """_collect_health_diagnostics state-file handling."""

    def test_seeds_missing_diagnostics_state_when_auto_resolve_enabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            self.assertFalse(os.path.exists(state_path))
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            self.assertEqual(diagnostics['severity'], 'warn')
            issue_codes = [i.get('code') for i in diagnostics['issues']]
            self.assertNotIn('DIAGNOSTICS_STATE_MISSING', issue_codes)
            self.assertTrue(os.path.exists(state_path))
            self.assertTrue(any('Seeded missing diagnostics_state.json' in msg for msg in diagnostics['auto_resolved']))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_reports_missing_diagnostics_state_when_auto_resolve_disabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=False)
            self.assertEqual(diagnostics['severity'], 'warn')
            self.assertEqual(len(diagnostics['issues']), 1)
            self.assertEqual(diagnostics['issues'][0]['code'], 'DIAGNOSTICS_STATE_MISSING')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_use_v2_phase_run_ids(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                        'C': '20260218-010001-22222222',
                        'D': '20260218-010002-33333333',
                        'E': '20260218-010003-44444444',
                    },
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_B_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_skip_pending_transitional_phases(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_phase': 'C',
                    'active_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                    },
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_d_invalid_external_id_skips_surface_elevated(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': 'x', 'C': 'x', 'D': 'x', 'E': 'x',
                    },
                    'last_phase_d_pass_count': 10,
                    'last_phase_d_constraint_skip_counts': {'patient_invalid_external_id': 3},
                }, f)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertIn('PHASE_D_INVALID_EXTERNAL_ID_ELEVATED', codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_d_invalid_external_id_skips_surface_low_ratio(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': 'x', 'C': 'x', 'D': 'x', 'E': 'x',
                    },
                    'last_phase_d_pass_count': 1000,
                    'last_phase_d_constraint_skip_counts': {'patient_invalid_external_id': 1},
                }, f)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertIn('PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestFindLatestRunIdByPrefix(unittest.TestCase):
    """_find_latest_run_id_by_prefix and _select_latest_evidence_files."""

    def test_single_run_returns_run_id(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid))
            with open(path, 'w') as f:
                f.write('{}')
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, rid)
            self.assertEqual(p, path)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_multi_run_picks_latest_by_mtime(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            r1 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120000-aaa11111.json')
            r2 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120500-bbb22222.json')
            with open(r1, 'w') as f:
                f.write('{}')
            with open(r2, 'w') as f:
                f.write('{}')
            os.utime(r1, (1000, 1000))
            os.utime(r2, (2000, 2000))
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, '20250216-120500-bbb22222')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_dir_returns_none(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertIsNone(run_id)
            self.assertIsNone(p)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestSelectLatestEvidenceFiles(unittest.TestCase):
    """_select_latest_evidence_files."""

    def test_single_file(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            self.assertEqual(len(files), 1)
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid), files[0][0])
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_both_formats_attached(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.txt'.format(rid)), 'w') as f:
                f.write('txt')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            basenames = [f[0] for f in files]
            # One canonical file per logical group (.json vs .txt); avoid duplicate attachments.
            self.assertEqual(len(basenames), 1)
            self.assertIn(
                basenames[0],
                (
                    'artifact_discovery_summary_{0}.json'.format(rid),
                    'artifact_discovery_summary_{0}.txt'.format(rid),
                ),
            )
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_same_run(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w') as f:
                f.write('[]')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertIn('ingest_write_anomalies_{0}.jsonl'.format(rid), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_missing(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertFalse(any('ingest_write_anomalies_' in b for b in basenames))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestRunPhaseFManual(unittest.TestCase):
    """run_phase_f_manual and run_phase_f_manual_for_run_id."""

    def test_run_phase_f_manual_no_pipeline_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, running = run_phase_f_manual('/repo', '/py', {})
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertNotIn('--pipeline-run-id', call_args)

    def test_run_phase_f_manual_blocks_when_bootstrap_not_ready(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(False, 'bootstrap failed', None)):
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('os.path.exists', return_value=True):
                    ok, msg, running = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('bootstrap failed', msg)
        self.assertIsNone(running)
        mock_popen.assert_not_called()

    def test_run_phase_f_manual_for_run_id_passes_exact_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/lab'):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '20250216-120000-abc12345')
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertIn('--pipeline-run-id', call_args)
            idx = call_args.index('--pipeline-run-id')
            self.assertEqual(call_args[idx + 1], '20250216-120000-abc12345')



    def test_run_phase_f_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'package_shadow_run_report.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)):
                    with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                        ok, msg, _ = run_phase_f_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_run_phase_f_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        fake_path = '/repo/scripts/unified_model/package_shadow_run_report.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('package_shadow_run_report.py not found. checked:', msg)



    def test_run_phase_b_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        fake_path = '/repo/scripts/unified_model/discover_artifacts.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_b_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('discover_artifacts.py not found. checked:', msg)

    def test_run_phase_d_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_d_manual
        fake_path = '/repo/scripts/unified_model/run_qa_canonical.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_d_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('run_qa_canonical.py not found. checked:', msg)

    def test_run_phase_b_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'discover_artifacts.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                ok, msg, _ = run_phase_b_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_find_unified_model_script_uses_package_repo_root_fallback(self):
        from MediCafe import shadow_orchestrator
        repo = tempfile.mkdtemp()
        try:
            package_dir = os.path.join(repo, 'MediCafe')
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(package_dir, exist_ok=True)
            os.makedirs(script_dir, exist_ok=True)
            script_path = os.path.join(script_dir, 'bootstrap_lab.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            fake_module_path = os.path.join(package_dir, 'shadow_orchestrator.py')
            with patch.object(shadow_orchestrator, '__file__', fake_module_path):
                resolved_root, resolved_script, checks = shadow_orchestrator._find_unified_model_script(
                    '/bad/repo',
                    'bootstrap_lab.py',
                    python_exe='/py',
                )
            self.assertEqual(resolved_root, repo)
            self.assertEqual(resolved_script, script_path)
            self.assertIn(repo, [c.get('candidate_repo_root') for c in checks])
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)



class TestIsPipelineRunning(unittest.TestCase):
    """is_pipeline_running."""

    def test_lock_absent_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            self.assertFalse(is_pipeline_running(lab_root))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_lock_present_pid_dead_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
            with open(lock_path, 'w') as f:
                f.write('pid=99999999\nheartbeat_at_utc=2025-02-16T12:00:00Z\n')
            result = is_pipeline_running(lab_root)
            self.assertFalse(result)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestSendPhaseEvidenceGating(unittest.TestCase):
    """_send_phase_evidence requires at least one phase artifact."""

    def test_send_phase_evidence_requires_phase_artifact(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                ok, msg, _ = _send_phase_evidence(
                    lab_root,
                    [('artifact_discovery_summary_', None)],
                    'phase_b_evidence',
                    'No discovery summaries.',
                )
            self.assertFalse(ok)
            self.assertEqual(msg, 'No discovery summaries.')
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestSendPhaseEvidenceContextFiles(unittest.TestCase):
    """_send_phase_evidence includes context files."""

    def test_includes_context_files_when_present(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files, _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    mock_collect.return_value = '/tmp/bundle.zip'
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertTrue(ok)
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('diagnostics_state.json', basenames)
            self.assertIn('run_cursor.json', basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_uses_interactive_reauth_mode(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with patch('MediCafe.cloud_readiness.collect_support_bundle', return_value='/tmp/bundle.zip'):
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=False) as mock_submit:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertTrue(mock_submit.called)
            self.assertEqual(mock_submit.call_args[1].get('skip_interactive_reauth'), False)
            self.assertIn('Report queued or failed', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_prefers_newest_phase_artifact_mtime_over_diagnostics_lineage(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid_old = '20250216-120000-old12345'
            rid_new = '20250216-120100-new12345'
            old_path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid_old))
            new_path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid_new))
            with open(old_path, 'w') as f:
                f.write('{}')
            with open(new_path, 'w') as f:
                f.write('{}')
            old = time.time() - 120
            new = time.time() - 10
            os.utime(old_path, (old, old))
            os.utime(new_path, (new, new))
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid_old}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [item[0] for item in extra_files]
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid_new), basenames)
            self.assertNotIn('artifact_discovery_summary_{0}.json'.format(rid_old), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)



class TestSendPhaseFEvidenceMismatchFallback(unittest.TestCase):
    """send_phase_f_evidence mismatch-only fallback."""

    def test_send_phase_f_evidence_mismatch_only_fallback(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            rid = '20250216-120000-abc12345'
            mismatch_path = os.path.join(reports_dir, 'phase_f_mismatch_{0}.txt'.format(rid))
            with open(mismatch_path, 'w') as f:
                f.write('PHASE_F_RUN_ID_MISMATCH\n')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    with patch('MediCafe.cloud_readiness._submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                        mock_collect.return_value = '/tmp/bundle.zip'
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertTrue(ok)
            extra_meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(extra_meta.get('run_id'), rid)
            self.assertEqual(extra_meta.get('send_source'), 'manual_phase_f_evidence')
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('phase_f_mismatch_{0}.txt'.format(rid), basenames)
            self.assertIn('diagnostics_state.json', basenames)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_send_phase_f_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)



class TestEnsureLabReady(unittest.TestCase):
    """ensure_lab_ready gate before Cloud Readiness UI."""

    def test_skips_when_lab_exists_with_core_artifacts(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root, _ = _make_lab()
        try:
            with open(os.path.join(lab_root, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                    ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_call.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstraps_when_lab_missing(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_12345')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)

    def test_missing_lab_transitions_from_baseline_to_pipeline_start_attach(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_transition')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)
        self.assertEqual(mock_start.call_args_list[0][1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)
        self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)

    def test_skips_auto_full_pipeline_when_recent_success_in_diagnostics(self):
        """Cloud Readiness opt-in: skip follow-up pipeline when diagnostics + Phase F JSONs match."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports, exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            for name in (
                'shadow_run_report_{0}.json'.format(rid),
                'shadow_evidence_index_{0}.json'.format(rid),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as jf:
                    jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                            return_value=baseline_result,
                        ) as mock_start:
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready(
                                    '/repo', '/py', {}, env_flag, skip_recent_success_autopipeline=True)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_start.assert_called_once()
            self.assertEqual(mock_start.call_args[1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_default_does_not_skip_auto_full_pipeline_with_recent_success_diagnostics(self):
        """Manual Phase F paths use default ensure_lab_ready; still escalate to full pipeline when baseline needed."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports, exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            for name in (
                'shadow_run_report_{0}.json'.format(rid),
                'shadow_evidence_index_{0}.json'.format(rid),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as jf:
                    jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            pipeline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': 'Initialization in progress.',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                        ) as mock_start:
                            mock_start.side_effect = [baseline_result, pipeline_result]
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertTrue(ok)
            self.assertEqual(msg, 'Initialization in progress.')
            self.assertEqual(mock_start.call_count, 2)
            self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_opt_in_does_not_skip_when_phase_f_json_missing(self):
        """Opt-in without both report+index JSON for run_id still runs follow-up full pipeline."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            os.makedirs(os.path.join(lab, 'reports'), exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            with open(os.path.join(lab, 'reports', 'shadow_run_report_{0}.json'.format(rid)), 'w', encoding='utf-8') as jf:
                jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            pipeline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': 'Initialization in progress.',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                        ) as mock_start:
                            mock_start.side_effect = [baseline_result, pipeline_result]
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready(
                                    '/repo', '/py', {}, env_flag, skip_recent_success_autopipeline=True)
            self.assertTrue(ok)
            self.assertEqual(msg, 'Initialization in progress.')
            self.assertEqual(mock_start.call_count, 2)
            self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_skips_when_pipeline_running(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_67890')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir') as mock_isdir:
                mock_isdir.return_value = False
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=True):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        mock_call.assert_not_called()

    def test_respects_phase_a_auto_disabled(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_11111')
        env_flag = lambda name, default: False if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('FAILED_POLICY_PHASE_A_DISABLED', msg)
        mock_call.assert_not_called()

    def test_recheck_soft_success_when_core_artifacts_exist_after_nonzero_exit(self):
        from MediCafe import cloud_readiness as cr
        ensure_lab_ready = cr.ensure_lab_ready
        nonexistent_first = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_first')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_first):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=True):
                        baseline_result = {
                            "status": cr.shadow_orchestrator.STATUS_READY_NOOP,
                            "error_code": cr.shadow_orchestrator.ERROR_READY_NOOP,
                            "message": "",
                            "payload": {},
                        }
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                            return_value=baseline_result
                        ) as mock_start:
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        mock_start.assert_called_once()
        self.assertEqual(mock_start.call_args[1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)

    def test_runs_bootstrap_when_lab_exists_but_no_core_artifacts(self):
        """Lab dir exists (e.g. partial bootstrap) but no db/cursor; must run bootstrap."""
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(lab_root, 'reports'), exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=1) as mock_call:
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 1', msg)
            mock_call.assert_called_once()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_lab_root_returns_error(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        env_flag = lambda name, default: True
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=''):
            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('Lab root could not be resolved', msg)

    def test_falls_back_to_repo_lab_when_resolved_lab_missing(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_persists_fallback_lab_root_before_reporting_ready(self):
        """When MEDICAFE_LAB_DIR points to missing dir but repo_root/lab has artifacts,
        persist fallback to os.environ so downstream resolve_lab_root uses correct path."""
        from MediCafe.cloud_readiness import ensure_lab_ready, resolve_lab_root
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertTrue(ok)
                mock_call.assert_not_called()
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_nonzero_exit_writes_bootstrap_diag_hint(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            lab_root = os.path.join(temp_repo, 'lab')
            os.makedirs(lab_root, exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=2):
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 2', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_missing_bootstrap_script_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.os.path.exists', return_value=False):
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('BOOTSTRAP_SCRIPT_MISSING', msg)
            self.assertIn('bootstrap_lab.py not found', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstrap_keyboard_interrupt_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.subprocess.call', side_effect=KeyboardInterrupt):
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_INTERRUPTED_CONTROL_EVENT', msg)
            self.assertIn('control event', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_orchestrator_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_failed = {
                'status': cr.shadow_orchestrator.STATUS_FAILED,
                'error_code': 'PIPELINE_SCRIPT_MISSING',
                'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
                'diagnostic_path': os.path.join(lab_root, 'reports', 'diag.json'),
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=baseline_failed):
                            with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                                ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
            mock_auto.assert_called_once()
            self.assertEqual(mock_auto.call_args[1].get('trigger'), 'ensure_lab_ready_baseline')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestOrchestratorFailureReportDedup(unittest.TestCase):
    """Orchestrator auto-report dedup must survive unique per-attempt diagnostic paths."""

    def test_dedup_key_strips_diagnostics_parenthetical(self):
        from MediCafe.cloud_readiness import _orchestrator_failure_report_dedup_key
        a = _orchestrator_failure_report_dedup_key(
            'PHASE_A_EXIT_1',
            'PHASE_A_EXIT_1: Phase A bootstrap exited with code 1 (diagnostics: /lab/reports/bootstrap_autofix_diag_a.json)',
        )
        b = _orchestrator_failure_report_dedup_key(
            'PHASE_A_EXIT_1',
            'PHASE_A_EXIT_1: Phase A bootstrap exited with code 1 (diagnostics: /lab/reports/bootstrap_autofix_diag_b.json)',
        )
        self.assertEqual(a, b)
        self.assertEqual(a, 'PHASE_A_EXIT_1')

    def test_second_auto_report_suppressed_within_window_for_same_logical_failure(self):
        from MediCafe import cloud_readiness as cr
        lab_root = tempfile.mkdtemp()
        try:
            collects = []

            def collect_fn(**kwargs):
                collects.append(1)
                p = os.path.join(lab_root, 'bundle.zip')
                with open(p, 'wb') as handle:
                    handle.write(b'PK\x05\x06' + b'\x00' * 18)
                return p

            failed_a = {
                'status': cr.shadow_orchestrator.STATUS_FAILED,
                'error_code': 'PHASE_A_EXIT_1',
                'message': (
                    'PHASE_A_EXIT_1: Phase A bootstrap exited with code 1 '
                    '(diagnostics: {0})'.format(os.path.join(lab_root, 'reports', 'diag_a.json'))
                ),
                'payload': {},
            }
            failed_b = dict(
                failed_a,
                message=(
                    'PHASE_A_EXIT_1: Phase A bootstrap exited with code 1 '
                    '(diagnostics: {0})'.format(os.path.join(lab_root, 'reports', 'diag_b.json'))
                ),
            )
            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                with patch.object(cr, 'collect_support_bundle', side_effect=collect_fn):
                    r1 = cr._maybe_send_orchestrator_failure_report('/repo', lab_root, failed_a, 't1')
                    r2 = cr._maybe_send_orchestrator_failure_report('/repo', lab_root, failed_b, 't2')
            self.assertTrue(r1)
            self.assertFalse(r2)
            self.assertEqual(len(collects), 1)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestRunPhaseFManualForRunIdEmptyGuard(unittest.TestCase):
    """run_phase_f_manual_for_run_id empty run_id guard."""

    def test_empty_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()

    def test_whitespace_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '   ')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()



class TestRunShadowPipelineAutoReport(unittest.TestCase):
    def test_manual_pipeline_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        failed = {
            'status': cr.shadow_orchestrator.STATUS_FAILED,
            'error_code': 'PIPELINE_SCRIPT_MISSING',
            'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
            'payload': {},
        }
        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=failed):
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/repo/lab'):
                with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                    ok, msg, _ = cr.run_shadow_pipeline('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
        mock_auto.assert_called_once()
        self.assertEqual(mock_auto.call_args[1].get('trigger'), 'run_shadow_pipeline_manual')



class TestMigrationHealthAuditWiring(unittest.TestCase):
    """run/open helpers for unified migration-health audit."""

    def test_run_migration_health_audit_passes_default_stage(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'pass', 'score': 100, 'exit_code': 0},
                'surfaces': {'xp_local': {'metrics': []}},
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock) as mock_popen:
                    ok, _msg, _data = cr.run_migration_health_audit(
                        repo, sys.executable, {}, scope='both', write_report=False
                    )
            self.assertTrue(ok)
            cmd = mock_popen.call_args[0][0]
            self.assertIn('--migration-stage', cmd)
            idx = cmd.index('--migration-stage')
            self.assertEqual(cmd[idx + 1], 'xp_validation')

    def test_run_migration_health_audit_parses_payload_and_hints(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'warn', 'score': 70, 'exit_code': 0},
                'surfaces': {
                    'xp_local': {'metrics': [
                        {'key': 'xp.phase_d_reject_ratio', 'status': 'warn', 'value': 0.22},
                        {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 1.0},
                        {'key': 'xp.phase_e_contract_parity', 'status': 'pass', 'value': 'pass'},
                        {'key': 'xp.post_medisoft_status', 'status': 'warn', 'value': 'blocked', 'detail': 'blocked_stage=qa'},
                        {'key': 'xp.phase_b_dat_candidates_seen_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_manifest_rows_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_b_dat_configured_root_missing_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_fallback_root_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_existing_empty_root_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_selection_mode', 'status': 'pass', 'value': 'fallback'},
                        {'key': 'xp.phase_b_dat_selected_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                        {'key': 'xp.phase_b_dat_effective_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                        {'key': 'xp.phase_d_dat_selected_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_d_dat_qa_pass_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_d_dat_qa_reject_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_d_dat_canonical_record_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_d_csv_docx_join_summary', 'status': 'warn', 'value': 'tracked', 'detail': 'matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)'},
                    ]},
                    'cloud': {'metrics': [
                        {'key': 'cloud.unacked_queue_count', 'status': 'warn', 'value': 35},
                    ]},
                },
                'degradations': [],
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock):
                    ok, msg, data = cr.run_migration_health_audit(repo, sys.executable, {}, scope='both', write_report=False)

            self.assertTrue(ok)
            self.assertIn('status=warn', msg)
            assert isinstance(data, dict)
            self.assertTrue(any('QA reject ratio' in h for h in data.get('hints', [])))
            self.assertTrue(any('Post-MediSoft path' in h for h in data.get('hints', [])))
            self.assertTrue(any('XP DAT Phase D' in h for h in data.get('hints', [])))
            self.assertTrue(any('CSV+DOCX join' in h for h in data.get('hints', [])))

    def test_deduplicate_audit_hint_lines(self):
        from MediCafe.cloud_readiness import _deduplicate_audit_hint_lines
        self.assertEqual(
            _deduplicate_audit_hint_lines(['a', '  a  ', 'b', 'a', 'c']),
            ['a', 'b', 'c'],
        )
        self.assertEqual(_deduplicate_audit_hint_lines([]), [])

    def test_audit_hint_lines_include_stage_aware_cloud_note(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'migration_stage': 'xp_validation',
            'overall': {'status': 'warn', 'score': 38, 'exit_code': 0},
            'gating': {'included_surfaces': ['xp_local'], 'excluded_surfaces': ['cloud']},
            'surfaces': {
                'xp_local': {'metrics': [
                    {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 'not_applicable'},
                    {'key': 'xp.cursor_state_run_alignment', 'status': 'warn', 'value': 2},
                    {'key': 'xp.post_medisoft_status', 'status': 'warn', 'value': 'blocked', 'detail': 'blocked_stage=missing_root,selection_mode=fallback,selected_root_source_id=dat_fallback,effective_root_source_id=dat_fallback'},
                    {'key': 'xp.phase_b_dat_candidates_seen_count', 'status': 'pass', 'value': 2},
                    {'key': 'xp.phase_b_dat_manifest_rows_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_b_dat_configured_root_missing_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_fallback_root_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_existing_empty_root_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_selection_mode', 'status': 'pass', 'value': 'fallback'},
                    {'key': 'xp.phase_b_dat_selected_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                    {'key': 'xp.phase_b_dat_effective_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                    {'key': 'xp.phase_d_dat_selected_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_d_dat_qa_pass_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_d_dat_qa_reject_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_d_dat_canonical_record_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_d_csv_docx_join_summary', 'status': 'warn', 'value': 'tracked', 'detail': 'matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)'},
                ]},
                'cloud': {'metrics': []},
            },
            'degradations': [{'surface': 'cloud', 'reason': 'project_id_missing'}],
        }
        hints = cr._audit_hint_lines_from_payload(payload)
        joined = '\n'.join(hints)
        self.assertIn('Migration stage: xp_validation', joined)
        self.assertIn('Cloud surface is informational-only', joined)
        self.assertIn('XP projection coverage: not_applicable', joined)
        self.assertIn('Post-MediSoft path: blocked', joined)
        self.assertIn('XP DAT discovery: candidates=2, manifest_rows=0', joined)
        self.assertIn('selected_root=dat_fallback', joined)
        self.assertIn('effective_root=dat_fallback', joined)
        self.assertIn('XP DAT Phase D: selected=1, qa_pass=0, qa_reject=1, canonical=0', joined)
        self.assertIn('XP upstream CSV+DOCX join: matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)', joined)
        self.assertIn('qa_planning_telemetry_log#17(run_id=r1)', joined)
        self.assertIn('XP cursor/state run alignment: 2 (warn)', joined)
        self.assertIn('Cloud degradation reasons: project_id_missing', joined)
        self.assertIn('Runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', joined)

    def test_open_latest_migration_health_report_prefers_latest(self):
        from MediCafe.cloud_readiness import open_latest_migration_health_report
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            p1 = os.path.join(reports, 'audit_migration_health_summary_20260101-000000-aaaa1111.txt')
            p2 = os.path.join(reports, 'audit_migration_health_summary_20260101-000500-bbbb2222.txt')
            with open(p1, 'w', encoding='utf-8') as f:
                f.write('one')
            with open(p2, 'w', encoding='utf-8') as f:
                f.write('two')
            os.utime(p1, (1000, 1000))
            os.utime(p2, (2000, 2000))
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': lab}, clear=False):
                ok, msg, path = open_latest_migration_health_report(repo)
            self.assertTrue(ok)
            assert isinstance(path, str)
            self.assertTrue(path.endswith('bbbb2222.txt'))



class TestReportDeliveryStatusViewer(unittest.TestCase):
    def test_open_report_delivery_status_writes_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            queue1 = os.path.join(repo, 'q1.zip')
            queue2 = os.path.join(repo, 'q2.zip')
            with open(queue1, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(queue2, 'w', encoding='utf-8') as f:
                f.write('y')
            os.utime(queue1, (1000, 1000))
            os.utime(queue2, (2000, 2000))

            health_state = os.path.join(lab, cr._HEALTH_ALERT_STATE_FILENAME)
            with open(health_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'A', 'last_sent_epoch': 123}, f)
            orch_state = os.path.join(lab, cr._ORCHESTRATOR_ALERT_STATE_FILENAME)
            with open(orch_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'B', 'last_attempt_epoch': 456, 'last_attempt_ok': False}, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, '_collect_delivery_diagnostics', return_value={
                    'token_available': False,
                    'recipient_count': 0,
                    'queued_bundle_count': 2,
                    'queued_bundle_paths': [queue1, queue2],
                }):
                    ok, msg, path = cr.open_report_delivery_status(repo)

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertIsInstance(path, str)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Report Delivery Status', text)
            self.assertIn('token_available=False', text)
            self.assertIn('recipient_count=0', text)
            self.assertIn('queued_bundle_count=2', text)
            self.assertIn('Cloud health auto-report', text)
            self.assertIn('Orchestrator auto-report', text)
            self.assertIn('Remediation Playbook', text)
            self.assertIn('Actions:', text)
