# -*- coding: utf-8 -*-
"""Tests for MediCafe.json_io (pytest; dev Python 3.11+)."""
from __future__ import print_function

import json
import os
import sys
import threading
import time

import pytest

_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from MediCafe import json_io  # noqa: E402


def test_write_json_atomic_roundtrip(tmp_path):
    p = str(tmp_path / 'cfg.json')
    payload = {'a': 1, 'b': [2, 3]}
    assert json_io.write_json_atomic(
        p, payload, 'test', 'pytest', indent=2, lock=False, ensure_ascii=True
    )
    with open(p, 'r', encoding='utf-8') as handle:
        got = json.load(handle)
    assert got == payload


def test_write_preserves_original_on_failed_promote(tmp_path, monkeypatch):
    dest = str(tmp_path / 'out.json')
    original = {'keep': True}
    with open(dest, 'w', encoding='utf-8') as handle:
        json.dump(original, handle)

    calls = {'n': 0}

    def boom_rename(src, dst):
        calls['n'] += 1
        raise OSError(13, 'permission denied')

    monkeypatch.setattr(os, 'rename', boom_rename)
    if hasattr(os, 'replace'):
        def boom_replace(src, dst):
            calls['n'] += 1
            raise OSError(13, 'permission denied')

        monkeypatch.setattr(os, 'replace', boom_replace)

    ok = json_io.write_json_atomic(
        dest, {'new': 'data'}, 'test', 'pytest', lock=False, ensure_ascii=True
    )
    assert ok is False
    with open(dest, 'r', encoding='utf-8') as handle:
        disk = json.load(handle)
    assert disk == original
    temps = [f for f in os.listdir(tmp_path) if 'tmp' in f and f.endswith('.json')]
    assert not temps


def test_lock_blocks_second_writer(tmp_path):
    path = str(tmp_path / 'x.json')
    lock_path = path + '.lock'
    results = []

    def first():
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, b'{"pid":999999,"created_at":0}')
        os.close(fd)
        time.sleep(0.3)
        try:
            os.remove(lock_path)
        except OSError:
            pass

    def second():
        ok = json_io.write_json_atomic(path, {'v': 2}, 't', 'w2', lock=True, ensure_ascii=True)
        results.append(ok)

    t1 = threading.Thread(target=first)
    t2 = threading.Thread(target=second)
    t1.start()
    time.sleep(0.05)
    t2.start()
    t1.join(timeout=5)
    t2.join(timeout=5)
    assert results == [True]
    assert os.path.isfile(path)


def test_stale_lock_removed(tmp_path):
    path = str(tmp_path / 'y.json')
    lock_path = path + '.lock'
    old = time.time() - 700
    with open(lock_path, 'w') as handle:
        handle.write('{"pid":999999,"created_at":%s}' % old)
    os.utime(lock_path, (old, old))
    assert json_io.write_json_atomic(path, {'ok': True}, 't', 'w', lock=True, ensure_ascii=True)
    assert not os.path.exists(lock_path)


def test_append_jsonl_and_rotate(tmp_path):
    jl = str(tmp_path / 'ev.jsonl')
    assert json_io.append_jsonl(jl, {'x': 1}, 'a', 'w', lock=False)
    assert json_io.append_jsonl(jl, {'x': 2}, 'a', 'w', lock=False)
    assert json_io.rotate_jsonl_tail(jl, 1, 'a', 'w')
    lines = open(jl, 'r', encoding='utf-8').read().strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])['x'] == 2


def test_update_json_uses_atomic(tmp_path, monkeypatch):
    cfg = str(tmp_path / 'config.json')
    with open(cfg, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old'}, handle)

    calls = []
    real_write = json_io.write_json_atomic

    def fake_atomic(path, payload, artifact, writer, **kwargs):
        calls.append((artifact, writer, path))
        kw = dict(kwargs)
        kw['lock'] = False
        return real_write(path, payload, artifact, writer, **kw)

    monkeypatch.setattr('MediCafe.json_io.write_json_atomic', fake_atomic)
    import importlib

    import MediBot.update_json as update_json_mod

    importlib.reload(update_json_mod)

    update_json_mod.update_csv_path(cfg, str(tmp_path / 'new.csv'))
    assert calls and calls[0][0] == 'config' and calls[0][1] == 'update_json'
    with open(cfg, 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    assert 'new.csv' in str(data.get('CSV_FILE_PATH', ''))


def test_preflight_json_io_passes_with_writable_dirs(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)
    assert fails == []


def test_preflight_detects_readonly_file(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    os.chmod(config_path, 0o444)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    try:
        fails = json_io.collect_json_io_preflight_failures(ctx)
        assert any('r+ probe' in f for f in fails)
    finally:
        os.chmod(config_path, 0o644)


def test_telemetry_probe_candidates_readonly_does_not_call_queue_resolver(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    called = {'resolve_queue_dir': False}
    sentinel = os.path.join(str(tmp_path), 'created_by_resolver')

    def creating_resolver(medi):
        called['resolve_queue_dir'] = True
        os.makedirs(sentinel)
        return os.path.join(sentinel, 'reports_queue')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)

    candidates = json_io._telemetry_probe_candidates_readonly(
        os.path.join(str(tmp_path), 'config.json'),
        local_storage,
    )

    assert called['resolve_queue_dir'] is False
    assert os.path.join(local_storage, 'telemetry') in candidates
    assert not os.path.exists(sentinel)


def test_preflight_does_not_create_optional_telemetry_dirs(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    def creating_resolver(medi):
        os.makedirs(os.path.join(str(tmp_path), 'reports_queue_created'))
        return os.path.join(str(tmp_path), 'reports_queue_created')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)

    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': local_storage}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)

    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': local_storage,
        'source_folder': local_storage,
        'target_folder': local_storage,
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)

    assert fails == []
    assert not os.path.exists(os.path.join(local_storage, 'telemetry'))
    assert not os.path.exists(os.path.join(str(tmp_path), 'reports_queue_created'))
