#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


class SubmitSelectorTests(unittest.TestCase):
    def _rows(self, count=3):
        rows = []
        for i in range(count):
            rows.append({
                'patient_name': 'Patient {}'.format(i + 1),
                'patient_id': 'CH{:03d}'.format(i + 1),
                'payer_id': 'PAY{}'.format((i % 2) + 1),
                'dos': '2026-05-{:02d}'.format((i % 9) + 1),
                'first_seen_str': '2026-05-{:02d} 08:00'.format((i % 9) + 1),
                'latest_seen_str': '2026-05-{:02d} 09:00'.format((i % 9) + 1),
                'claim_key': 'ck-{}'.format(i + 1),
                'family_key': 'ch{:03d}|pay{}|2026-05-{:02d}'.format(
                    i + 1, (i % 2) + 1, (i % 9) + 1
                ),
            })
        return rows

    def test_selector_refresh_action(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['refresh']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=['a.dat'])
        self.assertEqual(result.get('action'), 'refresh')

    def test_selector_legacy_action_when_fallback_present(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['legacy']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=['a.dat'])
        self.assertEqual(result.get('action'), 'legacy')

    def test_selector_page_select_returns_selected_rows(self):
        from MediLink import MediLink_UI as ui

        rows = self._rows(3)
        # move to next page (page size 12 default; use filter to keep stable path via direct select)
        # choose row #1 from current page and confirm
        with patch.object(ui, 'get_user_choice', side_effect=['select']):
            with patch('builtins.input', side_effect=['1', 'y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        self.assertEqual(len(result.get('selected_rows') or []), 1)
        # Default sort is latest-first; row 1 maps to newest candidate.
        self.assertEqual(result['selected_rows'][0].get('claim_key'), 'ck-3')

    def test_selector_toggle_view_then_cancel(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['view', 'cancel']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=None)
        self.assertEqual(result.get('action'), 'cancel')

    def test_selector_uses_claim_key_patient_id_when_identity_sparse(self):
        from MediLink import MediLink_UI as ui

        rows = [{
            'claim_key': 'CH900|PAY1|2026-06-01|svc',
            'dos': '2026-06-01',
            'payer_id': 'PAY1',
            'first_seen_str': '2026-06-01 08:00',
            'latest_seen_str': '2026-06-01 08:00',
        }]
        with patch.object(ui, 'get_user_choice', side_effect=['select']):
            with patch('builtins.input', side_effect=['1', 'y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        selected = result.get('selected_rows')[0]
        self.assertEqual(selected.get('_display_patient_id'), 'CH900')
        self.assertNotEqual(selected.get('_display_patient_name').lower(), 'unknown')

    def test_selector_falls_back_when_all_rows_non_actionable(self):
        from MediLink import MediLink_UI as ui

        rows = [{
            'dos': '',
            'payer_id': '',
            'first_seen_str': '',
            'latest_seen_str': '',
            'patient_name': '',
            'patient_id': '',
            'member_id': '',
            'claim_key': '',
        }]
        result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=['legacy.dat'])
        self.assertEqual(result.get('action'), 'legacy_unusable')


if __name__ == '__main__':
    unittest.main()

