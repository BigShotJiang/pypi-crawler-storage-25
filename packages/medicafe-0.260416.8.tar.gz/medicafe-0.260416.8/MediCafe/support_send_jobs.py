#!/usr/bin/env python
from __future__ import print_function

import json
import os
import subprocess
import sys
import threading
import time
import traceback



def _utc_now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _bool_env(name, default=False):
    raw = str(os.environ.get(name, '') or '').strip().lower()
    if raw in ('1', 'true', 'yes', 'on'):
        return True
    if raw in ('0', 'false', 'no', 'off'):
        return False
    return bool(default)


def _int_env(name, default_value):
    raw = str(os.environ.get(name, '') or '').strip()
    if not raw:
        return int(default_value)
    try:
        return int(raw)
    except Exception:
        return int(default_value)


def _short_token():
    try:
        return os.urandom(3).encode('hex')
    except Exception:
        return str(int(time.time() * 1000) % 1000000)


def _parse_iso_utc_to_epoch(value):
    raw = str(value or '').strip()
    if not raw:
        return None
    if raw.endswith('Z'):
        raw = raw[:-1]
    try:
        import calendar
        parsed = time.strptime(raw, '%Y-%m-%dT%H:%M:%S')
        return calendar.timegm(parsed)
    except Exception:
        return None

def _safe_remove(path):
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _safe_rename(src, dst):
    if src == dst:
        return
    try:
        if os.path.exists(dst):
            os.remove(dst)
    except Exception:
        pass
    os.rename(src, dst)


def _json_load(path):
    try:
        if not path or not os.path.exists(path):
            return {}
        with open(path, 'r') as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _json_dump_atomic(path, payload):
    try:
        from MediCafe.json_io import write_json_atomic
    except ImportError:
        write_json_atomic = None
    if write_json_atomic is None:
        folder = os.path.dirname(path)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        tmp = path + '.tmp'
        with open(tmp, 'w') as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        _safe_rename(tmp, path)
        return
    folder = os.path.dirname(path)
    if folder and not os.path.exists(folder):
        os.makedirs(folder)
    if not write_json_atomic(
            path,
            payload,
            'support_send_queue',
            'support_send_jobs',
            indent=2,
            sort_keys=True,
            lock=True,
            ensure_ascii=False,
    ):
        raise IOError('write_json_atomic returned false for {0}'.format(path))


class SupportSendQueuePolicy(object):
    PRIORITY_WEIGHT = {'high': 0, 'normal': 1, 'low': 2}

    def __init__(self, dedup_ttl_sec=900):
        self.dedup_ttl_sec = int(max(1, dedup_ttl_sec))

    def normalize_priority(self, priority):
        p = str(priority or '').strip().lower()
        if p in ('high', 'normal', 'low'):
            return p
        return 'normal'

    def dedup_key(self, request):
        req = request if isinstance(request, dict) else {}
        send_type = str(req.get('send_type', '') or '').strip()
        anchor = str(req.get('anchor_run_id', '') or '').strip()
        context = str(req.get('context_run_id', '') or '').strip()
        issue = str(req.get('issue_code', '') or '').strip()
        scope_hash = str(req.get('source_scope_hash', '') or '').strip()
        return '|'.join([send_type, anchor, context, issue, scope_hash])

    def queue_sort_key(self, job):
        payload = job if isinstance(job, dict) else {}
        p = self.normalize_priority(payload.get('priority'))
        created = str(payload.get('created_at_utc', '') or '')
        return (self.PRIORITY_WEIGHT.get(p, 1), created)


class SupportSendJobManager(object):
    def __init__(self, repo_root, lab_root, logger_fn=None, python_exe=''):
        self.repo_root = str(repo_root or '').strip()
        self.lab_root = str(lab_root or '').strip()
        self.logger_fn = logger_fn
        self.python_exe = str(python_exe or '').strip()

        self.detached_worker = _bool_env('MEDICAFE_SUPPORT_SEND_DETACHED_WORKER', default=False)
        self.single_flight = _bool_env('MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT', default=True)
        self.queue_max = max(1, _int_env('MEDICAFE_SUPPORT_SEND_QUEUE_MAX', 20))
        self.policy = SupportSendQueuePolicy(dedup_ttl_sec=max(1, _int_env('MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC', 900)))

        reports_dir = os.path.join(self.lab_root, 'reports')
        self.jobs_dir = os.path.join(reports_dir, 'support_send_jobs')
        self.queue_state_path = os.path.join(reports_dir, 'support_send_queue_state.json')
        self.single_flight_lock_path = os.path.join(reports_dir, 'support_send_lock')
        self.notice_state_path = os.path.join(reports_dir, 'support_send_notice_state.json')

        self._state_lock = threading.Lock()
        self._worker_thread = None

    def _log(self, event_name, details=None):
        if callable(self.logger_fn):
            try:
                if isinstance(details, dict):
                    self.logger_fn(str(event_name or ''), details)
                else:
                    self.logger_fn(str(event_name or ''))
                return
            except TypeError:
                try:
                    self.logger_fn(str(event_name or ''))
                    return
                except Exception:
                    pass
            except Exception:
                pass

    def _ensure_dirs(self):
        if self.jobs_dir and not os.path.exists(self.jobs_dir):
            os.makedirs(self.jobs_dir)

    def _job_json_path(self, job_id):
        return os.path.join(self.jobs_dir, 'job_{0}.json'.format(job_id))

    def _job_log_path(self, job_id):
        return os.path.join(self.jobs_dir, 'job_{0}.log'.format(job_id))

    def _new_job_id(self):
        return 'ssj_{0}_{1}'.format(time.strftime('%Y%m%d_%H%M%S', time.gmtime()), _short_token())

    def _append_job_log(self, job_id, line):
        try:
            from MediCafe.json_io import append_text_line

            path = self._job_log_path(job_id)
            append_text_line(
                path,
                '[{0}] {1}'.format(_utc_now(), str(line or '').strip()),
                'support_send_job_log',
                'support_send_jobs',
                lock=False,
            )
        except Exception:
            pass

    def _job_log_payload(self, job, extra=None):
        src = job if isinstance(job, dict) else {}
        payload = {}
        for key in (
                'job_id',
                'source',
                'send_type',
                'status',
                'progress_stage',
                'heartbeat_at_utc',
                'policy_decision',
                'policy_reason',
                'operator_execution_mode',
                'installed_version',
                'recommendation_action_kind',
                'result_message'):
            if key in src:
                payload[key] = src.get(key)
        if isinstance(extra, dict):
            payload.update(extra)
        return payload

    def _read_job(self, job_id):
        return _json_load(self._job_json_path(job_id))

    def _write_job(self, job):
        payload = job if isinstance(job, dict) else {}
        job_id = str(payload.get('job_id', '') or '').strip()
        if not job_id:
            return
        _json_dump_atomic(self._job_json_path(job_id), payload)

    def _read_queue_state(self):
        data = _json_load(self.queue_state_path)
        out = {'queued_job_ids': []}
        queued = data.get('queued_job_ids', []) if isinstance(data, dict) else []
        if isinstance(queued, list):
            out['queued_job_ids'] = [str(i or '').strip() for i in queued if str(i or '').strip()]
        return out

    def _write_queue_state(self, queued_ids):
        _json_dump_atomic(self.queue_state_path, {
            'updated_at_utc': _utc_now(),
            'queued_job_ids': list(queued_ids or []),
        })

    def _list_job_ids(self):
        if not os.path.exists(self.jobs_dir):
            return []
        ids = []
        for name in os.listdir(self.jobs_dir):
            if not (name.startswith('job_') and name.endswith('.json')):
                continue
            ids.append(name[4:-5])
        return ids

    def _find_active_job(self):
        for job_id in self._list_job_ids():
            job = self._read_job(job_id)
            if str(job.get('status', '') or '') == 'running':
                return job
        return {}

    def _find_recent_duplicate(self, request):
        dedup_key = self.policy.dedup_key(request)
        if not dedup_key:
            return {}
        cutoff = time.time() - self.policy.dedup_ttl_sec
        for job_id in self._list_job_ids():
            job = self._read_job(job_id)
            if str(job.get('dedup_key', '') or '') != dedup_key:
                continue
            created_at = float(job.get('created_epoch', 0.0) or 0.0)
            if created_at < cutoff:
                continue
            status = str(job.get('status', '') or '')
            if status in ('queued', 'running', 'succeeded'):
                return job
        return {}

    def _acquire_single_flight(self, job_id):
        if not self.single_flight:
            return True
        now = time.time()
        fd = None
        try:
            fd = os.open(self.single_flight_lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            payload = {
                'job_id': str(job_id or ''),
                'acquired_at_utc': _utc_now(),
                'acquired_epoch': now,
            }
            os.write(fd, json.dumps(payload).encode('utf-8'))
            return True
        except Exception:
            if fd is not None:
                _safe_remove(self.single_flight_lock_path)
            stale = False
            try:
                age_sec = now - os.path.getmtime(self.single_flight_lock_path)
                stale = age_sec > (6 * 60 * 60)
            except Exception:
                stale = False
            if stale:
                _safe_remove(self.single_flight_lock_path)
                return self._acquire_single_flight(job_id)
            return False
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

    def _release_single_flight(self):
        if not self.single_flight:
            return
        _safe_remove(self.single_flight_lock_path)

    def _build_job_record(self, request, policy_decision, policy_reason):
        req = request if isinstance(request, dict) else {}
        rec = req.get('frozen_recommendation', {})
        if not isinstance(rec, dict):
            rec = {}
        job_id = self._new_job_id()
        return {
            'job_id': job_id,
            'created_at_utc': _utc_now(),
            'created_epoch': float(time.time()),
            'started_at_utc': '',
            'finished_at_utc': '',
            'status': 'queued',
            'source': str(req.get('source', '') or ''),
            'priority': self.policy.normalize_priority(req.get('priority')),
            'send_type': str(req.get('send_type', '') or ''),
            'policy_decision': str(policy_decision or ''),
            'policy_reason': str(policy_reason or ''),
            'operator_execution_mode': str(req.get('operator_execution_mode', '') or ''),
            'dedup_key': self.policy.dedup_key(req),
            'anchor_run_id': str(req.get('anchor_run_id', '') or ''),
            'context_run_id': str(req.get('context_run_id', '') or ''),
            'issue_code': str(req.get('issue_code', '') or ''),
            'requested_artifact_scope': str(req.get('requested_artifact_scope', '') or ''),
            'source_scope_hash': str(req.get('source_scope_hash', '') or ''),
            'installed_version': str(req.get('installed_version', '') or ''),
            'recommendation_action_kind': str(req.get('recommendation_action_kind', '') or ''),
            'heartbeat_at_utc': _utc_now(),
            'progress_stage': 'queued',
            'worker_pid': '',
            'worker_mode': '',
            'worker_started_at_utc': '',
            'recovery_count': 0,
            'result_ok': False,
            'result_message': '',
            'delivery_status_path': '',
            'artifact_paths': [],
            'frozen_recommendation': rec,
            'error': {'type': '', 'detail': '', 'traceback_path': ''},
        }

    def enqueue(self, request):
        self._ensure_dirs()
        req = request if isinstance(request, dict) else {}
        send_type = str(req.get('send_type', '') or '').strip()
        if send_type not in ('run_evidence', 'system_health'):
            return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'invalid_send_type', 'message': 'Unsupported send type.'}
        with self._state_lock:
            duplicate = self._find_recent_duplicate(req)
            if duplicate:
                return {
                    'accepted': True,
                    'policy_decision': 'deduplicated',
                    'policy_reason': 'duplicate_equivalent_request',
                    'job_id': str(duplicate.get('job_id', '') or ''),
                    'status': str(duplicate.get('status', '') or ''),
                }
            queue_state = self._read_queue_state()
            queued_ids = queue_state.get('queued_job_ids', [])
            if len(queued_ids) >= self.queue_max and self.policy.normalize_priority(req.get('priority')) == 'low':
                return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'queue_full_low_priority', 'message': 'Queue is full for low-priority sends.'}

            active = self._find_active_job()
            busy = bool(active) or (self.single_flight and os.path.exists(self.single_flight_lock_path))
            decision = 'queued' if busy else 'started'
            reason = 'single_flight_busy' if busy else 'started_immediately'
            job = self._build_job_record(req, decision, reason)
            self._write_job(job)
            self._append_job_log(job.get('job_id'), 'accepted policy_decision={0} reason={1}'.format(decision, reason))
            self._log('job_accepted', self._job_log_payload(job))
            if decision == 'started' and self.detached_worker and self._spawn_detached_worker(job.get('job_id')):
                job['worker_mode'] = 'detached_spawned'
                job['detached_spawned_at_utc'] = _utc_now()
                self._write_job(job)
                self._append_job_log(job.get('job_id'), 'detached worker spawned')
                self._log('job_detached_worker_spawned', self._job_log_payload(job))
            else:
                queued_ids.append(job.get('job_id'))
                self._write_queue_state(queued_ids)
                self._ensure_worker_locked()
            return {
                'accepted': True,
                'policy_decision': decision,
                'policy_reason': reason,
                'job_id': str(job.get('job_id', '') or ''),
                'status': 'queued',
            }

    def _lock_owner_job_id(self):
        payload = _json_load(self.single_flight_lock_path)
        return str(payload.get('job_id', '') or '').strip() if isinstance(payload, dict) else ''

    def _heartbeat_age_sec(self, job):
        epoch = _parse_iso_utc_to_epoch((job or {}).get('heartbeat_at_utc'))
        if epoch is None:
            return None
        return max(0, int(time.time() - epoch))

    def _running_job_needs_restart_recovery(self, job):
        payload = job if isinstance(job, dict) else {}
        if str(payload.get('status', '') or '') != 'running':
            return False
        try:
            pid = int(payload.get('worker_pid', 0) or 0)
        except Exception:
            pid = 0
        if pid and pid == os.getpid():
            return False
        mode = str(payload.get('worker_mode', '') or '').strip()
        age = self._heartbeat_age_sec(payload)
        grace = _int_env('MEDICAFE_SUPPORT_SEND_RESTART_RECOVERY_GRACE_SEC', 60)
        if mode in ('detached_spawned', 'detached_worker') and age is not None and age < max(5, grace):
            return False
        return True

    def recover_jobs_after_launcher_restart(self, source='', installed_version=''):
        self._ensure_dirs()
        wanted_source = str(source or '').strip()
        wanted_version = str(installed_version or '').strip()
        recovered = []
        queued = []
        with self._state_lock:
            queue_state = self._read_queue_state()
            queued_ids = queue_state.get('queued_job_ids', [])
            for job_id in self._list_job_ids():
                job = self._read_job(job_id)
                if not job:
                    continue
                if wanted_source and str(job.get('source', '') or '') != wanted_source:
                    continue
                if wanted_version and str(job.get('installed_version', '') or '') != wanted_version:
                    continue
                status = str(job.get('status', '') or '')
                should_queue = False
                reason = ''
                if status == 'queued':
                    should_queue = True
                    reason = 'queued_job_resumed_after_launcher_restart'
                elif status == 'running' and self._running_job_needs_restart_recovery(job):
                    should_queue = True
                    reason = 'running_job_recovered_after_launcher_restart'
                elif status in ('failed', 'blocked', 'canceled'):
                    should_queue = True
                    reason = 'terminal_job_retried_after_launcher_restart'
                if not should_queue:
                    continue
                previous_status = status
                job['status'] = 'queued'
                job['policy_decision'] = 'queued'
                job['policy_reason'] = reason
                job['progress_stage'] = reason
                job['heartbeat_at_utc'] = _utc_now()
                job['result_ok'] = False
                job['result_message'] = 'Post-update support send recovered after launcher restart.'
                job['worker_pid'] = ''
                job['worker_started_at_utc'] = ''
                job['worker_mode'] = ''
                try:
                    job['recovery_count'] = int(job.get('recovery_count', 0) or 0) + 1
                except Exception:
                    job['recovery_count'] = 1
                job['previous_status_before_recovery'] = previous_status
                self._write_job(job)
                self._append_job_log(job_id, 'recovered after launcher restart from status={0}'.format(previous_status))
                self._log('job_recovered_after_restart', self._job_log_payload(job, {'previous_status': previous_status}))
                if job_id not in queued_ids:
                    queued_ids.append(job_id)
                recovered.append(job_id)
                if previous_status == 'running' and self._lock_owner_job_id() == job_id:
                    _safe_remove(self.single_flight_lock_path)
            self._write_queue_state(queued_ids)
            queued = list(queued_ids)
        if recovered or queued:
            self._ensure_worker_locked()
        return {'recovered_job_ids': recovered, 'queued_job_ids': queued}
    def _ensure_worker_locked(self):
        if self._worker_thread and self._worker_thread.is_alive():
            return
        t = threading.Thread(target=self._worker_loop)
        t.daemon = True
        self._worker_thread = t
        t.start()

    def _detached_worker_script_path(self):
        return os.path.join(self.repo_root, 'scripts', 'support_send_worker.py')

    def _spawn_detached_worker(self, job_id):
        script = self._detached_worker_script_path()
        if not os.path.isfile(script):
            return False
        py = self.python_exe or sys.executable
        if not py:
            return False
        cmd = [
            py,
            script,
            '--repo-root', self.repo_root,
            '--lab-root', self.lab_root,
            '--job-id', str(job_id or ''),
        ]
        kwargs = {
            'cwd': self.repo_root,
            'stdout': subprocess.DEVNULL,
            'stderr': subprocess.DEVNULL,
        }
        try:
            create_flag = int(getattr(subprocess, 'CREATE_NEW_CONSOLE', 0) or 0)
            if create_flag:
                kwargs['creationflags'] = create_flag
        except Exception:
            pass
        try:
            subprocess.Popen(cmd, **kwargs)
            return True
        except Exception:
            return False

    def _dequeue_next_job_locked(self):
        queue_state = self._read_queue_state()
        queued_ids = queue_state.get('queued_job_ids', [])
        jobs = []
        keep_ids = []
        for job_id in queued_ids:
            job = self._read_job(job_id)
            if not job:
                continue
            if str(job.get('status', '') or '') != 'queued':
                continue
            jobs.append(job)
            keep_ids.append(job_id)
        if not jobs:
            self._write_queue_state([])
            return {}
        jobs.sort(key=self.policy.queue_sort_key)
        picked = jobs[0]
        picked_id = str(picked.get('job_id', '') or '')
        new_queue = [jid for jid in keep_ids if jid != picked_id]
        self._write_queue_state(new_queue)
        return picked

    def _worker_loop(self):
        while True:
            with self._state_lock:
                job = self._dequeue_next_job_locked()
            if not job:
                return
            self._run_single_job(job)

    def _execute_send(self, job, progress_callback):
        from MediCafe import cloud_readiness
        send_type = str(job.get('send_type', '') or '').strip()
        frozen = job.get('frozen_recommendation', {}) if isinstance(job.get('frozen_recommendation', {}), dict) else {}
        if send_type == 'run_evidence':
            return cloud_readiness.send_latest_run_evidence_bundle(
                self.repo_root,
                progress_callback=progress_callback,
                send_source=str(job.get('source', '') or 'background_support_send_job'),
                operator_execution_mode=str(job.get('operator_execution_mode', '') or 'background_queue'),
                frozen_recommendation=frozen if frozen else None,
                support_send_job_context=self._job_log_payload(job),
            )
        return cloud_readiness.send_latest_system_health_pack(
            self.repo_root,
            _bool_env,
            progress_callback=progress_callback,
            recommendation=frozen if frozen else None,
            send_source=str(job.get('source', '') or 'background_support_send_job'),
                operator_execution_mode=str(job.get('operator_execution_mode', '') or 'background_queue'),
                frozen_recommendation=frozen if frozen else None,
                support_send_job_context=self._job_log_payload(job),
            )

    def _run_single_job(self, job):
        job_id = str(job.get('job_id', '') or '').strip()
        if not job_id:
            return
        if self.single_flight and not self._acquire_single_flight(job_id):
            job['status'] = 'blocked'
            job['policy_reason'] = 'single_flight_busy'
            job['result_message'] = 'Busy; could not acquire single-flight lock.'
            self._write_job(job)
            self._append_job_log(job_id, job.get('result_message'))
            self._log('job_blocked', self._job_log_payload(job))
            with self._state_lock:
                queue_state = self._read_queue_state()
                queued_ids = queue_state.get('queued_job_ids', [])
                if job_id not in queued_ids:
                    queued_ids.append(job_id)
                    self._write_queue_state(queued_ids)
            return
        try:
            job['status'] = 'running'
            job['started_at_utc'] = _utc_now()
            job['heartbeat_at_utc'] = _utc_now()
            job['progress_stage'] = 'starting'
            job['worker_pid'] = str(os.getpid())
            if str(job.get('worker_mode', '') or '') == 'detached_spawned':
                job['worker_mode'] = 'detached_worker'
            else:
                job['worker_mode'] = 'in_process_worker'
            job['worker_started_at_utc'] = _utc_now()
            self._write_job(job)
            self._append_job_log(job_id, 'job started')
            self._log('job_started', self._job_log_payload(job))

            def _progress(stage):
                j = self._read_job(job_id)
                if not j:
                    return
                j['heartbeat_at_utc'] = _utc_now()
                j['progress_stage'] = str(stage or '').strip()
                self._write_job(j)
                self._append_job_log(job_id, 'stage: {0}'.format(j['progress_stage'] or '-'))
                self._log('job_progress', self._job_log_payload(j))

            ok, msg, data = self._execute_send(job, _progress)
            job = self._read_job(job_id)
            if not job:
                return
            job['finished_at_utc'] = _utc_now()
            job['status'] = 'succeeded' if bool(ok) else 'failed'
            job['result_ok'] = bool(ok)
            job['result_message'] = str(msg or '')
            if isinstance(data, dict):
                job['delivery_status_path'] = str(data.get('delivery_status_path', '') or '')
                paths = []
                job['bundle_zip_path'] = str(data.get('zip_path', '') or '')
                for key in ('zip_path', 'triage_path', 'index_path', 'context_attachment_path'):
                    val = str(data.get(key, '') or '').strip()
                    if val:
                        paths.append(val)
                if paths:
                    job['artifact_paths'] = paths
                sent_anchor = str(data.get('run_id', '') or '').strip()
                if sent_anchor and not job.get('sent_anchor_run_id'):
                    job['sent_anchor_run_id'] = sent_anchor
            self._write_job(job)
            self._append_job_log(job_id, 'job finished status={0} message={1}'.format(job.get('status'), job.get('result_message')))
            self._log('job_finished', self._job_log_payload(job))
        except Exception as exc:
            job = self._read_job(job_id)
            if not job:
                return
            tb_path = os.path.join(self.jobs_dir, 'job_{0}_traceback.txt'.format(job_id))
            try:
                with open(tb_path, 'w') as handle:
                    handle.write(traceback.format_exc())
            except Exception:
                tb_path = ''
            job['finished_at_utc'] = _utc_now()
            job['status'] = 'failed'
            job['result_ok'] = False
            job['result_message'] = 'Error: {0}'.format(exc)
            job['error'] = {
                'type': exc.__class__.__name__,
                'detail': str(exc),
                'traceback_path': tb_path,
            }
            self._write_job(job)
            self._append_job_log(job_id, 'job failed: {0}'.format(exc))
            self._log('job_failed', self._job_log_payload(job, {'result_message': 'Error: {0}'.format(exc)}))
        finally:
            self._release_single_flight()

    def run_job_by_id(self, job_id):
        self._ensure_dirs()
        job = self._read_job(job_id)
        if not job:
            return False
        self._run_single_job(job)
        return True

    def list_jobs(self, limit=25):
        self._ensure_dirs()
        rows = []
        for job_id in self._list_job_ids():
            path = self._job_json_path(job_id)
            try:
                mtime = os.path.getmtime(path)
            except Exception:
                mtime = 0.0
            payload = self._read_job(job_id)
            if payload:
                payload['_mtime'] = mtime
                rows.append(payload)
        rows.sort(key=lambda x: x.get('_mtime', 0.0), reverse=True)
        return rows[:max(1, int(limit))]

    def retry(self, job_id):
        job = self._read_job(job_id)
        if not job:
            return {'accepted': False, 'policy_decision': 'rejected', 'policy_reason': 'missing_job', 'message': 'Job not found.'}
        source_scope_hash = str(job.get('source_scope_hash', '') or '').strip()
        if not source_scope_hash:
            dedup_key = str(job.get('dedup_key', '') or '')
            parts = dedup_key.split('|', 4)
            if len(parts) == 5:
                source_scope_hash = parts[4]
        return self.enqueue({
            'source': 'retry_{0}'.format(str(job.get('source', '') or 'support_send')),
            'priority': str(job.get('priority', '') or 'normal'),
            'send_type': str(job.get('send_type', '') or ''),
            'anchor_run_id': str(job.get('anchor_run_id', '') or ''),
            'context_run_id': str(job.get('context_run_id', '') or ''),
            'issue_code': str(job.get('issue_code', '') or ''),
            'requested_artifact_scope': str(job.get('requested_artifact_scope', '') or ''),
            'source_scope_hash': source_scope_hash,
            'operator_execution_mode': str(job.get('operator_execution_mode', '') or ''),
            'installed_version': str(job.get('installed_version', '') or ''),
            'recommendation_action_kind': str(job.get('recommendation_action_kind', '') or ''),
            'frozen_recommendation': job.get('frozen_recommendation', {}) if isinstance(job.get('frozen_recommendation', {}), dict) else {},
        })

    def read_notice_state(self):
        return _json_load(self.notice_state_path)

    def write_notice_state(self, state):
        payload = state if isinstance(state, dict) else {}
        payload['updated_at_utc'] = _utc_now()
        _json_dump_atomic(self.notice_state_path, payload)
