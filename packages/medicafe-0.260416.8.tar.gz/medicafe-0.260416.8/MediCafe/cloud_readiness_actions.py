#!/usr/bin/env python
"""
Action and phase-orchestration helpers extracted from MediCafe.cloud_readiness.
"""
from __future__ import print_function

from functools import wraps


_LOCAL_HELPER_NAMES = set(['_cloud_readiness_module', '_sync_cloud_readiness_globals', '_with_cloud_readiness_globals'])


def _cloud_readiness_module():
    from MediCafe import cloud_readiness as _cr
    return _cr


def _sync_cloud_readiness_globals():
    cr = _cloud_readiness_module()
    g = globals()
    for name, value in cr.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_cloud_readiness_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_cloud_readiness_globals()
        return fn(*args, **kwargs)
    return _wrapped

@_with_cloud_readiness_globals
def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)

@_with_cloud_readiness_globals
def _select_latest_evidence_files(lab_root, prefix_specs, prefer_diagnostics_lineage=False):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id = ''
    if prefer_diagnostics_lineage:
        run_id = _preferred_evidence_run_id(lab_root, reports_dir)
    if run_id:
        candidate_path = ''
        for suffix in suffix_choices:
            path = os.path.join(reports_dir, '{0}{1}{2}'.format(primary_prefix, run_id, suffix))
            if os.path.isfile(path):
                candidate_path = path
                break
        if not candidate_path:
            run_id = ''
    if not run_id:
        run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            group = {'prefix': prefix, 'suffixes': ('.json', '.txt')}
            for path in _collect_group_paths_for_run(reports_dir, run_id, group):
                basename = os.path.basename(path)
                if basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files

@_with_cloud_readiness_globals
def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(
        lab_root,
        prefix_specs,
        prefer_diagnostics_lineage=False,
    )
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                extra_meta_key: True,
                'send_source': 'manual_{0}'.format(extra_meta_key),
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)

@_with_cloud_readiness_globals
def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_STARTUP,
            entrypoint=shadow_orchestrator.ENTRYPOINT_STARTUP,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_pipeline_startup',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, 'Cloud Readiness startup orchestration failed: {0}'.format(e), None)

@_with_cloud_readiness_globals
def open_phase_b_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No artifact discovery summaries found.', None)

@_with_cloud_readiness_globals
def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)

@_with_cloud_readiness_globals
def run_phase_b_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'discover_artifacts.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def send_phase_b_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('artifact_discovery_summary_', None)],
        'phase_b_evidence',
        'No discovery summaries to attach.',
    )

@_with_cloud_readiness_globals
def open_phase_c_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'ingest_write_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase C ingest summaries found.', None)

@_with_cloud_readiness_globals
def run_phase_c_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'ingest_from_manifest.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def send_phase_c_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl')],
        'phase_c_evidence',
        'No Phase C summaries or anomalies to attach.',
    )

@_with_cloud_readiness_globals
def open_phase_d_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_canonical_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D summaries found.', None)

@_with_cloud_readiness_globals
def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)

@_with_cloud_readiness_globals
def run_phase_d_manual(repo_root, python_exe, env, artifact_classes=None):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_qa_canonical.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        classes = _normalize_phase_d_reprocess_classes(artifact_classes)
        if classes:
            proc_env['MEDICAFE_PHASE_D_ARTIFACT_CLASSES'] = ','.join(classes)
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_phase_d_dat_smoke(
        repo_root,
        python_exe,
        env,
        reference_phase_d_summary_path=None,
        recommendation_anchor_run_id='',
        recommendation_context_run_id='',
        recommendation_issue_code=''):
    """
    Run scripts/unified_model/run_phase_d_dat_smoke.py against repo_root/phase_d_dat_smoke_lab (background).
    Diagnostic only; does not close QA milestone. Reports: reports/phase_d_dat_smoke_report_<anchor>.txt

    Returns (ok, message, meta).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_phase_d_dat_smoke.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    requested_anchor = ''
    requested_context = ''
    requested_issue = ''
    try:
        smoke_lab = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
        if is_pipeline_running(smoke_lab):
            return (False, 'DAT smoke already running for phase_d_dat_smoke_lab.', {'already_running': True})
        requested_anchor = str(recommendation_anchor_run_id or '').strip()
        requested_context = str(recommendation_context_run_id or '').strip()
        requested_issue = str(recommendation_issue_code or '').strip()
        now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        update_phase_d_dat_smoke_state(
            repo_root,
            anchor_run_id=requested_anchor,
            context_run_id=requested_context,
            issue_code=requested_issue,
            started_at_utc=now_utc,
            status='started',
        )
        state_path = phase_d_dat_smoke_state_path(repo_root)
        proc_env = os.environ.copy()
        if env:
            proc_env.update(env)
        proc_env['MEDICAFE_LAB_DIR'] = smoke_lab
        args = [python_exe, script, '--lab-dir', smoke_lab, '--state-path', state_path]
        ref_path = str(reference_phase_d_summary_path or '').strip()
        if ref_path:
            args.extend(['--reference-phase-d-summary', ref_path])
        if requested_anchor:
            args.extend(['--requested-anchor-run-id', requested_anchor])
        if requested_context:
            args.extend(['--requested-context-run-id', requested_context])
        if requested_issue:
            args.extend(['--requested-issue-code', requested_issue])
        subprocess.Popen(
            args,
            cwd=script_repo_root,
            env=proc_env,
        )
        return (True, '', {
            'async_launch': True,
            'reference_phase_d_summary_path': ref_path,
            'requested_anchor_run_id': requested_anchor,
            'requested_context_run_id': requested_context,
            'requested_issue_code': requested_issue,
        })
    except Exception as e:
        try:
            now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            st = read_phase_d_dat_smoke_state(repo_root)
            st['last_requested_anchor_run_id'] = str(requested_anchor or '').strip()
            st['last_requested_context_run_id'] = str(requested_context or '').strip()
            st['last_remediation_issue_code'] = str(requested_issue or '').strip()
            st['last_finished_at_utc'] = now_utc
            st['last_status'] = 'failed'
            st['last_report_path'] = ''
            st['last_assessment'] = 'spawn_failed'
            st['cooldown_until_utc'] = ''
            write_phase_d_dat_smoke_state(repo_root, st)
        except Exception:
            pass
        return (False, str(e), None)

@_with_cloud_readiness_globals
def preview_historical_phase_d_reprocess(repo_root, artifact_classes=None, remediation_context_run_id=None):
    if _preview_historical_phase_d_reprocess_impl is None:
        return (False, 'Historical Phase D re-evaluation helper unavailable.', None)
    lab_root = resolve_lab_root(repo_root)
    data = _preview_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    ok = bool(isinstance(data, dict) and data.get('ok'))
    msg = '' if ok else str((data or {}).get('error', '') or 'Unable to build historical Phase D re-evaluation preview.')
    return (ok, msg, data)

@_with_cloud_readiness_globals
def run_historical_phase_d_reprocess(repo_root, python_exe, env, artifact_classes=None, remediation_context_run_id=None):
    if _execute_historical_phase_d_reprocess_impl is None:
        return (False, 'Historical Phase D re-evaluation helper unavailable.', None)
    lab_root = resolve_lab_root(repo_root)
    data = _execute_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    if not isinstance(data, dict) or not data.get('ok'):
        msg = str((data or {}).get('error', '') or 'Unable to reset historical Phase D reject state.')
        return (False, msg, data)
    classes = _normalize_phase_d_reprocess_classes(data.get('targeted_artifact_classes', []))
    ok_run, msg_run, _ = run_phase_d_manual(repo_root, python_exe, env, artifact_classes=classes)
    if not ok_run:
        data['phase_d_launch_error'] = msg_run
        return (
            False,
            'Historical Phase D reject state was reset, but the filtered Phase D rerun could not be started: {0}'.format(msg_run),
            data,
        )
    msg = 'Historical Phase D re-evaluation started for {0}. Return to 1) Follow recommendation after the rerun settles.'.format(
        ', '.join(classes) or 'the targeted classes'
    )
    return (True, msg, data)

@_with_cloud_readiness_globals
def send_phase_d_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'phase_d_evidence',
        'No Phase D summaries or reject samples to attach.',
    )

@_with_cloud_readiness_globals
def open_phase_e_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_parity_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E summaries found.', None)

@_with_cloud_readiness_globals
def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)

@_with_cloud_readiness_globals
def run_phase_e_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_projection_parity.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def send_phase_e_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'phase_e_evidence',
        'No Phase E summaries or deviation samples to attach.',
    )

@_with_cloud_readiness_globals
def run_shadow_pipeline(repo_root, python_exe, env):
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MANUAL,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=_env_flag,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_shadow_pipeline_manual',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)

@_with_cloud_readiness_globals
def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)

@_with_cloud_readiness_globals
def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    send_run_id = ''
    for _basename, _fullpath in phase_files:
        if str(_basename).startswith('shadow_run_report_'):
            send_run_id = _shadow_run_report_run_id_from_path(_fullpath)
            if send_run_id:
                break
    if not send_run_id:
        try:
            state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            send_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
        except Exception:
            send_run_id = ''
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'phase_f_evidence': True,
                'run_id': send_run_id,
                'send_source': 'manual_phase_f_evidence',
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)

@_with_cloud_readiness_globals
def open_report_delivery_status(repo_root):
    """
    Write and return a compact delivery-status snapshot for support bundle sends.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'report_delivery_status.txt')
        lines = get_report_delivery_status_lines(lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope='both',
        write_report=False,
        cloud_required=False,
        migration_stage='xp_validation'):
    """Run audit_migration_health synchronously and return parsed summary payload.

    Returns (ok, msg, data) where data includes parsed payload + operator hints.
    """
    script_info = _audit_script_path(repo_root, python_exe=python_exe)
    if not script_info.get('ok'):
        return (False, script_info.get('message') or 'audit_migration_health.py not found.', None)
    script = script_info.get('path')
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        if env and isinstance(env, dict):
            for k in ('GOOGLE_CLOUD_PROJECT', 'MEDICAFE_HEALTH_URL'):
                if env.get(k):
                    proc_env[k] = str(env.get(k))

        stage = str(migration_stage or 'xp_validation').strip().lower() or 'xp_validation'
        cmd = [
            python_exe,
            script,
            '--scope',
            scope,
            '--migration-stage',
            stage,
            '--json',
            '--no-text',
            '--output-mode',
            'write' if write_report else 'stdout',
        ]
        if cloud_required:
            cmd.append('--cloud-required')
        p = subprocess.Popen(cmd, cwd=script_info.get('cwd') or repo_root, env=proc_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out_b, err_b = p.communicate()
        out = out_b.decode('utf-8', 'replace') if hasattr(out_b, 'decode') else str(out_b)
        err = err_b.decode('utf-8', 'replace') if hasattr(err_b, 'decode') else str(err_b)
        payload = _extract_json_object_from_text(out)
        if not payload:
            return (False, 'Audit did not return parseable JSON. {0}'.format(err.strip() or 'No stderr.'), None)
        hints = _audit_hint_lines_from_payload(payload)
        data = {'payload': payload, 'hints': hints, 'stdout': out, 'stderr': err, 'returncode': int(p.returncode)}
        msg = 'Audit completed with status={0}, score={1}, exit_code={2}'.format(
            payload.get('overall', {}).get('status', '?'),
            payload.get('overall', {}).get('score', '?'),
            payload.get('overall', {}).get('exit_code', p.returncode),
        )
        return (True, msg, data)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def open_latest_migration_health_report(repo_root):
    """Open latest audit_migration_health summary report (txt preferred, then json)."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'audit_migration_health_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No migration health audit summaries found. Run an audit first.', None)
_IMPL__find_latest_run_id_by_prefix = _find_latest_run_id_by_prefix
_IMPL__select_latest_evidence_files = _select_latest_evidence_files
_IMPL__send_phase_evidence = _send_phase_evidence
_IMPL_run_pipeline = run_pipeline
_IMPL_open_phase_b_summary = open_phase_b_summary
_IMPL_open_manifest_location = open_manifest_location
_IMPL_run_phase_b_manual = run_phase_b_manual
_IMPL_send_phase_b_evidence = send_phase_b_evidence
_IMPL_open_phase_c_summary = open_phase_c_summary
_IMPL_run_phase_c_manual = run_phase_c_manual
_IMPL_send_phase_c_evidence = send_phase_c_evidence
_IMPL_open_phase_d_summary = open_phase_d_summary
_IMPL_open_phase_d_reject_sample = open_phase_d_reject_sample
_IMPL_run_phase_d_manual = run_phase_d_manual
_IMPL_run_phase_d_dat_smoke = run_phase_d_dat_smoke
_IMPL_preview_historical_phase_d_reprocess = preview_historical_phase_d_reprocess
_IMPL_run_historical_phase_d_reprocess = run_historical_phase_d_reprocess
_IMPL_send_phase_d_evidence = send_phase_d_evidence
_IMPL_open_phase_e_summary = open_phase_e_summary
_IMPL_open_phase_e_deviation_samples = open_phase_e_deviation_samples
_IMPL_run_phase_e_manual = run_phase_e_manual
_IMPL_send_phase_e_evidence = send_phase_e_evidence
_IMPL_run_shadow_pipeline = run_shadow_pipeline
_IMPL_open_phase_f_shadow_report = open_phase_f_shadow_report
_IMPL_open_phase_f_evidence_index = open_phase_f_evidence_index
_IMPL_run_phase_f_manual = run_phase_f_manual
_IMPL_run_phase_f_manual_for_run_id = run_phase_f_manual_for_run_id
_IMPL_send_phase_f_evidence = send_phase_f_evidence
_IMPL_open_report_delivery_status = open_report_delivery_status
_IMPL_run_migration_health_audit = run_migration_health_audit
_IMPL_open_latest_migration_health_report = open_latest_migration_health_report
