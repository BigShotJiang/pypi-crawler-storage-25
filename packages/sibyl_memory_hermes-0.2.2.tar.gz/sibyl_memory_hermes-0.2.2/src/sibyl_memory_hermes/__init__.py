"""sibyl-memory-hermes — Hermes Agent memory provider.

Public exports:
    SibylMemoryProvider     drop-in memory provider for Hermes v0.10.0+
    DEFAULT_DB_PATH         ~/.sibyl-memory/memory.db
    DEFAULT_CRED_PATH       ~/.sibyl-memory/credentials.json
    load_credentials        helper for reading the activation credential file
    HermesMemoryError       base exception (re-exports SibylMemoryError)

Quickstart:

    from sibyl_memory_hermes import SibylMemoryProvider
    from hermes_agent import Agent

    # Auto-detects ~/.sibyl-memory/credentials.json from `sibyl init`
    agent = Agent(memory=SibylMemoryProvider())

    # Or explicit:
    agent = Agent(
        memory=SibylMemoryProvider(
            db_path="~/.sibyl-memory/memory.db",
            tenant_id="alice@example.com",
        )
    )
"""
from sibyl_memory_client import SibylMemoryError

from .credentials import (
    DEFAULT_CRED_PATH,
    DEFAULT_DB_PATH,
    Credentials,
    CredentialsNotFoundError,
    load_credentials,
)
from .provider import SibylMemoryProvider

__version__ = "0.2.1"

# Backwards-compat alias for callers who want a Hermes-namespaced exception type
HermesMemoryError = SibylMemoryError

__all__ = [
    "SibylMemoryProvider",
    "Credentials",
    "CredentialsNotFoundError",
    "DEFAULT_DB_PATH",
    "DEFAULT_CRED_PATH",
    "load_credentials",
    "HermesMemoryError",
    "__version__",
]
