"""SibylMemoryProvider — the Hermes-compatible memory provider.

DESIGN NOTES
============

Hermes v0.10.0's memory-provider contract is the canonical target, but the
provider is deliberately framework-agnostic: any agent framework that calls
the documented methods directly (LangChain BaseMemory-style, custom rolls,
or Hermes itself) gets the same behavior.

The provider routes operations onto the correct memory tier:

    ┌─────────────────────────────────────────────────────────────┐
    │   intent                  │ tier         │ storage call       │
    ├─────────────────────────────────────────────────────────────┤
    │   "save the conversation" │ COLD journal │ write_event(...)   │
    │   "remember this fact"    │ WARM entity  │ set_entity(...)    │
    │   "current state"         │ HOT state    │ set_state(...)     │
    │   "lookup runbook"        │ REFERENCE    │ set_reference(...) │
    │   "archive stale entity"  │ ARCHIVE      │ archive_entity     │
    │   "search by content"     │ FTS5         │ search_entities    │
    └─────────────────────────────────────────────────────────────┘

The split is intentional. Vector-DB-only providers collapse all of the above
onto similarity search, which loses structure. Sibyl Memory preserves it.

HERMES CONTRACT BINDING
=======================

If Hermes is installed (`pip install sibyl-memory-hermes[hermes]`), the
provider auto-inherits Hermes' `MemoryProvider` ABC at import time so
isinstance checks pass. If not installed, the provider works standalone —
this is important because the plugin should be usable by Hermes developers
who pin to a specific Hermes version SIBYL hasn't seen yet.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from sibyl_memory_client import DEFAULT_TENANT, MemoryClient
from sibyl_memory_client.exceptions import NotFoundError

from .credentials import (
    DEFAULT_CRED_PATH,
    DEFAULT_DB_PATH,
    Credentials,
    CredentialsNotFoundError,
    load_credentials,
)

# Soft-detect Hermes' MemoryProvider base class. If absent, fall back to
# `object` so the provider works standalone. Sentinel `_HERMES_BOUND` lets
# tests assert the binding state.
_HERMES_BOUND = False
try:  # pragma: no cover - exercised only when hermes is installed
    from hermes_agent.memory import MemoryProvider as _HermesBase  # type: ignore[import-untyped]

    _HERMES_BOUND = True
except Exception:  # pragma: no cover
    _HermesBase = object  # type: ignore[assignment, misc]


class SibylMemoryProvider(_HermesBase):  # type: ignore[misc, valid-type]
    """Hermes Agent memory provider backed by sibyl-memory-client.

    Args:
        db_path:        path to the local SQLite database. Defaults to
                        ~/.sibyl-memory/memory.db (the path `sibyl init`
                        creates).
        tenant_id:      explicit tenant override. If None, credentials.json
                        is loaded; if also missing, DEFAULT_TENANT is used.
        credentials_path: override for credentials.json discovery.
        require_credentials: if True, raise CredentialsNotFoundError when
                        the file is missing. Default False — degrade to
                        DEFAULT_TENANT so callers can run pre-activation.
        autoload_credentials: if True (default), read credentials.json on
                        construction and apply tenant_id from it.
    """

    def __init__(
        self,
        db_path: str | Path = DEFAULT_DB_PATH,
        *,
        tenant_id: str | None = None,
        credentials_path: str | Path = DEFAULT_CRED_PATH,
        require_credentials: bool = False,
        autoload_credentials: bool = True,
    ) -> None:
        # Resolve tenant: explicit > credentials > default
        resolved_tenant = tenant_id
        creds: Credentials | None = None

        if resolved_tenant is None and autoload_credentials:
            try:
                creds = load_credentials(credentials_path)
                resolved_tenant = creds.tenant_id
            except CredentialsNotFoundError:
                if require_credentials:
                    raise
                resolved_tenant = DEFAULT_TENANT
            except (OSError, ValueError):
                if require_credentials:
                    raise
                resolved_tenant = DEFAULT_TENANT

        if resolved_tenant is None:
            resolved_tenant = DEFAULT_TENANT

        self._credentials = creds
        # Plumb account_id, session_token, tier, and the HMAC-signed
        # credentials claim through to the client so the cap gate can:
        #   1. verify free-tier writes against the authoritative server when
        #      the local DB approaches 2 MB (v0.3.0 behavior), and
        #   2. include the credentials_signature + claim in cap-check
        #      requests so the server can detect local credentials.json
        #      tampering and log it as telemetry (v0.3.1+).
        client_tier = creds.tier if creds else "free"
        client_account_id = creds.account_id if creds else None
        client_session_token = creds.session_token if creds else None
        # Build the canonical signed-claim object that matches the server's
        # SIGNING_FIELDS shape. Order doesn't matter on the JSON wire —
        # the server canonicalizes by field name.
        client_claim = None
        client_signature = None
        if creds and creds.signature:
            client_signature = creds.signature
            client_claim = {
                "account_id": creds.account_id,
                "tenant_id": creds.tenant_id,
                "tier": creds.tier,
                "email": creds.email,
                "wallet": creds.wallet,
                "issued_at": creds.issued_at,
                "schema_version": creds.schema_version,
            }
        self._client = MemoryClient.local(
            db_path,
            tenant_id=resolved_tenant,
            tier=client_tier,
            account_id=client_account_id,
            session_token=client_session_token,
            credentials_claim=client_claim,
            credentials_signature=client_signature,
        )

        # Call MemoryProvider.__init__ if Hermes is around — be defensive
        # because we don't know Hermes' constructor signature here.
        if _HERMES_BOUND:
            try:  # pragma: no cover
                super().__init__()
            except TypeError:
                pass

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------
    @property
    def client(self) -> MemoryClient:
        """The underlying MemoryClient. Use for advanced operations not
        covered by the provider surface."""
        return self._client

    @property
    def credentials(self) -> Credentials | None:
        return self._credentials

    @property
    def tenant_id(self) -> str:
        return self._client.get_tenant()

    @property
    def hermes_bound(self) -> bool:
        """True if Hermes' MemoryProvider ABC was found at import time."""
        return _HERMES_BOUND

    # ==================================================================
    # HERMES-STYLE PROVIDER SURFACE
    # ==================================================================
    # The Hermes v0.10.0 memory contract uses save_context / load_context
    # for the per-turn agent memory loop. We map these onto the journal
    # (COLD) tier — every turn is an event in the agent's session log.
    #
    # remember() / recall() / forget() are the higher-level fact-store
    # operations that map onto entities (WARM tier).
    # ==================================================================

    def save_context(
        self,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        *,
        ts: str | None = None,
    ) -> str:
        """Persist a single turn (inputs + outputs) to the journal.

        Returns the journal event id."""
        return self._client.write_event(
            evaluated=inputs,
            acted=outputs,
            ts=ts,
        )

    def load_context(self, *, limit: int = 20) -> list[dict[str, Any]]:
        """Return the most recent N turns from the journal."""
        return self._client.read_events(limit=limit)

    def clear_context(self) -> None:
        """No-op for now — journal events are append-only by design.

        If a caller genuinely wants to wipe the journal, they should drop
        the database file. This method exists for Hermes contract
        compatibility."""
        return None

    # ------------------------------------------------------------------
    # Fact store (WARM tier)
    # ------------------------------------------------------------------
    def remember(
        self,
        category: str,
        name: str,
        body: dict[str, Any] | list[Any],
        *,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Upsert an entity. Single source of truth per (tenant, category, name)."""
        return self._client.set_entity(category, name, body, status=status)

    def recall(self, category: str, name: str) -> dict[str, Any] | None:
        """Return the entity body, or None if absent (Hermes-style soft miss).

        T2-2 fix: previously caught bare `Exception`, which swallowed
        StorageError / TenantError / SchemaError as "not found". That
        masked underlying-storage failures end-to-end. Now narrows to
        NotFoundError only — every other exception propagates so the
        caller can surface or retry.
        """
        try:
            return self._client.get_entity(category, name)
        except NotFoundError:
            return None

    def list(  # noqa: A003 — Hermes-compatible name
        self,
        category: str | None = None,
        *,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        return self._client.list_entities(category=category, status=status, limit=limit)

    def forget(self, category: str, name: str) -> bool:
        return self._client.delete_entity(category, name)

    def archive(
        self,
        category: str,
        name: str,
        *,
        reason: str | None = None,
    ) -> dict[str, Any]:
        return self._client.archive_entity(category, name, reason=reason)

    # ------------------------------------------------------------------
    # State documents (HOT tier)
    # ------------------------------------------------------------------
    def set_state(self, key: str, body: dict[str, Any] | list[Any]) -> None:
        self._client.set_state(key, body)

    def get_state(self, key: str) -> dict[str, Any] | None:
        return self._client.get_state(key)

    # ------------------------------------------------------------------
    # Reference docs (REFERENCE tier)
    # ------------------------------------------------------------------
    def set_reference(
        self,
        key: str,
        body: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._client.set_reference(key, body, metadata=metadata)

    def get_reference(self, key: str) -> dict[str, Any] | None:
        return self._client.get_reference(key)

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    def search(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        """FTS5 full-text search across entities. Returns ranked results."""
        return self._client.search_entities(query, limit=limit)

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------
    def health(self) -> dict[str, Any]:
        """Return a small diagnostic dict — used by `sibyl status`."""
        db_path = self._client.storage.db_path
        return {
            "ok": True,
            "schema_version": self._client.schema_version(),
            "db_path": str(db_path),
            "db_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "tenant_id": self.tenant_id,
            "hermes_bound": _HERMES_BOUND,
            "tier": self._credentials.tier if self._credentials else "free",
            "email": self._credentials.email if self._credentials else None,
        }

    # ------------------------------------------------------------------
    # repr
    # ------------------------------------------------------------------
    def __repr__(self) -> str:  # pragma: no cover - trivial
        return (
            f"SibylMemoryProvider(db={self._client.storage.db_path}, "
            f"tenant={self.tenant_id!r}, hermes_bound={_HERMES_BOUND})"
        )
