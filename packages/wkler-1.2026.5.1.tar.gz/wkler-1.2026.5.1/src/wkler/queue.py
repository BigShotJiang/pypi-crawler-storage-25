from __future__ import annotations

import asyncio
import datetime as dt
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from qler import JobStatus, Queue
from qler.models import Job
from sqler import F

from wkler.api.client import WaniKaniClient
from wkler.review.engine import CompletedReview

QUEUE_NAME = "wk_reviews"
SUBMIT_TASK_PATH = "wkler.submit_review"
MAX_RETRIES = 5
RETRY_DELAY_SECONDS = 30
JOB_PRIORITY = 100


@dataclass(slots=True)
class QueueCounts:
    pending: int
    failed: int
    running: int
    completed: int
    cancelled: int


@dataclass(slots=True)
class QueueJobView:
    ulid: str
    status: str
    assignment_id: int | None
    subject_id: int | None
    retry_count: int
    max_retries: int
    eta: int
    updated_at: int
    last_error: str | None


@dataclass(slots=True)
class RetryReport:
    retried_from_failed: int
    claimed: int
    submitted: int
    failed: int
    remaining_pending: int
    remaining_failed: int


class ReviewSubmissionQueue:
    """Persist and retry failed WK review submissions via qler."""

    def __init__(self, db_path: Path, api_token: str) -> None:
        self._db_path = Path(db_path).expanduser()
        self._api_token = api_token

    def enqueue_failed_submission(
        self,
        review: CompletedReview,
        *,
        error_message: str,
    ) -> str:
        return asyncio.run(
            self.enqueue_failed_submission_async(review, error_message=error_message)
        )

    def queue_counts(self) -> QueueCounts:
        return asyncio.run(self.queue_counts_async())

    def list_jobs(self, *, status: str, limit: int) -> list[QueueJobView]:
        return asyncio.run(self.list_jobs_async(status=status, limit=limit))

    def retry(
        self,
        *,
        limit: int,
        retry_failed: bool,
        dry_run: bool,
        all_jobs: bool,
        job_ulid: str | None = None,
    ) -> RetryReport:
        return asyncio.run(
            self.retry_async(
                limit=limit,
                retry_failed=retry_failed,
                dry_run=dry_run,
                all_jobs=all_jobs,
                job_ulid=job_ulid,
            )
        )

    async def enqueue_failed_submission_async(
        self,
        review: CompletedReview,
        *,
        error_message: str,
    ) -> str:
        queue = await self._open_queue()
        try:
            created_at = dt.datetime.now(dt.UTC).isoformat().replace("+00:00", "Z")
            payload = {
                "assignment_id": review.assignment_id,
                "subject_id": review.subject_id,
                "incorrect_meaning_answers": review.incorrect_meaning_answers,
                "incorrect_reading_answers": review.incorrect_reading_answers,
                "assignment_available_at": review.available_at,
                "created_at": created_at,
                "error_snapshot": error_message[:500],
            }
            idempotency_key = (
                f"review-submit:{review.assignment_id}:"
                f"{review.incorrect_meaning_answers}:{review.incorrect_reading_answers}"
            )
            job = await queue.enqueue(
                SUBMIT_TASK_PATH,
                kwargs=payload,
                queue_name=QUEUE_NAME,
                priority=JOB_PRIORITY,
                max_retries=MAX_RETRIES,
                retry_delay=RETRY_DELAY_SECONDS,
                idempotency_key=idempotency_key,
            )
            return job.ulid
        finally:
            await queue.close()

    async def queue_counts_async(self) -> QueueCounts:
        queue = await self._open_queue()
        try:
            pending = await self._count_by_status(JobStatus.PENDING.value)
            failed = await self._count_by_status(JobStatus.FAILED.value)
            running = await self._count_by_status(JobStatus.RUNNING.value)
            completed = await self._count_by_status(JobStatus.COMPLETED.value)
            cancelled = await self._count_by_status(JobStatus.CANCELLED.value)
            return QueueCounts(
                pending=pending,
                failed=failed,
                running=running,
                completed=completed,
                cancelled=cancelled,
            )
        finally:
            await queue.close()

    async def list_jobs_async(self, *, status: str, limit: int) -> list[QueueJobView]:
        queue = await self._open_queue()
        try:
            query = (
                Job.query()
                .filter(F("queue_name") == QUEUE_NAME)
                .order_by("updated_at", desc=True)
            )
            if status == "done":
                query = query.filter(
                    F("status").in_list([JobStatus.COMPLETED.value, JobStatus.CANCELLED.value])
                )
            elif status != "all":
                query = query.filter(F("status") == status)
            rows = await query.limit(limit).all()
            return [self._job_view(row) for row in rows]
        finally:
            await queue.close()

    async def retry_async(
        self,
        *,
        limit: int,
        retry_failed: bool,
        dry_run: bool,
        all_jobs: bool,
        job_ulid: str | None = None,
    ) -> RetryReport:
        queue = await self._open_queue()
        try:
            await queue.recover_expired_leases()

            retried_from_failed = 0
            if retry_failed:
                retried_from_failed = await self._requeue_failed(
                    limit=limit,
                    all_jobs=all_jobs,
                    job_ulid=job_ulid,
                )

            if dry_run:
                pending = await self._count_by_status(JobStatus.PENDING.value)
                failed = await self._count_by_status(JobStatus.FAILED.value)
                return RetryReport(
                    retried_from_failed=retried_from_failed,
                    claimed=0,
                    submitted=0,
                    failed=0,
                    remaining_pending=pending,
                    remaining_failed=failed,
                )

            claimed = 0
            submitted = 0
            failed = 0
            max_to_process = 1_000_000 if all_jobs else max(1, limit)
            worker_id = f"wkler-retry-{int(dt.datetime.now(dt.UTC).timestamp())}"
            client = WaniKaniClient(self._api_token)
            try:
                for _ in range(max_to_process):
                    job = await queue.claim_job(worker_id, [QUEUE_NAME])
                    if job is None:
                        break

                    claimed += 1
                    try:
                        payload = _extract_payload(job)
                        client.create_review(
                            assignment_id=payload["assignment_id"],
                            incorrect_meaning_answers=payload["incorrect_meaning_answers"],
                            incorrect_reading_answers=payload["incorrect_reading_answers"],
                            assignment_available_at=payload["assignment_available_at"],
                        )
                        await queue.complete_job(job, worker_id, result={"submitted": True})
                        submitted += 1
                    except Exception as exc:
                        await queue.fail_job(job, worker_id, exc)
                        failed += 1
            finally:
                client.close()

            pending = await self._count_by_status(JobStatus.PENDING.value)
            remaining_failed = await self._count_by_status(JobStatus.FAILED.value)
            return RetryReport(
                retried_from_failed=retried_from_failed,
                claimed=claimed,
                submitted=submitted,
                failed=failed,
                remaining_pending=pending,
                remaining_failed=remaining_failed,
            )
        finally:
            await queue.close()

    async def _requeue_failed(
        self,
        *,
        limit: int,
        all_jobs: bool,
        job_ulid: str | None,
    ) -> int:
        if job_ulid:
            row = await Job.query().filter(
                (F("queue_name") == QUEUE_NAME) & (F("ulid") == job_ulid)
            ).first()
            if row is None:
                return 0
            if row.status == JobStatus.FAILED.value:
                await row.retry()
                return 1
            return 0

        query = Job.query().filter(
            (F("queue_name") == QUEUE_NAME) & (F("status") == JobStatus.FAILED.value)
        ).order_by("updated_at", desc=False)
        if not all_jobs:
            query = query.limit(limit)
        rows = await query.all()
        retried = 0
        for row in rows:
            if await row.retry():
                retried += 1
        return retried

    async def _count_by_status(self, status: str) -> int:
        return await Job.query().filter(
            (F("queue_name") == QUEUE_NAME) & (F("status") == status)
        ).count()

    async def _open_queue(self) -> Queue:
        queue = Queue(
            str(self._db_path),
            default_max_retries=MAX_RETRIES,
            default_retry_delay=RETRY_DELAY_SECONDS,
        )
        await queue.init_db()
        return queue

    def _job_view(self, job: Job) -> QueueJobView:
        payload: dict[str, Any] = {}
        try:
            payload = job.payload
        except Exception:
            payload = {}
        assignment_id = payload.get("kwargs", {}).get("assignment_id")
        subject_id = payload.get("kwargs", {}).get("subject_id")
        return QueueJobView(
            ulid=job.ulid,
            status=job.status,
            assignment_id=assignment_id if isinstance(assignment_id, int) else None,
            subject_id=subject_id if isinstance(subject_id, int) else None,
            retry_count=job.retry_count,
            max_retries=job.max_retries,
            eta=job.eta,
            updated_at=job.updated_at,
            last_error=job.last_error,
        )


def _extract_payload(job: Job) -> dict[str, int | str | None]:
    payload = job.payload.get("kwargs", {})
    return {
        "assignment_id": int(payload["assignment_id"]),
        "incorrect_meaning_answers": int(payload["incorrect_meaning_answers"]),
        "incorrect_reading_answers": int(payload["incorrect_reading_answers"]),
        "assignment_available_at": payload.get("assignment_available_at"),
    }
