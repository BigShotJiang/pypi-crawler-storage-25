from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.widgets import Button, ContentSwitcher, Input, Static

from wkler.api.client import WaniKaniClient
from wkler.api.models import AssignmentResource, SubjectResource
from wkler.app_logging import get_logger
from wkler.config import Settings
from wkler.db.repo import WKRepository
from wkler.queue import QueueCounts, ReviewSubmissionQueue
from wkler.review.engine import CompletedReview, ReviewEngine, build_session_items
from wkler.review.ime import apply_reading_ime
from wkler.tui.study_visuals import (
    format_last_miss_parts,
    subject_badge_alignment_class,
    subject_badge_class,
    subject_badge_label,
)
from wkler.tui.theme import THEMES, textual_theme_name

StatusLevel = Literal["success", "warning", "error", "info"]
LessonStage = Literal["meaning", "reading"]


@dataclass(slots=True)
class ReviewSubmissionStats:
    submitted_immediate: int = 0
    queued_for_retry: int = 0
    queue_errors: int = 0


@dataclass(slots=True)
class LessonStep:
    assignment_id: int
    subject_id: int
    subject_type: str
    stage: LessonStage
    prompt: str
    meanings: list[str] = field(default_factory=list)
    readings: list[str] = field(default_factory=list)


def build_lesson_steps(
    rows: list[tuple[AssignmentResource, SubjectResource]],
) -> list[LessonStep]:
    steps: list[LessonStep] = []
    for assignment, subject in rows:
        prompt = _primary_prompt(subject)
        meanings = _lesson_meanings(subject)
        readings = _lesson_readings(subject)
        subject_type = assignment.data.subject_type
        steps.append(
            LessonStep(
                assignment_id=assignment.id,
                subject_id=assignment.data.subject_id,
                subject_type=subject_type,
                stage="meaning",
                prompt=prompt,
                meanings=meanings,
                readings=readings,
            )
        )
        if subject_type in {"kanji", "vocabulary"} and readings:
            steps.append(
                LessonStep(
                    assignment_id=assignment.id,
                    subject_id=assignment.data.subject_id,
                    subject_type=subject_type,
                    stage="reading",
                    prompt=prompt,
                    meanings=meanings,
                    readings=readings,
                )
            )
    return steps


class CompactApp(App[None]):
    CSS = """
    Screen {
        background: $background;
        align: center middle;
    }
    #container {
        width: 46;
        max-width: 88%;
        height: auto;
        min-height: 18;
        border: tall $primary;
        background: #040604;
        padding: 0 1;
    }
    #container.wrap-up {
        border: heavy #D2B27A;
    }
    #title {
        color: $primary;
        text-style: bold;
    }
    #subtitle {
        color: #6F7C71;
        margin: 0;
    }
    #views {
        height: 1fr;
    }
    .view {
        height: 1fr;
    }
    #home_actions {
        height: auto;
        align: left top;
        margin: 0;
    }
    Button {
        color: #DCEFD8;
        background: #141914;
        border: tall #2B3B2F;
    }
    Button:focus {
        color: #FFFFFF;
        border: heavy $accent;
    }
    Button.-success {
        color: #E8FFE8;
        background: #173320;
    }
    Button.-primary {
        color: #E7F4FF;
        background: #1A2F3A;
    }
    Button.-warning {
        color: #FFF4CC;
        background: #3A3116;
    }
    Button.-error {
        color: #FFE1E1;
        background: #3A1A1A;
    }
    #home_actions Button {
        width: 12;
        min-height: 3;
        height: 3;
        margin: 0;
    }
    #home_hint {
        color: #6F7C71;
        margin: 0;
    }
    #review_header,
    #lesson_header {
        color: #98A99B;
        margin: 0 0 0 0;
    }
    #review_subject_stack {
        height: auto;
        margin: 0;
    }
    #review_subject,
    #lesson_subject {
        width: 1fr;
        color: #98A99B;
        text-style: bold;
    }
    #review_subject.align-left,
    #lesson_subject.align-left {
        content-align: left middle;
    }
    #review_subject.align-center,
    #lesson_subject.align-center {
        content-align: center middle;
    }
    #review_subject.align-right,
    #lesson_subject.align-right {
        content-align: right middle;
    }
    #review_subject.vocabulary,
    #lesson_subject.vocabulary {
        color: #4BE47D;
    }
    #review_subject.kanji,
    #lesson_subject.kanji {
        color: #FF9552;
    }
    #review_subject.radical,
    #lesson_subject.radical {
        color: #D678FF;
    }
    #review_subject.kana_vocabulary,
    #lesson_subject.kana_vocabulary {
        color: #FFE84A;
    }
    #review_subject.other,
    #lesson_subject.other {
        color: #A5A5A5;
    }
    #review_last_wrong {
        display: none;
        width: auto;
        color: #D16C6C;
    }
    #review_last_right {
        display: none;
        width: auto;
        color: #8CCF95;
    }
    #review_prompt,
    #lesson_prompt {
        min-height: 1;
        border: tall #2B3B2F;
        background: #060A06;
        color: #D6DED7;
        text-style: bold;
        content-align: center middle;
        margin: 0;
        padding: 0 1;
    }
    #review_prompt.meaning,
    #lesson_prompt.meaning {
        border: heavy #8A774D;
    }
    #review_prompt.reading,
    #lesson_prompt.reading {
        border: heavy #4D7698;
    }
    #review_mode,
    #lesson_mode {
        color: #778879;
        margin: 0;
    }
    #review_answer {
        border: tall #2B3B2F;
        background: #060A06;
        color: #D6DED7;
    }
    #review_answer.meaning {
        border: heavy #8A774D;
        color: #E9D7A3;
    }
    #review_answer.reading {
        border: heavy #4D7698;
        color: #BFE3F7;
    }
    #review_result_banner {
        display: none;
        height: 5;
        content-align: center middle;
        text-style: bold;
        margin: 0;
    }
    #review_result_banner.correct {
        display: block;
        color: $success;
        background: #0E1A0E;
        border: heavy $success;
    }
    #review_result_banner.incorrect {
        display: block;
        color: $error;
        background: #1A0E0E;
        border: heavy $error;
    }
    #review_mode.meaning,
    #lesson_mode.meaning {
        color: #D2B27A;
        content-align: left middle;
    }
    #review_mode.reading,
    #lesson_mode.reading {
        color: #6BC7FF;
        content-align: right middle;
    }
    #lesson_actions {
        height: auto;
        align: left top;
        margin: 0;
    }
    #lesson_actions Button {
        width: 12;
        min-height: 3;
        height: 3;
        margin: 0;
    }
    #review_hint {
        color: #7A8B7B;
        margin: 0;
    }
    #lesson_reveal {
        min-height: 1;
        color: #9BAC9D;
        border: none;
        background: #060A06;
        padding: 0 1;
    }
    #home_status,
    #review_status,
    #lesson_status {
        height: auto;
        min-height: 1;
        border: none;
        background: transparent;
        padding: 0;
    }
    #home_status.success,
    #review_status.success,
    #lesson_status.success {
        color: $success;
    }
    #home_status.warning,
    #review_status.warning,
    #lesson_status.warning {
        color: $warning;
    }
    #home_status.error,
    #review_status.error,
    #lesson_status.error {
        color: $error;
    }
    #home_status.info,
    #review_status.info,
    #lesson_status.info {
        color: $primary;
    }
    """

    BINDINGS = [
        Binding("r", "start_reviews", "Reviews"),
        Binding("l", "start_lessons", "Lessons"),
        Binding("y", "sync_cache", "Sync"),
        Binding("ctrl+r", "reveal_review", "Reveal"),
        Binding("g", "mark_lesson_got_it", "Lesson Got"),
        Binding("n", "mark_lesson_need_work", "Lesson Need"),
        Binding("ctrl+w", "wrap_up_review", "Wrap Up", priority=True),
        Binding("escape", "escape_back", "Back"),
        Binding("q", "quit_app", "Quit"),
        Binding("ctrl+q", "quit_app", "Quit"),
        Binding("ctrl+c", "quit_app", "Quit"),
    ]

    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self._settings = settings
        self._register_themes()
        self.theme = textual_theme_name(self._settings.theme)
        self._review_engine: ReviewEngine | None = None
        self._review_client: WaniKaniClient | None = None
        self._review_repo: WKRepository | None = None
        self._review_queue: ReviewSubmissionQueue | None = None
        self._review_stats = ReviewSubmissionStats()
        self._review_ime_mutation = False
        self._lesson_steps: list[LessonStep] = []
        self._lesson_index = 0
        self._lesson_revealed = False
        self._lesson_scores: list[float] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="container"):
            yield Static("wkler c", id="title")
            yield Static("r rev | l les | y sync | esc | q", id="subtitle")
            with ContentSwitcher(initial="home_view", id="views"):
                with Vertical(id="home_view", classes="view"):
                    with Vertical(id="home_actions"):
                        yield Button("Rev", id="home_reviews", variant="success")
                        yield Button("Les", id="home_lessons", variant="primary")
                    yield Static(
                        "keys: r/l",
                        id="home_hint",
                    )
                    yield Static("", id="home_status", classes="info")
                with Vertical(id="review_view", classes="view"):
                    yield Static("", id="review_header")
                    with Vertical(id="review_subject_stack"):
                        yield Static("", id="review_subject")
                        yield Static("", id="review_last_wrong")
                        yield Static("", id="review_last_right")
                    yield Static("", id="review_prompt")
                    yield Static("", id="review_mode")
                    yield Static(
                        "enter submit | ctrl+r reveal | ctrl+w wrap | esc back",
                        id="review_hint",
                    )
                    yield Input(placeholder="ans + Enter", id="review_answer")
                    yield Static("", id="review_result_banner")
                    yield Static("", id="review_status", classes="info")
                with Vertical(id="lesson_view", classes="view"):
                    yield Static("", id="lesson_header")
                    yield Static("", id="lesson_subject")
                    yield Static("", id="lesson_prompt")
                    yield Static("", id="lesson_mode")
                    yield Static("ctrl+r reveal | g got | n need", id="lesson_reveal")
                    with Vertical(id="lesson_actions"):
                        yield Button("Rev", id="lesson_reveal_btn", variant="warning")
                        yield Button("Got", id="lesson_got_btn", variant="success")
                        yield Button("Need", id="lesson_need_btn", variant="error")
                        yield Button("Bk", id="lesson_back_btn", variant="default")
                    yield Static("", id="lesson_status", classes="info")

    def on_mount(self) -> None:
        if not self._settings.api_token:
            self._set_home_status(
                "API token missing. Run `wkler setup` in full mode.",
                level="warning",
            )
        else:
            self._set_home_status("Ready. r/l to start.", level="info")
        self.query_one("#home_reviews", Button).focus()

    def on_unmount(self) -> None:
        self._close_review_resources()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        if button_id is None:
            return
        if button_id == "home_reviews":
            self._start_review_session()
            return
        if button_id == "home_lessons":
            self._start_lessons_default()
            return
        if button_id == "lesson_reveal_btn":
            self._reveal_lesson_step()
            return
        if button_id == "lesson_got_btn":
            self._score_lesson_step(1.0)
            return
        if button_id == "lesson_need_btn":
            self._score_lesson_step(0.0)
            return
        if button_id == "lesson_back_btn":
            self._back_to_home_from_lesson()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "review_answer":
            self._submit_review_answer()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "review_answer":
            return
        if self._review_ime_mutation:
            return
        if self._review_engine is None or self._review_engine.is_done():
            return
        if self._review_engine.awaiting_incorrect_continue:
            return
        if self._review_engine.awaiting_correct_continue:
            return
        question = self._review_engine.current_question()
        if question.kind != "reading":
            return
        converted = apply_reading_ime(
            event.value,
            mode=self._settings.reading_input_mode,
            convert_ending=False,
        )
        if converted == event.value:
            return
        self._review_ime_mutation = True
        event.input.value = converted
        self._review_ime_mutation = False

    def action_start_reviews(self) -> None:
        self._start_review_session()

    def action_start_lessons(self) -> None:
        self._start_lessons_default()

    def action_reveal_review(self) -> None:
        active = self._active_view()
        if active == "review_view":
            self._reveal_review_answer()
            return
        if active == "lesson_view":
            self._reveal_lesson_step()

    def action_mark_lesson_got_it(self) -> None:
        if self._active_view() == "lesson_view":
            self._score_lesson_step(1.0)

    def action_mark_lesson_need_work(self) -> None:
        if self._active_view() == "lesson_view":
            self._score_lesson_step(0.0)

    def action_wrap_up_review(self) -> None:
        if self._active_view() == "review_view":
            self._enable_review_wrap_up()

    def action_sync_cache(self) -> None:
        if not self._settings.api_token:
            self._set_active_status("API token missing. Run `wkler setup` first.", level="error")
            return
        self._set_active_status("Syncing cache...", level="info")
        client: WaniKaniClient | None = None
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            review_assignments = client.list_reviewable_assignments()
            review_assignments, review_subjects = _hydrate_assignments(
                client,
                repo,
                review_assignments,
            )
            lesson_assignments = client.list_available_lesson_assignments()
            lesson_assignments, lesson_subjects = _hydrate_assignments(
                client,
                repo,
                lesson_assignments,
            )
            subject_count = len(set(review_subjects.keys()) | set(lesson_subjects.keys()))
            self._set_active_status(
                f"Sync complete: r{len(review_assignments)} "
                f"l{len(lesson_assignments)} s{subject_count}",
                level="success",
            )
        except Exception as exc:
            get_logger().exception("compact sync failed")
            self._set_active_status(f"Sync failed: {exc}", level="error")
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

    def action_escape_back(self) -> None:
        active = self._active_view()
        if active == "review_view":
            self._back_to_home_from_review()
            return
        if active == "lesson_view":
            self._back_to_home_from_lesson()
            return
        self._close_review_resources()
        self.exit(None)

    def action_quit_app(self) -> None:
        self._close_review_resources()
        self.exit(None)

    def _active_view(self) -> str:
        switcher = self.query_one("#views", ContentSwitcher)
        return switcher.current or "home_view"

    def _set_view(self, view_id: str) -> None:
        switcher = self.query_one("#views", ContentSwitcher)
        switcher.current = view_id

    def _set_home_status(self, message: str, *, level: StatusLevel) -> None:
        node = self.query_one("#home_status", Static)
        node.update(message)
        node.set_classes(level)

    def _set_review_status(self, message: str, *, level: StatusLevel) -> None:
        node = self.query_one("#review_status", Static)
        node.update(message)
        node.set_classes(level)

    def _set_lesson_status(self, message: str, *, level: StatusLevel) -> None:
        node = self.query_one("#lesson_status", Static)
        node.update(message)
        node.set_classes(level)

    def _set_active_status(self, message: str, *, level: StatusLevel) -> None:
        active = self._active_view()
        if active == "review_view":
            self._set_review_status(message, level=level)
            return
        if active == "lesson_view":
            self._set_lesson_status(message, level=level)
            return
        self._set_home_status(message, level=level)

    def _set_review_last_error(self, wrong: str | None = None, correct: str | None = None) -> None:
        wrong_node = self.query_one("#review_last_wrong", Static)
        correct_node = self.query_one("#review_last_right", Static)
        wrong_value = (wrong or "").strip()
        correct_value = (correct or "").strip()
        wrong_node.update(f"incorrect: {wrong_value}" if wrong_value else "")
        correct_node.update(f"correct:   {correct_value}" if correct_value else "")
        wrong_node.display = bool(wrong_value)
        correct_node.display = bool(correct_value)

    def _start_review_session(self) -> None:
        if not self._settings.api_token:
            self._set_home_status("API token missing. Run `wkler setup` first.", level="error")
            return
        self._set_review_status("Preparing review session...", level="info")
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            queue = ReviewSubmissionQueue(self._settings.db_path, self._settings.api_token)
            assignments = client.list_reviewable_assignments()
            assignments, subjects_by_id = _hydrate_assignments(client, repo, assignments)
            if not assignments:
                client.close()
                self._set_home_status("No reviews are due right now.", level="info")
                return
            session_items = build_session_items(assignments, subjects_by_id)
            if not session_items:
                client.close()
                self._set_home_status("No reviewable items were prepared.", level="error")
                return
            self._review_client = client
            self._review_repo = repo
            self._review_queue = queue
            self._review_engine = ReviewEngine(
                session_items,
                reading_input_mode=self._settings.reading_input_mode,
                shuffle_mode=self._settings.review_shuffle_mode,
                shuffle_window=self._settings.review_shuffle_window,
                seed=None,
                second_chance_enabled=self._settings.review_second_chance,
                confirm_result_enabled=self._settings.review_confirm_result,
            )
            self._review_stats = ReviewSubmissionStats()
            self._set_review_last_error(None)
            self._set_view("review_view")
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            self._set_review_status("Session started.", level="success")
        except Exception as exc:
            self._close_review_resources()
            get_logger().exception("compact review session bootstrap failed")
            self._set_home_status(f"Failed to prepare reviews: {exc}", level="error")

    def _render_review_state(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_wrap_up_chrome(False)
            return
        stats = engine.stats()
        self._set_wrap_up_chrome(engine.wrap_up_enabled)
        header = self.query_one("#review_header", Static)
        subject = self.query_one("#review_subject", Static)
        prompt = self.query_one("#review_prompt", Static)
        mode = self.query_one("#review_mode", Static)
        answer = self.query_one("#review_answer", Input)
        if engine.is_done():
            counts = self._queue_counts_safe()
            wrap_suffix = (
                f" d{stats['deferred_remaining']}" if engine.wrap_up_enabled else ""
            )
            header.update(
                f"done a{stats['attempted']} c{stats['correct_first_try']} "
                f"i{stats['total_incorrect']} q{counts.pending}/{counts.failed}{wrap_suffix}"
            )
            prompt.update("Review session complete.")
            prompt.set_classes("")
            mode.update("Esc to return.")
            mode.set_classes("")
            answer.set_classes("")
            subject.update("")
            subject.set_classes("")
            self._set_review_last_error(None)
            answer.disabled = True
            return

        question = engine.current_question()
        header.update(
            f"left {stats['remaining']}"
            + (f" | wu {engine.wrap_up_items_left()}" if engine.wrap_up_enabled else "")
            + f" | c{stats['correct_first_try']} i{stats['total_incorrect']}"
        )
        prompt_class = "reading" if question.kind == "reading" else "meaning"
        prompt.update(question.prompt)
        prompt.set_classes(prompt_class)
        answer.set_classes(prompt_class)
        subject.update(subject_badge_label(question.subject_type))
        subject.set_classes(
            f"{subject_badge_class(question.subject_type)} "
            f"{subject_badge_alignment_class(question.subject_type)}"
        )
        if question.kind == "reading":
            mode.update(">>> [R|JP] READING")
            mode.set_classes("reading")
        else:
            mode.update("[M|EN] MEANING <<<")
            mode.set_classes("meaning")
        answer.disabled = False
        self._sync_review_result_banner()

    def _sync_review_result_banner(self) -> None:
        engine = self._review_engine
        banner = self.query_one("#review_result_banner", Static)
        if engine is None or engine.is_done():
            banner.set_classes("")
            return
        if engine.awaiting_correct_continue:
            banner.update("Correct!  Press Enter to continue.")
            banner.set_classes("correct")
        elif engine.awaiting_incorrect_continue:
            banner.update("Incorrect.  Press Enter to continue.")
            banner.set_classes("incorrect")
        else:
            banner.set_classes("")

    def _set_wrap_up_chrome(self, enabled: bool) -> None:
        self.query_one("#container", Vertical).set_class(enabled, "wrap-up")

    def _submit_review_answer(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        if engine.awaiting_correct_continue:
            self._continue_after_correct()
            return
        if engine.awaiting_incorrect_continue:
            self._continue_after_incorrect()
            return
        answer_input = self.query_one("#review_answer", Input)
        answer = answer_input.value.strip()
        if not answer:
            self._set_review_status("Answer is empty.", level="warning")
            return
        question = engine.current_question()
        result = engine.submit(answer)
        answer_input.value = ""
        self._handle_review_result(
            result,
            accepted_answers=question.accepted_answers,
            attempted_answer=answer,
            prompt_text=question.prompt,
        )

    def _continue_after_incorrect(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        try:
            result = engine.continue_after_incorrect()
        except RuntimeError:
            self._set_review_status("No pending incorrect answer to continue.", level="warning")
            return
        self.query_one("#review_answer", Input).value = ""
        self._handle_review_result(result, feedback_override="Continuing.", level_override="info")

    def _continue_after_correct(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        try:
            result = engine.continue_after_correct()
        except RuntimeError:
            self._set_review_status("No pending correct answer to continue.", level="warning")
            return
        self.query_one("#review_answer", Input).value = ""
        self._handle_review_result(result, feedback_override="Continuing.", level_override="info")

    def _reveal_review_answer(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        had_pending_incorrect = engine.awaiting_incorrect_continue
        result = engine.reveal()
        self.query_one("#review_answer", Input).value = ""
        if had_pending_incorrect:
            self._handle_review_result(
                result, feedback_override="Continuing.", level_override="info"
            )
            return
        self._handle_review_result(result)

    def _enable_review_wrap_up(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        if engine.wrap_up_enabled:
            self._set_review_status(
                f"Wrap Up already active: {engine.wrap_up_items_left()} left.",
                level="info",
            )
            return
        count = engine.enable_wrap_up(limit=10)
        self.query_one("#review_answer", Input).value = ""
        self._set_review_status(f"Wrap Up active: {count} left.", level="warning")
        self._render_review_state()
        self.query_one("#review_answer", Input).focus()

    def _handle_review_result(
        self,
        result: object,
        *,
        accepted_answers: list[str] | None = None,
        attempted_answer: str | None = None,
        prompt_text: str | None = None,
        feedback_override: str | None = None,
        level_override: StatusLevel | None = None,
    ) -> None:
        from wkler.review.engine import SubmissionResult

        if not isinstance(result, SubmissionResult):
            self._set_review_status("Unexpected review result.", level="error")
            return

        if result.outcome == "retry":
            if attempted_answer is not None:
                self._set_review_last_error(f"You typed: {attempted_answer}", None)
            self._set_review_status("Try again.", level="warning")
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            return

        if result.outcome == "correct_pending":
            self._set_review_last_error(None)
            self._set_review_status(
                "Correct. Press Enter to confirm.", level="success"
            )
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            return

        feedback = feedback_override or result.feedback
        is_alternate_reading = result.outcome == "alternate_reading"
        level: StatusLevel
        if is_alternate_reading:
            level = "warning"
        elif result.revealed:
            level = "warning"
        elif not result.correct and not result.advanced:
            level = "error"
        elif result.correct:
            level = "success"
        else:
            level = "info"
        if level_override is not None:
            level = level_override

        if result.correct and not result.revealed:
            self._set_review_last_error(None)

        if (
            not result.correct
            and not result.advanced
            and not result.revealed
            and not is_alternate_reading
            and accepted_answers is not None
        ):
            self._set_review_last_error(
                *format_last_miss_parts(
                    prompt_text or "",
                    attempted_answer or "",
                    accepted_answers,
                )
            )
            feedback = "Incorrect. Press Enter to continue."
            level = "error"

        if result.completed_review is not None:
            completion_message, completion_level = self._submit_or_queue_sync(
                result.completed_review
            )
            feedback = completion_message
            level = completion_level

        self._set_review_status(feedback, level=level)
        self._render_review_state()
        self.query_one("#review_answer", Input).focus()
        if self._review_engine is not None and self._review_engine.is_done():
            self._retry_queue_after_review()

    def _submit_or_queue_sync(self, review: CompletedReview) -> tuple[str, StatusLevel]:
        client = self._review_client
        repo = self._review_repo
        queue = self._review_queue
        if client is None or repo is None or queue is None:
            return ("Review resources unavailable.", "error")
        logger = get_logger()
        try:
            client.create_review(
                assignment_id=review.assignment_id,
                incorrect_meaning_answers=review.incorrect_meaning_answers,
                incorrect_reading_answers=review.incorrect_reading_answers,
                assignment_available_at=review.available_at,
            )
            repo.log_review(review)
            self._review_stats.submitted_immediate += 1
            logger.info(
                "compact review submitted",
                extra={
                    "event_type": "compact_review_submit_immediate",
                    "assignment_id": review.assignment_id,
                    "subject_id": review.subject_id,
                },
            )
            return ("Submitted.", "success")
        except Exception as submit_error:
            try:
                job_ulid = queue.enqueue_failed_submission(
                    review,
                    error_message=str(submit_error),
                )
            except Exception as queue_error:
                self._review_stats.queue_errors += 1
                logger.error(
                    "compact review submit and queue failed",
                    extra={
                        "event_type": "compact_review_submit_queue_error",
                        "assignment_id": review.assignment_id,
                        "subject_id": review.subject_id,
                        "error": str(queue_error),
                    },
                )
                return (f"Submit failed and queue failed: {queue_error}", "error")
            self._review_stats.queued_for_retry += 1
            logger.warning(
                "compact review queued for retry",
                extra={
                    "event_type": "compact_review_submit_queued",
                    "assignment_id": review.assignment_id,
                    "subject_id": review.subject_id,
                    "queue_job_id": job_ulid,
                    "error": str(submit_error),
                },
            )
            return (f"Queued for retry ({job_ulid[:8]}).", "warning")

    def _retry_queue_after_review(self) -> None:
        queue = self._review_queue
        if queue is None:
            return
        try:
            counts = queue.queue_counts()
            if counts.pending > 0 or counts.failed > 0:
                queue.retry(
                    limit=10,
                    all_jobs=False,
                    dry_run=False,
                    retry_failed=True,
                )
        except Exception as exc:
            get_logger().warning(f"compact queue retry after review failed: {exc}")

    def _queue_counts_safe(self) -> QueueCounts:
        queue = self._review_queue
        if queue is None:
            return QueueCounts(pending=0, failed=0, running=0, completed=0, cancelled=0)
        try:
            return queue.queue_counts()
        except Exception:
            return QueueCounts(pending=0, failed=0, running=0, completed=0, cancelled=0)

    def _back_to_home_from_review(self) -> None:
        self._close_review_resources()
        self._review_engine = None
        self._set_review_last_error(None)
        self._set_wrap_up_chrome(False)
        self._set_view("home_view")
        self.query_one("#home_reviews", Button).focus()
        self._set_home_status("Returned from reviews.", level="info")

    def _close_review_resources(self) -> None:
        if self._review_client is not None:
            try:
                self._review_client.close()
            except Exception:
                pass
        self._review_client = None
        self._review_repo = None
        self._review_queue = None

    def _start_lessons_default(self) -> None:
        if not self._settings.api_token:
            self._set_home_status("API token missing. Run `wkler setup` first.", level="error")
            return
        self._set_home_status("Starting lessons...", level="info")
        started_rows: list[tuple[AssignmentResource, SubjectResource]] = []
        started = 0
        failed = 0
        requested = 0
        client: WaniKaniClient | None = None
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            assignments = client.list_available_lesson_assignments()
            assignments, subjects_by_id = _hydrate_assignments(client, repo, assignments)
            rows: list[tuple[AssignmentResource, SubjectResource]] = []
            for assignment in assignments:
                subject = subjects_by_id.get(assignment.data.subject_id)
                if subject is None:
                    continue
                rows.append((assignment, subject))
            if not rows:
                self._set_home_status("No lessons are available right now.", level="info")
                return
            requested = min(self._settings.lesson_batch_size, len(rows))
            if requested <= 0:
                self._set_home_status("Default lesson count must be >= 1.", level="warning")
                return
            for assignment, subject in rows[:requested]:
                try:
                    updated = client.start_assignment(assignment.id)
                except Exception as exc:
                    failed += 1
                    get_logger().warning(
                        f"compact lesson start failed id={assignment.id} err={exc}"
                    )
                    continue
                repo.upsert_assignments([updated])
                started_rows.append((updated, subject))
                started += 1
        except Exception as exc:
            get_logger().exception("compact lessons start failed")
            self._set_home_status(f"Failed to start lessons: {exc}", level="error")
            return
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

        if started == 0:
            self._set_home_status("No lessons were started.", level="warning")
            return

        self._lesson_steps = build_lesson_steps(started_rows)
        if not self._lesson_steps:
            self._set_home_status("No lesson steps could be built.", level="error")
            return
        self._lesson_index = 0
        self._lesson_revealed = False
        self._lesson_scores = []
        self._set_view("lesson_view")
        self._render_lesson_step()
        self._set_lesson_status(
            f"Lesson session started. requested={requested} started={started} failed={failed}",
            level="info",
        )

    def _render_lesson_step(self) -> None:
        header = self.query_one("#lesson_header", Static)
        subject = self.query_one("#lesson_subject", Static)
        prompt = self.query_one("#lesson_prompt", Static)
        mode = self.query_one("#lesson_mode", Static)
        reveal = self.query_one("#lesson_reveal", Static)
        if self._lesson_index >= len(self._lesson_steps):
            total = len(self._lesson_scores)
            confident = sum(1 for value in self._lesson_scores if value >= 1.0)
            need_work = total - confident
            header.update(f"done {total} | ok {confident} | nw {need_work}")
            subject.update("")
            subject.set_classes("")
            prompt.update("Lesson session complete.")
            prompt.set_classes("")
            mode.update("Press Back.")
            mode.set_classes("")
            reveal.update("Use full mode for lesson center controls.")
            self._set_lesson_action_state(is_done=True, revealed=True)
            return

        step = self._lesson_steps[self._lesson_index]
        header.update(f"step {self._lesson_index + 1}/{len(self._lesson_steps)}")
        subject.update(subject_badge_label(step.subject_type))
        subject.set_classes(
            f"{subject_badge_class(step.subject_type)} "
            f"{subject_badge_alignment_class(step.subject_type)}"
        )
        prompt.update(step.prompt)
        stage_class = "reading" if step.stage == "reading" else "meaning"
        prompt.set_classes(stage_class)
        if step.stage == "reading":
            mode.update(">>> [R|JP] READING")
            mode.set_classes("reading")
        else:
            mode.update("[M|EN] MEANING <<<")
            mode.set_classes("meaning")
        if self._lesson_revealed:
            reveal.update(
                f"Meanings: {', '.join(step.meanings) or '-'}\n"
                f"Readings: {', '.join(step.readings) or '-'}"
            )
        else:
            reveal.update("Press Reveal to show details.")
        self._set_lesson_action_state(is_done=False, revealed=self._lesson_revealed)

    def _set_lesson_action_state(self, *, is_done: bool, revealed: bool) -> None:
        reveal_btn = self.query_one("#lesson_reveal_btn", Button)
        got_btn = self.query_one("#lesson_got_btn", Button)
        need_btn = self.query_one("#lesson_need_btn", Button)
        if is_done:
            reveal_btn.disabled = True
            got_btn.disabled = True
            need_btn.disabled = True
            return
        reveal_btn.disabled = revealed
        got_btn.disabled = not revealed
        need_btn.disabled = not revealed

    def _reveal_lesson_step(self) -> None:
        if self._lesson_index >= len(self._lesson_steps):
            self._set_lesson_status("Lesson session is complete.", level="info")
            return
        self._lesson_revealed = True
        self._render_lesson_step()
        self._set_lesson_status("Revealed. Mark Got It or Need Work.", level="info")

    def _score_lesson_step(self, value: float) -> None:
        if self._lesson_index >= len(self._lesson_steps):
            self._set_lesson_status("Lesson session is complete.", level="info")
            return
        if not self._lesson_revealed:
            self._set_lesson_status("Reveal details before scoring.", level="warning")
            return
        self._lesson_scores.append(value)
        self._lesson_index += 1
        self._lesson_revealed = False
        self._render_lesson_step()
        if value >= 1.0:
            self._set_lesson_status("Marked as confident.", level="success")
        else:
            self._set_lesson_status("Marked as need work.", level="warning")

    def _back_to_home_from_lesson(self) -> None:
        self._lesson_steps = []
        self._lesson_index = 0
        self._lesson_revealed = False
        self._lesson_scores = []
        self._set_view("home_view")
        self.query_one("#home_reviews", Button).focus()
        self._set_home_status("Returned from lessons.", level="info")

    def _register_themes(self) -> None:
        for theme in THEMES.values():
            self.register_theme(theme)


def _hydrate_assignments(
    client: WaniKaniClient,
    repo: WKRepository,
    assignments: list[AssignmentResource],
) -> tuple[list[AssignmentResource], dict[int, SubjectResource]]:
    if not assignments:
        return [], {}
    repo.upsert_assignments(assignments)
    subject_ids = sorted({assignment.data.subject_id for assignment in assignments})
    cached_subjects = repo.get_cached_subjects(subject_ids)
    missing_ids = [subject_id for subject_id in subject_ids if subject_id not in cached_subjects]
    if missing_ids:
        fetched = client.get_subjects(missing_ids)
        repo.upsert_subjects(fetched.values())
        cached_subjects.update(fetched)
    return assignments, cached_subjects


def _primary_prompt(subject: SubjectResource) -> str:
    if subject.data.characters:
        return subject.data.characters
    for meaning in subject.data.meanings:
        if meaning.primary:
            return meaning.meaning
    if subject.data.meanings:
        return subject.data.meanings[0].meaning
    return "(no prompt)"


def _lesson_meanings(subject: SubjectResource) -> list[str]:
    accepted = [entry.meaning for entry in subject.data.meanings if entry.accepted_answer]
    if accepted:
        return list(dict.fromkeys(accepted))
    fallback = [entry.meaning for entry in subject.data.meanings]
    return list(dict.fromkeys(fallback))


def _lesson_readings(subject: SubjectResource) -> list[str]:
    accepted = [entry.reading for entry in subject.data.readings if entry.accepted_answer]
    if accepted:
        return list(dict.fromkeys(accepted))
    fallback = [entry.reading for entry in subject.data.readings]
    return list(dict.fromkeys(fallback))
