from __future__ import annotations


def subject_badge_class(subject_type: str) -> str:
    normalized = _normalize_subject_type(subject_type)
    if normalized in {"vocabulary", "kanji", "radical", "kana_vocabulary"}:
        return normalized
    return "other"


def subject_badge_alignment_class(subject_type: str) -> str:
    normalized = _normalize_subject_type(subject_type)
    if normalized == "radical":
        return "align-left"
    if normalized == "kanji":
        return "align-center"
    if normalized == "vocabulary":
        return "align-right"
    if normalized == "kana_vocabulary":
        return "align-center"
    return "align-left"


def subject_badge_label(subject_type: str) -> str:
    normalized = _normalize_subject_type(subject_type)
    if normalized == "vocabulary":
        return "[VO] VOCAB"
    if normalized == "kanji":
        return "[KJ] KANJI"
    if normalized == "radical":
        return "[RD] RADICAL"
    if normalized == "kana_vocabulary":
        return "<< KANA ONLY VOCAB >>"
    return f"[??] {subject_type.upper()}"


def _normalize_subject_type(value: str) -> str:
    return value.strip().casefold().replace("-", "_").replace(" ", "_")


def format_accepted_answers(answers: list[str], *, max_items: int = 3) -> str:
    unique: list[str] = []
    for raw in answers:
        value = raw.strip()
        if not value or value in unique:
            continue
        unique.append(value)
    if not unique:
        return "No accepted answer available."

    shown = unique[:max_items]
    if len(shown) == 1:
        return f"Correct answer: {shown[0]}."

    suffix = ""
    remaining = len(unique) - len(shown)
    if remaining > 0:
        suffix = f" (+{remaining} more)"
    return f"Accepted answers: {', '.join(shown)}{suffix}."


def format_last_miss(prompt: str, typed: str, accepted_answers: list[str]) -> str:
    wrong_text, correct_text = format_last_miss_parts(prompt, typed, accepted_answers)
    return f"{wrong_text} -> {correct_text}"


def format_last_miss_parts(
    prompt: str,
    typed: str,
    accepted_answers: list[str],
) -> tuple[str, str]:
    prompt_value = _compact_text(prompt, max_len=12, empty_fallback="?")
    typed_value = _compact_text(typed, max_len=18, empty_fallback="(empty)")
    correct_value = _compact_text(
        _accepted_inline(accepted_answers),
        max_len=22,
        empty_fallback="n/a",
    )
    wrong_text = f"✗ {prompt_value}: {typed_value}"
    correct_text = f"✓ {correct_value}"
    return wrong_text, correct_text


def _accepted_inline(answers: list[str], *, max_items: int = 2) -> str:
    unique: list[str] = []
    for raw in answers:
        value = " ".join(raw.strip().split())
        if not value or value in unique:
            continue
        unique.append(value)
    if not unique:
        return ""

    shown = unique[:max_items]
    remaining = len(unique) - len(shown)
    suffix = f" (+{remaining})" if remaining > 0 else ""
    return ", ".join(shown) + suffix


def _compact_text(value: str, *, max_len: int, empty_fallback: str = "") -> str:
    text = " ".join(value.strip().split())
    if not text:
        return empty_fallback
    if len(text) <= max_len:
        return text
    return f"{text[: max_len - 3]}..."
