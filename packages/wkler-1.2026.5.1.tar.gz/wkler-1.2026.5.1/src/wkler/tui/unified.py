from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import (
    Button,
    ContentSwitcher,
    Input,
    LoadingIndicator,
    ProgressBar,
    Rule,
    Sparkline,
    Static,
)

from wkler.api.client import WaniKaniClient
from wkler.api.models import AssignmentResource, SubjectResource
from wkler.app_logging import get_logger
from wkler.config import Settings
from wkler.db.repo import WKRepository
from wkler.queue import QueueCounts, ReviewSubmissionQueue
from wkler.review.engine import CompletedReview, ReviewEngine, build_session_items
from wkler.review.ime import apply_reading_ime
from wkler.tui.home import HomeSelection
from wkler.tui.study_visuals import (
    format_last_miss_parts,
    subject_badge_alignment_class,
    subject_badge_class,
    subject_badge_label,
)
from wkler.tui.theme import THEMES, textual_theme_name

StatusLevel = Literal["success", "warning", "error", "info"]
LessonStage = Literal["meaning", "reading"]

_CORRECT_COLOR = "#8CCF95"
_INCORRECT_COLOR = "#D16C6C"

_HELP_TEXT = (
    "GLOBAL\n"
    "  ?               toggle help\n"
    "  esc             close help or go back\n"
    "  ctrl+q / ctrl+c quit app\n"
    "\n"
    "HOME\n"
    "  v               start reviews\n"
    "  l               start default lessons\n"
    "  i               open lessons center\n"
    "  o               setup\n"
    "  p               settings\n"
    "  d               doctor\n"
    "  y               sync\n"
    "  u               queue list\n"
    "  t               retry queue\n"
    "  ctrl+f          focus feedback input\n"
    "\n"
    "REVIEWS\n"
    "  enter           submit (or continue after incorrect)\n"
    "  ctrl+r          reveal answer\n"
    "  ctrl+w          enable wrap-up (10)\n"
    "  esc             return home\n"
    "  shuffle         set mode/window in Settings -> Behavior\n"
    "\n"
    "LESSONS\n"
    "  l               start default lessons from home\n"
    "  enter           start custom count from lessons center input\n"
    "  ctrl+r          reveal lesson details (session)\n"
    "  g               mark Got It (session)\n"
    "  n               mark Need Work (session)\n"
    "  esc             return home from lessons views\n"
)


@dataclass(slots=True)
class ReviewSubmissionStats:
    submitted_immediate: int = 0
    queued_for_retry: int = 0
    queue_errors: int = 0


@dataclass(slots=True)
class LessonStep:
    assignment_id: int
    subject_id: int
    subject_type: str
    stage: LessonStage
    prompt: str
    meanings: list[str] = field(default_factory=list)
    readings: list[str] = field(default_factory=list)


def build_lesson_steps(
    rows: list[tuple[AssignmentResource, SubjectResource]],
) -> list[LessonStep]:
    steps: list[LessonStep] = []
    for assignment, subject in rows:
        prompt = _primary_prompt(subject)
        meanings = _lesson_meanings(subject)
        readings = _lesson_readings(subject)
        subject_type = assignment.data.subject_type
        steps.append(
            LessonStep(
                assignment_id=assignment.id,
                subject_id=assignment.data.subject_id,
                subject_type=subject_type,
                stage="meaning",
                prompt=prompt,
                meanings=meanings,
                readings=readings,
            )
        )
        if subject_type in {"kanji", "vocabulary"} and readings:
            steps.append(
                LessonStep(
                    assignment_id=assignment.id,
                    subject_id=assignment.data.subject_id,
                    subject_type=subject_type,
                    stage="reading",
                    prompt=prompt,
                    meanings=meanings,
                    readings=readings,
                )
            )
    return steps


class UnifiedApp(App[HomeSelection | None]):
    """Single-app daily UX: home + in-app reviews + in-app lessons."""

    CSS = """
    Screen {
        align: center middle;
        background: $background;
    }
    #container {
        width: 94%;
        max-width: 138;
        height: 96%;
        border: heavy $primary;
        background: #060906;
        padding: 1 2;
    }
    #container.wrap-up {
        border: heavy #E8C66A;
    }
    #title {
        text-style: bold;
        color: $primary;
    }
    #subtitle {
        color: #D0E3D3;
        margin: 0 0 1 0;
    }
    #loading_row {
        height: auto;
        margin: 0 0 1 0;
        border: tall $accent;
        background: #0A120A;
        padding: 0 1;
    }
    #loading_text {
        margin-left: 1;
        color: #DDEBDD;
    }
    #views {
        height: 1fr;
    }
    .view {
        height: 1fr;
    }
    .section-title {
        color: $primary;
        text-style: bold;
        margin: 0 0 1 0;
    }
    .description {
        color: #D4E8D8;
        margin: 0 0 1 0;
    }
    .button-row {
        height: auto;
        margin: 0 0 1 0;
    }
    .button-row Button {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    .button-row Button:last-child {
        margin-right: 0;
    }
    #feedback_note {
        width: 1fr;
        margin-right: 1;
    }
    #review_prompt,
    #lesson_prompt {
        min-height: 4;
        border: heavy $secondary;
        background: #0B140B;
        color: $foreground;
        content-align: center middle;
        text-style: bold;
        margin: 1 0;
        padding: 0 1;
    }
    #review_subject_row {
        height: 1;
        margin: 1 0 0 0;
    }
    #review_subject,
    #lesson_subject {
        width: auto;
        margin: 0;
        color: #D6EAD8;
        text-style: bold;
    }
    #review_subject {
        width: 14;
    }
    #lesson_subject {
        width: 1fr;
    }
    #review_subject.align-left,
    #lesson_subject.align-left {
        content-align: left middle;
    }
    #review_subject.align-center,
    #lesson_subject.align-center {
        content-align: center middle;
    }
    #review_subject.align-right,
    #lesson_subject.align-right {
        content-align: right middle;
    }
    #review_last_wrong {
        display: none;
        width: 2fr;
        margin-left: 1;
        color: #D16C6C;
    }
    #review_last_right {
        display: none;
        width: 1fr;
        margin-left: 1;
        color: #8CCF95;
    }
    #review_subject.vocabulary,
    #lesson_subject.vocabulary {
        color: #4BE47D;
    }
    #review_subject.kanji,
    #lesson_subject.kanji {
        color: #FF9552;
    }
    #review_subject.radical,
    #lesson_subject.radical {
        color: #D678FF;
    }
    #review_subject.kana_vocabulary,
    #lesson_subject.kana_vocabulary {
        color: #FFE84A;
    }
    #review_subject.other,
    #lesson_subject.other {
        color: #D7D7D7;
    }
    #review_meta,
    #lesson_meta {
        color: #CDE0D0;
    }
    #review_mode {
        color: #CDE0D0;
    }
    #review_answer {
        border: tall $secondary;
        background: #0B140B;
        color: #DCEFE0;
    }
    #review_answer.meaning {
        border: heavy #E8C66A;
        color: #F7E2A2;
    }
    #review_answer.reading {
        border: heavy #6BC7FF;
        color: #BFE9FF;
    }
    #review_result_banner {
        display: none;
        height: 5;
        content-align: center middle;
        text-style: bold;
        margin: 0 0 1 0;
    }
    #review_result_banner.correct {
        display: block;
        color: $success;
        background: #0E1A0E;
        border: heavy $success;
    }
    #review_result_banner.incorrect {
        display: block;
        color: $error;
        background: #1A0E0E;
        border: heavy $error;
    }
    #review_mode.meaning,
    #lesson_meta.meaning {
        color: #E8C66A;
        text-style: bold;
        content-align: left middle;
    }
    #review_mode.reading,
    #lesson_meta.reading {
        color: #6BC7FF;
        text-style: bold;
        content-align: right middle;
    }
    #review_prompt.meaning,
    #lesson_prompt.meaning {
        border: heavy #E8C66A;
        background: #1A1608;
    }
    #review_prompt.reading,
    #lesson_prompt.reading {
        border: heavy #6BC7FF;
        background: #081620;
    }
    #review_actions,
    #lesson_session_actions {
        height: auto;
        margin: 1 0;
    }
    #review_actions Button,
    #lesson_session_actions Button {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    #review_actions Button:last-child,
    #lesson_session_actions Button:last-child {
        margin-right: 0;
    }
    #review_status,
    #lesson_session_status,
    #status {
        height: 2;
        border: tall $accent;
        background: #0D120D;
        padding: 0 1;
        color: #DCEFE0;
    }
    #review_status.success,
    #lesson_session_status.success,
    #status.success {
        color: $success;
    }
    #review_status.warning,
    #lesson_session_status.warning,
    #status.warning {
        color: $warning;
    }
    #review_status.error,
    #lesson_session_status.error,
    #status.error {
        color: $error;
    }
    #review_status.info,
    #lesson_session_status.info,
    #status.info {
        color: $primary;
    }
    #status {
        display: none;
    }
    #lessons_view {
        padding-right: 1;
    }
    #lessons_rows {
        min-height: 10;
        border: heavy $secondary;
        background: #0B140B;
        color: #D3E8D6;
        margin: 1 0;
        padding: 1;
    }
    #lessons_controls {
        height: auto;
        margin: 0 0 1 0;
    }
    #lessons_controls Button {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    #lessons_controls Button:last-child {
        margin-right: 0;
    }
    #lessons_custom_row {
        height: auto;
        margin: 0 0 1 0;
    }
    #lessons_custom_count {
        width: 16;
        margin-right: 1;
    }
    #lesson_reveal {
        min-height: 4;
        border: tall $accent;
        background: #0A140A;
        color: #DDECDD;
        margin: 1 0;
        padding: 1;
    }
    #help_overlay {
        display: none;
        position: absolute;
        width: 100%;
        height: 100%;
        layer: overlay;
        align: center middle;
        background: #000000;
    }
    #help_panel {
        width: 90;
        max-width: 96%;
        max-height: 90%;
        border: heavy $primary;
        background: #060906;
        padding: 1 2;
    }
    #help_title {
        color: $primary;
        text-style: bold;
        margin: 0 0 1 0;
    }
    #help_body {
        color: #D4E8D8;
    }
    #help_hint {
        color: #BFD5C3;
        margin: 1 0 0 0;
    }
    """

    BINDINGS = [
        Binding("question_mark", "toggle_help", "Help"),
        Binding("v", "start_reviews", "Reviews"),
        Binding("l", "start_lessons_default", "Lessons"),
        Binding("i", "open_lessons_center", "Lessons Center"),
        Binding("o", "open_setup", "Setup"),
        Binding("p", "open_settings", "Settings"),
        Binding("d", "run_doctor", "Doctor"),
        Binding("y", "run_sync", "Sync"),
        Binding("u", "run_queue_list", "Queue"),
        Binding("t", "run_retry", "Retry"),
        Binding("ctrl+f", "focus_feedback", "Feedback"),
        Binding("ctrl+r", "reveal_review", "Reveal"),
        Binding("g", "mark_lesson_got_it", "Lesson Got"),
        Binding("n", "mark_lesson_need_work", "Lesson Need"),
        Binding("ctrl+w", "wrap_up_review", "Wrap Up", priority=True),
        Binding("escape", "escape_back", "Back"),
        Binding("ctrl+q", "quit_app", "Quit"),
        Binding("ctrl+c", "quit_app", "Quit"),
    ]

    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self._settings = settings
        self._register_themes()
        self.theme = textual_theme_name(self._settings.theme)
        self._review_engine: ReviewEngine | None = None
        self._review_client: WaniKaniClient | None = None
        self._review_repo: WKRepository | None = None
        self._review_queue: ReviewSubmissionQueue | None = None
        self._review_stats = ReviewSubmissionStats()
        self._review_trend: list[float] = []
        self._review_ime_mutation = False
        self._lessons_rows: list[tuple[AssignmentResource, SubjectResource]] = []
        self._lesson_steps: list[LessonStep] = []
        self._lesson_index = 0
        self._lesson_revealed = False
        self._lesson_scores: list[float] = []
        self._status_message = ""
        self._help_visible = False

    def compose(self) -> ComposeResult:
        token_status = "present" if self._settings.api_token else "missing (run setup)"
        with Vertical(id="container"):
            yield Static(
                "wkler hub | reviews + lessons stay in one app | theme in settings",
                id="title",
            )
            yield Static(f"API token: {token_status} | ? help", id="subtitle")
            with Horizontal(id="loading_row"):
                yield LoadingIndicator()
                yield Static("", id="loading_text")
            with ContentSwitcher(initial="home_view", id="views"):
                with Vertical(id="home_view", classes="view"):
                    yield Static("Study", classes="section-title")
                    yield Static(
                        "No relaunch loop: reviews and lessons run inline.",
                        classes="description",
                    )
                    with Horizontal(classes="button-row"):
                        yield Button("Start Reviews", id="reviews", variant="success")
                        yield Button(
                            "Start Default Lessons", id="lessons_default", variant="primary"
                        )
                        yield Button("Lessons Center", id="lessons_list", variant="default")
                    yield Rule(line_style="heavy")
                    yield Static("Config + Maintenance", classes="section-title")
                    with Horizontal(classes="button-row"):
                        yield Button("Setup", id="setup", variant="default")
                        yield Button("Settings", id="settings", variant="default")
                        yield Button("Doctor", id="doctor", variant="default")
                        yield Button("Help", id="help", variant="default")
                    with Horizontal(classes="button-row"):
                        yield Button("Sync", id="sync", variant="default")
                        yield Button("Queue List", id="queue_list", variant="default")
                        yield Button("Retry Queue", id="retry", variant="default")
                    with Horizontal(classes="button-row"):
                        yield Input(
                            placeholder="Feedback note (press Enter)",
                            id="feedback_note",
                        )
                        yield Button("Submit Feedback", id="feedback", variant="primary")
                with Vertical(id="review_view", classes="view"):
                    yield Static("Reviews", classes="section-title")
                    yield Rule(line_style="dashed")
                    yield ProgressBar(total=1, id="review_progress")
                    yield Sparkline(
                        [],
                        id="review_spark",
                        min_color=_INCORRECT_COLOR,
                        max_color=_CORRECT_COLOR,
                    )
                    with Horizontal(id="review_subject_row"):
                        yield Static("", id="review_subject")
                        yield Static("", id="review_last_wrong")
                        yield Static("", id="review_last_right")
                    yield Static("", id="review_prompt")
                    yield Static("", id="review_meta")
                    yield Static("", id="review_mode")
                    yield Input(placeholder="Type answer and press Enter", id="review_answer")
                    yield Static("", id="review_result_banner")
                    with Horizontal(id="review_actions"):
                        yield Button("Submit", id="review_submit_btn", variant="success")
                        yield Button("Reveal", id="review_reveal_btn", variant="warning")
                        yield Button("Wrap Up (Ctrl+W)", id="review_wrap_btn", variant="default")
                        yield Button("Back Home", id="review_back_btn", variant="default")
                    yield Static("", id="review_status", classes="info")
                with VerticalScroll(id="lessons_view", classes="view"):
                    yield Static("Lessons Center", classes="section-title")
                    yield Static(
                        "Load lessons, choose batch size, then start "
                        "an interactive lesson session.",
                        classes="description",
                    )
                    yield Rule(line_style="dashed")
                    yield Static("", id="lessons_summary")
                    yield Static("", id="lessons_rows")
                    with Horizontal(id="lessons_controls"):
                        yield Button("Refresh", id="lessons_refresh_btn", variant="default")
                        yield Button(
                            "Start Default",
                            id="lessons_start_default_btn",
                            variant="primary",
                        )
                        yield Button("Start 5", id="lessons_start_five_btn", variant="default")
                        yield Button("Start All", id="lessons_start_all_btn", variant="warning")
                    with Horizontal(id="lessons_custom_row"):
                        yield Input(
                            value=str(self._settings.lesson_batch_size),
                            id="lessons_custom_count",
                            placeholder="Custom count",
                        )
                        yield Button(
                            "Start Custom", id="lessons_start_custom_btn", variant="success"
                        )
                        yield Button("Back Home", id="lessons_back_home_btn", variant="default")
                with Vertical(id="lesson_session_view", classes="view"):
                    yield Static("Lesson Session", classes="section-title")
                    yield Rule(line_style="heavy")
                    yield ProgressBar(total=1, id="lesson_progress")
                    yield Sparkline(
                        [],
                        id="lesson_spark",
                        min_color=_INCORRECT_COLOR,
                        max_color=_CORRECT_COLOR,
                    )
                    yield Static("", id="lesson_subject")
                    yield Static("", id="lesson_prompt")
                    yield Static("", id="lesson_meta")
                    yield Static("Press Reveal to show lesson details.", id="lesson_reveal")
                    with Horizontal(id="lesson_session_actions"):
                        yield Button("Reveal", id="lesson_reveal_btn", variant="warning")
                        yield Button("Got It", id="lesson_got_btn", variant="success")
                        yield Button("Need Work", id="lesson_need_btn", variant="error")
                        yield Button("Exit", id="lesson_exit_btn", variant="default")
                    yield Static("", id="lesson_session_status", classes="info")
            yield Static("", id="status", classes="info")
        with Vertical(id="help_overlay"):
            with VerticalScroll(id="help_panel"):
                yield Static("Keyboard Help", id="help_title")
                yield Rule(line_style="heavy")
                yield Static(_HELP_TEXT, id="help_body")
                yield Static("Press ? or Esc to close.", id="help_hint")

    def on_mount(self) -> None:
        self._set_busy(False, "")
        self._set_status("Ready. Start reviews or lessons without leaving the app.", level="info")
        self.query_one("#reviews", Button).focus()

    def on_unmount(self) -> None:
        self._close_review_resources()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        if button_id is None:
            return

        if button_id == "reviews":
            self._start_review_session()
            return
        if button_id == "lessons_default":
            self._start_default_lessons_session()
            return
        if button_id == "lessons_list":
            self._open_lessons_center()
            return
        if button_id == "help":
            self.action_toggle_help()
            return

        if button_id == "setup":
            self.exit(HomeSelection(action="setup"))
            return
        if button_id == "settings":
            self.exit(HomeSelection(action="settings"))
            return
        if button_id == "doctor":
            self.exit(HomeSelection(action="doctor"))
            return
        if button_id == "sync":
            self.exit(HomeSelection(action="sync"))
            return
        if button_id == "queue_list":
            self.exit(HomeSelection(action="queue_list"))
            return
        if button_id == "retry":
            self.exit(HomeSelection(action="retry"))
            return

        if button_id == "feedback":
            self._submit_home_feedback()
            return

        if button_id == "review_submit_btn":
            self._submit_review_answer()
            return
        if button_id == "review_reveal_btn":
            self._reveal_review_answer()
            return
        if button_id == "review_wrap_btn":
            self._enable_review_wrap_up()
            return
        if button_id == "review_back_btn":
            self._back_to_home_from_review()
            return

        if button_id == "lessons_refresh_btn":
            self._load_lessons_rows()
            return
        if button_id == "lessons_start_default_btn":
            self._start_lessons_with_count(self._settings.lesson_batch_size)
            return
        if button_id == "lessons_start_five_btn":
            self._start_lessons_with_count(5)
            return
        if button_id == "lessons_start_all_btn":
            self._start_lessons_with_count(len(self._lessons_rows), start_all=True)
            return
        if button_id == "lessons_start_custom_btn":
            self._start_lessons_with_count(self._read_custom_lessons_count())
            return
        if button_id == "lessons_back_home_btn":
            self._set_view("home_view")
            self.query_one("#reviews", Button).focus()
            return

        if button_id == "lesson_reveal_btn":
            self._reveal_lesson_step()
            return
        if button_id == "lesson_got_btn":
            self._score_lesson_step(1.0)
            return
        if button_id == "lesson_need_btn":
            self._score_lesson_step(0.0)
            return
        if button_id == "lesson_exit_btn":
            self._set_view("home_view")
            self.query_one("#reviews", Button).focus()
            self._set_status("Returned from lesson session.", level="info")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if self._help_visible:
            return
        input_id = event.input.id
        if input_id == "review_answer":
            self._submit_review_answer()
            return
        if input_id == "feedback_note":
            self._submit_home_feedback()
            return
        if input_id == "lessons_custom_count":
            self._start_lessons_with_count(self._read_custom_lessons_count())

    def on_input_changed(self, event: Input.Changed) -> None:
        if self._help_visible:
            return
        if event.input.id != "review_answer":
            return
        if self._review_ime_mutation:
            return
        if self._review_engine is None or self._review_engine.is_done():
            return
        if self._review_engine.awaiting_incorrect_continue:
            return
        if self._review_engine.awaiting_correct_continue:
            return
        question = self._review_engine.current_question()
        if question.kind != "reading":
            return
        converted = apply_reading_ime(
            event.value,
            mode=self._settings.reading_input_mode,
            convert_ending=False,
        )
        if converted == event.value:
            return
        self._review_ime_mutation = True
        event.input.value = converted
        self._review_ime_mutation = False

    def action_start_reviews(self) -> None:
        if self._help_visible:
            return
        self._start_review_session()

    def action_start_lessons_default(self) -> None:
        if self._help_visible:
            return
        self._start_default_lessons_session()

    def action_open_lessons_center(self) -> None:
        if self._help_visible:
            return
        self._open_lessons_center()

    def action_open_setup(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="setup"))

    def action_open_settings(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="settings"))

    def action_run_doctor(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="doctor"))

    def action_run_sync(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="sync"))

    def action_run_queue_list(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="queue_list"))

    def action_run_retry(self) -> None:
        if self._help_visible:
            return
        self.exit(HomeSelection(action="retry"))

    def action_focus_feedback(self) -> None:
        if self._help_visible:
            return
        if self._active_view() != "home_view":
            self._set_view("home_view")
        self.query_one("#feedback_note", Input).focus()
        self._set_status("Feedback input focused.", level="info")

    def action_reveal_review(self) -> None:
        if self._help_visible:
            return
        active = self._active_view()
        if active == "review_view":
            self._reveal_review_answer()
            return
        if active == "lesson_session_view":
            self._reveal_lesson_step()

    def action_mark_lesson_got_it(self) -> None:
        if self._help_visible:
            return
        if self._active_view() == "lesson_session_view":
            self._score_lesson_step(1.0)

    def action_mark_lesson_need_work(self) -> None:
        if self._help_visible:
            return
        if self._active_view() == "lesson_session_view":
            self._score_lesson_step(0.0)

    def action_wrap_up_review(self) -> None:
        if self._help_visible:
            return
        if self._active_view() == "review_view":
            self._enable_review_wrap_up()

    def action_toggle_help(self) -> None:
        if self._help_visible:
            self._hide_help()
            return
        self._show_help()

    def action_escape_back(self) -> None:
        if self._help_visible:
            self._hide_help()
            return
        active = self._active_view()
        if active == "review_view":
            self._back_to_home_from_review()
            return
        if active in {"lessons_view", "lesson_session_view"}:
            self._set_view("home_view")
            self.query_one("#reviews", Button).focus()
            return
        self._close_review_resources()
        self.exit(None)

    def action_quit_app(self) -> None:
        self._close_review_resources()
        self.exit(None)

    def _active_view(self) -> str:
        switcher = self.query_one("#views", ContentSwitcher)
        return switcher.current or "home_view"

    def _set_view(self, view_id: str) -> None:
        switcher = self.query_one("#views", ContentSwitcher)
        switcher.current = view_id
        self._refresh_global_status_visibility()

    def _show_help(self) -> None:
        overlay = self.query_one("#help_overlay", Vertical)
        overlay.display = True
        self._help_visible = True

    def _hide_help(self) -> None:
        overlay = self.query_one("#help_overlay", Vertical)
        overlay.display = False
        self._help_visible = False
        self._refocus_active_view()

    def _refocus_active_view(self) -> None:
        active = self._active_view()
        try:
            if active == "home_view":
                self.query_one("#reviews", Button).focus()
                return
            if active == "review_view":
                answer = self.query_one("#review_answer", Input)
                if answer.disabled:
                    self.query_one("#review_back_btn", Button).focus()
                else:
                    answer.focus()
                return
            if active == "lessons_view":
                self.query_one("#lessons_refresh_btn", Button).focus()
                return
            if active == "lesson_session_view":
                self.query_one("#lesson_reveal_btn", Button).focus()
        except Exception:
            return

    def _set_busy(self, busy: bool, message: str) -> None:
        row = self.query_one("#loading_row", Horizontal)
        row.display = busy
        self.query_one("#loading_text", Static).update(message)

    def _set_status(self, message: str, *, level: StatusLevel) -> None:
        self._status_message = message.strip()
        status = self.query_one("#status", Static)
        status.update(self._status_message)
        status.set_classes(level)
        self._refresh_global_status_visibility()

    def _set_review_status(self, message: str, *, level: StatusLevel) -> None:
        node = self.query_one("#review_status", Static)
        node.update(message)
        node.set_classes(level)

    def _set_review_last_error(self, wrong: str | None = None, correct: str | None = None) -> None:
        wrong_node = self.query_one("#review_last_wrong", Static)
        correct_node = self.query_one("#review_last_right", Static)
        wrong_value = (wrong or "").strip()
        correct_value = (correct or "").strip()
        wrong_node.update(wrong_value)
        correct_node.update(correct_value)
        wrong_node.display = bool(wrong_value)
        correct_node.display = bool(correct_value)

    def _set_lesson_status(self, message: str, *, level: StatusLevel) -> None:
        node = self.query_one("#lesson_session_status", Static)
        node.update(message)
        node.set_classes(level)

    def _refresh_global_status_visibility(self) -> None:
        status = self.query_one("#status", Static)
        visible = self._active_view() == "home_view" and bool(self._status_message)
        status.display = visible

    def _submit_home_feedback(self) -> None:
        note_input = self.query_one("#feedback_note", Input)
        note = note_input.value.strip()
        if not note:
            self._set_status("Feedback note is empty.", level="warning")
            return
        self.exit(HomeSelection(action="feedback", feedback_note=note))

    def _start_review_session(self) -> None:
        if not self._settings.api_token:
            self._set_status("API token is missing. Run setup first.", level="error")
            return
        self._set_busy(True, "Syncing review assignments...")
        self._set_review_status("Preparing review session...", level="info")
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            queue = ReviewSubmissionQueue(self._settings.db_path, self._settings.api_token)
            assignments = client.list_reviewable_assignments()
            assignments, subjects_by_id = _hydrate_assignments(client, repo, assignments)
            if not assignments:
                client.close()
                self._set_status("No reviews are due right now.", level="info")
                self._set_busy(False, "")
                return
            session_items = build_session_items(assignments, subjects_by_id)
            if not session_items:
                client.close()
                self._set_status("No reviewable session items were prepared.", level="error")
                self._set_busy(False, "")
                return
            self._review_client = client
            self._review_repo = repo
            self._review_queue = queue
            self._review_engine = ReviewEngine(
                session_items,
                reading_input_mode=self._settings.reading_input_mode,
                shuffle_mode=self._settings.review_shuffle_mode,
                shuffle_window=self._settings.review_shuffle_window,
                seed=None,
                second_chance_enabled=self._settings.review_second_chance,
                confirm_result_enabled=self._settings.review_confirm_result,
            )
            self._review_stats = ReviewSubmissionStats()
            self._review_trend = []
            self.query_one("#review_progress", ProgressBar).update(
                total=len(session_items),
                progress=0,
            )
            self.query_one("#review_spark", Sparkline).data = []
            self._set_review_last_error(None)
            self._set_view("review_view")
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            self._set_status("Review session started.", level="success")
        except Exception as exc:
            self._close_review_resources()
            get_logger().exception("review session bootstrap failed")
            self._set_status(f"Failed to prepare reviews: {exc}", level="error")
        finally:
            self._set_busy(False, "")

    def _render_review_state(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_wrap_up_chrome(False)
            return
        stats = engine.stats()
        self._set_wrap_up_chrome(engine.wrap_up_enabled)
        subject = self.query_one("#review_subject", Static)
        header = self.query_one("#review_meta", Static)
        mode = self.query_one("#review_mode", Static)
        prompt = self.query_one("#review_prompt", Static)
        answer = self.query_one("#review_answer", Input)
        progress = self.query_one("#review_progress", ProgressBar)
        if engine.is_done():
            counts = self._queue_counts_safe()
            wrap_up_suffix = ""
            if engine.wrap_up_enabled:
                wrap_up_suffix = f" deferred={stats['deferred_remaining']}"
            prompt.update(
                "Review session complete.\n"
                f"attempted={stats['attempted']} correct_first_try={stats['correct_first_try']} "
                f"incorrect={stats['total_incorrect']}{wrap_up_suffix}"
            )
            header.update(
                f"submitted={self._review_stats.submitted_immediate} "
                f"queued={self._review_stats.queued_for_retry} "
                f"pending={counts.pending} failed={counts.failed}"
            )
            mode.update("Press Back Home to return.")
            mode.set_classes("")
            prompt.set_classes("")
            answer.set_classes("")
            subject.update("")
            subject.set_classes("")
            self._set_review_last_error(None)
            progress.update(total=max(1, stats["total"]), progress=stats["attempted"])
            self._set_review_action_state(is_done=True)
            return

        question = engine.current_question()
        prompt_class = "reading" if question.kind == "reading" else "meaning"
        prompt.update(question.prompt)
        prompt.set_classes(prompt_class)
        answer.set_classes(prompt_class)
        subject.update(subject_badge_label(question.subject_type))
        subject.set_classes(
            f"{subject_badge_class(question.subject_type)} "
            f"{subject_badge_alignment_class(question.subject_type)}"
        )
        header.update(
            f"level {question.level or '?'} | remaining {stats['remaining']}"
            + (
                f" | wrap-up {engine.wrap_up_items_left()}"
                if engine.wrap_up_enabled
                else ""
            )
        )
        if question.kind == "reading":
            mode.update(">>> [R|JP] READING")
            mode.set_classes("reading")
        else:
            mode.update("[M|EN] MEANING <<<")
            mode.set_classes("meaning")
        progress.update(total=max(1, stats["total"]), progress=stats["attempted"])
        self._set_review_action_state(is_done=False)
        self._sync_review_result_banner()

    def _sync_review_result_banner(self) -> None:
        engine = self._review_engine
        banner = self.query_one("#review_result_banner", Static)
        if engine is None or engine.is_done():
            banner.set_classes("")
            return
        if engine.awaiting_correct_continue:
            banner.update("Correct!  Press Enter to continue.")
            banner.set_classes("correct")
        elif engine.awaiting_incorrect_continue:
            banner.update("Incorrect.  Press Enter to continue.")
            banner.set_classes("incorrect")
        else:
            banner.set_classes("")

    def _set_review_action_state(self, *, is_done: bool) -> None:
        self.query_one("#review_submit_btn", Button).disabled = is_done
        self.query_one("#review_reveal_btn", Button).disabled = is_done
        self.query_one("#review_wrap_btn", Button).disabled = is_done or (
            self._review_engine.wrap_up_enabled if self._review_engine is not None else True
        )
        self.query_one("#review_answer", Input).disabled = is_done

    def _set_wrap_up_chrome(self, enabled: bool) -> None:
        self.query_one("#container", Vertical).set_class(enabled, "wrap-up")

    def _enable_review_wrap_up(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        if engine.wrap_up_enabled:
            self._set_review_status(
                f"Wrap Up already active: {engine.wrap_up_items_left()} left.",
                level="info",
            )
            return
        count = engine.enable_wrap_up(limit=10)
        self.query_one("#review_answer", Input).value = ""
        self._set_review_status(f"Wrap Up active: {count} left.", level="warning")
        self._render_review_state()
        self.query_one("#review_answer", Input).focus()

    def _submit_review_answer(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        if engine.awaiting_correct_continue:
            self._continue_after_correct()
            return
        if engine.awaiting_incorrect_continue:
            self._continue_after_incorrect()
            return
        answer_input = self.query_one("#review_answer", Input)
        answer = answer_input.value.strip()
        if not answer:
            self._set_review_status("Answer is empty.", level="warning")
            return
        question = engine.current_question()
        result = engine.submit(answer)
        answer_input.value = ""
        self._handle_review_result(
            result,
            accepted_answers=question.accepted_answers,
            attempted_answer=answer,
            prompt_text=question.prompt,
        )

    def _continue_after_incorrect(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        try:
            result = engine.continue_after_incorrect()
        except RuntimeError:
            self._set_review_status("No pending incorrect answer to continue.", level="warning")
            return
        self.query_one("#review_answer", Input).value = ""
        self._handle_review_result(
            result,
            record_trend=False,
            feedback_override="Continuing.",
            level_override="info",
        )

    def _continue_after_correct(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        try:
            result = engine.continue_after_correct()
        except RuntimeError:
            self._set_review_status("No pending correct answer to continue.", level="warning")
            return
        self.query_one("#review_answer", Input).value = ""
        self._handle_review_result(
            result,
            record_trend=False,
            feedback_override="Continuing.",
            level_override="info",
        )

    def _reveal_review_answer(self) -> None:
        engine = self._review_engine
        if engine is None:
            self._set_review_status("Start reviews first.", level="warning")
            return
        if engine.is_done():
            self._set_review_status("Session already complete.", level="info")
            return
        had_pending_incorrect = engine.awaiting_incorrect_continue
        result = engine.reveal()
        self.query_one("#review_answer", Input).value = ""
        self._handle_review_result(result, record_trend=not had_pending_incorrect)

    def _handle_review_result(
        self,
        result: object,
        *,
        accepted_answers: list[str] | None = None,
        attempted_answer: str | None = None,
        prompt_text: str | None = None,
        record_trend: bool = True,
        feedback_override: str | None = None,
        level_override: StatusLevel | None = None,
    ) -> None:
        from wkler.review.engine import SubmissionResult

        if not isinstance(result, SubmissionResult):
            self._set_review_status("Unexpected review result.", level="error")
            return

        if result.outcome == "retry":
            if attempted_answer is not None:
                self._set_review_last_error(f"You typed: {attempted_answer}", None)
            self._set_review_status("Try again.", level="warning")
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            return

        if result.outcome == "correct_pending":
            self._set_review_last_error(None)
            self._set_review_status(
                "Correct. Press Enter to confirm.", level="success"
            )
            self._render_review_state()
            self.query_one("#review_answer", Input).focus()
            return

        feedback = feedback_override or result.feedback
        is_alternate_reading = result.outcome == "alternate_reading"
        level: StatusLevel
        if is_alternate_reading:
            level = "warning"
        elif result.revealed:
            level = "warning"
        elif not result.correct and not result.advanced:
            level = "error"
        elif result.correct:
            level = "success"
        else:
            level = "info"
        if level_override is not None:
            level = level_override

        if result.correct and not result.revealed:
            self._set_review_last_error(None)

        if (
            not result.correct
            and not result.advanced
            and not result.revealed
            and not is_alternate_reading
            and accepted_answers is not None
        ):
            self._set_review_last_error(
                *format_last_miss_parts(
                    prompt_text or "",
                    attempted_answer or "",
                    accepted_answers,
                )
            )
            feedback = "Incorrect. Press Enter to continue."
            level = "error"

        if result.completed_review is not None:
            completion_message, completion_level = self._submit_or_queue_sync(
                result.completed_review
            )
            feedback = completion_message
            level = completion_level

        if record_trend and not is_alternate_reading:
            self._review_trend.append(1.0 if result.correct and not result.revealed else 0.0)
            self.query_one("#review_spark", Sparkline).data = self._review_trend[-40:]
        self._set_review_status(feedback, level=level)
        self._render_review_state()
        self.query_one("#review_answer", Input).focus()
        if self._review_engine is not None and self._review_engine.is_done():
            self._retry_queue_after_review()

    def _submit_or_queue_sync(self, review: CompletedReview) -> tuple[str, StatusLevel]:
        client = self._review_client
        repo = self._review_repo
        queue = self._review_queue
        if client is None or repo is None or queue is None:
            return ("Review resources are unavailable.", "error")
        logger = get_logger()
        try:
            client.create_review(
                assignment_id=review.assignment_id,
                incorrect_meaning_answers=review.incorrect_meaning_answers,
                incorrect_reading_answers=review.incorrect_reading_answers,
                assignment_available_at=review.available_at,
            )
            repo.log_review(review)
            self._review_stats.submitted_immediate += 1
            logger.info(
                "review submitted",
                extra={
                    "event_type": "review_submit_immediate",
                    "assignment_id": review.assignment_id,
                    "subject_id": review.subject_id,
                },
            )
            return ("Submitted.", "success")
        except Exception as submit_error:
            try:
                job_ulid = queue.enqueue_failed_submission(
                    review,
                    error_message=str(submit_error),
                )
            except Exception as queue_error:
                self._review_stats.queue_errors += 1
                logger.error(
                    "review submit and queue failed",
                    extra={
                        "event_type": "review_submit_queue_error",
                        "assignment_id": review.assignment_id,
                        "subject_id": review.subject_id,
                        "error": str(queue_error),
                    },
                )
                return (f"Submit failed and queue failed: {queue_error}", "error")
            self._review_stats.queued_for_retry += 1
            logger.warning(
                "review queued for retry",
                extra={
                    "event_type": "review_submit_queued",
                    "assignment_id": review.assignment_id,
                    "subject_id": review.subject_id,
                    "queue_job_id": job_ulid,
                    "error": str(submit_error),
                },
            )
            return (f"Queued for retry ({job_ulid[:8]}).", "warning")

    def _retry_queue_after_review(self) -> None:
        queue = self._review_queue
        if queue is None:
            return
        try:
            counts = queue.queue_counts()
            if counts.pending > 0 or counts.failed > 0:
                queue.retry(
                    limit=10,
                    all_jobs=False,
                    dry_run=False,
                    retry_failed=True,
                )
        except Exception as exc:
            get_logger().warning(f"queue retry after review failed: {exc}")

    def _queue_counts_safe(self) -> QueueCounts:
        queue = self._review_queue
        if queue is None:
            return QueueCounts(pending=0, failed=0, running=0, completed=0, cancelled=0)
        try:
            return queue.queue_counts()
        except Exception:
            return QueueCounts(pending=0, failed=0, running=0, completed=0, cancelled=0)

    def _back_to_home_from_review(self) -> None:
        self._close_review_resources()
        self._review_engine = None
        self._review_trend = []
        self._set_review_last_error(None)
        self._set_wrap_up_chrome(False)
        self._set_view("home_view")
        self.query_one("#reviews", Button).focus()
        self._set_status("Returned from reviews.", level="info")

    def _close_review_resources(self) -> None:
        if self._review_client is not None:
            try:
                self._review_client.close()
            except Exception:
                pass
        self._review_client = None
        self._review_repo = None
        self._review_queue = None

    def _open_lessons_center(self) -> None:
        if not self._settings.api_token:
            self._set_status("API token is missing. Run setup first.", level="error")
            return
        self._set_view("lessons_view")
        self._load_lessons_rows()

    def _start_default_lessons_session(self) -> None:
        self._open_lessons_center()
        self._start_lessons_with_count(self._settings.lesson_batch_size)

    def _load_lessons_rows(self) -> None:
        if not self._settings.api_token:
            self._set_status("API token is missing. Run setup first.", level="error")
            return
        self._set_busy(True, "Loading lessons...")
        client: WaniKaniClient | None = None
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            assignments = client.list_available_lesson_assignments()
            assignments, subjects_by_id = _hydrate_assignments(client, repo, assignments)
            rows: list[tuple[AssignmentResource, SubjectResource]] = []
            for assignment in assignments:
                subject = subjects_by_id.get(assignment.data.subject_id)
                if subject is None:
                    continue
                rows.append((assignment, subject))
            self._lessons_rows = rows
            self._render_lessons_rows()
            self._set_status(f"Lessons loaded: {len(rows)} available.", level="success")
        except Exception as exc:
            get_logger().exception("lessons load failed")
            self._set_status(f"Failed to load lessons: {exc}", level="error")
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass
            self._set_busy(False, "")

    def _render_lessons_rows(self) -> None:
        summary = self.query_one("#lessons_summary", Static)
        rows_node = self.query_one("#lessons_rows", Static)
        if not self._lessons_rows:
            summary.update("No lessons are available right now.")
            rows_node.update("When lessons unlock, they will appear here.")
            return
        summary.update(f"{len(self._lessons_rows)} lesson assignment(s) available.")
        lines: list[str] = []
        for assignment, subject in self._lessons_rows[:25]:
            level = assignment.data.level or subject.data.level or 0
            prompt = _primary_prompt(subject)
            badge = subject_badge_label(assignment.data.subject_type)
            lines.append(
                f"id={assignment.id} level={level} {badge} prompt={prompt}"
            )
        rows_node.update("\n".join(lines))

    def _read_custom_lessons_count(self) -> int:
        raw = self.query_one("#lessons_custom_count", Input).value.strip()
        try:
            value = int(raw)
        except ValueError:
            self._set_status("Custom lesson count must be an integer.", level="error")
            return 0
        if value < 1:
            self._set_status("Custom lesson count must be >= 1.", level="error")
            return 0
        return value

    def _start_lessons_with_count(self, count: int, *, start_all: bool = False) -> None:
        if not self._settings.api_token:
            self._set_status("API token is missing. Run setup first.", level="error")
            return
        if not self._lessons_rows:
            self._load_lessons_rows()
        if not self._lessons_rows:
            self._set_status("No lessons available to start.", level="warning")
            return
        requested = len(self._lessons_rows) if start_all else min(count, len(self._lessons_rows))
        if requested <= 0:
            self._set_status("Requested lesson count must be greater than zero.", level="warning")
            return
        self._set_busy(True, "Starting lessons...")
        started_rows: list[tuple[AssignmentResource, SubjectResource]] = []
        started = 0
        failed = 0
        client: WaniKaniClient | None = None
        try:
            client = WaniKaniClient(self._settings.api_token)
            repo = WKRepository(self._settings.db_path)
            subjects_by_assignment = {
                assignment.id: subject for assignment, subject in self._lessons_rows
            }
            for assignment, _subject in self._lessons_rows[:requested]:
                try:
                    updated = client.start_assignment(assignment.id)
                except Exception as exc:
                    failed += 1
                    get_logger().warning(
                        f"lesson start failed id={assignment.id} err={exc}"
                    )
                    continue
                repo.upsert_assignments([updated])
                subject = subjects_by_assignment.get(updated.id)
                if subject is None:
                    subject = _subject
                started_rows.append((updated, subject))
                started += 1
        except Exception as exc:
            get_logger().exception("lesson start failed")
            self._set_status(f"Failed to start lessons: {exc}", level="error")
            return
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass
            self._set_busy(False, "")

        if started == 0:
            self._set_status("No lessons were started.", level="warning")
            return

        self._lesson_steps = build_lesson_steps(started_rows)
        if not self._lesson_steps:
            self._set_status("No lesson steps could be built.", level="error")
            return

        self._lesson_index = 0
        self._lesson_revealed = False
        self._lesson_scores = []
        self.query_one("#lesson_progress", ProgressBar).update(
            total=len(self._lesson_steps),
            progress=0,
        )
        self.query_one("#lesson_spark", Sparkline).data = []
        self._set_view("lesson_session_view")
        self._render_lesson_step()
        self._set_lesson_status(
            f"Lesson session started. requested={requested} started={started} failed={failed}",
            level="info",
        )
        self._set_status(
            f"Lesson start summary: requested={requested} started={started} failed={failed}",
            level="success",
        )

    def _render_lesson_step(self) -> None:
        progress = self.query_one("#lesson_progress", ProgressBar)
        reveal = self.query_one("#lesson_reveal", Static)
        meta = self.query_one("#lesson_meta", Static)
        subject = self.query_one("#lesson_subject", Static)
        prompt = self.query_one("#lesson_prompt", Static)
        if self._lesson_index >= len(self._lesson_steps):
            total = len(self._lesson_scores)
            confident = sum(1 for value in self._lesson_scores if value >= 1.0)
            need_work = total - confident
            prompt.update(
                "Lesson session complete.\n"
                f"steps={len(self._lesson_steps)} confident={confident} need_work={need_work}"
            )
            meta.update("Press Exit to return home.")
            meta.set_classes("")
            subject.update("")
            subject.set_classes("")
            prompt.set_classes("")
            reveal.update("Great work. Use settings for persistent theme and behavior changes.")
            progress.update(total=max(1, len(self._lesson_steps)), progress=len(self._lesson_steps))
            self._set_lesson_action_state(is_done=True, revealed=True)
            return

        step = self._lesson_steps[self._lesson_index]
        stage_class = "reading" if step.stage == "reading" else "meaning"
        subject.update(subject_badge_label(step.subject_type))
        subject.set_classes(
            f"{subject_badge_class(step.subject_type)} "
            f"{subject_badge_alignment_class(step.subject_type)}"
        )
        prompt.update(step.prompt)
        prompt.set_classes(stage_class)
        meta.update(
            
                f"[M|EN] MEANING <<< | step {self._lesson_index + 1}/{len(self._lesson_steps)}"
                if step.stage != "reading"
                else f"step {self._lesson_index + 1}/{len(self._lesson_steps)} | >>> [R|JP] READING"
            
        )
        meta.set_classes(stage_class)
        if self._lesson_revealed:
            reveal.update(
                f"Meanings: {', '.join(step.meanings) or '-'}\n"
                f"Readings: {', '.join(step.readings) or '-'}"
            )
        else:
            reveal.update("Press Reveal to show lesson details.")
        progress.update(total=max(1, len(self._lesson_steps)), progress=self._lesson_index)
        self._set_lesson_action_state(is_done=False, revealed=self._lesson_revealed)

    def _set_lesson_action_state(self, *, is_done: bool, revealed: bool) -> None:
        reveal_btn = self.query_one("#lesson_reveal_btn", Button)
        got_btn = self.query_one("#lesson_got_btn", Button)
        need_btn = self.query_one("#lesson_need_btn", Button)
        if is_done:
            reveal_btn.disabled = True
            got_btn.disabled = True
            need_btn.disabled = True
            return
        reveal_btn.disabled = revealed
        got_btn.disabled = not revealed
        need_btn.disabled = not revealed

    def _reveal_lesson_step(self) -> None:
        if self._lesson_index >= len(self._lesson_steps):
            self._set_lesson_status("Lesson session is complete.", level="info")
            return
        self._lesson_revealed = True
        self._render_lesson_step()
        self._set_lesson_status("Revealed. Mark Got It or Need Work.", level="info")

    def _score_lesson_step(self, value: float) -> None:
        if self._lesson_index >= len(self._lesson_steps):
            self._set_lesson_status("Lesson session is complete.", level="info")
            return
        if not self._lesson_revealed:
            self._set_lesson_status("Reveal details before scoring.", level="warning")
            return
        self._lesson_scores.append(value)
        self.query_one("#lesson_spark", Sparkline).data = self._lesson_scores[-40:]
        self._lesson_index += 1
        self._lesson_revealed = False
        self._render_lesson_step()
        if value >= 1.0:
            self._set_lesson_status("Marked as confident.", level="success")
        else:
            self._set_lesson_status("Marked as need work.", level="warning")

    def _register_themes(self) -> None:
        for theme in THEMES.values():
            self.register_theme(theme)


def _hydrate_assignments(
    client: WaniKaniClient,
    repo: WKRepository,
    assignments: list[AssignmentResource],
) -> tuple[list[AssignmentResource], dict[int, SubjectResource]]:
    if not assignments:
        return [], {}
    repo.upsert_assignments(assignments)
    subject_ids = sorted({assignment.data.subject_id for assignment in assignments})
    cached_subjects = repo.get_cached_subjects(subject_ids)
    missing_ids = [subject_id for subject_id in subject_ids if subject_id not in cached_subjects]
    if missing_ids:
        fetched = client.get_subjects(missing_ids)
        repo.upsert_subjects(fetched.values())
        cached_subjects.update(fetched)
    return assignments, cached_subjects


def _primary_prompt(subject: SubjectResource) -> str:
    if subject.data.characters:
        return subject.data.characters
    for meaning in subject.data.meanings:
        if meaning.primary:
            return meaning.meaning
    if subject.data.meanings:
        return subject.data.meanings[0].meaning
    return "(no prompt)"


def _lesson_meanings(subject: SubjectResource) -> list[str]:
    accepted = [entry.meaning for entry in subject.data.meanings if entry.accepted_answer]
    if accepted:
        return list(dict.fromkeys(accepted))
    fallback = [entry.meaning for entry in subject.data.meanings]
    return list(dict.fromkeys(fallback))


def _lesson_readings(subject: SubjectResource) -> list[str]:
    accepted = [entry.reading for entry in subject.data.readings if entry.accepted_answer]
    if accepted:
        return list(dict.fromkeys(accepted))
    fallback = [entry.reading for entry in subject.data.readings]
    return list(dict.fromkeys(fallback))
