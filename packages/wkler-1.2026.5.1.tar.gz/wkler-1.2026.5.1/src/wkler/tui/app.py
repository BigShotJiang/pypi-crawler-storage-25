from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Input, Static

from wkler.review.engine import CompletedReview, ReviewEngine, SubmissionResult
from wkler.review.ime import apply_reading_ime
from wkler.tui.study_visuals import (
    format_last_miss_parts,
    subject_badge_class,
    subject_badge_label,
)
from wkler.tui.theme import THEMES, ThemeName, textual_theme_name

FeedbackLevel = Literal["success", "warning", "error", "info"]


@dataclass(slots=True)
class CompletionFeedback:
    message: str
    level: FeedbackLevel = "info"


class ReviewApp(App[dict[str, int]]):
    CSS = """
    Screen {
        align: center middle;
        background: $background;
    }
    #container {
        width: 80%;
        max-width: 100;
        min-height: 18;
        border: heavy $accent;
        background: $surface;
        padding: 1 2;
    }
    #container.wrap-up {
        border: heavy #E8C66A;
    }
    #header {
        color: $primary;
    }
    #prompt {
        height: 3;
        content-align: center middle;
        text-style: bold;
        border: heavy $secondary;
        margin: 1 0;
        background: $panel;
        color: $foreground;
    }
    #subject_row {
        height: 1;
        margin: 0 0 1 0;
    }
    #subject {
        width: 14;
        color: #D6EAD8;
        text-style: bold;
    }
    #last_wrong {
        display: none;
        width: 2fr;
        margin-left: 1;
        color: #D16C6C;
    }
    #last_right {
        display: none;
        width: 1fr;
        margin-left: 1;
        color: #8CCF95;
    }
    #subject.vocabulary {
        color: #6BC7FF;
    }
    #subject.kanji {
        color: #F5C688;
    }
    #subject.radical {
        color: #8CCEFF;
    }
    #subject.other {
        color: #D7D7D7;
    }
    #mode {
        color: $warning;
        margin: 0 0 1 0;
    }
    #actions {
        height: auto;
        margin: 0 0 1 0;
    }
    #actions Button {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    #actions Button:last-child {
        margin-right: 0;
    }
    #feedback {
        height: 2;
        color: #DCEFE0;
        background: #0D120D;
        border: tall $accent;
        padding: 0 1;
    }
    #feedback.success {
        color: $success;
    }
    #feedback.warning {
        color: $warning;
    }
    #feedback.error {
        color: $error;
    }
    #feedback.info {
        color: $primary;
    }
    #result_banner {
        display: none;
        height: 5;
        content-align: center middle;
        text-style: bold;
        margin: 0 0 1 0;
    }
    #result_banner.correct {
        display: block;
        color: $success;
        background: #0E1A0E;
        border: heavy $success;
    }
    #result_banner.incorrect {
        display: block;
        color: $error;
        background: #1A0E0E;
        border: heavy $error;
    }
    """

    BINDINGS = [
        Binding("ctrl+r", "reveal", "Reveal"),
        Binding("ctrl+w", "wrap_up", "Wrap Up", priority=True),
        Binding("ctrl+e", "focus_answer", "Answer"),
        Binding("escape", "quit_session", "Quit"),
        Binding("ctrl+q", "quit_session", "Quit"),
        Binding("ctrl+c", "quit_session", "Quit"),
    ]

    def __init__(
        self,
        engine: ReviewEngine,
        *,
        on_review_complete: Callable[[CompletedReview], Awaitable[CompletionFeedback | None]],
        theme_name: ThemeName = "default",
    ) -> None:
        super().__init__()
        self._engine = engine
        self._on_review_complete = on_review_complete
        self._failed_submissions = 0
        self._theme_name = theme_name
        self._ime_mutation = False
        self._register_themes()
        self.theme = textual_theme_name(self._theme_name)

    def compose(self) -> ComposeResult:
        with Vertical(id="container"):
            yield Static("", id="header")
            yield Static("", id="prompt")
            with Horizontal(id="subject_row"):
                yield Static("", id="subject")
                yield Static("", id="last_wrong")
                yield Static("", id="last_right")
            yield Static("", id="meta")
            yield Static("", id="mode")
            yield Input(placeholder="Enter answer and press Enter", id="answer")
            yield Static("", id="result_banner")
            with Horizontal(id="actions"):
                yield Button("Reveal", id="reveal_btn", variant="warning")
                yield Button("Wrap Up (Ctrl+W)", id="wrap_up_btn", variant="default")
                yield Button("Quit", id="quit_btn", variant="error")
            yield Static("", id="feedback", classes="info")

    def on_mount(self) -> None:
        self._render_state()
        self.query_one("#answer", Input).focus()
        self._set_feedback("Ready. Type an answer or use Reveal.", level="info")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        if button_id == "reveal_btn":
            await self.action_reveal()
            return
        if button_id == "wrap_up_btn":
            self.action_wrap_up()
            return
        if button_id == "quit_btn":
            self.action_quit_session()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "answer":
            return
        if self._ime_mutation or self._engine.is_done():
            return
        if self._engine.awaiting_incorrect_continue:
            return
        if self._engine.awaiting_correct_continue:
            return
        question = self._engine.current_question()
        if question.kind != "reading":
            return
        converted = apply_reading_ime(
            event.value,
            mode=self._engine.reading_input_mode,
            convert_ending=False,
        )
        if converted == event.value:
            return
        self._ime_mutation = True
        event.input.value = converted
        self._ime_mutation = False

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if self._engine.is_done():
            return
        if self._engine.awaiting_correct_continue:
            result = self._engine.continue_after_correct()
            event.input.value = ""
            await self._handle_result(
                result,
                feedback_override="Continuing.",
                level_override="info",
            )
            return
        if self._engine.awaiting_incorrect_continue:
            result = self._engine.continue_after_incorrect()
            event.input.value = ""
            await self._handle_result(
                result,
                feedback_override="Continuing.",
                level_override="info",
            )
            return
        question = self._engine.current_question()
        attempted = event.value
        result = self._engine.submit(event.value)
        event.input.value = ""
        if result.outcome == "retry":
            self._set_last_error(f"You typed: {attempted}", None)
            self._set_feedback("Try again.", level="warning")
            self._render_state()
            return
        if result.outcome == "correct_pending":
            self._set_last_error(None)
            self._set_feedback("Correct. Press Enter to confirm.", level="success")
            self._render_state()
            return
        if not result.correct and not result.advanced and not result.revealed:
            self._set_last_error(
                *format_last_miss_parts(
                    question.prompt,
                    attempted,
                    question.accepted_answers,
                )
            )
            self._set_feedback(
                "Incorrect. Press Enter to continue.",
                level="error",
            )
            self._render_state()
            return
        await self._handle_result(result)

    async def action_reveal(self) -> None:
        if self._engine.is_done():
            return
        was_pending_incorrect = self._engine.awaiting_incorrect_continue
        result = self._engine.reveal()
        if was_pending_incorrect:
            await self._handle_result(
                result,
                feedback_override="Continuing.",
                level_override="info",
            )
            return
        await self._handle_result(result)

    def action_focus_answer(self) -> None:
        self.query_one("#answer", Input).focus()
        self._set_feedback("Answer input focused.", level="info")

    def action_wrap_up(self) -> None:
        if self._engine.is_done():
            self._set_feedback("Session already complete.", level="info")
            return
        if self._engine.wrap_up_enabled:
            self._set_feedback(
                f"Wrap Up already active: {self._engine.wrap_up_items_left()} left.",
                level="info",
            )
            return
        count = self._engine.enable_wrap_up(limit=10)
        self.query_one("#answer", Input).value = ""
        self._set_feedback(f"Wrap Up active: {count} left.", level="warning")
        self._render_state()

    def action_quit_session(self) -> None:
        summary = self._engine.stats()
        summary["failed_submissions"] = self._failed_submissions
        summary["aborted"] = 1
        self.exit(summary)

    async def _handle_result(
        self,
        result: SubmissionResult,
        *,
        feedback_override: str | None = None,
        level_override: FeedbackLevel | None = None,
    ) -> None:
        feedback = feedback_override or result.feedback
        level: FeedbackLevel = level_override or self._result_level(result)
        if result.correct and not result.revealed:
            self._set_last_error(None)
        if result.completed_review is not None:
            try:
                completion_feedback = await self._on_review_complete(result.completed_review)
            except Exception as exc:  # pragma: no cover - UI side effect
                self._failed_submissions += 1
                feedback = (
                    f"Submit failed for assignment "
                    f"{result.completed_review.assignment_id}: {exc}"
                )
                level = "error"
            else:
                if completion_feedback is not None:
                    feedback = completion_feedback.message
                    level = completion_feedback.level

        self._set_feedback(feedback, level=level)
        self._render_state()

    def _render_state(self) -> None:
        stats = self._engine.stats()
        self._set_wrap_up_chrome(self._engine.wrap_up_enabled)
        wrap_suffix = (
            f" | wrap-up {self._engine.wrap_up_items_left()}"
            if self._engine.wrap_up_enabled
            else ""
        )
        self.query_one("#header", Static).update(
            "wkler reviews | "
            f"remaining {stats['remaining']} | "
            f"correct {stats['correct_first_try']} | "
            f"incorrect {stats['total_incorrect']}{wrap_suffix} | ctrl+r reveal | ctrl+w wrap"
        )
        self.query_one("#wrap_up_btn", Button).disabled = (
            self._engine.wrap_up_enabled or self._engine.is_done()
        )

        if self._engine.is_done():
            summary = self._engine.stats()
            summary["failed_submissions"] = self._failed_submissions
            self.exit(summary)
            return

        question = self._engine.current_question()
        self.query_one("#prompt", Static).update(question.prompt)
        subject = self.query_one("#subject", Static)
        subject.update(subject_badge_label(question.subject_type))
        subject.set_classes(subject_badge_class(question.subject_type))
        self.query_one("#meta", Static).update(f"level {question.level or '?'}")
        self.query_one("#mode", Static).update(question.mode_label)
        self._sync_result_banner()

    def _sync_result_banner(self) -> None:
        banner = self.query_one("#result_banner", Static)
        if self._engine.awaiting_correct_continue:
            banner.update("Correct!  Press Enter to continue.")
            banner.set_classes("correct")
        elif self._engine.awaiting_incorrect_continue:
            banner.update("Incorrect.  Press Enter to continue.")
            banner.set_classes("incorrect")
        else:
            banner.set_classes("")

    def _register_themes(self) -> None:
        for theme in THEMES.values():
            self.register_theme(theme)

    def _set_feedback(self, message: str, *, level: FeedbackLevel) -> None:
        feedback = self.query_one("#feedback", Static)
        feedback.update(message)
        feedback.set_classes(level)

    def _result_level(self, result: SubmissionResult) -> FeedbackLevel:
        if result.revealed:
            return "warning"
        if not result.correct and not result.advanced:
            return "error"
        if result.correct:
            return "success"
        return "info"

    def _set_last_error(self, wrong: str | None = None, correct: str | None = None) -> None:
        wrong_node = self.query_one("#last_wrong", Static)
        correct_node = self.query_one("#last_right", Static)
        wrong_value = (wrong or "").strip()
        correct_value = (correct or "").strip()
        wrong_node.update(wrong_value)
        correct_node.update(correct_value)
        wrong_node.display = bool(wrong_value)
        correct_node.display = bool(correct_value)

    def _set_wrap_up_chrome(self, enabled: bool) -> None:
        self.query_one("#container", Vertical).set_class(enabled, "wrap-up")
