from __future__ import annotations

from typing import Literal

from textual.theme import Theme

ThemeName = Literal["default", "retro", "colorful"]

THEME_ORDER: list[ThemeName] = ["default", "retro", "colorful"]

THEMES: dict[ThemeName, Theme] = {
    "default": Theme(
        name="wkler-default",
        primary="#8CCF95",
        secondary="#5F9D68",
        warning="#C9B26A",
        error="#D16C6C",
        success="#8CCF95",
        accent="#324233",
        foreground="#E7F4E9",
        background="#000000",
        surface="#070A07",
        panel="#000000",
        dark=True,
    ),
    "retro": Theme(
        name="wkler-retro",
        primary="#00D66F",
        secondary="#00A956",
        warning="#9AC955",
        error="#D95E72",
        success="#66C989",
        accent="#1F3A28",
        foreground="#C9F7D8",
        background="#000000",
        surface="#041004",
        panel="#000000",
        dark=True,
    ),
    "colorful": Theme(
        name="wkler-colorful",
        primary="#6BC7FF",
        secondary="#B48BFF",
        warning="#E8C66A",
        error="#F26B8A",
        success="#61D6B1",
        accent="#3B3F66",
        foreground="#F2F5FF",
        background="#000000",
        surface="#090A14",
        panel="#000000",
        dark=True,
    ),
}


def resolve_theme_name(value: str | None) -> ThemeName:
    if value in THEMES:
        return value
    return "default"


def next_theme_name(current: ThemeName) -> ThemeName:
    index = THEME_ORDER.index(current)
    return THEME_ORDER[(index + 1) % len(THEME_ORDER)]


def textual_theme_name(theme: ThemeName) -> str:
    return THEMES[theme].name
