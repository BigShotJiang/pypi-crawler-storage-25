from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Input, RadioButton, RadioSet, Static

from wkler.config import MAX_REVIEW_SHUFFLE_WINDOW, Settings
from wkler.tui.theme import THEMES, textual_theme_name

FeedbackCallback = Callable[[str], str]
FieldLevel = Literal["info", "warning", "error"]

_THEME_ID_TO_NAME = {
    "theme_default": "default",
    "theme_retro": "retro",
    "theme_colorful": "colorful",
}
_MODE_ID_TO_NAME = {
    "mode_always": "always",
    "mode_auto": "auto",
}
_SHUFFLE_MODE_ID_TO_NAME = {
    "shuffle_mode_rolling": "rolling",
    "shuffle_mode_full": "full",
    "shuffle_mode_none": "none",
}
_SECOND_CHANCE_ID_TO_VALUE = {
    "second_chance_on": True,
    "second_chance_off": False,
}
_CONFIRM_RESULT_ID_TO_VALUE = {
    "confirm_result_on": True,
    "confirm_result_off": False,
}
LESSON_PRESET_VALUES = (5, 10, 15, 20)
_PRESET_PREFIX = "lesson_preset_"
SHUFFLE_WINDOW_PRESET_VALUES = (10, 20, 40, 80)
_SHUFFLE_WINDOW_PRESET_PREFIX = "shuffle_window_preset_"


@dataclass(frozen=True, slots=True)
class ValidationState:
    errors: dict[str, str]
    warnings: dict[str, str]

    def is_valid(self) -> bool:
        return not self.errors

    def first_invalid_field(self) -> str | None:
        ordered = (
            "api_token",
            "lesson_batch_size",
            "review_shuffle_window",
            "db_path",
            "log_path",
            "crash_log_path",
        )
        for field in ordered:
            if field in self.errors:
                return field
        return None

    def message_for(self, field: str, *, default: str) -> tuple[str, FieldLevel]:
        if field in self.errors:
            return self.errors[field], "error"
        if field in self.warnings:
            return self.warnings[field], "warning"
        return default, "info"


def clamp_lesson_batch_size(value: int) -> int:
    return max(1, min(100, value))


def bump_lesson_batch_size(current: int, delta: int) -> int:
    return clamp_lesson_batch_size(current + delta)


def lesson_batch_from_preset_button(button_id: str) -> int | None:
    if not button_id.startswith(_PRESET_PREFIX):
        return None
    raw = button_id.removeprefix(_PRESET_PREFIX)
    if not raw.isdigit():
        return None
    return clamp_lesson_batch_size(int(raw))


def clamp_review_shuffle_window(value: int) -> int:
    return max(1, min(MAX_REVIEW_SHUFFLE_WINDOW, value))


def bump_review_shuffle_window(current: int, delta: int) -> int:
    return clamp_review_shuffle_window(current + delta)


def review_shuffle_window_from_preset_button(button_id: str) -> int | None:
    if not button_id.startswith(_SHUFFLE_WINDOW_PRESET_PREFIX):
        return None
    raw = button_id.removeprefix(_SHUFFLE_WINDOW_PRESET_PREFIX)
    if not raw.isdigit():
        return None
    return clamp_review_shuffle_window(int(raw))


def validate_settings_form(
    *,
    api_token: str,
    require_api_token: bool,
    lesson_batch_size: int,
    review_shuffle_window: int,
    db_path_raw: str,
    log_path_raw: str,
    crash_log_path_raw: str,
) -> ValidationState:
    errors: dict[str, str] = {}
    warnings: dict[str, str] = {}

    if require_api_token and not api_token.strip():
        errors["api_token"] = "API token is required for setup."

    if lesson_batch_size < 1 or lesson_batch_size > 100:
        errors["lesson_batch_size"] = "Lesson count must be between 1 and 100."
    if review_shuffle_window < 1 or review_shuffle_window > MAX_REVIEW_SHUFFLE_WINDOW:
        errors["review_shuffle_window"] = (
            f"Review shuffle window must be between 1 and {MAX_REVIEW_SHUFFLE_WINDOW}."
        )

    _validate_path_field("db_path", "Database", db_path_raw, errors=errors, warnings=warnings)
    _validate_path_field("log_path", "Log", log_path_raw, errors=errors, warnings=warnings)
    _validate_path_field(
        "crash_log_path",
        "Crash log",
        crash_log_path_raw,
        errors=errors,
        warnings=warnings,
    )

    return ValidationState(errors=errors, warnings=warnings)


def _validate_path_field(
    field: str,
    label: str,
    raw: str,
    *,
    errors: dict[str, str],
    warnings: dict[str, str],
) -> None:
    cleaned = raw.strip()
    if not cleaned:
        errors[field] = f"{label} path is required."
        return

    expanded = Path(cleaned).expanduser()
    if not expanded.is_absolute():
        warnings[field] = f"{label} path is relative and uses the current working directory."
        return
    if not expanded.parent.exists():
        warnings[field] = f"{label} parent directory will be created when saving."


@dataclass(slots=True)
class SettingsExit:
    saved: bool
    settings: Settings | None = None


class SettingsApp(App[SettingsExit]):
    CSS = """
    Screen {
        align: center middle;
        background: $background;
    }
    #chrome {
        width: 94%;
        max-width: 136;
        height: 96%;
        border: heavy $primary;
        background: #060906;
        padding: 1 2;
    }
    #header {
        text-style: bold;
        color: $primary;
    }
    #config {
        color: #CADCCB;
    }
    #summary {
        margin: 0 0 1 0;
        color: #DCEFE0;
    }
    #summary.success {
        color: $success;
    }
    #summary.warning {
        color: $warning;
    }
    #summary.error {
        color: $error;
    }
    #summary.info {
        color: $primary;
    }
    #form {
        height: 1fr;
        overflow: auto auto;
        padding-right: 1;
    }
    .section {
        border: heavy $secondary;
        min-height: 5;
        height: auto !important;
        padding: 1 1;
        margin: 0 0 1 0;
        background: #111611;
    }
    .label {
        color: $primary;
        margin: 0 0 1 0;
        text-style: bold;
    }
    .hint {
        color: #D2E7D5;
        margin: 0 0 1 0;
    }
    .field-msg {
        margin: 0 0 1 0;
        color: #B7C9B9;
    }
    .field-msg.info {
        color: #9FC8A4;
    }
    .field-msg.warning {
        color: $warning;
    }
    .field-msg.error {
        color: $error;
    }
    RadioSet {
        margin: 0 0 1 0;
    }
    Input {
        margin: 0 0 1 0;
        background: #050705;
        color: $foreground;
        border: tall $accent;
    }
    #lesson_row {
        height: auto;
        align: left middle;
        margin: 0 0 1 0;
    }
    #lesson_row Button {
        width: 8;
    }
    #lesson_value {
        width: 8;
        border: tall $accent;
        content-align: center middle;
        margin: 0 1;
        background: #040604;
        color: $foreground;
    }
    #lesson_presets {
        height: auto;
        margin: 0 0 1 0;
    }
    #lesson_presets Button {
        width: 8;
        margin-right: 1;
    }
    #lesson_presets Button:last-child {
        margin-right: 0;
    }
    #shuffle_window_row {
        height: auto;
        align: left middle;
        margin: 0 0 1 0;
    }
    #shuffle_window_row Button {
        width: 8;
    }
    #shuffle_window_value {
        width: 8;
        border: tall $accent;
        content-align: center middle;
        margin: 0 1;
        background: #040604;
        color: $foreground;
    }
    #shuffle_window_presets {
        height: auto;
        margin: 0 0 1 0;
    }
    #shuffle_window_presets Button {
        width: 8;
        margin-right: 1;
    }
    #shuffle_window_presets Button:last-child {
        margin-right: 0;
    }
    #actions {
        height: auto;
        margin: 0 0 1 0;
    }
    #actions Button {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    #actions Button:last-child {
        margin-right: 0;
    }
    #feedback_row {
        height: auto;
        margin: 0 0 1 0;
    }
    #feedback_note {
        width: 1fr;
        margin-right: 1;
        min-height: 3;
    }
    #feedback_btn {
        width: 22;
        min-height: 3;
    }
    #exit_confirm {
        height: auto;
        border: heavy $warning;
        background: #221D10;
        padding: 0 1;
        margin: 0 0 1 0;
    }
    #exit_text {
        width: 1fr;
        color: #F3E2A7;
        content-align: left middle;
    }
    #exit_confirm Button {
        margin-left: 1;
        min-height: 3;
    }
    #status {
        height: 2;
        color: #DCEFE0;
        background: #0D120D;
        border: tall $accent;
        padding: 0 1;
    }
    #status.success {
        color: $success;
    }
    #status.warning {
        color: $warning;
    }
    #status.error {
        color: $error;
    }
    #status.info {
        color: $primary;
    }
    """

    BINDINGS = [
        Binding("ctrl+s", "save", "Save"),
        Binding("ctrl+f", "focus_feedback", "Feedback"),
        Binding("ctrl+d", "discard", "Discard"),
        Binding("escape", "request_exit", "Back"),
        Binding("ctrl+q", "request_exit", "Back"),
        Binding("ctrl+c", "request_exit", "Back"),
    ]

    def __init__(
        self,
        initial_settings: Settings,
        *,
        mode_label: str,
        require_api_token: bool,
        on_feedback: FeedbackCallback | None = None,
    ) -> None:
        super().__init__()
        self._initial_settings = initial_settings
        self._mode_label = mode_label
        self._require_api_token = require_api_token
        self._on_feedback = on_feedback
        self._dirty = False
        self._lesson_batch_size = initial_settings.lesson_batch_size
        self._review_shuffle_window = initial_settings.review_shuffle_window
        self._initial_snapshot = self._snapshot_from_settings(initial_settings)
        self._validation = validate_settings_form(
            api_token=initial_settings.api_token,
            require_api_token=self._require_api_token,
            lesson_batch_size=initial_settings.lesson_batch_size,
            review_shuffle_window=initial_settings.review_shuffle_window,
            db_path_raw=str(initial_settings.db_path),
            log_path_raw=str(initial_settings.log_path),
            crash_log_path_raw=str(initial_settings.crash_log_path),
        )
        self._register_themes()
        self.theme = textual_theme_name(initial_settings.theme)

    def compose(self) -> ComposeResult:
        with Vertical(id="chrome"):
            yield Static(
                f"wkler {self._mode_label} | ctrl+s save | ctrl+f feedback | esc back",
                id="header",
            )
            yield Static(f"Config file: {self._initial_settings.config_path}", id="config")
            yield Static("", id="summary", classes="info")

            with VerticalScroll(id="form"):
                with Vertical(classes="section"):
                    yield Static("General", classes="label")
                    yield Static(
                        "WaniKani token is hidden. You can paste with mouse or keyboard.",
                        classes="hint",
                    )
                    yield Input(
                        value=self._initial_settings.api_token,
                        password=True,
                        placeholder="WaniKani personal access token",
                        id="api_token",
                    )
                    yield Static("", id="api_token_msg", classes="field-msg info")

                with Vertical(classes="section"):
                    yield Static("Behavior", classes="label")
                    yield Static("Reading input mode", classes="hint")
                    with RadioSet(id="mode_set"):
                        yield RadioButton(
                            "Always convert romaji to hiragana",
                            id="mode_always",
                            value=self._initial_settings.reading_input_mode == "always",
                        )
                        yield RadioButton(
                            "Auto-detect conversion",
                            id="mode_auto",
                            value=self._initial_settings.reading_input_mode == "auto",
                        )
                    yield Static("Default lesson count (1-100)", classes="hint")
                    with Horizontal(id="lesson_row"):
                        yield Button("-", id="lesson_minus", variant="default")
                        yield Static(str(self._lesson_batch_size), id="lesson_value")
                        yield Button("+", id="lesson_plus", variant="default")
                    with Horizontal(id="lesson_presets"):
                        for preset in LESSON_PRESET_VALUES:
                            yield Button(
                                str(preset),
                                id=f"{_PRESET_PREFIX}{preset}",
                                variant="primary",
                            )
                    yield Static("", id="lesson_batch_msg", classes="field-msg info")
                    yield Static("Review shuffle mode", classes="hint")
                    with RadioSet(id="shuffle_mode_set"):
                        yield RadioButton(
                            "Rolling window (WaniKani-like)",
                            id="shuffle_mode_rolling",
                            value=self._initial_settings.review_shuffle_mode == "rolling",
                        )
                        yield RadioButton(
                            "Full shuffle (all active)",
                            id="shuffle_mode_full",
                            value=self._initial_settings.review_shuffle_mode == "full",
                        )
                        yield RadioButton(
                            "None (API order)",
                            id="shuffle_mode_none",
                            value=self._initial_settings.review_shuffle_mode == "none",
                        )
                    yield Static(
                        f"Rolling window size (1-{MAX_REVIEW_SHUFFLE_WINDOW})",
                        classes="hint",
                    )
                    with Horizontal(id="shuffle_window_row"):
                        yield Button("-", id="shuffle_window_minus", variant="default")
                        yield Static(str(self._review_shuffle_window), id="shuffle_window_value")
                        yield Button("+", id="shuffle_window_plus", variant="default")
                    with Horizontal(id="shuffle_window_presets"):
                        for preset in SHUFFLE_WINDOW_PRESET_VALUES:
                            yield Button(
                                str(preset),
                                id=f"{_SHUFFLE_WINDOW_PRESET_PREFIX}{preset}",
                                variant="primary",
                            )
                    yield Static("", id="review_shuffle_msg", classes="field-msg info")
                    yield Static("Second-chance on wrong answer", classes="hint")
                    with RadioSet(id="second_chance_set"):
                        yield RadioButton(
                            "On — give one retry per question before counting as fail",
                            id="second_chance_on",
                            value=self._initial_settings.review_second_chance,
                        )
                        yield RadioButton(
                            "Off — every wrong answer is sent to the API",
                            id="second_chance_off",
                            value=not self._initial_settings.review_second_chance,
                        )
                    yield Static("Confirm result before advancing", classes="hint")
                    with RadioSet(id="confirm_result_set"):
                        yield RadioButton(
                            "On — press Enter again to confirm correct answers (WaniKani-like)",
                            id="confirm_result_on",
                            value=self._initial_settings.review_confirm_result,
                        )
                        yield RadioButton(
                            "Off — advance immediately on correct",
                            id="confirm_result_off",
                            value=not self._initial_settings.review_confirm_result,
                        )

                with Vertical(classes="section"):
                    yield Static("Appearance", classes="label")
                    yield Static(
                        "Stealth look is default. All themes keep black backgrounds.",
                        classes="hint",
                    )
                    with RadioSet(id="theme_set"):
                        yield RadioButton(
                            "Stealth Default",
                            id="theme_default",
                            value=self._initial_settings.theme == "default",
                        )
                        yield RadioButton(
                            "Retro Green",
                            id="theme_retro",
                            value=self._initial_settings.theme == "retro",
                        )
                        yield RadioButton(
                            "Muted Colorful",
                            id="theme_colorful",
                            value=self._initial_settings.theme == "colorful",
                        )

                with Vertical(classes="section"):
                    yield Static("Storage (Advanced)", classes="label")
                    yield Static("Database path", classes="hint")
                    yield Input(value=str(self._initial_settings.db_path), id="db_path")
                    yield Static("", id="db_path_msg", classes="field-msg info")
                    yield Static("Log path", classes="hint")
                    yield Input(value=str(self._initial_settings.log_path), id="log_path")
                    yield Static("", id="log_path_msg", classes="field-msg info")
                    yield Static("Crash log path", classes="hint")
                    yield Input(
                        value=str(self._initial_settings.crash_log_path),
                        id="crash_log_path",
                    )
                    yield Static("", id="crash_log_path_msg", classes="field-msg info")

                with Vertical(classes="section"):
                    yield Static("Feedback", classes="label")
                    yield Static(
                        "Capture dogfood friction without leaving settings.",
                        classes="hint",
                    )
                    with Horizontal(id="feedback_row"):
                        yield Input(
                            value="",
                            placeholder="Feedback note",
                            id="feedback_note",
                        )
                        yield Button("Send Feedback", id="feedback_btn", variant="primary")

            with Horizontal(id="actions"):
                yield Button("Save", id="save_btn", variant="success")
                yield Button("Back", id="back_btn", variant="default")
                yield Button("Discard + Exit", id="discard_btn", variant="warning")

            with Horizontal(id="exit_confirm"):
                yield Static("Unsaved changes. Save, discard, or cancel.", id="exit_text")
                yield Button("Save + Exit", id="confirm_save_btn", variant="success")
                yield Button("Discard", id="confirm_discard_btn", variant="warning")
                yield Button("Cancel", id="confirm_cancel_btn", variant="default")

            yield Static("", id="status", classes="info")

    def on_mount(self) -> None:
        self._set_exit_confirm(visible=False)
        self._sync_lesson_widget()
        self._sync_review_shuffle_window_widget()
        self._refresh_form_state()
        self.query_one("#api_token", Input).focus()
        self._set_status(
            "Mouse and keyboard both work. Edit values, then Save.",
            level="info",
        )

    def action_save(self) -> None:
        built = self._build_settings()
        if built is None:
            return
        self.exit(SettingsExit(saved=True, settings=built))

    def action_focus_feedback(self) -> None:
        self.query_one("#feedback_note", Input).focus()
        self._set_status("Feedback mode: type note and press Enter.", level="info")

    def action_discard(self) -> None:
        self.exit(SettingsExit(saved=False, settings=None))

    def action_request_exit(self) -> None:
        if not self._dirty:
            self.exit(SettingsExit(saved=False, settings=None))
            return
        self._set_exit_confirm(visible=True)
        self.query_one("#confirm_save_btn", Button).focus()
        self._set_status(
            "Unsaved changes. Choose Save, Discard, or Cancel.",
            level="warning",
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        if button_id == "save_btn":
            self.action_save()
            return
        if button_id == "discard_btn":
            self.action_discard()
            return
        if button_id == "back_btn":
            self.action_request_exit()
            return
        if button_id == "confirm_save_btn":
            self.action_save()
            return
        if button_id == "confirm_discard_btn":
            self.exit(SettingsExit(saved=False, settings=None))
            return
        if button_id == "confirm_cancel_btn":
            self._set_exit_confirm(visible=False)
            self.query_one("#back_btn", Button).focus()
            self._set_status("Exit cancelled.", level="info")
            return
        if button_id == "feedback_btn":
            note = self.query_one("#feedback_note", Input).value
            self._submit_feedback(note)
            self.query_one("#feedback_note", Input).value = ""
            return
        if button_id == "lesson_minus":
            self._set_lesson_batch_size(self._lesson_batch_size - 1)
            return
        if button_id == "lesson_plus":
            self._set_lesson_batch_size(self._lesson_batch_size + 1)
            return
        if button_id == "shuffle_window_minus":
            self._set_review_shuffle_window(self._review_shuffle_window - 1)
            return
        if button_id == "shuffle_window_plus":
            self._set_review_shuffle_window(self._review_shuffle_window + 1)
            return
        if button_id is not None:
            preset = lesson_batch_from_preset_button(button_id)
            if preset is not None:
                self._set_lesson_batch_size(preset)
                return
            shuffle_preset = review_shuffle_window_from_preset_button(button_id)
            if shuffle_preset is not None:
                self._set_review_shuffle_window(shuffle_preset)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "feedback_note":
            self._submit_feedback(event.value)
            event.input.value = ""
            return
        self.focus_next()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "feedback_note":
            return
        self._refresh_form_state()

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id == "theme_set":
            theme_name = self._selected_theme_name()
            self.theme = textual_theme_name(theme_name)
            self._set_status(f"Theme preview: {theme_name}", level="info")
        elif event.radio_set.id == "shuffle_mode_set":
            shuffle_mode = self._selected_shuffle_mode()
            self._set_status(f"Review shuffle mode: {shuffle_mode}", level="info")
        elif event.radio_set.id == "second_chance_set":
            label = "on" if self._selected_second_chance() else "off"
            self._set_status(f"Second-chance: {label}", level="info")
        elif event.radio_set.id == "confirm_result_set":
            label = "on" if self._selected_confirm_result() else "off"
            self._set_status(f"Confirm result: {label}", level="info")
        self._refresh_form_state()

    def _build_settings(self) -> Settings | None:
        validation = self._refresh_form_state()
        if not validation.is_valid():
            self._set_status("Fix highlighted fields before saving.", level="error")
            self._focus_invalid_field(validation)
            return None

        api_token = self.query_one("#api_token", Input).value.strip()

        db_path = self._read_path("db_path")
        log_path = self._read_path("log_path")
        crash_log_path = self._read_path("crash_log_path")
        if not db_path or not log_path or not crash_log_path:
            self._set_status("Path fields must not be empty.", level="error")
            return None

        theme = self._selected_theme_name()
        reading_input_mode = self._selected_reading_mode()
        review_shuffle_mode = self._selected_shuffle_mode()
        settings = Settings(
            api_token=api_token,
            db_path=db_path,
            log_path=log_path,
            crash_log_path=crash_log_path,
            reading_input_mode=reading_input_mode,  # type: ignore[arg-type]
            theme=theme,  # type: ignore[arg-type]
            lesson_batch_size=self._lesson_batch_size,
            config_path=self._initial_settings.config_path,
            review_shuffle_mode=review_shuffle_mode,  # type: ignore[arg-type]
            review_shuffle_window=self._review_shuffle_window,
            review_second_chance=self._selected_second_chance(),
            review_confirm_result=self._selected_confirm_result(),
        )
        return settings

    def _submit_feedback(self, note: str) -> None:
        clean = note.strip()
        if not clean:
            self._set_status("Feedback note is empty.", level="warning")
            return
        if self._on_feedback is None:
            self._set_status("Feedback callback is unavailable.", level="error")
            return
        message = self._on_feedback(clean)
        self._set_status(message, level="success")

    def _read_path(self, field_id: str) -> Path | None:
        raw = self.query_one(f"#{field_id}", Input).value.strip()
        if not raw:
            return None
        return Path(raw).expanduser()

    def _selected_theme_name(self) -> str:
        radio_set = self.query_one("#theme_set", RadioSet)
        pressed = radio_set.pressed_button
        if pressed is None:
            return "default"
        return _THEME_ID_TO_NAME.get(pressed.id or "", "default")

    def _selected_reading_mode(self) -> str:
        radio_set = self.query_one("#mode_set", RadioSet)
        pressed = radio_set.pressed_button
        if pressed is None:
            return "always"
        return _MODE_ID_TO_NAME.get(pressed.id or "", "always")

    def _selected_shuffle_mode(self) -> str:
        radio_set = self.query_one("#shuffle_mode_set", RadioSet)
        pressed = radio_set.pressed_button
        if pressed is None:
            return "rolling"
        return _SHUFFLE_MODE_ID_TO_NAME.get(pressed.id or "", "rolling")

    def _selected_second_chance(self) -> bool:
        radio_set = self.query_one("#second_chance_set", RadioSet)
        pressed = radio_set.pressed_button
        if pressed is None:
            return self._initial_settings.review_second_chance
        return _SECOND_CHANCE_ID_TO_VALUE.get(
            pressed.id or "", self._initial_settings.review_second_chance
        )

    def _selected_confirm_result(self) -> bool:
        radio_set = self.query_one("#confirm_result_set", RadioSet)
        pressed = radio_set.pressed_button
        if pressed is None:
            return self._initial_settings.review_confirm_result
        return _CONFIRM_RESULT_ID_TO_VALUE.get(
            pressed.id or "", self._initial_settings.review_confirm_result
        )

    def _refresh_form_state(self) -> ValidationState:
        self._set_exit_confirm(visible=False)
        self._refresh_dirty_state()
        self._validation = validate_settings_form(
            api_token=self.query_one("#api_token", Input).value.strip(),
            require_api_token=self._require_api_token,
            lesson_batch_size=self._lesson_batch_size,
            review_shuffle_window=self._review_shuffle_window,
            db_path_raw=self.query_one("#db_path", Input).value,
            log_path_raw=self.query_one("#log_path", Input).value,
            crash_log_path_raw=self.query_one("#crash_log_path", Input).value,
        )
        self._render_field_messages(self._validation)
        self._render_summary(self._validation)
        return self._validation

    def _refresh_dirty_state(self) -> None:
        self._dirty = self._current_snapshot() != self._initial_snapshot

    def _current_snapshot(
        self,
    ) -> tuple[str, str, str, int, str, int, bool, bool, str, str, str]:
        return (
            self.query_one("#api_token", Input).value.strip(),
            self._selected_theme_name(),
            self._selected_reading_mode(),
            self._lesson_batch_size,
            self._selected_shuffle_mode(),
            self._review_shuffle_window,
            self._selected_second_chance(),
            self._selected_confirm_result(),
            self.query_one("#db_path", Input).value.strip(),
            self.query_one("#log_path", Input).value.strip(),
            self.query_one("#crash_log_path", Input).value.strip(),
        )

    def _snapshot_from_settings(
        self, settings: Settings
    ) -> tuple[str, str, str, int, str, int, bool, bool, str, str, str]:
        return (
            settings.api_token,
            settings.theme,
            settings.reading_input_mode,
            settings.lesson_batch_size,
            settings.review_shuffle_mode,
            settings.review_shuffle_window,
            settings.review_second_chance,
            settings.review_confirm_result,
            str(settings.db_path),
            str(settings.log_path),
            str(settings.crash_log_path),
        )

    def _set_lesson_batch_size(self, value: int) -> None:
        self._lesson_batch_size = clamp_lesson_batch_size(value)
        self._sync_lesson_widget()
        self._refresh_form_state()
        self._set_status(
            f"Default lesson count: {self._lesson_batch_size}",
            level="info",
        )

    def _sync_lesson_widget(self) -> None:
        self.query_one("#lesson_value", Static).update(str(self._lesson_batch_size))

    def _set_review_shuffle_window(self, value: int) -> None:
        self._review_shuffle_window = clamp_review_shuffle_window(value)
        self._sync_review_shuffle_window_widget()
        self._refresh_form_state()
        self._set_status(
            f"Review shuffle window: {self._review_shuffle_window}",
            level="info",
        )

    def _sync_review_shuffle_window_widget(self) -> None:
        self.query_one("#shuffle_window_value", Static).update(
            str(self._review_shuffle_window)
        )

    def _render_summary(self, validation: ValidationState) -> None:
        summary = self.query_one("#summary", Static)
        dirty_label = "Unsaved changes" if self._dirty else "Saved"
        if validation.is_valid():
            validation_label = "Ready to save"
            level: FieldLevel = "info" if self._dirty else "success"
        else:
            validation_label = f"{len(validation.errors)} field error(s)"
            level = "error"
        summary.update(
            f"{self._mode_label.upper()} | {dirty_label} | {validation_label} | "
            f"lesson {self._lesson_batch_size} | "
            f"shuffle {self._selected_shuffle_mode()}/{self._review_shuffle_window}"
        )
        summary.set_classes(level)

    def _render_field_messages(self, validation: ValidationState) -> None:
        if self._require_api_token:
            api_default = "Required for setup and API calls."
        else:
            api_default = "Optional here if WKLER_API_TOKEN is set elsewhere."

        self._set_field_message(
            "api_token_msg",
            "api_token",
            validation=validation,
            default=api_default,
        )
        self._set_field_message(
            "lesson_batch_msg",
            "lesson_batch_size",
            validation=validation,
            default="Use buttons/presets. Valid range is 1 to 100.",
        )
        self._set_field_message(
            "review_shuffle_msg",
            "review_shuffle_window",
            validation=validation,
            default=(
                f"Used in rolling mode only. Valid range is 1 to {MAX_REVIEW_SHUFFLE_WINDOW}."
            ),
        )
        self._set_field_message(
            "db_path_msg",
            "db_path",
            validation=validation,
            default="Expanded with ~. Missing parent directories are created.",
        )
        self._set_field_message(
            "log_path_msg",
            "log_path",
            validation=validation,
            default="Expanded with ~. Missing parent directories are created.",
        )
        self._set_field_message(
            "crash_log_path_msg",
            "crash_log_path",
            validation=validation,
            default="Expanded with ~. Missing parent directories are created.",
        )

    def _set_field_message(
        self,
        message_id: str,
        field: str,
        *,
        validation: ValidationState,
        default: str,
    ) -> None:
        message, level = validation.message_for(field, default=default)
        node = self.query_one(f"#{message_id}", Static)
        node.update(message)
        node.set_classes(f"field-msg {level}")

    def _focus_invalid_field(self, validation: ValidationState) -> None:
        field = validation.first_invalid_field()
        if field is None:
            return
        if field == "lesson_batch_size":
            self.query_one("#lesson_minus", Button).focus()
            return
        if field == "review_shuffle_window":
            self.query_one("#shuffle_window_minus", Button).focus()
            return
        self.query_one(f"#{field}", Input).focus()

    def _set_exit_confirm(self, *, visible: bool) -> None:
        node = self.query_one("#exit_confirm", Horizontal)
        node.display = visible

    def _register_themes(self) -> None:
        for theme in THEMES.values():
            self.register_theme(theme)

    def _set_status(self, message: str, *, level: str) -> None:
        status = self.query_one("#status", Static)
        status.update(message)
        status.set_classes(level)
