from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

HomeAction = Literal[
    "reviews",
    "lessons_default",
    "lessons_list",
    "setup",
    "settings",
    "doctor",
    "sync",
    "queue_list",
    "retry",
    "feedback",
]


@dataclass(slots=True)
class HomeSelection:
    action: HomeAction
    feedback_note: str = ""

