from wkler.cli import main

raise SystemExit(main())

