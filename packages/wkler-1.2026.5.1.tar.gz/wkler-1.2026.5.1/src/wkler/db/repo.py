from __future__ import annotations

import datetime as dt
from collections.abc import Iterable
from pathlib import Path

from sqler import F, SQLerDB

from wkler.api.models import AssignmentResource, SubjectResource
from wkler.db.models import AssignmentCache, ReviewLog, SubjectCache, SyncState
from wkler.review.engine import CompletedReview


class WKRepository:
    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = SQLerDB.on_disk(str(self.db_path))
        self._bind_models()

    def get_cached_subjects(self, subject_ids: Iterable[int]) -> dict[int, SubjectResource]:
        cached: dict[int, SubjectResource] = {}
        for subject_id in sorted(set(subject_ids)):
            row = SubjectCache.query().filter(F("subject_id") == subject_id).first()
            if row is None:
                continue
            cached[row.subject_id] = SubjectResource.model_validate(
                {
                    "id": row.subject_id,
                    "object": row.object,
                    "data_updated_at": row.data_updated_at,
                    "data": row.data,
                }
            )
        return cached

    def upsert_subjects(self, subjects: Iterable[SubjectResource]) -> None:
        for subject in subjects:
            row = SubjectCache.query().filter(F("subject_id") == subject.id).first()
            if row is None:
                row = SubjectCache(
                    subject_id=subject.id,
                    object=subject.object,
                    data_updated_at=subject.data_updated_at,
                    data=subject.data.model_dump(mode="python"),
                )
            else:
                row.object = subject.object
                row.data_updated_at = subject.data_updated_at
                row.data = subject.data.model_dump(mode="python")
            row.save()

    def upsert_assignments(self, assignments: Iterable[AssignmentResource]) -> None:
        for assignment in assignments:
            row = AssignmentCache.query().filter(
                F("assignment_id") == assignment.id
            ).first()
            if row is None:
                row = AssignmentCache(
                    assignment_id=assignment.id,
                    subject_id=assignment.data.subject_id,
                    subject_type=assignment.data.subject_type,
                    data_updated_at=assignment.data_updated_at,
                    data=assignment.data.model_dump(mode="python"),
                )
            else:
                row.subject_id = assignment.data.subject_id
                row.subject_type = assignment.data.subject_type
                row.data_updated_at = assignment.data_updated_at
                row.data = assignment.data.model_dump(mode="python")
            row.save()

    def save_sync_state(
        self,
        *,
        last_subjects_updated_after: str | None = None,
        last_assignments_updated_after: str | None = None,
    ) -> None:
        state = SyncState.query().filter(F("singleton") == "default").first()
        if state is None:
            state = SyncState(
                singleton="default",
                last_subjects_updated_after=last_subjects_updated_after,
                last_assignments_updated_after=last_assignments_updated_after,
            )
        else:
            state.last_subjects_updated_after = last_subjects_updated_after
            state.last_assignments_updated_after = last_assignments_updated_after
        state.save()

    def log_review(self, review: CompletedReview) -> None:
        ReviewLog(
            assignment_id=review.assignment_id,
            subject_id=review.subject_id,
            submitted_at=dt.datetime.now(dt.UTC).isoformat().replace("+00:00", "Z"),
            incorrect_meaning_answers=review.incorrect_meaning_answers,
            incorrect_reading_answers=review.incorrect_reading_answers,
            accepted_answers_snapshot={
                "meaning": review.accepted_meaning_answers,
                "reading": review.accepted_reading_answers,
            },
        ).save()

    def _bind_models(self) -> None:
        SubjectCache.set_db(self._db)
        AssignmentCache.set_db(self._db)
        SyncState.set_db(self._db)
        ReviewLog.set_db(self._db)

        SubjectCache.add_index(
            "subject_id",
            unique=True,
            name="uq_subject_cache_subject_id",
        )
        AssignmentCache.add_index(
            "assignment_id",
            unique=True,
            name="uq_assignment_cache_assignment_id",
        )

