from __future__ import annotations

from typing import Any

from sqler import SQLerModel


class SubjectCache(SQLerModel):
    subject_id: int
    object: str
    data_updated_at: str | None = None
    data: dict[str, Any]


class AssignmentCache(SQLerModel):
    assignment_id: int
    subject_id: int
    subject_type: str
    data_updated_at: str | None = None
    data: dict[str, Any]


class SyncState(SQLerModel):
    singleton: str = "default"
    last_subjects_updated_after: str | None = None
    last_assignments_updated_after: str | None = None


class ReviewLog(SQLerModel):
    assignment_id: int
    subject_id: int
    submitted_at: str
    incorrect_meaning_answers: int
    incorrect_reading_answers: int
    accepted_answers_snapshot: dict[str, Any] | None = None

