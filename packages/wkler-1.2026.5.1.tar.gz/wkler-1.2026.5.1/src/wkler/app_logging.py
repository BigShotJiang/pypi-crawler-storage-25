from __future__ import annotations

import json
import traceback
import uuid
from pathlib import Path
from typing import Any

from loguru import logger as loguru_logger

LOGGER_NAME = "wkler"
SERVICE_NAME = "wkler"

LOG_ROTATION = "10 MB"
LOG_RETENTION = "14 days"

loguru_logger.remove()

_main_sink_id: int | None = None
_main_sink_tag: str | None = None
_crash_sinks: set[str] = set()


class AppLogger:
    def __init__(self, sink_tag: str) -> None:
        self._sink_tag = sink_tag

    def info(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._bind(extra).info(message)

    def warning(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._bind(extra).warning(message)

    def error(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._bind(extra).error(message)

    def exception(self, message: str, *, extra: dict[str, Any] | None = None) -> None:
        self._bind(extra).exception(message)

    def log(
        self,
        level: int | str,
        message: str,
        *,
        extra: dict[str, Any] | None = None,
    ) -> None:
        self._bind(extra).log(_normalize_level(level), message)

    def _bind(self, extra: dict[str, Any] | None) -> Any:
        payload = {
            "service_name": SERVICE_NAME,
            "_sink": self._sink_tag,
        }
        if extra:
            payload.update(extra)
        return loguru_logger.bind(**payload)


def setup_logging(log_path: Path, *, command: str) -> tuple[AppLogger, str]:
    """Configure wkler logger to write rotating JSONL events for logler."""
    global _main_sink_id, _main_sink_tag
    correlation_id = f"wkler-{command}-{uuid.uuid4().hex[:12]}"
    log_path = Path(log_path).expanduser()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    sink_tag = f"main:{log_path}"

    if _main_sink_id is not None:
        loguru_logger.remove(_main_sink_id)
    _main_sink_id = loguru_logger.add(
        log_path,
        level="INFO",
        serialize=True,
        rotation=LOG_ROTATION,
        retention=LOG_RETENTION,
        enqueue=False,
        backtrace=False,
        diagnose=False,
        filter=lambda record, expected=sink_tag: record["extra"].get("_sink") == expected,
    )
    _main_sink_tag = sink_tag

    logger = AppLogger(sink_tag)
    logger.info(
        "wkler command started",
        extra={
            "event_type": "command_start",
            "command": command,
            "correlation_id": correlation_id,
        },
    )
    return logger, correlation_id


def write_crash_event(
    crash_log_path: Path,
    *,
    command: str,
    phase: str,
    error: BaseException,
    correlation_id: str | None = None,
) -> None:
    path = Path(crash_log_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    sink_tag = f"crash:{path}"
    if sink_tag not in _crash_sinks:
        loguru_logger.add(
            path,
            level="ERROR",
            serialize=True,
            rotation=LOG_ROTATION,
            retention=LOG_RETENTION,
            enqueue=False,
            backtrace=False,
            diagnose=False,
            filter=lambda record, expected=sink_tag: record["extra"].get("_sink") == expected,
        )
        _crash_sinks.add(sink_tag)

    loguru_logger.bind(
        service_name=SERVICE_NAME,
        _sink=sink_tag,
        event_type="command_crash",
        command=command,
        phase=phase,
        correlation_id=correlation_id,
        error_type=type(error).__name__,
        error_message=str(error),
        traceback="".join(
            traceback.format_exception(type(error), error, error.__traceback__)
        ),
    ).opt(exception=error).error(f"wkler crash during {phase}")


def get_logger() -> AppLogger:
    if _main_sink_tag is None:
        fallback_path = Path("~/.local/state/wkler/wkler.log").expanduser()
        fallback_path.parent.mkdir(parents=True, exist_ok=True)
        setup_logging(fallback_path, command="adhoc")
    return AppLogger(_main_sink_tag or "main:adhoc")


def read_recent_feedback(log_path: Path, *, tail: int) -> list[dict[str, Any]]:
    path = Path(log_path).expanduser()
    if not path.exists():
        return []

    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            normalized = _normalize_log_payload(payload)
            if normalized.get("event_type") == "dogfood_feedback":
                rows.append(normalized)
                continue
            if payload.get("event_type") == "dogfood_feedback":
                rows.append(payload)
    if tail <= 0:
        return rows
    return rows[-tail:]


def _normalize_level(level: int | str) -> str:
    if isinstance(level, str):
        return level.upper()
    if level >= 50:
        return "CRITICAL"
    if level >= 40:
        return "ERROR"
    if level >= 30:
        return "WARNING"
    if level >= 20:
        return "INFO"
    return "DEBUG"


def _normalize_log_payload(payload: dict[str, Any]) -> dict[str, Any]:
    record = payload.get("record")
    if not isinstance(record, dict):
        return payload

    extra = record.get("extra")
    if not isinstance(extra, dict):
        return payload

    out = {key: value for key, value in extra.items() if not key.startswith("_")}
    out.setdefault("message", record.get("message"))
    level = record.get("level")
    if isinstance(level, dict):
        out.setdefault("level", level.get("name"))
    out.setdefault("timestamp", _extract_timestamp(record.get("time")))
    return out


def _extract_timestamp(raw_time: Any) -> str | None:
    if isinstance(raw_time, dict):
        value = raw_time.get("repr") or raw_time.get("iso")
        return str(value) if value is not None else None
    if raw_time is None:
        return None
    return str(raw_time)
