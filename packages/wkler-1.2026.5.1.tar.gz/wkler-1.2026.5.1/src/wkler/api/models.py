from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ResourcePages(BaseModel):
    next_url: str | None = None


class CollectionEnvelope(BaseModel):
    data: list[dict[str, Any]] = Field(default_factory=list)
    pages: ResourcePages = Field(default_factory=ResourcePages)


class AssignmentData(BaseModel):
    subject_id: int
    subject_type: str
    level: int | None = None
    srs_stage: int | None = None
    unlocked_at: str | None = None
    started_at: str | None = None
    available_at: str | None = None


class AssignmentResource(BaseModel):
    id: int
    object: str | None = None
    data_updated_at: str | None = None
    data: AssignmentData


class SubjectMeaning(BaseModel):
    meaning: str
    accepted_answer: bool = False
    primary: bool = False


class AuxiliaryMeaning(BaseModel):
    meaning: str
    type: Literal["whitelist", "blacklist"] | str


class SubjectReading(BaseModel):
    reading: str
    accepted_answer: bool = False
    primary: bool = False
    type: str | None = None


class SubjectData(BaseModel):
    characters: str | None = None
    level: int | None = None
    meanings: list[SubjectMeaning] = Field(default_factory=list)
    auxiliary_meanings: list[AuxiliaryMeaning] = Field(default_factory=list)
    readings: list[SubjectReading] = Field(default_factory=list)


class SubjectResource(BaseModel):
    id: int
    object: str
    data_updated_at: str | None = None
    data: SubjectData
