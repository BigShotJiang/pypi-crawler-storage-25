from __future__ import annotations

import datetime as dt
import random
import time
from collections.abc import Callable, Iterable
from typing import Any
from urllib.parse import urljoin

import httpx

from wkler.api.models import AssignmentResource, CollectionEnvelope, SubjectResource

WANIKANI_REVISION = "20170710"
TRANSIENT_STATUS_CODES = {502, 503}


class WaniKaniClient:
    def __init__(
        self,
        token: str,
        *,
        base_url: str = "https://api.wanikani.com/v2",
        http_client: httpx.Client | None = None,
        max_retries: int = 3,
        sleep_func: Callable[[float], None] = time.sleep,
        time_func: Callable[[], float] = time.time,
        now_func: Callable[[], dt.datetime] | None = None,
        jitter_func: Callable[[], float] | None = None,
    ) -> None:
        self._token = token
        self._base_url = base_url.rstrip("/")
        self._client = http_client or httpx.Client()
        self._max_retries = max_retries
        self._sleep = sleep_func
        self._time = time_func
        self._now = now_func or (lambda: dt.datetime.now(dt.UTC))
        self._jitter = jitter_func or (lambda: random.uniform(0.05, 0.2))

    def list_reviewable_assignments(self) -> list[AssignmentResource]:
        records = self._get_paginated(
            "/assignments",
            params={
                "immediately_available_for_review": "true",
                "hidden": "false",
            },
        )
        return [AssignmentResource.model_validate(record) for record in records]

    def list_available_lesson_assignments(self) -> list[AssignmentResource]:
        records = self._get_paginated(
            "/assignments",
            params={
                "immediately_available_for_lessons": "true",
                "started": "false",
                "hidden": "false",
            },
        )
        return [AssignmentResource.model_validate(record) for record in records]

    def get_subjects(
        self, subject_ids: Iterable[int], *, chunk_size: int = 500
    ) -> dict[int, SubjectResource]:
        unique_ids = sorted(set(subject_ids))
        if not unique_ids:
            return {}

        subjects: dict[int, SubjectResource] = {}
        for chunk in _chunks(unique_ids, chunk_size):
            records = self._get_paginated(
                "/subjects",
                params={"ids": ",".join(str(subject_id) for subject_id in chunk)},
            )
            for record in records:
                subject = SubjectResource.model_validate(record)
                subjects[subject.id] = subject
        return subjects

    def create_review(
        self,
        *,
        assignment_id: int,
        incorrect_meaning_answers: int,
        incorrect_reading_answers: int,
        assignment_available_at: str | None = None,
    ) -> dict[str, Any]:
        now = self._now()
        created_at = _to_api_timestamp(now)

        if assignment_available_at:
            available_at = _parse_wk_timestamp(assignment_available_at)
            if available_at is not None and now <= available_at:
                created_at = None

        review_payload: dict[str, Any] = {
            "assignment_id": assignment_id,
            "incorrect_meaning_answers": incorrect_meaning_answers,
            "incorrect_reading_answers": incorrect_reading_answers,
        }
        if created_at is not None:
            review_payload["created_at"] = created_at

        response = self._request("POST", "/reviews", json={"review": review_payload})
        return response.json()

    def start_assignment(self, assignment_id: int) -> AssignmentResource:
        response = self._request("PUT", f"/assignments/{assignment_id}/start")
        return AssignmentResource.model_validate(response.json())

    def ping(self) -> None:
        self._request("GET", "/summary")

    def close(self) -> None:
        self._client.close()

    def _get_paginated(
        self,
        path: str,
        *,
        params: dict[str, str] | None = None,
    ) -> list[dict[str, Any]]:
        next_url: str | None = path
        next_params = params
        items: list[dict[str, Any]] = []

        while next_url:
            response = self._request("GET", next_url, params=next_params)
            payload = CollectionEnvelope.model_validate(response.json())
            items.extend(payload.data)
            next_url = payload.pages.next_url
            next_params = None
        return items

    def _request(
        self,
        method: str,
        path_or_url: str,
        *,
        params: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        attempts = 0
        url = self._resolve_url(path_or_url)

        while True:
            try:
                response = self._client.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json,
                    headers=self._headers(),
                    timeout=30.0,
                )
            except httpx.TransportError:
                if attempts >= self._max_retries:
                    raise
                self._sleep(_backoff_seconds(attempts))
                attempts += 1
                continue

            if response.status_code == 429:
                self._sleep(_rate_limit_delay(response, self._time, self._jitter))
                attempts += 1
                continue

            if response.status_code in TRANSIENT_STATUS_CODES and attempts < self._max_retries:
                self._sleep(_backoff_seconds(attempts))
                attempts += 1
                continue

            response.raise_for_status()
            return response

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Wanikani-Revision": WANIKANI_REVISION,
            "Content-Type": "application/json; charset=utf-8",
        }

    def _resolve_url(self, path_or_url: str) -> str:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            return path_or_url
        return urljoin(f"{self._base_url}/", path_or_url.lstrip("/"))


def _rate_limit_delay(
    response: httpx.Response,
    time_func: Callable[[], float],
    jitter_func: Callable[[], float],
) -> float:
    reset = response.headers.get("RateLimit-Reset")
    if reset is None:
        return 1.0 + jitter_func()

    try:
        reset_epoch = float(reset)
    except ValueError:
        return 1.0 + jitter_func()

    delay = max(0.0, reset_epoch - time_func())
    return delay + jitter_func()


def _backoff_seconds(attempt: int) -> float:
    return min(8.0, 0.5 * (2**attempt))


def _chunks(values: list[int], size: int) -> list[list[int]]:
    return [values[index : index + size] for index in range(0, len(values), size)]


def _parse_wk_timestamp(value: str) -> dt.datetime | None:
    candidate = value.strip()
    if not candidate:
        return None
    if candidate.endswith("Z"):
        candidate = candidate[:-1] + "+00:00"
    try:
        parsed = dt.datetime.fromisoformat(candidate)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.UTC)
    return parsed.astimezone(dt.UTC)


def _to_api_timestamp(value: dt.datetime) -> str:
    value = value.astimezone(dt.UTC).replace(microsecond=0)
    return value.isoformat().replace("+00:00", "Z")
