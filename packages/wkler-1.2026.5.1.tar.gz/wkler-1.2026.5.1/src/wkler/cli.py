from __future__ import annotations

import argparse
from collections.abc import Sequence
from dataclasses import dataclass
from importlib.metadata import version
from pathlib import Path

import httpx
from qler import JobStatus

from wkler.api.client import WaniKaniClient
from wkler.api.models import AssignmentResource, SubjectResource
from wkler.app_logging import (
    get_logger,
    read_recent_feedback,
    setup_logging,
    write_crash_event,
)
from wkler.config import (
    DEFAULT_CRASH_LOG_PATH,
    MAX_REVIEW_SHUFFLE_WINDOW,
    ConfigError,
    Settings,
    load_settings,
    write_settings_file,
)
from wkler.db.repo import WKRepository
from wkler.queue import QueueJobView, ReviewSubmissionQueue
from wkler.review.engine import CompletedReview, ReviewEngine, build_session_items
from wkler.tui.app import CompletionFeedback, ReviewApp
from wkler.tui.compact import CompactApp
from wkler.tui.home import HomeSelection
from wkler.tui.settings import SettingsApp, SettingsExit
from wkler.tui.unified import UnifiedApp


@dataclass(slots=True)
class SyncSnapshot:
    assignments_count: int
    subjects_count: int
    fetched_subjects_count: int


@dataclass(slots=True)
class SubmissionStats:
    submitted_immediate: int = 0
    queued_for_retry: int = 0
    queue_errors: int = 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        return _run_home_loop(args, parser)
    return _run_selected_command(args, parser)


def _run_home_loop(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    if getattr(args, "compact", False):
        try:
            bootstrap_settings = load_settings(
                config_path=args.config,
                require_api_token=False,
            )
        except ConfigError as exc:
            parser.error(str(exc))
            return 2
        except Exception as exc:
            write_crash_event(
                DEFAULT_CRASH_LOG_PATH,
                command="home_compact",
                phase="bootstrap",
                error=exc,
            )
            raise
        run_home_compact(bootstrap_settings)
        return 0

    while True:
        try:
            bootstrap_settings = load_settings(
                config_path=args.config,
                require_api_token=False,
            )
        except ConfigError as exc:
            parser.error(str(exc))
            return 2
        except Exception as exc:
            write_crash_event(
                DEFAULT_CRASH_LOG_PATH,
                command="home",
                phase="bootstrap",
                error=exc,
            )
            raise

        selection = run_home(bootstrap_settings)
        if selection is None:
            return 0

        selected_args = argparse.Namespace(config=args.config, command=None)
        _apply_home_selection(selected_args, selection)
        _run_selected_command(selected_args, parser, interactive_home=True)


def _run_selected_command(
    args: argparse.Namespace,
    parser: argparse.ArgumentParser,
    *,
    interactive_home: bool = False,
) -> int:
    command = args.command
    if command is None:
        return 0

    require_api_token = command not in {"setup", "settings"}
    try:
        settings = load_settings(
            config_path=args.config,
            require_api_token=require_api_token,
        )
    except ConfigError as exc:
        if interactive_home:
            print(str(exc))
            return 2
        parser.error(str(exc))
        return 2
    except Exception as exc:
        write_crash_event(
            DEFAULT_CRASH_LOG_PATH,
            command=command,
            phase="bootstrap",
            error=exc,
        )
        raise

    logger, correlation_id = setup_logging(settings.log_path, command=command)
    exit_code = 0
    try:
        exit_code = _dispatch_command(command, args, settings, parser)
        return exit_code
    except Exception as exc:
        exit_code = 1
        logger.exception(
            "wkler command failed",
            extra={
                "event_type": "command_exception",
                "command": command,
                "correlation_id": correlation_id,
            },
        )
        write_crash_event(
            settings.crash_log_path,
            command=command,
            phase="runtime",
            error=exc,
            correlation_id=correlation_id,
        )
        print(_render_user_error(command, exc, settings, interactive_home=interactive_home))
        return 1
    finally:
        logger.info(
            "wkler command finished",
            extra={
                "event_type": "command_end",
                "command": command,
                "correlation_id": correlation_id,
                "exit_code": exit_code,
            },
        )


def _render_user_error(
    command: str,
    exc: Exception,
    settings: Settings,
    *,
    interactive_home: bool,
) -> str:
    header = f"Error while running `{command}`."
    detail = _friendly_error_detail(exc)
    if interactive_home:
        return (
            f"{header} {detail}\n"
            "Returning to home."
        )
    return (
        f"{header} {detail}\n"
        f"See logs: {settings.log_path}\n"
        f"Crash log: {settings.crash_log_path}"
    )


def _friendly_error_detail(exc: Exception) -> str:
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        if status == 401:
            return (
                "WaniKani API returned 401 Unauthorized. "
                "Update your API token in Setup/Settings."
            )
        if status == 403:
            return (
                "WaniKani API returned 403 Forbidden. "
                "Confirm token permissions."
            )
        return (
            f"WaniKani API request failed with HTTP {status}."
        )
    if isinstance(exc, httpx.TimeoutException):
        return "Request to WaniKani API timed out. Check network and retry."
    if isinstance(exc, httpx.ConnectError):
        return "Could not connect to WaniKani API. Check network and retry."

    text = str(exc).strip()
    if text:
        return text
    return exc.__class__.__name__


def _dispatch_command(
    command: str,
    args: argparse.Namespace,
    settings: Settings,
    parser: argparse.ArgumentParser,
) -> int:
    if command == "setup":
        return run_setup(settings)
    if command == "settings":
        return run_settings(settings)
    if command == "doctor":
        return run_doctor(settings)
    if command == "sync":
        return run_sync(settings)
    if command == "reviews":
        return run_reviews(
            settings,
            seed=getattr(args, "seed", None),
            no_shuffle=getattr(args, "no_shuffle", False),
            shuffle_mode=getattr(args, "shuffle_mode", None),
            shuffle_window=getattr(args, "shuffle_window", None),
        )
    if command == "lessons":
        return run_lessons(
            settings,
            start_count=getattr(args, "start", 0),
            start_all=getattr(args, "all", False),
            list_limit=getattr(args, "list_limit", 20),
            start_default=getattr(args, "start_default", False),
            yes=getattr(args, "yes", False),
        )
    if command == "retry":
        return run_retry(
            settings,
            limit=getattr(args, "limit", 50),
            all_jobs=getattr(args, "all", False),
            dry_run=getattr(args, "dry_run", False),
            job_ulid=getattr(args, "id", None),
        )
    if command == "queue":
        queue_command = getattr(args, "queue_command", None)
        if queue_command == "list":
            return run_queue_list(
                settings,
                status=getattr(args, "status", "all"),
                limit=getattr(args, "limit", 50),
            )
        if queue_command == "retry":
            return run_retry(
                settings,
                limit=getattr(args, "limit", 50),
                all_jobs=getattr(args, "all", False),
                dry_run=False,
                job_ulid=getattr(args, "id", None),
            )
        parser.error("queue command requires a subcommand")
        return 2
    if command == "feedback":
        return run_feedback(
            settings,
            note=getattr(args, "note", None),
            area=getattr(args, "area", "other"),
            level=getattr(args, "level", "info"),
            blocker=getattr(args, "blocker", False),
            tail=getattr(args, "tail", 0),
        )

    parser.error(f"Unknown command: {command}")
    return 2


def run_home(settings: Settings) -> HomeSelection | None:
    app = UnifiedApp(settings)
    return app.run()


def run_home_compact(settings: Settings) -> None:
    app = CompactApp(settings)
    app.run()


def _apply_home_selection(args: argparse.Namespace, selection: HomeSelection) -> None:
    if selection.action == "reviews":
        args.command = "reviews"
        args.seed = None
        args.no_shuffle = False
        args.shuffle_mode = None
        args.shuffle_window = None
        return
    if selection.action == "lessons_default":
        args.command = "lessons"
        args.start = 0
        args.all = False
        args.list_limit = 20
        args.start_default = True
        args.yes = False
        return
    if selection.action == "lessons_list":
        args.command = "lessons"
        args.start = 0
        args.all = False
        args.list_limit = 20
        args.start_default = False
        args.yes = False
        return
    if selection.action == "setup":
        args.command = "setup"
        return
    if selection.action == "settings":
        args.command = "settings"
        return
    if selection.action == "doctor":
        args.command = "doctor"
        return
    if selection.action == "sync":
        args.command = "sync"
        return
    if selection.action == "queue_list":
        args.command = "queue"
        args.queue_command = "list"
        args.status = "all"
        args.limit = 50
        return
    if selection.action == "retry":
        args.command = "retry"
        args.limit = 50
        args.all = False
        args.dry_run = False
        args.id = None
        return

    args.command = "feedback"
    args.note = selection.feedback_note
    args.area = "other"
    args.level = "info"
    args.blocker = False
    args.tail = 0


def _resolve_review_shuffle_options(
    settings: Settings,
    *,
    no_shuffle: bool,
    shuffle_mode: str | None,
    shuffle_window: int | None,
) -> tuple[str, int]:
    mode = (
        shuffle_mode
        if shuffle_mode is not None
        else ("none" if no_shuffle else settings.review_shuffle_mode)
    )
    window = (
        settings.review_shuffle_window
        if shuffle_window is None
        else shuffle_window
    )
    return mode, window


def _parse_shuffle_window(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("shuffle window must be an integer") from exc
    if parsed < 1 or parsed > MAX_REVIEW_SHUFFLE_WINDOW:
        raise argparse.ArgumentTypeError(
            f"shuffle window must be between 1 and {MAX_REVIEW_SHUFFLE_WINDOW}"
        )
    return parsed


def run_reviews(
    settings: Settings,
    *,
    seed: str | None,
    no_shuffle: bool,
    shuffle_mode: str | None = None,
    shuffle_window: int | None = None,
) -> int:
    logger = get_logger()
    client = WaniKaniClient(settings.api_token)
    repo = WKRepository(settings.db_path)
    queue = ReviewSubmissionQueue(settings.db_path, settings.api_token)
    submission_stats = SubmissionStats()
    try:
        sync_snapshot, assignments, subjects_by_id = _sync_review_data(client, repo)
        if not assignments:
            print("No reviews are due right now.")
            return 0

        session_items = build_session_items(assignments, subjects_by_id)
        if not session_items:
            print("No reviewable session items could be prepared.")
            return 1

        effective_mode, effective_window = _resolve_review_shuffle_options(
            settings,
            no_shuffle=no_shuffle,
            shuffle_mode=shuffle_mode,
            shuffle_window=shuffle_window,
        )
        engine = ReviewEngine(
            session_items,
            reading_input_mode=settings.reading_input_mode,
            shuffle_mode=effective_mode,  # type: ignore[arg-type]
            shuffle_window=effective_window,
            seed=seed,
            second_chance_enabled=settings.review_second_chance,
            confirm_result_enabled=settings.review_confirm_result,
        )

        async def on_review_complete(review: CompletedReview) -> CompletionFeedback:
            return await _submit_or_queue(
                client=client,
                repo=repo,
                queue=queue,
                review=review,
                stats=submission_stats,
            )

        app = ReviewApp(
            engine,
            on_review_complete=on_review_complete,
            theme_name=settings.theme,
        )
        summary = app.run() or engine.stats()

        retry_report = None
        if summary.get("aborted", 0) == 0:
            counts = queue.queue_counts()
            if counts.pending > 0 or counts.failed > 0:
                retry_report = queue.retry(
                    limit=10,
                    all_jobs=False,
                    dry_run=False,
                    retry_failed=True,
                )

        final_counts = queue.queue_counts()
        attempted = summary.get("attempted", 0)
        correct_first_try = summary.get("correct_first_try", 0)
        total_incorrect = summary.get("total_incorrect", 0)
        callback_failures = summary.get("failed_submissions", 0)
        aborted = summary.get("aborted", 0)
        wrap_up_enabled = summary.get("wrap_up_enabled", 0)
        wrap_up_total = summary.get("wrap_up_total", 0)
        wrap_up_remaining = summary.get("wrap_up_remaining", 0)
        deferred_remaining = summary.get("deferred_remaining", 0)
        retried_submitted = retry_report.submitted if retry_report is not None else 0
        print(
            "Session summary: "
            f"attempted={attempted} "
            f"correct_first_try={correct_first_try} "
            f"total_incorrect={total_incorrect} "
            f"wrap_up_enabled={wrap_up_enabled} "
            f"wrap_up_total={wrap_up_total} "
            f"wrap_up_remaining={wrap_up_remaining} "
            f"deferred_remaining={deferred_remaining} "
            f"submitted_immediate={submission_stats.submitted_immediate} "
            f"queued_for_retry={submission_stats.queued_for_retry} "
            f"retry_submitted={retried_submitted} "
            f"queue_pending={final_counts.pending} "
            f"queue_failed={final_counts.failed} "
            f"queue_running={final_counts.running} "
            f"queue_errors={submission_stats.queue_errors} "
            f"callback_failures={callback_failures} "
            f"aborted={aborted} "
            f"synced_assignments={sync_snapshot.assignments_count} "
            f"synced_subjects={sync_snapshot.subjects_count}"
        )
        logger.info(
            "reviews session summary",
            extra={
                "event_type": "reviews_summary",
                "attempted": attempted,
                "correct_first_try": correct_first_try,
                "total_incorrect": total_incorrect,
                "wrap_up_enabled": wrap_up_enabled,
                "wrap_up_total": wrap_up_total,
                "wrap_up_remaining": wrap_up_remaining,
                "deferred_remaining": deferred_remaining,
                "submitted_immediate": submission_stats.submitted_immediate,
                "queued_for_retry": submission_stats.queued_for_retry,
                "retry_submitted": retried_submitted,
                "queue_pending": final_counts.pending,
                "queue_failed": final_counts.failed,
                "aborted": aborted,
            },
        )
        return 0
    finally:
        client.close()


def run_sync(settings: Settings) -> int:
    logger = get_logger()
    client = WaniKaniClient(settings.api_token)
    repo = WKRepository(settings.db_path)
    try:
        snapshot, _, _ = _sync_review_data(client, repo)
    finally:
        client.close()

    print(
        "Sync complete: "
        f"assignments={snapshot.assignments_count} "
        f"subjects={snapshot.subjects_count} "
        f"fetched_subjects={snapshot.fetched_subjects_count}"
    )
    logger.info(
        "sync complete",
        extra={
            "event_type": "sync_complete",
            "assignments": snapshot.assignments_count,
            "subjects": snapshot.subjects_count,
            "fetched_subjects": snapshot.fetched_subjects_count,
        },
    )
    return 0


def run_setup(settings: Settings) -> int:
    return _run_settings_editor(
        settings,
        mode_label="setup",
        require_api_token=True,
    )


def run_settings(settings: Settings) -> int:
    return _run_settings_editor(
        settings,
        mode_label="settings",
        require_api_token=False,
    )


def _run_settings_editor(
    settings: Settings,
    *,
    mode_label: str,
    require_api_token: bool,
) -> int:
    logger = get_logger()

    def on_feedback(note: str) -> str:
        logger.info(
            "dogfood feedback",
            extra={
                "event_type": "dogfood_feedback",
                "feedback_note": note,
                "feedback_area": "config",
                "feedback_level": "info",
                "feedback_blocker": False,
                "feedback_source": "settings_hotkey",
            },
        )
        return "Feedback logged."

    result = SettingsApp(
        settings,
        mode_label=mode_label,
        require_api_token=require_api_token,
        on_feedback=on_feedback,
    ).run()
    if not isinstance(result, SettingsExit) or not result.saved or result.settings is None:
        return 0

    saved_path = write_settings_file(result.settings)
    _ensure_runtime_paths(result.settings)
    print(f"Settings saved: {saved_path}")
    if mode_label == "setup":
        print("Setup complete. Run `wkler doctor` then `wkler reviews`.")
    return 0


def run_lessons(
    settings: Settings,
    *,
    start_count: int,
    start_all: bool,
    list_limit: int,
    start_default: bool,
    yes: bool = False,
) -> int:
    logger = get_logger()
    client = WaniKaniClient(settings.api_token)
    repo = WKRepository(settings.db_path)
    try:
        assignments = client.list_available_lesson_assignments()
        snapshot, _, subjects_by_id = _hydrate_assignments(client, repo, assignments)

        if not assignments:
            print("No lessons are available right now.")
            return 0

        rows = []
        for assignment in assignments:
            subject = subjects_by_id.get(assignment.data.subject_id)
            if subject is None:
                continue
            rows.append((assignment, subject))

        if not rows:
            print("No lesson subjects could be prepared.")
            return 1

        print(
            "Lessons available: "
            f"assignments={snapshot.assignments_count} subjects={snapshot.subjects_count}"
        )
        for assignment, subject in rows[: max(1, list_limit)]:
            prompt = _primary_prompt(subject)
            level = assignment.data.level or subject.data.level or 0
            meanings = ", ".join(
                m.meaning for m in subject.data.meanings if m.primary
            ) or ", ".join(
                m.meaning for m in subject.data.meanings[:3]
            )
            print(
                f"id={assignment.id} level={level} "
                f"type={assignment.data.subject_type} "
                f"prompt={prompt} meanings=[{meanings}]"
            )

        if start_all:
            to_start = len(rows)
        elif start_default:
            to_start = settings.lesson_batch_size
        else:
            to_start = max(0, start_count)
        if to_start == 0:
            print(
                "Use `wkler lessons --start N`, `wkler lessons --start-default`, "
                "or `wkler lessons --all` to start lessons."
            )
            return 0

        actual = min(to_start, len(rows))
        if not yes:
            print(f"\nAbout to start {actual} lesson(s):")
            for assignment, subject in rows[:actual]:
                prompt = _primary_prompt(subject)
                level = assignment.data.level or subject.data.level or 0
                meanings = ", ".join(
                    m.meaning for m in subject.data.meanings if m.primary
                ) or ", ".join(
                    m.meaning for m in subject.data.meanings[:3]
                )
                print(
                    f"  {prompt} (level {level}, "
                    f"{assignment.data.subject_type}) — {meanings}"
                )
            try:
                answer = input(f"\nStart {actual} lessons? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                return 0
            if answer not in ("y", "yes"):
                print("Aborted.")
                return 0

        started = 0
        failed = 0
        for assignment, _ in rows[:to_start]:
            try:
                updated = client.start_assignment(assignment.id)
            except Exception as exc:
                failed += 1
                print(f"start_failed id={assignment.id} error={exc}")
                continue
            started += 1
            repo.upsert_assignments([updated])

        print(
            "Lessons start summary: "
            f"requested={min(to_start, len(rows))} started={started} failed={failed}"
        )
        logger.info(
            "lessons start summary",
            extra={
                "event_type": "lessons_start_summary",
                "available": len(rows),
                "requested": min(to_start, len(rows)),
                "started": started,
                "failed": failed,
            },
        )
        return 0
    finally:
        client.close()


def _ensure_runtime_paths(settings: Settings) -> None:
    settings.db_path.parent.mkdir(parents=True, exist_ok=True)
    settings.log_path.parent.mkdir(parents=True, exist_ok=True)
    settings.crash_log_path.parent.mkdir(parents=True, exist_ok=True)


def run_doctor(settings: Settings) -> int:
    logger = get_logger()
    print(f"wkler version: {version('wkler')}")
    print(f"config path: {settings.config_path}")
    print(f"db path: {settings.db_path}")
    print(f"log path: {settings.log_path}")
    print(f"crash log path: {settings.crash_log_path}")
    print(f"reading input mode: {settings.reading_input_mode}")
    print(f"theme: {settings.theme}")
    print(f"default lesson count: {settings.lesson_batch_size}")
    print(f"review shuffle mode: {settings.review_shuffle_mode}")
    print(f"review shuffle window: {settings.review_shuffle_window}")

    queue = ReviewSubmissionQueue(settings.db_path, settings.api_token)
    try:
        counts = queue.queue_counts()
    except Exception as exc:
        print(f"queue connectivity: failed ({exc})")
        return 1
    print(
        "queue connectivity: ok "
        f"(pending={counts.pending} failed={counts.failed} running={counts.running})"
    )

    client = WaniKaniClient(settings.api_token)
    try:
        client.ping()
    except Exception as exc:  # pragma: no cover - network-bound path
        print(f"api connectivity: failed ({exc})")
        return 1
    finally:
        client.close()

    print("api connectivity: ok")
    logger.info(
        "doctor ok",
        extra={
            "event_type": "doctor_ok",
            "queue_pending": counts.pending,
            "queue_failed": counts.failed,
            "queue_running": counts.running,
        },
    )
    return 0


def run_retry(
    settings: Settings,
    *,
    limit: int,
    all_jobs: bool,
    dry_run: bool,
    job_ulid: str | None = None,
) -> int:
    logger = get_logger()
    limit = max(1, limit)
    queue = ReviewSubmissionQueue(settings.db_path, settings.api_token)
    report = queue.retry(
        limit=limit,
        all_jobs=all_jobs,
        dry_run=dry_run,
        retry_failed=True,
        job_ulid=job_ulid,
    )
    print(
        "Retry report: "
        f"retried_from_failed={report.retried_from_failed} "
        f"claimed={report.claimed} "
        f"submitted={report.submitted} "
        f"failed={report.failed} "
        f"remaining_pending={report.remaining_pending} "
        f"remaining_failed={report.remaining_failed}"
    )
    logger.info(
        "retry report",
        extra={
            "event_type": "retry_report",
            "retried_from_failed": report.retried_from_failed,
            "claimed": report.claimed,
            "submitted": report.submitted,
            "failed": report.failed,
            "remaining_pending": report.remaining_pending,
            "remaining_failed": report.remaining_failed,
        },
    )
    return 0


def run_queue_list(settings: Settings, *, status: str, limit: int) -> int:
    logger = get_logger()
    limit = max(1, limit)
    queue = ReviewSubmissionQueue(settings.db_path, settings.api_token)
    jobs = queue.list_jobs(status=status, limit=limit)
    if not jobs:
        print("Queue is empty for selected filter.")
        return 0

    print("ulid status assignment subject retry eta updated error")
    for job in jobs:
        print(_format_queue_row(job))
    logger.info(
        "queue list",
        extra={
            "event_type": "queue_list",
            "status": status,
            "limit": limit,
            "rows": len(jobs),
        },
    )
    return 0


def run_feedback(
    settings: Settings,
    *,
    note: str | None,
    area: str,
    level: str,
    blocker: bool,
    tail: int,
) -> int:
    logger = get_logger()
    if tail > 0:
        rows = read_recent_feedback(settings.log_path, tail=tail)
        if not rows:
            print("No feedback entries found.")
            return 0
        for row in rows:
            print(
                f"{row.get('timestamp')} "
                f"level={row.get('feedback_level')} "
                f"area={row.get('feedback_area')} "
                f"blocker={row.get('feedback_blocker')} "
                f"note={row.get('feedback_note')}"
            )
        return 0

    if not note or not note.strip():
        print("Feedback note is required unless --tail is used.")
        return 2

    logger.log(
        _to_logging_level(level),
        "dogfood feedback",
        extra={
            "event_type": "dogfood_feedback",
            "feedback_note": note.strip(),
            "feedback_area": area,
            "feedback_level": level,
            "feedback_blocker": blocker,
        },
    )
    print("Feedback logged.")
    return 0


def _to_logging_level(value: str) -> int:
    mapping = {
        "info": 20,
        "warning": 30,
        "error": 40,
    }
    return mapping.get(value, 20)


async def _submit_or_queue(
    *,
    client: WaniKaniClient,
    repo: WKRepository,
    queue: ReviewSubmissionQueue,
    review: CompletedReview,
    stats: SubmissionStats,
) -> CompletionFeedback:
    logger = get_logger()
    try:
        client.create_review(
            assignment_id=review.assignment_id,
            incorrect_meaning_answers=review.incorrect_meaning_answers,
            incorrect_reading_answers=review.incorrect_reading_answers,
            assignment_available_at=review.available_at,
        )
        repo.log_review(review)
        stats.submitted_immediate += 1
        logger.info(
            "review submitted",
            extra={
                "event_type": "review_submit_immediate",
                "assignment_id": review.assignment_id,
                "subject_id": review.subject_id,
            },
        )
        return CompletionFeedback(message="Submitted.", level="success")
    except Exception as submit_error:
        try:
            job_ulid = await queue.enqueue_failed_submission_async(
                review,
                error_message=str(submit_error),
            )
        except Exception as queue_error:
            stats.queue_errors += 1
            logger.error(
                "review submit and queue failed",
                extra={
                    "event_type": "review_submit_queue_error",
                    "assignment_id": review.assignment_id,
                    "subject_id": review.subject_id,
                    "error": str(queue_error),
                },
            )
            return CompletionFeedback(
                message=f"Submit failed and queue failed: {queue_error}",
                level="error",
            )

        stats.queued_for_retry += 1
        logger.warning(
            "review queued for retry",
            extra={
                "event_type": "review_submit_queued",
                "assignment_id": review.assignment_id,
                "subject_id": review.subject_id,
                "queue_job_id": job_ulid,
                "error": str(submit_error),
            },
        )
        return CompletionFeedback(
            message="Saved offline — will retry next session.",
            level="warning",
        )


def _sync_review_data(
    client: WaniKaniClient,
    repo: WKRepository,
) -> tuple[SyncSnapshot, list[AssignmentResource], dict[int, SubjectResource]]:
    assignments = client.list_reviewable_assignments()
    return _hydrate_assignments(client, repo, assignments)


def _hydrate_assignments(
    client: WaniKaniClient,
    repo: WKRepository,
    assignments: list[AssignmentResource],
) -> tuple[SyncSnapshot, list[AssignmentResource], dict[int, SubjectResource]]:
    if not assignments:
        return (
            SyncSnapshot(assignments_count=0, subjects_count=0, fetched_subjects_count=0),
            [],
            {},
        )

    repo.upsert_assignments(assignments)

    subject_ids = sorted({assignment.data.subject_id for assignment in assignments})
    cached_subjects = repo.get_cached_subjects(subject_ids)
    missing_ids = [subject_id for subject_id in subject_ids if subject_id not in cached_subjects]

    fetched_subjects_count = 0
    if missing_ids:
        fetched_subjects = client.get_subjects(missing_ids)
        repo.upsert_subjects(fetched_subjects.values())
        fetched_subjects_count = len(fetched_subjects)
        cached_subjects.update(fetched_subjects)

    return (
        SyncSnapshot(
            assignments_count=len(assignments),
            subjects_count=len(cached_subjects),
            fetched_subjects_count=fetched_subjects_count,
        ),
        assignments,
        cached_subjects,
    )


def _primary_prompt(subject: SubjectResource) -> str:
    if subject.data.characters:
        return subject.data.characters
    for meaning in subject.data.meanings:
        if meaning.primary:
            return meaning.meaning
    if subject.data.meanings:
        return subject.data.meanings[0].meaning
    return "(no prompt)"


def _format_queue_row(job: QueueJobView) -> str:
    error = (job.last_error or "-").replace("\n", " ")
    short_error = error[:40]
    assignment = str(job.assignment_id) if job.assignment_id is not None else "-"
    subject = str(job.subject_id) if job.subject_id is not None else "-"
    return (
        f"{job.ulid} {job.status} {assignment} {subject} "
        f"{job.retry_count}/{job.max_retries} {job.eta} {job.updated_at} {short_error}"
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wkler",
        description="Terminal-first WaniKani client (no subcommand opens home launcher).",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Optional path to config file (TOML).",
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Launch compact mode (minimal Reviews/Lessons home).",
    )

    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("setup", help="Run first-time interactive setup.")
    subparsers.add_parser("settings", help="Open interactive settings page.")

    reviews = subparsers.add_parser("reviews", help="Run review session.")
    reviews.add_argument(
        "--seed",
        default=None,
        help="Optional stable shuffle seed.",
    )
    reviews.add_argument(
        "--no-shuffle",
        action="store_true",
        help="Run reviews in API order.",
    )
    reviews.add_argument(
        "--shuffle-mode",
        choices=["rolling", "full", "none"],
        default=None,
        help=(
            "Question ordering mode. "
            "`rolling` keeps a rolling item window, `full` shuffles the full queue, "
            "`none` keeps API order."
        ),
    )
    reviews.add_argument(
        "--shuffle-window",
        type=_parse_shuffle_window,
        default=None,
        help="Rolling window size (used when shuffle mode is `rolling`).",
    )

    lessons = subparsers.add_parser("lessons", help="List and start available lessons.")
    lessons.add_argument(
        "--start",
        type=int,
        default=0,
        help="Start the first N available lessons.",
    )
    lessons.add_argument(
        "--all",
        action="store_true",
        help="Start all available lessons.",
    )
    lessons.add_argument(
        "--list-limit",
        type=int,
        default=20,
        help="Max lesson rows to print.",
    )
    lessons.add_argument(
        "--start-default",
        action="store_true",
        help="Start the default lesson count from settings.",
    )
    lessons.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompt (for scripted use).",
    )

    subparsers.add_parser("sync", help="Prefetch due assignments and missing subjects into cache.")
    subparsers.add_parser("doctor", help="Print config and API/queue diagnostics.")

    feedback = subparsers.add_parser("feedback", help="Log or view dogfood feedback entries.")
    feedback.add_argument(
        "--note",
        default=None,
        help="Feedback note text. Required unless using --tail.",
    )
    feedback.add_argument(
        "--area",
        choices=["reviews", "lessons", "queue", "ux", "config", "other"],
        default="other",
        help="Feedback area classification.",
    )
    feedback.add_argument(
        "--level",
        choices=["info", "warning", "error"],
        default="info",
        help="Feedback severity.",
    )
    feedback.add_argument(
        "--blocker",
        action="store_true",
        help="Mark this feedback note as a blocker.",
    )
    feedback.add_argument(
        "--tail",
        type=int,
        default=0,
        help="Show last N feedback entries from logs instead of adding a new note.",
    )

    retry = subparsers.add_parser("retry", help="Retry queued failed review submissions.")
    retry.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max jobs to retry when --all is not set.",
    )
    retry.add_argument(
        "--all",
        action="store_true",
        help="Retry all available queue jobs.",
    )
    retry.add_argument(
        "--dry-run",
        action="store_true",
        help="Show retry counts without submitting.",
    )
    retry.add_argument(
        "--id",
        default=None,
        help="Retry a specific job ULID (failed jobs are requeued first).",
    )

    queue_parser = subparsers.add_parser("queue", help="Inspect or retry the submission queue.")
    queue_subparsers = queue_parser.add_subparsers(dest="queue_command")

    queue_list = queue_subparsers.add_parser("list", help="List queued submission jobs.")
    queue_list.add_argument(
        "--status",
        choices=[
            "all",
            "done",
            JobStatus.PENDING.value,
            JobStatus.RUNNING.value,
            JobStatus.FAILED.value,
            JobStatus.COMPLETED.value,
            JobStatus.CANCELLED.value,
        ],
        default="all",
        help="Filter jobs by status.",
    )
    queue_list.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max rows to print.",
    )

    queue_retry = queue_subparsers.add_parser("retry", help="Retry jobs from queue view.")
    queue_retry.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max jobs to retry when --all is not set.",
    )
    queue_retry.add_argument(
        "--all",
        action="store_true",
        help="Retry all queued jobs.",
    )
    queue_retry.add_argument(
        "--id",
        default=None,
        help="Retry a specific job ULID.",
    )

    return parser
