from __future__ import annotations

import json
import os
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from wkler.tui.theme import ThemeName, resolve_theme_name

ReadingInputMode = Literal["always", "auto"]
ReviewShuffleMode = Literal["rolling", "full", "none"]

DEFAULT_CONFIG_PATH = Path("~/.config/wkler/config.toml").expanduser()
DEFAULT_DB_PATH = Path("~/.local/share/wkler/wkler.db").expanduser()
DEFAULT_LOG_PATH = Path("~/.local/state/wkler/wkler.log").expanduser()
DEFAULT_CRASH_LOG_PATH = Path("~/.local/state/wkler/wkler-crash.log").expanduser()
DEFAULT_LESSON_BATCH_SIZE = 5
DEFAULT_REVIEW_SHUFFLE_MODE: ReviewShuffleMode = "rolling"
DEFAULT_REVIEW_SHUFFLE_WINDOW = 20
MAX_REVIEW_SHUFFLE_WINDOW = 500
DEFAULT_REVIEW_SECOND_CHANCE = True
DEFAULT_REVIEW_CONFIRM_RESULT = True


class ConfigError(ValueError):
    """Raised when configuration is invalid or incomplete."""


@dataclass(frozen=True, slots=True)
class Settings:
    api_token: str
    db_path: Path
    log_path: Path
    crash_log_path: Path
    reading_input_mode: ReadingInputMode
    theme: ThemeName
    lesson_batch_size: int
    config_path: Path
    review_shuffle_mode: ReviewShuffleMode = DEFAULT_REVIEW_SHUFFLE_MODE
    review_shuffle_window: int = DEFAULT_REVIEW_SHUFFLE_WINDOW
    review_second_chance: bool = DEFAULT_REVIEW_SECOND_CHANCE
    review_confirm_result: bool = DEFAULT_REVIEW_CONFIRM_RESULT


def resolve_config_path(config_path: Path | None = None) -> Path:
    return Path(
        os.getenv("WKLER_CONFIG_PATH", str(config_path or DEFAULT_CONFIG_PATH))
    ).expanduser()


def load_settings(
    config_path: Path | None = None,
    *,
    require_api_token: bool = True,
) -> Settings:
    resolved_config_path = resolve_config_path(config_path)
    file_values = _load_config_file(resolved_config_path)

    api_token = _first_non_empty(
        os.getenv("WKLER_API_TOKEN"),
        _lookup_config(file_values, "api_token"),
    )
    if not api_token and require_api_token:
        raise ConfigError(
            "Missing API token. Set WKLER_API_TOKEN or api_token in config file."
        )

    raw_db_path = _first_non_empty(
        os.getenv("WKLER_DB_PATH"),
        _lookup_config(file_values, "db_path"),
        str(DEFAULT_DB_PATH),
    )
    db_path = Path(raw_db_path).expanduser()

    raw_log_path = _first_non_empty(
        os.getenv("WKLER_LOG_PATH"),
        _lookup_config(file_values, "log_path"),
        str(DEFAULT_LOG_PATH),
    )
    log_path = Path(raw_log_path).expanduser()

    raw_crash_log_path = _first_non_empty(
        os.getenv("WKLER_CRASH_LOG_PATH"),
        _lookup_config(file_values, "crash_log_path"),
        str(DEFAULT_CRASH_LOG_PATH),
    )
    crash_log_path = Path(raw_crash_log_path).expanduser()

    raw_mode = _first_non_empty(
        os.getenv("WKLER_READING_INPUT_MODE"),
        _lookup_config(file_values, "reading_input_mode"),
        "always",
    ).lower()
    if raw_mode not in {"always", "auto"}:
        raise ConfigError(
            "Invalid reading input mode. Expected one of: always, auto."
        )

    raw_theme = _first_non_empty(
        os.getenv("WKLER_THEME"),
        _lookup_config(file_values, "theme"),
        "default",
    ).lower()
    if raw_theme not in {"default", "retro", "colorful"}:
        raise ConfigError(
            "Invalid theme. Expected one of: default, retro, colorful."
        )

    raw_lesson_batch_size = _first_non_empty(
        os.getenv("WKLER_LESSON_BATCH_SIZE"),
        _lookup_config(file_values, "lesson_batch_size"),
        str(DEFAULT_LESSON_BATCH_SIZE),
    )
    try:
        lesson_batch_size = int(raw_lesson_batch_size)
    except ValueError as exc:
        raise ConfigError(
            "Invalid lesson batch size. Expected an integer between 1 and 100."
        ) from exc
    if lesson_batch_size < 1 or lesson_batch_size > 100:
        raise ConfigError(
            "Invalid lesson batch size. Expected an integer between 1 and 100."
        )

    raw_shuffle_mode = _first_non_empty(
        os.getenv("WKLER_REVIEW_SHUFFLE_MODE"),
        _lookup_config(file_values, "review_shuffle_mode"),
        DEFAULT_REVIEW_SHUFFLE_MODE,
    ).lower()
    if raw_shuffle_mode not in {"rolling", "full", "none"}:
        raise ConfigError(
            "Invalid review shuffle mode. Expected one of: rolling, full, none."
        )

    raw_shuffle_window = _first_non_empty(
        os.getenv("WKLER_REVIEW_SHUFFLE_WINDOW"),
        _lookup_config(file_values, "review_shuffle_window"),
        str(DEFAULT_REVIEW_SHUFFLE_WINDOW),
    )
    try:
        review_shuffle_window = int(raw_shuffle_window)
    except ValueError as exc:
        raise ConfigError(
            f"Invalid review shuffle window. Expected an integer between 1 and "
            f"{MAX_REVIEW_SHUFFLE_WINDOW}."
        ) from exc
    if review_shuffle_window < 1 or review_shuffle_window > MAX_REVIEW_SHUFFLE_WINDOW:
        raise ConfigError(
            f"Invalid review shuffle window. Expected an integer between 1 and "
            f"{MAX_REVIEW_SHUFFLE_WINDOW}."
        )

    review_second_chance = _parse_bool_setting(
        raw=_first_non_empty(
            os.getenv("WKLER_REVIEW_SECOND_CHANCE"),
            _lookup_config(file_values, "review_second_chance"),
            "true" if DEFAULT_REVIEW_SECOND_CHANCE else "false",
        ),
        field_name="review_second_chance",
    )

    review_confirm_result = _parse_bool_setting(
        raw=_first_non_empty(
            os.getenv("WKLER_REVIEW_CONFIRM_RESULT"),
            _lookup_config(file_values, "review_confirm_result"),
            "true" if DEFAULT_REVIEW_CONFIRM_RESULT else "false",
        ),
        field_name="review_confirm_result",
    )

    return Settings(
        api_token=api_token,
        db_path=db_path,
        log_path=log_path,
        crash_log_path=crash_log_path,
        reading_input_mode=raw_mode,  # type: ignore[arg-type]
        theme=resolve_theme_name(raw_theme),
        lesson_batch_size=lesson_batch_size,
        review_shuffle_mode=raw_shuffle_mode,  # type: ignore[arg-type]
        review_shuffle_window=review_shuffle_window,
        review_second_chance=review_second_chance,
        review_confirm_result=review_confirm_result,
        config_path=resolved_config_path,
    )


def write_settings_file(settings: Settings, *, config_path: Path | None = None) -> Path:
    path = resolve_config_path(config_path or settings.config_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = "\n".join(
        [
            "[wkler]",
            f"api_token = {_toml_string(settings.api_token)}",
            f"db_path = {_toml_string(str(settings.db_path))}",
            f"log_path = {_toml_string(str(settings.log_path))}",
            f"crash_log_path = {_toml_string(str(settings.crash_log_path))}",
            f"reading_input_mode = {_toml_string(settings.reading_input_mode)}",
            f"theme = {_toml_string(settings.theme)}",
            f"lesson_batch_size = {settings.lesson_batch_size}",
            f"review_shuffle_mode = {_toml_string(settings.review_shuffle_mode)}",
            f"review_shuffle_window = {settings.review_shuffle_window}",
            f"review_second_chance = {_toml_bool(settings.review_second_chance)}",
            f"review_confirm_result = {_toml_bool(settings.review_confirm_result)}",
            "",
        ]
    )
    path.write_text(serialized, encoding="utf-8")
    return path


def _load_config_file(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    if "wkler" in data and isinstance(data["wkler"], dict):
        return data["wkler"]  # type: ignore[return-value]
    return data  # type: ignore[return-value]


def _lookup_config(data: dict[str, object], key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    return str(value)


def _first_non_empty(*values: str | None) -> str:
    for value in values:
        if value is not None and value.strip():
            return value.strip()
    return ""


def _toml_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _toml_bool(value: bool) -> str:
    return "true" if value else "false"


def _parse_bool_setting(*, raw: str, field_name: str) -> bool:
    normalized = raw.strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    raise ConfigError(
        f"Invalid value for {field_name}. Expected one of: true, false."
    )
