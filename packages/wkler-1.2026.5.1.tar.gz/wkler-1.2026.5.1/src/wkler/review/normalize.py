from __future__ import annotations

import re

import wanakana

from wkler.review.ime import ReadingInputMode, apply_reading_ime

_MEANING_PUNCTUATION_RE = re.compile(r"[^\w\s-]")
_MULTISPACE_RE = re.compile(r"\s+")
_ASCII_TEXT_RE = re.compile(r"^[a-z][a-z\s-]*$")
_NON_ASCII_LETTER_RE = re.compile(r"[^a-z]")


def normalize_meaning(value: str) -> str:
    text = value.strip().casefold()
    text = _MEANING_PUNCTUATION_RE.sub(" ", text)
    return _MULTISPACE_RE.sub(" ", text).strip()


def normalize_reading(value: str, *, mode: ReadingInputMode = "always") -> str:
    text = apply_reading_ime(value, mode=mode)
    text = wanakana.to_hiragana(text.strip())
    return _MULTISPACE_RE.sub("", text)


def is_meaning_typo_match(answer: str, accepted: set[str]) -> bool:
    for candidate in accepted:
        if not _eligible_for_typo_tolerance(answer, candidate):
            continue
        compact_answer = _compact_for_typo_tolerance(answer)
        compact_candidate = _compact_for_typo_tolerance(candidate)
        if not compact_answer or not compact_candidate:
            continue
        max_distance = _max_typo_distance(compact_answer, compact_candidate)
        if _damerau_levenshtein_within(compact_answer, compact_candidate, max_distance):
            return True
    return False


def _eligible_for_typo_tolerance(answer: str, candidate: str) -> bool:
    if _ASCII_TEXT_RE.fullmatch(answer) is None:
        return False
    if _ASCII_TEXT_RE.fullmatch(candidate) is None:
        return False
    return True


def _compact_for_typo_tolerance(value: str) -> str:
    return _NON_ASCII_LETTER_RE.sub("", value)


def _max_typo_distance(left: str, right: str) -> int:
    max_len = max(len(left), len(right))
    return max(1, (max_len + 4) // 5)


def _damerau_levenshtein_within(left: str, right: str, max_distance: int) -> bool:
    if left == right:
        return True
    if abs(len(left) - len(right)) > max_distance:
        return False

    right_len = len(right)
    previous_previous_row: list[int] | None = None
    previous_row = list(range(right_len + 1))

    for left_index, left_char in enumerate(left, start=1):
        current_row = [left_index] + [0] * right_len
        row_min = current_row[0]
        for right_index, right_char in enumerate(right, start=1):
            substitution_cost = 0 if left_char == right_char else 1
            insertion = current_row[right_index - 1] + 1
            deletion = previous_row[right_index] + 1
            substitution = previous_row[right_index - 1] + substitution_cost
            best = min(insertion, deletion, substitution)

            if (
                previous_previous_row is not None
                and left_index > 1
                and right_index > 1
                and left[left_index - 1] == right[right_index - 2]
                and left[left_index - 2] == right[right_index - 1]
            ):
                best = min(best, previous_previous_row[right_index - 2] + 1)

            current_row[right_index] = best
            if best < row_min:
                row_min = best

        if row_min > max_distance:
            return False

        previous_previous_row = previous_row
        previous_row = current_row

    return previous_row[right_len] <= max_distance
