from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Literal

from wkler.api.models import AssignmentResource, SubjectResource
from wkler.review.ime import ReadingInputMode
from wkler.review.normalize import (
    is_meaning_typo_match,
    normalize_meaning,
    normalize_reading,
)

QuestionKind = Literal["meaning", "reading"]
SubmissionOutcome = Literal[
    "correct",
    "incorrect",
    "revealed",
    "alternate_reading",
    "retry",
    "correct_pending",
]
ShuffleMode = Literal["rolling", "full", "none"]


@dataclass(slots=True)
class SessionItem:
    assignment_id: int
    subject_id: int
    subject_type: str
    available_at: str | None
    subject: dict[str, Any]
    question_index: int = 0
    incorrect_meaning_answers: int = 0
    incorrect_reading_answers: int = 0


@dataclass(slots=True)
class QuestionPrompt:
    kind: QuestionKind
    mode_label: str
    prompt: str
    subject_type: str
    level: int | None
    accepted_answers: list[str]


@dataclass(slots=True)
class CompletedReview:
    assignment_id: int
    subject_id: int
    available_at: str | None
    incorrect_meaning_answers: int
    incorrect_reading_answers: int
    accepted_meaning_answers: list[str] = field(default_factory=list)
    accepted_reading_answers: list[str] = field(default_factory=list)


@dataclass(slots=True)
class SubmissionResult:
    correct: bool
    advanced: bool
    item_completed: bool
    revealed: bool
    feedback: str
    completed_review: CompletedReview | None = None
    outcome: SubmissionOutcome = "correct"


class ReviewEngine:
    def __init__(
        self,
        items: list[SessionItem],
        *,
        reading_input_mode: ReadingInputMode = "always",
        shuffle: bool | None = None,
        shuffle_mode: ShuffleMode | None = None,
        shuffle_window: int = 20,
        seed: str | None = None,
        second_chance_enabled: bool = False,
        confirm_result_enabled: bool = False,
    ) -> None:
        self._items = list(items)
        self._shuffle_mode = _resolve_shuffle_mode(
            shuffle=shuffle,
            shuffle_mode=shuffle_mode,
        )
        self._shuffle_window = max(1, shuffle_window)
        self._rng = random.Random(seed)
        self._pending_items = list(self._items)
        self._active_items: list[SessionItem] = []
        self._current: SessionItem | None = None
        self._attempted = 0
        self._correct_first_try = 0
        self._total_incorrect = 0
        self._reading_input_mode = reading_input_mode
        self._awaiting_incorrect_continue = False
        self._awaiting_correct_continue = False
        self._second_chance_enabled = second_chance_enabled
        self._confirm_result_enabled = confirm_result_enabled
        self._retry_used = False
        self._wrap_up_enabled = False
        self._wrap_up_limit = 10
        self._wrap_up_total = 0
        self._wrap_up_complete_next = False
        self._admit_items_to_capacity()
        self._select_next_item()

    @property
    def reading_input_mode(self) -> ReadingInputMode:
        return self._reading_input_mode

    @property
    def awaiting_incorrect_continue(self) -> bool:
        return self._awaiting_incorrect_continue

    @property
    def awaiting_correct_continue(self) -> bool:
        return self._awaiting_correct_continue

    @property
    def awaiting_retry(self) -> bool:
        return self._retry_used and not self._awaiting_incorrect_continue

    @property
    def wrap_up_enabled(self) -> bool:
        return self._wrap_up_enabled

    def is_done(self) -> bool:
        return self._current is None

    def enable_wrap_up(self, *, limit: int = 10) -> int:
        if self._wrap_up_enabled:
            return self.wrap_up_items_left()

        self._wrap_up_enabled = True
        self._wrap_up_limit = max(1, limit)
        self._wrap_up_complete_next = False

        if self.is_done():
            self._wrap_up_total = 0
            return 0

        ranked = sorted(
            self._active_items,
            key=lambda item: (self._remaining_questions(item), self._rng.random()),
        )
        self._active_items = ranked[: self._wrap_up_limit]
        self._wrap_up_total = len(self._active_items)
        if self._current is not None and not any(
            active is self._current for active in self._active_items
        ):
            self._current = None
        self._select_next_item()
        return self.wrap_up_items_left()

    def wrap_up_items_left(self) -> int:
        return len(self._active_items) if self._wrap_up_enabled else 0

    def wrap_up_items_total(self) -> int:
        return self._wrap_up_total if self._wrap_up_enabled else 0

    def current_question(self) -> QuestionPrompt:
        item = self._current_item()
        kind = _required_questions(item.subject_type)[item.question_index]

        subject_data = item.subject.get("data", {})
        characters = subject_data.get("characters")
        primary_meaning = _primary_meaning(item.subject)

        if kind == "reading":
            prompt = characters or primary_meaning
            accepted_answers = _accepted_readings(item.subject)
            mode_label = "READING"
        else:
            prompt = characters or primary_meaning
            accepted_answers = _accepted_meanings(item.subject)
            mode_label = "MEANING"

        return QuestionPrompt(
            kind=kind,
            mode_label=mode_label,
            prompt=prompt or "(no prompt available)",
            subject_type=item.subject_type,
            level=subject_data.get("level"),
            accepted_answers=accepted_answers,
        )

    def submit(self, answer: str) -> SubmissionResult:
        item = self._current_item()
        question = self.current_question()
        normalized_answer = _normalize_answer(
            answer,
            kind=question.kind,
            reading_input_mode=self._reading_input_mode,
        )

        accepted = _accepted_answer_set(
            item.subject,
            kind=question.kind,
            reading_input_mode=self._reading_input_mode,
        )

        if question.kind == "meaning":
            blacklist = _blacklisted_meaning_set(item.subject)
            is_exact_match = normalized_answer in accepted
            is_typo_match = (
                not is_exact_match and is_meaning_typo_match(normalized_answer, accepted)
            )
            is_correct = (is_exact_match or is_typo_match) and normalized_answer not in blacklist
        else:
            is_correct = normalized_answer in accepted
            if not is_correct:
                alternate_readings = _alternate_reading_set(
                    item.subject,
                    reading_input_mode=self._reading_input_mode,
                )
                if normalized_answer in alternate_readings:
                    self._awaiting_incorrect_continue = False
                    return SubmissionResult(
                        correct=False,
                        advanced=False,
                        item_completed=False,
                        revealed=False,
                        feedback=(
                            "Different valid reading type for this item. "
                            "Try the expected reading."
                        ),
                        outcome="alternate_reading",
                    )

        if is_correct:
            self._awaiting_incorrect_continue = False
            if self._confirm_result_enabled:
                self._awaiting_correct_continue = True
                return SubmissionResult(
                    correct=True,
                    advanced=False,
                    item_completed=False,
                    revealed=False,
                    feedback="Correct.",
                    outcome="correct_pending",
                )
            return self._advance(
                correct=True,
                revealed=False,
                feedback="Correct.",
                outcome="correct",
            )

        if self._second_chance_enabled and not self._retry_used:
            self._retry_used = True
            return SubmissionResult(
                correct=False,
                advanced=False,
                item_completed=False,
                revealed=False,
                feedback="Try again.",
                outcome="retry",
            )

        self._increment_incorrect(question.kind)
        self._awaiting_incorrect_continue = True
        return SubmissionResult(
            correct=False,
            advanced=False,
            item_completed=False,
            revealed=False,
            feedback="Incorrect.",
            outcome="incorrect",
        )

    def continue_after_incorrect(self) -> SubmissionResult:
        if not self._awaiting_incorrect_continue:
            raise RuntimeError("No pending incorrect answer to continue from.")
        self._awaiting_incorrect_continue = False
        return self._advance(
            correct=False,
            revealed=True,
            feedback="Incorrect.",
            outcome="revealed",
        )

    def continue_after_correct(self) -> SubmissionResult:
        if not self._awaiting_correct_continue:
            raise RuntimeError("No pending correct answer to continue from.")
        self._awaiting_correct_continue = False
        return self._advance(
            correct=True,
            revealed=False,
            feedback="Correct.",
            outcome="correct",
        )

    def reveal(self) -> SubmissionResult:
        if self._awaiting_correct_continue:
            return self.continue_after_correct()
        if self._awaiting_incorrect_continue:
            self._awaiting_incorrect_continue = False
            return self._advance(
                correct=False,
                revealed=True,
                feedback="Incorrect.",
                outcome="revealed",
            )
        question = self.current_question()
        self._increment_incorrect(question.kind)
        return self._advance(
            correct=False,
            revealed=True,
            feedback="Revealed. Counted as incorrect.",
            outcome="revealed",
        )

    def stats(self) -> dict[str, int]:
        remaining = len(self._items) - self._attempted
        wrap_up_remaining = self.wrap_up_items_left()
        deferred_remaining = (
            max(0, remaining - wrap_up_remaining) if self._wrap_up_enabled else 0
        )
        return {
            "total": len(self._items),
            "attempted": self._attempted,
            "remaining": remaining,
            "correct_first_try": self._correct_first_try,
            "total_incorrect": self._total_incorrect,
            "wrap_up_enabled": int(self._wrap_up_enabled),
            "wrap_up_remaining": wrap_up_remaining,
            "wrap_up_total": self.wrap_up_items_total(),
            "deferred_remaining": deferred_remaining,
        }

    def _current_item(self) -> SessionItem:
        if self._current is None:
            raise RuntimeError("Review session is complete.")
        return self._current

    def _advance(
        self,
        *,
        correct: bool,
        revealed: bool,
        feedback: str,
        outcome: SubmissionOutcome,
    ) -> SubmissionResult:
        self._awaiting_incorrect_continue = False
        self._awaiting_correct_continue = False
        self._retry_used = False
        item = self._current_item()
        item.question_index += 1

        required_questions = _required_questions(item.subject_type)
        if item.question_index < len(required_questions):
            self._select_next_item()
            return SubmissionResult(
                correct=correct,
                advanced=True,
                item_completed=False,
                revealed=revealed,
                feedback=feedback,
                outcome=outcome,
            )

        completed_review = CompletedReview(
            assignment_id=item.assignment_id,
            subject_id=item.subject_id,
            available_at=item.available_at,
            incorrect_meaning_answers=item.incorrect_meaning_answers,
            incorrect_reading_answers=item.incorrect_reading_answers,
            accepted_meaning_answers=_accepted_meanings(item.subject),
            accepted_reading_answers=_accepted_readings(item.subject),
        )

        if (
            item.incorrect_meaning_answers == 0
            and item.incorrect_reading_answers == 0
        ):
            self._correct_first_try += 1
        self._attempted += 1
        self._remove_active_item(item)
        self._admit_items_to_capacity()
        self._select_next_item()

        return SubmissionResult(
            correct=correct,
            advanced=True,
            item_completed=True,
            revealed=revealed,
            feedback="Item complete.",
            completed_review=completed_review,
            outcome=outcome,
        )

    def _increment_incorrect(self, kind: QuestionKind) -> None:
        item = self._current_item()
        if kind == "meaning":
            item.incorrect_meaning_answers += 1
        else:
            item.incorrect_reading_answers += 1
        self._total_incorrect += 1

    def _active_capacity(self) -> int:
        if self._shuffle_mode == "none":
            return 1
        if self._shuffle_mode == "full":
            return len(self._items)
        return min(self._shuffle_window, len(self._items))

    def _admit_items_to_capacity(self) -> None:
        if self._wrap_up_enabled:
            return
        capacity = self._active_capacity()
        while len(self._active_items) < capacity and self._pending_items:
            self._active_items.append(self._pending_items.pop(0))

    def _select_next_item(self) -> None:
        if not self._active_items:
            self._current = None
            return
        if self._wrap_up_enabled:
            completion_ready = [
                item for item in self._active_items if self._remaining_questions(item) == 1
            ]
            fresh_items = [
                item for item in self._active_items if self._remaining_questions(item) > 1
            ]
            if completion_ready and fresh_items:
                candidates = (
                    completion_ready if self._wrap_up_complete_next else fresh_items
                )
                self._wrap_up_complete_next = not self._wrap_up_complete_next
            elif completion_ready:
                candidates = completion_ready
                self._wrap_up_complete_next = False
            else:
                candidates = fresh_items
                self._wrap_up_complete_next = False
            self._current = self._rng.choice(candidates)
            return
        if self._shuffle_mode == "none":
            self._current = self._active_items[0]
            return
        self._current = self._rng.choice(self._active_items)

    def _remove_active_item(self, item: SessionItem) -> None:
        for idx, active in enumerate(self._active_items):
            if active is item:
                self._active_items.pop(idx)
                return
        raise RuntimeError("Completed item not found in active pool.")

    def _remaining_questions(self, item: SessionItem) -> int:
        required = _required_questions(item.subject_type)
        remaining = len(required) - item.question_index
        return max(1, remaining)


def build_session_items(
    assignments: list[AssignmentResource],
    subjects_by_id: dict[int, SubjectResource],
) -> list[SessionItem]:
    items: list[SessionItem] = []
    for assignment in assignments:
        subject = subjects_by_id.get(assignment.data.subject_id)
        if subject is None:
            continue
        items.append(
            SessionItem(
                assignment_id=assignment.id,
                subject_id=assignment.data.subject_id,
                subject_type=assignment.data.subject_type,
                available_at=assignment.data.available_at,
                subject=subject.model_dump(mode="python"),
            )
        )
    return items


def _resolve_shuffle_mode(
    *,
    shuffle: bool | None,
    shuffle_mode: ShuffleMode | None,
) -> ShuffleMode:
    if shuffle_mode is not None:
        return shuffle_mode
    if shuffle is None:
        return "rolling"
    return "full" if shuffle else "none"


def _required_questions(subject_type: str) -> list[QuestionKind]:
    if subject_type in {"kanji", "vocabulary"}:
        return ["meaning", "reading"]
    return ["meaning"]


def _primary_meaning(subject: dict[str, Any]) -> str:
    meanings = subject.get("data", {}).get("meanings", [])
    for meaning in meanings:
        if meaning.get("primary"):
            return str(meaning.get("meaning", ""))
    if meanings:
        return str(meanings[0].get("meaning", ""))
    return ""


def _accepted_meanings(subject: dict[str, Any]) -> list[str]:
    meanings = subject.get("data", {}).get("meanings", [])
    accepted = [
        str(entry.get("meaning", ""))
        for entry in meanings
        if entry.get("accepted_answer")
    ]

    auxiliary_meanings = subject.get("data", {}).get("auxiliary_meanings", [])
    accepted.extend(
        str(entry.get("meaning", ""))
        for entry in auxiliary_meanings
        if entry.get("type") == "whitelist"
    )

    return list(dict.fromkeys(answer for answer in accepted if answer.strip()))


def _accepted_readings(subject: dict[str, Any]) -> list[str]:
    readings = subject.get("data", {}).get("readings", [])
    accepted = [
        str(entry.get("reading", ""))
        for entry in readings
        if entry.get("accepted_answer")
    ]
    return list(dict.fromkeys(answer for answer in accepted if answer.strip()))


def _alternate_reading_set(
    subject: dict[str, Any],
    *,
    reading_input_mode: ReadingInputMode,
) -> set[str]:
    readings = subject.get("data", {}).get("readings", [])
    normalized = [
        normalize_reading(str(entry.get("reading", "")), mode=reading_input_mode)
        for entry in readings
        if not entry.get("accepted_answer")
    ]
    return {value for value in normalized if value}


def _blacklisted_meaning_set(subject: dict[str, Any]) -> set[str]:
    auxiliary_meanings = subject.get("data", {}).get("auxiliary_meanings", [])
    values = [
        normalize_meaning(str(entry.get("meaning", "")))
        for entry in auxiliary_meanings
        if entry.get("type") == "blacklist"
    ]
    return {value for value in values if value}


def _accepted_answer_set(
    subject: dict[str, Any],
    *,
    kind: QuestionKind,
    reading_input_mode: ReadingInputMode,
) -> set[str]:
    if kind == "meaning":
        normalized = [normalize_meaning(answer) for answer in _accepted_meanings(subject)]
    else:
        normalized = [
            normalize_reading(answer, mode=reading_input_mode)
            for answer in _accepted_readings(subject)
        ]
    return {value for value in normalized if value}


def _normalize_answer(
    answer: str,
    *,
    kind: QuestionKind,
    reading_input_mode: ReadingInputMode,
) -> str:
    if kind == "meaning":
        return normalize_meaning(answer)
    return normalize_reading(answer, mode=reading_input_mode)
