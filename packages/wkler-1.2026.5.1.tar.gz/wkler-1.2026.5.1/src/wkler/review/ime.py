from __future__ import annotations

import re
from typing import Literal

import wanakana

ReadingInputMode = Literal["always", "auto"]


def apply_reading_ime(
    raw: str,
    mode: ReadingInputMode = "always",
    *,
    convert_ending: bool = True,
) -> str:
    text = _expand_collapsed_double_n(raw, convert_ending=convert_ending)
    if mode == "always":
        converted = wanakana.to_hiragana(text, convert_ending=convert_ending)
        return _collapse_live_double_n(converted, convert_ending=convert_ending)
    if wanakana.is_romaji(text):
        converted = wanakana.to_hiragana(text, convert_ending=convert_ending)
        return _collapse_live_double_n(converted, convert_ending=convert_ending)
    return raw


def _collapse_live_double_n(text: str, *, convert_ending: bool) -> str:
    if convert_ending:
        return text
    if text.endswith("んn"):
        return text[:-1]
    return text


def _expand_collapsed_double_n(raw: str, *, convert_ending: bool) -> str:
    if convert_ending:
        return raw
    return re.sub(r"ん(?=[aiueoyAIUEOY])", "んn", raw)
