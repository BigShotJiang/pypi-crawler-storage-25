"""pyomq - Python binding for omq.rs.

Drop-in pyzmq replacement on the common path. Use as::

    import pyomq as zmq

The Socket / Context API mirrors pyzmq's surface; constants
(``zmq.PUSH``, ``zmq.SUBSCRIBE``, ``zmq.LINGER`` ...) match libzmq's
integer values, so existing pyzmq code typically just works.

For asynchronous code::

    import pyomq.asyncio as zmq_async
"""

import json
import os
import pickle
import random
import threading

from . import _native  # type: ignore[attr-defined]
from . import error as error  # noqa: F401

from ._native import (  # type: ignore[attr-defined]
    backend_name,
    version,
    # Socket types
    PAIR,
    PUB,
    SUB,
    REQ,
    REP,
    DEALER,
    ROUTER,
    PULL,
    PUSH,
    XPUB,
    XSUB,
    # Draft socket types (RFC 41 / 48 / 49 / 51 + PEER)
    SERVER,
    CLIENT,
    RADIO,
    DISH,
    GATHER,
    SCATTER,
    PEER,
    CHANNEL,
    # Option constants
    AFFINITY,
    IDENTITY,
    SUBSCRIBE,
    UNSUBSCRIBE,
    RCVMORE,
    TYPE,
    LINGER,
    RECONNECT_IVL,
    RECONNECT_IVL_MAX,
    BACKLOG,
    MAXMSGSIZE,
    SNDHWM,
    RCVHWM,
    RCVTIMEO,
    SNDTIMEO,
    ROUTER_MANDATORY,
    IMMEDIATE,
    IPV6,
    HEARTBEAT_IVL,
    HEARTBEAT_TTL,
    HEARTBEAT_TIMEOUT,
    HANDSHAKE_IVL,
    CONFLATE,
    TCP_KEEPALIVE,
    TCP_KEEPALIVE_IDLE,
    TCP_KEEPALIVE_CNT,
    TCP_KEEPALIVE_INTVL,
    SNDMORE,
    NOBLOCK,
    DONTWAIT,
    # CURVE option ids
    CURVE_SERVER,
    CURVE_PUBLICKEY,
    CURVE_SECRETKEY,
    CURVE_SERVERKEY,
    # BLAKE3ZMQ option ids
    BLAKE3ZMQ_SERVER,
    BLAKE3ZMQ_PUBLICKEY,
    BLAKE3ZMQ_SECRETKEY,
    BLAKE3ZMQ_SERVERKEY,
)

from .error import (  # noqa: F401  re-exports
    ZMQBaseError,
    ZMQError,
    Again,
    ContextTerminated,
    ZMQBindError,
    ZMQVersionError,
    InterruptedSystemCall,
    NotImplementedError as ZMQNotImplementedError,
)

# ── Constants ─────────────────────────────────────────────────────────

POLLIN = 1
POLLOUT = 2
POLLERR = 4
POLLPRI = 32
STREAM = 11
HWM = 1

ROUTING_ID = 5
LAST_ENDPOINT = 32
FD = 14
EVENTS = 15
MECHANISM = 43
SNDBUF = 11
RCVBUF = 12
RATE = 8
CONNECT_TIMEOUT = 79
XPUB_VERBOSE = 40
PROBE_ROUTER = 51
REQ_CORRELATE = 52
REQ_RELAXED = 53
ROUTER_HANDOVER = 56
IPV4ONLY = 31
TCP_ACCEPT_FILTER = 38
TCP_MAXRT = 80
MULTICAST_HOPS = 25
RECOVERY_IVL = 9
RECONNECT_STOP = 109
PLAIN_SERVER = 44
PLAIN_USERNAME = 45
PLAIN_PASSWORD = 46
ZAP_DOMAIN = 55

FORWARDER = 2
QUEUE = 3
STREAMER = 1

NULL = 0
PLAIN = 1
CURVE = 2
BLAKE3ZMQ = 3

__version__ = version()
zmq_version_info = (4, 3, 4)


# ── Top-level functions ──────────────────────────────────────────────

def strerror(errnum):
    return os.strerror(errnum)


def zmq_version():
    return "%d.%d.%d" % zmq_version_info


def pyomq_version():
    return __version__


def pyomq_version_info():
    parts = __version__.split(".")
    return tuple(int(p) for p in parts[:3])


def has(capability):
    cap = capability.lower()
    if cap in ("ipc", "inproc"):
        return True
    if hasattr(_native, "has_feature"):
        return _native.has_feature(cap)
    return False


def curve_keypair():
    if not hasattr(_native, "curve_keypair"):
        raise ZMQNotImplementedError("curve feature not compiled")
    return _native.curve_keypair()


def curve_public(secret):
    if not hasattr(_native, "curve_public"):
        raise ZMQNotImplementedError("curve feature not compiled")
    if isinstance(secret, str):
        secret = secret.encode("ascii")
    return _native.curve_public(secret)


def blake3zmq_keypair():
    if not hasattr(_native, "blake3zmq_keypair"):
        raise ZMQNotImplementedError("blake3zmq feature not compiled")
    return _native.blake3zmq_keypair()


if hasattr(_native, "PeerInfo"):
    PeerInfo = _native.PeerInfo


# ── Socket option attribute map ──────────────────────────────────────

_TYPE_NAMES = {
    PAIR: "PAIR", PUB: "PUB", SUB: "SUB", REQ: "REQ", REP: "REP",
    DEALER: "DEALER", ROUTER: "ROUTER", PULL: "PULL", PUSH: "PUSH",
    XPUB: "XPUB", XSUB: "XSUB", SERVER: "SERVER", CLIENT: "CLIENT",
    RADIO: "RADIO", DISH: "DISH", GATHER: "GATHER", SCATTER: "SCATTER",
    PEER: "PEER", CHANNEL: "CHANNEL", STREAM: "STREAM",
}

_SOCKOPT_NAMES = {
    "affinity": AFFINITY,
    "identity": IDENTITY,
    "routing_id": ROUTING_ID,
    "subscribe": SUBSCRIBE,
    "unsubscribe": UNSUBSCRIBE,
    "rcvmore": RCVMORE,
    "sndhwm": SNDHWM,
    "rcvhwm": RCVHWM,
    "linger": LINGER,
    "reconnect_ivl": RECONNECT_IVL,
    "reconnect_ivl_max": RECONNECT_IVL_MAX,
    "backlog": BACKLOG,
    "maxmsgsize": MAXMSGSIZE,
    "rcvtimeo": RCVTIMEO,
    "sndtimeo": SNDTIMEO,
    "ipv6": IPV6,
    "immediate": IMMEDIATE,
    "router_mandatory": ROUTER_MANDATORY,
    "tcp_keepalive": TCP_KEEPALIVE,
    "tcp_keepalive_idle": TCP_KEEPALIVE_IDLE,
    "tcp_keepalive_cnt": TCP_KEEPALIVE_CNT,
    "tcp_keepalive_intvl": TCP_KEEPALIVE_INTVL,
    "heartbeat_ivl": HEARTBEAT_IVL,
    "heartbeat_ttl": HEARTBEAT_TTL,
    "heartbeat_timeout": HEARTBEAT_TIMEOUT,
    "handshake_ivl": HANDSHAKE_IVL,
    "conflate": CONFLATE,
    "curve_server": CURVE_SERVER,
    "curve_publickey": CURVE_PUBLICKEY,
    "curve_secretkey": CURVE_SECRETKEY,
    "curve_serverkey": CURVE_SERVERKEY,
    "blake3zmq_server": BLAKE3ZMQ_SERVER,
    "blake3zmq_publickey": BLAKE3ZMQ_PUBLICKEY,
    "blake3zmq_secretkey": BLAKE3ZMQ_SECRETKEY,
    "blake3zmq_serverkey": BLAKE3ZMQ_SERVERKEY,
    "sndbuf": SNDBUF,
    "rcvbuf": RCVBUF,
    "mechanism": MECHANISM,
    "plain_server": PLAIN_SERVER,
    "plain_username": PLAIN_USERNAME,
    "plain_password": PLAIN_PASSWORD,
}


# ── Socket wrapper ───────────────────────────────────────────────────

class Socket:
    _sock: _native.Socket
    _context: "Context"
    _closed: bool

    def __init__(self, _sock, _context):
        self._sock = _sock
        self._context = _context
        self._closed = False
        self._last_endpoint = None

    def __getattr__(self, name):
        opt = _SOCKOPT_NAMES.get(name)
        if opt is not None:
            if opt == LAST_ENDPOINT:
                return self._last_endpoint
            return self.getsockopt(opt)
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'"
        )

    def __setattr__(self, name, value):
        if name.startswith("_"):
            object.__setattr__(self, name, value)
            return
        opt = _SOCKOPT_NAMES.get(name)
        if opt is not None:
            self.setsockopt(opt, value)
            return
        object.__setattr__(self, name, value)

    def __repr__(self):
        st = _TYPE_NAMES.get(self.socket_type, str(self.socket_type))
        return f"<pyomq.Socket(pyomq.{st}) at {id(self):#x}>"

    @property
    def closed(self):
        return self._closed

    @property
    def context(self):
        return self._context

    @property
    def socket_type(self):
        return self._sock.getsockopt(TYPE)

    @property
    def underlying(self):
        return self

    # ── I/O ──────────────────────────────────────────────────────────

    @property
    def last_endpoint(self):
        return self._last_endpoint

    def bind(self, endpoint):
        try:
            ep = self._sock.bind(endpoint)
            self._last_endpoint = ep.encode() if isinstance(ep, str) else ep
            return ep
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def connect(self, endpoint):
        try:
            self._sock.connect(endpoint)
            self._last_endpoint = (
                endpoint.encode() if isinstance(endpoint, str) else endpoint
            )
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def unbind(self, endpoint):
        try:
            return self._sock.unbind(endpoint)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def disconnect(self, endpoint):
        try:
            return self._sock.disconnect(endpoint)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def send(self, data, flags=0, copy=True, track=False):
        if not copy:
            raise builtins.NotImplementedError(
                "copy=False requires Frame, which is not implemented"
            )
        if track:
            raise builtins.NotImplementedError(
                "track=True requires MessageTracker, which is not implemented"
            )
        try:
            return self._sock.send(data, flags)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def recv(self, flags=0, copy=True, track=False):
        if not copy:
            raise builtins.NotImplementedError(
                "copy=False requires Frame, which is not implemented"
            )
        try:
            return self._sock.recv(flags)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def send_multipart(self, parts, flags=0, copy=True, track=False):
        try:
            return self._sock.send_multipart(parts, flags)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def recv_multipart(self, flags=0, copy=True, track=False):
        try:
            return self._sock.recv_multipart(flags)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    # ── Serialization helpers ────────────────────────────────────────

    def send_string(self, u, flags=0, encoding="utf-8"):
        return self.send(u.encode(encoding), flags)

    def recv_string(self, flags=0, encoding="utf-8"):
        return self.recv(flags).decode(encoding)

    def send_json(self, obj, flags=0, **kwargs):
        return self.send(json.dumps(obj, **kwargs).encode("utf-8"), flags)

    def recv_json(self, flags=0, **kwargs):
        return json.loads(self.recv(flags), **kwargs)

    def send_pyobj(self, obj, flags=0, protocol=-1):
        return self.send(pickle.dumps(obj, protocol), flags)

    def recv_pyobj(self, flags=0):
        return pickle.loads(self.recv(flags))

    def send_serialized(self, msg, serialize, flags=0, copy=True, **kwargs):
        frames = serialize(msg)
        return self.send_multipart(frames, flags=flags, copy=copy, **kwargs)

    def recv_serialized(self, deserialize, flags=0, copy=True):
        frames = self.recv_multipart(flags=flags, copy=copy)
        return deserialize(frames)

    # ── Options ──────────────────────────────────────────────────────

    def setsockopt(self, option, value):
        try:
            return self._sock.setsockopt(option, value)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def getsockopt(self, option):
        try:
            return self._sock.getsockopt(option)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def set(self, option, value):
        return self.setsockopt(option, value)

    def get(self, option):
        return self.getsockopt(option)

    def setsockopt_string(self, option, value, encoding="utf-8"):
        return self.setsockopt(option, value.encode(encoding))

    def getsockopt_string(self, option, encoding="utf-8"):
        v = self.getsockopt(option)
        if isinstance(v, bytes):
            return v.decode(encoding)
        return str(v)

    set_string = setsockopt_string
    get_string = getsockopt_string

    def set_curve_auth(self, auth):
        try:
            return self._sock.set_curve_auth(auth)
        except _native.ZMQError as e:
            raise error.from_native(e) from None
        except AttributeError:
            raise ZMQNotImplementedError("curve feature not compiled")

    def set_blake3zmq_auth(self, auth):
        try:
            return self._sock.set_blake3zmq_auth(auth)
        except _native.ZMQError as e:
            raise error.from_native(e) from None
        except AttributeError:
            raise ZMQNotImplementedError("blake3zmq feature not compiled")

    def set_hwm(self, value):
        self.setsockopt(SNDHWM, value)
        self.setsockopt(RCVHWM, value)

    def get_hwm(self):
        return self.getsockopt(SNDHWM)

    hwm = property(get_hwm, set_hwm)

    # ── Subscriptions ────────────────────────────────────────────────

    def subscribe(self, prefix):
        try:
            return self._sock.subscribe(prefix)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def unsubscribe(self, prefix):
        try:
            return self._sock.unsubscribe(prefix)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def join(self, group):
        try:
            return self._sock.join(group)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    def leave(self, group):
        try:
            return self._sock.leave(group)
        except _native.ZMQError as e:
            raise error.from_native(e) from None

    # ── Monitoring ───────────────────────────────────────────────────

    def monitor(self):
        return self._sock.monitor()

    def connections(self):
        return self._sock.connections()

    def connection_info(self, connection_id):
        return self._sock.connection_info(connection_id)

    # ── Lifecycle ────────────────────────────────────────────────────

    def close(self, linger=None):
        if not self._closed:
            self._closed = True
            self._sock.close(linger)

    def bind_to_random_port(self, addr, min_port=49152, max_port=65536,
                            max_tries=100):
        ep = self.bind(f"{addr}:0")
        if isinstance(ep, bytes):
            ep = ep.decode()
        return int(ep.rsplit(":", 1)[1])

    def poll(self, timeout=None, flags=POLLIN):
        p = Poller()
        p.register(self, flags)
        evts = p.poll(timeout)
        for sock, mask in evts:
            if sock is self:
                return mask
        return 0

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False


# ── Context wrapper ──────────────────────────────────────────────────

class Context:
    _instance = None
    _instance_lock = threading.Lock()

    def __init__(self, io_threads=1):
        self._ctx = _native.Context(io_threads)
        self._closed = False
        self._sockets = set()

    @property
    def closed(self):
        return self._closed

    def socket(self, socket_type, socket_class=None, **kwargs):
        native = self._ctx.socket(socket_type)
        cls = socket_class or Socket
        s = object.__new__(cls)
        s._sock = native
        s._context = self
        s._closed = False
        s._last_endpoint = None
        self._sockets.add(s)
        return s

    @classmethod
    def instance(cls, io_threads=1):
        with cls._instance_lock:
            if cls._instance is None or cls._instance._closed:
                cls._instance = cls(io_threads)
            return cls._instance

    def term(self):
        self._closed = True
        self._ctx.term()

    def destroy(self, linger=None):
        for s in list(self._sockets):
            if not s.closed:
                if linger is not None:
                    s.setsockopt(LINGER, linger)
                s.close()
        self._sockets.clear()
        self.term()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.term()
        return False


# ── Poller ───────────────────────────────────────────────────────────

class Poller:
    def __init__(self):
        self._sockets = {}  # native_socket_id -> (Socket, flags)

    def register(self, socket, flags=POLLIN):
        self._sockets[socket._sock.socket_id()] = (socket, flags)

    def unregister(self, socket):
        self._sockets.pop(socket._sock.socket_id(), None)

    def modify(self, socket, flags):
        k = socket._sock.socket_id()
        if k in self._sockets:
            self._sockets[k] = (socket, flags)

    @property
    def sockets(self):
        return [(s, f) for s, f in self._sockets.values()]

    def poll(self, timeout=None):
        if not self._sockets:
            return []
        pollin_socks = [
            s._sock
            for k, (s, f) in self._sockets.items()
            if f & POLLIN
        ]
        if not pollin_socks:
            return []
        t = None if (timeout is None or timeout < 0) else int(timeout)
        ready_ids = _native.wait_any(pollin_socks, t)
        return [
            (self._sockets[rid][0], POLLIN)
            for rid in ready_ids
            if rid in self._sockets
        ]


# ── select ──────────────────────────────────────────────────────────

def select(rlist, wlist, xlist, timeout=None):
    if timeout is not None:
        timeout_ms = int(timeout * 1000)
    else:
        timeout_ms = None
    p = Poller()
    for s in rlist:
        p.register(s, POLLIN)
    for s in wlist:
        p.register(s, POLLOUT)
    evts = p.poll(timeout_ms)
    rready, wready, xready = [], [], []
    for sock, mask in evts:
        if mask & POLLIN:
            rready.append(sock)
        if mask & POLLOUT:
            wready.append(sock)
    return rready, wready, xready


# ── proxy ────────────────────────────────────────────────────────────

def proxy(frontend, backend, capture=None):
    _native.native_proxy(
        frontend._sock, backend._sock,
        capture._sock if capture is not None else None,
    )


def proxy_steerable(frontend, backend, capture=None, control=None):
    _native.native_proxy(
        frontend._sock, backend._sock,
        capture._sock if capture is not None else None,
        control._sock if control is not None else None,
    )


def device(device_type, frontend, backend):
    proxy(frontend, backend)


# ── builtins reference (for copy/track errors) ──────────────────────

import builtins  # noqa: E402

__all__ = [
    "Context",
    "Socket",
    "Poller",
    "ZMQBaseError",
    "ZMQError",
    "ZMQBindError",
    "ZMQVersionError",
    "Again",
    "ContextTerminated",
    "InterruptedSystemCall",
    "backend_name",
    "version",
    "proxy",
    "proxy_steerable",
    "device",
    "strerror",
    "has",
    "select",
    "error",
    # socket types
    "PAIR", "PUB", "SUB", "REQ", "REP", "DEALER", "ROUTER",
    "PULL", "PUSH", "XPUB", "XSUB",
    # draft socket types
    "SERVER", "CLIENT", "RADIO", "DISH", "GATHER", "SCATTER",
    "PEER", "CHANNEL",
    # options
    "AFFINITY", "IDENTITY", "ROUTING_ID", "SUBSCRIBE", "UNSUBSCRIBE",
    "RCVMORE", "TYPE", "LINGER", "RECONNECT_IVL", "RECONNECT_IVL_MAX",
    "BACKLOG", "MAXMSGSIZE", "SNDHWM", "RCVHWM", "RCVTIMEO", "SNDTIMEO",
    "ROUTER_MANDATORY", "IMMEDIATE", "IPV6",
    "HEARTBEAT_IVL", "HEARTBEAT_TTL", "HEARTBEAT_TIMEOUT",
    "HANDSHAKE_IVL", "CONFLATE",
    "TCP_KEEPALIVE", "TCP_KEEPALIVE_IDLE", "TCP_KEEPALIVE_CNT",
    "TCP_KEEPALIVE_INTVL",
    "SNDMORE", "NOBLOCK", "DONTWAIT",
    "CURVE_SERVER", "CURVE_PUBLICKEY", "CURVE_SECRETKEY", "CURVE_SERVERKEY",
    "BLAKE3ZMQ_SERVER", "BLAKE3ZMQ_PUBLICKEY", "BLAKE3ZMQ_SECRETKEY", "BLAKE3ZMQ_SERVERKEY",
    # poll / compat constants
    "POLLIN", "POLLOUT", "POLLERR", "POLLPRI", "STREAM", "HWM",
    # additional compat constants
    "LAST_ENDPOINT", "FD", "EVENTS", "MECHANISM", "SNDBUF", "RCVBUF",
    "RATE", "CONNECT_TIMEOUT", "XPUB_VERBOSE", "PROBE_ROUTER",
    "REQ_CORRELATE", "REQ_RELAXED", "ROUTER_HANDOVER", "IPV4ONLY",
    "TCP_ACCEPT_FILTER", "TCP_MAXRT", "MULTICAST_HOPS", "RECOVERY_IVL",
    "RECONNECT_STOP", "PLAIN_SERVER", "PLAIN_USERNAME", "PLAIN_PASSWORD",
    "ZAP_DOMAIN",
    # device types
    "FORWARDER", "QUEUE", "STREAMER",
    # security mechanism constants
    "NULL", "PLAIN", "CURVE", "BLAKE3ZMQ",
    # version
    "__version__", "zmq_version_info", "zmq_version",
    "pyomq_version", "pyomq_version_info",
    # curve
    "curve_keypair", "curve_public", "blake3zmq_keypair", "PeerInfo",
]
