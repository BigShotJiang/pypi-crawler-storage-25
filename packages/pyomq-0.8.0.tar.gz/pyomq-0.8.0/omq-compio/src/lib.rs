//! omq-compio - compio-runtime backend for omq.
//!
//! Built on compio's thread-per-core executor with io_uring (Linux),
//! IOCP (Windows), and kqueue (macOS) drivers. Each `Socket`
//! is pinned to the executor it was created on; cross-executor sends
//! use a runtime-agnostic mpsc (flume).
//!
//! The codec, message types, mechanism handshakes, and routing
//! algorithms come from the runtime-agnostic `omq-proto` crate.
//! This crate provides only the runtime glue.
//!
//! Status: beachhead. PUSH/PULL on inproc + TCP, send-batching,
//! gather writes via compio's `Vec<Bytes>` `IoVectoredBuf` path.

#[cfg(feature = "priority")]
pub use omq_proto::ConnectOpts;
#[cfg(any(feature = "curve", feature = "blake3zmq", feature = "plain"))]
pub use omq_proto::{Authenticator, MechanismPeerInfo};
#[cfg(feature = "blake3zmq")]
pub use omq_proto::{Blake3ZmqKeypair, Blake3ZmqPublicKey, Blake3ZmqSecretKey};
#[cfg(feature = "curve")]
pub use omq_proto::{CurveCookieKeyring, CurveKeypair, CurvePublicKey, CurveSecretKey};
pub use omq_proto::{
    Endpoint, EndpointRole, EndpointSpec, Error, Frame, FrameFlags, IpcPath, KeepAlive,
    MechanismConfig, Message, MessageIter, OnMute, Options, ReconnectPolicy, Result, SocketType,
    is_compatible,
};

pub use omq_proto::endpoint;
pub use omq_proto::error;
pub use omq_proto::message;
pub use omq_proto::options;
pub use omq_proto::proto;

pub mod monitor;
pub mod runtime;
pub mod socket;
pub mod transport;

pub use monitor::{
    ConnectionStatus, DisconnectReason, MonitorEvent, MonitorRecvError, MonitorStream,
    MonitorTryRecvError, PeerCommandKind, PeerIdent, PeerInfo,
};
pub use runtime::{
    DEFAULT_BUFFER_POOL_COUNT, DEFAULT_BUFFER_POOL_LEN, ProactorBuilderExt, build_default_runtime,
};
pub use socket::Socket;
