"""Tests for MapViewer class."""

from pathlib import Path

import pytest

from ndslive.mapviewer import MapViewer, __default_image__
from ndslive.mapviewer.exceptions import (
    ConfigError,
    ContainerNotFound,
)


def _same_path(a: Path, b: Path) -> bool:
    """Compare paths, handling macOS /var -> /private/var symlink."""
    return a.resolve() == b.resolve()


class TestMapViewerInit:
    """Tests for MapViewer initialization."""

    def test_requires_config_or_demo(self):
        """Must provide config or use demo mode."""
        with pytest.raises(ConfigError) as exc_info:
            MapViewer()
        assert "No configuration provided" in str(exc_info.value)

    def test_demo_mode_no_config_required(self):
        """Demo mode doesn't require config file."""
        mv = MapViewer(demo=True)
        assert mv._demo is True
        assert mv.config_path is None

    def test_config_file_validation(self, temp_dir):
        """Config file must exist and be readable."""
        with pytest.raises(ConfigError) as exc_info:
            MapViewer(config=temp_dir / "nonexistent.yaml")
        assert "not found" in str(exc_info.value)

    def test_config_must_be_file(self, temp_dir):
        """Config path must be a file, not directory."""
        with pytest.raises(ConfigError) as exc_info:
            MapViewer(config=temp_dir)
        assert "not a file" in str(exc_info.value)

    def test_valid_config(self, sample_config):
        """Valid config creates MapViewer instance."""
        mv = MapViewer(config=sample_config, edition="member")
        assert _same_path(mv.config_path, sample_config)
        assert mv.edition == "member"

    def test_default_edition(self, sample_config):
        """Default edition is community."""
        mv = MapViewer(config=sample_config)
        assert mv.edition == "community"

    def test_default_version(self, sample_config):
        """Default version is 'latest'."""
        mv = MapViewer(config=sample_config)
        assert mv.version == __default_image__

    def test_auto_port_selection(self, sample_config):
        """Port 0 triggers auto-selection."""
        mv = MapViewer(config=sample_config, port=0)
        # Port should be auto-selected (likely 8089 or another)
        assert mv.port > 0

    def test_explicit_port(self, sample_config):
        """Explicit port is used."""
        mv = MapViewer(config=sample_config, port=9999)
        assert mv.port == 9999


class TestMapViewerBindAddress:
    """Tests for bind_address parameter."""

    def test_default_bind_address(self, sample_config):
        """Default bind address is 127.0.0.1."""
        mv = MapViewer(config=sample_config)
        assert mv.bind_address == "127.0.0.1"

    def test_custom_bind_address(self, sample_config):
        """Custom bind address is stored."""
        mv = MapViewer(config=sample_config, bind_address="0.0.0.0")
        assert mv.bind_address == "0.0.0.0"


class TestMapViewerProperties:
    """Tests for MapViewer properties."""

    def test_url_property(self, sample_config):
        """URL property returns correct format."""
        mv = MapViewer(config=sample_config, port=8089)
        assert mv.url == "http://localhost:8089"

    def test_name_property_default(self, sample_config):
        """Default container name."""
        mv = MapViewer(config=sample_config)
        assert mv.name == "ndslive-mapviewer"

    def test_name_property_custom(self, sample_config):
        """Custom container name."""
        mv = MapViewer(config=sample_config, name="custom-viewer")
        assert mv.name == "custom-viewer"


class TestMapViewerConnect:
    """Tests for MapViewer.connect()."""

    def test_connect_no_container_raises(self, docker_client):
        """connect() raises when no container exists."""
        with pytest.raises(ContainerNotFound):
            MapViewer.connect("nonexistent-viewer-xyz123")


class TestMapViewerStatus:
    """Tests for MapViewer.status()."""

    def test_status_not_started(self, sample_config, container_name):
        """Status is 'not_found' before starting."""
        mv = MapViewer(config=sample_config, name=container_name)
        assert mv.status() == "not_found"


class TestMapViewerConfigTransformation:
    """Tests for config transformation in MapViewer."""

    def test_load_and_transform_http_config(self, sample_config):
        """HTTP-only config transforms correctly."""
        mv = MapViewer(config=sample_config)
        # Force load (normally happens in start())
        transformed = mv._load_and_transform_config()

        assert transformed.config is not None
        assert transformed.volumes == []
        assert mv.original_config is not None

    def test_load_and_transform_local_path(self, sample_config_with_local_path):
        """Local path config creates volume mounts."""
        config_path, data_dir = sample_config_with_local_path
        mv = MapViewer(config=config_path)
        transformed = mv._load_and_transform_config()

        assert len(transformed.volumes) >= 1
        # Volume should point to the data directory (resolve for macOS symlink)
        host_paths = [v.host_path.resolve() for v in transformed.volumes]
        assert data_dir.resolve() in host_paths


class TestMapViewerDemoMode:
    """Tests for demo mode."""

    def test_demo_returns_no_config(self):
        """Demo mode should not produce a transformed config."""
        mv = MapViewer(demo=True)
        transformed = mv._load_and_transform_config()
        assert transformed is None

    def test_demo_has_no_config_path(self):
        """Demo mode has no config path."""
        mv = MapViewer(demo=True)
        assert mv.config_path is None
