"""Tests for Docker operations (requires Docker)."""

import pytest

from ndslive.mapviewer import docker_client as dc
from ndslive.mapviewer.exceptions import ContainerNotFound, ImagePullFailed


@pytest.mark.order(1)
class TestDockerAvailability:
    """Docker availability check - runs first."""

    def test_docker_is_available(self, docker_client):
        """Docker must be installed and running for tests to proceed."""
        assert docker_client is not None
        # If we get here, docker_client fixture succeeded
        info = docker_client.info()
        assert "ID" in info


class TestGetDockerClient:
    """Tests for get_docker_client()."""

    def test_returns_client(self, docker_client):
        """get_docker_client returns a working client."""
        client = dc.get_docker_client()
        assert client is not None
        client.ping()

    def test_client_can_list_containers(self, docker_client):
        """Client can list containers."""
        containers = docker_client.containers.list(all=True)
        assert isinstance(containers, list)


class TestGetDockerInfo:
    """Tests for get_docker_info()."""

    def test_returns_docker_info(self):
        """get_docker_info returns DockerInfo dataclass."""
        info = dc.get_docker_info()
        assert info is not None
        assert hasattr(info, "version")
        assert hasattr(info, "running")
        assert hasattr(info, "platform")
        assert info.running is True


class TestDetectArchitecture:
    """Tests for detect_architecture()."""

    def test_returns_valid_arch(self):
        """Returns a valid architecture string."""
        arch = dc.detect_architecture()
        assert arch in ("amd64", "arm64")


class TestFindFreePort:
    """Tests for find_free_port()."""

    def test_returns_integer(self):
        """Returns an integer port number."""
        port = dc.find_free_port()
        assert isinstance(port, int)
        assert 1024 <= port <= 65535

    def test_preferred_port_if_available(self):
        """Uses preferred port if available."""
        import socket

        # Find a definitely-free port first
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            free_port = s.getsockname()[1]

        # Now test that find_free_port returns it when preferred
        result = dc.find_free_port(preferred=free_port)
        assert result == free_port

    def test_fallback_when_preferred_busy(self):
        """Falls back to another port when preferred is busy."""
        import socket

        # Bind a port to make it busy
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            busy_port = s.getsockname()[1]
            s.listen(1)

            # Request the busy port
            result = dc.find_free_port(preferred=busy_port)
            assert result != busy_port
            assert isinstance(result, int)


class TestGetImageTag:
    """Tests for get_image_tag()."""

    def test_community_edition(self):
        """Community edition tag format."""
        tag = dc.get_image_tag("community", "latest", arch="amd64")
        assert "ndslive-dockerreg" in tag
        assert "nds-mapviewer" in tag
        assert "latest-amd64" in tag

    def test_member_edition(self):
        """Member edition tag format."""
        tag = dc.get_image_tag("member", "v2025.6.0", arch="arm64")
        assert "tooling-dockerreg" in tag
        assert "nds-mapviewer" in tag
        assert "v2025.6.0-arm64" in tag

    def test_invalid_edition_raises(self):
        """Invalid edition raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            dc.get_image_tag("invalid", "latest")
        assert "Unknown edition" in str(exc_info.value)


class TestIsLoggedIn:
    """Tests for is_logged_in()."""

    def test_returns_boolean(self):
        """Returns a boolean value."""
        result = dc.is_logged_in("member")
        assert isinstance(result, bool)

    def test_invalid_edition_returns_false(self):
        """Invalid edition returns False."""
        result = dc.is_logged_in("nonexistent")
        assert result is False


class TestListContainers:
    """Tests for list_containers()."""

    def test_returns_list(self, docker_client):
        """Returns a list (possibly empty)."""
        result = dc.list_containers()
        assert isinstance(result, list)


class TestGetContainer:
    """Tests for get_container()."""

    def test_nonexistent_returns_none(self, docker_client):
        """Returns None for nonexistent container."""
        result = dc.get_container("nonexistent-container-xyz123")
        assert result is None


class TestGetContainerStatus:
    """Tests for get_container_status()."""

    def test_nonexistent_returns_not_found(self, docker_client):
        """Returns 'not_found' for nonexistent container."""
        status = dc.get_container_status("nonexistent-container-xyz123")
        assert status == "not_found"


class TestGetContainerLogs:
    """Tests for get_container_logs()."""

    def test_nonexistent_raises(self, docker_client):
        """Raises ContainerNotFound for nonexistent container."""
        with pytest.raises(ContainerNotFound):
            dc.get_container_logs("nonexistent-container-xyz123")


class TestStopContainer:
    """Tests for stop_container()."""

    def test_nonexistent_raises(self, docker_client):
        """Raises ContainerNotFound for nonexistent container."""
        with pytest.raises(ContainerNotFound):
            dc.stop_container("nonexistent-container-xyz123")


class TestPullImageErrorHandling:
    """Tests for pull_image() error stream handling."""

    def test_stream_error_raises_pull_failed(self, docker_client, mocker):
        """Errors reported in the pull stream raise ImagePullFailed."""
        mock_client = mocker.MagicMock()
        mock_client.api.pull.return_value = iter([
            {"status": "Pulling from nds-mapviewer", "id": "latest-arm64"},
            {"error": "write /var/lib/docker/overlay2/...: no space left on device"},
        ])
        mocker.patch.object(dc, "get_docker_client", return_value=mock_client)
        mocker.patch.object(dc, "is_logged_in", return_value=True)

        with pytest.raises(ImagePullFailed, match="no space left on device"):
            dc.pull_image("community", "latest", arch="arm64")


class TestListInstalledEditions:
    """Tests for list_installed_editions()."""

    def test_returns_list(self, docker_client):
        """Returns a list of edition strings."""
        result = dc.list_installed_editions()
        assert isinstance(result, list)
        for edition in result:
            assert edition in ("community", "member")


class TestGetLocalDigest:
    """Tests for get_local_digest()."""

    def test_nonexistent_returns_none(self, docker_client):
        """Returns None when image does not exist locally."""
        result = dc.get_local_digest("community", "nonexistent-version-xyz")
        assert result is None


class TestGetRemoteDigest:
    """Tests for get_remote_digest()."""

    def test_with_mocked_distribution(self, docker_client, mocker):
        """Returns digest from inspect_distribution response."""
        mock_client = mocker.MagicMock()
        mock_client.api.inspect_distribution.return_value = {
            "Descriptor": {"digest": "sha256:abc123", "size": 12345},
        }
        mocker.patch.object(dc, "get_docker_client", return_value=mock_client)
        mocker.patch.object(dc, "is_logged_in", return_value=True)

        result = dc.get_remote_digest("community", "latest", "arm64")
        assert result == "sha256:abc123"
        mock_client.api.inspect_distribution.assert_called_once()

    def test_not_logged_in_raises(self, docker_client, mocker):
        """Raises RegistryNotLoggedIn when not logged in."""
        mocker.patch.object(dc, "is_logged_in", return_value=False)
        from ndslive.mapviewer.exceptions import RegistryNotLoggedIn
        with pytest.raises(RegistryNotLoggedIn):
            dc.get_remote_digest("community", "latest", "arm64")


class TestCheckForUpdate:
    """Tests for check_for_update()."""

    def test_same_digest_no_update(self, docker_client, mocker):
        """Same local and remote digest means no update."""
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:abc")
        mocker.patch.object(dc, "get_remote_digest", return_value="sha256:abc")

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is False
        assert status.error is None

    def test_different_digest_update_available(self, docker_client, mocker):
        """Different digests means update available."""
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:old")
        mocker.patch.object(dc, "get_remote_digest", return_value="sha256:new")

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is True
        assert status.error is None

    def test_remote_failure_captured(self, docker_client, mocker):
        """Remote digest failure is captured in error field."""
        from ndslive.mapviewer.exceptions import RegistryQueryFailed
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:abc")
        mocker.patch.object(
            dc, "get_remote_digest",
            side_effect=RegistryQueryFailed("test-registry", "connection refused"),
        )

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is False
        assert status.error is not None
