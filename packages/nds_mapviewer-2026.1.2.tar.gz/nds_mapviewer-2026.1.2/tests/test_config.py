"""Tests for config loading and transformation (no Docker required)."""

from pathlib import Path

import pytest
import yaml

from ndslive.mapviewer.config import (
    CONFIGS_DIR,
    _extract_local_path,
    _is_localhost,
    _transform_localhost,
    create_classic_config,
    create_filestore_config,
    create_folder_config,
    create_geojson_config,
    create_service_config,
    delete_config,
    detect_directory_type,
    list_saved_configs,
    load_config,
    resolve_config_source,
    save_config,
    transform_config,
    validate_paths,
    write_config_to_temp,
)
from ndslive.mapviewer.exceptions import ConfigError


class TestLoadConfig:
    """Tests for load_config()."""

    def test_load_valid_yaml(self, sample_config):
        """Load a valid YAML config file."""
        config = load_config(sample_config)
        assert isinstance(config, dict)
        assert "sources" in config
        assert len(config["sources"]) == 1
        assert config["sources"][0]["mapId"] == "Test Island"

    def test_load_nonexistent_file(self, temp_dir):
        """Raise ConfigError for nonexistent file."""
        with pytest.raises(ConfigError) as exc_info:
            load_config(temp_dir / "nonexistent.yaml")
        assert "not found" in str(exc_info.value)

    def test_load_invalid_yaml(self, temp_dir):
        """Raise ConfigError for invalid YAML."""
        bad_file = temp_dir / "bad.yaml"
        bad_file.write_text("{ invalid yaml: [")
        with pytest.raises(ConfigError) as exc_info:
            load_config(bad_file)
        assert "Invalid YAML" in str(exc_info.value)

    def test_load_non_dict_yaml(self, temp_dir):
        """Raise ConfigError if YAML is not a dictionary."""
        list_file = temp_dir / "list.yaml"
        list_file.write_text("- item1\n- item2")
        with pytest.raises(ConfigError) as exc_info:
            load_config(list_file)
        assert "must be a YAML dictionary" in str(exc_info.value)

    def test_load_empty_yaml(self, temp_dir):
        """Raise ConfigError for empty YAML file."""
        empty_file = temp_dir / "empty.yaml"
        empty_file.write_text("")
        with pytest.raises(ConfigError):
            load_config(empty_file)


class TestDemoMode:
    """Tests for demo mode (no config, container uses built-in)."""

    def test_demo_mode_returns_none(self):
        """Demo mode should not produce a transformed config."""
        from ndslive.mapviewer.viewer import MapViewer
        mv = MapViewer(demo=True)
        result = mv._load_and_transform_config()
        assert result is None


def _same_path(a: Path, b: Path) -> bool:
    """Compare paths, handling macOS /var -> /private/var symlink."""
    return a.resolve() == b.resolve()


class TestExtractLocalPath:
    """Tests for _extract_local_path()."""

    def test_filestore_absolute_path(self, temp_dir):
        """Extract path from filestore: URI."""
        data_dir = temp_dir / "data"
        data_dir.mkdir()
        result = _extract_local_path(f"filestore:{data_dir}")
        assert _same_path(result, data_dir)

    def test_folder_absolute_path(self, temp_dir):
        """Extract path from folder: URI."""
        data_dir = temp_dir / "folder"
        data_dir.mkdir()
        result = _extract_local_path(f"folder:{data_dir}")
        assert _same_path(result, data_dir)

    def test_plain_absolute_path(self, temp_dir):
        """Extract plain absolute path."""
        data_dir = temp_dir / "plain"
        data_dir.mkdir()
        result = _extract_local_path(str(data_dir))
        assert _same_path(result, data_dir)

    def test_http_url_returns_none(self):
        """HTTP URLs should not be extracted."""
        result = _extract_local_path("https://api.nds.live/island6")
        assert result is None

    def test_relative_path_returns_none(self):
        """Relative paths should not be extracted."""
        result = _extract_local_path("./data")
        assert result is None

    def test_filestore_relative_returns_none(self):
        """filestore: with relative path returns None."""
        result = _extract_local_path("filestore:./relative")
        assert result is None

    def test_tilde_expansion(self, temp_dir, monkeypatch):
        """Tilde paths should be expanded."""
        # Create dir in temp and pretend it's home
        home_data = temp_dir / "home_data"
        home_data.mkdir()
        monkeypatch.setenv("HOME", str(temp_dir))
        result = _extract_local_path("filestore:~/home_data")
        assert result is not None


class TestIsLocalhost:
    """Tests for _is_localhost()."""

    def test_localhost(self):
        assert _is_localhost("localhost") is True
        assert _is_localhost("localhost:8888") is True

    def test_127_0_0_1(self):
        assert _is_localhost("127.0.0.1") is True
        assert _is_localhost("127.0.0.1:9000") is True

    def test_remote_host(self):
        assert _is_localhost("api.nds.live") is False
        assert _is_localhost("192.168.1.1") is False
        assert _is_localhost("10.0.0.1:8080") is False


class TestTransformLocalhost:
    """Tests for _transform_localhost()."""

    def test_transform_localhost(self):
        assert _transform_localhost("localhost") == "host.docker.internal"
        assert _transform_localhost("localhost:8888") == "host.docker.internal:8888"

    def test_transform_127_0_0_1(self):
        assert _transform_localhost("127.0.0.1") == "host.docker.internal"
        assert _transform_localhost("127.0.0.1:9000") == "host.docker.internal:9000"

    def test_no_transform_remote(self):
        assert _transform_localhost("api.nds.live") == "api.nds.live"


class TestTransformConfig:
    """Tests for transform_config()."""

    def test_http_only_no_volumes(self):
        """HTTP-only config produces no volume mounts."""
        config = {
            "sources": [
                {
                    "type": "SmartLayerTileService",
                    "uri": "https://api.nds.live/test",
                    "mapId": "Test",
                }
            ]
        }
        result = transform_config(config)
        assert result.volumes == []
        assert result.config["sources"][0]["uri"] == "https://api.nds.live/test"

    def test_local_folder_creates_volume(self, temp_dir):
        """Local folder path creates volume mount."""
        data_dir = temp_dir / "data"
        data_dir.mkdir()

        config = {
            "sources": [
                {
                    "type": "ClassicFolder",
                    "folder": str(data_dir),
                    "mapId": "Local",
                }
            ]
        }
        result = transform_config(config)

        assert len(result.volumes) == 1
        assert _same_path(result.volumes[0].host_path, data_dir)
        assert result.config["sources"][0]["folder"].startswith("/data/")

    def test_filestore_uri_creates_volume(self, temp_dir):
        """filestore: URI creates volume mount."""
        data_dir = temp_dir / "store"
        data_dir.mkdir()

        config = {
            "sources": [
                {
                    "type": "SmartLayerTileService",
                    "uri": f"filestore:{data_dir}",
                    "mapId": "Filestore",
                }
            ]
        }
        result = transform_config(config)

        assert len(result.volumes) == 1
        assert "filestore:/data/" in result.config["sources"][0]["uri"]

    def test_localhost_host_transformed(self):
        """localhost host is transformed to host.docker.internal."""
        config = {
            "sources": [
                {
                    "type": "DataSourceHost",
                    "host": "localhost:8888",
                    "mapId": "Local Source",
                }
            ]
        }
        result = transform_config(config)
        assert result.config["sources"][0]["host"] == "host.docker.internal:8888"

    def test_multiple_local_paths_deduplicated(self, temp_dir):
        """Multiple paths under same parent share a volume mount."""
        parent = temp_dir / "parent"
        child1 = parent / "child1"
        child2 = parent / "child2"
        child1.mkdir(parents=True)
        child2.mkdir(parents=True)

        config = {
            "sources": [
                {"type": "ClassicFolder", "folder": str(child1), "mapId": "C1"},
                {"type": "ClassicFolder", "folder": str(child2), "mapId": "C2"},
            ]
        }
        result = transform_config(config)

        # Should have 2 separate volumes (different dirs)
        assert len(result.volumes) == 2


class TestValidatePaths:
    """Tests for validate_paths()."""

    def test_valid_paths_no_errors(self, temp_dir):
        """No errors for existing paths."""
        data_dir = temp_dir / "valid"
        data_dir.mkdir()

        config = {
            "sources": [
                {"type": "ClassicFolder", "folder": str(data_dir), "mapId": "Valid"}
            ]
        }
        errors = validate_paths(config)
        assert errors == []

    def test_missing_folder_error(self, temp_dir):
        """Error for missing folder path."""
        config = {
            "sources": [
                {
                    "type": "ClassicFolder",
                    "folder": str(temp_dir / "nonexistent"),
                    "mapId": "Missing",
                }
            ]
        }
        errors = validate_paths(config)
        assert len(errors) == 1
        assert "Missing" in errors[0]
        assert "does not exist" in errors[0]

    def test_missing_uri_filestore_error(self, temp_dir):
        """Error for missing filestore: path."""
        config = {
            "sources": [
                {
                    "type": "SmartLayerTileService",
                    "uri": f"filestore:{temp_dir}/missing",
                    "mapId": "Missing URI",
                }
            ]
        }
        errors = validate_paths(config)
        assert len(errors) == 1
        assert "Missing URI" in errors[0]

    def test_http_uri_no_error(self):
        """HTTP URIs should not be validated as local paths."""
        config = {
            "sources": [
                {
                    "type": "SmartLayerTileService",
                    "uri": "https://api.nds.live/test",
                    "mapId": "HTTP",
                }
            ]
        }
        errors = validate_paths(config)
        assert errors == []


class TestWriteConfigToTemp:
    """Tests for write_config_to_temp()."""

    def test_creates_temp_directory(self):
        """Creates temp directory with config file."""
        config = {"sources": [{"type": "test"}]}
        temp_dir = write_config_to_temp(config)

        try:
            assert temp_dir.exists()
            assert temp_dir.is_dir()
            config_file = temp_dir / "mapviewer.yaml"
            assert config_file.exists()

            with open(config_file) as f:
                loaded = yaml.safe_load(f)
            assert loaded == config
        finally:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_uses_nds_temp_dir(self):
        """Temp directory is under ~/.nds/tmp/."""
        config = {"sources": []}
        temp_dir = write_config_to_temp(config)

        try:
            expected_base = Path.home() / ".nds" / "tmp"
            assert expected_base in temp_dir.parents or temp_dir.parent == expected_base
        finally:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)


class TestDetectDirectoryType:
    """Tests for detect_directory_type()."""

    def test_geojson_detection(self, temp_dir):
        """Directory with .geojson files is detected as geojson."""
        (temp_dir / "layer.geojson").touch()
        assert detect_directory_type(temp_dir) == "geojson"

    def test_classic_detection(self, temp_dir):
        """Directory with ROOT.NDS is detected as classic."""
        (temp_dir / "ROOT.NDS").touch()
        assert detect_directory_type(temp_dir) == "classic"

    def test_default_folder(self, temp_dir):
        """Directory without markers defaults to folder."""
        assert detect_directory_type(temp_dir) == "folder"

    def test_geojson_takes_priority(self, temp_dir):
        """GeoJSON detection takes priority over classic."""
        (temp_dir / "layer.geojson").touch()
        (temp_dir / "ROOT.NDS").touch()
        assert detect_directory_type(temp_dir) == "geojson"


class TestCreateGeojsonConfig:
    """Tests for create_geojson_config()."""

    def test_structure(self, temp_dir):
        """Config has correct source type and folder, no mapId."""
        config = create_geojson_config(temp_dir)
        assert len(config["sources"]) == 1
        src = config["sources"][0]
        assert src["type"] == "GeoJsonFolder"
        assert src["folder"] == str(temp_dir)
        assert "mapId" not in src


class TestCreateClassicConfig:
    """Tests for create_classic_config()."""

    def test_structure(self, temp_dir):
        """Config has correct source type and folder."""
        config = create_classic_config(temp_dir)
        assert len(config["sources"]) == 1
        src = config["sources"][0]
        assert src["type"] == "ClassicFolder"
        assert src["folder"] == str(temp_dir)

    def test_mapid_from_folder_name(self, temp_dir):
        """mapId is derived from directory name."""
        config = create_classic_config(temp_dir)
        assert config["sources"][0]["mapId"] == temp_dir.name

    def test_custom_map_id(self, temp_dir):
        """Custom mapId overrides the default."""
        config = create_classic_config(temp_dir, map_id="CustomClassic")
        assert config["sources"][0]["mapId"] == "CustomClassic"


class TestCreateFolderConfig:
    """Tests for create_folder_config() custom mapId."""

    def test_custom_map_id(self, temp_dir):
        """Custom mapId overrides the default."""
        config = create_folder_config(temp_dir, map_id="CustomFolder")
        assert config["sources"][0]["mapId"] == "CustomFolder"


class TestCreateFilestoreConfig:
    """Tests for create_filestore_config() custom mapId."""

    def test_custom_map_id(self, temp_dir):
        """Custom mapId overrides the default."""
        store = temp_dir / "data.ndslive"
        store.touch()
        config = create_filestore_config(store, map_id="CustomStore")
        assert config["sources"][0]["mapId"] == "CustomStore"


class TestResolveConfigSourceDetection:
    """Tests for resolve_config_source() directory type detection."""

    def test_geojson_dir_resolves_as_local_geojson(self, temp_dir):
        """Directory with .geojson files resolves as local_geojson."""
        (temp_dir / "layer.geojson").touch()
        result = resolve_config_source(str(temp_dir))
        assert result is not None
        assert result.source_type == "local_geojson"

    def test_classic_dir_resolves_as_local_classic(self, temp_dir):
        """Directory with ROOT.NDS resolves as local_classic."""
        (temp_dir / "ROOT.NDS").touch()
        result = resolve_config_source(str(temp_dir))
        assert result is not None
        assert result.source_type == "local_classic"

    def test_plain_dir_resolves_as_local_folder(self, temp_dir):
        """Plain directory resolves as local_folder."""
        result = resolve_config_source(str(temp_dir))
        assert result is not None
        assert result.source_type == "local_folder"


class TestCreateServiceConfig:
    """Tests for create_service_config()."""

    def test_no_auth(self):
        """Config with no auth has no http-settings."""
        config = create_service_config("https://api.example.com/openapi.json")
        assert len(config["sources"]) == 1
        assert config["sources"][0]["type"] == "SmartLayerTileService"
        assert config["sources"][0]["uri"] == "https://api.example.com/openapi.json"
        assert "http-settings" not in config

    def test_api_key_auth(self):
        """API key auth populates http-settings with api-key."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="apiKey", api_key="secret123",
        )
        settings = config["http-settings"][0]
        assert settings["scope"] == "https://api.example.com/*"
        assert settings["api-key"] == "secret123"

    def test_query_param_auth(self):
        """Query param auth populates http-settings with query dict."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="queryParam",
            query_params=[{"key": "token", "value": "abc"}],
        )
        settings = config["http-settings"][0]
        assert settings["query"] == {"token": "abc"}

    def test_basic_auth(self):
        """Basic auth populates http-settings with basic-auth."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="basic", basic_user="user", basic_password="pass",
        )
        settings = config["http-settings"][0]
        assert settings["basic-auth"] == {"user": "user", "password": "pass"}

    def test_basic_auth_without_password(self):
        """Basic auth without password omits password field."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="basic", basic_user="user",
        )
        settings = config["http-settings"][0]
        assert settings["basic-auth"] == {"user": "user"}

    def test_bearer_auth(self):
        """Bearer auth populates http-settings with Authorization header."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="bearer", bearer_token="tok123",
        )
        settings = config["http-settings"][0]
        assert settings["headers"]["Authorization"] == "Bearer tok123"

    def test_oauth2_auth(self):
        """OAuth2 auth populates http-settings with oauth2 config."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="oauth2",
            oauth2_client_id="cid",
            oauth2_client_secret="csecret",
            oauth2_token_url="https://auth.example.com/token",
            oauth2_audience="aud",
            oauth2_scope="read write",
        )
        settings = config["http-settings"][0]
        oauth2 = settings["oauth2"]
        assert oauth2["clientId"] == "cid"
        assert oauth2["clientSecret"] == "csecret"
        assert oauth2["tokenUrl"] == "https://auth.example.com/token"
        assert oauth2["audience"] == "aud"
        assert oauth2["scope"] == ["read", "write"]

    def test_proxy_settings(self):
        """Proxy settings are added to http-settings."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            proxy_host="proxy.corp.com", proxy_port=8080,
            proxy_user="puser", proxy_password="ppass",
        )
        settings = config["http-settings"][0]
        proxy = settings["proxy"]
        assert proxy["host"] == "proxy.corp.com"
        assert proxy["port"] == 8080
        assert proxy["user"] == "puser"
        assert proxy["password"] == "ppass"

    def test_auth_with_proxy(self):
        """Auth and proxy can be combined."""
        config = create_service_config(
            "https://api.example.com/openapi.json",
            auth_method="apiKey", api_key="key",
            proxy_host="proxy.corp.com",
        )
        settings = config["http-settings"][0]
        assert settings["api-key"] == "key"
        assert settings["proxy"]["host"] == "proxy.corp.com"

    def test_mapid_derived_from_host(self):
        """mapId is derived from the URL host with dots replaced."""
        config = create_service_config("https://api.nds.live/openapi.json")
        assert config["sources"][0]["mapId"] == "api-nds-live"


class TestSaveAndListConfigs:
    """Tests for save_config() and list_saved_configs()."""

    def test_save_and_load_roundtrip(self, monkeypatch, temp_dir):
        """Saved config can be loaded back."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        original = {"sources": [{"type": "test", "mapId": "roundtrip"}]}
        path = save_config(original, "myconfig")

        assert path.exists()
        loaded = load_config(path)
        assert loaded == original

    def test_list_saved_configs(self, monkeypatch, temp_dir):
        """list_saved_configs returns saved config names sorted."""
        import ndslive.mapviewer.config as config_mod
        configs_dir = temp_dir / "configs"
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", configs_dir)

        save_config({"sources": []}, "beta")
        save_config({"sources": []}, "alpha")

        names = list_saved_configs()
        assert names == ["alpha", "beta"]

    def test_list_empty(self, monkeypatch, temp_dir):
        """list_saved_configs returns empty list when no configs exist."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "empty")
        assert list_saved_configs() == []

    def test_save_config_restrictive_permissions(self, monkeypatch, temp_dir):
        """Saved config files have 0o600 permissions."""
        import stat
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        path = save_config({"sources": []}, "secret")
        mode = stat.S_IMODE(path.stat().st_mode)
        assert mode == 0o600

    def test_save_config_rejects_path_traversal(self, monkeypatch, temp_dir):
        """save_config rejects names with path traversal characters."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        with pytest.raises(ConfigError):
            save_config({"sources": []}, "../escape")
        with pytest.raises(ConfigError):
            save_config({"sources": []}, "sub/dir")
        with pytest.raises(ConfigError):
            save_config({"sources": []}, "back\\slash")


class TestDeleteConfig:
    """Tests for delete_config()."""

    def test_delete_existing(self, monkeypatch, temp_dir):
        """Deleting an existing config removes the file and returns True."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        path = save_config({"sources": []}, "to-delete")
        assert path.exists()

        result = delete_config("to-delete")
        assert result is True
        assert not path.exists()

    def test_delete_nonexistent(self, monkeypatch, temp_dir):
        """Deleting a nonexistent config returns False."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")
        (temp_dir / "configs").mkdir(parents=True, exist_ok=True)

        result = delete_config("no-such-config")
        assert result is False

    def test_delete_rejects_path_traversal(self, monkeypatch, temp_dir):
        """delete_config rejects names with path traversal characters."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        with pytest.raises(ConfigError):
            delete_config("../escape")
        with pytest.raises(ConfigError):
            delete_config("sub/dir")

    def test_delete_then_list(self, monkeypatch, temp_dir):
        """Deleted config no longer appears in list_saved_configs()."""
        import ndslive.mapviewer.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIGS_DIR", temp_dir / "configs")

        save_config({"sources": []}, "alpha")
        save_config({"sources": []}, "beta")
        assert "alpha" in list_saved_configs()

        delete_config("alpha")
        names = list_saved_configs()
        assert "alpha" not in names
        assert "beta" in names
