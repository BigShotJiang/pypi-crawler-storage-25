# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Default Docker image version pinned to package (`--image-version` defaults to
  matching calver instead of `"latest"`)
- SCM-based versioning — package version derived from MapViewer git tags

### Fixed

- Container readiness check uses log sentinel before HTTP polling to avoid
  startup crash (mapget#151)

### Changed

- Version scheme: package now follows MapViewer calver (e.g. 2025.6.2)
  with post-release dev builds between releases

## [0.1.0] - Unreleased

### Added

- **CLI Commands**
  - `setup` - Interactive setup wizard for Docker, registry auth, and image download
  - `run` - Run MapViewer with a local path, saved config, or `--demo` mode
  - `connect` - Interactive connection picker / wizard for saved or new data sources
  - `update` - Check for and pull newer MapViewer Docker images
  - Shorthand: `mapviewer <path>` resolves `.ndslive` files, SmartLayer folders, or saved config names

- **Python API**
  - `MapViewer` class for programmatic container lifecycle management
  - Context manager support for automatic cleanup
  - `start()` / `stop()` / `restart()` for container control
  - `connect()` class method to attach to a running container by name
  - `logs()` with real-time streaming and severity filtering
  - `status()` and `get_datasources()` for runtime introspection
  - `open_browser()` to launch the viewer in a system or bundled browser

- **Configuration**
  - Automatic path transformation (host paths to container mount points)
  - Volume mount generation with read-only mounts and parent-directory deduplication
  - Localhost translation to `host.docker.internal`
  - YAML config creation helpers for filestores, SmartLayer folders, and remote services
  - Saved connections stored under `~/.nds/configs/`
  - Default config at `~/.nds/config.yaml` — shared across NDS tools, auto-loaded when no args given

- **Authentication**
  - Six methods: API key, query parameters, basic auth, bearer token, OAuth2 client credentials, and none
  - Optional proxy support with authentication

- **Browser Integration**
  - Multi-platform system browser detection (Chrome, Chromium, Edge, Brave)
  - Optional bundled Chromium via Playwright (`[browser]` extra)
  - Automatic browser launch on `run` and `connect`

- **Setup & Diagnostics**
  - Interactive setup wizard with Docker daemon and registry checks
  - Image pull with progress display
  - `--dry` mode for walkthroughs without Docker access
  - Edition selection (community / member)
