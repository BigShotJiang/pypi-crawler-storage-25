"""NDS MapViewer — Textual TUI application."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widget import Widget
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import (
    Button,
    Checkbox,
    Footer,
    Header,
    Input,
    ListItem,
    ListView,
    RadioButton,
    RadioSet,
    RichLog,
    Rule,
    Static,
)
from textual import work

from . import __default_image__ as _default_image
from . import docker_client
from .config import (
    CONFIGS_DIR,
    DEFAULT_CONFIG,
    create_classic_config,
    create_filestore_config,
    create_folder_config,
    create_geojson_config,
    create_service_config,
    delete_config,
    detect_directory_type,
    get_demo_config,
    list_saved_configs,
    load_config,
    save_config,
    write_config_to_temp,
)
from .exceptions import (
    ContainerNotFound,
    DockerNotInstalled,
    DockerNotRunning,
    MapViewerError,
)


# ---------------------------------------------------------------------------
# ASCII-art banner
# ---------------------------------------------------------------------------

NDS_HEADER = "[bold bright_cyan]" + "\n".join([
    r"  __  __          __     ___                     ",
    r" |  \/  |__ _ _ _\ \   / (_)_____ __ _____ _ _  ",
    r" | |\/| / _` | '_ \ \ / /| / -_) V  V / -_| '_| ",
    r" |_|  |_\__,_| .__/\_/ |_\___|\_/\_/\___|_|  ",
    r"             |_|                                  ",
]) + "[/bold bright_cyan]"


# ---------------------------------------------------------------------------
# Shared state
# ---------------------------------------------------------------------------

@dataclass
class TuiState:
    """Shared state across all screens."""

    edition: str = "community"
    version: str = _default_image
    no_browser: bool = False
    port: int = 0
    bind_address: str = "127.0.0.1"
    pull_policy: str = "prompt"
    docker_available: bool = False
    docker_error: str = ""


# ---------------------------------------------------------------------------
# Reusable config-list + YAML-preview widget
# ---------------------------------------------------------------------------

class ConfigListWithPreview(Widget):
    """Config names list with a YAML preview of the highlighted item."""

    DEFAULT_CSS = """
    ConfigListWithPreview {
        height: auto;
    }

    ConfigListWithPreview ListView {
        height: auto;
        max-height: 8;
    }

    ConfigListWithPreview .cfg-preview {
        margin-top: 1;
        background: $panel;
        padding: 1;
        max-height: 14;
        height: auto;
    }
    """

    def compose(self) -> ComposeResult:
        yield ListView(id="_cfg-lv")
        yield Static("", classes="cfg-preview")

    def refresh_configs(
        self, configs: list[str], current: str | None = None,
    ) -> None:
        """Populate the list with config names.

        Args:
            configs: Sorted config names.
            current: Currently active config (highlighted with a marker).
        """
        lv = self.query_one("#_cfg-lv", ListView)
        lv.clear()
        self.query_one(".cfg-preview", Static).update("")

        if not configs:
            lv.append(ListItem(Static("[dim]No saved configs[/dim]")))
            return

        for name in configs:
            marker = "[green]>[/green]" if name == current else " "
            lv.append(ListItem(Static(f"{marker} {name}"), name=name))

    @property
    def highlighted_name(self) -> str | None:
        """Name of the currently highlighted config, or ``None``."""
        item = self.query_one("#_cfg-lv", ListView).highlighted_child
        if item is None or item.name is None:
            return None
        return item.name

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        import yaml

        preview = self.query_one(".cfg-preview", Static)
        if event.item is None or event.item.name is None:
            preview.update("")
            return
        config_path = CONFIGS_DIR / f"{event.item.name}.yaml"
        try:
            config = load_config(config_path)
            text = yaml.dump(config, default_flow_style=False, sort_keys=False)
            preview.update(text)
        except Exception:
            preview.update("[dim]Could not load config[/dim]")


# ---------------------------------------------------------------------------
# HomeScreen
# ---------------------------------------------------------------------------

class HomeScreen(Screen):
    """Dashboard with running instances and quick actions."""

    BINDINGS = [
        Binding("n", "new_config", "New Config"),
        Binding("x", "delete_config", "Delete Config"),
        Binding("r", "refresh", "Refresh"),
        Binding("question_mark", "show_help", "Help"),
    ]

    CSS = """
    #home-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #instances-header, #configs-header {
        text-style: bold;
        margin-top: 1;
    }

    #instances-list {
        height: auto;
        max-height: 12;
        margin: 0 0 1 2;
    }

    #configs-list {
        margin: 0 0 1 2;
    }

    #docker-warning {
        margin: 1 0;
    }

    .home-buttons {
        margin-top: 1;
        height: auto;
    }

    .home-buttons Button {
        margin-right: 1;
    }

    #getting-started {
        margin: 1 2;
    }

    #network-access {
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static("NDS MapViewer", id="home-title")
            yield Rule()
            yield Static("Running Instances:", id="instances-header")
            yield Static("", id="docker-warning")
            yield ListView(id="instances-list")
            yield Static("Saved Configs:", id="configs-header")
            yield ConfigListWithPreview(id="configs-list")
            yield Static("", id="getting-started")
            with Horizontal(classes="home-buttons"):
                yield Button("New Config", variant="primary", id="new-config")
                yield Button("Demo", id="demo")
                yield Button("Refresh", id="refresh")
            yield Checkbox("Allow network access", id="network-access")
        yield Footer()

    def on_mount(self) -> None:
        state: TuiState = self.app.tui_state
        cb = self.query_one("#network-access", Checkbox)
        cb.value = state.bind_address == "0.0.0.0"
        self._load_data()

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        if event.checkbox.id == "network-access":
            state: TuiState = self.app.tui_state
            state.bind_address = "0.0.0.0" if event.value else "127.0.0.1"

    def action_refresh(self) -> None:
        self._load_data()

    @work(thread=True)
    def _load_data(self) -> None:
        state: TuiState = self.app.tui_state

        # Check Docker availability
        try:
            docker_client.get_docker_client()
            state.docker_available = True
            state.docker_error = ""
        except DockerNotInstalled:
            state.docker_available = False
            state.docker_error = "Docker is not installed"
        except DockerNotRunning:
            state.docker_available = False
            state.docker_error = "Docker daemon is not running"
        except Exception as e:
            state.docker_available = False
            state.docker_error = str(e)

        # Load instances
        instances: list[tuple[str, str, str]] = []
        if state.docker_available:
            try:
                from .viewer import MapViewer
                for container in docker_client.list_containers():
                    mv = MapViewer._from_container(container)
                    status = mv.status()
                    url = mv.url if status == "running" else ""
                    instances.append((mv.name, status, url))
            except Exception:
                pass

        # Load saved configs
        configs = list_saved_configs()

        self.app.call_from_thread(self._update_ui, instances, configs)

    def _update_ui(
        self,
        instances: list[tuple[str, str, str]],
        configs: list[str],
    ) -> None:
        state: TuiState = self.app.tui_state

        # Docker warning
        warning = self.query_one("#docker-warning", Static)
        if not state.docker_available:
            warning.update(
                f"[yellow]! {state.docker_error}[/yellow]\n"
                "[dim]Instance management unavailable. "
                "New Config still works for config creation.[/dim]"
            )
        else:
            warning.update("")

        # Instances list
        instances_lv = self.query_one("#instances-list", ListView)
        instances_lv.clear()
        if instances:
            for name, status, url in instances:
                if status == "running":
                    icon = "[green]+[/green]"
                    status_text = f"[green]{status}[/green]"
                elif status == "exited":
                    icon = "[yellow]![/yellow]"
                    status_text = f"[yellow]{status}[/yellow]"
                else:
                    icon = "[dim]-[/dim]"
                    status_text = f"[dim]{status}[/dim]"
                label = f"{icon} {name}   {status_text}"
                if url:
                    label += f"   [cyan]{url}[/cyan]"
                instances_lv.append(ListItem(Static(label), name=name))
        else:
            if state.docker_available:
                instances_lv.append(
                    ListItem(Static("[dim]No instances found[/dim]"))
                )

        # Configs list
        self.query_one(
            "#configs-list", ConfigListWithPreview,
        ).refresh_configs(configs)

        # Getting-started hint
        hint = self.query_one("#getting-started", Static)
        if not DEFAULT_CONFIG.exists():
            hint.update(
                "[dim]Tip: Create ~/.nds/config.yaml or press "
                "[bold]n[/bold] to set up a\n"
                "data source. The default config is used automatically "
                "when no source args\nare provided.[/dim]"
            )
        else:
            hint.update("")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "new-config":
            self.app.push_screen(WizardScreen())
        elif event.button.id == "demo":
            self._launch_demo()
        elif event.button.id == "refresh":
            self._load_data()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        lv = event.list_view
        item = event.item
        name = item.name

        if not name:
            return

        if lv.id == "instances-list":
            self.app.push_screen(RunScreen(connect_name=name))
        elif lv.id == "_cfg-lv":
            self.app.push_screen(RunScreen(saved_config=name))

    def _launch_demo(self) -> None:
        config = get_demo_config()
        self.app.push_screen(
            RunScreen(config=config, label="Demo (NDS Islands)", is_demo=True)
        )

    def action_new_config(self) -> None:
        self.app.push_screen(WizardScreen())

    def action_delete_config(self) -> None:
        name = self.query_one(
            "#configs-list", ConfigListWithPreview,
        ).highlighted_name
        if name is None:
            self.notify("No config selected", timeout=2)
            return

        def _on_dismiss(deleted: bool | None) -> None:
            if deleted:
                self._load_data()

        self.app.push_screen(ConfirmDeleteScreen(name), callback=_on_dismiss)

    def action_show_help(self) -> None:
        self.app.push_screen(HelpScreen())


# ---------------------------------------------------------------------------
# WizardScreen
# ---------------------------------------------------------------------------

WIZARD_STEPS = ["Source Type", "Source Details", "Auth", "Review & Save"]


class WizardScreen(Screen):
    """Step-based config wizard replacing the old Rich wizard."""

    CSS = """
    #wizard-layout {
        height: 1fr;
    }

    #wizard-sidebar {
        width: 24;
        background: $panel;
        padding: 1 1;
        border-right: thick $background;
    }

    #wizard-sidebar-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #wizard-content {
        padding: 1 3;
    }

    .step-title {
        text-style: bold;
        margin-bottom: 1;
    }

    .step-buttons {
        margin-top: 2;
        height: auto;
        align-horizontal: right;
    }

    .step-buttons Button {
        margin-left: 1;
    }

    #auth-fields {
        height: auto;
    }

    .field-label {
        margin-top: 1;
    }

    Input {
        margin: 0 0 1 0;
    }

    RadioSet {
        margin: 0 0 1 0;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._step = 0
        self._source_type = ""
        self._source_path = ""
        self._service_url = ""
        self._auth_method = "none"
        self._auth_data: dict[str, Any] = {}
        self._proxy_data: dict[str, Any] = {}
        self._config: dict[str, Any] | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="wizard-layout"):
            with Vertical(id="wizard-sidebar"):
                yield Static("[bold]Config Wizard[/bold]", id="wizard-sidebar-title")
                yield Rule()
                for i, label in enumerate(WIZARD_STEPS):
                    yield Static(
                        f"[dim]  {label}[/dim]",
                        id=f"wiz-ind-{i}",
                    )
            with VerticalScroll(id="wizard-content"):
                pass
        yield Footer()

    def on_mount(self) -> None:
        self._show_step(0)

    def _update_indicators(self) -> None:
        for i, label in enumerate(WIZARD_STEPS):
            ind = self.query_one(f"#wiz-ind-{i}", Static)
            if i < self._step:
                ind.update(f"[green]+ {label}[/green]")
            elif i == self._step:
                ind.update(f"[bold]> {label}[/bold]")
            else:
                ind.update(f"[dim]  {label}[/dim]")

    def _show_step(self, index: int) -> None:
        self._step = index
        self._update_indicators()
        content = self.query_one("#wizard-content", VerticalScroll)
        content.remove_children()

        if index == 0:
            self._compose_source_type(content)
        elif index == 1:
            self._compose_source_details(content)
        elif index == 2:
            self._compose_auth(content)
        elif index == 3:
            self._compose_review(content)

        content.scroll_home(animate=False)

    # -- Step 0: Source Type --

    def _compose_source_type(self, container: VerticalScroll) -> None:
        container.mount(Static("What would you like to view?", classes="step-title"))
        container.mount(RadioSet(
            RadioButton("Local file (.ndslive filestore)", value=True),
            RadioButton("Local folder (SmartLayer)"),
            RadioButton("Local folder (GeoJSON)"),
            RadioButton("Local folder (NDS Classic)"),
            RadioButton("Remote service (with optional auth)"),
            RadioButton("Demo (NDS Islands)"),
            id="source-type-radio",
        ))
        container.mount(Horizontal(
            Button("Cancel", id="wizard-cancel"),
            Button("Continue", variant="primary", id="wiz-next"),
            classes="step-buttons",
        ))

    # -- Step 1: Source Details --

    def _compose_source_details(self, container: VerticalScroll) -> None:
        if self._source_type == "filestore":
            container.mount(Static("Path to .ndslive file", classes="step-title"))
            container.mount(Input(placeholder="/path/to/data.ndslive", id="source-path"))
        elif self._source_type == "folder":
            container.mount(Static("Path to SmartLayer folder", classes="step-title"))
            container.mount(Input(placeholder="/path/to/folder", id="source-path"))
        elif self._source_type == "geojson":
            container.mount(Static("Path to GeoJSON folder", classes="step-title"))
            container.mount(Static(
                "[dim]Folder must contain .geojson files[/dim]",
            ))
            container.mount(Input(placeholder="/path/to/geojson/folder", id="source-path"))
        elif self._source_type == "classic":
            container.mount(Static("Path to NDS Classic folder", classes="step-title"))
            container.mount(Static(
                "[dim]Folder must contain a ROOT.NDS file[/dim]",
            ))
            container.mount(Input(placeholder="/path/to/classic/folder", id="source-path"))
        elif self._source_type == "service":
            container.mount(Static("Service URL", classes="step-title"))
            container.mount(Input(
                placeholder="https://api.example.com/openapi.json",
                id="service-url",
            ))
        container.mount(Static("", id="source-error"))
        container.mount(Horizontal(
            Button("Back", id="wiz-back"),
            Button("Continue", variant="primary", id="wiz-next"),
            classes="step-buttons",
        ))

    # -- Step 2: Auth --

    def _compose_auth(self, container: VerticalScroll) -> None:
        container.mount(Static("Authentication Method", classes="step-title"))
        container.mount(RadioSet(
            RadioButton("None", value=True),
            RadioButton("API Key (Header)"),
            RadioButton("Query Parameters"),
            RadioButton("Basic Auth (user/password)"),
            RadioButton("Bearer Token"),
            RadioButton("OAuth2 (Client Credentials)"),
            id="auth-radio",
        ))
        container.mount(Vertical(id="auth-fields"))

        # Proxy settings (for service type)
        container.mount(Rule())
        container.mount(Static("Proxy Settings (optional)", classes="field-label"))
        container.mount(Static("Proxy Host:", classes="field-label"))
        container.mount(Input(placeholder="proxy.example.com", id="proxy-host"))
        container.mount(Static("Proxy Port:", classes="field-label"))
        container.mount(Input(placeholder="8080", id="proxy-port"))
        container.mount(Static("Proxy Username:", classes="field-label"))
        container.mount(Input(placeholder="(optional)", id="proxy-user"))
        container.mount(Static("Proxy Password:", classes="field-label"))
        container.mount(Input(placeholder="(optional)", password=True, id="proxy-pass"))

        container.mount(Horizontal(
            Button("Back", id="wiz-back"),
            Button("Continue", variant="primary", id="wiz-next"),
            classes="step-buttons",
        ))

    def _on_auth_changed(self, index: int) -> None:
        methods = ["none", "apiKey", "queryParam", "basic", "bearer", "oauth2"]
        self._auth_method = methods[index]
        fields = self.query_one("#auth-fields", Vertical)
        fields.remove_children()

        if self._auth_method == "apiKey":
            fields.mount(Static("API Key:", classes="field-label"))
            fields.mount(Input(placeholder="API Key", id="auth-api-key"))
        elif self._auth_method == "queryParam":
            fields.mount(Static("Query parameter key:", classes="field-label"))
            fields.mount(Input(placeholder="key", id="auth-qp-key"))
            fields.mount(Static("Query parameter value:", classes="field-label"))
            fields.mount(Input(placeholder="value", id="auth-qp-value"))
        elif self._auth_method == "basic":
            fields.mount(Static("Username:", classes="field-label"))
            fields.mount(Input(placeholder="Username", id="auth-basic-user"))
            fields.mount(Static("Password:", classes="field-label"))
            fields.mount(Input(placeholder="Password", password=True, id="auth-basic-pass"))
        elif self._auth_method == "bearer":
            fields.mount(Static("Bearer Token:", classes="field-label"))
            fields.mount(Input(placeholder="Token", id="auth-bearer-token"))
        elif self._auth_method == "oauth2":
            fields.mount(Static("Client ID:", classes="field-label"))
            fields.mount(Input(placeholder="Client ID", id="auth-oauth-id"))
            fields.mount(Static("Client Secret:", classes="field-label"))
            fields.mount(Input(placeholder="Client Secret", password=True, id="auth-oauth-secret"))
            fields.mount(Static("Token URL:", classes="field-label"))
            fields.mount(Input(placeholder="https://auth.example.com/token", id="auth-oauth-url"))
            fields.mount(Static("Audience:", classes="field-label"))
            fields.mount(Input(placeholder="(optional)", id="auth-oauth-audience"))
            fields.mount(Static("Scopes (space-separated):", classes="field-label"))
            fields.mount(Input(placeholder="(optional)", id="auth-oauth-scope"))

    # -- Step 3: Review & Save --

    def _compose_review(self, container: VerticalScroll) -> None:
        container.mount(Static("Review Configuration", classes="step-title"))

        # Build config
        self._build_config()

        if self._config:
            import yaml
            yaml_str = yaml.dump(self._config, default_flow_style=False, sort_keys=False)
            lines = yaml_str.rstrip()
            container.mount(Static(f"[dim]{lines}[/dim]", id="config-preview"))
        else:
            container.mount(Static("[red]Failed to build config[/red]"))

        container.mount(Rule())
        container.mount(Static("Config name:", classes="field-label"))
        container.mount(Input(
            placeholder="Config name (required)",
            id="save-name",
        ))
        container.mount(Static("", id="save-status"))
        container.mount(Horizontal(
            Button("Back", id="wiz-back"),
            Button("Save", id="wiz-save"),
            Button("Save & Load", variant="primary", id="wiz-save-load"),
            classes="step-buttons",
        ))

    def _build_config(self) -> None:
        if self._source_type == "filestore":
            path = Path(self._source_path).expanduser().resolve()
            self._config = create_filestore_config(path)
        elif self._source_type == "folder":
            path = Path(self._source_path).expanduser().resolve()
            self._config = create_folder_config(path)
        elif self._source_type == "geojson":
            path = Path(self._source_path).expanduser().resolve()
            self._config = create_geojson_config(path)
        elif self._source_type == "classic":
            path = Path(self._source_path).expanduser().resolve()
            self._config = create_classic_config(path)
        elif self._source_type == "service":
            auth_kwargs = self._collect_auth_data()
            proxy_kwargs = self._collect_proxy_data()
            self._config = create_service_config(
                url=self._service_url,
                **auth_kwargs,
                **proxy_kwargs,
            )
        elif self._source_type == "demo":
            self._config = get_demo_config()

    def _collect_auth_data(self) -> dict[str, Any]:
        data: dict[str, Any] = {"auth_method": self._auth_method}
        ad = self._auth_data
        if self._auth_method == "apiKey":
            data["api_key"] = ad.get("api_key", "")
        elif self._auth_method == "queryParam":
            key = ad.get("qp_key", "")
            value = ad.get("qp_value", "")
            if key:
                data["query_params"] = [{"key": key, "value": value}]
        elif self._auth_method == "basic":
            data["basic_user"] = ad.get("basic_user", "")
            data["basic_password"] = ad.get("basic_pass", "")
        elif self._auth_method == "bearer":
            data["bearer_token"] = ad.get("bearer_token", "")
        elif self._auth_method == "oauth2":
            data["oauth2_client_id"] = ad.get("oauth_id", "")
            data["oauth2_client_secret"] = ad.get("oauth_secret", "")
            data["oauth2_token_url"] = ad.get("oauth_url", "")
            data["oauth2_audience"] = ad.get("oauth_audience", "")
            data["oauth2_scope"] = ad.get("oauth_scope", "")
        return data

    def _collect_proxy_data(self) -> dict[str, Any]:
        pd = self._proxy_data
        data: dict[str, Any] = {}
        host = pd.get("host", "")
        if host:
            data["proxy_host"] = host
            port_str = pd.get("port", "")
            if port_str:
                try:
                    data["proxy_port"] = int(port_str)
                except ValueError:
                    pass
            user = pd.get("user", "")
            if user:
                data["proxy_user"] = user
            password = pd.get("password", "")
            if password:
                data["proxy_password"] = password
        return data

    # -- Navigation & Events --

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id == "source-type-radio":
            pass  # selection stored on next
        elif event.radio_set.id == "auth-radio":
            self._on_auth_changed(event.index)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id
        if btn_id == "wizard-cancel":
            self.app.pop_screen()
        elif btn_id == "wiz-back":
            self._go_back()
        elif btn_id == "wiz-next":
            self._go_next()
        elif btn_id == "wiz-save":
            self._save_config(load_after=False)
        elif btn_id == "wiz-save-load":
            self._save_config(load_after=True)

    def _go_back(self) -> None:
        if self._step == 1:
            self._show_step(0)
        elif self._step == 2:
            self._show_step(1)
        elif self._step == 3:
            if self._source_type == "service":
                self._show_step(2)
            else:
                self._show_step(1)

    def _go_next(self) -> None:
        if self._step == 0:
            self._read_source_type()
            if self._source_type == "demo":
                self._config = get_demo_config()
                self._show_step(3)
            else:
                self._show_step(1)
        elif self._step == 1:
            if not self._validate_source_details():
                return
            if self._source_type == "service":
                self._show_step(2)
            else:
                self._show_step(3)
        elif self._step == 2:
            self._read_auth_fields()
            self._read_proxy_fields()
            self._show_step(3)

    def _read_source_type(self) -> None:
        rs = self.query_one("#source-type-radio", RadioSet)
        index = rs.pressed_index
        types = ["filestore", "folder", "geojson", "classic", "service", "demo"]
        self._source_type = types[index] if index >= 0 else "filestore"

    def _validate_source_details(self) -> bool:
        error_widget = self.query_one("#source-error", Static)
        if self._source_type in ("filestore", "folder", "geojson", "classic"):
            inp = self.query_one("#source-path", Input)
            path_str = inp.value.strip()
            if not path_str:
                error_widget.update("[red]Path is required[/red]")
                return False
            path = Path(path_str).expanduser().resolve()
            if not path.exists():
                error_widget.update(f"[red]Path not found: {path}[/red]")
                return False
            if self._source_type == "filestore" and path.suffix != ".ndslive":
                error_widget.update("[red]File must have .ndslive extension[/red]")
                return False
            if self._source_type == "folder" and not path.is_dir():
                error_widget.update("[red]Must be a directory[/red]")
                return False
            if self._source_type == "geojson":
                if not path.is_dir():
                    error_widget.update("[red]Must be a directory[/red]")
                    return False
                if not any(path.glob("*.geojson")):
                    error_widget.update("[red]No .geojson files found in directory[/red]")
                    return False
            if self._source_type == "classic":
                if not path.is_dir():
                    error_widget.update("[red]Must be a directory[/red]")
                    return False
                if not (path / "ROOT.NDS").exists():
                    error_widget.update("[red]ROOT.NDS not found in directory[/red]")
                    return False
            self._source_path = path_str
            error_widget.update("")
            return True
        elif self._source_type == "service":
            inp = self.query_one("#service-url", Input)
            url = inp.value.strip()
            if not url:
                error_widget.update("[red]URL is required[/red]")
                return False
            if not url.startswith(("http://", "https://")):
                url = f"https://{url}"
                inp.value = url
            self._service_url = url
            error_widget.update("")
            return True
        return True

    def _read_auth_fields(self) -> None:
        data: dict[str, str] = {}
        try:
            if self._auth_method == "apiKey":
                data["api_key"] = self.query_one("#auth-api-key", Input).value.strip()
            elif self._auth_method == "queryParam":
                data["qp_key"] = self.query_one("#auth-qp-key", Input).value.strip()
                data["qp_value"] = self.query_one("#auth-qp-value", Input).value.strip()
            elif self._auth_method == "basic":
                data["basic_user"] = self.query_one("#auth-basic-user", Input).value.strip()
                data["basic_pass"] = self.query_one("#auth-basic-pass", Input).value.strip()
            elif self._auth_method == "bearer":
                data["bearer_token"] = self.query_one("#auth-bearer-token", Input).value.strip()
            elif self._auth_method == "oauth2":
                data["oauth_id"] = self.query_one("#auth-oauth-id", Input).value.strip()
                data["oauth_secret"] = self.query_one("#auth-oauth-secret", Input).value.strip()
                data["oauth_url"] = self.query_one("#auth-oauth-url", Input).value.strip()
                data["oauth_audience"] = self.query_one("#auth-oauth-audience", Input).value.strip()
                data["oauth_scope"] = self.query_one("#auth-oauth-scope", Input).value.strip()
        except Exception:
            pass
        self._auth_data = data

    def _read_proxy_fields(self) -> None:
        data: dict[str, str] = {}
        try:
            data["host"] = self.query_one("#proxy-host", Input).value.strip()
            data["port"] = self.query_one("#proxy-port", Input).value.strip()
            data["user"] = self.query_one("#proxy-user", Input).value.strip()
            data["password"] = self.query_one("#proxy-pass", Input).value.strip()
        except Exception:
            pass
        self._proxy_data = data

    def _save_config(self, load_after: bool) -> None:
        if not self._config:
            return

        status = self.query_one("#save-status", Static)
        name_input = self.query_one("#save-name", Input)
        name = name_input.value.strip()

        if not name:
            status.update("[red]Config name is required[/red]")
            name_input.focus()
            return

        if not all(c.isalnum() or c in "-_" for c in name):
            status.update("[red]Only letters, digits, hyphens, underscores allowed[/red]")
            name_input.focus()
            return

        try:
            save_config(self._config, name)
        except Exception as e:
            status.update(f"[red]Save failed: {e}[/red]")
            return

        if not load_after:
            status.update(f"[green]Saved as '{name}'[/green]")
            self.notify(f"Config '{name}' saved", timeout=2)
            self.app.pop_screen()
            return

        label = self._source_type
        is_demo = False
        if self._source_type == "filestore":
            label = f"filestore: {Path(self._source_path).name}"
        elif self._source_type == "folder":
            label = f"folder: {Path(self._source_path).name}"
        elif self._source_type == "geojson":
            label = f"geojson: {Path(self._source_path).name}"
        elif self._source_type == "classic":
            label = f"classic: {Path(self._source_path).name}"
        elif self._source_type == "service":
            label = f"service: {self._service_url}"
        elif self._source_type == "demo":
            label = "Demo (NDS Islands)"
            is_demo = True

        self.app.switch_screen(
            RunScreen(
                config=self._config,
                label=label,
                saved_config=name,
                is_demo=is_demo,
            )
        )


# ---------------------------------------------------------------------------
# ConfirmPullScreen
# ---------------------------------------------------------------------------

class ConfirmPullScreen(Screen):
    """Modal asking the user whether to pull an image update."""

    BINDINGS = [
        Binding("y", "confirm", "Yes"),
        Binding("n", "decline", "No"),
        Binding("escape", "decline", "No"),
    ]

    CSS = """
    #pull-title {
        text-style: bold;
        margin: 1 2;
    }

    .pull-actions {
        margin: 1 2;
        height: auto;
    }

    .pull-actions Button {
        margin-right: 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            yield Static(
                "[bold]A newer MapViewer image is available.[/bold]\n"
                "Do you want to pull the update?",
                id="pull-title",
            )
            with Horizontal(classes="pull-actions"):
                yield Button("Yes, pull update", variant="primary", id="pull-yes")
                yield Button("No, use cached", id="pull-no")
        yield Footer()

    def action_confirm(self) -> None:
        self.dismiss(True)

    def action_decline(self) -> None:
        self.dismiss(False)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "pull-yes":
            self.dismiss(True)
        elif event.button.id == "pull-no":
            self.dismiss(False)


# ---------------------------------------------------------------------------
# RunScreen
# ---------------------------------------------------------------------------

LOG_FILTERS = [
    ("all", lambda buf, abuf: list(buf)),
    ("warnings + errors", lambda buf, abuf: list(abuf)),
    ("errors only", lambda buf, abuf: [l for l in abuf if "[error]" in l.lower()]),
]


class RunScreen(Screen):
    """Live container view with full-width logs and keyboard-driven controls."""

    BINDINGS = [
        Binding("o", "open_browser", "Browser"),
        Binding("f", "cycle_filter", "Filter: all"),
        Binding("c", "switch_config", "Config"),
        Binding("d", "open_docker", "Docker"),
        Binding("i", "open_image_picker", "Image"),
        Binding("question_mark", "show_help", "Help"),
        Binding("q", "quit_and_stop", "Quit"),
    ]

    CSS = """
    #run-header {
        margin-bottom: 0;
    }

    #run-status {
        margin-bottom: 0;
    }

    #log-header {
        margin: 0;
        padding: 0 1;
    }

    #log-pane {
        border: round $primary;
    }

    #filter-status {
        height: 1;
        margin-top: 0;
    }
    """

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        label: str = "",
        connect_name: str | None = None,
        saved_config: str | None = None,
        exit_on_back: bool = False,
        is_demo: bool = False,
    ) -> None:
        super().__init__()
        self._config = config
        self._label = label
        self._connect_name = connect_name
        self._saved_config = saved_config
        self._exit_on_back = exit_on_back
        self._is_demo = is_demo
        self._mv = None
        self._running = False
        self._log_buffer: deque[str] = deque(maxlen=500)
        self._alert_buffer: deque[str] = deque(maxlen=200)
        self._filter_index = 0

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            yield Static(NDS_HEADER, id="run-header")
            yield Static("", id="run-status")
            yield Rule()
            yield Static(
                "[bold]MapViewer Logs[/bold]  "
                "[dim]press [bold]f[/bold] to filter[/dim]",
                id="log-header",
            )
            yield RichLog(
                id="log-pane",
                highlight=True,
                markup=True,
                max_lines=500,
                wrap=True,
            )
            yield Static("", id="filter-status")
        yield Footer()

    def on_mount(self) -> None:
        self._update_filter_status()
        if self._connect_name:
            self._connect_to_existing()
        elif self._saved_config:
            self._start_from_saved()
        elif self._config:
            self._start_container()

    # -- Log buffer & filtering --

    def _colorize(self, line: str) -> str:
        low = line.lower()
        if "[error]" in low:
            return f"[red]{line}[/red]"
        if "[warning]" in low:
            return f"[yellow]{line}[/yellow]"
        return f"[dim]{line}[/dim]"

    def _is_alert(self, line: str) -> bool:
        low = line.lower()
        return "[error]" in low or "[warning]" in low

    def _matches_filter(self, line: str) -> bool:
        if self._filter_index == 0:
            return True
        if self._filter_index == 1:
            return self._is_alert(line)
        return "[error]" in line.lower()

    def _append_log(self, line: str) -> None:
        self._log_buffer.append(line)
        if self._is_alert(line):
            self._alert_buffer.append(line)
        if self._matches_filter(line):
            try:
                self.query_one("#log-pane", RichLog).write(self._colorize(line))
            except Exception:
                pass
        self._update_filter_status()

    def _apply_filter(self) -> None:
        rl = self.query_one("#log-pane", RichLog)
        rl.clear()
        _, select_fn = LOG_FILTERS[self._filter_index]
        for line in select_fn(self._log_buffer, self._alert_buffer):
            rl.write(self._colorize(line))
        self._update_filter_status()

    def _update_filter_status(self) -> None:
        name, select_fn = LOG_FILTERS[self._filter_index]
        count = len(select_fn(self._log_buffer, self._alert_buffer))
        total = len(self._log_buffer)
        try:
            self.query_one("#filter-status", Static).update(
                f"[dim]Filter: {name} ({count}/{total} lines)[/dim]"
            )
        except Exception:
            pass

    def _log(self, text: str) -> None:
        self._append_log(text)

    def _set_header(self, status: str = "", url: str = "") -> None:
        from . import __version__
        state: TuiState = self.app.tui_state
        img_display = state.version
        resolved = getattr(self, "_resolved_image_ver", "")
        if resolved and resolved != img_display:
            img_display = f"{img_display} | {resolved}"
        elif resolved:
            img_display = resolved
        parts = [
            f"v{__version__}",
            f"image: {img_display}",
            state.edition,
        ]
        if status:
            parts.append(status)
        line = "[dim] | [/dim]".join(parts)
        if url:
            line += f"   [cyan]{url}[/cyan]"
        self.query_one("#run-status", Static).update(line)

    def _resolve_image_version(self) -> None:
        """Query image version from running container, update status line."""
        raw = docker_client.get_image_version()
        if raw:
            ver, commit = docker_client.parse_image_version(raw)
            if ver != "unknown":
                display = f"{ver} ({commit})" if commit != "unknown" else ver
                self._resolved_image_ver = display
                self.app.call_from_thread(
                    self._set_header,
                    "[green]running[/green]",
                    self._mv.url if self._mv else "",
                )

    # -- Keyboard actions --

    def action_open_browser(self) -> None:
        if self._mv and self._running:
            try:
                self._mv.open_browser()
            except Exception:
                pass

    def action_cycle_filter(self) -> None:
        self._filter_index = (self._filter_index + 1) % len(LOG_FILTERS)
        name, _ = LOG_FILTERS[self._filter_index]
        # Rebuild bindings map to update footer description
        self._bindings.key_to_bindings.clear()
        self._bindings.bind("o", "open_browser", "Browser")
        self._bindings.bind("f", "cycle_filter", f"Filter: {name}")
        self._bindings.bind("c", "switch_config", "Config")
        self._bindings.bind("d", "open_docker", "Docker")
        self._bindings.bind("i", "open_image_picker", "Image")
        self._bindings.bind("question_mark", "show_help", "Help")
        self._bindings.bind("q", "quit_and_stop", "Quit")
        self.refresh_bindings()
        self._apply_filter()

    def action_show_help(self) -> None:
        self.app.push_screen(HelpScreen())

    def action_quit_and_stop(self) -> None:
        self._show_quit_overlay()
        self._do_quit()

    def _show_quit_overlay(self) -> None:
        try:
            for widget in self.query("Vertical > *"):
                widget.display = False
            overlay = self.query_one("#run-header", Static)
            overlay.display = True
            overlay.update(
                "\n\n\n[bold]Quitting MapViewer ...[/bold]"
            )
            overlay.styles.text_align = "center"
            overlay.styles.content_align = ("center", "middle")
            overlay.styles.height = "100%"
        except Exception:
            pass

    @staticmethod
    def _format_bytes(n: int) -> str:
        for unit in ("B", "KB", "MB", "GB"):
            if abs(n) < 1024:
                return f"{n:.1f} {unit}" if unit != "B" else f"{n} {unit}"
            n /= 1024
        return f"{n:.1f} TB"

    def _show_pull_overlay(self, message: str = "Pulling MapViewer image...") -> None:
        try:
            self._pull_layer_status: dict[str, str] = {}
            self._pull_layer_bytes: dict[str, tuple[int, int]] = {}
            for widget in self.query("Vertical > *"):
                widget.display = False
            overlay = self.query_one("#run-header", Static)
            overlay.display = True
            overlay.update(
                f"\n\n\n[bold]{message}[/bold]"
                "\n\nThis may take a few minutes."
            )
            overlay.styles.text_align = "center"
            overlay.styles.content_align = ("center", "middle")
            overlay.styles.height = "100%"
        except Exception:
            pass

    def _hide_pull_overlay(self) -> None:
        try:
            for widget in self.query("Vertical > *"):
                widget.display = True
            overlay = self.query_one("#run-header", Static)
            overlay.update(NDS_HEADER)
            overlay.styles.text_align = "left"
            overlay.styles.content_align = ("left", "top")
            overlay.styles.height = "auto"
        except Exception:
            pass

    def _update_pull_progress(self, info: dict) -> None:
        try:
            layer_id = info.get("id", "")
            status = info.get("status", "")
            if layer_id and status:
                self._pull_layer_status[layer_id] = status

            detail = info.get("progressDetail", {})
            if layer_id and isinstance(detail, dict):
                current = detail.get("current", 0)
                layer_total = detail.get("total", 0)
                if current or layer_total:
                    self._pull_layer_bytes[layer_id] = (current, layer_total)

            total = len(self._pull_layer_status)
            done = sum(
                1 for s in self._pull_layer_status.values()
                if s in ("Pull complete", "Already exists")
            )
            downloading = sum(
                1 for s in self._pull_layer_status.values()
                if s == "Downloading"
            )

            lines = ["[bold]Pulling MapViewer image...[/bold]", ""]
            if total > 0:
                if downloading > 0:
                    lines.append(f"Downloading: {done}/{total} layers complete")
                else:
                    lines.append(f"Layers: {done}/{total} complete")

            if self._pull_layer_bytes:
                dl_current = sum(c for c, _ in self._pull_layer_bytes.values())
                dl_total = sum(t for _, t in self._pull_layer_bytes.values())
                if dl_total > 0:
                    lines.append(
                        f"Downloaded: {self._format_bytes(dl_current)}"
                        f" / {self._format_bytes(dl_total)}"
                    )

            lines.extend(["", "This may take a few minutes."])

            overlay = self.query_one("#run-header", Static)
            overlay.update("\n\n" + "\n".join(lines))
        except Exception:
            pass

    @work(thread=True)
    def _do_quit(self) -> None:
        if self._mv and self._running:
            try:
                self._mv.stop()
            except Exception:
                pass
            self._running = False
        self.app.call_from_thread(self.app.exit)

    def action_open_docker(self) -> None:
        if self._mv:
            self.app.push_screen(DockerScreen(self._mv))

    def action_open_image_picker(self) -> None:
        self.app.push_screen(
            ImagePickerScreen(), callback=self._on_image_picker_dismiss
        )

    def _on_image_picker_dismiss(self, apply: bool | None) -> None:
        if apply:
            self._restart_with_new_image()

    @work(thread=True, exclusive=True, group="container")
    def _restart_with_new_image(self) -> None:
        state: TuiState = self.app.tui_state
        self._resolved_image_ver = ""
        self.app.call_from_thread(
            self._log,
            f"Switching to {state.edition} {state.version}...",
        )
        self.app.call_from_thread(self._set_header, "restarting")

        # Stop existing
        if self._mv and self._running:
            try:
                self._mv.stop()
            except Exception:
                pass
            self._mv = None
            self._running = False

        # Re-use _do_start which reads edition/version from TuiState
        config_path = None
        if self._config and not self._is_demo:
            config_dir = write_config_to_temp(self._config)
            config_path = config_dir / "mapviewer.yaml"
        self._do_start(config_path=config_path)

    # -- Switch saved config --

    def action_switch_config(self) -> None:
        self.app.push_screen(
            ConfigManagerScreen(current_config=self._saved_config),
            callback=self._on_config_picker_dismiss,
        )

    def _on_config_picker_dismiss(self, config_name: str | None) -> None:
        if config_name == "__new__":
            self.app.push_screen(WizardScreen())
        elif config_name and config_name != self._saved_config:
            self._restart_with_new_config(config_name)

    @work(thread=True, exclusive=True, group="container")
    def _restart_with_new_config(self, config_name: str) -> None:
        self._resolved_image_ver = ""
        self.app.call_from_thread(
            self._log,
            f"Switching to config '{config_name}'...",
        )
        self.app.call_from_thread(self._set_header, "restarting")

        # Stop existing
        if self._mv and self._running:
            try:
                self._mv.stop()
            except Exception:
                pass
            self._mv = None
            self._running = False

        # Load and apply new config
        config_path = CONFIGS_DIR / f"{config_name}.yaml"
        try:
            self._config = load_config(config_path)
        except Exception as e:
            self.app.call_from_thread(self._log, f"Failed to load config: {e}")
            return
        self._saved_config = config_name
        self._label = f"saved: {config_name}"
        self._is_demo = False
        self._do_start(config_path=config_path)

    # -- Connect to existing container --

    @work(thread=True, exclusive=True, group="container")
    def _connect_to_existing(self) -> None:
        self.app.call_from_thread(self._log, "Connecting to container...")
        try:
            from .viewer import MapViewer
            mv = MapViewer.connect(self._connect_name)
            self._mv = mv
            status = mv.status()
            self.app.call_from_thread(
                self._set_header,
                status,
                mv.url if status == "running" else "",
            )
            self._running = status == "running"
            if self._running:
                self.app.call_from_thread(
                    self._log, f"Connected to {mv.name}"
                )
                self._resolve_image_version()
                self._stream_logs(mv)
            else:
                self.app.call_from_thread(
                    self._log,
                    f"Container '{mv.name}' is {status}",
                )
        except MapViewerError as e:
            self.app.call_from_thread(self._log, str(e))

    # -- Start from saved config --

    @work(thread=True, exclusive=True, group="container")
    def _start_from_saved(self) -> None:
        self.app.call_from_thread(
            self._log, f"Loading config '{self._saved_config}'..."
        )
        config_path = CONFIGS_DIR / f"{self._saved_config}.yaml"
        if not config_path.exists():
            self.app.call_from_thread(
                self._log, f"Config not found: {config_path}"
            )
            return
        self._label = f"saved: {self._saved_config}"
        self.app.call_from_thread(self._set_header, "starting")
        self._do_start(config_path=config_path)

    # -- Start new container --

    @work(thread=True, exclusive=True, group="container")
    def _start_container(self) -> None:
        self.app.call_from_thread(self._set_header, "starting")
        self.app.call_from_thread(self._log, "Preparing config...")

        if self._is_demo:
            self._do_start(config_path=None)
        else:
            config_dir = write_config_to_temp(self._config)
            config_file = config_dir / "mapviewer.yaml"
            self._do_start(config_path=config_file)

    def _do_start(self, config_path: Path | None) -> None:
        """Shared start logic — runs inside a worker thread."""
        state: TuiState = self.app.tui_state
        edition = state.edition
        version = state.version

        # Stop existing container before starting a new one
        self.app.call_from_thread(
            self._log, "Stopping existing container (if any)..."
        )
        try:
            from .viewer import MapViewer as MV
            existing = MV.connect()
            existing.stop()
        except ContainerNotFound:
            pass
        except Exception:
            pass

        # Check for image updates
        import threading

        pull_policy = state.pull_policy
        image_exists = docker_client.image_exists(edition, version)

        def pull_progress(info: dict) -> None:
            self.app.call_from_thread(self._update_pull_progress, info)

        needs_pull = False
        if image_exists:
            if pull_policy == "never":
                self.app.call_from_thread(
                    self._log, "Using cached image (--no-pull)"
                )
            else:
                self.app.call_from_thread(
                    self._log, "Checking for image updates..."
                )
                try:
                    status = docker_client.check_for_update(edition, version)
                    if status.update_available:
                        needs_pull = True
                    elif status.error:
                        self.app.call_from_thread(
                            self._log,
                            f"Could not check for updates: {status.error}",
                        )
                except Exception:
                    pass  # Continue with cached image
        else:
            if pull_policy == "never":
                self.app.call_from_thread(
                    self._log,
                    "[red]Image not found locally and --no-pull is set[/red]",
                )
                return
            needs_pull = True

        # When prompting, ask the user before pulling an update
        if needs_pull and image_exists and pull_policy == "prompt":
            answer_event = threading.Event()
            user_wants_pull = [False]

            def _on_dismiss(result: bool) -> None:
                user_wants_pull[0] = result
                answer_event.set()

            self.app.call_from_thread(
                self.app.push_screen, ConfirmPullScreen(), _on_dismiss,
            )
            answer_event.wait()
            if not user_wants_pull[0]:
                self.app.call_from_thread(
                    self._log, "Skipping update, using cached image"
                )
                needs_pull = False

        if needs_pull:
            self.app.call_from_thread(
                self._show_pull_overlay, "Pulling MapViewer image..."
            )
            try:
                docker_client.pull_image(
                    edition, version, progress_callback=pull_progress,
                )
                self.app.call_from_thread(self._hide_pull_overlay)
                self.app.call_from_thread(self._log, "Image ready")
            except Exception as e:
                self.app.call_from_thread(self._hide_pull_overlay)
                self.app.call_from_thread(self._log, f"Pull failed: {e}")
                return

        def log_cb(line: str) -> None:
            stripped = line.strip()
            if stripped:
                self.app.call_from_thread(self._log, stripped)

        self.app.call_from_thread(self._log, "Starting container...")
        try:
            from .viewer import MapViewer

            if self._is_demo:
                mv = MapViewer(
                    demo=True, edition=edition, version=version,
                    port=state.port, bind_address=state.bind_address,
                )
            else:
                mv = MapViewer(
                    config=config_path, edition=edition, version=version,
                    port=state.port, bind_address=state.bind_address,
                )
            self._mv = mv
            self.app.call_from_thread(
                self._set_header, "starting", mv.url,
            )
            mv.start(pull=False, wait=True, timeout=120, log_callback=log_cb)
            self._running = True
            self.app.call_from_thread(
                self._set_header, "[green]running[/green]", mv.url,
            )
            self.app.call_from_thread(self._log, "Container started")

            # Resolve actual image version from container
            self._resolve_image_version()

            # Auto-open browser
            if not state.no_browser:
                try:
                    mv.open_browser()
                except Exception:
                    pass

            self._stream_logs(mv)
        except MapViewerError as e:
            self._running = False
            self.app.call_from_thread(self._log, str(e))

    # -- Log streaming --

    def _stream_logs(self, mv) -> None:
        """Stream container logs — called from worker thread."""
        try:
            for line in mv.logs(follow=True):
                stripped = line.strip() if isinstance(line, str) else line
                if stripped:
                    self.app.call_from_thread(self._log, stripped)
        except Exception:
            self.app.call_from_thread(self._log, "Log stream ended")


# ---------------------------------------------------------------------------
# ImagePickerScreen
# ---------------------------------------------------------------------------

class ImagePickerScreen(Screen):
    """Pick edition + image version, see local images, apply & restart."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    CSS = """
    #picker-title {
        text-style: bold;
        margin: 1 2;
    }

    .picker-section {
        margin: 1 2;
        text-style: bold;
    }

    #edition-radio {
        margin: 0 2 1 2;
    }

    #login-status {
        margin: 0 2;
    }

    .tag-buttons {
        margin: 0 2;
        height: auto;
    }

    .tag-buttons Button {
        margin-right: 1;
    }

    #version-input {
        margin: 0 2 1 2;
    }

    #local-images {
        height: auto;
        max-height: 10;
        margin: 0 2 1 2;
    }

    .picker-actions {
        margin: 1 2;
        height: auto;
    }

    .picker-actions Button {
        margin-right: 1;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._local_images: list[dict] = []
        self._active_tag = ""

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static("Select MapViewer Image", id="picker-title")

            yield Static("Edition", classes="picker-section")
            yield RadioSet(
                RadioButton("community"),
                RadioButton("member"),
                id="edition-radio",
            )
            yield Static("", id="login-status")

            yield Static("Version Tag", classes="picker-section")
            with Horizontal(classes="tag-buttons"):
                for tag in docker_client.KNOWN_TAGS:
                    yield Button(tag, id=f"tag-{tag}")
            yield Input(value=_default_image, id="version-input")

            yield Static("Local Images", classes="picker-section")
            yield ListView(id="local-images")

            with Horizontal(classes="picker-actions"):
                yield Button(
                    "Apply & Restart", variant="primary", id="picker-apply",
                )
                yield Button("Cancel", id="picker-cancel")
        yield Footer()

    def on_mount(self) -> None:
        state: TuiState = self.app.tui_state

        # Set edition radio
        radio = self.query_one("#edition-radio", RadioSet)
        index = 0 if state.edition == "community" else 1
        try:
            radio._nodes[index].value = True
        except Exception:
            pass

        # Set version input
        self.query_one("#version-input", Input).value = state.version

        # Compute active tag for highlighting
        self._active_tag = docker_client.get_image_tag(
            state.edition, state.version,
        )

        self._load_images()

    @work(thread=True)
    def _load_images(self) -> None:
        images = docker_client.list_local_image_versions()
        self._local_images = images

        state: TuiState = self.app.tui_state
        logged_in = docker_client.is_logged_in(state.edition)
        self.app.call_from_thread(self._update_ui, images, logged_in)

    def _update_ui(
        self, images: list[dict], logged_in: bool,
    ) -> None:
        state: TuiState = self.app.tui_state

        # Login status
        if logged_in:
            login_text = "[green]logged in[/green]"
        else:
            registry = docker_client.REGISTRIES.get(state.edition, "")
            host = registry.split("/")[0] if registry else ""
            login_text = (
                f"[yellow]not logged in[/yellow]"
                f" [dim]— run docker login {host}[/dim]"
            )
        self.query_one("#login-status", Static).update(login_text)

        # Local images
        lv = self.query_one("#local-images", ListView)
        lv.clear()

        edition_filter = state.edition
        filtered = [
            img for img in images if img["edition"] == edition_filter
        ]

        if filtered:
            for img in filtered:
                active = self._active_tag.endswith(f":{img['tag']}")
                marker = "[green]●[/green]" if active else "[dim]○[/dim]"
                active_label = "  [green]active[/green]" if active else ""
                label = (
                    f"{marker} {img['edition']}"
                    f" | {img['tag']}"
                    f" | {img['size_mb']:.1f} MB"
                    f"{active_label}"
                )
                lv.append(
                    ListItem(
                        Static(label),
                        name=f"{img['edition']}:{img['version']}",
                    )
                )
        else:
            lv.append(
                ListItem(Static("[dim]No local images for this edition[/dim]"))
            )

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id == "edition-radio":
            self._load_images()

    def _get_selected_edition(self) -> str:
        radio = self.query_one("#edition-radio", RadioSet)
        index = radio.pressed_index
        return "community" if index == 0 else "member"

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        name = event.item.name
        if not name or ":" not in name:
            return
        edition, version = name.split(":", 1)
        # Fill in edition + version from selection
        radio = self.query_one("#edition-radio", RadioSet)
        index = 0 if edition == "community" else 1
        try:
            radio._nodes[index].value = True
        except Exception:
            pass
        self.query_one("#version-input", Input).value = version

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("tag-"):
            tag = btn_id[4:]
            self.query_one("#version-input", Input).value = tag
        elif btn_id == "picker-apply":
            self._apply()
        elif btn_id == "picker-cancel":
            self.dismiss(False)

    def _apply(self) -> None:
        state: TuiState = self.app.tui_state
        state.edition = self._get_selected_edition()
        state.version = self.query_one("#version-input", Input).value.strip()
        if not state.version:
            state.version = "latest"
        self.dismiss(True)

    def action_cancel(self) -> None:
        self.dismiss(False)


# ---------------------------------------------------------------------------
# ConfirmDeleteScreen
# ---------------------------------------------------------------------------

class ConfirmDeleteScreen(Screen):
    """Modal confirmation for deleting a saved config."""

    BINDINGS = [
        Binding("y", "confirm_delete", "Delete"),
        Binding("escape", "cancel", "Cancel"),
    ]

    CSS = """
    #delete-title {
        text-style: bold;
        margin: 1 2;
    }

    #delete-yaml {
        margin: 1 2;
        background: $panel;
        padding: 1;
        max-height: 20;
    }

    #delete-error {
        margin: 0 2;
        color: $error;
    }

    .delete-actions {
        margin: 1 2;
        height: auto;
    }

    .delete-actions Button {
        margin-right: 1;
    }
    """

    def __init__(self, config_name: str) -> None:
        super().__init__()
        self._config_name = config_name

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static("", id="delete-title")
            yield Static("", id="delete-yaml")
            yield Static("", id="delete-error")
            with Horizontal(classes="delete-actions"):
                yield Button(
                    "Delete", variant="error", id="delete-confirm",
                )
                yield Button("Cancel", id="delete-cancel")
        yield Footer()

    def on_mount(self) -> None:
        import yaml

        self.query_one("#delete-title", Static).update(
            f"[bold]Delete config '[red]{self._config_name}[/red]'?[/bold]"
        )
        config_path = CONFIGS_DIR / f"{self._config_name}.yaml"
        try:
            config = load_config(config_path)
            text = yaml.dump(config, default_flow_style=False, sort_keys=False)
            self.query_one("#delete-yaml", Static).update(text)
        except Exception as e:
            self.query_one("#delete-error", Static).update(
                f"[red]Could not load config: {e}[/red]"
            )

    def action_confirm_delete(self) -> None:
        try:
            delete_config(self._config_name)
            self.dismiss(True)
        except Exception as e:
            self.query_one("#delete-error", Static).update(
                f"[red]Delete failed: {e}[/red]"
            )

    def action_cancel(self) -> None:
        self.dismiss(False)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "delete-confirm":
            self.action_confirm_delete()
        elif event.button.id == "delete-cancel":
            self.dismiss(False)


# ---------------------------------------------------------------------------
# ConfigManagerScreen
# ---------------------------------------------------------------------------

class ConfigManagerScreen(Screen):
    """Modal screen for managing saved configs (switch, create, delete)."""

    BINDINGS = [
        Binding("enter", "switch_config", "Switch", show=False),
        Binding("s", "switch_config", "Switch"),
        Binding("n", "new_config", "New Config"),
        Binding("x", "delete_config", "Delete"),
        Binding("escape", "cancel", "Cancel"),
    ]

    CSS = """
    #config-mgr-title {
        text-style: bold;
        margin: 1 2;
    }

    #config-mgr-empty {
        margin: 0 2;
        color: $text-muted;
    }

    #config-mgr-list {
        margin: 0 2 1 2;
    }

    .config-mgr-actions {
        margin: 1 2;
        height: auto;
    }

    .config-mgr-actions Button {
        margin-right: 1;
    }
    """

    def __init__(self, current_config: str | None = None) -> None:
        super().__init__()
        self._current_config = current_config

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static(
                "[bold]Config Manager[/bold]", id="config-mgr-title",
            )
            yield Static("", id="config-mgr-empty")
            yield ConfigListWithPreview(id="config-mgr-list")
            with Horizontal(classes="config-mgr-actions"):
                yield Button("Switch (s)", variant="primary", id="config-mgr-switch")
                yield Button("New Config (n)", id="config-mgr-new")
                yield Button("Delete (x)", variant="error", id="config-mgr-delete")
                yield Button("Cancel", id="config-mgr-cancel")
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_list()

    def _refresh_list(self) -> None:
        configs = list_saved_configs()
        empty = self.query_one("#config-mgr-empty", Static)
        if not configs:
            empty.update("[dim]No saved configs. Press [bold]n[/bold] to create one.[/dim]")
        else:
            empty.update("")
        self.query_one(
            "#config-mgr-list", ConfigListWithPreview,
        ).refresh_configs(configs, current=self._current_config)

    def action_switch_config(self) -> None:
        name = self.query_one(
            "#config-mgr-list", ConfigListWithPreview,
        ).highlighted_name
        if name is None:
            self.notify("No config selected", timeout=2)
            return
        self.dismiss(name)

    def action_new_config(self) -> None:
        # Dismiss with sentinel so RunScreen launches the wizard.
        # Pushing WizardScreen here would orphan ConfigManagerScreen
        # in the stack when the wizard calls switch_screen().
        self.dismiss("__new__")

    def action_delete_config(self) -> None:
        name = self.query_one(
            "#config-mgr-list", ConfigListWithPreview,
        ).highlighted_name
        if name is None:
            self.notify("No config selected", timeout=2)
            return

        def _on_dismiss(deleted: bool | None) -> None:
            if deleted:
                self._refresh_list()

        self.app.push_screen(
            ConfirmDeleteScreen(name), callback=_on_dismiss,
        )

    def action_cancel(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "config-mgr-switch":
            self.action_switch_config()
        elif event.button.id == "config-mgr-new":
            self.action_new_config()
        elif event.button.id == "config-mgr-delete":
            self.action_delete_config()
        elif event.button.id == "config-mgr-cancel":
            self.dismiss(None)


# ---------------------------------------------------------------------------
# DockerScreen
# ---------------------------------------------------------------------------

class DockerScreen(Screen):
    """Container introspection: stats, config, docker run command."""

    BINDINGS = [
        Binding("escape", "go_back", "Back"),
        Binding("b", "go_back", "Back", show=False),
        Binding("c", "copy_command", "Copy Cmd"),
        Binding("y", "copy_yaml", "Copy YAML"),
    ]

    CSS = """
    #docker-info {
        margin: 1 2;
    }

    .section-title {
        text-style: bold;
        margin: 0 2;
    }

    #stats-content {
        margin: 0 2 1 2;
    }

    #docker-cmd {
        margin: 0 2;
        background: $panel;
        padding: 1;
    }

    #yaml-path {
        margin: 0 2;
        color: $text-muted;
    }

    #yaml-content {
        margin: 0 2;
        background: $panel;
        padding: 1;
    }

    .copy-btn {
        margin: 1 2;
    }
    """

    def __init__(self, mv) -> None:
        super().__init__()
        self._mv = mv
        self._streaming = False

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static("", id="docker-info")
            yield Rule()
            yield Static("[bold]Resources[/bold]", classes="section-title")
            yield Static("[dim]waiting...[/dim]", id="stats-content")
            yield Rule()
            yield Static("[bold]Docker Run Command[/bold]", classes="section-title")
            yield Static("", id="docker-cmd")
            yield Button("Copy Command  (c)", id="copy-cmd", classes="copy-btn")
            yield Rule()
            yield Static("[bold]Generated Config[/bold]", classes="section-title")
            yield Static("", id="yaml-path")
            yield Static("", id="yaml-content")
            yield Button("Copy YAML  (y)", id="copy-yaml", classes="copy-btn")
        yield Footer()

    def on_mount(self) -> None:
        self._populate_info()
        self._populate_command()
        self._populate_yaml()
        self._streaming = True
        self._start_stats_stream()

    def _populate_info(self) -> None:
        mv = self._mv
        status = mv.status()
        uptime = self._compute_uptime()
        image = mv.image_tag or docker_client.get_image_tag(mv.edition, mv.version)
        info = (
            f"[bold]Container:[/bold]  {mv.name}\n"
            f"[bold]Image:[/bold]      {image}\n"
            f"[bold]Edition:[/bold]    {mv.edition}\n"
            f"[bold]Status:[/bold]     {status}\n"
            f"[bold]Uptime:[/bold]     {uptime}\n"
            f"[bold]URL:[/bold]        [cyan]{mv.url}[/cyan]"
        )
        self.query_one("#docker-info", Static).update(info)

    def _compute_uptime(self) -> str:
        from datetime import datetime, timezone
        try:
            container = docker_client.get_container(self._mv.name)
            if container is None:
                return "N/A"
            started = container.attrs["State"]["StartedAt"]
            # Docker ISO 8601 may have nanoseconds — truncate to microseconds
            ts = started.replace("Z", "+00:00")
            if "." in ts:
                dot = ts.index(".")
                plus = ts.index("+", dot) if "+" in ts[dot:] else len(ts)
                frac = ts[dot + 1:plus][:6]
                ts = ts[:dot + 1] + frac + ts[plus:]
            started_dt = datetime.fromisoformat(ts)
            delta = datetime.now(timezone.utc) - started_dt
            total = int(delta.total_seconds())
            hours, remainder = divmod(total, 3600)
            minutes, seconds = divmod(remainder, 60)
            if hours > 0:
                return f"{hours}h {minutes}m {seconds}s"
            if minutes > 0:
                return f"{minutes}m {seconds}s"
            return f"{seconds}s"
        except Exception:
            return "N/A"

    def _populate_command(self) -> None:
        try:
            cmd = self._mv.get_docker_run_command()
        except Exception:
            cmd = "[dim]Could not reconstruct command[/dim]"
        self.query_one("#docker-cmd", Static).update(cmd)

    def _populate_yaml(self) -> None:
        import yaml
        config = self._mv.get_transformed_config()
        if config:
            temp_dir = getattr(self._mv, "_temp_config_dir", None)
            if temp_dir:
                self.query_one("#yaml-path", Static).update(
                    f"[dim]{temp_dir / 'mapviewer.yaml'}[/dim]"
                )
            yaml_text = yaml.dump(config, default_flow_style=False, sort_keys=False)
            self.query_one("#yaml-content", Static).update(yaml_text.rstrip())
        else:
            self.query_one("#yaml-content", Static).update(
                "[dim]Demo mode \u2014 using built-in config[/dim]"
            )

    @work(thread=True, group="docker-stats")
    def _start_stats_stream(self) -> None:
        if not self._mv:
            return
        try:
            for stats in docker_client.get_container_stats(self._mv.name):
                if not self._streaming:
                    break
                self.app.call_from_thread(self._update_stats, stats)
        except Exception:
            pass

    def _update_stats(self, stats: docker_client.ContainerStats) -> None:
        mem_limit = (
            f" / {stats.memory_limit_mb:.0f}"
            if stats.memory_limit_mb > 0
            else ""
        )
        text = (
            f"CPU   [bold]{stats.cpu_percent:.1f}%[/bold]\n"
            f"MEM   {stats.memory_mb:.0f}{mem_limit} MB\n"
            f"NET   [cyan]\u2193[/cyan] {stats.net_rx_mb:.2f} MB  "
            f"[cyan]\u2191[/cyan] {stats.net_tx_mb:.2f} MB"
        )
        try:
            self.query_one("#stats-content", Static).update(text)
        except Exception:
            pass

    def action_go_back(self) -> None:
        self._streaming = False
        self.app.pop_screen()

    def action_copy_command(self) -> None:
        try:
            cmd = self._mv.get_docker_run_command()
            self.app.copy_to_clipboard(cmd)
            self.notify("Docker command copied to clipboard", timeout=2)
        except Exception:
            self.notify("Copy failed", severity="error", timeout=2)

    def action_copy_yaml(self) -> None:
        import yaml
        config = self._mv.get_transformed_config()
        if config:
            text = yaml.dump(config, default_flow_style=False, sort_keys=False)
            self.app.copy_to_clipboard(text)
            self.notify("YAML copied to clipboard", timeout=2)
        else:
            self.notify("No config to copy (demo mode)", timeout=2)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "copy-cmd":
            self.action_copy_command()
        elif event.button.id == "copy-yaml":
            self.action_copy_yaml()


# ---------------------------------------------------------------------------
# HelpScreen
# ---------------------------------------------------------------------------

class HelpScreen(Screen):
    """Modal help screen showing CLI usage and TUI keybindings."""

    BINDINGS = [
        Binding("escape", "go_back", "Back"),
        Binding("question_mark", "go_back", "Back", show=False),
    ]

    CSS = """
    #help-content {
        margin: 1 2;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll():
            yield Static("", id="help-content")
        yield Footer()

    def on_mount(self) -> None:
        from .cli import _build_parser

        cli_help = _build_parser().format_help()
        # Escape Rich markup characters in the raw help text
        cli_help = cli_help.replace("[", "\\[")

        keybindings = (
            "[bold]Keyboard Shortcuts[/bold]\n\n"
            "  [bold cyan]HomeScreen[/bold cyan]\n"
            "    [bold]n[/bold]   New config wizard\n"
            "    [bold]x[/bold]   Delete highlighted config\n"
            "    [bold]r[/bold]   Refresh instances and configs\n"
            "    [bold]?[/bold]   Show this help screen\n"
            "    [bold]q[/bold]   Quit\n\n"
            "  [bold cyan]RunScreen[/bold cyan]\n"
            "    [bold]o[/bold]   Open browser\n"
            "    [bold]f[/bold]   Cycle log filter (all / errors / alerts)\n"
            "    [bold]c[/bold]   Config manager (switch, create, delete)\n"
            "    [bold]d[/bold]   Docker container details\n"
            "    [bold]i[/bold]   Switch Docker image version\n"
            "    [bold]?[/bold]   Show this help screen\n"
            "    [bold]q[/bold]   Quit and stop container\n\n"
            "  [bold cyan]Config Manager[/bold cyan]\n"
            "    [bold]s[/bold]   Switch to highlighted config\n"
            "    [bold]n[/bold]   New config wizard\n"
            "    [bold]x[/bold]   Delete highlighted config\n"
            "    [bold]esc[/bold] Cancel\n"
        )

        getting_started = (
            "[bold]Getting Started[/bold]\n\n"
            "  If ~/.nds/config.yaml exists it is loaded automatically when no\n"
            "  source arguments are given on the command line.\n\n"
            "  Use the New Config wizard on the HomeScreen to create a data source\n"
            "  connection. Saved configs are stored in ~/.nds/configs/ and can be\n"
            "  launched from the HomeScreen or via:  mapviewer <name>\n"
        )

        content = (
            f"{NDS_HEADER}\n\n"
            f"[bold]CLI Usage[/bold]\n\n"
            f"[dim]{cli_help}[/dim]\n"
            f"{getting_started}\n"
            f"{keybindings}"
        )

        self.query_one("#help-content", Static).update(content)

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------

class MapViewerApp(App):
    """NDS MapViewer TUI application."""

    TITLE = "NDS MapViewer"

    CSS = """
    Screen {
        background: $surface;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
    ]

    def __init__(
        self,
        edition: str = "community",
        version: str = _default_image,
        no_browser: bool = False,
        port: int = 0,
        bind_address: str = "127.0.0.1",
        pull_policy: str = "prompt",
        run_config: dict[str, Any] | None = None,
        run_label: str = "",
        is_demo: bool = False,
    ) -> None:
        super().__init__()
        self.tui_state = TuiState(
            edition=edition,
            version=version,
            no_browser=no_browser,
            port=port,
            bind_address=bind_address,
            pull_policy=pull_policy,
        )
        self._run_config = run_config
        self._run_label = run_label
        self._is_demo = is_demo

    def on_mount(self) -> None:
        if self._run_config is not None:
            self.push_screen(RunScreen(
                config=self._run_config,
                label=self._run_label,
                exit_on_back=True,
                is_demo=self._is_demo,
            ))
        else:
            self.push_screen(HomeScreen())

    def action_quit(self) -> None:
        screen = self.screen
        if isinstance(screen, RunScreen) and screen._mv and screen._running:
            screen.action_quit_and_stop()
        else:
            self.exit()
