"""Main MapViewer class for managing the Docker container."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Iterator

if TYPE_CHECKING:
    from docker.models.containers import Container

from . import __default_image__ as _default_image
from . import docker_client
from .config import (
    TransformedConfig,
    load_config,
    transform_config,
    validate_paths,
    write_config_to_temp,
)
from .exceptions import ConfigError, ContainerNotFound


class MapViewer:
    """
    Manage the NDS MapViewer Docker container.

    This class handles:
    - Loading and transforming configuration files
    - Managing Docker volume mounts for local paths
    - Container lifecycle (start, stop, restart)
    - Log streaming

    Usage:
        # With config file
        mv = MapViewer(config="config.yaml", edition="community")
        mv.start()

        # With context manager
        with MapViewer(config="config.yaml") as mv:
            mv.start()
            # ... do work ...
        # Auto-cleanup on exit

        # Demo mode
        mv = MapViewer(demo=True, edition="community")
        mv.start()

        # Connect to existing container
        mv = MapViewer.connect()
        print(mv.status(), mv.url)
    """

    @classmethod
    def connect(cls, name: str = docker_client.CONTAINER_NAME) -> "MapViewer":
        """Connect to an existing MapViewer container.

        Args:
            name: Container name (defaults to the standard container name).

        Returns:
            MapViewer instance bound to the existing container.

        Raises:
            ContainerNotFound: If no container with that name exists.
        """
        container = docker_client.get_container(name)
        if container is None:
            raise ContainerNotFound(name)
        return cls._from_container(container)

    @classmethod
    def _from_container(cls, container) -> "MapViewer":
        """Create a MapViewer instance from an existing Docker container."""
        # Read port from container
        port = 8089
        ports = container.attrs.get("NetworkSettings", {}).get("Ports", {})
        if "8089/tcp" in ports and ports["8089/tcp"]:
            port = int(ports["8089/tcp"][0].get("HostPort", 8089))

        # Create instance without config validation
        instance = cls.__new__(cls)
        instance._config_path = None
        instance._edition = "unknown"  # Can't determine from container
        instance._version = "unknown"
        instance._port = port
        instance._demo = False
        instance._name = container.name
        instance._transformed = None
        instance._temp_config_dir = None
        instance._container = container
        instance._bind_address = "127.0.0.1"
        instance._original_config = None
        # Try to derive image tag from container
        try:
            tags = container.image.tags
            instance._image_tag = tags[0] if tags else None
        except Exception:
            instance._image_tag = None

        return instance

    def __init__(
        self,
        config: str | Path | None = None,
        edition: str = "community",
        version: str = _default_image,
        port: int = 0,
        bind_address: str = "127.0.0.1",
        demo: bool = False,
        name: str = docker_client.CONTAINER_NAME,
    ):
        """
        Initialize a MapViewer instance.

        Args:
            config: Path to config.yaml config file (uses host paths)
            edition: "community" or "member"
            version: Docker image version tag (e.g., "2025.6.2", "latest")
            port: Host port to expose MapViewer on (0 = auto-select, prefers 8089)
            bind_address: Host address to bind (default ``"127.0.0.1"``)
            demo: If True, use built-in demo config with NDS Islands
            name: Docker container name
        """
        if not demo and config is None:
            raise ConfigError(
                "No configuration provided.\n\n"
                "Either provide a data source:\n"
                "  mapviewer run /path/to/data\n\n"
                "Or use demo mode:\n"
                "  mapviewer run --demo"
            )

        # Validate config file early
        if config is not None:
            self._config_path = Path(config).expanduser().resolve()
            if not self._config_path.exists():
                raise ConfigError(
                    f"Config file not found: {self._config_path}\n\n"
                    "Please check the path and try again."
                )
            if not self._config_path.is_file():
                raise ConfigError(
                    f"Config path is not a file: {self._config_path}\n\n"
                    "Please provide a path to a config.yaml file."
                )
            if not os.access(self._config_path, os.R_OK):
                raise ConfigError(
                    f"Config file is not readable: {self._config_path}\n\n"
                    "Please check file permissions."
                )
        else:
            self._config_path = None

        self._edition = edition
        self._version = version
        self._demo = demo
        self._name = name

        # Auto-select port if not specified
        if port == 0:
            self._port = docker_client.find_free_port(8089)
        else:
            self._port = port

        self._bind_address = bind_address
        self._transformed: TransformedConfig | None = None
        self._temp_config_dir: Path | None = None
        self._container: Container | None = None
        self._original_config: dict | None = None
        self._image_tag: str | None = None

    @property
    def url(self) -> str:
        """Get the URL to access the MapViewer."""
        return f"http://localhost:{self._port}"

    @property
    def edition(self) -> str:
        """Get the edition (community or member)."""
        return self._edition

    @property
    def version(self) -> str:
        """Get the Docker image version."""
        return self._version

    @property
    def port(self) -> int:
        """Get the host port."""
        return self._port

    @property
    def bind_address(self) -> str:
        """Get the host bind address."""
        return self._bind_address

    @property
    def name(self) -> str:
        """Get the container name."""
        return self._name

    @property
    def config_path(self) -> Path | None:
        """Get the original config file path (None if demo mode)."""
        return self._config_path

    @property
    def original_config(self) -> dict | None:
        """Get the original config as loaded from file."""
        return self._original_config

    @property
    def image_tag(self) -> str | None:
        """Get the Docker image tag used for this container."""
        return self._image_tag

    def _load_and_transform_config(self) -> TransformedConfig | None:
        """Load config and transform paths for Docker.

        Returns None in demo mode (container uses built-in config).
        """
        if self._demo:
            return None

        config = load_config(self._config_path)

        # Store original config
        import copy
        self._original_config = copy.deepcopy(config)

        # Validate that local paths exist
        errors = validate_paths(config)
        if errors:
            raise ConfigError(
                "Some paths in your config do not exist:\n  " + "\n  ".join(errors),
                str(self._config_path) if self._config_path else None,
            )

        return transform_config(config)

    def _ensure_image(self, pull: bool = True) -> str:
        """Ensure the Docker image is available, pulling if needed."""
        image_tag = docker_client.get_image_tag(self._edition, self._version)

        if not docker_client.image_exists(self._edition, self._version):
            if pull:
                docker_client.pull_image(self._edition, self._version)
            else:
                raise ConfigError(
                    f"Image {image_tag} not found locally. "
                    "Run with pull=True or pull the image manually."
                )

        return image_tag

    def start(
        self,
        pull: bool = True,
        wait: bool = True,
        timeout: int = 60,
        log_callback: Callable[[str], None] | None = None,
    ) -> None:
        """
        Start the MapViewer container.

        Args:
            pull: Pull the image if not available locally
            wait: Wait for the container to be ready
            timeout: Timeout in seconds when waiting for ready state
            log_callback: Optional callback(line: str) called with log lines during startup
        """
        # Validate Docker setup
        docker_client.get_docker_client()
        docker_client.ensure_logged_in(self._edition)

        # Load and transform config
        self._transformed = self._load_and_transform_config()

        if self._transformed is not None:
            # Write transformed config to temp directory
            self._temp_config_dir = write_config_to_temp(self._transformed.config)
            volumes = self._transformed.get_docker_volumes()
        else:
            # Demo mode: no config mount, container uses built-in config
            self._temp_config_dir = None
            volumes = {}

        # Ensure image is available
        image_tag = self._ensure_image(pull=pull)
        self._image_tag = image_tag

        # Run container
        self._container = docker_client.run_container(
            image_tag=image_tag,
            port=self._port,
            bind_address=self._bind_address,
            config_dir=self._temp_config_dir,
            volumes=volumes,
            name=self._name,
            remove_existing=True,
        )

        # Wait for ready
        if wait:
            ready = docker_client.wait_for_container_ready(
                name=self._name,
                timeout=timeout,
                port=self._port,
                log_callback=log_callback,
            )
            if not ready:
                # Check if container exited
                status = self.status()
                if status != "running":
                    logs = self.logs(tail=30)
                    raise ConfigError(
                        f"Container exited unexpectedly (status: {status}).\n\n"
                        f"Recent logs:\n{logs}"
                    )
                else:
                    raise ConfigError(
                        f"Container did not become ready within {timeout}s.\n"
                        f"The MapViewer is still starting up. Try increasing the timeout or check:\n"
                        f"  docker logs {self._name}"
                    )

    def stop(self, remove: bool = True) -> None:
        """
        Stop the MapViewer container.

        Args:
            remove: Also remove the container after stopping
        """
        try:
            docker_client.stop_container(self._name, remove=remove)
        finally:
            self._cleanup()

    def restart(self, pull: bool = False, wait: bool = True, timeout: int = 30) -> None:
        """
        Restart the MapViewer container.

        Args:
            pull: Pull latest image before restarting
            wait: Wait for the container to be ready
            timeout: Timeout in seconds when waiting
        """
        try:
            self.stop(remove=True)
        except ContainerNotFound:
            pass

        self.start(pull=pull, wait=wait, timeout=timeout)

    def status(self) -> str:
        """
        Get the container status.

        Returns:
            One of: "running", "exited", "paused", "restarting", "not_found"
        """
        return docker_client.get_container_status(self._name)

    def logs(self, follow: bool = False, tail: int | str = "all") -> Iterator[str] | str:
        """
        Get container logs.

        Args:
            follow: Stream logs continuously
            tail: Number of lines from end, or "all"

        Returns:
            If follow=True, returns an iterator of log lines.
            If follow=False, returns the full log as a string.
        """
        return docker_client.get_container_logs(self._name, follow=follow, tail=tail)

    def get_datasources(self) -> list[str]:
        """
        Get list of loaded datasource names from the running MapViewer.

        Queries the /status endpoint to retrieve datasource information.

        Returns:
            List of datasource names, or empty list if unavailable.
        """
        import json
        import re
        import urllib.request
        import urllib.error

        try:
            url = f"http://127.0.0.1:{self._port}/status"
            with urllib.request.urlopen(url, timeout=5) as response:
                html = response.read().decode("utf-8")

            # Extract JSON from <pre> tags - first one contains service stats
            pre_match = re.search(r"<pre>(\{.*?\})</pre>", html, re.DOTALL)
            if pre_match:
                data = json.loads(pre_match.group(1))
                datasources = data.get("datasources", [])
                return [ds.get("name", "Unknown") for ds in datasources]
        except (urllib.error.URLError, OSError, json.JSONDecodeError):
            pass
        return []

    def open_browser(self, use_bundled: bool = False) -> bool:
        """
        Open the MapViewer in a web browser.

        Args:
            use_bundled: Use bundled Chromium (requires [browser] extra)

        Returns:
            True if browser was opened successfully
        """
        from .browser import open_browser

        return open_browser(self.url, use_bundled=use_bundled)

    def get_transformed_config(self) -> dict | None:
        """Get the transformed config (after path rewriting)."""
        if self._transformed:
            return self._transformed.config
        return None

    def get_volume_mounts(self) -> list[tuple[str, str]] | None:
        """Get the generated volume mounts as (host_path, container_path) tuples."""
        if self._transformed:
            return [(str(v.host_path), v.container_path) for v in self._transformed.volumes]
        return None

    def get_docker_run_command(self) -> str:
        """Reconstruct the equivalent ``docker run`` CLI command."""
        import platform as _platform

        tag = self._image_tag or docker_client.get_image_tag(
            self._edition, self._version,
        )
        parts = ["docker run -d", f"--name {self._name}", f"-p {self._bind_address}:{self._port}:8089"]

        if self._temp_config_dir:
            parts.append(f"-v {self._temp_config_dir}:/config:rw")

        if self._transformed:
            for vol in self._transformed.volumes:
                parts.append(f"-v {vol.host_path}:{vol.container_path}:ro")

        if _platform.system() == "Linux":
            parts.append("--add-host host.docker.internal:host-gateway")

        parts.append(tag)
        return " \\\n  ".join(parts)

    def _cleanup(self) -> None:
        """Clean up temporary files."""
        temp_dir = getattr(self, "_temp_config_dir", None)
        if temp_dir and temp_dir.exists():
            try:
                shutil.rmtree(temp_dir)
            except OSError:
                pass
            self._temp_config_dir = None

    def __enter__(self) -> MapViewer:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - stop container and cleanup."""
        try:
            if self.status() == "running":
                self.stop()
        except ContainerNotFound:
            pass
        finally:
            self._cleanup()

    def __del__(self) -> None:
        """Destructor - only cleanup temp files if container is not running."""
        # Don't cleanup if container is still running - it needs the mounted config
        try:
            if self.status() == "running":
                return
        except Exception:
            pass
        self._cleanup()
