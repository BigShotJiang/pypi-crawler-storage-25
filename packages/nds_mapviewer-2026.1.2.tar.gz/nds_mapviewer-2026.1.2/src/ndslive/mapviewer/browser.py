"""Browser detection and launching for MapViewer."""

from __future__ import annotations

import platform
import shutil
import subprocess
import webbrowser
from typing import Literal

# Preferred Chromium-based browsers in order of preference
CHROMIUM_BROWSERS = [
    "google-chrome",
    "google-chrome-stable",
    "chromium",
    "chromium-browser",
    "microsoft-edge",
    "brave-browser",
]

# macOS application names
MACOS_CHROMIUM_APPS = [
    "Google Chrome",
    "Chromium",
    "Microsoft Edge",
    "Brave Browser",
]


def detect_chromium_browser() -> str | None:
    """
    Detect an installed Chromium-based browser.

    Returns:
        Browser command/path if found, None otherwise.
    """
    system = platform.system()

    if system == "Darwin":
        # macOS: Check for .app bundles
        for app in MACOS_CHROMIUM_APPS:
            result = subprocess.run(
                ["mdfind", f"kMDItemKind == 'Application' && kMDItemDisplayName == '{app}'"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip().split("\n")[0]

        # Also check standard paths
        standard_paths = [
            "/Applications/Google Chrome.app",
            "/Applications/Chromium.app",
            "/Applications/Microsoft Edge.app",
            "/Applications/Brave Browser.app",
        ]
        for path in standard_paths:
            import os
            if os.path.exists(path):
                return path

    elif system == "Windows":
        # Windows: Check common locations
        import os
        program_files = os.environ.get("ProgramFiles", "C:\\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")
        local_app_data = os.environ.get("LOCALAPPDATA", "")

        windows_paths = [
            f"{program_files}\\Google\\Chrome\\Application\\chrome.exe",
            f"{program_files_x86}\\Google\\Chrome\\Application\\chrome.exe",
            f"{local_app_data}\\Google\\Chrome\\Application\\chrome.exe",
            f"{program_files}\\Microsoft\\Edge\\Application\\msedge.exe",
            f"{program_files_x86}\\Microsoft\\Edge\\Application\\msedge.exe",
            f"{program_files}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
        ]
        for path in windows_paths:
            if os.path.exists(path):
                return path

    else:
        # Linux: Check PATH
        for browser in CHROMIUM_BROWSERS:
            if shutil.which(browser):
                return browser

    return None


def is_playwright_available() -> bool:
    """Check if playwright is installed."""
    try:
        import playwright
        return True
    except ImportError:
        return False


def is_playwright_chromium_installed() -> bool:
    """Check if playwright's Chromium browser is installed."""
    if not is_playwright_available():
        return False

    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            # Try to get the executable path
            p.chromium.executable_path
            return True
    except Exception:
        return False


def install_playwright_chromium() -> bool:
    """Install playwright's Chromium browser."""
    if not is_playwright_available():
        return False

    try:
        result = subprocess.run(
            ["playwright", "install", "chromium"],
            capture_output=True,
            text=True,
        )
        return result.returncode == 0
    except Exception:
        return False


def open_browser(
    url: str,
    use_bundled: bool = False,
    prefer_chromium: bool = True,
) -> bool:
    """
    Open a URL in a web browser.

    Args:
        url: The URL to open
        use_bundled: Use playwright's bundled Chromium
        prefer_chromium: Prefer Chromium-based browsers for best performance

    Returns:
        True if the browser was opened successfully
    """
    # Option 1: Use bundled Chromium via playwright
    if use_bundled:
        if not is_playwright_available():
            raise ImportError(
                "Playwright is not installed. Install with:\n"
                "  pip install nds-mapviewer[browser]"
            )

        if not is_playwright_chromium_installed():
            # Prompt user or auto-install
            raise RuntimeError(
                "Playwright Chromium is not installed. Install with:\n"
                "  playwright install chromium"
            )

        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=False)
                page = browser.new_page()
                page.goto(url)
                # Keep browser open - user closes manually
                input("Press Enter to close the browser...")
                browser.close()
            return True
        except Exception:
            return False

    # Option 2: Prefer system Chromium browser
    if prefer_chromium:
        chromium = detect_chromium_browser()
        if chromium:
            try:
                system = platform.system()
                if system == "Darwin" and chromium.endswith(".app"):
                    # macOS: Use 'open -a'
                    subprocess.Popen(["open", "-a", chromium, url])
                    return True
                elif system == "Windows":
                    subprocess.Popen([chromium, url])
                    return True
                else:
                    subprocess.Popen([chromium, url])
                    return True
            except Exception:
                pass  # Fall through to default browser

    # Option 3: Use system default browser
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False


def get_browser_recommendation() -> str:
    """Get a recommendation message about browsers."""
    chromium = detect_chromium_browser()
    if chromium:
        return f"Using Chromium-based browser for best performance: {chromium}"

    return (
        "For best performance, we recommend using a Chromium-based browser:\n"
        "  - Google Chrome: https://www.google.com/chrome/\n"
        "  - Microsoft Edge: https://www.microsoft.com/edge\n"
        "  - Brave: https://brave.com/\n\n"
        "Or install the bundled browser:\n"
        "  pip install nds-mapviewer[browser]\n"
        "  playwright install chromium"
    )
