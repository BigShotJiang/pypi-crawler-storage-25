import os
from typing import Any

from fastapi import APIRouter, File, UploadFile
from pydantic import BaseModel

from pantoqa_bridge.models.misc import Action
from pantoqa_bridge.service.driver_driver_v2 import BridgeDriverV2
from pantoqa_bridge.utils.service_manager import get_adb_service

router = APIRouter()


class ActionRequestModel(BaseModel):
  id: str
  action: Action
  device_serial_no: str | None = None


class ActionResponseModel(BaseModel):
  id: str
  type: str
  data: Any | None = None


@router.post('/perform-action', response_model=ActionResponseModel)
async def perform_action(request: ActionRequestModel):
  srv = get_adb_service(request.device_serial_no)
  result = srv.process(request.action)

  return ActionResponseModel(
    id=request.id,
    type="driver_action_response",
    data=result,
  )


@router.post('/v2/perform-action', response_model=ActionResponseModel)
async def perform_action_v2(request: ActionRequestModel):
  with BridgeDriverV2(serial=request.device_serial_no) as driver:
    result = await _start_action_v2(driver, request)
    return ActionResponseModel(
      id=request.id,
      type="driver_action_response",
      data=result,
    )


@router.post('/install-apk')
async def install_apk(device_serial_no: str, apk_file: UploadFile = File(...)):
  os.makedirs("/tmp", exist_ok=True)
  apk_path = f"/tmp/{apk_file.filename}"
  with open(apk_path, "wb") as f:
    f.write(await apk_file.read())
  srv = get_adb_service(device_serial_no)
  srv.srv.install_app(apk_path)
  os.remove(apk_path)
  return {"message": "APK installed successfully on device."}


async def _start_action_v2(driver: BridgeDriverV2, request: ActionRequestModel):
  action = request.action.action_type
  params = request.action.params

  if action == "tap":
    assert params, "params is required"
    await driver.tap(params['x'], params['y'])
    return None
  elif action == "swipe":
    assert params, "params is required"
    await driver.swipe(
      params["x1"],
      params["y1"],
      params["x2"],
      params["y2"],
      duration_ms=params.get("duration_ms") or params.get('duration'),
    )
    return None
  elif action == "input_text":
    assert params, "params is required"
    return await driver.input_text(text=params["text"], clear=params.get("clear", False))
  elif action == "press_key":
    assert params, "params is required"
    await driver.press_key(params["keycode"])
    return None
  elif action == "drag":
    assert params, "params is required"
    await driver.drag(params["x1"], params["y1"], params["x2"], params["y2"],
                      params.get("duration", 3.0))
    return None
  elif action == "start_app":
    assert params, "params is required"
    return await driver.start_app(package=params["package"], activity=params.get("activity"))
  elif action == "install_app":
    assert params, "params is required"
    return await driver.install_app(path=params["path"])
  elif action == "get_apps":
    assert params, "params is required"
    return await driver.get_apps(include_system=params.get("include_system", True))
  elif action == "list_packages":
    assert params, "params is required"
    return await driver.list_packages(params.get("include_system", False))
  elif action == "screenshot":
    assert params, "params is required"
    return await driver.screenshot(params.get("hide_overlay", True))
  elif action == "get_ui_tree":
    return await driver.get_ui_tree()
  elif action == "get_date":
    return await driver.get_date()
  elif action == "get_device_resolution":
    return await driver.get_device_resolution()
  else:
    raise ValueError(f"Unsupported action type: {action}")
