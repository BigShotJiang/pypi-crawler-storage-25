import asyncio
import json
import uuid
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import urlencode, urlparse, urlunparse

import aiohttp

from pantoqa_bridge.logger import logger
from pantoqa_bridge.models.misc import Action
from pantoqa_bridge.routes.action import ActionRequestModel, _start_action_v2
from pantoqa_bridge.service.driver_driver_v2 import BridgeDriverV2
from pantoqa_bridge.utils.service_manager import get_adb_service


class PromptExecutor:

  def __init__(
    self,
    system_env_vars: dict[str, str] | None,
    headers: dict[str, str],
    device_serial: str | None,
    context_id: str | None,
    env_id: str | None,
    on_data: Callable[[str, str], Awaitable[None]],
    driver_type: str = "BRIDGE",
    blind_mode: bool = True,
  ):
    self.system_env_vars = system_env_vars or {}
    self.headers = headers
    self.device_serial = device_serial
    self.context_id = context_id
    self.env_id = env_id
    self.on_data = on_data
    self.driver_type = driver_type
    self.blind_mode = blind_mode

  async def execute(self, prompt: str) -> int:
    prompt = f"/qa {prompt.strip()}" if not prompt.startswith("/") else prompt.strip()
    api_base_url = self.system_env_vars.get("X_PANTO_SERVER_URL")
    auth_org_id = self.headers.get("X-Panto-Org-Id") or self.headers.get(
      "X-PANTO-ORG-ID") or self.headers.get("x-panto-org-id")
    auth_bearer_token = self.headers.get("authorization") or self.headers.get("Authorization")
    if not auth_org_id or not auth_bearer_token:
      raise Exception("Auth error")

    if not api_base_url:
      raise RuntimeError("Missing X_PANTO_SERVER_URL in system environment variables")

    await self.on_data("status", "Streaming response from execution API...")
    ws_base_url = self.system_env_vars.get("X_PANTO_WS_URL") or api_base_url
    ws_url = self._build_backend_ws_url(
      ws_base_url,
      session_id=self.system_env_vars.get("X_PANTO_SESSION_ID"),
    )

    token = auth_bearer_token.removeprefix("Bearer ").strip()
    protocol = f"{token}|{auth_org_id}"

    timeout = aiohttp.ClientTimeout(total=None, sock_connect=20, sock_read=None)
    async with aiohttp.ClientSession(timeout=timeout) as session:
      async with session.ws_connect(ws_url, protocols=[protocol]) as ws:
        await self.on_data("status", "Connected to backend websocket")
        if self.context_id:
          await ws.send_str(json.dumps({
            "type": "context_id",
            "data": self.context_id,
          }))
        if self.env_id:
          await ws.send_str(json.dumps({
            "type": "env_id",
            "data": self.env_id,
          }))
        await ws.send_str(json.dumps({
          "id": str(uuid.uuid4()),
          "type": "msg",
          "text": prompt,
        }), )

        try:
          async for ws_msg in ws:
            if ws_msg.type == aiohttp.WSMsgType.TEXT:
              is_finished = await self._handle_backend_ws_message(ws, ws_msg.data)
              if is_finished:
                return 0
              continue

            if ws_msg.type == aiohttp.WSMsgType.ERROR:
              err = ws.exception()
              raise RuntimeError(f"WebSocket error: {err}")

            if ws_msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.CLOSED):
              break
        except asyncio.CancelledError:
          try:
            await ws.send_str(
              json.dumps({
                "id": str(uuid.uuid4()),
                "type": "msg",
                "text": "/stop",
              }))
          except Exception:
            pass
          raise

    await self.on_data("status", "Backend websocket disconnected")
    return 0

  def _build_backend_ws_url(self, base_url: str, session_id: str | None) -> str:
    parsed = urlparse(base_url)
    scheme = parsed.scheme
    if scheme in ("http", "ws"):
      ws_scheme = "ws"
    elif scheme in ("https", "wss"):
      ws_scheme = "wss"
    else:
      raise RuntimeError(f"Unsupported X_PANTO_SERVER_URL scheme: {scheme}")

    path = parsed.path or ""
    if not path or path == "/":
      path = "/api/v1/qa/ws"

    query_params: dict[str, str] = {
      "driver_type": self.driver_type,
      "blind_mode": str(self.blind_mode).lower(),
    }
    if session_id:
      query_params["session_id"] = session_id

    return urlunparse((
      ws_scheme,
      parsed.netloc,
      path,
      "",
      urlencode(query_params),
      "",
    ))

  async def _handle_backend_ws_message(
    self,
    ws: aiohttp.ClientWebSocketResponse,
    raw_data: str,
  ) -> bool:
    try:
      message = json.loads(raw_data)
    except json.JSONDecodeError:
      await self.on_data("warning", f"Invalid WS JSON payload: {raw_data}")
      return False

    msg_type = message.get("type")

    if msg_type == "logmsg":
      if msg := message.get('message'):
        msg = str(msg)
        if msg == 'gathering_context':
          msg = ">\n\nGathering context from device..."
        await self.on_data("log", str(msg))
      return False

    if msg_type == 'msg':
      if message.get('data'):
        msg = str(message['data'])
        await self.on_data("log", msg)
      return False

    if msg_type == 'logmsg_step':
      message = message.get("message") or {}
      next_goal = message.get("next_goal")
      actions_description = message.get("actions_description")
      final_msg = ""
      if next_goal:
        final_msg += f"> \n{next_goal}\n"
      if actions_description:
        final_msg += f"> \n{actions_description}"
      if final_msg:
        await self.on_data("log", ">\n\n" + final_msg + "\n\n>")
      return False

    if msg_type == "session_id":
      await self.on_data("session_id", str(message.get("message") or ""))
      return False

    if msg_type == "device_resolution":
      await self.on_data("device_resolution", json.dumps(message.get("data") or {}))
      return False

    if msg_type == "user_input":
      await self.on_data("user_input", json.dumps(message))
      return False

    if msg_type == "summary":
      summary = message.get("data")
      if isinstance(summary, str):
        await self.on_data("summary", summary)
      else:
        await self.on_data("summary", json.dumps(summary))
      return True

    if msg_type in {"bridge_action", "bridge_v2_action"}:
      response = await self._execute_bridge_action_message(message,
                                                           is_v2=(msg_type == "bridge_v2_action"))
      await ws.send_str(json.dumps(response))
      return False

    await self.on_data("warning", f"Unhandled WS message type: {msg_type}")
    return False

  async def _execute_bridge_action_message(self, message: dict[str, Any],
                                           is_v2: bool) -> dict[str, Any]:
    action_id = str(message.get("id") or uuid.uuid4())
    repeat_times = int(message.get("repeat_times") or 1)
    repeat_times = max(1, repeat_times)
    data = message.get("data")

    action_payload = self._normalize_bridge_action_payload(data)
    if not action_payload:
      return {
        "id": action_id,
        "type": "driver_action_response",
        "data": None,
        "error": "Invalid bridge_action payload",
      }

    try:
      action = Action.model_validate(action_payload)
      if is_v2:
        result = await self._execute_bridge_action_v2(action_id, action, repeat_times)
      else:
        result = await self._execute_bridge_action_v1(action, repeat_times)

      return {
        "id": action_id,
        "type": "driver_action_response",
        "data": result,
        "error": None,
      }
    except Exception as exc:
      logger.exception(f"Error while executing bridge_action [{action_id}]: {exc}")
      return {
        "id": action_id,
        "type": "driver_action_response",
        "data": None,
        "error": str(exc),
      }

  async def _execute_bridge_action_v2(
    self,
    action_id: str,
    action: Action,
    repeat_times: int,
  ) -> Any:
    result: Any = None
    driver = BridgeDriverV2(serial=self.device_serial)
    request_model = ActionRequestModel(
      id=action_id,
      action=action,
      device_serial_no=self.device_serial,
    )

    for _ in range(repeat_times):
      result = await _start_action_v2(driver, request_model)
    return result

  async def _execute_bridge_action_v1(self, action: Action, repeat_times: int) -> Any:
    result: Any = None
    service_manager = get_adb_service(self.device_serial)
    for _ in range(repeat_times):
      result = await asyncio.to_thread(service_manager.process, action)
    return result

  def _normalize_bridge_action_payload(self, data: Any) -> dict[str, Any] | None:
    if not isinstance(data, dict):
      return None

    if "action_type" in data:
      return {
        "action_type": data["action_type"],
        "params": data.get("params"),
      }

    action_type = data.get("action") or data.get("type")
    if not action_type:
      return None

    params = data.get("params")
    if params is None:
      params = {k: v for k, v in data.items() if k not in {"action", "type", "params"}}

    return {
      "action_type": action_type,
      "params": params,
    }
