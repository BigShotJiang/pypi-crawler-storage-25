"""Exception behaviour tests."""
