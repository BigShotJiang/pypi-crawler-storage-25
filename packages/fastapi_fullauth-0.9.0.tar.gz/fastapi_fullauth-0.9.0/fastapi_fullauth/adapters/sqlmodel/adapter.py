from typing import Any

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession as SAAsyncSession
from sqlalchemy.ext.asyncio import async_sessionmaker
from sqlalchemy.orm import selectinload
from sqlmodel.ext.asyncio.session import AsyncSession as SMAsyncSession

from fastapi_fullauth.adapters.base import (
    AbstractUserAdapter,
    OAuthAdapterMixin,
    PasskeyAdapterMixin,
    PermissionAdapterMixin,
    RoleAdapterMixin,
)
from fastapi_fullauth.adapters.sqlmodel.models.base import RefreshTokenRecord, UserBase
from fastapi_fullauth.exceptions import UserAlreadyExistsError
from fastapi_fullauth.types import (
    CreateUserSchema,
    CreateUserSchemaType,
    OAuthAccount,
    PasskeyCredential,
    RefreshToken,
    UserID,
    UserSchema,
    UserSchemaType,
)
from fastapi_fullauth.utils import normalize_email


class SQLModelAdapter(
    AbstractUserAdapter[UserSchemaType, CreateUserSchemaType],
    RoleAdapterMixin,
    PermissionAdapterMixin,
    OAuthAdapterMixin,
    PasskeyAdapterMixin,
):
    def __init__(
        self,
        session_maker: async_sessionmaker[SMAsyncSession | SAAsyncSession],
        user_model: type[UserBase],
        user_schema: type[UserSchemaType] = UserSchema,  # type: ignore[assignment]
        create_user_schema: type[CreateUserSchemaType] = CreateUserSchema,  # type: ignore[assignment]
    ) -> None:
        self._session_maker = session_maker
        self._user_model = user_model
        self._user_schema = user_schema
        self._create_user_schema = create_user_schema

    def _user_query(self):
        query = select(self._user_model)
        if hasattr(self._user_model, "roles"):
            query = query.options(selectinload(self._user_model.roles))  # type: ignore[arg-type]
        return query

    def _to_schema(self, user) -> UserSchemaType:
        # convert Role objects to role name strings before validation
        data = {}
        for field_name in self._user_schema.model_fields:
            val = getattr(user, field_name, None)
            if val is not None:
                data[field_name] = val
        # roles need special handling: list[Role] -> list[str]
        if hasattr(user, "roles"):
            data["roles"] = [r.name for r in user.roles]
        return self._user_schema.model_validate(data)

    async def get_user_by_id(self, user_id: UserID) -> UserSchemaType | None:
        async with self._session_maker() as session:
            result = await session.execute(self._user_query().where(self._user_model.id == user_id))
            user = result.scalars().first()
            return self._to_schema(user) if user else None

    async def get_user_by_email(self, email: str) -> UserSchemaType | None:
        return await self.get_user_by_field("email", normalize_email(email))

    async def get_user_by_field(self, field: str, value: str) -> UserSchemaType | None:
        column = getattr(self._user_model, field, None)
        if column is None:
            raise ValueError(f"Model has no field '{field}'")
        if field == "email":
            value = normalize_email(value)
        async with self._session_maker() as session:
            result = await session.execute(self._user_query().where(column == value))
            user = result.scalars().first()
            return self._to_schema(user) if user else None

    async def create_user(self, data: CreateUserSchemaType, hashed_password: str) -> UserSchemaType:
        async with self._session_maker() as session:
            extra = data.model_dump(exclude={"email", "password"})
            email = normalize_email(data.email)
            user = self._user_model(
                email=email,
                hashed_password=hashed_password,
                **extra,
            )
            session.add(user)
            try:
                await session.commit()
            except IntegrityError as e:
                await session.rollback()
                raise UserAlreadyExistsError(f"User with email {email} already exists") from e
            # re-fetch with roles loaded
            result = await session.execute(self._user_query().where(self._user_model.id == user.id))
            user = result.scalars().first()
            assert user is not None  # just committed above
            return self._to_schema(user)

    async def update_user(self, user_id: UserID, data: dict[str, Any]) -> UserSchemaType:
        if "email" in data and data["email"] is not None:
            data = {**data, "email": normalize_email(data["email"])}
        async with self._session_maker() as session:
            await session.execute(
                update(self._user_model).where(self._user_model.id == user_id).values(**data)
            )
            await session.commit()
            result = await session.execute(self._user_query().where(self._user_model.id == user_id))
            user = result.scalars().first()
            if user is None:
                raise ValueError(f"User {user_id} not found")
            return self._to_schema(user)

    async def delete_user(self, user_id: UserID) -> None:
        async with self._session_maker() as session:
            result = await session.execute(
                select(self._user_model).where(self._user_model.id == user_id)
            )
            user = result.scalars().first()
            if user:
                await session.delete(user)
                await session.commit()

    async def get_user_roles(self, user_id: UserID) -> list[str]:
        if not hasattr(self._user_model, "roles"):
            return []
        async with self._session_maker() as session:
            result = await session.execute(self._user_query().where(self._user_model.id == user_id))
            user = result.scalars().first()
            if user is None:
                return []
            return [r.name for r in user.roles]

    async def get_hashed_password(self, user_id: UserID) -> str | None:
        async with self._session_maker() as session:
            result = await session.execute(
                select(self._user_model.hashed_password).where(self._user_model.id == user_id)
            )
            return result.scalars().first()

    async def set_password(self, user_id: UserID, hashed_password: str) -> None:
        async with self._session_maker() as session:
            await session.execute(
                update(self._user_model)
                .where(self._user_model.id == user_id)
                .values(hashed_password=hashed_password)
            )
            await session.commit()

    async def store_refresh_token(self, token: RefreshToken) -> None:
        async with self._session_maker() as session:
            db_token = RefreshTokenRecord(
                token=token.token,
                user_id=token.user_id,
                family_id=token.family_id,
                expires_at=token.expires_at,
                revoked=token.revoked,
            )
            session.add(db_token)
            await session.commit()

    async def get_refresh_token(self, token_str: str) -> RefreshToken | None:
        async with self._session_maker() as session:
            result = await session.execute(
                select(RefreshTokenRecord).where(RefreshTokenRecord.token == token_str)
            )
            row = result.scalars().first()
            if row is None:
                return None
            return RefreshToken(
                token=row.token,
                user_id=row.user_id,
                expires_at=row.expires_at,
                family_id=row.family_id,
                revoked=row.revoked,
            )

    async def revoke_refresh_token(self, token_str: str) -> bool:
        async with self._session_maker() as session:
            result = await session.execute(
                update(RefreshTokenRecord)
                .where(RefreshTokenRecord.token == token_str)
                .where(RefreshTokenRecord.revoked.is_(False))
                .values(revoked=True)
            )
            await session.commit()
            return result.rowcount == 1

    async def revoke_refresh_token_family(self, family_id: str) -> None:
        async with self._session_maker() as session:
            await session.execute(
                update(RefreshTokenRecord)
                .where(RefreshTokenRecord.family_id == family_id)
                .values(revoked=True)
            )
            await session.commit()

    async def revoke_all_user_refresh_tokens(self, user_id: UserID) -> None:
        async with self._session_maker() as session:
            await session.execute(
                update(RefreshTokenRecord)
                .where(RefreshTokenRecord.user_id == user_id)
                .values(revoked=True)
            )
            await session.commit()

    async def set_user_verified(self, user_id: UserID) -> None:
        async with self._session_maker() as session:
            await session.execute(
                update(self._user_model)
                .where(self._user_model.id == user_id)
                .values(is_verified=True)
            )
            await session.commit()

    async def assign_role(self, user_id: UserID, role_name: str) -> None:
        from fastapi_fullauth.adapters.sqlmodel.models.role import Role

        async with self._session_maker() as session:
            result = await session.execute(select(Role).where(Role.name == role_name))
            role = result.scalars().first()
            if role is None:
                role = Role(name=role_name)
                session.add(role)
                await session.flush()

            result = await session.execute(self._user_query().where(self._user_model.id == user_id))
            user = result.scalars().first()
            if user and role not in user.roles:
                user.roles.append(role)
                session.add(user)
                await session.commit()

    async def remove_role(self, user_id: UserID, role_name: str) -> None:
        async with self._session_maker() as session:
            result = await session.execute(self._user_query().where(self._user_model.id == user_id))
            user = result.scalars().first()
            if user:
                user.roles = [r for r in user.roles if r.name != role_name]
                session.add(user)
                await session.commit()

    # ── Permissions ──────────────────────────────────────────────────

    async def get_permissions_for_roles(self, role_names: list[str]) -> list[str]:
        from fastapi_fullauth.adapters.sqlmodel.models.permission import (
            Permission,
            RolePermissionLink,
        )
        from fastapi_fullauth.adapters.sqlmodel.models.role import Role

        async with self._session_maker() as session:
            result = await session.execute(
                select(Permission.name)
                .join(RolePermissionLink, Permission.id == RolePermissionLink.permission_id)
                .join(Role, Role.id == RolePermissionLink.role_id)
                .where(Role.name.in_(role_names))
            )
            return list(set(result.scalars().all()))

    async def get_role_permissions(self, role_name: str) -> list[str]:
        from fastapi_fullauth.adapters.sqlmodel.models.permission import (
            Permission,
            RolePermissionLink,
        )
        from fastapi_fullauth.adapters.sqlmodel.models.role import Role

        async with self._session_maker() as session:
            result = await session.execute(
                select(Permission.name)
                .join(RolePermissionLink, Permission.id == RolePermissionLink.permission_id)
                .join(Role, Role.id == RolePermissionLink.role_id)
                .where(Role.name == role_name)
            )
            return list(result.scalars().all())

    async def assign_permission_to_role(self, role_name: str, permission: str) -> None:
        from fastapi_fullauth.adapters.sqlmodel.models.permission import (
            Permission,
            RolePermissionLink,
        )
        from fastapi_fullauth.adapters.sqlmodel.models.role import Role

        async with self._session_maker() as session:
            # get or create role
            result = await session.execute(select(Role).where(Role.name == role_name))
            role = result.scalars().first()
            if role is None:
                role = Role(name=role_name)
                session.add(role)
                await session.flush()

            # get or create permission
            result = await session.execute(select(Permission).where(Permission.name == permission))
            perm = result.scalars().first()
            if perm is None:
                perm = Permission(name=permission)
                session.add(perm)
                await session.flush()

            # check if link already exists
            result = await session.execute(
                select(RolePermissionLink).where(
                    RolePermissionLink.role_id == role.id,
                    RolePermissionLink.permission_id == perm.id,
                )
            )
            if result.scalars().first() is None:
                session.add(RolePermissionLink(role_id=role.id, permission_id=perm.id))
                await session.commit()

    async def remove_permission_from_role(self, role_name: str, permission: str) -> None:
        from fastapi_fullauth.adapters.sqlmodel.models.permission import (
            Permission,
            RolePermissionLink,
        )
        from fastapi_fullauth.adapters.sqlmodel.models.role import Role

        async with self._session_maker() as session:
            result = await session.execute(select(Role).where(Role.name == role_name))
            role = result.scalars().first()
            if role is None:
                return

            result = await session.execute(select(Permission).where(Permission.name == permission))
            perm = result.scalars().first()
            if perm is None:
                return

            result = await session.execute(
                select(RolePermissionLink).where(
                    RolePermissionLink.role_id == role.id,
                    RolePermissionLink.permission_id == perm.id,
                )
            )
            link = result.scalars().first()
            if link:
                await session.delete(link)
                await session.commit()

    # ── OAuth ────────────────────────────────────────────────────────

    def _to_oauth_account(self, row) -> OAuthAccount:
        return OAuthAccount(
            provider=row.provider,
            provider_user_id=row.provider_user_id,
            user_id=row.user_id,
            provider_email=row.provider_email,
            access_token=row.access_token,
            refresh_token=row.refresh_token,
            expires_at=row.expires_at,
        )

    async def get_oauth_account(self, provider: str, provider_user_id: str) -> OAuthAccount | None:
        from fastapi_fullauth.adapters.sqlmodel.models.oauth import OAuthAccountRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(OAuthAccountRecord).where(
                    OAuthAccountRecord.provider == provider,
                    OAuthAccountRecord.provider_user_id == provider_user_id,
                )
            )
            row = result.scalars().first()
            return self._to_oauth_account(row) if row else None

    async def get_user_oauth_accounts(self, user_id: UserID) -> list[OAuthAccount]:
        from fastapi_fullauth.adapters.sqlmodel.models.oauth import OAuthAccountRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(OAuthAccountRecord).where(OAuthAccountRecord.user_id == user_id)
            )
            return [self._to_oauth_account(row) for row in result.scalars().all()]

    async def create_oauth_account(self, data: OAuthAccount) -> OAuthAccount:
        from fastapi_fullauth.adapters.sqlmodel.models.oauth import OAuthAccountRecord

        async with self._session_maker() as session:
            record = OAuthAccountRecord(
                provider=data.provider,
                provider_user_id=data.provider_user_id,
                user_id=data.user_id,
                provider_email=data.provider_email,
                access_token=data.access_token,
                refresh_token=data.refresh_token,
                expires_at=data.expires_at,
            )
            session.add(record)
            try:
                await session.commit()
            except IntegrityError:
                # Concurrent OAuth callback for the same (provider, provider_user_id)
                # won the insert. Return the existing row.
                await session.rollback()
                result = await session.execute(
                    select(OAuthAccountRecord).where(
                        OAuthAccountRecord.provider == data.provider,
                        OAuthAccountRecord.provider_user_id == data.provider_user_id,
                    )
                )
                existing = result.scalars().first()
                if existing is not None:
                    return self._to_oauth_account(existing)
                raise
            return data

    async def update_oauth_account(
        self, provider: str, provider_user_id: str, data: dict[str, Any]
    ) -> OAuthAccount | None:
        from fastapi_fullauth.adapters.sqlmodel.models.oauth import OAuthAccountRecord

        async with self._session_maker() as session:
            await session.execute(
                update(OAuthAccountRecord)
                .where(
                    OAuthAccountRecord.provider == provider,
                    OAuthAccountRecord.provider_user_id == provider_user_id,
                )
                .values(**data)
            )
            await session.commit()
            return await self.get_oauth_account(provider, provider_user_id)

    async def delete_oauth_account(self, provider: str, provider_user_id: str) -> None:
        from fastapi_fullauth.adapters.sqlmodel.models.oauth import OAuthAccountRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(OAuthAccountRecord).where(
                    OAuthAccountRecord.provider == provider,
                    OAuthAccountRecord.provider_user_id == provider_user_id,
                )
            )
            row = result.scalars().first()
            if row:
                await session.delete(row)
                await session.commit()

    # ── Passkeys ────────────────────────────────────────────────────

    def _to_passkey(self, row) -> PasskeyCredential:

        return PasskeyCredential(
            id=row.id,
            user_id=row.user_id,
            credential_id=row.credential_id,
            public_key=row.public_key,
            sign_count=row.sign_count,
            device_name=row.device_name,
            transports=row.transports.split(",") if row.transports else [],
            backed_up=row.backed_up,
            created_at=row.created_at,
            last_used_at=row.last_used_at,
        )

    async def get_passkey_by_credential_id(self, credential_id: str) -> PasskeyCredential | None:
        from fastapi_fullauth.adapters.sqlmodel.models.passkey import PasskeyRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(PasskeyRecord).where(PasskeyRecord.credential_id == credential_id)
            )
            row = result.scalars().first()
            return self._to_passkey(row) if row else None

    async def get_user_passkeys(self, user_id: UserID) -> list[PasskeyCredential]:
        from fastapi_fullauth.adapters.sqlmodel.models.passkey import PasskeyRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(PasskeyRecord).where(PasskeyRecord.user_id == user_id)
            )
            return [self._to_passkey(row) for row in result.scalars().all()]

    async def store_passkey(self, data: PasskeyCredential) -> PasskeyCredential:
        from fastapi_fullauth.adapters.sqlmodel.models.passkey import PasskeyRecord

        async with self._session_maker() as session:
            record = PasskeyRecord(
                id=data.id,
                user_id=data.user_id,
                credential_id=data.credential_id,
                public_key=data.public_key,
                sign_count=data.sign_count,
                device_name=data.device_name,
                transports=",".join(data.transports),
                backed_up=data.backed_up,
            )
            session.add(record)
            await session.commit()
            return data

    async def update_passkey_sign_count(self, credential_id: str, sign_count: int) -> bool:
        from datetime import datetime, timezone

        from fastapi_fullauth.adapters.sqlmodel.models.passkey import PasskeyRecord

        now = datetime.now(timezone.utc)
        async with self._session_maker() as session:
            result = await session.execute(
                update(PasskeyRecord)
                .where(PasskeyRecord.credential_id == credential_id)
                .where(PasskeyRecord.sign_count < sign_count)
                .values(sign_count=sign_count, last_used_at=now)
            )
            if result.rowcount == 0:
                await session.execute(
                    update(PasskeyRecord)
                    .where(PasskeyRecord.credential_id == credential_id)
                    .values(last_used_at=now)
                )
                await session.commit()
                return False
            await session.commit()
            return True

    async def delete_passkey(self, passkey_id: UserID) -> None:
        from fastapi_fullauth.adapters.sqlmodel.models.passkey import PasskeyRecord

        async with self._session_maker() as session:
            result = await session.execute(
                select(PasskeyRecord).where(PasskeyRecord.id == passkey_id)
            )
            row = result.scalars().first()
            if row:
                await session.delete(row)
                await session.commit()
