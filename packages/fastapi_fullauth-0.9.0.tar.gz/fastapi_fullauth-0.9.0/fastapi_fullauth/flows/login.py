import logging

from fastapi_fullauth.adapters.base import AbstractUserAdapter
from fastapi_fullauth.core.crypto import hash_password, password_needs_rehash, verify_password
from fastapi_fullauth.core.tokens import TokenEngine
from fastapi_fullauth.exceptions import AccountLockedError, AuthenticationError
from fastapi_fullauth.protection.lockout import LockoutManager
from fastapi_fullauth.types import RefreshToken, TokenPair, UserSchema

logger = logging.getLogger("fastapi_fullauth.login")


async def login(
    adapter: AbstractUserAdapter,
    token_engine: TokenEngine,
    identifier: str,
    password: str,
    login_field: str = "email",
    lockout: LockoutManager | None = None,
    extra_claims: dict | None = None,
    user: UserSchema | None = None,
    hash_algorithm: str = "argon2id",
) -> TokenPair:
    if lockout and await lockout.is_locked(identifier):
        logger.warning("Login blocked — account locked: %s", identifier)
        raise AccountLockedError("Account is temporarily locked")

    if user is None:
        user = await adapter.get_user_by_field(login_field, identifier)
    if user is None:
        if lockout:
            await lockout.record_failure(identifier)
        logger.warning("Login failed — user not found: %s", identifier)
        raise AuthenticationError("Invalid credentials")

    hashed = await adapter.get_hashed_password(user.id)
    if hashed is None or not verify_password(password, hashed):
        if lockout:
            await lockout.record_failure(identifier)
        logger.warning("Login failed — invalid password: %s", identifier)
        raise AuthenticationError("Invalid credentials")

    if not user.is_active:
        logger.warning("Login failed — account deactivated: %s", identifier)
        raise AuthenticationError("User account is deactivated")

    if password_needs_rehash(hashed, algorithm=hash_algorithm):
        await adapter.set_password(user.id, hash_password(password, algorithm=hash_algorithm))

    if lockout:
        await lockout.clear(identifier)

    logger.info("Login successful: user_id=%s", user.id)
    roles = await adapter.get_user_roles(user.id)
    access, refresh_meta = token_engine.create_token_pair(
        user_id=str(user.id),
        roles=roles,
        extra=extra_claims,
    )

    await adapter.store_refresh_token(
        RefreshToken(
            token=refresh_meta.token,
            user_id=user.id,
            expires_at=refresh_meta.expires_at,
            family_id=refresh_meta.family_id,
        )
    )

    return TokenPair(
        access_token=access,
        refresh_token=refresh_meta.token,
        expires_in=token_engine.config.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
