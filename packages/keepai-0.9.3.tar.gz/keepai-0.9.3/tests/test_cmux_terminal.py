"""Unit tests for the cmux backend's mission-container API.

Subprocess and the cmux UNIX-socket RPC are both stubbed.
"""
from __future__ import annotations

import subprocess

import pytest

from keep.terminals import cmux as cmux_mod
from keep.terminals.cmux import CmuxTerminal


class _Calls:
    def __init__(self):
        self.run: list[list[str]] = []
        self.rpc: list[tuple[str, dict]] = []
        self.run_returns: dict[str, subprocess.CompletedProcess] = {}
        self.rpc_returns: dict[str, dict] = {}


@pytest.fixture
def calls(monkeypatch):
    c = _Calls()

    def fake_run(argv, *args, **kwargs):
        c.run.append(list(argv))
        key = " ".join(argv[:3])
        if key in c.run_returns:
            return c.run_returns[key]
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    def fake_rpc(method, params=None):
        c.rpc.append((method, params or {}))
        return c.rpc_returns.get(method, {})

    monkeypatch.setattr(cmux_mod.subprocess, "run", fake_run)
    monkeypatch.setattr(cmux_mod, "_rpc", fake_rpc)
    monkeypatch.setattr(cmux_mod.time, "sleep", lambda *a, **k: None)
    return c


# ---------------------------------------------------------------------------
# ensure_mission_container
# ---------------------------------------------------------------------------


def test_ensure_creates_new_workspace(calls):
    calls.run_returns["cmux new-workspace --cwd"] = subprocess.CompletedProcess(
        [], 0, stdout="OK workspace:9 pane:1 surface:1", stderr="",
    )
    term = CmuxTerminal()

    ref = term.ensure_mission_container("mission-x")

    assert ref == "workspace:9"
    # Rename was attempted with the correct field name ('title', not 'name').
    renames = [(m, p) for m, p in calls.rpc if m == "workspace.rename"]
    assert renames, calls.rpc
    _, params = renames[0]
    assert params.get("title") == "keep-mission-x"
    assert "name" not in params


# ---------------------------------------------------------------------------
# spawn_in_container
# ---------------------------------------------------------------------------


def test_spawn_supervisor_renames_first_surface_and_runs_cmd(calls):
    calls.rpc_returns["surface.list"] = {
        "surfaces": [{"ref": "surface:1", "pane_ref": "pane:1", "title": "shell"}],
    }
    term = CmuxTerminal()

    out = term.spawn_in_container("workspace:9", "supervisor", 0, "/tmp", "claude")

    assert out == "surface:1"
    renames = [c for c in calls.run if "rename-tab" in c]
    assert renames, calls.run
    assert any("supervisor" in " ".join(c) for c in renames)
    sent = [m for m, _ in calls.rpc if m == "surface.send_text"]
    assert sent, calls.rpc


def test_spawn_reviewer_splits_right(calls):
    calls.rpc_returns["surface.list"] = {
        "surfaces": [
            {"ref": "surface:1", "pane_ref": "pane:1", "title": "supervisor"},
        ],
    }
    calls.run_returns["cmux new-split right"] = subprocess.CompletedProcess(
        [], 0, stdout="OK surface:2 pane:2", stderr="",
    )
    term = CmuxTerminal()

    out = term.spawn_in_container("workspace:9", "reviewer", 0, "/tmp", "claude")
    assert out == "surface:2"
    split = [c for c in calls.run if "new-split" in c and "right" in c]
    assert split, calls.run


def test_spawn_worker_0_splits_down(calls):
    calls.rpc_returns["surface.list"] = {
        "surfaces": [
            {"ref": "surface:1", "pane_ref": "pane:1", "title": "supervisor"},
        ],
    }
    calls.run_returns["cmux new-split down"] = subprocess.CompletedProcess(
        [], 0, stdout="OK surface:3 pane:3", stderr="",
    )
    term = CmuxTerminal()

    out = term.spawn_in_container("workspace:9", "worker", 0, "/tmp", "claude")
    assert out == "surface:3"
    split = [c for c in calls.run if "new-split" in c and "down" in c]
    assert split, calls.run


def test_spawn_worker_n_new_surface_in_worker_pane(calls):
    calls.rpc_returns["surface.list"] = {
        "surfaces": [
            {"ref": "surface:3", "pane_ref": "pane:3", "title": "worker-1"},
        ],
    }
    calls.run_returns["cmux new-surface --workspace"] = subprocess.CompletedProcess(
        [], 0, stdout="OK surface:4 pane:3", stderr="",
    )
    term = CmuxTerminal()

    out = term.spawn_in_container("workspace:9", "worker", 1, "/tmp", "claude")
    assert out == "surface:4"
    new_surface = [c for c in calls.run if "new-surface" in c]
    assert new_surface, calls.run
    # Ensure we pinned the pane to the worker-1 pane.
    assert any("pane:3" in " ".join(c) for c in new_surface)


# ---------------------------------------------------------------------------
# close_mission_container
# ---------------------------------------------------------------------------


def test_close_uses_workspace_close_rpc(calls):
    term = CmuxTerminal()
    term.close_mission_container("workspace:9")

    closes = [(m, p) for m, p in calls.rpc if m == "workspace.close"]
    assert closes == [("workspace.close", {"workspace_id": "workspace:9"})], calls.rpc
