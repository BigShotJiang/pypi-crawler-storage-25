"""Regression tests for `keep self reset`.

The bug: `self_reset` used to kill only the daemon and `delete_all()` mission
state — the terminal surfaces (tmux / kitty / Terminal.app / cmux) for every
supervisor / worker / reviewer were left orphaned. This suite locks in that
`self_reset` now delegates to the same `kill_and_close_worker` path that
`mission_remove` uses, for every participant across every mission.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from keep import state
from keep.cli import app


runner = CliRunner()


SUP1 = "22222222-2222-4222-8222-000000000001"
SUP2 = "22222222-2222-4222-8222-000000000002"
W1 = "11111111-1111-4111-8111-000000000001"
W2 = "11111111-1111-4111-8111-000000000002"
W3 = "11111111-1111-4111-8111-000000000003"


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    # KEEP_HOME drives STATE_DIR / MISSIONS_DIR / GLOBAL_FILE *and*
    # keep._daemon.constants.RUNTIME_STATE_FILE — one env var isolates all paths.
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    state.save_global(state.new_global())
    return state_dir


def _seed_mission_with_participants(
    mission_id: str,
    *,
    supervisor_session: str,
    supervisor_target: str,
    worker_session: str,
    worker_target: str,
    reviewer_target: str,
) -> str:
    """Create a mission + supervisor + worker + reviewer; return reviewer_id."""
    state.create_mission(mission_id)
    state.add_supervisor(
        mission_id, supervisor_session,
        name=f"sup-{mission_id}", path="/tmp/sup",
        cache={"target_id": supervisor_target, "pid": None, "jsonl_path": f"/tmp/{supervisor_session}.jsonl"},
    )
    state.add_worker(
        mission_id, worker_session,
        name=f"worker-{mission_id}", path="/tmp/worker",
        cache={"target_id": worker_target, "pid": None, "jsonl_path": f"/tmp/{worker_session}.jsonl"},
    )

    reviewer_id = state.add_reviewer(
        mission_id,
        {
            "name": f"rev-{mission_id}",
            "path": "/tmp/reviewer.md",
            "status": "active",
            "session": f"reviewer-session-{mission_id}",
            "cache": {"target_id": reviewer_target, "pid": None, "jsonl_path": f"/tmp/reviewer-{mission_id}.jsonl"},
        },
    )
    return reviewer_id


def _patch_recording_terminal(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    """Override the autouse `_NoopTerminal` with a factory that records close()."""
    closed: list[str] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            ensure_mission_container=lambda mission_id: f"rec:{mission_id}",
            spawn_in_container=lambda ref, role, role_index, cwd, cmd: f"rec:{role}:{role_index}",
            close_mission_container=lambda ref: None,
            send_text=lambda *a, **k: None,
            send_key=lambda *a, **k: None,
            read_screen=lambda *a, **k: "",
            close=lambda target_id: closed.append(target_id),
            resolve_target_id=lambda pid: None,
        ),
    )
    # Also stub resolve_worker so kill_and_close_worker doesn't shell out to `ps`
    # looking for real claude processes (test isolation).
    monkeypatch.setattr(
        "keep._cli.spawn.resolve_worker",
        lambda session, terminal_type: SimpleNamespace(running=False, pid=None, target_id=None),
    )
    return closed


def test_self_reset_closes_surfaces_for_every_participant_in_every_mission(
    isolated_state: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    closed = _patch_recording_terminal(monkeypatch)

    _seed_mission_with_participants(
        "mission-a",
        supervisor_session=SUP1, supervisor_target="tgt-sup-a",
        worker_session=W1, worker_target="tgt-worker-a",
        reviewer_target="tgt-rev-a",
    )
    _seed_mission_with_participants(
        "mission-b",
        supervisor_session=SUP2, supervisor_target="tgt-sup-b",
        worker_session=W2, worker_target="tgt-worker-b",
        reviewer_target="tgt-rev-b",
    )

    # Second worker on mission-b to prove iter_workers-level coverage, not just "one each".
    state.add_worker(
        "mission-b", W3,
        name="worker-b2", path="/tmp/worker",
        cache={"target_id": "tgt-worker-b2", "pid": None, "jsonl_path": f"/tmp/{W3}.jsonl"},
    )

    result = runner.invoke(app, ["self", "reset"])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert "已重置" in result.stdout

    # Every participant's target_id must have been closed.
    expected = {
        "tgt-sup-a", "tgt-worker-a", "tgt-rev-a",
        "tgt-sup-b", "tgt-worker-b", "tgt-worker-b2", "tgt-rev-b",
    }
    assert set(closed) == expected, (
        f"closed surfaces mismatch: got {set(closed)!r}, want {expected!r}"
    )

    # State must be fully wiped.
    assert state.list_missions() == []


def test_self_reset_is_best_effort_when_a_mission_file_is_corrupt(
    isolated_state: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A corrupt mission file must not abort surface-close for the other missions."""
    closed = _patch_recording_terminal(monkeypatch)

    # Healthy mission.
    _seed_mission_with_participants(
        "mission-ok",
        supervisor_session=SUP1, supervisor_target="tgt-sup-ok",
        worker_session=W1, worker_target="tgt-worker-ok",
        reviewer_target="tgt-rev-ok",
    )

    # Corrupt mission: a JSON file that won't parse.
    bad_file = isolated_state / "missions" / "mission-bad.json"
    bad_file.write_text("{not valid json", encoding="utf-8")

    result = runner.invoke(app, ["self", "reset"])
    assert result.exit_code == 0, result.stdout + result.stderr

    # The healthy mission's surfaces were still closed — corrupt mission didn't
    # take down the whole sweep.
    assert {"tgt-sup-ok", "tgt-worker-ok", "tgt-rev-ok"}.issubset(set(closed))

    # State wipe still ran.
    assert state.list_missions() == []


def test_self_reset_runtime_state_file_is_removed(
    isolated_state: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`delete_all()` doesn't touch daemon-runtime.json; `self_reset` must."""
    _patch_recording_terminal(monkeypatch)

    runtime_file = isolated_state / "daemon-runtime.json"
    runtime_file.write_text('{"last_notify": {"stale": 1.0}}', encoding="utf-8")
    assert runtime_file.exists()

    result = runner.invoke(app, ["self", "reset"])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert not runtime_file.exists()
