"""Test-wide isolation: pin KEEP_HOME to a tmp directory for the entire session.

Why at module top-level (not a fixture):
  `keep._daemon.constants` mkdir()'s KEEP_HOME and opens a FileHandler on
  `daemon.log` at *import* time. If we set the env var inside a fixture,
  any test module that (directly or transitively) imports from the daemon
  package before that fixture runs would already have touched the user's
  real ~/.keep. conftest.py executes before any test module is imported,
  so setting the env var here guarantees every subsequent import sees
  the tmp path.

Also: blocks the autouse terminal safety net (unchanged from before).
"""

from __future__ import annotations

import os
import tempfile

import pytest


# Pin KEEP_HOME for the whole session BEFORE any `keep.*` module is imported.
# tempfile.mkdtemp gives us a stable path for the session (pytest's tmp_path_factory
# isn't available at module-import time — it needs a fixture context).
_KEEP_HOME_SESSION = tempfile.mkdtemp(prefix="keep-test-home-")
os.environ["KEEP_HOME"] = _KEEP_HOME_SESSION


class _NoopTerminal:
    """Fake Terminal: all operations are no-ops. Used by autouse safety fixture."""

    def ensure_mission_container(self, mission_id: str) -> str:
        return f"noop:{mission_id}"

    def spawn_in_container(
        self, container_ref: str, role: str, role_index: int, cwd: str, cmd: str,
    ) -> str:
        return f"noop:{role}:{role_index}"

    def close_mission_container(self, container_ref: str) -> None:
        return None

    def send_text(self, target_id: str, text: str) -> None:
        return None

    def send_key(self, target_id: str, key: str) -> None:
        return None

    def read_screen(self, target_id: str) -> str:
        return ""

    def close(self, target_id: str) -> None:
        return None

    def resolve_target_id(self, pid: int) -> str | None:
        return None


@pytest.fixture(autouse=True)
def _block_real_terminal(monkeypatch):
    """Prevent any test from touching the user's real terminal.

    The CLI's worker/supervisor/reviewer/mission remove paths call
    `get_terminal(...).close(target_id)` on real cmux / Terminal.app / Kitty /
    tmux. Without this fixture, a test that exercises those paths via
    `runner.invoke(app, [...])` would issue real RPC calls to the user's running
    terminal — which has actually closed real windows in development (including
    the Claude Code session running the tests).

    `keep.terminal.get_terminal` delegates to `keep.terminal._factory` at call
    time, so monkeypatching that single symbol diverts every caller — no matter
    how they imported `get_terminal`. Tests that need a custom terminal should
    override `keep.terminal._factory` via the same monkeypatch.
    """
    monkeypatch.setattr("keep.terminal._factory", lambda terminal_type: _NoopTerminal())
    yield
