"""Keep 状态持久化（public facade）.

v0.4: Participants 模型
  $KEEP_HOME/global.json            — daemon_pid, stopped
  $KEEP_HOME/missions/<name>.json   — 每个 mission 独立状态
    participants: [{session, role, cache}]  role ∈ {"worker", "supervisor"}

多 mission 场景下所有命令必须显式指定 -m <mission>；不再有 current_mission 全局默认。

Implementation is split across `keep._state.*` sub-modules by responsibility
(missions, participants, tasks, reviewers, transcript, messages, …). This
module re-exports the public API unchanged; external callers should keep
importing from `keep.state`.

Path constants (STATE_DIR, MISSIONS_DIR, GLOBAL_FILE) resolve dynamically from
the ``KEEP_HOME`` env var (default ``~/.keep``) on every access. Tests isolate
by setting the env var (e.g. ``monkeypatch.setenv("KEEP_HOME", str(tmp))``);
the change propagates to every path derivation — including subprocesses.
"""

from __future__ import annotations

from keep._state import paths as _paths
from keep._state.content import resolve_content
from keep._state.globals_ import (
    delete_global,
    load_global,
    new_global,
    save_global,
)
from keep._state.messages import (
    append_message_index,
    messages_dir,
    write_and_index_message,
)
from keep._state.missions import (
    SCHEMA_VERSION,
    VALID_MISSION_STATUSES,
    VALID_PARTICIPANT_ROLES,
    create_mission,
    delete_all,
    delete_mission,
    list_missions,
    load_mission,
    mission_terminal_type,
    mutate_mission,
    new_mission,
    save_mission,
    set_mission_container,
    validate_mission,
)
from keep._state.participants import (
    add_supervisor,
    add_worker,
    find_supervisor,
    find_worker,
    find_worker_globally,
    iter_workers,
    remove_supervisor,
    remove_worker,
    worker_session_id,
)
from keep._state.paths import (
    DEFAULT_TERMINAL,
    VALID_TERMINALS,
    atomic_write_text,
)
from keep._state.reviewers import (
    add_review_event,
    add_reviewer,
    get_review_event,
    get_reviewer,
    iter_reviewers,
    remove_reviewer,
    update_review_event,
    update_reviewer,
)
from keep._state.tasks import (
    create_task,
    get_task,
    highwatermark_file,
    list_tasks,
    lock_file,
    next_task_id,
    remove_task,
    task_file,
    task_store_dir,
    update_task,
)
from keep._state.transcript import (
    Direction,
    Kind,
    TranscriptEntry,
    append_transcript,
    read_transcript,
)


# ── Dynamic path re-exports ───────────────────────────────────
#
# STATE_DIR / MISSIONS_DIR / GLOBAL_FILE resolve from `KEEP_HOME` on every
# access. Re-export via module-level __getattr__ so `from keep.state import
# STATE_DIR` captures the current value at the time of import, and
# `keep.state.STATE_DIR` attribute access always re-reads.

_PROXIED_PATH_NAMES = frozenset({"STATE_DIR", "MISSIONS_DIR", "GLOBAL_FILE"})


def __getattr__(name: str):
    if name in _PROXIED_PATH_NAMES:
        return getattr(_paths, name)
    raise AttributeError(f"module 'keep.state' has no attribute {name!r}")


__all__ = [
    # paths
    "STATE_DIR",
    "GLOBAL_FILE",
    "MISSIONS_DIR",
    "DEFAULT_TERMINAL",
    "VALID_TERMINALS",
    "atomic_write_text",
    # global
    "load_global",
    "save_global",
    "delete_global",
    "new_global",
    # mission
    "SCHEMA_VERSION",
    "VALID_MISSION_STATUSES",
    "VALID_PARTICIPANT_ROLES",
    "mission_terminal_type",
    "validate_mission",
    "new_mission",
    "load_mission",
    "save_mission",
    "delete_mission",
    "list_missions",
    "create_mission",
    "delete_all",
    "mutate_mission",
    "set_mission_container",
    # participants
    "worker_session_id",
    "iter_workers",
    "find_worker",
    "find_worker_globally",
    "find_supervisor",
    "add_worker",
    "remove_worker",
    "add_supervisor",
    "remove_supervisor",
    # tasks
    "task_store_dir",
    "task_file",
    "highwatermark_file",
    "lock_file",
    "next_task_id",
    "create_task",
    "get_task",
    "list_tasks",
    "update_task",
    "remove_task",
    # reviewers
    "add_reviewer",
    "remove_reviewer",
    "iter_reviewers",
    "get_reviewer",
    "update_reviewer",
    "add_review_event",
    "get_review_event",
    "update_review_event",
    # content
    "resolve_content",
    # transcript
    "Direction",
    "Kind",
    "TranscriptEntry",
    "append_transcript",
    "read_transcript",
    # messages
    "messages_dir",
    "append_message_index",
    "write_and_index_message",
]
