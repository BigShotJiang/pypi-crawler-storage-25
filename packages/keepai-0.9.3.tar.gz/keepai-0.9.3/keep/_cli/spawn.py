"""Agent-session spawn, readiness wait, terminal teardown, daemon launch.

All I/O that touches real terminals / subprocesses / signals lives here so the
rest of `_cli/` remains pure orchestration. Tests stub these symbols via
`monkeypatch.setattr("keep._cli.spawn.<name>", ...)`.
"""

from __future__ import annotations

import json
import os
import shlex
import signal
import subprocess
import sys
import tempfile
import time
import tomllib
from pathlib import Path
from typing import Callable

import typer

from keep.agent_types import normalize_agent_type
from keep.agents.cc import CCAgent
from keep._state import paths as _paths
from keep._state.participants import participant_agent_type
from keep.state import (
    iter_workers,
    load_mission,
    mission_terminal_type,
    save_global,
    set_mission_container,
)
from keep.terminal import get_terminal
from keep.worker import WorkerInfo, resolve_worker, worker_cache_from_info


def spawn_claude_session(
    session: str,
    path: str | None,
    *,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    mission_id: str,
) -> str:
    """Spawn a Claude session inside the mission's shared terminal container.

    Ensures the container exists (creating it on first call for the mission),
    persists the ref onto ``mission["terminal_container"]``, and spawns the
    participant at the role-appropriate location. Returns the target_id of
    the newly spawned surface.
    """
    check_stop_hook_or_fail({"claude-code"})
    target_path = path or os.getcwd()

    prompt_fd, prompt_path = tempfile.mkstemp(prefix="keep-sysprompt-", suffix=".txt")
    try:
        os.write(prompt_fd, append_system_prompt.encode())
    finally:
        os.close(prompt_fd)

    claude_cmd = (
        f"claude --dangerously-skip-permissions {shlex.quote(bootstrap_prompt)}"
        f" --session-id {shlex.quote(session)}"
        f" --append-system-prompt-file {shlex.quote(prompt_path)}"
    )

    mission = load_mission(mission_id)
    if mission is None:
        raise RuntimeError(f"Mission {mission_id!r} not found")

    terminal = get_terminal(terminal_type)
    ref = mission.get("terminal_container")
    if ref is None:
        ref = terminal.ensure_mission_container(mission_id)
        set_mission_container(mission_id, ref)

    if role == "supervisor":
        role_index = 0
    elif role == "reviewer":
        role_index = 0
    elif role == "worker":
        # Re-read mission under the lock elsewhere; here we just need the
        # current worker count to pick a fresh index. Concurrent worker
        # creations in the same mission are serialised upstream by
        # `mutate_mission`, so the index we compute here stays correct.
        fresh = load_mission(mission_id) or mission
        role_index = sum(1 for _ in iter_workers(fresh))
    else:
        raise ValueError(f"unknown role: {role!r}")

    target_id = terminal.spawn_in_container(ref, role, role_index, target_path, claude_cmd)
    return target_id


def spawn_codex_session(
    session: str,
    path: str | None,
    *,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    mission_id: str,
) -> str:
    """Spawn a Codex interactive session inside the mission terminal container."""
    check_stop_hook_or_fail({"codex"})
    _ = session
    _ = append_system_prompt
    target_path = path or os.getcwd()

    codex_cmd = (
        "codex --dangerously-bypass-approvals-and-sandbox --no-alt-screen "
        + shlex.quote(bootstrap_prompt)
    )

    mission = load_mission(mission_id)
    if mission is None:
        raise RuntimeError(f"Mission {mission_id!r} not found")

    terminal = get_terminal(terminal_type)
    ref = mission.get("terminal_container")
    if ref is None:
        ref = terminal.ensure_mission_container(mission_id)
        set_mission_container(mission_id, ref)

    if role == "supervisor":
        role_index = 0
    elif role == "reviewer":
        role_index = 0
    elif role == "worker":
        fresh = load_mission(mission_id) or mission
        role_index = sum(1 for _ in iter_workers(fresh))
    else:
        raise ValueError(f"unknown role: {role!r}")

    return terminal.spawn_in_container(ref, role, role_index, target_path, codex_cmd)


def spawn_agent_session(
    session: str,
    path: str | None,
    *,
    agent_type: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    mission_id: str,
) -> str:
    if normalize_agent_type(agent_type) == "codex":
        return spawn_codex_session(
            session,
            path,
            bootstrap_prompt=bootstrap_prompt,
            append_system_prompt=append_system_prompt,
            terminal_type=terminal_type,
            role=role,
            mission_id=mission_id,
        )
    return spawn_claude_session(
        session,
        path,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        terminal_type=terminal_type,
        role=role,
        mission_id=mission_id,
    )


def is_ready_message_present(jsonl_path: str | Path | None, *, agent_type: str = "claude-code") -> bool:
    if not jsonl_path:
        return False
    if normalize_agent_type(agent_type) == "codex":
        return Path(jsonl_path).exists() and Path(jsonl_path).stat().st_size > 0
    agent = CCAgent()
    last = agent.last_message("", jsonl_path=jsonl_path)
    return last is not None and bool(last.text.strip())


def _find_stop_payload_after(started_at: float) -> tuple[str, dict] | None:
    for stop_path in sorted(_paths.STATE_DIR.glob("stop-*"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            if stop_path.stat().st_mtime < started_at:
                continue
            payload = json.loads(stop_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        session_id = payload.get("session_id") or stop_path.name.removeprefix("stop-")
        return str(session_id), payload
    return None


def _has_session_identity(info: WorkerInfo) -> bool:
    agent_type = normalize_agent_type(getattr(info, "agent_type", None))
    if agent_type == "codex":
        return bool(getattr(info, "thread_id", None) or getattr(info, "jsonl_path", None))
    return getattr(info, "jsonl_path", None) is not None


def wait_for_worker_ready(
    session: str,
    *,
    agent_type: str = "claude-code",
    terminal_type: str,
    cache_hint: dict | None = None,
    started_at: float | None = None,
    attempts: int = 10,
    interval: float = 0.2,
) -> WorkerInfo:
    resolved_agent_type = normalize_agent_type(agent_type)
    if resolved_agent_type == "codex":
        info = resolve_worker(
            session,
            terminal_type,
            agent_type=resolved_agent_type,
            cache_hint=cache_hint,
        )
    else:
        info = resolve_worker(session, terminal_type)
    if resolved_agent_type == "codex":
        wait_started_at = started_at or time.time()
        ready_attempts = max(attempts, 300)
        for _ in range(ready_attempts):
            stop_payload = _find_stop_payload_after(wait_started_at)
            if stop_payload is not None:
                thread_id, payload = stop_payload
                transcript_path = payload.get("transcript_path")
                info.thread_id = thread_id
                if transcript_path:
                    info.jsonl_path = Path(transcript_path)
                if info.target_id is None and cache_hint:
                    info.target_id = cache_hint.get("target_id")
                if payload.get("last_assistant_message"):
                    return info
            time.sleep(interval)
            info = resolve_worker(
                session,
                terminal_type,
                agent_type=resolved_agent_type,
                cache_hint=cache_hint,
            )
        raise TimeoutError(f"Session '{session}' did not reach ready state")

    jsonl_attempts = max(attempts, 300)
    for _ in range(jsonl_attempts - 1):
        if info.jsonl_path is not None:
            break
        time.sleep(interval)
        info = resolve_worker(session, terminal_type)

    if info.jsonl_path is None:
        return info

    ready_attempts = max(attempts, 300)
    for _ in range(ready_attempts):
        if is_ready_message_present(info.jsonl_path, agent_type=resolved_agent_type):
            return info
        time.sleep(interval)
    raise TimeoutError(f"Session '{session}' did not reach ready state")


def spawn_and_wait_for_ready(
    session: str,
    path: str | None,
    *,
    agent_type: str = "claude-code",
    terminal_type: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    role: str,
    mission_id: str,
    on_failure: Callable[[], None] | None = None,
) -> tuple[dict, WorkerInfo]:
    """Spawn an agent session and block until transcript/hook signals readiness.

    Returns (cache, info). On timeout or missing jsonl, invokes `on_failure`
    (for rollback cleanup) then raises `typer.Exit(1)` after printing the error.
    """
    started_at = time.time()
    target_id = spawn_agent_session(
        session,
        path,
        agent_type=agent_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        terminal_type=terminal_type,
        role=role,
        mission_id=mission_id,
    )
    try:
        info = wait_for_worker_ready(
            session,
            agent_type=agent_type,
            terminal_type=terminal_type,
            cache_hint={"target_id": target_id},
            started_at=started_at,
        )
    except TimeoutError as exc:
        typer.echo(str(exc), err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    if not _has_session_identity(info):
        typer.echo(f"未找到可用的 session '{session}'", err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    cache = worker_cache_from_info(info)
    if target_id and not cache.get("target_id"):
        cache["target_id"] = target_id
    return cache, info


def kill_and_close_worker(worker: dict, mission: dict) -> None:
    """Kill worker process (if running) and close its terminal surface. Best-effort, never raises."""
    try:
        if participant_agent_type(worker) == "codex":
            info = resolve_worker(
                worker["session"],
                None,
                agent_type="codex",
                cache_hint=worker.get("cache") or {},
            )
        else:
            info = resolve_worker(worker["session"], None)
        if info.running and info.pid:
            try:
                os.kill(info.pid, signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
        target_id = (worker.get("cache") or {}).get("target_id")
        if target_id:
            try:
                get_terminal(mission_terminal_type(mission)).close(target_id)
            except Exception:
                pass
    except Exception:
        pass


def launch_daemon(global_state: dict, foreground: bool) -> None:
    global_state["stopped"] = False
    if foreground:
        global_state["daemon_pid"] = os.getpid()
        save_global(global_state)
        typer.echo(f"Daemon 已启动，PID {os.getpid()}，前台模式。")
        from keep.daemon import run_daemon
        run_daemon()
        return

    _paths.STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(_paths.STATE_DIR / "daemon.log", "a", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            [sys.executable, "-m", "keep.daemon_runner"],
            stdout=log_file,
            stderr=log_file,
        )
    global_state["daemon_pid"] = proc.pid
    save_global(global_state)
    typer.echo(f"Daemon 已启动，PID {proc.pid}，后台模式。")


def _codex_hook_paths() -> list[Path]:
    paths = [Path.home() / ".codex" / "hooks.json"]
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode == 0:
            paths.append(Path(result.stdout.strip()) / ".codex" / "hooks.json")
    except Exception:
        pass
    deduped: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        if path in seen:
            continue
        seen.add(path)
        deduped.append(path)
    return deduped


def _check_claude_stop_hook(errors: list[str]) -> None:
    state_dir = _paths.STATE_DIR
    hook_script = state_dir / "on-stop.sh"
    config_dir = os.environ.get("CLAUDE_CONFIG_DIR") or str(Path.home() / ".claude")
    settings_path = Path(config_dir) / "settings.json"

    if not hook_script.exists():
        errors.append(
            f"  缺少 stop hook 脚本: {hook_script}\n"
            f"  修复：cat > {hook_script} << 'EOF'\n"
            f"  #!/bin/bash\n"
            f"  INPUT=$(cat)\n"
            f"  SESSION_ID=$(echo \"$INPUT\" | jq -r '.session_id')\n"
            f"  echo \"$INPUT\" > {state_dir}/stop-${{SESSION_ID}}\n"
            f"  EOF\n"
            f"  chmod +x {hook_script}"
        )

    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except Exception as exc:
            errors.append(
                f"  Claude settings 解析失败: {settings_path}\n"
                f"  错误: {exc}\n"
                f"  修复：检查 JSON 语法或重新生成 settings.json"
            )
            settings = None
        if settings is not None:
            stop_hooks = settings.get("hooks", {}).get("Stop", [])
            hook_str = json.dumps(stop_hooks)
            # Match both absolute path and ~ shorthand
            hook_tilde = str(hook_script).replace(str(Path.home()), "~")
            if str(hook_script) not in hook_str and hook_tilde not in hook_str:
                errors.append(
                    f"  Claude settings 未配置 stop hook: {settings_path}\n"
                    f"  修复：在 settings.json 的 hooks.Stop 中添加:\n"
                    f'  {{"type": "command", "command": "bash {hook_script}"}}'
                )
    else:
        errors.append(
            f"  未找到 Claude settings: {settings_path}\n"
            f"  修复：创建 {settings_path} 并配置 hooks.Stop"
        )


def _check_codex_stop_hook(errors: list[str]) -> None:
    hook_script = _paths.STATE_DIR / "on-stop.sh"
    config_path = Path.home() / ".codex" / "config.toml"
    if not hook_script.exists():
        errors.append(
            f"  缺少 stop hook 脚本: {hook_script}\n"
            f"  修复：按 Claude 同步创建该脚本"
        )
        return

    if not config_path.exists():
        errors.append(
            f"  未找到 Codex config: {config_path}\n"
            "  修复：创建 ~/.codex/config.toml 并启用 [features].codex_hooks = true"
        )
        return

    try:
        config = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(
            f"  Codex config 解析失败: {config_path}\n"
            f"  错误: {exc}"
        )
        return

    if not bool(config.get("features", {}).get("codex_hooks")):
        errors.append(
            f"  Codex hooks feature 未启用: {config_path}\n"
            "  修复：在 config.toml 中添加 [features] codex_hooks = true"
        )

    hook_tilde = str(hook_script).replace(str(Path.home()), "~")
    hook_configured = False
    for hooks_path in _codex_hook_paths():
        if not hooks_path.exists():
            continue
        try:
            hooks = json.loads(hooks_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        stop_hooks = hooks.get("hooks", {}).get("Stop", [])
        hook_str = json.dumps(stop_hooks, ensure_ascii=False)
        if str(hook_script) in hook_str or hook_tilde in hook_str:
            hook_configured = True
            break

    if not hook_configured:
        searched = ", ".join(str(path) for path in _codex_hook_paths())
        errors.append(
            "  Codex hooks 未配置 stop hook\n"
            f"  已检查: {searched}\n"
            f"  修复：在 hooks.Stop 中添加 command 指向 {hook_script}"
        )


def check_stop_hook_or_fail(agent_types: set[str] | None = None) -> None:
    """Block mission start/spawn if required stop hooks are not correctly configured."""
    resolved_types = {normalize_agent_type(agent) for agent in (agent_types or {"claude-code"})}
    errors: list[str] = []
    if "claude-code" in resolved_types:
        _check_claude_stop_hook(errors)
    if "codex" in resolved_types:
        _check_codex_stop_hook(errors)

    if errors:
        typer.echo(
            "Mission 无法启动：stop hook 未生效，worker 完成后 supervisor 将收不到通知。\n"
            + "\n".join(errors),
            err=True,
        )
        raise typer.Exit(1)
