"""`keep <mission_id> task ...` verb dispatch.

Handles task CRUD plus the blocking `task review proposed|submitted` flow that
waits on the daemon/reviewer to produce a final verdict.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import typer

from keep._daemon.review import cancel_pending_mission_stop
from keep._cli.constants import COMMAND_HELP
from keep._cli.helpers import (
    ensure_file_in_messages_dir,
    extract_named_option,
    parse_task_update_payload,
    require_mission_active,
)
from keep.state import (
    add_review_event,
    create_task,
    get_review_event,
    get_task,
    list_tasks,
    load_mission,
    remove_task,
    update_task,
)

_STATUS_DISPLAY = {"awaiting_review": "proposed"}
_REVIEW_POLL_INTERVAL = 2
_REVIEW_TIMEOUT_SECONDS = 1800


def _wait_for_review_event(
    mission_id: str, task_ids: list[str], deadline: float
) -> str | None:
    """Poll mission.json until daemon attaches a review_event for this batch."""
    while time.time() < deadline:
        time.sleep(_REVIEW_POLL_INTERVAL)
        m = load_mission(mission_id)
        if m is None:
            typer.echo("Mission 已删除。", err=True)
            raise typer.Exit(1)
        for ev in reversed(m.get("review_events", [])):
            if (
                ev.get("type") == "task_proposed_review"
                and not ev.get("final_verdict")
                and set(ev.get("task_ids", [])) == set(task_ids)
            ):
                return ev.get("id")
    return None


def _wait_for_final_verdict(mission_id: str, event_id: str, deadline: float) -> None:
    while time.time() < deadline:
        ev = get_review_event(mission_id, event_id)
        if ev and ev.get("final_verdict"):
            verdict = ev["final_verdict"]
            if verdict == "approved":
                typer.echo("approved")
                raise typer.Exit()
            if verdict == "cancelled":
                typer.echo("review cancelled", err=True)
                raise typer.Exit(1)
            typer.echo(f"rejected by reviewer.{_reviewer_rationale_text(ev)}", err=True)
            raise typer.Exit(1)
        time.sleep(_REVIEW_POLL_INTERVAL)

    typer.echo("超时：reviewer 未在 30 分钟内完成判决。", err=True)
    raise typer.Exit(1)


def _cmd_create(mission_id: str, mission: dict, payload: list[str]) -> None:
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["create"])
        raise typer.Exit()
    if not payload:
        typer.echo("Task subject is required", err=True)
        raise typer.Exit(2)
    require_mission_active(mission_id, mission)
    task = create_task(mission_id, subject=payload[0])
    cancel_pending_mission_stop(mission_id)
    typer.echo(f"Task '{task['id']}' created: {task['subject']}")


def _cmd_update(mission_id: str, payload: list[str]) -> None:
    task_id, patch = parse_task_update_payload(payload)
    if get_task(mission_id, task_id) is None:
        typer.echo(f"Task '{task_id}' 不存在", err=True)
        raise typer.Exit(1)
    task = update_task(mission_id, task_id, patch)
    cancel_pending_mission_stop(mission_id)
    typer.echo(f"Task '{task['id']}' updated")


def _cmd_remove(mission_id: str, payload: list[str]) -> None:
    if not payload:
        typer.echo("Task id is required", err=True)
        raise typer.Exit(2)
    task_id = payload[0]
    if not remove_task(mission_id, task_id):
        typer.echo(f"Task '{task_id}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(f"Task '{task_id}' removed")


def _cmd_list(mission_id: str, payload: list[str]) -> None:
    status_filter, _ = extract_named_option(payload, "--status")
    tasks = list_tasks(mission_id)
    if status_filter:
        tasks = [t for t in tasks if t.get("status") == status_filter]
    if not tasks:
        typer.echo("(无 task)")
        return
    typer.echo("\n".join(
        f"#{task['id']} [{_STATUS_DISPLAY.get(task['status'], task['status'])}] {task['subject']}"
        for task in tasks
    ))


def _cmd_show(mission_id: str, payload: list[str]) -> None:
    if not payload:
        typer.echo("Task id is required", err=True)
        raise typer.Exit(2)
    task = get_task(mission_id, payload[0])
    if task is None:
        typer.echo(f"Task '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(task, ensure_ascii=False, indent=2))


def _cmd_review(mission_id: str, mission: dict, payload: list[str]) -> None:
    require_mission_active(mission_id, mission)
    review_type = payload[0] if payload else "proposed"
    if review_type not in {"proposed", "submitted"}:
        typer.echo(
            f"无效的 review 类型 '{review_type}'。用法：task review proposed|submitted <rationale_file>",
            err=True,
        )
        raise typer.Exit(2)
    rationale_file_raw = payload[1] if len(payload) > 1 else None
    if not rationale_file_raw:
        typer.echo(f"task review {review_type} 需要 <rationale_file>", err=True)
        raise typer.Exit(2)
    rationale_path = ensure_file_in_messages_dir(
        mission, rationale_file_raw, label="rationale file", record_index=True
    )

    tasks = list_tasks(mission_id)
    deadline = time.time() + _REVIEW_TIMEOUT_SECONDS

    if review_type == "proposed":
        batch = [t for t in tasks if t.get("status") == "proposed"]
        if not batch:
            typer.echo("无 proposed tasks 可送审。请先创建 task（默认 status=proposed）。", err=True)
            raise typer.Exit(1)
        task_ids = [t["id"] for t in batch]
        for t in batch:
            update_task(
                mission_id, t["id"],
                {"status": "awaiting_review", "review_rationale": str(rationale_path)},
            )
        ids_str = ", ".join(f"#{tid}" for tid in task_ids)
        typer.echo(f"Reviewing {len(batch)} proposed tasks: {ids_str}")

        event_id = _wait_for_review_event(mission_id, task_ids, deadline)
        if not event_id:
            typer.echo("超时：reviewer 未在 30 分钟内创建审批事件。", err=True)
            raise typer.Exit(1)
    else:  # submitted
        batch = [t for t in tasks if t.get("status") == "submitted"]
        if not batch:
            typer.echo("无 submitted tasks 可送审。请先用 task update --status submitted 标记。", err=True)
            raise typer.Exit(1)
        task_ids = [t["id"] for t in batch]
        subjects = [f"#{t['id']} {t.get('subject', '')}" for t in batch]
        event_data = {
            "type": "task_submitted_review",
            "task_ids": task_ids,
            "task_subjects": subjects,
            "rationale": str(rationale_path),
            "reviewer_verdicts": {},
        }
        event_id = add_review_event(mission_id, event_data)
        ids_str = ", ".join(f"#{tid}" for tid in task_ids)
        typer.echo(f"Reviewing {len(batch)} submitted tasks: {ids_str}")

    _wait_for_final_verdict(mission_id, event_id, deadline)


def dispatch(mission_id: str, mission: dict, command: str | None, payload: list[str]) -> None:
    if command == "create":
        _cmd_create(mission_id, mission, payload)
    elif command == "update":
        _cmd_update(mission_id, payload)
    elif command == "remove":
        _cmd_remove(mission_id, payload)
    elif command == "list":
        _cmd_list(mission_id, payload)
    elif command == "show":
        _cmd_show(mission_id, payload)
    elif command == "review":
        _cmd_review(mission_id, mission, payload)
    else:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    verdicts = dict(event.get("reviewer_verdicts") or {})
    for reviewer_id, rationale_path in dict(event.get("reviewer_rationales") or {}).items():
        if verdicts.get(reviewer_id) != "reject":
            continue
        try:
            rationale_text = Path(rationale_path).read_text(encoding="utf-8")
        except OSError:
            rationale_text = f"(rationale file not found: {rationale_path})"
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    try:
        return "\n" + Path(rationale_path).read_text(encoding="utf-8")
    except OSError:
        return f"\n(rationale file not found: {rationale_path})"
