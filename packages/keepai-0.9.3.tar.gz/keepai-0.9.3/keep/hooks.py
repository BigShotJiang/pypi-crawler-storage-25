"""Keep hook 系统：async fire-and-forget，不阻塞调用方。

Hook 配置来源：$KEEP_HOME/hooks.json（可选）。

格式：
  {
    "silent":     ["command", "arg1"],
    "align":      ["command", "arg1"],
    "idle":       ["command", "arg1"]
  }

每个事件对应一条命令。触发时将 payload 序列化为 JSON 通过 stdin 传入。
命令失败只 log 不抛异常。

事件：
  silent     — Worker 心跳停跳，Supervisor 可能需要介入
  align      — 所有 task 完成，Supervisor 需要对齐 mission 目标
  idle       — Mission 内所有 Worker 均已停止（安静状态）
"""

from __future__ import annotations

import json
import logging
import subprocess
import threading
from pathlib import Path
from typing import Any

from keep._state import paths as _paths

log = logging.getLogger("keep.hooks")


def _hooks_config_file() -> Path:
    return _paths.STATE_DIR / "hooks.json"

# 支持的 hook 事件名
HOOK_EVENTS = frozenset({"silent", "idle"})

_hooks_cache: dict = {}
_hooks_mtime: float = 0.0


def _load_hooks() -> dict[str, list[str]]:
    """Load hook commands from $KEEP_HOME/hooks.json with mtime-based caching.

    Returns an empty dict if the file doesn't exist or is malformed.
    Keys are event names; values are command lists (subprocess-style).
    File is only re-read when its mtime changes; otherwise the cached result
    is returned immediately.
    """
    global _hooks_cache, _hooks_mtime
    path = _hooks_config_file()
    try:
        mtime = path.stat().st_mtime
        if mtime == _hooks_mtime:
            return _hooks_cache
    except FileNotFoundError:
        return {}
    except Exception:
        return _hooks_cache  # 返回上次缓存，不抛异常

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("Failed to read hooks.json: %s", e)
        return _hooks_cache
    if not isinstance(raw, dict):
        log.warning("hooks.json must be a JSON object, got %s", type(raw).__name__)
        return _hooks_cache
    result: dict[str, list[str]] = {}
    for event, cmd in raw.items():
        if not isinstance(cmd, list) or not all(isinstance(c, str) for c in cmd):
            log.warning("hooks.json: event %r command must be a list of strings, skipping", event)
            continue
        result[event] = cmd
    _hooks_cache = result
    _hooks_mtime = mtime
    return _hooks_cache


def _run_hook(cmd: list[str], payload: dict[str, Any]) -> None:
    """Execute a single hook command synchronously (called from background thread).

    Feeds payload as JSON on stdin. Logs failures; never raises.
    """
    payload_json = json.dumps(payload, ensure_ascii=False)
    try:
        result = subprocess.run(
            cmd,
            input=payload_json,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            log.warning(
                "Hook %r exited with code %d: %s",
                cmd[0],
                result.returncode,
                (result.stderr or result.stdout)[:200],
            )
    except subprocess.TimeoutExpired:
        log.warning("Hook %r timed out after 30s", cmd[0])
    except Exception as e:
        log.warning("Hook %r failed: %s", cmd[0], e)


def fire_hook(hook_name: str, payload: dict[str, Any]) -> None:
    """Fire a named hook asynchronously (fire-and-forget).

    Looks up the command for `hook_name` in hooks.json.  If no command is
    configured for this event, returns immediately with no side-effects.

    The hook command runs in a daemon thread so it never blocks the caller
    and does not prevent process exit.  Failures are logged at WARNING level;
    exceptions are never propagated to the caller.

    Args:
        hook_name: One of "silent", "align", "idle".
        payload:   Dict that will be JSON-serialised and passed to the hook
                   command on stdin.
    """
    if hook_name not in HOOK_EVENTS:
        log.debug("fire_hook: unknown event %r, ignoring", hook_name)
        return

    hooks = _load_hooks()
    cmd = hooks.get(hook_name)
    if not cmd:
        log.debug("fire_hook: no command configured for %r", hook_name)
        return

    enriched = {"event": hook_name, **payload}
    t = threading.Thread(
        target=_run_hook,
        args=(cmd, enriched),
        daemon=True,
        name=f"keep-hook-{hook_name}",
    )
    t.start()
    log.debug("fire_hook: dispatched %r → %r (thread %s)", hook_name, cmd[0], t.name)
