"""Codex CLI implementation of `keep.agent.Agent`.

For now `keep` only needs one read-path capability from the provider:
materialize the latest assistant message for an existing session.
Codex exposes this directly via `codex exec resume ... --output-last-message`.
"""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from keep.agent import AgentMessage


class CodexAgent:
    name = "codex"

    def last_message(
        self,
        session: str,
        *,
        session_id: str | None = None,
    ) -> AgentMessage | None:
        resolved_session = session_id or session
        if not resolved_session:
            return None

        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
            tmp_path = Path(tmp.name)
        try:
            result = subprocess.run(
                [
                    "codex",
                    "exec",
                    "resume",
                    resolved_session,
                    "--ephemeral",
                    "--output-last-message",
                    str(tmp_path),
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=20,
            )
            if result.returncode != 0:
                return None
            if not tmp_path.exists() or tmp_path.stat().st_size == 0:
                return None
            text = tmp_path.read_text(encoding="utf-8", errors="replace")
        except (OSError, subprocess.SubprocessError):
            return None
        finally:
            tmp_path.unlink(missing_ok=True)

        if not text.strip():
            return None
        return AgentMessage(text=text, ts=None)
