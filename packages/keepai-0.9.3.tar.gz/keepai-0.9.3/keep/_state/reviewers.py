"""Reviewer + Review Event CRUD (stored inside mission state).

Reviewers live inside mission state under the "reviewers" key.
Each reviewer is a dict with at minimum {"id": ..., "session": ..., "role": "reviewer"}.
Reviewer IDs are UUID4 (opaque).

Review events live inside mission state under "review_events".
Each event is a dict with at minimum {"id": ..., ...event_data}.
Event IDs are generated as "re<n>" (sequential, scoped to the mission).
"""

from __future__ import annotations

import uuid
from typing import Any, Iterator

from keep.agent_types import normalize_agent_type
from keep._state.missions import load_mission, mutate_mission


def _next_seq_id(mission: dict, key: str, prefix: str) -> str:
    """生成下一个序列 ID。使用最大值 + 1，避免删除后 ID 碰撞。"""
    max_n = 0
    for item in mission.get(key, []):
        raw = str(item.get("id", "")).removeprefix(prefix)
        try:
            max_n = max(max_n, int(raw))
        except ValueError:
            pass
    return f"{prefix}{max_n + 1}"


def _next_reviewer_id(mission: dict[str, Any]) -> str:
    return str(uuid.uuid4())


def add_reviewer(mission_id: str, reviewer_data: dict) -> str:
    """Add a reviewer to a mission. Returns the generated reviewer_id."""
    with mutate_mission(mission_id) as mission:
        mission.setdefault("reviewers", [])
        reviewer_id = _next_reviewer_id(mission)
        reviewer = dict(reviewer_data)
        reviewer["agent_type"] = normalize_agent_type(reviewer.get("agent_type"))
        reviewer["id"] = reviewer_id
        mission["reviewers"].append(reviewer)
    return reviewer_id


def remove_reviewer(mission_id: str, reviewer_id: str) -> None:
    """Remove a reviewer from a mission. Raises ValueError if not found."""
    with mutate_mission(mission_id) as mission:
        reviewers = mission.get("reviewers", [])
        new_reviewers = [r for r in reviewers if r.get("id") != reviewer_id]
        if len(new_reviewers) == len(reviewers):
            raise ValueError(f"Reviewer '{reviewer_id}' 不存在")
        mission["reviewers"] = new_reviewers


def iter_reviewers(mission_id: str) -> Iterator[dict]:
    """Iterate over all reviewers in a mission."""
    mission = load_mission(mission_id)
    if mission is None:
        raise ValueError(f"Mission '{mission_id}' 不存在")
    yield from mission.get("reviewers", [])


def get_reviewer(mission_id: str, reviewer_id: str) -> dict:
    """Get a single reviewer by id. Raises ValueError if not found."""
    mission = load_mission(mission_id)
    if mission is None:
        raise ValueError(f"Mission '{mission_id}' 不存在")
    for r in mission.get("reviewers", []):
        if r.get("id") == reviewer_id:
            return r
    raise ValueError(f"Reviewer '{reviewer_id}' 不存在")


def update_reviewer(mission_id: str, reviewer_id: str, **kwargs) -> dict:
    """Update fields on a reviewer. Raises ValueError if not found."""
    with mutate_mission(mission_id) as mission:
        for r in mission.get("reviewers", []):
            if r.get("id") == reviewer_id:
                r.update(kwargs)
                return r
        raise ValueError(f"Reviewer '{reviewer_id}' 不存在")


# ── Review Events ─────────────────────────────────────────────


def _next_review_event_id(mission: dict[str, Any]) -> str:
    return _next_seq_id(mission, "review_events", "re")


def add_review_event(mission_id: str, event_data: dict) -> str:
    """Add a review event to a mission. Returns the generated event_id."""
    with mutate_mission(mission_id) as mission:
        mission.setdefault("review_events", [])
        event_id = _next_review_event_id(mission)
        event = dict(event_data)
        event["id"] = event_id
        event.setdefault("round", 1)
        mission["review_events"].append(event)
    return event_id


def get_review_event(mission_id: str, event_id: str) -> dict:
    """Get a single review event by id. Raises ValueError if not found."""
    mission = load_mission(mission_id)
    if mission is None:
        raise ValueError(f"Mission '{mission_id}' 不存在")
    for e in mission.get("review_events", []):
        if e.get("id") == event_id:
            return e
    raise ValueError(f"Review event '{event_id}' 不存在")


def update_review_event(mission_id: str, event_id: str, **kwargs) -> dict:
    """Update fields on a review event. Raises ValueError if not found."""
    with mutate_mission(mission_id) as mission:
        for e in mission.get("review_events", []):
            if e.get("id") == event_id:
                e.update(kwargs)
                return e
        raise ValueError(f"Review event '{event_id}' 不存在")
