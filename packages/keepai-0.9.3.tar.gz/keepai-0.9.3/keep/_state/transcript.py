"""Per-mission supervisor-worker dialogue record (append-only JSONL).

  ~/.keep/missions/<name>.json          # mission state (schema unchanged)
  ~/.keep/missions/<name>/transcript.jsonl   # dialogue record

Write points:
  - cli.send / cli.wake   → sup_to_worker, kind=send|wake
  - daemon stop handler   → worker_to_sup, kind=stop_reply

Observability guarantee: `append_transcript` catches all errors and logs them
at WARNING. It never raises. The observed system must not be broken by a
failure to observe it.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict

from keep._state.missions import _mission_resource_dir

_log = logging.getLogger("keep.state")

Direction = Literal["sup_to_worker", "worker_to_sup"]
Kind = Literal["send", "wake", "stop_reply"]


class TranscriptEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ts: str
    direction: Direction
    worker: str
    content: str
    kind: Kind


def _transcript_file(mission_name: str) -> Path:
    return _mission_resource_dir(mission_name) / "transcript.jsonl"


def _parse_iso_utc(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def append_transcript(
    mission_name: str,
    *,
    direction: str,
    worker: str,
    content: str,
    kind: str,
) -> None:
    """Append one entry to a mission's transcript. Never raises.

    All failures (schema validation, filesystem, encoding) are caught and
    logged. Callers must not rely on successful persistence.
    """
    try:
        entry = TranscriptEntry(
            ts=datetime.now(timezone.utc).isoformat(),
            direction=direction,  # type: ignore[arg-type]
            worker=worker,
            content=content,
            kind=kind,  # type: ignore[arg-type]
        )
        d = _mission_resource_dir(mission_name)
        d.mkdir(parents=True, exist_ok=True)
        with open(_transcript_file(mission_name), "a", encoding="utf-8") as f:
            f.write(entry.model_dump_json() + "\n")
    except Exception as e:
        _log.warning(
            "Failed to append transcript (mission=%s, kind=%s): %s",
            mission_name, kind, e,
        )


def read_transcript(
    mission_name: str,
    *,
    worker: str | None = None,
    tail: int | None = None,
    since: str | None = None,
) -> list[TranscriptEntry]:
    """Return transcript entries oldest-first, with optional filters.

    - worker: keep only entries where `worker` matches
    - since:  keep only entries with ts >= since (ISO8601, tolerant of Z suffix)
    - tail:   keep only the last N entries (applied after worker/since)

    Missing file → []. Malformed lines are skipped silently.
    """
    f = _transcript_file(mission_name)
    if not f.exists():
        return []

    try:
        raw_lines = f.read_text(encoding="utf-8").splitlines()
    except OSError as e:
        _log.warning("Failed to read transcript for %s: %s", mission_name, e)
        return []

    since_dt = _parse_iso_utc(since) if since else None

    entries: list[TranscriptEntry] = []
    for raw in raw_lines:
        if not raw.strip():
            continue
        try:
            entry = TranscriptEntry.model_validate_json(raw)
        except Exception:
            # Partial writes or schema-skew lines are ignored silently.
            continue
        if worker is not None and entry.worker != worker:
            continue
        if since_dt is not None:
            entry_dt = _parse_iso_utc(entry.ts)
            if entry_dt is None or entry_dt < since_dt:
                continue
        entries.append(entry)

    if tail is not None and tail > 0:
        entries = entries[-tail:]
    return entries
