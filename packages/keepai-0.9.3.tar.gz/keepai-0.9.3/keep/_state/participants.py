"""Participant (worker/supervisor) helpers.

Participant = {session, role, agent_type?, cache?, name?, path?, contract?}
  role:  "worker" | "supervisor"
  agent_type: "claude-code" | "codex"（缺省视为 claude-code）
  cache: 运行时信息（pid/target_id/jsonl_path/thread_id），可选

terminal_type 不存在 participant 上：mission 是唯一来源。

Mutator pattern (并发安全)：
  add_*/remove_* 接 mission_id，内部通过 `mutate_mission` 取 per-mission
  file lock，load → mutate → save 原子化。caller **不要** 自己
  `load_mission + save_mission` —— 那样绕开了锁，会和 daemon / 其他 CLI
  进程 race 写（后写覆盖前写，state 丢失）。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from keep.agent_types import normalize_agent_type
from keep._state.missions import list_missions, load_mission, mutate_mission


def _participants_by_role(mission: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [p for p in mission.get("participants", []) if p.get("role") == role]


def participant_agent_type(participant: dict[str, Any]) -> str:
    return normalize_agent_type(participant.get("agent_type"))


def worker_session_id(worker: dict[str, Any]) -> str | None:
    """从 participant dict 提取 session ID（JSONL 文件名 stem 或 session name）。"""
    cache = worker.get("cache") or {}
    thread_id = cache.get("thread_id", "")
    if thread_id:
        return str(thread_id)
    jsonl = cache.get("jsonl_path", "")
    if jsonl:
        return Path(jsonl).stem
    return worker.get("session")


def iter_workers(mission: dict[str, Any]) -> list[dict[str, Any]]:
    """返回 mission 里所有 role=worker 的 participant。"""
    return _participants_by_role(mission, "worker")


def find_worker(mission: dict[str, Any], session: str) -> dict[str, Any] | None:
    return next(
        (p for p in iter_workers(mission) if p.get("session") == session),
        None,
    )


def find_worker_globally(session: str) -> str | None:
    """检查 session 是否已作为 worker 在任何 mission 中，返回 mission name 或 None。"""
    for name in list_missions():
        m = load_mission(name)
        if m and find_worker(m, session):
            return name
    return None


def find_supervisor(mission: dict[str, Any]) -> dict[str, Any] | None:
    """返回 mission 的 supervisor participant（若有）。"""
    return next(iter(_participants_by_role(mission, "supervisor")), None)


def add_worker(
    mission_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool = False,
) -> dict[str, Any]:
    """Add a worker to the mission under file lock.

    Cross-mission uniqueness is checked **before** taking the lock to avoid
    holding a per-mission lock while scanning every mission file. The
    in-mission duplicate check happens inside the lock to stay race-free for
    the common case (two adds to the same mission at once).
    """
    existing = find_worker_globally(session)
    if existing and existing != mission_id:
        raise ValueError(
            f"Worker '{session}' 已在 mission '{existing}' 中，"
            f"先用 keep {existing} worker remove {session} 移除"
        )
    participant = {
        "session": session,
        "role": "worker",
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "agent_type": normalize_agent_type(agent_type),
        "cache": cache,
        "bootstrapped": bootstrapped,
    }
    with mutate_mission(mission_id) as mission:
        if find_worker(mission, session):
            raise ValueError(f"Worker '{session}' 已在此 mission 中")
        mission.setdefault("participants", []).append(participant)
    return participant


def remove_worker(mission_id: str, session: str) -> bool:
    with mutate_mission(mission_id) as mission:
        participants = mission.get("participants", [])
        new_participants = [
            p for p in participants
            if not (p.get("role") == "worker" and p.get("session") == session)
        ]
        if len(new_participants) == len(participants):
            return False
        mission["participants"] = new_participants
    return True


def add_supervisor(
    mission_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
) -> dict[str, Any]:
    """添加 mission 的 supervisor（lock 内原子化）。已有 supervisor 时直接拒绝。"""
    participant = {
        "session": session,
        "role": "supervisor",
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "agent_type": normalize_agent_type(agent_type),
        "cache": cache,
    }
    with mutate_mission(mission_id) as mission:
        mission.setdefault("participants", [])
        old_sup = find_supervisor(mission)
        if old_sup:
            old_id = old_sup.get("name") or old_sup.get("session", "")
            raise ValueError(
                f"Mission already has a supervisor ({old_id}). "
                "Remove it first: keep supervisor remove"
            )
        mission["participants"].append(participant)
    return participant


def remove_supervisor(mission_id: str) -> bool:
    with mutate_mission(mission_id) as mission:
        if not find_supervisor(mission):
            return False
        mission["participants"] = [
            p for p in mission.get("participants", [])
            if p.get("role") != "supervisor"
        ]
    return True
