"""Shared filesystem paths, atomic write, name validation.

Everything else in `_state` depends on this module. Keep it dependency-free.

Path layout is driven by the ``KEEP_HOME`` environment variable (default
``~/.keep``). Every STATE_DIR / GLOBAL_FILE / MISSIONS_DIR access re-reads the
env var, so tests can do ``monkeypatch.setenv("KEEP_HOME", str(tmp_path))``
and any subsequent path lookup picks it up — including inside subprocesses,
which inherit the env.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

_log = logging.getLogger("keep.state")

_MISSION_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

DEFAULT_TERMINAL = "cmux"
VALID_TERMINALS = frozenset({"cmux", "tmux", "terminal", "kitty", "iterm2"})


def _keep_home() -> Path:
    return Path(os.environ.get("KEEP_HOME", "~/.keep")).expanduser()


# Module-level dynamic attributes. Every read re-evaluates the env var, so
# `monkeypatch.setenv("KEEP_HOME", ...)` propagates without further plumbing.
_DYNAMIC_NAMES = {"STATE_DIR", "GLOBAL_FILE", "MISSIONS_DIR", "KEEP_HOME"}


def __getattr__(name: str):
    if name in _DYNAMIC_NAMES:
        home = _keep_home()
        if name in ("STATE_DIR", "KEEP_HOME"):
            return home
        if name == "GLOBAL_FILE":
            return home / "global.json"
        if name == "MISSIONS_DIR":
            return home / "missions"
    raise AttributeError(f"module 'keep._state.paths' has no attribute {name!r}")


def _ensure_dirs() -> None:
    home = _keep_home()
    home.mkdir(parents=True, exist_ok=True)
    (home / "missions").mkdir(parents=True, exist_ok=True)


def atomic_write_text(path: Path, text: str) -> None:
    """Write text to path atomically: write to .tmp then os.replace.

    Prevents partial / corrupt JSON if the process dies mid-write.
    """
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _validate_mission_name(name: str) -> None:
    if not _MISSION_NAME_RE.match(name):
        raise ValueError(
            f"Mission name 不合法: '{name}'（只允许字母、数字、-、_，不能以 -/_ 开头）"
        )
