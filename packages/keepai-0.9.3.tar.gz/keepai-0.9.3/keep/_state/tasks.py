"""Per-mission task store."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from filelock import FileLock

from keep._state import paths as _paths
from keep._state.paths import atomic_write_text


def task_store_dir(mission_id: str) -> Path:
    return _paths.STATE_DIR / "keep_id" / "tasks" / mission_id


def task_file(mission_id: str, task_id: str) -> Path:
    return task_store_dir(mission_id) / f"{task_id}.json"


def highwatermark_file(mission_id: str) -> Path:
    return task_store_dir(mission_id) / ".highwatermark"


def lock_file(mission_id: str) -> Path:
    return task_store_dir(mission_id) / ".lock"


def _ensure_task_store(mission_id: str) -> Path:
    task_dir = task_store_dir(mission_id)
    task_dir.mkdir(parents=True, exist_ok=True)
    lf = lock_file(mission_id)
    if not lf.exists():
        lf.write_text("", encoding="utf-8")
    hw = highwatermark_file(mission_id)
    if not hw.exists():
        hw.write_text("0", encoding="utf-8")
    return task_dir


def _task_record(
    *,
    task_id: str,
    subject: str,
    description: str = "",
    status: str = "proposed",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "id": task_id,
        "subject": subject,
        "description": description,
        "status": status,
        "owner": owner,
        "blocks": blocks or [],
        "blockedBy": blocked_by or [],
    }


def _write_task(mission_id: str, task: dict[str, Any]) -> None:
    _ensure_task_store(mission_id)
    atomic_write_text(
        task_file(mission_id, str(task["id"])),
        json.dumps(task, ensure_ascii=False, indent=2),
    )


def next_task_id(mission_id: str) -> str:
    """Atomically allocate the next task ID, preventing concurrent collisions."""
    _ensure_task_store(mission_id)
    hw = highwatermark_file(mission_id)
    with FileLock(str(lock_file(mission_id))):
        current = int(hw.read_text(encoding="utf-8").strip() or "0")
        new_value = current + 1
        atomic_write_text(hw, str(new_value))
    return str(new_value)


def create_task(
    mission_id: str,
    *,
    subject: str,
    description: str = "",
    status: str = "proposed",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    task = _task_record(
        task_id=next_task_id(mission_id),
        subject=subject,
        description=description,
        status=status,
        owner=owner,
        blocks=blocks,
        blocked_by=blocked_by,
    )
    _write_task(mission_id, task)
    return task


def get_task(mission_id: str, task_id: str) -> dict[str, Any] | None:
    f = task_file(mission_id, task_id)
    if not f.exists():
        return None
    return json.loads(f.read_text(encoding="utf-8"))


def list_tasks(mission_id: str) -> list[dict[str, Any]]:
    task_dir = task_store_dir(mission_id)
    if not task_dir.exists():
        return []
    tasks = [
        json.loads(task_path.read_text(encoding="utf-8"))
        for task_path in task_dir.glob("*.json")
    ]
    return sorted(tasks, key=lambda task: int(task["id"]))


_ALLOWED_TASK_PATCH_KEYS = frozenset({
    "subject", "description", "status", "owner",
    "blocks", "blockedBy", "rationale", "review_event_id", "review_rationale",
})


def update_task(mission_id: str, task_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Atomically update a task. Held under per-mission task lock to prevent
    concurrent updates from clobbering each other's fields."""
    _ensure_task_store(mission_id)
    with FileLock(str(lock_file(mission_id))):
        task = get_task(mission_id, task_id)
        if task is None:
            raise ValueError(f"Task '{task_id}' 不存在")
        for key, value in patch.items():
            if key in _ALLOWED_TASK_PATCH_KEYS:
                task[key] = value
        _write_task(mission_id, task)
    return task


def remove_task(mission_id: str, task_id: str) -> bool:
    f = task_file(mission_id, task_id)
    if not f.exists():
        return False
    f.unlink()
    return True
