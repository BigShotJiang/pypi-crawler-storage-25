"""CSV-in-ZIP parsers for the WGEA Public Data File.

WGEA's annual ZIP unpacks to 8 thematic CSVs:
  - wgea_workforce_composition_<YEAR>.csv
  - wgea_workforce_management_statistics_<YEAR>.csv
  - wgea_questionnaire_action_on_gender_equality_<YEAR>.csv
  - wgea_questionnaire_employee_support_<YEAR>.csv
  - wgea_questionnaire_flexible_work_<YEAR>.csv
  - wgea_questionnaire_harm_prevention_<YEAR>.csv
  - wgea_questionnaire_workplace_overview_<YEAR>.csv
  - wgea_questionnaire_catalogue_<YEAR>.csv      (metadata, not exposed)

`read_csv_from_zip(zip_bytes, member_pattern)` extracts the matching CSV
without unpacking the whole archive, parses it via pandas, and returns
a DataFrame. The member_pattern is a regex applied to filenames inside
the ZIP — this means curated YAMLs can declare a year-agnostic pattern
("wgea_workforce_composition_") that resolves to the actual year-suffixed
filename at runtime.

`stream_csv_from_zip(...)` is the limit-pushed-down variant: it iterates
rows with `csv.reader` and stops as soon as `max_rows` matching rows have
been collected. Used for the two largest CSVs (workforce_composition,
employee_support) where the full pandas parse is the timeout cost a
`limit=2`-style query was paying for.
"""
from __future__ import annotations

import csv
import io
import math
import re
import zipfile
from collections.abc import Callable
from io import BytesIO
from typing import Any

import pandas as pd


class ParseError(Exception):
    """Raised when a WGEA resource can't be parsed."""


def list_zip_members(zip_bytes: bytes) -> list[str]:
    """Return all filenames inside a WGEA ZIP."""
    if not zip_bytes:
        raise ParseError("empty ZIP body")
    try:
        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            return zf.namelist()
    except zipfile.BadZipFile as e:
        raise ParseError(f"could not open ZIP (corrupt or truncated body): {e}") from e


def _resolve_member(zip_bytes: bytes, member_pattern: str) -> str:
    """Find the ZIP member matching member_pattern.

    If `member_pattern` matches a filename exactly inside the ZIP, return it.
    Otherwise treat `member_pattern` as a regex-prefix and look for any
    member starting with the prefix (so YAML can say "wgea_workforce_composition_"
    and we resolve to "wgea_workforce_composition_2025.csv" / "..._2024.csv"
    interchangeably).
    """
    names = list_zip_members(zip_bytes)
    if member_pattern in names:
        return member_pattern
    # Try prefix match (no extension required)
    candidates = [n for n in names if n.startswith(member_pattern)]
    if not candidates:
        # Try regex match
        try:
            rx = re.compile(member_pattern)
            candidates = [n for n in names if rx.search(n)]
        except re.error:
            pass
    if not candidates:
        raise ParseError(
            f"no member in ZIP matches {member_pattern!r}. "
            f"Available members: {names[:8]}"
            + ("..." if len(names) > 8 else "")
        )
    # Pick the newest (highest year suffix) if multiple match.
    candidates.sort(key=_year_score, reverse=True)
    return candidates[0]


def _year_score(name: str) -> int:
    m = re.search(r"_(\d{4})\.csv$", name)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return 0
    return 0


def read_csv_from_zip(
    zip_bytes: bytes,
    member_pattern: str,
    *,
    max_rows: int | None = None,
    dtype: dict[str, str] | None = None,
) -> pd.DataFrame:
    """Extract one CSV member from a WGEA ZIP and parse it.

    Args:
        zip_bytes: raw bytes of the ZIP file (as fetched from data.gov.au).
        member_pattern: filename or regex/prefix that matches one CSV inside
            the ZIP. Year-agnostic patterns are recommended (the curated
            YAML's `zip_member` is a prefix).
        max_rows: optional cap on returned rows (useful for tests).
        dtype: optional pandas dtype overrides per column. Most callers pass
            None and let pandas infer.

    Returns:
        DataFrame with the source columns unchanged. Renaming to plain-English
        aliases happens later in `shaping.py`.

    Raises:
        ParseError on corrupt ZIP, missing member, or unreadable CSV.
    """
    member = _resolve_member(zip_bytes, member_pattern)
    try:
        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            with zf.open(member) as fp:
                df = pd.read_csv(
                    fp,
                    dtype=dtype,
                    nrows=max_rows,
                    low_memory=False,
                )
    except (zipfile.BadZipFile, OSError, UnicodeDecodeError) as e:
        raise ParseError(
            f"could not read {member!r} from ZIP (corrupt or truncated): {e}"
        ) from e
    except pd.errors.ParserError as e:
        raise ParseError(f"pandas could not parse {member!r}: {e}") from e

    df.columns = [_normalize_header(c) for c in df.columns]
    return df


def stream_csv_from_zip(
    zip_bytes: bytes,
    member_pattern: str,
    *,
    max_rows: int,
    row_predicate: Callable[[dict[str, str]], bool] | None = None,
) -> pd.DataFrame:
    """Stream-parse a CSV member from a WGEA ZIP, applying a row predicate.

    Iterates rows with the stdlib `csv.reader` (no pandas) and breaks out
    as soon as `max_rows` rows have been accepted by `row_predicate`. Used
    by the server's fast path for the two largest WGEA CSVs
    (workforce_composition + employee_support) when a caller specifies
    `max_rows` — previously the cold call was paying the full 5-15s
    pandas parse cost regardless of how few rows the caller wanted.

    Args:
        zip_bytes: raw bytes of the ZIP file (as fetched from data.gov.au).
        member_pattern: filename or regex/prefix that matches one CSV inside
            the ZIP (same semantics as `read_csv_from_zip`).
        max_rows: hard cap on accepted rows. Required — the whole point of
            this function is bounded reading. Must be >= 1.
        row_predicate: optional callable(dict[str, str]) -> bool. The dict
            is the row keyed by source column name (values are str). When
            None, all rows match.

    Returns:
        DataFrame whose columns are the source CSV headers (normalised).
        Dtypes default to pandas inference applied to the small accumulated
        list — so an `n_employees` column lands as int64 like the full-parse
        path. The DataFrame has at most `max_rows` rows.

    Raises:
        ParseError on corrupt ZIP, missing member, or unreadable CSV.
        ValueError if `max_rows` < 1.
    """
    if max_rows is None or max_rows < 1:
        raise ValueError(
            f"stream_csv_from_zip requires max_rows >= 1, got {max_rows!r}. "
            "Use read_csv_from_zip for unbounded reads."
        )
    member = _resolve_member(zip_bytes, member_pattern)
    try:
        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            with zf.open(member) as raw_fp:
                text_fp = io.TextIOWrapper(raw_fp, encoding="utf-8", newline="")
                reader = csv.reader(text_fp)
                try:
                    headers = next(reader)
                except StopIteration as e:
                    raise ParseError(
                        f"CSV member {member!r} is empty (no header row)."
                    ) from e
                headers = [_normalize_header(h) for h in headers]
                n_cols = len(headers)
                collected: list[list[str | None]] = []
                for row in reader:
                    # Tolerate ragged rows: pad with None or truncate to header width.
                    if len(row) < n_cols:
                        row = row + [None] * (n_cols - len(row))  # type: ignore[list-item]
                    elif len(row) > n_cols:
                        row = row[:n_cols]
                    if row_predicate is not None:
                        row_dict = dict(zip(headers, row, strict=False))
                        if not row_predicate(row_dict):
                            continue
                    collected.append(row)
                    if len(collected) >= max_rows:
                        break
    except (zipfile.BadZipFile, OSError, UnicodeDecodeError) as e:
        raise ParseError(
            f"could not read {member!r} from ZIP (corrupt or truncated): {e}"
        ) from e
    except csv.Error as e:
        raise ParseError(f"csv could not parse {member!r}: {e}") from e

    if not collected:
        # Return an empty DataFrame with the same columns so the downstream
        # shaping pipeline still has a well-formed input.
        return pd.DataFrame(columns=headers)
    df = pd.DataFrame(collected, columns=headers)
    # Mirror pandas' default behaviour from read_csv: numeric-looking columns
    # become numeric. apply per-column to_numeric with errors='ignore' so
    # string columns survive intact.
    for col in df.columns:
        coerced = pd.to_numeric(df[col], errors="coerce")
        # Only swap if the entire (non-null) column converted cleanly — that's
        # what pandas' inference would have decided on the original parse.
        non_null_in = df[col].notna() & (df[col] != "")
        non_null_out = coerced.notna()
        if non_null_in.any() and (non_null_in == non_null_out).all():
            df[col] = coerced
    return df


def _normalize_header(c):
    """Strip BOMs + leading/trailing whitespace from CSV column headers."""
    if not isinstance(c, str):
        return c
    return c.lstrip("﻿").strip()


def drop_blank_rows(df: pd.DataFrame, key_columns: list[str]) -> pd.DataFrame:
    """Drop rows where every column in `key_columns` is NaN."""
    present = [c for c in key_columns if c in df.columns]
    if not present:
        return df
    keep_mask = ~df[present].isna().all(axis=1)
    return df.loc[keep_mask].reset_index(drop=True)


# ─── HEADLINE_GAP — Employer Gender Pay Gaps spreadsheet aggregator ─────
#
# WGEA publishes the rolled-up industry "mid-point" gender pay gaps in an
# annual xlsx on wgea.gov.au. The xlsx is per-employer — 8,600+ rows on the
# Employers sheet. We aggregate it server-side into ~20 rows (19 ANZSIC
# divisions + 1 synthetic "All employers" national row) so HEADLINE_GAP
# returns a small, agent-friendly answer instead of 8k+ employer rows.

# Source-column labels on the EGPG xlsx Employers sheet. Pinned here so a
# WGEA header rename surfaces as a ParseError (not a silent column-drop in
# the groupby). Header row is row 3 in the xlsx (header=3 in pandas terms).
_EGPG_SHEET = "2. Employers "  # WGEA ships the trailing space; keep verbatim.
_EGPG_HEADER_ROW = 3
_EGPG_TITLE_ROW = 2  # row 2 col 0 carries "Results based on YYYY-YY ..."

# Headline pay-gap columns. WGEA encodes percentages as fractions (0.214 not
# 21.4) — the aggregator multiplies by 100 so DataResponse callers get the
# user-facing percent. Two snapshots per metric land in the xlsx (current
# year + prior year) — we take only the current-year columns (the first
# occurrence; the prior-year columns share the same label and would clash).
_EGPG_COL_AVG_TOTAL_REM = "Average total remuneration GPG (%)"
_EGPG_COL_AVG_BASE = "Average base salary GPG (%)"
_EGPG_COL_MED_TOTAL_REM = "Median total remuneration GPG (%)"
_EGPG_COL_MED_BASE = "Median base salary GPG (%)"
_EGPG_COL_INDUSTRY = "Industry (ANZSIC Division)"
_EGPG_COL_SECTOR = "Sector"
_EGPG_COL_EMPLOYER = "Employer name"

_ALL_EMPLOYERS_LABEL = "All employers"

# WGEA publishes the headline numbers on a private-sector basis (matches the
# annual EGPG report's Figure 4). Aggregating across all sectors would mix
# Commonwealth public-sector rows in and shift the mid-point away from
# WGEA's published number. Pin to Private explicitly.
_EGPG_SECTOR_FILTER = "Private"


def _extract_reporting_year(workbook_bytes: bytes) -> str:
    """Pull the "YYYY-YY" reporting-year label out of the xlsx title row.

    Row 2 col 0 of the Employers sheet carries text like
    "Results based on 2024-25 WGEA Gender Equality Reporting". The aggregator
    needs the year label to populate `reporting_year` on every returned row
    so cross-sister consumers can join on it.
    """
    try:
        head = pd.read_excel(
            BytesIO(workbook_bytes),
            sheet_name=_EGPG_SHEET,
            header=None,
            nrows=_EGPG_TITLE_ROW + 1,
            engine="openpyxl",
        )
    except (ValueError, OSError, zipfile.BadZipFile) as e:
        raise ParseError(
            f"could not open EGPG xlsx to read reporting year: {e}"
        ) from e
    try:
        cell = head.iloc[_EGPG_TITLE_ROW, 0]
    except (KeyError, IndexError) as e:
        raise ParseError(
            f"EGPG xlsx title cell (row {_EGPG_TITLE_ROW}) is missing"
        ) from e
    if not isinstance(cell, str):
        raise ParseError(
            f"EGPG xlsx title cell is not text: {cell!r} ({type(cell).__name__})"
        )
    m = re.search(r"(\d{4})-(\d{2,4})", cell)
    if not m:
        raise ParseError(
            f"EGPG xlsx title cell does not contain a YYYY-YY reporting year: {cell!r}"
        )
    return m.group(0)


def parse_egpg_xlsx(workbook_bytes: bytes) -> tuple[pd.DataFrame, str]:
    """Aggregate the EGPG spreadsheet into the HEADLINE_GAP DataFrame.

    Returns:
        (df, reporting_year) where `df` has columns:
          - reporting_year         (WGEA "YYYY-YY" label)
          - anzsic_division        (ANZSIC division name, or "All employers")
          - total_remuneration_gap_pct
          - base_salary_gap_pct
          - median_total_rem_gap_pct
          - median_base_salary_gap_pct
          - employer_count

        Percentages are out of 100 (so 21.4 means 21.4%, not 0.214). Filtered
        to private-sector employers to match WGEA's published headline figures
        (Commonwealth public-sector rows have a different aggregation that
        WGEA reports separately).

    Raises:
        ParseError on missing sheet, missing expected columns, or a corrupt
        xlsx body.
    """
    if not workbook_bytes:
        raise ParseError("empty xlsx body")
    reporting_year = _extract_reporting_year(workbook_bytes)
    try:
        df = pd.read_excel(
            BytesIO(workbook_bytes),
            sheet_name=_EGPG_SHEET,
            header=_EGPG_HEADER_ROW,
            engine="openpyxl",
        )
    except (ValueError, OSError, zipfile.BadZipFile) as e:
        raise ParseError(f"could not parse EGPG xlsx: {e}") from e

    required = [
        _EGPG_COL_INDUSTRY,
        _EGPG_COL_SECTOR,
        _EGPG_COL_EMPLOYER,
        _EGPG_COL_AVG_TOTAL_REM,
        _EGPG_COL_AVG_BASE,
        _EGPG_COL_MED_TOTAL_REM,
        _EGPG_COL_MED_BASE,
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ParseError(
            f"EGPG xlsx is missing expected columns: {missing}. "
            f"Saw: {list(df.columns)[:8]}"
            + ("..." if len(df.columns) > 8 else "")
            + ". WGEA may have changed the spreadsheet shape."
        )

    # Restrict to private sector — WGEA's published "Mid-point of employer
    # GPGs" tables are private-sector only.
    df = df[df[_EGPG_COL_SECTOR].astype("string").str.strip() == _EGPG_SECTOR_FILTER]
    # Drop rows missing the industry tag (a handful of NaN sentinel rows
    # appear at the bottom of recent releases).
    df = df.dropna(subset=[_EGPG_COL_INDUSTRY, _EGPG_COL_EMPLOYER])
    if df.empty:
        raise ParseError(
            f"EGPG xlsx has no {_EGPG_SECTOR_FILTER!r} sector rows after filtering. "
            "WGEA may have changed the sector labels — flag the release shape."
        )

    rows: list[dict[str, Any]] = []
    # One row per ANZSIC division.
    for division, sub in df.groupby(_EGPG_COL_INDUSTRY, sort=True):
        rows.append(_aggregate_industry_row(reporting_year, str(division), sub))
    # Synthetic "All employers" national row — same metric, computed across
    # the whole private-sector population. This is what answers "what's
    # Australia's gender pay gap?" without an industry filter.
    rows.append(_aggregate_industry_row(reporting_year, _ALL_EMPLOYERS_LABEL, df))

    out = pd.DataFrame(rows)
    # Lexical sort matches the rest of the portfolio (alphabetised divisions
    # with the All-employers row appearing as 'A...' before 'Agriculture').
    # Pull All-employers to the top so HEADLINE_GAP latest() with no filter
    # surfaces the national number first.
    is_all = out["anzsic_division"] == _ALL_EMPLOYERS_LABEL
    out = pd.concat([out[is_all], out[~is_all]], ignore_index=True)
    return out, reporting_year


def _aggregate_industry_row(
    reporting_year: str,
    division: str,
    sub: pd.DataFrame,
) -> dict[str, Any]:
    """One HEADLINE_GAP row for an ANZSIC division (or the All-employers slice).

    Methodology vs WGEA's national headline figures
    ───────────────────────────────────────────────
    HEADLINE_GAP aggregates the per-employer rows from WGEA's Employer Gender
    Pay Gaps Spreadsheet to a small agent-friendly response. The metrics are
    DESCRIPTIVE STATISTICS over the per-employer GPG distribution:

      * `total_remuneration_gap_pct` = mean of "Average total remuneration
        GPG (%)" across employers in the slice
      * `median_total_rem_gap_pct`   = median of "Median total remuneration
        GPG (%)" across employers in the slice

    These ARE NOT WGEA's published national headline figures. WGEA's
    Scorecard reports a "Mean Total Remuneration GPG" of ~21.1% (2024-25)
    computed from raw aggregated payroll across all reporting employers —
    not derivable from the per-employer GPG percentages in the spreadsheet.
    The spreadsheet does not publish the headcount column needed to weight
    correctly. Customers who want the WGEA national headline should cite
    the WGEA Scorecard directly (https://www.wgea.gov.au/publications/
    employer-gender-pay-gaps-report).

    What HEADLINE_GAP IS useful for: comparing one ANZSIC division to
    another, identifying outlier industries, tracking median-employer
    gaps over time. Per-industry mid-points within this dataset are
    self-consistent and reproducible.
    """
    return {
        "reporting_year": reporting_year,
        "anzsic_division": division,
        # mean(per-employer "Average ... GPG (%)") — the unweighted average
        # of employer-level mean gaps. Closer to WGEA's "Mean GPG" than
        # median was, but still not employee-weighted.
        "total_remuneration_gap_pct": _pct(sub[_EGPG_COL_AVG_TOTAL_REM].mean()),
        "base_salary_gap_pct": _pct(sub[_EGPG_COL_AVG_BASE].mean()),
        # median(per-employer "Median ... GPG (%)") — robust middle-employer
        # gap. Used by customers who want "what does the typical employer's
        # GPG look like in this industry?"
        "median_total_rem_gap_pct": _pct(sub[_EGPG_COL_MED_TOTAL_REM].median()),
        "median_base_salary_gap_pct": _pct(sub[_EGPG_COL_MED_BASE].median()),
        "employer_count": int(sub[_EGPG_COL_EMPLOYER].notna().sum()),
    }


def _pct(fraction: float) -> float | None:
    """Convert WGEA's fraction (0.214) to a user-facing percent (21.4).

    WGEA stores GPG values as fractions in the xlsx. NaN propagates as None
    so downstream shaping can drop the cell rather than emit NaN.
    """
    if fraction is None:
        return None
    try:
        f = float(fraction)
    except (TypeError, ValueError):
        return None
    if math.isnan(f):
        return None
    return round(f * 100.0, 2)
