"""LoopController — drives the run → validate → ralph → pass/fail cycle."""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from reporters.failure_report import write_failure_report
from reporters.progress import write_progress
from reporters.tracer import write_trace

from .agent_runner import AgentRunner
from .runtime_store import DEFAULT_WORKER_ID, Heartbeat, RuntimeStore
from .task_queue import Task, TaskQueue


class QualityEvaluatorProtocol(Protocol):
    def evaluate(self, task: Task, agent_output: str, workspace: Path) -> Any:
        ...


class EscalationHandler(Protocol):
    def __call__(
        self,
        task: Task,
        failure_count: int,
        last_errors: dict[str, str],
        workspace: Path,
    ) -> str | None:
        ...


@dataclass
class LoopResult:
    completed_tasks: list[str] = field(default_factory=list)
    failed_tasks: list[str] = field(default_factory=list)
    total_iterations: int = 0
    stopped_reason: str = ""  # "all_done" | "max_iterations" | "agent_unavailable" | ...
    escalated_issues: list[str] = field(default_factory=list)  # issue URLs


@dataclass
class LoopController:
    queue: TaskQueue
    runner: AgentRunner
    validators: list[ValidatorProtocol]
    storage_dir: Path
    workspace: Path
    max_iterations: int = 30
    auto_commit: bool = True
    quality_evaluator: QualityEvaluatorProtocol | None = None
    max_quality_retries: int = 2
    escalation_handler: EscalationHandler | None = None
    escalation_threshold: int = 3  # consecutive failures before escalation
    mode: str = "quick"
    runtime_store: RuntimeStore | None = None
    worker_id: str = DEFAULT_WORKER_ID
    heartbeat_interval_seconds: float = 30.0
    verbose: bool = False  # emit per-step narration to stderr

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg, flush=True)

    def run(self) -> LoopResult:
        result = LoopResult()
        failure_context: str | None = None
        quality_retries: dict[str, int] = {}
        consecutive_failures: dict[str, int] = {}
        last_errors: dict[str, dict[str, str]] = {}
        runtime_store = self.runtime_store
        runtime_finished = False

        try:
            while not self.queue.all_done():
                if result.total_iterations >= self.max_iterations:
                    result.stopped_reason = "max_iterations"
                    break

                task = self.queue.next()
                if task is None:
                    result.stopped_reason = (
                        "all_done" if self.queue.all_done() else "no_runnable_tasks"
                    )
                    break

                result.total_iterations += 1
                if runtime_store is None:
                    runtime_store = RuntimeStore.start(
                        self.workspace,
                        self.queue._tasks,
                        mode=self.mode,
                        worker_count=1,
                    )
                    self.runtime_store = runtime_store
                expected_runtime_revision = task.revision
                claim_token = f"{task.id}:{TaskQueue.utc_timestamp()}"
                runtime_store.claim_task(
                    task,
                    worker_id=self.worker_id,
                    claim_token=claim_token,
                    expected_revision=expected_runtime_revision,
                )
                self.queue.mark_in_progress(
                    task.id,
                    claimed_by=self.worker_id,
                    claim_token=claim_token,
                )
                write_progress(self.queue, self.storage_dir)

                if self.verbose:
                    desc = (
                        task.description
                        if len(task.description) <= 80
                        else task.description[:77] + "..."
                    )
                    self._log(f"\n├─ [task {task.id}] {desc}")
                    self._log(f"│  ├─ iteration {result.total_iterations}/{self.max_iterations}")
                    self._log(
                        f"│  ├─ agent: {self.runner.agent_cmd[0]} "
                        f"(timeout {self.runner.timeout_seconds}s)"
                    )

                with Heartbeat(
                    runtime_store,
                    task.id,
                    claim_token,
                    worker_id=self.worker_id,
                    interval_seconds=self.heartbeat_interval_seconds,
                ):
                    iter_start = time.monotonic()

                    # Execute
                    run = self.runner.run(task, failure_context=failure_context)
                    if self.verbose:
                        mark = "✓" if run.success else "✗"
                        self._log(
                            f"│  │  └─ {mark} done in {run.duration_seconds:.1f}s "
                            f"(exit {run.returncode})"
                        )

                    if not run.success:
                        duration = time.monotonic() - iter_start
                        errors = {"agent": run.stderr or run.stdout}

                        if run.returncode == -1 and "not found" in run.stderr:
                            result.stopped_reason = "agent_unavailable"
                            runtime_store.requeue_task(
                                task.id,
                                claim_token,
                                worker_id=self.worker_id,
                            )
                            self.queue.requeue(task.id, claim_token=claim_token)
                            write_trace(
                                task, success=False, duration_seconds=duration,
                                stopped_reason="agent_unavailable",
                                iteration=result.total_iterations,
                                storage_dir=self.storage_dir,
                            )
                            break

                        failure_context = write_failure_report(
                            task=task, validator_errors=errors,
                            storage_dir=self.storage_dir,
                        )
                        result.failed_tasks.append(task.id)
                        runtime_store.requeue_task(
                            task.id,
                            claim_token,
                            worker_id=self.worker_id,
                        )
                        self.queue.requeue(task.id, claim_token=claim_token)
                        write_progress(self.queue, self.storage_dir)
                        write_trace(
                            task, success=False, duration_seconds=duration,
                            validator_errors=errors,
                            iteration=result.total_iterations,
                            storage_dir=self.storage_dir,
                        )

                        # Track consecutive failures for escalation
                        consecutive_failures[task.id] = consecutive_failures.get(task.id, 0) + 1
                        last_errors[task.id] = errors
                        self._log(
                            f"│  └─ ↻ retry {consecutive_failures[task.id]}/"
                            f"{self.escalation_threshold} (agent failure)"
                        )
                        self._maybe_escalate(
                            task, consecutive_failures, last_errors, result
                        )
                        continue

                    # Validate
                    errors = self._run_validators()
                    if errors:
                        duration = time.monotonic() - iter_start
                        failure_context = write_failure_report(
                            task=task, validator_errors=errors,
                            storage_dir=self.storage_dir,
                        )
                        result.failed_tasks.append(task.id)
                        runtime_store.requeue_task(
                            task.id,
                            claim_token,
                            worker_id=self.worker_id,
                        )
                        self.queue.requeue(task.id, claim_token=claim_token)
                        write_progress(self.queue, self.storage_dir)
                        write_trace(
                            task, success=False, duration_seconds=duration,
                            validator_errors=errors,
                            iteration=result.total_iterations,
                            storage_dir=self.storage_dir,
                        )

                        consecutive_failures[task.id] = consecutive_failures.get(task.id, 0) + 1
                        last_errors[task.id] = errors
                        self._log(
                            f"│  └─ ↻ retry {consecutive_failures[task.id]}/"
                            f"{self.escalation_threshold} ({len(errors)} validator failure(s))"
                        )
                        self._maybe_escalate(
                            task, consecutive_failures, last_errors, result
                        )
                        continue

                    # Ralph cycle — quality gate (only when evaluator is set)
                    quality_score: float | None = None
                    quality_passed: bool | None = None
                    if self.quality_evaluator is not None:
                        retries = quality_retries.get(task.id, 0)
                        if retries < self.max_quality_retries:
                            quality = self.quality_evaluator.evaluate(
                                task=task,
                                agent_output=run.stdout,
                                workspace=self.workspace,
                            )
                            quality_score = quality.score
                            quality_passed = quality.passed
                            if not quality.passed:
                                duration = time.monotonic() - iter_start
                                quality_retries[task.id] = retries + 1
                                failure_context = quality.context()
                                result.failed_tasks.append(task.id)
                                runtime_store.requeue_task(
                                    task.id,
                                    claim_token,
                                    worker_id=self.worker_id,
                                )
                                self.queue.requeue(task.id, claim_token=claim_token)
                                write_progress(self.queue, self.storage_dir)
                                write_trace(
                                    task, success=False, duration_seconds=duration,
                                    quality_score=quality_score,
                                    quality_passed=False,
                                    iteration=result.total_iterations,
                                    storage_dir=self.storage_dir,
                                )
                                self._log(
                                    f"│  └─ ↻ ralph retry {quality_retries[task.id]}/"
                                    f"{self.max_quality_retries} "
                                    f"(quality {quality_score:.2f})"
                                )
                                continue

                    # Pass
                    duration = time.monotonic() - iter_start
                    failure_context = None
                    quality_retries.pop(task.id, None)
                    consecutive_failures.pop(task.id, None)
                    last_errors.pop(task.id, None)
                    runtime_store.complete_task(
                        task.id,
                        claim_token,
                        worker_id=self.worker_id,
                    )
                    self.queue.mark_done(task.id, claim_token=claim_token)
                    result.completed_tasks.append(task.id)
                    write_progress(self.queue, self.storage_dir)
                    write_trace(
                        task, success=True, duration_seconds=duration,
                        quality_score=quality_score,
                        quality_passed=quality_passed,
                        iteration=result.total_iterations,
                        storage_dir=self.storage_dir,
                    )

                    self._log(f"│  └─ ✓ task complete in {duration:.1f}s")

                    if self.auto_commit:
                        self._git_commit(task)

            if not result.stopped_reason:
                result.stopped_reason = "all_done"
            if runtime_store is not None:
                runtime_store.finish(result.stopped_reason)
                runtime_finished = True
        finally:
            if runtime_store is not None and not runtime_finished:
                runtime_store.finish("aborted")

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _run_validators(self) -> dict[str, str]:
        """Run all validators; collect errors from failing ones."""
        errors: dict[str, str] = {}
        self._log(f"│  ├─ validators ({len(self.validators)}):")
        for i, validator in enumerate(self.validators):
            is_last = i == len(self.validators) - 1
            branch = "└─" if is_last else "├─"
            t0 = time.monotonic()
            ok, output = validator.run(self.workspace)
            dt = time.monotonic() - t0
            mark = "✓" if ok else "✗"
            tail = ""
            if not ok:
                first = next(
                    (line.strip() for line in output.splitlines() if line.strip()),
                    "",
                )
                tail = f" — {first[:60]}" if first else ""
            self._log(f"│  │  {branch} {validator.name:<8} {mark} ({dt:.1f}s){tail}")
            if not ok:
                errors[validator.name] = output
        return errors

    def _maybe_escalate(
        self,
        task: Task,
        consecutive_failures: dict[str, int],
        last_errors: dict[str, dict[str, str]],
        result: LoopResult,
    ) -> None:
        """Escalate to human if consecutive failure threshold is reached."""
        count = consecutive_failures.get(task.id, 0)
        if count < self.escalation_threshold or self.escalation_handler is None:
            return
        errors = last_errors.get(task.id, {})
        self._log(f"│  └─ ⚠ escalating after {count} consecutive failures")
        url = self.escalation_handler(
            task, count, errors, self.workspace
        )
        if url:
            result.escalated_issues.append(url)
        # Reset counter so we don't re-escalate every iteration
        consecutive_failures[task.id] = 0

    def _git_commit(self, task: Task) -> None:
        msg = f"task({task.id}): {task.description[:72]}"
        try:
            subprocess.run(
                ["git", "add", "-A"],
                cwd=self.workspace,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "commit", "-m", msg],
                cwd=self.workspace,
                check=True,
                capture_output=True,
            )
        except subprocess.CalledProcessError:
            pass  # nothing staged — skip commit


class ValidatorProtocol:
    """Interface that all validators must implement."""

    name: str = "base"

    def run(self, workspace: Path) -> tuple[bool, str]:
        raise NotImplementedError
