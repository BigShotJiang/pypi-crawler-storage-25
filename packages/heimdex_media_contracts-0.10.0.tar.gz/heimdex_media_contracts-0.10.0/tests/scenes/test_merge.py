from dataclasses import dataclass

import pytest

from heimdex_media_contracts.scenes.merge import (
    SpeechSegmentLike,
    aggregate_scene_tags,
    aggregate_transcript,
    assign_segments_to_scenes,
)
from heimdex_media_contracts.scenes.schemas import SceneBoundary
from heimdex_media_contracts.speech.schemas import TaggedSegment


@dataclass
class FakeSegment:
    start: float
    end: float
    text: str


def _boundary(scene_id: str, index: int, start_ms: int, end_ms: int) -> SceneBoundary:
    return SceneBoundary(
        scene_id=scene_id,
        index=index,
        start_ms=start_ms,
        end_ms=end_ms,
        keyframe_timestamp_ms=(start_ms + end_ms) // 2,
    )


def _seg(start: float, end: float, text: str) -> dict:
    return {"start": start, "end": end, "text": text}


class TestAssignSegmentsToScenes:
    def test_segment_fully_inside_one_scene(self):
        scenes = [_boundary("v_scene_000", 0, 0, 10000)]
        segments = [_seg(1.0, 3.0, "hello")]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_000"]) == 1
        assert result["v_scene_000"][0]["text"] == "hello"

    def test_segment_spanning_two_scenes_assigned_to_max_overlap(self):
        scenes = [
            _boundary("v_scene_000", 0, 0, 5000),
            _boundary("v_scene_001", 1, 5000, 10000),
        ]
        segments = [_seg(3.0, 8.0, "spanning")]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_001"]) == 1
        assert len(result["v_scene_000"]) == 0

    def test_no_segments_returns_empty_lists(self):
        scenes = [_boundary("v_scene_000", 0, 0, 5000)]
        result = assign_segments_to_scenes(scenes, [])
        assert result["v_scene_000"] == []

    def test_multiple_segments_in_one_scene_sorted_by_time(self):
        scenes = [_boundary("v_scene_000", 0, 0, 10000)]
        segments = [
            _seg(5.0, 7.0, "second"),
            _seg(1.0, 3.0, "first"),
            _seg(8.0, 9.0, "third"),
        ]
        result = assign_segments_to_scenes(scenes, segments)
        texts = [s["text"] for s in result["v_scene_000"]]
        assert texts == ["first", "second", "third"]

    def test_segment_exactly_at_scene_boundary(self):
        scenes = [
            _boundary("v_scene_000", 0, 0, 5000),
            _boundary("v_scene_001", 1, 5000, 10000),
        ]
        segments = [_seg(5.0, 7.0, "at boundary")]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_001"]) == 1
        assert len(result["v_scene_000"]) == 0

    def test_zero_duration_scene(self):
        scenes = [_boundary("v_scene_000", 0, 5000, 5000)]
        segments = [_seg(4.9, 5.1, "near zero")]
        result = assign_segments_to_scenes(scenes, segments)
        assert result["v_scene_000"] == []

    def test_segment_outside_all_scenes_dropped(self):
        scenes = [_boundary("v_scene_000", 0, 0, 5000)]
        segments = [_seg(10.0, 12.0, "outside")]
        result = assign_segments_to_scenes(scenes, segments)
        assert result["v_scene_000"] == []

    def test_multiple_scenes_correct_assignment(self):
        scenes = [
            _boundary("v_scene_000", 0, 0, 10000),
            _boundary("v_scene_001", 1, 10000, 20000),
            _boundary("v_scene_002", 2, 20000, 30000),
        ]
        segments = [
            _seg(2.0, 4.0, "in first"),
            _seg(12.0, 14.0, "in second"),
            _seg(22.0, 24.0, "in third"),
        ]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_000"]) == 1
        assert len(result["v_scene_001"]) == 1
        assert len(result["v_scene_002"]) == 1

    def test_empty_scenes_list(self):
        result = assign_segments_to_scenes([], [_seg(1.0, 2.0, "orphan")])
        assert result == {}


class TestAggregateTranscript:
    def test_single_segment(self):
        assert aggregate_transcript([_seg(0, 1, "hello")]) == "hello"

    def test_multiple_segments_joined(self):
        segs = [_seg(0, 1, "hello"), _seg(1, 2, "world")]
        assert aggregate_transcript(segs) == "hello world"

    def test_empty_segments(self):
        assert aggregate_transcript([]) == ""

    def test_whitespace_only_text_skipped(self):
        segs = [_seg(0, 1, "hello"), _seg(1, 2, "   "), _seg(2, 3, "world")]
        assert aggregate_transcript(segs) == "hello world"

    def test_strips_individual_segments(self):
        segs = [_seg(0, 1, "  hello  "), _seg(1, 2, "  world  ")]
        assert aggregate_transcript(segs) == "hello world"

    def test_missing_text_key_skipped(self):
        segs = [{"start": 0, "end": 1}, {"start": 1, "end": 2, "text": "kept"}]
        assert aggregate_transcript(segs) == "kept"


class TestProtocolInputs:
    def test_dataclass_satisfies_protocol(self):
        seg = FakeSegment(start=1.0, end=2.0, text="hello")
        assert isinstance(seg, SpeechSegmentLike)

    def test_assign_with_typed_objects(self):
        scenes = [_boundary("v_scene_000", 0, 0, 10000)]
        segments = [FakeSegment(start=1.0, end=3.0, text="typed")]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_000"]) == 1
        assert result["v_scene_000"][0].text == "typed"

    def test_aggregate_with_typed_objects(self):
        segments = [
            FakeSegment(start=0, end=1, text="hello"),
            FakeSegment(start=1, end=2, text="world"),
        ]
        assert aggregate_transcript(segments) == "hello world"

    def test_mixed_dict_and_typed_objects(self):
        scenes = [_boundary("v_scene_000", 0, 0, 10000)]
        segments = [
            {"start": 1.0, "end": 2.0, "text": "dict_seg"},
            FakeSegment(start=3.0, end=4.0, text="typed_seg"),
        ]
        result = assign_segments_to_scenes(scenes, segments)
        assert len(result["v_scene_000"]) == 2


class TestAggregateSceneTags:
    def test_empty_segments_returns_empty_list(self):
        result = aggregate_scene_tags([])
        assert result == []

    def test_single_segment_with_tags(self):
        segments = [TaggedSegment(start=0.0, end=1.0, text="hello", tags=["tag1", "tag2"])]
        result = aggregate_scene_tags(segments)
        assert result == ["tag1", "tag2"]

    def test_single_segment_with_tags_sorted(self):
        segments = [TaggedSegment(start=0.0, end=1.0, text="hello", tags=["zebra", "apple", "banana"])]
        result = aggregate_scene_tags(segments)
        assert result == ["apple", "banana", "zebra"]

    def test_multiple_segments_with_tags_deduplicated(self):
        segments = [
            TaggedSegment(start=0.0, end=1.0, text="hello", tags=["tag1", "tag2"]),
            TaggedSegment(start=1.0, end=2.0, text="world", tags=["tag2", "tag3"]),
        ]
        result = aggregate_scene_tags(segments)
        assert result == ["tag1", "tag2", "tag3"]

    def test_overlapping_tags_from_multiple_segments_deduplicated_sorted(self):
        segments = [
            TaggedSegment(start=0.0, end=1.0, text="seg1", tags=["zebra", "apple"]),
            TaggedSegment(start=1.0, end=2.0, text="seg2", tags=["banana", "apple"]),
            TaggedSegment(start=2.0, end=3.0, text="seg3", tags=["cherry", "zebra"]),
        ]
        result = aggregate_scene_tags(segments)
        assert result == ["apple", "banana", "cherry", "zebra"]

    def test_segments_with_no_tags_returns_empty_list(self):
        segments = [
            TaggedSegment(start=0.0, end=1.0, text="seg1", tags=[]),
            TaggedSegment(start=1.0, end=2.0, text="seg2", tags=[]),
        ]
        result = aggregate_scene_tags(segments)
        assert result == []

    def test_mixed_segments_some_with_tags_some_without(self):
        segments = [
            TaggedSegment(start=0.0, end=1.0, text="seg1", tags=["tag1"]),
            TaggedSegment(start=1.0, end=2.0, text="seg2", tags=[]),
            TaggedSegment(start=2.0, end=3.0, text="seg3", tags=["tag2", "tag1"]),
        ]
        result = aggregate_scene_tags(segments)
        assert result == ["tag1", "tag2"]
