from __future__ import annotations

import json
import os
from typing import Any
from urllib.error import HTTPError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

from paysponge.errors import SpongeApiError, SpongeConfigError
from paysponge.models import Agent, JsonDict, McpConfig, Wallet
from paysponge._version import VERSION

DEFAULT_BASE_URL = "https://api.wallet.paysponge.com"
PYTHON_SDK_VERSION = VERSION


class _HttpTransport:
    def request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str],
        body: JsonDict | None = None,
        timeout: float = 30,
    ) -> Any:
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        request = Request(url=url, data=data, headers=headers, method=method)

        try:
            with urlopen(request, timeout=timeout) as response:
                raw = response.read()
        except HTTPError as error:
            raw = error.read()
            payload = _decode_body(raw)
            message = _error_message(payload) or error.reason or "Request failed"
            code = payload.get("code") if isinstance(payload, dict) else None
            raise SpongeApiError(
                status_code=error.code,
                message=str(message),
                code=str(code) if code else None,
                data=payload,
            ) from error

        return _decode_body(raw)


def _decode_body(raw: bytes) -> Any:
    if not raw:
        return None
    return json.loads(raw.decode("utf-8"))


def _error_message(payload: Any) -> str | None:
    if not isinstance(payload, dict):
        return None

    for key in ("message", "error"):
        value = payload.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            nested = value.get("message")
            if isinstance(nested, str):
                return nested

    return None


def _clean_query(query: JsonDict | None) -> JsonDict:
    if not query:
        return {}

    cleaned: JsonDict = {}
    for key, value in query.items():
        if value is None:
            continue
        if isinstance(value, bool):
            cleaned[key] = "true" if value else "false"
        elif isinstance(value, (list, tuple)):
            cleaned[key] = ",".join(str(item) for item in value)
        else:
            cleaned[key] = value
    return cleaned


def _pick_api_key(explicit: str | None, env_name: str) -> str:
    api_key = explicit or os.environ.get(env_name) or os.environ.get("SPONGE_API_KEY")
    if not api_key:
        raise SpongeConfigError(f"Missing API key. Pass api_key or set {env_name}.")
    return api_key


def _agent_path(agent_id: str | None) -> str:
    if not agent_id:
        raise SpongeConfigError(
            "Missing agent_id. Pass agent_id or call get_agent() first."
        )
    return quote(agent_id, safe="")


class _BaseClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30,
        transport: Any | None = None,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._transport = transport or _HttpTransport()

    def _request(
        self,
        method: str,
        path: str,
        *,
        query: JsonDict | None = None,
        body: JsonDict | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        cleaned_query = _clean_query(query)
        if cleaned_query:
            url = f"{url}?{urlencode(cleaned_query)}"

        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Sponge-Version": PYTHON_SDK_VERSION,
        }

        return self._transport.request(
            method=method,
            url=url,
            headers=headers,
            body=body,
            timeout=self.timeout,
        )


class SpongeWallet(_BaseClient):
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        agent_id: str | None = None,
        timeout: float = 30,
        transport: Any | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            transport=transport,
        )
        self.agent_id = agent_id

    @classmethod
    def connect(
        cls,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        agent_id: str | None = None,
        timeout: float = 30,
    ) -> "SpongeWallet":
        return cls(
            api_key=_pick_api_key(api_key, "SPONGE_API_KEY"),
            base_url=base_url or os.environ.get("SPONGE_API_URL", DEFAULT_BASE_URL),
            agent_id=agent_id,
            timeout=timeout,
        )

    def get_agent(self) -> Agent:
        payload = self._request("GET", "/api/agents/me")
        agent = Agent.model_validate(payload)
        self.agent_id = agent.id
        return agent

    def get_balances(
        self,
        *,
        chain: str = "all",
        allowed_chains: list[str] | str | None = None,
        only_usdc: bool | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "GET",
            "/api/balances",
            query={
                "chain": chain,
                "allowedChains": allowed_chains,
                "onlyUsdc": only_usdc,
                "agentId": agent_id or self.agent_id,
            },
        )

    def get_wallets(
        self,
        *,
        include_balances: bool = False,
        agent_id: str | None = None,
    ) -> list[Wallet]:
        payload = self._request(
            "GET",
            "/api/wallets/",
            query={
                "agentId": agent_id or self.agent_id,
                "includeBalances": include_balances,
            },
        )
        values = payload.get("wallets", payload) if isinstance(payload, dict) else payload
        if not isinstance(values, list):
            return []
        return [Wallet.model_validate(item) for item in values if isinstance(item, dict)]

    def get_addresses(self, *, agent_id: str | None = None) -> dict[str, str]:
        addresses: dict[str, str] = {}
        for wallet in self.get_wallets(agent_id=agent_id):
            chain = wallet.chain_name or wallet.chain
            if chain and wallet.address:
                addresses[chain] = wallet.address
        return addresses

    def transfer(
        self,
        *,
        chain: str,
        to: str,
        amount: str,
        currency: str = "USDC",
        agent_id: str | None = None,
    ) -> Any:
        normalized_chain = chain.lower()
        endpoint = "/api/transfers/evm"
        body_key = "currency"

        if normalized_chain in {"solana", "solana-mainnet", "solana-devnet"}:
            endpoint = "/api/transfers/solana"
        elif normalized_chain in {"tempo", "tempo-testnet"}:
            endpoint = "/api/transfers/tempo"
            body_key = "token"

        body = {
            "chain": chain,
            "to": to,
            "amount": amount,
            body_key: currency,
            "agentId": agent_id or self.agent_id,
        }
        return self._request("POST", endpoint, body=body)

    def paid_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/paid/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "agentId": agent_id or self.agent_id,
            },
        )

    def store_credit_card(
        self,
        *,
        card_number: str,
        cvc: str,
        cardholder_name: str,
        email: str,
        billing_address: JsonDict,
        shipping_address: JsonDict,
        expiry_month: str | None = None,
        expiry_year: str | None = None,
        expiration: str | None = None,
        label: str | None = None,
        metadata: JsonDict | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/credit-cards",
            body={
                "card_number": card_number,
                "expiry_month": expiry_month,
                "expiry_year": expiry_year,
                "expiration": expiration,
                "cvc": cvc,
                "cardholder_name": cardholder_name,
                "email": email,
                "billing_address": billing_address,
                "shipping_address": shipping_address,
                "label": label,
                "metadata": metadata,
                "agentId": agent_id or self.agent_id,
            },
        )

    def get_stored_credit_card(self, *, agent_id: str | None = None) -> Any:
        return self._request(
            "GET",
            "/api/credit-cards",
            query={"agentId": agent_id or self.agent_id},
        )

    def add_link_payment_method(
        self,
        *,
        agent_id: str | None = None,
        link_payment_method_id: str | None = None,
        set_as_default: bool | None = None,
        client_name: str | None = None,
        email: str | None = None,
        phone: str | None = None,
        billing: JsonDict | None = None,
        shipping: JsonDict | None = None,
    ) -> Any:
        resolved_agent_id = _agent_path(agent_id or self.agent_id)

        return self._request(
            "POST",
            f"/api/agents/{resolved_agent_id}/link-payment-methods/link",
            body={
                "linkPaymentMethodId": link_payment_method_id,
                "setAsDefault": set_as_default,
                "clientName": client_name,
                "email": email,
                "phone": phone,
                "billing": billing,
                "shipping": shipping,
            },
        )

    def create_link_payment_credential(
        self,
        *,
        agent_id: str | None = None,
        link_payment_method_id: str | None = None,
        spend_request_id: str | None = None,
        amount: str | None = None,
        currency: str | None = None,
        merchant_name: str | None = None,
        merchant_url: str | None = None,
        context: str | None = None,
    ) -> Any:
        resolved_agent_id = _agent_path(agent_id or self.agent_id)

        return self._request(
            "POST",
            f"/api/agents/{resolved_agent_id}/link-payment-methods/credential",
            body={
                "linkPaymentMethodId": link_payment_method_id,
                "spendRequestId": spend_request_id,
                "amount": amount,
                "currency": currency,
                "merchantName": merchant_name,
                "merchantUrl": merchant_url,
                "context": context,
            },
        )

    def get_card(
        self,
        *,
        card_type: str | None = None,
        payment_method_id: str | None = None,
        amount: str | None = None,
        currency: str | None = None,
        merchant_name: str | None = None,
        merchant_url: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/cards",
            body={
                "card_type": card_type,
                "payment_method_id": payment_method_id,
                "amount": amount,
                "currency": currency,
                "merchant_name": merchant_name,
                "merchant_url": merchant_url,
                "agentId": agent_id or self.agent_id,
            },
        )

    def issue_virtual_card(
        self,
        *,
        amount: str,
        merchant_name: str,
        merchant_url: str,
        currency: str | None = None,
        merchant_country_code: str | None = None,
        description: str | None = None,
        products: list[JsonDict] | None = None,
        shipping_address: JsonDict | None = None,
        enrollment_id: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/virtual-cards",
            body={
                "amount": amount,
                "currency": currency,
                "merchant_name": merchant_name,
                "merchant_url": merchant_url,
                "merchant_country_code": merchant_country_code,
                "description": description,
                "products": products,
                "shipping_address": shipping_address,
                "enrollment_id": enrollment_id,
                "agentId": agent_id or self.agent_id,
            },
        )

    def report_card_usage(
        self,
        *,
        payment_method_id: str,
        status: str,
        merchant_name: str | None = None,
        merchant_domain: str | None = None,
        amount: str | None = None,
        currency: str | None = None,
        failure_reason: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/card-usage",
            body={
                "payment_method_id": payment_method_id,
                "merchant_name": merchant_name,
                "merchant_domain": merchant_domain,
                "amount": amount,
                "currency": currency,
                "status": status,
                "failure_reason": failure_reason,
                "agentId": agent_id or self.agent_id,
            },
        )

    def get_sponge_card_status(
        self,
        *,
        refresh: bool | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "GET",
            "/api/sponge-card/status",
            query={
                "agentId": agent_id or self.agent_id,
                "refresh": refresh,
            },
        )

    def onboard_sponge_card(
        self,
        *,
        occupation: str | None = None,
        redirect_uri: str | None = None,
        e_sign_consent: bool | None = None,
        account_opening_privacy_notice: bool | None = None,
        sponge_card_terms: bool | None = None,
        information_certification: bool | None = None,
        unauthorized_solicitation_acknowledgement: bool | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/sponge-card/onboard",
            body={
                "occupation": occupation,
                "redirect_uri": redirect_uri,
                "e_sign_consent": e_sign_consent,
                "account_opening_privacy_notice": account_opening_privacy_notice,
                "sponge_card_terms": sponge_card_terms,
                "information_certification": information_certification,
                "unauthorized_solicitation_acknowledgement": (
                    unauthorized_solicitation_acknowledgement
                ),
                "agentId": agent_id or self.agent_id,
            },
        )

    def accept_sponge_card_terms(
        self,
        *,
        e_sign_consent: bool,
        sponge_card_terms: bool,
        information_certification: bool,
        unauthorized_solicitation_acknowledgement: bool,
        account_opening_privacy_notice: bool | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/sponge-card/terms",
            body={
                "e_sign_consent": e_sign_consent,
                "account_opening_privacy_notice": account_opening_privacy_notice,
                "sponge_card_terms": sponge_card_terms,
                "information_certification": information_certification,
                "unauthorized_solicitation_acknowledgement": (
                    unauthorized_solicitation_acknowledgement
                ),
                "agentId": agent_id or self.agent_id,
            },
        )

    def create_sponge_card(
        self,
        *,
        billing: JsonDict,
        email: str,
        phone: str,
        shipping: JsonDict | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/sponge-card/create-card",
            body={
                "billing": billing,
                "email": email,
                "phone": phone,
                "shipping": shipping,
                "agentId": agent_id or self.agent_id,
            },
        )

    def get_sponge_card_details(self, *, agent_id: str | None = None) -> Any:
        return self._request(
            "GET",
            "/api/sponge-card/details",
            query={"agentId": agent_id or self.agent_id},
        )

    def fund_sponge_card(
        self,
        *,
        amount: str,
        chain: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/sponge-card/fund",
            body={
                "amount": amount,
                "chain": chain,
                "agentId": agent_id or self.agent_id,
            },
        )

    def withdraw_sponge_card(
        self,
        *,
        amount: str,
        chain: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/sponge-card/withdraw",
            body={
                "amount": amount,
                "chain": chain,
                "agentId": agent_id or self.agent_id,
            },
        )

    def x402_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        preferred_chain: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/x402/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "preferred_chain": preferred_chain,
                "agentId": agent_id or self.agent_id,
            },
        )

    def mpp_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/mpp/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "agentId": agent_id or self.agent_id,
            },
        )

    def mcp(self) -> McpConfig:
        return McpConfig(
            url=f"{self.base_url}/mcp",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )


class SpongePlatform(_BaseClient):
    @classmethod
    def connect(
        cls,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30,
    ) -> "SpongePlatform":
        return cls(
            api_key=_pick_api_key(api_key, "SPONGE_MASTER_KEY"),
            base_url=base_url or os.environ.get("SPONGE_API_URL", DEFAULT_BASE_URL),
            timeout=timeout,
        )

    def create_agent(
        self,
        *,
        name: str,
        description: str | None = None,
        is_test_mode: bool = True,
        **extra: Any,
    ) -> Agent:
        body: JsonDict = {
            "name": name,
            "description": description,
            "isTestMode": is_test_mode,
            **extra,
        }
        return Agent.model_validate(self._request("POST", "/api/agents/", body=body))

    def list_agents(self, *, include_balances: bool = False) -> list[Agent]:
        payload = self._request(
            "GET",
            "/api/agents/",
            query={"includeBalances": include_balances},
        )
        values = payload.get("agents", payload) if isinstance(payload, dict) else payload
        if not isinstance(values, list):
            return []
        return [Agent.model_validate(item) for item in values if isinstance(item, dict)]

    def get_agent(self, agent_id: str) -> Agent:
        return Agent.model_validate(self._request("GET", f"/api/agents/{agent_id}"))

    def connect_agent(
        self,
        *,
        api_key: str,
        agent_id: str | None = None,
    ) -> SpongeWallet:
        return SpongeWallet(
            api_key=api_key,
            base_url=self.base_url,
            agent_id=agent_id,
            timeout=self.timeout,
        )
