from __future__ import annotations

from typing import Any


class SpongeConfigError(ValueError):
    """Raised when the SDK cannot find required configuration."""


class SpongeApiError(RuntimeError):
    def __init__(
        self,
        *,
        status_code: int,
        message: str,
        code: str | None = None,
        data: Any = None,
    ) -> None:
        self.status_code = status_code
        self.code = code
        self.data = data
        super().__init__(f"Sponge API error {status_code}: {message}")
