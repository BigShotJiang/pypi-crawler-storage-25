from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class SpongeModel(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class Agent(SpongeModel):
    id: str
    name: str | None = None
    description: str | None = None
    status: str | None = None
    is_test_mode: bool | None = Field(default=None, alias="isTestMode")


class Wallet(SpongeModel):
    id: str | None = None
    address: str | None = None
    chain: str | None = None
    chain_name: str | None = Field(default=None, alias="chainName")
    agent_id: str | None = Field(default=None, alias="agentId")


class McpConfig(SpongeModel):
    url: str
    headers: dict[str, str]


JsonDict = dict[str, Any]
