from __future__ import annotations

import json
from typing import Any

from paysponge_openapi.api.default_api import DefaultApi
from paysponge_openapi.api_client import ApiClient
from paysponge_openapi.api_response import ApiResponse
from paysponge_openapi.configuration import Configuration

PYTHON_SDK_VERSION = "0.1.0"
DEFAULT_BASE_URL = "https://api.wallet.paysponge.com"


def create_api_client(
    *,
    base_url: str = DEFAULT_BASE_URL,
    api_key: str | None = None,
) -> ApiClient:
    configuration = Configuration(host=base_url)
    client = ApiClient(configuration=configuration)
    client.set_default_header("Accept", "application/json")
    client.set_default_header("Sponge-Version", PYTHON_SDK_VERSION)

    if api_key:
        client.set_default_header("Authorization", f"Bearer {api_key}")

    return client


def create_default_api(
    *,
    base_url: str = DEFAULT_BASE_URL,
    api_key: str | None = None,
) -> DefaultApi:
    return DefaultApi(create_api_client(base_url=base_url, api_key=api_key))


def parse_json_response(response: ApiResponse[Any]) -> Any:
    raw = response.raw_data
    if not raw:
        return None

    if isinstance(raw, bytes):
        return json.loads(raw.decode("utf-8"))

    return json.loads(raw)
