"""``orca application-credential`` — manage application credentials (Keystone v3)."""

from __future__ import annotations

import click

from orca_cli.core.config import save_profile
from orca_cli.core.context import OrcaContext
from orca_cli.core.output import console, output_options, print_detail, print_list
from orca_cli.services.identity import IdentityService


def _current_user_id(client) -> str:
    """Resolve the user id from the current token.

    ``client._token_data`` already holds the inner ``token`` object returned by
    Keystone, so ``user`` is at the top level — no extra ``token`` wrapping.
    """
    user_id = client._token_data.get("user", {}).get("id")
    if not user_id:
        raise click.ClickException(
            "Cannot determine current user id from token. "
            "Pass --user explicitly."
        )
    return user_id


@click.group(name="application-credential")
@click.pass_context
def application_credential(ctx: click.Context) -> None:
    """Manage application credentials (Keystone v3)."""
    pass


@application_credential.command("list")
@click.option("--user", "user_id", default=None, help="User ID (default: current user).")
@output_options
@click.pass_context
def app_credential_list(ctx, user_id, output_format, columns, fit_width, max_width, noindent):
    """List application credentials."""
    client = ctx.find_object(OrcaContext).ensure_client()
    svc = IdentityService(client)
    uid = user_id or _current_user_id(client)
    print_list(
        svc.find_application_credentials(uid),
        [
            ("ID", "id", {"style": "cyan", "no_wrap": True}),
            ("Name", "name", {"style": "bold"}),
            ("Description", lambda a: (a.get("description") or "")[:40]),
            ("Expires", lambda a: a.get("expires_at") or "never"),
            ("Unrestricted", lambda a: "yes" if a.get("unrestricted") else "no"),
        ],
        title="Application Credentials",
        output_format=output_format, columns=columns,
        fit_width=fit_width, max_width=max_width, noindent=noindent,
        empty_msg="No application credentials found.",
    )


@application_credential.command("show")
@click.argument("credential_id")
@click.option("--user", "user_id", default=None)
@output_options
@click.pass_context
def app_credential_show(ctx, credential_id, user_id,
                        output_format, columns, fit_width, max_width, noindent):
    """Show application credential details."""
    client = ctx.find_object(OrcaContext).ensure_client()
    svc = IdentityService(client)
    uid = user_id or _current_user_id(client)
    a = svc.get_application_credential(uid, credential_id)
    print_detail(
        [
            ("ID", a.get("id", "")),
            ("Name", a.get("name", "")),
            ("Description", a.get("description") or "—"),
            ("Project ID", a.get("project_id", "")),
            ("Expires", a.get("expires_at") or "never"),
            ("Unrestricted", "yes" if a.get("unrestricted") else "no"),
        ],
        output_format=output_format, columns=columns,
        fit_width=fit_width, max_width=max_width, noindent=noindent,
    )


@application_credential.command("create")
@click.argument("name")
@click.option("--description", default=None)
@click.option("--secret", default=None, help="Secret (auto-generated if omitted).")
@click.option("--expires", "expires_at", default=None, help="Expiry (ISO 8601, e.g. 2026-12-31T00:00:00).")
@click.option("--unrestricted", is_flag=True, help="Allow creation of other credentials (dangerous).")
@click.option("--user", "user_id", default=None)
@click.option("--save-profile", "save_profile_name", default=None,
              metavar="PROFILE",
              help="Save the new credential as an orca profile of this name.")
@click.pass_context
def app_credential_create(ctx, name, description, secret, expires_at,
                          unrestricted, user_id, save_profile_name):
    """Create an application credential."""
    client = ctx.find_object(OrcaContext).ensure_client()
    svc = IdentityService(client)
    uid = user_id or _current_user_id(client)
    body: dict = {"name": name, "unrestricted": unrestricted}
    if description:
        body["description"] = description
    if secret:
        body["secret"] = secret
    if expires_at:
        body["expires_at"] = expires_at

    a = svc.create_application_credential(uid, body)
    console.print(f"[green]Application credential '{a.get('name')}' ({a.get('id')}) created.[/green]")
    if a.get("secret"):
        console.print(f"  [cyan]Secret:[/cyan] {a['secret']}")
        console.print("  [bold yellow]This secret will NOT be shown again.[/bold yellow]")

    if save_profile_name:
        if not a.get("secret"):
            raise click.ClickException(
                "Cannot save profile: Keystone did not return the credential secret."
            )
        profile_cfg = {
            "auth_url": client._auth_url,
            "auth_type": "v3applicationcredential",
            "application_credential_id": a["id"],
            "application_credential_secret": a["secret"],
        }
        if client._region_name:
            profile_cfg["region_name"] = client._region_name
        path = save_profile(save_profile_name, profile_cfg)
        console.print(
            f"[green]Saved as orca profile '{save_profile_name}' → {path}[/green]"
        )
        console.print(
            f"[dim]Activate with:[/dim] orca profile switch {save_profile_name}"
        )


@application_credential.command("delete")
@click.argument("credential_id")
@click.option("--user", "user_id", default=None)
@click.option("--yes", "-y", is_flag=True)
@click.pass_context
def app_credential_delete(ctx, credential_id, user_id, yes):
    """Delete an application credential."""
    if not yes:
        click.confirm(f"Delete application credential {credential_id}?", abort=True)
    client = ctx.find_object(OrcaContext).ensure_client()
    svc = IdentityService(client)
    uid = user_id or _current_user_id(client)
    svc.delete_application_credential(uid, credential_id)
    console.print(f"[green]Application credential {credential_id} deleted.[/green]")
