"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_sdk'
version = '1.3.2'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'dotenv',
        'pillow',
        'huggingface-hub',
        'utilities-nlp',
        'SUBMODELS',
        'FRANKENSTEIN-MODEL',
        'SAPI-ARCHITECTURE',
        'sapiens-bench',
        'sapiens-dataset',
        'sapiens-stack',
        'tqdm'
    ],
    url='https://github.com/sapiens-technology/SapiensSDK',
    license='Proprietary Software'
)
"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
