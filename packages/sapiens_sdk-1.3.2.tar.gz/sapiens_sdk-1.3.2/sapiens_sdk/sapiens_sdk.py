"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
SHOW_ERRORS, MODEL_CACHE, MODEL_NAME = True, None, str()
try:
	from warnings import simplefilter, filterwarnings
	from logging import getLogger, ERROR, disable, CRITICAL
	from os import environ
	from dotenv import load_dotenv
	simplefilter('ignore')
	filterwarnings('ignore')
	filterwarnings('ignore', category=UserWarning, module='torch.distributed')
	getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
	environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
	load_dotenv()
	disable(CRITICAL)
except: pass
from multiprocessing import Process, Queue
from os import cpu_count, path, makedirs, remove, listdir
def _mp_process_api_request(queue=[], models_path='', endpoint_path='', request_data={}, use_cache=True):
	from SAPI_ARCHITECTURE import SAPI
	from os import path, makedirs, remove, listdir
	from gc import collect
	global MODEL_CACHE, MODEL_NAME
	model_name = str(request_data.get('model_name', '')).strip()
	if model_name and model_name != MODEL_NAME:
		MODEL_NAME = model_name
		MODEL_CACHE = None
		collect()
	def _merge_directories(directory=''): return path.join(models_path, directory)
	architecture_instance = SAPI(show_errors=SHOW_ERRORS)
	if use_cache:
		_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
		_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
		if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
			_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
			_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
			_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
			_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
			_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
			if MODEL_CACHE: _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__setModelCache(model_cache=MODEL_CACHE)
	user_code = str(request_data.get('user_code', '')).strip()
	safe_user_code = path.basename(user_code) if user_code else ''
	target_directory = safe_user_code if safe_user_code else 'models'
	target_directory = _merge_directories(directory=target_directory)
	if not path.exists(target_directory): makedirs(target_directory)
	if endpoint_path == '/training':
		def __change_extension_if_sapiens(model_name='', file_name_root='', file_extension=''):
			if file_extension == '.sapiens': return file_name_root + '.model'
			return model_name
		from utilities_nlp import UtilitiesNLP as SapiensUtilities
		sapiens_utilities = SapiensUtilities(show_errors=SHOW_ERRORS)
		base64_dictionary = dict(request_data.get('base64_dictionary', {}))
		base64_string, _type, file_path, dataset_path = '', '', '', ''
		if base64_dictionary: base64_string, _type = str(base64_dictionary.get('base64_string', '')), str(base64_dictionary.get('type', '')).strip()
		if base64_string and _type:
			system_directory = sapiens_utilities.getTemporaryFilesDirectory()
			file_path = path.join(system_directory, f'{sapiens_utilities.getHashCode()}.{_type}')
			base64_to_file = sapiens_utilities.base64ToFile(file_dictionary=base64_dictionary, file_path=file_path)
			if base64_to_file: dataset_path = file_path
		if not dataset_path: dataset_path = str(request_data.get('dataset_path', '')).strip()
		presets = bool(request_data.get('presets', False))
		supplements = bool(request_data.get('supplements', False))
		progress = bool(request_data.get('progress', True))
		model_name = str(request_data.get('model_name', 'default.model')).strip()
		file_name_root, file_extension = path.splitext(model_name)
		file_extension = str(file_extension).lower().strip()
		if file_extension == '.sapiens': model_name = __change_extension_if_sapiens(model_name=model_name, file_name_root=file_name_root, file_extension=file_extension)
		safe_model_name = path.basename(model_name)
		if not file_extension: file_extension = '.model'
		model_path = path.join(target_directory, safe_model_name)
		training_result = architecture_instance.training(dataset_path=dataset_path, presets=presets, supplements=supplements, progress=progress)
		if file_path: sapiens_utilities.deleteFile(file_path=file_path)
		if training_result:
			saving_result = architecture_instance.saveModel(model_path=model_path, progress=progress)
			queue.put({'success': saving_result}); return
		queue.put({'success': False}); return
	elif endpoint_path == '/inference':
		model_name = str(request_data.get('model_name', 'default.model')).strip()
		safe_model_name = path.basename(model_name)
		if not safe_model_name.endswith('.model') and not safe_model_name.endswith('.sapiens'): safe_model_name += '.model'
		model_path = path.join(target_directory, safe_model_name)
		progress = bool(request_data.get('progress', True))
		if not path.exists(model_path): model_path = model_path.replace(safe_user_code, 'models')
		loading_result = architecture_instance.loadModel(model_path=model_path, progress=progress)
		if use_cache:
			_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
			_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
			if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
				_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
				_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
				_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
				_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
				_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
				if MODEL_CACHE: _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__setModelCache(model_cache=MODEL_CACHE)
		if loading_result:
			messages = list(request_data.get('messages', []))
			max_tokens = request_data.get('max_tokens', None)
			stream = bool(request_data.get('stream', True))
			task_names = list(request_data.get('task_names', []))
			language = str(request_data.get('language', '')).strip()
			temperature = float(request_data.get('temperature', 0.5))
			creativity = float(request_data.get('creativity', 0.5))
			humor = float(request_data.get('humor', 0.5))
			formality = float(request_data.get('formality', 0.5))
			political_spectrum = float(request_data.get('political_spectrum', 0.5))
			reasoning = float(request_data.get('reasoning', 0.0))
			reflection = bool(request_data.get('reflection', False))
			tools = list(request_data.get('tools', []))
			if '-' in language: language = str(language.split('-')[0]).strip()
			_FRANKENSTEIN__FrankensteinClassesStructure = None
			if use_cache:
				_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
				_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
				if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
					_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
					_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
					_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
					_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
					_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
			inference_result = architecture_instance.inference(messages=messages, max_tokens=max_tokens, stream=stream, task_names=task_names, language=language, temperature=temperature, creativity=creativity, humor=humor, formality=formality, political_spectrum=political_spectrum, reasoning=reasoning, reflection=reflection, tools=tools)
			if stream: inference_result = list(inference_result)
			if _FRANKENSTEIN__FrankensteinClassesStructure:
				_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
				MODEL_CACHE = _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__getModelCache()
			queue.put({'success': True, 'inference': inference_result})
		else:
			architecture_instance.close()
			queue.put({'success': False})
		del architecture_instance
		collect()
		return
	elif endpoint_path == '/fine-tuning':
		from utilities_nlp import UtilitiesNLP as SapiensUtilities
		sapiens_utilities = SapiensUtilities(show_errors=SHOW_ERRORS)
		base64_dictionary = dict(request_data.get('base64_dictionary', {}))
		base64_string, _type, file_path, dataset_path = '', '', '', ''
		if base64_dictionary: base64_string, _type = str(base64_dictionary.get('base64_string', '')), str(base64_dictionary.get('type', '')).strip()
		if base64_string and _type:
			system_directory = sapiens_utilities.getTemporaryFilesDirectory()
			file_path = path.join(system_directory, f'{sapiens_utilities.getHashCode()}.{_type}')
			base64_to_file = sapiens_utilities.base64ToFile(file_dictionary=base64_dictionary, file_path=file_path)
			if base64_to_file: dataset_path = file_path
		model_name = str(request_data.get('model_name', 'default.model')).strip()
		safe_model_name = path.basename(model_name)
		_, file_extension = path.splitext(model_name)
		file_extension = str(file_extension).lower().strip()
		if not file_extension: file_extension = '.model'
		model_path = path.join(target_directory, safe_model_name)
		progress = bool(request_data.get('progress', True))
		if not dataset_path: dataset_path = str(request_data.get('dataset_path', '')).strip()
		output_name = str(request_data.get('output_name', '')).strip()
		if not output_name: output_name = 'default.model'
		if not output_name.endswith(file_extension): output_name += file_extension
		output_path = path.join(target_directory, output_name)
		if not path.exists(model_path): model_path = model_path.replace(safe_user_code, 'models')
		loading_result = architecture_instance.loadModel(model_path=model_path, progress=progress)
		if loading_result:
			fine_tuning_result = architecture_instance.fineTuning(dataset_path=dataset_path, progress=progress)
			if file_path: sapiens_utilities.deleteFile(file_path=file_path)
			if fine_tuning_result:
				saving_result = architecture_instance.saveModel(model_path=output_path, progress=progress)
				if file_extension == '.model': architecture_instance.close()
				del architecture_instance
				collect()
				queue.put({'success': saving_result}); return
		elif file_path: sapiens_utilities.deleteFile(file_path=file_path)
		architecture_instance.close()
		queue.put({'success': False}); return
	elif endpoint_path == '/continuous-pre-training':
		from utilities_nlp import UtilitiesNLP as SapiensUtilities
		sapiens_utilities = SapiensUtilities(show_errors=SHOW_ERRORS)
		base64_dictionary = dict(request_data.get('base64_dictionary', {}))
		base64_string, _type, file_path, dataset_path = '', '', '', ''
		if base64_dictionary: base64_string, _type = str(base64_dictionary.get('base64_string', '')), str(base64_dictionary.get('type', '')).strip()
		if base64_string and _type:
			system_directory = sapiens_utilities.getTemporaryFilesDirectory()
			file_path = path.join(system_directory, f'{sapiens_utilities.getHashCode()}.{_type}')
			base64_to_file = sapiens_utilities.base64ToFile(file_dictionary=base64_dictionary, file_path=file_path)
			if base64_to_file: dataset_path = file_path
		model_name = str(request_data.get('model_name', 'default.model')).strip()
		safe_model_name = path.basename(model_name)
		_, file_extension = path.splitext(model_name)
		file_extension = str(file_extension).lower().strip()
		if not file_extension: file_extension = '.model'
		model_path = path.join(target_directory, safe_model_name)
		progress = bool(request_data.get('progress', True))
		if not dataset_path: dataset_path = str(request_data.get('dataset_path', '')).strip()
		presets = bool(request_data.get('presets', False))
		supplements = bool(request_data.get('supplements', False))
		output_name = str(request_data.get('output_name', '')).strip()
		if not output_name: output_name = 'default.model'
		if not output_name.endswith(file_extension): output_name += file_extension
		output_path = path.join(target_directory, output_name)
		if not path.exists(model_path): model_path = model_path.replace(safe_user_code, 'models')
		loading_result = architecture_instance.loadModel(model_path=model_path, progress=progress)
		if loading_result:
			training_result = architecture_instance.training(dataset_path=dataset_path, presets=presets, supplements=supplements, progress=progress)
			if file_path: sapiens_utilities.deleteFile(file_path=file_path)
			if training_result:
				saving_result = architecture_instance.saveModel(model_path=output_path, progress=progress)
				if file_extension == '.model': architecture_instance.close()
				del architecture_instance
				collect()
				queue.put({'success': saving_result}); return
		elif file_path: sapiens_utilities.deleteFile(file_path=file_path)
		architecture_instance.close()
		del architecture_instance
		collect()
		queue.put({'success': False}); return
	elif endpoint_path == '/reload-sapiens-model':
		model_name = str(request_data.get('model_name', '')).strip()
		file_paths = [model_name] if model_name else []
		if not model_name and not file_paths:
			_directory_path = _merge_directories(directory='models')
			file_paths = [path.join(_directory_path, file_name) for file_name in listdir(_directory_path) if file_name.endswith('.sapiens') and path.isfile(path.join(_directory_path, file_name))]
		loading_result = False
		for model_name in file_paths:
			safe_model_name = path.basename(model_name)
			_, file_extension = path.splitext(model_name)
			file_extension = str(file_extension).lower().strip()
			if not file_extension: file_extension = '.sapiens'
			_target_directory = 'models'
			_target_directory = _merge_directories(directory=_target_directory)
			model_path = path.join(_target_directory, safe_model_name)
			if path.exists(model_path) and path.isfile(model_path):
				architecture_instance = SAPI(show_errors=SHOW_ERRORS)
				loading_result, closed_model = architecture_instance.loadModel(model_path=model_path, progress=True), False
				if loading_result: closed_model = architecture_instance.close()
				if closed_model:
					loading_result = architecture_instance.loadModel(model_path=model_path, progress=True)
					del architecture_instance
					collect()
		if loading_result: queue.put({'success': loading_result}); return
		queue.put({'success': False}); return
	elif endpoint_path == '/reload-model':
		if not user_code: queue.put({'success': False, 'message': 'User code is required to reload a model.'}); return
		model_name = str(request_data.get('model_name', '')).strip()
		safe_model_name = path.basename(model_name)
		_, file_extension = path.splitext(model_name)
		file_extension = str(file_extension).lower().strip()
		if not file_extension: file_extension = '.model'
		model_path = path.join(target_directory, safe_model_name)
		if path.exists(model_path) and path.isfile(model_path):
			loading_result, closed_model = architecture_instance.loadModel(model_path=model_path, progress=False), False
			if loading_result: closed_model = architecture_instance.close()
			if closed_model:
				loading_result = architecture_instance.loadModel(model_path=model_path, progress=False)
				del architecture_instance
				collect()
			queue.put({'success': loading_result}); return
		queue.put({'success': False}); return
	elif endpoint_path == '/delete-model':
		if not user_code: queue.put({'success': False, 'message': 'User code is required to delete a model.'}); return
		model_name = str(request_data.get('model_name', '')).strip()
		safe_model_name = path.basename(model_name)
		_, file_extension = path.splitext(model_name)
		file_extension = str(file_extension).lower().strip()
		if not file_extension: file_extension = '.model'
		model_path = path.join(target_directory, safe_model_name)
		if path.exists(model_path) and path.isfile(model_path):
			loading_result, closed_model = architecture_instance.loadModel(model_path=model_path, progress=False), False
			if loading_result:
				closed_model = architecture_instance.close()
				del architecture_instance
				collect()
			if closed_model:
				try: remove(model_path)
				except: pass
			queue.put({'success': not path.exists(model_path)}); return
		queue.put({'success': False}); return
	elif endpoint_path == '/list-models':
		models_dict = {}
		normalized_target = path.normpath(target_directory)
		parent_dir = path.dirname(normalized_target)
		models_sibling_dir = path.join(parent_dir, 'models')
		directories_to_check = [target_directory, models_sibling_dir]
		for directory in directories_to_check:
			if path.exists(directory) and path.isdir(directory):
				for file_name in listdir(directory):
					if file_name:
						if file_name.lower().endswith('.model') or file_name.lower().endswith('.sapiens'):
							if file_name not in models_dict: models_dict[file_name] = directory
		models_list = list(models_dict.keys())
		del architecture_instance
		collect()
		queue.put({'success': True, 'models': models_list}); return
	del architecture_instance
	collect()
	queue.put({'success': False, 'message': 'Endpoint not found.'})
def _mp_stream_inference(queue=None, model_path='', inference_kwargs=[], use_cache=True):
	from SAPI_ARCHITECTURE import SAPI
	from gc import collect
	global MODEL_CACHE
	architecture_instance = SAPI(show_errors=SHOW_ERRORS)
	if use_cache:
		_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
		_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
		if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
			_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
			_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
			_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
			_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
			_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
			if MODEL_CACHE: _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__setModelCache(model_cache=MODEL_CACHE)
	loading_result = architecture_instance.loadModel(model_path=model_path, progress=False)
	if use_cache:
		_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
		_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
		if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
			_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
			_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
			_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
			_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
			_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
			if MODEL_CACHE: _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__setModelCache(model_cache=MODEL_CACHE)
	if loading_result:
		_FRANKENSTEIN__FrankensteinClassesStructure = None
		if use_cache:
			_SapiensSAPI__semantic_ai_with_pretrained_integration = architecture_instance._SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
			_SemanticAIWithPretrainedIntegration__schizophrenic_ai = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__schizophrenic_ai
			if _SemanticAIWithPretrainedIntegration__schizophrenic_ai:
				_SchizophrenicAI__sapiens_schizophrenic_ai = _SemanticAIWithPretrainedIntegration__schizophrenic_ai._SchizophrenicAI__sapiens_schizophrenic_ai
				_SapiensSchizophrenicAI__schizophrenic_artificial_intelligence = _SchizophrenicAI__sapiens_schizophrenic_ai._SapiensSchizophrenicAI__schizophrenic_artificial_intelligence
				_SchizophrenicArtificialIntelligence__sapiens_architecture = _SapiensSchizophrenicAI__schizophrenic_artificial_intelligence._SchizophrenicArtificialIntelligence__sapiens_architecture
				_FRANKENSTEIN__FrankensteinClassesStructure = _SchizophrenicArtificialIntelligence__sapiens_architecture._FRANKENSTEIN__FrankensteinClassesStructure
				_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
		tokens_generator = architecture_instance.inference(**inference_kwargs)
		try:
			for chunk in tokens_generator: queue.put(('data', chunk))
		finally:
			if _FRANKENSTEIN__FrankensteinClassesStructure:
				_FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__use_cache = use_cache
				MODEL_CACHE = _FRANKENSTEIN__FrankensteinClassesStructure._SapiensFrankenstein__getModelCache()
	else: architecture_instance.close()		
	del architecture_instance
	collect()
	queue.put(('done', None))
from SAPI_ARCHITECTURE import SAPI as BaseSAPI
from FRANKENSTEIN_MODEL import FRANKENSTEIN as BaseFRANKENSTEIN
from sapiens_bench import SapiensBench as BaseSapiensBench
from sapiens_dataset import SapiensDataset as BaseSapiensDataset
from sapiens_stack import SapiensStack as BaseSapiensStack
class SapiensSDK:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else True
			try:
				from warnings import simplefilter, filterwarnings
				from logging import getLogger, ERROR, disable, CRITICAL
				from os import environ
				from dotenv import load_dotenv
				simplefilter('ignore')
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
				load_dotenv()
				disable(CRITICAL)
			except: pass
			from traceback import print_exc
			self.__print_exc = print_exc
			self.__internal_packages = ['hurnet', 'semantic-comparison-network', 'scnetwork', 'hurnet-torch', 'sapiens-tokenizer', 'perpetual-context',
			'sapiens-embedding', 'scn', 'hurnet-torch', 'sapiens-attention', 'sapiens-infinite-context-window', 'sapiens-generalization', 'sapiens-machine',
			'sapiens-accelerator', 'sapiens-transformers', 'infinite-context', 'utilities-nlp', 'perpetual-context-window', 'INFINITE-CONTEXT-WINDOW',
			'sapiens-file-interpreter', 'hur', 'hur-multimodal', 'sapiens-cpu', 'mgt', 'sapiens-dataset', 'models-selector', 'sapiens-model',
			'sapiens-entity', 'sapiens-submodels', 'SUBMODELS', 'sapiens-loader', 'ENTITY-MODEL', 'model-entity', 'sapiens-frankenstein', 'gptmodel',
			'sapiens-gpt', 'sapiens-bert', 'hurmodel', 'FRANKENSTEIN-MODEL', 'schizophrenic-artificial-intelligence', 'sapiens-schizophrenic-ai',
			'SCHIZOPHRENIC-AI', 'sapitensors', 'semantic-ai-with-pretrained-integration', 'sapiens-sapi', 'SAPI-ARCHITECTURE', 'context-length',
			'math-precision', 'sapiens-bench', 'sapiens-stack', 'single-hurnet-core', 'single-hurnet', 'singlelayer-hurnet', 'multi-hurnet',
			'multilayer-hurnet', 'sapiensknn', 'sapiensnb']
			self.__all_packages = ['numpy==1.25.2', 'torch-xla==2.7.0', 'torch==2.4.1', 'tqdm==4.67.1', 'dotenv==0.9.9', 'python-dotenv==1.2.2', 'tiktoken==0.4.0',
			'hurnet==1.0.8', 'ijson==3.3.0', 'psutil==7.0.0', 'semantic-comparison-network==2.0.4', 'requests==2.31.0', 'count-tokens==0.7.0', 'openpyxl==3.1.3',
			'pandas==2.2.2', 'statistics==1.0.3.5', 'certifi==2026.1.4', 'tabulate==0.9.0', 'PyPDF2==3.0.1', 'PyMuPDF==1.24.5', 'python-docx==1.1.0', 'python-pptx==0.6.23',
			'beautifulsoup4==4.12.3', 'youtube-search-python==1.6.6', 'youtube-transcript-api==1.2.2', 'pillow==10.3.0', 'easyocr==1.7.1', 'torchvision==0.19.1',
			'webcolors==1.13', 'scikit-learn==1.5.0', 'pydub==0.25.1', 'SpeechRecognition==3.10.3', 'scnetwork==1.1.3', 'hurnet-torch==1.1.2', 'sapiens-tokenizer==1.2.3',
			'langdetect==1.0.9', 'yake==0.6.0', 'perpetual-context==4.0.1', 'lxml==5.2.2', 'paddlepaddle==2.6.2', 'paddleocr==2.7.3', 'opencv-python==4.6.0.66',
			'moviepy==1.0.3', 'ffmpeg-python==0.2.0', 'docx2txt==0.8', 'youtube-transcript-extractor==0.1.4', 'sapiens-embedding==1.1.1', 'scn==3.0.3',
			'sapiens-attention==1.0.9', 'sapiens-infinite-context-window==1.0.5', 'sapiens-generalization==1.0.1', 'scipy==1.15.1', 'packaging==24.2',
			'PyYAML==6.0.2', 'huggingface-hub==0.28.1', 'safetensors==0.5.2', 'transformers==4.45.2', 'torchaudio==2.4.1', 'accelerate==1.3.0',
			'sapiens-machine==1.1.0', 'sapiens-accelerator==1.0.7', 'tokenizers==0.20.1', 'regex==2024.9.11', 'datasets==3.0.1', 'sentencepiece==0.2.0',
			'protobuf==5.29.2', 'optimum==1.23.3', 'einops==0.8.0', 'nemo-toolkit[all]==2.1.0', 'hydra-core==1.3.2', 'lightning==2.5.0', 'braceexpand==0.1.7',
			'webdataset==0.2.100', 'h5py==3.12.1', 'matplotlib==3.10.0', 'diffusers==0.32.2', 'llama-cpp-python==0.3.6', 'llamacpp==0.1.14', 'pyav==14.1.0',
			'av==15.1.0', 'ftfy==6.3.1', 'TTS==0.22.0', 'megatron-core==0.10.0', 'sapiens-transformers==1.9.0', 'cloudinary==1.40.0', 'opencv-python-headless==4.6.0.66',
			'gTTS==2.5.3', 'noisereduce==3.0.2', 'yt-dlp==2025.10.22', 'httpx<0.28.0', 'fasttext==0.9.3', 'langid==1.1.6', 'mutagen==1.47.0', 'openai-whisper==20231117',
			'setuptools-rust==1.10.1', 'fpdf==1.7.2', 'reportlab==4.2.2', 'docx==0.2.4', 'XlsxWriter==3.2.0', 'seaborn==0.13.2', 'graphviz==0.20.3', 'networkx==3.3',
			'wordcloud==1.9.3', 'rembg==2.0.67', 'onnxruntime==1.23.1', 'super-image==0.2.0', 'infinite-context==4.0.2', 'utilities-nlp==7.1.5',
			'perpetual-context-window==5.0.1', 'INFINITE-CONTEXT-WINDOW==3.0.2', 'sapiens-file-interpreter==2.0.7', 'markdownify==1.2.2', 'mammoth==1.11.0',
			'wikipedia==1.4.0', 'StackAPI==0.3.1', 'hur==1.1.7', 'hur-multimodal==2.0.3', 'sapiens-cpu==4.0.1', 'mgt==2.0.9', 'sapiens-dataset==4.0.7',
			'models-selector==1.0.4', 'sapiens-model==3.1.9', 'sapiens-entity==5.0.7', 'sapiens-submodels==1.1.4', 'SUBMODELS==1.0.9', 'sapiens-loader==1.0.7',
			'ENTITY-MODEL==1.0.7', 'model-entity==1.0.7', 'sapiens-frankenstein==2.3.3', 'gptmodel==1.0.9', 'sapiens-gpt==5.0.8', 'sapiens-bert==3.0.3',
			'hurmodel==1.1.8', 'FRANKENSTEIN-MODEL==5.3.7', 'schizophrenic-artificial-intelligence==1.2.3', 'sapiens-schizophrenic-ai==1.0.7', 'SCHIZOPHRENIC-AI==1.0.7',
			'sapitensors==1.1.9', 'semantic-ai-with-pretrained-integration==1.1.7', 'sapiens-sapi==1.1.0', 'SAPI-ARCHITECTURE==1.0.5', 'context-length==1.0.7',
			'math-precision==1.0.1', 'sapiens-bench==1.0.7', 'sapiens-stack==1.0.2']
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def installDependencies(self, internal_versions=False, external_versions=True, package=''):
		try:
			installed_dependencies = {'installed': [], 'not_installed':[]}
			internal_versions = bool(internal_versions) if type(internal_versions) in (bool, int, float) else False
			external_versions = bool(external_versions) if type(external_versions) in (bool, int, float) else True
			package = str(package).strip()
			from sys import executable as python_executable
			from subprocess import run as run_subprocess
			from subprocess import DEVNULL as null_device
			from tqdm import tqdm as progress_bar
			from importlib.metadata import version as get_package_version
			all_packages = self.__all_packages
			internal_packages = self.__internal_packages
			all_packages_dictionary = {}
			for package_string in all_packages:
				if '==' in package_string: all_packages_dictionary[package_string.split('==')[0]] = package_string
				else: all_packages_dictionary[package_string] = package_string
			merged_packages_dictionary = {}
			for package_name in internal_packages:
				if package_name in all_packages_dictionary:
					if internal_versions: merged_packages_dictionary[package_name] = all_packages_dictionary[package_name]
					else: merged_packages_dictionary[package_name] = package_name
				else: merged_packages_dictionary[package_name] = package_name
			for package_name, package_string in all_packages_dictionary.items():
				if package_name not in internal_packages:
					if external_versions: merged_packages_dictionary[package_name] = package_string
					else: merged_packages_dictionary[package_name] = package_name
			packages_to_install = list(merged_packages_dictionary.values())
			if package != '':
				packages_to_install = [package]
				total_packages_count = 1
			else:
				packages = []
				for package in all_packages:
				    package = package.split('==')[0]
				    packages.append(package)
				for package in internal_packages:
				    packages.append(package)
				packages = sorted(list(set(packages)))
				total_packages_count = len(packages)
			installed_count = 0
			failed_count = 0
			with progress_bar(total=len(packages_to_install), desc="installing") as installation_progress:
				for package_item in packages_to_install:
					package_parts = package_item.split('==')
					package_name = package_parts[0]
					package_version = package_parts[1] if len(package_parts) > 1 else ''
					needs_installation = True
					try:
						installed_version = get_package_version(package_name)
						if package_version != '':
							if installed_version == package_version: needs_installation = False
						else: needs_installation = False
					except Exception: needs_installation = True
					if needs_installation:
						execution_result = run_subprocess([python_executable, '-m', 'pip', 'install', package_item], stdout=null_device, stderr=null_device)
						if execution_result.returncode == 0:
							installed_dependencies['installed'].append(package_item)
							installed_count += 1
						else:
							installed_dependencies['not_installed'].append(package_item)
							failed_count += 1
					else:
						installed_dependencies['installed'].append(package_item)
						installed_count += 1
					installation_progress.set_postfix({'total': total_packages_count, 'installed': installed_count, 'not_installed': failed_count})
					installation_progress.update(1)
			return installed_dependencies
		except Exception as error: 
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.installDependencies: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return {'installed': [], 'not_installed': []}
	def downloadModel(self, model_path='', output_path='', progress=True):
		try:
			downloaded_model = False
			model_path = str(model_path).strip()
			output_path = str(output_path).strip()
			progress = bool(progress) if type(progress) in (bool, int, float) else True
			if not model_path: return downloaded_model
			model_name = output_path
			if '/' not in model_path:
				if model_path.endswith('.sapiens'): model_path = model_path.split('.sapiens')[0].strip()
				model_path = f'schatmodels/{model_path[::-1]}'.strip()
				model_name = model_path.split('/')[-1][::-1].strip()
			else: model_name = model_path.split('/')[-1].strip()
			if not output_path: output_path = model_name
			if output_path.find('.') > 0: output_path = output_path.split('.')[0].strip()
			from SAPI_ARCHITECTURE import SAPI
			from os.path import join, exists
			from shutil import move, rmtree
			sapi = SAPI(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
			_SAPI__sapiens_sapi = sapi._SAPI__sapiens_sapi
			_SapiensSAPI__semantic_ai_with_pretrained_integration = _SAPI__sapiens_sapi._SapiensSAPI__semantic_ai_with_pretrained_integration
			__get_extra_data = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__get_extra_data
			__get_system_directory = _SapiensSAPI__semantic_ai_with_pretrained_integration._SemanticAIWithPretrainedIntegration__get_system_directory
			system_directory = __get_system_directory()
			output_directory = join(system_directory, model_name)
			if exists(output_directory):
				try: rmtree(output_directory)
				except: pass
			def _repository_exists(repository_name=''):
				repository_name = str(repository_name).strip()
				if repository_name.startswith('https://huggingface.co/'): repository_name = repository_name.replace('https://huggingface.co/', '')
				from requests import get
				try:
					repository_name = str(repository_name).strip()
					if not repository_name or '/' not in repository_name: return False
					url = f'https://huggingface.co/api/models/{repository_name}'
					response = get(url, timeout=10)
					return response.status_code == 200
				except: return False
			if not _repository_exists(repository_name=model_path):
				model_rote = model_path.split('/')
				model_rote[-1] = model_rote[-1][::-1]
				model_path = '/'.join(model_rote)
				if '/' not in model_path: model_name = model_name[::-1]
			downloaded_model = __get_extra_data(model_path=model_path, output_path=output_directory, description=model_name, progress=progress)
			def _move_and_cleanup(directory_path='', target_file_path=''):
				move_and_cleanup = False
				directory_path = str(directory_path).strip()
				target_file_path = str(target_file_path).strip()
				if not directory_path or not target_file_path: return move_and_cleanup
				from os import walk, path, makedirs
				extensions = ['.sapiens', '.submodel', '.SAPI']
				found_file = None
				for extension in extensions:
					for root, dirs, files in walk(directory_path):
						for file in files:
							if file.endswith(extension):
								found_file = path.join(root, file)
								break
						if found_file: break
					if found_file: break
				if found_file:
					file_extension = path.splitext(found_file)[1]
					final_path = target_file_path+file_extension
					target_directory = path.dirname(final_path)
					if target_directory: makedirs(target_directory, exist_ok=True)
					move(found_file, final_path)
					try: rmtree(directory_path)
					except: return move_and_cleanup
					move_and_cleanup = path.exists(final_path)
				else:
					target_directory = path.dirname(target_file_path)
					if target_directory: makedirs(target_directory, exist_ok=True)
					try:
						move(directory_path, target_file_path)
						move_and_cleanup = path.exists(target_file_path)
					except: move_and_cleanup = False
				return move_and_cleanup
			if downloaded_model: downloaded_model = _move_and_cleanup(directory_path=output_directory, target_file_path=output_path)
			return downloaded_model
		except Exception as error: 
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.downloadModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def runAPI(self, models_path='', host='0.0.0.0', port=8080, use_multiprocessing=False, use_threads=True, use_cache=True):
		try: self.__runAPI_internal(models_path=models_path, host=host, port=port, use_multiprocessing=use_multiprocessing, use_threads=use_threads, use_cache=use_cache)
		except Exception as error: 
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.runAPI [API server closed]: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def __runAPI_internal(self, models_path='', host='0.0.0.0', port=8080, use_multiprocessing=False, use_threads=True, use_cache=True):
		try:
			models_path = str(models_path).strip()
			host = str(host).strip()
			port = int(port) if type(port) in (int, float) else 8080
			use_multiprocessing = bool(use_multiprocessing) if type(use_multiprocessing) in (bool, int, float) else False
			use_threads = bool(use_threads) if type(use_threads) in (bool, int, float) else True
			use_cache = bool(use_cache) if type(use_cache) in (bool, int, float) else False
			if use_cache: use_multiprocessing = not use_cache
			from http.server import BaseHTTPRequestHandler, HTTPServer
			from json import loads, dumps
			from urllib.parse import urlparse
			def _merge_directories(directory=''): return path.join(models_path, directory)
			target_directory = _merge_directories(directory='models')
			if path.isdir(target_directory):
				directory_path = target_directory
				file_paths = [path.join(directory_path, file_name) for file_name in listdir(directory_path) if file_name.endswith('.sapiens') and path.isfile(path.join(directory_path, file_name))]
				if file_paths:
					from SUBMODELS import SUBMODELS
					submodels = SUBMODELS(show_errors=self.__show_errors)
					if submodels:
						from tqdm import tqdm
						total_files = len(file_paths)
						if total_files > 0:
							for file_path in tqdm(file_paths, total=total_files, desc='Loading models'):
								if file_path: submodels.loadModel(model_path=file_path, progress=True)
			if use_threads:
				processor_cores = cpu_count() or 1
				from concurrent.futures import ThreadPoolExecutor
				thread_executor = ThreadPoolExecutor(max_workers=processor_cores)
			else: thread_executor = None
			def _process_api_request(endpoint_path='', request_data=None):
				if use_multiprocessing:
					queue = Queue()
					process = Process(target=_mp_process_api_request, args=(queue, models_path, endpoint_path, request_data, use_cache))
					process.start()
					response_data = queue.get()
					process.join()
					return response_data
				else:
					queue = Queue()
					_mp_process_api_request(queue, models_path, endpoint_path, request_data, use_cache)
					return queue.get()
			class APIRequestHandler(BaseHTTPRequestHandler):
				def do_OPTIONS(self):
					self.send_response(200)
					self.send_header('Access-Control-Allow-Origin', '*')
					self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
					self.send_header('Access-Control-Allow-Headers', 'Content-Type')
					self.end_headers()
				def do_POST(self):
					content_length = int(self.headers.get('Content-Length', 0))
					request_body = self.rfile.read(content_length).decode('utf-8')
					try: request_data = loads(request_body)
					except: request_data = {}
					parsed_url = urlparse(self.path)
					endpoint_path = parsed_url.path
					stream = bool(request_data.get('stream', True))
					if endpoint_path == '/inference' and stream:
						self.send_response(200)
						self.send_header('Content-Type', 'application/x-ndjson')
						self.send_header('Access-Control-Allow-Origin', '*')
						self.end_headers()
						user_code = str(request_data.get('user_code', '')).strip()
						safe_user_code = path.basename(user_code) if user_code else ''
						target_dir = safe_user_code if safe_user_code else 'models'
						target_dir = _merge_directories(directory=target_dir)
						model_name = str(request_data.get('model_name', 'default.model')).strip()
						global MODEL_CACHE, MODEL_NAME
						if model_name and model_name != MODEL_NAME:
							from gc import collect
							MODEL_NAME = model_name
							MODEL_CACHE = None
							collect()
						safe_model_name = path.basename(model_name)
						model_path = path.join(target_dir, safe_model_name)
						if not path.exists(model_path): model_path = model_path.replace(safe_user_code, 'models')
						language = str(request_data.get('language', '')).strip()
						if '-' in language: language = str(language.split('-')[0]).strip()
						inference_kwargs = {
							'messages': list(request_data.get('messages', [])),
							'max_tokens': request_data.get('max_tokens', None),
							'stream': stream,
							'task_names': list(request_data.get('task_names', [])),
							'language': language,
							'temperature': float(request_data.get('temperature', 0.5)),
							'creativity': float(request_data.get('creativity', 0.5)),
							'humor': float(request_data.get('humor', 0.5)),
							'formality': float(request_data.get('formality', 0.5)),
							'political_spectrum': float(request_data.get('political_spectrum', 0.5)),
							'reasoning': float(request_data.get('reasoning', 0.0)),
							'reflection': bool(request_data.get('reflection', False)),
							'tools': list(request_data.get('tools', []))
						}
						queue, process, is_thread = Queue(), None, False
						if use_multiprocessing:
							process = Process(target=_mp_stream_inference, args=(queue, model_path, inference_kwargs, use_cache))
							process.start()
						elif use_threads:
							from threading import Thread
							process = Thread(target=_mp_stream_inference, args=(queue, model_path, inference_kwargs, use_cache))
							process.start()
							is_thread = True
						else: _mp_stream_inference(queue, model_path, inference_kwargs, use_cache)
						count_chunk = 0
						max_tokens = request_data.get('max_tokens', None)
						tokenize = (type(max_tokens) == int and max_tokens > 0) or (max_tokens is None)
						tokens_limit = max_tokens if max_tokens and type(max_tokens) == int else float('inf')
						while True:
							msg = queue.get()
							if msg[0] == 'done': break
							elif msg[0] == 'data':
								count_chunk += 1
								if tokenize and count_chunk <= tokens_limit:
									try:
										self.wfile.write((dumps(msg[1]) + "\n").encode('utf-8'))
										self.wfile.flush()
									except:
										if process and not is_thread: process.terminate()
										break
						if process: process.join()
						return
					elif endpoint_path == '/download-model':
						user_code = str(request_data.get('user_code', '')).strip()
						safe_user_code = path.basename(user_code) if user_code else ''
						target_dir = safe_user_code if safe_user_code else 'models'
						target_dir = _merge_directories(directory=target_dir)
						model_name = str(request_data.get('model_name', '')).strip()
						safe_model_name = path.basename(model_name)
						model_path = path.join(target_dir, safe_model_name)
						if path.exists(model_path) and path.isfile(model_path):
							self.send_response(200)
							self.send_header('Content-Type', 'application/octet-stream')
							self.send_header('Access-Control-Allow-Origin', '*')
							self.send_header('Content-Disposition', f'attachment; filename="{safe_model_name}"')
							self.send_header('Content-Length', str(path.getsize(model_path)))
							self.end_headers()
							with open(model_path, 'rb') as model_file:
								while True:
									file_chunk = model_file.read(65536)
									if not file_chunk: break
									self.wfile.write(file_chunk)
							return
						self.send_response(404)
						self.send_header('Content-Type', 'application/json')
						self.send_header('Access-Control-Allow-Origin', '*')
						error_response = dumps({'error': 'The model file was not found on the server.'}).encode('utf-8')
						self.send_header('Content-Length', str(len(error_response)))
						self.end_headers()
						self.wfile.write(error_response)
						return
					response_data = _process_api_request(endpoint_path, request_data)
					response_body = dumps(response_data).encode('utf-8')
					self.send_response(200)
					self.send_header('Content-Type', 'application/json')
					self.send_header('Access-Control-Allow-Origin', '*')
					self.send_header('Content-Length', str(len(response_body)))
					self.end_headers()
					self.wfile.write(response_body)
			class CoreBoundHTTPServer(HTTPServer):
				def process_request(self, client_request=None, client_address=None):
					def _handle_and_close():
						try: self.finish_request(client_request, client_address)
						except Exception: self.handle_error(client_request, client_address)
						finally: self.shutdown_request(client_request)
					if use_threads and thread_executor: thread_executor.submit(_handle_and_close)
					else: _handle_and_close()
			api_server = CoreBoundHTTPServer((host, port), APIRequestHandler)
			def _display_image_in_terminal(image_path=''):
				image_path = str(image_path).strip()
				from shutil import get_terminal_size
				try: from PIL import Image
				except: return
				def __get_current_directory():
					current_directory = path.dirname(path.abspath(__file__))
					return current_directory
				image_path = path.join(__get_current_directory(), image_path)
				terminal_width = get_terminal_size().columns
				grayscale_chars = '@%#*+=-:. '
				try:
					image = Image.open(image_path).convert('L')
					width, height = image.size
					aspect_ratio = height/width
					new_width = terminal_width
					new_height = int(aspect_ratio*new_width*0.55)
					image = image.resize((new_width, new_height))
					try: pixels = list(image.get_flattened_data())
					except: pixels = list(image.getdata())
					ascii_image = ''.join(grayscale_chars[pixel*len(grayscale_chars)//256] for pixel in pixels)
					for index in range(0, len(ascii_image), new_width): print(ascii_image[index:index+new_width])
				except: pass
			_display_image_in_terminal(image_path='sapiens.png')
			print("SAPIENS TECHNOLOGY local server fully operational...")
			api_server.serve_forever()
		except Exception as error: 
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.__runAPI_internal [API server closed]: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def repositoryUpload(self, model_path='', access_token='', repository_name=''):
		try:
			upload_result = False
			model_path = str(model_path).strip()
			access_token = str(access_token).strip()
			repository_name = str(repository_name).strip()
			if not model_path: return upload_result
			from pathlib import Path
			from huggingface_hub import HfApi
			_model_path = Path(model_path)
			_repository_name = repository_name if repository_name else (_model_path.stem if _model_path.is_file() else _model_path.name)
			repository_id = f'schatmodels/{_repository_name}'
			api = HfApi()
			api.create_repo(repo_id=repository_id, token=access_token, exist_ok=True)
			if _model_path.is_file(): api.upload_file(path_or_fileobj=str(_model_path), path_in_repo=_model_path.name, repo_id=repository_id, token=access_token)
			elif _model_path.is_dir(): api.upload_folder(folder_path=str(_model_path), repo_id=repository_id, token=access_token)
			upload_result = True
			return upload_result
		except Exception as error: 
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensSDK.repositoryUpload: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
class SAPI(BaseSAPI): pass
class FRANKENSTEIN(BaseFRANKENSTEIN): pass
class SapiensBench(BaseSapiensBench): pass
class SapiensDataset(BaseSapiensDataset): pass
class SapiensStack(BaseSapiensStack): pass
"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
