"""MCP tool definitions — shared across stdio and HTTP transports.

Each ``@mcp.tool`` calls the SONAR public API via ``client.call_sonar()``
and formats the response as Markdown the LLM can ingest. Tool annotations
follow the MCP spec (``readOnlyHint``, ``destructiveHint``, ``openWorldHint``)
so MCP clients can render them with appropriate UX warnings.

Tool catalogue:

  - kyb_findings        — quick KYB lookup (raw signals, no AI analysis)
  - kyb_run_submit      — full KYB report (Claude analysis, async)
  - competitive_findings— quick CI lookup
  - competitive_run_submit — full CI report (async)
  - adverse_media       — focused negative-media + complaints check
  - check_report_status — poll an async submission
  - account_balance     — read current account balance + free-tier remaining
"""

from __future__ import annotations

import json
from typing import Any

from .client import (
    call_sonar,
    format_findings,
    format_run_started,
    format_run_status,
    get_api_key_from_env,
)


def register_tools(mcp: Any) -> None:
    """Register all SONAR tools onto a FastMCP instance.

    Caller passes their FastMCP instance (different transports build the
    instance differently — see stdio.py and http_server.py).
    """

    # ── KYB ────────────────────────────────────────────────────────────────
    @mcp.tool(
        annotations={
            "title": "KYB Quick Lookup",
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": True,
        }
    )
    async def kyb_findings(company_name: str, website: str = "") -> str:
        """Run a fast KYB (Know Your Business) screening on a company.

        Returns raw structured findings — corporate registration, sanctions,
        adverse media, regulatory licensure (FCA for UK), directors, UBOs.
        Cheap, fast (30-90s), no Claude analysis. After 3 free trial calls: $0.40/call.
        

        Args:
            company_name: Legal name of the company (e.g. "Tesco PLC")
            website: Company website URL for better disambiguation
        """
        api_key = get_api_key_from_env()
        body = {"company_name": company_name}
        if website:
            body["website"] = website
        result = await call_sonar(
            "POST", "/v1/agents/kyb-diligence/findings", api_key, body=body,
        )
        return format_findings(result, f"KYB Quick Lookup: {company_name}")

    @mcp.tool(
        annotations={
            "title": "KYB Full Report (async)",
            "readOnlyHint": False,
            "destructiveHint": False,
            "openWorldHint": True,
        }
    )
    async def kyb_run_submit(company_name: str, website: str = "") -> str:
        """Submit a full KYB compliance report for AI-narrated analysis.

        Returns a run_id immediately (202). Poll with check_report_status
        in 1-3 minutes. Includes everything kyb_findings returns plus
        Claude-generated risk flags, narrative summary, and recommendations
        formatted for compliance-officer review. After 3 free trial calls: $2.00/call.
        

        Args:
            company_name: Legal name of the company
            website: Company website URL
        """
        api_key = get_api_key_from_env()
        body = {"company_name": company_name}
        if website:
            body["website"] = website
        result = await call_sonar(
            "POST", "/v1/agents/kyb-diligence/run", api_key, body=body,
        )
        return format_run_started(result, "kyb-diligence")

    # ── Competitive Intelligence ───────────────────────────────────────────
    @mcp.tool(
        annotations={
            "title": "Competitive Intelligence Quick Lookup",
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": True,
        }
    )
    async def competitive_findings(company_name: str, website: str = "") -> str:
        """Research a company for competitive intelligence signals.

        Returns structured signals on pricing changes, product updates,
        hiring, corporate events, customer sentiment, tech stack, and
        market presence. After 3 free trial calls: $0.40/call.

        Args:
            company_name: The company to research (e.g. "Notion")
            website: Company website URL for better accuracy
        """
        api_key = get_api_key_from_env()
        body = {"company_name": company_name}
        if website:
            body["website"] = website
        result = await call_sonar(
            "POST", "/v1/agents/company-intelligence/findings", api_key, body=body,
        )
        return format_findings(result, f"Competitive Intel: {company_name}")

    @mcp.tool(
        annotations={
            "title": "Competitive Intelligence Full Report (async)",
            "readOnlyHint": False,
            "destructiveHint": False,
            "openWorldHint": True,
        }
    )
    async def competitive_run_submit(company_name: str, website: str = "") -> str:
        """Submit a full competitive-intelligence report for AI analysis.

        Async — returns run_id, poll with check_report_status. Includes
        narrative analysis, top alerts, competitor positioning, strategic
        recommendations. After 3 free trial calls: $2.00/call.

        Args:
            company_name: The company to analyze
            website: Company website URL
        """
        api_key = get_api_key_from_env()
        body = {"company_name": company_name}
        if website:
            body["website"] = website
        result = await call_sonar(
            "POST", "/v1/agents/company-intelligence/run", api_key, body=body,
        )
        return format_run_started(result, "company-intelligence")

    # ── Adverse Media ──────────────────────────────────────────────────────
    @mcp.tool(
        annotations={
            "title": "Adverse Media Check",
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": True,
        }
    )
    async def adverse_media(company_name: str, website: str = "") -> str:
        """Screen a company for negative news, complaints, and bad reviews.

        Checks news sources, review platforms (G2, Capterra, Trustpilot,
        BBB), Reddit, and complaint databases. After 3 free trial calls: $0.40/call.
        

        Args:
            company_name: Company to screen
            website: Company website URL for accuracy
        """
        api_key = get_api_key_from_env()
        body = {"company_name": company_name}
        if website:
            body["website"] = website
        result = await call_sonar(
            "POST", "/v1/agents/adverse-media/findings", api_key, body=body,
        )
        return format_findings(result, f"Adverse Media: {company_name}")

    # ── Async polling ──────────────────────────────────────────────────────
    @mcp.tool(
        annotations={
            "title": "Check Report Status",
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        }
    )
    async def check_report_status(
        run_id: str,
        agent_type: str = "kyb-diligence",
    ) -> str:
        """Poll the status of an async report submitted via *_run_submit.

        Returns the full report JSON when status='completed'. Reports
        typically complete in 60-180s.

        Args:
            run_id: The run_id returned by kyb_run_submit / competitive_run_submit
            agent_type: One of "kyb-diligence", "company-intelligence", "adverse-media"
        """
        valid = {"kyb-diligence", "company-intelligence", "adverse-media"}
        if agent_type not in valid:
            return json.dumps({
                "error": f"Invalid agent_type. Must be one of: {sorted(valid)}"
            })
        api_key = get_api_key_from_env()
        result = await call_sonar(
            "GET", f"/v1/agents/{agent_type}/run/{run_id}", api_key,
        )
        return format_run_status(result)

    # ── Account / billing ──────────────────────────────────────────────────
    @mcp.tool(
        annotations={
            "title": "Account Balance & Usage",
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        }
    )
    async def account_balance() -> str:
        """Check current account usage, free-trial calls remaining, and pre-paid balance.

        Useful for AI agents to decide whether the next call will be free,
        paid, or fail with insufficient balance. Free trial is 3 lifetime
        calls per account (any endpoint type). After that, /findings calls
        deduct $0.40 and /run calls deduct $2.00 from balance_cents.
        """
        api_key = get_api_key_from_env()
        result = await call_sonar("GET", "/v1/usage", api_key)
        if result.get("error"):
            return f"⚠️  Couldn't read account: {result.get('message', '')}"
        period = result.get("period", "")
        total = result.get("total_requests", 0)
        free_remaining = result.get("free_trial_remaining", 0)
        balance_cents = result.get("balance_cents", 0)
        balance_str = f"${balance_cents // 100}.{balance_cents % 100:02d}"
        by_endpoint = result.get("by_endpoint", {}) or {}
        lines = [
            f"# Account usage — {period}",
            f"- Calls this month: **{total}**",
            f"- Free trial calls remaining: **{free_remaining}** (lifetime — not monthly)",
            f"- Pre-paid balance: **{balance_str}**",
        ]
        if by_endpoint:
            lines.append("")
            lines.append("By endpoint:")
            for k, v in sorted(by_endpoint.items()):
                lines.append(f"  - {k}: {v}")
        if free_remaining == 0 and balance_cents < 40:
            lines.append("")
            lines.append(
                "⚠️  Free trial used up and balance is below $0.40 (the cheapest "
                "/findings call). Top up at https://getsonar.report/api-keys."
            )
        elif free_remaining == 0 and balance_cents < 200:
            lines.append("")
            lines.append(
                "ℹ️  Free trial used up. Balance covers /findings calls but not "
                "/run reports ($2.00 each). Top up at https://getsonar.report/api-keys."
            )
        return "\n".join(lines)
