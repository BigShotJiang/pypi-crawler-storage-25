"""
Input/Output functions for RIPER calculations.

Handles:
    - Writing TURBOMOLE coord files
    - Writing TURBOMOLE control files
    - Reading energy from RIPER output
    - Reading forces from TURBOMOLE gradient file
    - Reading stress from RIPER gradlatt output
"""

import numpy as np
import os

from riper.utils import (
    ANGSTROM_TO_BOHR,
    BOHR_TO_ANGSTROM,
    HARTREE_TO_EV,
    HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM,
    cell_to_lattice_vectors,
)


def write_coord(atoms, filepath="coord"):
    """
    Write atomic coordinates in TURBOMOLE coord format (Bohr units).

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object.
    filepath : str
        Path to the output coord file.
    """
    positions_bohr = atoms.positions * ANGSTROM_TO_BOHR
    symbols = atoms.get_chemical_symbols()

    with open(filepath, "w") as f:
        f.write("$coord\n")
        for pos, sym in zip(positions_bohr, symbols):
            f.write(
                f"  {pos[0]:20.14f}  {pos[1]:20.14f}  {pos[2]:20.14f}  "
                f"{sym.lower()}\n"
            )
        f.write("$end\n")


def write_control(atoms, params, directory="."):
    """
    Write the TURBOMOLE control file for a RIPER calculation.

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object.
    params : dict
        Calculator parameters (basis, auxbasis, functional, nkpoints, etc.).
    directory : str
        Directory where control file will be written.
    """
    npdir = params.get("periodicity", 0)
    basis = params["basis"]
    auxbasis = params["auxbasis"]
    functional = params["functional"]
    nkpoints = params.get("nkpoints", [2, 2, 2])
    charge = params.get("charge", 0)
    uks = params.get("uks", False)
    smear = params.get("smear", False)
    sigma = params.get("sigma", 0.01)
    calculate_stress = params.get("calculate_stress", False)
    extra_keywords = params.get("extra_keywords", {})
    scfiterlimit = params.get("scfiterlimit", 50)
    scfconv = params.get("scfconv", 7)
    denconv = params.get("denconv", None)
    disp3 = params.get("disp3", False)
    plot_dens = params.get("plot_dens", False)

    control_path = os.path.join(directory, "control")

    lines = []

    # Coordinate file reference
    lines.append("$coord file=coord")

    # Atoms section: basis and auxiliary basis
    lines.append("$atoms")
    lines.append(f"  basis ={basis}")
    lines.append(f"  jbas  ={auxbasis}")

    # Periodicity and lattice
    if npdir > 0:
        lines.append(f"$periodic {npdir}")

        lattice_vecs = cell_to_lattice_vectors(atoms, npdir)
        lines.append("$lattice")
        for vec in lattice_vecs:
            line = "  " + "  ".join(f"{v:20.14f}" for v in vec)
            lines.append(line)

    # DFT functional
    lines.append("$dft")
    lines.append(f"  functional {functional}")
    lines.append(f"  gridsize m5")
    lines.append(f"  weight derivatives")

    # k-point sampling (only for periodic systems)
    if npdir > 0:
        lines.append("$kpoints")
        kpts = nkpoints[:npdir]  # Only use as many k-points as periodic directions
        kpt_str = " ".join(str(k) for k in kpts)
        lines.append(f"  nkpoints {kpt_str}")

    # Charge specification
    if charge != 0:
        lines.append("$atomdens")
        lines.append(f"  charge {charge}")

    # UKS (unrestricted Kohn-Sham)
    if uks:
        lines.append("$uhf")

    # SCF iteration limit
    lines.append(f"$scfiterlimit {scfiterlimit}")

    # SCF energy convergence criterion
    lines.append(f"$scfconv {scfconv}")

    # Density convergence criterion (only if specified)
    if denconv is not None:
        lines.append(f"$denconv {denconv}")

    # D3 dispersion correction
    if disp3:
        lines.append("$disp3")

    # RIPER-specific settings
    riper_lines = []
    if smear:
        riper_lines.append(f"  sigma {sigma}")
    # if calculate_stress and npdir > 0:
    #     riper_lines.append("  lstress on")

    # Add any extra riper keywords
    for key, val in extra_keywords.items():
        riper_lines.append(f"  {key} {val}")

    if riper_lines:
        lines.append("$riper")
        lines.extend(riper_lines)

    # Cell optimization keyword triggers stress calculation
    if calculate_stress and npdir > 0:
        lines.append("$optcell")

    # Electron density cube file output
    if plot_dens:
        lines.append("$pointvalper fmt=cub")
        lines.append("   dens")

    lines.append("$end")

    with open(control_path, "w") as f:
        f.write("\n".join(lines) + "\n")


def read_energy(output_file):
    """
    Read the total energy from the RIPER output file.

    Looks for the 'FINAL ENERGIES' section and extracts the 'TOTAL ENERGY'.

    Parameters
    ----------
    output_file : str
        Path to the RIPER output file.

    Returns
    -------
    float
        Total energy in eV.

    Raises
    ------
    RuntimeError
        If the output file is not found or energy cannot be parsed.
    """
    energy = None
    in_final_energies = False

    try:
        with open(output_file, "r") as f:
            for line in f:
                if "FINAL ENERGIES" in line:
                    in_final_energies = True
                if in_final_energies and "TOTAL ENERGY" in line:
                    parts = line.split()
                    # Find the numeric value after "TOTAL ENERGY"
                    for i, part in enumerate(parts):
                        if part == "ENERGY":
                            # Energy value is typically at index i+1 or later
                            for j in range(i + 1, len(parts)):
                                try:
                                    energy = float(parts[j])
                                    break
                                except ValueError:
                                    continue
                            break
                    if energy is not None:
                        break
    except FileNotFoundError:
        raise RuntimeError(f"Output file '{output_file}' not found.")

    if energy is None:
        raise RuntimeError(
            f"Total energy not found in the 'FINAL ENERGIES' section of '{output_file}'."
        )

    return energy * HARTREE_TO_EV


def read_forces(gradient_file, natoms):
    """
    Read atomic forces from the TURBOMOLE gradient file.

    The gradient file contains gradients (negative forces) in Hartree/Bohr.

    Parameters
    ----------
    gradient_file : str
        Path to the gradient file.
    natoms : int
        Number of atoms.

    Returns
    -------
    numpy.ndarray
        Forces array of shape (natoms, 3) in eV/Angstrom.

    Raises
    ------
    RuntimeError
        If the gradient file cannot be read or parsed.
    """
    try:
        with open(gradient_file, "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        raise RuntimeError(f"Gradient file '{gradient_file}' not found.")

    # Find $grad block
    grad_start = None
    for i, line in enumerate(lines):
        if "$grad" in line:
            grad_start = i
            break

    if grad_start is None:
        raise RuntimeError("Gradient block ($grad) not found in the gradient file.")

    # Find $end
    grad_end = None
    for i in range(len(lines) - 1, grad_start, -1):
        if "$end" in lines[i]:
            grad_end = i
            break

    if grad_end is None:
        raise RuntimeError("End of gradient block ($end) not found.")

    # The last natoms lines before $end are the gradient values
    gradient_lines = lines[grad_end - natoms : grad_end]

    gradients = []
    for line in gradient_lines:
        # Replace Fortran 'D' notation with 'E'
        values = [float(x.replace("D", "E")) for x in line.split()]
        gradients.append(values)

    gradients = np.array(gradients)

    # Forces = -gradients, convert from Hartree/Bohr to eV/Angstrom
    forces = -gradients * HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM

    return forces


def read_stress(output_file, atoms):
    """
    Read the stress tensor from the RIPER output file by parsing the
    'stress tensor, raw' section.

    RIPER prints the stress tensor in the output file in the following format:
        stress tensor, raw:
        in the order xx,xy,yy,xz,yz,zz,yx,zx,zy
        <9 values, one per line>

    The values are in atomic units (Hartree/Bohr^3).

    Parameters
    ----------
    output_file : str
        Path to the RIPER output file.
    atoms : ase.Atoms
        The atoms object (needed for unit cell information).

    Returns
    -------
    numpy.ndarray
        Stress in Voigt notation (6 components) in eV/Angstrom^3.
        Convention: [xx, yy, zz, yz, xz, xy]

    Raises
    ------
    RuntimeError
        If stress data cannot be found or parsed.
    """
    # Read the RIPER output file
    try:
        with open('riper.out', "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        raise RuntimeError(
            f"RIPER output file '{output_file}' not found for stress reading."
        )

    # Find the "stress tensor, raw:" section
    stress_start = None
    for i, line in enumerate(lines):
        if "stress tensor, raw:" in line:
            stress_start = i
            break

    if stress_start is None:
        raise RuntimeError(
            "Stress tensor section not found in RIPER output file. "
            "Make sure $optcell is in the control file and the calculation "
            "completed successfully."
        )

    # The order line is at stress_start + 1:
    #   "in the order xx,xy,yy,xz,yz,zz,yx,zx,zy"
    # Then 9 values follow, one per line, starting at stress_start + 2
    raw_values = []
    for i in range(stress_start + 2, stress_start + 2 + 9):
        try:
            val = float(lines[i].strip().replace("D", "E"))
            raw_values.append(val)
        except (ValueError, IndexError) as e:
            raise RuntimeError(
                f"Failed to parse stress tensor value at line {i + 1}: {e}"
            )

    if len(raw_values) != 9:
        raise RuntimeError(
            f"Expected 9 stress tensor components, got {len(raw_values)}."
        )

    # Order from RIPER: xx, xy, yy, xz, yz, zz, yx, zx, zy
    sxx = raw_values[0]
    sxy = raw_values[1]
    syy = raw_values[2]
    sxz = raw_values[3]
    syz = raw_values[4]
    szz = raw_values[5]
    # raw_values[6] = yx (should equal xy)
    # raw_values[7] = zx (should equal xz)
    # raw_values[8] = zy (should equal yz)

    # Values are in eV/Angstrom^3 already

    # ASE Voigt convention: [xx, yy, zz, yz, xz, xy]
    voigt_stress = np.array([
        sxx,
        syy,
        szz,
        syz,
        sxz,
        sxy,
    ]) 

    return voigt_stress