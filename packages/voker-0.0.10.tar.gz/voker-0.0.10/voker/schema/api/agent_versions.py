# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agent version related payloads and responses."""

from typing import NotRequired, Required, TypedDict


class CreateAgentVersionPayload(TypedDict):
    """Create an agent version.

    See [Creating an Agent Version](https://app.voker.ai/docs/concepts/agents#creating-agent-version) for more information.
    """

    agent_version_name: Required[str]
    """Unique identifier for the agent version within its agent."""

    description: NotRequired[str]
