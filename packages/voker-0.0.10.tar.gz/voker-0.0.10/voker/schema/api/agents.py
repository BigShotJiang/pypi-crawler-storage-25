# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agent related payloads and responses."""

from typing import NotRequired, Required, TypedDict


class CreateAgentPayload(TypedDict):
    """Create an agent.

    See [Creating an Agent](https://app.voker.ai/docs/concepts/agents#creating-agent) for more information.
    """

    agent_name: Required[str]
    """Unique identifier for the agent."""

    description: NotRequired[str]
