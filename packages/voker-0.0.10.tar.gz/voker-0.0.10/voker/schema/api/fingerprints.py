# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Fingerprint related payloads and responses."""

from typing import NotRequired, Required, TypedDict


class CreateFingerprintPayload(TypedDict):
    """Create a fingerprint.

    See [Fingerprints](https://app.voker.ai/docs/concepts/events#fingerprints) for more information.
    """

    language: Required[str]
    language_version: Required[str]
    system: Required[str]

    openai_sdk_version: NotRequired[str]
    anthropic_sdk_version: NotRequired[str]
    gemini_sdk_version: NotRequired[str]
    voker_sdk_version: NotRequired[str]
    all_packages: NotRequired[dict[str, str]]
    git_repository_url: NotRequired[str]
    git_branch: NotRequired[str]
    git_commit_hash: NotRequired[str]
    git_commit_date: NotRequired[str]
