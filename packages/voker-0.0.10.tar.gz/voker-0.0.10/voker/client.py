# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""TODO."""

from __future__ import annotations

import atexit
from typing import Any, Optional

from .api import ApiClient, EventQueue, EventWorker, Request
from .schema.api import EventProperties


class VokerClient:
    """Voker Client.

    See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient)
    """

    def __init__(
        self,
        *,
        base_url: str = "https://evals.voker.ai",
        api_key: Optional[str] = None,
    ) -> None:
        self._api_client = ApiClient(base_url=base_url, api_key=api_key)
        self._queue = EventQueue()
        self._event_worker = EventWorker(self._api_client, self._queue)
        self._closed = False

        atexit.register(self.close)

    @property
    def events(self) -> VokerClient_Events:
        """Access [events](https://app.voker.ai/docs/concepts/events#events) related endpoints."""
        return VokerClient_Events(self._queue)

    @property
    def people(self) -> VokerClient_People:
        """Access [people](https://app.voker.ai/docs/concepts/people) related endpoints."""
        return VokerClient_People(self._queue)

    @property
    def agents(self) -> VokerClient_Agents:
        """Access [agents](https://app.voker.ai/docs/concepts/agents#agents) related endpoints."""
        return VokerClient_Agents(self._queue)

    @property
    def agent_versions(self) -> VokerClient_AgentVersions:
        """Access [agent versions](https://app.voker.ai/docs/concepts/agents#agent-versions) related endpoints."""
        return VokerClient_AgentVersions(self._queue)

    def close(self) -> None:
        """Close the Voker client and stop the event worker."""
        if self._closed:
            return
        self._closed = True
        self._event_worker.close()


class _VokerClient_BaseSubPath:

    def __init__(self, queue: EventQueue) -> None:
        self._queue = queue


class VokerClient_Events(_VokerClient_BaseSubPath):
    """Access [events](https://app.voker.ai/docs/concepts/events#events) related endpoints.

    See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient_Events)
    """

    def create(
        self,
        *,
        event_name: str,
        properties: EventProperties,
        session: str,
        agent: Optional[str] = None,
        agent_version: Optional[str] = None,
        person: Optional[str] = None,
    ) -> None:
        """Create a new [event](https://app.voker.ai/docs/concepts/events).

        See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient_Events.create)

        Parameters
        ----------
        event_name: str
        properties: EventProperties
        agent: Optional[str]
            The name of the [agent](https://app.voker.ai/docs/concepts/agents#agents) associated with the event.
            If this agent does not exist, it will be created.
        agent_version: Optional[str]
            The name of the [agent version](https://app.voker.ai/docs/concepts/agents#agent-versions) associated with the event.
            If this agent version does not exist, it will be created. If an agent version is not supplied, a default version will be used.
        person: Optional[str]
            The unique identifier of the [person](https://app.voker.ai/docs/concepts/people) associated with the event.
            If the person does not exist, it will be created.
        session: str
            The unique identifier of the [session](https://app.voker.ai/docs/concepts/events#event-sessions) associated with the event.
        """
        self._queue.put(
            Request(
                "events",
                "create",
                event_name=event_name,
                properties=properties,
                agent=agent,
                agent_version=agent_version,
                person=person,
                session=session,
            )
        )


class VokerClient_People(_VokerClient_BaseSubPath):
    """Access [people](https://app.voker.ai/docs/concepts/people) related endpoints.

    See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient_People)
    """

    def create(
        self,
        *,
        person_id: str,
        properties: Optional[dict[str, Any]] = None,
    ) -> None:
        """Create a person.

        See [Creating a Person](https://app.voker.ai/docs/concepts/people#creating-a-person) for more information.

        Parameters
        ----------
        person_id: str
            Unique identifier for the person.
        properties: dict[str, Any]
        """
        self._queue.put(
            Request("people", "create", person_id=person_id, properties=properties)
        )

    def update(self, *, person_id: str, properties: dict[str, Any]) -> None:
        """Update a person."""
        self._queue.put(
            Request("people", "update", person_id=person_id, properties=properties)
        )


class VokerClient_Agents(_VokerClient_BaseSubPath):
    """Access [agents](https://app.voker.ai/docs/concepts/agents#agents) related endpoints.

    See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient_Agents)
    """

    def create(self, *, agent_name: str, description: Optional[str] = None) -> None:
        """Create an agent.

        See [Creating an Agent](https://app.voker.ai/docs/concepts/agents#creating-agent) for more information.

        Parameters
        ----------
        agent_name: str
            Unique identifier for the agent.
        description: Optional[str]
        """
        self._queue.put(
            Request("agents", "create", agent_name=agent_name, description=description)
        )


class VokerClient_AgentVersions(_VokerClient_BaseSubPath):
    """Access [agent versions](https://app.voker.ai/docs/concepts/agents#agent-versions) related endpoints.

    See [the reference documentation](https://app.voker.ai/docs/integrations/sdks/python#voker.client.VokerClient_AgentVersions)
    """

    def create(
        self,
        *,
        agent_name: str,
        agent_version_name: str,
        description: Optional[str] = None,
    ) -> None:
        """Create an agent version.

        See [Creating an Agent Version](https://app.voker.ai/docs/concepts/agents#creating-agent-version) for more information.

        Parameters
        ----------
        agent_name: str
            The name of the existing agent that this version belongs to.
        agent_version_name: str
            Unique identifier for the agent version within its agent.
        description: Optional[str]
        """
        self._queue.put(
            Request(
                "agent-versions",
                "create",
                agent_name=agent_name,
                agent_version_name=agent_version_name,
                description=description,
            )
        )
