# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Implement Voker tracking example for Gemini.

[See Here](https://app.voker.ai/docs/integrations/providers/gemini).
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any, Optional, overload

from voker.client import VokerClient

try:
    import google
    from google import genai
except ImportError:
    raise ModuleNotFoundError

from google.genai import _common as genai_common
from google.genai import _interactions as genai_interactions
from google.genai import models as genai_models
from google.genai import types as genai_types
from google.genai._interactions import resources as genai_interactions_resources
from google.genai._interactions import types as genai_interactions_types


def _serialize_inputs(
    data: dict[str, Any] | genai_common.BaseModel,
) -> dict[str, Any]:
    if isinstance(data, genai_common.BaseModel):
        return data.model_dump(mode="json")

    return data


class Client(genai.Client):
    """Gemini wrapper that automatically creates llm events in Voker."""

    @overload
    def __init__(
        self,
        voker_client: Optional[VokerClient] = None,
        base_genai_client: Optional[genai.Client] = None,
        *,
        vertexai: Optional[bool] = None,
        api_key: Optional[str] = None,
        credentials: Optional[google.auth.credentials.Credentials] = None,
        project: Optional[str] = None,
        location: Optional[str] = None,
        debug_config: Optional[genai.client.DebugConfig] = None,
        http_options: Optional[
            genai_types.HttpOptions | genai_types.HttpOptionsDict
        ] = None,
    ) -> None: ...

    def __init__(
        self,
        voker_client: Optional[VokerClient] = None,
        base_genai_client: Optional[genai.Client] = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)

        if voker_client is not None:
            self.__voker_client = voker_client
        else:
            self.__voker_client = VokerClient()

        if base_genai_client is None:
            base_genai_client = self

        self.__base_genai_client = base_genai_client

        if (base_models := getattr(base_genai_client, "_models", None)) is not None:
            self._models = Models(self.__voker_client, base_models)

        if (
            base_interactions := getattr(base_genai_client, "interactions", None)
        ) is not None:
            self._nextgen_client_instance

            self._nextgen_client.interactions = Interactions(
                self.__voker_client,
                base_interactions,
            )

    @property
    def aio(self) -> AsyncClient:
        """Pass through to the underlying AsyncClient instance."""
        return AsyncClient(
            self.__voker_client,
            self.__base_genai_client._aio,
        )


class Models:
    """Send calls to the models endpoints to Voker."""

    def __init__(
        self,
        voker_client: VokerClient,
        base_models: genai_models.Models,
    ) -> None:
        self.__voker_client = voker_client
        self.__base_models = base_models

    def __getattr__(self, name: str) -> Any:
        """Pass through to the underlying Models instance."""
        return getattr(self.__base_models, name)

    def generate_content(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> genai_types.GenerateContentResponse:
        """Send a content generation request to Voker as an llm event.

        See `google.genai.Client.models.generate_content`.
        """
        response = self.__base_models.generate_content(**kwargs)

        self.__voker_client.events.create(
            event_name="llm",
            properties={
                "api": "gemini-models",
                "inputs": kwargs,
                "output": response.model_dump(mode="json"),
            },
            agent=voker_agent,
            agent_version=voker_agent_version,
            person=voker_person,
            session=voker_session,
        )

        return response

    def generate_content_stream(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> Iterator[genai_types.GenerateContentResponse]:
        """Send a streaming content generation request to Voker as an llm event.

        See `google.genai.Client.models.generate_content_stream`.
        """
        aggregator = _GeminiModelsStreamAggregator()

        stream = self.__base_models.generate_content_stream(**kwargs)

        for chunk in stream:
            aggregator.add_chunk(chunk)
            yield chunk

        self.__voker_client.events.create(
            event_name="llm",
            properties={
                "api": "gemini-models",
                "inputs": _serialize_inputs(kwargs),
                "output": aggregator.get_result().model_dump(mode="json"),
            },
            agent=voker_agent,
            agent_version=voker_agent_version,
            person=voker_person,
            session=voker_session,
        )


class Interactions:
    """Send calls to the interactions endpoints to Voker."""

    def __init__(
        self,
        voker_client: VokerClient,
        base_interactions: genai_interactions_resources.InteractionsResource,
    ) -> None:
        self.__voker_client = voker_client
        self.__base_interactions = base_interactions

    def __getattr__(self, name: str) -> Any:
        """Pass through to the underlying Interactions instance."""
        return getattr(self.__base_interactions, name)

    def create(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> (
        genai_interactions_types.Interaction
        | genai_interactions.Stream[genai_interactions_types.InteractionSSEEvent]
    ):
        """Send a create interaction request to Voker as an llm event.

        See: `google.genai.Client.interactions.create`
        """
        from google.genai._interactions.types import Interaction

        stream = kwargs.get("stream", False)

        interaction = self.__base_interactions.create(**kwargs)

        if not stream:
            self.__voker_client.events.create(
                event_name="llm",
                properties={
                    "api": "gemini-interactions",
                    "inputs": kwargs,
                    "output": interaction.model_dump(mode="json"),
                },
                agent=voker_agent,
                agent_version=voker_agent_version,
                person=voker_person,
                session=voker_session,
            )

            return interaction

        return _InteractionStreamWrapper(
            interaction,
            self.__voker_client,
            kwargs,
            voker_agent,
            voker_agent_version,
            voker_person,
            voker_session,
        )


class _InteractionStreamWrapper:
    def __init__(
        self,
        stream,
        voker_client,
        kwargs,
        voker_agent,
        voker_agent_version,
        voker_person,
        voker_session,
    ):
        self._stream = stream
        self._voker_client = voker_client
        self._kwargs = kwargs
        self._voker_agent = voker_agent
        self._voker_agent_version = voker_agent_version
        self._voker_person = voker_person
        self._voker_session = voker_session
        self._final_interaction = None

    def __iter__(self):
        return self

    def __next__(self):
        event = next(self._stream)
        if getattr(event, "event_type", None) == "interaction.complete":
            self._final_interaction = event.interaction
        return event

    def __enter__(self):
        self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = self._stream.__exit__(*args)
        if self._final_interaction is not None:
            self._voker_client.events.create(
                event_name="llm",
                properties={
                    "api": "gemini-interactions",
                    "inputs": self._kwargs,
                    "output": self._final_interaction.model_dump(mode="json"),
                },
                agent=self._voker_agent,
                agent_version=self._voker_agent_version,
                person=self._voker_person,
                session=self._voker_session,
            )
        return result


class AsyncClient:
    """Async Gemini client wrapper that automatically creates llm events in Voker."""

    def __init__(
        self,
        voker_client: VokerClient,
        base_genai_async_client: genai.client.AsyncClient,
    ) -> None:
        self.__voker_client = voker_client
        self.__base_genai_async_client = base_genai_async_client

        if (
            base_models := getattr(self.__base_genai_async_client, "models", None)
        ) is not None:
            self.models = AsyncModels(voker_client, base_models)

        if (
            base_interactions := getattr(
                self.__base_genai_async_client, "interactions", None
            )
        ) is not None:
            self.interactions = AsyncInteractions(
                self.__voker_client,
                base_interactions,
            )

    def __getattr__(self, name: str) -> Any:
        """Pass through to the underlying AsyncClient object."""
        return getattr(self.__base_genai_async_client, name)


class AsyncModels:
    """Send async calls to the models endpoints to Voker as llm events."""

    def __init__(
        self,
        voker_client: VokerClient,
        base_models: genai_models.AsyncModels,
    ) -> None:
        self.__voker_client = voker_client
        self.__base_models = base_models

    def __getattr__(self, name: str) -> Any:
        """Pass through to the underlying AsyncModels object."""
        return getattr(self.__base_models, name)

    async def generate_content(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> genai_types.GenerateContentResponse:
        """Send an async content generation request to Voker as an llm event.

        See: `google.genai.client.AsyncClient.models.generate_content`
        """
        response = await self.__base_models.generate_content(**kwargs)

        self.__voker_client.events.create(
            event_name="llm",
            properties={
                "api": "gemini-models",
                "inputs": kwargs,
                "output": response.model_dump(mode="json"),
            },
            agent=voker_agent,
            agent_version=voker_agent_version,
            person=voker_person,
            session=voker_session,
        )

        return response

    async def generate_content_stream(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> AsyncIterator[genai_types.GenerateContentResponse]:
        """Send an async streaming content generation request to Voker as an llm event.

        See: `google.genai.client.AsyncClient.models.generate_content_stream`
        """
        aggregator = _GeminiModelsStreamAggregator()

        stream = await self.__base_models.generate_content_stream(**kwargs)

        async for chunk in stream:
            aggregator.add_chunk(chunk)
            yield chunk

        self.__voker_client.events.create(
            event_name="llm",
            properties={
                "api": "gemini-models",
                "inputs": _serialize_inputs(kwargs),
                "output": aggregator.get_result().model_dump(mode="json"),
            },
            agent=voker_agent,
            agent_version=voker_agent_version,
            person=voker_person,
            session=voker_session,
        )


class _GeminiModelsStreamAggregator:

    def __init__(self) -> None:
        self.current: genai_types.GenerateContentResponse | None = None

    def add_chunk(self, chunk: genai_types.GenerateContentResponse) -> None:
        if self.current is None:
            self.current = chunk
            return

        current_usage = self.current.usage_metadata

        if (usage := chunk.usage_metadata) is not None:
            if (ptc := usage.prompt_token_count) is not None:
                current = 0

                if (
                    current_usage is not None
                    and (c := current_usage.prompt_token_count) is not None
                ):
                    current += c

                assert self.current.usage_metadata is not None
                self.current.usage_metadata.prompt_token_count = current + ptc

            if (ctc := usage.candidates_token_count) is not None:
                current = 0

                if (
                    current_usage is not None
                    and (c := current_usage.candidates_token_count) is not None
                ):
                    current += c

                assert self.current.usage_metadata is not None
                self.current.usage_metadata.candidates_token_count = current + ctc

            if (ttc := usage.total_token_count) is not None:
                current = 0

                if (
                    current_usage is not None
                    and (c := current_usage.total_token_count) is not None
                ):
                    current += c

                assert self.current.usage_metadata is not None
                self.current.usage_metadata.total_token_count = current + ttc

        candidates = chunk.candidates

        if candidates is None:
            return

        for i, candidate in enumerate(candidates):
            if self.current.candidates is None:
                self.current.candidates = [candidate]
                continue

            if i >= len(self.current.candidates):
                self.current.candidates.append(candidate)
                continue

            current_candidate = self.current.candidates[i]

            if candidate.token_count is not None:
                if current_candidate.token_count is not None:
                    current_candidate.token_count += candidate.token_count
                else:
                    current_candidate.token_count = candidate.token_count

            current_candidate.finish_message = candidate.finish_message
            current_candidate.finish_reason = candidate.finish_reason

            current_content = current_candidate.content
            candidate_content = candidate.content

            if current_content is None:
                current_candidate.content = candidate_content
                continue

            if candidate_content is None:
                continue

            if (
                candidate_content is not None
                and (role := candidate_content.role) is not None
            ):
                current_content.role = role

            current_content_parts = current_content.parts

            if current_content_parts is None:
                current_content.parts = candidate_content.parts
                continue

            if candidate_content.parts is None:
                continue

            for j, part in enumerate(candidate_content.parts):
                if current_content.parts is None:
                    current_content.parts = [part]
                    continue

                if j >= len(current_content.parts):
                    current_content.parts.append(part)
                    continue

                current_part = current_content.parts[j]

                if part.text is not None and current_part.text is not None:
                    current_part.text += part.text

                if (
                    part.function_call is not None
                    and current_part.function_call is None
                ):
                    current_part.function_call = part.function_call

    def get_result(self) -> genai_types.GenerateContentResponse:
        assert self.current is not None
        return self.current


class AsyncInteractions:
    """Send async calls to the interactions endpoints to Voker."""

    def __init__(
        self,
        voker_client: VokerClient,
        base_interactions: genai_interactions_resources.AsyncInteractionsResource,
    ) -> None:
        self.__voker_client = voker_client
        self.__base_interactions = base_interactions

    def __getattr__(self, name: str) -> Any:
        """Pass through to the underlying Interactions instance."""
        return getattr(self.__base_interactions, name)

    async def create(
        self,
        voker_agent: str,
        voker_session: str,
        voker_agent_version: Optional[str] = None,
        voker_person: Optional[str] = None,
        **kwargs,
    ) -> (
        genai_interactions_types.Interaction
        | genai_interactions.AsyncStream[genai_interactions_types.InteractionSSEEvent]
    ):
        """Send a, async create interaction request to Voker as an llm event.

        See: `google.genai.client.AsyncClient.interactions.create`
        """
        from google.genai._interactions.types import Interaction

        stream = kwargs.get("stream", False)

        interaction = await self.__base_interactions.create(**kwargs)

        if not stream:
            self.__voker_client.events.create(
                event_name="llm",
                properties={
                    "api": "gemini-interactions",
                    "inputs": kwargs,
                    "output": interaction.model_dump(mode="json"),
                },
                agent=voker_agent,
                agent_version=voker_agent_version,
                person=voker_person,
                session=voker_session,
            )

            return interaction

        return _AsyncInteractionStreamWrapper(
            interaction,
            self.__voker_client,
            kwargs,
            voker_agent,
            voker_agent_version,
            voker_person,
            voker_session,
        )


class _AsyncInteractionStreamWrapper:
    def __init__(
        self,
        stream,
        voker_client,
        kwargs,
        voker_agent,
        voker_agent_version,
        voker_person,
        voker_session,
    ):
        self._stream = stream
        self._voker_client = voker_client
        self._kwargs = kwargs
        self._voker_agent = voker_agent
        self._voker_agent_version = voker_agent_version
        self._voker_person = voker_person
        self._voker_session = voker_session
        self._final_interaction = None

    def __aiter__(self):
        return self

    async def __anext__(self):
        event = await self._stream.__anext__()
        if getattr(event, "event_type", None) == "interaction.complete":
            self._final_interaction = event.interaction
        return event

    async def __aenter__(self):
        await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        result = await self._stream.__aexit__(*args)
        if self._final_interaction is not None:
            self._voker_client.events.create(
                event_name="llm",
                properties={
                    "api": "gemini-interactions",
                    "inputs": self._kwargs,
                    "output": self._final_interaction.model_dump(mode="json"),
                },
                agent=self._voker_agent,
                agent_version=self._voker_agent_version,
                person=self._voker_person,
                session=self._voker_session,
            )
        return result
