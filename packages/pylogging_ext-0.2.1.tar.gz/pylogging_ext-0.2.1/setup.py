from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name='pylogging-ext',
    version='0.2.1',
    author='chao',
    author_email='mr.qchao@gmail.com',
    description='一个支持 异步、批量、重试、多通道通知 的 logging 扩展库。',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/cnmax/pylogging-ext',
    project_urls={
        'Homepage': 'https://github.com/cnmax/pylogging-ext',
        'Bug Tracker': 'https://github.com/cnmax/pylogging-ext/issues',
        'Source Code': "https://github.com/cnmax/pylogging-ext",
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
        'Operating System :: OS Independent',
        'Topic :: System :: Logging',
        'Topic :: System :: Monitoring',
        'Topic :: Software Development :: Libraries',
    ],
    keywords=[
        'logging',
        'async logging',
        'handler',
        'cls',
        'tencent cloud',
        'wechat',
        'telegram',
        'dingtalk',
        'feishu',
        'notification',
        'monitoring',
    ],
    license='MIT',
    packages=find_packages(exclude=('tests', 'tests.*')),
    install_requires=[
        'requests',
    ],
    extras_require={
        'socks': ['requests[socks]'],
        'cls': ['tencentcloud-cls-sdk-python'],
    },
)
