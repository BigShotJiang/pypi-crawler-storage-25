import logging

from requests import Session

from pylogging_ext import BaseHandler


def _escape_html(text: str) -> str:
    if not text:
        return ''

    return (
        str(text).strip()
        .replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
    )


class TelegramHandler(BaseHandler):
    """Telegram机器人 Handler"""

    def __init__(
        self,
        token,
        chat_id,
        timeout=3,
        level=logging.NOTSET,
        queue_size=1000,
        retry=2,
        proxies=None,
        ssl_verify=True,
        endpoint='https://api.telegram.org',
    ):
        super().__init__(
            level=level,
            batch_size=1,
            queue_size=queue_size,
            retry=retry,
        )

        self.chat_id = chat_id
        self.api_url = f'{endpoint}/bot{token}/sendMessage'

        self.session = Session()

        if proxies:
            self.session.proxies.update(proxies)

        self.session.verify = ssl_verify
        self.timeout = timeout

    def make_html_message(self, log):
        """
        构建 Telegram HTML 消息

        - 标题：level + message
        - 正文：log / exc_info
        - 附加信息：thread / location
        """

        level = log.get('level', 'INFO')
        message = _escape_html(log.get('message'))

        # 标题
        content = (
            f'<b>{level}</b>'
            f'\n{message}'
        )

        # 优先展示异常
        if log.get('exc_info'):
            content += (
                f'<pre>'
                f'{_escape_html(log["exc_info"])}'
                f'</pre>'
            )
        else:
            content += (
                f'<pre>'
                f'{_escape_html(log["log"])}'
                f'</pre>'
            )

        # 附加信息
        content += (
            f'\n <i>Thread: {log["thread"]}</i>'
            f'\n <i>Location: {log["location"]}</i>'
        )

        return {
            'chat_id': self.chat_id,
            'text': content,
            'parse_mode': 'HTML',
            'disable_web_page_preview': True,
        }

    def send(self, logs):
        """发送到 Telegram"""
        resp = self.session.post(
            self.api_url,
            timeout=self.timeout,
            json=self.make_html_message(logs[0]),
        )

        # HTTP 错误
        resp.raise_for_status()

        result = resp.json()

        # Telegram 返回错误
        if not result.get('ok', False):
            raise Exception('Telegram API error [{error_code}]: {description}'.format_map(result))
