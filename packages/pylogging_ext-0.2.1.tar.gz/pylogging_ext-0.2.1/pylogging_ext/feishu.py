import base64
import hashlib
import hmac
import logging
import time

from requests import Session

from pylogging_ext import BaseHandler


def gen_sign(timestamp, secret):
    """生成签名"""
    hmac_code = hmac.new(
        key=f'{timestamp}\n{secret}'.encode('utf-8'),
        digestmod=hashlib.sha256,
    ).digest()

    return base64.b64encode(hmac_code).decode('utf-8')


class FeiShuHandler(BaseHandler):
    """飞书机器人 Handler"""

    def __init__(
        self,
        webhook,
        secret='',
        at_users=None,
        timeout=3,
        level=logging.NOTSET,
        queue_size=1000,
        retry=2,
    ):
        super().__init__(
            level=level,
            batch_size=1,
            queue_size=queue_size,
            retry=retry,
        )

        self.webhook = webhook
        self.secret = secret
        self.at_users = at_users or []

        self.session = Session()
        self.session.headers.update({'Content-Type': 'application/json'})

        self.timeout = timeout

    def make_post_message(self, log):
        """构建 飞书 POST 消息"""
        signs = {}

        if self.secret:
            ts = str(round(time.time()))
            signs.update({
                'timestamp': ts,
                'sign': gen_sign(ts, self.secret),
            })

        # 内容
        content = list()

        content.append([
            {
                'tag': 'text',
                'text': log.get('message'),
            },
        ])

        # At
        if self.at_users:
            content.append([
                {
                    'tag': 'at',
                    'user_id': user,
                } for user in self.at_users
            ])

        # 异常
        content.append([
            {
                'tag': 'text',
                'text': log.get('exc_info', log.get('log')),
            },
        ])

        # 附加信息
        content.append([
            {
                'tag': 'text',
                'text': f'Thread: {log.get("thread")}',
            },
        ])
        content.append([
            {
                'tag': 'text',
                'text': f'Location: {log.get("location")}',
            },
        ])

        return {
            'msg_type': 'post',
            'content': {
                'post': {
                    'zh_cn': {
                        'title': log.get('level'),
                        'content': content,
                    }
                },
            },
            **signs,
        }

    def send(self, logs):
        """发送到飞书"""
        resp = self.session.post(
            self.webhook,
            timeout=self.timeout,
            json=self.make_post_message(logs[0]),
        )

        # HTTP 错误
        resp.raise_for_status()

        result = resp.json()

        # 飞书返回错误
        if result.get('code') != 0:
            raise Exception('FeiShu API error [{code}]: {msg}'.format_map(result))
