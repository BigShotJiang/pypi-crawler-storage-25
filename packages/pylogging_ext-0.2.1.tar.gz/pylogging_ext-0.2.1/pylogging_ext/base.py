import logging
import queue
import threading
import time
import traceback
from datetime import datetime, timezone


class BaseHandler(logging.Handler):
    """
    通用异步通知 Handler 基类
    """

    def __init__(
        self,
        level=logging.NOTSET,
        batch_size=10,
        flush_interval=3.0,
        queue_size=1000,
        retry=1,
    ):
        super().__init__(level)

        # 内部日志
        self._internal_logger = logging.getLogger('pylogging_ext.internal')
        self._internal_logger.propagate = False

        if not self._internal_logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            )
            handler.setFormatter(formatter)
            self._internal_logger.addHandler(handler)

        # 批量参数
        self.batch_size = batch_size
        self.flush_interval = flush_interval

        # 重试次数
        self.retry = retry

        # 丢弃统计
        self._drop_count = 0

        # 队列
        self.queue = queue.Queue(maxsize=queue_size)

        # 停止信号
        self._stop_event = threading.Event()

        # worker 线程
        self.worker = threading.Thread(
            target=self._worker,
            name='BaseHandlerWorker',
            daemon=True,
        )
        self.worker.start()

    def emit(self, record):
        """logging入口"""
        try:
            payload = self.build_payload(record)
            self.queue.put_nowait(payload)

        except queue.Full:
            self._drop_count += 1

            if self._drop_count % 100 == 0:
                self._internal_logger.warning(
                    'log dropped count=%s', self._drop_count
                )

        except Exception:
            self.handleError(record)

    def _worker(self):
        """worker主循环"""
        buffer = []
        last_flush = time.monotonic()

        while not self._stop_event.is_set() or not self.queue.empty():
            try:
                log = self.queue.get(timeout=1)

                try:
                    if log is None:
                        # 收到退出信号
                        break

                    buffer.append(log)

                finally:
                    self.queue.task_done()

            except queue.Empty:
                pass

            now = time.monotonic()

            # flush条件：
            # 1. 达到 batch_size
            # 2. 超过 flush_interval
            if (
                len(buffer) >= self.batch_size
                or (buffer and now - last_flush >= self.flush_interval)
            ):
                self._flush(buffer[:])
                buffer.clear()
                last_flush = now

        # 兜底flush
        if buffer:
            self._flush(buffer)

    def _flush(self, logs):
        """
        带重试的发送逻辑（指数退避）
        """
        for i in range(self.retry + 1):
            attempt = i + 1

            try:
                self.send(logs)
                return

            except Exception as e:
                self._handle_send_error(e, attempt=attempt)

                if i < self.retry:
                    if self._stop_event.wait(2 ** i):
                        return

                else:
                    self._handle_final_failure(e)

    def _handle_send_error(self, error, attempt):
        self._internal_logger.warning(
            'send failed attempt=%s error=%s',
            attempt,
            error,
        )

    def _handle_final_failure(self, error):
        self._internal_logger.error(
            'FINAL send failure error=%s',
            error,
        )

    def build_payload(self, record):
        """构建日志结构"""
        payload = {
            'level': record.levelname,
            'location': f'{record.module}.{record.funcName}({record.pathname}:{record.lineno})',
            'log': self.format(record),
            'message': record.getMessage(),
            'thread': record.threadName,
            'time': datetime.fromtimestamp(
                record.created,
                tz=timezone.utc,
            ).strftime('%Y-%m-%dT%H:%M:%S%z'),
            'timestamp': record.created,
        }

        if record.exc_info:
            payload['exc_info'] = ''.join(
                traceback.format_exception(*record.exc_info)
            )

        return payload

    def send(self, logs):
        """
        子类必须实现
        :param logs: List[dict]
        """
        raise NotImplementedError

    def close(self):
        """优雅关闭"""
        # 停止接收新任务
        self._stop_event.set()

        # 发送退出信号
        while True:
            try:
                self.queue.put(None, timeout=1)
                break

            except queue.Full:
                time.sleep(0.1)

        # 等待队列消费完成
        self.queue.join()

        # 等待线程退出
        self.worker.join(timeout=5)

        super().close()
