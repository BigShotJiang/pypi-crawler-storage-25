import logging

from tencentcloud.log.cls_pb2 import LogGroupList, Log
from tencentcloud.log.logclient import LogClient
from tencentcloud.log.logexception import LogException

from pylogging_ext import BaseHandler


class TencentCloudCLSHandler(BaseHandler):
    """腾讯云 CLS Handler"""

    def __init__(
        self,
        endpoint,
        secret_id,
        secret_key,
        topic_id,
        security_token=None,
        source=None,
        region='',
        is_https=False,
        timeout=3,
        batch_size=10,
        flush_interval=3,
        level=logging.NOTSET,
        queue_size=1000,
        retry=2,
    ):
        super().__init__(
            level=level,
            batch_size=batch_size,
            flush_interval=flush_interval,
            queue_size=queue_size,
            retry=retry,
        )

        self.client = LogClient(
            endpoint,
            secret_id,
            secret_key,
            securityToken=security_token,
            source=source,
            region=region,
            is_https=is_https,
        )
        self.client.timeout = timeout

        self.topic_id = topic_id

    @classmethod
    def make_log(cls, log):
        pb_log = Log()
        pb_log.time = int(log.get('timestamp') * 1000000)

        for key in [
            'level',
            'location',
            'log',
            'message',
            'thread',
            'time',
        ]:
            content = pb_log.contents.add()
            content.key = key
            content.value = str(log.get(key, ''))

        if log.get('exc_info'):
            content = pb_log.contents.add()
            content.key = 'exc_info'
            content.value = str(log.get('exc_info'))

        return pb_log

    def send(self, logs):
        """批量发送到 CLS"""
        log_group_list = LogGroupList()
        log_group = log_group_list.logGroupList.add()

        # metadata
        log_group.filename = 'pylogging_ext.log'
        log_group.source = getattr(self.client, '_source', '')

        for log in logs:
            log_group.logs.append(self.make_log(log))

        try:
            self.client.put_log_raw(self.topic_id, log_group_list)

        except LogException as e:
            raise Exception(
                f'CLS API error [{e.get_error_code()}]: {e.get_error_message()}'
            )
