import base64
import hashlib
import hmac
import logging
import time
import urllib.parse

from requests import Session

from pylogging_ext import BaseHandler


class DingTalkHandler(BaseHandler):
    """钉钉机器人 Handler"""

    def __init__(
        self,
        access_token,
        secret='',
        at_mobiles=None,
        is_at_all=False,
        timeout=3,
        level=logging.NOTSET,
        queue_size=1000,
        retry=2,
    ):
        super().__init__(
            level=level,
            batch_size=1,
            queue_size=queue_size,
            retry=retry,
        )

        self.access_token = access_token
        self.secret = secret
        self.at_mobiles = at_mobiles or []
        self.is_at_all = is_at_all

        self.session = Session()
        self.session.headers.update({'Content-Type': 'application/json'})

        self.timeout = timeout

    def make_url(self):
        """构建请求URL"""
        sign = ''
        timestamp = str(round(time.time() * 1000))

        if self.secret:
            hmac_code = hmac.new(
                key=self.secret.encode('utf-8'),
                msg=f'{timestamp}\n{self.secret}'.encode('utf-8'),
                digestmod=hashlib.sha256,
            ).digest()
            sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))

        return (
            f'https://oapi.dingtalk.com/robot/send'
            f'?access_token={self.access_token}&timestamp={timestamp}&sign={sign}'
        )

    def make_markdown_message(self, log):
        """构建钉钉 Markdown 消息"""

        level = log.get('level', 'INFO')
        message = log.get('message')

        # 标题
        content = f'# {level}'
        content += f'\n{message}\n'

        # At
        content += '\n' + ''.join(
            [f'@{mobile}' for mobile in self.at_mobiles]
        )

        # 优先展示异常
        if log.get('exc_info'):
            content += (
                f'\n> {log["exc_info"]}'
            )
        else:
            content += (
                f'\n> {log["log"]}'
            )

        # 附加信息
        content += (
            f'\n###### Thread: {log["thread"]}'
            f'\n###### Location: {log["location"]}'
        )

        title = f'[{level}] {message}'
        title = title[:30] + '...' if len(title) > 30 else title

        return {
            'msgtype': 'markdown',
            'markdown': {
                'title': title,
                'text': content,
            },
            'at': {
                'isAtAll': self.is_at_all,
                'atMobiles': self.at_mobiles,
                'atUserIds': [],
            },
        }

    def send(self, logs):
        """发送到钉钉"""
        resp = self.session.post(
            self.make_url(),
            timeout=self.timeout,
            json=self.make_markdown_message(logs[0]),
        )

        # HTTP 错误
        resp.raise_for_status()

        result = resp.json()

        # 钉钉返回错误
        if result.get('errcode') != 0:
            raise Exception('DingTalk API error [{errcode}]: {errmsg}'.format_map(result))
