import logging

import requests

from pylogging_ext import BaseHandler


def _safe_text(text):
    if not text:
        return ''

    return (
        str(text).strip()
        .replace('\\', '\\\\')
    )


class WeChatHandler(BaseHandler):
    """企业微信机器人 Handler"""

    def __init__(
        self,
        webhook,
        timeout=3,
        level=logging.NOTSET,
        queue_size=1000,
        retry=2,
    ):
        super().__init__(
            level=level,
            batch_size=1,
            queue_size=queue_size,
            retry=retry,
        )

        self.webhook = webhook
        self.timeout = timeout

    @classmethod
    def make_markdown_message(cls, log):
        """
        构建企业微信 Markdown 消息

        - 标题：level + message
        - 正文：log / exc_info
        - 附加信息：thread / location
        """

        level = log.get('level', 'INFO')
        message = _safe_text(log.get('message'))

        # 标题
        content = (
            f'# {level}\n'
            f'{message}\n'
        )

        # 优先展示异常
        if log.get('exc_info'):
            content += (
                f'\n> '
                f'<font color=\"info\">'
                f'{_safe_text(log["exc_info"])}'
                f'</font>'
            )
        else:
            content += (
                f'\n> '
                f'<font color=\"info\">'
                f'{_safe_text(log["log"])}'
                f'</font>'
            )

        # 附加信息
        content += (
            f'\n> '
            f'\n> <font color=\"comment\">Thread: {log["thread"]}</font>'
            f'\n> <font color=\"warning\">Location: {_safe_text(log["location"])}</font>'
        )

        return {
            'msgtype': 'markdown',
            'markdown': {
                'content': content
            }
        }

    def send(self, logs):
        """发送到企业微信"""
        resp = requests.post(
            self.webhook,
            timeout=self.timeout,
            json=self.make_markdown_message(logs[0]),
        )

        # HTTP 错误
        resp.raise_for_status()

        result = resp.json()

        # 企业微信返回错误
        if result.get('errcode') != 0:
            raise Exception('WeChat API error [{errcode}]: {errmsg}'.format_map(result))
