import importlib
from typing import TYPE_CHECKING

from .base import BaseHandler
from .dingtalk import DingTalkHandler
from .feishu import FeiShuHandler
from .telegram import TelegramHandler
from .wechat import WeChatHandler

__all__ = [
    'BaseHandler',
    'WeChatHandler',
    'TelegramHandler',
    'TencentCloudCLSHandler',
    'DingTalkHandler',
    'FeiShuHandler',
]

_lazy_imports = {
    'TencentCloudCLSHandler': ('.cls', 'TencentCloudCLSHandler', 'cls'),
}

_cached_imports = {}

if TYPE_CHECKING:
    from .cls import TencentCloudCLSHandler


def __getattr__(name):
    if name not in _lazy_imports:
        raise AttributeError(f'module {__name__} has no attribute {name}')

    if name in _cached_imports:
        return _cached_imports[name]

    module_name, attr, extra = _lazy_imports[name]

    try:
        module = importlib.import_module(module_name, __name__)
        obj = getattr(module, attr)
        _cached_imports[name] = obj
        return obj

    except ImportError as e:
        raise RuntimeError(
            f"Optional dependency for '{name}' is not installed. "
            f"Install via: pip install pylogging_ext[{extra}]"
        ) from e
