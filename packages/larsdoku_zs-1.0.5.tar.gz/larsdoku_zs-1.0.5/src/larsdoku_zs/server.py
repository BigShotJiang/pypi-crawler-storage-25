#!/usr/bin/env python3
"""
Larsdoku FastAPI Server
========================
REST API wrapping the larsdoku engine — solve, cell query, SIRO, zone analysis,
like-puzzle generation, forge, generate, and exclude-solve endpoints.

Run:
    python -m larsdoku.server          # starts on port 8765
    larsdoku --serve                   # if CLI entry point exists
"""

from __future__ import annotations

import json
import pathlib
import random
import time
import traceback
from typing import Any, Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .engine import (
    BitBoard, solve_backtrack, has_unique_solution, validate_sudoku,
    propagate_l1l2, BIT, POPCOUNT, BOX_OF,
)
from .siro_boost import siro_predict, siro_predict_global
from .wsrf_zone import compute_likely_map, sir_get_rank1, _is_scout, _raw_rank1, siro_cascade
from .cli import (
    solve_selective, query_cell, parse_cell, normalize_puzzle,
    PRESETS, TECHNIQUE_LEVELS, parse_techniques, shuffle_sudoku, forge_variant,
)


# ══════════════════════════════════════════════════════════════
# STATIC FILES
# ══════════════════════════════════════════════════════════════

PKG_DIR = pathlib.Path(__file__).parent
STATIC_DIR = PKG_DIR / "static"


# ══════════════════════════════════════════════════════════════
# PYDANTIC MODELS
# ══════════════════════════════════════════════════════════════

class SolveRequest(BaseModel):
    puzzle: str
    preset: Optional[str] = None
    exclude: Optional[str] = None
    level: Optional[int] = None
    no_oracle: Optional[bool] = False
    gf2: Optional[bool] = False
    gf2x: Optional[bool] = False
    detail: Optional[bool] = True


class CellRequest(BaseModel):
    puzzle: str
    cell: str
    path: Optional[bool] = True
    preset: Optional[str] = None
    exclude: Optional[str] = None


class SiroRequest(BaseModel):
    puzzle: str
    threshold: Optional[int] = 3
    mcl: Optional[int] = 7


class ZoneRequest(BaseModel):
    puzzle: str
    threshold: Optional[int] = 3
    mcl: Optional[int] = 7


class LikeRequest(BaseModel):
    puzzle: str
    count: Optional[int] = 5


class ForgeRequest(BaseModel):
    puzzle: str


class GenerateRequest(BaseModel):
    clues: Optional[int] = 28
    unique: Optional[bool] = True


class ExcludeSolveRequest(BaseModel):
    puzzle: str
    exclude: str


# ══════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════

def _cell_name(pos: int) -> str:
    return f"R{pos // 9 + 1}C{pos % 9 + 1}"


def _build_only_techniques(preset: str | None, exclude: str | None) -> set | None:
    """Build the only_techniques set from preset + exclude strings."""
    only_techniques = None
    if preset and preset in PRESETS:
        only_techniques = PRESETS[preset]

    if exclude:
        exclude_set = parse_techniques(exclude)
        if exclude_set:
            if only_techniques is not None:
                only_techniques = only_techniques - exclude_set
            else:
                all_techs = set(TECHNIQUE_LEVELS.keys())
                only_techniques = all_techs - exclude_set

    return only_techniques


def _clean_steps(steps: list[dict]) -> list[dict]:
    """Serialize step dicts to JSON-safe form."""
    clean = []
    for s in steps:
        clean.append({
            "step": s["step"],
            "pos": s["pos"],
            "digit": s["digit"],
            "technique": s["technique"],
            "cell": s.get("cell", _cell_name(s["pos"])),
            "round": s.get("round", 0),
        })
    return clean


def _clean_elim_events(events: list[dict]) -> list[dict]:
    """Serialize elimination events to JSON-safe form."""
    clean = []
    for ev in events:
        clean.append({
            "round": ev.get("round"),
            "technique": ev.get("technique"),
            "detail": ev.get("detail", ""),
            "count": len(ev.get("eliminations", [])),
        })
    return clean


# ══════════════════════════════════════════════════════════════
# FASTAPI APP
# ══════════════════════════════════════════════════════════════

app = FastAPI(title="Larsdoku API", version="0.1.0")

# CORS for local dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files if the directory exists
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ══════════════════════════════════════════════════════════════
# ROOT — serve index.html
# ══════════════════════════════════════════════════════════════

@app.get("/")
async def root():
    index = STATIC_DIR / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return JSONResponse({"status": "ok", "message": "Larsdoku API is running"})


# ══════════════════════════════════════════════════════════════
# POST /api/solve
# ══════════════════════════════════════════════════════════════

@app.post("/api/solve")
async def api_solve(req: SolveRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        max_level = req.level if req.level is not None else 99
        only_techniques = _build_only_techniques(req.preset, req.exclude)

        t0 = time.perf_counter()
        result = solve_selective(
            bd81,
            max_level=max_level,
            only_techniques=only_techniques,
            gf2=req.gf2,
            gf2_extended=req.gf2x,
            detail=req.detail,
        )
        elapsed = (time.perf_counter() - t0) * 1000

        result["elapsed_ms"] = round(elapsed, 1)

        # Backtrack solution for display comparison (not used during solve)
        sol_str = solve_backtrack(bd81) if result["success"] else None
        result["solution"] = sol_str or ""

        result["steps"] = _clean_steps(result.get("steps", []))
        result["elim_events"] = _clean_elim_events(result.get("elim_events", []))

        return JSONResponse(content=json.loads(json.dumps(result, default=str)))

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/cell
# ══════════════════════════════════════════════════════════════

@app.post("/api/cell")
async def api_cell(req: CellRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        row, col = parse_cell(req.cell)
        only_techniques = _build_only_techniques(req.preset, req.exclude)

        t0 = time.perf_counter()
        qr = query_cell(
            bd81, row, col,
            only_techniques=only_techniques,
            autotrust=True,
        )
        elapsed = (time.perf_counter() - t0) * 1000
        qr["elapsed_ms"] = round(elapsed, 1)

        # Clean path steps
        if "path" in qr:
            qr["path"] = _clean_steps(qr["path"])
        # Clean elim_events
        if "elim_events" in qr:
            qr["elim_events"] = _clean_elim_events(qr["elim_events"])

        return JSONResponse(content=json.loads(json.dumps(qr, default=str)))

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/siro
# ══════════════════════════════════════════════════════════════

@app.post("/api/siro")
async def api_siro(req: SiroRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        bb = BitBoard.from_string(bd81)

        t0 = time.perf_counter()

        # SIRO predictions (cross-digit matrix constraint scoring)
        preds = siro_predict(bb)

        # Zone likely map
        lm = compute_likely_map(bb, threshold=req.threshold, mcl=req.mcl)

        # Rank-1 predictions for each empty cell
        rank1 = {}
        for pos in range(81):
            if bb.board[pos] == 0:
                r1 = sir_get_rank1(lm, bb, pos)
                if r1 > 0:
                    rank1[str(pos)] = r1

        # Oracle stats
        total_empty = sum(1 for i in range(81) if bb.board[i] == 0)
        rank1_count = len(rank1)

        elapsed = (time.perf_counter() - t0) * 1000

        # Build predictions dict (string keys for JSON)
        predictions_out = {}
        for pos, p in preds.items():
            predictions_out[str(pos)] = {
                "digit": p["digit"],
                "confidence": p["confidence"],
                "scores": [(d, s) for d, s in p["scores"]],
            }

        # Build zone_map dict
        zone_map = {}
        for pos, items in lm.items():
            zone_map[str(pos)] = [
                {
                    "d": info["d"],
                    "minRatio": round(info["minRatio"], 4),
                    "zone": info["zone"],
                    "baseScore": round(info["baseScore"], 4),
                    "harmonicDist": round(info["harmonicDist"], 6),
                    "rowRatio": round(info["rowRatio"], 4),
                    "colRatio": round(info["colRatio"], 4),
                    "boxRatio": round(info["boxRatio"], 4),
                    "score": round(info["score"], 4),
                }
                for info in items
            ]

        return JSONResponse(content={
            "predictions": predictions_out,
            "zone_map": zone_map,
            "rank1": rank1,
            "oracle_stats": {
                "total_empty": total_empty,
                "rank1_count": rank1_count,
            },
            "elapsed_ms": round(elapsed, 1),
        })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/siro-bootstrap — full SIRO cascade (zone oracle placement)
# ══════════════════════════════════════════════════════════════

@app.post("/api/siro-bootstrap")
async def api_siro_bootstrap(req: SiroRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        bb = BitBoard.from_string(bd81)

        # Get backtrack solution for oracle accuracy tracking
        solution_str = solve_backtrack(bd81)
        solution = [int(c) for c in solution_str] if solution_str else None

        t0 = time.perf_counter()
        steps = siro_cascade(bb, threshold=req.threshold, mcl=req.mcl, solution=solution)
        elapsed = (time.perf_counter() - t0) * 1000

        # Count results
        total_placed = len(steps)
        correct = sum(1 for s in steps if solution and solution[s["pos"]] == s["digit"])
        board_after = "".join(str(bb.board[i]) if bb.board[i] != 0 else "0" for i in range(81))
        empty_remaining = sum(1 for i in range(81) if bb.board[i] == 0)

        # Clean steps for JSON
        clean_steps = []
        for s in steps:
            pos = s["pos"]
            clean_steps.append({
                "type": s["type"],
                "subtype": s.get("subtype", ""),
                "round": s["round"],
                "cell": f"R{pos // 9 + 1}C{pos % 9 + 1}",
                "pos": pos,
                "digit": s["digit"],
                "detail": s.get("detail", ""),
                "correct": solution[pos] == s["digit"] if solution else None,
            })

        return JSONResponse(content={
            "steps": clean_steps,
            "total_placed": total_placed,
            "correct": correct,
            "accuracy": round(correct / max(1, total_placed) * 100, 1),
            "board_after": board_after,
            "empty_remaining": empty_remaining,
            "elapsed_ms": round(elapsed, 1),
        })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/zone
# ══════════════════════════════════════════════════════════════

@app.post("/api/zone")
async def api_zone(req: ZoneRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        bb = BitBoard.from_string(bd81)

        t0 = time.perf_counter()

        # Compute likely map
        lm = compute_likely_map(bb, threshold=req.threshold, mcl=req.mcl)

        # Rank-1 predictions: plain, with swap, with swap+boost
        rank1_plain = {}
        rank1_swap = {}
        rank1_boost = {}
        scout_info = {}

        for pos in range(81):
            if bb.board[pos] == 0:
                sp = str(pos)

                r1 = sir_get_rank1(lm, bb, pos)
                if r1 > 0:
                    rank1_plain[sp] = r1

                r1s = sir_get_rank1(lm, bb, pos, swap=True)
                if r1s > 0:
                    rank1_swap[sp] = r1s

                r1b = sir_get_rank1(lm, bb, pos, swap=True, boost=True)
                if r1b > 0:
                    rank1_boost[sp] = r1b

                # Scout status for the plain rank-1 digit
                if r1 > 0:
                    scout_peer = _is_scout(lm, bb, pos, r1)
                    scout_info[sp] = {
                        "is_scout": scout_peer >= 0,
                        "scout_peer": scout_peer if scout_peer >= 0 else None,
                        "scout_peer_cell": _cell_name(scout_peer) if scout_peer >= 0 else None,
                    }

        # Build likely_map data for each cell (with harmonic distances)
        likely_map = {}
        for pos, items in lm.items():
            cell_data = []
            for info in items:
                cell_data.append({
                    "d": info["d"],
                    "minRatio": round(info["minRatio"], 4),
                    "zone": info["zone"],
                    "baseScore": round(info["baseScore"], 4),
                    "harmonicDist": round(info["harmonicDist"], 6),
                    "rowRatio": round(info["rowRatio"], 4),
                    "colRatio": round(info["colRatio"], 4),
                    "boxRatio": round(info["boxRatio"], 4),
                    "score": round(info["score"], 4),
                })
            likely_map[str(pos)] = cell_data

        # Oracle rate stats
        total_empty = sum(1 for i in range(81) if bb.board[i] == 0)
        rank1_count = len(rank1_plain)
        scout_count = sum(1 for v in scout_info.values() if v["is_scout"])

        elapsed = (time.perf_counter() - t0) * 1000

        return JSONResponse(content={
            "likely_map": likely_map,
            "rank1": {
                "plain": rank1_plain,
                "swap": rank1_swap,
                "boost": rank1_boost,
            },
            "scout_info": scout_info,
            "oracle_stats": {
                "total_empty": total_empty,
                "rank1_count": rank1_count,
                "scout_count": scout_count,
                "non_scout_count": rank1_count - scout_count,
            },
            "elapsed_ms": round(elapsed, 1),
        })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/like
# ══════════════════════════════════════════════════════════════

@app.post("/api/like")
async def api_like(req: LikeRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        like_count = max(1, min(req.count or 5, 50))

        t0 = time.perf_counter()

        # Solve the reference puzzle to get its technique profile
        ref_result = solve_selective(bd81, verbose=False, gf2_silent=True)
        ref_techs = ref_result.get("technique_counts", {})
        ref_success = ref_result.get("success", False)
        ref_n = sum(1 for c in bd81 if c != "0")

        # Target techniques: all non-L1 techniques used by the reference
        l1_techs = {"crossHatch", "nakedSingle", "fullHouse", "lastRemaining"}
        target_profile = {t for t in ref_techs if t not in l1_techs and ref_techs[t] > 0}

        like_rng = random.Random()
        found = 0
        matches = []
        max_attempts = like_count * 50
        attempt = 0

        for attempt in range(max_attempts):
            if found >= like_count:
                break

            # Shuffle the reference puzzle (preserves structure)
            shuffled = shuffle_sudoku(bd81, rng=like_rng.random)
            if not has_unique_solution(shuffled):
                continue

            # Solve and check technique similarity
            r = solve_selective(shuffled, verbose=False, gf2_silent=True)
            s_techs = r.get("technique_counts", {})
            s_success = r.get("success", False)
            s_profile = {t for t in s_techs if t not in l1_techs and s_techs[t] > 0}

            # Accept if technique profile overlaps with reference
            overlap = target_profile & s_profile
            if target_profile and not overlap:
                continue

            found += 1
            s_n = sum(1 for c in shuffled if c != "0")
            matches.append({
                "puzzle": shuffled,
                "clues": s_n,
                "solved": s_success,
                "techniques": s_techs,
                "overlap": sorted(overlap) if overlap else [],
            })

        elapsed = (time.perf_counter() - t0) * 1000

        return JSONResponse(content={
            "reference": {
                "puzzle": bd81,
                "clues": ref_n,
                "solved": ref_success,
                "techniques": ref_techs,
                "profile": sorted(target_profile),
            },
            "matches": matches,
            "found": found,
            "attempts": attempt + 1,
            "elapsed_ms": round(elapsed, 1),
        })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/forge
# ══════════════════════════════════════════════════════════════

@app.post("/api/forge")
async def api_forge(req: ForgeRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)

        t0 = time.perf_counter()
        forged = forge_variant(bd81)
        elapsed = (time.perf_counter() - t0) * 1000

        if forged:
            n_clues = sum(1 for ch in forged if ch != "0")
            return JSONResponse(content={
                "forged": forged,
                "clues": n_clues,
                "elapsed_ms": round(elapsed, 1),
            })
        else:
            return JSONResponse(content={
                "error": "Could not forge variant after max retries",
                "elapsed_ms": round(elapsed, 1),
            })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/generate
# ══════════════════════════════════════════════════════════════

@app.post("/api/generate")
async def api_generate(req: GenerateRequest):
    try:
        want_unique = req.unique if req.unique is not None else True
        n_clues = req.clues if req.clues is not None else (28 if want_unique else 24)

        if want_unique:
            n_clues = max(17, min(27, n_clues))
        else:
            n_clues = max(8, min(16, n_clues))

        t0 = time.perf_counter()

        # Generate a random solved board
        sol = solve_backtrack("0" * 81)
        if not sol:
            raise ValueError("Failed to generate base board")
        sol = shuffle_sudoku(sol)

        # Remove digits to create puzzle
        positions = list(range(81))
        random.shuffle(positions)
        puzzle_chars = list(sol)
        removed = 0
        target_empty = 81 - n_clues

        for pos in positions:
            if removed >= target_empty:
                break
            saved = puzzle_chars[pos]
            puzzle_chars[pos] = "0"
            test = "".join(puzzle_chars)
            if want_unique:
                if has_unique_solution(test):
                    removed += 1
                else:
                    puzzle_chars[pos] = saved
            else:
                removed += 1

        puzzle = "".join(puzzle_chars)
        actual_clues = sum(1 for ch in puzzle if ch != "0")
        is_unique = has_unique_solution(puzzle)

        # Test solvability oracle-free
        result = solve_selective(puzzle, detail=False, verbose=False)
        elapsed = (time.perf_counter() - t0) * 1000

        return JSONResponse(content={
            "puzzle": puzzle,
            "clues": actual_clues,
            "unique": is_unique,
            "solvable": result["success"],
            "stalled_at": result["empty_remaining"] if not result["success"] else 0,
            "techniques": result["technique_counts"],
            "elapsed_ms": round(elapsed, 1),
        })

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/exclude-solve
# ══════════════════════════════════════════════════════════════

@app.post("/api/exclude-solve")
async def api_exclude_solve(req: ExcludeSolveRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        exclude_set = parse_techniques(req.exclude)

        # Build only_techniques by removing excluded from all
        only_techniques = None
        if exclude_set:
            all_techs = set(TECHNIQUE_LEVELS.keys())
            only_techniques = all_techs - exclude_set

        t0 = time.perf_counter()
        result = solve_selective(
            bd81,
            only_techniques=only_techniques,
            detail=True,
        )
        elapsed = (time.perf_counter() - t0) * 1000

        result["elapsed_ms"] = round(elapsed, 1)

        sol_str = solve_backtrack(bd81) if result["success"] else None
        result["solution"] = sol_str or ""

        result["steps"] = _clean_steps(result.get("steps", []))
        result["elim_events"] = _clean_elim_events(result.get("elim_events", []))
        result["excluded"] = sorted(exclude_set) if exclude_set else []

        return JSONResponse(content=json.loads(json.dumps(result, default=str)))

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "trace": traceback.format_exc()},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/hint — get next step hint
# ══════════════════════════════════════════════════════════════

class HintRequest(BaseModel):
    puzzle: str
    preset: Optional[str] = None

@app.post("/api/hint")
async def api_hint(req: HintRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        only_techniques = _build_only_techniques(req.preset, None)

        result = solve_selective(bd81, only_techniques=only_techniques, detail=True)

        steps = result.get("steps", [])
        if steps:
            s = steps[0]
            pos = s["pos"]
            return JSONResponse(content={
                "cell": f"R{pos // 9 + 1}C{pos % 9 + 1}",
                "digit": s["digit"],
                "technique": s["technique"],
                "message": f"R{pos // 9 + 1}C{pos % 9 + 1} = {s['digit']} via {s['technique']}",
            })
        else:
            return JSONResponse(content={"message": "No hint available — puzzle may be stalled"})

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e)},
        )


# ══════════════════════════════════════════════════════════════
# POST /api/best-move — get the best next placement
# ══════════════════════════════════════════════════════════════

@app.post("/api/best-move")
async def api_best_move(req: HintRequest):
    try:
        bd81 = normalize_puzzle(req.puzzle)
        only_techniques = _build_only_techniques(req.preset, None)

        result = solve_selective(bd81, only_techniques=only_techniques, detail=True)

        steps = result.get("steps", [])
        if steps:
            s = steps[0]
            pos = s["pos"]
            return JSONResponse(content={
                "cell": f"R{pos // 9 + 1}C{pos % 9 + 1}",
                "digit": s["digit"],
                "technique": s["technique"],
                "message": f"Best move: R{pos // 9 + 1}C{pos % 9 + 1} = {s['digit']} ({s['technique']})",
            })
        else:
            return JSONResponse(content={"message": "No moves available — puzzle may be stalled"})

    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"error": str(e)},
        )


# ══════════════════════════════════════════════════════════════
# MAIN — uvicorn runner
# ══════════════════════════════════════════════════════════════

def main():
    import uvicorn
    uvicorn.run(
        "larsdoku_zs.server:app",
        host="0.0.0.0",
        port=8765,
        reload=False,
    )


if __name__ == "__main__":
    main()
