"""gf2_larsxor — XOR-Friendly Matrix Rearrangement for GF(2) Acceleration.

Three strategies combined for hyper-accelerated GF(2) Sudoku solving:

1. BOX-BLOCK VARIABLE ORDERING
   Variables grouped by box → near-block-diagonal constraint matrix.
   Sudoku naturally decomposes into 9 weakly-coupled boxes: box constraints
   (cell + box-digit) are fully local, only row/col constraints cross boxes.

2. PURE PYTHON BIG-INT ELIMINATION
   Python's arbitrary-precision integers represent each GF(2) row as a single
   multi-limb integer. XOR of two rows = one CPU operation, no numpy overhead.
   Avoids the O(n_rows × n_words) packing cost of the numpy approach.

3. TWO-PHASE SCHUR COMPLEMENT
   Phase 1: Eliminate box-local constraints independently (9 small problems,
            ~20 vars each, pure Python). Determines ~60% of pivots.
   Phase 2: Substitute Phase 1 pivots into cross-box constraints (row/col-digit),
            eliminate the residual system. Back-substitute for full solution.

Together these exploit Sudoku's structure to accelerate GF(2) linear algebra.

Author: Sir Lars (WSRF) — March 2026
"""
from __future__ import annotations

import numpy as np

from .engine import BitBoard, BIT, UNITS, BOX_OF, _gf2_extract_results


# ══════════════════════════════════════════════════════════════════════
# VARIABLE REORDERING — box-block layout
# ══════════════════════════════════════════════════════════════════════

def _box_block_reorder(bb):
    """Compute box-block variable ordering.

    Variables are grouped contiguously by box: all candidates in box 0,
    then box 1, ..., box 8. Within each box, candidates are ordered by
    cell position then digit. This makes box constraints block-diagonal.

    Returns:
        var_map:    list of (pos, digit_1indexed)
        var_idx:    dict {(pos, digit) → variable index}
        box_bounds: list of (start, end) for each box's variable range
    """
    var_map = []
    var_idx = {}
    box_bounds = []

    for bi in range(9):
        start = len(var_map)
        for pos in UNITS[18 + bi]:          # cells in box bi
            if bb.board[pos] != 0:
                continue
            mask = bb.cands[pos]
            while mask:
                lsb = mask & -mask
                d = lsb.bit_length() - 1    # 0-indexed
                var_idx[(pos, d + 1)] = len(var_map)
                var_map.append((pos, d + 1))
                mask ^= lsb
        box_bounds.append((start, len(var_map)))

    return var_map, var_idx, box_bounds


# ══════════════════════════════════════════════════════════════════════
# CONSTRAINT BUILDING — partitioned by locality
# ══════════════════════════════════════════════════════════════════════

def build_xor_system(bb, add_conjugates=False, add_band_stack=False):
    """Build GF(2) constraint system with box-block variable ordering.

    Constraints are partitioned into:
      box_constraints[bi]: rows that only reference variables in box bi
                           (cell constraints + box-digit constraints)
      cross_constraints:   rows that span multiple boxes
                           (row-digit + col-digit constraints)

    Returns:
        (box_constraints, cross_constraints, var_map, var_idx,
         box_bounds, n_vars, rhs_bit)
    """
    var_map, var_idx, box_bounds = _box_block_reorder(bb)
    n_vars = len(var_map)
    if n_vars == 0:
        return [[] for _ in range(9)], [], var_map, var_idx, box_bounds, 0, 0

    rhs_bit = 1 << n_vars

    # ── Phase 1: Box-local constraints ──
    box_constraints = [[] for _ in range(9)]

    # Cell constraints: each empty cell gets exactly one digit
    for pos in range(81):
        if bb.board[pos] != 0:
            continue
        bi = BOX_OF[pos]
        row = 0
        mask = bb.cands[pos]
        while mask:
            lsb = mask & -mask
            d = lsb.bit_length() - 1
            row |= 1 << var_idx[(pos, d + 1)]
            mask ^= lsb
        if row:
            box_constraints[bi].append(row | rhs_bit)

    # Box-digit constraints: each digit appears exactly once per box
    for bi in range(9):
        for d in range(9):
            if bb.box_used[bi] & BIT[d]:
                continue
            row = 0
            for pos in UNITS[18 + bi]:
                key = (pos, d + 1)
                if key in var_idx:
                    row |= 1 << var_idx[key]
            if row:
                box_constraints[bi].append(row | rhs_bit)

    # ── Phase 2: Cross-box constraints ──
    cross_constraints = []

    # Row-digit constraints: each digit appears once per row (spans 3 boxes)
    for r in range(9):
        for d in range(9):
            if bb.row_used[r] & BIT[d]:
                continue
            row = 0
            for c in range(9):
                key = (r * 9 + c, d + 1)
                if key in var_idx:
                    row |= 1 << var_idx[key]
            if row:
                cross_constraints.append(row | rhs_bit)

    # Col-digit constraints: each digit appears once per column (spans 3 boxes)
    for c in range(9):
        for d in range(9):
            if bb.col_used[c] & BIT[d]:
                continue
            row = 0
            for r in range(9):
                key = (r * 9 + c, d + 1)
                if key in var_idx:
                    row |= 1 << var_idx[key]
            if row:
                cross_constraints.append(row | rhs_bit)

    # ═══ Option A: Band/stack locked minirow constraints (box-local) ═══
    if add_band_stack:
        for bi in range(9):
            br, bc = (bi // 3) * 3, (bi % 3) * 3
            for d in range(9):
                d1 = d + 1
                if bb.box_used[bi] & BIT[d]:
                    continue
                cand_cells = []
                for dr in range(3):
                    for dc in range(3):
                        pos = (br + dr) * 9 + bc + dc
                        if (pos, d1) in var_idx:
                            cand_cells.append((pos, dr, dc))
                if not cand_cells:
                    continue
                rows_seen = {dr for _, dr, _ in cand_cells}
                if len(rows_seen) == 1:
                    row = 0
                    for pos, _, _ in cand_cells:
                        row |= 1 << var_idx[(pos, d1)]
                    if row:
                        box_constraints[bi].append(row | rhs_bit)
                cols_seen = {dc for _, _, dc in cand_cells}
                if len(cols_seen) == 1:
                    row = 0
                    for pos, _, _ in cand_cells:
                        row |= 1 << var_idx[(pos, d1)]
                    if row:
                        box_constraints[bi].append(row | rhs_bit)

    # ═══ Option C: Conjugate pair constraints (cross-box) ═══
    if add_conjugates:
        for unit_idx in range(27):
            for d in range(9):
                d1 = d + 1
                pair = []
                for pos in UNITS[unit_idx]:
                    if (pos, d1) in var_idx:
                        pair.append(var_idx[(pos, d1)])
                if len(pair) == 2:
                    row = (1 << pair[0]) | (1 << pair[1])
                    cross_constraints.append(row | rhs_bit)

    return (box_constraints, cross_constraints, var_map, var_idx,
            box_bounds, n_vars, rhs_bit)


# ══════════════════════════════════════════════════════════════════════
# PURE BIG-INT ELIMINATION — no numpy overhead
# ══════════════════════════════════════════════════════════════════════

def _gf2_eliminate_bigint(rows, n_vars):
    """GF(2) Gaussian elimination using Python arbitrary-precision ints.

    Each row is a multi-limb integer. XOR = one CPU operation per row.
    No numpy packing overhead. Faster than numpy for n_vars < ~300.

    Returns: (pivots, free_vars)
        pivots:    dict {col → row_index}
        free_vars: set of free variable indices
    """
    n_rows = len(rows)
    used = [False] * n_rows
    pivots = {}

    for col in range(n_vars):
        bit = 1 << col
        # Find pivot
        pivot = -1
        for r in range(n_rows):
            if not used[r] and rows[r] & bit:
                pivot = r
                break
        if pivot < 0:
            continue

        pivots[col] = pivot
        used[pivot] = True
        prow = rows[pivot]

        # Eliminate: XOR pivot row into all others with this bit set
        for r in range(n_rows):
            if r != pivot and rows[r] & bit:
                rows[r] ^= prow

    free_vars = set(range(n_vars)) - set(pivots.keys())
    return pivots, free_vars


# ══════════════════════════════════════════════════════════════════════
# TWO-PHASE SCHUR COMPLEMENT — the core innovation
# ══════════════════════════════════════════════════════════════════════

def two_phase_eliminate(box_constraints, cross_constraints, n_vars, box_bounds,
                        return_intermediates=False):
    """Two-phase GF(2) elimination exploiting block-diagonal structure.

    Phase 1: Eliminate box-local constraints independently per box.
             9 problems of ~20 variables each (pure Python big-ints).
             Determines ~60% of pivots with minimal cross-talk.

    Phase 2: Substitute Phase 1 pivots into cross-box constraints,
             projecting them onto the box-local null space.
             Eliminate the residual system for remaining pivots.

    Back-substitute: Phase 2 pivots back into Phase 1 rows for
                     full reduced row echelon form.

    Args:
        return_intermediates: if True, also return Phase 1 pivots and
            cross_clean snapshot for cached probing (box-aware probe cache).

    Returns: (pivots, free_vars, M, n_words, contradiction)
        If return_intermediates: + (phase1_pivots_cache, cross_clean_cache)
        Format matches engine._gf2_block_eliminate for extract compatibility.
    """
    phase1_pivots = {}       # col → big-int (fully reduced pivot row)
    contradiction = False
    rhs_bit = 1 << n_vars
    var_mask = (1 << n_vars) - 1

    # ═══ PHASE 1: Per-box elimination ═══
    for bi in range(9):
        start, end = box_bounds[bi]
        if start == end:
            continue

        block = list(box_constraints[bi])
        if not block:
            continue

        # Forward + backward elimination within the box
        box_pivot_map = {}     # col → row_index in block
        used = [False] * len(block)
        for col in range(start, end):
            bit = 1 << col
            pivot = -1
            for r in range(len(block)):
                if not used[r] and block[r] & bit:
                    pivot = r
                    break
            if pivot < 0:
                continue

            box_pivot_map[col] = pivot
            used[pivot] = True
            prow = block[pivot]
            # Eliminate ALL other rows (forward + backward)
            for r in range(len(block)):
                if r != pivot and block[r] & bit:
                    block[r] ^= prow

        # Store the FULLY REDUCED rows (after all box pivots are done)
        for col, r in box_pivot_map.items():
            phase1_pivots[col] = block[r]

        # Contradiction check: non-pivot rows that are RHS-only (0=1)
        for r in range(len(block)):
            if not used[r]:
                row = block[r]
                if (row & var_mask) == 0 and (row & rhs_bit):
                    contradiction = True

    # ═══ SUBSTITUTE Phase 1 pivots into cross-box constraints ═══
    # This projects cross-box constraints onto the Phase 1 null space.
    cross_work = list(cross_constraints)      # don't mutate input
    for i in range(len(cross_work)):
        row = cross_work[i]
        for col, prow in phase1_pivots.items():
            if row & (1 << col):
                row ^= prow
        cross_work[i] = row

    # Remove zero rows and detect contradictions
    rhs_bit = 1 << n_vars
    var_mask = (1 << n_vars) - 1
    cross_clean = []
    for row in cross_work:
        if (row & var_mask) == 0:
            if row & rhs_bit:
                contradiction = True
            continue                          # zero or contradiction row
        cross_clean.append(row)

    # ═══ Cache intermediates for probing (before Phase 2 mutates cross_clean) ═══
    if return_intermediates:
        _p1_cache = dict(phase1_pivots)
        _cc_cache = list(cross_clean)

    # ═══ PHASE 2: Cross-box elimination ═══
    phase2_pivots = {}
    phase2_pivot_map = {}    # col → row_index in cross_clean
    pivoted_cols = set(phase1_pivots.keys())

    used2 = [False] * len(cross_clean)
    for col in range(n_vars):
        if col in pivoted_cols:
            continue
        bit = 1 << col
        pivot = -1
        for r in range(len(cross_clean)):
            if not used2[r] and cross_clean[r] & bit:
                pivot = r
                break
        if pivot < 0:
            continue

        phase2_pivot_map[col] = pivot
        used2[pivot] = True
        prow = cross_clean[pivot]
        for r in range(len(cross_clean)):
            if r != pivot and cross_clean[r] & bit:
                cross_clean[r] ^= prow

    # Store FULLY REDUCED Phase 2 rows (after all Phase 2 pivots done)
    for col, r in phase2_pivot_map.items():
        phase2_pivots[col] = cross_clean[r]

    # Phase 2 contradiction check
    for r in range(len(cross_clean)):
        if not used2[r]:
            row = cross_clean[r]
            if (row & var_mask) == 0 and (row & rhs_bit):
                contradiction = True

    # ═══ BACK-SUBSTITUTE Phase 2 into Phase 1 ═══
    # Phase 1 pivot rows may reference columns now pivoted by Phase 2.
    # XOR the Phase 2 pivot rows in to fully reduce them.
    for col2, prow2 in phase2_pivots.items():
        bit2 = 1 << col2
        for col1 in phase1_pivots:
            if phase1_pivots[col1] & bit2:
                phase1_pivots[col1] ^= prow2

    # ═══ COMBINE into final numpy matrix ═══
    combined = []
    all_pivots = {}

    for col in sorted(phase1_pivots):
        all_pivots[col] = len(combined)
        combined.append(phase1_pivots[col])

    for col in sorted(phase2_pivots):
        all_pivots[col] = len(combined)
        combined.append(phase2_pivots[col])

    free_vars = set(range(n_vars)) - set(all_pivots.keys())

    # Pack into numpy uint64 for _gf2_extract_results
    n_cols = n_vars + 1
    n_words = (n_cols + 63) >> 6
    n_rows = max(len(combined), 1)
    M = np.zeros((n_rows, n_words), dtype=np.uint64)
    _MASK64 = (1 << 64) - 1
    for i, row_int in enumerate(combined):
        for w in range(n_words):
            M[i, w] = np.uint64((row_int >> (w << 6)) & _MASK64)

    if return_intermediates:
        return all_pivots, free_vars, M, n_words, contradiction, _p1_cache, _cc_cache
    return all_pivots, free_vars, M, n_words, contradiction


# ══════════════════════════════════════════════════════════════════════
# BOX-AWARE PROBING — cached Phase 1 for fast probe loop
# ══════════════════════════════════════════════════════════════════════

def _phase2_with_probe(phase1_pivots, cross_clean_snapshot, probe_row, n_vars):
    """Run Phase 2 elimination with an additional probe constraint.

    Uses cached Phase 1 pivots to skip box-local elimination (~60% of work).
    Only re-runs Phase 2 on the cross-box residual + probe row.

    Args:
        phase1_pivots: dict {col → big-int row} from Phase 1 (immutable cache)
        cross_clean_snapshot: cross constraints after Phase 1 sub (immutable cache)
        probe_row: the probe constraint (big-int, e.g. 1<<fv or 1<<fv|rhs_bit)
        n_vars: total variable count

    Returns: (all_pivots, free_vars, M, n_words, contradiction)
    """
    rhs_bit = 1 << n_vars
    var_mask = (1 << n_vars) - 1

    # Substitute Phase 1 pivots into probe row
    for col, prow in phase1_pivots.items():
        if probe_row & (1 << col):
            probe_row ^= prow

    # Build Phase 2 work list
    probe_vars = probe_row & var_mask
    if probe_vars == 0:
        # Probe is trivial after Phase 1 substitution
        contradiction = bool(probe_row & rhs_bit)
        work = list(cross_clean_snapshot)
    else:
        contradiction = False
        work = list(cross_clean_snapshot) + [probe_row]

    # Phase 2 elimination
    pivoted_cols = set(phase1_pivots.keys())
    phase2_pivots = {}
    phase2_pivot_map = {}

    used = [False] * len(work)
    for col in range(n_vars):
        if col in pivoted_cols:
            continue
        bit = 1 << col
        pivot_r = -1
        for r in range(len(work)):
            if not used[r] and work[r] & bit:
                pivot_r = r
                break
        if pivot_r < 0:
            continue
        phase2_pivot_map[col] = pivot_r
        used[pivot_r] = True
        prow = work[pivot_r]
        for r in range(len(work)):
            if r != pivot_r and work[r] & bit:
                work[r] ^= prow

    for col, r in phase2_pivot_map.items():
        phase2_pivots[col] = work[r]

    # Contradiction check on non-pivot rows
    for r in range(len(work)):
        if not used[r]:
            row = work[r]
            if (row & var_mask) == 0 and (row & rhs_bit):
                contradiction = True

    # Back-substitute Phase 2 into Phase 1 (copy to avoid mutating cache)
    p1_work = dict(phase1_pivots)
    for col2, prow2 in phase2_pivots.items():
        bit2 = 1 << col2
        for col1 in p1_work:
            if p1_work[col1] & bit2:
                p1_work[col1] ^= prow2

    # Combine into final result
    combined = []
    all_pivots = {}
    for col in sorted(p1_work):
        all_pivots[col] = len(combined)
        combined.append(p1_work[col])
    for col in sorted(phase2_pivots):
        all_pivots[col] = len(combined)
        combined.append(phase2_pivots[col])

    free_vars = set(range(n_vars)) - set(all_pivots.keys())

    # Pack into numpy for _gf2_extract_results
    n_cols = n_vars + 1
    n_words = (n_cols + 63) >> 6
    n_rows = max(len(combined), 1)
    M = np.zeros((n_rows, n_words), dtype=np.uint64)
    _MASK64 = (1 << 64) - 1
    for i, row_int in enumerate(combined):
        for w in range(n_words):
            M[i, w] = np.uint64((row_int >> (w << 6)) & _MASK64)

    return all_pivots, free_vars, M, n_words, contradiction


# ══════════════════════════════════════════════════════════════════════
# FREE-VARIABLE HINTS — residual info for L4+ detectors
# ══════════════════════════════════════════════════════════════════════

def _compute_free_cells(free_vars, var_map):
    """Map free variables to cell/digit positions.

    Returns:
        free_cells: dict {pos: bitmask of free digits at that cell}
        skip_digits: 9-bit mask of digits fully determined by GF(2)
                     (no free variables anywhere for those digits)
    """
    free_cells = {}
    free_digit_bits = 0
    for fv in free_vars:
        pos, digit = var_map[fv]
        dbit = 1 << (digit - 1)
        free_cells[pos] = free_cells.get(pos, 0) | dbit
        free_digit_bits |= dbit
    return free_cells, 0x1FF & ~free_digit_bits


# ══════════════════════════════════════════════════════════════════════
# DETECTORS — drop-in replacements
# ══════════════════════════════════════════════════════════════════════

def detect_gf2_larsxor(bb, return_residual=False):
    """GF(2) XOR-Friendly — drop-in for detect_gf2_lanczos.

    Uses box-block reordering + two-phase Schur complement elimination
    for accelerated GF(2) linear algebra.

    Args:
        return_residual: if True, also return free_cells dict and skip_digits mask.

    Returns: (placements, eliminations, dof)
        If return_residual: (placements, eliminations, dof, free_cells, skip_digits)
    """
    (box_con, cross_con, var_map, var_idx,
     box_bounds, n_vars, rhs_bit) = build_xor_system(bb)

    if n_vars == 0:
        if return_residual:
            return [], [], 0, {}, 0x1FF
        return [], [], 0

    pivots, free_vars, M, n_words, _ = two_phase_eliminate(
        box_con, cross_con, n_vars, box_bounds)

    placements, eliminations, _ = _gf2_extract_results(
        pivots, free_vars, M, n_vars, n_words, var_map, 'GF2_XOR')

    if return_residual:
        free_cells, skip_digits = _compute_free_cells(free_vars, var_map)
        return placements, eliminations, len(free_vars), free_cells, skip_digits
    return placements, eliminations, len(free_vars)


def detect_gf2_larsxor_flat(bb):
    """GF(2) with box-block reordering but flat single-pass elimination.

    Diagnostic: isolates whether bugs are in reordering vs two-phase split.
    Uses _gf2_eliminate_bigint on the full combined constraint set.
    """
    (box_con, cross_con, var_map, var_idx,
     box_bounds, n_vars, rhs_bit) = build_xor_system(bb)

    if n_vars == 0:
        return [], [], 0

    # Flatten all constraints into one list
    all_rows = []
    for bi_rows in box_con:
        all_rows.extend(bi_rows)
    all_rows.extend(cross_con)

    pivots, free_vars = _gf2_eliminate_bigint(all_rows, n_vars)

    # Pack into numpy for _gf2_extract_results
    n_cols = n_vars + 1
    n_words = (n_cols + 63) >> 6
    n_rows_total = max(len(all_rows), 1)
    M = np.zeros((n_rows_total, n_words), dtype=np.uint64)
    _MASK64 = (1 << 64) - 1
    for i, row_int in enumerate(all_rows):
        for w in range(n_words):
            M[i, w] = np.uint64((row_int >> (w << 6)) & _MASK64)

    placements, eliminations, _ = _gf2_extract_results(
        pivots, free_vars, M, n_vars, n_words, var_map, 'GF2_XOR_Flat')

    return placements, eliminations, len(free_vars)


def detect_gf2_larsxor_extended(bb, zone_hints=None, probe_free=False,
                             conjugates=True, band_stack=True):
    """GF(2) XOR-Extended — full-power with box-block acceleration.

    Same options as detect_gf2_extended but with XOR-friendly layout.

    Returns: (placements, eliminations, dof, contradiction, probe_stats)
    """
    (box_con, cross_con, var_map, var_idx,
     box_bounds, n_vars, rhs_bit) = build_xor_system(
        bb, add_conjugates=conjugates, add_band_stack=band_stack)

    if n_vars == 0:
        return [], [], 0, False, {}

    # Zone hints: single-variable constraints (add to cross-box phase)
    cross_work = list(cross_con)
    if zone_hints:
        for (pos, digit), value in zone_hints.items():
            if (pos, digit) in var_idx:
                idx = var_idx[(pos, digit)]
                row = 1 << idx
                if value:
                    row |= rhs_bit
                cross_work.append(row)

    _need_cache = probe_free
    if _need_cache:
        pivots, free_vars, M, n_words, contradiction, _p1_cache, _cc_cache = \
            two_phase_eliminate(box_con, cross_work, n_vars, box_bounds,
                               return_intermediates=True)
    else:
        pivots, free_vars, M, n_words, contradiction = two_phase_eliminate(
            box_con, cross_work, n_vars, box_bounds)

    tech = 'GF2_XOR_Ext'

    if contradiction:
        return [], [], len(free_vars), True, {}

    placements, eliminations, _ = _gf2_extract_results(
        pivots, free_vars, M, n_vars, n_words, var_map, tech)

    # ═══ Option E: Free-variable probing (box-aware cached Phase 1) ═══
    probe_stats = {'probes': 0, 'forced_by_contradiction': 0,
                   'forced_by_agreement': 0}

    if probe_free and free_vars and len(free_vars) <= 20:
        probed_placements = []
        probed_eliminations = []
        already_forced = set()

        for fv in sorted(free_vars):
            if fv in already_forced:
                continue
            probe_stats['probes'] += 1

            # Try fv = 0 (using cached Phase 1 — skips ~60% of work)
            p0, fv0, M0, nw0, contra_0 = _phase2_with_probe(
                _p1_cache, _cc_cache, 1 << fv, n_vars)
            r0_p, r0_e, _ = _gf2_extract_results(
                p0, fv0, M0, n_vars, nw0, var_map, tech)

            # Try fv = 1 (using cached Phase 1)
            p1, fv1, M1, nw1, contra_1 = _phase2_with_probe(
                _p1_cache, _cc_cache, (1 << fv) | (1 << n_vars), n_vars)
            r1_p, r1_e, _ = _gf2_extract_results(
                p1, fv1, M1, n_vars, nw1, var_map, tech)

            fv_pos, fv_digit = var_map[fv]

            if contra_0 and not contra_1:
                probed_placements.append((fv_pos, fv_digit, 'GF2_XOR_Probe'))
                probed_placements.extend(
                    (p, d, 'GF2_XOR_Probe') for p, d, _ in r1_p)
                probed_eliminations.extend(r1_e)
                already_forced.add(fv)
                probe_stats['forced_by_contradiction'] += 1
            elif contra_1 and not contra_0:
                probed_eliminations.append((fv_pos, fv_digit))
                probed_placements.extend(
                    (p, d, 'GF2_XOR_Probe') for p, d, _ in r0_p)
                probed_eliminations.extend(r0_e)
                already_forced.add(fv)
                probe_stats['forced_by_contradiction'] += 1
            elif not contra_0 and not contra_1:
                map_0 = {(p, d): 1 for p, d, _ in r0_p}
                map_0.update({(p, d): 0 for p, d in r0_e})
                map_1 = {(p, d): 1 for p, d, _ in r1_p}
                map_1.update({(p, d): 0 for p, d in r1_e})
                for key in map_0:
                    if key in map_1 and map_0[key] == map_1[key]:
                        pos, digit = key
                        if map_0[key] == 1:
                            probed_placements.append(
                                (pos, digit, 'GF2_XOR_Probe'))
                        else:
                            probed_eliminations.append((pos, digit))
                        probe_stats['forced_by_agreement'] += 1

        # Merge probed results
        placed_set = {(p, d) for p, d, _ in placements}
        elim_set = set(eliminations)
        for p, d, t in probed_placements:
            if (p, d) not in placed_set:
                placements.append((p, d, t))
                placed_set.add((p, d))
        for p, d in probed_eliminations:
            if (p, d) not in elim_set:
                eliminations.append((p, d))
                elim_set.add((p, d))

    return placements, eliminations, len(free_vars), contradiction, probe_stats


# ══════════════════════════════════════════════════════════════════════
# BOARD FORGE — fast null space computation
# ══════════════════════════════════════════════════════════════════════

def gf2_null_space_fast(puzzle_str):
    """Fast GF(2) null space dimension using box-block + big-int elimination.

    Drop-in replacement for board_forge.gf2_null_space_dimension.
    Uses bit-packed Python integers instead of numpy uint8 element-wise ops.

    Returns: (n_vars, rank, null_dim)
    """
    bb = BitBoard.from_string(puzzle_str)

    (box_con, cross_con, var_map, var_idx,
     box_bounds, n_vars, _) = build_xor_system(bb)

    if n_vars == 0:
        return 0, 0, 0

    # Strip RHS bits — we only need rank
    var_mask = (1 << n_vars) - 1
    all_rows = []
    for bi_rows in box_con:
        for row in bi_rows:
            all_rows.append(row & var_mask)
    for row in cross_con:
        all_rows.append(row & var_mask)

    # Two-phase rank computation
    pivots = set()

    # Phase 1: per-box
    for bi in range(9):
        start, end = box_bounds[bi]
        if start == end:
            continue

        # Separate box-local rows from the rest
        box_mask = 0
        for col in range(start, end):
            box_mask |= 1 << col

        box_rows = []
        remaining = []
        for row in all_rows:
            if row and (row & ~box_mask) == 0:
                box_rows.append(row)
            else:
                remaining.append(row)
        all_rows = remaining

        # Eliminate within box
        used = [False] * len(box_rows)
        for col in range(start, end):
            bit = 1 << col
            pivot = -1
            for r in range(len(box_rows)):
                if not used[r] and box_rows[r] & bit:
                    pivot = r
                    break
            if pivot < 0:
                continue
            pivots.add(col)
            used[pivot] = True
            prow = box_rows[pivot]
            for r in range(len(box_rows)):
                if r != pivot and box_rows[r] & bit:
                    box_rows[r] ^= prow
            # Substitute into remaining rows
            for i in range(len(all_rows)):
                if all_rows[i] & bit:
                    all_rows[i] ^= prow

    # Phase 2: remaining
    all_rows = [r for r in all_rows if r]
    used2 = [False] * len(all_rows)
    for col in range(n_vars):
        if col in pivots:
            continue
        bit = 1 << col
        pivot = -1
        for r in range(len(all_rows)):
            if not used2[r] and all_rows[r] & bit:
                pivot = r
                break
        if pivot < 0:
            continue
        pivots.add(col)
        used2[pivot] = True
        prow = all_rows[pivot]
        for r in range(len(all_rows)):
            if r != pivot and all_rows[r] & bit:
                all_rows[r] ^= prow

    rank = len(pivots)
    return n_vars, rank, n_vars - rank


# ══════════════════════════════════════════════════════════════════════
# BENCHMARK — compare all strategies
# ══════════════════════════════════════════════════════════════════════

def benchmark_xor(puzzle_str, n_runs=100):
    """Compare original vs XOR-friendly GF(2) elimination.

    Returns dict with timing, correctness verification, and structure stats.
    """
    import time
    from .engine import detect_gf2_lanczos

    bb = BitBoard.from_string(puzzle_str)

    # ── Original (big-int build → numpy eliminate) ──
    t0 = time.perf_counter()
    for _ in range(n_runs):
        p_old, e_old, dof_old = detect_gf2_lanczos(bb)
    t_old = (time.perf_counter() - t0) / n_runs

    # ── XOR two-phase (box-block build → big-int 2-phase) ──
    t0 = time.perf_counter()
    for _ in range(n_runs):
        p_new, e_new, dof_new = detect_gf2_larsxor(bb)
    t_new = (time.perf_counter() - t0) / n_runs

    # ── Structure stats ──
    (box_con, cross_con, var_map, var_idx,
     box_bounds, n_vars, _) = build_xor_system(bb)
    box_sizes = [end - start for start, end in box_bounds]
    n_box_constraints = sum(len(bc) for bc in box_con)
    n_cross_constraints = len(cross_con)

    # ── Verify correctness ──
    old_place = {(p, d) for p, d, _ in p_old}
    new_place = {(p, d) for p, d, _ in p_new}
    old_elim = set(e_old)
    new_elim = set(e_new)

    return {
        'original_us': round(t_old * 1e6, 1),
        'xor_us': round(t_new * 1e6, 1),
        'speedup': round(t_old / t_new, 2) if t_new > 0 else float('inf'),
        'dof_match': dof_old == dof_new,
        'placements_match': old_place == new_place,
        'eliminations_match': old_elim == new_elim,
        'n_vars': n_vars,
        'dof': dof_new,
        'n_placements': len(p_new),
        'n_eliminations': len(e_new),
        'box_sizes': box_sizes,
        'n_box_constraints': n_box_constraints,
        'n_cross_constraints': n_cross_constraints,
    }


def benchmark_null_space(puzzle_str, n_runs=50):
    """Compare board_forge null space vs fast null space."""
    import time
    from .board_forge import gf2_null_space_dimension

    t0 = time.perf_counter()
    for _ in range(n_runs):
        v_old, r_old, d_old = gf2_null_space_dimension(puzzle_str)
    t_old = (time.perf_counter() - t0) / n_runs

    t0 = time.perf_counter()
    for _ in range(n_runs):
        v_new, r_new, d_new = gf2_null_space_fast(puzzle_str)
    t_new = (time.perf_counter() - t0) / n_runs

    return {
        'original_us': round(t_old * 1e6, 1),
        'fast_us': round(t_new * 1e6, 1),
        'speedup': round(t_old / t_new, 2) if t_new > 0 else float('inf'),
        'vars_match': v_old == v_new,
        'rank_match': r_old == r_new,
        'null_dim_match': d_old == d_new,
        'n_vars': v_new,
        'rank': r_new,
        'null_dim': d_new,
    }
