"""Backward compatibility -- import from larsdoku_zs directly.

All functions have moved to their proper modules:
  solver.py  — solve_selective, query_cell, solve_siro_bootstrap, solve_siro_guided
  utils.py   — parse_cell, normalize_puzzle, parse_techniques, shuffle_sudoku, etc.
  display.py — format_board, format_summary, format_detail, format_benchmark
  constants.py — TECHNIQUE_LEVELS, PRESETS, TECHNIQUE_ALIASES, etc.
"""
import warnings as _w
_w.warn(
    "Importing from larsdoku_zs.cli is deprecated. "
    "Import from larsdoku_zs directly, or from .solver/.utils/.display/.constants.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything for backward compatibility
from .solver import (  # noqa: F401
    solve_selective, query_cell,
    solve_siro_bootstrap, solve_siro_guided,
    detect_zone135, compute_zone_sums_from_solution,
)
from .utils import (  # noqa: F401
    parse_cell, normalize_puzzle, parse_techniques,
    validate_sudoku, validate_eliminations, validate_placement,
    validate_mask_rules, display_mask, generate_random_mask,
    shuffle_sudoku, crosswise_shuffle, forge_variant,
)
from .display import (  # noqa: F401
    format_board, format_summary, format_detail, format_benchmark,
)
from .constants import (  # noqa: F401
    TECHNIQUE_LEVELS, TECHNIQUE_ALIASES,
    WSRF_INVENTIONS, EXPERT_APPROVED, PRESETS,
    PREFER_EXCLUSIONS, EXOTIC_TECHNIQUES,
)
