"""Larsdoku — Parsing, validation, shuffling, and puzzle utilities."""
from __future__ import annotations

import random
import warnings

from .engine import BIT, BOX_OF, PEERS, POPCOUNT
from .constants import TECHNIQUE_LEVELS, TECHNIQUE_ALIASES


# ══════════════════════════════════════════════════════════════
# PARSE HELPERS
# ══════════════════════════════════════════════════════════════

def parse_cell(cell_str):
    """Parse cell reference like R3C5, r3c5, 2,4 (0-indexed), or 3,5 (1-indexed with R/C)."""
    cell_str = cell_str.strip().upper()
    # R3C5 format
    if cell_str.startswith('R') and 'C' in cell_str:
        parts = cell_str[1:].split('C')
        r = int(parts[0]) - 1
        c = int(parts[1]) - 1
        if 0 <= r <= 8 and 0 <= c <= 8:
            return r, c
        raise ValueError(f'Cell out of range: {cell_str}')
    # row,col format (0-indexed)
    if ',' in cell_str:
        parts = cell_str.split(',')
        r, c = int(parts[0]), int(parts[1])
        if 0 <= r <= 8 and 0 <= c <= 8:
            return r, c
        raise ValueError(f'Cell out of range: {cell_str}')
    raise ValueError(f'Cannot parse cell: {cell_str}. Use R3C5 or 2,4 format.')


def decode_bdp(s):
    """Decode SudokuWiki packed bd string (S9B format).

    Format: 3-char header (e.g. 'S9B') + 81 x 2-char base-36 pairs.
    Values: 01-09 = given clue, 10-18 = solved (digit = val-9),
            19-529 = candidates (bitmask = val-18, not a placed digit).

    Returns (bd81, cand_masks) where:
      - bd81: 81-char string (givens/solved only, candidates -> 0)
      - cand_masks: list of 81 ints (bitmask for candidate cells, 0 for placed)
    """
    body = s[3:]
    if len(body) < 162:
        raise ValueError(f'BDP string too short: need 162+ body chars, got {len(body)}')

    bd81 = []
    cand_masks = []
    for i in range(81):
        pair = body[i * 2:i * 2 + 2]
        val = int(pair, 36)
        if 1 <= val <= 9:
            bd81.append(str(val))       # given
            cand_masks.append(0)
        elif 10 <= val <= 18:
            bd81.append(str(val - 9))   # solved
            cand_masks.append(0)
        elif 19 <= val <= 529:
            bd81.append('0')            # candidates = unsolved
            cand_masks.append(val - 18) # preserve candidate bitmask
        else:
            bd81.append('0')
            cand_masks.append(0)
    return ''.join(bd81), cand_masks


def normalize_puzzle(puzzle_str):
    """Normalize a puzzle string to 81 digits (0 for empty).
    Also accepts SudokuWiki BDP strings (S9B/X9B/J9B format)."""
    puzzle_str = puzzle_str.strip()

    # Detect BDP format: starts with S9, X9, or J9 and is 165+ chars
    if len(puzzle_str) >= 165 and puzzle_str[:2] in ('S9', 'X9', 'J9'):
        bd81, _ = decode_bdp(puzzle_str)
        return bd81

    puzzle_str = puzzle_str.replace('.', '0').replace(' ', '').replace('\n', '')
    # Handle potential multi-line grid format
    puzzle_str = ''.join(ch for ch in puzzle_str if ch.isdigit())
    if len(puzzle_str) != 81:
        raise ValueError(f'Puzzle must be 81 digits, got {len(puzzle_str)}')
    return puzzle_str


def parse_techniques(tech_str):
    """Parse technique filter string like 'fpc,gf2,l1' into a set."""
    techs = set()
    for t in tech_str.lower().split(','):
        t = t.strip()
        if not t:
            continue
        if t in TECHNIQUE_ALIASES:
            alias = TECHNIQUE_ALIASES[t]
            if alias == 'L1':
                techs.update(['crossHatch', 'nakedSingle', 'fullHouse', 'lastRemaining'])
            elif alias == 'L2':
                techs.update(['crossHatch', 'nakedSingle', 'fullHouse', 'lastRemaining',
                             'GF2_Lanczos'])
            else:
                techs.add(alias)
                # Always include L1 as foundation
                techs.update(['crossHatch', 'nakedSingle', 'fullHouse', 'lastRemaining'])
        else:
            # Try direct match
            matched = False
            for known_tech in TECHNIQUE_LEVELS:
                if known_tech.lower() == t:
                    techs.add(known_tech)
                    matched = True
                    break
            if not matched:
                warnings.warn(f'Unknown technique "{t}", ignoring', stacklevel=2)
    return techs if techs else None


# ══════════════════════════════════════════════════════════════
# VALIDATION
# ══════════════════════════════════════════════════════════════

def validate_sudoku(board):
    """Verify completed board by Sudoku law — no oracle needed.
    Checks all 27 units (9 rows, 9 cols, 9 boxes) have exactly {1..9}."""
    FULL = {1, 2, 3, 4, 5, 6, 7, 8, 9}
    for i in range(9):
        row = set()
        col = set()
        box = set()
        br, bc = (i // 3) * 3, (i % 3) * 3
        for j in range(9):
            row.add(board[i * 9 + j])
            col.add(board[j * 9 + i])
            box.add(board[(br + j // 3) * 9 + bc + j % 3])
        if row != FULL or col != FULL or box != FULL:
            return False
    return True


def validate_eliminations(bb, elims):
    """Structural validation: reject eliminations that would leave a cell
    with 0 candidates. Pure Sudoku logic — no oracle needed."""
    # Group eliminations by cell
    cell_elims = {}
    for pos, d in elims:
        cell_elims.setdefault(pos, set()).add(d)
    # Check each cell retains at least 1 candidate
    safe = []
    for pos, d in elims:
        # Count what would remain after ALL eliminations for this cell
        full_mask = bb.cands[pos]
        for dd in cell_elims[pos]:
            full_mask &= ~BIT[dd - 1]
        if full_mask != 0:  # cell keeps at least one candidate
            safe.append((pos, d))
    return safe


def validate_placement(bb, pos, digit):
    """Structural validation: verify a placement doesn't violate Sudoku law.
    Returns True if the placement is safe (no duplicate in any unit)."""
    if bb.board[pos] != 0:
        return False  # cell already filled
    if not (bb.cands[pos] & BIT[digit - 1]):
        return False  # digit not a candidate
    # Check row, col, box for existing placement of this digit
    for peer in PEERS[pos]:
        if bb.board[peer] == digit:
            return False
    return True


# ══════════════════════════════════════════════════════════════
# MASK VALIDATION
# ══════════════════════════════════════════════════════════════

def _mask_analysis(bd81):
    """Analyze clue mask: coverage per box, row, col."""
    clue_positions = [i for i, ch in enumerate(bd81) if ch != '0' and ch != '.']
    n_clues = len(clue_positions)
    box_clues = [0] * 9
    row_clues = [0] * 9
    col_clues = [0] * 9
    for pos in clue_positions:
        r, c = pos // 9, pos % 9
        box_clues[BOX_OF[pos]] += 1
        row_clues[r] += 1
        col_clues[c] += 1
    return {
        'n_clues': n_clues, 'clue_positions': clue_positions,
        'box_clues': box_clues, 'row_clues': row_clues, 'col_clues': col_clues,
        'empty_boxes': sum(1 for b in box_clues if b == 0),
        'empty_rows': sum(1 for r in row_clues if r == 0),
        'empty_cols': sum(1 for c in col_clues if c == 0),
    }


def _compute_mask_score(analysis):
    """Quality score 0.0-1.0: box coverage (40%), row/col coverage (30%),
    evenness (20%), density (10%)."""
    n = analysis['n_clues']
    boxes_with = sum(1 for b in analysis['box_clues'] if b > 0)
    rows_with = sum(1 for r in analysis['row_clues'] if r > 0)
    cols_with = sum(1 for c in analysis['col_clues'] if c > 0)
    mean_bc = n / 9
    stddev = (sum((b - mean_bc) ** 2 for b in analysis['box_clues']) / 9) ** 0.5
    max_stddev = max(n * (8 / 9) ** 0.5, 0.001)
    evenness = max(0.0, 1 - stddev / max_stddev)
    score = (boxes_with / 9) * 0.4 + ((rows_with + cols_with) / 18) * 0.3 + evenness * 0.2 + min(n / 17, 1.0) * 0.1
    return round(score, 3), stddev


def validate_mask_rules(positions):
    """Validate mask against board-building rules. Returns validation dict."""
    bd81 = ''.join('x' if i in positions else '0' for i in range(81))
    a = _mask_analysis(bd81)
    rules = []
    warnings_list = []
    has_hard_fail = False

    # Rule 1: Min Clues (>= 8)
    if a['n_clues'] >= 8:
        rules.append({'name': 'Minimum Clues', 'status': 'PASS', 'detail': f'{a["n_clues"]} >= 8'})
    else:
        rules.append({'name': 'Minimum Clues', 'status': 'FAIL', 'detail': f'{a["n_clues"]} < 8'})
        has_hard_fail = True

    # Rule 2: Box Coverage (9/9)
    bw = 9 - a['empty_boxes']
    if a['empty_boxes'] == 0:
        rules.append({'name': 'Box Coverage', 'status': 'PASS', 'detail': '9/9 boxes'})
    elif a['empty_boxes'] <= 2:
        rules.append({'name': 'Box Coverage', 'status': 'WARN', 'detail': f'{bw}/9 boxes'})
    else:
        rules.append({'name': 'Box Coverage', 'status': 'FAIL', 'detail': f'{bw}/9 boxes'})
        has_hard_fail = True

    # Rule 3: Row Coverage
    rw = 9 - a['empty_rows']
    rules.append({'name': 'Row Coverage', 'status': 'PASS' if a['empty_rows'] == 0 else 'WARN',
                  'detail': f'{rw}/9 rows'})

    # Rule 4: Col Coverage
    cw = 9 - a['empty_cols']
    rules.append({'name': 'Col Coverage', 'status': 'PASS' if a['empty_cols'] == 0 else 'WARN',
                  'detail': f'{cw}/9 cols'})

    # Rule 5: Spread Evenness
    score, stddev = _compute_mask_score(a)
    ev = 'excellent' if stddev < 0.5 else ('good' if stddev < 1.5 else 'uneven')
    rules.append({'name': 'Spread Evenness', 'status': 'INFO', 'detail': f'stddev={stddev:.2f} ({ev})'})

    verdict = 'EXCELLENT' if score >= 0.80 else ('GOOD' if score >= 0.60 else ('FAIR' if score >= 0.40 else 'POOR'))
    return {'rules': rules, 'score': score, 'verdict': verdict, 'warnings': warnings_list,
            'has_hard_fail': has_hard_fail, 'stddev': stddev}


def display_mask(positions, label=''):
    """Display mask as visual 9x9 grid."""
    pos_set = set(positions)
    if label:
        print(f'  {label}')
    print('  +---------+---------+---------+')
    for r in range(9):
        row = '  |'
        for c in range(9):
            row += ' X ' if r * 9 + c in pos_set else ' . '
            if c % 3 == 2:
                row += '|'
        print(row)
        if r % 3 == 2:
            print('  +---------+---------+---------+')


def generate_random_mask(n_clues=17, min_score=0.80, max_attempts=1000, rng=None):
    """Generate a random clue mask that passes all validation rules."""
    if rng is None:
        rng = random.Random()
    box_cells = []
    for b in range(9):
        br, bc = (b // 3) * 3, (b % 3) * 3
        box_cells.append([r * 9 + c for r in range(br, br + 3) for c in range(bc, bc + 3)])

    for _ in range(max_attempts):
        positions = set()
        for b in range(9):
            positions.add(rng.choice(box_cells[b]))
        for r in range(9):
            row_pos = [r * 9 + c for c in range(9)]
            if not any(p in positions for p in row_pos):
                positions.add(rng.choice(row_pos))
        for c in range(9):
            col_pos = [r * 9 + c for r in range(9)]
            if not any(p in positions for p in col_pos):
                positions.add(rng.choice(col_pos))
        while len(positions) < n_clues:
            box_counts = [0] * 9
            for p in positions:
                box_counts[(p // 9 // 3) * 3 + (p % 9 // 3)] += 1
            min_bc = min(box_counts)
            underfilled = [b for b, cnt in enumerate(box_counts) if cnt == min_bc]
            tb = rng.choice(underfilled)
            cands = [p for p in box_cells[tb] if p not in positions]
            if cands:
                positions.add(rng.choice(cands))
            else:
                remaining = [p for p in range(81) if p not in positions]
                if remaining:
                    positions.add(rng.choice(remaining))
                else:
                    break
        validation = validate_mask_rules(positions)
        if validation['score'] >= min_score and not validation['has_hard_fail']:
            if all(r['status'] in ('PASS', 'INFO') for r in validation['rules']):
                return sorted(positions), validation['score'], validation['stddev']
    return None


# ══════════════════════════════════════════════════════════════
# SHUFFLER — symmetry-preserving puzzle permutation
# ══════════════════════════════════════════════════════════════

def shuffle_sudoku(bd81, rng=None):
    """Shuffle a Sudoku puzzle via symmetry transforms (preserves difficulty class).
    Swaps row bands, col bands, rows within bands, cols within bands,
    relabels digits, and optionally transposes."""
    if rng is None:
        rng = random.random
    g = [int(ch) for ch in bd81]

    def shuffle3():
        a = [0, 1, 2]
        for i in range(2, 0, -1):
            j = int(rng() * (i + 1))
            a[i], a[j] = a[j], a[i]
        return a

    # 1. Swap row bands
    new = [0] * 81
    band_order = shuffle3()
    for b in range(3):
        src = band_order[b]
        for r in range(3):
            for c in range(9):
                new[(b * 3 + r) * 9 + c] = g[(src * 3 + r) * 9 + c]
    g = list(new)

    # 2. Swap col bands
    col_band = shuffle3()
    for b in range(3):
        src = col_band[b]
        for r in range(9):
            for c in range(3):
                new[r * 9 + (b * 3 + c)] = g[r * 9 + (src * 3 + c)]
    g = list(new)

    # 3. Swap rows within each band
    for band in range(3):
        perm = shuffle3()
        for r in range(3):
            for c in range(9):
                new[(band * 3 + r) * 9 + c] = g[(band * 3 + perm[r]) * 9 + c]
    g = list(new)

    # 4. Swap cols within each band
    for band in range(3):
        perm = shuffle3()
        for r in range(9):
            for c in range(3):
                new[r * 9 + (band * 3 + c)] = g[r * 9 + (band * 3 + perm[c])]
    g = list(new)

    # 5. Relabel digits
    digits = list(range(1, 10))
    for i in range(8, 0, -1):
        j = int(rng() * (i + 1))
        digits[i], digits[j] = digits[j], digits[i]
    relabel = [0] + digits
    g = [0 if d == 0 else relabel[d] for d in g]

    # 6. Transpose (50% chance)
    if rng() < 0.5:
        t = list(g)
        for r in range(9):
            for c in range(9):
                g[r * 9 + c] = t[c * 9 + r]

    return ''.join(str(d) for d in g)


def crosswise_shuffle(bd81, rng=None):
    """Cross-section shuffle via full-board D4 + standard shuffling."""
    if rng is None:
        rng = random.random
    g = [int(ch) for ch in bd81]

    # Step 1: Random D4 board transformation
    op = int(rng() * 8)
    if op > 0:
        new = [0] * 81
        for r in range(9):
            for c in range(9):
                if op == 1:    nr, nc = c, 8 - r
                elif op == 2:  nr, nc = 8 - r, 8 - c
                elif op == 3:  nr, nc = 8 - c, r
                elif op == 4:  nr, nc = r, 8 - c
                elif op == 5:  nr, nc = 8 - r, c
                elif op == 6:  nr, nc = c, r
                elif op == 7:  nr, nc = 8 - c, 8 - r
                else:          nr, nc = r, c
                new[nr * 9 + nc] = g[r * 9 + c]
        g = new

    # Step 2: Standard shuffling
    def shuffle3():
        a = [0, 1, 2]
        for i in range(2, 0, -1):
            j = int(rng() * (i + 1))
            a[i], a[j] = a[j], a[i]
        return a

    new = [0] * 81
    band_order = shuffle3()
    for b in range(3):
        src = band_order[b]
        for r in range(3):
            for c in range(9):
                new[(b * 3 + r) * 9 + c] = g[(src * 3 + r) * 9 + c]
    g = list(new)

    col_band = shuffle3()
    for b in range(3):
        src = col_band[b]
        for r in range(9):
            for c in range(3):
                new[r * 9 + (b * 3 + c)] = g[r * 9 + (src * 3 + c)]
    g = list(new)

    for band in range(3):
        perm = shuffle3()
        for r in range(3):
            for c in range(9):
                new[(band * 3 + r) * 9 + c] = g[(band * 3 + perm[r]) * 9 + c]
    g = list(new)

    for band in range(3):
        perm = shuffle3()
        for r in range(9):
            for c in range(3):
                new[r * 9 + (band * 3 + c)] = g[r * 9 + (band * 3 + perm[c])]
    g = list(new)

    # Step 3: Digit relabeling
    digits = list(range(1, 10))
    for i in range(8, 0, -1):
        j = int(rng() * (i + 1))
        digits[i], digits[j] = digits[j], digits[i]
    relabel = [0] + digits
    g = [0 if d == 0 else relabel[d] for d in g]

    return ''.join(str(d) for d in g)


# ══════════════════════════════════════════════════════════════
# CONSTELLATION FORGE
# ══════════════════════════════════════════════════════════════

def forge_variant(bd81, target_clues=None, max_retries=20, max_level=99,
                  no_oracle=True, gf2_extended=False):
    """Generate a constellation-forged variant with the same clue count."""
    from .engine import has_unique_solution, solve_backtrack
    from .solver import solve_selective  # lazy import to avoid circular dep

    solution = solve_backtrack(bd81)
    if not solution:
        return None

    if target_clues is None:
        target_clues = sum(1 for ch in bd81 if ch != '0' and ch != '.')

    for attempt in range(max_retries):
        clue_set = {i for i, ch in enumerate(bd81) if ch != '0' and ch != '.'}
        empty_set = {i for i in range(81) if i not in clue_set}

        n_swaps = target_clues * 10
        for _ in range(n_swaps):
            if not empty_set:
                break
            add_pos = random.choice(list(empty_set))
            expanded = clue_set | {add_pos}

            removable = list(clue_set)
            random.shuffle(removable)
            for rm_pos in removable:
                test_clues = expanded - {rm_pos}
                test = ''.join(solution[i] if i in test_clues else '0' for i in range(81))
                if has_unique_solution(test):
                    clue_set = test_clues
                    empty_set = (empty_set - {add_pos}) | {rm_pos}
                    break

        forged = ''.join(solution[i] if i in clue_set else '0' for i in range(81))

        # Relabel digits
        digits = list(range(1, 10))
        for i in range(8, 0, -1):
            j = int(random.random() * (i + 1))
            digits[i], digits[j] = digits[j], digits[i]
        relabel_map = {0: '0'}
        for i, d in enumerate(digits):
            relabel_map[i + 1] = str(d)
        forged = ''.join(relabel_map[int(ch)] for ch in forged)

        result = solve_selective(forged, gf2_extended=gf2_extended)
        if result['success']:
            return forged

    return None
