"""Larsdoku — Solver pipeline: selective solver, SIRO bootstrap, cell query."""
from __future__ import annotations

import time

from .engine import (
    BitBoard, BIT, ALL_DIGITS, POPCOUNT, BOX_OF, PEERS,
    propagate_l1l2, solve_backtrack, solve_bitwise,
    detect_fpc_bitwise, detect_fpce_bitwise,
    detect_forcing_chain_bitwise, detect_forcing_net,
    detect_d2b_bitwise, detect_fpf_bitwise,
    detect_xwing, detect_swordfish, detect_simple_coloring,
    detect_bug_plus1, detect_ur_type2, detect_ur_type4,
    detect_junior_exocet_stuart, detect_junior_exocet, detect_template, detect_bowman_bingo,
    detect_gf2_extended, fast_propagate, iter_bits9,
    detect_x_cycle_bitwise, detect_als_xz_bitwise,
    detect_sue_de_coq_bitwise, detect_aligned_pair_exclusion_bitwise,
    detect_als_xy_wing_bitwise, detect_death_blossom_bitwise,
    detect_sk_loop_bitwise, detect_kraken_fish_bitwise,
    detect_deep_resonance, validate_sudoku as engine_validate_sudoku,
    has_unique_solution,
)
from .gf2_larsxor import detect_gf2_larsxor as detect_gf2_lanczos  # XOR-accelerated drop-in
from .constants import TECHNIQUE_LEVELS, WSRF_INVENTIONS, EXPERIMENTAL_TECHNIQUES
from .utils import validate_eliminations, validate_sudoku


# ══════════════════════════════════════════════════════════════
# ZONE 135 — cross-board zone sum deduction
# ══════════════════════════════════════════════════════════════

_ZONE_POSITIONS = {
    'TL': (0, 0), 'TC': (0, 1), 'TR': (0, 2),
    'ML': (1, 0), 'MC': (1, 1), 'MR': (1, 2),
    'BL': (2, 0), 'BC': (2, 1), 'BR': (2, 2),
}
_ZONE_ORDER = ['TL', 'TC', 'TR', 'ML', 'MC', 'MR', 'BL', 'BC', 'BR']

_ZONE_ROWS = [['TL', 'TC', 'TR'], ['ML', 'MC', 'MR'], ['BL', 'BC', 'BR']]
_ZONE_COLS = [['TL', 'ML', 'BL'], ['TC', 'MC', 'BC'], ['TR', 'MR', 'BR']]


def _zone_cells(pos_name):
    """Get 9 cell indices for a zone position (one per box)."""
    rel_r, rel_c = _ZONE_POSITIONS[pos_name]
    cells = []
    for box in range(9):
        br, bc = (box // 3) * 3, (box % 3) * 3
        cells.append((br + rel_r) * 9 + (bc + rel_c))
    return cells


def detect_zone135(bb, zone_sums_oracle):
    """Zone 135 detector — uses oracle zone sums for deduction.

    Two modes:
    1. PLACEMENT: If 8/9 cells at a zone position are filled,
       the last digit = zone_sum - partial_sum.
    2. ELIMINATION: If 7/9 cells are filled, the remaining 2 must
       sum to a known value -- eliminate candidates that can't work.
    """
    placements = []
    eliminations = []

    for pos_name in _ZONE_ORDER:
        if pos_name not in zone_sums_oracle:
            continue

        target = zone_sums_oracle[pos_name]
        cells = _zone_cells(pos_name)

        filled = []
        empty = []
        partial_sum = 0

        for cell in cells:
            if bb.board[cell] != 0:
                filled.append(cell)
                partial_sum += bb.board[cell]
            else:
                empty.append(cell)

        n_filled = len(filled)
        need = target - partial_sum

        # Mode 1: 8/9 filled -> place the last cell
        if n_filled == 8 and len(empty) == 1:
            cell = empty[0]
            if 1 <= need <= 9 and (bb.cands[cell] & BIT[need - 1]):
                placements.append((cell, need, 'Zone135'))

        # Mode 2: 7/9 filled -> two cells must sum to 'need'
        elif n_filled == 7 and len(empty) == 2:
            c1, c2 = empty
            cands1 = [d + 1 for d in range(9) if bb.cands[c1] & BIT[d]]
            cands2 = [d + 1 for d in range(9) if bb.cands[c2] & BIT[d]]
            valid_c1 = [d for d in cands1 if (need - d) in cands2 and d != (need - d)]
            valid_c2 = [d for d in cands2 if (need - d) in cands1 and d != (need - d)]
            for d in cands1:
                if d not in valid_c1:
                    eliminations.append((c1, d))
            for d in cands2:
                if d not in valid_c2:
                    eliminations.append((c2, d))

        # Mode 3: 6/9 filled -> three cells must sum to 'need'
        elif n_filled == 6 and len(empty) == 3:
            c1, c2, c3 = empty
            cands = [
                [d + 1 for d in range(9) if bb.cands[c] & BIT[d]]
                for c in [c1, c2, c3]
            ]
            valid = [set(), set(), set()]
            for d1 in cands[0]:
                for d2 in cands[1]:
                    d3 = need - d1 - d2
                    if d3 in cands[2] and len({d1, d2, d3}) == 3:
                        valid[0].add(d1)
                        valid[1].add(d2)
                        valid[2].add(d3)
            for idx, c in enumerate([c1, c2, c3]):
                for d in cands[idx]:
                    if d not in valid[idx]:
                        eliminations.append((c, d))

    return placements, eliminations


def compute_zone_sums_from_solution(solution_str):
    """Compute zone sums from a complete solution string."""
    sums = {}
    for pos_name in _ZONE_ORDER:
        cells = _zone_cells(pos_name)
        sums[pos_name] = sum(int(solution_str[c]) for c in cells)
    return sums


# ══════════════════════════════════════════════════════════════
# PRIVATE HELPERS
# ══════════════════════════════════════════════════════════════

def _cands_list(bb, pos):
    """Get candidate digits for a cell as a sorted list."""
    return [d + 1 for d in range(9) if bb.cands[pos] & BIT[d]]


def _cell_name(pos):
    return f'R{pos // 9 + 1}C{pos % 9 + 1}'


def _box_of(pos):
    r, c = pos // 9, pos % 9
    return (r // 3) * 3 + c // 3 + 1


def _unit_reason(bb, pos, digit, tech):
    """Generate a brief explanation of why a placement works."""
    box = _box_of(pos)
    if tech == 'nakedSingle':
        return f'only candidate left in {_cell_name(pos)}'
    elif tech == 'crossHatch':
        return f'{digit} can only go here in Box {box} -- peers block all other spots'
    elif tech == 'lastRemaining':
        return f'{digit} can only go here in Box {box} -- peers block all other spots'
    elif tech == 'fullHouse':
        return f'last empty cell in its unit'
    return ''


# ══════════════════════════════════════════════════════════════
# SELECTIVE SOLVER — technique-level control
# ══════════════════════════════════════════════════════════════

def solve_selective(bd81, max_level=99, only_techniques=None, exclude_techniques=None,
                    verbose=False, detail=False, gf2=False, gf2_extended=False,
                    gf2_silent=False,
                    zone_hints=None, dr_mode='all',
                    zone_oracle=False, rule_oracle=False,
                    zone135_oracle=None, **_ignored):
    """Solve with technique selection control -- ORACLE-FREE.

    No answer is computed or used during solving. Every placement is
    proven by Sudoku logic. Verification uses standard Sudoku law only.

    Args:
        bd81: 81-char puzzle string
        max_level: max technique level to use (1-7)
        only_techniques: set of technique names to allow (None = all)
        verbose: print each step as it happens
        detail: capture rich detail (candidates, explanations, rounds)
        gf2: enable GF(2) Block Lanczos (off by default)
        gf2_extended: use GF2_Extended with all options A-E (implies gf2=True)
        gf2_silent: run GF2 after L1 drain without recording in technique_counts
                    (preserves L4+ technique profile for --like matching)
        zone_hints: dict {(pos,digit) -> 0|1} for zone prediction injection (B)

    Returns dict with steps, technique_counts, success, stalled_at, etc.
    """
    bb = BitBoard.from_string(bd81)
    _dr_mode = dr_mode
    _use_zone_oracle = zone_oracle
    _use_rule_oracle = rule_oracle
    _skip_digits = 0

    def allowed(tech_name):
        if exclude_techniques and tech_name in exclude_techniques:
            return False
        if tech_name in EXPERIMENTAL_TECHNIQUES:
            if only_techniques is not None:
                return tech_name in only_techniques
            return False
        if only_techniques is not None:
            return tech_name in only_techniques
        return TECHNIQUE_LEVELS.get(tech_name, 99) <= max_level

    steps = []
    elim_events = []
    technique_counts = {}
    step_num = 0
    round_num = 0
    stalled = False

    while bb.empty > 0:
        round_num += 1

        # -- Phase 1: L1+L2 drain --
        if allowed('crossHatch'):
            l1_batch = propagate_l1l2(bb)
            for pos, digit, tech in l1_batch:
                cands_before = _cands_list(bb, pos) if detail and bb.board[pos] == 0 else None
                step_num += 1
                entry = {'step': step_num, 'pos': pos, 'digit': digit,
                         'technique': tech, 'cell': _cell_name(pos),
                         'round': round_num}
                if detail:
                    entry['cands_before'] = cands_before or [digit]
                    entry['explanation'] = _unit_reason(bb, pos, digit, tech)
                steps.append(entry)
                technique_counts[tech] = technique_counts.get(tech, 0) + 1
                if verbose:
                    print(f"  #{step_num:3d}  {entry['cell']}={digit}  [{tech}]")

        if bb.empty == 0:
            break

        # -- Phase 1.4: Silent GF(2) acceleration (no technique recording) --
        # Cleans linear constraints without polluting technique_counts,
        # so L4+ technique profile stays accurate for --like matching.
        if gf2_silent:
            _sg_p, _sg_e, _, _, _skip_digits = detect_gf2_lanczos(
                bb, return_residual=True)
            _sg_changed = False
            if _sg_e:
                for pos, d in _sg_e:
                    bb.eliminate(pos, d)
                _sg_changed = True
            for pos, digit, _ in _sg_p:
                if bb.board[pos] == 0:
                    bb.place(pos, digit)
                    _sg_changed = True
            if _sg_changed:
                _skip_digits = 0  # Board changed — recompute next round
                continue

        # -- Phase 1.25: Zone 135 (opt-in via zone135_oracle) --
        if zone135_oracle and allowed('Zone135'):
            z135_p, z135_e = detect_zone135(bb, zone135_oracle)

            z135_changed = False
            if z135_e:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'Zone135',
                        'eliminations': [(pos, d) for pos, d in z135_e],
                        'detail': f'Zone135: {len(z135_e)} eliminations (135 rule)',
                    })
                for pos, d in z135_e:
                    bb.eliminate(pos, d)
                z135_changed = True

            for pos, digit, tech in z135_p:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, digit)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': digit,
                             'technique': 'Zone135', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        zone_name = None
                        for zn in _ZONE_ORDER:
                            if pos in _zone_cells(zn):
                                zone_name = zn
                                break
                        entry['explanation'] = (
                            f'Zone135: {zone_name} sum={zone135_oracle.get(zone_name, "?")} '
                            f'-> last cell must be {digit}')
                    steps.append(entry)
                    technique_counts['Zone135'] = technique_counts.get('Zone135', 0) + 1
                    z135_changed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={digit}  [Zone135]")

            if z135_changed:
                continue

        # -- Phase 1.5: GF(2) Block Lanczos (opt-in via --gf2 or --gf2x) --
        if (gf2 or gf2_extended) and allowed('GF2_Lanczos'):
            gf2_p, gf2_e, dof, _, _skip_digits = detect_gf2_lanczos(
                bb, return_residual=True)
            probe_stats = {}

            if not gf2_p and not gf2_e and gf2_extended and (zone_hints or dof <= 20):
                gf2_p, gf2_e, dof, contradiction, probe_stats = detect_gf2_extended(
                    bb, zone_hints=zone_hints, probe_free=(dof <= 20),
                    conjugates=True, band_stack=True)
                if contradiction:
                    if verbose:
                        print("  GF(2) contradiction -- zone predictions inconsistent")
                    zone_hints = None
                    gf2_p, gf2_e, dof, _, probe_stats = detect_gf2_extended(
                        bb, zone_hints=None, probe_free=True,
                        conjugates=True, band_stack=True)

            gf2_changed = False
            if gf2_e:
                has_probe = any(t == 'GF2_Probe' for _, _, t in gf2_p) if gf2_p else False
                tech_label = 'GF2_Probe' if has_probe else ('GF2_Extended' if (gf2_extended and probe_stats) else 'GF2_Lanczos')
                if detail:
                    probe_info = ''
                    if probe_stats.get('forced_by_contradiction', 0) or probe_stats.get('forced_by_agreement', 0):
                        probe_info = f' | probed {probe_stats["probes"]} free vars: {probe_stats["forced_by_contradiction"]} by contradiction, {probe_stats["forced_by_agreement"]} by agreement'
                    elim_events.append({
                        'round': round_num, 'technique': tech_label,
                        'eliminations': [(pos, d) for pos, d in gf2_e],
                        'detail': f'GF(2) {tech_label}: {len(gf2_e)} eliminations (dof={dof}){probe_info}',
                    })
                for pos, d in gf2_e:
                    bb.eliminate(pos, d)
                gf2_changed = True
            for pos, digit, tech in gf2_p:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, digit)
                    step_num += 1
                    tech_label = tech if gf2_extended else 'GF2_Lanczos'
                    entry = {'step': step_num, 'pos': pos, 'digit': digit,
                             'technique': tech_label, 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        probe_note = ''
                        if tech == 'GF2_Probe':
                            probe_note = ' (found by probing free variables)'
                        entry['explanation'] = f'GF(2) linear algebra resolves cell (dof={dof}){probe_note}'
                    steps.append(entry)
                    technique_counts[tech_label] = technique_counts.get(tech_label, 0) + 1
                    gf2_changed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={digit}  [{tech_label}] (dof={dof})")
            if gf2_changed:
                continue

        # -- Phase 2: Advanced techniques --
        placed = False

        # X-Wing + Swordfish
        if allowed('XWing'):
            xw_before = {pos: _cands_list(bb, pos) for pos in range(81) if bb.board[pos] == 0} if detail else None
            if detect_xwing(bb):
                technique_counts['XWing'] = technique_counts.get('XWing', 0) + 1
                if detail:
                    elims = []
                    for pos in range(81):
                        if bb.board[pos] == 0 and pos in xw_before:
                            new_c = _cands_list(bb, pos)
                            removed = set(xw_before[pos]) - set(new_c)
                            for d in removed:
                                elims.append((pos, d))
                    elim_events.append({
                        'round': round_num, 'technique': 'XWing',
                        'eliminations': elims,
                        'detail': f'X-Wing: {len(elims)} eliminations',
                    })
                continue
        if allowed('Swordfish'):
            sf_before = {pos: _cands_list(bb, pos) for pos in range(81) if bb.board[pos] == 0} if detail else None
            if detect_swordfish(bb):
                technique_counts['Swordfish'] = technique_counts.get('Swordfish', 0) + 1
                if detail:
                    elims = []
                    for pos in range(81):
                        if bb.board[pos] == 0 and pos in sf_before:
                            new_c = _cands_list(bb, pos)
                            removed = set(sf_before[pos]) - set(new_c)
                            for d in removed:
                                elims.append((pos, d))
                    elim_events.append({
                        'round': round_num, 'technique': 'Swordfish',
                        'eliminations': elims,
                        'detail': f'Swordfish: {len(elims)} eliminations',
                    })
                continue

        # Simple Coloring
        if allowed('SimpleColoring'):
            sc_elims, sc_detail = detect_simple_coloring(bb, skip_digits=_skip_digits)
            if sc_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'SimpleColoring',
                        'eliminations': list(sc_elims),
                        'detail': f'Simple Coloring: {len(sc_elims)} eliminations',
                    })
                for pos, d in sc_elims:
                    bb.eliminate(pos, d)
                technique_counts['SimpleColoring'] = technique_counts.get('SimpleColoring', 0) + 1
                continue

        # -- Exotic techniques --

        # X-Cycles
        if allowed('XCycle'):
            xc_place, xc_elim = detect_x_cycle_bitwise(bb)
            if xc_place:
                pos, digit, tech = xc_place[0]
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, digit)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': digit,
                             'technique': 'XCycle', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'X-Cycle Rule 2: digit {digit} placed at {_cell_name(pos)}'
                    steps.append(entry)
                    technique_counts['XCycle'] = technique_counts.get('XCycle', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={digit}  [XCycle]")
            if not placed and xc_elim:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'XCycle',
                        'eliminations': list(xc_elim),
                        'detail': f'X-Cycle: {len(xc_elim)} eliminations',
                    })
                for pos, d in xc_elim:
                    bb.eliminate(pos, d)
                technique_counts['XCycle'] = technique_counts.get('XCycle', 0) + 1
                continue

        # ALS-XZ
        if allowed('ALS_XZ'):
            als_elims = detect_als_xz_bitwise(bb)
            if als_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'ALS_XZ',
                        'eliminations': list(als_elims),
                        'detail': f'ALS-XZ: {len(als_elims)} eliminations',
                    })
                for pos, d in als_elims:
                    bb.eliminate(pos, d)
                technique_counts['ALS_XZ'] = technique_counts.get('ALS_XZ', 0) + 1
                continue

        # Sue De Coq
        if allowed('SueDeCoq'):
            sdc_elims = detect_sue_de_coq_bitwise(bb)
            if sdc_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'SueDeCoq',
                        'eliminations': list(sdc_elims),
                        'detail': f'Sue De Coq: {len(sdc_elims)} eliminations',
                    })
                for pos, d in sdc_elims:
                    bb.eliminate(pos, d)
                technique_counts['SueDeCoq'] = technique_counts.get('SueDeCoq', 0) + 1
                continue

        # Aligned Pair Exclusion
        if allowed('AlignedPairExcl'):
            ape_elims = detect_aligned_pair_exclusion_bitwise(bb)
            if ape_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'AlignedPairExcl',
                        'eliminations': list(ape_elims),
                        'detail': f'Aligned Pair Exclusion: {len(ape_elims)} eliminations',
                    })
                for pos, d in ape_elims:
                    bb.eliminate(pos, d)
                technique_counts['AlignedPairExcl'] = technique_counts.get('AlignedPairExcl', 0) + 1
                continue

        # ALS-XY Wing
        if allowed('ALS_XYWing'):
            alsxy_elims = detect_als_xy_wing_bitwise(bb)
            if alsxy_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'ALS_XYWing',
                        'eliminations': list(alsxy_elims),
                        'detail': f'ALS-XY Wing: {len(alsxy_elims)} eliminations',
                    })
                for pos, d in alsxy_elims:
                    bb.eliminate(pos, d)
                technique_counts['ALS_XYWing'] = technique_counts.get('ALS_XYWing', 0) + 1
                continue

        # Death Blossom
        if allowed('DeathBlossom'):
            db_elims = detect_death_blossom_bitwise(bb)
            if db_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'DeathBlossom',
                        'eliminations': list(db_elims),
                        'detail': f'Death Blossom: {len(db_elims)} eliminations',
                    })
                for pos, d in db_elims:
                    bb.eliminate(pos, d)
                technique_counts['DeathBlossom'] = technique_counts.get('DeathBlossom', 0) + 1
                continue

        # Kraken Fish
        if allowed('KrakenFish'):
            kf_elims = detect_kraken_fish_bitwise(bb)
            if kf_elims:
                kf_elims = validate_eliminations(bb, kf_elims)
                if kf_elims:
                    if detail:
                        elim_events.append({
                            'round': round_num, 'technique': 'KrakenFish',
                            'eliminations': list(kf_elims),
                            'detail': f'Kraken Fish: {len(kf_elims)} eliminations',
                        })
                    for pos, d in kf_elims:
                        bb.eliminate(pos, d)
                    technique_counts['KrakenFish'] = technique_counts.get('KrakenFish', 0) + 1
                    continue

        # FPC
        if allowed('FPC'):
            fpc_hits = detect_fpc_bitwise(bb)
            for pos, val, fpc_detail in fpc_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'FPC', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        chain_desc = fpc_detail.get('chain', '') if isinstance(fpc_detail, dict) else str(fpc_detail)
                        entry['explanation'] = f'Finned Pointing Chain: digit {val} -> {_cell_name(pos)}'
                        if chain_desc:
                            entry['chain'] = chain_desc
                    steps.append(entry)
                    technique_counts['FPC'] = technique_counts.get('FPC', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [FPC]")
                    break
            if placed:
                continue

        # FPCE
        if allowed('FPCE'):
            fpce_p, fpce_e = detect_fpce_bitwise(bb)
            if fpce_e:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'FPCE',
                        'eliminations': list(fpce_e),
                        'detail': f'FPC Elimination: {len(fpce_e)} eliminations -- contradict on propagation',
                    })
                for pos, d in fpce_e:
                    bb.eliminate(pos, d)
            for pos, val, fpce_detail in fpce_p:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'FPCE', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'FPC Elimination: digit {val} -> {_cell_name(pos)} via contradiction'
                    steps.append(entry)
                    technique_counts['FPCE'] = technique_counts.get('FPCE', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [FPCE]")
                    break
            if placed:
                continue
            if fpce_e:
                continue

        # Forcing Chain
        if allowed('ForcingChain'):
            fc_hits = detect_forcing_chain_bitwise(bb)
            for pos, val, fc_detail in fc_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'ForcingChain', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'Forcing Chain: all branches from bivalue cell lead to {val}@{_cell_name(pos)}'
                    steps.append(entry)
                    technique_counts['ForcingChain'] = technique_counts.get('ForcingChain', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [ForcingChain]")
                    break
            if placed:
                continue

        # Forcing Net
        if allowed('ForcingNet'):
            fn_hits = detect_forcing_net(bb)
            for pos, val, fn_detail in fn_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'ForcingNet', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'Forcing Net: all candidate branches converge on {val}@{_cell_name(pos)}'
                    steps.append(entry)
                    technique_counts['ForcingNet'] = technique_counts.get('ForcingNet', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [ForcingNet]")
                    break
            if placed:
                continue

        # BUG+1
        if allowed('BUG+1'):
            bug_hits = detect_bug_plus1(bb)
            for pos, val, bug_detail in bug_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'BUG+1', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'BUG+1: {_cell_name(pos)} is the only trivalue cell -- {val} breaks the deadly pattern'
                    steps.append(entry)
                    technique_counts['BUG+1'] = technique_counts.get('BUG+1', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [BUG+1]")
                    break
            if placed:
                continue

        # UR Type 2
        if allowed('URType2'):
            ur2_elims, _ = detect_ur_type2(bb)
            if ur2_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'URType2',
                        'eliminations': list(ur2_elims),
                        'detail': f'Unique Rectangle Type 2: {len(ur2_elims)} eliminations',
                    })
                for pos, d in ur2_elims:
                    bb.eliminate(pos, d)
                technique_counts['URType2'] = technique_counts.get('URType2', 0) + 1
                continue

        # UR Type 4
        if allowed('URType4'):
            ur4_elims, _ = detect_ur_type4(bb)
            if ur4_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'URType4',
                        'eliminations': list(ur4_elims),
                        'detail': f'Unique Rectangle Type 4: {len(ur4_elims)} eliminations',
                    })
                for pos, d in ur4_elims:
                    bb.eliminate(pos, d)
                technique_counts['URType4'] = technique_counts.get('URType4', 0) + 1
                continue

        # Junior Exocet — Stuart's validated version
        if allowed('JuniorExocet'):
            je_elims, je_detail = detect_junior_exocet_stuart(bb)
            if je_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'JuniorExocet',
                        'eliminations': list(je_elims),
                        'detail': je_detail,
                    })
                for pos, d in je_elims:
                    bb.eliminate(pos, d)
                technique_counts['JuniorExocet'] = technique_counts.get('JuniorExocet', 0) + 1
                continue

        # JETest — experimental: our original Exocet detector (fire once)
        # Enable with --experimental flag
        if allowed('JETest') and technique_counts.get('JETest', 0) < 1:
            je_elims, _ = detect_junior_exocet(bb)
            if je_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'JETest',
                        'eliminations': list(je_elims),
                        'detail': f'JETest (experimental): {len(je_elims)} eliminations',
                    })
                for pos, d in je_elims:
                    bb.eliminate(pos, d)
                technique_counts['JETest'] = technique_counts.get('JETest', 0) + 1
                continue

        # Template
        if allowed('Template'):
            tmpl_p, tmpl_e = detect_template(bb)
            if tmpl_e:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'Template',
                        'eliminations': list(tmpl_e),
                        'detail': f'Template: {len(tmpl_e)} eliminations',
                    })
                for pos, d in tmpl_e:
                    bb.eliminate(pos, d)
            for pos, val, tmpl_detail in tmpl_p:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'Template', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'Template: digit {val} has only one valid placement pattern'
                    steps.append(entry)
                    technique_counts['Template'] = technique_counts.get('Template', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [Template]")
                    break
            if placed:
                continue
            if tmpl_e:
                continue

        # Bowman's Bingo
        if allowed('BowmanBingo'):
            bingo_hits = detect_bowman_bingo(bb)
            for pos, val, bingo_detail in bingo_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'BowmanBingo', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f"Bowman's Bingo: trial-and-error eliminates all but {val}"
                    steps.append(entry)
                    technique_counts['BowmanBingo'] = technique_counts.get('BowmanBingo', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [BowmanBingo]")
                    break
            if placed:
                continue

        # D2B
        if allowed('D2B'):
            d2b_hits = detect_d2b_bitwise(bb)
            for pos, val, d2b_detail in d2b_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'D2B', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'Depth-2 Bilateral: branch on bivalue cells, common result = {val}@{_cell_name(pos)}'
                    steps.append(entry)
                    technique_counts['D2B'] = technique_counts.get('D2B', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [D2B]")
                    break
            if placed:
                continue

        # SK Loop
        if allowed('SKLoop'):
            sk_elims = detect_sk_loop_bitwise(bb)
            if sk_elims:
                sk_elims = validate_eliminations(bb, sk_elims)
                if sk_elims:
                    if detail:
                        elim_events.append({
                            'round': round_num, 'technique': 'SKLoop',
                            'eliminations': list(sk_elims),
                            'detail': f'SK Loop: {len(sk_elims)} eliminations',
                        })
                    for pos, d in sk_elims:
                        bb.eliminate(pos, d)
                    technique_counts['SKLoop'] = technique_counts.get('SKLoop', 0) + 1
                    continue

        # Deep Resonance
        if allowed('DeepResonance'):
            dr_elims = detect_deep_resonance(bb, mode=_dr_mode)
            if dr_elims:
                dr_elims = validate_eliminations(bb, dr_elims)
                if dr_elims:
                    if detail:
                        elim_events.append({
                            'round': round_num, 'technique': 'DeepResonance',
                            'eliminations': list(dr_elims),
                            'detail': f'Deep Resonance: {len(dr_elims)} eliminations',
                        })
                    for pos, d in dr_elims:
                        bb.eliminate(pos, d)
                    technique_counts['DeepResonance'] = technique_counts.get('DeepResonance', 0) + 1
                    continue

        # FPF
        if allowed('FPF'):
            fpf_hits = detect_fpf_bitwise(bb)
            for pos, val, fpf_detail in fpf_hits:
                if bb.board[pos] == 0:
                    cands_before = _cands_list(bb, pos) if detail else None
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'FPF', 'cell': _cell_name(pos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = cands_before
                        entry['explanation'] = f'Full Pipeline Forcing: contradiction testing confirms {val}@{_cell_name(pos)}'
                    steps.append(entry)
                    technique_counts['FPF'] = technique_counts.get('FPF', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [FPF]")
                    break
            if placed:
                continue

        # -- STALLED: try Zone Oracle / Rule Oracle if enabled --
        if _use_zone_oracle:
            try:
                from .wsrf_zone import zone_predict
                zresult = zone_predict(bb)
                if zresult:
                    best_pos, zdigit, n_likely, zdetail = zresult
                    if bb.board[best_pos] == 0 and (bb.cands[best_pos] & BIT[zdigit - 1]):
                        cands_before = _cands_list(bb, best_pos) if detail else None
                        bb.place(best_pos, zdigit)
                        step_num += 1
                        entry = {'step': step_num, 'pos': best_pos, 'digit': zdigit,
                                 'technique': 'ZONE_ORACLE', 'cell': _cell_name(best_pos),
                                 'round': round_num}
                        if detail:
                            entry['cands_before'] = cands_before
                            entry['explanation'] = zdetail
                        steps.append(entry)
                        technique_counts['ZONE_ORACLE'] = technique_counts.get('ZONE_ORACLE', 0) + 1
                        placed = True
                        if verbose:
                            print(f"  #{step_num:3d}  {entry['cell']}={zdigit}  [ZONE ORACLE]")
            except ImportError:
                pass
            if placed:
                l1_after = propagate_l1l2(bb)
                for apos, adigit, atech in l1_after:
                    step_num += 1
                    entry = {'step': step_num, 'pos': apos, 'digit': adigit,
                             'technique': 'RULE_ORACLE', 'cell': _cell_name(apos),
                             'round': round_num}
                    if detail:
                        entry['cands_before'] = [adigit]
                        entry['explanation'] = f'Sudoku Rule Oracle: {_cell_name(apos)} = {adigit} -- forced by zone placement cascade'
                    steps.append(entry)
                    technique_counts['RULE_ORACLE'] = technique_counts.get('RULE_ORACLE', 0) + 1
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={adigit}  [RULE ORACLE]")
                if _use_rule_oracle:
                    for rpos in range(81):
                        if bb.board[rpos] != 0:
                            continue
                        if bb.cands[rpos] and (bb.cands[rpos] & (bb.cands[rpos] - 1)) == 0:
                            rval = bb.cands[rpos].bit_length()
                            cands_before = _cands_list(bb, rpos) if detail else None
                            bb.place(rpos, rval)
                            step_num += 1
                            entry = {'step': step_num, 'pos': rpos, 'digit': rval,
                                     'technique': 'RULE_ORACLE', 'cell': _cell_name(rpos),
                                     'round': round_num}
                            if detail:
                                entry['cands_before'] = cands_before
                                entry['explanation'] = (f'Sudoku Rule Oracle: {_cell_name(rpos)} = {rval} '
                                    f'-- only candidate left after zone placement')
                            steps.append(entry)
                            technique_counts['RULE_ORACLE'] = technique_counts.get('RULE_ORACLE', 0) + 1
                            if verbose:
                                print(f"  #{step_num:3d}  {entry['cell']}={rval}  [RULE ORACLE]")
                continue

        stalled = True
        break

    # Verify by Sudoku law -- no oracle
    board_str = ''.join(str(bb.board[i]) for i in range(81))
    solved = bb.empty == 0 and validate_sudoku(bb.board)

    return {
        'success': solved,
        'stalled': stalled,
        'steps': steps,
        'n_steps': len(steps),
        'technique_counts': technique_counts,
        'board': board_str,
        'empty_remaining': bb.empty,
        'rounds': round_num,
        'elim_events': elim_events if detail else [],
    }


# ══════════════════════════════════════════════════════════════
# SIRO BOOTSTRAP
# ══════════════════════════════════════════════════════════════

def solve_siro_bootstrap(bd81, max_level=99, verbose=False, detail=False):
    """SIRO Bootstrap: self-verifying oracle via L1 reduction + prediction."""
    import itertools

    clue_cells = {i for i in range(81) if bd81[i] not in ('0', '.')}

    verification = None
    result = None
    proven_placed = {}
    proof_level = 0

    for try_level in (1, 5, 7):
        proof_result = solve_selective(bd81, max_level=try_level, verbose=False)

        proven_placed = {}
        for s in proof_result['steps']:
            pos = s['pos']
            if pos not in clue_cells:
                proven_placed[pos] = s['digit']

        if verbose:
            print(f'  L{try_level} placed {len(proven_placed)} cells (stalled at {proof_result.get("empty_remaining", "?")} empty)')

        zone_proven = {}
        for pos_name in _ZONE_ORDER:
            cells = _zone_cells(pos_name)
            zone_proven[pos_name] = [(c, proven_placed[c]) for c in cells if c in proven_placed]

        has_candidates = any(len(v) >= 2 for v in zone_proven.values())
        if has_candidates:
            proof_level = try_level
            break
    else:
        proof_level = 7

    if verbose and proof_level > 1:
        print(f'  Using L{proof_level} placements as control group')

    if proof_level > 0:
        zone_proven = {}
        for pos_name in _ZONE_ORDER:
            cells = _zone_cells(pos_name)
            zone_proven[pos_name] = [(c, proven_placed[c]) for c in cells if c in proven_placed]

        for pos_name in _ZONE_ORDER:
            candidates = zone_proven[pos_name]
            if len(candidates) < 2:
                continue

            for (c1, d1), (c2, d2) in itertools.combinations(candidates, 2):
                reduced = list(bd81)
                for pos, digit in proven_placed.items():
                    if pos != c1 and pos != c2:
                        reduced[pos] = str(digit)
                reduced[c1] = '0'
                reduced[c2] = '0'
                reduced_str = ''.join(reduced)

                if verbose:
                    print(f'  Reduction: removed {_cell_name(c1)}={d1}, {_cell_name(c2)}={d2} from zone {pos_name}')

                cascade_result = solve_selective(
                    reduced_str, max_level=max_level,
                    verbose=False, detail=detail,
                    zone_oracle=True, rule_oracle=True,
                )

                if not cascade_result['success']:
                    if verbose:
                        print(f'    SIRO cascade did not solve -- trying next combo')
                    continue

                cascade_board = cascade_result['board']
                pred_d1 = int(cascade_board[c1]) if cascade_board[c1] != '0' else 0
                pred_d2 = int(cascade_board[c2]) if cascade_board[c2] != '0' else 0

                match1 = pred_d1 == d1
                match2 = pred_d2 == d2

                if verbose:
                    m1 = 'Y' if match1 else 'N'
                    m2 = 'Y' if match2 else 'N'
                    print(f'  SIRO prediction: {_cell_name(c1)}={pred_d1} {m1}  {_cell_name(c2)}={pred_d2} {m2}')

                if match1 and match2:
                    verification = {
                        'verified': True,
                        'zone': pos_name,
                        'proof_level': proof_level,
                        'control_cells': [
                            {'cell': _cell_name(c1), 'pos': c1, 'expected': d1, 'predicted': pred_d1, 'match': True},
                            {'cell': _cell_name(c2), 'pos': c2, 'expected': d2, 'predicted': pred_d2, 'match': True},
                        ],
                        'proven_placed_count': len(proven_placed),
                    }
                    result = cascade_result
                    if verbose:
                        print(f'  Oracle VERIFIED -- cascade trusted')
                    break

            if verification:
                break

    if verification is None:
        if verbose:
            print(f'  No verified bootstrap found -- falling back to standard SIRO')
        result = solve_selective(
            bd81, max_level=max_level,
            verbose=verbose, detail=detail,
            zone_oracle=True, rule_oracle=True,
        )
        verification = {
            'verified': False,
            'reason': f'no zone had >=2 proven cells (up to L{proof_level}) or no combo predicted correctly',
            'proven_placed_count': len(proven_placed),
        }

    result['siro_bootstrap'] = verification

    if result['success']:
        result['zone_sums'] = compute_zone_sums_from_solution(result['board'])

    return result


# ══════════════════════════════════════════════════════════════
# SIRO-GUIDED CASCADE
# ══════════════════════════════════════════════════════════════

def solve_siro_guided(bd81, max_level=99, no_oracle=False, verbose=False, detail=False):
    """SIRO-guided technique cascade with zone-predicted dispatch."""
    from .siro_boost import predict_technique_dispatch, siro_predict

    bb = BitBoard.from_string(bd81)
    solution_str = solve_backtrack(bd81)
    if not solution_str:
        return {'success': False, 'error': 'No solution exists', 'steps': [],
                'technique_counts': {}, 'n_steps': 0, 'board': bd81}
    solution = [int(ch) for ch in solution_str]

    def allowed(tech_name):
        if tech_name in EXPERIMENTAL_TECHNIQUES:
            return False
        return TECHNIQUE_LEVELS.get(tech_name, 99) <= max_level

    steps = []
    elim_events = []
    technique_counts = {}
    step_num = 0
    round_num = 0
    stalled = False

    while bb.empty > 0:
        round_num += 1

        # Phase 1: L1+L2 drain
        if allowed('crossHatch'):
            l1_batch = propagate_l1l2(bb)
            for pos, digit, tech in l1_batch:
                step_num += 1
                entry = {'step': step_num, 'pos': pos, 'digit': digit,
                         'technique': tech, 'cell': _cell_name(pos),
                         'round': round_num}
                steps.append(entry)
                technique_counts[tech] = technique_counts.get(tech, 0) + 1
                if verbose:
                    print(f"  #{step_num:3d}  {entry['cell']}={digit}  [{tech}]")

        if bb.empty == 0:
            break

        # Phase 1.5: GF(2)
        if allowed('GF2_Lanczos'):
            gf2_p, gf2_e, dof = detect_gf2_lanczos(bb)
            gf2_changed = False
            if gf2_e:
                for pos, d in gf2_e:
                    bb.eliminate(pos, d)
                gf2_changed = True
            for pos, digit, tech in gf2_p:
                if bb.board[pos] == 0:
                    bb.place(pos, digit)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': digit,
                             'technique': 'GF2_Lanczos', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['GF2_Lanczos'] = technique_counts.get('GF2_Lanczos', 0) + 1
                    gf2_changed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={digit}  [GF2_Lanczos]")
            if gf2_changed:
                continue

        # Phase 2: Cheap techniques
        placed = False

        if allowed('XWing') and detect_xwing(bb):
            technique_counts['XWing'] = technique_counts.get('XWing', 0) + 1
            continue
        if allowed('Swordfish') and detect_swordfish(bb):
            technique_counts['Swordfish'] = technique_counts.get('Swordfish', 0) + 1
            continue

        if allowed('SimpleColoring'):
            sc_elims, _ = detect_simple_coloring(bb)
            if sc_elims:
                for pos, d in sc_elims:
                    bb.eliminate(pos, d)
                technique_counts['SimpleColoring'] = technique_counts.get('SimpleColoring', 0) + 1
                continue

        if allowed('FPC'):
            fpc_hits = detect_fpc_bitwise(bb)
            for pos, val, det in fpc_hits:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'FPC', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['FPC'] = technique_counts.get('FPC', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [FPC]")
                    break
            if placed:
                continue

        if allowed('FPCE'):
            fpce_p, fpce_e = detect_fpce_bitwise(bb)
            if fpce_e:
                for pos, d in fpce_e:
                    bb.eliminate(pos, d)
            for pos, val, det in fpce_p:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'FPCE', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['FPCE'] = technique_counts.get('FPCE', 0) + 1
                    placed = True
                    if verbose:
                        print(f"  #{step_num:3d}  {entry['cell']}={val}  [FPCE]")
                    break
            if placed:
                continue
            if fpce_e:
                continue

        # SIRO dispatch
        dispatch, siro = predict_technique_dispatch(bb)
        predicted_techs = [t for t, _ in dispatch]

        for predicted_tech, target_cells in dispatch:
            if placed:
                break
            if predicted_tech in ('FPCE', 'FPC', 'FPC_TRI'):
                continue

            if predicted_tech == 'ForcingChain' and allowed('ForcingChain'):
                fc_hits = detect_forcing_chain_bitwise(bb)
                for pos, val, det in fc_hits:
                    if bb.board[pos] == 0:
                        bb.place(pos, val)
                        step_num += 1
                        entry = {'step': step_num, 'pos': pos, 'digit': val,
                                 'technique': 'ForcingChain', 'cell': _cell_name(pos),
                                 'round': round_num}
                        steps.append(entry)
                        technique_counts['ForcingChain'] = technique_counts.get('ForcingChain', 0) + 1
                        placed = True
                        break

            elif predicted_tech == 'D2B' and allowed('D2B'):
                d2b_hits = detect_d2b_bitwise(bb)
                for pos, val, det in d2b_hits:
                    if bb.board[pos] == 0:
                        bb.place(pos, val)
                        step_num += 1
                        entry = {'step': step_num, 'pos': pos, 'digit': val,
                                 'technique': 'D2B', 'cell': _cell_name(pos),
                                 'round': round_num}
                        steps.append(entry)
                        technique_counts['D2B'] = technique_counts.get('D2B', 0) + 1
                        placed = True
                        break

            elif predicted_tech == 'FPF' and allowed('FPF'):
                fpf_hits = detect_fpf_bitwise(bb)
                for pos, val, det in fpf_hits:
                    if bb.board[pos] == 0:
                        bb.place(pos, val)
                        step_num += 1
                        entry = {'step': step_num, 'pos': pos, 'digit': val,
                                 'technique': 'FPF', 'cell': _cell_name(pos),
                                 'round': round_num}
                        steps.append(entry)
                        technique_counts['FPF'] = technique_counts.get('FPF', 0) + 1
                        placed = True
                        break

        if placed:
            continue

        # Fallback techniques
        if allowed('ForcingNet') and 'ForcingNet' not in predicted_techs:
            fn_hits = detect_forcing_net(bb)
            for pos, val, det in fn_hits:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'ForcingNet', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['ForcingNet'] = technique_counts.get('ForcingNet', 0) + 1
                    placed = True
                    break
            if placed:
                continue

        if allowed('BUG+1'):
            bug_hits = detect_bug_plus1(bb)
            for pos, val, det in bug_hits:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'BUG+1', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['BUG+1'] = technique_counts.get('BUG+1', 0) + 1
                    placed = True
                    break
            if placed:
                continue

        if allowed('URType2'):
            ur2_elims, _ = detect_ur_type2(bb)
            if ur2_elims:
                for pos, d in ur2_elims:
                    bb.eliminate(pos, d)
                technique_counts['URType2'] = technique_counts.get('URType2', 0) + 1
                continue
        if allowed('URType4'):
            ur4_elims, _ = detect_ur_type4(bb)
            if ur4_elims:
                for pos, d in ur4_elims:
                    bb.eliminate(pos, d)
                technique_counts['URType4'] = technique_counts.get('URType4', 0) + 1
                continue

        # Junior Exocet — Stuart's validated version
        if allowed('JuniorExocet'):
            je_elims, je_detail = detect_junior_exocet_stuart(bb)
            if je_elims:
                if detail:
                    elim_events.append({
                        'round': round_num, 'technique': 'JuniorExocet',
                        'eliminations': list(je_elims),
                        'detail': je_detail,
                    })
                for pos, d in je_elims:
                    bb.eliminate(pos, d)
                technique_counts['JuniorExocet'] = technique_counts.get('JuniorExocet', 0) + 1
                continue

        if allowed('JETest') and technique_counts.get('JETest', 0) < 1:
            je_elims, _ = detect_junior_exocet(bb)
            if je_elims:
                for pos, d in je_elims:
                    bb.eliminate(pos, d)
                technique_counts['JETest'] = technique_counts.get('JETest', 0) + 1
                continue

        if allowed('Template'):
            tmpl_p, tmpl_e = detect_template(bb)
            if tmpl_e:
                for pos, d in tmpl_e:
                    bb.eliminate(pos, d)
            for pos, val, det in tmpl_p:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'Template', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['Template'] = technique_counts.get('Template', 0) + 1
                    placed = True
                    break
            if placed:
                continue
            if tmpl_e:
                continue

        if allowed('BowmanBingo'):
            bingo_hits = detect_bowman_bingo(bb)
            for pos, val, det in bingo_hits:
                if bb.board[pos] == 0:
                    bb.place(pos, val)
                    step_num += 1
                    entry = {'step': step_num, 'pos': pos, 'digit': val,
                             'technique': 'BowmanBingo', 'cell': _cell_name(pos),
                             'round': round_num}
                    steps.append(entry)
                    technique_counts['BowmanBingo'] = technique_counts.get('BowmanBingo', 0) + 1
                    placed = True
                    break
            if placed:
                continue

        # Stalled
        stalled = True
        break

    solved = all(bb.board[i] == solution[i] for i in range(81))
    board_str = ''.join(str(bb.board[i]) for i in range(81))

    return {
        'success': solved,
        'stalled': stalled,
        'steps': steps,
        'n_steps': len(steps),
        'technique_counts': technique_counts,
        'board': board_str,
        'solution': ''.join(str(s) for s in solution),
        'empty_remaining': bb.empty,
        'rounds': round_num,
        'elim_events': elim_events if detail else [],
        'siro_guided': True,
    }


# ══════════════════════════════════════════════════════════════
# CELL QUERY
# ══════════════════════════════════════════════════════════════

def query_cell(bd81, row, col, max_level=99, only_techniques=None, autotrust=False,
               gf2=False, gf2_extended=False):
    """Find how a specific cell gets solved."""
    pos_target = row * 9 + col

    solution_str = solve_backtrack(bd81)
    if not solution_str:
        return {'error': 'No solution exists'}

    answer = int(solution_str[pos_target])

    ch = bd81[pos_target]
    given_val = int(ch) if ch.isdigit() else 0
    if given_val != 0:
        return {
            'cell': f'R{row+1}C{col+1}',
            'answer': given_val,
            'technique': 'given',
            'step': 0,
            'reachable': True,
            'solve_status': 'given',
            'message': f'R{row+1}C{col+1} = {given_val} (given clue)',
        }

    bb = BitBoard.from_string(bd81)
    cand_mask = bb.cands[pos_target]
    cand_list = [d + 1 for d in range(9) if cand_mask & BIT[d]]

    def _try_solve(trusted_solution=None):
        r = solve_selective(bd81, max_level=max_level, only_techniques=only_techniques,
                            no_oracle=True, trusted_solution=trusted_solution, detail=True,
                            gf2=gf2, gf2_extended=gf2_extended)
        ts = None
        for s in r['steps']:
            if s['pos'] == pos_target:
                ts = s
                break
        p = []
        if ts:
            for s in r['steps']:
                p.append(s)
                if s['pos'] == pos_target:
                    break
        return r, ts, p

    result, target_step, path = _try_solve()

    retry_msg = None
    if not target_step and autotrust:
        retry_msg = 'Pure logic stalled -- retrying with autotrust...'
        result, target_step, path = _try_solve(trusted_solution=solution_str)

    path_techs = {}
    for s in (path if path else result['steps']):
        t = s['technique']
        path_techs[t] = path_techs.get(t, 0) + 1

    all_elim_events = result.get('elim_events', [])
    if target_step:
        target_round = target_step.get('round', 999)
        path_elims = [ev for ev in all_elim_events if ev.get('round', 0) <= target_round]
    else:
        path_elims = all_elim_events

    for ev in path_elims:
        t = ev.get('technique', '?')
        path_techs[t] = path_techs.get(t, 0) + 1

    if target_step:
        return {
            'cell': f'R{row+1}C{col+1}',
            'answer': answer,
            'technique': target_step['technique'],
            'step': target_step['step'],
            'reachable': True,
            'candidates': cand_list,
            'path': path,
            'elim_events': path_elims,
            'solve_status': 'solved' if result['success'] else 'found_cell',
            'total_steps': result['n_steps'],
            'total_empty': result.get('empty_remaining', 0),
            'technique_counts': result['technique_counts'],
            'path_technique_counts': path_techs,
            'used_autotrust': retry_msg is not None,
            'retry_msg': retry_msg,
            'message': f'R{row+1}C{col+1} = {answer} via {target_step["technique"]} (step {target_step["step"]})',
        }
    else:
        return {
            'cell': f'R{row+1}C{col+1}',
            'answer': answer,
            'technique': None,
            'step': None,
            'reachable': False,
            'candidates': cand_list,
            'path': result['steps'],
            'elim_events': path_elims,
            'solve_status': 'stalled',
            'stalled_at_step': result['n_steps'],
            'total_empty': result.get('empty_remaining', 0),
            'technique_counts': result['technique_counts'],
            'path_technique_counts': path_techs,
            'used_autotrust': retry_msg is not None,
            'message': (f'R{row+1}C{col+1} = {answer} (answer known via backtrack) '
                       f'but NOT reachable with selected techniques. '
                       f'Stalled at step {result["n_steps"]} with {result.get("empty_remaining", 0)} cells remaining.'),
        }
