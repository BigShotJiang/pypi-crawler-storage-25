"""Technique Predictor — predict which advanced technique will place a cell.

Based on training data from 100 forum hardest 11+ puzzles (241 samples).
Uses cell features (candidates, rival scores, board progress) to classify
which L5+ technique is needed before running any chains.

Usage:
    from larsdoku_zs.technique_predictor import predict_technique, predict_all

    # Single cell
    result = predict_technique(board, candidates, row, col)
    print(result)  # {'technique': 'FPC', 'confidence': 0.8, 'features': {...}}

    # All empty cells
    results = predict_all(board, candidates)
    for pos, result in results.items():
        print(f"R{pos//9+1}C{pos%9+1}: {result['technique']}")

Author: Lars Rocha — March 2026
"""
from __future__ import annotations


# Training data fingerprints (from 100 forum hardest 11+ puzzles)
# {technique: {avg_rivals, avg_cands, avg_progress, rival_range, n_samples}}
TECHNIQUE_PROFILES = {
    'FPC':  {'avg_rivals': 5.5, 'avg_cands': 3.5, 'avg_progress': 0.34, 'rival_range': (0, 6), 'n': 113},
    'FPCE': {'avg_rivals': 7.7, 'avg_cands': 3.5, 'avg_progress': 0.32, 'rival_range': (6, 10), 'n': 64},
    'D2B':  {'avg_rivals': 6.2, 'avg_cands': 3.2, 'avg_progress': 0.30, 'rival_range': (4, 8), 'n': 40},
    'FPF':  {'avg_rivals': 8.2, 'avg_cands': 3.2, 'avg_progress': 0.29, 'rival_range': (6, 12), 'n': 23},
    'ForcingChain': {'avg_rivals': 6.0, 'avg_cands': 2.0, 'avg_progress': 0.30, 'rival_range': (4, 8), 'n': 1},
    'DeepResonance': {'avg_rivals': 7.0, 'avg_cands': 3.0, 'avg_progress': 0.28, 'rival_range': (5, 10), 'n': 0},
}


def _compute_cell_features(board, candidates, row, col):
    """Compute features for a single cell.

    Args:
        board: 9x9 list of ints (0=empty)
        candidates: 9x9 list of sets
        row, col: cell position

    Returns:
        dict of features
    """
    cands = candidates[row][col]
    if not cands or len(cands) == 0:
        return None

    cell_size = len(cands)

    # Rival scores per candidate
    rival_scores = {}
    for d in cands:
        row_r = sum(1 for j in range(9) if j != col and board[row][j] == 0
                    and d in candidates[row][j])
        col_r = sum(1 for i in range(9) if i != row and board[i][col] == 0
                    and d in candidates[i][col])
        br, bc = (row // 3) * 3, (col // 3) * 3
        box_r = sum(1 for i in range(br, br + 3) for j in range(bc, bc + 3)
                    if (i != row or j != col) and board[i][j] == 0
                    and d in candidates[i][j])
        rival_scores[d] = row_r + col_r + box_r

    # Best candidate (lowest rivals)
    sorted_cands = sorted(rival_scores.items(), key=lambda x: x[1])
    best_d, best_score = sorted_cands[0]
    second_score = sorted_cands[1][1] if len(sorted_cands) > 1 else best_score
    confidence_gap = second_score - best_score

    # Board progress
    filled = sum(1 for i in range(9) for j in range(9) if board[i][j] != 0)
    progress = filled / 81

    # Unit emptiness
    row_empty = sum(1 for j in range(9) if board[row][j] == 0)
    col_empty = sum(1 for i in range(9) if board[i][col] == 0)
    br, bc = (row // 3) * 3, (col // 3) * 3
    box_empty = sum(1 for i in range(br, br + 3) for j in range(bc, bc + 3)
                    if board[i][j] == 0)

    return {
        'cell_size': cell_size,
        'best_digit': best_d,
        'rival_score': best_score,
        'confidence_gap': confidence_gap,
        'progress': round(progress, 3),
        'row_empty': row_empty,
        'col_empty': col_empty,
        'box_empty': box_empty,
        'min_empty': min(row_empty, col_empty, box_empty),
    }


def predict_technique(board, candidates, row, col):
    """Predict which L5+ technique will place this cell.

    Returns:
        dict with 'technique', 'confidence', 'predicted_digit', 'features'
        or None if cell is filled or has 0-1 candidates.
    """
    features = _compute_cell_features(board, candidates, row, col)
    if features is None:
        return None

    rivals = features['rival_score']
    cands = features['cell_size']
    progress = features['progress']

    # Decision tree based on training data
    if cands <= 2:
        # Bivalue cells → simpler techniques or ForcingChain
        technique = 'ForcingChain'
        confidence = 0.5
    elif rivals < 6:
        technique = 'FPC'
        confidence = 0.7
    elif rivals < 7:
        technique = 'D2B'
        confidence = 0.5
    elif progress < 0.30:
        technique = 'FPF'
        confidence = 0.6
    elif rivals >= 8:
        technique = 'FPCE'
        confidence = 0.6
    else:
        technique = 'FPCE'
        confidence = 0.4

    # Boost confidence if features match profile closely
    profile = TECHNIQUE_PROFILES.get(technique, {})
    if profile:
        rival_diff = abs(rivals - profile['avg_rivals'])
        cand_diff = abs(cands - profile['avg_cands'])
        if rival_diff < 1 and cand_diff < 0.5:
            confidence = min(1.0, confidence + 0.2)

    return {
        'technique': technique,
        'confidence': round(confidence, 2),
        'predicted_digit': features['best_digit'],
        'features': features,
    }


def predict_all(board, candidates):
    """Predict techniques for all empty cells with 2+ candidates.

    Returns:
        dict of {(row, col): prediction_result}
    """
    results = {}
    for row in range(9):
        for col in range(9):
            if board[row][col] != 0:
                continue
            if not candidates[row][col] or len(candidates[row][col]) < 2:
                continue
            pred = predict_technique(board, candidates, row, col)
            if pred:
                results[(row, col)] = pred
    return results


def predict_solve_path(board, candidates, solution=None):
    """Predict the full solve path: which cells need which techniques.

    Groups cells by predicted technique and sorts by confidence.

    Returns:
        list of {'cell': 'R1C2', 'digit': 5, 'technique': 'FPC',
                 'confidence': 0.8, 'correct': True/None}
    """
    preds = predict_all(board, candidates)
    path = []
    for (row, col), pred in sorted(preds.items(),
                                     key=lambda x: -x[1]['confidence']):
        entry = {
            'cell': f'R{row + 1}C{col + 1}',
            'pos': row * 9 + col,
            'digit': pred['predicted_digit'],
            'technique': pred['technique'],
            'confidence': pred['confidence'],
        }
        if solution:
            entry['correct'] = pred['predicted_digit'] == solution[row][col]
        path.append(entry)
    return path
