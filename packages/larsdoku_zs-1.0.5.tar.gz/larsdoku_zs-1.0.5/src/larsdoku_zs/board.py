"""Larsdoku — Board: the WSRF Sudoku data structure.

The Board class wraps BitBoard and exposes a Pythonic API for
technique detection, solving, zone intelligence, and GF(2) linear algebra.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field

from .engine import BitBoard, BIT, POPCOUNT, propagate_l1l2, solve_backtrack
from .constants import TECHNIQUE_LEVELS, TECHNIQUE_ALIASES, PRESETS, EXPERT_APPROVED
from .utils import normalize_puzzle, decode_bdp, parse_cell
from .display import format_board


# ══════════════════════════════════════════════════════════════
# DETECT RESULT — what a technique found
# ══════════════════════════════════════════════════════════════

@dataclass
class DetectResult:
    """Result of running a technique detector on a Board."""
    technique: str
    placements: list = field(default_factory=list)   # [(pos, digit, reason), ...]
    eliminations: list = field(default_factory=list)  # [(pos, digit, reason), ...]

    @property
    def found(self):
        return bool(self.placements or self.eliminations)

    def __bool__(self):
        return self.found

    def __repr__(self):
        parts = [f'DetectResult({self.technique!r}']
        if self.placements:
            parts.append(f', {len(self.placements)} placements')
        if self.eliminations:
            parts.append(f', {len(self.eliminations)} eliminations')
        parts.append(')')
        return ''.join(parts)


# ══════════════════════════════════════════════════════════════
# DETECTOR MAP — technique name -> detector function
# ══════════════════════════════════════════════════════════════

def _build_detector_map():
    """Build the technique-to-detector mapping. Lazy import to avoid circular deps."""
    from .engine import (
        detect_fpc_bitwise, detect_fpce_bitwise,
        detect_forcing_chain_bitwise, detect_forcing_net,
        detect_d2b_bitwise, detect_fpf_bitwise,
        detect_xwing, detect_swordfish, detect_simple_coloring,
        detect_bug_plus1, detect_ur_type2, detect_ur_type4,
        detect_junior_exocet, detect_template, detect_bowman_bingo,
        detect_gf2_lanczos, detect_gf2_extended,
        detect_x_cycle_bitwise, detect_als_xz_bitwise,
        detect_sue_de_coq_bitwise, detect_aligned_pair_exclusion_bitwise,
        detect_als_xy_wing_bitwise, detect_death_blossom_bitwise,
        detect_sk_loop_bitwise, detect_kraken_fish_bitwise,
        detect_deep_resonance,
    )

    # Each entry: (detector_func, result_type)
    # result_type: 'placement' = returns [(pos, digit, detail), ...]
    #              'elimination' = returns [(pos, digit), ...]
    #              'both' = returns (placements, eliminations)
    #              'bool' = returns True/False (modifies bb in-place)
    #              'gf2' = returns (placements, eliminations, dof)
    from .gf2_larsxor import detect_gf2_larsxor

    return {
        'FPC': (detect_fpc_bitwise, 'placement'),
        'FPCE': (detect_fpce_bitwise, 'both'),
        'ForcingChain': (detect_forcing_chain_bitwise, 'placement'),
        'ForcingNet': (detect_forcing_net, 'placement'),
        'D2B': (detect_d2b_bitwise, 'placement'),
        'FPF': (detect_fpf_bitwise, 'placement'),
        'XWing': (detect_xwing, 'bool'),
        'Swordfish': (detect_swordfish, 'bool'),
        'SimpleColoring': (detect_simple_coloring, 'sc'),
        'XCycle': (detect_x_cycle_bitwise, 'both'),
        'ALS_XZ': (detect_als_xz_bitwise, 'elimination'),
        'ALS_XYWing': (detect_als_xy_wing_bitwise, 'elimination'),
        'SueDeCoq': (detect_sue_de_coq_bitwise, 'elimination'),
        'AlignedPairExcl': (detect_aligned_pair_exclusion_bitwise, 'elimination'),
        'DeathBlossom': (detect_death_blossom_bitwise, 'elimination'),
        'KrakenFish': (detect_kraken_fish_bitwise, 'elimination'),
        'SKLoop': (detect_sk_loop_bitwise, 'elimination'),
        'BUG+1': (detect_bug_plus1, 'placement'),
        'URType2': (detect_ur_type2, 'ur'),
        'URType4': (detect_ur_type4, 'ur'),
        'JuniorExocet': (detect_junior_exocet, 'ur'),
        'Template': (detect_template, 'both'),
        'BowmanBingo': (detect_bowman_bingo, 'placement'),
        'GF2_Lanczos': (detect_gf2_lanczos, 'gf2'),
        'GF2_XOR': (detect_gf2_larsxor, 'gf2'),
        'DeepResonance': (detect_deep_resonance, 'elimination'),
    }


_DETECTOR_MAP = None


def _get_detector_map():
    global _DETECTOR_MAP
    if _DETECTOR_MAP is None:
        _DETECTOR_MAP = _build_detector_map()
    return _DETECTOR_MAP


def _normalize_technique(name):
    """Resolve a technique name through aliases."""
    low = name.lower()
    if low in TECHNIQUE_ALIASES:
        return TECHNIQUE_ALIASES[low]
    # Direct match
    for tech in TECHNIQUE_LEVELS:
        if tech.lower() == low:
            return tech
    return name


# ══════════════════════════════════════════════════════════════
# BOARD CLASS — the WSRF Sudoku data structure
# ══════════════════════════════════════════════════════════════

class Board:
    """High-level Sudoku board -- accepts bd81 or BDP strings.

    Wraps BitBoard for bitmask-native operations. All candidate state
    is authoritative in the BitBoard; the Board class adds Pythonic access.
    """

    def __init__(self, puzzle):
        """Auto-detect bd81 vs BDP, initialize board + candidates."""
        puzzle = puzzle.strip()
        if len(puzzle) >= 165 and puzzle[:2] in ('S9', 'X9', 'J9'):
            bd81, cand_masks = decode_bdp(puzzle)
            self._bb = BitBoard.from_string(bd81)
            self._given = bd81
            self._bdp_source = puzzle
            # Apply BDP candidate masks
            for i in range(81):
                if cand_masks[i] and self._bb.board[i] == 0:
                    self._bb.cands[i] = cand_masks[i]
        else:
            bd81 = normalize_puzzle(puzzle)
            self._bb = BitBoard.from_string(bd81)
            self._given = bd81
            self._bdp_source = None

    @classmethod
    def from_bdp(cls, bdp_str):
        """Load from BDP with candidate eliminations preserved."""
        return cls(bdp_str)

    @classmethod
    def from_bitboard(cls, bb):
        """Wrap an existing BitBoard."""
        b = object.__new__(cls)
        b._bb = bb
        b._given = ''.join(str(bb.board[i]) if bb.board[i] != 0 else '0' for i in range(81))
        b._bdp_source = None
        return b

    # ── Inspection ──────────────────────────────────────────────

    @property
    def bb(self):
        """Direct access to the underlying BitBoard."""
        return self._bb

    @property
    def grid(self):
        """81-element list of placed digits (0 = empty)."""
        return list(self._bb.board[:81])

    @property
    def empty(self):
        """Count of empty cells."""
        return self._bb.empty

    @property
    def given_str(self):
        """Original puzzle string."""
        return self._given

    def candidates(self, row, col):
        """Get candidate digits for cell (row, col) as a set."""
        pos = row * 9 + col
        mask = self._bb.cands[pos]
        return {d + 1 for d in range(9) if mask & BIT[d]}

    def cand_mask(self, row, col):
        """Raw 9-bit candidate bitmask for cell (row, col)."""
        return self._bb.cands[row * 9 + col]

    @property
    def cand_matrix(self):
        """(9, 9, 9) bool array: [r][c][d-1] = True if digit d is candidate at (r,c)."""
        import numpy as np
        mat = np.zeros((9, 9, 9), dtype=bool)
        for pos in range(81):
            if self._bb.board[pos] != 0:
                continue
            r, c = pos // 9, pos % 9
            for d in range(9):
                if self._bb.cands[pos] & BIT[d]:
                    mat[r, c, d] = True
        return mat

    def __repr__(self):
        bd = ''.join(str(self._bb.board[i]) if self._bb.board[i] != 0 else '0' for i in range(81))
        return format_board(bd, self._given)

    def _repr_html_(self):
        """Rich HTML display for Jupyter notebooks."""
        rows = []
        rows.append('<table style="border-collapse:collapse;font-family:monospace;font-size:14px;">')
        for r in range(9):
            rows.append('<tr>')
            for c in range(9):
                pos = r * 9 + c
                val = self._bb.board[pos]
                border = 'border:1px solid #ccc;'
                if r % 3 == 0:
                    border += 'border-top:2px solid #333;'
                if c % 3 == 0:
                    border += 'border-left:2px solid #333;'
                if r == 8:
                    border += 'border-bottom:2px solid #333;'
                if c == 8:
                    border += 'border-right:2px solid #333;'

                if val != 0:
                    given_val = int(self._given[pos]) if self._given[pos].isdigit() else 0
                    color = '#000' if given_val != 0 else '#0088cc'
                    rows.append(f'<td style="{border}width:40px;height:40px;text-align:center;'
                                f'vertical-align:middle;font-size:20px;font-weight:bold;color:{color};">{val}</td>')
                else:
                    # Show candidates as small text
                    cands = [str(d + 1) for d in range(9) if self._bb.cands[pos] & BIT[d]]
                    cand_str = ''.join(cands) if cands else ''
                    rows.append(f'<td style="{border}width:40px;height:40px;text-align:center;'
                                f'vertical-align:middle;font-size:9px;color:#888;">{cand_str}</td>')
            rows.append('</tr>')
        rows.append('</table>')
        return '\n'.join(rows)

    # ── Techniques ──────────────────────────────────────────────

    def detect(self, technique):
        """Try one technique on the current board state.

        Returns DetectResult or None if technique didn't fire.
        Does NOT modify the board.
        """
        tech_name = _normalize_technique(technique)
        dmap = _get_detector_map()
        if tech_name not in dmap:
            raise ValueError(f'Unknown technique: {technique!r} (resolved to {tech_name!r})')

        detector, rtype = dmap[tech_name]

        # Work on a copy so we don't mutate
        bb_copy = BitBoard.from_string(self.to_bd81())
        # Restore candidate state from original
        for i in range(81):
            bb_copy.cands[i] = self._bb.cands[i]

        if rtype == 'placement':
            hits = detector(bb_copy)
            if hits:
                placements = [(pos, digit, str(det)) for pos, digit, det in hits]
                return DetectResult(technique=tech_name, placements=placements)

        elif rtype == 'elimination':
            elims = detector(bb_copy)
            if elims:
                eliminations = [(pos, d, '') for pos, d in elims]
                return DetectResult(technique=tech_name, eliminations=eliminations)

        elif rtype == 'both':
            result = detector(bb_copy)
            if isinstance(result, tuple) and len(result) == 2:
                p, e = result
                placements = [(pos, digit, str(det)) for pos, digit, det in p] if p else []
                eliminations = [(pos, d, '') for pos, d in e] if e else []
                if placements or eliminations:
                    return DetectResult(technique=tech_name, placements=placements, eliminations=eliminations)

        elif rtype == 'bool':
            # These modify bb in-place and return True/False
            # We need to detect what changed by comparing before/after
            cands_before = [bb_copy.cands[i] for i in range(81)]
            fired = detector(bb_copy)
            if fired:
                eliminations = []
                for pos in range(81):
                    if bb_copy.board[pos] != 0:
                        continue
                    removed = cands_before[pos] & ~bb_copy.cands[pos]
                    for d in range(9):
                        if removed & BIT[d]:
                            eliminations.append((pos, d + 1, ''))
                return DetectResult(technique=tech_name, eliminations=eliminations)

        elif rtype == 'sc':
            elims, detail = detector(bb_copy)
            if elims:
                eliminations = [(pos, d, '') for pos, d in elims]
                return DetectResult(technique=tech_name, eliminations=eliminations)

        elif rtype == 'ur':
            elims, detail = detector(bb_copy)
            if elims:
                eliminations = [(pos, d, '') for pos, d in elims]
                return DetectResult(technique=tech_name, eliminations=eliminations)

        elif rtype == 'gf2':
            p, e, dof = detector(bb_copy)
            placements = [(pos, digit, str(det)) for pos, digit, det in p] if p else []
            eliminations = [(pos, d, '') for pos, d in e] if e else []
            if placements or eliminations:
                return DetectResult(technique=tech_name, placements=placements, eliminations=eliminations)

        return None

    def detect_all(self, level=99):
        """Try all techniques up to `level`, return first hit."""
        dmap = _get_detector_map()
        for tech_name in sorted(dmap.keys(), key=lambda t: TECHNIQUE_LEVELS.get(t, 99)):
            tech_level = TECHNIQUE_LEVELS.get(tech_name, 99)
            if tech_level > level:
                break
            result = self.detect(tech_name)
            if result:
                return result
        return None

    def apply(self, result):
        """Apply a DetectResult to the board (mutates)."""
        if not isinstance(result, DetectResult):
            raise TypeError(f'Expected DetectResult, got {type(result).__name__}')
        for pos, digit, reason in result.eliminations:
            d = digit - 1 if digit >= 1 else digit
            self._bb.cands[pos] &= ~BIT[d]
        for pos, digit, reason in result.placements:
            if self._bb.board[pos] == 0:
                self._bb.place(pos, digit)

    # ── Solving ─────────────────────────────────────────────────

    def solve(self, **kwargs):
        """Solve the puzzle with the full technique pipeline.

        Keyword args:
            exclude: set of technique names to exclude
            only: set of technique names to allow
            preset: preset name ('expert', 'exotic', 'wsrf', etc.)
            max_level: max technique level (1-7)
            gf2: enable GF(2) Block Lanczos
            gf2_extended: enable GF(2) Extended
            verbose: print steps
            detail: capture rich detail

        Returns SolveResult dict.
        """
        from .solver import solve_selective

        bd81 = self.to_bd81()
        solve_kwargs = {}

        # Handle preset
        preset = kwargs.pop('preset', None)
        if preset and preset in PRESETS:
            solve_kwargs['only_techniques'] = PRESETS[preset]

        # Handle only/exclude
        only = kwargs.pop('only', None)
        exclude = kwargs.pop('exclude', None)
        if only is not None:
            resolved = set()
            for t in only:
                resolved.add(_normalize_technique(t))
            solve_kwargs['only_techniques'] = resolved
        if exclude is not None:
            resolved = set()
            for t in exclude:
                resolved.add(_normalize_technique(t))
            solve_kwargs['exclude_techniques'] = resolved

        # Pass through remaining kwargs
        for k in ('max_level', 'verbose', 'detail', 'gf2', 'gf2_extended',
                   'zone_hints', 'dr_mode', 'zone_oracle', 'rule_oracle',
                   'zone135_oracle'):
            if k in kwargs:
                solve_kwargs[k] = kwargs[k]

        result = solve_selective(bd81, **solve_kwargs)

        # Update our board state to match the solved board
        for i in range(81):
            d = int(result['board'][i])
            if d != 0:
                self._bb.board[i] = d

        return result

    def solve_cascade(self, **kwargs):
        """Cascade solver: crack bottleneck moves, propagate, SIRO the rest.

        Uses the full solver but classifies each step:
          - 'bottleneck': L3+ technique placement (the hard move)
          - 'cascade': L1-L2 placement (naked single, crosshatch, etc.)
          - 'siro': SIRO prediction for remaining cells

        Returns dict with:
          - steps: full solve path with 'category' field
          - bottleneck_depth: number of hard technique placements
          - cascade_count: number of L1-L2 placements
          - siro_count: number of SIRO predictions used
          - success: bool
          - bottleneck_moves: list of the hard moves only
        """
        from .solver import solve_selective
        from .siro_boost import siro_predict

        bd81 = self.to_bd81()

        # Solve with the full pipeline to get the technique trace
        solve_kwargs = {}
        for k in ('preset', 'max_level', 'gf2', 'gf2_extended',
                   'dr_mode', 'zone_oracle', 'rule_oracle', 'zone135_oracle'):
            if k in kwargs:
                val = kwargs[k]
                if k == 'preset':
                    from .constants import PRESETS
                    if val in PRESETS:
                        solve_kwargs['only_techniques'] = PRESETS[val]
                else:
                    solve_kwargs[k] = val

        result = solve_selective(bd81, detail=True, **solve_kwargs)

        # Classify each step
        L1_TECHNIQUES = {'crossHatch', 'nakedSingle', 'fullHouse', 'lastRemaining'}
        L2_TECHNIQUES = {'Zone135', 'GF2_Lanczos', 'GF2_Extended', 'GF2_Probe'}
        CASCADE_SET = L1_TECHNIQUES | L2_TECHNIQUES

        bottleneck_moves = []
        cascade_count = 0
        steps_classified = []

        for step in result.get('steps', []):
            tech = step.get('technique', '')
            if tech in CASCADE_SET:
                cat = 'cascade'
                cascade_count += 1
            else:
                cat = 'bottleneck'
                bottleneck_moves.append(step)
            steps_classified.append({**step, 'category': cat})

        # Update board state
        for i in range(81):
            d = int(result['board'][i])
            if d != 0:
                self._bb.board[i] = d

        # Check for remaining empty cells — SIRO predicts those
        siro_steps = []
        remaining = sum(1 for i in range(81) if self._bb.board[i] == 0)
        if remaining > 0 and result.get('stalled'):
            # Board stalled — use SIRO for remaining cells
            preds = siro_predict(self._bb)
            for pos, info in sorted(preds.items()):
                if self._bb.board[pos] == 0:
                    r, c = divmod(pos, 9)
                    siro_steps.append({
                        'pos': pos,
                        'digit': info['digit'],
                        'technique': 'SIRO',
                        'cell': f'R{r+1}C{c+1}',
                        'category': 'siro',
                        'confidence': info.get('confidence', 0),
                        'rival_score': info.get('scores', {}).get(info['digit'], 0),
                    })
            steps_classified.extend(siro_steps)

        # Build cascade_depth map: for each cell, how many bottleneck
        # moves fired BEFORE this cell was placed
        cascade_depth = {}
        bn_so_far = 0
        for step in steps_classified:
            if step['category'] == 'bottleneck':
                bn_so_far += 1
            pos = step.get('pos')
            if pos is not None:
                cascade_depth[pos] = bn_so_far

        return {
            'steps': steps_classified,
            'bottleneck_depth': len(bottleneck_moves),
            'bottleneck_moves': bottleneck_moves,
            'cascade_count': cascade_count,
            'siro_count': len(siro_steps),
            'cascade_depth': cascade_depth,
            'success': result.get('success', False) or remaining == 0,
            'total_steps': len(steps_classified),
            'board': result.get('board', ''),
        }

    def siro_solve(self, max_siro=None, **kwargs):
        """Hybrid solver: techniques crack bottlenecks, SIRO predicts the rest.

        Args:
            max_siro: max SIRO predictions to attempt (None = unlimited)
            **kwargs: passed to solve() for technique selection

        Returns dict with:
            - success: bool
            - bottleneck_depth: number of hard technique placements
            - cascade_count: L1-L2 placements
            - siro_count: SIRO predictions used
            - siro_correct: SIRO predictions that were correct (if solution known)
            - steps: full path with category field
            - board: final board string
        """
        from .siro_boost import siro_predict

        # Get the known solution for correctness tracking
        solution = solve_backtrack(self._given)

        # Work on a copy so we can track everything cleanly
        work = self.copy()

        all_steps = []
        bottleneck_depth = 0
        cascade_count = 0
        siro_count = 0
        siro_correct = 0

        L1_TECHNIQUES = {'crossHatch', 'nakedSingle', 'fullHouse', 'lastRemaining'}
        L2_TECHNIQUES = {'Zone135', 'GF2_Lanczos', 'GF2_Extended', 'GF2_Probe'}
        CASCADE_SET = L1_TECHNIQUES | L2_TECHNIQUES

        # Phase 1: propagate L1+L2 to drain easy placements
        batch = propagate_l1l2(work._bb)
        for pos, digit, tech in batch:
            r, c = divmod(pos, 9)
            cascade_count += 1
            all_steps.append({
                'pos': pos, 'digit': digit, 'technique': tech,
                'cell': f'R{r+1}C{c+1}', 'category': 'cascade',
            })

        # Phase 2: technique + propagate loop
        stalled = False
        while work.empty > 0 and not stalled:
            # Try advanced techniques (L3+)
            hit = work.detect_all(level=kwargs.get('max_level', 99))
            if hit:
                # Apply the technique result
                work.apply(hit)
                for pos, digit, reason in hit.placements:
                    r, c = divmod(pos, 9)
                    tech_name = hit.technique
                    if tech_name in CASCADE_SET:
                        cat = 'cascade'
                        cascade_count += 1
                    else:
                        cat = 'bottleneck'
                        bottleneck_depth += 1
                    all_steps.append({
                        'pos': pos, 'digit': digit, 'technique': tech_name,
                        'cell': f'R{r+1}C{c+1}', 'category': cat,
                        'reason': reason,
                    })
                for pos, digit, reason in hit.eliminations:
                    r, c = divmod(pos, 9)
                    all_steps.append({
                        'pos': pos, 'digit': digit, 'technique': hit.technique,
                        'cell': f'R{r+1}C{c+1}', 'category': 'elimination',
                        'reason': reason,
                    })

                # Propagate after technique application
                batch = propagate_l1l2(work._bb)
                for pos, digit, tech in batch:
                    r, c = divmod(pos, 9)
                    cascade_count += 1
                    all_steps.append({
                        'pos': pos, 'digit': digit, 'technique': tech,
                        'cell': f'R{r+1}C{c+1}', 'category': 'cascade',
                    })
            else:
                # No technique fired — we're stuck, enter SIRO phase
                stalled = True

        # Phase 3: SIRO loop — predict most confident cell, place, propagate, repeat
        while work.empty > 0 and stalled:
            if max_siro is not None and siro_count >= max_siro:
                break

            preds = siro_predict(work._bb)
            if not preds:
                break

            # Sort by rival score ascending (lowest = most confident)
            # scores is list of (digit, score) tuples; first entry is the best
            ranked = []
            for pos, info in preds.items():
                if work._bb.board[pos] != 0:
                    continue
                best_score = info['scores'][0][1]  # score of predicted digit
                ranked.append((best_score, info['confidence'], pos, info))

            if not ranked:
                break

            # Pick the cell with the lowest rival score (most constrained)
            ranked.sort(key=lambda x: (x[0], -x[1]))
            best_score, best_conf, best_pos, best_info = ranked[0]
            digit = best_info['digit']
            r, c = divmod(best_pos, 9)

            # Check correctness if solution is available
            correct = None
            if solution:
                correct = (int(solution[best_pos]) == digit)
                if correct:
                    siro_correct += 1

            siro_count += 1
            all_steps.append({
                'pos': best_pos, 'digit': digit, 'technique': 'SIRO',
                'cell': f'R{r+1}C{c+1}', 'category': 'siro',
                'confidence': best_conf, 'rival_score': best_score,
                'correct': correct,
            })

            # Place the SIRO prediction
            work._bb.place(best_pos, digit)

            # Propagate after SIRO placement
            batch = propagate_l1l2(work._bb)
            for pos, d, tech in batch:
                rr, cc = divmod(pos, 9)
                cascade_count += 1
                all_steps.append({
                    'pos': pos, 'digit': d, 'technique': tech,
                    'cell': f'R{rr+1}C{cc+1}', 'category': 'cascade',
                })

            # After propagation, try techniques again before next SIRO
            stalled = False
            while work.empty > 0 and not stalled:
                hit = work.detect_all(level=kwargs.get('max_level', 99))
                if hit:
                    work.apply(hit)
                    for pos, d, reason in hit.placements:
                        rr, cc = divmod(pos, 9)
                        tech_name = hit.technique
                        if tech_name in CASCADE_SET:
                            cat = 'cascade'
                            cascade_count += 1
                        else:
                            cat = 'bottleneck'
                            bottleneck_depth += 1
                        all_steps.append({
                            'pos': pos, 'digit': d, 'technique': tech_name,
                            'cell': f'R{rr+1}C{cc+1}', 'category': cat,
                            'reason': reason,
                        })
                    for pos, d, reason in hit.eliminations:
                        rr, cc = divmod(pos, 9)
                        all_steps.append({
                            'pos': pos, 'digit': d, 'technique': hit.technique,
                            'cell': f'R{rr+1}C{cc+1}', 'category': 'elimination',
                            'reason': reason,
                        })
                    batch = propagate_l1l2(work._bb)
                    for pos, d, tech in batch:
                        rr, cc = divmod(pos, 9)
                        cascade_count += 1
                        all_steps.append({
                            'pos': pos, 'digit': d, 'technique': tech,
                            'cell': f'R{rr+1}C{cc+1}', 'category': 'cascade',
                        })
                else:
                    stalled = True

        # Update our board state to match the work board
        for i in range(81):
            self._bb.board[i] = work._bb.board[i]
            self._bb.cands[i] = work._bb.cands[i]

        final_board = work.to_bd81()
        success = work.empty == 0

        result = {
            'success': success,
            'bottleneck_depth': bottleneck_depth,
            'cascade_count': cascade_count,
            'siro_count': siro_count,
            'siro_correct': siro_correct,
            'steps': all_steps,
            'board': final_board,
        }

        return result

    def query(self, *args, **kwargs):
        """Query a specific cell's solution path.

        Usage:
            b.query("R3C5")
            b.query(2, 4)   # 0-indexed
        """
        from .solver import query_cell

        if len(args) == 1 and isinstance(args[0], str):
            row, col = parse_cell(args[0])
        elif len(args) == 2:
            row, col = args
        else:
            raise ValueError('query() takes "R3C5" or (row, col)')

        bd81 = self.to_bd81()
        return query_cell(bd81, row, col, **kwargs)

    # ── Board manipulation ──────────────────────────────────────

    def propagate(self):
        """Drain L1+L2 (naked singles + crosshatch). Returns list of placements."""
        batch = propagate_l1l2(self._bb)
        return [(pos, digit, tech) for pos, digit, tech in batch]

    def place(self, row, col, digit):
        """Place a digit at (row, col). Mutates the board."""
        pos = row * 9 + col
        self._bb.place(pos, digit)

    def eliminate(self, row, col, digit):
        """Remove a candidate from (row, col). Mutates the board."""
        pos = row * 9 + col
        self._bb.cands[pos] &= ~BIT[digit - 1]

    def clear_candidates(self):
        """Recompute all candidates from grid constraints (Sudoku rules only)."""
        for pos in range(81):
            if self._bb.board[pos] != 0:
                self._bb.cands[pos] = 0
                continue
            mask = (1 << 9) - 1  # all 9 bits
            for peer in self._bb.peers[pos]:
                d = self._bb.board[peer]
                if d != 0:
                    mask &= ~BIT[d - 1]
            self._bb.cands[pos] = mask

    def set_candidates(self, row, col, cands):
        """Override candidates at (row, col). cands is a set of ints {1..9}."""
        pos = row * 9 + col
        mask = 0
        for d in cands:
            mask |= BIT[d - 1]
        self._bb.cands[pos] = mask

    def scandalous_exocet(self, solution=None, **kwargs):
        """ScandolousExocet: post-solve validated Exocet pattern scan.

        Solves the puzzle first (pure logic), then checks if any Exocet
        patterns on the ORIGINAL board are valid by verifying target
        answers against the solved board. 100% accurate.

        Args:
            solution: 81-char solution string (if None, solves internally)

        Returns list of validated Exocet patterns, each a dict with:
            detail, base_digits, targets, eliminations, valid (bool)
        """
        from .engine import detect_junior_exocet, iter_bits9

        # Get solution if not provided
        if solution is None:
            result = self.solve(**kwargs)
            solution = result.get('board', '')
            if not solution or '0' in solution:
                return []

        # Scan original board for Exocet patterns
        orig_bb = BitBoard.from_string(self.given_str)
        je_result = detect_junior_exocet(orig_bb)
        if not je_result or not je_result[0]:
            return []

        elims = je_result[0]
        detail = je_result[1]

        try:
            base_str = detail.split('base {')[1].split('}')[0]
            base_digits = set(int(d) for d in base_str.split(','))
            target_part = detail.split('targets ')[1]
            t_cells = target_part.split(',')
            t1r = int(t_cells[0][1]) - 1
            t1c = int(t_cells[0][3]) - 1
            t2r = int(t_cells[1][1]) - 1
            t2c = int(t_cells[1][3]) - 1
            t1_answer = int(solution[t1r * 9 + t1c])
            t2_answer = int(solution[t2r * 9 + t2c])
            valid = t1_answer in base_digits and t2_answer in base_digits
        except Exception:
            return []

        return [{
            'detail': detail,
            'base_digits': base_digits,
            'targets': [(t1r, t1c, t1_answer), (t2r, t2c, t2_answer)],
            'eliminations': elims,
            'valid': valid,
            'technique': 'ScandolousExocet',
        }]

    @staticmethod
    def forge_permute(bd81, count=10):
        """Constellation Forge: generate unique puzzles via digit permutation.

        Takes a unique puzzle, permutes digits 1-9, returns up to 362,880
        unique puzzles. Every permutation preserves the constraint structure.

        Args:
            bd81: 81-char unique puzzle string
            count: how many to generate (max 362,880)

        Returns list of unique puzzle strings.
        """
        import itertools, random
        from .engine import solve_backtrack, has_unique_solution

        sol = solve_backtrack(bd81.replace('.', '0'))
        if not sol:
            return []

        mask = [i for i in range(81) if bd81[i] not in ('0', '.')]
        results = []
        seen = set()

        perms = list(itertools.permutations(range(1, 10)))
        random.shuffle(perms)

        for perm in perms:
            if len(results) >= count:
                break
            digit_map = {i+1: perm[i] for i in range(9)}
            puzzle = ['0'] * 81
            for pos in mask:
                puzzle[pos] = str(digit_map[int(sol[pos])])
            puzzle_str = ''.join(puzzle)
            if puzzle_str in seen:
                continue
            seen.add(puzzle_str)
            if has_unique_solution(puzzle_str):
                results.append(puzzle_str)

        return results

    # ── Zone intelligence ───────────────────────────────────────

    def compute_zones(self, **kwargs):
        """Compute WSRF zone likely map."""
        from .wsrf_zone import compute_likely_map
        return compute_likely_map(self._bb, **kwargs)

    def siro_predict(self):
        """Run SIRO cross-digit prediction."""
        from .siro_boost import siro_predict
        return siro_predict(self._bb)

    def siro_bootstrap(self, **kwargs):
        """Run SIRO bootstrap solver."""
        from .solver import solve_siro_bootstrap
        return solve_siro_bootstrap(self.to_bd81(), **kwargs)

    def predict_path(self, solution=None):
        """Predict which L5+ technique will place each empty cell.

        Returns list of dicts with cell, digit, technique, confidence.
        If solution provided, includes correctness check.
        """
        from .technique_predictor import predict_solve_path
        board_2d = [[0]*9 for _ in range(9)]
        cands_2d = [[set() for _ in range(9)] for _ in range(9)]
        for r in range(9):
            for c in range(9):
                pos = r*9+c
                board_2d[r][c] = self._bb.board[pos]
                if board_2d[r][c] == 0:
                    cands_2d[r][c] = set(d+1 for d in range(9) if self._bb.cands[pos] & BIT[d])
        sol_2d = None
        if solution:
            sol_2d = [[int(solution[r*9+c]) for c in range(9)] for r in range(9)]
        return predict_solve_path(board_2d, cands_2d, solution=sol_2d)

    def predict_cell(self, row, col):
        """Predict which technique will place a specific cell.

        Returns dict with technique, confidence, predicted_digit, features.
        """
        from .technique_predictor import predict_technique
        board_2d = [[0]*9 for _ in range(9)]
        cands_2d = [[set() for _ in range(9)] for _ in range(9)]
        for r in range(9):
            for c in range(9):
                pos = r*9+c
                board_2d[r][c] = self._bb.board[pos]
                if board_2d[r][c] == 0:
                    cands_2d[r][c] = set(d+1 for d in range(9) if self._bb.cands[pos] & BIT[d])
        return predict_technique(board_2d, cands_2d, row, col)

    def gf2(self, return_residual=False):
        """Run GF(2) XOR-accelerated (box-block + two-phase Schur). Returns DetectResult.
        If return_residual=True, result also has .free_cells and .skip_digits."""
        from .gf2_larsxor import detect_gf2_larsxor
        if return_residual:
            p, e, dof, free_cells, skip_digits = detect_gf2_larsxor(self._bb, return_residual=True)
        else:
            p, e, dof = detect_gf2_larsxor(self._bb)
        placements = [(pos, digit, f'dof={dof}') for pos, digit, tech in p] if p else []
        eliminations = [(pos, d, f'dof={dof}') for pos, d in e] if e else []
        r = DetectResult(technique='GF2_XOR', placements=placements, eliminations=eliminations)
        r.dof = dof
        if return_residual:
            r.free_cells = free_cells
            r.skip_digits = skip_digits
        return r

    def gf2_xor(self):
        """Run GF(2) XOR-Friendly (box-block + two-phase Schur). Returns DetectResult."""
        from .gf2_larsxor import detect_gf2_larsxor
        p, e, dof = detect_gf2_larsxor(self._bb)
        placements = [(pos, digit, f'dof={dof}') for pos, digit, tech in p] if p else []
        eliminations = [(pos, d, f'dof={dof}') for pos, d in e] if e else []
        return DetectResult(technique='GF2_XOR', placements=placements, eliminations=eliminations)

    def gf2_extended(self, **kwargs):
        """Run GF(2) Extended with probing. Returns DetectResult."""
        from .engine import detect_gf2_extended
        p, e, dof, contradiction, stats = detect_gf2_extended(self._bb, **kwargs)
        placements = [(pos, digit, f'dof={dof}') for pos, digit, tech in p] if p else []
        eliminations = [(pos, d, f'dof={dof}') for pos, d in e] if e else []
        return DetectResult(technique='GF2_Extended', placements=placements, eliminations=eliminations)

    def analyze(self):
        """Full board analysis: candidates, zones, technique forecast."""
        analysis = {
            'empty': self.empty,
            'total_candidates': sum(POPCOUNT[self._bb.cands[p]] for p in range(81) if self._bb.board[p] == 0),
            'bivalue_cells': sum(1 for p in range(81) if self._bb.board[p] == 0 and POPCOUNT[self._bb.cands[p]] == 2),
        }
        # Average candidates per empty cell
        if self.empty > 0:
            analysis['avg_candidates'] = round(analysis['total_candidates'] / self.empty, 2)
        else:
            analysis['avg_candidates'] = 0
        return analysis

    # ── Utility ─────────────────────────────────────────────────

    def copy(self):
        """Deep copy for experimentation."""
        b = object.__new__(Board)
        b._bb = BitBoard.from_string(self.to_bd81())
        # Copy candidate state
        for i in range(81):
            b._bb.cands[i] = self._bb.cands[i]
        b._given = self._given
        b._bdp_source = self._bdp_source
        return b

    def to_bd81(self):
        """Export current state as bd81 string."""
        return ''.join(str(self._bb.board[i]) if self._bb.board[i] != 0 else '0' for i in range(81))

    def to_bdp(self):
        """Pack current state to BDP string (preserves candidate state)."""
        header = 'S9B'
        pairs = []
        for i in range(81):
            val = self._bb.board[i]
            if val != 0:
                # Check if it was a given
                given_val = int(self._given[i]) if self._given[i].isdigit() else 0
                if given_val != 0:
                    bdp_val = val  # 1-9 = given
                else:
                    bdp_val = val + 9  # 10-18 = solved
            else:
                # Encode candidate bitmask
                bdp_val = self._bb.cands[i] + 18  # 19-529
            # Convert to 2-char base-36
            high = bdp_val // 36
            low = bdp_val % 36
            def _b36(n):
                if n < 10:
                    return str(n)
                return chr(ord('A') + n - 10)
            pairs.append(_b36(high) + _b36(low))
        return header + ''.join(pairs)

    def bdp_info(self):
        """Return info about the current board state."""
        n_given = sum(1 for i in range(81) if self._given[i].isdigit() and int(self._given[i]) != 0)
        n_solved = sum(1 for i in range(81)
                      if self._bb.board[i] != 0 and (not self._given[i].isdigit() or int(self._given[i]) == 0))
        n_empty = self.empty
        total_cands = sum(POPCOUNT[self._bb.cands[i]] for i in range(81) if self._bb.board[i] == 0)
        return {
            'n_given': n_given,
            'n_solved': n_solved,
            'n_empty': n_empty,
            'total_candidates': total_cands,
            'avg_candidates': round(total_cands / max(1, n_empty), 2),
        }
