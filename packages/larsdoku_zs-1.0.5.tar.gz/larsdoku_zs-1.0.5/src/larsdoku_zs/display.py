"""Larsdoku — Display and formatting utilities."""
from __future__ import annotations

from .constants import TECHNIQUE_LEVELS, WSRF_INVENTIONS


# ══════════════════════════════════════════════════════════════
# BOARD DISPLAY
# ══════════════════════════════════════════════════════════════

def format_board(board_str, given_str=None):
    """Pretty-print a 9x9 Sudoku board."""
    lines = []
    lines.append('\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u252c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u252c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510')
    for r in range(9):
        row = '\u2502'
        for c in range(9):
            pos = r * 9 + c
            d = board_str[pos]
            if d == '0' or d == '.':
                row += ' .'
            elif given_str and (given_str[pos] != '0' and given_str[pos] != '.'):
                row += f' {d}'  # given
            else:
                row += f' {d}'
            if c % 3 == 2:
                row += ' \u2502'
        lines.append(row)
        if r % 3 == 2 and r < 8:
            lines.append('\u251c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u253c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2524')
    lines.append('\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518')
    return '\n'.join(lines)


# ══════════════════════════════════════════════════════════════
# SOLVE SUMMARY
# ══════════════════════════════════════════════════════════════

def format_summary(result, elapsed_ms):
    """Format solve summary."""
    lines = []
    status = 'SOLVED' if result['success'] else ('STALLED' if result.get('stalled') else 'FAILED')
    lines.append(f'Status: {status}')
    lines.append(f'Steps:  {result["n_steps"]}')
    lines.append(f'Time:   {elapsed_ms:.1f}ms')
    if result.get('empty_remaining', 0) > 0:
        lines.append(f'Empty:  {result["empty_remaining"]} cells remaining')

    tc = result['technique_counts']
    wsrf_used = WSRF_INVENTIONS & set(tc.keys())
    oracle_used = 'ORACLE_ONLY' in tc
    tags = []
    if wsrf_used:
        tags.append(f'WSRF:   {", ".join(sorted(wsrf_used))}')
    if oracle_used:
        tags.append(f'Oracle: {tc["ORACLE_ONLY"]} oracle placement{"s" if tc["ORACLE_ONLY"] != 1 else ""} (not pure logic)')
    if tags:
        for t in tags:
            lines.append(t)
    elif result['success']:
        lines.append('Verify: All techniques are Sudoku Expert Approved')
    else:
        lines.append('Verify: Pure logic -- stalled (selected techniques insufficient)')

    lines.append('')
    lines.append('Techniques:')
    total = sum(tc.values())
    for tech, count in sorted(tc.items(), key=lambda x: -x[1]):
        pct = count / total * 100 if total else 0
        lvl = TECHNIQUE_LEVELS.get(tech, '?')
        bar = '#' * max(1, int(pct / 3))
        tag = ' *' if tech in WSRF_INVENTIONS else (' !' if tech == 'ORACLE_ONLY' else '')
        lines.append(f'  {tech:20s}  {count:4d} ({pct:5.1f}%)  L{lvl}  {bar}{tag}')

    return '\n'.join(lines)


# ══════════════════════════════════════════════════════════════
# DETAILED OUTPUT
# ══════════════════════════════════════════════════════════════

def _cell_name(pos):
    return f'R{pos // 9 + 1}C{pos % 9 + 1}'


def format_detail(result):
    """Format rich round-by-round detailed output."""
    lines = []
    steps = result.get('steps', [])
    elim_events = result.get('elim_events', [])

    # Index elimination events by round
    elim_by_round = {}
    for ev in elim_events:
        rnd = ev['round']
        elim_by_round.setdefault(rnd, []).append(ev)

    # Group steps by round
    rounds = {}
    for s in steps:
        rnd = s.get('round', 1)
        rounds.setdefault(rnd, []).append(s)

    all_rounds = sorted(set(list(rounds.keys()) + list(elim_by_round.keys())))

    for rnd in all_rounds:
        lines.append(f'Round {rnd}')

        if rnd in elim_by_round:
            for ev in elim_by_round[rnd]:
                tech = ev['technique']
                elims = ev.get('eliminations', [])
                wsrf_tag = ' *' if tech in WSRF_INVENTIONS else ''
                lines.append(f'  {tech} {len(elims)} elimination{"s" if len(elims) != 1 else ""}{wsrf_tag}')
                by_cell = {}
                for pos, d in elims:
                    by_cell.setdefault(pos, []).append(d + 1 if d < 9 else d)
                elim_parts = []
                for pos in sorted(by_cell):
                    digits = ','.join(str(d) for d in sorted(by_cell[pos]))
                    elim_parts.append(f'{_cell_name(pos)}: {digits}')
                if elim_parts:
                    if len(elim_parts) <= 8:
                        lines.append(f'    {" | ".join(elim_parts)}')
                    else:
                        lines.append(f'    {" | ".join(elim_parts[:6])} ... +{len(elim_parts)-6} more')
                detail_text = ev.get('detail', '')
                if detail_text:
                    lines.append(f'    {detail_text}')

        if rnd in rounds:
            for s in rounds[rnd]:
                tech = s['technique']
                cell = s['cell']
                digit = s['digit']
                wsrf_tag = ' *' if tech in WSRF_INVENTIONS else ''
                cands = s.get('cands_before', [])
                cands_str = ' '.join(str(c) for c in cands) if cands else ''

                if cands_str:
                    lines.append(f'  {tech} {cell} = {digit}{wsrf_tag}')
                    lines.append(f'    Notes before: {cands_str} -> placed {digit}')
                else:
                    lines.append(f'  {tech} {cell} = {digit}{wsrf_tag}')

                explanation = s.get('explanation', '')
                if explanation:
                    lines.append(f'    {explanation}')

    return '\n'.join(lines)


# ══════════════════════════════════════════════════════════════
# BENCHMARK DISPLAY
# ══════════════════════════════════════════════════════════════

def format_benchmark(bench, preset_label=None):
    """Format benchmark results."""
    lines = []
    if preset_label:
        lines.append(f'\n  {preset_label} Techniques')
    lines.append(f'\n{"=" * 60}')
    lines.append(f'BENCHMARK: {bench["count"]} shuffled variants')
    lines.append(f'{"=" * 60}')
    lines.append(f'Solve rate: {bench["solve_rate"]} ({bench["solved"]}/{bench["count"]})')
    if bench['stalled']:
        lines.append(f'Stalled:    {bench["stalled"]}')
    lines.append(f'Avg time:   {bench["avg_time_ms"]:.1f}ms/puzzle')
    lines.append(f'Total time: {bench["total_time_ms"]:.0f}ms')
    lines.append(f'Avg steps:  {bench["avg_steps"]}')
    if bench['avg_oracle']:
        lines.append(f'Avg oracle: {bench["avg_oracle"]} per puzzle')

    wsrf_used = WSRF_INVENTIONS & set(bench['technique_totals'].keys())
    oracle_used = 'ORACLE_ONLY' in bench['technique_totals']
    if not wsrf_used and not oracle_used and bench['solved'] == bench['count']:
        lines.append('Verify:     All techniques are Sudoku Expert Approved')
    elif wsrf_used:
        lines.append(f'WSRF:       {", ".join(sorted(wsrf_used))}')

    lines.append(f'\nTechnique Averages (per puzzle):')
    ta = bench['technique_averages']
    total_avg = sum(ta.values())
    for tech, avg in sorted(ta.items(), key=lambda x: -x[1]):
        pct = avg / total_avg * 100 if total_avg else 0
        lvl = TECHNIQUE_LEVELS.get(tech, '?')
        bar = '#' * max(1, int(pct / 3))
        tag = ' *' if tech in WSRF_INVENTIONS else (' !' if tech == 'ORACLE_ONLY' else '')
        lines.append(f'  {tech:20s}  {avg:6.2f} ({pct:5.1f}%)  L{lvl}  {bar}{tag}')

    lines.append(f'{"=" * 60}')
    return '\n'.join(lines)
