#!/usr/bin/env python3
"""
GF(2) XOR-Friendly Matrix Rearrangement — Test Suite
=====================================================

Verifies:
1. Correctness: XOR-friendly results match original GF(2) results exactly
2. Structure: box-block ordering produces correct variable grouping
3. Null space: fast null space matches board_forge version
4. Performance: benchmarks original vs XOR-friendly vs null space

Author: Sir Lars (WSRF) — March 2026
"""

import sys
import os
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from larsdoku_zs.engine import BitBoard, detect_gf2_lanczos, BIT, BOX_OF, UNITS
from larsdoku_zs.gf2_xor import (
    _box_block_reorder, build_xor_system, two_phase_eliminate,
    detect_gf2_xor, detect_gf2_xor_extended,
    gf2_null_space_fast, benchmark_xor, benchmark_null_space,
    _phase2_with_probe, _compute_free_cells,
)
from larsdoku_zs.engine import _gf2_extract_results
from larsdoku_zs.board_forge import gf2_null_space_dimension


# ══════════════════════════════════════════════════════════════
# TEST PUZZLES
# ══════════════════════════════════════════════════════════════

EASY = [
    "003020600900305001001806400008102900700000008006708200002609500800203009005010300",
    "530070000600195000098000060800060003400803001700020006060000280000419005000080079",
    "000260701680070090190004500820100040004602900050003028009300074040050036703018000",
]

MEDIUM = [
    "000000010400000000020000000000050407008000300001090000300400200050100000000806000",
    "020000000000600003074080000000003002080000060400500000000010780500009000000000040",
]

HARD = [
    "000000001090000050000700008000060000009500800000003000000080000004000000800000004",
    "100007090030020008009600500005300900010080002600004000300000010040000007007000300",
]

# Top1465 entries (notoriously hard)
TOP1465 = [
    "000000010400000000020000000000050407008000300001090000300400200050100000000806000",
    "000000010400000000020000000000050604008000300001090000300400200050100000000807000",
    "000000012000035000000600070700000300000400800100000000000120000080000040050003600",
]

ALL_PUZZLES = EASY + MEDIUM + HARD + TOP1465


# ══════════════════════════════════════════════════════════════
# TEST 1: Box-block variable ordering
# ══════════════════════════════════════════════════════════════

def test_01_box_block_ordering():
    """STRUCTURE: Variables are correctly grouped by box."""
    print("TEST 01: Box-block variable ordering...")

    for puzzle in ALL_PUZZLES[:3]:
        bb = BitBoard.from_string(puzzle)
        var_map, var_idx, box_bounds = _box_block_reorder(bb)

        # Every variable should be in exactly one box range
        for i, (pos, digit) in enumerate(var_map):
            bi = BOX_OF[pos]
            start, end = box_bounds[bi]
            assert start <= i < end, (
                f"Variable {i} (pos={pos}, d={digit}) is in box {bi} "
                f"but index {i} not in [{start}, {end})")

        # Box bounds should be contiguous and cover all variables
        assert box_bounds[0][0] == 0
        for bi in range(8):
            assert box_bounds[bi][1] == box_bounds[bi + 1][0]
        assert box_bounds[8][1] == len(var_map)

        # var_idx should be consistent
        for i, (pos, digit) in enumerate(var_map):
            assert var_idx[(pos, digit)] == i

    print(f"  PASS: Box-block ordering verified on {3} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 2: Constraint partitioning
# ══════════════════════════════════════════════════════════════

def test_02_constraint_partitioning():
    """STRUCTURE: Box constraints are truly box-local."""
    print("TEST 02: Constraint partitioning (box-local vs cross-box)...")

    for puzzle in ALL_PUZZLES[:3]:
        bb = BitBoard.from_string(puzzle)
        (box_con, cross_con, var_map, var_idx,
         box_bounds, n_vars, rhs_bit) = build_xor_system(bb)

        var_mask = (1 << n_vars) - 1

        # Each box constraint should only have bits in its box's variable range
        for bi in range(9):
            start, end = box_bounds[bi]
            box_mask = 0
            for col in range(start, end):
                box_mask |= 1 << col

            for row in box_con[bi]:
                var_bits = row & var_mask
                outside = var_bits & ~box_mask
                assert outside == 0, (
                    f"Box {bi} constraint has bits outside [{start},{end}): "
                    f"outside bits = {bin(outside)}")

        # Cross constraints should span at least 2 boxes (or be trivial)
        for row in cross_con:
            var_bits = row & var_mask
            if var_bits == 0:
                continue
            boxes_touched = set()
            for bi in range(9):
                start, end = box_bounds[bi]
                for col in range(start, end):
                    if var_bits & (1 << col):
                        boxes_touched.add(bi)
            # Most cross constraints touch 2-3 boxes; some may touch 1
            # (when a row/col digit is confined to one box — which is a
            # duplicate of a box constraint, but still valid)

    print(f"  PASS: Box constraints are box-local on {3} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 3: Correctness — same results as original
# ══════════════════════════════════════════════════════════════

def test_03_correctness():
    """CORRECTNESS: XOR-friendly extractions are all correct.

    Different variable orderings produce different (but equally valid) pivot
    decompositions. The DoF must match (rank invariance), and every extracted
    placement/elimination must be verifiably correct against the true solution.
    """
    print("TEST 03: Correctness — verify XOR results against backtrack solution...")

    from larsdoku_zs.engine import solve_backtrack

    wrong_placements = 0
    wrong_eliminations = 0
    dof_mismatches = 0
    total_placements = 0
    total_eliminations = 0

    for puzzle in ALL_PUZZLES:
        bb = BitBoard.from_string(puzzle)
        solution = solve_backtrack(puzzle)
        if not solution:
            continue
        sol = [int(ch) for ch in solution]

        p_old, e_old, dof_old = detect_gf2_lanczos(bb)
        p_new, e_new, dof_new = detect_gf2_xor(bb)

        # DoF must match (rank is invariant)
        if dof_old != dof_new:
            print(f"  FAIL: DoF mismatch for {puzzle[:20]}...")
            print(f"    Original: {dof_old}, XOR: {dof_new}")
            dof_mismatches += 1

        # Every XOR placement must be correct
        for pos, digit, _ in p_new:
            total_placements += 1
            if sol[pos] != digit:
                print(f"  FAIL: Wrong placement at pos {pos}: "
                      f"placed {digit}, answer is {sol[pos]}")
                wrong_placements += 1

        # Every XOR elimination must be correct (removed candidate != answer)
        for pos, digit in e_new:
            total_eliminations += 1
            if sol[pos] == digit:
                print(f"  FAIL: Wrong elimination at pos {pos}: "
                      f"eliminated {digit} but it's the answer!")
                wrong_eliminations += 1

    if dof_mismatches or wrong_placements or wrong_eliminations:
        print(f"  FAIL: {dof_mismatches} DoF mismatches, "
              f"{wrong_placements} wrong placements, "
              f"{wrong_eliminations} wrong eliminations")
        return False

    print(f"  PASS: {total_placements} placements + {total_eliminations} eliminations "
          f"verified correct across {len(ALL_PUZZLES)} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 4: Null space — fast version matches board_forge
# ══════════════════════════════════════════════════════════════

def test_04_null_space():
    """CORRECTNESS: Fast null space matches board_forge version."""
    print("TEST 04: Null space — fast vs board_forge...")

    for puzzle in ALL_PUZZLES:
        v_old, r_old, d_old = gf2_null_space_dimension(puzzle)
        v_new, r_new, d_new = gf2_null_space_fast(puzzle)

        if v_old != v_new or r_old != r_new or d_old != d_new:
            print(f"  FAIL: Null space mismatch for {puzzle[:20]}...")
            print(f"    board_forge: vars={v_old}, rank={r_old}, null={d_old}")
            print(f"    fast:        vars={v_new}, rank={r_new}, null={d_new}")
            return False

    print(f"  PASS: {len(ALL_PUZZLES)}/{len(ALL_PUZZLES)} puzzles match")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 5: Two-phase structure stats
# ══════════════════════════════════════════════════════════════

def test_05_two_phase_stats():
    """INFO: Show the two-phase structure decomposition."""
    print("TEST 05: Two-phase structure analysis...")

    for puzzle in HARD[:1] + TOP1465[:1]:
        bb = BitBoard.from_string(puzzle)
        (box_con, cross_con, var_map, var_idx,
         box_bounds, n_vars, rhs_bit) = build_xor_system(bb)

        box_sizes = [end - start for start, end in box_bounds]
        n_box_con = sum(len(bc) for bc in box_con)
        n_cross_con = len(cross_con)

        print(f"  Puzzle: {puzzle[:20]}...")
        print(f"    Variables: {n_vars}")
        print(f"    Box sizes: {box_sizes} (avg {sum(box_sizes)/9:.1f})")
        print(f"    Box constraints: {n_box_con} (phase 1)")
        print(f"    Cross constraints: {n_cross_con} (phase 2)")
        print(f"    Block-diagonal ratio: {n_box_con / (n_box_con + n_cross_con):.1%}")

    return True


# ══════════════════════════════════════════════════════════════
# TEST 6: Performance benchmark
# ══════════════════════════════════════════════════════════════

def test_06_benchmark():
    """BENCHMARK: Compare original vs XOR-friendly performance."""
    print("TEST 06: Performance benchmark...")

    n_runs = 200

    for label, puzzles in [("Easy", EASY[:1]), ("Hard", HARD[:1]), ("Top1465", TOP1465[:1])]:
        for puzzle in puzzles:
            result = benchmark_xor(puzzle, n_runs=n_runs)
            print(f"  {label}: original={result['original_us']:.0f}us  "
                  f"xor={result['xor_us']:.0f}us  "
                  f"speedup={result['speedup']:.2f}x  "
                  f"vars={result['n_vars']}  dof={result['dof']}  "
                  f"match={result['placements_match'] and result['eliminations_match']}")

    return True


def test_07_null_space_benchmark():
    """BENCHMARK: Compare null space performance."""
    print("TEST 07: Null space benchmark...")

    n_runs = 100
    for puzzle in HARD[:1] + TOP1465[:1]:
        result = benchmark_null_space(puzzle, n_runs=n_runs)
        print(f"  {puzzle[:20]}...  "
              f"original={result['original_us']:.0f}us  "
              f"fast={result['fast_us']:.0f}us  "
              f"speedup={result['speedup']:.2f}x  "
              f"vars={result['n_vars']}  rank={result['rank']}  "
              f"match={result['vars_match'] and result['rank_match']}")

    return True


# ══════════════════════════════════════════════════════════════
# TEST 8: Box-aware probing gives identical results to flat probing
# ══════════════════════════════════════════════════════════════

def test_08_box_aware_probing():
    """CORRECTNESS: Box-aware cached probing matches flat probing results."""
    print("TEST 08: Box-aware probing — cached Phase 1 vs flat elimination...")

    from larsdoku_zs.engine import solve_backtrack
    from larsdoku_zs.gf2_xor import _gf2_eliminate_bigint

    for puzzle in HARD + TOP1465[:2]:
        bb = BitBoard.from_string(puzzle)
        solution = solve_backtrack(puzzle)
        if not solution:
            continue
        sol = [int(ch) for ch in solution]

        (box_con, cross_con, var_map, var_idx,
         box_bounds, n_vars, rhs_bit) = build_xor_system(
            bb, add_conjugates=True, add_band_stack=True)

        if n_vars == 0:
            continue

        # Get cached intermediates
        pivots, free_vars, M, n_words, contradiction, p1_cache, cc_cache = \
            two_phase_eliminate(box_con, cross_con, n_vars, box_bounds,
                               return_intermediates=True)

        if not free_vars or len(free_vars) > 20:
            continue

        # Flatten for comparison
        aug_flat = []
        for bi_rows in box_con:
            aug_flat.extend(bi_rows)
        aug_flat.extend(cross_con)

        tech = 'GF2_XOR_Ext'
        mismatches = 0

        for fv in sorted(list(free_vars)[:5]):  # Test first 5 free vars
            for val in (0, 1):
                if val == 0:
                    probe_row = 1 << fv
                else:
                    probe_row = (1 << fv) | (1 << n_vars)

                # Box-aware (cached Phase 1)
                bp, bfv, bM, bnw, b_contra = _phase2_with_probe(
                    p1_cache, cc_cache, probe_row, n_vars)
                b_place, b_elim, _ = _gf2_extract_results(
                    bp, bfv, bM, n_vars, bnw, var_map, tech)

                # Flat (full elimination from scratch)
                rows_flat = list(aug_flat) + [probe_row]
                fpiv, ffv = _gf2_eliminate_bigint(rows_flat, n_vars)
                n_w = (n_vars + 64) >> 6
                fM = np.zeros((max(len(rows_flat), 1), n_w), dtype=np.uint64)
                _MK = (1 << 64) - 1
                for i, ri in enumerate(rows_flat):
                    for w in range(n_w):
                        fM[i, w] = np.uint64((ri >> (w << 6)) & _MK)
                f_place, f_elim, f_contra = _gf2_extract_results(
                    fpiv, ffv, fM, n_vars, n_w, var_map, tech)

                # Compare: every box-aware result must be correct
                for pos, digit, _ in b_place:
                    if sol[pos] != digit:
                        print(f"  FAIL: Box-aware probe fv={fv} val={val} "
                              f"wrong placement {pos}={digit} (answer={sol[pos]})")
                        mismatches += 1
                for pos, digit in b_elim:
                    if sol[pos] == digit:
                        print(f"  FAIL: Box-aware probe fv={fv} val={val} "
                              f"wrong elimination {pos}:{digit} is the answer!")
                        mismatches += 1

                # Contradiction agreement
                if b_contra != f_contra:
                    print(f"  WARN: Contradiction mismatch fv={fv} val={val}: "
                          f"box-aware={b_contra}, flat={f_contra}")

        if mismatches:
            print(f"  FAIL: {mismatches} mismatches for {puzzle[:20]}...")
            return False

    print(f"  PASS: Box-aware probing verified correct on {len(HARD) + 2} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 9: Silent GF2 preserves L4+ technique profile
# ══════════════════════════════════════════════════════════════

def test_09_silent_gf2():
    """CORRECTNESS: gf2_silent=True doesn't pollute technique_counts."""
    print("TEST 09: Silent GF2 — technique profile preservation...")

    from larsdoku_zs.solver import solve_selective

    gf2_techs = {'GF2_Lanczos', 'GF2_XOR', 'GF2_Extended', 'GF2_Probe',
                 'GF2_XOR_Ext', 'GF2_XOR_Probe'}

    for puzzle in HARD + TOP1465[:2]:
        # Solve with silent GF2
        result = solve_selective(puzzle, gf2_silent=True)
        techs = result.get('technique_counts', {})

        # Silent GF2 should NOT appear in technique_counts
        gf2_in_counts = gf2_techs & set(techs.keys())
        if gf2_in_counts:
            print(f"  FAIL: gf2_silent leaked into technique_counts: {gf2_in_counts}")
            print(f"    Puzzle: {puzzle[:20]}...")
            return False

        # Should still solve (or at least get as far as without GF2)
        ref = solve_selective(puzzle)
        # Silent GF2 should solve at least as many cells
        if result['empty_remaining'] > ref['empty_remaining']:
            print(f"  FAIL: gf2_silent solved fewer cells ({result['empty_remaining']} vs {ref['empty_remaining']})")
            return False

    print(f"  PASS: gf2_silent keeps technique_counts clean on {len(HARD) + 2} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# TEST 10: return_residual API returns valid free_cells data
# ══════════════════════════════════════════════════════════════

def test_10_return_residual():
    """CORRECTNESS: return_residual=True gives valid free_cells + skip_digits."""
    print("TEST 10: return_residual API — free_cells and skip_digits...")

    from larsdoku_zs.engine import solve_backtrack

    for puzzle in ALL_PUZZLES:
        bb = BitBoard.from_string(puzzle)
        solution = solve_backtrack(puzzle)
        if not solution:
            continue
        sol = [int(ch) for ch in solution]

        p, e, dof, free_cells, skip_digits = detect_gf2_xor(bb, return_residual=True)

        # skip_digits must be a 9-bit mask
        if skip_digits < 0 or skip_digits > 0x1FF:
            print(f"  FAIL: skip_digits out of range: {skip_digits}")
            return False

        # free_cells positions must be empty cells
        for pos, mask in free_cells.items():
            if bb.board[pos] != 0:
                print(f"  FAIL: free_cells contains filled cell {pos}")
                return False
            # mask must be a subset of the cell's candidates
            if mask & ~bb.cands[pos]:
                print(f"  FAIL: free_cells mask {bin(mask)} exceeds cands {bin(bb.cands[pos])} at {pos}")
                return False

        # skip_digits and free_cells must be consistent:
        # a digit in skip_digits should have NO free vars for that digit
        for d in range(9):
            dbit = BIT[d]
            if skip_digits & dbit:
                for pos, mask in free_cells.items():
                    if mask & dbit:
                        print(f"  FAIL: digit {d+1} in skip_digits but has free var at {pos}")
                        return False

        # When dof == 0, skip_digits should be ALL_DIGITS (all determined)
        if dof == 0 and skip_digits != 0x1FF:
            # Only if there are actually empty cells with candidates
            has_vars = any(bb.board[i] == 0 and bb.cands[i] for i in range(81))
            if has_vars and skip_digits != 0x1FF:
                print(f"  FAIL: dof=0 but skip_digits={bin(skip_digits)} != 0x1FF")
                return False

    print(f"  PASS: return_residual verified on {len(ALL_PUZZLES)} puzzles")
    return True


# ══════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("GF(2) XOR-FRIENDLY MATRIX REARRANGEMENT — TEST SUITE")
    print("=" * 60)

    tests = [
        test_01_box_block_ordering,
        test_02_constraint_partitioning,
        test_03_correctness,
        test_04_null_space,
        test_05_two_phase_stats,
        test_06_benchmark,
        test_07_null_space_benchmark,
        test_08_box_aware_probing,
        test_09_silent_gf2,
        test_10_return_residual,
    ]

    passed = 0
    failed = 0
    errors = []

    for test in tests:
        print()
        try:
            result = test()
            if result:
                passed += 1
            else:
                failed += 1
                errors.append(test.__name__)
        except Exception as e:
            failed += 1
            errors.append(f"{test.__name__}: {e}")
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()

    print()
    print("=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(tests)} tests")
    if errors:
        print(f"FAILURES: {', '.join(errors)}")
    else:
        print("ALL TESTS PASSED — XOR-FRIENDLY GF(2) VERIFIED")
    print("=" * 60)

    return failed == 0


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
