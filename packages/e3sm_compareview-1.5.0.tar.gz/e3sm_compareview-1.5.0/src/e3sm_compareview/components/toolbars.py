import asyncio

from trame.app import asynchronous
from trame.decorators import change
from trame.widgets import client, html
from trame.widgets import vuetify3 as v3

from e3sm_compareview.comparison import COMPARISON_TYPES, COMPARISON_TYPE_LABELS
from e3sm_quickview.components.toolbars import Layout as Layout
from e3sm_quickview.utils import js

DENSITY = {
    "adjust-layout": "compact",
    "comparison-controls": "compact",
    "adjust-databounds": "default",
    "select-slice-time": "default",
    "animation-controls": "compact",
}

DEFAULT_STYLES = {
    "color": "white",
    "classes": "border-b-thin",
}

COMPARISON_TYPE_TOOLTIPS = {
    "source": "Source data (no comparison)",
    "diff": "Difference: comparison - control",
    "comp1": "Relative difference w.r.t. control: (comparison - control) / control",
    "comp2": (
        "Relative difference w.r.t. mean: "
        "2 * (comparison - control) / (comparison + control)"
    ),
}

COLUMN_TOOLTIPS = {
    "ctrl": "Control simulation values",
    "test": "Test simulation values",
    "diff": "Difference: test - control",
    "comp1": "Relative difference w.r.t. control: (test - control) / control",
    "comp2": "Relative difference w.r.t. mean: 2 * (test - control) / (test + control)",
}


def to_kwargs(value):
    return {
        "v_show": js.is_active(value),
        "density": DENSITY[value],
        **DEFAULT_STYLES,
    }


class Cropping(v3.VToolbar):
    def __init__(self):
        super().__init__(**to_kwargs("adjust-databounds"))

        with self:
            with v3.VTooltip(
                text=(
                    "crop_slider_edit ? 'Toggle to text edit' : 'Toggle to slider edit'",
                ),
            ):
                with v3.Template(v_slot_activator="{ props }"):
                    v3.VIcon(
                        "mdi-web",
                        v_bind="props",
                        classes="pl-6 opacity-50",
                        click="crop_slider_edit = !crop_slider_edit",
                    )
            with v3.VRow(
                classes="ma-0 px-2 align-center", v_if=("crop_slider_edit", True)
            ):
                with v3.VCol(cols=6):
                    with v3.VRow(classes="mx-2 my-0"):
                        v3.VLabel(
                            "Longitude",
                            classes="text-subtitle-2",
                        )
                        v3.VSpacer()
                        v3.VLabel(
                            "{{ crop_longitude }}",
                            classes="text-body-2",
                        )
                    v3.VRangeSlider(
                        v_model=("crop_longitude", [-180, 180]),
                        min=-180,
                        max=180,
                        step=1,
                        density="compact",
                        hide_details=True,
                    )
                with v3.VCol(cols=6):
                    with v3.VRow(classes="mx-2 my-0"):
                        v3.VLabel(
                            "Latitude",
                            classes="text-subtitle-2",
                        )
                        v3.VSpacer()
                        v3.VLabel(
                            "{{ crop_latitude }}",
                            classes="text-body-2",
                        )
                    v3.VRangeSlider(
                        v_model=("crop_latitude", [-90, 90]),
                        min=-90,
                        max=90,
                        step=1,
                        density="compact",
                        hide_details=True,
                    )
            with v3.VRow(classes="ma-0 pl-6 pr-2 align-center ga-4", v_else=True):
                v3.VNumberInput(
                    label="Longitude (min)",
                    v_model=("crop_longitude_min", -180),
                    min=[-180],
                    max=("crop_longitude_max", 180),
                    step=[1],
                    hide_details=True,
                    density="comfortable",
                    variant="plain",
                    flat=True,
                    control_variant="stacked",
                )
                v3.VNumberInput(
                    label="Longitude (max)",
                    v_model=("crop_longitude_max", 180),
                    min=("crop_longitude_min", -180),
                    max=[180],
                    step=[1],
                    hide_details=True,
                    density="comfortable",
                    variant="plain",
                    flat=True,
                    control_variant="stacked",
                    inset=True,
                )
                v3.VNumberInput(
                    label="Latitude (min)",
                    v_model=("crop_latitude_min", -90),
                    min=[-90],
                    max=("crop_latitude_max", 90),
                    step=[1],
                    hide_details=True,
                    density="comfortable",
                    variant="plain",
                    flat=True,
                    control_variant="stacked",
                    inset=True,
                )
                v3.VNumberInput(
                    label="Latitude (max)",
                    v_model=("crop_latitude_max", 90),
                    min=("crop_latitude_min", -90),
                    max=[90],
                    step=[1],
                    hide_details=True,
                    density="comfortable",
                    variant="plain",
                    flat=True,
                    control_variant="stacked",
                    inset=True,
                )

    @change("crop_longitude_min", "crop_longitude_max")
    def _on_crop_lon(self, crop_longitude_min, crop_longitude_max, **_):
        if crop_longitude_min is None or crop_longitude_max is None:
            return

        data_range = [float(crop_longitude_min), float(crop_longitude_max)]
        if data_range[0] < data_range[1]:
            self.state.crop_longitude = data_range

    @change("crop_latitude_min", "crop_latitude_max")
    def _on_crop_lat(self, crop_latitude_min, crop_latitude_max, **_):
        if crop_latitude_min is None or crop_latitude_max is None:
            return

        data_range = [float(crop_latitude_min), float(crop_latitude_max)]
        if data_range[0] < data_range[1]:
            self.state.crop_latitude = data_range

    @change("crop_longitude")
    def _sync_crop_lon_inputs(self, crop_longitude, **_):
        if not crop_longitude or len(crop_longitude) < 2:
            return

        self.state.crop_longitude_min = crop_longitude[0]
        self.state.crop_longitude_max = crop_longitude[1]

    @change("crop_latitude")
    def _sync_crop_lat_inputs(self, crop_latitude, **_):
        if not crop_latitude or len(crop_latitude) < 2:
            return

        self.state.crop_latitude_min = crop_latitude[0]
        self.state.crop_latitude_max = crop_latitude[1]


class ComparisonMode(v3.VToolbar):
    def __init__(self):
        super().__init__(**to_kwargs("comparison-controls"))

        with self:
            v3.VIcon("mdi-compare-horizontal", classes="pl-6 opacity-50")
            with v3.Template(v_if="comparison_mode === 'multi-sim'"):
                v3.VLabel("Comparison", classes="text-subtitle-2 px-4")
                for comparison_type in COMPARISON_TYPES:
                    with v3.VTooltip(
                        text=COMPARISON_TYPE_TOOLTIPS.get(
                            comparison_type,
                            COMPARISON_TYPE_LABELS.get(
                                comparison_type, comparison_type.upper()
                            ),
                        ),
                    ):
                        with v3.Template(v_slot_activator="{ props }"):
                            v3.VBtn(
                                COMPARISON_TYPE_LABELS.get(
                                    comparison_type, comparison_type.upper()
                                ),
                                v_bind="props",
                                size="small",
                                variant="outlined",
                                color=(
                                    f"comparison_type === '{comparison_type}' ? 'primary' : 'default'",
                                ),
                                classes=(
                                    f"`mx-1 text-none ${{comparison_type === '{comparison_type}' ? '' : 'text-medium-emphasis'}}`",
                                ),
                                click=f"comparison_type = '{comparison_type}'",
                            )
                v3.VSpacer()
                with v3.VTooltip():
                    with v3.Template(v_slot_activator="{ props }"):
                        v3.VLabel(
                            "{{ Math.max(0, simulation_configs.filter(sim => sim.path !== control_simulation_file && sim.include).length) }} comparisons",
                            v_bind="props",
                            classes="text-caption mr-4",
                        )
                    html.Div(
                        "{{ (() => { const included = simulation_configs.filter(sim => sim.path === control_simulation_file || sim.include); if (!included.length) return 'Included simulations:\\nnone'; return `Included simulations:\\n${included.map(sim => `${sim.label || sim.path.split('/').pop()}${sim.path === control_simulation_file ? ' (ctrl)' : ''}`).join('\\n')}`; })() }}",
                        style="white-space: pre-line;",
                    )

            with v3.Template(v_else=True):
                v3.VLabel("Columns", classes="text-subtitle-2 px-4")
                for comp_type in ["ctrl", "test", "diff", "comp1", "comp2"]:
                    with v3.VTooltip(
                        text=COLUMN_TOOLTIPS.get(
                            comp_type,
                            COMPARISON_TYPE_LABELS.get(comp_type, comp_type.upper()),
                        ),
                    ):
                        with v3.Template(v_slot_activator="{ props }"):
                            v3.VBtn(
                                COMPARISON_TYPE_LABELS.get(
                                    comp_type, comp_type.upper()
                                ),
                                v_bind="props",
                                size="small",
                                variant="outlined",
                                color=(
                                    "selected_columns.includes('{0}') ? 'primary' : 'default'".format(
                                        comp_type
                                    ),
                                ),
                                classes=(
                                    f"`mx-1 text-none ${{selected_columns.includes('{comp_type}') ? '' : 'text-medium-emphasis'}}`",
                                ),
                                click=(
                                    f"selected_columns.includes('{comp_type}') ? "
                                    f"selected_columns = selected_columns.filter(c => c !== '{comp_type}') : "
                                    f"selected_columns = [...selected_columns, '{comp_type}']"
                                ),
                            )
                v3.VSpacer()
                v3.VBtn(
                    "Show all",
                    size="small",
                    variant="text",
                    classes="mr-2 text-none",
                    click="selected_columns = ['ctrl', 'test', 'diff', 'comp1', 'comp2']",
                )


class DataSelection(html.Div):
    def __init__(self):
        style = to_kwargs("select-slice-time")
        # Use style instead of d-flex class to avoid !important override of v-show
        # Add background color to match VToolbar appearance
        style["style"] = (
            "display: flex; align-items: center; background: rgb(var(--v-theme-surface));"
        )
        super().__init__(**style)

        with self:
            with v3.VTooltip(
                text=(
                    "slice_slider_edit ? 'Toggle to text edit' : 'Toggle to slider edit'",
                ),
            ):
                with v3.Template(v_slot_activator="{ props }"):
                    v3.VIcon(
                        "mdi-tune-variant",
                        v_bind="props",
                        classes="ml-3 mr-2 opacity-50",
                        click="slice_slider_edit = !slice_slider_edit",
                    )

            with v3.VRow(
                classes="ma-0 pr-2 flex-wrap flex-grow-1",
                dense=True,
                v_if=("slice_slider_edit", True),
            ):
                with v3.VCol(
                    cols=4,
                    v_for="(track, idx) in available_animation_tracks",
                    key="idx",
                    classes="pa-2",
                ):
                    with client.Getter(name=("track",), value_name="t_values"):
                        with client.Getter(
                            name=("track + '_idx'",), value_name="t_idx"
                        ):
                            with v3.VRow(classes="ma-0 align-center", dense=True):
                                v3.VLabel(
                                    "{{track}}",
                                    classes="text-subtitle-2",
                                )
                                v3.VSpacer()
                                v3.VLabel(
                                    "{{ dim_units[track] ? parseFloat(t_values[t_idx]).toFixed(2) + ' ' + dim_units[track] : 'Index value: ' + t_idx }} (k={{ t_idx }})",
                                    classes="text-body-2",
                                )
                            v3.VSlider(
                                model_value=("t_idx",),
                                update_modelValue=(
                                    self.on_update_slider,
                                    "[track, $event]",
                                ),
                                min=0,
                                max=("t_values.length - 1",),
                                step=1,
                                density="compact",
                                hide_details=True,
                            )
            with v3.VRow(
                classes="ma-0 pl-6 pr-2 align-center ga-4",
                v_else=True,
            ):
                with v3.VCol(
                    v_for="(track, idx) in available_animation_tracks",
                    key="idx",
                ):
                    with client.Getter(name=("track",), value_name="t_values"):
                        with client.Getter(
                            name=("track + '_idx'",), value_name="t_idx"
                        ):
                            with v3.VRow(classes="ma-0 align-center", dense=True):
                                v3.VNumberInput(
                                    model_value=("Number(t_idx)",),
                                    update_modelValue=(
                                        self.on_update_slider,
                                        "[track, Number($event)]",
                                    ),
                                    key=("track + '_' + t_idx",),
                                    min=[0],
                                    max=["t_values ? t_values.length - 1 : 0"],
                                    step=[1],
                                    hide_details=True,
                                    density="comfortable",
                                    variant="plain",
                                    flat=True,
                                    control_variant="stacked",
                                    style="max-width: 100px;",
                                    reverse=True,
                                )
                                v3.VLabel(
                                    "{{track}}",
                                    classes="text-subtitle-2 ml-2 mt-1",
                                )
                                v3.VLabel(
                                    "{{ dim_units[track] ? parseFloat(t_values[Number(t_idx)]).toFixed(2) + ' ' + dim_units[track] : 'Index value: ' + t_idx }}",
                                    classes="text-body-2 text-no-wrap ml-2 mt-1",
                                )

    def on_update_slider(self, dimension, index, *_, **__):
        with self.state:
            self.state[f"{dimension}_idx"] = int(index)


class Animation(v3.VToolbar):
    def __init__(self):
        super().__init__(**to_kwargs("animation-controls"))

        with self:
            v3.VIcon(
                "mdi-video",
                classes="px-6 opacity-50",
            )
            with v3.VRow(classes="ma-0 px-2 align-center"):
                v3.VSelect(
                    v_model=("animation_track", None),
                    items=("available_animation_tracks", []),
                    flat=True,
                    variant="plain",
                    hide_details=True,
                    density="compact",
                    style="max-width: 10rem;",
                )
                v3.VDivider(vertical=True, classes="mx-2")
                v3.VSlider(
                    v_model=("animation_step", 1),
                    min=0,
                    max=("animation_step_max", 0),
                    step=1,
                    hide_details=True,
                    density="compact",
                    classes="mx-4",
                )
                v3.VDivider(vertical=True, classes="mx-2")
                v3.VIconBtn(
                    icon="mdi-page-first",
                    flat=True,
                    disabled=("animation_step === 0",),
                    click="animation_step = 0",
                )
                v3.VIconBtn(
                    icon="mdi-chevron-left",
                    flat=True,
                    disabled=("animation_step === 0",),
                    click="animation_step = Math.max(0, animation_step - 1)",
                )
                v3.VIconBtn(
                    icon="mdi-chevron-right",
                    flat=True,
                    disabled=("animation_step === animation_step_max",),
                    click="animation_step = Math.min(animation_step_max, animation_step + 1)",
                )
                v3.VIconBtn(
                    icon="mdi-page-last",
                    disabled=("animation_step === animation_step_max",),
                    flat=True,
                    click="animation_step = animation_step_max",
                )
                v3.VDivider(vertical=True, classes="mx-2")
                v3.VIconBtn(
                    icon=("animation_play ? 'mdi-stop' : 'mdi-play'",),
                    flat=True,
                    click="animation_play = !animation_play",
                )

    @change("animation_track")
    def _on_animation_track_change(self, animation_track, **_):
        self.state.animation_step = 0
        self.state.animation_step_max = 0

        if animation_track:
            values = None
            try:
                values = self.state[animation_track]
            except Exception:
                values = None

            if values:
                self.state.animation_step_max = len(values) - 1

    @change("animation_step")
    def _on_animation_step(self, animation_track, animation_step, **_):
        if animation_track:
            self.state[f"{animation_track}_idx"] = animation_step

    @change("animation_play")
    def _on_animation_play(self, animation_play, **_):
        if animation_play:
            asynchronous.create_task(self._run_animation())

    async def _run_animation(self):
        with self.state as s:
            while s.animation_play:
                await asyncio.sleep(0.1)
                if s.animation_step < s.animation_step_max:
                    with s:
                        s.animation_step += 1
                    await self.server.network_completion
                else:
                    s.animation_play = False
