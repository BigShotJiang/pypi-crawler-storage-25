from collections import defaultdict
import fnmatch
import json
import os

import e3sm_quickview
from paraview import simple
from paraview.simple import (
    Contour,
    ExtractSurface,
    LegacyVTKReader,
    LoadPlugin,
    OutputPort,
    ProgrammableFilter,
)
from vtkmodules.vtkCommonCore import vtkLogger
from vtkmodules.vtkRenderingCore import vtkActor, vtkPolyDataMapper

from e3sm_compareview.comparison import (
    COMPARISON_TYPES,
    COMPARISON_TYPE_TITLE_SUFFIXES,
)


def range_to_trim(value_range, max_value):
    """Convert [-max, max] coordinate ranges into [left_trim, right_trim]."""
    min_value, max_range = value_range
    return [min_value + max_value, max_value - max_range]


def load_plugins():
    try:
        plugin_dir = os.path.join(
            os.path.dirname(e3sm_quickview.__file__),
            "plugins",
        )
        plugins = fnmatch.filter(os.listdir(path=plugin_dir), "*.py")
        for plugin in plugins:
            print("Loading plugin : ", plugin)
            plugpath = os.path.abspath(os.path.join(plugin_dir, plugin))
            if os.path.isfile(plugpath):
                LoadPlugin(plugpath, ns=globals())

        vtkLogger.SetStderrVerbosity(vtkLogger.VERBOSITY_OFF)
    except Exception as e:
        print("Error loading plugin :", e)


class ErrorObserver:
    def __init__(self):
        self.error_occurred = False
        self.error_message = ""

    def __call__(self, obj, event):
        self.error_occurred = True

    def clear(self):
        self.error_occurred = False


class Continent:
    def __init__(self, projection="Mollweide"):
        self._projection = projection
        self.clip_longitude = [-180.0, 180.0]
        self.clip_latitude = [-90.0, 90.0]

        globe_file = os.path.join(os.path.dirname(__file__), "data", "globe.vtk")
        self.reader = LegacyVTKReader(
            registrationName="ContReader",
            FileNames=[globe_file],
        )
        self.contour = Contour(registrationName="ContContour", Input=self.reader)
        self.contour.ContourBy = ["POINTS", "cstar"]
        self.contour.Isosurfaces = [0.5]
        self.contour.PointMergeMethod = "Uniform Binning"

        self.extract = EAMTransformAndExtract(  # noqa: F821
            registrationName="ContExtract",
            Input=self.contour,
        )
        self.extract.LongitudeRange = self.clip_longitude
        self.extract.LatitudeRange = self.clip_latitude

        self.proj = EAMProject(  # noqa: F821
            registrationName="ContProj",
            Input=OutputPort(self.extract, 0),
        )
        self.proj.Projection = projection
        self.proj.Translate = 0
        self.surface = ExtractSurface(registrationName="ContSurface", Input=self.proj)

        self.mapper = vtkPolyDataMapper()
        self.mapper.SetScalarVisibility(0)
        self.actor = vtkActor()
        self.actor.SetMapper(self.mapper)
        prop = self.actor.GetProperty()
        prop.SetRepresentationToWireframe()
        prop.SetRenderLinesAsTubes(1)
        prop.SetLineWidth(1.0)
        prop.SetAmbientColor(0.67, 0.67, 0.67)
        prop.SetDiffuseColor(0.67, 0.67, 0.67)

    @property
    def projection(self):
        return self._projection

    @projection.setter
    def projection(self, value):
        self._projection = value
        self.proj.Projection = value

    @property
    def view_proxy(self):
        return OutputPort(self.proj, 0)

    @property
    def vtk_geometry(self):
        return self.surface.GetClientSideObject()

    def crop(self, longitude_min_max, latitude_min_max):
        self.clip_longitude = [float(longitude_min_max[0]), float(longitude_min_max[1])]
        self.clip_latitude = [float(latitude_min_max[0]), float(latitude_min_max[1])]
        self.extract.LongitudeRange = self.clip_longitude
        self.extract.LatitudeRange = self.clip_latitude

    def update(self, time=0.0):
        self.proj.UpdatePipeline(time)
        self.surface.UpdatePipeline(time)
        self.mapper.SetInputConnection(self.vtk_geometry.output_port)


class GridLines:
    def __init__(self, projection="Mollweide"):
        self._projection = projection
        self.clip_longitude = [-180.0, 180.0]
        self.clip_latitude = [-90.0, 90.0]

        self.grid_lines = EAMGridLines(registrationName="GridGen")  # noqa: F821
        self.grid_lines.LongitudeRange = self.clip_longitude
        self.grid_lines.LatitudeRange = self.clip_latitude

        self.proj = EAMProject(  # noqa: F821
            registrationName="GridProj",
            Input=OutputPort(self.grid_lines, 0),
        )
        self.proj.Projection = projection
        self.proj.Translate = 0
        self.surface = ExtractSurface(registrationName="GridSurface", Input=self.proj)

        self.mapper = vtkPolyDataMapper()
        self.mapper.SetScalarVisibility(0)
        self.actor = vtkActor()
        self.actor.SetMapper(self.mapper)
        prop = self.actor.GetProperty()
        prop.SetRepresentationToWireframe()
        prop.SetAmbientColor(0.67, 0.67, 0.67)
        prop.SetDiffuseColor(0.67, 0.67, 0.67)
        prop.SetOpacity(0.4)

    @property
    def projection(self):
        return self._projection

    @projection.setter
    def projection(self, value):
        self._projection = value
        self.proj.Projection = value

    @property
    def view_proxy(self):
        return OutputPort(self.proj, 0)

    @property
    def vtk_geometry(self):
        return self.surface.GetClientSideObject()

    def crop(self, longitude_min_max, latitude_min_max):
        self.clip_longitude = [float(longitude_min_max[0]), float(longitude_min_max[1])]
        self.clip_latitude = [float(latitude_min_max[0]), float(latitude_min_max[1])]
        self.grid_lines.LongitudeRange = self.clip_longitude
        self.grid_lines.LatitudeRange = self.clip_latitude

    def update(self, time=0.0):
        self.grid_lines.UpdatePipeline(time)
        self.proj.UpdatePipeline(time)
        self.surface.UpdatePipeline(time)
        self.mapper.SetInputConnection(self.vtk_geometry.output_port)


class DataReader:
    def __init__(self, projection="Mollweide"):
        self.valid = False
        self.conn_file = None
        self.simulation_files = []
        self.simulation_configs = []
        self.varmeta = None
        self.dimmeta = None
        self.slicing = defaultdict(int)
        self.data_readers = []
        self._projection = projection
        self.timestamps = []
        self.variable_view_specs = {}
        self.array_metadata = {}
        self.loaded_variables = []
        self.prog_filter = None
        self.atmos_center = None
        self.atmos_extract = None
        self.atmos_proj = None
        self.atmos_surface = None
        self._atmos_extract_mode = "range"
        self.extents = [-180.0, 180.0, -90.0, 90.0]
        self.moveextents = [-180.0, 180.0, -90.0, 90.0]
        self.clip_longitude = [-180.0, 180.0]
        self.clip_latitude = [-90.0, 90.0]
        self.observer = ErrorObserver()

    @property
    def projection(self):
        return self._projection

    @projection.setter
    def projection(self, value):
        self._projection = value
        if self.atmos_proj is not None:
            self.atmos_proj.Projection = value

    @property
    def view_proxy(self):
        if self.atmos_surface is None:
            return None
        return OutputPort(self.atmos_surface, 0)

    @property
    def vtk_geometry(self):
        if self.atmos_surface is None:
            return None
        return self.atmos_surface.GetClientSideObject()

    def crop(self, longitude_min_max, latitude_min_max):
        self.clip_longitude = [float(longitude_min_max[0]), float(longitude_min_max[1])]
        self.clip_latitude = [float(latitude_min_max[0]), float(latitude_min_max[1])]
        if self.atmos_extract is None:
            return
        self._apply_clip_to_extract()

    def _apply_clip_to_extract(self):
        if self._atmos_extract_mode == "trim":
            self.atmos_extract.TrimLongitude = range_to_trim(self.clip_longitude, 180)
            self.atmos_extract.TrimLatitude = range_to_trim(self.clip_latitude, 90)
        else:
            self.atmos_extract.LongitudeRange = self.clip_longitude
            self.atmos_extract.LatitudeRange = self.clip_latitude

    def update(self, time=0.0):
        if not self.valid or self.atmos_proj is None:
            return

        self.atmos_proj.UpdatePipeline(time)
        self.moveextents = self.atmos_proj.GetDataInformation().GetBounds()
        if self.atmos_surface is not None:
            self.atmos_surface.UpdatePipeline(time)

    def update_slicing(self, dimension, slice_index):
        if self.slicing.get(dimension) == slice_index:
            return
        self.slicing[dimension] = slice_index
        if self.data_readers:
            slicing_state = json.dumps(self.slicing)
            for reader in self.data_readers:
                reader.Slicing = slicing_state

    def clear_readers(self):
        for reader in self.data_readers:
            try:
                simple.Delete(reader)
            except Exception:
                pass
        self.data_readers = []

    def clear_derived_state(self):
        self.valid = False
        self.timestamps = []
        self.variable_view_specs = {}
        self.array_metadata = {}
        self.prog_filter = None
        self.atmos_center = None
        self.atmos_extract = None
        self.atmos_proj = None
        self.atmos_surface = None

    def _create_reader(self, index, file_path):
        reader = EAMSliceDataReader(  # noqa: F821
            registrationName=f"AtmosReader{index}",
            ConnectivityFile=self.conn_file,
            DataFile=file_path,
        )
        vtk_obj = reader.GetClientSideObject()
        vtk_obj.AddObserver("ErrorEvent", self.observer)
        vtk_obj.GetExecutive().AddObserver("ErrorEvent", self.observer)
        return reader

    def _configure_readers(self):
        slicing_state = json.dumps(self.slicing)
        for reader in self.data_readers:
            reader.Slicing = slicing_state
            reader.Variables = self.loaded_variables

    def _update_varmeta(self):
        reader_varmeta = []
        for index, reader in enumerate(self.data_readers):
            vtk_obj = reader.GetClientSideObject()
            if index == 0:
                self.dimmeta = vtk_obj.GetDimensions()
            reader_varmeta.append(vtk_obj.GetVariables())

        if not reader_varmeta:
            self.varmeta = {}
            return

        common_keys = set(reader_varmeta[0])
        for metadata in reader_varmeta[1:]:
            common_keys &= set(metadata)

        self.varmeta = {
            key: reader_varmeta[0][key]
            for key in reader_varmeta[0]
            if key in common_keys
        }

        for dim in self.dimmeta.keys():
            self.slicing.setdefault(dim, 0)

    @staticmethod
    def control_array_name(var_name):
        return f"{var_name}__control"

    @staticmethod
    def comparison_array_name(var_name, comparison_type, index):
        return f"{var_name}__{comparison_type}__{index}"

    @staticmethod
    def _normalize_timestamps(timestep_values):
        if isinstance(timestep_values, (list, tuple)):
            return list(timestep_values)
        if hasattr(timestep_values, "__iter__") and not isinstance(
            timestep_values, str
        ):
            return list(timestep_values)
        return [timestep_values] if timestep_values is not None else []

    def _build_programmable_filter_script(self):
        # Emit control/source arrays and derived comparison arrays per simulation.
        return f"""import numpy as np

def _to_float_array(values, shape=None):
    try:
        array = np.asarray(values, dtype=np.float64)
    except (TypeError, ValueError):
        return None if shape is None else np.full(shape, np.nan, dtype=np.float64)
    if shape is not None and array.shape != shape:
        return np.full(shape, np.nan, dtype=np.float64)
    return array

vars = {self.loaded_variables}
for var in vars:
    ctrl_np = _to_float_array(inputs[0].CellData[f"{{var}}"])
    if ctrl_np is None:
        continue

    output.CellData.append(ctrl_np, f'{{var}}')
    output.CellData.append(ctrl_np, f'{{var}}__control')
    for sim_index, sim_input in enumerate(inputs[1:], start=1):
        sim_np = _to_float_array(sim_input.CellData[f"{{var}}"], ctrl_np.shape)
        output.CellData.append(sim_np, f'{{var}}__test__{{sim_index}}')
        output.CellData.append(sim_np, f'{{var}}__source__{{sim_index}}')

        # Use guarded division to avoid runtime warnings for zero-valued slices.
        diff = sim_np - ctrl_np
        comp1 = np.full(ctrl_np.shape, np.nan, dtype=np.float64)
        comp2 = np.full(ctrl_np.shape, np.nan, dtype=np.float64)
        denom_ctrl = ctrl_np
        denom_sum = sim_np + ctrl_np
        np.divide(diff, denom_ctrl, out=comp1, where=(denom_ctrl != 0))
        np.divide(2.0 * diff, denom_sum, out=comp2, where=(denom_sum != 0))

        output.CellData.append(diff, f'{{var}}__diff__{{sim_index}}')
        output.CellData.append(comp1, f'{{var}}__comp1__{{sim_index}}')
        output.CellData.append(comp2, f'{{var}}__comp2__{{sim_index}}')

area_np = _to_float_array(inputs[0].CellData["area"])
if area_np is not None:
    output.CellData.append(area_np, 'area') # needed for utils.compute.extract_avgs
"""

    def _build_view_specs(self, variables):
        self.variable_view_specs = {}
        self.array_metadata = {}
        if not self.simulation_configs:
            return

        control = self.simulation_configs[0]
        for var_name in variables:
            per_type_specs = {}
            control_array_name = self.control_array_name(var_name)
            control_metadata = {
                "array_name": control_array_name,
                "base_variable": var_name,
                "role": "control",
                "metric": "raw",
                "label": f"{control['label']} (control)",
                "path": control["path"],
                "index": 0,
                "source_index": control.get("source_index", 0),
            }
            self.array_metadata[control_array_name] = control_metadata

            two_sim_specs = {
                "ctrl": {
                    **control_metadata,
                    "comparison_mode": "two-sim",
                    "label": f"{var_name}_ctrl",
                }
            }
            for comparison_type in COMPARISON_TYPES:
                specs = [
                    {
                        **control_metadata,
                        "comparison_mode": "multi-sim",
                        "comparison_type": comparison_type,
                    }
                ]

                for index, simulation in enumerate(
                    self.simulation_configs[1:], start=1
                ):
                    is_source = comparison_type == "source"
                    comparison_spec = {
                        "array_name": self.comparison_array_name(
                            var_name, comparison_type, index
                        ),
                        "base_variable": var_name,
                        "role": "source" if is_source else comparison_type,
                        "metric": "raw" if is_source else comparison_type,
                        "comparison_mode": "multi-sim",
                        "comparison_type": comparison_type,
                        "label": (
                            f"{simulation['label']} "
                            f"({COMPARISON_TYPE_TITLE_SUFFIXES[comparison_type]})"
                        ),
                        "path": simulation["path"],
                        "index": index,
                        "source_index": simulation.get("source_index", index),
                    }
                    specs.append(comparison_spec)
                    self.array_metadata[comparison_spec["array_name"]] = comparison_spec

                per_type_specs[comparison_type] = sorted(
                    specs,
                    key=lambda spec: spec.get("source_index", 0),
                )

            if len(self.simulation_configs) > 1:
                two_sim_target = self.simulation_configs[1]
                test_spec = {
                    "array_name": f"{var_name}__test__1",
                    "base_variable": var_name,
                    "role": "test",
                    "metric": "raw",
                    "label": f"{var_name}_test",
                    "path": two_sim_target["path"],
                    "index": 1,
                    "source_index": two_sim_target.get("source_index", 1),
                    "comparison_mode": "two-sim",
                }
                two_sim_specs["test"] = test_spec
                self.array_metadata[test_spec["array_name"]] = test_spec

                for comparison_type in COMPARISON_TYPES:
                    two_sim_specs[comparison_type] = {
                        "array_name": self.comparison_array_name(
                            var_name, comparison_type, 1
                        ),
                        "base_variable": var_name,
                        "role": comparison_type,
                        "metric": comparison_type,
                        "comparison_mode": "two-sim",
                        "comparison_type": comparison_type,
                        "label": f"{var_name}_{comparison_type}",
                        "path": two_sim_target["path"],
                        "index": 1,
                        "source_index": two_sim_target.get("source_index", 1),
                    }
                    self.array_metadata[
                        two_sim_specs[comparison_type]["array_name"]
                    ] = two_sim_specs[comparison_type]

            self.variable_view_specs[var_name] = {
                "multi-sim": per_type_specs,
                "two-sim": two_sim_specs,
            }

    def get_view_specs(
        self,
        variable_name,
        comparison_mode="multi-sim",
        comparison_type="diff",
        selected_columns=None,
    ):
        entry = self.variable_view_specs.get(variable_name, {})
        if comparison_mode == "two-sim":
            two_sim_specs = entry.get("two-sim", {})
            column_order = ["ctrl", "test", "diff", "comp1", "comp2"]
            selected = selected_columns or column_order
            selected_set = set(selected)
            return [
                two_sim_specs[column]
                for column in column_order
                if column in selected_set
                if column in two_sim_specs
            ]
        return entry.get("multi-sim", {}).get(comparison_type, [])

    def get_array_metadata(self, array_name):
        return self.array_metadata.get(array_name)

    def refresh_view_specs(self, simulation_configs=None):
        if simulation_configs is not None:
            self.simulation_configs = simulation_configs
        self._build_view_specs(self.loaded_variables)

    def _build_atmosphere_pipeline(self):
        script = self._build_programmable_filter_script()
        self.prog_filter = ProgrammableFilter(
            registrationName="ProgrammableFilter",
            Input=self.data_readers,
        )
        self.prog_filter.Script = script
        self.prog_filter.RequestInformationScript = ""
        self.prog_filter.RequestUpdateExtentScript = ""
        self.prog_filter.PythonPath = ""

        has_trim_extract = (
            "EAMCenterMeridian" in globals() and "EAMExtract" in globals()
        )
        has_range_extract = "EAMTransformAndExtract" in globals()

        if has_trim_extract:
            self.atmos_center = EAMCenterMeridian(  # noqa: F821
                registrationName="AtmosCenter",
                Input=self.prog_filter,
            )
            self.atmos_extract = EAMExtract(  # noqa: F821
                registrationName="AtmosExtract",
                Input=self.atmos_center,
            )
            self._atmos_extract_mode = "trim"
        elif has_range_extract:
            self.atmos_center = None
            self.atmos_extract = EAMTransformAndExtract(  # noqa: F821
                registrationName="AtmosExtract",
                Input=self.prog_filter,
            )
            self._atmos_extract_mode = "range"
        else:
            raise RuntimeError(
                "No compatible atmospheric extract filter is available "
                "(expected EAMCenterMeridian+EAMExtract or EAMTransformAndExtract)"
            )

        self._apply_clip_to_extract()
        self.atmos_extract.UpdatePipeline()
        self.extents = self.atmos_extract.GetDataInformation().GetBounds()

        self.atmos_proj = EAMProject(  # noqa: F821
            registrationName="AtmosProj",
            Input=OutputPort(self.atmos_extract, 0),
        )
        self.atmos_proj.Projection = self.projection
        self.atmos_proj.Translate = 0
        self.atmos_proj.UpdatePipeline()

        self.atmos_surface = ExtractSurface(
            registrationName="AtmosSurface",
            Input=self.atmos_proj,
        )
        self.atmos_surface.UpdatePipeline()
        self.moveextents = self.atmos_proj.GetDataInformation().GetBounds()

    def load(self, simulation_configs, conn_file, variables=None, force_reload=False):
        next_loaded_variables = (
            self.loaded_variables if variables is None else list(variables)
        )
        simulation_files = [entry["path"] for entry in simulation_configs]
        if not simulation_files:
            self.loaded_variables = next_loaded_variables
            self.simulation_files = []
            self.simulation_configs = []
            self.conn_file = conn_file
            self.clear_readers()
            self.clear_derived_state()
            return self.valid

        if (
            not force_reload
            and self.simulation_files == simulation_files
            and self.conn_file == conn_file
            and self.loaded_variables == next_loaded_variables
        ):
            self.simulation_configs = simulation_configs
            self._build_view_specs(self.loaded_variables)
            return self.valid

        self.loaded_variables = next_loaded_variables
        self.simulation_files = simulation_files
        self.simulation_configs = simulation_configs
        self.conn_file = conn_file

        if len(self.data_readers) != len(simulation_files):
            self.clear_readers()
            self.data_readers = [
                self._create_reader(index, file_path)
                for index, file_path in enumerate(simulation_files)
            ]
        else:
            for reader, file_path in zip(self.data_readers, simulation_files):
                reader.DataFile = file_path
                reader.ConnectivityFile = self.conn_file

        self._update_varmeta()
        if self.varmeta is None:
            self.loaded_variables = []
        else:
            valid_variables = set(self.varmeta)
            self.loaded_variables = [
                var_name
                for var_name in self.loaded_variables
                if var_name in valid_variables
            ]
        self._configure_readers()
        self.observer.clear()

        try:
            for reader in self.data_readers:
                reader.UpdatePipeline(time=0.0)
            if self.observer.error_occurred:
                raise RuntimeError(
                    "Error occurred in UpdatePipeline. "
                    "Please check if the data and connectivity files exist "
                    "and are compatible"
                )

            self.timestamps = self._normalize_timestamps(
                self.data_readers[0].TimestepValues
            )
            self._build_view_specs(self.loaded_variables)
            self._build_atmosphere_pipeline()
            self.valid = True
            self.observer.clear()
        except Exception as e:
            print(e)
            self.clear_derived_state()

        return self.valid

    def load_variables(self, variables):
        if not self.valid:
            return
        self.loaded_variables = list(variables)
        for reader in self.data_readers:
            reader.Variables = variables

    def get_output_dataset(self):
        vtk_geometry = self.vtk_geometry
        if vtk_geometry is None:
            return None
        vtk_geometry.Update()
        return vtk_geometry.GetOutput()

    def get_cell_data_array(self, array_name):
        dataset = self.get_output_dataset()
        if dataset is None:
            return None
        cell_data = dataset.GetCellData()
        if cell_data is None:
            return None
        return cell_data.GetArray(array_name)


class EAMVisSource:
    def __init__(self):
        self.projection = "Mollweide"
        load_plugins()
        self.data_reader = DataReader(self.projection)
        self.continent = Continent(self.projection)
        self.grid_lines = GridLines(self.projection)

    def update(self, time=0.0):
        self.data_reader.update(time=time)
        self.continent.update(time=time)
        self.grid_lines.update(time=time)

    def ApplyClipping(self, cliplong, cliplat):
        if not self.data_reader.valid:
            return
        self.data_reader.crop(cliplong, cliplat)
        self.continent.crop(cliplong, cliplat)
        self.grid_lines.crop(cliplong, cliplat)

    def UpdateProjection(self, proj):
        if not self.data_reader.valid:
            return

        if self.projection != proj:
            self.projection = proj
            self.data_reader.projection = proj
            self.continent.projection = proj
            self.grid_lines.projection = proj

    def UpdatePipeline(self, time=0.0):
        if not self.data_reader.valid:
            return
        self.update(time=time)

    def UpdateSlicing(self, dimension, slice):
        self.data_reader.update_slicing(dimension, slice)

    def Update(self, simulation_configs, conn_file, variables=None, force_reload=False):
        valid = self.data_reader.load(
            simulation_configs,
            conn_file,
            variables=variables,
            force_reload=force_reload,
        )
        if valid:
            self.update()
        return valid


if __name__ == "__main__":
    e = EAMVisSource()
