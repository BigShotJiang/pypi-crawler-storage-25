"""Behavior tests for the 57 MCP tools.

Uses mocks to exercise each tool's body without network or real cookies.
Covers: args passed through to twikit, output JSON shape, text truncation,
URL parsing in get_tweet, and action-only tools (like/retweet) that return
confirmation JSON.
"""

import json
import time as _time
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from twitter_mcp import server


def _fake_user(screen_name="alice", name="Alice", user_id="42"):
    return SimpleNamespace(id=user_id, screen_name=screen_name, name=name)


def _fake_tweet(
    tid="100",
    text="hello world",
    user=None,
    favorite_count=5,
    retweet_count=2,
    created_at="Mon Jan 01 00:00:00 +0000 2026",
    in_reply_to=None,
    conversation_id=None,
    is_quote_status=False,
    quote=None,
):
    return SimpleNamespace(
        id=tid,
        text=text,
        user=user or _fake_user(),
        favorite_count=favorite_count,
        retweet_count=retweet_count,
        created_at=created_at,
        in_reply_to=in_reply_to,
        conversation_id=conversation_id,
        is_quote_status=is_quote_status,
        quote=quote,
    )


@pytest.fixture
def fake_client(monkeypatch):
    """Inject an AsyncMock client returned from server._get_client."""
    client = AsyncMock()
    monkeypatch.setattr(server, "_get_client", AsyncMock(return_value=client))
    return client


# ── send_tweet ───────────────────────────────────────


async def test_send_tweet_returns_sent_status(fake_client):
    fake_client.create_tweet = AsyncMock(return_value=_fake_tweet(tid="999"))
    out = json.loads(await server.send_tweet("hi there"))
    assert out == {"id": "999", "text": "hi there", "status": "sent"}


async def test_send_tweet_passes_text_and_reply_to(fake_client):
    fake_client.create_tweet = AsyncMock(return_value=_fake_tweet())
    await server.send_tweet("reply body", reply_to="42")
    fake_client.create_tweet.assert_awaited_once_with(text="reply body", reply_to="42")


async def test_send_tweet_default_reply_to_is_none(fake_client):
    fake_client.create_tweet = AsyncMock(return_value=_fake_tweet())
    await server.send_tweet("standalone")
    fake_client.create_tweet.assert_awaited_once_with(text="standalone", reply_to=None)


# ── get_tweet ────────────────────────────────────────


async def test_get_tweet_returns_full_shape(fake_client):
    t = _fake_tweet(
        tid="12345",
        text="a tweet",
        user=_fake_user(screen_name="bob", name="Bob B."),
        favorite_count=10,
        retweet_count=3,
        created_at="Sat Apr 18 10:00:00 +0000 2026",
    )
    fake_client.get_tweets_by_ids = AsyncMock(return_value=[t])
    out = json.loads(await server.get_tweet("12345"))
    assert out == {
        "id": "12345",
        "author": "bob",
        "author_name": "Bob B.",
        "text": "a tweet",
        "created_at": "Sat Apr 18 10:00:00 +0000 2026",
        "likes": 10,
        "retweets": 3,
        "in_reply_to": None,
        "conversation_id": None,
        "is_quote_status": False,
        "quoted_id": None,
        "quoted_author": None,
        "quoted_text": None,
    }


async def test_get_tweet_includes_reply_context(fake_client):
    t = _fake_tweet(
        tid="99999",
        in_reply_to="88888",
        conversation_id="77777",
    )
    fake_client.get_tweets_by_ids = AsyncMock(return_value=[t])
    out = json.loads(await server.get_tweet("99999"))
    assert out["in_reply_to"] == "88888"
    assert out["conversation_id"] == "77777"


async def test_get_tweet_includes_quote_context(fake_client):
    """Issue #82: when the tweet is a quote retweet, the response carries
    the quoted tweet's id / author / text — extracted from the SAME
    GraphQL response, no extra network call."""
    quoted = _fake_tweet(
        tid="20",
        text="just setting up my twttr",
        user=_fake_user(screen_name="jack", name="jack"),
    )
    quoter = _fake_tweet(
        tid="55555",
        text="historic moment",
        is_quote_status=True,
        quote=quoted,
    )
    fake_client.get_tweets_by_ids = AsyncMock(return_value=[quoter])
    out = json.loads(await server.get_tweet("55555"))
    assert out["is_quote_status"] is True
    assert out["quoted_id"] == "20"
    assert out["quoted_author"] == "jack"
    assert out["quoted_text"] == "just setting up my twttr"


async def test_get_tweet_quote_fields_default_when_not_quote(fake_client):
    """Non-quote tweet: all 4 quote keys present with stable defaults
    (no key-not-present surprises)."""
    fake_client.get_tweets_by_ids = AsyncMock(return_value=[_fake_tweet(tid="1")])
    out = json.loads(await server.get_tweet("1"))
    assert out["is_quote_status"] is False
    assert out["quoted_id"] is None
    assert out["quoted_author"] is None
    assert out["quoted_text"] is None


@pytest.mark.parametrize(
    "url,expected_id",
    [
        ("12345", "12345"),
        ("https://x.com/user/status/12345", "12345"),
        ("https://x.com/user/status/12345/", "12345"),
        ("https://twitter.com/user/status/67890", "67890"),
    ],
)
async def test_get_tweet_parses_urls(fake_client, url, expected_id):
    fake_client.get_tweets_by_ids = AsyncMock(
        return_value=[_fake_tweet(tid=expected_id)]
    )
    await server.get_tweet(url)
    fake_client.get_tweets_by_ids.assert_awaited_once_with([expected_id])


# ── get_timeline ─────────────────────────────────────


async def test_get_timeline_returns_list_with_truncated_text(fake_client):
    long_text = "x" * 500
    fake_client.get_timeline = AsyncMock(
        return_value=[_fake_tweet(tid="1", text=long_text)]
    )
    out = json.loads(await server.get_timeline(count=5))
    assert len(out) == 1
    assert out[0]["id"] == "1"
    assert len(out[0]["text"]) == 200  # truncated to 200 chars


async def test_get_timeline_default_count(fake_client):
    fake_client.get_timeline = AsyncMock(return_value=[])
    await server.get_timeline()
    fake_client.get_timeline.assert_awaited_once_with(count=20)


async def test_get_timeline_passes_count(fake_client):
    fake_client.get_timeline = AsyncMock(return_value=[])
    await server.get_timeline(count=7)
    fake_client.get_timeline.assert_awaited_once_with(count=7)


async def test_get_timeline_empty_returns_empty_array(fake_client):
    fake_client.get_timeline = AsyncMock(return_value=[])
    assert json.loads(await server.get_timeline()) == []


# ── search_tweets ────────────────────────────────────


async def test_search_tweets_passes_query_product_count(fake_client):
    fake_client.search_tweet = AsyncMock(return_value=[])
    await server.search_tweets("opus 4.7", count=3, product="Top")
    fake_client.search_tweet.assert_awaited_once_with(
        "opus 4.7", product="Top", count=3
    )


async def test_search_tweets_defaults_to_latest(fake_client):
    fake_client.search_tweet = AsyncMock(return_value=[])
    await server.search_tweets("q")
    fake_client.search_tweet.assert_awaited_once_with("q", product="Latest", count=20)


async def test_search_tweets_formats_results(fake_client):
    fake_client.search_tweet = AsyncMock(
        return_value=[
            _fake_tweet(tid="a", text="short", favorite_count=1, retweet_count=0),
            _fake_tweet(tid="b", text="y" * 300, favorite_count=2, retweet_count=1),
        ]
    )
    out = json.loads(await server.search_tweets("q"))
    assert len(out) == 2
    assert out[0]["id"] == "a"
    assert out[0]["text"] == "short"
    assert len(out[1]["text"]) == 200  # truncated


# ── like_tweet ───────────────────────────────────────


async def test_like_tweet_calls_favorite_and_returns_status(fake_client):
    fake_client.favorite_tweet = AsyncMock()
    out = json.loads(await server.like_tweet("555"))
    assert out == {"tweet_id": "555", "status": "liked"}
    fake_client.favorite_tweet.assert_awaited_once_with("555")


# ── retweet ──────────────────────────────────────────


async def test_retweet_calls_retweet_and_returns_status(fake_client):
    fake_client.retweet = AsyncMock()
    out = json.loads(await server.retweet("777"))
    assert out == {"tweet_id": "777", "status": "retweeted"}
    fake_client.retweet.assert_awaited_once_with("777")


# ── get_user_tweets ──────────────────────────────────


async def test_get_user_tweets_resolves_screen_name_then_fetches(fake_client):
    user = _fake_user(user_id="u-1", screen_name="alice")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.get_user_tweets = AsyncMock(
        return_value=[_fake_tweet(tid="t1", text="tweet one")]
    )

    out = json.loads(await server.get_user_tweets("alice", count=4))

    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.get_user_tweets.assert_awaited_once_with(
        "u-1", tweet_type="Tweets", count=4
    )
    assert len(out) == 1
    assert out[0]["id"] == "t1"
    assert out[0]["text"] == "tweet one"


async def test_get_user_tweets_truncates_long_text(fake_client):
    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.get_user_tweets = AsyncMock(
        return_value=[_fake_tweet(tid="t", text="z" * 1000)]
    )
    out = json.loads(await server.get_user_tweets("alice"))
    assert len(out[0]["text"]) == 200


async def test_get_user_tweets_empty(fake_client):
    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.get_user_tweets = AsyncMock(return_value=[])
    assert json.loads(await server.get_user_tweets("alice")) == []


# ── follow_user / unfollow_user (issue #18) ──────────


async def test_follow_user_resolves_screen_name_then_calls_follow(fake_client):
    """follow_user takes a screen_name (matches get_user_tweets convention),
    resolves to a numeric user_id, then calls twikit's follow_user(user_id)."""
    user = _fake_user(user_id="u-42", screen_name="ClaudeDevs")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.follow_user = AsyncMock()

    out = json.loads(await server.follow_user("ClaudeDevs"))

    fake_client.get_user_by_screen_name.assert_awaited_once_with("ClaudeDevs")
    fake_client.follow_user.assert_awaited_once_with("u-42")
    assert out == {
        "user_id": "u-42",
        "screen_name": "ClaudeDevs",
        "status": "followed",
    }


async def test_unfollow_user_resolves_screen_name_then_calls_unfollow(fake_client):
    """Same shape as follow_user, mirrored verb."""
    user = _fake_user(user_id="u-99", screen_name="ClaudeDevs")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.unfollow_user = AsyncMock()

    out = json.loads(await server.unfollow_user("ClaudeDevs"))

    fake_client.get_user_by_screen_name.assert_awaited_once_with("ClaudeDevs")
    fake_client.unfollow_user.assert_awaited_once_with("u-99")
    assert out == {
        "user_id": "u-99",
        "screen_name": "ClaudeDevs",
        "status": "unfollowed",
    }


async def test_follow_user_does_not_call_follow_if_resolve_fails(monkeypatch):
    """If get_user_by_screen_name raises, follow_user must propagate (no
    silent swallow) and must not have invoked follow_user with a bad id."""
    client = AsyncMock()
    client.get_user_by_screen_name = AsyncMock(side_effect=RuntimeError("no such user"))
    client.follow_user = AsyncMock()
    monkeypatch.setattr(server, "_get_client", AsyncMock(return_value=client))

    with pytest.raises(RuntimeError):
        await server.follow_user("ghost")
    client.follow_user.assert_not_called()


async def test_unfollow_user_does_not_call_unfollow_if_resolve_fails(monkeypatch):
    client = AsyncMock()
    client.get_user_by_screen_name = AsyncMock(side_effect=RuntimeError("no such user"))
    client.unfollow_user = AsyncMock()
    monkeypatch.setattr(server, "_get_client", AsyncMock(return_value=client))

    with pytest.raises(RuntimeError):
        await server.unfollow_user("ghost")
    client.unfollow_user.assert_not_called()


# ── get_user_info (issue #22) ────────────────────────


def _fake_user_full(
    user_id="2024518793679294464",
    screen_name="ClaudeDevs",
    name="Claude Devs",
    description="bio text",
    created_at="Mon Jan 01 00:00:00 +0000 2026",
    followers_count=1234,
    following_count=42,
    statuses_count=99,
    verified=True,
    is_blue_verified=True,
    location="The Cloud",
    url="https://claude.com",
    profile_image_url="https://pbs.twimg.com/avatar/x.jpg",
    protected=False,
):
    return SimpleNamespace(
        id=user_id,
        screen_name=screen_name,
        name=name,
        description=description,
        created_at=created_at,
        followers_count=followers_count,
        following_count=following_count,
        statuses_count=statuses_count,
        verified=verified,
        is_blue_verified=is_blue_verified,
        location=location,
        url=url,
        # twikit's `User.profile_image_url` (NO `_https` suffix on the
        # attribute, even though the X JSON key is `profile_image_url_https`).
        # Issue #37: the test fake formerly used the JSON key shape, so
        # `server.get_user_info` reading `u.profile_image_url_https` looked
        # green under mocks but blew up on the real model with
        # `AttributeError: 'User' object has no attribute …_https`.
        profile_image_url=profile_image_url,
        protected=protected,
    )


async def test_get_user_info_returns_full_metadata_shape(fake_client):
    """Happy path: returns the documented JSON shape, no missing keys."""
    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user_full())
    out = json.loads(await server.get_user_info("ClaudeDevs"))
    assert out == {
        "id": "2024518793679294464",
        "screen_name": "ClaudeDevs",
        "name": "Claude Devs",
        "description": "bio text",
        "created_at": "Mon Jan 01 00:00:00 +0000 2026",
        "followers_count": 1234,
        "following_count": 42,
        "tweets_count": 99,
        "verified": True,
        "is_blue_verified": True,
        "profile_image_url": "https://pbs.twimg.com/avatar/x.jpg",
        "protected": False,
        "location": "The Cloud",
        "url": "https://claude.com",
    }
    fake_client.get_user_by_screen_name.assert_awaited_once_with("ClaudeDevs")


async def test_get_user_info_passes_screen_name_through(fake_client):
    """The screen_name arg is forwarded verbatim to twikit's resolver."""
    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user_full())
    await server.get_user_info("elonmusk")
    fake_client.get_user_by_screen_name.assert_awaited_once_with("elonmusk")


async def test_get_user_info_propagates_resolve_failure(monkeypatch):
    """If twikit raises (unknown user / network), the tool propagates — no swallow."""
    client = AsyncMock()
    client.get_user_by_screen_name = AsyncMock(side_effect=RuntimeError("no such user"))
    monkeypatch.setattr(server, "_get_client", AsyncMock(return_value=client))

    with pytest.raises(RuntimeError):
        await server.get_user_info("ghost")


async def test_get_user_info_uses_statuses_count_for_tweets_count(fake_client):
    """twikit's User.statuses_count maps to our `tweets_count` key (issue #22 spec)."""
    fake_client.get_user_by_screen_name = AsyncMock(
        return_value=_fake_user_full(statuses_count=12345)
    )
    out = json.loads(await server.get_user_info("anyone"))
    assert out["tweets_count"] == 12345
    # And the upstream key name does NOT leak into the output.
    assert "statuses_count" not in out


async def test_get_user_info_exposes_both_verified_fields(fake_client):
    """PR #23 review: u.verified is the legacy gold/grey badge (almost
    always False on modern X); u.is_blue_verified is the X Premium blue
    badge that most users actually have. Expose BOTH so callers don't
    silently get misleading false negatives.
    """
    fake_client.get_user_by_screen_name = AsyncMock(
        return_value=_fake_user_full(verified=False, is_blue_verified=True)
    )
    out = json.loads(await server.get_user_info("modern_user"))
    assert out["verified"] is False
    assert out["is_blue_verified"] is True


async def test_get_user_info_handles_none_optional_fields(fake_client):
    """PR #23 review gap: description / location / url can be None (twikit's
    User defaults missing legacy.* fields to None). Output must round-trip
    them as JSON null, not the string "None".
    """
    fake_client.get_user_by_screen_name = AsyncMock(
        return_value=_fake_user_full(description=None, location=None, url=None)
    )
    out = json.loads(await server.get_user_info("sparse_user"))
    assert out["description"] is None
    assert out["location"] is None
    assert out["url"] is None


# ── get_user_info: user_id overload + typed exception handling (PR #24 review) ─


async def test_get_user_info_accepts_user_id_kwarg(fake_client):
    """`user_id=` resolves via twikit's get_user_by_id, NOT screen_name path."""
    fake_client.get_user_by_id = AsyncMock(return_value=_fake_user_full())
    fake_client.get_user_by_screen_name = AsyncMock()  # must NOT be called
    out = json.loads(await server.get_user_info(user_id="2024518793679294464"))
    assert out["id"] == "2024518793679294464"
    fake_client.get_user_by_id.assert_awaited_once_with("2024518793679294464")
    fake_client.get_user_by_screen_name.assert_not_called()


async def test_get_user_info_raises_when_neither_provided(fake_client):
    """Strict contract: caller must give exactly one of screen_name / user_id."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_user_info()
    msg = str(exc.value)
    assert "screen_name" in msg and "user_id" in msg


async def test_get_user_info_raises_when_both_provided(fake_client):
    """Both at once is also a contract violation — pick one."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_user_info(screen_name="alice", user_id="42")
    msg = str(exc.value)
    assert "screen_name" in msg and "user_id" in msg


async def test_get_user_info_raises_clean_error_on_too_many_requests(fake_client):
    """twikit's TooManyRequests → ToolError with a friendly rate-limit message."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(
        side_effect=TooManyRequests("rate limited")
    )
    with pytest.raises(ToolError) as exc:
        await server.get_user_info("alice")
    assert "rate limit" in str(exc.value).lower()


async def test_get_user_info_raises_clean_error_on_not_found(fake_client):
    """twikit's NotFound → ToolError with a 'user not found' message."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_id = AsyncMock(side_effect=NotFound("no user"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_info(user_id="9999999999999")
    assert "not found" in str(exc.value).lower()
    # The id we asked about appears in the message so callers know what failed.
    assert "9999999999999" in str(exc.value)


# ── get_user_followers / get_user_following ──────────


class _FakeResult(list):
    """Stand-in for twikit's Result[User] — list-like + .next_cursor attr."""

    def __init__(self, users, next_cursor=None):
        super().__init__(users)
        self.next_cursor = next_cursor


def _fake_followers_result(users=None, next_cursor="cursor-page-2"):
    if users is None:
        users = [
            _fake_user_full(
                user_id=f"u-{i}",
                screen_name=f"follower_{i}",
                name=f"Follower {i}",
                description="b" * 250,  # long bio to verify truncation
            )
            for i in range(3)
        ]
    return _FakeResult(users, next_cursor=next_cursor)


async def test_get_user_followers_resolves_screen_name_then_fetches(fake_client):
    """screen_name → get_user_by_screen_name → get_user_followers(user.id)."""
    fake_client.get_user_by_screen_name = AsyncMock(
        return_value=_fake_user_full(user_id="u-42", screen_name="alice")
    )
    fake_client.get_user_followers = AsyncMock(return_value=_fake_followers_result())
    out = json.loads(await server.get_user_followers(screen_name="alice", count=5))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.get_user_followers.assert_awaited_once_with(
        "u-42", count=5, cursor=None
    )
    assert "users" in out
    assert len(out["users"]) == 3
    assert out["next_cursor"] == "cursor-page-2"


async def test_get_user_followers_uses_user_id_directly_no_resolve(fake_client):
    """When user_id is given, skip the screen_name resolution roundtrip."""
    fake_client.get_user_by_screen_name = AsyncMock()  # must NOT be called
    fake_client.get_user_followers = AsyncMock(return_value=_fake_followers_result())
    await server.get_user_followers(user_id="u-99", count=10)
    fake_client.get_user_by_screen_name.assert_not_called()
    fake_client.get_user_followers.assert_awaited_once_with(
        "u-99", count=10, cursor=None
    )


async def test_get_user_followers_truncates_bio_in_compact_user(fake_client):
    """Bio in the followers list is truncated (long lists otherwise blow the
    MCP_OUTPUT cap). Match get_user_tweets/get_timeline truncation pattern."""
    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user_full())
    long_bio_user = _fake_user_full(description="X" * 500)
    fake_client.get_user_followers = AsyncMock(
        return_value=_fake_followers_result(users=[long_bio_user])
    )
    out = json.loads(await server.get_user_followers(screen_name="alice"))
    assert len(out["users"][0]["description"]) <= 200  # truncated


async def test_get_user_followers_passes_cursor_through(fake_client):
    """Caller can paginate via cursor — pass through verbatim."""
    fake_client.get_user_followers = AsyncMock(return_value=_fake_followers_result())
    await server.get_user_followers(user_id="u-1", count=20, cursor="abc-cursor")
    fake_client.get_user_followers.assert_awaited_once_with(
        "u-1", count=20, cursor="abc-cursor"
    )


async def test_get_user_followers_raises_on_count_over_100(fake_client):
    """Don't silently clamp — raise so callers know about the cap."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_user_followers(user_id="u-1", count=500)
    assert "100" in str(exc.value)


async def test_get_user_followers_raises_when_neither_provided(fake_client):
    """Same exactly-one contract as get_user_info."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_user_followers()


async def test_get_user_following_mirrors_followers_shape(fake_client):
    """Symmetrical to get_user_followers, just calls get_user_following."""
    fake_client.get_user_following = AsyncMock(return_value=_fake_followers_result())
    out = json.loads(await server.get_user_following(user_id="u-42", count=5))
    fake_client.get_user_following.assert_awaited_once_with(
        "u-42", count=5, cursor=None
    )
    assert "users" in out
    assert "next_cursor" in out


async def test_get_user_following_resolves_screen_name(fake_client):
    fake_client.get_user_by_screen_name = AsyncMock(
        return_value=_fake_user_full(user_id="u-7", screen_name="alice")
    )
    fake_client.get_user_following = AsyncMock(return_value=_fake_followers_result())
    await server.get_user_following(screen_name="alice", count=15)
    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.get_user_following.assert_awaited_once_with(
        "u-7", count=15, cursor=None
    )


async def test_get_user_following_raises_on_count_over_100(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_user_following(user_id="u-1", count=200)


async def test_get_user_followers_raises_clean_on_rate_limit(fake_client):
    """TooManyRequests during followers fetch → ToolError, not raw twikit error."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_followers = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_followers(user_id="u-1")
    assert "rate limit" in str(exc.value).lower()


async def test_get_user_followers_raises_clean_on_not_found(fake_client):
    """NotFound during followers fetch → ToolError naming the missing user."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_followers = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_followers(user_id="ghost")
    assert "ghost" in str(exc.value)


async def test_get_user_following_raises_clean_on_rate_limit(fake_client):
    """Same TooManyRequests pattern for get_user_following."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_following = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError):
        await server.get_user_following(user_id="u-1")


async def test_get_user_following_raises_clean_on_not_found(fake_client):
    """Same NotFound pattern for get_user_following."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_following = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_following(user_id="ghost")
    assert "ghost" in str(exc.value)


# ── PR #25 Claude review followups ────────────────────


async def test_get_user_followers_raises_clean_on_not_found_during_resolve(fake_client):
    """If screen_name resolution itself raises NotFound, that path is also
    caught — not just the followers-fetch path."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("no user"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_followers(screen_name="ghost")
    assert "ghost" in str(exc.value)


async def test_get_user_following_raises_clean_on_not_found_during_resolve(fake_client):
    """Same NotFound-during-resolve path on get_user_following."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("no user"))
    with pytest.raises(ToolError) as exc:
        await server.get_user_following(screen_name="ghost")
    assert "ghost" in str(exc.value)


async def test_get_user_followers_raises_on_count_below_1(fake_client):
    """count=0 / -1 must raise — don't silently forward to twikit."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_user_followers(user_id="u-1", count=0)
    with pytest.raises(ToolError):
        await server.get_user_followers(user_id="u-1", count=-5)


async def test_get_user_following_raises_on_count_below_1(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_user_following(user_id="u-1", count=0)


# ── delete_tweet ─────────────────────────────────────


async def test_delete_tweet_calls_client_and_returns_deleted(fake_client):
    fake_client.delete_tweet = AsyncMock()
    out = json.loads(await server.delete_tweet("123"))
    assert out == {"tweet_id": "123", "status": "deleted"}
    fake_client.delete_tweet.assert_awaited_once_with("123")


async def test_delete_tweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.delete_tweet = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.delete_tweet("999")
    assert "not found" in str(exc.value).lower()


async def test_delete_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.delete_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.delete_tweet("123")
    assert "rate limit" in str(exc.value).lower()


# ── unfavorite_tweet ──────────────────────────────────


async def test_unfavorite_tweet_calls_client_and_returns_unliked(fake_client):
    fake_client.unfavorite_tweet = AsyncMock()
    out = json.loads(await server.unfavorite_tweet("555"))
    assert out == {"tweet_id": "555", "status": "unliked"}
    fake_client.unfavorite_tweet.assert_awaited_once_with("555")


async def test_unfavorite_tweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.unfavorite_tweet = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.unfavorite_tweet("999")
    assert "not found" in str(exc.value).lower()


# ── delete_retweet ────────────────────────────────────


async def test_delete_retweet_calls_client_and_returns_un_retweeted(fake_client):
    fake_client.delete_retweet = AsyncMock()
    out = json.loads(await server.delete_retweet("777"))
    assert out == {"tweet_id": "777", "status": "un-retweeted"}
    fake_client.delete_retweet.assert_awaited_once_with("777")


async def test_delete_retweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.delete_retweet = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.delete_retweet("888")
    assert "not found" in str(exc.value).lower()


# ── bookmark_tweet ────────────────────────────────────


async def test_bookmark_tweet_calls_client_and_returns_bookmarked(fake_client):
    fake_client.bookmark_tweet = AsyncMock()
    out = json.loads(await server.bookmark_tweet("100"))
    assert out == {"tweet_id": "100", "status": "bookmarked"}
    fake_client.bookmark_tweet.assert_awaited_once_with("100", None)


async def test_bookmark_tweet_passes_folder_id(fake_client):
    fake_client.bookmark_tweet = AsyncMock()
    out = json.loads(await server.bookmark_tweet("100", folder_id="folder42"))
    assert out["folder_id"] == "folder42"
    fake_client.bookmark_tweet.assert_awaited_once_with("100", "folder42")


async def test_bookmark_tweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.bookmark_tweet = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.bookmark_tweet("999")
    assert "not found" in str(exc.value).lower()


# ── delete_bookmark ───────────────────────────────────


async def test_delete_bookmark_calls_client_and_returns_un_bookmarked(fake_client):
    fake_client.delete_bookmark = AsyncMock()
    out = json.loads(await server.delete_bookmark("200"))
    assert out == {"tweet_id": "200", "status": "un-bookmarked"}
    fake_client.delete_bookmark.assert_awaited_once_with("200")


async def test_delete_bookmark_raises_clean_on_not_found(fake_client):
    """Error message says 'bookmark not found' (not 'tweet not found') because
    the tweet typically still exists — only the bookmark is missing."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.delete_bookmark = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.delete_bookmark("999")
    msg = str(exc.value).lower()
    assert "bookmark" in msg
    assert "999" in str(exc.value)


# ── get_bookmarks ─────────────────────────────────────


class _FakeTweetResult(list):
    """Stand-in for twikit's Result[Tweet] — list-like + .next_cursor attr."""

    def __init__(self, tweets, next_cursor=None):
        super().__init__(tweets)
        self.next_cursor = next_cursor


def _fake_bookmark_tweet(tid="bk1", text="bookmark text", screen_name="bob"):
    return _fake_tweet(tid=tid, text=text, user=_fake_user(screen_name=screen_name))


async def test_get_bookmarks_returns_compact_tweet_list(fake_client):
    fake_client.get_bookmarks = AsyncMock(
        return_value=_FakeTweetResult(
            [_fake_bookmark_tweet("bk1"), _fake_bookmark_tweet("bk2")],
            next_cursor="cur-2",
        )
    )
    out = json.loads(await server.get_bookmarks(count=20))
    assert out["count"] == 2
    assert out["next_cursor"] == "cur-2"
    assert out["tweets"][0]["id"] == "bk1"
    assert "author" in out["tweets"][0]
    assert "text" in out["tweets"][0]
    assert "likes" in out["tweets"][0]
    assert "retweets" in out["tweets"][0]


async def test_get_bookmarks_truncates_text_to_200(fake_client):
    long_text = "z" * 500
    fake_client.get_bookmarks = AsyncMock(
        return_value=_FakeTweetResult([_fake_bookmark_tweet(text=long_text)])
    )
    out = json.loads(await server.get_bookmarks())
    assert len(out["tweets"][0]["text"]) == 200


async def test_get_bookmarks_passes_count_and_cursor(fake_client):
    fake_client.get_bookmarks = AsyncMock(return_value=_FakeTweetResult([]))
    await server.get_bookmarks(count=10, cursor="abc")
    fake_client.get_bookmarks.assert_awaited_once_with(count=10, cursor="abc")


async def test_get_bookmarks_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_bookmarks(count=101)
    assert "100" in str(exc.value)


async def test_get_bookmarks_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_bookmarks(count=0)


async def test_get_bookmarks_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_bookmarks = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_bookmarks()
    assert "rate limit" in str(exc.value).lower()


# ── get_favoriters ────────────────────────────────────


async def test_get_favoriters_returns_user_list(fake_client):
    fake_client.get_favoriters = AsyncMock(
        return_value=_fake_followers_result(next_cursor="cur-f")
    )
    out = json.loads(await server.get_favoriters("tw-1", count=3))
    fake_client.get_favoriters.assert_awaited_once_with("tw-1", count=3, cursor=None)
    assert "users" in out
    assert out["next_cursor"] == "cur-f"
    assert out["count"] == len(out["users"])


async def test_get_favoriters_passes_cursor(fake_client):
    fake_client.get_favoriters = AsyncMock(return_value=_fake_followers_result())
    await server.get_favoriters("tw-1", count=5, cursor="xyz")
    fake_client.get_favoriters.assert_awaited_once_with("tw-1", count=5, cursor="xyz")


async def test_get_favoriters_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_favoriters("tw-1", count=200)
    assert "100" in str(exc.value)


async def test_get_favoriters_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_favoriters("tw-1", count=0)


async def test_get_favoriters_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_favoriters = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_favoriters("tw-1")
    assert "rate limit" in str(exc.value).lower()


async def test_get_favoriters_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_favoriters = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_favoriters("tw-ghost")
    assert "not found" in str(exc.value).lower()


# ── get_retweeters ────────────────────────────────────


async def test_get_retweeters_returns_user_list(fake_client):
    fake_client.get_retweeters = AsyncMock(
        return_value=_fake_followers_result(next_cursor="cur-r")
    )
    out = json.loads(await server.get_retweeters("tw-2", count=5))
    fake_client.get_retweeters.assert_awaited_once_with("tw-2", count=5, cursor=None)
    assert "users" in out
    assert out["next_cursor"] == "cur-r"


async def test_get_retweeters_passes_cursor(fake_client):
    fake_client.get_retweeters = AsyncMock(return_value=_fake_followers_result())
    await server.get_retweeters("tw-2", count=10, cursor="pgcur")
    fake_client.get_retweeters.assert_awaited_once_with(
        "tw-2", count=10, cursor="pgcur"
    )


async def test_get_retweeters_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_retweeters("tw-2", count=500)
    assert "100" in str(exc.value)


async def test_get_retweeters_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_retweeters("tw-2", count=-1)


async def test_get_retweeters_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_retweeters = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_retweeters("tw-2")
    assert "rate limit" in str(exc.value).lower()


async def test_get_retweeters_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_retweeters = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_retweeters("tw-ghost")
    assert "not found" in str(exc.value).lower()


# ── search_user ───────────────────────────────────────


async def test_search_user_returns_user_list(fake_client):
    fake_client.search_user = AsyncMock(
        return_value=_fake_followers_result(next_cursor="cur-s")
    )
    out = json.loads(await server.search_user("alice", count=5))
    fake_client.search_user.assert_awaited_once_with("alice", count=5, cursor=None)
    assert "users" in out
    assert out["next_cursor"] == "cur-s"
    assert out["count"] == len(out["users"])


async def test_search_user_passes_cursor(fake_client):
    fake_client.search_user = AsyncMock(return_value=_fake_followers_result())
    await server.search_user("bob", count=10, cursor="pg2")
    fake_client.search_user.assert_awaited_once_with("bob", count=10, cursor="pg2")


async def test_search_user_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_user("query", count=101)
    assert "100" in str(exc.value)


async def test_search_user_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.search_user("query", count=0)


async def test_search_user_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.search_user = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.search_user("alice")
    assert "rate limit" in str(exc.value).lower()


# ── get_trends ────────────────────────────────────────


def _fake_trend(name="AI", tweets_count=50000, domain_context="Technology"):
    from types import SimpleNamespace

    return SimpleNamespace(
        name=name, tweets_count=tweets_count, domain_context=domain_context
    )


async def test_get_trends_returns_trend_list(fake_client):
    fake_client.get_trends = AsyncMock(
        return_value=[_fake_trend("AI"), _fake_trend("#Python")]
    )
    out = json.loads(await server.get_trends())
    fake_client.get_trends.assert_awaited_once_with("trending", count=20)
    assert out["category"] == "trending"
    assert len(out["trends"]) == 2
    assert out["trends"][0]["name"] == "AI"
    assert "tweets_count" in out["trends"][0]
    assert "domain_context" in out["trends"][0]


async def test_get_trends_passes_category_and_count(fake_client):
    fake_client.get_trends = AsyncMock(return_value=[])
    await server.get_trends(category="news", count=10)
    fake_client.get_trends.assert_awaited_once_with("news", count=10)


async def test_get_trends_raises_on_invalid_category(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_trends(category="invalid")
    assert "category" in str(exc.value).lower()


async def test_get_trends_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_trends = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_trends()
    assert "rate limit" in str(exc.value).lower()


# ── PR #26 followup: TooManyRequests coverage on action tools ─
# (delete_tweet's rate-limit test already exists; covering the other 4)


async def test_unfavorite_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.unfavorite_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.unfavorite_tweet("123")
    assert "rate limit" in str(exc.value).lower()


async def test_delete_retweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.delete_retweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.delete_retweet("123")
    assert "rate limit" in str(exc.value).lower()


async def test_bookmark_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.bookmark_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.bookmark_tweet("123")
    assert "rate limit" in str(exc.value).lower()


async def test_delete_bookmark_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.delete_bookmark = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.delete_bookmark("123")
    assert "rate limit" in str(exc.value).lower()


# ── PR #27 Claude review followups ────────────────────


async def test_get_trends_raises_on_count_too_low(fake_client):
    """Claude PR #27 review: get_trends was missing the count<1 guard."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_trends(count=0)
    with pytest.raises(ToolError):
        await server.get_trends(count=-3)


async def test_search_user_raises_on_empty_query(fake_client):
    """Claude PR #27 review: empty / whitespace query → clean ToolError."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_user("")
    assert "empty" in str(exc.value).lower()
    with pytest.raises(ToolError):
        await server.search_user("   ")  # whitespace-only also empty


# ── block_user / unblock_user / mute_user / unmute_user ──────────────────────


async def test_block_user_resolves_screen_name_then_calls_block(fake_client):
    user = _fake_user(user_id="u-42", screen_name="badactor")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.block_user = AsyncMock()
    out = json.loads(await server.block_user("badactor"))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("badactor")
    fake_client.block_user.assert_awaited_once_with("u-42")
    assert out == {"user_id": "u-42", "screen_name": "badactor", "status": "blocked"}


async def test_unblock_user_returns_unblocked_status(fake_client):
    user = _fake_user(user_id="u-42", screen_name="badactor")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.unblock_user = AsyncMock()
    out = json.loads(await server.unblock_user("badactor"))
    fake_client.unblock_user.assert_awaited_once_with("u-42")
    assert out == {"user_id": "u-42", "screen_name": "badactor", "status": "unblocked"}


async def test_mute_user_returns_muted_status(fake_client):
    user = _fake_user(user_id="u-42", screen_name="noisy")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.mute_user = AsyncMock()
    out = json.loads(await server.mute_user("noisy"))
    fake_client.mute_user.assert_awaited_once_with("u-42")
    assert out == {"user_id": "u-42", "screen_name": "noisy", "status": "muted"}


async def test_unmute_user_returns_unmuted_status(fake_client):
    user = _fake_user(user_id="u-42", screen_name="noisy")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.unmute_user = AsyncMock()
    out = json.loads(await server.unmute_user("noisy"))
    fake_client.unmute_user.assert_awaited_once_with("u-42")
    assert out == {"user_id": "u-42", "screen_name": "noisy", "status": "unmuted"}


async def test_block_user_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.block_user("someone")
    assert "rate limit" in str(exc.value).lower()


async def test_block_user_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.block_user("ghost")
    assert "not found" in str(exc.value).lower()


# ── get_notifications ─────────────────────────────────────────────────────────


class _FakeNotificationResult(list):
    """Stand-in for twikit's Result[Notification]."""

    def __init__(self, items, next_cursor=None):
        super().__init__(items)
        self.next_cursor = next_cursor


def _fake_notification(
    nid="n1",
    timestamp_ms=1000,
    message="Alice liked your tweet",
    icon=None,
    tweet=None,
    from_user=None,
):
    from types import SimpleNamespace

    return SimpleNamespace(
        id=nid,
        timestamp_ms=timestamp_ms,
        message=message,
        icon=icon or {},
        tweet=tweet,
        from_user=from_user,
    )


async def test_get_notifications_returns_notification_list(fake_client):
    notif = _fake_notification(nid="n1", tweet=_fake_tweet(tid="tw1"))
    fake_client.get_notifications = AsyncMock(
        return_value=_FakeNotificationResult([notif], next_cursor="nc-1")
    )
    out = json.loads(await server.get_notifications(notification_type="All", count=10))
    fake_client.get_notifications.assert_awaited_once_with("All", count=10, cursor=None)
    assert out["count"] == 1
    assert out["next_cursor"] == "nc-1"
    assert out["notifications"][0]["id"] == "n1"
    assert out["notifications"][0]["tweet_id"] == "tw1"


async def test_get_notifications_omits_tweet_id_when_no_tweet(fake_client):
    notif = _fake_notification(nid="n2", tweet=None)
    fake_client.get_notifications = AsyncMock(
        return_value=_FakeNotificationResult([notif])
    )
    out = json.loads(await server.get_notifications())
    assert "tweet_id" not in out["notifications"][0]


async def test_get_notifications_raises_on_invalid_type(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_notifications(notification_type="BadType")
    assert "notification_type" in str(exc.value).lower()


async def test_get_notifications_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_notifications(count=101)
    assert "100" in str(exc.value)


async def test_get_notifications_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_notifications(count=0)


async def test_get_notifications_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_notifications = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_notifications()
    assert "rate limit" in str(exc.value).lower()


async def test_get_notifications_passes_cursor(fake_client):
    fake_client.get_notifications = AsyncMock(return_value=_FakeNotificationResult([]))
    await server.get_notifications(cursor="abc")
    fake_client.get_notifications.assert_awaited_once_with(
        "All", count=40, cursor="abc"
    )


# ── send_dm ───────────────────────────────────────────────────────────────────


def _fake_message(mid="msg1"):
    from types import SimpleNamespace

    return SimpleNamespace(id=mid)


async def test_send_dm_resolves_screen_name_then_sends(fake_client):
    user = _fake_user(user_id="u-42", screen_name="alice")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.send_dm = AsyncMock(return_value=_fake_message("m1"))
    out = json.loads(await server.send_dm("alice", "hello"))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.send_dm.assert_awaited_once_with("u-42", "hello", None)
    assert out == {"message_id": "m1", "status": "sent"}


async def test_send_dm_passes_media_id(fake_client):
    user = _fake_user(user_id="u-1", screen_name="alice")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.send_dm = AsyncMock(return_value=_fake_message())
    await server.send_dm("alice", "hi", media_id="mid123")
    fake_client.send_dm.assert_awaited_once_with("u-1", "hi", "mid123")


async def test_send_dm_raises_on_empty_text(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.send_dm("alice", "")
    with pytest.raises(ToolError):
        await server.send_dm("alice", "   ")


async def test_send_dm_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.send_dm("alice", "hi")
    assert "rate limit" in str(exc.value).lower()


async def test_send_dm_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.send_dm("ghost", "hi")
    assert "not found" in str(exc.value).lower()


# ── send_dm_to_group ──────────────────────────────────────────────────────────


async def test_send_dm_to_group_sends_to_group_id(fake_client):
    fake_client.send_dm_to_group = AsyncMock(return_value=_fake_message("gm1"))
    out = json.loads(await server.send_dm_to_group("grp-1", "hello group"))
    fake_client.send_dm_to_group.assert_awaited_once_with("grp-1", "hello group", None)
    assert out == {"message_id": "gm1", "status": "sent"}


async def test_send_dm_to_group_passes_media_id(fake_client):
    fake_client.send_dm_to_group = AsyncMock(return_value=_fake_message())
    await server.send_dm_to_group("grp-1", "hi", media_id="mid456")
    fake_client.send_dm_to_group.assert_awaited_once_with("grp-1", "hi", "mid456")


async def test_send_dm_to_group_raises_on_empty_text(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.send_dm_to_group("grp-1", "")


async def test_send_dm_to_group_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.send_dm_to_group = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.send_dm_to_group("grp-1", "hi")
    assert "rate limit" in str(exc.value).lower()


# ── get_dm_history ────────────────────────────────────────────────────────────


class _FakeMessageResult(list):
    """Stand-in for twikit's Result[Message]."""

    def __init__(self, msgs, next_cursor=None):
        super().__init__(msgs)
        self.next_cursor = next_cursor


def _fake_dm(
    mid="m1",
    text="hello",
    sender_id="s1",
    recipient_id="r1",
    time="1234567890000",
):
    from types import SimpleNamespace

    return SimpleNamespace(
        id=mid,
        text=text,
        sender_id=sender_id,
        recipient_id=recipient_id,
        time=time,
    )


async def test_get_dm_history_resolves_screen_name_then_fetches(fake_client):
    user = _fake_user(user_id="u-42", screen_name="alice")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.get_dm_history = AsyncMock(
        return_value=_FakeMessageResult([_fake_dm("m1")], next_cursor="m1")
    )
    out = json.loads(await server.get_dm_history("alice"))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.get_dm_history.assert_awaited_once_with("u-42", None)
    assert len(out["messages"]) == 1
    assert out["messages"][0]["id"] == "m1"


async def test_get_dm_history_passes_max_id(fake_client):
    user = _fake_user(user_id="u-1")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.get_dm_history = AsyncMock(return_value=_FakeMessageResult([]))
    await server.get_dm_history("alice", max_id="mx1")
    fake_client.get_dm_history.assert_awaited_once_with("u-1", "mx1")


async def test_get_dm_history_truncates_text_to_500(fake_client):
    user = _fake_user(user_id="u-1")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    long_msg = _fake_dm(text="z" * 1000)
    fake_client.get_dm_history = AsyncMock(return_value=_FakeMessageResult([long_msg]))
    out = json.loads(await server.get_dm_history("alice"))
    assert len(out["messages"][0]["text"]) == 500


async def test_get_dm_history_returns_next_cursor(fake_client):
    """Output uses `next_cursor` consistently with all other paginated tools.
    Caller passes this back as `max_id` on the next call to walk older messages."""
    user = _fake_user(user_id="u-1")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.get_dm_history = AsyncMock(
        return_value=_FakeMessageResult([_fake_dm("mx99")], next_cursor="mx99")
    )
    out = json.loads(await server.get_dm_history("alice"))
    assert out["next_cursor"] == "mx99"
    assert "max_id_for_next_page" not in out  # old key removed


async def test_get_dm_history_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_dm_history("alice")
    assert "rate limit" in str(exc.value).lower()


async def test_get_dm_history_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_dm_history("ghost")
    assert "not found" in str(exc.value).lower()


# ── delete_dm ─────────────────────────────────────────────────────────────────


async def test_delete_dm_returns_deleted_status(fake_client):
    fake_client.delete_dm = AsyncMock()
    out = json.loads(await server.delete_dm("msg-999"))
    assert out == {"message_id": "msg-999", "status": "deleted"}
    fake_client.delete_dm.assert_awaited_once_with("msg-999")


async def test_delete_dm_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.delete_dm = AsyncMock(side_effect=NotFound("gone"))
    with pytest.raises(ToolError) as exc:
        await server.delete_dm("msg-404")
    assert "not found" in str(exc.value).lower()


async def test_delete_dm_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.delete_dm = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.delete_dm("msg-1")
    assert "rate limit" in str(exc.value).lower()


# ── PR #29 followup: TooManyRequests coverage on remaining moderation tools ─


async def test_unblock_user_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.unblock_user = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.unblock_user("alice")
    assert "rate limit" in str(exc.value).lower()


async def test_mute_user_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.mute_user = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.mute_user("alice")
    assert "rate limit" in str(exc.value).lower()


async def test_unmute_user_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.unmute_user = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.unmute_user("alice")
    assert "rate limit" in str(exc.value).lower()


async def test_unblock_user_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.unblock_user = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.unblock_user("ghost")
    assert "ghost" in str(exc.value)


async def test_mute_user_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.mute_user = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.mute_user("ghost")
    assert "ghost" in str(exc.value)


async def test_unmute_user_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(return_value=_fake_user())
    fake_client.unmute_user = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.unmute_user("ghost")
    assert "ghost" in str(exc.value)


async def test_send_dm_to_group_raises_clean_on_not_found(fake_client):
    """Claude PR #29 review: send_dm_to_group was missing the NotFound handler.
    Sibling DM tools (send_dm, get_dm_history) all catch it; this one was the
    only outlier. Now matches the pattern."""
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.send_dm_to_group = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.send_dm_to_group("g-missing", "hi")
    assert "g-missing" in str(exc.value)


# ── Tier 2B: Twitter Lists CRUD ───────────────────────────────────────────────


def _fake_list(
    list_id="lst-1",
    name="My List",
    description="A test list",
    member_count=5,
    subscriber_count=3,
    mode="Public",
    created_at=1234567890,
):
    return SimpleNamespace(
        id=list_id,
        name=name,
        description=description,
        member_count=member_count,
        subscriber_count=subscriber_count,
        mode=mode,
        created_at=created_at,
    )


class _FakeListResult(list):
    """Stand-in for twikit's Result[List] — list-like + .next_cursor attr."""

    def __init__(self, lists, next_cursor=None):
        super().__init__(lists)
        self.next_cursor = next_cursor


# ── get_list ──────────────────────────────────────────


async def test_get_list_returns_list_dict(fake_client):
    fake_client.get_list = AsyncMock(return_value=_fake_list("lst-1", "My List"))
    out = json.loads(await server.get_list("lst-1"))
    fake_client.get_list.assert_awaited_once_with("lst-1")
    assert out["id"] == "lst-1"
    assert out["name"] == "My List"
    assert "description" in out
    assert "member_count" in out
    assert "subscriber_count" in out
    assert "is_private" in out
    assert "created_at" in out


async def test_get_list_is_private_for_private_mode(fake_client):
    fake_client.get_list = AsyncMock(return_value=_fake_list(mode="Private"))
    out = json.loads(await server.get_list("lst-1"))
    assert out["is_private"] is True


async def test_get_list_is_public_for_public_mode(fake_client):
    fake_client.get_list = AsyncMock(return_value=_fake_list(mode="Public"))
    out = json.loads(await server.get_list("lst-1"))
    assert out["is_private"] is False


async def test_get_list_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_list = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_list("lst-ghost")
    assert "lst-ghost" in str(exc.value)


async def test_get_list_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_list = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_list("lst-1")
    assert "rate limit" in str(exc.value).lower()


# ── get_lists ─────────────────────────────────────────


async def test_get_lists_returns_list_of_dicts(fake_client):
    fake_client.get_lists = AsyncMock(
        return_value=_FakeListResult(
            [_fake_list("l1"), _fake_list("l2")], next_cursor="nc-1"
        )
    )
    out = json.loads(await server.get_lists(count=10))
    fake_client.get_lists.assert_awaited_once_with(count=10, cursor=None)
    assert out["count"] == 2
    assert out["next_cursor"] == "nc-1"
    assert out["lists"][0]["id"] == "l1"


async def test_get_lists_passes_cursor(fake_client):
    fake_client.get_lists = AsyncMock(return_value=_FakeListResult([]))
    await server.get_lists(count=5, cursor="abc")
    fake_client.get_lists.assert_awaited_once_with(count=5, cursor="abc")


async def test_get_lists_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_lists(count=101)
    assert "100" in str(exc.value)


async def test_get_lists_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_lists(count=0)


async def test_get_lists_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_lists = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_lists()
    assert "rate limit" in str(exc.value).lower()


async def test_get_lists_description_truncated_to_200(fake_client):
    long_desc = "d" * 500
    fake_client.get_lists = AsyncMock(
        return_value=_FakeListResult([_fake_list(description=long_desc)])
    )
    out = json.loads(await server.get_lists())
    assert len(out["lists"][0]["description"]) == 200


# ── get_list_tweets ───────────────────────────────────


async def test_get_list_tweets_returns_compact_tweet_list(fake_client):
    fake_client.get_list_tweets = AsyncMock(
        return_value=_FakeTweetResult(
            [_fake_tweet(tid="t1"), _fake_tweet(tid="t2")], next_cursor="nc-lt"
        )
    )
    out = json.loads(await server.get_list_tweets("lst-1", count=5))
    fake_client.get_list_tweets.assert_awaited_once_with("lst-1", count=5, cursor=None)
    assert out["count"] == 2
    assert out["next_cursor"] == "nc-lt"
    assert out["tweets"][0]["id"] == "t1"
    assert "author" in out["tweets"][0]
    assert "text" in out["tweets"][0]
    assert "likes" in out["tweets"][0]
    assert "retweets" in out["tweets"][0]


async def test_get_list_tweets_truncates_text_to_200(fake_client):
    long_text = "z" * 500
    fake_client.get_list_tweets = AsyncMock(
        return_value=_FakeTweetResult([_fake_tweet(text=long_text)])
    )
    out = json.loads(await server.get_list_tweets("lst-1"))
    assert len(out["tweets"][0]["text"]) == 200


async def test_get_list_tweets_passes_cursor(fake_client):
    fake_client.get_list_tweets = AsyncMock(return_value=_FakeTweetResult([]))
    await server.get_list_tweets("lst-1", count=10, cursor="pg2")
    fake_client.get_list_tweets.assert_awaited_once_with(
        "lst-1", count=10, cursor="pg2"
    )


async def test_get_list_tweets_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_list_tweets("lst-1", count=200)
    assert "100" in str(exc.value)


async def test_get_list_tweets_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_list_tweets("lst-1", count=0)


async def test_get_list_tweets_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_list_tweets = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_tweets("lst-1")
    assert "rate limit" in str(exc.value).lower()


async def test_get_list_tweets_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_list_tweets = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_tweets("lst-ghost")
    assert "lst-ghost" in str(exc.value)


# ── get_list_members ──────────────────────────────────


async def test_get_list_members_returns_user_list(fake_client):
    fake_client.get_list_members = AsyncMock(
        return_value=_fake_followers_result(next_cursor="nc-m")
    )
    out = json.loads(await server.get_list_members("lst-1", count=5))
    fake_client.get_list_members.assert_awaited_once_with("lst-1", count=5, cursor=None)
    assert "users" in out
    assert out["next_cursor"] == "nc-m"
    assert out["count"] == len(out["users"])


async def test_get_list_members_passes_cursor(fake_client):
    fake_client.get_list_members = AsyncMock(return_value=_fake_followers_result())
    await server.get_list_members("lst-1", count=10, cursor="cur2")
    fake_client.get_list_members.assert_awaited_once_with(
        "lst-1", count=10, cursor="cur2"
    )


async def test_get_list_members_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_list_members("lst-1", count=200)
    assert "100" in str(exc.value)


async def test_get_list_members_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_list_members("lst-1", count=0)


async def test_get_list_members_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_list_members = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_members("lst-1")
    assert "rate limit" in str(exc.value).lower()


async def test_get_list_members_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_list_members = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_members("lst-ghost")
    assert "lst-ghost" in str(exc.value)


# ── get_list_subscribers ──────────────────────────────


async def test_get_list_subscribers_returns_user_list(fake_client):
    fake_client.get_list_subscribers = AsyncMock(
        return_value=_fake_followers_result(next_cursor="nc-s")
    )
    out = json.loads(await server.get_list_subscribers("lst-1", count=5))
    fake_client.get_list_subscribers.assert_awaited_once_with(
        "lst-1", count=5, cursor=None
    )
    assert "users" in out
    assert out["next_cursor"] == "nc-s"
    assert out["count"] == len(out["users"])


async def test_get_list_subscribers_passes_cursor(fake_client):
    fake_client.get_list_subscribers = AsyncMock(return_value=_fake_followers_result())
    await server.get_list_subscribers("lst-1", count=10, cursor="cur3")
    fake_client.get_list_subscribers.assert_awaited_once_with(
        "lst-1", count=10, cursor="cur3"
    )


async def test_get_list_subscribers_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_list_subscribers("lst-1", count=200)
    assert "100" in str(exc.value)


async def test_get_list_subscribers_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_list_subscribers("lst-1", count=0)


async def test_get_list_subscribers_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_list_subscribers = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_subscribers("lst-1")
    assert "rate limit" in str(exc.value).lower()


async def test_get_list_subscribers_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_list_subscribers = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_list_subscribers("lst-ghost")
    assert "lst-ghost" in str(exc.value)


# ── create_list ───────────────────────────────────────


async def test_create_list_returns_list_dict(fake_client):
    fake_client.create_list = AsyncMock(return_value=_fake_list("new-lst", "New List"))
    out = json.loads(await server.create_list("New List"))
    fake_client.create_list.assert_awaited_once_with("New List", "", False)
    assert out["id"] == "new-lst"
    assert out["name"] == "New List"


async def test_create_list_passes_description_and_is_private(fake_client):
    fake_client.create_list = AsyncMock(return_value=_fake_list(mode="Private"))
    out = json.loads(await server.create_list("Secret", "my secret list", True))
    fake_client.create_list.assert_awaited_once_with("Secret", "my secret list", True)
    assert out["is_private"] is True


async def test_create_list_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.create_list = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.create_list("My List")
    assert "rate limit" in str(exc.value).lower()


# ── edit_list ─────────────────────────────────────────


async def test_edit_list_returns_updated_list_dict(fake_client):
    fake_client.edit_list = AsyncMock(return_value=_fake_list("lst-1", "New Name"))
    out = json.loads(await server.edit_list("lst-1", name="New Name"))
    fake_client.edit_list.assert_awaited_once_with("lst-1", "New Name", None, None)
    assert out["name"] == "New Name"


async def test_edit_list_raises_on_no_fields(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.edit_list("lst-1")
    assert "at least one" in str(exc.value).lower()


async def test_edit_list_passes_description_and_is_private(fake_client):
    fake_client.edit_list = AsyncMock(return_value=_fake_list(mode="Private"))
    await server.edit_list("lst-1", description="new desc", is_private=True)
    fake_client.edit_list.assert_awaited_once_with("lst-1", None, "new desc", True)


async def test_edit_list_allows_empty_string_description(fake_client):
    """Empty string clears description — distinct from None (which means skip)."""
    fake_client.edit_list = AsyncMock(return_value=_fake_list())
    await server.edit_list("lst-1", description="")
    fake_client.edit_list.assert_awaited_once_with("lst-1", None, "", None)


async def test_edit_list_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.edit_list = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.edit_list("lst-ghost", name="new name")
    assert "lst-ghost" in str(exc.value)


async def test_edit_list_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.edit_list = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.edit_list("lst-1", name="new name")
    assert "rate limit" in str(exc.value).lower()


# ── add_list_member ───────────────────────────────────


async def test_add_list_member_by_screen_name(fake_client):
    user = _fake_user(user_id="u-99", screen_name="alice")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.add_list_member = AsyncMock(return_value=_fake_list("lst-1"))
    out = json.loads(await server.add_list_member("lst-1", screen_name="alice"))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("alice")
    fake_client.add_list_member.assert_awaited_once_with("lst-1", "u-99")
    assert out["id"] == "lst-1"


async def test_add_list_member_by_user_id(fake_client):
    fake_client.add_list_member = AsyncMock(return_value=_fake_list("lst-1"))
    out = json.loads(await server.add_list_member("lst-1", user_id="u-77"))
    fake_client.add_list_member.assert_awaited_once_with("lst-1", "u-77")
    assert out["id"] == "lst-1"


async def test_add_list_member_raises_on_neither(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.add_list_member("lst-1")
    assert "add_list_member" in str(exc.value)


async def test_add_list_member_raises_on_both(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.add_list_member("lst-1", screen_name="alice", user_id="u-1")


async def test_add_list_member_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.add_list_member("lst-1", screen_name="ghost")
    assert "not found" in str(exc.value).lower()


async def test_add_list_member_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.add_list_member("lst-1", screen_name="alice")
    assert "rate limit" in str(exc.value).lower()


# ── remove_list_member ────────────────────────────────


async def test_remove_list_member_by_screen_name(fake_client):
    user = _fake_user(user_id="u-88", screen_name="bob")
    fake_client.get_user_by_screen_name = AsyncMock(return_value=user)
    fake_client.remove_list_member = AsyncMock(return_value=_fake_list("lst-1"))
    out = json.loads(await server.remove_list_member("lst-1", screen_name="bob"))
    fake_client.get_user_by_screen_name.assert_awaited_once_with("bob")
    fake_client.remove_list_member.assert_awaited_once_with("lst-1", "u-88")
    assert out["id"] == "lst-1"


async def test_remove_list_member_by_user_id(fake_client):
    fake_client.remove_list_member = AsyncMock(return_value=_fake_list("lst-1"))
    out = json.loads(await server.remove_list_member("lst-1", user_id="u-55"))
    fake_client.remove_list_member.assert_awaited_once_with("lst-1", "u-55")
    assert out["id"] == "lst-1"


async def test_remove_list_member_raises_on_neither(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.remove_list_member("lst-1")
    assert "remove_list_member" in str(exc.value)


async def test_remove_list_member_raises_on_both(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.remove_list_member("lst-1", screen_name="alice", user_id="u-1")


async def test_remove_list_member_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.remove_list_member("lst-1", screen_name="ghost")
    assert "not found" in str(exc.value).lower()


async def test_remove_list_member_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_user_by_screen_name = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.remove_list_member("lst-1", screen_name="alice")
    assert "rate limit" in str(exc.value).lower()


async def test_create_list_raises_on_empty_name(fake_client):
    """Claude PR #31 review: empty / whitespace-only name should raise
    a clean ToolError before reaching twikit (matches send_dm pattern)."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_list("")
    assert "empty" in str(exc.value).lower()
    with pytest.raises(ToolError):
        await server.create_list("   ")  # whitespace-only also empty


# ── create_scheduled_tweet ────────────────────────────


def _fake_scheduled_tweet(
    tweet_id="sched-1",
    text="hello scheduled",
    execute_at=9999999999,
    state="Scheduled",
    media=None,
):
    return SimpleNamespace(
        id=tweet_id,
        text=text,
        execute_at=execute_at,
        state=state,
        media=media or [],
    )


async def test_create_scheduled_tweet_returns_dict(fake_client):
    future_ts = int(_time.time()) + 3600
    fake_client.create_scheduled_tweet = AsyncMock(return_value="sched-1")
    out = json.loads(await server.create_scheduled_tweet(future_ts, "hello"))
    fake_client.create_scheduled_tweet.assert_awaited_once_with(
        future_ts, "hello", None
    )
    assert out["scheduled_tweet_id"] == "sched-1"
    assert out["scheduled_at"] == future_ts
    assert out["status"] == "scheduled"


async def test_create_scheduled_tweet_passes_media_ids(fake_client):
    future_ts = int(_time.time()) + 3600
    fake_client.create_scheduled_tweet = AsyncMock(return_value="sched-2")
    await server.create_scheduled_tweet(future_ts, "", ["m1", "m2"])
    fake_client.create_scheduled_tweet.assert_awaited_once_with(
        future_ts, "", ["m1", "m2"]
    )


async def test_create_scheduled_tweet_rejects_past_timestamp(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    past_ts = int(_time.time()) - 10
    with pytest.raises(ToolError) as exc:
        await server.create_scheduled_tweet(past_ts, "hello")
    assert "future" in str(exc.value).lower()


async def test_create_scheduled_tweet_rejects_current_timestamp(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    now_ts = int(_time.time())
    with pytest.raises(ToolError):
        await server.create_scheduled_tweet(now_ts, "hello")


async def test_create_scheduled_tweet_rejects_empty_text_and_no_media(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    future_ts = int(_time.time()) + 3600
    with pytest.raises(ToolError) as exc:
        await server.create_scheduled_tweet(future_ts, "")
    assert "text" in str(exc.value).lower() or "media" in str(exc.value).lower()


async def test_create_scheduled_tweet_rejects_whitespace_text_and_no_media(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    future_ts = int(_time.time()) + 3600
    with pytest.raises(ToolError):
        await server.create_scheduled_tweet(future_ts, "   ")


async def test_create_scheduled_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    future_ts = int(_time.time()) + 3600
    fake_client.create_scheduled_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.create_scheduled_tweet(future_ts, "hello")
    assert "rate limit" in str(exc.value).lower()


# ── get_scheduled_tweets ──────────────────────────────


async def test_get_scheduled_tweets_returns_list(fake_client):
    tweets = [
        _fake_scheduled_tweet("s1", "tweet one", 9000000001),
        _fake_scheduled_tweet("s2", "tweet two", 9000000002),
    ]
    fake_client.get_scheduled_tweets = AsyncMock(return_value=tweets)
    out = json.loads(await server.get_scheduled_tweets())
    assert out["count"] == 2
    assert len(out["scheduled_tweets"]) == 2
    assert out["scheduled_tweets"][0]["id"] == "s1"
    assert out["scheduled_tweets"][0]["text"] == "tweet one"
    assert out["scheduled_tweets"][0]["scheduled_at"] == 9000000001
    assert "state" in out["scheduled_tweets"][0]


async def test_get_scheduled_tweets_returns_empty_list(fake_client):
    fake_client.get_scheduled_tweets = AsyncMock(return_value=[])
    out = json.loads(await server.get_scheduled_tweets())
    assert out["count"] == 0
    assert out["scheduled_tweets"] == []


async def test_get_scheduled_tweets_truncates_text_to_200(fake_client):
    long_text = "x" * 300
    tweets = [_fake_scheduled_tweet("s1", long_text)]
    fake_client.get_scheduled_tweets = AsyncMock(return_value=tweets)
    out = json.loads(await server.get_scheduled_tweets())
    assert len(out["scheduled_tweets"][0]["text"]) == 200


async def test_get_scheduled_tweets_includes_media_count(fake_client):
    media = [{"media_info": "img1"}, {"media_info": "img2"}]
    tweet = SimpleNamespace(
        id="s1",
        text="with media",
        execute_at=9000000001,
        state="Scheduled",
        media=media,
    )
    fake_client.get_scheduled_tweets = AsyncMock(return_value=[tweet])
    out = json.loads(await server.get_scheduled_tweets())
    assert out["scheduled_tweets"][0]["media_count"] == 2


async def test_get_scheduled_tweets_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_scheduled_tweets = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_scheduled_tweets()
    assert "rate limit" in str(exc.value).lower()


# ── delete_scheduled_tweet ────────────────────────────


async def test_delete_scheduled_tweet_returns_dict(fake_client):
    fake_client.delete_scheduled_tweet = AsyncMock(return_value=None)
    out = json.loads(await server.delete_scheduled_tweet("sched-99"))
    fake_client.delete_scheduled_tweet.assert_awaited_once_with("sched-99")
    assert out["scheduled_tweet_id"] == "sched-99"
    assert out["status"] == "deleted"


async def test_delete_scheduled_tweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.delete_scheduled_tweet = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.delete_scheduled_tweet("ghost-id")
    assert "ghost-id" in str(exc.value)


async def test_delete_scheduled_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.delete_scheduled_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.delete_scheduled_tweet("sched-1")
    assert "rate limit" in str(exc.value).lower()


# ── create_poll ───────────────────────────────────────


async def test_create_poll_returns_card_uri(fake_client):
    fake_client.create_poll = AsyncMock(return_value="card://123456")
    out = json.loads(await server.create_poll(["Yes", "No"], 60))
    fake_client.create_poll.assert_awaited_once_with(["Yes", "No"], 60)
    assert out["card_uri"] == "card://123456"
    assert out["status"] == "created"


async def test_create_poll_accepts_two_choices(fake_client):
    fake_client.create_poll = AsyncMock(return_value="card://111")
    await server.create_poll(["A", "B"], 30)
    fake_client.create_poll.assert_awaited_once_with(["A", "B"], 30)


async def test_create_poll_accepts_four_choices(fake_client):
    fake_client.create_poll = AsyncMock(return_value="card://222")
    await server.create_poll(["A", "B", "C", "D"], 1440)
    fake_client.create_poll.assert_awaited_once_with(["A", "B", "C", "D"], 1440)


async def test_create_poll_rejects_one_choice(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_poll(["Only"], 60)
    assert "2" in str(exc.value) or "choice" in str(exc.value).lower()


async def test_create_poll_rejects_five_choices(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.create_poll(["A", "B", "C", "D", "E"], 60)


async def test_create_poll_rejects_zero_duration(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_poll(["Yes", "No"], 0)
    assert "duration" in str(exc.value).lower() or "0" in str(exc.value)


async def test_create_poll_rejects_negative_duration(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.create_poll(["Yes", "No"], -1)


async def test_create_poll_rejects_empty_choice(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_poll(["Yes", ""], 60)
    assert "empty" in str(exc.value).lower() or "choice" in str(exc.value).lower()


async def test_create_poll_rejects_whitespace_only_choice(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.create_poll(["Yes", "   "], 60)


async def test_create_poll_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.create_poll = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.create_poll(["Yes", "No"], 60)
    assert "rate limit" in str(exc.value).lower()


# ── vote ──────────────────────────────────────────────


async def test_vote_returns_dict(fake_client):
    fake_client.vote = AsyncMock(return_value=SimpleNamespace())
    out = json.loads(
        await server.vote("Option A", "card://123", "tweet-99", "poll2choice")
    )
    fake_client.vote.assert_awaited_once_with(
        "Option A", "card://123", "tweet-99", "poll2choice"
    )
    assert out["tweet_id"] == "tweet-99"
    assert out["selected_choice"] == "Option A"
    assert out["status"] == "voted"


async def test_vote_rejects_empty_selected_choice(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.vote("", "card://123", "tweet-1", "poll2choice")
    assert "choice" in str(exc.value).lower() or "empty" in str(exc.value).lower()


async def test_vote_rejects_whitespace_selected_choice(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.vote("   ", "card://123", "tweet-1", "poll2choice")


async def test_vote_rejects_empty_card_uri(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.vote("Option A", "", "tweet-1", "poll2choice")


async def test_vote_rejects_empty_card_name(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.vote("Option A", "card://123", "tweet-1", "")


async def test_vote_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.vote = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.vote("Option A", "card://123", "tweet-1", "poll2choice")
    assert "rate limit" in str(exc.value).lower()


async def test_vote_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.vote = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.vote("Option A", "card://123", "tweet-ghost", "poll2choice")
    assert "not found" in str(exc.value).lower()


# ── PR #33 Claude review followups ────────────────────


async def test_vote_rejects_empty_tweet_id(fake_client):
    """Claude PR #33 review: vote was missing the tweet_id non-empty guard
    (other 3 string params already had it)."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.vote("Option A", "card://123", "", "poll2choice")
    assert "tweet_id" in str(exc.value)


async def test_create_poll_rejects_duration_over_max(fake_client):
    """Claude PR #33 review: X polls cap at 7 days = 10080 minutes."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_poll(["A", "B"], 10_081)
    assert "10080" in str(exc.value) or "7 days" in str(exc.value)


async def test_create_poll_rejects_choice_over_25_chars(fake_client):
    """Claude PR #33 review: X poll choices cap at 25 chars per choice."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.create_poll(["A" * 26, "B"], 60)
    msg = str(exc.value)
    assert "25" in msg


async def test_delete_scheduled_tweet_rejects_empty_id(fake_client):
    """Consistency with vote: empty id → clean ToolError before twikit call."""
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.delete_scheduled_tweet("")
    assert "scheduled_tweet_id" in str(exc.value)


# ── Tier 3B: Twitter Communities ─────────────────────────────────────────────


def _fake_community(
    community_id="comm-1",
    name="Test Community",
    description="A test community",
    member_count=100,
    is_member=True,
    join_policy="Open",
    created_at=1234567890,
):
    return SimpleNamespace(
        id=community_id,
        name=name,
        description=description,
        member_count=member_count,
        is_member=is_member,
        join_policy=join_policy,
        created_at=created_at,
    )


class _FakeCommunityResult(list):
    """Stand-in for twikit's Result[Community] — list-like + .next_cursor attr."""

    def __init__(self, communities, next_cursor=None):
        super().__init__(communities)
        self.next_cursor = next_cursor


def _fake_community_member(
    user_id="m-1",
    screen_name="member1",
    name="Member One",
    community_role="Member",
    verified=False,
    is_blue_verified=True,
    protected=False,
    following=False,
    followed_by=False,
):
    """Mirror twikit.community.CommunityMember — NOT a User (no description / followers_count)."""
    return SimpleNamespace(
        id=user_id,
        screen_name=screen_name,
        name=name,
        community_role=community_role,
        verified=verified,
        is_blue_verified=is_blue_verified,
        protected=protected,
        following=following,
        followed_by=followed_by,
    )


def _fake_community_members_result(members=None, next_cursor="cm-cursor-2"):
    if members is None:
        members = [_fake_community_member(user_id=f"m-{i}") for i in range(3)]
    return _FakeResult(members, next_cursor=next_cursor)


# ── get_community ─────────────────────────────────────


async def test_get_community_returns_community_dict(fake_client):
    fake_client.get_community = AsyncMock(
        return_value=_fake_community("comm-1", "Test Comm")
    )
    out = json.loads(await server.get_community("comm-1"))
    fake_client.get_community.assert_awaited_once_with("comm-1")
    assert out["id"] == "comm-1"
    assert out["name"] == "Test Comm"
    assert "description" in out
    assert "member_count" in out
    assert "is_member" in out
    assert "join_policy" in out
    assert "created_at" in out


async def test_get_community_description_truncated_to_200(fake_client):
    long_desc = "d" * 500
    fake_client.get_community = AsyncMock(
        return_value=_fake_community(description=long_desc)
    )
    out = json.loads(await server.get_community("comm-1"))
    assert len(out["description"]) == 200


async def test_get_community_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community("")
    assert "community_id" in str(exc.value)


async def test_get_community_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_community = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_community("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_get_community_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_community = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_community("comm-1")
    assert "rate limit" in str(exc.value).lower()


# ── search_community ──────────────────────────────────


async def test_search_community_returns_community_list(fake_client):
    fake_client.search_community = AsyncMock(
        return_value=_FakeCommunityResult(
            [_fake_community("c1"), _fake_community("c2")], next_cursor="sc-nc"
        )
    )
    out = json.loads(await server.search_community("python"))
    fake_client.search_community.assert_awaited_once_with("python", None)
    assert out["count"] == 2
    assert out["next_cursor"] == "sc-nc"
    assert out["communities"][0]["id"] == "c1"


async def test_search_community_passes_cursor(fake_client):
    fake_client.search_community = AsyncMock(return_value=_FakeCommunityResult([]))
    await server.search_community("python", cursor="abc")
    fake_client.search_community.assert_awaited_once_with("python", "abc")


async def test_search_community_raises_on_empty_query(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_community("")
    assert "query" in str(exc.value)


async def test_search_community_raises_on_whitespace_query(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.search_community("   ")


async def test_search_community_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.search_community = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.search_community("python")
    assert "rate limit" in str(exc.value).lower()


# ── get_community_tweets ──────────────────────────────


async def test_get_community_tweets_returns_compact_tweet_list(fake_client):
    fake_client.get_community_tweets = AsyncMock(
        return_value=_FakeTweetResult(
            [_fake_tweet(tid="t1"), _fake_tweet(tid="t2")], next_cursor="ct-nc"
        )
    )
    out = json.loads(await server.get_community_tweets("comm-1", "Latest", count=10))
    fake_client.get_community_tweets.assert_awaited_once_with(
        "comm-1", "Latest", 10, None
    )
    assert out["count"] == 2
    assert out["next_cursor"] == "ct-nc"
    assert out["tweets"][0]["id"] == "t1"
    assert "author" in out["tweets"][0]
    assert "text" in out["tweets"][0]
    assert "likes" in out["tweets"][0]
    assert "retweets" in out["tweets"][0]


async def test_get_community_tweets_passes_cursor(fake_client):
    fake_client.get_community_tweets = AsyncMock(return_value=_FakeTweetResult([]))
    await server.get_community_tweets("comm-1", "Top", count=5, cursor="pg2")
    fake_client.get_community_tweets.assert_awaited_once_with("comm-1", "Top", 5, "pg2")


async def test_get_community_tweets_truncates_text_to_200(fake_client):
    long_text = "z" * 500
    fake_client.get_community_tweets = AsyncMock(
        return_value=_FakeTweetResult([_fake_tweet(text=long_text)])
    )
    out = json.loads(await server.get_community_tweets("comm-1", "Latest"))
    assert len(out["tweets"][0]["text"]) == 200


async def test_get_community_tweets_rejects_invalid_tweet_type(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_tweets("comm-1", "Invalid")
    assert "Invalid" in str(exc.value) or "tweet_type" in str(exc.value).lower()


async def test_get_community_tweets_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_tweets("", "Latest")
    assert "community_id" in str(exc.value)


async def test_get_community_tweets_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_community_tweets("comm-1", "Latest", count=0)


async def test_get_community_tweets_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_tweets("comm-1", "Latest", count=200)
    assert "100" in str(exc.value)


async def test_get_community_tweets_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_community_tweets = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_community_tweets("comm-ghost", "Latest")
    assert "comm-ghost" in str(exc.value)


async def test_get_community_tweets_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_community_tweets = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_community_tweets("comm-1", "Latest")
    assert "rate limit" in str(exc.value).lower()


# ── get_communities_timeline ──────────────────────────


async def test_get_communities_timeline_returns_compact_tweet_list(fake_client):
    fake_client.get_communities_timeline = AsyncMock(
        return_value=_FakeTweetResult(
            [_fake_tweet(tid="tl1"), _fake_tweet(tid="tl2")], next_cursor="tl-nc"
        )
    )
    out = json.loads(await server.get_communities_timeline(count=10))
    fake_client.get_communities_timeline.assert_awaited_once_with(10, None)
    assert out["count"] == 2
    assert out["next_cursor"] == "tl-nc"
    assert out["tweets"][0]["id"] == "tl1"
    assert "author" in out["tweets"][0]
    assert "text" in out["tweets"][0]


async def test_get_communities_timeline_passes_cursor(fake_client):
    fake_client.get_communities_timeline = AsyncMock(return_value=_FakeTweetResult([]))
    await server.get_communities_timeline(count=5, cursor="tl-pg2")
    fake_client.get_communities_timeline.assert_awaited_once_with(5, "tl-pg2")


async def test_get_communities_timeline_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_communities_timeline(count=0)


async def test_get_communities_timeline_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_communities_timeline(count=200)
    assert "100" in str(exc.value)


async def test_get_communities_timeline_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_communities_timeline = AsyncMock(
        side_effect=TooManyRequests("rate")
    )
    with pytest.raises(ToolError) as exc:
        await server.get_communities_timeline()
    assert "rate limit" in str(exc.value).lower()


# ── get_community_members ─────────────────────────────


async def test_get_community_members_returns_member_list(fake_client):
    fake_client.get_community_members = AsyncMock(
        return_value=_fake_community_members_result(next_cursor="cm-nc")
    )
    out = json.loads(await server.get_community_members("comm-1", count=5))
    fake_client.get_community_members.assert_awaited_once_with("comm-1", 5, None)
    assert "members" in out
    assert out["next_cursor"] == "cm-nc"
    assert out["count"] == len(out["members"])
    # Sanity-check the projected shape — community_role is the discriminator
    # that proves we surfaced CommunityMember fields, not User fields.
    assert "community_role" in out["members"][0]
    assert "description" not in out["members"][0]


async def test_get_community_members_passes_cursor(fake_client):
    fake_client.get_community_members = AsyncMock(
        return_value=_fake_community_members_result()
    )
    await server.get_community_members("comm-1", count=10, cursor="cur-m")
    fake_client.get_community_members.assert_awaited_once_with("comm-1", 10, "cur-m")


async def test_get_community_members_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_members("")
    assert "community_id" in str(exc.value)


async def test_get_community_members_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_community_members("comm-1", count=0)


async def test_get_community_members_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_members("comm-1", count=200)
    assert "100" in str(exc.value)


async def test_get_community_members_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_community_members = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_community_members("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_get_community_members_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_community_members = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.get_community_members("comm-1")
    assert "rate limit" in str(exc.value).lower()


# ── get_community_moderators ──────────────────────────


async def test_get_community_moderators_returns_moderator_list(fake_client):
    fake_client.get_community_moderators = AsyncMock(
        return_value=_fake_community_members_result(next_cursor="mod-nc")
    )
    out = json.loads(await server.get_community_moderators("comm-1", count=5))
    fake_client.get_community_moderators.assert_awaited_once_with("comm-1", 5, None)
    assert "moderators" in out
    assert out["next_cursor"] == "mod-nc"
    assert out["count"] == len(out["moderators"])
    assert "community_role" in out["moderators"][0]
    assert "description" not in out["moderators"][0]


async def test_get_community_moderators_passes_cursor(fake_client):
    fake_client.get_community_moderators = AsyncMock(
        return_value=_fake_community_members_result()
    )
    await server.get_community_moderators("comm-1", count=10, cursor="cur-mod")
    fake_client.get_community_moderators.assert_awaited_once_with(
        "comm-1", 10, "cur-mod"
    )


async def test_get_community_moderators_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_moderators("")
    assert "community_id" in str(exc.value)


async def test_get_community_moderators_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.get_community_moderators("comm-1", count=0)


async def test_get_community_moderators_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.get_community_moderators("comm-1", count=200)
    assert "100" in str(exc.value)


async def test_get_community_moderators_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.get_community_moderators = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.get_community_moderators("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_get_community_moderators_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.get_community_moderators = AsyncMock(
        side_effect=TooManyRequests("rate")
    )
    with pytest.raises(ToolError) as exc:
        await server.get_community_moderators("comm-1")
    assert "rate limit" in str(exc.value).lower()


# ── search_community_tweet ────────────────────────────


async def test_search_community_tweet_returns_compact_tweet_list(fake_client):
    fake_client.search_community_tweet = AsyncMock(
        return_value=_FakeTweetResult(
            [_fake_tweet(tid="st1"), _fake_tweet(tid="st2")], next_cursor="st-nc"
        )
    )
    out = json.loads(await server.search_community_tweet("comm-1", "python", count=10))
    fake_client.search_community_tweet.assert_awaited_once_with(
        "comm-1", "python", 10, None
    )
    assert out["count"] == 2
    assert out["next_cursor"] == "st-nc"
    assert out["tweets"][0]["id"] == "st1"
    assert "author" in out["tweets"][0]
    assert "text" in out["tweets"][0]


async def test_search_community_tweet_passes_cursor(fake_client):
    fake_client.search_community_tweet = AsyncMock(return_value=_FakeTweetResult([]))
    await server.search_community_tweet("comm-1", "python", count=5, cursor="st-pg2")
    fake_client.search_community_tweet.assert_awaited_once_with(
        "comm-1", "python", 5, "st-pg2"
    )


async def test_search_community_tweet_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_community_tweet("", "python")
    assert "community_id" in str(exc.value)


async def test_search_community_tweet_raises_on_empty_query(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_community_tweet("comm-1", "")
    assert "query" in str(exc.value)


async def test_search_community_tweet_raises_on_whitespace_query(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.search_community_tweet("comm-1", "   ")


async def test_search_community_tweet_raises_on_count_too_low(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError):
        await server.search_community_tweet("comm-1", "python", count=0)


async def test_search_community_tweet_raises_on_count_too_high(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.search_community_tweet("comm-1", "python", count=200)
    assert "100" in str(exc.value)


async def test_search_community_tweet_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.search_community_tweet = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.search_community_tweet("comm-ghost", "python")
    assert "comm-ghost" in str(exc.value)


async def test_search_community_tweet_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.search_community_tweet = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.search_community_tweet("comm-1", "python")
    assert "rate limit" in str(exc.value).lower()


# ── join_community ────────────────────────────────────


async def test_join_community_returns_community_dict_with_status(fake_client):
    fake_client.join_community = AsyncMock(return_value=_fake_community("comm-1"))
    out = json.loads(await server.join_community("comm-1"))
    fake_client.join_community.assert_awaited_once_with("comm-1")
    assert out["id"] == "comm-1"
    assert out["status"] == "joined"
    assert "name" in out
    assert "description" in out
    assert "member_count" in out


async def test_join_community_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.join_community("")
    assert "community_id" in str(exc.value)


async def test_join_community_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.join_community = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.join_community("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_join_community_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.join_community = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.join_community("comm-1")
    assert "rate limit" in str(exc.value).lower()


# ── leave_community ───────────────────────────────────


async def test_leave_community_returns_community_dict_with_status(fake_client):
    fake_client.leave_community = AsyncMock(return_value=_fake_community("comm-1"))
    out = json.loads(await server.leave_community("comm-1"))
    fake_client.leave_community.assert_awaited_once_with("comm-1")
    assert out["id"] == "comm-1"
    assert out["status"] == "left"
    assert "name" in out


async def test_leave_community_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.leave_community("")
    assert "community_id" in str(exc.value)


async def test_leave_community_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.leave_community = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.leave_community("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_leave_community_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.leave_community = AsyncMock(side_effect=TooManyRequests("rate"))
    with pytest.raises(ToolError) as exc:
        await server.leave_community("comm-1")
    assert "rate limit" in str(exc.value).lower()


# ── request_to_join_community ─────────────────────────


async def test_request_to_join_community_returns_status(fake_client):
    fake_client.request_to_join_community = AsyncMock(
        return_value=_fake_community("comm-1")
    )
    out = json.loads(await server.request_to_join_community("comm-1"))
    fake_client.request_to_join_community.assert_awaited_once_with("comm-1", None)
    assert out["community_id"] == "comm-1"
    assert out["status"] == "request_sent"


async def test_request_to_join_community_passes_answer(fake_client):
    fake_client.request_to_join_community = AsyncMock(
        return_value=_fake_community("comm-1")
    )
    await server.request_to_join_community("comm-1", answer="My answer")
    fake_client.request_to_join_community.assert_awaited_once_with(
        "comm-1", "My answer"
    )


async def test_request_to_join_community_raises_on_empty_community_id(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    with pytest.raises(ToolError) as exc:
        await server.request_to_join_community("")
    assert "community_id" in str(exc.value)


async def test_request_to_join_community_raises_clean_on_not_found(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import NotFound

    fake_client.request_to_join_community = AsyncMock(side_effect=NotFound("nope"))
    with pytest.raises(ToolError) as exc:
        await server.request_to_join_community("comm-ghost")
    assert "comm-ghost" in str(exc.value)


async def test_request_to_join_community_raises_clean_on_rate_limit(fake_client):
    from mcp.server.fastmcp.exceptions import ToolError

    from twitter_mcp._vendor.twikit.errors import TooManyRequests

    fake_client.request_to_join_community = AsyncMock(
        side_effect=TooManyRequests("rate")
    )
    with pytest.raises(ToolError) as exc:
        await server.request_to_join_community("comm-1")
    assert "rate limit" in str(exc.value).lower()
