"""Generic modal picker for selecting an item by ID.

Used for slash-command list views (e.g. /actions list, /runs list) so the
list UI is separate from the main chat timeline.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import DataTable, OptionList, Static
from textual.widgets.option_list import Option

from textual.events import (
    MouseScrollDown,
    MouseScrollLeft,
    MouseScrollRight,
    MouseScrollUp,
)


class _IdPickerDataTable(DataTable):
    """DataTable that supports horizontal trackpad / shift-scroll gestures.

    Notes:
    - Some terminals emit horizontal scrolling as MouseScrollLeft/Right events.
    - Some emit MouseScrollDown/Up with delta_x set.
    - Some map horizontal scrolling to Shift+wheel (shift=True with delta_y).

    We handle all of the above so the IdPicker table can be scrolled horizontally
    with a touchpad when the terminal supports it.
    """

    _H_SCROLL_MULTIPLIER = 4

    def _scroll_x(self, dx: int) -> None:
        if dx == 0:
            return
        self.scroll_relative(x=dx * self._H_SCROLL_MULTIPLIER, y=0, animate=False)

    def _try_handle_horizontal_from_delta(
        self, delta_x: int, *, shift: bool, delta_y: int
    ) -> bool:
        dx = delta_x
        if dx == 0 and shift and delta_y != 0:
            dx = delta_y
        if dx == 0:
            return False
        self._scroll_x(dx)
        return True

    def _on_mouse_scroll_down(self, event: MouseScrollDown) -> None:
        if self._try_handle_horizontal_from_delta(
            event.delta_x, shift=event.shift, delta_y=event.delta_y
        ):
            event.stop()
            return
        return super()._on_mouse_scroll_down(event)

    def _on_mouse_scroll_up(self, event: MouseScrollUp) -> None:
        if self._try_handle_horizontal_from_delta(
            event.delta_x, shift=event.shift, delta_y=event.delta_y
        ):
            event.stop()
            return
        return super()._on_mouse_scroll_up(event)

    def _on_mouse_scroll_left(self, event: MouseScrollLeft) -> None:
        # Ensure negative direction regardless of terminal conventions.
        dx = event.delta_x or -1
        self._scroll_x(-abs(dx))
        event.stop()

    def _on_mouse_scroll_right(self, event: MouseScrollRight) -> None:
        # Ensure positive direction regardless of terminal conventions.
        dx = event.delta_x or 1
        self._scroll_x(abs(dx))
        event.stop()



class IdPickerScreen(ModalScreen[str]):
    """Modal that lets the user pick an item (returns its ID).

    - Returns the selected ID.
    - Returns an empty string if cancelled.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
        Binding("ctrl+left", "hscroll_left", "Scroll left", show=False),
        Binding("ctrl+right", "hscroll_right", "Scroll right", show=False),
    ]
    CSS = """
    IdPickerScreen {
        align: center middle;
    }

    #idpicker-container {
        width: 90;
        height: 90%;
        background: $primary-background;
        border: solid $accent;
        padding: 0 1;
    }

    #idpicker-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        background: $primary-background;
        height: 1;
        margin-bottom: 0;
    }

    #idpicker-table {
        height: 1fr;
        width: 100%;
        background: $primary-background;
        /* Slightly dim the row text so it's easier on the eyes. */
        color: $foreground 80%;
        border: none;
        overflow-x: auto;
        overflow-y: auto;
        scrollbar-gutter: auto;
        scrollbar-background: $primary-background;
        scrollbar-background-hover: $primary-background;
        scrollbar-background-active: $primary-background;
        scrollbar-corner-color: $primary-background;
        scrollbar-color: $panel;
        scrollbar-color-hover: $primary;
        scrollbar-color-active: $primary;
        scrollbar-size-vertical: 1;
        scrollbar-size-horizontal: 1;
        padding: 0 1;
    }


    /* Softer column-header styling (avoid the high-contrast cyan/white look). */
    #idpicker-table > .datatable--header {
        background: $brand-cyan;
        color: black;
    }
    /* Override Textual's ANSI-mode defaults (it makes headers bright blue by default). */
    #idpicker-table:ansi > .datatable--header {
        background: $brand-cyan;
        color: black;
    }
    #idpicker-table > .datatable--header-cursor {
        background: $brand-cyan;
        color: black;
    }
    #idpicker-table > .datatable--header-hover {
        background: $brand-cyan;
    }
    #idpicker-list {
        height: 1fr;
        width: 100%;
        border: none;
        overflow-x: auto;
        overflow-y: auto;
        scrollbar-gutter: auto;
        scrollbar-background: $primary-background;
        scrollbar-background-hover: $primary-background;
        scrollbar-background-active: $primary-background;
        scrollbar-corner-color: $primary-background;
        scrollbar-color: $panel;
        scrollbar-color-hover: $primary;
        scrollbar-color-active: $primary;
        scrollbar-size-vertical: 1;
        scrollbar-size-horizontal: 1;
        padding: 0 1;
    }
    """

    def __init__(
        self,
        title: str,
        options: list[tuple[str, str]] | None = None,
        *,
        columns: list[str] | None = None,
        rows: list[tuple[str, list[str] | tuple[str, ...]]] | None = None,
    ):
        super().__init__()
        self._title = title
        self._options = options or []
        self._columns = columns
        self._rows = rows

    def compose(self) -> ComposeResult:
        with Vertical(id="idpicker-container"):
            yield Static(self._title, id="idpicker-title")
            if self._columns is not None and self._rows is not None:
                table = _IdPickerDataTable(id="idpicker-table", zebra_stripes=True)
                # Add a bit of breathing room between columns for readability.
                table.cell_padding = 2
                table.cursor_type = "row"
                table.add_columns(*self._columns)
                for item_id, cells in self._rows:
                    table.add_row(*list(cells), key=item_id)
                yield table
            else:
                option_list = OptionList(id="idpicker-list")
                for item_id, label in self._options:
                    # Option.id is independent of widget IDs; it only needs to be unique in this list.
                    option_list.add_option(Option(label, id=item_id))
                yield option_list

    def on_mount(self) -> None:
        """Focus the primary list widget."""
        try:
            if self._columns is not None and self._rows is not None:
                self.query_one("#idpicker-table", DataTable).focus()
            else:
                self.query_one("#idpicker-list", OptionList).focus()
        except Exception:
            # Don't crash the modal due to focus issues.
            pass

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(event.option.id or "")

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        key = getattr(event.row_key, "value", None)
        self.dismiss(key or "")


    def action_hscroll_left(self) -> None:
        """Scroll the table horizontally to the left (Ctrl+Left)."""
        try:
            table = self.query_one("#idpicker-table", DataTable)
        except Exception:
            return
        table.scroll_relative(x=-10, y=0, animate=False)

    def action_hscroll_right(self) -> None:
        """Scroll the table horizontally to the right (Ctrl+Right)."""
        try:
            table = self.query_one("#idpicker-table", DataTable)
        except Exception:
            return
        table.scroll_relative(x=10, y=0, animate=False)
    def action_cancel(self) -> None:
        self.dismiss("")
