"""Command result modal screen.

Goal: keep slash-command output out of the main chat timeline.

- Esc closes the modal.
- Intended for any non-interactive slash command that returns text output.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Markdown, Static


class CommandResultScreen(ModalScreen[None]):
    """Modal showing a command's output."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
    ]

    CSS = """
    CommandResultScreen {
        align: center middle;
    }

    #cmdres-container {
        width: 90;
        height: 80%;
        background: $primary-background;
        border: solid $accent;
        padding: 1 2;
    }

    #cmdres-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: auto;
        margin-bottom: 1;
    }

    #cmdres-body {
        height: 1fr;
        width: 100%;
        border: solid $panel;
        padding: 1 1;
        overflow: auto;
    }

    #cmdres-footer {
        width: 100%;
        height: auto;
        margin-top: 1;
        content-align: right middle;
    }

    .cmdres-error {
        border: solid $error;
    }

    .cmdres-error #cmdres-title {
        color: $error;
    }
    """

    def __init__(self, title: str, body: str, *, is_error: bool = False):
        super().__init__()
        self._title = title
        self._body = body
        self._is_error = is_error

    def compose(self) -> ComposeResult:
        container_id = "cmdres-container"
        with Vertical(id=container_id, classes="cmdres-error" if self._is_error else ""):
            yield Static(self._title, id="cmdres-title")
            yield Markdown(self._body or "(no output)", id="cmdres-body")
            with Horizontal(id="cmdres-footer"):
                yield Button("Close", id="cmdres-close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cmdres-close":
            self.dismiss(None)

    def action_close(self) -> None:
        self.dismiss(None)
