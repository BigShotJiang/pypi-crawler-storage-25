from textual.css.stylesheet import Stylesheet
from pathlib import Path

from kiwi_tui.main import AutobotsTUI
from kiwi_tui.screens.attach_content import AttachContentScreen
from kiwi_tui.screens.command_result import CommandResultScreen
from kiwi_tui.screens.file_browser import FileBrowserScreen
from kiwi_tui.screens.help import HelpScreen
from kiwi_tui.screens.id_picker import IdPickerScreen
from kiwi_tui.screens.slash_picker import SlashPickerScreen


def test_tui_dark_palette_vars(isolated_home: Path, monkeypatch) -> None:
    app = AutobotsTUI()
    monkeypatch.setattr(app, "_is_dark_theme", lambda: True)

    variables = app.get_css_variables()

    assert variables["background"] == "#1E1E1E"
    assert variables["surface"] == "#252526"
    assert variables["boost"] == "#2D2D2D"
    assert variables["panel"] == "#333333"
    assert variables["foreground"] == "#F3F3F3"
    assert variables["user-msg-bg"] == "#3A3A3A"
    assert variables["assistant-stream-bg"] == "#252526"


def test_tui_light_palette_vars(isolated_home: Path, monkeypatch) -> None:
    app = AutobotsTUI()
    monkeypatch.setattr(app, "_is_dark_theme", lambda: False)

    variables = app.get_css_variables()

    assert variables["background"] == "#f6f7f8"
    assert variables["surface"] == "#ffffff"
    assert variables["boost"] == "#eef1f3"
    assert variables["panel"] == "#dbe7ea"
    assert variables["foreground"] == "#101213"
    assert variables["user-msg-bg"] == "#f1f3f4"
    assert variables["assistant-stream-bg"] == "#f4f6f7"


def test_slash_related_modals_use_primary_background() -> None:
    css_blocks = {
        "slash_picker": SlashPickerScreen.CSS,
        "help": HelpScreen.CSS,
        "id_picker": IdPickerScreen.CSS,
        "command_result": CommandResultScreen.CSS,
        "attach_content": AttachContentScreen.CSS,
        "file_browser": FileBrowserScreen.CSS,
    }

    for name, css in css_blocks.items():
        assert "$primary-background" in css, f"{name} should use the shared modal background"


def test_file_browser_css_parses(isolated_home: Path) -> None:
    app = AutobotsTUI()
    sheet = Stylesheet(variables=app.get_css_variables())
    sheet.add_source(FileBrowserScreen.CSS, read_from=("file_browser.py", "FileBrowserScreen.CSS"))
    sheet.parse()


def test_file_browser_tree_hover_styling_is_softened() -> None:
    css = FileBrowserScreen.CSS
    assert "#dir-tree > .tree--highlight-line" in css
    assert "#dir-tree > .tree--cursor" in css
    assert "background-tint: 0%" in css
