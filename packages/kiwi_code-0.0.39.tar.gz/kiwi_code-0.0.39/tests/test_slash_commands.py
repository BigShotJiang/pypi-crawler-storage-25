from kiwi_cli.commands import HELP_TEXT
from kiwi_tui.slash_commands import SLASH_COMMANDS


def test_slash_commands_lists_autocode_select_with_updated_description() -> None:
    command = next(cmd for cmd in SLASH_COMMANDS if cmd.template == "/autocode-select")
    assert command.description == "Choose the version of AutoCode you wish to use"


def test_cli_help_text_lists_autocode_select_with_updated_description() -> None:
    assert "/autocode-select     Choose the version of AutoCode you wish to use" in HELP_TEXT
