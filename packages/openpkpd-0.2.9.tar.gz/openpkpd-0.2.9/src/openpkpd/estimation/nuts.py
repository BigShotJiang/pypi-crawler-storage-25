"""
No-U-Turn Sampler (NUTS) — pure NumPy/SciPy implementation.

Implements the NUTS algorithm with dual averaging step-size adaptation
(Algorithm 6 from Hoffman & Gelman 2014) entirely in NumPy. No external
autodiff or accelerator stack is required.

The sampler can be used standalone or as the ``'nuts'`` backend for
:class:`~openpkpd.estimation.bayes.BAYESMethod`.

Usage::

    from openpkpd.estimation.nuts import NUTSSampler

    sampler = NUTSSampler(log_prob_fn, grad_log_prob_fn)
    samples = sampler.sample(
        init_theta=np.array([1.5, 0.1, 30.0]),
        n_samples=1000,
        n_warmup=500,
    )
    print(samples.shape)   # (1000, 3)

References
----------
Hoffman, M.D. & Gelman, A. (2014). The No-U-Turn Sampler: Adaptively
    setting path lengths in Hamiltonian Monte Carlo. JMLR 15:1593-1623.
"""

from __future__ import annotations

from collections import OrderedDict
from collections.abc import Callable

import numpy as np

# ---------------------------------------------------------------------------
# Leapfrog integrator
# ---------------------------------------------------------------------------


def _leapfrog(
    theta: np.ndarray,
    r: np.ndarray,
    grad_log_prob: Callable[[np.ndarray], np.ndarray],
    step_size: float,
    n_steps: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Leapfrog integrator for Hamiltonian dynamics.

    Args:
        theta:         Current position (parameters).
        r:             Current momentum.
        grad_log_prob: Gradient of log p(theta) w.r.t. theta.
        step_size:     Leapfrog step size epsilon.
        n_steps:       Number of leapfrog steps.

    Returns:
        (theta_new, r_new) after *n_steps* steps.
    """
    r = r + 0.5 * step_size * grad_log_prob(theta)
    for _ in range(n_steps - 1):
        theta = theta + step_size * r
        r = r + step_size * grad_log_prob(theta)
    theta = theta + step_size * r
    r = r + 0.5 * step_size * grad_log_prob(theta)
    return theta, r


# ---------------------------------------------------------------------------
# NUTS tree building (Algorithm 3 from Hoffman & Gelman 2014)
# ---------------------------------------------------------------------------


def _build_tree(
    theta: np.ndarray,
    r: np.ndarray,
    log_u: float,
    v: int,
    j: int,
    step_size: float,
    log_prob: Callable[[np.ndarray], float],
    grad_log_prob: Callable[[np.ndarray], np.ndarray],
    joint_log_prob: Callable[[np.ndarray, np.ndarray], float],
    delta_max: float,
    rng: np.random.Generator,
    joint0: float | None = None,
) -> tuple:
    """
    Recursively build a NUTS binary tree.

    Returns:
        (theta_minus, r_minus, theta_plus, r_plus,
         theta_prime, n_prime, s_prime, alpha_prime, n_alpha_prime)
    """
    if j == 0:
        # Base case: single leapfrog step
        theta_prime, r_prime = _leapfrog(theta, r, grad_log_prob, v * step_size, 1)
        joint = joint_log_prob(theta_prime, r_prime)
        if joint0 is None:
            joint0 = joint_log_prob(theta, r)
        n_prime = int(log_u <= joint)
        s_prime = int(joint > log_u - delta_max)
        alpha_prime = min(1.0, np.exp(joint - joint0))
        return (
            theta_prime,
            r_prime,
            theta_prime,
            r_prime,
            theta_prime,
            n_prime,
            s_prime,
            alpha_prime,
            1,
        )

    # Recursion
    (
        theta_minus,
        r_minus,
        theta_plus,
        r_plus,
        theta_prime,
        n_prime,
        s_prime,
        alpha_prime,
        n_alpha_prime,
    ) = _build_tree(
        theta,
        r,
        log_u,
        v,
        j - 1,
        step_size,
        log_prob,
        grad_log_prob,
        joint_log_prob,
        delta_max,
        rng,
        joint0,
    )

    if s_prime:
        if v == -1:
            (
                theta_minus,
                r_minus,
                _,
                _,
                theta_double_prime,
                n_double_prime,
                s_double_prime,
                alpha_double_prime,
                n_alpha_double_prime,
            ) = _build_tree(
                theta_minus,
                r_minus,
                log_u,
                v,
                j - 1,
                step_size,
                log_prob,
                grad_log_prob,
                joint_log_prob,
                delta_max,
                rng,
                joint0,
            )
        else:
            (
                _,
                _,
                theta_plus,
                r_plus,
                theta_double_prime,
                n_double_prime,
                s_double_prime,
                alpha_double_prime,
                n_alpha_double_prime,
            ) = _build_tree(
                theta_plus,
                r_plus,
                log_u,
                v,
                j - 1,
                step_size,
                log_prob,
                grad_log_prob,
                joint_log_prob,
                delta_max,
                rng,
                joint0,
            )

        if n_prime > 0:
            accept_prob = n_double_prime / (n_prime + n_double_prime)
        else:
            accept_prob = 1.0 if n_double_prime > 0 else 0.0

        if rng.uniform() < accept_prob:
            theta_prime = theta_double_prime

        alpha_prime = alpha_prime + alpha_double_prime
        n_alpha_prime = n_alpha_prime + n_alpha_double_prime
        n_prime = n_prime + n_double_prime

        # No-U-Turn condition
        delta_theta = theta_plus - theta_minus
        s_prime = int(
            s_double_prime
            and np.dot(delta_theta, r_minus) >= 0
            and np.dot(delta_theta, r_plus) >= 0
        )

    return (
        theta_minus,
        r_minus,
        theta_plus,
        r_plus,
        theta_prime,
        n_prime,
        s_prime,
        alpha_prime,
        n_alpha_prime,
    )


# ---------------------------------------------------------------------------
# NUTSSampler
# ---------------------------------------------------------------------------


class NUTSSampler:
    """
    No-U-Turn Sampler with dual averaging step-size adaptation.

    Args:
        log_prob_fn:      Function returning the log-probability of theta.
                          Signature: ``(theta: np.ndarray) -> float``.
        grad_log_prob_fn: Function returning the gradient of log p(theta).
                          Signature: ``(theta: np.ndarray) -> np.ndarray``.
                          If None, a finite-difference approximation is used
                          (slower but requires no analytic gradient).
        delta:            Target acceptance probability for dual averaging
                          (default 0.65, NUTS recommended value).
        max_tree_depth:   Maximum binary tree depth (default 10 → 2^10 steps).
        delta_max:        Max energy deviation allowed (default 1000).
        fd_step:          Finite-difference step size (used only when
                          grad_log_prob_fn is None).
        seed:             Random seed for reproducibility.
    """

    def __init__(
        self,
        log_prob_fn: Callable[[np.ndarray], float],
        grad_log_prob_fn: Callable[[np.ndarray], np.ndarray] | None = None,
        *,
        delta: float = 0.65,
        max_tree_depth: int = 10,
        delta_max: float = 1000.0,
        fd_step: float = 1e-5,
        log_prob_cache_size: int = 4096,
        seed: int | None = None,
    ) -> None:
        self._log_prob_raw = log_prob_fn
        self._delta = delta
        self._max_tree_depth = max_tree_depth
        self._delta_max = delta_max
        self._fd_step = fd_step
        self._log_prob_cache_size = max(int(log_prob_cache_size), 0)
        self._log_prob_cache: OrderedDict[bytes, float] = OrderedDict()
        self._log_prob_cache_hits = 0
        self._log_prob_cache_misses = 0
        # H-07: use an instance-level Generator so concurrent NUTSSampler
        # instances cannot corrupt each other's random state.
        self._rng = np.random.default_rng(seed)

        if grad_log_prob_fn is not None:
            self._grad_log_prob = grad_log_prob_fn
            self._uses_fd_gradient = False
        else:
            self._grad_log_prob = self._fd_gradient
            self._uses_fd_gradient = True
        self.last_diagnostics: dict[str, float | int | bool] = {}

    def _reset_log_prob_cache(self) -> None:
        self._log_prob_cache.clear()
        self._log_prob_cache_hits = 0
        self._log_prob_cache_misses = 0

    def _cached_log_prob(self, theta: np.ndarray) -> float:
        theta_arr = np.asarray(theta, dtype=float)
        key = theta_arr.tobytes()
        cached = self._log_prob_cache.get(key)
        if cached is not None:
            self._log_prob_cache.move_to_end(key)
            self._log_prob_cache_hits += 1
            return cached

        value = float(self._log_prob_raw(theta_arr))
        self._log_prob_cache_misses += 1
        if self._log_prob_cache_size > 0:
            self._log_prob_cache[key] = value
            self._log_prob_cache.move_to_end(key)
            if len(self._log_prob_cache) > self._log_prob_cache_size:
                self._log_prob_cache.popitem(last=False)
        return value

    def _fd_gradient(self, theta: np.ndarray) -> np.ndarray:
        """Finite-difference gradient approximation."""
        grad = np.zeros_like(theta)
        f0 = self._cached_log_prob(theta)
        for i in range(len(theta)):
            th_p = theta.copy()
            th_p[i] += self._fd_step
            grad[i] = (self._cached_log_prob(th_p) - f0) / self._fd_step
        return grad

    def _joint_log_prob(self, theta: np.ndarray, r: np.ndarray) -> float:
        """Joint log-probability: log p(theta) - 0.5 * r^T r."""
        return float(self._cached_log_prob(theta)) - 0.5 * float(np.dot(r, r))

    def sample(
        self,
        init_theta: np.ndarray,
        n_samples: int = 1000,
        n_warmup: int = 500,
        init_step_size: float = 0.1,
    ) -> np.ndarray:
        """
        Draw samples from the target distribution.

        Warm-up phase uses dual averaging to adapt the step size.
        Post-warm-up samples use the fixed adapted step size.

        Args:
            init_theta:     Initial parameter values, shape (n_params,).
            n_samples:      Number of post-warm-up samples to return.
            n_warmup:       Number of warm-up (adaptation) steps (discarded).
            init_step_size: Initial leapfrog step size.

        Returns:
            Sample array of shape (n_samples, n_params).
        """
        theta = np.asarray(init_theta, dtype=float).copy()
        n_params = len(theta)
        self._reset_log_prob_cache()

        # Dual averaging parameters (Nesterov 2009 / Hoffman & Gelman 2014)
        mu = np.log(10 * init_step_size)
        log_eps_bar = 0.0
        h_bar = 0.0
        gamma = 0.05
        t0 = 10.0
        kappa = 0.75
        epsilon = init_step_size

        samples: list[np.ndarray] = []
        total_steps = n_warmup + n_samples
        tree_depths: list[int] = []
        accept_stats: list[float] = []
        max_depth_hits = 0
        total_leaf_evals = 0

        for m in range(1, total_steps + 1):
            # Sample fresh momentum
            r0 = self._rng.standard_normal(n_params)
            joint0 = self._joint_log_prob(theta, r0)

            # Slice variable
            log_u = joint0 - self._rng.exponential(1.0)

            # Build NUTS tree
            theta_minus = theta.copy()
            theta_plus = theta.copy()
            r_minus = r0.copy()
            r_plus = r0.copy()
            n_accepted = 1
            s = 1
            theta_m = theta.copy()
            alpha_sum = 0.0
            n_alpha = 0

            j = 0
            while s and j < self._max_tree_depth:
                v = 1 if self._rng.uniform() > 0.5 else -1
                if v == -1:
                    (
                        theta_minus,
                        r_minus,
                        _,
                        _,
                        theta_prime,
                        n_prime,
                        s_prime,
                        alpha_prime,
                        n_alpha_prime,
                    ) = _build_tree(
                        theta_minus,
                        r_minus,
                        log_u,
                        v,
                        j,
                        epsilon,
                        self._cached_log_prob,
                        self._grad_log_prob,
                        self._joint_log_prob,
                        self._delta_max,
                        self._rng,
                        joint0,
                    )
                else:
                    (
                        _,
                        _,
                        theta_plus,
                        r_plus,
                        theta_prime,
                        n_prime,
                        s_prime,
                        alpha_prime,
                        n_alpha_prime,
                    ) = _build_tree(
                        theta_plus,
                        r_plus,
                        log_u,
                        v,
                        j,
                        epsilon,
                        self._cached_log_prob,
                        self._grad_log_prob,
                        self._joint_log_prob,
                        self._delta_max,
                        self._rng,
                        joint0,
                    )

                if s_prime:
                    # Sample from the newly expanded tree in proportion to the
                    # number of valid states it contributes relative to the
                    # states already accumulated. Using only the previous count
                    # in the denominator biases selection toward later
                    # subtrees and can skew the chain.
                    accept = min(1.0, n_prime / max(n_accepted + n_prime, 1))
                    if self._rng.uniform() < accept:
                        theta_m = theta_prime

                n_accepted += n_prime
                alpha_sum += alpha_prime
                n_alpha += n_alpha_prime

                # No-U-Turn stop
                delta_theta = theta_plus - theta_minus
                s = int(
                    s_prime
                    and np.dot(delta_theta, r_minus) >= 0
                    and np.dot(delta_theta, r_plus) >= 0
                )
                j += 1

            theta = theta_m
            if j >= self._max_tree_depth:
                max_depth_hits += 1
            tree_depths.append(j)
            alpha_bar = alpha_sum / max(n_alpha, 1)
            accept_stats.append(alpha_bar)
            total_leaf_evals += int(n_alpha)

            # Dual averaging step-size adaptation during warm-up
            if m <= n_warmup:
                h_bar = (1 - 1.0 / (m + t0)) * h_bar + (self._delta - alpha_bar) / (m + t0)
                log_eps = mu - np.sqrt(m) / gamma * h_bar
                log_eps_bar = m ** (-kappa) * log_eps + (1 - m ** (-kappa)) * log_eps_bar
                epsilon = np.exp(log_eps)
            else:
                epsilon = np.exp(log_eps_bar)
                samples.append(theta.copy())

        warmup_depths = tree_depths[:n_warmup]
        sample_depths = tree_depths[n_warmup:]
        warmup_accept = accept_stats[:n_warmup]
        sample_accept = accept_stats[n_warmup:]
        self.last_diagnostics = {
            "n_warmup": int(n_warmup),
            "n_samples": int(n_samples),
            "step_size_initial": float(init_step_size),
            "step_size_final": float(np.exp(log_eps_bar)),
            "target_accept": float(self._delta),
            "max_tree_depth": int(self._max_tree_depth),
            "max_tree_depth_hit_count": int(max_depth_hits),
            "max_tree_depth_hit_fraction": float(max_depth_hits / max(total_steps, 1)),
            "mean_tree_depth_warmup": float(np.mean(warmup_depths)) if warmup_depths else 0.0,
            "mean_tree_depth_sampling": float(np.mean(sample_depths)) if sample_depths else 0.0,
            "mean_accept_stat_warmup": float(np.mean(warmup_accept)) if warmup_accept else 0.0,
            "mean_accept_stat_sampling": float(np.mean(sample_accept)) if sample_accept else 0.0,
            "total_leaf_evaluations": int(total_leaf_evals),
            "used_fd_gradient": bool(self._uses_fd_gradient),
            "log_prob_cache_hits": int(self._log_prob_cache_hits),
            "log_prob_cache_misses": int(self._log_prob_cache_misses),
            "unique_log_prob_evals": int(self._log_prob_cache_misses),
        }
        return np.array(samples)


# ---------------------------------------------------------------------------
# Integration with BAYESMethod
# ---------------------------------------------------------------------------


def nuts_estimate(
    log_prob_fn: Callable[[np.ndarray], float],
    init_theta: np.ndarray,
    n_samples: int = 1000,
    n_warmup: int = 500,
    delta: float = 0.65,
    seed: int = 42,
) -> dict:
    """
    Run the NUTS sampler and return a summary dict compatible with
    :class:`~openpkpd.estimation.bayes.BayesianResult`.

    Args:
        log_prob_fn:  Log-probability function.
        init_theta:   Initial parameter vector.
        n_samples:    Number of posterior samples to collect.
        n_warmup:     Number of warm-up (adaptation) samples.
        delta:        Target acceptance probability.
        seed:         Random seed.

    Returns:
        Dict with keys:

        - ``samples``: posterior draws (``n_samples × n_params``)
        - ``r_hat``: ``NaN`` per parameter because the standalone helper is
          single-chain and cannot compute a meaningful Gelman-Rubin diagnostic
        - ``n_effective``: rough single-chain ESS estimate
        - ``backend_used``: ``"nuts"``
        - ``n_chains``: always ``1`` for this helper
        - ``diagnostics_note``: explicit note describing the single-chain
          diagnostic limitation
    """
    sampler = NUTSSampler(log_prob_fn, delta=delta, seed=seed)
    samples = sampler.sample(init_theta, n_samples=n_samples, n_warmup=n_warmup)

    # Rough effective sample size via autocorrelation lag-1 estimate
    n_eff = []
    for k in range(samples.shape[1]):
        col = samples[:, k]
        if col.std() < 1e-10:
            n_eff.append(0)
            continue
        col_norm = col - col.mean()
        ac1 = float(np.corrcoef(col_norm[:-1], col_norm[1:])[0, 1]) if len(col) > 1 else 0.0
        rho = max(min(ac1, 0.9999), -0.9999)
        neff = int(len(col) * (1 - rho) / (1 + rho))
        n_eff.append(max(neff, 1))

    diagnostics_note = (
        "Standalone nuts_estimate() runs a single chain. R-hat is undefined in this mode; "
        "use BAYESMethod(backend='nuts', n_chains>=2) for multi-chain diagnostics."
    )

    return {
        "samples": samples,
        "r_hat": np.full(samples.shape[1], np.nan),
        "n_effective": np.array(n_eff),
        "backend_used": "nuts",
        "n_chains": 1,
        "diagnostics_note": diagnostics_note,
    }
