"""Workspace resolution owners for automation-facing gateway flows."""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from fastapi import Request

from obra.gateway.session_helpers import _validate_working_dir

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class WorkspaceResolution:
    """Resolved project/workspace launch context."""

    project_id: str
    working_dir: str
    source: str
    stored_working_dir: str | None = None

    def to_payload(self) -> dict[str, str | None]:
        return {
            "project_id": self.project_id,
            "working_dir": self.working_dir,
            "source": self.source,
            "stored_working_dir": self.stored_working_dir,
        }


def resolve_gateway_workspace(
    *,
    project_id: str,
    working_dir: str | None,
    allowed_base: Path | None = None,
    client_factory: Callable[[], Any] | None = None,
) -> WorkspaceResolution:
    """Resolve the canonical gateway workspace.

    When *allowed_base* is provided (automation workspaces), the resolved
    path must fall within it.  Interactive callers pass ``None`` to skip
    the base-path restriction — OS filesystem permissions are the
    access-control layer for user-chosen paths.
    """
    normalized_project_id = _normalize_required_string(project_id, field_name="project_id")
    allowed_base_resolved = allowed_base.expanduser().resolve() if allowed_base is not None else None

    explicit_working_dir = _normalize_optional_string(working_dir)
    if explicit_working_dir is not None:
        resolved = _validate_working_dir(explicit_working_dir, allowed_base_resolved)
        return WorkspaceResolution(
            project_id=normalized_project_id,
            working_dir=str(resolved),
            source="explicit_working_dir",
        )

    project_metadata_dir = _resolve_project_metadata_working_dir(
        normalized_project_id,
        allowed_base=allowed_base_resolved,
        client_factory=client_factory,
    )
    if project_metadata_dir is not None:
        return WorkspaceResolution(
            project_id=normalized_project_id,
            working_dir=str(project_metadata_dir),
            source="project_metadata",
            stored_working_dir=str(project_metadata_dir),
        )

    if allowed_base_resolved is not None:
        candidate = allowed_base_resolved / normalized_project_id
        if candidate.exists():
            resolved = _validate_working_dir(str(candidate), allowed_base_resolved)
            return WorkspaceResolution(
                project_id=normalized_project_id,
                working_dir=str(resolved),
                source="allowed_base_project_id",
            )

    raise ValueError(
        f"No working directory is configured for project '{normalized_project_id}'. "
        "Set the project's working_directory or pass working_dir explicitly."
    )


def resolve_gateway_workspace_from_request(
    request: Request,
    *,
    project_id: str,
    working_dir: str | None,
) -> WorkspaceResolution:
    """Resolve workspace precedence from request-bound gateway state."""
    gateway_config = getattr(request.app.state, "gateway_config", {})
    allowed_base = Path(str(gateway_config.get("allowed_working_dir_base", "~/obra-projects")))
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    return resolve_gateway_workspace(
        project_id=project_id,
        working_dir=working_dir,
        allowed_base=allowed_base,
        client_factory=client_factory if callable(client_factory) else None,
    )


def provision_run_workspace(
    *,
    project_dir: Path,
    run_id: str,
    workflow_id: str | None,
    input_manifest: list[str] | None,
    input_payload: dict[str, str] | None,
    allowed_base: Path,
) -> Path:
    """Create an isolated run workspace and stage input files.

    Returns the path to the provisioned run workspace directory.
    """
    run_workspace = project_dir / "runs" / run_id
    run_workspace.mkdir(parents=True, exist_ok=False)

    if workflow_id:
        workflow_source = project_dir / ".obra-biz" / "workflows" / workflow_id
        if workflow_source.is_dir():
            workflow_dest = run_workspace / ".obra-biz" / "workflows" / workflow_id
            shutil.copytree(workflow_source, workflow_dest)

    for relative_path in input_manifest or []:
        source = project_dir / relative_path
        _validate_working_dir(str(source), allowed_base)
        dest = run_workspace / Path(relative_path).name
        shutil.copy2(source, dest)

    for filename, content in (input_payload or {}).items():
        validate_payload_filename(filename)
        (run_workspace / filename).write_text(content)

    (run_workspace / ".obra-run-metadata.json").write_text(
        json.dumps(
            {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "project_dir": str(project_dir),
                "input_manifest": input_manifest or [],
                "input_payload_keys": list((input_payload or {}).keys()),
                "provisioned_at": datetime.now(UTC).isoformat(),
            }
        )
    )

    logger.info(
        "Provisioned run workspace",
        extra={
            "run_id": run_id,
            "project_id": project_dir.name,
            "workspace": str(run_workspace),
            "manifest_count": len(input_manifest or []),
            "payload_count": len(input_payload or {}),
        },
    )

    return run_workspace


def cleanup_run_workspace(workspace_path: Path, *, project_dir: Path) -> bool:
    """Remove a provisioned run workspace directory.

    Returns True if the directory was removed, False if it was already gone
    or removal failed.
    """
    if not workspace_path.is_relative_to(project_dir / "runs"):
        raise ValueError(
            f"workspace_path must be under {project_dir / 'runs'}, "
            f"got {workspace_path}"
        )

    if not workspace_path.exists():
        logger.info(
            "Run workspace already removed",
            extra={"workspace": str(workspace_path)},
        )
        return False

    try:
        shutil.rmtree(workspace_path)
    except OSError:
        logger.warning(
            "Failed to remove run workspace",
            extra={"workspace": str(workspace_path)},
            exc_info=True,
        )
        return False

    logger.info(
        "Cleaned up run workspace",
        extra={"workspace": str(workspace_path)},
    )
    return True


def validate_payload_filename(filename: str) -> None:
    """Reject payload filenames that attempt path traversal."""
    if not filename or "/" in filename or "\\" in filename or ".." in filename:
        raise ValueError(f"Invalid payload filename: {filename!r}")


def _resolve_project_metadata_working_dir(
    project_id: str,
    *,
    allowed_base: Path | None = None,
    client_factory: Callable[[], Any] | None = None,
) -> Path | None:
    client = _create_api_client(client_factory)
    if client is None:
        return None
    try:
        project = client.get_project(project_id)
    except Exception:
        return None
    configured = _normalize_optional_string(
        project.get("working_directory") or project.get("working_dir")
    )
    if configured is None:
        return None
    return _validate_working_dir(configured, allowed_base)


def _create_api_client(client_factory: Callable[[], Any] | None) -> Any | None:
    if callable(client_factory):
        return client_factory()
    try:
        from obra.api import APIClient
    except Exception:
        return None
    try:
        return APIClient.from_config()
    except Exception:
        return None


def _normalize_optional_string(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _normalize_required_string(value: Any, *, field_name: str) -> str:
    normalized = _normalize_optional_string(value)
    if normalized is None:
        raise ValueError(f"{field_name} is required")
    return normalized
