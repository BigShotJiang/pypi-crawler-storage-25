"""Prompt builders for assistant diagnostics, brainstorming, and guided tool-use."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


def _render_stage_summary(
    stage: dict[str, Any],
    selected_stage_id: str | None,
    stage_title_map: dict[str, str],
) -> list[str]:
    stage_id = stage.get("stage_id") or stage.get("id") or "?"
    title = stage.get("title") or stage.get("name") or stage_id
    template_role = stage.get("template_role") or stage.get("type") or ""
    line = f"  - {title} ({stage_id})"
    if template_role:
        line += f" [{template_role}]"
    if selected_stage_id and stage_id == selected_stage_id:
        line = f"  → {title} ({stage_id})"
        if template_role:
            line += f" [{template_role}]"
        line += " [SELECTED]"

    lines = [line]
    purpose = stage.get("purpose") or stage.get("description")
    if purpose:
        lines.append(f"    Purpose: {purpose}")
    depends_on = stage.get("depends_on") or []
    if depends_on:
        dep_titles = [stage_title_map.get(dep_id, dep_id) for dep_id in depends_on]
        lines.append(f"    Depends on: {', '.join(dep_titles)}")
    runner = stage.get("runner")
    if isinstance(runner, dict) and runner.get("runner_id"):
        version = runner.get("version", "?")
        lines.append(f"    Runner: {runner['runner_id']} v{version}")
    quality_loop = stage.get("quality_loop")
    if isinstance(quality_loop, dict):
        enabled = quality_loop.get("enabled", False)
        rules = quality_loop.get("quality_gates") or quality_loop.get("rules") or []
        lines.append(f"    Quality loop: {'enabled' if enabled else 'disabled'}, {len(rules)} rules")
    return lines


def _render_dependency_chain(
    stages: list[dict[str, Any]],
    stage_title_map: dict[str, str],
    max_chain: int,
) -> list[str]:
    if not any(stage.get("depends_on") for stage in stages):
        return []

    lines = ["Dependency chain:"]
    rendered = 0
    for stage in stages:
        if rendered >= max_chain:
            break
        stage_id = stage.get("stage_id") or stage.get("id") or "?"
        title = stage_title_map.get(stage_id, stage_id)
        depends_on = stage.get("depends_on") or []
        if not depends_on:
            lines.append(f"  Start → {title}")
        elif len(depends_on) == 1:
            upstream_title = stage_title_map.get(depends_on[0], depends_on[0])
            lines.append(f"  {upstream_title} → {title}")
        else:
            upstream_titles = [stage_title_map.get(dep_id, dep_id) for dep_id in depends_on]
            lines.append(f"  {', '.join(upstream_titles)} → {title} (join)")
        rendered += 1
    return lines


def _render_edges_section(workflow: dict[str, Any]) -> list[str]:
    edges = workflow.get("edges") or workflow.get("definition", {}).get("edges") or []
    if not edges:
        return []

    lines = [f"Connections ({len(edges)}):"]
    for edge in edges:
        source = edge.get("source") or edge.get("source_stage_id") or "?"
        target = edge.get("target") or edge.get("target_stage_id") or "?"
        lines.append(f"  - {source} → {target}")
    return lines


def _summarize_workflow(
    workflow: dict[str, Any],
    selected_stage_id: str | None = None,
    assistant_config: dict[str, Any] | None = None,
) -> str:
    """Build a concise text summary of the current workflow definition."""
    name = workflow.get("name") or workflow.get("title") or workflow.get("workflow_id", "Untitled")
    summary = workflow.get("summary") or workflow.get("description") or ""
    domain = workflow.get("domain") or workflow.get("business_domain") or ""
    status = workflow.get("status") or "unknown"

    stages = workflow.get("stages") or workflow.get("definition", {}).get("stages") or []
    lines = [
        f"Workflow: {name}",
        f"Status: {status}",
    ]
    if domain:
        lines.append(f"Domain: {domain}")
    if summary:
        lines.append(f"Summary: {summary}")

    # Build stage_id -> title lookup
    stage_title_map: dict[str, str] = {}
    for stage in stages:
        sid = stage.get("stage_id") or stage.get("id") or "?"
        stage_title_map[sid] = stage.get("title") or stage.get("name") or sid

    if stages:
        lines.append(f"Stages ({len(stages)}):")
        for stage in stages:
            lines.extend(_render_stage_summary(stage, selected_stage_id, stage_title_map))
        max_chain = (
            assistant_config.get("stage_detail_max_dependency_chain_stages", 20)
            if assistant_config is not None
            else 20
        )
        lines.extend(_render_dependency_chain(stages, stage_title_map, max_chain))

    lines.extend(_render_edges_section(workflow))

    return "\n".join(lines)


def _summarize_run(run: dict[str, Any]) -> str:
    """Build a concise summary of the latest run."""
    run_id = run.get("run_id") or run.get("id") or "?"
    run_status = run.get("status") or "unknown"
    failure_stage = run.get("failure_stage_id") or ""
    lines = [
        f"Latest run: {run_id} — status: {run_status}",
    ]
    if failure_stage:
        lines.append(f"Failure stage: {failure_stage}")
    stage_outputs = run.get("stage_outputs")
    if isinstance(stage_outputs, dict) and stage_outputs:
        lines.append("Stage outputs:")
        for stage_id, output in stage_outputs.items():
            limit = 500 if stage_id == failure_stage else 200
            text = str(output)[:limit]
            lines.append(f"  {stage_id}: {text}")
    return "\n".join(lines)


def _summarize_selected_artifact(
    artifact: dict[str, Any],
    artifact_content: str | None,
) -> str:
    """Summarize the selected artifact and its content preview."""
    lines = [
        f"Selected artifact: {artifact.get('title') or artifact.get('artifact_id') or '?'}",
        f"Type: {artifact.get('artifact_type') or 'unknown'}",
        f"Lifecycle: {artifact.get('lifecycle') or 'unknown'}",
    ]
    producer_run_id = artifact.get("producer_run_id")
    if producer_run_id:
        lines.append(f"Producer run: {producer_run_id}")
    if artifact_content:
        lines.append("Content preview:")
        lines.append(artifact_content[:600])
    return "\n".join(lines)


def _summarize_selected_derivation(derivation: dict[str, Any]) -> str:
    """Summarize a selected derivation."""
    return "\n".join(
        [
            f"Selected derivation: {derivation.get('derivation_id') or '?'}",
            f"Status: {derivation.get('status') or 'unknown'}",
            f"Mission: {derivation.get('normalized_inputs', {}).get('mission') or derivation.get('mission') or ''}",
        ]
    )


def _build_replay_summary(run_replay: dict[str, Any]) -> str:
    """Build a concise replay summary for output review and diagnostics."""
    entries = run_replay.get("entries") or []
    if not isinstance(entries, list) or not entries:
        return ""
    lines = ["## Run Replay Evidence"]
    for entry in entries[-8:]:
        if not isinstance(entry, dict):
            continue
        event_name = str(entry.get("event_name") or entry.get("event_type") or "event")
        payload = entry.get("payload")
        lines.append(f"  - {event_name}: {json.dumps(payload, sort_keys=True)[:240]}")
    return "\n".join(lines)


def _render_selected_output(output_review: dict[str, Any]) -> list[str]:
    selected_output = output_review.get("selected_output")
    if not isinstance(selected_output, dict):
        return []
    stage_label = str(
        selected_output.get("stage_title")
        or selected_output.get("stage_name")
        or selected_output.get("title")
        or "Selected output"
    )
    lines = [f"Selected evidence: {stage_label}"]
    preview = str(selected_output.get("content_preview") or "").strip()
    if preview:
        lines.append("Selected output preview:")
        lines.append(preview)
    return lines


def _render_output_list(items: list[Any], label: str, limit: int) -> list[str]:
    if not isinstance(items, list) or not items:
        return []
    header = "Intermediate stage outputs:" if label == "intermediate" else "Final outputs:"
    lines = [header]
    for entry in items[:limit]:
        if not isinstance(entry, dict):
            continue
        item_label = (
            str(entry.get("stage_title") or entry.get("stage_name") or entry.get("artifact_id") or "stage")
            if label == "intermediate"
            else str(entry.get("title") or entry.get("artifact_id") or "output")
        )
        preview = str(entry.get("content_preview") or "").strip().replace("\n", " ")
        preview_text = f": {preview[:220]}" if preview else ""
        lines.append(f"  - {item_label}{preview_text}")
    return lines


def _render_replay_entries(entries: list[Any], limit: int) -> list[str]:
    if not isinstance(entries, list) or not entries:
        return []
    lines = ["Replay evidence:"]
    for entry in entries[:limit]:
        if not isinstance(entry, dict):
            continue
        event_name = str(entry.get("event_name") or "event")
        payload = entry.get("payload")
        lines.append(f"  - {event_name}: {json.dumps(payload, sort_keys=True)[:220]}")
    return lines


def _build_output_review_section(output_review: dict[str, Any]) -> str:
    """Render normalized output-review evidence for prompts."""
    if not isinstance(output_review, dict):
        return ""

    lines = ["## Output Review Evidence"]
    route = str(output_review.get("route") or "").strip()
    if route:
        lines.append(f"Route: {route}")
    run_id = str(output_review.get("run_id") or "").strip()
    run_status = str(output_review.get("run_status") or "").strip()
    if run_id:
        run_line = f"Run: {run_id}"
        if run_status:
            run_line += f" ({run_status})"
        lines.append(run_line)
    lines.extend(_render_selected_output(output_review))
    lines.extend(_render_output_list(output_review.get("intermediate_outputs") or [], "intermediate", 5))
    lines.extend(_render_output_list(output_review.get("final_outputs") or [], "final", 3))
    lines.extend(_render_replay_entries(output_review.get("replay_entries") or [], 4))

    evidence_sources = output_review.get("evidence_sources") or []
    if isinstance(evidence_sources, list) and evidence_sources:
        lines.append(f"Evidence sources: {', '.join(str(source) for source in evidence_sources)}")

    return "\n".join(lines)


def _format_relative_time(timestamp_str: str) -> str | None:
    """Format a timestamp as relative time (e.g. '5s ago', '2m ago')."""
    try:
        ts = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        delta = now - ts
        total_seconds = int(delta.total_seconds())
        if total_seconds < 0:
            return None
        if total_seconds < 60:
            return f"{total_seconds}s ago"
        total_minutes = total_seconds // 60
        if total_minutes < 60:
            return f"{total_minutes}m ago"
        total_hours = total_minutes // 60
        return f"{total_hours}h ago"
    except (ValueError, TypeError):
        return None


def _build_business_tier_guidance_section(resolved_context: dict[str, Any]) -> str:
    """Render configured business tier guidance when available."""
    stage_type_tiers = resolved_context.get("business_stage_type_tiers")
    execution_tier = str(resolved_context.get("business_execution_tier") or "").strip()
    workflow = resolved_context.get("workflow")
    if not isinstance(stage_type_tiers, dict):
        return ""
    if not isinstance(workflow, dict):
        return ""
    stages = workflow.get("stages") or workflow.get("definition", {}).get("stages") or []
    if not isinstance(stages, list) or not stages:
        return ""

    lines = [
        "## Business Model Tier Guidance",
        "Use the existing `update_stage` tool for a single stage tier change, or "
        "`batch_mutation` when coordinating several stage tier updates together.",
    ]
    if execution_tier:
        lines.append(f"Workflow fallback tier: {execution_tier}")
    lines.append("Configured defaults by stage type:")
    for stage_type, entry in stage_type_tiers.items():
        if isinstance(entry, dict):
            fields = []
            for key in ("model_tier", "provider", "model", "reasoning_level", "auth_method"):
                value = str(entry.get(key) or "").strip()
                if value:
                    fields.append(f"{key}={value}")
            entry_text = ", ".join(fields) if fields else "no override"
        else:
            entry_text = str(entry)
        lines.append(f"  - {stage_type}: {entry_text}")
    lines.append(
        "Treat these configured defaults as the baseline complexity heuristic. "
        "Only recommend overriding a stage when its reasoning demand is clearly above "
        "or below the configured default."
    )
    lines.append(
        "Per-stage LLM overrides may set `model_tier`, `provider`, `model`, "
        "`reasoning_level`, or `auth_method`. Leave a field unset when the stage "
        "should inherit the configured default."
    )
    return "\n".join(lines)


def _summarize_ui_context(ui_context: dict[str, Any]) -> str:
    """Summarize what the user is currently looking at."""
    parts: list[str] = []
    route = ui_context.get("current_route")
    if route:
        parts.append(f"Current page: {route}")
    selected = ui_context.get("selected_nodes")
    if selected:
        parts.append(f"Selected nodes: {', '.join(str(n) for n in selected)}")

    # Editor state
    editor_surface = ui_context.get("editor_surface")
    editor_mode = ui_context.get("editor_mode")
    if editor_surface:
        parts.append(f"Editor: {editor_surface} mode ({editor_mode})")

    if ui_context.get("dirty"):
        parts.append("Unsaved changes: yes")

    stage_count = ui_context.get("stage_count")
    if stage_count is not None:
        parts.append(f"Stage count: {stage_count}")

    last_change_kind = ui_context.get("last_change_kind")
    if last_change_kind:
        line = f"Last change: {last_change_kind}"
        last_change_summary = ui_context.get("last_change_summary")
        if last_change_summary:
            line += f" — {last_change_summary}"
        parts.append(line)

    # Validation
    if ui_context.get("has_validation_errors"):
        error_count = ui_context.get("validation_error_count", 0)
        parts.append(f"Validation issues ({error_count}):")
        for issue in ui_context.get("validation_issues", []):
            stage_id = issue.get("stage_id", "?")
            message = issue.get("message", "")
            severity = issue.get("severity", "")
            line = f"  - Stage {stage_id}: {message} ({severity})"
            repair = issue.get("repair_action_id")
            if repair is not None:
                line += f" [repair: {repair}]"
            parts.append(line)

    # Conflict / save
    if ui_context.get("has_conflict"):
        parts.append("Conflict detected")

    last_save = ui_context.get("last_save_status")
    if last_save:
        parts.append(f"Last save: {last_save}")
    save_readiness = ui_context.get("save_readiness")
    if save_readiness:
        parts.append(f"Save readiness: {save_readiness}")

    # Recent interactions
    recent = ui_context.get("recent_interactions")
    if isinstance(recent, list) and recent:
        skipped = max(0, len(recent) - 10)
        if skipped:
            parts.append(f"Recent user activity: (...{skipped} earlier actions)")
        else:
            parts.append("Recent user activity:")
        for event in recent[-10:]:
            action = event.get("action", "?")
            line = f"  - {action}"
            target = event.get("target")
            if target is not None:
                line += f" on {target}"
            detail = event.get("detail")
            if detail is not None:
                line += f" ({detail})"
            ts = event.get("timestamp")
            if ts:
                rel = _format_relative_time(str(ts))
                if rel:
                    line += f" [{rel}]"
            parts.append(line)

    return "\n".join(parts) if parts else ""


def _summarize_graph_structure(ui_context: dict[str, Any]) -> str:
    """Summarize graph topology and available actions from semantic projection."""
    projection = ui_context.get("semantic_projection")
    if not projection or not isinstance(projection, dict):
        return ""

    parts: list[str] = []

    stages = projection.get("stages")
    if isinstance(stages, dict) and stages:
        parts.append("## Graph Structure")
        for stage_id, stage_data in stages.items():
            if not isinstance(stage_data, dict):
                continue
            role = stage_data.get("role", "?")
            status = stage_data.get("status", "?")
            line = f"  - {stage_id} ({role}, {status})"
            upstream = stage_data.get("upstream_ids", [])
            if upstream:
                line += f" <- upstream: {', '.join(str(u) for u in upstream)}"
            downstream = stage_data.get("downstream_ids", [])
            if downstream:
                line += f" -> downstream: {', '.join(str(d) for d in downstream)}"
            parts.append(line)

    actions = projection.get("available_actions")
    if isinstance(actions, list) and actions:
        parts.append("## Available Actions")
        for action in actions:
            if not isinstance(action, dict):
                continue
            action_id = action.get("action_id", "?")
            enabled = action.get("enabled", False)
            line = f"  - {action_id}: {'enabled' if enabled else 'disabled'}"
            reason = action.get("disabled_reason")
            if reason and not enabled:
                line += f" ({reason})"
            parts.append(line)

    issue_targets = projection.get("issue_targets")
    if isinstance(issue_targets, list) and issue_targets:
        parts.append("## Repair Targets")
        for issue in issue_targets[:8]:
            if not isinstance(issue, dict):
                continue
            stage_id = str(issue.get("stage_id") or "?")
            severity = str(issue.get("severity") or "warn")
            message = str(issue.get("message") or "Issue")
            repair_ids = issue.get("repair_action_ids")
            line = f"  - {stage_id}: {message} ({severity})"
            if isinstance(repair_ids, list) and repair_ids:
                line += f" [repair: {', '.join(str(item) for item in repair_ids[:3])}]"
            parts.append(line)

    interaction = projection.get("interaction_state")
    if isinstance(interaction, dict):
        mode = interaction.get("mode", "idle")
        if mode != "idle":
            line = f"User is currently: {mode}"
            preview = interaction.get("preview_message")
            if preview:
                line += f" — {preview}"
            parts.append(line)

    return "\n".join(parts) if parts else ""


def _build_proactive_guidance(ui_context: dict[str, Any]) -> str:
    """Generate proactive guidance hints based on current context signals."""
    hints: list[str] = []

    if ui_context.get("has_conflict"):
        hints.append(
            "The user has a revision conflict. Prioritize helping them understand "
            "what changed and whether to reapply their draft or reload the newer version."
        )

    if ui_context.get("has_validation_errors"):
        count = ui_context.get("validation_error_count", 0)
        hints.append(
            f"The workflow has {count} validation issue{'s' if count != 1 else ''}. "
            "If the user asks a general question, mention the issues proactively and "
            "offer to help fix them. Reference specific stage IDs and issue messages."
        )

    if ui_context.get("dirty"):
        last_save = ui_context.get("last_save_status")
        if last_save == "error":
            hints.append(
                "The last save attempt failed. If relevant, suggest retrying or "
                "checking for issues before saving again."
            )
        else:
            hints.append(
                "The visible editor draft has unsaved local changes. Do not imply that a backend-applied "
                "workflow mutation will update that draft unless the response explicitly tells the user to save, "
                "discard, or reload first."
            )

    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        interaction = projection.get("interaction_state", {})
        if isinstance(interaction, dict) and interaction.get("mode") == "connect_select_target":
            hints.append(
                "The user is in the middle of connecting two stages. Keep responses "
                "brief and relevant to the connection action."
            )

    return "\n".join(hints) if hints else ""


_STRATEGY_PREAMBLES = {
    "diagnostic": (
        "Identify the root cause by tracing the execution timeline. "
        "Attribute issues to specific stages."
    ),
    "brainstorming": (
        "You are helping design a new workflow. Do not immediately generate a workflow. "
        "Start by asking 3-5 clarifying questions covering the expected input format and "
        "source, desired output and audience, review or approval requirements, intermediate "
        "quality gates, and error handling. Ask one round at a time and only propose a "
        "structured outline after the user confirms understanding."
    ),
    "console_objective_drafting": (
        "The operator is on the Console page preparing to launch an obra software session. "
        "Help them draft a clear, actionable objective for `obra run`. A good objective states "
        "what should be accomplished rather than prescribing implementation steps, is specific "
        "enough for autonomous execution, and names the target codebase area when relevant. "
        "If the operator mentions a seed document, help structure it as a markdown brief with "
        "sections: Problem, Requirements, Constraints, Success Criteria. Do not propose workflow "
        "scaffold actions."
    ),
    "error_resolution": (
        "Address each validation issue with specific fix instructions. "
        "Order by severity (fail > revise > warn)."
    ),
    "design_guidance": (
        "Ask 3-5 clarifying questions about requirements before suggesting structure."
    ),
    "connection_guidance": (
        "Guide the user through establishing the dependency chain between stages."
    ),
    "readiness_assessment": (
        "Summarize what was just saved. Reference the workflow current development phase and "
        "overall readiness. Suggest the most impactful next step based on the Workflow "
        "Development Phase section. If all stages are enriched and validation passes, suggest "
        "running the workflow."
    ),
    "contextual": "",
}
_PHASE_TONE_DIRECTIVES = {
    "seed": (
        "Treat the workflow as an idea being shaped into a concrete plan. Focus on clarifying "
        "intent, input, output, and success criteria before suggesting stage-level polish."
    ),
    "draft": (
        "Focus on getting the rough workflow shape right. Prioritize missing stage purpose, "
        "basic sequencing, and clear instructions over optimization details."
    ),
    "enrich": (
        "Focus on strengthening stage instructions, runners, dependencies, and quality gates "
        "so the workflow becomes runnable and reviewable."
    ),
    "refine": (
        "Assume the workflow structure is mostly in place. Focus on tightening weak spots, "
        "validation issues, and operator confidence before runs."
    ),
    "validate": (
        "Ground advice in observed runs and readiness signals. Emphasize iteration on results, "
        "evidence, and stability rather than redesigning the whole workflow."
    ),
}


def _strategy_preamble(strategies: list[str]) -> str:
    """Return a tone instruction paragraph for the primary strategy."""
    if not strategies:
        return ""
    primary = strategies[0]
    return _STRATEGY_PREAMBLES.get(primary, "")


def _build_first_use_introduction(resolved_context: dict[str, Any]) -> str:
    """Return the conversational first-use introduction for empty-canvas flows."""
    readiness = resolved_context.get("workflow_readiness")
    phase = (
        str(readiness.get("phase") or "").strip().lower()
        if isinstance(readiness, dict)
        else "seed"
    )
    if phase == "seed":
        return (
            "You are meeting the operator at the very start of workflow design. In 2-3 short "
            "sentences, explain that you will first help shape the seed into a concrete workflow "
            "plan, then turn that plan into stages and refinements."
        )
    return (
        "You are meeting the operator in an empty create flow. In 2-3 short sentences, explain "
        "that you will orient them to the current workflow phase and help them take the next "
        "concrete step without overwhelming them."
    )


def _load_context_file(filename: str) -> str:
    """Load a markdown context file from the workflow-studio context directory."""
    context_path = Path(__file__).parent / "context" / filename
    if not context_path.exists():
        raise FileNotFoundError(f"Assistant context file not found: {context_path}")
    return context_path.read_text(encoding="utf-8").strip()


def _build_tool_use_preamble(safety_mode: str, strategies: list[str]) -> str:
    """Assemble the guided tool-use preamble from file-backed context sections."""
    from obra.gateway.assistant.tool_schema import generate_tool_catalog_context

    sections = [
        _load_context_file("identity.md"),
        _load_context_file("product-context.md"),
        _load_context_file("design-guidelines.md"),
        _load_context_file("scaffold-schema.md"),
        _load_context_file("tool-use-contract.md"),
        generate_tool_catalog_context(),
    ]
    strategy_text = _strategy_preamble(strategies)
    if strategy_text:
        sections.append(f"## Strategy Focus\n{strategy_text}")
    safety_text = (
        "You may only give advice and propose changes — never execute actions directly."
        if safety_mode == "advisory"
        else "You may propose changes with previews for the user to accept."
        if safety_mode == "guided"
        else "You may propose and execute changes with user awareness."
    )
    sections.append(
        f"## Safety Mode: {safety_mode}\nThe user is in '{safety_mode}' mode. {safety_text}"
    )
    return "\n\n".join(section for section in sections if section).strip()


def _apply_strategy_adjustments(
    budget: "PromptBudget",  # noqa: F821
    strategies: list[str],
    resolved_context: dict[str, Any] | None = None,
) -> None:
    """Modify section priorities based on active strategies."""
    for strategy in strategies:
        if strategy == "diagnostic":
            budget.update_priority("latest_run", 2)
            budget.update_priority("output_review", 3)
            budget.update_priority("graph_structure", 10)
        elif strategy == "error_resolution":
            budget.update_priority("selected_stage", 2)
        elif strategy == "design_guidance":
            budget.update_priority("knowledge_docs", 3)
        elif strategy == "connection_guidance":
            budget.update_priority("graph_structure", 2)
        elif strategy == "readiness_assessment":
            budget.update_priority("workflow_readiness", 2)
            budget.update_priority("run_comparison", 3)
            budget.update_priority("recent_changes", 3)


_OUTCOME_VERBS = {
    "proposal": "proposed",
    "applied": "accepted and applied",
    "rejected": "rejected by user",
    "reverted": "reverted",
    "conflict": "conflicted",
}


def _build_conversation_history(
    turn_history: list[dict[str, Any]],
    assistant_config: dict[str, Any],
) -> str:
    """Summarize prior proposal outcomes for re-proposal suppression."""
    if not turn_history:
        return ""

    max_turns = assistant_config.get("conversation_history_max_proposal_turns", 10)
    preview_chars = assistant_config.get("conversation_history_message_preview_chars", 80)

    # Filter to proposal turns (non-advice outcomes)
    proposals = [t for t in turn_history if t.get("outcome") and t["outcome"] != "advice"]
    if not proposals:
        return ""

    lines = ["## Conversation History"]

    if len(proposals) > max_turns:
        earlier = proposals[:-max_turns]
        applied_count = sum(1 for t in earlier if t.get("outcome") == "applied")
        rejected_count = sum(1 for t in earlier if t.get("outcome") == "rejected")
        other_count = len(earlier) - applied_count - rejected_count
        parts = []
        if applied_count:
            parts.append(f"{applied_count} applied")
        if rejected_count:
            parts.append(f"{rejected_count} rejected")
        if other_count:
            parts.append(f"{other_count} other")
        lines.append(f"{len(earlier)} earlier proposals were {'/'.join(parts)}")
        proposals = proposals[-max_turns:]

    for i, turn in enumerate(proposals, 1):
        outcome = turn.get("outcome", "?")
        verb = _OUTCOME_VERBS.get(outcome, outcome)
        message = turn.get("message", "")[:preview_chars]
        lines.append(f"Turn {i}: {verb} — {message}")

    lines.append("Do not re-propose changes that were rejected unless the user explicitly asks.")

    return "\n".join(lines)


def _build_recent_guided_decisions_section(recent_decisions: list[dict[str, Any]]) -> str:
    """Render structured recent guided decisions for repeat/stale awareness."""
    if not recent_decisions:
        return ""

    lines = ["## Recent Guided Decisions"]
    for entry in recent_decisions[-8:]:
        if not isinstance(entry, dict):
            continue
        intent_id = str(entry.get("intent_id") or "proposal")
        status = str(entry.get("status") or "pending")
        target_summary = str(entry.get("target_summary") or intent_id).strip() or intent_id
        request_text = str(entry.get("request_text") or "").strip()
        line = f"- {target_summary} -> {status}"
        if request_text:
            line += f" (user asked: {request_text})"
        lines.append(line)

    lines.append(
        "Avoid repeating the same rejected, already-applied, conflicted, or superseded proposal. "
        "If you stay advisory, explain the boundary and give the user a concrete next step."
    )
    return "\n".join(lines)


def _build_recent_transcript_section(turns: list[dict[str, Any]]) -> str:
    """Render recent raw transcript turns."""
    if not turns:
        return ""

    lines = ["## Recent Transcript"]
    for turn in turns:
        rendered = _render_transcript_turn(turn)
        if rendered:
            lines.append(rendered)
    return "\n".join(lines)


def _render_transcript_turn(turn: dict[str, Any], *, prefix: str = "- ") -> str | None:
    """Render one transcript turn, truncating invalid responses."""
    if not isinstance(turn, dict):
        return None
    role = str(turn.get("role") or "assistant")
    if role == "system":
        title = str(turn.get("event_title") or turn.get("event_type") or "System event")
        return f"{prefix}System: {title}"
    message = str(turn.get("message") or "").strip()
    if not message:
        return None
    if str(turn.get("outcome") or "").strip() == "invalid":
        message = _message_preview(message, limit=80) + " [response rejected - invalid format]"
    return f"{prefix}{role.capitalize()}: {message}"


def _message_preview(message: str, *, limit: int) -> str:
    normalized = " ".join(message.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: max(0, limit - 3)].rstrip() + "..."


def _build_thread_summary_section(summary: str | None) -> str:
    """Render compact thread summary memory."""
    if not summary:
        return ""
    return f"## Earlier Thread Memory\n{summary}"


def _build_transcript_summary_section(summary: str | None) -> str:
    """Render deterministic summary of older transcript turns."""
    if not summary:
        return ""
    return f"## Earlier Conversation Summary\n{summary}"


def _build_carry_forward_section(summary: str | None) -> str:
    """Render explicit carry-forward memory."""
    if not summary:
        return ""
    return f"## Carry-Forward Memory\n{summary}"


def _build_recent_changes(ui_context: dict[str, Any]) -> str:
    """Render recent save/validate diff summary as human-readable text."""
    diff_summary = ui_context.get("last_diff_summary")
    if not diff_summary or not isinstance(diff_summary, dict):
        return ""

    change_type = diff_summary.get("change_type", "unknown")
    stages_added = diff_summary.get("stages_added", 0)
    stages_removed = diff_summary.get("stages_removed", 0)
    connections_changed = diff_summary.get("connections_changed", 0)

    lines = [
        "## Recent Changes",
        f"Last save: {change_type} change — {stages_added} stages added, "
        f"{stages_removed} removed, {connections_changed} connections changed.",
    ]

    validation_outcome = diff_summary.get("validation_outcome")
    if validation_outcome is not None:
        blocking_count = diff_summary.get("blocking_issue_count", 0)
        lines.append(f"Validation: {validation_outcome}, {blocking_count} blocking issues.")

    return "\n".join(lines)


def _build_revision_history(revisions: list[dict[str, Any]]) -> str:
    """Render compact revision history for temporal awareness."""
    if not revisions:
        return ""

    lines = ["## Revision History"]
    for rev in revisions:
        rev_id = rev.get("revision_id") or rev.get("id") or "?"
        change_type = rev.get("change_type") or "unknown"
        stage_count = rev.get("stage_count", "?")
        validation = rev.get("validation_outcome") or rev.get("status") or "?"

        timestamp = rev.get("created_at") or rev.get("timestamp") or ""
        rel_time = ""
        if timestamp:
            rel = _format_relative_time(str(timestamp))
            if rel:
                rel_time = f" ({rel})"

        lines.append(
            f"Revision {rev_id}{rel_time}: {change_type}, "
            f"validation {validation}, {stage_count} stages"
        )

    return "\n".join(lines)


def _build_execution_timeline(timeline: list[dict[str, Any]]) -> str:
    """Render run replay events as a narrative timeline."""
    if not timeline:
        return ""

    lines = ["## Execution Timeline"]
    prev_timestamp = None

    for entry in timeline:
        stage_id = entry.get("stage_id") or "?"
        event_type = entry.get("event_type") or "?"
        timestamp = entry.get("timestamp") or ""

        duration_str = ""
        if prev_timestamp and timestamp:
            try:
                ts = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
                prev_ts = datetime.fromisoformat(str(prev_timestamp).replace("Z", "+00:00"))
                delta = ts - prev_ts
                secs = delta.total_seconds()
                if secs >= 0:
                    duration_str = f" (+{secs:.1f}s)"
            except (ValueError, TypeError):
                pass

        lines.append(f"  {stage_id}: {event_type}{duration_str}")
        if timestamp:
            prev_timestamp = timestamp

    return "\n".join(lines)


def _build_knowledge_section(documents: list[dict[str, Any]]) -> str:
    """Render knowledge reference documents for assistant context."""
    if not documents:
        return ""

    lines = ["## Reference Documents"]
    for doc in documents:
        name = doc.get("name", "Untitled")
        scope = doc.get("scope", "org-wide")
        description = doc.get("description", "")
        content = doc.get("content_text", "")

        lines.append(f"### {name} ({scope})")
        if description:
            lines.append(description)
        if content:
            lines.append(content)
        lines.append("---")

    return "\n".join(lines)


def _resolve_selected_stage(
    ui_context: dict[str, Any],
    workflow: dict[str, Any] | None,
) -> tuple[str | None, dict[str, Any] | None, dict[str, Any] | None]:
    selected = ui_context.get("selected_nodes") or []
    projection = ui_context.get("semantic_projection")
    selected_stage_detail = (
        projection.get("selected_stage_detail")
        if isinstance(projection, dict)
        and isinstance(projection.get("selected_stage_detail"), dict)
        else None
    )

    selected_stage_id = ""
    if isinstance(selected_stage_detail, dict):
        selected_stage_id = str(selected_stage_detail.get("stage_id") or "")
    if not selected_stage_id and selected:
        selected_stage_id = str(selected[0])
    if not selected_stage_id:
        return None, None, selected_stage_detail

    stages = workflow.get("stages") if isinstance(workflow, dict) else None
    if not stages and isinstance(workflow, dict):
        stages = workflow.get("definition", {}).get("stages") or []
    stage = None
    for candidate in stages or []:
        stage_id = candidate.get("stage_id") or candidate.get("id") or ""
        if stage_id == selected_stage_id:
            stage = candidate
            break
    return selected_stage_id, stage, selected_stage_detail


def _render_stage_metadata(
    stage: dict[str, Any] | None,
    selected_stage_detail: dict[str, Any] | None,
    stage_id: str,
) -> list[str]:
    title = (
        (selected_stage_detail or {}).get("title")
        or (stage or {}).get("title")
        or (stage or {}).get("name")
        or stage_id
    )
    lines = [f"## Selected Stage: {title}"]
    if isinstance(selected_stage_detail, dict):
        status = selected_stage_detail.get("status")
        if status:
            lines.append(f"Status: {status}")
        lane_title = selected_stage_detail.get("lane_title")
        category = selected_stage_detail.get("category")
        if lane_title or category:
            parts = []
            if lane_title:
                parts.append(f"lane {lane_title}")
            if category:
                parts.append(f"category {category}")
            lines.append(f"Business posture: {', '.join(parts)}")
        relationship_summary = selected_stage_detail.get("relationship_summary")
        if isinstance(relationship_summary, dict):
            summary_text = relationship_summary.get("summary_text")
            if summary_text:
                lines.append(str(summary_text))
    purpose = (stage.get("purpose") or stage.get("description")) if isinstance(stage, dict) else None
    if purpose:
        lines.append(f"Purpose: {purpose}")
    return lines


def _render_stage_dependencies(
    stage: dict[str, Any] | None,
    workflow: dict[str, Any] | None,
    selected_stage_detail: dict[str, Any] | None,
) -> list[str]:
    lines: list[str] = []
    depends_on = (stage.get("depends_on") or []) if isinstance(stage, dict) else []
    stages = []
    if isinstance(workflow, dict):
        stages = workflow.get("stages") or workflow.get("definition", {}).get("stages") or []
    if depends_on:
        dependency_titles: list[str] = []
        for dependency_id in depends_on:
            dependency_title = dependency_id
            for candidate in stages:
                stage_id = candidate.get("stage_id") or candidate.get("id") or ""
                if stage_id == dependency_id:
                    dependency_title = candidate.get("title") or candidate.get("name") or dependency_id
                    break
            dependency_titles.append(dependency_title)
        lines.append(f"Depends on: {', '.join(dependency_titles)}")
        return lines
    if isinstance(selected_stage_detail, dict):
        upstream_ids = selected_stage_detail.get("upstream_stage_ids") or []
        if upstream_ids:
            lines.append(f"Depends on: {', '.join(str(item) for item in upstream_ids)}")
    return lines


def _render_stage_operational(
    stage: dict[str, Any] | None,
    selected_stage_detail: dict[str, Any] | None,
) -> list[str]:
    lines: list[str] = []
    runner = stage.get("runner") if isinstance(stage, dict) else None
    if isinstance(runner, dict) and runner.get("runner_id"):
        version = runner.get("version", "?")
        lines.append(f"Runner: {runner['runner_id']} v{version}")
    elif isinstance(selected_stage_detail, dict) and selected_stage_detail.get("runner_id"):
        lines.append(f"Runner: {selected_stage_detail['runner_id']}")
    quality_loop = stage.get("quality_loop") if isinstance(stage, dict) else None
    if isinstance(quality_loop, dict):
        enabled = quality_loop.get("enabled", False)
        rules = quality_loop.get("quality_gates") or quality_loop.get("rules") or []
        lines.append(f"Quality loop: {'enabled' if enabled else 'disabled'}, {len(rules)} rules")
    return lines


def _render_stage_validation(
    ui_context: dict[str, Any],
    stage_id: str,
    selected_stage_detail: dict[str, Any] | None,
    resolved_context: dict[str, Any] | None,
) -> list[str]:
    lines: list[str] = []
    validation_issues = ui_context.get("validation_issues", [])
    stage_issues = [issue for issue in validation_issues if issue.get("stage_id") == stage_id]
    semantic_stage_issues = (
        selected_stage_detail.get("issue_targets")
        if isinstance(selected_stage_detail, dict)
        and isinstance(selected_stage_detail.get("issue_targets"), list)
        else []
    )
    if semantic_stage_issues:
        stage_issues = semantic_stage_issues
    if stage_issues:
        lines.append(f"Validation issues ({len(stage_issues)}):")
        for issue in stage_issues:
            severity = issue.get("severity", "?")
            message = issue.get("message", "")
            line = f"  - {message} ({severity})"
            repair_ids = issue.get("repair_action_ids")
            if isinstance(repair_ids, list) and repair_ids:
                line += f" [repair: {', '.join(str(item) for item in repair_ids[:3])}]"
            lines.append(line)

    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        stage_semantics = projection.get("stages", {}).get(stage_id)
        if isinstance(stage_semantics, dict):
            role = stage_semantics.get("role")
            if role:
                lines.append(f"Semantic role: {role}")
            upstream = stage_semantics.get("upstream_ids", [])
            if upstream:
                lines.append(f"Upstream: {', '.join(str(item) for item in upstream)}")
            downstream = stage_semantics.get("downstream_ids", [])
            if downstream:
                lines.append(f"Downstream: {', '.join(str(item) for item in downstream)}")
        available_actions = (
            selected_stage_detail.get("available_action_ids")
            if isinstance(selected_stage_detail, dict)
            else None
        )
        if isinstance(available_actions, list) and available_actions:
            lines.append(f"Available actions: {', '.join(str(item) for item in available_actions[:6])}")

    if resolved_context:
        template_assets = resolved_context.get("template_assets", {})
        template_content = template_assets.get(stage_id)
        if template_content:
            lines.append(f"### Template Content\n{template_content}")
    return lines


def _build_selected_stage_section(
    ui_context: dict[str, Any],
    workflow: dict[str, Any] | None,
    resolved_context: dict[str, Any] | None = None,
) -> str:
    """Build a focused section for the currently selected stage."""
    selected_stage_id, stage, selected_stage_detail = _resolve_selected_stage(ui_context, workflow)
    if selected_stage_id is None:
        return ""
    lines = _render_stage_metadata(stage, selected_stage_detail, selected_stage_id)
    lines.extend(_render_stage_dependencies(stage, workflow, selected_stage_detail))
    lines.extend(_render_stage_operational(stage, selected_stage_detail))
    lines.extend(
        _render_stage_validation(
            ui_context,
            selected_stage_id,
            selected_stage_detail,
            resolved_context,
        )
    )
    return "\n".join(lines)


def _default_assistant_config() -> dict[str, Any]:
    return {
        "prompt_budget_tokens": 16000,
        "chars_per_token": 4,
        "section_priorities": {
            "preamble": 1,
            "selected_stage": 2,
            "workflow_definition": 3,
            "workflow_readiness": 3,
            "template_authoring_guidelines": 3,
            "output_review": 4,
            "knowledge_docs": 4,
            "recent_transcript": 4,
            "thread_summary": 4,
            "carry_forward_context": 4,
            "conversation_history": 5,
            "run_comparison": 5,
            "latest_run": 6,
            "ui_state": 7,
            "graph_structure": 7,
            "proactive_guidance": 7,
            "recent_changes": 8,
            "interaction_log": 9,
            "revision_history": 10,
        },
        "workflow_readiness_max_tokens": 800,
    }


def _selected_stage_id_from_ui_context(ui_context: dict[str, Any] | None) -> str | None:
    if not isinstance(ui_context, dict):
        return None
    selected_nodes = ui_context.get("selected_nodes")
    if selected_nodes:
        return selected_nodes[0]
    return None


def _build_workflow_sections(
    workflow: dict[str, Any],
    resolved_context: dict[str, Any],
    assistant_config: dict[str, Any],
    safety_mode: str,
) -> list[tuple[str, str]]:
    from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines
    from obra.gateway.assistant.pipelines.registry import list_pipelines

    sections = [
        (
            "workflow_definition",
            "## Current Workflow\n"
            + _summarize_workflow(
                workflow,
                selected_stage_id=_selected_stage_id_from_ui_context(resolved_context.get("ui_context")),
                assistant_config=assistant_config,
            ),
        )
    ]
    business_tier_guidance = _build_business_tier_guidance_section(resolved_context)
    if business_tier_guidance:
        sections.append(("business_tier_guidance", business_tier_guidance))
    if safety_mode == "guided" and workflow.get("stages"):
        sections.append(
            (
                "template_authoring_guidelines",
                "## Template Authoring Guidelines\n"
                + _load_context_file("template-authoring-guidelines.md"),
            )
        )
        register_builtin_pipelines()
        available_pipelines = list_pipelines()
        if available_pipelines:
            pipeline_lines = [
                f"- `{pipeline.pipeline_id}`: {pipeline.display_name} (trigger: {pipeline.trigger_mode})"
                for pipeline in available_pipelines
            ]
            sections.append(
                (
                    "available_pipelines",
                    "## Available Pipelines\nUse run_pipeline to trigger these:\n"
                    + "\n".join(pipeline_lines),
                )
            )
    return sections


def _build_ui_sections(
    ui_context: dict[str, Any],
    resolved_context: dict[str, Any],
) -> list[tuple[str, str]]:
    del resolved_context
    sections: list[tuple[str, str]] = []
    ui_summary = _summarize_ui_context(ui_context)
    if ui_summary:
        sections.append(("ui_state", "## User's Current View\n" + ui_summary))
    graph_summary = _summarize_graph_structure(ui_context)
    if graph_summary:
        sections.append(("graph_structure", graph_summary))
    guidance = _build_proactive_guidance(ui_context)
    if guidance:
        sections.append(("proactive_guidance", "## Contextual Guidance\n" + guidance))
    recent_changes = _build_recent_changes(ui_context)
    if recent_changes:
        sections.append(("recent_changes", recent_changes))
    return sections


def _build_conversation_sections(
    resolved_context: dict[str, Any],
    assistant_config: dict[str, Any],
) -> list[tuple[str, str]]:
    sections: list[tuple[str, str]] = []
    recent_transcript_turns = resolved_context.get("recent_transcript_turns", [])
    if isinstance(recent_transcript_turns, list):
        recent_transcript = _build_recent_transcript_section(recent_transcript_turns)
        if recent_transcript:
            sections.append(("recent_transcript", recent_transcript))

    thread_summary = _build_thread_summary_section(resolved_context.get("thread_summary"))
    if thread_summary:
        sections.append(("thread_summary", thread_summary))

    transcript_summary = _build_transcript_summary_section(resolved_context.get("transcript_summary"))
    if transcript_summary:
        sections.append(("transcript_summary", transcript_summary))

    carry_forward_context = _build_carry_forward_section(resolved_context.get("carry_forward_summary"))
    if carry_forward_context:
        sections.append(("carry_forward_context", carry_forward_context))

    turn_history = resolved_context.get("turn_history", [])
    if turn_history:
        history_section = _build_conversation_history(turn_history, assistant_config)
        if history_section:
            sections.append(("conversation_history", history_section))

    recent_guided_decisions = resolved_context.get("recent_guided_decisions")
    if isinstance(recent_guided_decisions, list):
        recent_decisions_section = _build_recent_guided_decisions_section(recent_guided_decisions)
        if recent_decisions_section:
            sections.append(("recent_guided_decisions", recent_decisions_section))

    return sections


def _build_evidence_sections(resolved_context: dict[str, Any]) -> list[tuple[str, str]]:
    sections: list[tuple[str, str]] = []
    run_comparison = resolved_context.get("run_comparison")
    if isinstance(run_comparison, dict):
        comparison_section = _build_run_comparison_section(run_comparison)
        if comparison_section:
            sections.append(("run_comparison", comparison_section))

    revision_history = resolved_context.get("revision_history", [])
    if revision_history:
        revision_section = _build_revision_history(revision_history)
        if revision_section:
            sections.append(("revision_history", revision_section))

    run_timeline = resolved_context.get("run_timeline", [])
    if run_timeline:
        timeline_section = _build_execution_timeline(run_timeline)
        if timeline_section:
            sections.append(("execution_timeline", timeline_section))

    run_replay = resolved_context.get("run_replay")
    if run_replay and isinstance(run_replay, dict):
        replay_section = _build_replay_summary(run_replay)
        if replay_section:
            sections.append(("run_replay", replay_section))

    knowledge_docs = resolved_context.get("knowledge_documents", [])
    if knowledge_docs:
        knowledge_section = _build_knowledge_section(knowledge_docs)
        if knowledge_section:
            sections.append(("knowledge_docs", knowledge_section))

    return sections


def _truncate_section_content(
    content: str,
    *,
    max_tokens: int,
    chars_per_token: int,
    section_name: str,
) -> str:
    if not content:
        return ""
    if max_tokens <= 0 or chars_per_token <= 0:
        return content
    max_chars = max_tokens * chars_per_token
    if len(content) <= max_chars:
        return content
    return content[:max_chars].rstrip() + f"\n[... truncated for {section_name} section budget]"


def _build_run_comparison_section(run_comparison: dict[str, Any]) -> str:
    runs = run_comparison.get("runs")
    if not isinstance(runs, list) or len(runs) < 2:
        return ""

    latest = runs[0] if isinstance(runs[0], dict) else {}
    previous = runs[1] if isinstance(runs[1], dict) else {}
    latest_run_id = str(latest.get("run_id") or "latest")
    previous_run_id = str(previous.get("run_id") or "previous")
    latest_status = str(latest.get("status") or "unknown")
    previous_status = str(previous.get("status") or "unknown")

    lines = [
        "## Run-to-Run Comparison",
        "",
        f"Comparing latest run `{latest_run_id}` ({latest_status}) against `{previous_run_id}` ({previous_status}).",
    ]

    revision_chain = run_comparison.get("revision_chain")
    if isinstance(revision_chain, list):
        latest_revision = ""
        previous_revision = ""
        if isinstance(latest.get("workflow_ref"), dict):
            latest_revision = str(latest["workflow_ref"].get("revision_id") or "").strip()
        if isinstance(previous.get("workflow_ref"), dict):
            previous_revision = str(previous["workflow_ref"].get("revision_id") or "").strip()
        if latest_revision or previous_revision:
            lines.append(
                f"Revision context: latest={latest_revision or 'unknown'}, previous={previous_revision or 'unknown'}."
            )

    stage_alignment = run_comparison.get("stage_alignment")
    changed_stages: list[dict[str, Any]] = []
    if isinstance(stage_alignment, list):
        for entry in stage_alignment:
            if not isinstance(entry, dict):
                continue
            delta = entry.get("delta")
            if not isinstance(delta, dict):
                continue
            if any(bool(delta.get(flag)) for flag in ("status_changed", "loop_verdict_changed", "runner_changed", "reordered")):
                changed_stages.append(entry)

    if changed_stages:
        lines.extend(["", "### Notable Stage Deltas"])
        for entry in changed_stages[:6]:
            stage_name = str(entry.get("stage_name") or "Stage")
            delta = entry.get("delta") if isinstance(entry.get("delta"), dict) else {}
            changes = []
            if delta.get("status_changed"):
                changes.append("status")
            if delta.get("loop_verdict_changed"):
                changes.append("loop verdict")
            if delta.get("runner_changed"):
                changes.append("runner")
            if delta.get("reordered"):
                changes.append("position")
            lines.append(f"- {stage_name}: changed {', '.join(changes)}")
    else:
        lines.extend(["", "### Notable Stage Deltas", "- No major stage deltas detected."])

    return "\n".join(lines)


def _validate_readiness_data(
    readiness_data: dict[str, Any],
    *,
    workflow_seed_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Extract and type-validate fields from raw readiness data.

    Returns a normalized dict with all fields coerced to their expected types.
    No string building occurs here.
    """
    phase = str(readiness_data.get("phase") or "unknown")
    phase_confidence = float(readiness_data.get("phase_confidence") or 0.0)
    can_run = "yes" if bool(readiness_data.get("can_run")) else "no"
    overall_completeness = float(readiness_data.get("overall_completeness") or 0.0)
    stage_readiness = (
        readiness_data.get("stage_readiness")
        if isinstance(readiness_data.get("stage_readiness"), list)
        else []
    )
    blocking_issues = (
        readiness_data.get("blocking_issues")
        if isinstance(readiness_data.get("blocking_issues"), list)
        else []
    )
    improvement_issues = (
        readiness_data.get("improvement_issues")
        if isinstance(readiness_data.get("improvement_issues"), list)
        else []
    )
    seed_alignment = (
        readiness_data.get("seed_alignment")
        if isinstance(readiness_data.get("seed_alignment"), dict)
        else None
    )
    suggested_next_action = str(readiness_data.get("suggested_next_action") or "").strip()

    return {
        "phase": phase,
        "phase_confidence": phase_confidence,
        "can_run": can_run,
        "overall_completeness": overall_completeness,
        "stage_readiness": stage_readiness,
        "blocking_issues": blocking_issues,
        "improvement_issues": improvement_issues,
        "seed_alignment": seed_alignment,
        "suggested_next_action": suggested_next_action,
        "workflow_seed_summary": workflow_seed_summary,
    }


def _render_seed_alignment_section(validated: dict[str, Any]) -> list[str]:
    """Render the seed summary and seed alignment text block.

    Receives the validated data dict from ``_validate_readiness_data``.
    """
    lines: list[str] = []
    workflow_seed_summary = validated["workflow_seed_summary"]
    if isinstance(workflow_seed_summary, dict):
        seed_intent = str(workflow_seed_summary.get("intent") or "").strip()
        if seed_intent:
            lines.extend(["", f"Seed intent: {seed_intent}"])
        first_requirement = str(workflow_seed_summary.get("first_requirement") or "").strip()
        if first_requirement:
            lines.append(f"Seed requirement focus: {first_requirement}")
        output_names = workflow_seed_summary.get("output_names")
        if isinstance(output_names, list) and output_names:
            lines.append(f"Seed outputs: {', '.join(str(item) for item in output_names)}")
        seed_notes = str(workflow_seed_summary.get("notes") or "").strip()
        if seed_notes:
            lines.append(f"Seed notes: {seed_notes}")

    seed_alignment = validated["seed_alignment"]
    if isinstance(seed_alignment, dict):
        matched_requirement_count = int(seed_alignment.get("matched_requirement_count") or 0)
        total_requirement_count = int(seed_alignment.get("total_requirement_count") or 0)
        coverage_ratio = float(seed_alignment.get("coverage_ratio") or 0.0)
        lines.extend(
            [
                "",
                "### Seed Alignment",
                f"Requirement coverage: {matched_requirement_count}/{total_requirement_count} ({coverage_ratio:.0%})",
            ]
        )
        unmatched_requirements = (
            seed_alignment.get("unmatched_requirements")
            if isinstance(seed_alignment.get("unmatched_requirements"), list)
            else []
        )
        if unmatched_requirements:
            for requirement in unmatched_requirements[:5]:
                if not isinstance(requirement, dict):
                    continue
                description = str(requirement.get("description") or "").strip()
                if description:
                    lines.append(f"- Unmatched seed requirement: {description}")
    return lines


def _render_stage_readiness_section(validated: dict[str, Any]) -> list[str]:
    """Render the per-stage readiness text block.

    Receives the validated data dict from ``_validate_readiness_data``.
    """
    stage_readiness = validated["stage_readiness"]
    lines: list[str] = ["", "### Per-Stage Readiness"]
    if stage_readiness:
        for stage in stage_readiness:
            title = str(stage.get("title") or stage.get("stage_id") or "Stage").strip()
            status = str(stage.get("status") or "unknown")
            completeness = float(stage.get("completeness") or 0.0)
            missing = stage.get("missing_fields") if isinstance(stage.get("missing_fields"), list) else []
            if missing:
                lines.append(
                    f"- {title}: {status} ({completeness:.0%}) — missing {', '.join(str(item) for item in missing)}"
                )
            else:
                lines.append(f"- {title}: {status} ({completeness:.0%})")
    else:
        lines.append("- No stages available.")
    return lines


def _render_issues_section(validated: dict[str, Any]) -> list[str]:
    """Render the blocking and improvement issues text block.

    Receives the validated data dict from ``_validate_readiness_data``.
    """
    blocking_issues = validated["blocking_issues"]
    improvement_issues = validated["improvement_issues"]
    suggested_next_action = validated["suggested_next_action"]

    lines: list[str] = ["", "### Blocking Issues (user must fix)"]
    if blocking_issues:
        for issue in blocking_issues:
            lines.append(f"- {str(issue.get('plain_description') or issue.get('message') or '').strip()}")
    else:
        lines.append("- None.")

    lines.extend(["", "### Improvement Issues (you can help resolve)"])
    if improvement_issues:
        for issue in improvement_issues:
            lines.append(f"- {str(issue.get('plain_description') or issue.get('message') or '').strip()}")
    else:
        lines.append("- None.")

    if suggested_next_action:
        lines.extend(["", "### Suggested Next Action", suggested_next_action])

    return lines


def _build_workflow_readiness_section(
    readiness: dict[str, Any],
    *,
    workflow_seed_summary: dict[str, Any] | None = None,
) -> str:
    if not isinstance(readiness, dict):
        return ""

    from obra.config.loaders import get_readiness_recap_enabled

    validated = _validate_readiness_data(
        readiness, workflow_seed_summary=workflow_seed_summary,
    )

    lines = [
        "## Workflow Development Phase",
        "",
        f"Current phase: **{validated['phase']}** (confidence: {validated['phase_confidence']:.1f})",
        f"Can run: {validated['can_run']}",
        f"Overall completeness: {validated['overall_completeness']:.0%}",
    ]
    phase_tone = _PHASE_TONE_DIRECTIVES.get(validated["phase"])
    if phase_tone:
        lines.extend(["", f"Phase guidance: {phase_tone}"])

    lines.extend(_render_seed_alignment_section(validated))
    lines.extend(_render_stage_readiness_section(validated))
    lines.extend(_render_issues_section(validated))

    if get_readiness_recap_enabled():
        lines.extend(
            [
                "",
                "After completing any task, briefly note the phase status and suggest the natural next step. "
                "Keep recaps to 1-2 sentences. Never show raw validation issue codes to the user.",
            ]
        )
    return "\n".join(lines)


def build_post_pipeline_followup_prompt(
    pipeline_id: str,
    pipeline_display_name: str,
    pipeline_status: str,
    proposal_count: int,
    readiness: dict[str, Any] | None,
    recent_turns: list[dict[str, str]],
    available_pipelines: list[dict[str, str]] | None = None,
) -> tuple[str, str]:
    """Build system + user prompt for the post-pipeline follow-up advisory.

    Returns (system_prompt, user_message) for a short LLM call that produces
    a 1-2 sentence nudge telling the user what just completed, where the
    workflow stands, and what to do next.
    """
    phase = "unknown"
    suggested_next = ""
    completeness = 0.0
    can_run = False
    if isinstance(readiness, dict):
        phase = str(readiness.get("phase") or "unknown")
        suggested_next = str(readiness.get("suggested_next_action") or "")
        completeness = float(readiness.get("overall_completeness") or 0.0)
        can_run = bool(readiness.get("can_run"))

    system_lines = [
        "You are the Workflow Studio assistant. A background pipeline just finished.",
        "Write a brief follow-up message (2-3 sentences max) for the user that:",
        "1. Acknowledges what completed and its outcome.",
        "2. States where the workflow stands now (phase, completeness).",
        "3. Suggests the single most useful next step and offers to do it.",
        "",
        "If the next step is a pipeline the assistant can run, name it clearly",
        "so the user can ask for it or click Accept.",
        "",
        "Do NOT repeat raw data, issue codes, or phase names verbatim.",
        "Be conversational and concise. No markdown headers.",
    ]

    user_lines = [
        f"Pipeline completed: {pipeline_display_name} ({pipeline_id})",
        f"Status: {pipeline_status}",
        f"Proposals generated: {proposal_count}",
        "",
        f"Workflow phase: {phase}",
        f"Overall completeness: {completeness:.0%}",
        f"Can run: {can_run}",
    ]
    if suggested_next:
        user_lines.append(f"Readiness model suggestion: {suggested_next}")

    if available_pipelines:
        user_lines.append("")
        user_lines.append("Available pipelines the assistant can offer to run:")
        for p in available_pipelines:
            user_lines.append(f"- {p['pipeline_id']}: {p['display_name']} (trigger: {p['trigger_mode']})")

    if recent_turns:
        user_lines.append("")
        user_lines.append("Recent conversation (for intent context):")
        for turn in recent_turns[-3:]:
            role = turn.get("role", "user")
            msg = turn.get("message", "")
            # Truncate long messages to keep the prompt small
            if len(msg) > 200:
                msg = msg[:200] + "..."
            user_lines.append(f"  {role}: {msg}")

    return "\n".join(system_lines), "\n".join(user_lines)


def _build_contextual_preamble(
    resolved_context: dict[str, Any],
    strategies: list[str],
    safety_mode: str,
) -> str:
    if safety_mode == "guided":
        return _build_tool_use_preamble(safety_mode, strategies)
    safety_text = (
        "You may only give advice and propose changes — never execute actions directly."
        if safety_mode == "advisory"
        else "You may propose and execute changes with user awareness."
    )
    strategy_text = _strategy_preamble(strategies)
    preamble = _load_context_file("identity.md") + "\n\n" + _load_context_file("product-context.md")
    if strategy_text:
        preamble += f"\n\n## Strategy Focus\n{strategy_text}"
    preamble += (
        f"\n\n## Safety Mode: {safety_mode}\nThe user is in '{safety_mode}' mode. {safety_text}"
    )
    return preamble


def _build_primary_context_sections(resolved_context: dict[str, Any]) -> list[tuple[str, str]]:
    sections: list[tuple[str, str]] = []
    latest_run = resolved_context.get("latest_run")
    if latest_run and isinstance(latest_run, dict):
        sections.append(("latest_run", "## Latest Run\n" + _summarize_run(latest_run)))

    output_review = resolved_context.get("output_review")
    if output_review and isinstance(output_review, dict):
        output_review_section = _build_output_review_section(output_review)
        if output_review_section:
            sections.append(("output_review", output_review_section))

    selected_artifact = resolved_context.get("selected_artifact")
    if selected_artifact and isinstance(selected_artifact, dict):
        sections.append(
            (
                "selected_artifact",
                "## Selected Artifact\n"
                + _summarize_selected_artifact(
                    selected_artifact,
                    resolved_context.get("artifact_content"),
                ),
            )
        )

    selected_derivation = resolved_context.get("selected_derivation")
    if selected_derivation and isinstance(selected_derivation, dict):
        sections.append(
            (
                "selected_derivation",
                "## Selected Derivation\n"
                + _summarize_selected_derivation(selected_derivation),
            )
        )
    return sections


def _workflow_section_priority(priorities: dict[str, Any], section_name: str) -> int:
    if section_name == "template_authoring_guidelines":
        return priorities.get("template_authoring_guidelines", 3)
    if section_name == "available_pipelines":
        return priorities.get(
            "available_pipelines",
            priorities.get("template_authoring_guidelines", 3),
        )
    return priorities.get(section_name, 3)


def _primary_section_priority(priorities: dict[str, Any], section_name: str) -> int:
    defaults = {
        "latest_run": 6,
        "output_review": 4,
        "selected_artifact": 4,
        "selected_derivation": 5,
    }
    return priorities.get(section_name, defaults[section_name])


def _ui_section_priority(priorities: dict[str, Any], section_name: str) -> int:
    return priorities.get(section_name, 8 if section_name == "recent_changes" else 7)


def _conversation_section_priority(priorities: dict[str, Any], section_name: str) -> int:
    if section_name in {"conversation_history", "recent_guided_decisions"}:
        return priorities.get(section_name, priorities.get("conversation_history", 5))
    if section_name == "transcript_summary":
        return priorities.get(section_name, priorities.get("thread_summary", 4))
    if section_name == "carry_forward_context":
        return priorities.get(section_name, priorities.get("carry_forward_context", 4))
    return priorities.get(section_name, 4)


def _evidence_section_priority(priorities: dict[str, Any], section_name: str) -> int:
    if section_name == "run_comparison":
        return priorities.get("run_comparison", 5)
    if section_name == "revision_history":
        return priorities.get("revision_history", 10)
    if section_name == "execution_timeline":
        return priorities.get("execution_timeline", 3)
    return priorities.get(section_name, 4)


def _add_built_sections(
    budget: Any,
    sections: list[tuple[str, str]],
    priority_resolver: Callable[[dict[str, Any], str], int],
    priorities: dict[str, Any],
) -> None:
    for section_name, section_text in sections:
        if not section_text:
            continue
        budget.add_section(
            section_name,
            section_text,
            priority_resolver(priorities, section_name),
        )


def build_contextual_system_prompt(
    resolved_context: dict[str, Any],
    assistant_config: dict[str, Any] | None = None,
    strategies: list[str] | None = None,
) -> str:
    """Build a rich system prompt incorporating all available context.

    Uses PromptBudget for token-aware assembly when assistant_config is provided.
    """
    from obra.gateway.workflow_studio.prompt_budget import PromptBudget

    if assistant_config is None:
        assistant_config = _default_assistant_config()

    if strategies is None:
        strategies = resolved_context.get("strategies", ["contextual"])

    priorities = assistant_config.get("section_priorities", {})
    budget = PromptBudget(
        total_budget=assistant_config.get("prompt_budget_tokens", 16000),
        chars_per_token=assistant_config.get("chars_per_token", 4),
    )

    safety_mode = resolved_context.get("safety_mode", "advisory")
    preamble = _build_contextual_preamble(resolved_context, strategies, safety_mode)
    budget.add_section("preamble", preamble, priorities.get("preamble", 1))

    workflow = resolved_context.get("workflow")
    ui_context = resolved_context.get("ui_context")
    if ui_context and isinstance(ui_context, dict) and workflow:
        selected_section = _build_selected_stage_section(ui_context, workflow, resolved_context)
        if selected_section:
            budget.add_section(
                "selected_stage",
                selected_section,
                priorities.get("selected_stage", 2),
            )

    if workflow and isinstance(workflow, dict):
        _add_built_sections(
            budget,
            _build_workflow_sections(
                workflow,
                resolved_context,
                assistant_config,
                safety_mode,
            ),
            _workflow_section_priority,
            priorities,
        )

    _add_built_sections(
        budget,
        _build_primary_context_sections(resolved_context),
        _primary_section_priority,
        priorities,
    )

    if ui_context and isinstance(ui_context, dict):
        _add_built_sections(
            budget,
            _build_ui_sections(ui_context, resolved_context),
            _ui_section_priority,
            priorities,
        )

    _add_built_sections(
        budget,
        _build_conversation_sections(resolved_context, assistant_config),
        _conversation_section_priority,
        priorities,
    )
    _add_built_sections(
        budget,
        _build_evidence_sections(resolved_context),
        _evidence_section_priority,
        priorities,
    )

    readiness = resolved_context.get("workflow_readiness")
    if isinstance(readiness, dict):
        readiness_section = _build_workflow_readiness_section(
            readiness,
            workflow_seed_summary=(
                resolved_context.get("workflow_seed_summary")
                if isinstance(resolved_context.get("workflow_seed_summary"), dict)
                else None
            ),
        )
        readiness_section = _truncate_section_content(
            readiness_section,
            max_tokens=int(assistant_config.get("workflow_readiness_max_tokens", 800)),
            chars_per_token=int(assistant_config.get("chars_per_token", 4)),
            section_name="workflow_readiness",
        )
        if readiness_section:
            budget.add_section(
                "workflow_readiness",
                readiness_section,
                priorities.get("workflow_readiness", 3),
            )

    _apply_strategy_adjustments(budget, strategies, resolved_context)

    assembled_text, manifest = budget.assemble()
    manifest.strategy = strategies[0] if strategies else "contextual"
    resolved_context["context_manifest"] = manifest
    return assembled_text


def build_diagnostic_system_prompt(
    run_status: str,
    failure_stage_id: str | None,
    stage_outputs: dict[str, str],
) -> str:
    """Build a diagnostic system prompt tailored to run health."""
    mode = (
        "failure diagnosis"
        if run_status in {"failed", "cancelled"} or failure_stage_id
        else "quality review"
    )
    failure_line = (
        f"Failure stage: {failure_stage_id}."
        if failure_stage_id
        else "Failure stage: not explicitly identified."
    )
    identity = _load_context_file("identity.md")
    product = _load_context_file("product-context.md")
    return (
        identity + "\n\n" + product + f"\n\n## Diagnostic Mode: {mode}\n"
        f"Run status: {run_status}.\n"
        f"{failure_line}\n"
        "Identify the exact failure point by stage when possible. Attribute issues to the "
        "specific stage, template, input contract, or handoff that caused them. Translate "
        "technical errors into business-language explanations. Propose targeted fixes that name "
        "the specific workflow change to make, such as a template edit, stage reorder, input "
        "correction, or quality-gate adjustment. Never give generic advice.\n"
        f"Stage output summary: {json.dumps(stage_outputs, sort_keys=True)}"
    )


def build_brainstorming_system_prompt(first_use_intro: str | None = None) -> str:
    """Build a brainstorming system prompt with judgment-based clarification and brief generation."""
    from obra.gateway.assistant.tool_schema import generate_tool_catalog_context

    sections = [
        _load_context_file("identity.md"),
        _load_context_file("product-context.md"),
        _load_context_file("design-guidelines.md"),
        _load_context_file("scaffold-schema.md"),
        _load_context_file("tool-use-contract.md"),
        generate_tool_catalog_context(),
        (
            "## First-Use Introduction\n"
            f"{first_use_intro}"
            if isinstance(first_use_intro, str) and first_use_intro.strip()
            else ""
        ),
        "## Mode: Workflow Design\n"
        "You are helping design a new workflow.\n\n"
        "### Clarification (use judgment)\n"
        "- For VAGUE requests (short, underspecified): ask 1-3 focused clarifying questions "
        "about the gaps that matter most. Do not ask more than necessary.\n"
        "- For RICH requests (detailed specs, clear constraints): make reasonable assumptions, "
        "state them, and proceed directly.\n"
        "- When the user says to proceed, make recommendations, or asks you to decide: "
        "decide and move forward.\n\n"
        "### Design Brief\n"
        "Once you have enough context (from the initial request or after clarification), "
        "produce a **Workflow Design Brief** using this structure:\n\n"
        "**Objective**: What the workflow accomplishes in one sentence.\n\n"
        "**Input**: What the workflow receives (format, source, constraints).\n\n"
        "**Output**: What the workflow produces (format, audience, quality criteria).\n\n"
        "**Assumptions**: Decisions you made where the user didn't specify. "
        "State each explicitly so the user can correct them.\n\n"
        "**Proposed Stages**: A numbered list of stages with a one-line description each. "
        "Include the purpose, not implementation details.\n\n"
        "**Review Gates**: Where human review or quality checks happen.\n\n"
        "**Open Questions** (if any): Only genuine ambiguities that would change the design.\n\n"
        "If the request is rich and unambiguous, skip the brief: state your key "
        "assumptions in the `message` field and call `build_workflow_scaffold` directly. "
        "If the request is vague or underspecified, present the brief and ask the user "
        "to confirm before creating the workflow. Keep the brief concise — one page, "
        "not a thesis.",
    ]
    return "\n\n".join(section for section in sections if section).strip()
