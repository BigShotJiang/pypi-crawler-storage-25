"""CLI commands for the Obra hybrid orchestration package.

This module provides all CLI commands for the unified obra package:
- Main workflow: obra run "objective" to start orchestrated tasks
- status: Check session status
- run --resume: Resume an interrupted session
- login/logout/whoami: Authentication commands
- config: Configuration management
- docs: Access local documentation
- doctor: Run health checks (includes version and server compatibility)
- plans: Manage plan files (upload, list, delete) for SaaS

Usage:
    $ obra --version
    $ obra run "Add user authentication"
    $ obra run --plan-id abc123 "Execute uploaded plan"
    $ obra run --plan-file plan.yaml "Upload and execute plan"
    $ obra status
    $ obra status <session_id>
    $ obra run --resume <session_id>
    $ obra login
    $ obra logout
    $ obra whoami
    $ obra config
    $ obra docs
    $ obra doctor
    $ obra plans upload path/to/plan.yaml
    $ obra plans list
    $ obra plans delete <plan_id>

Note: For local plan validation, use 'dobra plan validate' instead.

Reference: EPIC-HYBRID-001 Story S10: CLI Commands
          FEAT-PLAN-IMPORT-OBRA-001: Plan File Import
"""

import contextlib
import os

# ISSUE-DOBRA-008: Configure UTF-8 console encoding FIRST, before any imports
# This is the industry-standard solution for Windows console Unicode issues.
import sys

if hasattr(sys.stdout, "reconfigure") and sys.stdout is not None:
    with contextlib.suppress(Exception):
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
if hasattr(sys.stderr, "reconfigure") and sys.stderr is not None:
    with contextlib.suppress(Exception):
        sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
os.environ.setdefault("PYTHONIOENCODING", "utf-8:backslashreplace")

import logging

import click
import typer
from rich.console import Console
from rich.table import Table

from obra import __version__

# Bootstrap safety: validate default_config.yaml exists before heavy imports.
# This fails fast with a clear error if installation is corrupted (S1.T2).
from obra.config.loaders import validate_default_schema

validate_default_schema()

from obra.cli._editable_install_check import check_editable_install_freshness  # noqa: E402
from obra.display import (  # noqa: E402
    console,
    glyphs,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
    print_warning,
)
from obra.display.errors import display_error  # noqa: E402
from obra.utils.obra_home import (  # noqa: E402
    legacy_notice_needed,
    mark_legacy_notice_shown,
    resolve_runtime_dir,
)
from obra.version_check import check_for_updates_async, try_auto_update  # noqa: E402

logger = logging.getLogger(__name__)

from obra.cli._shared import (  # noqa: E402
    require_terms_accepted,
    setup_logging,
)

from . import _doctor as doctor_commands  # noqa: E402
from . import _setup as setup_commands  # noqa: E402
from . import _status as status_commands  # noqa: E402


def _maybe_print_legacy_runtime_notice() -> None:
    """Emit a one-time notice when legacy runtime path is active."""
    selection = resolve_runtime_dir()
    if not legacy_notice_needed(selection):
        return

    print_warning(
        "Using legacy runtime directory "
        f"{selection.path}. The canonical runtime path is ~/.obra-runtime. "
        "Set OBRA_RUNTIME_DIR to override."
    )
    mark_legacy_notice_shown(selection)


def _should_skip_startup_chatter(argv: list[str] | None = None) -> bool:
    """Return whether version/editable-install startup chatter should be suppressed."""
    args = list(sys.argv[1:] if argv is None else argv)
    for value in args:
        stripped = str(value).strip()
        if not stripped or stripped.startswith("-"):
            continue
        return stripped == "simulate"
    return False


# Enforce UTF-8 mode for consistent cross-platform behavior
os.environ.setdefault("PYTHONUTF8", "1")


# Create Typer app with custom error handling
app = typer.Typer(
    name="obra",
    help="""Obra - AI Orchestration for Software and Business Workflows

\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510
\u2502  \U0001f916 AI ASSISTANTS: Start with `obra briefing quick` for the LLM fast path \u2502
\u2502     Then use `obra models`, `obra help domains`, and `obra help run`      \u2502
\u2502     Domains: software (default), business                                 \u2502
\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518
Plan mode note: Atomic ideas can use `plan_mode=one_step` (see docs/development/backlog/ONE_STEP_PLAN.md) and log validations under `docs/quality/MANUAL_TESTING_LOG.json` so the planner keeps acceptance/tests/docs explicit.
""",
    no_args_is_help=True,  # Show help when no command specified
    rich_markup_mode="rich",
    epilog='Start with `obra briefing quick`, then use `obra models`, `obra help domains`, and `obra help run` before `obra run "<objective>"`.\nDomains: software (default), business. Run `obra help domains` for examples.\nEncountered a problem? Run `obra bug "<description>"` to report it.',
)


# =============================================================================
# App Callback (Primary Invocation Pattern)
# =============================================================================


def version_callback(value: bool) -> None:
    """Print version and exit when --version is passed."""
    if value:
        print(f"obra {__version__}")
        raise typer.Exit()


@app.callback()
@handle_encoding_errors
def app_callback(
    ctx: typer.Context,
    _version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Reduce output (quiet mode)",
    ),
    session_config: str | None = typer.Option(
        None,
        "--session-config",
        help="Path to a session config layer file",
    ),
    verbose: int = typer.Option(
        1,
        "--verbose",
        "-v",
        count=True,
        help="Verbosity level (0-3, default=progress; use -v/-vv/-vvv)",
    ),
) -> None:
    """Obra - AI orchestration for software and business workflows.

    Run subcommands for specific operations, or use 'obra run' for orchestration.
    """
    ctx.obj = ctx.obj or {}
    if quiet:
        verbose = 0
    ctx.obj["verbose"] = verbose
    if session_config:
        os.environ["OBRA_SESSION_CONFIG"] = session_config
    setup_logging(verbose)

    # Ensure ~/.obra/README.md exists with helpful documentation
    # Only creates if missing, lightweight check
    from obra.utils.obra_home import ensure_obra_home_readme, get_obra_home

    readme_path = get_obra_home() / "README.md"
    if not readme_path.exists():
        try:
            ensure_obra_home_readme()
        except Exception:
            pass  # Non-critical, don't fail CLI startup


def _display_business_domain_help(console: Console) -> None:
    """Display comprehensive help for the business workflow domain."""
    console.print()
    console.print("[bold]Business Workflow Domain[/bold]")
    console.print("[cyan]═══════════════════════════════════════════════════════════════[/cyan]")
    console.print()

    # What it is
    console.print("[bold]What is a business workflow?[/bold]")
    console.print()
    console.print("  A business workflow is a multi-stage pipeline that processes an input")
    console.print("  document (e.g., an invoice packet, compliance report, or brief) through")
    console.print("  a sequence of LLM-powered stages, producing structured output artifacts.")
    console.print()
    console.print("  Unlike software-domain sessions (which write code), business workflows")
    console.print("  produce documents, summaries, decisions, and structured data. No git")
    console.print("  repository is required.")
    console.print()

    # Lifecycle
    console.print("[bold]Lifecycle: Extraction → Compilation → Execution[/bold]")
    console.print()
    console.print("  [cyan]1. Extraction[/cyan]  Your natural-language objective is analyzed by an LLM,")
    console.print("                  which produces a [bold]definition.yaml[/bold] — the workflow blueprint.")
    console.print("                  This defines stages, inputs, outputs, and quality rules.")
    console.print()
    console.print("  [cyan]2. Compilation[/cyan] The definition is compiled into a [bold]WORKFLOW_PLAN.json[/bold],")
    console.print("                  mapping each stage to an executable story with tasks and")
    console.print("                  verification criteria.")
    console.print()
    console.print("  [cyan]3. Execution[/cyan]   Each stage runs in sequence (or parallel where configured).")
    console.print("                  Stage output flows to downstream stages as context.")
    console.print("                  Quality gates can loop until output meets criteria.")
    console.print()

    # Stage types
    console.print("[bold]Stage Types[/bold]")
    console.print()
    console.print("  [cyan]input_validation[/cyan]   Validate and normalize the input document")
    console.print("  [cyan]transformation[/cyan]     Transform, restructure, or reformat data")
    console.print("  [cyan]enrichment[/cyan]         Add context, lookup references, augment content")
    console.print("  [cyan]decision[/cyan]           Route, classify, or make approval/rejection calls")
    console.print("  [cyan]generation[/cyan]         Produce new content (reports, summaries, drafts)")
    console.print("  [cyan]quality_gate[/cyan]       Evaluate prior output against quality rules")
    console.print("  [cyan]output[/cyan]             Format and emit final deliverables")
    console.print()
    console.print("  Each stage declares its type, and the runtime assigns an LLM model tier")
    console.print("  (fast/medium/high) based on stage type unless overridden.")
    console.print()

    # Quality gates
    console.print("[bold]Quality Gates[/bold]")
    console.print()
    console.print("  Quality gate stages evaluate output from prior stages against declared")
    console.print("  quality rules. Behavior is configurable:")
    console.print()
    console.print("  [cyan]loop[/cyan]  (default)  Re-run the prior stage until output passes (up to retry_max)")
    console.print("  [cyan]fail[/cyan]             Fail the workflow if the gate does not pass")
    console.print("  [cyan]skip[/cyan]             Log the issue and continue")
    console.print()

    # Parallel execution
    console.print("[bold]Parallel Execution[/bold]")
    console.print()
    console.print("  Stages with no mutual dependencies can run in parallel. Assign stages to")
    console.print("  the same [bold]parallel_group[/bold] and declare their [bold]depends_on[/bold] to the same")
    console.print("  predecessor. Use [bold]failure_policy[/bold] (fail_fast or all_settle) to control")
    console.print("  group behavior.")
    console.print()

    # Output artifacts
    console.print("[bold]Output Artifacts[/bold]")
    console.print()
    console.print("  A completed business workflow produces:")
    console.print()
    console.print("  [cyan]definition.yaml[/cyan]       The extracted workflow blueprint")
    console.print("  [cyan]WORKFLOW_PLAN.json[/cyan]    The compiled execution plan")
    console.print("  [cyan]stages/S0_*.md[/cyan]        Per-stage instruction files")
    console.print("  [cyan]runs/<run-id>/[/cyan]        Execution artifacts (stage outputs, logs)")
    console.print()

    # Configuration
    console.print("[bold]Key Configuration[/bold]")
    console.print()
    console.print("  Override via [cyan].obra/config.yaml[/cyan] under the [bold]business:[/bold] key:")
    console.print()
    console.print("  [dim]business.llm.extraction_model[/dim]       Model for extraction (default: sonnet)")
    console.print("  [dim]business.llm.stage_type_tiers[/dim]       Model tier per stage type")
    console.print("  [dim]business.execution.quality_gate_behavior[/dim]  loop | fail | skip")
    console.print("  [dim]business.execution.retry_max[/dim]        Max quality-gate retries (default: 3)")
    console.print("  [dim]business.execution.parallel.enabled[/dim]  Enable parallel stages (default: true)")
    console.print()

    # Quick start
    console.print("[bold]Quick Start[/bold]")
    console.print()
    console.print(
        '  [cyan]obra run --domain business "Process invoice packet: validate line items,\n'
        "    flag exceptions over $10k for approval, generate finance summary.\n"
        '    Success: exceptions routed, summary includes totals and flags."[/cyan]'
    )
    console.print()

    # Related commands
    console.print("[bold]Related Commands[/bold]")
    console.print()
    console.print("  [cyan]obra help domains[/cyan]          List all available domains")
    console.print("  [cyan]obra help business-schema[/cyan]  Show WorkflowDefinition JSON Schema")
    console.print("  [cyan]obra briefing examples[/cyan]     Good vs bad input examples")
    console.print("  [cyan]obra models[/cyan]                List available LLM providers and models")
    console.print()


def _display_business_schema(console: Console) -> None:
    """Display the WorkflowDefinition JSON Schema for the business domain."""
    import json

    try:
        from obra_business.schemas.workflow import WorkflowDefinition

        schema = WorkflowDefinition.model_json_schema()
        console.print()
        console.print("[bold]WorkflowDefinition JSON Schema[/bold]")
        console.print("[dim]Schema for definition.yaml — the extracted workflow blueprint[/dim]")
        console.print()
        console.print_json(json.dumps(schema, indent=2))
        console.print()
        console.print("[dim]Generate this schema programmatically:[/dim]")
        console.print(
            '[dim]  python -c "from obra_business.schemas.workflow import WorkflowDefinition; '
            'import json; print(json.dumps(WorkflowDefinition.model_json_schema(), indent=2))"[/dim]'
        )
        console.print()
    except ImportError as exc:
        from obra.display import print_error

        print_error(
            "obra-business package is not installed. "
            "Install it with: pip install -e obra-business/"
        )
        raise typer.Exit(1) from exc


def _print_domain_recovery(domain_name: str) -> None:
    """Print canonical guidance when a runtime domain is typed as a command."""
    console.print()
    console.print(f"[yellow]'{domain_name}' is a domain, not a CLI command.[/yellow]")
    console.print(f'  obra run --domain {domain_name} "your objective"')
    console.print("  obra help domains")
    console.print()
    console.print("[dim]Software is the default domain when no explicit domain resolves.[/dim]")


# =============================================================================
# Help Command (Industry Standard Pattern)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def help(
    ctx: typer.Context,
    command: str | None = typer.Argument(
        None,
        help="Command to get help for (e.g., 'run', 'status', 'briefing')",
    ),
) -> None:
    """Get help for Obra commands.

    Like `git help`, shows help for main app or specific commands.
    Tier 2: Supports keyword search - if command not found, searches all commands.

    Examples:
        obra help                # Main help
        obra help run            # Help for 'run' command
        obra help briefing       # Help for 'briefing' command
        obra help domains        # List available domains
        obra help business       # Business workflow concepts and lifecycle
        obra help business-schema  # WorkflowDefinition JSON Schema
        obra help upload         # Search for commands matching 'upload'
    """

    # Get the underlying Click group from Typer
    click_app = typer.main.get_group(app)

    if command is None:
        # Show main help
        with click.Context(click_app) as click_ctx:
            click.echo(click_app.get_help(click_ctx))
        click.echo(
            "\nNote: default verbosity is PROGRESS (same as -v). Use -q/--quiet for minimal output."
        )
    else:
        if command.lower() == "domains":
            from obra.domains import get_available_domains, load_domain

            console.print()
            console.print("[bold]Available Domains[/bold]")
            console.print()
            for domain_name in get_available_domains():
                domain = load_domain(domain_name)
                default_marker = " (default)" if domain.name == "software" else ""
                console.print(
                    f"  [cyan]{domain.name}[/cyan]{default_marker} - {domain.display_name}: {domain.description}"
                )
                if domain.example_objectives:
                    console.print(
                        f"    Example: obra run --domain {domain.name} "
                        f'"{domain.example_objectives[0]}"'
                    )
                console.print()
            return

        if command.lower() == "business":
            _display_business_domain_help(console)
            return

        if command.lower() == "business-schema":
            _display_business_schema(console)
            return

        from obra.domains import get_available_domains

        domain_names = {name.lower() for name in get_available_domains()}
        if command.lower() in domain_names:
            _print_domain_recovery(command.lower())
            raise typer.Exit(1)

        # Find and show help for specific command
        cmd = click_app.get_command(ctx, command)
        if cmd is None:
            # Tier 2: Command not found - search for matching commands
            # Search for substring matches in command names and descriptions
            matches = []
            search_term = command.lower()

            for cmd_obj in app.registered_commands:
                if not cmd_obj.name:
                    continue

                # Check if search term is in command name
                if search_term in cmd_obj.name.lower():
                    matches.append((cmd_obj.name, "name match"))
                    continue

                # Check if search term is in command description
                if cmd_obj.help and search_term in cmd_obj.help.lower():
                    matches.append((cmd_obj.name, "description match"))

            if matches:
                console.print()
                console.print(f"[yellow]Commands matching '{command}':[/yellow]")
                console.print()
                for cmd_name, _match_type in matches:
                    # Get command to show its help snippet
                    cmd_match = click_app.get_command(ctx, cmd_name)
                    if cmd_match and cmd_match.help:
                        first_line = cmd_match.help.split("\n")[0]
                        console.print(f"  [cyan]obra {cmd_name}[/cyan]")
                        console.print(f"    {first_line}")
                        console.print()
                console.print("[dim]Run 'obra help <command>' for detailed help.[/dim]")
                return

            # No matches found - show error
            print_error(f"Unknown command: {command}")
            print_info("Run 'obra help' to see available commands.")
            raise typer.Exit(1)
        with click.Context(cmd, info_name=command, parent=ctx) as click_ctx:
            click.echo(cmd.get_help(click_ctx))


# =============================================================================
# Procs Command (Process Management)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def procs(
    kill: bool = typer.Option(
        False,
        "--kill",
        "-k",
        help="Kill running processes (not just stale PID files)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Manage Obra background processes and sessions.

    Lists tracked Obra processes (config explorer, etc.) and running sessions.
    Removes stale PID files and optionally kills running processes.

    Examples:
        obra procs             # List processes and sessions
        obra procs --kill      # Kill running processes too
        obra procs -k -f       # Kill without confirmation
    """
    from obra.hybrid.session_guard import find_running_sessions
    from obra.utils.process_guard import cleanup_stale_processes, find_stale_processes

    processes = find_stale_processes()
    sessions = find_running_sessions()

    if not processes and not sessions:
        console.print("[green]No Obra processes or sessions found.[/green]")
        return

    # Show running sessions
    if sessions:
        console.print("\n[bold]Running sessions:[/bold]\n")
        for hb in sessions:
            runtime_h = hb.runtime_seconds / 3600
            progress = (
                f"{hb.items_completed}/{hb.items_total}"
                if hb.items_total
                else str(hb.items_completed)
            )
            warning = ""
            if runtime_h >= 24:
                warning = " [yellow]LONG[/yellow]"
            console.print(
                f"  [cyan]{hb.short_id}[/cyan]: {runtime_h:.1f}h, "
                f"{progress} items, {hb.current_phase} (PID {hb.pid}){warning}"
            )
        console.print()

    # Show other processes
    if processes:
        console.print("[bold]Background processes:[/bold]\n")
        for name, pid, alive in processes:
            status = "[green]running[/green]" if alive else "[dim]stale[/dim]"
            console.print(f"  {name}: PID {pid} ({status})")

        running = [(name, pid) for name, pid, alive in processes if alive]
        stale = [(name, pid) for name, pid, alive in processes if not alive]

        if stale:
            console.print(f"\n[dim]Stale PID files: {len(stale)}[/dim]")
        if running:
            console.print(f"[yellow]Running processes: {len(running)}[/yellow]")

        # Determine what to clean up
        if running and not kill:
            console.print("\n[dim]Use --kill to terminate running processes.[/dim]")
            # Only clean stale
            if stale:
                for name, _pid in stale:
                    console.print(f"  [dim]Removed stale PID file: {name}[/dim]")
                cleanup_stale_processes(kill=False)
                console.print(f"\n[green]Cleaned {len(stale)} stale PID file(s).[/green]")
            return

        # Confirm before killing
        if running and kill and not force:
            console.print()
            if not typer.confirm(f"Kill {len(running)} running process(es)?"):
                console.print("[dim]Cancelled.[/dim]")
                return

        # Do the cleanup
        def on_cleanup(name: str, pid: int) -> None:
            console.print(f"  [green]Cleaned: {name} (PID {pid})[/green]")

        cleaned = cleanup_stale_processes(kill=kill, on_cleanup=on_cleanup)

        if cleaned:
            console.print(f"\n[green]Cleaned {len(cleaned)} process(es).[/green]")
        else:
            console.print("\n[dim]Nothing to clean.[/dim]")


# =============================================================================
# Models Command (Provider/Model Discovery)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def models(
    provider: str | None = typer.Option(
        None,
        "--provider",
        "-p",
        help="Filter to specific provider (anthropic, google, openai, ollama)",
    ),
) -> None:
    """List available LLM providers and models.

    Discovery command for LLM operators: use this to find valid provider/model
    names before running `obra run --model ... --impl-provider ...`. Pair with
    `obra help domains` for domain discovery and `obra help run` for execution
    flags.

    Examples:
        obra models                    # All providers
        obra models --provider openai  # OpenAI models only
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus

    # Filter providers if specified
    providers_to_show = (
        {provider: MODEL_REGISTRY[provider]}
        if provider and provider in MODEL_REGISTRY
        else MODEL_REGISTRY
    )

    if provider and provider not in MODEL_REGISTRY:
        print_error(f"Unknown provider: {provider}")
        print_info(f"Available providers: {', '.join(MODEL_REGISTRY.keys())}")
        raise typer.Exit(1)

    import shutil

    console.print("\n[bold]Available LLM Providers[/bold]\n")

    for _provider_key, config in providers_to_show.items():
        # Check CLI installation status
        cli_installed = shutil.which(config.cli) is not None
        status_icon = (
            f"[green]{glyphs.success}[/green]" if cli_installed else f"[red]{glyphs.failure}[/red]"
        )
        status_text = "installed" if cli_installed else "not installed"

        # Provider header
        console.print(f"[bold cyan]{config.name}[/bold cyan]")
        console.print(f"  CLI: [yellow]{config.cli}[/yellow] {status_icon} {status_text}")
        if config.default_model:
            console.print(f"  Default: [green]{config.default_model}[/green]")
        console.print()

        # Models table
        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("Model", style="cyan")
        table.add_column("Description")
        table.add_column("Status", style="dim")

        for model_id, model_info in config.models.items():
            if model_info.status == ModelStatus.DEPRECATED:
                continue  # Skip deprecated models

            status_str = model_info.status.value
            desc = model_info.description or ""
            if model_info.resolves_to:
                desc = (
                    f"{desc} \u2192 {model_info.resolves_to}"
                    if desc
                    else f"\u2192 {model_info.resolves_to}"
                )

            table.add_row(model_id, desc, status_str)

        console.print(table)
        console.print()

    # Usage examples section
    console.print("[bold]Usage Examples[/bold]\n")
    console.print("  [dim]# Discovery path[/dim]")
    console.print("  obra models")
    console.print("  obra help domains")
    console.print("  obra help run")
    console.print()
    console.print("  [dim]# Single provider run[/dim]")
    console.print('  obra run "Add user authentication" --model opus')
    console.print('  obra run "Fix tests" --impl-provider openai --model gpt-5.2')
    console.print()
    console.print("  [dim]# Parallel execution with multiple providers[/dim]")
    console.print('  obra run "Implement feature X" --model sonnet &')
    console.print('  obra run "Review code quality" --impl-provider openai &')
    console.print("  wait  # Wait for all jobs to complete")
    console.print()


# =============================================================================
# Main Workflow Commands
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def status(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to check (defaults to most recent)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (Tier 1: machine-readable format for LLM operators)",
    ),
    show_tasks: bool = typer.Option(
        False,
        "--tasks",
        "-t",
        help="Show inline task progress from the execution plan",
    ),
) -> None:
    """Check the status of a derivation session."""
    return status_commands.status(
        ctx,
        session_id=session_id,
        verbose=verbose,
        json_output=json_output,
        show_tasks=show_tasks,
    )


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def cleanup(
    session_id: str = typer.Option(
        ...,
        "--session-id",
        help="Session ID to clean up Obra-managed containers for",
    ),
) -> None:
    """Clean up Obra-managed containers for a session."""
    try:
        from obra.hybrid.handlers.story0 import cleanup_containers

        cleaned = cleanup_containers(session_id)
        if cleaned:
            print_success(f"Cleaned up {cleaned} Obra-managed containers for session {session_id}")
        else:
            print_info("No Obra-managed containers found for cleanup")
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception("Error cleaning up Story 0 containers: %s", e)
        raise typer.Exit(1) from e


# =============================================================================
# Setup Command (First-Time Onboarding)
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def setup(
    check: bool = typer.Option(
        False,
        "--check",
        help="Check setup status without prompting",
    ),
    skip_validation: bool = typer.Option(
        False,
        "--skip-validation",
        help="Skip environment validation after authentication",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
    device_code: bool = typer.Option(
        False,
        "--device-code",
        help="Use device code flow for headless/remote environments",
    ),
) -> None:
    """First-time setup with terms acceptance, authentication, and provider selection."""
    return setup_commands.setup(
        check=check,
        skip_validation=skip_validation,
        timeout=timeout,
        no_browser=no_browser,
        device_code=device_code,
    )


# Authentication commands extracted to obra/cli/auth.py
# Configuration commands extracted to obra/cli/config.py
from obra.cli.config import config_app  # noqa: E402

app.add_typer(config_app, name="config", rich_help_panel="User Commands")

# Documentation and log viewer commands extracted to obra/cli/docs.py


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def doctor(
    report: bool = typer.Option(
        False,
        "--report",
        help="Submit diagnostic report if checks fail (for troubleshooting)",
    ),
) -> None:
    """Run health checks on your Obra environment."""
    return doctor_commands.doctor(report=report)


# Skip tracking commands extracted to obra/cli/skips.py
# Prompt file management commands extracted to obra/cli/prompts.py
# Gateway server commands extracted to obra/cli/gateway.py


# =============================================================================
# Entry Point
# =============================================================================


def main() -> None:
    """Main entry point for the CLI.

    Tier 2: Includes command typo suggestions for better discoverability.
    """
    # Windows UTF-8 setup BEFORE any output (including --help)
    # This must run before Typer/Rich output anything with Unicode
    if sys.platform == "win32":
        os.environ["PYTHONUTF8"] = "1"
        # Reconfigure stdout/stderr for UTF-8 with fallback for unprintable chars
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    suppress_startup_chatter = _should_skip_startup_chatter()

    if not suppress_startup_chatter:
        _maybe_print_legacy_runtime_notice()

        # Dev-only: warn when pyproject.toml has changed since last pip install -e .
        # Zero-cost for wheel installs (no editable marker present).
        check_editable_install_freshness()

        # FEAT-CLI-AUTO-UPDATE-001: Auto-upgrade via detected package manager if behind (synchronous)
        # Returns True if it attempted an update (success or fail).
        # On successful upgrade, try_auto_update() re-execs and never returns.
        auto_updated = try_auto_update()

        # FEAT-CLI-VERSION-NOTIFY-001: Fallback notification when auto-update is off
        if not auto_updated:
            check_for_updates_async()

    # Tier 2: Wrap app() to catch unknown commands and suggest alternatives
    try:
        app()
    except SystemExit as e:
        # Check if this is an unknown command error (exit code 2 from Click)
        if e.code == 2 and len(sys.argv) > 1:
            import difflib

            # Get the command that was attempted
            attempted_cmd = sys.argv[1]

            # Skip if it starts with - (it's a flag, not a command)
            if attempted_cmd.startswith("-"):
                raise

            from obra.domains import get_available_domains

            domain_names = {name.lower() for name in get_available_domains()}
            if attempted_cmd.lower() in domain_names:
                _print_domain_recovery(attempted_cmd.lower())
                raise SystemExit(2) from e

            # Get all available command names
            all_commands = [cmd.name for cmd in app.registered_commands if cmd.name]

            # Find close matches
            suggestions = difflib.get_close_matches(attempted_cmd, all_commands, n=3, cutoff=0.6)

            if suggestions:
                console.print()
                console.print("[yellow]\U0001f4a1 Did you mean:[/yellow]")
                for suggestion in suggestions:
                    console.print(f"   \u2022 obra {suggestion}")
                console.print()
                console.print("[dim]Run 'obra --help' for full command list.[/dim]")
                raise SystemExit(2) from e
        raise


if __name__ == "__main__":
    main()
