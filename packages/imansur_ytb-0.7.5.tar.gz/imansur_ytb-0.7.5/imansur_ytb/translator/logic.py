import os
import json
import sqlite3
import httpx
import re
import shutil
import threading
import time
from pathlib import Path
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed

load_dotenv()
db_lock = threading.Lock()

DEFAULT_PROMPT = """ROLE
You are a professional Audio-Visual Translation (AVT) specialist and Dubbing Script Writer.

CORE MISSION
Translate the provided English JSON transcript into Turkish while ensuring the spoken duration of the Turkish text matches the original English timing exactly. Use a "Two-Pass" strategy: translate, then condense to fit.

STRICT TIMING RULES (CRITICAL):
1. Logical Grouping: Group English segments into logical Turkish sentences.
2. NO IDS: Do NOT return "ids", "index", or "id".
3. CALCULATE TIMES: For every Turkish segment, you MUST provide:
    - "start": The exact 'start' time of the first English segment in your group.
    - "end": The exact 'end' time (start + duration) of the last English segment in your group.
    - "duration": The calculated 'end' minus 'start'.
4. NO OVERLAPS: The 'start' of segment N must be greater than or equal to the 'end' of segment N-1. Do NOT overlap timings.
5. 1.0x SPEED: Assume ~13-15 characters per second. If the Turkish text is too long, SHORTEN it aggressively.

GLOSSARY (DO NOT TRANSLATE THESE):
{glossary}

OUTPUT FORMAT (STRICT JSON OBJECT):
{{
  "segments": [
    {{
      "start": 10.5,
      "end": 15.2,
      "duration": 4.7,
      "text": "Kısa ve öz Türkçe çeviri."
    }}
  ],
  "new_terms": {{"Term": "Okunuş"}}
}}

GİRDİ:
{json_data}"""

class Translator:
    def __init__(self, db_path="glossary.db"):
        self.user_db_path = db_path
        self._initialize_db()

    def _initialize_db(self):
        with db_lock:
            # Create DB if not exists
            if not os.path.exists(self.user_db_path):
                pkg_db = Path(__file__).parent / "data" / "default_glossary.db"
                if pkg_db.exists(): shutil.copy(pkg_db, self.user_db_path)
                else: self._create_empty_db_raw()
            
            # FORCE UPDATE PROMPT (Cache busting)
            try:
                conn = sqlite3.connect(self.user_db_path)
                c = conn.cursor()
                c.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
                c.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)", ("system_prompt", DEFAULT_PROMPT))
                conn.commit()
                conn.close()
            except: pass

    def _create_empty_db_raw(self):
        conn = sqlite3.connect(self.user_db_path)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS terms (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT UNIQUE NOT NULL, phonetic TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
        c.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)", ("system_prompt", DEFAULT_PROMPT))
        conn.commit()
        conn.close()

    def get_terms(self):
        with db_lock:
            conn = sqlite3.connect(self.user_db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT term FROM terms")
            terms = [row[0] for row in cursor.fetchall()]
            conn.close()
            return terms

    def add_new_terms(self, new_terms):
        if not new_terms: return 0
        with db_lock:
            conn = sqlite3.connect(self.user_db_path)
            cursor = conn.cursor()
            added = 0
            for term, phonetic in new_terms.items():
                try:
                    cursor.execute("INSERT INTO terms (term, phonetic) VALUES (?, ?)", (term, phonetic))
                    added += 1
                except: pass
            conn.commit()
            conn.close()
            return added

    def get_prompt(self):
        try:
            with db_lock:
                conn = sqlite3.connect(self.user_db_path)
                cursor = conn.cursor()
                cursor.execute("SELECT value FROM metadata WHERE key = 'system_prompt'")
                row = cursor.fetchone()
                conn.close()
                return row[0] if row else DEFAULT_PROMPT
        except:
            return DEFAULT_PROMPT

    def call_gemini(self, api_key, prompt, model="gemini-2.5-flash", verbose=False):
        url = f"https://generativelanguage.googleapis.com/v1/models/{model.split('/')[-1]}:generateContent?key={api_key}"
        payload = {"contents": [{"parts": [{"text": prompt}]}]}
        for i in range(3):
            try:
                with httpx.Client(timeout=120.0) as client:
                    res = client.post(url, json=payload)
                    res.raise_for_status()
                    raw = res.json()['candidates'][0]['content']['parts'][0]['text']
                    match = re.search(r'\{.*\}', raw, re.DOTALL) 
                    return json.loads(match.group()) if match else json.loads(raw)
            except Exception as e:
                if verbose: print(f"    [!] Attempt {i+1} failed: {e}")
                time.sleep(5)
        raise Exception("AI failed.")

def translate_transcript(transcript_path, api_key=None, video_url=None, model="gemini-2.5-flash", db_path="glossary.db", verbose=False):
    if not api_key: api_key = os.getenv("GEMINI_API_KEY")
    if not api_key: return []
    
    with open(transcript_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    transcript = data.get("segments", data) if isinstance(data, dict) else data
    if verbose: print(f"[*] Processing {len(transcript)} raw segments...")

    translator = Translator(db_path)
    chunk_size = 20 
    chunks = [transcript[i:i + chunk_size] for i in range(0, len(transcript), chunk_size)]

    def process_pass(current_chunks, pass_label="Pass"):
        results_segments = []
        any_new_found = False
        
        def process_chunk(chunk):
            # NO IDs here to avoid confusing the AI
            input_list = [{"text": seg["text"], "start": seg["start"], "duration": seg["duration"]} for seg in chunk]
            
            prompt = translator.get_prompt().replace("{json_data}", json.dumps(input_list, ensure_ascii=False))
            prompt = prompt.replace("{glossary}", ", ".join(translator.get_terms()) if translator.get_terms() else "None")
            prompt = prompt.replace("{video_url}", video_url or "https://youtube.com")
            
            return translator.call_gemini(api_key, prompt, model, verbose)

        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(process_chunk, c) for c in current_chunks]
            for f in as_completed(futures):
                try:
                    res = f.result()
                    segs = res.get("segments", [])
                    if isinstance(segs, list): results_segments.extend(segs)
                    
                    new_terms = res.get("new_terms", {})
                    if new_terms:
                        added = translator.add_new_terms(new_terms)
                        if added > 0: any_new_found = True
                except Exception as e:
                    if verbose: print(f"[!] Chunk error in {pass_label}: {e}")
        
        results_segments.sort(key=lambda x: x.get("start", 0))
        return results_segments, any_new_found

    # PHASE 1: Discovery Pass
    if verbose: print("[*] Phase 1: Discovery & Preliminary Translation...")
    first_pass_segments, found_new = process_pass(chunks, "Phase 1")

    # PHASE 2: Final Pass (If new terms were discovered)
    final_segments = first_pass_segments
    if found_new:
        if verbose: print("[*] Phase 2: Re-translating with enriched glossary for consistency...")
        final_segments, _ = process_pass(chunks, "Phase 2")

    if not final_segments: return []

    # Save output
    out = transcript_path.replace(".json", "_tr.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(final_segments, f, ensure_ascii=False, indent=2)
    
    if verbose: print(f"[+] Saved {len(final_segments)} translated blocks to {out}.")
    return final_segments


