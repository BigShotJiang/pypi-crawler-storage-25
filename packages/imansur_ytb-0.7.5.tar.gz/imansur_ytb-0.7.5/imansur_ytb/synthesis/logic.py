import os
import json
import asyncio
import subprocess
import shutil
import sqlite3
import edge_tts
import re
from pathlib import Path

# --- PHONETIC REPLACEMENT LOGIC ---
def _apply_phonetics(text, db_path):
    if not os.path.exists(db_path): return text
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT term, phonetic FROM terms")
        rows = cursor.fetchall()
        conn.close()
        rows.sort(key=lambda x: len(x[0]), reverse=True)
        for term, phonetic in rows:
            pattern = re.compile(re.escape(term), re.IGNORECASE)
            text = pattern.sub(phonetic, text)
    except: pass
    return text

def _get_audio_duration(file_path):
    cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    try: return float(result.stdout.strip())
    except: return 0.0

async def _text_to_speech(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz"):
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)

def synthesize_text(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz", db_path="glossary.db"):
    processed_text = _apply_phonetics(text, db_path)
    asyncio.run(_text_to_speech(processed_text, output_path, voice, rate, pitch))
    return output_path

def synthesize_transcript(transcript_path, output_file="final_dub.mp3", voice="tr-TR-AhmetNeural", db_path="glossary.db", verbose=False):
    if not os.path.exists(transcript_path): raise FileNotFoundError(f"Transcript not found: {transcript_path}")

    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    temp_dir = Path("temp_audio_segments")
    temp_dir.mkdir(exist_ok=True)
    
    # We will build a complex filter or a sequence of files. 
    # To ensure ZERO drift, we use a fixed timeline approach.
    segments_to_concat = []
    
    current_timeline_pos = 0.0
    if verbose: print(f"[*] Synthesis started for {len(transcript)} segments. Target Sync: 100%")

    for i, entry in enumerate(transcript):
        text = entry['text']
        start_time = entry['start']
        duration = entry.get('duration', entry.get('end', start_time + 2) - start_time)
        
        # 1. Handle Gap (Silence)
        gap = start_time - current_timeline_pos
        if gap > 0.001:
            silence_file = temp_dir / f"silence_{i}.mp3"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono", 
                "-t", f"{gap:.3f}", str(silence_file)
            ], stderr=subprocess.DEVNULL)
            segments_to_concat.append(silence_file)
            current_timeline_pos += gap

        # 2. Synthesize Segment
        seg_raw = temp_dir / f"seg_{i}_raw.mp3"
        seg_final = temp_dir / f"seg_{i}_final.mp3"
        
        synthesize_text(text, str(seg_raw), voice=voice, db_path=db_path)
        actual_duration = _get_audio_duration(seg_raw)
        
        # 3. Hard Sync Logic: Force the audio to fit the EXACT duration available 
        # until the next segment starts to prevent any cumulative drift.
        if i < len(transcript) - 1:
            next_start = transcript[i+1]['start']
        else:
            next_start = start_time + duration
            
        allowed_duration = next_start - start_time
        if allowed_duration <= 0: allowed_duration = 0.1 # Minimum safety

        if actual_duration > 0:
            speed_factor = actual_duration / allowed_duration
            
            filter_str = ""
            temp_factor = speed_factor
            while temp_factor > 2.0:
                filter_str += "atempo=2.0,"
                temp_factor /= 2.0
            while temp_factor < 0.5:
                filter_str += "atempo=0.5,"
                temp_factor /= 0.5
            filter_str += f"atempo={temp_factor:.3f}"

            subprocess.run([
                "ffmpeg", "-y", "-i", str(seg_raw), 
                "-filter:a", filter_str, str(seg_final)
            ], stderr=subprocess.DEVNULL)
        else:
            shutil.copy(seg_raw, seg_final)

        segments_to_concat.append(seg_final)
        current_timeline_pos = next_start # Always snap to the next start

    # Final Concat
    concat_list_path = temp_dir / "concat.txt"
    with open(concat_list_path, "w", encoding="utf-8") as f:
        for seg in segments_to_concat:
            f.write(f"file '{seg.absolute()}'\n")

    if verbose: print(f"[*] Concatenating into {output_file}...")
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list_path), 
        "-c", "copy", output_file
    ], stderr=subprocess.DEVNULL)

    # Cleanup
    try: shutil.rmtree(temp_dir)
    except: pass
    return output_file
