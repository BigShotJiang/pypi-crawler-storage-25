from .cog import FastAFK


async def setup(bot):
    await bot.add_cog(FastAFK(bot))
