from __future__ import annotations

import asyncio
import logging
import time
from datetime import UTC, datetime

import discord
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import AfkGuildConfig
from .services.afk_service import AFKEntry, AFKService

log = logging.getLogger("ember.afk")

_ = Translator("afk", __file__)

NICK_PREFIX = "[AFK] "
_AFK_SAFE_COMMANDS = frozenset(("afk", "afklist", "afkstats", "afkclean"))


@feature(
    display_name="AFK System",
    emoji="💤",
    description="Sets AFK status and prefixes your nickname. Use `.afk [reason]` to activate.",
    fields=[
        ConfigField(
            key="nick_prefix_enabled",
            label="Nickname Prefix",
            type=FieldType.BOOLEAN,
            description="Prepend [AFK] to nickname while AFK.",
            default=True,
        ),
    ],
)
@cog_i18n(_)
class FastAFK(EmberCog, name="AFK"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.afk_service = AFKService()

        self._afk_cache: dict[tuple[int, int], AFKEntry] = {}

        self._nick_edit_timestamps: dict[int, float] = {}
        self._nick_edit_cooldown: float = 1.0

        self._last_mention_notify: dict[int, float] = {}
        self._last_welcome_back: dict[int, float] = {}
        self._mention_cooldown: float = 5.0
        self._welcome_back_cooldown: float = 5.0
        self._afk_removal_cooldown: dict[tuple[int, int], float] = {}
        self._min_afk_duration: float = 2.0
        self._message_queue: dict[int, asyncio.Queue] = {}
        self._message_queue_lock = asyncio.Lock()
        self._message_limit_cooldown: float = 5
        self.stats: dict[str, int] = {
            "messages_processed": 0,
            "fast_path_skipped": 0,
            "afk_removed": 0,
            "mentions_checked": 0,
            "cleanup_passes": 0,
        }
        self._cleanup_task: asyncio.Task | None = None
        self.db.register_schema("guild", AfkGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)
        await self._preload_cache()
        self._cleanup_task = asyncio.create_task(self._periodic_cleanup())

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        user_afk_cache_keys = [
            cache_key for cache_key in self._afk_cache if cache_key[1] == user_id
        ]
        for cache_key in user_afk_cache_keys:
            self._afk_cache.pop(cache_key, None)
            self._afk_removal_cooldown.pop(cache_key, None)
        self._nick_edit_timestamps.pop(user_id, None)
        await self.afk_service.remove_afk_all_guilds(user_id)
        return {}

    async def _preload_cache(self) -> None:
        try:
            afk_users = await self.afk_service.get_all_afk_users()
            for afk_record in afk_users:
                try:
                    entry_user_id = int(afk_record["user_id"])
                    entry_guild_id = int(afk_record.get("guild_id", 0))
                    entry_timestamp = datetime.fromisoformat(afk_record["since"])
                    if entry_timestamp.tzinfo is None:
                        entry_timestamp = entry_timestamp.replace(tzinfo=UTC)
                    cache_key = (entry_guild_id, entry_user_id)
                    self._afk_cache[cache_key] = AFKEntry(
                        entry_user_id, entry_guild_id, afk_record["reason"], entry_timestamp
                    )
                except (ValueError, KeyError):
                    continue
        except Exception as error:
            log.error("AFK cache preload failed: %s", error)

    def _get_guild_afk_user_ids(self, guild_id: int) -> set[int]:
        return {
            user_id for (cache_guild_id, user_id) in self._afk_cache if cache_guild_id == guild_id
        }

    async def _remove_afk_internal(self, user_id: int, guild_id: int) -> None:
        key = (guild_id, user_id)
        self._afk_cache.pop(key, None)
        self._afk_removal_cooldown.pop(key, None)
        self._nick_edit_timestamps.pop(user_id, None)
        await self.afk_service.remove_afk(user_id, guild_id)

    async def _periodic_cleanup(self) -> None:
        while True:
            await asyncio.sleep(3600)
            self.stats["cleanup_passes"] += 1
            stale_cache_keys = [
                cache_key
                for cache_key in self._afk_cache
                if self.bot.get_user(cache_key[1]) is None
            ]
            for stale_key in stale_cache_keys:
                await self._remove_afk_internal(stale_key[1], stale_key[0])
            cutoff_timestamp = (
                time.time() - max(self._mention_cooldown, self._welcome_back_cooldown) * 2
            )
            self._last_mention_notify = {
                channel_id: timestamp
                for channel_id, timestamp in self._last_mention_notify.items()
                if timestamp > cutoff_timestamp
            }
            self._last_welcome_back = {
                channel_id: timestamp
                for channel_id, timestamp in self._last_welcome_back.items()
                if timestamp > cutoff_timestamp
            }

    async def _is_enabled_in_guild(self, guild_id: int) -> bool:
        return await self.db.guild(guild_id).get("enabled", default=True)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if not message.guild or message.author.bot:
            return

        if not await self._is_enabled_in_guild(message.guild.id):
            return

        self.stats["messages_processed"] += 1

        guild_id = message.guild.id
        author_id = message.author.id
        cache_key = (guild_id, author_id)

        if not self._afk_cache and not message.mentions:
            self.stats["fast_path_skipped"] += 1
            await self.bot.process_commands(message)
            return

        entry = self._afk_cache.get(cache_key)

        if entry:
            is_command = False
            try:
                raw = await self.bot.get_prefix(message)
                resolved_prefixes = tuple(raw) if not isinstance(raw, str) else (raw,)
                is_command = message.content.startswith(resolved_prefixes)
            except Exception:
                is_command = message.content.startswith(("!", "?", ".", "/"))

            if is_command:
                await self.bot.process_commands(message)
                return

            current_time = time.time()
            if (
                current_time - self._afk_removal_cooldown.get(cache_key, 0.0)
                >= self._min_afk_duration
            ):
                afk_duration = entry.human_readable_duration
                await self._remove_afk_internal(author_id, guild_id)
                self.stats["afk_removed"] += 1

                ch_id = message.channel.id
                now = time.time()
                if now - self._last_welcome_back.get(ch_id, 0.0) >= self._welcome_back_cooldown:
                    self._last_welcome_back[ch_id] = now
                    view = discord.ui.LayoutView(timeout=None)
                    view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("## 👋 Welcome Back!"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(
                                f"{message.author.mention}, AFK removed.\n"
                                f"You were AFK for **{afk_duration}**."
                            ),
                            accent_color=EmberColors.WARNING,
                        )
                    )
                    asyncio.create_task(
                        self._queued_send(
                            message.channel,
                            view,
                            20,
                            allowed_mentions=discord.AllowedMentions.none(),
                        )
                    )

        await self.bot.process_commands(message)

        if message.mentions and self._afk_cache:
            self.stats["mentions_checked"] += 1
            current_time = time.time()
            if (
                current_time - self._last_mention_notify.get(message.channel.id, 0.0)
                >= self._mention_cooldown
            ):
                for mentioned_user in message.mentions:
                    if mentioned_user.id == message.author.id:
                        continue
                    afk_entry = self._afk_cache.get((guild_id, mentioned_user.id))
                    if afk_entry:
                        clean_display_name = mentioned_user.display_name.removeprefix(NICK_PREFIX)
                        view = discord.ui.LayoutView(timeout=None)
                        view.add_item(
                            discord.ui.Container(
                                discord.ui.TextDisplay(f"## {clean_display_name} is AFK 💤"),
                                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                                discord.ui.TextDisplay(
                                    f"**Reason:** {self.afk_service.sanitize_reason(afk_entry.reason)}\n"
                                    f"**AFK for:** {afk_entry.human_readable_duration}"
                                ),
                                accent_color=discord.Color.from_rgb(255, 200, 0),
                            )
                        )
                        asyncio.create_task(
                            self._queued_send(
                                message.channel,
                                view,
                                600,
                                allowed_mentions=discord.AllowedMentions.none(),
                            )
                        )
                        self._last_mention_notify[message.channel.id] = current_time
                        break

    @commands.command(name="afk")
    async def afk_command(self, ctx: commands.Context, *, reason: str = "AFK") -> None:
        if not ctx.guild:
            return

        if not await self._is_enabled_in_guild(ctx.guild.id):
            return

        try:
            await ctx.message.delete()
        except Exception:
            pass

        user = ctx.author
        guild_id = ctx.guild.id
        cache_key = (guild_id, user.id)
        existing = self._afk_cache.get(cache_key)
        reason = self.afk_service.sanitize_reason(reason)

        if existing:
            if existing.reason == reason:
                return
            entry = AFKEntry(user.id, guild_id, reason, existing.since)
            self._afk_cache[cache_key] = entry
            self._afk_removal_cooldown[cache_key] = time.time()
            await self.afk_service.set_afk(user.id, guild_id, reason)
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✏️ AFK Updated"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"{user.mention}, AFK reason updated to: **{reason}**"),
                    accent_color=EmberColors.WARNING,
                )
            )
        else:
            since = datetime.now(UTC)
            entry = AFKEntry(user.id, guild_id, reason, since)
            self._afk_cache[cache_key] = entry
            self._afk_removal_cooldown[cache_key] = time.time()
            await self.afk_service.set_afk(user.id, guild_id, reason)
            if isinstance(user, discord.Member):
                if not user.display_name.startswith(NICK_PREFIX):
                    asyncio.create_task(
                        self._safe_edit_nick(user, f"{NICK_PREFIX}{user.display_name}")
                    )
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ AFK Set"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"{user.mention}, you are now AFK: **{reason}**"),
                    accent_color=EmberColors.WARNING,
                )
            )

        msg = await ctx.send(view=view, allowed_mentions=discord.AllowedMentions.none())
        asyncio.create_task(self._auto_delete_message(msg, 20))

    @commands.command(name="afklist")
    @commands.is_owner()
    async def afk_list(self, ctx: commands.Context) -> None:
        if not ctx.guild:
            return
        guild_id = ctx.guild.id
        guild_entries = {uid: e for (gid, uid), e in self._afk_cache.items() if gid == guild_id}
        if not guild_entries:
            return await ctx.reply(
                "No users are currently AFK in this server.", mention_author=False
            )
        lines: list[str] = []
        for uid, e in list(guild_entries.items())[:50]:
            u = self.bot.get_user(uid)
            lines.append(
                f"{u.mention if u else f'Unknown ({uid})'} — `{e.reason}` *(for {e.human_readable_duration})*"
            )
        view = discord.ui.LayoutView(timeout=None)
        children = [
            discord.ui.TextDisplay("## 📜 AFK List"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay("\n".join(lines)),
            discord.ui.TextDisplay(f"-# Total AFK in this server: {len(guild_entries)}"),
        ]
        view.add_item(discord.ui.Container(*children, accent_color=EmberColors.WARNING))
        await ctx.reply(
            view=view, mention_author=False, allowed_mentions=discord.AllowedMentions.none()
        )

    @commands.command(name="afkstats")
    @commands.is_owner()
    async def afk_stats(self, ctx: commands.Context) -> None:
        total = self.stats["messages_processed"]
        eff = self.stats["fast_path_skipped"] / total * 100 if total else 0.0
        view = discord.ui.LayoutView(timeout=None)
        stats_text = (
            f"**Active AFK entries (all guilds):** {len(self._afk_cache)}\n"
            f"**Messages processed:** {total}\n"
            f"**Fast-path skipped:** {self.stats['fast_path_skipped']}\n"
            f"**AFK removals:** {self.stats['afk_removed']}\n"
            f"**Mentions checked:** {self.stats['mentions_checked']}\n"
            f"**Cleanup passes:** {self.stats['cleanup_passes']}\n"
            f"**Fast-path efficiency:** {eff:.1f}%"
        )
        children = [
            discord.ui.TextDisplay("## 📊 AFK System Stats"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay(stats_text),
        ]
        view.add_item(discord.ui.Container(*children, accent_color=discord.Color.blurple()))
        await ctx.reply(
            view=view, mention_author=False, allowed_mentions=discord.AllowedMentions.none()
        )

    @commands.command(name="afkclean")
    @commands.is_owner()
    async def afk_clean(self, ctx: commands.Context) -> None:
        await ctx.reply(
            "🧹 Cleaning up AFK entries…",
            mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        stale = [k for k in list(self._afk_cache) if self.bot.get_user(k[1]) is None]
        for k in stale:
            await self._remove_afk_internal(k[1], k[0])
        await ctx.reply(
            f"✅ Removed {len(stale)} stale AFK entries.",
            mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    async def _queued_send(
        self,
        channel: discord.TextChannel,
        view: discord.ui.LayoutView,
        delete_after: int | None = None,
        allowed_mentions: discord.AllowedMentions | None = None,
    ) -> None:
        # Lock spans the put so the worker can't pop+exit between get-or-create and enqueue.
        async with self._message_queue_lock:
            queue = self._message_queue.get(channel.id)
            if queue is None:
                queue = asyncio.Queue()
                self._message_queue[channel.id] = queue
                asyncio.create_task(self._process_channel_queue(channel.id))
            queue.put_nowait((channel, view, delete_after, allowed_mentions))

    async def _process_channel_queue(self, channel_id: int) -> None:
        queue = self._message_queue[channel_id]
        while True:
            try:
                channel, view, delete_after, allowed_mentions = await asyncio.wait_for(
                    queue.get(), timeout=self._message_limit_cooldown + 1
                )
            except TimeoutError:
                async with self._message_queue_lock:
                    if queue.empty():
                        self._message_queue.pop(channel_id, None)
                        return
                continue
            try:
                msg = await channel.send(view=view, allowed_mentions=allowed_mentions)
                if delete_after:
                    asyncio.create_task(self._auto_delete_message(msg, delete_after))
            except Exception:
                pass
            finally:
                queue.task_done()
                await asyncio.sleep(self._message_limit_cooldown)

    async def _safe_edit_nick(self, member: discord.Member, new_nick: str) -> None:
        now = time.time()
        if now - self._nick_edit_timestamps.get(member.id, 0.0) < self._nick_edit_cooldown:
            return
        try:
            await member.edit(nick=new_nick)
            self._nick_edit_timestamps[member.id] = now
        except Exception:
            pass

    async def _auto_delete_message(self, message: discord.Message, delay: int) -> None:
        await asyncio.sleep(delay)
        try:
            await message.delete()
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(FastAFK(bot))
