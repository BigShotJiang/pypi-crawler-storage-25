from typing import TypedDict


class AfkGuildConfig(TypedDict, total=False):
    """Guild-level afk configuration."""

    enabled: bool
