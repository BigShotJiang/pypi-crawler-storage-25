import logging
import re
from dataclasses import dataclass
from datetime import UTC, datetime

from core.store import Store

logger = logging.getLogger("ember.afk.service")

AFK_MAX_REASON_LENGTH = 100
NICK_PREFIX = "[AFK] "


@dataclass(frozen=True)
class AFKEntry:
    user_id: int
    guild_id: int
    reason: str
    since: datetime

    @property
    def human_readable_duration(self) -> str:
        delta = datetime.now(UTC) - self.since
        if delta.days > 0:
            return f"{delta.days} day{'s' if delta.days != 1 else ''}"
        if delta.seconds >= 3600:
            h = delta.seconds // 3600
            return f"{h} hour{'s' if h != 1 else ''}"
        if delta.seconds >= 60:
            m = delta.seconds // 60
            return f"{m} minute{'s' if m != 1 else ''}"
        return f"{delta.seconds} second{'s' if delta.seconds != 1 else ''}"


class AFKService:
    def __init__(self):
        self.db = Store.for_cog("afk")
        self._table_registered = False

    async def _ensure_table(self):
        if not self._table_registered:
            self.db.register_table("""
                CREATE TABLE IF NOT EXISTS afk (
                    user_id  TEXT    NOT NULL,
                    guild_id INTEGER NOT NULL DEFAULT 0,
                    reason   TEXT    NOT NULL DEFAULT '',
                    since    TEXT    NOT NULL,
                    PRIMARY KEY (user_id, guild_id)
                )
            """)
            self._table_registered = True
            await self.db.initialize()

    async def initialize_tables(self) -> None:
        """Public alias for _ensure_table; useful for testing and startup."""
        await self._ensure_table()

    def sanitize_reason(self, reason: str) -> str:
        if not reason:
            return "AFK"
        lines = [line.strip() for line in reason.split("\n") if line.strip()]
        cleaned = re.sub(r"\s+", " ", " ".join(lines))
        if len(cleaned) > AFK_MAX_REASON_LENGTH:
            cleaned = cleaned[: AFK_MAX_REASON_LENGTH - 3] + "..."
        return cleaned or "AFK"

    async def get_afk_entry(self, user_id: int, guild_id: int) -> AFKEntry | None:
        await self._ensure_table()
        try:
            row = await self.db.find_one("afk", user_id=str(user_id), guild_id=guild_id)
            if row:
                entry_user_id = int(row["user_id"])
                entry_guild_id = int(row["guild_id"])
                entry_timestamp = datetime.fromisoformat(row["since"])
                if entry_timestamp.tzinfo is None:
                    entry_timestamp = entry_timestamp.replace(tzinfo=UTC)
                return AFKEntry(entry_user_id, entry_guild_id, row["reason"], entry_timestamp)
        except Exception as error:
            logger.error("Error getting AFK entry: %s", error)
        return None

    async def set_afk(self, user_id: int, guild_id: int, reason: str) -> AFKEntry:
        await self._ensure_table()
        since = datetime.now(UTC)
        await self.db.store(
            "afk",
            {
                "user_id": str(user_id),
                "guild_id": guild_id,
                "reason": reason,
                "since": since.isoformat(),
            },
            pk_columns=["user_id", "guild_id"],
        )
        return AFKEntry(user_id, guild_id, reason, since)

    async def remove_afk(self, user_id: int, guild_id: int) -> bool:
        await self._ensure_table()
        try:
            removed_count = await self.db.remove("afk", user_id=str(user_id), guild_id=guild_id)
            return removed_count > 0
        except Exception as error:
            logger.error("Error removing AFK entry: %s", error)
            return False

    async def remove_afk_all_guilds(self, user_id: int) -> int:
        await self._ensure_table()
        try:
            return await self.db.remove("afk", user_id=str(user_id))
        except Exception as error:
            logger.error("Error removing all AFK entries for user: %s", error)
            return 0

    async def get_all_afk_users(self) -> list[dict]:
        await self._ensure_table()
        try:
            return await self.db.find("afk")
        except Exception as error:
            logger.error("Error getting all AFK users: %s", error)
            return []

    async def is_user_afk(self, user_id: int, guild_id: int) -> bool:
        return await self.get_afk_entry(user_id, guild_id) is not None
