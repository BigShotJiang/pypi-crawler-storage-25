from typing import TypedDict


class WelcomeGuildConfig(TypedDict, total=False):
    """Guild-level welcome configuration."""

    enabled: bool
