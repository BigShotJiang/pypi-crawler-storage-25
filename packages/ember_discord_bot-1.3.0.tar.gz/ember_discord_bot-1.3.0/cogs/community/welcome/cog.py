from __future__ import annotations

import logging

import discord
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import WelcomeGuildConfig

_ = Translator("welcome", __file__)

log = logging.getLogger("ember.welcome")

DEFAULT_MESSAGE_TEMPLATE = "Welcome to {guild}, {user}!"


@cog_i18n(_)
@feature(
    display_name="Welcome Messages",
    description="Sends a customisable welcome message when a new member joins the server.",
    emoji="👋",
    fields=[
        ConfigField(
            key="channel_id",
            label="Welcome Channel",
            type=FieldType.CHANNEL,
            description="Channel where welcome messages are posted.",
            required=True,
        ),
        ConfigField(
            key="message_template",
            label="Message Template",
            type=FieldType.TEXT,
            description="Supports {user}, {username}, {guild}, {member_count}.",
            placeholder="Welcome to {guild}, {user}! You are member #{member_count}.",
            default="Welcome to {guild}, {user}!",
            max_length=500,
        ),
    ],
)
class WelcomeCog(EmberCog, name="Welcome"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "enabled": True,
                    "channel_id": None,
                    "message_template": DEFAULT_MESSAGE_TEMPLATE,
                },
            }
        )
        self.db.register_schema("guild", WelcomeGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        guild = member.guild
        cfg = await self.db.get_all("guild", guild.id)
        if not cfg.get("enabled", True):
            return

        channel_id = cfg.get("channel_id")
        if not channel_id:
            return

        channel = guild.get_channel(channel_id)
        if not channel:
            return

        try:
            template = cfg.get("message_template", DEFAULT_MESSAGE_TEMPLATE)
            message = template.format(
                user=member.mention,
                username=member.name,
                guild=guild.name,
                member_count=guild.member_count,
            )
            welcome_view = discord.ui.LayoutView(timeout=None)
            welcome_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay(message),
                    accent_color=discord.Color.blurple(),
                )
            )
            await channel.send(view=welcome_view)
        except (discord.Forbidden, discord.HTTPException) as e:
            log.error("Failed to send welcome message: %s", e)


async def setup(bot: discord.Client) -> None:
    await bot.add_cog(WelcomeCog(bot))
