from typing import TypedDict


class ActivityRolesGuildConfig(TypedDict, total=False):
    """Guild-level activity_roles configuration."""

    enabled: bool
