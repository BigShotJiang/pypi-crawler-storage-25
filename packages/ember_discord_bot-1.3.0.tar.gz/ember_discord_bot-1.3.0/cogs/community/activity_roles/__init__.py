from .cog import ActivityRoles


async def setup(bot):
    await bot.add_cog(ActivityRoles(bot))
