import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp
import discord
from discord import ButtonStyle, Interaction, SelectOption, ui
from discord.ext import commands

from core.branding import EmberColors
from utils.cards import make_error_card, make_info_card, make_success_card, make_warning_card

from .modals import CreateRoleModal, RoleColorsModal, RoleNameModal

logger = logging.getLogger("ember.booster_roles")


class RenounceConfirmationView(discord.ui.LayoutView):
    """LayoutView for confirming role renouncement — display + buttons in one component."""

    def __init__(self, cog, role: discord.Role, owner_id: int, owner_mention: str | None = None):
        super().__init__(timeout=60.0)
        self.cog = cog
        self.role = role
        self.owner_id = owner_id
        self.confirmed = False

        owner_line = f"\n**Bestowed By:** {owner_mention}" if owner_mention else ""
        body = (
            f"**Role:** {role.mention}\n**Color:** `{role.color}`{owner_line}\n\n"
            "**If you renounce:**\n"
            "• Role will be removed from you\n"
            "• You will lose all role permissions\n"
            "• Owner will be notified\n"
            "• You can be invited again later"
        )
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ⚠️ Renounce Role"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(body),
                accent_color=EmberColors.WARNING,
            )
        )

        confirm_btn = discord.ui.Button(
            label="✅ Renounce Role", style=ButtonStyle.danger, emoji="🚫"
        )
        confirm_btn.callback = self._confirm_callback

        cancel_btn = discord.ui.Button(label="❌ Keep Role", style=ButtonStyle.secondary)
        cancel_btn.callback = self._cancel_callback
        self.add_item(discord.ui.ActionRow(confirm_btn, cancel_btn))

    async def _confirm_callback(self, inter: Interaction):
        await inter.response.defer(ephemeral=True)
        self.confirmed = True
        self.stop()

        try:
            await inter.user.remove_roles(self.role, reason="User renounced bestowed role")

            await self.cog.db.remove("bestowals", giver_id=self.owner_id, receiver_id=inter.user.id)

            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ Role Renounced"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"You have renounced **{self.role.name}**\n\n"
                        "**What changed?**\n"
                        "• Role removed from your profile\n"
                        "• Database entry cleared\n"
                        "• Owner has been notified\n\n"
                        "**Want it back?** The owner can send you a new invitation anytime."
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await inter.edit_original_response(view=result)

            try:
                owner = inter.guild.get_member(self.owner_id)
                if owner:
                    notify_view = discord.ui.LayoutView(timeout=None)
                    notify_view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("## 🎭 Role Renounced"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(
                                f"{inter.user.mention} has renounced your role **{self.role.name}**\n\n"
                                f"**User:** {inter.user.mention}\n"
                                f"**Role:** {self.role.name}\n"
                                f"**Time:** <t:{int(datetime.now().timestamp())}:R>\n\n"
                                "You can send them a new invitation if you want."
                            ),
                            accent_color=EmberColors.WARNING,
                        )
                    )
                    await owner.send(view=notify_view)
            except Exception:
                pass

        except discord.Forbidden:
            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Permission Error"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay("Bot lacks permissions to remove roles."),
                    accent_color=EmberColors.ERROR,
                )
            )
            await inter.edit_original_response(view=result)

        except Exception as e:
            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Failed to Renounce"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"Error: {str(e)[:100]}"),
                    accent_color=EmberColors.ERROR,
                )
            )
            await inter.edit_original_response(view=result)

    async def _cancel_callback(self, inter: Interaction):
        self.confirmed = False
        self.stop()
        result = discord.ui.LayoutView(timeout=None)
        result.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ✅ Role Kept"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(f"You decided to keep **{self.role.name}**"),
                accent_color=discord.Color.blurple(),
            )
        )
        await inter.response.edit_message(view=result)

    async def on_timeout(self):
        """Handle view timeout"""
        if not self.confirmed:
            try:
                result = discord.ui.LayoutView(timeout=None)
                result.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## ⏰ Decision Timed Out"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            "Renounce confirmation timed out. Your role is safe."
                        ),
                        accent_color=discord.Color.greyple(),
                    )
                )
                await self.message.edit(view=result)
            except Exception:
                pass


class RoleConflictView(discord.ui.LayoutView):
    """LayoutView for resolving role conflicts — display + switch/keep buttons."""

    def __init__(
        self,
        cog,
        new_role: discord.Role,
        new_owner: discord.Member,
        current_role: discord.Role,
        current_owner: discord.Member,
        bot: commands.Bot = None,
    ):
        super().__init__(timeout=604800.0)  # 7 days
        self.cog = cog
        self.new_role = new_role
        self.new_owner = new_owner
        self.current_role = current_role
        self.current_owner = current_owner
        self.decision = None
        self.bot = bot

        self._switch_btn = discord.ui.Button(
            label="🔄 Switch to New Role", style=ButtonStyle.secondary, emoji="🔄"
        )
        self._switch_btn.callback = self._switch_callback

        self._keep_btn = discord.ui.Button(
            label="💎 Keep Current Role", style=ButtonStyle.secondary, emoji="💎"
        )
        self._keep_btn.callback = self._keep_callback
        self.add_item(discord.ui.ActionRow(self._switch_btn, self._keep_btn))

    async def _switch_callback(self, inter: Interaction):
        self.decision = "switch"
        self.stop()

        self._switch_btn.disabled = True
        self._keep_btn.disabled = True

        processing = discord.ui.LayoutView(timeout=None)
        processing.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("🔄 **Switching roles...**"),
                accent_color=discord.Color.blurple(),
            )
        )
        await inter.response.edit_message(view=processing)

        # Remove current role and add new role
        try:
            # Get the guild from the role (safer than inter.guild)
            guild = self.new_role.guild or self.current_role.guild

            if not guild:
                return await inter.followup.send(
                    view=make_error_card("❌ Error", "Could not find guild."), ephemeral=True
                )

            # Get the member
            member = guild.get_member(inter.user.id)
            if not member:
                try:
                    member = await guild.fetch_member(inter.user.id)
                except discord.NotFound:
                    return await inter.followup.send(
                        view=make_error_card("❌ Error", "Could not find member in guild."),
                        ephemeral=True,
                    )

            # Remove current role
            await member.remove_roles(
                self.current_role,
                reason=f"Switched to {self.new_role.name} from {self.new_owner}",
            )

            # Add new role
            await member.add_roles(
                self.new_role,
                reason=f"Switched from {self.current_role.name} by {member}",
            )

            # Update database
            await self.cog.db.remove(
                "bestowals", giver_id=self.current_owner.id, receiver_id=inter.user.id
            )
            await self.cog.db.store(
                "bestowals",
                {
                    "giver_id": self.new_owner.id,
                    "receiver_id": inter.user.id,
                    "role_id": self.new_role.id,
                    "accepted": True,
                },
            )

            try:
                v1 = discord.ui.LayoutView(timeout=None)
                v1.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## ✅ Role Switch Accepted"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            f"{member.mention} has accepted your role and switched from **{self.current_role.name}**!"
                        ),
                        accent_color=EmberColors.SUCCESS,
                    )
                )
                await self.new_owner.send(view=v1)

                v2 = discord.ui.LayoutView(timeout=None)
                v2.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## 🎭 Role Switch Notification"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            f"{member.mention} has switched from your role **{self.current_role.name}** "
                            f"to **{self.new_role.name}** by {self.new_owner.mention}"
                        ),
                        accent_color=EmberColors.WARNING,
                    )
                )
                await self.current_owner.send(view=v2)
            except Exception:
                pass

            await inter.followup.send(
                view=make_success_card("✅ Done", "Successfully switched roles"), ephemeral=True
            )

        except discord.Forbidden:
            await inter.followup.send(
                view=make_error_card("❌ Error", "Bot doesn't have permission to manage roles."),
                ephemeral=True,
            )
        except discord.HTTPException as e:
            await inter.followup.send(f"❌ Discord API error: {e}", ephemeral=True)
        except Exception as e:
            await inter.followup.send(f"❌ Failed to switch roles: {e}", ephemeral=True)

    async def _keep_callback(self, inter: Interaction):
        self.decision = "keep"
        self.stop()

        self._switch_btn.disabled = True
        self._keep_btn.disabled = True

        await inter.response.edit_message(content="💎 **Keeping current role...**", view=self)

        # Update database - remove the new invitation
        await self.cog.db.remove("bestowals", giver_id=self.new_owner.id, receiver_id=inter.user.id)

        try:
            decline_v = discord.ui.LayoutView(timeout=None)
            decline_v.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Invitation Declined"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"{inter.user.mention} has chosen to keep their current role instead of accepting yours."
                    ),
                    accent_color=EmberColors.ERROR,
                )
            )
            await self.new_owner.send(view=decline_v)
        except Exception:
            pass

        await inter.followup.send(
            "✅ You've kept your current role. The new invitation has been declined.",
            ephemeral=True,
        )


class DeleteConfirmationView(discord.ui.LayoutView):
    """LayoutView for confirming role deletion — display + buttons in one component."""

    def __init__(
        self,
        parent_view,
        role: discord.Role,
        is_mod_action: bool = False,
        reason: str | None = None,
        bestowed_count: int = 0,
    ):
        super().__init__(timeout=30.0)
        self.parent_view = parent_view
        self.role = role
        self.is_mod_action = is_mod_action
        self.reason = reason
        self.confirmed = False
        self.countdown = 5
        self.countdown_task = None

        role_details = f"**Name:** `{role.name}`"
        if hasattr(role, "created_at") and role.created_at:
            role_details += f"\n**Created:** <t:{int(role.created_at.timestamp())}:R>"

        stats = (
            f"• **Bestowed to:** {bestowed_count} user{'s' if bestowed_count != 1 else ''}\n"
            f"• **Color Type:** {'Gradient' if (hasattr(parent_view, 'role_data') and parent_view.role_data and parent_view.role_data.get('color_type') == 'gradient') else 'Solid'}"
        )

        body = (
            f"{role_details}\n\n"
            f"{stats}\n\n"
            "```diff\n"
            "- Role will be PERMANENTLY deleted\n"
            "- All bestowed users will LOSE the role\n"
            "- Role history will be ERASED\n"
            "- No recovery possible\n"
            "```\n\n"
            "**Alternatives to consider:**\n"
            "• Rename the role instead\n"
            "• Change colors for a fresh look\n"
            "• Remove specific bestowed users\n"
            "• Start fresh with a new role"
        )

        title = (
            "## ⚠️ Moderator: Confirm Role Deletion"
            if is_mod_action
            else "## ⚠️ Confirm Role Deletion"
        )
        if is_mod_action and reason:
            body = f"**Reason:** {reason}\n\n" + body

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(title),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(body),
                discord.ui.MediaGallery(
                    discord.MediaGalleryItem(
                        media="https://media.giphy.com/media/3o7aD2vscU9WE8uVUQ/giphy.gif"
                    )
                ),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay("-# Think carefully! This action cannot be undone."),
                accent_color=EmberColors.ERROR,
            )
        )

        self.confirm_button = discord.ui.Button(
            label="✅ Confirm Delete", style=ButtonStyle.danger, emoji="💀"
        )
        self.confirm_button.callback = self._confirm_callback

        cancel_btn = discord.ui.Button(label="❌ Cancel", style=ButtonStyle.secondary, emoji="🚫")
        cancel_btn.callback = self._cancel_callback
        self.add_item(discord.ui.ActionRow(self.confirm_button, cancel_btn))

    async def _confirm_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.user.id and not self.is_mod_action:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can confirm deletion."),
                ephemeral=True,
            )
            return

        self.confirmed = True
        self.stop()

        if self.countdown_task:
            self.countdown_task.cancel()

        progress_steps = [
            "💔 Disconnecting role from users...",
            "🔥 Burning role data...",
            "🧹 Cleaning up permissions...",
            "🚮 Sending role to the void...",
            "✅ Role deleted successfully!",
        ]

        def _progress_view(i: int, step: str) -> discord.ui.LayoutView:
            bar = f"{'▰' * (i+1)}{'▱' * (len(progress_steps)-i-1)} {(i+1)*20}%"
            v = discord.ui.LayoutView(timeout=None)
            v.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## 🗑️ Role Deletion in Progress"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"**Step {i+1}/{len(progress_steps)}:** {step}\n\n"
                        f"**Role:** `{self.role.name}`\n\n"
                        f"`{bar}`"
                    ),
                    accent_color=EmberColors.ERROR,
                )
            )
            return v

        await inter.response.edit_message(view=_progress_view(0, progress_steps[0]))

        try:
            role_name = self.role.name
            role_color = self.role.color

            for i, step in enumerate(progress_steps):
                await inter.edit_original_response(view=_progress_view(i, step))
                await asyncio.sleep(0.8)

            delete_reason = f"Deleted by {'moderator' if self.is_mod_action else 'owner'} {inter.user} via /boosterroles"
            if self.reason:
                delete_reason += f" - Reason: {self.reason}"

            await self.role.delete(reason=delete_reason)

            role_owner_id = None
            all_roles = await self.parent_view.cog.db.find("roles")
            for role_data in all_roles:
                if role_data.get("role_id") == self.role.id:
                    role_owner_id = role_data["user_id"]
                    break

            if role_owner_id:
                await self.parent_view.cog.db.remove("roles", user_id=role_owner_id)
                await self.parent_view.cog.db.remove("bestowals", role_id=self.role.id)

            delete_gifs = [
                "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",
                "https://media.giphy.com/media/3o7aD2vscU9WE8uVUQ/giphy.gif",
                "https://media.giphy.com/media/26ufdMZhKcIBAk8FG/giphy.gif",
                "https://media.giphy.com/media/l0MYNwK00Dx4y5D4c/giphy.gif",
                "https://media.giphy.com/media/3o7abAHdYvZdBNnGZq/giphy.gif",
            ]
            gif = delete_gifs[datetime.now().second % len(delete_gifs)]

            details = (
                f"**Name:** `{role_name}`\n"
                f"**Color:** `{role_color}`\n"
                f"**Deleted:** <t:{int(datetime.now().timestamp())}:R>"
            )
            if self.is_mod_action:
                details += f"\n**Moderator:** {inter.user.mention}"
            if self.reason:
                details += f"\n**Reason:** {self.reason}"

            success_view = discord.ui.LayoutView(timeout=None)
            success_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ Role Successfully Deleted"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"The role **{role_name}** has been permanently deleted.\n\n"
                        f"{details}\n\n"
                        "• Role removed from Discord\n"
                        "• Database entry cleared\n"
                        "• All bestowed users lost the role\n"
                        "• Role owner can create a new role anytime"
                    ),
                    discord.ui.MediaGallery(discord.MediaGalleryItem(media=gif)),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        "-# Create a new role by clicking **🎭 Create Role** in the main menu."
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await inter.edit_original_response(view=success_view)

            if self.parent_view and self.parent_view.user.id == inter.user.id:
                self.parent_view.role = None
                self.parent_view.role_data = None
                if hasattr(self.parent_view, "update_button_states"):
                    self.parent_view.update_button_states()

                await asyncio.sleep(5)
                if hasattr(self.parent_view, "cog"):
                    await self.parent_view.cog.send_booster_roles_embed(inter)

        except discord.Forbidden:
            err = discord.ui.LayoutView(timeout=None)
            err.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Permission Error"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay("Bot lacks permissions to delete roles."),
                    accent_color=EmberColors.ERROR,
                )
            )
            await inter.edit_original_response(view=err)

        except Exception as e:
            err = discord.ui.LayoutView(timeout=None)
            err.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Deletion Failed"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"Error: {str(e)}"),
                    accent_color=EmberColors.ERROR,
                )
            )
            await inter.edit_original_response(view=err)

    async def _cancel_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.user.id and not self.is_mod_action:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can cancel."), ephemeral=True
            )
            return

        self.confirmed = False
        self.stop()

        if self.countdown_task:
            self.countdown_task.cancel()

        result = discord.ui.LayoutView(timeout=None)
        result.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ✅ Deletion Cancelled"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay("Your role is safe!"),
                accent_color=EmberColors.SUCCESS,
            )
        )
        await inter.response.edit_message(view=result)

    async def start_countdown(self, message):
        """Start a countdown animation on the confirm button"""
        original_label = self.confirm_button.label
        try:
            for i in range(5, 0, -1):
                self.countdown = i
                self.confirm_button.label = f"✅ Confirm Delete ({i}s)"
                await message.edit(view=self)
                await asyncio.sleep(1)

            self.confirm_button.disabled = True
            self.confirm_button.label = "⏰ Time's up!"
            await message.edit(view=self)

        except asyncio.CancelledError:
            self.confirm_button.label = original_label
            await message.edit(view=self)

    async def on_timeout(self):
        """Handle view timeout"""
        if not self.confirmed:
            if self.countdown_task:
                self.countdown_task.cancel()

            try:
                result = discord.ui.LayoutView(timeout=None)
                result.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## ⏰ Deletion Timed Out"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            "Deletion confirmation timed out. Your role is safe!"
                        ),
                        accent_color=discord.Color.greyple(),
                    )
                )
                await self.message.edit(view=result)
            except Exception:
                pass


class RemoveIconView(discord.ui.LayoutView):
    """LayoutView for confirming role icon removal."""

    def __init__(self, parent_view):
        super().__init__(timeout=30.0)
        self.parent_view = parent_view

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🗑️ Remove Role Icon"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"Are you sure you want to remove the icon from {parent_view.role.mention}?\n\n"
                    + (
                        "**Current Icon:** Custom Emoji"
                        if parent_view.role and parent_view.role.display_icon
                        else ""
                    )
                ),
                accent_color=EmberColors.WARNING,
            )
        )

        confirm_btn = discord.ui.Button(label="✅ Remove Icon", style=ButtonStyle.danger)
        confirm_btn.callback = self._confirm_callback

        cancel_btn = discord.ui.Button(label="❌ Cancel", style=ButtonStyle.secondary)
        cancel_btn.callback = self._cancel_callback
        self.add_item(discord.ui.ActionRow(confirm_btn, cancel_btn))

    async def _confirm_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.user.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can confirm."), ephemeral=True
            )
            return

        await inter.response.defer(ephemeral=True)

        try:
            await self.parent_view.role.edit(display_icon=None)

            role_data = await self.parent_view.cog.db.find_one("roles", user_id=inter.user.id)

            if role_data:
                role_data.pop("icon_type", None)
                role_data.pop("icon_set_at", None)
                role_data["updated_at"] = datetime.now(
                    timezone(timedelta(hours=5, minutes=30))
                ).isoformat()
                await self.parent_view.cog.db.store(
                    "roles", {"user_id": inter.user.id, **role_data}
                )

            await inter.followup.send(
                view=make_success_card("✅ Done", "Icon removed from your role"), ephemeral=True
            )

        except discord.Forbidden:
            await inter.followup.send(
                view=make_error_card("❌ Error", "Bot lacks permissions to edit role icons."),
                ephemeral=True,
            )
        except Exception as e:
            await inter.followup.send(f"❌ Error removing icon: {str(e)}", ephemeral=True)

    async def _cancel_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.user.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can cancel."), ephemeral=True
            )
            return

        result = discord.ui.LayoutView(timeout=None)
        result.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("✅ Icon removal cancelled."),
                accent_color=discord.Color.blurple(),
            )
        )
        await inter.response.edit_message(view=result)


class RoleInvitationView(discord.ui.LayoutView):
    """LayoutView for role invitation DMs — display + accept/decline buttons."""

    def __init__(self, cog, owner: discord.Member, recipient: discord.Member, role: discord.Role):
        super().__init__(timeout=604800.0)  # 7 day timeout
        self.cog = cog
        self.owner = owner
        self.recipient = recipient
        self.role = role
        self.decision_made = False

        icon_line = "\n**Role Icon:** Custom Icon" if role.display_icon else ""
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🎁 Role Invitation"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"{owner.mention} wants to bestow their custom role to you!\n\n"
                    f"**Role Name:** {role.name}\n"
                    f"**Color:** `{str(role.color)}`\n"
                    f"**Bestowed By:** {owner.mention}{icon_line}\n\n"
                    "You'll receive this role and it will appear in your profile.\n"
                    "You can remove it anytime via `/renounce`.\n\n"
                    "**Invitation expires in:** 7 days"
                ),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay("-# Accept or decline below"),
                accent_color=role.color,
            )
        )

        self._accept_btn = discord.ui.Button(
            label="✅ Accept Role", style=ButtonStyle.success, emoji="🎭"
        )
        self._accept_btn.callback = self._accept_callback

        self._decline_btn = discord.ui.Button(
            label="❌ Decline Role", style=ButtonStyle.danger, emoji="🚫"
        )
        self._decline_btn.callback = self._decline_callback
        self.add_item(discord.ui.ActionRow(self._accept_btn, self._decline_btn))

    async def _accept_callback(self, inter: Interaction):
        if inter.user.id != self.recipient.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "This invitation is not for you"), ephemeral=True
            )
            return

        self.decision_made = True
        self.stop()

        self._accept_btn.disabled = True
        self._decline_btn.disabled = True

        # Update message
        await inter.response.edit_message(
            content="🎭 **Processing your acceptance...**", embed=None, view=self
        )

        # Add role to recipient
        try:
            await self.recipient.add_roles(
                self.role, reason=f"Accepted invitation from {self.owner}"
            )

            # Update database
            bestowed = await self.cog.db.find_one(
                "bestowals", giver_id=self.owner.id, receiver_id=self.recipient.id
            )
            if bestowed:
                bestowed["accepted"] = True
                await self.cog.db.store("bestowals", bestowed)

            accept_view = discord.ui.LayoutView(timeout=None)
            accept_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ Role Accepted!"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"You have accepted **{self.role.name}** from {self.owner.mention}\n\n"
                        f"**Role:** {self.role.name}\n"
                        f"**Bestowed By:** {self.owner.mention}\n"
                        f"**Accepted:** <t:{int(datetime.now().timestamp())}:R>\n\n"
                        "**Want to give up this role later?**\n"
                        "Use `/renounce` to remove it from yourself at any time.\n"
                        "• `/renounce` — Shows a menu of roles you can give up\n"
                        "• `/renounce @role` — Directly give up a specific role"
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await inter.followup.send(view=accept_view)

            try:
                owner_view = discord.ui.LayoutView(timeout=None)
                owner_view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## ✅ Role Accepted"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            f"{self.recipient.mention} has accepted your role invitation!\n\n"
                            f"**Role:** {self.role.mention}\n"
                            f"**Accepted By:** {self.recipient.mention}"
                        ),
                        accent_color=EmberColors.SUCCESS,
                    )
                )
                await self.owner.send(view=owner_view)
            except Exception:
                pass

        except discord.Forbidden:
            await inter.followup.send(
                view=make_error_card("❌ Error", "Bot lacks permissions to add roles."),
                ephemeral=True,
            )
        except Exception as e:
            await inter.followup.send(f"❌ Failed to add role: {e}", ephemeral=True)

    async def _decline_callback(self, inter: Interaction):
        if inter.user.id != self.recipient.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "This invitation is not for you"), ephemeral=True
            )
            return

        self.decision_made = True
        self.stop()

        self._accept_btn.disabled = True
        self._decline_btn.disabled = True

        # Update message
        await inter.response.edit_message(content="**Invitation Declined**", embed=None, view=self)

        # Update database
        await self.cog.db.remove("bestowals", giver_id=self.owner.id, receiver_id=self.recipient.id)

        try:
            declined_view = discord.ui.LayoutView(timeout=None)
            declined_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Role Declined"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"{self.recipient.mention} has declined your role invitation."
                    ),
                    accent_color=EmberColors.ERROR,
                )
            )
            await self.owner.send(view=declined_view)
        except Exception:
            pass

    async def on_timeout(self):
        """Handle invitation timeout"""
        if not self.decision_made:
            # Update database to remove expired invitation
            await self.cog.db.remove(
                "bestowals", giver_id=self.owner.id, receiver_id=self.recipient.id
            )


class ManageRoleView(discord.ui.LayoutView):
    """LayoutView for managing role properties — display + action buttons."""

    def __init__(self, parent_view):
        super().__init__(timeout=300.0)
        self.parent_view = parent_view

        role = parent_view.role
        role_line = f"**Role:** {role.mention}" if role else "**Role:** None"
        icon_line = (
            f"\n**Has Icon:** {'✅ Yes' if role and role.display_icon else '❌ No'}" if role else ""
        )

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ⚙️ Role Management"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"{role_line}{icon_line}\n\n"
                    "**✏️ Change Name** — Rename your role\n"
                    "**🎨 Edit Colors** — Change role color\n"
                    "**🖼️ Set Icon** — Add an emoji icon\n"
                    "**🗑️ Remove Icon** — Remove current icon\n"
                    "**⚠️ Delete Role** — Permanently delete role"
                ),
                accent_color=discord.Color.blurple(),
            )
        )

        self.name_button = discord.ui.Button(
            label="✏️ Change Name", style=ButtonStyle.secondary, emoji="📝"
        )
        self.name_button.callback = self._name_callback

        self.colors_button = discord.ui.Button(
            label="🎨 Edit Colors", style=ButtonStyle.secondary, emoji="🌈"
        )
        self.colors_button.callback = self._colors_callback

        self.icon_button = discord.ui.Button(
            label="🖼️ Set Icon", style=ButtonStyle.secondary, emoji="🎨"
        )
        self.icon_button.callback = self._icon_callback
        self.add_item(discord.ui.ActionRow(self.name_button, self.colors_button, self.icon_button))

        self.remove_icon_button = discord.ui.Button(
            label="🗑️ Remove Icon", style=ButtonStyle.secondary, emoji="❌"
        )
        self.remove_icon_button.callback = self._remove_icon_callback

        self.delete_button = discord.ui.Button(
            label="🗑️ Delete Role", style=ButtonStyle.danger, emoji="⚠️"
        )
        self.delete_button.callback = self._delete_callback

        back_btn = discord.ui.Button(label="Back to Main", style=ButtonStyle.secondary, emoji="⬅️")
        back_btn.callback = self._back_callback
        self.add_item(discord.ui.ActionRow(self.remove_icon_button, self.delete_button, back_btn))

        self.update_button_states()

    def update_button_states(self):
        has_role = self.parent_view.role is not None
        self.name_button.disabled = not has_role
        self.colors_button.disabled = not has_role
        self.icon_button.disabled = not has_role
        self.remove_icon_button.disabled = not has_role or not (
            self.parent_view.role and self.parent_view.role.display_icon
        )
        self.delete_button.disabled = not has_role

    async def _name_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to rename"), ephemeral=True
            )
            return
        modal = RoleNameModal(self.parent_view.cog, self.parent_view.role)
        await interaction.response.send_modal(modal)

    async def _colors_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        if not self.parent_view.role or not self.parent_view.role_data:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to edit"), ephemeral=True
            )
            return
        modal = RoleColorsModal(
            self.parent_view.cog, self.parent_view.role, self.parent_view.role_data
        )
        await interaction.response.send_modal(modal)

    async def _icon_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to set an icon for"),
                ephemeral=True,
            )
            return

        # Ask user to send an emoji
        await interaction.response.send_message(
            "🎨 **Please send an emoji in chat to use as the role icon!**\n"
            "You can send any emoji (Unicode or custom Discord emoji).",
            ephemeral=True,
        )

        # Wait for user's emoji response
        def check(m):
            return m.author.id == interaction.user.id and m.channel.id == interaction.channel_id

        try:
            emoji_msg = await interaction.client.wait_for("message", timeout=60.0, check=check)

            # Extract emoji from the message
            emoji_content = emoji_msg.content.strip()

            if not emoji_content:
                await interaction.followup.send(
                    view=make_error_card("❌ Error", "No emoji found in your message"),
                    ephemeral=True,
                )
                return

            # Process and set the emoji as role icon
            await self.process_emoji_for_role(interaction, emoji_content, emoji_msg)

        except TimeoutError:
            await interaction.followup.send(
                view=make_warning_card("⚠️ Heads Up", "Timeout! You didn't send an emoji in time."),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

    async def process_emoji_for_role(self, interaction: Interaction, emoji_content: str, emoji_msg):
        """Process any type of emoji and set it as role icon"""

        try:
            # Delete the user's emoji message
            await emoji_msg.delete()

            # If it's a custom Discord emoji (<:name:id> or <a:name:id>)
            if emoji_content.startswith("<") and emoji_content.endswith(">"):
                # Extract emoji ID from the format
                emoji_id = emoji_content.split(":")[-1][:-1]

                # Download the emoji
                emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.png"
                async with aiohttp.ClientSession() as session:
                    async with session.get(emoji_url) as resp:
                        if resp.status == 200:
                            emoji_data = await resp.read()
                        else:
                            # Try with gif extension for animated emojis
                            emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.gif"
                            async with session.get(emoji_url) as gif_resp:
                                if gif_resp.status == 200:
                                    emoji_data = await gif_resp.read()
                                else:
                                    raise ValueError("Could not download emoji from Discord")

            else:
                # It's a Unicode emoji
                await interaction.followup.send(
                    "⚠️ Unicode emoji support requires additional setup. "
                    "Please use a custom Discord emoji for now!",
                    ephemeral=True,
                )
                return

            # Set the role icon
            await self.parent_view.role.edit(display_icon=emoji_data)

            await interaction.followup.send(
                f"✅ Successfully set role icon to {emoji_content}!", ephemeral=True
            )

        except Exception as e:
            await interaction.followup.send(
                f"❌ Failed to set role icon: {str(e)}\n"
                f"Make sure you're using a valid custom Discord emoji!",
                ephemeral=True,
            )

    async def _remove_icon_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role"), ephemeral=True
            )
            return

        if not self.parent_view.role.display_icon:
            await interaction.response.send_message(
                view=make_info_card("ℹ️ Info", "Your role doesn't have an icon to remove."),
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            view=RemoveIconView(self.parent_view), ephemeral=True
        )

    async def _delete_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to delete"), ephemeral=True
            )
            return

        bestowed_entries = await self.parent_view.cog.db.find(
            "bestowals", giver_id=self.parent_view.user.id
        )
        bestowed_count = len(bestowed_entries) if bestowed_entries else 0

        confirm_view = DeleteConfirmationView(
            self.parent_view,
            self.parent_view.role,
            bestowed_count=bestowed_count,
        )
        await interaction.response.send_message(view=confirm_view, ephemeral=True)
        confirm_view.message = await interaction.original_response()
        confirm_view.countdown_task = asyncio.create_task(
            confirm_view.start_countdown(confirm_view.message)
        )

    async def _back_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        await self.parent_view.cog.send_booster_roles_embed(interaction)


class ShareRoleView(discord.ui.LayoutView):
    """LayoutView for sharing a booster role — display + action buttons."""

    def __init__(self, parent_view):
        super().__init__(timeout=300.0)
        self.parent_view = parent_view  # This is BoosterRoleView

        role = parent_view.role
        role_line = f"**Role:** {role.mention}" if role else "**Role:** None"

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🤝 Share Your Role"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"{role_line}\n\n"
                    "**🎁 Bestow Role** — Send role invitations to users\n"
                    "**👥 Manage Bestowed** — View and manage users with your role\n"
                    "**🔙 Back** — Return to main menu"
                ),
                accent_color=EmberColors.SUCCESS,
            )
        )

        self.bestow_button = discord.ui.Button(
            label="🎁 Bestow Role", style=ButtonStyle.success, emoji="🤝"
        )
        self.bestow_button.callback = self._bestow_callback

        self.manage_bestowed_button = discord.ui.Button(
            label="👥 Manage Bestowed", style=ButtonStyle.secondary, emoji="⚙️"
        )
        self.manage_bestowed_button.callback = self._manage_bestowed_callback

        back_btn = discord.ui.Button(
            label="🔙 Back to Main", style=ButtonStyle.secondary, emoji="⬅️"
        )
        back_btn.callback = self._back_callback
        self.add_item(
            discord.ui.ActionRow(self.bestow_button, self.manage_bestowed_button, back_btn)
        )

        self.update_button_states()

    def update_button_states(self):
        has_role = self.parent_view.role is not None
        self.bestow_button.disabled = not has_role
        self.manage_bestowed_button.disabled = not has_role

    async def check_capacity(self, interaction: Interaction) -> tuple[bool, int, int]:
        """Check if user can send more invitations"""
        bestowed_entries = await self.parent_view.cog.db.find(
            "bestowals", giver_id=self.parent_view.user.id
        )
        total = len(bestowed_entries) if bestowed_entries else 0
        accepted = (
            sum(1 for data in bestowed_entries if data.get("accepted", False))
            if bestowed_entries
            else 0
        )
        total - accepted
        # Max 10 total invitations
        can_send = total < 10
        remaining = 10 - total

        return can_send, remaining, total

    async def _bestow_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return

        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to bestow"), ephemeral=True
            )
            return

        # Check capacity
        can_send, remaining, current_total = await self.check_capacity(interaction)

        if not can_send:
            await interaction.response.send_message(
                "❌ **Capacity Reached!**\n"
                "You have already bestowed your role to 10 users.\n"
                "To send more invitations, you must remove some existing bestowed users.",
                ephemeral=True,
            )
            return

        # Create user selector with capacity info
        class UserSelectView(ui.View):
            def __init__(self, share_view, remaining):
                super().__init__(timeout=120.0)
                self.share_view = share_view
                self.remaining = remaining

                # Create the user select dropdown - limited to remaining capacity
                max_users = min(10, remaining)  # Don't allow more than capacity
                self.user_select = ui.UserSelect(
                    placeholder=f"Select users ({remaining} slots remaining)...",
                    min_values=1,
                    max_values=max_users,
                    custom_id="user_select",
                )
                self.add_item(self.user_select)

            async def on_timeout(self):
                for child in self.children:
                    child.disabled = True
                try:
                    await self.message.edit(view=self)
                except Exception:
                    pass

        select_view = UserSelectView(self, remaining)
        await interaction.response.send_message(
            f"**👥 Select Users**\n"
            f"You have **{remaining} invitation slot(s)** remaining.\n"
            f"Choose up to **{remaining} user(s)** to offer your role to:",
            view=select_view,
            ephemeral=True,
        )
        select_view.message = await interaction.original_response()

        try:
            await self.wait_for_user_selection(interaction, select_view)
        except TimeoutError:
            await interaction.followup.send(
                view=make_warning_card("⚠️ Heads Up", "Selection timed out."), ephemeral=True
            )

    async def wait_for_user_selection(self, interaction: Interaction, select_view: ui.View):
        """Wait for user selection and process invitations"""
        try:
            # Access bot through parent_view.cog.bot
            select_interaction = await self.parent_view.cog.bot.wait_for(
                "interaction",
                timeout=120.0,
                check=lambda i: (
                    i.data.get("custom_id") == "user_select" and i.user.id == interaction.user.id
                ),
            )

            # Get selected users
            selected_user_ids = select_interaction.data.get("values", [])
            selected_users = []

            for user_id in selected_user_ids:
                user = interaction.guild.get_member(int(user_id))
                if user and user.id != self.parent_view.user.id:  # Can't bestow to self
                    selected_users.append(user)

            if not selected_users:
                await select_interaction.response.edit_message(
                    content="❌ No valid users selected.", embed=None, view=None
                )
                return

            # Show selected users and confirmation
            warnings = []
            can_invite_users = []

            for user in selected_users:
                is_banned = await self.parent_view.cog.db.count("blacklist", user_id=user.id) > 0
                if is_banned:
                    warnings.append(f"🚫 {user.mention} - Blacklisted (skipped)")
                    continue
                if self.parent_view.role in user.roles:
                    warnings.append(f"⚠️ {user.mention} - Already has role (skipped)")
                    continue
                existing_invitation = await self.parent_view.cog.db.find_one(
                    "bestowals", giver_id=self.parent_view.user.id, receiver_id=user.id
                )
                if existing_invitation:
                    warnings.append(f"📨 {user.mention} - Already invited (skipped)")
                    continue
                user_bestowed = await self.parent_view.cog.db.find("bestowals", receiver_id=user.id)
                accepted_roles = [b for b in user_bestowed if b.get("accepted")]
                if accepted_roles:
                    warnings.append(
                        f"⚡ {user.mention} - Has existing role (conflict DM will be sent)"
                    )
                    can_invite_users.append(user)
                else:
                    can_invite_users.append(user)

            user_list = "\n".join([user.mention for user in selected_users])
            body_lines = [
                f"**{len(selected_users)} user(s) selected:**\n{user_list}",
            ]
            if warnings:
                body_lines.append("**⚠️ Notes**\n" + "\n".join(warnings))

            if not can_invite_users:
                body_lines.append(
                    "**❌ No valid users**\nAll selected users have issues. No invitations sent."
                )
                err_view = discord.ui.LayoutView(timeout=None)
                err_view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## 👥 Selected Users"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay("\n\n".join(body_lines)),
                        accent_color=EmberColors.ERROR,
                    )
                )
                await select_interaction.response.edit_message(view=err_view, embed=None)
                return

            body_lines.append(
                f"**Next Step**\nClick 'Send Invitations' to send requests to {len(can_invite_users)} user(s)."
            )
            display_text = "\n\n".join(body_lines)

            # Add send button
            class SendInvitationsView(discord.ui.LayoutView):
                def __init__(self, share_view, selected_users, valid_users, display):
                    super().__init__(timeout=120.0)
                    self.share_view = share_view
                    self.selected_users = selected_users
                    self.valid_users = valid_users
                    self.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("## 👥 Selected Users"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(display),
                            accent_color=discord.Color.blurple(),
                        )
                    )
                    send_btn = discord.ui.Button(
                        label="📨 Send Invitations", style=ButtonStyle.success
                    )
                    send_btn.callback = self._send_callback
                    cancel_btn = discord.ui.Button(label="❌ Cancel", style=ButtonStyle.secondary)
                    cancel_btn.callback = self._cancel_callback
                    self.add_item(discord.ui.ActionRow(send_btn, cancel_btn))

                async def _send_callback(self, inter: Interaction):
                    if inter.user.id != interaction.user.id:
                        await inter.response.send_message(
                            "❌ Only the role owner can send invitations.",
                            ephemeral=True,
                        )
                        return

                    await inter.response.defer(ephemeral=True)

                    # Track invitation results
                    results = {
                        "success": [],  # Normal invitations sent
                        "conflict": [],  # Conflict invitations sent
                        "failed": [],  # DMs disabled
                        "already_has": [],  # Already has role
                        "blacklisted": [],  # Blacklisted users
                    }

                    for user in self.selected_users:
                        # Check if user is blacklisted
                        is_banned = (
                            await self.share_view.parent_view.cog.db.count(
                                "blacklist", user_id=user.id
                            )
                            > 0
                        )
                        if is_banned:
                            results["blacklisted"].append(user.mention)
                            continue

                        # Check if user already has this role
                        if self.share_view.parent_view.role in user.roles:
                            results["already_has"].append(user.mention)
                            continue

                        # Check if user already has a pending invitation
                        existing_invitation = await self.share_view.parent_view.cog.db.find_one(
                            "bestowals",
                            giver_id=self.share_view.parent_view.user.id,
                            receiver_id=user.id,
                        )
                        if existing_invitation:
                            continue  # Skip, already invited

                        # Check if user has existing bestowed roles
                        user_bestowed = await self.share_view.parent_view.cog.db.find(
                            "bestowals", receiver_id=user.id
                        )
                        accepted_roles = [b for b in user_bestowed if b.get("accepted")]

                        if user in self.valid_users:
                            # Check which type of invitation to send
                            if accepted_roles:
                                # Send conflict invitation
                                success = (
                                    await self.share_view.parent_view.send_conflict_invitation(
                                        inter, user, accepted_roles
                                    )
                                )
                                if success:
                                    results["conflict"].append(user.mention)
                                else:
                                    results["failed"].append(user.mention)
                            else:
                                # Send normal invitation
                                success = await self.share_view.parent_view.send_normal_invitation(
                                    inter, user
                                )
                                if success:
                                    results["success"].append(user.mention)
                                else:
                                    results["failed"].append(user.mention)

                    total_invited = len(results["success"]) + len(results["conflict"])
                    lines = []
                    if total_invited > 0:
                        lines.append(f"**Successfully sent {total_invited} invitation(s)**")
                        if results["success"]:
                            lines.append(
                                "**✅ Normal Invitations**\n" + "\n".join(results["success"])
                            )
                        if results["conflict"]:
                            lines.append(
                                "**⚡ Conflict Invitations**\n"
                                + "\n".join(results["conflict"])
                                + "\n*These users already have roles. They'll get a comparison DM.*"
                            )
                    if results["failed"]:
                        lines.append(
                            "**❌ Failed (DMs disabled)**\n" + "\n".join(results["failed"])
                        )
                    if results["already_has"]:
                        lines.append(
                            "**⚠️ Already Have Role**\n" + "\n".join(results["already_has"])
                        )
                    if results["blacklisted"]:
                        lines.append("**🚫 Blacklisted**\n" + "\n".join(results["blacklisted"]))

                    accent = EmberColors.SUCCESS if total_invited > 0 else EmberColors.WARNING
                    result_view = discord.ui.LayoutView(timeout=None)
                    result_view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("## 📨 Invitation Results"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(
                                "\n\n".join(lines) if lines else "No invitations processed."
                            ),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(
                                f"-# Invitations sent by {self.share_view.parent_view.user.display_name}"
                            ),
                            accent_color=accent,
                        )
                    )
                    await inter.followup.send(view=result_view, ephemeral=True)

                    done_view = discord.ui.LayoutView(timeout=None)
                    done_view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("✅ Invitations sent successfully!"),
                            accent_color=EmberColors.SUCCESS,
                        )
                    )
                    await select_interaction.edit_original_response(view=done_view)

                async def _cancel_callback(self, inter: Interaction):
                    if inter.user.id != interaction.user.id:
                        await inter.response.send_message(
                            view=make_error_card("❌ Error", "Only the role owner can cancel."),
                            ephemeral=True,
                        )
                        return
                    cancelled_view = discord.ui.LayoutView(timeout=None)
                    cancelled_view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("❌ Invitation sending cancelled."),
                            accent_color=discord.Color.greyple(),
                        )
                    )
                    await inter.response.edit_message(view=cancelled_view)

            send_view = SendInvitationsView(self, selected_users, can_invite_users, display_text)
            await select_interaction.response.edit_message(view=send_view, embed=None)

        except TimeoutError:
            await interaction.followup.send(
                view=make_warning_card("⚠️ Heads Up", "Selection timed out."), ephemeral=True
            )

    async def _manage_bestowed_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return

        if not self.parent_view.role:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "You don't have a role to manage"), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        await self.parent_view.show_bestowed_management(interaction)

    async def _back_callback(self, interaction: Interaction):
        if interaction.user.id != self.parent_view.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        await self.parent_view.cog.send_booster_roles_embed(interaction)


class BoosterRoleView(discord.ui.LayoutView):
    """LayoutView for the main booster role management panel."""

    def __init__(
        self,
        cog,
        user: discord.Member,
        role: discord.Role | None,
        role_data: dict[str, Any] | None,
        display_text: str = "",
        accent_color: discord.Color | None = None,
    ):
        super().__init__(timeout=300.0)
        self.cog = cog
        self.user = user
        self.role = role
        self.role_data = role_data
        self.selected_users: set[discord.Member] = set()

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🎭 Booster Role Manager"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(display_text or "Loading..."),
                accent_color=accent_color or EmberColors.WARNING,
            )
        )

        has_role = role is not None
        self.create_button = discord.ui.Button(
            label="🎭 Create Role", style=ButtonStyle.success, emoji="✨", disabled=has_role
        )
        self.create_button.callback = self._create_callback

        self.manage_role_button = discord.ui.Button(
            label="⚙️ Manage Role", style=ButtonStyle.secondary, emoji="🔧", disabled=not has_role
        )
        self.manage_role_button.callback = self._manage_callback

        self.share_role_button = discord.ui.Button(
            label="🤝 Share Role", style=ButtonStyle.secondary, emoji="🎁", disabled=not has_role
        )
        self.share_role_button.callback = self._share_callback

        self.refresh_button = discord.ui.Button(
            label="🔄 Refresh", style=ButtonStyle.secondary, emoji="🔄"
        )
        self.refresh_button.callback = self._refresh_callback
        self.add_item(
            discord.ui.ActionRow(
                self.create_button,
                self.manage_role_button,
                self.share_role_button,
                self.refresh_button,
            )
        )

    def update_button_states(self):
        has_role = self.role is not None
        self.create_button.disabled = has_role
        self.manage_role_button.disabled = not has_role
        self.share_role_button.disabled = not has_role
        self.refresh_button.disabled = False

    async def _create_callback(self, interaction: Interaction):
        if interaction.user.id != self.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        modal = CreateRoleModal(self.cog)
        await interaction.response.send_modal(modal)

    async def _manage_callback(self, interaction: Interaction):
        if interaction.user.id != self.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        await interaction.response.send_message(view=ManageRoleView(self), ephemeral=True)

    async def _share_callback(self, interaction: Interaction):
        if interaction.user.id != self.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        await interaction.response.send_message(view=ShareRoleView(self), ephemeral=True)

    async def _refresh_callback(self, interaction: Interaction):
        if interaction.user.id != self.user.id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "This menu is not for you"), ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        await self.cog.send_booster_roles_embed(interaction)

    async def send_normal_invitation(
        self, interaction: Interaction, recipient: discord.Member
    ) -> bool:
        """Send normal invitation DM (when user has no existing role)"""
        await self.cog.db.store(
            "bestowals",
            {
                "giver_id": self.user.id,
                "receiver_id": recipient.id,
                "role_id": self.role.id,
                "accepted": False,
            },
        )

        view = RoleInvitationView(self.cog, self.user, recipient, self.role)

        try:
            await recipient.send(view=view)
            # DM successful - mark as sent
            return True

        except discord.Forbidden:
            # User has DMs disabled - remove from database
            await self.cog.db.remove("bestowals", giver_id=self.user.id, receiver_id=recipient.id)
            return False

    async def send_conflict_invitation(
        self, interaction: Interaction, recipient: discord.Member, current_roles: list
    ) -> bool:
        """Send conflict invitation DM (when user already has a role)"""
        try:
            # Get current role info
            current_role_data = current_roles[0]  # User can only have one
            current_role = interaction.guild.get_role(current_role_data.get("role_id"))
            current_owner = interaction.guild.get_member(current_role_data.get("owner_id"))

            if not current_role:
                # Fallback to normal invitation
                return await self.send_normal_invitation(interaction, recipient)

            # Save to database first
            await self.cog.db.store(
                "bestowals",
                {
                    "giver_id": self.user.id,
                    "receiver_id": recipient.id,
                    "role_id": self.role.id,
                    "accepted": False,
                },
            )

            current_owner_name = current_owner.display_name if current_owner else "Unknown"
            current_owner_mention = current_owner.mention if current_owner else "Unknown"
            conflict_view = RoleConflictView(
                self.cog, self.role, self.user, current_role, current_owner
            )
            # Build the display and add it to the LayoutView before sending
            conflict_view._items.insert(
                0,
                discord.ui.Container(
                    discord.ui.TextDisplay("## ⚠️ Role Conflict Detected"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"You already have a bestowed role from {current_owner_mention}!\n\n"
                        "```diff\n"
                        f"+ NEW: {self.role.name} (from {self.user.display_name})\n"
                        f"- CURRENT: {current_role.name} (from {current_owner_name})\n"
                        "```\n\n"
                        f"**Colors:**\n**New:** `{self.role.color}` | **Current:** `{current_role.color}`\n\n"
                        "**If you switch:**\n"
                        "• Your current role will be **automatically removed**\n"
                        "• The previous owner will be notified\n"
                        "• You'll only have the new role"
                    ),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        "-# Choose carefully! You can only have one bestowed role at a time."
                    ),
                    accent_color=EmberColors.WARNING,
                ),
            )

            await recipient.send(view=conflict_view)
            return True

        except discord.Forbidden:
            # User has DMs disabled
            return False

    async def show_bestowed_management(self, interaction: Interaction):
        """Show bestowed users management interface"""
        bestowed_entries = await self.cog.db.find("bestowals", giver_id=self.user.id)

        # Filter to only show successful invitations (those in database)
        # Users with DMs disabled won't be in the database after failed send attempts

        # Build display text
        display_lines = [
            f"**Role:** {self.role.mention}\n**Owner:** {self.user.mention}\n"
            "*Only users who could receive DMs are shown.*"
        ]

        if bestowed_entries:
            total = len(bestowed_entries)
            accepted = sum(1 for data in bestowed_entries if data.get("accepted", False))
            pending = total - accepted
            display_lines.append(
                f"**📊 Statistics**\n"
                f"**Total:** {total} | **Accepted:** {accepted} | **Pending:** {pending} | "
                f"**Capacity:** {10 - total} remaining"
            )

            recent_users = []
            for entry in bestowed_entries[:5]:
                user = interaction.guild.get_member(entry["user_id"])
                if user:
                    status = "✅ Accepted" if entry.get("accepted", False) else "📨 Pending"
                    invited_at = datetime.fromisoformat(
                        entry.get("invited_at", datetime.now().isoformat())
                    )
                    recent_users.append(
                        f"• {user.mention} - {status} (<t:{int(invited_at.timestamp())}:R>)"
                    )

            if recent_users:
                footer = f"\n*...and {total - 5} more*" if total > 5 else ""
                display_lines.append(
                    "**👥 Recent Invitations**\n" + "\n".join(recent_users) + footer
                )

            if total >= 8:
                display_lines.append(
                    f"⚠️ **Capacity Warning:** You have bestowed to {total}/10 users."
                )
        else:
            display_lines.append(
                "**📭 No Active Invitations**\n"
                "You haven't successfully sent any invitations yet."
            )

        display_text = "\n\n".join(display_lines)

        # Management buttons as LayoutView
        class ManagementView(discord.ui.LayoutView):
            def __init__(self, parent_view, display):
                super().__init__(timeout=300.0)
                self.parent_view = parent_view
                self.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## 👥 Bestowed Users Management"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(display),
                        accent_color=(
                            parent_view.role.color if parent_view.role else discord.Color.blurple()
                        ),
                    )
                )
                view_all_btn = discord.ui.Button(
                    label="📋 View All", style=ButtonStyle.secondary, emoji="👥"
                )
                view_all_btn.callback = self._view_all
                remove_btn = discord.ui.Button(
                    label="🗑️ Remove User", style=ButtonStyle.danger, emoji="➖"
                )
                remove_btn.callback = self._remove_user
                refresh_btn = discord.ui.Button(
                    label="🔄 Refresh", style=ButtonStyle.secondary, emoji="🔄"
                )
                refresh_btn.callback = self._refresh
                self.add_item(discord.ui.ActionRow(view_all_btn, remove_btn, refresh_btn))

            async def _view_all(self, inter: Interaction):
                if inter.user.id != self.parent_view.user.id:
                    await inter.response.send_message(
                        "❌ Only the role owner can manage bestowed users.",
                        ephemeral=True,
                    )
                    return

                await inter.response.defer(ephemeral=True)
                await self.parent_view.show_all_bestowed(inter)

            async def _remove_user(self, inter: Interaction):
                if inter.user.id != self.parent_view.user.id:
                    await inter.response.send_message(
                        "❌ Only the role owner can manage bestowed users.",
                        ephemeral=True,
                    )
                    return

                # Get current bestowed users
                bestowed_entries = await self.parent_view.cog.db.find(
                    "bestowals", giver_id=self.parent_view.user.id
                )

                if not bestowed_entries:
                    await inter.response.send_message(
                        "❌ You haven't bestowed your role to anyone yet.",
                        ephemeral=True,
                    )
                    return

                # Create user selection
                options = []
                for entry in bestowed_entries:
                    user = inter.guild.get_member(entry["receiver_id"])
                    if user:
                        status = "✅ Accepted" if entry.get("accepted", False) else "📨 Pending"
                        options.append(
                            SelectOption(
                                label=f"{user.display_name}",
                                description=f"{status} | ID: {entry['user_id']}",
                                value=str(entry["user_id"]),
                                emoji="👤",
                            )
                        )

                if not options:
                    await inter.response.send_message(
                        view=make_error_card("❌ Error", "No valid users to remove."),
                        ephemeral=True,
                    )
                    return

                class RemoveSelectView(ui.View):
                    def __init__(self, parent_view, options):
                        super().__init__(timeout=120.0)
                        self.parent_view = parent_view
                        self.select = ui.Select(
                            placeholder="Select user to remove...",
                            options=options[:25],
                            custom_id="remove_select",
                        )
                        self.add_item(self.select)

                    async def on_timeout(self):
                        for child in self.children:
                            child.disabled = True
                        try:
                            await self.message.edit(view=self)
                        except Exception:
                            pass

                select_view = RemoveSelectView(self, options)
                await inter.response.send_message(
                    "**🗑️ Remove User**\nSelect a user to remove from your bestowed list:",
                    view=select_view,
                    ephemeral=True,
                )
                select_view.message = await inter.original_response()

                # Wait for selection
                try:
                    # Wait for the select interaction
                    select_interaction = await self.parent_view.cog.bot.wait_for(
                        "interaction",
                        timeout=120.0,
                        check=lambda i: (
                            i.data.get("custom_id") == "remove_select"
                            and i.user.id == inter.user.id
                        ),
                    )

                    user_id = int(select_interaction.data.get("values", [])[0])
                    user = inter.guild.get_member(user_id)

                    if not user:
                        await select_interaction.response.edit_message(
                            content="❌ User not found in this server.",
                            embed=None,
                            view=None,
                        )
                        return

                    # Create confirmation view
                    confirm_view = RemoveConfirmationView(
                        user_to_remove=user,
                        parent_view=self,
                        role=self.parent_view.role,
                    )

                    await select_interaction.response.edit_message(view=confirm_view, embed=None)

                except TimeoutError:
                    await inter.followup.send(
                        view=make_warning_card("⚠️ Heads Up", "Selection timed out."),
                        ephemeral=True,
                    )

            async def _refresh(self, inter: Interaction):
                if inter.user.id != self.parent_view.user.id:
                    await inter.response.send_message(
                        view=make_error_card("❌ Error", "Only the role owner can refresh."),
                        ephemeral=True,
                    )
                    return

                await inter.response.defer(ephemeral=True)
                await self.parent_view.show_bestowed_management(inter)

        view = ManagementView(self, display_text)
        await interaction.followup.send(view=view, ephemeral=True)

    async def show_all_bestowed(self, interaction: Interaction):
        """Show detailed list of all bestowed users"""
        bestowed_entries = await self.cog.db.find("bestowals", giver_id=self.user.id)

        if not bestowed_entries:
            no_users_view = discord.ui.LayoutView(timeout=None)
            no_users_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## 📭 No Bestowed Users"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"{self.user.mention} hasn't bestowed their role to anyone yet."
                    ),
                    accent_color=discord.Color.blurple(),
                )
            )
            await interaction.followup.send(view=no_users_view, ephemeral=True)
            return

        # Create paginated embeds
        users_list = []
        for entry in bestowed_entries:
            user = interaction.guild.get_member(entry["receiver_id"])
            if user:
                status = "✅ Accepted" if entry.get("accepted", False) else "📨 Pending"
                invited_at = datetime.fromisoformat(
                    entry.get("invited_at", datetime.now().isoformat())
                )

                if entry.get("accepted_at"):
                    accepted_at = datetime.fromisoformat(entry["accepted_at"])
                    accepted_str = f"Accepted: <t:{int(accepted_at.timestamp())}:R>"
                else:
                    accepted_str = None

                users_list.append(
                    {
                        "user": user,
                        "status": status,
                        "invited_at": invited_at,
                        "accepted_at": entry.get("accepted_at"),
                        "accepted_str": accepted_str,
                    }
                )

        # Sort by invited date (newest first)
        users_list.sort(key=lambda x: x["invited_at"], reverse=True)

        total_pages = (len(users_list) + 9) // 10

        def _make_page(page_idx: int) -> str:
            page_users = users_list[page_idx * 10 : (page_idx + 1) * 10]
            lines = [
                f"**Role:** {self.role.mention} | **Total Users:** {len(bestowed_entries)}\n"
                f"*Page {page_idx + 1}/{total_pages}*"
            ]
            for ud in page_users:
                user = ud["user"]
                status = ud["status"]
                invited_at = ud["invited_at"]
                line = f"**{user.display_name}** — {status} | Invited <t:{int(invited_at.timestamp())}:R>"
                if ud["accepted_at"]:
                    at = datetime.fromisoformat(ud["accepted_at"])
                    line += f" | Accepted <t:{int(at.timestamp())}:R>"
                lines.append(f"• {line}")
            return "\n".join(lines)

        class PaginationView(discord.ui.LayoutView):
            def __init__(self, page_data, current_page, total, role_color):
                super().__init__(timeout=300.0)
                self.page_data = page_data
                self.current_page = current_page
                self.total = total
                self.role_color = role_color
                self.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## 👥 Bestowed Users"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(page_data[current_page]),
                        accent_color=role_color,
                    )
                )
                prev_btn = discord.ui.Button(
                    label="◀️ Previous", style=ButtonStyle.secondary, disabled=current_page == 0
                )
                prev_btn.callback = self._prev
                next_btn = discord.ui.Button(
                    label="Next ▶️", style=ButtonStyle.secondary, disabled=current_page >= total - 1
                )
                next_btn.callback = self._next
                close_btn = discord.ui.Button(label="❌ Close", style=ButtonStyle.danger)
                close_btn.callback = self._close
                self.add_item(discord.ui.ActionRow(prev_btn, next_btn, close_btn))

            async def _prev(self, inter: Interaction):
                if inter.user.id != interaction.user.id:
                    await inter.response.send_message(
                        view=make_error_card("❌ Error", "Only the command user can navigate."),
                        ephemeral=True,
                    )
                    return
                new_view = PaginationView(
                    self.page_data, max(0, self.current_page - 1), self.total, self.role_color
                )
                await inter.response.edit_message(view=new_view)

            async def _next(self, inter: Interaction):
                if inter.user.id != interaction.user.id:
                    await inter.response.send_message(
                        view=make_error_card("❌ Error", "Only the command user can navigate."),
                        ephemeral=True,
                    )
                    return
                new_view = PaginationView(
                    self.page_data,
                    min(self.total - 1, self.current_page + 1),
                    self.total,
                    self.role_color,
                )
                await inter.response.edit_message(view=new_view)

            async def _close(self, inter: Interaction):
                if inter.user.id != interaction.user.id:
                    await inter.response.send_message(
                        view=make_error_card("❌ Error", "Only the command user can close."),
                        ephemeral=True,
                    )
                    return
                await inter.message.delete()

        page_texts = [_make_page(i) for i in range(total_pages)]
        role_color = self.role.color if self.role else discord.Color.blurple()

        if total_pages == 1:
            single_view = discord.ui.LayoutView(timeout=None)
            single_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## 👥 Bestowed Users"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(page_texts[0]),
                    accent_color=role_color,
                )
            )
            await interaction.followup.send(view=single_view, ephemeral=True)
        else:
            view = PaginationView(page_texts, 0, total_pages, role_color)
            await interaction.followup.send(view=view, ephemeral=True)


class RemoveConfirmationView(discord.ui.LayoutView):
    """LayoutView for confirming user removal from bestowed list."""

    def __init__(self, user_to_remove: discord.Member, parent_view, role: discord.Role):
        super().__init__(timeout=60.0)
        self.user_to_remove = user_to_remove
        self.parent_view = parent_view
        self.role = role
        self.confirmed = False

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ⚠️ Confirm Removal"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"Are you sure you want to remove {user_to_remove.mention} from your bestowed list?\n\n"
                    f"**User:** {user_to_remove.mention}\n"
                    f"**Role:** {role.mention}\n\n"
                    "**Effects:**\n"
                    "• Role will be removed from user\n"
                    "• User will be notified\n"
                    "• User will be removed from your bestowed list"
                ),
                accent_color=EmberColors.WARNING,
            )
        )

        confirm_btn = discord.ui.Button(label="✅ Confirm Remove", style=ButtonStyle.danger)
        confirm_btn.callback = self._confirm_callback

        cancel_btn = discord.ui.Button(label="❌ Cancel", style=ButtonStyle.secondary)
        cancel_btn.callback = self._cancel_callback
        self.add_item(discord.ui.ActionRow(confirm_btn, cancel_btn))

    async def _confirm_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.parent_view.user.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can confirm."), ephemeral=True
            )
            return

        self.confirmed = True
        self.stop()

        # Remove the role
        try:
            await self.user_to_remove.remove_roles(
                self.role,
                reason=f"Removed by role owner {self.parent_view.parent_view.user}",
            )

            # Update database
            await self.parent_view.parent_view.cog.db.remove(
                "bestowals",
                giver_id=self.parent_view.parent_view.user.id,
                receiver_id=self.user_to_remove.id,
            )

            # Notify the removed user
            try:
                removed_view = discord.ui.LayoutView(timeout=None)
                removed_view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## 🎭 Role Removed"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            f"Your bestowed role **{self.role.name}** has been removed by "
                            f"{self.parent_view.parent_view.user.mention}\n\n"
                            f"**Removed At:** <t:{int(datetime.now().timestamp())}:R>"
                        ),
                        accent_color=EmberColors.ERROR,
                    )
                )
                await self.user_to_remove.send(view=removed_view)
            except Exception:
                pass

            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ User Removed"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"Removed {self.user_to_remove.mention} from your bestowed list and removed the role."
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await inter.response.edit_message(view=result, embed=None)

        except Exception as e:
            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ❌ Removal Failed"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"Failed to remove {self.user_to_remove.mention}: {e}"),
                    accent_color=EmberColors.ERROR,
                )
            )
            await inter.response.edit_message(view=result, embed=None)

    async def _cancel_callback(self, inter: Interaction):
        if inter.user.id != self.parent_view.parent_view.user.id:
            await inter.response.send_message(
                view=make_error_card("❌ Error", "Only the role owner can cancel."), ephemeral=True
            )
            return

        self.confirmed = False
        self.stop()
        result = discord.ui.LayoutView(timeout=None)
        result.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## Removal Cancelled"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay("No changes were made."),
                accent_color=discord.Color.blurple(),
            )
        )
        await inter.response.edit_message(view=result, embed=None)

    async def on_timeout(self):
        """Handle view timeout"""
        try:
            result = discord.ui.LayoutView(timeout=None)
            result.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ⏰ Confirmation Timed Out"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay("The removal confirmation timed out."),
                    accent_color=discord.Color.greyple(),
                )
            )
            await self.message.edit(view=result, embed=None)
        except Exception:
            pass
