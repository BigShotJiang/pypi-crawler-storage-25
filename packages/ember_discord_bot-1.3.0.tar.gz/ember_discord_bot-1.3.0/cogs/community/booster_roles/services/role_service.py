# Booster Roles Service
# This module contains business logic for booster role management

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any

import discord

from core.branding import EmberColors

if TYPE_CHECKING:
    from core.store import Store

logger = logging.getLogger("ember.booster_roles.service")


class BoosterRoleService:
    """Business logic for booster role management."""

    def __init__(self, store: Store | None = None):
        self.logger = logging.getLogger("ember.booster_roles.service")
        self._store = store

    async def initialize_tables(self) -> None:
        if self._store is None:
            return
        self._store.register_table("""
            CREATE TABLE IF NOT EXISTS roles (
                user_id INTEGER PRIMARY KEY,
                role_id INTEGER NOT NULL,
                name TEXT,
                created_at TEXT,
                created_by INTEGER,
                guild_id INTEGER,
                color TEXT
            )
        """)
        self._store.register_table("""
            CREATE TABLE IF NOT EXISTS bestowals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giver_id INTEGER NOT NULL,
                receiver_id INTEGER NOT NULL,
                role_id INTEGER NOT NULL,
                accepted BOOLEAN DEFAULT 0,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self._store.register_table("""
            CREATE TABLE IF NOT EXISTS blacklist (
                user_id INTEGER PRIMARY KEY
            )
        """)
        await self._store.initialize()

    async def save_role(self, user_id: int, data: dict[str, Any]) -> None:
        if self._store is None:
            raise RuntimeError("BoosterRoleService requires a store for data operations")
        await self._store.store("roles", {"user_id": user_id, **data}, pk_columns=["user_id"])

    async def get_role(self, user_id: int) -> dict[str, Any] | None:
        if self._store is None:
            raise RuntimeError("BoosterRoleService requires a store for data operations")
        return await self._store.find_one("roles", user_id=user_id)

    async def delete_user_data(self, user_id: int) -> None:
        """GDPR: Remove all data for a user across all tables."""
        if self._store is None:
            raise RuntimeError("BoosterRoleService requires a store for data operations")
        await self._store.remove("roles", user_id=user_id)
        await self._store.remove("bestowals", giver_id=user_id)
        await self._store.remove("bestowals", receiver_id=user_id)
        await self._store.remove("blacklist", user_id=user_id)

    async def validate_role_name(self, name: str, guild: discord.Guild) -> tuple[bool, str]:
        """Validate a role name.

        Returns:
            tuple[bool, str]: (is_valid, error_message)
        """
        if not name or not name.strip():
            return False, "Role name cannot be empty."

        name = name.strip()

        # Length checks
        if len(name) < 2:
            return False, "Role name must be at least 2 characters long."
        if len(name) > 32:
            return False, "Role name must be 32 characters or less."

        # Reserved names
        reserved_names = {"admin", "moderator", "owner", "bot", "system", "discord"}
        if name.lower() in reserved_names:
            return False, f"'{name}' is a reserved name and cannot be used."

        # Check for existing roles with same name
        if discord.utils.get(guild.roles, name=name):
            return False, f"A role named '{name}' already exists."

        return True, ""

    async def create_role(
        self, guild: discord.Guild, user: discord.Member, role_name: str
    ) -> dict[str, Any]:
        """Create a custom booster role and return its metadata."""
        # Validate inputs
        is_valid, error_msg = await self.validate_role_name(role_name, guild)
        if not is_valid:
            raise ValueError(error_msg)

        # Create the role
        try:
            # Create the actual Discord role
            role = await guild.create_role(
                name=role_name,
                reason=f"Custom booster role for {user.display_name} ({user.id})",
                color=EmberColors.WARNING,
                hoist=False,
                mentionable=False,
            )

            # Return role details
            role_data = {
                "name": role_name,
                "role_id": role.id,
                "created_at": datetime.now().isoformat(),
                "created_by": user.id,
                "guild_id": guild.id,
                "color": str(role.color),
            }

            # Log the creation
            await self.log_role_action(
                user.id,
                "create",
                {
                    "name": role_name,
                    "role_id": role.id,
                    "guild_id": guild.id,
                    "color": str(role.color),
                },
            )

            return role_data
        except Exception as e:
            self.logger.error(f"Failed to create role: {e}")
            raise

    async def log_role_action(self, user_id: int, action: str, details: dict[str, Any]) -> None:
        """Log a role-related action."""
        try:
            # In a real implementation, you'd log to database here
            self.logger.info(f"Role action: {action} by user {user_id}: {details}")
        except Exception as e:
            self.logger.error(f"Failed to log role action: {e}")
