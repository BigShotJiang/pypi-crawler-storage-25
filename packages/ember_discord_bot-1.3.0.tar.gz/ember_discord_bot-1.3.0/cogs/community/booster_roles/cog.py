from __future__ import annotations

import asyncio
import logging
from datetime import datetime

import discord
from discord import Interaction, app_commands

from core import checks
from core.branding import EmberColors
from core.checks import check_is_mod as is_mod
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator, cog_i18n
from utils.cards import make_error_card, make_info_card, make_success_card, make_warning_card
from utils.feature_registry import ConfigField, FieldType, feature

from .panel import create_booster_roles_content
from .schema import BoosterRolesGuildConfig
from .services.role_service import BoosterRoleService
from .views import BoosterRoleView, RenounceConfirmationView

_ = Translator("booster_roles", __file__)

log = logging.getLogger("ember.booster_roles")


@cog_i18n(_)
@feature(
    display_name="Booster Roles",
    description="Lets server boosters create and customise their own personal display roles.",
    emoji="🌟",
    fields=[
        ConfigField(
            key="booster_role_id",
            label="Booster Role",
            type=FieldType.ROLE,
            required=True,
            description="Members must have this role to create a custom role.",
        ),
        ConfigField(
            key="showcase_channel_id",
            label="Showcase Channel",
            type=FieldType.CHANNEL,
            description="Channel where custom roles are shown off.",
        ),
    ],
)
class BoosterRolesCog(EmberCog):
    def __init__(self, bot):
        super().__init__(bot)
        self.role_position_lock = asyncio.Lock()
        self.role_service = BoosterRoleService()
        self.db.defaults(
            {
                "guild": {"booster_role_id": None, "showcase_channel_id": None, "enabled": True},
            }
        )
        self.db.register_schema("guild", BoosterRolesGuildConfig)
        self.db.register_schema("role", BoosterRolesGuildConfig)

        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS roles (
                user_id INTEGER PRIMARY KEY,
                role_id INTEGER NOT NULL,
                name TEXT,
                created_at TEXT,
                created_by INTEGER,
                guild_id INTEGER,
                color TEXT
            )
        """)
        self.db.register_index("roles", "role_id")

        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS bestowals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giver_id INTEGER NOT NULL,
                receiver_id INTEGER NOT NULL,
                role_id INTEGER NOT NULL,
                accepted BOOLEAN DEFAULT 0,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS blacklist (
                user_id INTEGER PRIMARY KEY
            )
        """)

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        await self.db.remove("roles", user_id=user_id)
        await self.db.remove("bestowals", giver_id=user_id)
        await self.db.remove("bestowals", receiver_id=user_id)
        await self.db.remove("blacklist", user_id=user_id)
        return {}

    async def process_role_creation(self, interaction: Interaction, name: str):
        try:
            is_valid, validation_msg = await self.role_service.validate_role_name(
                name, interaction.guild
            )
            if not is_valid:
                await interaction.followup.send(f"❌ {validation_msg}", ephemeral=True)
                return

            role_data = await self.role_service.create_role(
                guild=interaction.guild, user=interaction.user, role_name=name
            )

            await self.db.store("roles", {"user_id": interaction.user.id, **role_data})

            success_view = discord.ui.LayoutView(timeout=None)
            success_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## ✅ Custom Role Created Successfully!"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(
                        f"🎉 **Your custom booster role is ready!**\n\n"
                        f"**Name:** `{role_data['name']}`\n"
                        f"**ID:** `{role_data.get('role_id', 'N/A')}`\n\n"
                        f"**Created For:** {interaction.user.mention}\n"
                        f"**Created:** <t:{int(datetime.now().timestamp())}:R>\n\n"
                        "**Customization Options:**\n"
                        "Use `/booster panel` to change name, edit colors, add an icon, or bestow to friends."
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await interaction.followup.send(view=success_view)

        except ValueError as e:
            await interaction.followup.send(f"❌ {str(e)}", ephemeral=True)
        except Exception as e:
            log.error("Unexpected error in process_role_creation: %s", e)
            await interaction.followup.send(
                "❌ An unexpected error occurred. Please contact an administrator.", ephemeral=True
            )

    async def send_booster_roles_embed(self, interaction: Interaction):
        cfg = await self.db.get_all("guild", interaction.guild.id)
        if not cfg.get("enabled", True):
            await interaction.followup.send(
                view=make_error_card(
                    "🚫 Feature Disabled", "Booster roles are disabled on this server."
                ),
                ephemeral=True,
            )
            return
        booster_role_id = cfg.get("booster_role_id")

        booster_role = interaction.guild.get_role(booster_role_id)

        if not booster_role:
            await interaction.followup.send(
                "❌ Booster role not configured on this server.", ephemeral=True
            )
            return

        if booster_role not in interaction.user.roles:
            await interaction.followup.send(
                "🚫 You need to be a server booster to use this feature!",
                ephemeral=True,
            )
            return

        is_banned = await self.db.count("blacklist", user_id=interaction.user.id) > 0
        if is_banned:
            await interaction.followup.send(
                "🚫 You are blacklisted from using custom roles.", ephemeral=True
            )
            return

        role_data = await self.db.find_one("roles", user_id=interaction.user.id)
        role = None

        if role_data:
            role = interaction.guild.get_role(role_data.get("role_id"))
            if not role:
                await self.db.remove("roles", user_id=interaction.user.id)
                role_data = None

        display_text, accent = await create_booster_roles_content(
            interaction, role, role_data, self.db
        )
        view = BoosterRoleView(self, interaction.user, role, role_data, display_text, accent)
        await interaction.followup.send(view=view, ephemeral=True)

    booster_group = app_commands.Group(name="booster", description="Booster role management")

    @booster_group.command(name="panel", description="Open your custom booster role control panel")
    async def booster_panel(self, interaction: Interaction):
        await interaction.response.defer(ephemeral=True)
        await self.send_booster_roles_embed(interaction)

    @booster_group.command(name="renounce", description="Remove a bestowed role from yourself")
    @app_commands.describe(role="Role to renounce (optional - shows menu if not specified)")
    async def booster_renounce(self, interaction: Interaction, role: discord.Role | None = None):
        await interaction.response.defer(ephemeral=True)

        if role:
            await self.process_role_renounce(interaction, role)
        else:
            await self.show_renounce_menu(interaction)

    async def process_role_renounce(self, interaction: Interaction, role: discord.Role):
        role_data = await self.db.find_one("roles", role_id=role.id)
        if not role_data:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Not a Booster Role", f"{role.mention} is not a booster role."
                ),
                ephemeral=True,
            )
            return

        user_has_role = role in interaction.user.roles

        if not user_has_role:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Role Not Found", f"You don't have the {role.mention} role."
                ),
                ephemeral=True,
            )
            return

        if role_data["user_id"] == interaction.user.id:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Own Role",
                    f"{role.mention} is your own custom role. You cannot renounce your own role.",
                ),
                ephemeral=True,
            )
            return

        bestowed_entry = await self.db.find_one(
            "bestowals", giver_id=role_data["user_id"], receiver_id=interaction.user.id
        )
        if not bestowed_entry or not bestowed_entry.get("accepted"):
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Not Bestowed", f"{role.mention} was not officially bestowed to you."
                ),
                ephemeral=True,
            )
            return

        await self.show_renounce_confirmation(interaction, role, role_data)

    async def show_renounce_menu(self, interaction: Interaction):
        user_roles = interaction.user.roles
        bestowed_roles = []

        for role in user_roles:
            role_data = await self.db.find_one("roles", role_id=role.id)
            if role_data and role_data["user_id"] != interaction.user.id:
                bestowed_entry = await self.db.find_one(
                    "bestowals", giver_id=role_data["user_id"], receiver_id=interaction.user.id
                )
                if bestowed_entry and bestowed_entry.get("accepted"):
                    bestowed_roles.append(
                        {
                            "role": role,
                            "role_data": role_data,
                            "owner_id": role_data["user_id"],
                        }
                    )

        if not bestowed_roles:
            await interaction.followup.send(
                view=make_info_card(
                    "📭 No Bestowed Roles",
                    "You don't have any bestowed roles to renounce.\n\n"
                    "**What are bestowed roles?**\n"
                    "These are roles gifted to you by other boosters using the **Bestow Role** feature.",
                ),
                ephemeral=True,
            )
            return

        if len(bestowed_roles) == 1:
            role_info = bestowed_roles[0]
            await self.show_renounce_confirmation(
                interaction, role_info["role"], role_info["role_data"]
            )
        else:
            lines = []
            for i, role_info in enumerate(bestowed_roles, 1):
                role = role_info["role"]
                owner = interaction.guild.get_member(role_info["owner_id"])
                owner_name = owner.display_name if owner else "Unknown"
                lines.append(
                    f"**{i}. {role.name}**\nBestowed by: {owner_name} | Color: `{role.color}`"
                )

            await interaction.followup.send(
                view=make_info_card(
                    "🎭 Select Role to Renounce",
                    "Choose which bestowed role you want to remove:\n\n" + "\n\n".join(lines),
                    footer="Type the number of the role you want to renounce.",
                ),
                ephemeral=True,
            )

            def check(m):
                return (
                    m.author.id == interaction.user.id
                    and m.channel.id == interaction.channel.id
                    and m.content.isdigit()
                    and 1 <= int(m.content) <= len(bestowed_roles)
                )

            try:
                msg = await self.bot.wait_for("message", timeout=60.0, check=check)
                selection = int(msg.content) - 1

                try:
                    await msg.delete()
                except Exception:
                    pass

                role_info = bestowed_roles[selection]
                await self.show_renounce_confirmation(
                    interaction, role_info["role"], role_info["role_data"]
                )

            except TimeoutError:
                await interaction.followup.send(
                    view=make_warning_card(
                        "⏰ Timed Out",
                        "Selection timed out. Use `/booster renounce` with the role option to specify a role directly.",
                    ),
                    ephemeral=True,
                )

    async def show_renounce_confirmation(
        self, interaction: Interaction, role: discord.Role, role_data: dict
    ):
        owner = interaction.guild.get_member(role_data["user_id"])
        owner_mention = owner.mention if owner else None
        view = RenounceConfirmationView(
            self, role, role_data["user_id"], owner_mention=owner_mention
        )
        await interaction.followup.send(view=view, ephemeral=True)

    @booster_group.command(
        name="blacklist", description="Manage the custom role blacklist (mods only)"
    )
    @checks.mod()
    @app_commands.describe(
        action="Action to perform",
        user="User to add/remove",
        reason="Reason for blacklisting (optional)",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="add", value="add"),
            app_commands.Choice(name="remove", value="remove"),
            app_commands.Choice(name="list", value="list"),
            app_commands.Choice(name="check", value="check"),
        ]
    )
    async def booster_blacklist(
        self,
        interaction: Interaction,
        action: str,
        user: discord.User | None = None,
        reason: str | None = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if not await is_mod(interaction):
            await interaction.followup.send(
                view=make_error_card(
                    "🚫 Unauthorized", "You are not authorized to use this command."
                ),
                ephemeral=True,
            )
            return

        if action == "list":
            blacklist_rows = await self.db.find("blacklist")
            blacklist = [r["user_id"] for r in blacklist_rows]
            if not blacklist:
                await interaction.followup.send(
                    view=make_info_card("📜 Blacklist", "The blacklist is currently empty."),
                    ephemeral=True,
                )
                return

            user_list = []
            for user_id in blacklist[:10]:
                user_obj = self.bot.get_user(user_id)
                if user_obj:
                    user_list.append(f"• {user_obj.mention} (`{user_id}`)")
                else:
                    user_list.append(f"• `{user_id}`")

            extra = f"\n*...and {len(blacklist) - 10} more*" if len(blacklist) > 10 else ""
            await interaction.followup.send(
                view=make_warning_card(
                    "📜 Blacklisted Users",
                    f"**Total:** {len(blacklist)} users\n\n" + "\n".join(user_list) + extra,
                ),
                ephemeral=True,
            )
            return

        if action == "check":
            if not user:
                await interaction.followup.send(
                    view=make_error_card("❌ Missing User", "Please specify a user to check."),
                    ephemeral=True,
                )
                return

            is_blacklisted = await self.db.count("blacklist", user_id=user.id) > 0
            if is_blacklisted:
                await interaction.followup.send(
                    view=make_error_card(
                        f"🚫 {user} — Blacklisted",
                        f"**User ID:** `{user.id}`\n\nThis user cannot create or update custom roles.",
                    ),
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    view=make_success_card(
                        f"✅ {user} — Clear",
                        f"**User ID:** `{user.id}`\n\nThis user can create and manage custom roles.",
                    ),
                    ephemeral=True,
                )
            return

        if not user:
            await interaction.followup.send(
                view=make_error_card("❌ Missing User", "Please specify a user for this action."),
                ephemeral=True,
            )
            return

        if action == "add":
            is_blacklisted = await self.db.count("blacklist", user_id=user.id) > 0
            if is_blacklisted:
                await interaction.followup.send(
                    view=make_warning_card(
                        "⚠️ Already Blacklisted", f"{user.mention} is already blacklisted."
                    ),
                    ephemeral=True,
                )
                return

            await self.db.store("blacklist", {"user_id": user.id})

            reason_line = f"\n**Reason:** {reason}" if reason else ""
            await interaction.followup.send(
                view=make_success_card(
                    "✅ User Blacklisted",
                    f"{user.mention} has been added to the blacklist.\n"
                    f"**By:** {interaction.user.mention}{reason_line}",
                ),
                ephemeral=True,
            )

        elif action == "remove":
            is_blacklisted = await self.db.count("blacklist", user_id=user.id) > 0
            if not is_blacklisted:
                await interaction.followup.send(
                    view=make_warning_card(
                        "⚠️ Not Blacklisted", f"{user.mention} is not in the blacklist."
                    ),
                    ephemeral=True,
                )
                return

            await self.db.remove("blacklist", user_id=user.id)

            await interaction.followup.send(
                view=make_success_card(
                    "✅ User Removed from Blacklist",
                    f"{user.mention} has been removed from the blacklist.\n"
                    f"**By:** {interaction.user.mention}",
                ),
                ephemeral=True,
            )

        else:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Invalid Action", "Use `add`, `remove`, `list`, or `check`."
                ),
                ephemeral=True,
            )


async def setup(bot):
    await bot.add_cog(BoosterRolesCog(bot))
