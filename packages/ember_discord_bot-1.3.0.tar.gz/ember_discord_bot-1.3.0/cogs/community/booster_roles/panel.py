from datetime import datetime

import discord
from discord import Color


async def create_booster_roles_content(
    interaction: discord.Interaction,
    role: discord.Role | None,
    role_data: dict | None,
    db,
) -> tuple[str, discord.Color]:
    """Return (display_text, accent_color) for the booster roles panel LayoutView."""
    lines = []

    if role:
        lines.append(f"Manage your custom booster role: {role.mention}\n")
        lines.append(f"**Role Name:** `{role.name}`  **Color:** `{str(role.color)}`")

        if role_data:
            created_at = datetime.fromisoformat(
                role_data.get("created_at", datetime.now().isoformat())
            )
            lines[-1] += f"\n**Created:** <t:{int(created_at.timestamp())}:R>"
            if "updated_at" in role_data:
                updated_at = datetime.fromisoformat(role_data["updated_at"])
                lines[-1] += f"  **Updated:** <t:{int(updated_at.timestamp())}:R>"

        has_icon = bool(role.display_icon or role.unicode_emoji)
        has_gradient = role_data.get("color_type") == "gradient" if role_data else False
        icon_str = "✅ Yes" if has_icon else "❌ No"
        color_type = "🌈 Gradient" if has_gradient else "🎨 Solid"
        lines.append(f"**Has Icon:** {icon_str}  **Color Type:** {color_type}")
        if has_gradient and role_data and "secondary_colour" in role_data:
            lines[-1] += f"  **Secondary:** `{role_data['secondary_colour']}`"

        bestowed_users = await db.find("bestowals", giver_id=interaction.user.id)
        if bestowed_users:
            total = len(bestowed_users)
            accepted = sum(1 for d in bestowed_users if d.get("accepted", False))
            pending = total - accepted
            lines.append(
                f"**🎁 Bestowed:** {total} invited · {accepted} accepted · {pending} pending"
            )
            recent = []
            for bd in bestowed_users[:3]:
                member = interaction.guild.get_member(bd["receiver_id"])
                if member:
                    status = "✅" if bd.get("accepted", False) else "📨"
                    recent.append(f"{status} {member.mention}")
            if recent:
                lines.append("**👥 Recent:** " + "  ".join(recent))

        lines.append(
            "**🎭 Edit Role** — Rename, recolor, or change icon\n"
            "**🎁 Bestow Role** — Share your role with others\n"
            "**🔄 Refresh** — Update this menu"
        )
        lines.append(
            "**What is Bestow Role?** Share your role with friends via DM invite. "
            "They can accept or decline, and you can manage access anytime."
        )
        accent = role.color

    else:
        lines.append("Create and manage your custom booster role!")
        lines.append(
            "**How It Works**\n"
            "1. Click **🎭 Create Role** to make your custom role\n"
            "2. Use buttons to customize name, color, and icon\n"
            "3. Share with friends using **🎁 Bestow Role**\n"
            "4. Your role will appear above other members!"
        )
        lines.append(
            "**🎭 Create Role** — Make your custom booster role\n"
            "**🔄 Refresh** — Update this menu"
        )
        accent = Color.gold()

    is_banned = await db.count("blacklist", user_id=interaction.user.id) > 0
    if is_banned:
        lines.append(
            "⚠️ **Account Status:** ❌ Your account has been blacklisted. "
            "You cannot create or manage booster roles."
        )
        accent = Color.red()

    return "\n\n".join(lines), accent
