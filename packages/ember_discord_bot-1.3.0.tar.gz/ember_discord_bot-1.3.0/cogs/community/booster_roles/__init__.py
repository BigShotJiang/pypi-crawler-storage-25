from .cog import BoosterRolesCog


async def setup(bot):
    await bot.add_cog(BoosterRolesCog(bot))
