from typing import TypedDict


class BoosterRolesGuildConfig(TypedDict, total=False):
    """Guild-level booster_roles configuration."""

    enabled: bool
