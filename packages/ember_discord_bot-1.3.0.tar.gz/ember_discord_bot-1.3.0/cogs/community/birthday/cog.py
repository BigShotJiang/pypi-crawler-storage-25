from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo

import discord
import pytz
from discord import app_commands, ui
from discord.ext import commands, tasks

from core.branding import EmberColors
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.errors import ResourceNotFoundError, UserFeedbackError
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import BirthdayGuildConfig, BirthdayUserConfig
from .services.birthday_service import BirthdayService

logger = logging.getLogger("ember.birthday")
_ = Translator("birthday", __file__)

_COMMON_ZONES = [
    "Asia/Kolkata",
    "Asia/Karachi",
    "Asia/Dhaka",
    "Asia/Colombo",
    "Asia/Kathmandu",
    "Asia/Dubai",
    "Asia/Shanghai",
    "Asia/Tokyo",
    "Asia/Seoul",
    "Australia/Sydney",
    "Pacific/Auckland",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "Brazil/East",
    "Europe/London",
    "Europe/Paris",
    "Europe/Berlin",
    "Europe/Moscow",
    "Africa/Johannesburg",
    "UTC",
]


class _TimezoneSelect(ui.Select):
    def __init__(self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None):
        self._user_id = user_id
        self._guild_id = guild_id
        self._birth_date = birth_date
        self._birth_year = birth_year
        options = [discord.SelectOption(label=tz, value=tz) for tz in _COMMON_ZONES]
        super().__init__(placeholder="Select your timezone…", options=options, custom_id="bday:tz")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=_BirthdayConfirmView(
                self._user_id, self._guild_id, self._birth_date, self._birth_year, self.values[0]
            )
        )


class _ConfirmBtn(ui.Button):
    def __init__(
        self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None, timezone: str
    ):
        self._user_id = user_id
        self._guild_id = guild_id
        self._birth_date = birth_date
        self._birth_year = birth_year
        self._timezone = timezone
        super().__init__(
            style=discord.ButtonStyle.success, label="✅ Confirm", custom_id="bday:confirm"
        )

    async def callback(self, interaction: discord.Interaction):
        cog = interaction.client.get_cog("Birthday")
        if cog:
            await cog.set_birthday(
                self._user_id, self._guild_id, self._birth_date, self._birth_year, self._timezone
            )
        done_view = ui.LayoutView(timeout=None)
        done_view.add_item(
            ui.Container(
                ui.TextDisplay("## ✅ Birthday Saved!"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"**Date:** {self._birth_date}\n**Timezone:** {self._timezone}"),
                accent_color=EmberColors.SUCCESS,
            )
        )
        await interaction.response.edit_message(view=done_view)
        await asyncio.sleep(8)
        try:
            await interaction.message.delete()
        except discord.NotFound:
            pass


class _CancelBtn(ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.danger, label="✖ Cancel", custom_id="bday:cancel"
        )

    async def callback(self, interaction: discord.Interaction):
        v = ui.LayoutView(timeout=None)
        v.add_item(
            ui.Container(
                ui.TextDisplay("## ❌ Cancelled"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay("-# Birthday setup was cancelled."),
                accent_color=discord.Color.blurple(),
            )
        )
        await interaction.response.edit_message(view=v)
        await asyncio.sleep(5)
        try:
            await interaction.message.delete()
        except discord.NotFound:
            pass


class _BirthdayConfirmView(ui.LayoutView):
    def __init__(
        self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None, timezone: str
    ):
        super().__init__(timeout=300)
        tz = ZoneInfo(timezone)
        current_year = datetime.now(tz).year
        age_line = f"**Age:** turning {current_year - birth_year}\n" if birth_year else ""
        self.add_item(
            ui.Container(
                ui.TextDisplay("## 🎂 Confirm Birthday"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"**Date:** {birth_date}\n{age_line}**Timezone:** {timezone}"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(
                    _ConfirmBtn(user_id, guild_id, birth_date, birth_year, timezone),
                    _CancelBtn(),
                ),
                accent_color=EmberColors.WARNING,
            )
        )


class _BirthdaySetupView(ui.LayoutView):
    def __init__(self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None):
        super().__init__(timeout=300)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## 🎂 Set Your Birthday"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"**Date:** {birth_date}\nSelect your timezone to continue."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_TimezoneSelect(user_id, guild_id, birth_date, birth_year)),
                accent_color=EmberColors.WARNING,
            )
        )


class _ConfirmRemoveBtn(ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.danger, label="Yes, Remove", custom_id="bday:rm_yes"
        )

    async def callback(self, interaction: discord.Interaction):
        cog = interaction.client.get_cog("Birthday")
        if cog and interaction.guild:
            await cog.birthday_service.remove_birthday(interaction.user.id, interaction.guild.id)
        v = ui.LayoutView(timeout=None)
        v.add_item(
            ui.Container(
                ui.TextDisplay("## ✅ Birthday Removed"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay("Your birthday data has been permanently removed."),
                accent_color=EmberColors.SUCCESS,
            )
        )
        await interaction.response.edit_message(view=v)
        await asyncio.sleep(5)
        try:
            await interaction.message.delete()
        except discord.NotFound:
            pass


class _KeepBtn(ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.secondary, label="Keep It", custom_id="bday:rm_no"
        )

    async def callback(self, interaction: discord.Interaction):
        v = ui.LayoutView(timeout=None)
        v.add_item(
            ui.Container(
                ui.TextDisplay("## ✅ Kept"),
                ui.TextDisplay("-# Your birthday data is still saved."),
                accent_color=EmberColors.SUCCESS,
            )
        )
        await interaction.response.edit_message(view=v)
        await asyncio.sleep(5)
        try:
            await interaction.message.delete()
        except discord.NotFound:
            pass


class _RemoveBirthdayView(ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=60)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ⚠️ Remove Birthday?"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay("This will permanently delete your birthday data. Are you sure?"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_ConfirmRemoveBtn(), _KeepBtn()),
                accent_color=EmberColors.WARNING,
            )
        )


class _PrevPageBtn(ui.Button):
    def __init__(self, birthdays, guild_name, bot, page):
        self._d = (birthdays, guild_name, bot, page)
        super().__init__(style=discord.ButtonStyle.secondary, label="◀ Prev", disabled=(page == 0))

    async def callback(self, interaction: discord.Interaction):
        bd, gn, bot, pg = self._d
        await interaction.response.edit_message(view=_UpcomingView(bd, gn, bot, pg - 1))


class _NextPageBtn(ui.Button):
    def __init__(self, birthdays, guild_name, bot, page, has_next):
        self._d = (birthdays, guild_name, bot, page)
        super().__init__(style=discord.ButtonStyle.secondary, label="Next ▶", disabled=not has_next)

    async def callback(self, interaction: discord.Interaction):
        bd, gn, bot, pg = self._d
        await interaction.response.edit_message(view=_UpcomingView(bd, gn, bot, pg + 1))


class _UpcomingView(ui.LayoutView):
    PER_PAGE = 10

    def __init__(self, birthdays: list, guild_name: str, bot, page: int = 0):
        super().__init__(timeout=120)
        start = page * self.PER_PAGE
        end = start + self.PER_PAGE
        total_pages = max(1, (len(birthdays) + self.PER_PAGE - 1) // self.PER_PAGE)
        lines = []

        for user_data in birthdays[start:end]:
            user_id = user_data["user_id"]
            birth_date = user_data["birth_date"]
            birth_year = user_data["birth_year"]
            timezone = user_data["timezone"]
            month, day = map(int, birth_date.split("-"))
            try:
                tz = ZoneInfo(timezone)
                now_local = datetime.now(tz)
                next_bday = datetime(now_local.year, month, day, tzinfo=tz)
                if next_bday < now_local:
                    next_bday = datetime(now_local.year + 1, month, day, tzinfo=tz)
                days_until = (next_bday - now_local).days
                age_str = f" (turning {next_bday.year - birth_year})" if birth_year else ""
                u = bot.get_user(user_id)
                name = u.display_name if u else f"ID {user_id}"
                lines.append(f"**{name}** — {birth_date}{age_str} — {days_until}d away")
            except Exception:
                lines.append(f"**ID {user_id}** — {birth_date}")

        body = "\n".join(lines) if lines else "*No birthdays found.*"
        has_next = end < len(birthdays)

        self.add_item(
            ui.Container(
                ui.TextDisplay(f"## 🎂 Upcoming Birthdays — {guild_name}"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(body),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"-# Page {page + 1}/{total_pages}"),
                ui.ActionRow(
                    _PrevPageBtn(birthdays, guild_name, bot, page),
                    _NextPageBtn(birthdays, guild_name, bot, page, has_next),
                ),
                accent_color=EmberColors.WARNING,
            )
        )


@feature(
    display_name="Birthday Tracker",
    emoji="🎂",
    description="Tracks member birthdays and announces them with an optional birthday role.",
    fields=[
        ConfigField(
            key="channel_id",
            label="Announcement Channel",
            type=FieldType.CHANNEL,
            required=True,
            description="Channel for birthday announcements.",
        ),
        ConfigField(
            key="birthday_role_id",
            label="Birthday Role",
            type=FieldType.ROLE,
            description="Role given to the member on their birthday (removed after 24 h).",
        ),
    ],
)
@cog_i18n(_)
class BirthdayCog(EmberCog, name="Birthday"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.birthday_service = BirthdayService(self.db)
        self.db.defaults(
            {
                "guild": {
                    "channel_id": None,
                    "birthday_role_id": None,
                    "enabled": True,
                },
            }
        )
        self.db.register_schema("guild", BirthdayGuildConfig)
        self.db.register_schema("user", BirthdayUserConfig)

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)

        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS users (
                user_id    INTEGER NOT NULL,
                guild_id   INTEGER NOT NULL DEFAULT 0,
                birth_date TEXT    NOT NULL,
                birth_year INTEGER,
                timezone   TEXT    NOT NULL,
                PRIMARY KEY (user_id, guild_id)
            )
        """)

        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                year INTEGER NOT NULL
            )
        """)

        await self.db.initialize()

        try:
            self.birthday_check.start()
        except RuntimeError:
            pass

    async def cog_unload(self) -> None:
        self.birthday_check.cancel()

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        await self.birthday_service.remove_birthday_all_guilds(user_id)
        await self.db.remove("announcements", user_id=user_id)
        return {}

    async def set_birthday(
        self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None, timezone: str
    ):
        await self.birthday_service.set_birthday(
            user_id, guild_id, birth_date, birth_year, timezone
        )

    @tasks.loop(minutes=1)
    async def birthday_check(self):
        for guild in self.bot.guilds:
            if not await self.db.guild(guild.id).is_enabled():
                continue
            users = await self.birthday_service.get_guild_birthdays(guild.id)
            for user_data in users:
                user_id = user_data["user_id"]
                birth_date = user_data["birth_date"]
                tz_name = user_data["timezone"]
                try:
                    tz = ZoneInfo(tz_name)
                    local_time = datetime.now(tz)
                    if local_time.hour == 0 and local_time.minute == 0:
                        if birth_date == local_time.strftime("%m-%d"):
                            await self.send_birthday_wishes(user_id, guild, local_time.year)
                except Exception as e:
                    logger.error("Birthday check error for user %s: %s", user_id, e)

        await self._expire_birthday_roles()

    async def _expire_birthday_roles(self):
        """Remove birthday roles from members whose birthday is no longer today."""
        datetime.now(pytz.UTC)
        for guild in self.bot.guilds:
            if not await self.db.guild(guild.id).is_enabled():
                continue
            role_id = await self.db.guild(guild.id).get("birthday_role_id")
            if not role_id:
                continue
            role = guild.get_role(role_id)
            if not role or not role.members:
                continue

            for member in list(role.members):
                try:
                    # Get user data using service layer (check if birthday is today)
                    await self.birthday_service.get_birthday(member.id, guild.id)
                except Exception as e:
                    logger.error("Birthday role expiry error for %s: %s", member.id, e)

    async def send_birthday_wishes(self, user_id: int, guild: discord.Guild, year: int):
        member = guild.get_member(user_id)
        if not member:
            return

        user_data = await self.birthday_service.get_birthday(user_id, guild.id)
        if not user_data:
            return

        birth_date = user_data["birth_date"]
        birth_year = user_data["birth_year"]

        channel_id = await self.db.guild(guild.id).get("channel_id")
        if not channel_id:
            return

        channel = guild.get_channel(channel_id)
        if not channel:
            return

        announcement = await self.birthday_service.get_user_announcement(user_id, guild.id, year)
        if announcement:
            return

        children: list = [
            ui.TextDisplay(f"## 🎉 Happy Birthday, {member.display_name}!"),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
        ]

        if birth_year:
            children.append(ui.TextDisplay(f"Turning **{year - birth_year}** today! 🎂"))

        birthday_image = os.environ.get("BIRTHDAY_IMAGE_URL", "")
        if birthday_image:
            children.append(ui.MediaGallery(discord.MediaGalleryItem(media=birthday_image)))

        children.extend(
            [
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"-# {member.mention} • {birth_date}"),
            ]
        )

        bday_view = ui.LayoutView(timeout=None)
        bday_view.add_item(ui.Container(*children, accent_color=EmberColors.WARNING))
        await channel.send(view=bday_view)

        role_id = await self.db.guild(guild.id).get("birthday_role_id")
        if role_id:
            role = guild.get_role(role_id)
            if role:
                try:
                    await member.add_roles(role, reason="Birthday role")
                except Exception as e:
                    logger.error("Failed to add birthday role: %s", e)

        await self.birthday_service.save_announcement(user_id, guild.id, channel_id, year)

    birthday_group = app_commands.Group(name="birthday", description="Birthday commands")

    @birthday_group.command(name="set", description="Set your birthday")
    @app_commands.describe(
        date="Your birthday in MM-DD format, e.g. 03-15 for March 15",
        year="Your birth year (optional, used to display age)",
    )
    async def birthday_set(
        self, interaction: discord.Interaction, date: str, year: int | None = None
    ):
        if not re.match(r"^\d{2}-\d{2}$", date):
            raise UserFeedbackError(
                "Use **MM-DD** format, e.g. `03-15` for March 15.", title="Invalid Format"
            )
        try:
            month, day = map(int, date.split("-"))
            if not (1 <= month <= 12 and 1 <= day <= 31):
                raise ValueError
        except ValueError as e:
            raise UserFeedbackError(
                "Enter a valid date like `03-15` for March 15.", title="Invalid Date"
            ) from e

        current_year = datetime.now(pytz.UTC).year
        if year and not (1900 <= year <= current_year):
            raise UserFeedbackError(
                f"Year must be between 1900 and {current_year}.", title="Invalid Year"
            )

        guild_id = interaction.guild_id or 0
        await interaction.response.send_message(
            view=_BirthdaySetupView(interaction.user.id, guild_id, date, year),
            ephemeral=True,
        )

    @birthday_group.command(name="remove", description="Remove your birthday from this server")
    async def birthday_remove(self, interaction: discord.Interaction):
        guild_id = interaction.guild_id or 0
        user_data = await self.birthday_service.get_birthday(interaction.user.id, guild_id)
        if not user_data:
            raise ResourceNotFoundError("birthday")
        await interaction.response.send_message(view=_RemoveBirthdayView(), ephemeral=True)

    @birthday_group.command(name="check", description="View a member's saved birthday")
    @app_commands.describe(member="Who to check (leave empty for yourself)")
    async def birthday_check_cmd(
        self, interaction: discord.Interaction, member: discord.Member | None = None
    ):
        target = member or interaction.user
        guild_id = interaction.guild_id or 0
        user_data = await self.birthday_service.get_birthday(target.id, guild_id)
        if not user_data:
            raise ResourceNotFoundError("birthday")

        birth_date = user_data["birth_date"]
        birth_year = user_data["birth_year"]
        timezone = user_data["timezone"]
        month, day = map(int, birth_date.split("-"))
        countdown = ""
        try:
            tz = ZoneInfo(timezone)
            now_local = datetime.now(tz)
            next_bday = datetime(now_local.year, month, day, tzinfo=tz)
            if next_bday < now_local:
                next_bday = datetime(now_local.year + 1, month, day, tzinfo=tz)
            days = (next_bday - now_local).days
            countdown = f"\n**Days until birthday:** {days}"
        except Exception:
            pass

        age_line = f"\n**Age:** {next_bday.year - birth_year}" if birth_year else ""

        info_view = ui.LayoutView(timeout=None)
        info_view.add_item(
            ui.Container(
                ui.TextDisplay(f"## 🎂 {target.display_name}'s Birthday"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(
                    f"**Date:** {birth_date}\n**Timezone:** {timezone}{age_line}{countdown}"
                ),
                accent_color=EmberColors.WARNING,
            )
        )
        await interaction.response.send_message(view=info_view, ephemeral=True)

    @birthday_group.command(name="upcoming", description="See upcoming birthdays in this server")
    async def birthday_upcoming(self, interaction: discord.Interaction):
        guild_id = interaction.guild_id or 0
        guild_users = await self.birthday_service.get_guild_birthdays(guild_id)

        if not guild_users:
            raise ResourceNotFoundError("birthday")

        def sort_key(user_data):
            bd = user_data["birth_date"]
            tz_name = user_data["timezone"]
            month, day = map(int, bd.split("-"))
            try:
                tz = ZoneInfo(tz_name)
                now_local = datetime.now(tz)
                next_bday = datetime(now_local.year, month, day, tzinfo=tz)
                if next_bday < now_local:
                    next_bday = datetime(now_local.year + 1, month, day, tzinfo=tz)
                return (next_bday - now_local).days
            except Exception:
                return 999

        guild_users.sort(key=sort_key)
        await interaction.response.send_message(
            view=_UpcomingView(guild_users, interaction.guild.name, self.bot),
            ephemeral=True,
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(BirthdayCog(bot))
