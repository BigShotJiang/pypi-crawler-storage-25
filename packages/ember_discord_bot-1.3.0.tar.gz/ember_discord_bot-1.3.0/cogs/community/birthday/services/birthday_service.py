from datetime import datetime
from zoneinfo import ZoneInfo

from core.store import Store


class BirthdayService:
    """Business logic for birthday management (pure business logic, no DB coupling)."""

    def __init__(self, store: Store) -> None:
        self.store = store

    async def set_birthday(
        self, user_id: int, guild_id: int, birth_date: str, birth_year: int | None, timezone: str
    ) -> None:
        await self.store.store(
            "users",
            {
                "user_id": user_id,
                "guild_id": guild_id,
                "birth_date": birth_date,
                "birth_year": birth_year,
                "timezone": timezone,
            },
        )

    async def get_birthday(self, user_id: int, guild_id: int) -> dict | None:
        return await self.store.find_one("users", user_id=user_id, guild_id=guild_id)

    async def remove_birthday(self, user_id: int, guild_id: int) -> int:
        return await self.store.remove("users", user_id=user_id, guild_id=guild_id)

    async def remove_birthday_all_guilds(self, user_id: int) -> int:
        """Remove birthday data across all guilds (GDPR delete)."""
        return await self.store.remove("users", user_id=user_id)

    async def get_guild_birthdays(self, guild_id: int) -> list[dict]:
        return await self.store.find("users", guild_id=guild_id)

    async def get_user_announcement(self, user_id: int, guild_id: int, year: int) -> dict | None:
        return await self.store.find_one(
            "announcements", user_id=user_id, guild_id=guild_id, year=year
        )

    async def save_announcement(
        self, user_id: int, guild_id: int, channel_id: int, year: int
    ) -> None:
        await self.store.store(
            "announcements",
            {
                "user_id": user_id,
                "guild_id": guild_id,
                "channel_id": channel_id,
                "year": year,
            },
        )

    async def init_database(self) -> None:
        """No-op: birthday service uses driver-agnostic document store; no DDL required."""

    def calculate_days_until_birthday(self, birth_date: str, timezone: str) -> int:
        try:
            month, day = map(int, birth_date.split("-"))
            tz = ZoneInfo(timezone)
            now_local = datetime.now(tz)
            next_bday = datetime(now_local.year, month, day, tzinfo=tz)
            if next_bday < now_local:
                next_bday = datetime(now_local.year + 1, month, day, tzinfo=tz)
            return (next_bday - now_local).days
        except Exception:
            return 999
