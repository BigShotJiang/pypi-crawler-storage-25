from typing import TypedDict


class BirthdayGuildConfig(TypedDict, total=False):
    """Guild-level birthday configuration."""

    channel_id: int | None
    birthday_role_id: int | None
    enabled: bool


class BirthdayUserConfig(TypedDict, total=False):
    """User-level birthday data."""

    birthday_date: str | None
    timezone: str
