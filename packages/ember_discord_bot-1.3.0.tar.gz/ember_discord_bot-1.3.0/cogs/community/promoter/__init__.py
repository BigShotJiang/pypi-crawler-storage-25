from .cog import PromoterRole


async def setup(bot):
    await bot.add_cog(PromoterRole(bot))
