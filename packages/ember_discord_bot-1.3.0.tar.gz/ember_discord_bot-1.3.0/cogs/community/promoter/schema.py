from typing import TypedDict


class PromoterGuildConfig(TypedDict, total=False):
    """Guild-level promoter configuration."""

    enabled: bool
