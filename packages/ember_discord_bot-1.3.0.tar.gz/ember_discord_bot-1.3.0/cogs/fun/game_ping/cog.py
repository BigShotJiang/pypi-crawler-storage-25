"""Game ping functionality cog."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.cards import make_error_card, make_success_card
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import GamePingGuildConfig

_ = Translator("game_ping", __file__)

if TYPE_CHECKING:
    from core.bot import EmberBot

log = logging.getLogger("ember.game_ping")


@cog_i18n(_)
@feature(
    display_name="Game Ping",
    description="Ping users when a game is ready to play.",
    emoji="🎮",
    fields=[
        ConfigField(
            key="channel_id",
            label="Game Channel",
            type=FieldType.CHANNEL,
            description="Channel where game pings are sent.",
            required=True,
        ),
        ConfigField(
            key="role_id",
            label="Game Role",
            type=FieldType.ROLE,
            description="Role to ping when a game is ready.",
            required=True,
        ),
    ],
)
class GamePingCog(EmberCog):
    """Game ping functionality."""

    def __init__(self, bot: EmberBot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {"enabled": True, "channel_id": None, "role_id": None},
            }
        )
        self.db.register_schema("guild", GamePingGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    game_group = app_commands.Group(name="game", description="Game ping commands")

    @game_group.command(name="ping", description="Ping users for a game")
    @app_commands.describe(game="The game to ping for", message="Additional message (optional)")
    async def game_ping(
        self, interaction: discord.Interaction, game: str, message: str = ""
    ) -> None:
        if not interaction.guild:
            return await interaction.response.send_message(
                view=make_error_card("Server Only", "This command can only be used in a server."),
                ephemeral=True,
            )
        guild = interaction.guild
        cfg = await self.db.get_all("guild", guild.id)
        if not cfg.get("enabled", True):
            view = make_error_card(
                "❌ Not Configured", "Game ping is not configured for this server."
            )
            return await interaction.response.send_message(view=view, ephemeral=True)

        channel_id = cfg.get("channel_id")
        role_id = cfg.get("role_id")

        if not channel_id or not role_id:
            view = make_error_card(
                "❌ Configuration Error",
                "Game ping requires both channel and role to be configured.",
            )
            return await interaction.response.send_message(view=view, ephemeral=True)

        channel = guild.get_channel(channel_id)
        role = guild.get_role(role_id)

        if not channel or not role:
            view = make_error_card(
                "❌ Invalid Configuration", "Configured channel or role not found."
            )
            return await interaction.response.send_message(view=view, ephemeral=True)

        ping_message = f"{role.mention} - {game} is ready!{' ' + message if message else ''}"
        await channel.send(ping_message)

        view = make_success_card(
            "🎮 Game Ping Sent!",
            f"Successfully pinged {role.mention} in {channel.mention} for **{game}**.",
        )
        await interaction.response.send_message(view=view, ephemeral=True)


async def setup(bot: EmberBot) -> None:
    await bot.add_cog(GamePingCog(bot))
