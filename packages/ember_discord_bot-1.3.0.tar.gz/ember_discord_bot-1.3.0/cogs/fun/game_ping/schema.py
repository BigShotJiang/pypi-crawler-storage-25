from typing import TypedDict


class GamePingGuildConfig(TypedDict, total=False):
    """Guild-level game_ping configuration."""

    enabled: bool
