from __future__ import annotations

import re
import time
from collections import defaultdict, deque

import aiohttp
import discord
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.cards import make_error_card, make_success_card, make_warning_card

_ = Translator("emoji_stealer", __file__)


@cog_i18n(_)
class EmojiStealerCog(EmberCog):
    """Steal emojis from messages by replying! Only steals new ones not already on server."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.emoji_regex = re.compile(r"<(a?):(\w+):(\d+)>")
        self.user_cooldowns: dict[int, deque] = defaultdict(lambda: deque(maxlen=5))
        self.cooldown_period = 60
        self.server_emoji_cache: dict[int, set[str]] = {}
        self.server_emoji_ids: dict[int, set[int]] = {}

    def update_server_cache(self, guild: discord.Guild):
        self.server_emoji_cache[guild.id] = {emoji.name.lower() for emoji in guild.emojis}
        self.server_emoji_ids[guild.id] = {emoji.id for emoji in guild.emojis}

    def get_server_emojis(self, guild: discord.Guild) -> tuple[set[str], set[int]]:
        if guild.id not in self.server_emoji_cache:
            self.update_server_cache(guild)
        return self.server_emoji_cache[guild.id], self.server_emoji_ids[guild.id]

    def check_rate_limit(self, user_id: int) -> tuple[bool, int | None]:
        now = time.time()
        user_timestamps = self.user_cooldowns[user_id]
        while user_timestamps and now - user_timestamps[0] > self.cooldown_period:
            user_timestamps.popleft()
        if len(user_timestamps) >= 5:
            wait_time = int(self.cooldown_period - (now - user_timestamps[0]))
            return False, wait_time
        return True, None

    def extract_emojis_from_message(self, message: discord.Message) -> list[tuple[str, int, bool]]:
        matches = self.emoji_regex.findall(message.content)
        emojis = []
        for match in matches:
            animated_flag = match[0]
            name = match[1]
            emoji_id = match[2]
            is_animated = bool(animated_flag)
            emojis.append((name, int(emoji_id), is_animated))
        return emojis

    def get_emoji_limits(self, guild: discord.Guild) -> tuple[int, int]:
        if guild.premium_tier == 0:
            return 50, 50
        elif guild.premium_tier == 1:
            return 100, 100
        elif guild.premium_tier == 2:
            return 150, 150
        else:
            return 250, 250

    def get_emoji_counts(self, guild: discord.Guild) -> tuple[int, int]:
        static = len([e for e in guild.emojis if not e.animated])
        animated = len([e for e in guild.emojis if e.animated])
        return static, animated

    def check_emoji_space(
        self, guild: discord.Guild, is_animated: bool
    ) -> tuple[bool, int, int, int]:
        static_count, animated_count = self.get_emoji_counts(guild)
        static_limit, animated_limit = self.get_emoji_limits(guild)
        if is_animated:
            available = animated_limit - animated_count
            return available > 0, available, animated_count, animated_limit
        else:
            available = static_limit - static_count
            return available > 0, available, static_count, static_limit

    async def steal_single_emoji(
        self, ctx: commands.Context, emoji_name: str, emoji_id: int, is_animated: bool
    ) -> tuple[bool, discord.Emoji | str]:
        try:
            has_space, available, current, limit = self.check_emoji_space(ctx.guild, is_animated)
            if not has_space:
                emoji_type = "animated" if is_animated else "static"
                return False, f"no_space|{emoji_type}|{current}|{limit}"

            existing_names, existing_ids = self.get_server_emojis(ctx.guild)
            if emoji_name.lower() in existing_names:
                return False, "name_exists"
            if emoji_id in existing_ids:
                return False, "already_exists"

            extension = "gif" if is_animated else "png"
            url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{extension}?quality=lossless"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        alt_ext = "png" if is_animated else "gif"
                        url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{alt_ext}?quality=lossless"
                        async with session.get(url) as resp2:
                            if resp2.status != 200:
                                url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{extension}"
                                async with session.get(url) as resp3:
                                    if resp3.status != 200:
                                        return False, "download_failed"
                                    img_data = await resp3.read()
                            else:
                                img_data = await resp2.read()
                    else:
                        img_data = await resp.read()

            emoji = await ctx.guild.create_custom_emoji(
                name=emoji_name, image=img_data, reason=f"Stolen by {ctx.author}"
            )
            self.update_server_cache(ctx.guild)
            return True, emoji

        except discord.Forbidden:
            return False, "forbidden"
        except discord.HTTPException as e:
            return False, f"http_error|{str(e)}"
        except Exception as e:
            return False, f"error|{str(e)}"

    async def steal_bulk_emojis(
        self, ctx: commands.Context, emojis: list[tuple[str, int, bool]]
    ) -> dict[str, tuple[bool, discord.Emoji | str]]:
        results = {}
        for emoji_name, emoji_id, is_animated in emojis:
            success, result = await self.steal_single_emoji(ctx, emoji_name, emoji_id, is_animated)
            results[emoji_name] = (success, result)
        return results

    def format_steal_result(self, name: str, success: bool, result: discord.Emoji | str) -> str:
        if success:
            return f"✅ {name} → {result}"
        error = result if isinstance(result, str) else "unknown error"
        if error == "name_exists":
            return f"❌ {name} - Name already exists"
        if error == "already_exists":
            return f"❌ {name} - Already on server"
        if error.startswith("no_space"):
            parts = error.split("|")
            emoji_type, current, limit = parts[1], parts[2], parts[3]
            return f"❌ {name} - No {emoji_type} space ({current}/{limit})"
        if error == "download_failed":
            return f"❌ {name} - Download failed"
        if error == "forbidden":
            return f"❌ {name} - No permission"
        return f"❌ {name} - {error}"

    def _steal_result_card(self, title: str, results: dict, success_count: int, fail_count: int):
        body = "\n".join(
            self.format_steal_result(name, success, result)
            for name, (success, result) in results.items()
        )
        footer = f"Success: {success_count} | Failed: {fail_count}"
        if success_count > 0:
            return make_success_card(title, body, footer=footer)
        return make_error_card(title, body, footer=footer)

    @commands.command(name="steal", aliases=["st"])
    async def steal_emoji(self, ctx: commands.Context, *, emoji_input: str = None):
        """Steal emojis from a message or emoji link. Usage: .steal <emoji> or reply to a message."""
        if not ctx.author.guild_permissions.manage_emojis:
            await ctx.send(
                view=make_error_card(
                    "❌ Permission Denied",
                    "You need 'Manage Emojis' permission to use this command.",
                ),
                delete_after=5,
            )
            return

        is_limited, wait_time = self.check_rate_limit(ctx.author.id)
        if is_limited:
            await ctx.send(
                view=make_warning_card(
                    "⏳ Rate Limited",
                    f"Please wait **{wait_time}** seconds before stealing another emoji.",
                ),
                delete_after=5,
            )
            return

        if ctx.message.reference and ctx.message.reference.resolved:
            replied_message = ctx.message.reference.resolved
            emojis = self.extract_emojis_from_message(replied_message)
            source = f"from {replied_message.author}'s message"
        elif emoji_input:
            emojis = self.extract_emojis_from_message(
                discord.Message(content=emoji_input, author=ctx.author, channel=ctx.channel)
            )
            source = "from your input"
        else:
            await ctx.send(
                view=make_error_card(
                    "❌ No Emojis",
                    "Please provide an emoji or reply to a message with emojis.\n"
                    "Example: `.steal <a:emoji:123456789>`",
                ),
                delete_after=5,
            )
            return

        if not emojis:
            await ctx.send(
                view=make_error_card(
                    "❌ No Emojis", "No custom emojis found in the provided content."
                ),
                delete_after=5,
            )
            return

        results = await self.steal_bulk_emojis(ctx, emojis)
        self.user_cooldowns[ctx.author.id].append(time.time())

        success_count = sum(1 for success, _ in results.values() if success)
        fail_count = len(results) - success_count

        await ctx.send(
            view=self._steal_result_card(
                f"Emoji Stealer Results {source}", results, success_count, fail_count
            ),
            delete_after=30,
        )

    @commands.command(name="steallist", aliases=["sl"])
    async def steal_from_list(self, ctx: commands.Context, *, message_ids: str):
        """Steal emojis from multiple messages by ID. Usage: .steallist 123456789,987654321"""
        if not ctx.author.guild_permissions.manage_emojis:
            await ctx.send(
                view=make_error_card(
                    "❌ Permission Denied",
                    "You need 'Manage Emojis' permission to use this command.",
                ),
                delete_after=5,
            )
            return

        all_emojis = []
        ids = [id.strip() for id in message_ids.split(",")]
        for msg_id_str in ids:
            if not msg_id_str.isdigit():
                continue
            try:
                msg = await ctx.channel.fetch_message(int(msg_id_str))
                all_emojis.extend(self.extract_emojis_from_message(msg))
            except (discord.NotFound, discord.HTTPException):
                continue

        if not all_emojis:
            await ctx.send(
                view=make_error_card(
                    "❌ No Emojis", "No custom emojis found in the specified messages."
                ),
                delete_after=5,
            )
            return

        results = await self.steal_bulk_emojis(ctx, all_emojis)
        self.user_cooldowns[ctx.author.id].append(time.time())

        success_count = sum(1 for success, _ in results.values() if success)
        fail_count = len(results) - success_count

        await ctx.send(
            view=self._steal_result_card(
                f"Emoji Stealer Results (from {len(ids)} messages)",
                results,
                success_count,
                fail_count,
            ),
            delete_after=30,
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(EmojiStealerCog(bot))
