from __future__ import annotations

import platform
import time
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.bot import EmberBot
from core.cog import EmberCog
from core.i18n import Translator
from utils.cards import make_error_card, make_info_card
from utils.formatting import humanize_number, humanize_timedelta

_ = Translator("General", __file__)


def _info_view(
    title: str, fields: list[tuple[str, Any]], footer: str | None = None
) -> discord.ui.LayoutView:
    """Build a Components V2 info card with Section rows (label + value side-by-side)."""
    children: list[Any] = [
        discord.ui.TextDisplay(f"## {title}"),
        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
    ]
    lines = "\n".join(f"**{label}:** {value}" for label, value in fields)
    children.append(discord.ui.TextDisplay(lines))
    if footer:
        children += [
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay(f"-# {footer}"),
        ]
    container = discord.ui.Container(*children, accent_color=discord.Color.blurple())
    view = discord.ui.LayoutView(timeout=None)
    view.add_item(container)
    return view


class General(EmberCog, name="General"):
    """General-purpose utility commands."""

    info = app_commands.Group(name="info", description="Information commands")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._start_time = time.time()

    @info.command(name="ping", description="Check bot latency")
    async def ping(self, interaction: discord.Interaction) -> None:
        latency = round(self.bot.latency * 1000, 1)
        color = discord.Color.green() if latency < 200 else discord.Color.yellow()
        container = discord.ui.Container(
            discord.ui.TextDisplay("## 🏓 Pong!"),
            discord.ui.TextDisplay(f"Latency: **{latency}ms**"),
            accent_color=color,
        )
        view = discord.ui.LayoutView(timeout=None)
        view.add_item(container)
        await interaction.response.send_message(view=view)

    @info.command(name="botinfo", description="Show bot statistics")
    async def botinfo(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        bot: EmberBot = self.bot
        uptime = humanize_timedelta(int(time.time() - self._start_time))
        total_members = sum(g.member_count or 0 for g in bot.guilds)
        total_channels = sum(len(g.channels) for g in bot.guilds)
        cmd_count = len(list(bot.tree.walk_commands()))

        view = _info_view(
            f"🤖 {bot.user.name}",
            [
                ("Uptime", uptime),
                ("Latency", f"{round(bot.latency * 1000, 1)}ms"),
                ("Guilds", humanize_number(len(bot.guilds))),
                ("Users", humanize_number(total_members)),
                ("Channels", humanize_number(total_channels)),
                ("Commands", humanize_number(cmd_count)),
                ("Python", platform.python_version()),
                ("Discord.py", discord.__version__),
            ],
            footer=f"Bot ID: {bot.user.id}",
        )
        await interaction.followup.send(view=view)

    @info.command(name="userinfo", description="Show information about a user")
    @app_commands.describe(user="User to look up (default: yourself)")
    async def userinfo(
        self,
        interaction: discord.Interaction,
        user: discord.User | None = None,
    ) -> None:
        target = user or interaction.user
        member = interaction.guild.get_member(target.id) if interaction.guild else None

        fields: list[tuple[str, Any]] = [
            ("Username", f"{target.name}"),
            ("ID", target.id),
            ("Bot", "Yes" if target.bot else "No"),
        ]
        if member:
            fields.append(
                (
                    "Joined",
                    member.joined_at.strftime("%Y-%m-%d %H:%M") if member.joined_at else "Unknown",
                )
            )
            fields.append(("Created", target.created_at.strftime("%Y-%m-%d %H:%M")))
            roles = [r.mention for r in member.roles if r != interaction.guild.default_role]
            if roles:
                fields.append(
                    (
                        f"Roles ({len(roles)})",
                        ", ".join(roles[:10]) + ("…" if len(roles) > 10 else ""),
                    )
                )

        view = _info_view(
            f"👤 {target.display_name}",
            fields,
            footer=f"User ID: {target.id}",
        )
        await interaction.response.send_message(view=view)

    @info.command(name="serverinfo", description="Show information about this server")
    async def serverinfo(self, interaction: discord.Interaction) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                view=make_error_card("Not in Server", "This command can only be used in a server."),
                ephemeral=True,
            )
            return
        guild = interaction.guild
        fields: list[tuple[str, Any]] = [
            ("ID", guild.id),
            ("Owner", guild.owner.mention if guild.owner else "Unknown"),
            ("Created", guild.created_at.strftime("%Y-%m-%d %H:%M")),
            ("Members", humanize_number(guild.member_count or 0)),
            ("Channels", humanize_number(len(guild.channels))),
            ("Roles", humanize_number(len(guild.roles))),
            ("Boosts", guild.premium_subscription_count or 0),
            ("Verification Level", str(guild.verification_level)),
        ]
        if guild.features:
            fields.append(("Features", ", ".join(guild.features)))

        view = _info_view(f"🏛️ {guild.name}", fields)
        await interaction.response.send_message(view=view)

    @info.command(name="stats", description="Show command usage statistics")
    async def stats(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            view=make_info_card("📊 Stats", "Command statistics feature coming soon!"),
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(General(bot))
