from .cog import General


async def setup(bot) -> None:
    await bot.add_cog(General(bot))
