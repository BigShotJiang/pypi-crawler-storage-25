import os
import time

import discord
import psutil
from discord import ui
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n

_ = Translator("ping", __file__)

_proc = psutil.Process(os.getpid())


def _uptime(start: float) -> str:
    s = int(time.time() - start)
    parts = []
    for label, div in [("d", 86400), ("h", 3600), ("m", 60), ("s", 1)]:
        v, s = divmod(s, div)
        if v:
            parts.append(f"{v}{label}")
    return " ".join(parts) or "0s"


def _color(ms: float) -> discord.Color:
    if ms < 100:
        return EmberColors.SUCCESS
    if ms < 200:
        return EmberColors.WARNING
    if ms < 300:
        return EmberColors.WARNING
    return EmberColors.ERROR


def _emoji(ms: float) -> str:
    if ms < 100:
        return "💚"
    if ms < 200:
        return "💛"
    if ms < 300:
        return "🧡"
    return "❤️"


@cog_i18n(_)
class CutePing(EmberCog, name="Ping"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.start_time = getattr(bot, "start_time", time.time())

    @commands.command(name="ping", aliases=["pong", "latency"])
    @commands.has_permissions(manage_messages=True)
    async def ping(self, ctx: commands.Context):
        t0 = time.time()
        placeholder = await ctx.send("🏓 Pinging...")
        api_ms = round((time.time() - t0) * 1000, 2)
        ws_ms = round(self.bot.latency * 1000, 2)

        view = ui.LayoutView(timeout=None)
        view.add_item(
            ui.Container(
                ui.TextDisplay(f"## {_emoji(ws_ms)} Pong!"),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(
                    f"**WS** `{ws_ms}ms` · **API** `{api_ms}ms`\n"
                    f"**CPU** `{_proc.cpu_percent():.1f}%` · "
                    f"**RAM** `{_proc.memory_percent():.1f}%`\n"
                    f"**Uptime** `{_uptime(self.start_time)}`"
                ),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.TextDisplay(f"-# Requested by {ctx.author.display_name}"),
                accent_color=_color(ws_ms),
            )
        )

        await placeholder.delete()
        await ctx.send(view=view)


async def setup(bot):
    await bot.add_cog(CutePing(bot))
