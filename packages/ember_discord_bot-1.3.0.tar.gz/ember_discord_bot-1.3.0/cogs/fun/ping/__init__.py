from .cog import CutePing


async def setup(bot):
    await bot.add_cog(CutePing(bot))
