from .cog import BackupCog


async def setup(bot):
    """
    Set up the backup cog.

    This function is called by the bot when loading the cog.
    """
    await bot.add_cog(BackupCog(bot))
