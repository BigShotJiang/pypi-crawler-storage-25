"""AutoRestart — restarts the systemd service on fatal connection loss."""

from __future__ import annotations

import asyncio
import logging
import os
import subprocess

from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n

_ = Translator("reconnect", __file__)

log = logging.getLogger("ember.reconnect")
SERVICE_NAME = os.getenv("BOT_SERVICE_NAME", "discord-bot.service")


@cog_i18n(_)
class AutoRestart(EmberCog, name="AutoRestart"):
    """Listens for fatal connection errors and restarts the bot service."""

    async def cog_load(self):
        self.bot.loop.set_exception_handler(self._handle_exception)

    def _handle_exception(self, loop, context):
        exc = context.get("exception")
        msg = context.get("message", "")
        log.error(f"Unhandled loop exception: {exc or msg}")
        if self._is_fatal(exc or msg):
            asyncio.ensure_future(self._restart())

    @staticmethod
    def _is_fatal(exc) -> bool:
        indicators = [
            "Cannot connect to host",
            "name resolution",
            "ClientConnectorError",
            "ConnectionResetError",
        ]
        s = str(exc).lower()
        return any(i.lower() in s for i in indicators)

    async def _restart(self):
        await asyncio.sleep(3)
        log.warning(f"Restarting service: {SERVICE_NAME}")
        try:
            subprocess.Popen(
                ["sudo", "/usr/bin/systemctl", "restart", SERVICE_NAME],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception as e:
            log.error(f"Failed to trigger restart: {e}")

    @commands.Cog.listener()
    async def on_disconnect(self):
        log.warning("Bot disconnected — waiting to see if it reconnects")

    @commands.Cog.listener()
    async def on_resumed(self):
        log.info("Session resumed")

    @commands.command(name="restart", hidden=True)
    @commands.is_owner()
    async def restart_cmd(self, ctx: commands.Context):
        await ctx.send("Restarting bot service...")
        await asyncio.sleep(1)
        await self._restart()


async def setup(bot):
    await bot.add_cog(AutoRestart(bot))
