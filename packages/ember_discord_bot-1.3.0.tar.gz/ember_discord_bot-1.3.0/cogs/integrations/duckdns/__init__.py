from .cog import DuckDNSCog


async def setup(bot):
    await bot.add_cog(DuckDNSCog(bot))
