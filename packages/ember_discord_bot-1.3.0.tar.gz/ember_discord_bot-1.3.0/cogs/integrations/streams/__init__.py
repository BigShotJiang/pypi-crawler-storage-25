from .cog import Streams


async def setup(bot) -> None:
    await bot.add_cog(Streams(bot))
