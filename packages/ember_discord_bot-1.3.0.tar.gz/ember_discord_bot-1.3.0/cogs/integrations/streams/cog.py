"""Stream alerts cog — Twitch live notifications with per-guild channel config."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from utils.cards import make_error_card, make_info_card, make_success_card, make_warning_card
from utils.feature_registry import ConfigField, FieldType, feature

log = logging.getLogger("ember.streams")

TWITCH_API = "https://api.twitch.tv/helix"
TWITCH_AUTH = "https://id.twitch.tv/oauth2/token"

_POLL_INTERVAL = 120  # seconds between checks


@feature(
    display_name="Stream Alerts",
    emoji="📡",
    description="Twitch live notifications posted to a configured channel.",
    fields=[
        ConfigField(
            "alert_channel_id",
            "Alert Channel",
            FieldType.CHANNEL,
            required=True,
            description="Channel where live alerts are posted.",
        ),
        ConfigField("enabled", "Enabled", FieldType.BOOLEAN, default=True),
    ],
)
class Streams(EmberCog, name="Streams"):
    """Track Twitch streamers and post live alerts to a configured channel."""

    streams = app_commands.Group(name="streams", description="Stream integration commands")

    def __init__(self, bot: commands.Bot) -> None:
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "enabled": True,
                    "watched": [],
                    "alert_channel_id": None,
                },
            }
        )
        self._session: aiohttp.ClientSession | None = None
        self._access_token: str | None = None
        self._token_expires: float = 0.0
        # guild_id -> set of watched usernames (lowercase)
        self._cache: dict[int, set[str]] = {}
        # username -> bool (currently live)
        self._live: dict[str, bool] = {}

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)
        self._session = aiohttp.ClientSession()
        self.poll_streams.start()

    async def cog_unload(self) -> None:
        self.poll_streams.cancel()
        if self._session:
            await self._session.close()

    # ── Twitch auth ────────────────────────────────────────────────────────────

    async def _get_credentials(self) -> tuple[str, str] | None:
        """Return (client_id, client_secret) from stored tokens."""
        try:
            from core.api_tokens import get_manager

            mgr = get_manager()
            client_id = await mgr.get_token("streams", "TWITCH_CLIENT_ID")
            client_secret = await mgr.get_token("streams", "TWITCH_CLIENT_SECRET")
            if client_id and client_secret:
                return client_id, client_secret
        except Exception:
            pass
        return None

    async def _ensure_token(self) -> bool:
        now = datetime.now(UTC).timestamp()
        if self._access_token and now < self._token_expires - 60:
            return True

        creds = await self._get_credentials()
        if not creds:
            return False

        client_id, client_secret = creds
        try:
            async with self._session.post(
                TWITCH_AUTH,
                params={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "grant_type": "client_credentials",
                },
            ) as resp:
                if resp.status != 200:
                    return False
                data = await resp.json()
                self._access_token = data["access_token"]
                self._token_expires = now + data["expires_in"]
                return True
        except Exception as exc:
            log.error("Twitch auth error: %s", exc)
            return False

    async def _fetch_streams(self, usernames: list[str]) -> list[dict[str, Any]]:
        if not await self._ensure_token():
            return []
        creds = await self._get_credentials()
        if not creds:
            return []
        client_id = creds[0]
        params = [("user_login", u) for u in usernames]
        try:
            async with self._session.get(
                f"{TWITCH_API}/streams",
                params=params,
                headers={
                    "Client-ID": client_id,
                    "Authorization": f"Bearer {self._access_token}",
                },
            ) as resp:
                if resp.status != 200:
                    return []
                return (await resp.json()).get("data", [])
        except Exception as exc:
            log.error("Twitch stream fetch error: %s", exc)
            return []

    # ── Poll task ──────────────────────────────────────────────────────────────

    @tasks.loop(seconds=_POLL_INTERVAL)
    async def poll_streams(self) -> None:
        # Collect all watched usernames across all guilds
        all_usernames: set[str] = set()
        for guild_id in list(self._cache.keys()):
            cfg = await self.db.get_all("guild", guild_id)
            stored = cfg.get("watched", [])
            self._cache[guild_id] = set(stored)
            all_usernames.update(self._cache[guild_id])

        if not all_usernames:
            return

        live_now = await self._fetch_streams(list(all_usernames))
        live_usernames = {s["user_login"].lower() for s in live_now}
        live_data = {s["user_login"].lower(): s for s in live_now}

        for username in all_usernames:
            was_live = self._live.get(username, False)
            is_live = username in live_usernames

            if is_live and not was_live:
                # Went live — post alert to all guilds watching this streamer
                await self._post_live_alert(username, live_data[username])

            self._live[username] = is_live

    @poll_streams.before_loop
    async def before_poll(self) -> None:
        await self.bot.wait_until_ready()
        # Pre-load watched lists from all guilds
        for guild in self.bot.guilds:
            cfg = await self.db.get_all("guild", guild.id)
            stored = cfg.get("watched", [])
            self._cache[guild.id] = set(stored)

    async def _post_live_alert(self, username: str, stream: dict[str, Any]) -> None:
        title = stream.get("title", "")
        game = stream.get("game_name", "")
        viewers = stream.get("viewer_count", 0)
        url = f"https://twitch.tv/{username}"

        for guild in self.bot.guilds:
            watched = self._cache.get(guild.id, set())
            if username not in watched:
                continue
            cfg = await self.db.get_all("guild", guild.id)
            if not cfg.get("enabled", True):
                continue
            channel_id = cfg.get("alert_channel_id")
            if not channel_id:
                continue
            channel = guild.get_channel(channel_id)
            if not channel:
                continue
            try:
                view = discord.ui.LayoutView(timeout=None)
                view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay(f"## 🔴 {username} is live!"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            f"**{title}**\n" f"🎮 {game}\n" f"👥 {viewers:,} viewers\n" f"📺 {url}"
                        ),
                        accent_color=discord.Color.from_str("#9146FF"),
                    )
                )
                await channel.send(view=view)
            except Exception as exc:
                log.warning(
                    "Failed to post stream alert for %s in guild %d: %s", username, guild.id, exc
                )

    # ── Commands ───────────────────────────────────────────────────────────────

    @streams.command(name="stream_add", description="Add a Twitch streamer to watch")
    @app_commands.describe(username="Twitch username to watch")
    @app_commands.default_permissions(manage_guild=True)
    async def stream_add(self, interaction: discord.Interaction, username: str) -> None:
        await interaction.response.defer(ephemeral=True)
        username = username.lower().strip()
        cfg = await self.db.get_all("guild", interaction.guild.id)
        watched: list[str] = cfg.get("watched", [])
        if username in watched:
            await interaction.followup.send(
                view=make_warning_card(
                    "⚠️ Already Watching", f"`{username}` is already on the watch list."
                ),
                ephemeral=True,
            )
            return
        watched.append(username)
        await self.db.set("guild", interaction.guild.id, "watched", watched)
        self._cache.setdefault(interaction.guild.id, set()).add(username)
        await interaction.followup.send(
            view=make_success_card("✅ Added", f"Now watching **{username}** on Twitch."),
            ephemeral=True,
        )

    @streams.command(
        name="stream_remove", description="Remove a Twitch streamer from the watch list"
    )
    @app_commands.describe(username="Twitch username to remove")
    @app_commands.default_permissions(manage_guild=True)
    async def stream_remove(self, interaction: discord.Interaction, username: str) -> None:
        await interaction.response.defer(ephemeral=True)
        username = username.lower().strip()
        cfg = await self.db.get_all("guild", interaction.guild.id)
        watched: list[str] = cfg.get("watched", [])
        if username not in watched:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"`{username}` is not being watched."),
                ephemeral=True,
            )
            return
        watched.remove(username)
        await self.db.set("guild", interaction.guild.id, "watched", watched)
        self._cache.get(interaction.guild.id, set()).discard(username)
        await interaction.followup.send(
            view=make_success_card("✅ Removed", f"No longer watching **{username}**."),
            ephemeral=True,
        )

    @streams.command(name="stream_list", description="List all watched streamers")
    async def stream_list(self, interaction: discord.Interaction) -> None:
        cfg = await self.db.get_all("guild", interaction.guild.id)
        watched: list[str] = cfg.get("watched", [])
        if not watched:
            await interaction.response.send_message(
                view=make_info_card("📋 Streams", "No streamers configured yet."),
                ephemeral=True,
            )
            return
        live = {u for u, v in self._live.items() if v}
        lines = [f"{'🔴' if u in live else '⚫'} {u}" for u in sorted(watched)]
        await interaction.response.send_message(
            view=make_info_card(f"📋 Watched Streams ({len(lines)})", "\n".join(lines)),
            ephemeral=True,
        )

    @streams.command(name="stream_channel", description="Set the channel for live alerts")
    @app_commands.describe(channel="Channel to post alerts in")
    @app_commands.default_permissions(manage_guild=True)
    async def stream_channel(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
    ) -> None:
        await self.db.set("guild", interaction.guild.id, "alert_channel_id", channel.id)
        await interaction.response.send_message(
            view=make_success_card(
                "✅ Channel Set", f"Live alerts will post to {channel.mention}."
            ),
            ephemeral=True,
        )

    @streams.command(
        name="stream_check", description="Manually check if a streamer is live right now"
    )
    @app_commands.describe(username="Twitch username to check")
    async def stream_check(self, interaction: discord.Interaction, username: str) -> None:
        await interaction.response.defer(ephemeral=True)
        username = username.lower().strip()
        data = await self._fetch_streams([username])
        if not data:
            await interaction.followup.send(
                view=make_info_card(f"⚫ {username}", "Not currently live."),
                ephemeral=True,
            )
            return
        stream = data[0]
        body = (
            f"**{stream.get('title', '—')}**\n"
            f"🎮 {stream.get('game_name', '—')}\n"
            f"👥 {stream.get('viewer_count', 0):,} viewers\n"
            f"📺 https://twitch.tv/{username}"
        )
        await interaction.followup.send(
            view=make_info_card(f"🔴 {username} is LIVE", body),
            ephemeral=True,
        )

    # ── GDPR ───────────────────────────────────────────────────────────────────

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        return {}

    async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        return {}


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Streams(bot))
