from .cog import Bank


async def setup(bot) -> None:
    await bot.add_cog(Bank(bot))
