from typing import TypedDict


class UserMediaGuildConfig(TypedDict, total=False):
    """Guild-level usermedia configuration."""

    cooldown_seconds: int
    enabled: bool
