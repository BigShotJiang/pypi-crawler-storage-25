"""User media viewer — avatars and banners with privacy-aware responses."""

from __future__ import annotations

import logging
import time

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator
from utils.cards import make_error_card
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import UserMediaGuildConfig

_ = Translator("user_media", __file__)
log = logging.getLogger("ember.user_media")


@feature(
    display_name="User Media",
    description="Shows user avatars and banners with privacy-aware responses.",
    emoji="👤",
    fields=[
        ConfigField(
            key="enabled",
            label="Enable Commands",
            type=FieldType.BOOLEAN,
            description="Whether avatar/banner commands are enabled in this server.",
            required=True,
            default=True,
        ),
        ConfigField(
            key="cooldown_seconds",
            label="Cooldown (seconds)",
            type=FieldType.INTEGER,
            description="Rate limit per user for avatar/banner commands.",
            required=True,
            default=10,
            min_value=1,
            max_value=3600,
        ),
    ],
)
class UserMedia(EmberCog, name="User Media"):
    """Show user avatars and banners with privacy-aware responses."""

    usermedia = app_commands.Group(name="usermedia", description="User media commands")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.register_schema("guild", UserMediaGuildConfig)
        self.db.defaults(
            {
                "guild": {"enabled": True, "cooldown_seconds": 10},
            }
        )
        self.db.defaults(
            {
                "global": {"cooldown_seconds": 10},
            }
        )
        self._last_used: dict[int, float] = {}

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        await super().cog_unload()

    async def _get_cooldown_seconds(self, guild_id: int | None) -> int:
        if guild_id is not None:
            return await self.db.get("guild", guild_id, "cooldown_seconds")
        return await self.db.get("global", 0, "cooldown_seconds")

    def _prune_last_used(self) -> None:
        now = time.time()
        if len(self._last_used) > 5000:
            cutoff = now - 3600
            self._last_used = {uid: ts for uid, ts in self._last_used.items() if ts > cutoff}

    def _make_media_items(
        self,
        fetched_user: discord.User,
        member: discord.Member | None,
        kind: str,
    ) -> list[discord.MediaGalleryItem]:
        """
        Always receives:
          fetched_user — a discord.User from fetch_user(), guaranteed to have .banner
          member       — discord.Member if the target is in the guild (for guild_avatar), else None
        """
        items: list[discord.MediaGalleryItem] = []

        if kind == "avatar":
            global_asset = fetched_user.avatar or fetched_user.default_avatar
            if global_asset:
                items.append(
                    discord.MediaGalleryItem(media=global_asset.url, description="Global Avatar")
                )
            # Guild avatar lives on the Member object only
            if member is not None and member.guild_avatar:
                if global_asset and member.guild_avatar.url != global_asset.url:
                    items.append(
                        discord.MediaGalleryItem(
                            media=member.guild_avatar.url, description="Guild Avatar"
                        )
                    )

        elif kind == "banner":
            # .banner only exists (and is populated) on discord.User from fetch_user()
            if fetched_user.banner:
                items.append(
                    discord.MediaGalleryItem(media=fetched_user.banner.url, description="Banner")
                )

        return items

    def _make_ephemeral_view(
        self,
        fetched_user: discord.User,
        member: discord.Member | None,
        kind: str,
    ) -> discord.ui.LayoutView:
        display_name = member.display_name if member else fetched_user.display_name
        title = f"{display_name}'s {kind.title()}"
        media_items = self._make_media_items(fetched_user, member, kind)

        children: list = [
            discord.ui.TextDisplay(f"## {title}"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
        ]

        if not media_items:
            children.append(discord.ui.TextDisplay(f"No {kind} available."))
        else:
            children.append(discord.ui.MediaGallery(*media_items))

        # Add "Open in Browser" button
        buttons = []
        if kind == "avatar":
            display_avatar = member.display_avatar if member else fetched_user.display_avatar
            if display_avatar:
                buttons.append(
                    discord.ui.Button(
                        label="Open in Browser",
                        style=discord.ButtonStyle.link,
                        url=display_avatar.url,
                        emoji="🔗",
                    )
                )
        elif kind == "banner":
            if fetched_user.banner:
                buttons.append(
                    discord.ui.Button(
                        label="Open in Browser",
                        style=discord.ButtonStyle.link,
                        url=fetched_user.banner.url,
                        emoji="🔗",
                    )
                )

        if buttons:
            children.append(discord.ui.Separator(spacing=discord.SeparatorSpacing.small))
            children.append(discord.ui.ActionRow(*buttons))

        container = discord.ui.Container(*children, accent_color=discord.Color.blurple())
        view = discord.ui.LayoutView(timeout=60)
        view.add_item(container)
        return view

    def _ephemeral_callback(
        self,
        fetched_user: discord.User,
        member: discord.Member | None,
        kind: str,
    ):
        async def callback(interaction: discord.Interaction):
            await interaction.response.send_message(
                view=self._make_ephemeral_view(fetched_user, member, kind),
                ephemeral=True,
            )

        return callback

    def _make_main_view(
        self,
        fetched_user: discord.User,
        member: discord.Member | None,
        kind: str,
        is_self: bool,
    ) -> discord.ui.LayoutView:
        display_name = member.display_name if member else fetched_user.display_name
        title = f"{display_name}'s {kind.title()}"

        children: list = [
            discord.ui.TextDisplay(f"## {title}"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
        ]

        media_items = self._make_media_items(fetched_user, member, kind)

        if not is_self:
            children.append(
                discord.ui.TextDisplay(
                    f"-# {display_name}'s {kind} is not for the public eye, use the buttons below."
                )
            )

        # Only show the gallery inline when viewing your own media
        if is_self and media_items:
            children.append(discord.ui.MediaGallery(*media_items))

        buttons = []

        # Open-in-browser link button (only for self — other users use the ephemeral view)
        if is_self:
            if kind == "avatar":
                display_avatar = member.display_avatar if member else fetched_user.display_avatar
                if display_avatar:
                    buttons.append(
                        discord.ui.Button(
                            label="Open in Browser",
                            style=discord.ButtonStyle.link,
                            url=display_avatar.url,
                            emoji="🔗",
                        )
                    )
            elif kind == "banner":
                if fetched_user.banner:
                    buttons.append(
                        discord.ui.Button(
                            label="Open in Browser",
                            style=discord.ButtonStyle.link,
                            url=fetched_user.banner.url,
                            emoji="🔗",
                        )
                    )

        # "View X" ephemeral button — only for other users
        if media_items and not is_self:
            view_btn = discord.ui.Button(
                label=f"View {kind.title()}",
                style=discord.ButtonStyle.primary,
                emoji="👁️",
            )
            view_btn.callback = self._ephemeral_callback(fetched_user, member, kind)
            buttons.append(view_btn)

        # Cross-link: viewing avatar → offer banner, and vice versa
        if kind == "avatar" and fetched_user.banner:
            banner_btn = discord.ui.Button(
                label="View Banner",
                style=discord.ButtonStyle.secondary,
                emoji="🖼️",
            )
            banner_btn.callback = self._ephemeral_callback(fetched_user, member, "banner")
            buttons.append(banner_btn)
        elif kind == "banner":
            avatar_btn = discord.ui.Button(
                label="View Avatar",
                style=discord.ButtonStyle.secondary,
                emoji="👤",
            )
            avatar_btn.callback = self._ephemeral_callback(fetched_user, member, "avatar")
            buttons.append(avatar_btn)

        if buttons:
            children.append(discord.ui.Separator(spacing=discord.SeparatorSpacing.small))

        if buttons:
            children.append(discord.ui.ActionRow(*buttons))

        container = discord.ui.Container(*children, accent_color=discord.Color.blurple())
        view = discord.ui.LayoutView(timeout=180 if is_self else 60)
        view.add_item(container)
        return view

    async def _handle_command(
        self,
        interaction: discord.Interaction | None,
        ctx: commands.Context | None,
        user: discord.User | None,
        kind: str,
    ) -> None:
        if interaction:
            invoker = interaction.user
            guild = interaction.guild
            guild_id = interaction.guild_id
            raw_target = user or interaction.user
        else:
            invoker = ctx.author
            guild = ctx.guild
            guild_id = ctx.guild.id if ctx.guild else None
            raw_target = user or ctx.author

        async def reply_error(msg: str) -> None:
            view = make_error_card("❌ Error", msg)
            if interaction:
                if interaction.response.is_done():
                    await interaction.followup.send(view=view, ephemeral=True)
                else:
                    await interaction.response.send_message(view=view, ephemeral=True)
            else:
                await ctx.send(view=view)

        # Always fetch the full User object — this is the only source of .banner
        try:
            fetched_user: discord.User = await self.bot.fetch_user(raw_target.id)
        except discord.NotFound:
            await reply_error("User not found.")
            return

        # Early-exit if the requested media simply doesn't exist
        if kind == "banner" and not fetched_user.banner:
            await reply_error(f"{fetched_user.name} does not have a banner.")
            return

        if kind == "avatar" and not (fetched_user.avatar or fetched_user.default_avatar):
            await reply_error(f"{fetched_user.name} does not have an avatar.")
            return

        # Guild enabled check
        if guild_id:
            cfg = await self.db.get_all("guild", guild_id)
            if not cfg.get("enabled", True):
                await reply_error("This command is disabled in this server.")
                return

        # Defer only now — after all cheap early-exit checks pass
        if interaction:
            await interaction.response.defer()

        # Resolve Member for guild-specific attributes (guild_avatar, display_name)
        # This is SEPARATE from fetched_user and never used as the banner source
        member: discord.Member | None = None
        if guild:
            member = guild.get_member(fetched_user.id)

        # Cooldown
        cooldown = await self._get_cooldown_seconds(guild_id)
        now = time.time()
        if now - self._last_used.get(invoker.id, 0) < cooldown:
            return
        self._last_used[invoker.id] = now
        self._prune_last_used()

        is_self = invoker.id == fetched_user.id
        view = self._make_main_view(fetched_user, member, kind, is_self=is_self)

        if interaction:
            await interaction.followup.send(view=view)
        else:
            await ctx.reply(view=view, mention_author=True)

    # ── Slash Commands ──────────────────────────────────────────────────────

    @usermedia.command(name="avatar", description="Show a user's avatar")
    @app_commands.describe(user="User to show avatar for (default: yourself)")
    async def avatar_slash(
        self, interaction: discord.Interaction, user: discord.User | None = None
    ) -> None:
        await self._handle_command(interaction, None, user, "avatar")

    @usermedia.command(name="banner", description="Show a user's banner")
    @app_commands.describe(user="User to show banner for (default: yourself)")
    async def banner_slash(
        self, interaction: discord.Interaction, user: discord.User | None = None
    ) -> None:
        await self._handle_command(interaction, None, user, "banner")

    # ── Prefix Commands ─────────────────────────────────────────────────────

    @commands.command(name="avatar", aliases=["av"])
    async def avatar_prefix(self, ctx: commands.Context, user: discord.User | None = None) -> None:
        await self._handle_command(None, ctx, user, "avatar")

    @commands.command(name="banner", aliases=["b"])
    async def banner_prefix(
        self, ctx: commands.Context, *, user: discord.Member | None = None
    ) -> None:
        await self._handle_command(None, ctx, user, "banner")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(UserMedia(bot))
