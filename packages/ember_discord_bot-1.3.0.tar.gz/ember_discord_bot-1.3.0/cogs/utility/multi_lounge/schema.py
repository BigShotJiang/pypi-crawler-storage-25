from typing import TypedDict


class MultiLoungeGuildConfig(TypedDict, total=False):
    """Guild-level multi_lounge configuration."""

    enabled: bool
