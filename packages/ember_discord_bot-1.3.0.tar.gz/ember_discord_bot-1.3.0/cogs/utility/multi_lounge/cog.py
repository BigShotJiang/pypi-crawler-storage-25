"""MultiLoungeCog — headless smart lounge manager.

Monitors a voice channel category and auto-creates/deletes overflow lounges
based on occupancy. All names and IDs are configured via env vars.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import MultiLoungeGuildConfig

_ = Translator("multi_lounge", __file__)

log = logging.getLogger("ember.multi_lounge")

_NUMBER_RE = re.compile(r"(\d+)", re.IGNORECASE)


def _get_number(name: str) -> int:
    m = _NUMBER_RE.search(name)
    return int(m.group(1)) if m else 0


def _user_limit_for(number: int) -> int:
    """Graduated user caps: unlimited for first two, then decreasing."""
    if number <= 2:
        return 0
    if number <= 4:
        return 8
    if number <= 6:
        return 7
    return 6


@cog_i18n(_)
@feature(
    display_name="Multi Lounge",
    description="Auto-creates overflow lounge voice channels when the main lounge is busy.",
    emoji="🎙️",
    fields=[
        ConfigField(
            key="base_channel_id",
            label="Base Lounge Channel",
            type=FieldType.CHANNEL,
            required=True,
            description="The primary lounge voice channel to monitor.",
        ),
        ConfigField(
            key="busy_threshold",
            label="Busy Threshold",
            type=FieldType.INTEGER,
            placeholder="2",
            default=2,
            description="Members needed in a lounge before a new one is created.",
        ),
        ConfigField(
            key="creation_cooldown",
            label="Creation Cooldown (s)",
            type=FieldType.INTEGER,
            placeholder="10",
            default=10,
            description="Seconds between lounge creations.",
        ),
        ConfigField(
            key="name_format",
            label="Lounge Name Format",
            type=FieldType.STRING,
            placeholder="lounge {}",
            default="lounge {}",
            description="Name template — {} is replaced with the lounge number.",
        ),
    ],
)
class MultiLoungeCog(EmberCog, name="MultiLounge"):
    """Headless cog that auto-manages overflow voice lounges."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "enabled": True,
                    "base_channel_id": None,
                    "busy_threshold": 2,
                    "creation_cooldown": 10,
                    "name_format": "lounge {}",
                },
            }
        )
        self._last_creation: dict[int, float] = {}  # keyed by guild_id
        self._next_run: dict[int, float] = {}
        self._creation_lock = asyncio.Lock()
        self._deletion_lock = asyncio.Lock()
        self.db.register_schema("guild", MultiLoungeGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    async def _get_state(self, guild_id: int, base_channel_id: int | None = None):
        if base_channel_id is None:
            cfg = await self.db.guild(guild_id).all()
            base_channel_id = cfg.get("base_channel_id")
        if not base_channel_id:
            return None, []
        base = self.bot.get_channel(base_channel_id)
        if not base or not base.category:
            return None, []

        category = base.category
        lounges = []

        for ch in category.voice_channels:
            n = _get_number(ch.name)
            if n > 0:
                lounges.append({"num": n, "channel": ch, "count": len(ch.members)})

        lounges.sort(key=lambda x: x["num"])
        return category, lounges

    async def _create_lounge(
        self, category: discord.CategoryChannel, number: int, position: int, name_format: str
    ) -> bool:
        name = name_format.format(number)
        limit = _user_limit_for(number)
        try:
            await category.create_voice_channel(
                name=name,
                position=position,
                user_limit=limit,
                reason=f"MultiLounge: created lounge {number}",
            )
            log.info("Created %s (cap=%d)", name, limit)
            return True
        except (discord.Forbidden, discord.HTTPException) as e:
            log.error("Failed to create lounge %d: %s", number, e)
            return False

    async def _delete_lounge(self, channel: discord.VoiceChannel) -> bool:
        try:
            if len(channel.members) > 0:
                return False
            await channel.delete(reason="MultiLounge: excess empty lounge")
            log.info("Deleted %s", channel.name)
            return True
        except discord.NotFound:
            return False
        except (discord.Forbidden, discord.HTTPException) as e:
            log.error("Failed to delete %s: %s", channel.name, e)
            return False

    async def _fix_gaps(self, lounges: list, name_format: str):
        for i, lounge in enumerate(lounges, start=1):
            expected_name = name_format.format(i)
            expected_limit = _user_limit_for(i)
            ch = lounge["channel"]
            if ch.name != expected_name or ch.user_limit != expected_limit:
                try:
                    await ch.edit(
                        name=expected_name,
                        user_limit=expected_limit,
                        reason=f"MultiLounge: fix lounge {i}",
                    )
                except (discord.Forbidden, discord.HTTPException):
                    pass

    async def _manage(self, guild_id: int):
        cfg = await self.db.guild(guild_id).all()
        busy_threshold = cfg.get("busy_threshold", 2)
        creation_cooldown = cfg.get("creation_cooldown", 10)
        name_format = cfg.get("name_format", "lounge {}")

        category, lounges = await self._get_state(guild_id, cfg.get("base_channel_id"))
        if not category or not lounges:
            return

        all_busy = all(lo["count"] >= busy_threshold for lo in lounges)
        now = time.time()
        last_creation = self._last_creation.get(guild_id, 0.0)

        if all_busy and (now - last_creation) >= creation_cooldown:
            async with self._creation_lock:
                category, lounges = await self._get_state(guild_id)
                if not lounges:
                    return
                if all(lo["count"] >= busy_threshold for lo in lounges):
                    highest = lounges[-1]
                    try:
                        fresh = await self.bot.fetch_channel(highest["channel"].id)
                        pos = fresh.position
                    except Exception:
                        pos = highest["channel"].position
                    ok = await self._create_lounge(category, highest["num"] + 1, pos, name_format)
                    if ok:
                        self._last_creation[guild_id] = time.time()
            return

        spares = [lo for lo in lounges if lo["count"] == 0 and lo["num"] > 1]
        if len(spares) > 1:
            async with self._deletion_lock:
                category, lounges = await self._get_state(guild_id)
                spares = sorted(
                    [lo for lo in lounges if lo["count"] == 0 and lo["num"] > 1],
                    key=lambda x: x["num"],
                )
                for spare in spares[1:]:
                    await self._delete_lounge(spare["channel"])
                    await asyncio.sleep(5)
            category, lounges = await self._get_state(guild_id)

        await self._fix_gaps(lounges, name_format)

    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ):
        if before.channel == after.channel:
            return

        guild_id = member.guild.id
        cfg = await self.db.guild(guild_id).all()
        if not cfg.get("enabled", True):
            return
        base_channel_id = cfg.get("base_channel_id")
        if not base_channel_id:
            return

        base = self.bot.get_channel(base_channel_id)
        if not base or not base.category:
            return

        cat_id = base.category.id
        relevant = (before.channel and before.channel.category_id == cat_id) or (
            after.channel and after.channel.category_id == cat_id
        )
        if not relevant:
            return

        now = time.time()
        if now < self._next_run.get(guild_id, 0.0):
            return
        self._next_run[guild_id] = now + 1

        asyncio.create_task(self._manage(guild_id))

    lounge_group = app_commands.Group(
        name="lounge", description="Lounge management commands", guild_only=True
    )

    @lounge_group.command(name="stats", description="Show lounge system status")
    @app_commands.default_permissions(manage_channels=True)
    async def lounge_stats(self, interaction: discord.Interaction):
        guild_id = interaction.guild_id
        cfg = await self.db.guild(guild_id).all()
        category, lounges = await self._get_state(guild_id, cfg.get("base_channel_id"))
        if not category or not lounges:
            return await self.send_warning(
                interaction,
                "MultiLounge is not configured or no numbered lounges were found.",
                title="⚙️ Not Configured",
            )

        busy_threshold = cfg.get("busy_threshold", 2)
        total = sum(lo["count"] for lo in lounges)
        lines = "\n".join(
            f"**L{lo['num']}** — {lo['count']}/{lo['channel'].user_limit or '∞'} users  `{lo['channel'].name}`"
            for lo in lounges
        )
        body = f"{lines}\n-# Total users: {total} | Busy threshold: {busy_threshold}"
        await self.send_info(interaction, body, title=f"🎙️ Lounges — {category.name}")


async def setup(bot):
    await bot.add_cog(MultiLoungeCog(bot))
