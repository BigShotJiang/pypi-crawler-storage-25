from .cog import MultiLoungeCog


async def setup(bot):
    await bot.add_cog(MultiLoungeCog(bot))
