from typing import TypedDict


class NickGuildConfig(TypedDict, total=False):
    """Guild-level nick configuration."""

    enabled: bool
