from .cog import NicknameChanger


async def setup(bot):
    await bot.add_cog(NicknameChanger(bot))
