"""NicknameChanger — hierarchy-aware `.nick` command."""

from __future__ import annotations

import asyncio

import discord
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import NickGuildConfig

_ = Translator("nick", __file__)

_DANGEROUS_PERMS = {
    "administrator",
    "manage_guild",
    "manage_roles",
    "manage_channels",
    "manage_webhooks",
}
_LEVEL_NAMES = {3: "Moderator", 2: "Helper", 1: "Chat Manager", 0: "Member"}


@cog_i18n(_)
@feature(
    display_name="Nickname Manager",
    description="Hierarchy-aware `.nick` command for staff to change member nicknames safely.",
    emoji="✏️",
    fields=[
        ConfigField(
            key="mod_role_id",
            label="Moderator Role",
            type=FieldType.ROLE,
            description="Role with level-3 nickname permissions.",
        ),
        ConfigField(
            key="helper_role_id",
            label="Helper Role",
            type=FieldType.ROLE,
            description="Role with level-2 nickname permissions.",
        ),
        ConfigField(
            key="chat_manager_role_id",
            label="Chat Manager Role",
            type=FieldType.ROLE,
            description="Role with level-1 nickname permissions.",
        ),
    ],
)
class NicknameChanger(EmberCog, name="NicknameChanger"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "mod_role_id": None,
                    "helper_role_id": None,
                    "chat_manager_role_id": None,
                },
            }
        )
        self.db.register_schema("guild", NickGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    async def _level(self, member: discord.Member) -> int:
        cfg = await self.db.get_all("guild", member.guild.id)
        ids = {r.id for r in member.roles}
        mod_id = cfg.get("mod_role_id")
        if mod_id and mod_id in ids:
            return 3
        helper_id = cfg.get("helper_role_id")
        if helper_id and helper_id in ids:
            return 2
        cm_id = cfg.get("chat_manager_role_id")
        if cm_id and cm_id in ids:
            return 1
        return 0

    def _has_dangerous(self, member: discord.Member) -> bool:
        perms = member.guild_permissions
        return any(getattr(perms, p, False) for p in _DANGEROUS_PERMS)

    async def _can_change(
        self, executor: discord.Member, target: discord.Member
    ) -> tuple[bool, str]:
        if target.bot:
            return False, "❌ Can't change a bot's nickname."
        if target == executor:
            return False, "⚠️ Can't change your own nickname with this command."

        exe_lvl = await self._level(executor)
        tgt_lvl = await self._level(target)

        if executor.guild_permissions.administrator:
            if target.guild_permissions.administrator:
                return False, "❌ Can't change another administrator's nickname."
            return True, ""

        if exe_lvl == 0:
            return False, "🚫 You don't have permission to use this command."

        if tgt_lvl > 0:
            if tgt_lvl == exe_lvl:
                return (
                    False,
                    f"❌ Can't change another {_LEVEL_NAMES[tgt_lvl]}'s nickname (same level).",
                )
            if tgt_lvl > exe_lvl:
                return False, f"❌ Can't change a {_LEVEL_NAMES[tgt_lvl]}'s nickname."

        if self._has_dangerous(target):
            return False, "❌ Can't change the nickname of someone with manage permissions."

        return True, ""

    async def _temp(self, ctx: commands.Context, view: discord.ui.LayoutView, delay: int = 3):
        msg = await ctx.reply(view=view, mention_author=False)
        await asyncio.sleep(delay)
        try:
            await msg.delete()
        except (discord.NotFound, discord.Forbidden):
            pass

    @commands.command(name="nick")
    @commands.guild_only()
    async def nick(self, ctx: commands.Context, member: discord.Member, *, new_nick: str = None):
        ok, reason = await self._can_change(ctx.author, member)
        if not ok:
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(discord.ui.TextDisplay(reason), accent_color=EmberColors.ERROR)
            )
            await self._temp(ctx, view)
            return

        if member.top_role.position >= ctx.guild.me.top_role.position:
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay(
                        "❌ Can't change nickname of someone equal to or above my role."
                    ),
                    accent_color=EmberColors.ERROR,
                )
            )
            await self._temp(ctx, view)
            return

        try:
            old = member.nick or member.name
            await member.edit(nick=new_nick)
            desc = (
                f"**{old}** → **{new_nick}**"
                if new_nick
                else f"**{old}**'s nickname reset to username."
            )
            title_text = "✅ Nickname Changed" if new_nick else "✅ Nickname Reset"
            lvl = await self._level(ctx.author)
            role_name = (
                "Administrator" if ctx.author.guild_permissions.administrator else _LEVEL_NAMES[lvl]
            )
            children = [
                discord.ui.TextDisplay(f"## {title_text}"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(desc),
                discord.ui.TextDisplay(f"-# Changed by {ctx.author} ({role_name})"),
            ]
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(discord.ui.Container(*children, accent_color=EmberColors.SUCCESS))
            await self._temp(ctx, view)
        except discord.Forbidden:
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("❌ Missing permissions to change that nickname."),
                    accent_color=EmberColors.ERROR,
                )
            )
            await self._temp(ctx, view)

    @nick.error
    async def nick_error(self, ctx: commands.Context, error):
        if isinstance(error, commands.MissingRequiredArgument):
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("❗ Usage: `.nick @user [new_nick]`"),
                    accent_color=EmberColors.WARNING,
                )
            )
            await self._temp(ctx, view)
        elif isinstance(error, commands.BadArgument):
            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("❗ Couldn't find that user."),
                    accent_color=EmberColors.WARNING,
                )
            )
            await self._temp(ctx, view)


async def setup(bot):
    await bot.add_cog(NicknameChanger(bot))
