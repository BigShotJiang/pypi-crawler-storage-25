"""Alias cog — user-defined shortcuts for prefix commands.

Users can register custom names that expand to existing prefix commands,
optionally with preset arguments. Inspired by Red-DiscordBot's alias cog.

Aliases live in the document store with scope=guild|global. Lookup order:
guild → global. The cog listens on ``on_message`` and, when a message
starts with a configured prefix and the next token matches an alias,
rewrites the content and re-dispatches via ``bot.process_commands``.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.errors import AlreadyExistsError, ResourceNotFoundError, UserFeedbackError
from core.permissions import PermissionLevel, requires
from utils.cards import make_info_card, make_list_card
from utils.feature_registry import ConfigField, FieldType, feature

_NAME_RE = re.compile(r"^[A-Za-z0-9_\-]{1,40}$")


def _validate_name(name: str) -> str:
    name = name.strip().lower()
    if not _NAME_RE.match(name):
        raise UserFeedbackError(
            "Alias names must be 1–40 characters, alphanumeric, underscore, or hyphen.",
            title="Invalid alias name",
        )
    return name


@feature(
    display_name="Aliases",
    emoji="🔗",
    description="Define shortcut names that expand to existing prefix commands.",
    fields=[
        ConfigField("enabled", "Enabled", FieldType.BOOLEAN, default=True),
    ],
)
class AliasCog(EmberCog, name="Alias"):
    """Per-guild and global command aliases."""

    alias = app_commands.Group(name="alias", description="Manage command aliases")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults({"guild": {"enabled": True}})

    async def _find(self, *, scope: str, scope_id: int, name: str) -> dict[str, Any] | None:
        return await self.db.find_one("alias", scope=scope, scope_id=scope_id, name=name)

    async def _create(
        self,
        *,
        scope: str,
        scope_id: int,
        name: str,
        command: str,
        creator_id: int,
    ) -> None:
        if await self._find(scope=scope, scope_id=scope_id, name=name):
            raise AlreadyExistsError(f"Alias `{name}` already exists.")
        await self.db.store(
            "alias",
            {
                "scope": scope,
                "scope_id": scope_id,
                "name": name,
                "command": command,
                "creator_id": creator_id,
                "uses": 0,
                "created": datetime.now(UTC).isoformat(),
            },
        )

    async def _delete(self, *, scope: str, scope_id: int, name: str) -> None:
        n = await self.db.remove("alias", scope=scope, scope_id=scope_id, name=name)
        if not n:
            raise ResourceNotFoundError(f"Alias `{name}` not found.")

    @alias.command(name="add", description="Create a guild alias for a command")
    @app_commands.describe(name="Alias name", command="The command this alias expands to")
    @requires(PermissionLevel.MOD)
    async def add(self, interaction: discord.Interaction, name: str, command: str) -> None:
        if interaction.guild is None:
            raise UserFeedbackError("Use this in a server.", title="Server only")
        name = _validate_name(name)
        await self._create(
            scope="guild",
            scope_id=interaction.guild.id,
            name=name,
            command=command,
            creator_id=interaction.user.id,
        )
        await self.send_success(
            interaction,
            f"`{name}` → `{command}`",
            title="✅ Alias created",
        )

    @alias.command(name="remove", description="Remove a guild alias")
    @app_commands.describe(name="Alias name to remove")
    @requires(PermissionLevel.MOD)
    async def remove(self, interaction: discord.Interaction, name: str) -> None:
        if interaction.guild is None:
            raise UserFeedbackError("Use this in a server.", title="Server only")
        name = _validate_name(name)
        await self._delete(scope="guild", scope_id=interaction.guild.id, name=name)
        await self.send_success(interaction, f"Removed alias `{name}`.", title="🗑️ Removed")

    @alias.command(name="show", description="Show what an alias expands to")
    @app_commands.describe(name="Alias name")
    async def show(self, interaction: discord.Interaction, name: str) -> None:
        name = _validate_name(name)
        guild_id = interaction.guild.id if interaction.guild else 0
        row = await self._find(scope="guild", scope_id=guild_id, name=name) or await self._find(
            scope="global", scope_id=0, name=name
        )
        if not row:
            raise ResourceNotFoundError(f"Alias `{name}` not found.")
        body = (
            f"**Name:** `{row['name']}`\n"
            f"**Scope:** {row['scope']}\n"
            f"**Command:** `{row['command']}`\n"
            f"**Uses:** {row.get('uses', 0)}"
        )
        await self.send_card(interaction, make_info_card("🔗 Alias", body))

    @alias.command(name="list", description="List aliases in this server")
    async def list_aliases(self, interaction: discord.Interaction) -> None:
        guild_id = interaction.guild.id if interaction.guild else 0
        rows = await self.db.find("alias", scope="guild", scope_id=guild_id)
        if not rows:
            await self.send_card(
                interaction, make_info_card("🔗 Aliases", "No aliases configured.")
            )
            return
        lines = [f"`{r['name']}` → `{r['command']}`" for r in sorted(rows, key=lambda r: r["name"])]
        await self.send_card(
            interaction,
            make_list_card(f"🔗 Aliases ({len(lines)})", lines, numbered=False, per_page=20),
        )

    global_group = app_commands.Group(
        name="global", description="Global aliases (bot owner)", parent=alias
    )

    @global_group.command(name="add", description="Create a global alias")
    @app_commands.describe(name="Alias name", command="The command this alias expands to")
    async def global_add(self, interaction: discord.Interaction, name: str, command: str) -> None:
        if not await self.bot.is_owner(interaction.user):
            raise UserFeedbackError("Bot owner only.", title="🚫 Owner only")
        name = _validate_name(name)
        await self._create(
            scope="global",
            scope_id=0,
            name=name,
            command=command,
            creator_id=interaction.user.id,
        )
        await self.send_success(
            interaction, f"`{name}` → `{command}` (global)", title="✅ Alias created"
        )

    @global_group.command(name="remove", description="Remove a global alias")
    @app_commands.describe(name="Alias name to remove")
    async def global_remove(self, interaction: discord.Interaction, name: str) -> None:
        if not await self.bot.is_owner(interaction.user):
            raise UserFeedbackError("Bot owner only.", title="🚫 Owner only")
        name = _validate_name(name)
        await self._delete(scope="global", scope_id=0, name=name)
        await self.send_success(interaction, f"Removed global alias `{name}`.", title="🗑️ Removed")

    @global_group.command(name="list", description="List global aliases")
    async def global_list(self, interaction: discord.Interaction) -> None:
        rows = await self.db.find("alias", scope="global", scope_id=0)
        if not rows:
            await self.send_card(
                interaction, make_info_card("🔗 Global Aliases", "No global aliases configured.")
            )
            return
        lines = [f"`{r['name']}` → `{r['command']}`" for r in sorted(rows, key=lambda r: r["name"])]
        await self.send_card(
            interaction,
            make_list_card(f"🔗 Global Aliases ({len(lines)})", lines, numbered=False, per_page=20),
        )

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or not message.content:
            return

        prefixes = await self.bot.get_prefix(message)
        if isinstance(prefixes, str):
            prefixes = [prefixes]
        used_prefix: str | None = None
        for p in prefixes:
            if message.content.startswith(p):
                used_prefix = p
                break
        if used_prefix is None:
            return

        rest = message.content[len(used_prefix) :].lstrip()
        if not rest:
            return
        first, _, tail = rest.partition(" ")
        name = first.lower()
        if not _NAME_RE.match(name):
            return

        guild_id = message.guild.id if message.guild else 0
        row = await self._find(scope="guild", scope_id=guild_id, name=name)
        if row is None:
            row = await self._find(scope="global", scope_id=0, name=name)
        if row is None:
            return

        new_content = f"{used_prefix}{row['command']}"
        if tail:
            new_content = f"{new_content} {tail}"

        try:
            await self.db.store(
                "alias_use",
                {"id": row.get("id"), "ts": datetime.now(UTC).isoformat()},
            )
        except Exception:
            pass

        message.content = new_content
        ctx = await self.bot.get_context(message)
        if ctx.command is not None:
            await self.bot.invoke(ctx)

    async def delete_data_for_user(self, *, user_id: int, guild_id: int | None = None) -> dict:
        n = await self.db.remove("alias", creator_id=user_id)
        return {"aliases_removed": n}


async def setup(bot):
    await bot.add_cog(AliasCog(bot))
