from typing import TypedDict


class FeedbackGuildConfig(TypedDict, total=False):
    """Guild-level feedback configuration."""

    enabled: bool
