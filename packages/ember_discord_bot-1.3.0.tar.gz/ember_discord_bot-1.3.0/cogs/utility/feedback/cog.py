from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.errors import UserFeedbackError, UserNotFoundError
from core.i18n import Translator, cog_i18n
from core.permissions import PermissionLevel, requires
from utils.cards import make_error_card, make_success_card
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import FeedbackGuildConfig

_ = Translator("feedback", __file__)
log = logging.getLogger("ember.feedback")

_FEEDBACK_ID = 0x46656462  # 'Fedb' magic number


@cog_i18n(_)
@feature(
    display_name="Feedback",
    description="Anonymous two-way DM feedback system between members and the bot owner.",
    emoji="💬",
    fields=[
        ConfigField(
            key="channel_id",
            label="Feedback Channel",
            type=FieldType.CHANNEL,
            required=True,
            description="Channel where feedback submissions are forwarded.",
        ),
    ],
)
class FeedbackCog(EmberCog, name="Feedback"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        # In-memory state (not persisted across restarts)
        self.banned_users: set[int] = set()
        self.pending_feedback: dict[int, dict] = {}  # message_id -> {user_id, content, attachments}
        self._owner_id: int | None = None
        self._owner_dm: discord.DMChannel | None = None
        self.db.register_schema("guild", FeedbackGuildConfig)

    async def cog_load(self) -> None:
        register_data_callbacks(self)
        stored = await self.db.get("global", 0, "banned_users")
        if stored:
            self.banned_users = set(stored)

    async def cog_unload(self) -> None:
        pass

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        self.banned_users.discard(user_id)
        await self.db.set("global", 0, "banned_users", list(self.banned_users))
        to_remove = [
            mid for mid, data in self.pending_feedback.items() if data["user_id"] == user_id
        ]
        for mid in to_remove:
            self.pending_feedback.pop(mid, None)
        return {}

    async def _get_owner(self):
        if self._owner_id is None:
            app_info = await self.bot.application_info()
            self._owner_id = app_info.owner.id
            owner_user = await self.bot.fetch_user(self._owner_id)
            self._owner_dm = owner_user.dm_channel or await owner_user.create_dm()
        return self._owner_id, self._owner_dm

    @commands.Cog.listener()
    async def on_ready(self):
        try:
            await self._get_owner()
            log.info("[Feedback] System ready.")
        except Exception as e:
            log.error(f"[Feedback] Failed to setup: {e}")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return
        try:
            owner_id, owner_dm = await self._get_owner()
        except Exception:
            return

        if not message.guild and message.author.id == owner_id and message.reference:
            await self._handle_owner_reply(message)
            return

        if message.author.id == owner_id:
            return

        if not message.guild:
            await self._handle_user_dm(message)

    async def _handle_user_dm(self, message: discord.Message):
        if message.author.id in self.banned_users:
            view = make_error_card(
                "❌ Message Blocked",
                "You are banned from using this feedback service.",
            )
            await message.author.send(view=view)
            return

        try:
            _, owner_dm = await self._get_owner()
        except Exception:
            return

        view = discord.ui.LayoutView(timeout=None)
        children: list = [
            discord.ui.TextDisplay("## 📩 New Feedback"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay(message.content or "(empty)"),
        ]
        if message.attachments:
            attachments = "\n".join(a.url for a in message.attachments)[:1024]
            children.append(discord.ui.TextDisplay(f"**📎 Attachments:**\n{attachments}"))
        children.append(
            discord.ui.TextDisplay(f"-# UserID: {message.author.id} • Reply to respond")
        )
        view.add_item(discord.ui.Container(*children, accent_color=discord.Color.blurple()))

        try:
            sent_msg = await owner_dm.send(view=view)
            # Track pending feedback for reply resolution
            self.pending_feedback[sent_msg.id] = {
                "user_id": message.author.id,
                "content": message.content or "",
                "attachments": [a.url for a in message.attachments],
            }
        except discord.Forbidden:
            view = make_error_card(
                "❌ Cannot Deliver",
                "The staff has DMs disabled. Try again later.",
            )
            await message.author.send(view=view)

    async def _handle_owner_reply(self, message: discord.Message):
        try:
            ref_msg = await message.channel.fetch_message(message.reference.message_id)
        except Exception:
            return

        data = self.pending_feedback.pop(ref_msg.id, None)
        if not data:
            await message.reply(
                view=make_error_card("❌ Unknown Feedback", "Original feedback context not found."),
                delete_after=10,
            )
            return

        user_id = data["user_id"]
        content = data["content"]
        attachments = data.get("attachments", [])

        try:
            user = await self.bot.fetch_user(user_id)
        except discord.NotFound:
            await message.reply(
                view=make_error_card("❌ User Not Found", "The user no longer exists."),
                delete_after=10,
            )
            return

        if user.id in self.banned_users:
            await message.reply(
                view=make_error_card("❌ User Banned", "This user is banned from feedback."),
                delete_after=5,
            )
            return

        reply_view = discord.ui.LayoutView(timeout=None)
        children: list = [
            discord.ui.TextDisplay("## 📨 Staff Response"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay(message.content),
        ]
        if message.attachments:
            children.append(
                discord.ui.TextDisplay(
                    "📎 **Attachments:**\n" + "\n".join(a.url for a in message.attachments)[:1024]
                )
            )
        children.extend(
            [
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay("-# You can reply to continue the conversation"),
            ]
        )
        reply_view.add_item(discord.ui.Container(*children, accent_color=EmberColors.SUCCESS))

        try:
            await user.send(view=reply_view)
            replied_view = discord.ui.LayoutView(timeout=None)
            replied_children = [
                discord.ui.TextDisplay("## 📩 Feedback Replied"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(content or "(empty)"),
            ]
            if attachments:
                replied_children.append(
                    discord.ui.TextDisplay("📎 **Attachments:**\n" + "\n".join(attachments)[:1024])
                )
            replied_children.extend(
                [
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"-# ✅ Replied by {message.author.display_name}"),
                ]
            )
            replied_view.add_item(
                discord.ui.Container(*replied_children, accent_color=EmberColors.SUCCESS)
            )
            await ref_msg.edit(view=replied_view)
        except discord.Forbidden:
            await message.reply(
                view=make_error_card(
                    "❌ Cannot Deliver",
                    "User has DMs disabled or blocked the bot.",
                ),
                delete_after=10,
            )

    feedback_group = app_commands.Group(name="feedback", description="Manage the feedback system")

    @feedback_group.command(name="stats", description="Show feedback system statistics")
    @requires(PermissionLevel.BOT_OWNER)
    async def feedback_stats(self, interaction: discord.Interaction):
        await self.send_info(
            interaction,
            f"**Banned Users:** {len(self.banned_users)}\n**Delivery:** Owner DMs",
            title="📊 Feedback Statistics",
        )

    @feedback_group.command(name="ban", description="Ban a user from feedback")
    @app_commands.describe(user_id="User ID to ban")
    @requires(PermissionLevel.BOT_OWNER)
    async def feedback_ban(self, interaction: discord.Interaction, user_id: str):
        try:
            user = await self.bot.fetch_user(int(user_id))
        except (discord.NotFound, ValueError) as exc:
            raise UserNotFoundError(user_id) from exc
        if user.id in self.banned_users:
            raise UserFeedbackError(f"{user.mention} is already banned.", title="⚠️ Already Banned")
        self.banned_users.add(user.id)
        await self.db.set("global", 0, "banned_users", list(self.banned_users))
        await interaction.response.send_message(
            view=make_error_card("🔨 User Banned", f"{user.mention} banned from feedback.")
        )

    @feedback_group.command(name="unban", description="Unban a user from feedback")
    @app_commands.describe(user_id="User ID to unban")
    @requires(PermissionLevel.BOT_OWNER)
    async def feedback_unban(self, interaction: discord.Interaction, user_id: str):
        try:
            user = await self.bot.fetch_user(int(user_id))
        except (discord.NotFound, ValueError) as exc:
            raise UserNotFoundError(user_id) from exc
        if user.id not in self.banned_users:
            raise UserFeedbackError(f"{user.mention} is not banned.", title="ℹ️ Not Banned")
        self.banned_users.discard(user.id)
        await self.db.set("global", 0, "banned_users", list(self.banned_users))
        await interaction.response.send_message(
            view=make_success_card("✅ User Unbanned", f"{user.mention} unbanned.")
        )

    @feedback_group.command(name="banlist", description="List all banned users")
    @requires(PermissionLevel.BOT_OWNER)
    async def feedback_banlist(self, interaction: discord.Interaction):
        if not self.banned_users:
            return await self.send_info(
                interaction, "No users are currently banned.", title="ℹ️ Banned Users"
            )
        lines = []
        for uid in self.banned_users:
            try:
                u = await self.bot.fetch_user(uid)
                lines.append(f"{u.mention} ({uid})")
            except discord.NotFound:
                lines.append(f"Unknown ({uid})")
        view = discord.ui.LayoutView(timeout=None)
        children = [
            discord.ui.TextDisplay("## 📋 Banned Users"),
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay("\n".join(lines) or "(no users)"),
        ]
        view.add_item(discord.ui.Container(*children, accent_color=EmberColors.WARNING))
        await interaction.response.send_message(view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(FeedbackCog(bot))
