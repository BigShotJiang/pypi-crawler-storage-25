import logging
from collections import defaultdict
from datetime import UTC, datetime

from discord.ext import tasks

log = logging.getLogger("ember.rolementions")


class RoleMentionTracker:
    """Tracks role mention statistics per guild and role."""

    def __init__(self, cog):
        self.cog = cog
        self.bot = cog.bot
        self.db = cog.db
        self._role_mentions: dict[str, dict[str, int]] = {}
        self._daily_reset_task: tasks.Loop | None = None

        # Initialize storage
        self._load_data()

    def _load_data(self) -> None:
        """Load role mention data from Store into memory."""
        # We'll lazily load per guild as needed
        pass

    async def _get_guild_data(self, guild_id: int) -> dict[str, int]:
        """Get role mention data for a guild, loading from Store if needed."""
        guild_id_str = str(guild_id)
        if guild_id_str not in self._role_mentions:
            data = await self.db.guild(guild_id).get("stats", default={})
            self._role_mentions[guild_id_str] = defaultdict(int, data)
        return self._role_mentions[guild_id_str]

    async def _save_guild_data(self, guild_id: int) -> None:
        """Save guild role mention data to Store."""
        guild_id_str = str(guild_id)
        if guild_id_str in self._role_mentions:
            data = dict(self._role_mentions[guild_id_str])
            await self.db.guild(guild_id).set("stats", data)

    async def increment_mentions(self, guild_id: int, role_id: str) -> None:
        """Increment mention count for a role."""
        guild_data = await self._get_guild_data(guild_id)
        guild_data[role_id] += 1
        # We'll batch save periodically, not on every increment to reduce I/O

    async def get_role_count(self, guild_id: int, role_id: str) -> int:
        """Get mention count for a specific role."""
        guild_data = await self._get_guild_data(guild_id)
        return guild_data.get(role_id, 0)

    async def get_guild_stats(self, guild_id: int) -> dict:
        """Get all role mention stats for a guild."""
        guild_data = await self._get_guild_data(guild_id)
        total = sum(guild_data.values())
        unique = len(guild_data)
        return {"total": total, "unique": unique, "roles": dict(guild_data)}

    async def reset_guild(self, guild_id: int) -> None:
        """Reset all counters for a specific guild."""
        guild_id_str = str(guild_id)
        if guild_id_str in self._role_mentions:
            self._role_mentions[guild_id_str].clear()
        await self.db.guild(guild_id).set("stats", {})
        log.info(f"[RoleMentionTracker] Reset stats for guild {guild_id}")

    async def reset_all(self) -> None:
        """Reset all guild counters."""
        for guild_id_str in list(self._role_mentions.keys()):
            self._role_mentions[guild_id_str].clear()
        log.info("[RoleMentionTracker] Reset all guild stats")

    async def cog_unload(self) -> None:
        """Cleanup when cog is unloaded — save all data."""
        for guild_id in list(self._role_mentions.keys()):
            try:
                guild_id_int = int(guild_id)
                await self._save_guild_data(guild_id_int)
            except ValueError:
                continue
        if self._daily_reset_task:
            self._daily_reset_task.cancel()

    async def start_tasks(self) -> None:
        """Start background tasks."""
        if self._daily_reset_task is None:
            self._daily_reset_task = self.daily_reset
            self._daily_reset_task.start()

    @tasks.loop(minutes=1)
    async def daily_reset(self):
        """Reset counters daily at 4 AM guild-local time for each guild."""
        await self.bot.wait_until_ready()
        now = datetime.now(UTC)

        # For each guild, check if it's 4 AM in that guild's timezone
        # We'll use a simple approach: check at 4 AM UTC for all guilds (simpler)
        # But discord-data uses IST (Asia/Kolkata). Since Ember is multi-guild, we need
        # a strategy. We'll reset daily at midnight UTC for all guilds.
        if now.hour == 0 and now.minute == 0:
            await self.reset_all()
            log.info(f"[RoleMentionTracker] Daily reset performed at {now.isoformat()}")

    @daily_reset.before_loop
    async def before_daily_reset(self):
        """Wait until bot is ready."""
        await self.bot.wait_until_ready()

    async def save_all(self) -> None:
        """Force save all data to Store."""
        for guild_id_str in list(self._role_mentions.keys()):
            try:
                guild_id = int(guild_id_str)
                await self._save_guild_data(guild_id)
            except ValueError:
                continue
