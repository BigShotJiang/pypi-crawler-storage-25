import logging
from datetime import UTC, datetime, timedelta

import discord
from discord import AutoModRuleAction, AutoModTrigger
from discord.enums import AutoModRuleEventType, AutoModRuleTriggerType
from discord.ext import tasks

log = logging.getLogger("ember.rolementions")


class AutoModManager:
    """Manages dynamic AutoMod rules for role protection."""

    def __init__(self, cog):
        self.cog = cog
        self.bot = cog.bot
        self.store = cog.db

        # Load configuration
        self._load_config()

        # State
        self.main_rule_id: str | None = None
        self.rule_guild_id: str | None = None
        self.current_keywords: list[str] = []
        self.active_blocks: dict[str, dict] = {}

        # Tasks will be started by cog_load
        self._rule_manager_task: tasks.Loop | None = None
        self._cleanup_task: tasks.Loop | None = None
        self._message_update_task: tasks.Loop | None = None

        # Load saved blocks
        self._load_blocks()

    def _load_config(self) -> None:
        """Load configuration from Store (Feature Registry)."""
        # Defaults are defined in FeatureMeta, we'll read them from guild config
        self.MENTION_LIMIT = 3
        self.DEFAULT_DURATION = 120
        self.PROTECTED_ROLES: dict[str, int] = {}

        # IST timezone for logging
        try:
            import pytz

            self.ist = pytz.timezone("Asia/Kolkata")
        except ImportError:
            self.ist = None

    async def load_guild_config(self, guild_id: int) -> None:
        """Load guild-specific configuration from Store."""
        cfg = await self.store.guild(guild_id).all()
        self.MENTION_LIMIT = cfg.get("mention_limit", 3)
        self.DEFAULT_DURATION = cfg.get("block_duration_minutes", 120)
        self.PROTECTED_ROLES = cfg.get("protected_roles", {})

        # Ensure PROTECTED_ROLES keys are strings
        self.PROTECTED_ROLES = {str(k): v for k, v in self.PROTECTED_ROLES.items()}

    def _load_blocks(self) -> None:
        """Load active blocks from Store."""
        # We'll lazily load per guild as needed
        pass

    async def _get_guild_blocks(self, guild_id: int) -> dict[str, dict]:
        """Get active blocks for a guild, loading from Store if needed."""
        guild_id_str = str(guild_id)
        if guild_id_str not in self.active_blocks:
            data = await self.store.guild(guild_id).get("active_blocks", default={})
            self.active_blocks[guild_id_str] = {}
            for role_id, block_data in data.items():
                for ts_key in ("expires_at", "created_at"):
                    raw = block_data.get(ts_key)
                    if isinstance(raw, str):
                        try:
                            raw = datetime.fromisoformat(raw)
                        except (ValueError, TypeError):
                            raw = None
                    # legacy rows stored naive datetimes; coerce to UTC-aware
                    if isinstance(raw, datetime) and raw.tzinfo is None:
                        raw = raw.replace(tzinfo=UTC)
                    block_data[ts_key] = raw
                self.active_blocks[guild_id_str][role_id] = block_data
        return self.active_blocks[guild_id_str]

    async def _save_guild_blocks(self, guild_id: int) -> None:
        """Save guild active blocks to Store."""
        guild_id_str = str(guild_id)
        if guild_id_str in self.active_blocks:
            # Convert datetime objects to ISO format for storage
            serializable = {}
            for role_id, block_data in self.active_blocks[guild_id_str].items():
                serializable[role_id] = block_data.copy()
                if "expires_at" in serializable[role_id] and isinstance(
                    serializable[role_id]["expires_at"], datetime
                ):
                    serializable[role_id]["expires_at"] = serializable[role_id][
                        "expires_at"
                    ].isoformat()
                if "created_at" in serializable[role_id] and isinstance(
                    serializable[role_id]["created_at"], datetime
                ):
                    serializable[role_id]["created_at"] = serializable[role_id][
                        "created_at"
                    ].isoformat()
            await self.store.guild(guild_id).set("active_blocks", serializable)

    def is_protected_role(self, role_id: str) -> bool:
        """Check if a role ID is in the protected list (configured)."""
        return str(role_id) in self.PROTECTED_ROLES

    def get_role_duration(self, role_id: str) -> int:
        """Get the duration in minutes for a protected role."""
        return self.PROTECTED_ROLES.get(str(role_id), self.DEFAULT_DURATION)

    def get_remaining_time(self, expires_at: datetime) -> str:
        """Get human-readable remaining time."""
        if not expires_at:
            return "unknown"
        now = datetime.now(UTC)
        if expires_at <= now:
            return "expired"

        remaining = expires_at - now
        total_minutes = int(remaining.total_seconds() / 60)

        if total_minutes >= 60:
            hours = total_minutes / 60
            if hours >= 24:
                days = int(hours / 24)
                hours_remain = int(hours % 24)
                if hours_remain > 0:
                    return f"{days}d{hours_remain}h"
                else:
                    return f"{days}d"
            else:
                remaining_minutes = total_minutes % 60
                if remaining_minutes > 0:
                    return f"{int(hours)}h{remaining_minutes}m"
                else:
                    return f"{int(hours)}h"
        else:
            return f"{total_minutes}m"

    async def ensure_main_rule_exists(self, guild: discord.Guild) -> None:
        """Create or find the main AutoMod rule."""
        try:
            if not guild.me.guild_permissions.manage_guild:
                log.warning(f"[AutoMod] Missing 'Manage Guild' permission in {guild.name}")
                return

            # Look for existing rule
            existing_rules = await guild.fetch_automod_rules()
            for rule in existing_rules:
                if rule.name == "🛡️ Dynamic Role Protection":
                    self.main_rule_id = str(rule.id)
                    self.rule_guild_id = str(guild.id)
                    if hasattr(rule.trigger, "keyword_filter"):
                        self.current_keywords = rule.trigger.keyword_filter
                    log.info(f"[AutoMod] Found existing rule: {self.main_rule_id}")
                    return

            # Create new rule
            rule = await guild.create_automod_rule(
                name="🛡️ Dynamic Role Protection",
                event_type=AutoModRuleEventType.message_send,
                trigger=AutoModTrigger(
                    type=AutoModRuleTriggerType.keyword,
                    keyword_filter=["placeholder"],
                ),
                actions=[
                    AutoModRuleAction(
                        type=discord.AutoModRuleActionType.block_message,
                        custom_message="This role is temporarily protected from mention spam.",
                    )
                ],
                enabled=True,
                reason="Dynamic role protection system",
            )

            self.main_rule_id = str(rule.id)
            self.rule_guild_id = str(guild.id)
            self.current_keywords = []
            log.info(f"[AutoMod] Created rule: {self.main_rule_id}")

        except Exception as e:
            log.error(f"[AutoMod] Error ensuring rule exists: {e}")

    async def update_rule_keywords(self, guild_id: int) -> None:
        """Update the AutoMod rule's keyword list based on active blocks."""
        if not self.main_rule_id or not self.rule_guild_id:
            return

        guild = self.bot.get_guild(int(self.rule_guild_id))
        if not guild:
            return

        guild_blocks = await self._get_guild_blocks(guild_id)
        new_keywords = [f"<@&{role_id}>" for role_id in guild_blocks.keys()]

        if not new_keywords:
            new_keywords = ["no_active_blocks_placeholder"]

        if set(new_keywords) != set(self.current_keywords):
            try:
                rule = await guild.fetch_automod_rule(int(self.main_rule_id))
                await rule.edit(
                    trigger=AutoModTrigger(
                        type=AutoModRuleTriggerType.keyword,
                        keyword_filter=new_keywords,
                    )
                )
                self.current_keywords = new_keywords
                log.info(f"[AutoMod] Updated keywords: {len(new_keywords)} roles")
                await self.update_block_message(guild)
            except Exception as e:
                log.error(f"[AutoMod] Error updating keywords: {e}")

    async def update_block_message(self, guild: discord.Guild) -> None:
        """Update the custom block message."""
        if not self.main_rule_id or not self.active_blocks.get(str(guild.id)):
            return

        try:
            rule = await guild.fetch_automod_rule(int(self.main_rule_id))
            guild_blocks = await self._get_guild_blocks(guild.id)

            if len(guild_blocks) == 1:
                role_id, block_data = next(iter(guild_blocks.items()))
                role = guild.get_role(int(role_id))
                if role:
                    remaining = self.get_remaining_time(block_data["expires_at"])
                    custom_message = f"⚠️ @{role.name} protected ({remaining}). Do not mention."
                else:
                    custom_message = "This role is temporarily protected."
            else:
                custom_message = f"⚠️ {len(guild_blocks)} roles are currently protected."

            await rule.edit(
                actions=[
                    AutoModRuleAction(
                        type=discord.AutoModRuleActionType.block_message,
                        custom_message=custom_message,
                    )
                ]
            )
        except Exception as e:
            log.error(f"[AutoMod] Error updating block message: {e}")

    async def add_block(
        self,
        guild: discord.Guild,
        role_id: str,
        role_name: str,
        duration_minutes: int,
        trigger_user_id: int,
        trigger_message_id: int | None = None,
        manually_added: bool = False,
    ) -> dict:
        """Add a role to the protection list."""
        guild_id_str = str(guild.id)
        expires_at = datetime.now(UTC) + timedelta(minutes=duration_minutes)

        block_data = {
            "guild_id": guild_id_str,
            "role_id": role_id,
            "role_name": role_name,
            "created_at": datetime.now(UTC),
            "expires_at": expires_at,
            "duration_minutes": duration_minutes,
            "trigger_message_id": str(trigger_message_id) if trigger_message_id else None,
            "trigger_user_id": str(trigger_user_id),
            "manually_added": manually_added,
        }

        guild_blocks = await self._get_guild_blocks(guild.id)
        guild_blocks[role_id] = block_data
        await self._save_guild_blocks(guild.id)

        await self.update_rule_keywords(guild.id)
        await self.log_block_created(guild, role_name, duration_minutes)

        return block_data

    async def remove_block(self, guild: discord.Guild, role_id: str) -> dict | None:
        """Remove a role from the protection list."""
        str(guild.id)
        guild_blocks = await self._get_guild_blocks(guild.id)

        if role_id not in guild_blocks:
            return None

        block_data = guild_blocks.pop(role_id)
        await self._save_guild_blocks(guild.id)
        await self.update_rule_keywords(guild.id)
        return block_data

    async def is_blocked(self, guild_id: int, role_id: str) -> bool:
        """Check if a role is currently blocked."""
        guild_blocks = await self._get_guild_blocks(guild_id)
        return role_id in guild_blocks

    async def check_and_block_role(self, message: discord.Message, role: discord.Role) -> None:
        """Check if a role mention should trigger protection."""
        guild_id = message.guild.id

        # Load guild config
        await self.load_guild_config(guild_id)

        # Check if automod is enabled
        automod_enabled = await self.cog.db.guild(guild_id).get("automod_enabled", default=True)
        if not automod_enabled:
            return

        # Only check protected roles
        if not self.is_protected_role(str(role.id)):
            return

        # Check if already blocked
        if await self.is_blocked(guild_id, str(role.id)):
            log.debug(f"[AutoMod] Role {role.name} already blocked")
            return

        # Count mentions in this message
        role_mentions_in_message = sum(1 for r in message.role_mentions if r.id == role.id)
        if role_mentions_in_message < self.MENTION_LIMIT:
            return

        # Add block
        duration = self.get_role_duration(str(role.id))
        await self.add_block(
            guild=message.guild,
            role_id=str(role.id),
            role_name=role.name,
            duration_minutes=duration,
            trigger_user_id=message.author.id,
            trigger_message_id=message.id,
        )

        log.info(f"[AutoMod] Blocked role {role.name} in guild {guild_id}")

    async def log_block_created(
        self, guild: discord.Guild, role_name: str, duration_minutes: int
    ) -> None:
        """Log block creation to channel."""
        automod_channel_id = await self.cog._get_automod_channel_id(guild.id)
        if not automod_channel_id:
            return

        channel = guild.get_channel(automod_channel_id)
        if not channel:
            return

        expires_at = datetime.now(UTC) + timedelta(minutes=duration_minutes)
        duration_display = (
            f"{duration_minutes/60:.1f}h" if duration_minutes >= 60 else f"{duration_minutes}m"
        )

        view = discord.ui.LayoutView(timeout=None)
        view.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🛡️ Role Protection Activated"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"**Protected Role:** {role_name}\n"
                    f"**Duration:** {duration_display}\n"
                    f"**Expires:** <t:{int(expires_at.timestamp())}:R>\n"
                    f"**Mention Limit:** {self.MENTION_LIMIT} per message"
                ),
                accent_color=discord.Color.red(),
            )
        )

        try:
            await channel.send(view=view, delete_after=3600)
        except Exception as e:
            log.warning(f"[AutoMod] Failed to log block creation: {e}")

    async def log_block_expired(self, guild: discord.Guild, block_data: dict) -> None:
        """Log block expiration to channel."""
        automod_channel_id = await self.cog._get_automod_channel_id(guild.id)
        if not automod_channel_id:
            return

        channel = guild.get_channel(automod_channel_id)
        if not channel:
            return

        role_name = block_data.get("role_name", "Unknown")
        duration_minutes = block_data.get("duration_minutes", 120)
        duration_display = (
            f"{duration_minutes/60:.1f}h" if duration_minutes >= 60 else f"{duration_minutes}m"
        )

        view = discord.ui.LayoutView(timeout=None)
        view.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## ✅ Role Protection Expired"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"**Role:** {role_name}\n"
                    f"**Duration:** {duration_display}\n"
                    f"**Created:** <t:{int(block_data['created_at'].timestamp())}:R>"
                ),
                accent_color=discord.Color.green(),
            )
        )

        try:
            await channel.send(view=view, delete_after=3600)
        except Exception as e:
            log.warning(f"[AutoMod] Failed to log block expiration: {e}")

    async def start_tasks(self) -> None:
        """Start background tasks."""
        if self._rule_manager_task is None:
            self._rule_manager_task = self.rule_manager
            self._rule_manager_task.start()

        if self._cleanup_task is None:
            self._cleanup_task = self.cleanup_task
            self._cleanup_task.start()

        if self._message_update_task is None:
            self._message_update_task = self.message_update_task
            self._message_update_task.start()

    def cog_unload(self) -> None:
        """Cleanup when cog is unloaded."""
        if self._rule_manager_task:
            self._rule_manager_task.cancel()
        if self._cleanup_task:
            self._cleanup_task.cancel()
        if self._message_update_task:
            self._message_update_task.cancel()

    @tasks.loop(seconds=60)
    async def rule_manager(self):
        """Ensure AutoMod rule exists and is updated."""
        await self.bot.wait_until_ready()
        if not self.main_rule_id and self.bot.guilds:
            guild = self.bot.guilds[
                0
            ]  # We'll try first guild; logic may need refinement for multi-guild
            await self.ensure_main_rule_exists(guild)

        if self.main_rule_id and self.rule_guild_id:
            await self.update_rule_keywords(int(self.rule_guild_id))

    @tasks.loop(seconds=300)
    async def message_update_task(self):
        """Update block message with remaining time."""
        await self.bot.wait_until_ready()
        if not self.main_rule_id or not self.rule_guild_id:
            return

        guild = self.bot.get_guild(int(self.rule_guild_id))
        if not guild:
            return

        try:
            await guild.fetch_automod_rule(int(self.main_rule_id))
            await self.update_block_message(guild)
        except Exception as e:
            log.debug(f"[AutoMod] Error updating message: {e}")

    @tasks.loop(seconds=30)
    async def cleanup_task(self):
        """Remove expired blocks."""
        await self.bot.wait_until_ready()
        now = datetime.now(UTC)
        expired_roles = []

        for guild_id_str, guild_blocks in list(self.active_blocks.items()):
            for role_id, block_data in list(guild_blocks.items()):
                expires_at = block_data.get("expires_at")
                if expires_at and expires_at <= now:
                    expired_roles.append((guild_id_str, role_id))
                    guild = self.bot.get_guild(int(guild_id_str))
                    if guild:
                        await self.log_block_expired(guild, block_data)

        for guild_id_str, role_id in expired_roles:
            if guild_id_str in self.active_blocks and role_id in self.active_blocks[guild_id_str]:
                del self.active_blocks[guild_id_str][role_id]
                await self._save_guild_blocks(int(guild_id_str))

        if expired_roles:
            log.info(f"[AutoMod] Removed {len(expired_roles)} expired blocks")
