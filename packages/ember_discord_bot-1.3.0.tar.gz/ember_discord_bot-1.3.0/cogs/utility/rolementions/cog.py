"""RoleMentionCog — tracks role mentions and posts to an automod channel."""

from __future__ import annotations

import logging

import discord
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import RolementionsGuildConfig

_ = Translator("rolementions", __file__)

log = logging.getLogger("ember.rolementions")


@cog_i18n(_)
@feature(
    display_name="Role Mentions",
    description="Logs role mentions to a mod channel so staff can track ping abuse.",
    emoji="🔔",
    fields=[
        ConfigField(
            key="automod_channel_id",
            label="Log Channel",
            type=FieldType.CHANNEL,
            required=True,
            description="Channel where role-mention events are logged.",
        ),
    ],
)
class RoleMentionCog(EmberCog, name="RoleMentions"):
    """Tracks role mentions and logs them to a configured automod channel."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {"enabled": True, "exempt_roles": [], "automod_channel_id": None},
            }
        )
        self.db.register_schema("guild", RolementionsGuildConfig)
        self.db.register_schema("role", RolementionsGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    async def on_message(self, message: discord.Message) -> None:
        if not message.guild or message.author.bot:
            return
        if not message.role_mentions:
            return

        cfg = await self.db.get_all("guild", message.guild.id)
        if not cfg.get("enabled", True):
            return

        exempt_roles = cfg.get("exempt_roles", [])
        exempt_role_ids = set(exempt_roles)
        mentioned = [r for r in message.role_mentions if r.id not in exempt_role_ids]
        if not mentioned:
            return

        automod_channel_id = cfg.get("automod_channel_id")
        if not automod_channel_id:
            return

        channel = message.guild.get_channel(automod_channel_id)
        if not channel:
            return

        roles_str = ", ".join(r.mention for r in mentioned)
        log_view = discord.ui.LayoutView(timeout=None)
        log_view.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("## 🔔 Role Mention Detected"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"**Author:** {message.author.mention} (`{message.author.id}`)\n"
                    f"**Channel:** {message.channel.mention}\n"
                    f"**Roles:** {roles_str}\n"
                    f"**[Jump to message]({message.jump_url})**"
                ),
                accent_color=EmberColors.WARNING,
            )
        )

        try:
            await channel.send(view=log_view)
        except (discord.Forbidden, discord.HTTPException) as e:
            log.warning(f"[RoleMentions] Failed to log mention: {e}")


async def setup(bot):
    await bot.add_cog(RoleMentionCog(bot))
