# Configuration moved to core.config — all settings are per-guild via Config.get_conf().
