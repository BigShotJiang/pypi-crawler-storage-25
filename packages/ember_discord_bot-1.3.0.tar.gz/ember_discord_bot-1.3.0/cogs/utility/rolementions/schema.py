from typing import TypedDict


class RolementionsGuildConfig(TypedDict, total=False):
    """Guild-level rolementions configuration."""

    enabled: bool
