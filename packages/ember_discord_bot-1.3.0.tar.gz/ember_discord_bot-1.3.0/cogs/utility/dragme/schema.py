from typing import TypedDict


class DragmeGuildConfig(TypedDict, total=False):
    """Guild-level dragme configuration."""

    enabled: bool
