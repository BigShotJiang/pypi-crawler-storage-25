import logging
import os

logger = logging.getLogger("ember.dragme")

# Timeouts
TIMEOUT_DURATION = 60  # seconds
MESSAGE_CLEANUP_DELAY = 5  # seconds

# Channel configuration
DRAGME_CHANNEL_ID = None
BLACKLISTED_VOICE_ROLES = set()


def load_config():
    """Load configuration from environment variables."""
    global DRAGME_CHANNEL_ID, BLACKLISTED_VOICE_ROLES

    # Load dragme channel ID
    dragme_channel_str = os.environ.get("DRAGME_CHANNEL_ID")
    if dragme_channel_str:
        try:
            DRAGME_CHANNEL_ID = int(dragme_channel_str)
        except ValueError:
            logger.warning(
                f"⚠️ WARNING: DRAGME_CHANNEL_ID must be an integer, got: {dragme_channel_str}"
            )

    # Load blacklisted voice roles
    if os.environ.get("BLACKLISTED_VOICE_ROLES"):
        try:
            BLACKLISTED_VOICE_ROLES = {
                int(rid.strip())
                for rid in os.environ["BLACKLISTED_VOICE_ROLES"].split(",")
                if rid.strip()
            }
        except ValueError as e:
            logger.warning(f"⚠️ WARNING: Error parsing BLACKLISTED_VOICE_ROLES: {e}")
