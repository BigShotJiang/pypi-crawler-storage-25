from __future__ import annotations

import asyncio
import logging
import re

import discord
from discord import app_commands
from discord.ext import commands

from core import checks
from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.cards import make_error_card
from utils.feature_registry import ConfigField, FieldType, feature

from . import config
from .schema import DragmeGuildConfig

_ = Translator("dragme", __file__)

log = logging.getLogger("ember.dragme")


def extract_user_id(content: str) -> int | None:
    mention_pattern = r"<@!?(\d+)>"
    match = re.search(mention_pattern, content)
    if match:
        return int(match.group(1))
    if content.strip().isdigit():
        return int(content.strip())
    return None


async def delete_message_after(message, delay: int):
    await asyncio.sleep(delay)
    try:
        await message.delete()
    except (discord.NotFound, discord.Forbidden, Exception):
        pass


@cog_i18n(_)
@feature(
    display_name="DragMe",
    description="Lets members request to be dragged into an active voice channel.",
    emoji="🎯",
    fields=[
        ConfigField(
            key="channel_id",
            label="Requests Channel",
            type=FieldType.CHANNEL,
            required=True,
            description="Text channel where drag requests are posted.",
        ),
        ConfigField(
            key="allowed_role_id",
            label="Allowed Role",
            type=FieldType.ROLE,
            description="Restrict who can send drag requests. Leave unset for everyone.",
        ),
    ],
)
class DragmeCog(EmberCog, name="DragMe"):
    """DragMe voice channel request system."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {"enabled": True, "channel_id": None, "allowed_role_id": None},
            }
        )
        self.active_requests: list[dict] = []
        self.requests_lock = asyncio.Lock()
        self.cleanup_task = None
        self.orphan_cleanup_task = None
        self.db.register_schema("guild", DragmeGuildConfig)

    async def cog_load(self):
        await super().cog_load()

        config.load_config()
        # Load active requests from store
        stored = await self.db.globals.get("active_requests")
        if stored:
            self.active_requests = stored
        else:
            self.active_requests = []
        self.cleanup_task = asyncio.create_task(self.channel_cleanup_task())
        self.orphan_cleanup_task = asyncio.create_task(self.cleanup_orphaned_requests())

    async def cog_unload(self):
        await self._persist_requests()
        if self.cleanup_task:
            self.cleanup_task.cancel()
        if self.orphan_cleanup_task:
            self.orphan_cleanup_task.cancel()

    async def _persist_requests(self):
        await self.db.globals.set("active_requests", self.active_requests)

    async def process_drag_request(self, channel, requester, target):
        """Process a drag request between two users."""

        async def send_temp_message(content=None, embed=None, delete_after=10):
            msg = await channel.send(content=content, embed=embed, delete_after=delete_after)
            asyncio.create_task(delete_message_after(msg, delete_after))
            return msg

        if requester.id == target.id:
            return await send_temp_message(
                f"{requester.mention} ❌ You cannot drag yourself!", delete_after=10
            )

        if any(role.id in config.BLACKLISTED_VOICE_ROLES for role in requester.roles):
            return await send_temp_message(
                f"{requester.mention} ❌ You are not allowed to use this command.",
                delete_after=10,
            )

        if not requester.voice or not requester.voice.channel:
            return await send_temp_message(
                f"{requester.mention} ❌ You must join a voice channel first.",
                delete_after=10,
            )

        if not target.voice or not target.voice.channel:
            return await send_temp_message(
                f"{requester.mention} ❌ {target.mention} must be in a voice channel.",
                delete_after=10,
            )

        if requester.voice.channel == target.voice.channel:
            return await send_temp_message(
                f"{requester.mention} ⚠️ You're already in {target.mention}'s VC.",
                delete_after=10,
            )

        async with self.requests_lock:
            user_pending = [
                r
                for r in self.active_requests
                if r["requester"] == requester.id or r["target"] == requester.id
            ]
            if user_pending:
                return await send_temp_message(
                    f"{requester.mention} ❌ You already have a pending request! Please wait for it to complete.",
                    delete_after=10,
                )

            request_key = {"requester": requester.id, "target": target.id}
            existing = next(
                (
                    r
                    for r in self.active_requests
                    if (r["requester"] == requester.id and r["target"] == target.id)
                    or (r["requester"] == target.id and r["target"] == requester.id)
                ),
                None,
            )
            if existing:
                return await send_temp_message(
                    f"{requester.mention} ⚠️ There's already an active request between you and {target.mention}",
                    delete_after=10,
                )

            self.active_requests.append(request_key)
            await self._persist_requests()

        await send_temp_message(
            f"✅ {requester.mention} Your request was sent to {target.mention}",
            delete_after=10,
        )

        target_channel = target.voice.channel

        class DragmeView(discord.ui.LayoutView):
            def __init__(self, requester, target, bot, request_key, *, hidden=False, cog_ref):
                super().__init__(timeout=config.TIMEOUT_DURATION)
                self.msg = None
                self.finished = False
                self.requester = requester
                self.target = target
                self.bot = bot
                self.request_key = request_key
                self.hidden = hidden
                self.cog = cog_ref

                # Build UI container
                children = []
                if hidden:
                    title = "## 🔔 New DragMe Request (Hidden VC)"
                    desc = f"{requester.mention} wants to join {target.mention}'s hidden voice channel!"
                    children.append(discord.ui.TextDisplay(title))
                    children.append(discord.ui.Separator(spacing=discord.SeparatorSpacing.small))
                    children.append(discord.ui.TextDisplay(desc))
                    children.append(
                        discord.ui.TextDisplay(f"**Target:** {target.name}\n{target.mention}")
                    )
                    footer = f"Request expires in {config.TIMEOUT_DURATION} seconds • Target is in hidden VC"
                else:
                    title = "## 🔔 New DragMe Request!"
                    desc = f"{requester.mention} wants to join your voice channel!"
                    children.append(discord.ui.TextDisplay(title))
                    children.append(discord.ui.Separator(spacing=discord.SeparatorSpacing.small))
                    children.append(discord.ui.TextDisplay(desc))
                    footer = (
                        f"Use the buttons below to respond • Expires in {config.TIMEOUT_DURATION}s"
                    )

                children.append(discord.ui.TextDisplay(f"-# {footer}"))

                btn_accept = discord.ui.Button(style=discord.ButtonStyle.success, label="✅ Accept")
                btn_decline = discord.ui.Button(
                    style=discord.ButtonStyle.danger, label="❌ Decline"
                )
                btn_accept.callback = self.accept_callback
                btn_decline.callback = self.decline_callback
                children.append(discord.ui.ActionRow(btn_accept, btn_decline))

                container = discord.ui.Container(*children, accent_color=EmberColors.WARNING)
                self.add_item(container)

            async def remove_request(self):
                async with self.cog.requests_lock:
                    if self.request_key in self.cog.active_requests:
                        self.cog.active_requests.remove(self.request_key)
                        await self.cog._persist_requests()

            async def finish(self, content: str, color=EmberColors.SUCCESS):
                self.finished = True
                await self.remove_request()

                view = discord.ui.LayoutView(timeout=None)
                children = [
                    discord.ui.TextDisplay("## 📍 DragMe Request"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(content),
                    discord.ui.TextDisplay(
                        f"-# {discord.utils.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
                    ),
                ]
                view.add_item(discord.ui.Container(*children, accent_color=color))

                dragme_channel = self.cog.bot.get_channel(config.DRAGME_CHANNEL_ID)
                if dragme_channel:
                    log_msg = await dragme_channel.send(view=view)
                    asyncio.create_task(delete_message_after(log_msg, 30))

                if self.msg:
                    await self.msg.edit(view=view, content=None, embed=None)
                    asyncio.create_task(delete_message_after(self.msg, 10))
                self.stop()

            async def on_timeout(self):
                if not self.finished and self.msg:
                    await self.remove_request()
                    content = f"⌛ Request from {self.requester.mention} to {self.target.mention} timed out."

                    dragme_channel = self.cog.bot.get_channel(config.DRAGME_CHANNEL_ID)
                    if dragme_channel:
                        view = discord.ui.LayoutView(timeout=None)
                        children = [
                            discord.ui.TextDisplay("## ⏰ DragMe Request Timed Out"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(content),
                            discord.ui.TextDisplay(
                                f"-# {discord.utils.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
                            ),
                        ]
                        view.add_item(
                            discord.ui.Container(*children, accent_color=EmberColors.ERROR)
                        )
                        log_msg = await dragme_channel.send(view=view)
                        asyncio.create_task(delete_message_after(log_msg, 30))

                    if self.msg:
                        view = discord.ui.LayoutView(timeout=None)
                        children = [
                            discord.ui.TextDisplay("## ⏰ DragMe Request Timed Out"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay(content),
                            discord.ui.TextDisplay(
                                f"-# {discord.utils.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
                            ),
                        ]
                        view.add_item(
                            discord.ui.Container(*children, accent_color=EmberColors.ERROR)
                        )
                        await self.msg.edit(view=view, content=None, embed=None)
                        asyncio.create_task(delete_message_after(self.msg, 10))

            async def accept_callback(self, interaction: discord.Interaction):
                if interaction.user.id != self.target.id:
                    return await interaction.response.send_message(
                        view=make_error_card("❌ Error", "This is not your request"), ephemeral=True
                    )

                updated_target = interaction.guild.get_member(self.target.id)
                if (
                    not updated_target
                    or not updated_target.voice
                    or not updated_target.voice.channel
                ):
                    return await interaction.response.send_message(
                        view=make_error_card("❌ Error", "You are no longer in a voice channel."),
                        ephemeral=True,
                    )

                updated_channel = updated_target.voice.channel
                is_hidden = not updated_channel.permissions_for(
                    interaction.guild.default_role
                ).connect

                try:
                    await self.requester.move_to(updated_channel)

                    if is_hidden:
                        try:
                            await updated_channel.set_permissions(
                                self.requester,
                                connect=True,
                                speak=True,
                                reason=f"Temporary access via dragme request from {self.target.display_name}",
                            )

                            async def remove_perms_when_done():
                                await asyncio.sleep(300)
                                try:
                                    current_member = interaction.guild.get_member(self.requester.id)
                                    if (
                                        current_member
                                        and current_member.voice
                                        and current_member.voice.channel == updated_channel
                                    ):
                                        return
                                    await updated_channel.set_permissions(
                                        self.requester, overwrite=None
                                    )
                                except Exception:
                                    pass

                            asyncio.create_task(remove_perms_when_done())
                        except Exception:
                            pass

                    success_msg = f"✅ {self.target.mention} accepted. {self.requester.mention} was moved to **{updated_channel.name}**"
                    await self.finish(success_msg, EmberColors.SUCCESS)

                except discord.Forbidden:
                    await self.finish(
                        f"❌ Missing permissions to move {self.requester.mention}",
                        EmberColors.ERROR,
                    )
                except discord.HTTPException as e:
                    await self.finish(f"❌ Failed to move user: {e}", EmberColors.ERROR)

            async def decline_callback(self, interaction: discord.Interaction):
                if interaction.user.id != self.target.id:
                    return await interaction.response.send_message(
                        view=make_error_card("❌ Error", "This is not your request"), ephemeral=True
                    )
                await self.finish(
                    f"❌ {self.target.mention} declined {self.requester.mention}'s request",
                    EmberColors.ERROR,
                )

        view = DragmeView(requester, target, self.bot, request_key, hidden=False, cog_ref=self)

        try:
            view.msg = await target_channel.send(content=f"{target.mention}", view=view)
            asyncio.create_task(delete_message_after(view.msg, config.TIMEOUT_DURATION + 5))

        except (discord.Forbidden, discord.HTTPException):
            dragme_channel = self.bot.get_channel(config.DRAGME_CHANNEL_ID)
            if dragme_channel:
                view = DragmeView(
                    requester, target, self.bot, request_key, hidden=True, cog_ref=self
                )
                view.msg = await dragme_channel.send(content=f"{target.mention}", view=view)
                asyncio.create_task(delete_message_after(view.msg, config.TIMEOUT_DURATION + 5))

        except Exception as e:
            async with self.requests_lock:
                if request_key in self.active_requests:
                    self.active_requests.remove(request_key)
                    await self._persist_requests()
            log.error("Error in drag request: %s", e)

    async def channel_cleanup_task(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                if config.DRAGME_CHANNEL_ID:
                    channel = self.bot.get_channel(config.DRAGME_CHANNEL_ID)
                    if channel:
                        async for message in channel.history(limit=50):
                            if message.author == self.bot.user:
                                if (
                                    discord.utils.utcnow() - message.created_at
                                ).total_seconds() > 60:
                                    try:
                                        await message.delete()
                                    except Exception:
                                        pass
            except Exception:
                pass
            await asyncio.sleep(300)

    async def cleanup_orphaned_requests(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                for guild in self.bot.guilds:
                    async with self.requests_lock:
                        updated_requests = []
                        for request in self.active_requests[:]:
                            requester = guild.get_member(request["requester"])
                            target = guild.get_member(request["target"])
                            if (
                                not requester
                                or not target
                                or not requester.voice
                                or not target.voice
                                or requester.voice.channel == target.voice.channel
                            ):
                                continue
                            updated_requests.append(request)

                        if len(updated_requests) != len(self.active_requests):
                            self.active_requests.clear()
                            self.active_requests.extend(updated_requests)
                            await self._persist_requests()

                await asyncio.sleep(300)
            except Exception:
                await asyncio.sleep(60)

    @commands.Cog.listener()
    async def on_message(self, message):
        if not config.DRAGME_CHANNEL_ID:
            return
        if message.channel.id != config.DRAGME_CHANNEL_ID:
            return
        if not message.guild:
            return
        if not await self.db.guild(message.guild.id).is_enabled():
            return
        if message.author.bot:
            asyncio.create_task(delete_message_after(message, config.MESSAGE_CLEANUP_DELAY))
            return

        user_id = extract_user_id(message.content)
        if not user_id:
            error_msg = await message.channel.send(
                f"{message.author.mention} ❌ Please mention a user or provide a user ID!\n"
                f"Examples: `@username` or `<@123456789>` or `123456789`",
                delete_after=8,
            )
            asyncio.create_task(delete_message_after(error_msg, 8))
            return

        target = message.guild.get_member(user_id)
        if not target:
            error_msg = await message.channel.send(
                f"{message.author.mention} ❌ Could not find that user in this server!",
                delete_after=8,
            )
            asyncio.create_task(delete_message_after(error_msg, 8))
            return

        await self.process_drag_request(
            message.channel,
            message.author,
            target,
        )

    @commands.hybrid_command(name="active_requests", description="View all active dragme requests")
    @app_commands.default_permissions(manage_guild=True)
    @checks.manage_guild()
    async def active_requests_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        async with self.requests_lock:
            if not self.active_requests:
                return await interaction.followup.send(
                    "No active requests right now.", ephemeral=True
                )

            children = [
                discord.ui.TextDisplay("## 📋 Active DragMe Requests"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            ]

            for request in self.active_requests:
                requester = interaction.guild.get_member(request["requester"])
                target = interaction.guild.get_member(request["target"])
                if requester and target:
                    children.append(
                        discord.ui.TextDisplay(
                            f"**{requester.display_name} → {target.display_name}**\n"
                            f"Requester: {requester.mention}\n"
                            f"Target: {target.mention}"
                        )
                    )

            view = discord.ui.LayoutView(timeout=None)
            view.add_item(discord.ui.Container(*children, accent_color=discord.Color.blurple()))
            await interaction.followup.send(view=view, ephemeral=True)

    @commands.hybrid_command(
        name="clean_dragme", description="Clean all bot messages in the dragme channel"
    )
    @commands.has_permissions(manage_messages=True)
    async def clean_dragme(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        if not config.DRAGME_CHANNEL_ID:
            return await interaction.followup.send(
                view=make_error_card("❌ Error", "DragMe channel not configured"), ephemeral=True
            )

        channel = self.bot.get_channel(config.DRAGME_CHANNEL_ID)
        if not channel:
            return await interaction.followup.send(
                view=make_error_card("❌ Error", "DragMe channel not found"), ephemeral=True
            )

        deleted = 0
        async for message in channel.history(limit=100):
            if message.author == self.bot.user:
                try:
                    await message.delete()
                    deleted += 1
                    await asyncio.sleep(0.5)
                except Exception:
                    pass

        await interaction.followup.send(
            f"✅ Cleaned {deleted} bot messages from {channel.mention}", ephemeral=True
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(DragmeCog(bot))
