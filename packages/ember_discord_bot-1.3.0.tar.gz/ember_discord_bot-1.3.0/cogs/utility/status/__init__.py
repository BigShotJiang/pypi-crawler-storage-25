from .cog import CustomStatusRotator


async def setup(bot):
    await bot.add_cog(CustomStatusRotator(bot))
