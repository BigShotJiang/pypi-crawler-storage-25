from typing import TypedDict


class StatusGuildConfig(TypedDict, total=False):
    """Guild-level status configuration."""

    enabled: bool
