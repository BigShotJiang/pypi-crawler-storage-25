"""CustomStatusRotator — rotates bot presence status on a timer."""

from __future__ import annotations

import os
import random

import discord
from discord.ext import commands, tasks

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import feature

from .schema import StatusGuildConfig

_ = Translator("status", __file__)

DURATION = int(os.getenv("STATUS_ROTATION_INTERVAL", "120"))

_DEFAULT_STATUSES = [
    "Chilling at The Aakhri Station",
    "Meow Meow Cuddles?",
    "LEMME CATCH THE CATS!!",
    "Living the bot life",
]


def _load_statuses() -> list[str]:
    raw = os.getenv("BOT_STATUSES", "")
    if raw:
        return [s.strip() for s in raw.split("|") if s.strip()]
    return _DEFAULT_STATUSES


@cog_i18n(_)
@feature(
    display_name="Status Rotator",
    description="Rotates the bot Discord presence through a list of custom status messages.",
    emoji="🔄",
    fields=[],
)
class CustomStatusRotator(EmberCog, name="StatusRotator"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._statuses = _load_statuses()
        self._queue: list[str] = []
        self._last: str | None = None
        self.db.register_schema("guild", StatusGuildConfig)

    def _next(self) -> str:
        if not self._queue:
            self._queue = self._statuses.copy()
            random.shuffle(self._queue)
        nxt = self._queue.pop(0)
        if nxt == self._last and self._queue:
            alt = random.choice(self._queue)
            self._queue[self._queue.index(alt)] = nxt
            nxt = alt
        self._last = nxt
        return nxt

    async def cog_load(self):

        self.rotate.start()

    async def cog_unload(self) -> None:
        self.rotate.cancel()

    @tasks.loop(seconds=DURATION)
    async def rotate(self):
        await self.bot.change_presence(
            status=discord.Status.idle,
            activity=discord.CustomActivity(name=self._next()),
        )

    @rotate.before_loop
    async def before_rotate(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(CustomStatusRotator(bot))
