from typing import TypedDict


class ThreadCleanerGuildConfig(TypedDict, total=False):
    """Guild-level thread_cleaner configuration."""

    enabled: bool
