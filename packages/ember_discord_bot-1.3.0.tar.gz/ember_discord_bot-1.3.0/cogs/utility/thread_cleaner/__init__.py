from .cog import ThreadCleanerCog


async def setup(bot):
    await bot.add_cog(ThreadCleanerCog(bot))
