import asyncio
import logging
import time

import discord
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import ThreadCleanerGuildConfig

_ = Translator("thread_cleaner", __file__)

log = logging.getLogger("ember.thread_cleaner")


@cog_i18n(_)
@feature(
    display_name="Thread Cleaner",
    description="Automatically removes non-bot users from managed threads after a configurable timeout.",
    emoji="🧹",
    fields=[
        ConfigField(
            key="enabled",
            label="Enabled",
            type=FieldType.BOOLEAN,
            default=True,
            description="Enable or disable thread cleaning for this server.",
        ),
        ConfigField(
            key="channel_ids",
            label="Monitored Channel IDs",
            type=FieldType.STRING,
            placeholder="123,456,789",
            description="Comma-separated parent channel IDs whose threads are monitored.",
        ),
        ConfigField(
            key="timeout_secs",
            label="Timeout (seconds)",
            type=FieldType.INTEGER,
            placeholder="86400",
            default=86400,
            description="Seconds after thread creation before members are removed.",
        ),
        ConfigField(
            key="check_interval",
            label="Check Interval (seconds)",
            type=FieldType.INTEGER,
            placeholder="900",
            default=900,
            description="How often the cleanup job runs (bot-wide).",
        ),
    ],
)
class ThreadCleanerCog(EmberCog, name="ThreadCleaner"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "enabled": True,
                    "channel_ids": "",
                    "timeout_secs": 86400,
                    "check_interval": 900,
                },
            }
        )
        self._task: asyncio.Task | None = None
        self.db.register_schema("guild", ThreadCleanerGuildConfig)

    async def cog_load(self):
        await super().cog_load()

        await self._init_db()
        self._task = asyncio.create_task(self._loop(), name="thread_cleaner")
        log.info("ThreadCleaner started")

    async def cog_unload(self):
        if self._task and not self._task.done():
            self._task.cancel()

    async def _init_db(self):
        # Tables are implicitly created by Store when first used via store() / find() / etc.
        pass

    def _parse_channel_ids(self, raw: str) -> set[int]:
        ids = set()
        for part in (raw or "").split(","):
            part = part.strip()
            if part.isdigit():
                ids.add(int(part))
        return ids

    async def _track_thread(self, thread: discord.Thread):
        # Only track if not already present
        existing = await self.db.find_one("thread_metadata", thread_id=thread.id)
        if not existing:
            await self.db.store(
                "thread_metadata",
                {
                    "thread_id": thread.id,
                    "channel_id": thread.parent_id,
                    "guild_id": thread.guild.id,
                    "created_at": time.time(),
                },
            )

    async def _log_removal(self, user_id: int, thread_id: int):
        await self.db.store(
            "thread_removals",
            {
                "user_id": user_id,
                "thread_id": thread_id,
                "removed_at": time.time(),
            },
        )

    @commands.Cog.listener()
    async def on_thread_create(self, thread: discord.Thread):
        if not thread.guild:
            return
        cfg = await self.db.guild(thread.guild.id).all()
        if not cfg.get("enabled", True):
            return
        channel_ids = self._parse_channel_ids(cfg.get("channel_ids", ""))
        if thread.parent_id in channel_ids:
            await self._track_thread(thread)

    async def _loop(self):
        await self.bot.wait_until_ready()
        while True:
            try:
                await self._run_cleanup()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error("Cleanup error: %s", e, exc_info=True)
            # Use the shortest configured interval across all guilds (min 60s)
            intervals = []
            for guild in self.bot.guilds:
                cfg = await self.db.guild(guild.id).all()
                iv = cfg.get("check_interval", 900)
                intervals.append(iv)
            await asyncio.sleep(min(intervals) if intervals else 900)

    async def _run_cleanup(self):
        # Build per-guild config map
        guild_configs: dict[int, tuple[set[int], float]] = {}
        for guild in self.bot.guilds:
            cfg = await self.db.guild(guild.id).all()
            if not cfg.get("enabled", True):
                continue
            channel_ids = self._parse_channel_ids(cfg.get("channel_ids", ""))
            if not channel_ids:
                continue
            timeout = cfg.get("timeout_secs", 86400) or 86400
            guild_configs[guild.id] = (channel_ids, float(timeout))

        if not guild_configs:
            return

        # Find the earliest cutoff across all guilds
        earliest_cutoff = min(time.time() - t for _, t in guild_configs.values())

        # Get all thread metadata and filter by cutoff in Python (driver-agnostic)
        all_rows = await self.db.find("thread_metadata")
        rows = [r for r in all_rows if r.get("created_at", 0) < earliest_cutoff]

        for row in rows:
            gid = row.get("guild_id")
            if gid not in guild_configs:
                continue
            channel_ids, timeout = guild_configs[gid]
            if row.get("channel_id") not in channel_ids:
                continue
            thread = self.bot.get_channel(row.get("thread_id"))
            if not isinstance(thread, discord.Thread):
                continue
            await self._clean_thread(thread)

    async def _clean_thread(self, thread: discord.Thread):
        try:
            members = thread.members or await thread.fetch_members()
        except Exception:
            return

        for member in members:
            user = self.bot.get_user(member.id)
            if user and user.bot:
                continue
            try:
                await thread.remove_user(discord.Object(id=member.id))
                await self._log_removal(member.id, thread.id)
            except (discord.Forbidden, discord.HTTPException):
                pass

        # Clean up the thread metadata record
        await self.db.remove("thread_metadata", thread_id=thread.id)


async def setup(bot):
    await bot.add_cog(ThreadCleanerCog(bot))
