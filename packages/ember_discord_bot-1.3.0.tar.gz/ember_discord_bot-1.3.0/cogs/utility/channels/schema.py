from typing import TypedDict


class CatBotGuildConfig(TypedDict, total=False):
    """Guild-level catbot configuration."""

    cat_delete_delay: int
