"""Channel utility cogs — cat_bot, no_text, study_roles, suppress_instagram."""

from __future__ import annotations

import asyncio
import re

import discord
from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import CatBotGuildConfig

_ = Translator("channels", __file__)

_CAT_RE = re.compile(
    r"(cought.*cat|cat.*cought|fella.*cought|☔.*cats|</rain:\d+>)",
    re.IGNORECASE | re.DOTALL,
)


@cog_i18n(_)
@feature(
    display_name="Channel Utilities",
    description="Auto-replies, no-text enforcement, study-role assignment, and Instagram embed suppression.",
    emoji="📡",
    fields=[
        ConfigField(
            key="cat_delete_delay",
            label="Cat Message Delete Delay (s)",
            type=FieldType.INTEGER,
            placeholder="20",
            default=20,
            description="Seconds before deleting caught-cat bot messages.",
        ),
    ],
)
class CatBot(EmberCog, name="CatBot"):
    """Delete bot 'caught cat' messages after a short delay."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.register_schema("guild", CatBotGuildConfig)
        self.db.defaults(
            {
                "guild": {"cat_delete_delay": 20},
            }
        )

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass

    async def on_message(self, message: discord.Message):
        if not message.author.bot or not message.guild:
            return
        if _CAT_RE.search(message.content or ""):
            delay = await self.db.get("guild", message.guild.id, "cat_delete_delay", default=20)
            await asyncio.sleep(delay)
            try:
                await message.delete()
            except (discord.NotFound, discord.Forbidden):
                pass


@cog_i18n(_)
class NoText(EmberCog):
    pass


@cog_i18n(_)
class StudyRoles(EmberCog):
    pass


@cog_i18n(_)
class SuppressInstagram(EmberCog):
    pass


async def setup(bot: commands.Bot):
    await bot.add_cog(CatBot(bot))
    await bot.add_cog(NoText(bot))
    await bot.add_cog(StudyRoles(bot))
    await bot.add_cog(SuppressInstagram(bot))
