import logging

from ..database import TempVCDB, get_db

logger = logging.getLogger("ember.tempvc.service")


class TempVCService:
    """Business logic for temporary voice channel management."""

    def __init__(self):
        self._store = None

    def _db(self) -> TempVCDB | None:
        return TempVCDB(self._store) if self._store is not None else None

    async def init_db(self):
        """Initialize the TempVC database."""
        db = await get_db()
        await db.initialize()

    async def get_voice_channel(self, voice_id: int) -> dict | None:
        """Get voice channel data by voice ID."""
        db = await get_db()
        return await db.get_channel(voice_id)

    async def save_voice_channel(
        self,
        guild_id: int,
        user_id: int,
        voice_id: int,
        vc_type: str,
        channel_number: int,
        name: str,
        limit: int,
    ):
        """Save voice channel data."""
        db = await get_db()
        await db.save_channel(guild_id, user_id, voice_id, vc_type, channel_number, name, limit)

    async def delete_voice_channel(self, voice_id: int) -> int:
        """Delete voice channel data and return number of rows deleted."""
        db = await get_db()
        return await db.delete_channel(voice_id)

    async def get_user_channels(self, user_id: int) -> list[dict]:
        """Get all voice channels created by a user."""
        if (db := self._db()) is not None:
            return await db.get_user_channels(user_id)
        db = await get_db()
        return await db.get_user_channels(user_id)

    async def save_channel(
        self,
        guild_id: int,
        user_id: int,
        voice_id: int,
        vc_type: str,
        channel_number: int,
        name: str,
        limit: int,
    ) -> None:
        if (db := self._db()) is not None:
            await db.save_channel(guild_id, user_id, voice_id, vc_type, channel_number, name, limit)
            return
        db = await get_db()
        await db.save_channel(guild_id, user_id, voice_id, vc_type, channel_number, name, limit)

    async def get_channel(self, voice_id: int) -> dict | None:
        if (db := self._db()) is not None:
            return await db.get_channel(voice_id)
        db = await get_db()
        return await db.get_channel(voice_id)

    async def delete_channel(self, voice_id: int) -> int:
        if (db := self._db()) is not None:
            return await db.delete_channel(voice_id)
        db = await get_db()
        return await db.delete_channel(voice_id)

    async def channel_owner(self, voice_id: int) -> int | None:
        channel = await self.get_channel(voice_id)
        return channel["userID"] if channel else None
