import discord

from utils.cards import make_error_card

from .database import get_db


class LimitModal(discord.ui.Modal, title="Set User Limit"):
    def __init__(self, cog, channel, is_gaming: bool = False):
        super().__init__()
        self.cog = cog
        self.channel = channel
        self.db_name = "tempvc_gaming" if is_gaming else "tempvc"

        self.limit_input = discord.ui.TextInput(
            label="User Limit (0-99)",
            placeholder="Enter 0 for no limit...",
            default=str(channel.user_limit if channel.user_limit else 0),
            max_length=2,
            required=True,
        )
        self.add_item(self.limit_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            limit = int(self.limit_input.value)
            if limit < 0 or limit > 99:
                await interaction.followup.send(
                    view=make_error_card("❌ Error", "Limit must be between 0 and 99"),
                    ephemeral=True,
                )
                return

            await self.channel.edit(user_limit=limit if limit > 0 else None)
            db = await get_db(self.db_name)
            await db.update_channel_limit(self.channel.id, limit if limit > 0 else None)
            await interaction.followup.send(
                f"✅ User limit set to {limit}!" if limit > 0 else "✅ User limit removed!",
                ephemeral=True,
            )
        except ValueError:
            await interaction.followup.send(
                view=make_error_card("❌ Error", "Please enter a valid number"), ephemeral=True
            )


class RenameModal(discord.ui.Modal, title="Rename Voice Channel"):
    def __init__(self, cog, channel, is_gaming: bool = False):
        super().__init__()
        self.cog = cog
        self.channel = channel
        self.db_name = "tempvc_gaming" if is_gaming else "tempvc"

        self.name_input = discord.ui.TextInput(
            label="New Channel Name",
            placeholder="Enter new name...",
            default=channel.name,
            max_length=100,
            required=True,
        )
        self.add_item(self.name_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        name = self.name_input.value.strip()
        if not name:
            await interaction.followup.send(
                view=make_error_card("❌ Error", "Please provide a valid name"), ephemeral=True
            )
            return

        old_name = self.channel.name
        await self.channel.edit(name=name)
        db = await get_db(self.db_name)
        await db.update_channel_name(self.channel.id, name)
        await interaction.followup.send(f"✏️ Renamed `{old_name}` to `{name}`", ephemeral=True)
