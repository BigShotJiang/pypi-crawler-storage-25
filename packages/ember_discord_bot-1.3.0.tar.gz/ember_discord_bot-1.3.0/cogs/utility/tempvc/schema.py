from typing import TypedDict


class TempvcGuildConfig(TypedDict, total=False):
    """Guild-level tempvc configuration."""

    enabled: bool
