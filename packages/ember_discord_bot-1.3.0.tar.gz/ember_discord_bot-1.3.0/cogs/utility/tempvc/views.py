import logging
import time

import discord
from discord import ui
from discord.ui import Button, UserSelect, View

from core.branding import EmberColors
from utils.cards import make_error_card, make_success_card

from .modals import LimitModal, RenameModal

log = logging.getLogger("ember.tempvc")


def _has_allow(overwrite: discord.PermissionOverwrite) -> bool:
    return any(
        getattr(overwrite, p) is True for p in ("connect", "view_channel", "speak", "stream")
    )


def _has_deny(overwrite: discord.PermissionOverwrite) -> bool:
    return any(
        getattr(overwrite, p) is False for p in ("connect", "view_channel", "speak", "stream")
    )


async def _update_voice_channel(cog, channel_id: int, **kwargs) -> None:
    if not kwargs:
        return
    await cog.db.update_one("voice_channel", kwargs, voiceID=channel_id)


def _owner_denied(interaction: discord.Interaction) -> bool:
    return False  # ownership checked per-button via stored owner_id


class _VCButton(Button):
    """Base button that carries its own channel/owner context."""

    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool, **kwargs):
        super().__init__(**kwargs)
        self.cog = cog
        self.channel_id = channel_id
        self.owner_id = owner_id
        self.is_gaming = is_gaming

    async def _check_owner(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                view=make_error_card("❌ Error", "Only the VC owner can use these controls"),
                ephemeral=True,
            )
            return False
        return True

    def _get_channel(self, interaction: discord.Interaction) -> discord.VoiceChannel | None:
        return interaction.guild.get_channel(self.channel_id)


class NameButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="👤 Name",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_name_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )
        await interaction.response.send_modal(
            RenameModal(self.cog, channel, is_gaming=self.is_gaming)
        )


class LimitButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="👥 Limit",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_limit_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )
        await interaction.response.send_modal(
            LimitModal(self.cog, channel, is_gaming=self.is_gaming)
        )


class DeleteButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="🗑️ Delete",
            style=discord.ButtonStyle.danger,
            custom_id=f"vc_delete_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        confirm_view = View(timeout=60)
        _cog, channel_id, _is_gaming = self.cog, self.channel_id, self.is_gaming

        async def confirm_cb(ci: discord.Interaction):
            await ci.response.defer(ephemeral=True)
            try:
                await _cog.db.remove("voice_channel", voiceID=channel_id)
                await channel.delete(reason="VC owner requested deletion")
                await ci.followup.send(
                    view=make_success_card("✅ Done", "Voice channel deleted"), ephemeral=True
                )
            except Exception as e:
                log.error(f"[TempVoice] Error deleting channel: {e}")
                await ci.followup.send(
                    view=make_error_card("❌ Error", "Failed to delete channel"), ephemeral=True
                )

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Deletion cancelled.", view=None)

        confirm_btn = Button(label="✅ Confirm Delete", style=discord.ButtonStyle.danger)
        confirm_btn.callback = confirm_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
        cancel_btn.callback = cancel_cb
        confirm_view.add_item(confirm_btn)
        confirm_view.add_item(cancel_btn)

        await interaction.response.send_message(
            "⚠️ Are you sure you want to delete this voice channel? This action cannot be undone!",
            view=confirm_view,
            ephemeral=True,
        )


class LockButton(_VCButton):
    def __init__(
        self,
        cog,
        channel_id: int,
        owner_id: int,
        is_gaming: bool = False,
        *,
        is_locked: bool = False,
    ):
        label = "🔓 Unlock" if is_locked else "🔒 Lock"
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label=label,
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_lock_{channel_id}",
        )
        self.is_locked = is_locked

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)
        current = channel.overwrites_for(interaction.guild.default_role)

        if self.is_locked:
            await channel.set_permissions(
                interaction.guild.default_role, connect=True, view_channel=current.view_channel
            )
            for member in list(channel.guild.members):
                if member.id == self.owner_id:
                    continue
                ow = channel.overwrites_for(member)
                if ow and (ow.connect is True or ow.view_channel is True):
                    try:
                        await channel.set_permissions(member, overwrite=None)
                    except Exception:
                        pass
            await _update_voice_channel(self.cog, self.channel_id, locked=False)
            msg = "🔓 Channel unlocked!"
        else:
            await channel.set_permissions(
                interaction.guild.default_role, connect=False, view_channel=current.view_channel
            )
            for member in list(channel.members):
                try:
                    await channel.set_permissions(member, connect=True, view_channel=True)
                except Exception:
                    pass
            await _update_voice_channel(self.cog, self.channel_id, locked=True)
            msg = "🔒 Channel locked! Current members kept access."

        new_view = BasicControlsView(self.cog, self.channel_id, self.owner_id, self.is_gaming)
        await interaction.edit_original_response(view=new_view)
        await interaction.followup.send(msg, ephemeral=True)


class HideButton(_VCButton):
    def __init__(
        self,
        cog,
        channel_id: int,
        owner_id: int,
        is_gaming: bool = False,
        *,
        is_hidden: bool = False,
    ):
        label = "👀 Unhide" if is_hidden else "🕵️ Hide"
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label=label,
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_hide_{channel_id}",
        )
        self.is_hidden = is_hidden

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)
        current = channel.overwrites_for(interaction.guild.default_role)

        if self.is_hidden:
            await channel.set_permissions(
                interaction.guild.default_role, view_channel=True, connect=current.connect
            )
            for member in list(channel.guild.members):
                if member.id == self.owner_id:
                    continue
                ow = channel.overwrites_for(member)
                if ow and ow.view_channel is True:
                    try:
                        await channel.set_permissions(member, overwrite=None)
                    except Exception:
                        pass
            await _update_voice_channel(self.cog, self.channel_id, hidden=False)
            msg = "👀 Channel now visible!"
        else:
            await channel.set_permissions(
                interaction.guild.default_role, view_channel=False, connect=current.connect
            )
            for member in list(channel.members):
                try:
                    await channel.set_permissions(member, view_channel=True)
                except Exception:
                    pass
            await _update_voice_channel(self.cog, self.channel_id, hidden=True)
            msg = "🕵️ Channel hidden! Current members can still see it."

        new_view = BasicControlsView(self.cog, self.channel_id, self.owner_id, self.is_gaming)
        await interaction.edit_original_response(view=new_view)
        await interaction.followup.send(msg, ephemeral=True)


class KickButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="👢 Kick",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_kick_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        vc_users = [m for m in channel.members if m.id != self.owner_id]
        if not vc_users:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "No users to kick"), ephemeral=True
            )

        select_view = View(timeout=60)
        select = UserSelect(
            placeholder="Select users to kick...",
            min_values=1,
            max_values=min(25, len(vc_users)),
            row=0,
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            done = []
            for member in select.values:
                if member.voice and member.voice.channel == channel:
                    try:
                        await member.move_to(None)
                        done.append(member.display_name)
                    except Exception as e:
                        log.warning(f"[TempVoice] Kick error: {e}")
            msg = f"👢 Kicked: {', '.join(done)}" if done else "❌ Failed to kick users!"
            await si.followup.send(msg, ephemeral=True)

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Kick cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "Select users to kick:", view=select_view, ephemeral=True
        )


class TrustButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="✅ Trust",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_trust_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        available = [
            m
            for m in channel.guild.members
            if m.id != self.owner_id and not m.bot and not _has_allow(channel.overwrites_for(m))
        ]
        if not available:
            return await interaction.response.send_message(
                view=make_success_card("✅ Done", "All users already have access"), ephemeral=True
            )

        select_view = View(timeout=60)
        select = UserSelect(
            placeholder="Select users to trust...",
            min_values=1,
            max_values=min(25, len(available)),
            row=0,
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            done = []
            for member in select.values:
                try:
                    await channel.set_permissions(
                        member, connect=True, view_channel=True, speak=True, stream=True
                    )
                    done.append(member.display_name)
                except Exception as e:
                    log.warning(f"[TempVoice] Trust error: {e}")
            msg = (
                f"✅ Granted access to: {', '.join(done)}" if done else "❌ Failed to grant access!"
            )
            await si.followup.send(msg, ephemeral=True)

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Trust cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "Select users to trust:", view=select_view, ephemeral=True
        )


class UntrustButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="❌ Untrust",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_untrust_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        trusted = [
            m
            for m in channel.guild.members
            if m.id != self.owner_id and not m.bot and _has_allow(channel.overwrites_for(m))
        ]
        if not trusted:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "No users have trusted access"), ephemeral=True
            )

        select_view = View(timeout=60)
        select = UserSelect(
            placeholder="Select users to untrust...",
            min_values=1,
            max_values=min(25, len(trusted)),
            row=0,
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            done = []
            for member in select.values:
                try:
                    await channel.set_permissions(member, overwrite=None)
                    done.append(member.display_name)
                except Exception as e:
                    log.warning(f"[TempVoice] Untrust error: {e}")
            msg = (
                f"❌ Revoked access from: {', '.join(done)}"
                if done
                else "❌ Failed to revoke access!"
            )
            await si.followup.send(msg, ephemeral=True)

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Untrust cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "Select users to untrust:", view=select_view, ephemeral=True
        )


class BlockButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="🚫 Block",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_block_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        available = [
            m
            for m in channel.guild.members
            if m.id != self.owner_id and not m.bot and not _has_deny(channel.overwrites_for(m))
        ]
        if not available:
            return await interaction.response.send_message(
                view=make_success_card("✅ Done", "All users already blocked"), ephemeral=True
            )

        select_view = View(timeout=60)
        select = UserSelect(
            placeholder="Select users to block...",
            min_values=1,
            max_values=min(25, len(available)),
            row=0,
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            done = []
            for member in select.values:
                try:
                    if member.voice and member.voice.channel == channel:
                        await member.move_to(None)
                    await channel.set_permissions(
                        member, connect=False, view_channel=False, speak=False, stream=False
                    )
                    done.append(member.display_name)
                except Exception as e:
                    log.warning(f"[TempVoice] Block error: {e}")
            msg = f"🚫 Blocked: {', '.join(done)}" if done else "❌ Failed to block users!"
            await si.followup.send(msg, ephemeral=True)

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Block cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "Select users to block:", view=select_view, ephemeral=True
        )


class UnblockButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="✅ Unblock",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_unblock_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        blocked = [
            m
            for m in channel.guild.members
            if m.id != self.owner_id and not m.bot and _has_deny(channel.overwrites_for(m))
        ]
        if not blocked:
            return await interaction.response.send_message(
                view=make_success_card("✅ Done", "No users are blocked"), ephemeral=True
            )

        select_view = View(timeout=60)
        select = UserSelect(
            placeholder="Select users to unblock...",
            min_values=1,
            max_values=min(25, len(blocked)),
            row=0,
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            done = []
            for member in select.values:
                try:
                    await channel.set_permissions(member, overwrite=None)
                    done.append(member.display_name)
                except Exception as e:
                    log.warning(f"[TempVoice] Unblock error: {e}")
            msg = f"✅ Unblocked: {', '.join(done)}" if done else "❌ Failed to unblock users!"
            await si.followup.send(msg, ephemeral=True)

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Unblock cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "Select users to unblock:", view=select_view, ephemeral=True
        )


class TransferButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="🔄 Transfer",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_transfer_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not await self._check_owner(interaction):
            return
        channel = self._get_channel(interaction)
        if not channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "Channel not found"), ephemeral=True
            )

        vc_users = [m for m in channel.members if m.id != self.owner_id and not m.bot]
        if not vc_users:
            return await interaction.response.send_message(
                view=make_error_card(
                    "❌ Error", "No users in the voice channel to transfer ownership to"
                ),
                ephemeral=True,
            )

        select_view = View(timeout=60)
        cog, channel_id, owner_id, is_gaming = (
            self.cog,
            self.channel_id,
            self.owner_id,
            self.is_gaming,
        )
        select = UserSelect(
            placeholder="Select a user to transfer ownership...", min_values=1, max_values=1, row=0
        )

        async def select_cb(si: discord.Interaction):
            await si.response.defer(ephemeral=True)
            new_owner = select.values[0]
            if new_owner not in channel.members:
                return await si.followup.send(
                    view=make_error_card("❌ Error", "That user is no longer in the VC"),
                    ephemeral=True,
                )
            try:
                await cog.db.update_one(
                    "voice_channel", {"userID": new_owner.id}, voiceID=channel_id
                )
                old_owner = interaction.guild.get_member(owner_id)
                if old_owner:
                    await channel.set_permissions(old_owner, manage_channels=False)
                await channel.set_permissions(new_owner, manage_channels=True)

                transfer_view = discord.ui.LayoutView(timeout=None)
                transfer_view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay(
                            f"## 🔄 VC Ownership Transferred\n{new_owner.mention} is now the owner!"
                        ),
                        accent_color=discord.Color.blurple(),
                    )
                )
                await channel.send(view=transfer_view)
                await si.followup.send(
                    f"✅ Transferred ownership to {new_owner.mention}!", ephemeral=True
                )
                try:
                    new_panel = BasicControlsView(cog, channel_id, new_owner.id, is_gaming)
                    await interaction.edit_original_response(view=new_panel)
                except Exception:
                    pass
            except Exception as e:
                log.error(f"[TempVoice] Transfer error: {e}")
                await si.followup.send(
                    view=make_error_card(
                        "❌ Error", "Failed to transfer ownership. Please try again."
                    ),
                    ephemeral=True,
                )

        async def cancel_cb(ci: discord.Interaction):
            await ci.response.edit_message(content="Transfer cancelled.", view=None)

        select.callback = select_cb
        cancel_btn = Button(label="❌ Cancel", style=discord.ButtonStyle.secondary, row=1)
        cancel_btn.callback = cancel_cb
        select_view.add_item(select)
        select_view.add_item(cancel_btn)
        await interaction.response.send_message(
            "👥 Select a user from the VC to transfer ownership to:",
            view=select_view,
            ephemeral=True,
        )


class ClaimButton(_VCButton):
    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(
            cog,
            channel_id,
            owner_id,
            is_gaming,
            label="🎯 Claim",
            style=discord.ButtonStyle.secondary,
            custom_id=f"vc_claim_{channel_id}",
        )

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message(
                view=make_error_card("❌ Error", "You must be in a voice channel to claim it"),
                ephemeral=True,
            )
        if interaction.user.voice.channel.id != self.channel_id:
            return await interaction.response.send_message(
                view=make_error_card(
                    "❌ Error", "You can only claim the channel you're currently in"
                ),
                ephemeral=True,
            )

        await interaction.response.defer(ephemeral=True)
        channel = interaction.user.voice.channel

        join_channels = await self.cog._get_join_channels(channel.guild.id)
        if channel.id in join_channels:
            return await interaction.followup.send(
                view=make_error_card("❌ Error", "Cannot claim a generator channel"), ephemeral=True
            )

        row = await self.cog.db.find_one("voice_channel", voiceID=channel.id)

        if not row:
            return await interaction.followup.send(
                view=make_error_card("❌ Error", "Channel not found in database."), ephemeral=True
            )

        owner_id = row["userID"]
        owner = interaction.guild.get_member(owner_id)

        if owner and owner in channel.members:
            return await interaction.followup.send(
                f"❌ {owner.display_name} is currently here — can't claim!", ephemeral=True
            )

        cog = self.cog
        lock_key = f"claim_{channel.id}"
        now = time.time()
        if now - cog.creation_cooldowns.get(lock_key, 0) < 2:
            return await interaction.followup.send(
                "⏳ Someone else is attempting to claim. Please wait...", ephemeral=True
            )
        cog.creation_cooldowns[lock_key] = now

        try:
            await self.cog.db.update_one(
                "voice_channel", {"userID": interaction.user.id}, voiceID=channel.id
            )
            if owner:
                await channel.set_permissions(owner, manage_channels=False)
            await channel.set_permissions(interaction.user, manage_channels=True)
            self.cog.owner_leave_times.pop(channel.id, None)

            claim_view = discord.ui.LayoutView(timeout=None)
            claim_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay(
                        f"## 🎯 VC Ownership Claimed\n"
                        f"{interaction.user.mention} has claimed ownership of this voice channel!"
                    ),
                    accent_color=EmberColors.SUCCESS,
                )
            )
            await channel.send(view=claim_view)
            await interaction.followup.send(
                f"✅ You have claimed ownership of {channel.mention}!", ephemeral=True
            )

            try:
                new_panel = BasicControlsView(
                    self.cog, self.channel_id, interaction.user.id, self.is_gaming
                )
                async for msg in channel.history(limit=10):
                    if msg.author == interaction.guild.me and msg.components:
                        await msg.edit(view=new_panel)
                        break
            except Exception as e:
                log.warning(f"[TempVoice] Error refreshing panel after claim: {e}")

        except Exception as e:
            log.error(f"[TempVoice] Claim error: {e}")
            await self.cog.db.update_one("voice_channel", {"userID": owner_id}, voiceID=channel.id)
            await interaction.followup.send(
                view=make_error_card("❌ Error", "Failed to claim channel. Please try again."),
                ephemeral=True,
            )
        finally:
            self.cog.creation_cooldowns.pop(lock_key, None)


class VCRow0(ui.ActionRow):
    """Basic: Name, Limit, Delete"""

    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__()
        self.add_item(NameButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(LimitButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(DeleteButton(cog, channel_id, owner_id, is_gaming))


class VCRow1(ui.ActionRow):
    """Privacy: Lock, Hide, Kick"""

    def __init__(
        self,
        cog,
        channel_id: int,
        owner_id: int,
        is_gaming: bool = False,
        *,
        is_locked: bool = False,
        is_hidden: bool = False,
    ):
        super().__init__()
        self.add_item(LockButton(cog, channel_id, owner_id, is_gaming, is_locked=is_locked))
        self.add_item(HideButton(cog, channel_id, owner_id, is_gaming, is_hidden=is_hidden))
        self.add_item(KickButton(cog, channel_id, owner_id, is_gaming))


class VCRow2(ui.ActionRow):
    """Members: Trust, Untrust, Block, Unblock"""

    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__()
        self.add_item(TrustButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(UntrustButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(BlockButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(UnblockButton(cog, channel_id, owner_id, is_gaming))


class VCRow3(ui.ActionRow):
    """Advanced: Transfer, Claim"""

    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__()
        self.add_item(TransferButton(cog, channel_id, owner_id, is_gaming))
        self.add_item(ClaimButton(cog, channel_id, owner_id, is_gaming))


class BasicControlsView(ui.LayoutView):
    """
    Single Components V2 LayoutView with all VC controls.
    Buttons live in ActionRows inside the Container — confessions.py pattern.
    """

    def __init__(self, cog, channel_id: int, owner_id: int, is_gaming: bool = False):
        super().__init__(timeout=None)
        self.cog = cog
        self.channel_id = channel_id
        self.owner_id = owner_id
        self.is_gaming = is_gaming

        channel = cog.bot.get_channel(channel_id)
        is_locked = is_hidden = False
        if channel:
            default_ow = channel.overwrites_for(channel.guild.default_role)
            is_locked = default_ow.connect is False
            is_hidden = default_ow.view_channel is False

        children: list = [
            ui.TextDisplay("## 🎯 Voice Channel Controls"),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay(
                "**📝 Basic —** 👤 Name · 👥 Limit · 🗑️ Delete\n"
                "**🔒 Privacy —** Lock/Unlock · Hide/Unhide · 👢 Kick\n"
                "**👥 Members —** ✅ Trust · ❌ Untrust · 🚫 Block · ✅ Unblock\n"
                "**🔄 Advanced —** Transfer · 🎯 Claim"
            ),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay("-# Only the VC owner can use these controls"),
            VCRow0(cog, channel_id, owner_id, is_gaming),
            VCRow1(cog, channel_id, owner_id, is_gaming, is_locked=is_locked, is_hidden=is_hidden),
            VCRow2(cog, channel_id, owner_id, is_gaming),
            VCRow3(cog, channel_id, owner_id, is_gaming),
        ]

        self.add_item(ui.Container(*children, accent_color=EmberColors.WARNING))
