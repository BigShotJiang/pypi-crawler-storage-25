import logging
import time
from typing import Any

from core.store import Store

logger = logging.getLogger("ember.tempvc")


class TempVCDB:
    """TempVC data layer using Store document API."""

    def __init__(self, store: Store):
        self.store = store

    async def initialize(self) -> None:
        """Initialize database (document store is auto-created)."""
        logger.info("TempVC database initialized")

    async def get_channel(self, voice_id: int) -> dict[str, Any] | None:
        """Get a voice channel by ID."""
        return await self.store.find_one("voiceChannel", voiceID=voice_id)

    async def get_user_channels(self, user_id: int) -> list[dict[str, Any]]:
        """Get all voice channels owned by a user."""
        return await self.store.find("voiceChannel", userID=user_id)

    async def get_guild_channels(self, guild_id: int) -> list[dict[str, Any]]:
        """Get all voice channels in a guild."""
        return await self.store.find("voiceChannel", guildID=guild_id)

    async def get_all_channels(self) -> list[dict[str, Any]]:
        """Get all voice channels."""
        return await self.store.find("voiceChannel")

    async def save_channel(
        self,
        guild_id: int,
        user_id: int,
        voice_id: int,
        vc_type: str,
        channel_number: int,
        name: str,
        limit: int,
    ) -> None:
        """Save or update a voice channel."""
        await self.store.store(
            "voiceChannel",
            {
                "guildID": guild_id,
                "userID": user_id,
                "voiceID": voice_id,
                "vcType": vc_type,
                "channelNumber": channel_number,
                "channelName": name,
                "channelLimit": limit,
                "locked": False,
                "hidden": False,
                "created_at": int(time.time()),
            },
            pk_columns=["voiceID"],
        )

    async def update_channel_name(self, voice_id: int, name: str) -> None:
        """Update a channel's name."""
        channel = await self.store.find_one("voiceChannel", voiceID=voice_id)
        if channel:
            channel["channelName"] = name
            await self.store.store("voiceChannel", channel)

    async def update_channel_limit(self, voice_id: int, limit: int | None) -> None:
        """Update a channel's member limit."""
        channel = await self.store.find_one("voiceChannel", voiceID=voice_id)
        if channel:
            channel["channelLimit"] = limit or 0
            await self.store.store("voiceChannel", channel)

    async def delete_channel(self, voice_id: int) -> int:
        """Delete a voice channel."""
        return await self.store.remove("voiceChannel", voiceID=voice_id)

    async def delete_channels(self, voice_ids: list[int]) -> int:
        """Delete multiple voice channels."""
        count = 0
        for voice_id in voice_ids:
            count += await self.store.remove("voiceChannel", voiceID=voice_id)
        return count

    async def channel_owner(self, voice_id: int) -> int | None:
        """Get the owner (user ID) of a voice channel."""
        channel = await self.store.find_one("voiceChannel", voiceID=voice_id)
        return channel.get("userID") if channel else None

    async def delete_user_data(self, user_id: int) -> None:
        """Delete all tempvc data for a user (GDPR compliance)."""
        await self.store.remove("voiceChannel", userID=user_id)


# Module-level singleton
_db: TempVCDB | None = None


async def get_db() -> TempVCDB:
    """Get or create the TempVC database singleton."""
    global _db
    if _db is None:
        store = Store("tempvc")
        _db = TempVCDB(store)
        await _db.initialize()
    return _db
