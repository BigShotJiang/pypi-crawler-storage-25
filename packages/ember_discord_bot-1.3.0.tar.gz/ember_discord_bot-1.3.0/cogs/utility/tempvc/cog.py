import asyncio
import logging
import re
import time
from collections import deque

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.branding import EmberColors
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator, cog_i18n
from utils.cards import make_error_card
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import TempvcGuildConfig
from .views import BasicControlsView

_ = Translator("tempvc", __file__)
log = logging.getLogger("ember.tempvc")


@cog_i18n(_)
@feature(
    display_name="Temp Voice Channels",
    description="Creates on-demand temporary voice channels that disappear when everyone leaves.",
    emoji="🔊",
    fields=[
        ConfigField(
            key="category_id",
            label="Voice Category",
            type=FieldType.CHANNEL,
            channel_types=[discord.ChannelType.category],
            description="Category where temp voice channels are created.",
        ),
        ConfigField(
            key="drag_requests_channel_id",
            label="Drag Requests Channel",
            type=FieldType.CHANNEL,
            description="Text channel for drag-to-vc requests (optional).",
        ),
        ConfigField(
            key="duo_channel_id",
            label="Duo Join Channel",
            type=FieldType.CHANNEL,
            description="Join this channel to create a Duo (2-person) temp VC.",
        ),
        ConfigField(
            key="trio_channel_id",
            label="Trio Join Channel",
            type=FieldType.CHANNEL,
            description="Join this channel to create a Trio (3-person) temp VC.",
        ),
        ConfigField(
            key="squad_channel_id",
            label="Squad Join Channel",
            type=FieldType.CHANNEL,
            description="Join this channel to create a Squad (4-person) temp VC.",
        ),
    ],
)
class TempVoice(EmberCog, name="TempVoice"):

    tempvc = app_commands.Group(name="tempvc", description="Temporary voice channel commands")

    def __init__(self, bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "enabled": True,
                    "category_id": None,
                    "drag_requests_channel_id": None,
                    "duo_channel_id": None,
                    "trio_channel_id": None,
                    "squad_channel_id": None,
                },
            }
        )
        self.db.register_table("""
            CREATE TABLE IF NOT EXISTS voice_channel (
                voiceID INTEGER PRIMARY KEY,
                guildID INTEGER NOT NULL,
                userID INTEGER NOT NULL,
                vcType TEXT NOT NULL,
                channelNumber INTEGER NOT NULL,
                channelName TEXT NOT NULL,
                channelLimit INTEGER,
                locked BOOLEAN DEFAULT 0,
                hidden BOOLEAN DEFAULT 0,
                created_at INTEGER
            )
        """)
        self._join_channel_cache: dict[int, dict[int, tuple[str, int]]] = {}
        self._vc_creation_lock = asyncio.Lock()
        self.creation_cooldowns = {}
        self.cleanup_tasks = {}
        self.creation_queues = {}
        self.queue_locks = {}
        self.cleanup_locks = {}
        self.owner_leave_times = {}
        self.type_order = {"Duo": 1, "Trio": 2, "Squad": 3, "Other": 4}

        self._channel_cache = {}
        self._last_cache_update = {}
        self._cache_ttl = 5
        self.db.register_schema("guild", TempvcGuildConfig)

    async def _get_join_channels(self, guild_id: int) -> dict[int, tuple[str, int]]:
        if guild_id in self._join_channel_cache:
            return self._join_channel_cache[guild_id]
        cfg = await self.db.guild(guild_id).all()
        mapping: dict[int, tuple[str, int]] = {}
        for key, name, limit in [
            ("duo_channel_id", "Duo", 2),
            ("trio_channel_id", "Trio", 3),
            ("squad_channel_id", "Squad", 4),
        ]:
            cid = cfg.get(key)
            if cid:
                mapping[cid] = (name, limit)
        self._join_channel_cache[guild_id] = mapping
        return mapping

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        self._join_channel_cache.pop(getattr(after, "guild", None) and after.guild.id, None)

    async def cog_load(self):
        await super().cog_load()
        register_data_callbacks(self)
        self._heartbeat.start()

        try:
            rows = await self.db.find("voice_channel")
            for row in rows:
                voice_id, user_id = row.get("voiceID"), row.get("userID")
                if voice_id and user_id:
                    channel = self.bot.get_channel(voice_id)
                    if channel:
                        view = BasicControlsView(self, voice_id, user_id)
                        self.bot.add_view(view)
        except Exception as e:
            log.error("Error loading persistent views: %s", e)

    async def cog_unload(self) -> None:
        self._heartbeat.cancel()

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        await self.db.remove("voice_channel", userID=user_id)
        return {}

    @tasks.loop(minutes=10)
    async def _heartbeat(self):
        pass

    @_heartbeat.before_loop
    async def _wait_ready(self):
        await self.bot.wait_until_ready()

    def _ensure_structs(self, join_id, guild_id):
        if join_id not in self.creation_queues:
            self.creation_queues[join_id] = deque(maxlen=100)
        if join_id not in self.queue_locks:
            self.queue_locks[join_id] = asyncio.Lock()
        if guild_id not in self.cleanup_locks:
            self.cleanup_locks[guild_id] = asyncio.Lock()

    def _cooldown_ok(self, user_id, cooldown=30):
        now = time.time()
        last = self.creation_cooldowns.get(user_id, 0)
        if now - last < cooldown:
            return False, cooldown - (now - last)
        self.creation_cooldowns[user_id] = now
        return True, 0

    async def _get_cached_channels(self, guild_id, force_refresh=False):
        now = time.time()

        if (
            not force_refresh
            and guild_id in self._channel_cache
            and guild_id in self._last_cache_update
            and now - self._last_cache_update[guild_id] < self._cache_ttl
        ):
            return self._channel_cache[guild_id].copy()

        rows = await self.db.find("voice_channel", guildID=guild_id)

        cache = {row["voiceID"]: (row["vcType"], row["channelNumber"]) for row in rows}
        self._channel_cache[guild_id] = cache
        self._last_cache_update[guild_id] = now
        return cache

    def _update_cache(self, guild_id, voice_id, vc_type, channel_num):
        if guild_id in self._channel_cache:
            self._channel_cache[guild_id][voice_id] = (vc_type, channel_num)

    def _remove_from_cache(self, guild_id, voice_id):
        if guild_id in self._channel_cache:
            self._channel_cache[guild_id].pop(voice_id, None)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if not member or member.bot:
            return

        if not await self.db.guild(member.guild.id).is_enabled():
            return

        if after.channel and after.channel.id in self.owner_leave_times:
            if after.channel.guild.id in self._channel_cache:
                cached = self._channel_cache[after.channel.guild.id]
                if after.channel.id in cached:
                    data = await self.db.find_one(
                        "voice_channel", voiceID=after.channel.id, userID=member.id
                    )
                    if data:
                        self.owner_leave_times.pop(after.channel.id, None)

        if before.channel:
            guild_cache = await self._get_cached_channels(before.channel.guild.id)
            if before.channel.id in guild_cache:
                data = await self.db.find_one(
                    "voice_channel", voiceID=before.channel.id, userID=member.id
                )
                if data:
                    self.owner_leave_times[before.channel.id] = time.time()

        join_channels = await self._get_join_channels(member.guild.id)
        if after.channel and after.channel.id in join_channels:
            join_id = after.channel.id
            guild_id = member.guild.id
            self._ensure_structs(join_id, guild_id)

            self.creation_queues[join_id].append((member, after.channel))

            if len(self.creation_queues[join_id]) == 1:
                asyncio.create_task(self._queue_worker(join_id))

        if before.channel and before.channel != after.channel:
            guild_cache = await self._get_cached_channels(before.channel.guild.id)
            if before.channel.id in guild_cache:
                asyncio.create_task(self._schedule_cleanup(before.channel))

    async def _queue_worker(self, join_id):
        async with self.queue_locks[join_id]:
            queue = self.creation_queues[join_id]
            while queue:
                member, channel = queue.popleft()
                try:
                    await self._process_creation(member, channel)
                    await asyncio.sleep(2.0)
                except Exception as e:
                    log.error("Queue task error: %s", e)
                await asyncio.sleep(0.5)

    async def _process_creation(self, member, join_channel):
        ok, wait = self._cooldown_ok(member.id)
        if not ok:
            try:
                await member.move_to(None)
                view = discord.ui.LayoutView(timeout=None)
                view.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay(
                            f"⏳ Slow down — wait {wait:.1f}s before creating another channel."
                        ),
                        accent_color=EmberColors.WARNING,
                    )
                )
                await member.send(view=view)
            except Exception:
                pass
            return

        try:
            await asyncio.gather(
                self._cleanup_ghost(member.guild), self._cleanup_empty(member.guild)
            )
            await self._create_vc(member, join_channel)
        except Exception as e:
            log.error("VC creation error: %s", e)

    async def _create_vc(self, member, join_channel):
        guild = member.guild
        category = join_channel.category

        join_channels = await self._get_join_channels(guild.id)
        base_name, limit = join_channels.get(join_channel.id, ("VC ", 0))
        clean_base = base_name.strip()

        vc_type = "Other"
        if re.search(r"\bduo\b", clean_base, re.IGNORECASE):
            vc_type = "Duo"
        elif re.search(r"\btrio\b", clean_base, re.IGNORECASE):
            vc_type = "Trio"
        elif re.search(r"\bsquad\b", clean_base, re.IGNORECASE):
            vc_type = "Squad"

        async with self._vc_creation_lock:
            db_map = await self._get_cached_channels(guild.id, force_refresh=True)

            used_numbers = set()
            for voice_id, (type_name, num) in db_map.items():
                ch = guild.get_channel(voice_id)
                if ch and ch.category_id == category.id and type_name == vc_type:
                    used_numbers.add(num)

            channel_number = 1
            while channel_number in used_numbers:
                channel_number += 1

            name = f"{clean_base} {channel_number}"

            vc = await guild.create_voice_channel(
                name=name,
                category=category,
                user_limit=limit or None,
                reason=f"Temp VC created by {member}",
            )

            try:
                await member.move_to(vc)
            except Exception:
                pass

            await self.db.store(
                "voice_channel",
                {
                    "guildID": guild.id,
                    "userID": member.id,
                    "voiceID": vc.id,
                    "vcType": vc_type,
                    "channelNumber": channel_number,
                    "channelName": name,
                    "channelLimit": limit,
                },
            )

            self._update_cache(guild.id, vc.id, vc_type, channel_number)

            asyncio.create_task(
                self._reorder_channels_background(
                    guild, category.id, vc.id, vc_type, channel_number
                )
            )

            await self._send_panel(vc, member.id)

    async def _reorder_channels_background(
        self, guild, category_id, new_vc_id, vc_type, channel_number
    ):
        try:
            await asyncio.sleep(1)

            category = guild.get_channel(category_id)
            if not category:
                return

            db_map = await self._get_cached_channels(guild.id, force_refresh=True)

            all_vcs = category.voice_channels

            generators = []
            static_vcs = []
            managed_vcs = []

            for ch in all_vcs:
                join_channels = await self._get_join_channels(guild.id)
                if ch.id in join_channels:
                    generators.append(ch)
                elif ch.id in db_map:
                    managed_vcs.append(ch)
                else:
                    static_vcs.append(ch)

            generators.sort(key=lambda x: x.position)

            sort_keys = {}
            for ch in managed_vcs:
                if ch.id == new_vc_id:
                    sort_keys[ch.id] = (self.type_order.get(vc_type, 4), channel_number)
                else:
                    m_type, m_num = db_map[ch.id]
                    sort_keys[ch.id] = (self.type_order.get(m_type, 4), m_num)

            managed_vcs.sort(key=lambda x: sort_keys[x.id])

            final_order = generators + managed_vcs + static_vcs

            position_mapping = {}
            for index, ch in enumerate(final_order):
                if ch.position != index:
                    position_mapping[ch] = index

            if position_mapping:
                sorted_channels = sorted(position_mapping.items(), key=lambda x: x[1])

                for ch, pos in sorted_channels:
                    try:
                        if ch.position != pos:
                            await ch.edit(position=pos)
                            await asyncio.sleep(0.3)
                    except Exception as e:
                        log.debug("Background positioning failed for %s: %s", ch.name, e)

        except Exception as e:
            log.error("Background reordering error: %s", e)

    async def _schedule_cleanup(self, ch):
        if ch.members:
            return

        guild_id = ch.guild.id
        self._ensure_structs(ch.id, guild_id)

        async with self.cleanup_locks[guild_id]:
            if ch.id in self.cleanup_tasks:
                return

            guild_cache = await self._get_cached_channels(guild_id)
            if ch.id not in guild_cache:
                return

            task = asyncio.create_task(self._cleanup_task(ch))
            self.cleanup_tasks[ch.id] = task

    async def _cleanup_task(self, ch):
        try:
            if ch.members:
                return

            guild_cache = await self._get_cached_channels(ch.guild.id)
            if ch.id not in guild_cache:
                return

            await ch.delete(reason="Empty temp VC cleanup")
            await self.db.remove("voice_channel", voiceID=ch.id)
            self._remove_from_cache(ch.guild.id, ch.id)
            self.owner_leave_times.pop(ch.id, None)
        except Exception as e:
            log.error("Cleanup error: %s", e)
        finally:
            self.cleanup_tasks.pop(ch.id, None)

    async def _cleanup_ghost(self, guild):
        guild_cache = await self._get_cached_channels(guild.id)
        to_delete = [voice_id for voice_id in guild_cache if not guild.get_channel(voice_id)]

        if to_delete:
            for vid in to_delete:
                await self.db.remove("voice_channel", voiceID=vid)
                self._remove_from_cache(guild.id, vid)

    async def _cleanup_empty(self, guild):
        guild_cache = await self._get_cached_channels(guild.id)

        for voice_id in guild_cache:
            ch = guild.get_channel(voice_id)
            if ch and not ch.members:
                await self._schedule_cleanup(ch)

    async def _send_panel(self, channel, owner_id):
        try:
            view = BasicControlsView(self, channel.id, owner_id, is_gaming=False)
            await channel.send(view=view)
        except Exception as e:
            log.error("Error sending panel: %s", e)

    @tempvc.command(name="panel", description="Open your voice channel control panel")
    @app_commands.guild_only()
    async def panel(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message(
                view=make_error_card(
                    "❌ Error", "You must be in a voice channel to use this command"
                ),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)
        voice_channel = interaction.user.voice.channel

        guild_cache = await self._get_cached_channels(interaction.guild_id)
        if voice_channel.id not in guild_cache:
            await interaction.followup.send(
                view=make_error_card("❌ Error", "This voice channel is not managed by the bot"),
                ephemeral=True,
            )
            return

        data = await self.db.find_one("voice_channel", voiceID=voice_channel.id)
        if not data:
            await interaction.followup.send(
                view=make_error_card("❌ Error", "Database error"), ephemeral=True
            )
            return

        owner_id = data["userID"]

        view = BasicControlsView(self, voice_channel.id, owner_id)
        await interaction.followup.send(view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(TempVoice(bot))
