from .cog import CustomCom


async def setup(bot) -> None:
    await bot.add_cog(CustomCom(bot))
