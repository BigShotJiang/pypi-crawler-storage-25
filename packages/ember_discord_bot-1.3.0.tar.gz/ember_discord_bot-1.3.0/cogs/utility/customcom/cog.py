"""Custom commands — guild-specific user-defined commands.

Admins can create commands that trigger a response with variable substitution.
Commands are registered as prefix commands dynamically.
"""

from __future__ import annotations

import re
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator
from core.permissions import PermissionLevel, requires
from utils.cards import make_error_card, make_info_card, make_list_card, make_success_card
from utils.feature_registry import ConfigField, FieldType, feature

_ = Translator("CustomCom", __file__)


@feature(
    display_name="Custom Commands",
    emoji="🧩",
    description="User-defined per-guild commands with variable substitution.",
    fields=[
        ConfigField("enabled", "Enabled", FieldType.BOOLEAN, default=True),
    ],
)
class CustomCom(EmberCog, name="CustomCom"):
    """Custom command system with variable substitution.

    Admins can create commands that respond with preset text.
    Supports variables: {user}, {user.name}, {user.id}, {server}, {channel}, {args}, {count}.
    """

    customcom = app_commands.Group(name="customcom", description="Custom command management")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._custom_commands: dict[int, dict[str, dict[str, Any]]] = (
            {}
        )  # guild_id -> {name: {response, creator, uses}}
        self._bot_user_mention = None
        self.db.defaults(
            {
                "guild": {
                    "commands": None,
                    "enabled": True,
                },
            }
        )

    async def cog_load(self) -> None:
        await super().cog_load()
        # Cache bot mention for prefix matching
        self._bot_user_mention = self.bot.user.mention if self.bot.user else None
        register_data_callbacks(self)
        # Preload all custom commands from all guilds? Lazy load on demand.
        # We'll load per guild when needed.

    async def _get_guild_commands(self, guild_id: int) -> dict[str, dict[str, Any]]:
        if guild_id in self._custom_commands:
            return self._custom_commands[guild_id]
        cmds = await self.db.guild(guild_id).get("commands") or {}
        self._custom_commands[guild_id] = cmds
        return cmds

    async def _save_guild_commands(self, guild_id: int, cmds: dict[str, dict[str, Any]]) -> None:
        self._custom_commands[guild_id] = cmds
        await self.db.guild(guild_id).set("commands", cmds)

    # ─── Admin Commands ──────────────────────────────────────────────────────────

    @customcom.command(name="create", description="Create a custom command")
    @app_commands.describe(
        name="Command name (lowercase, no spaces)",
        response="Response text (use {user}, {server}, {args} for variables)",
    )
    @requires(PermissionLevel.ADMIN)
    async def customcom_create(
        self,
        interaction: discord.Interaction,
        name: str,
        response: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)

        # Validate name
        name = name.lower().strip()
        if not re.match(r"^[a-z0-9_]{1,32}$", name):
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Invalid Name",
                    "Use only lowercase letters, numbers, and underscores. Max 32.",
                ),
                ephemeral=True,
            )
            return

        # Prevent conflict with existing commands
        if name in self.bot.all_commands:
            await interaction.followup.send(
                view=make_error_card("❌ Conflict", f"A built-in command `{name}` already exists."),
                ephemeral=True,
            )
            return

        cmds = await self._get_guild_commands(interaction.guild.id)
        if name in cmds:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Exists", f"Custom command `{name}` already exists. Use edit to modify."
                ),
                ephemeral=True,
            )
            return

        cmds[name] = {
            "response": response,
            "creator": interaction.user.id,
            "created_at": discord.utils.utcnow().isoformat(),
            "uses": 0,
        }
        await self._save_guild_commands(interaction.guild.id, cmds)

        await interaction.followup.send(
            view=make_success_card(
                "✅ Created", f"Custom command `{name}` created. Use `{self._get_prefix()}{name}`."
            ),
            ephemeral=True,
        )

    @customcom.command(name="edit", description="Edit an existing custom command")
    @app_commands.describe(name="Command name", response="New response text")
    @requires(PermissionLevel.ADMIN)
    async def customcom_edit(
        self,
        interaction: discord.Interaction,
        name: str,
        response: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        cmds = await self._get_guild_commands(interaction.guild.id)
        name = name.lower()
        if name not in cmds:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Custom command `{name}` does not exist."),
                ephemeral=True,
            )
            return
        cmds[name]["response"] = response
        await self._save_guild_commands(interaction.guild.id, cmds)
        await interaction.followup.send(
            view=make_success_card("✅ Updated", f"Custom command `{name}` updated."),
            ephemeral=True,
        )

    @customcom.command(name="delete", description="Delete a custom command")
    @app_commands.describe(name="Command name")
    @requires(PermissionLevel.ADMIN)
    async def customcom_delete(
        self,
        interaction: discord.Interaction,
        name: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        cmds = await self._get_guild_commands(interaction.guild.id)
        name = name.lower()
        if name not in cmds:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Custom command `{name}` does not exist."),
                ephemeral=True,
            )
            return
        del cmds[name]
        await self._save_guild_commands(interaction.guild.id, cmds)
        await interaction.followup.send(
            view=make_success_card("✅ Deleted", f"Custom command `{name}` deleted."),
            ephemeral=True,
        )

    @customcom.command(name="list", description="List all custom commands in this server")
    async def customcom_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=False)
        cmds = await self._get_guild_commands(interaction.guild.id)
        if not cmds:
            await interaction.followup.send(
                view=make_info_card("📋 Custom Commands", "No custom commands defined."),
                ephemeral=False,
            )
            return
        lines = []
        for name, data in sorted(cmds.items()):
            uses = data.get("uses", 0)
            lines.append(f"`{self._get_prefix()}{name}` — used {uses:,} times")
        await interaction.followup.send(
            view=make_list_card(f"📋 Custom Commands ({len(lines)})", lines, per_page=20),
            ephemeral=False,
        )

    @customcom.command(name="info", description="Show details of a custom command")
    @app_commands.describe(name="Command name")
    async def customcom_info(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=False)
        cmds = await self._get_guild_commands(interaction.guild.id)
        name = name.lower()
        if name not in cmds:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Custom command `{name}` does not exist."),
                ephemeral=False,
            )
            return
        data = cmds[name]
        creator_id = data.get("creator")
        creator = self.bot.get_user(creator_id) or f"<@{creator_id}>"
        body = (
            f"{data['response']}\n\n"
            f"**Creator:** {creator}\n"
            f"**Uses:** {data.get('uses', 0)}\n"
            f"**Created:** {data.get('created_at', 'Unknown')}"
        )
        await interaction.followup.send(
            view=make_info_card(f"/customcom {name}", body),
            ephemeral=False,
        )

    def _get_prefix(self) -> str:
        """Get the first prefix for this guild (for display)."""
        # For simplicity, show the first default prefix
        return "!"

    # ─── Message Handler ─────────────────────────────────────────────────────────────

    async def on_message(self, message: discord.Message) -> None:
        # Ignore bots, DMs
        if message.author.bot or not message.guild:
            return

        if not await self.db.guild(message.guild.id).is_enabled():
            return

        # Get prefix list
        try:
            prefixes = await self.bot.get_prefix(message)
        except Exception:
            return

        # Find which prefix was used
        content = message.content
        used_prefix = None
        for prefix in prefixes:
            if content.startswith(prefix):
                used_prefix = prefix
                break

        if not used_prefix:
            return

        # Extract command name
        after_prefix = content[len(used_prefix) :].strip()
        if not after_prefix:
            return
        cmd_name = after_prefix.split()[0].lower()

        # Check if this is a custom command
        cmds = await self._get_guild_commands(message.guild.id)
        if cmd_name not in cmds:
            return

        # Perform access checks (mirroring global_check/interaction_check logic)
        user_id = message.author.id
        guild_id = message.guild.id

        # Owner bypass
        if await self.bot.is_owner(message.author):
            pass
        else:
            # Ignore checks
            try:
                from core.ignore import is_channel_ignored, is_guild_ignored

                if await is_guild_ignored(guild_id):
                    return
                if await is_channel_ignored(guild_id, message.channel.id):
                    return
                # Check thread parent if applicable
                if hasattr(message.channel, "parent") and message.channel.parent:
                    if await is_channel_ignored(guild_id, message.channel.parent.id):
                        return
            except Exception:
                pass

            # Whitelist/Blacklist check
            try:
                from core.whitelist_blacklist import is_blocked

                if await is_blocked(guild_id, user_id):
                    return
            except Exception:
                pass

        # Execute the custom command
        cmd_data = cmds[cmd_name]
        response_text = cmd_data["response"]

        # Increment usage
        cmd_data["uses"] = cmd_data.get("uses", 0) + 1
        await self._save_guild_commands(message.guild.id, cmds)

        # Variable substitution
        response_text = self._substitute_variables(response_text, message, cmd_name)

        try:
            await message.channel.send(response_text)
        except Exception:
            pass

    def _substitute_variables(self, text: str, message: discord.Message, cmd_name: str) -> str:
        """Replace variables in the response."""
        # Prepare common values
        user = message.author
        server = message.guild
        channel = message.channel
        args = message.content[len(self._get_prefix()) + len(cmd_name) :].strip()

        # Build count separately because we need to compute it from cmd_data
        # We'll lookup after increment already done
        # We'll fetch uses count from memory (but it's already incremented)
        # For accuracy, we can get from cmds; but we don't have cmds here easily
        # We can look up in _custom_commands cache but that's messy. For simplicity, we'll not replace {count} here or we compute it by fetching from settings synchronously? That would be blocking. We'll skip {count} in substitution due to async complexity.

        substitutions = {
            "user": user.mention,
            "user.name": user.display_name,
            "user.id": str(user.id),
            "server": server.name,
            "server.id": str(server.id),
            "channel": channel.mention,
            "channel.name": channel.name,
            "args": args,
            "prefix": self._get_prefix(),
            "command": cmd_name,
        }

        # Perform replacements using regex for {var}
        def repl(match):
            key = match.group(1)
            return substitutions.get(key, match.group(0))

        result = re.sub(r"\{(\w+(?:\.\w+)*)\}", repl, text)
        return result

    # ─── GDPR Callbacks ───────────────────────────────────────────────────────────

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Delete all custom commands created by this user.

        If guild_id is specified, only delete in that guild.
        """
        deleted_count = 0
        # Iterate all affected guilds
        guilds_to_check = [guild_id] if guild_id else list(self._custom_commands.keys())
        for gid in list(guilds_to_check):
            cmds = await self._get_guild_commands(gid)
            # Filter out commands where creator == user_id
            new_cmds = {k: v for k, v in cmds.items() if v.get("creator") != user_id}
            if len(new_cmds) != len(cmds):
                await self._save_guild_commands(gid, new_cmds)
                deleted_count += len(cmds) - len(new_cmds)
        return {"deleted_commands": deleted_count}

    async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Export custom commands created by this user."""
        exports = []
        guilds_to_check = [guild_id] if guild_id else list(self._custom_commands.keys())
        for gid in guilds_to_check:
            cmds = await self._get_guild_commands(gid)
            for name, data in cmds.items():
                if data.get("creator") == user_id:
                    exports.append(
                        {
                            "guild_id": gid,
                            "command": name,
                            "response": data["response"],
                            "uses": data.get("uses", 0),
                            "created_at": data.get("created_at"),
                        }
                    )
        return {"commands": exports, "total": len(exports)}


async def setup(bot):
    await bot.add_cog(CustomCom(bot))
