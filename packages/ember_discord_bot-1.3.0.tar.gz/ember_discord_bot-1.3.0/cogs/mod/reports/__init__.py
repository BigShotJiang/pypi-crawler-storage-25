from .cog import Reports


async def setup(bot) -> None:
    await bot.add_cog(Reports(bot))
