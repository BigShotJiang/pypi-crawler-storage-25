"""Reports system — anonymous user reporting for staff.

Allows users to submit reports that go to a designated staff channel.
Supports anonymous reporting and report status tracking.
"""

from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator
from core.permissions import PermissionLevel, requires
from utils.cards import make_error_card, make_info_card, make_list_card, make_success_card
from utils.feature_registry import ConfigField, FieldType, feature

_ = Translator("Reports", __file__)


@feature(
    display_name="User Reports",
    emoji="📣",
    description="Anonymous user reporting with staff review channel.",
    fields=[
        ConfigField(
            "report_channel_id",
            "Report Channel",
            FieldType.CHANNEL,
            required=True,
            description="Channel where user reports are posted for staff review.",
        ),
        ConfigField("enabled", "Enabled", FieldType.BOOLEAN, default=True),
    ],
)
class Reports(EmberCog, name="Reports"):
    """User reporting system with staff review workflow."""

    reports = app_commands.Group(name="reports", description="Report handling commands")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {
                    "report_channel_id": None,
                    "next_report_id": 1,
                    "reports": None,
                    "enabled": True,
                },
            }
        )

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)

    # ─── User Commands ───────────────────────────────────────────────────────────

    @reports.command(name="report", description="Submit a report to staff")
    @app_commands.describe(
        target="User to report (optional)",
        reason="Reason for the report",
        evidence="Evidence (message link, image, etc.)",
    )
    async def report(
        self,
        interaction: discord.Interaction,
        reason: str,
        target: discord.User | None = None,
        evidence: str | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)

        # Get or create report channel
        cfg = self.config.guild(interaction.guild.id)
        channel_id = await cfg.report_channel_id()
        if not channel_id:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Not Configured", "Reports channel not set. Ask an admin to configure it."
                ),
                ephemeral=True,
            )
            return

        channel = self.bot.get_channel(channel_id)
        if not channel:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Not Found", "Report channel not found or bot can't access it."
                ),
                ephemeral=True,
            )
            return

        # Build report card
        report_id = await self._get_next_report_id(interaction.guild)
        body_lines = [f"**Reporter:** {interaction.user.mention}"]
        if target:
            body_lines.append(f"**Target:** {target.mention}")
        body_lines.append(f"**Reason:** {reason}")
        if evidence:
            body_lines.append(f"**Evidence:** {evidence}")
        from utils.cards import make_error_card as _make_error_card

        report_card = _make_error_card(
            f"🚨 Report #{report_id}",
            "\n".join(body_lines),
            footer=f"User ID: {interaction.user.id}",
        )

        try:
            await channel.send(view=report_card)
            # Store report in database
            await self._log_report(
                guild_id=interaction.guild.id,
                report_id=report_id,
                reporter_id=interaction.user.id,
                target_id=target.id if target else None,
                reason=reason,
                evidence=evidence,
            )
            await interaction.followup.send(
                view=make_success_card(
                    "✅ Report Submitted", f"Report #{report_id} has been submitted to staff."
                ),
                ephemeral=True,
            )
        except Exception as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", f"Could not send report: {exc}"),
                ephemeral=True,
            )

    @reports.command(name="my_reports", description="View your submitted reports")
    async def my_reports(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        reports = await self._get_user_reports(interaction.guild.id, interaction.user.id)
        if not reports:
            await interaction.followup.send(
                view=make_info_card("📋 Your Reports", "You haven't submitted any reports."),
                ephemeral=True,
            )
            return

        lines = []
        for rep in reports[-10:]:  # Show last 10
            target_text = f" against <@{rep['target_id']}>" if rep.get("target_id") else ""
            status = rep.get("status", "pending")
            lines.append(f"**#{rep['report_id']}**{target_text} — {status}")
        await interaction.followup.send(
            view=make_list_card(f"📋 Your Reports ({len(reports)})", lines, per_page=10),
            ephemeral=True,
        )

    # ─── Admin Commands ───────────────────────────────────────────────────────────

    @reports.command(name="list", description="List all recent reports")
    @requires(PermissionLevel.MOD)
    async def reports_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        reports = await self._get_all_reports(interaction.guild.id)
        if not reports:
            await interaction.followup.send(
                view=make_info_card("📋 All Reports", "No reports found."),
                ephemeral=True,
            )
            return

        lines = []
        for rep in reports[-20:]:
            target = f" <@{rep['target_id']}>" if rep.get("target_id") else ""
            status = rep.get("status", "pending")
            lines.append(
                f"#{rep['report_id']}: {rep['reason'][:50]}... (by <@{rep['reporter_id']}>{target}) [{status}]"
            )
        await interaction.followup.send(
            view=make_list_card(f"📋 Recent Reports ({len(reports)})", lines, per_page=10),
            ephemeral=True,
        )

    @reports.command(name="report_resolve", description="Mark a report as resolved")
    @app_commands.describe(report_id="Report number", resolution="Resolution notes (optional)")
    @requires(PermissionLevel.MOD)
    async def report_resolve(
        self,
        interaction: discord.Interaction,
        report_id: int,
        resolution: str | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        if await self._update_report_status(
            interaction.guild.id, report_id, "resolved", resolution
        ):
            await interaction.followup.send(
                view=make_success_card("✅ Resolved", f"Report #{report_id} marked as resolved."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Report #{report_id} not found."),
                ephemeral=True,
            )

    @reports.command(name="report_configure", description="Configure the reports channel")
    @app_commands.describe(channel="Channel where reports will be sent")
    @requires(PermissionLevel.ADMIN)
    async def report_configure(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
    ) -> None:
        await self.db.set("guild", interaction.guild.id, "report_channel_id", channel.id)
        await interaction.response.send_message(
            view=make_success_card("✅ Configured", f"Reports will be sent to {channel.mention}"),
            ephemeral=True,
        )

    # ─── Storage ─────────────────────────────────────────────────────────────────

    async def _get_next_report_id(self, guild: discord.Guild) -> int:
        cfg = await self.db.get_all("guild", guild.id)
        current = cfg.get("next_report_id", 1)
        await self.db.set("guild", guild.id, "next_report_id", current + 1)
        return current

    async def _log_report(
        self,
        guild_id: int,
        report_id: int,
        reporter_id: int,
        target_id: int | None,
        reason: str,
        evidence: str | None,
    ) -> None:
        reports = await self.db.get("guild", guild_id, "reports") or []
        reports.append(
            {
                "report_id": report_id,
                "reporter_id": reporter_id,
                "target_id": target_id,
                "reason": reason,
                "evidence": evidence,
                "timestamp": discord.utils.utcnow().isoformat(),
                "status": "pending",
            }
        )
        # Keep last 1000 reports per guild
        await self.db.set("guild", guild_id, "reports", reports[-1000:])

    async def _get_user_reports(self, guild_id: int, user_id: int) -> list[dict]:
        reports = await self.db.get("guild", guild_id, "reports") or []
        return [r for r in reports if r["reporter_id"] == user_id]

    async def _get_all_reports(self, guild_id: int) -> list[dict]:
        return await self.db.get("guild", guild_id, "reports") or []

    async def _update_report_status(
        self,
        guild_id: int,
        report_id: int,
        status: str,
        resolution: str | None,
    ) -> bool:
        reports = await self.db.get("guild", guild_id, "reports") or []
        for rep in reports:
            if rep["report_id"] == report_id:
                rep["status"] = status
                if resolution:
                    rep["resolution"] = resolution
                rep["resolved_at"] = discord.utils.utcnow().isoformat()
                rep["resolved_by"] = None  # Could add interaction.user.id here if we pass it
                await self.db.set("guild", guild_id, "reports", reports)
                return True
        return False

    # ─── GDPR Callbacks ───────────────────────────────────────────────────────────

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Delete reports submitted by this user."""
        deleted_count = 0
        guilds_to_check = [guild_id] if guild_id else [g.id for g in self.bot.guilds]
        for gid in guilds_to_check:
            reports = await self.db.get("guild", gid, "reports") or []
            original_len = len(reports)
            reports = [r for r in reports if r["reporter_id"] != user_id]
            if len(reports) < original_len:
                await self.db.set("guild", gid, "reports", reports)
                deleted_count += original_len - len(reports)
        return {"deleted_reports": deleted_count}

    async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Export reports submitted by this user."""
        exports = []
        guilds_to_check = [guild_id] if guild_id else [g.id for g in self.bot.guilds]
        for gid in guilds_to_check:
            reports = await self.db.get("guild", gid, "reports") or []
            user_reports = [r for r in reports if r["reporter_id"] == user_id]
            exports.extend(user_reports)
        return {"reports": exports, "total": len(exports)}


async def setup(bot):
    await bot.add_cog(Reports(bot))
