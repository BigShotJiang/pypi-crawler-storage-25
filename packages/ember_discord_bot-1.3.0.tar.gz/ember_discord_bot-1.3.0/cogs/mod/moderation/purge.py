import logging

import discord
from discord import ui
from discord.ext import commands

from core.branding import EmberColors
from core.checks import ctx_is_mod
from core.cog import EmberCog

log = logging.getLogger("ember.purge")


class PurgeCog(EmberCog, name="Purge"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._cooldown = commands.CooldownMapping.from_cooldown(3, 60, commands.BucketType.user)

    def _result_card(self, text: str, accent: discord.Color) -> ui.LayoutView:
        view = ui.LayoutView(timeout=None)
        view.add_item(ui.Container(ui.TextDisplay(text), accent_color=accent))
        return view

    async def _confirm(self, ctx: commands.Context, count: int) -> bool:
        if count <= 50:
            return True
        view = self._result_card(
            f"⚠️ Delete **{count}** messages? Type `confirm`.", EmberColors.WARNING
        )
        msg = await ctx.send(view=view)
        try:
            await self.bot.wait_for(
                "message",
                timeout=10,
                check=lambda m: m.author == ctx.author
                and m.channel == ctx.channel
                and m.content.lower() == "confirm",
            )
            await msg.delete()
            return True
        except TimeoutError:
            await msg.delete()
            await ctx.send("❌ Purge cancelled.", delete_after=5)
            return False

    @commands.command(name="purge")
    async def purge(self, ctx: commands.Context, amount: int = None):
        bucket = self._cooldown.get_bucket(ctx.message)
        if retry := bucket.update_rate_limit():
            return await ctx.send(f"⏳ Wait {retry:.1f}s.", delete_after=5)
        if not await ctx_is_mod(ctx):
            return await ctx.send("❌ Not allowed.", delete_after=5)

        if ctx.message.reference:
            try:
                ref = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                msgs = await ctx.channel.history(after=ref, limit=None).flatten()
                if not await self._confirm(ctx, len(msgs)):
                    return
                deleted = await ctx.channel.purge(limit=None, after=ref)
                await ctx.send(
                    view=self._result_card(
                        f"✅ Deleted **{len(deleted)}** messages.",
                        EmberColors.SUCCESS,
                    ),
                    delete_after=5,
                )
            except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
                await ctx.send(f"❌ {e}", delete_after=5)
            return

        if amount is None:
            return await ctx.send("❌ Usage: `.purge <n>` or reply to a message.", delete_after=5)
        if not 1 <= amount <= 1000:
            return await ctx.send("❌ Amount must be 1–1000.", delete_after=5)
        if not await self._confirm(ctx, amount):
            return
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)
            await ctx.send(
                view=self._result_card(
                    f"✅ Deleted **{len(deleted)-1}** messages.", EmberColors.SUCCESS
                ),
                delete_after=5,
            )
        except (discord.Forbidden, discord.HTTPException) as e:
            await ctx.send(f"❌ {e}", delete_after=5)

    @commands.command(name="purgeuser")
    async def purge_user(self, ctx: commands.Context, user: discord.Member, amount: int = 100):
        if not await ctx_is_mod(ctx):
            return await ctx.send("❌ Not allowed.", delete_after=5)
        if amount > 500:
            return await ctx.send("❌ Max 500.", delete_after=5)
        try:
            deleted = await ctx.channel.purge(limit=amount, check=lambda m: m.author == user)
            await ctx.send(
                view=self._result_card(
                    f"✅ Deleted **{len(deleted)}** messages from {user.mention}.",
                    EmberColors.SUCCESS,
                ),
                delete_after=5,
            )
        except (discord.Forbidden, discord.HTTPException) as e:
            await ctx.send(f"❌ {e}", delete_after=5)

    @commands.command(name="purgeuntil")
    async def purge_until(self, ctx: commands.Context, message_id: int):
        if not await ctx_is_mod(ctx):
            return await ctx.send("❌ Not allowed.", delete_after=5)
        try:
            target = await ctx.channel.fetch_message(message_id)
            deleted = await ctx.channel.purge(limit=None, after=target)
            await ctx.send(
                view=self._result_card(
                    f"✅ Deleted **{len(deleted)}** messages.", EmberColors.SUCCESS
                ),
                delete_after=5,
            )
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            await ctx.send(f"❌ {e}", delete_after=5)


async def setup(bot):
    await bot.add_cog(PurgeCog(bot))
