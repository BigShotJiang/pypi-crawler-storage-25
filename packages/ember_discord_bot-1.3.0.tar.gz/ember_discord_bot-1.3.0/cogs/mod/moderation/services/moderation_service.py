from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

logger = logging.getLogger("ember.moderation.service")


class ModerationService:
    """Business logic layer for moderation operations."""

    def __init__(self):
        pass

    def get_staff_level(self, member_roles: list[int], role_ids: dict[str, int]) -> int:
        """Return staff level (0-4) based on role membership.

        Args:
            member_roles: List of role IDs the member has
            role_ids: Dict mapping role names to role IDs from environment

        Returns:
            0 = no staff role
            1 = Trial Staff
            2 = Chat Manager
            3 = Helper
            4 = Moderator
        """
        if role_ids.get("MODERATOR") and role_ids["MODERATOR"] in member_roles:
            return 4
        if role_ids.get("HELPER") and role_ids["HELPER"] in member_roles:
            return 3
        if role_ids.get("CHAT_MANAGER") and role_ids["CHAT_MANAGER"] in member_roles:
            return 2
        if role_ids.get("TRIAL_STAFF") and role_ids["TRIAL_STAFF"] in member_roles:
            return 1
        return 0

    def can_punish(
        self,
        punisher_level: int,
        punisher_is_admin: bool,
        target_level: int,
        action: str,
    ) -> tuple[bool, str]:
        """Check if a staff member can punish another member.

        Returns:
            (allowed, reason_string)
        """
        # Admins can always punish
        if punisher_is_admin:
            return True, ""

        # No staff role
        if punisher_level == 0:
            return False, "You don't have a staff role."

        # Can't punish self
        # (This check is done at call site where we have full objects)

        # Hierarchy
        if target_level > punisher_level:
            return False, f"Cannot punish staff level {target_level} with level {punisher_level}."
        if target_level == punisher_level and target_level > 0:
            return False, "Cannot punish another staff member of equal rank."

        # Action requirements
        if action == "warn" and punisher_level < 3:
            return False, f"Staff level {punisher_level} cannot warn (requires level 3+)."
        if action == "kick" and punisher_level < 3:
            return False, f"Staff level {punisher_level} cannot kick (requires level 3+)."
        if action == "ban" and punisher_level < 4:
            return False, f"Staff level {punisher_level} cannot ban (requires level 4)."

        return True, ""

    def get_max_duration_for_level(self, staff_level: int) -> int | None:
        """Return max duration in seconds for a staff level, or None for unlimited."""
        if staff_level == 1:  # Trial Staff
            return 3600  # 1 hour
        if staff_level == 2:  # Chat Manager
            return 43200  # 12 hours
        # Levels 3+ have no time limit
        return None

    @staticmethod
    def parse_duration(duration: str) -> int | None:
        """Parse duration like '10m 30s' into seconds."""
        if not duration:
            return None
        import re

        matches = re.findall(r"(\d+)([smhd])", duration.lower())
        if not matches:
            return None
        secs = 0
        for amt, unit in matches:
            amt = int(amt)
            secs += amt * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
        return secs

    @staticmethod
    def format_duration(seconds: int) -> str:
        """Format seconds into human-readable duration."""
        if seconds < 60:
            return f"{seconds}s"
        if seconds < 3600:
            mins = seconds // 60
            secs = seconds % 60
            return f"{mins}m {secs}s" if secs else f"{mins}m"
        if seconds < 86400:
            hrs = seconds // 3600
            mins = (seconds % 3600) // 60
            return f"{hrs}h {mins}m" if mins else f"{hrs}h"
        days = seconds // 86400
        hrs = (seconds % 86400) // 3600
        return f"{days}d {hrs}h" if hrs else f"{days}d"
