import logging

import discord
from discord import ui
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from utils.feature_registry import ConfigField, FeatureMeta, FieldType, register, unregister

log = logging.getLogger("ember.verification")

_COG_NAME = "verification"
VERIFICATION_ID = 0x5665726966696361

_FEATURE = FeatureMeta(
    cog_name=_COG_NAME,
    display_name="Verification",
    description="Staff commands to verify and unverify members.",
    emoji="✅",
    fields=[
        ConfigField(
            key="staff_role_id",
            label="Staff Role",
            type=FieldType.ROLE,
            required=True,
            description="Role allowed to run verify/unverify commands.",
        ),
        ConfigField(
            key="verified_role_id",
            label="Verified Role",
            type=FieldType.ROLE,
            required=True,
            description="Role given to verified members.",
        ),
        ConfigField(
            key="log_channel_id",
            label="Log Channel",
            type=FieldType.CHANNEL,
            description="Channel where verification actions are logged.",
        ),
    ],
)


class Verification(EmberCog, name="Verification"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot, cog_name="verification", identifier=VERIFICATION_ID)
        self.db.defaults(
            {
                "guild": {"staff_role_id": None, "verified_role_id": None, "log_channel_id": None},
            }
        )

    async def cog_load(self) -> None:
        await super().cog_load()
        register(_FEATURE)

    async def cog_unload(self) -> None:
        unregister(_COG_NAME)

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if ctx.author.guild_permissions.administrator:
            return True
        cfg = await self.db.get_all("guild", ctx.guild.id)
        staff_role_id = cfg.get("staff_role_id")
        if not staff_role_id:
            return False
        role = ctx.guild.get_role(staff_role_id)
        return role is not None and role in ctx.author.roles

    async def _send_card(
        self,
        ctx: commands.Context,
        title: str,
        accent: discord.Color,
        delete_after: int | None = None,
    ):
        view = ui.LayoutView(timeout=None)
        view.add_item(ui.Container(ui.TextDisplay(title), accent_color=accent))
        await ctx.send(view=view, delete_after=delete_after)

    async def _log(
        self, ctx: commands.Context, target: discord.Member, action: str, color: discord.Color
    ):
        cfg = await self.db.get_all("guild", ctx.guild.id)
        log_channel_id = cfg.get("log_channel_id")
        if not log_channel_id:
            return
        ch = ctx.guild.get_channel(log_channel_id)
        if not ch:
            return
        log_view = discord.ui.LayoutView(timeout=None)
        log_view.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(f"## User {action}"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(
                    f"**User:** {target.mention}\n`{target.id}`\n"
                    f"**Moderator:** {ctx.author.mention}"
                ),
                discord.ui.MediaGallery(discord.MediaGalleryItem(media=target.display_avatar.url)),
                accent_color=color,
            )
        )
        try:
            await ch.send(view=log_view)
        except (discord.Forbidden, discord.HTTPException):
            pass

    @commands.command(name="verify")
    async def verify_user(self, ctx: commands.Context, member: discord.Member):
        cfg = await self.db.get_all("guild", ctx.guild.id)
        verified_role_id = cfg.get("verified_role_id")
        role = ctx.guild.get_role(verified_role_id) if verified_role_id else None
        if not role:
            return await ctx.send(
                "❌ Verified role not configured. Use `/settings` to set it.", delete_after=5
            )
        if role in member.roles:
            return await self._send_card(
                ctx,
                f"⚠️ {member.mention} is already verified.",
                EmberColors.WARNING,
                delete_after=5,
            )
        try:
            await member.add_roles(role, reason=f"Verified by {ctx.author}")
            await self._send_card(
                ctx,
                f"✅ {member.mention} verified.",
                EmberColors.SUCCESS,
                delete_after=5,
            )
            await self._log(ctx, member, "Verified", EmberColors.SUCCESS)
        except (discord.Forbidden, discord.HTTPException) as e:
            await ctx.send(f"❌ {e}", delete_after=5)

    @commands.command(name="unverify")
    async def unverify_user(self, ctx: commands.Context, member: discord.Member):
        cfg = await self.db.get_all("guild", ctx.guild.id)
        verified_role_id = cfg.get("verified_role_id")
        role = ctx.guild.get_role(verified_role_id) if verified_role_id else None
        if not role:
            return await ctx.send(
                "❌ Verified role not configured. Use `/settings` to set it.", delete_after=5
            )
        if role not in member.roles:
            return await self._send_card(
                ctx,
                f"⚠️ {member.mention} is not verified.",
                EmberColors.WARNING,
                delete_after=5,
            )
        try:
            await member.remove_roles(role, reason=f"Unverified by {ctx.author}")
            await self._send_card(
                ctx,
                f"✅ Removed verification from {member.mention}.",
                EmberColors.ERROR,
                delete_after=5,
            )
            await self._log(ctx, member, "Unverified", discord.Color.dark_red())
        except (discord.Forbidden, discord.HTTPException) as e:
            await ctx.send(f"❌ {e}", delete_after=5)

    @verify_user.error
    async def _verify_err(self, ctx, error):
        if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
            await ctx.send("❌ Usage: `.verify @member`", delete_after=5)

    @unverify_user.error
    async def _unverify_err(self, ctx, error):
        if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
            await ctx.send("❌ Usage: `.unverify @member`", delete_after=5)


async def setup(bot):
    await bot.add_cog(Verification(bot))
