from .cog import Moderation
from .purge import PurgeCog
from .verify import Verification


async def setup(bot):
    await bot.add_cog(Moderation(bot))
    await bot.add_cog(PurgeCog(bot))
    await bot.add_cog(Verification(bot))
