from typing import TypedDict


class ModerationGuildConfig(TypedDict, total=False):
    """Guild-level moderation configuration."""

    enabled: bool
