import asyncio
import logging
import os
import time
from datetime import UTC, datetime, timedelta

import discord
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator, cog_i18n
from core.modlog import create_case, delete_case, get_cases
from core.permissions import PermissionLevel, requires
from utils.cards import (
    make_error_card,
    make_info_card,
    make_success_card,
    make_warning_card,
)
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import ModerationGuildConfig
from .services.moderation_service import ModerationService

_ = Translator("moderation", __file__)

log = logging.getLogger("ember.moderation")


def _role_id(env: str) -> int:
    return int(os.getenv(env, "0"))


# Staff role hierarchy mapping
ROLE_IDS = {
    "TRIAL_STAFF": _role_id("TRIAL_STAFF_ROLE_ID"),
    "CHAT_MANAGER": _role_id("CHAT_MANAGER_ROLE_ID"),
    "HELPER": _role_id("HELPER_ROLE_ID"),
    "MODERATOR": _role_id("MODERATOR_ROLE_ID"),
}


@cog_i18n(_)
@feature(
    display_name="Moderation",
    description="Staff moderation: warn, mute, kick, ban, purge — with role-hierarchy enforcement.",
    emoji="🛡️",
    fields=[
        ConfigField(
            key="log_channel_id",
            label="Mod Log Channel",
            type=FieldType.CHANNEL,
            description="Channel for moderation action logs.",
        ),
    ],
)
class Moderation(EmberCog, name="Moderation"):
    """Moderation cog with role hierarchy and modlog integration."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.service = ModerationService()
        self.db.defaults(
            {
                "guild": {"enabled": True, "log_channel_id": None, "warn_thresholds": {}},
            }
        )
        self.db.register_schema("guild", ModerationGuildConfig)
        self._tempban_tasks: list[asyncio.Task] = []

    async def cog_load(self) -> None:
        await super().cog_load()
        register_data_callbacks(self)
        await self._reschedule_tempbans()

    async def cog_unload(self) -> None:
        for task in self._tempban_tasks:
            task.cancel()

    def _get_staff_level(self, member: discord.Member) -> int:
        """Return the numeric staff level for a member.

        0 = no staff role
        1 = Trial Staff
        2 = Chat Manager
        3 = Helper
        4 = Moderator
        """
        member_role_ids = [r.id for r in member.roles]
        return self.service.get_staff_level(member_role_ids, ROLE_IDS)

    def _can_punish(
        self, punisher: discord.Member, target: discord.Member, action: str
    ) -> tuple[bool, str]:
        """Check if punisher can punish target based on hierarchy."""
        return self.service.can_punish(
            punisher_level=self._get_staff_level(punisher),
            punisher_is_admin=punisher.guild_permissions.administrator,
            target_level=self._get_staff_level(target),
            action=action,
        )

    async def _get_user_permission_level(
        self, user: discord.Member, guild: discord.Guild
    ) -> PermissionLevel:
        """Override to provide fine-grained permission levels.

        This allows @requires(PermissionLevel.MOD) to work based on staff roles.
        """
        # Bot owner
        if await self.bot.is_owner(user):
            return PermissionLevel.BOT_OWNER

        # Guild owner
        if user.id == guild.owner_id:
            return PermissionLevel.GUILD_OWNER

        # Administrator permission → ADMIN
        if user.guild_permissions.administrator:
            return PermissionLevel.ADMIN

        # Check staff level → MOD
        if self._get_staff_level(user) >= 1:
            return PermissionLevel.MOD

        return PermissionLevel.USER

    @requires(PermissionLevel.MOD)
    @commands.command(name="warn")
    async def warn(
        self,
        ctx: commands.Context,
        member: discord.Member,
        *,
        reason: str = "No reason provided",
    ):
        """Warn a member."""
        # Staff hierarchy check
        allowed, msg = self._can_punish(ctx.author, member, "warn")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        # Create modlog case
        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="warn",
            user=member,
            mod=ctx.author,
            reason=reason,
        )

        # Send DM to user (optional, swallow errors)
        try:
            dm_view = discord.ui.LayoutView(timeout=None)
            dm_view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay(f"## ⚠️ Warning from {ctx.guild.name}"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"**Reason:** {reason}"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay(f"-# Case #{case.id}"),
                    accent_color=EmberColors.WARNING,
                )
            )
            await member.send(view=dm_view)
        except Exception:
            pass  # User has DMs closed

        # Confirm in channel
        await ctx.send(
            view=make_warning_card(
                "⚠️ Member Warned",
                f"**User:** {member.mention}\n"
                f"**Moderator:** {ctx.author.mention}\n"
                f"**Case #:** {case.id}\n"
                f"**Reason:** {reason}",
            )
        )

        # Check if a warn threshold has been crossed
        await self._check_warn_thresholds(ctx, member)

    @requires(PermissionLevel.MOD)
    @commands.command(name="warns", aliases=["warnings"])
    async def check_warns(
        self,
        ctx: commands.Context,
        member: discord.Member | None = None,
    ):
        """View warnings for a member (defaults to self)."""
        if member is None:
            member = ctx.author

        # Fetch cases from modlog
        cases = await get_cases(ctx.guild, user=member, action="warn")

        if not cases:
            return await ctx.send(
                view=make_success_card(f"📋 {member.display_name}", "No warnings on record.")
            )

        # Build response
        lines = [f"**Total warnings:** {len(cases)}"]
        for case in cases[:5]:  # Show last 5
            ts = datetime.fromtimestamp(case.timestamp, tz=UTC).strftime("%Y-%m-%d %H:%M UTC")
            mod = ctx.guild.get_member(case.mod_id) or await self.bot.fetch_user(case.mod_id)
            mod_text = mod.mention if mod else f"`{case.mod_id}`"
            lines.append(f"**#{case.id}** — {ts}\n**Mod:** {mod_text}\n**Reason:** {case.reason}")

        await ctx.send(
            view=make_info_card(
                f"📋 Warnings for {member.display_name}",
                "\n\n".join(lines),
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="clearwarn", aliases=["delwarn"])
    async def clear_warn(
        self,
        ctx: commands.Context,
        member: discord.Member,
        warning_id: int,
    ):
        """Clear a specific warning by case number."""
        # Limitations: Only staff level 3+ (Helper) can clear warnings
        staff_lvl = self._get_staff_level(ctx.author)
        if staff_lvl < 3 and not ctx.author.guild_permissions.administrator:
            return await ctx.send(
                view=make_error_card(
                    "❌ Denied",
                    f"Staff level {staff_lvl} cannot remove warnings (requires level 3+).",
                )
            )

        # Get the case
        from core.modlog import get_case

        case = await get_case(ctx.guild, case_number=warning_id)
        if not case or case.action != "warn":
            return await ctx.send(
                view=make_error_card("❌ Not Found", f"Warning case #{warning_id} not found.")
            )

        # Delete case from modlog
        deleted = await delete_case(ctx.guild, warning_id)
        if not deleted:
            return await ctx.send(view=make_error_card("❌ Failed", "Could not delete case."))

        await ctx.send(
            view=make_success_card(
                "✅ Warning Removed",
                f"**User:** {member.mention}\n"
                f"**Removed by:** {ctx.author.mention}\n"
                f"**Case #:** {warning_id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="mute")
    async def mute(
        self,
        ctx: commands.Context,
        member: discord.Member,
        duration: str | None = None,
        *,
        reason: str = "No reason provided",
    ):
        """Timeout a member.

        Duration format: 10m, 1h30m, 2d, etc.
        """
        allowed, msg = self._can_punish(ctx.author, member, "mute")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        # Parse and check duration limits
        secs = self.service.parse_duration(duration) if duration else None
        staff_lvl = self._get_staff_level(ctx.author)

        if secs:
            max_duration = self.service.get_max_duration_for_level(staff_lvl)
            if max_duration and secs > max_duration:
                max_str = self.service.format_duration(max_duration)
                return await ctx.send(
                    view=make_error_card(
                        "❌ Denied", f"Your staff level allows max duration: {max_str}."
                    )
                )

        until = datetime.now(UTC) + timedelta(seconds=secs) if secs else None
        try:
            await member.timeout(until, reason=f"Muted by {ctx.author} | {reason}")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        # Create modlog case
        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="mute" if secs else "timeout",
            user=member,
            mod=ctx.author,
            reason=reason,
            duration=secs,
        )

        dur_line = f"\n**Duration:** {duration}" if duration else ""
        await ctx.send(
            view=make_warning_card(
                "🔇 Muted",
                f"**User:** {member.mention}\n"
                f"**Mod:** {ctx.author.mention}"
                f"{dur_line}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="unmute")
    async def unmute(
        self,
        ctx: commands.Context,
        member: discord.Member,
        *,
        reason: str = "No reason provided",
    ):
        """Remove timeout from a member."""
        allowed, msg = self._can_punish(ctx.author, member, "mute")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        try:
            await member.timeout(None, reason=f"Unmuted by {ctx.author} | {reason}")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        # Create modlog case
        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="unmute",
            user=member,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_success_card(
                "🔊 Unmuted",
                f"**User:** {member.mention}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="kick")
    async def kick(
        self,
        ctx: commands.Context,
        member: discord.Member,
        *,
        reason: str = "No reason provided",
    ):
        """Kick a member from the server."""
        allowed, msg = self._can_punish(ctx.author, member, "kick")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        try:
            await member.kick(reason=f"Kicked by {ctx.author} | {reason}")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="kick",
            user=member,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_warning_card(
                "👢 Kicked",
                f"**User:** {member.mention}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="ban")
    async def ban(
        self,
        ctx: commands.Context,
        member: discord.Member,
        *,
        reason: str = "No reason provided",
    ):
        """Ban a member from the server."""
        allowed, msg = self._can_punish(ctx.author, member, "ban")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        try:
            await member.ban(reason=f"Banned by {ctx.author} | {reason}")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="ban",
            user=member,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_error_card(
                "🔨 Banned",
                f"**User:** {member.mention}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="unban")
    async def unban(
        self,
        ctx: commands.Context,
        user_id: int,
        *,
        reason: str = "No reason provided",
    ):
        """Unban a user by ID."""
        # Admin-level check for unban
        if not ctx.author.guild_permissions.administrator:
            staff_lvl = self._get_staff_level(ctx.author)
            if staff_lvl < 4:
                return await ctx.send(
                    view=make_error_card(
                        "❌ Denied",
                        f"Staff level {staff_lvl} cannot unban (requires level 4 or admin).",
                    )
                )

        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=f"Unbanned by {ctx.author} | {reason}")
        except discord.NotFound:
            return await ctx.send(
                view=make_error_card("❌ Not Found", "User is not banned or invalid ID.")
            )
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="unban",
            user=user,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_success_card(
                "⚖️ Unbanned",
                f"**User:** {user.mention}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.MOD)
    @commands.command(name="softban")
    async def softban(
        self,
        ctx: commands.Context,
        member: discord.Member,
        *,
        reason: str = "No reason provided",
    ):
        """Softban a member (ban + immediate unban to delete messages)."""
        allowed, msg = self._can_punish(ctx.author, member, "ban")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        try:
            await member.ban(
                reason=f"Softban by {ctx.author} | {reason}", delete_message_seconds=86400
            )
            await ctx.guild.unban(member, reason="Softban - immediate unban")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="softban",
            user=member,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_warning_card(
                "💨 Softbanned",
                f"**User:** {member.mention}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.ADMIN)
    @commands.command(name="hackban")
    async def hackban(
        self,
        ctx: commands.Context,
        user_id: int,
        *,
        reason: str = "No reason provided",
    ):
        """Hackban (ban a user not in the server by ID)."""
        try:
            user = await self.bot.fetch_user(user_id)
        except discord.NotFound:
            return await ctx.send(view=make_error_card("❌ Not Found", "No user with that ID."))

        try:
            await ctx.guild.ban(
                discord.Object(user_id),
                reason=f"Hackban by {ctx.author} | {reason}",
                delete_message_seconds=86400,
            )
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="hackban",
            user=user,
            mod=ctx.author,
            reason=reason,
        )

        await ctx.send(
            view=make_error_card(
                "🔨 Hackbanned",
                f"**User:** {user} (`{user_id}`)\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.ADMIN)
    @commands.command(name="tempban")
    async def tempban(
        self,
        ctx: commands.Context,
        member: discord.Member,
        duration: str,
        *,
        reason: str = "No reason provided",
    ):
        """Temporarily ban a member. Duration: 1h, 2d, 1w, etc."""
        allowed, msg = self._can_punish(ctx.author, member, "ban")
        if not allowed:
            return await ctx.send(view=make_error_card("❌ Denied", msg))

        secs = self.service.parse_duration(duration)
        if not secs:
            return await ctx.send(
                view=make_error_card("❌ Invalid Duration", "Use formats like `1h`, `2d`, `1w`.")
            )

        try:
            await member.ban(reason=f"Tempban by {ctx.author} | {reason}")
        except (discord.Forbidden, discord.HTTPException) as e:
            return await ctx.send(view=make_error_card("❌ Failed", str(e)))

        case = await create_case(
            bot=self.bot,
            guild=ctx.guild,
            action="ban",
            user=member,
            mod=ctx.author,
            reason=f"[Tempban: {duration}] {reason}",
            duration=secs,
        )

        # Persist so the unban survives a restart, then schedule in memory
        unban_at = int(time.time() + secs)
        await self.db.store(
            "tempbans",
            {
                "user_id": member.id,
                "guild_id": ctx.guild.id,
                "unban_at": unban_at,
                "reason": duration,
            },
            pk_columns=["user_id", "guild_id"],
        )
        task = asyncio.create_task(self._unban_scheduled(ctx.guild.id, member.id, secs, duration))
        self._tempban_tasks.append(task)
        task.add_done_callback(self._tempban_tasks.remove)

        await ctx.send(
            view=make_warning_card(
                "🔨 Tempbanned",
                f"**User:** {member.mention}\n"
                f"**Duration:** {duration}\n"
                f"**Mod:** {ctx.author.mention}\n"
                f"**Reason:** {reason}\n"
                f"**Case #:** {case.id}",
            )
        )

    @requires(PermissionLevel.ADMIN)
    @commands.command(name="warn_threshold")
    async def warn_threshold(
        self,
        ctx: commands.Context,
        threshold: int,
        action: str,
        duration: str | None = None,
    ):
        """Configure auto-punishment when warn count hits a threshold.

        Actions: kick, ban, mute
        Example: .warn_threshold 3 mute 1h
        """
        action = action.lower()
        if action not in ("kick", "ban", "mute"):
            return await ctx.send(
                view=make_error_card(
                    "❌ Invalid Action", "Action must be `kick`, `ban`, or `mute`."
                )
            )
        if not 1 <= threshold <= 50:
            return await ctx.send(
                view=make_error_card("❌ Invalid Threshold", "Threshold must be between 1 and 50.")
            )

        cfg = await self.db.get_all("guild", ctx.guild.id)
        thresholds = cfg.get("warn_thresholds") or {}
        thresholds[str(threshold)] = {"action": action, "duration": duration}
        await self.db.set("guild", ctx.guild.id, "warn_thresholds", thresholds)

        dur_text = f" for {duration}" if duration else ""
        await ctx.send(
            view=make_success_card(
                "✅ Threshold Set",
                f"At **{threshold}** warnings → **{action}**{dur_text}.",
            )
        )

    @requires(PermissionLevel.ADMIN)
    @commands.command(name="warn_thresholds")
    async def list_warn_thresholds(self, ctx: commands.Context):
        """List configured warning thresholds."""
        cfg = await self.db.get_all("guild", ctx.guild.id)
        thresholds = cfg.get("warn_thresholds") or {}
        if not thresholds:
            return await ctx.send(
                view=make_info_card("📋 Warn Thresholds", "No thresholds configured.")
            )
        lines = []
        for count, config in sorted(thresholds.items(), key=lambda x: int(x[0])):
            action = config["action"]
            duration = config.get("duration") or "permanent"
            lines.append(f"**{count} warns** → {action} ({duration})")
        await ctx.send(view=make_info_card("📋 Warn Thresholds", "\n".join(lines)))

    async def _reschedule_tempbans(self) -> None:
        rows = await self.db.find("tempbans")
        now = time.time()
        for row in rows:
            delay = max(0.0, row["unban_at"] - now)
            task = asyncio.create_task(
                self._unban_scheduled(row["guild_id"], row["user_id"], delay, row["reason"])
            )
            self._tempban_tasks.append(task)
            task.add_done_callback(self._tempban_tasks.remove)

    async def _unban_scheduled(
        self, guild_id: int, user_id: int, delay: float, reason: str
    ) -> None:
        await asyncio.sleep(delay)
        try:
            guild = self.bot.get_guild(guild_id) or await self.bot.fetch_guild(guild_id)
            await guild.unban(discord.Object(user_id), reason=f"Tempban expired ({reason})")
        except Exception:
            pass
        finally:
            await self.db.remove("tempbans", user_id=user_id, guild_id=guild_id)

    async def _check_warn_thresholds(self, ctx: commands.Context, member: discord.Member) -> None:
        """Check and apply automatic punishment if warn threshold is reached."""
        cfg = await self.db.get_all("guild", ctx.guild.id)
        thresholds = cfg.get("warn_thresholds") or {}
        if not thresholds:
            return

        cases = await get_cases(ctx.guild, user=member, action="warn")
        warn_count = len(cases)

        # Find highest threshold that has been crossed
        triggered = None
        for t_str, config in thresholds.items():
            t = int(t_str)
            if warn_count >= t:
                if triggered is None or t > int(list(triggered.keys())[0]):
                    triggered = {t_str: config}

        if not triggered:
            return

        t_str, config = next(iter(triggered.items()))
        action = config["action"]
        duration_str = config.get("duration")
        secs = self.service.parse_duration(duration_str) if duration_str else None

        try:
            if action == "kick":
                await member.kick(
                    reason=f"Auto-kick: {warn_count} warnings reached threshold {t_str}"
                )
            elif action == "ban":
                await member.ban(
                    reason=f"Auto-ban: {warn_count} warnings reached threshold {t_str}"
                )
            elif action == "mute" and secs:
                until = datetime.now(UTC) + timedelta(seconds=secs)
                await member.timeout(
                    until, reason=f"Auto-mute: {warn_count} warnings reached threshold {t_str}"
                )

            await ctx.send(
                view=make_warning_card(
                    f"⚠️ Auto-{action.title()}",
                    f"{member.mention} reached **{warn_count}** warnings (threshold: {t_str}).\n"
                    f"Automatic **{action}** applied.",
                )
            )
        except (discord.Forbidden, discord.HTTPException):
            pass

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Handle GDPR data deletion request.

        Moderation cases are retained for server safety and compliance,
        but a deletion record is logged. Override if additional user data is stored.
        """
        # Cases are kept; this is standard practice for audit trails.
        # Could be extended to anonymize user data in cases if needed.
        return {"note": "Moderation cases retained for compliance"}

    async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Export all moderation data for a user (GDPR right to data portability)."""
        from core.modlog import get_cases

        cases_data = []

        if guild_id:
            guild = self.bot.get_guild(guild_id)
            if guild:
                try:
                    cases = await get_cases(guild, user=discord.Object(user_id))
                    for case in cases:
                        cases_data.append(
                            {
                                "case_id": case.id,
                                "action": case.action,
                                "reason": case.reason,
                                "mod_id": case.mod_id,
                                "timestamp": (
                                    case.timestamp.isoformat()
                                    if hasattr(case, "timestamp")
                                    else None
                                ),
                            }
                        )
                except Exception as e:
                    log = logging.getLogger("ember.moderation")
                    log.error("Error exporting cases for user %d: %s", user_id, e)
        else:
            # Global request: collect from all guilds
            for guild in self.bot.guilds:
                try:
                    cases = await get_cases(guild, user=discord.Object(user_id))
                    for case in cases:
                        cases_data.append(
                            {
                                "guild_id": guild.id,
                                "case_id": case.id,
                                "action": case.action,
                                "reason": case.reason,
                                "mod_id": case.mod_id,
                                "timestamp": (
                                    case.timestamp.isoformat()
                                    if hasattr(case, "timestamp")
                                    else None
                                ),
                            }
                        )
                except Exception:
                    continue

        return {"cases": cases_data, "total_cases": len(cases_data)}


async def setup(bot):
    await bot.add_cog(Moderation(bot))
