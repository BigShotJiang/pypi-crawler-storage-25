from typing import TypedDict


class BotLoggingGuildConfig(TypedDict, total=False):
    """Guild-level bot_logging configuration."""

    enabled: bool
