import asyncio
import io
import logging
import re
import shutil
import sys
import traceback
from datetime import datetime
from pathlib import Path

import discord
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import feature

from .schema import BotLoggingGuildConfig

_ = Translator("bot_logging", __file__)


@cog_i18n(_)
@feature(
    display_name="Bot Logging",
    description="Captures bot console output to logs/log.txt for debugging (max 300 lines).",
    emoji="📋",
    fields=[],
)
class LogManagerCog(EmberCog, name="LogManager"):

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.log_file = Path("logs/log.txt")
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self.max_lines = 300
        self._setup_logging()
        sys.__stdout__.write(f"[Log Manager] Initialized. Logging to {self.log_file}\n")
        self.db.register_schema("guild", BotLoggingGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    def _setup_logging(self):
        logging.raiseExceptions = False
        self.file_handler = logging.FileHandler(self.log_file, encoding="utf-8")
        self.file_handler.setLevel(logging.INFO)
        self.file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        logging.getLogger().addHandler(self.file_handler)
        self._redirect_print()

    def _redirect_print(self):
        cog = self

        class PrintLogger:
            def __init__(self, is_stdout: bool):
                self.is_stdout = is_stdout
                self.original = sys.__stdout__ if is_stdout else sys.__stderr__
                self.buffer = ""

            def write(self, text):
                self.buffer += text
                if "\n" in self.buffer:
                    lines = self.buffer.split("\n")
                    for line in lines[:-1]:
                        if line.strip():
                            self._log_line(line)
                    self.buffer = lines[-1]

            def _log_line(self, line):
                ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    with open(cog.log_file, "a", encoding="utf-8") as f:
                        f.write(f"{ts} | PRINT | {line}\n")
                except Exception:
                    pass
                cog._trim_log_file()
                try:
                    self.original.write(f"{line}\n")
                    self.original.flush()
                except OSError:
                    pass

            def flush(self):
                if self.buffer.strip():
                    self._log_line(self.buffer)
                    self.buffer = ""
                self.original.flush()

        sys.stdout = PrintLogger(is_stdout=True)
        sys.stderr = PrintLogger(is_stdout=False)

    def _trim_log_file(self):
        try:
            lines = self.log_file.read_text(encoding="utf-8").splitlines(keepends=True)
            if len(lines) > self.max_lines:
                self.log_file.write_text("".join(lines[-self.max_lines :]), encoding="utf-8")
        except Exception:
            pass

    @staticmethod
    async def _is_owner(ctx: commands.Context) -> bool:
        return await ctx.bot.is_owner(ctx.author)

    @commands.command(name="logs", aliases=["getlogs", "logfile"])
    @commands.check(_is_owner)
    async def get_logs(self, ctx: commands.Context, lines: int | None = 50):
        try:
            lines = min(max(1, lines or 50), 300)
            if not self.log_file.exists():
                return await ctx.send("❌ Log file doesn't exist yet.")
            all_lines = self.log_file.read_text(encoding="utf-8").splitlines(keepends=True)
            if not all_lines:
                return await ctx.send("📭 Log file is empty.")
            requested = all_lines[-lines:]
            content = "".join(requested)
            file = discord.File(
                io.BytesIO(content.encode()), filename=f"bot_logs_last_{lines}_lines.txt"
            )
            view = discord.ui.LayoutView(timeout=None)
            children = [
                discord.ui.TextDisplay("## 📁 Bot Logs"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(f"**Description:** Last {lines} lines"),
                discord.ui.TextDisplay(
                    f"**File Info:** Lines: {len(requested)} • Size: {len(content)} chars"
                ),
            ]
            if len(requested) >= 5:
                preview = "".join(requested[-5:])[-500:]
                children.append(
                    discord.ui.TextDisplay(f"**Preview (last 5 lines):**\n```{preview}```")
                )
            children.append(discord.ui.TextDisplay(f"-# Requested by {ctx.author.name}"))
            view.add_item(discord.ui.Container(*children, accent_color=EmberColors.SUCCESS))
            await ctx.send(view=view, file=file)
        except Exception as e:
            await ctx.send(f"❌ Error reading logs: {e}")

    @commands.command(name="logstats", aliases=["loginfo"])
    @commands.check(_is_owner)
    async def log_stats(self, ctx: commands.Context):
        try:
            if not self.log_file.exists():
                return await ctx.send("❌ Log file doesn't exist yet.")
            lines = self.log_file.read_text(encoding="utf-8").splitlines(keepends=True)
            size = self.log_file.stat().st_size
            ts_pattern = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"
            first = re.search(ts_pattern, lines[0]).group() if lines else None
            last = re.search(ts_pattern, lines[-1]).group() if lines else None

            # Build stats display
            stats_lines = [
                f"**File:** `{self.log_file}`",
                f"**Lines:** `{len(lines)}`  •  **Max:** `{self.max_lines}`  •  **Size:** `{size:,} bytes`",
            ]
            if first:
                stats_lines.append(f"**First Entry:** `{first}`")
            if last:
                stats_lines.append(f"**Last Entry:** `{last}`")

            # Log level counts
            levels = {"INFO": 0, "WARNING": 0, "ERROR": 0, "CRITICAL": 0, "PRINT": 0}
            for line in lines[-500:]:
                for lvl in levels:
                    if f"| {lvl} |" in line:
                        levels[lvl] += 1
                        break
            summary = "\n".join(f"• {k}: {v}" for k, v in levels.items() if v)
            if summary:
                stats_lines.append(f"**Recent Log Levels:**\n```{summary}```")

            view = discord.ui.LayoutView(timeout=None)
            view.add_item(
                discord.ui.Container(
                    discord.ui.TextDisplay("## 📊 Log File Statistics"),
                    discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                    discord.ui.TextDisplay("\n".join(stats_lines)),
                    accent_color=discord.Color.blurple(),
                )
            )
            await ctx.send(view=view)
        except Exception as e:
            await ctx.send(f"❌ Error: {e}")

    @commands.command(name="clearlogs", aliases=["resetlogs"])
    @commands.check(_is_owner)
    async def clear_logs(self, ctx: commands.Context):
        class ConfirmLayoutView(discord.ui.LayoutView):
            def __init__(self, cog):
                super().__init__(timeout=30)
                self.cog = cog

                # Create buttons with callbacks
                async def confirm_callback(interaction: discord.Interaction):
                    if interaction.user.id != ctx.author.id:
                        return await interaction.response.send_message(
                            "Not for you.", ephemeral=True
                        )
                    await interaction.response.defer()
                    try:
                        backup = self.cog.log_file.with_suffix(
                            f".backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                        )
                        await asyncio.to_thread(shutil.copy2, self.cog.log_file, backup)
                        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        await asyncio.to_thread(
                            self.cog.log_file.write_text,
                            f"{ts} | INFO | LogManager | Cleared by {interaction.user}\n"
                            + "=" * 80
                            + "\n",
                            encoding="utf-8",
                        )
                        # Show success
                        success_view = discord.ui.LayoutView(timeout=None)
                        success_view.add_item(
                            discord.ui.Container(
                                discord.ui.TextDisplay("## ✅ Log File Cleared"),
                                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                                discord.ui.TextDisplay("Backup created and logs cleared."),
                                accent_color=EmberColors.SUCCESS,
                            )
                        )
                        await interaction.edit_original_response(view=success_view)
                    except Exception as e:
                        await interaction.followup.send(f"❌ Error: {e}")

                async def cancel_callback(interaction: discord.Interaction):
                    if interaction.user.id != ctx.author.id:
                        return await interaction.response.send_message(
                            "Not for you.", ephemeral=True
                        )
                    cancel_view = discord.ui.LayoutView(timeout=None)
                    cancel_view.add_item(
                        discord.ui.Container(
                            discord.ui.TextDisplay("## ❌ Cancelled"),
                            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                            discord.ui.TextDisplay("Log file was not cleared."),
                            accent_color=EmberColors.ERROR,
                        )
                    )
                    await interaction.response.edit_message(view=cancel_view)

                btn_confirm = discord.ui.Button(
                    label="✅ Yes, Clear Logs",
                    style=discord.ButtonStyle.danger,
                    custom_id="confirm_clear",
                )
                btn_confirm.callback = confirm_callback

                btn_cancel = discord.ui.Button(
                    label="❌ Cancel", style=discord.ButtonStyle.secondary, custom_id="cancel_clear"
                )
                btn_cancel.callback = cancel_callback

                # Build container with ActionRow
                self.add_item(
                    discord.ui.Container(
                        discord.ui.TextDisplay("## ⚠️ Clear Log File"),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay(
                            "This will create a backup and clear all log entries."
                        ),
                        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                        discord.ui.TextDisplay("**Are you sure?"),
                        discord.ui.ActionRow(btn_confirm, btn_cancel),
                        accent_color=EmberColors.WARNING,
                    )
                )

        await ctx.send(view=ConfirmLayoutView(self))

    @commands.command(name="searchlogs", aliases=["grep"])
    @commands.check(_is_owner)
    async def search_logs(self, ctx: commands.Context, *, search_term: str):
        try:
            if not self.log_file.exists():
                return await ctx.send("❌ Log file doesn't exist yet.")
            lines = self.log_file.read_text(encoding="utf-8").splitlines(keepends=True)
            matches = [line for line in lines if search_term.lower() in line.lower()][:50]
            if not matches:
                return await ctx.send(f"❌ No matches for `{search_term}`")
            result = "".join(matches[-25:])[-1500:]
            view = discord.ui.LayoutView(timeout=None)
            children = [
                discord.ui.TextDisplay("## 🔍 Log Search Results"),
                discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
                discord.ui.TextDisplay(f"**Search:** `{search_term}`"),
                discord.ui.TextDisplay(f"**Found {len(matches)} matches:**\n```{result}```"),
            ]
            view.add_item(discord.ui.Container(*children, accent_color=discord.Color.blurple()))
            await ctx.send(view=view)
        except Exception as e:
            await ctx.send(f"❌ Error: {e}")

    @commands.Cog.listener()
    async def on_command_error(self, ctx: commands.Context, error):
        if isinstance(error, commands.CheckFailure):
            return
        cmd_name = (
            ctx.command.name if ctx.command else ctx.message.content if ctx.message else "Unknown"
        )
        self.logger.error(f"Command '{cmd_name}' failed: {error}")
        if hasattr(error, "original"):
            traceback.print_exception(
                type(error.original), error.original, error.original.__traceback__
            )

    async def cog_unload(self) -> None:
        logging.getLogger().removeHandler(self.file_handler)
        self.file_handler.close()
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__


async def setup(bot):
    await bot.add_cog(LogManagerCog(bot))
