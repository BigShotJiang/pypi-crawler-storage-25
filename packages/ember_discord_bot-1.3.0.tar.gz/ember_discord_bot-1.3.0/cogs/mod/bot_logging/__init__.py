from .cog import LogManagerCog


async def setup(bot):
    await bot.add_cog(LogManagerCog(bot))
