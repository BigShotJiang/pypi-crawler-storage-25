from .cog import Filter


async def setup(bot) -> None:
    await bot.add_cog(Filter(bot))
