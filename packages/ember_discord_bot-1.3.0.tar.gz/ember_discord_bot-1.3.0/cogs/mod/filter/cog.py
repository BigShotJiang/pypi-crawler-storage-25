"""Filter system — automatic message content moderation.

Provides configurable filters for:
- Word/phrase blocking (with regex)
- Domain/URL blocking
- Invite link detection
- Automated actions (delete, warn, mute, ban)
- Role/channel exemptions
"""

from __future__ import annotations

import re
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.data_deletion import register_data_callbacks
from core.i18n import Translator
from core.permissions import PermissionLevel, requires
from utils.cards import make_error_card, make_info_card, make_list_card, make_success_card
from utils.feature_registry import ConfigField, FieldType, feature

_ = Translator("Filter", __file__)


@feature(
    display_name="Content Filter",
    emoji="🛡️",
    description="Automatic message filtering with word/regex/domain/invite blocking and exemptions.",
    fields=[
        ConfigField("enabled", "Enabled", FieldType.BOOLEAN, default=True),
    ],
)
class Filter(EmberCog, name="Filter"):
    """Automatic content filtering and moderation."""

    filter = app_commands.Group(name="filter", description="Content filtering commands")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._bot_user_mention = None
        self.db.defaults(
            {
                "guild": {
                    "filters": None,
                    "exempt_roles": None,
                    "exempt_channels": None,
                    "enabled": True,
                },
            }
        )

    async def cog_load(self) -> None:
        await super().cog_load()
        self._bot_user_mention = self.bot.user.mention if self.bot.user else None
        register_data_callbacks(self)

    # ─── Message Listener ─────────────────────────────────────────────────────────

    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or not message.guild:
            return

        if not await self.db.guild(message.guild.id).is_enabled():
            return

        # Check if bot can moderate this channel
        if not message.channel.permissions_for(message.guild.me).manage_messages:
            return

        # Check exemptions (owner, admin, mod roles)
        if await self._is_exempt(message):
            return

        # Get filters for this guild
        filters = await self._get_filters(message.guild.id)
        if not filters:
            return

        # Check against each filter
        trigger_results = []
        for filter_rule in filters:
            if await self._check_filter(filter_rule, message):
                trigger_results.append(filter_rule)

        if not trigger_results:
            return

        # Take action (use most severe or first)
        action = trigger_results[0].get("action", "delete")
        reason = f"Triggered filter: {trigger_results[0].get('name', 'Unknown')}"

        try:
            await message.delete()
        except Exception:
            pass

        if action == "warn":
            # Add warning via moderation cog or modlog
            await self._warn_user(message.author, message.guild, reason)
        elif action == "mute":
            # Apply timeout (10 minutes default)
            try:
                await message.author.timeout(
                    discord.utils.utcnow() + timedelta(minutes=10), reason=reason
                )
            except Exception:
                pass
        elif action == "kick":
            try:
                await message.author.kick(reason=reason)
            except Exception:
                pass
        elif action == "ban":
            try:
                await message.author.ban(reason=reason, delete_message_seconds=86400)
            except Exception:
                pass

    async def _is_exempt(self, message: discord.Message) -> bool:
        """Check if user/channel is exempt from filters."""
        if not message.guild:
            return False

        member = message.guild.get_member(message.author.id)
        if not member:
            return False

        # Bot owners exempt
        if await self.bot.is_owner(member):
            return True

        # Guild owner exempt
        if member.id == message.guild.owner_id:
            return True

        # Admin permission exempt
        if member.guild_permissions.administrator:
            return True

        # Check configured exempt roles
        cfg = await self.db.guild(message.guild.id).all()
        exempt_role_ids = cfg.get("exempt_roles") or []
        if any(role.id in exempt_role_ids for role in member.roles):
            return True

        # Check exempt channels
        exempt_channels = cfg.get("exempt_channels") or []
        if message.channel.id in exempt_channels:
            return True

        return False

    async def _check_filter(self, filter_rule: dict, message: discord.Message) -> bool:
        """Check if message triggers a filter rule."""
        try:
            # Check content triggers
            content = message.content.lower()
            for trigger in filter_rule.get("triggers", []):
                pattern = trigger.get("pattern", "")
                if not pattern:
                    continue

                # If regex
                if trigger.get("regex", False):
                    try:
                        if re.search(pattern, content, re.IGNORECASE):
                            return True
                    except re.error:
                        continue
                else:
                    # Simple substring match
                    if pattern.lower() in content:
                        return True

            # Check embeds
            if filter_rule.get("check_embeds", False):
                for embed in message.embeds:
                    embed_text = (embed.title or "") + (embed.description or "")
                    for field in embed.fields:
                        embed_text += field.value or ""
                    for trigger in filter_rule.get("triggers", []):
                        pattern = trigger.get("pattern", "")
                        if pattern and pattern.lower() in embed_text.lower():
                            return True

            return False
        except Exception:
            return False

    async def _warn_user(self, target: discord.Member, guild: discord.Guild, reason: str) -> None:
        """Issue a warning to a user (integration with modlog)."""
        try:
            # Try to use moderation cog if loaded
            from core.modlog import create_case

            await create_case(
                bot=self.bot,
                guild=guild,
                action="warn",
                user=target,
                mod=self.bot.user,
                reason=reason,
            )
        except Exception:
            pass

    # ─── Admin Commands ───────────────────────────────────────────────────────────

    @filter.command(name="add", description="Add a content filter")
    @app_commands.describe(
        name="Filter name",
        pattern="Word/phrase to block (use * for wildcard)",
        action="Action to take",
        regex="Treat pattern as regex",
    )
    @requires(PermissionLevel.ADMIN)
    async def filter_add(
        self,
        interaction: discord.Interaction,
        name: str,
        pattern: str,
        action: str = "delete",
        regex: bool = False,
    ) -> None:
        await interaction.response.defer(ephemeral=True)

        if action not in ["delete", "warn", "mute", "kick", "ban"]:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Invalid Action", "Must be delete, warn, mute, kick, or ban."
                ),
                ephemeral=True,
            )
            return

        filters = await self._get_filters(interaction.guild.id)
        if any(f.get("name") == name for f in filters):
            await interaction.followup.send(
                view=make_error_card("❌ Exists", f"Filter `{name}` already exists."),
                ephemeral=True,
            )
            return

        filters.append(
            {
                "name": name,
                "triggers": [{"pattern": pattern, "regex": regex}],
                "action": action,
                "created_by": interaction.user.id,
                "created_at": discord.utils.utcnow().isoformat(),
            }
        )
        await self._save_filters(interaction.guild.id, filters)

        await interaction.followup.send(
            view=make_success_card("✅ Filter Added", f"Filter `{name}` created."),
            ephemeral=True,
        )

    @filter.command(name="remove", description="Remove a filter")
    @app_commands.describe(name="Filter name")
    @requires(PermissionLevel.ADMIN)
    async def filter_remove(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        filters = await self._get_filters(interaction.guild.id)
        new_filters = [f for f in filters if f.get("name") != name]
        if len(new_filters) == len(filters):
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Filter `{name}` not found."),
                ephemeral=True,
            )
            return
        await self._save_filters(interaction.guild.id, new_filters)
        await interaction.followup.send(
            view=make_success_card("✅ Removed", f"Filter `{name}` removed."),
            ephemeral=True,
        )

    @filter.command(name="list", description="List all filters in this server")
    async def filter_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=False)
        filters = await self._get_filters(interaction.guild.id)
        if not filters:
            await interaction.followup.send(
                view=make_info_card("📋 Filters", "No filters configured."),
                ephemeral=False,
            )
            return
        lines = []
        for f in filters:
            triggers = ", ".join(t["pattern"] for t in f.get("triggers", []))
            lines.append(
                f"**{f.get('name')}** → {f.get('action', 'delete')}\n  Triggers: {triggers}"
            )
        await interaction.followup.send(
            view=make_list_card(f"📋 Filters ({len(filters)})", lines, per_page=10),
            ephemeral=False,
        )

    @filter.command(name="exempt_role", description="Add/remove role from filter exemptions")
    @app_commands.describe(role="Role to exempt", action="Add or remove")
    @requires(PermissionLevel.ADMIN)
    async def filter_exempt_role(
        self,
        interaction: discord.Interaction,
        role: discord.Role,
        action: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        if action not in ["add", "remove"]:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Action must be 'add' or 'remove'"),
                ephemeral=True,
            )
            return

        g = self.db.guild(interaction.guild.id)
        cfg = await g.all()
        exempt_roles = cfg.get("exempt_roles") or []

        if action == "add":
            if role.id not in exempt_roles:
                exempt_roles.append(role.id)
                await g.set("exempt_roles", exempt_roles)
                await interaction.followup.send(
                    view=make_success_card(
                        "✅ Exempt", f"{role.mention} added to filter exemptions."
                    ),
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    view=make_info_card("ℹ️ Already Exempt", f"{role.mention} is already exempt."),
                    ephemeral=True,
                )
        else:
            if role.id in exempt_roles:
                exempt_roles.remove(role.id)
                await g.set("exempt_roles", exempt_roles)
                await interaction.followup.send(
                    view=make_success_card(
                        "✅ Removed", f"{role.mention} removed from filter exemptions."
                    ),
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    view=make_info_card("ℹ️ Not Exempt", f"{role.mention} is not in exemptions."),
                    ephemeral=True,
                )

    @filter.command(name="exempt_channel", description="Add/remove channel from filter exemptions")
    @app_commands.describe(channel="Channel to exempt", action="Add or remove")
    @requires(PermissionLevel.ADMIN)
    async def filter_exempt_channel(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        action: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        if action not in ["add", "remove"]:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Action must be 'add' or 'remove'"),
                ephemeral=True,
            )
            return

        g = self.db.guild(interaction.guild.id)
        cfg = await g.all()
        exempt_channels = cfg.get("exempt_channels") or []

        if action == "add":
            if channel.id not in exempt_channels:
                exempt_channels.append(channel.id)
                await g.set("exempt_channels", exempt_channels)
                await interaction.followup.send(
                    view=make_success_card(
                        "✅ Exempt", f"{channel.mention} added to filter exemptions."
                    ),
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    view=make_info_card(
                        "ℹ️ Already Exempt", f"{channel.mention} is already exempt."
                    ),
                    ephemeral=True,
                )
        else:
            if channel.id in exempt_channels:
                exempt_channels.remove(channel.id)
                await g.set("exempt_channels", exempt_channels)
                await interaction.followup.send(
                    view=make_success_card(
                        "✅ Removed", f"{channel.mention} removed from filter exemptions."
                    ),
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    view=make_info_card(
                        "ℹ️ Not Exempt", f"{channel.mention} is not in exemptions."
                    ),
                    ephemeral=True,
                )

    # ─── Storage ─────────────────────────────────────────────────────────────────

    async def _get_filters(self, guild_id: int) -> list[dict]:
        filters = await self.db.guild(guild_id).get("filters")
        return filters if filters else []

    async def _save_filters(self, guild_id: int, filters: list[dict]) -> None:
        await self.db.guild(guild_id).set("filters", filters)

    # ─── GDPR Callbacks ───────────────────────────────────────────────────────────

    async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """Filter doesn't store user-specific data, so nothing to delete."""
        return {"note": "No user-specific data stored"}

    async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict:
        """No user data to export."""
        return {"note": "No user-specific data stored"}


async def setup(bot):
    await bot.add_cog(Filter(bot))
