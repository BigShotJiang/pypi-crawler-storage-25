from .cog import BrandingCog


async def setup(bot):
    await bot.add_cog(BrandingCog(bot))
