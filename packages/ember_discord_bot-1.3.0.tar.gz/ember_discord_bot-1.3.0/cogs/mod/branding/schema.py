from typing import TypedDict


class BrandingGuildConfig(TypedDict, total=False):
    """Guild-level branding configuration."""

    enabled: bool
