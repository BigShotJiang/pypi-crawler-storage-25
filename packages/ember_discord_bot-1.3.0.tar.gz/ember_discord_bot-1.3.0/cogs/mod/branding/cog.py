from __future__ import annotations

from discord.ext import commands

from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from utils.feature_registry import ConfigField, FieldType, feature

from .schema import BrandingGuildConfig

_ = Translator("branding", __file__)


@cog_i18n(_)
@feature(
    display_name="Branding",
    description="Customize the bot's appearance in this server. Set theme colors and visual identity.",
    emoji="🎨",
    fields=[
        ConfigField(
            key="accent_color",
            label="Theme Accent Color",
            type=FieldType.TEXT,
            required=False,
            default="#FEE75C",
            placeholder="#FEE75C (orange/yellow)",
            description="Hex color code for the server's theme accent. Default is Ember orange (#FEE75C).",
        ),
    ],
)
class BrandingCog(EmberCog, name="Branding"):
    """Manage server-specific branding and theme colors."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.defaults(
            {
                "guild": {"enabled": True, "accent_color": "#FEE75C"},
            }
        )
        self.db.register_schema("guild", BrandingGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        pass


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(BrandingCog(bot))
