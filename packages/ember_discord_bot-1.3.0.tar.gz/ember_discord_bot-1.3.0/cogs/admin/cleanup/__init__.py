from .cog import Cleanup


async def setup(bot) -> None:
    await bot.add_cog(Cleanup(bot))
