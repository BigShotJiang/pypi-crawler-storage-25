from __future__ import annotations

import logging
import re
from datetime import UTC, datetime, timedelta

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from utils.cards import make_error_card, make_success_card

log = logging.getLogger("ember.cleanup")

_TWO_WEEKS = timedelta(weeks=2)


class Cleanup(EmberCog, name="Cleanup"):
    """Advanced message cleanup with per-filter targeting."""

    async def _purge(
        self,
        interaction: discord.Interaction,
        check,
        limit: int = 100,
        *,
        channel: discord.TextChannel | None = None,
    ) -> None:
        """Run bulk delete and report results."""
        target = channel or interaction.channel
        cutoff = datetime.now(UTC) - _TWO_WEEKS

        async def _check_age(m: discord.Message) -> bool:
            return m.created_at > cutoff and check(m)

        try:
            deleted = await target.purge(limit=limit, check=_check_age, bulk=True)
            await interaction.followup.send(
                view=make_success_card(
                    "🧹 Cleanup Done",
                    f"Deleted **{len(deleted)}** message(s) in {target.mention}.",
                ),
                ephemeral=True,
            )
        except discord.Forbidden:
            await interaction.followup.send(
                view=make_error_card("❌ No Permission", "Missing Manage Messages permission."),
                ephemeral=True,
            )
        except discord.HTTPException as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(exc)),
                ephemeral=True,
            )

    group = app_commands.Group(name="cleanup", description="Delete messages with various filters")

    @group.command(name="all", description="Delete recent messages (no filter)")
    @app_commands.describe(
        amount="Number of messages to delete (1–500)",
        channel="Channel to clean (defaults to current)",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_all(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        await self._purge(interaction, lambda _: True, amount, channel=channel)

    @group.command(name="bots", description="Delete messages from bots")
    @app_commands.describe(
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_bots(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        await self._purge(interaction, lambda m: m.author.bot, amount, channel=channel)

    @group.command(name="user", description="Delete messages from a specific user")
    @app_commands.describe(
        user="Target user",
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_user(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        await self._purge(interaction, lambda m: m.author.id == user.id, amount, channel=channel)

    @group.command(name="contains", description="Delete messages containing text")
    @app_commands.describe(
        text="Substring to match (case-insensitive)",
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_contains(
        self,
        interaction: discord.Interaction,
        text: str,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        needle = text.lower()
        await self._purge(
            interaction,
            lambda m: needle in m.content.lower(),
            amount,
            channel=channel,
        )

    @group.command(name="links", description="Delete messages containing links")
    @app_commands.describe(
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_links(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        _url = re.compile(r"https?://\S+")
        await self._purge(
            interaction,
            lambda m: bool(_url.search(m.content)),
            amount,
            channel=channel,
        )

    @group.command(name="invites", description="Delete messages containing Discord invites")
    @app_commands.describe(
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_invites(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        _invite = re.compile(r"discord(?:\.gg|app\.com/invite)/\S+", re.IGNORECASE)
        await self._purge(
            interaction,
            lambda m: bool(_invite.search(m.content)),
            amount,
            channel=channel,
        )

    @group.command(name="embeds", description="Delete messages with embeds or attachments")
    @app_commands.describe(
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_embeds(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        await self._purge(
            interaction,
            lambda m: bool(m.embeds or m.attachments),
            amount,
            channel=channel,
        )

    @group.command(name="regex", description="Delete messages matching a regex pattern")
    @app_commands.describe(
        pattern="Regular expression pattern",
        amount="Max messages to scan (1–500)",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_regex(
        self,
        interaction: discord.Interaction,
        pattern: str,
        amount: app_commands.Range[int, 1, 500] = 100,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            compiled = re.compile(pattern, re.IGNORECASE)
        except re.error as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Bad Pattern", f"Invalid regex: `{exc}`"),
                ephemeral=True,
            )
            return
        await self._purge(
            interaction,
            lambda m: bool(compiled.search(m.content)),
            amount,
            channel=channel,
        )

    @group.command(name="after", description="Delete messages after a specific message ID")
    @app_commands.describe(
        message_id="ID of the message to delete after",
        channel="Channel to clean",
    )
    @app_commands.default_permissions(manage_messages=True)
    async def cmd_after(
        self,
        interaction: discord.Interaction,
        message_id: str,
        channel: discord.TextChannel | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        target = channel or interaction.channel
        try:
            anchor = await target.fetch_message(int(message_id))
        except (ValueError, discord.NotFound):
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", "Message not found in this channel."),
                ephemeral=True,
            )
            return
        try:
            deleted = await target.purge(limit=500, after=anchor, bulk=True)
            await interaction.followup.send(
                view=make_success_card(
                    "🧹 Cleanup Done",
                    f"Deleted **{len(deleted)}** message(s) after that message.",
                ),
                ephemeral=True,
            )
        except (discord.Forbidden, discord.HTTPException) as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(exc)),
                ephemeral=True,
            )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Cleanup(bot))
