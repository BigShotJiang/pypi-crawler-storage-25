from .cog import SettingsCog


async def setup(bot):
    await bot.add_cog(SettingsCog(bot))
