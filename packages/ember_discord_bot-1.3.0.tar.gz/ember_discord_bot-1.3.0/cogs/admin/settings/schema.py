from typing import TypedDict


class SettingsGuildConfig(TypedDict, total=False):
    """Guild-level settings configuration."""

    enabled: bool
