"""Settings — central /config panel for all registered features."""

from __future__ import annotations

import discord
from discord import app_commands, ui
from discord.ext import commands

from core.branding import EmberColors
from core.cog import EmberCog
from core.i18n import Translator, cog_i18n
from core.store import get_cog_store
from utils.cards import make_error_card
from utils.feature_registry import FeatureMeta, FieldType, all_features, feature, get_feature

from .schema import SettingsGuildConfig

_ = Translator("settings", __file__)


# ─── Interaction helpers ──────────────────────────────────────────────────────


async def _safe_edit(interaction: discord.Interaction, view: ui.LayoutView) -> None:
    """Edit the originating message, or send a fresh ephemeral if the token has expired."""
    try:
        await interaction.response.edit_message(view=view)
    except discord.NotFound:
        await interaction.response.send_message(
            view=make_error_card(
                "⏰ Panel Expired",
                "This config panel has expired. Run `/config` again.",
            ),
            ephemeral=True,
        )


# ─── Config access wrappers ────────────────────────────────────────────────────


async def _get_config_dict(cog_name: str, guild_id: int) -> dict | None:
    """Get the full config dict (merged with defaults) for a cog+guild."""
    store = get_cog_store(cog_name)
    if store is None:
        return None
    return await store.get_all("guild", guild_id)


async def _set_config_dict(cog_name: str, guild_id: int, data: dict) -> None:
    """Replace the entire config for a cog+guild with the given dict, atomically."""
    store = get_cog_store(cog_name)
    if store is None:
        return
    async with store.transaction("guild", guild_id) as cfg:
        cfg.clear()
        cfg.update(data)


async def _clear_config(cog_name: str, guild_id: int) -> None:
    """Clear all stored config for a cog+guild (reverts to defaults)."""
    store = get_cog_store(cog_name)
    if store is None:
        return
    await store.delete("guild", guild_id)


# ─── Value formatting ─────────────────────────────────────────────────────────


def _fmt(cfg: dict, f) -> str:
    val = cfg.get(f.key, f.default)
    if val is None:
        return "-# *(not set)*"
    if f.type == FieldType.CHANNEL:
        return f"<#{val}>"
    if f.type == FieldType.ROLE:
        return f"<@&{val}>"
    if f.type in (FieldType.USER, FieldType.MENTIONABLE):
        return f"<@{val}>"
    if f.type == FieldType.BOOLEAN:
        return "✅ Yes" if val else "❌ No"
    return str(val)


# ─── Feature list ─────────────────────────────────────────────────────────────


# Discord caps Select options at 25; paginate when more features are registered.
_FEATURES_PER_PAGE = 25


class _FeatureSelect(ui.Select):
    def __init__(
        self, guild_id: int, config_data: dict[str, dict], page: int, page_features: list
    ) -> None:
        self._gid = guild_id
        self._config_data = config_data
        self._page = page
        if page_features:
            options = [
                discord.SelectOption(
                    label=f.display_name[:100],
                    value=f.cog_name,
                    description=(f.description[:100] if f.description else None),
                    emoji=f.emoji,
                )
                for f in page_features
            ]
        else:
            options = [discord.SelectOption(label="No features registered", value="_none")]
        super().__init__(
            placeholder="Select a feature to configure…",
            options=options,
            custom_id=f"cfg:list_select:{page}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.values[0] == "_none":
            return await interaction.response.defer()
        feat = get_feature(self.values[0])
        if feat:
            cfg = self._config_data.get(feat.cog_name, {})
            await _safe_edit(
                interaction, FeatureDetailView(feat, self._gid, cfg, self._config_data)
            )
        else:
            await interaction.response.defer()


class _PageNavBtn(ui.Button):
    def __init__(
        self,
        guild_id: int,
        config_data: dict[str, dict],
        page: int,
        direction: int,
        total_pages: int,
    ) -> None:
        self._gid = guild_id
        self._config_data = config_data
        self._target_page = page + direction
        label = "← Prev" if direction < 0 else "Next →"
        disabled = self._target_page < 0 or self._target_page >= total_pages
        super().__init__(
            label=label,
            style=discord.ButtonStyle.secondary,
            custom_id=f"cfg:list_page:{self._target_page}",
            disabled=disabled,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await _safe_edit(
            interaction, FeatureListView(self._gid, self._config_data, page=self._target_page)
        )


class FeatureListView(ui.LayoutView):
    def __init__(self, guild_id: int, config_data: dict[str, dict], *, page: int = 0) -> None:
        super().__init__(timeout=300)
        self._config_data = config_data
        features = all_features()
        total_pages = max(1, (len(features) + _FEATURES_PER_PAGE - 1) // _FEATURES_PER_PAGE)
        page = max(0, min(page, total_pages - 1))
        start = page * _FEATURES_PER_PAGE
        page_features = features[start : start + _FEATURES_PER_PAGE]

        lines = []
        for f in page_features:
            cfg = config_data.get(f.cog_name, {})
            dot = "🟢" if cfg.get("enabled", True) else "🔴"
            lines.append(f"{dot} {f.emoji} **{f.display_name}**")

        body = "\n".join(lines) if lines else "*No features registered.*"
        children: list = [
            ui.TextDisplay("## ⚙️ Server Config"),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay(body),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay("-# Select a feature below to enable, disable, or configure it."),
            ui.ActionRow(_FeatureSelect(guild_id, config_data, page, page_features)),
        ]
        if total_pages > 1:
            children.append(ui.TextDisplay(f"-# Page **{page + 1}** of **{total_pages}**"))
            children.append(
                ui.ActionRow(
                    _PageNavBtn(guild_id, config_data, page, -1, total_pages),
                    _PageNavBtn(guild_id, config_data, page, +1, total_pages),
                )
            )
        self.add_item(ui.Container(*children, accent_color=EmberColors.PRIMARY))


# ─── Feature detail buttons ───────────────────────────────────────────────────


class _ToggleBtn(ui.Button):
    def __init__(
        self, feat: FeatureMeta, gid: int, enabled: bool, config_data: dict[str, dict]
    ) -> None:
        self._feat, self._gid = feat, gid
        self._config_data = config_data
        super().__init__(
            label="Disable" if enabled else "Enable",
            style=discord.ButtonStyle.danger if enabled else discord.ButtonStyle.success,
            custom_id=f"cfg:toggle:{feat.cog_name}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        cfg["enabled"] = not cfg.get("enabled", True)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        self._config_data[self._feat.cog_name] = cfg
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


class _ConfigureBtn(ui.Button):
    def __init__(self, feat: FeatureMeta, gid: int, config_data: dict[str, dict]) -> None:
        self._feat, self._gid = feat, gid
        self._config_data = config_data
        super().__init__(
            label="Configure…",
            style=discord.ButtonStyle.secondary,
            custom_id=f"cfg:configure:{feat.cog_name}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        await interaction.response.send_modal(
            _ConfigModal(self._feat, self._gid, cfg, self._config_data)
        )


class _ResetBtn(ui.Button):
    def __init__(self, feat: FeatureMeta, gid: int, config_data: dict[str, dict]) -> None:
        self._feat, self._gid = feat, gid
        self._config_data = config_data
        super().__init__(
            label="Reset",
            style=discord.ButtonStyle.secondary,
            emoji="🗑️",
            custom_id=f"cfg:reset:{feat.cog_name}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await _clear_config(self._feat.cog_name, self._gid)
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


class _BackBtn(ui.Button):
    def __init__(self, gid: int, config_data: dict[str, dict]) -> None:
        self._gid = gid
        self._config_data = config_data
        super().__init__(
            label="← Back",
            style=discord.ButtonStyle.secondary,
            custom_id="cfg:back",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        config_data = {}
        for f in all_features():
            config_data[f.cog_name] = await _get_config_dict(f.cog_name, self._gid) or {}
        await _safe_edit(interaction, FeatureListView(self._gid, config_data))


class _BoolToggleBtn(ui.Button):
    """Inline toggle for a single BOOLEAN config field."""

    def __init__(
        self,
        feat: FeatureMeta,
        gid: int,
        key: str,
        label: str,
        val: bool,
        config_data: dict[str, dict],
    ) -> None:
        self._feat, self._gid, self._key = feat, gid, key
        self._config_data = config_data
        icon = "✅" if val else "❌"
        state = "On" if val else "Off"
        super().__init__(
            label=f"{icon} {label}: {state}",
            style=discord.ButtonStyle.success if val else discord.ButtonStyle.secondary,
            custom_id=f"cfg:bool:{feat.cog_name}:{key}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        cfg[self._key] = not cfg.get(self._key, False)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


# ─── Feature detail selects ───────────────────────────────────────────────────


class _ChannelSelect(ui.ChannelSelect):
    def __init__(self, feat: FeatureMeta, gid: int, f, config_data: dict[str, dict]) -> None:
        self._feat, self._gid, self._key = feat, gid, f.key
        self._config_data = config_data
        types = f.channel_types if f.channel_types else [discord.ChannelType.text]
        kwargs = {}
        if types != [None]:  # sentinel means "all types"
            kwargs["channel_types"] = types
        super().__init__(
            placeholder=f"Set: {f.label}",
            custom_id=f"cfg:ch:{feat.cog_name}:{f.key}",
            min_values=0,
            max_values=1,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        if self.values:
            cfg[self._key] = self.values[0].id
        else:
            cfg.pop(self._key, None)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


class _RoleSelect(ui.RoleSelect):
    def __init__(self, feat: FeatureMeta, gid: int, f, config_data: dict[str, dict]) -> None:
        self._feat, self._gid, self._key = feat, gid, f.key
        self._config_data = config_data
        super().__init__(
            placeholder=f"Set: {f.label}",
            custom_id=f"cfg:role:{feat.cog_name}:{f.key}",
            min_values=0,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        if self.values:
            cfg[self._key] = self.values[0].id
        else:
            cfg.pop(self._key, None)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


class _UserSelect(ui.UserSelect):
    def __init__(self, feat: FeatureMeta, gid: int, f, config_data: dict[str, dict]) -> None:
        self._feat, self._gid, self._key = feat, gid, f.key
        self._config_data = config_data
        super().__init__(
            placeholder=f"Set: {f.label}",
            custom_id=f"cfg:user:{feat.cog_name}:{f.key}",
            min_values=0,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        if self.values:
            cfg[self._key] = self.values[0].id
        else:
            cfg.pop(self._key, None)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


class _MentionableSelect(ui.MentionableSelect):
    def __init__(self, feat: FeatureMeta, gid: int, f, config_data: dict[str, dict]) -> None:
        self._feat, self._gid, self._key = feat, gid, f.key
        self._config_data = config_data
        super().__init__(
            placeholder=f"Set: {f.label}",
            custom_id=f"cfg:mention:{feat.cog_name}:{f.key}",
            min_values=0,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        if self.values:
            val = self.values[0]
            cfg[self._key] = val.id
        else:
            cfg.pop(self._key, None)
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


# ─── Feature detail view ──────────────────────────────────────────────────────


class FeatureDetailView(ui.LayoutView):
    def __init__(
        self, feat: FeatureMeta, guild_id: int, cfg: dict, config_data: dict[str, dict]
    ) -> None:
        super().__init__(timeout=300)
        self._feat = feat
        self._guild_id = guild_id
        self._config_data = config_data
        enabled = cfg.get("enabled", True)

        status_line = "🟢 **Enabled**" if enabled else "🔴 **Disabled**"
        field_lines = [f"**Status:** {status_line}"]
        for f in feat.fields:
            req = " *(required)*" if f.required else ""
            field_lines.append(f"**{f.label}:** {_fmt(cfg, f)}{req}")

        has_text_int = any(f.type in (FieldType.TEXT, FieldType.INTEGER) for f in feat.fields)
        bool_fields = [f for f in feat.fields if f.type == FieldType.BOOLEAN]

        main_row = ui.ActionRow(
            _ToggleBtn(feat, guild_id, enabled, config_data),
            _ResetBtn(feat, guild_id, config_data),
        )
        if has_text_int:
            main_row.add_item(_ConfigureBtn(feat, guild_id, config_data))
        main_row.add_item(_BackBtn(guild_id, config_data))

        hints = []
        field_types = {f.type for f in feat.fields}
        if FieldType.CHANNEL in field_types or FieldType.ROLE in field_types:
            hints.append("use the selects below to pick channels and roles")
        if FieldType.BOOLEAN in field_types:
            hints.append("toggle options with the buttons")
        if FieldType.TEXT in field_types or FieldType.INTEGER in field_types:
            hints.append("click **Configure…** to set text values")
        hint_line = (
            f"-# 💡 {'; '.join(hints).capitalize()}."
            if hints
            else "-# 💡 Enable or disable this feature with the button below."
        )

        children: list = [
            ui.TextDisplay(f"## {feat.emoji} {feat.display_name}"),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay(feat.description),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay(hint_line),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            ui.TextDisplay("\n".join(field_lines)),
            ui.Separator(spacing=discord.SeparatorSpacing.small),
            main_row,
        ]

        if bool_fields:
            row = ui.ActionRow()
            for i, f in enumerate(bool_fields):
                if i > 0 and i % 5 == 0:
                    children.append(row)
                    row = ui.ActionRow()
                val = cfg.get(f.key, f.default if f.default is not None else False)
                row.add_item(_BoolToggleBtn(feat, guild_id, f.key, f.label, bool(val), config_data))
            children.append(row)

        for f in feat.fields:
            if f.type == FieldType.CHANNEL:
                children.append(ui.ActionRow(_ChannelSelect(feat, guild_id, f, config_data)))
            elif f.type == FieldType.ROLE:
                children.append(ui.ActionRow(_RoleSelect(feat, guild_id, f, config_data)))
            elif f.type == FieldType.USER:
                children.append(ui.ActionRow(_UserSelect(feat, guild_id, f, config_data)))
            elif f.type == FieldType.MENTIONABLE:
                children.append(ui.ActionRow(_MentionableSelect(feat, guild_id, f, config_data)))

        self.add_item(
            ui.Container(
                *children,
                accent_color=EmberColors.SUCCESS if enabled else EmberColors.ERROR,
            )
        )


class _ConfigModal(ui.Modal):
    def __init__(
        self, feat: FeatureMeta, gid: int, current_cfg: dict, config_data: dict[str, dict]
    ) -> None:
        super().__init__(title=f"Configure {feat.display_name}"[:45])
        self._feat, self._gid = feat, gid
        self._config_data = config_data
        self._map: list[tuple[str, ui.TextInput, FieldType]] = []

        for f in feat.fields:
            if f.type not in (FieldType.TEXT, FieldType.INTEGER):
                continue
            current = current_cfg.get(f.key, f.default)
            inp = ui.TextInput(
                label=f.label[:45],
                placeholder=(f.placeholder or f.description)[:100] or None,
                default=str(current) if current is not None else None,
                required=f.required,
                max_length=min(f.max_length, 4000),
                style=(
                    discord.TextStyle.paragraph if f.max_length > 100 else discord.TextStyle.short
                ),
            )
            self.add_item(inp)
            self._map.append((f.key, inp, f.type))

    async def on_submit(self, interaction: discord.Interaction) -> None:
        cfg = await _get_config_dict(self._feat.cog_name, self._gid) or {}
        for key, inp, ftype in self._map:
            val = inp.value.strip()
            if not val:
                cfg.pop(key, None)
                continue
            if ftype == FieldType.INTEGER:
                try:
                    cfg[key] = int(val)
                except ValueError:
                    err_view = ui.LayoutView(timeout=None)
                    err_view.add_item(
                        ui.Container(
                            ui.TextDisplay("## ❌ Invalid Value"),
                            ui.Separator(spacing=discord.SeparatorSpacing.small),
                            ui.TextDisplay(f"**{inp.label}** must be a whole number."),
                            accent_color=EmberColors.ERROR,
                        )
                    )
                    return await interaction.response.send_message(view=err_view, ephemeral=True)
            else:
                cfg[key] = val
        await _set_config_dict(self._feat.cog_name, self._gid, cfg)
        await _safe_edit(
            interaction, FeatureDetailView(self._feat, self._gid, cfg, self._config_data)
        )


# ─── Cog ──────────────────────────────────────────────────────────────────────


@cog_i18n(_)
@feature(
    display_name="Settings",
    description="Central configuration panel for all bot features.",
    emoji="⚙️",
    fields=[],
)
class SettingsCog(EmberCog, name="Settings"):

    settings = app_commands.Group(name="settings", description="Bot settings commands")

    def __init__(self, bot):
        super().__init__(bot)
        self.db.register_schema("guild", SettingsGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        await super().cog_unload()

    @settings.command(name="config", description="Configure bot features for this server")
    @app_commands.checks.has_permissions(administrator=True)
    async def config_cmd(self, interaction: discord.Interaction) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                view=make_error_card("Server Only", "This command can only be used in a server."),
                ephemeral=True,
            )
            return
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        config_data = {}
        for f in all_features():
            cfg = await _get_config_dict(f.cog_name, guild.id) or {}
            config_data[f.cog_name] = cfg
        await interaction.followup.send(view=FeatureListView(guild.id, config_data), ephemeral=True)

    @settings.command(
        name="diagnose", description="Show why a command works or doesn't for a member."
    )
    @app_commands.describe(
        command="Command name to inspect",
        member="Member to check (default: yourself)",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def diagnose_cmd(
        self,
        interaction: discord.Interaction,
        command: str,
        member: discord.Member | None = None,
    ) -> None:
        from core.diagnostics import diagnose_command, format_diagnose_report
        from utils.cards import make_info_card

        await interaction.response.defer(ephemeral=True)
        results = await diagnose_command(command, interaction)
        report = format_diagnose_report(results)
        await interaction.followup.send(
            view=make_info_card(f"Diagnostics: /{command}", report),
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(SettingsCog(bot))
