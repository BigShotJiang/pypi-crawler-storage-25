from typing import TypedDict


class DownloaderGuildConfig(TypedDict, total=False):
    """Guild-level downloader configuration."""

    enabled: bool
