from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import EmberCog
from core.downloader import CogDownloader
from core.i18n import Translator
from core.permissions import PermissionLevel, requires
from utils.cards import (
    make_error_card,
    make_info_card,
    make_list_card,
    make_success_card,
)
from utils.feature_registry import feature

from .schema import DownloaderGuildConfig

_ = Translator("Downloader", __file__)

log = logging.getLogger("ember.downloader")


@feature(
    display_name="Cog Downloader",
    description="Install, update, and manage cogs from git repositories.",
    emoji="📥",
    fields=[],
)
class Downloader(EmberCog):
    """Install and manage cogs from git repositories."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        # The service is attached to bot during setup_hook
        self.service: CogDownloader = bot.downloader  # type: ignore
        self.db.register_schema("guild", DownloaderGuildConfig)

    async def cog_load(self) -> None:
        log.info("Downloader cog loaded, /download commands available")
        await super().cog_load()

    async def cog_unload(self) -> None:
        log.info("Downloader cog unloaded, /download commands unavailable")
        await super().cog_unload()

    download = app_commands.Group(
        name="download", description="Manage cog installations from git repositories"
    )

    @download.command(name="install", description="Install a cog from a git repository")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(
        git_url="Git repository URL (e.g., https://github.com/user/repo.git)",
        name="Name for the cog (default: derived from repo name)",
        branch="Branch to checkout (default: main)",
    )
    async def install(
        self,
        interaction: discord.Interaction,
        git_url: str,
        name: app_commands.Range[str, 1, 32] = None,
        branch: str = "main",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        success, msg = await self.service.install(git_url, name=name, branch=branch)
        if success:
            await interaction.followup.send(
                view=make_success_card("✅ Installed", msg),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Install Failed", msg),
                ephemeral=True,
            )

    @download.command(name="update", description="Update an installed cog to the latest version")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(name="Name of the cog to update")
    async def update(
        self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 32]
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        success, msg = await self.service.update(name)
        if success:
            await interaction.followup.send(
                view=make_success_card("✅ Updated", msg),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Update Failed", msg),
                ephemeral=True,
            )

    @download.command(name="uninstall", description="Uninstall a cog")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(name="Name of the cog to uninstall")
    async def uninstall(
        self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 32]
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        success, msg = await self.service.uninstall(name)
        if success:
            await interaction.followup.send(
                view=make_success_card("✅ Uninstalled", msg), ephemeral=True
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Uninstall Failed", msg),
                ephemeral=True,
            )

    @download.command(name="list", description="List all installed cogs")
    @requires(PermissionLevel.BOT_OWNER)
    async def list_cogs(self, interaction: discord.Interaction) -> None:
        cogs = self.service.list_installed()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("📋 Installed Cogs", "No third-party cogs installed."),
                ephemeral=True,
            )
            return
        lines = []
        for cog in sorted(cogs, key=lambda x: x["name"]):
            pinned = f" (pinned @ `{cog['pinned']}`)" if cog.get("pinned") else ""
            lines.append(
                f"**{cog['name']}**\n"
                f"Repo: {cog['repo_url']}\n"
                f"Branch: {cog['branch']}, Commit: `{cog['commit']}`{pinned}"
            )
        await interaction.response.send_message(
            view=make_list_card(
                f"Installed Cogs ({len(cogs)})", lines, per_page=10, numbered=False
            ),
            ephemeral=True,
        )

    @download.command(name="pin", description="Lock a cog to a specific commit")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(
        name="Name of the cog to pin",
        commit="Commit hash to pin to (default: current HEAD)",
    )
    async def pin(
        self,
        interaction: discord.Interaction,
        name: app_commands.Range[str, 1, 32],
        commit: str = "",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        success, msg = await self.service.pin(name, commit)
        if success:
            await interaction.followup.send(
                view=make_success_card("📌 Pinned", msg),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Pin Failed", msg),
                ephemeral=True,
            )

    @download.command(name="unpin", description="Allow a cog to be updated again")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(name="Name of the cog to unpin")
    async def unpin(
        self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 32]
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        success, msg = await self.service.unpin(name)
        if success:
            await interaction.followup.send(
                view=make_success_card("📌 Unpinned", msg),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Unpin Failed", msg),
                ephemeral=True,
            )

    @download.command(name="info", description="Show details about an installed cog")
    @requires(PermissionLevel.BOT_OWNER)
    @app_commands.describe(name="Name of the cog to inspect")
    async def info(
        self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 32]
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        repo = self.service.get_repo(name)
        if not repo:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Cog `{name}` is not installed."),
                ephemeral=True,
            )
            return

        # Check for requirements
        req_file = repo.path / "requirements.txt"
        req_count = 0
        if req_file.exists():
            try:
                req_count = sum(
                    1
                    for line in req_file.read_text().splitlines()
                    if line.strip() and not line.startswith("#")
                )
            except Exception:
                pass

        pin_status = f"📌 Pinned @ `{repo.pinned_commit[:8]}`" if repo.is_pinned else "Not pinned"
        req_text = f"{req_count} requirement(s)" if req_count else "No external dependencies"
        info_lines = [
            f"**Repository:** {repo.repo_url}",
            f"**Branch:** {repo.branch}",
            f"**Current Commit:** `{repo.short_commit}`",
            f"**Pin Status:** {pin_status}",
            f"**Dependencies:** {req_text}",
        ]

        await interaction.followup.send(
            view=make_info_card("ℹ️ Cog Details", "\n".join(info_lines)),
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(Downloader(bot))
