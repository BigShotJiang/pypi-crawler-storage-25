from .cog import Downloader

__all__ = ["Downloader"]


async def setup(bot):
    await bot.add_cog(Downloader(bot))
