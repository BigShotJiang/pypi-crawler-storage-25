from __future__ import annotations

import discord
from discord import app_commands, ui
from discord.ext import commands

from core._cog_manager import CogManager, get_manager
from core.cog import EmberCog
from core.i18n import Translator
from core.permissions import PermissionLevel, requires
from utils.cards import (
    make_error_card,
    make_info_card,
    make_list_card,
    make_success_card,
    make_warning_card,
)
from utils.feature_registry import feature

from .schema import CogManagerGuildConfig

_ = Translator("CogManagerCog", __file__)


@feature(
    display_name="Cog Manager",
    description="Manage cog loading, enabling, and dependencies.",
    emoji="📦",
    fields=[],
)
class CogManagerCog(EmberCog, name="CogManager"):
    """Manage cog loading states and view dependencies."""

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self.db.register_schema("guild", CogManagerGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        await super().cog_unload()

    group = app_commands.Group(
        name="cog", description="Manage cogs (list, load, unload, enable, disable)"
    )

    @group.command(name="list", description="List all cogs and their status")
    async def cmd_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        manager = get_manager()
        await manager.discover_cogs()
        manager.sync_loaded_from_bot(self.bot)
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.followup.send(
                view=make_info_card("📋 Cogs", "No cogs discovered."),
                ephemeral=True,
            )
            return

        lines = []
        for c in sorted(cogs, key=lambda x: x["name"]):
            status = []
            if c["loaded"]:
                status.append("✅ Loaded")
            else:
                status.append("❌ Not Loaded")
            if not c["enabled"]:
                status.append("⛔ Disabled")
            deps = ", ".join(c.get("dependencies", [])) or "None"
            lines.append(f"`{c['name']}` — {', '.join(status)}\n   Depends: {deps}")

        await interaction.followup.send(
            view=make_list_card(f"📋 Cogs ({len(cogs)})", lines, per_page=10, numbered=False),
            ephemeral=True,
        )

    @group.command(name="info", description="Show detailed info about a cog")
    async def cmd_info(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("📦 Info", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _InfoSelectView(cogs, manager)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="enable", description="Enable a cog globally and optionally load it")
    @requires(PermissionLevel.ADMIN)
    async def cmd_enable(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("✅ Enable", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _EnableSelectView(cogs, manager, self.bot)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="disable", description="Disable a cog globally and unload it")
    @requires(PermissionLevel.ADMIN)
    async def cmd_disable(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("❌ Disable", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _DisableSelectView(cogs, manager, self.bot)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="reload", description="Reload a cog")
    @requires(PermissionLevel.ADMIN)
    async def cmd_reload(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        loaded_cogs = await manager.list_cogs()
        loaded_cogs = [c for c in loaded_cogs if c["loaded"]]
        if not loaded_cogs:
            await interaction.response.send_message(
                view=make_info_card("🔁 Reload", "No cogs are currently loaded."),
                ephemeral=True,
            )
            return

        view = _ReloadSelectView(loaded_cogs, manager)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="guild_enable", description="Enable a cog for this server only")
    @requires(PermissionLevel.ADMIN)
    async def cmd_guild_enable(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("✅ Guild Enable", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _GuildEnableSelectView(cogs, manager, interaction.guild.id)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="guild_disable", description="Disable a cog for this server only")
    @requires(PermissionLevel.ADMIN)
    async def cmd_guild_disable(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("❌ Guild Disable", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _GuildDisableSelectView(cogs, manager, interaction.guild.id)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @group.command(name="guild_status", description="Check if a cog is enabled in this server")
    async def cmd_guild_status(self, interaction: discord.Interaction) -> None:
        manager = get_manager()
        await manager.discover_cogs()
        cogs = await manager.list_cogs()
        if not cogs:
            await interaction.response.send_message(
                view=make_info_card("ℹ️ Guild Status", "No cogs discovered."),
                ephemeral=True,
            )
            return

        view = _GuildStatusSelectView(cogs, manager, interaction.guild.id)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )


class _InfoSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager):
        self._manager = manager
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to view…",
            options=options,
            custom_id="cog:info:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        info = await self._manager.get_cog_info(cog_name)
        if not info:
            await interaction.response.edit_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog_name}` not found."),
            )
            return

        status = "✅ Loaded" if info.loaded else "❌ Not Loaded"
        enabled = "✅ Enabled" if info.enabled else "⛔ Disabled"
        deps = ", ".join(info.dependencies) if info.dependencies else "None"
        conflicts = ", ".join(info.conflicts) if info.conflicts else "None"
        body = (
            f"**Module:** `{info.qualname}`\n"
            f"**Status:** {status} | {enabled}\n"
            f"**Version:** {info.version}\n"
            f"**Dependencies:** {deps}\n"
            f"**Conflicts:** {conflicts}\n"
            f"**Path:** `{info.path}`"
        )
        await interaction.response.edit_message(
            view=make_info_card(f"📦 Cog: {info.name}", body),
        )


class _InfoSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## 📦 Cog Info\nSelect a cog to view details."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_InfoSelect(cogs, manager)),
                accent_color=discord.Color.blurple(),
            )
        )


class _EnableSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager, bot: commands.Bot):
        self._manager = manager
        self._bot = bot
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to enable…",
            options=options,
            custom_id="cog:enable:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        info = await self._manager.get_cog_info(cog_name)
        if not info:
            await interaction.response.edit_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog_name}` not found."),
            )
            return

        if info.enabled:
            await interaction.response.edit_message(
                view=make_info_card("ℹ️ Already Enabled", f"Cog `{cog_name}` is already enabled."),
            )
            return

        try:
            await self._manager.set_enabled(cog_name, True)
            if not info.loaded:
                success = await self._manager.load_cog(self._bot, cog_name)
                if success:
                    await interaction.response.edit_message(
                        view=make_success_card(
                            "✅ Enabled & Loaded", f"Cog `{cog_name}` has been enabled and loaded."
                        ),
                    )
                else:
                    await interaction.response.edit_message(
                        view=make_warning_card(
                            "⚠️ Enabled but Load Failed",
                            f"Cog `{cog_name}` is enabled but failed to load. Check logs.",
                        ),
                    )
            else:
                await interaction.response.edit_message(
                    view=make_success_card(
                        "✅ Enabled", f"Cog `{cog_name}` has been enabled (already loaded)."
                    ),
                )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", str(exc)),
            )


class _EnableSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager, bot: commands.Bot):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ✅ Enable Cog\nSelect a cog to enable."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_EnableSelect(cogs, manager, bot)),
                accent_color=discord.Color.blurple(),
            )
        )


class _DisableSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager, bot: commands.Bot):
        self._manager = manager
        self._bot = bot
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to disable…",
            options=options,
            custom_id="cog:disable:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        info = await self._manager.get_cog_info(cog_name)
        if not info:
            await interaction.response.edit_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog_name}` not found."),
            )
            return

        if not info.enabled:
            await interaction.response.edit_message(
                view=make_info_card(
                    "ℹ️ Already Disabled", f"Cog `{cog_name}` is already disabled."
                ),
            )
            return

        try:
            if info.loaded:
                unloaded = await self._manager.unload_cog(self._bot, cog_name)
                if not unloaded:
                    await interaction.response.edit_message(
                        view=make_error_card(
                            "❌ Failed to Unload",
                            f"Cog `{cog_name}` could not be unloaded. It has NOT been disabled. Check logs.",
                        ),
                    )
                    return
            await self._manager.set_enabled(cog_name, False)
            await interaction.response.edit_message(
                view=make_success_card(
                    "✅ Disabled",
                    f"Cog `{cog_name}` has been disabled."
                    + ("" if not info.loaded else " Unloaded."),
                ),
            )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", str(exc)),
            )


class _DisableSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager, bot: commands.Bot):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ❌ Disable Cog\nSelect a cog to disable."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_DisableSelect(cogs, manager, bot)),
                accent_color=discord.Color.blurple(),
            )
        )


class _ReloadSelect(ui.Select):
    def __init__(self, loaded_cogs: list[dict], manager: CogManager):
        self._manager = manager
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(loaded_cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to reload…",
            options=options,
            custom_id="cog:reload:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        try:
            await self._manager.reload_cog(interaction.client, cog_name)
            await interaction.response.edit_message(
                view=make_success_card("🔄 Reloaded", f"Cog `{cog_name}` reloaded."),
            )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", f"```\n{exc}\n```"),
            )


class _ReloadSelectView(ui.LayoutView):
    def __init__(self, loaded_cogs: list[dict], manager: CogManager):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## 🔁 Reload Cog\nSelect a loaded cog to reload from disk."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_ReloadSelect(loaded_cogs, manager)),
                accent_color=discord.Color.blurple(),
            )
        )


class _GuildEnableSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        self._manager = manager
        self._guild_id = guild_id
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to enable in this server…",
            options=options,
            custom_id="cog:guild_enable:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        try:
            await self._manager.set_cog_enabled_in_guild(cog_name, self._guild_id, True)
            await interaction.response.edit_message(
                view=make_success_card(
                    "✅ Enabled", f"Cog `{cog_name}` is now enabled for this server."
                ),
            )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", str(exc)),
            )


class _GuildEnableSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ✅ Guild Enable Cog\nSelect a cog to enable for this server."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_GuildEnableSelect(cogs, manager, guild_id)),
                accent_color=discord.Color.blurple(),
            )
        )


class _GuildDisableSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        self._manager = manager
        self._guild_id = guild_id
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to disable in this server…",
            options=options,
            custom_id="cog:guild_disable:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        try:
            await self._manager.set_cog_enabled_in_guild(cog_name, self._guild_id, False)
            await interaction.response.edit_message(
                view=make_success_card(
                    "✅ Disabled", f"Cog `{cog_name}` is now disabled for this server."
                ),
            )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", str(exc)),
            )


class _GuildDisableSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ❌ Guild Disable Cog\nSelect a cog to disable for this server."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_GuildDisableSelect(cogs, manager, guild_id)),
                accent_color=discord.Color.blurple(),
            )
        )


class _GuildStatusSelect(ui.Select):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        self._manager = manager
        self._guild_id = guild_id
        options = [
            discord.SelectOption(
                label=c["name"],
                description=f"Module: {c.get('module', '?')}",
                value=c["name"],
            )
            for c in sorted(cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a cog to check status…",
            options=options,
            custom_id="cog:guild_status:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        info = await self._manager.get_cog_info(cog_name)
        if not info:
            await interaction.response.edit_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog_name}` not found."),
            )
            return

        global_enabled = await self._manager.is_enabled(cog_name)
        guild_enabled = await self._manager.is_cog_enabled_in_guild(cog_name, self._guild_id)

        status_lines = [
            f"Global: {'✅ Enabled' if global_enabled else '⛔ Disabled'}",
            f"Server: {'✅ Enabled' if guild_enabled else '⛔ Disabled'}",
        ]
        await interaction.response.edit_message(
            view=make_info_card(f"Cog Status: {cog_name}", "\n".join(status_lines)),
        )


class _GuildStatusSelectView(ui.LayoutView):
    def __init__(self, cogs: list[dict], manager: CogManager, guild_id: int):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## ℹ️ Guild Cog Status\nSelect a cog to check its status."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_GuildStatusSelect(cogs, manager, guild_id)),
                accent_color=discord.Color.blurple(),
            )
        )


async def setup(bot):
    await bot.add_cog(CogManagerCog(bot))
