from .cog import CogManagerCog


async def setup(bot) -> None:
    await bot.add_cog(CogManagerCog(bot))
