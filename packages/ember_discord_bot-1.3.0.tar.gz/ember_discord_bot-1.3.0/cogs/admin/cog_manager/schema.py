from typing import TypedDict


class CogManagerGuildConfig(TypedDict, total=False):
    """Guild-level cog_manager configuration."""

    enabled: bool
