from .cog import PermissionsManagerCog


async def setup(bot) -> None:
    await bot.add_cog(PermissionsManagerCog(bot))
