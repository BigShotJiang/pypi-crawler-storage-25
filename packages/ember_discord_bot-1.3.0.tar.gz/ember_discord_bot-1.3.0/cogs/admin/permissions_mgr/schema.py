from typing import TypedDict


class PermissionsMgrGuildConfig(TypedDict, total=False):
    """Guild-level permissions_mgr configuration."""

    enabled: bool
