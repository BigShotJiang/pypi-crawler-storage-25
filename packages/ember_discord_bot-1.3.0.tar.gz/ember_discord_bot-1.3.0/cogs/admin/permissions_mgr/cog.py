import discord
from discord import app_commands

from core.cog import EmberCog
from core.permissions import requires
from core.permissions_engine import PermissionLevel, PermissionRegistry, PermState
from utils.cards import make_error_card, make_info_card, make_list_card, make_success_card
from utils.feature_registry import feature

from .schema import PermissionsMgrGuildConfig


def _model_key(
    target_user: discord.Member | None,
    target_channel: discord.TextChannel | None,
    interaction: discord.Interaction,
) -> str:
    """Derive the model key from whichever target is provided."""
    if target_user is not None:
        return f"user:{target_user.id}"
    if target_channel is not None:
        return f"channel:{target_channel.id}"
    return f"guild:{interaction.guild_id}"


def _state_label(state: PermState) -> str:
    return {
        PermState.ACTIVE_ALLOW: "✅ ALLOW",
        PermState.ACTIVE_DENY: "❌ DENY",
        PermState.NORMAL: "⬜ NORMAL",
    }.get(state, state.name)


@feature(
    display_name="Permissions Manager",
    description="Override command permissions per guild, channel, or user.",
    emoji="🔐",
    fields=[],
)
class PermissionsManagerCog(EmberCog):
    """Slash commands for managing per-guild permission overrides."""

    def __init__(self, bot):
        super().__init__(bot)
        self.db.register_schema("guild", PermissionsMgrGuildConfig)

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        await super().cog_unload()

    perms_group = app_commands.Group(
        name="permissions",
        description="Manage command permission overrides for this server.",
        guild_only=True,
    )

    async def _registry(self) -> PermissionRegistry:
        return await PermissionRegistry.get(self.bot)

    @perms_group.command(
        name="allow", description="Allow a command for a user, channel, or the whole server."
    )
    @app_commands.describe(
        command="Command name (e.g. 'moderation kick')",
        target_user="Allow for a specific member (leave blank for server-wide)",
        target_channel="Allow in a specific channel (leave blank for server-wide)",
    )
    @requires(PermissionLevel.ADMIN)
    async def perms_allow(
        self,
        interaction: discord.Interaction,
        command: str,
        target_user: discord.Member | None = None,
        target_channel: discord.TextChannel | None = None,
    ) -> None:
        model = _model_key(target_user, target_channel, interaction)
        reg = await self._registry()
        await reg.set_rule(command, model, PermState.ACTIVE_ALLOW, guild_id=interaction.guild_id)
        await interaction.response.send_message(
            view=make_success_card("Permission set", f"**{command}** → ✅ ALLOW for `{model}`."),
            ephemeral=True,
        )

    @perms_group.command(
        name="deny", description="Deny a command for a user, channel, or the whole server."
    )
    @app_commands.describe(
        command="Command name",
        target_user="Deny for a specific member",
        target_channel="Deny in a specific channel",
    )
    @requires(PermissionLevel.ADMIN)
    async def perms_deny(
        self,
        interaction: discord.Interaction,
        command: str,
        target_user: discord.Member | None = None,
        target_channel: discord.TextChannel | None = None,
    ) -> None:
        model = _model_key(target_user, target_channel, interaction)
        reg = await self._registry()
        await reg.set_rule(command, model, PermState.ACTIVE_DENY, guild_id=interaction.guild_id)
        await interaction.response.send_message(
            view=make_success_card("Permission set", f"**{command}** → ❌ DENY for `{model}`."),
            ephemeral=True,
        )

    @perms_group.command(name="reset", description="Remove a permission override.")
    @app_commands.describe(
        command="Command name",
        target_user="Remove override for a specific member",
        target_channel="Remove override for a specific channel",
    )
    @requires(PermissionLevel.ADMIN)
    async def perms_reset(
        self,
        interaction: discord.Interaction,
        command: str,
        target_user: discord.Member | None = None,
        target_channel: discord.TextChannel | None = None,
    ) -> None:
        model = _model_key(target_user, target_channel, interaction)
        reg = await self._registry()
        existed = await reg.clear_rule(command, model, guild_id=interaction.guild_id)
        if existed:
            await interaction.response.send_message(
                view=make_success_card(
                    "Override removed", f"**{command}** rule for `{model}` cleared."
                ),
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                view=make_info_card(
                    "No override", f"No override existed for **{command}** / `{model}`."
                ),
                ephemeral=True,
            )

    @perms_group.command(
        name="list", description="List all active permission overrides for this server."
    )
    @requires(PermissionLevel.ADMIN)
    async def perms_list(self, interaction: discord.Interaction) -> None:
        reg = await self._registry()
        guild_id = interaction.guild_id
        lines: list[str] = []

        for cmd_path in reg.get_all_commands():
            rules = await reg.get_rules(cmd_path, guild_id)
            if not rules:
                continue
            for model, state in rules.guild_rules.get(str(guild_id), {}).items():
                if state != PermState.NORMAL:
                    lines.append(f"`{cmd_path}` — `{model}` — {_state_label(state)}")

        if not lines:
            await interaction.response.send_message(
                view=make_info_card(
                    "No overrides", "No permission overrides are set for this server."
                ),
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            view=make_list_card("Permission Overrides", lines, per_page=15),
            ephemeral=True,
        )

    @perms_group.command(
        name="info", description="Show the effective permission state for a command."
    )
    @app_commands.describe(command="Command name to inspect")
    @requires(PermissionLevel.ADMIN)
    async def perms_info(self, interaction: discord.Interaction, command: str) -> None:
        reg = await self._registry()
        rules = await reg.get_rules(command, interaction.guild_id)
        req = reg.get_requires(command)

        if req is None and (rules is None or not rules.guild_rules.get(str(interaction.guild_id))):
            await interaction.response.send_message(
                view=make_error_card(
                    "Unknown command", f"No registered command found for **{command}**."
                ),
                ephemeral=True,
            )
            return

        default_level = req.privilege_level.name if req and req.privilege_level else "NONE"
        guild_rules = rules.guild_rules.get(str(interaction.guild_id), {}) if rules else {}

        lines = [f"**Default level:** {default_level}"]
        if guild_rules:
            lines.append("**Guild overrides:**")
            for model, state in guild_rules.items():
                lines.append(f"  `{model}` → {_state_label(state)}")
        else:
            lines.append("No guild-specific overrides.")

        await interaction.response.send_message(
            view=make_info_card(f"Permissions: {command}", "\n".join(lines)),
            ephemeral=True,
        )

    @perms_group.command(
        name="reset-all", description="Wipe ALL permission overrides globally. Bot owner only."
    )
    @requires(PermissionLevel.BOT_OWNER)
    async def perms_reset_all(self, interaction: discord.Interaction) -> None:
        reg = await self._registry()
        for rules in (await reg.get_rules(p) for p in reg.get_all_commands()):
            if rules:
                rules.guild_rules.clear()
                rules.global_rules.clear()
        await reg._save_rules()
        await interaction.response.send_message(
            view=make_success_card(
                "All overrides cleared", "Every permission override has been removed globally."
            ),
            ephemeral=True,
        )


async def setup(bot) -> None:
    await bot.add_cog(PermissionsManagerCog(bot))
