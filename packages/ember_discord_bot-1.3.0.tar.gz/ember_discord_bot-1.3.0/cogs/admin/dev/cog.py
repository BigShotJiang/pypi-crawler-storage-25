import contextlib
import io
import textwrap
import time
import traceback
from typing import TYPE_CHECKING

import discord
from discord import app_commands, ui
from discord.ext import commands

from core.cog import EmberCog
from core.permissions import requires
from core.permissions_engine import PermissionLevel
from utils.cards import make_error_card, make_info_card, make_success_card
from utils.feature_registry import feature
from utils.formatting import sanitize_output

if TYPE_CHECKING:
    from core._cog_manager import CogManager

_TRUNC = 1900  # leave room for code fences


def _fmt(output: str) -> str:
    output = sanitize_output(output)
    if len(output) > _TRUNC:
        output = output[:_TRUNC] + "\n… (truncated)"
    return f"```\n{output}\n```"


class _ReplSession:
    """Persistent REPL state for a single channel."""

    def __init__(self):
        self.env: dict = {}
        self.last_activity: float = time.monotonic()

    def touch(self) -> None:
        self.last_activity = time.monotonic()

    def expired(self, timeout: float = 60.0) -> bool:
        return time.monotonic() - self.last_activity > timeout


@feature(
    display_name="Developer Tools",
    description="Bot owner-only: eval, repl, reload, diagnose.",
    emoji="⚙️",
    fields=[],
)
class DevCog(EmberCog):
    """Developer commands — bot owner only."""

    dev = app_commands.Group(name="dev", description="Developer tools")

    def __init__(self, bot: commands.Bot):
        super().__init__(bot)
        self._repl_sessions: dict[int, _ReplSession] = {}

    async def cog_load(self) -> None:
        await super().cog_load()

    async def cog_unload(self) -> None:
        await super().cog_unload()

    async def _exec(self, code: str, env: dict) -> str:
        """Execute *code* in *env*, return combined stdout + return value."""
        stdout = io.StringIO()
        wrapped = f"async def _eval_fn():\n{textwrap.indent(code, '    ')}"
        try:
            exec(compile(wrapped, "<eval>", "exec"), env)  # noqa: S102
            with contextlib.redirect_stdout(stdout):
                result = await env["_eval_fn"]()
        except Exception:
            return sanitize_output(traceback.format_exc())
        out = stdout.getvalue()
        if result is not None:
            out += repr(result)
        return sanitize_output(out or "(no output)")

    @dev.command(name="eval", description="Execute Python in an async context.")
    @app_commands.describe(code="Python code to execute")
    @requires(PermissionLevel.BOT_OWNER)
    async def dev_eval(self, interaction: discord.Interaction, code: str) -> None:
        await interaction.response.defer(ephemeral=True)
        env = {
            "bot": self.bot,
            "interaction": interaction,
            "guild": interaction.guild,
            "channel": interaction.channel,
            "author": interaction.user,
            "__import__": __import__,
        }
        output = await self._exec(code, env)
        await interaction.followup.send(
            view=make_info_card("Eval", _fmt(output)),
            ephemeral=True,
        )

    @dev.command(name="repl", description="Start a persistent REPL session in this channel.")
    @requires(PermissionLevel.BOT_OWNER)
    async def dev_repl(self, interaction: discord.Interaction) -> None:
        channel_id = interaction.channel_id
        if channel_id in self._repl_sessions and not self._repl_sessions[channel_id].expired():
            await interaction.response.send_message(
                view=make_info_card("REPL", "Session already active. Send code as messages."),
                ephemeral=True,
            )
            return
        session = _ReplSession()
        session.env.update(
            {
                "bot": self.bot,
                "guild": interaction.guild,
                "channel": interaction.channel,
                "author": interaction.user,
                "__import__": __import__,
            }
        )
        self._repl_sessions[channel_id] = session
        await interaction.response.send_message(
            view=make_success_card(
                "REPL started", "Send Python code as messages. Times out after 60s of inactivity."
            ),
            ephemeral=True,
        )

    @EmberCog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or message.channel.id not in self._repl_sessions:
            return
        if not await self.bot.is_owner(message.author):
            return
        session = self._repl_sessions[message.channel.id]
        if session.expired():
            del self._repl_sessions[message.channel.id]
            return
        session.touch()
        session.env["message"] = message
        code = message.content.strip().strip("`")
        output = await self._exec(code, session.env)
        await message.channel.send(_fmt(output))

    @dev.command(name="reload", description="Force-reload a cog by qualified name.")
    @app_commands.describe(module_path="Dotted module path, e.g. cogs.mod.moderation.cog")
    @requires(PermissionLevel.BOT_OWNER)
    async def dev_reload(
        self, interaction: discord.Interaction, module_path: str | None = None
    ) -> None:
        if module_path:
            try:
                await self.bot.reload_extension(module_path)
                await interaction.response.send_message(
                    view=make_success_card("Reload successful", f"`{module_path}` reloaded."),
                    ephemeral=True,
                )
            except Exception as exc:
                await interaction.response.send_message(
                    view=make_error_card("Reload failed", str(exc)),
                    ephemeral=True,
                )
            return

        from core._cog_manager import get_manager

        manager = get_manager()
        await manager.discover_cogs()
        loaded = await manager.list_cogs()
        loaded = [c for c in loaded if c["loaded"]]
        if not loaded:
            await interaction.response.send_message(
                view=make_info_card("🔁 Reload", "No cogs are currently loaded."),
                ephemeral=True,
            )
            return

        view = _DevReloadSelectView(loaded, manager, self.bot)
        await interaction.response.send_message(
            view=view,
            ephemeral=True,
        )

    @dev.command(name="sudo", description="Run a slash command as another member.")
    @app_commands.describe(
        member="Member to impersonate",
        command="Slash command name to invoke",
    )
    @requires(PermissionLevel.BOT_OWNER)
    async def dev_sudo(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        command: str,
    ) -> None:
        cmd = self.bot.tree.get_command(command)
        if cmd is None:
            await interaction.response.send_message(
                view=make_error_card("Unknown command", f"No slash command `{command}` found."),
                ephemeral=True,
            )
            return
        await interaction.response.send_message(
            view=make_info_card(
                "Sudo",
                f"Invoking `/{command}` as {member.mention}.\n*(Full sudo requires monkey-patching the interaction — use with care.)*",
            ),
            ephemeral=True,
        )


class _DevReloadSelect(ui.Select):
    def __init__(self, loaded_cogs: list[dict], manager: "CogManager", bot: commands.Bot):
        self._manager = manager
        self._bot = bot
        options = [
            discord.SelectOption(
                label=c["name"],
                description=c.get("module", ""),
                value=c["name"],
            )
            for c in sorted(loaded_cogs, key=lambda x: x["name"])
        ]
        super().__init__(
            placeholder="Select a loaded cog to reload…",
            options=options,
            custom_id="dev:reload:select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        cog_name = self.values[0]
        info = await self._manager.get_cog_info(cog_name)
        if not info:
            await interaction.response.edit_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog_name}` not found."),
            )
            return
        try:
            await self._bot.reload_extension(info.qualname)
            await interaction.response.edit_message(
                view=make_success_card("🔄 Reloaded", f"`{info.qualname}` reloaded."),
            )
        except Exception as exc:
            await interaction.response.edit_message(
                view=make_error_card("❌ Failed", f"```\n{exc}\n```"),
            )


class _DevReloadSelectView(ui.LayoutView):
    def __init__(self, loaded_cogs: list[dict], manager: CogManager, bot: commands.Bot):
        super().__init__(timeout=180)
        self.add_item(
            ui.Container(
                ui.TextDisplay("## 🔁 Reload Cog\nSelect a loaded cog to reload."),
                ui.Separator(spacing=discord.SeparatorSpacing.small),
                ui.ActionRow(_DevReloadSelect(loaded_cogs, manager, bot)),
                accent_color=discord.Color.blurple(),
            )
        )


async def setup(bot) -> None:
    await bot.add_cog(DevCog(bot))
