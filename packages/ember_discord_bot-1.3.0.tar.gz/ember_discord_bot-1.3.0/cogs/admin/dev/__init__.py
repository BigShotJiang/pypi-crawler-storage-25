from .cog import DevCog


async def setup(bot) -> None:
    await bot.add_cog(DevCog(bot))
