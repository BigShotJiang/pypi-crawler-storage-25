"""Unified test suite for all storage drivers.

Run this test suite against each driver to ensure identical behavior across:
- SQLite (file-based)
- Postgres (SQL database)
- JSON (file-based)
- Mongo (document database)

All drivers must pass the same tests without modification.
"""

from __future__ import annotations

import pytest
from core._drivers import ConfigScope, BaseDriver


class TestDriverUnified:
    """Base test class for all drivers. Run once per driver implementation."""

    # Subclasses must define this fixture
    @pytest.fixture
    async def driver(self) -> BaseDriver:
        """Provide a clean driver instance for each test."""
        raise NotImplementedError("Subclass must provide driver fixture")

    # ── Config scope tests ────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_set_get_single_value(self, driver):
        """Test setting and retrieving a single value."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key", "value")
        result = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key")
        assert result == "value"

    @pytest.mark.asyncio
    async def test_get_nonexistent_returns_none(self, driver):
        """Test that getting a nonexistent key returns None."""
        result = await driver.get("test_cog", 123, ConfigScope.GUILD, "999", "", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_multiple_keys_in_scope(self, driver):
        """Test setting multiple keys in a single scope."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key1", "val1")
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key2", "val2")

        result1 = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key1")
        result2 = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key2")

        assert result1 == "val1"
        assert result2 == "val2"

    @pytest.mark.asyncio
    async def test_type_preservation(self, driver):
        """Test that various Python types are preserved through set/get."""
        test_cases = [
            ("int_key", 42),
            ("float_key", 3.14),
            ("bool_key", True),
            ("list_key", [1, 2, 3]),
            ("dict_key", {"nested": "value"}),
            ("none_key", None),
        ]

        for key, value in test_cases:
            await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", key, value)
            result = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", key)
            assert result == value, f"Type mismatch for {key}: expected {value!r}, got {result!r}"

    @pytest.mark.asyncio
    async def test_get_all_scope(self, driver):
        """Test retrieving all keys in a scope."""
        await driver.set_all(
            "test_cog",
            123,
            ConfigScope.GUILD,
            "456",
            "",
            {"key1": "val1", "key2": "val2", "key3": "val3"},
        )

        result = await driver.get_all("test_cog", 123, ConfigScope.GUILD, "456", "")
        assert result == {"key1": "val1", "key2": "val2", "key3": "val3"}

    @pytest.mark.asyncio
    async def test_delete_single_key(self, driver):
        """Test deleting a single key."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key", "value")
        await driver.delete("test_cog", 123, ConfigScope.GUILD, "456", "", "key")

        result = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key")
        assert result is None

    @pytest.mark.asyncio
    async def test_delete_scope(self, driver):
        """Test clearing an entire scope."""
        await driver.set_all(
            "test_cog",
            123,
            ConfigScope.GUILD,
            "456",
            "",
            {"key1": "val1", "key2": "val2"},
        )

        await driver.clear_scope("test_cog", 123, ConfigScope.GUILD, "456", "")

        result = await driver.get_all("test_cog", 123, ConfigScope.GUILD, "456", "")
        assert result == {}

    @pytest.mark.asyncio
    async def test_different_scopes_isolated(self, driver):
        """Test that different scopes don't interfere with each other."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key", "guild_value")
        await driver.set("test_cog", 123, ConfigScope.USER, "789", "", "key", "user_value")

        guild_result = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key")
        user_result = await driver.get("test_cog", 123, ConfigScope.USER, "789", "", "key")

        assert guild_result == "guild_value"
        assert user_result == "user_value"

    @pytest.mark.asyncio
    async def test_different_scope_ids_isolated(self, driver):
        """Test that different scope IDs don't interfere with each other."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key", "value1")
        await driver.set("test_cog", 123, ConfigScope.GUILD, "789", "", "key", "value2")

        result1 = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key")
        result2 = await driver.get("test_cog", 123, ConfigScope.GUILD, "789", "", "key")

        assert result1 == "value1"
        assert result2 == "value2"

    @pytest.mark.asyncio
    async def test_get_all_scope_ids(self, driver):
        """Test retrieving all scope IDs that have data."""
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key", "val1")
        await driver.set("test_cog", 123, ConfigScope.GUILD, "789", "", "key", "val2")
        await driver.set("test_cog", 123, ConfigScope.GUILD, "111", "", "key", "val3")

        result = await driver.get_all_scope_ids("test_cog", 123, ConfigScope.GUILD)
        ids = sorted([id1 for id1, id2 in result])

        assert ids == ["111", "456", "789"]

    @pytest.mark.asyncio
    async def test_set_all_atomic(self, driver):
        """Test that set_all is atomic (all or nothing)."""
        data = {"key1": "val1", "key2": "val2", "key3": "val3"}
        await driver.set_all("test_cog", 123, ConfigScope.GUILD, "456", "", data)

        result = await driver.get_all("test_cog", 123, ConfigScope.GUILD, "456", "")
        assert result == data

    @pytest.mark.asyncio
    async def test_member_scope_with_secondary_id(self, driver):
        """Test member scope which uses both primary and secondary IDs."""
        await driver.set(
            "test_cog", 123, ConfigScope.MEMBER, "456", "789", "key", "member_value"
        )

        result = await driver.get("test_cog", 123, ConfigScope.MEMBER, "456", "789", "key")
        assert result == "member_value"

    @pytest.mark.asyncio
    async def test_clear_cog_deletes_all(self, driver):
        """Test that clear_cog removes all data for a cog."""
        # Add data across multiple scopes
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key1", "val1")
        await driver.set("test_cog", 123, ConfigScope.USER, "789", "", "key2", "val2")
        await driver.set("test_cog", 123, ConfigScope.MEMBER, "111", "222", "key3", "val3")

        # Clear entire cog
        await driver.clear_cog("test_cog", 123)

        # Verify all gone
        result1 = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key1")
        result2 = await driver.get("test_cog", 123, ConfigScope.USER, "789", "", "key2")
        result3 = await driver.get("test_cog", 123, ConfigScope.MEMBER, "111", "222", "key3")

        assert result1 is None
        assert result2 is None
        assert result3 is None

    # ── Export/Import tests ───────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_export_import_roundtrip(self, driver):
        """Test that export followed by import preserves data."""
        # Add data
        await driver.set("test_cog", 123, ConfigScope.GUILD, "456", "", "key1", "val1")
        await driver.set("test_cog", 123, ConfigScope.USER, "789", "", "key2", "val2")

        # Export
        exported = await driver.export()

        # Clear
        await driver.clear_cog("test_cog", 123)

        # Import
        await driver.import_data(exported)

        # Verify
        result1 = await driver.get("test_cog", 123, ConfigScope.GUILD, "456", "", "key1")
        result2 = await driver.get("test_cog", 123, ConfigScope.USER, "789", "", "key2")

        assert result1 == "val1"
        assert result2 == "val2"

    # ── SQL tests (SQL drivers only) ───────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_execute_sql_write(self, driver):
        """Test raw SQL write (SQL drivers only)."""
        try:
            # Drop table if it exists, then create (handles re-runs)
            await driver.execute_sql("test_cog", "DROP TABLE IF EXISTS test", ())
            await driver.execute_sql("test_cog", "CREATE TABLE test (id INTEGER, name TEXT)", ())
            # If we get here, driver supports SQL
            assert True
        except NotImplementedError:
            # Non-SQL driver, skip
            pytest.skip(f"{type(driver).__name__} does not support SQL")

    # ── Table helpers tests ───────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_store_record(self, driver):
        """Test storing a record (driver-agnostic table helper)."""
        record = {"id": 1, "name": "test", "value": 42}
        try:
            # Try to store a record
            await driver.store_record("test_cog", 123, "test_table", record)
            # If successful, the driver supports this
            assert True
        except (NotImplementedError, AttributeError):
            # Driver doesn't support store_record, skip
            pytest.skip(f"{type(driver).__name__} does not support store_record")
        except Exception:
            # Other errors (like table not found) are OK - just means driver is working
            # but table wasn't pre-created
            assert True

    # ── Consistency tests ─────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_global_scope(self, driver):
        """Test global scope (single instance)."""
        await driver.set("test_cog", 123, ConfigScope.GLOBAL, "", "", "key", "global_value")
        result = await driver.get("test_cog", 123, ConfigScope.GLOBAL, "", "", "key")
        assert result == "global_value"


# ═════════════════════════════════════════════════════════════════════════════
# Driver-specific test classes
# ═════════════════════════════════════════════════════════════════════════════


class TestSQLiteDriver(TestDriverUnified):
    """Test SQLiteDriver against the unified test suite."""

    @pytest.fixture
    async def driver(self):
        """Provide a clean SQLite driver instance."""
        from pathlib import Path
        from core._drivers.sqlite import SQLiteDriver
        import tempfile
        import shutil

        tmpdir = tempfile.mkdtemp()
        db_path = Path(tmpdir) / "test.db"
        driver = SQLiteDriver(db_path=db_path)
        await driver.initialize()
        yield driver
        shutil.rmtree(tmpdir, ignore_errors=True)


class TestJSONDriver(TestDriverUnified):
    """Test JsonDriver against the unified test suite."""

    @pytest.fixture
    async def driver(self):
        """Provide a clean JSON driver instance."""
        from pathlib import Path
        from core._drivers.json_driver import JsonDriver
        import tempfile
        import shutil

        tmpdir = tempfile.mkdtemp()
        data_dir = Path(tmpdir)
        driver = JsonDriver(data_dir=data_dir)
        await driver.initialize()
        yield driver
        shutil.rmtree(tmpdir, ignore_errors=True)
