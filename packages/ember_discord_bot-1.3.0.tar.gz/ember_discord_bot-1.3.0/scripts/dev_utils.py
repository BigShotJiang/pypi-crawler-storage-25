#!/usr/bin/env python3
"""
Developer utility scripts for Ember framework.

This script provides common development tasks like:
- Checking TODO/FIXME comments
- Validating cog structure
- Running linters
- Testing utilities
"""

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path


def check_todos() -> list[str]:
    """Check for TODO/FIXME comments in the codebase."""
    todo_patterns = [
        r"TODO\w*:?",
        r"FIXME\w*:?",
        r"XXX\w*:?",
        r"HACK\w*:?",
        r"BUG\w*:?",
    ]

    todo_regex = "|".join(todo_patterns)
    found_issues = []

    # Walk through all Python files
    for root, dirs, files in os.walk("."):
        # Skip virtual environments and cache directories
        dirs[:] = [
            d for d in dirs if not d.startswith(".") and d not in ["venv", "__pycache__", ".git"]
        ]

        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, encoding="utf-8") as f:
                        lines = f.readlines()
                        for line_num, line in enumerate(lines, 1):
                            if re.search(todo_regex, line, re.IGNORECASE):
                                found_issues.append(f"{file_path}:{line_num}: {line.strip()}")
                except Exception:
                    continue

    return found_issues


def validate_cog_structure() -> list[str]:
    """Validate cog structure and required components."""
    issues = []
    cog_dir = Path("cogs")

    if not cog_dir.exists():
        return ["cogs/ directory not found"]

    for cog_path in cog_dir.iterdir():
        if cog_path.is_dir() and not cog_path.name.startswith("."):
            # Check for required files
            required_files = ["__init__.py", "cog.py"]
            for req_file in required_files:
                if not (cog_path / req_file).exists():
                    issues.append(f"Missing {req_file} in {cog_path.name}")

            # Check for setup function in __init__.py
            init_file = cog_path / "__init__.py"
            if init_file.exists():
                try:
                    with open(init_file) as f:
                        content = f.read()
                        if "async def setup(" not in content and "def setup(" not in content:
                            issues.append(f"No setup function found in {cog_path.name}/__init__.py")
                except Exception:
                    issues.append(f"Could not read {cog_path.name}/__init__.py")

    return issues


def run_linters() -> tuple[int, list[str]]:
    """Run code quality tools and return exit code and output."""
    tools = [
        ("black", [sys.executable, "-m", "black", "--check", "."]),
        ("ruff", [sys.executable, "-m", "ruff", "check", "."]),
        ("mypy", [sys.executable, "-m", "mypy", "."]),
    ]

    results = []
    exit_code = 0

    for tool_name, cmd in tools:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if result.returncode != 0:
                exit_code = result.returncode
                results.append(f"{tool_name} found issues:")
                results.append(result.stdout)
                if result.stderr:
                    results.append(result.stderr)
        except subprocess.TimeoutExpired:
            results.append(f"{tool_name} timed out")
            exit_code = 1
        except Exception as e:
            results.append(f"Error running {tool_name}: {e}")
            exit_code = 1

    return exit_code, results


def run_tests() -> tuple[int, list[str]]:
    """Run pytest and return exit code and output."""
    try:
        result = subprocess.run(["pytest", "-v"], capture_output=True, text=True, timeout=300)
        output = [result.stdout]
        if result.stderr:
            output.append(result.stderr)
        return result.returncode, output
    except subprocess.TimeoutExpired:
        return 1, ["Tests timed out"]
    except Exception as e:
        return 1, [f"Error running tests: {e}"]


def main():
    parser = argparse.ArgumentParser(description="Ember Development Utilities")
    parser.add_argument("--check-todos", action="store_true", help="Check for TODO/FIXME comments")
    parser.add_argument("--validate-cogs", action="store_true", help="Validate cog structure")
    parser.add_argument("--lint", action="store_true", help="Run code quality tools")
    parser.add_argument("--test", action="store_true", help="Run tests")
    parser.add_argument("--all", action="store_true", help="Run all checks")

    args = parser.parse_args()

    if args.all or args.check_todos:
        print("🔍 Checking TODO/FIXME comments...")
        todos = check_todos()
        if todos:
            print("Found TODO/FIXME comments:")
            for todo in todos:
                print(f"  {todo}")
        else:
            print("✅ No TODO/FIXME comments found")
        print()

    if args.all or args.validate_cogs:
        print("🏗️  Validating cog structure...")
        issues = validate_cog_structure()
        if issues:
            print("Found cog structure issues:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ All cogs have valid structure")
        print()

    if args.all or args.lint:
        print("🧹 Running code quality tools...")
        exit_code, results = run_linters()
        if results:
            for result in results:
                print(result)
        if exit_code == 0:
            print("✅ All linters passed")
        print()

    if args.all or args.test:
        print("🧪 Running tests...")
        exit_code, results = run_tests()
        if results:
            for result in results:
                print(result)
        if exit_code == 0:
            print("✅ All tests passed")
        print()


if __name__ == "__main__":
    main()
