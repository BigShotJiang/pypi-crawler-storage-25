#!/usr/bin/env python3
"""Extract translatable strings from cog source files.

Finds all ``_("...")`` calls in cog source files and writes/updates
``locales/en-US/<cog_name>.json`` identity maps.

No manual gettext pipeline needed. Just edit the JSON, commit, done.

Usage::

    python scripts/extract_strings.py
"""

import ast
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
COGS_DIR = PROJECT_ROOT / "cogs"
LOCALES_DIR = PROJECT_ROOT / "locales" / "en-US"


def extract_strings_from_file(path: Path) -> list[str]:
    """Extract all _("...") string literals from a Python source file."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        print(f"  SKIP {path}: {exc}", file=sys.stderr)
        return []

    strings: list[str] = []
    for node in ast.walk(tree):
        # Match _("string") or _('string')
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "_"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Constant)
            and isinstance(node.args[0].value, str)
        ):
            strings.append(node.args[0].value)
    return strings


def process_cog(cog_dir: Path) -> None:
    """Extract strings from all .py files in a cog directory."""
    cog_name = cog_dir.name
    strings: set[str] = set()

    for py_file in cog_dir.rglob("*.py"):
        found = extract_strings_from_file(py_file)
        strings.update(found)

    if not strings:
        return

    locale_file = LOCALES_DIR / f"{cog_name}.json"
    existing: dict[str, str] = {}
    if locale_file.exists():
        try:
            existing = json.loads(locale_file.read_text(encoding="utf-8"))
        except Exception:
            pass

    # Merge: keep existing translations, add new keys as identity
    merged = {s: existing.get(s, s) for s in sorted(strings)}
    # Also keep any keys in existing that are no longer in source (don't delete translations)
    for k, v in existing.items():
        if k not in merged:
            merged[k] = v

    locale_file.write_text(
        json.dumps(merged, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    try:
        display = locale_file.relative_to(PROJECT_ROOT)
    except ValueError:
        display = locale_file
    print(f"  {cog_name}: {len(strings)} string(s) → {display}")


def main() -> None:
    LOCALES_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Extracting strings from {COGS_DIR}...")
    for cog_dir in sorted(COGS_DIR.iterdir()):
        if cog_dir.is_dir() and not cog_dir.name.startswith("_"):
            process_cog(cog_dir)
    print("Done.")


if __name__ == "__main__":
    main()
