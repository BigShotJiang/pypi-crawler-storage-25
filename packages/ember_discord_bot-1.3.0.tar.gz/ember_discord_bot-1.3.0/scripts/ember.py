#!/usr/bin/env python3
"""
Ember CLI Tool - Development helper for the Ember Discord bot framework.

This tool provides command-line utilities for:
- Creating new cogs with proper structure
- Running tests and linting
- Managing database migrations
- Generating documentation
- Plugin management
"""

import argparse
import importlib.metadata
import secrets
import subprocess
import sys
from pathlib import Path
from typing import Any


def run_command(command: str, cwd: Path | None = None) -> int:
    """Run a shell command and return exit code."""
    print(f"Running: {command}")
    result = subprocess.run(command, shell=True, cwd=cwd)
    return result.returncode


def create_cog_structure(cog_name: str, use_package: bool = False):
    """Create a new cog with proper directory structure."""
    cogs_dir = Path("cogs")
    cog_dir = cogs_dir / cog_name

    if cog_dir.exists():
        print(f"Error: Cog '{cog_name}' already exists!")
        return 1

    print(f"Creating new cog: {cog_name}")

    if use_package:
        # Create package structure
        cog_dir.mkdir(parents=True, exist_ok=True)

        # __init__.py
        init_content = f"""from .cog import {cog_name.capitalize()}Cog

async def setup(bot):
    await bot.add_cog({cog_name.capitalize()}Cog(bot))
"""
        (cog_dir / "__init__.py").write_text(init_content)

        # cog.py
        cog_content = f'''"""{cog_name} cog for Ember Discord bot."""

import discord
from discord import app_commands
from discord.ext import commands
from core.cog import EmberCog


class {cog_name.capitalize()}Cog(EmberCog):
    """{cog_name} functionality."""

    group = app_commands.Group(
        name="{cog_name}",
        description="{cog_name} commands",
    )

    async def cog_load(self) -> None:
        await super().cog_load()

    @group.command(name="cmd", description="Example command")
    async def example(self, interaction: discord.Interaction) -> None:
        await self.send_success(interaction, "Hello from {cog_name}!")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog({cog_name.capitalize()}Cog(bot))
'''
        (cog_dir / "cog.py").write_text(cog_content)

        # database.py
        database_content = f'''"""Database operations for {cog_name} cog.

Subclass DatabaseManager for SQL-heavy cogs that need complex queries.
For simple key-value config, use self.db (inherited from EmberCog) instead.
"""

from core.database import DatabaseManager


class {cog_name.capitalize()}DB(DatabaseManager):

    def __init__(self) -> None:
        super().__init__("{cog_name}")

    async def initialize_tables(self) -> None:
        self._store.register_table("""
            CREATE TABLE IF NOT EXISTS {cog_name}_data (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id  INTEGER NOT NULL,
                data      TEXT,
                created_at TEXT DEFAULT (datetime(\'now\'))
            )
        """)
        await self._store.initialize()
'''
        (cog_dir / "database.py").write_text(database_content)

    else:
        # Single file cog
        cog_content = f'''"""{cog_name} cog for Ember Discord bot."""

import discord
from discord import app_commands
from discord.ext import commands
from core.cog import EmberCog


class {cog_name.capitalize()}Cog(EmberCog):
    """{cog_name} functionality."""

    group = app_commands.Group(
        name="{cog_name}",
        description="{cog_name} commands",
    )

    @group.command(name="cmd", description="Example command")
    async def example(self, interaction: discord.Interaction) -> None:
        await self.send_success(interaction, "Hello from {cog_name}!")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog({cog_name.capitalize()}Cog(bot))
'''
        cog_dir.with_suffix(".py").write_text(cog_content)

    print(f"Created cog: {cog_name}")
    return 0


def run_tests(test_filter: str | None = None):
    """Run the test suite."""
    command = "python -m pytest"
    if test_filter:
        command += f" -k {test_filter}"
    command += " -v"
    return run_command(command)


def run_lint():
    """Run code quality checks."""
    commands = ["black --check .", "ruff check .", "mypy ."]

    for command in commands:
        if run_command(command) != 0:
            print(f"Linting failed on: {command}")
            return 1

    print("All linting checks passed!")
    return 0


def run_format():
    """Format code with Black."""
    return run_command("black .")


def read_env_file() -> dict[str, str]:
    """Read existing .env file into a dict."""
    env_file = Path(".env")
    if not env_file.exists():
        return {}
    lines = env_file.read_text().splitlines()
    env: dict[str, str] = {}
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            env[key.strip()] = value.strip().strip('"').strip("'")
    return env


def setup_command():
    """Interactive setup to create/update .env file."""
    print("=== Ember Setup Wizard ===\n")
    env = read_env_file()

    # Start with all existing env vars to preserve unknown/optional ones
    new_env: dict[str, str] = dict(env)

    # Define prompts: (var_name, description, is_required, conditional_var, conditional_value)
    prompts = [
        ("BOT_TOKEN", "Discord Bot Token", True, None, None),
        ("APP_ID", "Discord Application ID", False, None, None),
        ("GUILD_ID", "Test Guild ID (optional)", False, None, None),
        ("EMBER_DB_BACKEND", "Database backend (sqlite, postgres, json, mongo)", False, None, None),
        (
            "EMBER_POSTGRES_DSN",
            "Postgres DSN (if using postgres)",
            False,
            "EMBER_DB_BACKEND",
            "postgres",
        ),
        (
            "EMBER_MONGO_URI",
            "MongoDB connection URI (if using mongo)",
            False,
            "EMBER_DB_BACKEND",
            "mongo",
        ),
        ("OWNER_ID", "Bot Owner Discord ID", False, None, None),
        ("EMBER_RPC_ENABLED", "Enable RPC? (y/n)", False, None, None),
    ]

    for var_name, description, required, cond_var, cond_val in prompts:
        # Skip conditional if not met
        if cond_var and new_env.get(cond_var) != cond_val:
            # If condition not met and this var has a value, we should remove it?
            # Better to keep it for now; will be overwritten if condition becomes true
            # We'll just skip prompting.
            continue

        current = new_env.get(var_name, "")
        prompt_text = f"{description}"
        if current:
            prompt_text += f" [current: {current}]"
        prompt_text += ": "

        while True:
            user_input = input(prompt_text).strip()
            if not user_input and current:
                # Keep existing (already in new_env)
                break
            elif not user_input and required:
                print(f"  -> {var_name} is required. Please provide a value.")
                continue
            elif user_input.lower() in ("y", "n") and "y/n" in description:
                new_env[var_name] = "true" if user_input.lower() == "y" else "false"
                # If RPC enabled, generate secret (only if not already set or user wants new)
                if var_name == "EMBER_RPC_ENABLED" and user_input.lower() == "y":
                    # If no existing secret, generate one; if existing, keep it unless user wants new?
                    # For simplicity, generate new only if not set
                    if "EMBER_RPC_SECRET" not in new_env or not new_env["EMBER_RPC_SECRET"]:
                        secret = secrets.token_hex(16)  # 32 chars
                        new_env["EMBER_RPC_SECRET"] = secret
                        print(f"  -> Generated RPC secret: {secret}")
                break
            else:
                new_env[var_name] = user_input
                break

    # Write .env file (sort for consistency, but preserve all keys)
    env_lines = []
    for key, value in sorted(new_env.items()):
        env_lines.append(f"{key}={value}")
    Path(".env").write_text("\n".join(env_lines) + "\n")

    print("\n=== Configuration Summary ===")
    for key in sorted(new_env.keys()):
        val = new_env[key]
        display = val if "token" not in key.lower() else "*" * 20
        print(f"  {key}: {display}")
    print(f"\n✅ .env file created/updated with {len(new_env)} entries.")


def start_command(cog_filter: str | None = None, instance: str | None = None):
    """Start the bot in-process via core.cli.run."""
    if instance:
        from core.instances import apply_to_env, get_instance

        inst = get_instance(instance)
        if inst is None:
            print(f"❌ Unknown instance: {instance!r}")
            return 1
        apply_to_env(inst)
        print(f"📁 Using instance {inst.name!r} (data={inst.data_path}, backend={inst.backend})")

    env_path = Path(".env")
    if not env_path.exists():
        print("⚠️  .env not found in cwd — relying on real environment variables.")

    print("🚀 Starting Ember bot...")
    try:
        from core.cli import run

        return run(cog_filter)
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user.")
        return 0
    except ModuleNotFoundError as e:
        print(f"❌ Cannot import Ember from cwd: {e}")
        print("   Run from your Ember repo root, or install with `pip install -e .`")
        return 1


def version_command():
    """Print Ember + Python + discord.py + OS in one line."""
    from core.cli import version_string

    print(version_string())
    return 0


def debuginfo_command():
    """Multi-line environment dump for issue reports."""
    from core.cli import debuginfo

    print(debuginfo())
    return 0


def backend_command(action: str):
    """Inspect the active storage backend."""
    if action == "show":
        from core.cli import backend_show

        print(backend_show())
        return 0
    print(f"unknown backend action: {action}")
    return 1


def cog_command(action: str, *args: str):
    """`ember cog list` — discover cogs on disk."""
    if action == "list":
        from core.cli import cog_list

        print(cog_list())
        return 0
    print(f"unknown cog action: {action}")
    print("Available: list")
    return 1


def diagnose_command():
    """Run offline diagnostics to check system readiness."""
    print("=== Ember Offline Diagnostics ===\n")
    issues = []
    env = read_env_file()  # always loaded; empty dict if .env absent

    # 1. Python version
    py_version = sys.version_info
    if py_version < (3, 11):
        issues.append(
            ("FAIL", f"Python {py_version.major}.{py_version.minor} detected (need 3.11+)")
        )
    else:
        print(f"✅ Python {py_version.major}.{py_version.minor}.{py_version.micro}")

    # 2. Required packages
    required_packages = ["discord.py", "python-dotenv", "aiosqlite"]
    for pkg in required_packages:
        try:
            dist = importlib.metadata.distribution(pkg)
            print(f"✅ {pkg} ({dist.version})")
        except importlib.metadata.PackageNotFoundError:
            print(f"❌ {pkg} not installed")
            issues.append(("FAIL", f"Missing package: {pkg}"))

    # 3. .env file
    env_path = Path(".env")
    if not env_path.exists():
        print("❌ .env file not found (run 'ember setup')")
        issues.append(("FAIL", "Missing .env file"))
    else:
        print("✅ .env file exists")
        if not env.get("BOT_TOKEN"):
            print("❌ BOT_TOKEN not set in .env")
            issues.append(("FAIL", "BOT_TOKEN missing"))
        else:
            print("✅ BOT_TOKEN present")

    # 4. Directory structure
    required_dirs = ["cogs", "data", "logs"]
    for d in required_dirs:
        if Path(d).exists():
            print(f"✅ Directory '{d}' exists")
        else:
            print(f"⚠️  Directory '{d}' missing (will be created at runtime)")
            issues.append(("WARN", f"Directory '{d}' missing"))

    # 5. Cogs
    cogs_dir = Path("cogs")
    if cogs_dir.exists():
        cog_count = sum(
            1 for p in cogs_dir.iterdir() if p.is_dir() and (p / "__init__.py").exists()
        )
        if cog_count > 0:
            print(f"✅ Found {cog_count} cog(s) in cogs/")
        else:
            print("⚠️  No cogs found (cogs/ is empty or missing __init__.py files)")
            issues.append(("WARN", "No cogs detected"))
    else:
        print("❌ cogs/ directory missing")
        issues.append(("FAIL", "cogs/ directory missing"))

    # 6. Database backend
    backend = env.get("EMBER_DB_BACKEND", "sqlite")
    print(f"ℹ️  DB backend: {backend}")
    if backend == "sqlite":
        db_path = Path("data/ember_config.db")
        if db_path.exists():
            print("✅ SQLite database exists")
        else:
            print("ℹ️  SQLite DB will be created on first run")
    elif backend == "postgres":
        if env.get("EMBER_POSTGRES_DSN"):
            print("✅ Postgres DSN configured (connection not tested offline)")
        else:
            print("❌ EMBER_POSTGRES_DSN not set for postgres backend")
            issues.append(("FAIL", "Postgres DSN missing"))
    elif backend == "mongo":
        if env.get("EMBER_MONGO_URI"):
            print("✅ MongoDB URI configured (connection not tested offline)")
        else:
            print("❌ EMBER_MONGO_URI not set for mongo backend")
            issues.append(("FAIL", "MongoDB URI missing"))

    # Summary
    print("\n=== Summary ===")
    if issues:
        print(f"Found {len(issues)} issue(s):")
        for level, msg in issues:
            symbol = "✅" if level == "OK" else "⚠️" if level == "WARN" else "❌"
            print(f"  {symbol} {msg}")
        return 1
    else:
        print("✅ All checks passed. System is ready.")
        return 0


def instance_command(action: str, *args: str, **kwargs: Any) -> int:
    """`ember instance create|list|show|delete|use`."""
    from core.instances import (
        create_instance,
        delete_instance,
        get_instance,
        list_instances,
        set_default,
    )

    if action == "list":
        instances = list_instances()
        if not instances:
            print("No instances configured. Run: ember instance create <name> --data-path <dir>")
            return 0
        width = max(len(i.name) for i in instances)
        print(f"{'NAME':<{width}}  BACKEND   DATA PATH")
        for inst in instances:
            print(f"{inst.name:<{width}}  {inst.backend:<8}  {inst.data_path}")
        return 0

    if action == "show":
        if not args:
            print("Usage: ember instance show <name>")
            return 1
        inst = get_instance(args[0])
        if not inst:
            print(f"❌ Unknown instance: {args[0]!r}")
            return 1
        print(f"name:       {inst.name}")
        print(f"data_path:  {inst.data_path}")
        print(f"backend:    {inst.backend}")
        print(f"created:    {inst.created}")
        return 0

    if action == "create":
        if not args:
            print("Usage: ember instance create <name> --data-path <dir> [--backend sqlite]")
            return 1
        try:
            inst = create_instance(
                args[0],
                data_path=kwargs.get("data_path") or f"./data/{args[0]}",
                backend=kwargs.get("backend") or "sqlite",
                overwrite=bool(kwargs.get("overwrite")),
            )
        except ValueError as exc:
            print(f"❌ {exc}")
            return 1
        print(f"✅ Created instance {inst.name!r} (data={inst.data_path}, backend={inst.backend})")
        return 0

    if action == "delete":
        if not args:
            print("Usage: ember instance delete <name> [--purge]")
            return 1
        ok = delete_instance(args[0], remove_data=bool(kwargs.get("purge")))
        if not ok:
            print(f"❌ Unknown instance: {args[0]!r}")
            return 1
        print(f"✅ Deleted instance {args[0]!r}")
        return 0

    if action == "use":
        if not args:
            print("Usage: ember instance use <name>")
            return 1
        try:
            set_default(args[0])
        except KeyError:
            print(f"❌ Unknown instance: {args[0]!r}")
            return 1
        print(f"✅ Default instance is now {args[0]!r}")
        return 0

    print(f"unknown instance action: {action}")
    print("Available: create, list, show, delete, use")
    return 1


def convert_command(
    *,
    src_backend: str,
    dst_backend: str,
    data_dir: str,
    postgres_dsn: str | None,
    mongo_uri: str | None,
    dump_to: str | None,
    restore_from: str | None,
) -> int:
    """`ember convert --from <src> --to <dst>` — copy data between backends."""
    import asyncio

    from core.conversion import run_conversion

    try:
        report = asyncio.run(
            run_conversion(
                src_backend=src_backend,
                dst_backend=dst_backend,
                data_dir=Path(data_dir),
                postgres_dsn=postgres_dsn,
                mongo_uri=mongo_uri,
                dump_to=Path(dump_to) if dump_to else None,
                restore_from=Path(restore_from) if restore_from else None,
            )
        )
    except Exception as exc:
        print(f"❌ Conversion failed: {exc}")
        return 1
    print(f"✅ {report}")
    return 0


def vendor_command(action: str, *args: str, **kwargs: Any) -> int:
    """`ember vendor list|show|search|install|uninstall` — manage curated cogs."""
    from core.vendor import get_cog, install, list_cogs, search, uninstall

    if action == "list":
        cogs = list_cogs()
        if not cogs:
            print("No vendor entries available.")
            return 0
        width = max(len(c.name) for c in cogs)
        print(f"{'NAME':<{width}}  REPO")
        for c in cogs:
            print(f"{c.name:<{width}}  {c.repo_url}")
        return 0

    if action == "show":
        if not args:
            print("Usage: ember vendor show <name>")
            return 1
        c = get_cog(args[0])
        if c is None:
            print(f"❌ Unknown vendor cog: {args[0]!r}")
            return 1
        print(f"name:        {c.name}")
        print(f"author:      {c.author}")
        print(f"repo_url:    {c.repo_url}")
        print(f"branch:      {c.branch}")
        if c.subpath:
            print(f"subpath:     {c.subpath}")
        print(f"min_ember:   {c.min_ember}")
        print(f"tags:        {', '.join(c.tags)}")
        print(f"description: {c.description}")
        if c.install_msg:
            print(f"install_msg: {c.install_msg}")
        return 0

    if action == "search":
        if not args:
            print("Usage: ember vendor search <query>")
            return 1
        results = search(args[0])
        if not results:
            print(f"No matches for {args[0]!r}.")
            return 0
        for c in results:
            print(f"{c.name}: {c.description}")
        return 0

    if action == "install":
        if not args:
            print("Usage: ember vendor install <name> [--update]")
            return 1
        c = get_cog(args[0])
        if c is None:
            print(f"❌ Unknown vendor cog: {args[0]!r}")
            return 1
        try:
            link = install(c, update=bool(kwargs.get("update")))
        except Exception as exc:
            print(f"❌ Install failed: {exc}")
            return 1
        print(f"✅ Installed {c.name!r} → {link}")
        if c.install_msg:
            print(c.install_msg)
        return 0

    if action == "uninstall":
        if not args:
            print("Usage: ember vendor uninstall <name>")
            return 1
        c = get_cog(args[0])
        if c is None:
            print(f"❌ Unknown vendor cog: {args[0]!r}")
            return 1
        if uninstall(c):
            print(f"✅ Removed symlink for {c.name!r}.")
            return 0
        print(f"⚠️  No symlink found for {c.name!r}.")
        return 1

    print(f"unknown vendor action: {action}")
    print("Available: list, show, search, install, uninstall")
    return 1


def info_command():
    """Display system and bot information."""
    print("=== Ember System Info ===\n")

    # Version
    try:
        version = importlib.metadata.version("ember-discord-bot")
        print(f"Ember Version: {version}")
    except importlib.metadata.PackageNotFoundError:
        print("Ember Version: (dev / not installed)")

    # Python
    print(f"Python: {sys.version.split()[0]} ({sys.platform})")

    # Cog count
    cogs_dir = Path("cogs")
    cog_count = 0
    if cogs_dir.exists():
        cog_count = sum(
            1 for p in cogs_dir.iterdir() if p.is_dir() and (p / "__init__.py").exists()
        )
    print(f"Loaded Cogs: {cog_count}")

    # DB backend
    env = read_env_file()
    backend = env.get("EMBER_DB_BACKEND", "sqlite (default)")
    print(f"DB Backend: {backend}")

    # Directories
    print(f"Cogs Dir: {cogs_dir.resolve() if cogs_dir.exists() else 'missing'}")
    print(f"Data Dir: {Path('data').exists()}")
    print(f"Logs Dir: {Path('logs').exists()}")

    # Optional: check if bot token is set
    if env.get("BOT_TOKEN"):
        token = env["BOT_TOKEN"]
        masked = token[:6] + "..." if len(token) > 10 else "***"
        print(f"Bot Token: {masked}")
    else:
        print("Bot Token: NOT SET")


def main():
    parser = argparse.ArgumentParser(description="Ember CLI Tool")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Setup command
    subparsers.add_parser("setup", help="Interactive .env configuration")

    # Start command
    start_parser = subparsers.add_parser("start", help="Start the bot (loads .env)")
    start_parser.add_argument(
        "cog_filter", nargs="?", help="Optional cog filter to load specific cogs"
    )
    start_parser.add_argument(
        "--instance",
        help="Named instance from the registry (sets DATA_DIR + EMBER_DB_BACKEND)",
    )
    # Alias 'run' to 'start' for backwards compatibility
    run_parser = subparsers.add_parser("run", help="[alias for start] Start the bot")
    run_parser.add_argument(
        "cog_filter", nargs="?", help="Optional cog filter to load specific cogs"
    )
    run_parser.add_argument("--instance", help="Named instance from the registry")

    # Instance management
    inst_parser = subparsers.add_parser("instance", help="Manage named bot instances")
    inst_parser.add_argument(
        "action", choices=["create", "list", "show", "delete", "use"], help="What to do"
    )
    inst_parser.add_argument("name", nargs="?", help="Instance name")
    inst_parser.add_argument("--data-path", help="Data directory for this instance")
    inst_parser.add_argument(
        "--backend",
        choices=["sqlite", "postgres", "json", "mongo"],
        default="sqlite",
        help="Storage backend",
    )
    inst_parser.add_argument(
        "--overwrite", action="store_true", help="Replace an existing instance"
    )
    inst_parser.add_argument(
        "--purge", action="store_true", help="Also delete the instance's data directory"
    )

    # Version
    subparsers.add_parser("version", help="Print Ember/Python/discord.py/OS versions")

    # Debuginfo
    subparsers.add_parser("debuginfo", help="Dump environment for issue reports")

    # Backend
    backend_parser = subparsers.add_parser("backend", help="Inspect the storage backend")
    backend_parser.add_argument("action", choices=["show"], help="What to do")

    # Cog
    cog_parser = subparsers.add_parser("cog", help="Cog discovery and management")
    cog_parser.add_argument("action", choices=["list"], help="What to do")

    # Diagnose command
    subparsers.add_parser("diagnose", help="Run offline system checks")

    # Info command
    subparsers.add_parser("info", help="Show system and bot information")

    # Vendor (curated cog registry)
    vendor_parser = subparsers.add_parser("vendor", help="Browse curated cogs")
    vendor_parser.add_argument(
        "action",
        choices=["list", "show", "search", "install", "uninstall"],
        help="What to do",
    )
    vendor_parser.add_argument("query", nargs="?", help="Cog name or search query")
    vendor_parser.add_argument(
        "--update", action="store_true", help="Pull latest if the repo is already cached"
    )

    # Convert (backend migration)
    convert_parser = subparsers.add_parser("convert", help="Copy data between storage backends")
    convert_parser.add_argument(
        "--from",
        dest="src_backend",
        choices=["sqlite", "postgres", "json", "mongo"],
        help="Source backend (omit when using --restore-from)",
    )
    convert_parser.add_argument(
        "--to",
        dest="dst_backend",
        choices=["sqlite", "postgres", "json", "mongo"],
        help="Destination backend (omit when using --dump-to)",
    )
    convert_parser.add_argument(
        "--data-dir", default="data", help="Data dir for file-based backends"
    )
    convert_parser.add_argument("--postgres-dsn", help="Postgres DSN if either side is postgres")
    convert_parser.add_argument("--mongo-uri", help="Mongo URI if either side is mongo")
    convert_parser.add_argument(
        "--dump-to", help="Dump source to a JSON file instead of writing a destination"
    )
    convert_parser.add_argument("--restore-from", help="Restore a JSON dump into the destination")

    # Create cog command
    create_parser = subparsers.add_parser("create-cog", help="Create a new cog")
    create_parser.add_argument("name", help="Name of the cog to create")
    create_parser.add_argument(
        "--package", action="store_true", help="Create as package structure instead of single file"
    )

    # Test commands
    test_parser = subparsers.add_parser("test", help="Run tests")
    test_parser.add_argument("filter", nargs="?", help="Test filter pattern")

    # Lint commands
    lint_parser = subparsers.add_parser("lint", help="Run code quality checks")
    lint_parser.add_argument("--format", action="store_true", help="Format code with Black")

    args = parser.parse_args()

    if args.command == "setup":
        return setup_command()
    elif args.command in ("start", "run"):
        return start_command(args.cog_filter, instance=getattr(args, "instance", None))
    elif args.command == "instance":
        kwargs = {
            "data_path": getattr(args, "data_path", None),
            "backend": getattr(args, "backend", None),
            "overwrite": getattr(args, "overwrite", False),
            "purge": getattr(args, "purge", False),
        }
        return instance_command(args.action, *([args.name] if args.name else []), **kwargs)
    elif args.command == "version":
        return version_command()
    elif args.command == "debuginfo":
        return debuginfo_command()
    elif args.command == "backend":
        return backend_command(args.action)
    elif args.command == "cog":
        return cog_command(args.action)
    elif args.command == "diagnose":
        return diagnose_command()
    elif args.command == "info":
        return info_command()
    elif args.command == "vendor":
        return vendor_command(
            args.action,
            *([args.query] if args.query else []),
            update=getattr(args, "update", False),
        )
    elif args.command == "convert":
        if not args.restore_from and not args.src_backend:
            print("❌ --from is required (unless --restore-from)")
            return 1
        if not args.dump_to and not args.dst_backend:
            print("❌ --to is required (unless --dump-to)")
            return 1
        return convert_command(
            src_backend=args.src_backend or "sqlite",
            dst_backend=args.dst_backend or "sqlite",
            data_dir=args.data_dir,
            postgres_dsn=args.postgres_dsn,
            mongo_uri=args.mongo_uri,
            dump_to=args.dump_to,
            restore_from=args.restore_from,
        )
    elif args.command == "create-cog":
        return create_cog_structure(args.name, args.package)
    elif args.command == "test":
        return run_tests(args.filter)
    elif args.command == "lint":
        if args.format:
            return run_format()
        else:
            return run_lint()
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
