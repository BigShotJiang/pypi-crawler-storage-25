"""Smoke tests for the core.testing pytest plugin fixtures."""

from __future__ import annotations

import pytest

pytest_plugins = ["core.testing"]


@pytest.mark.asyncio
async def test_ember_store_roundtrip(ember_store):
    await ember_store.set("guild", 1, "enabled", True)
    assert await ember_store.get("guild", 1, "enabled") is True


def test_mock_bot_defaults(mock_bot):
    assert mock_bot.user.id == 999
    assert mock_bot.guilds == []


def test_mock_interaction_send(mock_interaction):
    assert mock_interaction.user.id == 42
    assert mock_interaction.guild.id == 1
    assert mock_interaction.response.is_done() is False
