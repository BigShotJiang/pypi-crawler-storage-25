from __future__ import annotations

import io
import re
from datetime import datetime, timedelta

import discord


def humanize_timedelta(seconds: int | float, *, max_units: int = 3) -> str:
    seconds = int(abs(seconds))
    if seconds == 0:
        return "0 seconds"

    units = [
        ("year", 365 * 24 * 3600),
        ("week", 7 * 24 * 3600),
        ("day", 24 * 3600),
        ("hour", 3600),
        ("minute", 60),
        ("second", 1),
    ]

    parts: list[str] = []
    for name, size in units:
        if seconds >= size and len(parts) < max_units:
            value, seconds = divmod(seconds, size)
            parts.append(f"{value} {name}{'s' if value != 1 else ''}")

    return ", ".join(parts)


def humanize_timedelta_short(seconds: int | float) -> str:
    """Compact form: 1d 2h 3m 4s."""
    seconds = int(abs(seconds))
    if seconds == 0:
        return "0s"

    units = [
        ("y", 365 * 24 * 3600),
        ("w", 7 * 24 * 3600),
        ("d", 24 * 3600),
        ("h", 3600),
        ("m", 60),
        ("s", 1),
    ]
    parts: list[str] = []
    for suffix, size in units:
        if seconds >= size:
            value, seconds = divmod(seconds, size)
            parts.append(f"{value}{suffix}")
    return " ".join(parts[:3])  # keep at most 3 units


def humanize_number(value: int | float, *, precision: int = 0) -> str:
    if precision:
        return f"{value:,.{precision}f}"
    if isinstance(value, float):
        return f"{value:,.2f}"
    return f"{int(value):,}"


def ordinal(n: int) -> str:
    suffix = ["th", "st", "nd", "rd", "th"][min(n % 10, 4)]
    if 11 <= n % 100 <= 13:
        suffix = "th"
    return f"{n}{suffix}"


def pagify(
    text: str,
    *,
    page_size: int = 2000,
    delims: tuple[str, ...] = ("\n", " "),
    strip_before_yield: bool = True,
) -> list[str]:
    pages: list[str] = []
    while len(text) > page_size:
        stop = page_size
        for delim in delims:
            idx = text.rfind(delim, 0, page_size)
            if idx != -1:
                stop = min(stop, idx + len(delim))
                break
        page = text[:stop]
        if strip_before_yield:
            page = page.strip()
        if page:
            pages.append(page)
        text = text[stop:]
    if text:
        pages.append(text.strip() if strip_before_yield else text)
    return pages


def truncate(text: str, max_len: int, *, suffix: str = "…") -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - len(suffix)] + suffix


def escape_markdown(text: str) -> str:
    """Escape Discord markdown special characters in *text*."""
    return re.sub(r"([\\`*_~|<>{}[\]()])", r"\\\1", text)


def bold(text: str) -> str:
    return f"**{text}**"


def italic(text: str) -> str:
    return f"*{text}*"


def underline(text: str) -> str:
    return f"__{text}__"


def strikethrough(text: str) -> str:
    return f"~~{text}~~"


def inline(text: str) -> str:
    return f"`{text}`"


def codeblock(text: str, lang: str = "") -> str:
    return f"```{lang}\n{text}\n```"


def subtext(text: str) -> str:
    return f"-# {text}"


def spoiler(text: str) -> str:
    return f"||{text}||"


def quote(text: str) -> str:
    return "\n".join(f"> {line}" for line in text.splitlines())


def hyperlink(label: str, url: str) -> str:
    return f"[{label}]({url})"


def parse_duration(text: str) -> timedelta | None:
    text = text.strip()
    if not text:
        return None

    total = timedelta()
    matched_any = False
    # "mo" alternative must come before "m" so "5mo" isn't parsed as 5 minutes
    for m in re.finditer(r"(\d+)\s*(mo(?:nths?)?|[ywdhms])(?![A-Za-z])", text, re.IGNORECASE):
        val = int(m.group(1))
        unit = m.group(2).lower()
        if unit.startswith("mo"):
            unit = "mo"
        matched_any = True
        total += {
            "y": timedelta(days=365 * val),
            "mo": timedelta(days=30 * val),
            "w": timedelta(weeks=val),
            "d": timedelta(days=val),
            "h": timedelta(hours=val),
            "m": timedelta(minutes=val),
            "s": timedelta(seconds=val),
        }[unit]
    if matched_any:
        return total

    m = re.match(r"(\d+)\s+(second|minute|hour|day|week|month|year)s?$", text, re.IGNORECASE)
    if m:
        val, unit = int(m.group(1)), m.group(2).lower()
        return {
            "second": timedelta(seconds=val),
            "minute": timedelta(minutes=val),
            "hour": timedelta(hours=val),
            "day": timedelta(days=val),
            "week": timedelta(weeks=val),
            "month": timedelta(days=30 * val),
            "year": timedelta(days=365 * val),
        }.get(unit)

    return None


def text_to_file(
    text: str,
    filename: str = "output.txt",
    *,
    encoding: str = "utf-8",
) -> discord.File:
    return discord.File(
        io.BytesIO(text.encode(encoding)),
        filename=filename,
    )


def format_perms_list(perms: discord.Permissions) -> str:
    return ", ".join(perm.replace("_", " ").title() for perm, value in perms if value) or "None"


def format_filesize(size_bytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(size_bytes) < 1024:
            return f"{size_bytes:.1f} {unit}" if unit != "B" else f"{size_bytes} B"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def format_relative_time(dt: datetime | int | float) -> str:
    if isinstance(dt, datetime):
        ts = int(dt.timestamp())
    else:
        ts = int(dt)
    return f"<t:{ts}:R>"


def format_timestamp(dt: datetime | int | float, style: str = "f") -> str:
    if isinstance(dt, datetime):
        ts = int(dt.timestamp())
    else:
        ts = int(dt)
    return f"<t:{ts}:{style}>"


def sanitize_output(text: str) -> str:
    import os
    import re

    sensitive = [
        os.getenv("BOT_TOKEN", ""),
        os.getenv("TOKEN_ENCRYPTION_KEY", ""),
        os.getenv("EMBER_POSTGRES_DSN", ""),
        os.getenv("EMBER_MONGO_URI", ""),
    ]
    result = text
    for secret in sensitive:
        if secret:
            result = result.replace(secret, "[REDACTED]")

    # Also redact anything that looks like a Discord token (base64.base64.base64)
    result = re.sub(
        r"[A-Za-z0-9_-]{23,28}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,}",
        "[REDACTED_TOKEN]",
        result,
    )
    return result
