from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine, Sequence

import discord

logger = logging.getLogger("ember.cards")


_SUCCESS = discord.Color.from_str("#57F287")
_ERROR = discord.Color.from_str("#ED4245")
_WARNING = discord.Color.from_str("#FEE75C")
_INFO = discord.Color.blurple()


def _card_container(
    title: str,
    body: str,
    accent: discord.Color,
    footer: str | None = None,
    image_url: str | None = None,
) -> discord.ui.Container[discord.ui.LayoutView]:
    children: list[discord.ui.Item] = [
        discord.ui.TextDisplay(f"## {title}"),
        discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
        discord.ui.TextDisplay(body),
    ]
    if image_url:
        children.append(discord.ui.MediaGallery(discord.MediaGalleryItem(media=image_url)))
    if footer:
        children += [
            discord.ui.Separator(spacing=discord.SeparatorSpacing.small),
            discord.ui.TextDisplay(f"-# {footer}"),
        ]
    return discord.ui.Container(*children, accent_color=accent)


def _wrap(container: discord.ui.Container) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    view.add_item(container)
    return view


def make_info_card(
    title: str,
    body: str,
    *,
    accent_color: discord.Color = _INFO,
    footer: str | None = None,
    image_url: str | None = None,
) -> discord.ui.LayoutView:
    """Generic informational card (blurple accent by default)."""
    return _wrap(_card_container(title, body, accent_color, footer, image_url))


def make_success_card(
    title: str,
    body: str,
    *,
    footer: str | None = None,
) -> discord.ui.LayoutView:
    """Green-accented success card."""
    return _wrap(_card_container(title, body, _SUCCESS, footer))


def make_error_card(
    title: str,
    body: str,
    *,
    footer: str | None = None,
) -> discord.ui.LayoutView:
    """Error card."""
    return _wrap(_card_container(title, body, _ERROR, footer))


def make_warning_card(
    title: str,
    body: str,
    *,
    footer: str | None = None,
) -> discord.ui.LayoutView:
    """Yellow-accented warning card."""
    return _wrap(_card_container(title, body, _WARNING, footer))


class ConfirmView(discord.ui.LayoutView):
    """
    Interactive confirm / cancel dialog using Components V2.

    Usage::

        async def _do_delete(inter):
            await inter.response.send_message("Deleted!", ephemeral=True)

        view = ConfirmView(
            title="Delete role?",
            body="This cannot be undone.",
            on_confirm=_do_delete,
            accent_color=discord.Color.red(),
            confirm_label="Delete",
            confirm_style=discord.ButtonStyle.danger,
        )
        await interaction.followup.send(view=view, ephemeral=True)

    After the user clicks, ``view.confirmed`` is True/False.
    """

    confirmed: bool = False

    def __init__(
        self,
        title: str,
        body: str,
        *,
        on_confirm: Callable[[discord.Interaction], Coroutine] | None = None,
        on_cancel: Callable[[discord.Interaction], Coroutine] | None = None,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
        confirm_style: discord.ButtonStyle = discord.ButtonStyle.success,
        cancel_style: discord.ButtonStyle = discord.ButtonStyle.secondary,
        confirm_emoji: str | None = "✅",
        cancel_emoji: str | None = "❌",
        accent_color: discord.Color = _WARNING,
        footer: str | None = None,
        timeout: float = 60.0,
        allowed_user_id: int | None = None,
    ):
        super().__init__(timeout=timeout)
        self._on_confirm = on_confirm
        self._on_cancel = on_cancel
        self._allowed_user_id = allowed_user_id

        self.add_item(_card_container(title, body, accent_color, footer))

        confirm_btn = discord.ui.Button(
            label=confirm_label,
            style=confirm_style,
            emoji=confirm_emoji,
        )
        confirm_btn.callback = self._confirm

        cancel_btn = discord.ui.Button(
            label=cancel_label,
            style=cancel_style,
            emoji=cancel_emoji,
        )
        cancel_btn.callback = self._cancel
        self.add_item(discord.ui.ActionRow(confirm_btn, cancel_btn))

    async def _guard(self, inter: discord.Interaction) -> bool:
        if self._allowed_user_id is not None and inter.user.id != self._allowed_user_id:
            await inter.response.send_message("This dialog isn't for you.", ephemeral=True)
            return False
        return True

    async def _confirm(self, inter: discord.Interaction) -> None:
        if not await self._guard(inter):
            return
        self.confirmed = True
        self.stop()
        if self._on_confirm:
            await self._on_confirm(inter)
        elif not inter.response.is_done():
            await inter.response.defer()

    async def _cancel(self, inter: discord.Interaction) -> None:
        if not await self._guard(inter):
            return
        self.confirmed = False
        self.stop()
        if self._on_cancel:
            await self._on_cancel(inter)
        elif not inter.response.is_done():
            await inter.response.defer()


class PaginatedView(discord.ui.LayoutView):
    """
    Components V2 paginator.

    Pass a list of pre-rendered page strings (markdown) and optionally a title.
    The view renders one page at a time with prev/next buttons.

    Usage::

        pages = ["Page 1 content", "Page 2 content", "Page 3 content"]
        view = PaginatedView(pages, title="Results", accent_color=discord.Color.blurple())
        await interaction.followup.send(view=view, ephemeral=True)
    """

    def __init__(
        self,
        pages: Sequence[str],
        *,
        title: str = "",
        accent_color: discord.Color = _INFO,
        footer_prefix: str = "",
        timeout: float = 180.0,
        allowed_user_id: int | None = None,
    ):
        super().__init__(timeout=timeout)
        if not pages:
            raise ValueError("PaginatedView requires at least one page")
        self._pages = list(pages)
        self._title = title
        self._accent = accent_color
        self._footer_prefix = footer_prefix
        self._allowed_user_id = allowed_user_id
        self._current = 0
        self._render()

    def _render(self) -> None:
        self.clear_items()
        n = len(self._pages)
        footer = f"{self._footer_prefix}Page {self._current + 1} of {n}".strip()
        title = self._title or "Results"
        self.add_item(_card_container(title, self._pages[self._current], self._accent, footer))
        self._add_nav()

    def _add_nav(self) -> None:
        n = len(self._pages)
        if n <= 1:
            return
        buttons: list[discord.ui.Button] = []
        if self._current > 0:
            prev = discord.ui.Button(label="← Previous", style=discord.ButtonStyle.secondary)
            prev.callback = self._prev
            buttons.append(prev)
        if self._current < n - 1:
            nxt = discord.ui.Button(label="Next →", style=discord.ButtonStyle.secondary)
            nxt.callback = self._next
            buttons.append(nxt)
        if buttons:
            self.add_item(discord.ui.ActionRow(*buttons))

    async def _guard(self, inter: discord.Interaction) -> bool:
        if self._allowed_user_id is not None and inter.user.id != self._allowed_user_id:
            await inter.response.send_message("This isn't your paginator.", ephemeral=True)
            return False
        return True

    async def _prev(self, inter: discord.Interaction) -> None:
        if not await self._guard(inter):
            return
        self._current = max(0, self._current - 1)
        self._render()
        await inter.response.edit_message(view=self)

    async def _next(self, inter: discord.Interaction) -> None:
        if not await self._guard(inter):
            return
        self._current = min(len(self._pages) - 1, self._current + 1)
        self._render()
        await inter.response.edit_message(view=self)


class SelectView(discord.ui.LayoutView):
    """
    Components V2 container with a Select menu.

    Usage::

        async def on_pick(inter, values):
            await inter.response.send_message(f"You picked: {values[0]}", ephemeral=True)

        options = [
            discord.SelectOption(label="Option A", value="a"),
            discord.SelectOption(label="Option B", value="b"),
        ]
        view = SelectView(
            title="Pick one",
            body="Choose from the menu below.",
            options=options,
            on_select=on_pick,
        )
        await interaction.followup.send(view=view, ephemeral=True)
    """

    def __init__(
        self,
        title: str,
        body: str,
        options: list[discord.SelectOption],
        *,
        on_select: Callable[[discord.Interaction, list[str]], Coroutine] | None = None,
        placeholder: str = "Select an option…",
        min_values: int = 1,
        max_values: int = 1,
        accent_color: discord.Color = _INFO,
        footer: str | None = None,
        timeout: float = 60.0,
        allowed_user_id: int | None = None,
    ):
        super().__init__(timeout=timeout)
        self._on_select = on_select
        self._allowed_user_id = allowed_user_id
        self.selected: list[str] = []

        self.add_item(_card_container(title, body, accent_color, footer))

        sel = discord.ui.Select(
            placeholder=placeholder,
            options=options,
            min_values=min_values,
            max_values=max_values,
        )
        sel.callback = self._select_callback
        self.add_item(discord.ui.ActionRow(sel))

    async def _select_callback(self, inter: discord.Interaction) -> None:
        if self._allowed_user_id is not None and inter.user.id != self._allowed_user_id:
            await inter.response.send_message("This isn't your menu.", ephemeral=True)
            return
        self.selected = inter.data.get("values", [])  # type: ignore[arg-type]
        self.stop()
        if self._on_select:
            await self._on_select(inter, self.selected)
        elif not inter.response.is_done():
            await inter.response.defer()


def make_list_card(
    title: str,
    items: Sequence[str],
    *,
    per_page: int = 10,
    accent_color: discord.Color = _INFO,
    footer_prefix: str = "",
    empty_message: str = "Nothing to show.",
    numbered: bool = True,
    allowed_user_id: int | None = None,
    timeout: float = 180.0,
) -> discord.ui.LayoutView:
    """Build a paginated list view from a sequence of string items.

    Each page shows *per_page* items, numbered if *numbered* is True.
    Returns a single static card if the list fits in one page,
    or a ``PaginatedView`` with prev/next buttons if it doesn't.

    Usage::

        items = [f"{m.mention} — {m.display_name}" for m in guild.members]
        view = make_list_card("Server Members", items, per_page=15)
        await interaction.followup.send(view=view, ephemeral=True)
    """
    if not items:
        return make_info_card(title, empty_message, accent_color=accent_color)

    # Split into pages
    chunks: list[str] = []
    for i in range(0, len(items), per_page):
        page_items = items[i : i + per_page]
        offset = i + 1
        if numbered:
            lines = "\n".join(f"`{offset + j}.` {item}" for j, item in enumerate(page_items))
        else:
            lines = "\n".join(f"• {item}" for item in page_items)
        chunks.append(lines)

    if len(chunks) == 1:
        footer = f"{footer_prefix}{len(items)} item{'s' if len(items) != 1 else ''}".strip()
        return _wrap(_card_container(title, chunks[0], accent_color, footer))

    return PaginatedView(
        chunks,
        title=title,
        accent_color=accent_color,
        footer_prefix=(
            f"{footer_prefix}{len(items)} items — " if not footer_prefix else footer_prefix
        ),
        timeout=timeout,
        allowed_user_id=allowed_user_id,
    )


def make_case_card(
    case_number: int,
    action: str,
    user: discord.User | discord.Member,
    moderator: discord.User | discord.Member | None,
    reason: str | None = None,
    *,
    timestamp: int | None = None,
    extra_fields: dict[str, str] | None = None,
    accent_color: discord.Color | None = None,
    duration: str | None = None,
) -> discord.ui.LayoutView:
    """Build a modlog case card (Components V2).

    Used by core/modlog.py when posting to the mod-log channel.

    Args:
        case_number: Incrementing case ID for this guild.
        action: Action name: "ban", "kick", "warn", "timeout", etc.
        user: The user the action was taken against.
        moderator: The moderator who issued the action.
        reason: Optional reason string.
        timestamp: Unix timestamp (int). Defaults to now.
        extra_fields: Additional ``{label: value}`` lines in the card body.
        accent_color: Override the default action colour.
        duration: Duration string for temporary actions (e.g. "7d", "1h").
    """
    import time

    from core.branding import EmberIcons

    ACTION_COLORS = {
        "ban": discord.Color.from_str("#ED4245"),
        "hackban": discord.Color.from_str("#ED4245"),
        "softban": discord.Color.from_str("#FEE75C"),
        "kick": discord.Color.from_str("#FEE75C"),
        "warn": discord.Color.from_str("#FEE75C"),
        "timeout": discord.Color.from_str("#FF6B35"),
        "mute": discord.Color.from_str("#FF6B35"),
        "unban": discord.Color.from_str("#57F287"),
        "unmute": discord.Color.from_str("#57F287"),
        "note": discord.Color.blurple(),
        "voicekick": discord.Color.from_str("#FEE75C"),
        "voiceban": discord.Color.from_str("#ED4245"),
    }

    color = accent_color or ACTION_COLORS.get(action.lower(), discord.Color.blurple())
    icon = EmberIcons.for_case(action)
    ts = timestamp or int(time.time())
    mod_str = moderator.mention if moderator else "Unknown"
    reason_str = reason or "No reason provided."

    lines = [
        f"**User:** {user.mention} (`{user.id}`)",
        f"**Moderator:** {mod_str}",
        f"**Reason:** {reason_str}",
    ]
    if duration:
        lines.append(f"**Duration:** {duration}")
    lines.append(f"**When:** <t:{ts}:F> (<t:{ts}:R>)")
    if extra_fields:
        for label, value in extra_fields.items():
            lines.append(f"**{label}:** {value}")

    body = "\n".join(lines)
    title = f"{icon} Case #{case_number} — {action.title()}"

    return _wrap(_card_container(title, body, color))


def make_balance_card(
    user: discord.User | discord.Member,
    balance: int,
    currency: str = "credits",
    *,
    rank: int | None = None,
    max_balance: int | None = None,
    accent_color: discord.Color = _INFO,
) -> discord.ui.LayoutView:
    """Components V2 card for displaying a user's bank balance.

    Used by core/bank.py balance commands.

    Usage::

        view = make_balance_card(interaction.user, 1500, "coins", rank=3)
        await interaction.followup.send(view=view, ephemeral=True)
    """
    from utils.formatting import humanize_number

    lines = [
        f"**Balance:** `{humanize_number(balance)} {currency}`",
    ]
    if rank is not None:
        lines.append(f"**Rank:** #{rank}")
    if max_balance is not None:
        pct = min(100, int(balance / max_balance * 100)) if max_balance else 0
        bar_filled = pct // 10
        bar = "█" * bar_filled + "░" * (10 - bar_filled)
        lines.append(f"**Capacity:** `{bar}` {pct}%")

    body = "\n".join(lines)
    title = f"💰 {user.display_name}'s Balance"

    return _wrap(_card_container(title, body, accent_color))
