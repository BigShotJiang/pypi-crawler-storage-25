from __future__ import annotations

import re

_INVITE_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(?:discord(?:\.gg|\.com/invite|app\.com/invite)|"
    r"discordapp\.com/invite)/[a-zA-Z0-9\-]{2,32}",
    re.IGNORECASE,
)

_URL_RE = re.compile(
    r"https?://[^\s<>\"{}|\\^`\[\]]+",
    re.IGNORECASE,
)

_MASS_MENTION_RE = re.compile(r"@(?:everyone|here)", re.IGNORECASE)

_SPOILER_RE = re.compile(r"\|\|(.+?)\|\|", re.DOTALL)

_MENTION_RE = re.compile(r"<@[!&]?\d+>")

_CHANNEL_MENTION_RE = re.compile(r"<#\d+>")

_EMOJI_RE = re.compile(r"<a?:[a-zA-Z0-9_]+:\d+>")

_NEWLINE_RE = re.compile(r"\n+")


def filter_invites(text: str, replacement: str = "[invite removed]") -> str:
    """Replace Discord invite links with *replacement*."""
    return _INVITE_RE.sub(replacement, text)


def filter_urls(text: str, replacement: str = "[url removed]") -> str:
    """Replace all HTTP/HTTPS URLs with *replacement*."""
    return _URL_RE.sub(replacement, text)


def filter_mass_mentions(text: str, replacement: str = "@​") -> str:
    """Neutralise @everyone and @here by inserting a zero-width space."""
    return _MASS_MENTION_RE.sub(replacement, text)


def filter_user_mentions(text: str, replacement: str = "@user") -> str:
    """Replace ``<@id>`` / ``<@!id>`` with *replacement*."""
    return _MENTION_RE.sub(replacement, text)


def filter_role_mentions(text: str, replacement: str = "@role") -> str:
    """Replace ``<@&id>`` with *replacement*."""
    return re.sub(r"<@&\d+>", replacement, text)


def filter_channel_mentions(text: str, replacement: str = "#channel") -> str:
    """Replace ``<#id>`` with *replacement*."""
    return _CHANNEL_MENTION_RE.sub(replacement, text)


def escape_spoilers(text: str) -> str:
    """Escape ``||spoiler||`` tags so they render as plain text."""
    return _SPOILER_RE.sub(lambda m: m.group(1), text)


def escape_mentions(text: str) -> str:
    """Escape ALL Discord mention types — users, roles, channels, @everyone."""
    text = filter_mass_mentions(text)
    text = filter_user_mentions(text)
    text = filter_role_mentions(text)
    text = filter_channel_mentions(text)
    return text


def clean_content(
    text: str,
    *,
    fix_channel_mentions: bool = True,
    fix_user_mentions: bool = True,
    fix_role_mentions: bool = True,
    remove_mass_mentions: bool = True,
    remove_invites: bool = False,
    remove_urls: bool = False,
    max_length: int | None = None,
) -> str:
    """All-in-one content sanitiser.

    Args:
        text: Raw user input.
        fix_channel_mentions: Neutralise ``<#id>`` mentions.
        fix_user_mentions: Neutralise ``<@id>`` mentions.
        fix_role_mentions: Neutralise ``<@&id>`` mentions.
        remove_mass_mentions: Neutralise @everyone and @here.
        remove_invites: Remove invite links.
        remove_urls: Remove all URLs.
        max_length: Truncate to this length (appends …).

    Returns:
        Sanitised string.
    """
    if remove_invites:
        text = filter_invites(text)
    if remove_urls:
        text = filter_urls(text)
    if remove_mass_mentions:
        text = filter_mass_mentions(text)
    if fix_user_mentions:
        text = filter_user_mentions(text)
    if fix_role_mentions:
        text = filter_role_mentions(text)
    if fix_channel_mentions:
        text = filter_channel_mentions(text)
    if max_length and len(text) > max_length:
        text = text[: max_length - 1] + "…"
    return text


def normalize_whitespace(text: str) -> str:
    """Collapse runs of newlines to a single newline."""
    return _NEWLINE_RE.sub("\n", text).strip()
