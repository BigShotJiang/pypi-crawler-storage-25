from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable, Generator, Iterable, Iterator
from typing import (
    Any,
    TypeVar,
)

_T = TypeVar("_T")
_S = TypeVar("_S")


# ══════════════════════════════════════════════════════════════
# bounded_gather
# ══════════════════════════════════════════════════════════════


async def bounded_gather(
    *coros: Awaitable[_T],
    limit: int = 4,
    return_exceptions: bool = False,
) -> list[_T | BaseException]:
    """Run coroutines concurrently, at most *limit* at a time.

    Like ``asyncio.gather`` but with a semaphore so you don't hammer rate limits.

    Args:
        *coros: Coroutines to run.
        limit: Maximum concurrent coroutines (default 4).
        return_exceptions: If True, exceptions are returned as results instead
            of being raised. Same behaviour as asyncio.gather.

    Returns:
        List of results in the same order as *coros*.

    Example::

        results = await bounded_gather(
            *(send_dm(user) for user in users),
            limit=5,
            return_exceptions=True,
        )
    """
    sem = asyncio.Semaphore(limit)

    async def _wrap(coro: Awaitable[_T]) -> _T:
        async with sem:
            return await coro

    tasks = [asyncio.ensure_future(_wrap(c)) for c in coros]
    return await asyncio.gather(*tasks, return_exceptions=return_exceptions)


async def bounded_gather_iter(
    *coros: Awaitable[_T],
    limit: int = 4,
    return_exceptions: bool = False,
) -> AsyncIterator[_T | BaseException]:
    """Like ``bounded_gather`` but yields results as they complete."""
    sem = asyncio.Semaphore(limit)

    async def _wrap(coro: Awaitable[_T]) -> _T:
        async with sem:
            return await coro

    tasks = [asyncio.ensure_future(_wrap(c)) for c in coros]
    for future in asyncio.as_completed(tasks):
        try:
            yield await future
        except Exception as exc:
            if return_exceptions:
                yield exc
            else:
                raise


# ══════════════════════════════════════════════════════════════
# AsyncIter
# ══════════════════════════════════════════════════════════════


class AsyncIter(AsyncIterator[_T], Awaitable[list[_T]]):
    """Async iterator that yields items from a sync iterable, sleeping periodically
    to avoid blocking the event loop on large datasets.

    Args:
        iterable: Any sync iterable (list, tuple, dict, generator, etc.).
        steps: Yield control to the event loop every *steps* items (default 100).
        delay: Seconds to sleep every *steps* items (default 0 — just yields).

    Awaitable shortcut::

        # Collect all items into a list:
        items = await AsyncIter(my_list)

    Filter / map / enumerate::

        async for item in AsyncIter(items).filter(lambda x: x > 0):
            ...

        async for i, item in AsyncIter(items).enumerate(start=1):
            ...

        results = await AsyncIter(items).map(str)
        flat    = await AsyncIter(items).flatten()
    """

    def __init__(
        self,
        iterable: Iterable[_T],
        steps: int = 100,
        delay: float = 0.0,
    ):
        self._iter: Iterator[_T] = iter(iterable)
        self._steps = max(1, steps)
        self._delay = delay
        self._count = 0

    def __aiter__(self) -> AsyncIter[_T]:
        return self

    async def __anext__(self) -> _T:
        try:
            item = next(self._iter)
        except StopIteration:
            raise StopAsyncIteration from None

        self._count += 1
        if self._count % self._steps == 0:
            if self._delay:
                await asyncio.sleep(self._delay)
            else:
                await asyncio.sleep(0)

        return item

    def __await__(self) -> Generator[Any, None, list[_T]]:
        return self.flatten().__await__()

    def filter(self, predicate: Callable[[_T], bool]) -> _FilteredIter[_T]:
        """Return an AsyncIter that only yields items matching *predicate*."""
        return _FilteredIter(self, predicate)

    def map(self, func: Callable[[_T], _S]) -> _MappedIter[_S]:
        """Return an AsyncIter that applies *func* to every item."""
        return _MappedIter(self, func)

    def enumerate(self, start: int = 0) -> _EnumeratedIter[_T]:
        """Return an AsyncIter yielding (index, item) tuples."""
        return _EnumeratedIter(self, start)

    async def flatten(self) -> list[_T]:
        """Consume the iterator and return all items as a list."""
        return [item async for item in self]

    async def find(self, predicate: Callable[[_T], bool]) -> _T | None:
        """Return the first item matching *predicate*, or None."""
        async for item in self:
            if predicate(item):
                return item
        return None

    async def count(self) -> int:
        """Count total items."""
        n = 0
        async for _ in self:
            n += 1
        return n

    async def any(self, predicate: Callable[[_T], bool]) -> bool:
        """True if any item matches *predicate*."""
        async for item in self:
            if predicate(item):
                return True
        return False

    async def all(self, predicate: Callable[[_T], bool]) -> bool:
        """True if all items match *predicate*."""
        async for item in self:
            if not predicate(item):
                return False
        return True


class _FilteredIter(AsyncIter[_T]):
    def __init__(self, source: AsyncIter[_T], predicate: Callable[[_T], bool]):
        self._source = source
        self._predicate = predicate
        self._steps = source._steps
        self._delay = source._delay
        self._count = 0

    def __aiter__(self):
        return self

    async def __anext__(self) -> _T:
        async for item in self._source:
            if self._predicate(item):
                return item
        raise StopAsyncIteration


class _MappedIter(AsyncIter[_S]):
    def __init__(self, source: AsyncIter[_T], func: Callable[[_T], _S]):
        self._source = source
        self._func = func
        self._steps = source._steps
        self._delay = source._delay
        self._count = 0

    def __aiter__(self):
        return self

    async def __anext__(self) -> _S:
        item = await self._source.__anext__()
        return self._func(item)


class _EnumeratedIter(AsyncIter[tuple[int, _T]]):
    def __init__(self, source: AsyncIter[_T], start: int):
        self._source = source
        self._index = start
        self._steps = source._steps
        self._delay = source._delay
        self._count = 0

    def __aiter__(self):
        return self

    async def __anext__(self) -> tuple[int, _T]:
        item = await self._source.__anext__()
        idx = self._index
        self._index += 1
        return idx, item
