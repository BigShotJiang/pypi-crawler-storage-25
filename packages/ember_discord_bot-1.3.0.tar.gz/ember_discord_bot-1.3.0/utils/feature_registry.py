from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum, auto
from functools import wraps
from typing import Any


def _snake_case(name: str) -> str:
    """Convert CamelCase class name to snake_case."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    snake = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
    return snake.replace("_cog", "")


class FieldType(Enum):
    TEXT = auto()
    STRING = TEXT  # alias for TEXT
    INTEGER = auto()
    CHANNEL = auto()  # channel select (defaults to text channels)
    ROLE = auto()  # role select
    USER = auto()  # user/member select
    MENTIONABLE = auto()  # user or role select
    BOOLEAN = auto()  # inline toggle button
    LIST = auto()  # multi-select or list of values


@dataclass
class ConfigField:
    key: str
    label: str
    type: FieldType
    description: str = ""
    required: bool = False
    default: Any = None
    placeholder: str = ""
    max_length: int = 200
    min_value: int | None = None
    max_value: int | None = None
    # CHANNEL only: restrict which channel types appear in the select.
    # Empty list = text channels only (default). Pass e.g. [discord.ChannelType.category]
    # to override. Pass a magic sentinel list [None] to show all channel types.
    channel_types: list = field(default_factory=list)


@dataclass
class FeatureMeta:
    cog_name: str
    display_name: str
    description: str
    emoji: str = "⚙️"
    fields: list[ConfigField] = field(default_factory=list)


_registry: dict[str, FeatureMeta] = {}


def register(meta: FeatureMeta) -> None:
    _registry[meta.cog_name] = meta


def unregister(cog_name: str) -> None:
    _registry.pop(cog_name, None)


def all_features() -> list[FeatureMeta]:
    return sorted(_registry.values(), key=lambda m: m.display_name)


def get_feature(cog_name: str) -> FeatureMeta | None:
    return _registry.get(cog_name)


def feature(
    *,
    display_name: str,
    emoji: str,
    description: str = "",
    fields: list[ConfigField] | None = None,
) -> Any:
    """Decorator for automatic feature registration on cog load.

    Automatically:
    - Derives cog_name from class name
    - Registers feature on cog_load
    - Unregisters feature on cog_unload

    Example::

        @feature(
            display_name="Birthday Tracker",
            emoji="🎂",
            description="Announce member birthdays.",
            fields=[ConfigField(...), ...],
        )
        class BirthdayCog(EmberCog):
            pass  # Registration is automatic
    """

    def decorator(cog_class: type) -> type:
        cog_name = _snake_case(cog_class.__name__)
        meta = FeatureMeta(
            cog_name=cog_name,
            display_name=display_name,
            description=description,
            emoji=emoji,
            fields=fields or [],
        )
        cog_class._feature_meta = meta

        original_load = getattr(cog_class, "cog_load", None)

        @wraps(original_load or (lambda self: None))
        async def new_load(self: Any) -> None:
            register(meta)
            if original_load:
                return await original_load(self)

        original_unload = getattr(cog_class, "cog_unload", None)

        @wraps(original_unload or (lambda self: None))
        async def new_unload(self: Any) -> None:
            unregister(cog_name)
            if original_unload:
                return await original_unload(self)

        cog_class.cog_load = new_load
        cog_class.cog_unload = new_unload
        return cog_class

    return decorator
