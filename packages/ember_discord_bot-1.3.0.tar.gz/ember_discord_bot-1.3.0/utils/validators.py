from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

from core.errors import EmberError


class ValidationError(EmberError):
    """Raised when validation fails."""

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(f"**{field}**: {message}")


def validate_length(
    value: str, min_len: int = 0, max_len: int = 2000, field: str = "Input"
) -> None:
    """Validate string length.

    Raises:
        ValidationError: If length constraints not met.
    """
    length = len(value)
    if length < min_len:
        raise ValidationError(field, f"Must be at least {min_len} characters (got {length}).")
    if length > max_len:
        raise ValidationError(field, f"Must be at most {max_len} characters (got {length}).")


def validate_user_id(user_id: int, field: str = "User ID") -> None:
    """Validate that a user ID is a valid Discord snowflake."""
    if user_id <= 0:
        raise ValidationError(field, "Invalid user ID.")
    # Discord snowflakes are >= 18 digits (2^63) but we can just check positive non-zero


def validate_color_hex(hex_code: str, field: str = "Color") -> None:
    """Validate a hex color code."""
    if not isinstance(hex_code, str):
        raise ValidationError(field, "Color must be a string.")
    if not re.fullmatch(r"#?[0-9A-Fa-f]{6}", hex_code):
        raise ValidationError(field, "Color must be a hex code like #RRGGBB.")


def validate_url(url: str, field: str = "URL", schemes: list[str] | None = None) -> None:
    """Validate a URL string."""
    if schemes is None:
        schemes = ["http", "https"]
    # Simple check - can be extended with urllib.parse for strict validation
    if not url.startswith(tuple(f"{s}://" for s in schemes)):
        raise ValidationError(field, f"URL must start with one of: {', '.join(schemes)}://")


def validate_duration(duration: str, field: str = "Duration") -> None:
    """Validate duration string format (e.g., '10m', '1h30m')."""
    if not duration:
        raise ValidationError(field, "Duration cannot be empty.")
    if not re.fullmatch(r"(?:\d+[smhd] ?)+", duration.lower()):
        raise ValidationError(field, "Invalid duration format. Use e.g., '10m', '1h30m', '2d'.")


def validate_ratio(
    value: float, min_val: float = 0.0, max_val: float = 1.0, field: str = "Value"
) -> None:
    """Validate that a numeric value is within a range."""
    if not (min_val <= value <= max_val):
        raise ValidationError(field, f"Must be between {min_val} and {max_val} (got {value}).")


def sanitize_filename(filename: str) -> str:
    """Remove dangerous characters from a filename."""
    # Remove path separators and control characters
    return re.sub(r"[^\w\-_.]", "_", filename)
