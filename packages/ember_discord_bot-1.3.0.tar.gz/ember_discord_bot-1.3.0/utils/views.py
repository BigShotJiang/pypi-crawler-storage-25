import discord

from utils.cards import (
    ConfirmView,
    PaginatedView,
    SelectView,
    make_error_card,
    make_info_card,
    make_success_card,
    make_warning_card,
)


# Kept for code that imports EmberTheme from here
class EmberTheme:
    PRIMARY = discord.Color.from_str("#5865F2")
    SUCCESS = discord.Color.from_str("#57F287")
    ERROR = discord.Color.from_str("#ED4245")
    WARNING = discord.Color.from_str("#FEE75C")
    INFO = discord.Color.from_str("#5865F2")
    SECONDARY = discord.Color.from_str("#4f545c")

    @classmethod
    def get_color(cls, name: str) -> discord.Color:
        return getattr(cls, name.upper(), cls.PRIMARY)


__all__ = [
    "EmberTheme",
    "make_info_card",
    "make_success_card",
    "make_error_card",
    "make_warning_card",
    "ConfirmView",
    "PaginatedView",
    "SelectView",
]
