import logging
import sys


class ColoredFormatter(logging.Formatter):
    """Custom formatter that adds ANSI colors based on log level."""

    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[94m",  # Blue
        "INFO": "\033[92m",  # Green
        "WARNING": "\033[93m",  # Yellow
        "ERROR": "\033[91m",  # Red
        "CRITICAL": "\033[95m",  # Magenta
        "RESET": "\033[0m",
    }

    def __init__(
        self, fmt: str | None = None, datefmt: str | None = None, use_color: bool | None = None
    ) -> None:
        super().__init__(fmt, datefmt)
        # If use_color is explicitly True/False, use that; otherwise auto-detect
        if use_color is None:
            self.use_color = self._is_terminal()
        else:
            self.use_color = use_color

    @staticmethod
    def _is_terminal() -> bool:
        """Check if stdout is a terminal that supports colors."""
        return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with optional colors."""
        if self.use_color:
            levelname = record.levelname
            color = self.COLORS.get(levelname, self.COLORS["RESET"])
            record.levelname = f"{color}{levelname}{self.COLORS['RESET']}"
        return super().format(record)


def setup_colored_logging(logger: logging.Logger | None = None, level: int = logging.INFO) -> None:
    """Set up colored logging for a logger.

    Args:
        logger: Logger to configure. If None, configures the root logger.
        level: Logging level to use.
    """
    if logger is None:
        logger = logging.getLogger()

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)

    formatter = ColoredFormatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(level)


def format_colored(level: str, message: str, use_color: bool = True) -> str:
    """Format a message with color based on log level.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        message: Message to format
        use_color: Whether to apply colors

    Returns:
        Formatted message with optional ANSI colors.
    """
    if not use_color or not ColoredFormatter._is_terminal():
        return message

    colors = {
        "DEBUG": "\033[94m",
        "INFO": "\033[92m",
        "WARNING": "\033[93m",
        "ERROR": "\033[91m",
        "CRITICAL": "\033[95m",
    }
    color = colors.get(level.upper(), "\033[0m")
    return f"{color}{message}\033[0m"


# Quick access functions for common colors
def info(message: str) -> str:
    """Green text for info messages."""
    return format_colored("INFO", message)


def warning(message: str) -> str:
    """Yellow text for warning messages."""
    return format_colored("WARNING", message)


def error(message: str) -> str:
    """Red text for error messages."""
    return format_colored("ERROR", message)


def debug(message: str) -> str:
    """Blue text for debug messages."""
    return format_colored("DEBUG", message)
