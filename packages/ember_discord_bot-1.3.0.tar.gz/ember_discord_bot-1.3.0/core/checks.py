from __future__ import annotations

import enum
import logging
import os
from collections.abc import Callable
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.errors import InsufficientPermissionsError, NotConfiguredError, UserBannedError

log = logging.getLogger("ember.checks")


# ══════════════════════════════════════════════════════════════════
# Privilege levels
# ══════════════════════════════════════════════════════════════════


class PrivilegeLevel(enum.IntEnum):
    """Ordered privilege tiers (each implies all below it)."""

    NONE = 0
    MOD = 10
    ADMIN = 20
    GUILD_OWNER = 30
    BOT_OWNER = 40


# ══════════════════════════════════════════════════════════════════
# Internal helpers
# ══════════════════════════════════════════════════════════════════


def _static_owner_ids() -> set[int]:
    raw = os.getenv("OWNER_IDS", os.getenv("MOD_IDS", ""))
    return {int(x) for x in raw.split(",") if x.strip().isdigit()}


def _has_mod_perms(p: discord.Permissions) -> bool:
    return any(
        [
            p.manage_messages,
            p.manage_guild,
            p.kick_members,
            p.ban_members,
            p.moderate_members,
            p.manage_roles,
        ]
    )


def _perm_label(**perms: bool) -> str:
    return ", ".join(k.replace("_", " ").title() for k, v in perms.items() if v)


def _denied(msg: str) -> None:
    """Raise the correct error type for cog_app_command_error to catch."""
    raise app_commands.CheckFailure(str(InsufficientPermissionsError(msg)))


# ══════════════════════════════════════════════════════════════════
# Async inline predicates  (await checks.check_is_mod(interaction))
# ══════════════════════════════════════════════════════════════════


async def check_is_owner(interaction: discord.Interaction) -> bool:
    """True if user is the bot owner, a team member, or in OWNER_IDS."""
    if interaction.user.id in _static_owner_ids():
        return True
    try:
        app = await interaction.client.application_info()
        if app.team:
            return interaction.user.id in {m.id for m in app.team.members}
        return interaction.user.id == app.owner.id
    except Exception:
        return False


async def check_is_guild_owner(interaction: discord.Interaction) -> bool:
    """True if user is the guild owner or bot owner."""
    if not interaction.guild:
        return False
    return interaction.user.id == interaction.guild.owner_id or await check_is_owner(interaction)


async def check_is_admin(interaction: discord.Interaction) -> bool:
    """True if user has Administrator, is guild owner, or is bot owner."""
    if not isinstance(interaction.user, discord.Member):
        return False
    return interaction.user.guild_permissions.administrator or await check_is_guild_owner(
        interaction
    )


async def check_is_mod(interaction: discord.Interaction) -> bool:
    """True if user has any mod permission or is admin."""
    if not isinstance(interaction.user, discord.Member):
        return False
    return _has_mod_perms(interaction.user.guild_permissions) or await check_is_admin(interaction)


async def check_has_permissions(interaction: discord.Interaction, **perms: bool) -> bool:
    """True if user has ALL the given guild permissions (owners always pass)."""
    if await check_is_owner(interaction):
        return True
    if not isinstance(interaction.user, discord.Member):
        return False
    p = interaction.user.guild_permissions
    return all(getattr(p, name, False) == val for name, val in perms.items())


async def check_bot_has_permissions(interaction: discord.Interaction, **perms: bool) -> bool:
    """True if the bot has ALL the given permissions in the current channel."""
    if not interaction.guild:
        return False
    me = interaction.guild.me
    if not me:
        return False
    p = interaction.channel.permissions_for(me)
    return all(getattr(p, name, False) == val for name, val in perms.items())


# Prefix-command equivalents
async def ctx_is_owner(ctx: commands.Context) -> bool:
    return await ctx.bot.is_owner(ctx.author)


async def ctx_is_guild_owner(ctx: commands.Context) -> bool:
    return (ctx.guild and ctx.author == ctx.guild.owner) or await ctx_is_owner(ctx)


async def ctx_is_admin(ctx: commands.Context) -> bool:
    if isinstance(ctx.author, discord.Member) and ctx.author.guild_permissions.administrator:
        return True
    return await ctx_is_guild_owner(ctx)


async def ctx_is_mod(ctx: commands.Context) -> bool:
    if isinstance(ctx.author, discord.Member) and _has_mod_perms(ctx.author.guild_permissions):
        return True
    return await ctx_is_admin(ctx)


# ══════════════════════════════════════════════════════════════════
# Core decorator factory
# ══════════════════════════════════════════════════════════════


def _make_check(
    level_pred: Callable[[discord.Interaction], Any],
    extra_perms: dict[str, bool],
    denied_label: str,
) -> Callable[[], app_commands.Check]:
    """Build an app_commands.check that passes if level OR extra_perms is satisfied."""

    async def predicate(interaction: discord.Interaction) -> bool:
        if await level_pred(interaction):
            return True
        if extra_perms and await check_has_permissions(interaction, **extra_perms):
            return True
        _denied(denied_label)
        return False

    return app_commands.check(predicate)


# ══════════════════════════════════════════════════════════════════
# Hierarchy checks
# ══════════════════════════════════════════════════════════════════


def is_owner() -> Callable:
    """Bot owner only. Cannot be bypassed by any permission override."""

    async def predicate(interaction: discord.Interaction) -> bool:
        if await check_is_owner(interaction):
            return True
        _denied("Bot Owner")
        return False

    return app_commands.check(predicate)


def guild_owner() -> Callable:
    """Guild owner or bot owner."""
    return guild_owner_or_permissions()


def guild_owner_or_permissions(**perms: bool) -> Callable:
    """Guild owner, bot owner, or user has ALL of *perms*."""
    label = _perm_label(**perms) or "Server Owner"
    return _make_check(check_is_guild_owner, perms, label)


def admin() -> Callable:
    """Administrator permission or higher."""
    return admin_or_permissions()


def admin_or_permissions(**perms: bool) -> Callable:
    """Admin-level privilege or user has ALL of *perms*."""
    label = _perm_label(**perms) or "Administrator"
    return _make_check(check_is_admin, perms, label)


def mod() -> Callable:
    """Mod-level privilege or higher."""
    return mod_or_permissions()


def mod_or_permissions(**perms: bool) -> Callable:
    """Mod-level privilege or user has ALL of *perms*."""
    label = _perm_label(**perms) or "Moderator"
    return _make_check(check_is_mod, perms, label)


# ══════════════════════════════════════════════════════════════════
# Discord permission checks
# ══════════════════════════════════════════════════════════════════


def has_permissions(**perms: bool) -> Callable:
    """User must have ALL of the given guild permissions (owners always pass).

    Usage::

        @checks.has_permissions(ban_members=True)
        @checks.has_permissions(manage_roles=True, manage_channels=True)
    """
    label = _perm_label(**perms)

    async def predicate(interaction: discord.Interaction) -> bool:
        if await check_has_permissions(interaction, **perms):
            return True
        _denied(label)
        return False

    return app_commands.check(predicate)


def bot_has_permissions(**perms: bool) -> Callable:
    """Bot must have ALL of the given permissions in the current channel.

    This check cannot be bypassed. If the bot lacks the permission,
    a clear error message is sent.

    Usage::

        @checks.bot_has_permissions(embed_links=True, attach_files=True)
    """
    label = _perm_label(**perms)

    async def predicate(interaction: discord.Interaction) -> bool:
        if await check_bot_has_permissions(interaction, **perms):
            return True
        raise app_commands.CheckFailure(
            f"I'm missing the **{label}** permission(s) required for this command."
        )

    return app_commands.check(predicate)


def bot_in_a_guild() -> Callable:
    """Bot must be in at least one guild (sanity check for DM-capable bots)."""

    async def predicate(interaction: discord.Interaction) -> bool:
        return len(interaction.client.guilds) > 0

    return app_commands.check(predicate)


def bot_can_manage_channel() -> Callable:
    """Bot must have Manage Channels in the current channel."""
    return bot_has_permissions(manage_channels=True)


def bot_can_react() -> Callable:
    """Bot must have Add Reactions in the current channel."""
    return bot_has_permissions(add_reactions=True)


def bot_can_embed() -> Callable:
    """Bot must have Embed Links in the current channel."""
    return bot_has_permissions(embed_links=True)


# ══════════════════════════════════════════════════════════════════
# Discord permission aliases  (high-level API)
# ══════════════════════════════════════════════════════════════


def manage_guild() -> Callable:
    """User must have the Manage Server permission (or be bot/guild owner)."""
    return has_permissions(manage_guild=True)


def manage_channels() -> Callable:
    """User must have the Manage Channels permission."""
    return has_permissions(manage_channels=True)


def manage_roles() -> Callable:
    """User must have the Manage Roles permission."""
    return has_permissions(manage_roles=True)


def manage_messages() -> Callable:
    """User must have the Manage Messages permission."""
    return has_permissions(manage_messages=True)


# ══════════════════════════════════════════════════════════════════
# Context guards
# ══════════════════════════════════════════════════════════════════


def guild_only() -> Callable:
    """Command may only be used inside a server (blocks DMs)."""

    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.guild:
            return True
        raise app_commands.NoPrivateMessage("This command can only be used in a server.")

    return app_commands.check(predicate)


def dm_only() -> Callable:
    """Command may only be used in DMs."""

    async def predicate(interaction: discord.Interaction) -> bool:
        if not interaction.guild:
            return True
        raise app_commands.CheckFailure("This command can only be used in DMs.")

    return app_commands.check(predicate)


def in_voice() -> Callable:
    """User must be connected to a voice channel."""

    async def predicate(interaction: discord.Interaction) -> bool:
        m = interaction.user
        if isinstance(m, discord.Member) and m.voice and m.voice.channel:
            return True
        raise app_commands.CheckFailure("You need to be in a voice channel to use this.")

    return app_commands.check(predicate)


def same_voice() -> Callable:
    """User and bot must be in the same voice channel."""

    async def predicate(interaction: discord.Interaction) -> bool:
        m = interaction.user
        if not isinstance(m, discord.Member):
            raise app_commands.NoPrivateMessage()
        bot_vc = interaction.guild.me.voice.channel if interaction.guild.me.voice else None
        user_vc = m.voice.channel if m.voice else None
        if bot_vc and user_vc and bot_vc == user_vc:
            return True
        raise app_commands.CheckFailure("You must be in the same voice channel as me.")

    return app_commands.check(predicate)


# ══════════════════════════════════════════════════════════════════
# Ember cog-requirement checks
# ══════════════════════════════════════════════════════════════════


def cog_is_configured(cog_name: str, *required_keys: str) -> Callable:
    """Ensure the guild has configured all required settings before the command runs.

    Replaces the boilerplate every command used to repeat::

        channel_id = await config.get(guild.id, "channel_id")
        if not channel_id:
            raise NotConfiguredError("channel_id")

    Now just decorate the command::

        @checks.cog_is_configured("welcome", "channel_id", "message")
        async def preview(self, interaction): ...

    Admins can still run the command even if it's not configured (so they can
    set it up via the settings panel), unless *admin_bypass=False* is passed.
    """

    async def predicate(interaction: discord.Interaction) -> bool:
        if not interaction.guild:
            raise app_commands.NoPrivateMessage()

        # Admins can always run unconfigured commands so they can set things up
        if await check_is_admin(interaction):
            return True

        from core.store import get_cog_store

        store = get_cog_store(cog_name)
        if store is None:
            raise app_commands.CheckFailure(f"Configuration for `{cog_name}` not found.")

        missing = []
        for key in required_keys:
            val = await store.get("guild", interaction.guild.id, key)
            if not val:
                missing.append(key)

        if not missing:
            return True

        missing_str = ", ".join(f"`{k}`" for k in missing)
        raise app_commands.CheckFailure(str(NotConfiguredError(missing_str)))

    return app_commands.check(predicate)


def is_booster() -> Callable:
    """User must be a Nitro server booster in this guild."""

    async def predicate(interaction: discord.Interaction) -> bool:
        m = interaction.user
        if isinstance(m, discord.Member) and m.premium_since is not None:
            return True
        raise app_commands.CheckFailure("You need to be a server booster to use this feature.")

    return app_commands.check(predicate)


def is_vc_owner() -> Callable:
    """User must own their TempVC channel. Mods automatically bypass.

    Looks up ownership in the tempvc database, so it works even if the
    user was transferred ownership via the control panel.
    """

    async def predicate(interaction: discord.Interaction) -> bool:
        if await check_is_mod(interaction):
            return True
        m = interaction.user
        if not isinstance(m, discord.Member) or not m.voice:
            raise app_commands.CheckFailure("You need to be in a voice channel.")
        vc = m.voice.channel
        try:
            from cogs.tempvc.database import get_db

            db = await get_db("tempvc")
            row = await db.get("voiceChannel", "voiceID = ?", (vc.id,))
            if row and row["userID"] == m.id:
                return True
        except Exception:
            pass
        raise app_commands.CheckFailure("You don't own this voice channel.")

    return app_commands.check(predicate)


def not_banned(db_fn: Callable[[int], Any]) -> Callable:
    """User must not be banned from this feature.

    Pass any async callable that takes ``user_id: int`` and returns ``bool``.

    Usage::

        @checks.not_banned(lambda uid: db.is_user_banned(uid))
        async def create_role(self, interaction): ...
    """

    async def predicate(interaction: discord.Interaction) -> bool:
        try:
            if await db_fn(interaction.user.id):
                raise app_commands.CheckFailure(str(UserBannedError(interaction.user.id)))
        except app_commands.CheckFailure:
            raise
        except Exception:
            pass
        return True

    return app_commands.check(predicate)


def feature_enabled(cog_name: str) -> Callable:
    """Guild must have this feature enabled in Config.

    Cogs that support per-guild enable/disable can use this to block commands
    on guilds where the feature is turned off::

        @checks.feature_enabled("birthday")
        async def birthday_set(self, interaction): ...
    """

    async def predicate(interaction: discord.Interaction) -> bool:
        if not interaction.guild:
            raise app_commands.NoPrivateMessage()
        if await check_is_admin(interaction):
            return True  # admins can always run to re-enable

        from core.store import get_cog_store

        store = get_cog_store(cog_name)
        if store is None:
            raise app_commands.CheckFailure(f"Configuration for `{cog_name}` not found.")
        enabled = await store.get("guild", interaction.guild.id, "enabled")
        if enabled is None:
            enabled = True  # default if not set
        if enabled:
            return True
        raise app_commands.CheckFailure(
            f"The **{cog_name.replace('_', ' ').title()}** feature is disabled on this server."
        )

    return app_commands.check(predicate)


# ══════════════════════════════════════════════════════════════════
# Prefix-command equivalents  (check_*)
# ══════════════════════════════════════════════════════════════


def check_guild_owner() -> Callable[[commands.Context], bool]:
    return commands.check(ctx_is_guild_owner)


def check_admin() -> Callable[[commands.Context], bool]:
    return commands.check(ctx_is_admin)


def check_mod() -> Callable[[commands.Context], bool]:
    return commands.check(ctx_is_mod)
