from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from aiohttp import web

try:
    from aiohttp_json_rpc import JsonRpc
    from aiohttp_json_rpc.rpc import JsonRpcMethod

    _HAS_JSON_RPC = True
except ImportError:
    _HAS_JSON_RPC = False
    JsonRpc = object  # type: ignore[assignment]

if TYPE_CHECKING:
    from collections.abc import Awaitable
    from typing import Protocol

    class RpcMethod(Protocol):
        """Protocol for RPC methods."""

        async def __call__(self, request: Any) -> Any: ...


log = logging.getLogger("ember.rpc")

__all__ = ("RPC", "RPCMixin", "get_rpc_method_name")


def get_rpc_method_name(func: Callable[..., Any], prefix: str = "") -> str:
    """Return ``COGNAME__METHODNAME`` for *func*, uppercased."""
    class_name = prefix or func.__self__.__class__.__name__.lower()  # type: ignore[attr-defined,unused-ignore]
    func_name = func.__name__.strip("_")
    if class_name == "emberrpc":
        return func_name.upper()
    return f"{class_name}__{func_name}".upper()


class _EmberRpc(JsonRpc):
    methods: dict[str, JsonRpcMethod]

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.add_methods(("", self.list_methods))
        self.add_methods(("", self.method_info))

    def _add_method(self, method: Callable[..., Any], name: str = "", prefix: str = "") -> None:
        if not asyncio.iscoroutinefunction(method):
            return
        name = name or get_rpc_method_name(method, prefix)
        self.methods[name] = JsonRpcMethod(method)

    def remove_method(self, method: Callable[..., Any]) -> None:
        name = get_rpc_method_name(method)
        self.methods = {k: v for k, v in self.methods.items() if k != name}

    def remove_methods(self, prefix: str) -> None:
        prefix_upper = prefix.upper()
        self.methods = {
            k: v
            for k, v in self.methods.items()
            if not (len(k.split("__")) >= 2 and k.split("__")[0] == prefix_upper)
        }

    async def list_methods(self, request: Any) -> list[str]:
        """Return all registered RPC method names."""
        return sorted(self.methods.keys())

    async def method_info(self, request: Any) -> str:
        """Return the docstring for a method. Params: [method_name]"""
        name = request.params[0] if request.params else ""
        meth = self.methods.get(name)
        return meth.__doc__ or "No docstring." if meth else f"Unknown method: {name!r}"


def _make_auth_middleware(secret: str) -> web.Middleware:
    @web.middleware
    async def _auth(request: web.Request, handler: Callable[[web.Request], Awaitable[Any]]) -> Any:
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer ") or auth[7:] != secret:
            raise web.HTTPUnauthorized(reason="Invalid or missing RPC secret")
        return await handler(request)

    return _auth


class RPC:
    """Manages the aiohttp JSON-RPC server lifecycle."""

    def __init__(self) -> None:
        self._site: web.TCPSite | None = None
        self._runner: web.AppRunner | None = None
        self._rpc: _EmberRpc | None = None
        self.app: web.Application | None = None
        self._started = False

    async def _setup(self, secret: str | None = None) -> None:
        """Wire up aiohttp app + RPC handler. Called before ``initialize()``."""
        if not _HAS_JSON_RPC:
            raise ImportError(
                "aiohttp-json-rpc is required for RPC. "
                "Install with: pip install aiohttp-json-rpc"
            )
        middlewares: list[web.Middleware] = [_make_auth_middleware(secret)] if secret else []
        self.app = web.Application(middlewares=middlewares)
        self._rpc = _EmberRpc()
        self.app.router.add_route("*", "/", self._rpc.handle_request)
        self._runner = web.AppRunner(self.app)

    async def initialize(self, port: int, host: str = "127.0.0.1") -> None:
        """Start the TCP listener."""
        assert self._runner is not None, "Call _setup() first"
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, host=host, port=port, shutdown_timeout=120)
        await self._site.start()
        self._started = True
        log.info("RPC listening on %s:%d", host, port)

    async def close(self) -> None:
        if self._started and self.app is not None and self._runner is not None:
            await self.app.shutdown()
            await self._runner.cleanup()
            self._started = False

    def add_method(self, method: Callable[..., Any], prefix: str | None = None) -> None:
        if not asyncio.iscoroutinefunction(method):
            raise TypeError("RPC methods must be coroutines.")
        if self._rpc is None:
            raise RuntimeError("RPC not set up — call _setup() first.")
        if prefix is None:
            prefix = method.__self__.__class__.__name__.lower()  # type: ignore[attr-defined]
        self._rpc.add_methods((prefix, method))

    def remove_method(self, method: Callable[..., Any]) -> None:
        if self._rpc is not None:
            self._rpc.remove_method(method)

    def remove_methods(self, prefix: str) -> None:
        if self._rpc is not None:
            self._rpc.remove_methods(prefix)


class RPCMixin:
    """Mixin for :class:`EmberBot` that wires in the JSON-RPC server.

    Inheriting from this gives the bot:

    * ``self.rpc`` — the :class:`RPC` instance (always present, server only
      starts when ``EMBER_RPC_ENABLED=true``)
    * ``self.rpc_handlers`` — dict of uppercase cog name → list of registered methods
    * ``register_rpc_handler(method)`` / ``unregister_rpc_handler(method)``
    * ``rpc_start()`` — call from ``setup_hook()``
    * ``_rpc_cog_unload(cog)`` — call from ``on_cog_unload()``
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.rpc: RPC = RPC()
        self.rpc_handlers: dict[str, list[Callable[..., Any]]] = {}

    async def rpc_start(self) -> None:
        """Start the RPC server if ``EMBER_RPC_ENABLED=true``.

        Call this from ``setup_hook()`` after other services are ready so that
        built-in introspection methods have a live bot reference.
        """
        if os.environ.get("EMBER_RPC_ENABLED", "").lower() != "true":
            return
        try:
            port = int(os.environ.get("EMBER_RPC_PORT", "6133"))
            host = os.environ.get("EMBER_RPC_HOST", "127.0.0.1")
            secret = os.environ.get("EMBER_RPC_SECRET") or None
            await self.rpc._setup(secret=secret)
            # Register built-in bot introspection methods
            await self._rpc_register_builtins()
            await self.rpc.initialize(port=port, host=host)
            if secret:
                log.info("RPC auth enabled (Bearer token)")
        except Exception as exc:
            log.error("RPC start failed: %s", exc)

    async def _rpc_register_builtins(self) -> None:
        """Register bot-level introspection methods on the RPC server."""
        bot = self  # type: ignore[assignment]

        async def get_status(request: Any) -> dict[str, Any]:
            """Return bot status: guilds, users, latency, uptime, shard info."""
            return {
                "guilds": len(bot.guilds),
                "users": sum(g.member_count or 0 for g in bot.guilds),
                "latency_ms": round(bot.latency * 1000, 1),
                "uptime": bot.uptime if hasattr(bot, "uptime") else None,
                "shard_count": bot.shard_count,
                "shard_id": bot.shard_id,
                "user": str(bot.user) if bot.user else None,
            }

        async def get_guilds(request: Any) -> list[dict[str, Any]]:
            """Return list of guilds: id, name, member_count."""
            return [
                {"id": str(g.id), "name": g.name, "members": g.member_count} for g in bot.guilds
            ]

        async def get_cogs(request: Any) -> list[str]:
            """Return list of loaded extension module names."""
            return sorted(bot.extensions.keys())

        async def reload_cog(request: Any) -> dict[str, Any]:
            """Reload an extension by module name. Params: [module_name]"""
            name = request.params[0] if request.params else ""
            if not name:
                return {"error": "No module name provided"}
            try:
                await bot.reload_extension(name)
                return {"ok": True, "module": name}
            except Exception as exc:
                return {"ok": False, "error": str(exc)}

        async def get_commands(request: Any) -> list[str]:
            """Return all slash command names."""
            return [c.qualified_name for c in bot.tree.walk_commands()]

        # Register under the "bot" prefix so names become BOT__GET_STATUS etc.
        for fn in (get_status, get_guilds, get_cogs, reload_cog, get_commands):
            self.rpc.add_method(fn, prefix="bot")

    def register_rpc_handler(self, method: Callable[..., Any]) -> None:
        """Register *method* as an RPC endpoint (``COGNAME__METHODNAME``).

        Call from ``cog_load()``.  The method must be a coroutine.
        """
        self.rpc.add_method(method)
        cog_name = method.__self__.__class__.__name__.upper()  # type: ignore[attr-defined]
        self.rpc_handlers.setdefault(cog_name, []).append(method)

    def unregister_rpc_handler(self, method: Callable[..., Any]) -> None:
        """Deregister *method* from the RPC server.  Safe if not registered."""
        self.rpc.remove_method(method)
        name = get_rpc_method_name(method)
        cog_name = name.split("__")[0]
        if cog_name in self.rpc_handlers:
            try:
                self.rpc_handlers[cog_name].remove(method)
            except ValueError:
                pass

    async def _rpc_cog_unload(self, cog: Any) -> None:
        """Unregister all RPC handlers for *cog* when it is unloaded."""
        cog_name = type(cog).__name__.upper()
        for method in list(self.rpc_handlers.get(cog_name, [])):
            try:
                self.rpc.remove_method(method)
            except Exception:
                pass
        self.rpc_handlers.pop(cog_name, None)
