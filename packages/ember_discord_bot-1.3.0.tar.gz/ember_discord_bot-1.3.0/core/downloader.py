from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import discord

from core.store import Store

logger = logging.getLogger("ember.downloader")

_STORE_IDENTIFIER = 0x646F776E6C6F61  # "downloa" in hex
_LIB_BASE = Path("data/cogs")  # per-cog lib lives at data/cogs/<name>/lib/


@dataclass
class CogManifest:
    """Parsed info.json at the root of a cog repo.

    All fields are optional; a missing info.json silently returns defaults.
    """

    name: str = ""
    description: str = ""
    short: str = ""
    author: list[str] = field(default_factory=list)
    required_cogs: list[str] = field(default_factory=list)
    requirements: list[str] = field(default_factory=list)
    min_python: str = ""
    min_bot_version: str = ""
    max_bot_version: str = ""
    hidden: bool = False

    @classmethod
    def load(cls, repo_path: Path) -> CogManifest:
        info_file = repo_path / "info.json"
        if not info_file.exists():
            return cls()
        try:
            data = json.loads(info_file.read_text(encoding="utf-8"))
            return cls(
                name=data.get("name", ""),
                description=data.get("description", ""),
                short=data.get("short", ""),
                author=data.get("author", []),
                required_cogs=data.get("required_cogs", []),
                requirements=data.get("requirements", []),
                min_python=data.get("min_python", ""),
                min_bot_version=data.get("min_bot_version", ""),
                max_bot_version=data.get("max_bot_version", ""),
                hidden=data.get("hidden", False),
            )
        except Exception as exc:
            logger.warning("Failed to parse info.json in %s: %s", repo_path, exc)
            return cls()

    def check_compatibility(self, bot_version: str) -> tuple[bool, str]:
        """Return (ok, reason) — False if this cog is incompatible."""
        if self.hidden:
            return False, "Cog is marked hidden and not intended for direct installation."
        if self.min_bot_version and bot_version:
            try:
                from packaging.version import Version

                if Version(bot_version) < Version(self.min_bot_version):
                    return False, f"Requires bot ≥ {self.min_bot_version} (you have {bot_version})."
            except Exception:
                pass
        if self.max_bot_version and bot_version:
            try:
                from packaging.version import Version

                if Version(bot_version) > Version(self.max_bot_version):
                    return False, f"Requires bot ≤ {self.max_bot_version} (you have {bot_version})."
            except Exception:
                pass
        return True, ""


@dataclass
class InstalledRepo:
    name: str
    repo_url: str
    branch: str = "main"
    commit: str = ""
    pinned_commit: str = ""  # non-empty → locked; update() refuses
    path: Path = field(default_factory=Path)
    locked_versions: dict[str, str] = field(default_factory=dict)

    @property
    def is_pinned(self) -> bool:
        return bool(self.pinned_commit)

    @property
    def short_commit(self) -> str:
        return (
            (self.pinned_commit or self.commit)[:8]
            if (self.pinned_commit or self.commit)
            else "unknown"
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "repo_url": self.repo_url,
            "branch": self.branch,
            "commit": self.commit,
            "pinned_commit": self.pinned_commit,
            "path": str(self.path),
            "locked_versions": self.locked_versions,
        }

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> InstalledRepo:
        return cls(
            name=name,
            repo_url=data["repo_url"],
            branch=data.get("branch", "main"),
            commit=data.get("commit", ""),
            pinned_commit=data.get("pinned_commit", ""),
            path=Path(data.get("path", f"data/cog_repos/{name}")),
            locked_versions=data.get("locked_versions", {}),
        )


class CogDownloader:
    """Manages cog repositories: install, update, pin, uninstall, hot-reload."""

    BASE_PATH = Path("data/cog_repos")

    def __init__(self, bot: discord.Client) -> None:
        self.bot = bot
        self._repos: dict[str, InstalledRepo] = {}
        self._watcher_task: asyncio.Task[Any] | None = None
        self.BASE_PATH.mkdir(parents=True, exist_ok=True)

    @property
    def _db(self) -> Store:
        return Store.for_cog(self, _STORE_IDENTIFIER)

    async def initialize(self) -> None:
        await self._db.initialize()
        raw: dict[str, Any] = await self._db.get("global", "0", "installed_repos", default={})
        for name, data in raw.items():
            repo = InstalledRepo.from_dict(name, data)
            self._repos[name] = repo
            # Re-register each cog's lib path so imports work after restart
            self._add_lib_to_syspath(name)
        logger.info("CogDownloader: %d repos loaded", len(self._repos))

        if os.getenv("EMBER_HOT_RELOAD", "").lower() == "true":
            interval = int(os.getenv("EMBER_HOT_RELOAD_INTERVAL", "30"))
            self._watcher_task = asyncio.create_task(
                self._hot_reload_loop(interval), name="ember-hot-reload"
            )
            logger.info("Hot-reload watcher started (interval=%ds)", interval)

    async def shutdown(self) -> None:
        if self._watcher_task and not self._watcher_task.done():
            self._watcher_task.cancel()
            try:
                await self._watcher_task
            except asyncio.CancelledError:
                pass

    async def install(
        self,
        git_url: str,
        name: str | None = None,
        branch: str = "main",
        pin: str = "",
    ) -> tuple[bool, str]:
        """Clone a repo and load the cog.

        Args:
            git_url: Remote git URL.
            name:    Override the repo name (derived from URL by default).
            branch:  Branch to clone.
            pin:     Commit hash to pin to. Requires full history clone.
        """
        if name is None:
            name = self._repo_name_from_url(git_url)
        if not name:
            return False, "Could not determine a cog name from that URL."
        if name in self._repos:
            return False, f"`{name}` is already installed."

        repo_path = self.BASE_PATH / name
        cog_link = Path("cogs") / name

        try:
            if repo_path.exists():
                shutil.rmtree(repo_path, ignore_errors=True)
            cog_link.unlink(missing_ok=True)

            # Full clone when pinning to allow arbitrary commit checkout
            ok, err = await self._git_clone(git_url, repo_path, branch, shallow=not bool(pin))
            if not ok:
                return False, f"Git clone failed: {err}"

            if pin:
                ok, err = await self._git_checkout(repo_path, pin)
                if not ok:
                    shutil.rmtree(repo_path, ignore_errors=True)
                    return False, f"Checkout of `{pin[:8]}` failed: {err}"

            commit = await self._git_head(repo_path)
            manifest = CogManifest.load(repo_path)

            # info.json version compatibility check
            bot_ver = _bot_version()
            compat_ok, compat_err = manifest.check_compatibility(bot_ver)
            if not compat_ok:
                shutil.rmtree(repo_path, ignore_errors=True)
                return False, f"Incompatible cog: {compat_err}"

            cog_link.symlink_to(repo_path.resolve(), target_is_directory=True)

            repo = InstalledRepo(
                name=name,
                repo_url=git_url,
                branch=branch,
                commit=commit,
                pinned_commit=commit if pin else "",
                path=repo_path,
            )
            self._repos[name] = repo
            await self._persist()

            locked = await self._install_requirements(name, repo_path)
            repo.locked_versions = locked
            await self._persist()

            conflicts = await self._check_dependency_conflicts()
            if conflicts:
                logger.warning("Dependency conflicts after installing %s:\n%s", name, conflicts)

            # Subprocess import check before loading — rolls back on failure
            import_ok, import_err = await self._post_install_check(name)
            if not import_ok:
                logger.warning("Post-install import check failed for %s: %s", name, import_err)
                shutil.rmtree(repo_path, ignore_errors=True)
                cog_link.unlink(missing_ok=True)
                del self._repos[name]
                await self._persist()
                return False, f"Import check failed (install rolled back):\n{import_err}"

            loaded, load_err = await self._load_cog(name)
            if not loaded:
                return True, f"Installed `{name}` but failed to load: {load_err}"

            pin_note = f" (pinned @ `{commit[:8]}`)" if pin else ""
            suffix = f"\n⚠ Dependency conflicts:\n{conflicts}" if conflicts else ""
            desc = manifest.description or manifest.short or ""
            return (
                True,
                f"Installed and loaded `{name}` @ `{commit[:8]}`{pin_note}."
                + (f"\n{desc}" if desc else "")
                + suffix,
            )
        except Exception:
            logger.exception("Install failed for %s", name)
            shutil.rmtree(repo_path, ignore_errors=True)
            cog_link.unlink(missing_ok=True)
            self._repos.pop(name, None)
            return False, "Unexpected error during install — see logs."

    async def update(self, name: str) -> tuple[bool, str]:
        """Pull latest commits and hot-reload the cog.

        Refuses if the repo is pinned; use ``unpin()`` first.
        Returns the git commit log between old and new HEAD as update notes.
        """
        if name not in self._repos:
            return False, f"`{name}` is not installed."
        repo = self._repos[name]

        if repo.is_pinned:
            return (
                False,
                f"`{name}` is pinned @ `{repo.pinned_commit[:8]}`. "
                f"Run `unpin {name}` before updating.",
            )

        old_commit = repo.commit
        try:
            ok, err = await self._git_pull(repo.path, repo.branch)
            if not ok:
                return False, f"Git pull failed: {err}"

            new_commit = await self._git_head(repo.path)
            if new_commit == old_commit:
                return True, f"`{name}` is already up to date (`{old_commit[:8]}`)."

            # Which modules changed?
            changed = await self._changed_modules(repo.path, old_commit, new_commit)
            changed_summary = (
                f" ({len(changed)} file(s) changed)" if changed else " (no .py changes)"
            )

            # Collect commit messages as update notes
            notes = await self._git_log(repo.path, old_commit, new_commit)

            repo.commit = new_commit
            locked = await self._install_requirements(name, repo.path)
            repo.locked_versions = locked
            await self._persist()

            conflicts = await self._check_dependency_conflicts()
            if conflicts:
                logger.warning("Dependency conflicts after updating %s:\n%s", name, conflicts)

            if changed:
                await self._reload_cog(name)
            else:
                logger.info("No .py files changed in %s — skipping reload.", name)

            lines = [f"Updated `{name}`: `{old_commit[:8]}` → `{new_commit[:8]}`{changed_summary}."]
            if notes:
                lines.append("**What changed:**")
                lines.extend(f"• {note}" for note in notes[:10])  # cap at 10 lines
                if len(notes) > 10:
                    lines.append(f"… and {len(notes) - 10} more commit(s).")
            if conflicts:
                lines.append(f"⚠ Dependency conflicts:\n{conflicts}")

            return True, "\n".join(lines)
        except Exception:
            logger.exception("Update failed for %s", name)
            return False, "Unexpected error during update — see logs."

    async def pin(self, name: str, commit: str = "") -> tuple[bool, str]:
        """Pin a repo to a specific commit (or to its current HEAD if commit='').

        When pinned, ``update()`` will refuse until ``unpin()`` is called.
        Pinning to an older commit requires full history — the repo will be
        re-cloned without ``--depth 1`` if needed.
        """
        if name not in self._repos:
            return False, f"`{name}` is not installed."
        repo = self._repos[name]

        target = commit.strip() or repo.commit
        if not target:
            return False, "No commit hash available. Try `pin <name> <commit>`."

        # If targeting a commit not in the shallow history, unshallow first
        if commit and commit != repo.commit:
            ok, _ = await self._run(
                ["git", "-C", str(repo.path), "cat-file", "-e", f"{commit}^{{commit}}"]
            )
            if not ok:
                # Commit not in local history — fetch it
                ok, err = await self._run(
                    [
                        "git",
                        "-C",
                        str(repo.path),
                        "fetch",
                        "--unshallow",
                        "origin",
                    ]
                )
                if not ok:
                    await self._run(
                        [
                            "git",
                            "-C",
                            str(repo.path),
                            "fetch",
                            "origin",
                        ]
                    )
                ok, err = await self._git_checkout(repo.path, commit)
                if not ok:
                    return False, f"Could not checkout `{commit[:8]}`: {err}"
                target = await self._git_head(repo.path)

        repo.pinned_commit = target
        repo.commit = target
        await self._persist()
        return True, f"`{name}` pinned @ `{target[:8]}`."

    async def unpin(self, name: str) -> tuple[bool, str]:
        """Remove the pin from a repo, allowing future updates."""
        if name not in self._repos:
            return False, f"`{name}` is not installed."
        repo = self._repos[name]
        if not repo.is_pinned:
            return False, f"`{name}` is not pinned."
        old_pin = repo.pinned_commit[:8]
        repo.pinned_commit = ""
        await self._persist()
        return True, f"`{name}` unpinned (was @ `{old_pin}`). Run `update {name}` to get latest."

    async def uninstall(self, name: str) -> tuple[bool, str]:
        """Unload, remove symlink, delete repo and lib directories."""
        if name not in self._repos:
            return False, f"`{name}` is not installed."
        repo = self._repos[name]
        try:
            await self._unload_cog(name)
            (Path("cogs") / name).unlink(missing_ok=True)
            if repo.path.exists():
                shutil.rmtree(repo.path)
            lib_path = _LIB_BASE / name / "lib"
            if lib_path.exists():
                shutil.rmtree(lib_path)
            # Remove from sys.path
            lib_str = str(lib_path)
            if lib_str in sys.path:
                sys.path.remove(lib_str)
            del self._repos[name]
            await self._persist()
            return True, f"Uninstalled `{name}`."
        except Exception:
            logger.exception("Uninstall failed for %s", name)
            return False, "Unexpected error during uninstall — see logs."

    def list_installed(self) -> list[dict[str, str]]:
        result = []
        for r in self._repos.values():
            entry = {
                "name": r.name,
                "repo_url": r.repo_url,
                "branch": r.branch,
                "commit": r.commit[:8] if r.commit else "unknown",
                "pinned": r.pinned_commit[:8] if r.is_pinned else "",
            }
            result.append(entry)
        return result

    def get_repo(self, name: str) -> InstalledRepo | None:
        return self._repos.get(name)

    async def _hot_reload_loop(self, interval: int) -> None:
        while True:
            await asyncio.sleep(interval)
            for name, repo in list(self._repos.items()):
                if repo.is_pinned:
                    continue  # never hot-reload a pinned repo
                try:
                    current = await self._git_head(repo.path)
                    if current and current != repo.commit:
                        logger.info("Hot-reload: %s %s→%s", name, repo.commit[:8], current[:8])
                        await self._install_requirements(name, repo.path)
                        await self._reload_cog(name)
                        repo.commit = current
                        await self._persist()
                except Exception as exc:
                    logger.warning("Hot-reload check failed for %s: %s", name, exc)

    async def _git_clone(
        self, url: str, dest: Path, branch: str, *, shallow: bool = True
    ) -> tuple[bool, str]:
        cmd = ["git", "clone", "-b", branch]
        if shallow:
            cmd += ["--single-branch", "--depth", "1"]
        cmd += [url, str(dest)]
        return await self._run(cmd)

    async def _git_pull(self, path: Path, branch: str) -> tuple[bool, str]:
        ok, err = await self._run(["git", "-C", str(path), "fetch", "origin", branch])
        if not ok:
            return False, err
        return await self._run(["git", "-C", str(path), "reset", "--hard", f"origin/{branch}"])

    async def _git_checkout(self, path: Path, commit: str) -> tuple[bool, str]:
        return await self._run(["git", "-C", str(path), "checkout", commit])

    async def _git_head(self, path: Path) -> str:
        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                "-C",
                str(path),
                "rev-parse",
                "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            return stdout.decode().strip() if proc.returncode == 0 else ""
        except Exception:
            return ""

    async def _git_log(self, path: Path, old_commit: str, new_commit: str) -> list[str]:
        """Return one-line commit messages between old_commit and new_commit."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                "-C",
                str(path),
                "log",
                "--oneline",
                "--no-merges",
                f"{old_commit}..{new_commit}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode != 0:
                return []
            lines = [ln.strip() for ln in stdout.decode().splitlines() if ln.strip()]
            return lines
        except Exception:
            return []

    async def _changed_modules(self, path: Path, old_commit: str, new_commit: str) -> list[str]:
        """Return .py files changed between two commits."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                "-C",
                str(path),
                "diff",
                "--name-only",
                old_commit,
                new_commit,
                "--",
                "*.py",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode != 0:
                return []
            return [f.strip() for f in stdout.decode().splitlines() if f.strip()]
        except Exception:
            return []

    async def _run(self, cmd: list[str]) -> tuple[bool, str]:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                err = stderr.decode().strip() or stdout.decode().strip()
                logger.error("Git failed (%s): %s", " ".join(cmd), err)
                return False, err
            return True, stdout.decode().strip()
        except FileNotFoundError:
            return False, "git not found in PATH"
        except Exception as exc:
            return False, str(exc)

    async def _load_cog(self, name: str) -> tuple[bool, str]:
        self._add_lib_to_syspath(name)
        for module in (f"cogs.{name}.cog", f"cogs.{name}"):
            try:
                await self.bot.load_extension(module)
                return True, ""
            except Exception as exc:
                return False, str(exc)
        return False, "No loadable module found"

    async def _unload_cog(self, name: str) -> None:
        for module in (f"cogs.{name}.cog", f"cogs.{name}"):
            if module in self.bot.extensions:
                try:
                    await self.bot.unload_extension(module)
                except Exception:
                    pass
                return

    async def _reload_cog(self, name: str) -> None:
        self._add_lib_to_syspath(name)
        for module in (f"cogs.{name}.cog", f"cogs.{name}"):
            if module in self.bot.extensions:
                try:
                    await self.bot.reload_extension(module)
                    return
                except Exception as exc:
                    logger.error("Reload failed for %s: %s", name, exc)
                    return
        await self._load_cog(name)

    def _add_lib_to_syspath(self, name: str) -> None:
        """Append the cog's lib directory to sys.path if it exists."""
        lib_path = str(_LIB_BASE / name / "lib")
        if lib_path not in sys.path and Path(lib_path).exists():
            sys.path.append(lib_path)
            logger.debug("[shared_libs] %s: lib path registered", name)

    async def _install_requirements(self, name: str, repo_path: Path) -> dict[str, str]:
        """Install requirements.txt into data/cogs/<name>/lib/ using pip --target.

        Returns {package_name: version} from the installed dist-info directories.
        """
        req_file = repo_path / "requirements.txt"
        if not req_file.exists():
            return {}

        lib_path = _LIB_BASE / name / "lib"
        lib_path.mkdir(parents=True, exist_ok=True)

        logger.info("Installing requirements for %s → %s", name, lib_path)
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "pip",
                "install",
                "--target",
                str(lib_path),
                "--upgrade",
                "--no-cache-dir",
                "-r",
                str(req_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                err = stderr.decode().strip()
                logger.error("pip install failed for %s: %s", name, err)
                return {}
            logger.debug("pip install success for %s", name)
        except Exception as exc:
            logger.error("Requirements install failed for %s: %s", name, exc)
            return {}

        self._add_lib_to_syspath(name)
        return _snapshot_lib_packages(lib_path)

    async def _check_dependency_conflicts(self) -> str:
        """Run ``pip check`` on global site-packages; return output if conflicts."""
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "pip",
                "check",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            stdout, _ = await proc.communicate()
            output = stdout.decode().strip()
            if proc.returncode != 0 and output:
                return output
        except Exception as exc:
            logger.debug("pip check failed: %s", exc)
        return ""

    async def _post_install_check(self, name: str) -> tuple[bool, str]:
        """Import the cog in a subprocess; return (ok, error).

        Catches broken installs before the live bot process tries to load them.
        """
        module = f"cogs.{name}.cog"
        lib_path = str(_LIB_BASE / name / "lib")
        env_pythonpath = os.environ.get("PYTHONPATH", "")
        new_pythonpath = f"{lib_path}:{env_pythonpath}" if env_pythonpath else lib_path
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                f"import {module}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(Path.cwd()),
                env={**os.environ, "PYTHONPATH": new_pythonpath},
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
            if proc.returncode != 0:
                return False, stderr.decode().strip() or f"import {module} failed."
            return True, ""
        except TimeoutError:
            return False, "Import check timed out after 30s."
        except Exception as exc:
            return False, str(exc)

    async def _persist(self) -> None:
        await self._db.set(
            "global",
            "0",
            "installed_repos",
            {name: repo.to_dict() for name, repo in self._repos.items()},
        )

    @staticmethod
    def _repo_name_from_url(url: str) -> str:
        url = url.rstrip("/")
        if url.endswith(".git"):
            url = url[:-4]
        return url.split("/")[-1].lower()


def _bot_version() -> str:
    try:
        import importlib

        mod = importlib.import_module("main")
        return getattr(mod, "__version__", "")
    except Exception:
        return ""


def _snapshot_lib_packages(lib_path: Path) -> dict[str, str]:
    """Read installed package versions from dist-info directories in *lib_path*.

    This reads directly from the per-cog lib directory so the lockfile
    reflects what is actually installed there, not what pip says globally.
    """
    packages: dict[str, str] = {}
    for dist_info in lib_path.glob("*.dist-info"):
        stem = dist_info.name[: -len(".dist-info")]
        # Stem format: Name-Version  (or Name-Version.dist-info after stripping)
        parts = stem.rsplit("-", 1)
        if len(parts) == 2:
            pkg_name, version = parts
            # Normalise: underscores → dashes, lowercase
            packages[pkg_name.replace("_", "-").lower()] = version
    return packages
