from __future__ import annotations

import json
import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.store import Store

logger = logging.getLogger("ember.data_deletion")

# Data export directory
EXPORT_DIR = Path("data/exports")
EXPORT_DIR.mkdir(parents=True, exist_ok=True)

# Config for storing audit logs
_config = Store.for_cog("EmberDataDeletion", 400_001)
_config.defaults({"global": {"deletion_log_json": "{}"}})  # {guild_id_str: [log_entries]}


class DataDeletionManager:
    """Manages user data deletion and export across all cogs."""

    def __init__(self) -> None:
        self._deletion_callbacks: list[Callable[[int, int | None], Any]] = []
        self._export_callbacks: list[Callable[[int, int | None], dict[str, Any]]] = []

    def register_deletion_callback(self, callback: Callable[[int, int | None], Any]) -> None:
        if callback not in self._deletion_callbacks:
            self._deletion_callbacks.append(callback)

    def register_export_callback(
        self, callback: Callable[[int, int | None], dict[str, Any]]
    ) -> None:
        if callback not in self._export_callbacks:
            self._export_callbacks.append(callback)

    async def delete_data(self, user_id: int, guild_id: int | None = None) -> dict[str, Any]:
        results = {}
        logger.info("Starting data deletion for user %d (guild: %s)", user_id, guild_id or "global")

        for callback in self._deletion_callbacks:
            try:
                cog_name = getattr(callback, "__self__", "unknown").__class__.__name__
                result = await callback(user_id, guild_id)
                if result:
                    results[cog_name] = result
            except Exception as exc:
                logger.error("Deletion callback error in %s: %s", callback, exc)

        await self._log_deletion(user_id, guild_id, results)
        logger.info("Completed data deletion for user %d", user_id)
        return results

    async def export_data(self, user_id: int, guild_id: int | None = None) -> dict[str, Any]:
        results = {}
        logger.info("Starting data export for user %d (guild: %s)", user_id, guild_id or "global")

        for callback in self._export_callbacks:
            try:
                cog_name = getattr(callback, "__self__", "unknown").__class__.__name__
                data = await callback(user_id, guild_id)
                if data:
                    results[cog_name] = data
            except Exception as exc:
                logger.error("Export callback error in %s: %s", callback, exc)

        results["_metadata"] = {
            "user_id": user_id,
            "guild_id": guild_id,
            "exported_at": datetime.now(UTC).isoformat(),
            "cogs": list(results.keys()),
        }

        filename = f"user_{user_id}_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}.json"
        filepath = EXPORT_DIR / filename
        filepath.write_text(json.dumps(results, indent=2))
        logger.info("Exported data for user %d to %s", user_id, filepath)

        return results

    async def _log_deletion(
        self, user_id: int, guild_id: int | None, results: dict[str, Any]
    ) -> None:
        log_entry = {
            "user_id": user_id,
            "guild_id": guild_id,
            "timestamp": datetime.now(UTC).isoformat(),
            "cogs_affected": list(results.keys()),
            "details": results,
        }

        raw: str = await _config.get("global", 0, "deletion_log_json") or "{}"
        try:
            logs = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            logs = {}

        key = str(guild_id) if guild_id else "global"
        entries = logs.get(key, [])
        entries.append(log_entry)
        logs[key] = entries[-100:]  # Keep last 100

        await _config.set("global", 0, "deletion_log_json", json.dumps(logs, ensure_ascii=False))


# Global singleton
_manager: DataDeletionManager | None = None


def get_manager() -> DataDeletionManager:
    global _manager
    if _manager is None:
        _manager = DataDeletionManager()
    return _manager


def register_data_callbacks(cog: Any) -> None:
    """Register a cog's GDPR delete/export callbacks with the global manager.

    The cog should implement any of:
        async def delete_data_for_user(self, user_id: int, guild_id: int | None) -> dict
        async def export_data_for_user(self, user_id: int, guild_id: int | None) -> dict
    """
    mgr = get_manager()
    if hasattr(cog, "delete_data_for_user"):
        mgr.register_deletion_callback(lambda uid, gid: cog.delete_data_for_user(uid, gid))
    if hasattr(cog, "export_data_for_user"):
        mgr.register_export_callback(lambda uid, gid: cog.export_data_for_user(uid, gid))
