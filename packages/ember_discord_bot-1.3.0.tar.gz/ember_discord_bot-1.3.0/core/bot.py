from __future__ import annotations

import logging
import os
from datetime import UTC, datetime

import discord
from discord import app_commands
from discord.ext import commands

from core.cog import _convert_to_snake_case
from core.permissions_engine import PermissionRegistry
from core.prefix import get_guild_prefixes
from core.rpc import RPCMixin
from utils.cards import (
    make_error_card,
)

logger = logging.getLogger("ember.bot")


class EmberBot(RPCMixin, commands.AutoShardedBot):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Services (initialized in __init__, async init in setup_hook)
        from core.downloader import CogDownloader

        self.downloader = CogDownloader(self)
        self._owner_ids: set[int] = set()
        self._start_time = datetime.now(UTC)
        # Add global check for whitelist/blacklist and ignore
        self.add_check(self._global_access_check)
        # Register prefix commands
        self.add_command(self.sync)

    async def _global_access_check(self, ctx: commands.Context) -> bool:
        """Check if user is allowed to use commands (whitelist/blacklist/ignore)."""
        guild_id = ctx.guild.id if ctx.guild else None
        user_id = ctx.author.id

        if await self.is_owner(ctx.author):
            return True

        try:
            from core.ignore import is_channel_ignored, is_guild_ignored

            if await is_guild_ignored(guild_id or 0):
                return False
            if guild_id and await is_channel_ignored(guild_id, ctx.channel.id):
                return False
        except Exception as e:
            logger.warning("ignore check failed: %s", e)

        try:
            from core.whitelist_blacklist import is_blocked

            if await is_blocked(guild_id, user_id):
                return False
        except Exception as e:
            logger.warning("whitelist/blacklist check failed: %s", e)

        if guild_id and ctx.command and ctx.command.cog:
            try:
                from core._cog_manager import get_manager

                cog_name = _convert_to_snake_case(type(ctx.command.cog).__name__)
                if not await get_manager().is_cog_enabled_in_guild(cog_name, guild_id):
                    return False
            except Exception as e:
                logger.warning("cog-enable check failed: %s", e)

        return True

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if await self.is_owner(interaction.user):
            return True

        guild_id = interaction.guild.id if interaction.guild else None
        user_id = interaction.user.id

        try:
            from core.ignore import is_channel_ignored, is_guild_ignored

            if await is_guild_ignored(guild_id or 0):
                await interaction.response.send_message(
                    view=make_error_card("⛔ Ignored", "Bot commands are disabled in this server."),
                    ephemeral=True,
                )
                return False
            if guild_id and interaction.channel_id:
                if await is_channel_ignored(guild_id, interaction.channel_id):
                    await interaction.response.send_message(
                        view=make_error_card(
                            "⛔ Ignored", "Bot commands are disabled in this channel."
                        ),
                        ephemeral=True,
                    )
                    return False
        except Exception as e:
            logger.warning("ignore check failed: %s", e)

        try:
            from core.whitelist_blacklist import is_blocked

            if await is_blocked(guild_id, user_id):
                await interaction.response.send_message(
                    view=make_error_card("🚫 Blocked", "You are not allowed to use this bot."),
                    ephemeral=True,
                )
                return False
        except Exception as e:
            logger.warning("whitelist/blacklist check failed: %s", e)

        if guild_id and interaction.command and hasattr(interaction.command, "binding"):
            try:
                from core._cog_manager import get_manager

                cog = interaction.command.binding
                if cog is not None:
                    cog_name = _convert_to_snake_case(type(cog).__name__)
                    if not await get_manager().is_cog_enabled_in_guild(cog_name, guild_id):
                        await interaction.response.send_message(
                            view=make_error_card(
                                "🚫 Disabled", "This feature is disabled in this server."
                            ),
                            ephemeral=True,
                        )
                        return False
            except Exception as e:
                logger.warning("cog-enable check failed: %s", e)

        if guild_id and interaction.command:
            cog = interaction.command.binding
            if cog is not None:
                cog_name = _convert_to_snake_case(type(cog).__name__)
                command_path = f"{cog_name}:{interaction.command.name}"
                registry: PermissionRegistry = self.permission_registry  # type: ignore
                requires = registry.get_requires(command_path)
                if requires is not None:
                    try:
                        allowed = await requires.verify(interaction, registry)
                        if not allowed:
                            await interaction.response.send_message(
                                view=make_error_card(
                                    "🚫 No Permission",
                                    "You do not have permission to use this command.",
                                ),
                                ephemeral=True,
                            )
                            return False
                    except app_commands.AppCommandError:
                        raise
                    except Exception as e:
                        logger.error(
                            "Permission check failed for %s: %s", command_path, e, exc_info=True
                        )
                        await interaction.response.send_message(
                            view=make_error_card(
                                "❌ Permission Error", "Could not verify permissions."
                            ),
                            ephemeral=True,
                        )
                        return False

        return True

    async def setup_hook(self) -> None:
        logger.info("initialising core systems")

        try:
            from core._drivers import get_driver

            driver = get_driver()
            await driver.initialize()
        except Exception as exc:
            logger.error("data driver init failed: %s", exc)

        for name, loader in [
            ("ModLog", "core.modlog._get_db"),
            ("Bank", "core.bank._get_db"),
        ]:
            try:
                module, fn = loader.rsplit(".", 1)
                import importlib

                mod = importlib.import_module(module)
                await getattr(mod, fn)()
                logger.info("%s initialised", name)
            except Exception as exc:
                logger.error("%s init failed: %s", name, exc)

        # Setup help system
        try:
            from core._bot_admin import _AdminGroup, _OwnerGroup
            from core.help import register_help

            await register_help(self)
            self.tree.add_command(_OwnerGroup(self))
            self.tree.add_command(_AdminGroup(self))
        except Exception as exc:
            logger.error("Help system init failed: %s", exc)

        # Initialize token manager
        try:
            from core.api_tokens import get_manager

            await get_manager().load()
            logger.info("Token manager initialized")
        except Exception as exc:
            logger.error("Token manager init failed: %s", exc)

        # Initialize whitelist/blacklist system
        try:
            from core.whitelist_blacklist import initialize as init_wb

            await init_wb()
            logger.info("Whitelist/Blacklist system initialized")
        except Exception as exc:
            logger.error("Whitelist/Blacklist init failed: %s", exc)

        # Initialize ignore system
        try:
            from core.ignore import initialize as init_ignore

            await init_ignore()
            logger.info("Ignore system initialized")
        except Exception as exc:
            logger.error("Ignore system init failed: %s", exc)

        # Initialize permission registry (loads rules from config)
        try:
            from core.permissions_engine import PermissionRegistry

            self.permission_registry = await PermissionRegistry.get(self)
            await self.permission_registry.initialize()
            logger.info(
                "Permission registry initialized with %d commands",
                len(self.permission_registry.get_all_commands()),
            )
        except Exception as exc:
            logger.error("Permission registry init failed: %s", exc)

        # Initialize cog downloader service (created in __init__)
        try:
            await self.downloader.initialize()
            logger.info("Cog downloader initialized")
        except Exception as exc:
            logger.error("Cog downloader init failed: %s", exc)

        await self.rpc_start()

    async def on_ready(self) -> None:
        shard_info = (
            f"  |  Shard {self.shard_id}/{self.shard_count}"
            if self.shard_count and self.shard_count > 1
            else ""
        )
        logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        logger.info(" Ember  |  %s  |  %d guilds%s", self.user, len(self.guilds), shard_info)
        logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        try:
            from core.diagnostics import format_report, run_diagnostics

            results = await run_diagnostics(self)
            report = format_report(results)
            for line in report.splitlines():
                logger.info(line)
        except Exception as exc:
            logger.warning("Diagnostics failed: %s", exc)

        try:
            from core._bot_admin import apply_owner_profile

            await apply_owner_profile(self)
        except Exception as exc:
            logger.warning("apply_owner_profile failed: %s", exc)

    async def on_guild_remove(self, guild: discord.Guild) -> None:
        logger.info("Left guild %s (%d)", guild.name, guild.id)

    async def close(self) -> None:
        """Clean shutdown: stop RPC server and hot-reload watcher."""
        try:
            await self.rpc.close()
        except Exception as e:
            logger.error("RPC server stop error: %s", e)
        try:
            await self.downloader.shutdown()
        except Exception as e:
            logger.error("Downloader shutdown error: %s", e)
        await super().close()

    async def on_cog_unload(self, cog: commands.Cog) -> None:
        await self._rpc_cog_unload(cog)

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        if interaction.response.is_done():
            return
        cause = getattr(error, "__cause__", error)
        from core.errors import UserFeedbackError

        if isinstance(cause, UserFeedbackError):
            try:
                await interaction.response.send_message(
                    view=make_error_card(cause.title, cause.message),
                    ephemeral=True,
                )
            except Exception:
                pass
            return
        logger.error(
            "Unhandled error in /%s: %s",
            getattr(interaction.command, "qualified_name", "?"),
            error,
            exc_info=error,
        )
        try:
            await interaction.response.send_message(
                view=make_error_card(
                    "❌ Unexpected Error", "Something went wrong. Contact an admin."
                ),
                ephemeral=True,
            )
        except Exception:
            pass

    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.NotOwner):
            await ctx.send("🚫 Owner only.", delete_after=5)
        elif isinstance(error, commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            await ctx.send(f"🚫 Need: **{missing}**", delete_after=8)
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Retry in {error.retry_after:.1f}s", delete_after=5)
        elif isinstance(error, commands.CheckFailure):
            await ctx.send("🚫 Check failed.", delete_after=5)
        else:
            logger.error("Prefix command error: %s", error, exc_info=error)

    async def send_to_owners(
        self,
        content: str | None = None,
        *,
        view: discord.ui.LayoutView | None = None,
    ) -> None:
        """DM all bot owners."""
        for owner_id in await self._get_owner_ids():
            try:
                user = self.get_user(owner_id) or await self.fetch_user(owner_id)
                dm = user.dm_channel or await user.create_dm()
                if view:
                    await dm.send(view=view)
                elif content:
                    await dm.send(content)
            except (discord.Forbidden, discord.HTTPException):
                pass

    async def _get_owner_ids(self) -> set[int]:
        if self._owner_ids:
            return self._owner_ids
        static = {int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()}
        if static:
            self._owner_ids = static
            return static
        try:
            app = await self.application_info()
            self._owner_ids = {m.id for m in app.team.members} if app.team else {app.owner.id}
        except Exception:
            pass
        return self._owner_ids

    async def is_owner(self, user: discord.abc.User) -> bool:
        return user.id in await self._get_owner_ids()

    async def get_prefix(self, message: discord.Message) -> list[str]:
        """Return the list of valid prefixes for this guild.

        Includes global defaults, per-guild custom prefixes, and bot mention.
        This method is used by commands.when_mentioned_or() pattern.
        """
        guild_id = message.guild.id if message.guild else None
        prefixes = await get_guild_prefixes(guild_id)
        # Always allow mentioning the bot
        prefixes.append(self.user.mention)
        return prefixes

    @property
    def uptime(self) -> str:
        from utils.formatting import humanize_timedelta

        return humanize_timedelta(int((datetime.now(UTC) - self._start_time).total_seconds()))

    @commands.command()
    @commands.is_owner()
    async def sync(ctx: commands.Context, guild_id: int | None = None) -> None:
        """Sync slash commands to a guild or globally.

        Usage:
            ,sync              — Sync globally (all servers)
            ,sync 1234567890   — Sync to specific guild
        """
        try:
            if guild_id:
                synced = await ctx.bot.tree.sync(guild=discord.Object(id=guild_id))
                await ctx.send(f"✅ Synced **{len(synced)}** commands to guild {guild_id}")
            else:
                synced = await ctx.bot.tree.sync()
                await ctx.send(f"✅ Synced **{len(synced)}** commands globally")
        except Exception as e:
            await ctx.send(f"❌ Sync failed: {e}")

    async def on_message(self, message: discord.Message) -> None:
        await self.process_commands(message)

    async def load_cogs(self, cog_filter: str | None = None) -> tuple[int, int]:
        """Load cogs using CogManager. Returns (loaded, failed)."""
        from core._cog_manager import get_manager

        manager = get_manager()
        await manager.discover_cogs()
        if cog_filter:
            info = await manager.get_cog_info(cog_filter)
            if info:
                success = await manager.load_cog(self, cog_filter)
                return (1, 0) if success else (0, 1)
            else:
                logger.error("Cog not found: %s", cog_filter)
                return 0, 1
        else:
            return await manager.load_all_cogs(self)
