from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import Any

import discord
from discord import app_commands

from core.store import Store

logger = logging.getLogger("ember.permissions_engine")


# ═══════════════════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════════════════


class PermissionLevel(IntEnum):
    """Hierarchical permission levels."""

    NONE = 0
    USER = 0  # alias: regular guild member (same level as NONE)
    MOD = 1
    ADMIN = 2
    GUILD_OWNER = 3
    BOT_OWNER = 4


class PermState(Enum):
    """Permission state for rule evaluation.

    States form a state machine. When evaluating a command, we walk through
    the model chain (user → channel → roles → guild) and transition between
    states based on encountered rules.

    Values:
        ACTIVE_ALLOW: Explicitly allowed. Command will run.
        ACTIVE_DENY: Explicitly denied. Command blocked.
        NORMAL: No override, use default checks (privilege level / user perms).
        PASSIVE_ALLOW: A subcommand was ACTIVE_ALLOW. Parent commands should allow traversal.
        CAUTIOUS_ALLOW: A subcommand was ACTIVE_ALLOW but this node is ACTIVE_DENY.
                       Allow traversal but deny at this level (rare).
    """

    ACTIVE_ALLOW = auto()
    ACTIVE_DENY = auto()
    NORMAL = auto()
    PASSIVE_ALLOW = auto()
    CAUTIOUS_ALLOW = auto()

    @classmethod
    def from_bool(cls, value: bool | None) -> PermState:
        if value is True:
            return cls.ACTIVE_ALLOW
        if value is False:
            return cls.ACTIVE_DENY
        return cls.NORMAL


# ═══════════════════════════════════════════════════════════════════════════
# State Machine Transitions
# ═══════════════════════════════════════════════════════════════════════════

# TransitionResult = (should_invoke: Optional[bool], next_state: PermState|Dict[bool, PermState])
# Dict[bool, PermState] is used for NORMAL→PASSIVE_ALLOW where next state depends on default check result

_PermStateTransitions: dict[
    PermState, dict[PermState, tuple[bool | None, PermState | dict[bool, PermState]]]
] = {
    PermState.ACTIVE_ALLOW: {
        PermState.ACTIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),
        PermState.NORMAL: (True, PermState.ACTIVE_ALLOW),
        PermState.PASSIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),
        PermState.CAUTIOUS_ALLOW: (True, PermState.CAUTIOUS_ALLOW),
        PermState.ACTIVE_DENY: (False, PermState.ACTIVE_DENY),
    },
    PermState.NORMAL: {
        PermState.ACTIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),
        PermState.NORMAL: (None, PermState.NORMAL),
        PermState.PASSIVE_ALLOW: (True, {True: PermState.NORMAL, False: PermState.PASSIVE_ALLOW}),
        PermState.CAUTIOUS_ALLOW: (True, PermState.CAUTIOUS_ALLOW),
        PermState.ACTIVE_DENY: (False, PermState.ACTIVE_DENY),
    },
    PermState.PASSIVE_ALLOW: {
        PermState.ACTIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),
        PermState.NORMAL: (False, PermState.NORMAL),
        PermState.PASSIVE_ALLOW: (True, PermState.PASSIVE_ALLOW),
        PermState.CAUTIOUS_ALLOW: (True, PermState.CAUTIOUS_ALLOW),
        PermState.ACTIVE_DENY: (False, PermState.ACTIVE_DENY),
    },
    PermState.CAUTIOUS_ALLOW: {
        PermState.ACTIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),
        PermState.NORMAL: (False, PermState.ACTIVE_DENY),
        PermState.PASSIVE_ALLOW: (True, PermState.CAUTIOUS_ALLOW),
        PermState.CAUTIOUS_ALLOW: (True, PermState.CAUTIOUS_ALLOW),
        PermState.ACTIVE_DENY: (False, PermState.ACTIVE_DENY),
    },
    PermState.ACTIVE_DENY: {
        PermState.ACTIVE_ALLOW: (True, PermState.ACTIVE_ALLOW),  # should not happen
        PermState.NORMAL: (False, PermState.ACTIVE_DENY),
        PermState.PASSIVE_ALLOW: (False, PermState.ACTIVE_DENY),
        PermState.CAUTIOUS_ALLOW: (False, PermState.ACTIVE_DENY),
        PermState.ACTIVE_DENY: (False, PermState.ACTIVE_DENY),
    },
}


def _transition(prev: PermState, next_state: PermState) -> tuple[bool | None, PermState]:
    """Compute state transition. Returns (should_invoke, new_state)."""
    result = _PermStateTransitions[prev][next_state]
    should_invoke, next_state_result = result

    if isinstance(next_state_result, dict):
        # NORMAL→PASSIVE_ALLOW: allow but stay in PASSIVE_ALLOW (default check deferred)
        return should_invoke, PermState.PASSIVE_ALLOW
    return should_invoke, next_state_result


# ═══════════════════════════════════════════════════════════════════════════
# Rules Storage Format
# ═══════════════════════════════════════════════════════════════════════════

# Rule = {"model": int|str, "state": "allow"|"deny"}
# Model types:
#   - user:<user_id>         (e.g., "user:123456")
#   - role:<role_id>         (e.g., "role:789012")
#   - channel:<channel_id>   (e.g., "channel:345678")
#   - guild:<guild_id>       (e.g., "guild:901234") - guild-wide default
#   - default                (special string for the Default rule)

# Storage structure in config:
# {
#   "rules": {
#     "<cog_name>": {
#       "<command_name>": {
#         "global": {
#           "default": "normal",  # or "allow" or "deny"
#           "rules": [{"model": "user:123", "state": "allow"}, ...]
#         },
#         "guilds": {
#           "<guild_id>": {
#             "default": "normal",
#             "rules": [...]
#           }
#         }
#       }
#     }
#   }
# }

# ═══════════════════════════════════════════════════════════════════════════
# Requires - Command Requirements + Rule Lookup
# ═══════════════════════════════════════════════════════════════════════════


@dataclass
class Requires:
    """Describes the requirements for executing a specific command.

    Attributes:
        privilege_level: Required PrivilegeLevel (NONE, MOD, ADMIN, etc.)
        user_perms: Required discord.Permissions (optional, checked as OR with privilege_level)
        bot_perms: Required bot permissions (non-overrideable)
        checks: Custom check predicates (also overrideable unless flagged)
        command_path: Unique identifier "cog_name:command_name" (e.g., "moderation:kick")
    """

    privilege_level: PermissionLevel | None
    user_perms: discord.Permissions | None
    bot_perms: discord.Permissions
    checks: list[Callable[[app_commands.Context], Awaitable[bool]]]
    command_path: str

    async def verify(
        self, interaction: app_commands.Interaction, registry: PermissionRegistry
    ) -> bool:
        """Verify if the interaction can execute this command.

        This combines:
        1. Bot permissions (non-overrideable)
        2. Owner bypass
        3. Permission hooks (global checks)
        4. Rule-based state machine evaluation
        5. Default checks (privilege level / user permissions)

        Returns True if allowed, raises appropriate errors if denied.
        """
        # Bot permissions check (always enforced)
        bot_perms = interaction.app_permissions
        if bot_perms is None:
            bot_perms = discord.Permissions.none()
        if not (bot_perms.administrator or bot_perms >= self.bot_perms):
            missing = self._missing_perms(self.bot_perms, bot_perms)
            raise app_commands.BotMissingPermissions([name for name, val in missing if val])

        # Owner bypass
        if await registry.bot.is_owner(interaction.user):
            return True

        # Bot owner-only commands cannot be overridden
        if self.privilege_level == PermissionLevel.BOT_OWNER:
            return False

        # Permission hooks
        hook_result = await registry.bot.verify_permissions_hooks(interaction)
        if hook_result is not None:
            return hook_result

        # Rule-based evaluation (state machine)
        if interaction.guild is None:
            # DMs: check global rules for the user
            allowed = await self._evaluate_dm(interaction.user.id, registry)
            if allowed is not None:
                return allowed
        else:
            # Build model chain for guild context
            allowed = await self._evaluate_guild(interaction, registry)
            if allowed is not None:
                return allowed

        # Fall back to default checks (privilege level OR user perms)
        return await self._verify_default(interaction, registry)

    async def _evaluate_guild(
        self, interaction: app_commands.Interaction, registry: PermissionRegistry
    ) -> bool | None:
        """Evaluate rules in guild context following the model chain."""
        guild = interaction.guild
        user = interaction.user
        assert isinstance(user, discord.Member), "user must be Member in guild"

        rules = await registry.get_rules(self.command_path, guild.id)
        if not rules:
            return None

        def _model_key(m: discord.abc.Snowflake) -> str:
            if isinstance(m, discord.Member):
                return f"user:{m.id}"
            if isinstance(m, discord.Role):
                return f"role:{m.id}"
            if isinstance(m, discord.Guild):
                return f"guild:{m.id}"
            return f"channel:{m.id}"

        models: list[discord.abc.Snowflake] = []
        models.append(user)

        channel = interaction.channel
        if isinstance(channel, discord.Thread):
            models.append(channel.parent)
        models.append(channel)

        if hasattr(channel, "category") and channel.category:
            models.append(channel.category)

        for role in reversed(user.roles[1:]):
            models.append(role)

        models.append(guild)

        state = PermState.NORMAL

        # Check global rules
        for model in models:
            rule = rules.global_rules.get(_model_key(model))
            if rule:
                should_invoke, state = _transition(state, rule)
                if should_invoke is not None:
                    return should_invoke

        # Check guild-specific rules (inner dict keyed by guild_id)
        per_guild = rules.guild_rules.get(str(guild.id), {})
        for model in models:
            if isinstance(model, discord.Guild):
                continue
            rule = per_guild.get(_model_key(model))
            if rule:
                should_invoke, state = _transition(state, rule)
                if should_invoke is not None:
                    return should_invoke

        # Guild default
        if state == PermState.NORMAL:
            guild_default = per_guild.get("default")
            if guild_default:
                should_invoke, state = _transition(state, guild_default)
                if should_invoke is not None:
                    return should_invoke

        # Global default fallback
        if state == PermState.NORMAL:
            global_default = rules.global_rules.get("default")
            if global_default:
                should_invoke, state = _transition(PermState.NORMAL, global_default)
                if should_invoke is not None:
                    return should_invoke

        return None

    async def _evaluate_dm(self, user_id: int, registry: PermissionRegistry) -> bool | None:
        """Evaluate rules in DM context. Only global rules apply."""
        rules = await registry.get_rules(self.command_path)
        if not rules:
            return None

        # In DM, only check direct user rule and global default
        user_rule = rules.global_rules.get(f"user:{user_id}")
        if user_rule:
            should_invoke, state = _transition(PermState.NORMAL, user_rule)
            if should_invoke is not None:
                return should_invoke

        default_rule = rules.global_rules.get("default")
        if default_rule:
            should_invoke, state = _transition(PermState.NORMAL, default_rule)
            if should_invoke is not None:
                return should_invoke

        return None

    async def _verify_default(
        self, interaction: app_commands.Interaction, registry: PermissionRegistry
    ) -> bool:
        """Standard privilege/user-permissions check."""
        checks_pass = await discord.utils.async_all(check(interaction) for check in self.checks)
        if not checks_pass:
            return False

        if self.user_perms is not None:
            user_perms = (
                interaction.user.guild_permissions
                if interaction.guild
                else discord.Permissions.none()
            )
            if user_perms.administrator or user_perms >= self.user_perms:
                return True

        if self.privilege_level is not None:
            from core.permissions import _get_user_permission_level

            if interaction.guild is None:
                # In DMs, only bot owners can run commands requiring >NONE
                if self.privilege_level > PermissionLevel.NONE:
                    return await registry.bot.is_owner(interaction.user)
                return True  # any user can run NONE-level commands in DM
            level = await _get_user_permission_level(
                interaction.user, interaction.guild, registry.bot
            )
            return level >= self.privilege_level

        return False

    @staticmethod
    def _missing_perms(
        required: discord.Permissions, actual: discord.Permissions
    ) -> discord.Permissions:
        """Calculate missing permissions."""
        return discord.Permissions(required.value & ~actual.value)

    def __repr__(self) -> str:
        return (
            f"<Requires command={self.command_path!r} "
            f"privilege_level={self.privilege_level!r} "
            f"user_perms={self.user_perms!r}>"
        )


# ═══════════════════════════════════════════════════════════════════════════
# Rule Storage and Retrieval
# ═══════════════════════════════════════════════════════════════════════════


@dataclass
class CommandRules:
    """Rules for a specific command (cog:command)."""

    global_rules: dict[str, PermState] = field(
        default_factory=dict
    )  # {'default': NORMAL, 'user:123': ALLOW, ...}
    guild_rules: dict[str, dict[str, PermState]] = field(
        default_factory=dict
    )  # {guild_id: {default: NORMAL, ...}}

    def get_rule(self, model_id: str, guild_id: int | None = None) -> PermState | None:
        """Get rule for a model in a specific guild or globally."""
        if guild_id:
            guild_rules = self.guild_rules.get(str(guild_id), {})
            return guild_rules.get(model_id)
        return self.global_rules.get(model_id)

    def set_rule(self, model: str, state: PermState, guild_id: int | None = None) -> None:
        """Set a rule."""
        if guild_id:
            guild_dict = self.guild_rules.setdefault(str(guild_id), {})
            guild_dict[model] = state
        else:
            self.global_rules[model] = state

    def clear_rule(self, model: str, guild_id: int | None = None) -> bool:
        """Remove a rule. Returns True if existed."""
        if guild_id:
            guild_dict = self.guild_rules.get(str(guild_id))
            if guild_dict and model in guild_dict:
                del guild_dict[model]
                return True
            return False
        if model in self.global_rules:
            del self.global_rules[model]
            return True
        return False

    def clear_all(self, guild_id: int | None = None, preserve_default: bool = True) -> None:
        """Clear all rules for a guild (or global)."""
        if guild_id:
            guild_dict = self.guild_rules.get(str(guild_id))
            if guild_dict:
                if preserve_default and "default" in guild_dict:
                    default = guild_dict["default"]
                    guild_dict.clear()
                    guild_dict["default"] = default
                else:
                    guild_dict.clear()
        else:
            if preserve_default and "default" in self.global_rules:
                default = self.global_rules["default"]
                self.global_rules.clear()
                self.global_rules["default"] = default
            else:
                self.global_rules.clear()


# ═══════════════════════════════════════════════════════════════════════════
# Permission Registry - Singleton Manager
# ═══════════════════════════════════════════════════════════════════════════


class PermissionRegistry:
    """Global registry for all command permissions.

    Responsibilities:
    - Track all commands and their Requires objects
    - Store and retrieve permission rules (in Config)
    - Evaluate permissions for any command in any context
    - Load/save rules from persistent storage

    Usage:
        registry = PermissionRegistry.get()
        registry.register(command_path, requires_obj)
        allowed = await registry.check(interaction, command_path)
    """

    _instance: PermissionRegistry | None = None
    _lock = asyncio.Lock()

    def __init__(self, bot: discord.Client):
        self.bot = bot
        self._requires: dict[str, Requires] = {}  # command_path → Requires
        self._rules: dict[str, CommandRules] = {}  # command_path → CommandRules
        self._config: Store | None = None
        self._initialized = False

    @classmethod
    async def get(cls, bot: discord.Client) -> PermissionRegistry:
        """Get or create the singleton registry."""
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(bot)
        return cls._instance

    async def initialize(self) -> None:
        """Load rules from config and mark as ready."""
        if self._initialized:
            return
        from core.store import Store

        self._config = Store.for_cog("permissions", 0x7065726D73)
        self._config.defaults({"global": {"rules": {}}})  # {"cog:command": {...}}

        await self._load_rules()
        self._initialized = True
        logger.info("Permission registry initialized with %d commands", len(self._requires))

    async def _load_rules(self) -> None:
        """Load all permission rules from config."""
        raw = await self._config.get("global", 0, "rules") or {}
        self._rules.clear()

        for command_path, rule_data in raw.items():
            rules = CommandRules()
            # Global rules
            for model, state_str in rule_data.get("global", {}).items():
                rules.global_rules[model] = PermState(state_str)
            # Guild rules
            for guild_id, guild_data in rule_data.get("guilds", {}).items():
                rules.guild_rules[guild_id] = {
                    model: PermState(state_str) for model, state_str in guild_data.items()
                }
            self._rules[command_path] = rules

        logger.debug("Loaded permission rules for %d commands", len(self._rules))

    async def _save_rules(self) -> None:
        """Persist all rules to config."""
        if not self._config:
            return

        raw: dict[str, dict[str, dict[str, str]]] = {}
        for command_path, rules in self._rules.items():
            rule_dict: dict[str, dict[str, str]] = {}
            # Global
            rule_dict["global"] = {
                model: state.value for model, state in rules.global_rules.items()
            }
            # Guilds
            rule_dict["guilds"] = {
                guild_id: {model: state.value for model, state in guild_rules.items()}
                for guild_id, guild_rules in rules.guild_rules.items()
            }
            raw[command_path] = rule_dict

        await self._config.set("global", 0, "rules", raw)

    def register(self, command_path: str, requires: Requires) -> None:
        """Register a command's default requirements."""
        self._requires[command_path] = requires
        # Ensure we have a CommandRules entry
        if command_path not in self._rules:
            self._rules[command_path] = CommandRules()

    def unregister(self, command_path: str) -> None:
        """Unregister a command (on cog unload)."""
        self._requires.pop(command_path, None)
        self._rules.pop(command_path, None)

    def get_requires(self, command_path: str) -> Requires | None:
        """Get the Requires object for a command."""
        return self._requires.get(command_path)

    async def get_rules(
        self, command_path: str, guild_id: int | None = None
    ) -> CommandRules | None:
        """Get rules for a command (from cache or load if needed)."""
        return self._rules.get(command_path)

    async def set_rule(
        self, command_path: str, model: str, state: PermState, guild_id: int | None = None
    ) -> None:
        """Set a permission rule.

        Args:
            command_path: e.g., "moderation:kick"
            model: model identifier like "user:123456", "role:789", "default"
            state: PermState (ACTIVE_ALLOW, ACTIVE_DENY, NORMAL)
            guild_id: guild ID for guild-specific rule, None for global
        """
        rules = self._rules.setdefault(command_path, CommandRules())
        rules.set_rule(model, state, guild_id)
        await self._save_rules()

    async def clear_rule(self, command_path: str, model: str, guild_id: int | None = None) -> bool:
        """Clear a rule. Returns True if existed."""
        rules = self._rules.get(command_path)
        if not rules:
            return False
        existed = rules.clear_rule(model, guild_id)
        if existed:
            await self._save_rules()
        return existed

    async def clear_all_guild_rules(self, guild_id: int) -> None:
        """Clear all permission rules for a guild (on guild remove)."""
        for rules in self._rules.values():
            rules.clear_all(guild_id=guild_id)
        await self._save_rules()

    async def check(self, interaction: app_commands.Interaction, command_path: str) -> bool:
        """Check if interaction is allowed to run command."""
        requires = self._requires.get(command_path)
        if not requires:
            logger.warning(
                "No Requires found for command %s, defaulting to owner-only", command_path
            )
            return await self.bot.is_owner(interaction.user)

        try:
            return await requires.verify(interaction, self)
        except app_commands.AppCommandError:
            raise
        except Exception as e:
            logger.error("Permission check failed for %s: %s", command_path, e, exc_info=True)
            raise

    def get_all_commands(self) -> list[str]:
        """List all command paths (registered or with stored rules)."""
        return list(set(self._requires.keys()) | set(self._rules.keys()))

    def get_command_info(self, command_path: str) -> dict[str, Any] | None:
        """Get info about a command's requirements."""
        req = self._requires.get(command_path)
        if not req:
            return None
        return {
            "command_path": command_path,
            "privilege_level": req.privilege_level.name if req.privilege_level else None,
            "user_perms": dict(req.user_perms) if req.user_perms else None,
        }
