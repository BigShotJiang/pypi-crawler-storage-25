"""Admin and owner slash command groups for EmberBot.

Extracted from core/bot.py to keep the bot module focused on the
EmberBot class itself. These groups are instantiated and attached
to the command tree by EmberBot.setup_hook.
"""

from __future__ import annotations

import logging
import traceback
from typing import TYPE_CHECKING, Literal

import discord
from discord import app_commands
from discord.ext import commands

from utils.cards import (
    make_error_card,
    make_info_card,
    make_list_card,
    make_success_card,
    make_warning_card,
)

if TYPE_CHECKING:
    from core.bot import EmberBot

logger = logging.getLogger("ember.bot.admin")


# ══════════════════════════════════════════════════════════════════════
# /owner — bot owner only
# Truly restricted: interaction_check verifies bot ownership programmatically.
# Not visible to non-owners even if they guess the name.
# ══════════════════════════════════════════════════════════════════════


class _OwnerGroup(app_commands.Group):
    """Restricted to the bot owner. Use for global/destructive operations."""

    def __init__(self, bot: EmberBot):
        super().__init__(name="owner", description="Bot owner tools")
        self.bot = bot
        self.add_command(_OwnerSetGroup(bot))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if await self.bot.is_owner(interaction.user):
            return True
        await interaction.response.send_message(
            view=make_error_card(
                "🚫 Owner Only", "These commands are restricted to the bot owner."
            ),
            ephemeral=True,
        )
        return False

    @app_commands.command(name="shutdown", description="Gracefully shut down the bot")
    async def shutdown(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            view=make_warning_card("⚠️ Shutting Down", "Goodbye."),
            ephemeral=True,
        )
        logger.info("Shutdown by %s", interaction.user)
        await self.bot.close()

    @app_commands.command(name="restart", description="Restart the bot process")
    async def restart(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            view=make_warning_card("🔄 Restarting", "Bot is restarting…"),
            ephemeral=True,
        )
        logger.info("Restart by %s", interaction.user)
        import os as _os
        import sys

        _os.execv(sys.executable, [sys.executable] + sys.argv)

    @app_commands.command(
        name="sync_global", description="Sync slash commands globally (all servers)"
    )
    async def sync_global(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            synced = await self.bot.tree.sync()
            await interaction.followup.send(
                view=make_success_card(
                    "✅ Global Sync", f"Synced **{len(synced)}** commands globally."
                ),
                ephemeral=True,
            )
        except Exception as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Sync Failed", str(exc)), ephemeral=True
            )

    @app_commands.command(name="status", description="Show bot runtime info")
    async def status(self, interaction: discord.Interaction) -> None:
        from utils.formatting import humanize_number

        shard_line = ""
        if self.bot.shard_count and self.bot.shard_count > 1:
            shard_line = f"**Shards:** {self.bot.shard_count} (this: {self.bot.shard_id})\n"
        body = (
            f"**Uptime:** {self.bot.uptime}\n"
            f"**Latency:** {round(self.bot.latency * 1000, 1)}ms\n"
            f"{shard_line}"
            f"**Guilds:** {humanize_number(len(self.bot.guilds))}\n"
            f"**Users:** {humanize_number(sum(g.member_count or 0 for g in self.bot.guilds))}\n"
            f"**Cogs:** {len(self.bot.extensions)}\n"
            f"**Commands:** {len(list(self.bot.tree.walk_commands()))}\n"
        )
        await interaction.response.send_message(
            view=make_info_card("🤖 Bot Status", body), ephemeral=True
        )

    @app_commands.command(name="send", description="Send a message to a channel")
    @app_commands.describe(channel="Target channel", message="Message to send")
    async def send(
        self, interaction: discord.Interaction, channel: discord.TextChannel, message: str
    ) -> None:
        await channel.send(message)
        await interaction.response.send_message(
            view=make_success_card("✅ Sent", f"Message sent to {channel.mention}."),
            ephemeral=True,
        )


class _OwnerSetGroup(app_commands.Group):
    """Persistent runtime profile config (avatar/username/presence/...)."""

    _STATUS_CHOICES = [
        app_commands.Choice(name="Online", value="online"),
        app_commands.Choice(name="Idle", value="idle"),
        app_commands.Choice(name="Do Not Disturb", value="dnd"),
        app_commands.Choice(name="Invisible", value="invisible"),
    ]
    _ACTIVITY_CHOICES = [
        app_commands.Choice(name="Playing", value="playing"),
        app_commands.Choice(name="Listening", value="listening"),
        app_commands.Choice(name="Watching", value="watching"),
        app_commands.Choice(name="Competing", value="competing"),
        app_commands.Choice(name="Streaming", value="streaming"),
        app_commands.Choice(name="(clear)", value="clear"),
    ]

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="set", description="Set persistent bot profile / presence")
        self.bot = bot

    def _store(self):
        from core.store import Store

        return Store.for_cog("owner", None)

    @app_commands.command(name="username", description="Change the bot's username")
    @app_commands.describe(name="New username (2–32 chars)")
    async def username(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            await self.bot.user.edit(username=name)
        except discord.HTTPException as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(exc)), ephemeral=True
            )
            return
        store = self._store()
        await store.set("global", 0, "username", name)
        await interaction.followup.send(
            view=make_success_card("✅ Username", f"Set to **{name}**."), ephemeral=True
        )

    @app_commands.command(name="avatar", description="Change the bot's avatar from a URL")
    @app_commands.describe(url="Direct image URL (PNG/JPEG/GIF)")
    async def avatar(self, interaction: discord.Interaction, url: str) -> None:
        await interaction.response.defer(ephemeral=True)
        import aiohttp

        try:
            async with aiohttp.ClientSession() as session, session.get(url) as resp:
                resp.raise_for_status()
                data = await resp.read()
            await self.bot.user.edit(avatar=data)
        except Exception as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(exc)), ephemeral=True
            )
            return
        store = self._store()
        await store.set("global", 0, "avatar_url", url)
        await interaction.followup.send(
            view=make_success_card("✅ Avatar", "Updated."), ephemeral=True
        )

    @app_commands.command(name="nickname", description="Set the bot's nickname in this server")
    @app_commands.describe(nickname="New nickname (leave blank to clear)")
    async def nickname(self, interaction: discord.Interaction, nickname: str | None = None) -> None:
        if interaction.guild is None:
            await interaction.response.send_message(
                view=make_error_card("🚫 Server only", "Use this in a server."),
                ephemeral=True,
            )
            return
        try:
            await interaction.guild.me.edit(nick=nickname or None)
        except discord.HTTPException as exc:
            await interaction.response.send_message(
                view=make_error_card("❌ Failed", str(exc)), ephemeral=True
            )
            return
        await interaction.response.send_message(
            view=make_success_card("✅ Nickname", f"Set to **{nickname or '(cleared)'}**."),
            ephemeral=True,
        )

    @app_commands.command(name="status", description="Set the bot's presence status")
    @app_commands.choices(value=_STATUS_CHOICES)
    async def status(
        self, interaction: discord.Interaction, value: app_commands.Choice[str]
    ) -> None:
        store = self._store()
        await store.set("global", 0, "status", value.value)
        await self.bot.change_presence(status=discord.Status(value.value))
        await interaction.response.send_message(
            view=make_success_card("✅ Status", f"Now **{value.name}**."), ephemeral=True
        )

    @app_commands.command(name="presence", description="Set the bot's activity / playing text")
    @app_commands.choices(kind=_ACTIVITY_CHOICES)
    @app_commands.describe(
        kind="Activity type", text="Activity text", url="Stream URL (Streaming only)"
    )
    async def presence(
        self,
        interaction: discord.Interaction,
        kind: app_commands.Choice[str],
        text: str | None = None,
        url: str | None = None,
    ) -> None:
        store = self._store()
        if kind.value == "clear":
            await store.set("global", 0, "activity", None)
            await self.bot.change_presence(activity=None)
            await interaction.response.send_message(
                view=make_success_card("✅ Presence", "Cleared."), ephemeral=True
            )
            return
        if not text:
            await interaction.response.send_message(
                view=make_error_card("❌ Missing text", "Provide activity text."), ephemeral=True
            )
            return
        activity = _build_activity(kind.value, text, url)
        if activity is None:
            await interaction.response.send_message(
                view=make_error_card("❌ Invalid", "Could not build activity."), ephemeral=True
            )
            return
        await store.set("global", 0, "activity", {"type": kind.value, "text": text, "url": url})
        await self.bot.change_presence(activity=activity)
        await interaction.response.send_message(
            view=make_success_card("✅ Presence", f"{kind.name}: **{text}**"), ephemeral=True
        )


def _build_activity(kind: str, text: str, url: str | None) -> discord.BaseActivity | None:
    if kind == "playing":
        return discord.Game(name=text)
    if kind == "listening":
        return discord.Activity(type=discord.ActivityType.listening, name=text)
    if kind == "watching":
        return discord.Activity(type=discord.ActivityType.watching, name=text)
    if kind == "competing":
        return discord.Activity(type=discord.ActivityType.competing, name=text)
    if kind == "streaming":
        return discord.Streaming(name=text, url=url or "https://twitch.tv/discord")
    return None


async def apply_owner_profile(bot: EmberBot) -> None:
    """Re-apply persisted /owner set values on startup."""
    from core.store import Store

    store = Store.for_cog("owner", None)
    cfg = await store.get_all("global", 0)
    if not cfg:
        return
    status = cfg.get("status")
    activity_cfg = cfg.get("activity")
    activity = None
    if isinstance(activity_cfg, dict):
        activity = _build_activity(
            activity_cfg.get("type", ""),
            activity_cfg.get("text", ""),
            activity_cfg.get("url"),
        )
    try:
        await bot.change_presence(
            status=discord.Status(status) if status else discord.Status.online,
            activity=activity,
        )
    except Exception as exc:
        logger.warning("apply_owner_profile presence failed: %s", exc)


# ══════════════════════════════════════════════════════════════════════
# /admin — server admins + guild owners
# Restructured into sub-groups to stay under Discord's 25-command limit.
#
# Sub-groups:
#   /admin cog   reload|load|unload|list
#   /admin cfg   view|set|reset
#   /admin token list|set|delete
#   /admin bl    global_add|global_remove|guild_add|guild_remove|list
#   /admin wl    global_add|global_remove|guild_add|guild_remove|list
#   /admin ignore guild|unignore_guild|channel|unignore_channel|list
#   /admin help  per_page|show_brief
# Standalone: /admin sync
# ══════════════════════════════════════════════════════════════════════


class _AdminCogGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="cog", description="Load, unload, and reload cogs")
        self.bot = bot

    def _sync_manager_loaded(self, cog_name: str, loaded: bool) -> None:
        """Keep CogManager's loaded flag in sync after direct extension ops."""
        from core._cog_manager import get_manager

        manager = get_manager()
        info = manager._cogs.get(cog_name)
        if info is not None:
            info.loaded = loaded

    @app_commands.command(name="reload", description="Reload a cog")
    @app_commands.describe(name="Cog name (e.g. birthday, tempvc)")
    async def reload(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        for mod in [f"cogs.{name}.cog", f"cogs.{name}"]:
            if mod in self.bot.extensions:
                try:
                    await self.bot.reload_extension(mod)
                    self._sync_manager_loaded(name, True)
                    await interaction.followup.send(
                        view=make_success_card("🔄 Reloaded", f"`{mod}` reloaded."), ephemeral=True
                    )
                    return
                except Exception:
                    tb = traceback.format_exc()
                    self._sync_manager_loaded(name, False)
                    await interaction.followup.send(
                        view=make_error_card("❌ Failed", f"```\n{tb[-1800:]}\n```"), ephemeral=True
                    )
                    return
        await interaction.followup.send(
            view=make_error_card("❌ Not Found", f"`{name}` is not loaded."), ephemeral=True
        )

    @app_commands.command(name="load", description="Load a cog")
    @app_commands.describe(name="Cog name")
    async def load(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        for mod in [f"cogs.{name}.cog", f"cogs.{name}"]:
            try:
                await self.bot.load_extension(mod)
                self._sync_manager_loaded(name, True)
                await interaction.followup.send(
                    view=make_success_card("✅ Loaded", f"`{mod}` loaded."), ephemeral=True
                )
                return
            except commands.ExtensionAlreadyLoaded:
                await interaction.followup.send(
                    view=make_warning_card("⚠️ Already Loaded", f"`{mod}` is already loaded."),
                    ephemeral=True,
                )
                return
            except commands.ExtensionNotFound:
                continue
            except Exception:
                tb = traceback.format_exc()
                await interaction.followup.send(
                    view=make_error_card("❌ Failed", f"```\n{tb[-1800:]}\n```"), ephemeral=True
                )
                return
        await interaction.followup.send(
            view=make_error_card("❌ Not Found", f"No cog found for `{name}`."), ephemeral=True
        )

    @app_commands.command(name="unload", description="Unload a cog")
    @app_commands.describe(name="Cog name")
    async def unload(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        for mod in [f"cogs.{name}.cog", f"cogs.{name}"]:
            if mod in self.bot.extensions:
                try:
                    await self.bot.unload_extension(mod)
                    self._sync_manager_loaded(name, False)
                    await interaction.followup.send(
                        view=make_success_card("✅ Unloaded", f"`{mod}` unloaded."), ephemeral=True
                    )
                    return
                except Exception as exc:
                    await interaction.followup.send(
                        view=make_error_card("❌ Failed", str(exc)), ephemeral=True
                    )
                    return
        await interaction.followup.send(
            view=make_error_card("❌ Not Loaded", f"`{name}` is not currently loaded."),
            ephemeral=True,
        )

    @app_commands.command(name="list", description="List all loaded cogs")
    async def list_cogs(self, interaction: discord.Interaction) -> None:
        names = [f"`{e}`" for e in sorted(self.bot.extensions)]
        await interaction.response.send_message(
            view=make_list_card(f"Loaded Cogs ({len(names)})", names, numbered=False, per_page=20),
            ephemeral=True,
        )


class _AdminCfgGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="cfg", description="View and edit per-guild cog configuration")
        self.bot = bot

    @app_commands.command(name="view", description="View a cog's config for this server")
    @app_commands.describe(cog="Cog name (e.g. birthday, welcome)")
    async def view(self, interaction: discord.Interaction, cog: str) -> None:
        from core.store import get_cog_store

        store = get_cog_store(cog)
        if store is None:
            await interaction.response.send_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog}` not loaded."),
                ephemeral=True,
            )
            return
        cfg = await store.get_all("guild", interaction.guild.id)
        if not cfg:
            await interaction.response.send_message(
                view=make_info_card(f"⚙️ {cog} Config", "No settings configured yet."),
                ephemeral=True,
            )
            return
        lines = [f"`{k}`: `{v}`" for k, v in cfg.items()]
        await interaction.response.send_message(
            view=make_list_card(f"⚙️ {cog} Config", lines, numbered=False, per_page=20),
            ephemeral=True,
        )

    @app_commands.command(name="set", description="Set a config value for a cog")
    @app_commands.describe(cog="Cog name", key="Setting key", value="New value (JSON supported)")
    async def set_cfg(
        self, interaction: discord.Interaction, cog: str, key: str, value: str
    ) -> None:
        import json as _json

        from core.store import get_cog_store

        store = get_cog_store(cog)
        if store is None:
            await interaction.response.send_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog}` not loaded."),
                ephemeral=True,
            )
            return
        try:
            parsed = _json.loads(value)
        except _json.JSONDecodeError:
            parsed = value
        await store.set("guild", interaction.guild.id, key, parsed)
        await interaction.response.send_message(
            view=make_success_card("✅ Saved", f"`{cog}.{key}` = `{parsed}`"), ephemeral=True
        )

    @app_commands.command(name="reset", description="Reset all config for a cog in this server")
    @app_commands.describe(cog="Cog name")
    async def reset(self, interaction: discord.Interaction, cog: str) -> None:
        from core.store import get_cog_store

        store = get_cog_store(cog)
        if store is None:
            await interaction.response.send_message(
                view=make_error_card("❌ Not Found", f"Cog `{cog}` not loaded."),
                ephemeral=True,
            )
            return
        await store.delete("guild", interaction.guild.id)
        await interaction.response.send_message(
            view=make_success_card("✅ Reset", f"All `{cog}` config cleared for this server."),
            ephemeral=True,
        )


class _AdminTokenGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="token", description="Manage encrypted API tokens for cogs")
        self.bot = bot

    @app_commands.command(name="list", description="List stored API tokens for a cog")
    @app_commands.describe(cog="Cog name")
    async def list_tokens(self, interaction: discord.Interaction, cog: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.api_tokens import get_manager

        tokens = await get_manager().list_tokens(cog)
        if not tokens:
            await interaction.followup.send(
                view=make_info_card(f"🔑 {cog} Tokens", "No tokens stored."), ephemeral=True
            )
            return
        lines = [
            f"`{t['key']}`" + (f" — {t['description']}" if t["description"] else "") for t in tokens
        ]
        await interaction.followup.send(
            view=make_list_card(
                f"🔑 {cog} Tokens ({len(lines)})", lines, numbered=False, per_page=20
            ),
            ephemeral=True,
        )

    @app_commands.command(name="set", description="Store an API token for a cog")
    @app_commands.describe(
        cog="Cog name", key="Token key", value="Token value", description="Optional description"
    )
    async def set_token(
        self,
        interaction: discord.Interaction,
        cog: str,
        key: str,
        value: str,
        description: str = "",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.api_tokens import get_manager

        try:
            await get_manager().set_token(cog, key, value, description)
            await interaction.followup.send(
                view=make_success_card("✅ Saved", f"Token `{key}` stored for `{cog}`."),
                ephemeral=True,
            )
        except Exception as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Failed", f"```\n{exc}\n```"), ephemeral=True
            )

    @app_commands.command(name="delete", description="Delete a stored API token")
    @app_commands.describe(cog="Cog name", key="Token key to delete")
    async def delete_token(self, interaction: discord.Interaction, cog: str, key: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.api_tokens import get_manager

        if await get_manager().delete_token(cog, key):
            await interaction.followup.send(
                view=make_success_card("🗑️ Deleted", f"Token `{key}` removed from `{cog}`."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_error_card("❌ Not Found", f"Token `{key}` not found in `{cog}`."),
                ephemeral=True,
            )


class _AdminBlacklistGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="bl", description="Manage user blacklists (global and per-guild)")
        self.bot = bot

    @app_commands.command(name="global_add", description="Add user to global blacklist")
    @app_commands.describe(user="User mention or ID")
    async def global_add(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import add_global_blacklist, parse_user_id

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        await add_global_blacklist(uid)
        await interaction.followup.send(
            view=make_success_card("✅ Blacklisted", f"<@{uid}> added to global blacklist."),
            ephemeral=True,
        )

    @app_commands.command(name="global_remove", description="Remove user from global blacklist")
    @app_commands.describe(user="User mention or ID")
    async def global_remove(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import parse_user_id, remove_global_blacklist

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        if await remove_global_blacklist(uid):
            await interaction.followup.send(
                view=make_success_card("✅ Removed", f"<@{uid}> removed from global blacklist."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Found", f"<@{uid}> not in global blacklist."),
                ephemeral=True,
            )

    @app_commands.command(name="guild_add", description="Add user to this server's blacklist")
    @app_commands.describe(user="User mention or ID")
    async def guild_add(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import add_guild_blacklist, parse_user_id

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        await add_guild_blacklist(interaction.guild.id, uid)
        await interaction.followup.send(
            view=make_success_card("✅ Blacklisted", f"<@{uid}> blacklisted in this server."),
            ephemeral=True,
        )

    @app_commands.command(
        name="guild_remove", description="Remove user from this server's blacklist"
    )
    @app_commands.describe(user="User mention or ID")
    async def guild_remove(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import parse_user_id, remove_guild_blacklist

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        if await remove_guild_blacklist(interaction.guild.id, uid):
            await interaction.followup.send(
                view=make_success_card("✅ Removed", f"<@{uid}> removed from server blacklist."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Found", f"<@{uid}> not in server blacklist."),
                ephemeral=True,
            )

    @app_commands.command(name="list", description="List globally blacklisted users")
    async def list_bl(self, interaction: discord.Interaction) -> None:
        from core.whitelist_blacklist import get_blacklist

        blacklist = await get_blacklist()
        if not blacklist:
            await interaction.response.send_message(
                view=make_info_card("📋 Global Blacklist", "No users blacklisted globally."),
                ephemeral=True,
            )
            return
        lines = [f"<@{uid}> (`{uid}`)" for uid in sorted(blacklist)]
        await interaction.response.send_message(
            view=make_list_card(f"📋 Global Blacklist ({len(lines)})", lines, per_page=20),
            ephemeral=True,
        )


class _AdminWhitelistGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="wl", description="Manage user whitelists (global and per-guild)")
        self.bot = bot

    @app_commands.command(name="global_add", description="Add user to global whitelist")
    @app_commands.describe(user="User mention or ID")
    async def global_add(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import add_global_whitelist, parse_user_id

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        await add_global_whitelist(uid)
        await interaction.followup.send(
            view=make_success_card("✅ Whitelisted", f"<@{uid}> added to global whitelist."),
            ephemeral=True,
        )

    @app_commands.command(name="global_remove", description="Remove user from global whitelist")
    @app_commands.describe(user="User mention or ID")
    async def global_remove(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import parse_user_id, remove_global_whitelist

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        if await remove_global_whitelist(uid):
            await interaction.followup.send(
                view=make_success_card("✅ Removed", f"<@{uid}> removed from global whitelist."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Found", f"<@{uid}> not in global whitelist."),
                ephemeral=True,
            )

    @app_commands.command(name="guild_add", description="Add user to this server's whitelist")
    @app_commands.describe(user="User mention or ID")
    async def guild_add(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import add_guild_whitelist, parse_user_id

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        await add_guild_whitelist(interaction.guild.id, uid)
        await interaction.followup.send(
            view=make_success_card("✅ Whitelisted", f"<@{uid}> added to server whitelist."),
            ephemeral=True,
        )

    @app_commands.command(
        name="guild_remove", description="Remove user from this server's whitelist"
    )
    @app_commands.describe(user="User mention or ID")
    async def guild_remove(self, interaction: discord.Interaction, user: str) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.whitelist_blacklist import parse_user_id, remove_guild_whitelist

        uid = parse_user_id(user)
        if not uid:
            await interaction.followup.send(
                view=make_error_card("❌ Invalid", "Provide a user mention or ID."), ephemeral=True
            )
            return
        if await remove_guild_whitelist(interaction.guild.id, uid):
            await interaction.followup.send(
                view=make_success_card("✅ Removed", f"<@{uid}> removed from server whitelist."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Found", f"<@{uid}> not in server whitelist."),
                ephemeral=True,
            )

    @app_commands.command(name="list", description="List globally whitelisted users")
    async def list_wl(self, interaction: discord.Interaction) -> None:
        from core.whitelist_blacklist import get_whitelist

        whitelist = await get_whitelist()
        if not whitelist:
            await interaction.response.send_message(
                view=make_info_card(
                    "📋 Global Whitelist", "Whitelist is empty (all users allowed)."
                ),
                ephemeral=True,
            )
            return
        lines = [f"<@{uid}> (`{uid}`)" for uid in sorted(whitelist)]
        await interaction.response.send_message(
            view=make_list_card(f"📋 Global Whitelist ({len(lines)})", lines, per_page=20),
            ephemeral=True,
        )


class _AdminIgnoreGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="ignore", description="Suppress bot responses in guilds or channels")
        self.bot = bot

    @app_commands.command(name="guild", description="Disable all bot commands in this server")
    async def ignore_guild(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.ignore import ignore_guild

        await ignore_guild(interaction.guild.id)
        await interaction.followup.send(
            view=make_warning_card(
                "⛔ Guild Ignored", "All bot commands are now disabled in this server."
            ),
            ephemeral=True,
        )

    @app_commands.command(
        name="unignore_guild", description="Re-enable bot commands in this server"
    )
    async def unignore_guild(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.ignore import unignore_guild

        if await unignore_guild(interaction.guild.id):
            await interaction.followup.send(
                view=make_success_card("✅ Active", "Bot commands are now enabled in this server."),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Ignored", "This server is not currently ignored."),
                ephemeral=True,
            )

    @app_commands.command(name="channel", description="Disable bot commands in this channel")
    async def ignore_channel(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.ignore import ignore_channel

        await ignore_channel(interaction.guild.id, interaction.channel.id)
        await interaction.followup.send(
            view=make_warning_card(
                "⛔ Channel Ignored", f"Bot commands disabled in {interaction.channel.mention}."
            ),
            ephemeral=True,
        )

    @app_commands.command(
        name="unignore_channel", description="Re-enable bot commands in this channel"
    )
    async def unignore_channel(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.ignore import unignore_channel

        if await unignore_channel(interaction.guild.id, interaction.channel.id):
            await interaction.followup.send(
                view=make_success_card(
                    "✅ Active", f"Bot commands enabled in {interaction.channel.mention}."
                ),
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                view=make_info_card("ℹ️ Not Ignored", "This channel is not currently ignored."),
                ephemeral=True,
            )

    @app_commands.command(name="list", description="Show ignored channels and guild status")
    async def list_ignores(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.ignore import list_guild_ignores

        data = await list_guild_ignores(interaction.guild.id)
        lines: list[str] = []
        if data["guild_ignored"]:
            lines.append("⚠️ **Guild-wide ignore is active**")
        if data["channels"]:
            lines.append("**Ignored channels:**")
            for ch_id in sorted(data["channels"]):
                ch = interaction.guild.get_channel(ch_id)
                lines.append(f"• {ch.mention if ch else f'`{ch_id}` (deleted)'}")
        if not lines:
            lines.append("✅ No ignore rules configured.")
        await interaction.followup.send(
            view=make_info_card("📋 Ignore List", "\n".join(lines)), ephemeral=True
        )


class _AdminHelpGroup(app_commands.Group):
    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="help", description="Configure the help command display")
        self.bot = bot

    @app_commands.command(name="per_page", description="Set commands per page for help (5-20)")
    @app_commands.describe(count="Commands per page")
    async def per_page(
        self, interaction: discord.Interaction, count: app_commands.Range[int, 5, 20]
    ) -> None:
        from core.help import _config as help_config

        await help_config.set("guild", interaction.guild.id, "help_per_page", count)
        await interaction.response.send_message(
            view=make_success_card("✅ Saved", f"Help will show {count} commands per page."),
            ephemeral=True,
        )

    @app_commands.command(
        name="show_brief", description="Toggle showing command descriptions in help"
    )
    async def show_brief(self, interaction: discord.Interaction) -> None:
        from core.help import _config as help_config

        current = await help_config.get("guild", interaction.guild.id, "help_show_brief")
        new = not bool(current)
        await help_config.set("guild", interaction.guild.id, "help_show_brief", new)
        state = "enabled" if new else "disabled"
        await interaction.response.send_message(
            view=make_success_card("✅ Saved", f"Command descriptions are now {state}."),
            ephemeral=True,
        )


class _AdminPermissionsGroup(app_commands.Group):
    """Manage permission overrides for commands."""

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="permissions", description="Manage command permission overrides")
        self.bot = bot

    @app_commands.command(
        name="allow", description="Allow a user/role to use a command, overriding the default"
    )
    @app_commands.describe(
        command="Command in format cog:command (e.g., moderation:kick)",
        model="User or role (user:@User, role:@Role, or default)",
        scope="Global or guild-only",
    )
    async def allow(
        self,
        interaction: discord.Interaction,
        command: str,
        model: str,
        scope: Literal["global", "guild"] = "guild",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.permissions import PermissionRegistry
        from core.permissions_engine import PermState

        # Parse model
        model_id = self._parse_model(model)
        if model_id is None:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Invalid", "Model must be `user:@User`, `role:@Role`, or `default`."
                ),
                ephemeral=True,
            )
            return

        # Determine guild scope
        guild_id = interaction.guild.id if scope == "guild" else None

        # Build rule key
        rule_model = model_id  # already prefixed with type:

        try:
            registry = await PermissionRegistry.get(self.bot)
            await registry.set_rule(command, rule_model, PermState.ACTIVE_ALLOW, guild_id=guild_id)
            scope_txt = "globally" if guild_id is None else f"in {interaction.guild.name}"
            await interaction.followup.send(
                view=make_success_card(
                    "✅ Allowed", f"{model} can now use `{command}` ({scope_txt})."
                ),
                ephemeral=True,
            )
        except Exception as e:
            logger.error("Failed to set allow rule: %s", e, exc_info=True)
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(e)), ephemeral=True
            )

    @app_commands.command(name="deny", description="Deny a user/role from using a command")
    @app_commands.describe(
        command="Command in format cog:command",
        model="User or role (user:@User, role:@Role, or default)",
        scope="Global or guild-only",
    )
    async def deny(
        self,
        interaction: discord.Interaction,
        command: str,
        model: str,
        scope: Literal["global", "guild"] = "guild",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.permissions import PermissionRegistry
        from core.permissions_engine import PermState

        model_id = self._parse_model(model)
        if model_id is None:
            await interaction.followup.send(
                view=make_error_card(
                    "❌ Invalid", "Model must be `user:@User`, `role:@Role`, or `default`."
                ),
                ephemeral=True,
            )
            return

        guild_id = interaction.guild.id if scope == "guild" else None

        try:
            registry = await PermissionRegistry.get(self.bot)
            await registry.set_rule(command, model_id, PermState.ACTIVE_DENY, guild_id=guild_id)
            scope_txt = "globally" if guild_id is None else f"in {interaction.guild.name}"
            await interaction.followup.send(
                view=make_success_card(
                    "🚫 Denied", f"{model} cannot use `{command}` ({scope_txt})."
                ),
                ephemeral=True,
            )
        except Exception as e:
            logger.error("Failed to set deny rule: %s", e, exc_info=True)
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(e)), ephemeral=True
            )

    @app_commands.command(name="clear", description="Clear a permission rule")
    @app_commands.describe(
        command="Command in format cog:command",
        model="User or role to clear (omit to clear all for command)",
        scope="Global or guild-only",
    )
    async def clear(
        self,
        interaction: discord.Interaction,
        command: str,
        model: str | None = None,
        scope: Literal["global", "guild"] = "guild",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.permissions import PermissionRegistry

        guild_id = interaction.guild.id if scope == "guild" else None

        if model:
            model_id = self._parse_model(model)
            if model_id is None:
                await interaction.followup.send(
                    view=make_error_card(
                        "❌ Invalid", "Model must be `user:@User`, `role:@Role`, or `default`."
                    ),
                    ephemeral=True,
                )
                return
            try:
                registry = await PermissionRegistry.get(self.bot)
                existed = await registry.clear_rule(command, model_id, guild_id=guild_id)
                if existed:
                    await interaction.followup.send(
                        view=make_success_card(
                            "✅ Cleared", f"Removed rule for {model} on `{command}`."
                        ),
                        ephemeral=True,
                    )
                else:
                    await interaction.followup.send(
                        view=make_info_card("ℹ️ Not Found", f"No rule for {model} on `{command}`."),
                        ephemeral=True,
                    )
            except Exception as e:
                logger.error("Failed to clear rule: %s", e, exc_info=True)
                await interaction.followup.send(
                    view=make_error_card("❌ Failed", str(e)), ephemeral=True
                )
        else:
            # Clear all rules for this command in this scope
            try:
                registry = await PermissionRegistry.get(self.bot)
                rules = await registry.get_rules(command)
                if rules:
                    if guild_id:
                        rules.clear_all(guild_id=guild_id)
                        await registry._save_rules()
                        await interaction.followup.send(
                            view=make_success_card(
                                "✅ Cleared", f"All rules for `{command}` cleared in this server."
                            ),
                            ephemeral=True,
                        )
                    else:
                        rules.clear_all(guild_id=None)
                        await registry._save_rules()
                        await interaction.followup.send(
                            view=make_success_card(
                                "✅ Cleared", f"All global rules for `{command}` cleared."
                            ),
                            ephemeral=True,
                        )
                else:
                    await interaction.followup.send(
                        view=make_info_card("ℹ️ No Rules", f"No rules configured for `{command}`."),
                        ephemeral=True,
                    )
            except Exception as e:
                logger.error("Failed to clear rules: %s", e, exc_info=True)
                await interaction.followup.send(
                    view=make_error_card("❌ Failed", str(e)), ephemeral=True
                )

    @app_commands.command(name="list", description="List permission rules for a command")
    @app_commands.describe(command="Command in format cog:command (omit to list all)")
    async def list_rules(
        self, interaction: discord.Interaction, command: str | None = None
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        from core.permissions import PermissionRegistry

        try:
            registry = await PermissionRegistry.get(self.bot)

            if command:
                # Show rules for specific command
                rules = await registry.get_rules(command)
                if not rules:
                    await interaction.followup.send(
                        view=make_info_card("📋 No Rules", f"No permission rules for `{command}`."),
                        ephemeral=True,
                    )
                    return

                lines = [f"**{command}**"]
                # Global rules
                if rules.global_rules:
                    lines.append("__Global Rules:__")
                    for model, state in rules.global_rules.items():
                        lines.append(f"• {model}: {state.name}")
                # Guild rules
                if rules.guild_rules:
                    lines.append("__Guild Rules:__")
                    for guild_id, grules in rules.guild_rules.items():
                        guild = self.bot.get_guild(int(guild_id))
                        guild_name = guild.name if guild else f"Guild {guild_id}"
                        for model, state in grules.items():
                            lines.append(f"• [{guild_name}] {model}: {state.name}")

                await interaction.followup.send(
                    view=make_info_card(f"📋 Permission Rules: {command}", "\n".join(lines)),
                    ephemeral=True,
                )
            else:
                # List all commands with rules
                all_commands = registry.get_all_commands()
                if not all_commands:
                    await interaction.followup.send(
                        view=make_info_card("📋 No Rules", "No commands have permission rules."),
                        ephemeral=True,
                    )
                    return
                lines = [f"**{len(all_commands)} commands have rules:**"]
                for cmd in sorted(all_commands):
                    info = registry.get_command_info(cmd)
                    if info and info.get("privilege_level"):
                        lines.append(f"• `{cmd}` — {info['privilege_level']}")
                    else:
                        lines.append(f"• `{cmd}`")
                await interaction.followup.send(
                    view=make_list_card("📋 All Command Rules", lines, per_page=25, numbered=False),
                    ephemeral=True,
                )
        except Exception as e:
            logger.error("Failed to list rules: %s", e, exc_info=True)
            await interaction.followup.send(
                view=make_error_card("❌ Failed", str(e)), ephemeral=True
            )

    def _parse_model(self, model_str: str) -> str | None:
        """Parse a model specifier into 'type:id' format.
        Accepts: user:@User, role:@Role, user:123456, role:789012, default
        """
        model_str = model_str.strip().lower()
        if model_str == "default":
            return "default"
        if model_str.startswith("user:"):
            user_id = self._extract_id(model_str[5:])
            return f"user:{user_id}" if user_id else None
        if model_str.startswith("role:"):
            role_id = self._extract_id(model_str[5:])
            return f"role:{role_id}" if role_id else None
        # Also accept plain @User or @Role mention format
        if model_str.startswith("@"):
            # Could be a mention or just a name; we need ID
            # This is hard without discord.py objects. We'll accept user:ID format only.
            return None
        return None

    def _extract_id(self, id_str: str) -> str | None:
        """Extract numeric ID from string (handles mentions)."""
        # If it's a mention like <@123456>, strip angles
        if id_str.startswith("<@") and id_str.endswith(">"):
            id_str = id_str[2:-1]
            if id_str.startswith("!"):
                id_str = id_str[1:]
        if id_str.isdigit():
            return id_str
        return None


class _AdminPluginGroup(app_commands.Group):
    """Install, update, and remove cog plugins from git repositories."""

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="plugin", description="Manage installed cog plugins")
        self.bot = bot

    @app_commands.command(name="install", description="Install a cog from a git repository")
    @app_commands.describe(
        url="Git repository URL",
        name="Override the cog name (defaults to repo name)",
        branch="Git branch to install from (default: main)",
    )
    async def install(
        self,
        interaction: discord.Interaction,
        url: str,
        name: str | None = None,
        branch: str = "main",
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        ok, msg = await self.bot.downloader.install(url, name=name, branch=branch)
        card = (
            make_success_card("📦 Installed", msg)
            if ok
            else make_error_card("❌ Install Failed", msg)
        )
        await interaction.followup.send(view=card, ephemeral=True)

    @app_commands.command(
        name="update", description="Update an installed plugin to its latest commit"
    )
    @app_commands.describe(name="Plugin name")
    async def update(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        ok, msg = await self.bot.downloader.update(name)
        card = (
            make_success_card("🔄 Updated", msg) if ok else make_error_card("❌ Update Failed", msg)
        )
        await interaction.followup.send(view=card, ephemeral=True)

    @app_commands.command(name="uninstall", description="Uninstall a plugin")
    @app_commands.describe(name="Plugin name")
    async def uninstall(self, interaction: discord.Interaction, name: str) -> None:
        await interaction.response.defer(ephemeral=True)
        ok, msg = await self.bot.downloader.uninstall(name)
        card = (
            make_success_card("🗑️ Uninstalled", msg)
            if ok
            else make_error_card("❌ Uninstall Failed", msg)
        )
        await interaction.followup.send(view=card, ephemeral=True)

    @app_commands.command(name="list", description="List all installed plugins")
    async def list_plugins(self, interaction: discord.Interaction) -> None:
        repos = self.bot.downloader.list_installed()
        if not repos:
            await interaction.response.send_message(
                view=make_info_card("📦 Plugins", "No plugins installed yet."), ephemeral=True
            )
            return
        lines = [
            f"**{r['name']}** — `{r['commit']}` on `{r['branch']}`\n  {r['repo_url']}"
            for r in repos
        ]
        await interaction.response.send_message(
            view=make_list_card(
                f"📦 Installed Plugins ({len(lines)})", lines, numbered=False, per_page=10
            ),
            ephemeral=True,
        )


class _AdminPrefixGroup(app_commands.Group):
    """Manage per-guild command prefixes for prefix commands."""

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="prefix", description="Manage prefix command triggers")
        self.bot = bot

    @app_commands.command(name="list", description="Show current prefixes for this server")
    async def list_prefixes(self, interaction: discord.Interaction) -> None:
        from core.prefix import get_guild_prefixes

        prefixes = await get_guild_prefixes(interaction.guild.id if interaction.guild else None)
        body = "\n".join(f"• `{p}`" for p in prefixes) or "*(none set)*"
        await interaction.response.send_message(
            view=make_info_card("📋 Prefixes", body), ephemeral=True
        )

    @app_commands.command(name="add", description="Add a prefix for this server")
    @app_commands.describe(prefix="The prefix to add (e.g. ! or ember)")
    async def add_prefix(self, interaction: discord.Interaction, prefix: str) -> None:
        from core.prefix import add_guild_prefix

        prefix = prefix.strip()
        if not prefix:
            await interaction.response.send_message(
                view=make_error_card("❌ Invalid", "Prefix cannot be empty."), ephemeral=True
            )
            return
        if len(prefix) > 10:
            await interaction.response.send_message(
                view=make_error_card("❌ Too Long", "Prefix must be 10 characters or fewer."),
                ephemeral=True,
            )
            return
        await add_guild_prefix(interaction.guild.id, prefix)
        await interaction.response.send_message(
            view=make_success_card("✅ Added", f"Prefix `{prefix}` added."), ephemeral=True
        )

    @app_commands.command(name="remove", description="Remove a prefix from this server")
    @app_commands.describe(prefix="The prefix to remove")
    async def remove_prefix(self, interaction: discord.Interaction, prefix: str) -> None:
        from core.prefix import remove_guild_prefix

        await remove_guild_prefix(interaction.guild.id, prefix)
        await interaction.response.send_message(
            view=make_success_card("✅ Removed", f"Prefix `{prefix}` removed."), ephemeral=True
        )

    @app_commands.command(name="reset", description="Reset to default prefixes")
    async def reset_prefixes(self, interaction: discord.Interaction) -> None:
        from core.prefix import clear_guild_prefixes

        await clear_guild_prefixes(interaction.guild.id)
        await interaction.response.send_message(
            view=make_success_card("✅ Reset", "Prefixes reset to defaults."), ephemeral=True
        )


@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
class _AdminGroup(app_commands.Group):
    """Server admin tools. Visible only to users with Administrator by default."""

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="admin", description="Server administration tools")
        self.bot = bot
        self.add_command(_AdminCogGroup(bot))
        self.add_command(_AdminCfgGroup(bot))
        self.add_command(_AdminTokenGroup(bot))
        self.add_command(_AdminBlacklistGroup(bot))
        self.add_command(_AdminWhitelistGroup(bot))
        self.add_command(_AdminIgnoreGroup(bot))
        self.add_command(_AdminHelpGroup(bot))
        self.add_command(_AdminPermissionsGroup(bot))
        self.add_command(_AdminPluginGroup(bot))
        self.add_command(_AdminDataGroup(bot))
        self.add_command(_AdminPrefixGroup(bot))

    @app_commands.command(
        name="debuginfo",
        description="Bot owner: dump environment / version info for issue reports.",
    )
    @app_commands.default_permissions(administrator=True)
    async def debuginfo(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        if interaction.user.id not in getattr(self.bot, "owner_ids", set()):
            await interaction.followup.send(
                view=make_error_card("🚫 Bot Owner Only", "This command is restricted."),
                ephemeral=True,
            )
            return

        from core.cli import debuginfo as _debuginfo

        text = _debuginfo()
        if len(text) <= 1900:
            await interaction.followup.send(f"```\n{text}\n```", ephemeral=True)
            return
        import io

        file = discord.File(fp=io.BytesIO(text.encode("utf-8")), filename="ember_debuginfo.txt")
        await interaction.followup.send(file=file, ephemeral=True)

    @app_commands.command(name="sync", description="Sync slash commands to this server")
    async def sync(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        try:
            self.bot.tree.copy_global_to(guild=interaction.guild)
            synced = await self.bot.tree.sync(guild=interaction.guild)
            await interaction.followup.send(
                view=make_success_card(
                    "✅ Synced", f"Synced **{len(synced)}** command(s) to this server."
                ),
                ephemeral=True,
            )
        except Exception as exc:
            await interaction.followup.send(
                view=make_error_card("❌ Sync Failed", str(exc)), ephemeral=True
            )


class _AdminDataGroup(app_commands.Group):
    """GDPR / data management commands. Bot owner only."""

    def __init__(self, bot: EmberBot) -> None:
        super().__init__(name="data", description="User data management (GDPR)")
        self.bot = bot

    @app_commands.command(
        name="export", description="Export all stored data for a user (bot owner only)."
    )
    @app_commands.describe(user_id="Discord user ID to export data for")
    @app_commands.default_permissions(administrator=True)
    async def data_export(self, interaction: discord.Interaction, user_id: str) -> None:
        await interaction.response.defer(ephemeral=True)
        import io
        import json as _json

        from core.gdpr import export_user_data

        uid = int(user_id)
        export = await export_user_data(self.bot, uid)

        if not export:
            await interaction.followup.send(
                view=make_info_card("No data found", f"No stored data for user `{uid}`."),
                ephemeral=True,
            )
            return

        payload = _json.dumps(export, indent=2, default=str).encode("utf-8")
        file = discord.File(fp=io.BytesIO(payload), filename=f"user_export_{uid}.json")
        await interaction.followup.send(file=file, ephemeral=True)

    @app_commands.command(
        name="forget",
        description="Purge all stored data for a user across every cog (bot owner only).",
    )
    @app_commands.describe(
        user_id="Discord user ID to forget",
        requester="Who is requesting the deletion (affects retention policy)",
    )
    @app_commands.choices(
        requester=[
            app_commands.Choice(name="Bot owner", value="owner"),
            app_commands.Choice(name="User self-request", value="user"),
            app_commands.Choice(name="User strict erasure", value="user_strict"),
            app_commands.Choice(name="Discord-deleted account", value="discord_deleted_user"),
        ]
    )
    @app_commands.default_permissions(administrator=True)
    async def data_forget(
        self,
        interaction: discord.Interaction,
        user_id: str,
        requester: app_commands.Choice[str] | None = None,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        import io
        import json as _json

        from core.gdpr import RequesterType, forget_user_data

        if interaction.user.id not in getattr(self.bot, "owner_ids", set()):
            await interaction.followup.send(
                view=make_error_card("🚫 Bot Owner Only", "This command is restricted."),
                ephemeral=True,
            )
            return

        uid = int(user_id)
        rtype = RequesterType(requester.value) if requester else RequesterType.OWNER
        summary = await forget_user_data(self.bot, uid, requester=rtype)

        payload = _json.dumps(summary, indent=2, default=str).encode("utf-8")
        file = discord.File(fp=io.BytesIO(payload), filename=f"user_forget_{uid}.json")
        await interaction.followup.send(
            view=make_success_card(
                "🧹 Forget complete",
                f"Purged data for `{uid}` (requester=`{rtype.value}`).",
            ),
            file=file,
            ephemeral=True,
        )
