from __future__ import annotations

import logging
import re
from typing import Any

from core._drivers.base import BaseDriver
from core.errors import UnsupportedDriverError
from core.store import Store

logger = logging.getLogger("ember.database")


def _db_identifier(cog_name: str) -> int:
    return hash(cog_name) & 0xFFFFFFFF


def _parse_where(where: str, params: tuple) -> dict[str, Any]:
    """Convert ``col = ? AND col2 = ?`` into ``{col: val, col2: val2}``.

    Only ``=`` equality joined by ``AND`` is supported.
    """
    if not where:
        return {}
    parts = re.split(r"\s+AND\s+", where.strip(), flags=re.IGNORECASE)
    if len(parts) != len(params):
        raise UnsupportedDriverError(
            f"WHERE clause has {len(parts)} condition(s) but {len(params)} parameter(s)."
        ) from None
    result: dict[str, Any] = {}
    for part, val in zip(parts, params, strict=True):
        m = re.match(r"^\s*(\w+)\s*=\s*\?\s*$", part)
        if not m:
            raise UnsupportedDriverError(
                f"Cannot translate '{part.strip()}' — only 'col = ?' equality is supported."
            ) from None
        result[m.group(1)] = val
    return result


class DatabaseManager:
    """Driver-agnostic data API backed by Store.

    Subclass and override ``initialize_tables()`` to register DDL; call
    ``await self.execute(ddl)`` inside it on SQL backends or
    ``self._store.register_table(ddl)`` + ``await self._store.initialize()``
    for driver-neutral schema registration.
    """

    def __init__(self, cog_name: str):
        self.cog_name = cog_name
        self._store = Store.for_cog(cog_name, _db_identifier(cog_name))

    @property
    def _sql_capable(self) -> bool:
        """True when the active driver overrides execute_sql (SQLite / Postgres)."""
        cls_method = getattr(type(self._store._driver), "execute_sql", None)
        return cls_method is not None and cls_method is not BaseDriver.execute_sql

    async def initialize(self) -> None:
        await self._store.initialize()
        await self.initialize_tables()

    async def initialize_tables(self) -> None:
        """Override in subclasses to run CREATE TABLE / index statements."""

    async def execute(self, sql: str, params: tuple = ()) -> int:
        """Execute a write statement. Returns rowcount."""
        try:
            return await self._store.execute(sql, params)
        except (NotImplementedError, AttributeError):
            raise UnsupportedDriverError(
                "Raw SQL is not supported on the active backend. " "Use SQLite or Postgres."
            ) from None

    async def execute_many(self, sql: str, param_list: list[tuple]) -> None:
        for params in param_list:
            await self.execute(sql, params)

    async def execute_script(self, script: str) -> None:
        for stmt in script.split(";"):
            stmt = stmt.strip()
            if stmt:
                await self.execute(stmt)

    async def fetch(self, sql: str, params: tuple = ()) -> list[dict]:
        """Execute a SELECT and return all rows as dicts."""
        try:
            return await self._store.query(sql, params)
        except (NotImplementedError, AttributeError):
            raise UnsupportedDriverError(
                "Raw SQL is not supported on the active backend. " "Use SQLite or Postgres."
            ) from None

    async def fetch_one(self, sql: str, params: tuple = ()) -> dict | None:
        rows = await self.fetch(sql, params)
        return rows[0] if rows else None

    async def get(self, table: str, where: str, params: tuple = ()) -> dict | None:
        if self._sql_capable:
            return await self.fetch_one(f"SELECT * FROM {table} WHERE {where}", params)
        return await self._store.find_one(table, **_parse_where(where, params))

    async def get_all(
        self, table: str, where: str = "", params: tuple = (), order_by: str = ""
    ) -> list[dict]:
        if self._sql_capable:
            sql = f"SELECT * FROM {table}"
            if where:
                sql += f" WHERE {where}"
            if order_by:
                sql += f" ORDER BY {order_by}"
            return await self.fetch(sql, params)
        filters = _parse_where(where, params) if where else {}
        return await self._store.find(table, order_by=order_by, **filters)

    async def save(self, table: str, data: dict[str, Any]) -> None:
        if self._sql_capable:
            cols = list(data.keys())
            ph = ", ".join("?" * len(cols))
            await self.execute(
                f"INSERT OR REPLACE INTO {table} ({', '.join(cols)}) VALUES ({ph})",
                tuple(data[c] for c in cols),
            )
        else:
            await self._store.store(table, data)

    async def update(self, table: str, data: dict[str, Any], where: str, params: tuple = ()) -> int:
        if self._sql_capable:
            set_clause = ", ".join(f"{k} = ?" for k in data)
            return await self.execute(
                f"UPDATE {table} SET {set_clause} WHERE {where}",
                tuple(data.values()) + params,
            )
        filters = _parse_where(where, params)
        rows = await self._store.find(table, **filters)
        for row in rows:
            await self._store.store(table, {**row, **data})
        return len(rows)

    async def delete(self, table: str, where: str, params: tuple = ()) -> int:
        if self._sql_capable:
            return await self.execute(f"DELETE FROM {table} WHERE {where}", params)
        return await self._store.remove(table, **_parse_where(where, params))

    async def count(self, table: str, where: str = "", params: tuple = ()) -> int:
        if self._sql_capable:
            sql = f"SELECT COUNT(*) FROM {table}"
            if where:
                sql += f" WHERE {where}"
            row = await self.fetch_one(sql, params)
            return next(iter(row.values())) if row else 0
        filters = _parse_where(where, params) if where else {}
        return await self._store.count(table, **filters)

    async def exists(self, table: str, where: str, params: tuple = ()) -> bool:
        return await self.count(table, where, params) > 0

    async def get_guild(
        self, table: str, guild_id: int, extra_where: str = "", params: tuple = ()
    ) -> dict | None:
        if extra_where:
            return await self.get(table, f"{extra_where} AND guild_id = ?", params + (guild_id,))
        return await self.get(table, "guild_id = ?", (guild_id,))

    async def get_all_guild(
        self,
        table: str,
        guild_id: int,
        extra_where: str = "",
        params: tuple = (),
        order_by: str = "",
    ) -> list[dict]:
        if extra_where:
            return await self.get_all(
                table, f"{extra_where} AND guild_id = ?", params + (guild_id,), order_by
            )
        return await self.get_all(table, "guild_id = ?", (guild_id,), order_by)

    async def save_guild(self, table: str, guild_id: int, data: dict[str, Any]) -> None:
        await self.save(table, {"guild_id": guild_id, **data})

    async def delete_guild(
        self, table: str, guild_id: int, extra_where: str = "", params: tuple = ()
    ) -> int:
        if extra_where:
            return await self.delete(table, f"{extra_where} AND guild_id = ?", params + (guild_id,))
        return await self.delete(table, "guild_id = ?", (guild_id,))
