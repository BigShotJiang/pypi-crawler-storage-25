from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

import discord

from core.database import DatabaseManager
from utils.cards import make_case_card

log = logging.getLogger("ember.modlog")

# ══════════════════════════════════════════════════════════════
# Built-in case types
# ══════════════════════════════════════════════════════════════


@dataclass
class CaseType:
    name: str
    emoji: str
    label: str
    color: str = "#5865F2"  # hex string


_CASE_TYPES: dict[str, CaseType] = {}


def _register_builtins() -> None:
    builtins = [
        CaseType("ban", "🔨", "Ban", "#ED4245"),
        CaseType("softban", "💨", "Softban", "#FEE75C"),
        CaseType("hackban", "🔨", "Hackban", "#ED4245"),
        CaseType("kick", "👢", "Kick", "#FEE75C"),
        CaseType("warn", "⚠️", "Warning", "#FEE75C"),
        CaseType("timeout", "⏱️", "Timeout", "#FF6B35"),
        CaseType("mute", "🔇", "Mute", "#FF6B35"),
        CaseType("unban", "🕊️", "Unban", "#57F287"),
        CaseType("unmute", "🔊", "Unmute", "#57F287"),
        CaseType("note", "📝", "Note", "#5865F2"),
        CaseType("voicekick", "🎙️", "Voice Kick", "#FEE75C"),
        CaseType("voiceban", "🔇", "Voice Ban", "#ED4245"),
        CaseType("voiceunban", "🔊", "Voice Unban", "#57F287"),
        CaseType("tempban", "🔨", "Temporary Ban", "#ED4245"),
        CaseType("untimeout", "⏱️", "Remove Timeout", "#57F287"),
        CaseType("channel_mute", "🔇", "Channel Mute", "#FF6B35"),
        CaseType("channel_unmute", "🔊", "Channel Unmute", "#57F287"),
        CaseType("strike", "⚡", "Strike", "#FEE75C"),
        CaseType("slowmode", "⏰", "Slowmode", "#FF6B35"),
        CaseType("warn_clear", "🧹", "Clear Warnings", "#57F287"),
    ]
    for ct in builtins:
        _CASE_TYPES[ct.name] = ct


_register_builtins()


def register_casetype(
    name: str, *, emoji: str = "📋", label: str = "", color: str = "#5865F2"
) -> None:
    """Register a custom case type.

    Args:
        name:  Internal name used when calling create_case(action=name).
        emoji: Emoji displayed on the case card.
        label: Human-readable label (defaults to title-cased name).
        color: Hex color string for the card accent.

    Example::

        modlog.register_casetype("strike", emoji="⚡", label="Strike", color="#FF6B35")
    """
    _CASE_TYPES[name] = CaseType(name=name, emoji=emoji, label=label or name.title(), color=color)


def get_casetype(name: str) -> CaseType | None:
    """Return a CaseType by name, or None if not registered."""
    return _CASE_TYPES.get(name)


def get_all_casetypes() -> list[CaseType]:
    """Return all registered case types."""
    return list(_CASE_TYPES.values())


# ══════════════════════════════════════════════════════════════
# Case dataclass
# ══════════════════════════════════════════════════════════════


@dataclass
class Case:
    """A single moderation action record.

    Attributes:
        id:           Auto-incrementing case number within the guild.
        guild_id:     Discord guild ID.
        action:       Case type name (e.g. "ban", "kick").
        user_id:      Target user ID.
        mod_id:       Moderator user ID (0 if unknown).
        reason:       Action reason.
        timestamp:    Unix timestamp when the case was created.
        message_id:   Discord message ID of the case card (0 if not posted).
        channel_id:   Channel where the case was posted (0 if not posted).
        extra:        Freeform JSON-serialisable dict for extra data.
        duration:     Duration string for temporary actions (e.g. "7d", "1h") or None.
    """

    id: int
    guild_id: int
    action: str
    user_id: int
    mod_id: int = 0
    reason: str = "No reason provided."
    timestamp: int = field(default_factory=lambda: int(time.time()))
    message_id: int = 0
    channel_id: int = 0
    extra: dict = field(default_factory=dict)
    duration: str | None = None


# ══════════════════════════════════════════════════════════════
# Database layer
# ══════════════════════════════════════════════════════════════


class _ModLogDB(DatabaseManager):
    def __init__(self):
        super().__init__("modlog")

    async def initialize(self) -> None:
        await self.execute("""
            CREATE TABLE IF NOT EXISTS cases (
                id          INTEGER NOT NULL,
                guild_id    INTEGER NOT NULL,
                action      TEXT    NOT NULL,
                user_id     INTEGER NOT NULL,
                mod_id      INTEGER NOT NULL DEFAULT 0,
                reason      TEXT    NOT NULL DEFAULT 'No reason provided.',
                timestamp   INTEGER NOT NULL,
                message_id  INTEGER NOT NULL DEFAULT 0,
                channel_id  INTEGER NOT NULL DEFAULT 0,
                extra       TEXT    NOT NULL DEFAULT '{}',
                duration    TEXT,
                PRIMARY KEY (guild_id, id)
            )
        """)
        try:
            columns = await self.fetch("PRAGMA table_info(cases)")
            has_duration = any(col["name"] == "duration" for col in columns)
            if not has_duration:
                await self.execute("ALTER TABLE cases ADD COLUMN duration TEXT")
        except Exception:
            pass  # If PRAGMA fails or column exists, ignore

        await self.execute("""
            CREATE TABLE IF NOT EXISTS modlog_settings (
                guild_id    INTEGER PRIMARY KEY,
                channel_id  INTEGER NOT NULL DEFAULT 0,
                next_case   INTEGER NOT NULL DEFAULT 1
            )
        """)
        await self.execute("CREATE INDEX IF NOT EXISTS idx_cases_guild   ON cases(guild_id)")
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_cases_user    ON cases(guild_id, user_id)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_cases_action  ON cases(guild_id, action)"
        )

    async def next_case_number(self, guild_id: int) -> int:
        await self.execute(
            "INSERT OR IGNORE INTO modlog_settings (guild_id, channel_id, next_case) VALUES (?, 0, 1)",
            (guild_id,),
        )
        row = await self.fetch_one(
            "UPDATE modlog_settings SET next_case = next_case + 1 "
            "WHERE guild_id = ? RETURNING next_case - 1 AS n",
            (guild_id,),
        )
        return row["n"] if row else 1

    async def insert_case(self, case: Case) -> None:
        import json

        await self.execute(
            """INSERT INTO cases (id, guild_id, action, user_id, mod_id, reason, timestamp, message_id, channel_id, extra, duration)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                case.id,
                case.guild_id,
                case.action,
                case.user_id,
                case.mod_id,
                case.reason,
                case.timestamp,
                case.message_id,
                case.channel_id,
                json.dumps(case.extra),
                case.duration,
            ),
        )

    async def update_case_message(
        self, guild_id: int, case_id: int, message_id: int, channel_id: int
    ) -> None:
        await self.execute(
            "UPDATE cases SET message_id = ?, channel_id = ? WHERE guild_id = ? AND id = ?",
            (message_id, channel_id, guild_id, case_id),
        )

    async def fetch_case(self, guild_id: int, case_id: int) -> Case | None:
        row = await self.fetch_one(
            "SELECT * FROM cases WHERE guild_id = ? AND id = ?", (guild_id, case_id)
        )
        return _row_to_case(row) if row else None

    async def fetch_cases(
        self, guild_id: int, user_id: int | None = None, action: str | None = None
    ) -> list[Case]:
        where = "guild_id = ?"
        params: tuple = (guild_id,)
        if user_id:
            where += " AND user_id = ?"
            params += (user_id,)
        if action:
            where += " AND action = ?"
            params += (action,)
        rows = await self.fetch(f"SELECT * FROM cases WHERE {where} ORDER BY id DESC", params)
        return [_row_to_case(r) for r in rows]

    async def delete_case(self, guild_id: int, case_id: int) -> bool:
        return await self.delete("cases", "guild_id = ? AND id = ?", (guild_id, case_id)) > 0

    async def reset(self, guild_id: int) -> None:
        await self.delete("cases", "guild_id = ?", (guild_id,))
        await self.execute("DELETE FROM modlog_settings WHERE guild_id = ?", (guild_id,))

    async def get_channel_id(self, guild_id: int) -> int:
        row = await self.fetch_one(
            "SELECT channel_id FROM modlog_settings WHERE guild_id = ?", (guild_id,)
        )
        return row["channel_id"] if row else 0

    async def set_channel_id(self, guild_id: int, channel_id: int) -> None:
        await self.execute(
            "INSERT OR REPLACE INTO modlog_settings (guild_id, channel_id, next_case) VALUES (?, ?, COALESCE((SELECT next_case FROM modlog_settings WHERE guild_id = ?), 1))",
            (guild_id, channel_id, guild_id),
        )


def _row_to_case(row: dict) -> Case:
    import json

    extra = {}
    try:
        extra = json.loads(row.get("extra", "{}") or "{}")
    except Exception:
        pass
    return Case(
        id=row["id"],
        guild_id=row["guild_id"],
        action=row["action"],
        user_id=row["user_id"],
        mod_id=row["mod_id"],
        reason=row["reason"],
        timestamp=row["timestamp"],
        message_id=row["message_id"],
        channel_id=row["channel_id"],
        extra=extra,
        duration=row.get("duration"),
    )


# Module-level singleton
_db: _ModLogDB | None = None


async def _get_db() -> _ModLogDB:
    global _db
    if _db is None:
        _db = _ModLogDB()
        await _db.initialize()
    return _db


# ══════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════


async def create_case(
    bot: discord.Client,
    guild: discord.Guild,
    action: str,
    user: discord.abc.User,
    mod: discord.abc.User | None = None,
    reason: str | None = None,
    *,
    timestamp: int | None = None,
    extra: dict | None = None,
    duration: str | None = None,
) -> Case:
    """Create a mod-log case, post it to the mod-log channel, and return the Case.

    Args:
        bot:       The bot client (used to fetch the mod-log channel).
        guild:     The guild where the action occurred.
        action:    Case type name: "ban", "kick", "warn", etc.
        user:      The target user.
        mod:       The moderator (None = unknown/automated).
        reason:    Reason for the action.
        timestamp: Override the creation timestamp (Unix int).
        extra:     Extra data stored on the case.
        duration:  Duration string for temporary actions (e.g. "7d", "1h").

    Returns:
        The created Case object.

    Example::

        case = await modlog.create_case(
            bot    = self.bot,
            guild  = interaction.guild,
            action = "ban",
            user   = member,
            mod    = interaction.user,
            reason = "Spamming",
            duration = "7d",
        )
        log.info("Created case #%d", case.id)
    """
    db = await _get_db()
    case_id = await db.next_case_number(guild.id)

    case = Case(
        id=case_id,
        guild_id=guild.id,
        action=action,
        user_id=user.id,
        mod_id=mod.id if mod else 0,
        reason=reason or "No reason provided.",
        timestamp=timestamp or int(time.time()),
        extra=extra or {},
        duration=duration,
    )
    await db.insert_case(case)

    # Post to mod-log channel
    channel = await get_channel(bot, guild)
    if channel:
        try:
            ct = _CASE_TYPES.get(action.lower())
            color = discord.Color.from_str(ct.color) if ct else None
            view = make_case_card(
                case_number=case_id,
                action=action,
                user=user,
                moderator=mod,
                reason=case.reason,
                timestamp=case.timestamp,
                accent_color=color,
                duration=case.duration,
            )
            msg = await channel.send(view=view)
            await db.update_case_message(guild.id, case_id, msg.id, channel.id)
            case.message_id = msg.id
            case.channel_id = channel.id
        except discord.HTTPException as exc:
            log.warning("Failed to post modlog case #%d: %s", case_id, exc)

    return case


async def get_case(
    guild: discord.Guild,
    case_number: int,
) -> Case | None:
    """Fetch a single case by number.

    Returns None if no such case exists.
    """
    db = await _get_db()
    return await db.fetch_case(guild.id, case_number)


async def get_cases(
    guild: discord.Guild,
    user: discord.abc.User | None = None,
    action: str | None = None,
) -> list[Case]:
    """Fetch all cases for a guild, optionally filtered by user or action type.

    Args:
        guild:  The guild to query.
        user:   Filter to cases against this user.
        action: Filter to a specific action type.

    Returns:
        List of Case objects, newest first.
    """
    db = await _get_db()
    return await db.fetch_cases(guild.id, user.id if user else None, action)


async def get_latest_case(guild: discord.Guild) -> Case | None:
    """Return the most recent case for *guild*, or None."""
    cases = await get_cases(guild)
    return cases[0] if cases else None


async def delete_case(guild: discord.Guild, case_number: int) -> bool:
    """Delete a case by number. Returns True if it existed."""
    db = await _get_db()
    return await db.delete_case(guild.id, case_number)


async def reset_cases(guild: discord.Guild) -> None:
    """Delete all cases for *guild* and reset the case counter."""
    db = await _get_db()
    await db.reset(guild.id)


async def set_channel(guild: discord.Guild, channel: discord.TextChannel | None) -> None:
    """Set (or unset) the mod-log channel for *guild*.

    Args:
        guild:   The guild.
        channel: The text channel, or None to disable the mod log.
    """
    db = await _get_db()
    await db.set_channel_id(guild.id, channel.id if channel else 0)


async def get_channel(bot: discord.Client, guild: discord.Guild) -> discord.TextChannel | None:
    """Return the mod-log channel for *guild*, or None if not configured."""
    db = await _get_db()
    channel_id = await db.get_channel_id(guild.id)
    if not channel_id:
        return None
    ch = bot.get_channel(channel_id)
    if isinstance(ch, discord.TextChannel):
        return ch
    try:
        ch = await bot.fetch_channel(channel_id)
        return ch if isinstance(ch, discord.TextChannel) else None
    except discord.HTTPException:
        return None


async def edit_case(
    bot: discord.Client,
    guild: discord.Guild,
    case_number: int,
    *,
    reason: str | None = None,
    mod: discord.abc.User | None = None,
) -> Case | None:
    """Edit an existing case's reason and/or moderator.

    Args:
        bot:        The bot client (used to fetch Discord objects).
        guild:      The guild the case belongs to.
        case_number: The case number to edit.
        reason:     New reason (if provided).
        mod:        New moderator (if provided).

    Returns:
        The updated Case object, or None if not found.
    """
    db = await _get_db()
    case = await db.fetch_case(guild.id, case_number)
    if not case:
        return None

    if reason is not None:
        case.reason = reason
    if mod is not None:
        case.mod_id = mod.id

    await db.execute(
        """UPDATE cases SET reason = ?, mod_id = ? WHERE guild_id = ? AND id = ?""",
        (case.reason, case.mod_id, guild.id, case_number),
    )

    # Edit the Discord message if it exists
    if case.message_id and case.channel_id:
        try:
            channel = guild.get_channel(case.channel_id) or await guild.fetch_channel(
                case.channel_id
            )
            if isinstance(channel, discord.TextChannel):
                # Resolve user (handle anonymized IDs)
                if case.user_id != 0:
                    user_obj = guild.get_member(case.user_id) or await bot.fetch_user(case.user_id)
                else:
                    # Create dummy user for anonymized records
                    class DummyUser:
                        mention = "`[Anonymized]`"
                        id = 0
                        display_name = "Anonymized"

                    user_obj = DummyUser()

                # Resolve moderator (None if anonymized/unknown)
                if case.mod_id != 0:
                    mod_obj = guild.get_member(case.mod_id) or await bot.fetch_user(case.mod_id)
                else:
                    mod_obj = None

                msg = await channel.fetch_message(case.message_id)
                view = make_case_card(
                    case_number=case.id,
                    action=case.action,
                    user=user_obj,
                    moderator=mod_obj,
                    reason=case.reason,
                    timestamp=case.timestamp,
                    accent_color=(
                        discord.Color.from_str(_CASE_TYPES[case.action].color)
                        if case.action in _CASE_TYPES
                        else None
                    ),
                    duration=case.duration,
                )
                await msg.edit(view=view)
        except Exception as exc:
            log.warning("Failed to edit modlog message for case #%d: %s", case_number, exc)

    return case


async def get_cases_by_type(
    guild: discord.Guild,
    action: str,
    limit: int = 50,
) -> list[Case]:
    """Fetch cases filtered by action type.

    Args:
        guild:    The guild to query.
        action:   The action type to filter by.
        limit:    Maximum number of cases to return (default 50).

    Returns:
        List of Case objects matching the action, newest first.
    """
    db = await _get_db()
    return await db.fetch_cases(guild.id, action=action.lower())[:limit]


async def export_cases(
    guild: discord.Guild,
    fmt: str = "json",
) -> str:
    """Export all cases for a guild in JSON or CSV format.

    Args:
        guild: The guild to export.
        fmt:   Export format: "json" or "csv".

    Returns:
        A string containing the exported data.

    Raises:
        ValueError: If fmt is not "json" or "csv".
    """
    import csv
    import io
    import json

    db = await _get_db()
    cases = await db.fetch_cases(guild.id)

    if fmt == "json":
        data = [
            {
                "id": c.id,
                "action": c.action,
                "user_id": c.user_id,
                "mod_id": c.mod_id,
                "reason": c.reason,
                "timestamp": c.timestamp,
                "duration": c.duration,
                "extra": c.extra,
            }
            for c in cases
        ]
        return json.dumps(data, indent=2)

    elif fmt == "csv":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            ["Case ID", "Action", "User ID", "Moderator ID", "Reason", "Timestamp", "Duration"]
        )
        for c in cases:
            writer.writerow(
                [
                    c.id,
                    c.action,
                    c.user_id,
                    c.mod_id,
                    c.reason,
                    c.timestamp,
                    c.duration or "",
                ]
            )
        return output.getvalue()

    else:
        raise ValueError("fmt must be 'json' or 'csv'")


async def get_case_stats(guild: discord.Guild) -> dict[str, Any]:
    """Get statistics about cases for a guild.

    Args:
        guild: The guild to get stats for.

    Returns:
        A dictionary with:
        - total: total number of cases
        - by_action: dict mapping action names to counts
    """
    db = await _get_db()
    cases = await db.fetch_cases(guild.id)

    stats = {
        "total": len(cases),
        "by_action": {},
    }

    for case in cases:
        stats["by_action"][case.action] = stats["by_action"].get(case.action, 0) + 1

    return stats


async def delete_data_for_user(user_id: int) -> None:
    """GDPR: anonymise all case records for *user_id*.

    Replaces user_id and mod_id fields with 0 in all cases.
    Does not delete cases — audit trails must be preserved.
    """
    db = await _get_db()
    await db.execute("UPDATE cases SET user_id = 0 WHERE user_id = ?", (user_id,))
    await db.execute("UPDATE cases SET mod_id  = 0 WHERE mod_id  = ?", (user_id,))
    log.info("Anonymised modlog records for user %d (GDPR)", user_id)
