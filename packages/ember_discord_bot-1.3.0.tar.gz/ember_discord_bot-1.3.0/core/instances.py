"""Named-instance registry for Ember.

Mirrors Red-DiscordBot's `redbot --instance` model: each instance is a named
bundle of (data_dir, backend) recorded in a single JSON registry file. The
CLI reads this registry to spin up the right environment without the user
juggling DATA_DIR / EMBER_DB_BACKEND manually.

Registry path: ``$XDG_CONFIG_HOME/ember/instances.json`` (or
``~/.config/ember/instances.json``).
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REGISTRY_ENV_VAR = "EMBER_REGISTRY"


def registry_path() -> Path:
    override = os.getenv(REGISTRY_ENV_VAR)
    if override:
        return Path(override).expanduser()
    base = os.getenv("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "ember" / "instances.json"


@dataclass
class Instance:
    name: str
    data_path: str
    backend: str = "sqlite"
    created: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> Instance:
        return cls(
            name=name,
            data_path=data.get("data_path", ""),
            backend=data.get("backend", "sqlite"),
            created=data.get("created", ""),
            extra=data.get("extra", {}),
        )


def _load_raw() -> dict[str, Any]:
    path = registry_path()
    if not path.exists():
        return {"instances": {}, "default": None}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"instances": {}, "default": None}


def _save_raw(data: dict[str, Any]) -> None:
    path = registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


def list_instances() -> list[Instance]:
    raw = _load_raw()
    return [Instance.from_dict(name, payload) for name, payload in sorted(raw["instances"].items())]


def get_instance(name: str) -> Instance | None:
    raw = _load_raw()
    payload = raw["instances"].get(name)
    if payload is None:
        return None
    return Instance.from_dict(name, payload)


def create_instance(
    name: str,
    *,
    data_path: str | Path,
    backend: str = "sqlite",
    overwrite: bool = False,
) -> Instance:
    raw = _load_raw()
    if not overwrite and name in raw["instances"]:
        raise ValueError(f"Instance {name!r} already exists; pass overwrite=True to replace.")
    inst = Instance(
        name=name, data_path=str(Path(data_path).expanduser().resolve()), backend=backend
    )
    raw["instances"][name] = inst.to_dict()
    raw["instances"][name].pop("name", None)  # don't persist name twice
    if raw.get("default") is None:
        raw["default"] = name
    _save_raw(raw)
    Path(inst.data_path).mkdir(parents=True, exist_ok=True)
    return inst


def delete_instance(name: str, *, remove_data: bool = False) -> bool:
    raw = _load_raw()
    if name not in raw["instances"]:
        return False
    payload = raw["instances"].pop(name)
    if raw.get("default") == name:
        remaining = sorted(raw["instances"])
        raw["default"] = remaining[0] if remaining else None
    _save_raw(raw)
    if remove_data:
        import shutil

        path = Path(payload.get("data_path", ""))
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    return True


def set_default(name: str) -> None:
    raw = _load_raw()
    if name not in raw["instances"]:
        raise KeyError(name)
    raw["default"] = name
    _save_raw(raw)


def get_default() -> Instance | None:
    raw = _load_raw()
    name = raw.get("default")
    if not name:
        return None
    return get_instance(name)


def apply_to_env(inst: Instance) -> None:
    """Set process env vars so the rest of the bootstrap picks the instance up."""
    os.environ["DATA_DIR"] = inst.data_path
    os.environ["EMBER_DB_BACKEND"] = inst.backend
    os.environ["EMBER_INSTANCE"] = inst.name
    env_file = Path(inst.data_path) / ".env"
    if env_file.exists():
        try:
            from dotenv import load_dotenv

            load_dotenv(env_file, override=False)
        except ImportError:
            pass
