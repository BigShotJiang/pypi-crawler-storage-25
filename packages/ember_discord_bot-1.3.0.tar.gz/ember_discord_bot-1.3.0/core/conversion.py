"""Backend conversion: copy all data from one driver to another.

Mirrors Red-DiscordBot's ``redbot --convert`` flow. Uses the driver
``export()`` / ``import_data()`` contract from ``BaseDriver`` so any
backend pair that implements both is portable.

Typical use:

    ember convert --from sqlite --to postgres \\
        --postgres-dsn postgresql://user:pass@host/ember
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core._drivers import BackendType, BaseDriver, JsonDriver, SQLiteDriver


def _build_driver(
    backend: BackendType,
    *,
    data_dir: Path,
    postgres_dsn: str | None = None,
    mongo_uri: str | None = None,
) -> BaseDriver:
    if backend is BackendType.SQLITE:
        return SQLiteDriver(data_dir / "ember_config.db")
    if backend is BackendType.JSON:
        return JsonDriver(data_dir / "config_json")
    if backend is BackendType.POSTGRES:
        from core._drivers.postgres import PostgresDriver

        if not postgres_dsn:
            raise ValueError("--postgres-dsn is required for the postgres backend.")
        return PostgresDriver(postgres_dsn)
    if backend is BackendType.MONGO:
        from core._drivers.mongo import MongoDriver

        if not mongo_uri:
            raise ValueError("--mongo-uri is required for the mongo backend.")
        return MongoDriver(mongo_uri)
    raise ValueError(f"Unknown backend: {backend}")


def _normalize_to_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Translate a driver-native export() payload into canonical rows.

    Canonical row keys: cog_name, identifier, scope, scope_id_1, scope_id_2, key, value.
    """
    drv = payload.get("driver")
    if drv in ("sqlite", "postgres"):
        return list(payload.get("rows", []))
    if drv == "json":
        rows: list[dict[str, Any]] = []
        for stem, content in payload.get("files", {}).items():
            cog_name, _, ident_s = stem.rpartition("_")
            try:
                identifier = int(ident_s)
            except ValueError:
                continue
            rows.extend(_walk_json_tree(cog_name, identifier, content))
        return rows
    if drv == "mongo":
        return list(payload.get("rows", []))
    if "rows" in payload:
        return list(payload["rows"])
    return []


def _walk_json_tree(cog: str, ident: int, tree: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten the JSON driver's nested {scope: {id1: {id2?: {key: val}}}} layout."""
    out: list[dict[str, Any]] = []
    for scope, sub in tree.items():
        if not isinstance(sub, dict):
            continue
        if scope == "global":
            for k, v in sub.items():
                out.append(_row(cog, ident, scope, "", "", k, v))
            continue
        for id1, leaf in sub.items():
            if not isinstance(leaf, dict):
                continue
            if scope == "member":
                for id2, kv in leaf.items():
                    if isinstance(kv, dict):
                        for k, v in kv.items():
                            out.append(_row(cog, ident, scope, id1, id2, k, v))
            else:
                for k, v in leaf.items():
                    out.append(_row(cog, ident, scope, id1, "", k, v))
    return out


def _row(cog, ident, scope, id1, id2, key, value):
    return {
        "cog_name": cog,
        "identifier": ident,
        "scope": scope,
        "scope_id_1": id1,
        "scope_id_2": id2,
        "key": key,
        "value": value,
    }


async def _write_rows(dst: BaseDriver, rows: list[dict[str, Any]]) -> int:
    """Write canonical rows to *dst* via the row-level set() API."""
    from core._drivers.base import ConfigScope

    n = 0
    for r in rows:
        try:
            scope = ConfigScope(r["scope"])
        except ValueError:
            continue
        await dst.set(
            r["cog_name"],
            int(r["identifier"]),
            scope,
            str(r.get("scope_id_1") or ""),
            str(r.get("scope_id_2") or ""),
            r["key"],
            r["value"],
        )
        n += 1
    return n


async def convert(
    *,
    src: BaseDriver,
    dst: BaseDriver,
) -> dict[str, Any]:
    """Copy every key from *src* into *dst* via the canonical row format.

    Both drivers must already be initialized. Returns a small report dict.
    """
    payload = await src.export()
    rows = _normalize_to_rows(payload)
    written = await _write_rows(dst, rows)
    return {"rows": written, "ok": True}


async def convert_via_files(
    *,
    src: BaseDriver,
    out_path: Path,
) -> Path:
    """Dump *src* to a canonical-rows JSON file (for offline migration)."""
    payload = await src.export()
    rows = _normalize_to_rows(payload)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps({"rows": rows}, indent=2, default=str), encoding="utf-8")
    return out_path


async def restore_from_file(*, dst: BaseDriver, in_path: Path) -> int:
    """Load a canonical-rows dump into *dst*. Returns rows written."""
    payload = json.loads(in_path.read_text(encoding="utf-8"))
    rows = _normalize_to_rows(payload)
    return await _write_rows(dst, rows)


async def run_conversion(
    *,
    src_backend: str,
    dst_backend: str,
    data_dir: Path,
    postgres_dsn: str | None = None,
    mongo_uri: str | None = None,
    dump_to: Path | None = None,
    restore_from: Path | None = None,
) -> dict[str, Any]:
    """High-level entry point used by the CLI.

    If *dump_to* is given, write src → file and skip dst.
    If *restore_from* is given, read file → dst and skip src.
    Otherwise both ends are built and data flows src → dst directly.
    """
    if restore_from is not None:
        dst = _build_driver(
            BackendType(dst_backend),
            data_dir=data_dir,
            postgres_dsn=postgres_dsn,
            mongo_uri=mongo_uri,
        )
        await dst.initialize()
        n = await restore_from_file(dst=dst, in_path=restore_from)
        return {"restored_from": str(restore_from), "rows": n, "ok": True}

    src = _build_driver(
        BackendType(src_backend),
        data_dir=data_dir,
        postgres_dsn=postgres_dsn,
        mongo_uri=mongo_uri,
    )
    await src.initialize()

    if dump_to is not None:
        path = await convert_via_files(src=src, out_path=dump_to)
        return {"dumped_to": str(path), "ok": True}

    dst = _build_driver(
        BackendType(dst_backend),
        data_dir=data_dir,
        postgres_dsn=postgres_dsn,
        mongo_uri=mongo_uri,
    )
    await dst.initialize()
    return await convert(src=src, dst=dst)
