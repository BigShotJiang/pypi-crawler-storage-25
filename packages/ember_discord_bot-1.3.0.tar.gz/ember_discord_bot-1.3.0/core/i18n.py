from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING

import discord

if TYPE_CHECKING:
    from core.bot import EmberBot

log = logging.getLogger("ember.i18n")

# Absolute path to <project_root>/locales/
_PROJECT_ROOT = Path(__file__).parent.parent
_LOCALES_DIR = _PROJECT_ROOT / "locales"

FRESH_INSTALL_LOCALE = "en-US"
_locale_override: str | None = None
_registered_translators: list[Translator] = []


def get_locale() -> str:
    if _locale_override:
        return _locale_override
    return FRESH_INSTALL_LOCALE


def set_locale_override(locale: str) -> None:
    global _locale_override
    _locale_override = locale
    _reload_translators()


def clear_locale_override() -> None:
    global _locale_override
    _locale_override = None
    _reload_translators()


def _reload_translators() -> None:
    for translator in _registered_translators:
        translator.load_translations()


class Translator:
    """Per-cog translation helper.

    Loads ``locales/<locale>/<cog_name_lower>.json`` on first use.
    Falls back to the original string when no translation is found.
    """

    def __init__(self, name: str, file_location: str | Path):
        self.cog_name = name
        self._file = Path(file_location)
        self._translations: dict[str, str] = {}
        self._loaded_locale: str | None = None
        _registered_translators.append(self)
        self.load_translations()

    def load_translations(self) -> None:
        """Load (or reload) translations for the current locale."""
        locale = get_locale()
        if locale == self._loaded_locale:
            return

        self._translations.clear()
        self._loaded_locale = locale

        locale_file = _LOCALES_DIR / locale / f"{self.cog_name.lower()}.json"
        if not locale_file.exists():
            return

        try:
            with locale_file.open(encoding="utf-8") as fh:
                data = json.load(fh)
            # Only keep non-identity entries so identity maps have zero overhead
            self._translations = {k: v for k, v in data.items() if k != v}
        except Exception as exc:
            log.warning("Failed to load %s: %s", locale_file, exc)

    def __call__(self, untranslated: str) -> str:
        """Return the translated string, or the original if not found."""
        return self._translations.get(untranslated, untranslated)

    def for_interaction(self, interaction: discord.Interaction) -> Callable[[str], str]:
        """Return a translate function scoped to the interaction's locale."""
        locale = str(interaction.locale) if interaction.locale else get_locale()

        locale_file = _LOCALES_DIR / locale / f"{self.cog_name.lower()}.json"
        if locale_file.exists():
            try:
                data = json.loads(locale_file.read_text(encoding="utf-8"))
                overrides = {k: v for k, v in data.items() if k != v}
                return lambda text: overrides.get(text, text)
            except Exception:
                pass

        return self.__call__


def cog_i18n(translator: Translator) -> Callable[[type], type]:
    """Decorator that links a Translator to a cog class."""

    def decorator(cog_class: type) -> type:
        cog_class.__translator__ = translator
        for name, attr in cog_class.__dict__.items():
            if isinstance(attr, (discord.app_commands.Command, discord.app_commands.Group)):
                attr.translator = translator
                setattr(cog_class, name, attr)
        return cog_class

    return decorator


async def get_locale_from_guild(bot: EmberBot, guild: discord.Guild | None) -> str:
    """Get locale for a guild (falls back to global)."""
    from core._settings_caches import i18n_mgr

    if guild is None:
        return await i18n_mgr.get_global_locale()
    return await i18n_mgr.get_guild_locale(guild.id)


def make_translator(name: str, file_location: str | Path) -> Translator:
    """Create and return a Translator. Preferred pattern for cogs."""
    return Translator(name, file_location)
