from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

import discord

log = logging.getLogger("ember.diagnostics")


class Level(Enum):
    OK = "ok"
    WARN = "warn"
    FAIL = "fail"


@dataclass
class DiagnosticResult:
    """Result of a single diagnostic check.

    Used for both startup diagnostics (category/message) and
    runtime command diagnostics (check_name/passed/reason).
    """

    level: Level
    category: str
    message: str
    # Runtime fields
    check_name: str = ""
    passed: bool = True
    reason: str = ""


async def diagnose_command(
    command_name: str,
    interaction: discord.Interaction,
) -> list[DiagnosticResult]:
    """Run through the full permission evaluation chain for *command_name*.

    Returns a list of DiagnosticResult — one per check — with pass/fail and
    a human-readable reason.  Guild admins can use this to understand exactly
    why a command does or doesn't work for a given member.
    """
    results: list[DiagnosticResult] = []

    def _ok(name: str, reason: str) -> DiagnosticResult:
        return DiagnosticResult(
            Level.OK,
            "permissions",
            f"{name}: {reason}",
            check_name=name,
            passed=True,
            reason=reason,
        )

    def _fail(name: str, reason: str) -> DiagnosticResult:
        return DiagnosticResult(
            Level.FAIL,
            "permissions",
            f"{name}: {reason}",
            check_name=name,
            passed=False,
            reason=reason,
        )

    # 1. Command registered?
    from core.permissions_engine import PermissionRegistry

    try:
        registry = PermissionRegistry._instance
        if registry is None:
            results.append(_fail("registry", "PermissionRegistry not initialised."))
            return results
    except Exception as exc:
        results.append(_fail("registry", str(exc)))
        return results

    req = registry.get_requires(command_name)
    if req is None:
        results.append(_fail("command_exists", f"No command '{command_name}' registered."))
        return results
    results.append(_ok("command_exists", f"Command '{command_name}' is registered."))

    # 2. Guild context?
    if interaction.guild is None:
        results.append(_ok("guild_context", "DM context — only global rules apply."))
    else:
        results.append(_ok("guild_context", f"Guild: {interaction.guild.name}"))

    # 3. Bot owner bypass?
    bot = interaction.client
    if await bot.is_owner(interaction.user):
        results.append(_ok("owner_bypass", "User is bot owner — all checks bypassed."))
        return results
    results.append(_ok("owner_bypass", "User is not bot owner."))

    # 4. Privilege level
    if req.privilege_level is not None:
        if interaction.guild:
            from core.permissions import _get_user_permission_level

            try:
                level = await _get_user_permission_level(interaction.user, interaction.guild, bot)
                if level >= req.privilege_level:
                    results.append(
                        _ok(
                            "privilege_level",
                            f"User level {level.name} ≥ required {req.privilege_level.name}.",
                        )
                    )
                else:
                    results.append(
                        _fail(
                            "privilege_level",
                            f"User level {level.name} < required {req.privilege_level.name}.",
                        )
                    )
            except Exception as exc:
                results.append(_fail("privilege_level", f"Check error: {exc}"))
        else:
            results.append(_ok("privilege_level", "DM — privilege check skipped."))

    # 5. Permission overrides
    if interaction.guild:
        rules = await registry.get_rules(command_name, interaction.guild.id)
        if rules:
            guild_rules = rules.guild_rules.get(str(interaction.guild.id), {})
            if guild_rules:
                for model, state in guild_rules.items():
                    results.append(_ok("override", f"{model} → {state.name}"))
            else:
                results.append(_ok("overrides", "No guild-specific overrides."))
        else:
            results.append(_ok("overrides", "No permission rules stored for this command."))

    return results


def format_diagnose_report(results: list[DiagnosticResult]) -> str:
    """Format runtime diagnostic results as a compact card-friendly string."""
    lines = []
    for r in results:
        icon = "✅" if r.passed else "❌"
        name = r.check_name or r.category
        reason = r.reason or r.message
        lines.append(f"{icon} **{name}** — {reason}")
    return "\n".join(lines) if lines else "No checks ran."


async def run_diagnostics(bot: discord.Client) -> list[DiagnosticResult]:
    results: list[DiagnosticResult] = []

    # 1. Intents
    for intent_name in ("members", "message_content", "guilds"):
        if not getattr(bot.intents, intent_name, False):
            results.append(
                DiagnosticResult(Level.FAIL, "Intents", f"Intent '{intent_name}' is not enabled.")
            )
        else:
            results.append(
                DiagnosticResult(Level.OK, "Intents", f"Intent '{intent_name}' is enabled.")
            )

    # 2. Guild count
    if len(bot.guilds) == 0:
        results.append(DiagnosticResult(Level.WARN, "Guilds", "Bot is not in any guilds."))
    else:
        results.append(
            DiagnosticResult(Level.OK, "Guilds", f"Bot is in {len(bot.guilds)} guild(s).")
        )

    # 3. Latency
    if bot.latency > 1.0:
        results.append(
            DiagnosticResult(Level.WARN, "Latency", f"High latency: {bot.latency:.2f}s.")
        )
    else:
        results.append(DiagnosticResult(Level.OK, "Latency", f"Latency is {bot.latency:.3f}s."))

    # 4. Driver
    try:
        from core._drivers import get_driver

        get_driver()
        results.append(
            DiagnosticResult(Level.OK, "Driver", "Storage driver initialised successfully.")
        )
    except Exception as exc:
        results.append(DiagnosticResult(Level.FAIL, "Driver", f"Storage driver failed: {exc}"))

    # 5. Modlog channels
    for guild in bot.guilds:
        try:
            from core.modlog import get_channel

            ch = await get_channel(bot, guild)
            if ch is None:
                results.append(
                    DiagnosticResult(
                        Level.WARN, "Modlog", f"No modlog channel set for guild '{guild.name}'."
                    )
                )
            else:
                results.append(
                    DiagnosticResult(
                        Level.OK, "Modlog", f"Modlog channel configured for guild '{guild.name}'."
                    )
                )
        except Exception as exc:
            results.append(
                DiagnosticResult(
                    Level.WARN, "Modlog", f"Could not check modlog for guild '{guild.name}': {exc}"
                )
            )

    # 6. Permissions
    required_perms = (
        "manage_roles",
        "ban_members",
        "kick_members",
        "moderate_members",
        "manage_messages",
    )
    for guild in bot.guilds:
        if guild.me is None:
            continue
        perms = guild.me.guild_permissions
        missing = [p for p in required_perms if not getattr(perms, p, False)]
        if missing:
            results.append(
                DiagnosticResult(
                    Level.WARN,
                    "Permissions",
                    f"Guild '{guild.name}' missing: {', '.join(missing)}.",
                )
            )
        else:
            results.append(
                DiagnosticResult(
                    Level.OK, "Permissions", f"All required permissions present in '{guild.name}'."
                )
            )

    # 7. Cog count
    cog_count = len(bot.cogs)
    if cog_count >= 5:
        results.append(DiagnosticResult(Level.OK, "Cogs", f"{cog_count} cog(s) loaded."))
    else:
        results.append(
            DiagnosticResult(Level.WARN, "Cogs", f"Only {cog_count} cog(s) loaded (expected ≥5).")
        )

    # 8. Owner
    if bot.owner_id is not None:
        results.append(DiagnosticResult(Level.OK, "Owner", f"Owner ID is set: {bot.owner_id}."))
    else:
        results.append(
            DiagnosticResult(
                Level.OK, "Owner", "Owner ID not cached yet (will resolve via application info)."
            )
        )

    return results


def format_report(results: list[DiagnosticResult]) -> str:
    _emoji = {Level.OK: "✅", Level.WARN: "⚠️", Level.FAIL: "❌"}
    categories: dict[str, list[DiagnosticResult]] = {}
    for r in results:
        categories.setdefault(r.category, []).append(r)

    lines = ["── Ember Diagnostics ──────────────────"]
    for category, items in categories.items():
        lines.append(f"  [{category}]")
        for item in items:
            lines.append(f"    {_emoji[item.level]} {item.message}")
    lines.append("────────────────────────────────────")
    return "\n".join(lines)
