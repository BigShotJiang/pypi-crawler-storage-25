from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from core.errors import (
    EmberError,
    InsufficientPermissionsError,
    NotConfiguredError,
    RateLimitedError,
    UserBannedError,
    UserFeedbackError,
)
from core.permissions import PermissionsMixin
from core.permissions_engine import PermissionLevel
from core.store import Store
from utils.cards import (
    make_error_card,
    make_info_card,
    make_success_card,
    make_warning_card,
)

if TYPE_CHECKING:
    from core.bot import EmberBot

logger = logging.getLogger("ember.core.cog")


def _convert_to_snake_case(name: str) -> str:
    initial_pass = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    final_pass = re.sub("([a-z0-9])([A-Z])", r"\1_\2", initial_pass).lower()
    return final_pass.replace("_cog", "")


class EmberCog(commands.Cog, PermissionsMixin):
    def __init__(
        self,
        bot: EmberBot,
        *,
        cog_name: str | None = None,
        identifier: int | None = None,
    ) -> None:
        self.bot = bot
        self.logger = logging.getLogger(f"ember.{_convert_to_snake_case(self.__class__.__name__)}")
        if cog_name:
            derived_name = cog_name
        elif hasattr(self, "__cog_name__") and self.__cog_name__:
            derived_name = _convert_to_snake_case(self.__cog_name__)
        else:
            derived_name = _convert_to_snake_case(type(self).__name__)
        self.db = Store.for_cog(derived_name, identifier)

    async def cog_load(self) -> None:
        await super().cog_load()
        await self.db.initialize()
        await self._register_permissions()

    async def _get_user_permission_level(
        self, user: discord.Member, guild: discord.Guild
    ) -> PermissionLevel:
        from core.permissions import _get_user_permission_level

        return await _get_user_permission_level(user, guild, self.bot)

    def cog_data_path(self) -> Path:
        from core.data_manager import cog_data_path as _cdp

        return _cdp(self)

    async def send_to_owners(
        self,
        content: str | None = None,
        *,
        view: discord.ui.LayoutView | None = None,
    ) -> None:
        await self.bot.send_to_owners(content, view=view)

    async def cog_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        cause = getattr(error, "__cause__", error)
        msg = str(cause) or str(error)

        if isinstance(cause, UserFeedbackError):
            view = make_error_card(cause.title, cause.message)
        elif isinstance(cause, NotConfiguredError):
            view = make_warning_card("⚙️ Not Configured", msg)
        elif isinstance(cause, InsufficientPermissionsError):
            view = make_error_card("🚫 No Permission", msg)
        elif isinstance(cause, UserBannedError):
            view = make_error_card("🚫 Banned", msg)
        elif isinstance(cause, RateLimitedError):
            view = make_warning_card("⏳ Slow Down", msg)
        elif isinstance(cause, EmberError):
            view = make_error_card("❌ Error", msg)
        elif isinstance(error, app_commands.NoPrivateMessage):
            view = make_error_card("🚫 Server Only", "This command only works in a server.")
        elif isinstance(error, app_commands.CheckFailure):
            view = make_error_card("🚫 Not Allowed", str(error))
        elif isinstance(error, app_commands.CommandOnCooldown):
            from utils.formatting import humanize_timedelta

            view = make_warning_card(
                "⏳ Slow Down",
                f"Try again in **{humanize_timedelta(int(error.retry_after))}**.",
            )
        elif isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            view = make_error_card("🚫 No Permission", f"You need: **{missing}**")
        elif isinstance(error, app_commands.BotMissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            view = make_error_card("🔧 Bot Missing Permission", f"I need: **{missing}**")
        else:
            self.logger.error(
                "Unhandled error in /%s: %s",
                getattr(interaction.command, "qualified_name", "?"),
                error,
                exc_info=error,
            )
            view = make_error_card(
                "❌ Unexpected Error",
                "Something went wrong. Please try again or contact an admin.",
            )

        try:
            if interaction.response.is_done():
                await interaction.followup.send(view=view, ephemeral=True)
            else:
                await interaction.response.send_message(view=view, ephemeral=True)
        except Exception as send_exc:
            self.logger.debug("Error sending error response: %s", send_exc)

    async def send_card(
        self,
        interaction: discord.Interaction,
        view: discord.ui.LayoutView,
        *,
        ephemeral: bool = True,
    ) -> discord.InteractionMessage | None:
        try:
            if interaction.response.is_done():
                return await interaction.followup.send(view=view, ephemeral=ephemeral)
            await interaction.response.send_message(view=view, ephemeral=ephemeral)
            return await interaction.original_response()
        except Exception as exc:
            self.logger.error("send_card failed: %s", exc)
            return None

    async def send_success(
        self,
        interaction: discord.Interaction,
        message: str,
        *,
        title: str = "✅ Success",
        ephemeral: bool = True,
        footer: str | None = None,
    ) -> discord.InteractionMessage | None:
        return await self.send_card(
            interaction,
            make_success_card(title, message, footer=footer),
            ephemeral=ephemeral,
        )

    async def send_error(
        self,
        interaction: discord.Interaction,
        message: str,
        *,
        title: str = "❌ Error",
        ephemeral: bool = True,
        footer: str | None = None,
    ) -> discord.InteractionMessage | None:
        return await self.send_card(
            interaction,
            make_error_card(title, message, footer=footer),
            ephemeral=ephemeral,
        )

    async def send_warning(
        self,
        interaction: discord.Interaction,
        message: str,
        *,
        title: str = "⚠️ Warning",
        ephemeral: bool = True,
        footer: str | None = None,
    ) -> discord.InteractionMessage | None:
        return await self.send_card(
            interaction,
            make_warning_card(title, message, footer=footer),
            ephemeral=ephemeral,
        )

    async def send_info(
        self,
        interaction: discord.Interaction,
        message: str,
        *,
        title: str = "ℹ️ Info",
        ephemeral: bool = True,
        footer: str | None = None,
    ) -> discord.InteractionMessage | None:
        return await self.send_card(
            interaction,
            make_info_card(title, message, footer=footer),
            ephemeral=ephemeral,
        )

    def log_action(self, action: str, user: discord.Member | None = None, **details) -> None:
        user_str = f"@{user.name}" if user else "system"
        formatted_details = ", ".join(f"{key}={value}" for key, value in details.items())
        self.logger.info(
            "%s by %s%s", action, user_str, f" ({formatted_details})" if formatted_details else ""
        )
