from __future__ import annotations

import base64
import json
import logging
import os
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from core.store import Store

logger = logging.getLogger("ember.tokens")

_config = Store.for_cog("EmberTokens", 200_004)
_config.defaults(
    {
        "global": {"tokens_json": "{}"},
        "guild": {"tokens_json": "{}"},  # for guild-scoped tokens if needed
    }
)


def _derive_key(password: str, salt: bytes, iterations: int = 100_000) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))


class TokenManager:
    """Manages encrypted API tokens for cogs, backed by Config."""

    def __init__(self) -> None:
        self._master_key = self._get_or_create_master_key()

    async def load(self) -> None:
        """Initialize the token manager (ensures Store is ready)."""
        await _config.initialize()

    def _get_or_create_master_key(self) -> bytes:
        env_key = os.getenv("TOKEN_ENCRYPTION_KEY")
        if env_key:
            # Use env directly if provided (must be 32 url-safe base64)
            return (
                env_key.encode()
                if isinstance(env_key, bytes)
                else base64.urlsafe_b64decode(env_key)
            )

        # Generate from a hidden file with a fixed salt (simple but effective)
        key_file = Path("data/token_master.key")
        key_file.parent.mkdir(parents=True, exist_ok=True)

        if key_file.exists():
            raw = key_file.read_bytes()
            try:
                return base64.urlsafe_b64decode(raw)
            except Exception:
                pass

        # Generate new key
        salt = b"ember_token_salt_v1"
        pwd = os.urandom(16).hex()
        key = _derive_key(pwd, salt)
        key_file.write_bytes(base64.urlsafe_b64encode(key))
        logger.warning("Generated new token encryption key. Save this if moving servers: %s", pwd)
        return key

    def _fernet(self) -> Fernet:
        return Fernet(self._master_key)

    async def _payload(self) -> dict[str, Any]:
        raw: str = await _config.get("global", 0, "tokens_json") or "{}"
        try:
            return json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            return {}

    async def _save_payload(self, data: dict[str, Any]) -> None:
        await _config.set("global", 0, "tokens_json", json.dumps(data, ensure_ascii=False))

    async def store_token(self, cog_name: str, key: str, value: str) -> None:
        """Store an encrypted token."""
        payload = await self._payload()
        if cog_name not in payload:
            payload[cog_name] = {}
        payload[cog_name][key] = self._fernet().encrypt(value.encode()).decode()
        await self._save_payload(payload)
        logger.info("Stored token: %s/%s", cog_name, key)

    async def get_token(self, cog_name: str, key: str) -> str | None:
        """Retrieve and decrypt a token."""
        payload = await self._payload()
        try:
            enc = payload[cog_name][key]
            return self._fernet().decrypt(enc.encode()).decode()
        except KeyError:
            return None
        except Exception as exc:
            logger.error("Failed to decrypt token %s/%s: %s", cog_name, key, exc)
            return None

    async def delete_token(self, cog_name: str, key: str) -> bool:
        """Remove a token. Returns True if it existed."""
        payload = await self._payload()
        try:
            del payload[cog_name][key]
            if not payload[cog_name]:
                del payload[cog_name]
            await self._save_payload(payload)
            return True
        except KeyError:
            return False

    async def list_tokens(self, cog_name: str | None = None) -> dict[str, list[str]]:
        """List stored token keys."""
        payload = await self._payload()
        if cog_name:
            return {cog_name: list(payload.get(cog_name, {}).keys())}
        return {cn: list(keys.keys()) for cn, keys in payload.items()}

    async def rotate_key(self, new_password: str | None = None) -> None:
        """Re-encrypt all tokens with a new master key."""
        payload = await self._payload()
        if not payload:
            return

        new_key = _derive_key(new_password or os.urandom(16).hex(), b"ember_token_salt_v1")
        fnew = Fernet(new_key)

        for cog, keys in payload.items():
            for k, enc_val in keys.items():
                try:
                    plain = self._fernet().decrypt(enc_val.encode()).decode()
                    keys[k] = fnew.encrypt(plain.encode()).decode()
                except Exception as exc:
                    logger.error("Failed to rotate token %s/%s: %s", cog, k, exc)

        self._master_key = new_key
        await self._save_payload(payload)
        logger.info("Rotated all token encryption keys.")


# Global singleton
_manager: TokenManager | None = None


def get_manager() -> TokenManager:
    global _manager
    if _manager is None:
        _manager = TokenManager()
    return _manager
