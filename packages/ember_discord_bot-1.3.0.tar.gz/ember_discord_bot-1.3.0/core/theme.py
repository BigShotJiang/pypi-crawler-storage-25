from __future__ import annotations

import discord

from core.branding import ACCENT_COLOR as DEFAULT_ACCENT
from core.store import Store

# Success states - Green
SUCCESS = discord.Color.from_str("#57F287")
SUCCESS_DARK = discord.Color.from_str("#3BA55C")

# Error states
ERROR = discord.Color.from_str("#ED4245")
ERROR_DARK = discord.Color.from_str("#c0392b")

# Warning states - Orange (Ember brand accent)
WARNING = DEFAULT_ACCENT  # Use brand accent color
WARNING_DARK = discord.Color.from_str("#e65c00")  # Darker orange

# Neutral states
BLURPLE = discord.Color.blurple()  # #5865F2
GREYPLE = discord.Color.greyple()  # #4f545c


# Legacy compatibility aliases
ORANGE = WARNING
GOLD = WARNING  # Yellow replaced with orange to match brand
BLUE = BLURPLE
GREEN = SUCCESS


_branding_config = Store.for_cog("branding", 300_001)
_branding_config.defaults({"guild": {"accent_color": None}})


async def get_accent_color(guild_id: int) -> discord.Color:
    """Get the guild's custom accent color, or default."""
    hex_color = await _branding_config.get("guild", guild_id, "accent_color")
    if hex_color:
        try:
            return discord.Color.from_str(hex_color)
        except Exception:
            pass
    return WARNING


async def get_theme_colors(guild_id: int) -> dict[str, discord.Color]:
    """Get a complete color theme for a guild."""
    accent = await get_accent_color(guild_id)
    return {
        "accent": accent,
        "success": SUCCESS,
        "error": ERROR,
        "warning": WARNING,
        "blurple": BLURPLE,
        "greyple": GREYPLE,
    }
