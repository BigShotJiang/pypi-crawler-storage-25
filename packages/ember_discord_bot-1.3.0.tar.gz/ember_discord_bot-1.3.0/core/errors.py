from __future__ import annotations


class EmberError(Exception):
    pass


class NotConfiguredError(EmberError):
    def __init__(self, setting: str = ""):
        self.setting = setting
        msg = (
            "This feature isn't configured yet."
            if not setting
            else (
                f"Missing required setting: **{setting}**.\n"
                f"A server administrator needs to configure this feature first."
            )
        )
        super().__init__(msg)


class InsufficientPermissionsError(EmberError):
    def __init__(self, required: str = ""):
        self.required = required
        msg = "You don't have permission to do that."
        if required:
            msg = f"You need the **{required}** permission to use this."
        super().__init__(msg)


class UserBannedError(EmberError):
    def __init__(self, user_id: int = 0):
        self.user_id = user_id
        super().__init__("You are banned from using this feature.")


class UserNotFoundError(EmberError):
    def __init__(self, identifier: str | int = ""):
        self.identifier = identifier
        super().__init__(f"User `{identifier}` not found." if identifier else "User not found.")


class ResourceNotFoundError(EmberError):
    def __init__(self, resource_type: str = "resource", identifier: str | int = ""):
        self.resource_type = resource_type
        self.identifier = identifier
        id_part = f" `{identifier}`" if identifier else ""
        super().__init__(f"The {resource_type}{id_part} no longer exists.")


class AlreadyExistsError(EmberError):
    def __init__(self, resource_type: str = "resource"):
        self.resource_type = resource_type
        super().__init__(f"A {resource_type} already exists.")


class CogError(EmberError):
    pass


class DependencyError(EmberError):
    pass


class UserFeedbackError(EmberError):
    def __init__(self, message: str, *, title: str = "Not allowed"):
        self.message = message
        self.title = title
        super().__init__(message)


class UnsupportedDriverError(EmberError):
    def __init__(self, detail: str = ""):
        msg = "This operation requires a SQL-capable backend (SQLite or Postgres)."
        if detail:
            msg = detail
        super().__init__(msg)


class RateLimitedError(EmberError):
    def __init__(self, retry_after: float = 0):
        self.retry_after = retry_after
        if retry_after:
            from utils.formatting import humanize_timedelta

            friendly = humanize_timedelta(int(retry_after))
            super().__init__(f"You're doing that too fast. Try again in **{friendly}**.")
        else:
            super().__init__("You're doing that too fast. Please slow down.")
