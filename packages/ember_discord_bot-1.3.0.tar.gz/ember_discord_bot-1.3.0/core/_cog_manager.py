from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import discord

from core.errors import CogError, DependencyError
from core.store import Store, get_cog_store

logger = logging.getLogger("ember.cog_manager")

# Global singleton
_manager: CogManager | None = None


def get_manager() -> CogManager:
    """Return the shared CogManager instance."""
    global _manager
    if _manager is None:
        _manager = CogManager()
    return _manager


# Config for cog manager
_cog_manager_config = Store.for_cog("cog_manager", 900_001)
_cog_manager_config.defaults(
    {
        "global": {"global_enabled": {}},  # dict[cog_name, bool]
        "guild": {"guild_enabled": {}},  # dict[cog_name, bool]
    }
)


@dataclass
class CogInfo:
    """Metadata about a cog."""

    name: str
    module: str
    path: Path
    dependencies: list[str] = field(default_factory=list)
    conflicts: list[str] = field(default_factory=list)
    version: str = "1.0.0"
    enabled: bool = True
    loaded: bool = False

    @property
    def qualname(self) -> str:
        """Fully qualified module name (e.g., 'cogs.birthday')."""
        return self.module

    def __repr__(self) -> str:
        return f"<CogInfo {self.name} loaded={self.loaded}>"


class CogManager:
    """Manages cog discovery, loading, and state persistence."""

    def __init__(self, cog_paths: list[str | Path] | None = None):
        self.cog_paths: list[Path] = [Path(p) for p in (cog_paths or ["cogs"])]
        self._cogs: dict[str, CogInfo] = {}
        self._load_order: list[str] = []
        self._lock = asyncio.Lock()
        self.config = _cog_manager_config

    async def discover_cogs(self) -> list[CogInfo]:
        """Scan all cog paths and build the cog registry.

        Supports two layouts:
          - Flat:    cogs/<name>/cog.py          → module cogs.<name>.cog
          - Nested:  cogs/<cat>/<name>/cog.py    → module cogs.<cat>.<name>.cog
        Category directories are detected as dirs that contain subdirs with cog.py
        but have no cog.py themselves.
        """
        discovered: dict[str, CogInfo] = {}

        for root in self.cog_paths:
            if not root.exists():
                logger.warning("Cog path does not exist: %s", root)
                continue

            for item in root.iterdir():
                if item.name.startswith("_") or not item.is_dir():
                    continue

                if (item / "cog.py").exists():
                    # Flat layout: cogs/<name>/cog.py
                    cog_info = await self._inspect_cog(item, root)
                    if cog_info:
                        discovered[cog_info.name] = cog_info
                else:
                    # Category layout: cogs/<category>/<name>/cog.py
                    for sub in item.iterdir():
                        if sub.name.startswith("_") or not sub.is_dir():
                            continue
                        if (sub / "cog.py").exists():
                            cog_info = await self._inspect_cog(sub, root)
                            if cog_info:
                                discovered[cog_info.name] = cog_info

        # Preserve loaded state from existing registry to avoid resetting on rediscovery.
        # enabled is always re-read from config above so it stays in sync with DB.
        for name, info in discovered.items():
            if name in self._cogs:
                info.loaded = self._cogs[name].loaded

        self._cogs = discovered
        return list(discovered.values())

    def sync_loaded_from_bot(self, bot: Any) -> None:
        """Reconcile in-memory loaded flags against bot.extensions (ground truth)."""
        loaded_modules = set(bot.extensions)
        for info in self._cogs.values():
            info.loaded = info.qualname in loaded_modules

    async def _inspect_cog(self, path: Path, root: Path) -> CogInfo | None:
        """Inspect a cog directory and return CogInfo, or None if invalid.

        *path* is the cog directory (contains cog.py).
        *root* is the top-level cogs/ directory used to compute the dotted module name.
        """
        cog_py = path / "cog.py"
        if not cog_py.exists():
            return None

        # Build fully-qualified module name: cogs.<category?>.<name>.cog
        try:
            rel = path.relative_to(root.parent)  # e.g. cogs/community/birthday
        except ValueError:
            rel = path
        module_name = ".".join(rel.parts) + ".cog"  # e.g. cogs.community.birthday.cog

        info = CogInfo(name=path.name, module=module_name, path=path)

        try:
            content = cog_py.read_text()
            if "__cog_dependencies__" in content:
                info.dependencies = self._extract_list(content, "__cog_dependencies__")
            if "__cog_conflicts__" in content:
                info.conflicts = self._extract_list(content, "__cog_conflicts__")
        except Exception as exc:
            logger.debug("Failed to inspect %s: %s", path, exc)

        # Load global enabled state from config (Store API, not old Config proxy)
        try:
            global_enabled: dict = await self.config.get("global", 0, "global_enabled") or {}
            if path.name in global_enabled:
                info.enabled = bool(global_enabled[path.name])
        except Exception as exc:
            logger.debug("Could not load enabled state for %s: %s", path.name, exc)

        return info

    def _extract_list(self, content: str, var_name: str) -> list[str]:
        """Very basic extraction of list variable from Python source."""
        start = content.find(var_name)
        if start == -1:
            return []
        bracket_start = content.find("[", start)
        if bracket_start == -1:
            return []
        bracket_count = 0
        for i in range(bracket_start, len(content)):
            if content[i] == "[":
                bracket_count += 1
            elif content[i] == "]":
                bracket_count -= 1
                if bracket_count == 0:
                    list_str = content[bracket_start : i + 1]
                    try:
                        return eval(list_str)  # noqa: S307
                    except Exception:
                        return []
        return []

    def resolve_load_order(self) -> list[str]:
        """Topologically sort cogs by dependencies."""
        graph: dict[str, set[str]] = {
            name: set(info.dependencies) for name, info in self._cogs.items()
        }
        order: list[str] = []
        visited: set[str] = set()
        temp: set[str] = set()

        def visit(name: str) -> None:
            if name in temp:
                raise DependencyError(f"Circular dependency detected: {name}")
            if name in visited:
                return
            temp.add(name)
            for dep in graph.get(name, set()):
                if dep not in self._cogs:
                    raise DependencyError(f"Cog '{name}' depends on missing cog '{dep}'")
                visit(dep)
            temp.remove(name)
            visited.add(name)
            order.append(name)

        for name in self._cogs:
            if name not in visited:
                visit(name)

        self._load_order = order
        return order

    async def load_cog(self, bot: Any, cog_name: str) -> bool:
        if cog_name not in self._cogs:
            logger.error("Cog not found: %s", cog_name)
            return False
        info = self._cogs[cog_name]
        if info.loaded:
            logger.warning("Cog already loaded: %s", cog_name)
            return True
        if not info.enabled:
            logger.info("Cog disabled, skipping: %s", cog_name)
            return False
        try:
            await bot.load_extension(info.qualname)
            info.loaded = True
            logger.info("Loaded cog: %s", cog_name)
            return True
        except Exception as exc:
            logger.error("Failed to load cog %s: %s", cog_name, exc)
            return False

    async def load_all_cogs(self, bot: Any, *, disabled: set[str] | None = None) -> tuple[int, int]:
        loaded = failed = 0
        order = self.resolve_load_order()
        for name in order:
            if disabled and name in disabled:
                logger.info("Cog skipped (disabled): %s", name)
                continue
            if await self.load_cog(bot, name):
                loaded += 1
            else:
                failed += 1
        logger.info("Cogs loaded: %d, failed: %d", loaded, failed)
        return loaded, failed

    async def unload_cog(self, bot: Any, cog_name: str) -> bool:
        if cog_name not in self._cogs:
            return False
        info = self._cogs[cog_name]
        try:
            await bot.unload_extension(info.qualname)
            info.loaded = False
            logger.info("Unloaded cog: %s", cog_name)
            return True
        except Exception as exc:
            logger.error("Failed to unload cog %s: %s", cog_name, exc)
            return False

    async def reload_cog(self, bot: Any, cog_name: str) -> bool:
        if not await self.unload_cog(bot, cog_name):
            return False
        return await self.load_cog(bot, cog_name)

    async def set_enabled(self, cog_name: str, enabled: bool) -> None:
        if cog_name not in self._cogs:
            raise CogError(f"Unknown cog: {cog_name}")
        self._cogs[cog_name].enabled = enabled
        # Persist via Store
        current: dict = await self.config.get("global", 0, "global_enabled") or {}
        current[cog_name] = enabled
        await self.config.set("global", 0, "global_enabled", current)

    async def is_enabled(self, cog_name: str) -> bool:
        if cog_name in self._cogs:
            return self._cogs[cog_name].enabled
        return False

    async def get_cog_info(self, cog_name: str) -> CogInfo | None:
        return self._cogs.get(cog_name)

    async def list_cogs(self) -> list[dict[str, Any]]:
        return [
            {
                "name": info.name,
                "dependencies": info.dependencies,
                "loaded": info.loaded,
                "enabled": info.enabled,
                "module": info.qualname,
            }
            for info in self._cogs.values()
        ]

    async def is_cog_enabled_in_guild(self, cog_name: str, guild_id: int) -> bool:
        from core._settings_caches import cog_cache

        return await cog_cache.is_enabled_in_guild(cog_name, guild_id)

    async def set_cog_enabled_in_guild(self, cog_name: str, guild_id: int, enabled: bool) -> None:
        from core._settings_caches import cog_cache

        await cog_cache.set_guild_enabled(cog_name, guild_id, enabled)

    async def check_requirements(self, interaction: discord.Interaction, cog_name: str) -> bool:
        from core.checks import check_is_admin

        try:
            if await check_is_admin(interaction):
                return True
        except Exception:
            pass
        store = get_cog_store(cog_name)
        if store is None:
            return False
        required_keys = await store.get("guild", interaction.guild.id, "_required_keys") or []
        for key in required_keys:
            val = await store.get("guild", interaction.guild.id, key)
            if not val:
                return False
        return True
