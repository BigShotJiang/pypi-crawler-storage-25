"""Ember CLI core — programmatic entry points for `ember` subcommands and `main.py`.

Anything `main.py` or `scripts/ember.py` does should land here so a single import
path drives bot startup, version reporting, environment dumps, and cog
discovery.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import sys
from pathlib import Path
from typing import Any


def _setup_logging() -> logging.Logger:
    log_dir = Path(os.getenv("LOG_DIR", "logs"))
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "bot.log"

    if logging.getLogger().handlers:
        return logging.getLogger("ember.main")

    from utils.colored_logging import ColoredFormatter

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(
        ColoredFormatter(
            fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            use_color=True,
        )
    )
    logging.basicConfig(level=logging.INFO, handlers=[file_handler, console_handler])
    return logging.getLogger("ember.main")


async def _run_bot(cog_filter: str | None) -> None:
    import discord

    from config import load_env

    load_env()

    log = _setup_logging()

    token = os.getenv("BOT_TOKEN")
    if not token:
        log.error("BOT_TOKEN not found in environment variables.")
        sys.exit(1)

    if cog_filter:
        log.info(f"Loading cogs with filter: {cog_filter}")
    else:
        log.info("Loading all cogs")

    from core.bot import EmberBot

    intents = discord.Intents.default()
    intents.members = True
    intents.message_content = True

    shard_kwargs: dict[str, Any] = {}
    if shard_count_env := os.getenv("SHARD_COUNT"):
        shard_kwargs["shard_count"] = int(shard_count_env)
    if shard_ids_env := os.getenv("SHARD_IDS"):
        shard_kwargs["shard_ids"] = [
            int(s) for s in shard_ids_env.split(",") if s.strip().isdigit()
        ]

    bot = EmberBot(command_prefix=",", intents=intents, **shard_kwargs)

    async with bot:
        from core._drivers import get_driver

        driver = get_driver()
        await driver.initialize()
        log.info("Data driver initialized")

        _, failed = await bot.load_cogs(cog_filter)
        if failed > 0:
            log.warning(f"Some cogs failed to load: {failed} failed")

        await bot.start(token)


def run(cog_filter: str | None = None) -> int:
    """Start the bot. Returns a process exit code."""
    try:
        asyncio.run(_run_bot(cog_filter))
        return 0
    except KeyboardInterrupt:
        return 0


def version_string() -> str:
    """One-line version banner — Ember + Python + discord.py + OS."""
    from core import __version__

    try:
        import discord

        dpy = getattr(discord, "__version__", "unknown")
    except Exception:
        dpy = "unavailable"

    return (
        f"Ember {__version__}  •  Python {platform.python_version()}  •  "
        f"discord.py {dpy}  •  {platform.system()} {platform.release()}"
    )


def debuginfo() -> str:
    """Multi-line environment dump for issue reports.

    Reports versions, backend, loaded-on-disk cog count, env-var presence
    (names only — never values), and data/log directory sizes.
    """
    from core import __version__

    lines: list[str] = []
    lines.append(f"Ember:        {__version__}")
    lines.append(f"Python:       {platform.python_version()} ({sys.executable})")
    try:
        import discord

        lines.append(f"discord.py:   {getattr(discord, '__version__', 'unknown')}")
    except Exception:
        lines.append("discord.py:   not importable")
    lines.append(f"Platform:     {platform.system()} {platform.release()} ({platform.machine()})")
    lines.append(f"Working dir:  {Path.cwd()}")

    backend = os.getenv("EMBER_DB_BACKEND", "sqlite")
    lines.append(f"DB backend:   {backend}")
    if backend == "sqlite":
        db_path = Path("data/ember_config.db")
        lines.append(f"DB file:      {db_path} ({_size_str(db_path)})")
    elif backend == "postgres":
        lines.append(f"DB DSN set:   {bool(os.getenv('EMBER_POSTGRES_DSN'))}")
    elif backend == "mongo":
        lines.append(f"Mongo URI set:{bool(os.getenv('EMBER_MONGO_URI'))}")

    cogs_dir = Path("cogs")
    if cogs_dir.exists():
        on_disk = [p.parent.name for p in cogs_dir.rglob("cog.py") if "__pycache__" not in p.parts]
        lines.append(f"On-disk cogs: {len(on_disk)}")
    else:
        lines.append("On-disk cogs: cogs/ missing")

    data_dir = Path(os.getenv("DATA_DIR", "data"))
    log_dir = Path(os.getenv("LOG_DIR", "logs"))
    lines.append(f"data/:        {_size_str(data_dir)}")
    lines.append(f"logs/:        {_size_str(log_dir)}")

    rpc = os.getenv("EMBER_RPC_ENABLED", "false").lower() == "true"
    lines.append(f"RPC enabled:  {rpc}")

    interesting = [
        "BOT_TOKEN",
        "OWNER_IDS",
        "EMBER_DB_BACKEND",
        "EMBER_POSTGRES_DSN",
        "EMBER_MONGO_URI",
        "EMBER_HOT_RELOAD",
        "EMBER_RPC_ENABLED",
        "EMBER_RPC_SECRET",
        "SHARD_COUNT",
        "SHARD_IDS",
        "DATA_DIR",
        "LOG_DIR",
        "B2_KEY_ID",
        "B2_APP_KEY",
        "B2_BUCKET",
    ]
    present = sorted(k for k in interesting if os.getenv(k))
    absent = sorted(k for k in interesting if not os.getenv(k))
    lines.append(f"Env present:  {', '.join(present) if present else '(none)'}")
    lines.append(f"Env absent:   {', '.join(absent) if absent else '(none)'}")

    return "\n".join(lines)


def backend_show() -> str:
    """One-line summary of the active driver and where it stores data."""
    backend = os.getenv("EMBER_DB_BACKEND", "sqlite")
    if backend == "sqlite":
        path = Path("data/ember_config.db").resolve()
        return f"backend=sqlite  path={path}  exists={path.exists()}"
    if backend == "json":
        path = Path("data/ember_config.json").resolve()
        return f"backend=json    path={path}  exists={path.exists()}"
    if backend == "postgres":
        dsn = os.getenv("EMBER_POSTGRES_DSN", "")
        masked = _mask_dsn(dsn)
        return f"backend=postgres dsn={masked or '(unset)'}"
    if backend == "mongo":
        uri = os.getenv("EMBER_MONGO_URI", "")
        return f"backend=mongo   uri={_mask_dsn(uri) or '(unset)'}"
    return f"backend={backend} (unknown driver)"


def cog_list() -> str:
    """Discovered cogs as a flat table."""
    cogs_dir = Path("cogs")
    if not cogs_dir.exists():
        return "cogs/ directory not found (run from your Ember repo root)"

    rows: list[tuple[str, str]] = []
    for p in sorted(cogs_dir.rglob("cog.py")):
        if "__pycache__" in p.parts:
            continue
        rel = p.relative_to(cogs_dir).parent
        category = rel.parts[0] if len(rel.parts) > 1 else ""
        name = rel.parts[-1]
        rows.append((category, name))

    if not rows:
        return "no cogs discovered under cogs/"

    width_cat = max(len(c) for c, _ in rows) or 1
    out = [f"{'CATEGORY':<{width_cat}}  NAME"]
    for cat, name in rows:
        out.append(f"{cat:<{width_cat}}  {name}")
    return "\n".join(out)


# ── helpers ──────────────────────────────────────────────────────────


def _size_str(path: Path) -> str:
    if not path.exists():
        return "missing"
    if path.is_file():
        return _human_bytes(path.stat().st_size)
    total = sum(p.stat().st_size for p in path.rglob("*") if p.is_file())
    return _human_bytes(total)


def _human_bytes(n: int) -> str:
    for unit in ("B", "KiB", "MiB", "GiB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n //= 1024
    return f"{n} TiB"


def _mask_dsn(dsn: str) -> str:
    if not dsn:
        return ""
    import re

    return re.sub(r"://([^:]+):([^@]+)@", r"://\1:***@", dsn)
