"""Curated third-party cog registry.

Ships ``vendor/index.json`` alongside the package — a JSON manifest that
maps short names to git URLs of cogs the Aakhri Station team has reviewed.
``CogDownloader`` and the CLI use this so users can install by short name
(``ember vendor install foo``) instead of a full repo URL.

Users can override the bundled manifest by setting ``EMBER_VENDOR_INDEX``
to a path or HTTPS URL.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_BUNDLED_INDEX = Path(__file__).resolve().parent.parent / "vendor" / "index.json"


@dataclass
class VendorCog:
    name: str
    description: str
    repo_url: str
    branch: str = "main"
    subpath: str = ""
    tags: list[str] = field(default_factory=list)
    min_ember: str = ""
    author: str = ""
    install_msg: str = ""

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> VendorCog:
        return cls(
            name=name,
            description=data.get("description", ""),
            repo_url=data.get("repo_url", ""),
            branch=data.get("branch", "main"),
            subpath=data.get("subpath", ""),
            tags=list(data.get("tags", [])),
            min_ember=data.get("min_ember", ""),
            author=data.get("author", ""),
            install_msg=data.get("install_msg", ""),
        )


def _index_path() -> Path:
    override = os.getenv("EMBER_VENDOR_INDEX")
    if override:
        return Path(override).expanduser()
    return _BUNDLED_INDEX


def _load_raw() -> dict[str, Any]:
    path = _index_path()
    if not path.exists():
        return {"cogs": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"cogs": {}}


def list_cogs() -> list[VendorCog]:
    raw = _load_raw()
    return [VendorCog.from_dict(n, d) for n, d in sorted(raw.get("cogs", {}).items())]


def get_cog(name: str) -> VendorCog | None:
    raw = _load_raw()
    data = raw.get("cogs", {}).get(name)
    if data is None:
        return None
    return VendorCog.from_dict(name, data)


def search(query: str) -> list[VendorCog]:
    q = query.lower()
    return [
        c
        for c in list_cogs()
        if q in c.name.lower() or q in c.description.lower() or q in " ".join(c.tags).lower()
    ]


def _repo_slug(url: str) -> str:
    slug = url.rstrip("/").rsplit("/", 1)[-1]
    if slug.endswith(".git"):
        slug = slug[:-4]
    return slug or "repo"


def install(
    cog: VendorCog,
    *,
    cogs_dir: Path = Path("cogs/community"),
    cache_dir: Path = Path("data/cog_repos"),
    update: bool = False,
) -> Path:
    """Clone (or update) the vendor repo and symlink the cog into cogs/.

    Returns the symlink path. Pure filesystem; safe to run without a live bot.
    """
    import subprocess

    cache_dir.mkdir(parents=True, exist_ok=True)
    slug = _repo_slug(cog.repo_url)
    repo_path = cache_dir / slug

    if repo_path.exists():
        if update:
            subprocess.run(["git", "-C", str(repo_path), "pull", "--ff-only"], check=True)
    else:
        subprocess.run(
            ["git", "clone", "--branch", cog.branch, "--depth", "1", cog.repo_url, str(repo_path)],
            check=True,
        )

    src = repo_path / cog.subpath if cog.subpath else repo_path
    if not src.exists():
        raise FileNotFoundError(f"Vendor source {src} not found in cloned repo.")

    cogs_dir.mkdir(parents=True, exist_ok=True)
    link = cogs_dir / cog.name
    if link.is_symlink() or link.exists():
        if link.is_symlink():
            link.unlink()
        else:
            raise FileExistsError(f"{link} exists and is not a symlink; refusing to overwrite.")
    link.symlink_to(src.resolve(), target_is_directory=True)
    return link


def uninstall(cog: VendorCog, *, cogs_dir: Path = Path("cogs/community")) -> bool:
    link = cogs_dir / cog.name
    if link.is_symlink():
        link.unlink()
        return True
    return False
