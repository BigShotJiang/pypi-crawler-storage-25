from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger("ember.settings_caches")


# PrefixManager


class PrefixManager:
    """Cache for per-guild prefix lists.

    Hot path: called on every message to resolve command prefixes.
    """

    # Load default prefix from COMMAND_PREFIX env var
    # Fallback to "!" if not set
    DEFAULT_PREFIXES: list[str] = [os.getenv("COMMAND_PREFIX", "!")]

    def __init__(self) -> None:
        from core.store import Store

        self._cfg = Store.for_cog("EmberPrefix", 200_001)
        self._cfg.defaults({"guild": {"prefixes": []}})
        self._cache: dict[int | None, list[str]] = {}

    async def get(self, guild_id: int | None) -> list[str]:
        if guild_id in self._cache:
            return self._cache[guild_id]

        if guild_id:
            custom: list[str] = await self._cfg.get("guild", guild_id, "prefixes") or []
            result = list(self.DEFAULT_PREFIXES) + [
                p for p in custom if p not in self.DEFAULT_PREFIXES
            ]
        else:
            result = list(self.DEFAULT_PREFIXES)

        self._cache[guild_id] = result
        return result

    async def set(self, guild_id: int, prefixes: list[str]) -> None:
        await self._cfg.set("guild", guild_id, "prefixes", prefixes)
        self.invalidate(guild_id)

    async def add(self, guild_id: int, prefix: str) -> None:
        current: list[str] = await self._cfg.get("guild", guild_id, "prefixes") or []
        if prefix not in current:
            await self._cfg.set("guild", guild_id, "prefixes", current + [prefix])
        self.invalidate(guild_id)

    async def remove(self, guild_id: int, prefix: str) -> None:
        current: list[str] = await self._cfg.get("guild", guild_id, "prefixes") or []
        await self._cfg.set("guild", guild_id, "prefixes", [p for p in current if p != prefix])
        self.invalidate(guild_id)

    async def clear(self, guild_id: int) -> None:
        await self._cfg.set("guild", guild_id, "prefixes", [])
        self.invalidate(guild_id)

    def invalidate(self, guild_id: int | None) -> None:
        self._cache.pop(guild_id, None)

    def invalidate_all(self) -> None:
        self._cache.clear()


# IgnoreManager


class IgnoreManager:
    """Cache for guild and channel ignore state.

    Stores: guild_id → {ignored: bool, ignored_channels: list[int]}
    """

    def __init__(self) -> None:
        from core.store import Store

        self._cfg = Store.for_cog("EmberIgnore", 200_002)
        self._cfg.defaults({"guild": {"ignored": False, "ignored_channels": []}})
        self._cache: dict[int, dict] = {}

    async def _load(self, guild_id: int) -> dict[str, Any]:
        if guild_id not in self._cache:
            data = await self._cfg.get_all("guild", guild_id)
            data.setdefault("ignored_channels", [])
            self._cache[guild_id] = data
        return self._cache[guild_id]

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    async def is_guild_ignored(self, guild_id: int) -> bool:
        data = await self._load(guild_id)
        return bool(data.get("ignored", False))

    async def is_channel_ignored(self, guild_id: int, channel_id: int) -> bool:
        data = await self._load(guild_id)
        return channel_id in data.get("ignored_channels", [])

    async def ignore_guild(self, guild_id: int) -> None:
        await self._cfg.set("guild", guild_id, "ignored", True)
        self.invalidate(guild_id)

    async def unignore_guild(self, guild_id: int) -> bool:
        data = await self._load(guild_id)
        if not data.get("ignored", False):
            return False
        await self._cfg.set("guild", guild_id, "ignored", False)
        self.invalidate(guild_id)
        return True

    async def ignore_channel(self, guild_id: int, channel_id: int) -> None:
        data = await self._load(guild_id)
        channels: list[int] = list(data.get("ignored_channels", []))
        if channel_id not in channels:
            channels.append(channel_id)
            await self._cfg.set("guild", guild_id, "ignored_channels", channels)
            self.invalidate(guild_id)

    async def unignore_channel(self, guild_id: int, channel_id: int) -> bool:
        data = await self._load(guild_id)
        channels: list[int] = list(data.get("ignored_channels", []))
        if channel_id not in channels:
            return False
        channels.remove(channel_id)
        await self._cfg.set("guild", guild_id, "ignored_channels", channels)
        self.invalidate(guild_id)
        return True

    async def list_guild(self, guild_id: int) -> dict[str, Any]:
        data = await self._load(guild_id)
        return {
            "guild_ignored": bool(data.get("ignored", False)),
            "channels": list(data.get("ignored_channels", [])),
        }


# WhitelistBlacklistManager


class WhitelistBlacklistManager:
    """Cache for global and per-guild whitelist/blacklist.

    Global sets are loaded once on first use and kept coherent via
    invalidate_global(). Per-guild dicts are loaded on demand.
    """

    def __init__(self) -> None:
        from core.store import Store

        self._cfg = Store.for_cog("EmberWB", 200_003)
        self._cfg.defaults(
            {
                "global": {"blacklist": [], "whitelist": []},
                "guild": {"blacklist": [], "whitelist": [], "whitelist_enabled": False},
            }
        )

        self._global_blacklist: set[int] = set()
        self._global_whitelist: set[int] = set()
        self._guild_data: dict[int, dict] = {}
        self._initialized = False

    async def initialize(self) -> None:
        if self._initialized:
            return
        bl: list[int] = await self._cfg.get("global", 0, "blacklist") or []
        wl: list[int] = await self._cfg.get("global", 0, "whitelist") or []
        self._global_blacklist = set(bl)
        self._global_whitelist = set(wl)
        self._initialized = True

    async def _guild(self, guild_id: int) -> dict[str, Any]:
        if guild_id not in self._guild_data:
            self._guild_data[guild_id] = await self._cfg.get_all("guild", guild_id)
        return self._guild_data[guild_id]

    def invalidate_global(self) -> None:
        self._initialized = False
        self._global_blacklist.clear()
        self._global_whitelist.clear()

    def invalidate_guild(self, guild_id: int) -> None:
        self._guild_data.pop(guild_id, None)

    async def get_blacklist(self) -> set[int]:
        await self.initialize()
        return set(self._global_blacklist)

    async def add_to_blacklist(self, user_id: int) -> None:
        await self.initialize()
        self._global_blacklist.add(user_id)
        await self._cfg.set("global", 0, "blacklist", list(self._global_blacklist))

    async def remove_from_blacklist(self, user_id: int) -> None:
        await self.initialize()
        self._global_blacklist.discard(user_id)
        await self._cfg.set("global", 0, "blacklist", list(self._global_blacklist))

    async def get_whitelist(self) -> set[int]:
        await self.initialize()
        return set(self._global_whitelist)

    async def add_to_whitelist(self, user_id: int) -> None:
        await self.initialize()
        self._global_whitelist.add(user_id)
        await self._cfg.set("global", 0, "whitelist", list(self._global_whitelist))

    async def remove_from_whitelist(self, user_id: int) -> None:
        await self.initialize()
        self._global_whitelist.discard(user_id)
        await self._cfg.set("global", 0, "whitelist", list(self._global_whitelist))

    async def guild_blacklist_add(self, guild_id: int, user_id: int) -> None:
        data = await self._guild(guild_id)
        bl = set(data.get("blacklist", []))
        bl.add(user_id)
        await self._cfg.set("guild", guild_id, "blacklist", list(bl))
        self.invalidate_guild(guild_id)

    async def guild_blacklist_remove(self, guild_id: int, user_id: int) -> None:
        data = await self._guild(guild_id)
        bl = set(data.get("blacklist", []))
        bl.discard(user_id)
        await self._cfg.set("guild", guild_id, "blacklist", list(bl))
        self.invalidate_guild(guild_id)

    async def guild_whitelist_add(self, guild_id: int, user_id: int) -> None:
        data = await self._guild(guild_id)
        wl = set(data.get("whitelist", []))
        wl.add(user_id)
        await self._cfg.set("guild", guild_id, "whitelist", list(wl))
        self.invalidate_guild(guild_id)

    async def guild_whitelist_remove(self, guild_id: int, user_id: int) -> None:
        data = await self._guild(guild_id)
        wl = set(data.get("whitelist", []))
        wl.discard(user_id)
        await self._cfg.set("guild", guild_id, "whitelist", list(wl))
        self.invalidate_guild(guild_id)

    async def set_guild_whitelist_enabled(self, guild_id: int, enabled: bool) -> None:
        await self._cfg.set("guild", guild_id, "whitelist_enabled", enabled)
        self.invalidate_guild(guild_id)

    async def is_blocked(self, guild_id: int | None, user_id: int) -> bool:
        """Return True if user_id is blocked from using commands."""
        await self.initialize()

        if self._global_whitelist and user_id not in self._global_whitelist:
            return True
        if user_id in self._global_blacklist:
            return True
        if not guild_id:
            return False

        data = await self._guild(guild_id)
        if data.get("whitelist_enabled") and data.get("whitelist"):
            return user_id not in set(data["whitelist"])
        if user_id in set(data.get("blacklist", [])):
            return True

        return False


# DisabledCogCache


class DisabledCogCache:
    """Cache for global and per-guild cog enable/disable state.

    Hot path: called on every slash command and prefix command in
    EmberBot._global_access_check().

    Global state is a flat dict loaded once and invalidated on change.
    Guild state is loaded lazily per guild and invalidated on change.
    """

    def __init__(self) -> None:
        from core.store import Store

        self._cfg = Store.for_cog("cog_manager", 900_001)
        self._cfg.defaults(
            {
                "global": {"global_enabled": {}},
                "guild": {"guild_enabled": {}},
            }
        )

        self._global: dict[str, bool] = {}
        self._global_loaded = False
        self._guild: dict[int, dict[str, bool]] = {}

    async def _load_global(self) -> dict[str, bool]:
        if not self._global_loaded:
            self._global = dict(await self._cfg.get("global", 0, "global_enabled") or {})
            self._global_loaded = True
        return self._global

    async def _load_guild(self, guild_id: int) -> dict[str, bool]:
        if guild_id not in self._guild:
            self._guild[guild_id] = dict(
                await self._cfg.get("guild", guild_id, "guild_enabled") or {}
            )
        return self._guild[guild_id]

    def invalidate_global(self, cog_name: str | None = None) -> None:
        if cog_name is None:
            self._global_loaded = False
            self._global.clear()
        else:
            self._global.pop(cog_name, None)
            self._global_loaded = False

    def invalidate_guild(self, guild_id: int, cog_name: str | None = None) -> None:
        if cog_name is None:
            self._guild.pop(guild_id, None)
        else:
            guild_map = self._guild.get(guild_id)
            if guild_map is not None:
                guild_map.pop(cog_name, None)

    async def is_enabled_globally(self, cog_name: str) -> bool:
        global_map = await self._load_global()
        return bool(global_map.get(cog_name, True))

    async def is_enabled_in_guild(self, cog_name: str, guild_id: int) -> bool:
        if not await self.is_enabled_globally(cog_name):
            return False
        guild_map = await self._load_guild(guild_id)
        return bool(guild_map.get(cog_name, True))

    async def set_global_enabled(self, cog_name: str, enabled: bool) -> None:
        global_map = await self._load_global()
        global_map[cog_name] = enabled
        await self._cfg.set("global", 0, "global_enabled", dict(global_map))
        self.invalidate_global(cog_name)

    async def set_guild_enabled(self, cog_name: str, guild_id: int, enabled: bool) -> None:
        guild_map = await self._load_guild(guild_id)
        if enabled:
            guild_map.pop(cog_name, None)
        else:
            guild_map[cog_name] = False
        await self._cfg.set("guild", guild_id, "guild_enabled", dict(guild_map))
        # No explicit invalidation needed; cache already updated.


# I18nManager


class I18nManager:
    """Cache for per-guild locale settings. Falls back to global locale."""

    DEFAULT_LOCALE = "en-US"

    def __init__(self) -> None:
        from core.store import Store

        self._cfg = Store.for_cog("EmberI18n", 200_004)
        self._cfg.defaults(
            {
                "global": {"locale": self.DEFAULT_LOCALE},
                "guild": {"locale": None},
            }
        )
        self._guild_cache: dict[int, str] = {}
        self._global_locale: str | None = None

    async def get_global_locale(self) -> str:
        if self._global_locale is None:
            self._global_locale = await self._cfg.get("global", 0, "locale") or self.DEFAULT_LOCALE
        return self._global_locale

    async def set_global_locale(self, locale: str) -> None:
        await self._cfg.set("global", 0, "locale", locale)
        self._global_locale = locale
        self._guild_cache.clear()

    async def get_guild_locale(self, guild_id: int) -> str:
        if guild_id in self._guild_cache:
            return self._guild_cache[guild_id]
        result = await self._cfg.get_cascading(
            "locale",
            ("guild", guild_id),
            ("global", 0),
            default=self.DEFAULT_LOCALE,
        )
        self._guild_cache[guild_id] = result
        return result

    async def set_guild_locale(self, guild_id: int, locale: str | None) -> None:
        await self._cfg.set("guild", guild_id, "locale", locale)
        self._guild_cache.pop(guild_id, None)

    def invalidate(self, guild_id: int) -> None:
        self._guild_cache.pop(guild_id, None)

    def invalidate_all(self) -> None:
        self._guild_cache.clear()
        self._global_locale = None


# Module-level singletons  (import these, not the classes)

prefix_mgr = PrefixManager()
ignore_mgr = IgnoreManager()
wb_mgr = WhitelistBlacklistManager()
cog_cache = DisabledCogCache()
i18n_mgr = I18nManager()
