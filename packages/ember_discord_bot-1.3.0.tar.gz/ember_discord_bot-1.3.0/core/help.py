from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.store import Store
from utils.cards import PaginatedView, make_error_card, make_info_card

logger = logging.getLogger("ember.help")

_config = Store.for_cog("EmberHelp", 500_001)
_config.defaults({"guild": {"help_per_page": 10, "help_show_brief": True}})


@dataclass
class HelpSettings:
    per_page: int = 10
    show_hidden: bool = False
    show_brief: bool = True


async def _get_settings(guild_id: int | None) -> HelpSettings:
    if guild_id is None:
        return HelpSettings()
    per_page = await _config.get("guild", guild_id, "help_per_page")
    show_brief = await _config.get("guild", guild_id, "help_show_brief")
    return HelpSettings(
        per_page=per_page or 10,
        show_brief=show_brief if show_brief is not None else True,
    )


def _cog_lines(
    bot: commands.Bot,
    settings: HelpSettings,
) -> list[str]:
    """One line per cog: ``**CogName** — N commands``."""
    lines: list[str] = []
    seen_cogs: set[str] = set()

    for cmd in sorted(bot.tree.walk_commands(), key=lambda c: c.qualified_name):
        # App commands bind to a cog via their binding attribute
        binding = getattr(cmd, "binding", None)
        if binding is None:
            cog_name = "General"
        else:
            cog_name = type(binding).__name__

        if cog_name not in seen_cogs:
            seen_cogs.add(cog_name)
            # Count top-level commands in this cog
            count = sum(
                1
                for c in bot.tree.walk_commands()
                if _cmd_cog_name(c) == cog_name and not isinstance(c, app_commands.Group)
            )
            if count:
                lines.append(f"**{cog_name}** — {count} command{'s' if count != 1 else ''}")

    return lines or ["No commands loaded."]


def _cog_command_lines(
    bot: commands.Bot,
    cog_name: str,
    settings: HelpSettings,
) -> list[str]:
    """One line per command in *cog_name*: `` `/name` — brief``."""
    lines: list[str] = []
    for cmd in sorted(bot.tree.walk_commands(), key=lambda c: c.qualified_name):
        if isinstance(cmd, app_commands.Group):
            continue
        if _cmd_cog_name(cmd) != cog_name:
            continue
        brief = cmd.description or ""
        entry = f"`/{cmd.qualified_name}`"
        if settings.show_brief and brief:
            entry += f" — {brief}"
        lines.append(entry)
    return lines or [f"No commands found for **{cog_name}**."]


def _command_detail(cmd: app_commands.Command[Any, Any, Any]) -> discord.ui.LayoutView:
    """Info card for a single command."""
    params = (
        "\n".join(
            f"• `{p.name}` — {p.description}" + (" *(optional)*" if not p.required else "")
            for p in cmd.parameters
        )
        or "No parameters."
    )
    body = f"{cmd.description or 'No description.'}\n\n**Parameters:**\n{params}"
    cog_name = _cmd_cog_name(cmd)
    return make_info_card(
        f"/{cmd.qualified_name}",
        body,
        footer=f"Cog: {cog_name}",
    )


def _cmd_cog_name(cmd: app_commands.Command[Any, Any, Any] | app_commands.Group) -> str:
    binding = getattr(cmd, "binding", None)
    if binding is None:
        return "General"
    return type(binding).__name__


def _build_help_command(bot: commands.Bot) -> app_commands.Command:

    @app_commands.command(name="help", description="Browse available commands")
    @app_commands.describe(query="Cog or command name to look up (leave blank for overview)")
    async def help_cmd(interaction: discord.Interaction, query: str = "") -> None:
        await interaction.response.defer(ephemeral=True)
        settings = await _get_settings(interaction.guild.id if interaction.guild else None)
        query = query.strip()

        if not query:
            # Overview: one line per cog
            lines = _cog_lines(bot, settings)
            view = PaginatedView(
                pages=lines,
                title="🤖 Help — All Cogs",
                per_page=settings.per_page,
            )
            await interaction.followup.send(view=view, ephemeral=True)
            return

        # Try matching as a cog name (case-insensitive)
        for cmd in bot.tree.walk_commands():
            if isinstance(cmd, app_commands.Group):
                continue
            if _cmd_cog_name(cmd).lower() == query.lower():
                lines = _cog_command_lines(bot, _cmd_cog_name(cmd), settings)
                view = PaginatedView(
                    pages=lines,
                    title=f"📦 {_cmd_cog_name(cmd)}",
                    per_page=settings.per_page,
                )
                await interaction.followup.send(view=view, ephemeral=True)
                return

        # Try matching as a command qualified name (e.g. "admin cog reload")
        query_norm = query.replace(" ", " ").lower()
        for cmd in bot.tree.walk_commands():
            if isinstance(cmd, app_commands.Group):
                continue
            if cmd.qualified_name.lower() == query_norm:
                await interaction.followup.send(view=_command_detail(cmd), ephemeral=True)
                return

        # Nothing found
        await interaction.followup.send(
            view=make_error_card("❌ Not Found", f"No cog or command matching `{query}`."),
            ephemeral=True,
        )

    # Autocomplete
    @help_cmd.autocomplete("query")
    async def _autocomplete(
        interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        current_lower = current.lower()
        choices: list[app_commands.Choice[str]] = []
        seen: set[str] = set()

        # Add cog names
        for cmd in bot.tree.walk_commands():
            cog = _cmd_cog_name(cmd)
            if cog not in seen and current_lower in cog.lower():
                seen.add(cog)
                choices.append(app_commands.Choice(name=cog, value=cog))

        # Add command qualified names
        for cmd in bot.tree.walk_commands():
            if isinstance(cmd, app_commands.Group):
                continue
            name = cmd.qualified_name
            if current_lower in name.lower() and name not in seen:
                seen.add(name)
                choices.append(app_commands.Choice(name=f"/{name}", value=name))

        return choices[:25]

    return help_cmd


async def register_help(bot: commands.Bot) -> None:
    """Register the /help command on *bot*'s app command tree."""
    # Remove any existing help command (prefix or slash)
    bot.remove_command("help")
    existing = bot.tree.get_command("help")
    if existing:
        bot.tree.remove_command("help")

    bot.tree.add_command(_build_help_command(bot))
    logger.info("/help command registered")
