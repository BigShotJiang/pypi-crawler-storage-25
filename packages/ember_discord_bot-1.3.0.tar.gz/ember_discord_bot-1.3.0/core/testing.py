"""Pytest plugin for Ember cog authors.

Activate with::

    pytest_plugins = ["core.testing"]

or by installing Ember and running ``pytest`` (registered as the
``ember`` entry point).

Provides fixtures that spin up:

- ``ember_driver`` / ``ember_store`` — an in-memory storage layer so the
  cog under test can read/write config without touching disk.
- ``mock_bot`` — a ``MagicMock`` standing in for ``EmberBot`` with the
  surface most cog tests need (``user``, ``is_owner``, ``send_to_owners``).
- ``mock_interaction`` — a ``MagicMock`` ``discord.Interaction`` with
  awaitable response/followup helpers and a synthetic guild/member.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest


@pytest.fixture
async def ember_driver(tmp_path: Path):
    """A real SQLite driver pointed at a tmp DB; safe to use in parallel tests."""
    from core._drivers.sqlite import SQLiteDriver

    driver = SQLiteDriver(tmp_path / "test.db")
    await driver.initialize()
    return driver


@pytest.fixture
def ember_store(ember_driver):
    """A Store bound to a fresh cog name, sharing the test driver."""
    from core import _drivers
    from core.store import Store

    _drivers.set_driver(ember_driver)
    return Store.for_cog("test_cog", 1)


@pytest.fixture
def mock_bot() -> MagicMock:
    """A MagicMock EmberBot with the most-used surface stubbed."""
    bot = MagicMock()
    bot.user = MagicMock(id=999, name="EmberTest")
    bot.user.mention = "<@999>"
    bot.is_owner = AsyncMock(return_value=True)
    bot.send_to_owners = AsyncMock()
    bot.get_guild = MagicMock(return_value=None)
    bot.guilds = []
    bot.cogs = {}
    bot.tree = MagicMock()
    bot.latency = 0.05
    return bot


@pytest.fixture
def mock_guild() -> MagicMock:
    guild = MagicMock(id=1, name="TestGuild")
    guild.member_count = 10
    guild.me = MagicMock(id=999, edit=AsyncMock())
    guild.get_channel = MagicMock(return_value=None)
    guild.get_role = MagicMock(return_value=None)
    return guild


@pytest.fixture
def mock_member(mock_guild: MagicMock) -> MagicMock:
    member = MagicMock(id=42, name="TestUser", bot=False)
    member.mention = "<@42>"
    member.guild = mock_guild
    member.guild_permissions = MagicMock(administrator=False, manage_guild=False)
    return member


@pytest.fixture
def mock_interaction(mock_bot: MagicMock, mock_guild: MagicMock, mock_member: MagicMock):
    """A MagicMock discord.Interaction with awaitable response/followup."""
    interaction = MagicMock()
    interaction.user = mock_member
    interaction.guild = mock_guild
    interaction.guild_id = mock_guild.id
    interaction.channel = MagicMock(id=2, mention="<#2>")
    interaction.client = mock_bot
    interaction.command = MagicMock(qualified_name="test_cmd")

    response = MagicMock()
    response.is_done = MagicMock(return_value=False)
    response.send_message = AsyncMock()
    response.defer = AsyncMock()
    interaction.response = response

    followup = MagicMock()
    followup.send = AsyncMock()
    interaction.followup = followup

    interaction.original_response = AsyncMock(return_value=MagicMock())
    return interaction


def make_message(
    content: str,
    *,
    author: Any | None = None,
    guild: Any | None = None,
    channel: Any | None = None,
) -> MagicMock:
    """Build a MagicMock ``discord.Message`` for on_message listener tests."""
    msg = MagicMock()
    msg.content = content
    msg.author = author or MagicMock(id=42, name="TestUser", bot=False)
    msg.guild = guild
    msg.channel = channel or MagicMock(id=2)
    return msg
