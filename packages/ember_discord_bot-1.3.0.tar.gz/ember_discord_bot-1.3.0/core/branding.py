import discord


class EmberColors:
    PRIMARY = discord.Color.from_str("#5865F2")
    SUCCESS = discord.Color.from_str("#57F287")
    ERROR = discord.Color.from_str("#ED4245")
    WARNING = discord.Color.from_str("#FEE75C")
    INFO = discord.Color.from_str("#5865F2")
    NEUTRAL = discord.Color.from_str("#4f545c")
    SECONDARY = discord.Color.from_str("#4f545c")
    BRAND_PRIMARY = PRIMARY  # compat alias


class EmberIcons:
    SUCCESS = "✅"
    ERROR = "❌"
    WARNING = "⚠️"
    INFO = "ℹ️"
    CONFIRM = "✅"
    CANCEL = "❌"
    EDIT = "✏️"
    DELETE = "🗑️"
    SETTINGS = "⚙️"
    USER = "👤"
    CHANNEL = "💬"
    ROLE = "🎭"
    TIME = "⏰"
    ADD = "➕"
    REMOVE = "➖"
    SEARCH = "🔍"
    LOADING = "🔄"
    MONEY = "💰"
    SHIELD = "🛡️"
    HAMMER = "🔨"
    STAR = "⭐"

    @classmethod
    def for_status(cls, status: str) -> str:
        return {
            "success": cls.SUCCESS,
            "error": cls.ERROR,
            "warning": cls.WARNING,
            "info": cls.INFO,
        }.get(status.lower(), cls.INFO)

    @classmethod
    def for_case(cls, action: str) -> str:
        return {
            "ban": "🔨",
            "kick": "👢",
            "warn": "⚠️",
            "timeout": "⏱️",
            "mute": "🔇",
            "unban": "🕊️",
            "note": "📝",
            "softban": "💨",
            "hackban": "🔨",
            "voicekick": "🎙️",
            "voiceban": "🔇",
        }.get(action.lower(), "📋")


BOT_NAME = "Ember"
TAGLINE = "Modular. Modern. Production-ready Discord bot framework."
DEFAULT_PREFIX = "!"
ACCENT_COLOR = discord.Color.from_str("#FF6600")
SUPPORT_URL = "https://github.com/guardiansofspartax/Ember"
INVITE_URL = None
FOOTER_TEXT = f"{BOT_NAME} Discord Bot"
LOGO_URL = None

__all__ = [
    "EmberColors",
    "EmberIcons",
    "BOT_NAME",
    "TAGLINE",
    "DEFAULT_PREFIX",
    "ACCENT_COLOR",
    "SUPPORT_URL",
    "INVITE_URL",
    "FOOTER_TEXT",
    "LOGO_URL",
]
