from __future__ import annotations

from enum import StrEnum
from pathlib import Path

from .base import BaseDriver, ConfigScope, ScopeKey
from .json_driver import JsonDriver
from .sqlite import SQLiteDriver

__all__ = [
    "BaseDriver",
    "ConfigScope",
    "ScopeKey",
    "BackendType",
    "SQLiteDriver",
    "JsonDriver",
    "PostgresDriver",
    "MongoDriver",
    "get_driver",
    "get_driver_class",
    "set_driver",
]

try:
    from .postgres import PostgresDriver
except ImportError:
    PostgresDriver = None

try:
    from .mongo import MongoDriver
except ImportError:
    MongoDriver = None


class BackendType(StrEnum):
    SQLITE = "sqlite"
    JSON = "json"
    POSTGRES = "postgres"
    MONGO = "mongo"


_DRIVER_CLASSES: dict[BackendType, type[BaseDriver]] = {
    BackendType.SQLITE: SQLiteDriver,
    BackendType.JSON: JsonDriver,
}
if PostgresDriver is not None:
    _DRIVER_CLASSES[BackendType.POSTGRES] = PostgresDriver
if MongoDriver is not None:
    _DRIVER_CLASSES[BackendType.MONGO] = MongoDriver

_driver_instance: BaseDriver | None = None


def get_driver_class(backend: BackendType | None = None) -> type[BaseDriver]:
    if backend is None:
        import os

        env = os.environ.get("EMBER_DB_BACKEND", "sqlite").lower()
        try:
            backend = BackendType(env)
        except ValueError:
            backend = BackendType.SQLITE
    if backend not in _DRIVER_CLASSES:
        raise ValueError(f"Backend {backend!r} is not available. Install required dependencies.")
    return _DRIVER_CLASSES[backend]


def get_driver(backend: BackendType | None = None) -> BaseDriver:
    """Return the shared driver singleton, creating it if needed."""
    global _driver_instance
    if _driver_instance is None:
        cls = get_driver_class(backend)
        if cls is SQLiteDriver:
            _driver_instance = cls(Path("data/ember_config.db"))
        elif PostgresDriver is not None and cls is PostgresDriver:
            import os

            dsn = os.environ.get("EMBER_POSTGRES_DSN", "postgresql://localhost/ember")
            _driver_instance = cls(dsn)
        elif MongoDriver is not None and cls is MongoDriver:
            import os

            uri = os.environ.get("EMBER_MONGO_URI", "mongodb://localhost:27017/ember")
            _driver_instance = cls(uri)
        else:
            _driver_instance = cls()

        from .cache import CachingDriver, cache_enabled

        if cache_enabled():
            _driver_instance = CachingDriver(_driver_instance)
    return _driver_instance


def set_driver(driver: BaseDriver) -> None:
    """Override the driver singleton (useful for testing)."""
    global _driver_instance
    _driver_instance = driver
