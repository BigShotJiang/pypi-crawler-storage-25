from __future__ import annotations

import logging
import os
from typing import Any

try:
    import motor.motor_asyncio
    import pymongo
except ModuleNotFoundError:
    motor = None
    pymongo = None

from .base import BaseDriver, ConfigScope

logger = logging.getLogger("ember.driver.mongo")

__all__ = ["MongoDriver"]

# Collection name for the flat key-value config store
_CONFIG_COLLECTION = "ember_config"


def _scope_key(
    cog_name: str,
    identifier: int,
    scope: ConfigScope,
    scope_id_1: str,
    scope_id_2: str,
) -> dict[str, Any]:
    """Build the compound _id used to identify one scope-instance document."""
    return {
        "c": cog_name,
        "i": identifier,
        "s": scope.value,
        "s1": scope_id_1,
        "s2": scope_id_2,
    }


class MongoDriver(BaseDriver):
    """Async MongoDB backend via motor.

    All config keys for a given (cog, identifier, scope, scope_id_1, scope_id_2)
    are stored as sub-fields inside a single document, keyed by the compound _id
    returned by :func:`_scope_key`.  Table helpers store each record as its own
    document in a per-(cog, identifier, table) collection.
    """

    _client: motor.motor_asyncio.AsyncIOMotorClient | None = None
    _db: motor.motor_asyncio.AsyncIOMotorDatabase | None = None

    def __init__(self, uri: str | None = None) -> None:
        if motor is None:
            raise ImportError(
                "motor is required for the MongoDB driver. " "Install it with: pip install motor"
            )
        self._uri = uri or os.environ.get("EMBER_MONGO_URI", "mongodb://localhost:27017/ember")

    async def initialize(self) -> None:
        self._client = motor.motor_asyncio.AsyncIOMotorClient(self._uri)
        # Derive DB name from the URI path component (last segment after /)
        db_name = self._uri.rstrip("/").rsplit("/", 1)[-1] or "ember"
        self._db = self._client[db_name]

        # Ensure a compound index on the config collection
        col = self._db[_CONFIG_COLLECTION]
        await col.create_index(
            [
                ("_id.c", pymongo.ASCENDING),
                ("_id.i", pymongo.ASCENDING),
                ("_id.s", pymongo.ASCENDING),
            ],
            background=True,
        )
        logger.debug("MongoDriver initialised — db=%s", db_name)

    @property
    def _config(self) -> motor.motor_asyncio.AsyncIOMotorCollection:
        assert self._db is not None, "MongoDriver not initialized"
        return self._db[_CONFIG_COLLECTION]

    def _table_col(
        self, cog_name: str, identifier: int, table: str
    ) -> motor.motor_asyncio.AsyncIOMotorCollection:
        """Return the collection used for table-helper records."""
        assert self._db is not None, "MongoDriver not initialized"
        return self._db[f"{cog_name}__{identifier}__{table}"]

    async def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> Any:
        doc = await self._config.find_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)},
            projection={"_id": False, f"data.{key}": True},
        )
        if doc is None:
            return None
        return doc.get("data", {}).get(key)

    async def set(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
        value: Any,
    ) -> None:
        await self._config.update_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)},
            {"$set": {f"data.{key}": value}},
            upsert=True,
        )

    async def delete(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> None:
        await self._config.update_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)},
            {"$unset": {f"data.{key}": ""}},
        )

    async def get_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> dict[str, Any]:
        doc = await self._config.find_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)},
            projection={"_id": False, "data": True},
        )
        if doc is None:
            return {}
        return doc.get("data", {})

    async def set_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        data: dict[str, Any],
    ) -> None:
        set_fields = {f"data.{k}": v for k, v in data.items()}
        await self._config.update_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)},
            {"$set": set_fields},
            upsert=True,
        )

    async def clear_scope(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> None:
        await self._config.delete_one(
            {"_id": _scope_key(cog_name, identifier, scope, scope_id_1, scope_id_2)}
        )

    async def get_all_scope_ids(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
    ) -> list[tuple[str, str]]:
        cursor = self._config.find(
            {"_id.c": cog_name, "_id.i": identifier, "_id.s": scope.value},
            projection={"_id": True},
        )
        results = []
        async for doc in cursor:
            key = doc["_id"]
            results.append((key["s1"], key["s2"]))
        return results

    async def clear_cog(self, cog_name: str, identifier: int) -> None:
        await self._config.delete_many({"_id.c": cog_name, "_id.i": identifier})

    async def export(self) -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        async for doc in self._config.find():
            key = doc["_id"]
            for k, v in doc.get("data", {}).items():
                rows.append(
                    {
                        "cog_name": key["c"],
                        "identifier": key["i"],
                        "scope": key["s"],
                        "scope_id_1": key["s1"],
                        "scope_id_2": key["s2"],
                        "key": k,
                        "value": v,
                    }
                )
        return {"driver": "mongo", "rows": rows}

    async def import_data(self, data: dict[str, Any]) -> None:
        rows = data.get("rows", [])
        for row in rows:
            scope = ConfigScope(row["scope"])
            await self.set(
                row["cog_name"],
                row["identifier"],
                scope,
                row["scope_id_1"],
                row["scope_id_2"],
                row["key"],
                row["value"],
            )

    async def store_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        data: dict[str, Any],
    ) -> None:
        if not data:
            return
        col = self._table_col(cog_name, identifier, table)
        # Use the first field as the primary key for upsert semantics
        pk_field = next(iter(data))
        await col.replace_one({pk_field: data[pk_field]}, data, upsert=True)

    async def get_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> dict[str, Any] | None:
        col = self._table_col(cog_name, identifier, table)
        query = _build_simple_query(where, params)
        doc = await col.find_one(query, projection={"_id": False})
        return doc

    async def get_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
        order_by: str,
    ) -> list[dict[str, Any]]:
        col = self._table_col(cog_name, identifier, table)
        query = _build_simple_query(where, params)
        cursor = col.find(query, projection={"_id": False})
        if order_by:
            cursor = cursor.sort(order_by, pymongo.ASCENDING)
        return [doc async for doc in cursor]

    async def delete_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        col = self._table_col(cog_name, identifier, table)
        query = _build_simple_query(where, params)
        result = await col.delete_many(query)
        return result.deleted_count

    async def count_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        col = self._table_col(cog_name, identifier, table)
        query = _build_simple_query(where, params)
        return await col.count_documents(query)


def _build_simple_query(where: str, params: tuple[Any, ...]) -> dict[str, Any]:
    """Convert a trivial ``field = ?`` / ``field = %s`` WHERE clause to a Mongo filter.

    Only supports simple equality chains joined with AND.  For complex SQL
    predicates, callers should switch to a SQL-capable backend.
    """
    if not where:
        return {}
    query: dict[str, Any] = {}
    param_iter = iter(params)
    for part in where.split(" AND "):
        part = part.strip()
        # Accepts "field = ?" or "field = %s"
        if "=" not in part:
            continue
        field, _ = part.split("=", 1)
        field = field.strip()
        try:
            query[field] = next(param_iter)
        except StopIteration:
            break
    return query
