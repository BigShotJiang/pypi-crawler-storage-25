from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

import aiosqlite

from .base import BaseDriver, ConfigScope

logger = logging.getLogger("ember.driver.sqlite")

_DB_PATH = Path("data/ember_config.db")
_CONFIG_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS config_values (
    cog_name    TEXT    NOT NULL,
    identifier  TEXT    NOT NULL,
    scope       TEXT    NOT NULL,
    scope_id_1  TEXT    NOT NULL DEFAULT '',
    scope_id_2  TEXT    NOT NULL DEFAULT '',
    key         TEXT    NOT NULL,
    value       TEXT,
    PRIMARY KEY (cog_name, identifier, scope, scope_id_1, scope_id_2, key)
);
CREATE INDEX IF NOT EXISTS idx_config_scope
    ON config_values (cog_name, identifier, scope, scope_id_1);
"""

_SAFE_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _check_ident(name: str) -> str:
    """Validate a SQL identifier (table/column name) to prevent injection."""
    if not _SAFE_IDENT.match(name):
        raise ValueError(f"Unsafe SQL identifier: {name!r}")
    return name


def _enc(val: Any) -> str:
    return json.dumps(val, ensure_ascii=False)


def _dec(raw: str | None) -> Any:
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return raw


class SQLiteDriver(BaseDriver):
    def __init__(self, db_path: Path = _DB_PATH) -> None:
        self._path = db_path

    async def initialize(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self._path) as db:
            await db.executescript(_CONFIG_SCHEMA)
            await db.commit()
        logger.debug("SQLiteDriver initialized at %s", self._path)

    async def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> Any:
        async with aiosqlite.connect(self._path) as db:
            async with db.execute(
                "SELECT value FROM config_values "
                "WHERE cog_name=? AND identifier=? AND scope=? "
                "AND scope_id_1=? AND scope_id_2=? AND key=?",
                (cog_name, identifier, scope.value, scope_id_1, scope_id_2, key),
            ) as cur:
                row = await cur.fetchone()
                return _dec(row[0]) if row else None

    async def set(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
        value: Any,
    ) -> None:
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                "INSERT OR REPLACE INTO config_values "
                "(cog_name, identifier, scope, scope_id_1, scope_id_2, key, value) "
                "VALUES (?,?,?,?,?,?,?)",
                (cog_name, identifier, scope.value, scope_id_1, scope_id_2, key, _enc(value)),
            )
            await db.commit()

    async def delete(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> None:
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                "DELETE FROM config_values "
                "WHERE cog_name=? AND identifier=? AND scope=? "
                "AND scope_id_1=? AND scope_id_2=? AND key=?",
                (cog_name, identifier, scope.value, scope_id_1, scope_id_2, key),
            )
            await db.commit()

    async def get_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> dict[str, Any]:
        async with aiosqlite.connect(self._path) as db:
            async with db.execute(
                "SELECT key, value FROM config_values "
                "WHERE cog_name=? AND identifier=? AND scope=? "
                "AND scope_id_1=? AND scope_id_2=?",
                (cog_name, identifier, scope.value, scope_id_1, scope_id_2),
            ) as cur:
                rows = await cur.fetchall()
                return {r[0]: _dec(r[1]) for r in rows}

    async def set_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        data: dict[str, Any],
    ) -> None:
        async with aiosqlite.connect(self._path) as db:
            await db.executemany(
                "INSERT OR REPLACE INTO config_values "
                "(cog_name, identifier, scope, scope_id_1, scope_id_2, key, value) "
                "VALUES (?,?,?,?,?,?,?)",
                [
                    (
                        cog_name,
                        identifier,
                        scope.value,
                        scope_id_1,
                        scope_id_2,
                        k,
                        _enc(v),
                    )
                    for k, v in data.items()
                ],
            )
            await db.commit()

    async def clear_scope(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> None:
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                "DELETE FROM config_values "
                "WHERE cog_name=? AND identifier=? AND scope=? "
                "AND scope_id_1=? AND scope_id_2=?",
                (cog_name, identifier, scope.value, scope_id_1, scope_id_2),
            )
            await db.commit()

    async def get_all_scope_ids(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
    ) -> list[tuple[str, str]]:
        async with aiosqlite.connect(self._path) as db:
            async with db.execute(
                "SELECT DISTINCT scope_id_1, scope_id_2 FROM config_values "
                "WHERE cog_name=? AND identifier=? AND scope=?",
                (cog_name, identifier, scope.value),
            ) as cur:
                return [(r[0], r[1]) for r in await cur.fetchall()]

    async def clear_cog(self, cog_name: str, identifier: int) -> None:
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                "DELETE FROM config_values WHERE cog_name=? AND identifier=?",
                (cog_name, identifier),
            )
            await db.commit()

    async def export(self) -> dict[str, Any]:
        async with aiosqlite.connect(self._path) as db:
            async with db.execute("SELECT * FROM config_values") as cur:
                rows = await cur.fetchall()
        return {
            "driver": "sqlite",
            "rows": [
                {
                    "cog_name": r[0],
                    "identifier": r[1],
                    "scope": r[2],
                    "scope_id_1": r[3],
                    "scope_id_2": r[4],
                    "key": r[5],
                    "value": r[6],
                }
                for r in rows
            ],
        }

    async def import_data(self, data: dict[str, Any]) -> None:
        rows = data.get("rows", [])
        async with aiosqlite.connect(self._path) as db:
            await db.executemany(
                "INSERT OR REPLACE INTO config_values "
                "(cog_name, identifier, scope, scope_id_1, scope_id_2, key, value) "
                "VALUES (?,?,?,?,?,?,?)",
                [
                    (
                        r["cog_name"],
                        r["identifier"],
                        r["scope"],
                        r["scope_id_1"],
                        r["scope_id_2"],
                        r["key"],
                        r["value"],
                    )
                    for r in rows
                ],
            )
            await db.commit()

    async def execute_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> int:
        """Execute a raw SQL statement in the per-cog database."""
        db_path = await self._get_table_path(cog_name, identifier, "")
        async with aiosqlite.connect(db_path) as db:
            async with db.execute(sql, params) as cur:
                await db.commit()
                return cur.rowcount

    async def fetch_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> list[dict[str, Any]]:
        # commits after fetch so UPDATE ... RETURNING persists
        db_path = await self._get_table_path(cog_name, identifier, "")
        async with aiosqlite.connect(db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(sql, params) as cur:
                rows = await cur.fetchall()
            await db.commit()
            return [dict(r) for r in rows]

    async def _get_table_path(self, cog_name: str, identifier: int, table: str) -> Path:
        """Return the SQLite DB file for this cog's data."""
        base = Path("data/cogs") / cog_name
        base.mkdir(parents=True, exist_ok=True)
        return base / f"{identifier}.db"

    async def store_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        data: dict[str, Any],
        *,
        pk_columns: list[str] | None = None,
    ) -> None:
        safe_table = _check_ident(table)
        safe_cols = [_check_ident(c) for c in data.keys()]
        db_path = await self._get_table_path(cog_name, identifier, table)
        async with aiosqlite.connect(db_path) as db:
            placeholders = ", ".join("?" * len(safe_cols))
            sql = (
                f"INSERT OR REPLACE INTO {safe_table} ({', '.join(safe_cols)}) "
                f"VALUES ({placeholders})"
            )
            await db.execute(sql, tuple(data[c] for c in data.keys()))
            await db.commit()

    async def get_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> dict[str, Any] | None:
        rows = await self.get_records(cog_name, identifier, table, where, params, "")
        return rows[0] if rows else None

    async def get_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
        order_by: str,
    ) -> list[dict[str, Any]]:
        safe_table = _check_ident(table)
        safe_order = _check_ident(order_by) if order_by else ""
        db_path = await self._get_table_path(cog_name, identifier, table)
        async with aiosqlite.connect(db_path) as db:
            db.row_factory = aiosqlite.Row
            sql = f"SELECT * FROM {safe_table}"
            if where:
                sql += f" WHERE {where}"
            if safe_order:
                sql += f" ORDER BY {safe_order}"
            async with db.execute(sql, params) as cur:
                rows = await cur.fetchall()
                return [dict(r) for r in rows]

    async def delete_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        safe_table = _check_ident(table)
        db_path = await self._get_table_path(cog_name, identifier, table)
        async with aiosqlite.connect(db_path) as db:
            sql = f"DELETE FROM {safe_table}"
            if where:
                sql += f" WHERE {where}"
            async with db.execute(sql, params) as cur:
                await db.commit()
                return cur.rowcount

    async def count_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        safe_table = _check_ident(table)
        db_path = await self._get_table_path(cog_name, identifier, table)
        async with aiosqlite.connect(db_path) as db:
            sql = f"SELECT COUNT(*) FROM {safe_table}"
            if where:
                sql += f" WHERE {where}"
            async with db.execute(sql, params) as cur:
                row = await cur.fetchone()
                return row[0] if row else 0
