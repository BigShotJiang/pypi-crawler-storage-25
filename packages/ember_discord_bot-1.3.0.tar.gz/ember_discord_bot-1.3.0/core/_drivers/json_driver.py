from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from .base import BaseDriver, ConfigScope

logger = logging.getLogger("ember.driver.json")

_DATA_DIR = Path("data/config_json")


def _deep_set(d: dict[str, Any], keys: list[str], value: Any) -> None:
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    d[keys[-1]] = value


def _deep_get(d: dict[str, Any], keys: list[str], default: Any = None) -> Any:
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return default
        d = d[k]
    return d


def _deep_del(d: dict[str, Any], keys: list[str]) -> None:
    for k in keys[:-1]:
        if not isinstance(d, dict) or k not in d:
            return
        d = d[k]
    d.pop(keys[-1], None)


class JsonDriver(BaseDriver):
    def __init__(self, data_dir: Path = _DATA_DIR) -> None:
        self._dir = data_dir
        self._lock = asyncio.Lock()

    async def initialize(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)

    def _path(self, cog_name: str, identifier: int) -> Path:
        return self._dir / f"{cog_name}_{identifier}.json"

    def _load(self, cog_name: str, identifier: int) -> dict[str, Any]:
        p = self._path(cog_name, identifier)
        if not p.exists():
            return {}
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, cog_name: str, identifier: int, data: dict[str, Any]) -> None:
        p = self._path(cog_name, identifier)
        p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _keys(self, scope: ConfigScope, id1: str, id2: str, key: str) -> list[str]:
        if scope == ConfigScope.GLOBAL:
            return [scope.value, key]
        if scope in (ConfigScope.GUILD, ConfigScope.CHANNEL, ConfigScope.USER, ConfigScope.ROLE):
            return [scope.value, id1, key]
        if scope == ConfigScope.MEMBER:
            return [scope.value, id1, id2, key]
        return [scope.value, id1, id2, key]

    def _scope_keys(self, scope: ConfigScope, id1: str, id2: str) -> list[str]:
        if scope == ConfigScope.GLOBAL:
            return [scope.value]
        if scope in (ConfigScope.GUILD, ConfigScope.CHANNEL, ConfigScope.USER, ConfigScope.ROLE):
            return [scope.value, id1]
        return [scope.value, id1, id2]

    async def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> Any:
        async with self._lock:
            data = self._load(cog_name, identifier)
            keys = self._keys(scope, scope_id_1, scope_id_2, key)
            return _deep_get(data, keys)

    async def set(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
        value: Any,
    ) -> None:
        async with self._lock:
            data = self._load(cog_name, identifier)
            _deep_set(data, self._keys(scope, scope_id_1, scope_id_2, key), value)
            self._save(cog_name, identifier, data)

    async def delete(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> None:
        async with self._lock:
            data = self._load(cog_name, identifier)
            _deep_del(data, self._keys(scope, scope_id_1, scope_id_2, key))
            self._save(cog_name, identifier, data)

    async def get_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> dict[str, Any]:
        async with self._lock:
            data = self._load(cog_name, identifier)
            sub = _deep_get(data, self._scope_keys(scope, scope_id_1, scope_id_2), {})
            return dict(sub) if isinstance(sub, dict) else {}

    async def set_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        data: dict[str, Any],
    ) -> None:
        async with self._lock:
            full = self._load(cog_name, identifier)
            sub = _deep_get(full, ks := self._scope_keys(scope, scope_id_1, scope_id_2), {})
            if not isinstance(sub, dict):
                sub = {}
            sub.update(data)
            _deep_set(full, ks, sub)
            self._save(cog_name, identifier, full)

    async def clear_scope(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> None:
        async with self._lock:
            data = self._load(cog_name, identifier)
            _deep_del(data, self._scope_keys(scope, scope_id_1, scope_id_2))
            self._save(cog_name, identifier, data)

    async def get_all_scope_ids(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
    ) -> list[tuple[str, str]]:
        async with self._lock:
            data = self._load(cog_name, identifier)
            scope_data = data.get(scope.value, {})
            if scope == ConfigScope.GLOBAL:
                return [("", "")]
            if scope == ConfigScope.MEMBER:
                result = []
                for id1, sub in scope_data.items():
                    if isinstance(sub, dict):
                        for id2 in sub:
                            result.append((id1, id2))
                return result
            return [(k, "") for k in scope_data]

    async def clear_cog(self, cog_name: str, identifier: int) -> None:
        async with self._lock:
            p = self._path(cog_name, identifier)
            p.unlink(missing_ok=True)

    async def export(self) -> dict[str, Any]:
        async with self._lock:
            all_data: dict[str, Any] = {}
            for f in self._dir.glob("*.json"):
                try:
                    all_data[f.stem] = json.loads(f.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    pass
            return {"driver": "json", "files": all_data}

    async def import_data(self, data: dict[str, Any]) -> None:
        async with self._lock:
            for stem, content in data.get("files", {}).items():
                p = self._dir / f"{stem}.json"
                p.write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")

    async def execute_sql(self, cog_name: str, sql: str, params: tuple[Any, ...]) -> int:
        raise NotImplementedError("JSON driver does not support raw SQL")

    async def fetch_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...]
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("JSON driver does not support raw SQL")

    # JSON stores "collections" as lists of dicts in a dedicated section:
    # { "collections": { "modlog": [ {...}, {...} ] } }

    def _collections_path(self, cog_name: str, identifier: int) -> Path:
        return self._path(cog_name, identifier)  # same file

    def _load_collections(self, cog_name: str, identifier: int) -> dict[str, list[dict[str, Any]]]:
        full = self._load(cog_name, identifier)
        return full.get("_collections", {})

    def _save_collections(
        self,
        cog_name: str,
        identifier: int,
        collections: dict[str, list[dict[str, Any]]],
    ) -> None:
        full = self._load(cog_name, identifier)
        full["_collections"] = collections
        self._save(cog_name, identifier, full)

    async def store_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        data: dict[str, Any],
        *,
        pk_columns: list[str] | None = None,
    ) -> None:
        async with self._lock:
            colls = self._load_collections(cog_name, identifier)
            coll = colls.get(table, [])
            pks = pk_columns or (list(data.keys())[:1] if data else [])
            if coll and pks:
                for i, rec in enumerate(coll):
                    if all(rec.get(k) == data.get(k) for k in pks):
                        coll[i] = data
                        break
                else:
                    coll.append(data)
            else:
                coll.append(data)
            colls[table] = coll
            self._save_collections(cog_name, identifier, colls)

    async def get_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> dict[str, Any] | None:
        records = await self.get_records(cog_name, identifier, table, where, params, "")
        return records[0] if records else None

    async def get_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
        order_by: str,
    ) -> list[dict[str, Any]]:
        async with self._lock:
            colls = self._load_collections(cog_name, identifier)
            coll = colls.get(table, [])
            if not where:
                # order_by ignored for JSON — you get list order as stored
                return list(coll)
            # Very simple WHERE parsing: "col = ?" only; combine with AND
            if " AND " in where:
                conditions = where.split(" AND ")
                param_sets = [tuple(params[i : i + 1]) for i in range(len(params))]
                if len(conditions) != len(params):
                    raise ValueError("JSON driver: WHERE conditions must match params count")
                filtered = []
                for rec in coll:
                    ok = True
                    for cond, p in zip(conditions, param_sets, strict=True):
                        col = cond.split("=")[0].strip()
                        if rec.get(col) != p[0]:
                            ok = False
                            break
                    if ok:
                        filtered.append(rec)
                return filtered
            else:
                col = where.split("=")[0].strip()
                val = params[0] if params else None
                return [rec for rec in coll if rec.get(col) == val]

    async def delete_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        async with self._lock:
            colls = self._load_collections(cog_name, identifier)
            coll = colls.get(table, [])
            before = len(coll)
            if not where:
                coll = []
            elif " AND " in where:
                conditions = where.split(" AND ")
                param_sets = [tuple(params[i : i + 1]) for i in range(len(params))]
                if len(conditions) != len(params):
                    raise ValueError("JSON driver: WHERE conditions must match params count")
                coll = [
                    rec
                    for rec, keep in zip(
                        coll,
                        [
                            all(
                                rec.get(c.split("=")[0].strip()) == p[0]
                                for c, p in zip(conditions, param_sets, strict=True)
                            )
                            for rec in coll
                        ],
                        strict=True,
                    )
                    if not keep
                ]
            else:
                col = where.split("=")[0].strip()
                val = params[0] if params else None
                coll = [rec for rec in coll if rec.get(col) != val]
            colls[table] = coll
            self._save_collections(cog_name, identifier, colls)
            return before - len(coll)

    async def count_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        return len(await self.get_records(cog_name, identifier, table, where, params, ""))
