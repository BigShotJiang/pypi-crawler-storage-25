"""Driver-level read cache.

Wraps any ``BaseDriver`` with a per-instance LRU that mirrors the row-level
get/get_all hot path. Writes invalidate. The cache is opt-in via the
``EMBER_DRIVER_CACHE`` env var (``1``/``true``/``yes``).

This complements the higher-level cache in ``Store``: code paths that go
straight to the driver (DatabaseManager helpers, conversion tooling,
in-flight migrations) get the speedup without changes.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Any

from .base import BaseDriver, ConfigScope

_KEY = tuple[str, int, str, str, str]


class CachingDriver(BaseDriver):
    """Decorator that adds an LRU read cache to any ``BaseDriver``."""

    def __init__(self, inner: BaseDriver, *, maxsize: int = 4096) -> None:
        self._inner = inner
        self._maxsize = maxsize
        self._scope_cache: OrderedDict[_KEY, dict[str, Any]] = OrderedDict()
        self.hits = 0
        self.misses = 0

    def _k(self, cog: str, ident: int, scope: ConfigScope, id1: str, id2: str) -> _KEY:
        return (cog, ident, scope.value, id1, id2)

    def _bump(self, key: _KEY, value: dict[str, Any]) -> None:
        self._scope_cache[key] = dict(value)
        self._scope_cache.move_to_end(key)
        if len(self._scope_cache) > self._maxsize:
            self._scope_cache.popitem(last=False)

    def _invalidate(self, key: _KEY) -> None:
        self._scope_cache.pop(key, None)

    def _invalidate_cog(self, cog: str, ident: int) -> None:
        stale = [k for k in self._scope_cache if k[0] == cog and k[1] == ident]
        for k in stale:
            del self._scope_cache[k]

    async def initialize(self) -> None:
        await self._inner.initialize()

    async def get(self, cog, ident, scope, id1, id2, key):
        k = self._k(cog, ident, scope, id1, id2)
        cached = self._scope_cache.get(k)
        if cached is not None:
            self._scope_cache.move_to_end(k)
            self.hits += 1
            return cached.get(key)
        self.misses += 1
        scope_data = await self._inner.get_all(cog, ident, scope, id1, id2)
        self._bump(k, scope_data)
        return scope_data.get(key)

    async def set(self, cog, ident, scope, id1, id2, key, value):
        await self._inner.set(cog, ident, scope, id1, id2, key, value)
        self._invalidate(self._k(cog, ident, scope, id1, id2))

    async def delete(self, cog, ident, scope, id1, id2, key):
        await self._inner.delete(cog, ident, scope, id1, id2, key)
        self._invalidate(self._k(cog, ident, scope, id1, id2))

    async def get_all(self, cog, ident, scope, id1, id2):
        k = self._k(cog, ident, scope, id1, id2)
        cached = self._scope_cache.get(k)
        if cached is not None:
            self._scope_cache.move_to_end(k)
            self.hits += 1
            return dict(cached)
        self.misses += 1
        data = await self._inner.get_all(cog, ident, scope, id1, id2)
        self._bump(k, data)
        return dict(data)

    async def set_all(self, cog, ident, scope, id1, id2, data):
        await self._inner.set_all(cog, ident, scope, id1, id2, data)
        self._invalidate(self._k(cog, ident, scope, id1, id2))

    async def clear_scope(self, cog, ident, scope, id1, id2):
        await self._inner.clear_scope(cog, ident, scope, id1, id2)
        self._invalidate(self._k(cog, ident, scope, id1, id2))

    async def get_all_scope_ids(self, cog, ident, scope):
        return await self._inner.get_all_scope_ids(cog, ident, scope)

    async def clear_cog(self, cog, ident):
        await self._inner.clear_cog(cog, ident)
        self._invalidate_cog(cog, ident)

    async def export(self):
        return await self._inner.export()

    async def import_data(self, data):
        await self._inner.import_data(data)
        self._scope_cache.clear()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def cache_enabled() -> bool:
    import os

    return os.getenv("EMBER_DRIVER_CACHE", "").lower() in ("1", "true", "yes", "on")
