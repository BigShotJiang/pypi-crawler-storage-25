from __future__ import annotations

from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Any, NamedTuple


class ConfigScope(StrEnum):
    GLOBAL = "global"
    GUILD = "guild"
    CHANNEL = "channel"
    USER = "user"
    MEMBER = "member"
    ROLE = "role"
    CUSTOM = "custom"


class ScopeKey(NamedTuple):
    """Typed address for a single scope instance in the config store.

    Replaces the 5-positional-arg convention so callers can build and pass
    scope addresses as a single value:

        key = ScopeKey("birthday", 12345, ConfigScope.GUILD, str(guild_id))
        data = await driver.get_all(*key, "")
        # or unpack directly into store helpers
    """

    cog_name: str
    identifier: int
    scope: ConfigScope
    scope_id_1: str = ""
    scope_id_2: str = ""


class BaseDriver(ABC):
    """Abstract base for all Ember config + data storage backends.

    All drivers must implement the key-value config methods (get/set/delete etc.).
    SQL-capable drivers (SQLite, Postgres) also implement execute_sql / fetch_sql.
    All drivers should implement the driver-agnostic table helpers
    (store_record, get_record, get_records, delete_records, count_records).
    """

    @abstractmethod
    async def initialize(self) -> None:
        """Create schema / open connections. Called once at startup."""

    @abstractmethod
    async def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> Any:
        """Return the stored value or None if not set."""

    @abstractmethod
    async def set(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
        value: Any,
    ) -> None:
        """Persist a value."""

    @abstractmethod
    async def delete(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> None:
        """Delete a single key."""

    @abstractmethod
    async def get_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> dict[str, Any]:
        """Return all key-value pairs for a given scope instance."""

    @abstractmethod
    async def set_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        data: dict[str, Any],
    ) -> None:
        """Atomically write multiple key-value pairs."""

    @abstractmethod
    async def clear_scope(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
    ) -> None:
        """Delete all keys for a scope instance."""

    @abstractmethod
    async def get_all_scope_ids(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
    ) -> list[tuple[str, str]]:
        """Return all (scope_id_1, scope_id_2) pairs that have data."""

    @abstractmethod
    async def clear_cog(self, cog_name: str, identifier: int) -> None:
        """Delete ALL config data for a cog."""

    @abstractmethod
    async def export(self) -> dict[str, Any]:
        """Export all data as a portable dict (for backup / migration)."""

    @abstractmethod
    async def import_data(self, data: dict[str, Any]) -> None:
        """Import data produced by export()."""

    async def execute_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> int:
        """Execute a raw SQL statement in the per-cog DB. Returns rowcount.

        Override in SQL-capable drivers. Default raises NotImplementedError.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support raw SQL. "
            "Use the driver-agnostic table helpers instead."
        )

    async def fetch_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> list[dict[str, Any]]:
        """Execute a raw SQL SELECT in the per-cog DB. Returns list of dicts.

        Override in SQL-capable drivers. Default raises NotImplementedError.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support raw SQL. "
            "Use the driver-agnostic table helpers instead."
        )

    async def store_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        data: dict[str, Any],
        *,
        pk_columns: list[str] | None = None,
    ) -> None:
        """Upsert a record into *table*.

        SQL backends: ``INSERT OR REPLACE`` (SQLite) or ``ON CONFLICT DO UPDATE`` (Postgres).
        *pk_columns* names the primary-key columns driving conflict detection; defaults to the
        first column when not provided.
        Default raises NotImplementedError.
        """
        raise NotImplementedError(f"{type(self).__name__} has not implemented store_record.")

    async def get_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> dict[str, Any] | None:
        """Return the first record matching *where*, or None."""
        raise NotImplementedError(f"{type(self).__name__} has not implemented get_record.")

    async def get_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
        order_by: str,
    ) -> list[dict[str, Any]]:
        """Return all records matching *where*."""
        raise NotImplementedError(f"{type(self).__name__} has not implemented get_records.")

    async def delete_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        """Delete matching records. Returns count deleted."""
        raise NotImplementedError(f"{type(self).__name__} has not implemented delete_records.")

    async def count_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
    ) -> int:
        """Return the count of matching records."""
        raise NotImplementedError(f"{type(self).__name__} has not implemented count_records.")
