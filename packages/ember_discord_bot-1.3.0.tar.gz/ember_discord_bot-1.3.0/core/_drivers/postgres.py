from __future__ import annotations

import json
import logging
import re
from typing import Any

from .base import BaseDriver, ConfigScope

_SAFE_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _check_ident(name: str) -> str:
    if not _SAFE_IDENT.match(name):
        raise ValueError(f"Unsafe SQL identifier: {name!r}")
    return name


def _rewrite_placeholders(where: str) -> str:
    """Convert ? placeholders to $n for asyncpg."""
    n = 0
    result = []
    for ch in where:
        if ch == "?":
            n += 1
            result.append(f"${n}")
        else:
            result.append(ch)
    return "".join(result)


try:
    import asyncpg

    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False

logger = logging.getLogger("ember.config.postgres")


class PostgresDriver(BaseDriver):
    """AsyncPG-backed config storage."""

    def __init__(self, dsn: str = "postgresql://localhost/ember"):
        if not ASYNCPG_AVAILABLE:
            raise ImportError(
                "asyncpg is required for PostgreSQL driver. Install with: pip install asyncpg"
            )
        self._dsn = dsn
        self._pool: asyncpg.pool.Pool | None = None

    async def initialize(self) -> None:
        self._pool = await asyncpg.create_pool(dsn=self._dsn)
        async with self._pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS config_values (
                    cog_name    TEXT    NOT NULL,
                    identifier  BIGINT  NOT NULL,
                    scope       TEXT    NOT NULL,
                    scope_id_1  TEXT    NOT NULL DEFAULT '',
                    scope_id_2  TEXT    NOT NULL DEFAULT '',
                    key         TEXT    NOT NULL,
                    value       TEXT,
                    PRIMARY KEY (cog_name, identifier, scope, scope_id_1, scope_id_2, key)
                );
                CREATE INDEX IF NOT EXISTS idx_config_scope
                    ON config_values (cog_name, identifier, scope, scope_id_1);
                """)
        logger.debug("PostgreSQL driver initialized")

    async def _conn(self) -> asyncpg.Connection:
        assert self._pool is not None, "PostgresDriver not initialized"
        return await self._pool.acquire()

    async def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> Any:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT value FROM config_values WHERE cog_name=$1 AND identifier=$2 AND scope=$3 AND scope_id_1=$4 AND scope_id_2=$5 AND key=$6",
                cog_name,
                identifier,
                scope.value,
                scope_id_1,
                scope_id_2,
                key,
            )
            if row is None:
                return None
            val = row["value"]
            return json.loads(val) if val is not None else None

    async def set(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
        value: Any,
    ) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO config_values (cog_name, identifier, scope, scope_id_1, scope_id_2, key, value)
                VALUES ($1,$2,$3,$4,$5,$6,$7)
                ON CONFLICT (cog_name, identifier, scope, scope_id_1, scope_id_2, key)
                DO UPDATE SET value = EXCLUDED.value""",
                cog_name,
                identifier,
                scope.value,
                scope_id_1,
                scope_id_2,
                key,
                json.dumps(value, ensure_ascii=False),
            )

    async def delete(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        key: str,
    ) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM config_values WHERE cog_name=$1 AND identifier=$2 AND scope=$3 AND scope_id_1=$4 AND scope_id_2=$5 AND key=$6",
                cog_name,
                identifier,
                scope.value,
                scope_id_1,
                scope_id_2,
                key,
            )

    async def get_all(
        self, cog_name: str, identifier: int, scope: ConfigScope, scope_id_1: str, scope_id_2: str
    ) -> dict[str, Any]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT key, value FROM config_values WHERE cog_name=$1 AND identifier=$2 AND scope=$3 AND scope_id_1=$4 AND scope_id_2=$5",
                cog_name,
                identifier,
                scope.value,
                scope_id_1,
                scope_id_2,
            )
            result = {}
            for r in rows:
                val = r["value"]
                result[r["key"]] = json.loads(val) if val is not None else None
            return result

    async def set_all(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_1: str,
        scope_id_2: str,
        data: dict[str, Any],
    ) -> None:
        if not data:
            return
        async with self._pool.acquire() as conn:
            values = [
                (
                    cog_name,
                    identifier,
                    scope.value,
                    scope_id_1,
                    scope_id_2,
                    k,
                    json.dumps(v, ensure_ascii=False),
                )
                for k, v in data.items()
            ]
            await conn.executemany(
                """INSERT INTO config_values (cog_name, identifier, scope, scope_id_1, scope_id_2, key, value)
                VALUES ($1,$2,$3,$4,$5,$6,$7)
                ON CONFLICT (cog_name, identifier, scope, scope_id_1, scope_id_2, key)
                DO UPDATE SET value = EXCLUDED.value""",
                values,
            )

    async def clear_scope(
        self, cog_name: str, identifier: int, scope: ConfigScope, scope_id_1: str, scope_id_2: str
    ) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM config_values WHERE cog_name=$1 AND identifier=$2 AND scope=$3 AND scope_id_1=$4 AND scope_id_2=$5",
                cog_name,
                identifier,
                scope.value,
                scope_id_1,
                scope_id_2,
            )

    async def get_all_scope_ids(
        self, cog_name: str, identifier: int, scope: ConfigScope
    ) -> list[tuple[str, str]]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT DISTINCT scope_id_1, scope_id_2 FROM config_values WHERE cog_name=$1 AND identifier=$2 AND scope=$3",
                cog_name,
                identifier,
                scope.value,
            )
            return [(r["scope_id_1"], r["scope_id_2"]) for r in rows]

    async def clear_cog(self, cog_name: str, identifier: int) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM config_values WHERE cog_name=$1 AND identifier=$2",
                cog_name,
                identifier,
            )

    async def export(self) -> dict[str, Any]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT cog_name, identifier, scope, scope_id_1, scope_id_2, key, value FROM config_values"
            )
            data = []
            for r in rows:
                data.append(
                    {
                        "cog_name": r["cog_name"],
                        "identifier": r["identifier"],
                        "scope": r["scope"],
                        "scope_id_1": r["scope_id_1"],
                        "scope_id_2": r["scope_id_2"],
                        "key": r["key"],
                        "value": json.loads(r["value"]) if r["value"] is not None else None,
                    }
                )
            return {"driver": "postgres", "data": data}

    async def import_data(self, data: dict[str, Any]) -> None:
        async with self._pool.acquire() as conn:
            for item in data.get("data", []):
                await conn.execute(
                    """INSERT INTO config_values (cog_name, identifier, scope, scope_id_1, scope_id_2, key, value)
                    VALUES ($1,$2,$3,$4,$5,$6,$7)
                    ON CONFLICT (cog_name, identifier, scope, scope_id_1, scope_id_2, key)
                    DO UPDATE SET value = EXCLUDED.value""",
                    item["cog_name"],
                    item["identifier"],
                    item["scope"],
                    item["scope_id_1"],
                    item["scope_id_2"],
                    item["key"],
                    json.dumps(item["value"], ensure_ascii=False),
                )

    async def _ensure_cog_schema(self, conn: asyncpg.Connection, cog_name: str) -> None:
        """Ensure a per-cog schema exists (namespacing via Postgres schemas)."""
        safe = cog_name.replace("-", "_").replace(".", "_")
        await conn.execute(f"CREATE SCHEMA IF NOT EXISTS cog_{safe}")

    async def execute_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> int:
        safe = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe}"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            # Set search path for this connection so table names resolve correctly
            await conn.execute(f"SET search_path TO {schema}, public")
            result = await conn.execute(sql, *params)
            # asyncpg returns a command tag like "UPDATE 3"
            try:
                return int(result.split()[-1])
            except (ValueError, IndexError):
                return 0

    async def fetch_sql(
        self, cog_name: str, sql: str, params: tuple[Any, ...], identifier: int = 0
    ) -> list[dict[str, Any]]:
        safe = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe}"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            await conn.execute(f"SET search_path TO {schema}, public")
            rows = await conn.fetch(sql, *params)
            return [dict(r) for r in rows]

    async def store_record(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        data: dict[str, Any],
        *,
        pk_columns: list[str] | None = None,
    ) -> None:
        if not data:
            return
        safe_cog = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe_cog}"
        cols = list(data.keys())
        safe_cols = [_check_ident(c) for c in cols]
        col_names = ", ".join(safe_cols)
        placeholders = ", ".join(f"${i+1}" for i in range(len(safe_cols)))

        conflict_keys = pk_columns if pk_columns else cols[:1]
        safe_conflict = [_check_ident(c) for c in conflict_keys]
        conflict_target = ", ".join(safe_conflict)
        non_pk = [c for c in safe_cols if c not in safe_conflict]
        do_clause = (
            f"DO UPDATE SET {', '.join(f'{c} = EXCLUDED.{c}' for c in non_pk)}"
            if non_pk
            else "DO NOTHING"
        )
        sql = (
            f"INSERT INTO {schema}.{table} ({col_names}) VALUES ({placeholders}) "
            f"ON CONFLICT ({conflict_target}) {do_clause}"
        )
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            await conn.execute(sql, *data.values())

    async def get_record(
        self, cog_name: str, identifier: int, table: str, where: str, params: tuple[Any, ...]
    ) -> dict[str, Any] | None:
        safe_cog = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe_cog}"
        pg_where = _rewrite_placeholders(where)
        clause = f" WHERE {pg_where}" if pg_where else ""
        sql = f"SELECT * FROM {schema}.{table}{clause} LIMIT 1"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            row = await conn.fetchrow(sql, *params)
            return dict(row) if row else None

    async def get_records(
        self,
        cog_name: str,
        identifier: int,
        table: str,
        where: str,
        params: tuple[Any, ...],
        order_by: str,
    ) -> list[dict[str, Any]]:
        safe_cog = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe_cog}"
        pg_where = _rewrite_placeholders(where)
        clause = f" WHERE {pg_where}" if pg_where else ""
        safe_order = _check_ident(order_by) if order_by else ""
        order = f" ORDER BY {safe_order}" if safe_order else ""
        sql = f"SELECT * FROM {schema}.{table}{clause}{order}"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            rows = await conn.fetch(sql, *params)
            return [dict(r) for r in rows]

    async def delete_records(
        self, cog_name: str, identifier: int, table: str, where: str, params: tuple[Any, ...]
    ) -> int:
        safe_cog = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe_cog}"
        pg_where = _rewrite_placeholders(where)
        clause = f" WHERE {pg_where}" if pg_where else ""
        sql = f"DELETE FROM {schema}.{table}{clause}"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            result = await conn.execute(sql, *params)
            try:
                return int(result.split()[-1])
            except (ValueError, IndexError):
                return 0

    async def count_records(
        self, cog_name: str, identifier: int, table: str, where: str, params: tuple[Any, ...]
    ) -> int:
        safe_cog = cog_name.replace("-", "_").replace(".", "_")
        schema = f"cog_{safe_cog}"
        pg_where = _rewrite_placeholders(where)
        clause = f" WHERE {pg_where}" if pg_where else ""
        sql = f"SELECT COUNT(*) FROM {schema}.{table}{clause}"
        async with self._pool.acquire() as conn:
            await self._ensure_cog_schema(conn, cog_name)
            row = await conn.fetchrow(sql, *params)
            return row[0] if row else 0
