from __future__ import annotations

import functools
import logging
import time
from collections.abc import Callable

import discord
from discord import app_commands

from core.errors import UserFeedbackError
from core.store import Store

log = logging.getLogger("ember.bank")

_MAX_BALANCE_DEFAULT = 2**63 - 1
_DEFAULT_BALANCE = 0
_DEFAULT_CURRENCY = "credits"

# ══════════════════════════════════════════════════════════════
# Errors
# ══════════════════════════════════════════════════════════════


class BankError(UserFeedbackError):
    """Base class for all bank errors — always shown directly to the user."""


class InsufficientFundsError(BankError):
    def __init__(self, user_id: int = 0, needed: int = 0, has: int = 0):
        self.user_id = user_id
        self.needed = needed
        self.has = has
        msg = (
            f"Insufficient funds. Need **{needed:,}**, have **{has:,}**."
            if needed
            else "Insufficient funds."
        )
        super().__init__(msg, title="Insufficient Funds")


class BalanceTooHighError(BankError):
    def __init__(self, max_bal: int = 0):
        self.max_balance = max_bal
        super().__init__(f"Balance cannot exceed **{max_bal:,}**.", title="Balance Too High")


class AccountNotFoundError(BankError):
    def __init__(self, user_id: int = 0):
        self.user_id = user_id
        super().__init__("Account not found.", title="Bank Error")


# ══════════════════════════════════════════════════════════════
# Database layer
# ══════════════════════════════════════════════════════════════


class _BankDB:
    def __init__(self, store: Store):
        self.store = store

    async def initialize(self) -> None:
        self.store.register_table("""
            CREATE TABLE IF NOT EXISTS accounts (
                guild_id   INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                balance    INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                PRIMARY KEY (guild_id, user_id)
            )
        """)
        self.store.register_table("""
            CREATE TABLE IF NOT EXISTS guild_bank (
                guild_id     INTEGER PRIMARY KEY,
                currency     TEXT    NOT NULL DEFAULT 'credits',
                max_balance  INTEGER NOT NULL DEFAULT 9223372036854775807,
                bank_name    TEXT    NOT NULL DEFAULT 'Guild Bank'
            )
        """)
        self.store.register_table(
            "CREATE INDEX IF NOT EXISTS idx_accounts_guild ON accounts(guild_id)"
        )
        self.store.register_table(
            "CREATE INDEX IF NOT EXISTS idx_accounts_bal   ON accounts(guild_id, balance DESC)"
        )
        await self.store.initialize()

    async def ensure_account(self, guild_id: int, user_id: int) -> None:
        existing = await self.store.find_one("accounts", guild_id=guild_id, user_id=user_id)
        if not existing:
            await self.store.store(
                "accounts",
                {
                    "guild_id": guild_id,
                    "user_id": user_id,
                    "balance": _DEFAULT_BALANCE,
                    "created_at": int(time.time()),
                },
            )

    async def get_balance(self, guild_id: int, user_id: int) -> int:
        row = await self.store.find_one("accounts", guild_id=guild_id, user_id=user_id)
        return row["balance"] if row else 0

    async def set_balance(self, guild_id: int, user_id: int, amount: int) -> None:
        existing = await self.store.find_one("accounts", guild_id=guild_id, user_id=user_id)
        created_at = existing.get("created_at", int(time.time())) if existing else int(time.time())
        await self.store.store(
            "accounts",
            {
                "guild_id": guild_id,
                "user_id": user_id,
                "balance": amount,
                "created_at": created_at,
            },
        )

    async def get_leaderboard(self, guild_id: int, limit: int = 10) -> list[dict]:
        all_accounts = await self.store.find("accounts", guild_id=guild_id)
        sorted_accounts = sorted(all_accounts, key=lambda x: x.get("balance", 0), reverse=True)
        return sorted_accounts[:limit]

    async def get_rank(self, guild_id: int, user_id: int) -> int:
        user_account = await self.store.find_one("accounts", guild_id=guild_id, user_id=user_id)
        if not user_account:
            return 0
        user_balance = user_account.get("balance", 0)
        all_accounts = await self.store.find("accounts", guild_id=guild_id)
        rank = 1
        for account in all_accounts:
            if account.get("balance", 0) > user_balance:
                rank += 1
        return rank

    async def wipe(self, guild_id: int) -> None:
        await self.store.remove("accounts", guild_id=guild_id)

    async def prune(self, guild_id: int, user_ids_to_keep: list[int]) -> int:
        all_accounts = await self.store.find("accounts", guild_id=guild_id)
        count = 0
        for account in all_accounts:
            if account["user_id"] not in user_ids_to_keep:
                await self.store.remove("accounts", guild_id=guild_id, user_id=account["user_id"])
                count += 1
        return count

    async def delete_user(self, user_id: int) -> None:
        await self.store.remove("accounts", user_id=user_id)

    async def get_guild_settings(self, guild_id: int) -> dict:
        row = await self.store.find_one("guild_bank", guild_id=guild_id)
        return row or {
            "currency": _DEFAULT_CURRENCY,
            "max_balance": _MAX_BALANCE_DEFAULT,
            "bank_name": "Guild Bank",
        }

    async def set_currency(self, guild_id: int, name: str) -> None:
        existing = await self.store.find_one("guild_bank", guild_id=guild_id)
        await self.store.store(
            "guild_bank",
            {
                "guild_id": guild_id,
                "currency": name,
                "max_balance": (
                    existing.get("max_balance", _MAX_BALANCE_DEFAULT)
                    if existing
                    else _MAX_BALANCE_DEFAULT
                ),
                "bank_name": existing.get("bank_name", "Guild Bank") if existing else "Guild Bank",
            },
        )

    async def set_max_balance(self, guild_id: int, amount: int) -> None:
        existing = await self.store.find_one("guild_bank", guild_id=guild_id)
        await self.store.store(
            "guild_bank",
            {
                "guild_id": guild_id,
                "currency": (
                    existing.get("currency", _DEFAULT_CURRENCY) if existing else _DEFAULT_CURRENCY
                ),
                "max_balance": amount,
                "bank_name": existing.get("bank_name", "Guild Bank") if existing else "Guild Bank",
            },
        )

    async def set_bank_name(self, guild_id: int, name: str) -> None:
        existing = await self.store.find_one("guild_bank", guild_id=guild_id)
        await self.store.store(
            "guild_bank",
            {
                "guild_id": guild_id,
                "currency": (
                    existing.get("currency", _DEFAULT_CURRENCY) if existing else _DEFAULT_CURRENCY
                ),
                "max_balance": (
                    existing.get("max_balance", _MAX_BALANCE_DEFAULT)
                    if existing
                    else _MAX_BALANCE_DEFAULT
                ),
                "bank_name": name,
            },
        )


_db: _BankDB | None = None


async def _get_db() -> _BankDB:
    global _db
    if _db is None:
        from core.store import Store

        store = Store.for_cog("bank")
        _db = _BankDB(store)
        await _db.initialize()
    return _db


# ══════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════


async def get_balance(user: discord.abc.User, guild: discord.Guild) -> int:
    """Return *user*'s balance in *guild* (0 if no account yet)."""
    db = await _get_db()
    return await db.get_balance(guild.id, user.id)


async def can_spend(user: discord.abc.User, guild: discord.Guild, amount: int) -> bool:
    """Return True if *user* can afford *amount*."""
    return await get_balance(user, guild) >= amount


async def deposit(user: discord.abc.User, guild: discord.Guild, amount: int) -> int:
    """Add *amount* to *user*'s balance.

    Raises BalanceTooHighError if the new balance would exceed the guild cap.
    Returns the new balance.
    """
    if amount <= 0:
        raise ValueError("Deposit amount must be positive.")
    db = await _get_db()
    await db.ensure_account(guild.id, user.id)
    current = await db.get_balance(guild.id, user.id)
    settings = await db.get_guild_settings(guild.id)
    new_bal = current + amount
    if new_bal > settings["max_balance"]:
        raise BalanceTooHighError(settings["max_balance"])
    await db.set_balance(guild.id, user.id, new_bal)
    return new_bal


async def withdraw(user: discord.abc.User, guild: discord.Guild, amount: int) -> int:
    """Deduct *amount* from *user*'s balance.

    Raises InsufficientFundsError if the user can't afford it.
    Returns the new balance.
    """
    if amount <= 0:
        raise ValueError("Withdrawal amount must be positive.")
    db = await _get_db()
    current = await db.get_balance(guild.id, user.id)
    if current < amount:
        raise InsufficientFundsError(user.id, needed=amount, has=current)
    new_bal = current - amount
    await db.set_balance(guild.id, user.id, new_bal)
    return new_bal


async def set_balance(user: discord.abc.User, guild: discord.Guild, amount: int) -> int:
    """Set *user*'s balance directly (owner/admin tool).

    Raises BalanceTooHighError if *amount* exceeds the guild cap.
    """
    if amount < 0:
        raise ValueError("Balance cannot be negative.")
    db = await _get_db()
    settings = await db.get_guild_settings(guild.id)
    if amount > settings["max_balance"]:
        raise BalanceTooHighError(settings["max_balance"])
    await db.ensure_account(guild.id, user.id)
    await db.set_balance(guild.id, user.id, amount)
    return amount


async def transfer(
    from_user: discord.abc.User,
    to_user: discord.abc.User,
    guild: discord.Guild,
    amount: int,
) -> tuple[int, int]:
    """Transfer *amount* from *from_user* to *to_user* atomically.

    Raises InsufficientFundsError or BalanceTooHighError on failure.
    Returns (from_new_balance, to_new_balance).
    """
    if amount <= 0:
        raise ValueError("Transfer amount must be positive.")
    # Check sender first
    db = await _get_db()
    sender_bal = await db.get_balance(guild.id, from_user.id)
    if sender_bal < amount:
        raise InsufficientFundsError(from_user.id, needed=amount, has=sender_bal)

    settings = await db.get_guild_settings(guild.id)
    await db.ensure_account(guild.id, to_user.id)
    recv_bal = await db.get_balance(guild.id, to_user.id)
    if recv_bal + amount > settings["max_balance"]:
        raise BalanceTooHighError(settings["max_balance"])

    new_sender = sender_bal - amount
    new_recv = recv_bal + amount
    await db.set_balance(guild.id, from_user.id, new_sender)
    await db.set_balance(guild.id, to_user.id, new_recv)
    return new_sender, new_recv


async def get_leaderboard(
    guild: discord.Guild,
    limit: int = 10,
) -> list[tuple[int, int]]:
    """Return top *limit* accounts as ``[(user_id, balance), ...]`` descending."""
    db = await _get_db()
    rows = await db.get_leaderboard(guild.id, limit)
    return [(r["user_id"], r["balance"]) for r in rows]


async def get_leaderboard_position(user: discord.abc.User, guild: discord.Guild) -> int:
    """Return *user*'s rank on the leaderboard (1-indexed, 0 if no account)."""
    db = await _get_db()
    return await db.get_rank(guild.id, user.id)


async def get_currency_name(guild: discord.Guild) -> str:
    db = await _get_db()
    return (await db.get_guild_settings(guild.id))["currency"]


async def set_currency_name(guild: discord.Guild, name: str) -> None:
    db = await _get_db()
    await db.set_currency(guild.id, name)


async def get_max_balance(guild: discord.Guild) -> int:
    db = await _get_db()
    return (await db.get_guild_settings(guild.id))["max_balance"]


async def set_max_balance(guild: discord.Guild, amount: int) -> None:
    if amount <= 0:
        raise ValueError("Max balance must be positive.")
    db = await _get_db()
    await db.set_max_balance(guild.id, amount)


async def get_bank_name(guild: discord.Guild) -> str:
    db = await _get_db()
    return (await db.get_guild_settings(guild.id))["bank_name"]


async def set_bank_name(guild: discord.Guild, name: str) -> None:
    db = await _get_db()
    await db.set_bank_name(guild.id, name)


async def wipe_bank(guild: discord.Guild) -> None:
    """Delete ALL accounts in *guild*."""
    db = await _get_db()
    await db.wipe(guild.id)


async def bank_prune(guild: discord.Guild) -> int:
    """Remove accounts for users no longer in *guild*. Returns count deleted."""
    db = await _get_db()
    member_ids = [m.id for m in guild.members]
    return await db.prune(guild.id, member_ids)


async def delete_data_for_user(user_id: int) -> None:
    """GDPR: remove all account data for *user_id* across all guilds."""
    db = await _get_db()
    await db.delete_user(user_id)
    log.info("Deleted bank data for user %d (GDPR)", user_id)


# ══════════════════════════════════════════════════════════════
# @cost decorator
# ══════════════════════════════════════════════════════════════


def cost(amount: int) -> Callable:
    """Decorator that charges *amount* credits before running a slash command.

    Deducts from the user's balance before the command body runs.
    Raises InsufficientFundsError (handled by cog_app_command_error) if
    the user can't afford it.

    Usage::

        @app_commands.command()
        @bank.cost(50)
        async def gamble(self, interaction: discord.Interaction):
            # User has already been charged 50 credits
            ...
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(self, interaction: discord.Interaction, *args, **kwargs):
            if not interaction.guild:
                raise app_commands.NoPrivateMessage()
            bal = await get_balance(interaction.user, interaction.guild)
            if bal < amount:
                raise InsufficientFundsError(interaction.user.id, needed=amount, has=bal)
            await withdraw(interaction.user, interaction.guild, amount)
            return await func(self, interaction, *args, **kwargs)

        return wrapper

    return decorator
