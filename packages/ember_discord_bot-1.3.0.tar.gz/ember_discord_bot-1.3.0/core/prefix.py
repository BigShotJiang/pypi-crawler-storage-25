from __future__ import annotations

import discord
from discord.ext import commands

from core._settings_caches import prefix_mgr


async def get_guild_prefixes(guild_id: int | None) -> list[str]:
    return await prefix_mgr.get(guild_id)


async def set_guild_prefix(guild_id: int, prefix: str) -> None:
    await prefix_mgr.set(guild_id, [prefix])


async def add_guild_prefix(guild_id: int, prefix: str) -> None:
    await prefix_mgr.add(guild_id, prefix)


async def remove_guild_prefix(guild_id: int, prefix: str) -> None:
    await prefix_mgr.remove(guild_id, prefix)


async def clear_guild_prefixes(guild_id: int) -> None:
    await prefix_mgr.clear(guild_id)


def invalidate_guild(guild_id: int) -> None:
    prefix_mgr.invalidate(guild_id)


def invalidate_all() -> None:
    prefix_mgr.invalidate_all()


async def get_prefix(bot: commands.Bot, message: discord.Message) -> list[str]:
    """Callable for commands.Bot(command_prefix=...)."""
    guild_id = message.guild.id if message.guild else None
    prefixes = await prefix_mgr.get(guild_id)
    return commands.when_mentioned_or(*prefixes)(bot, message)
