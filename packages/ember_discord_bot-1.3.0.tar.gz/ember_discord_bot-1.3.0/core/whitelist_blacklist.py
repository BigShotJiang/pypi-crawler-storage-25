from __future__ import annotations

from core._settings_caches import wb_mgr


async def initialize() -> None:
    await wb_mgr.initialize()


async def get_blacklist() -> set[int]:
    return await wb_mgr.get_blacklist()


async def add_to_blacklist(user_id: int) -> None:
    await wb_mgr.add_to_blacklist(user_id)


async def remove_from_blacklist(user_id: int) -> None:
    await wb_mgr.remove_from_blacklist(user_id)


async def get_whitelist() -> set[int]:
    return await wb_mgr.get_whitelist()


async def add_to_whitelist(user_id: int) -> None:
    await wb_mgr.add_to_whitelist(user_id)


async def remove_from_whitelist(user_id: int) -> None:
    await wb_mgr.remove_from_whitelist(user_id)


async def guild_blacklist_add(guild_id: int, user_id: int) -> None:
    await wb_mgr.guild_blacklist_add(guild_id, user_id)


async def guild_blacklist_remove(guild_id: int, user_id: int) -> None:
    await wb_mgr.guild_blacklist_remove(guild_id, user_id)


async def guild_whitelist_add(guild_id: int, user_id: int) -> None:
    await wb_mgr.guild_whitelist_add(guild_id, user_id)


async def guild_whitelist_remove(guild_id: int, user_id: int) -> None:
    await wb_mgr.guild_whitelist_remove(guild_id, user_id)


async def set_guild_whitelist_enabled(guild_id: int, enabled: bool) -> None:
    await wb_mgr.set_guild_whitelist_enabled(guild_id, enabled)


async def is_blocked(guild_id: int | None, user_id: int) -> bool:
    return await wb_mgr.is_blocked(guild_id, user_id)


def parse_user_id(s: str) -> int | None:
    """Parse a user ID from a raw ID string or a Discord mention (<@123> / <@!123>)."""
    s = s.strip()
    if s.startswith("<@") and s.endswith(">"):
        s = s[2:-1].lstrip("!")
    return int(s) if s.isdigit() else None


add_global_blacklist = add_to_blacklist
remove_global_blacklist = remove_from_blacklist
add_guild_blacklist = guild_blacklist_add
remove_guild_blacklist = guild_blacklist_remove
add_global_whitelist = add_to_whitelist
remove_global_whitelist = remove_from_whitelist
add_guild_whitelist = guild_whitelist_add
remove_guild_whitelist = guild_whitelist_remove
