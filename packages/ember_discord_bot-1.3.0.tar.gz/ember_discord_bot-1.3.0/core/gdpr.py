"""GDPR taxonomy and fan-out helpers.

Mirrors Red-DiscordBot's data API: a `RequesterType` describing *why* the
request happened, and helpers that walk every loaded cog plus the central
Store registry to either export or purge a user's data.

Cogs declare what they store by overriding ``EmberCog.delete_data_for_user``
(``user_id``, ``guild_id``) — the existing signature in this codebase. They
may optionally override ``red_get_data_for_user`` returning a dict.
"""

from __future__ import annotations

import logging
from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from core.bot import EmberBot

log = logging.getLogger("ember.gdpr")


class RequesterType(StrEnum):
    """Why a GDPR request was issued.

    - ``DISCORD_DELETED_USER``: Discord told us the account was deleted.
      Cogs must purge regardless of retention policy.
    - ``OWNER``: Bot owner initiated. Treated like USER_STRICT.
    - ``USER``: The user themselves asked. Cogs may keep records required
      by moderation/audit obligations.
    - ``USER_STRICT``: User asked and demanded full erasure. Purge unless a
      legal hold applies.
    """

    DISCORD_DELETED_USER = "discord_deleted_user"
    OWNER = "owner"
    USER = "user"
    USER_STRICT = "user_strict"


async def export_user_data(bot: EmberBot, user_id: int) -> dict[str, Any]:
    """Aggregate every cog's stored data for ``user_id`` into one dict.

    Walks the central Store registry (covers every cog using ``self.db``)
    and additionally calls ``red_get_data_for_user`` on cogs that opt in.
    """
    from core.store import _cog_name_registry

    export: dict[str, Any] = {}

    for cog_name, store in list(_cog_name_registry.items()):
        try:
            data = await store.get_all_for_user(user_id)
        except Exception as exc:
            log.warning("Store export failed for %s: %s", cog_name, exc)
            continue
        if data:
            export[cog_name] = {str(k): v for k, v in data.items()}

    for cog in list(bot.cogs.values()):
        getter = getattr(cog, "red_get_data_for_user", None)
        if not callable(getter):
            continue
        try:
            extra = await getter(user_id=user_id)
        except Exception as exc:
            log.warning("red_get_data_for_user failed for %s: %s", cog.qualified_name, exc)
            continue
        if extra:
            key = f"{cog.qualified_name.lower()}_extra"
            export[key] = extra

    return export


async def forget_user_data(
    bot: EmberBot,
    user_id: int,
    *,
    requester: RequesterType = RequesterType.OWNER,
    guild_id: int | None = None,
) -> dict[str, Any]:
    """Fan out a deletion request to every loaded cog plus core subsystems.

    Returns a per-cog summary dict suitable for showing the operator what
    was purged.
    """
    summary: dict[str, Any] = {"requester": requester.value, "user_id": user_id}
    cog_results: dict[str, Any] = {}

    for cog in list(bot.cogs.values()):
        deleter = getattr(cog, "delete_data_for_user", None)
        if not callable(deleter):
            continue
        try:
            result = await deleter(user_id=user_id, guild_id=guild_id)
        except TypeError:
            try:
                result = await deleter(user_id, guild_id)
            except Exception as exc:
                cog_results[cog.qualified_name] = {"error": str(exc)}
                continue
        except Exception as exc:
            cog_results[cog.qualified_name] = {"error": str(exc)}
            continue
        cog_results[cog.qualified_name] = result or {"ok": True}

    try:
        from core import bank as _bank

        await _bank.delete_data_for_user(user_id)
        cog_results["__bank__"] = {"ok": True}
    except Exception as exc:
        cog_results["__bank__"] = {"error": str(exc)}

    try:
        from core import modlog as _modlog

        await _modlog.delete_data_for_user(user_id)
        cog_results["__modlog__"] = {"ok": True}
    except Exception as exc:
        cog_results["__modlog__"] = {"error": str(exc)}

    summary["cogs"] = cog_results
    log.info(
        "GDPR forget by %s for user %d touched %d cogs", requester.value, user_id, len(cog_results)
    )
    return summary
