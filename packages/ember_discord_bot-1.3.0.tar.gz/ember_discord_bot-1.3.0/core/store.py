from __future__ import annotations

import asyncio
import logging
import pickle
import re
import weakref
from collections import OrderedDict
from typing import Any

import discord

from core._drivers import BaseDriver, ConfigScope, get_driver

logger = logging.getLogger("ember.store")
_SAFE_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

_store_cache: weakref.WeakValueDictionary[tuple[str, int], Store] = weakref.WeakValueDictionary()
_cog_name_registry: dict[str, Store] = {}


def get_cog_store(cog_name: str) -> Store | None:
    return _cog_name_registry.get(cog_name)


_ScopeKey = tuple[str, int, str, str, str]


class _ReadCache:

    def __init__(self, maxsize: int = 2000) -> None:
        self._data: OrderedDict[_ScopeKey, dict[str, Any]] = OrderedDict()
        self._maxsize = maxsize

    def _key(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_primary: str,
        scope_id_secondary: str,
    ) -> _ScopeKey:
        return (cog_name, identifier, scope.value, scope_id_primary, scope_id_secondary)

    def get(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_primary: str,
        scope_id_secondary: str,
    ) -> dict[str, Any] | None:
        cache_key = self._key(cog_name, identifier, scope, scope_id_primary, scope_id_secondary)
        if cache_key not in self._data:
            return None
        self._data.move_to_end(cache_key)
        return dict(self._data[cache_key])

    def put(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_primary: str,
        scope_id_secondary: str,
        data: dict[str, Any],
    ) -> None:
        cache_key = self._key(cog_name, identifier, scope, scope_id_primary, scope_id_secondary)
        self._data[cache_key] = dict(data)
        self._data.move_to_end(cache_key)
        if len(self._data) > self._maxsize:
            self._data.popitem(last=False)

    def invalidate(
        self,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_primary: str,
        scope_id_secondary: str,
    ) -> None:
        self._data.pop(
            self._key(cog_name, identifier, scope, scope_id_primary, scope_id_secondary), None
        )

    def invalidate_cog(self, cog_name: str, identifier: int) -> None:
        stale_keys = [key for key in self._data if key[0] == cog_name and key[1] == identifier]
        for stale_key in stale_keys:
            del self._data[stale_key]

    def clear(self) -> None:
        self._data.clear()


_SCOPE_MAP: dict[str, ConfigScope] = {
    "global": ConfigScope.GLOBAL,
    "guild": ConfigScope.GUILD,
    "channel": ConfigScope.CHANNEL,
    "user": ConfigScope.USER,
    "member": ConfigScope.MEMBER,
    "role": ConfigScope.ROLE,
    "custom": ConfigScope.CUSTOM,
}


def _scope(name: str) -> ConfigScope:
    try:
        return _SCOPE_MAP[name.lower()]
    except KeyError:
        raise ValueError(f"Unknown scope {name!r}. Valid scopes: {list(_SCOPE_MAP)}") from None


def _ids_from(scope_id: Any) -> tuple[str, str]:
    if isinstance(scope_id, tuple):
        primary_id, secondary_id = scope_id
        return str(primary_id), str(secondary_id)
    if hasattr(scope_id, "id"):
        return str(scope_id.id), ""
    return str(scope_id), ""


class _TransactionContext:
    def __init__(
        self,
        driver: BaseDriver,
        cog_name: str,
        identifier: int,
        scope: ConfigScope,
        scope_id_primary: str,
        scope_id_secondary: str,
        defaults: dict[str, Any],
        lock: asyncio.Lock,
        cache: _ReadCache,
    ) -> None:
        self._driver = driver
        self._cog_name = cog_name
        self._identifier = identifier
        self._scope = scope
        self._scope_id_primary = scope_id_primary
        self._scope_id_secondary = scope_id_secondary
        self._defaults = defaults
        self._lock = lock
        self._cache = cache
        self._data: dict[str, Any] | None = None
        self._original: dict[str, Any] | None = None

    async def __aenter__(self) -> dict[str, Any]:
        await self._lock.acquire()
        try:
            stored_data = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                self._scope,
                self._scope_id_primary,
                self._scope_id_secondary,
            )
            self._data = {**self._defaults, **stored_data}
            self._original = pickle.loads(pickle.dumps(self._data, -1))
            return self._data
        except Exception:
            self._lock.release()
            raise

    async def __aexit__(self, exc_type: type | None, exc: BaseException | None, tb: Any) -> None:
        try:
            if exc_type is None and self._data != self._original:
                await self._driver.set_all(
                    self._cog_name,
                    self._identifier,
                    self._scope,
                    self._scope_id_primary,
                    self._scope_id_secondary,
                    self._data,
                )
                self._cache.invalidate(
                    self._cog_name,
                    self._identifier,
                    self._scope,
                    self._scope_id_primary,
                    self._scope_id_secondary,
                )
        finally:
            self._lock.release()


class ScopedConfig:
    __slots__ = ("_store", "_scope", "_id")

    def __init__(self, store: Store, scope: str, scope_id: Any) -> None:
        self._store = store
        self._scope = scope
        self._id = scope_id

    async def get(self, key: str | None = None, *, default: Any = None) -> Any:
        return await self._store.get(self._scope, self._id, key, default=default)

    async def __call__(self, key: str, *, default: Any = None) -> Any:
        return await self._store.get(self._scope, self._id, key, default=default)

    async def all(self) -> dict[str, Any]:
        return await self._store.get_all(self._scope, self._id)

    async def is_enabled(self) -> bool:
        return bool(await self.get("enabled", default=True))

    async def set(self, key: str, value: Any) -> None:
        await self._store.set(self._scope, self._id, key, value)

    async def update(self, **kv: Any) -> None:
        await self._store.set_many(self._scope, self._id, kv)

    async def delete(self, key: str | None = None) -> None:
        await self._store.delete(self._scope, self._id, key)

    def transaction(self) -> _TransactionContext:
        return self._store.transaction(self._scope, self._id)


class Store:
    def __init__(
        self,
        cog_name: str,
        identifier: int,
        driver: BaseDriver,
    ) -> None:
        self._cog_name = cog_name
        self._identifier = str(identifier)
        self._driver = driver
        self._defaults: dict[ConfigScope, dict[str, Any]] = {s: {} for s in ConfigScope}
        self._schemas: dict[str, Any] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._ddl_statements: list[str] = []
        self._cache = _ReadCache()

    @staticmethod
    def _generate_identifier(cog_name: str) -> int:
        return int(cog_name.encode("utf-8").hex(), 16)

    @classmethod
    def for_cog(
        cls,
        cog: Any,
        identifier: int | None = None,
    ) -> Store:
        cog_name = cog if isinstance(cog, str) else type(cog).__name__
        if identifier is None:
            identifier = cls._generate_identifier(cog_name)
        key = (cog_name, identifier)
        try:
            inst = _store_cache[key]
        except KeyError:
            inst = cls(cog_name, identifier, get_driver())
            _store_cache[key] = inst
        _cog_name_registry[cog_name] = inst
        return inst

    def defaults(
        self,
        scope_or_map: str | dict[str, dict[str, Any]],
        **kwargs: Any,
    ) -> Store:
        if isinstance(scope_or_map, dict):
            for scope_name, fields in scope_or_map.items():
                self._defaults[_scope(scope_name)].update(fields)
        else:
            self._defaults[_scope(scope_or_map)].update(kwargs)
        return self

    def register_schema(self, scope: str, schema_class: Any) -> Store:
        self._schemas[scope] = schema_class
        return self

    def register_table(self, sql: str) -> None:
        self._ddl_statements.append(sql)

    def register_index(self, table: str, columns: list[str] | str, *, name: str = "") -> None:
        if isinstance(columns, str):
            columns = [columns]
        if not name:
            name = f"idx_{table}_{'_'.join(columns)}"
        col_str = ", ".join(columns)
        self.register_table(f"CREATE INDEX IF NOT EXISTS {name} ON {table}({col_str})")

    async def initialize(self) -> None:
        for sql in self._ddl_statements:
            try:
                await self._driver.execute_sql(self._cog_name, sql, (), int(self._identifier))
            except NotImplementedError:
                logger.debug(
                    "Driver %s skipping DDL for %s (no SQL support)",
                    type(self._driver).__name__,
                    self._cog_name,
                )
                break
            except Exception as exc:
                logger.error("DDL failed for %s: %s", self._cog_name, exc)

    def _lock_for(
        self, scope: ConfigScope, scope_id_primary: str, scope_id_secondary: str
    ) -> asyncio.Lock:
        lock_key = f"{scope.value}:{scope_id_primary}:{scope_id_secondary}"
        if lock_key not in self._locks:
            self._locks[lock_key] = asyncio.Lock()
        return self._locks[lock_key]

    def _defaults_for(self, scope: ConfigScope) -> dict[str, Any]:
        return dict(self._defaults[scope])

    async def get(
        self, scope: str, scope_id: Any, key: str | None = None, *, default: Any = None
    ) -> Any:
        parsed_scope = _scope(scope)
        scope_id_primary, scope_id_secondary = (
            _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
        )
        scope_defaults = self._defaults_for(parsed_scope)

        cached_data = self._cache.get(
            self._cog_name, self._identifier, parsed_scope, scope_id_primary, scope_id_secondary
        )
        if cached_data is None:
            stored_data = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
            )
            cached_data = {**scope_defaults, **stored_data}
            self._cache.put(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
                cached_data,
            )

        if key is None:
            return dict(cached_data)
        if key in cached_data:
            return cached_data[key]
        return scope_defaults.get(key, default)

    async def set(self, scope: str, scope_id: Any, key: str, value: Any) -> None:
        parsed_scope = _scope(scope)
        scope_id_primary, scope_id_secondary = (
            _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
        )
        await self._driver.set(
            self._cog_name,
            self._identifier,
            parsed_scope,
            scope_id_primary,
            scope_id_secondary,
            key,
            value,
        )
        self._cache.invalidate(
            self._cog_name, self._identifier, parsed_scope, scope_id_primary, scope_id_secondary
        )

    async def delete(self, scope: str, scope_id: Any, key: str | None = None) -> None:
        parsed_scope = _scope(scope)
        scope_id_primary, scope_id_secondary = (
            _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
        )
        if key is None:
            await self._driver.clear_scope(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
            )
        else:
            await self._driver.delete(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
                key,
            )
        self._cache.invalidate(
            self._cog_name, self._identifier, parsed_scope, scope_id_primary, scope_id_secondary
        )

    async def get_all(self, scope: str, scope_id: Any) -> dict[str, Any]:
        return await self.get(scope, scope_id)

    async def set_many(self, scope: str, scope_id: Any, data: dict[str, Any]) -> None:
        parsed_scope = _scope(scope)
        scope_id_primary, scope_id_secondary = (
            _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
        )
        async with self._lock_for(parsed_scope, scope_id_primary, scope_id_secondary):
            await self._driver.set_all(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
                data,
            )
            self._cache.invalidate(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
            )

    def transaction(self, scope: str, scope_id: Any) -> _TransactionContext:
        parsed_scope = _scope(scope)
        scope_id_primary, scope_id_secondary = (
            _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
        )
        return _TransactionContext(
            self._driver,
            self._cog_name,
            self._identifier,
            parsed_scope,
            scope_id_primary,
            scope_id_secondary,
            self._defaults_for(parsed_scope),
            self._lock_for(parsed_scope, scope_id_primary, scope_id_secondary),
            self._cache,
        )

    def guild(self, guild: discord.Guild | int) -> ScopedConfig:
        guild_id = guild.id if isinstance(guild, discord.Guild) else int(guild)
        return ScopedConfig(self, "guild", guild_id)

    def user(self, user: discord.User | discord.Member | int) -> ScopedConfig:
        user_id = user.id if hasattr(user, "id") else int(user)
        return ScopedConfig(self, "user", user_id)

    def member(
        self, guild: discord.Guild | int, user: discord.Member | discord.User | int
    ) -> ScopedConfig:
        gid = guild.id if isinstance(guild, discord.Guild) else int(guild)
        uid = user.id if hasattr(user, "id") else int(user)
        return ScopedConfig(self, "member", (gid, uid))

    def channel(self, channel: discord.abc.GuildChannel | int) -> ScopedConfig:
        channel_id = channel.id if hasattr(channel, "id") else int(channel)
        return ScopedConfig(self, "channel", channel_id)

    def role(self, role: discord.Role | int) -> ScopedConfig:
        role_id = role.id if isinstance(role, discord.Role) else int(role)
        return ScopedConfig(self, "role", role_id)

    @property
    def globals(self) -> ScopedConfig:
        return ScopedConfig(self, "global", 0)

    async def all_guilds(self) -> dict[int, dict[str, Any]]:
        guild_scope_ids = await self._driver.get_all_scope_ids(
            self._cog_name,
            self._identifier,
            ConfigScope.GUILD,
        )
        guild_defaults = self._defaults_for(ConfigScope.GUILD)
        result: dict[int, dict[str, Any]] = {}
        for guild_id, _ in guild_scope_ids:
            stored_config = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                ConfigScope.GUILD,
                guild_id,
                "",
            )
            result[int(guild_id)] = {**guild_defaults, **stored_config}
        return result

    async def all_users(self) -> dict[int, dict[str, Any]]:
        user_scope_ids = await self._driver.get_all_scope_ids(
            self._cog_name,
            self._identifier,
            ConfigScope.USER,
        )
        user_defaults = self._defaults_for(ConfigScope.USER)
        result: dict[int, dict[str, Any]] = {}
        for user_id, _ in user_scope_ids:
            stored_config = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                ConfigScope.USER,
                user_id,
                "",
            )
            result[int(user_id)] = {**user_defaults, **stored_config}
        return result

    async def all_members(
        self, guild: discord.Guild | int | None = None
    ) -> dict[int, dict[int, dict[str, Any]]]:
        member_scope_ids = await self._driver.get_all_scope_ids(
            self._cog_name,
            self._identifier,
            ConfigScope.MEMBER,
        )
        if guild is not None:
            guild_id_str = str(guild.id if isinstance(guild, discord.Guild) else guild)
            member_scope_ids = [
                (guild_id, user_id)
                for guild_id, user_id in member_scope_ids
                if guild_id == guild_id_str
            ]
        member_defaults = self._defaults_for(ConfigScope.MEMBER)
        result: dict[int, dict[int, dict[str, Any]]] = {}
        for guild_id, user_id in member_scope_ids:
            stored_config = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                ConfigScope.MEMBER,
                guild_id,
                user_id,
            )
            result.setdefault(int(guild_id), {})[int(user_id)] = {
                **member_defaults,
                **stored_config,
            }
        return result

    async def clear_all(self) -> None:
        await self._driver.clear_cog(self._cog_name, self._identifier)
        self._cache.invalidate_cog(self._cog_name, self._identifier)
        logger.warning("Cleared ALL store data for %s", self._cog_name)

    async def get_all_for_user(self, user_id: int) -> dict[tuple[str, Any], dict[str, Any]]:
        result: dict[tuple[str, Any], dict[str, Any]] = {}
        target_user_id_str = str(user_id)

        user_scope_ids = await self._driver.get_all_scope_ids(
            self._cog_name,
            self._identifier,
            ConfigScope.USER,
        )
        for scope_user_id, _ in user_scope_ids:
            if scope_user_id == target_user_id_str:
                user_config = await self._driver.get_all(
                    self._cog_name,
                    self._identifier,
                    ConfigScope.USER,
                    scope_user_id,
                    "",
                )
                if user_config:
                    result[("user", int(scope_user_id))] = user_config

        member_scope_ids = await self._driver.get_all_scope_ids(
            self._cog_name,
            self._identifier,
            ConfigScope.MEMBER,
        )
        for member_guild_id, member_user_id in member_scope_ids:
            if member_user_id == target_user_id_str:
                member_config = await self._driver.get_all(
                    self._cog_name,
                    self._identifier,
                    ConfigScope.MEMBER,
                    member_guild_id,
                    member_user_id,
                )
                if member_config:
                    result[("member", (int(member_guild_id), int(member_user_id)))] = member_config

        return result

    async def store(
        self, collection: str, data: dict[str, Any], *, pk_columns: list[str] | None = None
    ) -> None:
        await self._driver.store_record(
            self._cog_name, self._identifier, collection, data, pk_columns=pk_columns
        )

    async def find(
        self, collection: str, /, *, order_by: str = "", **filters: Any
    ) -> list[dict[str, Any]]:
        where, params = _build_where(filters)
        return await self._driver.get_records(
            self._cog_name, self._identifier, collection, where, params, order_by
        )

    async def find_one(self, collection: str, /, **filters: Any) -> dict[str, Any] | None:
        where, params = _build_where(filters)
        return await self._driver.get_record(
            self._cog_name, self._identifier, collection, where, params
        )

    async def remove(self, collection: str, /, **filters: Any) -> int:
        where, params = _build_where(filters)
        return await self._driver.delete_records(
            self._cog_name, self._identifier, collection, where, params
        )

    async def count(self, collection: str, /, **filters: Any) -> int:
        where, params = _build_where(filters)
        return await self._driver.count_records(
            self._cog_name, self._identifier, collection, where, params
        )

    async def update_one(self, collection: str, data: dict[str, Any], /, **filters: Any) -> bool:
        if not filters:
            raise ValueError("update_one requires at least one filter to identify the record")
        row = await self.find_one(collection, **filters)
        if row is None:
            return False
        await self.store(collection, {**row, **data}, pk_columns=list(filters.keys()))
        return True

    async def get_cascading(
        self, key: str, *scope_pairs: tuple[str, Any], default: Any = None
    ) -> Any:
        # bypasses defaults — only stored values count as "set"
        for scope_name, scope_id in scope_pairs:
            parsed_scope = _scope(scope_name)
            scope_id_primary, scope_id_secondary = (
                _ids_from(scope_id) if parsed_scope != ConfigScope.GLOBAL else ("", "")
            )
            stored = await self._driver.get_all(
                self._cog_name,
                self._identifier,
                parsed_scope,
                scope_id_primary,
                scope_id_secondary,
            )
            if key in stored:
                return stored[key]
        return default

    async def execute(self, sql: str, params: tuple[Any, ...] = ()) -> int:
        return await self._driver.execute_sql(self._cog_name, sql, params, int(self._identifier))

    async def query(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        return await self._driver.fetch_sql(self._cog_name, sql, params, int(self._identifier))


def _build_where(filters: dict[str, Any]) -> tuple[str, tuple[Any, ...]]:
    if not filters:
        return "", ()
    for col in filters:
        if not _SAFE_IDENT.match(col):
            raise ValueError(f"Unsafe column name in filter: {col!r}")
    where_clauses = [f"{col} = ?" for col in filters]
    return " AND ".join(where_clauses), tuple(filters.values())
