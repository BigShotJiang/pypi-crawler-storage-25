from __future__ import annotations

import functools
import logging
from collections.abc import Callable
from typing import Any

import discord
from discord import app_commands

from core.errors import InsufficientPermissionsError
from core.permissions_engine import PermissionLevel, PermissionRegistry, Requires
from core.store import Store

logger = logging.getLogger("ember.permissions")


# ═══════════════════════════════════════════════════════════════════════════
# Global config for role IDs (shared with settings cog)
# ═══════════════════════════════════════════════════════════════════════════

_config = Store.for_cog("permissions", 0x7065726D73)
_config.defaults({"guild": {"mod_role_id": None, "admin_role_id": None}})


# ═══════════════════════════════════════════════════════════════════════════
# Decorator
# ═══════════════════════════════════════════════════════════════════════════


def requires(level: PermissionLevel) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that enforces a minimum privilege level before a command runs.

    Attaches metadata AND wraps the function with an inline permission check so
    that callers without sufficient privilege get InsufficientPermissionsError.
    Bot owners always pass regardless of the required level.

    Example::

        @app_commands.command()
        @requires(PermissionLevel.MOD)
        async def ban(self, interaction, member: discord.Member):
            await self.send_success(interaction, f"Banned {member}")
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        async def wrapper(
            self_or_cog: Any, context_or_interaction: Any, *args: Any, **kwargs: Any
        ) -> Any:
            ctx = context_or_interaction
            guild = getattr(ctx, "guild", None)
            user = getattr(ctx, "user", None) or getattr(ctx, "author", None)

            if guild is None and level > PermissionLevel.USER:
                raise InsufficientPermissionsError(
                    f"This command can only be used in a server (requires {level.name})."
                )

            if user is not None and guild is not None:
                bot = getattr(self_or_cog, "bot", None)
                if bot and await bot.is_owner(user):
                    return await func(self_or_cog, ctx, *args, **kwargs)

                if hasattr(self_or_cog, "_get_user_permission_level"):
                    user_level = await self_or_cog._get_user_permission_level(user, guild)
                else:
                    user_level = await _get_user_permission_level(user, guild, bot)

                if user_level < level:
                    raise InsufficientPermissionsError(
                        f"Requires {level.name} access (you have {user_level.name})."
                    )

            return await func(self_or_cog, ctx, *args, **kwargs)

        wrapper.__requires_level__ = level
        return wrapper

    return decorator


# ═══════════════════════════════════════════════════════════════════════════
# Permission level calculation (used by engine and PermissionsMixin)
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# EmberCog Mixin - auto-registers commands
# ═══════════════════════════════════════════════════════════════════════════


class PermissionsMixin:
    """Mixin for EmberCog that integrates with the permission system.

    Add this to EmberCog's base classes to auto-register @requires commands.
    EmberCog already inherits from commands.Cog, so we use multiple inheritance.

    In cog_load(), call `await self._register_permissions()` to register all
    commands that use @requires with the PermissionRegistry.
    """

    async def _register_permissions(self) -> None:
        """Register all @requires-decorated commands in this cog."""
        from core.cog import _convert_to_snake_case

        registry = await PermissionRegistry.get(self.bot)
        cog_name = _convert_to_snake_case(self.__class__.__name__)

        for attr_name in dir(self):
            if attr_name.startswith("_"):
                continue
            attr = getattr(self, attr_name)
            if isinstance(attr, app_commands.Command):
                # Check for command groups recursively
                await self._register_command_recursive(attr, cog_name, registry)
            elif isinstance(attr, app_commands.Group):
                # Groups also need registration for their callback if decorated
                await self._register_command_recursive(attr, cog_name, registry)

        logger.debug("Registered permissions for cog %s", cog_name)

    async def _register_command_recursive(
        self,
        cmd: app_commands.Command[Any, Any, Any] | app_commands.Group,
        cog_name: str,
        registry: PermissionRegistry,
    ) -> None:
        """Recursively register a command and its subcommands."""
        # Check if command has __requires_level__ (from @requires)
        level = None
        if isinstance(cmd, app_commands.Command) and cmd.callback:
            level = getattr(cmd.callback, "__requires_level__", None)

        # For groups, try to get level from the group's callback if it exists
        if (
            isinstance(cmd, app_commands.Group)
            and level is None
            and hasattr(cmd, "callback")
            and cmd.callback
        ):
            level = getattr(cmd.callback, "__requires_level__", None)

        if level is not None:
            # Build Requires object
            # Default user_perms = None (use privilege level)
            # Default bot_perms = empty (no special bot perms required)
            bot_perms = getattr(cmd, "__requires_bot_perms__", discord.Permissions.none())
            if isinstance(bot_perms, dict):
                perms = discord.Permissions.none()
                perms.update(**bot_perms)
                bot_perms = perms

            requires_obj = Requires(
                privilege_level=level,
                user_perms=None,
                bot_perms=bot_perms,
                checks=[],  # No custom checks yet
                command_path=f"{cog_name}:{cmd.name}",
            )
            registry.register(requires_obj.command_path, requires_obj)
            logger.debug("Registered permission: %s -> %s", requires_obj.command_path, level.name)

        # Recurse into subcommands
        if isinstance(cmd, app_commands.Group):
            for subcmd in cmd.commands:
                await self._register_command_recursive(subcmd, cog_name, registry)


# ═══════════════════════════════════════════════════════════════════════════
# Helper: Get a member's permission level (for PermissionsMixin._get_user_permission_level)
# ═══════════════════════════════════════════════════════════════════════════


async def _get_user_permission_level(
    user: discord.Member, guild: discord.Guild, bot: discord.Client
) -> PermissionLevel:
    """Calculate user's actual PrivilegeLevel (used by EmberCog's permission checks)."""
    if await bot.is_owner(user):
        return PermissionLevel.BOT_OWNER
    if user.id == guild.owner_id:
        return PermissionLevel.GUILD_OWNER

    # Intrinsic Discord permissions short-circuit before hitting Config.
    if getattr(getattr(user, "guild_permissions", None), "administrator", False):
        return PermissionLevel.ADMIN

    mod_role_id = await _config.get("guild", guild.id, "mod_role_id")
    admin_role_id = await _config.get("guild", guild.id, "admin_role_id")

    if admin_role_id and any(role.id == admin_role_id for role in getattr(user, "roles", [])):
        return PermissionLevel.ADMIN
    if mod_role_id and any(r.id == mod_role_id for r in getattr(user, "roles", [])):
        return PermissionLevel.MOD
    if getattr(getattr(user, "guild_permissions", None), "manage_messages", False):
        return PermissionLevel.MOD

    return PermissionLevel.NONE  # Regular members have NONE privilege
