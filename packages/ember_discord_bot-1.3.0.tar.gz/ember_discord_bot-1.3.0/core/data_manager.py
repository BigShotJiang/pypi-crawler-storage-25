from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from discord.ext import commands

logger = logging.getLogger("ember.data_manager")

# Root directories
_DATA_ROOT = Path("data/cogs")
_GLOBAL_DATA = Path("data/global")

_DATA_ROOT.mkdir(parents=True, exist_ok=True)
_GLOBAL_DATA.mkdir(parents=True, exist_ok=True)


# ══════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════


def cog_data_path(cog_or_name: commands.Cog | str) -> Path:
    """Return the writable data directory for a cog.

    Creates the directory if it does not exist.

    Args:
        cog_or_name: A cog instance or its name string.

    Returns:
        ``Path("data/cogs/<cog_name>/")``

    Example::

        path = cog_data_path(self)                   # inside a cog method
        path = cog_data_path("birthday")             # by name
        db   = cog_data_path(self) / "birthday.db"
    """
    name = _resolve_name(cog_or_name)
    path = _DATA_ROOT / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def bundled_data_path(cog_or_name: commands.Cog | str) -> Path:
    """Return the read-only assets directory shipped with a cog.

    Looks for ``cogs/<cog_name>/data/``.  Does NOT create the directory —
    these files are part of the cog's source tree.

    Args:
        cog_or_name: A cog instance or its name string.

    Returns:
        ``Path("cogs/<cog_name>/data/")``

    Raises:
        FileNotFoundError: If the bundled data directory does not exist.
    """
    name = _resolve_name(cog_or_name)
    # Try cog package directory first, fall back to top-level cogs/
    candidates = [
        Path("cogs") / name / "data",
        Path("cogs") / name.lower() / "data",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"No bundled data directory found for cog '{name}'. "
        f"Expected one of: {[str(c) for c in candidates]}"
    )


def global_data_path() -> Path:
    """Return the shared global data directory (not per-cog).

    Use this for data shared between multiple cogs (e.g. a shared user registry).
    Returns ``Path("data/global/")``.
    """
    return _GLOBAL_DATA


def core_data_path() -> Path:
    """Return the core system data directory: ``Path("data/core/")``."""
    path = Path("data/core")
    path.mkdir(parents=True, exist_ok=True)
    return path


# ══════════════════════════════════════════════════════════════
# Internal
# ══════════════════════════════════════════════════════════════


def _resolve_name(cog_or_name: commands.Cog | str) -> str:
    if isinstance(cog_or_name, str):
        return cog_or_name.lower()
    # Cog instance — use the class name, lowercased
    return type(cog_or_name).__name__.lower()
