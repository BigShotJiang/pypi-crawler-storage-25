from __future__ import annotations

from core._settings_caches import ignore_mgr


async def initialize() -> None:
    pass


async def is_guild_ignored(guild_id: int) -> bool:
    return await ignore_mgr.is_guild_ignored(guild_id)


async def ignore_guild(guild_id: int) -> None:
    await ignore_mgr.ignore_guild(guild_id)


async def unignore_guild(guild_id: int) -> bool:
    return await ignore_mgr.unignore_guild(guild_id)


async def is_channel_ignored(guild_id: int, channel_id: int) -> bool:
    return await ignore_mgr.is_channel_ignored(guild_id, channel_id)


async def ignore_channel(guild_id: int, channel_id: int) -> None:
    await ignore_mgr.ignore_channel(guild_id, channel_id)


async def unignore_channel(guild_id: int, channel_id: int) -> bool:
    return await ignore_mgr.unignore_channel(guild_id, channel_id)


async def list_guild_ignores(guild_id: int) -> dict:
    return await ignore_mgr.list_guild(guild_id)
