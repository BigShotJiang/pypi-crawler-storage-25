import logging
import os
from pathlib import Path

from dotenv import load_dotenv

logger = logging.getLogger(__name__)


def load_env() -> bool:
    """
    Load environment variables from .env file.

    Returns:
        True if .env was loaded successfully, False otherwise.
    """
    env_path = Path(__file__).parent.parent / ".env"
    if env_path.exists():
        result = load_dotenv(env_path)
        logger.info(f"Loaded .env file: {result}")
        return result
    logger.warning("No .env file found")
    return False


def get_required_env(var_name: str, default: str | None = None) -> str:
    """
    Get a required environment variable.

    Args:
        var_name: Name of the environment variable.
        default: Optional default value.

    Returns:
        The environment variable value.

    Raises:
        ValueError: If the variable is not set and no default provided.
    """
    value = os.getenv(var_name, default)
    if value is None:
        raise ValueError(f"Required environment variable '{var_name}' is not set")
    return value


def get_int_env(var_name: str, default: int | None = None) -> int:
    """
    Get an integer environment variable.

    Args:
        var_name: Name of the environment variable.
        default: Optional default value.

    Returns:
        The integer value.
    """
    value = os.getenv(var_name)
    if value is None:
        if default is not None:
            return default
        raise ValueError(f"Environment variable '{var_name}' is not set")
    return int(value)
