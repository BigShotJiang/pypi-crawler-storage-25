import os
from pathlib import Path

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

LOG_DIR = Path(os.getenv("LOG_DIR", "logs"))
DATA_DIR = Path(os.getenv("DATA_DIR", "data"))

LOG_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
