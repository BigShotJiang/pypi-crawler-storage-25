import os
from typing import Any

from .env_loader import get_int_env, get_required_env, load_env

# Load .env file if available
load_env()


class _LazyConfig:
    """Lazy configuration loader that defers env var access until needed."""

    def __init__(self) -> None:
        self._cache: dict[str, Any] = {}
        self._loaded = False

    def _load(self) -> None:
        """Load all config values into cache."""
        if self._loaded:
            return

        self._cache["BOT_TOKEN"] = get_required_env("BOT_TOKEN")
        self._cache["APP_ID"] = get_int_env("APP_ID", 0)
        self._cache["OWNER_IDS"] = [
            int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()
        ]

        self._cache["SHARD_COUNT"] = get_int_env("SHARD_COUNT", 1)
        self._cache["SHARD_IDS"] = [
            int(s) for s in os.getenv("SHARD_IDS", "").split(",") if s.strip().isdigit()
        ]

        self._cache["EMBER_DB_BACKEND"] = os.getenv("EMBER_DB_BACKEND", "sqlite")
        self._cache["EMBER_POSTGRES_DSN"] = os.getenv("EMBER_POSTGRES_DSN")
        self._cache["EMBER_MONGO_URI"] = os.getenv("EMBER_MONGO_URI")

        self._cache["EMBER_RPC_ENABLED"] = os.getenv("EMBER_RPC_ENABLED", "false").lower() == "true"
        self._cache["EMBER_RPC_PORT"] = get_int_env("EMBER_RPC_PORT", 6133)
        self._cache["EMBER_RPC_HOST"] = os.getenv("EMBER_RPC_HOST", "127.0.0.1")
        self._cache["EMBER_RPC_SECRET"] = os.getenv("EMBER_RPC_SECRET")

        self._cache["TRIAL_STAFF_ROLE_ID"] = get_int_env("TRIAL_STAFF_ROLE_ID", 0)
        self._cache["CHAT_MANAGER_ROLE_ID"] = get_int_env("CHAT_MANAGER_ROLE_ID", 0)
        self._cache["HELPER_ROLE_ID"] = get_int_env("HELPER_ROLE_ID", 0)
        self._cache["MODERATOR_ROLE_ID"] = get_int_env("MODERATOR_ROLE_ID", 0)

        self._cache["EMBER_HOT_RELOAD"] = os.getenv("EMBER_HOT_RELOAD", "false").lower() == "true"

        self._cache["BIRTHDAY_IMAGE_URL"] = os.getenv("BIRTHDAY_IMAGE_URL", "")

        self._loaded = True

    def __getattr__(self, name: str) -> Any:
        """Access config values as attributes."""
        if name not in self._cache:
            self._load()
        return self._cache.get(name)

    def __getitem__(self, key: str) -> Any:
        """Access config values using dict-style indexing."""
        if key not in self._cache:
            self._load()
        return self._cache.get(key)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value with optional default."""
        if key not in self._cache:
            self._load()
        return self._cache.get(key, default)


# Global config instance
_settings = _LazyConfig()

# Expose as module-level attributes (will be resolved on first access)
BOT_TOKEN = _settings.BOT_TOKEN
APP_ID = _settings.APP_ID
OWNER_IDS = _settings.OWNER_IDS
SHARD_COUNT = _settings.SHARD_COUNT
SHARD_IDS = _settings.SHARD_IDS
EMBER_DB_BACKEND = _settings.EMBER_DB_BACKEND
EMBER_POSTGRES_DSN = _settings.EMBER_POSTGRES_DSN
EMBER_MONGO_URI = _settings.EMBER_MONGO_URI
EMBER_RPC_ENABLED = _settings.EMBER_RPC_ENABLED
EMBER_RPC_PORT = _settings.EMBER_RPC_PORT
EMBER_RPC_HOST = _settings.EMBER_RPC_HOST
EMBER_RPC_SECRET = _settings.EMBER_RPC_SECRET
TRIAL_STAFF_ROLE_ID = _settings.TRIAL_STAFF_ROLE_ID
CHAT_MANAGER_ROLE_ID = _settings.CHAT_MANAGER_ROLE_ID
HELPER_ROLE_ID = _settings.HELPER_ROLE_ID
MODERATOR_ROLE_ID = _settings.MODERATOR_ROLE_ID
EMBER_HOT_RELOAD = _settings.EMBER_HOT_RELOAD
BIRTHDAY_IMAGE_URL = _settings.BIRTHDAY_IMAGE_URL

__all__ = [
    "BOT_TOKEN",
    "APP_ID",
    "OWNER_IDS",
    "SHARD_COUNT",
    "SHARD_IDS",
    "EMBER_DB_BACKEND",
    "EMBER_POSTGRES_DSN",
    "EMBER_MONGO_URI",
    "EMBER_RPC_ENABLED",
    "EMBER_RPC_PORT",
    "EMBER_RPC_HOST",
    "EMBER_RPC_SECRET",
    "TRIAL_STAFF_ROLE_ID",
    "CHAT_MANAGER_ROLE_ID",
    "HELPER_ROLE_ID",
    "MODERATOR_ROLE_ID",
    "EMBER_HOT_RELOAD",
    "BIRTHDAY_IMAGE_URL",
    "_settings",
]
