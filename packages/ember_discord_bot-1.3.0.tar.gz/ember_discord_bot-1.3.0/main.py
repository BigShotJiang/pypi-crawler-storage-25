"""Ember Discord Bot — direct entry point.

Equivalent to `ember run [cog_filter]`. Kept as a thin shim so existing
``python main.py`` invocations and `Dockerfile`/systemd units keep working.

Usage:
    python main.py                       # load all cogs
    python main.py birthday              # filter by cog name
    python main.py cogs/mod              # filter by category
"""

from __future__ import annotations

import sys

from core.cli import run


def _print_usage() -> None:
    print("""Ember Discord Bot

Usage:
    python main.py [COG_FILTER]
    ember run [COG_FILTER]

Cog filters:
    Full path:    cogs/folder/file.py
    Folder path:  cogs/folder/
    Folder name:  folder (looks under cogs/)
    Cog name:     name (looks for name.py or name folder)

For everything else (debuginfo, version, cog list, backend), use the `ember`
CLI directly: `ember --help`.""")


def main() -> int:
    cog_filter: str | None = None
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg in ("-h", "--help", "help"):
            _print_usage()
            return 0
        cog_filter = arg
    return run(cog_filter)


if __name__ == "__main__":
    sys.exit(main())
