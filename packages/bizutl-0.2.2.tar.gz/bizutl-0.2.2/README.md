
## 📂 System Architecture


The `bizutl` suite is designed with a clean separation of concerns, ensuring high performance and modularity.

[Full Documentation & Architecture (with Diagrams) at Codeberg](https://codeberg.org/yellow-x-black/bizutl)

* ***File explorer***

* ***File to markdown***

* ***Japan stats api***

* ***Office to pdf***

* ***Pdf editor***

```text

bizutl/

├── LICENSE
├── README.md
├── bizutl
│   ├── config
│   ├── file_explorer / # Foundational navigation & keyword search (Recursive)
│   ├── file_to_markdown / # Universal file-to-markdown utility
│   ├── japan_stats_api / # High-performance e-stat integration (asyncio)
│   ├── launcher
│   │   ├── bizutl_cli.py / # Unified CLI Entry Point
│   │   └── bizutl_gui.py / # Unified GUI Entry Point
│   ├── office_to_pdf / # Office document conversion (Libre/soffice)
│   └── pdf_editor / # PDF viewing and editing (pypdf)
├── docs
│   └── assets / # Logo
├── pyproject.toml
├── tests / # Global test suite
└── uv.lock
```
