import sys
from functools import wraps
from logging import INFO, Formatter, Handler, LogRecord
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTimer, SignalInstance
from PySide6.QtGui import QClipboard, QFont, QFontDatabase, QKeySequence, QShortcut, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QLayout,
    QLayoutItem,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QScrollArea,
    QTextEdit,
    QWidget,
)

from bizutl.config.base_config import (
    BaseLogTools,
    CustomBranchFormatter,
    convert_from_dt_type_to_str_type,
    is_wsl,
)


class QtSignalLogHandler(Handler):
    """
    A logging handler that forwards formatted log messages to a Qt signal.
    """

    def __init__(self, signal: SignalInstance):
        """Constructor"""
        super().__init__()
        self.signal: SignalInstance = signal

    def emit(self, record: LogRecord) -> None:
        """Formats the given log record and emits the resulting message through the associated Qt signal."""
        msg: str = self.format(record)
        self.signal.emit(msg)


class GUILogTools(BaseLogTools):
    """
    A utility class for configuring a logger with file, Qt signal handlers.
    ex.
    * logger.debug()
    * logger.info()
    * logger.warning()
    * logger.error()
    * logger.critical()
    """

    def __init__(self):
        """Constructor"""
        super().__init__()

    def setup_qt_signal_handler(self, log: SignalInstance) -> bool:
        """
        Configures and attaches a QtSignalLogHandler
        that forwards log messages to the specified Qt signal.
        """
        result: bool = False
        try:
            self.qt_signal_handler: QtSignalLogHandler = QtSignalLogHandler(log)
            self.qt_signal_handler.setLevel(INFO)
            self.str_of_qt_signal_formatter: str = "%(message)s"
            self.qt_signal_formatter: Formatter = CustomBranchFormatter(fmt=self.str_of_qt_signal_formatter)
            self.qt_signal_handler.setFormatter(self.qt_signal_formatter)
            self.logger.addHandler(self.qt_signal_handler)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result


class ConfigureShortcutsWithQtOnWsl:
    """Configure the shortcuts with Qt on WSL (Windows Subsystem Linux)."""

    def __init__(self, app: QApplication):
        """Constructor"""
        self.app: QApplication = app
        self.clipboard: QClipboard = self.app.clipboard()

    def focused(self) -> QWidget | None:
        """Focus QWidget on QApplication."""
        return self.app.focusWidget()

    def noop(self) -> None:
        """No operation"""
        pass

    def copy(self) -> None:
        self.widget: QWidget | None = self.focused()
        if isinstance(self.widget, QLineEdit):
            self.clipboard.setText(self.widget.selectedText())
        elif isinstance(self.widget, (QTextEdit, QPlainTextEdit)):
            self.cursor: QTextCursor = self.widget.textCursor()
            if self.cursor.hasSelection():
                self.clipboard.setText(self.cursor.selectedText())

    def paste(self) -> None:
        self.widget: QWidget | None = self.focused()
        if isinstance(self.widget, QLineEdit):
            self.widget.insert(self.clipboard.text())
        elif isinstance(self.widget, (QTextEdit, QPlainTextEdit)):
            self.widget.insertPlainText(self.clipboard.text())

    def undo(self) -> None:
        self.widget: QWidget | None = self.focused()
        if isinstance(self.widget, (QLineEdit, QTextEdit, QPlainTextEdit)):
            self.widget.undo()

    def redo(self) -> None:
        self.widget: QWidget | None = self.focused()
        if isinstance(self.widget, (QLineEdit, QTextEdit, QPlainTextEdit)):
            self.widget.redo()

    def configure(self, parent: QWidget) -> bool:
        """Configure."""
        result: bool = False
        try:
            self.parent: QWidget = parent
            self.enabled_sc_dct: dict = {
                "e_sc_copy": ("Ctrl+Alt+C", self.copy),
                "e_sc_paste": ("Ctrl+Alt+V", self.paste),
                "e_sc_undo": ("Ctrl+Alt+Z", self.undo),
                "e_sc_redo": ("Ctrl+Alt+Y", self.redo),
            }
            for name, (key, slot) in self.enabled_sc_dct.items():
                e_sc: QShortcut = QShortcut(
                    QKeySequence(key), self.parent, slot, Qt.ShortcutContext.ApplicationShortcut
                )
                setattr(self, name, e_sc)
            self.disenabled_sc_dct: dict = {
                "d_sc_copy": QKeySequence.StandardKey.Copy,
                "d_sc_paste": QKeySequence.StandardKey.Paste,
                "d_sc_undo": QKeySequence.StandardKey.Undo,
                "d_sc_redo": QKeySequence.StandardKey.Redo,
            }
            for name, key in self.disenabled_sc_dct.items():
                d_sc: QShortcut = QShortcut(
                    key, self.parent, self.noop, Qt.ShortcutContext.ApplicationShortcut
                )
                d_sc.activated.connect(self.noop)
                setattr(self, name, d_sc)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result


def display_error_of_start_up(msg: str) -> None:
    """Display the error of start up."""
    box: QMessageBox = QMessageBox(None)
    box.setIcon(QMessageBox.Icon.Critical)
    box.setWindowTitle("Error")
    box.setText(msg)
    MILLI_SECONDS: int = 10000
    QTimer.singleShot(MILLI_SECONDS, box.accept)
    box.exec()


def clear_layout(layout: QLayout) -> None:
    """Safely delete the contents of the QLayout."""
    while layout.count():
        item: QLayoutItem | None = layout.takeAt(0)
        if item is not None:
            child_widget: QWidget | None = item.widget()
            if child_widget is not None:
                child_widget.deleteLater()
            else:
                child_layout: QLayout | None = item.layout()
                if child_layout is not None:
                    clear_layout(child_layout)


def clear_widget(widget: QWidget | None) -> None:
    """Safely delete the contents of the QWidget."""
    if widget is None:
        raise Exception("Widget is None.")
    # QScrollArea
    if isinstance(widget, QScrollArea):
        inner: QWidget | None = widget.takeWidget()
        if inner is not None:
            inner.deleteLater()
    else:
        layout: QLayout | None = widget.layout()
        if layout is not None:
            clear_layout(layout)


def wrap_settingup_log_with_gui(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        def _setup_log_with_gui() -> None:
            """Set up log."""
            # exe化されている場合とそれ以外を切り分ける
            exe_path: Path = Path(sys.executable) if getattr(sys, "frozen", False) else Path(__file__)
            # ログフォルダのパス
            folder_p: Path = exe_path.parent / "__log__"
            # ログフォルダが存在しない場合は、作成します
            folder_p.mkdir(parents=True, exist_ok=True)
            # ログファイル名
            file_name: str = f"log_{convert_from_dt_type_to_str_type("for_file_name")}.log"
            file_p: Path = folder_p / file_name
            self.obj_of_lt.file_path_of_log = str(file_p)
            self.obj_of_lt.setup_file_handler(self.obj_of_lt.file_path_of_log)
            self.obj_of_lt.setup_qt_signal_handler(self.log)
            self.log.connect(self.append_log_to_qtextedit, Qt.ConnectionType.QueuedConnection)
            self.obj_of_lt.logger.propagate = False
            self.obj_of_cls.append_log_for_constructor()

        result: None = None
        self.obj_of_lt: GUILogTools = GUILogTools()
        try:
            func(self, *args, **kwargs)
            _setup_log_with_gui()
        except ImportError as e:
            display_error_of_start_up(str(e))
            raise
        except Exception as e:
            display_error_of_start_up(str(e))
            raise
        else:
            pass
        finally:
            pass
        return result

    return wrapper


def wrap_showevent_with_gui(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        result: None = func(self, *args, **kwargs)
        if is_wsl() and self.obj_of_sc and not self.sc_init_flag:
            self.obj_of_sc.configure(self)
            self.sc_init_flag = True
        return result

    return wrapper


def wrap_closeevent_with_gui(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        result: None = None
        if hasattr(self, "obj_of_lt") and self.obj_of_lt:
            msg: str = f"Log file path: \n{self.obj_of_lt.file_path_of_log}"
            self.obj_of_lt.logger.info(msg)
            QMessageBox.information(self, "Information", msg)
        result = func(self, *args, **kwargs)
        return result

    return wrapper


def wrap_notifying_result_with_gui(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        result: None = None
        funcname: str = func.__name__
        try:
            result = func(self, *args, **kwargs)
        except ImportError:
            raise
        except Exception as e:
            failure_msg: str = f"{funcname} -> ***Failed***\n{str(e)}"
            if hasattr(self, "obj_of_lt") and self.obj_of_lt:
                self.obj_of_lt.logger.warning(failure_msg)
            QMessageBox.warning(self, "Result", failure_msg)
        else:
            success_msg: str = f"{funcname} -> ***Succeeded***"
            if hasattr(self, "obj_of_lt") and self.obj_of_lt:
                self.obj_of_lt.logger.info(success_msg)
        finally:
            pass
        return result

    return wrapper


def wrap_start_up_with_gui(func):
    @wraps(wrapped=func)
    def wrapper(*args, **kwargs):
        result: None = None
        try:
            app, create_window = func()
            # アプリ単位でフォントを設定する
            if is_wsl():
                font_path: str = "/usr/share/fonts/opentype/ipafont-gothic/ipag.ttf"
                font_id: int = QFontDatabase.addApplicationFont(font_path)
                font_family: str = QFontDatabase.applicationFontFamilies(font_id)[0]
                font: QFont = QFont(font_family)
            else:
                font: QFont = QFont()
            font.setPointSize(12)
            app.setFont(font)
            window: Any = create_window(app)
            window.resize(1000, 800)
            # 最大化して、表示させる
            window.showMaximized()
            sys.exit(app.exec())
        except ImportError as e:
            display_error_of_start_up(str(e))
        except Exception as e:
            display_error_of_start_up(str(e))
        else:
            pass
        finally:
            pass
        return result

    return wrapper
