import sys
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable

from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from bizutl.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from bizutl.file_explorer.explorer_engine import GetFileList
from bizutl.file_to_markdown.converter_md_engine import ConvertToMd
from bizutl.japan_stats_api.stats_engine import GetJapanGovernmentStatistics
from bizutl.pdf_editor.pdf_editor_engine import EditPdf


@dataclass
class LauncherItem:
    title: str
    callback: Callable
    description: str | None


class MainApp_Of_Gui_Launcher(QMainWindow):
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.child_windows: list = []
        self.setup_ui()

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)

    def launch(self, tool: str) -> None:
        """Call the user-specified tool."""
        match tool:
            case "file_explorer":
                from bizutl.file_explorer.search_gui import create_window
            case "file_to_markdown":
                from bizutl.file_to_markdown.convert_md_gui import create_window
            case "japan_stats_api":
                from bizutl.japan_stats_api.stats_gui import create_window
            case "office_to_pdf":
                from bizutl.office_to_pdf.convert_pdf_gui import create_window
            case "pdf_editor":
                from bizutl.pdf_editor.edit_pdf_gui import create_window
            case _:
                raise Exception("That tool is invalid.")
        window: Any = create_window(self.app)
        window.showMaximized()
        self.child_windows.append(window)

    @wrap_notifying_result_with_gui
    def setup_ui(self) -> None:
        """Configure the User Interface."""
        from bizutl.office_to_pdf.converter_pdf_engine import ConvertLibreToPDF

        # タイトル
        self.setWindowTitle("Useful Tools - GUI Launcher - ")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # 主要
        main_scroll_area: QScrollArea = QScrollArea()
        main_scroll_area.setWidgetResizable(True)
        base_layout.addWidget(main_scroll_area)
        main_container: QWidget = QWidget()
        main_container_layout: QVBoxLayout = QVBoxLayout(main_container)
        main_scroll_area.setWidget(main_container)
        main_container_layout.addWidget(QLabel("Select from the list below."))
        # 選択
        launcher_items: tuple = (
            LauncherItem(
                title="source/file_explorer",
                callback=partial(self.launch, "file_explorer"),
                description=GetFileList.__doc__,
            ),
            LauncherItem(
                title="source/file_to_markdown",
                callback=partial(self.launch, "file_to_markdown"),
                description=ConvertToMd.__doc__,
            ),
            LauncherItem(
                title="source/japan_stats_api",
                callback=partial(self.launch, "japan_stats_api"),
                description=GetJapanGovernmentStatistics.__doc__,
            ),
            LauncherItem(
                title="source/office_to_pdf",
                callback=partial(self.launch, "office_to_pdf"),
                description=ConvertLibreToPDF.__doc__,
            ),
            LauncherItem(
                title="source/pdf_editor",
                callback=partial(self.launch, "pdf_editor"),
                description=EditPdf.__doc__,
            ),
        )
        for item in launcher_items:
            description: QLabel = QLabel(item.description)
            description.setWordWrap(True)
            btn: QPushButton = QPushButton(item.title)
            btn.clicked.connect(item.callback)
            main_container_layout.addWidget(description)
            main_container_layout.addWidget(btn)
        main_container_layout.addStretch()


def create_window(app: QApplication) -> MainApp_Of_Gui_Launcher:
    window: MainApp_Of_Gui_Launcher = MainApp_Of_Gui_Launcher(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
