import sys

from bizutl.config.cli_config import wrap_start_up_with_cli


class Launcher_With_Cli:
    def __init__(self):
        """Constructor"""
        pass

    def run_with_cli(self, tool: str) -> None:
        """Run with CLI."""
        try:
            match tool:
                case "file_explorer":
                    from bizutl.file_explorer.search_cli import main
                case "file_to_markdown":
                    from bizutl.file_to_markdown.convert_md_cli import main
                case "japan_stats_api":
                    from bizutl.japan_stats_api.stats_cli import main
                case "office_to_pdf":
                    from bizutl.office_to_pdf.convert_pdf_cli import main
                case "pdf_editor":
                    from bizutl.pdf_editor.edit_pdf_cli import main
                case _:
                    raise Exception("That tool is invalid.")
            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def run_with_gui(self, tool: str) -> None:
        """Run with GUI."""
        try:
            match tool:
                case "file_explorer":
                    from bizutl.file_explorer.search_gui import main
                case "file_to_markdown":
                    from bizutl.file_to_markdown.convert_md_gui import main
                case "office_to_pdf":
                    from bizutl.office_to_pdf.convert_pdf_gui import main
                case "pdf_editor":
                    from bizutl.pdf_editor.edit_pdf_gui import main
                case "japan_stats_api":
                    from bizutl.japan_stats_api.stats_gui import main
                case _:
                    raise Exception("That tool is invalid.")
            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def run_gui_launcher(self) -> None:
        """Run GUI launcher."""
        try:
            from bizutl.launcher.bizutl_gui import main

            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def print_usage(self) -> None:
        """Print usage."""
        print("\nUsage: ")
        usage_tpl: tuple = (
            "* GUI Launcher => cli_launcher.py",
            "* Tool of CLI => cli_launcher.py cli <tool_name>",
            "* Tool of GUI => cli_launcher.py gui <tool_name>",
        )
        print("\n".join(usage_tpl))
        print("\nTools List: ")
        tools_lst: list = [
            "file_explorer",
            "file_to_markdown",
            "japan_stats_api",
            "office_to_pdf",
            "pdf_editor",
        ]
        print("\n".join(f"* {key}" for key in tools_lst))

    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        try:
            if len(sys.argv) == 1:
                self.run_gui_launcher()
            elif len(sys.argv) == 3:
                mode: str = sys.argv[1]
                tool: str = sys.argv[2]
                match mode:
                    case "cli":
                        self.run_with_cli(tool)
                    case "gui":
                        self.run_with_gui(tool)
                    case _:
                        raise Exception("That mode is invalid.")
            else:
                self.print_usage()
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"***Processing failed.***: \n{str(e)}")
        else:
            result = True
        finally:
            pass
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: Launcher_With_Cli = Launcher_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
