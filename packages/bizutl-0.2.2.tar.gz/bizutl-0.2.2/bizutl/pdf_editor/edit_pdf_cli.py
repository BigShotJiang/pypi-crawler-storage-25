import re
from enum import IntEnum, StrEnum
from typing import Self

from pypdf import DocumentInformation

from bizutl.config.base_config import convert_from_dt_type_to_str_type
from bizutl.config.cli_config import (
    CLILogTools,
    input_and_check_number,
    input_file_path,
    input_lst,
    wrap_execution_with_cli,
    wrap_repeating_input,
    wrap_settingup_log_with_cli,
    wrap_start_up_with_cli,
)
from bizutl.pdf_editor.pdf_editor_engine import EditPdf


class MENU(StrEnum):
    encrypt_file: str | None = EditPdf.encrypt_file.__doc__
    decrypt_file: str | None = EditPdf.decrypt_file.__doc__
    get_metadata: str | None = EditPdf.get_metadata.__doc__
    write_metadata: str | None = EditPdf.write_metadata.__doc__
    merge_files: str | None = EditPdf.merge_files.__doc__
    extract_pages: str | None = EditPdf.extract_pages.__doc__
    delete_pages: str | None = EditPdf.delete_pages.__doc__
    extract_text: str | None = EditPdf.extract_text.__doc__
    rotate_page: str | None = EditPdf.rotate_page_clockwise.__doc__

    @classmethod
    def by_index(cls, index: int) -> Self:
        return list(cls)[index]

    @classmethod
    def to_index(cls, member: Self) -> int:
        return list(cls).index(member)


class DEGREES(IntEnum):
    ninety: int = 90
    one_hundred_eighty: int = 180
    two_hundred_seventy: int = 270

    @classmethod
    def by_index(cls, index: int) -> Self:
        return list(cls)[index]

    @classmethod
    def to_index(cls, member: Self) -> int:
        return list(cls).index(member)


class EP_With_Cli:
    @wrap_settingup_log_with_cli
    def __init__(self):
        """Constructor"""
        self.obj_of_lt: CLILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls = EditPdf(self.obj_of_lt.logger)

    def select_menu_number(self) -> str | None:
        """Select the menu."""
        menu: list = [f"({index}) {m.value}" for index, m in enumerate(MENU, start=1)]
        choice: int = 0
        try:
            print(*menu, sep="\n")
            choice = input_and_check_number("menu number", len(menu))
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"Error: \n{str(e)}")
        else:
            pass
        finally:
            pass
        return MENU.by_index(choice - 1)

    @wrap_repeating_input
    def input_password(self, keyword: str) -> str:
        """Enter the password to encrypt or decrypt the PDF file."""
        pw: str = ""
        pw = input(f"Enter the password to {keyword} the PDF file: ").strip()
        if pw == "":
            raise Exception("The password is not entered.")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", pw):
            raise Exception(
                "Enter the following characters: \n* Alphanumeric characters\n* Underscores\n* Hyphens"
            )
        return pw

    @wrap_repeating_input
    def input_writing_metadata(
        self, metadata_of_writer: dict, creation_date: DocumentInformation | None, fields: dict
    ) -> dict:
        """Enter the metadata to be written to the PDF file."""
        for ky, vl in fields.items():
            match ky:
                case "creation_date":
                    metadata_of_writer[vl] = creation_date
                case "modification_date":
                    time: str = convert_from_dt_type_to_str_type("for_metadata_of_pdf_file")
                    metadata_of_writer[vl] = time
                case _:
                    value: str = input(f"{ky.capitalize().replace("_", " ")}: ").strip()
                    metadata_of_writer[vl] = value
        return metadata_of_writer

    @wrap_repeating_input
    def input_page_range(self, kw: str, num_of_pages: int) -> tuple:
        """Enter the page numbers of the specified range in the PDF file."""
        start: int = 0
        end: int = 0
        start = input_and_check_number(f"start page number to {kw}", num_of_pages)
        end = input_and_check_number(f"end page number to {kw}", num_of_pages)
        if end < start:
            raise Exception("The page range is invalid.")
        if kw != "extract text":
            p: int = end - start + 1
            if p == num_of_pages:
                raise Exception("Do not specify all pages.")
        return (start, end)

    def select_degree(self) -> int:
        """Enter the degrees number to rotate the specified page of the PDF file clockwise."""
        degrees: list = [f"({index}) {d.value}" for index, d in enumerate(DEGREES, start=1)]
        choice: int = 0
        try:
            print(*degrees, sep="\n")
            choice = input_and_check_number("number of degrees number", len(degrees))
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"Error: \n{str(e)}")
        else:
            pass
        finally:
            pass
        return DEGREES.by_index(choice - 1)

    @wrap_execution_with_cli
    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        # メニューを選択します
        option: str | None = self.select_menu_number()
        match option:
            case MENU.encrypt_file:
                # ファイルを暗号化します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                pw: str = self.input_password("encrypt")
                self.obj_of_cls.encrypt_file(pw)
            case MENU.decrypt_file:
                # ファイルを復号化します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                pw: str = self.input_password("decrypt")
                self.obj_of_cls.decrypt_file(pw)
            case MENU.get_metadata:
                # メタデータを取得します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                self.obj_of_cls.get_metadata()
            case MENU.write_metadata:
                # メタデータを書き込みます
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                self.obj_of_cls.metadata_of_writer = self.input_writing_metadata(
                    self.obj_of_cls.metadata_of_writer, self.obj_of_cls.creation_date, self.obj_of_cls.fields
                )
                self.obj_of_cls.write_metadata(self.obj_of_cls.metadata_of_writer)
            case MENU.merge_files:
                # ファイルをマージします
                pdfs: list = input_lst(input_file_path, self.obj_of_cls.EXTENSION)
                self.obj_of_cls.merge_files(pdfs)
            case MENU.extract_pages:
                # ページを抽出します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                start, end = self.input_page_range("extract", self.obj_of_cls.num_of_pages)
                self.obj_of_cls.extract_pages(start, end)
            case MENU.delete_pages:
                # ページを削除します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                start, end = self.input_page_range("delete", self.obj_of_cls.num_of_pages)
                self.obj_of_cls.delete_pages(start, end)
            case MENU.extract_text:
                # テキストを抽出します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                start, end = self.input_page_range("extract text", self.obj_of_cls.num_of_pages)
                self.obj_of_cls.extract_text(start, end)
            case MENU.rotate_page:
                # ページを時計回りで回転します
                self.obj_of_cls.file_path = input_file_path(self.obj_of_cls.EXTENSION)
                self.obj_of_cls.read_file()
                page: int = input_and_check_number("page number to rotate", self.obj_of_cls.num_of_pages)
                degrees: int = self.select_degree()
                self.obj_of_cls.rotate_page_clockwise(page, degrees)
            case None:
                raise Exception("The description of your choice is none.")
            case _:
                pass
        result = True
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: EP_With_Cli = EP_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
