"""Tests for the plugin layer.

Coverage:

* Discovery against an empty environment returns empty dict.
* load_by_name raises informative KeyError for unknown plugin.
* TribunalCheck constructor validation.
* TribunalCheck verdict logic with mocked judges (both-allow, both-block,
  disagree, judge-error).
* SandboxPreviewCheck constructor validation.
* SandboxPreviewCheck dispatch (only_for_tools filter, dryrun-required
  escalation, policy allow/escalate, runner exception fails closed).
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from signet.core.context import RequestContext, ResponseContext, ToolCallContext
from signet.core.owner import Owner
from signet.plugins import (
    DiscoveredPlugin,
    discover,
    discover_plugins,
    load_by_name,
    reset_cache,
    resolve,
)
from signet.plugins.sandbox import (
    SandboxPreviewCheck,
    SandboxResult,
)
from signet.plugins.tribunal import TribunalCheck


def _tool_ctx(tool: str = "send_email", **meta: Any) -> ToolCallContext:
    req = RequestContext(owner=Owner.human("alice"))
    rsp = ResponseContext(request=req)
    return ToolCallContext(
        request=req,
        response=rsp,
        tool_name=tool,
        arguments={"to": "bob@example.com"},
        tool_metadata=meta,
    )


class TestDiscovery:
    def test_empty_environment(self) -> None:
        # Without any external plugin packages installed, discovery
        # returns an empty dict — but it still completes without error.
        reset_cache()
        result = discover(refresh=True)
        # Anything found here came from random installed packages. We
        # only assert the type, not the content.
        assert isinstance(result, dict)

    def test_load_by_name_unknown(self) -> None:
        reset_cache()
        with pytest.raises(KeyError, match="no signet plugin named"):
            load_by_name("definitely-not-installed-7e3a8c")

    def test_discover_plugins_returns_structured_result(self) -> None:
        # Without plugins installed, returns []. With them, every entry
        # carries the documented fields. We only assert structure here —
        # content is environment-dependent.
        reset_cache()
        result = discover_plugins(refresh=True)
        assert isinstance(result, list)
        for entry in result:
            assert isinstance(entry, DiscoveredPlugin)
            assert entry.group in {
                "signet.checks",
                "signet.adapters",
                "signet.anchors",
            }
            assert isinstance(entry.name, str) and entry.name
            assert isinstance(entry.package, str)
            assert isinstance(entry.package_version, str)
            assert isinstance(entry.target, str) and ":" in entry.target
            assert entry.status in {"loaded", "incompatible_abi", "load_error"}
            assert isinstance(entry.abi_required, int)
            if entry.status == "loaded":
                assert entry.error is None
                assert entry.obj is not None
            else:
                assert entry.error  # non-empty error text on failure
                assert entry.obj is None

    def test_check_abi_version_constant(self) -> None:
        from signet.core.check import CHECK_ABI_VERSION, Check

        assert CHECK_ABI_VERSION == 1
        assert Check.CHECK_ABI_VERSION == 1

    def test_resolve_unknown_plugin_raises(self) -> None:
        reset_cache()
        with pytest.raises(KeyError, match="no signet plugin named"):
            resolve("nonexistent-plugin-9f7c1a")

    def test_resolve_returns_check_class(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from signet.core.check import CHECK_ABI_VERSION, Check
        from signet.core.stage import Stage
        from signet.plugins import discovery as discovery_mod

        class _StubCheck(Check):
            name = "stub_resolve_check"
            stage = Stage.ADMISSION

        stub = DiscoveredPlugin(
            group="signet.checks",
            name="stub_resolve_check",
            package="stub-pkg",
            package_version="0.0.1",
            target="tests.fake:_StubCheck",
            status="loaded",
            abi_declared=CHECK_ABI_VERSION,
            abi_required=CHECK_ABI_VERSION,
            error=None,
            obj=_StubCheck,
        )

        def fake_discover_plugins(*, refresh: bool = False) -> list[DiscoveredPlugin]:
            return [stub]

        monkeypatch.setattr(discovery_mod, "discover_plugins", fake_discover_plugins)
        # resolve() lives in signet.plugins and imports discover_plugins
        # from discovery; patch the import site too.
        import signet.plugins as plugins_pkg

        monkeypatch.setattr(plugins_pkg, "discover_plugins", fake_discover_plugins)

        cls = resolve("stub_resolve_check")
        assert cls is _StubCheck

    def test_incompatible_abi_marked_as_unloaded(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from signet.core.check import CHECK_ABI_VERSION, Check
        from signet.core.stage import Stage

        class _FutureCheck(Check):
            name = "future_check"
            stage = Stage.ADMISSION
            CHECK_ABI_VERSION = 99

        stub = DiscoveredPlugin(
            group="signet.checks",
            name="future_check",
            package="future-pkg",
            package_version="0.0.1",
            target="tests.fake:_FutureCheck",
            status="incompatible_abi",
            abi_declared=99,
            abi_required=CHECK_ABI_VERSION,
            error=(
                f"plugin 'future_check' declares CHECK_ABI_VERSION=99; "
                f"signet requires {CHECK_ABI_VERSION}"
            ),
            obj=None,
        )

        def fake_discover_plugins(*, refresh: bool = False) -> list[DiscoveredPlugin]:
            return [stub]

        import signet.plugins as plugins_pkg
        from signet.plugins import discovery as discovery_mod

        monkeypatch.setattr(discovery_mod, "discover_plugins", fake_discover_plugins)
        monkeypatch.setattr(plugins_pkg, "discover_plugins", fake_discover_plugins)

        # Status is reported as incompatible_abi, not loaded.
        plugins = plugins_pkg.discover_plugins()
        assert plugins[0].status == "incompatible_abi"
        assert plugins[0].abi_declared == 99

        # And resolve() refuses with a RuntimeError naming the mismatch.
        with pytest.raises(RuntimeError, match="incompatible_abi"):
            resolve("future_check")


class TestTribunalConstruction:
    def test_requires_both_urls(self) -> None:
        with pytest.raises(ValueError, match="judge_a_url and judge_b_url"):
            TribunalCheck(judge_a_url="http://a", judge_b_url="")
        with pytest.raises(ValueError, match="judge_a_url and judge_b_url"):
            TribunalCheck(judge_a_url="", judge_b_url="http://b")


class TestTribunalVerdicts:
    @pytest.fixture
    def check(self) -> TribunalCheck:
        return TribunalCheck(judge_a_url="http://a", judge_b_url="http://b")

    def _patch_judges(self, monkeypatch: pytest.MonkeyPatch, verdicts: list[str]) -> None:
        """Replace TribunalCheck._ask_judge with a stub returning verdicts in order."""
        calls: list[int] = []

        async def fake_ask(self, _client, _url, _model, _prompt) -> str:
            idx = len(calls)
            calls.append(idx)
            return verdicts[idx]

        monkeypatch.setattr(TribunalCheck, "_ask_judge", fake_ask)

    async def test_both_allow(self, check: TribunalCheck, monkeypatch: pytest.MonkeyPatch) -> None:
        self._patch_judges(monkeypatch, ["ALLOW", "ALLOW"])
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_allow

    async def test_both_block(self, check: TribunalCheck, monkeypatch: pytest.MonkeyPatch) -> None:
        self._patch_judges(monkeypatch, ["BLOCK", "BLOCK"])
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_block

    async def test_disagreement_escalates(
        self, check: TribunalCheck, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        self._patch_judges(monkeypatch, ["ALLOW", "BLOCK"])
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_escalate
        assert result.metadata["judge_a"] == "ALLOW"
        assert result.metadata["judge_b"] == "BLOCK"

    async def test_disagreement_with_unanimous_block_required(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        check = TribunalCheck(
            judge_a_url="http://a", judge_b_url="http://b", require_unanimous_block=True
        )
        self._patch_judges(monkeypatch, ["ALLOW", "BLOCK"])
        result = await check.inspect_tool_call(_tool_ctx())
        # require_unanimous_block flips disagreement to allow
        assert result.is_allow

    async def test_judge_error_treated_as_block(
        self, check: TribunalCheck, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        async def fake_post(self, url, *, json):
            raise httpx.ConnectError("network down")

        monkeypatch.setattr(httpx.AsyncClient, "post", fake_post)
        result = await check.inspect_tool_call(_tool_ctx())
        # Both judges fail → both vote BLOCK → block
        assert result.is_block


class TestSandboxResultSafety:
    def test_ok_with_benign_effect_is_safe(self) -> None:
        r = SandboxResult(ok=True, observed_effect="read 3 rows from users table")
        assert r.is_safe()

    def test_not_ok_is_unsafe(self) -> None:
        r = SandboxResult(ok=False, observed_effect="anything")
        assert not r.is_safe()

    def test_destroy_keyword_flags_unsafe(self) -> None:
        r = SandboxResult(ok=True, observed_effect="would DESTROY 1000 records")
        assert not r.is_safe()


class TestSandboxConstruction:
    def test_no_runner_raises(self) -> None:
        with pytest.raises(ValueError, match="requires a `runner`"):
            SandboxPreviewCheck()


class TestSandboxDispatch:
    @pytest.fixture
    def safe_runner(self):
        async def runner(_tool: str, _args: dict[str, Any]) -> SandboxResult:
            return SandboxResult(ok=True, observed_effect="read-only")

        return runner

    @pytest.fixture
    def destructive_runner(self):
        async def runner(_tool: str, _args: dict[str, Any]) -> SandboxResult:
            return SandboxResult(ok=True, observed_effect="would DELETE table 'users'")

        return runner

    async def test_safe_preview_allows(self, safe_runner) -> None:
        check = SandboxPreviewCheck(runner=safe_runner, require_dryrun_supported=False)
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_allow

    async def test_destructive_preview_escalates(self, destructive_runner) -> None:
        check = SandboxPreviewCheck(runner=destructive_runner, require_dryrun_supported=False)
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_escalate

    async def test_only_for_tools_filter(self, destructive_runner) -> None:
        check = SandboxPreviewCheck(
            runner=destructive_runner,
            only_for_tools=frozenset({"some_other_tool"}),
            require_dryrun_supported=False,
        )
        result = await check.inspect_tool_call(_tool_ctx("send_email"))
        assert result.is_allow  # send_email skipped — not in only_for_tools

    async def test_dryrun_required_but_unsupported_escalates(self, safe_runner) -> None:
        check = SandboxPreviewCheck(runner=safe_runner, require_dryrun_supported=True)
        # tool_metadata defaults to dryrun_supported=False
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_escalate

    async def test_dryrun_supported_proceeds(self, safe_runner) -> None:
        check = SandboxPreviewCheck(runner=safe_runner, require_dryrun_supported=True)
        ctx = _tool_ctx(dryrun_supported=True)
        result = await check.inspect_tool_call(ctx)
        assert result.is_allow

    async def test_runner_exception_fails_closed(self) -> None:
        async def crashing_runner(_tool, _args) -> SandboxResult:
            raise RuntimeError("sandbox container crashed")

        check = SandboxPreviewCheck(runner=crashing_runner, require_dryrun_supported=False)
        result = await check.inspect_tool_call(_tool_ctx())
        assert result.is_block
        assert "RuntimeError" in result.reason

    async def test_registry_is_canonical_source_for_dryrun(self, safe_runner) -> None:
        # v0.1.5 #10: when a registry is supplied, sandbox reads
        # dryrun_supported from there rather than the parallel
        # ToolCallContext.tool_metadata dict. ctx.tool_metadata says
        # False; the registry says True; the registry wins.
        from signet.checks.tool_call_inspector import RiskTier, ToolSpec

        registry = {"send_email": ToolSpec(risk_tier=RiskTier.HIGH, dryrun_supported=True)}
        check = SandboxPreviewCheck(
            runner=safe_runner,
            require_dryrun_supported=True,
            registry=registry,
        )
        # ctx.tool_metadata is empty (default) — without the registry,
        # this would escalate.
        ctx = _tool_ctx("send_email")
        result = await check.inspect_tool_call(ctx)
        assert result.is_allow

    def test_toolspec_as_metadata_round_trip(self) -> None:
        # ToolSpec.as_metadata produces the canonical dict shape that
        # ToolCallContext.tool_metadata expects.
        from signet.checks.tool_call_inspector import RiskTier, ToolSpec

        spec = ToolSpec(risk_tier=RiskTier.HIGH, irreversible=True, dryrun_supported=True)
        meta = spec.as_metadata()
        assert meta == {
            "risk_tier": "high",
            "irreversible": True,
            "dryrun_supported": True,
        }
