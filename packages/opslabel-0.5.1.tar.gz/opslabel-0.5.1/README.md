# OpsLabel CLI

Internal QA CLI for [opslabel.in](https://opslabel.in) contributors.

## Install

```bash
pip install opslabel
```

Requires Python 3.10+.

## Usage

Generate a pairing code on the dashboard at https://opslabel.in/app and follow the on-screen instructions to authenticate this machine.

For all available commands, run:

```bash
opslabel --help
```

## License

MIT — see [LICENSE](LICENSE).
