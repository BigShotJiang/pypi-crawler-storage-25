"""The 8 QA checks for Terminal-Bench tasks.

Each check returns a CheckResult dict matching the schema_version=2 contract:

    {
        "passed": bool,
        "skipped": bool,
        "reason": str,        # only when skipped
        "score": float,       # optional
        "severity": "info" | "warn" | "error",
        "summary": str,
        "details": dict,
        "duration_ms": int,
    }
"""

from __future__ import annotations

import hashlib
import json
import random
import re
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Optional

try:
    import tomllib  # type: ignore[import-not-found]
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]

from . import nim


REQUIRED_FILES = [
    "task.toml",
    "instruction.md",
    "environment/Dockerfile",
    "solution/solve.sh",
    "tests/test.sh",
    "tests/test_outputs.py",
]

REQUIRED_TOP_LEVEL = {"task.toml", "instruction.md", "environment", "solution", "tests"}

ALLOWED_DIFFICULTIES = {"easy", "medium", "hard"}

CANARY_RE = re.compile(
    r"terminal-bench-canary GUID ([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
)

HARBOR_TIMEOUT_SEC = 900


# --------------------------------------------------------------------------- #
# Public helpers reused by scan.py
# --------------------------------------------------------------------------- #

def load_toml(p: Path) -> dict:
    with open(p, "rb") as f:
        return tomllib.load(f)


# --------------------------------------------------------------------------- #
# Result helpers
# --------------------------------------------------------------------------- #

def _result(
    *,
    passed: bool,
    severity: str,
    summary: str,
    details: Optional[dict] = None,
    score: Optional[float] = None,
    duration_ms: int = 0,
) -> dict:
    out: dict[str, Any] = {
        "passed": passed,
        "skipped": False,
        "severity": severity,
        "summary": summary,
        "details": details or {},
        "duration_ms": duration_ms,
    }
    if score is not None:
        out["score"] = score
    return out


def _skipped(reason: str, *, duration_ms: int = 0, details: Optional[dict] = None) -> dict:
    return {
        "passed": False,
        "skipped": True,
        "reason": reason,
        "severity": "info",
        "summary": reason,
        "details": details or {},
        "duration_ms": duration_ms,
    }


def _verdict_to_status(verdict: str) -> tuple[bool, str]:
    v = (verdict or "").lower()
    if v == "pass":
        return True, "info"
    if v == "warn":
        return True, "warn"
    if v == "fail":
        return False, "error"
    return False, "error"


# --------------------------------------------------------------------------- #
# (1) skeleton
# --------------------------------------------------------------------------- #

def check_skeleton(task_path: Path) -> dict:
    t0 = time.monotonic()
    missing: list[str] = []
    empty: list[str] = []
    for rel in REQUIRED_FILES:
        f = task_path / rel
        if not f.exists() or not f.is_file():
            missing.append(rel)
            continue
        try:
            if f.stat().st_size == 0:
                empty.append(rel)
        except OSError:
            empty.append(rel)

    extras: list[str] = []
    try:
        for entry in task_path.iterdir():
            if entry.name not in REQUIRED_TOP_LEVEL and not entry.name.startswith("."):
                extras.append(entry.name + ("/" if entry.is_dir() else ""))
    except OSError:
        pass

    elapsed = int((time.monotonic() - t0) * 1000)
    if missing or empty:
        bits = []
        if missing:
            bits.append(f"missing: {', '.join(missing)}")
        if empty:
            bits.append(f"empty: {', '.join(empty)}")
        return _result(
            passed=False,
            severity="error",
            summary="; ".join(bits),
            details={"missing": missing, "empty": empty, "extras": extras},
            duration_ms=elapsed,
        )

    summary = f"All {len(REQUIRED_FILES)} required files present"
    if extras:
        summary += f" (extras at root: {', '.join(extras[:5])}{'…' if len(extras) > 5 else ''})"
    return _result(
        passed=True,
        severity="info",
        summary=summary,
        details={"missing": [], "empty": [], "extras": extras},
        duration_ms=elapsed,
    )


# --------------------------------------------------------------------------- #
# (2) task_metadata
# --------------------------------------------------------------------------- #

def check_task_metadata(task_path: Path) -> dict:
    t0 = time.monotonic()
    toml_path = task_path / "task.toml"
    if not toml_path.exists():
        return _result(
            passed=False, severity="error",
            summary="task.toml not found",
            details={"issues": ["task.toml not found"]},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )
    try:
        data = load_toml(toml_path)
    except Exception as e:
        return _result(
            passed=False, severity="error",
            summary=f"task.toml parse error: {e}",
            details={"issues": [f"parse error: {e}"]},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )

    issues: list[str] = []

    version = data.get("version")
    if not isinstance(version, str) or not version.strip():
        issues.append("top-level `version` missing or not a string")

    meta = data.get("metadata") or {}
    if not isinstance(meta, dict):
        issues.append("[metadata] section missing or wrong type")
        meta = {}
    for key in ("author_name", "author_email", "difficulty", "category"):
        v = meta.get(key)
        if not isinstance(v, str) or not v.strip():
            issues.append(f"[metadata].{key} missing or not a non-empty string")
    diff = meta.get("difficulty")
    if isinstance(diff, str) and diff not in ALLOWED_DIFFICULTIES:
        issues.append(
            f"[metadata].difficulty is '{diff}', expected one of {sorted(ALLOWED_DIFFICULTIES)}"
        )
    tags = meta.get("tags")
    if not isinstance(tags, list) or not all(isinstance(t, str) for t in tags):
        issues.append("[metadata].tags missing or not a list[str]")

    verifier = data.get("verifier") or {}
    v_timeout = verifier.get("timeout_sec") if isinstance(verifier, dict) else None
    if not isinstance(v_timeout, (int, float)) or v_timeout <= 0:
        issues.append("[verifier].timeout_sec missing or not a positive number")

    agent = data.get("agent") or {}
    a_timeout = agent.get("timeout_sec") if isinstance(agent, dict) else None
    if not isinstance(a_timeout, (int, float)) or a_timeout <= 0:
        issues.append("[agent].timeout_sec missing or not a positive number")

    env = data.get("environment") or {}
    docker_image = env.get("docker_image") if isinstance(env, dict) else None
    if not isinstance(docker_image, str) or not docker_image.strip():
        issues.append("[environment].docker_image missing or not a non-empty string")

    elapsed = int((time.monotonic() - t0) * 1000)
    extracted = {
        "version": version if isinstance(version, str) else None,
        "author_name": meta.get("author_name") if isinstance(meta.get("author_name"), str) else None,
        "author_email": meta.get("author_email") if isinstance(meta.get("author_email"), str) else None,
        "difficulty": meta.get("difficulty") if isinstance(meta.get("difficulty"), str) else None,
        "category": meta.get("category") if isinstance(meta.get("category"), str) else None,
        "tags": tags if isinstance(tags, list) else [],
        "verifier_timeout_sec": v_timeout if isinstance(v_timeout, (int, float)) else None,
        "agent_timeout_sec": a_timeout if isinstance(a_timeout, (int, float)) else None,
        "docker_image": docker_image if isinstance(docker_image, str) else None,
    }
    if issues:
        return _result(
            passed=False, severity="error",
            summary=f"task.toml: {len(issues)} issue(s)",
            details={"metadata": extracted, "issues": issues},
            duration_ms=elapsed,
        )
    return _result(
        passed=True, severity="info",
        summary=f"task.toml valid (v{version}, {meta.get('difficulty')})",
        details={"metadata": extracted, "issues": []},
        duration_ms=elapsed,
    )


# --------------------------------------------------------------------------- #
# (3) canary_present
# --------------------------------------------------------------------------- #

def check_canary(task_path: Path) -> dict:
    t0 = time.monotonic()
    toml_path = task_path / "task.toml"
    if not toml_path.exists():
        return _result(
            passed=False, severity="error",
            summary="task.toml not found",
            details={"guid": None},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )
    try:
        contents = toml_path.read_text(errors="replace")
    except OSError as e:
        return _result(
            passed=False, severity="error",
            summary=f"could not read task.toml: {e}",
            details={"guid": None},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )
    m = CANARY_RE.search(contents)
    elapsed = int((time.monotonic() - t0) * 1000)
    if not m:
        return _result(
            passed=False, severity="error",
            summary="canary string missing from task.toml",
            details={"guid": None},
            duration_ms=elapsed,
        )
    return _result(
        passed=True, severity="info",
        summary="canary GUID present",
        details={"guid": m.group(1)},
        duration_ms=elapsed,
    )


# --------------------------------------------------------------------------- #
# (4)+(5) oracle_run / nop_run — shared logic
# --------------------------------------------------------------------------- #

def check_oracle_run(task_path: Path, *, rerun: bool = False) -> dict:
    return _run_check(task_path, agent="oracle", expected_reward=1.0, rerun=rerun)


def check_nop_run(task_path: Path, *, rerun: bool = False) -> dict:
    return _run_check(task_path, agent="nop", expected_reward=0.0, rerun=rerun)


def _run_check(task_path: Path, *, agent: str, expected_reward: float, rerun: bool) -> dict:
    t0 = time.monotonic()
    rerun_log_tail: Optional[str] = None
    rerun_rc: Optional[int] = None

    if rerun:
        rerun_rc, log = _run_harbor(task_path, agent)
        rerun_log_tail = (log or "")[-2000:]
        if rerun_rc != 0:
            return _result(
                passed=False, severity="error",
                summary=f"`harbor run --agent {agent}` failed (rc={rerun_rc})",
                details={
                    "agent": agent,
                    "rerun": True,
                    "rerun_rc": rerun_rc,
                    "rerun_log_tail": rerun_log_tail,
                },
                duration_ms=int((time.monotonic() - t0) * 1000),
            )

    jobs_dir = task_path / "jobs"
    if not jobs_dir.exists() or not any(jobs_dir.iterdir()):
        elapsed = int((time.monotonic() - t0) * 1000)
        if rerun:
            return _result(
                passed=False, severity="error",
                summary=f"harbor ran but no jobs/ output found",
                details={"agent": agent, "rerun": True, "rerun_log_tail": rerun_log_tail},
                duration_ms=elapsed,
            )
        return _skipped(
            f"no jobs/ directory yet — run `harbor run --agent {agent}` first or use --rerun-{agent}",
            duration_ms=elapsed,
        )

    found = _find_run_for_agent(jobs_dir, agent)
    if found is None:
        elapsed = int((time.monotonic() - t0) * 1000)
        return _skipped(
            f"no {agent} run found in jobs/ — try --rerun-{agent}",
            duration_ms=elapsed,
            details={"agent": agent},
        )

    run_path, result_data = found
    reward = _find_reward(result_data)
    elapsed = int((time.monotonic() - t0) * 1000)
    if reward is None:
        return _result(
            passed=False, severity="error",
            summary=f"{agent} run found but no `reward` in result",
            details={
                "agent": agent,
                "run_path": str(run_path),
                "rerun": rerun,
                "raw_result_keys": _shallow_keys(result_data),
            },
            duration_ms=elapsed,
        )

    passed = reward == expected_reward

    details: dict[str, Any] = {
        "agent": agent,
        "run_path": str(run_path),
        "reward": reward,
        "expected_reward": expected_reward,
        "rerun": rerun,
    }
    for k in ("trial_name", "started_at", "finished_at", "task_checksum"):
        v = result_data.get(k)
        if isinstance(v, (str, int, float)):
            details[k] = v
    exc = result_data.get("exception_info")
    if exc:
        details["exception_info"] = exc

    test_summary: Optional[dict] = None
    verifier_stdout = run_path / "verifier" / "test-stdout.txt"
    if verifier_stdout.is_file():
        details["verifier_output_path"] = str(verifier_stdout)
        try:
            text = verifier_stdout.read_text(errors="replace")
            details["verifier_output_tail"] = text[-1500:]
            test_summary = _parse_pytest_summary(text)
            if test_summary:
                details["test_summary"] = test_summary
        except OSError:
            pass

    if agent == "oracle":
        if passed:
            summary = f"oracle reward {reward}{_format_test_counts(test_summary)}"
        else:
            summary = (
                f"oracle reward {reward} (expected 1.0)"
                f"{_format_test_counts(test_summary)} — verifier may be too strict"
            )
    else:
        if passed:
            summary = (
                f"NOP correctly failed (reward 0.0)"
                f"{_format_test_counts(test_summary)}"
            )
        else:
            summary = (
                f"NOP unexpectedly returned reward {reward}"
                f"{_format_test_counts(test_summary)} — tests may be trivially passing"
            )
    trial_log = run_path / "trial.log"
    if trial_log.is_file():
        details["trial_log_path"] = str(trial_log)
    logs_dir = run_path / "logs"
    if logs_dir.exists():
        details["logs_path"] = str(logs_dir)

    if rerun_log_tail:
        details["rerun_log_tail"] = rerun_log_tail
    if rerun_rc is not None:
        details["rerun_rc"] = rerun_rc

    return _result(
        passed=passed,
        severity="info" if passed else "error",
        summary=summary,
        score=reward,
        details=details,
        duration_ms=elapsed,
    )


def _run_harbor(task_path: Path, agent: str) -> tuple[int, str]:
    cmd = ["harbor", "run", "--path", str(task_path), "--agent", agent]
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=HARBOR_TIMEOUT_SEC
        )
    except FileNotFoundError:
        return 127, "`harbor` not found on PATH"
    except subprocess.TimeoutExpired:
        return 124, f"harbor run timed out after {HARBOR_TIMEOUT_SEC}s"
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def _find_run_for_agent(
    jobs_dir: Path, agent: str
) -> Optional[tuple[Path, dict]]:
    """Walk jobs/ newest-first; return the most recent trial whose agent matches.

    Harbor layout (current):
      jobs/<timestamp>/<trial>/result.json
        with `agent_info.name` = "oracle" | "nop"
        and  `verifier_result.rewards.reward` = 1.0 | 0.0

    Legacy fallbacks (old/alt layouts) are tried only if the Harbor layout
    doesn't yield a match for that run.
    """
    target = agent.lower()
    try:
        runs = sorted(
            (d for d in jobs_dir.iterdir() if d.is_dir() and not d.name.startswith(".")),
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return None

    for run in runs:
        try:
            trials = sorted(
                (d for d in run.iterdir() if d.is_dir() and not d.name.startswith(".")),
                key=lambda d: d.stat().st_mtime,
                reverse=True,
            )
        except OSError:
            trials = []
        for trial in trials:
            tr_result = trial / "result.json"
            if not tr_result.is_file():
                continue
            try:
                data = json.loads(tr_result.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            if _extract_agent_name(data) == target:
                return trial, data

        per_agent = run / "results" / f"{agent}.json"
        if per_agent.is_file():
            try:
                return run, json.loads(per_agent.read_text())
            except (OSError, json.JSONDecodeError):
                pass
        single = run / "result.json"
        if single.is_file():
            try:
                data = json.loads(single.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            run_agent = str(data.get("agent") or "").lower()
            if run_agent == target:
                return run, data
    return None


def _extract_agent_name(data: dict) -> str:
    agent_info = data.get("agent_info")
    if isinstance(agent_info, dict):
        n = agent_info.get("name")
        if isinstance(n, str):
            return n.lower()
    config = data.get("config")
    if isinstance(config, dict):
        a = config.get("agent")
        if isinstance(a, dict):
            n = a.get("name")
            if isinstance(n, str):
                return n.lower()
    return ""


def _find_reward(d: Any) -> Optional[float]:
    if isinstance(d, dict):
        if "reward" in d and isinstance(d["reward"], (int, float)) and not isinstance(d["reward"], bool):
            return float(d["reward"])
        for v in d.values():
            r = _find_reward(v)
            if r is not None:
                return r
    elif isinstance(d, list):
        for v in d:
            r = _find_reward(v)
            if r is not None:
                return r
    return None


def _find_first_key(d: Any, key: str) -> Any:
    if isinstance(d, dict):
        if key in d:
            return d[key]
        for v in d.values():
            r = _find_first_key(v, key)
            if r is not None:
                return r
    elif isinstance(d, list):
        for v in d:
            r = _find_first_key(v, key)
            if r is not None:
                return r
    return None


def _shallow_keys(d: Any) -> list[str]:
    if isinstance(d, dict):
        return list(d.keys())[:20]
    return []


PYTEST_SUMMARY_RE = re.compile(
    r"^=+\s+(.+?)\s+in\s+([\d.]+)s\s+=+\s*$",
    re.MULTILINE,
)
PYTEST_COUNT_RE = re.compile(
    r"(\d+)\s+(passed|failed|skipped|errors?|warnings?|xfailed|xpassed|deselected)"
)


def _parse_pytest_summary(text: str) -> Optional[dict]:
    """Extract pytest's final summary line.

    Matches lines like:
        ============= 13 passed in 0.04s =============
        ===== 1 failed, 12 passed in 0.5s =====

    Returns {passed, failed, ..., duration_sec} or None if no match.
    """
    matches = list(PYTEST_SUMMARY_RE.finditer(text))
    if not matches:
        return None
    last = matches[-1]
    body = last.group(1)
    duration_sec = float(last.group(2))
    out: dict[str, Any] = {"duration_sec": duration_sec}
    for cm in PYTEST_COUNT_RE.finditer(body):
        n = int(cm.group(1))
        status = cm.group(2).rstrip("s")  # "errors" -> "error", "warnings" -> "warning"
        out[status] = n
    return out if len(out) > 1 else None  # need at least one count besides duration


def _format_test_counts(summary: Optional[dict]) -> str:
    """Render parsed pytest summary as ' — 13 passed (0.04s)' or '' if unavailable."""
    if not summary:
        return ""
    parts: list[str] = []
    for k in ("passed", "failed", "error", "skipped"):
        n = summary.get(k)
        if n:
            parts.append(f"{n} {k}")
    if not parts:
        return ""
    dur = summary.get("duration_sec")
    dur_s = f" ({dur}s)" if isinstance(dur, (int, float)) else ""
    return f" — {', '.join(parts)}{dur_s}"


# --------------------------------------------------------------------------- #
# (6)(7)(8) LLM judge checks
# --------------------------------------------------------------------------- #

INSTRUCTION_BALANCE_SYSTEM = """You are a Terminal-Bench task QA reviewer. Evaluate the supplied
`instruction.md` against this rule taxonomy:

OVERCONTEXT (BAD): step-by-step instructions, code snippets, example commands,
explanations of edge cases, hints how to solve.
UNDERCONTEXT (BAD): too vague, missing exact filenames/paths, unclear goal,
omits hard constraints (no internet, no installs, etc.).
BALANCED (GOOD): single clear goal sentence, exact file paths to read/write,
hard constraints stated, no solution hints.

Reply with JSON only, this exact shape:
{
  "verdict": "pass" | "warn" | "fail",
  "score": 0-100,
  "category": "overcontext" | "undercontext" | "balanced",
  "issues": [{"line_number": int, "issue": "string"}],
  "summary": "one sentence"
}"""

HINT_LEAKAGE_SYSTEM = """You are a Terminal-Bench task QA reviewer. The task author MUST NOT leak hints
about how to solve the task in `instruction.md`. Specifically check for:

- Step-by-step instructions ("first do X, then Y")
- Example commands or shell snippets
- Mentions of specific functions / algorithms / library APIs to use
- Edge cases or error conditions the agent should watch for
- Pseudocode or partial code

NOTE: Do NOT examine `solution/solve.sh`. That file is the reference solution
used by Harbor's oracle agent to prove the task is solvable — it is supposed
to contain a full working solution. Hint leakage is exclusively a property of
the task description (instruction.md).

Reply with JSON only:
{
  "verdict": "pass" | "warn" | "fail",
  "score": 0-100,
  "instruction_issues": [{"line_number": int, "issue": "string"}],
  "summary": "one sentence"
}"""

TEST_STRICTNESS_SYSTEM = """You are a Terminal-Bench task QA reviewer. The task's tests must enforce STRICT
correctness with no tolerance, no partial credit, and no human-readable output.
Specifically check:

In `tests/test_outputs.py`:
- Strict equality (`==`) not heuristic comparison
- Format / order / spacing / data type checks
- No `print("PASS")` or human-readable success messages
- No partial credit / scoring logic
- No tolerance like `assert abs(a - b) < 0.1` unless task explicitly allows it

In `tests/test.sh`:
- Single fail-fast entry point (`set -e`)
- Writes 1 to /logs/verifier/reward.txt on full pass, 0 otherwise
- No manual inspection logic, no echo "Looks correct"

Reply with JSON only:
{
  "verdict": "pass" | "warn" | "fail",
  "score": 0-100,
  "test_outputs_issues": [{"line_number": int, "issue": "string"}],
  "test_sh_issues":      [{"line_number": int, "issue": "string"}],
  "summary": "one sentence"
}"""


def check_instruction_balance(task_path: Path, nim_key: Optional[str]) -> dict:
    return _llm_check(
        nim_key,
        files=[task_path / "instruction.md"],
        system=INSTRUCTION_BALANCE_SYSTEM,
        user_builder=lambda contents: contents[0],
        extract_details=lambda r: {
            "category": r.get("category"),
            "issues": r.get("issues") or [],
        },
    )


def check_hint_leakage(task_path: Path, nim_key: Optional[str]) -> dict:
    return _llm_check(
        nim_key,
        files=[task_path / "instruction.md"],
        system=HINT_LEAKAGE_SYSTEM,
        user_builder=lambda contents: contents[0],
        extract_details=lambda r: {
            "instruction_issues": r.get("instruction_issues") or [],
        },
    )


def check_test_strictness(task_path: Path, nim_key: Optional[str]) -> dict:
    return _llm_check(
        nim_key,
        files=[task_path / "tests" / "test_outputs.py", task_path / "tests" / "test.sh"],
        system=TEST_STRICTNESS_SYSTEM,
        user_builder=lambda contents: (
            f"=== tests/test_outputs.py ===\n{contents[0]}\n\n"
            f"=== tests/test.sh ===\n{contents[1]}"
        ),
        extract_details=lambda r: {
            "test_outputs_issues": r.get("test_outputs_issues") or [],
            "test_sh_issues": r.get("test_sh_issues") or [],
        },
    )


# --------------------------------------------------------------------------- #
# (9) gptzero_check — MOCK (no API key wired up yet)
# --------------------------------------------------------------------------- #

def check_gptzero(task_path: Path) -> dict:
    """Mock GPTZero AI-detection on instruction.md.

    Real implementation will POST instruction.md text to
    https://api.gptzero.me/v2/predict/text with a Bearer key. Until that's
    wired up, this returns *deterministic* fake numbers seeded by the file's
    SHA-256 — same file always yields the same verdict, different files
    visibly differ. The `fake_mode: True` flag in details makes it obvious
    this isn't a real API call.

    To make this real later: replace the seeded RNG block with an HTTP call,
    keep the rest of the result-shaping unchanged.
    """
    t0 = time.monotonic()
    instr = task_path / "instruction.md"
    if not instr.exists():
        return _result(
            passed=False, severity="error",
            summary="instruction.md not found",
            details={"file_analyzed": "instruction.md", "error": "missing"},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )
    try:
        text = instr.read_text(errors="replace")
    except OSError as e:
        return _result(
            passed=False, severity="error",
            summary=f"could not read instruction.md: {e}",
            details={"error": str(e)},
            duration_ms=int((time.monotonic() - t0) * 1000),
        )

    seed = int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:8], 16)
    rng = random.Random(seed)
    ai_probability = round(rng.uniform(5.0, 38.0), 1)
    perplexity = round(rng.uniform(48.0, 130.0), 1)
    burstiness = round(rng.uniform(0.20, 0.90), 2)

    if ai_probability < 25:
        classification, verdict_phrase = "human", "likely human-authored"
    elif ai_probability < 50:
        classification, verdict_phrase = "mixed", "mixed signals"
    elif ai_probability < 75:
        classification, verdict_phrase = "ai_likely", "likely AI-generated"
    else:
        classification, verdict_phrase = "ai", "very likely AI-generated"

    threshold = 50.0
    passed = ai_probability < threshold
    if ai_probability < 25:
        severity = "info"
    elif ai_probability < threshold:
        severity = "warn"
    elif ai_probability < 75:
        severity = "warn"
        passed = False
    else:
        severity = "error"
        passed = False

    summary = f"GPTZero (mock): {ai_probability}% AI probability — {verdict_phrase}"

    return _result(
        passed=passed,
        severity=severity,
        summary=summary,
        score=round(100.0 - ai_probability, 1),
        details={
            "fake_mode": True,
            "fake_mode_note": (
                "Mock response — no GPTZero API key wired up. Replace "
                "checks.check_gptzero() body with a real api.gptzero.me call "
                "when a key is available."
            ),
            "file_analyzed": "instruction.md",
            "char_count": len(text),
            "ai_probability": ai_probability,
            "human_probability": round(100.0 - ai_probability, 1),
            "classification": classification,
            "threshold": threshold,
            "metrics": {
                "perplexity": perplexity,
                "burstiness": burstiness,
            },
        },
        duration_ms=int((time.monotonic() - t0) * 1000),
    )


def _llm_check(
    nim_key: Optional[str],
    *,
    files: list[Path],
    system: str,
    user_builder: Callable[[list[str]], str],
    extract_details: Callable[[dict], dict],
) -> dict:
    t0 = time.monotonic()
    if not nim_key:
        return _skipped(
            "no NIM key configured (set via env NIM_API_KEY or `opslabel config set-nim-key`)",
            duration_ms=int((time.monotonic() - t0) * 1000),
        )
    contents: list[str] = []
    missing: list[str] = []
    for f in files:
        if not f.exists():
            missing.append(str(f.name))
            contents.append("")
            continue
        try:
            contents.append(f.read_text(errors="replace"))
        except OSError as e:
            return _result(
                passed=False, severity="error",
                summary=f"could not read {f.name}: {e}",
                details={"error": str(e), "file": str(f)},
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
    if missing:
        return _skipped(
            f"required file(s) missing: {', '.join(missing)} (skeleton check covers this)",
            duration_ms=int((time.monotonic() - t0) * 1000),
        )

    user_text = user_builder(contents)

    try:
        response = nim.chat_complete(nim_key, system=system, user=user_text)
    except nim.NIMError as e:
        return _skipped(
            f"NIM call failed: {e}",
            duration_ms=int((time.monotonic() - t0) * 1000),
        )

    verdict = str(response.get("verdict") or "").lower()
    passed, severity = _verdict_to_status(verdict)
    summary = str(response.get("summary") or f"verdict={verdict or 'unknown'}")
    score = response.get("score")
    if not isinstance(score, (int, float)):
        score = None

    details = {"verdict": verdict, **extract_details(response)}
    return _result(
        passed=passed,
        severity=severity,
        summary=summary,
        score=float(score) if score is not None else None,
        details=details,
        duration_ms=int((time.monotonic() - t0) * 1000),
    )
