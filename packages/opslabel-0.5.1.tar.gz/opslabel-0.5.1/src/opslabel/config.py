import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, TypedDict

CONFIG_DIR = Path.home() / ".opslabel"
CONFIG_FILE = CONFIG_DIR / "config.json"
LAST_REPORT_FILE = CONFIG_DIR / "last-report.json"

# CLI sessions auto-expire after this duration. Mirrors the Firestore rule
# on cliSessions which requires `expiresAt is timestamp`. Keep these in sync.
SESSION_LIFETIME_HOURS = 12


class _Required(TypedDict):
    contributorUid: str
    projectId: str
    anonUid: str
    refreshToken: str


class Config(_Required, total=False):
    nimApiKey: str
    pairingId: str
    expiresAt: str   # ISO-8601 UTC string


def load() -> Optional[Config]:
    if not CONFIG_FILE.exists():
        return None
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def save(cfg: Config) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except OSError:
        pass


def update(patch: dict) -> Config:
    """Merge `patch` into the existing config and persist. Returns the new config."""
    existing = load() or {}
    merged: Config = {**existing, **patch}  # type: ignore[typeddict-item]
    save(merged)
    return merged


def is_paired(cfg: Optional[Config]) -> bool:
    """True if the config has all four pairing fields populated."""
    if not cfg:
        return False
    return all(cfg.get(k) for k in ("contributorUid", "projectId", "anonUid", "refreshToken"))


def session_expired(cfg: Optional[Config]) -> bool:
    """True if the local config's `expiresAt` is in the past (or missing/malformed).

    Pre-0.5.0 configs don't have `expiresAt` — those are treated as expired so
    the user gets a clean re-pair prompt rather than a permission-denied error
    from Firestore.
    """
    if not cfg:
        return True
    raw = cfg.get("expiresAt")
    if not raw:
        return True
    try:
        exp = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return True
    return datetime.now(timezone.utc) >= exp


def session_remaining_str(cfg: Optional[Config]) -> Optional[str]:
    """Return a human-readable 'Xh Ym' string for the remaining session time,
    or None if no valid expiresAt is set."""
    if not cfg:
        return None
    raw = cfg.get("expiresAt")
    if not raw:
        return None
    try:
        exp = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    delta = exp - datetime.now(timezone.utc)
    secs = int(delta.total_seconds())
    if secs <= 0:
        return "expired"
    h, rem = divmod(secs, 3600)
    m, _ = divmod(rem, 60)
    if h > 0:
        return f"{h}h {m}m"
    return f"{m}m"


def get_nim_key(cfg: Optional[Config]) -> Optional[str]:
    """Resolve NIM API key. Env var wins over config file."""
    env_key = os.environ.get("NIM_API_KEY")
    if env_key:
        return env_key
    if cfg and cfg.get("nimApiKey"):
        return cfg["nimApiKey"]
    return None


def save_last_report(data: dict) -> None:
    """Cache the most recent uploaded scan report locally so that
    `opslabel request-review` (run later) can pick it up. The CLI's anon UID
    can't read /qaReports back via security rules, so the cache is the only
    way to keep the payload around between commands."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    LAST_REPORT_FILE.write_text(json.dumps(data, indent=2, default=str))
    try:
        os.chmod(LAST_REPORT_FILE, 0o600)
    except OSError:
        pass


def load_last_report() -> Optional[dict]:
    if not LAST_REPORT_FILE.exists():
        return None
    try:
        return json.loads(LAST_REPORT_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def mask_secret(s: Optional[str]) -> str:
    """Mask credentials for display: first 6 chars then `…`."""
    if not s:
        return "<not set>"
    if len(s) <= 6:
        return "*" * len(s)
    return f"{s[:6]}…"
