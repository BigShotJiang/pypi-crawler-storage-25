from __future__ import annotations

import atexit
import json
import socket
import sys
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterator, Optional

import requests
import typer
from rich.console import Console

from . import __version__
from . import config as config_mod
from . import firebase
from . import scan as scan_mod
from .banner import (
    finish_banner,
    install_banner_wrapper,
    is_active as banner_active,
    is_exhausted as banner_exhausted,
)

app = typer.Typer(
    help="OpsLabel QA CLI",
    no_args_is_help=True,
    add_completion=False,
)
config_app = typer.Typer(
    help="Manage local CLI config (NIM key, view stored values).",
    no_args_is_help=True,
)
app.add_typer(config_app, name="config")


# --------------------------------------------------------------------------- #
# Root callback (--version)
# --------------------------------------------------------------------------- #

def _version_callback(value: bool) -> None:
    if value:
        # No banner for --version (no header context to fill the right column).
        typer.echo(f"opslabel {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """OpsLabel QA CLI."""
    if install_banner_wrapper() is not None:
        atexit.register(finish_banner)


def _require_active_session(console_or_none: Optional[Console] = None) -> dict:
    """Read config, ensure paired AND session not expired. Exit cleanly otherwise.
    Returns the loaded config on success."""
    cfg = config_mod.load()
    if not config_mod.is_paired(cfg):
        msg = (
            "Not authenticated. Run `opslabel auth <code>` first "
            "(generate a code on the dashboard)."
        )
        if console_or_none is not None:
            console_or_none.print(f"[red]{msg}[/red]")
        else:
            typer.secho(msg, fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    if config_mod.session_expired(cfg):
        msg = (
            "Your CLI session has expired. Re-pair with "
            "`opslabel auth <new-code>` from the dashboard."
        )
        if console_or_none is not None:
            console_or_none.print(f"[red]{msg}[/red]")
        else:
            typer.secho(msg, fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    assert cfg is not None
    return cfg


def _open_authenticated_session(console: Console) -> tuple[dict, str]:
    """Run the full session-validity gate up-front: local checks, token
    refresh, AND server-side cliSessions doc lookup. Exits cleanly with the
    re-pair message on any failure.

    Returns (cfg, id_token). Use this at the start of any command that hits
    Firestore so the user sees a clear "session expired/revoked" message
    BEFORE any expensive work runs (e.g. multi-minute LLM checks).
    """
    cfg = _require_active_session(console)

    try:
        with _maybe_status(console, "[cyan]checking session…[/cyan]"):
            refreshed = firebase.refresh_id_token(cfg["refreshToken"])
            id_token = refreshed["id_token"]
            new_refresh = refreshed.get("refresh_token", cfg["refreshToken"])
            returned_uid = refreshed.get("user_id")
            if returned_uid and returned_uid != cfg["anonUid"]:
                _print_stale_session(console)
                raise typer.Exit(1)
            if new_refresh != cfg["refreshToken"]:
                cfg = config_mod.update({"refreshToken": new_refresh})

            session_doc = firebase.get_cli_session(id_token, cfg["anonUid"])
            if session_doc is None:
                _print_stale_session(console)
                raise typer.Exit(1)
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
        else:
            console.print(f"[red]Session check failed: {e}[/red]")
        raise typer.Exit(1) from e
    except requests.RequestException as e:
        console.print(f"[red]Network error during session check: {e}[/red]")
        raise typer.Exit(1) from e

    return cfg, id_token


@contextmanager
def _maybe_status(console: Console, message: str) -> Iterator[Optional[object]]:
    """Yield a rich spinner-status when it's safe — i.e. either the banner
    isn't active, or the banner art is fully drawn. Inside the banner zone,
    yield None so callers can fall back to printing without a spinner."""
    if banner_active() and not banner_exhausted():
        yield None
    else:
        with console.status(message, spinner="dots") as status:
            yield status


# --------------------------------------------------------------------------- #
# auth (Phase 1, unchanged behavior)
# --------------------------------------------------------------------------- #

@app.command()
def auth(
    code: str = typer.Argument(
        ..., help="The 8-character pairing code shown on opslabel.in"
    ),
) -> None:
    """Pair this machine with your OpsLabel contributor account."""
    code = code.strip().upper()
    if len(code) != 8:
        typer.secho(
            f"Pairing codes are 8 characters; got {len(code)}.",
            fg=typer.colors.RED, err=True,
        )
        raise typer.Exit(1)

    try:
        typer.echo("Syncing with OpsLabel…")
        auth_data = firebase.sign_up_anonymous()
        id_token = auth_data["idToken"]
        refresh_token = auth_data["refreshToken"]
        anon_uid = auth_data["localId"]

        typer.echo("Looking up pairing code…")
        pairing = firebase.query_pairing_by_code(id_token, code)
        if pairing is None:
            typer.secho(
                f"No pairing found for code {code}. Generate a fresh code on opslabel.in.",
                fg=typer.colors.RED, err=True,
            )
            raise typer.Exit(1)

        data = pairing["data"]
        if data.get("used"):
            typer.secho(
                f"Pairing code {code} has already been used. Generate a fresh code on opslabel.in.",
                fg=typer.colors.RED, err=True,
            )
            raise typer.Exit(1)

        expires_at = data.get("expiresAt")
        if isinstance(expires_at, str):
            try:
                exp = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                if datetime.now(timezone.utc) > exp:
                    typer.secho(
                        f"Pairing code {code} expired. Generate a fresh code on opslabel.in.",
                        fg=typer.colors.RED, err=True,
                    )
                    raise typer.Exit(1)
            except ValueError:
                pass

        contributor_uid = data["contributorUid"]
        project_id = data["projectId"]
        hostname = socket.gethostname()

        typer.echo("Claiming pairing…")
        firebase.update_pairing(
            id_token,
            pairing["name"],
            {
                "used": True,
                "cliMachineUid": anon_uid,
                "cliMachineName": hostname,
                "cliPairedAt": datetime.now(timezone.utc),
            },
        )

        # Register the CLI session so Firestore rules can resolve
        # anonUid → contributorUid securely (via get(/cliSessions/{anonUid}))
        # for downstream pods reads and reviewRequests writes.
        typer.echo("Registering CLI session…")
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(hours=config_mod.SESSION_LIFETIME_HOURS)
        firebase.create_cli_session(
            id_token,
            anon_uid,
            {
                "contributorUid": contributor_uid,
                "projectId": project_id,
                "pairingId": pairing["id"],
                "pairedAt": now,
                "expiresAt": expires_at,
            },
        )

        config_mod.update(
            {
                "contributorUid": contributor_uid,
                "projectId": project_id,
                "anonUid": anon_uid,
                "refreshToken": refresh_token,
                "pairingId": pairing["id"],
                "expiresAt": expires_at.isoformat().replace("+00:00", "Z"),
            }
        )
    except firebase.FirebaseError as e:
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except requests.RequestException as e:
        typer.secho(f"Network error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e

    typer.secho(f"✓ Paired as {hostname}.", fg=typer.colors.GREEN)
    typer.echo(f"  Session valid for {config_mod.SESSION_LIFETIME_HOURS}h")
    typer.echo(f"  Config: {config_mod.CONFIG_FILE}")
    typer.echo("Set a NIM key for LLM checks: `opslabel config set-nim-key <KEY>`")
    typer.echo("Then `opslabel scan` from a TB task folder to send your first report.")


# --------------------------------------------------------------------------- #
# scan
# --------------------------------------------------------------------------- #

@app.command()
def scan(
    path: Optional[Path] = typer.Argument(
        None, help="Path to TB task root (defaults to cwd).",
    ),
    rerun_oracle: bool = typer.Option(
        False, "--rerun-oracle",
        help="Run `harbor run --agent oracle` instead of parsing existing jobs/.",
    ),
    rerun_nop: bool = typer.Option(
        False, "--rerun-nop",
        help="Run `harbor run --agent nop` instead of parsing existing jobs/.",
    ),
    skip_llm: bool = typer.Option(
        False, "--skip-llm",
        help="Skip LLM-judge checks even if a NIM key is configured.",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Print the report to stdout, do not upload.",
    ),
    task_name_override: Optional[str] = typer.Option(
        None, "--task-name",
        help="Override the task name used when matching the dashboard's "
             "taskSubmissions doc. Defaults to the task folder basename.",
    ),
) -> None:
    """Run QA on a Terminal-Bench task and upload the report.

    Once a report has been uploaded, run `opslabel request-review` separately
    to send it to your pod lead — that command picks up the just-uploaded
    report from the local cache.
    """
    task_path = (path or Path.cwd()).resolve()
    task_name = task_name_override or task_path.name
    if not task_path.exists():
        typer.secho(f"Path does not exist: {task_path}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    if not (task_path / "task.toml").exists():
        typer.secho(
            f"{task_path} is not a TB task (no task.toml at root).",
            fg=typer.colors.RED, err=True,
        )
        raise typer.Exit(1)

    # We need a Console for the upfront server-side session check (so it can
    # render the spinner/error in the same style as the rest of the run).
    early_console = Console(stderr=True)
    id_token: Optional[str] = None
    if dry_run:
        cfg = config_mod.load()
    else:
        # Fail fast: validate the session BEFORE running expensive checks.
        # This catches dashboard-side disconnects before LLM checks waste time.
        cfg, id_token = _open_authenticated_session(early_console)

    nim_key = config_mod.get_nim_key(cfg)
    if not skip_llm and not nim_key:
        typer.secho(
            "Note: no NIM key configured — LLM-judge checks will be skipped. "
            "Set with `opslabel config set-nim-key <KEY>` or env NIM_API_KEY.",
            fg=typer.colors.YELLOW, err=True,
        )

    console = Console(stderr=True)
    console.print(f"[bold]Scanning[/bold] {task_path}…")

    # Manage the rich Status manually rather than via _maybe_status: scan
    # often crosses the banner-exhausted boundary mid-run (early static
    # checks fall in the banner zone, slow LLM checks come later). We start
    # the spinner lazily on the first "start" event after the banner art
    # finishes drawing.
    active_status: Optional[object] = None

    def on_progress(name: str, event: str, result: Optional[dict]) -> None:
        nonlocal active_status
        if event == "start":
            if banner_exhausted():
                if active_status is None:
                    active_status = console.status(
                        f"[cyan]{name}…[/cyan]", spinner="dots"
                    )
                    active_status.start()  # type: ignore[attr-defined]
                else:
                    active_status.update(  # type: ignore[attr-defined]
                        f"[cyan]{name}…[/cyan]"
                    )
        elif event == "done" and result is not None:
            if active_status is not None:
                active_status.stop()  # type: ignore[attr-defined]
                active_status = None
            console.print(_format_check_line(name, result))

    try:
        report = scan_mod.run_scan(
            task_path,
            rerun_oracle=rerun_oracle,
            rerun_nop=rerun_nop,
            skip_llm=skip_llm,
            nim_key=nim_key,
            on_progress=on_progress,
            task_name=task_name,
        )
    finally:
        if active_status is not None:
            active_status.stop()  # type: ignore[attr-defined]
            active_status = None

    _print_verdict(console, report)

    if dry_run:
        console.print("\n[dim]--- report (dry-run, not uploaded) ---[/dim]")
        sys.stdout.write(json.dumps(report, indent=2, default=str) + "\n")
        return

    assert cfg is not None  # not dry_run path
    assert id_token is not None  # set by _open_authenticated_session above
    # Re-load cfg in case _open_authenticated_session rotated the refresh token.
    cfg = config_mod.load() or cfg
    try:
        with _maybe_status(console, "[cyan]uploading report…[/cyan]"):
            fields = {
                "contributorUid": cfg["contributorUid"],
                "projectId": cfg["projectId"],
                "cliMachineUid": cfg["anonUid"],
                "cliMachineName": socket.gethostname(),
                "cliVersion": __version__,
                "scanType": "tb-task-qa",
                "payload": report,
                "createdAt": datetime.now(timezone.utc),
            }
            name = firebase.create_qa_report(id_token, fields)
            report_id = name.rsplit("/", 1)[-1]
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
            raise typer.Exit(1) from e
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e
    except requests.RequestException as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1) from e

    console.print(f"\n[green]✓ Uploaded as {report_id}[/green]")

    # Link this scan to the dashboard's taskSubmissions doc so the
    # progress bar (25% / 50% / ...) advances. The dashboard creates the
    # doc when the contributor clicks "Create New Task"; the CLI matches
    # by contributor + project + taskName + open stage.
    try:
        with _maybe_status(console, "[cyan]linking to dashboard task…[/cyan]"):
            ts = firebase.find_task_submission(
                id_token, cfg["contributorUid"], cfg["projectId"], task_name
            )
        if ts is None:
            console.print(
                f"\n[red]No open task '{task_name}' found in your "
                "OpsLabel dashboard.[/red]"
            )
            console.print(
                "Open the project's Tasking tab on opslabel.in/app, click "
                "[bold]Create New Task[/bold], enter the task name "
                f"[bold]{task_name}[/bold] (case-sensitive), then re-run "
                "[bold]opslabel scan[/bold]."
            )
            raise typer.Exit(1)
        with _maybe_status(console, "[cyan]updating task progress…[/cyan]"):
            firebase.update_task_submission(
                id_token,
                ts["name"],
                {
                    "qaReportId": report_id,
                    "stage": "scanned",
                    "updatedAt": datetime.now(timezone.utc),
                },
            )
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
            raise typer.Exit(1) from e
        console.print(f"[red]Failed to link to dashboard task: {e}[/red]")
        raise typer.Exit(1) from e
    except requests.RequestException as e:
        console.print(f"[red]Network error during task link: {e}[/red]")
        raise typer.Exit(1) from e

    config_mod.save_last_report({
        "report_id": report_id,
        "task_name": task_name,
        "uploaded_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "payload": report,
        "task_submission_id": ts["id"],
        "task_submission_name": ts["name"],
    })

    console.print(
        f"[green]✓ Linked to task '{task_name}' → progress 25%[/green]"
    )
    console.print("View on https://opslabel.in/app")

    s = report["summary"]
    gate_ok = (s.get("failed", 0) + s.get("warned", 0)) <= 1
    if gate_ok:
        console.print(
            "\n[dim]→ run [bold]opslabel request-review[/bold] to send this "
            "report to your pod lead.[/dim]"
        )


def _format_check_line(name: str, r: dict) -> str:
    duration_ms = r.get("duration_ms", 0)
    dur_s = f" [dim]({duration_ms/1000:.1f}s)[/dim]" if duration_ms >= 1000 else ""

    if r.get("skipped"):
        reason = r.get("reason", "skipped")
        return f"  [dim]○ {name}: {reason}[/dim]{dur_s}"
    if r.get("passed") is False or r.get("severity") == "error":
        return f"  [red]✗[/red] [bold]{name}[/bold]: {r.get('summary', 'failed')}{dur_s}"
    if r.get("severity") == "warn":
        return f"  [yellow]⚠[/yellow] [bold]{name}[/bold]: {r.get('summary', 'warning')}{dur_s}"
    score = r.get("score")
    score_s = f" [dim][{score}][/dim]" if score is not None else ""
    return f"  [green]✓[/green] [bold]{name}[/bold]{score_s}: {r.get('summary', 'passed')}{dur_s}"


# --------------------------------------------------------------------------- #
# request-review (sends the last cached scan to a pod for review)
# --------------------------------------------------------------------------- #

@app.command(name="request-review")
def request_review() -> None:
    """Send your most recent scan report to your pod for review.

    Uses the report cached locally by the last successful `opslabel scan`.
    Run `opslabel scan` first, view the verdict, then run this when you're
    ready to send it for pod review. Gated: report must have <=1 failed/warned
    check.
    """
    console = Console(stderr=True)
    # Validate session up-front (local + server-side cliSessions doc).
    cfg, id_token = _open_authenticated_session(console)

    last = config_mod.load_last_report()
    if not last:
        console.print(
            "[red]No previous scan found.[/red] "
            "Run `opslabel scan <task>` first, then re-run this command."
        )
        raise typer.Exit(1)

    report = last.get("payload")
    report_id = last.get("report_id")
    ts_name = last.get("task_submission_name")
    if not isinstance(report, dict) or not report_id:
        console.print(
            "[red]Cached report is incomplete.[/red] Re-run `opslabel scan`."
        )
        raise typer.Exit(1)
    if not ts_name:
        # Pre-0.4.0 cache: scanned before taskSubmissions linking existed.
        console.print(
            "[red]Cached scan report doesn't reference a dashboard task "
            "submission.[/red] Re-run [bold]opslabel scan[/bold] to refresh "
            "the cache before requesting review."
        )
        raise typer.Exit(1)

    task_name = report.get("task_name") or "(unknown)"
    s = report.get("summary") or {}
    verdict = str(s.get("verdict", "?")).upper()
    counts = (
        f"{s.get('passed', 0)} passed · {s.get('warned', 0)} warned · "
        f"{s.get('failed', 0)} failed · {s.get('skipped', 0)} skipped"
    )
    uploaded_at = last.get("uploaded_at", "?")

    console.print(f"[bold]Last scan:[/bold]   {task_name}")
    console.print(f"[bold]Report ID:[/bold]   {report_id}")
    console.print(f"[bold]Uploaded:[/bold]    {uploaded_at}")
    console.print(f"[bold]Verdict:[/bold]     {verdict}  ({counts})")
    console.print()

    # Re-load in case _open_authenticated_session rotated the refresh token.
    cfg = config_mod.load() or cfg

    _create_review_request(
        console=console,
        cfg=cfg,
        id_token=id_token,
        report=report,
        report_id=report_id,
        task_submission_name=ts_name,
    )


# --------------------------------------------------------------------------- #
# logout
# --------------------------------------------------------------------------- #

@app.command()
def logout() -> None:
    """Disconnect this machine from OpsLabel.

    Best-effort deletes the CLI session on the server, then removes the local
    config and cached scan report. After logout, run `opslabel auth <code>`
    to pair again.
    """
    cfg = config_mod.load()

    server_deleted = False
    if cfg and cfg.get("anonUid") and cfg.get("refreshToken"):
        try:
            refreshed = firebase.refresh_id_token(cfg["refreshToken"])
            id_token = refreshed["id_token"]
            firebase.delete_cli_session(id_token, cfg["anonUid"])
            server_deleted = True
        except (firebase.FirebaseError, requests.RequestException):
            # Best-effort: stale refresh token, expired session, or no network.
            # Local cleanup proceeds regardless.
            pass

    for f in (config_mod.CONFIG_FILE, config_mod.LAST_REPORT_FILE):
        try:
            f.unlink()
        except FileNotFoundError:
            pass
        except OSError as e:
            typer.secho(
                f"Warning: could not remove {f}: {e}",
                fg=typer.colors.YELLOW, err=True,
            )

    if server_deleted:
        typer.secho("✓ Logged out.", fg=typer.colors.GREEN)
    else:
        typer.secho(
            "✓ Local config cleared. (Server-side session may still exist; "
            "it will expire on its own.)",
            fg=typer.colors.GREEN,
        )
    typer.echo("Run `opslabel auth <code>` to pair again.")


def _create_review_request(
    *,
    console: Console,
    cfg: dict,
    id_token: str,
    report: dict,
    report_id: str,
    task_submission_name: str,
) -> None:
    """Gate the report, find the contributor's pod, create a reviewRequests
    doc, and link it back to the dashboard's taskSubmissions doc."""
    s = report.get("summary") or {}
    if (s.get("failed", 0) + s.get("warned", 0)) > 1:
        console.print(
            f"\n[red]Cannot request review: {s.get('failed', 0)} failed + "
            f"{s.get('warned', 0)} warned > 1.[/red]"
        )
        console.print("Fix the failing checks and re-scan before requesting review.")
        raise typer.Exit(1)

    # contributorUid is the contributor's real (Google) UID. Firestore rules
    # verify the CLI's authority to write on its behalf via the
    # cliSessions/{anonUid} doc created at `opslabel auth` time — that doc
    # maps anonUid → contributorUid, and is chained-validated against the
    # original cliPairings doc so it can't be forged.
    contributor_uid = cfg["contributorUid"]
    project_id = cfg["projectId"]

    try:
        with _maybe_status(console, "[cyan]finding your review pod…[/cyan]"):
            pod = firebase.find_pod_for_contributor(
                id_token, contributor_uid, project_id
            )
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
            raise typer.Exit(1) from e
        console.print(f"[red]Pod lookup failed: {e}[/red]")
        raise typer.Exit(1) from e

    if not pod:
        console.print(
            "[red]No review pod found for this project.[/red] "
            "Ask an admin to add you to a pod, then retry."
        )
        raise typer.Exit(1)

    pod_id = pod["id"]
    pod_hash_name = str(pod["data"].get("hashName") or "")

    user_doc = firebase.get_user_doc(id_token, cfg["contributorUid"])
    contributor_name = _resolve_display_name(user_doc, cfg["contributorUid"])

    now = datetime.now(timezone.utc)
    review_fields = {
        "podId": pod_id,
        "podHashName": pod_hash_name,
        "projectId": project_id,
        "contributorUid": contributor_uid,
        "contributorName": contributor_name,
        "qaReportId": report_id,
        "taskName": report.get("task_name", ""),
        "qaReportPayload": report,
        "qaReportCliVersion": __version__,
        "qaReportMachineName": socket.gethostname(),
        "qaReportCreatedAt": now,
        "status": "pending",
        "createdAt": now,
        "updatedAt": now,
    }

    try:
        with _maybe_status(console, "[cyan]creating review request…[/cyan]"):
            rr_name = firebase.create_review_request(id_token, review_fields)
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
            raise typer.Exit(1) from e
        console.print(f"[red]Review request write failed: {e}[/red]")
        raise typer.Exit(1) from e

    rr_id = rr_name.rsplit("/", 1)[-1]
    label = pod_hash_name or pod_id
    console.print(f"[green]✓ Review requested from {label}[/green] — id {rr_id}")

    # Advance the dashboard's task progress: 25% (scanned) → 50% (awaiting review)
    try:
        with _maybe_status(console, "[cyan]updating task progress…[/cyan]"):
            firebase.update_task_submission(
                id_token,
                task_submission_name,
                {
                    "reviewRequestId": rr_id,
                    "stage": "awaiting_review",
                    "updatedAt": datetime.now(timezone.utc),
                },
            )
    except firebase.FirebaseError as e:
        if e.is_permission_denied:
            _print_stale_session(console)
            raise typer.Exit(1) from e
        console.print(
            f"[red]Review request created but task-link update failed: {e}[/red]"
        )
        raise typer.Exit(1) from e

    console.print("[green]✓ Linked to task → progress 50% (awaiting review)[/green]")
    console.print("Pod lead will see status update on opslabel.in/app")


def _print_stale_session(console: Console) -> None:
    """Friendly message when Firestore rejects with PERMISSION_DENIED.

    Three plausible causes, all with the same fix:
      1. Session expired (server-side, even if local clock disagrees)
      2. Session was deleted (e.g., another `opslabel logout`)
      3. Pre-Phase-3 pairing without a cliSessions doc
    """
    console.print(
        "[red]Your CLI session has expired, been revoked, or is out of sync.[/red]\n"
        "Re-pair with [bold]opslabel auth <new-code>[/bold] — "
        "generate a fresh code from the dashboard."
    )


def _resolve_display_name(user_doc: Optional[dict], uid: str) -> str:
    """Mirror dashboard's resolveUserName chain, simplified.

    profile.fullName → displayName → fullName → name → firstName+lastName →
    email local-part → uid prefix. Email-shaped values get their local part
    extracted (so `displayName == "alice@x.com"` becomes "alice").
    """
    def local(s: str) -> str:
        i = s.find("@")
        return s[:i].strip() if i > 0 else s.strip()

    if user_doc:
        profile = user_doc.get("profile") if isinstance(user_doc.get("profile"), dict) else None
        candidates: list = []
        if profile:
            candidates.append(profile.get("fullName"))
        candidates.extend([
            user_doc.get("displayName"),
            user_doc.get("fullName"),
            user_doc.get("name"),
        ])
        first = user_doc.get("firstName")
        last = user_doc.get("lastName")
        if isinstance(first, str) or isinstance(last, str):
            candidates.append(" ".join(p for p in (first, last) if isinstance(p, str) and p))
        for c in candidates:
            if isinstance(c, str) and c.strip():
                return local(c) if "@" in c else c.strip()
        email = user_doc.get("email")
        if isinstance(email, str) and email.strip():
            return local(email)
    return f"{uid[:8]}…"


def _print_verdict(console: Console, report: dict) -> None:
    s = report["summary"]
    color = (
        "green" if s["verdict"] == "pass"
        else "yellow" if s["verdict"] == "pass_with_warnings"
        else "red"
    )
    console.print(
        f"\n[bold {color}]{s['verdict'].upper()}[/bold {color}] — "
        f"{s['passed']} passed, {s['warned']} warned, "
        f"{s['failed']} failed, {s['skipped']} skipped"
        f"  [dim]({report['duration_ms']/1000:.1f}s)[/dim]"
    )


# --------------------------------------------------------------------------- #
# config subgroup
# --------------------------------------------------------------------------- #

@config_app.command("set-nim-key")
def cfg_set_nim_key(
    key: str = typer.Argument(..., help="NVIDIA NIM API key (typically starts with `nvapi-`)."),
) -> None:
    """Store a NIM API key for LLM-judge checks."""
    if not key.strip():
        typer.secho("Empty key.", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    config_mod.update({"nimApiKey": key.strip()})
    typer.secho(
        f"✓ NIM key saved ({config_mod.mask_secret(key.strip())}) → {config_mod.CONFIG_FILE}",
        fg=typer.colors.GREEN,
    )


@config_app.command("show")
def cfg_show() -> None:
    """Print current config (secrets masked)."""
    typer.echo(f"Config file: {config_mod.CONFIG_FILE}")
    cfg = config_mod.load()
    if not cfg:
        typer.secho("(not paired — run `opslabel auth <code>`)", fg=typer.colors.YELLOW)
        return
    typer.echo(f"  contributorUid: {cfg.get('contributorUid', '<not set>')}")
    typer.echo(f"  projectId:      {cfg.get('projectId', '<not set>')}")
    typer.echo(f"  anonUid:        {cfg.get('anonUid', '<not set>')}")
    typer.echo(f"  refreshToken:   {config_mod.mask_secret(cfg.get('refreshToken'))}")
    typer.echo(f"  nimApiKey:      {config_mod.mask_secret(cfg.get('nimApiKey'))}")
    import os
    if os.environ.get("NIM_API_KEY"):
        typer.secho(
            "  (env NIM_API_KEY is set and will override the stored nimApiKey)",
            fg=typer.colors.YELLOW,
        )
