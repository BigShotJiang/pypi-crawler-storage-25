import json
from datetime import datetime, timezone
from typing import Any, Optional

import requests

API_KEY = "AIzaSyBfDod4StY1Z8vcFEr1cNzbleYzT2ef6E4"
PROJECT_ID = "opslabel"

IDENTITY_URL = "https://identitytoolkit.googleapis.com/v1"
SECURE_TOKEN_URL = "https://securetoken.googleapis.com/v1"
FIRESTORE_BASE = "https://firestore.googleapis.com/v1"
FIRESTORE_DOCS = f"{FIRESTORE_BASE}/projects/{PROJECT_ID}/databases/(default)/documents"

TIMEOUT = 20


# ---------- auth ----------

def sign_up_anonymous() -> dict:
    r = requests.post(
        f"{IDENTITY_URL}/accounts:signUp",
        params={"key": API_KEY},
        json={"returnSecureToken": True},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "anonymous sign-in")
    return r.json()


def refresh_id_token(refresh_token: str) -> dict:
    r = requests.post(
        f"{SECURE_TOKEN_URL}/token",
        params={"key": API_KEY},
        data={"grant_type": "refresh_token", "refresh_token": refresh_token},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "refresh token")
    return r.json()


# ---------- firestore typed values ----------

def _to_value(v: Any) -> dict:
    if v is None:
        return {"nullValue": None}
    if isinstance(v, bool):
        return {"booleanValue": v}
    if isinstance(v, int):
        return {"integerValue": str(v)}
    if isinstance(v, float):
        return {"doubleValue": v}
    if isinstance(v, str):
        return {"stringValue": v}
    if isinstance(v, datetime):
        ts = v.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return {"timestampValue": ts}
    if isinstance(v, dict):
        return {"mapValue": {"fields": {k: _to_value(val) for k, val in v.items()}}}
    if isinstance(v, list):
        return {"arrayValue": {"values": [_to_value(x) for x in v]}}
    raise TypeError(f"Unsupported Firestore field type: {type(v).__name__}")


def _from_value(v: dict) -> Any:
    if "stringValue" in v:
        return v["stringValue"]
    if "booleanValue" in v:
        return v["booleanValue"]
    if "integerValue" in v:
        return int(v["integerValue"])
    if "doubleValue" in v:
        return v["doubleValue"]
    if "nullValue" in v:
        return None
    if "timestampValue" in v:
        return v["timestampValue"]
    if "mapValue" in v:
        return {k: _from_value(val) for k, val in v["mapValue"].get("fields", {}).items()}
    if "arrayValue" in v:
        return [_from_value(x) for x in v["arrayValue"].get("values", [])]
    return None


def _to_fields(d: dict) -> dict:
    return {k: _to_value(v) for k, v in d.items()}


def _from_fields(fields: dict) -> dict:
    return {k: _from_value(v) for k, v in fields.items()}


# ---------- firestore ops ----------

def query_pairing_by_code(id_token: str, code: str) -> Optional[dict]:
    body = {
        "structuredQuery": {
            "from": [{"collectionId": "cliPairings"}],
            "where": {
                "fieldFilter": {
                    "field": {"fieldPath": "code"},
                    "op": "EQUAL",
                    "value": {"stringValue": code},
                }
            },
            "limit": 1,
        }
    }
    r = requests.post(
        f"{FIRESTORE_DOCS}:runQuery",
        json=body,
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "query pairing")
    for entry in r.json():
        doc = entry.get("document")
        if doc:
            return {
                "name": doc["name"],
                "id": doc["name"].rsplit("/", 1)[-1],
                "data": _from_fields(doc.get("fields", {})),
            }
    return None


def update_pairing(id_token: str, doc_name: str, fields: dict) -> None:
    params = [("updateMask.fieldPaths", k) for k in fields.keys()]
    r = requests.patch(
        f"{FIRESTORE_BASE}/{doc_name}",
        params=params,
        json={"fields": _to_fields(fields)},
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "update pairing")


def create_qa_report(id_token: str, fields: dict) -> str:
    r = requests.post(
        f"{FIRESTORE_DOCS}/qaReports",
        json={"fields": _to_fields(fields)},
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "create QA report")
    return r.json()["name"]


def create_cli_session(id_token: str, anon_uid: str, fields: dict) -> None:
    """Create cliSessions/{anonUid} with the chained-validation fields.

    The doc id MUST equal the CLI's anon UID — Firestore rules use
    `match /cliSessions/{anonUid}` and require `request.auth.uid == anonUid`.
    Uses the createDocument REST endpoint (POST with `documentId` query param)
    so we can pin the doc id rather than letting Firestore auto-generate one.
    """
    r = requests.post(
        f"{FIRESTORE_DOCS}/cliSessions",
        params={"documentId": anon_uid},
        json={"fields": _to_fields(fields)},
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "create CLI session")


def delete_cli_session(id_token: str, anon_uid: str) -> None:
    """Delete cliSessions/{anonUid}. Used by `opslabel logout`."""
    r = requests.delete(
        f"{FIRESTORE_DOCS}/cliSessions/{anon_uid}",
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    # 200 = deleted; 404 = already gone (treat as success)
    if r.status_code == 404:
        return
    _raise_for_firebase(r, "delete CLI session")


def get_cli_session(id_token: str, anon_uid: str) -> Optional[dict]:
    """Fetch cliSessions/{anonUid}. Returns parsed doc data, or None if it
    doesn't exist (404). Used to verify the session is still valid before
    expensive work — the dashboard can delete this doc to disconnect.
    """
    r = requests.get(
        f"{FIRESTORE_DOCS}/cliSessions/{anon_uid}",
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    if r.status_code == 404:
        return None
    _raise_for_firebase(r, "fetch CLI session")
    try:
        return _from_fields(r.json().get("fields", {}))
    except Exception:
        return None


def find_pod_for_contributor(
    id_token: str, contributor_uid: str, project_id: str
) -> Optional[dict]:
    """Return the first pod where memberUids contains contributor_uid AND projectId matches."""
    body = {
        "structuredQuery": {
            "from": [{"collectionId": "pods"}],
            "where": {
                "compositeFilter": {
                    "op": "AND",
                    "filters": [
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "memberUids"},
                                "op": "ARRAY_CONTAINS",
                                "value": {"stringValue": contributor_uid},
                            }
                        },
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "projectId"},
                                "op": "EQUAL",
                                "value": {"stringValue": project_id},
                            }
                        },
                    ],
                }
            },
            "limit": 1,
        }
    }
    r = requests.post(
        f"{FIRESTORE_DOCS}:runQuery",
        json=body,
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "find pod")
    for entry in r.json():
        doc = entry.get("document")
        if doc:
            return {
                "name": doc["name"],
                "id": doc["name"].rsplit("/", 1)[-1],
                "data": _from_fields(doc.get("fields", {})),
            }
    return None


def get_user_doc(id_token: str, uid: str) -> Optional[dict]:
    """Best-effort fetch of /users/{uid}. Returns None on permission denied / 404 / parse error."""
    r = requests.get(
        f"{FIRESTORE_DOCS}/users/{uid}",
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    if r.status_code != 200:
        return None
    try:
        return _from_fields(r.json().get("fields", {}))
    except Exception:
        return None


def create_review_request(id_token: str, fields: dict) -> str:
    r = requests.post(
        f"{FIRESTORE_DOCS}/reviewRequests",
        json={"fields": _to_fields(fields)},
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "create review request")
    return r.json()["name"]


def find_task_submission(
    id_token: str,
    contributor_uid: str,
    project_id: str,
    task_name: str,
) -> Optional[dict]:
    """Find the most recent OPEN taskSubmissions doc for this contributor+task.

    Match criteria:
      contributorUid == contributor_uid
      projectId      == project_id
      taskName       == task_name
      stage          IN ['created', 'rework', 'scanned']
    Ordered by createdAt DESC, limit 1.

    'scanned' is included so that `request-review` (which re-finds the doc
    after `scan` already advanced stage from 'created' to 'scanned') still
    matches. Stages 'awaiting_review' / 'accepted' / 'submitted' remain
    excluded — once review has started or finished, the CLI shouldn't
    retroactively rewrite the qaReport/reviewRequest links.

    Returns {name, id, data} or None when no match exists.
    """
    body = {
        "structuredQuery": {
            "from": [{"collectionId": "taskSubmissions"}],
            "where": {
                "compositeFilter": {
                    "op": "AND",
                    "filters": [
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "contributorUid"},
                                "op": "EQUAL",
                                "value": {"stringValue": contributor_uid},
                            }
                        },
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "projectId"},
                                "op": "EQUAL",
                                "value": {"stringValue": project_id},
                            }
                        },
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "taskName"},
                                "op": "EQUAL",
                                "value": {"stringValue": task_name},
                            }
                        },
                        {
                            "fieldFilter": {
                                "field": {"fieldPath": "stage"},
                                "op": "IN",
                                "value": {
                                    "arrayValue": {
                                        "values": [
                                            {"stringValue": "created"},
                                            {"stringValue": "rework"},
                                            {"stringValue": "scanned"},
                                        ]
                                    }
                                },
                            }
                        },
                    ],
                }
            },
            "orderBy": [
                {
                    "field": {"fieldPath": "createdAt"},
                    "direction": "DESCENDING",
                }
            ],
            "limit": 1,
        }
    }
    r = requests.post(
        f"{FIRESTORE_DOCS}:runQuery",
        json=body,
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "find task submission")
    for entry in r.json():
        doc = entry.get("document")
        if doc:
            return {
                "name": doc["name"],
                "id": doc["name"].rsplit("/", 1)[-1],
                "data": _from_fields(doc.get("fields", {})),
            }
    return None


def update_task_submission(id_token: str, doc_name: str, fields: dict) -> None:
    """PATCH a taskSubmissions doc. Uses updateMask so we don't clobber unrelated fields."""
    params = [("updateMask.fieldPaths", k) for k in fields.keys()]
    r = requests.patch(
        f"{FIRESTORE_BASE}/{doc_name}",
        params=params,
        json={"fields": _to_fields(fields)},
        headers={"Authorization": f"Bearer {id_token}"},
        timeout=TIMEOUT,
    )
    _raise_for_firebase(r, "update task submission")


# ---------- error helpers ----------

class FirebaseError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        status: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.status = status

    @property
    def is_permission_denied(self) -> bool:
        return self.status_code == 403 or self.status == "PERMISSION_DENIED"


def _raise_for_firebase(r: requests.Response, action: str) -> None:
    if r.ok:
        return
    detail = ""
    status: Optional[str] = None
    try:
        body = r.json()
        err = body.get("error", body)
        if isinstance(err, dict):
            detail = err.get("message") or json.dumps(err)
            s = err.get("status")
            if isinstance(s, str):
                status = s
        else:
            detail = str(err)
    except Exception:
        detail = r.text[:300]
    raise FirebaseError(
        f"{action} failed ({r.status_code}): {detail}",
        status_code=r.status_code,
        status=status,
    )
