"""OpsLabel CLI banner — 2-column layout where the banner art sits on the
left and ALL command output flows into the right column.

How it works:
  - `install_banner_wrapper()` (called from cli.py's root callback) wraps
    sys.stderr (and sys.stdout, when it's a TTY) so each line of output
    gets prefixed with the next row of the banner art.
  - The shared `BannerCoordinator` advances one row per output line, so
    stdout and stderr writes both pull from the same 12-row pool.
  - Once the banner is exhausted, output continues at full width.
  - On exit, `finish_banner()` pads remaining rows with empty content so
    the banner art always shows in full.

Suppression:
  - `OPSLABEL_NO_BANNER=1` disables it.
  - Auto-suppressed when stderr isn't a TTY (so piped output stays clean).
  - `NO_COLOR=1` keeps the banner but drops ANSI codes.
"""
from __future__ import annotations

import os
import sys
from typing import IO, Optional

from . import __version__

# Brand: #FE4D00
ORANGE = "\033[38;2;254;77;0m"
DARK = "\033[38;2;30;30;30m"
DIM = "\033[38;2;130;125;120m"
BOLD = "\033[1m"
RESET = "\033[0m"


def _supports_color(stream: Optional[IO] = None) -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    s = stream if stream is not None else sys.stderr
    if not hasattr(s, "isatty") or not s.isatty():
        return False
    if sys.platform == "win32":
        return bool(os.environ.get("WT_SESSION") or os.environ.get("ANSICON"))
    return True


def _c(color: str, text: str, *, on: bool) -> str:
    return f"{color}{text}{RESET}" if on else text


_COMPACT_ART = [
    "  ▄▀▄          ▄▀▄ ",   # ear tufts + feather marks
    "▀██▀▀▀███  ███▀▀▀██▀",   # ear bases + head top
    "  █▀▀█▄▄▀▀▀▀▄▄█▀▀█",     # forehead
    " █  ██.██  ██.██  █",    # eyes
    " █  ▀██▀    ▀██▀  █",    # eye bottoms
    "▄███▄▄▄▄████▄▄▄▄███▄",   # chin
    "▄██▌░░▒░░▒▒░░▒░░▐██▄",   # chest top + wing seams + light bib
    "███░░▒▒░░▒▒░░▒▒░░███",   # body + feather barring
    "███░░▒▒░░▒▒░░▒▒░░███",
    " ▀█▌ ░▒░░▒▒░░▒░ ▐█▀ ",   # belly + wing seams
    "   ▀▀▀████████▀▀▀   ",   # wing/tail tips
    "       ▀▀  ▀▀       ",   # feet
]


def should_print() -> bool:
    if os.environ.get("OPSLABEL_NO_BANNER"):
        return False
    if not (hasattr(sys.stderr, "isatty") and sys.stderr.isatty()):
        return False
    return True


# --------------------------------------------------------------------------- #
# Stream wrapping for live banner-prefix injection
# --------------------------------------------------------------------------- #


class BannerCoordinator:
    """Shared row-counter between stdout and stderr wrappers so the banner
    advances exactly once per emitted line, regardless of which stream
    produced it."""

    def __init__(self, art_lines: list[str], *, color: bool) -> None:
        self.art_lines = art_lines
        self.color = color
        self.row = 0
        self.left_width = max(len(line) for line in art_lines)

    def has_lines_left(self) -> bool:
        return self.row < len(self.art_lines)

    def take_prefix(self) -> Optional[str]:
        if self.row >= len(self.art_lines):
            return None
        art = self.art_lines[self.row]
        self.row += 1
        pad = " " * (self.left_width - len(art))
        if self.color:
            return f"{ORANGE}{art}{RESET}{pad}    "
        return f"{art}{pad}    "


class BannerStream:
    """Buffers writes until newline, then prepends the next banner row.

    Buffering on newline (rather than passing through real-time) makes us
    incompatible with live spinners — the cli.py side avoids creating
    rich.console.Console.status() while a banner is active.
    """

    def __init__(self, original: IO, coordinator: BannerCoordinator) -> None:
        self.original = original
        self.coord = coordinator
        self.buffer = ""

    @property
    def is_tty(self) -> bool:
        return hasattr(self.original, "isatty") and self.original.isatty()

    def write(self, text: str) -> int:
        if not self.is_tty:
            return self.original.write(text)
        # Once the banner art is fully drawn, pass writes through in real time.
        # This is what lets rich spinners (which write \r-updates without
        # newlines) animate properly after the banner is done.
        if not self.coord.has_lines_left():
            if self.buffer:
                self.original.write(self.buffer)
                self.buffer = ""
            return self.original.write(text)
        # Inside the banner zone: buffer until newline so each output line
        # gets a banner-row prefix.
        self.buffer += text
        while "\n" in self.buffer:
            line, self.buffer = self.buffer.split("\n", 1)
            self._emit(line)
        return len(text)

    def _emit(self, line: str) -> None:
        prefix = self.coord.take_prefix()
        if prefix is None:
            self.original.write(line + "\n")
        else:
            self.original.write(prefix + line + "\n")

    def flush(self) -> None:
        self.original.flush()

    def drain_buffer(self) -> None:
        """Force-emit anything left in the buffer (no trailing newline)."""
        if self.buffer:
            self._emit(self.buffer)
            self.buffer = ""

    def isatty(self) -> bool:
        return self.is_tty

    def fileno(self) -> int:
        return self.original.fileno()

    def __getattr__(self, name: str):
        return getattr(self.original, name)


_active_coord: Optional[BannerCoordinator] = None
_active_err_wrapper: Optional[BannerStream] = None
_active_out_wrapper: Optional[BannerStream] = None


def is_active() -> bool:
    """True when the banner wrapper is installed (so cli.py can opt out
    of features that conflict with the left-margin layout, e.g. spinners)."""
    return _active_coord is not None


def is_exhausted() -> bool:
    """True when no banner rows remain (or the banner isn't active at all).
    cli.py checks this to decide when it's safe to start a rich spinner —
    after the banner art is fully drawn, cursor-controls don't fight a
    left-margin anymore."""
    if _active_coord is None:
        return True
    return not _active_coord.has_lines_left()


def install_banner_wrapper() -> Optional[BannerStream]:
    """Wrap stderr (and stdout, if TTY) so output flows into the banner's
    right column. Writes the 3 header lines (CLI name, separator, tagline)
    immediately so they consume banner rows 0–2."""
    global _active_coord, _active_err_wrapper, _active_out_wrapper
    if not should_print():
        return None

    on = _supports_color(sys.stderr)
    coord = BannerCoordinator(_COMPACT_ART, color=on)

    err_wrapper = BannerStream(sys.stderr, coord)
    sys.stderr = err_wrapper  # type: ignore[assignment]

    out_wrapper: Optional[BannerStream] = None
    if hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
        out_wrapper = BannerStream(sys.stdout, coord)
        sys.stdout = out_wrapper  # type: ignore[assignment]

    title = (
        _c(BOLD + ORANGE, "OpsLabel CLI", on=on)
        + _c(DIM, f"   v{__version__}", on=on)
    )
    sep = _c(DIM, "───────────────────────────────", on=on)
    tag = (
        _c(DARK, "AI Data Operations", on=on)
        + _c(DIM, "  ·  opslabel.in", on=on)
    )
    # Two blank rows so the title sits centered against the disc/face.
    err_wrapper.write("\n")
    err_wrapper.write("\n")
    err_wrapper.write(title + "\n")
    err_wrapper.write(sep + "\n")
    err_wrapper.write(tag + "\n")
    err_wrapper.write(sep + "\n")

    _active_coord = coord
    _active_err_wrapper = err_wrapper
    _active_out_wrapper = out_wrapper
    return err_wrapper


def finish_banner() -> None:
    """Pad any remaining banner rows with empty right-column content so the
    art always shows in full. Registered via atexit by cli.py."""
    if _active_coord is None or _active_err_wrapper is None:
        return
    if _active_out_wrapper is not None:
        _active_out_wrapper.drain_buffer()
    _active_err_wrapper.drain_buffer()
    while _active_coord.has_lines_left():
        _active_err_wrapper._emit("")
    try:
        _active_err_wrapper.original.flush()
    except Exception:
        pass
