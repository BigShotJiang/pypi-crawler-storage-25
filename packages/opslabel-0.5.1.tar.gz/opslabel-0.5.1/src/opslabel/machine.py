from __future__ import annotations

import platform
import re
import socket
import subprocess
import sys
from typing import Optional


def _os_name() -> str:
    p = sys.platform
    if p.startswith("linux"):
        return "linux"
    if p == "darwin":
        return "darwin"
    if p in ("win32", "cygwin"):
        return "windows"
    return p


def _tool_version(cmd: list[str]) -> Optional[str]:
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=5, text=True)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    if r.returncode != 0:
        return None
    blob = (r.stdout or "") + (r.stderr or "")
    m = re.search(r"(\d+\.\d+(?:\.\d+)?)", blob)
    return m.group(1) if m else None


def info() -> dict:
    return {
        "hostname": socket.gethostname(),
        "os": _os_name(),
        "python_version": platform.python_version(),
        "docker_version": _tool_version(["docker", "--version"]),
        "harbor_version": _tool_version(["harbor", "--version"]),
    }
