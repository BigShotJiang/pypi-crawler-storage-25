"""Scan orchestrator — runs the 8 checks and assembles a v2 report."""

from __future__ import annotations

import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from . import __version__, checks, machine


TASK_INSTRUCTION_MAX_CHARS = 50_000


CHECK_ORDER = [
    "skeleton",
    "task_metadata",
    "canary_present",
    "oracle_run",
    "nop_run",
    "instruction_balance",
    "hint_leakage",
    "test_strictness",
    "gptzero_check",
]


def run_scan(
    task_path: Path,
    *,
    rerun_oracle: bool,
    rerun_nop: bool,
    skip_llm: bool,
    nim_key: Optional[str],
    on_progress: Optional[Callable[[str, str, Optional[dict]], None]] = None,
    task_name: Optional[str] = None,
) -> dict:
    """Run all 8 checks and return the v2 report dict.

    `on_progress(name, event, result)` is called twice per check:
      - event="start", result=None — when the check begins
      - event="done",  result=dict — when the check finishes

    `task_name`, if set, overrides the folder basename in the report's
    `task_name` field. Used by cli.py to honor the `--task-name` flag.
    """
    notify = on_progress or (lambda *_a, **_kw: None)
    started = datetime.now(timezone.utc)
    t0 = time.monotonic()

    results: dict[str, dict] = {}

    def _run(name: str, fn: Callable[..., dict], *args: Any, **kwargs: Any) -> None:
        notify(name, "start", None)
        results[name] = _safe(fn, *args, **kwargs)
        notify(name, "done", results[name])

    def _force(name: str, reason: str) -> None:
        notify(name, "start", None)
        results[name] = _force_skip(reason)
        notify(name, "done", results[name])

    _run("skeleton", checks.check_skeleton, task_path)
    _run("task_metadata", checks.check_task_metadata, task_path)
    _run("canary_present", checks.check_canary, task_path)
    _run("oracle_run", checks.check_oracle_run, task_path, rerun=rerun_oracle)
    _run("nop_run", checks.check_nop_run, task_path, rerun=rerun_nop)

    if skip_llm:
        for name in ("instruction_balance", "hint_leakage", "test_strictness"):
            _force(name, "LLM checks disabled by --skip-llm")
    else:
        _run("instruction_balance", checks.check_instruction_balance, task_path, nim_key)
        _run("hint_leakage", checks.check_hint_leakage, task_path, nim_key)
        _run("test_strictness", checks.check_test_strictness, task_path, nim_key)

    _run("gptzero_check", checks.check_gptzero, task_path)

    summary = _summarize(results)
    duration_ms = int((time.monotonic() - t0) * 1000)

    report: dict[str, Any] = {
        "schema_version": 2,
        "task_path": str(task_path.resolve()),
        "task_name": task_name or task_path.name,
        "task_metadata": _read_task_metadata_header(task_path),
        "ran_at": started.isoformat().replace("+00:00", "Z"),
        "duration_ms": duration_ms,
        "cli_version": __version__,
        "machine": machine.info(),
        "summary": summary,
        "checks": results,
    }
    instruction = _read_task_instruction(task_path)
    if instruction is not None:
        report["task_instruction_md"] = instruction
    return report


def _read_task_instruction(task_path: Path) -> Optional[str]:
    """Read instruction.md raw, capped at TASK_INSTRUCTION_MAX_CHARS.
    Returns None if the file is missing or unreadable (so the field is
    omitted from the payload — the dashboard renders conditionally).
    """
    p = task_path / "instruction.md"
    if not p.is_file():
        return None
    try:
        text = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    if len(text) > TASK_INSTRUCTION_MAX_CHARS:
        text = text[:TASK_INSTRUCTION_MAX_CHARS] + "\n\n[...truncated]"
    return text


def _force_skip(reason: str) -> dict:
    return {
        "passed": False,
        "skipped": True,
        "reason": reason,
        "severity": "info",
        "summary": reason,
        "details": {},
        "duration_ms": 0,
    }


def _safe(fn: Callable[..., dict], *args: Any, **kwargs: Any) -> dict:
    """Run a check with a generic crash-guard so one bad check can't kill the scan."""
    t0 = time.monotonic()
    try:
        return fn(*args, **kwargs)
    except Exception as e:
        return {
            "passed": False,
            "skipped": False,
            "severity": "error",
            "summary": f"check crashed: {type(e).__name__}: {e}",
            "details": {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc(limit=4),
            },
            "duration_ms": int((time.monotonic() - t0) * 1000),
        }


def _summarize(results: dict[str, dict]) -> dict:
    passed = warned = failed = skipped = 0
    for r in results.values():
        if r.get("skipped"):
            skipped += 1
        elif r.get("passed") is False or r.get("severity") == "error":
            failed += 1
        elif r.get("severity") == "warn":
            warned += 1
        else:
            passed += 1

    if failed > 0:
        verdict = "fail"
    elif warned > 0:
        verdict = "pass_with_warnings"
    else:
        verdict = "pass"

    return {
        "verdict": verdict,
        "passed": passed,
        "warned": warned,
        "failed": failed,
        "skipped": skipped,
    }


def _read_task_metadata_header(task_path: Path) -> dict:
    """Best-effort metadata extraction for the report header.
    The task_metadata check does its own validation; this is only for the dashboard's
    metadata strip, so failures degrade silently.
    """
    try:
        data = checks.load_toml(task_path / "task.toml")
    except Exception:
        return {}
    meta = data.get("metadata") or {}
    if not isinstance(meta, dict):
        meta = {}
    tags = meta.get("tags")
    if not isinstance(tags, list):
        tags = []
    return {
        "version": data.get("version") if isinstance(data.get("version"), str) else None,
        "author_name": meta.get("author_name") if isinstance(meta.get("author_name"), str) else None,
        "author_email": meta.get("author_email") if isinstance(meta.get("author_email"), str) else None,
        "difficulty": meta.get("difficulty") if isinstance(meta.get("difficulty"), str) else None,
        "category": meta.get("category") if isinstance(meta.get("category"), str) else None,
        "tags": [t for t in tags if isinstance(t, str)],
    }
